/**
 * Mock Exam JavaScript
 * Interactive exam functionality with timer, navigation, and results
 * @since 7.3.8
 */

jQuery(document).ready(function ($) {
    'use strict';

    const container = $('#nm-mock-exam-container');
    if (container.length === 0) return;

    // Parse exam data from HTML
    const questionsData = JSON.parse(container.attr('data-questions'));
    const timeLimit = parseInt(container.attr('data-time-limit')) * 60; // Convert to seconds
    const passingScore = parseInt(container.attr('data-passing-score'));
    const topicSlug = container.attr('data-topic') || 'general';

    // State variables
    let currentQuestionIndex = 0;
    let userAnswers = {};
    let flaggedQuestions = new Set();
    let timerInterval = null;
    let timeElapsed = 0;
    let examStartTime = null;

    // Screen elements
    const startScreen = $('#nm-exam-start-screen');
    const questionScreen = $('#nm-exam-question-screen');
    const resultsScreen = $('#nm-exam-results-screen');

    // Navigation elements
    const startBtn = $('#nm-start-exam-btn');
    const prevBtn = $('#nm-exam-prev-btn');
    const nextBtn = $('#nm-exam-next-btn');
    const submitBtn = $('#nm-exam-submit-btn');
    const flagBtn = $('#nm-exam-flag-btn');
    const retryBtn = $('#nm-exam-retry-btn');

    // Display elements
    const timerDisplay = $('#nm-exam-timer-display');
    const currentQDisplay = $('#nm-exam-current-q');
    const totalQDisplay = $('#nm-exam-total-q');
    const questionContainer = $('#nm-exam-question-container');

    /**
     * Initialize and start the exam
     */
    startBtn.on('click', function () {
        startScreen.removeClass('active');
        questionScreen.addClass('active');
        examStartTime = Date.now();
        startTimer();
        displayQuestion();
    });

    /**
     * Start countdown timer
     */
    function startTimer() {
        timerInterval = setInterval(function () {
            timeElapsed++;
            updateTimerDisplay();

            // Auto-submit when time runs out
            if (timeElapsed >= timeLimit) {
                clearInterval(timerInterval);
                submitExam(true); // Auto-submit
            }
        }, 1000);
    }

    /**
     * Update timer display
     */
    function updateTimerDisplay() {
        const remaining = timeLimit - timeElapsed;
        const minutes = Math.floor(remaining / 60);
        const seconds = remaining % 60;
        const formatted = `${minutes}:${seconds.toString().padStart(2, '0')}`;
        timerDisplay.text(formatted);

        // Change color when time is running low
        if (remaining <= 60) {
            timerDisplay.css('color', '#dc2626'); // Red
        } else if (remaining <= 300) {
            timerDisplay.css('color', '#f59e0b'); // Orange
        }
    }

    /**
     * Display current question
     */
    function displayQuestion() {
        const question = questionsData[currentQuestionIndex];
        const isFlagged = flaggedQuestions.has(currentQuestionIndex);

        let optionsHTML = '';
        if (question.options && typeof question.options === 'object') {
            Object.keys(question.options).forEach(function (key) {
                const isSelected = userAnswers[currentQuestionIndex] === key;
                const selectedClass = isSelected ? 'selected' : '';

                optionsHTML += `
                    <li class="nm-exam-option ${selectedClass}" data-option="${key}">
                        <span class="nm-exam-option-label">${key}</span>
                        <span class="nm-exam-option-text">${question.options[key]}</span>
                    </li>
                `;
            });
        }

        const questionHTML = `
            <div class="nm-exam-question">
                <div class="nm-exam-question-number">Question ${currentQuestionIndex + 1} of ${questionsData.length}</div>
                <h3 class="nm-exam-question-text">${question.question}</h3>
                <ul class="nm-exam-options">
                    ${optionsHTML}
                </ul>
            </div>
        `;

        questionContainer.html(questionHTML);

        // Update progress
        currentQDisplay.text(currentQuestionIndex + 1);
        totalQDisplay.text(questionsData.length);

        // Update navigation buttons
        prevBtn.prop('disabled', currentQuestionIndex === 0);

        // Show submit button on last question
        if (currentQuestionIndex === questionsData.length - 1) {
            nextBtn.hide();
            submitBtn.show();
        } else {
            nextBtn.show();
            submitBtn.hide();
        }

        // Update flag button
        flagBtn.toggleClass('flagged', isFlagged);
    }

    /**
     * Handle option selection
     */
    questionContainer.on('click', '.nm-exam-option', function () {
        const selectedOption = $(this).data('option');

        // Remove selection from all options
        $('.nm-exam-option').removeClass('selected');

        // Add selection to clicked option
        $(this).addClass('selected');

        // Store answer
        userAnswers[currentQuestionIndex] = selectedOption;
    });

    /**
     * Previous question
     */
    prevBtn.on('click', function () {
        if (currentQuestionIndex > 0) {
            currentQuestionIndex--;
            displayQuestion();
        }
    });

    /**
     * Next question
     */
    nextBtn.on('click', function () {
        if (currentQuestionIndex < questionsData.length - 1) {
            currentQuestionIndex++;
            displayQuestion();
        }
    });

    /**
     * Flag/unflag question
     */
    flagBtn.on('click', function () {
        if (flaggedQuestions.has(currentQuestionIndex)) {
            flaggedQuestions.delete(currentQuestionIndex);
            $(this).removeClass('flagged');
        } else {
            flaggedQuestions.add(currentQuestionIndex);
            $(this).addClass('flagged');
        }
    });

    /**
     * Submit exam
     */
    submitBtn.on('click', function () {
        const unanswered = questionsData.length - Object.keys(userAnswers).length;

        if (unanswered > 0) {
            const confirmMsg = `You have ${unanswered} unanswered question(s). Submit anyway?`;
            if (!confirm(confirmMsg)) {
                return;
            }
        }

        submitExam(false);
    });

    /**
     * Submit exam and calculate results
     */
    function submitExam(autoSubmit) {
        clearInterval(timerInterval);

        // Calculate score
        let correctCount = 0;
        const detailedAnswers = [];

        questionsData.forEach(function (question, index) {
            const userAnswer = userAnswers[index];
            const isCorrect = userAnswer === question.answer;

            if (isCorrect) {
                correctCount++;
            }

            detailedAnswers.push({
                questionId: question.id,
                question: question.question,
                userAnswer: userAnswer || null,
                correctAnswer: question.answer,
                isCorrect: isCorrect,
                explanation: question.explanation || ''
            });
        });

        const totalQuestions = questionsData.length;
        const percentage = Math.round((correctCount / totalQuestions) * 100);
        const passed = percentage >= passingScore;

        // Save result to database (if logged in)
        if (nmExamData.isLoggedIn) {
            saveResult({
                exam_type: 'mock_exam',
                topics: topicSlug,
                total: totalQuestions,
                correct: correctCount,
                percentage: percentage,
                time_taken: timeElapsed,
                answers: detailedAnswers
            });
        }

        // Display results
        displayResults({
            total: totalQuestions,
            correct: correctCount,
            incorrect: totalQuestions - correctCount,
            percentage: percentage,
            passed: passed,
            timeTaken: formatTime(timeElapsed),
            answers: detailedAnswers,
            autoSubmitted: autoSubmit
        });
    }

    /**
     * Save result to database via AJAX
     */
    function saveResult(data) {
        $.ajax({
            url: nmExamData.ajaxurl,
            type: 'POST',
            data: {
                action: 'nm_save_exam_result',
                nonce: nmExamData.nonce,
                ...data
            },
            success: function (response) {
                if (response.success) {
                    console.log('Exam result saved:', response.data);
                }
            },
            error: function (xhr, status, error) {
                console.error('Failed to save result:', error);
            }
        });
    }

    /**
     * Display results screen
     */
    function displayResults(results) {
        questionScreen.removeClass('active');
        resultsScreen.addClass('active');

        // Display score
        $('#nm-exam-score-display .nm-score-percentage').text(results.percentage + '%');

        // Display pass/fail status
        const statusHTML = results.passed
            ? '<span class="nm-pass-status pass">✓ PASSED</span>'
            : '<span class="nm-pass-status fail">✗ FAILED</span>';
        $('#nm-exam-pass-status').html(statusHTML);

        // Display stats
        $('#nm-stat-correct').text(results.correct);
        $('#nm-stat-incorrect').text(results.incorrect);
        $('#nm-stat-time').text(results.timeTaken);

        // Display answer review
        let reviewHTML = '<h3>Answer Review</h3>';
        results.answers.forEach(function (answer, index) {
            const statusClass = answer.isCorrect ? 'correct' : 'incorrect';
            const statusIcon = answer.isCorrect ? '✓' : '✗';

            reviewHTML += `
                <div class="nm-review-item ${statusClass}">
                    <div class="nm-review-question">
                        <span>${statusIcon}</span> ${index + 1}. ${answer.question}
                    </div>
                    <div class="nm-review-answer">
                        <strong>Your Answer:</strong> ${answer.userAnswer || 'Not answered'}
                    </div>
                    ${!answer.isCorrect ? `<div class="nm-review-answer"><strong>Correct Answer:</strong> ${answer.correctAnswer}</div>` : ''}
                    ${answer.explanation ? `<div class="nm-review-explanation"><strong>Explanation:</strong> ${answer.explanation}</div>` : ''}
                </div>
            `;
        });

        $('#nm-exam-review-container').html(reviewHTML);

        // Show auto-submit message if applicable
        if (results.autoSubmitted) {
            alert('Time is up! Your exam has been automatically submitted.');
        }
    }

    /**
     * Retry exam
     */
    retryBtn.on('click', function () {
        // Reset state
        currentQuestionIndex = 0;
        userAnswers = {};
        flaggedQuestions.clear();
        timeElapsed = 0;

        // Reset screens
        resultsScreen.removeClass('active');
        startScreen.addClass('active');

        // Reset timer display
        timerDisplay.css('color', '#dc2626');
    });

    /**
     * Share results
     */
    $('#nm-exam-share-btn').on('click', function () {
        const percentage = parseInt($('#nm-exam-score-display .nm-score-percentage').text());
        const shareText = `I scored ${percentage}% on the Mock Exam! Can you beat my score?`;
        const shareUrl = window.location.href;

        if (navigator.share) {
            navigator.share({
                title: 'My Exam Results',
                text: shareText,
                url: shareUrl
            }).catch(err => console.log('Share cancelled'));
        } else {
            // Fallback: Copy to clipboard
            const tempInput = document.createElement('input');
            tempInput.value = shareText + ' ' + shareUrl;
            document.body.appendChild(tempInput);
            tempInput.select();
            document.execCommand('copy');
            document.body.removeChild(tempInput);
            alert('Results copied to clipboard!');
        }
    });

    /**
     * Format time in MM:SS
     */
    function formatTime(seconds) {
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    }

    /**
     * Prevent accidental page refresh during exam
     */
    window.addEventListener('beforeunload', function (e) {
        if (questionScreen.hasClass('active')) {
            e.preventDefault();
            e.returnValue = '';
            return '';
        }
    });
});
