/**
 * MCQVS Schema Validator (lightweight)
 * For templates/config contract enforcement.
 *
 * @package MCQ_Video_Studio
 * @since 9.0.0
 */
(function (window) {
  "use strict";

  const MCQVS_SchemaValidate = {
    validate(schema, data, path = "") {
      const issues = [];
      const add = (msg) => issues.push({ path, message: msg });

      if (!schema || typeof schema !== "object") return { ok: true, issues };

      for (const [k, rule] of Object.entries(schema)) {
        const v = data ? data[k] : undefined;
        const p = path ? `${path}.${k}` : k;

        if (rule && rule.required && (v === undefined || v === null || v === "")) {
          issues.push({ path: p, message: "required" });
          continue;
        }
        if (v === undefined || v === null) continue;

        if (rule.type) {
          if (rule.type === "string" && typeof v !== "string") issues.push({ path: p, message: "must be string" });
          if (rule.type === "number" && typeof v !== "number") issues.push({ path: p, message: "must be number" });
          if (rule.type === "boolean" && typeof v !== "boolean") issues.push({ path: p, message: "must be boolean" });
          if (rule.type === "object" && (typeof v !== "object" || Array.isArray(v))) issues.push({ path: p, message: "must be object" });
          if (rule.type === "array" && !Array.isArray(v)) issues.push({ path: p, message: "must be array" });
        }
        if (rule.enum && !rule.enum.includes(v)) issues.push({ path: p, message: `must be one of: ${rule.enum.join(", ")}` });
      }

      return { ok: issues.length === 0, issues };
    },
  };

  window.MCQVS_SchemaValidate = MCQVS_SchemaValidate;
})(window);
