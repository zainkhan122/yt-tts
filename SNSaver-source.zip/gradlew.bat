@rem Gradle startup script
@echo off
set APP_HOME=%~dp0
java %JAVA_OPTS% -classpath "%APP_HOME%\gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
