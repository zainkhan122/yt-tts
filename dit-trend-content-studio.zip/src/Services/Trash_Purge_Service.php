<?php

/**
 * Trash Purge Service
 *
 * Permanently deletes ALL posts currently in WordPress Trash, optionally including media.
 *
 * Safety:
 * - Media deletion is guarded by usage checks unless force delete is enabled.
 * - When a media item is in Trash but referenced elsewhere, it will be restored and detached (safe-by-default).
 *
 * @package DIT_TrendStudio
 * @since 2.15.12
 * @MODIFIED 2026-02-25 - Added global empty-trash tool (batch-based).
 */

namespace DIT\TrendStudio\Services;

use DIT\TrendStudio\Infrastructure\Logger;

if (!defined('ABSPATH')) {
    exit;
}

class Trash_Purge_Service
{
    private Logger $logger;

    public function __construct(Logger $logger)
    {
        $this->logger = $logger;
    }

    /**
     * Purge all trash items in batches.
     *
     * @param int  $batch_size
     * @param bool $include_media If true, also delete trashed attachments and delete attachments associated with trashed posts.
     * @param bool $force_media If true, deletes media even when referenced elsewhere (DANGEROUS).
     * @return array
     */
    public function purge_all_trash_now(int $batch_size = 25, bool $include_media = true, bool $force_media = false): array
    {
        global $wpdb;

        $batch_size = max(5, min(50, (int) $batch_size));

        $deleted_posts = 0;
        $deleted_media = 0;
        $detached_media = 0;

        $this->logger->warning('Global Trash Purge: Starting batch', array(
            'batch_size' => $batch_size,
            'include_media' => $include_media,
            'force_media' => $force_media,
        ));

        // 1) Delete non-attachment trash posts first.
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT ID, post_type
             FROM {$wpdb->posts}
             WHERE post_status = 'trash'
               AND post_type <> 'attachment'
             ORDER BY ID ASC
             LIMIT %d",
            $batch_size
        ));

        if (!empty($rows)) {
            foreach ($rows as $row) {
                $post_id = (int) $row->ID;

                // Associated media cleanup (safe-by-default)
                if ($include_media) {
                    $attachment_ids = Media_Cleanup_Helper::get_candidate_attachment_ids_for_post($post_id);

                    foreach ($attachment_ids as $attachment_id) {
                        $attachment_id = (int) $attachment_id;
                        if ($attachment_id <= 0) {
                            continue;
                        }

                        if (!$force_media && Media_Cleanup_Helper::is_attachment_used_elsewhere($attachment_id, array($post_id)) > 0) {
                            // Keep attachment, but detach to avoid orphan parent pointers.
                            Media_Cleanup_Helper::detach_attachment($attachment_id);
                            $detached_media++;
                            continue;
                        }

                        if (wp_delete_attachment($attachment_id, true)) {
                            $deleted_media++;
                        }
                    }
                }

		add_filter('dit_ts_skip_before_delete_cleanup', '__return_true');
			if (wp_delete_post($post_id, true)) {
				$deleted_posts++;
			}
			remove_filter('dit_ts_skip_before_delete_cleanup', '__return_true');
            }
        } elseif ($include_media) {
            // 2) If no non-attachment trash remains, purge trashed attachments.
            $aids = $wpdb->get_col($wpdb->prepare(
                "SELECT ID
                 FROM {$wpdb->posts}
                 WHERE post_status = 'trash'
                   AND post_type = 'attachment'
                 ORDER BY ID ASC
                 LIMIT %d",
                $batch_size
            ));

            foreach ((array) $aids as $aid) {
                $aid = (int) $aid;

                if (!$force_media && Media_Cleanup_Helper::is_attachment_used_elsewhere($aid, array()) > 0) {
                    // Safe-by-default: restore referenced attachment instead of deleting.
                    Media_Cleanup_Helper::restore_attachment_from_trash($aid);
                    $detached_media++;
                    continue;
                }

                if (wp_delete_attachment($aid, true)) {
                    $deleted_media++;
                }
            }
        }

        // Remaining trash count
        if ($include_media) {
            $remaining = (int) $wpdb->get_var("SELECT COUNT(1) FROM {$wpdb->posts} WHERE post_status='trash'");
        } else {
            $remaining = (int) $wpdb->get_var("SELECT COUNT(1) FROM {$wpdb->posts} WHERE post_status='trash' AND post_type <> 'attachment'");
        }

        $done = ($remaining === 0);

        $this->logger->warning('Global Trash Purge: Batch complete', array(
            'deleted_posts' => $deleted_posts,
            'deleted_media' => $deleted_media,
            'detached_media' => $detached_media,
            'remaining' => $remaining,
            'done' => $done,
        ));

        return array(
            'deleted_posts' => $deleted_posts,
            'deleted_media' => $deleted_media,
            'detached_media' => $detached_media,
            'remaining' => $remaining,
            'done' => $done,
        );
    }
}
