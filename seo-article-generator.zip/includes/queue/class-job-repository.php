<?php

/**
 * Job Repository — DB access layer for queue jobs table
 *
 * @package SEO_Article_Generator
 */

namespace SEO_Article_Generator\Queue;

use SEO_Article_Generator\Utils\Plugin_Time;

// Prevent direct access
if (! defined('ABSPATH')) {
    exit;
}

/**
 * Handles all database operations for the queue table.
 * Uses row-level locking (FOR UPDATE) for atomic job reservation.
 */
class Job_Repository
{
    public const STATUS_QUEUED    = 'queued';
    public const STATUS_RESERVED  = 'reserved';
    public const STATUS_COMPLETED = 'completed';
    public const STATUS_FAILED    = 'failed';

    /**
     * @var \wpdb WordPress database instance.
     */
    private $db;

    /**
     * @var string Fully prefixed table name.
     */
    private $table;

    /**
     * @param \wpdb $db WordPress database instance.
     */
    public function __construct(\wpdb $db)
    {
        $this->db    = $db;
        $this->table = \SEO_Article_Generator\Installer::table_queue();
    }

    /**
     * Add a new job to the queue.
     *
     * @param string $type        Job type.
     * @param int    $reference_id Reference entity ID.
     * @param array  $payload     Optional extra data.
     * @return void
     */
    public function enqueue($type, $reference_id, $payload = array(), $available_at = null)
    {
        $now_utc      = Plugin_Time::utc_mysql_now();
        $available_at = $available_at ?: $now_utc;

        $ok = $this->db->insert(
            $this->table,
            array(
                'type'                 => $type,
                'reference_id'         => (int) $reference_id,
                'payload'              => wp_json_encode($payload),
                'status'               => self::STATUS_QUEUED,
                'reservation_token'    => null,
                'attempts'             => 0,
                'available_at'         => $available_at,
                'reserved_at'          => null,
                'processing_started_at'=> null,
                'heartbeat_at'         => null,
                'lease_expires_at'     => null,
                'completed_at'         => null,
                'created_at'           => $now_utc,
                'updated_at'           => $now_utc,
            )
        );

        if (1 !== (int) $ok) {
            throw new \RuntimeException('Failed to enqueue queue job: ' . $this->db->last_error);
        }

        return (int) $this->db->insert_id;
    }

    /**
     * Find an existing open (queued or reserved) job for a type+reference pair.
     *
     * @param string $type        Job type.
     * @param int    $reference_id Reference entity ID.
     * @return int Job ID if found, 0 otherwise.
     */
    public function find_open_job_id(string $type, int $reference_id = 0): int
    {
        return (int) $this->db->get_var(
            $this->db->prepare(
                "SELECT id
                 FROM {$this->table}
                 WHERE type = %s
                   AND reference_id = %d
                   AND status IN (%s, %s)
                 ORDER BY id ASC
                 LIMIT 1",
                $type,
                $reference_id,
                self::STATUS_QUEUED,
                self::STATUS_RESERVED
            )
        );
    }

    /**
     * Enqueue a job only if no open job of the same type+reference exists (idempotent).
     *
     * @param string     $type        Job type.
     * @param int        $reference_id Reference entity ID.
     * @param array      $payload     Optional extra data.
     * @param string     $available_at Optional availability datetime.
     * @return int Existing or newly created job ID.
     */
    public function enqueue_unique($type, int $reference_id, $payload = array(), $available_at = null): int
    {
        $lock_name = $this->get_enqueue_lock_name((string) $type, $reference_id);
        $locked = (int) $this->db->get_var(
            $this->db->prepare("SELECT GET_LOCK(%s, 5)", $lock_name)
        );

        if ($locked !== 1) {
            throw new \RuntimeException('Failed to acquire queue dedupe lock for ' . $type . ':' . $reference_id);
        }

        try {
            $existing_id = $this->find_open_job_id((string) $type, $reference_id);
            if ($existing_id > 0) {
                return $existing_id;
            }

            return $this->enqueue($type, $reference_id, $payload, $available_at);
        } finally {
            $this->db->get_var(
                $this->db->prepare("SELECT RELEASE_LOCK(%s)", $lock_name)
            );
        }
    }

    /**
     * Generate a unique lock name for idempotent enqueueing.
     *
     * @param string $type Job type.
     * @param int    $reference_id Reference entity ID.
     * @return string Lock name.
     */
    private function get_enqueue_lock_name(string $type, int $reference_id): string
    {
        return 'seo_gen_queue_' . md5($type . ':' . $reference_id);
    }

    /**
     * Atomically reserve the next available job.
     *
     * @return object|null Job row or null if queue is empty.
     */
    public function reserve($lease_seconds = 3600, array $allowed_types = array())
    {
        $now_utc      = Plugin_Time::utc_mysql_now();
        $lease_until  = Plugin_Time::utc_mysql_from_utc_ts(Plugin_Time::now_utc_ts() + (int) $lease_seconds);
        $token        = \wp_generate_uuid4();

        $this->db->query('START TRANSACTION');

        try {
            $sql = "SELECT id, type, reference_id, payload, status, attempts, available_at FROM {$this->table}
                     WHERE status = %s
                       AND available_at <= %s";
            $params = array(self::STATUS_QUEUED, $now_utc);

            if (! empty($allowed_types)) {
                $placeholders = implode(',', array_fill(0, count($allowed_types), '%s'));
                $sql .= " AND type IN ({$placeholders})";
                $params = array_merge($params, array_values($allowed_types));
            }

            $sql .= " ORDER BY available_at ASC, id ASC LIMIT 1 FOR UPDATE";

            $job = $this->db->get_row(
                $this->db->prepare($sql, $params)
            );

            if (! $job) {
                $this->db->query('COMMIT');
                return null;
            }

            $updated = $this->db->update(
                $this->table,
                array(
                    'status'                => self::STATUS_RESERVED,
                    'reservation_token'     => $token,
                    'reserved_at'           => $now_utc,
                    'processing_started_at' => $now_utc,
                    'heartbeat_at'          => $now_utc,
                    'lease_expires_at'      => $lease_until,
                    'updated_at'            => $now_utc,
                ),
                array(
                    'id'     => (int) $job->id,
                    'status' => self::STATUS_QUEUED,
                ),
                array('%s', '%s', '%s', '%s', '%s', '%s', '%s'),
                array('%d', '%s')
            );

            if (1 !== (int) $updated) {
                $this->db->query('ROLLBACK');
                return null;
            }

            $job->status                = self::STATUS_RESERVED;
            $job->reservation_token     = $token;
            $job->reserved_at           = $now_utc;
            $job->processing_started_at = $now_utc;
            $job->heartbeat_at          = $now_utc;
            $job->lease_expires_at      = $lease_until;

            $this->db->query('COMMIT');

            return $job;
        } catch (\Throwable $e) {
            $this->db->query('ROLLBACK');
            throw $e;
        }
    }

    public function heartbeat($id, $reservation_token, $lease_seconds = 3600)
    {
        return 1 === (int) $this->db->update(
            $this->table,
            array(
                'heartbeat_at'      => Plugin_Time::utc_mysql_now(),
                'lease_expires_at'  => Plugin_Time::utc_mysql_from_utc_ts(Plugin_Time::now_utc_ts() + (int) $lease_seconds),
                'updated_at'        => Plugin_Time::utc_mysql_now(),
            ),
            array(
                'id'                => (int) $id,
                'status'            => self::STATUS_RESERVED,
                'reservation_token' => (string) $reservation_token,
            ),
            array('%s', '%s', '%s'),
            array('%d', '%s', '%s')
        );
    }

    public function get_state(int $id): array
    {
        $row = $this->db->get_row(
            $this->db->prepare(
                "SELECT id, status, reservation_token, heartbeat_at, lease_expires_at
                 FROM {$this->table}
                 WHERE id = %d
                 LIMIT 1",
                $id
            ),
            ARRAY_A
        );

        return is_array($row) ? $row : array();
    }

    /**
     * Mark a job as terminally completed.
     *
     * @param int    $id                Queue ID.
     * @param string $reservation_token Ownership token.
     * @return bool
     */
    public function mark_terminal_completed($id, $reservation_token)
    {
        return $this->mark_completed($id, $reservation_token);
    }

    /**
     * Mark a job as terminally failed (no more retries).
     *
     * @param int    $id                Queue ID.
     * @param string $reservation_token Ownership token.
     * @param string $error             Optional error message to store in payload.
     * @return bool
     */
    public function mark_terminal_failed($id, $reservation_token, $error = null)
    {
        $data = array(
            'status'             => self::STATUS_FAILED,
            'attempts'           => 99, // Force terminal state
            'completed_at'       => Plugin_Time::utc_mysql_now(),
            'heartbeat_at'       => null,
            'lease_expires_at'   => null,
            'reservation_token'  => null,
            'updated_at'         => Plugin_Time::utc_mysql_now(),
        );

        if ($error) {
            $data['payload'] = $this->add_error_to_payload($id, $error);
        }

        return 1 === (int) $this->db->update(
            $this->table,
            $data,
            array(
                'id'                => (int) $id,
                'status'            => self::STATUS_RESERVED,
                'reservation_token' => (string) $reservation_token,
            )
        );
    }

    /**
     * Quietly retire a queue ticket that was superseded BEFORE any AI work ran.
     *
     * Phase 3F (2.34.0): the worker claims a backlog ticket only to discover the
     * underlying generation job is a duplicate of a newer job for the same post
     * (or its discovery owns a different/live job). Such tickets must be retired
     * without burning an AI call and without a backoff requeue. Unlike the
     * CAS-completion methods above (which require STATUS_RESERVED + token), a
     * superseded ticket can be encountered in either QUEUED (re-released stale
     * claim) or RESERVED (current claim) state, so both are accepted.
     *
     * @param int    $id      Queue ticket ID.
     * @param string $token   Reservation token (may be empty when not yet reserved).
     * @param string $reason  Short supersede reason recorded in payload.
     * @return bool
     */
    public function mark_superseded($id, $token = '', $reason = 'superseded')
    {
        $id = (int) $id;
        if ($id <= 0) {
            return false;
        }

        $data = array(
            'status'             => self::STATUS_COMPLETED,
            'attempts'           => 99, // terminal: never re-released by reserve()
            'completed_at'       => Plugin_Time::utc_mysql_now(),
            'heartbeat_at'       => null,
            'lease_expires_at'   => null,
            'reservation_token'  => null,
            'reserved_at'        => null,
            'processing_started_at' => null,
            'updated_at'         => Plugin_Time::utc_mysql_now(),
        );

        $where = array(
            'id'     => $id,
            'status' => self::STATUS_RESERVED,
        );
        if ((string) $token !== '') {
            $where['reservation_token'] = (string) $token;
        }

        $affected = (int) $this->db->update($this->table, $data, $where);

        // Fall through for a ticket that was still QUEUED (stale re-release path).
        if (1 !== $affected) {
            $affected = (int) $this->db->update(
                $this->table,
                $data,
                array(
                    'id'     => $id,
                    'status' => self::STATUS_QUEUED,
                )
            );
        }

        if (1 === $affected && (string) $reason !== '') {
            $this->add_error_to_payload($id, 'superseded: ' . (string) $reason);
        }

        return 1 === $affected;
    }

    /**
     * Requeue a job due to a deferral (e.g. rate limit), resetting attempts or using a custom delay.
     *
     * @param int    $id                Queue ID.
     * @param string $reservation_token Ownership token.
     * @param int    $delay_seconds     Delay before it's available again.
     * @return bool
     */
    public function requeue_deferred($id, $reservation_token, $delay_seconds = 300)
    {
        return 1 === (int) $this->db->update(
            $this->table,
            array(
                'status'                => self::STATUS_QUEUED,
                'available_at'          => Plugin_Time::utc_mysql_from_utc_ts(Plugin_Time::now_utc_ts() + $delay_seconds),
                'reserved_at'           => null,
                'processing_started_at' => null,
                'heartbeat_at'          => null,
                'lease_expires_at'      => null,
                'reservation_token'     => null,
                'updated_at'            => Plugin_Time::utc_mysql_now(),
            ),
            array(
                'id'                => (int) $id,
                'status'            => self::STATUS_RESERVED,
                'reservation_token' => (string) $reservation_token,
            )
        );
    }

    /**
     * Mark a job as completed.
     *
     * @param int    $id                Queue ID.
     * @param string $reservation_token Ownership token.
     * @return bool
     */
    public function mark_completed($id, $reservation_token)
    {
        return 1 === (int) $this->db->update(
            $this->table,
            array(
                'status'             => self::STATUS_COMPLETED,
                'completed_at'       => Plugin_Time::utc_mysql_now(),
                'heartbeat_at'       => null,
                'lease_expires_at'   => null,
                'reservation_token'  => null,
                'updated_at'         => Plugin_Time::utc_mysql_now(),
            ),
            array(
                'id'                => (int) $id,
                'status'            => self::STATUS_RESERVED,
                'reservation_token' => (string) $reservation_token,
            ),
            array('%s', '%s', '%s', '%s', '%s', '%s'),
            array('%d', '%s', '%s')
        );
    }

    /**
     * Mark a job as failed or re-queue with backoff.
     *
     * @param int    $id                Queue ID.
     * @param int    $attempts          Current attempt count.
     * @param string $reservation_token Ownership token.
     * @return bool
     */
    public function mark_failed($id, $attempts, $reservation_token)
    {
        $attempts = (int) $attempts;

        if ($attempts >= \SEO_Article_Generator\Jobs\Job_Handler::MAX_JOB_RETRIES) {
            return $this->mark_terminal_failed($id, $reservation_token);
        }

        $delay = Backoff_Strategy::delay_for_attempt($attempts);

        return 1 === (int) $this->db->update(
            $this->table,
            array(
                'status'                => self::STATUS_QUEUED,
                'attempts'              => $attempts,
                'available_at'          => Plugin_Time::utc_mysql_from_utc_ts(Plugin_Time::now_utc_ts() + $delay),
                'reserved_at'           => null,
                'processing_started_at' => null,
                'heartbeat_at'          => null,
                'lease_expires_at'      => null,
                'reservation_token'     => null,
                'updated_at'            => Plugin_Time::utc_mysql_now(),
            ),
            array(
                'id'                => (int) $id,
                'status'            => self::STATUS_RESERVED,
                'reservation_token' => (string) $reservation_token,
            )
        );
    }

    /**
     * Helper to append error to payload.
     */
    private function add_error_to_payload($id, $error)
    {
        $row = $this->db->get_row($this->db->prepare("SELECT payload FROM {$this->table} WHERE id = %d", (int) $id));
        $payload = $row ? json_decode($row->payload, true) : array();
        $payload['last_error'] = (string) $error;
        return wp_json_encode($payload);
    }

    /**
     * Recover stale reservations (crash recovery).
     *
     * @param int $minutes Threshold in minutes.
     * @return void
     */
    public function cleanup_stale_reservations()
    {
        $now_utc = Plugin_Time::utc_mysql_now();

        return (int) $this->db->query(
            $this->db->prepare(
                "UPDATE {$this->table}
                 SET status = %s,
                     reserved_at = NULL,
                     processing_started_at = NULL,
                     heartbeat_at = NULL,
                     lease_expires_at = NULL,
                     reservation_token = NULL,
                     updated_at = %s
                 WHERE status = %s
                   AND lease_expires_at IS NOT NULL
                   AND lease_expires_at < %s",
                self::STATUS_QUEUED,
                $now_utc,
                self::STATUS_RESERVED,
                $now_utc
            )
        );
    }

    /**
     * Purge old completed/failed jobs.
     *
     * @param int $days Age threshold in days.
     * @return int Number of rows deleted.
     */
    public function purge_old_jobs($days = 30)
    {
        $cutoff = Plugin_Time::utc_mysql_from_utc_ts(Plugin_Time::now_utc_ts() - ((int) $days * DAY_IN_SECONDS));

        return (int) $this->db->query(
            $this->db->prepare(
                "DELETE FROM {$this->table}
                 WHERE status IN (%s, %s)
                   AND completed_at IS NOT NULL
                   AND completed_at < %s",
                self::STATUS_COMPLETED,
                self::STATUS_FAILED,
                $cutoff
            )
        );
    }

    /**
     * Reset stale queued jobs whose available_at is far in the past.
     *
     * When a job is deferred (backoff), its available_at is set to a future
     * timestamp. If the runner never fires it, the job stays stuck with a
     * stale available_at that may be in the past but still not picked up.
     * This method resets such jobs so the next worker tick can process them.
     *
     * @param int $stale_seconds Jobs with available_at older than this are reset.
     * @return int Number of rows reset.
     */
    public function cleanup_stale_queued_jobs(int $stale_seconds = 3600): int
    {
        $now_utc  = Plugin_Time::utc_mysql_now();
        $cutoff   = Plugin_Time::utc_mysql_from_utc_ts(
            Plugin_Time::now_utc_ts() - $stale_seconds
        );

        return (int) $this->db->query(
            $this->db->prepare(
                "UPDATE {$this->table}
                 SET available_at = %s,
                     updated_at = %s
                 WHERE status = %s
                   AND available_at IS NOT NULL
                   AND available_at <= %s",
                $now_utc,
                $now_utc,
                self::STATUS_QUEUED,
                $cutoff
            )
        );
    }
}
