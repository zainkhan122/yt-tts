<?php

/**
 * Style Auditor
 *
 * Scans for generic phrases and analyzes editorial breathability.
 *
 * @package DIT_TrendStudio\Security
 * @since   1.3.0
 */

namespace DIT\TrendStudio\Security;

use DIT\TrendStudio\Schema\Content_Schema;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Analyzes the "Editorial Style" of the article.
 */
class Style_Auditor
{
    /**
     * Generic/Robotic phrases to avoid in elite content.
     * @MODIFIED 2025-12-27 - Added meta-narration and AI artifact phrases
     * @MODIFIED 2026-01-12 - Expanded with additional AI-telltale phrases
     */
    private const ROBOTIC_PHRASES = [
        'taking the world by storm',
        'a testament to',
        'at the end of the day',
        'only time will tell',
        'delve into',
        'embark on a journey',
        'game changer',
        'world-class',
        'elevate your style',
        'unlock the secrets',
        // Meta-narration (self-referential AI artifacts)
        'the verified research confirms',
        'the research confirms',
        'our research shows',
        'according to our analysis',
        'it is worth noting that',
        'it should be noted that',
        'in the ever-evolving landscape',
        'as one expert noted',
        'as one commentator noted',
        'as commentators have noted',
        'experts agree that',
        'industry insiders suggest',
        // @MODIFIED 2026-01-12 - Additional AI-telltale phrases
        'navigating the',
        'landscape of',
        'poised to',
        'underscores the importance',
        'crucial to note',
        'represents a significant',
        'plays a pivotal role',
        'it\'s important to remember',
    ];

    /**
     * Audit style and breathability.
     *
     * @param Content_Schema $schema
     * @param array          $config
     * @return array
     */
    public function audit(Content_Schema $schema, array $config): array
    {
        $issues = [];
        $pts_lost = 0;

        $body_html = '';
        foreach ($schema->sections as $section) {
            $body_html .= ' ' . $section['body_html'];
        }
        $full_text = wp_strip_all_tags($body_html);

        // 1. Robotic Phrase Detection
        $robotic_count = 0;
        foreach (self::ROBOTIC_PHRASES as $phrase) {
            if (stripos($full_text, $phrase) !== false) {
                $robotic_count++;
            }
        }

        if ($robotic_count > 0) {
            $penalty = $robotic_count * 2;
            $issues[] = sprintf('Detected %d generic/robotic phrases (suggests low editorial quality).', $robotic_count);
            $pts_lost += $penalty;
        }

        // 2. Superlative Language (Elite Check)
        $superlatives = ['everywhere', 'always', 'never', 'dominant', 'definitive', 'most popular', 'completely'];
        $found_superlatives = [];
        foreach ($superlatives as $word) {
            if (preg_match('/\b' . preg_quote($word, '/') . '\b/i', $full_text)) {
                $found_superlatives[] = $word;
            }
        }
        if (!empty($found_superlatives)) {
            $issues[] = 'Contains overly absolute language: ' . implode(', ', array_slice($found_superlatives, 0, 3));
            $pts_lost += 3;
        }

        // 3. Unattributed Quote Detection
        if (preg_match_all('/"([^"]{15,})"/', $body_html, $quotes)) {
            $unattributed = 0;
            foreach ($quotes[1] as $quote) {
                $signal = '/(said|according to|noted|wrote|stated|recommends|advises)/i';
                if (!preg_match($signal, $body_html)) {
                    $unattributed++;
                }
            }
            if ($unattributed > 0) {
                $issues[] = sprintf('Detected %d potential unattributed quote(s).', $unattributed);
                $pts_lost += ($unattributed * 5);
            }
        }

        // 4. Breathability (Sentence Length Variance)
        $sentences = preg_split('/[\.\!\?]+/', $full_text, -1, PREG_SPLIT_NO_EMPTY);
        $lengths = array_map(function ($s) {
            return str_word_count(trim($s));
        }, $sentences);
        $lengths = array_filter($lengths, fn($l) => $l > 2);

        if (count($lengths) > 5) {
            $avg = array_sum($lengths) / count($lengths);
            $variance = 0;
            foreach ($lengths as $l) {
                $variance += pow($l - $avg, 2);
            }
            $std_dev = sqrt($variance / count($lengths));
            $breathability_ratio = $std_dev / $avg;

            if ($breathability_ratio < $config['optimal_breathability']) {
                $issues[] = sprintf('Low breathability: content rhythm is too uniform (ratio: %.2f).', $breathability_ratio);
                $pts_lost += 5;
            }

            $long_count = count(array_filter($lengths, fn($l) => $l > $config['max_sentence_length']));
            if ($long_count > 0) {
                $issues[] = sprintf('Detected %d overly long sentences (>%d words).', $long_count, $config['max_sentence_length']);
                $pts_lost += ($long_count * 3);
            }
        }

        // @MODIFIED 2026-01-12 - Add sentence variance check
        $variance_result = $this->check_sentence_variance($schema);
        if (!empty($variance_result['issues'])) {
            $issues = array_merge($issues, $variance_result['issues']);
            $pts_lost += $variance_result['pts_lost'];
        }

        // @MODIFIED 2026-01-12 - Add paragraph start repetition check
        $repetition_result = $this->check_paragraph_start_repetition($schema);
        if (!empty($repetition_result['issues'])) {
            $issues = array_merge($issues, $repetition_result['issues']);
            $pts_lost += $repetition_result['pts_lost'];
        }

        return [
            'issues'   => $issues,
            'pts_lost' => $pts_lost,
        ];
    }

    /**
     * Check sentence length variance within paragraphs
     * @MODIFIED 2026-01-12 - NEW: Flags "Robotic Rhythm" when std_dev < 3.0
     *
     * @param Content_Schema $schema
     * @return array Issues and points lost
     */
    private function check_sentence_variance(Content_Schema $schema): array
    {
        $issues = [];
        $pts_lost = 0;
        $robotic_paragraphs = 0;

        foreach ($schema->sections as $section) {
            $body = wp_strip_all_tags($section['body_html'] ?? '');
            $paragraphs = preg_split('/\n\n+/', $body, -1, PREG_SPLIT_NO_EMPTY);

            foreach ($paragraphs as $para) {
                $sentences = preg_split('/[.!?]+/', $para, -1, PREG_SPLIT_NO_EMPTY);
                $lengths = array_map(fn($s) => str_word_count(trim($s)), $sentences);
                $lengths = array_filter($lengths, fn($l) => $l > 2);

                if (count($lengths) >= 3) {
                    $avg = array_sum($lengths) / count($lengths);
                    $variance = 0;
                    foreach ($lengths as $l) {
                        $variance += pow($l - $avg, 2);
                    }
                    $std_dev = sqrt($variance / count($lengths));

                    if ($std_dev < 3.0) {
                        $robotic_paragraphs++;
                    }
                }
            }
        }

        if ($robotic_paragraphs > 0) {
            $issues[] = sprintf('Robotic Rhythm: %d paragraph(s) have too uniform sentence lengths (std_dev < 3.0).', $robotic_paragraphs);
            $pts_lost += ($robotic_paragraphs * 2);
        }

        return ['issues' => $issues, 'pts_lost' => $pts_lost];
    }

    /**
     * Check for repeated paragraph starting words (transition word abuse)
     * @MODIFIED 2026-01-12 - NEW: Flags when multiple paragraphs start with same transition
     *
     * @param Content_Schema $schema
     * @return array Issues and points lost
     */
    private function check_paragraph_start_repetition(Content_Schema $schema): array
    {
        $issues = [];
        $pts_lost = 0;

        $transition_words = [
            'additionally',
            'moreover',
            'furthermore',
            'however',
            'therefore',
            'consequently',
            'meanwhile',
            'similarly',
            'in addition',
            'as a result',
            'on the other hand',
            'in conclusion',
            'to summarize',
            'notably',
        ];

        $paragraph_starts = [];

        foreach ($schema->sections as $section) {
            $body = wp_strip_all_tags($section['body_html'] ?? '');
            $paragraphs = preg_split('/\n\n+/', $body, -1, PREG_SPLIT_NO_EMPTY);

            foreach ($paragraphs as $para) {
                $para = trim($para);
                if (empty($para)) continue;

                // Get first few words
                $first_words = strtolower(substr($para, 0, 30));

                foreach ($transition_words as $transition) {
                    if (strpos($first_words, $transition) === 0) {
                        $paragraph_starts[$transition] = ($paragraph_starts[$transition] ?? 0) + 1;
                        break;
                    }
                }
            }
        }

        // Flag any transition used 2+ times
        $repeated = array_filter($paragraph_starts, fn($count) => $count >= 2);
        if (!empty($repeated)) {
            $examples = array_slice(array_keys($repeated), 0, 3);
            $issues[] = sprintf('Paragraph Start Repetition: Multiple paragraphs start with: %s', implode(', ', $examples));
            $pts_lost += (count($repeated) * 3);
        }

        return ['issues' => $issues, 'pts_lost' => $pts_lost];
    }
}
