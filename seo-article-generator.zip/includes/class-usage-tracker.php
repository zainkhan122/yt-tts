<?php

namespace SEO_Article_Generator;

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Tracks API usage per provider
 * 
 * @MODIFIED 2026-03-02 - Initial implementation for Usage Tracker
 */
class Usage_Tracker
{
	/**
	 * Get provider-specific "day" key.
	 *
	 * Gemini RPD resets at midnight Pacific time; align usage counters to that day.
	 * Others default to UTC.
	 *
	 * @param string $provider
	 * @return string
	 */
	private static function get_provider_day_key($provider)
	{
		$provider = strtolower($provider);

		if ($provider === 'gemini') {
			try {
				$pt = new \DateTimeZone('America/Los_Angeles');
				return (new \DateTimeImmutable('now', $pt))->format('Y-m-d');
			} catch (\Throwable $e) {
				// fallthrough
			}
		}

		return \SEO_Article_Generator\Utils\Plugin_Time::site_date_str(\SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts());
	}

	/**
	 * Increment usage for a provider
	 *
	 * @param string $provider Gemini, Perplexity, etc.
	 * @return void
	 */
	public static function increment($provider)
	{
		$provider = strtolower($provider);
		$today    = self::get_provider_day_key($provider);

		// Increment Daily
		$daily_stats = \get_option('seo_gen_usage_daily', array());
		if (!\is_array($daily_stats)) {
			$daily_stats = array();
		}
		if (!isset($daily_stats[$today])) {
			$daily_stats[$today] = array();
		}
		if (!isset($daily_stats[$today][$provider])) {
			$daily_stats[$today][$provider] = 0;
		}
		$daily_stats[$today][$provider]++;
		\update_option('seo_gen_usage_daily', $daily_stats);

		// Increment Total
		$total_stats = \get_option('seo_gen_usage_total', array());
		if (!isset($total_stats[$provider])) {
			$total_stats[$provider] = 0;
		}
		$total_stats[$provider]++;
		\update_option('seo_gen_usage_total', $total_stats);
	}

	/**
	 * Get usage stats for a provider
	 *
	 * @param string $provider
	 * @return array array('today' => X, 'total' => Y)
	 */
	public static function get_stats($provider)
	{
		$provider = strtolower($provider);
		$today    = self::get_provider_day_key($provider);

		$daily_stats = \get_option('seo_gen_usage_daily', array());
		$total_stats = \get_option('seo_gen_usage_total', array());

		return array(
			'today' => $daily_stats[$today][$provider] ?? 0,
			'total' => $total_stats[$provider] ?? 0
		);
	}

	/**
	 * Get all stats
	 *
	 * @return array
	 */
	public static function get_all_stats()
	{
		$daily = \get_option('seo_gen_usage_daily', array());
		$total = \get_option('seo_gen_usage_total', array());

		$providers = array_unique(array_merge(
			array_keys($total),
			// Also include providers seen today
			array_reduce($daily, function ($carry, $item) {
				return array_merge($carry, array_keys($item));
			}, array())
		));

		$registry = \SEO_Article_Generator\AI\Provider_Registry::get_instance();
		$stats = array();
		foreach ($providers as $p) {
			$today = self::get_provider_day_key($p);
			$label = ucfirst($p);
			if ($registry->is_custom($p)) {
				$profile = $registry->get_custom_profile($p);
				$label = $profile['name'] ?? $label;
			}
			$stats[$p] = array(
				'label' => $label,
				'today' => $daily[$today][$p] ?? 0,
				'total' => $total[$p] ?? 0
			);
		}

		return $stats;
	}

	/**
	 * Get total API calls today across all providers.
	 * 
	 * @return int
	 */
	public static function get_today_total_score(): int
	{
		$stats = self::get_all_stats();
		$total = 0;
		foreach ($stats as $s) {
			$total += $s['today'];
		}
		return $total;
	}
}
