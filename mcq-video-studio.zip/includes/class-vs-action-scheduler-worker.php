<?php

/**
 * Action Scheduler Worker
 *
 * Handles background generation tasks to prevent timeouts.
 *
 * @package MCQ_Video_Studio
 */

if (! defined('ABSPATH')) {
    exit;
}

class VS_Action_Scheduler_Worker
{

    public static function init()
    {
        // Register the action hook
        add_action('vs_generate_mcq_batch', array(__CLASS__, 'process_batch'), 10, 3);
    }

    /**
     * Process a generation batch.
     *
     * @param int $topic_id The ID from `wp_vs_topics`
     * @param int $count Number of MCQs to generate
     * @param int $batch_id Unique ID for this generation run (for tracking)
     */
    public static function process_batch($topic_id, $count, $batch_id)
    {
        // 1. Dependency Check
        if (! class_exists('VS_MCQ_Repository') || ! class_exists('VS_Validation_Service')) {
            error_log('VS Worker: Missing dependencies.');
            return;
        }

        $repo = new VS_MCQ_Repository();
        $topic = $repo->get_topic($topic_id);

        if (! $topic) {
            error_log("VS Worker: Topic ID $topic_id not found.");
            return;
        }

        error_log("VS Worker: Starting batch $batch_id for topic '{$topic['name']}' ($count items).");

        // 2. AI Generation Loop
        // Check for VS_API_Client
        if (! class_exists('VS_API_Client')) {
            error_log('VS Worker: API Client not found.');
            return;
        }

        try {
            // Real API Integration via Wrapper (with model rotation)
            $api = VS_API_Client::init(); // Ensure instance
            $context = 'as_worker_' . $batch_id;
            $generated_questions = $api->generate_mcq_batch_with_context($topic['name'], $count, $context);

            if (is_wp_error($generated_questions)) {
                error_log('VS Worker API Error: ' . $generated_questions->get_error_message());
                // We don't throw immediately if we want to log more context, 
                // but creating an exception forces Action Scheduler to retry.
                throw new Exception($generated_questions->get_error_message());
            }

            error_log('VS Worker: Generated ' . count($generated_questions) . ' items. Saving...');

            // 3. Validation and Save
            $saved_count = 0;
            $saved_questions = array();
            foreach ($generated_questions as $item) {
                // Normalize data structure
                $item['topic_id'] = $topic_id;

                // Map AI/quiz handler keys to DB keys
                if (isset($item['question']) && ! isset($item['question_text'])) {
                    $item['question_text'] = $item['question'];
                }
                if (isset($item['correct']) && ! isset($item['correct_index'])) {
                    $item['correct_index'] = $item['correct'];
                }
                if (isset($item['answer']) && ! isset($item['correct_index'])) {
                    $map = array('A' => 0, 'B' => 1, 'C' => 2, 'D' => 3);
                    $item['correct_index'] = $map[strtoupper($item['answer'])] ?? 0;
                }

                // Validate
                $valid = VS_Validation_Service::validate_mcq_structure($item);
                if (is_wp_error($valid)) {
                    error_log("VS Worker: Skipped Invalid Item - " . $valid->get_error_message());
                    continue;
                }

                // Copy tags if present
                if (!empty($item['exam_tags'])) {
                    // Logic to store tags can be added here
                }

                $result = $repo->insert_mcq($item);
                if (! is_wp_error($result)) {
                    $saved_count++;
                    $saved_questions[] = array(
                        'id'         => 'topic_' . $topic_id . '_' . $saved_count,
                        'question'   => sanitize_text_field($item['question_text'] ?? $item['question'] ?? ''),
                        'options'    => is_string($item['options']) ? json_decode($item['options'], true) : $item['options'],
                        'correct'    => intval($item['correct_index'] ?? $item['correct'] ?? 0),
                        'background' => 'gradient',
                    );
                } else {
                    error_log("VS Worker: DB Error - " . $result->get_error_message());
                }
            }

            error_log("VS Worker: Batch Complete. Saved $saved_count / " . count($generated_questions));

            if ($saved_count > 0 && class_exists('VS_Job_Repository') && class_exists('VS_Job_Status')) {
                $job_repo = VS_Job_Repository::init();
                $job_repo->create_job(array(
                    'topic_id'       => $topic_id,
                    'question_count'  => $saved_count,
                    'status'         => VS_Job_Status::READY_FOR_RENDER,
                    'quiz_data'      => wp_json_encode($saved_questions),
                    'settings'       => wp_json_encode(array(
                        'topic_name' => $topic['name'] ?? $topic,
                        'template'   => get_option('mcqvs_default_template', 'trivia'),
                        'save_mode'  => get_option('mcqvs_delivery_mode', 'local'),
                    )),
                ));
                error_log("VS Worker: Created render job for topic {$topic_id} with {$saved_count} questions.");
            }
        } catch (Exception $e) {
            // Action Scheduler handles uncaught exceptions by failing the action.
            error_log('VS Worker Exception: ' . $e->getMessage());
            throw $e; // Rethrow to let AS know it failed
        }
    }
}
