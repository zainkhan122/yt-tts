/**
 * MCQVS Job Manager
 * Centralizes job lifecycle + cancellation to prevent "stuck export" states.
 *
 * @package MCQ_Video_Studio
 * @since 9.0.0
 */
(function (window) {
  "use strict";

  const STATES = Object.freeze({
    IDLE: "IDLE",
    PREFLIGHT: "PREFLIGHT",
    PREVIEWING: "PREVIEWING",
    RENDERING: "RENDERING",
    FINALIZING: "FINALIZING",
    DONE: "DONE",
    FAILED: "FAILED",
    CANCELLED: "CANCELLED",
  });

  function create() {
    let state = STATES.IDLE;
    let token = { cancelled: false };
    let startedAt = null;

    const setState = (s) => {
      state = s;
      return state;
    };

    return {
      STATES,
      getState() {
        return state;
      },
      getToken() {
        return token;
      },
      start(nextState) {
        token = { cancelled: false };
        startedAt = Date.now();
        setState(nextState || STATES.RENDERING);
        return token;
      },
      cancel() {
        token.cancelled = true;
        setState(STATES.CANCELLED);
      },
      fail() {
        setState(STATES.FAILED);
      },
      done() {
        setState(STATES.DONE);
      },
      reset() {
        token = { cancelled: false };
        startedAt = null;
        setState(STATES.IDLE);
      },
      ageMs() {
        return startedAt ? (Date.now() - startedAt) : 0;
      },
    };
  }

  window.MCQVS_JobManager = { create, STATES };
})(window);
