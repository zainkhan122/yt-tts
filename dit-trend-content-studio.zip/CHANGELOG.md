## 2.29.0 (2026-09-10)
- New: Link Whisper Premium integration. New `DIT\TrendStudio\Integrations\LinkWhisper\Link_Whisper_Bridge` class (`src/Integrations/LinkWhisper/Link_Whisper_Bridge.php`) auto-injects contextual internal links into generated posts using LW's full NLP pipeline (no editor UI required). The bridge parses flat Gutenberg block markup, allowlists linkable block types (`core/paragraph`, `core/list`, `core/quote`, `core/table`, `core/heading` H2/H3), skips editorial callouts (`dit-ts-callout` group), derives multi-word anchors via LW's own `Wpil_Suggestion::getSuggestionAnchorWords()`, inserts `<a>` tags only into the inner HTML of the matching block, and re-serializes via WP's `serialize_block()`. Idempotent via `_dit_ts_lw_processed` post meta; LW Reports visibility via `wpil_links` meta; never blocks publishing (try/catch at every boundary).
- New: `Scheduler::auto_publish_job()` calls the bridge immediately after `wp_insert_post()` (`src/Infrastructure/Scheduler.php:2599`) so the cushion before a scheduled `future` publish is used for link injection.
- New: `future_to_publish` observer registered in `Plugin::init()` (`src/Core/Plugin.php:217`) acts as an idempotent backstop for posts published via the publish watchdog or by an editor — guarded by the `_dit_ts_scheduled` marker meta and the bridge's own processed-flag.
- New: Settings UI under "Link Whisper Integration" with three options: `dit_ts_lw_integration_enabled` (master toggle, default off), `dit_ts_lw_max_links_per_post` (default 2, range 1–10), `dit_ts_lw_skip_callouts` (default on). Registered in `SettingsPage::register_settings()` (`src/Admin/SettingsPage.php`) and saved in `handle_settings_save()`.

## 2.28.3 (2026-08-30)
- Fix: 504 Gateway Timeout when deleting a single WordPress post. `Plugin::handle_generated_post_before_delete()` (`src/Core/Plugin.php:2783`) now (1) returns early for posts already in `trash` status (the trashed handler already ran), (2) fast-exits for non-plugin posts that have no `_dit_ts_media_managed=1` children, (3) trusts the prior usage validation stored in `_dit_ts_trash_managed_attachments` for generated posts instead of re-running the expensive `Media_Cleanup_Helper::is_attachment_used_elsewhere()` scan, and (4) caps the synchronous loop via a `dit_ts_before_delete_attachment_budget` filter (default 25) — any overflow is handed off to a new `dit_ts_continue_attachment_purge` Action Scheduler action processed in the background, so the originating HTTP delete request always finishes within the proxy timeout.
- New: `Plugin::handle_continue_attachment_purge()` and `dit_ts_continue_attachment_purge` hook — background companion that processes the attachment batch deferred by the budget guard. Has its own larger budget (default 100) and self-reschedules any remaining overflow 30s later. Group: `dit_ts_attachment_purge`.

## 2.28.2 (2026-08-14)
- Fix: Dashboard "Total Articles" card was stuck because it counted `dit_ts_jobs` rows with status `completed`, but `clean_old_jobs()` prunes completed rows after 3 days — making the "Lifetime" counter a rolling 3-day window. It now counts plugin-generated posts lifetime (`_dit_ts_scheduled='1'` auto-publish or `_dit_ts_job_id` manual publish meta), which are never pruned. Applied in `SettingsPage::render_dashboard_page()` and `Plugin::get_metrics()` (REST) for consistency.
- UX: "Total Articles" card sub-stat relabeled from "Size" to "Job History" since the MB figure is the size of the pruned jobs table, not the articles themselves.

## 2.28.1 (2026-08-01)
- Fix: Random Interval cap lifted from 24 to 1440 minutes in `SettingsPage.php` save handler so values entered in the UI (which already advertises `max="1440"`) persist on save. Previously any value above 24 minutes was silently clamped to 24, making it appear to revert after save.
- Fix: Random Interval save now also enforces `min ≤ max` by auto-swapping when the user enters a larger min than max, preventing an inverted random range from being persisted.

## 2.28.0 (2026-07-31)
- Fix: Buffer channels now persist across page refreshes. Added `get_cached_channels()` to read from `wp_options` cache without API calls; embedded cached channel data in account card data attributes; auto-rendered via JS on page load. Previously channels were stored only in jQuery memory and lost on refresh.
- Fix: Fixed version mismatch between plugin header (2.28.0) and `DIT_TS_VERSION` constant (2.27.0). Both now consistent at 2.28.0.

## 2.27.0 (2026-03-09)
- Ops: Comprehensive release cleanup for live deployment.
- Ops: Removed ~27MB of legacy zip archives and test scripts.
- Optimization: Pruned `assets/fonts` directory to retain only essential professional fonts (Urdu/English), reducing plugin footprint by ~70%.

## 2.15.35 (2026-03-08)
- New: Decoupled Social Queue from post publication status. Posts are no longer forced to 'Draft' when social assets are present; they respect their intended 'Publish' or 'Scheduled' status.
- New: Social Review Queue now displays post status; approving a social post/collage no longer forces a status transition to 'Publish', preserving the original post state.

## 2.15.31 (2026-03-06)
- Fix: Duplicate post generation prevented by stabilizing source idea locks during AI quota pauses and job failures.
- Fix: Source ideas now remain locked ('processing' or 'failed') instead of being released prematurely, preventing redundant job scheduling.

## 2.15.23 (2026-02-28)
- New: Collage Maker template "Split Top + Text Card" with canvas-based preview + export parity (WYSIWYG).
- New: Split Card typography controls (heading/body/brand line-height; LTR-only letter spacing; heading max lines with auto-wrap).
- New: Split Card brand controls (brand font override, size, spacing, logo picker).

## 2.15.19 (2026-02-26)
- Fix: Master AI Automation OFF now cancels all queued job runners; jobs no longer execute or get marked failed while the switch is OFF.
- Fix: If an already-queued job callback fires while Master Switch is OFF, it exits gracefully (no failure) and is resumable after re-enable.
- Ops: On re-enable, plugin drains orphaned pending jobs safely (one-at-a-time) without action-scheduler stampedes.

## 2.15.18 (2026-02-26)
- Fix: Gemini daily quota exhaustion now pauses until the next official RPD reset (midnight Pacific time), avoiding hourly retry loops.
- Fix: Gemini client now propagates machine-readable quota context (reason + pause_until), so jobs are rescheduled instead of marked failed.
- UX: API Usage page now shows provider status (ACTIVE/PAUSED), pause reason, next retry, and Gemini reset timing.
- Metrics: Gemini "Calls Made Today" now aligns to the Gemini quota day (PT), reducing day-boundary confusion.

## 2.15.17 (2026-02-25)
- Fix: transfer_exclusive local-image mode no longer falsely treats post revisions/autosaves as "used elsewhere" (enables rename + media transfer for truly unique drafts).
- Fix: Attachment usage detection now checks http/https URL variants to avoid unsafe false exclusivity.
- Ops: Scheduler now always logs media rename/cleanup completion, even when no job-managed media is eligible (improves debugging).

## 2.15.16 (2026-02-25)
- Fix: showbiz_pk/fashion_pk rewrites now honor the "Local Image Handling (Rewrite)" setting (no forced clone override).
- Fix: Attachment resolution from <img src> now handles mixed http/https URLs reliably (prevents wp:image id=0 and rename no-op).
- Fix: URL replacement map for renamed media now expands http/https variants so generated posts reflect renamed filenames.

## 2.15.15 (2026-02-25)
- Fix: Rewrite pipeline now localizes external images for ALL rewrite jobs (not persona-only), preventing hotlinking and 404s.
- New: Configurable local-image handling for rewrites: clone (safe), transfer-exclusive, or force-transfer.
- Fix: Draft cleanup now resolves attachments referenced only by <img src> URLs (unattached media), making media deletion reliable.
- UX: Cleanup logs now list ALL posts blocking attachment deletion (up to 5).
- Ops: Auto-publish now transfers job-managed media to the published post (post_parent + owner meta), reducing orphan garbage.

## 2.15.14 (2026-02-25)
- Fix: Media cleanup logic now correctly identifies the using post's ID instead of just a boolean, fixing a bug where trashed posts were falsely flagged as using media.
- UX: Draft cleanup logs now provide a direct edit link to any post that is preventing an attachment from being deleted.

## 2.15.13 (2026-02-25)
- Fix: Actually enabled DeepSeek strategies (`composite_deepseek`, `deepseek_only`) in the Campaign management UI dropdown.

## 2.15.12 (2026-02-25)
- New: DeepSeek provider integration (OpenAI-compatible) with JSON Output mode (deepseek-chat / deepseek-reasoner).
- New: New strategies: composite_deepseek (Perplexity research + DeepSeek writing) and deepseek_only (no grounding).
- UX: Settings now include DeepSeek API key/model + one-click connection test (uses existing Test API endpoint).
- UX: Campaign UI now supports DeepSeek strategy selection per campaign.
- New (DANGER): Global "Empty Trash Now" button with batch processing and guarded media deletion; FORCE delete media is OFF by default.
- Fix: Provider pause now applies to all providers (not Gemini-only) and schedules quota probes per-provider.
- Ops: Smoke test updated to validate DeepSeek + global trash purge classes/files.
- Metrics: Usage tracker now registers DeepSeek stats in API Usage page.

### [Fixed]
- Social Queue: Draft posts now correctly show and share "pretty" permalinks instead of plain IDs (`?p=ID`).
- Jetpack Integration: Social sharing messages now use pretty permalinks for draft and scheduled posts.

## 2.15.11 (2026-02-25)
- Fix: Replaced midnight-based Gemini quota pause logic with provider-aware exponential backoff (prevents “Day 2” quota loops).
- New: Added quota probe runner (Action Scheduler hook `dit_ts_quota_probe`) to automatically resume as soon as quota actually recovers.
- Fix: Added VPS-wide request mutex + last-request tracking via sys temp file to prevent multi-site bursts when sharing the same API key.

## 2.15.10 (2026-02-25)
- Fix: Draft cleanup now respects the "Delete Associated Media" setting for both scheduled cleanup and manual trash purge.
- Fix: Media deletion is safety-guarded: attachments are deleted only if not referenced elsewhere (otherwise skipped).
- New: Automation tab now includes "Purge Orphan Media Now" to remediate orphan attachments whose parent posts no longer exist; in-use attachments are detached instead of deleted.
- UX: Manual trash purge now reports deleted attachment counts.

## 2.15.9 (2026-02-25)
- Fix: Smoke Test DB schema check now correctly accepts legacy jobs column `error_message` (and also supports `error` if present).
- Fix: Smoke Test embed detection now recognizes WP core serializer output (`wp:embed`) as well as fallback (`wp:core/embed`).

## 2.15.8 (2026-02-25)
- New: Settings > Diagnostics tab with a comprehensive Smoke Test suite (no external API calls).
- New: Smoke_Test_Service validates required file presence, critical class autoloadability, jobs table schema, cron hooks, and runs a local pipeline dry-run (MediaSelector → Content_Schema → PostComposer → QualityGate).
- UX: Results render as a grouped table with Pass/Warn/Fail badges + Copy JSON.

## 2.15.7 (2026-02-24)
- Fix: Preloaded schema DTO files (Content_Schema, Content_Blocks) to avoid autoload edge cases during partial updates.

## 2.15.6 (2026-02-24)
- New: Automation tab now includes a manual "Purge Trashed Sources Now" button to permanently delete plugin-marked source drafts currently in Trash (ignores age threshold for testing).
- New: AJAX endpoint dit_ts_purge_trash_now with permission+nonce checks; returns deleted/remaining counts.
- Service: Draft_Cleanup_Service now supports manual purge helper with safety caps and remaining count.

## 2.15.5 (2026-02-24)
- UX: Jobs page "Regenerate" now performs reset+queue without page reload; row updates to queued state with live status polling.
- Fix: Job polling now uses a dynamic Set and preserves Preview/Regenerate actions on completion (no UI regression).
- Fix: Stuck-job "Run Manually" link now correctly targets jobs (not campaigns).
- Fix: Scheduler get_job_status now returns message + timestamps + post_id + error; batch polling now returns extended payload.
- Fix: update_job_status now stamps completed_at for terminal statuses (cancel + audit correctness).
- Refactor: Jobs table inline CSS moved to admin.css.

## 2.15.4 (2026-02-24)
- Fix: Removed duplicate AJAX handler for force-run/reset; reset now works reliably.
- Fix: Manual run now loads job input payload for strategy-aware quota gating.
- Fix: Legacy workflow now attaches _source_visual_map after article_data init (passthrough correctness).
- Fix: Plugin deactivation now clears WP-Cron fallbacks to prevent orphan schedules.
- UX: Preview now prefers rendered HTML (do_blocks) over raw block markup.
- Arch: Added PersonaRegistry + PersonaInterface; moved showbiz_pk/fashion_pk overrides into persona providers + new filter hooks.
- Refactor: Canonical SEO namespace via SEO\SchemaGenerator wrapper.

## 2.15.3 (2026-02-24)
- Security: Redact API keys and secrets from log files before writing to disk.
- Change: Count Gemini JSON repair and regeneration attempts as billable usage tracker increments.

## 2.15.2 (2026-02-24)
- New: Added "Download Full Log" button to the Error Logs page for easier log retrieval.


## 2.15.1 (2026-02-24)
- Fix: Safe Source Cleanup: Source drafts are now trashed immediately upon successful auto-publish.
- Fix: Daily cleanup refined to only purge trashed processed sources older than threshold, preserving all media assets.
- Fix: Processed sources are now reliably marked with `_dit_ts_cleanup_candidate` and timestamp.


## 2.15.0 (2026-02-24)
- Fix: Pak Showbiz persona rewrite could produce image 404s and mutate source drafts/ideas by renaming/deleting shared media.
- Change: Persona media localization is now non-destructive: job-owned copies are created (external sideload + local clone) and only those copies are renamed/capped/deleted.
- Fix: Scheduler deleted-URL scrubbing now runs even when no rename URL-map exists.



## [2.15.7] - 2026-02-24

### Fixed
- Preloaded Schema DTOs (Content_Schema, Content_Blocks) during bootstrap to prevent fatal "Class not found" errors on some installs where autoloading can fail due to filesystem/case or partial deployments.
