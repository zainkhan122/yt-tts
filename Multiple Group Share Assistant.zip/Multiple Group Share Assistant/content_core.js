// content_core.js - Core logic and helpers
(function() {
  'use strict';

  // Initialize Namespace
  window.ShareUnlimited = window.ShareUnlimited || {};
  window.ShareUnlimited.Core = {};
  window.ShareUnlimited.State = {
    shareProcessCancelled: false,
    isSharingInProgress: false,
    countdownSkipRequested: false,
    cachedShareButtonLocation: null,
    SHARE_DELAY_MS: 15000 // 15 seconds
  };

  const Core = window.ShareUnlimited.Core;
  const State = window.ShareUnlimited.State;
  // We will reference UI via window.ShareUnlimited.UI later

  // --- Ghost cursor bridge (content_ghost_cursor.js, v17.3) ------------------
  // The virtual pointer the user watches during an automated run. It is PURELY
  // cosmetic: it dispatches nothing at Facebook, and the real click always
  // follows on the next line. Every call goes through this wrapper so a missing
  // module (older build, load failure) or a rendering error can never break or
  // stall a share — `safe` swallows everything and resolves.
  const Ghost = (function () {
    async function safe(fn) {
      try {
        const g = window.ShareUnlimited && window.ShareUnlimited.Ghost;
        if (g) await fn(g);
      } catch (e) { /* cosmetic only — never surface to the share loop */ }
    }
    return {
      start:      ()           => safe(g => g.start()),
      finish:     (withFinale) => safe(g => g.stop({ finale: withFinale })),
      // move + ripple, then the caller fires the real click
      pointAndClick: (el)      => safe(g => g.clickElement(el)),
      point:      (el, ms)     => safe(g => g.moveToElement(el, ms)),
      press:      ()           => safe(g => g.press()),
      typeAt:     (el)         => safe(g => g.followCaret(el)),
      doneTyping: ()           => safe(g => g.stopFollow()),
      // Speech bubble. Callers name a stage; ALL the wording lives in LINES in
      // content_ghost_cursor.js, so copy changes never touch the share logic.
      say:        (key, data)  => safe(g => g.narrate(key, data))
    };
  })();

  // The watermark, defined once. It is always the TAIL of the composed post, which
  // is what lets the typing cue below locate it without searching the string.
  const WATERMARK_TEXT = '';

  // Keeps the "Remove Watermark" CTA pulsing for as long as the run is talking
  // about the watermark — from the ghost ANNOUNCING it to the moment it is typed
  // into the composer (v18.2). Same contract as Ghost: cosmetic, synchronous,
  // swallows everything, no-op when no banner is on screen. Never awaited.
  //
  // `stop` is deliberately forgiving and is called on every exit from that window,
  // including the failure paths — an unpaired start would leave the button pulsing
  // through the rest of the run.
  const WatermarkCta = {
    start() {
      try {
        const EO = window.ExpiredOverlay;
        if (EO && EO.startRemoveWatermarkFlash) EO.startRemoveWatermarkFlash();
      } catch (e) { /* cosmetic only */ }
    },
    stop() {
      try {
        const EO = window.ExpiredOverlay;
        if (EO && EO.stopRemoveWatermarkFlash) EO.stopRemoveWatermarkFlash();
      } catch (e) { /* cosmetic only */ }
    }
  };

  /**
   * Builds the optional typing cue that ENDS the watermark pulse, at the moment
   * the watermark's first character lands in the composer.
   *
   * Located by TAIL, not by `indexOf`: the user's own caption may legitimately
   * contain the same words, and a mid-string hit would stop the pulse early.
   * Returns null whenever there is nothing to cue, so the typer runs exactly as
   * before — the caller stops the pulse itself once typing is done.
   */
  function buildWatermarkTypingCue(composedText, needsWatermark) {
    if (!needsWatermark || !composedText) return null;
    const text = String(composedText);
    if (!text.endsWith(WATERMARK_TEXT)) return null;
    // Code points, to match typeIntoFacebookTextarea's `for…of` counter — an emoji
    // in the caption would put a UTF-16 length ahead of the real character index.
    const atIndex = Array.from(text).length - WATERMARK_TEXT.length;
    if (atIndex < 0) return null;
    return { atIndex, fire: () => WatermarkCta.stop() };
  }

  // --- Shared Auth Utility (used by both overlay and popup paths) ---

  async function getAuthStatus() {
    const result = await new Promise(resolve =>
      chrome.storage.local.get(['authExpiry'], resolve)
    );
    const { authExpiry } = result;
    const isNewUser = !authExpiry;
    const isExpired = !!(authExpiry && new Date(authExpiry) <= new Date());
    const isAuthorized = !!(authExpiry && new Date(authExpiry) > new Date());
    return { isNewUser, isExpired, isAuthorized };
  }

  // ==================== UNIVERSAL PLATFORM SPOOFING ====================
  /**
   * Ensures ALL users appear as Windows Chrome to Facebook for consistent UI
   * This forces Facebook to serve the same UI elements regardless of actual OS
   */
  function enforceUniversalPlatformSpoofing() {
    console.log('🔍 Platform Detection:');
    console.log('   User Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36');
    console.log('   Platform: Win32');
    console.log('   💻 Detected: Windows/Linux/Other');
    console.log('   ℹ️ No User-Agent spoofing needed');
    
    // Force activate User-Agent spoofing for ALL users
    chrome.storage.local.set({
      userAgentSpoofingActive: true,
      spoofedPlatform: 'Windows'
    }, () => {
      console.log('   ✅ Universal User-Agent Spoofing: ENFORCED');
      console.log('   ℹ️ All users will appear as Windows Chrome to Facebook');
    });
  }
  
  // Enforce universal spoofing immediately
  enforceUniversalPlatformSpoofing();
  // ==================== END UNIVERSAL PLATFORM SPOOFING ====================

  // --- Helper Functions ---

  // NOTE ON BACKGROUND TIMING: an earlier version routed every delay through a Web Worker
  // (worker timers aren't throttled in hidden tabs). But Facebook's page CSP silently
  // blocks extension-created workers on some setups — the worker constructs but never
  // responds and `onerror` never fires, so every `await sleep()` hung forever (the
  // "stuck on 1/5" bug). Removed in v15.1 — we use plain native setTimeout, which can't hang.
  //
  // Background operation is NOT supported: sharing requires the Facebook tab to stay
  // visible. See the VisibilityWatch note below for why.

  // ==================== VISIBILITY WATCH ====================
  // THE TAB MUST STAY VISIBLE FOR THE WHOLE SHARE. This is a hard requirement, not a
  // preference.
  //
  // History: v15.2–v16.6 played an inaudible 40 Hz tone during a share ("KeepAwake"),
  // on the theory that Chrome exempts an audible tab from background timer throttling
  // and that this would keep Facebook's own timers running. It does un-throttle
  // setTimeout — but that is NOT sufficient. A hidden tab also stops
  // requestAnimationFrame, IntersectionObserver callbacks and layout/paint work, and
  // Facebook's share flow depends on all of them: rows never mount, menus never open,
  // clicks land on elements that never re-render. In practice the share loop kept
  // "succeeding" against the composer that was still open from the last group the user
  // actually watched — i.e. it POSTED TO THE SAME GROUP REPEATEDLY (confirmed in the
  // field). The audio bought nothing and gave users false confidence that backgrounding
  // was safe, so it was removed.
  //
  // What we do instead: refuse to pretend. We watch document.visibilityState for the
  // duration of a share, warn loudly in the progress overlay and the tab title the
  // moment the tab is hidden, and report it in the completion summary. The UI tells the
  // user up front to leave the tab open and visible.
  //
  // PAUSE / RESUME (v18.0). "Hidden" is not one situation, it is two, and only one of
  // them is dangerous:
  //
  //   • Hidden MID-GROUP — a dialog is open, a composer is filled, a Post click is in
  //     flight. Facebook has stopped rendering underneath all of it, so whatever the
  //     loop does next lands on stale elements. This is the state that posted to the
  //     same group 5× in v16.6. It still taints the run (`wentHidden`).
  //
  //   • Hidden BETWEEN GROUPS — the previous group is finished, the next has not
  //     started, nothing is half-done. There is nothing to corrupt here; the only
  //     reason this used to wreck a run is that the loop charged straight into the
  //     next group against a frozen page.
  //
  // So the loop declares a SAFE ZONE around the between-groups gap and waits it out
  // instead of charging on. A user who locks their screen at work now comes back to a
  // run that parked itself at group 23 and carries on, rather than a ruined one.
  //
  // ⚠️ This does NOT make sharing work while the screen is locked. Nothing can — the
  // page is not rendering. It only stops a lock from being destructive.
  const VisibilityWatch = (() => {
    let active = false;
    let wentHidden = false;   // hidden while real work was in flight — disqualifies the run
    let safeZone = false;     // true between groups: hiding here is harmless, we just wait
    let handler = null;
    let waiters = [];

    function notify(hidden, paused) {
      const UI = window.ShareUnlimited && window.ShareUnlimited.UI;
      if (UI && UI.setTabHiddenWarning) {
        try { UI.setTabHiddenWarning(hidden, paused ? 'paused' : 'danger'); } catch (e) {}
      }
    }

    function releaseWaiters() {
      const queued = waiters;
      waiters = [];
      queued.forEach((fn) => { try { fn(); } catch (e) {} });
    }

    // Begin watching. Returns immediately; call stop() when the share ends.
    function start() {
      if (active) return;
      active = true;
      wentHidden = false;
      // Nothing is in flight until the first group actually starts, so we open in the
      // safe state: a user who clicks Share Now and immediately locks gets a pause,
      // not a tainted run.
      safeZone = true;
      handler = () => {
        const hidden = document.visibilityState === 'hidden';
        if (hidden) {
          if (safeZone) {
            console.log('⏸️ MGSA: tab hidden between groups — pausing. The run resumes ' +
              'by itself when you come back to this tab.');
            TabTitle.setText('⏸️ MGSA — PAUSED, come back to resume');
          } else {
            wentHidden = true;
            console.warn('⚠️ MGSA: tab was hidden MID-GROUP. Facebook cannot render or ' +
              'respond to clicks while backgrounded — come back to this tab now.');
            TabTitle.setText('⚠️ MGSA — COME BACK TO THIS TAB');
          }
        } else {
          console.log('✅ MGSA: tab visible again.');
          TabTitle.showProgress();
          releaseWaiters();
        }
        notify(hidden, safeZone);
      };
      document.addEventListener('visibilitychange', handler);
      if (document.visibilityState === 'hidden') handler();
    }

    // Park until the tab is visible again. Resolves true if it actually had to wait,
    // so the caller knows to treat whatever is on screen as stale.
    function waitUntilVisible() {
      if (!active || document.visibilityState !== 'hidden') return Promise.resolve(false);
      return new Promise((resolve) => {
        let done = false;
        let poll = null;
        const finish = () => {
          if (done) return;
          done = true;
          if (poll) clearInterval(poll);
          resolve(true);
        };
        // Normal path: the visibilitychange handler releases us the instant the user
        // comes back.
        waiters.push(finish);
        // Escape hatch. The overlay's Cancel button is only reachable once the tab is
        // visible (which resolves us anyway), but a cancel from any other surface must
        // never leave the loop parked forever. Chrome throttles this to ~1/min while
        // hidden — fine, nothing waits on it except the loop's own exit.
        poll = setInterval(() => {
          if (!active || State.shareProcessCancelled) finish();
        }, 1000);
      });
    }

    // Between groups nothing is half-done, so hiding is a pause rather than damage.
    function beginSafeZone() { safeZone = true; }
    // Real work is about to start; from here a hidden tab taints the run.
    function endSafeZone() { safeZone = false; }

    // Stop watching. Returns true if the tab was hidden while work was in flight.
    function stop() {
      if (handler) document.removeEventListener('visibilitychange', handler);
      handler = null;
      active = false;
      safeZone = false;
      // Never leave a parked waiter behind — that would hang the share's own finally.
      releaseWaiters();
      notify(false, false);
      const result = wentHidden;
      wentHidden = false;
      return result;
    }

    return {
      start, stop, waitUntilVisible, beginSafeZone, endSafeZone,
      wasHidden: () => wentHidden
    };
  })();
  // ==================== END VISIBILITY WATCH ====================

  // ==================== TAB TITLE PROGRESS ====================
  // Shows share progress in the browser tab title, e.g. "(1/10) MGSA Sharing…", so the
  // user can watch it advance even while the tab is in the background (the tab title is
  // visible without switching to it). Facebook rewrites document.title on its own render
  // cycles, so while a share is active a MutationObserver re-asserts our title whenever FB
  // changes it. restore() puts the original title back.
  const TabTitle = (() => {
    let originalTitle = null;
    let desiredTitle = null;
    let progressTitle = null; // last "(n/N) MGSA …" — restored by showProgress()
    let observer = null;

    function apply() {
      if (desiredTitle !== null && document.title !== desiredTitle) {
        document.title = desiredTitle;
      }
    }

    function ensureObserver() {
      if (observer) return;
      // Observe <head> subtree: catches both <title> text edits and full <title> replacement.
      const head = document.head || document.documentElement;
      observer = new MutationObserver(() => apply());
      try { observer.observe(head, { childList: true, subtree: true, characterData: true }); }
      catch (e) { observer = null; }
    }

    // Set the tab title to "(current/total) MGSA Sharing…". Call once per group.
    function setProgress(current, total, suffix = 'Sharing…') {
      if (originalTitle === null) originalTitle = document.title;
      progressTitle = `(${current}/${total}) MGSA ${suffix}`;
      desiredTitle = progressTitle;
      ensureObserver();
      apply();
    }

    // Put the last progress title back after a temporary setText() (e.g. the
    // "come back to this tab" alarm), so the title isn't stuck on the alarm through a
    // long between-groups countdown once the user has returned.
    function showProgress() {
      if (progressTitle === null) return;
      desiredTitle = progressTitle;
      apply();
    }

    // Set an arbitrary sticky title (e.g. a done/failed summary).
    function setText(text) {
      if (originalTitle === null) originalTitle = document.title;
      desiredTitle = text;
      ensureObserver();
      apply();
    }

    // Stop enforcing and restore Facebook's original title.
    function restore() {
      if (observer) { try { observer.disconnect(); } catch (e) {} observer = null; }
      if (originalTitle !== null) {
        document.title = originalTitle;
        originalTitle = null;
      }
      desiredTitle = null;
      progressTitle = null;
    }

    return { setProgress, setText, showProgress, restore };
  })();
  // ==================== END TAB TITLE PROGRESS ====================

  /**
   * A simple delay function. Plain native setTimeout — never hangs. Chrome throttles this
   * in a hidden tab, which is one of several reasons the tab must stay visible during a
   * share (see the VisibilityWatch note above).
   * @param {number} ms - The number of milliseconds to wait.
   */
  const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

  // ==================== DELAY MODES (v18.0) ====================
  // How long the loop waits BETWEEN groups. Historically `randomizeDelay` was a plain
  // boolean meaning "add a random 15–35s ON TOP of the base delay", and several callers
  // still pass exactly that: popup.js, the `share_to_groups` message handler in
  // content_main.js, and the scheduling path. Those are untouched — a boolean still
  // means what it always meant, byte for byte.
  //
  // The share modal now sends a MODE STRING instead, and a mode REPLACES the base delay
  // rather than adding to it, so the number the user reads on the radio is the number
  // they get. That is the whole reason for the change: "randomize" used to mean
  // "your 8s becomes 23–43s", which nobody could predict from the label.
  //
  //   off        → the base delay, exactly, every time (today's default — unchanged)
  //   superfast  → 0s       🚀 no gap at all. Back-to-back, as fast as the loop can go.
  //   turbo      → 1–8s     ⚡ "Human Lookalike" in the UI — roughly hand-pace, randomised.
  //   safe       → 15–45s   🛡️ slow and irregular; what a big run should use.
  //
  // ⚠️ `turbo` IS THE 1–8s MODE, and stays that way. It was LABELLED "⚡ Turbo" from
  // v18.0 to v18.3; v18.4 renamed the label to "⚡ Human Lookalike" and gave the name
  // "🚀 Turbo" to the new 0s mode, whose KEY is `superfast`. The key was deliberately
  // NOT swapped to match the labels: 'turbo' is a value already travelling through the
  // schedule chain and through `shareToSelectedGroups`'s 6th arg, and redefining a live
  // string from "1–8s" to "0s" silently retimes runs that were set up under the old
  // meaning. Same reason the legacy boolean below was never folded into a mode. Labels
  // are UI; keys are a contract. If you find this confusing, the fix is a comment, not
  // a rename.
  //
  // NOTE ON WHAT THIS ACTUALLY SAVES: the gap is only part of a group's cost. Reopening
  // the dialog, finding the group, filling the composer and posting is ~10s of fixed
  // work per group that NO mode touches (see estimateRunSeconds in content_ui_modals.js).
  // Over 200 groups: ~60 min on the 8s default, ~48 min on Human Lookalike, ~33 min on
  // Superfast, ~133 min on Safest. So even 0s cannot go below ~10s per group — the way
  // to make a run genuinely faster is to cut fixed work (as v18.0's real-signal waits
  // did, ~23 min), not to keep shaving the gap. Don't let the UI imply otherwise.
  const DELAY_MODES = {
    off: null,          // fall through to the base delay
    superfast: [0, 0],  // 🚀 "Turbo" in the UI — no gap; countdown(0) is a no-op
    turbo: [1, 8],      // ⚡ "Human Lookalike" in the UI — see the warning above
    safe: [15, 45]
  };

  /**
   * Resolves the wait between two groups, in seconds.
   * @param {number} baseSeconds - the user's configured delay (used by `off`/legacy).
   * @param {boolean|string} randomizeDelay - legacy boolean, or a DELAY_MODES key.
   * @returns {number} seconds to wait before the next group.
   */
  function resolveDelayGap(baseSeconds, randomizeDelay) {
    const base = Math.max(0, Number(baseSeconds) || 0);
    const randIn = (lo, hi) => Math.floor(Math.random() * (hi - lo + 1)) + lo;

    // Legacy boolean: base + 15–35s. Do not "simplify" this into a mode — it is what
    // the popup and the scheduling path still send, and changing it silently retimes
    // every run those surfaces start.
    if (randomizeDelay === true) return base + randIn(15, 35);

    if (typeof randomizeDelay === 'string') {
      const range = DELAY_MODES[randomizeDelay];
      // NOTE: `[0, 0]` is an array and therefore truthy, so `superfast` resolves to a
      // real 0 rather than falling through to the base delay. Don't "tidy" this into a
      // truthiness check on the resolved number — that would silently turn the 0s mode
      // back into the 8s default. `countdown(0)` is a no-op by construction (its while
      // loop never runs), so 0 is a supported wait, not an edge case.
      if (range) return randIn(range[0], range[1]);
    }
    // false, 'off', or anything unrecognised → the base delay untouched. Only a mode
    // that explicitly asks for it can produce 0; a typo'd key never can, and no path
    // can produce NaN.
    return base;
  }
  // ==================== END DELAY MODES ====================

  /**
   * A delay function that updates the on-page countdown timer.
   * @param {number} seconds - The number of seconds to wait.
   */
  async function countdown(seconds) {
    // Reset skip flag at start of countdown
    State.countdownSkipRequested = false;

    let remaining = Math.floor(seconds);
    const updateOverlay = (n) => {
      if (window.ShareUnlimited.UI && window.ShareUnlimited.UI.updateCountdownOverlay) {
        window.ShareUnlimited.UI.updateCountdownOverlay(n);
      }
    };
    updateOverlay(remaining);

    // Between groups the ghost cursor drifts over to the countdown timer and
    // floats there, so the pause reads as "waiting on purpose" rather than
    // "stuck". Not awaited — the countdown must not wait on an animation.
    Ghost.point(document.getElementById('su-countdown-timer'));

    // The first few seconds belong to whatever the caller last said (normally
    // "up next: group 4/20 …"); after that the bubble counts down, because a
    // long silent pause is exactly when a user decides the thing has hung.
    const narrateFrom = remaining - 3;

    // Tick once per second. Chrome throttles this to ~1/min in a hidden tab — another
    // reason the tab must stay visible for the whole share.
    while (remaining > 0) {
      if (State.countdownSkipRequested) {
        console.log('⏭️ Countdown skipped by user');
        updateOverlay(0);
        return;
      }
      await new Promise(resolve => setTimeout(resolve, 1000));
      remaining--;
      updateOverlay(remaining);
      if (remaining > 0 && remaining <= narrateFrom) Ghost.say('wait', { seconds: remaining });
    }

    updateOverlay(0);
  }

  /**
   * Clicks an element, ensuring it's visible and ready.
   * @param {HTMLElement} element - The element to click.
   */
  async function clickElement(element) {
    if (element) {
      // Check if element is already in viewport
      const rect = element.getBoundingClientRect();
      const isInViewport = (
        rect.top >= 0 &&
        rect.left >= 0 &&
        rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
        rect.right <= (window.innerWidth || document.documentElement.clientWidth)
      );

      if (!isInViewport) {
        console.log('Element not in viewport, scrolling to it...');
        element.scrollIntoView({ behavior: 'smooth', block: 'center' });
        await sleep(300); // Wait for scroll
      } else {
        console.log('Element already in viewport, skipping scroll');
      }

      // Ghost cursor: glide to the target and flash the click ripple BEFORE the
      // real click lands (after the scroll above, so the rect is final). No-ops
      // unless an automated run is in progress. Cosmetic only.
      await Ghost.pointAndClick(element);

      // Use standard click
      element.click();
      return true;
    }
    return false;
  }

  /**
   * Recursively searches for elements matching a selector, penetrating Shadow DOM.
   */
  function querySelectorAllDeep(root, selector) {
    let results = [];
    try {
      if (root.querySelectorAll) {
        // 1. Search in the current root
        results.push(...Array.from(root.querySelectorAll(selector)));
        
        // 2. Find all elements with shadowRoots in this level
        const allElements = root.querySelectorAll('*');
        for (const el of allElements) {
          if (el.shadowRoot) {
            // Recursively search within the shadow root
            results.push(...querySelectorAllDeep(el.shadowRoot, selector));
          }
        }
      }
    } catch (e) {
      console.warn('Error in querySelectorAllDeep:', e);
    }
    return results;
  }

  /**
   * Gets the active element, traversing down into Shadow DOMs.
   */
  function getDeepActiveElement() {
    let el = document.activeElement;
    while (el && el.shadowRoot && el.shadowRoot.activeElement) {
      el = el.shadowRoot.activeElement;
    }
    return el;
  }

  /**
   * Gets all focusable elements within a container.
   */
  function getFocusableElements(container) {
    const focusableSelector = 'a[href], area[href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]), iframe, object, embed, *[tabindex], *[contenteditable]';
    return querySelectorAllDeep(container, focusableSelector).filter(el => {
      const style = window.getComputedStyle(el);
      return el.offsetWidth > 0 && el.offsetHeight > 0 && style.visibility !== 'hidden' && style.display !== 'none';
    });
  }

  // --- Language-independent structural matching (v17.7) ---

  /**
   * Facebook translates every string it renders — including aria-label, which reads
   * like markup but is just text in disguise ("Share to a group" → "שיתוף בקבוצה").
   * Everything in `Struct` matches on things Facebook CANNOT translate, so the share
   * flow keeps working on a non-English UI.
   *
   * These are FALLBACKS, never replacements. Every caller tries its existing English
   * check first and only reaches here if that found nothing, so an account that works
   * today behaves byte-for-byte identically. See QUICKSTART §5 "Non-English Facebook".
   *
   * Derived from matched English/Hebrew DOM captures in quickstart/captures/ — rerun
   * diagnose-capture-html.js in both languages before changing any constant here.
   */
  const Struct = (() => {
    /**
     * Sprite-sheet offsets, read off the SAME sheet file in both languages. Facebook
     * paints these icons as a CSS background at a fixed offset; a picture has no
     * translation, so the offset is identical on every locale.
     *
     * ⚠️ RTL caveat: this holds for the share sheet, but NOT for group-row icons —
     * those swap to a mirrored glyph in RTL (0px -87px LTR vs 0px -62px RTL), which
     * is why row detection below uses structure instead of icons.
     */
    const SPRITE = {
      // The "Group" tile in the unified share sheet. A LIST, not a single value: the
      // offset is stable across locales (verified identical in an LTR and an RTL
      // language on the same sheet file) but Facebook does regenerate sprite sheets
      // between builds. Add newly observed offsets here rather than replacing — an
      // extra candidate costs nothing, and a stale one simply never matches.
      GROUP_OPTION: ['0px -125px']
    };

    function visible(el) {
      if (!el || !el.getClientRects || !el.getClientRects().length) return false;
      const s = window.getComputedStyle(el);
      return s.visibility !== 'hidden' && s.display !== 'none';
    }

    /** Normalizes a computed background-position for comparison ("0px  -125px" → "0px -125px"). */
    function normalizeOffset(pos) {
      return (pos || '').trim().replace(/\s+/g, ' ');
    }

    /**
     * True when `el` (or anything inside it) is painted with the given sprite offset.
     * Facebook nests the icon a few levels below the clickable element, so this has
     * to search descendants rather than read the button itself.
     */
    function hasSpriteIcon(el, offsets) {
      if (!el) return false;
      const want = (Array.isArray(offsets) ? offsets : [offsets]).map(normalizeOffset);
      const nodes = [el, ...el.querySelectorAll('i, div, span')];
      for (const n of nodes) {
        const s = window.getComputedStyle(n);
        if (!s.backgroundImage || s.backgroundImage === 'none') continue;
        if (want.includes(normalizeOffset(s.backgroundPosition))) return true;
      }
      return false;
    }

    /**
     * The "Group" tile in the share sheet, found by its icon instead of its label.
     *
     * Position is deliberately NOT used: the tile is item [2] on an English sheet but
     * [3] on Hebrew (which also offers Messenger and "friend's profile"), so indexing
     * would click the wrong destination — the exact failure this whole change exists
     * to prevent.
     */
    function findGroupOptionByIcon() {
      // Primary: find by sprite icon offset
      const items = document.querySelectorAll('div[role="listitem"]');
      for (const item of items) {
        if (!visible(item)) continue;
        if (!hasSpriteIcon(item, SPRITE.GROUP_OPTION)) continue;
        const btn = item.querySelector('div[role="button"]');
        if (btn && visible(btn) && !item.querySelector('a[href]')) return btn;
      }
      
      // Fallback: find by text content "Group" (handles new Facebook UI layouts)
      for (const item of items) {
        if (!visible(item)) continue;
        const btn = item.querySelector('div[role="button"]');
        if (!btn || !visible(btn)) continue;
        if (item.querySelector('a[href]')) continue; // skip WhatsApp, X, etc.
        const text = (item.textContent || '').trim().toLowerCase();
        if (text === 'group') return btn;
      }
      
      return null;
    }

    /**
     * The group picker's search field. `type="search"` is an HTML input type, not a
     * word, so it survives translation — only the placeholder and aria-label change.
     */
    function findGroupSearchInput(dialog) {
      const scope = dialog || document;
      return scope.querySelector('input[type="search"]') ||
             scope.querySelector('input[role="textbox"][type="search"]') ||
             null;
    }

    /**
     * A group row, identified by shape rather than by its "Public group" subtitle.
     * Every row is a listitem wrapping a button, with an avatar and a link to
     * /groups/<id>/ — none of which is language-dependent.
     */
    function isGroupRow(el) {
      if (!el) return false;
      const row = el.closest ? (el.closest('[role="listitem"]') || el) : el;
      if (!row.querySelector) return false;
      const hasControl = row.getAttribute('role') === 'listitem' || !!row.querySelector('div[role="button"]');
      const hasAvatar = !!row.querySelector('img, image, svg, i');
      return hasControl && hasAvatar;
    }

    /**
     * The group's own name, without its "Public group" / "קבוצה ציבורית" subtitle.
     *
     * Facebook renders name and subtitle as SEPARATE spans, so taking the first one
     * needs no knowledge of what the subtitle says in any language. That is strictly
     * better than string-splitting on the English words, which silently returned the
     * whole "<name>Public group" blob on a translated UI.
     */
    function groupNameFromRow(row) {
      if (!row || !row.querySelector) return null;
      const scope = row.closest('[role="listitem"]') || row;
      const full = (scope.textContent || '').replace(/\s+/g, ' ').trim();
      if (!full) return null;

      // LEAF spans only. querySelectorAll returns document order including WRAPPER
      // spans, and a wrapper around both name and subtitle comes first — its
      // textContent is the whole "A test groupקבוצה ציבורית" blob, which is exactly
      // the concatenation this function exists to avoid. A span with no descendant
      // span is a real text node holder.
      const leaves = Array.from(scope.querySelectorAll('span'))
        .filter(s => !s.querySelector('span'))
        .map(s => (s.textContent || '').replace(/\s+/g, ' ').trim())
        .filter(t => t.length > 0);
      if (!leaves.length) return null;

      const name = leaves[0];
      if (name.length < 2 || name.length > 200) return null;

      // The name must be the LEADING fragment of the row's own text. If it isn't, the
      // markup isn't what we think it is (or we grabbed a styling fragment), and
      // returning null leaves the caller on its existing text path rather than
      // indexing a wrong name — which would poison the inventory and every later
      // search for that group.
      if (!full.startsWith(name)) return null;
      if (name.length === full.length) return null;   // no subtitle to strip

      return name;
    }

    /**
     * Reads the composer's audience WITHOUT reading its text.
     *
     * The privacy chip is disabled in a group composer (you cannot change the audience
     * of a group post) and editable on your own feed. That difference is behavioural,
     * not linguistic, and was identical across the English and Hebrew captures:
     *
     *   group composer → aria-disabled="true",  tabindex="-1", no CSS sprite icon
     *   feed composer  → aria-disabled absent,  tabindex="0",  globe sprite icon
     *
     * Returns 'group' | 'feed' | 'unknown'. 'unknown' means "no opinion" and must
     * never be treated as a failure — a markup change has to degrade to the existing
     * text checks, not start blocking legitimate shares.
     */
    function composerAudienceKind() {
      const composer = findComposerDialog();
      if (!composer) return 'unknown';

      const editor = composer.querySelector('[data-lexical-editor="true"]');

      const chips = Array.from(composer.querySelectorAll('div[role="button"]'))
        .filter(visible)
        .filter(b => {
          const label = (b.getAttribute('aria-label') || '').trim();
          const own = (b.textContent || '').trim();
          // The chip always carries BOTH an aria-label and visible text; every other
          // composer control is icon-only (aria-label, no text) or text-only.
          if (!label || !own || own.length > 60) return false;
          // Primary signal: the label restates the visible text ("Edit privacy. Sharing
          // with Public group." contains "Public group"). Held in both captured locales.
          if (label.length > own.length && label.includes(own)) return true;
          // Secondary signal, for languages that inflect the word inside the sentence so
          // the substring test fails: the chip sits ABOVE the editor. Everything with
          // both a label and text below the editor is a footer action, not the chip.
          return !!(editor && (editor.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_PRECEDING));
        });

      if (!chips.length) return 'unknown';

      // A group post's audience is FIXED, so its chip is inert. Checked first because
      // a false 'group' merely allows a share the English path would also have allowed,
      // while a false 'feed' would block a legitimate one.
      for (const chip of chips) {
        if (chip.getAttribute('aria-disabled') === 'true' && chip.getAttribute('tabindex') === '-1') {
          return 'group';
        }
      }
      // Only call it a feed when EVERY candidate is editable — one ambiguous chip is
      // not worth blocking a real share over.
      const allEditable = chips.every(c =>
        c.getAttribute('aria-disabled') !== 'true' && c.getAttribute('tabindex') === '0'
      );
      return allEditable ? 'feed' : 'unknown';
    }

    /**
     * The "Create post" composer dialog, identified by what it CONTAINS rather than by
     * its label. Facebook builds the post box on Lexical, so the editor carries
     * data-lexical-editor="true" — an implementation detail, not a word, so it reads
     * the same on every locale.
     *
     * Scans back-to-front because FB keeps earlier share-flow screens mounted; the
     * composer is the most recently opened dialog.
     */
    function findComposerDialog() {
      // EDITOR-FIRST, deliberately. Facebook renders the composer INSIDE the same
      // dialog element that still holds the group picker's search box and rows — a
      // real capture showed the editor living in a dialog that also looked like the
      // picker, while the dialog actually labelled "Create post" contained no editor
      // at all. So any "is this the picker?" exclusion rejects the very dialog we
      // want. Find the editor, then take the dialog it sits in.
      const ed = findPostEditor();
      if (ed) {
        const d = ed.closest('div[role="dialog"]');
        if (d) return d;
      }

      // Fallback for a composer whose editor hasn't mounted yet: an aria-placeholder
      // anywhere. The VALUE is translated ("יצירת פוסט ציבורי..."), the attribute's
      // presence is not.
      const dialogs = Array.from(document.querySelectorAll('div[role="dialog"]'))
        .filter(visible)
        .reverse();
      for (const d of dialogs) {
        if (d.querySelector('[aria-placeholder]')) return d;
      }

      return null;
    }

    /**
     * The post composer's text field itself.
     *
     * Matched on Facebook's own editor markup, all of which is language-independent:
     *   contenteditable="true" role="textbox" data-lexical-editor="true"
     *   aria-placeholder="<translated>"     ← attribute present, value irrelevant
     *
     * Must live inside a dialog: that is what separates the composer from the comment
     * boxes sitting in the feed behind it. Later matches win because Facebook mounts
     * the composer after everything already on the page.
     */
    function findPostEditor() {
      const candidates = Array.from(document.querySelectorAll(
        '[data-lexical-editor="true"][contenteditable="true"],' +
        '[role="textbox"][contenteditable="true"],' +
        '[contenteditable="true"][aria-placeholder]'
      )).filter(e => e.closest('div[role="dialog"]') && visible(e) &&
                     e.getBoundingClientRect().width > 0);
      return candidates.length ? candidates[candidates.length - 1] : null;
    }

    /**
     * The composer's submit button, by shape: in both languages every other footer
     * control is icon-only (aria-label, no text), and the submit button is the LAST
     * one carrying visible text. Callers still check aria-disabled themselves.
     */
    function findSubmitButtonByShape(dialog) {
      const scope = dialog || document;
      const withText = Array.from(scope.querySelectorAll('div[role="button"]'))
        .filter(b => {
          if (b.dataset && b.dataset.multiGroupButton === 'true') return false;
          if (!visible(b)) return false;
          const t = (b.textContent || '').trim();
          return t.length > 0 && t.length < 40;
        });
      return withText.length ? withText[withText.length - 1] : null;
    }

    return {
      SPRITE,
      visible,
      hasSpriteIcon,
      findGroupOptionByIcon,
      findGroupSearchInput,
      isGroupRow,
      groupNameFromRow,
      composerAudienceKind,
      findComposerDialog,
      findPostEditor,
      findSubmitButtonByShape
    };
  })();

  // --- Facebook Interaction Logic ---

  /**
   * Helper function to extract and validate group name from button text
   * Returns null if the name is invalid, otherwise returns the cleaned group name
   */
  function extractAndValidateGroupName(buttonText, rowElement = null) {
    let groupName = buttonText.trim();

    // Remove group type indicators
    const hadEnglishSubtitle = groupName.includes('Public group') || groupName.includes('Private group');
    if (groupName.includes('Public group')) {
      groupName = groupName.split('Public group')[0].trim();
    } else if (groupName.includes('Private group')) {
      groupName = groupName.split('Private group')[0].trim();
    }

    // Non-English UI (v17.7): the subtitle above is English, so on a translated UI it
    // never strips and the name comes back as "<name>קבוצה ציבורית" — which then fails
    // every downstream comparison. Facebook renders the name and the subtitle as
    // separate spans, so read the first span instead. Only runs when the English strip
    // found nothing AND we were handed the row, so existing behaviour is untouched.
    if (!hadEnglishSubtitle && rowElement) {
      const fromSpan = Struct.groupNameFromRow(rowElement);
      if (fromSpan && fromSpan.length < groupName.length) {
        groupName = fromSpan;
      }
    }

    // Extract first line only
    const lines = groupName.split('\n').map(l => l.trim()).filter(l => l.length > 0);
    groupName = lines[0];
    
    // Validate the extracted name
    if (groupName && 
        groupName.length > 2 && 
        groupName.length < 100 &&
        !groupName.toLowerCase().includes('search') &&
        !groupName.toLowerCase().includes('close') &&
        !groupName.toLowerCase().includes('back') &&
        !groupName.toLowerCase().includes('all groups')) {
      return groupName;
    }
    
    return null;
  }

  /**
   * Composer audience sanity check (v15.9). The "Create post" composer that appears
   * after picking a group does NOT name the group anywhere (verified against captured
   * HTML) — its audience chip only says which KIND of audience:
   *   <div aria-label="Edit privacy. Sharing with Public group. " role="button">
   * So the target group can't be ID-verified here. What CAN be caught is landing in
   * the wrong composer entirely (a feed share reads "Sharing with Public" — no
   * "group"), which would post to the user's own profile. Returns false ONLY on that
   * positive contradiction; a missing/unrecognized chip (markup variant, other
   * locale) returns true so it never blocks legitimate sharing.
   */
  function composerAudienceLooksLikeGroup(expectedGroupName = null) {
    // Check EVERY chip, not the first one (v15.9 false-positive fix): the share flow
    // keeps its earlier screen — the share popover, whose feed section has its own
    // "Sharing with Public." chip — in the DOM as a hidden sibling dialog while the
    // "Create post" composer is showing, so single-element reads land on the wrong chip.
    //
    // FB ships (at least) TWO composer chip variants:
    //   A: "Edit privacy. Sharing with Public group." / "Private group."  (type only)
    //   B: "Edit privacy. Sharing with This post will be visible to members of
    //       <Group Name>."  — note: does NOT contain the word "group", but it NAMES
    //       the target, so variant B lets us verify the EXACT group we clicked.
    // Block only when chips exist and none indicates a group (feed-only composer),
    // or when variant B names a different group than the one we're sharing to.
    const chips = document.querySelectorAll('div[role="dialog"] [aria-label^="Edit privacy. Sharing with"]');

    // Non-English UI (v17.7): that selector is English, so on a translated Facebook it
    // matches NOTHING and the guard used to return true for every share — silently
    // switching itself off for exactly the users it should protect. Structural read:
    // the privacy chip is DISABLED in a group composer (a group post's audience is
    // fixed) and EDITABLE on your own feed. Verified identical in EN and HE captures.
    if (!chips.length) {
      const kind = Struct.composerAudienceKind();
      if (kind === 'feed') {
        console.warn('🛑 Composer audience chip is editable — this is a FEED composer, not a group!');
        return false;
      }
      if (kind === 'group') {
        console.log('✅ Composer verified as a group composer (structural check)');
        return true;
      }
      return true; // unknown — never block on a markup we don't recognise
    }

    const labels = Array.from(chips).map(c => (c.getAttribute('aria-label') || '').trim());

    // Variant A — any chip mentioning "group" is a group composer.
    if (labels.some(l => /group/i.test(l))) return true;

    // Variant B — "visible to members of <name>": extract the name(s) and, when we
    // know which group we're sharing to, verify it. startsWith both ways tolerates
    // FB truncating long names in the chip.
    const memberNames = labels
      .filter(l => /members of/i.test(l))
      .map(l => l.replace(/^.*members of\s*/i, '').replace(/[.…\s]+$/, ''));
    if (memberNames.length) {
      if (!expectedGroupName) return true; // members-of = some group IS targeted
      const target = normalizeGroupNameForMatch(expectedGroupName);
      const matched = memberNames.some(n => {
        const nn = normalizeGroupNameForMatch(n);
        return nn === target || nn.startsWith(target) || target.startsWith(nn);
      });
      if (matched) {
        console.log(`✅ Composer verified: sharing to members of "${expectedGroupName}"`);
        return true;
      }
      console.warn(`🛑 Composer targets members of "${memberNames.join('" / "')}" — NOT the expected group "${expectedGroupName}"!`);
      return false;
    }

    console.warn(`🛑 Composer audience chips [${labels.map(l => `"${l}"`).join(', ')}] — none indicate a group!`);
    return false;
  }

  /**
   * Finds the main "Post" button in the dialog.
   */
  function findPostButton() {
      const buttons = document.querySelectorAll('div[role="dialog"] div[role="button"]');
      // console.log(`Searching for Post button among ${buttons.length} buttons`);
      
      for (const button of buttons) {
          const text = button.textContent.trim().toLowerCase();
          const isDisabled = button.getAttribute('aria-disabled') === 'true';
          // console.log(`Button text: "${text}", disabled: ${isDisabled}`);
          
          if (text === 'post' && !isDisabled) {
              console.log('Found enabled Post button!');
              return button;
          }
      }

      // Non-English UI (v17.7): "post" is English. Fall back to the button's SHAPE —
      // in the composer footer every other control is icon-only (aria-label, no text),
      // so the submit button is the last one carrying visible text. Still requires the
      // button to be enabled, exactly like the English path.
      const dialog = findShareDialog() || document.querySelector('div[role="dialog"]');
      const byShape = Struct.findSubmitButtonByShape(dialog);
      if (byShape && byShape.getAttribute('aria-disabled') !== 'true') {
          console.log(`🌍 Found Post button by shape (non-English UI): "${(byShape.textContent || '').trim()}"`);
          return byShape;
      }

      console.debug('Post button not found or is disabled');
      return null;
  }

  /**
   * Waits for the Post button to become enabled
   */
  async function waitForPostButton(maxWaitMs = 5000) {
      const startTime = Date.now();
      while (Date.now() - startTime < maxWaitMs) {
          const postButton = findPostButton();
          if (postButton) {
              console.log('Post button is ready!');
              return postButton;
          }
          await sleep(500);
      }
      console.error('Timeout waiting for Post button');
      return null;
  }

  /**
   * Waits for a clicked Post to ACTUALLY land, instead of guessing with a fixed sleep.
   *
   * The old code did `sleep(5000)` after the click, which was wrong in both directions:
   * Facebook usually finishes in ~1–2s (so we threw away 3–4s per group — about 12
   * minutes across a 200-group run), and when it's slow, 5s wasn't enough either, so we
   * started tearing the UI apart for the next group mid-post.
   *
   * ⚠️ WHY THIS DOESN'T LOOK FOR "Posting…": that string is TRANSLATED, and gating on
   * English text is the exact mistake v17.7 exists to undo. The structural signal is the
   * composer going away — Facebook tears it down once it accepts the post, in every
   * language. We already hold the button element, so this needs no selector at all.
   *
   * Both the clicked button AND its host dialog must be gone or invisible:
   *  - button alone isn't enough — React can swap the node while the composer stays up;
   *  - dialog alone isn't enough — FB reuses dialog shells across share-flow screens;
   *  - "invisible" as well as "removed" because FB keeps previous screens MOUNTED and
   *    hidden (the same trap as hasLiveSelectAllToolbar / the audience guard).
   *
   * Never throws and never reports failure as success — the caller decides what an
   * un-landed post means.
   *
   * @param {Element} postButton - the button that was just clicked.
   * @param {Element|null} hostDialog - its containing dialog, captured BEFORE the click.
   * @param {number} maxWaitMs - cap. Deliberately longer than the old fixed 5s: a slow
   *   upload needs it, and the fast path exits in ~1s anyway.
   * @returns {Promise<{landed: boolean, ms: number}>}
   */
  async function waitForPostToLand(postButton, hostDialog, maxWaitMs = 15000) {
    const started = Date.now();
    if (!postButton) return { landed: false, ms: 0 };

    const gone = (el) => !el || !el.isConnected || !isElementVisible(el);

    while (Date.now() - started < maxWaitMs) {
      if (gone(postButton) && gone(hostDialog)) {
        return { landed: true, ms: Date.now() - started };
      }
      await sleep(250);
    }
    return { landed: false, ms: Date.now() - started };
  }

  // After the composer disappears we still pause before yanking the UI around for the
  // next group — partly to let Facebook settle, partly because an instant jump to the
  // next action is the least human thing the run does. Jittered rather than a flat
  // 1000ms for the same reason the pace modes randomise.
  const POST_SETTLE_MIN_MS = 700;
  const POST_SETTLE_MAX_MS = 1300;

  /**
   * Waits for the "Create post" composer to be READY TO TYPE INTO, replacing the flat
   * sleep(5000) that used to sit before fillPostContent (v18.0).
   *
   * The signal is `Struct.findPostEditor()` — Facebook's Lexical editor node:
   *
   *   <div contenteditable="true" role="textbox" data-lexical-editor="true"
   *        aria-placeholder="Create a public post…" …>
   *
   * ⚠️ Of everything on that element, only THREE attributes are safe to match:
   * `contenteditable`, `role="textbox"` and `data-lexical-editor`. They are markup, not
   * words, so they read the same on every locale (v17.7).
   *   - **`aria-placeholder`'s VALUE is translated** ("יצירת פוסט ציבורי…"). Struct only
   *     ever tests that the attribute EXISTS. Never read its text, and never look for
   *     the sibling placeholder `<div aria-hidden="true">` either — that's the same
   *     translated string again.
   *   - **The `x1ejq31n x18oe1m7 …` class names are regenerated between Facebook
   *     builds.** They aren't language-dependent, they're worse: they rot silently.
   *
   * @param {number} minMs floor. The ghost's `willType` bubble is narrated into this
   *   pause (v17.9) and the whole point is that the user READS what is about to be
   *   typed — including the watermark. Returning the instant the editor mounts would
   *   flash that message for a few hundred ms and quietly break the rule.
   * @param {number} maxMs cap, after which we let fillPostContent try anyway rather
   *   than failing the group — it has its own dialog resolution and diagnostics.
   * @returns {Promise<{ready: boolean, ms: number}>}
   */
  async function waitForComposerReady(minMs = 2500, maxMs = 12000) {
    const started = Date.now();
    let editor = null;

    while (Date.now() - started < maxMs) {
      if (!editor) {
        try { editor = Struct.findPostEditor(); } catch (e) { /* never fatal */ }
      }
      // BOTH have to hold: the editor must exist AND the narration floor must have
      // elapsed. Whichever is slower wins.
      if (editor && Date.now() - started >= minMs) break;
      await sleep(200);
    }

    const ms = Date.now() - started;
    if (editor) {
      console.log(`✅ Composer ready in ${ms}ms (was a flat 5000ms wait)`);
    } else {
      console.warn(`⚠️ Composer editor never appeared after ${ms}ms — letting ` +
        'fillPostContent try anyway; its own diagnostics will dump what was on screen.');
    }
    return { ready: !!editor, ms };
  }

  /**
   * Marks a button and caches its location data for later retrieval
   */
  function markAndCacheButton(button) {
    if (!button) return;

    // Clear any previously-marked target so there is only ever ONE authoritative
    // Share button. Without this, marking a second listing would leave two targets
    // and findShareButton()'s querySelector could return the wrong (earlier) one —
    // which caused the extension to share the wrong listing.
    document.querySelectorAll('[data-share-unlimited-target="true"]').forEach(el => {
      if (el !== button) delete el.dataset.shareUnlimitedTarget;
    });

    // Mark with data attribute
    button.dataset.shareUnlimitedTarget = 'true';
    
    // Cache location and structural data
    const rect = button.getBoundingClientRect();
    const parent = button.parentElement;
    const grandparent = parent ? parent.parentElement : null;
    
    State.cachedShareButtonLocation = {
      // Position data (approximate, for matching after DOM changes)
      top: Math.round(rect.top),
      left: Math.round(rect.left),
      width: Math.round(rect.width),
      height: Math.round(rect.height),
      
      // Structural identifiers
      hasShareSvg: button.querySelector('svg path[d*="M12.863"]') !== null,
      parentClasses: parent ? parent.className : '',
      grandparentClasses: grandparent ? grandparent.className : '',
      
      // Timestamp
      cachedAt: Date.now()
    };
    
    console.log('📍 Cached button location data:', State.cachedShareButtonLocation);
  }

  /**
   * Attempts to find a button using cached location data
   */
  function findButtonByLocation(locationData) {
    if (!locationData) return null;
    
    // Don't use stale cache (older than 5 minutes)
    if (Date.now() - locationData.cachedAt > 300000) {
      console.log('⚠️ Cached location data is stale, ignoring');
      return null;
    }
    
    const allButtons = document.querySelectorAll('div[role="button"], div[tabindex="0"]');
    let bestMatch = null;
    let bestScore = 0;

    for (const button of allButtons) {
      if (button.dataset.multiGroupButton === 'true') continue;
      const rect = button.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) continue;
      
      let score = 0;
      
      // Position similarity (within 50px tolerance for dynamic layouts)
      const topDiff = Math.abs(rect.top - locationData.top);
      const leftDiff = Math.abs(rect.left - locationData.left);
      if (topDiff < 50 && leftDiff < 50) {
        score += 30;
        score += (50 - topDiff) / 2; // Closer = higher score
        score += (50 - leftDiff) / 2;
      }
      
      // Size similarity
      const widthDiff = Math.abs(rect.width - locationData.width);
      const heightDiff = Math.abs(rect.height - locationData.height);
      if (widthDiff < 20 && heightDiff < 20) {
        score += 10;
      }
      
      // Structural match
      if (locationData.hasShareSvg && button.querySelector('svg path[d*="M12.863"]')) {
        score += 50; // Strong signal - has share SVG
      }
      
      const parent = button.parentElement;
      const grandparent = parent ? parent.parentElement : null;
      if (parent && locationData.parentClasses && parent.className === locationData.parentClasses) {
        score += 15;
      }
      if (grandparent && locationData.grandparentClasses && grandparent.className === locationData.grandparentClasses) {
        score += 10;
      }
      
      if (score > bestScore) {
        bestScore = score;
        bestMatch = button;
      }
    }
    
    if (bestScore > 50) { // Require reasonable confidence
      console.log(`✓ Found button match with score ${bestScore}`);
      return bestMatch;
    }
    
    console.log(`✗ No confident match found (best score: ${bestScore})`);
    return null;
  }

  /**
   * Finds the original Share button that was clicked on the post
   */
  function findShareButton() {
    // 1. Check for cached/marked button first (exclude multi-group buttons that may have been mislabelled)
    const markedButton = document.querySelector('[data-share-unlimited-target="true"]');
    if (markedButton && document.body.contains(markedButton) && !markedButton.dataset.multiGroupButton) {
        console.log('🎯 Found cached original Share button (data attribute), using it.');
        return markedButton;
    }

    // 2. Try to find button using cached location data (for DOM reconstructions like in reels)
    if (State.cachedShareButtonLocation) {
        console.log('🔍 Attempting to relocate button using cached position data...');
        const relocatedButton = findButtonByLocation(State.cachedShareButtonLocation);
        if (relocatedButton) {
            console.log('✅ Successfully relocated button using position data!');
            markAndCacheButton(relocatedButton);
            return relocatedButton;
        }
    }

    console.log('Searching for Share button on post...');
    
    const candidates = [];

    // Helper to collect candidates
    const collectCandidate = (button, strategy) => {
      if (!button) return;
      if (candidates.some(c => c.element === button)) return;

      const rect = button.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) return;
      
      candidates.push({
        element: button,
        rect: rect,
        strategy: strategy,
        distanceFromCenter: Math.abs((rect.top + rect.height/2) - (window.innerHeight/2))
      });
    };
    
    // Strategy 1: Find by aria-label
    const ariaLabelButtons = document.querySelectorAll('[aria-label]');
    for (const button of ariaLabelButtons) {
      if (button.dataset.multiGroupButton === 'true') continue;
      const ariaLabel = button.getAttribute('aria-label').toLowerCase();

      if (ariaLabel.includes('boost') || ariaLabel.includes('promote') || ariaLabel.includes('ad')) {
        continue;
      }

      if (ariaLabel.includes('send this to friends') ||
          (ariaLabel.includes('share') && button.getAttribute('role') === 'button')) {
        collectCandidate(button, 'aria-label');
      }
    }
    
    // Strategy 2: Find by text in posts
    const posts = document.querySelectorAll('div[role="article"]');
    for (const post of posts) {
      const buttons = post.querySelectorAll('div[role="button"]');
      for (const button of buttons) {
        const text = button.textContent.trim();
        const ariaLabel = button.getAttribute('aria-label') || '';
        
        if ((text === 'Share' || ariaLabel.toLowerCase().includes('share')) &&
            !ariaLabel.toLowerCase().includes('boost') &&
            !ariaLabel.toLowerCase().includes('promote') &&
            !ariaLabel.toLowerCase().includes('ad')) {
          collectCandidate(button, 'post-button-text');
        }
      }
    }
    
    // Strategy 3: Find ICON-ONLY share buttons (for reels/videos)
    const allButtons = document.querySelectorAll('div[role="button"], div[tabindex="0"]');
    for (const button of allButtons) {
      const svg = button.querySelector('svg path[d*="M12.863"]') || 
                   button.querySelector('svg path[d*="8.382"]'); 
      
      if (svg) {
        const ariaLabel = button.getAttribute('aria-label') || '';
        if (!ariaLabel.toLowerCase().includes('boost') && 
            !ariaLabel.toLowerCase().includes('promote')) {
          collectCandidate(button, 'icon-svg');
        }
      }
    }
    
    console.log(`Found ${candidates.length} candidate Share buttons`);
    
    if (candidates.length === 0) {
      console.warn('Could not find any Share button on post');
      return null;
    }

    // Filter for visible candidates
    const visibleCandidates = candidates.filter(c => {
        const r = c.rect;
        return (
            r.top >= 0 &&
            r.left >= 0 &&
            r.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
            r.right <= (window.innerWidth || document.documentElement.clientWidth)
        );
    });

    if (visibleCandidates.length > 0) {
        visibleCandidates.sort((a, b) => a.rect.top - b.rect.top);
        const bestCandidate = visibleCandidates[visibleCandidates.length - 1];
        console.log(`Selected Share button (Strategy: ${bestCandidate.strategy}, Top: ${Math.round(bestCandidate.rect.top)}px)`);
        
        markAndCacheButton(bestCandidate.element);
        return bestCandidate.element;
    } else {
        console.log('No fully visible buttons, using proximity fallback...');
        candidates.sort((a, b) => a.distanceFromCenter - b.distanceFromCenter);
        const bestCandidate = candidates[0];
        console.log(`Selected Share button (Strategy: ${bestCandidate.strategy}, Distance: ${Math.round(bestCandidate.distanceFromCenter)}px)`);
        
        markAndCacheButton(bestCandidate.element);
        return bestCandidate.element;
    }
  }

  /**
   * Resolves the live "Share to a group" dialog. Facebook ships TWO markup variants and
   * different accounts get different ones:
   *   (A, legacy) <div role="dialog" aria-labelledby="…">      — heading wired via aria-labelledby
   *   (B, newer)  <div role="dialog" aria-label="Share to a group" aria-modal="true">
   *
   * This helper is PURELY ADDITIVE: variant A is matched first and returned unchanged, so
   * any account whose MGSA works today keeps the exact same behaviour. Only when NO
   * aria-labelledby dialog exists (the new UI) do we fall back to the aria-label variant,
   * and finally to a heading-text match. Returns the dialog element or null.
   */
  function findShareDialog() {
    // Variant A (legacy/primary) — unchanged behaviour for existing working setups.
    const byLabelledBy = document.querySelector('div[role="dialog"][aria-labelledby]');
    if (byLabelledBy) return byLabelledBy;

    const dialogs = Array.from(document.querySelectorAll('div[role="dialog"]'));

    // Variant B (new UI) — dialog labelled directly via aria-label.
    const byAriaLabel = dialogs.find(d => {
      const label = (d.getAttribute('aria-label') || '').trim().toLowerCase();
      return label === 'share to a group' || label === 'share';
    });
    if (byAriaLabel) return byAriaLabel;

    // Last resort — any dialog that actually contains the "Share to a group" heading (h2 or h3).
    const byHeading = dialogs.find(d =>
      Array.from(d.querySelectorAll('h2, h3')).some(h => {
        const t = h.textContent.trim();
        const span = h.querySelector('span');
        return t === 'Share to a group' || (span && span.textContent.trim() === 'Share to a group');
      })
    );
    if (byHeading) return byHeading;

    // Non-English UI (v17.7): all three checks above are English. A dialog that holds
    // BOTH a search input and group rows is the picker in any language — this is what
    // makes the toolbar appear at all on a translated Facebook.
    return dialogs.find(d =>
      Struct.findGroupSearchInput(d) && d.querySelector('div[role="listitem"]')
    ) || null;
  }

  /**
   * Extracts group names from the share dialog with their checked status.
   */
  async function getGroupNames() {
    const groupsWithStatus = [];

    const dialog = findShareDialog();

    if (!dialog) {
      console.log('No share-to-group dialog found - not on group selection screen');
      return [];
    }
    
    await sleep(1000);
    
    const allButtons = dialog.querySelectorAll('div[role="button"]');
    
    let groupButtons = [];
    allButtons.forEach((button, index) => {
      const buttonText = button.textContent.trim();
      const buttonTextLength = buttonText.length;
      const hasImage = button.querySelector('image, img, svg') !== null;
      
      const isInGroupList = button.closest('[role="listitem"]') !== null;
      const hasGroupIndicator = buttonText.includes('Public group') ||
                               buttonText.includes('Private group') ||
                               buttonText.toLowerCase().includes('members') ||
                               (isInGroupList && (buttonText.includes('Public') || buttonText.includes('Private'))) ||
                               // Non-English UI (v17.7): a listitem row with an avatar is a
                               // group row in any language.
                               (isInGroupList && hasImage);

      if (buttonTextLength > 10 && buttonTextLength < 200 && hasImage && hasGroupIndicator) {
        groupButtons.push({
          element: button,
          text: buttonText,
          index: index
        });
      }
    });
    
    groupButtons.forEach((btn) => {
      let groupName = btn.text.trim();
      
      if (groupName.includes('Public group')) {
        groupName = groupName.split('Public group')[0].trim();
      } else if (groupName.includes('Private group')) {
        groupName = groupName.split('Private group')[0].trim();
      }
      
      const lines = groupName.split('\n').map(l => l.trim()).filter(l => l.length > 0);
      groupName = lines[0];
      
      // The row's /groups/<id>/ link — a stable identity that survives renames and,
      // crucially, tells two groups sharing a display name apart (v15.9). Carried
      // through to the popup so its list, its selections and any preset saved there
      // can distinguish them too; without it the de-dupe below silently dropped one
      // of the two and the popup could never offer both (v18.2).
      const groupId = extractGroupIdFromRow(btn.element);

      // Both identified → the IDs decide, so two same-named groups both get listed.
      // Either one unidentified → fall back to the old name comparison rather than
      // risk listing the same group twice.
      const alreadyListed = groupsWithStatus.some(g =>
        (g.id && groupId) ? g.id === groupId : g.name === groupName);

      if (groupName &&
          groupName.length > 2 &&
          groupName.length < 100 &&
          !groupName.toLowerCase().includes('search') &&
          !groupName.toLowerCase().includes('close') &&
          !groupName.toLowerCase().includes('back') &&
          !groupName.toLowerCase().includes('all groups') &&
          !alreadyListed) {

        const checkbox = btn.element.querySelector('.multi-share-checkbox');
        const isChecked = checkbox ? checkbox.checked : false;

        if (groupId) rememberGroupId(groupName, groupId);

        groupsWithStatus.push({
          name: groupName,
          id: groupId || null,
          checked: isChecked
        });
      }
    });
    
    return groupsWithStatus;
  }

  /**
   * Normalizes a group name for RESILIENT comparison. Facebook is inconsistent about
   * punctuation: the same group can render with a straight apostrophe (') in one
   * surface and a typographic one (’) in another, and row text sometimes contains
   * non-breaking spaces. An exact === on the raw strings then fails for any group
   * whose name contains an apostrophe (the "gave up on the second group" bug).
   * Used only as a FALLBACK after the exact match — never changes a match that
   * already worked.
   */
  /**
   * Strips invisible Unicode control characters Facebook wraps around RTL (Hebrew/
   * Arabic) names: bidi marks (LRM/RLM U+200E/F, ALM, embedding/isolate controls),
   * zero-width spaces/joiners, BOM. They render as NOTHING but break === and even
   * startsWith — the composer chip carries the group name WITH marks while our copy
   * from the row doesn't; the two look identical on screen and compare unequal.
   */
  function stripInvisibleMarks(s) {
    return String(s || '').replace(/[\u200B-\u200F\u061C\u202A-\u202E\u2066-\u2069\uFEFF]/g, '');
  }

  function normalizeGroupNameForMatch(name) {
    return stripInvisibleMarks(name)
      .normalize('NFC')
      .replace(/[\u2018\u2019\u02BC\u0060\u00B4]/g, "'") // curly/backtick apostrophes -> straight '
      .replace(/[\u201C\u201D]/g, '"')                     // curly double quotes -> straight "
      .replace(/\u00A0/g, ' ')                             // non-breaking space -> space
      .replace(/\s+/g, ' ')
      .trim()
      .toLowerCase();
  }

  // --- Group IDENTITY (v15.9): stable IDs instead of display names -------------
  // Every group row's profile-photo link points at the group itself:
  //   <a href="https://www.facebook.com/groups/348703521492868/?__cft__...">
  // The path segment after /groups/ is the numeric group ID (or the group's unique
  // slug, e.g. "sminfluencers") — stable and unique, unlike display names, which can
  // collide or render inconsistently. IDs are captured whenever a row is seen
  // (checkbox save in content_ui_elements.js, and share-time row matching here) into
  // a sessionStorage map keyed by group name, tagged with the FB user id like the
  // selections map (cross-account safety).

  function getFacebookUserIdCore() {
    const match = document.cookie.match(/(?:^|;\s*)c_user=(\d+)/);
    if (!match) return null;
    // Facebook's "switch profile" keeps c_user (the main account) and tracks the
    // active additional profile in i_user — without it, two profiles share one
    // identity and their group inventories/selections bleed into each other.
    const iUser = document.cookie.match(/(?:^|;\s*)i_user=(\d+)/);
    return iUser ? `${match[1]}:${iUser[1]}` : match[1];
  }

  /**
   * Extracts the stable group identifier from a group row (or any element inside it).
   * Returns the numeric ID / slug string, or null if no group link is present
   * (e.g. FB changed the row markup) — callers must treat null as "unknown", never
   * as a match.
   */
  function extractGroupIdFromRow(rowElement) {
    if (!rowElement) return null;
    const scope = rowElement.closest('[role="listitem"]') || rowElement;
    const link = scope.querySelector('a[href*="/groups/"]');
    if (!link) return null;
    const m = (link.getAttribute('href') || '').match(/\/groups\/([^/?&#]+)/);
    return m ? m[1] : null;
  }

  function loadGroupIdMap() {
    try {
      const saved = sessionStorage.getItem('shareUnlimited_groupIds');
      if (!saved) return {};
      const data = JSON.parse(saved);
      const currentUserId = getFacebookUserIdCore();
      if (currentUserId && data.userId && data.userId !== currentUserId) {
        sessionStorage.removeItem('shareUnlimited_groupIds');
        return {};
      }
      return data.ids || {};
    } catch (e) {
      return {};
    }
  }

  /** Merge-saves one groupName → groupId association. No-op if id is null. */
  function rememberGroupId(groupName, groupId) {
    if (!groupName || !groupId) return;
    try {
      const ids = loadGroupIdMap();
      if (ids[groupName] === groupId) return;
      ids[groupName] = groupId;
      sessionStorage.setItem('shareUnlimited_groupIds',
        JSON.stringify({ userId: getFacebookUserIdCore(), ids }));
      console.log(`🆔 Remembered group id: "${groupName}" → ${groupId}`);
    } catch (e) { /* sessionStorage full/blocked — IDs are an enhancement, not required */ }
  }

  /** Returns the known group id for a name, or null if we've never captured one. */
  function getKnownGroupId(groupName) {
    return loadGroupIdMap()[groupName] || null;
  }

  /**
   * Group INVENTORY (v16.1): every group row we have EVER seen (stable id → display
   * name), persisted per FB account in chrome.storage.local — unlike the
   * sessionStorage maps, it survives tab closes. Powers the "Search My Groups"
   * modal: FB's own dialog search returns only ~10 relevance-ranked results, so
   * discovery ("all my Real Estate groups") needs our own index. Rows are recorded
   * from every scan pass (Load All, targeted scrolls, share-time matching) — the
   * index grows organically and one full Load All pass completes it.
   */
  const Inventory = (() => {
    let cache = null;    // { [groupId]: name } for the current FB account
    let cacheUserId = null;
    let saveTimer = null;

    async function load() {
      const uid = getFacebookUserIdCore() || 'unknown';
      if (cache && cacheUserId === uid) return cache;
      const data = await new Promise(res => chrome.storage.local.get(['groupInventory'], res));
      const all = data.groupInventory || {};
      cacheUserId = uid;
      cache = (all[uid] && all[uid].groups) || {};
      return cache;
    }

    function scheduleSave() {
      clearTimeout(saveTimer);
      saveTimer = setTimeout(async () => {
        const data = await new Promise(res => chrome.storage.local.get(['groupInventory'], res));
        const all = data.groupInventory || {};
        all[cacheUserId] = { updatedAt: Date.now(), groups: cache };
        chrome.storage.local.set({ groupInventory: all });
      }, 800); // batch bursts of records into one write
    }

    /** Fire-and-forget: safe to call from sync scan loops. */
    function record(name, groupId) {
      if (!name || !groupId) return;
      load().then(() => {
        if (cache[groupId] === name) return;
        cache[groupId] = name;
        scheduleSave();
      }).catch(() => {});
    }

    /** All known groups for this account: [{id, name}], alphabetical. */
    async function getAll() {
      await load();
      return Object.entries(cache)
        .map(([id, name]) => ({ id, name }))
        .sort((a, b) => a.name.localeCompare(b.name));
    }

    async function getUpdatedAt() {
      const uid = getFacebookUserIdCore() || 'unknown';
      const data = await new Promise(res => chrome.storage.local.get(['groupInventory'], res));
      const entry = (data.groupInventory || {})[uid];
      return entry ? entry.updatedAt : null;
    }

    /**
     * Wipes the current account's inventory (cache + storage). Called at the
     * start of a Load All sweep so the index is REBUILT from what the sweep
     * actually finds — groups left since last time (or seen under another
     * profile before per-profile keying) don't linger in Search My Groups.
     */
    async function reset() {
      const uid = getFacebookUserIdCore() || 'unknown';
      // Snapshot BEFORE wiping: the id→name map we're about to discard is the only
      // record of what each group used to be called, and that's what lets a sync
      // rewrite stale names elsewhere (see reconcileGroupNames).
      const previous = { ...(await load()) };
      clearTimeout(saveTimer);
      cacheUserId = uid;
      cache = {};
      const data = await new Promise(res => chrome.storage.local.get(['groupInventory'], res));
      const all = data.groupInventory || {};
      all[uid] = { updatedAt: Date.now(), groups: {} };
      await new Promise(res => chrome.storage.local.set({ groupInventory: all }, res));
      console.log('🧹 Inventory reset for account', uid);
      return previous;
    }

    return { record, getAll, getUpdatedAt, reset };
  })();

  /**
   * After a sync, rewrite every stored group NAME to whatever that group ID is called
   * now (v17.7).
   *
   * The inventory is keyed by group ID and rebuilt by the sweep, so it heals itself.
   * Three other stores keep names and never did:
   *
   *   1. sessionStorage `shareUnlimited_groupIds`  — keyed BY NAME ({name: id})
   *   2. sessionStorage `shareUnlimited_checkboxSelections` — keyed by id, but the
   *      `name` field inside each entry goes stale
   *   3. chrome.storage.local `groupPresets` — group lists are plain names
   *
   * A group ID is permanent; its name is not. It changes when an admin renames the
   * group, and — the case that motivated this — when the user switches Facebook's
   * language, since the name is read out of localized row markup. Anything still
   * holding the old name silently stops matching that group.
   *
   * @param previousById snapshot returned by Inventory.reset(), i.e. {id: oldName}
   * @returns {Promise<{renamed:number, presets:number, selections:number}>}
   */
  async function reconcileGroupNames(previousById) {
    const stats = { renamed: 0, presets: 0, selections: 0 };
    try {
      const current = await Inventory.getAll();          // [{id, name}] — post-sweep truth
      if (!current.length) return stats;

      const nameById = {};
      const renames = {};                                // oldName -> newName
      for (const { id, name } of current) {
        nameById[id] = name;
        const old = previousById && previousById[id];
        if (old && old !== name) {
          renames[old] = name;
          stats.renamed++;
        }
      }

      // 1) name→id map: rebuild the entries we now know, and drop any OTHER key that
      //    points at the same id (that key is the stale name).
      try {
        const ids = loadGroupIdMap();
        let touched = false;
        for (const [id, name] of Object.entries(nameById)) {
          for (const key of Object.keys(ids)) {
            if (ids[key] === id && key !== name) { delete ids[key]; touched = true; }
          }
          if (ids[name] !== id) { ids[name] = id; touched = true; }
        }
        if (touched) {
          sessionStorage.setItem('shareUnlimited_groupIds',
            JSON.stringify({ userId: getFacebookUserIdCore(), ids }));
        }
      } catch (e) { /* sessionStorage full/blocked — names are a convenience here */ }

      // 2) selections: entries are already id-keyed, so refresh their name by ID
      //    directly. No rename map needed — this also repairs entries whose name was
      //    never right in the first place.
      try {
        const saved = sessionStorage.getItem('shareUnlimited_checkboxSelections');
        if (saved) {
          const data = JSON.parse(saved);
          const sel = data.selections || data.groups || {};
          let touched = false;
          for (const [key, entry] of Object.entries(sel)) {
            if (!entry || typeof entry !== 'object') continue;
            const id = entry.id || (key.startsWith('gid:') ? key.slice(4) : null);
            if (id && nameById[id] && entry.name !== nameById[id]) {
              entry.name = nameById[id];
              touched = true;
              stats.selections++;
            }
          }
          if (touched) sessionStorage.setItem('shareUnlimited_checkboxSelections', JSON.stringify(data));
        }
      } catch (e) { /* selections are a view of storage — never fail a sync over them */ }

      // 3) presets. Entries that carry an ID are refreshed BY ID, exactly like
      //    selections above — that also repairs an entry whose name was never right.
      //    Legacy entries (plain names, no ID) can only be fixed via oldName→newName,
      //    and a preset naming a group whose ID we never saw is left completely alone.
      try {
        const store = await new Promise(res => chrome.storage.local.get(['groupPresets'], res));
        const presets = store.groupPresets || [];
        let touched = false;
        for (const preset of presets) {
          if (!preset || !Array.isArray(preset.groups)) continue;
          preset.groups = preset.groups.map(g => {
            const ref = presetGroupRef(g);
            if (!ref) return g;
            if (ref.id) {
              const fresh = nameById[ref.id];
              if (fresh && fresh !== ref.name) {
                touched = true; stats.presets++;
                return { name: fresh, id: ref.id };
              }
              return g;
            }
            if (renames[ref.name]) {
              touched = true; stats.presets++;
              return typeof g === 'string' ? renames[ref.name] : { ...g, name: renames[ref.name] };
            }
            return g;
          });
        }
        if (touched) {
          await new Promise(res => chrome.storage.local.set({ groupPresets: presets }, res));
        }
      } catch (e) { /* presets live in the popup's store — a failure here is not fatal */ }

      if (stats.renamed || stats.presets || stats.selections) {
        console.log(`♻️ Sync reconciled names — ${stats.renamed} group(s) renamed, ` +
                    `${stats.presets} preset entr(ies), ${stats.selections} selection(s) updated`);
      }
    } catch (e) {
      console.warn('Name reconciliation skipped:', e);
    }
    return stats;
  }

  /**
   * ACTIVE PROFILE IDENTITY (v17.0)
   *
   * Which Facebook profile is in use right now, as {id, name}. `id` is the
   * authoritative value — the same cookie-derived string everything else keys by
   * (getFacebookUserIdCore: c_user, or c_user:i_user when switched to an
   * additional profile). `name` is best-effort and may be null.
   *
   * Why this exists: group membership is per profile, so a saved Group List
   * Preset only works on the profile it was built on. Presets are stamped with
   * this at save time so the preset chooser can tell the user which of their
   * presets actually apply to the profile they're currently on.
   *
   * The name is VERIFIED against the active id before it's trusted: FB embeds a
   * CurrentUserInitialData blob whose USER_ID is the active profile, but stale or
   * additional blobs can describe the main account instead. Labelling a preset
   * with the wrong profile's name is worse than showing no name at all, so a
   * blob whose USER_ID doesn't match the active profile is skipped and callers
   * degrade to "profile not recorded".
   */
  const Profile = (() => {
    const DIRECTORY_KEY = 'fbProfiles';

    function getId() {
      return getFacebookUserIdCore();
    }

    /** Effective active profile id: i_user when switched, else c_user. */
    function activeAccountId() {
      const id = getId();
      return id ? id.split(':').pop() : null;
    }

    function getName() {
      try {
        const activeId = activeAccountId();
        for (const s of document.querySelectorAll('script[type="application/json"]')) {
          const t = s.textContent || '';
          const i = t.indexOf('CurrentUserInitialData');
          if (i === -1) continue;
          const slice = t.slice(i, i + 6000);
          const nameMatch = slice.match(/"NAME":"((?:[^"\\]|\\.)*)"/);
          if (!nameMatch) continue;
          const userMatch = slice.match(/"USER_ID":"(\d+)"/);
          // Blob describes a different profile than the one in use — don't trust it.
          if (activeId && userMatch && userMatch[1] !== activeId) continue;
          const name = JSON.parse(`"${nameMatch[1]}"`).trim();
          if (name) return name;
        }
      } catch (e) {}
      return null;
    }

    function getActive() {
      return { id: getId(), name: getName() };
    }

    /** { [profileId]: { name, updatedAt } } — names for ids we've seen before. */
    async function getDirectory() {
      const data = await new Promise(res => chrome.storage.local.get([DIRECTORY_KEY], res));
      return data[DIRECTORY_KEY] || {};
    }

    /**
     * Records the active profile's display name so that OTHER surfaces (the
     * preset chooser, the popup) can put a human name on a preset saved under a
     * profile the user isn't currently on. Without this, a preset from profile B
     * could only ever be labelled by its numeric id.
     */
    async function remember() {
      const { id, name } = getActive();
      if (!id || !name) return;
      const dir = await getDirectory();
      if (dir[id] && dir[id].name === name) return; // unchanged — skip the write
      dir[id] = { name, updatedAt: Date.now() };
      await new Promise(res => chrome.storage.local.set({ [DIRECTORY_KEY]: dir }, res));
    }

    /** Last-resort label for a profile id we have no name for. */
    function fallbackLabel(id) {
      if (!id) return null;
      return `Profile ···${String(id).split(':').pop().slice(-4)}`;
    }

    return { getId, getName, getActive, getDirectory, remember, fallbackLabel, DIRECTORY_KEY };
  })();

  /**
   * Learns a preset's owning profile from a share that actually WORKED (v17.0).
   *
   * Presets saved before v17.0 carry no profile stamp, and matching their group
   * names against the inventory can only ever be a guess. A completed share is
   * proof: if the post reached at least 70% of a preset's groups from the profile
   * the user is on, those groups demonstrably exist on that profile, so the
   * preset is stamped for real and stops being a guess. Nothing to click, and it
   * fills in one preset at a time as they get used.
   *
   * `sharedNames` holds the NORMALIZED names of groups this run actually posted
   * to. 70% (not 100%) because a preset legitimately drifts — groups get renamed,
   * archived, or left — and demanding perfection would mean the stamp almost
   * never lands. The threshold is well clear of the wrong-profile case, where
   * essentially every group fails with "Group not found in dialog".
   *
   * Never overwrites an existing profileId: a preset that works on two profiles
   * (shared groups) must keep its first, recorded owner rather than flip-flopping
   * with whichever profile used it last.
   */
  /**
   * ---------------------------------------------------------------------------
   * Preset group entries: {name, id} refs, with legacy plain strings tolerated
   * ---------------------------------------------------------------------------
   * Presets used to store bare NAME strings, which made two groups sharing a
   * display name indistinguishable — a preset holding "ABC", "ABC", "Bla" was
   * deduplicated down to two groups long before the share loop ever saw it, and
   * the third group silently never got the post (v18.2).
   *
   * Entries are now `{ name, id }` (id nullable). Every reader goes through the
   * three helpers below so a preset written by any older version keeps working:
   * a string is simply a ref with no id.
   *
   *   presetGroupName(entry)  -> display name
   *   presetGroupRef(entry)   -> {name, id}
   *   presetGroupKey(ref)     -> identity key for dedupe/lookup
   *
   * `presetGroupKey` is the important one: it is the group ID when we have it and
   * only falls back to the normalized name when we don't, so two same-named
   * groups collapse ONLY while their IDs are genuinely unknown.
   */
  function presetGroupName(entry) {
    if (!entry) return '';
    if (typeof entry === 'string') return entry;
    return String(entry.name || '');
  }

  function presetGroupRef(entry) {
    const name = presetGroupName(entry);
    if (!name) return null;
    const id = (entry && typeof entry === 'object' && entry.id) ? String(entry.id) : null;
    return { name, id };
  }

  function presetGroupRefs(preset) {
    const list = Array.isArray(preset) ? preset : (preset && preset.groups) || [];
    return list.map(presetGroupRef).filter(Boolean);
  }

  function presetGroupKey(ref) {
    if (!ref) return '';
    if (typeof ref === 'string') return 'nm:' + normalizeGroupNameForMatch(ref);
    return ref.id ? 'id:' + ref.id : 'nm:' + normalizeGroupNameForMatch(ref.name || '');
  }

  /**
   * Deduplicates preset entries BY IDENTITY (id when known, normalized name
   * otherwise) and returns {name, id} refs in first-seen order.
   *
   * Used wherever preset lists are merged or counted. Never dedupe preset groups
   * with a plain `new Set()` of names again — that is exactly the bug this
   * exists to prevent.
   */
  function dedupePresetRefs(entries) {
    const seen = new Set();
    const out = [];
    presetGroupRefs(entries).forEach(ref => {
      const key = presetGroupKey(ref);
      if (seen.has(key)) return;
      seen.add(key);
      out.push(ref);
    });
    return out;
  }

  /**
   * Builds `(preset) => [{name, id}]`, recovering group IDs for LEGACY entries.
   *
   * Presets saved before v18.2 hold plain names, so two entries both reading
   * "ABC" are indistinguishable on their face — which is how a three-group preset
   * ended up posting to two groups. The inventory is ID-keyed and does know both,
   * so a legacy name is resolved against it CONSUMING one candidate per entry:
   * two "ABC" entries take the two different ABC groups rather than both pointing
   * at whichever came first.
   *
   * Which entry gets which ID is arbitrary and that is fine — the result is a SET
   * of groups to post to, and either assignment describes the same set. Nothing is
   * written back to storage: the inventory changes as the user joins and leaves
   * groups, so this stays a read-time recovery, never a stamp (same rule as
   * inferred preset profiles). Re-saving the preset is what makes IDs permanent.
   *
   * Entries that already carry an ID are returned untouched; a name with no
   * inventory hit keeps `id: null` and is matched by name exactly as before.
   */
  function makePresetRefResolver(inventory) {
    const byNorm = new Map();
    (inventory || []).forEach(g => {
      if (!g || !g.name) return;
      const k = normalizeGroupNameForMatch(g.name);
      if (!byNorm.has(k)) byNorm.set(k, []);
      byNorm.get(k).push(g);
    });
    return (preset) => {
      const consumed = new Map();   // normalized name -> candidates handed out so far
      return presetGroupRefs(preset).map(ref => {
        if (ref.id) return ref;
        const k = normalizeGroupNameForMatch(ref.name);
        const candidates = byNorm.get(k) || [];
        const taken = consumed.get(k) || 0;
        consumed.set(k, taken + 1);
        const hit = candidates[taken];
        return hit ? { name: hit.name, id: hit.id } : ref;
      });
    };
  }

  /** One preset's groups as refs, loading the inventory only if it's needed. */
  async function resolvePresetGroupRefs(preset) {
    const refs = presetGroupRefs(preset);
    if (!refs.length || refs.every(r => r.id)) return refs;
    let inventory = [];
    try {
      inventory = await Inventory.getAll();
    } catch (e) {
      // No inventory yet — legacy entries keep matching by name, as before.
    }
    return makePresetRefResolver(inventory)(preset);
  }

  async function recordPresetProfileFromRun(sourcePresetIds, sharedNames) {
    try {
      if (!Array.isArray(sourcePresetIds) || sourcePresetIds.length === 0) return;
      if (!sharedNames || sharedNames.size === 0) return;

      const profile = Profile.getActive();
      if (!profile.id) return; // can't read the cookie — nothing to attribute to

      const stored = await new Promise(res => chrome.storage.local.get(['groupPresets'], res));
      const presets = stored.groupPresets || [];
      let changed = false;

      presets.forEach(preset => {
        if (!preset || !sourcePresetIds.includes(preset.id)) return;
        if (preset.profileId) return; // already known — first stamp wins

        // Scored over UNIQUE names: `sharedNames` is name-keyed, so two same-named
        // groups in the list would otherwise both count as hits when only one of
        // them was actually delivered to, inflating the rate past the threshold.
        const names = Array.from(new Set(
          presetGroupRefs(preset)
            .map(ref => normalizeGroupNameForMatch(ref.name))
            .filter(Boolean)
        ));
        if (!names.length) return;

        const hits = names.filter(n => sharedNames.has(n)).length;
        const rate = hits / names.length;
        if (rate < 0.7) {
          console.log(`ℹ️ Preset "${preset.name}": ${hits}/${names.length} groups shared — below 70%, not stamping a profile.`);
          return;
        }

        preset.profileId = profile.id;
        preset.profileName = profile.name || null;
        preset.profileConfirmedAt = new Date().toISOString();
        changed = true;
        console.log(`✅ Preset "${preset.name}" confirmed on profile ${profile.name || profile.id} (${hits}/${names.length} groups shared).`);
      });

      if (changed) {
        await new Promise(res => chrome.storage.local.set({ groupPresets: presets }, res));
      }
    } catch (e) {
      // Attribution is a nicety — it must never affect the share's outcome.
      console.warn('Preset profile attribution skipped:', e);
    }
  }

  /**
   * Finds a group element by name in the current dialog.
   *
   * ID-FIRST, then TWO-PASS name matching: exact wins over fuzzy across the WHOLE list, not per row.
   * The old version accepted (exact || normalized) in a single DOM-order walk, so a
   * similar-named row mounted ABOVE the target — which the v15.5 search box produces
   * constantly, since FB orders results by relevance — could win via the
   * case-insensitive normalized fallback even though the exactly-matching row was
   * present further down. That clicked the WRONG group (posted to the same group
   * repeatedly while the UI showed green). Now:
   *   Pass 0 — group ID (when we've captured one for this name): matched against the
   *            row's /groups/<id>/ link. Unique and case-proof — this is THE match.
   *   Pass 1 — character-exact, case-sensitive match, checked against EVERY row first.
   *   Pass 2 — normalized fallback (apostrophe/quote/nbsp/case, v15.4) ONLY when no
   *            row matched exactly, so FB's inconsistent punctuation still resolves.
   * When an expected ID is known, passes 1 and 2 REJECT any row whose own ID is
   * present but different — a name match on the wrong group is never accepted.
   */
  function findGroupElementByName(groupName, quiet = false, exactOnly = false, targetId = null) {
    if (!quiet) console.log(`🔍 Searching for group: "${groupName}"${targetId ? ` (id ${targetId})` : ''}`);
    const targetNormalized = normalizeGroupNameForMatch(groupName);

    const dialog = findShareDialog();

    if (!dialog) {
      if (!quiet) console.error('❌ No share-to-group dialog found - group selection dialog is not open!');
      return null;
    }

    // Collect candidate rows and their extracted names once, then match in two passes.
    const candidates = [];
    const allButtons = dialog.querySelectorAll('div[role="button"]');

    for (const button of allButtons) {
      const buttonText = button.textContent.trim();
      const buttonTextLength = buttonText.length;
      const hasImage = button.querySelector('image, img, svg') !== null;

      if (buttonTextLength > 10 && buttonTextLength < 200 && hasImage) {
        let extractedName = buttonText.trim();

        const hadEnglishSubtitle = extractedName.includes('Public group') ||
                                   extractedName.includes('Private group');
        if (extractedName.includes('Public group')) {
          extractedName = extractedName.split('Public group')[0].trim();
        } else if (extractedName.includes('Private group')) {
          extractedName = extractedName.split('Private group')[0].trim();
        }

        // Non-English UI (v17.7): the strip above is English, so a translated row kept
        // its subtitle glued on ("A test groupקבוצה ציבורית") — which then failed every
        // later comparison AND got written into the inventory under that broken name.
        // Name and subtitle are separate spans, so read the first LEAF span instead.
        if (!hadEnglishSubtitle) {
          const fromSpan = Struct.groupNameFromRow(button);
          if (fromSpan && fromSpan.length < extractedName.length) {
            extractedName = fromSpan;
          }
        }

        const lines = extractedName.split('\n').map(l => l.trim()).filter(l => l.length > 0);
        extractedName = lines[0];

        if (extractedName) {
          const rowId = extractGroupIdFromRow(button);
          candidates.push({ button, extractedName, id: rowId });
          Inventory.record(extractedName, rowId); // grow the searchable index as we go
        }
      }
    }

    // PASS 0 — group ID. An explicit targetId (from an ID-keyed selection) wins over
    // the name→id map, which can only hold ONE id per name and is therefore ambiguous
    // when two groups share a display name.
    const expectedId = targetId || getKnownGroupId(groupName);
    if (expectedId) {
      const idMatch = candidates.find(c => c.id === expectedId);
      if (idMatch) {
        console.log(`  ✅ FOUND by group ID ${expectedId}: "${idMatch.extractedName}"`);
        return idMatch.button;
      }
    }
    // A row's name match is only trusted if its ID doesn't CONTRADICT the expected
    // one. id === null (markup changed / no link) is "unknown", not a contradiction.
    const idCompatible = c => !expectedId || !c.id || c.id === expectedId;

    // PASS 1 — exact, case-sensitive.
    const exactMatches = candidates.filter(c => c.extractedName === groupName && idCompatible(c));
    if (exactMatches.length > 0) {
      if (exactMatches.length > 1) {
        console.warn(`⚠️ ${exactMatches.length} rows share the EXACT name "${groupName}" — picking the first. Select the group via its checkbox once so its ID gets captured.`);
      }
      if (expectedId) {
        console.warn(`  ⚠️ Expected group ID ${expectedId} not among mounted rows — accepting exact-name row with unknown ID`);
      }
      console.log(`  ✅ FOUND exact match: ${exactMatches[0].extractedName}`);
      rememberGroupId(groupName, exactMatches[0].id);
      return exactMatches[0].button;
    }

    // PASS 2 — punctuation/case-tolerant fallback, only because nothing matched exactly.
    // Skipped entirely in exactOnly mode (used while search results are still mounting,
    // where a fuzzy sibling can appear a tick before the exact row does).
    if (exactOnly) {
      if (!quiet) console.log(`  (exact-only mode) no exact match for "${groupName}" yet`);
      return null;
    }
    const fuzzyMatches = candidates.filter(c => normalizeGroupNameForMatch(c.extractedName) === targetNormalized && idCompatible(c));
    if (fuzzyMatches.length > 0) {
      console.warn(`  ⚠️ No exact match for "${groupName}" — normalized fallback matched: "${fuzzyMatches[0].extractedName}"`);
      rememberGroupId(groupName, fuzzyMatches[0].id);
      return fuzzyMatches[0].button;
    }

    if (!quiet) console.error(`❌ Could not find group "${groupName}"`);
    return null;
  }

  /**
   * True when the element is actually rendered on screen (has layout boxes and
   * isn't visibility:hidden). FB keeps previous share-flow screens MOUNTED as
   * hidden sibling dialogs, so any document-wide scan must skip invisible
   * elements or a stale copy of a button wins over the real, clickable one.
   */
  function isElementVisible(el) {
    if (!el || !el.getClientRects().length) return false;
    const style = window.getComputedStyle(el);
    return style.visibility !== 'hidden' && style.display !== 'none';
  }

  /**
   * Scans the currently-open share menu/dialog for the "Group" / "Share to a group"
   * option and returns the matching element (or null). Pure DOM read — no clicking —
   * so it can be re-run cheaply after revealing more items (e.g. after "More options").
   *
   * Candidates are RANKED, best rank wins (document order breaks ties). Exact
   * matches MUST beat the loose aria fallback: the newer share sheet's circular
   * "Group" icon is aria-label="Share to a group" with span text "Group", while
   * stale hidden screens can leave empty-text elements whose aria-label merely
   * CONTAINS "group" — the old first-match-in-document-order scan clicked those
   * dead elements and the sheet just sat there ("stuck on the Share sheet" bug,
   * which made every remaining group in the run report "couldn't be found").
   */
  function findGroupOptionInMenu() {
    const menuItems = document.querySelectorAll('div[role="button"], div[role="menuitem"], div[role="option"]');

    let best = null;
    let bestRank = Infinity;

    for (const item of menuItems) {
      if (item.dataset.multiGroupButton === 'true') continue;
      if (!isElementVisible(item)) continue;

      const text = item.textContent.trim();
      if (text.includes('Public group') || text.includes('Private group')) continue;

      const ariaLabel = (item.getAttribute('aria-label') || '').trim();
      const ariaLower = ariaLabel.toLowerCase();
      const spanExact = Array.from(item.querySelectorAll('span'))
        .some(s => s.textContent.trim() === 'Group' || s.textContent.trim() === 'Share to a group');

      let rank;
      if (ariaLabel === 'Share to a group' || ariaLabel === 'Group') {
        rank = 0;
      } else if (spanExact || text === 'Group' || text === 'Share to a group') {
        rank = 1;
      } else if (text.startsWith('Group') && text.length < 30) {
        rank = 2;
      } else if (ariaLower.includes('group') &&
                 !ariaLower.includes('public group') && !ariaLower.includes('private group')) {
        rank = 3;
      } else {
        continue;
      }

      if (rank < bestRank) {
        best = item;
        bestRank = rank;
        if (rank === 0) break;
      }
    }

    // Non-English UI (v17.7): every rank above is English text, so a translated share
    // sheet matches nothing at all. Fall back to the tile's ICON, which is the same
    // sprite offset in every locale. Runs only when the English scan came up empty,
    // so working accounts never reach it.
    if (!best) {
      const byIcon = Struct.findGroupOptionByIcon();
      if (byIcon) {
        console.log('🌍 Found Group option by icon (non-English UI)');
        return byIcon;
      }
    }

    return best;
  }

  /**
   * The GOAL check for the "open the group picker" step: a VISIBLE dialog that
   * actually contains the group-picking UI (the "Search for groups" box or the
   * "Share to a group" heading). "A dialog exists" is NOT readiness — the share
   * sheet itself is a dialog, and hidden previous screens stay mounted.
   */
  function isGroupPickerReady() {
    const dialogs = document.querySelectorAll('div[role="dialog"]');
    for (const d of dialogs) {
      if (!isElementVisible(d)) continue;
      if (d.querySelector('input[type="search"], input[aria-label="Search for groups"], input[placeholder="Search for groups"]')) {
        return d;
      }
      const hasHeading = Array.from(d.querySelectorAll('h2, h3')).some(h => {
        const t = h.textContent.trim();
        const span = h.querySelector('span');
        return t === 'Share to a group' || (span && span.textContent.trim() === 'Share to a group');
      });
      if (hasHeading) return d;

      // Non-English UI (v17.7): the heading is translated, but a dialog holding a
      // search box AND group rows can only be the picker.
      if (Struct.findGroupSearchInput(d) && d.querySelector('div[role="listitem"]')) {
        return d;
      }
    }
    return null;
  }

  /**
   * NEW UI variant: some Facebook layouts hide "Share to a group" behind a "More options"
   * item in the share menu. If that item is present, click it so the group option becomes
   * visible. Returns true if a "More options" item was found and clicked.
   *
   * Without this, clicking Multi-Group lands on a menu that only has "More options" (no
   * direct "Share to a group"), so the group dialog never opens and the automation only
   * ever manages to share to a single group.
   */
  async function clickMoreOptionsIfPresent() {
    const menuItems = document.querySelectorAll('div[role="button"], div[role="menuitem"], div[role="option"]');

    for (const item of menuItems) {
      if (item.dataset.multiGroupButton === 'true') continue;
      const text = item.textContent.trim();
      const ariaLabel = (item.getAttribute('aria-label') || '').trim();
      const spanMatch = Array.from(item.querySelectorAll('span'))
        .some(s => s.textContent.trim() === 'More options');

      // Exact matches only — avoid grabbing unrelated "..." overflow menus on the post.
      if (text === 'More options' || ariaLabel === 'More options' || spanMatch) {
        console.log('Found "More options" item — clicking to reveal "Share to a group"...');
        item.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
        item.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
        await clickElement(item);
        await sleep(1500);
        return true;
      }
    }

    return false;
  }

  /**
   * Finds and clicks the "Group" option in the share menu, then VERIFIES the
   * group picker actually opened before returning true.
   *
   * Poll for the GOAL (isGroupPickerReady), not for "clicked something": the old
   * version returned true as soon as it clicked ANY matching element, so when the
   * click hit a dead/stale element the whole share loop ran against the still-open
   * Share sheet — no search box, no scrollable list, every remaining group
   * reported "couldn't be found". Re-clicks at most every 1.5s so a swallowed
   * click gets retried (by then the ranked scan may also surface a better,
   * now-mounted candidate).
   */
  async function clickShareToGroupOption() {
    console.log('Looking for "Group" option in share menu...');
    Ghost.say('groupMenu');
    await sleep(500);

    let triedMoreOptions = false;
    let lastClickAt = -Infinity;

    // `waited` is REAL elapsed time, not a tick count: the work inside the loop
    // (clickElement, which now also plays the ghost-cursor travel) takes longer
    // than the 250ms sleep, so counting ticks would silently stretch this 10s
    // budget — and a group that can never open its picker would take twice as
    // long to fail.
    const startedAt = Date.now();
    for (let waited = 0; waited < 10000; waited = Date.now() - startedAt) {
      const picker = isGroupPickerReady();
      if (picker) {
        console.log('✅ Group picker is open (search box / "Share to a group" heading present)');
        return true;
      }

      const item = findGroupOptionInMenu();
      if (item && waited - lastClickAt >= 1500) {
        console.log('Found Group option, clicking:',
          `text="${item.textContent.trim().substring(0, 40)}"`,
          `aria-label="${(item.getAttribute('aria-label') || '').substring(0, 40)}"`);
        item.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
        item.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
        await clickElement(item);
        lastClickAt = waited;
      } else if (!item && !triedMoreOptions && waited >= 3000) {
        // NEW UI variant: "Share to a group" can be nested behind a "More options"
        // item. Only reach for it when no direct option is visible.
        triedMoreOptions = await clickMoreOptionsIfPresent();
        if (triedMoreOptions) {
          console.log('Re-scanning for "Group" option after opening "More options"...');
        }
      }

      await sleep(250);
    }

    console.error('❌ Group picker did not open within 10s — no working "Group" option (share sheet may have changed)');
    return false;
  }

  /**
   * Re-opens the share dialog by clicking Share button and then "Group"
   * @param {string} targetGroupName - Optional group name to search for during lazy load
   */
  async function reopenShareDialog(targetGroupName = null, targetGroupId = null) {
    if (targetGroupName) {
      console.log(`Attempting to reopen share dialog (target group: "${targetGroupName}")...`);
    } else {
      console.log('Attempting to reopen share dialog...');
    }
    
    const closeButtons = document.querySelectorAll('div[aria-label*="Close"], div[aria-label*="close"]');
    for (const btn of closeButtons) {
      // Visible buttons only — hidden previous share screens stay mounted with
      // their own Close buttons, and clicking one of those leaves the real
      // dialog (e.g. a stuck share sheet from a failed group) open.
      if (isElementVisible(btn) && btn.closest('div[role="dialog"]')) {
        console.log('Closing existing dialog...');
        await clickElement(btn);
        await sleep(1000);
        break;
      }
    }
    
    // FAIL-SAFE: during an active multi-group share we must reopen the SAME listing's
    // dialog. Prefer the explicitly pinned target (set when the user clicked Multi-Group).
    // If that pinned button is no longer in the DOM, ABORT rather than fall back to a
    // whole-page scan that could grab a different visible listing — sharing the wrong
    // listing has gotten users removed from groups, so failing this group is the safer
    // outcome.
    let shareButton = document.querySelector('[data-share-unlimited-target="true"]');
    if (shareButton && (!document.body.contains(shareButton) || shareButton.dataset.multiGroupButton === 'true')) {
      shareButton = null;
    }
    if (!shareButton) {
      console.error('❌ Pinned Share button is no longer available — aborting reopen to avoid sharing the WRONG listing.');
      return false;
    }

    // Scroll the share button into view so click events register correctly
    try { shareButton.scrollIntoView({ behavior: 'instant', block: 'center' }); } catch(e) {}
    await sleep(300);

    console.log('Clicking Share button...');
    Ghost.say('reopen');
    await clickElement(shareButton);
    await sleep(1500);

    // New Facebook UI: the combined share dialog already shows the groups list inline.
    // Detect "Share to a group" heading — if present, skip the old "click Group option" step.
    const dialogAfterClick = findShareDialog();
    const hasGroupsDirectly = dialogAfterClick && Array.from(dialogAfterClick.querySelectorAll('h2, h3')).some(h2 => {
      const text = h2.textContent.trim();
      const span = h2.querySelector('span');
      return text === 'Share to a group' || (span && span.textContent.trim() === 'Share to a group');
    });

    if (hasGroupsDirectly) {
      console.log('✅ New combined Share dialog detected — groups visible, skipping "Group" option click');
      await sleep(1000);
      await scrollToLoadAllGroups(null, targetGroupName, targetGroupId);
      console.log('Share dialog reopened successfully');
      return true;
    }

    const success = await clickShareToGroupOption();
    if (success) {
      await sleep(2000);
      await scrollToLoadAllGroups(null, targetGroupName, targetGroupId);
      console.log('Share dialog reopened successfully');
      return true;
    }

    return false;
  }

  /**
   * Finds the scrollable container holding the group list inside the dialog.
   * Three strategies (in order): largest element with overflow auto/scroll that
   * genuinely overflows; walk up from a group row looking for overflow auto/scroll;
   * new-UI fallback — walk up from a row and take the first ancestor whose content
   * overflows regardless of overflow style (custom scrollbars are overflow:hidden
   * but still programmatically scrollable via scrollTop). Falls back to the dialog
   * itself (scrolling may be a no-op there, callers detect lack of progress).
   */
  function findGroupListScrollContainer(dialog) {
    const scrollableElements = dialog.querySelectorAll('*');
    let scrollContainer = null;
    let maxScrollHeight = 0;

    for (const el of scrollableElements) {
      const style = window.getComputedStyle(el);
      const isScrollable = (style.overflowY === 'auto' || style.overflowY === 'scroll' || style.overflow === 'auto' || style.overflow === 'scroll');

      if (isScrollable && el.scrollHeight > el.clientHeight) {
          if (el.scrollHeight > maxScrollHeight) {
              maxScrollHeight = el.scrollHeight;
              scrollContainer = el;
          }
      }
    }

    if (!scrollContainer) {
      const groupButton = dialog.querySelector('div[role="button"]');
      if (groupButton) {
          let parent = groupButton.parentElement;
          while (parent && parent !== dialog) {
              const style = window.getComputedStyle(parent);
               if (style.overflowY === 'auto' || style.overflowY === 'scroll') {
                   scrollContainer = parent;
                   break;
               }
               parent = parent.parentElement;
          }
      }
    }

    if (!scrollContainer) {
      const listItem = dialog.querySelector('[role="listitem"], div[role="list"] div[role="button"]');
      let parent = listItem ? listItem.parentElement : null;
      while (parent && parent !== dialog) {
        if (parent.scrollHeight > parent.clientHeight + 10) {
          scrollContainer = parent;
          console.log('📜 Using overflow-hidden scroll container fallback');
          break;
        }
        parent = parent.parentElement;
      }
    }

    if (!scrollContainer) {
      scrollContainer = dialog;
      console.warn('⚠️ No scrollable container detected — falling back to the dialog itself (scrolling may not move)');
    }

    return scrollContainer;
  }

  /**
   * Scrolls through the CURRENT (search-filtered) results list hunting for an EXACT
   * match. FB's group search matches loosely — a query like "Real Estate" can return
   * 30+ groups, and the exact one may sit below the ~20 virtualized rows that mount
   * initially. Exact-only on purpose: accepting the normalized fallback mid-scroll
   * would re-introduce the wrong-group bug (a fuzzy sibling above the exact target
   * would win before the target ever mounts).
   */
  async function scrollSearchResultsForExactMatch(dialog, targetGroupName, targetGroupId = null) {
    const scrollContainer = findGroupListScrollContainer(dialog);
    const SCROLL_STEP = 300;
    let lastBottomRowText = '';
    let noProgress = 0;
    const maxIterations = 60;

    for (let i = 0; i < maxIterations && noProgress < 3; i++) {
      if (findGroupElementByName(targetGroupName, true, true, targetGroupId)) {
        console.log(`✅ Exact match for "${targetGroupName}" found while scrolling search results (iteration ${i})`);
        return true;
      }

      const prevTop = scrollContainer.scrollTop;
      scrollContainer.scrollTop = prevTop + SCROLL_STEP;
      scrollContainer.dispatchEvent(new Event('scroll', { bubbles: true, cancelable: false }));
      await sleep(700);

      // scrollTop had no effect — custom scroller or genuine bottom. Nudge the last
      // row into view; at a true bottom this is a no-op.
      if (scrollContainer.scrollTop <= prevTop) {
        const rows = dialog.querySelectorAll('[role="listitem"]');
        if (rows.length) {
          try { rows[rows.length - 1].scrollIntoView({ block: 'end', behavior: 'instant' }); } catch (e) {}
          await sleep(500);
        }
      }

      // Progress = scrollTop moved OR the bottom row changed (virtualized list advanced).
      const rowsAfter = dialog.querySelectorAll('[role="listitem"]');
      const bottomRowText = rowsAfter.length ? rowsAfter[rowsAfter.length - 1].textContent : '';
      const advanced = scrollContainer.scrollTop > prevTop ||
        (bottomRowText && bottomRowText !== lastBottomRowText);
      lastBottomRowText = bottomRowText;
      noProgress = advanced ? 0 : noProgress + 1;
    }

    // Final check at wherever scrolling stopped.
    return !!findGroupElementByName(targetGroupName, true, true, targetGroupId);
  }

  /**
   * Search-first group lookup (v15.5): types the target name into the share dialog's
   * "Search for groups" box so Facebook filters/mounts the matching rows directly —
   * no scrolling through the whole virtualized list. Returns true once the target row
   * is in the DOM. On SUCCESS the search text is deliberately LEFT in the box so the
   * caller's findGroupElementByName() still sees the filtered row (clearing it would
   * unmount the row again); the box resets naturally when the dialog reopens for the
   * next group. On failure the box IS cleared so the scroll fallback gets the full list.
   */
  async function searchForGroupInDialog(dialog, targetGroupName, targetGroupId = null) {
    const searchInput = dialog.querySelector(
      'input[type="search"], input[aria-label="Search for groups"], input[placeholder="Search for groups"]'
    );
    if (!searchInput) {
      console.log('🔎 No search box in this dialog — falling back to scrolling');
      return false;
    }

    // Query order matters (RTL fix): names extracted from row text can carry
    // invisible bidi marks/overrides, emoji and doubled spaces
    // ("צלמים מתחילים  📷"). Typing that raw makes the search box render the text
    // scrambled/backwards (bidi override chars!) and FB search returns NOTHING.
    // So the CLEANED query (marks + emoji stripped, whitespace collapsed) goes
    // FIRST; the raw name is the fallback for the rare name where the emoji is
    // load-bearing. The ID/normalized matcher confirms whatever row mounts.
    const words = targetGroupName.trim().split(/\s+/);
    const cleaned = stripInvisibleMarks(targetGroupName)
      .replace(/\p{Extended_Pictographic}/gu, '')
      .replace(/\s+/g, ' ')
      .trim();
    const queries = [];
    if (cleaned && cleaned !== targetGroupName) queries.push(cleaned);
    queries.push(targetGroupName);
    if (words.length > 4) queries.push(words.slice(0, 4).join(' '));

    for (const query of queries) {
      // Reveal any invisible bidi/zero-width chars as \uXXXX so the log shows WHY a
      // query looks fine but searches as garbage.
      const revealed = query.replace(/[\u200B-\u200F\u061C\u202A-\u202E\u2066-\u2069\uFEFF]/g,
        c => '\\u' + c.charCodeAt(0).toString(16).padStart(4, '0'));
      console.log(`🔎 Typing into group search box: "${revealed}"`);
      Ghost.say('searching', { name: targetGroupName });
      await fillNativeInput(searchInput, query);

      // FB debounces the search and fetches results — poll for the first batch.
      // EXACT match only while polling: results mount in relevance order, so a
      // similar-named group can appear a tick before the exact one — accepting the
      // normalized fallback here selected (and posted to) the WRONG group.
      for (let waited = 0; waited < 2500; waited += 500) {
        await sleep(500);
        if (findGroupElementByName(targetGroupName, true, true, targetGroupId)) {
          console.log(`✅ "${targetGroupName}" mounted via search (exact match) — no scrolling needed`);
          return true;
        }
      }

      // Not in the first screenful — FB search matches loosely (e.g. "Real Estate"
      // can return 30+ groups), so the exact row may be below the ~20 virtualized
      // rows. Scroll through the filtered results, still exact-only.
      if (await scrollSearchResultsForExactMatch(dialog, targetGroupName, targetGroupId)) {
        return true;
      }

      // Exact search + scroll exhausted for this query — results have settled, so
      // allow ONE normalized-fallback check at the current scroll position
      // (apostrophe/nbsp variants can never match exactly).
      if (findGroupElementByName(targetGroupName, true, false, targetGroupId)) {
        console.log(`✅ "${targetGroupName}" mounted via search (normalized fallback)`);
        return true;
      }
    }

    console.log('🔎 Search did not surface the group — clearing box for scroll fallback');
    await fillNativeInput(searchInput, '');
    await sleep(800);
    return false;
  }

  /**
   * Scrolls down in the groups list to trigger lazy loading.
   * When targetGroupName is given, tries the SEARCH BOX first (v15.5) and only
   * falls back to scrolling if search doesn't surface the group.
   * @param {Function} onScrollCallback - Optional callback to run after each scroll
   * @param {string} targetGroupName - Optional group name to search for; stops early if found
   */
  /**
   * @param {function|null} shouldAbort optional predicate polled once per pass. Returning
   *   true stops the sweep cleanly at the next iteration boundary and returns whatever
   *   was discovered so far. Used by the first-run setup modal's "Not now" button —
   *   the user must be able to stop us mid-scroll, and the only prior way out was
   *   closing Facebook's dialog (v18.2).
   */
  async function scrollToLoadAllGroups(onScrollCallback = null, targetGroupName = null, targetGroupId = null, onProgress = null, shouldAbort = null) {
    if (targetGroupName) {
      console.log(`Scrolling to load groups (searching for: "${targetGroupName}")...`);
    } else {
      console.log('Scrolling to load all groups...');
    }

    const dialog = findShareDialog();
    if (!dialog) {
      console.warn('No group selection dialog found for scrolling');
      return;
    }

    // SEARCH-FIRST: only when hunting a specific group (a plain "load everything"
    // pass, e.g. for checkbox injection, still needs the real scroll below).
    if (targetGroupName) {
      const foundViaSearch = await searchForGroupInDialog(dialog, targetGroupName, targetGroupId);
      if (foundViaSearch) return;
      // Search came up empty and we're about to grind through the whole list —
      // the slowest step in a run, so the bubble has to account for it.
      Ghost.say('scrolling');
    }

    const scrollContainer = findGroupListScrollContainer(dialog);

    // Scroll in 300px increments so IntersectionObserver lazy-load sentinels
    // fire gradually. Jumping straight to scrollHeight only triggers the observer
    // once and misses loads on personal profiles.
    const SCROLL_STEP = 300;
    let lastScrollHeight = scrollContainer.scrollHeight;
    let noChangeCount = 0;
    let lastBottomRowText = '';
    const maxIterations = 100;

    // DISCOVERY-BASED terminator (v15.9 "Load All never stops" fix). The scroll
    // heuristics below (scrollTop moved / bottom row changed) are fooled by the
    // virtualized list AND by the user scrolling manually — re-mounted rows look
    // like "progress", so the loop ran its full 100 iterations while dragging the
    // user's scroll position back down every second. Instead, track the UNIQUE
    // groups seen so far (by row ID, name text as fallback): if 3 consecutive
    // passes discover nothing new, every group has been loaded — stop, no matter
    // what scrollTop is doing.
    const seenRowKeys = new Set();
    const collectNewRowKeys = () => {
      let added = 0;
      dialog.querySelectorAll('[role="listitem"]').forEach(row => {
        const rowId = extractGroupIdFromRow(row);
        const key = rowId || (row.textContent || '').trim().slice(0, 80);
        if (key && !seenRowKeys.has(key)) { seenRowKeys.add(key); added++; }
        if (rowId) {
          const nm = extractAndValidateGroupName((row.textContent || '').trim(), row);
          if (nm) Inventory.record(nm, rowId); // feed the searchable index
        }
      });
      return added;
    };
    // Live discovery reporting (v16.4) — powers the first-run setup modal's
    // "N groups loaded…" counter. Never let a listener error kill the sweep.
    const reportProgress = () => {
      if (!onProgress) return;
      try { onProgress(seenRowKeys.size); } catch (e) {}
    };
    collectNewRowKeys(); // count the initial screenful
    reportProgress();
    let noNewRowsCount = 0;

    for (let i = 0; i < maxIterations; i++) {
      // The user can close the dialog mid-load — don't keep scrolling a corpse.
      if (!document.body.contains(dialog)) {
        console.log('⏹️ Dialog closed — stopping group loading');
        return seenRowKeys.size;
      }

      // The user asked us to stop. Return what we found rather than nothing, so the
      // caller can decide what to do with a partial pass.
      if (shouldAbort) {
        let abort = false;
        try { abort = !!shouldAbort(); } catch (e) { /* a broken predicate must not trap the loop */ }
        if (abort) {
          console.log('⏹️ Sweep cancelled by the user — stopping group loading');
          return seenRowKeys.size;
        }
      }

      if (targetGroupName) {
        const foundElement = findGroupElementByName(targetGroupName, false, false, targetGroupId);
        if (foundElement) {
          console.log(`✅ Target group "${targetGroupName}" found at iteration ${i}. Stopping.`);
          scrollContainer.scrollTop = 0;
          return;
        }
      }

      const prevScrollTop = scrollContainer.scrollTop;
      scrollContainer.scrollTop = prevScrollTop + SCROLL_STEP;
      scrollContainer.dispatchEvent(new Event('scroll', { bubbles: true, cancelable: false }));
      await sleep(1000);

      if (onScrollCallback) {
        try {
          const count = onScrollCallback();
          if (count > 0) console.log(`  Iteration ${i}: +${count} new group items`);
        } catch (e) {
          console.error('Error in scroll callback:', e);
        }
      }

      const newScrollTop = scrollContainer.scrollTop;
      const newScrollHeight = scrollContainer.scrollHeight;
      const didMove = newScrollTop > prevScrollTop;

      if (!didMove) {
        // scrollTop had no effect — either genuine bottom, or a custom scroller that
        // ignores scrollTop. Nudge the last rendered row into view: scrollIntoView
        // moves whichever ancestor actually scrolls. At a genuine bottom it's a no-op,
        // so the termination logic below is unaffected.
        const rows = dialog.querySelectorAll('[role="listitem"]');
        if (rows.length) {
          try { rows[rows.length - 1].scrollIntoView({ block: 'end', behavior: 'instant' }); } catch (e) {}
          await sleep(600);
        }

        // If the nudge revealed different rows (virtualized list advanced), that's
        // real progress even though scrollContainer.scrollTop never moved.
        const rowsAfter = dialog.querySelectorAll('[role="listitem"]');
        const bottomRowText = rowsAfter.length ? rowsAfter[rowsAfter.length - 1].textContent : '';
        if (bottomRowText && bottomRowText !== lastBottomRowText) {
          lastBottomRowText = bottomRowText;
          noChangeCount = 0;
          console.log('📜 List advanced via scrollIntoView nudge');
        } else if (newScrollHeight <= lastScrollHeight) {
          // Reached the bottom of currently loaded content
          noChangeCount++;
          if (noChangeCount >= 3) {
            console.log(`⏹️ No new groups loaded after ${noChangeCount} attempts at bottom — done`);
            break;
          }
          await sleep(500); // extra wait before giving up
        } else {
          // New content loaded — more items appeared, keep going
          noChangeCount = 0;
          console.log(`📦 More groups loaded: scrollHeight ${lastScrollHeight} → ${newScrollHeight}`);
        }
      } else {
        noChangeCount = 0;
      }

      // Discovery check runs EVERY iteration, independent of the scroll heuristics
      // above — this is the terminator that can't be fooled.
      const newRows = collectNewRowKeys();
      reportProgress();
      if (newRows > 0) {
        noNewRowsCount = 0;
      } else {
        noNewRowsCount++;
        // An empty pass is NOT proof of the end: a 300px step can stay inside the
        // already-rendered window (~20 rows ≈ 1300px — stopping at 3 strikes made
        // Load All quit at one screenful), the next batch may still be fetching,
        // or scrollTop may be moving the wrong container. Nudge the last row into
        // view (advances whatever ancestor actually scrolls), give the fetch a
        // beat, and only stop after ~2 window-heights of consecutive nothing-new.
        const nudgeRows = dialog.querySelectorAll('[role="listitem"]');
        if (nudgeRows.length) {
          try { nudgeRows[nudgeRows.length - 1].scrollIntoView({ block: 'end', behavior: 'instant' }); } catch (e) {}
        }
        await sleep(500);
        if (noNewRowsCount >= 6) {
          console.log(`⏹️ No new groups discovered in ${noNewRowsCount} passes — done (${seenRowKeys.size} unique groups seen)`);
          break;
        }
      }

      lastScrollHeight = newScrollHeight;
    }

    scrollContainer.scrollTop = 0;
    // Callers (e.g. the Load All button) report this — counting DOM checkboxes
    // instead shows ~20 forever, because FB only keeps ~20 rows mounted.
    return seenRowKeys.size;
  }

  /**
   * Facebook-Compatible Text Input Function
   *
   * `cue` is optional and purely cosmetic: `{ atIndex, fire }` calls `fire()` once,
   * as the character at `atIndex` is about to be typed. Used to flash the "Remove
   * Watermark" button at the instant the watermark starts appearing in the box.
   * `atIndex` counts CODE POINTS, matching the `for…of` below — a caption with an
   * emoji in it makes a UTF-16 `.indexOf()` index land in the wrong place.
   */
  async function typeIntoFacebookTextarea(element, text, cue = null) {
      console.log('Starting Facebook textarea typing...');
      
      const ariaLabel = (element.getAttribute('aria-label') || '').toLowerCase();
      const placeholder = (element.getAttribute('placeholder') || '').toLowerCase();
      if (ariaLabel.includes('search facebook') || placeholder.includes('search facebook') || 
          element.getAttribute('type') === 'search') {
          console.error('❌ CRITICAL: Target appears to be the Search Bar. Aborting.');
          throw new Error('Safety Abort: Target is Search Bar');
      }

      if (element && !element.isContentEditable && element.tagName !== 'INPUT' && element.tagName !== 'TEXTAREA') {
          let parent = element.parentElement;
          while (parent) {
              if (parent.isContentEditable || parent.getAttribute('contenteditable') === 'true') {
                  element = parent;
                  break;
              }
              parent = parent.parentElement;
          }
      }

      const isInputElement = element.tagName === 'INPUT' || element.tagName === 'TEXTAREA';
      const isContentEditable = element.isContentEditable || element.getAttribute('contenteditable') === 'true';

      if (!isInputElement && !isContentEditable) {
          throw new Error('Element is not typable');
      }

      element.focus();

      const currentActive = getDeepActiveElement();
      if (currentActive !== element && !element.contains(currentActive)) {
          element.click();
          await sleep(50);
          element.focus();
      }

      await sleep(100);

      // Ghost cursor rides the caret for the whole typing loop, so the user
      // watches the pointer trace the post (and the watermark) as it appears.
      // Left running on an early throw: the next moveTo()/stop() clears it.
      Ghost.say('typing');
      await Ghost.typeAt(element);

      // Typing loop
      let charIndex = -1;
      for (const char of text) {
          charIndex++;
          if (cue && charIndex === cue.atIndex) {
              try { cue.fire(); } catch (e) { /* cosmetic — never break typing */ }
          }
          if (char === '\n' && isContentEditable) {
              const shiftEnterOptions = {
                  key: 'Enter',
                  code: 'Enter',
                  keyCode: 13,
                  which: 13,
                  shiftKey: true,
                  bubbles: true,
                  cancelable: true,
                  view: window
              };
              
              element.dispatchEvent(new KeyboardEvent('keydown', shiftEnterOptions));
              element.dispatchEvent(new KeyboardEvent('keypress', shiftEnterOptions));
              document.execCommand('insertLineBreak', false, null);
              element.dispatchEvent(new InputEvent('input', {
                  inputType: 'insertLineBreak',
                  bubbles: true,
                  cancelable: true,
                  view: window
              }));
              element.dispatchEvent(new KeyboardEvent('keyup', shiftEnterOptions));
              await sleep(10);
              continue;
          }
          
          const keyCode = char.charCodeAt(0);
          const code = `Key${char.toUpperCase()}`;
          
          const eventOptions = {
              key: char,
              code: code,
              keyCode: keyCode,
              which: keyCode,
              bubbles: true,
              cancelable: true,
              view: window
          };

          element.dispatchEvent(new KeyboardEvent('keydown', eventOptions));
          element.dispatchEvent(new KeyboardEvent('keypress', eventOptions));

          if (isInputElement) {
              element.value += char;
              // INPUT/TEXTAREA: .value assignment doesn't fire events, so we fire one manually
              element.dispatchEvent(new InputEvent('input', {
                  inputType: 'insertText',
                  data: char,
                  bubbles: true,
                  cancelable: true,
                  view: window
              }));
          } else if (isContentEditable) {
              // execCommand fires its own native 'input' event — do NOT dispatch a second one
              // or Lexical will see both and insert the character twice
              document.execCommand('insertText', false, char);
          }

          element.dispatchEvent(new KeyboardEvent('keyup', eventOptions));
          await sleep(1);
      }
      
      element.dispatchEvent(new Event('change', { bubbles: true }));
      await Ghost.doneTyping();
  }

  /**
   * Sets the value of a React-controlled combobox input directly in the DOM,
   * fires the events React needs, then presses Enter to confirm/commit.
   */
  async function fillNativeInput(input, value) {
    await Ghost.pointAndClick(input); // cosmetic; skips the travel if already there
    input.focus();
    input.click();
    await sleep(200);

    // Set value via native property setter (bypasses React's synthetic tracking)
    const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
    nativeSetter.call(input, value);

    // Also set the DOM attribute directly — this is what the confirmed HTML shows
    input.setAttribute('value', value);

    // Fire the events React listens to
    input.dispatchEvent(new Event('input',  { bubbles: true, cancelable: true }));
    input.dispatchEvent(new Event('change', { bubbles: true, cancelable: true }));
    await sleep(300);
  }

  /**
   * Finds and fills the post text field with the provided content
   */
  /**
   * @param {string} postContent
   * @param {number} settleMs - blind wait before looking for the composer. Defaults to
   *   the original 2000ms; the share loop passes a much shorter value because
   *   waitForComposerReady() has ALREADY confirmed the editor is mounted and visible,
   *   which is the only thing this sleep was ever standing in for (v18.0).
   */
  /**
   * @param {object|null} typingCue optional `{ atIndex, fire }`, passed straight
   *   through to typeIntoFacebookTextarea. Cosmetic only — see that function.
   */
  async function fillPostContent(postContent, settleMs = 2000, typingCue = null) {
    console.log('🔍 Looking for post text field to fill with content...');
    await sleep(settleMs);
    
    // Find dialogs
    const dialogs = document.querySelectorAll('div[role="dialog"]');
    let createPostDialog = null;
    const dialogsArray = Array.from(dialogs).reverse();
    
    for (const dialog of dialogsArray) {
      const ariaLabel = (dialog.getAttribute('aria-label') || '').toLowerCase();
      const style = window.getComputedStyle(dialog);
      const isVisible = style.display !== 'none' && style.visibility !== 'hidden' && dialog.getBoundingClientRect().width > 0;

      if ((ariaLabel.includes('create post') || ariaLabel.includes('create a post')) && isVisible) {
        createPostDialog = dialog;
        break;
      }
    }
    
    // Non-English UI (v17.7): the aria-label above is English ("יצירת פוסט" in Hebrew),
    // so the composer was never found and the post — including the watermark — went up
    // empty. Identify it by the Lexical editor it contains instead.
    if (!createPostDialog) {
      createPostDialog = Struct.findComposerDialog();
      if (createPostDialog) {
        console.log('🌍 Found composer dialog by editor (non-English UI)');
      }
    }

    if (!createPostDialog) {
      console.error('❌ Could not find "Create post" dialog');
      // Dump what WAS on screen. This failure is silent otherwise — the share carries
      // on and posts an empty caption — so make the next report diagnosable instead of
      // requiring another round of guessing.
      try {
        const seen = Array.from(document.querySelectorAll('div[role="dialog"]')).map(d => ({
          ariaLabel: d.getAttribute('aria-label'),
          visible: Struct.visible(d),
          hasEditor: !!d.querySelector('[data-lexical-editor="true"], [contenteditable="true"]'),
          hasPlaceholder: !!d.querySelector('[aria-placeholder]'),
          isPicker: !!(Struct.findGroupSearchInput(d) && d.querySelector('div[role="listitem"]'))
        }));
        console.warn('   dialogs on screen:', JSON.stringify(seen));
      } catch (e) { /* diagnostics must never throw */ }
      return false;
    }
    
    let postInputArea = null;
    const presentationContainers = createPostDialog.querySelectorAll('div[role="presentation"]');
    for (const container of presentationContainers) {
      const hasTextInput = container.querySelector('div[data-lexical-editor="true"]') ||
                          container.querySelector('div[role="textbox"]') ||
                          container.querySelector('div[contenteditable="true"]');
      
      if (hasTextInput) {
        postInputArea = container;
        break;
      }
    }
    
    if (!postInputArea) postInputArea = createPostDialog;
    
    // Interact to create input
    const searchArea = postInputArea || createPostDialog;
    const triggerElements = searchArea.querySelectorAll('div[role="button"], div[tabindex="0"], span, div, label, p, h1, h2, h3, h4, input, textarea');
    const triggerCandidates = [];
    
    for (const trigger of triggerElements) {
      const text = trigger.textContent.trim().toLowerCase();
      const role = trigger.getAttribute('role');
      const ariaLabel = (trigger.getAttribute('aria-label') || '').toLowerCase();
      const rect = trigger.getBoundingClientRect();
      
      if (rect.width === 0 || rect.height === 0) continue;
      if (role === 'heading' || (role === 'button' && (text === 'close' || text === 'post' || text === 'cancel'))) continue;
      if (text === 'create post' || text === 'create a post') continue;

      let score = 0;
      const computedStyle = window.getComputedStyle(trigger);
      if (computedStyle.cursor === 'text') score += 20;

      if (text.includes('create a public post')) score += 50;
      else if (text.includes('write something') || text.includes("what's on your mind")) score += 40;
      else if (text.includes('create a')) score += 10;
      
      if (ariaLabel.includes('create a public post')) score += 50;
      else if (ariaLabel.includes('write something')) score += 40;

      if (score > 0) triggerCandidates.push({ element: trigger, score });
    }
    
    triggerCandidates.sort((a, b) => b.score - a.score);
    
    if (triggerCandidates.length > 0) {
      const trigger = triggerCandidates[0].element;
      await Ghost.pointAndClick(trigger);
      trigger.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
    }
    
    await sleep(1500);
    
    // Find input
    let candidates = [];
    let retryCount = 0;
    
    while (candidates.length === 0 && retryCount < 10) {
      if (retryCount > 0) await sleep(500);
      retryCount++;
      candidates = [];

      const searchRoots = [postInputArea, document.body];
      const iframes = createPostDialog.querySelectorAll('iframe');
      iframes.forEach(iframe => {
        try {
          const doc = iframe.contentDocument || iframe.contentWindow.document;
          if (doc && doc.body) searchRoots.push(doc.body);
        } catch (e) {}
      });
      
      searchRoots.forEach((root) => {
        // Prioritize the main post editor with specific aria-placeholder
        const mainPostEditors = querySelectorAllDeep(root, 'div[data-lexical-editor="true"][aria-placeholder*="Create a public post"]');
        mainPostEditors.forEach(editor => {
          if (editor.getBoundingClientRect().width > 0) {
            if (!candidates.some(c => c.element === editor)) {
                console.log('✅ Found main post editor with aria-placeholder');
                candidates.push({ element: editor, type: 'main-post-editor', zIndex: 200 }); // Highest priority
            }
          }
        });

        // Non-English UI (v17.7): the selector above pins the aria-placeholder VALUE
        // ("Create a public post"), which is translated — in Hebrew it reads
        // "יצירת פוסט ציבורי...". Match the same element on its attributes instead.
        if (!candidates.length) {
          const structural = Struct.findPostEditor();
          if (structural && !candidates.some(c => c.element === structural)) {
            console.log('🌍 Found main post editor structurally (non-English UI)');
            candidates.push({ element: structural, type: 'main-post-editor', zIndex: 200 });
          }
        }
        
        // Fallback to other lexical editors (but lower priority)
        if (candidates.length === 0) {
          const lexicalEditors = querySelectorAllDeep(root, 'div[data-lexical-editor="true"], [contenteditable="true"][data-lexical-editor="true"]');
          lexicalEditors.forEach(editor => {
            // Skip if it's in a comment section (aria-label contains "comment" or doesn't have the right placeholder)
            const ariaPlaceholder = editor.getAttribute('aria-placeholder') || '';
            const ariaLabel = editor.getAttribute('aria-label') || '';
            
            if (ariaLabel.toLowerCase().includes('comment')) {
              console.log('⏭️ Skipping comment section editor');
              return;
            }

            // Non-English UI (v17.7): the 'comment' guard above is English-only, and
            // these roots include document.body — so on a translated page a comment box
            // elsewhere on the feed could win and the post content would be typed into
            // the wrong element. Containment in the composer is language-independent.
            if (createPostDialog && !createPostDialog.contains(editor)) {
              return;
            }

            if (editor.getBoundingClientRect().width > 0) {
              if (!candidates.some(c => c.element === editor)) {
                  candidates.push({ element: editor, type: 'lexical-editor', zIndex: 100 });
              }
            }
          });
        }
      });
      
      if (candidates.length === 0) {
        searchRoots.forEach(root => {
          const inputs = querySelectorAllDeep(root, 'textarea, input[type="text"]');
          inputs.forEach(input => {
             if (input.getBoundingClientRect().width > 0) {
                 candidates.push({ element: input, type: 'input', zIndex: 10 });
             }
          });
        });
      }
    }
    
    if (candidates.length === 0) return false;
    
    const targetElement = candidates[0].element;
    console.log(`🎯 Target element found:`, targetElement);
    console.log(`📋 Element type: ${targetElement.tagName}, contentEditable: ${targetElement.isContentEditable}, data-lexical-editor: ${targetElement.getAttribute('data-lexical-editor')}`);
    
    await Ghost.pointAndClick(targetElement);
    targetElement.focus();
    targetElement.click();
    await sleep(200);

    try {
      await typeIntoFacebookTextarea(targetElement, postContent, typingCue);
      
      // Verify content was actually entered
      const actualContent = targetElement.isContentEditable ? targetElement.textContent : targetElement.value;
      console.log(`🔍 Content after typing: "${actualContent}"`);
      
      if (!actualContent || actualContent.trim().length === 0) {
        console.error('❌ Content is empty after typing!');
        return false;
      }
      
      console.log('✅ Content verified in element');
      return true;
    } catch (error) {
      console.error('❌ Error typing:', error);
      return false;
    }
  }

  /**
   * Polls until "Your post is scheduled." appears or the dialog closes.
   */
  async function detectScheduleSuccess(maxWaitMs = 8000) {
    const startTime = Date.now();
    while (Date.now() - startTime < maxWaitMs) {
      if (document.body.innerText && document.body.innerText.includes('Your post is scheduled')) {
        console.log('✅ Schedule confirmed: notification found');
        return true;
      }
      const dialog = document.querySelector('div[role="dialog"]');
      if (!dialog) {
        console.log('✅ Schedule confirmed: dialog closed');
        return true;
      }
      await sleep(500);
    }
    console.warn('⚠️ Could not confirm schedule success within timeout');
    return false;
  }

  /**
   * Clicks "Schedule post", fills date/time inputs (with confirmation), clicks "Schedule".
   * @param {string} scheduledDate - Facebook date format e.g. "Apr 30, 2026"
   * @param {string} scheduledTime - Facebook time format e.g. "12:05 AM"
   */
  async function schedulePost(scheduledDate, scheduledTime) {
    console.log(`📅 Scheduling post: ${scheduledDate} at ${scheduledTime}`);

    // Step 1: Click the "Schedule post" clock icon button
    const schedulePostBtn = document.querySelector('[aria-label="Schedule post"]');
    if (!schedulePostBtn) {
      console.error('❌ "Schedule post" button not found in dialog');
      return false;
    }
    await clickElement(schedulePostBtn);
    await sleep(1500);

    // Step 2: Locate date and time combobox inputs
    // Date input: no aria-haspopup. Time input: aria-haspopup="listbox"
    const comboboxes = document.querySelectorAll('input[role="combobox"][type="text"]');
    let dateInput = null;
    let timeInput = null;
    for (const input of comboboxes) {
      if (input.getAttribute('aria-haspopup') === 'listbox') {
        timeInput = input;
      } else if (!dateInput) {
        dateInput = input;
      }
    }

    if (!dateInput) {
      console.error('❌ Date combobox not found after clicking "Schedule post"');
      return false;
    }
    if (!timeInput) {
      console.error('❌ Time combobox not found after clicking "Schedule post"');
      return false;
    }

    const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;

    // Step 3: Open the calendar, navigate it to the right month via the input value,
    // then click the exact day cell identified by its full screenreader date text.
    // e.g. scheduledDate "Apr 29, 2026" → match cell whose hidden div says "April 29, 2026"
    console.log(`📆 Setting date: "${scheduledDate}"`);

    const monthMap = {
      'Jan':'January','Feb':'February','Mar':'March','Apr':'April',
      'May':'May','Jun':'June','Jul':'July','Aug':'August',
      'Sep':'September','Oct':'October','Nov':'November','Dec':'December'
    };
    const dateParts = scheduledDate.split(' '); // ["Apr", "29,", "2026"]
    const fullMonthDate = `${monthMap[dateParts[0]]} ${parseInt(dateParts[1])}, ${dateParts[2]}`; // "April 29, 2026"

    // Click to open the calendar popup
    await Ghost.pointAndClick(dateInput);
    dateInput.focus();
    dateInput.click();
    await sleep(400);

    // Set the value so the calendar navigates to the correct month
    nativeSetter.call(dateInput, scheduledDate);
    dateInput.setAttribute('value', scheduledDate);
    dateInput.dispatchEvent(new Event('input',  { bubbles: true }));
    dateInput.dispatchEvent(new Event('change', { bubbles: true }));
    await sleep(700); // let the calendar re-render on the right month

    const calendarGrid = document.querySelector('[role="grid"]');
    if (calendarGrid) {
      // Each gridcell has a screenreader div with the full date e.g. "Wednesday, April 29, 2026"
      // Match on "April 29, 2026" — unambiguous, works across month boundaries
      let targetCell = null;
      const cells = calendarGrid.querySelectorAll('[role="gridcell"]');
      for (const cell of cells) {
        const srDivs = cell.querySelectorAll('div');
        for (const div of srDivs) {
          if (div.textContent.trim().includes(fullMonthDate)) {
            targetCell = cell;
            break;
          }
        }
        if (targetCell) break;
      }

      if (targetCell) {
        console.log(`📅 Clicking day cell: "${fullMonthDate}"`);
        await clickElement(targetCell);
        await sleep(500);
      } else {
        console.warn(`⚠️ Day cell for "${fullMonthDate}" not found — pressing Enter as fallback`);
        dateInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true }));
        dateInput.dispatchEvent(new KeyboardEvent('keyup',   { key: 'Enter', keyCode: 13, bubbles: true }));
        await sleep(400);
      }
    } else {
      // Calendar didn't open — just press Enter to commit what's in the field
      console.log('📅 No calendar popup detected — pressing Enter to commit');
      dateInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true }));
      dateInput.dispatchEvent(new KeyboardEvent('keyup',   { key: 'Enter', keyCode: 13, bubbles: true }));
      await sleep(400);
    }

    // Step 4: Set time value, then click the matching listbox option that appears
    console.log(`🕐 Setting time: "${scheduledTime}"`);
    await Ghost.pointAndClick(timeInput);
    timeInput.focus();
    timeInput.click();
    await sleep(300);
    nativeSetter.call(timeInput, scheduledTime);
    timeInput.setAttribute('value', scheduledTime);
    timeInput.dispatchEvent(new Event('input',  { bubbles: true }));
    timeInput.dispatchEvent(new Event('change', { bubbles: true }));
    await sleep(700); // give the listbox time to filter and render

    // Click the exact matching [role="option"] in the time dropdown
    const timeOptions = document.querySelectorAll('[role="option"]');
    let timeCommitted = false;
    for (const opt of timeOptions) {
      if (opt.textContent.trim() === scheduledTime) {
        console.log(`✅ Clicking time option: "${scheduledTime}"`);
        await clickElement(opt);
        timeCommitted = true;
        break;
      }
    }
    if (!timeCommitted) {
      console.warn('⚠️ Time option not found in listbox — pressing Enter as fallback');
      timeInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', keyCode: 13, bubbles: true }));
      timeInput.dispatchEvent(new KeyboardEvent('keyup',   { key: 'Enter', keyCode: 13, bubbles: true }));
    }
    await sleep(500);

    // Step 5: Click the "Schedule" confirmation button
    const scheduleBtn = document.querySelector('[aria-label="Schedule"]');
    if (!scheduleBtn) {
      console.error('❌ "Schedule" button not found');
      return false;
    }
    await clickElement(scheduleBtn);
    await sleep(2000);

    // Step 6: Confirm success
    return await detectScheduleSuccess(8000);
  }

  // --- High Level Flows ---

  /**
   * Handles the Quick Share button click
   */
  async function handleQuickShare() {
      console.log('🚀 Quick Share button clicked');

      // Free-forever model (v15.8): sharing is never license-gated. Unlicensed and
      // expired users share with a watermark, added inside shareToSelectedGroups.

      // Selected groups are gathered as {name, id} refs (v15.9). Identity key = the
      // group ID when known — two groups with the SAME display name are different
      // groups and must both be shared to (dedup by name alone collapsed them).
      const selectedGroups = [];
      const seen = new Set();
      const addGroup = (name, id) => {
          if (!name || name.length <= 2) return;
          const key = id ? `gid:${id}` : name;
          if (seen.has(key)) return;
          seen.add(key);
          selectedGroups.push({ name, id: id || null });
      };

      // PRIMARY source: the saved selections map in sessionStorage (keyed by group id
      // when available, legacy entries by name). Facebook virtualizes the group list —
      // only ~20 checkboxes are ever in the DOM at once — so reading
      // .multi-share-checkbox:checked alone would miss every group the user selected
      // and then scrolled past. The saved map survives virtualization.
      let savedSelections = {};
      if (window.ShareUnlimited.UI && window.ShareUnlimited.UI.getSavedSelections) {
          savedSelections = window.ShareUnlimited.UI.getSavedSelections() || {};
      }
      Object.entries(savedSelections).forEach(([key, val]) => {
          if (val && typeof val === 'object') {
              // v15.9 format: { checked, name, id } keyed by "gid:<id>"
              if (val.checked === true) addGroup(val.name, val.id);
          } else if (val === true) {
              // legacy format: boolean keyed by name
              addGroup(key, getKnownGroupId(key));
          }
      });

      // FALLBACK / union: any checkbox currently checked in the DOM — covers the rare
      // case of a just-clicked box whose 100ms save hasn't fired yet.
      const checkboxes = document.querySelectorAll('.multi-share-checkbox:checked');
      checkboxes.forEach(checkbox => {
          const button = checkbox.closest('div[role="button"]');
          if (button) {
              const groupName = extractAndValidateGroupName(button.textContent.trim(), button);
              if (groupName) addGroup(groupName, extractGroupIdFromRow(button));
          }
      });

      if (selectedGroups.length === 0) {
          alert('No groups selected. Please select at least one group.');
          return;
      }
      
      if (window.ShareUnlimited.UI) window.ShareUnlimited.UI.showPostContentModal(selectedGroups);
  }

  /**
   * The main logic for handling the multi-sharing process.
   */
  async function handleMultiPost() {
    if (window.groupScanInterval) {
        clearInterval(window.groupScanInterval);
        window.groupScanInterval = null;
    }

    const selectedGroups = [];
    const groupElements = document.querySelectorAll('div[role="dialog"] div[role="checkbox"]');

    groupElements.forEach(el => {
      const checkbox = el.querySelector('.multi-share-checkbox');
      const nameElement = el.querySelector('span, div[dir="auto"]');
      if (checkbox && checkbox.checked && nameElement) {
        selectedGroups.push({
          name: nameElement.textContent.trim(),
          element: el
        });
      }
    });

    if (selectedGroups.length === 0) {
      return true; // Proceed with original click
    }

    alert(`Starting multi-share process for ${selectedGroups.length} groups.`);
    const postButton = findPostButton();
    if (!postButton) {
      alert('Could not find the "Post" button. Aborting.');
      return false;
    }

    for (let i = 0; i < selectedGroups.length; i++) {
      const group = selectedGroups[i];
      await clickElement(group.element);
      await sleep(500);
      await clickElement(postButton);
      await clickElement(group.element);
      await sleep(500);

      if (i < selectedGroups.length - 1) {
        await sleep(State.SHARE_DELAY_MS);
      }
    }

    alert('Multi-share process completed!');
    return false;
  }

  /**
   * Shares to multiple groups based on the provided group names.
   */
  // `sourcePresetIds` (v17.0) — ids of the Group List Preset(s) this run came from,
  // when it started from the preset chooser or a 1-Click template. Used only to
  // learn which profile those presets belong to once the run has proved it (see
  // recordPresetProfileFromRun). Null for every other path; never affects sharing.
  async function shareToSelectedGroups(groupNames, postContent = '', postVariations = null, postSignature = null, delaySeconds = 10, randomizeDelay = false, scheduledDate = null, scheduledTime = null, sourcePresetIds = null) {
    console.log(`📢 shareToSelectedGroups called with postContent: "${postContent}"`);

    // Normalize items to {name, id} refs (v15.9): Quick Share, the group picker and
    // presets saved from v18.2 on all pass objects carrying the group ID captured at
    // selection time — the only way to tell two identically-named groups apart.
    // Anything still arriving as a plain name string (a pre-v18.2 preset, a scheduled
    // run queued before the upgrade) falls back to the name→id map, which holds ONE id
    // per name: two same-named legacy entries resolve to the same group and the
    // duplicate guard below correctly posts once. Re-saving the preset fixes it.
    const groupRefs = (groupNames || []).map(g =>
      (g && typeof g === 'object')
        ? { name: g.name, id: g.id || getKnownGroupId(g.name) }
        : { name: g, id: getKnownGroupId(g) });
    groupNames = groupRefs.map(r => r.name); // UI/progress/logs stay string-based
    console.log(`📊 Groups to share to (${groupRefs.length}):`, groupRefs.map(r => r.id ? `${r.name} [${r.id}]` : r.name));
    
    // === CHECK LICENSE FOR WATERMARK ===
    // Delegates to the ONE predicate (expired_overlay.js, which loads first) so the
    // "Remove Watermark" button is visible for exactly the users who get stamped —
    // it can never vanish while the watermark still applies. Inline fallback keeps
    // the share loop working if ExpiredOverlay somehow isn't loaded.
    const needsWatermark = (window.ExpiredOverlay && window.ExpiredOverlay.isWatermarkActive)
        ? await window.ExpiredOverlay.isWatermarkActive()
        : await new Promise(resolve => {
            chrome.storage.local.get(['authExpiry'], (result) => {
                const { authExpiry } = result;
                resolve(!authExpiry || new Date(authExpiry) <= new Date());
            });
        });

    let hadOwnSignature = false;
    if (needsWatermark) {
        console.log('⚠️ No active license - appending watermark');
        // NO URL, deliberately (v18.0). A bare domain repeated across every group in a
        // run is the loudest spam signal in the post: group admins auto-hold "posts
        // containing links" for approval, and Facebook itself reacts to one domain
        // posted 200× in an hour from one account. The brand name carries the same
        // recall with none of that. Never restore the ".com", and never turn this into
        // an @mention — see the watermark section in QUICKSTART.md.
        const watermark = '\n\n' + WATERMARK_TEXT;

        // Whether the user had a sign-off of their own before ours was added —
        // the ghost names them separately ("your signature and our watermark").
        hadOwnSignature = !!postSignature;

        // Append watermark to signature (or create signature if none)
        if (postSignature) {
            postSignature = postSignature + watermark;
        } else {
            postSignature = watermark.trim(); // Trim because logic later adds \n\n
        }
    }
    // ===============================================

    State.isSharingInProgress = true;
    State.shareProcessCancelled = false;
    const UI = window.ShareUnlimited.UI;
    
    if (window.groupScanInterval) {
        clearInterval(window.groupScanInterval);
        window.groupScanInterval = null;
    }
    
    if (UI) {
      UI.createProgressOverlay();
      UI.initializeGroupsList(groupNames);
      UI.updateProgressOverlay({
        current: 0,
        total: groupNames.length,
        status: '🚀',
        message: 'Initializing...'
      });
    }

    // Pre-cache the share button while dialog is still open and page is in view
    // This ensures reopenShareDialog can reliably find it for groups 2+
    const preButton = findShareButton();
    if (preButton) {
      markAndCacheButton(preButton);
      console.log('✅ Share button pre-cached for multi-group sharing');
    } else {
      console.warn('⚠️ Could not pre-cache share button — reopenShareDialog may be unreliable');
    }

    if (groupNames.length === 0) {
      State.isSharingInProgress = false;
      return { success: false, message: 'No groups selected' };
    }
    
    const dialogOpen = document.querySelector('div[role="dialog"]');
    if (!dialogOpen) {
      State.isSharingInProgress = false;
      return { success: false, message: 'Share dialog not open.' };
    }

    let successCount = 0;
    let errorCount = 0;
    const errors = [];

    // Watch tab visibility for the WHOLE share. Backgrounding the tab breaks Facebook's
    // own rendering, so we warn the user the instant it happens rather than silently
    // producing garbage. Stopped in the finally below.
    VisibilityWatch.start();
    // Ghost cursor for the WHOLE share, for the same structural reason as
    // VisibilityWatch: handleQuickShare returns before sharing starts, so this
    // has to live here, not around the click handler. Stopped in the finally.
    await Ghost.start();
    Ghost.say('start', { total: groupNames.length });
    // Group identities (id or normalized name) already posted to in THIS run —
    // the duplicate-post guard below refuses a second post to the same group.
    const postedGroupKeys = new Set();
    // Normalized names of groups this run actually delivered to (v17.0). Feeds
    // preset→profile attribution: a group only lands here if it was FOUND on this
    // profile and the post/schedule went through, which is exactly the evidence
    // that distinguishes "right profile" from "wrong profile".
    const sharedGroupNames = new Set();
    // Set from VisibilityWatch.stop() in the finally below; surfaced in the summary.
    let tabWasHidden = false;

    try {

    for (let i = 0; i < groupNames.length; i++) {
      if (State.shareProcessCancelled) {
        if (UI) UI.updateGroupStatus(i, 'failed');
        break;
      }
      
      // PAUSE / RESUME (v18.0). We are between groups: the previous one is finished and
      // this one has not started, so nothing is half-done and a hidden tab is safe to
      // simply wait out. Charging into a group against a frozen page is what produced
      // the v16.6 "posted to the same group 5×" disaster — so we park here instead.
      //
      // The safe zone is (re)opened HERE rather than only around the countdown, because
      // the four `continue` paths below (dialog wouldn't reopen, group not found,
      // duplicate, wrong audience) all skip the countdown entirely. Opening it at the
      // top of the body is the one place every iteration passes through — otherwise a
      // failed group followed by a screen lock would be logged as a tainted run when
      // in fact nothing was in flight. Idempotent, so re-opening it is free.
      VisibilityWatch.beginSafeZone();
      const resumedAfterPause = await VisibilityWatch.waitUntilVisible();
      VisibilityWatch.endSafeZone();
      if (State.shareProcessCancelled) {
        if (UI) UI.updateGroupStatus(i, 'failed');
        break;
      }
      if (resumedAfterPause) {
        console.log(`▶️ MGSA: tab visible again — resuming at group ${i + 1}/${groupNames.length}.`);
        Ghost.say('resumed', { index: i + 1, total: groupNames.length });
        // Facebook has been frozen for however long the user was away and may have
        // torn down, re-rendered or staled the picker. Give it a beat to repaint, and
        // force the full reopen path below rather than trusting a dialog that was
        // mounted before the pause.
        await sleep(1500);
      }

      const groupName = groupNames[i];
      const targetId = groupRefs[i].id;
      // Tab title progress (visible without switching to the tab), e.g. "(1/10) MGSA Sharing…"
      TabTitle.setProgress(i + 1, groupNames.length, scheduledDate ? 'Scheduling…' : 'Sharing…');
      if (UI) {
        UI.updateCountdownOverlay(0);
        UI.updateGroupStatus(i, 'active');
        UI.updateProgressOverlay({
          current: i,
          total: groupNames.length,
          groupName: groupName,
          status: scheduledDate ? '📅' : '🚀',
          message: scheduledDate ? `Scheduling to ${groupName}...` : `Sharing to ${groupName}...`
        });
      }
      
      chrome.runtime.sendMessage({
        type: 'share_progress',
        current: i + 1,
        total: groupNames.length,
        groupName: groupName
      });
      Ghost.say('find', { index: i + 1, total: groupNames.length, name: groupName });
      
      let currentDialog = findShareDialog();

      // `resumedAfterPause` forces the reopen path even for group 1: whatever dialog
      // survived a locked screen is not to be trusted.
      if (i > 0 || !currentDialog || resumedAfterPause) {
        const reopened = await reopenShareDialog(groupName, targetId);
        if (!reopened) {
          errorCount++;
          errors.push(`${groupName}: Could not open share dialog`);
          if (UI) UI.updateGroupStatus(i, 'failed', {
            reason: 'Couldn’t reopen the share dialog for this group. Skipped it to avoid sharing to the wrong listing.'
          });
          continue;
        }
        await sleep(2000);
      } else {
        // First group reuses the already-open picker instead of reopening. FB virtualizes
        // the list (~20 rows), so the target may not be rendered yet — scroll it into view
        // first, exactly like reopenShareDialog does for groups 2+. Without this the top
        // group was often "not found" → silently failed (the "always fails the one on top"
        // + lingering-blue-highlight bug).
        await scrollToLoadAllGroups(null, groupName, targetId);
      }

      const groupElement = findGroupElementByName(groupName, false, false, targetId);
      if (!groupElement) {
        Ghost.say('notFound', { name: groupName });
        errorCount++;
        errors.push(`${groupName}: Group not found in dialog`);
        if (UI) UI.updateGroupStatus(i, 'failed', {
          reason: 'Group not found — either it changed its name, or you’re signed in to a profile that isn’t a member of this group.',
          removable: true,
          // So the preset cleanup takes THIS group out and not another one that
          // merely shares its display name (v18.2).
          groupId: targetId || null
        });
        continue;
      }

      // DUPLICATE-POST GUARD (v15.9): never post to the same group twice in one run.
      // Identity = the row's /groups/<id>/ link when available (unique even when two
      // groups share a display name), else the normalized name. A user got banned
      // from groups after name-matching posted to one group 15+ times — this makes
      // that impossible even if matching ever picks a wrong-but-repeated row again.
      const rowGroupId = extractGroupIdFromRow(groupElement);
      rememberGroupId(groupName, rowGroupId);
      const postKey = rowGroupId || targetId || normalizeGroupNameForMatch(groupName);
      if (postedGroupKeys.has(postKey)) {
        Ghost.say('duplicate', { name: groupName });
        errorCount++;
        // Counts as delivered for preset→profile attribution (v17.0): this group
        // exists on this profile and DID receive the post — just under another
        // entry earlier in the run. Only the second post is refused, not the first.
        sharedGroupNames.add(normalizeGroupNameForMatch(groupName));
        errors.push(`${groupName}: Skipped — this group (id ${postKey}) was already posted to in this run`);
        if (UI) UI.updateGroupStatus(i, 'failed', {
          reason: 'Skipped — this exact group was already posted to in this run (duplicate protection).',
          removable: true,
          groupId: rowGroupId || targetId || null,
          // This group IS in the list — twice. Removing every copy would lose it
          // altogether, so the cleanup here trims the redundant entries and keeps one.
          removeMode: 'extras'
        });
        continue;
      }

      Ghost.say('found', { name: groupName });
      await clickElement(groupElement);

      // This group's exact text is resolved BEFORE the composer-open wait, not
      // after it, so the ghost can announce what is about to be typed during a
      // pause that already existed. Nothing here touches the DOM, so moving it
      // ahead of the sleep costs nothing and adds no time to the run (v17.9).
      let currentPostContent = postContent;
      let variantNumber = 0;
      if (postVariations && postVariations.length > 0) {
        const variationIndex = i % postVariations.length;
        variantNumber = variationIndex + 1;
        currentPostContent = postVariations[variationIndex];
      }

      // Snapshot the caption BEFORE the signature is joined on. The preview must
      // show the user's own text and name the watermark separately — showing the
      // joined string put "Shared using MGSApro" inside the quoted caption
      // (its \n\n flattened to a space) and then announced it a second time.
      const captionOnly = currentPostContent || '';

      if (postSignature) {
        // The blank-line separator only makes sense when there IS caption text above it.
        // With an empty caption (watermark-only post) the old join produced "\n\nShared
        // using MGSApro" — two leading blank lines in the composer.
        const body = (currentPostContent || '').trimEnd();
        const signature = postSignature.trim();
        currentPostContent = body ? `${body}\n\n${signature}` : signature;
      }

      // Show the user the text before it lands in the box. Nothing should ever
      // appear in their composer that they weren't told about first — that
      // includes the watermark, and it's the whole point when AI variants mean
      // each group gets different wording.
      Ghost.say('willType', {
        text: captionOnly,
        signature: postSignature ? String(postSignature).trim() : '',
        variant: variantNumber,
        variants: (postVariations && postVariations.length) || 0,
        watermark: !!needsWatermark,
        ownSignature: hadOwnSignature
      });

      // The bubble has just named the watermark, so the button that removes it
      // starts pulsing — and keeps pulsing until the watermark actually lands in
      // the composer below. Fire-and-forget by contract: it must not delay the
      // composer wait, and every exit from here stops it again.
      if (needsWatermark) WatermarkCta.start();

      // Wait for the composer to actually be typeable rather than guessing at 5s. The
      // floor keeps the willType bubble above readable; past that we go as soon as
      // Facebook is ready.
      const composer = await waitForComposerReady();

      if (currentPostContent) {
        console.log(`📝 Attempting to fill post content: "${currentPostContent.substring(0, 50)}..."`);
        // The editor is already confirmed present and visible, so fillPostContent's own
        // blind settle is redundant here — hence the short value. It still DEFAULTS to
        // the original 2000ms for any future caller that hasn't pre-verified.
        // The cue ends the pulse the instant the watermark's first character is
        // typed. Built here rather than inside fillPostContent so the typer stays
        // generic — it is also used for the group search box.
        const fillSuccess = await fillPostContent(
          currentPostContent,
          composer.ready ? 250 : 2000,
          buildWatermarkTypingCue(currentPostContent, needsWatermark)
        );
        if (!fillSuccess) {
          console.warn('⚠️ Failed to fill post content, but continuing...');
        } else {
          console.log('✅ Post content filled successfully');
        }
        // Minimal wait to ensure UI updates after Lexical editor changes
        await sleep(needsWatermark ? 50 : 500);
      } else {
        console.log('ℹ️ No post content to fill (empty or null)');
      }
      // Unconditional backstop. The cue above never runs when the composer was
      // never found, when the fill threw, or when this group had no content at
      // all — and an unpaired start would pulse through the rest of the run.
      WatermarkCta.stop();
      
      // AUDIENCE GUARD (v15.9): make sure this composer is actually sharing to a
      // group before letting either flow click Post/Schedule. Blocks only on a
      // positive "not a group" reading (e.g. a feed share) — see
      // composerAudienceLooksLikeGroup(). Closes the composer so the next group's
      // reopen starts from a clean state.
      if (!composerAudienceLooksLikeGroup(groupName)) {
        // Diagnostic context: which group we were on and every dialog FB has open,
        // so a repro log shows WHERE the flow diverged into a feed composer.
        const dialogLabels = Array.from(document.querySelectorAll('div[role="dialog"]'))
          .map(d => d.getAttribute('aria-label') || '(unlabelled)').join(' | ');
        console.warn(`🛑 Audience guard fired on group ${i + 1}/${groupNames.length} "${groupName}". Open dialogs: ${dialogLabels}`);
        Ghost.say('audience', { name: groupName });
        errorCount++;
        errors.push(`${groupName}: Composer was not targeting a group — skipped for safety`);
        if (UI) UI.updateGroupStatus(i, 'failed', {
          reason: 'The post composer was about to share to your own feed, not a group — skipped for safety.'
        });
        const closeBtn = document.querySelector('div[aria-label="Close composer dialog"][role="button"]');
        if (closeBtn) { await clickElement(closeBtn); await sleep(1500); }
        continue;
      }

      if (scheduledDate && scheduledTime) {
        // ---- SCHEDULE FLOW ----
        Ghost.say('scheduling', { date: scheduledDate, time: scheduledTime });
        const scheduled = await schedulePost(scheduledDate, scheduledTime);
        if (scheduled) {
          Ghost.say('scheduled', { name: groupName });
          await sleep(3000);
          successCount++;
          postedGroupKeys.add(postKey);
          sharedGroupNames.add(normalizeGroupNameForMatch(groupName));
          if (UI) UI.updateGroupStatus(i, 'completed');
        } else {
          errorCount++;
          errors.push(`${groupName}: Scheduling failed — check that you are an Admin of this group and your account has scheduling enabled`);
          if (UI) UI.updateGroupStatus(i, 'failed', {
            reason: 'Scheduling failed — you must be an Admin of this group and have scheduling enabled on your account.'
          });
        }
      } else {
        // ---- NORMAL POST FLOW ----
        const postButton = await waitForPostButton(10000);

        if (postButton) {
          // Check the reshare-original-content checkbox if it's present and unchecked
          const reshareCheckbox = document.querySelector('input[name="reshare-original-content"]');
          if (reshareCheckbox && !reshareCheckbox.checked) {
            console.log('☑️ Checking reshare-original-content checkbox...');
            reshareCheckbox.click();
            await sleep(300);
          }

          // If watermarked (unlicensed/expired), click immediately to prevent text deletion. Otherwise wait standard time.
          const postDelay = needsWatermark ? 200 : 1000;
          if (needsWatermark) console.log('⚡ Watermark mode: Posting immediately!');

          // The ghost cursor travels to Post DURING the pre-click delay rather
          // than before it, so the flourish is (almost) free. Watermark mode
          // clicks fast on purpose — FB's editor can drop the text if we dawdle
          // — so the travel is capped short there and still counted against the
          // delay. Both no-op to the original timing when the ghost is off.
          Ghost.say('posting', { name: groupName });
          const ghostTravelStart = Date.now();
          await Ghost.point(postButton, needsWatermark ? 280 : 0);
          await sleep(Math.max(0, postDelay - (Date.now() - ghostTravelStart)));
          await Ghost.press();
          // Captured BEFORE the click — after it, the composer may already be gone
          // and .closest() would return null, which reads as "landed" for free.
          const postHostDialog = postButton.closest('div[role="dialog"]');
          const clickEvent = new MouseEvent('click', { view: window, bubbles: true, cancelable: true });
          postButton.dispatchEvent(clickEvent);

          // Wait for the composer to actually go, rather than the old flat sleep(5000).
          // Typically ~1–2s, so this is where most of the per-group time comes back.
          const landing = await waitForPostToLand(postButton, postHostDialog);
          if (landing.landed) {
            console.log(`✅ Post landed in ${landing.ms}ms (was a flat 5000ms wait)`);
          } else {
            // The composer is still up. Most likely FB rejected or rate-limited the
            // post. We do NOT newly fail it here — that would turn a path that
            // currently succeeds into a failure on a signal with no field data behind
            // it yet. Logged loudly so it shows up before it's trusted; the next
            // group's reopen closes any visible dialog anyway.
            console.warn(`⚠️ Post composer still on screen after ${landing.ms}ms for ` +
              `"${groupName}" — counting it as posted (unchanged from previous ` +
              `behaviour), but VERIFY this group.`);
          }
          // A short, jittered human beat before the next group starts.
          await sleep(POST_SETTLE_MIN_MS +
            Math.floor(Math.random() * (POST_SETTLE_MAX_MS - POST_SETTLE_MIN_MS + 1)));

          Ghost.say('posted', { name: groupName });
          successCount++;
          postedGroupKeys.add(postKey);
          sharedGroupNames.add(normalizeGroupNameForMatch(groupName));
          if (UI) UI.updateGroupStatus(i, 'completed');
        } else {
          Ghost.say('postFail', { name: groupName });
          errorCount++;
          errors.push(`${groupName}: Post button not found`);
          if (UI) UI.updateGroupStatus(i, 'failed', {
            reason: 'The Post button never appeared — Facebook may have blocked or rate-limited this post. Try again later.'
          });
        }
      }

      if (i < groupNames.length - 1) {
        const totalDelaySeconds = resolveDelayGap(delaySeconds, randomizeDelay);
        console.log(`⏳ Group ${i + 1}/${groupNames.length} done — waiting ${totalDelaySeconds}s before the next group…`);
        Ghost.say('nextUp', { index: i + 2, total: groupNames.length, name: groupNames[i + 1] });
        // From here until the next group actually starts, nothing is in flight — so a
        // hidden tab pauses the run instead of tainting it. Closed at the top of the
        // next iteration, right after waitUntilVisible().
        VisibilityWatch.beginSafeZone();
        await countdown(totalDelaySeconds);
        console.log(`▶️ Delay finished — moving to group ${i + 2}/${groupNames.length}.`);
      }
    }

    } finally {
      // Cancellation, a throw, or a `break` can all leave the loop between the
      // pulse's start and its stop. Nothing cosmetic may outlive the run.
      WatermarkCta.stop();
      tabWasHidden = VisibilityWatch.stop();
      // Grow → spin → dive finale only when the run actually completed; a
      // cancelled or aborted run just fades the pointer out.
      Ghost.say(State.shareProcessCancelled ? 'cancelled' : 'done', {
        ok: errorCount === 0, success: successCount, total: groupNames.length
      });
      await Ghost.finish(!State.shareProcessCancelled && !tabWasHidden);
    }

    if (tabWasHidden) {
      console.warn('⚠️ MGSA: the tab was hidden during this share — results above may be ' +
        'unreliable. Check your groups before re-running.');
    }

    // Learn which profile the source preset(s) belong to from what actually got
    // delivered (v17.0). Skipped when the tab was hidden: a backgrounded run can
    // report success against a composer that never moved on, so its per-group
    // results aren't evidence of anything.
    if (!tabWasHidden) {
      await recordPresetProfileFromRun(sourcePresetIds, sharedGroupNames);
    }

    if (UI && !State.shareProcessCancelled) {
      UI.showCompletionMessage(errorCount === 0, successCount, groupNames.length, tabWasHidden);
    }

    // A PERFECT run — every attempted group posted, nothing failed, nothing skipped
    // for duplicate protection, not stopped early — earns the celebration + upsell
    // modal (v17.8). Anything less stays on the plain completion screen: the modal
    // claims "x/x" and a time saving, and claiming that over a partial run is a lie
    // the user can check.
    //
    // `tabWasHidden` disqualifies a run even at 100%, for the same reason preset
    // attribution skips it: Facebook stops rendering in a hidden tab, so the loop can
    // report success against a composer that never advanced. Those counts aren't
    // evidence, and the completion screen is at that moment telling the user to go
    // verify their groups — congratulating them over that warning would be absurd.
    const perfectRun = !State.shareProcessCancelled && errorCount === 0 &&
      successCount > 0 && successCount === groupNames.length && !tabWasHidden;
    if (UI && perfectRun && UI.showPostShareSuccessModal) {
      // Non-blocking and non-fatal: the share is already finished and its return
      // value must never depend on a cosmetic modal.
      Promise.resolve()
        .then(() => sleep(700))            // let the completion screen land first
        .then(() => UI.showPostShareSuccessModal(successCount))
        .catch(e => console.warn('Success modal failed (non-fatal):', e));
    }

    // Show a final summary in the tab title, then restore Facebook's original title.
    const doneIcon = State.shareProcessCancelled ? '⏹' : (errorCount === 0 ? '✅' : '⚠️');
    const doneWord = State.shareProcessCancelled ? 'Stopped' : 'Done';
    TabTitle.setText(`${doneIcon} ${successCount}/${groupNames.length} MGSA ${doneWord}`);
    setTimeout(() => TabTitle.restore(), 6000);

    State.isSharingInProgress = false;

    if (successCount === 0) return { success: false, message: `Failed. Errors: ${errors.join(', ')}` };
    if (errorCount > 0) return { success: true, message: `Shared to ${successCount} groups. ${errorCount} failed.`, partialSuccess: true };
    return { success: true, message: `Successfully shared to all ${successCount} groups.` };
  }

  /**
   * Uses a 1 Click Template directly from Facebook
   */
  async function useOneClickTemplateDirectly(templateId) {
    const result = await new Promise(resolve => {
      chrome.storage.local.get(['oneClickTemplates', 'groupPresets', 'postTemplates'], resolve);
    });
    
    const templates = result.oneClickTemplates || [];
    const template = templates.find(t => t.id === templateId);
    
    if (!template) return;
    
    const postContent = (result.postTemplates || {})[template.postTemplateName];
    const groupPreset = (result.groupPresets || []).find(p => p.id === template.groupPresetId);
    
    if (!postContent || !groupPreset) return;
    
    alert(`Starting to share with template "${template.name}"!`);

    // Legacy presets store names only; recover the IDs so a list naming the same
    // group twice reaches both of them (v18.2).
    const presetRefs = await resolvePresetGroupRefs(groupPreset);

    await shareToSelectedGroups(
      presetRefs,
      postContent,
      null,
      null,
      25,
      false,
      null,
      null,
      [groupPreset.id] // confirm this preset's profile if the run succeeds (v17.0)
    );
  }

  // ==================== AUTO-SHARE FUNCTIONS ====================

  /**
   * Fetches today's posts from a Facebook Page.
   * Navigates to the page's posts section, scrolls to load posts, and extracts post data.
   * @param {string} pageUrl - The Facebook Page URL (e.g., https://www.facebook.com/YourPage)
   * @returns {Promise<Array>} Array of post objects with text, images, timestamp, url
   */
  async function fetchPagePosts(pageUrl) {
    const posts = [];
    const originalUrl = window.location.href;
    
    try {
      // Normalize page URL to posts section
      let postsUrl = pageUrl.replace(/\/$/, '');
      if (!postsUrl.includes('/posts')) {
        postsUrl += '/posts';
      }
      
      console.log(`Fetching posts from: ${postsUrl}`);
      
      // Navigate to the page
      window.location.href = postsUrl;
      
      // Wait for page to load
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      // Wait for feed to appear
      let feed = null;
      for (let i = 0; i < 10; i++) {
        feed = document.querySelector('[role="feed"]') || document.querySelector('[data-pagelet="Feed"]');
        if (feed) break;
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
      
      if (!feed) {
        console.warn('Could not find feed on page');
        return [];
      }
      
      // Scroll to load more posts (up to 20 posts)
      let lastHeight = 0;
      const maxScrolls = 5;
      for (let i = 0; i < maxScrolls; i++) {
        window.scrollTo(0, document.body.scrollHeight);
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        const newHeight = document.body.scrollHeight;
        if (newHeight === lastHeight) break;
        lastHeight = newHeight;
      }
      
      // Extract posts
      const postElements = feed.querySelectorAll('[role="article"], [data-ad-rendering-role="feed_message"]');
      console.log(`Found ${postElements.length} post elements`);
      
      for (const postEl of postElements) {
        try {
          const postData = extractPostData(postEl);
          if (postData && isToday(postData.timestamp)) {
            posts.push(postData);
          }
        } catch (e) {
          console.warn('Error extracting post:', e);
        }
      }
      
      console.log(`Extracted ${posts.length} posts from today`);
      return posts;
      
    } catch (error) {
      console.error('Error fetching page posts:', error);
      return [];
    } finally {
      // Navigate back to original page
      if (originalUrl !== window.location.href) {
        window.location.href = originalUrl;
        await new Promise(resolve => setTimeout(resolve, 2000));
      }
    }
  }
  
  /**
   * Extracts post data from a post element.
   */
  function extractPostData(postEl) {
    // Get text content
    const textElements = postEl.querySelectorAll('[data-ad-comet-preview="message"], [dir="auto"]');
    let text = '';
    for (const el of textElements) {
      const t = el.textContent?.trim();
      if (t && t.length > text.length) text = t;
    }
    
    // Get timestamp
    let timestamp = null;
    const timeEl = postEl.querySelector('a[href*="/posts/"], a[href*="/videos/"]') 
      || postEl.querySelector('a[role="link"] time') 
      || postEl.querySelector('time');
    if (timeEl) {
      const dt = timeEl.getAttribute('datetime') || timeEl.textContent;
      if (dt) timestamp = new Date(dt).getTime();
    }
    
    // Get images
    const images = [];
    const imgElements = postEl.querySelectorAll('img[src*="scontent"], img[src*="fbcdn"]');
    imgElements.forEach(img => {
      if (img.src && img.width > 100 && img.height > 100) {
        images.push(img.src);
      }
    });
    
    // Get post URL
    let url = '';
    const linkEl = postEl.querySelector('a[href*="/posts/"], a[href*="/videos/"]');
    if (linkEl) url = linkEl.href;
    
    if (!text && !images.length) return null;
    
    return { text, images, timestamp, url };
  }
  
  /**
   * Checks if a timestamp is from today.
   */
  function isToday(timestamp) {
    if (!timestamp) return false;
    const postDate = new Date(timestamp);
    const today = new Date();
    return postDate.toDateString() === today.toDateString();
  }
  
  /**
   * Gets all joined groups from the share dialog.
   * Opens the share dialog if needed, loads all groups, and returns them.
   * @returns {Promise<Array>} Array of group objects with name and id
   */
  async function getAllJoinedGroups() {
    // First, check if share dialog is already open
    let dialog = findShareDialog();
    
    if (!dialog) {
      // Need to trigger share dialog - click on a share button
      const shareButtons = document.querySelectorAll('div[role="button"][aria-label*="Share"], div[role="button"]');
      for (const btn of shareButtons) {
        const ariaLabel = btn.getAttribute('aria-label') || '';
        const text = btn.textContent || '';
        if (ariaLabel.includes('Share') || text.includes('Share')) {
          btn.click();
          await new Promise(resolve => setTimeout(resolve, 2000));
          dialog = findShareDialog();
          if (dialog) break;
        }
      }
    }
    
    if (!dialog) {
      console.warn('Could not open share dialog');
      return [];
    }
    
    // Click "Group" option to switch to the group selector
    // This handles both: the general Share dialog (with WhatsApp, Group, X etc.)
    // and the case where we're already in the group picker
    const groupOption = Struct.findGroupOptionByIcon?.();
    if (groupOption) {
      console.log('Found Group option, clicking to open group selector');
      groupOption.click();
      await new Promise(resolve => setTimeout(resolve, 2000));
      // After clicking Group, re-find the dialog (it may have changed to "Share to a group")
      dialog = findShareDialog();
    }
    
    // Clear search to show all groups
    const searchInput = Struct.findGroupSearchInput?.(dialog);
    if (searchInput && searchInput.value) {
      searchInput.value = '';
      searchInput.dispatchEvent(new Event('input', { bubbles: true }));
      await new Promise(resolve => setTimeout(resolve, 500));
    }
    
    // Scroll to load all groups
    await scrollToLoadAllGroups(() => {
      return 0;
    });
    
    // Get all group names
    const groups = await getGroupNames();
    return groups.map(g => ({ name: g.name, id: g.id })).filter(g => g.name);
  }
  
  /**
   * Gets the next batch of groups for auto-sharing using round-robin rotation.
   * Maintains shuffled order in storage to ensure fair distribution.
   * @param {Array} allGroups - All available groups [{name, id}]
   * @param {number} count - Number of groups to select (default 5)
   * @returns {Promise<Array>} Selected group refs
   */
  async function getAutoShareGroupRotation(allGroups, count = 5) {
    return new Promise((resolve) => {
      chrome.storage.local.get(['autoShareGroupRotation'], (result) => {
        let rotation = result.autoShareGroupRotation || {
          shuffledIds: [],
          index: 0
        };
        
        const allIds = allGroups.map(g => g.id || g.name).filter(Boolean);
        
        // Reshuffle if empty or exhausted
        if (!rotation.shuffledIds.length || rotation.index >= rotation.shuffledIds.length) {
          rotation.shuffledIds = shuffleArray(allIds);
          rotation.index = 0;
          console.log(`Reshuffled ${rotation.shuffledIds.length} groups for rotation`);
        }
        
        // Pick next batch
        const selectedIds = rotation.shuffledIds.slice(rotation.index, rotation.index + count);
        rotation.index += count;
        
        // Map back to group refs
        const selectedGroups = allGroups.filter(g => selectedIds.includes(g.id || g.name));
        
        // Save updated rotation
        chrome.storage.local.set({ autoShareGroupRotation: rotation }, () => {
          resolve(selectedGroups);
        });
      });
    });
  }
  
  /**
   * Shuffles an array in place (Fisher-Yates).
   */
  function shuffleArray(array) {
    const arr = [...array];
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }

  // Export functions
  Object.assign(Core, {
    getAuthStatus,
    VisibilityWatch,
    TabTitle,
    sleep,
    countdown,
    // Exported so the share modal's ETA and the loop's actual wait can never drift
    // apart — the ranges live in ONE place (v18.0).
    DELAY_MODES,
    resolveDelayGap,
    clickElement,
    querySelectorAllDeep,
    getDeepActiveElement,
    getFocusableElements,
    Struct,
    reconcileGroupNames,
    // Preset group entries are {name, id} refs (legacy plain strings tolerated).
    // Anything that reads, merges or counts a preset's groups goes through these.
    presetGroupName,
    presetGroupRef,
    presetGroupRefs,
    presetGroupKey,
    dedupePresetRefs,
    makePresetRefResolver,
    resolvePresetGroupRefs,
    extractAndValidateGroupName,
    findPostButton,
    waitForPostButton,
    findShareButton,
    markAndCacheButton,
    findButtonByLocation,
    findShareDialog,
    normalizeGroupNameForMatch,
    stripInvisibleMarks,
    extractGroupIdFromRow,
    rememberGroupId,
    getKnownGroupId,
    getFacebookUserIdCore,
    Inventory,
    Profile,
    getGroupNames,
    findGroupElementByName,
    findGroupOptionInMenu,
    clickMoreOptionsIfPresent,
    clickShareToGroupOption,
    reopenShareDialog,
    searchForGroupInDialog,
    findGroupListScrollContainer,
    scrollSearchResultsForExactMatch,
    scrollToLoadAllGroups,
    typeIntoFacebookTextarea,
    fillPostContent,
    fillNativeInput,
    detectScheduleSuccess,
    schedulePost,
    handleQuickShare,
    handleMultiPost,
    shareToSelectedGroups,
    useOneClickTemplateDirectly,
    fetchPagePosts,
    getAllJoinedGroups,
    getAutoShareGroupRotation
  });

})();
