<?php
/**
 * Central Cleanup Service for MCQ Video Studio artifacts.
 *
 * Owns all filesystem cleanup the plugin depends on. Registered as a single
 * daily cron (`mcqvs_daily_artifact_prune`) by VS_Core::init(). Retention is
 * per-category and admin-configurable (empty = disabled, no defaults).
 *
 * Categories covered:
 *   uploads/mcq-video-studio/
 *     tts/         — TTS MP3 cache     (class-vs-ajax-tts-handler.php:88,154)
 *     covers/      — Cover PNG cache   (class-vs-headless-renderer.php:938)
 *     generated/   — Local-render MP4s (class-vs-ajax-video-url-handler.php:485)
 *     exports/     — Batch-encoded MP4s(class-vs-ajax-batch-handler.php:274)
 *     batch/       — Per-job frames    (class-vs-ajax-batch-handler.php:111)
 *   {get_temp_dir()}/mcqvs_*  (PHP + Node render temps, one dir on default installs)
 *
 * The five-minute safety-net crons (`mcqvs_orphan_kill_cron`,
 * `mcqvs_render_liveness`) and per-job cleanup methods
 * (`VS_Headless_Renderer::cleanup_render_artifacts`,
 * `VS_AJAX_Batch_Handler::cleanup_frames`) remain untouched — the daily cron
 * here is the safety net for the paths they miss (crashed renders, partial
 * uploads, Node-side leftovers).
 *
 * @package MCQ_Video_Studio
 */

if (! defined('ABSPATH')) {
    exit;
}

class VS_Artifact_Cleanup
{
    /** Cron hook. */
    public const CRON_HOOK = 'mcqvs_daily_artifact_prune';

    /** Sentinel meaning "feature disabled / admin hasn't set a value". */
    public const DISABLED = -1;

    /** Sub-trees we own inside uploads/mcq-video-studio/. */
    private const UPLOAD_SUBDIRS = array('tts', 'covers', 'generated', 'exports');

    /** Sanitize range for retention (days). 0 and -1 both disable. */
    public const RETENTION_MIN_DAYS = 0;
    public const RETENTION_MAX_DAYS = 365;

    /** Terminal job statuses per VS_Schema::get_job_statuses() (line 151). */
    private const TERMINAL_STATUSES = array('completed', 'failed', 'cancelled');

    private static $instance = null;

    /**
     * Lazy terminal-job cache. Populated on first prune run per request.
     * @var array<string,bool>|null
     */
    private $terminal_cache = null;

    public static function init()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        // Cron handler — single entrypoint for everything.
        add_action(self::CRON_HOOK, array($this, 'run_daily_artifact_prune'));

        // Idempotent schedule registration. Mirror VS_Error_Logger::init()
        // (class-vs-error-logger.php:89-92) so the two daily jobs are
        // independent and share no failure surface.
        if (! wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time() + 3600, 'daily', self::CRON_HOOK);
        }

        // AJAX for "Run cleanup now" button. Nonce matches every other
        // settings-page action (mcqvs_studio_nonce — see class-vs-settings.php:1243).
        add_action('wp_ajax_mcqvs_run_artifact_cleanup', array($this, 'ajax_run_cleanup_now'));
    }

    // ------------------------------------------------------------------
    //  PUBLIC API
    // ------------------------------------------------------------------

    /**
     * Single entrypoint. Walks every category, enforces its retention window,
     * never throws (logs and continues). Safe to call from cron or AJAX.
     *
     * @return array Stats: ['tts'=>N, 'covers'=>N, 'generated'=>N, 'exports'=>N,
     *                       'batch'=>N, 'render_temp'=>N, 'temp'=>N, 'bytes'=>N,
     *                       'duration_ms'=>N, 'dry_run'=>bool]
     */
    public function run_daily_artifact_prune()
    {
        $started  = microtime(true);
        $dry_run  = (bool) $this->option('dry_run');

        $stats = array(
            'tts'         => 0,
            'covers'      => 0,
            'generated'   => 0,
            'exports'     => 0,
            'batch'       => 0,
            'render_temp' => 0,
            'temp'        => 0,
            'bytes'       => 0,
            'dry_run'     => $dry_run,
        );

        // --- uploads/mcq-video-studio/{tts,covers,generated,exports}/ ---
        $base = $this->uploads_base();
        if ($base !== '') {
            foreach (self::UPLOAD_SUBDIRS as $sub) {
                $key = $sub;
                $days = $this->option($key);
                if ($days <= 0) {
                    continue; // disabled or admin hasn't set a value
                }
                $stats[$key] = $this->prune_flat_dir(
                    $base . '/' . $sub,
                    $days,
                    $dry_run,
                    $stats
                );
            }

            // batch/{job_id}/ — each job gets its own subdir with frames,
            // output.mp4, chunk_*.zip. Per-job subtree ownership check vs
            // wp_vs_jobs.status before deletion.
            $batch_days = $this->option('batch');
            if ($batch_days > 0) {
                $stats['batch'] = $this->prune_batch_subdirs(
                    $base . '/batch',
                    $batch_days,
                    $dry_run,
                    $stats
                );
            }
        }

        // --- {get_temp_dir()}/mcqvs_* ---
        // get_temp_dir() and sys_get_temp_dir() resolve to the same dir on
        // default WP installs (WP falls back to sys_get_temp_dir() when no
        // WP_TEMP_DIR constant is set — see wp-includes/functions.php).
        // Both PHP and Node writers drop files here with the `mcqvs_` prefix.
        //
        // PHP render side (VS_Headless_Renderer.php:586-592, 622):
        //   mcqvs_payload_<job>.json
        //   mcqvs_status_<job>.json
        //   mcqvs_renderlog_<job>.log
        //   mcqvs_exit_<job>
        //   mcqvs_<job>.mp4  (render output)
        //
        // Node/PHP-bridge side (render-node.js:96,204 + media-prep.js:191,330,401):
        //   mcqvs_audio_<job>.wav
        //   mcqvs_bgframes_*/  (mkdtemp dir)
        //   mcqvs_sfx_<rand>.mp3
        //   mcqvs_video_<rand>.<ext>  (downloaded stock)
        //   mcqvs_r2_*, mcqvs_video_*, mcqvs_tts_err_*  (PHP helpers)
        //
        // Globs are deliberately DISJOINT — render_temp matches only the
        // PHP-side prefix set; temp matches only the Node-side prefix set.
        // This means the same file is never double-counted or double-deleted.
        $temp = get_temp_dir();
        if (is_dir($temp)) {
            $render_temp_days = $this->option('render_temp');
            if ($render_temp_days > 0) {
                $stats['render_temp'] = $this->prune_glob_disjoint(
                    $temp,
                    array('mcqvs_payload_*', 'mcqvs_status_*', 'mcqvs_renderlog_*', 'mcqvs_exit_*'),
                    array('json', 'log', 'txt', ''),
                    $render_temp_days,
                    $dry_run,
                    $stats
                );
                // Catch-all for the renderer's out_path file
                // (VS_Headless_Renderer.php:595: mcqvs_<job_id>.mp4).
                // Job IDs always start with 'vs_' (class-vs-job-repository.php:389:
                // "$job_id = 'vs_' . uniqid() . '_' . wp_rand(...)"), so this file is
                // ALWAYS `mcqvs_vs_*.mp4`. Narrowing to that prefix keeps it disjoint
                // from Node's `mcqvs_video_*.mp4` (media-prep.js:182,330) — a broad
                // `mcqvs_*.mp4` catch-all would double-count those.
                $stats['render_temp'] += $this->prune_glob_disjoint(
                    $temp,
                    array('mcqvs_vs_*.mp4'),
                    array('mp4'),
                    $render_temp_days,
                    $dry_run,
                    $stats
                );
            }
            $node_temp_days = $this->option('temp');
            if ($node_temp_days > 0) {
                $stats['temp'] = $this->prune_glob_disjoint(
                    $temp,
                    array(
                        'mcqvs_audio_*',   // render-node.js:204 (wav voiceover)
                        'mcqvs_bgframes_*',// media-prep.js:191 (mkdtemp dir)
                        'mcqvs_sfx_*',     // media-prep.js:401 (sfx mp3)
                        'mcqvs_video_*',   // media-prep.js:182,330 (stock video/webm)
                    ),
                    null,
                    $node_temp_days,
                    $dry_run,
                    $stats
                );

                // PHP tempnam() producers. On Windows `tempnam($dir,'mcqvs_X')`
                // truncates the prefix to ~3 chars (mcq + 5 hex) → `mcqD25C.tmp`.
                // On Linux the full prefix is preserved. Catch both without
                // double-counting: Linux files get the full-prefix glob; the
                // truncated Windows output is owned by the `mcq*.tmp` glob.
                // The truncated sweep enforces a 7-day hard floor because
                // tempnam files often have second-to-minute lifetimes.
                $stats['temp'] += $this->prune_glob_disjoint(
                    $temp,
                    array('mcqvs_r2_*', 'mcqvs_tts_err_*', 'mcqvs_asset_*'),
                    null,
                    $node_temp_days,
                    $dry_run,
                    $stats
                );
                if (DIRECTORY_SEPARATOR === '\\') {
                    $stats['temp'] += $this->prune_glob_disjoint(
                        $temp,
                        array('mcq*.tmp'),
                        array('tmp'),
                        max(7, $node_temp_days),
                        $dry_run,
                        $stats
                    );
                }
            }
        }

        // --- /tmp/mcqvs_exit_<job> ---
        // VS_Headless_Renderer.php:634 hardcodes '/tmp/mcqvs_exit_' + job_id
        // (regardless of WP_TEMP_DIR). Sweep only the literal /tmp path so we
        // don't double-count with the get_temp_dir() walker above. On hosts
        // without a literal /tmp dir (Windows where it's C:\Users\...\Temp,
        // already covered by get_temp_dir), skip.
        $literal_tmp = (DIRECTORY_SEPARATOR === '/') ? '/tmp/' : null;
        if ($literal_tmp !== null && is_dir($literal_tmp)) {
            $render_temp_days = $this->option('render_temp');
            if ($render_temp_days > 0 && $literal_tmp !== trailingslashit($temp)) {
                $stats['render_temp'] += $this->prune_glob_disjoint(
                    $literal_tmp,
                    array('mcqvs_exit_*'),
                    array('json', 'log', 'txt', ''),
                    $render_temp_days,
                    $dry_run,
                    $stats
                );
            }
        }

        $stats['duration_ms'] = (int) round((microtime(true) - $started) * 1000);

        if (class_exists('VS_Error_Logger')) {
            VS_Error_Logger::get_instance()->log(
                'Artifact prune complete: ' . wp_json_encode($stats),
                'info',
                array('_type' => 'artifact_prune', 'stats' => $stats)
            );
        }

        return $stats;
    }

    /**
     * AJAX handler used by the Settings page button. Returns the same stats
     * shape as run_daily_artifact_prune().
     */
    public function ajax_run_cleanup_now()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }
        $stats = $this->run_daily_artifact_prune();
        wp_send_json_success($stats);
    }

    // ------------------------------------------------------------------
    //  WALKERS
    // ------------------------------------------------------------------

    /**
     * Unlink files older than $days in a flat-ish directory. Removes empty
     * subdirs on the way out. Refuses to touch anything outside $dir.
     *
     * @param string $dir Absolute path to directory.
     * @param int    $days Retention window in days (caller guarantees > 0).
     * @param bool   $dry_run If true, count but do not delete.
     * @param array  $stats Pass-by-ref; accumulates 'bytes' freed.
     * @return int Files deleted (or that would be deleted in dry-run).
     */
    private function prune_flat_dir($dir, $days, $dry_run, array &$stats)
    {
        if (! is_dir($dir)) {
            return 0;
        }
        $dir_norm = wp_normalize_path($dir);
        $cutoff   = time() - ((int) $days * DAY_IN_SECONDS);
        $count    = 0;

        try {
            $iter = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS),
                RecursiveIteratorIterator::CHILD_FIRST
            );
        } catch (\Throwable $e) {
            return 0;
        }

        foreach ($iter as $entry) {
            $path = $entry->getPathname();
            // Defence-in-depth: never escape $dir.
            if (strpos(wp_normalize_path($path), $dir_norm) !== 0) {
                continue;
            }
            try {
                $mtime = $entry->getMTime();
            } catch (\Throwable $e) {
                continue;
            }
            if ($mtime >= $cutoff) {
                continue;
            }
            if ($entry->isDir()) {
                if (! $dry_run) {
                    @rmdir($path);
                }
                continue;
            }
            $size = (int) $entry->getSize();
            if (! $dry_run) {
                @unlink($path);
            }
            $stats['bytes'] += $size;
            $count++;
        }
        return $count;
    }

    /**
     * batch/{job_id}/ — owner-aware. For each job subdir: if older than $days,
     * check whether the job is terminal in `wp_vs_jobs`. If yes OR if the
     * job is unknown (orphaned), delete the entire subtree. Active jobs
     * (pending/rendering/uploading/ready_for_render) are left alone.
     */
    private function prune_batch_subdirs($base, $days, $dry_run, array &$stats)
    {
        if (! is_dir($base)) {
            return 0;
        }
        $cutoff = time() - ((int) $days * DAY_IN_SECONDS);
        $count  = 0;

        $job_dirs = @glob($base . '/*', GLOB_ONLYDIR);
        if (! $job_dirs) {
            return 0;
        }

        // Pull terminal statuses once per prune pass.
        $terminal_ids = $this->terminal_job_ids();

        foreach ($job_dirs as $job_dir) {
            $job_id = basename($job_dir);
            $mtime  = @filemtime($job_dir);
            if ($mtime === false || $mtime >= $cutoff) {
                continue;
            }

            $is_terminal = isset($terminal_ids[$job_id]);
            $is_unknown  = ! $this->job_exists($job_id);

            // Only delete batch subdirs whose job is terminal OR orphaned.
            // Active jobs (pending/rendering/uploading/ready_for_render) are
            // never touched here — we don't know if frames are mid-encode.
            if (! $is_terminal && ! $is_unknown) {
                continue;
            }

            // Measure subtree size before deletion (for byte savings).
            $subtree_bytes = $dry_run ? 0 : $this->dir_size($job_dir);
            if (! $dry_run) {
                $this->rrmdir($job_dir);
            }
            $stats['bytes'] += $subtree_bytes;
            $count++;
        }
        return $count;
    }

    /**
     * Generic glob-based sweeper. Matches everything starting with `mcqvs_`
     * in $temp and deletes files older than $days. If $exts is non-null it
     * filters to those extensions. $exts=null means "any extension".
     * Dir-mode matches (e.g. `mcqvs_bgframes_*`) are recursed with rrmdir().
     *
     * @deprecated Kept for backward compatibility. Use prune_glob_disjoint
     *             for category walkers — it takes explicit prefix patterns
     *             so multiple walkers on the same dir cannot double-count.
     */
    private function prune_glob($pattern, $exts, $days, $dry_run, array &$stats)
    {
        $cutoff = time() - ((int) $days * DAY_IN_SECONDS);
        $count  = 0;
        $files  = @glob($pattern);
        if (! $files) {
            return 0;
        }
        return $this->collect_and_delete($files, $exts, $cutoff, $dry_run, $stats);
    }

    /**
     * Disjoint glob walker. Each prefix in $prefixes becomes its own glob,
     * results are concatenated then deduplicated. This guarantees a file
     * matched by one category walker is never picked up by another.
     *
     * @param string $dir       Absolute directory (no trailing slash needed).
     * @param array  $prefixes  List of glob patterns relative to $dir.
     * @param array  $exts      Extension whitelist; null = any; '' = no extension.
     * @param int    $days      Retention window.
     * @param bool   $dry_run
     * @param array  $stats     Pass-by-ref; accumulates 'bytes'.
     * @return int Files deleted (or that would be in dry-run).
     */
    private function prune_glob_disjoint($dir, $prefixes, $exts, $days, $dry_run, array &$stats)
    {
        $cutoff = time() - ((int) $days * DAY_IN_SECONDS);
        $seen   = array();
        $files  = array();
        foreach ($prefixes as $prefix) {
            $matches = @glob(trailingslashit($dir) . $prefix);
            if (! $matches) {
                continue;
            }
            foreach ($matches as $m) {
                $key = wp_normalize_path($m);
                if (isset($seen[$key])) {
                    continue;
                }
                $seen[$key] = true;
                $files[] = $m;
            }
        }
        return $this->collect_and_delete($files, $exts, $cutoff, $dry_run, $stats);
    }

    /**
     * Shared delete logic for the glob walkers. Splits file vs dir, applies
     * age + extension filters, accumulates byte count.
     */
    private function collect_and_delete(array $files, $exts, $cutoff, $dry_run, array &$stats)
    {
        $count = 0;
        foreach ($files as $f) {
            if (is_dir($f)) {
                $mtime = @filemtime($f);
                if ($mtime === false || $mtime >= $cutoff) {
                    continue;
                }
                $subtree_bytes = $dry_run ? 0 : $this->dir_size($f);
                if (! $dry_run) {
                    $this->rrmdir($f);
                }
                $stats['bytes'] += $subtree_bytes;
                $count++;
                continue;
            }
            if ($exts !== null) {
                $ext = strtolower(pathinfo($f, PATHINFO_EXTENSION));
                if (! in_array($ext, $exts, true)) {
                    continue;
                }
            }
            $mtime = @filemtime($f);
            if ($mtime === false || $mtime >= $cutoff) {
                continue;
            }
            $size = (int) @filesize($f);
            if (! $dry_run) {
                @unlink($f);
            }
            $stats['bytes'] += $size;
            $count++;
        }
        return $count;
    }

    // ------------------------------------------------------------------
    //  HELPERS
    // ------------------------------------------------------------------

    /**
     * Read a retention option with the disabled sentinel applied.
     * Empty / unset → DISABLED (-1). 0 → also disabled. > 0 → that many days.
     *
     * NB: the `dry_run` key is a boolean flag, not a retention window. It is
     * stored as 0/1 in `mcqvs_artifact_retention_dry_run` and returned as the
     * raw integer here (callers cast to bool). Returning -1 for "unset"
     * makes the boolean false by accident — see `run_daily_artifact_prune`.
     */
    private function option($key)
    {
        if ($key === 'dry_run') {
            return (int) get_option('mcqvs_artifact_retention_dry_run', 0);
        }
        $opt = (int) get_option('mcqvs_artifact_retention_' . $key, self::DISABLED);
        if ($opt < 0) {
            return self::DISABLED;
        }
        if ($opt > self::RETENTION_MAX_DAYS) {
            return self::RETENTION_MAX_DAYS;
        }
        return $opt;
    }

    /**
     * uploads/mcq-video-studio base. Returns '' if uploads dir not writable.
     */
    private function uploads_base()
    {
        $u = wp_upload_dir();
        if (! empty($u['error']) || empty($u['basedir'])) {
            return '';
        }
        $base = trailingslashit($u['basedir']) . 'mcq-video-studio';
        if (! is_dir($base)) {
            // Don't auto-create — never write during a cleanup pass.
            return '';
        }
        return $base;
    }

    /**
     * Cache of terminal job IDs from wp_vs_jobs. Status column hardcoded
     * 'status' per VS_Job_Repository (see line 461, 731, 1100) — there is
     * NO get_status_column() method.
     *
     * @return array<string,bool> Set of terminal job_id values.
     */
    private function terminal_job_ids()
    {
        if ($this->terminal_cache !== null) {
            return $this->terminal_cache;
        }
        $this->terminal_cache = array();
        if (! class_exists('VS_Job_Repository')) {
            return $this->terminal_cache;
        }
        try {
            global $wpdb;
            $table = VS_Job_Repository::get_table_name();
            // Hardcoded status column matches every other query in
            // class-vs-job-repository.php (lines 461, 731, 733, 1100, etc.).
            $placeholders = implode(',', array_fill(0, count(self::TERMINAL_STATUSES), '%s'));
            $sql          = "SELECT job_id FROM {$table} WHERE status IN ({$placeholders})";
            $prepared     = call_user_func_array(array($wpdb, 'prepare'), array_merge(array($sql), self::TERMINAL_STATUSES));
            $rows         = $wpdb->get_results($prepared, 'ARRAY_A');
            foreach ((array) $rows as $r) {
                if (! empty($r['job_id'])) {
                    $this->terminal_cache[(string) $r['job_id']] = true;
                }
            }
        } catch (\Throwable $e) {
            // Leave cache empty — unknown jobs will still be eligible for
            // prune by age (the $is_unknown path in prune_batch_subdirs).
        }
        return $this->terminal_cache;
    }

    /**
     * Lightweight "does this job_id exist in wp_vs_jobs?" check.
     * @return bool
     */
    private function job_exists($job_id)
    {
        if ($job_id === '' || ! class_exists('VS_Job_Repository')) {
            return false;
        }
        try {
            global $wpdb;
            $table = VS_Job_Repository::get_table_name();
            $found = $wpdb->get_var($wpdb->prepare(
                "SELECT 1 FROM {$table} WHERE job_id = %s LIMIT 1",
                $job_id
            ));
            return ! empty($found);
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Recursive remove. Used for batch subdirs and Node temp dirs.
     * Refuses to follow symlinks (defence-in-depth against symlink-attack
     * inside shared /tmp on shared hosting).
     *
     * @param string $dir Absolute path.
     */
    private function rrmdir($dir)
    {
        if (! is_dir($dir)) {
            return;
        }
        try {
            $iter = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS),
                RecursiveIteratorIterator::CHILD_FIRST
            );
        } catch (\Throwable $e) {
            return;
        }
        foreach ($iter as $entry) {
            $path = $entry->getPathname();
            try {
                $is_link = $entry->isLink();
            } catch (\Throwable $e) {
                $is_link = false;
            }
            if ($is_link) {
                @unlink($path);
                continue;
            }
            if ($entry->isDir()) {
                @rmdir($path);
                continue;
            }
            @unlink($path);
        }
        @rmdir($dir);
    }

    /**
     * Sum of file sizes in a directory subtree. Used for byte stats in
     * dry-run mode and before destructive deletes.
     */
    private function dir_size($dir)
    {
        $bytes = 0;
        try {
            $iter = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS),
                RecursiveIteratorIterator::LEAVES_ONLY
            );
        } catch (\Throwable $e) {
            return 0;
        }
        foreach ($iter as $entry) {
            try {
                if ($entry->isLink()) {
                    continue;
                }
                $bytes += (int) $entry->getSize();
            } catch (\Throwable $e) {
                // ignore
            }
        }
        return $bytes;
    }
}
