<?php
/**
 * AI Social Collage — Hashtag Pipeline DRY-RUN (real log data)
 *
 * Replays the FULL hashtag producer→consumer chain with REAL data extracted
 * from ai-collage-logs-*.csv, simulating the pre-change WordPress state
 * (source slug categories/tags like apify/divamagzine/magnews/allaboutpakistan)
 * and verifying the post-change code emits ONLY AI-generated hashtags.
 *
 * Run:  php tests/test-hashtag-dryrun.php <path-to-real-data.json>
 */

if ( $argc < 2 || ! file_exists( $argv[1] ) ) {
    fwrite( STDERR, "Usage: php tests/test-hashtag-dryrun.php <real_data.json>\n" );
    exit( 2 );
}

$realJson = file_get_contents( $argv[1] );
if ( substr( $realJson, 0, 3 ) === "\xEF\xBB\xBF" ) {
    $realJson = substr( $realJson, 3 );
}
$real     = json_decode( $realJson, true );
$jobs     = $real['jobs'] ?? [];
if ( empty( $jobs ) ) {
    fwrite( STDERR, "No real AI hashtag jobs found in data file.\n" );
    exit( 2 );
}

// ───────────────────────────────────────────────────────────────────────────
//  WORDPRESS FUNCTION STUBS + IN-MEMORY STORE
// ───────────────────────────────────────────────────────────────────────────

$GLOBALS['__post_meta'] = [];
$GLOBALS['__post_tags'] = [];
$GLOBALS['__post_cats'] = [];
$GLOBALS['__options']   = [];

define( 'ABSPATH', __DIR__ . '/../' );

function __meta_get( $pid, $key ) {
    return $GLOBALS['__post_meta'][ (int) $pid ][ $key ] ?? false;
}
function __meta_set( $pid, $key, $val ) {
    $GLOBALS['__post_meta'][ (int) $pid ][ $key ] = $val;
}

if ( ! function_exists( 'get_post_meta' ) ) {
    function get_post_meta( $post_id, $key = '', $single = false ) {
        return __meta_get( $post_id, $key );
    }
}
if ( ! function_exists( 'update_post_meta' ) ) {
    function update_post_meta( $post_id, $meta_key, $meta_value, $prev_value = '' ) {
        __meta_set( $post_id, $meta_key, $meta_value );
        return true;
    }
}
if ( ! function_exists( 'add_post_meta' ) ) {
    function add_post_meta( $post_id, $meta_key, $meta_value, $unique = false ) {
        __meta_set( $post_id, $meta_key, $meta_value );
        return true;
    }
}
if ( ! function_exists( 'delete_post_meta' ) ) {
    function delete_post_meta( $post_id, $meta_key, $meta_value = '' ) {
        unset( $GLOBALS['__post_meta'][ (int) $post_id ][ $meta_key ] );
        return true;
    }
}
if ( ! function_exists( 'get_post' ) ) {
    function get_post( $post_id ) {
        $obj = new stdClass();
        $obj->ID            = (int) $post_id;
        $obj->post_title    = 'Dry run post ' . (int) $post_id;
        $obj->post_content  = 'Dry run content';
        $obj->post_status   = 'publish';
        $obj->post_type     = 'post';
        return $obj;
    }
}
if ( ! function_exists( 'get_post_field' ) ) {
    function get_post_field( $field, $post_id ) {
        if ( $field === 'post_title' ) return 'Dry run post ' . (int) $post_id;
        if ( $field === 'post_content' ) return 'Dry run content';
        return '';
    }
}
if ( ! function_exists( 'get_option' ) ) {
    function get_option( $key, $default = false ) {
        return array_key_exists( $key, $GLOBALS['__options'] ) ? $GLOBALS['__options'][ $key ] : $default;
    }
}
if ( ! function_exists( 'update_option' ) ) {
    function update_option( $key, $value, $autoload = true ) {
        $GLOBALS['__options'][ $key ] = $value;
        return true;
    }
}
if ( ! function_exists( 'delete_option' ) ) {
    function delete_option( $key ) {
        unset( $GLOBALS['__options'][ $key ] );
        return true;
    }
}
if ( ! function_exists( 'get_transient' ) ) { function get_transient( $k ) { return false; } }
if ( ! function_exists( 'set_transient' ) ) { function set_transient() {} }
if ( ! function_exists( 'delete_transient' ) ) { function delete_transient() {} }
if ( ! function_exists( 'sanitize_text_field' ) ) { function sanitize_text_field( $s ) { return trim( (string) $s ); } }
if ( ! function_exists( 'sanitize_key' ) ) { function sanitize_key( $s ) { return $s; } }
if ( ! function_exists( 'is_wp_error' ) ) { function is_wp_error( $t ) { return $t instanceof WP_Error; } }
if ( ! function_exists( 'wp_trim_words' ) ) { function wp_trim_words( $t, $n = 30 ) { $w = preg_split('/\s+/', trim( strip_tags( $t ) ) ); return implode( ' ', array_slice( $w, 0, $n ) ); } }
if ( ! function_exists( 'wp_strip_all_tags' ) ) { function wp_strip_all_tags( $t ) { return strip_tags( (string) $t ); } }
if ( ! function_exists( 'get_permalink' ) ) { function get_permalink( $pid = 0 ) { return 'https://example.test/?p=' . (int) $pid; } }
if ( ! function_exists( 'wp_get_attachment_url' ) ) { function wp_get_attachment_url( $id = 0 ) { return ''; } }
if ( ! function_exists( 'get_attached_file' ) ) { function get_attached_file( $id = 0 ) { return ''; } }
if ( ! function_exists( 'current_time' ) ) { function current_time( $type = 'mysql' ) { return $type === 'mysql' ? date( 'Y-m-d H:i:s' ) : time(); } }
if ( ! function_exists( 'get_post_mime_type' ) ) { function get_post_mime_type( $id = 0 ) { return ''; } }
if ( ! function_exists( 'get_bloginfo' ) ) { function get_bloginfo( $k = '' ) { return 'DryRun Blog'; } }
if ( ! function_exists( 'mb_check_encoding' ) ) { function mb_check_encoding( $s, $enc = null ) { $e = $enc ?: mb_internal_encoding(); return mb_convert_encoding( $s, $e, $e ) !== false; } }

// Logger writes via $wpdb; provide a no-op DB handle so dispatch logging is real-but-harmless.
$GLOBALS['wpdb'] = new class {
    public $prefix = 'wp_';
    public function get_var( $q ) { return null; }
    public function insert( $t, $d, $f = [] ) { return true; }
    public function update( $t, $d, $w, $f = [], $fw = [] ) { return true; }
    public function prepare( $q, ...$a ) { return $q; }
    public function query( $q ) { return 0; }
    public function get_row( $q ) { return null; }
    public function get_results( $q ) { return []; }
    public function esc_like( $s ) { return $s; }
};

class WP_Error {
    private $code, $msg;
    public function __construct( $code = '', $msg = '' ) { $this->code = $code; $this->msg = $msg; }
    public function get_error_message() { return $this->msg; }
}

/**
 * WordPress-side taxonomy state simulated as the pipeline creates it.
 * wp_set_post_tags(..., true) MERGES AI tags into existing source tags.
 */
if ( ! function_exists( 'wp_set_post_tags' ) ) {
    function wp_set_post_tags( $post_id, $tags, $append = false ) {
        $existing = $GLOBALS['__post_tags'][ (int) $post_id ] ?? [];
        $incoming = is_array( $tags ) ? $tags : array_map( 'trim', explode( ',', (string) $tags ) );
        if ( $append ) {
            $merged = array_values( array_unique( array_merge( $existing, $incoming ) ) );
        } else {
            $merged = array_values( array_unique( $incoming ) );
        }
        $GLOBALS['__post_tags'][ (int) $post_id ] = $merged;
        return true;
    }
}

// Categories are set from feed/source config (slug names).
if ( ! function_exists( 'get_the_category' ) ) {
    function get_the_category( $post_id = 0 ) {
        if ( ! isset( $GLOBALS['__post_cats'][ (int) $post_id ] ) ) {
            return [];
        }
        $out = [];
        foreach ( $GLOBALS['__post_cats'][ (int) $post_id ] as $name ) {
            $obj = new stdClass();
            $obj->name = $name;
            $obj->slug = sanitize_title2( $name );
            $out[] = $obj;
        }
        return $out;
    }
}
if ( ! function_exists( 'get_the_tags' ) ) {
    function get_the_tags( $post_id = 0 ) {
        if ( empty( $GLOBALS['__post_tags'][ (int) $post_id ] ) ) return false;
        $out = [];
        foreach ( $GLOBALS['__post_tags'][ (int) $post_id ] as $name ) {
            $obj = new stdClass();
            $obj->name = $name;
            $obj->slug = sanitize_title2( $name );
            $out[] = $obj;
        }
        return $out;
    }
}
if ( ! function_exists( 'sanitize_title2' ) ) {
    function sanitize_title2( $str ) {
        return strtolower( preg_replace( '/[^a-zA-Z0-9\-]/', '-', trim( $str ) ) );
    }
}
function wp_set_cats( $post_id, $names ) {
    $GLOBALS['__post_cats'][ (int) $post_id ] = $names;
}

// ───────────────────────────────────────────────────────────────────────────
//  LOAD PLUGIN CLASSES (REAL MODIFIED CODE)
// ───────────────────────────────────────────────────────────────────────────

$base = __DIR__ . '/../core/';
require_once $base . 'Config.php';
require_once $base . 'Logger.php';
require_once $base . 'Services/SocialBridge.php';
require_once $base . 'Services/BufferIntegration.php';
require_once $base . 'Services/JetpackSocial.php';

use AiSocialCollage\Config;
use AiSocialCollage\Services\SocialBridge;
use AiSocialCollage\Services\BufferIntegration;
use AiSocialCollage\Services\JetpackSocial;

// Reflection helpers to invoke PRIVATE consumers exactly as the pipeline does.
function reflect_call( string $class, string $method, array $args ) {
    $ref = new \ReflectionMethod( $class, $method );
    $ref->setAccessible( true );
    return $ref->invokeArgs( null, $args );
}

// ───────────────────────────────────────────────────────────────────────────
//  SCENARIO
// ───────────────────────────────────────────────────────────────────────────

// Feed source slugs set as WP CATEGORIES — these are the exact class of junk
// (apify/divamagzine/magnews/allaboutpakistan) that used to leak as hashtags.
$source_slugs = [ 'apify', 'divamagzine', 'magnews', 'allaboutpakistan', 'showbiz' ];
$FORBIDDEN_SET = [ '#Apify', '#Divamagzine', '#Magnews', '#Allaboutpakistan', '#ApifyShowbiz' ];

$passed = 0;
$failed = 0;
$failMsg = [];
$matrix = [];

function assert_eq( string $name, $actual, $expected, string $detail = '' ) {
    global $passed, $failed, $failMsg;
    $ok = ( $actual === $expected ) || ( is_array( $expected ) && is_array( $actual ) && $actual == $expected );
    if ( $ok ) {
        $passed++;
        echo "  PASS  {$name}\n";
    } else {
        $failed++;
        $m = "  FAIL  {$name}";
        if ( $detail ) $m .= " — {$detail}";
        $m .= " expected=" . var_export( $expected, true ) . " actual=" . var_export( $actual, true );
        $failMsg[] = $m;
        echo "{$m}\n";
    }
}
function assert_true( string $name, $condition, string $detail = '' ) {
    global $passed, $failed, $failMsg;
    if ( $condition ) {
        $passed++;
        echo "  PASS  {$name}\n";
    } else {
        $failed++;
        $m = "  FAIL  {$name}" . ( $detail ? " — {$detail}" : '' );
        $failMsg[] = $m;
        echo "{$m}\n";
    }
}
function assert_no_forbidden_tags( string $name, string $tagStr, string $detail = '' ) {
    global $passed, $failed, $failMsg, $FORBIDDEN_SET;
    $found = [];
    foreach ( $FORBIDDEN_SET as $forbidden ) {
        if ( stripos( $tagStr, $forbidden ) !== false ) {
            $found[] = $forbidden;
        }
    }
    if ( empty( $found ) ) {
        $passed++;
        echo "  PASS  {$name}\n";
    } else {
        $failed++;
        $m = "  FAIL  {$name} — leaked: " . implode( ',', $found ) . ( $detail ? " | {$detail}" : '' );
        $failMsg[] = $m;
        echo "{$m}\n";
    }
}

echo "\n══════════════════════════════════════════════════════════════\n";
echo "  REAL DATA: " . count( $jobs ) . " AI-hashtag sets pulled from logs\n";
echo "══════════════════════════════════════════════════════════════\n\n";

$post_id = 50001; // synthetic post id (logs expose post ids; content model is identical)
$i = 0;
foreach ( $jobs as $key => $job ) {
    $i++;
    $aiHash = $job['hashtags'];
    $aiX    = $job['x_hashtags'];

    // ── 1. PRODUCER: step_rewrite (QueueProcessor.php:469-497) ────────────
    //   a) Store META_AUTO_META['ai_hashtags'] (real AI hashtags)
    //   b) wp_set_post_tags(..., $tag_names, true) → APPEND to existing tags
    $auto_meta = [
        'ai_hashtags'   => $aiHash,
        'ai_headline'   => $job['headline'],
        'ai_hook'       => 'Replayed hook from log',
        'x_hashtags'    => $aiX,
        'x_description' => 'Replay x desc',
        'ai_x_hashtags' => $aiX,
    ];
    __meta_set( $post_id, Config::META_AUTO_META, $auto_meta );

    // Producer side-effect: append='true' merges AI tags into EXISTING source tags.
    wp_set_post_tags( $post_id, array_map( function ( $t ) { return ltrim( $t, '#' ); }, $aiHash ), true );

    // Pre-existing source-tag state (reflects real pre-patch WP taxonomy):
    // WP tags on the post = source tags (from ingest) + AI tags (appended).
    wp_set_post_tags( $post_id, [ 'apify', 'showbiz' ], true );
    wp_set_cats( $post_id, $source_slugs );

    // ── 2. CONSUMERS (all read the REAL modified code) ────────────────────
    $sb  = reflect_call( SocialBridge::class, 'generate_hashtags', [ get_post( $post_id ), [] ] );
    $buf = reflect_call( BufferIntegration::class, 'get_hashtags', [ $post_id ] );
    $jp  = reflect_call( JetpackSocial::class, 'get_hashtags', [ $post_id ] );

    // ── 3. Assert consumers are IDENTICAL (no SSOT split) ─────────────────
    assert_eq( "job#{$i} SocialBridge == BufferIntegration hashtags", strip_lrm( $buf ), normalize( $sb ), 'buffer=' . strip_lrm( $buf ) );
    assert_eq( "job#{$i} BufferIntegration == JetpackSocial hashtags", strip_lrm( $buf ), normalize( $jp ), 'buffer=' . strip_lrm( $buf ) );

    // ── 4. Assert ONLY AI tags present, no source-slug pollution ──────────
    assert_no_forbidden_tags( "job#{$i} SocialBridge pure AI", $sb );
    assert_no_forbidden_tags( "job#{$i} Buffer pure AI", strip_lrm( $buf ) );
    assert_no_forbidden_tags( "job#{$i} Jetpack pure AI", $jp );

    // ── 5. Assert returned tags are a SUBSET of the AI-generated set ────
    $sbSet  = explode( ' ', normalize( $sb ) );
    $aiSet  = array_map( 'normalize', $aiHash );
    foreach ( $sbSet as $t ) {
        if ( $t === '' ) continue;
        assert_true( "job#{$i} SocialBridge tag '{$t}' ∈ AI set", in_array( normalize( $t ), $aiSet, true ), 'AI=' . implode( ',', $aiSet ) );
    }

    // ── 6. QUEUE PROCESSOR POST-CONTENT APPEND (image + video paths) ─────
    $GLOBALS['__options'][ Config::OPTION_APPEND_TAGS_TO_POST ] = true;
    $post_content  = "Replay content\n";
    // Image path code (verbatim from step_render)
    $ai_hashtags = $auto_meta['ai_hashtags'] ?? [];
    if ( is_array( $ai_hashtags ) && ! empty( $ai_hashtags ) ) {
        $tag_strings = [];
        foreach ( array_slice( $ai_hashtags, 0, 5 ) as $tag ) {
            $tag_strings[] = '#' . preg_replace( '/[^\p{L}\p{N}]/u', '', ltrim( $tag, '#' ) );
        }
        $hashtags_str = implode( ' ', $tag_strings );
        if ( ! empty( $hashtags_str ) ) {
            $post_content .= "\n\n" . $hashtags_str;
        }
    }
    // Video path is byte-identical (QueueProcessor.php:1244).
    assert_no_forbidden_tags( "job#{$i} post-content append pure AI", $post_content );
    assert_true( "job#{$i} post-content has AI hashtag block", strpos( $post_content, "\n\n#" ) !== false );

    unset( $GLOBALS['__options'][ Config::OPTION_APPEND_TAGS_TO_POST ] );

    $matrix[ $i ] = [
        'headline'   => mb_substr( $job['headline'], 0, 40 ),
        'ai'         => implode( ' ', $aiHash ),
        'social'     => $sb,
        'buffer'     => strip_lrm( $buf ),
        'jetpack'    => $jp,
    ];

    $post_id++;
}

function normalize( string $s ): string {
    return trim( str_replace( "\xE2\x80\x8E", '', $s ) );
}
function strip_lrm( string $s ): string {
    return str_replace( "\xE2\x80\x8E", '', $s );
}

// ───────────────────────────────────────────────────────────────────────────
//  EMPTY-AI FALLBACK PATH: AI returns no hashtags → OLD code fell back to
//  categories (source slugs). NEW code must return EMPTY, not slugs.
// ───────────────────────────────────────────────────────────────────────────

echo "\n══════════════════════════════════════════════════════════════\n";
echo "  EDGE: AI hashtags EMPTY (old fallback would leak category slugs)\n";
echo "══════════════════════════════════════════════════════════════\n\n";

__meta_set( $post_id, Config::META_AUTO_META, [ 'ai_hashtags' => [], 'ai_headline' => 'No AI tags' ] );
wp_set_post_tags( $post_id, [ 'apify', 'divamagzine', 'magnews' ], false );
wp_set_cats( $post_id, [ 'apify', 'divamagzine', 'magnews', 'allaboutpakistan' ] );

$sb  = reflect_call( SocialBridge::class, 'generate_hashtags', [ get_post( $post_id ), [] ] );
$buf = reflect_call( BufferIntegration::class, 'get_hashtags', [ $post_id ] );
$jp  = reflect_call( JetpackSocial::class, 'get_hashtags', [ $post_id ] );

assert_eq( 'Empty AI → SocialBridge returns empty (no category fallback)', $sb, '' );
assert_eq( 'Empty AI → BufferIntegration returns empty', strip_lrm( $buf ), '' );
assert_eq( 'Empty AI → JetpackSocial returns empty', $jp, '' );

// ───────────────────────────────────────────────────────────────────────────
//  META_GENERATED_HASHTAGS (AutoHashtagGenerator write path) — still AI-only
// ───────────────────────────────────────────────────────────────────────────

echo "\n══════════════════════════════════════════════════════════════\n";
echo "  EDGE: META_GENERATED_HASHTAGS populated (AI, from AutoHashtagGenerator)\n";
echo "══════════════════════════════════════════════════════════════\n\n";

__meta_set( $post_id, Config::META_GENERATED_HASHTAGS, [ '#TrendingPakistan', '#BreakingNews' ] );
__meta_set( $post_id, Config::META_AUTO_META, [] );
wp_set_post_tags( $post_id, [ 'apify' ], false );

$buf = reflect_call( BufferIntegration::class, 'get_hashtags', [ $post_id ] );
$jp  = reflect_call( JetpackSocial::class, 'get_hashtags', [ $post_id ] );

assert_eq( 'META_GENERATED_HASHTAGS → Buffer AI only', strip_lrm( $buf ), '#TrendingPakistan #BreakingNews' );
assert_eq( 'META_GENERATED_HASHTAGS → Jetpack AI only', $jp, '#TrendingPakistan #BreakingNews' );

// ───────────────────────────────────────────────────────────────────────────
//  FULL-PAYLOAD CONTRACT: SocialBridge::dispatch → platform_texts + hashtags
//  Exercises the REAL build_payload → build_platform_text chain (producer→consumer).
// ───────────────────────────────────────────────────────────────────────────

echo "\n══════════════════════════════════════════════════════════════\n";
echo "  FULL-PAYLOAD CONTRACT (SocialBridge::build_payload → platform texts)\n";
echo "══════════════════════════════════════════════════════════════\n\n";

$captured_payloads = [];
if ( ! function_exists( 'do_action' ) ) {
    function do_action( $hook, ...$args ) {
        global $captured_payloads;
        $captured_payloads[] = $args[0];
    }
}

// Rebuild a realistic auto-meta from a real job (job #1) + source-slug taxonomy.
$replayPostId = 60001;
$replayMeta = $jobs ? reset( $jobs ) : [];
__meta_set( $replayPostId, Config::META_AUTO_META, [
    'ai_hashtags'          => $replayMeta['hashtags'] ?? [],
    'ai_headline'          => 'Replay headline',
    'ai_hook'              => 'Replay hook body text',
    'ai_detailed_description' => 'Replay detailed description body.',
    'ai_x_hashtags'        => $replayMeta['x_hashtags'] ?? [],
    'ai_x_description'     => 'Replay X description.',
    'x_content'            => 'Replay X description. ' . implode( ' ', array_slice( $replayMeta['x_hashtags'] ?? [], 0, 5 ) ),
] );
wp_set_post_tags( $replayPostId, [ 'apify', 'showbiz' ], false );
wp_set_cats( $replayPostId, $source_slugs );

$captured_payloads = [];
SocialBridge::dispatch( $replayPostId, 100, 1, 'Replay detailed description body.', 'Replay headline' );

$dispatchOk = ( count( $captured_payloads ) >= 1 );
assert_true( 'dispatch captured ≥1 payload', $dispatchOk );
if ( $dispatchOk ) {
    $payload = $captured_payloads[0];
    $combined = '';
    foreach ( ( $payload['platform_texts'] ?? [] ) as $text ) {
        $combined .= ' ' . $text;
    }
    $combined .= ' ' . ( $payload['hashtags'] ?? '' );
    $combined .= ' ' . ( $payload['x_hashtags'] ?? '' );

    // 1. The dispatch payload hashtags field must equal the AI set.
    $expected = implode( ' ', array_slice( $replayMeta['hashtags'] ?? [], 0, 5 ) );
    assert_eq( 'payload[hashtags] == AI only', $payload['hashtags'] ?? '', $expected );

    // 2. Combined platform text + hashtags must NOT contain any source slug/category.
    assert_no_forbidden_tags( 'payload platform_texts + hashtags pure AI', $combined );

    // 3. Every #tag inside combined output ∈ AI set (both hashtags and x_hashtags).
    preg_match_all( '/#[\p{L}\p{N}_]+/u', $combined, $m );
    $allowed = array_merge(
        array_map( 'normalize', $replayMeta['hashtags'] ?? [] ),
        array_map( 'normalize', $replayMeta['x_hashtags'] ?? [] )
    );
    $allowed = array_unique( $allowed );
    $bad = [];
    foreach ( array_unique( $m[0] ) as $t ) {
        if ( ! in_array( normalize( $t ), $allowed, true ) ) {
            $bad[] = $t;
        }
    }
    assert_eq( 'no tag outside AI sets in dispatch payload', $bad, [], 'unexpected=' . implode( ',', $bad ) );

    echo "  [payload] hashtags={$payload['hashtags']}\n";
    echo "  [payload] x_hashtags={$payload['x_hashtags']}\n";
    echo "  [payload] twitter  = " . wordwrap( mb_substr( $payload['platform_texts']['twitter'] ?? '', 0, 140 ), 100, "\n              " ) . "\n";
}

// ───────────────────────────────────────────────────────────────────────────
//  MATRIX
// ───────────────────────────────────────────────────────────────────────────

echo "\n══════════════════════════════════════════════════════════════\n";
echo "  CONSUMER AGREEMENT MATRIX (first 8 real jobs)\n";
echo "══════════════════════════════════════════════════════════════\n\n";
$shown = 0;
foreach ( $matrix as $row ) {
    if ( $shown >= 8 ) break;
    $agree = ( $row['social'] === $row['buffer'] && $row['buffer'] === $row['jetpack'] );
    printf( "  %-42s agree=%s\n", mb_substr( $row['headline'], 0, 40 ), $agree ? 'YES' : 'NO' );
    printf( "    AI      : %s\n", $row['ai'] );
    printf( "    Buffer  : %s\n", $row['buffer'] );
    $shown++;
}

echo "\n══════════════════════════════════════════════════════════════\n";
echo "  RESULTS: {$passed} passed, {$failed} failed\n";
echo "══════════════════════════════════════════════════════════════\n";

if ( $failed > 0 ) {
    echo "\n  FAILURES:\n";
    foreach ( $failMsg as $f ) echo "  {$f}\n";
    echo "\n";
    exit( 1 );
}
echo "\n  ALL DRY-RUN CHECKS PASSED ✓ (no consumer mismatch, no slug/category leakage)\n\n";
exit( 0 );