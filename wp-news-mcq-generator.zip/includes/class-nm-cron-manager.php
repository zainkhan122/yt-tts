<?php

/**
 * Cron Manager
 *
 * @package WP_News_MCQ_Generator
 * @version 2.1 - Re-implemented Feeder/Worker cron system for Current Affairs
 */

if (! defined('ABSPATH')) {
	exit;
}

class NM_Cron_Manager
{


	private static $instance = null;

	/**
	 * Get singleton instance.
	 */
	public static function init()
	{
		if (self::$instance === null) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor. Hooks into WordPress.
	 */
	private function __construct()
	{
		// Register custom cron intervals
		add_filter('cron_schedules', array(self::class, 'register_cron_intervals'), 1);

		// Register all cron action handlers
		add_action('init', array(self::class, 'register_all_cron_hooks'), 1);

		// Ensure crons are scheduled on load
		add_action('wp_loaded', array(self::class, 'ensure_crons_scheduled'), 1);

		// Reschedule crons when settings are changed
		add_action('update_option_nm_news_cron_schedule', array(self::class, 'schedule_all_crons'));
		add_action('update_option_nm_topic_cron_schedule', array(self::class, 'schedule_all_crons'));
		add_action('update_option_nm_feed_importer_enabled', array(self::class, 'schedule_all_crons'));
		add_action('update_option_nm_feed_importer_cron_schedule', array(self::class, 'schedule_all_crons'));
		add_action('update_option_nm_current_affairs_enabled', array(self::class, 'schedule_all_crons'));
		add_action('update_option_nm_current_affairs_cron_schedule', array(self::class, 'schedule_all_crons'));
		add_action('update_option_nm_pillar_generation_enabled', array(self::class, 'schedule_all_crons'));
		add_action('update_option_nm_article_generation_enabled', array(self::class, 'schedule_all_crons'));
		add_action('update_option_nm_pdf_archive_enabled', array(self::class, 'schedule_all_crons'));

		// AJAX handler for fixing crons
		add_action('wp_ajax_nm_ajax_reset_stuck_crons', array(self::class, 'ajax_reset_stuck_crons'));

		// Admin notice for cron health
		add_action('admin_notices', array(self::class, 'cron_health_notice'));
	}

	// ========================================================================
	// 1. INTERVAL & HOOK REGISTRATION
	// ========================================================================

	/**
	 * Register ALL custom cron intervals from V23
	 */
	public static function register_cron_intervals($schedules)
	{
		$intervals = array(
			'every_two_minutes'     => array(
				'interval' => 120,
				'display'  => 'Every 2 Minutes',
			),
			'every_five_minutes'    => array(
				'interval' => 300,
				'display'  => 'Every 5 Minutes',
			),
			'every_ten_minutes'     => array(
				'interval' => 600,
				'display'  => 'Every 10 Minutes',
			),
			'every_fifteen_minutes' => array(
				'interval' => 900,
				'display'  => 'Every 15 Minutes',
			),
			'every_thirty_minutes'  => array(
				'interval' => 1800,
				'display'  => 'Every 30 Minutes',
			),
			'every_two_hours'       => array(
				'interval' => 7200,
				'display'  => 'Every 2 Hours',
			),
			'every_three_hours'     => array(
				'interval' => 10800,
				'display'  => 'Every 3 Hours',
			),
			'every_four_hours'      => array(
				'interval' => 14400,
				'display'  => 'Every 4 Hours',
			),
			'every_five_hours'      => array(
				'interval' => 18000,
				'display'  => 'Every 5 Hours',
			),
			'every_six_hours'       => array(
				'interval' => 21600,
				'display'  => 'Every 6 Hours',
			),
			'every_seven_hours'     => array(
				'interval' => 25200,
				'display'  => 'Every 7 Hours',
			),
			'every_eight_hours'     => array(
				'interval' => 28800,
				'display'  => 'Every 8 Hours',
			),
			'every_nine_hours'      => array(
				'interval' => 32400,
				'display'  => 'Every 9 Hours',
			),
			'every_ten_hours'       => array(
				'interval' => 36000,
				'display'  => 'Every 10 Hours',
			),
			'weekly'                => array(
				'interval' => 604800,
				'display'  => 'Weekly',
			),
		);

		foreach ($intervals as $key => $interval) {
			if (! isset($schedules[$key])) {
				$schedules[$key] = $interval;
			}
		}
		return $schedules;
	}

	/**
	 * Register all cron action handlers to point to new Class Methods
	 */
	public static function register_all_cron_hooks()
	{
		// News Generation
		add_action('nm_generate_mcqs_cron', array(self::class, 'handle_news_generation_cron'));

		// Topic Generation
		add_action('nm_generate_mcqs_from_topics_cron', array(self::class, 'handle_topic_generation_cron'));

		// Feed Importer
		add_action('nm_feed_import_cron', array(self::class, 'handle_feed_import_cron'));

		// --- Current Affairs Hooks (Feeder/Worker) ---
		add_action('nm_generate_current_affairs_mcq_cron', array(self::class, 'handle_current_affairs_feeder_cron'));
		add_action('nm_ca_queue_worker_cron', array(self::class, 'handle_current_affairs_queue_worker'));

		// Maintenance Hooks
		add_action('nm_initial_sync_cron', array(self::class, 'run_initial_sync'));
		add_action('nm_weekly_db_cleanup', array('NM_Database_Migration', 'cleanup_old_data'));
		add_action('nm_monthly_buffer_history_cleanup', array('NM_Database_Migration', 'cleanup_buffer_share_history'));

		// Email Digest
		add_action('nm_email_digest_cron', array('NM_Email_Digest', 'send_digest_emails'));

		// Gamification Hooks
		add_action('nm_recalculate_leaderboards_cron', array('NM_Leaderboard', 'recalculate_all_leaderboards'));
		add_action('nm_cleanup_rate_limits_cron', array('NM_User_Authentication', 'cleanup_rate_limits'));
		add_action('nm_cleanup_notifications_cron', array('NM_Notifications', 'cleanup_old_notifications'));
		add_action('nm_cleanup_security_logs_cron', array('NM_Security_Manager', 'cleanup_old_logs'));

		// Story image cleanup (always runs daily)
		add_action('nm_daily_story_image_cleanup', array('NM_Social_Image_Generator', 'cleanup_old_story_images'));

		// Topic Pillar generation (daily when enabled)
		add_action('nm_pillar_generation_cron', array('NM_Topic_Pillar_Generator', 'run_cron'));
		add_action('nm_daily_roundup_cron', array('NM_News_Article_Generator', 'run_daily_roundup_cron'));
		add_action('nm_pdf_archive_cron', array('NM_Monthly_PDF_Archive', 'run_cron'));

		// Placeholder for unused cron
		add_action('nm_cleanup_old_mcqs_cron', array(self::class, 'handle_placeholder_cron'));
	}

	// ========================================================================
	// 2. CRON SCHEDULING LOGIC
	// ========================================================================

	/**
	 * Ensure all crons are scheduled. Runs on wp_loaded.
	 */
	public static function ensure_crons_scheduled()
	{
		if (
			get_option('nm_news_generation_enabled', 0)
			&& get_option('nm_news_cron_schedule', 'hourly') !== 'disabled'
			&& ! wp_next_scheduled('nm_generate_mcqs_cron')
		) {
			if (class_exists('NM_Generation_Logger')) {
				NM_Generation_Logger::nm_log_activity(
					'[CRON] Crons missing on wp_loaded, rescheduling',
					'warning',
					array('sourcetype' => 'cron')
				);
			}
			self::schedule_all_crons();
		}

		// ✅ NEW: Check for CA crons as well
		if (get_option('nm_current_affairs_enabled', 0)) {
			if (! wp_next_scheduled('nm_generate_current_affairs_mcq_cron') || ! wp_next_scheduled('nm_ca_queue_worker_cron')) {
				if (class_exists('NM_Generation_Logger')) {
					NM_Generation_Logger::nm_log_activity('[CRON] Current Affairs crons missing on wp_loaded, rescheduling', 'warning', array('sourcetype' => 'cron'));
				}
				self::schedule_all_crons();
			}
		}
	}

	/**
	 * Master function to schedule/clear all plugin crons based on settings.
	 */
	public static function schedule_all_crons()
	{
		if (class_exists('NM_Generation_Logger')) {
			NM_Generation_Logger::nm_log_activity('[CRON SCHEDULER] Running schedule_all_crons()', 'info', array('sourcetype' => 'cron'));
		}

		// @MODIFIED: Ensure schedules exist before attempting to schedule
		// This prevents "invalid_schedule" errors during activation
		$schedules = wp_get_schedules();
		if (! isset($schedules['every_two_minutes']) || ! isset($schedules['every_five_minutes'])) {
			if (class_exists('NM_Generation_Logger')) {
				NM_Generation_Logger::nm_log_activity('[CRON SCHEDULER] Custom schedules missing, force-registering...', 'warning', array('sourcetype' => 'cron'));
			}
			// Force-add filters if they are missing
			add_filter('cron_schedules', array(self::class, 'register_cron_intervals'));

			// Reload schedules (though wp_get_schedules is cached, we need to bypass or merge)
			// Since we can't easily clear the WP private cache, we'll trust that the next wp_schedule_event call 
			// will trigger the filter again inside its own check.
		}

		// 1. News Generation
		$news_status = get_option('nm_news_generation_enabled', 0) ? get_option('nm_news_cron_schedule', 'hourly') : 'disabled';
		self::schedule_job('nm_generate_mcqs_cron', $news_status, 'News Generation');

		// 2. Topic Generation
		$topic_status = get_option('nm_topic_generation_enabled', 0) ? get_option('nm_topic_cron_schedule', 'hourly') : 'disabled';
		self::schedule_job('nm_generate_mcqs_from_topics_cron', $topic_status, 'Topic Generation');

		// 3. Feed Importer
		$feed_enabled  = get_option('nm_feed_importer_enabled', 0);
		$feed_schedule = get_option('nm_feed_importer_cron_schedule', 'hourly');
		$feed_status   = ($feed_enabled && $feed_schedule !== 'disabled') ? $feed_schedule : 'disabled';
		self::schedule_job('nm_feed_import_cron', $feed_status, 'Feed Importer');

		// 4. Current Affairs (Feeder/Worker System)
		$ca_enabled  = get_option('nm_current_affairs_enabled', 0);
		$ca_schedule = get_option('nm_current_affairs_cron_schedule', 'every_fifteen_minutes');
		$ca_status   = $ca_enabled ? $ca_schedule : 'disabled';

		// Schedule the Feeder
		self::schedule_job('nm_generate_current_affairs_mcq_cron', $ca_status, 'Current Affairs Feeder');

		// Schedule the Worker (always every 2 mins if enabled)
		// @MODIFIED: Changed from 'every_five_minutes' to 'every_two_minutes' to match user report data and make it faster? 
		// Wait, user report showed: Data: {"schedule":"every_five_minutes","args":[],"interval":300}
		// But in my plan I noticed the user had error for BOTH every_two_minutes and every_five_minutes.
		// The original code here said $worker_status = $ca_enabled ? 'every_five_minutes' : 'disabled';
		// I will keep it as 'every_five_minutes' as per existing code, unless the user wanted it faster.
		// Update: User logs showed: nm_embedding_backfill_cron was every_two_minutes, nm_ca_queue_worker_cron was every_five_minutes.
		// So I will stick to what's in the code.
		$worker_status = $ca_enabled ? 'every_five_minutes' : 'disabled';
		self::schedule_job('nm_ca_queue_worker_cron', $worker_status, 'Current Affairs Worker');

		// Unschedule the old, unused hooks (just in case)
		self::schedule_job('nm_current_affairs_cron_hook', 'disabled', 'Old Current Affairs Feeder');
		// 5. Other Maintenance Crons (always on)
		self::schedule_job('nm_email_digest_cron', 'daily', 'Email Digest');
		self::schedule_job('nm_recalculate_leaderboards_cron', 'hourly', 'Leaderboard Recalc');
		self::schedule_job('nm_weekly_db_cleanup', 'weekly', 'Weekly DB Cleanup');
		self::schedule_job('nm_monthly_buffer_history_cleanup', 'monthly', 'Monthly Buffer History Cleanup');
		self::schedule_job('nm_cleanup_rate_limits_cron', 'daily', 'Rate Limit Cleanup');
		self::schedule_job('nm_cleanup_notifications_cron', 'daily', 'Notification Cleanup');
		self::schedule_job('nm_cleanup_security_logs_cron', 'daily', 'Security Log Cleanup');
		self::schedule_job('nm_daily_story_image_cleanup', 'daily', 'Story Image Cleanup');

		// 6. Topic Pillar generation (daily when enabled; cadence handled in the generator)
		$pillar_status = get_option('nm_pillar_generation_enabled', 0) ? 'daily' : 'disabled';
		self::schedule_job('nm_pillar_generation_cron', $pillar_status, 'Topic Pillar Generation');

		// 6b. Daily Current Affairs Roundup — ONE post/day covering all of that day's MCQs.
		// Fires once per day near end-of-day (23:30 by default). Runs regardless of the
		// article daily-limit (that limit applies to the legacy per-batch articles); the
		// roundup itself guards against double-generating via a per-day transient.
		$roundup_status = class_exists('NM_News_Article_Generator') && NM_News_Article_Generator::is_enabled() ? 'daily' : 'disabled';
		self::schedule_daily_at_time('nm_daily_roundup_cron', $roundup_status, 'Daily Roundup');

		// 6c. Monthly PDF Archive — runs daily, generates once per (topic, month). The
		// handler itself targets the previous completed month and is idempotent, so a
		// daily trigger is safe and self-healing.
		$pdf_status = ( class_exists('NM_Monthly_PDF_Archive') && NM_Monthly_PDF_Archive::is_enabled() ) ? 'daily' : 'disabled';
		self::schedule_job('nm_pdf_archive_cron', $pdf_status, 'Monthly PDF Archive');

		// 7. Embedding Backfill (runs only if Gemini API key is configured)
		$embedding_status = 'disabled';
		if (class_exists('NM_API_Client')) {
			$gemini_key = NM_API_Client::get_gemini_api_key();
			if (! empty($gemini_key)) {
				// Run frequently so backlog clears quickly; worker no-ops when there is nothing to process.
				$embedding_status = 'every_two_minutes';
			}
		}
		self::schedule_job('nm_embedding_backfill_cron', $embedding_status, 'Embedding Backfill');

		if (class_exists('NM_Generation_Logger')) {
			NM_Generation_Logger::nm_log_activity('[CRON SCHEDULER] All cron scheduling complete', 'info', array('sourcetype' => 'cron'));
		}
	}

	/**
	 * Helper to schedule or unschedule a single job.
	 */
	private static function schedule_job($hook, $schedule, $log_name)
	{
		$timestamp        = wp_next_scheduled($hook);
		$current_schedule = wp_get_schedule($hook);

		if ($schedule === 'disabled' || $schedule === 0) {
			if ($timestamp) {
				$cleared_count = wp_clear_scheduled_hook($hook);
				if (class_exists('NM_Generation_Logger')) {
					NM_Generation_Logger::nm_log_activity("[CRON] Cleared {$log_name} (disabled). Removed {$cleared_count} hooks", 'info', array('sourcetype' => 'cron'));
				}
			}
		} elseif (! $timestamp) {
			wp_schedule_event(time() + rand(60, 300), $schedule, $hook); // Add jitter
			if (class_exists('NM_Generation_Logger')) {
				NM_Generation_Logger::nm_log_activity("[CRON] SCHEDULED: {$log_name} ({$schedule})", 'info', array('sourcetype' => 'cron'));
			}
		} elseif ($current_schedule !== $schedule) {
			wp_clear_scheduled_hook($hook);
			wp_schedule_event(time() + rand(60, 300), $schedule, $hook);
			if (class_exists('NM_Generation_Logger')) {
				NM_Generation_Logger::nm_log_activity("[CRON] UPDATED: {$log_name} (from '{$current_schedule}' to '{$schedule}')", 'info', array('sourcetype' => 'cron'));
			}
		}
	}

	/**
	 * @NEW 9.4.1: Schedule a 'daily' job to fire once per day near end-of-day (default
	 * 23:30 site time). Uses wp_schedule_event with a computed first timestamp so the
	 * daily recurrence aligns to a fixed wall-clock hour rather than the moment of save.
	 */
	private static function schedule_daily_at_time($hook, $schedule, $log_name, $hour = 23, $minute = 30)
	{
		$timestamp        = wp_next_scheduled($hook);
		$current_schedule = wp_get_schedule($hook);

		if ($schedule === 'disabled' || $schedule === 0) {
			if ($timestamp) {
				$cleared_count = wp_clear_scheduled_hook($hook);
				if (class_exists('NM_Generation_Logger')) {
					NM_Generation_Logger::nm_log_activity("[CRON] Cleared {$log_name} (disabled). Removed {$cleared_count} hooks", 'info', array('sourcetype' => 'cron'));
				}
			}
			return;
		}

		// @FIX 9.4.5: Compute the next occurrence of the target time in the SITE timezone.
		// The old code used mktime(), which builds the timestamp in the PHP SERVER timezone
		// (often UTC). With a +05:00 site (e.g. Asia/Karachi) that scheduled 23:30 UTC =
		// 04:30 the next morning site time — so the daily roundup fired at the START of the
		// wrong day, found no MCQs published yet, and skipped every day. Use WP's timezone.
		$tz  = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone( get_option( 'timezone_string' ) ? get_option( 'timezone_string' ) : 'UTC' );
		$now = current_time('timestamp'); // site-local wall clock as a Unix timestamp
		try {
			$target   = new DateTime( 'today ' . (int) $hour . ':' . (int) $minute, $tz );
			$today_ts = $target->getTimestamp();
		} catch (Exception $e) {
			$today_ts = mktime( $hour, $minute, 0, (int) date('n', $now), (int) date('j', $now), (int) date('Y', $now) );
		}
		if ($today_ts <= $now) {
			$today_ts += DAY_IN_SECONDS;
		}

		if (! $timestamp) {
			wp_schedule_event($today_ts, 'daily', $hook);
			if (class_exists('NM_Generation_Logger')) {
				NM_Generation_Logger::nm_log_activity("[CRON] SCHEDULED: {$log_name} (daily at " . date('H:i', $today_ts) . ')', 'info', array('sourcetype' => 'cron'));
			}
		} elseif ($current_schedule !== $schedule) {
			wp_clear_scheduled_hook($hook);
			wp_schedule_event($today_ts, 'daily', $hook);
			if (class_exists('NM_Generation_Logger')) {
				NM_Generation_Logger::nm_log_activity("[CRON] UPDATED: {$log_name} (from '{$current_schedule}' to '{$schedule}')", 'info', array('sourcetype' => 'cron'));
			}
		}
	}

	/**
	 * Helper function to provide ALL schedules to settings pages.
	 */
	public static function get_cron_schedules()
	{
		return array(
			'disabled'              => 'Disabled',
			'every_two_minutes'     => 'Every 2 Minutes',
			'every_five_minutes'    => 'Every 5 Minutes',
			'every_ten_minutes'     => 'Every 10 Minutes',
			'every_fifteen_minutes' => 'Every 15 Minutes',
			'every_thirty_minutes'  => 'Every 30 Minutes',
			'hourly'                => 'Hourly (1 Hour)',
			'every_two_hours'       => 'Every 2 Hours',
			'every_three_hours'     => 'Every 3 Hours',
			'every_four_hours'      => 'Every 4 Hours',
			'every_five_hours'      => 'Every 5 Hours',
			'every_six_hours'       => 'Every 6 Hours',
			'every_seven_hours'     => 'Every 7 Hours',
			'every_eight_hours'     => 'Every 8 Hours',
			'every_nine_hours'      => 'Every 9 Hours',
			'every_ten_hours'       => 'Every 10 Hours',
			'twicedaily'            => 'Twice Daily',
			'daily'                 => 'Daily',
			'weekly'                => 'Weekly',
		);
	}

	// ========================================================================
	// 3. CRON EXECUTION HANDLERS (Pointing to new classes)
	// ========================================================================

	public static function handle_placeholder_cron()
	{
		if (class_exists('NM_Generation_Logger')) {
			NM_Generation_Logger::nm_log_activity('[CRON] Placeholder cron nm_cleanup_old_mcqs_cron ran (no action)', 'info', array('sourcetype' => 'cron'));
		}
	}

	public static function handle_news_generation_cron()
	{
		if (class_exists('NM_Generation_Logger')) {
			NM_Generation_Logger::nm_log_activity('[NEWS CRON] Starting cron news generation', 'info', array('sourcetype' => 'cron'));
		}
		if (class_exists('NM_Generation_Service') && method_exists('NM_Generation_Service', 'generate_mcqs_from_news_sync')) {
			// Check Global Smart Schedule Setting
			$smart_schedule_global = get_option('nm_scheduler_enabled', 0);
			$override_status       = $smart_schedule_global ? 'smart_schedule' : null;

			list($count, $log) = NM_Generation_Service::generate_mcqs_from_news_sync(array(), $override_status);

			// Ensure scheduler is running if needed
			if ($smart_schedule_global && class_exists('NMPublicationScheduler')) {
				NMPublicationScheduler::maybe_schedule_first_event();
			}

			if (class_exists('NM_Generation_Logger')) {
				// @MODIFIED: Changed severity to 'info' to prevent counting as 'created' on dashboard
				NM_Generation_Logger::nm_log_activity('[NEWS CRON] Completed: ' . $count . ' MCQs generated', 'info', array('sourcetype' => 'cron'));
			}
		} elseif (class_exists('NM_Generation_Logger')) {
			NM_Generation_Logger::nm_log_activity('[NEWS CRON] Fatal: NM_Generation_Service::generate_mcqs_from_news_sync() not found!', 'error', array('sourcetype' => 'cron'));
		}
	}

	public static function handle_topic_generation_cron()
	{
		if (class_exists('NM_Generation_Logger')) {
			NM_Generation_Logger::nm_log_activity('[TOPIC CRON] Starting cron topic generation', 'info', array('sourcetype' => 'cron'));
		}
		if (class_exists('NM_Generation_Service') && method_exists('NM_Generation_Service', 'generate_mcqs_from_topics_sync')) {
			// Check Global Smart Schedule Setting
			$smart_schedule_global = get_option('nm_scheduler_enabled', 0);
			$override_status       = $smart_schedule_global ? 'smart_schedule' : null;

			list($count, $log) = NM_Generation_Service::generate_mcqs_from_topics_sync(array(), $override_status);

			// Ensure scheduler is running if needed
			if ($smart_schedule_global && class_exists('NMPublicationScheduler')) {
				NMPublicationScheduler::maybe_schedule_first_event();
			}

			if (class_exists('NM_Generation_Logger')) {
				// @MODIFIED: Changed severity to 'info' to prevent counting as 'created' on dashboard
				NM_Generation_Logger::nm_log_activity('[TOPIC CRON] Completed: ' . $count . ' MCQs generated', 'info', array('sourcetype' => 'cron'));
			}
		} elseif (class_exists('NM_Generation_Logger')) {
			NM_Generation_Logger::nm_log_activity('[TOPIC CRON] Fatal: NM_Generation_Service::generate_mcqs_from_topics_sync() not found!', 'error', array('sourcetype' => 'cron'));
		}
	}

	public static function handle_feed_import_cron()
	{
		if (class_exists('NM_Generation_Logger')) {
			NM_Generation_Logger::nm_log_activity('[FEED IMPORT CRON] Starting automatic import', 'info', array('sourcetype' => 'cron'));
		}
		try {
			if (! get_option('nm_feed_importer_enabled', 0)) {
				if (class_exists('NM_Generation_Logger')) {
					NM_Generation_Logger::nm_log_activity('[FEED IMPORT CRON] Disabled, skipping', 'info', array('sourcetype' => 'cron'));
				}
				return;
			}
			if (! class_exists('NM_Feed_Importer') || ! method_exists('NM_Feed_Importer', 'run_import')) {
				if (class_exists('NM_Generation_Logger')) {
					NM_Generation_Logger::nm_log_activity('[FEED IMPORT CRON] Fatal: NM_Feed_Importer::run_import() not found!', 'error', array('sourcetype' => 'cron'));
				}
				return;
			}
			// Check Global Smart Schedule Setting
			$smart_schedule_global = get_option('nm_scheduler_enabled', 0);
			$override_status       = $smart_schedule_global ? 'smart_schedule' : null;

			list($count, $log) = NM_Feed_Importer::run_import($override_status);

			// Ensure scheduler is running if needed
			if ($smart_schedule_global && class_exists('NMPublicationScheduler')) {
				NMPublicationScheduler::maybe_schedule_first_event();
			}

			if (class_exists('NM_Generation_Logger')) {
				// @MODIFIED: Changed severity to 'info' to prevent counting as 'created' on dashboard
				NM_Generation_Logger::nm_log_activity("[FEED IMPORT CRON] Completed: {$count} MCQs imported", 'info', array('sourcetype' => 'cron'));
			}
		} catch (Throwable $t) {
			if (class_exists('NM_Generation_Logger')) {
				NM_Generation_Logger::nm_log_activity('[FEED IMPORT CRON] FATAL: ' . $t->getMessage(), 'error', array('sourcetype' => 'cron'));
			}
		}
	}

	/**
	 * ✅ NEW: Handler for the Current Affairs Feeder
	 */
	public static function handle_current_affairs_feeder_cron()
	{
		if (class_exists('NM_Generation_Logger')) {
			NM_Generation_Logger::nm_log_activity('[CA Feeder CRON] Starting article queuing', 'info', array('sourcetype' => 'cron'));
		}
		if (class_exists('NM_Current_Affairs_Generator') && method_exists('NM_Current_Affairs_Generator', 'run_generation_cron')) {
			NM_Current_Affairs_Generator::run_generation_cron();
			if (class_exists('NM_Generation_Logger')) {
				// @MODIFIED: Changed severity to 'info' to prevent counting as 'created' on dashboard
				NM_Generation_Logger::nm_log_activity('[CA Feeder CRON] Article queuing complete', 'info', array('sourcetype' => 'cron'));
			}
		} elseif (class_exists('NM_Generation_Logger')) {
			NM_Generation_Logger::nm_log_activity('[CA Feeder CRON] Fatal: NM_Current_Affairs_Generator::run_generation_cron() not found!', 'error', array('sourcetype' => 'cron'));
		}
	}

	/**
	 * ✅ NEW: Handler for the Current Affairs Worker
	 */
	public static function handle_current_affairs_queue_worker()
	{
		if (class_exists('NM_Generation_Logger')) {
			NM_Generation_Logger::nm_log_activity('[CA Worker CRON] Starting queue processing', 'info', array('sourcetype' => 'cron'));
		}
		if (class_exists('NM_Current_Affairs_Generator') && method_exists('NM_Current_Affairs_Generator', 'run_worker_cron')) {
			NM_Current_Affairs_Generator::run_worker_cron();
			// ✅ Update last run timestamp for health monitoring
			update_option('nm_ca_worker_last_run', time());
			if (class_exists('NM_Generation_Logger')) {
				// @MODIFIED: Changed severity to 'info' to prevent counting as 'created' on dashboard
				NM_Generation_Logger::nm_log_activity('[CA Worker CRON] Queue processing complete', 'info', array('sourcetype' => 'cron'));
			}
		} elseif (class_exists('NM_Generation_Logger')) {
			NM_Generation_Logger::nm_log_activity('[CA Worker CRON] Fatal: NM_Current_Affairs_Generator::run_worker_cron() not found!', 'error', array('sourcetype' => 'cron'));
		}
	}

	public static function run_initial_sync()
	{
		if (class_exists('NM_Database_Optimizer')) {
			NM_Database_Optimizer::run_initial_sync();
		}
	}

	// ========================================================================
	// 4. AJAX & ADMIN NOTICES
	// ========================================================================

	/**
	 * AJAX: Manually reset/fix crons from admin dashboard.
	 */
	public static function ajax_reset_stuck_crons()
	{
		check_ajax_referer('nm_ajax_dashboard');
		if (! current_user_can('manage_options')) {
			wp_send_json_error(array('message' => 'Permission denied'));
		}
		if (class_exists('NM_Generation_Logger')) {
			NM_Generation_Logger::nm_log_activity('[AJAX] User requesting cron reset', 'info');
		}

		$hooks = array(
			'nm_generate_mcqs_cron',
			'nm_generate_mcqs_from_topics_cron',
			'nm_email_digest_cron',
			'nm_cleanup_old_mcqs_cron',
			'nm_generate_current_affairs_mcq_cron', // New Feeder hook
			'nm_ca_queue_worker_cron',              // New Worker hook
			'nm_feed_import_cron',
			'nm_recalculate_leaderboards_cron',
			'nm_weekly_db_cleanup',
			'nm_monthly_buffer_history_cleanup',
			'nm_cleanup_rate_limits_cron',
			'nm_cleanup_notifications_cron',
			'nm_cleanup_security_logs_cron',
			'nm_embedding_backfill_cron',           // Embedding Backfill worker
			'nm_daily_story_image_cleanup',       // Story image cleanup
			'nm_send_daily_digest',
			'nm_initial_sync_cron',
		);

		foreach ($hooks as $hook) {
			wp_clear_scheduled_hook($hook);
		}

		// Re-schedule all plugin crons
		self::schedule_all_crons();

		// Bust the admin System Health cache so the dashboard reflects new cron state
		if (class_exists('NM_Cache_Manager')) {
			NM_Cache_Manager::delete('admin_system_health');
		}

		if (class_exists('NM_Generation_Logger')) {
			NM_Generation_Logger::nm_log_activity('[AJAX] Cron reset successful', 'success');
		}
		wp_send_json_success(array('message' => 'Cron jobs reset successfully.'));
	}

	/**
	 * Admin Notice: Display cron health on plugin pages.
	 */
	public static function cron_health_notice()
	{
		if (! current_user_can('manage_options') || ! isset($_GET['page']) || strpos($_GET['page'], 'nm_') === false) {
			return;
		}

		$all_crons_ok  = true;
		$cron_messages = array();

		// Define the hooks to check based on settings
		$hooks_to_check = array();

		if (get_option('nm_news_generation_enabled', 0) && get_option('nm_news_cron_schedule', 'hourly') !== 'disabled') {
			$hooks_to_check['News Generation'] = 'nm_generate_mcqs_cron';
		}
		if (get_option('nm_topic_generation_enabled', 0) && get_option('nm_topic_cron_schedule', 'hourly') !== 'disabled') {
			$hooks_to_check['Topic Generation'] = 'nm_generate_mcqs_from_topics_cron';
		}
		if (get_option('nm_feed_importer_enabled', 0) && get_option('nm_feed_importer_cron_schedule', 'hourly') !== 'disabled') {
			$hooks_to_check['Feed Importer'] = 'nm_feed_import_cron';
		}

		// ✅ NEW: Check both Feeder and Worker
		if (get_option('nm_current_affairs_enabled', 0)) {
			$hooks_to_check['Current Affairs Feeder'] = 'nm_generate_current_affairs_mcq_cron';
			$hooks_to_check['Current Affairs Worker'] = 'nm_ca_queue_worker_cron';
		}

		// ✅ NEW: Embedding Backfill cron (only if Gemini API key is configured)
		if (class_exists('NM_API_Client') && ! empty(NM_API_Client::get_gemini_api_key())) {
			$hooks_to_check['Embedding Backfill'] = 'nm_embedding_backfill_cron';
		}

		// Check the status of each required cron
		foreach ($hooks_to_check as $name => $hook) {
			$timestamp = wp_next_scheduled($hook);
			if (! $timestamp) {
				$all_crons_ok    = false;
				$cron_messages[] = "{$name} Cron: Not Scheduled";
			} elseif ($timestamp < time()) {
				$all_crons_ok    = false;
				$cron_messages[] = "{$name} Cron: Stuck (Overdue)";
			}
		}

		// Display the notice
		if ($all_crons_ok && ! empty($hooks_to_check)) {
			// All active crons are scheduled
			echo '<div class="notice notice-success is-dismissible" style="margin-left: 2px;"><p>✅ All Crons: ACTIVE</p></div>';
		} elseif (! $all_crons_ok) {
			// One or more crons have issues
?>
			<div class="notice notice-error" style="margin-left: 2px;">
				<p><strong>❌ Cron Issue Detected:</strong></p>
				<ul style="list-style: disc; margin-left: 20px;">
					<?php foreach ($cron_messages as $msg) : ?>
						<li><?php echo esc_html($msg); ?></li>
					<?php endforeach; ?>
				</ul>
				<p>
					<button type="button" id="nm-fix-crons-notice" class="button button-primary">
						🔧 Attempt to Fix Crons Now
					</button>
				</p>
			</div>
			<script>
				jQuery(function($) {
					$('#nm-fix-crons-notice').on('click', function() {
						const btn = $(this).prop('disabled', true).text('Fixing...');
						$.post(ajaxurl, {
							action: 'nm_ajax_reset_stuck_crons', // This AJAX action is in NM_AJAX_Manager
							_ajax_nonce: '<?php echo wp_create_nonce('nm_ajax_dashboard'); ?>' // Nonce from dashboard
						}, function(resp) {
							if (resp.success) {
								btn.text('Fixed! Reloading...');
								location.reload();
							} else {
								btn.text('Failed: ' + (resp.data.message || 'Unknown error'));
								btn.prop('disabled', false);
							}
						}).fail(function() {
							btn.text('Server error. Please try again.');
							btn.prop('disabled', false);
						});
					});
				});
			</script>
<?php
		}
	}
}
?>