<?php
/**
 * Option Registry
 *
 * Single source of truth for all wp_options keys and their canonical defaults.
 * Zero business logic. Constants and data only.
 *
 * Rules enforced by this file:
 * - Every get_option() / update_option() call plugin-wide MUST reference these constants.
 * - Default values here MUST match the fallback parameter used in every get_option() call.
 * - Installer::set_default_options() MUST derive its array from self::defaults().
 *
 * @package SEO_Article_Generator
 */

namespace SEO_Article_Generator;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class Option_Registry {

    // -----------------------------------------------------------------------
    // Discovery toggles — confirmed in Installer::set_default_options()
    // -----------------------------------------------------------------------
    const DISCOVERY_ENABLED            = 'seo_gen_discovery_enabled';
    const RSS_DISCOVERY_ENABLED       = 'seo_gen_rss_discovery_enabled';
    const AI_DISCOVERY_ENABLED         = 'seo_gen_ai_discovery_enabled';

    // -----------------------------------------------------------------------
    // Section configuration — confirmed in Installer + Job_Handler fallbacks
    // -----------------------------------------------------------------------
    const DISCOVERY_SECTIONS           = 'seo_gen_discovery_sections';
    const UPDATE_SECTIONS             = 'seo_gen_update_sections';

    // -----------------------------------------------------------------------
    // Auto-generation cron — confirmed in Installer + Discovery_Bootstrap
    // -----------------------------------------------------------------------
    const ENABLE_AUTO_GENERATION      = 'seo_gen_enable_auto_generation';
    const AUTO_GENERATION_INTERVAL   = 'seo_gen_auto_generation_interval';
    const AUTO_GENERATION_BATCH        = 'seo_gen_auto_generation_batch';
    const AUTO_GENERATION_APPLIED_INTERVAL = 'seo_gen_auto_generation_applied_interval';

    // -----------------------------------------------------------------------
    // Publish watchdog — recurring AS safety net for plugin-owned 'future' posts
    // -----------------------------------------------------------------------
    const ENABLE_PUBLISH_WATCHDOG     = 'seo_gen_enable_publish_watchdog';
    const PUBLISH_WATCHDOG_INTERVAL   = 'seo_gen_publish_watchdog_interval';
    const PUBLISH_WATCHDOG_APPLIED    = 'seo_gen_publish_watchdog_applied_interval';

    // -----------------------------------------------------------------------
    // External heartbeat cron — deterministic, traffic-independent watchdog
    // (mirrors WP Automatic's ?wp_automatic=cron external cron pattern).
    // The secret token prevents anonymous abuse of the endpoint.
    // -----------------------------------------------------------------------
    const EXTERNAL_CRON_SECRET         = 'seo_gen_external_cron_secret';
    const EXTERNAL_CRON_LAST_FIRE      = 'seo_gen_external_cron_last_fire';
    const EXTERNAL_CRON_LAST_REPORT    = 'seo_gen_external_cron_last_report';

    // -----------------------------------------------------------------------
    // Watchdog / recovery thresholds — single source of truth (Audit Enhancement 4)
    // -----------------------------------------------------------------------
    // FIX F11 (Phase 3C, 2.32.26): removed dead WATCHDOG_STALE_HEARTBEAT_SECONDS
    // (declared + defaulted but never read; stale cutoff is governed by
    // OVERDUE_RECOVERY_WINDOW_MIN, which is wired into run_overdue_recovery).
    const OVERDUE_RECOVERY_WINDOW_MIN      = 'seo_gen_overdue_recovery_window_min';
    const PENDING_AGING_THRESHOLD_MIN      = 'seo_gen_pending_aging_threshold_min';

    // -----------------------------------------------------------------------
    // API / provider — confirmed in Installer + settings.php
    // -----------------------------------------------------------------------
	const API_PROVIDER = 'seo_gen_api_provider';
	const PROVIDER_ONLY_MODE = 'seo_gen_provider_only_mode';
	const GEMINI_API_KEY = 'seo_gen_gemini_api_key';
	const GEMINI_MODEL = 'seo_gen_gemini_model';
	const GEMINI_MODEL_MODE = 'seo_gen_gemini_model_mode';
	const GEMINI_CUSTOM_MODEL = 'seo_gen_gemini_custom_model';
	const OPENAI_API_KEY = 'seo_gen_openai_api_key';
    const OPENAI_MODEL               = 'seo_gen_openai_model';
	const GROQ_API_KEY = 'seo_gen_groq_api_key';
	const GROQ_MODEL = 'seo_gen_groq_model';
	const GROQ_FALLBACK = 'seo_gen_groq_fallback';
	const GEMINI_FALLBACK = 'seo_gen_gemini_fallback';
	const CLAUDE_API_KEY = 'seo_gen_claude_api_key';
	const PERPLEXITY_API_KEY = 'seo_gen_perplexity_api_key';
	const PERPLEXITY_MODEL = 'seo_gen_perplexity_model';
	const OPENROUTER_API_KEY = 'seo_gen_openrouter_api_key';
	const OPENROUTER_MODEL = 'seo_gen_openrouter_model';
	const OPENROUTER_FALLBACK = 'seo_gen_openrouter_fallback';
    const ENABLE_WEB_SEARCH          = 'seo_gen_enable_web_search';
    const DAILY_QUOTA                = 'seo_gen_daily_quota';

	const CUSTOM_PROVIDERS = 'seo_gen_custom_providers';
	const CUSTOM_DEFAULT_PROVIDER = 'seo_gen_custom_default_provider';

	// -----------------------------------------------------------------------
	// OpenRouter free model auto-sync — single source of truth
	// (the recurring hook string lives in AS_Registry::HOOK_SYNC_OPENROUTER)
	// -----------------------------------------------------------------------
	const OPENROUTER_LAST_SYNC       = 'seo_gen_openrouter_last_sync';
	const LOG_ACTION_OPENROUTER_SYNC = 'openrouter_models_synced';

	// -----------------------------------------------------------------------
	// OpenCode Zen free model auto-sync — sibling of the OpenRouter sync.
	// The recurring hook string lives in AS_Registry::HOOK_SYNC_ZEN.
	// -----------------------------------------------------------------------
	const ZEN_LAST_SYNC        = 'seo_gen_zen_last_sync';
	const LOG_ACTION_ZEN_SYNC  = 'zen_models_synced';

    // -----------------------------------------------------------------------
    // Publishing & scheduling — confirmed in settings.php
    // -----------------------------------------------------------------------
    const DISCOVERY_PUBLISH_STATUS     = 'seo_gen_discovery_publish_status';
    const ENABLE_SCHEDULING          = 'seo_gen_enable_scheduling';
    const PUBLISH_START              = 'seo_gen_publish_start';
    const PUBLISH_END                = 'seo_gen_publish_end';
    const POSTS_PER_DAY              = 'seo_gen_posts_per_day';
    const ACTIVE_DAYS                = 'seo_gen_active_days';
    const PUBLISH_INTERVAL_MIN       = 'seo_gen_publish_interval_min';
    const PUBLISH_INTERVAL_MAX       = 'seo_gen_publish_interval_max';
    const UPDATE_DELAY_MIN          = 'seo_gen_update_delay_min';
    const UPDATE_DELAY_MAX          = 'seo_gen_update_delay_max';
    const UPDATES_PER_DAY           = 'seo_gen_updates_per_day';

    // -----------------------------------------------------------------------
    // Inflight / concurrency — confirmed in Installer
    // -----------------------------------------------------------------------
    const INFLIGHT_GENERATIONS        = 'seo_gen_inflight_generations';
    const INFLIGHT_SCOUTS          = 'seo_gen_inflight_scouts';
    const MAX_PARALLEL_JOBS        = 'seo_gen_max_parallel_jobs';
    const MAX_PARALLEL_SCOUTS       = 'seo_gen_max_parallel_scouts';

    // -----------------------------------------------------------------------
    // Content generation — confirmed in Installer + Generator
    // -----------------------------------------------------------------------
    const VALIDATION_THRESHOLD        = 'seo_gen_validation_threshold';
    const INTERNAL_LINK_COUNT      = 'seo_gen_internal_link_count';
    const PLATFORM_THRESHOLD     = 'seo_gen_platform_threshold';
    const KEYWORD_DENSITY_MIN   = 'seo_gen_keyword_density_min';
    const KEYWORD_DENSITY_MAX    = 'seo_gen_keyword_density_max';
    const CONTENT_LENGTH_MIN   = 'seo_gen_content_length_min';
    const CONTENT_LENGTH_MAX   = 'seo_gen_content_length_max';
    const TITLE_STYLE           = 'seo_gen_title_style';

    // -----------------------------------------------------------------------
    // Logging & misc — confirmed in Installer + settings.php
    // -----------------------------------------------------------------------
    const ENABLE_LOGGING           = 'seo_gen_enable_logging';
    const LOG_RETENTION         = 'seo_gen_log_retention';
    const DRAFT_RETENTION_DAYS  = 'seo_gen_draft_retention_days';
    const WP_AUTO_CATEGORY_ID   = 'seo_gen_wp_auto_category_id';
    const DEFAULT_CATEGORY     = 'seo_gen_default_category';
    const DEFAULT_TAGS        = 'seo_gen_default_tags';
    const PURGE_ON_UNINSTALL   = 'seo_gen_purge_on_uninstall';
    const DISCOVERY_SOURCES    = 'seo_gen_discovery_sources';
    const DISCOVERY_FEEDS      = 'seo_gen_discovery_feeds';
    const API_PAUSE_REASON     = 'seo_gen_api_pause_reason';
	const PLUGIN_FILTER_ENABLED = 'seo_gen_discovery_plugin_filter_enabled';
	const ENABLE_PORTABLE_DISCOVERY = 'seo_gen_enable_portable_discovery';
	const DOWNLOAD_ALLOWLIST = 'seo_gen_download_allowlist';
	const DOWNLOAD_DOMAIN_DENYLIST = 'seo_gen_download_domain_denylist';
	const DEBUG_LOG_PATH = 'seo_gen_debug_log_path';

	// -----------------------------------------------------------------------
	// Category & Tag Mapping — deterministic taxonomy assignment
	// -----------------------------------------------------------------------
	const CATEGORY_KEYWORD_MAP = 'seo_gen_category_keyword_map';
	const TAG_BLOCKLIST = 'seo_gen_tag_blocklist';
	const TAG_MAX_COUNT = 'seo_gen_tag_max_count';

	// -----------------------------------------------------------------------
	// Migration guards — write-once flags, never read as settings
// -----------------------------------------------------------------------
const MIGRATION_LEGACY_OPTIONS_DONE = 'seo_gen_migration_legacy_options_done';
const MIGRATION_BATCH_TYPO_DONE = 'seo_gen_migration_batch_typo_done';

	// -----------------------------------------------------------------------
	// Canonical Slug Migration — redirect control
	// -----------------------------------------------------------------------
	const DISABLE_RM_REDIRECTS = 'seo_gen_disable_rm_redirects';

    // -----------------------------------------------------------------------
    // Dashboard Integration
    // -----------------------------------------------------------------------
    const DASHBOARD_API_KEY                = 'seo_gen_dashboard_api_key';

    // -----------------------------------------------------------------------
    // Jetpack & Buffer Integrations
    // -----------------------------------------------------------------------
    const JETPACK_ENABLED                  = 'seo_gen_jetpack_enabled';
    const JETPACK_TEMPLATE                 = 'seo_gen_jetpack_template';
    const JETPACK_NETWORKS                 = 'seo_gen_jetpack_networks';
    const JETPACK_NETWORK_TEMPLATES        = 'seo_gen_jetpack_network_templates';
    const JETPACK_NETWORKS_INITIALIZED     = 'seo_gen_jetpack_networks_initialized';

    const BUFFER_ENABLED              = 'seo_gen_buffer_enabled';
    const BUFFER_ACCESS_TOKEN         = 'seo_gen_buffer_access_token';
    const BUFFER_DAILY_LIMIT          = 'seo_gen_buffer_daily_limit';
    const BUFFER_PUB_TRACKER          = 'seo_gen_buffer_pub_tracker';
    const BUFFER_ENABLED_CHANNELS     = 'seo_gen_buffer_enabled_channels';
    const BUFFER_CHANNEL_TYPES        = 'seo_gen_buffer_channel_types';
    const BUFFER_CHANNEL_TEMPLATES    = 'seo_gen_buffer_channel_templates';
    const BUFFER_CHANNEL_LINK_POSTS   = 'seo_gen_buffer_channel_link_posts';
    const BUFFER_CHANNEL_PINTEREST_BOARDS = 'seo_gen_buffer_channel_pinterest_boards';
    const BUFFER_CHANNEL_PINTEREST_TITLES = 'seo_gen_buffer_channel_pinterest_titles';
    const BUFFER_CHANNEL_OMIT_LINKS        = 'seo_gen_buffer_channel_omit_links';
    const BUFFER_CHANNEL_OBFUSCATE_LINKS   = 'seo_gen_buffer_channel_obfuscate_links';

    // -----------------------------------------------------------------------
    // Defaults — ALL values confirmed against Installer::set_default_options()
    // -----------------------------------------------------------------------

    /**
     * Returns canonical defaults for every option.
     *
     * Installer::set_default_options() MUST be derived from this method.
     * Every get_option( CONSTANT, $fallback ) fallback MUST match this value.
     *
     * @return array<string,mixed>
     */
    public static function defaults(): array {
		return [
			// API / Provider
			self::API_PROVIDER => 'gemini',
			self::GEMINI_API_KEY => '',
			self::GEMINI_MODEL => 'gemini-2.0-flash',
			self::GEMINI_MODEL_MODE => 'gemini-2.0-flash',
			self::GEMINI_CUSTOM_MODEL => '',
			self::OPENAI_API_KEY => '',
            self::OPENAI_MODEL               => '',
		self::GROQ_API_KEY => '',
		self::GROQ_MODEL => '',
		self::GROQ_FALLBACK => 0,
		self::GEMINI_FALLBACK => 0,
		self::CLAUDE_API_KEY => '',
            self::PERPLEXITY_API_KEY           => '',
		self::PERPLEXITY_MODEL => 'sonar-pro',
		self::OPENROUTER_API_KEY => '',
		self::OPENROUTER_MODEL => '',
		self::OPENROUTER_FALLBACK => 0,
            self::PROVIDER_ONLY_MODE         => true,
            self::ENABLE_WEB_SEARCH          => true,
			self::DAILY_QUOTA                => 50,
			self::CUSTOM_PROVIDERS => '[]',
			self::CUSTOM_DEFAULT_PROVIDER => '',

            // Category / Tags
            self::DEFAULT_CATEGORY            => '',
            self::DEFAULT_TAGS               => array(),

            // Content generation
            self::VALIDATION_THRESHOLD       => 75,
            self::PLATFORM_THRESHOLD        => 3,
            self::INTERNAL_LINK_COUNT        => 3,
            self::KEYWORD_DENSITY_MIN        => 1.0,
            self::KEYWORD_DENSITY_MAX        => 3.0,
            self::CONTENT_LENGTH_MIN        => 600,
            self::CONTENT_LENGTH_MAX        => 1400,
            self::TITLE_STYLE               => array( 1, 2, 3 ),

            // Logging
            self::ENABLE_LOGGING             => true,
            self::LOG_RETENTION              => 7,
            self::API_PAUSE_REASON          => '',

            // Discovery toggles
            self::DISCOVERY_ENABLED         => 1,
            self::RSS_DISCOVERY_ENABLED    => 1,
            self::AI_DISCOVERY_ENABLED     => 0,

            // Discovery config
            self::DISCOVERY_SOURCES         => array(),
            self::DISCOVERY_FEEDS           => array(),
self::DISCOVERY_SECTIONS => array('introduction', 'features', 'download', 'tech_specs', 'installation', 'faqs', 'moat', 'whats_new', 'toc'),
            self::UPDATE_SECTIONS            => array('download', 'tech_specs', 'whats_new', 'hero', 'relatedsoftware'),

            // Publishing
            self::DISCOVERY_PUBLISH_STATUS  => 'publish',
self::DRAFT_RETENTION_DAYS => 2,
            self::WP_AUTO_CATEGORY_ID      => 0,

            // Scheduling
            self::ENABLE_SCHEDULING         => false,
            self::PUBLISH_START            => '09:00',
            self::PUBLISH_END              => '20:00',
            self::POSTS_PER_DAY            => 5,
            self::ACTIVE_DAYS              => array('mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'),
            self::PUBLISH_INTERVAL_MIN      => 1,
            self::PUBLISH_INTERVAL_MAX     => 4,
            self::UPDATE_DELAY_MIN         => 15,
            self::UPDATE_DELAY_MAX         => 30,
            self::UPDATES_PER_DAY           => 15,

            // Auto-generation
            self::ENABLE_AUTO_GENERATION   => false,
            self::AUTO_GENERATION_INTERVAL => 60,
            self::AUTO_GENERATION_BATCH    => 2,
            self::AUTO_GENERATION_APPLIED_INTERVAL => '',

            // Publish watchdog
            self::ENABLE_PUBLISH_WATCHDOG  => 1,
            self::PUBLISH_WATCHDOG_INTERVAL => 120,
            self::PUBLISH_WATCHDOG_APPLIED => 0,

            // External cron secret — empty here; lazily generated on first use.
            self::EXTERNAL_CRON_SECRET => '',
            self::EXTERNAL_CRON_LAST_FIRE => 0,
            self::EXTERNAL_CRON_LAST_REPORT => '',

            // Dashboard Integration
            self::DASHBOARD_API_KEY => '',

            // Watchdog / recovery thresholds
            self::OVERDUE_RECOVERY_WINDOW_MIN      => 30,
            self::PENDING_AGING_THRESHOLD_MIN      => 120,

            // Concurrency
            self::INFLIGHT_GENERATIONS      => 0,
            self::INFLIGHT_SCOUTS         => 0,
            self::MAX_PARALLEL_JOBS       => 3,
            self::MAX_PARALLEL_SCOUTS     => 2,

		// Plugin
	self::PLUGIN_FILTER_ENABLED => 0,
	self::ENABLE_PORTABLE_DISCOVERY => 1,
		self::DOWNLOAD_ALLOWLIST => '',
		self::DOWNLOAD_DOMAIN_DENYLIST => 'prf.hn
awin1.com
shareasale.com
cjmp.gw
jdoqocy.com
tkqlhce.com
anrdoezrs.net
dpbolvw.net
kqzyfj.com
qksrv.net
click.linksynergy.com
rd.bizrate.com
commission-junction.com
impact.com
impactradius.com
flexlinkspro.com
tracking.flexlinks.com
referralrock.com
partnerstack.com
getrewardful.com
tapfiliate.com
leaddyno.com
refersion.com
ambassador.com
emjcd.com
linksynergy.com
rakuten.com
avangate.com
shareit.com
regnow.com
digistore24.com
hop.clickbank.net
clickbank.com
ad.admitad.com
clk.tradedoubler.com
tradedoubler.com
track.webgains.com
postaffiliatepro.com
xtsl.net
9w9.io
irs01.com
incomeaccess.com
go.hasoffers.com
performancepartner.com
linkconnector.com
gopajam.com
pjatracker.com
affiliatewindow.com
zanox.com
cj.com
referralcandy.com',
		self::DEBUG_LOG_PATH => '',
	self::CATEGORY_KEYWORD_MAP => '',
	self::TAG_BLOCKLIST => 'software,download,free download,windows software,pc software,best software,top software,utility,utilities,computer software,latest version,new version,software download,free software,app,application',
	self::TAG_MAX_COUNT => 8,
	self::PURGE_ON_UNINSTALL => false,
		self::DISABLE_RM_REDIRECTS => false,

            // Jetpack & Buffer Integrations
            self::JETPACK_ENABLED => false,
            self::JETPACK_TEMPLATE => "{title}\n\n{excerpt}\n\n{tags}\n\n{link}",
            self::JETPACK_NETWORKS => array(),
            self::JETPACK_NETWORK_TEMPLATES => array(),
            self::JETPACK_NETWORKS_INITIALIZED => false,

            self::BUFFER_ENABLED => false,
            self::BUFFER_ACCESS_TOKEN => '',
            self::BUFFER_DAILY_LIMIT => 5,
            self::BUFFER_PUB_TRACKER => array('date' => '', 'ids' => array()),
            self::BUFFER_ENABLED_CHANNELS => array(),
            self::BUFFER_CHANNEL_TYPES => array(),
            self::BUFFER_CHANNEL_TEMPLATES => array(),
            self::BUFFER_CHANNEL_LINK_POSTS => array(),
            self::BUFFER_CHANNEL_PINTEREST_BOARDS => array(),
            self::BUFFER_CHANNEL_PINTEREST_TITLES => array(),
            self::BUFFER_CHANNEL_OMIT_LINKS => array(),
            self::BUFFER_CHANNEL_OBFUSCATE_LINKS => array(),
        ];
    }

    /**
     * Returns keys that are boolean checkboxes in the settings form.
     *
     * Admin_Menu::save_settings() uses this list to explicitly set unchecked
     * checkboxes to 0/false. Without this, an unchecked box sends no POST value
     * and the option silently retains its previous value.
     *
     * @return string[]
     */
	public static function boolean_keys(): array {
		return [
			self::DISCOVERY_ENABLED,
			self::RSS_DISCOVERY_ENABLED,
			self::AI_DISCOVERY_ENABLED,
			self::ENABLE_AUTO_GENERATION,
			self::ENABLE_SCHEDULING,
			self::PROVIDER_ONLY_MODE,
			self::ENABLE_WEB_SEARCH,
			self::ENABLE_LOGGING,
			self::PURGE_ON_UNINSTALL,
		self::GROQ_FALLBACK,
		self::OPENROUTER_FALLBACK,
		self::GEMINI_FALLBACK,
			self::PLUGIN_FILTER_ENABLED,
			self::ENABLE_PORTABLE_DISCOVERY,
			self::DISABLE_RM_REDIRECTS,
            self::JETPACK_ENABLED,
            self::BUFFER_ENABLED,
		];
	}

	/**
	 * Returns the canonical list of option keys saved by Admin_Menu::save_settings().
	 *
	 * Admin_Menu::save_settings() MUST derive its $settings array from this method,
	 * not maintain a parallel hand-coded list.
	 *
	 * @return string[]
	 */
	public static function settings_form_keys(): array {
		return array(
			self::API_PROVIDER,
			self::GEMINI_API_KEY,
			self::GEMINI_MODEL,
			self::GEMINI_MODEL_MODE,
			self::GEMINI_CUSTOM_MODEL,
			self::CLAUDE_API_KEY,
			self::PERPLEXITY_API_KEY,
			self::PERPLEXITY_MODEL,
			self::OPENAI_API_KEY,
			self::OPENAI_MODEL,
		self::GROQ_API_KEY,
		self::GROQ_MODEL,
		self::OPENROUTER_API_KEY,
		self::OPENROUTER_MODEL,
			self::PROVIDER_ONLY_MODE,
			self::VALIDATION_THRESHOLD,
			self::INTERNAL_LINK_COUNT,
			self::KEYWORD_DENSITY_MIN,
			self::KEYWORD_DENSITY_MAX,
			self::CONTENT_LENGTH_MIN,
			self::CONTENT_LENGTH_MAX,
			self::ENABLE_LOGGING,
			self::LOG_RETENTION,
			self::DISCOVERY_PUBLISH_STATUS,
			self::DRAFT_RETENTION_DAYS,
			self::DISCOVERY_SECTIONS,
			self::ENABLE_SCHEDULING,
			self::PUBLISH_START,
			self::PUBLISH_END,
			self::POSTS_PER_DAY,
			self::ACTIVE_DAYS,
			self::ENABLE_AUTO_GENERATION,
			self::AUTO_GENERATION_INTERVAL,
			self::AUTO_GENERATION_BATCH,
			self::PUBLISH_INTERVAL_MIN,
			self::PUBLISH_INTERVAL_MAX,
			self::UPDATE_DELAY_MIN,
			self::UPDATE_DELAY_MAX,
			self::UPDATES_PER_DAY,
			self::TITLE_STYLE,
			self::PLATFORM_THRESHOLD,
			self::PURGE_ON_UNINSTALL,
			self::UPDATE_SECTIONS,
			self::DISCOVERY_ENABLED,
			self::RSS_DISCOVERY_ENABLED,
			self::AI_DISCOVERY_ENABLED,
			self::PLUGIN_FILTER_ENABLED,
			self::ENABLE_PORTABLE_DISCOVERY,
		self::DISABLE_RM_REDIRECTS,
		self::DOWNLOAD_ALLOWLIST,
		self::DOWNLOAD_DOMAIN_DENYLIST,
		self::CATEGORY_KEYWORD_MAP,
		self::TAG_BLOCKLIST,
		self::TAG_MAX_COUNT,
		self::DAILY_QUOTA,
		self::DASHBOARD_API_KEY,
            self::JETPACK_ENABLED,
            self::JETPACK_TEMPLATE,
            self::JETPACK_NETWORKS,
            self::JETPACK_NETWORK_TEMPLATES,
            self::JETPACK_NETWORKS_INITIALIZED,
            self::BUFFER_ENABLED,
            self::BUFFER_ACCESS_TOKEN,
            self::BUFFER_DAILY_LIMIT,
            self::BUFFER_PUB_TRACKER,
            self::BUFFER_ENABLED_CHANNELS,
            self::BUFFER_CHANNEL_TYPES,
            self::BUFFER_CHANNEL_TEMPLATES,
            self::BUFFER_CHANNEL_LINK_POSTS,
            self::BUFFER_CHANNEL_PINTEREST_BOARDS,
            self::BUFFER_CHANNEL_PINTEREST_TITLES,
            self::BUFFER_CHANNEL_OMIT_LINKS,
            self::BUFFER_CHANNEL_OBFUSCATE_LINKS,
		);
	}

	/**
	 * Convert an auto-generation interval value to seconds.
	 *
	 * Handles both legacy string values ('hourly', '2hours', etc.)
	 * and new numeric minute values (e.g. 15, 30, 60).
	 *
	 * @param mixed $interval The stored interval value.
	 * @return int Interval in seconds (minimum 300 = 5 minutes).
	 */
	public static function interval_to_seconds( $interval ): int {
		if ( is_numeric( $interval ) && (int) $interval > 0 ) {
			return max( 300, (int) $interval * MINUTE_IN_SECONDS );
		}

		$raw = (string) $interval;

		if ( preg_match( '/^(\d+)hours?$/i', $raw, $m ) ) {
			return max( 300, (int) $m[1] * HOUR_IN_SECONDS );
		}
		if ( $raw === 'twicedaily' ) {
			return 12 * HOUR_IN_SECONDS;
		}
		if ( $raw === 'daily' ) {
			return DAY_IN_SECONDS;
		}
		if ( $raw === 'twodays' ) {
			return 2 * DAY_IN_SECONDS;
		}

		return HOUR_IN_SECONDS;
	}
}