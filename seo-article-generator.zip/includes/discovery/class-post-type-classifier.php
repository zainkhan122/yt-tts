<?php
namespace SEO_Article_Generator\Discovery;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class Post_Type_Classifier {

    const TYPE_NEW           = 'new';
    const TYPE_LEGACY        = 'legacy';
    const TYPE_PLUGIN        = 'plugingenerated';
    const TYPE_PLUGIN_LEGACY = 'plugingeneratedlegacy';

    private const META_CONTENT_CONTRACT        = '_seo_gen_content_contract';
    private const META_CONTENT_CONTRACT_LEGACY = 'seogencontentcontract';
    private const CONTENT_CONTRACT_V1          = 'blocks-v1';

    /**
     * FIX F8 (Phase 3B, 2.32.26): every content-contract meta key ever written.
     *   _seo_gen_content_contract  — canonical
     *   seogencontentcontract      — legacy underscore-less variant
     *   _seogen_content_contract   — typo variant historically read by the engine
     */
    private const META_CONTENT_CONTRACT_KEYS = [
        self::META_CONTENT_CONTRACT,
        self::META_CONTENT_CONTRACT_LEGACY,
        '_seogen_content_contract',
    ];

    private const PLUGIN_META_SIGNALS = [
        self::META_CONTENT_CONTRACT,
        self::META_CONTENT_CONTRACT_LEGACY,
        '_seo_gen_hero_data',
        'seogenherodata',
        '_seo_gen_version',
        'seogenversion',
        '_seo_gen_software_name',
        'seogensoftwarename',
        '_seo_gen_article_snapshot',
        'seogenarticlesnapshot',
        '_seo_gen_heading_map',
        'seogenheadingmap',
        '_seo_gen_article_data',
        'seogenarticledata',
        '_seo_gen_schema_snapshot',
        'seogenschemasnapshot',
    ];

    private const PLUGIN_CONTENT_SIGNALS = [
        'seo-gen-',
        'wp:seo-gen/',
        'data-seo-gen-zone=',
        '<!-- SW_',
        '<!-- seo-gen-',
    ];

    public static function classify( int $post_id ): string {
        if ( $post_id <= 0 ) {
            return self::TYPE_NEW;
        }
        $post = \get_post( $post_id );
        if ( ! $post || ! is_a( $post, 'WP_Post' ) ) {
            return self::TYPE_NEW;
        }
        if ( empty( trim( $post->post_content ) ) ) {
            return self::TYPE_NEW;
        }

        // CRITICAL FIX: Check _seo_gen_force_legacy_rewrite flag BEFORE content contract.
        // When approve_item() sets this flag (post has no sentinels), the post MUST be
        // routed to TYPE_LEGACY full rewrite regardless of any existing content contract.
        // The contract check below would otherwise return TYPE_PLUGIN_LEGACY for posts
        // that have blocks-v1 but no sentinel structure, producing empty html_content
        // and zero-content posts after finalization.
        // STALE FLAG GUARD: If the flag is set but the post already has sentinel structure,
        // the flag is stale from a previous failed session — clear it and proceed.
        $legacy_flag = \get_post_meta( $post_id, '_seo_gen_force_legacy_rewrite', true );
        if ( $legacy_flag ) {
            if ( ! self::has_sentinel_structure( $post->post_content ) ) {
                return self::TYPE_LEGACY;
            }
            \delete_post_meta( $post_id, '_seo_gen_force_legacy_rewrite' );
        }

        // CRITICAL FIX: Check content contract FIRST.
        // A post with blocks-v1 contract has been successfully migrated and
        // must be classified as TYPE_PLUGIN regardless of legacy flags.
        // The _seo_gen_force_legacy_rewrite meta is a transient migration
        // directive — once sentinels are written and contract is persisted,
        // the post is no longer legacy.
        if ( self::has_content_contract( $post->ID ) ) {
            if ( self::has_sentinel_structure( $post->post_content ) ) {
                return self::TYPE_PLUGIN;
            }
            return self::TYPE_PLUGIN_LEGACY;
        }

        $has_ownership = self::has_plugin_meta_signals( $post->ID )
                       || self::has_plugin_content_signals( $post->post_content );
        if ( $has_ownership ) {
            if ( self::has_sentinel_structure( $post->post_content ) ) {
                return self::TYPE_PLUGIN;
            }
            return self::TYPE_PLUGIN_LEGACY;
        }
        return self::TYPE_LEGACY;
    }

    public static function is_plugin_owned( string $type ): bool {
        return in_array( $type, [ self::TYPE_PLUGIN, self::TYPE_PLUGIN_LEGACY ], true );
    }

    public static function label( string $type ): string {
        return [
            self::TYPE_NEW           => 'New Post (full generation)',
            self::TYPE_LEGACY        => 'Legacy Post (full rewrite)',
            self::TYPE_PLUGIN        => 'Plugin Post (surgical patch)',
            self::TYPE_PLUGIN_LEGACY => 'Plugin Post - Old Format (migrate then patch)',
        ][ $type ] ?? 'Unknown';
    }

    /**
     * Single reader for the content contract (F8). Reads every known contract
     * meta key and returns the stored contract string ('' when absent).
     * Owned here so classify()/canonicalize()/the engine all agree on which
     * post carries a blocks-v1 contract.
     */
    public static function get_content_contract( int $post_id ): string {
        foreach ( self::META_CONTENT_CONTRACT_KEYS as $key ) {
            $value = \get_post_meta( $post_id, $key, true );
            if ( $value !== '' && $value !== null && $value !== false ) {
                return (string) $value;
            }
        }
        return '';
    }

    public static function has_content_contract( int $post_id ): bool {
        return self::get_content_contract( $post_id ) === self::CONTENT_CONTRACT_V1;
    }

    private static function has_plugin_meta_signals( int $post_id ): bool {
        foreach ( self::PLUGIN_META_SIGNALS as $meta_key ) {
            $value = \get_post_meta( $post_id, $meta_key, true );
            if ( '' !== $value && null !== $value && false !== $value ) {
                return true;
            }
        }
        return false;
    }

    private static function has_plugin_content_signals( string $content ): bool {
        foreach ( self::PLUGIN_CONTENT_SIGNALS as $signal ) {
            if ( strpos( $content, $signal ) !== false ) {
                return true;
            }
        }
        return false;
    }

    public static function has_sentinel_structure( string $content ): bool {
        if ( strpos( $content, '<!-- wp:seo-gen/section ' ) !== false ) {
            return true;
        }
        if ( preg_match( '/<!--\s*seo-gen-zone(?::|\s+)[a-z0-9_-]+\s*-->/i', $content ) ) {
            return true;
        }
        if ( strpos( $content, 'data-seo-gen-zone=' ) !== false ) {
            return true;
        }
        return false;
    }
}