<?php

namespace DIT\TrendStudio\Services;

use DIT\TrendStudio\Infrastructure\Logger;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Media Passthrough
 * Ensures that visuals present in the input (images/embeds/social links) are preserved in output.
 *
 * This avoids relying on the LLM to repeat URLs verbatim.
 */
class Media_Passthrough
{
    private ?Logger $logger;

    public function __construct(?Logger $logger = null)
    {
        $this->logger = $logger;
    }

    /**
     * Extract required visuals (URLs) from raw HTML/text blob.
     * @MODIFIED 2026-02-14 - Returns associative array of [source_html => url] for robust comparison.
     */
    public function extract_required_visuals(string $html): array
    {
        $visuals = [];

        // [embed] shortcodes
        if (preg_match_all('/\[embed\]([^\[]+)\[\/embed\]/i', $html, $m)) {
            foreach ($m[1] as $i => $u) {
                $u = trim($u);
                if ($u) {
                    $u = \DIT\TrendStudio\Security\Sanitizer::decode_ai_string($u);
                    $visuals[$m[0][$i]] = $u;
                }
            }
        }

        // img src
        // @MODIFIED 2026-02-13 - Extract full tag to ensure native block parsing in PostComposer
        // @MODIFIED 2026-02-14 - Map tag to URL
        // @MODIFIED 2026-02-15 - Harden regex to handle varied attribute order and over-escaping
        // Uses non-greedy [^>]+? and explicit boundary to prevent greedy attribute stealing.
        if (preg_match_all('/(<img[^>]+?\b(?:src|data-src|data-lazy-src)=\\\\?["\'](.*?)\\\\?["\'][^>]*>)/i', $html, $m)) {
            foreach ($m[1] as $i => $tag) {
                $tag = trim($tag);
                if ($tag) {
                    $url = \DIT\TrendStudio\Security\Sanitizer::decode_ai_string($m[2][$i]);
                    $visuals[\DIT\TrendStudio\Security\Sanitizer::decode_ai_string($tag)] = $url;
                }
            }
        }

        // iframe src
        // @MODIFIED 2026-02-13 - Extract full tag for embeds
        // @MODIFIED 2026-02-14 - Map tag to URL
        if (preg_match_all('/(<iframe[^>]+src=\\\\?["\'](.*?)\\\\?["\'][^>]*>.*?<\/iframe>|<iframe[^>]+src=\\\\?["\'](.*?)\\\\?["\'][^>]*\/>)/is', $html, $m)) {
            foreach ($m[0] as $i => $tag) {
                $tag = trim($tag);
                if ($tag) {
                    $url = \DIT\TrendStudio\Security\Sanitizer::decode_ai_string($m[2][$i] ?: $m[3][$i]);
                    $visuals[\DIT\TrendStudio\Security\Sanitizer::decode_ai_string($tag)] = $url;
                }
            }
        }

        // social blockquotes -> url (tiktok/facebook/ig/twitter)
        if (preg_match_all('/<blockquote[^>]*>(.*?)<\/blockquote>/is', $html, $bqs)) {
            foreach ($bqs[0] as $bq) {
                $cls = '';
                if (preg_match('/class=\\\\?["\'](.*?)\\\\?["\']/i', $bq, $cm)) $cls = $cm[1];

                $is_social = (
                    strpos($cls, 'twitter-tweet') !== false ||
                    strpos($cls, 'instagram-media') !== false ||
                    strpos($cls, 'tiktok-embed') !== false ||
                    strpos($cls, 'fb-video') !== false ||
                    strpos($cls, 'fb-post') !== false
                );
                if (!$is_social) continue;

                $url = '';
                if (preg_match('/\scite=\\\\?["\'](.*?)\\\\?["\']/i', $bq, $m)) $url = \DIT\TrendStudio\Security\Sanitizer::decode_ai_string($m[1]); // @MODIFIED 2026-02-15 - Handle escaped quotes

                if (empty($url) && preg_match_all('/<a[^>]+href=\\\\?["\'](.*?)\\\\?["\']/i', $bq, $links) && !empty($links[1])) {
                    $url = end($links[1]);
                }

                if (!empty($url)) {
                    $visuals[trim($bq)] = trim($url);
                }
            }
        }

        // @MODIFIED 2026-02-14 - Filter out blacklisted visuals (Smart Channel Detection)
        $blacklist_raw = get_option('dit_ts_smn_blacklist', '');
        // Robust split for various newline formats
        $blacklist_terms = array_filter(preg_split('/\r\n|\r|\n/', $blacklist_raw));
        $blacklist_terms = array_map('trim', $blacklist_terms);
        $blacklist_terms = array_filter($blacklist_terms); // Remove empty strings after trim

        if (!empty($blacklist_terms) && !empty($visuals)) {
            foreach ($visuals as $tag => $url) {
                $is_blacklisted = false;

                // 1. Direct String Match (Fast)
                foreach ($blacklist_terms as $term) {
                    if (stripos($url, $term) !== false || stripos($tag, $term) !== false) {
                        $is_blacklisted = true;
                        $this->logger && $this->logger->info("Media Blacklisted (Direct): $url matches '$term'");
                        break;
                    }
                }

                // 2. Smart OEmbed Lookup (Slow - Context Aware)
                // Only if it's a YouTube video and NOT already blacklisted
                if (!$is_blacklisted && (strpos($url, 'youtube.com') !== false || strpos($url, 'youtu.be') !== false)) {

                    // Helper to get oembed data using global WP function
                    if (function_exists('_wp_oembed_get_object')) {
                        $oembed = \_wp_oembed_get_object();
                        if ($oembed) {
                            $provider = $oembed->get_provider($url);
                            if ($provider) {
                                $data = $oembed->fetch($provider, $url);
                                if ($data && isset($data->author_url)) {
                                    foreach ($blacklist_terms as $term) {
                                        if (stripos($data->author_url, $term) !== false || (isset($data->author_name) && stripos($data->author_name, $term) !== false)) {
                                            $is_blacklisted = true;
                                            $this->logger && $this->logger->info("Media Blacklisted (Smart): $url belongs to channel '$term' (" . $data->author_url . ")");
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if ($is_blacklisted) {
                    unset($visuals[$tag]);
                }
            }
        }

        return $visuals;
    }

    /**
     * Get required visuals from input data.
     *
     * @param array $input_data Source input data
     * @param string $vertical Vertical (e.g. 'showbiz', 'fashion')
     * @return array [tag => url]
     */
    /**
     * Get required visuals from input data.
     *
     * @param array $input_data Source input data
     * @param string $vertical Vertical (e.g. 'showbiz', 'fashion')
     * @return array [tag => url]
     */
    public function get_required_visuals(array $input_data, string $vertical): array
    {
        // 1. Prefer the pre-calculated source visual map (from Phase 2 Smart Selection)
        if (!empty($input_data['source_visual_map']) && is_array($input_data['source_visual_map'])) {
            $visuals = [];
            foreach ($input_data['source_visual_map'] as $token => $data) {
                // map token => url? OR tag => url?
                // ensure_media_passthrough expects [tag => url].
                if (!empty($data['tag']) && !empty($data['url'])) {
                    $visuals[$data['tag']] = $data['url'];
                }
            }
            if (!empty($visuals)) {
                return $visuals;
            }
        }

        // 2. Fallback: Parse raw text/html
        $text = ($input_data['idea_text'] ?? '') . "\n" . ($input_data['source_urls'] ?? '');
        return $this->extract_required_visuals($text);
    }

    /**
     * ensure_media_passthrough wrapper (for back-compat if needed, though we updated call sites)
     */
    public function Legacy_ensure_media_passthrough(array $article, string $html): array
    {
        // ... implementation if needed, but we are fixing the main one
        return $article;
    }

    /**
     * Ensure extracted visuals appear in article sections (adds a dedicated "Media" section if needed).
     *
     * @param array $article Article schema array
     * @param string $source_blob Input blob that contains media (idea_text + source_urls)
     * @param string $headline Optional post headline for alt text synchronization
     * @return array
     */
    public function ensure_media_passthrough(array $article, array $input_data, string $vertical): array
    {
        $required = $this->get_required_visuals($input_data, $vertical);
        if (empty($required)) {
            // Even if no specific required logic, we might want simple passthrough if it's token based
            // but for now, we return if empty.
            if (empty($input_data['source_visual_map'])) {
                return $article;
            }
        }

        // @MODIFIED 2026-02-16 - Phase 3: Structured blocks passthrough using visual_ref.
        $pmode = (string) get_option('dit_ts_media_placement_mode', 'token_matcher');
        if ($pmode === 'structured_blocks') {
            $vmap = [];
            // @MODIFIED 2026-02-17 - Fix: Look in input_data for the map, as article schema doesn't carry it yet
            if (!empty($input_data['source_visual_map']) && is_array($input_data['source_visual_map'])) {
                $vmap = $input_data['source_visual_map'];
            } elseif (!empty($article['_source_visual_map']) && is_array($article['_source_visual_map'])) {
                // Fallback if attached elsewhere
                $vmap = $article['_source_visual_map'];
            }

            $expected = [];
            foreach (array_keys($vmap) as $k) {
                if (preg_match('/^\[VISUAL_(\d+)\]$/', (string) $k, $m)) {
                    $expected[] = (int) $m[1];
                }
            }
            $expected = array_values(array_unique($expected));
            if (empty($expected)) {
                return $article;
            }

            $seen = [];
            foreach ((array) ($article['sections'] ?? []) as $si => $s) {
                foreach ((array) ($s['blocks'] ?? []) as $b) {
                    if (is_array($b) && ($b['type'] ?? '') === 'visual_ref' && isset($b['id'])) {
                        $seen[] = (int) $b['id'];
                    }
                }
            }
            $seen = array_values(array_unique($seen));

            $missing = array_values(array_diff($expected, $seen));

            // @MODIFIED 2026-06-28 - Do NOT return early if no missing visual_refs,
            // because embed_ref blocks may still be missing. Check both.
            $has_missing_visuals = !empty($missing);

            $oembed_hosts = ['youtube.com', 'youtu.be', 'vimeo.com', 'tiktok.com', 'instagram.com', 'twitter.com', 'x.com', 'facebook.com', 'pinterest.com'];
            $missing_embeds = [];
            if (!empty($required)) {
                $existing_embed_urls = [];
                foreach ((array) ($article['sections'] ?? []) as $sec) {
                    foreach ((array) ($sec['blocks'] ?? []) as $b) {
                        if (($b['type'] ?? '') === 'embed_ref' && !empty($b['url'])) {
                            $existing_embed_urls[] = strtolower($b['url']);
                        }
                    }
                }
                foreach ($required as $req_tag => $req_url) {
                    $host = strtolower(parse_url($req_url, PHP_URL_HOST) ?: '');
                    $is_embed = false;
                    foreach ($oembed_hosts as $dh) {
                        if (stripos($host, $dh) !== false) {
                            $is_embed = true;
                            break;
                        }
                    }
                    if (!$is_embed) continue;
                    $found = false;
                    foreach ($existing_embed_urls as $eu) {
                        if (stripos($eu, strtolower($req_url)) !== false || stripos(strtolower($req_url), $eu) !== false) {
                            $found = true;
                            break;
                        }
                    }
                    if (!$found) {
                        $missing_embeds[] = $req_url;
                    }
                }
            }

            if (!$has_missing_visuals && empty($missing_embeds)) {
                return $article;
            }

            // Append missing refs to last section as a small gallery (do not fail publishing).
            $last = count((array) ($article['sections'] ?? [])) - 1;
            if ($last < 0) {
                $article['sections'] = [
                    ['heading' => 'Gallery', 'verification_status' => 'UNVERIFIED', 'blocks' => []],
                ];
                $last = 0;
            }
            if (empty($article['sections'][$last]['blocks']) || !is_array($article['sections'][$last]['blocks'])) {
                $article['sections'][$last]['blocks'] = [];
            }

            foreach ($missing as $id) {
                $article['sections'][$last]['blocks'][] = ['type' => 'visual_ref', 'id' => (int) $id];
            }

            // @MODIFIED 2026-06-28 - Reinject missing embed_ref blocks (Instagram/YouTube/TikTok embeds)
            // $missing_embeds was already computed above before the early-return check.
            foreach ($missing_embeds as $embed_url) {
                $article['sections'][$last]['blocks'][] = ['type' => 'embed_ref', 'url' => $embed_url];
                if ($this->logger) {
                    $this->logger->info('Media passthrough injected missing embed_ref', ['url' => $embed_url]);
                }
            }

            return $article;
        }

        // Legacy token logic follows...
        $headline = $article['headline'] ?? '';

        // We scan the final HTML to see which token keys are present.
        $out = $this->render_preview_html($article);

        $missing_tags = [];
        // @MODIFIED 2026-02-15 - Token-aware de-confliction.
        // We track a counter to match against [VISUAL_N] tokens if they leaked.
        // This index aligns with ContentPipeline::tokenize_source_visuals().
        $counter = 0;
        $seen_norm_urls = []; // @MODIFIED 2026-02-21 - Track normalized URLs to prevent triple-dipping

        foreach ($required as $tag => $url) {
            $norm_url = $this->normalize_url_for_dedupe($url);

            // 1. Check if either the original tag OR the URL is present
            // @MODIFIED 2026-02-21 - Added normalized URL check to prevent duplication of similar URLs (e.g. w/o timestamp)
            if (stripos($out, $tag) !== false || stripos($out, $url) !== false || $this->url_exists_in_html($norm_url, $out) || isset($seen_norm_urls[$norm_url])) {
                $counter++;
                continue;
            }

            // 2. Check for the specific [VISUAL_N] token that represents this item.
            // This prevents duplicate injection if the token was leaked/not swapped.
            $token = "[VISUAL_{$counter}]";
            if (stripos($out, $token) !== false) {
                // @MODIFIED 2026-02-16 - Token leakage rescue: if tokens were not swapped back,
                // replace the leaked token in-place with the original <img> tag rather than skipping injection.
                if (! empty($article['sections']) && is_array($article['sections'])) {
                    foreach ($article['sections'] as &$section) {
                        $key = ! empty($section['body_html']) ? 'body_html' : (! empty($section['bodyhtml']) ? 'bodyhtml' : '');
                        if ($key && stripos((string) $section[$key], $token) !== false) {
                            $section[$key] = str_ireplace($token, $tag, (string) $section[$key]);
                        }
                    }
                    unset($section);
                }

                $out = str_ireplace($token, $tag, $out);
                $seen_norm_urls[$norm_url] = true;
                $counter++;
                continue;
            }

            // 3. Fallback: Check for filename match WITHOUT extension (e.g. "my-image")
            // This prevents duplicates if the AI changed the extension (e.g. jpg -> webp) or protocol.
            $filename = basename(parse_url($url, PHP_URL_PATH) ?: '');
            $pure_name = pathinfo($filename, PATHINFO_FILENAME);
            if (!empty($pure_name) && stripos($out, $pure_name) !== false) {
                $counter++;
                continue;
            }

            $missing_tags[$tag] = $url;
            $seen_norm_urls[$norm_url] = true;
            $counter++;
        }

        if (empty($missing_tags)) {
            return $article;
        }

        $media_html = $this->build_media_section_html($missing_tags, $headline);

        $article['sections'] = $article['sections'] ?? [];
        $article['sections'][] = [
            'heading'   => '', // Empty heading to avoid <h2>Media</h2>
            'body_html' => $media_html,
            'verification_status' => 'VERIFIED',
        ];

        if ($this->logger) {
            $this->logger->info('Media passthrough injected missing visuals', [
                'missing_count' => count($missing_tags),
            ]);
        }

        return $article;
    }

    private function build_media_section_html(array $visual_map, string $alt_text = ''): string
    {
        $chunks = [];

        foreach ($visual_map as $tag => $u) {
            $tag = trim((string) $tag);
            $u   = trim((string) $u);
            if ($tag === '' && $u === '') continue;

            // If we have the original tag, use it (it might be a complex blockquote or iframe)
            if (strpos($tag, '<') === 0) {
                // If it's an img tag and we have alt_text, try to inject it if missing
                if (stripos($tag, '<img') === 0 && !empty($alt_text) && (stripos($tag, 'alt=""') !== false || stripos($tag, 'alt=\'\'') !== false || stripos($tag, ' alt ') === false)) {
                    if (stripos($tag, ' alt ') === false) {
                        $tag = str_ireplace('<img', '<img alt="' . esc_attr($alt_text) . '"', $tag);
                    } else {
                        $tag = str_ireplace(['alt=""', "alt=''"], 'alt="' . esc_attr($alt_text) . '"', $tag);
                    }
                }
                $chunks[] = $tag;
                continue;
            }

            // Fallback for bare URLs
            $path = parse_url($u, PHP_URL_PATH) ?: '';
            $host = parse_url($u, PHP_URL_HOST) ?: '';
            $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));

            // Check for image extensions
            if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'gif'], true)) {
                // Construct clean image block
                $html = '';
                $html .= '<figure class="wp-block-image size-large">';
                $html .= '<img src="' . esc_url($u) . '" alt="' . (!empty($alt_text) ? esc_attr($alt_text) : '') . '" />';
                $html .= '</figure>';
                $chunks[] = $html;
                continue;
            }

            // Check for OEmbed Support (YouTube, Vimeo, etc) or general video
            // Similar logic to PostComposer::detect_oembed_url, but simplified for restoration validation
            $is_oembed = false;
            $detect_hosts = ['youtube.com', 'youtu.be', 'vimeo.com', 'tiktok.com', 'instagram.com', 'twitter.com', 'x.com', 'facebook.com', 'pinterest.com'];
            foreach ($detect_hosts as $dh) {
                if (stripos($host, $dh) !== false) {
                    $is_oembed = true;
                    break;
                }
            }

            if ($is_oembed) {
                // Output as a clean [embed] shortcode
                // PostComposer::parse_body_to_elements will detect this as an embed
                // @MODIFIED 2026-02-21 - Ensure YouTube URLs with timestamps are standalone for Gutenberg detection
                // @MODIFIED 2026-03-08 - Use [embed] for maximum compatibility with Gutenberg block serialization
                $chunks[] = '[embed]' . esc_url($u) . '[/embed]';
                continue;
            }
        }

        return "\n" . implode("\n\n", $chunks) . "\n";
    }

    /**
     * Helper to render article preview HTML for token scanning.
     */
    private function render_preview_html(array $article): string
    {
        $html = '';
        foreach (($article['sections'] ?? []) as $section) {
            $html .= ($section['heading'] ?? '') . ' ';
            $html .= ($section['body_html'] ?? '') . ' ';
        }
        return $html;
    }

    /**
     * Normalize URL for de-duplication purposes.
     * Strips protocol, www, and common video parameters while preserving timestamps.
     * 
     * @MODIFIED 2026-02-21 - NEW
     */
    private function normalize_url_for_dedupe(string $url): string
    {
        $u = strtolower(trim($url));
        $u = preg_replace('/^https?:\/\/(?:www\.)?/', '', $u);

        // For YouTube, unify watch?v= and youtu.be/
        if (stripos($u, 'youtube.com/watch') !== false || stripos($u, 'youtu.be/') !== false) {
            if (preg_match('/(?:v=|v\/|embed\/|youtu\.be\/)([a-zA-Z0-9_-]{11})/', $u, $m)) {
                $vid = $m[1];
                // Extract timestamp if present (t=10 or start=10)
                $t = '';
                if (preg_match('/[?&](t|start)=([^&#]+)/', $u, $tm)) {
                    $t = $tm[2];
                }
                return 'youtube:' . $vid . ($t ? ':t' . $t : '');
            }
        }

        return $u;
    }

    /**
     * Check if a normalized URL exists in a piece of HTML.
     * 
     * @MODIFIED 2026-02-21 - NEW
     */
    private function url_exists_in_html(string $norm_url, string $html): bool
    {
        if ($norm_url === '') return false;

        // If it's a normalized youtube ID, check for the ID itself in the HTML
        if (strpos($norm_url, 'youtube:') === 0) {
            $parts = explode(':', $norm_url);
            $vid = $parts[1] ?? '';
            return ($vid !== '' && stripos($html, $vid) !== false);
        }

        return stripos($html, $norm_url) !== false;
    }
}
