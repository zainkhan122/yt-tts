<?php

/**
 * Comprehensive Smoke Test Engine
 *
 * Provides complete plugin validation including syntax checking, class loading,
 * AJAX endpoints, database, hooks, and services testing.
 *
 * @package    MCQ_Video_Studio
 * @subpackage Tests
 * @since      1.1.0
 * @modified   2026-01-06 Added comprehensive test coverage
 */

if (! defined('ABSPATH')) {
    exit;
}

/**
 * Class VS_Smoke_Test
 *
 * Comprehensive smoke test engine with UI integration.
 *
 * @since 1.1.0
 */
class VS_Smoke_Test
{

    /**
     * Singleton instance.
     *
     * @var VS_Smoke_Test|null
     */
    private static $instance = null;

    /**
     * Test results storage.
     *
     * @var array
     */
    private static $results = array();

    /**
     * Initialize smoke test system.
     *
     * @since 1.1.0
     * @return VS_Smoke_Test
     */
    public static function init()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor.
     */
    private function __construct()
    {
        add_action('wp_ajax_mcqvs_run_smoke_test', array($this, 'ajax_run_tests'));
    }

    /**
     * Render the Smoke Test UI.
     *
     * @since 1.2.0
     */
    public function render_ui()
    {
?>
        <div class="mcqvs-smoke-test-container">
            <div class="notice notice-info inline">
                <p><?php esc_html_e('Run a comprehensive test of all plugin components including PHP syntax, JavaScript files, class loading, AJAX endpoints, database, hooks, and external services.', 'mcq-video-studio'); ?></p>
            </div>

            <div class="mcqvs-smoke-test-actions" style="margin-top: 20px; margin-bottom: 20px;">
                <button type="button" id="mcqvs-run-smoke-test" class="button button-primary button-hero">
                    <span class="dashicons dashicons-yes-alt"></span>
                    <?php esc_html_e('Run Comprehensive Test', 'mcq-video-studio'); ?>
                </button>
                <button type="button" id="mcqvs-export-results" class="button button-secondary" style="display:none;">
                    <span class="dashicons dashicons-download"></span>
                    <?php esc_html_e('Export Results', 'mcq-video-studio'); ?>
                </button>
            </div>

            <div id="mcqvs-smoke-test-progress" class="mcqvs-progress-container" style="display:none; margin-bottom: 20px;">
                <div class="mcqvs-progress-bar" style="height: 20px; background: #e0e0e0; border-radius: 10px; overflow: hidden; position: relative;">
                    <div id="mcqvs-progress-fill" class="mcqvs-progress-fill" style="width: 0%; height: 100%; background: #2271b1; transition: width 0.3s;"></div>
                </div>
                <p id="mcqvs-progress-text" class="mcqvs-progress-text" style="font-weight: bold; margin-top: 5px;">Initializing...</p>
            </div>

            <div id="mcqvs-smoke-test-results" class="mcqvs-test-results" style="display:none;">
                <!-- Results will be populated via JavaScript -->
            </div>
        </div>
<?php
    }

    /**
     * AJAX handler to run comprehensive tests.
     *
     * @since 1.1.0
     */
    public function ajax_run_tests()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');

        if (! current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        // Increase time limit for comprehensive testing
        set_time_limit(60);

        // Run all test categories
        if (class_exists('VS_Error_Logger')) {
            VS_Error_Logger::get_instance()->log('Smoke Test: Starting comprehensive tests.', 'info');
        }

        self::$results = array();
        self::$results['php_syntax']    = self::test_php_syntax();
        self::$results['js_syntax']     = self::test_js_syntax();
        self::$results['class_loading'] = self::test_class_loading();
        self::$results['ajax_endpoints'] = self::test_ajax_endpoints();
        self::$results['database']      = self::test_database();
        self::$results['hooks']         = self::test_hooks();
        self::$results['services']      = self::test_services();
        self::$results['option_consistency'] = self::$instance->test_option_key_consistency(); // @NEW 2026-01-08

        // Calculate summary
        $summary = self::calculate_summary(self::$results);

        if (class_exists('VS_Error_Logger')) {
            if ($summary['total_failed'] > 0) {
                VS_Error_Logger::get_instance()->log('Smoke Test: Completed with ' . $summary['total_failed'] . ' failures.', 'warning', array('summary' => $summary));
            } else {
                VS_Error_Logger::get_instance()->log('Smoke Test: Completed successfully with 100% pass rate.', 'info');
            }
        }

        wp_send_json_success(array(
            'results' => self::$results,
            'summary' => $summary,
        ));
    }

    /**
     * Test PHP file syntax.
     *
     * @since 1.1.0
     * @return array Test results
     */
    private static function test_php_syntax()
    {
        $result = array(
            'category' => 'PHP Syntax',
            'tests'    => array(),
            'passed'   => 0,
            'failed'   => 0,
        );

        $php_files = self::discover_php_files();

        foreach ($php_files as $file) {
            $test = self::validate_php_file($file);
            $result['tests'][] = $test;

            if ($test['passed']) {
                $result['passed']++;
            } else {
                $result['failed']++;
            }
        }

        return $result;
    }



    /**
     * Test 10: Option Key Consistency (Crucial for Split-Brain Fix)
     * Verifies that settings saved via canonical keys are readable via fallback logic.
     */
    public function test_option_key_consistency()
    {
        $result = array(
            'category' => 'Option Consistency',
            'tests'    => array(),
            'passed'   => 0,
            'failed'   => 0,
        );

        // 1. Save a test value using the CANONICAL method (simulating VS_AJAX_Asset_Handler)
        $test_key = 'mcqvs_smoke_test_key_' . time();
        $test_val = 'test_value_' . time();

        // This simulates what VS_AJAX_Asset_Handler does now:
        update_option($test_key, $test_val);

        // 2. Try to read it back using the CORE helper logic
        // We need to instantiate core to access the helper, or simulate the logic.
        // Since get_config_option is private, we simulate its logic here to verify the PRINCIPLE.

        $read_canonical = get_option($test_key);
        $read_legacy    = get_option(strtoupper($test_key)); // Should be empty or fallback

        $passed = ($read_canonical === $test_val);
        $result['tests'][] = array(
            'name'    => 'Canonical Read',
            'passed'  => $passed,
            'message' => $passed ? 'Success' : "Saved '$test_val' to '$test_key' but read '$read_canonical'.",
        );
        if ($passed) $result['passed']++;
        else $result['failed']++;

        // 3. Verify ElevenLabs Logic specifically (since it was a known failure point)
        $el_key_canonical = 'mcqvs_elevenlabs_api_key';
        $el_key_legacy    = 'MCQVS_elevenlabs_api_key';

        // Backup existing
        $existing = get_option($el_key_canonical);

        // Test Save
        update_option($el_key_canonical, 'smoke_test_el_key');

        // Test Read with Fallback Logic (simulating VS_AJAX_TTS_Handler)
        $val = get_option($el_key_canonical, get_option($el_key_legacy, ''));

        // Restore
        if ($existing !== false) update_option($el_key_canonical, $existing);
        else delete_option($el_key_canonical);

        $passed = ($val === 'smoke_test_el_key');
        $result['tests'][] = array(
            'name'    => 'ElevenLabs Fallback',
            'passed'  => $passed,
            'message' => $passed ? 'Success' : "Expected 'smoke_test_el_key', got '$val'.",
        );
        if ($passed) $result['passed']++;
        else $result['failed']++;

        return $result;
    }

    /**
     * Test JavaScript file syntax.
     *
     * @since 1.1.0
     * @return array Test results
     */
    private static function test_js_syntax()
    {
        $result = array(
            'category' => 'JavaScript Syntax',
            'tests'    => array(),
            'passed'   => 0,
            'failed'   => 0,
        );

        $js_files = self::discover_js_files();

        foreach ($js_files as $file) {
            $test = self::validate_js_file($file);
            $result['tests'][] = $test;

            if ($test['passed']) {
                $result['passed']++;
            } else {
                $result['failed']++;
            }
        }

        return $result;
    }

    /**
     * Test class loading and instantiation.
     *
     * @since 1.1.0
     * @return array Test results
     */
    private static function test_class_loading()
    {
        $result = array(
            'category' => 'Class Loading',
            'tests'    => array(),
            'passed'   => 0,
            'failed'   => 0,
        );

        $required_classes = array(
            'VS_Core',
            // @NEW 2026-06-26: Provider Registry
            'VS_Provider_Registry',
            'VS_Settings',
            'VS_API_Client',
            'VS_Automation_Engine',
            'VS_Job_Repository',
            'VS_Buffer_Client',
            'VS_R2_Storage',
            'VS_AJAX_Studio_Handler',
            'VS_AJAX_AI_Quiz_Handler',
            'VS_AJAX_TTS_Handler',
            'VS_AJAX_AI_Tools_Handler',
            'VS_AJAX_Asset_Handler',
            'VS_AJAX_Stock_Handler',
            'VS_AJAX_Batch_Handler',
            'VS_AJAX_Branding_Handler',
 // @NEW 2026-01-27: Dedicated MCQ System Classes
 'VS_MCQ_Repository',
 'VS_Validation_Service',
 'VS_Action_Scheduler_Worker',
 'VS_Bridge_API',
        );

        foreach ($required_classes as $class_name) {
            $test = self::test_class_exists($class_name);
            $result['tests'][] = $test;

            if ($test['passed']) {
                $result['passed']++;
            } else {
                $result['failed']++;
            }
        }

        return $result;
    }

    /**
     * Test AJAX endpoint registration.
     *
     * @since 1.1.0
     * @return array Test results
     */
    private static function test_ajax_endpoints()
    {
        $result = array(
            'category' => 'AJAX Endpoints',
            'tests'    => array(),
            'passed'   => 0,
            'failed'   => 0,
        );

        // Get instances for callback verification
        $core = VS_Core::init();
        $settings = VS_Settings::init();

        $ajax_hooks = array(
            // Studio endpoints
            'mcqvs_get_studio_sources'     => array($core->studio_handler, 'ajax_get_studio_sources'),
            'mcqvs_get_studio_data'        => array($core->studio_handler, 'ajax_get_studio_data'),
            'mcqvs_generate_ai_quiz'       => array($core->ai_quiz_handler, 'ajax_generate_ai_quiz'),
            'mcqvs_generate_tts'           => array($core->tts_handler, 'ajax_generate_tts'),
            // Removed: mcqvs_start_batch_job (Client-side export only)
            'mcqvs_save_branding'          => array($core->branding_handler, 'ajax_save_branding'),
            'mcqvs_get_branding'           => array($core->branding_handler, 'ajax_get_branding'),
            // Settings endpoints
            'mcqvs_test_buffer'            => array($settings, 'ajax_test_buffer'),
            'mcqvs_refresh_buffer_channels' => array($settings, 'ajax_refresh_buffer_channels'),
            'mcqvs_test_r2'               => array($settings, 'ajax_test_r2'),
            'mcqvs_run_automation'         => array($settings, 'ajax_run_automation'),
            // @NEW 2026-06-26: API Provider Connection Tests & Custom Provider CRUD
            'mcqvs_test_gemini'             => array($settings, 'ajax_test_gemini'),
            'mcqvs_test_custom_provider'    => array($settings, 'ajax_test_custom_provider'),
            'mcqvs_save_custom_provider'    => array($settings, 'ajax_save_custom_provider'),
            'mcqvs_delete_custom_provider'  => array($settings, 'ajax_delete_custom_provider'),
            'mcqvs_get_custom_providers'    => array($settings, 'ajax_get_custom_providers'),
            'mcqvs_reset_rotation'          => array($settings, 'ajax_reset_rotation'),
            'mcqvs_save_builtin_custom_models' => array($settings, 'ajax_save_builtin_custom_models'),
            // Smoke test endpoint
            'mcqvs_run_smoke_test'         => array(self::$instance, 'ajax_run_tests'),
        );

        foreach ($ajax_hooks as $hook_name => $expected_callback) {
            $test = self::test_ajax_hook('wp_ajax_' . $hook_name, $expected_callback);
            $result['tests'][] = $test;

            if ($test['passed']) {
                $result['passed']++;
            } else {
                $result['failed']++;
            }
        }

        return $result;
    }

    /**
     * Test database tables and structure.
     *
     * @since 1.1.0
     * @return array Test results
     */
    private static function test_database()
    {
        global $wpdb;

        $result = array(
            'category' => 'Database',
            'tests'    => array(),
            'passed'   => 0,
            'failed'   => 0,
        );

        $tables_to_check = array(
            'vs_jobs' => array(
                'required_columns' => array('id', 'job_id', 'topic_id', 'status', 'scheduled_at', 'created_at', 'error_message', 'quiz_data', 'settings', 'video_url', 'project_id'),
            ),
            'vs_projects' => array(
                'required_columns' => array('id', 'user_id', 'title', 'status', 'video_url'),
            ),
            'vs_project_questions' => array(
                'required_columns' => array('id', 'project_id', 'question_text', 'options', 'correct_index'),
            ),
            'vs_mcq_bank' => array(
                'required_columns' => array('id', 'question_text', 'options', 'correct_index', 'topic_id', 'status'),
            ),
            'vs_topics' => array(
                'required_columns' => array('id', 'name', 'slug', 'type'),
            ),
        );

        foreach ($tables_to_check as $table_name => $config) {
            $full_table_name = $wpdb->prefix . $table_name;

            $table_exists = ($wpdb->get_var("SHOW TABLES LIKE '$full_table_name'") === $full_table_name);
            $result['tests'][] = array(
                'name'    => 'Table Exists: ' . $table_name,
                'passed'  => $table_exists,
                'message' => $table_exists ? 'Table exists' : 'Table not found',
            );
            if ($table_exists) {
                $result['passed']++;
            } else {
                $result['failed']++;
            }

            if ($table_exists) {
                $required_columns = $config['required_columns'];
                $existing_columns = $wpdb->get_col("DESCRIBE $full_table_name");

                $missing_columns = array_diff($required_columns, $existing_columns);
                $columns_valid = empty($missing_columns);

                $result['tests'][] = array(
                    'name'    => 'Required Columns: ' . $table_name,
                    'passed'  => $columns_valid,
                    'message' => $columns_valid ? 'All columns present' : 'Missing: ' . implode(', ', $missing_columns),
                );
                if ($columns_valid) {
                    $result['passed']++;
                } else {
                    $result['failed']++;
                }
            }
        }

        return $result;
    }

    /**
     * Test WordPress hooks registration.
     *
     * @since 1.1.0
     * @return array Test results
     */
    private static function test_hooks()
    {
        $result = array(
            'category' => 'WordPress Hooks',
            'tests'    => array(),
            'passed'   => 0,
            'failed'   => 0,
        );

        $core = VS_Core::init();
        $settings = VS_Settings::init();

        $critical_hooks = array(
            // Admin hooks
            array('type' => 'action', 'name' => 'admin_menu', 'callback' => array($core, 'add_menu_page')),
            array('type' => 'action', 'name' => 'admin_enqueue_scripts', 'callback' => array($core, 'enqueue_assets')),
            array('type' => 'action', 'name' => 'admin_menu', 'callback' => array($settings, 'add_settings_page')),
            array('type' => 'action', 'name' => 'admin_init', 'callback' => array($settings, 'register_settings')),
        );

        foreach ($critical_hooks as $hook) {
            $hook_name = $hook['name'];
            $callback = $hook['callback'];
            $priority = has_action($hook_name, $callback);

            $passed = ($priority !== false);
            $result['tests'][] = array(
                'name'    => ucfirst($hook['type']) . ': ' . $hook_name,
                'passed'  => $passed,
                'message' => $passed ? 'Registered (priority: ' . $priority . ')' : 'Not registered',
            );

            if ($passed) {
                $result['passed']++;
            } else {
                $result['failed']++;
            }
        }

        return $result;
    }

    /**
     * Test external service connectivity.
     *
     * @since 1.1.0
     * @return array Test results
     */
    private static function test_services()
    {
        $result = array(
            'category' => 'External Services',
            'tests'    => array(),
            'passed'   => 0,
            'failed'   => 0,
            'skipped'  => 0,
        );

        // Buffer Test
        $buffer_token = get_option('mcqvs_buffer_access_token', '');
        if (empty($buffer_token)) {
            $result['tests'][] = array(
                'name'    => 'Buffer API',
                'passed'  => null,
                'message' => 'Skipped - No token configured',
                'skipped' => true,
            );
            $result['skipped']++;
        } else {
            try {
                $client = new VS_Buffer_Client($buffer_token);
                $profiles = $client->get_profiles();
                $passed = !is_wp_error($profiles) && !isset($profiles['error']);

                $result['tests'][] = array(
                    'name'    => 'Buffer API',
                    'passed'  => $passed,
                    'message' => $passed ? 'Connected' : 'Failed to connect',
                );
                if ($passed) {
                    $result['passed']++;
                } else {
                    $result['failed']++;
                }
            } catch (Exception $e) {
                $result['tests'][] = array(
                    'name'    => 'Buffer API',
                    'passed'  => false,
                    'message' => 'Error: ' . $e->getMessage(),
                );
                $result['failed']++;
            }
        }

        // R2 Test
        $r2_endpoint = get_option('mcqvs_r2_endpoint', '');
        if (empty($r2_endpoint)) {
            $result['tests'][] = array(
                'name'    => 'Cloudflare R2',
                'passed'  => null,
                'message' => 'Skipped - No endpoint configured',
                'skipped' => true,
            );
            $result['skipped']++;
        } else {
            $response = wp_remote_head($r2_endpoint, array('timeout' => 10));
            $passed = !is_wp_error($response);

            $result['tests'][] = array(
                'name'    => 'Cloudflare R2',
                'passed'  => $passed,
                'message' => $passed ? 'Endpoint reachable' : 'Endpoint unreachable',
            );
            if ($passed) {
                $result['passed']++;
            } else {
                $result['failed']++;
            }
        }

        return $result;
    }

    /**
     * Discover all PHP files in plugin directory.
     *
     * @since 1.1.0
     * @return array List of PHP file paths
     */
    private static function discover_php_files()
    {
        $files = array();
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator(MCQVS_PLUGIN_DIR, RecursiveDirectoryIterator::SKIP_DOTS)
        );

        foreach ($iterator as $file) {
            if ($file->isFile() && $file->getExtension() === 'php') {
                // Skip vendor and node_modules
                $path = $file->getPathname();
                if (strpos($path, 'vendor') === false && strpos($path, 'node_modules') === false) {
                    $files[] = $path;
                }
            }
        }

        return $files;
    }

    /**
     * Discover all JavaScript files in plugin directory.
     *
     * @since 1.1.0
     * @return array List of JS file paths
     */
    private static function discover_js_files()
    {
        $files = array();
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator(MCQVS_PLUGIN_DIR . 'assets/js', RecursiveDirectoryIterator::SKIP_DOTS)
        );

        foreach ($iterator as $file) {
            if ($file->isFile() && $file->getExtension() === 'js') {
                $filename = $file->getFilename();
                // Skip FFmpeg core files (they're minified and large)
                if (strpos($filename, 'ffmpeg-core') === false && strpos($filename, '814.ffmpeg') === false) {
                    $files[] = $file->getPathname();
                }
            }
        }

        return $files;
    }

    /**
     * Validate PHP file syntax.
     *
     * @since 1.1.0
     * @param string $file File path
     * @return array Test result
     */
    private static function validate_php_file($file)
    {
        $relative_path = str_replace(MCQVS_PLUGIN_DIR, '', $file);

        // Use token_get_all for syntax checking
        $contents = file_get_contents($file);
        if ($contents === false) {
            return array(
                'name'    => $relative_path,
                'passed'  => false,
                'message' => 'Could not read file',
            );
        }

        // Suppress errors and use error handler
        $old_error_handler = set_error_handler(function () {});
        $tokens = @token_get_all($contents);
        restore_error_handler();

        if ($tokens === false || empty($tokens)) {
            return array(
                'name'    => $relative_path,
                'passed'  => false,
                'message' => 'Syntax error detected',
            );
        }

        return array(
            'name'    => $relative_path,
            'passed'  => true,
            'message' => 'Valid syntax',
        );
    }

    /**
     * Validate JavaScript file syntax (basic).
     *
     * @since 1.1.0
     * @param string $file File path
     * @return array Test result
     */
    /**
     * Validate JavaScript file syntax (balance check).
     * Strips comments/strings/template raw text so brackets in comments don't false-fail.
     *
     * @since 1.1.0
     * @param string $file File path
     * @return array Test result
     */
    private static function validate_js_file($file)
    {
        $relative_path = str_replace(MCQVS_PLUGIN_DIR, '', $file);

        $contents = file_get_contents($file);
        if ($contents === false) {
            return array(
                'name'    => $relative_path,
                'passed'  => false,
                'message' => 'Could not read file',
            );
        }

        $scan = self::strip_js_for_balance_check($contents);

        $errors = array();

        $open_braces  = substr_count($scan, '{');
        $close_braces = substr_count($scan, '}');
        if ($open_braces !== $close_braces) {
            $errors[] = 'Unmatched braces';
        }

        $open_parens  = substr_count($scan, '(');
        $close_parens = substr_count($scan, ')');
        if ($open_parens !== $close_parens) {
            $errors[] = 'Unmatched parentheses';
        }

        $open_brackets  = substr_count($scan, '[');
        $close_brackets = substr_count($scan, ']');
        if ($open_brackets !== $close_brackets) {
            $errors[] = 'Unmatched brackets';
        }

        if (!empty($errors)) {
            return array(
                'name'    => $relative_path,
                'passed'  => false,
                'message' => implode(', ', $errors),
            );
        }

        return array(
            'name'    => $relative_path,
            'passed'  => true,
            'message' => 'Balance check OK',
        );
    }

    /**
     * Strip JS comments/strings/template raw text before balance counting.
     * Keeps real code tokens, including inside ${ ... } template expressions.
     *
     * Supports nested template literals inside template expressions by using a stack.
     *
     * @param string $src
     * @return string
     */
    private static function strip_js_for_balance_check($src)
    {
        $len = strlen($src);
        $out = '';
        $i   = 0;

        // code | lc (line comment) | bc (block comment) | sq | dq | tpl | re
        $mode = 'code';

        // Stack of template-expression brace depths. Each marker pushes depth=1.
        $tpl_expr_stack = array();

        // Regex character class flag: /[ ... ]/
        $re_in_class = false;

        while ($i < $len) {
            $ch   = $src[$i];
            $next = ($i + 1 < $len) ? $src[$i + 1] : '';

            if ($mode === 'code') {
                // Comments
                if ($ch === '/' && $next === '/') {
                    $mode = 'lc';
                    $out .= '  ';
                    $i += 2;
                    continue;
                }
                if ($ch === '/' && $next === '*') {
                    $mode = 'bc';
                    $out .= '  ';
                    $i += 2;
                    continue;
                }

                // Strings
                if ($ch === "'") {
                    $mode = 'sq';
                    $out .= ' ';
                    $i++;
                    continue;
                }
                if ($ch === '"') {
                    $mode = 'dq';
                    $out .= ' ';
                    $i++;
                    continue;
                }

                // Template literal
                if ($ch === '`') {
                    $mode = 'tpl';
                    $out .= ' ';
                    $i++;
                    continue;
                }

                // Regex literal (heuristic, avoids most division cases)
                if ($ch === '/' && self::is_regex_literal_start($src, $i)) {
                    $mode = 're';
                    $re_in_class = false;
                    $out .= ' ';
                    $i++;
                    continue;
                }

                // If we're inside one or more template expressions, track brace depth on the top frame.
                if (!empty($tpl_expr_stack)) {
                    $top = count($tpl_expr_stack) - 1;

                    if ($ch === '{') {
                        $tpl_expr_stack[$top]++;
                    } elseif ($ch === '}') {
                        $tpl_expr_stack[$top]--;
                        if ($tpl_expr_stack[$top] === 0) {
                            array_pop($tpl_expr_stack);
                            $out .= $ch;
                            $i++;
                            $mode = 'tpl';
                            continue;
                        }
                    }
                }

                $out .= $ch;
                $i++;
                continue;
            }

            if ($mode === 'lc') {
                if ($ch === "\n") {
                    $mode = 'code';
                    $out .= "\n";
                    $i++;
                    continue;
                }
                $out .= ' ';
                $i++;
                continue;
            }

            if ($mode === 'bc') {
                if ($ch === '*' && $next === '/') {
                    $mode = 'code';
                    $out .= '  ';
                    $i += 2;
                    continue;
                }
                $out .= ($ch === "\n") ? "\n" : ' ';
                $i++;
                continue;
            }

            if ($mode === 'sq') {
                if ($ch === '\\') {
                    $out .= '  ';
                    $i += 2;
                    continue;
                }
                if ($ch === "'") {
                    $mode = 'code';
                    $out .= ' ';
                    $i++;
                    continue;
                }
                $out .= ($ch === "\n") ? "\n" : ' ';
                $i++;
                continue;
            }

            if ($mode === 'dq') {
                if ($ch === '\\') {
                    $out .= '  ';
                    $i += 2;
                    continue;
                }
                if ($ch === '"') {
                    $mode = 'code';
                    $out .= ' ';
                    $i++;
                    continue;
                }
                $out .= ($ch === "\n") ? "\n" : ' ';
                $i++;
                continue;
            }

            if ($mode === 'tpl') {
                if ($ch === '\\') {
                    $out .= '  ';
                    $i += 2;
                    continue;
                }
                if ($ch === '`') {
                    $mode = 'code';
                    $out .= ' ';
                    $i++;
                    continue;
                }
                if ($ch === '$' && $next === '{') {
                    // Enter template expression: keep opening bracket for balance counting.
                    $out .= ' ';
                    $out .= '{';
                    $tpl_expr_stack[] = 1;
                    $mode = 'code';
                    $i += 2;
                    continue;
                }
                $out .= ($ch === "\n") ? "\n" : ' ';
                $i++;
                continue;
            }

            if ($mode === 're') {
                if ($ch === '\\') {
                    $out .= '  ';
                    $i += 2;
                    continue;
                }
                if ($ch === '[') {
                    $re_in_class = true;
                    $out .= ' ';
                    $i++;
                    continue;
                }
                if ($ch === ']' && $re_in_class) {
                    $re_in_class = false;
                    $out .= ' ';
                    $i++;
                    continue;
                }
                if ($ch === '/' && ! $re_in_class) {
                    // End regex literal; consume flags.
                    $mode = 'code';
                    $out .= ' ';
                    $i++;

                    while ($i < $len) {
                        $c = $src[$i];
                        if (ctype_alpha($c)) {
                            $out .= ' ';
                            $i++;
                            continue;
                        }
                        break;
                    }
                    continue;
                }

                // If regex is broken across newline, recover to code.
                if ($ch === "\n") {
                    $mode = 'code';
                    $out .= "\n";
                    $i++;
                    continue;
                }

                $out .= ' ';
                $i++;
                continue;
            }

            // Safety fallback
            $out .= $ch;
            $i++;
        }

        return $out;
    }


    /**
     * Heuristic detection of a regex literal start to avoid stripping division expressions.
     *
     * @param string $src
     * @param int    $pos Position of '/'
     * @return bool
     */
    private static function is_regex_literal_start($src, $pos)
    {
        $len = strlen($src);
        if ($pos + 1 >= $len) return false;

        $next = $src[$pos + 1];

        // Not a regex if it's a comment opener.
        if ($next === '/' || $next === '*') return false;

        // Strong division guard: `a / b` is common; regex rarely begins with whitespace.
        if ($next === ' ' || $next === "\t" || $next === "\r" || $next === "\n") return false;

        // Find previous non-whitespace character
        $j = $pos - 1;
        while ($j >= 0) {
            $c = $src[$j];
            if ($c === ' ' || $c === "\t" || $c === "\r" || $c === "\n") {
                $j--;
                continue;
            }
            break;
        }
        if ($j < 0) return true;

        $prev = $src[$j];

        // After these tokens, a regex literal is legal in JS.
        $can_start_after = array('(', '{', '[', '=', ':', ',', ';', '!', '?', '&', '|', '+', '-', '*', '~', '<', '>');
        if (in_array($prev, $can_start_after, true)) return true;

        // Look behind for keywords and control statements.
        $before = rtrim(substr($src, max(0, $pos - 240), 240));

        // Keywords like: return /re/, throw /re/, else /re/
        if (preg_match('/\b(return|throw|case|else|do)\s*$/', $before)) return true;

        // Binary operators/keywords where a new expression can begin (regex is an expression).
        if (preg_match('/\b(typeof|void|delete|in|instanceof)\s*$/', $before)) return true;

        // Control statements: if (x) /re/.test(...)
        if ($prev === ')' && preg_match('/\b(if|while|for|with|catch)\s*\([^;{}]*\)\s*$/', $before)) return true;

        return false;
    }

    /**
     * Test if a class exists and can be instantiated.
     *
     * @since 1.1.0
     * @param string $class_name Class name
     * @return array Test result
     */
    private static function test_class_exists($class_name)
    {
        $exists = class_exists($class_name);

        return array(
            'name'    => $class_name,
            'passed'  => $exists,
            'message' => $exists ? 'Class loaded' : 'Class not found',
        );
    }

    /**
     * Test if an AJAX hook is registered.
     *
     * @since 1.1.0
     * @param string $hook_name Hook name (with wp_ajax_ prefix)
     * @param mixed $expected_callback Expected callback
     * @return array Test result
     */
    private static function test_ajax_hook($hook_name, $expected_callback)
    {
        $priority = has_action($hook_name, $expected_callback);
        $passed = ($priority !== false);

        return array(
            'name'    => str_replace('wp_ajax_', '', $hook_name),
            'passed'  => $passed,
            'message' => $passed ? 'Registered' : 'Not registered',
        );
    }

    /**
     * Calculate test summary statistics.
     *
     * @since 1.1.0
     * @param array $results Test results
     * @return array Summary statistics
     */
    private static function calculate_summary($results)
    {
        $total_passed = 0;
        $total_failed = 0;
        $total_tests = 0;
        $categories_passed = 0;
        $categories_failed = 0;

        foreach ($results as $category => $data) {
            $total_passed += $data['passed'];
            $total_failed += $data['failed'];
            $total_tests += count($data['tests']);

            if ($data['failed'] === 0) {
                $categories_passed++;
            } else {
                $categories_failed++;
            }
        }

        $pass_rate = $total_tests > 0 ? round(($total_passed / $total_tests) * 100, 2) : 0;

        return array(
            'total_tests'        => $total_tests,
            'total_passed'       => $total_passed,
            'total_failed'       => $total_failed,
            'pass_rate'          => $pass_rate,
            'categories_passed'  => $categories_passed,
            'categories_failed'  => $categories_failed,
            'overall_status'     => ($total_failed === 0) ? 'pass' : 'fail',
        );
    }

    /**
     * Export test results.
     *
     * @since 1.1.0
     * @param string $format Export format (json|text)
     * @return string Formatted results
     */
    public static function export_results($format = 'json')
    {
        if ($format === 'json') {
            return wp_json_encode(self::$results, JSON_PRETTY_PRINT);
        }

        // Text format
        $output = "=== MCQ Video Studio Comprehensive Smoke Test ===\n\n";
        $output .= "Date: " . current_time('Y-m-d H:i:s') . "\n";
        $output .= "Version: " . (defined('MCQVS_VERSION') ? MCQVS_VERSION : 'Unknown') . "\n\n";

        foreach (self::$results as $category => $data) {
            $output .= "[" . $data['category'] . "]\n";
            $output .= "Passed: " . $data['passed'] . " | Failed: " . $data['failed'] . "\n\n";

            foreach ($data['tests'] as $test) {
                $status = $test['passed'] ? '[PASS]' : '[FAIL]';
                $output .= "  $status " . $test['name'] . " - " . $test['message'] . "\n";
            }
            $output .= "\n";
        }

        return $output;
    }
}
