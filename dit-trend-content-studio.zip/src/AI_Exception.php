<?php

/**
 * AI Exception
 *
 * @package DIT_TrendStudio
 * @MODIFIED 2025-12-13 - Extracted from class-error-handler.php for autoloader compatibility
 */

namespace DIT\TrendStudio;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Custom exception for AI-related errors
 */
class AI_Exception extends \Exception
{
    /**
     * Optional structured context for debugging/logging.
     *
     * @var array<string, mixed>
     */
    protected array $context = [];

    /**
     * @param string $message
     * @param int|array<string,mixed> $code_or_context
     * @param \Throwable|null $previous
     * @param array<string,mixed> $context
     */
    public function __construct($message = '', $code_or_context = 0, $previous = null, array $context = [])
    {
        // Backwards-compatible: allow passing a context array as 2nd arg.
        if (is_array($code_or_context)) {
            $this->context = $code_or_context;
            $code_or_context = 0;
        } else {
            $this->context = $context;
        }

        parent::__construct((string) $message, (int) $code_or_context, $previous instanceof \Throwable ? $previous : null);
    }

    /**
     * Return structured context attached to this exception.
     *
     * @return array<string, mixed>
     */
    public function get_context(): array
    {
        return $this->context;
    }
}
