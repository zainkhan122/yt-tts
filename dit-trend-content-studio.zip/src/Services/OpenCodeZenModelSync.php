<?php
/**
 * OpenCode Zen Free Model Auto-Sync
 *
 * Pulls the Zen model catalog from OpenCode and replaces the matching custom
 * provider's model list with the hard-coded free-model whitelist. Unlike the
 * OpenRouter sync, this performs a full replace (not an incremental diff).
 *
 * @package    DIT_TrendStudio
 * @subpackage Services
 * @since      2.29.0
 */

namespace DIT\TrendStudio\Services;

use DIT\TrendStudio\Infrastructure\AI_Provider_Factory;
use DIT\TrendStudio\Infrastructure\Logger;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class OpenCodeZenModelSync
 *
 * Static facade. State lives in `dit_ts_custom_providers` (sequential array of
 * provider profiles) and `dit_ts_opencode_last_sync` (unix timestamp).
 */
class OpenCodeZenModelSync
{
    /** OpenCode Zen public catalog endpoint. */
    const API_URL = 'https://opencode.ai/zen/v1/models';

    /** wp_options key holding the last successful sync timestamp. */
    const OPTION_LAST_SYNC = 'dit_ts_opencode_last_sync';

    /** wp_options key holding the sequential custom-provider list. */
    const OPTION_PROVIDERS = 'dit_ts_custom_providers';

    /** Action Scheduler hook fired by the recurring 3-day cron. */
    const ACTION_HOOK = 'dit_ts_sync_opencode_models';

    /** Action Scheduler group for the recurring sync. */
    const AS_GROUP = 'dit_ts_opencode_sync';

    /** Log message tag used in Logger::info() / warning() calls. */
    const LOG_TAG = 'OpenCode Zen model sync';

    /**
     * Hard-coded whitelist of known free Zen model IDs.
     *
     * @var string[]
     */
    private static $FREE_MODEL_IDS = array(
        'big-pickle',
        'deepseek-v4-flash-free',
        'mimo-v2.5-free',
        'north-mini-code-free',
        'nemotron-3-ultra-free',
        'hy3-free',
    );

    /**
     * Run the sync.
     *
     * Algorithm (mirrors openrouter-model-sync-universal-plan.md §2g):
     *  1. Locate the OpenCode Zen custom provider (is_zen_url() is true).
     *  2. Fetch the Zen model catalog from the API.
     *  3. Abort without modifying state on API failure or empty result.
     *  4. REPLACE the provider's model list with the whitelisted free models.
     *  5. Validate every profile before persisting.
     *  6. Save raw sequential array to preserve provider order.
     *  7. Update last-sync timestamp and log the operation.
     *
     * @return array {
     *     @type bool   $success
     *     @type string $message
     *     @type int    $total
     *     @type array  $model_ids
     * }
     */
    public static function sync(): array
    {
        $logger = new Logger();

        // 1. Pull the raw sequential list.
        $providers = self::get_raw_providers();
        if (!is_array($providers) || empty($providers)) {
            $logger->warning(self::LOG_TAG . ': no custom providers configured.');
            return array(
                'success'   => false,
                'message'   => __('No custom providers configured.', 'dit-trend-content-studio'),
                'total'     => 0,
                'model_ids' => array(),
            );
        }

        $zen_index = null;
        $zen_profile = null;
        foreach ($providers as $i => $profile) {
            $url = (string) ($profile['api_url'] ?? '');
            if (self::is_zen_url($url)) {
                $zen_index = $i;
                $zen_profile = $profile;
                break;
            }
        }

        if ($zen_index === null) {
            $logger->info(self::LOG_TAG . ': no OpenCode Zen custom provider found, skipping.');
            return array(
                'success'   => false,
                'message'   => __('No OpenCode Zen custom provider found (URL must contain opencode.ai).', 'dit-trend-content-studio'),
                'total'     => 0,
                'model_ids' => array(),
            );
        }

        // 3. Fetch + filter. Never mutate state when the API misbehaves.
        $api_models = self::fetch_free_models();
        if ($api_models === null) {
            return array(
                'success'   => false,
                'message'   => __('OpenCode Zen API request failed. Existing models left unchanged.', 'dit-trend-content-studio'),
                'total'     => 0,
                'model_ids' => array(),
            );
        }
        if (empty($api_models)) {
            return array(
                'success'   => false,
                'message'   => __('OpenCode Zen returned no free models. Existing models left unchanged.', 'dit-trend-content-studio'),
                'total'     => 0,
                'model_ids' => array(),
            );
        }

        // 4. Full replace — build the new model list from the whitelisted API result.
        $new_models = array();
        $model_ids = array();
        foreach ($api_models as $m) {
            $mid = (string) ($m['model_id'] ?? '');
            if ($mid === '') {
                continue;
            }
            $model_ids[] = $mid;
            $new_models[] = array(
                'display_name' => (string) ($m['display_name'] ?? $mid),
                'model_id'     => $mid,
            );
        }

        // 5. Refuse to leave the provider empty.
        if (empty($new_models)) {
            $logger->warning(self::LOG_TAG . ': sync would empty the provider, aborting.', array(
                'provider_id' => (string) ($zen_profile['id'] ?? ''),
            ));
            return array(
                'success'   => false,
                'message'   => __('Sync would remove every model — aborted to protect the provider.', 'dit-trend-content-studio'),
                'total'     => 0,
                'model_ids' => array(),
            );
        }

        // 6. Save. Operate on the raw sequential array to preserve provider order.
        $zen_profile['models'] = $new_models;
        $providers[$zen_index]  = $zen_profile;

        // Validate every profile shape before persisting.
        $clean = array();
        foreach ($providers as $profile) {
            $pid = isset($profile['id']) ? sanitize_key((string) $profile['id']) : '';
            if ($pid === '') {
                continue;
            }
            $models_clean = array();
            if (isset($profile['models']) && is_array($profile['models'])) {
                foreach ($profile['models'] as $m) {
                    $mid = (string) ($m['model_id'] ?? '');
                    $mname = (string) ($m['display_name'] ?? $mid);
                    if ($mid !== '') {
                        $models_clean[] = array(
                            'display_name' => sanitize_text_field($mname),
                            'model_id'     => sanitize_text_field($mid),
                        );
                    }
                }
            }
            $profile['models'] = $models_clean;
            $clean[] = $profile;
        }

        update_option(self::OPTION_PROVIDERS, $clean);
        AI_Provider_Factory::clear_custom_providers_cache();
        update_option(self::OPTION_LAST_SYNC, time(), false);

        $summary = array(
            'success'   => true,
            'message'   => sprintf(
                /* translators: %d: number of synced models */
                __('Synced %d OpenCode Zen free model(s).', 'dit-trend-content-studio'),
                count($model_ids)
            ),
            'total'     => count($model_ids),
            'model_ids' => $model_ids,
        );

        $logger->info(self::LOG_TAG . ': complete.', array(
            'provider_id' => (string) ($zen_profile['id'] ?? ''),
            'total'       => $summary['total'],
            'model_ids'   => $summary['model_ids'],
        ));

        return $summary;
    }

    /**
     * Fetch the OpenCode Zen catalog and return only whitelisted free models.
     *
     * Returns null on ANY error so that `sync()` can abort without mutating state.
     *
     * @return array|null Filtered array of model rows (model_id, display_name),
     *                    or null if the request failed or the response could not be parsed.
     */
    private static function fetch_free_models(): ?array
    {
        $response = wp_remote_get(self::API_URL, array(
            'timeout'     => 30,
            'headers'     => array('Accept' => 'application/json'),
            'user-agent'  => 'DIT-TrendStudio/' . DIT_TS_VERSION . ' (WordPress ' . get_bloginfo('version') . ')',
        ));

        if (is_wp_error($response)) {
            (new Logger())->warning(self::LOG_TAG . ': wp_remote_get failed.', array(
                'error' => $response->get_error_message(),
            ));
            return null;
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            (new Logger())->warning(self::LOG_TAG . ': non-200 response.', array(
                'http_code' => $code,
            ));
            return null;
        }

        $body = wp_remote_retrieve_body($response);
        $json = json_decode($body, true);
        if (!is_array($json) || !isset($json['data']) || !is_array($json['data']) || empty($json['data'])) {
            (new Logger())->warning(self::LOG_TAG . ': malformed response, no data array.');
            return null;
        }

        $filtered = array();
        foreach ($json['data'] as $row) {
            if (!is_array($row) || empty($row['id'])) {
                continue;
            }

            $mid = (string) $row['id'];
            if (!in_array($mid, self::$FREE_MODEL_IDS, true)) {
                continue;
            }

            $filtered[] = array(
                'model_id'     => $mid,
                'display_name' => self::model_id_to_display($mid),
            );
        }

        return empty($filtered) ? null : $filtered;
    }

    /**
     * Derive a human-readable display name from a Zen model ID.
     *
     * @param string $id Model ID (e.g. 'deepseek-v4-flash-free').
     * @return string Display name (e.g. 'Deepseek V4 Flash (Free)').
     */
    private static function model_id_to_display(string $id): string
    {
        $base = $id;
        $suffix = '';
        if (substr($base, -5) === '-free') {
            $base = substr($base, 0, -5);
            $suffix = ' (Free)';
        }
        $display = str_replace('-', ' ', $base);
        $display = ucwords($display);
        return $display . $suffix;
    }

    /**
     * Read the raw sequential providers array directly from the option.
     *
     * @return array
     */
    private static function get_raw_providers(): array
    {
        $raw = get_option(self::OPTION_PROVIDERS, array());
        if (is_string($raw)) {
            $decoded = json_decode($raw, true);
            $raw = is_array($decoded) ? $decoded : array();
        }
        return is_array($raw) ? $raw : array();
    }

    /**
     * Unix timestamp of the last successful sync (0 when never run).
     *
     * @return int
     */
    public static function get_last_sync_time(): int
    {
        return (int) get_option(self::OPTION_LAST_SYNC, 0);
    }

    /**
     * Whether at least one configured custom provider points at OpenCode Zen.
     *
     * @return bool
     */
    public static function has_zen_provider(): bool
    {
        foreach (self::get_raw_providers() as $profile) {
            $url = (string) ($profile['api_url'] ?? '');
            if (self::is_zen_url($url)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Determine whether a URL belongs to the OpenCode Zen API.
     *
     * @param string $url
     * @return bool
     */
    public static function is_zen_url(string $url): bool
    {
        $url = trim($url);
        if ($url === '') {
            return false;
        }
        if (stripos($url, 'opencode.ai') !== false) {
            return true;
        }
        $host = wp_parse_url($url, PHP_URL_HOST);
        if (is_string($host) && ($host === 'opencode.ai'
            || substr($host, -strlen('.opencode.ai')) === '.opencode.ai')) {
            return true;
        }
        return false;
    }
}
