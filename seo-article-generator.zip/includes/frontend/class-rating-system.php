<?php

/**
 * Rating System
 *
 * Handles user ratings for software posts with anti-spam protection.
 *
 * @package SEO_Article_Generator
 * @since 2.7.3
 */

namespace SEO_Article_Generator\Frontend;

// Prevent direct access.
if (! defined('ABSPATH')) {
    exit;
}

/**
 * Rating System class.
 *
 * @since 2.7.3
 */
class Rating_System
{

    /**
     * Meta key for rating sum.
     */
    const META_RATING_SUM = '_seo_gen_rating_sum';

    /**
     * Meta key for rating count.
     */
    const META_RATING_COUNT = '_seo_gen_rating_count';

    /**
     * Meta key for vote ledger (prevents duplicate votes).
     */
    const META_VOTE_LEDGER = '_seo_gen_vote_ledger';

    /**
     * Rate limit transient prefix.
     */
    const RATE_LIMIT_PREFIX = 'seo_gen_rate_';

    /**
     * Rate limit duration in seconds (24 hours).
     */
    const RATE_LIMIT_DURATION = 86400;

    /**
     * Get rating data for a post.
     *
     * @since 2.7.3
     * @param int $post_id Post ID.
     * @return array {
     *     @type float $sum     Total sum of ratings.
     *     @type int   $count   Number of ratings.
     *     @type float $average Average rating (0 if no ratings).
     * }
     */
    public static function get_rating_data(int $post_id): array
    {
        $sum   = \get_post_meta($post_id, self::META_RATING_SUM, true);
        $count = \get_post_meta($post_id, self::META_RATING_COUNT, true);

        if ($sum === '' || $sum === false || $count === '' || $count === false) {
            return array(
                'sum'     => 0,
                'count'   => 0,
                'average' => 0,
            );
        }

        $sum   = (float) $sum;
        $count = (int) $count;

        return array(
            'sum'     => $sum,
            'count'   => $count,
            'average' => $count > 0 ? round($sum / $count, 1) : 0,
        );
    }

    /**
     * Ensure ratings are seeded for a post if they don't exist.
     *
     * @since 2.30.0
     * @param int $post_id Post ID.
     * @return void
     */
    public static function maybe_seed_ratings(int $post_id): void
    {
        $sum = \get_post_meta($post_id, self::META_RATING_SUM, true);
        if ($sum !== '' && $sum !== false) {
            return;
        }

	// Use canonical get_hero_data() instead of raw get_post_meta() to benefit
	// from the per-request static cache and correct key fallback logic.
	$hero_data = \SEO_Article_Generator\Plugin::get_instance()->get_hero_data($post_id);
        if (is_array($hero_data) && !empty($hero_data['rating'])) {
            $rating = (float) $hero_data['rating'];
            // Seed with a reasonable count (e.g., 50-200) to give it "weight"
            $seed_count = mt_rand(50, 200);
            \update_post_meta($post_id, self::META_RATING_SUM, $rating * $seed_count);
            \update_post_meta($post_id, self::META_RATING_COUNT, $seed_count);
            return;
        }

        self::seed_ratings($post_id);
    }

    /**
     * Seed rating meta with a persistent random number (Sticky Seeding).
     *
     * @since 2.24.1
     * @param int $post_id Post ID.
     * @return array Seeded rating data.
     */
    public static function seed_ratings(int $post_id): array
    {
        // Generate random rating between 3.0 and 4.8
        // We use mt_rand for better randomness
        $rating_val = 3.0 + (mt_rand() / mt_getrandmax()) * (4.8 - 3.0);
        $count = mt_rand(50, 500);
        $sum = $rating_val * $count;

        \update_post_meta($post_id, self::META_RATING_SUM, $sum);
        \update_post_meta($post_id, self::META_RATING_COUNT, $count);

        return array(
            'sum'     => $sum,
            'count'   => $count,
            'average' => round($rating_val, 1),
        );
    }

    /**
     * Add a rating to a post.
     *
     * @since 2.7.3
     * @param int $post_id Post ID.
     * @param int $rating  Rating value (1-5).
     * @return bool|WP_Error True on success, WP_Error on failure.
     */
    public static function add_rating(int $post_id, int $rating)
    {
        // Validate rating range.
        if ($rating < 1 || $rating > 5) {
            return new \WP_Error('invalid_rating', 'Rating must be between 1 and 5.');
        }

        // Check rate limit.
        if (self::is_rate_limited($post_id)) {
            return new \WP_Error('rate_limited', 'You can only rate once per 24 hours.');
        }

        // Check vote ledger.
        if (self::has_voted($post_id)) {
            return new \WP_Error('already_voted', 'You have already rated this software.');
        }

        // Get current values.
        $sum   = (float) \get_post_meta($post_id, self::META_RATING_SUM, true);
        $count = (int) \get_post_meta($post_id, self::META_RATING_COUNT, true);

        // Update values.
        \update_post_meta($post_id, self::META_RATING_SUM, $sum + $rating);
        \update_post_meta($post_id, self::META_RATING_COUNT, $count + 1);

        // Add to vote ledger.
        self::add_to_ledger($post_id);

        // Set rate limit.
        self::set_rate_limit($post_id);

        // [ISSUE-3 FIX] Fire hook to refresh Rank Math schema with live rating data.
        // Schema must match visible Hero rating per Google Structured Data Guidelines.
        $new_data = self::get_rating_data($post_id);
        \do_action('seo_gen_rating_updated', $post_id, $new_data['average'], $new_data['count']);

        return true;
    }

    /**
     * Check if current user/IP has already voted on this post.
     *
     * @since 2.7.3
     * @param int $post_id Post ID.
     * @return bool True if already voted.
     */
    public static function has_voted(int $post_id): bool
    {
        $ledger = get_post_meta($post_id, self::META_VOTE_LEDGER, true);

        if (! is_array($ledger)) {
            return false;
        }

        $hash = self::generate_vote_hash();
        return in_array($hash, $ledger, true);
    }

    /**
     * Check if current user/IP is rate limited.
     *
     * @since 2.7.3
     * @param int $post_id Post ID.
     * @return bool True if rate limited.
     */
    public static function is_rate_limited(int $post_id): bool
    {
        $transient_key = self::RATE_LIMIT_PREFIX . $post_id . '_' . self::get_ip_hash();
        return (bool) \get_transient($transient_key);
    }

    /**
     * Set rate limit for current user/IP.
     *
     * @since 2.7.3
     * @param int $post_id Post ID.
     * @return void
     */
    private static function set_rate_limit(int $post_id): void
    {
        $transient_key = self::RATE_LIMIT_PREFIX . $post_id . '_' . self::get_ip_hash();
        \set_transient($transient_key, 1, self::RATE_LIMIT_DURATION);
    }

    /**
     * Add current user/IP hash to vote ledger.
     *
     * @since 2.7.3
     * @param int $post_id Post ID.
     * @return void
     */
    private static function add_to_ledger(int $post_id): void
    {
        $ledger = get_post_meta($post_id, self::META_VOTE_LEDGER, true);

        if (! is_array($ledger)) {
            $ledger = array();
        }

        $hash = self::generate_vote_hash();
        if (! in_array($hash, $ledger, true)) {
            $ledger[] = $hash;
            \update_post_meta($post_id, self::META_VOTE_LEDGER, $ledger);
        }
    }

    /**
     * Generate unique vote hash for current visitor.
     *
     * @since 2.7.3
     * @return string SHA256 hash of IP + User Agent.
     */
    public static function generate_vote_hash(): string
    {
        $ip = self::get_client_ip();
        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? \sanitize_text_field(\wp_unslash($_SERVER['HTTP_USER_AGENT'])) : '';

        return hash('sha256', $ip . $ua);
    }

    /**
     * Get hashed IP for rate limiting key.
     *
     * @since 2.7.3
     * @return string MD5 hash of IP (shorter for transient keys).
     */
    private static function get_ip_hash(): string
    {
        return md5(self::get_client_ip());
    }

    /**
     * Get client IP address.
     *
     * @since 2.7.3
     * @return string Client IP.
     */
    private static function get_client_ip(): string
    {
        $ip = '';

        if (! empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = \sanitize_text_field(\wp_unslash($_SERVER['HTTP_CLIENT_IP']));
        } elseif (! empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            // Can contain multiple IPs separated by comma.
            $ips = explode(',', \sanitize_text_field(\wp_unslash($_SERVER['HTTP_X_FORWARDED_FOR'])));
            $ip  = trim($ips[0]);
        } elseif (! empty($_SERVER['REMOTE_ADDR'])) {
            $ip = \sanitize_text_field(\wp_unslash($_SERVER['REMOTE_ADDR']));
        }

        return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : '0.0.0.0';
    }

    /**
     * Render rating UI HTML for hero section.
     *
     * @since 2.7.3
     * @param int $post_id Post ID.
     * @return string HTML output.
     */
    public static function render_rating_ui(int $post_id): string
    {
        $data      = self::get_rating_data($post_id);
        $avg       = $data['average'];
        $count     = $data['count'];
        $has_voted = self::has_voted($post_id);

        ob_start();
?>
        <div class="seo-gen-rating-widget" data-post-id="<?php echo esc_attr($post_id); ?>" data-rated="<?php echo $has_voted ? 'true' : 'false'; ?>">
            <div class="seo-gen-rating-stars-wrapper">
                <div class="seo-gen-rating-stars-container <?php echo $has_voted ? 'is-rated' : 'is-interactive'; ?>">
                    <?php for ($i = 1; $i <= 5; $i++) : ?>
                        <?php if ($has_voted) : ?>
                            <span class="seo-gen-star-static">
                                <?php echo self::render_single_star($avg, $i); ?>
                            </span>
                        <?php else : ?>
                            <button type="button" class="seo-gen-star-btn" data-rating="<?php echo $i; ?>" aria-label="<?php printf(esc_attr__('Rate %d out of 5 stars', 'seo-article-generator'), $i); ?>">
                                <?php echo self::render_single_star($avg, $i); ?>
                            </button>
                        <?php endif; ?>
                    <?php endfor; ?>
                </div>
                <div class="seo-gen-rating-meta">
                    <span class="seo-gen-rating-avg"><?php echo number_format($avg, 1); ?></span>
                    <span class="seo-gen-rating-count">(<?php echo number_format_i18n($count); ?>)</span>
                    <?php if (!$has_voted) : ?>
                        <span class="seo-gen-rating-label"><?php esc_html_e('Rate it:', 'seo-article-generator'); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="seo-gen-rating-feedback"></div>
        </div>
<?php
        return ob_get_clean();
    }

    /**
     * Render a single star based on rating and index.
     * 
     * @since 2.24.2
     */
    private static function render_single_star(float $avg, int $index): string
    {
        if ($avg >= $index) {
            return '<svg class="seo-gen-star seo-gen-star--full" viewBox="0 0 24 24" width="16" height="16"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" fill="currentColor"/></svg>';
        } elseif ($avg >= $index - 0.5) {
            $gradient_id = 'half-' . mt_rand(1000, 9999);
            return '<svg class="seo-gen-star seo-gen-star--half" viewBox="0 0 24 24" width="16" height="16"><defs><linearGradient id="' . $gradient_id . '"><stop offset="50%" stop-color="currentColor"/><stop offset="50%" stop-color="transparent"/></linearGradient></defs><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" fill="url(#' . $gradient_id . ')" stroke="currentColor" stroke-width="1"/></svg>';
        } else {
            return '<svg class="seo-gen-star seo-gen-star--empty" viewBox="0 0 24 24" width="16" height="16"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" fill="none" stroke="currentColor" stroke-width="1"/></svg>';
        }
    }

    /**
     * Render star icons for display.
     *
     * @since 2.7.3
     * @param float $rating Rating value (0-5).
     * @return string SVG stars HTML.
     */
    private static function render_stars(float $rating): string
    {
        $html = '';
        for ($i = 1; $i <= 5; $i++) {
            if ($rating >= $i) {
                // Full star.
                $html .= '<svg class="seo-gen-star seo-gen-star--full" viewBox="0 0 24 24" width="16" height="16"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" fill="currentColor"/></svg>';
            } elseif ($rating >= $i - 0.5) {
                // Half star.
                $html .= '<svg class="seo-gen-star seo-gen-star--half" viewBox="0 0 24 24" width="16" height="16"><defs><linearGradient id="half"><stop offset="50%" stop-color="currentColor"/><stop offset="50%" stop-color="transparent"/></linearGradient></defs><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" fill="url(#half)" stroke="currentColor" stroke-width="1"/></svg>';
            } else {
                // Empty star.
                $html .= '<svg class="seo-gen-star seo-gen-star--empty" viewBox="0 0 24 24" width="16" height="16"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" fill="none" stroke="currentColor" stroke-width="1"/></svg>';
            }
        }
        return $html;
    }
}
