<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) exit;

class FrameAnalyzer {

	/**
	 * Analyze video frames using Gemini to find the main content region.
	 *
	 * @param array  $frame_paths List of frame image file paths.
	 * @param string $provider_name AI provider name (e.g., 'gemini').
	 * @return array Region with x, y, w, h as percentages (0.0-1.0), or full-frame default.
	 */
	public static function analyze_frames( array $frame_paths, string $provider_name = '' ): array {
		if ( empty( $frame_paths ) ) {
			return self::fallback_region();
		}

		if ( empty( $provider_name ) ) {
			$provider_name = Config::PROVIDER_GEMINI;
		}

		$provider = null;
		try {
			$provider = AIProviderRegistry::get_provider_instance( $provider_name );
		} catch ( \Throwable $e ) {
			Logger::warning( 'frame_analyzer_provider_fail', null, [
				'provider' => $provider_name,
				'error' => $e->getMessage(),
			], '500' );
			return self::fallback_region();
		}

		if ( ! $provider instanceof \AiSocialCollage\Contracts\AIProviderInterface ) {
			return self::fallback_region();
		}

		$results = [];
		$frame_count = count( $frame_paths );

		foreach ( $frame_paths as $idx => $frame_path ) {
			if ( ! file_exists( $frame_path ) ) continue;

			$analysis = self::analyze_single_frame( $provider, $frame_path, $idx + 1, $frame_count );
			if ( $analysis !== null ) {
				$results[] = $analysis;
			}
		}

		if ( empty( $results ) ) {
			Logger::warning( 'frame_analyzer_no_results', null, [
				'frames_attempted' => $frame_count,
			], '200' );
			return self::fallback_region();
		}

		$merged = self::merge_results( $results );

		Logger::info( Config::LOG_ACTION_VIDEO_FRAME_ANALYSIS, null, [
			'frames_analyzed' => count( $results ),
			'merged_region' => $merged,
		], '200' );

		return $merged;
	}

	/**
	 * Analyze a single frame using the AI provider.
	 */
	private static function analyze_single_frame( $provider, string $frame_path, int $frame_num, int $total_frames ): ?array {
		$image_data = @file_get_contents( $frame_path );
		if ( $image_data === false ) return null;

		$b64 = base64_encode( $image_data );
		$mime = 'image/jpeg';

		$prompt = <<<'PROMPT'
Analyze this video frame from a Pakistani news channel or social media video.
Your task: identify the MAIN VIDEO CONTENT area (the actual footage being shown),
excluding any news tickers, headline text bands, logos, lower thirds, and overlay graphics.

Return ONLY valid JSON with this structure:
{
  "content_region": {"x": 0.10, "y": 0.15, "w": 0.80, "h": 0.55},
  "confidence": 0.92,
  "has_ticker": true,
  "has_headline_band": true,
  "has_logo": true,
  "logo_position": "bottom-right"
}

Coordinate rules:
- x, y = top-left corner of the main content (0.0 = left/top edge, 1.0 = right/bottom edge)
- w, h = width and height of the content region (0.0 to 1.0)
- All values must be between 0.0 and 1.0
- If the frame is already clean (no overlays), return x=0.0, y=0.0, w=1.0, h=1.0
- confidence = how sure you are (0.0 to 1.0)
PROMPT;

		$payload = [
			'contents' => [
				[
					'parts' => [
						[ 'text' => $prompt ],
						[
							'inline_data' => [
								'mime_type' => $mime,
								'data' => $b64,
							],
						],
					],
				],
			],
			'generationConfig' => [
				'temperature' => 0.1,
				'maxOutputTokens' => 500,
				'responseMimeType' => 'application/json',
			],
		];

		$api_key = get_option( Config::OPTION_GEMINI_KEY, '' );
		if ( empty( $api_key ) ) {
			Logger::warning( 'frame_analyzer_no_api_key', null, [], '401' );
			return null;
		}

		$model = get_option( Config::OPTION_GEMINI_MODEL, Config::DEFAULT_GEMINI_MODEL );
		$url = sprintf(
			'https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent?key=%s',
			$model,
			$api_key
		);

		$response = wp_remote_post( $url, [
			'headers' => [ 'Content-Type' => 'application/json' ],
			'body' => wp_json_encode( $payload ),
			'timeout' => 30,
		] );

		if ( is_wp_error( $response ) ) {
			Logger::warning( 'frame_analyzer_api_error', null, [
				'frame' => $frame_num,
				'error' => $response->get_error_message(),
			], '500' );
			return null;
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( empty( $data['candidates'][0]['content']['parts'][0]['text'] ) ) {
			Logger::warning( 'frame_analyzer_empty_response', null, [
				'frame' => $frame_num,
			], '200' );
			return null;
		}

		$text = trim( $data['candidates'][0]['content']['parts'][0]['text'] );
		$parsed = json_decode( $text, true );

		if ( ! is_array( $parsed ) || empty( $parsed['content_region'] ) ) {
			Logger::warning( 'frame_analyzer_parse_failed', null, [
				'frame' => $frame_num,
				'raw' => mb_substr( $text, 0, 200 ),
			], '200' );
			return null;
		}

		$region = $parsed['content_region'];
		$confidence = $parsed['confidence'] ?? 0.5;

		$region = self::validate_region( $region );

		return [
			'region' => $region,
			'confidence' => (float) $confidence,
		];
	}

	/**
	 * Validate and clamp region values.
	 */
	private static function validate_region( array $region ): array {
		$x = max( 0.0, min( 1.0, (float) ( $region['x'] ?? 0 ) ) );
		$y = max( 0.0, min( 1.0, (float) ( $region['y'] ?? 0 ) ) );
		$w = max( 0.1, min( 1.0 - $x, (float) ( $region['w'] ?? 1 ) ) );
		$h = max( 0.1, min( 1.0 - $y, (float) ( $region['h'] ?? 1 ) ) );
		return [ 'x' => $x, 'y' => $y, 'w' => $w, 'h' => $h ];
	}

	/**
	 * Merge multiple frame analysis results by averaging, weighted by confidence.
	 */
	private static function merge_results( array $results ): array {
		$total_weight = 0;
		$sum_x = 0;
		$sum_y = 0;
		$sum_w = 0;
		$sum_h = 0;

		foreach ( $results as $r ) {
			$weight = max( 0.1, $r['confidence'] );
			$sum_x += $r['region']['x'] * $weight;
			$sum_y += $r['region']['y'] * $weight;
			$sum_w += $r['region']['w'] * $weight;
			$sum_h += $r['region']['h'] * $weight;
			$total_weight += $weight;
		}

		if ( $total_weight === 0 ) {
			return self::fallback_region();
		}

		return self::validate_region( [
			'x' => $sum_x / $total_weight,
			'y' => $sum_y / $total_weight,
			'w' => $sum_w / $total_weight,
			'h' => $sum_h / $total_weight,
		] );
	}

	/**
	 * Fallback region: full frame (no cropping).
	 */
	private static function fallback_region(): array {
		return [ 'x' => 0.0, 'y' => 0.0, 'w' => 1.0, 'h' => 1.0 ];
	}
}
