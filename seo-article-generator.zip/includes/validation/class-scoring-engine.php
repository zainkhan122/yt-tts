<?php

/**
 * Scoring Engine
 *
 * @package SEO_Article_Generator
 * @MODIFIED 2025-12-12 v1.9.0: Refactored to consume Threshold_Config for all thresholds
 * @MODIFIED 2025-12-12 v1.9.3: Download-intent scoring realignment
 * @MODIFIED 2025-12-30 v2.7.7: Realigned distribution for manual review workflow
 */

namespace SEO_Article_Generator\Validation;

use SEO_Article_Generator\Traits\Type_Safety;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Calculate article quality scores
 */
class Scoring_Engine
{
    use Type_Safety;

    /**
     * Mode for threshold lookups (portal/lite)
     * @MODIFIED v1.9.1: Added for mode consistency
     * @var string|null
     */
    private $mode = null;

    /**
     * Placeholder URL sentinel value - used to detect fake/incomplete download links.
     * @MODIFIED 2025-12-13 v2.0.3: Centralized constant (consistency with Validator)
     */
    private const PLACEHOLDER_URL = 'PLACEHOLDER_URL';

    /**
     * Get the validation threshold based on content mode
     * @MODIFIED 2025-12-12 v1.9.0: Delegated to Threshold_Config
     *
     * @return int Threshold score (0-100)
     */
    public static function get_mode_threshold()
    {
        return Threshold_Config::get_mode_threshold();
    }

    /**
     * Get minimum content requirements based on mode
     * @MODIFIED 2025-12-12 v1.9.0: Delegated to Threshold_Config
     *
     * @return array Array with min_features, min_faqs, require_installation
     */
    public static function get_mode_requirements()
    {
        return Threshold_Config::get_mode_requirements();
    }

    /**
     * Calculate overall quality score (0-100)
     * @MODIFIED v1.7.0: New 100-point distribution for portal-grade hardening
     * @MODIFIED v1.9.1: Added mode parameter for consistent threshold usage
     * @MODIFIED v1.9.3: Rebalanced for download-intent priority
     *
     * Distribution:
     * - Download & Safety: 37 pts (Download 17, Safety 12, Sys reqs 8)
     * - Trust Tech Specs: 20 pts
     * - User Guidance: 13 pts (Install 10, Rating 3)
     * - Content Quality: 30 pts (Links 0, Density 6, Meta 8, Length 6, FAQs 5, Features 5)
     *
     * @param array       $article    Article data
     * @param array       $input_data Original input
     * @param string|null $mode       Mode override (optional, defaults to plugin setting)
     * @return int Score
     */
    public function calculate_score($article, $input_data, $mode = null)
    {
        // Store mode for use in scoring methods
        $this->mode = $mode;

        $score = 0;

        // =====================
        // DOWNLOAD & SAFETY (35 pts)
        // =====================
        $score += $this->score_download_section($article);
        $score += $this->score_safety_signals($article);
        $score += $this->score_system_requirements($article);

        // =====================
        // TRUST TECH SPECS (18 pts)
        // =====================
        $score += $this->score_tech_specs($article);

        // =====================
        // USER GUIDANCE (11 pts)
        // =====================
        $score += $this->score_installation_guide($article);
        $score += $this->score_editor_rating($article);

        // =====================
        // CONTENT QUALITY (36 pts)
        // =====================
        $score += $this->score_internal_links($article);
        $score += $this->score_keyword_density($article);
        $score += $this->score_meta_description($article);
        $score += $this->score_content_length($article);
        $score += $this->score_faqs($article);
        $score += $this->score_features($article);
        $score += $this->score_moat($article);

        return min(100, $score);
    }

    /**
     * Score internal links (Uses Threshold_Config for max points)
     * @MODIFIED 2025-12-12 v1.9.0: Uses Threshold_Config
     * @MODIFIED 2025-12-12 v1.9.3: Max reduced from 10 to 6
     * @since 2.6.0 Disabled - Link Whisper handles internal linking
     *
     * @param array $article Article data
     * @return int Score (always 0 - internal linking handled by Link Whisper)
     */
    private function score_internal_links($article)
    {
        // @since 2.6.0: Internal linking removed - using Link Whisper plugin
        // Previously scored 0-6 pts based on internal link count
        return 0;
    }

    /**
     * Score content length (Uses Threshold_Config for max points)
     * @MODIFIED 2025-12-12 v1.9.0: Uses Threshold_Config
     * @MODIFIED 2025-12-12 v1.9.2: Removed low tier (binary full/partial)
     *
     * @param array $article Article data
     * @return int Score
     */
    private function score_content_length($article)
    {
        if (empty($article['html_content'])) {
            return 0;
        }

        $text = wp_strip_all_tags($article['html_content']);
        $word_count = str_word_count($text);
        $cfg = Threshold_Config::get($this->mode)['content_length'];

        // Full tier: 600-1400 words (flattened from 800-1200)
        if ($word_count >= $cfg['full_min'] && $word_count <= $cfg['full_max']) {
            return $cfg['pts_full'];
        }
        // Partial tier: 500-1600 words
        if ($word_count >= $cfg['partial_min'] && $word_count <= $cfg['partial_max']) {
            return $cfg['pts_partial'];
        }
        // Outside all tiers = 0 points (too short or bloated)
        return 0;
    }

    /**
     * Score FAQs (Max 5)
     * @MODIFIED 2025-12-12 v1.9.0: Uses Threshold_Config
     *
     * @param array $article Article data
     * @return int Score (0-5)
     */
    private function score_faqs($article)
    {
        if (empty($article['faqs'])) {
            return 0;
        }

        $faq_count = count($article['faqs']);
        $cfg = Threshold_Config::get($this->mode)['faqs'];

        if ($faq_count >= $cfg['full_count']) {
            return $cfg['pts_full'];
        } elseif ($faq_count >= $cfg['partial_count']) {
            return $cfg['pts_partial'];
        }

        return 0;
    }

    /**
     * Score safety signals (Max 12)
     * @MODIFIED v1.7.0: Rebalanced pts (verified=5, hash=4, scanned=1)
     * @MODIFIED v1.9.3: Rebalanced to 12 pts (verified=6, hash=5, scanned=1)
     * @MODIFIED v2.0.2: Unverified + hash gets partial credit for honesty
     *
     * @param array $article Article data
     * @return int Score (0-12)
     */
    private function score_safety_signals($article)
    {
        $score = 0;

        if (!empty($article['safety']['verified_download'])) {
            $score += 10; // @since 2.6.1: Verified is primary signal
        } else {
            // @since 2.6.1: Base score for official links without verification
            $score += 4;
        }
        // @since 2.6.1: Hash is now optional bonus
        if (!empty($article['safety']['file_hash'])) {
            $score += 1;
        }
        if (!empty($article['safety']['scanned_by'])) {
            $score += 1;
        }

        return $score;
    }

    /**
     * Score download section (Max 15)
     * @MODIFIED v1.7.0: Rebalanced to 12 pts
     * @MODIFIED v1.9.2: 4-dimension scoring for portal trust
     * @MODIFIED v1.9.3: Rebalanced to 15 pts for download-intent priority
     *   - Dimension 1 (4 pts): Primary link exists and is real
     *   - Dimension 2 (3 pts): Label is meaningful (not generic)
     *   - Dimension 3 (4 pts): Platform matrix coverage (≥2 platforms OR variants)
     *   - Dimension 4 (4 pts): Domain matches official homepage
     *
     * @param array $article Article data
     * @return int Score (0-15)
     */
    private function score_download_section($article)
    {
        $score = 0;

        if (empty($article['download_section']['links']) || !is_array($article['download_section']['links'])) {
            return 0;
        }

        $links = $article['download_section']['links'];

        // Find primary link
        $primary_link = null;
        foreach ($links as $link) {
            if (!empty($link['is_primary'])) {
                $primary_link = $link;
                break;
            }
        }
        if (!$primary_link && !empty($links[0])) {
            $primary_link = $links[0];
        }

        // DIMENSION 1: Primary link exists and is real (5 pts)
        $url = isset($primary_link['url']) ? self::as_string($primary_link['url']) : '';
        if (!empty($url) && self::PLACEHOLDER_URL !== $url && filter_var($url, FILTER_VALIDATE_URL)) {
            $score += 5;
        }

        // DIMENSION 2: Label is meaningful (3 pts)
        // Not generic like "Click here", "Download", has platform/version info
        $label = isset($primary_link['text']) ? self::as_string($primary_link['text']) : '';
        $generic_labels = array('download', 'click here', 'get it', 'download now', 'free download');
        $is_generic = in_array(strtolower($label), $generic_labels, true) || strlen($label) <= 5;
        if (!empty($label) && !$is_generic) {
            $score += 3;
        }

        // DIMENSION 3: Platform matrix coverage (4 pts)
        // Full points for: ≥2 distinct platforms, OR 1 platform with ≥2 variants
        $platforms = array();
        $variants = array();
        foreach ($links as $link) {
            $platform = isset($link['platform']) ? strtolower(self::as_string($link['platform'])) : '';
            $variant = isset($link['variant']) ? strtolower(self::as_string($link['variant'])) : '';

            if (!empty($platform)) {
                $platforms[$platform] = true;
            }
            if (!empty($variant)) {
                $variants[$variant] = true;
            }
        }

        $platform_count = count($platforms);
        $variant_count = count($variants);

        // Full 4 pts: ≥2 platforms OR (1 platform with ≥2 variants)
        if ($platform_count >= 2 || ($platform_count === 1 && $variant_count >= 2)) {
            $score += 4;
        } elseif ($platform_count >= 1) {
            // Single platform, no meaningful variants: 2 pts
            // Note: Links with no platform field set get 0 pts for this dimension
            $score += 2;
        }
        // $platform_count === 0: no points for platform matrix (missing platform data)

        // DIMENSION 4: Domain matches official homepage (4 pts)
        // @since 2.6.2: Improved matching - extract root domain for comparison (handles CDNs/subdomains)
        if (!empty($url) && !empty($article['tech_specs']['homepage'])) {
            $download_host = parse_url($url, PHP_URL_HOST);
            $homepage_host = parse_url($article['tech_specs']['homepage'], PHP_URL_HOST);

            if ($download_host && $homepage_host) {
                // Strip www. for comparison
                $download_host = preg_replace('/^www\./', '', $download_host);
                $homepage_host = preg_replace('/^www\./', '', $homepage_host);

                // Extract root domains and compare
                $download_root = $this->extract_root_domain($download_host);
                $homepage_root = $this->extract_root_domain($homepage_host);

                if ($download_root === $homepage_root) {
                    $score += 5;
                }
                // No points if root domains differ
            }
        }

        return $score;
    }

    /**
     * Score keyword density (Uses Threshold_Config for max points)
     * @MODIFIED 2025-12-12 v1.9.0: Uses Threshold_Config
     * @MODIFIED 2025-12-12 v1.9.3: Max reduced from 8 to 6
     *
     * @param array $article Article data
     * @return int Score
     */
    private function score_keyword_density($article)
    {
        if (empty($article['html_content']) || empty($article['focus_keyword'])) {
            return 0;
        }

        $text = wp_strip_all_tags($article['html_content']);
        $total_words = str_word_count($text);

        if ($total_words === 0) {
            return 0;
        }

        $keyword_count = substr_count(strtolower($text), strtolower($article['focus_keyword']));
        $density = ($keyword_count / $total_words) * 100;
        $cfg = Threshold_Config::get($this->mode)['keyword_density'];

        if ($density >= $cfg['full_min'] && $density <= $cfg['full_max']) {
            return $cfg['pts_full'];
        } elseif ($density >= $cfg['partial_min'] && $density <= $cfg['partial_max']) {
            return $cfg['pts_partial'];
        } elseif ($density >= $cfg['low_min'] && $density <= $cfg['low_max']) {
            return $cfg['pts_low'];
        }

        return 0;
    }

    /**
     * Score meta description (Max 8)
     * @MODIFIED 2025-12-12 v1.9.0: Uses Threshold_Config
     *
     * @param array $article Article data
     * @return int Score (0-8)
     */
    private function score_meta_description($article)
    {
        if (empty($article['meta_description'])) {
            return 0;
        }

        $length = strlen($article['meta_description']);
        $cfg = Threshold_Config::get($this->mode)['meta_description'];

        if ($length >= $cfg['full_min'] && $length <= $cfg['full_max']) {
            return $cfg['pts_full'];
        }
        if ($length >= $cfg['partial_min'] && $length <= $cfg['partial_max']) {
            return $cfg['pts_partial'];
        }
        if ($length >= $cfg['low_min'] && $length <= $cfg['low_max']) {
            return $cfg['pts_low'];
        }

        return 0;
    }

    /**
     * Score technical specs (Max 18)
     * @MODIFIED v1.7.0: Rebalanced to 18 pts with trust fields
     *
     * @param array $article Article data
     * @return int Score (0-18)
     */
    private function score_tech_specs($article)
    {
        if (empty($article['tech_specs'])) {
            return 0;
        }

        $score = 0;
        $specs = $article['tech_specs'];

        // Core fields (8 pts)
        if (!empty($specs['software_name'])) {
            $score += 2;
        }
        if (!empty($specs['version'])) {
            $score += 2;
        }
        if (!empty($specs['license'])) {
            $score += 2;
        }
        if (!empty($specs['file_size'])) {
            $score += 1;
        }
        if (!empty($specs['os_support'])) {
            $score += 1;
        }

        // Trust fields (12 pts)
        if (!empty($specs['developer'])) {
            $score += 4;
        }
        if (!empty($specs['homepage']) && filter_var($specs['homepage'], FILTER_VALIDATE_URL)) {
            $score += 4;
        }
        if (!empty($specs['last_updated'])) {
            $score += 2;
        }
        if (!empty($specs['language_support'])) {
            $score += 1;
        }
        if (!empty($specs['file_type'])) {
            $score += 1;
        }

        return $score;
    }

    /**
     * Score features (Max 5)
     * @MODIFIED 2025-12-12 v1.9.0: Uses Threshold_Config
     *
     * @param array $article Article data
     * @return int Score (0-5)
     */
    private function score_features($article)
    {
        if (empty($article['features'])) {
            return 0;
        }

        $feature_count = count($article['features']);
        $cfg = Threshold_Config::get($this->mode)['features'];

        if ($feature_count >= $cfg['full_count']) {
            return $cfg['pts_full'];
        } elseif ($feature_count >= $cfg['partial_count']) {
            return $cfg['pts_partial'];
        } elseif ($feature_count >= $cfg['low_count']) {
            return $cfg['pts_low'];
        }

        return 0;
    }

    /**
     * Score moat count (Max 3)
     * Count-based scoring only; quality is validated separately in the validator.
     * @ADDED 2026-04-30: Count gating to reduce fixed-3 pattern.
     *
     * @param array $article Article data
     * @return int Score (0-3)
     */
    private function score_moat($article)
    {
        if (empty($article['moat_data']['content'])) {
            return 0;
        }

        $moat_count = count($article['moat_data']['content']);
	$cfg = Threshold_Config::get($this->mode)['moat'] ?? ['full_count' => 3, 'min_count' => 0];

        if ($moat_count >= $cfg['full_count']) {
            return 3;
        } elseif ($moat_count >= $cfg['min_count']) {
            return 2;
        }

        return 0;
    }

    /**
     * Score installation guide (Uses Threshold_Config for max points)
     * @MODIFIED 2025-12-12 v1.9.0: Uses Threshold_Config
     * @MODIFIED 2025-12-12 v1.9.3: Max increased from 5 to 8
     *
     * @param array $article Article data
     * @return int Score
     */
    private function score_installation_guide($article)
    {
        if (empty($article['installation_guide']['steps'])) {
            return 0;
        }

        $step_count = count($article['installation_guide']['steps']);
        $cfg = Threshold_Config::get($this->mode)['installation_steps'];

        if ($step_count >= $cfg['full_count']) {
            return $cfg['pts_full'];
        } elseif ($step_count >= $cfg['partial_count']) {
            return $cfg['pts_partial'];
        }

        return 0;
    }

    /**
     * Score system requirements (Max 8)
     * @MODIFIED v1.7.0: New method for portal-grade hardening
     *
     * @param array $article Article data
     * @return int Score (0-8)
     */
    private function score_system_requirements($article)
    {
        $score = 0;

        if (!empty($article['system_requirements']['minimum']['os'])) {
            $score += 6;
        }
        if (!empty($article['system_requirements']['recommended'])) {
            $score += 2;
        }

        return $score;
    }

    /**
     * Score editor rating (Max 3)
     * @MODIFIED v1.7.0: New method for portal-grade hardening
     * @MODIFIED v1.9.3: Reduced from 5 to 3 (weak signal, easily gamed)
     *
     * @param array $article Article data
     * @return int Score (0-3)
     */
    private function score_editor_rating($article)
    {
        if (empty($article['editor_rating'])) {
            return 0;
        }

        $rating = floatval($article['editor_rating']);
        $cfg = Threshold_Config::get($this->mode)['editor_rating'] ?? array('pts_max' => 3);

        if ($rating >= 1 && $rating <= 5) {
            return $cfg['pts_max'];
        }

        return 0;
    }

    /**
     * Get download section score for Validator gating
     * @MODIFIED v1.9.3: Added for Portal hard gate on download quality
     *
     * @param array $article Article data
     * @return int Download section score (0-17)
     */
    public function get_download_section_score($article)
    {
        return $this->score_download_section($article);
    }

    /**
     * Extract root/registrable domain from a hostname.
     * Handles subdomains and common TLD patterns (including country-code TLDs).
     *
     * @since 2.6.2: Added for improved domain matching (CDN/subdomain support)
     *
     * @param string $host Hostname to extract root domain from
     * @return string Root domain
     */
    private function extract_root_domain($host)
    {
        if (empty($host)) {
            return '';
        }

        $parts = explode('.', $host);
        $count = count($parts);

        if ($count <= 2) {
            return $host;
        }

        // Common country-code second-level domains
        $country_slds = array(
            'co.uk',
            'org.uk',
            'me.uk',
            'ac.uk',
            'co.nz',
            'org.nz',
            'ac.nz',
            'com.au',
            'org.au',
            'net.au',
            'co.jp',
            'ne.jp',
            'or.jp',
            'co.in',
            'org.in',
            'net.in',
            'com.br',
            'org.br',
            'net.br',
            'co.za',
            'org.za',
        );

        $last_two = $parts[$count - 2] . '.' . $parts[$count - 1];
        if (in_array($last_two, $country_slds, true)) {
            return implode('.', array_slice($parts, -3));
        }

        return implode('.', array_slice($parts, -2));
    }
}
