# Brand Links — MANUAL LIST v4 (2026-09-01, user hand-verified batch applied)

**USER-VERIFIED BATCH (16 brands) applied — map now 186 rows: 153 site+IG, 33 IG-only, 0 site-only.**
Resolved by you: zouj (zouj.store + zouj.official), shurooq (+shurooqpakistan), dhaga (+dhagaofficialstore),
rehan-n-muzammil (IG-only), inara (shopinara confirmed), abyaan, maherposh, tana-bana (tanabana.com.pk),
nomi-nisar, saphron (saphrononline.com), shahjahan (shahjahanofficial.com), regalia-textiles,
maryam-hussain (maryamhussain.pk), yashfa (yashfastudio.com), bin-saeed (IG → binsaeedfabrics), elan (+elanofficial).
All new domains spot-checked live (200 OK).

**176 / 239 brands live in `config/brand-map.txt`** (138 site+IG, 6 site-only, 32 IG-only).
Every site row was re-verified from its own page source: brand token + PK-fashion signals +
not-parked, and the Instagram read from the brand's own footer/JSON-LD `sameAs` (119 exact
matches; the rest fixed below). Expired domains (NXDOMAIN at the .com/.pk registry):
avyana.pk, bareeqoutfits.com, khuwabbykazma.com, misaalwear.com, ricamo.com.pk — sites
blanked, their (alive) Instagrams kept. Moved domains updated: Saira Rizwan → sairarizwan.pk,
LSM Lakhany → lakhanyonline.com, Misaal → misaalbyas.com, Narmin → narmin.pk, Sahar →
saharonline.pk (user-reported, confirmed).

## 1) PICK ONE — both candidates look right

- **tng**: tngclothing.com ("The New Generation") — unsure it's the PK brand; **unss-apparel**: unsforall.com ("UNS Shop"); **zebtan**: zaibtan.online vs zebtancollection.com — still open.

## 2) IG STILL MISSING (site live+verified, IG is JS-only) — grab from your phone

- **bin-saeed / threads-motifs**: IGs in map from their indexed schema; site no longer shows them in HTML — spot-check once.
- **dhaga** (Dhaga): https://dhaga.com.pk
- **elan** (Elan): https://elan.pk
- **inara** (Inara): https://inara.pk
- **rehan-n-muzammil** (Rehan N Muzammil): https://rehannmuzammil.com
- **shurooq** (Shurooq): https://shurooq.pk
- **zellbury** (Zellbury): https://zellbury.com
- **bin-saeed / threads-motifs**: IGs in map (binsaeedonline 113K / threadsandmotifsofficial) from their indexed schema — site no longer shows them in HTML; spot-check once.

## 3) IG-ONLY ROWS (32) — evidence = search-indexed profiles with brand bios; no site to cross-check
Fine to keep; if you want 100% eyeballs, open each once. Notable: elaf (122K), meeral (233K),
tgm (173K). Full list = map rows with empty website field.

## 4) NO LINKS FOUND (~50) + confirmed-foreign rejects
Unchanged from v2 — see docs/brand-search-log.md waves for what was checked.


## 6) CF/BLOCKED-RESIDUE OUTCOMES (2026-09-01, this pass)

- **inara**: inara.pk was WRONG — "Inara Technologies" (IT company). Replaced with shopinara.com + IG shop_inaraofficial (own schema, PK store, Rs. prices). VERIFY once: confirm Sanaulla's Inara products = this brand.
- **zellbury**: IG confirmed @zellbury by user.
