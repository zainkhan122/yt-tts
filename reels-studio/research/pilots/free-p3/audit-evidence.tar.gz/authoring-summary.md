# Optional agent — shadow authoring report

Status: **authoring_partial_or_blocked** · production activation: **OFF**

| Case | Actual stage |
|---|---|
| news-gemini-agent-01 | blocked_quality |
| news-haiku-55-01 | blocked_quality |
| repo-whistle-01 | blocked_quality |
| tool-mosa-01 | blocked |
| tool-pomelli-01 | blocked |

No publication was attempted. Model ratings are not parity certification.

