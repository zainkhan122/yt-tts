<?php

namespace SEO_Article_Generator\Security;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Rate Limiter
 * 
 * Simple transient-based rate limiting by IP.
 * @since 2.13.5
 */
class Rate_Limiter
{
    /**
     * Check if request is allowed
     * 
     * @param string $action Action name (e.g. 'download_track')
     * @param int $limit Max requests
     * @param int $window Window in seconds
     * @return bool|WP_Error True if allowed, WP_Error if limit exceeded
     */
    public static function check($action, $limit = 10, $window = 3600)
    {
        global $wpdb;
        $ip = self::get_ip();
        $transient_key = 'seo_gen_rl_' . $action . '_' . md5($ip);
        $now = time();

        // 1. Check expiration first (simple check)
        $timeout_key = '_transient_timeout_' . $transient_key;
        $expiry = (int) get_option($timeout_key);
        if ($expiry && $expiry < $now) {
            delete_option($transient_key);
            delete_option($timeout_key);
        }

        // 2. Atomic Increment and Limit Check
        // We use ON DUPLICATE KEY UPDATE with an IF condition.
        // If the update happens but the value doesn't change because it hit the limit, 
        // rows_affected will be 0.
        $wpdb->query($wpdb->prepare(
            "INSERT INTO {$wpdb->options} (option_name, option_value, autoload) 
             VALUES (%s, '1', 'no') 
             ON DUPLICATE KEY UPDATE 
             option_value = IF(CAST(option_value AS UNSIGNED) < %d, CAST(option_value AS UNSIGNED) + 1, option_value)",
            $transient_key,
            $limit
        ));

        // Use get_var to see if we are currently over limit (post-increment)
        $count = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s",
            $transient_key
        ));

        if ($count >= $limit) {
            // Note: We don't decrement here because the IF condition prevented the increment if it was already at limit.
            // But if multiple workers hit it at the exact same time, we're safe.
            return new \WP_Error('rate_limit_exceeded', 'Too many requests. Please try again later.');
        }

        // 3. Set expiration if it doesn't exist
        if (!get_option($timeout_key)) {
            update_option($timeout_key, $now + $window);
        }

        return true;
    }

    /**
     * Get Client IP (Simple version)
     */
    private static function get_ip()
    {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            return sanitize_text_field($_SERVER['HTTP_CLIENT_IP']);
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            return sanitize_text_field($_SERVER['HTTP_X_FORWARDED_FOR']);
        } else {
            return isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field($_SERVER['REMOTE_ADDR']) : '0.0.0.0';
        }
    }
}
