// content_ui_modals.js - Modal dialogs and popups
(function() {
  'use strict';

  // Initialize Namespace
  window.ShareUnlimited = window.ShareUnlimited || {};
  window.ShareUnlimited.UI = window.ShareUnlimited.UI || {};
  
  const UI = window.ShareUnlimited.UI;

  // ---- Preset group entries ----------------------------------------------
  // A preset's groups are {name, id} refs (legacy presets hold plain name
  // strings; both shapes go through these). Core owns the implementations —
  // these are thin, defensively-guarded wrappers so this file keeps working if
  // it somehow evaluates before content_core.js.
  const presetCore = () => (window.ShareUnlimited && window.ShareUnlimited.Core) || null;

  // Group names and preset names are user/Facebook text — `&`, `<`, quotes and
  // bidi marks all occur in real group names, so nothing goes into an innerHTML
  // template unescaped.
  const escHtml = s => String(s).replace(/[&<>"']/g,
    c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  // Backdrop-dismiss for full-screen modals. Dismissing on a plain 'click' with
  // `e.target === backdrop` is unsafe: if the user starts a drag INSIDE the card
  // (selecting post text, dragging the delay slider, dragging it past the
  // track's end) and the pointer strays over the dimmed backdrop before they
  // release, browsers resolve that click's target to the nearest common
  // ancestor of mousedown/mouseup — the backdrop — even though nothing was
  // "clicked outside". That silently wiped the whole modal (typed content,
  // pace, slider) mid-drag. Requiring the mousedown to ALSO have landed on the
  // backdrop (not just the mouseup/click) fixes it without weakening real
  // outside-click-to-close. Every modal's backdrop-dismiss goes through this.
  const wireBackdropDismiss = (backdrop, onDismiss) => {
    let pressedBackdrop = false;
    backdrop.addEventListener('mousedown', (e) => { pressedBackdrop = (e.target === backdrop); });
    backdrop.addEventListener('click', (e) => {
      if (e.target === backdrop && pressedBackdrop) onDismiss(e);
      pressedBackdrop = false;
    });
  };
  UI.wireBackdropDismiss = wireBackdropDismiss;

  const presetRefsOf = (preset) => {
    const C = presetCore();
    if (C && C.presetGroupRefs) return C.presetGroupRefs(preset);
    const list = Array.isArray(preset) ? preset : (preset && preset.groups) || [];
    return list
      .map(g => {
        const name = (g && typeof g === 'object') ? String(g.name || '') : String(g || '');
        if (!name) return null;
        return { name, id: (g && typeof g === 'object' && g.id) ? String(g.id) : null };
      })
      .filter(Boolean);
  };

  // Deduplicate BY IDENTITY — the group ID when it is known, the normalized name
  // only when it isn't. Never dedupe preset groups with a plain Set of names:
  // two groups can legitimately share a display name and are still two groups.
  const dedupeRefs = (entries) => {
    const C = presetCore();
    if (C && C.dedupePresetRefs) return C.dedupePresetRefs(entries);
    const seen = new Set();
    const out = [];
    presetRefsOf(entries).forEach(ref => {
      const key = ref.id ? 'id:' + ref.id : 'nm:' + String(ref.name).trim().toLowerCase();
      if (seen.has(key)) return;
      seen.add(key);
      out.push(ref);
    });
    return out;
  };

  /**
   * Builds `(preset) => [{name, id}]`, recovering group IDs for LEGACY entries.
   *
   * Presets saved before v18.2 hold plain names, so two entries reading "ABC"
   * are indistinguishable on their face — which is exactly how a three-group
   * preset ended up posting to two groups. The group inventory is ID-keyed and
   * does know both, so a legacy name is resolved against it, CONSUMING one
   * candidate per entry: two "ABC" entries take the two different ABC groups
   * instead of both pointing at whichever one came first.
   *
   * Which entry gets which ID is arbitrary, and that is fine — the result is a
   * set of groups to post to, and both orderings describe the same set. Nothing
   * is written back to storage: the inventory changes as the user joins and
   * leaves groups, so this stays a read-time recovery, never a stamp. Re-saving
   * the preset is what makes the IDs permanent.
   *
   * Entries that already carry an ID are returned untouched, and a name with no
   * inventory hit keeps `id: null` and is matched by name as it always was.
   */
  function makePresetRefResolver(inventory, norm) {
    const C = presetCore();
    if (C && C.makePresetRefResolver) return C.makePresetRefResolver(inventory);
    const byNorm = new Map();
    (inventory || []).forEach(g => {
      const k = norm(g.name);
      if (!byNorm.has(k)) byNorm.set(k, []);
      byNorm.get(k).push(g);
    });
    return (preset) => {
      const consumed = new Map();
      return presetRefsOf(preset).map(ref => {
        if (ref.id) return ref;
        const k = norm(ref.name);
        const candidates = byNorm.get(k) || [];
        const taken = consumed.get(k) || 0;
        consumed.set(k, taken + 1);
        const hit = candidates[taken];
        return hit ? { name: hit.name, id: hit.id } : ref;
      });
    };
  }

  /** As above, loading the active profile's inventory itself. Never throws. */
  async function buildPresetRefResolver() {
    const C = presetCore();
    const norm = (C && C.normalizeGroupNameForMatch)
      ? C.normalizeGroupNameForMatch
      : (s => String(s).trim().toLowerCase());
    let inventory = [];
    try {
      if (C && C.Inventory) inventory = await C.Inventory.getAll();
    } catch (e) {
      // No inventory (never swept, storage blocked) — legacy entries simply keep
      // matching by name, which is what they did before.
    }
    return makePresetRefResolver(inventory, norm);
  }

  /**
   * Shows the license expired modal
   */
  function showLicenseExpiredModal() {
    const existing = document.getElementById('share-unlimited-license-modal');
    if (existing) existing.remove();
    
    const modal = document.createElement('div');
    modal.id = 'share-unlimited-license-modal';
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        z-index: 99999999;
        display: flex;
        align-items: center;
        justify-content: center;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    `;

    const modalContent = document.createElement('div');
    modalContent.style.cssText = `
        background: white;
        border-radius: 12px;
        padding: 40px;
        max-width: 500px;
        text-align: center;
        box-shadow: 0 12px 40px rgba(0, 0, 0, 0.3);
    `;

    modalContent.innerHTML = `
        <div style="font-size: 64px; margin-bottom: 20px;">🎉</div>
        <h2 style="color: #050505; margin: 0 0 16px 0; font-size: 28px; font-weight: 700;">Glad you tried MGSA!</h2>
        <p style="color: #050505; margin: 0 0 12px 0; font-size: 18px; line-height: 1.6; font-weight: 500;">
            Want to continue sharing in 1 click?
        </p>
        <p style="color: #65676b; margin: 0 0 28px 0; font-size: 16px; line-height: 1.5;">
            Click on the extension icon to extend your license today! ✨
        </p>
        <button id="close-license-modal" style="
            background: #1877f2;
            border: none;
            color: white;
            padding: 14px 36px;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
        ">Got it!</button>
    `;

    modal.appendChild(modalContent);
    document.body.appendChild(modal);

    const closeBtn = modal.querySelector('#close-license-modal');
    closeBtn.addEventListener('mouseenter', () => {
        closeBtn.style.background = '#166fe5';
    });
    closeBtn.addEventListener('mouseleave', () => {
        closeBtn.style.background = '#1877f2';
    });
    closeBtn.addEventListener('click', () => modal.remove());

    wireBackdropDismiss(modal, () => modal.remove());
  }

  // ---------------------------------------------------------------------------
  // Info tooltips (v17.1)
  //
  // Every explanatory paragraph that used to sit permanently in the share modal
  // now lives behind a small (i). One shared tooltip element is appended to
  // <body> (NOT inside the modal) so it is never clipped by the modal's own
  // overflow/scroll, and it is positioned with fixed coords each time it opens.
  // Tooltip HTML is authored here only — never interpolate user/group text into it.
  // ---------------------------------------------------------------------------
  const INFO_TIPS = {
    preset: `
      <b>Share to this exact list in 1 click — forever.</b>
      <p>Save these groups once instead of re-selecting them every time you post.</p>
      <ul>
        <li>Re-share to the whole list in a single click</li>
        <li>Keep a separate list per campaign or niche</li>
        <li>Combine 2+ lists — every unique group gets it once, no duplicates</li>
      </ul>`,
    delay: `
      <b>How long MGSA waits between each group.</b>
      <p>Facebook flags accounts that post too fast, so bigger gaps look more human.
      <b>8–15s</b> suits most accounts. Go higher if you're sharing to a lot of groups
      or your account is new.</p>`,
    delaymode: `
      <b>How long to wait between each group.</b>
      <p>Posting at a perfectly even rhythm is one of the easiest automation patterns
      for Facebook to spot, so two of these three pick a random gap every time.</p>
      <p>The gap isn't the whole story: finding the group, filling the box and posting
      takes about <b>10s per group</b> whatever you pick here. So the wait you choose
      lands <i>on top</i> of that.</p>
      <ul>
        <li><b>No randomization</b> — exactly your delay, every group. Predictable
        timing is the pattern Facebook looks for.</li>
        <li><b>🚀 Turbo (0s)</b> — no gap at all: the next group starts the moment the
        last post lands, about <b>10 seconds apart</b>. This is as fast as MGSA can go.
        Built for accounts that already share a lot, every day.</li>
        <li><b>⚡ Human Lookalike (1–8s)</b> — posts land roughly <b>15 seconds apart</b>,
        which is about the pace of a person sharing by hand. That's the idea: it does the
        job you'd otherwise sit and do yourself, at about the speed you'd do it. Best on an
        established account — and best with the watermark off, since a post signed
        "Shared using MGSApro" gives the game away however well it's paced.</li>
        <li><b>🛡️ Safest (15–45s)</b> — slower and more spread out. Use it for very big
        runs, new accounts, or anything you can just leave running.</li>
      </ul>
      <p>Because of that fixed 10s, the faster modes save less than they look like they
      should — over 200 groups Turbo is about <b>33 min</b> against <b>60 min</b> on the 8s
      default. The estimate at the top is the number to actually go by.</p>
      <p><b>Whatever you pick here is remembered</b> and used for your next share, so you
      only have to set it once.</p>`,
    variants: `
      <b>A different wording for every group.</b>
      <p>Posting identical text into group after group is the pattern Facebook's
      spam systems look for. Rotating human-sounding variants makes the run read
      like a person posting, not a bot.</p>
      <p>Variants are used in order and start over when they run out — 12 variants
      across 30 groups means each one is used 2–3 times, never twice in a row.</p>`,
    tab: `
      <b>Facebook stops responding in a background tab.</b>
      <p>It pauses rendering, so group rows never load and clicks land on stale
      elements — the post can go to the wrong group, or to the same group twice.
      <b>Locking your screen counts as leaving.</b></p>
      <p>If you step away <i>between</i> groups, MGSA now parks itself and picks up
      where it left off when you come back — nothing is lost, it just waits. What it
      can't survive is leaving <i>mid-post</i>, so the safe habit is still: leave it
      on screen.</p>
      <p>Other <b>windows</b> on top are fine. Just don't switch to another
      <b>tab</b> in this window until it's done.</p>`
  };

  let tipEl = null;
  let tipOwner = null;

  function getTipEl() {
    if (tipEl && tipEl.isConnected) return tipEl;
    tipEl = document.createElement('div');
    tipEl.className = 'su-tip';
    tipEl.setAttribute('role', 'tooltip');
    document.body.appendChild(tipEl);
    return tipEl;
  }

  function hideInfoTip() {
    if (tipEl) tipEl.classList.remove('su-tip-open');
    if (tipOwner) tipOwner.classList.remove('su-pm-i-active');
    tipOwner = null;
  }

  function showInfoTip(trigger, html) {
    const tip = getTipEl();
    tip.innerHTML = html;
    tip.style.visibility = 'hidden';
    tip.classList.add('su-tip-open');

    const r = trigger.getBoundingClientRect();
    const t = tip.getBoundingClientRect();
    const GAP = 10;
    const EDGE = 10;

    let top = r.top - t.height - GAP;
    let below = false;
    if (top < EDGE) { top = r.bottom + GAP; below = true; }

    let left = r.left + (r.width / 2) - (t.width / 2);
    left = Math.max(EDGE, Math.min(left, window.innerWidth - t.width - EDGE));

    tip.style.top = `${Math.round(top)}px`;
    tip.style.left = `${Math.round(left)}px`;
    tip.dataset.place = below ? 'below' : 'above';
    tip.style.setProperty('--su-tip-arrow', `${Math.round(r.left + r.width / 2 - left)}px`);
    tip.style.visibility = 'visible';

    tipOwner = trigger;
    trigger.classList.add('su-pm-i-active');
  }

  /**
   * Wires every [data-su-tip] trigger inside `root`. Hover/focus opens, and click
   * toggles (so it also works on touch, where there is no hover).
   */
  function wireInfoTips(root) {
    ensureTipStyles();
    root.querySelectorAll('[data-su-tip]').forEach((btn) => {
      const html = INFO_TIPS[btn.dataset.suTip];
      if (!html) return;
      btn.addEventListener('mouseenter', () => showInfoTip(btn, html));
      btn.addEventListener('mouseleave', () => { if (tipOwner === btn) hideInfoTip(); });
      btn.addEventListener('focus', () => showInfoTip(btn, html));
      btn.addEventListener('blur', () => { if (tipOwner === btn) hideInfoTip(); });
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (tipOwner === btn) hideInfoTip(); else showInfoTip(btn, html);
      });
    });
    // The tooltip is fixed-positioned against the viewport, so it has to close
    // when the modal body scrolls out from under it.
    const scroller = root.querySelector('.su-pm-body');
    if (scroller) scroller.addEventListener('scroll', hideInfoTip, { passive: true });
  }

  function ensureTipStyles() {
    if (document.getElementById('su-tip-styles')) return;
    const s = document.createElement('style');
    s.id = 'su-tip-styles';
    s.textContent = `
      .su-tip {
        position: fixed !important;
        z-index: 100000001 !important;
        max-width: 268px !important;
        background: #1c1e21 !important;
        color: #e4e6eb !important;
        padding: 10px 12px !important;
        border-radius: 10px !important;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif !important;
        font-size: 12.5px !important;
        line-height: 1.5 !important;
        box-shadow: 0 8px 28px rgba(0,0,0,0.32) !important;
        opacity: 0; visibility: hidden;
        transform: translateY(4px);
        transition: opacity .14s ease, transform .14s ease !important;
        pointer-events: none !important;
      }
      .su-tip.su-tip-open { opacity: 1; transform: translateY(0); }
      .su-tip b { color: #fff !important; font-weight: 700 !important; }
      .su-tip p { margin: 6px 0 0 0 !important; color: #b0b3b8 !important; }
      .su-tip ul { margin: 7px 0 0 0 !important; padding: 0 0 0 15px !important; }
      .su-tip li { margin: 3px 0 !important; color: #d8dadf !important; }
      .su-tip::after {
        content: ''; position: absolute;
        left: var(--su-tip-arrow, 50%);
        margin-left: -6px;
        border: 6px solid transparent;
      }
      .su-tip[data-place="above"]::after { top: 100%; border-top-color: #1c1e21; }
      .su-tip[data-place="below"]::after { bottom: 100%; border-bottom-color: #1c1e21; }
    `;
    document.head.appendChild(s);
  }

  /**
   * Stylesheet for the share modal. Replaces ~250 lines of inline style strings —
   * everything is namespaced under #share-unlimited-post-modal so it cannot leak
   * into Facebook's own UI, and carries !important because FB's stylesheet is
   * aggressive on generic selectors (button, input, label).
   */
  function ensurePostModalStyles() {
    if (document.getElementById('su-post-modal-styles')) return;
    const s = document.createElement('style');
    s.id = 'su-post-modal-styles';
    s.textContent = `
      @property --su-preset-angle { syntax: '<angle>'; initial-value: 0deg; inherits: false; }
      @keyframes su-preset-spin { to { --su-preset-angle: 360deg; } }
      @keyframes su-pm-in { from { opacity: 0; transform: translateY(8px) scale(.985); } to { opacity: 1; transform: none; } }
      @keyframes su-pm-fade { from { opacity: 0; } to { opacity: 1; } }

      #share-unlimited-post-modal {
        position: fixed !important; inset: 0 !important;
        background: rgba(0,0,0,0.55) !important;
        z-index: 99999999 !important;
        display: flex !important; align-items: center !important; justify-content: center !important;
        padding: 16px !important; box-sizing: border-box !important;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif !important;
        animation: su-pm-fade .16s ease !important;
      }
      #share-unlimited-post-modal * { box-sizing: border-box !important; }

      /* The card never exceeds the viewport: header and footer are pinned, only
         the middle scrolls. This is what stops the modal running off-screen on
         short windows / large group lists. */
      .su-pm-card-root {
        background: #fff !important;
        border-radius: 14px !important;
        width: 100% !important; max-width: 540px !important;
        max-height: min(88vh, 760px) !important;
        display: flex !important; flex-direction: column !important;
        overflow: hidden !important;
        box-shadow: 0 24px 64px rgba(0,0,0,0.30), 0 2px 8px rgba(0,0,0,0.12) !important;
        animation: su-pm-in .18s cubic-bezier(.2,.8,.3,1) !important;
      }

      /* ---- header ---- */
      .su-pm-head {
        flex: 0 0 auto !important;
        display: flex !important; align-items: flex-start !important; justify-content: space-between !important;
        gap: 12px !important;
        padding: 14px 16px 12px 18px !important;
        border-bottom: 1px solid #e4e6eb !important;
      }
      .su-pm-title { margin: 0 !important; color: #050505 !important; font-size: 19px !important; font-weight: 700 !important; letter-spacing: -.2px !important; }
      .su-pm-sub { margin-top: 3px !important; color: #65676b !important; font-size: 12.5px !important; display: flex !important; align-items: center !important; gap: 6px !important; }
      .su-pm-sub b { color: #050505 !important; font-weight: 600 !important; }
      .su-pm-x {
        flex: 0 0 auto !important;
        width: 32px !important; height: 32px !important; border-radius: 50% !important;
        background: #f0f2f5 !important; border: none !important; color: #65676b !important;
        font-size: 15px !important; cursor: pointer !important; transition: background .15s !important;
        display: flex !important; align-items: center !important; justify-content: center !important;
      }
      .su-pm-x:hover { background: #d8dadf !important; }

      /* ---- scrollable body ---- */
      .su-pm-body { flex: 1 1 auto !important; overflow-y: auto !important; padding: 14px 18px !important; }
      .su-pm-body::-webkit-scrollbar { width: 8px !important; }
      .su-pm-body::-webkit-scrollbar-thumb { background: #ccd0d5 !important; border-radius: 4px !important; }

      /* ---- info (i) ---- */
      .su-pm-i {
        width: 16px !important; height: 16px !important; min-width: 16px !important;
        border-radius: 50% !important; border: 1.5px solid #b0b3b8 !important;
        background: transparent !important; color: #65676b !important;
        font-size: 10px !important; font-weight: 800 !important; font-style: italic !important;
        line-height: 1 !important; padding: 0 !important; cursor: pointer !important;
        display: inline-flex !important; align-items: center !important; justify-content: center !important;
        transition: all .15s !important; flex: 0 0 auto !important; font-family: Georgia, serif !important;
      }
      .su-pm-i:hover, .su-pm-i-active { border-color: #1877f2 !important; color: #1877f2 !important; background: #e7f3ff !important; }
      .su-pm-i-onblue { border-color: rgba(255,255,255,.7) !important; color: #fff !important; }
      .su-pm-i-onblue:hover, .su-pm-i-onblue.su-pm-i-active { background: rgba(255,255,255,.22) !important; border-color: #fff !important; color: #fff !important; }
      .su-pm-i-warn { border-color: #c79100 !important; color: #7a5b00 !important; }
      .su-pm-i-warn:hover, .su-pm-i-warn.su-pm-i-active { background: #ffe9a8 !important; border-color: #7a5b00 !important; color: #7a5b00 !important; }

      /* ---- save-as-preset (one row) ---- */
      .su-pm-preset {
        position: relative !important; z-index: 0 !important; isolation: isolate !important;
        display: flex !important; align-items: center !important; gap: 6px !important;
        background: linear-gradient(135deg, #1877f2 0%, #0a66d8 100%) !important;
        border-radius: 10px !important; margin-bottom: 12px !important; padding-right: 11px !important;
        transition: filter .15s, box-shadow .15s !important;
        box-shadow: 0 2px 10px rgba(24,119,242,.22) !important;
      }
      .su-pm-preset:hover { filter: brightness(1.07) !important; box-shadow: 0 4px 16px rgba(24,119,242,.34) !important; }
      .su-pm-preset::before {
        content: ''; position: absolute; inset: -1.5px; border-radius: 11.5px; padding: 1.5px;
        background: conic-gradient(from var(--su-preset-angle), transparent 0deg, #00d4ff 40deg, #1877f2 110deg, #66b2ff 150deg, transparent 220deg, transparent 360deg);
        -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
        -webkit-mask-composite: xor; mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
        mask-composite: exclude; animation: su-preset-spin 2.8s linear infinite;
        pointer-events: none; z-index: -1;
      }
      .su-pm-preset-btn {
        flex: 1 1 auto !important; border: none !important; background: transparent !important;
        cursor: pointer !important; color: #fff !important;
        padding: 11px 4px 11px 12px !important; font-size: 13.5px !important; font-weight: 600 !important;
        display: flex !important; align-items: center !important; gap: 9px !important;
        text-align: left !important; font-family: inherit !important;
      }
      .su-pm-preset-btn .su-pm-grow { flex: 1 1 auto !important; }

      /* ---- collapsible group list ---- */
      .su-pm-groups { border: 1px solid #e4e6eb !important; border-radius: 10px !important; margin-bottom: 12px !important; overflow: hidden !important; }
      .su-pm-groups-head {
        width: 100% !important; background: #f7f8fa !important; border: none !important; cursor: pointer !important;
        padding: 9px 12px !important; display: flex !important; align-items: center !important; gap: 8px !important;
        font-family: inherit !important; font-size: 13px !important; color: #050505 !important; text-align: left !important;
        transition: background .15s !important;
      }
      .su-pm-groups-head:hover { background: #f0f2f5 !important; }
      .su-pm-chev { color: #65676b !important; font-size: 10px !important; transition: transform .18s ease !important; display: inline-block !important; }
      .su-pm-groups[open-list] .su-pm-chev { transform: rotate(90deg) !important; }
      .su-pm-groups-count { font-weight: 700 !important; flex: 0 0 auto !important; }
      .su-pm-groups-peek {
        flex: 1 1 auto !important; min-width: 0 !important; color: #65676b !important; font-size: 12px !important;
        white-space: nowrap !important; overflow: hidden !important; text-overflow: ellipsis !important;
      }
      .su-pm-groups-list { max-height: 132px !important; overflow-y: auto !important; padding: 4px 0 6px !important; border-top: 1px solid #e4e6eb !important; }
      .su-pm-group-row { display: flex !important; gap: 8px !important; padding: 4px 12px !important; font-size: 12.5px !important; color: #050505 !important; line-height: 1.4 !important; }
      .su-pm-group-row span:first-child { color: #8a8d91 !important; min-width: 18px !important; flex: 0 0 auto !important; }

      /* ---- post text ---- */
      .su-pm-field-head { display: flex !important; align-items: center !important; justify-content: space-between !important; margin-bottom: 6px !important; min-height: 26px !important; }
      .su-pm-field-head label { color: #050505 !important; font-size: 13.5px !important; font-weight: 600 !important; }
      .su-pm-opt { color: #8a8d91 !important; font-weight: 400 !important; font-size: 12px !important; }
      #quick-share-post-content {
        display: block !important;
        width: 100% !important; height: 86px !important; min-height: 60px !important;
        padding: 11px 12px !important; border: 1px solid #ccd0d5 !important; border-radius: 10px !important;
        font-size: 14px !important; font-family: inherit !important; resize: vertical !important;
        background: #fff !important; color: #050505 !important; line-height: 1.45 !important;
        transition: border-color .15s, box-shadow .15s !important; outline: none !important;
      }
      #quick-share-post-content:focus { border-color: #1877f2 !important; box-shadow: 0 0 0 3px rgba(24,119,242,.12) !important; }

      /* ---- timing card ---- */
      .su-pm-timing { background: #f7f8fa !important; border: 1px solid #e4e6eb !important; border-radius: 10px !important; padding: 10px 12px !important; margin: 12px 0 !important; }

      /* ---- pace: collapsed behind a button (v18.4) ----
         The four pace cards used to sit open permanently and cost ~200px of the
         modal's fixed height budget — enough that the warning and tip below them
         were off-screen on a laptop. They are a decision made once per run, so
         they collapse: button → summary of the current choice → panel on demand. */
      .su-pm-pace-btn {
        width: 100% !important; border: none !important; border-radius: 8px !important;
        background: #1877f2 !important; color: #fff !important;
        padding: 10px 12px !important; font-size: 13.5px !important; font-weight: 600 !important;
        font-family: inherit !important; cursor: pointer !important; text-align: left !important;
        display: flex !important; align-items: center !important; gap: 9px !important;
        transition: background .15s !important;
      }
      .su-pm-pace-btn:hover { background: #166fe5 !important; }
      .su-pm-pace-btn .su-pm-chev { color: #cfe0ff !important; }
      .su-pm-timing[data-pace-open="1"] .su-pm-pace-btn .su-pm-chev { transform: rotate(90deg) !important; }
      /* The summary is what makes collapsing safe: the chosen pace is never hidden,
         only the act of choosing it is. Never let this row go empty. */
      .su-pm-pace-sum {
        display: flex !important; align-items: center !important; gap: 7px !important;
        margin-top: 8px !important; flex-wrap: wrap !important;
      }
      .su-pm-pace-sum-tail { color: #65676b !important; font-size: 12px !important; font-weight: 600 !important; }
      .su-pm-pace-panel[hidden] { display: none !important; }
      .su-pm-row { display: flex !important; align-items: center !important; gap: 7px !important; }
      .su-pm-label { color: #050505 !important; font-size: 13px !important; font-weight: 600 !important; display: flex !important; align-items: center !important; gap: 6px !important; }
      .su-pm-grow { flex: 1 1 auto !important; }
      #quick-share-delay-input {
        width: 50px !important; padding: 4px 6px !important; border: 1px solid #ccd0d5 !important;
        border-radius: 7px !important; font-size: 13.5px !important; font-weight: 700 !important;
        text-align: center !important; color: #050505 !important; background: #fff !important;
        font-family: inherit !important; outline: none !important;
      }
      #quick-share-delay-input:focus { border-color: #1877f2 !important; }
      .su-pm-unit { color: #65676b !important; font-size: 12px !important; font-weight: 600 !important; }
      #quick-share-delay-slider {
        width: 100% !important; margin: 8px 0 4px !important; cursor: pointer !important;
        -webkit-appearance: none !important; appearance: none !important; background: transparent !important; height: 16px !important;
      }
      #quick-share-delay-slider::-webkit-slider-runnable-track { height: 5px !important; border-radius: 3px !important; background: #d8dadf !important; }
      #quick-share-delay-slider::-webkit-slider-thumb {
        -webkit-appearance: none !important; appearance: none !important;
        width: 16px !important; height: 16px !important; border-radius: 50% !important;
        background: #1877f2 !important; border: 2px solid #fff !important; margin-top: -5.5px !important;
        box-shadow: 0 1px 4px rgba(0,0,0,.3) !important; transition: transform .12s !important;
      }
      #quick-share-delay-slider:hover::-webkit-slider-thumb { transform: scale(1.15) !important; }
      .su-pm-check { display: flex !important; align-items: center !important; gap: 7px !important; cursor: pointer !important; color: #050505 !important; font-size: 12.5px !important; font-weight: 500 !important; }

      /* ---- delay mode radios (v18.0; 2-up top row v18.4) ---- */
      .su-pm-modes { display: flex !important; flex-direction: column !important; gap: 5px !important; margin-top: 9px !important; }
      /* The two "no waiting around" modes sit side by side so the fast choice is
         visible without reading down the list — that is the whole point of the row.
         Grid (not flex) so both halves are exactly 1fr regardless of text length;
         min-width:0 on the cards stops a long word from blowing the column out.
         NOTE: this whole stylesheet is a JS template literal — no backticks in here. */
      .su-pm-mode-pair { display: grid !important; grid-template-columns: 1fr 1fr !important; gap: 5px !important; }
      .su-pm-mode-pair > .su-pm-mode { min-width: 0 !important; }
      /* The "No randomization" card owns the base-delay slider (v18.4) — that control
         only means anything in this mode, so it lives where it applies instead of in a
         row of its own below. The card is therefore a DIV stacking a <label> hit-area
         over the slider, not a <label> wrapping everything: a label may contain at most
         one labelable descendant, and nesting the range + number inputs inside it is
         both invalid and unpredictable (browsers skip label forwarding for interactive
         targets, so the radio would sometimes not select). Same rule as the (i) button. */
      .su-pm-mode-stack { flex-direction: column !important; align-items: stretch !important; gap: 0 !important; cursor: default !important; }
      .su-pm-mode-hit { display: flex !important; align-items: flex-start !important; gap: 8px !important; cursor: pointer !important; }
      .su-pm-basedelay-row { display: flex !important; align-items: center !important; gap: 6px !important; }
      .su-pm-basedelay-lab { color: #65676b !important; font-size: 11.5px !important; font-weight: 600 !important; }
      .su-pm-mode {
        display: flex !important; align-items: flex-start !important; gap: 8px !important;
        padding: 7px 9px !important; border: 1px solid #e4e6eb !important; border-radius: 8px !important;
        background: #fff !important; cursor: pointer !important; transition: border-color .12s, background .12s !important;
      }
      .su-pm-mode:hover { background: #f0f2f5 !important; }
      .su-pm-mode input[type="radio"] {
        width: 15px !important; height: 15px !important; accent-color: #1877f2 !important;
        cursor: pointer !important; margin: 1px 0 0 !important; flex: 0 0 auto !important;
      }
      .su-pm-mode-body { display: flex !important; flex-direction: column !important; gap: 1px !important; min-width: 0 !important; }
      .su-pm-mode-t { color: #050505 !important; font-size: 12.5px !important; font-weight: 600 !important; display: flex !important; align-items: center !important; gap: 6px !important; flex-wrap: wrap !important; }
      .su-pm-mode-s { color: #65676b !important; font-size: 11.5px !important; font-weight: 400 !important; line-height: 1.3 !important; }
      .su-pm-mode-r { font-size: 11px !important; font-weight: 700 !important; padding: 1px 7px !important; border-radius: 999px !important; background: #e4e6eb !important; color: #050505 !important; white-space: nowrap !important; }
      /* Selected state; the range chip picks up the mode's own colour so the choice
         reads at a glance from across the card. */
      .su-pm-mode[data-on="1"] { border-color: #1877f2 !important; background: #f0f6ff !important; }
      /* data-mode="superfast" is the 🚀 Turbo card; data-mode="turbo" is ⚡ Human
         Lookalike. The keys are historical — see the DELAY_MODES comment in
         content_core.js before renaming anything here. */
      .su-pm-mode[data-on="1"][data-mode="superfast"] { border-color: #e8590c !important; background: #fff4ec !important; }
      .su-pm-mode[data-on="1"][data-mode="superfast"] .su-pm-mode-r { background: #ffd8bf !important; color: #a83c00 !important; }
      .su-pm-mode[data-on="1"][data-mode="turbo"] { border-color: #f0a500 !important; background: #fff8e1 !important; }
      .su-pm-mode[data-on="1"][data-mode="turbo"] .su-pm-mode-r { background: #ffe08a !important; color: #7a5b00 !important; }
      .su-pm-mode[data-on="1"][data-mode="safe"] { border-color: #42b72a !important; background: #f1faef !important; }
      .su-pm-mode[data-on="1"][data-mode="safe"] .su-pm-mode-r { background: #cdeec6 !important; color: #2a7d1d !important; }
      /* The base-delay row only means anything in "no randomization" mode — the other
         two replace it outright, so it dims rather than sitting there lying. */
      .su-pm-basedelay[data-off="1"] { opacity: .42 !important; pointer-events: none !important; }
      .su-pm-pill { font-size: 11px !important; font-weight: 700 !important; padding: 3px 9px !important; border-radius: 999px !important; letter-spacing: .2px !important; white-space: nowrap !important; }
      .su-pm-pill-superfast { background: #ffe3d1 !important; color: #a83c00 !important; }
      .su-pm-pill-fast { background: #fff3cd !important; color: #7a5b00 !important; }
      .su-pm-pill-balanced { background: #e7f3ff !important; color: #1877f2 !important; }
      .su-pm-pill-safe { background: #e3f7e0 !important; color: #2a7d1d !important; }

      /* ---- tab warning (one line) ---- */
      .su-pm-warn {
        display: flex !important; align-items: center !important; gap: 8px !important;
        background: #fff8e1 !important; border: 1px solid #ffe08a !important; border-radius: 10px !important;
        padding: 8px 11px !important; color: #7a5b00 !important; font-size: 12.5px !important; line-height: 1.35 !important;
      }
      .su-pm-warn b { font-weight: 700 !important; }

      /* ---- quick tip (v18.4) ----
         Sits directly under the tab warning because it answers the objection that
         warning raises ("so I have to sit and watch it?"). Blue, not amber: it must
         read as help, never as a second warning competing with the real one. */
      .su-pm-tip {
        display: flex !important; align-items: flex-start !important; gap: 8px !important;
        margin-top: 8px !important;
        background: #e7f3ff !important; border: 1px solid #cfe3ff !important; border-radius: 10px !important;
        padding: 8px 11px !important; color: #1c3d63 !important; font-size: 12.5px !important; line-height: 1.4 !important;
      }
      .su-pm-tip b { font-weight: 700 !important; }
      /* Opens YouTube in a new tab — never this one, which is mid-share-setup. */
      .su-pm-tip a {
        color: #1877f2 !important; font-weight: 700 !important; text-decoration: underline !important;
        white-space: nowrap !important; cursor: pointer !important;
      }
      .su-pm-tip a:hover { color: #166fe5 !important; }

      /* ---- footer ---- */
      .su-pm-foot {
        flex: 0 0 auto !important; display: flex !important; gap: 8px !important;
        padding: 12px 18px !important; border-top: 1px solid #e4e6eb !important; background: #fff !important;
      }
      .su-pm-btn {
        border: none !important; border-radius: 8px !important; padding: 11px 16px !important;
        font-size: 14.5px !important; font-weight: 600 !important; cursor: pointer !important;
        font-family: inherit !important; transition: background .15s, transform .12s, filter .15s !important;
        display: flex !important; align-items: center !important; justify-content: center !important; gap: 7px !important;
      }
      .su-pm-btn:active { transform: scale(.985) !important; }
      .su-pm-btn-ghost { background: #e4e6eb !important; color: #050505 !important; flex: 1 1 auto !important; }
      .su-pm-btn-ghost:hover { background: #d8dadf !important; }
      .su-pm-btn-icon { flex: 0 0 auto !important; padding: 11px 13px !important; font-size: 17px !important; }
      .su-pm-btn-primary {
        flex: 2 1 auto !important; color: #fff !important;
        background: linear-gradient(135deg, #1877f2 0%, #0a66d8 100%) !important;
        box-shadow: 0 2px 10px rgba(24,119,242,.32) !important;
      }
      .su-pm-btn-primary:hover { filter: brightness(1.07) !important; }

      /* template buttons injected later */
      .su-pm-mini-btn {
        background: #e4e6eb !important; border: none !important; color: #050505 !important;
        padding: 5px 11px !important; border-radius: 7px !important; font-size: 12.5px !important;
        font-weight: 600 !important; cursor: pointer !important; font-family: inherit !important;
        transition: background .15s !important;
      }
      .su-pm-mini-btn:hover { background: #d8dadf !important; }
      .su-pm-tmpl-btn { width: 100% !important; margin-top: 8px !important; }

      /* ---- AI variants (v17.9) ----
         The head button lives in .su-pm-field-head next to Apply Template; the
         bar below appears only while a set is applied, and its whole job is to
         make "your typed text is NOT what gets posted" impossible to miss. */
      .su-pm-ai-btn {
        background: linear-gradient(135deg, #1877f2 0%, #0a66d8 100%) !important;
        color: #fff !important; border: none !important; border-radius: 6px !important;
        padding: 5px 10px !important; font-size: 12px !important; font-weight: 700 !important;
        font-family: inherit !important; cursor: pointer !important;
        transition: filter .15s !important; white-space: nowrap !important;
      }
      .su-pm-ai-btn:hover { filter: brightness(1.08) !important; }
      .su-pm-field-actions { display: flex !important; align-items: center !important; gap: 6px !important; }

      .su-pm-varbar[hidden] { display: none !important; }
      .su-pm-varbar {
        margin-top: 8px !important; border: 1px solid #cfe3ff !important; background: #f2f8ff !important;
        border-radius: 10px !important; padding: 8px 10px !important;
      }
      .su-pm-varbar-head { display: flex !important; align-items: center !important; gap: 6px !important; }
      .su-pm-varbar-title { color: #050505 !important; font-size: 12.5px !important; font-weight: 700 !important; }
      .su-pm-varbar-note { color: #1877f2 !important; font-size: 11.5px !important; font-weight: 600 !important; }
      .su-pm-varbar-nav { display: flex !important; align-items: center !important; gap: 6px !important; margin-top: 7px !important; }
      .su-pm-varnav {
        width: 26px !important; height: 26px !important; flex: 0 0 auto !important;
        border: none !important; border-radius: 6px !important; background: #dfe9f7 !important;
        color: #1877f2 !important; font-size: 11px !important; font-weight: 700 !important;
        font-family: inherit !important; cursor: pointer !important; transition: background .15s !important;
      }
      .su-pm-varnav:hover { background: #cfe0f5 !important; }
      .su-pm-varidx { color: #65676b !important; font-size: 12px !important; font-weight: 600 !important; min-width: 54px !important; text-align: center !important; }
      .su-pm-varclear {
        border: none !important; border-radius: 6px !important; background: #e4e6eb !important;
        color: #050505 !important; padding: 5px 10px !important; font-size: 12px !important;
        font-weight: 600 !important; font-family: inherit !important; cursor: pointer !important;
        transition: background .15s !important; white-space: nowrap !important;
      }
      .su-pm-varclear:hover { background: #d8dadf !important; }
      /* Read-only while a variant is previewed: edits belong in the AI modal, so
         a stray keystroke here can't silently diverge from what will be posted. */
      #quick-share-post-content.su-pm-var-locked {
        background: #f2f8ff !important; border-color: #cfe3ff !important; cursor: default !important;
      }

      @media (max-height: 640px) {
        #quick-share-post-content { height: 64px !important; }
      }
    `;
    document.head.appendChild(s);
  }

  /**
   * Rough wall-clock estimate for a run, shown in the modal header.
   * PER_GROUP_WORK is the non-configurable part (reopen dialog → find group →
   * fill → post); the delay only applies BETWEEN groups, not after the last one.
   */
  function estimateRunSeconds(groupCount, delaySeconds, mode) {
    // Was 12 before v18.0, which removed ~7s of flat sleep per group (5s guessing that
    // the composer had opened + 2s more inside fillPostContent, both now replaced by
    // waitForComposerReady; and 5s guessing that the post had gone, now
    // waitForPostToLand). The deterministic sleeps left add up to ~8.5s.
    //
    // Set to 10, not 8.5: finding the group still costs a variable amount of
    // searching/scrolling that isn't in that sum, and over-estimating is the safe
    // direction — finishing early is a pleasant surprise, finishing late reads as a hang.
    //
    // TO RE-MEASURE properly: run a real share and read the `✅ Composer ready in Nms`
    // and `✅ Post landed in Nms` lines in the console, then set this from the medians.
    const PER_GROUP_WORK = 10;
    const n = Math.max(1, groupCount);
    return (n * PER_GROUP_WORK) + ((n - 1) * averageGapSeconds(delaySeconds, mode));
  }

  /**
   * Mean wait between groups for a pace mode (v18.0). Ranges come from
   * `Core.DELAY_MODES` so the estimate shown here and the wait the share loop
   * actually takes can never drift apart — if you retune a range, retune it there.
   * @param {number} delaySeconds - base delay, used by the 'off' mode only.
   * @param {string} mode - a DELAY_MODES key ('off' | 'turbo' | 'safe').
   */
  function averageGapSeconds(delaySeconds, mode) {
    const Core = window.ShareUnlimited && window.ShareUnlimited.Core;
    const range = Core && Core.DELAY_MODES && Core.DELAY_MODES[mode];
    if (range) return (range[0] + range[1]) / 2;
    return delaySeconds;
  }

  /**
   * Display name + pill tone per pace mode (v18.4), for the collapsed summary row
   * and the speed pill. Keys are DELAY_MODES keys — note that `turbo` is the 1–8s
   * "Human Lookalike" mode and `superfast` is the 0s "Turbo" one; the labels moved
   * in v18.4 and the keys deliberately did not. See DELAY_MODES in content_core.js.
   * `off` has no fixed tone: its pill follows the number the user picked.
   */
  const MODE_META = {
    off:       { name: 'No randomization',  tone: null },
    superfast: { name: '🚀 Turbo',           tone: 'superfast' },
    turbo:     { name: '⚡ Human Lookalike',  tone: 'fast' },
    safe:      { name: '🛡️ Safest',          tone: 'safe' }
  };

  // ---- remembered pace (v18.5) ---------------------------------------------
  // The pace is a workflow choice, not a per-post one: someone who shares to 200
  // groups on Turbo every morning wants Turbo every morning. Both the mode AND the
  // base delay are remembered, so "No randomization at 12s" comes back as 12s.
  //
  // Best-effort by design, exactly like `aiVariantSet`: every read and write is
  // swallowed. If storage is unavailable (invalidated extension context, quota,
  // a wiped profile) the modal silently opens on today's defaults — a remembered
  // preference must never be able to stop someone sharing.
  const PACE_PREFS_KEY = 'pacePrefs';
  const PACE_DEFAULTS = { delayMode: 'off', delaySeconds: 8 };
  // null = not read yet. Primed once at load so the SECOND and later opens apply
  // the saved pace synchronously, with no flip from "No randomization" to the
  // user's real setting a few ms after the modal paints.
  let pacePrefsCache = null;

  /**
   * Whatever comes out of storage is untrusted: it was written by an older version,
   * possibly naming a mode that no longer exists. Anything unrecognised falls back
   * to the shipped default rather than through to `resolveDelayGap`, where an
   * unknown key silently becomes the base delay and reads as "it ignored my setting".
   */
  function sanitizePacePrefs(raw) {
    const Core = window.ShareUnlimited && window.ShareUnlimited.Core;
    const modes = (Core && Core.DELAY_MODES) || null;
    const out = { delayMode: PACE_DEFAULTS.delayMode, delaySeconds: PACE_DEFAULTS.delaySeconds };
    if (raw && typeof raw === 'object') {
      const m = raw.delayMode;
      // 'off' is legitimate but has no range in DELAY_MODES (it maps to null), so it
      // is allowed explicitly; every other value must be a key the resolver knows.
      if (m === 'off' || (typeof m === 'string' && modes && modes[m])) out.delayMode = m;
      const d = parseInt(raw.delaySeconds, 10);
      if (!isNaN(d)) out.delaySeconds = Math.max(3, Math.min(100, d));
    }
    return out;
  }

  function loadPacePrefs(cb) {
    try {
      chrome.storage.local.get([PACE_PREFS_KEY], (res) => {
        let prefs;
        try {
          if (chrome.runtime.lastError) throw chrome.runtime.lastError;
          prefs = sanitizePacePrefs(res && res[PACE_PREFS_KEY]);
        } catch (e) {
          prefs = sanitizePacePrefs(null);
        }
        pacePrefsCache = prefs;
        try { if (cb) cb(prefs); } catch (e) { /* never let a caller break the modal */ }
      });
    } catch (e) {
      pacePrefsCache = sanitizePacePrefs(null);
      try { if (cb) cb(pacePrefsCache); } catch (e2) { /* swallowed */ }
    }
  }

  function savePacePrefs(delaySeconds, delayMode) {
    const prefs = sanitizePacePrefs({ delaySeconds, delayMode });
    pacePrefsCache = prefs;
    try { chrome.storage.local.set({ [PACE_PREFS_KEY]: prefs }, () => void chrome.runtime.lastError); }
    catch (e) { /* swallowed — the in-memory cache still serves this session */ }
  }

  // Prime the cache as soon as this file evaluates, long before any modal opens.
  loadPacePrefs(null);

  /**
   * The human-readable gap for a mode, rendered from `Core.DELAY_MODES` rather than
   * authored anywhere — same reason `averageGapSeconds` reads it: the chip a user
   * picks by and the wait the loop actually takes must not be able to drift apart.
   * A single-value range renders as one number ("0s"), not "0–0s".
   */
  function modeRangeText(delaySeconds, mode) {
    const Core = window.ShareUnlimited && window.ShareUnlimited.Core;
    const range = Core && Core.DELAY_MODES && Core.DELAY_MODES[mode];
    if (!range) return `${delaySeconds}s`;
    return range[0] === range[1] ? `${range[0]}s` : `${range[0]}–${range[1]}s`;
  }

  function formatDuration(totalSeconds) {
    if (totalSeconds < 90) return `≈ ${Math.round(totalSeconds / 5) * 5}s`;
    const mins = Math.round(totalSeconds / 60);
    if (mins < 60) return `≈ ${mins} min`;
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    return m ? `≈ ${h}h ${m}m` : `≈ ${h}h`;
  }

  /**
   * Shows the post content input modal
   */
  // `sourcePresetIds` (v17.0): when this share started from the preset chooser,
  // the preset ids ride along to the share call so a successful run can record
  // which profile those presets belong to. Passed through untouched, and null for
  // every other entry point (Quick Share, Search My Groups).
  // `initialVariations` (v17.9): an AI variant set already applied to this share.
  // Passed back in when the user returns here from the schedule flow so the set
  // survives the round trip.
  function showPostContentModal(selectedGroups, initialContent = '', sourcePresetIds = null, initialVariations = null) {
    const existing = document.getElementById('share-unlimited-post-modal');
    if (existing) existing.remove();
    
    ensurePostModalStyles();

    const groupCount = selectedGroups.length;
    const plural = groupCount === 1 ? '' : 's';

    const modal = document.createElement('div');
    modal.id = 'share-unlimited-post-modal';

    const modalContent = document.createElement('div');
    modalContent.className = 'su-pm-card-root';
    modalContent.setAttribute('role', 'dialog');
    modalContent.setAttribute('aria-modal', 'true');
    modalContent.setAttribute('aria-label', 'Share to multiple groups');

    // Layout note (v17.1): header and footer are fixed, only .su-pm-body scrolls,
    // so the card can never grow past the viewport no matter how many groups are
    // selected. Every long explanation moved into a (i) tooltip — see INFO_TIPS.
    let modalHTML = `
        <div class="su-pm-head">
            <div>
                <h2 class="su-pm-title">Share to Multiple Groups</h2>
                <div class="su-pm-sub"><b>${groupCount}</b> group${plural} · <span id="su-pm-eta">≈</span></div>
            </div>
            <button id="close-post-modal" class="su-pm-x" aria-label="Close">✕</button>
        </div>

        <div class="su-pm-body">

            <!-- Save as preset — one row. The sell copy lives in the (i) tooltip. -->
            <div id="save-preset-cta" class="su-pm-preset">
                <button id="save-group-list-preset" class="su-pm-preset-btn">
                    <span style="font-size:15px;">💾</span>
                    <span class="su-pm-grow" id="su-pm-preset-label">Save these ${groupCount} groups as a Preset</span>
                </button>
                <button class="su-pm-i su-pm-i-onblue su-pm-preset-i" data-su-tip="preset"
                        aria-label="What is a preset?">i</button>
            </div>

            <!-- Collapsed by default: the names are reassurance, not a decision the
                 user makes here, so they cost one line until asked for. -->
            <div class="su-pm-groups" id="su-pm-groups">
                <button class="su-pm-groups-head" id="su-pm-groups-toggle" aria-expanded="false" aria-controls="su-pm-groups-list">
                    <span class="su-pm-chev">▶</span>
                    <span class="su-pm-groups-count">${groupCount} group${plural}</span>
                    <span class="su-pm-groups-peek" id="su-pm-groups-peek"></span>
                </button>
                <div class="su-pm-groups-list" id="su-pm-groups-list" hidden></div>
            </div>

            <div>
                <div class="su-pm-field-head">
                    <label for="quick-share-post-content">Post text <span class="su-pm-opt">— optional</span></label>
                    <div class="su-pm-field-actions">
                        <button id="su-pm-ai-btn" class="su-pm-ai-btn" type="button">✨ AI Variants</button>
                        <div id="apply-template-container"></div>
                    </div>
                </div>
                <textarea id="quick-share-post-content" placeholder="What's on your mind?"></textarea>

                <!-- Shown only while an AI set is applied (v17.9). The textarea above
                     goes read-only and previews one variant at a time, so it is never
                     ambiguous which text actually gets posted. -->
                <div class="su-pm-varbar" id="su-pm-varbar" hidden>
                    <div class="su-pm-varbar-head">
                        <span class="su-pm-varbar-title">✨ <span id="su-pm-var-count">0</span> AI variants active</span>
                        <span class="su-pm-varbar-note" id="su-pm-var-rot"></span>
                        <button class="su-pm-i" data-su-tip="variants" aria-label="About AI variants">i</button>
                        <span class="su-pm-grow"></span>
                        <button id="su-pm-var-clear" class="su-pm-varclear" type="button">Remove</button>
                    </div>
                    <div class="su-pm-varbar-nav">
                        <button id="su-pm-var-prev" class="su-pm-varnav" type="button" aria-label="Previous variant">◀</button>
                        <span class="su-pm-varidx" id="su-pm-var-idx">1 / 1</span>
                        <button id="su-pm-var-next" class="su-pm-varnav" type="button" aria-label="Next variant">▶</button>
                        <span class="su-pm-grow"></span>
                        <span class="su-pm-opt">Preview — group 1 gets variant 1</span>
                    </div>
                </div>

                <div id="save-template-container"></div>
            </div>

            <!-- v18.4: the pace cards are collapsed behind a button. They were ~200px of
                 permanently-open UI for a decision made once, which pushed the visibility
                 warning and the quick tip off a laptop screen. The SUMMARY row directly
                 under the button always states the current choice, so nothing is hidden —
                 only the act of choosing is. Never ship the panel without the summary. -->
            <div class="su-pm-timing" id="su-pm-timing" data-pace-open="0">
                <button type="button" id="su-pm-pace-toggle" class="su-pm-pace-btn"
                        aria-expanded="false" aria-controls="su-pm-pace-panel">
                    <span style="flex:0 0 auto;">🏁</span>
                    <span class="su-pm-grow">Select Speed of Sharing</span>
                    <span class="su-pm-chev">▶</span>
                </button>

                <div class="su-pm-pace-sum">
                    <span class="su-pm-pill su-pm-pill-balanced" id="su-pm-speed">No randomization</span>
                    <span class="su-pm-pace-sum-tail" id="su-pm-pace-sum-tail">8s between groups</span>
                    <span class="su-pm-grow"></span>
                    <button class="su-pm-i" data-su-tip="delaymode" aria-label="About the pace">i</button>
                </div>

                <!-- v18.0: mutually exclusive pace modes replace the old "Randomize"
                     checkbox. A mode REPLACES the base delay rather than adding to it,
                     so the range on the chip is the wait the user gets.
                     v18.4: the two no-waiting modes share a 2-up row, and the 1–8s mode
                     is now labelled "Human Lookalike" — its VALUE is still "turbo", and
                     the new 0s mode's value is "superfast". Read the DELAY_MODES comment
                     in content_core.js before touching either string.
                     Every .su-pm-mode-r chip is filled from Core.DELAY_MODES at refresh
                     time, so the text below is a placeholder, not the source of truth. -->
                <div class="su-pm-pace-panel" id="su-pm-pace-panel" hidden>
                <div class="su-pm-modes" role="radiogroup" aria-label="Pace between groups">
                    <div class="su-pm-mode-pair">
                        <div class="su-pm-mode su-pm-mode-stack" data-mode="off">
                            <label class="su-pm-mode-hit">
                                <input type="radio" name="su-pm-delay-mode" value="off" checked>
                                <span class="su-pm-mode-body">
                                    <span class="su-pm-mode-t">No randomization <span class="su-pm-mode-r">8s</span></span>
                                    <span class="su-pm-mode-s">The same gap every time — set it here.</span>
                                </span>
                            </label>
                            <!-- Lives inside this card because it applies to this mode and
                                 no other; it dims (never disappears) in the other three. -->
                            <div class="su-pm-basedelay" id="su-pm-basedelay">
                                <input id="quick-share-delay-slider" type="range" min="3" max="100" value="8" step="1" aria-label="Delay between groups">
                                <div class="su-pm-basedelay-row">
                                    <span class="su-pm-basedelay-lab">Gap</span>
                                    <span class="su-pm-grow"></span>
                                    <input id="quick-share-delay-input" type="number" min="3" max="100" value="8" aria-label="Delay in seconds">
                                    <span class="su-pm-unit">sec</span>
                                    <button class="su-pm-i" data-su-tip="delay" aria-label="About the delay">i</button>
                                </div>
                            </div>
                        </div>
                        <label class="su-pm-mode" data-mode="superfast">
                            <input type="radio" name="su-pm-delay-mode" value="superfast">
                            <span class="su-pm-mode-body">
                                <span class="su-pm-mode-t">🚀 Turbo <span class="su-pm-mode-r">0s</span></span>
                                <span class="su-pm-mode-s">No gap at all. Use if your account regularly shares many posts to many groups.</span>
                            </span>
                        </label>
                    </div>
                    <label class="su-pm-mode" data-mode="turbo">
                        <input type="radio" name="su-pm-delay-mode" value="turbo">
                        <span class="su-pm-mode-body">
                            <span class="su-pm-mode-t">⚡ Human Lookalike <span class="su-pm-mode-r">1–8s</span></span>
                            <span class="su-pm-mode-s">Roughly the pace you'd share at by hand, with random gaps. Best on an established account, with the watermark off.</span>
                        </span>
                    </label>
                    <label class="su-pm-mode" data-mode="safe">
                        <input type="radio" name="su-pm-delay-mode" value="safe">
                        <span class="su-pm-mode-body">
                            <span class="su-pm-mode-t">🛡️ Safest <span class="su-pm-mode-r">15–45s</span></span>
                            <span class="su-pm-mode-s">Slower and more spread out. For newer accounts, or when you can just leave it running.</span>
                        </span>
                    </label>
                </div>
                </div>
            </div>

            <!-- Tab-visibility requirement. Facebook stops rendering and stops responding
                 to clicks in a hidden tab, so a backgrounded run can post to the wrong
                 group or the same group repeatedly. Kept visible here (before the user
                 commits) and again, live, in the progress overlay — only the long
                 explanation moved into the tooltip. -->
            <div class="su-pm-warn">
                <span style="flex:0 0 auto;">👁️</span>
                <span class="su-pm-grow"><b>Keep this tab on screen</b> until it finishes.</span>
                <button class="su-pm-i su-pm-i-warn" data-su-tip="tab" aria-label="Why this matters">i</button>
            </div>

            <!-- The warning above makes users think they have to sit and watch, which is
                 the #1 reason a big run gets abandoned. They don't — a SEPARATE WINDOW is
                 fine, because Chrome throttles on tab-hidden, not window-unfocused.
                 ⚠️ Word this as "its own window", never "in the background": a background
                 TAB is the v16.6 state where Facebook stops rendering and the loop posted
                 to the same group 5×. The distinction is the entire tip — don't blur it
                 for brevity. The link is a plain <a target="_blank">; FB's page CSP blocks
                 inline handlers in injected markup, so this must never become an onclick. -->
            <div class="su-pm-tip">
                <span style="flex:0 0 auto;">💡</span>
                <span class="su-pm-grow"><b>Quick tip!</b> Do other work while MGSA shares for you — put Facebook
                    in its own window and carry on in another one. Just don't switch to a different tab
                    <i>in this window</i>. <a href="https://youtu.be/LrzP0UKdUs0" target="_blank" rel="noopener noreferrer">See how</a></span>
            </div>
        </div>

        <div class="su-pm-foot">
            <button id="cancel-quick-share" class="su-pm-btn su-pm-btn-ghost">Cancel</button>
            <button id="schedule-quick-share" class="su-pm-btn su-pm-btn-ghost su-pm-btn-icon"
                    title="Schedule this share for later (BETA)" aria-label="Schedule for later">📅</button>
            <button id="confirm-quick-share" class="su-pm-btn su-pm-btn-primary">Share Now</button>
        </div>
    `;

    modalContent.innerHTML = modalHTML;

    // Group names are rendered with textContent, never interpolated into the HTML
    // above: names routinely contain &, <, quotes and RTL/bidi control marks.
    const groupsListEl = modalContent.querySelector('#su-pm-groups-list');
    const groupNames = selectedGroups.map((g) => String((g && g.name) || g || ''));
    groupNames.forEach((name, idx) => {
      const row = document.createElement('div');
      row.className = 'su-pm-group-row';
      const num = document.createElement('span');
      num.textContent = `${idx + 1}.`;
      const label = document.createElement('span');
      label.textContent = name;
      row.appendChild(num);
      row.appendChild(label);
      groupsListEl.appendChild(row);
    });
    const peekEl = modalContent.querySelector('#su-pm-groups-peek');
    peekEl.textContent = groupNames.slice(0, 3).join(' · ') +
      (groupNames.length > 3 ? ` +${groupNames.length - 3} more` : '');

    modal.appendChild(modalContent);
    document.body.appendChild(modal);
    wireInfoTips(modal);

    const textarea = modal.querySelector('#quick-share-post-content');
    const closeBtn = modal.querySelector('#close-post-modal');
    const cancelBtn = modal.querySelector('#cancel-quick-share');
    const scheduleBtn = modal.querySelector('#schedule-quick-share');
    const confirmBtn = modal.querySelector('#confirm-quick-share');
    const savePresetBtn = modal.querySelector('#save-group-list-preset');

    const closeModal = () => { hideInfoTip(); modal.remove(); };

    // Expand/collapse the group list
    const groupsWrap = modal.querySelector('#su-pm-groups');
    const groupsToggle = modal.querySelector('#su-pm-groups-toggle');
    groupsToggle.addEventListener('click', () => {
      const open = !groupsListEl.hidden;
      groupsListEl.hidden = open;
      groupsToggle.setAttribute('aria-expanded', String(!open));
      if (open) groupsWrap.removeAttribute('open-list');
      else groupsWrap.setAttribute('open-list', '');
      hideInfoTip();
    });

    // Delay slider ⟷ number input stay in sync (both clamp to 3–100s), and both
    // drive the speed pill + the ETA in the header.
    const delaySlider = modal.querySelector('#quick-share-delay-slider');
    const delayInput = modal.querySelector('#quick-share-delay-input');
    const modeRadios = Array.from(modal.querySelectorAll('input[name="su-pm-delay-mode"]'));
    const baseDelayWrap = modal.querySelector('#su-pm-basedelay');
    const speedPill = modal.querySelector('#su-pm-speed');
    const paceSumTail = modal.querySelector('#su-pm-pace-sum-tail');
    const timingWrap = modal.querySelector('#su-pm-timing');
    const paceToggle = modal.querySelector('#su-pm-pace-toggle');
    const pacePanel = modal.querySelector('#su-pm-pace-panel');
    const etaEl = modal.querySelector('#su-pm-eta');

    const readDelay = () => {
      const v = parseInt(delayInput.value, 10);
      return isNaN(v) ? 8 : Math.max(3, Math.min(100, v));
    };

    // Which pace mode is selected. Defaults to 'off' — the same behaviour the modal
    // has always had with the Randomize box unticked, so upgrading changes nobody's
    // timing until they choose to change it.
    const readMode = () => {
      const on = modeRadios.find((r) => r.checked);
      return on ? on.value : 'off';
    };

    // Only a real interaction writes a preference. Restoring a saved pace calls
    // refreshTiming() too, and without this that echo would re-save what we just
    // read — harmless, but it also means a failed/absent read can never overwrite
    // a good stored value with the defaults it fell back to.
    let userTouchedPace = false;
    let pacePersistTimer = null;
    const persistPaceSoon = (delay, mode) => {
      // Debounced: dragging the slider fires `input` on every pixel, and each one
      // would otherwise be a storage write.
      clearTimeout(pacePersistTimer);
      pacePersistTimer = setTimeout(() => savePacePrefs(delay, mode), 400);
    };

    const refreshTiming = () => {
      const delay = readDelay();
      const mode = readMode();

      // Selected-card highlight, and every range chip is (re)rendered from
      // Core.DELAY_MODES — only `off`'s tracks the slider, but going through one
      // code path means no chip can quietly disagree with the loop's actual wait.
      modeRadios.forEach((r) => {
        const card = r.closest('.su-pm-mode');
        card.setAttribute('data-on', r.checked ? '1' : '0');
        const chip = card.querySelector('.su-pm-mode-r');
        if (chip) chip.textContent = modeRangeText(delay, r.value);
      });
      // The base-delay controls dim (never vanish) in the three modes that ignore
      // them, rather than sitting there implying they still apply.
      baseDelayWrap.setAttribute('data-off', mode === 'off' ? '0' : '1');

      const effective = averageGapSeconds(delay, mode);

      // The pill doubles as the collapsed summary's name, so it says WHICH mode is
      // on. `off` is the one mode whose character depends on a number the user set,
      // so it keeps the old Fast/Balanced/Safe wording appended to its name.
      const meta = MODE_META[mode] || MODE_META.off;
      let tone = meta.tone;
      let word = meta.name;
      if (!tone) {
        tone = 'balanced';
        if (effective < 8) tone = 'fast';
        else if (effective >= 16) tone = 'safe';
      }
      speedPill.textContent = word;
      speedPill.className = `su-pm-pill su-pm-pill-${tone}`;
      paceSumTail.textContent = `${modeRangeText(delay, mode)} between groups`;

      etaEl.textContent = formatDuration(estimateRunSeconds(groupCount, delay, mode));

      // Whatever the user last chose becomes the default for the next share.
      if (userTouchedPace) persistPaceSoon(delay, mode);
    };

    // Open/close the pace panel. Collapsed by default: the summary above already
    // states the current choice, so the panel only has to exist while the user is
    // actually choosing.
    const setPaceOpen = (open) => {
      pacePanel.hidden = !open;
      paceToggle.setAttribute('aria-expanded', String(open));
      timingWrap.setAttribute('data-pace-open', open ? '1' : '0');
      hideInfoTip();
    };
    paceToggle.addEventListener('click', () => setPaceOpen(pacePanel.hidden));

    delaySlider.addEventListener('input', () => {
      userTouchedPace = true;
      delayInput.value = delaySlider.value;
      refreshTiming();
    });
    delayInput.addEventListener('input', () => {
      userTouchedPace = true;
      const v = parseInt(delayInput.value, 10);
      if (isNaN(v)) return; // let the user finish typing
      delaySlider.value = Math.max(3, Math.min(100, v));
      refreshTiming();
    });
    // Final clamp when the number field loses focus
    delayInput.addEventListener('blur', () => {
      userTouchedPace = true;
      const v = readDelay();
      delayInput.value = v;
      delaySlider.value = v;
      refreshTiming();
    });
    // Picking a mode collapses the panel — the choice is made, and the summary row
    // reports it. Deliberately on `change`, not `click`: dragging the slider inside
    // the "No randomization" card fires no change event, so the panel stays open
    // while the user tunes the number (it would otherwise slam shut under their
    // cursor), and re-clicking the already-selected card doesn't close it either.
    modeRadios.forEach((r) => r.addEventListener('change', () => {
      userTouchedPace = true;
      refreshTiming();
      setPaceOpen(false);
    }));

    // Restore the pace this user last chose (v18.5). Applied from the cache when it
    // is primed — which it is on every open after the first — so the modal paints
    // once, with their setting already on it, instead of flashing the default.
    const applyPacePrefs = (prefs) => {
      // A slow first read must never yank a control out from under someone who has
      // already started setting the pace by hand.
      if (userTouchedPace || !modal.isConnected) return;
      const radio = modeRadios.find((r) => r.value === prefs.delayMode);
      if (radio) radio.checked = true;
      delayInput.value = prefs.delaySeconds;
      delaySlider.value = prefs.delaySeconds;
      refreshTiming();
    };
    if (pacePrefsCache) applyPacePrefs(pacePrefsCache);
    else loadPacePrefs(applyPacePrefs);

    refreshTiming();

    // Hover states are CSS (:hover) now — no JS hover handlers to keep in sync.
    closeBtn.addEventListener('click', closeModal);
    cancelBtn.addEventListener('click', closeModal);

    scheduleBtn.addEventListener('click', () => {
        closeModal();
        // Pace rides along to the schedule chain for the same reason the variant array
        // does — the user set it here, and re-deriving it downstream is how the two
        // paths drift apart.
        showScheduleDisclaimerModal(selectedGroups, readDraft(), sourcePresetIds,
          readVariations(), readDelay(), readMode());
    });

    confirmBtn.addEventListener('click', async () => {
        // With a variant set applied the textarea is only a preview, so the text
        // to share comes from the set — variant 1 as the base content, the whole
        // array as the rotation. Allow empty post content either way.
        const variations = readVariations();
        const postContent = variations ? variations[0] : textarea.value.trim();

        // Base delay (3–100s, default 8) plus the pace mode. The 6th arg takes a
        // DELAY_MODES string from this surface; every other caller still passes a
        // boolean and still gets the legacy behaviour (see resolveDelayGap).
        const delaySeconds = readDelay();
        const delayMode = readMode();

        closeModal();
        if (window.ShareUnlimited.Core && window.ShareUnlimited.Core.shareToSelectedGroups) {
          await window.ShareUnlimited.Core.shareToSelectedGroups(
            selectedGroups, postContent, variations, null, delaySeconds, delayMode, null, null, sourcePresetIds);
        }
    });

    // Save Group List Preset button
    if (savePresetBtn) {
      savePresetBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          hideInfoTip();
          showSaveGroupListPresetDialog(selectedGroups);
      });
    }

    // Esc closes the modal (tooltip first, if one is open)
    const onKeyDown = (e) => {
      if (e.key !== 'Escape') return;
      if (tipOwner && modal.contains(tipOwner)) { hideInfoTip(); return; }
      if (!modal.isConnected) { document.removeEventListener('keydown', onKeyDown, true); return; }
      e.stopPropagation();
      closeModal();
      document.removeEventListener('keydown', onKeyDown, true);
    };
    document.addEventListener('keydown', onKeyDown, true);

    // Check if user has post templates to conditionally show Apply Template button
    chrome.storage.local.get(['postTemplates'], (result) => {
        const postTemplates = result.postTemplates || {};
        const hasTemplates = Object.keys(postTemplates).length > 0;
        
        const applyTemplateContainer = modal.querySelector('#apply-template-container');
        if (hasTemplates && applyTemplateContainer) {
            const applyTemplateBtn = document.createElement('button');
            applyTemplateBtn.id = 'apply-post-template-btn';
            applyTemplateBtn.className = 'su-pm-mini-btn';
            applyTemplateBtn.textContent = '📖 Apply Template';
            applyTemplateBtn.addEventListener('click', () => {
                showApplyPostTemplateDialog(textarea);
            });
            applyTemplateContainer.appendChild(applyTemplateBtn);
        }
    });
    
    // Monitor textarea for text to conditionally show Save Template button
    const saveTemplateContainer = modal.querySelector('#save-template-container');
    let savePostTemplateBtn = null;
    
    const updateSaveTemplateButton = () => {
        const hasText = textarea.value.trim().length > 0;
        
        if (hasText && !savePostTemplateBtn) {
            // Create the button
            savePostTemplateBtn = document.createElement('button');
            savePostTemplateBtn.id = 'save-post-template';
            savePostTemplateBtn.className = 'su-pm-mini-btn su-pm-tmpl-btn';
            savePostTemplateBtn.textContent = '📝 Save as Post Template';
            savePostTemplateBtn.style.opacity = '0';
            savePostTemplateBtn.style.transform = 'translateY(-8px)';
            savePostTemplateBtn.style.transition = 'opacity .2s, transform .2s, background .15s';
            savePostTemplateBtn.addEventListener('click', () => {
                const postContent = textarea.value.trim();
                if (!postContent) {
                    alert('Please enter some post content before saving as a template!');
                    return;
                }
                showSavePostTemplateDialog(postContent);
            });
            saveTemplateContainer.appendChild(savePostTemplateBtn);
            
            // Animate in
            setTimeout(() => {
                savePostTemplateBtn.style.opacity = '1';
                savePostTemplateBtn.style.transform = 'translateY(0)';
            }, 10);
        } else if (!hasText && savePostTemplateBtn) {
            // Remove the button
            savePostTemplateBtn.style.opacity = '0';
            savePostTemplateBtn.style.transform = 'translateY(-10px)';
            setTimeout(() => {
                if (savePostTemplateBtn && savePostTemplateBtn.parentNode) {
                    savePostTemplateBtn.remove();
                }
                savePostTemplateBtn = null;
            }, 200);
        }
    };
    
    // Monitor textarea changes
    textarea.addEventListener('input', updateSaveTemplateButton);
    textarea.addEventListener('keyup', updateSaveTemplateButton);
    textarea.addEventListener('paste', () => setTimeout(updateSaveTemplateButton, 10));

    wireBackdropDismiss(modal, () => closeModal());

    // Initial check for save template button visibility
    updateSaveTemplateButton();

    if (initialContent) {
      textarea.value = initialContent;
      updateSaveTemplateButton();
    }

    // ------------------------------------------------------------------
    // AI variants (v17.9)
    //
    // `shareToSelectedGroups` already rotates postVariations by group index
    // (`i % length`), so nothing here schedules anything — this only decides
    // WHICH array gets handed over, and makes the state legible.
    //
    // The rule that keeps it unambiguous: while a set is applied the textarea
    // is a read-only preview of one variant. There is never a moment where the
    // user's typing and the text that will be posted can disagree.
    // ------------------------------------------------------------------
    const aiBtn = modal.querySelector('#su-pm-ai-btn');
    const varBar = modal.querySelector('#su-pm-varbar');
    const varCountEl = modal.querySelector('#su-pm-var-count');
    const varRotEl = modal.querySelector('#su-pm-var-rot');
    const varIdxEl = modal.querySelector('#su-pm-var-idx');
    const varPrevBtn = modal.querySelector('#su-pm-var-prev');
    const varNextBtn = modal.querySelector('#su-pm-var-next');
    const varClearBtn = modal.querySelector('#su-pm-var-clear');

    let activeVariations = Array.isArray(initialVariations) && initialVariations.length
      ? initialVariations.slice()
      : null;
    let previewIdx = 0;
    let manualDraft = textarea.value;   // what the user typed before variants took over

    // Hoisted on purpose: the Share Now / Schedule handlers above call these.
    function readVariations() {
      return activeVariations && activeVariations.length ? activeVariations.slice() : null;
    }
    function readDraft() {
      return activeVariations ? manualDraft.trim() : textarea.value.trim();
    }

    function renderVariantState() {
      const on = !!(activeVariations && activeVariations.length);
      varBar.hidden = !on;
      textarea.readOnly = on;
      textarea.classList.toggle('su-pm-var-locked', on);
      aiBtn.textContent = on ? `✨ Edit ${activeVariations.length} variants` : '✨ AI Variants';

      // Applying a template would write into a read-only preview and be silently
      // discarded on the next nav click, so that path is hidden while a set is on.
      // (The container is created up-front; the button inside it arrives async.)
      const tmplContainer = modal.querySelector('#apply-template-container');
      if (tmplContainer) tmplContainer.style.display = on ? 'none' : '';

      if (!on) {
        textarea.placeholder = "What's on your mind?";
        return;
      }

      previewIdx = ((previewIdx % activeVariations.length) + activeVariations.length) % activeVariations.length;
      textarea.value = activeVariations[previewIdx];
      varCountEl.textContent = String(activeVariations.length);
      varIdxEl.textContent = `${previewIdx + 1} / ${activeVariations.length}`;
      const AI = window.ShareUnlimited.AIVariants;
      varRotEl.textContent = AI ? `· ${AI.rotationSummary(groupCount, activeVariations.length)}` : '';
      const single = activeVariations.length === 1;
      varPrevBtn.disabled = single;
      varNextBtn.disabled = single;
      updateSaveTemplateButton();
    }

    const openAiModal = () => {
      const AI = window.ShareUnlimited.AIVariants;
      if (!AI || !AI.showAiVariantsModal) {
        alert('AI variants are unavailable — reload the extension and refresh this tab.');
        return;
      }
      hideInfoTip();
      AI.showAiVariantsModal({
        // Seed from whatever they typed; when a set is applied their original
        // draft is the seed, not the variant currently on screen.
        seedText: activeVariations ? manualDraft : textarea.value.trim(),
        groupCount,
        existing: activeVariations,
        onApply: (variants) => {
          if (!activeVariations) manualDraft = textarea.value;
          activeVariations = variants.slice();
          previewIdx = 0;
          renderVariantState();
        }
      });
    };

    aiBtn.addEventListener('click', openAiModal);

    varPrevBtn.addEventListener('click', () => { previewIdx -= 1; renderVariantState(); });
    varNextBtn.addEventListener('click', () => { previewIdx += 1; renderVariantState(); });
    varClearBtn.addEventListener('click', () => {
      activeVariations = null;
      previewIdx = 0;
      textarea.value = manualDraft;
      renderVariantState();
      updateSaveTemplateButton();
      textarea.focus();
    });

    renderVariantState();
    if (!activeVariations) textarea.focus();
  }

  /**
   * PRESET → PROFILE RESOLUTION (v17.0)
   *
   * Works out which Facebook profile each saved preset belongs to, so the
   * chooser can say which presets actually apply to the profile in use. Group
   * membership is per profile: applying profile A's preset while on profile B
   * means most of its groups simply aren't there.
   *
   * Two sources, in priority order:
   *   1. STAMPED — preset.profileId, written at save time. Authoritative.
   *   2. INFERRED — presets saved before v17.0 have no stamp, so they're matched
   *      against each profile's group inventory (chrome.storage `groupInventory`
   *      is already keyed per profile). A profile only wins if it covers ≥60% of
   *      the preset's groups AND beats every other profile outright — a tie means
   *      the profiles share these groups, which tells the user nothing, so it
   *      stays "not recorded" rather than guessing. Inferred results are labelled
   *      as guesses in the UI and never written back to storage: the inventory
   *      changes as the user joins/leaves groups, so freezing a guess would turn
   *      a soft hint into a wrong fact.
   *
   * Returns { current, resolved } where `resolved` maps preset.id →
   * { id, name, inferred, isCurrent }.
   */
  async function resolvePresetProfiles(presets) {
    const Core = window.ShareUnlimited.Core;
    const current = (Core && Core.Profile)
      ? Core.Profile.getActive()
      : { id: null, name: null };
    const directory = (Core && Core.Profile) ? await Core.Profile.getDirectory() : {};
    const norm = (Core && Core.normalizeGroupNameForMatch)
      ? Core.normalizeGroupNameForMatch
      : (s => String(s).trim().toLowerCase());

    const stored = await new Promise(res => chrome.storage.local.get(['groupInventory'], res));
    const inventories = Object.entries(stored.groupInventory || {})
      // 'unknown' is Inventory's bucket for pages where the cookie couldn't be
      // read — it isn't a profile, so it must never win an inference.
      .filter(([id]) => id && id !== 'unknown')
      .map(([id, entry]) => ({
        id,
        names: new Set(Object.values((entry && entry.groups) || {}).map(norm))
      }))
      .filter(inv => inv.names.size > 0);

    // Prefer the live name for the active profile, then the recorded directory,
    // then whatever was stamped on the preset itself (covers a profile that has
    // never been seen since the directory was introduced).
    const nameFor = (id, stamped) =>
      (id && current.id === id && current.name) ||
      (id && directory[id] && directory[id].name) ||
      stamped ||
      (Core && Core.Profile ? Core.Profile.fallbackLabel(id) : null);

    const resolved = new Map();
    presets.forEach(preset => {
      const names = (preset.groups || []).map(g => norm((g && g.name) || g)).filter(Boolean);
      let id = preset.profileId || null;
      let inferred = false;

      if (!id && names.length && inventories.length) {
        const scored = inventories
          .map(inv => ({ id: inv.id, hits: names.filter(n => inv.names.has(n)).length }))
          .sort((a, b) => b.hits - a.hits);
        const best = scored[0];
        const runnerUp = scored[1] ? scored[1].hits : -1;
        if (best && best.hits > runnerUp && best.hits / names.length >= 0.6) {
          id = best.id;
          inferred = true;
        }
      }

      resolved.set(preset.id, {
        id,
        name: id ? nameFor(id, preset.profileName) : (preset.profileName || null),
        inferred,
        isCurrent: !!(id && current.id && id === current.id)
      });
    });

    return { current, resolved };
  }

  /**
   * Shows Group Presets modal directly on Facebook for selecting and applying presets
   */
  async function showGroupPresetsModal() {
    const existing = document.getElementById('share-unlimited-group-presets-modal');
    if (existing) existing.remove();
    
    const result = await new Promise(resolve => {
      chrome.storage.local.get(['groupPresets'], resolve);
    });
    
    const presets = result.groupPresets || [];

    // Newest first — preset.id is Date.now() at creation, createdAt an ISO string.
    presets.sort((a, b) =>
      (new Date(b.createdAt || 0) - new Date(a.createdAt || 0)) ||
      ((Number(b.id) || 0) - (Number(a.id) || 0)));

    // Group refs per preset, with IDs recovered for pre-v18.2 name-only entries so
    // a legacy preset listing the same name twice still reaches BOTH groups.
    const resolveRefs = await buildPresetRefResolver();
    const refsByPreset = new Map(presets.map(p => [p.id, resolveRefs(p)]));

    // Which profile each preset belongs to, and which profile we're on (v17.0).
    const { current: currentProfile, resolved: presetProfiles } =
      await resolvePresetProfiles(presets);

    // Styles: custom checkbox (FB's dark-mode CSS makes the native input render as
    // a black square), rounded pills, and slim scrollbars.
    if (!document.getElementById('su-preset-styles')) {
      const st = document.createElement('style');
      st.id = 'su-preset-styles';
      st.textContent = `
        .su-preset-cb {
          appearance: none !important; -webkit-appearance: none !important;
          width: 22px !important; height: 22px !important; margin: 0 !important;
          border: 2px solid #ced0d4 !important; border-radius: 6px !important;
          background: #fff !important; cursor: pointer !important; flex-shrink: 0 !important;
          position: relative !important; display: inline-block !important;
          transition: background 0.15s, border-color 0.15s, transform 0.1s !important;
        }
        .su-preset-cb:hover { border-color: #1877f2 !important; }
        .su-preset-cb:checked { background: #1877f2 !important; border-color: #1877f2 !important; }
        .su-preset-cb:checked::after {
          content: ''; position: absolute; left: 6px; top: 2px;
          width: 5px; height: 10px; border: solid #fff;
          border-width: 0 2.5px 2.5px 0; transform: rotate(45deg);
        }
        .su-preset-pill {
          display: inline-block; background: #f3f4f6; color: #374151;
          border: none; padding: 4px 11px;
          border-radius: 50px; margin: 3px 4px 3px 0; font-size: 13px; font-weight: 500;
          max-width: 100%; overflow: hidden; text-overflow: ellipsis;
          white-space: nowrap; vertical-align: middle; box-sizing: border-box;
        }
        .su-more-chip {
          display: inline-block; background: transparent; color: #1877f2;
          border: 1px dashed rgba(24,119,242,0.4); padding: 3px 11px;
          border-radius: 50px; margin: 3px 4px 3px 0; font-size: 13px; font-weight: 600;
          cursor: pointer; vertical-align: middle; transition: background 0.15s;
        }
        .su-more-chip:hover { background: #e7f3ff; }
        .su-hidden-chip { display: none; }
        .su-count-badge {
          display: inline-flex; align-items: center; gap: 5px;
          background: #f3f4f6; color: #4b5563; font-size: 12px; font-weight: 600;
          padding: 3px 9px; border-radius: 50px; flex-shrink: 0;
        }
        /* Profile ownership chip — which FB profile a preset belongs to (v17.0).
           Green = the profile you're on, amber = a different one, grey = unknown.
           Dashed = inferred from the group inventory rather than recorded. */
        .su-profile-chip {
          display: inline-flex; align-items: center; gap: 5px;
          font-size: 12px; font-weight: 600;
          padding: 3px 10px; border-radius: 50px;
          border: 1px solid transparent; flex-shrink: 0;
          max-width: 190px; min-width: 0;
        }
        .su-profile-chip .su-profile-name {
          overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
        }
        .su-profile-current { background: #e3f5e8; color: #1a7f37; }
        .su-profile-other   { background: #fff4e5; color: #b26a00; }
        .su-profile-unknown { background: #f3f4f6; color: #9ca3af; }
        .su-profile-guess   { background: transparent; border-color: currentColor; border-style: dashed; }
        .delete-preset-btn { opacity: 0; }
        .preset-card:hover .delete-preset-btn { opacity: 1; }
        .delete-preset-btn.su-armed { opacity: 1 !important; }
        .su-slim-scroll { scrollbar-width: thin; scrollbar-color: #c8ccd3 transparent; }
        .su-slim-scroll::-webkit-scrollbar { width: 8px; }
        .su-slim-scroll::-webkit-scrollbar-track { background: transparent; }
        .su-slim-scroll::-webkit-scrollbar-thumb {
          background: #c8ccd3; border-radius: 8px;
          border: 2px solid transparent; background-clip: content-box;
        }
        .su-slim-scroll::-webkit-scrollbar-thumb:hover { background: #a9adb4; background-clip: content-box; border: 2px solid transparent; }
      `;
      document.head.appendChild(st);
    }
    // Lucide-style inline SVG icons — consistent set instead of mixed emoji.
    const iconSvg = (name, size = 16, color = '#6b7280') => {
      const paths = {
        layers: '<path d="M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z"/><path d="m22 17.65-9.17 4.16a2 2 0 0 1-1.66 0L2 17.65"/><path d="m22 12.65-9.17 4.16a2 2 0 0 1-1.66 0L2 12.65"/>',
        users: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
        zap: '<path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"/>',
        trash: '<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/>',
        user: '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
        userCheck: '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><polyline points="16 11 18 13 22 9"/>'
      };
      return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;flex-shrink:0;display:inline-block;">${paths[name] || ''}</svg>`;
    };

    /**
     * The profile-ownership chip shown top-right of a preset card. Colour is the
     * answer to "does this preset work on the profile I'm on right now?" — green
     * yes, amber no, grey unknown. The tooltip spells it out for each case; the
     * chip is decoration only, so it never intercepts the card's click-to-select.
     */
    const profileChipHtml = (info) => {
      const knowCurrent = !!currentProfile.id;
      const here = currentProfile.name || 'this profile';

      let cls, label, icon, title;
      if (!info || !info.id) {
        cls = 'su-profile-unknown';
        icon = 'user';
        label = 'Profile not recorded';
        title = "This preset was saved before profiles were tracked, and its groups don't clearly match any profile you've loaded groups for. Run Load All on a profile to identify it.";
      } else if (!knowCurrent) {
        cls = 'su-profile-unknown';
        icon = 'user';
        label = info.name;
        title = `Saved on ${info.name}. Couldn't read which profile you're on right now.`;
      } else if (info.isCurrent) {
        cls = 'su-profile-current';
        icon = 'userCheck';
        label = info.name;
        title = info.inferred
          ? `Its groups match ${here} — the profile you're on. Best guess: this preset wasn't stamped with a profile when it was saved.`
          : `Saved on ${info.name} — the profile you're on. These groups are available.`;
      } else {
        cls = 'su-profile-other';
        icon = 'user';
        label = info.name;
        title = info.inferred
          ? `Its groups look like ${info.name}, not ${here}. Best guess — this preset wasn't stamped with a profile when it was saved. Most of its groups probably aren't reachable from here.`
          : `Saved on ${info.name}, not ${here}. Most of its groups won't be reachable from the profile you're on.`;
      }

      const guess = info && info.inferred ? ' su-profile-guess' : '';
      const text = info && info.inferred ? `Likely ${label}` : label;
      return `<span class="su-profile-chip ${cls}${guess}" title="${escHtml(title)}">`
        + `${iconSvg(icon, 12, 'currentColor')}`
        + `<span class="su-profile-name">${escHtml(text)}</span></span>`;
    };

    const modal = document.createElement('div');
    modal.id = 'share-unlimited-group-presets-modal';
    modal.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      z-index: 99999999;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    `;

    const modalContent = document.createElement('div');
    modalContent.className = 'su-slim-scroll';
    modalContent.style.cssText = `
      background: white;
      border-radius: 12px;
      padding: 24px;
      max-width: 600px;
      max-height: 80vh;
      overflow-y: auto;
      box-shadow: 0 12px 40px rgba(0, 0, 0, 0.3);
    `;
    
    const header = document.createElement('div');
    header.style.cssText = `
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
    `;
    
    const title = document.createElement('h2');
    title.innerHTML = `${iconSvg('layers', 20, '#374151')} <span style="vertical-align:middle;">Group Presets</span>`;
    title.style.cssText = `
      color: #050505;
      margin: 0;
      font-size: 20px;
      font-weight: 700;
      display: flex;
      align-items: center;
      gap: 8px;
    `;

    const closeBtn = document.createElement('button');
    closeBtn.textContent = '✕';
    closeBtn.style.cssText = `
      background: #f0f2f5;
      border: none;
      color: #65676b;
      font-size: 18px;
      width: 36px;
      height: 36px;
      border-radius: 50%;
      cursor: pointer;
      transition: all 0.2s;
    `;
    closeBtn.addEventListener('mouseenter', () => { closeBtn.style.background = '#d8dadf'; });
    closeBtn.addEventListener('mouseleave', () => { closeBtn.style.background = '#f0f2f5'; });
    closeBtn.addEventListener('click', () => modal.remove());
    
    header.appendChild(title);

    // Top right: the profile you're on. Every card's chip is read against this,
    // so without it the per-preset colours would mean nothing.
    const headerRight = document.createElement('div');
    headerRight.style.cssText = 'display: flex; align-items: center; gap: 10px; min-width: 0;';
    if (currentProfile.id) {
      const youChip = document.createElement('div');
      youChip.style.cssText = 'display: flex; align-items: center; gap: 6px; min-width: 0; color: #65676b; font-size: 13px;';
      const youLabel = currentProfile.name
        || (window.ShareUnlimited.Core.Profile.fallbackLabel(currentProfile.id));
      youChip.innerHTML = `<span style="flex-shrink:0;">${iconSvg('user', 14, '#6b7280')}</span>`
        + `<span style="color:#050505;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${escHtml(youLabel)}</span>`;
      youChip.title = "The Facebook profile you're currently using. Each preset is matched against it.";
      headerRight.appendChild(youChip);
    }
    headerRight.appendChild(closeBtn);
    header.appendChild(headerRight);
    modalContent.appendChild(header);

    // Info banner
    const infoBanner = document.createElement('div');
    infoBanner.style.cssText = `
      background: #e7f3ff;
      border: 1px solid #1877f2;
      border-radius: 10px;
      padding: 12px 14px;
      margin-bottom: 18px;
      display: flex;
      gap: 10px;
      align-items: flex-start;
    `;
    infoBanner.innerHTML = `
      <span style="flex-shrink: 0; margin-top: 2px;">${iconSvg('zap', 16, '#6b7280')}</span>
      <div style="color: #65676b; font-size: 13px; line-height: 1.6;">
        Pick one or more presets — your post goes to every <strong style="color: #050505;">unique group</strong> across them. No duplicates, ever.
      </div>
    `;
    modalContent.appendChild(infoBanner);

    // Only warn when there's actually something to warn about — a user with one
    // profile should never see profile chatter.
    const offProfileCount = presets.filter(p => {
      const info = presetProfiles.get(p.id);
      return info && info.id && !info.isCurrent;
    }).length;
    if (currentProfile.id && offProfileCount > 0) {
      const notice = document.createElement('div');
      notice.style.cssText = `
        display: flex; gap: 8px; align-items: flex-start;
        margin: -8px 0 16px; padding: 0 2px;
        color: #b26a00; font-size: 12px; line-height: 1.5;
      `;
      notice.innerHTML = `<span style="flex-shrink:0;margin-top:1px;">${iconSvg('user', 13, '#b26a00')}</span>`
        + `<div>${offProfileCount} preset${offProfileCount === 1 ? ' was' : 's were'} saved on a different profile `
        + `(marked in amber). Groups aren't shared between profiles, so most of those groups won't be reachable from here.</div>`;
      modalContent.appendChild(notice);
    }

    if (presets.length === 0) {
      const emptyState = document.createElement('div');
      emptyState.style.cssText = `
        text-align: center;
        padding: 40px 20px;
        color: #050505;
      `;
      emptyState.innerHTML = `
        <div style="font-size: 48px; margin-bottom: 16px;">📭</div>
        <p style="font-size: 18px; margin-bottom: 8px;">No Group Presets Yet</p>
        <p style="opacity: 0.8;">Create presets from the extension popup to use them here!</p>
      `;
      modalContent.appendChild(emptyState);
    } else {
      // Container for preset cards
      const presetsContainer = document.createElement('div');
      presetsContainer.id = 'presets-container';
      
      presets.forEach(preset => {
        const card = document.createElement('div');
        card.className = 'preset-card';
        card.style.cssText = `
          background: #f0f2f5;
          border-radius: 12px;
          padding: 16px;
          margin-bottom: 12px;
          transition: all 0.2s;
          cursor: pointer;
        `;
        card.addEventListener('mouseenter', () => {
          card.style.background = '#e4e6eb';
          card.style.transform = 'translateY(-2px)';
        });
        card.addEventListener('mouseleave', () => {
          card.style.background = '#f0f2f5';
          card.style.transform = 'translateY(0)';
        });
        
        const createdDate = new Date(preset.createdAt).toLocaleDateString();
        
        const MAX_CHIPS = 6;
        const hiddenCount = Math.max(0, preset.groups.length - MAX_CHIPS);
        const profileInfo = presetProfiles.get(preset.id);
        card.innerHTML = `
          <div style="display: flex; align-items: center; gap: 12px;">
            <input type="checkbox" class="preset-checkbox su-preset-cb" data-preset-id="${preset.id}">
            ${iconSvg('layers', 16, '#6b7280')}
            <span style="color: #050505; font-size: 16px; font-weight: 600; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; flex: 0 1 auto; min-width: 0;">${escHtml(preset.name)}</span>
            <span class="su-count-badge">${iconSvg('users', 12, '#6b7280')}${preset.groups.length} group${preset.groups.length > 1 ? 's' : ''}</span>
            <span style="flex: 1 1 8px; min-width: 8px;"></span>
            ${profileChipHtml(profileInfo)}
            <button class="delete-preset-btn" data-preset-id="${preset.id}" title="Delete preset" style="
              background: transparent;
              border: none;
              width: 32px;
              height: 32px;
              border-radius: 8px;
              cursor: pointer;
              display: flex;
              align-items: center;
              justify-content: center;
              flex-shrink: 0;
              transition: all 0.15s;
            ">${iconSvg('trash', 16, '#6b7280')}</button>
          </div>
          <div style="margin: 4px 0 8px 34px; color: #9ca3af; font-size: 12px;">Created ${createdDate}</div>
          <div class="su-chips-wrap" style="margin-left: 34px;">
            ${preset.groups.map((g, gi) =>
              `<span class="su-preset-pill${gi >= MAX_CHIPS ? ' su-hidden-chip' : ''}">${escHtml((g && g.name) || g)}</span>`).join('')}
            ${hiddenCount ? `<span class="su-more-chip" role="button">+${hiddenCount} more</span>` : ''}
          </div>
        `;
        
        presetsContainer.appendChild(card);
        
        // Get the checkbox after it's added to DOM
        const checkbox = card.querySelector('.preset-checkbox');
        
        // Make the card clickable to toggle checkbox, but not the checkbox itself
        card.addEventListener('click', (e) => {
          // Only toggle if we didn't click directly on the checkbox
          if (e.target !== checkbox) {
            e.preventDefault();
            e.stopPropagation();
            checkbox.checked = !checkbox.checked;
            // Manually trigger the change event
            const event = new Event('change', { bubbles: true });
            checkbox.dispatchEvent(event);
          }
        });
        
        // Prevent checkbox clicks from bubbling to card
        checkbox.addEventListener('click', (e) => {
          e.stopPropagation();
        });

        // "+N more" chip expands the full group list inline (replaces the old
        // nested scrollbar). stopPropagation so it doesn't toggle the card.
        const moreChip = card.querySelector('.su-more-chip');
        if (moreChip) {
          moreChip.addEventListener('click', (e) => {
            e.stopPropagation();
            card.querySelectorAll('.su-hidden-chip').forEach(el => el.classList.remove('su-hidden-chip'));
            moreChip.remove();
          });
        }
      });
      
      modalContent.appendChild(presetsContainer);

      // Sticky footer: live primary CTA (dedup count updates as presets are
      // checked) + secondary Cancel. Sticks to the bottom of the scrolling modal.
      const footer = document.createElement('div');
      footer.style.cssText = `
        position: sticky;
        bottom: 0;
        background: white;
        margin-top: 8px;
        padding: 12px 0 0;
        border-top: 1px solid #e4e6eb;
        display: flex;
        gap: 8px;
      `;

      const cancelBtn = document.createElement('button');
      cancelBtn.textContent = 'Cancel';
      cancelBtn.style.cssText = `
        background: #e4e6eb;
        border: none;
        color: #050505;
        padding: 12px 20px;
        border-radius: 8px;
        font-size: 15px;
        font-weight: 600;
        cursor: pointer;
        transition: background 0.15s;
        flex-shrink: 0;
      `;
      cancelBtn.addEventListener('mouseenter', () => cancelBtn.style.background = '#d8dadf');
      cancelBtn.addEventListener('mouseleave', () => cancelBtn.style.background = '#e4e6eb');
      cancelBtn.addEventListener('click', () => modal.remove());

      const multiSelectBtn = document.createElement('button');
      multiSelectBtn.id = 'multi-preset-share-btn';
      multiSelectBtn.style.cssText = `
        flex: 1;
        background: #e4e6eb;
        border: none;
        color: #90949c;
        padding: 12px 20px;
        border-radius: 8px;
        font-size: 15px;
        font-weight: 700;
        cursor: not-allowed;
        transition: background 0.2s, color 0.2s;
      `;
      multiSelectBtn.textContent = 'Select at least one preset';
      multiSelectBtn.disabled = true;

      footer.appendChild(cancelBtn);
      footer.appendChild(multiSelectBtn);
      modalContent.appendChild(footer);
    }
    
    modal.appendChild(modalContent);
    wireBackdropDismiss(modal, () => modal.remove());

    document.body.appendChild(modal);

    // NOW add event listeners after modal is in DOM
    if (presets.length > 0) {
      const updateMultiSelectButton = () => {
        const multiSelectBtn = document.getElementById('multi-preset-share-btn');
        if (!multiSelectBtn) return;

        const checkedIds = Array.from(modal.querySelectorAll('.preset-checkbox:checked'))
          .map(cb => cb.getAttribute('data-preset-id'));
        const selectedCount = checkedIds.length;

        // Live DEDUPLICATED group count across the checked presets — by identity,
        // exactly as showMergedPresetsConfirmation merges them, so the number on
        // the button is the number of groups that will actually be posted to.
        // (Counting unique NAMES here was the visible half of the bug: a preset
        // holding two different groups with the same name read as one.)
        const countRefs = [];
        presets.filter(p => checkedIds.includes(p.id))
          .forEach(p => countRefs.push(...(refsByPreset.get(p.id) || presetRefsOf(p))));
        const uniqueCount = dedupeRefs(countRefs).length;

        if (selectedCount >= 1) {
          // One path for any selection: confirm, then hand the merged group
          // list to showPostContentModal → shareToSelectedGroups, which
          // searches for each group and posts directly. Never tick DOM
          // checkboxes — virtualization only mounts ~20 rows.
          multiSelectBtn.disabled = false;
          multiSelectBtn.style.background = '#1877f2';
          multiSelectBtn.style.color = 'white';
          multiSelectBtn.style.cursor = 'pointer';
          multiSelectBtn.textContent = selectedCount > 1
            ? `Post to ${uniqueCount} unique group${uniqueCount === 1 ? '' : 's'}`
            : `Post to ${uniqueCount} group${uniqueCount === 1 ? '' : 's'}`;
          multiSelectBtn.onclick = () => {
            modal.remove();
            showMergedPresetsConfirmation(checkedIds, presets, refsByPreset);
          };
        } else {
          multiSelectBtn.disabled = true;
          multiSelectBtn.style.background = '#e4e6eb';
          multiSelectBtn.style.color = '#90949c';
          multiSelectBtn.style.cursor = 'not-allowed';
          multiSelectBtn.textContent = 'Select at least one preset';
          multiSelectBtn.onclick = null;
        }
      };
      updateMultiSelectButton();
      
      // Add event listeners to all checkboxes NOW that they're in the DOM
      document.querySelectorAll('.preset-checkbox').forEach(checkbox => {
        checkbox.addEventListener('change', (e) => {
          console.log(`[Group Presets] Checkbox changed, checked=${e.target.checked}`);
          updateMultiSelectButton();
        });
      });

      // Delete buttons — ghost icon (visible on card hover), click-to-arm confirm:
      // first click turns the button into a red "Delete?" pill; a second click
      // within 3.5s deletes, otherwise it disarms back to the ghost icon.
      modal.querySelectorAll('.delete-preset-btn').forEach(btn => {
        const ghostIcon = btn.innerHTML;
        let disarmTimer = null;
        const disarm = () => {
          clearTimeout(disarmTimer);
          btn.classList.remove('su-armed');
          btn.dataset.armed = '';
          btn.innerHTML = ghostIcon;
          btn.style.background = 'transparent';
          btn.style.width = '32px';
          btn.style.color = '';
        };
        btn.addEventListener('mouseenter', () => {
          if (!btn.dataset.armed) btn.style.background = '#f0f2f5';
        });
        btn.addEventListener('mouseleave', () => {
          if (!btn.dataset.armed) btn.style.background = 'transparent';
        });
        btn.addEventListener('click', async (e) => {
          e.stopPropagation();
          if (!btn.dataset.armed) {
            btn.dataset.armed = '1';
            btn.classList.add('su-armed');
            btn.textContent = 'Delete?';
            btn.style.background = '#e41e3f';
            btn.style.color = 'white';
            btn.style.width = 'auto';
            btn.style.fontSize = '13px';
            btn.style.fontWeight = '700';
            btn.style.padding = '0 12px';
            disarmTimer = setTimeout(disarm, 3500);
            return;
          }
          clearTimeout(disarmTimer);
          const presetId = btn.getAttribute('data-preset-id');
          const result = await new Promise(resolve => chrome.storage.local.get(['groupPresets'], resolve));
          const updated = (result.groupPresets || []).filter(p => p.id !== presetId);
          await new Promise(resolve => chrome.storage.local.set({ groupPresets: updated }, resolve));

          // Refresh the modal
          modal.remove();
          showGroupPresetsModal();
        });
      });
    }
  }

  /**
   * Shows confirmation modal with merged groups from multiple presets
   */
  function showMergedPresetsConfirmation(selectedPresetIds, allPresets, refsByPreset = null) {
    // Get selected presets
    const selectedPresets = allPresets.filter(p => selectedPresetIds.includes(p.id));
    // Pre-resolved refs from the chooser (IDs recovered for legacy entries). Falls
    // back to reading the preset directly if a future caller doesn't pass them.
    const presetRefsOfPreset = (p) =>
      (refsByPreset && refsByPreset.get(p.id)) || presetRefsOf(p);
    
    // Merge groups and remove duplicates BY IDENTITY, not by display name.
    // Two groups can share a display name (they are still two different groups),
    // so a `new Set()` of names silently dropped one of them and the preset posted
    // to fewer groups than it listed. Core.dedupePresetRefs keys on the group ID
    // and only falls back to the normalized name when the ID is genuinely unknown.
    const allRefs = [];
    selectedPresets.forEach(preset => {
      allRefs.push(...presetRefsOfPreset(preset));
    });
    const uniqueGroups = dedupeRefs(allRefs);
    const totalGroupsBeforeMerge = selectedPresets.reduce((sum, p) => sum + (p.groups || []).length, 0);

    // Two surviving entries can now share a display name (that's the point), and
    // listing "ABC" twice with nothing to tell them apart reads like a bug. Show
    // the group ID next to a name only when it is genuinely ambiguous.
    const nameTally = new Map();
    uniqueGroups.forEach(g => nameTally.set(g.name, (nameTally.get(g.name) || 0) + 1));
    const ambiguous = (g) => nameTally.get(g.name) > 1 && !!g.id;
    const duplicatesRemoved = totalGroupsBeforeMerge - uniqueGroups.length;
    
    // Create confirmation modal
    const modal = document.createElement('div');
    modal.id = 'share-unlimited-merged-presets-modal';
    modal.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      z-index: 999999999;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    `;

    const modalContent = document.createElement('div');
    modalContent.style.cssText = `
      background: white;
      border-radius: 12px;
      padding: 32px;
      max-width: 700px;
      max-height: 80vh;
      overflow-y: auto;
      box-shadow: 0 12px 40px rgba(0, 0, 0, 0.3);
      width: 90%;
    `;
    
    // Create buttons first
    const cancelBtn = document.createElement('button');
    cancelBtn.id = 'cancel-merged-share';
    cancelBtn.textContent = 'Cancel';
    cancelBtn.style.cssText = `
      flex: 1;
      background: #e4e6eb;
      border: none;
      color: #050505;
      padding: 14px 24px;
      border-radius: 10px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s;
    `;
    
    const confirmBtn = document.createElement('button');
    confirmBtn.id = 'confirm-merged-share';
    confirmBtn.textContent = `🚀 Share Now with ${selectedPresets.length} Group List${selectedPresets.length > 1 ? 's' : ''} (${uniqueGroups.length} Group${uniqueGroups.length > 1 ? 's' : ''} Total)`;
    confirmBtn.style.cssText = `
      flex: 2;
      background: #42b72a;
      border: none;
      color: white;
      padding: 14px 24px;
      border-radius: 10px;
      font-size: 17px;
      font-weight: 700;
      cursor: pointer;
      transition: all 0.2s;
      box-shadow: 0 4px 15px rgba(66, 183, 42, 0.4);
      position: relative;
      z-index: 999999999;
      pointer-events: auto;
    `;
    
    // Attach event listeners BEFORE adding to DOM
    cancelBtn.addEventListener('mouseenter', () => { cancelBtn.style.background = '#d8dadf'; });
    cancelBtn.addEventListener('mouseleave', () => { cancelBtn.style.background = '#e4e6eb'; });
    cancelBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      e.preventDefault();
      console.log('[Merged Presets] Cancel button clicked');
      modal.remove();
      showGroupPresetsModal();
    });
    
    confirmBtn.addEventListener('mouseenter', () => {
      confirmBtn.style.transform = 'translateY(-2px)';
      confirmBtn.style.background = '#36a420';
      confirmBtn.style.boxShadow = '0 6px 20px rgba(66, 183, 42, 0.5)';
    });
    confirmBtn.addEventListener('mouseleave', () => {
      confirmBtn.style.transform = 'translateY(0)';
      confirmBtn.style.background = '#42b72a';
      confirmBtn.style.boxShadow = '0 4px 15px rgba(66, 183, 42, 0.4)';
    });
    confirmBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      e.preventDefault();
      console.log('[Merged Presets] Confirm button clicked - opening post content modal with', uniqueGroups.length, 'groups');
      
      // Disable button to prevent double clicks
      confirmBtn.disabled = true;
      confirmBtn.style.opacity = '0.5';
      confirmBtn.style.cursor = 'not-allowed';
      
      // Force remove modal from DOM
      if (modal && modal.parentNode) {
        modal.parentNode.removeChild(modal);
      }
      
      // Ensure modal is gone before creating new one. The preset ids ride along
      // (v17.0) so a run that works confirms which profile these presets belong to.
      requestAnimationFrame(() => {
        showPostContentModal(uniqueGroups, '', selectedPresetIds);
      });
    }, true); // USE CAPTURE MODE to intercept event before modal background
    
    // Build modal content
    modalContent.innerHTML = `
      <div style="text-align: center; margin-bottom: 24px;">
        <div style="font-size: 64px; margin-bottom: 16px;">🎯</div>
        <h2 style="color: #050505; margin: 0 0 12px 0; font-size: 28px; font-weight: 700;">
          Sharing to ${selectedPresets.length} Group List${selectedPresets.length > 1 ? 's' : ''}
        </h2>
        <p style="color: #65676b; margin: 0 0 12px 0; font-size: 16px; line-height: 1.6;">
          ${duplicatesRemoved > 0 ?
            `✅ We removed <strong style="color: #42b72a;">${duplicatesRemoved} duplicate${duplicatesRemoved > 1 ? 's' : ''}</strong> so don't worry!<br>` :
            '✅ No duplicates found!<br>'}
          Each group will only receive 1 share.
        </p>
      </div>

      <div style="background: #e7f3ff; border: 1px solid #1877f2; border-radius: 12px; padding: 16px; margin-bottom: 20px;">
        <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 12px;">
          <span style="font-size: 24px;">📋</span>
          <div>
            <div style="color: #050505; font-size: 18px; font-weight: 700;">Selected Presets:</div>
            ${selectedPresets.map(p => `<div style="color: #65676b; font-size: 14px;">• ${escHtml(p.name)} (${(p.groups || []).length} groups)</div>`).join('')}
          </div>
        </div>
      </div>

      <div style="background: #f0f2f5; border: 1px solid #e4e6eb; border-radius: 12px; padding: 16px; margin-bottom: 24px;">
        <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 12px;">
          <span style="font-size: 24px;">✨</span>
          <span style="color: #050505; font-size: 18px; font-weight: 700;">
            ${uniqueGroups.length} Unique Group${uniqueGroups.length > 1 ? 's' : ''}
          </span>
        </div>
        <div style="max-height: 300px; overflow-y: auto; background: white; border: 1px solid #e4e6eb; border-radius: 8px; padding: 12px;">
          ${uniqueGroups.map((g, i) => `
            <div style="color: #050505; font-size: 13px; padding: 6px 8px; margin: 4px 0; background: #f0f2f5; border-radius: 6px;">
              ${i + 1}. ${escHtml(g.name)}${ambiguous(g) ? `<span style="color:#65676b;"> · id ${escHtml(g.id)}</span>` : ''}
            </div>
          `).join('')}
        </div>
      </div>
      
      <div id="button-container" style="display: flex; gap: 12px;"></div>
    `;
    
    // Append buttons to container
    const buttonContainer = modalContent.querySelector('#button-container');
    buttonContainer.appendChild(cancelBtn);
    buttonContainer.appendChild(confirmBtn);
    
    modal.appendChild(modalContent);
    document.body.appendChild(modal);
    
    wireBackdropDismiss(modal, () => {
      console.log('[Merged Presets] Modal background clicked');
      modal.remove();
      showGroupPresetsModal();
    });
  }

  /**
   * Shows dialog to save selected groups as a Group List Preset
   */
  function showSaveGroupListPresetDialog(selectedGroups) {
    const existing = document.getElementById('share-unlimited-save-preset-modal');
    if (existing) existing.remove();
    
    const modal = document.createElement('div');
    modal.id = 'share-unlimited-save-preset-modal';
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        z-index: 999999999;
        display: flex;
        align-items: center;
        justify-content: center;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    `;

    const modalContent = document.createElement('div');
    modalContent.style.cssText = `
        background: white;
        border-radius: 12px;
        max-width: 500px;
        width: 92%;
        overflow: hidden;
        box-shadow: 0 12px 40px rgba(0, 0, 0, 0.3);
    `;

    modalContent.innerHTML = `
        <div style="padding: 14px 20px; border-bottom: 1px solid #e4e6eb; display: flex; align-items: center; justify-content: space-between;">
            <div style="color: #050505; font-size: 20px; font-weight: 700;">💾 Save as Group List Preset</div>
            <button id="close-save-preset" style="background:#f0f2f5;border:none;color:#65676b;font-size:18px;width:36px;height:36px;border-radius:50%;cursor:pointer;transition:background 0.15s;flex-shrink:0;">✕</button>
        </div>

        <div style="padding: 16px 20px 20px;">
            <p style="color: #65676b; margin: 0 0 14px 0; font-size: 14px; line-height: 1.5;">
                By saving this group list you can easily apply it next time when you want to share to these same groups!
            </p>

            <div style="display: inline-block; background: #e7f3ff; color: #1877f2; border-radius: 50px; padding: 6px 14px; font-size: 13px; font-weight: 700; margin-bottom: 16px;">
                📋 ${selectedGroups.length} group${selectedGroups.length > 1 ? 's' : ''} selected
            </div>

            <div style="margin-bottom: 20px;">
                <label style="color: #050505; display: block; margin-bottom: 8px; font-size: 15px; font-weight: 600;">
                    Name your Group List Preset
                </label>
                <input
                    type="text"
                    id="preset-name-input"
                    placeholder="e.g., My Favorite Groups, Tech Communities..."
                    style="
                        width: 100%;
                        background: #f0f2f5;
                        border: 2px solid transparent;
                        border-radius: 8px;
                        padding: 10px 14px;
                        font-size: 15px;
                        color: #050505;
                        font-family: inherit;
                        box-sizing: border-box;
                        outline: none;
                        transition: border-color 0.15s, background 0.15s;
                    "
                />
            </div>

            <div style="display: flex; gap: 8px;">
                <button id="cancel-save-preset" style="
                    flex: 1;
                    background: #e4e6eb;
                    border: none;
                    color: #050505;
                    padding: 10px 16px;
                    border-radius: 8px;
                    font-size: 15px;
                    font-weight: 600;
                    cursor: pointer;
                    transition: background 0.15s;
                ">Cancel</button>

                <button id="confirm-save-preset" style="
                    flex: 2;
                    background: #1877f2;
                    border: none;
                    color: white;
                    padding: 10px 16px;
                    border-radius: 8px;
                    font-size: 15px;
                    font-weight: 600;
                    cursor: pointer;
                    transition: background 0.15s;
                ">Save Preset</button>
            </div>
        </div>
    `;

    modal.appendChild(modalContent);
    document.body.appendChild(modal);

    const nameInput = modal.querySelector('#preset-name-input');
    const closeBtn = modal.querySelector('#close-save-preset');
    const cancelBtn = modal.querySelector('#cancel-save-preset');
    const confirmBtn = modal.querySelector('#confirm-save-preset');

    nameInput.addEventListener('focus', () => { nameInput.style.borderColor = '#1877f2'; nameInput.style.background = '#fff'; });
    nameInput.addEventListener('blur', () => { nameInput.style.borderColor = 'transparent'; nameInput.style.background = '#f0f2f5'; });

    closeBtn.addEventListener('mouseenter', () => { closeBtn.style.background = '#d8dadf'; });
    closeBtn.addEventListener('mouseleave', () => { closeBtn.style.background = '#f0f2f5'; });
    closeBtn.addEventListener('click', () => modal.remove());

    cancelBtn.addEventListener('mouseenter', () => { cancelBtn.style.background = '#d8dadf'; });
    cancelBtn.addEventListener('mouseleave', () => { cancelBtn.style.background = '#e4e6eb'; });
    cancelBtn.addEventListener('click', () => modal.remove());

    confirmBtn.addEventListener('mouseenter', () => { confirmBtn.style.background = '#166fe5'; });
    confirmBtn.addEventListener('mouseleave', () => { confirmBtn.style.background = '#1877f2'; });
    confirmBtn.addEventListener('click', async () => {
        const presetName = nameInput.value.trim();
        
        if (!presetName) {
            alert('Please enter a name for your Group List Preset!');
            nameInput.focus();
            return;
        }
        
        // Save the preset
        const result = await new Promise(resolve => {
            chrome.storage.local.get(['groupPresets'], resolve);
        });
        
        const presets = result.groupPresets || [];

        // Stamp the profile this list was built on (v17.0). Group membership is
        // per profile, so a preset saved on profile A is largely useless on
        // profile B — showGroupPresetsModal surfaces this. Both fields may be
        // null (cookies/name unreadable); the chooser degrades to "not recorded".
        const profile = (window.ShareUnlimited.Core && window.ShareUnlimited.Core.Profile)
            ? window.ShareUnlimited.Core.Profile.getActive()
            : { id: null, name: null };

        const newPreset = {
            id: Date.now().toString(),
            name: presetName,
            // Groups are stored as {name, id} refs (v18.2). This used to unwrap the
            // v15.9 {name, id} objects down to bare name strings, which threw away
            // the only thing that distinguishes two groups sharing a display name —
            // so a preset listing the same name twice collapsed to one group and
            // silently never posted to the second. IDs may be null (a group typed
            // in by name, or restored from a pre-v18.2 preset); everything reading
            // presets falls back to the name in that case.
            groups: presetRefsOf(selectedGroups),
            createdAt: new Date().toISOString(),
            profileId: profile.id || null,
            profileName: profile.name || null
        };

        presets.push(newPreset);
        
        await new Promise(resolve => {
            chrome.storage.local.set({ groupPresets: presets }, resolve);
        });
        
        // Show success message
        modal.remove();
        if (window.ShareUnlimited.UI && window.ShareUnlimited.UI.showSuccessNotification) {
          window.ShareUnlimited.UI.showSuccessNotification(`✓ Group List Preset "${presetName}" saved successfully!`);
        }
        
        // Update the Group Presets button badge if it exists
        const groupPresetsBtn = document.querySelector('#share-unlimited-group-presets-btn');
        if (groupPresetsBtn) {
            // Match the toolbar's ghost-button pattern (Lucide layers icon + muted badge)
            groupPresetsBtn.innerHTML = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;"><path d="M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z"/><path d="m22 17.65-9.17 4.16a2 2 0 0 1-1.66 0L2 17.65"/><path d="m22 12.65-9.17 4.16a2 2 0 0 1-1.66 0L2 12.65"/></svg> Presets <span class="su-badge">${presets.length}</span>`;
        }
    });
    
    wireBackdropDismiss(modal, () => modal.remove());

    nameInput.focus();
  }

  /**
   * Shows dialog to save post content as a Post Template
   */
  function showSavePostTemplateDialog(postContent) {
    const existing = document.getElementById('share-unlimited-save-post-template-modal');
    if (existing) existing.remove();
    
    const modal = document.createElement('div');
    modal.id = 'share-unlimited-save-post-template-modal';
    modal.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        z-index: 999999999;
        display: flex;
        align-items: center;
        justify-content: center;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    `;

    const modalContent = document.createElement('div');
    modalContent.style.cssText = `
        background: white;
        border-radius: 12px;
        max-width: 500px;
        width: 92%;
        overflow: hidden;
        box-shadow: 0 12px 40px rgba(0, 0, 0, 0.3);
    `;

    const preview = postContent.substring(0, 100) + (postContent.length > 100 ? '...' : '');

    modalContent.innerHTML = `
        <div style="padding: 14px 20px; border-bottom: 1px solid #e4e6eb;">
            <div style="color: #050505; font-size: 20px; font-weight: 700;">📝 Save as Post Template</div>
        </div>

        <div style="padding: 16px 20px 20px;">
            <p style="color: #65676b; margin: 0 0 14px 0; font-size: 14px; line-height: 1.5;">
                Save this post content as a reusable template!
            </p>

            <div style="background: #f0f2f5; border-radius: 8px; padding: 12px 14px; margin-bottom: 16px;">
                <p style="color: #050505; margin: 0 0 8px 0; font-size: 14px; font-weight: 600;">
                    📋 Post Preview
                </p>
                <p style="color: #65676b; margin: 0; font-size: 13px; line-height: 1.4;">
                    ${preview}
                </p>
            </div>

            <div style="margin-bottom: 20px;">
                <label style="color: #050505; display: block; margin-bottom: 8px; font-size: 15px; font-weight: 600;">
                    Name your Post Template
                </label>
                <input
                    type="text"
                    id="post-template-name-input"
                    placeholder="e.g., My Product Ad, Daily Update..."
                    style="
                        width: 100%;
                        background: #f0f2f5;
                        border: 2px solid transparent;
                        border-radius: 8px;
                        padding: 10px 14px;
                        font-size: 15px;
                        color: #050505;
                        font-family: inherit;
                        box-sizing: border-box;
                        outline: none;
                        transition: border-color 0.15s, background 0.15s;
                    "
                />
            </div>

            <div style="display: flex; gap: 8px;">
                <button id="cancel-save-post-template" style="
                    flex: 1;
                    background: #e4e6eb;
                    border: none;
                    color: #050505;
                    padding: 10px 16px;
                    border-radius: 8px;
                    font-size: 15px;
                    font-weight: 600;
                    cursor: pointer;
                    transition: background 0.15s;
                ">Cancel</button>

                <button id="confirm-save-post-template" style="
                    flex: 2;
                    background: #42b72a;
                    border: none;
                    color: white;
                    padding: 10px 16px;
                    border-radius: 8px;
                    font-size: 15px;
                    font-weight: 600;
                    cursor: pointer;
                    transition: background 0.15s;
                ">📝 Save Template</button>
            </div>
        </div>
    `;

    modal.appendChild(modalContent);
    document.body.appendChild(modal);

    const nameInput = modal.querySelector('#post-template-name-input');
    const cancelBtn = modal.querySelector('#cancel-save-post-template');
    const confirmBtn = modal.querySelector('#confirm-save-post-template');

    nameInput.addEventListener('focus', () => { nameInput.style.borderColor = '#1877f2'; nameInput.style.background = '#fff'; });
    nameInput.addEventListener('blur', () => { nameInput.style.borderColor = 'transparent'; nameInput.style.background = '#f0f2f5'; });

    cancelBtn.addEventListener('mouseenter', () => { cancelBtn.style.background = '#d8dadf'; });
    cancelBtn.addEventListener('mouseleave', () => { cancelBtn.style.background = '#e4e6eb'; });
    cancelBtn.addEventListener('click', () => modal.remove());

    confirmBtn.addEventListener('mouseenter', () => { confirmBtn.style.background = '#36a420'; });
    confirmBtn.addEventListener('mouseleave', () => { confirmBtn.style.background = '#42b72a'; });
    confirmBtn.addEventListener('click', () => {
        const templateName = nameInput.value.trim();
        
        if (!templateName) {
            alert('Please enter a name for your Post Template!');
            nameInput.focus();
            return;
        }
        
        // Save the template
        chrome.storage.local.get(['postTemplates'], (result) => {
            const postTemplates = result.postTemplates || {};
            
            // Check if template name already exists
            if (postTemplates[templateName]) {
                if (!confirm(`A template named "${templateName}" already exists. Replace it?`)) {
                    return;
                }
            }
            
            postTemplates[templateName] = postContent;
            
            chrome.storage.local.set({ postTemplates }, () => {
                modal.remove();
                if (window.ShareUnlimited.UI && window.ShareUnlimited.UI.showSuccessNotification) {
                  window.ShareUnlimited.UI.showSuccessNotification(`✓ Post Template "${templateName}" saved successfully!`);
                }
            });
        });
    });
    
    wireBackdropDismiss(modal, () => modal.remove());

    nameInput.focus();
  }

  /**
   * Shows dialog to apply a Post Template to the textarea
   */
  function showApplyPostTemplateDialog(textarea) {
    const existing = document.getElementById('share-unlimited-apply-post-template-modal');
    if (existing) existing.remove();
    
    chrome.storage.local.get(['postTemplates'], (result) => {
        const postTemplates = result.postTemplates || {};
        const templateKeys = Object.keys(postTemplates);
        
        const modal = document.createElement('div');
        modal.id = 'share-unlimited-apply-post-template-modal';
        modal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 999999999;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
        `;

        const modalContent = document.createElement('div');
        modalContent.style.cssText = `
            background: white;
            border-radius: 12px;
            padding: 24px;
            max-width: 600px;
            max-height: 80vh;
            overflow-y: auto;
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.3);
        `;
        
        const header = document.createElement('div');
        header.style.cssText = `
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        `;
        
        const title = document.createElement('h2');
        title.textContent = '📖 Apply Post Template';
        title.style.cssText = `
            color: #050505;
            margin: 0;
            font-size: 20px;
            font-weight: 700;
        `;

        const closeBtn = document.createElement('button');
        closeBtn.textContent = '✕';
        closeBtn.style.cssText = `
            background: #f0f2f5;
            border: none;
            color: #65676b;
            font-size: 18px;
            width: 36px;
            height: 36px;
            border-radius: 50%;
            cursor: pointer;
            transition: all 0.2s;
        `;
        closeBtn.addEventListener('mouseenter', () => { closeBtn.style.background = '#d8dadf'; });
        closeBtn.addEventListener('mouseleave', () => { closeBtn.style.background = '#f0f2f5'; });
        closeBtn.addEventListener('click', () => modal.remove());
        
        header.appendChild(title);
        header.appendChild(closeBtn);
        modalContent.appendChild(header);
        
        if (templateKeys.length === 0) {
            const emptyState = document.createElement('div');
            emptyState.style.cssText = `
                text-align: center;
                padding: 40px 20px;
                color: #050505;
            `;
            emptyState.innerHTML = `
                <div style="font-size: 48px; margin-bottom: 16px;">📭</div>
                <p style="font-size: 18px; margin-bottom: 8px;">No Post Templates Yet</p>
                <p style="opacity: 0.8;">Save your first template to use it here!</p>
            `;
            modalContent.appendChild(emptyState);
        } else {
            templateKeys.forEach(templateName => {
                const card = document.createElement('div');
                card.style.cssText = `
                    background: #f0f2f5;
                    border-radius: 12px;
                    padding: 16px;
                    margin-bottom: 12px;
                    transition: all 0.2s;
                    cursor: pointer;
                `;
                card.addEventListener('mouseenter', () => {
                    card.style.background = '#e4e6eb';
                    card.style.transform = 'translateY(-2px)';
                });
                card.addEventListener('mouseleave', () => {
                    card.style.background = '#f0f2f5';
                    card.style.transform = 'translateY(0)';
                });
                
                const preview = postTemplates[templateName].substring(0, 100) + (postTemplates[templateName].length > 100 ? '...' : '');
                
                card.innerHTML = `
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <span style="font-size: 24px;">📝</span>
                            <span style="color: #050505; font-size: 18px; font-weight: 600;">${templateName}</span>
                        </div>
                        <button class="apply-template-btn" data-template-name="${templateName}" style="
                            background: #42b72a;
                            border: none;
                            color: white;
                            padding: 8px 20px;
                            border-radius: 8px;
                            font-size: 14px;
                            font-weight: 600;
                            cursor: pointer;
                            transition: all 0.2s;
                        ">✓ Apply</button>
                    </div>
                    <div style="color: #65676b; font-size: 14px; line-height: 1.4;">
                        ${preview}
                    </div>
                `;
                
                modalContent.appendChild(card);
            });
            
            modalContent.querySelectorAll('.apply-template-btn').forEach(btn => {
                btn.addEventListener('mouseenter', (e) => {
                    e.target.style.background = '#36a420';
                    e.target.style.transform = 'scale(1.05)';
                });
                btn.addEventListener('mouseleave', (e) => {
                    e.target.style.background = '#42b72a';
                    e.target.style.transform = 'scale(1)';
                });
                btn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const templateName = e.target.getAttribute('data-template-name');
                    textarea.value = postTemplates[templateName];
                    modal.remove();
                    if (window.ShareUnlimited.UI && window.ShareUnlimited.UI.showSuccessNotification) {
                      window.ShareUnlimited.UI.showSuccessNotification(`✓ Applied template "${templateName}"!`);
                    }
                });
            });
        }
        
        modal.appendChild(modalContent);
        wireBackdropDismiss(modal, () => modal.remove());

        document.body.appendChild(modal);
    });
  }

  /**
   * Shows 1 Click Presets modal directly on Facebook
   */
  async function showOneClickPresetsModal() {
    const existing = document.getElementById('share-unlimited-presets-modal');
    if (existing) existing.remove();
    
    const result = await new Promise(resolve => {
      chrome.storage.local.get(['oneClickTemplates'], resolve);
    });
    
    const templates = result.oneClickTemplates || [];
    
    const modal = document.createElement('div');
    modal.id = 'share-unlimited-presets-modal';
    modal.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.5);
      z-index: 99999999;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    `;

    const modalContent = document.createElement('div');
    modalContent.style.cssText = `
      background: white;
      border-radius: 12px;
      padding: 24px;
      max-width: 600px;
      max-height: 80vh;
      overflow-y: auto;
      box-shadow: 0 12px 40px rgba(0, 0, 0, 0.3);
    `;
    
    const header = document.createElement('div');
    header.style.cssText = `
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
    `;
    
    const title = document.createElement('h2');
    title.textContent = '⚡ 1 Click Share Templates';
    title.style.cssText = `
      color: #050505;
      margin: 0;
      font-size: 20px;
      font-weight: 700;
    `;

    const closeBtn = document.createElement('button');
    closeBtn.textContent = '✕';
    closeBtn.style.cssText = `
      background: #f0f2f5;
      border: none;
      color: #65676b;
      font-size: 18px;
      width: 36px;
      height: 36px;
      border-radius: 50%;
      cursor: pointer;
      transition: all 0.2s;
    `;
    closeBtn.addEventListener('mouseenter', () => { closeBtn.style.background = '#d8dadf'; });
    closeBtn.addEventListener('mouseleave', () => { closeBtn.style.background = '#f0f2f5'; });
    closeBtn.addEventListener('click', () => modal.remove());
    
    header.appendChild(title);
    header.appendChild(closeBtn);
    modalContent.appendChild(header);
    
    if (templates.length === 0) {
      const emptyState = document.createElement('div');
      emptyState.style.cssText = `
        text-align: center;
        padding: 40px 20px;
        color: #050505;
      `;
      emptyState.innerHTML = `
        <div style="font-size: 48px; margin-bottom: 16px;">📭</div>
        <p style="font-size: 18px; margin-bottom: 8px;">No Templates Yet</p>
        <p style="opacity: 0.8;">Create templates from the extension popup to use them here!</p>
      `;
      modalContent.appendChild(emptyState);
    } else {
      templates.forEach(template => {
        const card = document.createElement('div');
        card.style.cssText = `
          background: #f0f2f5;
          border-radius: 12px;
          padding: 16px;
          margin-bottom: 12px;
          transition: all 0.2s;
        `;
        card.addEventListener('mouseenter', () => {
          card.style.background = '#e4e6eb';
          card.style.transform = 'translateY(-2px)';
        });
        card.addEventListener('mouseleave', () => {
          card.style.background = '#f0f2f5';
          card.style.transform = 'translateY(0)';
        });
        
        card.innerHTML = `
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
            <div style="display: flex; align-items: center; gap: 10px;">
              <span style="font-size: 24px;">⚡</span>
              <span style="color: #050505; font-size: 18px; font-weight: 600;">${template.name}</span>
            </div>
            <button class="use-template-btn" data-template-id="${template.id}" style="
              background: #42b72a;
              border: none;
              color: white;
              padding: 8px 20px;
              border-radius: 8px;
              font-size: 14px;
              font-weight: 600;
              cursor: pointer;
              transition: all 0.2s;
            ">🚀 Use Now</button>
          </div>
          <div style="display: flex; flex-direction: column; gap: 8px; color: #65676b; font-size: 14px;">
            <div style="display: flex; align-items: center; gap: 8px;">
              <span>📖</span>
              <span>Group List: ${template.groupPresetName} (${template.groupCount} groups)</span>
            </div>
            <div style="display: flex; align-items: center; gap: 8px;">
              <span>📝</span>
              <span>Post Template: ${template.postTemplateName}</span>
            </div>
          </div>
        `;
        
        modalContent.appendChild(card);
      });
      
      modalContent.querySelectorAll('.use-template-btn').forEach(btn => {
        btn.addEventListener('mouseenter', (e) => {
          e.target.style.background = '#36a420';
          e.target.style.transform = 'scale(1.05)';
        });
        btn.addEventListener('mouseleave', (e) => {
          e.target.style.background = '#42b72a';
          e.target.style.transform = 'scale(1)';
        });
        btn.addEventListener('click', async (e) => {
          e.stopPropagation();
          const templateId = e.target.getAttribute('data-template-id');
          modal.remove();
          if (window.ShareUnlimited.Core && window.ShareUnlimited.Core.useOneClickTemplateDirectly) {
            await window.ShareUnlimited.Core.useOneClickTemplateDirectly(templateId);
          }
        });
      });
    }
    
    modal.appendChild(modalContent);
    wireBackdropDismiss(modal, () => modal.remove());

    document.body.appendChild(modal);
  }

  /**
   * Shows the schedule disclaimer modal (BETA warning) before the date/time picker
   */
  // `postVariations` (v17.9) rides through the schedule chain untouched so a
  // scheduled run rotates the same way an immediate one does.
  function showScheduleDisclaimerModal(selectedGroups, postContent, sourcePresetIds = null,
                                       postVariations = null, delaySeconds = 10, delayMode = false) {
    const existing = document.getElementById('share-unlimited-schedule-disclaimer-modal');
    if (existing) existing.remove();

    const modal = document.createElement('div');
    modal.id = 'share-unlimited-schedule-disclaimer-modal';
    modal.style.cssText = `
      position: fixed; top: 0; left: 0; width: 100%; height: 100%;
      background: rgba(0, 0, 0, 0.5); z-index: 999999999;
      display: flex; align-items: center; justify-content: center;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    `;

    const modalContent = document.createElement('div');
    modalContent.style.cssText = `
      background: white; border-radius: 12px; padding: 28px;
      max-width: 460px; width: 90%; box-shadow: 0 8px 32px rgba(0,0,0,0.25);
    `;

    modalContent.innerHTML = `
      <div style="text-align: center; margin-bottom: 18px;">
        <div style="font-size: 44px; margin-bottom: 10px;">📅</div>
        <div style="display: flex; align-items: center; justify-content: center; gap: 8px; margin-bottom: 6px;">
          <h2 style="color: #050505; margin: 0; font-size: 20px; font-weight: 700;">Schedule for Future</h2>
          <span style="background: #e4e6eb; color: #65676b; font-size: 10px; font-weight: 700; padding: 2px 8px; border-radius: 20px; letter-spacing: 0.4px;">BETA</span>
        </div>
        <p style="color: #1877f2; font-size: 14px; font-weight: 600; margin: 0;">
          Post to all your groups at the perfect moment — hands free. 🚀
        </p>
      </div>
      <div style="background: #f0f2f5; border-radius: 8px; padding: 12px 14px; margin-bottom: 20px; font-size: 13px; color: #444; line-height: 1.65;">
        <strong style="color: #050505;">📋 Quick note before you continue:</strong><br><br>
        • Your account needs Facebook's <strong>scheduling permission</strong> enabled.<br>
        • Only works in groups where you are an <strong>Admin</strong>.
      </div>
      <div style="display: flex; gap: 10px;">
        <button id="schedule-disclaimer-cancel" style="
          flex: 1; background: #e4e6eb; border: none; color: #050505;
          padding: 10px 16px; border-radius: 6px; font-size: 15px; font-weight: 600; cursor: pointer;
        ">← Back</button>
        <button id="schedule-disclaimer-continue" style="
          flex: 2; background: #1877f2; border: none; color: white;
          padding: 10px 16px; border-radius: 6px; font-size: 15px; font-weight: 600; cursor: pointer;
        ">Set Date &amp; Time →</button>
      </div>
    `;

    modal.appendChild(modalContent);
    document.body.appendChild(modal);

    const cancelBtn = modalContent.querySelector('#schedule-disclaimer-cancel');
    const continueBtn = modalContent.querySelector('#schedule-disclaimer-continue');

    cancelBtn.addEventListener('mouseenter', () => { cancelBtn.style.background = '#d8dadf'; });
    cancelBtn.addEventListener('mouseleave', () => { cancelBtn.style.background = '#e4e6eb'; });
    cancelBtn.addEventListener('click', () => {
      modal.remove();
      showPostContentModal(selectedGroups, postContent, sourcePresetIds, postVariations);
    });

    continueBtn.addEventListener('mouseenter', () => { continueBtn.style.background = '#166fe5'; });
    continueBtn.addEventListener('mouseleave', () => { continueBtn.style.background = '#1877f2'; });
    continueBtn.addEventListener('click', () => {
      modal.remove();
      showSchedulePickerModal(selectedGroups, postContent, sourcePresetIds, postVariations,
        delaySeconds, delayMode);
    });

    wireBackdropDismiss(modal, () => {
      modal.remove();
      showPostContentModal(selectedGroups, postContent, sourcePresetIds, postVariations);
    });
  }

  /**
   * Shows the date/time picker for scheduling — calls Core.shareToSelectedGroups with schedule params
   */
  function showSchedulePickerModal(selectedGroups, postContent, sourcePresetIds = null,
                                   postVariations = null, delaySeconds = 10, delayMode = false) {
    const existing = document.getElementById('share-unlimited-schedule-picker-modal');
    if (existing) existing.remove();

    // Build 5-minute interval time options
    const timeOptions = [];
    for (let h = 0; h < 24; h++) {
      for (let m = 0; m < 60; m += 5) {
        const h12 = h % 12 === 0 ? 12 : h % 12;
        const ampm = h < 12 ? 'AM' : 'PM';
        const display = `${h12}:${String(m).padStart(2, '0')} ${ampm}`;
        const value = `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
        timeOptions.push({ display, value });
      }
    }

    // Default: now + 1 hour, rounded up to next 5 min
    const minDt = new Date(Date.now() + 2 * 60 * 60 * 1000);
    const roundedMin = Math.ceil(minDt.getMinutes() / 5) * 5;
    minDt.setMinutes(roundedMin, 0, 0);

    const pad = n => String(n).padStart(2, '0');
    const defaultDate = `${minDt.getFullYear()}-${pad(minDt.getMonth() + 1)}-${pad(minDt.getDate())}`;
    const defaultTime = `${pad(minDt.getHours())}:${pad(minDt.getMinutes())}`;

    const modal = document.createElement('div');
    modal.id = 'share-unlimited-schedule-picker-modal';
    modal.style.cssText = `
      position: fixed; top: 0; left: 0; width: 100%; height: 100%;
      background: rgba(0, 0, 0, 0.5); z-index: 999999999;
      display: flex; align-items: center; justify-content: center;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    `;

    const modalContent = document.createElement('div');
    modalContent.style.cssText = `
      background: white; border-radius: 12px; padding: 28px;
      max-width: 420px; width: 90%; box-shadow: 0 8px 32px rgba(0,0,0,0.25);
    `;

    const timeOptionsHTML = timeOptions.map(opt =>
      `<option value="${opt.value}"${opt.value === defaultTime ? ' selected' : ''}>${opt.display}</option>`
    ).join('');

    modalContent.innerHTML = `
      <div style="margin-bottom: 20px;">
        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 5px;">
          <h2 style="color: #050505; margin: 0; font-size: 18px; font-weight: 700;">When should this go live? 📅</h2>
          <span style="background: #e4e6eb; color: #65676b; font-size: 10px; font-weight: 700; padding: 2px 8px; border-radius: 20px; letter-spacing: 0.4px; flex-shrink: 0;">BETA</span>
        </div>
        <p style="margin: 0; color: #1877f2; font-size: 13px; font-weight: 600;">Every group. Perfectly timed. Hands free. 🚀</p>
      </div>
      <div style="margin-bottom: 16px;">
        <label style="display: block; color: #050505; font-size: 13px; font-weight: 600; margin-bottom: 6px;">Date</label>
        <input type="date" id="overlay-schedule-date" value="${defaultDate}" style="
          width: 100%; padding: 10px 12px; border: 1.5px solid #bbb; border-radius: 6px;
          font-size: 14px; font-family: inherit; box-sizing: border-box;
          background: #fff; color: #1a1a1a; outline: none;
        ">
      </div>
      <div style="margin-bottom: 20px;">
        <label style="display: block; color: #050505; font-size: 13px; font-weight: 600; margin-bottom: 6px;">Time</label>
        <select id="overlay-schedule-time" style="
          width: 100%; padding: 10px 12px; border: 1.5px solid #bbb; border-radius: 6px;
          font-size: 14px; font-family: inherit; box-sizing: border-box;
          background: #fff; color: #1a1a1a; outline: none;
        ">${timeOptionsHTML}</select>
      </div>
      <div id="overlay-schedule-error" style="color: #c00; font-size: 13px; margin-bottom: 12px; display: none;"></div>
      <div style="display: flex; gap: 10px;">
        <button id="overlay-schedule-back" style="
          flex: 1; background: #e4e6eb; border: none; color: #050505;
          padding: 10px 16px; border-radius: 6px; font-size: 15px; font-weight: 600; cursor: pointer;
        ">← Back</button>
        <button id="overlay-schedule-confirm" style="
          flex: 2; background: #1877f2; border: none; color: white;
          padding: 10px 16px; border-radius: 6px; font-size: 15px; font-weight: 600; cursor: pointer;
        ">📅 Schedule</button>
      </div>
    `;

    modal.appendChild(modalContent);
    document.body.appendChild(modal);

    const dateInput = modalContent.querySelector('#overlay-schedule-date');
    const timeSelect = modalContent.querySelector('#overlay-schedule-time');
    const errorDiv = modalContent.querySelector('#overlay-schedule-error');
    const backBtn = modalContent.querySelector('#overlay-schedule-back');
    const confirmBtn = modalContent.querySelector('#overlay-schedule-confirm');

    backBtn.addEventListener('mouseenter', () => { backBtn.style.background = '#d8dadf'; });
    backBtn.addEventListener('mouseleave', () => { backBtn.style.background = '#e4e6eb'; });
    backBtn.addEventListener('click', () => {
      modal.remove();
      showPostContentModal(selectedGroups, postContent, sourcePresetIds, postVariations);
    });

    confirmBtn.addEventListener('mouseenter', () => { confirmBtn.style.background = '#166fe5'; });
    confirmBtn.addEventListener('mouseleave', () => { confirmBtn.style.background = '#1877f2'; });
    confirmBtn.addEventListener('click', async () => {
      const dateVal = dateInput.value;   // "2026-04-30"
      const timeVal = timeSelect.value;  // "12:05" (24h)

      if (!dateVal || !timeVal) {
        errorDiv.textContent = 'Please select a date and time.';
        errorDiv.style.display = 'block';
        return;
      }

      const [year, month, day] = dateVal.split('-').map(Number);
      const [hours, minutes] = timeVal.split(':').map(Number);
      const scheduledDt = new Date(year, month - 1, day, hours, minutes, 0);

      if (scheduledDt <= new Date(Date.now() + 60 * 60 * 1000)) {
        errorDiv.textContent = 'Please choose a time at least 1 hour from now.';
        errorDiv.style.display = 'block';
        return;
      }

      // Format for Facebook
      const monthNames = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
      const fbDate = `${monthNames[month - 1]} ${day}, ${year}`;
      const h12 = hours % 12 === 0 ? 12 : hours % 12;
      const ampm = hours < 12 ? 'AM' : 'PM';
      const fbTime = `${h12}:${String(minutes).padStart(2, '0')} ${ampm}`;

      modal.remove();

      if (window.ShareUnlimited.Core && window.ShareUnlimited.Core.shareToSelectedGroups) {
        await window.ShareUnlimited.Core.shareToSelectedGroups(
          selectedGroups, postContent, postVariations, null, delaySeconds, delayMode,
          fbDate, fbTime, sourcePresetIds
        );
      }
    });

    wireBackdropDismiss(modal, () => modal.remove());
  }

  /**
   * "Search My Groups" modal (v16.1). FB's own dialog search returns only ~10
   * relevance-ranked results — this searches OUR persistent inventory (every group
   * row the extension has ever seen, built up by Load All / scans / shares), so a
   * query like "real estate" lists ALL matching groups the user is in. Picked
   * groups become {name, id} refs that go straight into the existing share modal
   * (which already offers preset-saving) or directly into the preset dialog.
   * Purely additive — touches no saved selections and no FB DOM outside itself.
   */
  async function showGroupSearchModal() {
    const existing = document.getElementById('share-unlimited-group-search-modal');
    if (existing) existing.remove();

    const Core = window.ShareUnlimited.Core;
    if (!Core || !Core.Inventory) return;

    const inventory = await Core.Inventory.getAll();      // [{id, name}] alphabetical
    const updatedAt = await Core.Inventory.getUpdatedAt();
    const byId = new Map(inventory.map(g => [g.id, g.name]));
    const norm = Core.normalizeGroupNameForMatch || (s => String(s).toLowerCase());

    // One-time animation styles
    if (!document.getElementById('su-gsm-styles')) {
      const style = document.createElement('style');
      style.id = 'su-gsm-styles';
      style.textContent = `
        @keyframes suGsmFadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes suGsmCardIn { from { opacity: 0; transform: scale(0.94) translateY(10px); } to { opacity: 1; transform: scale(1) translateY(0); } }
        @keyframes suGsmRowIn  { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes suGsmChipIn { 0% { opacity: 0; transform: scale(0.6); } 70% { transform: scale(1.08); } 100% { opacity: 1; transform: scale(1); } }
        @keyframes suGsmPulse  { 0% { transform: scale(1); } 50% { transform: scale(1.06); } 100% { transform: scale(1); } }
        @keyframes suGsmDropIn { from { opacity: 0; transform: translateY(-8px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes suGsmToastIn { from { opacity: 0; transform: translate(-50%, 10px); } to { opacity: 1; transform: translate(-50%, 0); } }
        .su-gsm-row { animation: suGsmRowIn 0.18s ease-out both; }
        .su-gsm-row:hover { background: #f2f2f2 !important; }
        .su-gsm-chip { animation: suGsmChipIn 0.22s cubic-bezier(0.34, 1.56, 0.64, 1) both; }
        .su-gsm-count-pulse { animation: suGsmPulse 0.25s ease-out; }
      `;
      document.head.appendChild(style);
    }

    const modal = document.createElement('div');
    modal.id = 'share-unlimited-group-search-modal';
    modal.style.cssText = `
        position: fixed; inset: 0; background: rgba(0, 0, 0, 0.6); z-index: 99999999;
        display: flex; align-items: center; justify-content: center;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
        animation: suGsmFadeIn 0.15s ease-out;
    `;

    const card = document.createElement('div');
    // position:relative — the presets dropdown and the toast are absolutely
    // positioned against this card so neither can push the footer out of view.
    card.style.cssText = `
        background: white; border-radius: 12px; max-width: 560px; width: 92%;
        max-height: min(82vh, 820px); display: flex; flex-direction: column;
        overflow: hidden; position: relative;
        box-shadow: 0 12px 40px rgba(0, 0, 0, 0.3);
        animation: suGsmCardIn 0.22s cubic-bezier(0.16, 1, 0.3, 1);
    `;
    modal.appendChild(card);

    // ---- Header ----
    const header = document.createElement('div');
    header.style.cssText = 'padding: 14px 20px; border-bottom: 1px solid #e4e6eb; display: flex; align-items: center; justify-content: space-between; flex-shrink: 0; position: relative;';
    const title = document.createElement('div');
    // App logo from the extension package — images/* is web-accessible, so the
    // chrome-extension:// URL loads fine inside Facebook's page.
    const appIconUrl = chrome.runtime.getURL('images/icon48.png');
    title.innerHTML =
      '<div style="display:flex;align-items:center;gap:10px;">' +
        `<img src="${appIconUrl}" alt="" style="width:34px;height:34px;flex-shrink:0;">` +
        '<div id="su-gsm-title-col">' +
          '<div style="color:#050505;font-size:20px;font-weight:700;">Select Groups To Share With</div>' +
        '</div>' +
      '</div>';
    const subtitle = document.createElement('div');
    subtitle.style.cssText = 'color:#65676b;font-size:12px;margin-top:2px;';
    const ago = (t) => {
      if (!t) return '';
      const m = Math.round((Date.now() - t) / 60000);
      if (m < 1) return 'updated just now';
      if (m < 60) return `updated ${m}m ago`;
      const h = Math.round(m / 60);
      return h < 48 ? `updated ${h}h ago` : `updated ${Math.round(h / 24)}d ago`;
    };
    subtitle.textContent = inventory.length
      ? `${inventory.length} groups indexed · ${ago(updatedAt)}`
      : 'No groups indexed yet';
    // Nest the subtitle under the title text (inside the logo+text row) so it
    // lines up with the title, not with the logo.
    title.querySelector('#su-gsm-title-col').appendChild(subtitle);
    const closeBtn = document.createElement('button');
    closeBtn.textContent = '✕';
    closeBtn.style.cssText = 'background:#f0f2f5;border:none;color:#65676b;font-size:18px;width:36px;height:36px;border-radius:50%;cursor:pointer;transition:background 0.15s;';
    closeBtn.addEventListener('mouseenter', () => closeBtn.style.background = '#d8dadf');
    closeBtn.addEventListener('mouseleave', () => closeBtn.style.background = '#f0f2f5');
    closeBtn.addEventListener('click', () => modal.remove());
    // Right-hand header slot: the Presets button is inserted before ✕ further down
    // (only once we know the inventory isn't empty — see the early return below).
    const headerActions = document.createElement('div');
    headerActions.style.cssText = 'display:flex;align-items:center;gap:8px;flex-shrink:0;';
    headerActions.appendChild(closeBtn);
    header.appendChild(title);
    header.appendChild(headerActions);
    card.appendChild(header);

    // ---- Empty-inventory state ----
    if (!inventory.length) {
      const empty = document.createElement('div');
      empty.style.cssText = 'padding: 40px 28px; text-align: center;';
      empty.innerHTML = `
          <div style="font-size: 44px; margin-bottom: 12px;">📋</div>
          <div style="color:#050505;font-size:17px;font-weight:600;margin-bottom:6px;">Let's index your groups first</div>
          <div style="color:#65676b;font-size:14px;line-height:1.5;">
            Click <b>Load All</b> in the toolbar once — the extension will scroll through
            your whole group list and remember every group. After that, this search finds
            <b>all</b> your matching groups instantly (Facebook's own search only shows ~10).
          </div>`;
      const okBtn = document.createElement('button');
      okBtn.textContent = 'Got it';
      okBtn.style.cssText = 'margin-top:18px;background:#1877f2;color:white;border:none;border-radius:8px;padding:10px 28px;font-size:15px;font-weight:600;cursor:pointer;';
      okBtn.addEventListener('click', () => modal.remove());
      empty.appendChild(okBtn);
      card.appendChild(empty);
      document.body.appendChild(modal);
      wireBackdropDismiss(modal, () => modal.remove());
      return;
    }

    // ---- Search box ----
    const searchWrap = document.createElement('div');
    searchWrap.style.cssText = 'padding: 12px 20px 8px; flex-shrink: 0;';
    const searchInput = document.createElement('input');
    searchInput.type = 'text';
    searchInput.placeholder = 'Search your groups… e.g. "real estate"';
    searchInput.style.cssText = `
        width: 100%; box-sizing: border-box; background: #f0f2f5; border: 2px solid transparent;
        border-radius: 50px; padding: 10px 16px; font-size: 15px; color: #050505; outline: none;
        transition: border-color 0.15s, background 0.15s;`;
    searchInput.addEventListener('focus', () => { searchInput.style.borderColor = '#1877f2'; searchInput.style.background = '#fff'; });
    searchInput.addEventListener('blur', () => { searchInput.style.borderColor = 'transparent'; searchInput.style.background = '#f0f2f5'; });
    searchWrap.appendChild(searchInput);
    card.appendChild(searchWrap);

    // ---- Actions bar: match count + Select all / Reset ----
    const actionsBar = document.createElement('div');
    actionsBar.style.cssText = 'display:flex;align-items:center;justify-content:space-between;gap:8px;padding:0 20px 8px;flex-shrink:0;';
    const matchCount = document.createElement('div');
    matchCount.style.cssText = 'color:#65676b;font-size:13px;';
    const actionBtns = document.createElement('div');
    actionBtns.style.cssText = 'display:flex;gap:6px;';
    const selectAllBtn = document.createElement('button');
    selectAllBtn.style.cssText = 'background:#e7f3ff;color:#1877f2;border:none;border-radius:50px;padding:6px 14px;font-size:13px;font-weight:700;cursor:pointer;transition:background 0.15s,opacity 0.15s;';
    selectAllBtn.addEventListener('mouseenter', () => { if (!selectAllBtn.disabled) selectAllBtn.style.background = '#d4e9ff'; });
    selectAllBtn.addEventListener('mouseleave', () => selectAllBtn.style.background = '#e7f3ff');
    const resetBtn = document.createElement('button');
    resetBtn.textContent = '↺ Reset';
    resetBtn.style.cssText = 'background:#f0f2f5;color:#65676b;border:none;border-radius:50px;padding:6px 14px;font-size:13px;font-weight:700;cursor:pointer;transition:background 0.15s,opacity 0.15s;';
    resetBtn.addEventListener('mouseenter', () => { if (!resetBtn.disabled) resetBtn.style.background = '#d8dadf'; });
    resetBtn.addEventListener('mouseleave', () => resetBtn.style.background = '#f0f2f5');
    actionBtns.appendChild(selectAllBtn);
    actionBtns.appendChild(resetBtn);
    actionsBar.appendChild(matchCount);
    actionsBar.appendChild(actionBtns);
    card.appendChild(actionsBar);

    // ---- Results list ----
    const results = document.createElement('div');
    // min-height:0 (not 120px) — this is the ONLY child allowed to absorb the
    // card's height budget. A hard min here made the card's minimum content
    // height exceed its own max-height on short screens, and `overflow:hidden`
    // then clipped the footer clean off with no scrollbar to reach it.
    results.style.cssText = 'flex: 1 1 auto; overflow-y: auto; padding: 0 8px; min-height: 0;';
    card.appendChild(results);

    // ---- Selected chips ----
    const chipsWrap = document.createElement('div');
    chipsWrap.style.cssText = 'padding: 8px 20px 0; border-top: 1px solid #e4e6eb; flex-shrink: 0; display: none; max-height: min(110px, 20vh); overflow-y: auto;';
    const chipsHeader = document.createElement('div');
    chipsHeader.style.cssText = 'display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;';
    const chipsTitle = document.createElement('div');
    chipsTitle.style.cssText = 'color:#050505;font-size:13px;font-weight:600;';
    const clearAll = document.createElement('span');
    clearAll.textContent = 'Clear all';
    clearAll.style.cssText = 'color:#1877f2;font-size:13px;font-weight:600;cursor:pointer;';
    chipsHeader.appendChild(chipsTitle);
    chipsHeader.appendChild(clearAll);
    const chips = document.createElement('div');
    chips.style.cssText = 'display:flex;flex-wrap:wrap;gap:6px;padding-bottom:8px;';
    chipsWrap.appendChild(chipsHeader);
    chipsWrap.appendChild(chips);
    card.appendChild(chipsWrap);

    // ---- Footer ----
    const footer = document.createElement('div');
    footer.style.cssText = 'padding: 12px 20px; border-top: 1px solid #e4e6eb; display: flex; gap: 10px; flex-shrink: 0;';
    const presetBtn = document.createElement('button');
    presetBtn.style.cssText = 'flex:1;background:#e4e6eb;color:#050505;border:none;border-radius:8px;padding:11px 0;font-size:15px;font-weight:600;cursor:pointer;transition:background 0.15s,opacity 0.15s;';
    presetBtn.addEventListener('mouseenter', () => { if (!presetBtn.disabled) presetBtn.style.background = '#d8dadf'; });
    presetBtn.addEventListener('mouseleave', () => presetBtn.style.background = '#e4e6eb');
    const shareBtn = document.createElement('button');
    shareBtn.style.cssText = 'flex:1.4;background:#1877f2;color:white;border:none;border-radius:8px;padding:11px 0;font-size:15px;font-weight:600;cursor:pointer;transition:background 0.15s,opacity 0.15s;';
    shareBtn.addEventListener('mouseenter', () => { if (!shareBtn.disabled) shareBtn.style.background = '#166fe5'; });
    shareBtn.addEventListener('mouseleave', () => shareBtn.style.background = '#1877f2');
    footer.appendChild(presetBtn);
    footer.appendChild(shareBtn);
    card.appendChild(footer);

    // ---- Toast ----
    // Sits just above the footer (absolute, so it costs no layout height). After
    // an action that closes a panel — loading a preset — this is what tells the
    // user what happened, and it points their eye straight at the Share button.
    const toast = document.createElement('div');
    toast.style.cssText =
      'position:absolute;left:50%;bottom:74px;transform:translateX(-50%);z-index:6;' +
      'background:#31a24c;color:white;font-size:13px;font-weight:600;' +
      'border-radius:50px;padding:8px 16px;max-width:82%;text-align:center;' +
      'box-shadow:0 4px 14px rgba(0,0,0,0.22);display:none;pointer-events:none;';
    card.appendChild(toast);
    let toastTimer = null;
    function flashToast(text) {
      toast.textContent = text;
      toast.style.display = 'block';
      toast.style.animation = 'none';
      void toast.offsetWidth;
      toast.style.animation = 'suGsmToastIn 0.2s ease-out';
      clearTimeout(toastTimer);
      toastTimer = setTimeout(() => { toast.style.display = 'none'; }, 2200);
    }

    // ---- State + rendering ----
    // key -> {name, id}. Key is the group ID for anything picked from the inventory;
    // groups loaded from a preset that aren't in the inventory fall back to a
    // name-derived key so they can't collide with (or shadow) an ID-keyed entry.
    const selected = new Map();
    const keyOf = (ref) => ref.id || `nm:${norm(ref.name)}`;
    const AVATAR_COLORS = ['#1877f2', '#42b72a', '#f5533d', '#a333c8', '#fb8c00', '#00a4a6', '#e91e8c'];
    const avatarColor = (id) => {
      let h = 0;
      for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) >>> 0;
      return AVATAR_COLORS[h % AVATAR_COLORS.length];
    };

    function refreshFooter() {
      const n = selected.size;
      shareBtn.textContent = n ? `🚀 Share to ${n} Group${n > 1 ? 's' : ''}` : '🚀 Share';
      presetBtn.textContent = '💾 Save as Preset';
      shareBtn.disabled = presetBtn.disabled = n === 0;
      shareBtn.style.opacity = presetBtn.style.opacity = n === 0 ? '0.45' : '1';
      shareBtn.style.cursor = presetBtn.style.cursor = n === 0 ? 'not-allowed' : 'pointer';
      chipsTitle.textContent = `Your list (${n})`;
      chipsWrap.style.display = n ? 'block' : 'none';
      resetBtn.disabled = n === 0;
      resetBtn.style.opacity = n === 0 ? '0.45' : '1';
      resetBtn.style.cursor = n === 0 ? 'not-allowed' : 'pointer';
      if (n) { shareBtn.classList.remove('su-gsm-count-pulse'); void shareBtn.offsetWidth; shareBtn.classList.add('su-gsm-count-pulse'); }
    }

    function renderChips() {
      chips.textContent = '';
      selected.forEach((ref, key) => {
        const chip = document.createElement('span');
        chip.className = 'su-gsm-chip';
        chip.style.cssText = 'display:inline-flex;align-items:center;gap:6px;background:#e7f3ff;color:#1877f2;font-size:13px;font-weight:600;border-radius:50px;padding:5px 10px;max-width:240px;';
        const nameSpan = document.createElement('span');
        nameSpan.style.cssText = 'overflow:hidden;text-overflow:ellipsis;white-space:nowrap;';
        nameSpan.textContent = ref.name;
        const x = document.createElement('span');
        x.textContent = '✕';
        x.style.cssText = 'cursor:pointer;font-size:12px;opacity:0.7;';
        x.addEventListener('click', () => { selected.delete(key); renderChips(); refreshFooter(); renderResults(); });
        chip.appendChild(nameSpan);
        chip.appendChild(x);
        chips.appendChild(chip);
      });
    }

    const MAX_SHOWN = 60;
    let currentMatches = inventory;
    function renderResults() {
      const q = norm(searchInput.value || '');
      const matches = q
        ? inventory.filter(g => norm(g.name).includes(q))
        : inventory;
      currentMatches = matches;
      matchCount.textContent = q
        ? `${matches.length} match${matches.length === 1 ? '' : 'es'}`
        : `${inventory.length} groups`;
      // Select all applies to the FULL filtered set, not just the rows shown.
      selectAllBtn.textContent = `☑ Select all${q ? ` (${matches.length})` : ''}`;
      selectAllBtn.disabled = matches.length === 0;
      selectAllBtn.style.opacity = matches.length === 0 ? '0.45' : '1';
      selectAllBtn.style.cursor = matches.length === 0 ? 'not-allowed' : 'pointer';
      results.textContent = '';

      if (!matches.length) {
        const none = document.createElement('div');
        none.style.cssText = 'padding: 28px; text-align: center; color: #65676b; font-size: 14px;';
        none.textContent = `No groups matching "${searchInput.value}" — try a shorter word.`;
        results.appendChild(none);
        return;
      }

      matches.slice(0, MAX_SHOWN).forEach((g, idx) => {
        const row = document.createElement('div');
        row.className = 'su-gsm-row';
        row.style.cssText = 'display:flex;align-items:center;gap:12px;padding:8px 12px;border-radius:8px;cursor:pointer;transition:background 0.12s;';
        row.style.animationDelay = `${Math.min(idx * 18, 250)}ms`;

        const av = document.createElement('div');
        av.style.cssText = `width:36px;height:36px;border-radius:50%;background:${avatarColor(g.id)};color:white;display:flex;align-items:center;justify-content:center;font-size:16px;font-weight:700;flex-shrink:0;`;
        av.textContent = (g.name[0] || '?').toUpperCase();

        const nm = document.createElement('div');
        nm.style.cssText = 'flex:1;color:#050505;font-size:15px;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;';
        nm.textContent = g.name;

        const btn = document.createElement('button');
        const isSel = selected.has(g.id);
        btn.textContent = isSel ? '✓ Added' : '+ Add';
        btn.style.cssText = `border:none;border-radius:50px;padding:6px 14px;font-size:13px;font-weight:700;cursor:pointer;flex-shrink:0;transition:background 0.15s,color 0.15s,transform 0.15s;` +
          (isSel ? 'background:#e6f4ea;color:#31a24c;' : 'background:#e7f3ff;color:#1877f2;');

        const toggle = () => {
          if (selected.has(g.id)) selected.delete(g.id);
          else selected.set(g.id, { name: g.name, id: g.id });
          renderChips(); refreshFooter();
          const now = selected.has(g.id);
          btn.textContent = now ? '✓ Added' : '+ Add';
          btn.style.background = now ? '#e6f4ea' : '#e7f3ff';
          btn.style.color = now ? '#31a24c' : '#1877f2';
          btn.style.transform = 'scale(1.12)';
          setTimeout(() => btn.style.transform = 'scale(1)', 140);
        };
        row.addEventListener('click', (e) => { e.stopPropagation(); toggle(); });

        row.appendChild(av);
        row.appendChild(nm);
        row.appendChild(btn);
        results.appendChild(row);
      });

      if (matches.length > MAX_SHOWN) {
        const more = document.createElement('div');
        more.style.cssText = 'padding: 10px; text-align: center; color: #65676b; font-size: 13px;';
        more.textContent = `Showing ${MAX_SHOWN} of ${matches.length} — keep typing to narrow it down`;
        results.appendChild(more);
      }
    }

    // ---- Presets: reachable from inside the picker (header button) ----
    // Saved group lists used to be reachable ONLY from the toolbar's Presets button,
    // so once this picker was open there was no way to pull one in — you had to close
    // everything and start over. The header button drops a panel under the header and
    // MERGES a preset's groups into the current selection, so a preset composes with
    // hand-picked/searched groups instead of replacing them.
    const layersSvg = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;"><path d="M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z"/><path d="m22 17.65-9.17 4.16a2 2 0 0 1-1.66 0L2 17.65"/><path d="m22 12.65-9.17 4.16a2 2 0 0 1-1.66 0L2 12.65"/></svg>';

    const presetsBtn = document.createElement('button');
    presetsBtn.id = 'su-gsm-presets-btn';
    presetsBtn.type = 'button';
    presetsBtn.title = 'Load a saved group list';
    presetsBtn.style.cssText = 'display:flex;align-items:center;gap:6px;border:none;border-radius:50px;padding:8px 14px;font-size:14px;font-weight:600;cursor:pointer;transition:background 0.15s,color 0.15s;';
    headerActions.insertBefore(presetsBtn, closeBtn);

    // The panel is an OVERLAY dropdown anchored under the header, not a flex child
    // of the card. As an in-flow child it added its own height to the card's
    // minimum, which (with the card capped at 82vh and clipping its overflow)
    // pushed the Share/Save footer off-screen the moment it opened — the whole
    // reason this picker felt like a dead end once a preset was loaded.
    const presetsPanel = document.createElement('div');
    presetsPanel.style.cssText =
      'display:none;position:absolute;top:100%;left:0;right:0;z-index:5;' +
      'background:#f7f8fa;border-bottom:1px solid #e4e6eb;border-radius:0 0 8px 8px;' +
      'max-height:min(300px,42vh);overflow-y:auto;padding:8px 12px;' +
      'box-shadow:0 10px 24px rgba(0,0,0,0.14);';
    header.appendChild(presetsPanel);

    let presetsOpen = false;
    let presetCount = 0;

    function paintPresetsBtn() {
      presetsBtn.innerHTML = `${layersSvg}<span>Presets</span>` +
        (presetCount ? `<span style="background:rgba(0,0,0,0.08);border-radius:50px;padding:1px 7px;font-size:11px;font-weight:700;">${presetCount}</span>` : '');
      presetsBtn.style.background = presetsOpen ? '#e7f3ff' : '#e4e6eb';
      presetsBtn.style.color = presetsOpen ? '#1877f2' : '#050505';
    }
    presetsBtn.addEventListener('mouseenter', () => { if (!presetsOpen) presetsBtn.style.background = '#d8dadf'; });
    presetsBtn.addEventListener('mouseleave', () => { if (!presetsOpen) presetsBtn.style.background = '#e4e6eb'; });

    // A preset's groups as {name, id} refs. Entries that already carry an ID keep it;
    // legacy name-only entries have theirs recovered from the inventory already
    // loaded by this picker (see makePresetRefResolver for why that consumes one
    // candidate per entry rather than always taking the first match).
    const presetRefs = makePresetRefResolver(inventory, norm);

    async function renderPresetsPanel() {
      const stored = await new Promise(resolve => chrome.storage.local.get(['groupPresets'], resolve));
      const presets = (stored.groupPresets || []).slice();
      // Newest first — same ordering as showGroupPresetsModal.
      presets.sort((a, b) =>
        (new Date(b.createdAt || 0) - new Date(a.createdAt || 0)) ||
        ((Number(b.id) || 0) - (Number(a.id) || 0)));
      presetCount = presets.length;
      paintPresetsBtn();
      presetsPanel.textContent = '';

      if (!presets.length) {
        const empty = document.createElement('div');
        empty.style.cssText = 'padding:18px 10px;text-align:center;color:#65676b;font-size:13px;line-height:1.5;';
        empty.innerHTML = 'No saved group lists yet.<br>Pick your groups below, then hit <b style="color:#050505;">💾 Save as Preset</b> to reuse them in one click.';
        presetsPanel.appendChild(empty);
        return;
      }

      presets.forEach(preset => {
        const refs = presetRefs(preset);
        const row = document.createElement('div');
        row.className = 'su-gsm-row';
        row.style.cssText = 'display:flex;align-items:center;gap:12px;padding:8px 10px;border-radius:8px;cursor:pointer;background:#fff;margin-bottom:6px;border:1px solid #e4e6eb;';

        const txt = document.createElement('div');
        txt.style.cssText = 'flex:1;min-width:0;';
        const nm = document.createElement('div');
        nm.style.cssText = 'color:#050505;font-size:14px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;';
        nm.textContent = preset.name;
        const sub = document.createElement('div');
        sub.style.cssText = 'color:#65676b;font-size:12px;margin-top:1px;';
        sub.textContent = `${refs.length} group${refs.length === 1 ? '' : 's'}`;
        txt.appendChild(nm);
        txt.appendChild(sub);

        const btn = document.createElement('button');
        btn.style.cssText = 'border:none;border-radius:50px;padding:6px 14px;font-size:13px;font-weight:700;cursor:pointer;flex-shrink:0;transition:background 0.15s,color 0.15s;';
        const allIn = () => refs.length > 0 && refs.every(r => selected.has(keyOf(r)));
        const paint = () => {
          const done = allIn();
          btn.textContent = done ? '✓ Added' : '+ Add all';
          btn.style.background = done ? '#e6f4ea' : '#e7f3ff';
          btn.style.color = done ? '#31a24c' : '#1877f2';
        };
        paint();

        row.addEventListener('click', (e) => {
          e.stopPropagation();
          if (!refs.length) return;
          const before = selected.size;
          // Merge-only: adding a preset never drops groups the user already picked.
          refs.forEach(r => selected.set(keyOf(r), r));
          const added = selected.size - before;
          paint();
          renderChips(); refreshFooter(); renderResults();
          flashToast(added
            ? `Added ${added} group${added === 1 ? '' : 's'} from “${preset.name}”`
            : `“${preset.name}” is already in your list`);
          // Then close the panel. Holding it open hid the list and the footer
          // behind it, so the user had no idea the click had done anything.
          // Short delay so the row's ✓ Added state is actually seen first.
          setTimeout(() => { if (presetsOpen) setPresetsOpen(false); }, 260);
        });

        row.appendChild(txt);
        row.appendChild(btn);
        presetsPanel.appendChild(row);
      });

      // Escape hatch to the full presets surface (rename/delete/share straight from
      // a preset) — that modal rebuilds from storage, so handing off is safe.
      const manage = document.createElement('div');
      manage.style.cssText = 'text-align:center;padding:4px 0 2px;';
      const manageLink = document.createElement('span');
      manageLink.textContent = 'Manage presets →';
      manageLink.style.cssText = 'color:#1877f2;font-size:13px;font-weight:600;cursor:pointer;';
      manageLink.addEventListener('click', (e) => {
        e.stopPropagation();
        modal.remove();
        showGroupPresetsModal();
      });
      manage.appendChild(manageLink);
      presetsPanel.appendChild(manage);
    }

    function setPresetsOpen(open) {
      presetsOpen = open;
      presetsPanel.style.display = open ? 'block' : 'none';
      paintPresetsBtn();
      if (open) {
        // The card clips its overflow, so an overlay taller than the space below
        // the header would have unreachable rows. Measure and cap instead of
        // trusting a fixed vh — the card's height follows its content.
        const avail = card.clientHeight - header.offsetHeight - 12;
        presetsPanel.style.maxHeight = Math.max(140, Math.min(300, avail)) + 'px';
        presetsPanel.scrollTop = 0;
        presetsPanel.style.animation = 'suGsmDropIn 0.16s ease-out';
        renderPresetsPanel();
      }
    }
    presetsBtn.addEventListener('click', (e) => { e.stopPropagation(); setPresetsOpen(!presetsOpen); });

    // Initial badge count only — the panel itself renders on first open, and
    // re-reads storage every time, so presets saved elsewhere always show up.
    chrome.storage.local.get(['groupPresets'], (stored) => {
      presetCount = (stored.groupPresets || []).length;
      paintPresetsBtn();
    });
    paintPresetsBtn();

    clearAll.addEventListener('click', () => { selected.clear(); renderChips(); refreshFooter(); renderResults(); });

    selectAllBtn.addEventListener('click', () => {
      if (!currentMatches.length) return;
      currentMatches.forEach(g => selected.set(g.id, { name: g.name, id: g.id }));
      renderChips(); refreshFooter(); renderResults();
    });
    resetBtn.addEventListener('click', () => {
      if (!selected.size) return;
      selected.clear();
      renderChips(); refreshFooter(); renderResults();
    });

    let searchDebounce = null;
    searchInput.addEventListener('input', () => {
      clearTimeout(searchDebounce);
      searchDebounce = setTimeout(renderResults, 120);
    });

    const selectedRefs = () => Array.from(selected.values(), r => ({ name: r.name, id: r.id || null }));

    shareBtn.addEventListener('click', () => {
      if (!selected.size) return;
      const refs = selectedRefs();
      modal.remove();
      // Hands off to the existing share modal — content, scheduling and the
      // save-as-preset CTA all live there already.
      showPostContentModal(refs);
    });

    presetBtn.addEventListener('click', () => {
      if (!selected.size) return;
      const refs = selectedRefs();
      modal.remove();
      showSaveGroupListPresetDialog(refs);
    });

    wireBackdropDismiss(modal, () => modal.remove());
    // Clicking anywhere in the card dismisses the presets panel — INCLUDING the
    // panel's own dead space. The panel overlays the search box, so a click that
    // does nothing would otherwise leave the user stuck looking at it. Rows and
    // the Manage link stop propagation themselves, so they still work normally.
    card.addEventListener('click', () => { if (presetsOpen) setPresetsOpen(false); });
    // Esc closes the presets panel first, the modal second.
    const onKey = (e) => {
      if (e.key !== 'Escape') return;
      if (presetsOpen) { setPresetsOpen(false); return; }
      modal.remove();
      document.removeEventListener('keydown', onKey, true);
    };
    document.addEventListener('keydown', onKey, true);

    document.body.appendChild(modal);
    renderResults();
    refreshFooter();
    setTimeout(() => searchInput.focus(), 150);
  }

  // ===========================================================================
  // Post-share success modal (v17.8)
  // ===========================================================================

  /**
   * The nine upsell angles shown after a clean run, rotated one per qualifying
   * share so a daily user never reads the same line twice running — a single fixed
   * string stops being read after the second time (banner blindness), which is the
   * whole reason this is an array and not a constant.
   *
   * `{count}` and `{minutes_saved}` are substituted at render time. Every string is
   * authored HERE and rendered with `textContent`: nothing from Facebook, the user,
   * or a group name is ever interpolated into this copy.
   *
   * COPY RULE — what the upgrade actually promises (v17.9):
   * The payoff is that NO tool is visible, not that a better-looking tool is. An
   * agent's post has to read as if they sat down and wrote it in that group
   * themselves. Five of these variants used to sell the opposite ("looks like it
   * came straight from a custom agency tool", "100% bespoke", "completely
   * custom") — that tells their buyers and their competitors that the listing was
   * blasted out by software, which is the exact thing they're paying to hide.
   * Never write "agency tool", "bespoke", "custom tool", "automated", or any
   * phrasing that implies a system posted it. The words to reach for are
   * hand-posted, personally, typed it yourself, nothing pointing back to an app.
   */
  const SUCCESS_VARIANTS = [
    // 1 — Client presentation
    'Want your listing posts to look 100% clean and unbranded to prospective buyers and clients? Remove the watermark link today.',
    // 2 — Facebook algorithm
    "Did you know Facebook's algorithm treats posts with external links more harshly? Upgrade to Pro to remove the watermark link and protect your post reach.",
    // 3 — Pure ROI
    "Boom—{minutes_saved} minutes saved! You're crushing it. Ready to drop the watermark link so every post reads like you sat down and wrote it in that group yourself?",
    // 4 — Speed to market
    'Speed closes deals! Your listing is live across {count} groups. Upgrade to Pro to drop the watermark link — so it looks like you posted in every one of them personally.',
    // 5 — Keep your method to yourself
    'Don’t let a free watermark tell everyone how you posted. Upgrade to Pro and your listings show up looking hand-posted, one group at a time.',
    // 6 — Cost vs. value
    'Removing the watermark costs less than one coffee with a client. Upgrade to Pro and every share looks like you typed it out yourself.',
    // 7 — Admin approval
    "Here's a quick heads-up: some group admins instantly decline posts that contain external links. Don't let link-blocking admins stop your momentum—upgrade to Pro to remove the watermark link and get approved every time.",
    // 8 — 20-year ROI
    'If your buyer comes from even ONE of those {count} groups, you just covered the cost of going Pro for the next 20 years. Upgrade now so every post looks personally written, with nothing pointing back to an app.',
    // 9 — Reverse psychology
    "Honestly, if you don't remove the watermark, we get free advertising every time you share... so please, don't upgrade to Pro! We're a team: you get property exposure, and we get brand exposure! 😉 (Or upgrade now to keep all the spotlight on your listing)."
  ];

  /** Storage key holding the index of the variant shown LAST — next display is +1. */
  const SUCCESS_VARIANT_KEY = 'last_seen_variant_index';

  /** Hand-posting one group — open share sheet, find group, paste, post — costs ~90s. */
  const MINUTES_SAVED_PER_GROUP = 1.5;

  /**
   * Advances the rotation and returns the index to render now.
   *
   * The write happens here rather than on modal close: a user who closes the tab
   * mid-celebration would otherwise see the same variant again next time, which is
   * exactly the repetition the rotation exists to avoid. Every failure path resolves
   * to 0 — a cosmetic upsell must never be able to throw into the share's epilogue.
   */
  function nextSuccessVariantIndex() {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get([SUCCESS_VARIANT_KEY], (result) => {
          if (chrome.runtime.lastError || !result) { resolve(0); return; }
          const last = Number.isInteger(result[SUCCESS_VARIANT_KEY]) ? result[SUCCESS_VARIANT_KEY] : -1;
          const next = (((last + 1) % SUCCESS_VARIANTS.length) + SUCCESS_VARIANTS.length) % SUCCESS_VARIANTS.length;
          chrome.storage.local.set({ [SUCCESS_VARIANT_KEY]: next }, () => { void chrome.runtime.lastError; });
          resolve(next);
        });
      } catch (e) {
        resolve(0);
      }
    });
  }

  /** `15` not `15.0`, `10.5` not `10.500000000000002`. */
  function formatMinutesSaved(minutes) {
    const rounded = Math.round(minutes * 10) / 10;
    return Number.isInteger(rounded) ? String(rounded) : rounded.toFixed(1);
  }

  /**
   * Celebrates a run where EVERY group landed, and uses that moment — the one
   * moment the user is provably happy with the product — to make the watermark case.
   *
   * Two gates the caller does not own, kept here so no future call site can skip them:
   *
   *  1. **Licensed users never see it.** The CTA is a Remove Watermark affordance, so
   *     its visibility comes from `ExpiredOverlay.isWatermarkActive()` — the single
   *     watermark predicate — never from a locally re-derived condition. A paying
   *     user's clean run gets no modal at all rather than an upsell for something
   *     they already bought.
   *  2. **The CTA checks before it sells.** It is wired by
   *     `ExpiredOverlay.wireRemoveWatermarkButton()` like every other upgrade button:
   *     `Checking…` → re-read the server → a user whose licence merely failed to land
   *     locally is repaired in place and never sees a checkout page. If that helper
   *     is unavailable the CTA is omitted entirely — a sell-without-checking button
   *     is worse than no button.
   *
   * @param {number} count Groups posted to. Only called when count === total attempted.
   */
  async function showPostShareSuccessModal(count) {
    const groups = Number(count);
    if (!Number.isFinite(groups) || groups < 1) return;

    const ExpiredOverlay = window.ExpiredOverlay;
    if (!ExpiredOverlay || typeof ExpiredOverlay.isWatermarkActive !== 'function') return;
    if (!(await ExpiredOverlay.isWatermarkActive())) return;

    const existing = document.getElementById('share-unlimited-success-modal');
    if (existing) existing.remove();

    const minutesSaved = formatMinutesSaved(groups * MINUTES_SAVED_PER_GROUP);
    const variantIndex = await nextSuccessVariantIndex();
    const variantText = SUCCESS_VARIANTS[variantIndex]
      .replace(/\{count\}/g, String(groups))
      .replace(/\{minutes_saved\}/g, minutesSaved);

    const canSell = typeof ExpiredOverlay.wireRemoveWatermarkButton === 'function';

    const modal = document.createElement('div');
    modal.id = 'share-unlimited-success-modal';
    modal.style.cssText = `
      position: fixed; top: 0; left: 0; width: 100%; height: 100%;
      background: rgba(0, 0, 0, 0.5); z-index: 1000000000;
      display: flex; align-items: center; justify-content: center;
      opacity: 0; transition: opacity 0.2s ease-out;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    `;

    // Height-capped like the share modal (v17.1): only the body scrolls, so a long
    // variant can never push the CTA below the fold on a laptop.
    const card = document.createElement('div');
    card.style.cssText = `
      position: relative; background: white; border-radius: 12px;
      width: 90%; max-width: 460px; max-height: min(88vh, 660px);
      display: flex; flex-direction: column;
      box-shadow: 0 12px 40px rgba(0,0,0,0.3);
    `;

    card.innerHTML = `
      <button id="su-success-x" aria-label="Close" style="
        position: absolute; top: 12px; right: 12px; width: 32px; height: 32px;
        border: none; border-radius: 50%; background: #f0f2f5; color: #050505;
        font-size: 16px; line-height: 1; cursor: pointer; transition: background 0.2s;
      ">✕</button>

      <div style="flex: 1 1 auto; overflow-y: auto; padding: 28px 24px 4px; text-align: center;">
        <div style="font-size: 44px; line-height: 1; margin-bottom: 12px;">🎉</div>
        <h2 style="margin: 0 0 12px; color: #050505; font-size: 20px; font-weight: 700; line-height: 1.3;">
          ${groups}/${groups} Groups Posted Successfully!
        </h2>

        <div style="
          display: inline-block; background: #e7f3ff; color: #1877f2;
          font-size: 13px; font-weight: 600; line-height: 1.4;
          padding: 8px 14px; border-radius: 20px; margin-bottom: 18px;
        ">⚡ You just saved roughly ${minutesSaved} minutes of manual work!</div>

        <div id="su-success-copy" style="
          background: #f0f2f5; border-left: 3px solid #1877f2; border-radius: 8px;
          padding: 14px 16px; margin-bottom: 18px; text-align: left;
          font-size: 13px; line-height: 1.6; color: #050505;
        "></div>
      </div>

      <div style="flex: 0 0 auto; padding: 0 24px 22px;">
        <div id="su-success-cta-wrap" style="
          display: ${canSell ? 'flex' : 'none'}; align-items: center; justify-content: center;
          min-height: 44px; border: 1px solid transparent; border-radius: 8px;
          overflow: hidden; margin-bottom: 10px; transition: opacity 0.5s;
        ">
          <button id="su-success-cta" style="
            flex: 1; background: #1877f2; border: none; color: white;
            padding: 12px 18px; border-radius: 8px;
            font-size: 15px; font-weight: 700; cursor: pointer; transition: background 0.2s;
          ">Upgrade to Pro — Remove Watermark</button>
        </div>
        <button id="su-success-done" style="
          width: 100%; background: #e4e6eb; border: none; color: #050505;
          padding: 10px 18px; border-radius: 8px;
          font-size: 14px; font-weight: 600; cursor: pointer; transition: background 0.2s;
        ">Done</button>
      </div>
    `;

    // Authored copy, but set as TEXT — the variants carry apostrophes, an emoji and
    // an em dash, and none of them are markup.
    card.querySelector('#su-success-copy').textContent = variantText;

    modal.appendChild(card);
    document.body.appendChild(modal);
    requestAnimationFrame(() => { modal.style.opacity = '1'; });

    let closed = false;
    const close = () => {
      if (closed) return;
      closed = true;
      document.removeEventListener('keydown', onKey, true);
      modal.style.opacity = '0';
      setTimeout(() => modal.remove(), 200);
    };
    const onKey = (e) => { if (e.key === 'Escape') close(); };
    document.addEventListener('keydown', onKey, true);

    const xBtn = card.querySelector('#su-success-x');
    const doneBtn = card.querySelector('#su-success-done');
    const ctaWrap = card.querySelector('#su-success-cta-wrap');
    const ctaBtn = card.querySelector('#su-success-cta');

    xBtn.addEventListener('mouseenter', () => { xBtn.style.background = '#d8dadf'; });
    xBtn.addEventListener('mouseleave', () => { xBtn.style.background = '#f0f2f5'; });
    xBtn.addEventListener('click', close);

    doneBtn.addEventListener('mouseenter', () => { doneBtn.style.background = '#d8dadf'; });
    doneBtn.addEventListener('mouseleave', () => { doneBtn.style.background = '#e4e6eb'; });
    doneBtn.addEventListener('click', close);

    // Backdrop click closes; a click inside the card must not.
    wireBackdropDismiss(modal, () => close());

    if (canSell) {
      ctaBtn.addEventListener('mouseenter', () => { ctaBtn.style.background = '#166fe5'; });
      ctaBtn.addEventListener('mouseleave', () => { ctaBtn.style.background = '#1877f2'; });
      // Checks the server before it sells, and repairs a stale licence in place —
      // on success it replaces this wrapper with "✓ License found", leaving the
      // celebration and the Done button intact.
      ExpiredOverlay.wireRemoveWatermarkButton(ctaBtn, ctaWrap);
    }

    console.log(`🎉 MGSA: clean run — ${groups}/${groups} groups, ~${minutesSaved} min saved, upsell variant #${variantIndex + 1}`);
  }

  // Keep the Group Presets modal itself live if it's open when a preset is
  // created/updated/deleted elsewhere (popup, another tab, this tab's own
  // Save-Preset dialog) — showGroupPresetsModal() always rebuilds fresh from
  // storage, so re-invoking it is a safe, idempotent refresh.
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.groupPresets &&
        document.getElementById('share-unlimited-group-presets-modal')) {
      showGroupPresetsModal();
    }
  });

  // Export functions
  Object.assign(UI, {
    showLicenseExpiredModal,
    showGroupSearchModal,
    showPostContentModal,
    showGroupPresetsModal,
    showMergedPresetsConfirmation,
    showSaveGroupListPresetDialog,
    showSavePostTemplateDialog,
    showApplyPostTemplateDialog,
    showOneClickPresetsModal,
    showScheduleDisclaimerModal,
    showSchedulePickerModal,
    showPostShareSuccessModal
  });

})();
