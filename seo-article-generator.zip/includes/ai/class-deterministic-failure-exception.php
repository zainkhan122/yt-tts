<?php
/**
 * Deterministic Failure Exception
 *
 * Thrown when a generation job fails for reasons that are guaranteed to 
 * repeat on retry (e.g. malformed AI payload, sanity check failure).
 *
 * @package SEO_Article_Generator\AI
 */

namespace SEO_Article_Generator\AI;

use SEO_Article_Generator\AI_Exception;

if (!defined('ABSPATH')) {
    exit;
}

class DeterministicFailureException extends AI_Exception
{
    /**
     * @var array Optional context or debug data
     */
    protected $context;

    public function __construct($message = "", $code = 0, array $context = [], \Throwable $previous = null)
    {
        $this->context = $context;
        parent::__construct($message, $code, $previous);
    }

    public function getContext(): array
    {
        return $this->context;
    }
}
