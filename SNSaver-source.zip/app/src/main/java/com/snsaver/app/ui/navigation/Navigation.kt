package com.snsaver.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.snsaver.app.ui.screens.detail.DetailScreen
import com.snsaver.app.ui.screens.gallery.GalleryScreen
import com.snsaver.app.ui.screens.inbox.InboxScreen
import com.snsaver.app.ui.screens.settings.SettingsScreen

object Routes {
    const val INBOX = "inbox"
    const val GALLERY = "gallery"
    const val SETTINGS = "settings"
    const val DETAIL = "detail/{id}"
    fun detail(id: Long) = "detail/$id"
}

@Composable
fun AppNavigation(nav: NavHostController, modifier: Modifier = Modifier) {
    NavHost(navController = nav, startDestination = Routes.INBOX, modifier = modifier) {
        composable(Routes.INBOX) {
            InboxScreen(onItem = { nav.navigate(Routes.detail(it)) })
        }
        composable(Routes.GALLERY) {
            GalleryScreen(onItem = { nav.navigate(Routes.detail(it)) })
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(onBack = { nav.popBackStack() })
        }
        composable(
            route = Routes.DETAIL,
            arguments = listOf(navArgument("id") { type = NavType.LongType })
        ) { entry ->
            val id = entry.arguments?.getLong("id") ?: return@composable
            DetailScreen(id = id, onBack = { nav.popBackStack() })
        }
    }
}
