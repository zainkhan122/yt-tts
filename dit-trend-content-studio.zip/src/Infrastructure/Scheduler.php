<?php

/**
 * Job Handler
 *
 * @package DIT_TrendStudio
 * @MODIFIED 2025-12-13 - Forked from SEO Article Generator, adapted for magazine content
 * @MODIFIED 2025-12-14 - Store block_markup at generation, add get_job_for_publish with ownership check
 */

namespace DIT\TrendStudio\Infrastructure;

use DIT\TrendStudio\Integrations\Gemini\Client as AI_Client;
use DIT\TrendStudio\Content\PromptEngine;
use DIT\TrendStudio\Core\Research_Orchestrator as Workflow_Orchestrator;
use DIT\TrendStudio\Core\Content_Auditor;
use DIT\TrendStudio\Content\ContentPipeline;
use DIT\TrendStudio\Content\PostComposer as Content_Formatter;
use DIT\TrendStudio\Security\Validator;
use DIT\TrendStudio\Infrastructure\Logger;
use DIT\TrendStudio\Infrastructure\API_Error_Parser;
use DIT\TrendStudio\Infrastructure\Quota_State_Manager;
use DIT\TrendStudio\Infrastructure\Backoff_Strategy;
use DIT\TrendStudio\SEO\MetadataGenerator;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Background job processing with Action Scheduler
 */
class Scheduler
{
    /**
     * Job state enumeration
     * @var string[]
     */
    const STATE_BRIEFING   = 'briefing';
    const STATE_RESEARCHING = 'researching';
    const STATE_OUTLINING  = 'outlining';
    const STATE_DRAFTING   = 'drafting';
    const STATE_REVIEWING  = 'reviewing';
    const STATE_COMPLETED  = 'completed';

    /**
     * Advance job to next state
     * @param int $job_id
     * @return void
     */
    public function advance_state($job_id)
    {
        $job = $this->get_job_status($job_id);
        $current = $job['status'];
        $next = $this->next_state($current);
        if ($next) {
            $this->update_job_status($job_id, $next);
        }
    }

    /**
     * Get current state of a job
     * @param int $job_id
     * @return string|null
     */
    public function get_current_state($job_id)
    {
        $job = $this->get_job_status($job_id);
        return $job ? $job['status'] : null;
    }

    /**
     * Determine next state based on current
     * @param string $current
     * @return string|null
     */
    private function next_state($current)
    {
        $order = [
            self::STATE_BRIEFING,
            self::STATE_RESEARCHING,
            self::STATE_OUTLINING,
            self::STATE_DRAFTING,
            self::STATE_REVIEWING,
            self::STATE_COMPLETED,
        ];
        $idx = array_search($current, $order, true);
        return ($idx !== false && $idx < count($order) - 1) ? $order[$idx + 1] : null;
    }


    /**
     * Logger instance
     *
     * @var Logger
     */
    private $logger;

    /**
     * Constructor
     *
     * @param Logger $logger Logger instance
     */
    public function __construct(Logger $logger)
    {
        $this->logger = $logger;
        $this->register_hooks();
    }

    /**
     * Quota probe runner.
     *
     * @param string $provider_slug
     * @return void
     */
    public function quota_probe(string $provider_slug = 'gemini')
    {
        $provider_slug = sanitize_key($provider_slug);

        if (!class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Pause_Manager')) {
            return;
        }

        if (!\DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::is_paused($provider_slug)) {
            return;
        }

		// Probe supported providers
	$built_in = array('gemini', 'custom');
	$is_known = in_array($provider_slug, $built_in, true);
	if (!$is_known && class_exists('DIT\\TrendStudio\\Infrastructure\\AI_Provider_Factory')) {
		$custom_providers = AI_Provider_Factory::get_custom_providers();
		$is_known = isset($custom_providers[$provider_slug]);
	}
	if (!$is_known) {
		return;
	}

	$api_key = '';
	$client = null;

	try {
		$create_input = [];
		if (!in_array($provider_slug, $built_in, true)) {
			$create_input['custom_provider_id'] = $provider_slug;
		}
		$client = AI_Provider_Factory::create($provider_slug, $this->logger, $create_input);
		} catch (\Exception $e) {
			$this->logger->warning('Quota probe aborted: ' . $e->getMessage());
			return;
		}

        try {
            $ok = ($client && method_exists($client, 'probe_quota')) ? $client->probe_quota() : false;

            if ($ok) {
                \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::clear($provider_slug);
                $this->logger->info('Quota probe OK: Provider quota recovered. Cleared pause.', array('provider' => $provider_slug));
                return;
            }

            // Still blocked: extend pause and probe again later.
            $until = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::pause($provider_slug, 'quota_probe_failed', 3600, 86400);
            $delay = max(900, min(3600, ($until - time())));
            $delay += wp_rand(5, 30); // jitter

            $this->logger->warning('Quota probe failed: Provider still blocked. Next probe scheduled.', [
                'delay_sec' => $delay,
            ]);

            if (function_exists('as_schedule_single_action')) {
                as_schedule_single_action(time() + $delay, 'dit_ts_quota_probe', array($provider_slug));
            }
        } catch (\Throwable $e) {
            $this->logger->error('Quota probe crashed: ' . $e->getMessage());
        }
    }

    /**
     * Register Action Scheduler hooks
     *
     * @return void
     */
    public function register_hooks()
    {
        add_action('dit_ts_process_job', array($this, 'process_job'));

        // @MODIFIED 2026-02-25 - Quota probe runner (clears provider pause when quota recovers)
        add_action('dit_ts_quota_probe', array($this, 'quota_probe'), 10, 1);

        // @MODIFIED 2026-02-26 - Pending drain runner (resumes orphaned pending jobs after Master Switch re-enable)
        add_action('dit_ts_resume_pending_jobs', array($this, 'resume_pending_jobs'), 10, 1);

        // @MODIFIED 2026-03-07 - Social Queue Handler for 4:5 collage generation
        add_action('dit_ts_generate_social_collage', array($this, 'process_social_collage_job'));

        // @MODIFIED 2026-06-01 - Publish watchdog: recovers "Missed schedule" posts.
        // Fires every 2 minutes via Action Scheduler (registered in Plugin::ensure_publish_watchdog()).
        add_action('dit_ts_publish_due_posts', array($this, 'publish_due_scheduled_posts'), 10, 1);
    }

    /**
     * Resume orphaned pending jobs (one-at-a-time)
     *
     * When Master AI Automation is toggled OFF, we unschedule all queued job runner actions.
     * On re-enable, this drains pending jobs safely without creating large Action Scheduler backlogs.
     *
     * @since 2.15.20
     * @MODIFIED 2026-02-26 - Added pending drain runner.
     *
     * @param int $batch Number of jobs to enqueue (keep 1 for serialized processing)
     * @return void
     */
    public function resume_pending_jobs($batch = 1)
    {
        $batch = max(1, (int) $batch);

        $enabled = (int) get_option('dit_ts_enable_ai_automation', '1');
        if (!$enabled) {
            return;
        }

        if (!get_transient('dit_ts_pending_drain_active')) {
            return;
        }

        // Do not enqueue while another job is running.
        if ($this->get_running_jobs_count(0, false) > 0) {
            if (function_exists('as_schedule_single_action')) {
                as_schedule_single_action(time() + 120, 'dit_ts_resume_pending_jobs', array($batch));
            }
            return;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'dit_ts_jobs';

        $job_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT id FROM {$table} WHERE status = %s ORDER BY created_at ASC LIMIT %d",
            'pending',
            $batch
        ));

        if (empty($job_ids)) {
            delete_transient('dit_ts_pending_drain_active');
            return;
        }

        foreach ($job_ids as $job_id) {
            $job_id = (int) $job_id;
            if ($job_id <= 0) {
                continue;
            }

            if (function_exists('as_has_scheduled_action')) {
                if (as_has_scheduled_action('dit_ts_process_job', array($job_id))) {
                    continue;
                }
            }

            if (function_exists('as_enqueue_async_action')) {
                as_enqueue_async_action('dit_ts_process_job', array($job_id));
                $this->logger->info("Pending drain: Enqueued job {$job_id} after Master Switch re-enable.");
            } elseif (function_exists('as_schedule_single_action')) {
                as_schedule_single_action(time() + 10, 'dit_ts_process_job', array($job_id));
                $this->logger->info("Pending drain: Scheduled job {$job_id} after Master Switch re-enable.");
            } else {
                // Fallback (rare): run synchronously
                $this->logger->info("Pending drain: Running job {$job_id} synchronously (no Action Scheduler).");
                $this->process_job($job_id);
            }
        }
    }


    /**
     * Schedule article generation job
     *
     * @param array $input_data Input data
     * @param int   $user_id    User ID
     * @return int Job ID
     */
    public function schedule_generation($input_data, $user_id)
    {
        // @MODIFIED 2026-02-11 - Defensive check: Do not schedule if AI Automation is globally disabled
        $is_automation_enabled = get_option('dit_ts_enable_ai_automation', '1');
        if (!$is_automation_enabled && empty($input_data['is_manual_override'])) {
            $this->logger->info("Manual Generation aborted: AI Automation is globally DISABLED.");
            throw new \Exception('AI Automation is globally DISABLED. Please enable it in Settings.');
        }

        global $wpdb;

        $table = $wpdb->prefix . 'dit_ts_jobs';

        // @MODIFIED 2026-05-06 - Retire stale failed/pending jobs for the same idea before creating a new one.
        // When a post is re-queued after failure, old job rows linger with status='failed' or 'pending'.
        // If left alive, the watchdog may pick them up and race with the new job, overwriting the
        // newer 'queued'/'processing' post meta flag.
        if (!empty($input_data['idea_id'])) {
            $idea_id = (int) $input_data['idea_id'];
            $stale = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE status IN ('failed','pending') AND id != %d AND input_data LIKE %s",
                0,
                '%' . $wpdb->esc_like('"idea_id":' . $idea_id) . '%'
            ));
            if ((int) $stale > 0) {
                $retired = $wpdb->query($wpdb->prepare(
                    "UPDATE {$table} SET status = 'failed', error_message = CONCAT(IFNULL(error_message,''), ' [Superseded by re-queue]'), completed_at = %s WHERE status IN ('failed','pending') AND input_data LIKE %s",
                    current_time('mysql'),
                    '%' . $wpdb->esc_like('"idea_id":' . $idea_id) . '%'
                ));
                if ($retired > 0) {
                    $this->logger->info("schedule_generation: Retired {$retired} stale job(s) for idea_id={$idea_id} before scheduling new job.");
                }
            }
        }

        $wpdb->insert(
            $table,
            array(
                'user_id' => $user_id,
                'job_type' => 'generation',
                'status' => 'pending',
                'input_data' => wp_json_encode($input_data),
                'created_at' => current_time('mysql'),
            ),
            array('%d', '%s', '%s', '%s', '%s')
        );

        $job_id = $wpdb->insert_id;

        // Schedule with Action Scheduler if available
        if (function_exists('as_enqueue_async_action')) {
            as_enqueue_async_action('dit_ts_process_job', array($job_id));
            $this->logger->info("Job {$job_id} scheduled with Action Scheduler");
        } else {
            // Fallback: process synchronously
            $this->process_job($job_id);
        }

        return $job_id;
    }

    /**
     * Process generation job
     *
     * @param int $job_id Job ID
     * @return void
     */
    public function process_job($job_id)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'dit_ts_jobs';

        // @MODIFIED 2026-02-26 - Master AI Switch: do NOT run or fail jobs when globally disabled
        // Note: Already-enqueued Action Scheduler callbacks may still fire; they must be a no-op.
        $is_automation_enabled = get_option('dit_ts_enable_ai_automation', '1');
        if (!$is_automation_enabled) {
            $this->logger->info("Job {$job_id} skipped: AI Automation is globally DISABLED (Master Switch OFF).");
            return;
        }

        $this->logger->info("Processing job {$job_id}");

        // @MODIFIED 2026-05-13 - CRITICAL FIX: Outer try-catch wrapping entire job to prevent silent failures.
        // The existing inner try-catch (line ~608) only wraps the generation code. Initialization code
        // (input_data, strategy, provider, quota-pause, mutex) was unprotected. Any \Throwable there
        // (TypeError, memory, runtime) would kill the PHP process silently — no log, no status update.
        // Watchdog finds the job stuck with status='processing' after 900s and force-fails it.
        try {

        // @MODIFIED 2026-02-10 - Sequencing & Gap Enforcement
        $job_status = $this->get_current_state($job_id);

        // @MODIFIED 2026-04-26 - Log current blocking state for diagnostics
        $last_comp = (int) get_option('dit_ts_last_job_completion', 0);
        $time_since_last = time() - $last_comp;
        $lock_holder = get_transient('dit_ts_job_lock');
        $running_count = $this->get_running_jobs_count($job_id, false);
        $this->logger->info("Job {$job_id} pre-flight", [
            'status' => $job_status,
            'time_since_last_completion' => $time_since_last . 's',
            'lock_holder' => $lock_holder ?: 'none',
            'running_jobs' => $running_count
        ]);

        $input_json = $wpdb->get_var($wpdb->prepare(
            "SELECT input_data FROM {$table} WHERE id = %d", $job_id
        ));
        $input_data = !empty($input_json) ? json_decode($input_json, true) : [];

        $strategy = AI_Provider_Factory::get_effective_strategy($input_data);
        $provider = AI_Provider_Factory::strategy_to_provider($strategy);

        // @MODIFIED 2026-02-25 - Provider-aware quota pause (avoid guessing reset windows).
        $provider_pause = false;
        $pause_until = 0;

 if (class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Pause_Manager')) {
 $provider_pause = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::is_paused($provider);
 $pause_until = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::get_pause_until($provider);
 }

 if ($provider_pause) {
            // @MODIFIED 2026-07-04 - Cross-Provider Fallback on Pause
            // When the primary provider is paused, try fallback providers before rescheduling.
            $fallback = self::resolve_first_available_fallback($strategy, $input_data);

            if ($fallback !== null) {
                // Swap strategy/provider to the available fallback and proceed.
                $input_data['strategy_override'] = $fallback['strategy'];
                if ($fallback['strategy'] === 'custom') {
                    $input_data['custom_provider_id'] = $fallback['provider_id'];
                } else {
                    unset($input_data['custom_provider_id']);
                }
                $input_data['cross_provider_fallback'] = true;

                // Persist the swapped input_data so the job uses the fallback provider.
                $wpdb->update($table, array('input_data' => json_encode($input_data)), array('id' => $job_id));

                $this->logger->info("Job {$job_id}: Primary provider '{$provider}' paused. Falling back to '{$fallback['label']}' (strategy: {$fallback['strategy']}, provider_id: {$fallback['provider_id']}).");
                // Fall through — job proceeds with fallback provider.
            } else {
                // No available fallback — reschedule for after pause expires.
                $delay = 3600;
                $now = time();
                if ($pause_until > 0) {
                    // Wait until the actual pause expiry (can be many hours for daily quota).
                    $delay = max(300, ($pause_until - $now));
                }

                // Add small jitter to avoid stampedes across sites.
                $delay += wp_rand(10, 90);

                $this->logger->info("Job {$job_id} aborted: Provider quota pause active ({$provider}). No fallback available. Rescheduling in {$delay}s.");
                // @MODIFIED 2026-02-12 - Graceful Quota Exit: Reset timestamp & Release post lock
                // This prevents the Watchdog from killing the job and allows the draft to be "clean" while waiting.
                $wpdb->update($table, array('created_at' => current_time('mysql')), array('id' => $job_id));
                if (!empty($input_data['idea_id'])) {
                    // @MODIFIED 2026-03-06 - Stable Locking: Do NOT release lock during quota pause to prevent duplicate scheduling.
                    // delete_post_meta($input_data['idea_id'], '_dit_ts_generated');
                    $this->logger->info("Graceful Exit: Preserved source post lock for Idea {$input_data['idea_id']} (Global Pause active)");
                }

                // Schedule a probe (deduped) so the system recovers as soon as quota resets.
                // @MODIFIED 2026-05-05 - Use proportional dedup TTL instead of flat 3600s
                // to avoid blocking recovery probes after midnight quota reset.
                if (function_exists('as_schedule_single_action')) {
                    $tkey = 'dit_ts_' . $provider . '_quota_probe_scheduled';
                    $probe_delay = 900;
                    if (class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Pause_Manager')) {
                        $reason = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::get_reason($provider);
                        $reset_at = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::get_reset_at($provider);
                        if ($reason === 'daily_quota_exhausted' && $reset_at > 0) {
                            $probe_delay = max(120, ($reset_at + 60) - $now);
                        }
                    }

                    if (!get_transient($tkey)) {
                        $dedup_ttl = max(300, min(1800, $probe_delay));
                        set_transient($tkey, '1', $dedup_ttl);

                        as_schedule_single_action($now + $probe_delay + wp_rand(1, 30), 'dit_ts_quota_probe', array($provider));
                    }
                }

                if (function_exists('as_schedule_single_action')) {
                    as_schedule_single_action($now + $delay, 'dit_ts_process_job', array($job_id));
                }
                return;
            }
        }

        // @MODIFIED 2026-02-11 - Atomic Start Mutex (Critical Fix for Race Condition)
        // We use add_option as a mutex because it is atomic in MySQL. 
        // If it exists, another job is currently *starting*.
        // This serialized the *check* for running jobs, preventing the race condition where 
        // multiple jobs see "0 running" and start simultaneously.
        $mutex_key = 'dit_ts_job_start_mutex';
        $acquired = add_option($mutex_key, time(), '', 'no'); // 'no' = autoload off

        if (!$acquired) {
            // Check if mutex is stale (older than 10s)
            $mutex_time = get_option($mutex_key);
            if ($mutex_time && (time() - $mutex_time > 10)) {
                delete_option($mutex_key);
                $acquired = add_option($mutex_key, time(), '', 'no');
            }
        }

        if (!$acquired) {
            // System is busy *starting* another job. 
            // We delay this one slightly (random 5-15s) to stagger the next attempt.
            $delay = wp_rand(5, 15);
            $this->logger->info("Job {$job_id} delayed: Start Mutex locked. Retrying in {$delay}s.");
            $wpdb->update($table, array('created_at' => current_time('mysql')), array('id' => $job_id));
            if (function_exists('as_schedule_single_action')) {
                as_schedule_single_action(time() + $delay, 'dit_ts_process_job', array($job_id));
            }
            return;
        }

        // --- MUTEX ACQUIRED ---
        try {
            // 0. THREAD MUTEX FIX: Prevent duplicate executions of the SAME job instantly
            $exec_mutex = 'dit_ts_job_executing_' . $job_id;
            if (!add_option($exec_mutex, time(), '', 'no')) {
                if (time() - get_option($exec_mutex) > 300) {
                    update_option($exec_mutex, time());
                } else {
                    $this->logger->warning("Job {$job_id} aborted immediately: Duplicate thread execution detected.");
                    delete_option($mutex_key);
                    return;
                }
            }

            // 1. Concurrency Lock: Use unified check (DB + Transient Lock)
            // @MODIFIED BUG FIX - Pass false so other pending jobs do not falsely trigger "system busy" for this job
            if ($this->has_running_jobs($job_id, false)) {
                $this->logger->info("Job {$job_id} delayed: System busy or another job starting. Rescheduling in 5 mins.");
                $wpdb->update($table, array('created_at' => current_time('mysql')), array('id' => $job_id));
                if (function_exists('as_schedule_single_action')) {
                    as_schedule_single_action(time() + 300, 'dit_ts_process_job', array($job_id));
                }
                // @MODIFIED 2026-05-05 - Finding 1: Release exec mutex so the rescheduled task
                // is not falsely detected as a duplicate thread execution.
                delete_option('dit_ts_job_executing_' . $job_id);
                delete_option($mutex_key); // Release start mutex
                return;
            }

// 2. Gap Enforcement
        // @MODIFIED 2026-04-26 - Reduced from 20 min to 5 min.
        // The 20-min global gap was starving multi-campaign setups: when Showbiz completed,
        // Fashion had to wait 20 min, by which time the Fashion campaign had already fired
        // and found "no pending ideas" (drafts were locked with _dit_ts_generated='processing').
        // 5 min is enough to prevent API rate-limiting while allowing both campaigns to process.
        $is_resume = in_array($job_status, [self::STATE_BRIEFING, self::STATE_RESEARCHING, self::STATE_OUTLINING, self::STATE_DRAFTING, self::STATE_REVIEWING, 'processing'], true);

        if (!$is_resume) {
            $last_completion = (int) get_option('dit_ts_last_job_completion', 0);
            $gap_needed = 5 * 60;
            $time_since = time() - $last_completion;

                if ($time_since < $gap_needed) {
                    $wait = $gap_needed - $time_since;
                    $this->logger->info("Job {$job_id} delayed: Enforcing 5-minute gap ({$wait}s remaining). Rescheduling.");
                    $wpdb->update($table, array('created_at' => current_time('mysql')), array('id' => $job_id));
                    if (function_exists('as_schedule_single_action')) {
                        as_schedule_single_action(time() + $wait, 'dit_ts_process_job', array($job_id));
                    }
                    // @MODIFIED 2026-05-05 - Finding 1: Release exec mutex so the rescheduled task
                    // is not falsely detected as a duplicate thread execution. The gap enforcer returns
                    // early (bypassing the final delete_option at the bottom of process_job), so the
                    // mutex must be cleared here explicitly.
                    delete_option('dit_ts_job_executing_' . $job_id);
                    delete_option($mutex_key); // Release start mutex
                    return;
                }

                // ATOMIC START GAP FIX: Mark the job as started so other concurrent jobs respect the 20 min gap from THIS start
                update_option('dit_ts_last_job_completion', time());
            }

            // ATOMIC START: Set transient lock immediately
            set_transient('dit_ts_job_lock', $job_id, 300); // 5 mins timeout for initial start

        } catch (\Exception $e) {
            delete_option($mutex_key); // Release mutex on error
            throw $e;
        }

        delete_option($mutex_key); // Release mutex
        // --- MUTEX RELEASED ---

	// @MODIFIED 2026-02-10 - Pre-flight Gemini Daily Quota Check (Provider-Aware)
	// Only run for Gemini jobs
	if ($provider === 'gemini') {
            $api_key = get_option('dit_ts_gemini_api_key', '');
            if (empty($api_key)) {
                $api_key = AI_Client::get_gemini_key();
            }

            if (!empty($api_key)) {
                $ai_client = new AI_Client($api_key, $this->logger);
        if ($ai_client->is_daily_quota_exhausted()) {
            // @MODIFIED 2026-05-05 - Respect existing pause reason; do NOT overwrite non-daily reasons with daily_quota_exhausted
            $existing_reason = '';
            $pause_until_val = 0;
            if (class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Pause_Manager')) {
                $existing_reason = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::get_reason('gemini');
                $pause_until_val = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::get_pause_until('gemini');
            }
            $this->logger->warning("Job {$job_id} aborted: Gemini quota pause active (reason: {$existing_reason}).");

            // Release lock we acquired.
            delete_transient('dit_ts_job_lock');

            if (class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Pause_Manager')) {
                if ($existing_reason === 'daily_quota_exhausted') {
                    $until = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::pause('gemini', 'daily_quota_exhausted', 3600, 86400);
                } else {
                    // Non-daily pause already active — use its existing until timestamp
                    $until = $pause_until_val > time() ? $pause_until_val : time() + 3600;
                }
                $delay = max(300, ($until - time()));
            } else {
                $delay = 3600;
            }

 delete_transient('dit_ts_gemini_quota_pause');
 delete_transient('dit_ts_gemini_daily_quota_exhausted');

                    $wpdb->update($table, array('created_at' => current_time('mysql')), array('id' => $job_id));
                    if (!empty($input_data['idea_id'])) {
                        // @MODIFIED 2026-03-06 - Stable Locking: Do NOT release lock during daily quota hit.
                        // delete_post_meta($input_data['idea_id'], '_dit_ts_generated');
                        $this->logger->info("Graceful Exit: Preserved source post lock for Idea {$input_data['idea_id']} (Quota hit)");
                    }

                    if (function_exists('as_schedule_single_action')) {
                        $now = time();
                        $probe_delay = 900;
                        if (class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Pause_Manager')) {
                            $reset_at = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::get_reset_at('gemini');
                            if ($reset_at > 0) {
                                $probe_delay = max(120, ($reset_at + 60) - $now);
                            }
                        }
                        as_schedule_single_action($now + $probe_delay + wp_rand(1, 30), 'dit_ts_quota_probe', array('gemini'));
                        as_schedule_single_action($now + $delay + wp_rand(10, 60), 'dit_ts_process_job', array($job_id));
                    }
                    return;
                }
            }
        }

try {
        // Get job data
        $job = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table} WHERE id = %d",
            $job_id
        ), ARRAY_A);

        if (!$job) {
            throw new \Exception("Job {$job_id} not found");
        }

        // @MODIFIED 2026-04-26 - Upgrade _dit_ts_generated from 'queued' → 'processing' when the job
        // actually starts running. 'queued' was set in run_campaign_job()/process_pending_queue()
        // to prevent duplicate pickup; 'processing' means the job is actively executing.
        $input_data = !empty($job['input_data']) ? json_decode($job['input_data'], true) : [];
        if (!empty($input_data['idea_id'])) {
            $current_meta = get_post_meta((int) $input_data['idea_id'], '_dit_ts_generated', true);
            if ($current_meta === 'queued' || empty($current_meta) || $current_meta === '') {
                update_post_meta((int) $input_data['idea_id'], '_dit_ts_generated', 'processing');
                update_post_meta((int) $input_data['idea_id'], '_dit_ts_flag_set_at', time());
            }
        }

        // Route to workflow step processor if in a sub-state
            $sub_states = [
                self::STATE_BRIEFING,
                self::STATE_RESEARCHING,
                self::STATE_OUTLINING,
                self::STATE_DRAFTING
            ];

            if (in_array($job['status'], $sub_states, true)) {
                // @MODIFIED 2026-01-29 - Loop through workflow steps until completion or timeout
                $start_time = time();

                // @MODIFIED 2026-02-09 - Increase PHP time limit to prevent timeouts during long AI calls
                if (function_exists('set_time_limit')) {
                    set_time_limit(300); // 5 minutes (matches Watchdog)
                }

                // Allow up to 25s of processing time before yielding to avoid overlapping schedule runs
                // or browser timeouts if running via AJAX
                $max_execution_time = 25;

                while (in_array($job['status'], $sub_states, true)) {
                    // Refresh global lock to prevent another job starting mid-workflow (long AI calls/yields).
                    set_transient('dit_ts_job_lock', $job_id, 900); // 15 mins rolling lock
                    $this->process_workflow_step($job);
                    // Refresh job data to check new status
                    $old_status = $job['status']; // Track previous status
                    $job = $wpdb->get_row($wpdb->prepare(
                        "SELECT * FROM {$table} WHERE id = %d",
                        $job_id
                    ), ARRAY_A);

                    // Check time limit
                    if (time() - $start_time > $max_execution_time) {
                        $this->logger->info("Job {$job_id} time limit reached ({$max_execution_time}s). Rescheduling immediate continuation...");

                        // @CRITICAL FIX 2026-02-09 - Re-enqueue action before yielding!
                        if (function_exists('as_enqueue_async_action')) {
                            as_enqueue_async_action('dit_ts_process_job', array($job_id));
                        }

                        // Keep lock alive for the continuation run.
                        set_transient('dit_ts_job_lock', $job_id, 900); // 15 mins
                        delete_option('dit_ts_job_executing_' . $job_id); // Release thread mutex
                        return;
                    }
                }

                // If we exited the loop and are no longer in sub_states, 
                // but the job isn't terminal (e.g. it just finished drafting and needs final assembly),
                // we continue. If it is terminal, update_job_status will clear the lock.
                if (in_array($job['status'], ['completed', 'failed'])) {
                    delete_option('dit_ts_job_executing_' . $job_id); // Release thread mutex
                    return;
                }
            }

            if ($job['status'] !== 'pending' && !$is_resume) {
                $this->logger->warning("Job {$job_id} already processed (status: {$job['status']})");
                delete_option('dit_ts_job_executing_' . $job_id); // Release thread mutex
                return;
            }

            // Update status to processing
            $this->update_job_status($job_id, 'processing');

$input_data = json_decode($job['input_data'], true);

        // Start Generation Logic
// @FIXED 2026-04-24 - Use AI_Provider_Factory to eliminate duplicated provider wiring

		$ai_client = AI_Provider_Factory::create($strategy, $this->logger, $input_data);

		// Wrap the AI client with PromptEngine
            // @MODIFIED 2026-02-13 - Fixed class name and used FQN for reliable resolution
            $promptEngine = new \DIT\TrendStudio\Content\PromptEngine($ai_client, $this->logger);

            // Pass strategy to generate method if PromptEngine supports it
            // We need to modify the call to generate below.

            $generator    = new ContentPipeline($promptEngine, $this->logger);
            $formatter = new Content_Formatter();
            $validator = new Validator($this->logger);

            // Generate article
            // @MODIFIED 2026-02-12 - Pass strategy map to PromptEngine via ContentPipeline??
            // ContentPipeline::generate calls $this->promptEngine->generate($input_data, $strategy??)
            // Let's check ContentPipeline.
            // Assuming ContentPipeline just passes data. We'll inject strategy into $input_data for PromptEngine to pick up.
            $input_data['strategy_override'] = $strategy;

            // @MODIFIED 2026-02-25 - Localize external images for ALL rewrite pipelines (not just personas).
            // This prevents hotlinking and makes downstream rename/cap/cleanup deterministic.
            //
            // IMPORTANT: This is non-destructive for the source post: we only update idea_text used for AI.
            if (!empty($input_data['idea_id']) && class_exists('DIT\TrendStudio\Services\Media_Localizer')) {
                $idea_id = (int) $input_data['idea_id'];

                // @MODIFIED 2026-06-07 - Skip media localization on retry if already done for this job.
                // Prevents redundant image downloads (10 per retry) when Gemini 503 triggers reschedule.
                $already_localized = (int) $wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM {$wpdb->postmeta} pm
                     INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
                     WHERE p.post_type = 'attachment'
                     AND pm.meta_key = '_dit_ts_media_job'
                     AND pm.meta_value = %d",
                    (int) $job_id
                ));
                if ($already_localized > 0) {
                    $this->logger->info("Media localization skipped on retry: already localized for job {$job_id}", [
                        'idea_id' => $idea_id,
                        'existing_attachments' => $already_localized,
                    ]);
                } else {

                $vertical = (string) ($input_data['vertical'] ?? get_option('dit_ts_content_vertical', 'showbiz'));

                $cap = (int) get_option('dit_ts_media_visual_limit', 15);
                if ($vertical === 'fashion_pk') {
                    $cap = 15;
                } elseif ($vertical === 'showbiz_pk') {
                    $cap = 10;
                }
                $cap = max(1, min(30, $cap));

                // Local image handling mode (clone|transfer_exclusive|transfer_force|keep).
                // @MODIFIED 2026-02-26 - Do not override personas; honor admin setting (fix: rename not applying on showbiz_pk).
                $local_mode = (string) get_option('dit_ts_media_local_image_mode', 'clone');
                $local_mode = in_array($local_mode, array('clone', 'transfer_exclusive', 'transfer_force', 'keep'), true) ? $local_mode : 'clone';

                $localize_enabled = (bool) get_option('dit_ts_media_localize_external', true);
                if ($localize_enabled) {
                    $localizer = new \DIT\TrendStudio\Services\Media_Localizer($this->logger);
                    if (method_exists($localizer, 'localize_html_images')) {
                        $src_html = (string) ($input_data['idea_text'] ?? '');
                        // @FIXED 2026-05-11 - Pass local_mode as 5th parameter (replaces hardcoded true)
                        // @MODIFIED 2026-06-25 - Pass vertical as 6th parameter for dimension-aware sorting
                        $loc = $localizer->localize_html_images($src_html, $idea_id, $cap, (int) $job_id, $local_mode, $vertical);

                        if (!empty($loc['updated_content'])) {
                            $input_data['idea_text'] = (string) $loc['updated_content'];
                        }

                        $src_post = get_post($idea_id);
                        $this->logger->info('Scheduler: media localization (non-destructive) completed', [
                            'idea_id'    => $idea_id,
                            'idea_type'  => $src_post ? $src_post->post_type : 'unknown',
                            'vertical'   => $vertical,
                            'local_mode' => $local_mode,
                            'updated'    => (bool) ($loc['updated'] ?? false),
                            'kept'       => (int) ($loc['kept'] ?? 0),
                            'imported'   => (int) ($loc['imported'] ?? 0),
                            'removed'    => (int) ($loc['removed'] ?? 0),
                            'failed'     => (int) ($loc['failed'] ?? 0),
                        ]);

                        // @MODIFIED 2026-05-06 - Finding 2: Post-parent attachment sweep.
                        // Safety net for attachments whose URL-based resolution still returns 0
                        // after the basename fallback (e.g. file exists on disk but was never
                        // registered in wp_postmeta via media_handle_sideload). Any attachment
                        // already parented to the source draft that was not caught by
                        // localize_html_images is tagged here so rename, transfer, and cleanup
                        // all work identically for every vertical.
                        if (
                            in_array($local_mode, ['transfer_exclusive', 'transfer_force'], true)
                            && class_exists('DIT\\TrendStudio\\Services\\Media_Cleanup_Helper')
                        ) {
$direct_atts = get_posts([
    'post_type' => 'attachment',
    'post_parent' => $idea_id,
    'post_status' => 'inherit',
    'posts_per_page' => -1,
    'fields' => 'ids',
    'no_found_rows' => true,
]);
$swept = 0;
foreach ($direct_atts as $direct_att_id) {
    $direct_att_id = (int) $direct_att_id;
    if ($direct_att_id <= 0) {
        continue;
    }
    // Already tagged by localize_html_images — skip.
    if ((int) get_post_meta($direct_att_id, '_dit_ts_media_job', true) === (int) $job_id) {
        continue;
    }
    // @MODIFIED 2026-05-07 - Removed is_attachment_used_elsewhere guard from sweep.
    // Source idea posts are the SOLE owners of their images — the source is always
    // deleted after publish. The "shared" check was a false positive that caused the
    // sweep to skip ALL source attachments (logging swept=0 silently), leaving them
    // untagged → no rename → no re-parent → orphaned on trash. Now all direct
    // children of the source idea are tagged and detached unconditionally.
    update_post_meta($direct_att_id, '_dit_ts_media_owner', $idea_id);
    update_post_meta($direct_att_id, '_dit_ts_media_managed', 1);
    update_post_meta($direct_att_id, '_dit_ts_media_job', (int) $job_id);
    // @MODIFIED 2026-05-07 - Detach so re-parent query (meta-based) can find them.
    // The sweep finds attachments by post_parent=$idea_id, tags them with meta, then
    // detaches (post_parent=0) so both meta-based and parent-based queries can locate them.
    // Aligns with clone/sideload paths that already detach.
    \wp_update_post(['ID' => $direct_att_id, 'post_parent' => 0]);
    $swept++;
}
if ($swept > 0 && isset($this->logger)) {
    $this->logger->info('Scheduler: post_parent sweep tagged additional source attachments as job-managed', [
        'idea_id' => $idea_id,
        'job_id' => (int) $job_id,
        'swept' => $swept,
    ]);
}
}
}
}
}
            } // close: if (!empty($input_data['idea_id']) && class_exists('Media_Localizer'))

            $article_data = $generator->generate($input_data);

            // @MODIFIED 2026-05-12/13 - Hero-First Gatekeeper (Persona-Aware)
            // Ensure vertical-specific image requirements are met before proceeding.
            $vertical = $input_data['vertical'] ?? 'showbiz';
            $is_fashion = (strpos($vertical, 'fashion') !== false);
            $is_showbiz = (strpos($vertical, 'showbiz') !== false);
            
            if (($is_fashion || $is_showbiz) && !empty($input_data['idea_id'])) {
                $visual_map = $article_data['_source_visual_map'] ?? [];
                
                // Fashion: Require at least 1 portrait image (H>W, H>=700px)
                // Showbiz: Require at least 1 image (H>=400px OR W>=600px)
                // If visual_map is empty after MediaSelector filtering, no valid images found
                if (empty($visual_map)) {
                    $this->logger->warning("Hero-First Gatekeeper: No valid images for $vertical post. Halting.", ['idea_id' => $input_data['idea_id']]);
                    throw new \Exception('Featured Collage Aborted: No valid images found for ' . $vertical . '. Requirements: Fashion (H>W, H>=700px) or Showbiz (H>=400px OR W>=600px). Post requires manual review.');
                }
            }

            // @MODIFIED 2026-02-17 - Fix: Auto-Restore Missing Media before Validation
            // This prevents "MEDIA PASSTHROUGH FAILED" by reinjecting dropped source media (images/embeds)
            // at the end of the article if the AI omitted them.
            $passthrough = new \DIT\TrendStudio\Services\Media_Passthrough($this->logger);
            $article_data = $passthrough->ensure_media_passthrough($article_data, $input_data, $vertical);

            // Validate
            $validation = $validator->validate($article_data);

            // HARD GATE: media passthrough (fail if media present in input disappears in output)
            $source_html = (string) (($input_data['idea_text'] ?? '') . "\n" . ($input_data['source_urls'] ?? ''));
            $this->assert_media_passthrough($source_html, $article_data);

            // @MODIFIED 2026-02-14 - Rename source images to match generated headline (SEO)
            // Must happen AFTER media passthrough assertion (which validates old URLs) but
            // BEFORE block markup generation (which serializes the final URLs).
            //
            // @MODIFIED 2026-02-19 - Deterministic media inventory + persona caps (fashion_pk=15, showbiz_pk=10) with hard-delete surplus.
            if (!empty($input_data['idea_id']) && !empty($article_data['headline']) && class_exists('DIT\TrendStudio\Services\Image_Renamer')) {
                $idea_id = (int) $input_data['idea_id'];

                // Ensure clean headline for renaming (no HTML)
                $clean_headline = strip_tags((string) $article_data['headline']);
                $clean_headline = html_entity_decode($clean_headline); // Decode '&amp;'

                $vertical = (string) ($input_data['vertical'] ?? get_option('dit_ts_content_vertical', 'showbiz'));

                $max_images = 0;
                if ($vertical === 'fashion_pk') {
                    $max_images = 15;
                } elseif ($vertical === 'showbiz_pk') {
                    $max_images = 10;
                }

                $rename_enabled = (bool) get_option('dit_ts_rename_images', true);
                if (!$rename_enabled && $max_images === 0) {
                    $this->logger->info('Scheduler: image rename disabled (non-persona)', [
                        'idea_id'  => $idea_id,
                        'vertical' => $vertical,
                    ]);
                } else {

                    $this->logger->info('Scheduler: media rename/cleanup start', [
                        'idea_id'    => $idea_id,
                        'vertical'   => $vertical,
                        'max_images' => $max_images,
                    ]);

                    $job_managed_ids = get_posts([
                        'post_type'      => 'attachment',
                        'post_status'    => 'inherit',
                        'fields'         => 'ids',
                        'posts_per_page' => -1,
                        'meta_query'     => [
                            'relation' => 'AND',
                            [
                                'key'     => '_dit_ts_media_job',
                                'value'   => (string) $job_id,
                                'compare' => '=',
                            ],
                            [
                                'key'     => '_dit_ts_media_managed',
                                'value'   => '1',
                                'compare' => '=',
                            ],
                            [
                                'key'     => '_dit_ts_media_owner',
                                'value'   => (string) $idea_id,
                                'compare' => '=',
                            ],
                        ],
                    ]);

                    $renamer = new \DIT\TrendStudio\Services\Image_Renamer($this->logger);
                    $url_map = [];
                    $deleted_urls = [];

                    if (!empty($job_managed_ids) && is_array($job_managed_ids)) {
                        $job_managed_ids = array_values(array_unique(array_map('intval', $job_managed_ids)));

                        // Enforce cap: sort by ID (oldest first), keep first $max_images, delete rest.
                        if ($max_images > 0 && count($job_managed_ids) > $max_images) {
                            $keep_ids = array_slice($job_managed_ids, 0, $max_images);
                            $delete_ids = array_slice($job_managed_ids, $max_images);

                            foreach ($delete_ids as $del_id) {
                                if (!\wp_attachment_is_image((int) $del_id)) {
                                    continue;
                                }
                                $del_url = \wp_get_attachment_url((int) $del_id);
                                if (!empty($del_url)) {
                                    $deleted_urls[] = $del_url;
                                }
                                \wp_delete_attachment((int) $del_id, true);
                            }

                            $job_managed_ids = $keep_ids;
                        }

                        $url_map = $renamer->rename_attachments_by_ids($job_managed_ids, $clean_headline, 0);

                        if (!empty($deleted_urls) && isset($url_map['_deleted_urls'])) {
                            $url_map['_deleted_urls'] = array_values(array_unique(array_merge($deleted_urls, $url_map['_deleted_urls'])));
                        } elseif (!empty($deleted_urls)) {
                            $url_map['_deleted_urls'] = $deleted_urls;
                        }
                    }

                    // @MODIFIED 2026-05-12 - Bridge content URLs (bare filenames) to renamed attachment URLs.
                    // Image_Renamer maps attachment URLs, but article data has content URLs (from source_visual_map).
                    // Read _dit_ts_content_url meta (set during localization) to add content→renamed mappings.
                    if (!empty($job_managed_ids) && is_array($job_managed_ids)) {
                        foreach ($job_managed_ids as $bridged_id) {
                            $bridged_id = (int) $bridged_id;
                            $content_url = \get_post_meta($bridged_id, '_dit_ts_content_url', true);
                            if (!empty($content_url) && !isset($url_map[$content_url])) {
                                $new_att_url = \wp_get_attachment_url($bridged_id);
                                if (!empty($new_att_url)) {
                                    $url_map[$content_url] = $new_att_url;
                                    $this->logger->info('Scheduler: bridged content URL to renamed attachment', [
                                        'content_url'  => $content_url,
                                        'renamed_url'  => $new_att_url,
                                        'attachment_id' => $bridged_id,
                                    ]);
                                }
                            }
                        }
                    }

                    // Replace URLs in article payload.
                    if (!empty($url_map)) {
                        $replace_map = $url_map;

                        $deleted_list = [];
                        if (isset($replace_map['_deleted_urls']) && is_array($replace_map['_deleted_urls'])) {
                            $deleted_list = $replace_map['_deleted_urls'];
                            unset($replace_map['_deleted_urls']);
                        }

                        // @MODIFIED 2026-02-26 - Expand replacement map with http/https and decoded variants (fix: rename not reflected in output HTML).
                        $replace_map = $this->augment_url_map($replace_map);

                        $string_fields_replaced = 0;

                        // 1) Replace renamed URLs (if any).
                        if (!empty($replace_map)) {
                            array_walk_recursive($article_data, function (&$value) use ($replace_map, &$string_fields_replaced) {
                                if (!is_string($value) || $value === '') {
                                    return;
                                }
                                $before = $value;
                                $value = strtr($value, $replace_map);
                                if ($value !== $before) {
                                    $string_fields_replaced++;
                                }
                            });
                        }

                        // 2) Always scrub deleted URLs, even if no rename map existed.
                        // @MODIFIED 2026-02-24 - Fix scrub gating bug (Fix #Showbiz404)
                        if (!empty($deleted_list)) {
                            $dus = $deleted_list;
                            array_walk_recursive($article_data, function (&$value) use ($dus) {
                                if (!is_string($value) || $value === '') {
                                    return;
                                }
                                foreach ($dus as $du) {
                                    $du = preg_quote((string) $du, '/');
                                    $value = preg_replace('/(?:<figure[^>]*>\s*)?(?:<a[^>]*>\s*)?<img\b[^>]*\bsrc=["\']' . $du . '["\'][^>]*>\s*(?:<\/a>\s*)?(?:<figcaption[^>]*>.*?<\/figcaption>\s*)?(?:<\/figure>\s*)?/is', '', $value);
                                }
                            });
                        }

                        // @MODIFIED 2026-05-11 - Use $job_managed_ids instead of removed $managed_keep_ids
                        $this->logger->info('Scheduler: media rename/cleanup complete', [
                            'keep_count'              => count($job_managed_ids),
                            'delete_count'            => 0,
                            'map_count'               => count($replace_map),
                            'deleted_url_count'       => !empty($deleted_list) ? count($deleted_list) : 0,
                            'string_fields_replaced'  => $string_fields_replaced,
                        ]);
                    } else {
                        // @MODIFIED 2026-05-11 - Updated to use $job_managed_ids variable.
                        $this->logger->info('Scheduler: media rename/cleanup complete', [
                            'keep_count'              => count($job_managed_ids),
                            'delete_count'            => 0,
                            'map_count'               => 0,
                            'deleted_url_count'       => 0,
                            'string_fields_replaced'  => 0,
                            'note'                    => 'No job-managed media found for rename/delete (check local image mode + exclusivity).',
                        ]);
                    }
                }
            }

            // @MODIFIED 2025-12-14 - Generate block markup as canonical artifact
            // @MODIFIED 2026-01-13 - Enforce wrapper for CSS styling
            $block_markup = $formatter->to_block_markup($article_data, false);

            // Save results with both article and block_markup
            $output = array(
                'article' => $article_data,
                'block_markup' => $block_markup,
            );

            // @MODIFIED 2026-07-14 - Use update_job_status() for terminal-state side effects
            // (lock clearing, dit_ts_last_job_completion, pending drain). Previous raw $wpdb->update
            // bypassed these, leaving stale locks and preventing pending-job drain after completion.
            $this->update_job_status($job_id, 'completed');

            // Persist output data and validation results separately (update_job_status only sets status fields).
            $wpdb->update(
                $table,
                array(
                    'output_data' => wp_json_encode($output),
                    'validation_results' => wp_json_encode($validation),
                ),
                array('id' => $job_id),
                array('%s', '%s'),
                array('%d')
            );

            // @MODIFIED 2026-01-25 - Fix missing Auto-Publish for automated jobs
            // @MODIFIED 2026-06-07 - Block auto-publish when validation flagged structural hard gates
            if (!empty($input_data['is_auto_process'])) {
                $validation_passed = $validation['passed'] ?? true;
                if (!$validation_passed) {
                    $this->logger->warning("Auto-publish blocked by structural validation for Job {$job_id}", [
                        'errors' => $validation['errors'] ?? [],
                        'score' => $validation['score'] ?? 0,
                    ]);
                } else {
                    $this->logger->info("Auto-Publishing Job {$job_id}");
                    $post_id = $this->auto_publish_job($job_id);

                    if ($post_id) {
                        $this->logger->info("Job {$job_id} Auto-Published to Post {$post_id}");
                        if (!empty($input_data['idea_id'])) {
                            do_action('dit_ts_job_auto_published', $job_id, $post_id, $input_data['idea_id']);
                        }
                    } else {
                        $this->logger->error("Failed to auto-publish Job {$job_id}");
                    }
                }
            }

            $this->logger->info("Job {$job_id} completed successfully");

            // @MODIFIED 2026-07-14 - Release thread mutex on success (previously only released in catch block).
            delete_option('dit_ts_job_executing_' . $job_id);
        } catch (\Throwable $e) {
            // @MODIFIED 2026-02-10 - Clear lock and use update_job_status for failure recovery
            delete_transient('dit_ts_job_lock');
            delete_option('dit_ts_job_executing_' . $job_id); // Release thread mutex

            $ctx = array();
            if ($e instanceof \DIT\TrendStudio\AI_Exception) {
                $ctx = $e->get_context();
            }

            $message = $e->getMessage();
            $this->logger->error(
                "Job {$job_id} failed: " . $message,
                array(
                    'file' => $e->getFile(),
                    'line' => $e->getLine(),
'context' => $ctx,
		)
	);

        // @MODIFIED 2026-04-29 - Level 2 Cross-Provider Fallback
        // @MODIFIED 2026-06-01 - Universal Provider Fallback (supersedes Level 2 when enabled)
        // @MODIFIED 2026-06-07 - Route 503 through fallback: always enter fallback when
        // all_models_exhausted (3+ consecutive 503s), regardless of enable_cross_provider_fallback.
        // The 3-consecutive threshold already prevents premature fallback.
        $fallback_config = $this->load_fallback_config();
        $can_universal = !empty($fallback_config['enable_universal_fallback']);
        $all_models_exhausted = !empty($ctx['all_models_exhausted']);
        $job_cross_provider = !empty($input_data['cross_provider_fallback']);
        $can_cross_fallback = !empty($fallback_config['enable_cross_provider_fallback']) || $job_cross_provider;

        if ($can_universal || $all_models_exhausted || ($all_models_exhausted && $can_cross_fallback)) {
                $chain = $this->build_fallback_chain($strategy, $input_data, $fallback_config, $can_universal);
                // @MODIFIED 2026-07-17 - Fix fallback_path source-of-truth.
                // PRECEDENCE: ctx['provider'] (set by every AI_Exception throw site with the failing
                // provider, e.g. Client.php:658 'gemini') > custom_provider_id (custom strategy
                // job input) > strategy (last-resort semantic label like 'gemini' or 'custom').
                // Previously custom_provider_id??ctx??strategy silently allowed an unset
                // custom_provider_id to skip ctx and resolve to the strategy label, which for
                // gemini_direct jobs reported failed_provider as "custom-legacy" and omitted
                // gemini from the recorded fallback_path. Now ctx['provider'] always wins.
                $failed_provider = (string) ($ctx['provider'] ?? ($input_data['custom_provider_id'] ?? $strategy));
                $fallback_path = [$failed_provider];

                foreach ($chain as $entry) {
                    $next_strategy = $entry['strategy'];
                    $next_id = $entry['provider_id'];
                    $next_label = ($next_strategy === 'custom') ? $next_id : $next_strategy;

                    if ($next_id === $failed_provider || $next_label === $failed_provider) {
                        continue;
                    }

                    $pause_slug = ($next_strategy === 'custom') ? $next_id : $next_strategy;
                    if (class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Pause_Manager')) {
                        if (\DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::is_paused($pause_slug)) {
                            $this->logger->info("Job {$job_id}: Fallback skipping provider '{$next_label}' — quota paused.");
                            $fallback_path[] = $next_label . '(paused)';
                            continue;
                        }
                    }

                    $level_label = $can_universal ? 'Universal' : 'Level 2';
                    $this->logger->info("Job {$job_id}: {$level_label} fallback — trying provider '{$next_label}'", [
                        'failed_provider' => $failed_provider,
                        'next_provider' => $next_label,
                        'next_strategy' => $next_strategy,
                    ]);

                    try {
$fallback_input = $input_data;
            $fallback_input['strategy_override'] = $next_strategy;
            if ($next_strategy === 'custom') {
                $fallback_input['custom_provider_id'] = $next_id;
            } else {
                unset($fallback_input['custom_provider_id']);
            }
            unset($fallback_input['custom_model_id']);
                        $fallback_client = AI_Provider_Factory::create($next_strategy, $this->logger, $fallback_input);
                        $fallback_engine = new \DIT\TrendStudio\Content\PromptEngine($fallback_client, $this->logger);
                        $fallback_generator = new ContentPipeline($fallback_engine, $this->logger);

                        $article_data = $fallback_generator->generate($fallback_input);
                        $fallback_path[] = $next_label;

                        if (!empty($article_data)) {
                            $article_data['_actual_provider'] = $next_label;
                            $article_data['_fallback_path'] = $fallback_path;

                            // @FIXED Finding 5 — Run media localization + image rename/cleanup for fallback path
                            if (!empty($fallback_input['idea_id']) && class_exists('DIT\TrendStudio\Services\Media_Localizer')) {
                                $fb_idea_id = (int) $fallback_input['idea_id'];
                                $fb_vertical = (string) ($fallback_input['vertical'] ?? get_option('dit_ts_content_vertical', 'showbiz'));
                                $fb_cap = ($fb_vertical === 'fashion_pk') ? 15 : (($fb_vertical === 'showbiz_pk') ? 10 : (int) get_option('dit_ts_media_visual_limit', 15));
                                $fb_cap = max(1, min(30, $fb_cap));
                                $fb_local_mode = (string) get_option('dit_ts_media_local_image_mode', 'clone');
                                $fb_local_mode = in_array($fb_local_mode, array('clone', 'transfer_exclusive', 'transfer_force', 'keep'), true) ? $fb_local_mode : 'clone';
                                $fb_localize_enabled = (bool) get_option('dit_ts_media_localize_external', true);
                                if ($fb_localize_enabled) {
                                    $fb_localizer = new \DIT\TrendStudio\Services\Media_Localizer($this->logger);
                                    if (method_exists($fb_localizer, 'localize_html_images')) {
                                        $fb_src_html = (string) ($fallback_input['idea_text'] ?? '');
                                        // @FIXED 2026-05-11 - Pass local_mode as 5th parameter (replaces hardcoded true)
                                        // @MODIFIED 2026-06-25 - Pass vertical as 6th parameter for dimension-aware sorting
                                        $fb_loc = $fb_localizer->localize_html_images($fb_src_html, $fb_idea_id, $fb_cap, (int) $job_id, $fb_local_mode, $fb_vertical);
                                        if (!empty($fb_loc['updated_content'])) {
                                            $fallback_input['idea_text'] = (string) $fb_loc['updated_content'];
                                        }
                                    }
                                }
                            }

                            $passthrough = new \DIT\TrendStudio\Services\Media_Passthrough($this->logger);
                            $fb_vertical = $fallback_input['vertical'] ?? 'showbiz';
                            $article_data = $passthrough->ensure_media_passthrough($article_data, $fallback_input, $fb_vertical);

                            // @FIXED Finding 5 — Image rename/cleanup for fallback path
                            if (!empty($fallback_input['idea_id']) && !empty($article_data['headline']) && class_exists('DIT\TrendStudio\Services\Image_Renamer')) {
                                $fb_idea_id = (int) $fallback_input['idea_id'];
                                $fb_clean_headline = strip_tags((string) $article_data['headline']);
                                $fb_clean_headline = html_entity_decode($fb_clean_headline);
                                $fb_vertical = (string) ($fallback_input['vertical'] ?? get_option('dit_ts_content_vertical', 'showbiz'));
                                $fb_max_images = ($fb_vertical === 'fashion_pk') ? 15 : (($fb_vertical === 'showbiz_pk') ? 10 : 0);

                                if (class_exists('DIT\TrendStudio\Services\Media_Inventory')) {
                                    $fb_inv = new \DIT\TrendStudio\Services\Media_Inventory($this->logger);
                                    $fb_src_html = (string) ($fallback_input['idea_text'] ?? '');
                                    $fb_inventory = !empty($fb_src_html) ? $fb_inv->extract_from_content($fb_src_html) : $fb_inv->get_post_image_inventory($fb_idea_id);
                                    $fb_source_ids = (array) ($fb_inventory['ordered_ids'] ?? []);
                                    $fb_selected_ids = [];
                                    if (!empty($fallback_input['source_visual_map']) && is_array($fallback_input['source_visual_map'])) {
                                        $fb_selected_ids = $fb_inv->get_attachment_ids_from_visual_map((array) $fallback_input['source_visual_map']);
                                    }
                                    // @MODIFIED 2026-05-11 - SIMPLIFIED fallback path: Use job-managed IDs directly
                                    $fb_job_managed_ids = get_posts([
                                        'post_type'      => 'attachment',
                                        'post_status'    => 'inherit',
                                        'fields'         => 'ids',
                                        'posts_per_page' => -1,
                                        'meta_query'     => [
                                            'relation' => 'AND',
                                            [
                                                'key'     => '_dit_ts_media_job',
                                                'value'   => (string) $job_id,
                                                'compare' => '=',
                                            ],
                                            [
                                                'key'     => '_dit_ts_media_managed',
                                                'value'   => '1',
                                                'compare' => '=',
                                            ],
                                            [
                                                'key'     => '_dit_ts_media_owner',
                                                'value'   => (string) $fb_idea_id,
                                                'compare' => '=',
                                            ],
                                        ],
                                    ]);

                                    $fb_renamer = new \DIT\TrendStudio\Services\Image_Renamer($this->logger);
                                    $fb_url_map = [];
                                    if (!empty($fb_job_managed_ids) && is_array($fb_job_managed_ids)) {
                                        $fb_job_managed_ids = array_values(array_unique(array_map('intval', $fb_job_managed_ids)));

                                        // Enforce cap in fallback path
                                        if ($fb_max_images > 0 && count($fb_job_managed_ids) > $fb_max_images) {
                                            $fb_keep_ids = array_slice($fb_job_managed_ids, 0, $fb_max_images);
                                            $fb_delete_ids = array_slice($fb_job_managed_ids, $fb_max_images);
                                            foreach ($fb_delete_ids as $del_id) {
                                                if (!\wp_attachment_is_image((int) $del_id)) {
                                                    continue;
                                                }
                                                \wp_delete_attachment((int) $del_id, true);
                                            }
                                            $fb_job_managed_ids = $fb_keep_ids;
                                        }

                                        $fb_url_map = $fb_renamer->rename_attachments_by_ids($fb_job_managed_ids, $fb_clean_headline, 0);
                                    }

                                    if (!empty($fb_url_map)) {
                                        $fb_replace_map = $fb_url_map;
                                        $fb_deleted_list = [];
                                        if (isset($fb_replace_map['_deleted_urls']) && is_array($fb_replace_map['_deleted_urls'])) {
                                            $fb_deleted_list = $fb_replace_map['_deleted_urls'];
                                            unset($fb_replace_map['_deleted_urls']);
                                        }
                                        $fb_replace_map = $this->augment_url_map($fb_replace_map);

                                        if (!empty($fb_replace_map)) {
                                            array_walk_recursive($article_data, function (&$value) use ($fb_replace_map) {
                                                if (!is_string($value) || $value === '') { return; }
                                                $value = strtr($value, $fb_replace_map);
                                            });
                                        }
                                        if (!empty($fb_deleted_list)) {
                                            array_walk_recursive($article_data, function (&$value) use ($fb_deleted_list) {
                                                if (!is_string($value) || $value === '') { return; }
                                                foreach ($fb_deleted_list as $du) {
                                                    $du = preg_quote((string) $du, '/');
                                                    $value = preg_replace('/(?:<figure[^>]*>\s*)?(?:<a[^>]*>\s*)?<img\b[^>]*\bsrc=["\']' . $du . '["\'][^>]*>\s*(?:<\/a>\s*)?(?:<figcaption[^>]*>.*?<\/figcaption>\s*)?(?:<\/figure>\s*)?/is', '', $value);
                                                }
                                            });
                                        }
                                    }
                                }
                            }

                            $validation = $validator->validate($article_data);

                            $block_markup = $formatter->to_block_markup($article_data, false);
                            $output = array(
                                'article' => $article_data,
                                'block_markup' => $block_markup,
                            );

                            // @MODIFIED 2026-07-14 - Use update_job_status() for terminal-state side effects (fallback path).
                            $this->update_job_status($job_id, 'completed');

                            $wpdb->update(
                                $table,
                                array(
                                    'output_data' => wp_json_encode($output),
                                    'validation_results' => wp_json_encode($validation),
                                ),
                                array('id' => $job_id),
                                array('%s', '%s'),
                                array('%d')
                            );

                            if (!empty($fallback_input['is_auto_process'])) {
                                $post_id = $this->auto_publish_job($job_id);
                                if ($post_id && !empty($fallback_input['idea_id'])) {
                                    do_action('dit_ts_job_auto_published', $job_id, $post_id, $fallback_input['idea_id']);
                                }
                            }

                            $this->logger->info("Job {$job_id}: {$level_label} fallback succeeded via provider '{$next_label}'", [
                                'fallback_path' => $fallback_path,
                            ]);
                            delete_option('dit_ts_job_executing_' . $job_id);
                            return;
                        }
                    } catch (\Throwable $fallback_e) {
                        $fallback_path[] = $next_label . '(failed)';
                        $this->logger->warning("Job {$job_id}: {$level_label} fallback provider '{$next_label}' failed: " . $fallback_e->getMessage());
                        continue;
                    }
                }

			$this->logger->warning("Job {$job_id}: All " . ($can_universal ? 'universal' : 'cross-provider') . " fallbacks exhausted.", [
				'fallback_path' => $fallback_path,
			]);
		}

	// @MODIFIED 2026-02-10 - Intelligent Rescheduling for Quota Issues
	// Prefer machine-readable context from AI_Exception over fragile message sniffing.
	// This prevents "quota=0 model / not enabled" from poisoning the whole system as "daily exhausted".
	$is_daily_quota = false;
            $is_quota_block = false; // model not allowed / quota=0 / plan mismatch

        if (!empty($ctx['reason'])) {
            if ($ctx['reason'] === 'daily_quota_exhausted') {
                $is_daily_quota = true;
            } elseif ($ctx['reason'] === 'service_unavailable') {
                // 503 = Google server overload. Soft error — no quota state, no pause.
                // Just reschedule with a moderate fixed delay and let the job gap enforcement
                // prevent retry storms.
                $provider = (string) ($ctx['provider'] ?? 'gemini');
                $delay = 120;
                $this->logger->info("Job $job_id: service_unavailable (soft error, provider=$provider). Rescheduled in {$delay}s.");
                $wpdb->update($table, array('created_at' => current_time('mysql')), array('id' => $job_id));
                $this->update_job_status($job_id, 'pending');
                if (function_exists('as_schedule_single_action')) {
                    as_schedule_single_action(time() + $delay + wp_rand(10, 60), 'dit_ts_process_job', array($job_id));
                }
                return;
            } elseif ($ctx['reason'] === 'rate_limit_retry') {
                // @MODIFIED 2026-04-23 - Three-Layer Intelligence with class_exists guards
                // and corrected error_info reconstruction (no double-counting)
                $consecutive = (int) ($ctx['consecutive_count'] ?? 1);
                $provider = (string) ($ctx['provider'] ?? 'gemini');

                // Log for debugging
                error_log("[Scheduler] rate_limit_retry caught: provider=$provider, consecutive=$consecutive");

                $has_layers = class_exists(API_Error_Parser::class)
                    && class_exists(Quota_State_Manager::class)
                    && class_exists(Backoff_Strategy::class);

                error_log("[Scheduler] has_layers=" . ($has_layers ? 'true' : 'false'));

                if ($has_layers) {
                    $error_info = [
                        'error_type' => (string) ($ctx['error_class'] ?? 'rpm_burst'),
                        'quota_bucket' => (string) ($ctx['quota_bucket'] ?? API_Error_Parser::RPM),
                        'retry_delay' => (int) ($ctx['api_retry_delay'] ?? ($ctx['retry_after'] ?? 0)),
                        'reset_at' => Quota_Pause_Manager::get_reset_at($provider),
                        'is_quota_zero' => !empty($ctx['is_quota_zero']),
                    ];
                    $quota_health = Quota_State_Manager::get_health($provider);
                    $delay = Backoff_Strategy::calculate($error_info, $quota_health, $consecutive);
                    $rpm_pct = $quota_health['rpm']['pct'];
                } else {
                    $delay = min(3600, 60 * $consecutive);
                    $rpm_pct = 0;
                }

                $error_class = (string) ($ctx['error_class'] ?? 'unknown');
                $wpdb->update($table, array('created_at' => current_time('mysql')), array('id' => $job_id));
                $this->update_job_status($job_id, 'pending');
                if (function_exists('as_schedule_single_action')) {
                    as_schedule_single_action(time() + $delay + wp_rand(10, 60), 'dit_ts_process_job', array($job_id));
                }
                if ($this->logger) {
                    $this->logger->info("Job $job_id: three-layer backoff (provider={$provider}, class={$error_class}, attempt {$consecutive}, rpm_pct={$rpm_pct}%). Rescheduled in {$delay}s.");
                }
                return;
            } elseif (in_array($ctx['reason'], ['quota_exhausted', 'quota_blocked', 'model_quota_zero', 'model_not_allowed'], true)) {
                    $is_quota_block = true;
                }
            }

            // Keep a minimal backward-compatible message check (only if no ctx provided)
            if (!$is_daily_quota && empty($ctx['reason']) && strpos($message, 'Daily Quota Exhausted') !== false) {
                $is_daily_quota = true;
            }

        if ($is_daily_quota) {
        // @MODIFIED 2026-04-23 - Use $provider instead of hardcoded 'gemini'
        $daily_provider = (string) ($ctx['provider'] ?? 'gemini');
        $delay = 3600;
        if (class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Pause_Manager')) {
            $until = !empty($ctx['pause_until']) ? (int) $ctx['pause_until'] : 0;
            if ($until <= 0) {
                $until = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::pause($daily_provider, 'daily_quota_exhausted', 3600, 86400);
            }
                    $delay = max(300, ($until - time()));
                } else {
                    $delay = 3600;
                }

        $wpdb->update($table, array('created_at' => current_time('mysql')), array('id' => $job_id));
        if (!empty($input_data['idea_id'])) {
            $this->logger->info("Graceful Exit: Preserved source post lock for Idea {$input_data['idea_id']} (Catch: quota hit)");
        }

        if (function_exists('as_schedule_single_action')) {
            $now = time();
            $probe_delay = 900;
            if (class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Pause_Manager')) {
                $reset_at = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::get_reset_at($daily_provider);
                if ($reset_at > 0) {
                    $probe_delay = max(120, ($reset_at + 60) - $now);
                }
            }
            as_schedule_single_action($now + $probe_delay + wp_rand(1, 30), 'dit_ts_quota_probe', array($daily_provider));
            as_schedule_single_action($now + $delay + wp_rand(10, 60), 'dit_ts_process_job', array($job_id));
        }

        $this->update_job_status($job_id, 'pending');
        return;
    }
            if ($is_quota_block) {
                // Do not set global pause; this is usually "model not allowed / quota=0" configuration.
                $this->update_job_status($job_id, 'failed');

                $wpdb->update(
                    $table,
                    array(
                        'error_message' => ucfirst($provider) . ' call blocked (model not allowed / quota=0 / plan mismatch). Fix model selection in plugin settings.',
                        'completed_at' => current_time('mysql'),
                    ),
                    array('id' => $job_id),
                    array('%s', '%s'),
                    array('%d')
                );
                return;
            }

            $this->update_job_status($job_id, 'failed', $e->getMessage());
        }

        // Final catch-all cleanup of thread mutex
        delete_option('dit_ts_job_executing_' . $job_id);

        // @MODIFIED 2026-05-13 - Outer catch: catches any \Throwable that escaped the inner
        // try-catch (initialization code, mutex re-throw, TypeError, runtime errors).
        } catch (\Throwable $e) {
            $this->logger->error(
                "Job {$job_id} FATAL (outer catch): " . $e->getMessage(),
                ['file' => $e->getFile(), 'line' => $e->getLine(), 'class' => get_class($e)]
            );
            delete_transient('dit_ts_job_lock');
            delete_option('dit_ts_job_executing_' . $job_id);
            delete_option('dit_ts_job_start_mutex');
            $this->update_job_status($job_id, 'failed', 'FATAL: ' . get_class($e) . ' - ' . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Get job status
     *
     * @param int $job_id Job ID
     * @return array Job status data
     */
    public function get_job_status($job_id)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'dit_ts_jobs';

        $job = $wpdb->get_row($wpdb->prepare(
            "SELECT id, status, job_type, post_id, created_at, completed_at, error_message FROM {$table} WHERE id = %d",
            $job_id
        ), ARRAY_A);

        if (!$job) {
            return array(
                'status'  => 'not_found',
                'message' => 'Job not found',
            );
        }

        $status = (string) $job['status'];

        $response = array(
            'id'           => (int) $job['id'],
            'status'       => $status,
            'message'      => $this->get_status_message($status),
            'job_type'     => (string) $job['job_type'],
            'post_id'      => !empty($job['post_id']) ? (int) $job['post_id'] : null,
            'created_at'   => !empty($job['created_at']) ? (string) $job['created_at'] : null,
            'completed_at' => !empty($job['completed_at']) ? (string) $job['completed_at'] : null,
        );

        if ($status === 'failed' && !empty($job['error_message'])) {
            $response['error'] = (string) $job['error_message'];
        }

        return $response;
    }

    /**
     * Get job input payload
     *
     * @param int $job_id Job ID
     * @return array Decoded input_data payload
     */
    public function get_job_input_data(int $job_id): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'dit_ts_jobs';

        $input_json = $wpdb->get_var($wpdb->prepare(
            "SELECT input_data FROM {$table} WHERE id = %d",
            $job_id
        ));

        if (empty($input_json) || !is_string($input_json)) {
            return array();
        }

        $decoded = json_decode($input_json, true);
        if (!is_array($decoded)) {
            return array();
        }

        return $decoded;
    }

    /**
     * Get preview for completed job
     *
     * @param int $job_id Job ID
     * @return array Preview data
     * @throws \Exception If job not completed
     */
    public function get_preview($job_id)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'dit_ts_jobs';

        $job = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table} WHERE id = %d",
            $job_id
        ), ARRAY_A);

        if (!$job) {
            throw new \Exception('Job not found');
        }

        if ($job['status'] !== 'completed') {
            throw new \Exception('Job not completed yet');
        }

        // @MODIFIED 2025-12-14 - Parse new output structure with article + block_markup
        $output = json_decode($job['output_data'], true);
        $validation = json_decode($job['validation_results'], true);

        // Handle both old format (article only) and new format (article + block_markup)
        $article = isset($output['article']) ? $output['article'] : $output;
        $block_markup = $output['block_markup'] ?? null;

        // Render preview from block markup if available, else fallback to preview HTML
        if (!empty($block_markup)) {
            $html = do_blocks($block_markup);
        } else {
            $formatter = new Content_Formatter();
            $html = $formatter->to_preview_html($article, $validation);
        }

        return array(
            'article' => $article,
            'validation' => $validation,
            'html' => $html,
            'title' => $article['headline'] ?? 'Untitled',
            // @MODIFIED 2026-01-13 - Expose data for Copy Buttons
            'block_markup' => $block_markup,
            'raw_request'  => $output['raw_request'] ?? 'Request data not bridged in this version.',
            'raw_response' => $output['raw_response'] ?? 'Response data not bridged in this version.',
        );
    }

    /**
     * Get job for publishing with ownership verification
     * @MODIFIED 2025-12-14 - Secure publish flow
     *
     * @param int $job_id Job ID
     * @param int $user_id Current user ID
     * @return array Job data with article and block_markup
     * @throws \Exception If job not found, not owned, or not completed
     */
    public function get_job_for_publish(int $job_id, int $user_id): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'dit_ts_jobs';

        $job = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table} WHERE id = %d",
            $job_id
        ), ARRAY_A);

        if (!$job) {
            throw new \Exception('Job not found');
        }

        // Ownership check
        if ((int) $job['user_id'] !== $user_id) {
            $this->logger->warning('Publish attempt on non-owned job', array(
                'job_id' => $job_id,
                'job_user' => $job['user_id'],
                'attempted_by' => $user_id,
            ));
            throw new \Exception('Cannot publish another user\'s job');
        }

        if (!in_array($job['status'], array('completed', 'reviewing'), true)) {
            throw new \Exception('Job not ready for publish');
        }

        $output = json_decode($job['output_data'], true);

        // Handle both old format (article only) and new format (article + block_markup)
        $article = isset($output['article']) ? $output['article'] : $output;
        $block_markup = $output['block_markup'] ?? null;

        // Generate block markup if not stored (backward compat)
        if (empty($block_markup)) {
            $formatter = new Content_Formatter();
            $block_markup = $formatter->to_block_markup($article, false);
        }

        return array(
            'article' => $article,
            'block_markup' => $block_markup,
            'title' => $article['headline'] ?? 'Untitled',
            'validation' => json_decode($job['validation_results'], true),
            // @MODIFIED 2026-01-13 - Pass input/review data for Bridge
            'input_data' => json_decode($job['input_data'], true),
            'review_data' => $output['review_data'] ?? [],
        );
    }

    /**
     * Update job status
     *
     * @param int    $job_id Job ID
     * @param string $status New status
     * @return void
     */
    public function update_job_status($job_id, $status, $error_message = '')
    {
        global $wpdb;
        $table = $wpdb->prefix . 'dit_ts_jobs';

        // @MODIFIED 2026-02-10 - Record completion time and CLEAR atomic lock
        if (in_array($status, ['completed', 'failed'])) {
            update_option('dit_ts_last_job_completion', time());
            delete_transient('dit_ts_job_lock');
        }

        // @MODIFIED 2026-02-26 - If pending drain is active, enqueue next pending job after terminal status
        if (in_array($status, ['completed', 'failed'], true)) {
            $enabled = (int) get_option('dit_ts_enable_ai_automation', '1');
            if ($enabled && get_transient('dit_ts_pending_drain_active') && function_exists('as_schedule_single_action')) {
                as_schedule_single_action(time() + 30, 'dit_ts_resume_pending_jobs', array(1));
            }
        }

        // @MODIFIED 2026-02-09 - Release source post lock if job fails (Issue #stuck-processing)
        if ($status === 'failed') {
            $job = $wpdb->get_row($wpdb->prepare("SELECT input_data FROM {$table} WHERE id = %d", $job_id), ARRAY_A);
            if ($job) {
                $input = json_decode($job['input_data'], true);
            if (!empty($input['idea_id'])) {
                // @MODIFIED 2026-03-06 - Stable Locking: Mark as 'failed' instead of deleting to prevent immediate retry loops and duplicate generation.
                // @MODIFIED 2026-05-08 - Guard: Only write 'failed' if no NEWER ACTIVE job owns the flag.
                // Cross-check the jobs table: if another active job row exists for this idea_id
                // (excluding the current failed job), the flag is legitimately owned — skip overwrite.
                // Without this cross-check, a job that set 'processing' then failed would leave the
                // flag stuck at 'processing' forever, deadlocking the idea from re-queue.
                $current_flag = get_post_meta((int) $input['idea_id'], '_dit_ts_generated', true);
                if ($current_flag === 'queued' || $current_flag === 'processing') {
                    $active_states = "'pending','processing','briefing','researching','outlining','drafting'";
                    $has_active = (int) $wpdb->get_var($wpdb->prepare(
                        "SELECT COUNT(*) FROM {$table} WHERE status IN ({$active_states}) AND input_data LIKE %s AND id != %d LIMIT 1",
                        '%' . $wpdb->esc_like('"idea_id":' . (int) $input['idea_id']) . '%',
                        $job_id
                    ));
                    if ($has_active > 0) {
                        $this->logger->info("Skipped stale 'failed' flag overwrite for Idea {$input['idea_id']} — newer active job exists (flag='{$current_flag}', Job {$job_id} is stale)");
                    } else {
                        update_post_meta($input['idea_id'], '_dit_ts_generated', 'failed');
                        update_post_meta($input['idea_id'], '_dit_ts_flag_set_at', time());
                        $this->logger->info("Force-released 'failed' flag for Idea {$input['idea_id']} (Job {$job_id} failed, no newer active job, previous flag='{$current_flag}')");
                    }
                } else {
                    update_post_meta($input['idea_id'], '_dit_ts_generated', 'failed');
                    update_post_meta($input['idea_id'], '_dit_ts_flag_set_at', time());
                    $this->logger->info("Marked source post as 'failed' for Idea {$input['idea_id']} (Job {$job_id} failed)");
                }
                }
            }
        }

        $data = array('status' => $status);
        $formats = array('%s');

        // @MODIFIED 2026-03-06 - Support passing error message directly to status update
        if (!empty($error_message)) {
            $data['error_message'] = $error_message;
            $formats[] = '%s';
        }

        // @MODIFIED 2026-02-24 - Stamp completion time for terminal statuses (UI + retention correctness).
        if (in_array($status, array('completed', 'failed'), true)) {
            $data['completed_at'] = current_time('mysql');
            $formats[] = '%s';
        }

        $wpdb->update(
            $table,
            $data,
            array('id' => $job_id),
            $formats,
            array('%d')
        );
    }

    /**
     * Heartbeat: Update job timestamp to prevent watchdog timeout during long operations
     *
     * @param int $job_id Job ID
     * @return void
     */
    public function heartbeat($job_id)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'dit_ts_jobs';
        // @MODIFIED 2026-05-08 - Update updated_at instead of created_at for heartbeat.
        // created_at must stay immutable for job age calculations. updated_at tracks
        // the last activity time used by self-healing stale-job detection.
        $wpdb->update(
            $table,
            array('updated_at' => current_time('mysql')),
            array('id' => $job_id),
            array('%s'),
            array('%d')
        );
        if (isset($this->logger)) {
            $this->logger->info("Heartbeat for job {$job_id}");
        }
    }

    /**
     * Get human-readable status message
     *
     * @param string $status Status code
     * @return string Status message
     */
    private function get_status_message($status)
    {
        $messages = array(
            'pending'     => 'Queued (waiting for worker)...',
            'briefing'    => 'Preparing brief...',
            'researching' => 'Researching sources...',
            'outlining'   => 'Building outline...',
            'drafting'    => 'Drafting content...',
            'reviewing'   => 'Running quality checks...',
            'processing'  => 'Generating article...',
            'completed'   => 'Completed',
            'failed'      => 'Failed',
        );

        return $messages[$status] ?? 'Working...';
    }

    /**
     * Get user jobs
     *
     * @param int $user_id User ID
     * @param int $limit   Limit
     * @return array Jobs
     */
    public function get_user_jobs($user_id, $limit = 10)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'dit_ts_jobs';

        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table} WHERE user_id = %d ORDER BY created_at DESC LIMIT %d",
            $user_id,
            $limit
        ), ARRAY_A);
    }

    /**
     * Clean old jobs
     *
     * @param int $days_to_keep Days to keep
     * @return int Number of deleted jobs
     */
    /**
     * Clean old completed/failed jobs to free up space
     * @MODIFIED 2026-01-25 - Reduced retention to 3 days per user request
     *
     * @param int $days_to_keep Number of days to keep jobs (default: 3)
     * @return int Number of jobs deleted
     */
    public function clean_old_jobs($days_to_keep = 3)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'dit_ts_jobs';

        $deleted = $wpdb->query($wpdb->prepare(
            "DELETE FROM {$table} WHERE status IN ('completed', 'failed') AND completed_at < DATE_SUB(NOW(), INTERVAL %d DAY)",
            $days_to_keep
        ));

        $this->logger->info("Cleaned {$deleted} old jobs");

        return $deleted;
    }


    /**
     * Process workflow step (Research, Outline, or Drafting)
     *
     * @param array $job Job data
     * @return void
     */
    private function process_workflow_step($job)
    {
        $job_id = $job['id'];
        $status = $job['status'];
        $input_data = json_decode($job['input_data'], true);

        $this->logger->info("Processing workflow step: {$status} for job {$job_id}");

        try {

// @FIXED 2026-04-24 - Use AI_Provider_Factory (was hardcoded to Gemini)
		$strategy = AI_Provider_Factory::get_effective_strategy($input_data);
		$ai_client = AI_Provider_Factory::create($strategy, $this->logger, $input_data);

		// Initialize components for new workflow
        // @MODIFIED 2025-12-18 - Use Workflow_Orchestrator for Phase 2 state-machine
        $orchestrator = new Workflow_Orchestrator($ai_client, $this->logger);

            // Handle state actions
            if ($status === self::STATE_BRIEFING) {
                // BRIEFING -> RESEARCHING
                $this->update_job_status($job_id, self::STATE_RESEARCHING);

                $this->logger->info("Starting research for job {$job_id}");
                $this->heartbeat($job_id);
                $intelligence = $orchestrator->gather_intelligence($input_data);
                $this->heartbeat($job_id);

                $current_output = json_decode($job['output_data'], true) ?: [];
                $current_output['intelligence'] = $intelligence;

                global $wpdb;
                $table = $wpdb->prefix . 'dit_ts_jobs';
                $wpdb->update(
                    $table,
                    array('output_data' => wp_json_encode($current_output)),
                    array('id' => $job_id),
                    array('%s'),
                    array('%d')
                );
            } elseif ($status === self::STATE_RESEARCHING) {
                $output = json_decode($job['output_data'], true);
                if (empty($output['intelligence'])) {
                    $intelligence = $orchestrator->gather_intelligence($input_data);
                    $output = $output ?: [];
                    $output['intelligence'] = $intelligence;

                    global $wpdb;
                    $table = $wpdb->prefix . 'dit_ts_jobs';
                    $wpdb->update(
                        $table,
                        array('output_data' => wp_json_encode($output)),
                        array('id' => $job_id),
                        array('%s'),
                        array('%d')
                    );
                }

                // ADVANCE: RESEARCHING -> OUTLINING
                $this->update_job_status($job_id, self::STATE_OUTLINING);
            } elseif ($status === self::STATE_OUTLINING) {
                // Generate Outline
                $output = json_decode($job['output_data'], true);
                $intelligence = $output['intelligence'] ?? [];

                $this->heartbeat($job_id);
                $outline = $orchestrator->generate_outline($intelligence, $input_data);
                $this->heartbeat($job_id);

                $output['outline'] = $outline;

                global $wpdb;
                $table = $wpdb->prefix . 'dit_ts_jobs';
                $wpdb->update(
                    $table,
                    array('output_data' => wp_json_encode($output)),
                    array('id' => $job_id),
                    array('%s'),
                    array('%d')
                );

                // ADVANCE: OUTLINING -> DRAFTING
                $this->update_job_status($job_id, self::STATE_DRAFTING);
            } elseif ($status === self::STATE_DRAFTING) {
                // Draft content
                $output = json_decode($job['output_data'], true);
                $outline = $output['outline'] ?? [];

                // @MODIFIED 2026-02-13 - Bulk rename source images and sync URLs before drafting
                if (!empty($input_data['idea_id']) && class_exists('DIT\TrendStudio\Services\Image_Renamer')) {
                    $renamer = new \DIT\TrendStudio\Services\Image_Renamer($this->logger);
                    $rename_title = $input_data['topic'] ?? $input_data['idea_title'] ?? 'Untitled';
                    $url_map = $renamer->rename_attachments_to_match_title((int)$input_data['idea_id'], $rename_title);

                    if (!empty($url_map)) {
                        foreach ($url_map as $old => $new) {
                            if (!empty($input_data['idea_text'])) {
                                $input_data['idea_text'] = str_replace($old, $new, $input_data['idea_text']);
                            }
                            if (!empty($input_data['source_urls'])) {
                                $input_data['source_urls'] = str_replace($old, $new, $input_data['source_urls']);
                            }
                        }
                    }
                }

                $sections = [];
                $media_ids = $input_data['media_ids'] ?? [];
                $prev_section_content = '';
                $sources_index = $output['intelligence']['sources_index'] ?? [];

                // @MODIFIED 2026-02-22 - Phase 4: Consolidated Article Generation
                // @MODIFIED 2026-03-13 - Extended Heartbeat support to prevent watchdog killing long drafting sessions
                $this->heartbeat($job_id);
                $drafted_sections = $orchestrator->draft_full_article($outline, [
                    'brief'        => $input_data,
                    'intelligence' => $output['intelligence'] ?? [],
                    'user_notes'   => $input_data['user_notes'] ?? '',
                ]);
                $this->heartbeat($job_id);

                // @MODIFIED 2025-12-27 - Prepare auditor for per-section citation validation
                $auditor = new Content_Auditor($this->logger);
                $strict_citations = get_option('dit_ts_strict_inline_citations', false);

                // If strict citations are enabled, batch repair any failing sentences
                // across the entire article instead of sequentially.
                $all_failing_sentences = [];
                $section_audits = []; // slug => audit_result

                if ($strict_citations && !empty($sources_index)) {
                    foreach ($outline as $sec) {
                        $slug = $sec['slug'];
                        $section_html = $drafted_sections[$slug] ?? '<p>Content generation failed.</p>';
                        $section_audit = $auditor->validate_inline_citations($section_html, $sources_index);
                        $section_audits[$slug] = $section_audit;

                        if ($section_audit['missing_citation_count'] > 0 || $section_audit['invalid_citation_count'] > 0) {
                            $failing = array_filter(
                                $section_audit['claims'] ?? [],
                                fn($c) => !$c['has_inline_citation'] || !empty($c['invalid_citation_ids'])
                            );
                            foreach ($failing as $f) {
                                $all_failing_sentences[] = $f['sentence'];
                            }
                        }
                    }

                    // Repair all failing sentences in ONE call.
                    if (!empty($all_failing_sentences)) {
                        $this->logger->info('Batch citation repair needed', ['failing_count' => count($all_failing_sentences)]);
                        $repaired_map = $orchestrator->batch_repair_citations($all_failing_sentences, $sources_index);

                        // Apply patches
                        if (!empty($repaired_map)) {
                            foreach ($drafted_sections as $slug => $html) {
                                foreach ($repaired_map as $original => $fixed) {
                                    $html = str_replace($original, $fixed, $html);
                                }
                                $drafted_sections[$slug] = $html;
                            }
                        }
                    }
                }

                // Finalize sections array format for ContentPipeline
                foreach ($outline as $sec) {
                    $slug = $sec['slug'];
                    $section_html = $drafted_sections[$slug] ?? '<p>Content generation failed.</p>';

                    $verification_status = 'VERIFIED';
                    if ($strict_citations) {
                        if (empty($sources_index)) {
                            // No sources = cannot verify anything in strict mode
                            $verification_status = 'REPORT_CLAIMS';
                        } else {
                            if (isset($section_audits[$slug]) && ($section_audits[$slug]['missing_citation_count'] > 0 || $section_audits[$slug]['invalid_citation_count'] > 0)) {
                                // Re-audit after batch patch
                                $re_audit = $auditor->validate_inline_citations($section_html, $sources_index);
                                if ($re_audit['missing_citation_count'] > 0 || $re_audit['invalid_citation_count'] > 0) {
                                    $verification_status = 'REPORT_CLAIMS';
                                }
                            }
                        }
                    }

                    $sections[] = [
                        'heading'             => $sec['title'],
                        'body_html'           => $section_html,
                        'verification_status' => $verification_status,
                    ];
                }

                // @MODIFIED 2026-02-24 - Moved source_visual_map attachment to after $article_data initialization (legacy workflow path).

                // Step 3: Parse & Format Content_Schema format
                $article_data = [
                    'headline'  => $input_data['topic'] ?? $input_data['idea_title'] ?? 'Untitled',
                    'dek'       => '', // Will be filled by AI or user if needed
                    'category'  => $input_data['vertical'] ?? 'showbiz',
                    'sections'  => $sections,
                    'sources'   => $output['intelligence']['sources'] ?? [],
                    'vertical'  => $input_data['vertical'] ?? 'showbiz',
                ];

                // @MODIFIED 2026-02-24 - Attach source visual map for passthrough/audit (legacy workflow path).
                if (!empty($input_data['source_visual_map']) && is_array($input_data['source_visual_map'])) {
                    $article_data['_source_visual_map'] = $input_data['source_visual_map'];
                }

                // Auto-inject images if media provided
                if (!empty($media_ids)) {
                    $formatter = new Content_Formatter();
                    $article_data = $formatter->auto_inject_images($article_data, $media_ids);
                }

                $output['article'] = $article_data;

                // @MODIFIED 2026-02-09 - Rename source attachments to match generated headline
                if (!empty($input_data['idea_id']) && !empty($article_data['headline']) && class_exists('DIT\TrendStudio\Services\Image_Renamer')) {
                    $renamer = new \DIT\TrendStudio\Services\Image_Renamer($this->logger);
                    $rename_map = $renamer->rename_attachments_to_match_title((int)$input_data['idea_id'], $article_data['headline']);
                    if (!empty($rename_map)) {
                        if (isset($rename_map['_deleted_urls'])) {
                            unset($rename_map['_deleted_urls']);
                        }
                        $rename_map = $this->augment_url_map($rename_map);
                        if (!empty($rename_map)) {
                            array_walk_recursive($article_data, function (&$value) use ($rename_map) {
                                if (!is_string($value) || $value === '') {
                                    return;
                                }
                                foreach ($rename_map as $old => $new) {
                                    $value = str_replace($old, $new, $value);
                                }
                            });
                        }
                    }
                }

                // Generate block markup immediately for faster preview/publish
                $formatter = new Content_Formatter();
                $output['block_markup'] = $formatter->to_block_markup($article_data);

                // @MODIFIED 2026-01-13 - Extract Review Data for Rank Math Bridge
                $full_html = implode("\n", array_column($sections, 'body_html'));
                $review_data = [];
                // Extract Rating (Verdict Box usually has "Rating: 4.5/5" or similar)
                if (preg_match('/Rating:\s*(\d+(\.\d+)?)\/5/i', $full_html, $matches)) {
                    $review_data['rating'] = $matches[1];
                }
                // Extract Pros/Cons (Look for li elements inside pros-cons list)
                // This is a rough heuristic; refined in v2.2
                if (preg_match_all('/<div class="[^"]*dit-ts-pros-col[^"]*is-pros[^"]*">.*?<ul>(.*?)<\/ul>/s', $full_html, $pros_matches)) {
                    if (!empty($pros_matches[1][0])) {
                        preg_match_all('/<li>(.*?)<\/li>/s', $pros_matches[1][0], $li_matches);
                        $review_data['pros'] = array_map('strip_tags', $li_matches[1]);
                    }
                }
                if (preg_match_all('/<div class="[^"]*dit-ts-pros-col[^"]*is-cons[^"]*">.*?<ul>(.*?)<\/ul>/s', $full_html, $cons_matches)) {
                    if (!empty($cons_matches[1][0])) {
                        preg_match_all('/<li>(.*?)<\/li>/s', $cons_matches[1][0], $li_matches);
                        $review_data['cons'] = array_map('strip_tags', $li_matches[1]);
                    }
                }
                $output['review_data'] = $review_data;

                // @MODIFIED 2025-12-18 - Phase 3: Run content audit before REVIEWING state
                // @MODIFIED 2025-12-26 - Phase 3: Pass sources_index for inline citation validation
                $audit_result = $auditor->audit(
                    wp_strip_all_tags(implode("\n", array_column($sections, 'body_html'))),
                    $output['intelligence']['sources'] ?? [],
                    $output['intelligence'] ?? [],
                    $sources_index
                );
                $output['audit'] = $audit_result;

                global $wpdb;
                $table = $wpdb->prefix . 'dit_ts_jobs';
                $wpdb->update(
                    $table,
                    array(
                        'status'       => self::STATE_REVIEWING,
                        'output_data'  => wp_json_encode($output),
                        'completed_at' => current_time('mysql')
                    ),
                    array('id' => $job_id),
                    array('%s', '%s', '%s'),
                    array('%d')
                );

                // @MODIFIED 2026-01-25 - Auto-Publish if requested
                if (!empty($input_data['is_auto_process'])) {
                    $this->logger->info("Auto-Publishing Job {$job_id}");
                    $post_id = $this->auto_publish_job($job_id);
                    if ($post_id) {
                        // Hook for cleaning source idea is handled by Plugin logic usually, 
                        // but here we might need to invoke it? 
                        // Plugin typically handles 'mark_as_generated' after ajax publish.
                        // We need to do it here too.
                        if (!empty($input_data['idea_id'])) {
                            // We don't have access to Idea_Importer here easily without dependency injection loop.
                            // But we can update the meta directly or fire an action.
                            do_action('dit_ts_job_auto_published', $job_id, $post_id, $input_data['idea_id']);
                        }
                    }
                }
            }

        } catch (\Throwable $e) {
        $ctx = array();
        if ($e instanceof \DIT\TrendStudio\AI_Exception) {
            $ctx = $e->get_context();
        }

        $message = $e->getMessage();
        // @MODIFIED 2026-04-23 - Check structured context before string sniffing (Finding 2.4)
        $is_quota = false;
        $wf_provider = 'gemini';
        if (!empty($ctx['reason'])) {
            $is_quota = in_array($ctx['reason'], ['daily_quota_exhausted', 'quota_runtime_hit'], true);
            $wf_provider = (string) ($ctx['provider'] ?? 'gemini');
        }
        if (!$is_quota) {
            $is_quota = (strpos($message, '429') !== false ||
                strpos($message, 'Quota') !== false ||
                strpos($message, 'limit: 0') !== false);
        }

        if ($is_quota) {
            $this->logger->warning("Quota hit during workflow step ({$status}): {$message}. Attempting fallback before rescheduling.", $ctx);

            global $wpdb;
            $table = $wpdb->prefix . 'dit_ts_jobs';

            // Attempt cross-provider fallback BEFORE rescheduling — same logic as process_job pre-flight
            $wf_fallback = null;
            if (class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Pause_Manager')) {
                $wf_strategy = AI_Provider_Factory::get_effective_strategy($input_data);
                $wf_fallback = self::resolve_first_available_fallback($wf_strategy, $input_data);
            }

            if ($wf_fallback !== null) {
                $input_data['strategy_override'] = $wf_fallback['strategy'];
                if ($wf_fallback['strategy'] === 'custom') {
                    $input_data['custom_provider_id'] = $wf_fallback['provider_id'];
                } else {
                    unset($input_data['custom_provider_id']);
                }
                $input_data['cross_provider_fallback'] = true;
                $wpdb->update($table, array('input_data' => json_encode($input_data)), array('id' => $job_id));
                $this->update_job_status($job_id, 'pending');
                delete_transient('dit_ts_job_lock');
                delete_option('dit_ts_job_executing_' . $job_id);
                $this->logger->info("Workflow step {$status}: Quota hit — switched to fallback provider '{$wf_fallback['label']}' (strategy: {$wf_fallback['strategy']}, provider_id: {$wf_fallback['provider_id']}). Re-queued as pending.");
                if (function_exists('as_enqueue_async_action')) {
                    as_enqueue_async_action('dit_ts_process_job', array($job_id));
                } elseif (function_exists('as_schedule_single_action')) {
                    as_schedule_single_action(time() + 10, 'dit_ts_process_job', array($job_id));
                }
                return;
            }

            $wpdb->update($table, array('created_at' => current_time('mysql')), array('id' => $job_id));
        if (!empty($input_data['idea_id'])) {
                update_post_meta($input_data['idea_id'], '_dit_ts_generated', 'queued');
                update_post_meta($input_data['idea_id'], '_dit_ts_flag_set_at', time());
                $this->logger->info("Graceful Exit: Re-queued source post lock for Idea {$input_data['idea_id']} (Runtime Quota hit)");
        }

            delete_transient('dit_ts_job_lock');
            delete_option('dit_ts_job_executing_' . $job_id);

            // @MODIFIED 2026-04-23 - Use $wf_provider instead of hardcoded 'gemini'
            $delay = 3600;
            if (class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Pause_Manager')) {
                $reason = !empty($ctx['reason']) ? $ctx['reason'] : 'quota_runtime_hit';
                if ($reason === 'daily_quota_exhausted') {
                    $until = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::pause($wf_provider, $reason, 3600, 86400);
                } else {
                    $until = time() + 900;
                }
                    $delay = max(900, min(3600, $until - time()));
                } else {
                    $delay = 3600;
                }

            if (function_exists('as_schedule_single_action')) {
                as_schedule_single_action(time() + 900 + wp_rand(1, 30), 'dit_ts_quota_probe', array($wf_provider));
                as_schedule_single_action(time() + $delay, 'dit_ts_process_job', array($job_id));
            }
            return;
        }

        // @MODIFIED 2026-05-05 - Circuit breaker errors are transient; reschedule instead of permanently failing.
        $cb_message = $e->getMessage();
        if (strpos($cb_message, 'Circuit breaker') !== false || strpos($cb_message, 'circuit') !== false) {
            $wpdb->update($table, array('created_at' => current_time('mysql')), array('id' => $job_id));
            $this->update_job_status($job_id, 'pending');
            if (function_exists('as_schedule_single_action')) {
                as_schedule_single_action(time() + 150, 'dit_ts_process_job', array($job_id));
            }
            $this->logger->info("Job {$job_id}: Circuit breaker open. Rescheduling in 150s instead of failing.");
            return;
        }

        $this->logger->error(
                "Workflow step {$status} failed: " . $e->getMessage(),
                array(
                    'file' => $e->getFile(),
                    'line' => $e->getLine(),
                    'context' => $ctx,
                )
            );

            $this->update_job_status($job_id, 'failed', $e->getMessage());
        }
    }
    /**
     * Check if there are any active (non-terminal) jobs
     * @MODIFIED 2026-02-12 - Added $exclude_job_id to prevent self-lockout during yields
     * @MODIFIED 2026-02-14 - Include 'pending' jobs in check to prevent premature cleanup
     * @param int $exclude_job_id Optional job ID to ignore in busy check
     * @param bool $include_pending Whether to include pending jobs in the check
     * @return bool
     */
    public function has_running_jobs($exclude_job_id = 0, $include_pending = true)
    {
        // 1. Check Database for active states (researching, drafting, etc)
        // @MODIFIED 2026-02-12 - Pass exclusion to count
        if ($this->get_running_jobs_count($exclude_job_id, $include_pending) > 0) {
            return true;
        }

        // 2. Check Atomic Transient Lock (The semaphore)
        $lock = get_transient('dit_ts_job_lock');
        if ($lock) {
            // @MODIFIED 2026-02-12 - Allow if it is our OWN lock (Resume after yield)
            if ($exclude_job_id && (int)$lock === (int)$exclude_job_id) {
                return false;
            }
            return true;
        }

        return false;
    }

    /**
     * Get the number of currently active jobs
     * 
     * @since 2.2.0
     * @MODIFIED 2026-02-14 - Added $include_pending parameter
     * @param int $exclude_job_id Optional job ID to ignore
     * @param bool $include_pending Whether to include pending jobs in the count
     * @return int
     */
    public function get_running_jobs_count($exclude_job_id = 0, $include_pending = false): int
    {
        global $wpdb;
        $table = $wpdb->prefix . 'dit_ts_jobs';

        $excluded_status = $include_pending ? "'completed', 'failed'" : "'completed', 'failed', 'pending'";
        $sql = "SELECT COUNT(*) FROM {$table} WHERE status NOT IN ({$excluded_status})";

        // @MODIFIED 2026-02-12 - Exclude specific job ID (Resume logic)
        if ($exclude_job_id) {
            $sql .= $wpdb->prepare(" AND id != %d", (int)$exclude_job_id);
        }

        $count = $wpdb->get_var($sql);
        return (int) $count;
    }

    /**
     * Publish job result to WP Post (Auto-Publish)
     * @param int $job_id
     */
    public function auto_publish_job($job_id)
    {
        $job = $this->get_job_for_publish_internal($job_id); // Internal ownership bypass
        // We need simple publish logic here
        $content = $job['block_markup'];
        if (empty($content)) return false;

        // Generate SEO metadata
        $article = $job['article'];
        if (class_exists('DIT\\TrendStudio\\SEO\\MetadataGenerator')) {
            $meta = MetadataGenerator::generate($article);
        } else {
            $meta = [
                'title'       => $job['title'],
                'description' => '',
                'slug'        => sanitize_title($job['title']),
            ];
        }

        // Prepare the new post
        // @MODIFIED 2026-02-18 - Removed [TS]/[TSF] prefix logic. Title is now clean.
        // @MODIFIED 2026-02-18 - Fix Markdown/Entities in Titles
        $ai_title = $meta['title'] ?: $job['title'];
        $ai_title = strip_tags($ai_title);
        $ai_title = html_entity_decode($ai_title, ENT_QUOTES | ENT_HTML5);
        $ai_title = str_replace(['**', '__', '##'], '', $ai_title);

        // @MODIFIED 2026-05-08 - Extract input_data BEFORE the language gate so $idea_id
        // is available for meta writes. Previously $input_data was extracted AFTER the gate,
        // causing $idea_id to be undefined and the publish_status='draft' override to be
        // silently overwritten by the re-read.
        $input_data = $job['input_data'] ?? [];
        $idea_id = (int) ($input_data['idea_id'] ?? 0);
        $publish_status = $input_data['publish_status'] ?? 'publish';

        // @MODIFIED 2026-05-08 - English language validation gate.
        // Fallback models (especially kimi-k2.6) sometimes write entire articles in
        // Roman Urdu instead of English. Detect this and block publish — force to draft.
        $plain_text = strip_tags($ai_title . ' ' . $content);
        $plain_text = html_entity_decode($plain_text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $plain_text = preg_replace('/\[[A-Z_]+\]/', '', $plain_text);
        $words = preg_split('/\s+/', trim($plain_text));
        $words = array_filter($words, function ($w) { return mb_strlen($w) > 2; });
        $total_words = count($words);
        $roman_urdu_signals = 0;
        if ($total_words >= 10) {
            $urdu_patterns = [
                '/\b(ki|ka|ke|ko|hai|hain|ka|ki|ne|se|me|par|aur|bhi|toh|yeh|woh|jo|pe|tab|ab|phir|jab|kuch|nahi|bohot|zyada|kam|sirf|bina|wala|wali|wale|hota|hoti|hote|karta|karti|karte|raha|rahi|rahe|chahiye|sakta|sakti|sakte|mila|mili|gaya|gayi|diya|diye|liya|liye|kya|kyun|kaise|kab|kahan|itna|itni|aise|taise|apna|apni|apne|khud|unke|uske|iske|inke|meri|teri|unka|uska|iska)\b/i',
            ];
            $combined = implode(' ', array_slice($words, 0, 200));
            foreach ($urdu_patterns as $p) {
                if (preg_match_all($p, $combined, $m)) {
                    $roman_urdu_signals += count($m[0]);
                }
            }
            $ratio = $roman_urdu_signals / min($total_words, 200);
            if ($ratio > 0.15) {
                if (isset($this->logger)) {
                    $this->logger->warning("English language gate: Article appears to be Roman Urdu (ratio={$ratio}, signals={$roman_urdu_signals}/{$total_words} words). Forcing draft status.", [
                        'idea_id' => $idea_id,
                        'headline' => $ai_title,
                    ]);
                }
                $publish_status = 'draft';
                if ($idea_id > 0) {
                    update_post_meta($idea_id, '_dit_ts_generated', 'failed');
                    update_post_meta($idea_id, '_dit_ts_language_flag', 'roman_urdu');
                }
            }
        }

        // @MODIFIED 2026-02-14 - Check for Draft vs Publish status
        $publish_time = $this->calculate_next_publish_time();

        $sa = \DIT\TrendStudio\Schema\Content_Schema::extract_social_assets($article);

        $post_arr = [
            'post_title' => $ai_title,
            'post_content' => $content,
            'post_author' => $job['user_id'],
            'post_type' => 'post',
            'post_name' => $meta['slug'] ?: sanitize_title($job['title']),
            // @MODIFIED 2026-04-14 - Set meta BEFORE insert so transition_post_status hook in Social_Bootstrap can process correctly
            // @MODIFIED 2026-07-21 - Use robust Content_Schema::extract_social_assets
            'meta_input' => [
                '_dit_ts_scheduled' => '1',
                '_dit_ts_generated' => '1',
                '_dit_ts_flag_set_at' => (string) time(),
                '_dit_ts_urdu_heading' => $sa['urdu_heading'] ?? '',
                '_dit_ts_urdu_description' => $sa['urdu_description'] ?? '',
                '_dit_ts_hashtags' => is_array($sa['hashtags'] ?? '') ? implode(' ', $sa['hashtags']) : ($sa['hashtags'] ?? ''),
            ],
        ];

// @MODIFIED 2026-05-09 - Fix posts publishing immediately instead of being scheduled.
	// CRITICAL: When scheduling is enabled, ALWAYS respect the calculated publish_time from settings.
	// The random interval (min_interval to max_interval) is already calculated in calculate_next_publish_time().
	// DO NOT add arbitrary buffers that override user settings.
	$scheduling_enabled = get_option('dit_ts_enable_scheduling', false);

	// @MODIFIED 2026-05-30 - Media presence guard: force pending when post has no images.
	// Prevents publishing text-only posts when media localization failed silently.
	// @MODIFIED 2026-05-31 - Also block when featured collage is missing even if content has images.
	// Ensures every published post has a proper featured image / thumbnail.
	$has_featured_collage = !empty($article['_featured_collage_id']);
	$has_content_images = (bool) preg_match('/<img\b/i', $content);
	if (!$has_featured_collage) {
		$publish_status = 'pending';
		if (isset($this->logger)) {
			$this->logger->warning("auto_publish: Media presence guard — no featured collage. Forcing pending.", [
				'idea_id' => $idea_id,
				'headline' => $ai_title,
				'has_content_images' => $has_content_images ? 'yes' : 'no',
			]);
		}
	}

	// @MODIFIED 2026-06-07 - Content presence guard: force draft when title or content is missing.
	// Follows the same pattern as the media presence guard above.
	// Prevents publishing image-only posts with no meaningful text.
	$content_plain = wp_strip_all_tags($content);
	$content_plain = html_entity_decode($content_plain, ENT_QUOTES | ENT_HTML5, 'UTF-8');
	$content_plain = trim($content_plain);
	$content_len = mb_strlen($content_plain);
	$title_len = mb_strlen($ai_title);

	if ($title_len < 5 || $content_len < 400) {
		$reason = [];
		if ($title_len < 5) $reason[] = 'title_empty';
		if ($content_len < 400) $reason[] = sprintf('content_too_short_%d', $content_len);
		$publish_status = 'draft';
		if (isset($this->logger)) {
			$this->logger->warning("auto_publish: Content presence guard — " . implode(', ', $reason) . ". Forcing draft.", [
				'idea_id' => $idea_id,
				'headline' => $ai_title,
				'title_len' => $title_len,
				'content_len' => $content_len,
			]);
		}
		if ($idea_id > 0) {
			update_post_meta($idea_id, '_dit_ts_generated', 'content_too_short');
			update_post_meta($idea_id, '_dit_ts_content_length', $content_len);
			update_post_meta($idea_id, '_dit_ts_validation_flag', implode('_', $reason));
		}
	}
	
            if ($publish_status === 'draft' || $publish_status === 'pending') {
		$post_arr['post_status'] = $publish_status;
	} else {
		// @FIXED 2026-05-09 - Use datetime string comparison instead of timestamp to avoid timezone issues
		// Previous code used strtotime() which could have timezone mismatch with current_time('timestamp')
		$now_mysql = current_time('mysql');
		$now_timestamp = current_time('timestamp');

		// @MODIFIED 2026-06-21 - Scheduling drift fix: clamp past publish times to now+interval
		// Prevents posts being published immediately when calculate_next_publish_time()
		// returns a time in the past (scheduling drift).
		if ($scheduling_enabled) {
			$publish_ts = strtotime($publish_time);
			if ($publish_ts !== false && $publish_ts <= $now_timestamp) {
				$interval_seconds = wp_rand(60, 240) * 60;
				$original_time = $publish_time;
				$publish_time = date('Y-m-d H:i:s', $now_timestamp + $interval_seconds);
				if (isset($this->logger)) {
					$this->logger->warning("auto_publish: Clamped past publish_time to future", [
						'original' => $original_time,
						'clamped' => $publish_time,
						'idea_id' => $idea_id,
					]);
				}
			}
		}

		// Compare datetime strings directly - both in WordPress timezone
		if ($scheduling_enabled && $publish_time > $now_mysql) {
			$post_arr['post_status'] = 'future';
			$post_arr['post_date'] = $publish_time;
			$post_arr['post_date_gmt'] = get_gmt_from_date($publish_time);
			if (isset($this->logger)) {
				$this->logger->info("auto_publish: Scheduling post for future publish", [
					'post_id' => $post_id ?? 'pending',
					'scheduled_time' => $publish_time,
					'now' => $now_mysql,
					'delay_seconds' => (strtotime($publish_time) - $now_timestamp)
				]);
			}
		} else {
			$post_arr['post_status'] = 'publish';
			if (isset($this->logger)) {
				$this->logger->info("auto_publish: Publishing immediately", [
					'post_id' => $post_id ?? 'pending',
					'scheduling_enabled' => $scheduling_enabled ? 'yes' : 'no',
					'publish_time' => $publish_time,
					'now' => $now_mysql,
					'reason' => $scheduling_enabled ? 'time_not_in_future' : 'scheduling_disabled'
				]);
			}
		}
	}

        $post_id = wp_insert_post($post_arr);

        if (!is_wp_error($post_id)) {
            // @MODIFIED 2026-09-10 - Link Whisper integration: inject internal links
            // into the post's Gutenberg block markup immediately after insert, so
            // the cushion before `future` publish (and any manual publish by editor)
            // gives LW time to compute suggestions. Bridge is idempotent and never
            // blocks publishing on failure.
            if (isset($this->logger)) {
                $this->logger->info('auto_publish: LW integration check', [
                    'post_id' => $post_id,
                    'class_exists' => class_exists('\\DIT\\TrendStudio\\Integrations\\LinkWhisper\\Link_Whisper_Bridge'),
                ]);
            }
            if ($post_id > 0 && class_exists('\\DIT\\TrendStudio\\Integrations\\LinkWhisper\\Link_Whisper_Bridge')) {
                try {
                    if (isset($this->logger)) {
                        $this->logger->info('auto_publish: instantiating Link_Whisper_Bridge', ['post_id' => $post_id]);
                    }
                    $lw_bridge = new \DIT\TrendStudio\Integrations\LinkWhisper\Link_Whisper_Bridge($this->logger ?? null);
                    if (isset($this->logger)) {
                        $this->logger->info('auto_publish: calling inject_for_post', ['post_id' => $post_id]);
                    }
                    $lw_bridge->inject_for_post((int) $post_id);
                    if (isset($this->logger)) {
                        $this->logger->info('auto_publish: inject_for_post returned', ['post_id' => $post_id]);
                    }
                } catch (\Throwable $lw_e) {
                    if (isset($this->logger)) {
                        $this->logger->warning('auto_publish: Link Whisper bridge threw — continuing', [
                            'post_id' => $post_id,
                            'message' => $lw_e->getMessage(),
                            'file' => $lw_e->getFile(),
                            'line' => $lw_e->getLine(),
                        ]);
                    }
                }
            } else {
                if (isset($this->logger)) {
                    $this->logger->info('auto_publish: LW bridge class not found or post_id invalid', [
                        'post_id' => $post_id,
                        'class_exists' => class_exists('\\DIT\\TrendStudio\\Integrations\\LinkWhisper\\Link_Whisper_Bridge'),
                    ]);
                }
            }

            // @MODIFIED 2026-06-21 - Record exact generation provider/model as post meta
            $provider_strategy = $input_data['strategy_override'] ?? 'gemini';
            if ($provider_strategy === 'gemini') {
                $model = \DIT\TrendStudio\Integrations\Gemini\Client::get_model_id();
                $provider_label = 'gemini/' . $model;
            } else {
                $custom_model = $input_data['custom_model_id'] ?? '';
                $provider_label = $custom_model ? 'custom/' . $custom_model : 'custom';
            }
            update_post_meta($post_id, '_dit_ts_generation_provider', $provider_label);

            // Featured image
            // @MODIFIED 2026-02-28 - Mark featured collage as plugin-managed so it can be safely cleaned up if the post is trashed/deleted.
            if (!empty($article['_featured_collage_id'])) {
                $cid = (int) $article['_featured_collage_id'];
                set_post_thumbnail($post_id, $cid);
                // @MODIFIED 2026-07-07 - Bust WP object cache for thumbnail meta so
                // Social_Bootstrap::maybe_generate_social_collage() immediately sees the
                // newly set featured image instead of falling back to _dit_ts_images.
                if (function_exists('wp_cache_delete')) {
                    wp_cache_delete($post_id . '_thumbnail_id', 'post_meta');
                    wp_cache_delete('wp_post_thumbnail_' . $post_id, 'posts');
                }
                if ($cid > 0) {
                    update_post_meta($cid, '_dit_ts_media_managed', 1);
                    update_post_meta($cid, '_dit_ts_media_owner', (int) $post_id);
                    update_post_meta($cid, '_dit_ts_media_job', (int) $job_id);
                }
            }

            // [NEW] Apply Fashion Tags
            if (!empty($article['_meta_tags'])) {
                $tags = is_array($article['_meta_tags']) ? $article['_meta_tags'] : explode(',', $article['_meta_tags']);
                // Filter out empty or non-string values
                $tags = array_filter($tags, function ($t) {
                    return is_string($t) && !empty($t);
                });
                wp_set_post_tags($post_id, $tags, true);
            }

            // @MODIFIED 2026-03-01 - Apply Campaign Tags
            if (!empty($input_data['campaign_tags'])) {
                $campaign_tags = is_array($input_data['campaign_tags']) ? $input_data['campaign_tags'] : explode(',', $input_data['campaign_tags']);
                // Filter out empty or non-string values, and trim
                $campaign_tags = array_filter(array_map('trim', $campaign_tags), function ($t) {
                    return is_string($t) && !empty($t);
                });
                wp_set_post_tags($post_id, $campaign_tags, true);
            }

            // [NEW] Apply Destination Category (Multi-Campaign Mapping)
            if (!empty($input_data['dest_category'])) {
                $dest_cats = is_array($input_data['dest_category']) ? $input_data['dest_category'] : array($input_data['dest_category']);
                $dest_cats = array_map('absint', $dest_cats);
                $dest_cats = array_filter($dest_cats);
                if (!empty($dest_cats)) {
                    wp_set_post_categories($post_id, $dest_cats);
                }
            }

            // Update custom/meta fields
            if (!empty($meta['title'])) {
                update_post_meta($post_id, '_dit_ts_meta_title', $meta['title']);
                update_post_meta($post_id, '_yoast_wpseo_title', $meta['title']);
                update_post_meta($post_id, 'rank_math_title', $meta['title']);
            }
            if (!empty($meta['description'])) {
                update_post_meta($post_id, '_dit_ts_meta_description', $meta['description']);
                update_post_meta($post_id, '_yoast_wpseo_metadesc', $meta['description']);
                update_post_meta($post_id, 'rank_math_description', $meta['description']);
            }

            // Write Focus Keyword to RankMath
            $focus_keyword = $article['primary_keyword'] ?? $meta['primary_keyword'] ?? '';
            if (empty($focus_keyword)) {
                $tags = $article['tags'] ?? array();
                $focus_keyword = is_array($tags) && !empty($tags) ? (string) reset($tags) : '';
            }
            if (empty($focus_keyword)) {
                $focus_keyword = $article['headline'] ?? '';
            }
            if (!empty($focus_keyword)) {
                update_post_meta($post_id, 'rank_math_focus_keyword', $focus_keyword);
            }

            // Store search intent for RankMath schema integration
            $intent = $article['_search_intent'] ?? $article['search_intent'] ?? '';
            if ($intent) {
                update_post_meta($post_id, '_dit_search_intent', $intent);
            }

	// @MODIFIED 2026-03-06 - Store Social Assets for WP to Buffer Pro
	// @MODIFIED 2026-07-21 - Use robust Content_Schema::extract_social_assets
	$sa = \DIT\TrendStudio\Schema\Content_Schema::extract_social_assets($article);
	if (!empty($sa) && (!empty($sa['urdu_heading']) || !empty($sa['urdu_description']))) {
		$this->logger->info('Social Queue: Registering post for Urdu asset review', ['post_id' => $post_id]);
		$sa_heading = $sa['urdu_heading'] ?? '';
		$sa_desc = $sa['urdu_description'] ?? '';
		$sa_hashtags = $sa['hashtags'] ?? '';
            if (!empty($sa_heading)) {
                update_post_meta($post_id, '_dit_ts_urdu_heading', $sa_heading);
            }
            if (!empty($sa_desc)) {
                update_post_meta($post_id, '_dit_ts_urdu_description', $sa_desc);
            }
            if (!empty($sa_hashtags)) {
                update_post_meta($post_id, '_dit_ts_hashtags', is_array($sa_hashtags) ? implode(' ', $sa_hashtags) : $sa_hashtags);
            }

            // @MODIFIED 2026-03-07 - Store in custom table for Social Review Queue
            global $wpdb;
            $inserted = $wpdb->insert(
                $wpdb->prefix . 'dit_ts_social_meta',
                array(
                    'post_id' => $post_id,
                    'urdu_heading' => $sa_heading,
                    'urdu_description' => $sa_desc,
                    'hashtags' => is_array($sa['hashtags'] ?? '') ? implode(' ', $sa['hashtags']) : ($sa['hashtags'] ?? ''),
                    'image_path' => '', // Defer social image URL until queued generation
                    'status' => 'pending',
                    'created_at' => current_time('mysql')
                ),
                array('%d', '%s', '%s', '%s', '%s', '%s', '%s')
            );

		if ($inserted === false) {
			$this->logger->error('Social Queue DB Insert Failed', ['error' => $wpdb->last_error, 'table' => $wpdb->prefix . 'dit_ts_social_meta']);
		} else {
			$this->logger->info('Social Queue DB Insert Success', ['row_id' => $wpdb->insert_id]);
			// @FIXED 2026-05-09: DO NOT immediately mark Urdu assets as 'completed' on publish.
			// Previously: status was set to 'completed' immediately, causing Urdu assets to disappear
			// from the Social Queue admin page where they need to be reviewed for collage generation.
			// Status will be updated to 'completed' later by Social_Bootstrap when collage is successfully generated.
		}
            }

            // @MODIFIED 2026-03-06 - Store Collage URL for Buffer Pro (Legacy 16:9 or Showbiz)
            if (!empty($article['_featured_collage_id'])) {
                $image_url = wp_get_attachment_url($article['_featured_collage_id']);
                if ($image_url) {
                    update_post_meta($post_id, '_dit_ts_social_image_url', $image_url);
                }
            }

// @MODIFIED 2026-05-07 - Re-parent query no longer requires post_parent=0.
// Previously required post_parent=0 which missed transfer_* attachments that were never
// detached during generation. Now queries by meta keys (consistent with Media_Transfer_Service)
// and moves all job-managed attachments regardless of their current post_parent.
// All three meta keys must match — prevents cross-contamination if job IDs overlap.
$attachments = \get_posts([
    'post_type' => 'attachment',
    'post_status' => 'inherit',
    'meta_query' => [
        'relation' => 'AND',
        [
            'key' => '_dit_ts_media_job',
            'value' => $job_id,
            'compare' => '=',
        ],
        [
            'key' => '_dit_ts_media_managed',
            'value' => '1',
            'compare' => '=',
        ],
        [
            'key' => '_dit_ts_media_owner',
            'value' => (string) $idea_id,
            'compare' => '=',
        ],
    ],
    'fields' => 'ids',
    'posts_per_page' => -1,
]);

        if (!empty($attachments)) {
            foreach ($attachments as $att_id) {
                \wp_update_post([
                    'ID' => $att_id,
                    'post_parent' => $post_id
                ]);
            }
            // @MODIFIED 2026-04-20 - Store attachment IDs in _dit_ts_images meta
            // so Social_Bootstrap::get_post_image_urls() can find them
            update_post_meta($post_id, '_dit_ts_images', array_map('intval', $attachments));

            if (isset($this->logger)) {
                $this->logger->info("auto_publish: Re-parented " . count($attachments) . " kept attachments to final Post $post_id");
            }
        }

        // @MODIFIED 2026-05-09 - SYNCHRONOUS social collage generation (eliminates race condition).
        // @MODIFIED 2026-05-09 - REMOVED conditional: always generate collage synchronously
        // Previous async approach had race condition: transition_post_status fires BEFORE Urdu assets
        // are written to dit_ts_social_meta table, causing "Urdu assets missing" aborts.
        // NEW APPROACH: Generate collage NOW, synchronously, after:
        // 1. Urdu assets are in post_meta (lines 2308-2315)
        // 2. Urdu assets are in dit_ts_social_meta (lines 2436-2460)
        // 3. Media is re-parented (lines 2476-2515)
        // This utilizes the "cushion" time for future posts - collage is ready BEFORE publish.
        $collage_generated = false;
        // Always generate social collage - no option needed
        // This ensures collage is ready BEFORE post is fully published
        if (!class_exists('\\DIT\\TrendStudio\\Core\\Social_Bootstrap')) {
            require_once DIT_TS_PLUGIN_DIR . 'src/Core/Social_Bootstrap.php';
        }
        if (!class_exists('\\DIT\\TrendStudio\\Services\\Collage_Generator')) {
            require_once DIT_TS_PLUGIN_DIR . 'src/Services/Collage_Generator.php';
        }
        if (!class_exists('\\DIT\\TrendStudio\\Services\\Social_Queue_Manager')) {
            require_once DIT_TS_PLUGIN_DIR . 'src/Services/Social_Queue_Manager.php';
        }
        $sb_logger = new \DIT\TrendStudio\Infrastructure\Logger();
        $sb_generator = new \DIT\TrendStudio\Services\Collage_Generator($sb_logger);
        // @MODIFIED 2026-05-09 - Fix constructor arg order: Social_Queue_Manager expects Collage_Generator as arg #1
        $sb_queue = new \DIT\TrendStudio\Services\Social_Queue_Manager($sb_generator);
        $social_bootstrap = new \DIT\TrendStudio\Core\Social_Bootstrap($sb_logger, $sb_generator, $sb_queue);
        $collage_id = $social_bootstrap->maybe_generate_social_collage($post_id);
        if ($collage_id) {
            $collage_generated = true;
            if (get_option('dit_ts_jetpack_enabled', false)) {
                $social_bootstrap->sync_to_jetpack($post_id);
            }
            if (isset($this->logger)) {
                $this->logger->info("auto_publish: Social collage #{$collage_id} generated synchronously for post #{$post_id}");
            }
        } else {
            if (isset($this->logger)) {
                $this->logger->warning("auto_publish: Social collage generation skipped for post #{$post_id} (no Urdu assets or images)");
            }
        }

            // Complete job and record completion time
            // @MODIFIED 2026-01-30 - Store generated post ID for dashboard linking
            global $wpdb;
            $table = $wpdb->prefix . 'dit_ts_jobs';

            $wpdb->update(
                $table,
                array(
                    'status' => 'completed',
                    'completed_at' => current_time('mysql'),
                    'post_id' => $post_id
                ),
                array('id' => $job_id),
                array('%s', '%s', '%d'),
                array('%d')
            );

            // Also update option for cooldown check
            update_option('dit_ts_last_job_completion', time());

            // @MODIFIED 2026-05-05 - Finding 3: Explicitly release the job-lock transient on
            // successful publish. The normal process_job() success path never calls
            // update_job_status(), so the transient (TTL=300s) would survive up to 5 minutes
            // after job completion and falsely block subsequent campaign triggers.
            delete_transient('dit_ts_job_lock');

            return $post_id;
        }
        return false;
    }

    // Helper for internal use (duplicates specific parts of get_job_for_publish_internal without user check)
    private function get_job_for_publish_internal($job_id)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'dit_ts_jobs';
        $job = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $job_id), ARRAY_A);
        $output = json_decode($job['output_data'], true);
        $article = isset($output['article']) ? $output['article'] : $output;
        $block_markup = $output['block_markup'] ?? (new Content_Formatter())->to_block_markup($article, false);
        return [
            'article' => $article,
            'block_markup' => $block_markup,
            'title' => $article['headline'] ?? 'Untitled',
            'user_id' => $job['user_id'],
            'input_data' => json_decode($job['input_data'], true) ?: []
        ];
    }

    /**
     * Clear jobs stuck in processing for too long
     * @MODIFIED 2026-01-29 - Added 3-retry logic before failing
     * @param int $timeout_seconds Default 600 (10 mins)
     * @return int Number of jobs failed/retried
     */
    public function clear_stuck_jobs($timeout_seconds = 1800)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'dit_ts_jobs';

        // @MODIFIED 2026-02-22 - Fixed Bug: Use current_time('timestamp') to match DB timezone
        $cutoff = date('Y-m-d H:i:s', current_time('timestamp') - $timeout_seconds);

        // @MODIFIED 2026-06-21 - Skip jobs with recent heartbeat (actively running, not stuck)
        $heartbeat_cutoff = date('Y-m-d H:i:s', current_time('timestamp') - 120);

        // Find stuck jobs
        // @MODIFIED 2026-02-13 - Exclude 'pending' from stuck check. 
        // Pending jobs are waiting for the 20-min gap and shouldn't be failed by Watchdog.
        $stuck_jobs = $wpdb->get_results($wpdb->prepare(
            "SELECT id, input_data FROM {$table} 
             WHERE status IN ('processing', 'briefing', 'researching', 'outlining', 'drafting') 
             AND created_at < %s
             AND (updated_at IS NULL OR updated_at < %s)",
            $cutoff,
            $heartbeat_cutoff
        ), ARRAY_A);

        if (empty($stuck_jobs)) {
            return 0;
        }

        // @MODIFIED 2026-02-22 - CRITICAL Engine Recovery: Clear blocked transients/locks if stuck jobs exist
        delete_transient('dit_ts_job_lock');
        delete_option('dit_ts_job_start_mutex');


        $count = 0;
        foreach ($stuck_jobs as $job) {
            $id = $job['id'];
            $input_data = json_decode($job['input_data'], true) ?: [];
            $retry_count = isset($input_data['_retry_count']) ? (int)$input_data['_retry_count'] : 0;

            if ($retry_count < 3) {
                // Retry
                $retry_count++;
                $input_data['_retry_count'] = $retry_count;

                // Update DB: input_data (for count) AND reset created_at (to reset timeout clock)
                // @FIXED 2026-01-29 - CRITICAL: Must reset status to 'pending' so it gets picked up again
                $wpdb->update(
                    $table,
                    array(
                        'status' => 'pending', // <--- THE FIX
                        'input_data' => wp_json_encode($input_data),
                        'created_at' => current_time('mysql'), // Reset clock
                        'error_message' => "Auto-retrying attempt {$retry_count}/3" // Helpful status
                    ),
                    array('id' => $id),
                    array('%s', '%s', '%s', '%s'),
                    array('%d')
                );

                $this->logger->warning("Watchdog: Job {$id} stuck. Resetting to PENDING for Auto-retry (Attempt {$retry_count}/3).");

                // @MODIFIED 2026-03-13 - Ensure thread mutex is cleared for the specific job being retried
                delete_option('dit_ts_job_executing_' . $id);

                // Trigger async processing
                if (function_exists('as_enqueue_async_action')) {
                    as_enqueue_async_action('dit_ts_process_job', array($id));
                }
            } else {
                // Fail
                $this->update_job_status($id, 'failed');
                // @MODIFIED 2026-03-13 - Ensure thread mutex is cleared even on max-retry failure
                delete_option('dit_ts_job_executing_' . $id);
                $this->logger->error("Watchdog: Job {$id} stuck. Max retries (3) reached. Marked as failed.");
            }
            $count++;
        }

        return $count;
    }

    /**
     * Detect and fail orphaned pending jobs that have exceeded their maximum lifetime.
     * @MODIFIED 2026-05-08 - Added pending-job aging to complement clear_stuck_jobs().
     * Pending jobs are normally excluded from the stuck-jobs watchdog because they may be
     * waiting for the gap-enforcement cooldown. However, quota-pause loops can keep a job
     * in 'pending' indefinitely by repeatedly rescheduling it far into the future. This
     * method catches such orphans: pending jobs older than the threshold with no scheduled
     * Action Scheduler callback (or one scheduled > 2h out) are marked failed and their
     * source post lock is released.
     *
     * @param int $max_pending_seconds Default 7200 (2 hours)
     * @return int Number of jobs failed
     */
    public function clear_stale_pending_jobs($max_pending_seconds = 7200)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'dit_ts_jobs';

        $cutoff = date('Y-m-d H:i:s', current_time('timestamp') - $max_pending_seconds);

        $stale_pending = $wpdb->get_results($wpdb->prepare(
            "SELECT id, input_data FROM {$table}
             WHERE status = 'pending'
             AND created_at < %s",
            $cutoff
        ), ARRAY_A);

        if (empty($stale_pending)) {
            return 0;
        }

        $count = 0;
        foreach ($stale_pending as $job) {
            $id = (int) $job['id'];
            $input_data = json_decode($job['input_data'], true) ?: [];
            $idea_id = (int) ($input_data['idea_id'] ?? 0);

            // Skip if a legitimate Action Scheduler action is scheduled within 2 hours
            $has_near_term_action = false;
            if (function_exists('as_has_scheduled_action')) {
                $has_near_term_action = as_has_scheduled_action('dit_ts_process_job', array($id));
            }

            if ($has_near_term_action) {
                // Action exists — check if it's scheduled too far in the future (> 2h)
                // If so, it's likely stuck in a quota-pause loop
                if (function_exists('as_get_scheduled_actions') && class_exists('\ActionScheduler_Store')) {
                    $scheduled = as_get_scheduled_actions([
                        'hook' => 'dit_ts_process_job',
                        'args' => array($id),
                        'status' => \ActionScheduler_Store::STATUS_PENDING,
                        'per_page' => 1,
                    ]);
                    if (!empty($scheduled)) {
                        $next_run = reset($scheduled)->get_schedule()->next();
                        if ($next_run && ($next_run - time()) > 7200) {
                            // Scheduled > 2h out — effectively stuck in quota-pause loop
                            $has_near_term_action = false;
                            $this->logger->warning("Watchdog: Job {$id} pending > 2h with next run > 2h away. Breaking quota-pause loop.");
                        }
                    }
                }
            }

            if ($has_near_term_action) {
                $this->logger->info("Watchdog: Job {$id} pending > 2h but has near-term scheduled action. Skipping.");
                continue;
            }

            // Mark as failed and release source post lock
            $this->update_job_status($id, 'failed', 'Watchdog: pending job exceeded ' . ((int) $max_pending_seconds / 60) . 'm lifetime. No near-term scheduled action.');
            delete_option('dit_ts_job_executing_' . $id);
            $this->logger->warning("Watchdog: Job {$id} pending > " . ((int) $max_pending_seconds / 60) . "m with no scheduled action. Marked failed. Idea {$idea_id} released.");
            $count++;
        }

        return $count;
    }

    /**
 *
 * @since 2.1.6
     * @param int $job_id
     * @return bool True if reset
     */
    public function recover_job($job_id)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'dit_ts_jobs';

        $this->logger->info("Hard Reset requested for Job {$job_id}");

        $job = $wpdb->get_row(
            $wpdb->prepare("SELECT input_data FROM {$table} WHERE id = %d", $job_id),
            ARRAY_A
        );

        if (!$job || empty($job['input_data'])) {
            return false;
        }

        $input_data = json_decode($job['input_data'], true) ?: array();

        // @MODIFIED 2026-02-24 - Clear retry history on reset.
        if (isset($input_data['_retry_count'])) {
            unset($input_data['_retry_count']);
        }

        $now_mysql = current_time('mysql');

        // @MODIFIED 2026-02-24 - Use explicit SQL to ensure NULL fields are set correctly (wpdb->update + NULL is inconsistent).
        $updated = $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$table}
                 SET status = %s,
                     output_data = NULL,
                     validation_results = NULL,
                     error_message = NULL,
                     completed_at = NULL,
                     input_data = %s,
                     created_at = %s
                 WHERE id = %d",
                'pending',
                wp_json_encode($input_data),
                $now_mysql,
                $job_id
            )
        );

        if ($updated !== false) {
            $this->logger->info("Job {$job_id} was successfully hard reset.");
            return true;
        }

        return false;
    }

    /**

     * Forcefully delete jobs stuck in processing for too long
     * @MODIFIED 2026-01-27 - Hard delete stuck jobs to clear UI
     * @param int $timeout_seconds Default 3600 (1 hour)
     * @return int Number of jobs deleted
     */
    public function force_clear_stuck_jobs($timeout_seconds = 1800)
    {
        global $wpdb;
        $table = $wpdb->prefix . 'dit_ts_jobs';

        // @MODIFIED 2026-01-27 - Use current_time('timestamp') to match current_time('mysql') stored in DB
        $cutoff = date('Y-m-d H:i:s', current_time('timestamp') - $timeout_seconds);

        // Mark stuck jobs as failed (do NOT delete; keep audit trail)
        $message  = sprintf('Watchdog: job exceeded %ds timeout. Marked failed.', (int) $timeout_seconds);
        $now_mysql = current_time('mysql');

        // Fetch IDs first to process their locks later
        // @MODIFIED 2026-02-13 - Exclude 'pending' status.
        // @MODIFIED 2026-06-01 - Dynamic self-healing safety: fallback to created_at if updated_at doesn't exist yet
        $has_updated_at = $wpdb->get_results("SHOW COLUMNS FROM {$table} LIKE 'updated_at'");
        $date_expr = !empty($has_updated_at) ? 'COALESCE(updated_at, created_at)' : 'created_at';

        // @MODIFIED 2026-06-21 - Skip jobs with recent heartbeat (actively running, not stuck)
        $heartbeat_cutoff = date('Y-m-d H:i:s', current_time('timestamp') - 120);

        $stuck_jobs = $wpdb->get_results($wpdb->prepare(
            "SELECT id, input_data FROM {$table} 
             WHERE status IN ('processing', 'briefing', 'researching', 'outlining', 'drafting') 
             AND {$date_expr} < %s
             AND (updated_at IS NULL OR updated_at < %s)",
            $cutoff,
            $heartbeat_cutoff
        ), ARRAY_A);

        $affected = $wpdb->query($wpdb->prepare(
            "UPDATE {$table}
             SET status = 'failed',
                  error_message = %s,
                  completed_at = %s
             WHERE status IN ('processing', 'briefing', 'researching', 'outlining', 'drafting')
               AND {$date_expr} < %s
               AND (updated_at IS NULL OR updated_at < %s)",
            $message,
            $now_mysql,
            $cutoff,
            $heartbeat_cutoff
        ));

        if ($affected > 0) {
            $this->logger->info("Watchdog marked {$affected} stuck jobs as failed.");

            // @MODIFIED 2026-02-09 - Release locks on source posts (Self-Healing)
            // @MODIFIED 2026-05-06 - Guard: Only delete flag if no newer job already holds 'queued'/'processing'.
            // When a failed post is re-queued, a newer job sets _dit_ts_generated='queued'.
            // Forcing delete here would wipe that newer lock, causing duplicate pickup.
            foreach ($stuck_jobs as $job) {
                $input = json_decode($job['input_data'], true);
                if (!empty($input['idea_id'])) {
                    $current_flag = get_post_meta((int) $input['idea_id'], '_dit_ts_generated', true);
                    if ($current_flag === 'queued' || $current_flag === 'processing') {
                        // @MODIFIED 2026-05-08 - Cross-check jobs table before skipping (same logic as update_job_status)
                        $active_states = "'pending','processing','briefing','researching','outlining','drafting'";
                        $has_active = (int) $wpdb->get_var($wpdb->prepare(
                            "SELECT COUNT(*) FROM {$table} WHERE status IN ({$active_states}) AND input_data LIKE %s AND id != %d LIMIT 1",
                            '%' . $wpdb->esc_like('"idea_id":' . (int) $input['idea_id']) . '%',
                            (int) $job['id']
                        ));
                        if ($has_active > 0) {
                            $this->logger->info("Skipped flag release for Idea {$input['idea_id']} — newer active job exists (flag='{$current_flag}', Job {$job['id']} is stale)");
                        } else {
                            update_post_meta($input['idea_id'], '_dit_ts_generated', 'failed');
                            update_post_meta($input['idea_id'], '_dit_ts_flag_set_at', time());
                            $this->logger->info("Force-released 'failed' flag for Idea {$input['idea_id']} (Job {$job['id']} timed out, no newer active job, previous flag='{$current_flag}')");
                        }
                    } else {
                        delete_post_meta($input['idea_id'], '_dit_ts_generated');
                        delete_post_meta($input['idea_id'], '_dit_ts_flag_set_at');
                        $this->logger->info("Released source post lock for Idea {$input['idea_id']} (Job {$job['id']} timed out)");
                    }
                }
                // @MODIFIED 2026-03-13 - Ensure thread mutex is cleared for each job being forced to fail
                delete_option('dit_ts_job_executing_' . $job['id']);
            }

            // @MODIFIED 2026-02-22 - CRITICAL: Clear engine locks after watchdog forced failure
            delete_transient('dit_ts_job_lock');
            delete_option('dit_ts_job_start_mutex');
        }

        return $affected;
    }

    /**
     * Clear ALL jobs from the database (Nuclear Option)
     * @MODIFIED 2026-01-27 - Added full wipe capability
     * @return int Number of rows affected
     */
    public function clear_all_jobs()
    {
        global $wpdb;
        $table = $wpdb->prefix . 'dit_ts_jobs';

        $deleted = $wpdb->query("DELETE FROM {$table}");

        $this->logger->info("Nuclear Option: Cleared ALL {$deleted} jobs.");

        return $deleted;
    }

    /**
     * Publish watchdog: publish plugin-generated posts whose publish time has arrived
     *
     * Runs on a recurring Action Scheduler event (every 2 minutes). Scans for posts
     * marked with `_dit_ts_scheduled = '1'` that are still in `future` status past their
     * `post_date_gmt`, and force-publishes them via `wp_publish_post()`.
     *
     * This is the recovery layer for the WordPress "Missed schedule" condition that
     * happens when WP-Cron (or a server-level cron calling wp-cron.php) does not fire
     * the `publish_future_post` event on time. Action Scheduler is used because it
     * survives on hosts that disable WP-Cron (WPEngine, Kinsta, Pressable).
     *
     * @MODIFIED 2026-06-01 - Added plugin-owned publish watchdog to fix missed-schedule.
     * @param int $batch Maximum posts to publish per invocation (default 20)
     * @return int Number of posts published
     */
    public function publish_due_scheduled_posts($batch = 20)
    {
        global $wpdb;

        $batch = max(1, (int) $batch);

        // Master AI Switch guard: do not republish anything while automation is off.
        $is_automation_enabled = (int) get_option('dit_ts_enable_ai_automation', '1');
        if (!$is_automation_enabled) {
            return 0;
        }

        // Use post_date_gmt (UTC, deterministic) — not post_date which is WP-local and
        // can drift across DST boundaries.
        $now_gmt = current_time('mysql', 1); // GMT

        // @MODIFIED 2026-06-01 - Use a single indexed query against post_status + post_date
        // and the `_dit_ts_scheduled` meta. The meta key is what auto_publish_job() stamps
        // on every plugin-generated post (see Scheduler::auto_publish_job, line ~2368),
        // so we only touch posts that the plugin itself scheduled — never user drafts.
        $due_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT p.ID FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
             WHERE p.post_status = 'future'
               AND p.post_date_gmt <= %s
               AND pm.meta_key = '_dit_ts_scheduled'
               AND pm.meta_value = '1'
             ORDER BY p.post_date_gmt ASC
             LIMIT %d",
            $now_gmt,
            $batch
        ));

        if (empty($due_ids)) {
            return 0;
        }

        $published = 0;
        $failed    = 0;

        foreach ($due_ids as $post_id) {
            $post_id = (int) $post_id;
            if ($post_id <= 0) {
                continue;
            }

            // Defensive re-check: skip if a concurrent worker already published it.
            $current_status = get_post_status($post_id);
            if ($current_status !== 'future') {
                continue;
            }

            $scheduled_for = get_post_field('post_date_gmt', $post_id, 'raw');

            // wp_publish_post() is the canonical WordPress function. It:
            //   - Transitions post_status from 'future' to 'publish'
            //   - Fires 'transition_post_status', 'future_to_publish', 'save_post' hooks
            //   - Updates post_date_gmt to match post_date if needed
            //   - Triggers subsequent cron events (e.g. social queue) downstream
            // @MODIFIED 2026-06-07 - wp_publish_post() returns void (null) by design.
            // Verify publication by re-checking post status instead of relying on return value.
            wp_publish_post($post_id);
            $after_status = get_post_status($post_id);

            if ($after_status === 'publish') {
                $published++;
                $delay_seconds = max(0, time() - (int) mysql2date('U', $scheduled_for . ' 00:00:00'));
                $this->logger->info(sprintf(
                    'Publish Watchdog: published post %d (scheduled_for=%s, delay=%ds)',
                    $post_id,
                    $scheduled_for,
                    $delay_seconds
                ));
            } else {
                $failed++;
                $this->logger->warning(sprintf(
                    'Publish Watchdog: post %d status after wp_publish_post: %s (scheduled_for=%s)',
                    $post_id,
                    $after_status,
                    $scheduled_for
                ));
            }
        }

        if ($published > 0) {
            $this->logger->info(sprintf(
                'Publish Watchdog: recovered %d missed-schedule post(s) (%d failed).',
                $published,
                $failed
            ));
        }

        return $published;
    }

    private function assert_media_passthrough(string $input_html, array $article_data): void
    {
        // @MODIFIED 2026-02-14 - Use robust associative extraction
        $passthrough = new \DIT\TrendStudio\Services\Media_Passthrough($this->logger);

        // @MODIFIED 2026-02-17 - Validate against the *Selected* visuals (via MediaSelector), not raw input.
        // This prevents false positives when MediaSelector culls images (limit 15).
        // We need input_data to get the map. Since we don't have it passed here, we must parse it from the method signature?
        // Wait, assert_media_passthrough signature is (string $input_html, array $article_data).
        // We need to fetch the input_data from the job context or pass it in.
        // Looking at call sites: extract_required_visuals($input_html) was using raw text.
        // We'll trust the $article_data['_source_visual_map'] if available (attached in process_workflow_step).

        $required_map = [];
        if (!empty($article_data['_source_visual_map'])) {
            foreach ($article_data['_source_visual_map'] as $item) {
                if (!empty($item['tag']) && !empty($item['url'])) {
                    $required_map[$item['tag']] = $item['url'];
                }
            }
        } else {
            // Fallback to raw extraction if no map (legacy jobs)
            $required_map = $passthrough->extract_required_visuals($input_html);
        }

        if (empty($required_map)) return;

        // @MODIFIED 2026-02-17 - Scan Structured Blocks for visuals (visual_ref/embed_ref)
        // This is required because 'body_html' might not be fully hydrated with images yet in structured mode.
        $block_found_urls = [];
        if (!empty($article_data['sections']) && is_array($article_data['sections'])) {
            foreach ($article_data['sections'] as $sec) {
                if (!empty($sec['blocks']) && is_array($sec['blocks'])) {
                    foreach ($sec['blocks'] as $b) {
                        // 1. Visual Refs (Images mapped to [VISUAL_N])
                        if (($b['type'] ?? '') === 'visual_ref' && isset($b['id'])) {
                            $token_key = '[VISUAL_' . $b['id'] . ']';
                            // Look up URL in source map
                            if (!empty($article_data['_source_visual_map'][$token_key]['url'])) {
                                $block_found_urls[] = $article_data['_source_visual_map'][$token_key]['url'];
                            }
                        }
                        // 2. Embed Refs (Direct URLs)
                        if (($b['type'] ?? '') === 'embed_ref' && !empty($b['url'])) {
                            $block_found_urls[] = $b['url'];
                        }
                    }
                }
            }
        }

        // Build the output HTML blob to search
        $out = '';

        // @MODIFIED 2026-02-14 - Include hero_image in searchable blob
        if (!empty($article_data['hero_image'])) {
            $out .= "\n" . $article_data['hero_image'];
        }

        if (!empty($article_data['sections']) && is_array($article_data['sections'])) {
            foreach ($article_data['sections'] as $s) {
                // Check both body_html (canonical) and legacy bodyhtml
                $out .= "\n" . ($s['body_html'] ?? $s['bodyhtml'] ?? '');
            }
        }

        $missing = [];
        $out_clean = \DIT\TrendStudio\Security\Sanitizer::decode_ai_string($out);

        foreach ($required_map as $tag => $url) {
            // @MODIFIED 2026-02-14 - Robustify: Check for EITHER the original tag OR the URL
            // This handles cases where tags are slightly modified (alt text, quotes) but the URL is preserved.
            // @MODIFIED 2026-02-14 - Robust unescaping for comparison
            $url = \DIT\TrendStudio\Security\Sanitizer::decode_ai_string($url);

            // @MODIFIED 2026-06-28 - For oEmbed URLs (Instagram/YouTube/TikTok etc.),
            // a bare URL in body text (e.g. inside an <a> tag linking to a profile) does NOT satisfy
            // passthrough — the URL must appear as an actual embed_ref block. Without this check,
            // Instagram reel URLs in <a href> text caused false-positive passthrough assertions.
            $is_oembed_url = false;
            $oembed_hosts = ['youtube.com', 'youtu.be', 'vimeo.com', 'tiktok.com', 'instagram.com', 'twitter.com', 'x.com', 'facebook.com', 'pinterest.com'];
            $url_host = strtolower(parse_url($url, PHP_URL_HOST) ?: '');
            foreach ($oembed_hosts as $oh) {
                if (stripos($url_host, $oh) !== false) {
                    $is_oembed_url = true;
                    break;
                }
            }

            if ($is_oembed_url) {
                // For oEmbed URLs: only consider it "present" if it exists as an embed_ref block
                $found_in_blocks = false;
                foreach ($block_found_urls as $b_url) {
                    if (stripos($b_url, $url) !== false || stripos($url, $b_url) !== false) {
                        $found_in_blocks = true;
                        break;
                    }
                }
                if (!$found_in_blocks) {
                    $missing[] = $url;
                }
            } elseif (stripos($out_clean, $tag) === false && stripos($out_clean, $url) === false) {

                // @MODIFIED 2026-02-17 - Rescue via Structured Blocks
                $found_in_blocks = false;
                foreach ($block_found_urls as $b_url) {
                    // Loose matching to handle encoding/protocol differences
                    if (stripos($b_url, $url) !== false || stripos($url, $b_url) !== false) {
                        $found_in_blocks = true;
                        break;
                    }
                }

                if (!$found_in_blocks) {
                    $missing[] = $url;
                }
            }
        }

        if (!empty($missing)) {
            // Check if we have ANY placeholders in output. 
            // @MODIFIED 2026-02-14 - If we have missing visuals AND NO placeholders, it's a hard failure.
            // If we have placeholders, we are more lenient as the pipeline likely swapped a broken URL for a placeholder.
            $placeholder = 'via.placeholder.com';
            if (stripos($out_clean, $placeholder) === false) {
                $msg = "MEDIA PASSTHROUGH FAILED. Missing visuals in output: " . implode(' | ', array_slice($missing, 0, 10));
                throw new \DIT\TrendStudio\AI_Exception($msg, [
                    'reason' => 'media_passthrough_failed',
                    'missing_count' => count($missing),
                    'missing_urls' => array_slice($missing, 0, 10),
                ]);
            } else {
                $this->logger->info("Media passthrough warns of missing originals, but placeholders found. Proceeding.");
            }
        }
    }

    /**
     * Cancel all pending and processing jobs
     * @MODIFIED 2026-02-10 - New Emergency Stop helper
     * 
     * @return int Number of cancelled jobs
     */
    public function cancel_all_jobs()
    {
        global $wpdb;
        $table = $wpdb->prefix . 'dit_ts_jobs';

        // 1. Bulk Update DB status
        $count = $wpdb->query(
            "UPDATE {$table} 
             SET status = 'failed', error_message = 'Cancelled by Master Switch Emergency Stop', completed_at = NOW() 
             WHERE status IN ('pending', 'processing', 'briefing', 'researching', 'outlining', 'drafting')"
        );

        // 2. Clear Action Scheduler Queue
        if (function_exists('as_unschedule_all_actions')) {
            as_unschedule_all_actions('dit_ts_process_job');
        }

        return (int) $count;
    }

    /**
     * Centralized System Reset
     * Wipes all transients/locks and resets active jobs to pending to restore engine flow.
     * 
     * @since 2.4.0
     * @return array Summary of cleared items
     */
    public function reset_system_state()
    {
        global $wpdb;
        $table = $wpdb->prefix . 'dit_ts_jobs';

        $this->logger->warning("SYSTEM RESET TRIGGERED: Clearing all transients, locks, and resetting jobs.");

        // 1. Clear Transients
        delete_transient('dit_ts_job_lock');
        delete_transient('dit_ts_gemini_quota_pause');
        delete_transient('dit_ts_gemini_daily_quota_exhausted');
        delete_transient('dit_ts_gemini_daily_quota_exhausted'); // legacy flag cleanup
        delete_transient('dit_ts_schedule_last_check');
        delete_transient('dit_ts_pending_drain_active');

        // @MODIFIED 2026-04-22 - Clear ALL provider quota pauses via Quota_Pause_Manager
        // Previously only deleted legacy transients, leaving modern options active.
        if (class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Pause_Manager')) {
		foreach (['gemini', 'custom'] as $provider) {
                Quota_Pause_Manager::clear($provider);
            }
        }

        // 2. Clear Mutex
        delete_option('dit_ts_job_start_mutex');

        // 3. Clear per-job execution locks
        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
                $wpdb->esc_like('dit_ts_job_executing_') . '%'
            )
        );

        // 4. Cancel Action Scheduler actions
        if (function_exists('as_unschedule_all_actions')) {
            as_unschedule_all_actions('dit_ts_process_job');
            as_unschedule_all_actions('dit_ts_resume_pending_jobs');
        }

        // 5. Reset active jobs to pending
        $active_statuses = array(
            'processing',
            'briefing',
            'researching',
            'outlining',
            'drafting',
            'reviewing'
        );

        $placeholders = implode(', ', array_fill(0, count($active_statuses), '%s'));
        $params = array_merge(array(current_time('mysql')), $active_statuses);

        $updated = $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$table}
                 SET status = 'pending',
                     error_message = NULL,
                     created_at = %s
                 WHERE status IN ($placeholders)",
                $params
            )
        );

        // 6. Trigger queue processor to resume pending jobs
        set_transient('dit_ts_pending_drain_active', true, HOUR_IN_SECONDS);

        if (function_exists('as_enqueue_async_action')) {
            as_enqueue_async_action('dit_ts_resume_pending_jobs', array(1));
        }

        // 7. Get pending count
        $pending = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE status = 'pending'");

        return [
            'transients' => true,
            'mutex'      => true,
            'executing_locks_cleared' => true,
            'jobs_reset' => (int) $updated,
            'pending'   => $pending
        ];
    }

    /**
     * Calculate the next available publish time based on schedule settings
     * @since 2.3.0
     * @return string MySQL formatted datetime
     */
    public function calculate_next_publish_time()
    {
        // 1. Get Settings
        $enabled = get_option('dit_ts_enable_scheduling', false);
        if (!$enabled) {
            return current_time('mysql');
        }

        $posts_per_day = (int) get_option('dit_ts_posts_per_day', 5);
        $start_time    = get_option('dit_ts_publish_start', '09:00');
        $end_time      = get_option('dit_ts_publish_end', '20:00');
$min_interval = (int) get_option('dit_ts_min_interval', 60);
$max_interval = (int) get_option('dit_ts_max_interval', 240);
        $active_days   = get_option('dit_ts_active_days', ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun']);

        // @MODIFIED 2026-02-15 - Find latest scheduled post using meta instead of title prefixes
        global $wpdb;
        $latest_date = $wpdb->get_var("
            SELECT MAX(p.post_date) FROM {$wpdb->posts} p
            INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
            WHERE (p.post_status = 'future' OR (p.post_status = 'publish' AND p.post_date > NOW()))
            AND pm.meta_key = '_dit_ts_scheduled' AND pm.meta_value = '1'
        ");

$now = current_time('timestamp');
		$candidate_ts = $latest_date ? strtotime($latest_date) : $now;

		// Add random interval
		$interval_seconds = wp_rand($min_interval * 60, $max_interval * 60);
		$candidate_ts += $interval_seconds;

		// @ADDED 2026-05-09 - Log scheduling calculation for debugging
		if (isset($this->logger)) {
			$this->logger->info("calculate_next_publish_time: Initial calculation", [
				'enabled' => $enabled ? 'yes' : 'no',
				'latest_date' => $latest_date ?: 'none',
				'interval_minutes' => round($interval_seconds / 60, 1),
				'candidate_time' => date('Y-m-d H:i:s', $candidate_ts),
				'now' => date('Y-m-d H:i:s', $now)
			]);
		}

		// Ensure candidate is strictly in the future so WP converts publish→future
		if ($candidate_ts <= $now) {
			$candidate_ts = $now + $interval_seconds; // @FIXED: Use interval_seconds instead of hardcoded 60
		}

        $max_iterations = 30; // Safety break for 30 days ahead
        $iterations = 0;

        while ($iterations < $max_iterations) {
            $iterations++;
            $day_of_week = strtolower(date('D', $candidate_ts));

            // A. Check if day is active
            if (!in_array($day_of_week, $active_days)) {
                // Move to start of next day
                $candidate_ts = strtotime('tomorrow 00:00:00', $candidate_ts);
                continue;
            }

            // B. Check if within time window
            $day_start = strtotime(date('Y-m-d', $candidate_ts) . ' ' . $start_time);
            $day_end   = strtotime(date('Y-m-d', $candidate_ts) . ' ' . $end_time);

            if ($candidate_ts < $day_start) {
                $candidate_ts = $day_start;
            }

            if ($candidate_ts > $day_end) {
                // Move to start of next day
                $candidate_ts = strtotime('tomorrow 00:00:00', $candidate_ts);
                continue;
            }

            // C. Check daily limit
            // @MODIFIED 2026-02-15 - Check daily limit using meta query
            $date_str = date('Y-m-d', $candidate_ts);
            $day_count = $wpdb->get_var($wpdb->prepare("
                SELECT COUNT(*) FROM {$wpdb->posts} p
                INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
                WHERE p.post_date LIKE %s
                AND pm.meta_key = '_dit_ts_scheduled' AND pm.meta_value = '1'
            ", $date_str . '%'));

            if ($day_count >= $posts_per_day) {
                // Move to start of next day
                $candidate_ts = strtotime('tomorrow 00:00:00', $candidate_ts);
                continue;
            }

// If we reached here, the time is valid
			$final_time = date('Y-m-d H:i:s', $candidate_ts);
			
			// @ADDED 2026-05-09 - Log final scheduled time
			if (isset($this->logger)) {
				$this->logger->info("calculate_next_publish_time: Final scheduled time", [
					'scheduled_time' => $final_time,
					'delay_from_now_minutes' => round(($candidate_ts - current_time('timestamp')) / 60, 1)
				]);
			}
			
			return $final_time;
        }

        return date('Y-m-d H:i:s', $candidate_ts);
    }

    /**
     * Expand a URL replacement map to cover common variants (http/https and entity decoding).
     *
     * @since 2.15.16
     * @MODIFIED 2026-02-26 - Fix: rename URL replacements fail when content uses http but attachment URLs are https (or vice versa).
     *
     * @param array<string,string> $map
     * @return array<string,string>
     */
    private function augment_url_map(array $map): array
    {
        $out = [];

        foreach ($map as $old => $new) {
            if (!is_string($old) || $old === '' || !is_string($new) || $new === '') {
                continue;
            }

            $out[$old] = $new;

            $old_dec = html_entity_decode($old, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            if ($old_dec !== $old) {
                $out[$old_dec] = $new;
            }

            // Scheme swap: content often has http while WP returns https URLs (or vice versa).
            if (strpos($old, 'http://') === 0) {
                $out['https://' . substr($old, 7)] = $new;
            } elseif (strpos($old, 'https://') === 0) {
                $out['http://' . substr($old, 8)] = $new;
            }

            if (strpos($old_dec, 'http://') === 0) {
                $out['https://' . substr($old_dec, 7)] = $new;
            } elseif (strpos($old_dec, 'https://') === 0) {
                $out['http://' . substr($old_dec, 8)] = $new;
            }
        }

        return $out;
    }

    /**
     * @MODIFIED 2026-03-07 - Generate 4:5 Social Collage & Publish Post
     * 
     * Handled via ActionScheduler from the Social Queue Dashboard.
     * Takes approved Urdu text and selected images, builds collage,
     * updates meta, and publishes the draft.
     * 
     * @param array|int $args Action Scheduler payload or Meta ID
     */
    public function process_social_collage_job($args)
    {
        if (!get_option('dit_ts_enable_social_collage', false)) {
            return;
        }

        // @MODIFIED 2026-04-20 - Support both meta_id and post_id payloads
        $post_id = 0;
        $meta_id = 0;

        if (is_array($args)) {
            $post_id = (int)($args['post_id'] ?? 0);
            $meta_id = (int)($args['meta_id'] ?? 0);
        } else {
            $meta_id = (int)$args;
        }

        // If post_id given directly, use Social_Bootstrap which has full image resolution
        if ($post_id > 0 && $meta_id === 0) {
            if (!class_exists('\\DIT\\TrendStudio\\Core\\Social_Bootstrap')) {
                require_once DIT_TS_PLUGIN_DIR . 'src/Core/Social_Bootstrap.php';
            }
            $logger = new \DIT\TrendStudio\Infrastructure\Logger();
            $generator = new \DIT\TrendStudio\Services\Collage_Generator($logger);
            $queue = new \DIT\TrendStudio\Services\Social_Queue_Manager($generator, $logger);
            $sb = new \DIT\TrendStudio\Core\Social_Bootstrap($logger, $generator, $queue);
            $result = $sb->maybe_generate_social_collage($post_id);
            if ($result) {
                if (get_option('dit_ts_jetpack_enabled', false)) {
                    $sb->sync_to_jetpack($post_id);
                }
                if (isset($this->logger)) {
                    $this->logger->info("Deferred social collage #{$result} generated for post #{$post_id}");
                }
            } else {
                if (isset($this->logger)) {
                    $this->logger->warning("Deferred social collage generation failed for post #{$post_id}");
                }
            }
            return;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'dit_ts_social_meta';

        $social_meta = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE id = %d", $meta_id), ARRAY_A);

        if (!$social_meta) {
            if (isset($this->logger)) {
                $this->logger->error("Social Collage Job: Meta ID {$meta_id} not found.");
            }
            return;
        }

        $post_id = (int)$social_meta['post_id'];
        $post = get_post($post_id);

        if (!$post) {
            $wpdb->update($table, ['status' => 'failed'], ['id' => $meta_id]);
            return;
        }

        // @MODIFIED 2026-05-09 - SSOT: post_meta is PRIMARY source for Urdu assets.
        // Database table (dit_ts_social_meta) is SECONDARY fallback.
        // This matches Social_Bootstrap::maybe_generate_social_collage (lines 223-245).
        // Rationale: post_meta is written during wp_insert_post (meta_input), always available.
        $urdu_head = (string) \get_post_meta($post_id, '_dit_ts_urdu_heading', true);
        $urdu_desc = (string) \get_post_meta($post_id, '_dit_ts_urdu_description', true);
        // Fallback to database table if post_meta is empty
        if (empty($urdu_head) || empty($urdu_desc)) {
            $urdu_head = $urdu_head ?: (string) $social_meta['urdu_heading'];
            $urdu_desc = $urdu_desc ?: (string) $social_meta['urdu_description'];
        }
        if (empty($urdu_head) || empty($urdu_desc)) {
            $stale_id = (int) \get_post_meta($post_id, '_dit_ts_social_collage_id', true);
            if ($stale_id > 0) {
                $parent = (int) \get_post_field('post_parent', $stale_id);
                if ($parent === 0 || $parent === $post_id) {
                    \wp_delete_attachment($stale_id, true);
                }
            }
            \delete_post_meta($post_id, '_dit_ts_social_collage_id');
            \delete_post_meta($post_id, '_dit_ts_social_image_url');
            $thumb_id = (int) \get_post_thumbnail_id($post_id);
            if ($thumb_id) {
                $thumb_url = \wp_get_attachment_url($thumb_id);
                \update_post_meta($post_id, '_wpas_media_src', $thumb_url);
                \DIT\TrendStudio\Core\Social_Bootstrap::update_jetpack_social_options($post_id, $thumb_id, $thumb_url, 'featured-image');
            } else {
                \delete_post_meta($post_id, '_wpas_media_src');
                \delete_post_meta($post_id, '_wpas_options');
            }
            \delete_post_meta($post_id, '_wpas_mess');
            $wpdb->update($table, ['status' => 'failed'], ['id' => $meta_id]);
            if (isset($this->logger)) {
                $this->logger->warning("Social Collage Job: Aborted for post #{$post_id} — Urdu assets missing. Featured image set as share fallback.");
            }
            return;
        }

        try {
            $image_ids = json_decode($social_meta['selected_image_ids'], true);
            if (!is_array($image_ids) || empty($image_ids)) {
                throw new \Exception("No selected images found for collage generation.");
            }

            $image_urls = [];
            foreach ($image_ids as $img_id) {
                $img_id = (int) $img_id;
                if ($img_id <= 0) {
                    continue;
                }
                $url = wp_get_attachment_url($img_id);
                if ($url) {
                    $image_urls[] = $url;
                }
            }

            if (empty($image_urls)) {
                throw new \Exception("Failed to retrieve valid image URLs from media library.");
            }

$brand_text = get_option('dit_ts_brand_bar_text', get_bloginfo('name'));
$brand_color = get_option('dit_ts_brand_bar_color', '#1a1a2e');
$font_name = get_option('dit_ts_social_font', 'NotoNastaliqUrdu-Regular.ttf');
$font_path = DIT_TS_PLUGIN_DIR . 'assets/fonts/' . basename($font_name);

// @MODIFIED 2026-04-21 - Ensure font fallback and log errors (sync with Social_Bootstrap)
$final_font_path = $font_path;
if (!file_exists($font_path)) {
        $fallbacks = [
            'NotoNastaliqUrdu-Regular.ttf',
            'NotoNastaliqUrdu-Medium.ttf',
            'NotoSansArabic-Regular.ttf',
        ];
    foreach ($fallbacks as $fb) {
        $fb_path = DIT_TS_PLUGIN_DIR . 'assets/fonts/' . $fb;
        if (file_exists($fb_path)) {
            $final_font_path = $fb_path;
            break;
        }
    }
    if (isset($this->logger)) {
        $this->logger->error("Scheduler collage: Font '$font_name' not found at '$font_path'. Using fallback: '$final_font_path'");
    }
}

$vertical = get_post_meta($post_id, 'vertical', true) ?: 'general';
            $is_fashion = ($vertical === 'fashion');
            $limit      = $is_fashion ? 3 : 2;
            $layout     = $is_fashion ? '3-cols' : '2-cols';

            $image_urls = array_values(array_slice($image_urls, 0, $limit));

            $_hashtags_src = !empty($social_meta['hashtags']) ? $social_meta['hashtags'] : get_post_meta($post_id, '_dit_ts_hashtags', true);
            $hashtags_raw = is_array($_hashtags_src) ? implode(' ', $_hashtags_src) : (string) $_hashtags_src;
            $parsed       = \DIT\TrendStudio\Services\Social_Queue_Manager::split_desc_and_hashtags(
                (string) $social_meta['urdu_description'],
                (string) $hashtags_raw
            );
            $clean_desc   = $parsed['desc'];

            if (!class_exists('\\DIT\\TrendStudio\\Services\\Collage_Generator')) {
                require_once DIT_TS_PLUGIN_DIR . 'src/Services/Collage_Generator.php';
            }

            $generator = new \DIT\TrendStudio\Services\Collage_Generator($this->logger);

        $options = [
            'aspect_ratio' => '4:5',
            'layout' => $layout,
            'target_count' => $limit,
            'social_bands' => [
                'heading' => (string) $social_meta['urdu_heading'],
                'description' => (string) $clean_desc,
            ],
            'bottom_text' => $brand_text,
            'border_color' => $brand_color,
            'font_file' => $final_font_path,
		'heading_font_size' => (int) get_option('dit_ts_social_h_size', 36),
		'desc_font_size' => (int) get_option('dit_ts_social_d_size', 26),
		'image_area_pct' => (int) get_option('dit_ts_social_image_pct', 50),
		'heading_area_pct' => (int) get_option('dit_ts_social_heading_pct', 20),
		'desc_area_pct' => (int) get_option('dit_ts_social_desc_pct', 20),
		'bar_area_pct' => (int) get_option('dit_ts_social_bar_pct', 10),
		'corner_radius' => (int) get_option('dit_ts_social_radius', 0),
		// @MODIFIED 2026-05-04 - Top-biased crop (y=25) preserves faces in portrait images
		'crops' => [['x' => 50, 'y' => 25, 'scale' => 1.0, 'full_crop' => true]],
            'logo_path' => '',
            'use_brand_logo' => true,
            'is_retina' => true,
            'format' => 'jpg',
            'social_font' => basename($final_font_path),
            'social_heading_bg' => (string) get_option('dit_ts_social_heading_bg', '#0f1c34'),
            'social_heading_color' => (string) get_option('dit_ts_social_heading_color', '#ffffff'),
            'social_desc_bg' => (string) get_option('dit_ts_social_desc_bg', '#500f19'),
            'social_desc_color' => (string) get_option('dit_ts_social_desc_color', '#ffffff'),
        ];

            $attach_id = $generator->create_collage(
                array_values(array_filter($image_urls)),
                $post->post_title . ' - Social Grid',
                $options
            );

            if (is_wp_error($attach_id)) {
                throw new \Exception($attach_id->get_error_message());
            }

        $old_collage_id = (int) get_post_meta($post_id, '_dit_ts_social_collage_id', true);
        if ($old_collage_id && $old_collage_id !== $attach_id) {
            wp_delete_attachment($old_collage_id, true);
        }

        // @MODIFIED 2026-04-21 - Social collage should NOT be attached to post as featured image
        // The social collage is only for social sharing, not for the post itself
        // Removed: wp_update_post(['ID' => $attach_id, 'post_parent' => $post_id]);
        $image_url = wp_get_attachment_url($attach_id);

        update_post_meta($post_id, '_dit_ts_social_collage_id', $attach_id);
        update_post_meta($post_id, '_wpas_media_src', $image_url);
        update_post_meta($post_id, '_dit_ts_social_image_url', $image_url);
        \DIT\TrendStudio\Core\Social_Bootstrap::update_jetpack_social_options($post_id, (int) $attach_id, $image_url);
        update_post_meta($post_id, '_dit_ts_urdu_heading', wp_strip_all_tags(html_entity_decode((string) $social_meta['urdu_heading'], ENT_QUOTES | ENT_HTML5, 'UTF-8')));
        update_post_meta($post_id, '_dit_ts_urdu_description', wp_strip_all_tags(html_entity_decode((string) $social_meta['urdu_description'], ENT_QUOTES | ENT_HTML5, 'UTF-8')));
            if (!empty($social_meta['hashtags'])) {
                update_post_meta($post_id, '_dit_ts_hashtags', is_array($social_meta['hashtags']) ? implode(' ', $social_meta['hashtags']) : $social_meta['hashtags']);
            }

            $wpdb->update($table, ['image_path' => $image_url, 'status' => 'published'], ['id' => $meta_id]);

            if (isset($this->logger)) {
                $this->logger->info("Social Collage Job: Generated 4:5 collage #{$attach_id} and updated post #{$post_id} meta.");
            }
        } catch (\Exception $e) {
            // @MODIFIED 2026-05-07 - On collage generation failure, fall back to featured image
            // for _wpas_media_src so Jetpack still has a valid share image.
            $thumb_id = (int) \get_post_thumbnail_id($post_id);
            if ($thumb_id) {
                $thumb_url = \wp_get_attachment_url($thumb_id);
                \update_post_meta($post_id, '_wpas_media_src', $thumb_url);
                \DIT\TrendStudio\Core\Social_Bootstrap::update_jetpack_social_options($post_id, $thumb_id, $thumb_url, 'featured-image');
            }
            $wpdb->update($table, ['status' => 'failed'], ['id' => $meta_id]);
            if (isset($this->logger)) {
                $this->logger->error("Social Collage Job Failed for Post {$post_id}: " . $e->getMessage());
            }
        }
	}

    private function load_fallback_config(): array
    {
        $fallback_config = \get_option('dit_ts_custom_fallback_config', []);
        if (\is_array($fallback_config) && (!empty($fallback_config['enable_cross_provider_fallback']) || !empty($fallback_config['enable_universal_fallback']))) {
            return $fallback_config;
        }

        $providers_raw = \get_option('dit_ts_custom_providers', []);
        if (\is_string($providers_raw)) {
            $providers_raw = \json_decode($providers_raw, true);
        }
        if (\is_array($providers_raw) && !empty($providers_raw['_fallback_config'])) {
            return (array) $providers_raw['_fallback_config'];
        }

        return [
            'enable_model_fallback' => true,
            'enable_cross_provider_fallback' => false,
            'enable_universal_fallback' => false,
            'cross_provider_order' => [],
        ];
    }

    /**
     * Build ordered fallback chain for Universal or Cross-Provider fallback.
     *
     * @param string $primary_strategy The strategy that already failed.
     * @param array  $input_data       Job input data (contains custom_provider_id).
     * @param array  $fallback_config  The fallback config from dit_ts_custom_fallback_config.
     * @param bool   $universal        When true, append built-in providers after custom ones.
     * @return array<int, array{strategy: string, provider_id: string}>
     */
    private function build_fallback_chain(string $primary_strategy, array $input_data, array $fallback_config, bool $universal): array
    {
        $primary_provider_id = ($primary_strategy === 'custom')
            ? ($input_data['custom_provider_id'] ?? '')
            : $primary_strategy;

        // Merge the $universal flag into a synthetic config dict so the shared builder
        // can use its standard enable_universal_fallback gate.
        if ($universal && empty($fallback_config['enable_universal_fallback'])) {
            $fallback_config['enable_universal_fallback'] = true;
        }

        return \DIT\TrendStudio\Infrastructure\AI_Provider_Factory::build_fallback_chain(
            $primary_strategy,
            $primary_provider_id,
            $fallback_config,
            true // skip_gate: caller already verified fallback eligibility
        );
    }

    /**
     * Resolve the first available (non-paused) fallback provider when the primary is paused.
     *
     * @param string $primary_strategy  The paused provider's strategy (e.g. 'gemini').
     * @param array  $input_data        Job input data (contains custom_provider_id).
     * @return array|null  ['strategy' => ..., 'provider_id' => ..., 'label' => ...] or null if none available.
     */
    public static function resolve_first_available_fallback(string $primary_strategy, array $input_data = []): ?array
    {
        if (!class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Pause_Manager')) {
            return null;
        }

        $fallback_config = \get_option('dit_ts_custom_fallback_config', []);
        if (!\is_array($fallback_config)) {
            $fallback_config = [];
        }

        $can_fallback = !empty($fallback_config['enable_cross_provider_fallback'])
                     || !empty($fallback_config['enable_universal_fallback']);

        if (!$can_fallback) {
            return null;
        }

        $primary_provider_id = ($primary_strategy === 'custom')
            ? ($input_data['custom_provider_id'] ?? '')
            : $primary_strategy;

        $chain = \DIT\TrendStudio\Infrastructure\AI_Provider_Factory::build_fallback_chain(
            $primary_strategy,
            $primary_provider_id,
            $fallback_config,
            true // skip_gate: we already verified can_fallback above
        );

        foreach ($chain as $entry) {
            $pause_slug = ($entry['strategy'] === 'custom') ? $entry['provider_id'] : $entry['strategy'];
            if (!\DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::is_paused($pause_slug)) {
                $entry['label'] = ($entry['strategy'] === 'custom') ? $entry['provider_id'] : $entry['strategy'];
                return $entry;
            }
        }

        return null;
    }
}
