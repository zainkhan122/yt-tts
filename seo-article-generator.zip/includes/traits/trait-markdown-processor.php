<?php

/**
 * Markdown Processor Trait
 *
 * Provides methods for processing markdown and cleaning up AI-generated content.
 *
 * @package SEO_Article_Generator
 */

namespace SEO_Article_Generator\Traits;

trait Markdown_Processor
{
    /**
     * Process content: remove citations and convert basic markdown to HTML.
     *
     * @param string $text The text to process.
     * @return string Processed HTML-ready string.
     */
    protected static function process_markdown($text)
    {
        if (!is_string($text)) {
            return '';
        }

        // 1. Remove citations like [cite: 1, 7, 8 from 1st search]
        // Matches [cite: ...] case insensitive
        $text = preg_replace('/\[cite:[^\]]+\]/i', '', $text);

        // 2. Convert **bold** to <strong>bold</strong>
        // Non-greedy match for content between asterisks
        $text = preg_replace('/\*\*(.*?)\*\*/', '<strong>$1</strong>', $text);

        // 2.5 Convert *italic* to <em>italic</em>
        $text = preg_replace('/(?<!\*)\*(?![*\s])(.+?)(?<!\s)\*(?!\*)/', '<em>$1</em>', $text);

        // 3. Convert `text` to <strong>text</strong> (bold, not code per user preference)
        // @MODIFIED 2026-01-08: User requested backticks as bold emphasis
        $text = preg_replace('/`([^`]+)`/', '<strong>$1</strong>', $text);

        // 4. Convert 'text' to <strong>text</strong> (User requested "professional" formatting)
        // Guard against contractions (it's, don't) by ensuring quotes are surrounded by boundaries
        // Lookbehind: Start of line, whitespace, or open bracket
        // Lookahead: End of line, whitespace, or punctuation
        $text = preg_replace("/(?<=^|\s|[(\\[])'([^']+)'(?=$|\s|[.,:;!?\\])])/", '<strong>$1</strong>', $text);

        // 5. Trim extra whitespace that might be left after removal
        return trim($text);
    }
}
