/**
 * MCQVS Render Plan Validator
 * Hard-fails on invalid plan to prevent "half renders" and parity drift.
 *
 * @package MCQ_Video_Studio
 * @since 9.0.0
 */
(function (window) {
  "use strict";

  const MCQVS_RenderPlanValidator = {
    assertValid(plan) {
      if (!plan || typeof plan !== "object") throw new Error("RenderPlan missing");
      if (!Number.isFinite(plan.fps) || plan.fps <= 0) throw new Error("RenderPlan.fps invalid");
      if (!Array.isArray(plan.scenes) || plan.scenes.length === 0) throw new Error("RenderPlan.scenes empty");
      if (!Number.isFinite(plan.totalMs) || plan.totalMs <= 0) throw new Error("RenderPlan.totalMs invalid");

      let lastEnd = 0;
      for (const s of plan.scenes) {
        if (!s.id) throw new Error("RenderPlan.scene.id missing");
        if (!Number.isFinite(s.startMs) || s.startMs < 0) throw new Error("RenderPlan.scene.startMs invalid");
        if (!Number.isFinite(s.durMs) || s.durMs < 0) throw new Error("RenderPlan.scene.durMs invalid");
        if (!Number.isFinite(s.endMs) || s.endMs < s.startMs) throw new Error("RenderPlan.scene.endMs invalid");
        if (s.startMs < lastEnd - 0.01) throw new Error("RenderPlan scenes overlap/out of order");
        lastEnd = s.endMs;
      }
      if (Math.abs(lastEnd - plan.totalMs) > 0.5) throw new Error("RenderPlan.totalMs mismatch");

      // Phase 4: optional fields validation
      if (plan.requiredSfx != null) {
        if (!Array.isArray(plan.requiredSfx)) throw new Error("RenderPlan.requiredSfx must be an array");
        const bad = plan.requiredSfx.filter((x) => typeof x !== "string" || !x.trim());
        if (bad.length) throw new Error("RenderPlan.requiredSfx contains invalid entries");
      }
      if (plan.fxEvents != null) {
        if (!Array.isArray(plan.fxEvents)) throw new Error("RenderPlan.fxEvents must be an array");
      }
      if (plan.sfxEvents != null) {
        if (!Array.isArray(plan.sfxEvents)) throw new Error("RenderPlan.sfxEvents must be an array");
      }

      return true;
    },

    validate(plan) {
      try {
        this.assertValid(plan);
        return { ok: true, issues: [] };
      } catch (e) {
        return { ok: false, issues: [e.message] };
      }
    },
  };

  window.MCQVS_RenderPlanValidator = MCQVS_RenderPlanValidator;
})(window);
