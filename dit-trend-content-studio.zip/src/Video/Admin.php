<?php
/**
 * DIT Video Module — Admin
 *
 * A "Video" submenu under Trend Studio: master toggle, settings (incl. the
 * required cleanup + diagnostics settings), a diagnostics table, "Generate for
 * all" and per-post generate, and manual cleanup. Self-contained; no edits to
 * DIT's settings page.
 *
 * @package DIT\TrendStudio\Video
 */

namespace DIT\TrendStudio\Video;

use DIT\TrendStudio\Infrastructure\Logger;

if (!defined('ABSPATH')) {
    exit;
}

class Admin
{
    /** @var Settings */
    protected $settings;

    /** @var Logger */
    protected $logger;

    /** @var Job_Manager */
    protected $jobs;

    /** @var Cleanup */
    protected $cleanup;

    /** @var Diagnostics */
    protected $diagnostics;

    public function __construct(Settings $settings, Logger $logger, Job_Manager $jobs, Cleanup $cleanup, Diagnostics $diagnostics)
    {
        $this->settings    = $settings;
        $this->logger      = $logger;
        $this->jobs        = $jobs;
        $this->cleanup     = $cleanup;
        $this->diagnostics = $diagnostics;
    }

    public function register_menu(): void
    {
        add_submenu_page(
            'dit-trend-studio',
            __('Video Shorts', 'dit-trend-content-studio'),
            __('Video Shorts', 'dit-trend-content-studio'),
            'edit_posts',
            'dit-ts-video',
            array($this, 'render_page')
        );
    }

    public function enqueue_assets($hook): void
    {
        if (false === strpos((string) $hook, 'dit-ts-video')) {
            return;
        }
        $nonce = wp_create_nonce('dit_video_nonce');
        echo '<style>
            .dit-video-wrap{max-width:1100px;background:#fff;padding:20px;border:1px solid #ccd0d4;margin-top:16px;}
            .dit-video-wrap h1{margin-top:0;}
            .dit-video-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px;margin:18px 0;}
            .dit-video-card{background:#f8f9fa;border:1px solid #e2e4e7;border-radius:6px;padding:14px;}
            .dit-video-card .n{font-size:26px;font-weight:600;}
            .dit-video-table{width:100%;border-collapse:collapse;margin-top:12px;}
            .dit-video-table td,.dit-video-table th{border:1px solid #e2e4e7;padding:7px 9px;text-align:left;}
            .ok{color:#00a32a;font-weight:600;} .bad{color:#d63638;font-weight:600;}
            .dit-video-section{margin:18px 0;padding:16px;border:1px solid #e2e4e7;border-radius:6px;}
        </style>';
        echo '<script>window.DIT_VIDEO_NONCE=' . wp_json_encode($nonce) . ';</script>';
    }

    public function render_page(): void
    {
        if (!current_user_can('edit_posts')) {
            return;
        }
        $settings  = $this->settings;
        $enabled   = $settings->get_bool('enabled', false);
        $runner    = $settings->runner_dir();
        $count     = $this->count_videos();
        $today     = $this->count_videos_today();
        $queued    = $this->count_queued();
        ?>
        <div class="wrap dit-video-wrap">
            <h1><?php _e('DIT Video Shorts', 'dit-trend-content-studio'); ?></h1>
            <p class="description"><?php _e('Optional module: turns DIT-generated posts into 60s Urdu-voiced Shorts. If disabled or missing a dependency, DIT is unaffected.', 'dit-trend-content-studio'); ?></p>

            <div class="dit-video-cards">
                <div class="dit-video-card"><div class="n"><?php echo esc_html($count); ?></div><div>Videos generated</div></div>
                <div class="dit-video-card"><div class="n"><?php echo esc_html($today); ?></div><div>Generated today</div></div>
                <div class="dit-video-card"><div class="n"><?php echo esc_html($queued); ?></div><div>Queued</div></div>
            </div>

            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="dit-video-section">
                <?php wp_nonce_field('dit_video_settings', 'dit_video_nonce'); ?>
                <h2><?php _e('Settings', 'dit-trend-content-studio'); ?></h2>
                <table class="form-table">
                    <tr><th><?php _e('Enable video module', 'dit-trend-content-studio'); ?></th>
                        <td><label><input type="checkbox" name="video_enabled" value="1" <?php checked($enabled); ?>> <?php _e('Turn on (off = fully inactive, no effect)', 'dit-trend-content-studio'); ?></label></td></tr>
                    <tr><th><?php _e('Auto-generate on publish', 'dit-trend-content-studio'); ?></th>
                        <td><label><input type="checkbox" name="video_auto" value="1" <?php checked($settings->get_bool('auto_generate', false)); ?>> <?php _e('Queue a video when a DIT post is published', 'dit-trend-content-studio'); ?></label></td></tr>
                    <tr><th><?php _e('TTS backend', 'dit-trend-content-studio'); ?></th>
                        <td><select name="video_tts_backend">
                            <option value="edge" <?php selected($settings->get('tts_backend'), 'edge'); ?>>Edge-TTS (Urdu ur-PK, female) — recommended</option>
                            <option value="kokoro" <?php selected($settings->get('tts_backend'), 'kokoro'); ?>>Kokoro (self-hosted — NO Urdu, English/Hindi only)</option>
                            <option value="none" <?php selected($settings->get('tts_backend'), 'none'); ?>>None (silent video)</option>
                        </select>
                        <p class="description"><?php _e('Kokoro does NOT support Urdu script/voice. Use Edge-TTS ur-PK for real Urdu. Kokoro voice: af_heart (female, English) or hf_alpha (Hindi female).', 'dit-trend-content-studio'); ?></p></td></tr>
                    <tr><th><?php _e('TTS voice', 'dit-trend-content-studio'); ?></th>
                        <td><input type="text" name="video_tts_voice" value="<?php echo esc_attr($settings->get('tts_voice')); ?>" class="regular-text"></td></tr>
                    <tr><th><?php _e('TTS speed', 'dit-trend-content-studio'); ?></th>
                        <td><input type="text" name="video_tts_speed" value="<?php echo esc_attr($settings->get('tts_speed')); ?>" class="small-text"> (1.0 normal, 1.15 energetic)</td></tr>
                    <tr><th><?php _e('Max duration (s)', 'dit-trend-content-studio'); ?></th>
                        <td><input type="number" name="video_max_duration" value="<?php echo esc_attr($settings->get_int('max_duration', 60)); ?>" class="small-text"></td></tr>
                    <tr><th><?php _e('Heading font size (px)', 'dit-trend-content-studio'); ?></th>
                        <td><input type="number" name="video_heading_font_size" value="<?php echo esc_attr($settings->get_int('heading_font_size', 64)); ?>" class="small-text">
                        <p class="description"><?php _e('Separate from the Social Collage heading font — video heading is tuned independently.', 'dit-trend-content-studio'); ?></p></td></tr>
                    <tr><th><?php _e('Fit images without cropping', 'dit-trend-content-studio'); ?></th>
                        <td><label><input type="checkbox" name="video_black_bars" value="1" <?php checked($settings->get_bool('use_black_bars', true)); ?>> <?php _e('Letterbox (black bars) instead of cropping landscape/portrait images', 'dit-trend-content-studio'); ?></label></td></tr>
                    <tr><th><?php _e('Runner dir', 'dit-trend-content-studio'); ?></th>
                        <td><input type="text" name="video_runner_dir" value="<?php echo esc_attr($settings->get('runner_dir')); ?>" class="regular-text" placeholder="<?php echo esc_attr($runner); ?>"></td></tr>
                </table>
                <h3><?php _e('YouTube link-back (to embed the shared Short)', 'dit-trend-content-studio'); ?></h3>
                <table class="form-table">
                    <tr><th><?php _e('YouTube Data API key', 'dit-trend-content-studio'); ?></th>
                        <td><input type="text" name="video_yt_api_key" value="<?php echo esc_attr($settings->get('yt_api_key')); ?>" class="regular-text">
                            <p class="description"><?php _e('Used to find the uploaded Short on your channel by its generated title. Falls back to DIT\'s Google key if present.', 'dit-trend-content-studio'); ?></p></td></tr>
                    <tr><th><?php _e('YouTube Channel ID', 'dit-trend-content-studio'); ?></th>
                        <td><input type="text" name="video_yt_channel_id" value="<?php echo esc_attr($settings->get('yt_channel_id')); ?>" class="regular-text">
                            <p class="description"><?php _e('e.g. UCxxxxxxxxxxxxxxxxxxxx. Search is scoped to this channel.', 'dit-trend-content-studio'); ?></p></td></tr>
                    <tr><th><?php _e('Embed YT block after 2nd paragraph', 'dit-trend-content-studio'); ?></th>
                        <td><label><input type="checkbox" name="video_embed_after" value="1" <?php checked($settings->get_bool('embed_after_2nd_para', true)); ?>> <?php _e('Insert a native YouTube Gutenberg block after the 2nd paragraph on publish', 'dit-trend-content-studio'); ?></label></td></tr>
                    <tr><th><?php _e('Detach local video after YT embed', 'dit-trend-content-studio'); ?></th>
                        <td><label><input type="checkbox" name="video_detach_after" value="1" <?php checked($settings->get_bool('detach_local_after_yt', true)); ?> disabled> <?php _e('Always on — the local video is deleted once the YT link is embedded (frees server space)', 'dit-trend-content-studio'); ?></label></td></tr>
                    <tr><th><?php _e('Share video to all connected SMNs', 'dit-trend-content-studio'); ?></th>
                        <td><label><input type="checkbox" name="video_share_all_smn" value="1" <?php checked($settings->get_bool('share_video_all_smn', true)); ?>> <?php _e('Also share the video to other enabled Buffer channels (Instagram/Facebook/TikTok), not just YouTube', 'dit-trend-content-studio'); ?></label></td></tr>
                </table>
                <p><button type="submit" class="button button-primary"><?php _e('Save Settings', 'dit-trend-content-studio'); ?></button>
                   <button type="submit" name="run_diagnostics" value="1" class="button"><?php _e('Run Diagnostics', 'dit-trend-content-studio'); ?></button></p>
            </form>

            <div class="dit-video-section">
                <h2><?php _e('Pipeline Diagnostics', 'dit-trend-content-studio'); ?></h2>
                <?php $this->render_diagnostics_table(); ?>
                <p><button class="button" id="dit-video-refresh-diag"><?php _e('Re-check', 'dit-trend-content-studio'); ?></button></p>
            </div>

            <div class="dit-video-section">
                <h2><?php _e('Actions', 'dit-trend-content-studio'); ?></h2>
                <p>
                    <button class="button button-primary" id="dit-video-generate-all"><?php _e('Generate videos for all qualified posts', 'dit-trend-content-studio'); ?></button>
                    <button class="button" id="dit-video-generate-latest"><?php _e('Generate for latest qualified post', 'dit-trend-content-studio'); ?></button>
                    <button class="button button-link-delete" id="dit-video-cleanup"><?php _e('Clean all video temp + attachments', 'dit-trend-content-studio'); ?></button>
                </p>
                <div id="dit-video-actions-out" class="description"></div>
                <h3><?php _e('Per-post generate', 'dit-trend-content-studio'); ?></h3>
                <p><input type="number" id="dit-video-post-id" placeholder="Post ID" style="width:110px">
                   <button class="button" id="dit-video-generate-one"><?php _e('Generate video for post', 'dit-trend-content-studio'); ?></button></p>
            </div>
        </div>
        <script>
        jQuery(function($){
            function act(url, btn, label){
                btn.prop('disabled',true); var old=btn.text(); btn.text(label||'Working...');
                $.post(url, {nonce: window.DIT_VIDEO_NONCE}, function(r){
                    btn.prop('disabled',false); btn.text(old);
                    $('#dit-video-actions-out').text(r.message || (r.ok?'Done':'Error'));
                }).fail(function(){ btn.prop('disabled',false); btn.text(old); $('#dit-video-actions-out').text('Request failed'); });
            }
            var aj = window.ajaxurl || '/wp-admin/admin-ajax.php';
            $('#dit-video-generate-all').on('click',function(){ act(aj+'?action=dit_video_generate&all=1', $(this)); });
            $('#dit-video-generate-latest').on('click',function(){ act(aj+'?action=dit_video_generate&latest=1', $(this)); });
            $('#dit-video-generate-one').on('click',function(){ var id=$('#dit-video-post-id').val(); if(!id)return; act(aj+'?action=dit_video_generate&post_id='+id, $(this)); });
            $('#dit-video-cleanup').on('click',function(){ if(!confirm('Delete ALL video temp data + attachments?'))return; act(aj+'?action=dit_video_cleanup', $(this)); });
            $('#dit-video-refresh-diag').on('click',function(){
                $.get(aj+'?action=dit_video_diagnostics', function(r){ location.reload(); });
            });
        });
        </script>
        <?php
    }

    protected function render_diagnostics_table(): void
    {
        $checks = $this->diagnostics->persist();
        echo '<table class="widefat dit-video-table"><thead><tr><th>Check</th><th>Value</th><th>Status</th></tr></thead><tbody>';
        foreach ($checks as $c) {
            printf(
                '<tr><td>%s</td><td>%s</td><td class="%s">%s</td></tr>',
                esc_html($c['label']),
                esc_html($c['value']),
                $c['ok'] ? 'ok' : 'bad',
                $c['ok'] ? 'OK' : 'MISSING'
            );
        }
        echo '</tbody></table>';
    }

    /**
     * Handle the settings form submit (admin-post).
     * Registered in Module? No — we hook admin_init here for the POST.
     */
    public function handle_settings_post(): void
    {
        if (empty($_POST['dit_video_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['dit_video_nonce'])), 'dit_video_settings')) {
            return;
        }
        $this->settings->set('enabled', !empty($_POST['video_enabled']) ? '1' : '0');
        $this->settings->set('auto_generate', !empty($_POST['video_auto']) ? '1' : '0');
        $this->settings->set('tts_backend', sanitize_text_field(wp_unslash($_POST['video_tts_backend'] ?? 'edge')));
        $this->settings->set('tts_voice', sanitize_text_field(wp_unslash($_POST['video_tts_voice'] ?? 'ur-PK-UzmaNeural')));
        $this->settings->set('tts_speed', sanitize_text_field(wp_unslash($_POST['video_tts_speed'] ?? '1.15')));
        $this->settings->set('max_duration', absint($_POST['video_max_duration'] ?? 60));
        $this->settings->set('heading_font_size', absint($_POST['video_heading_font_size'] ?? 64));
        $this->settings->set('use_black_bars', !empty($_POST['video_black_bars']) ? '1' : '0');
        $this->settings->set('runner_dir', sanitize_text_field(wp_unslash($_POST['video_runner_dir'] ?? '')));
        $this->settings->set('yt_api_key', sanitize_text_field(wp_unslash($_POST['video_yt_api_key'] ?? '')));
        $this->settings->set('yt_channel_id', sanitize_text_field(wp_unslash($_POST['video_yt_channel_id'] ?? '')));
        $this->settings->set('embed_after_2nd_para', !empty($_POST['video_embed_after']) ? '1' : '0');
        $this->settings->set('detach_local_after_yt', '1'); // always on
        $this->settings->set('share_video_all_smn', !empty($_POST['video_share_all_smn']) ? '1' : '0');
        $this->logger->info('DIT Video: settings saved.');
        wp_safe_redirect(add_query_arg('page', 'dit-ts-video', admin_url('admin.php')));
        exit;
    }

    public function ajax_generate(): void
    {
        check_ajax_referer('dit_video_nonce', 'nonce');
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(array('message' => 'Forbidden'));
        }
        if (isset($_GET['all'])) {
            $res = $this->jobs->queue_all_qualified(30);
            wp_send_json_success(array('message' => 'Queued ' . $res['queued'] . ' of ' . $res['scanned'] . ' scanned posts.'));
        }
        $post_id = isset($_GET['post_id']) ? (int) $_GET['post_id'] : (isset($_GET['latest']) ? $this->latest_qualified() : 0);
        if (!$post_id) {
            wp_send_json_error(array('message' => 'No qualified post found.'));
        }
        $res = $this->generator->generate_for_post($post_id);
        wp_send_json(array('ok' => (bool) ($res['ok'] ?? false), 'message' => implode(' | ', $res['log'] ?? array())));
    }

    public function ajax_diagnostics(): void
    {
        check_ajax_referer('dit_video_nonce', 'nonce');
        $this->diagnostics->persist();
        wp_send_json_success(array('message' => 'Diagnostics refreshed.'));
    }

    public function ajax_cleanup(): void
    {
        check_ajax_referer('dit_video_nonce', 'nonce');
        if (!current_user_can('edit_posts')) {
            wp_send_json_error(array('message' => 'Forbidden'));
        }
        $res = $this->cleanup->clean_all();
        wp_send_json_success(array('message' => 'Cleanup done: removed ' . $res['removed'] . ' items.'));
    }

    protected function latest_qualified(): int
    {
        $posts = get_posts(array(
            'post_type' => 'post', 'post_status' => array('publish', 'future', 'draft'),
            'posts_per_page' => 1, 'orderby' => 'date', 'order' => 'DESC',
            'meta_query' => array(array('key' => '_dit_ts_generated', 'value' => '1')),
        ));
        return $posts ? (int) $posts[0]->ID : 0;
    }

    protected function count_videos(): int
    {
        global $wpdb;
        return (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key='_dit_ts_video_ready' AND meta_value='1'");
    }

    protected function count_videos_today(): int
    {
        global $wpdb;
        $since = gmdate('Y-m-d 00:00:00');
        return (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key='_dit_ts_video_generated_at' AND meta_value >= %s", $since));
    }

    protected function count_queued(): int
    {
        global $wpdb;
        return (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key='_dit_ts_video_queued' AND meta_value='1'");
    }
}
