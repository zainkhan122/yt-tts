<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Contracts\AIProviderInterface;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GeminiProvider implements AIProviderInterface {

	private $current_model = '';

	private static $valid_models = [
		'gemini-2.0-flash',
		'gemini-2.5-flash',
		'gemini-2.0-flash-lite',
		'gemini-1.5-flash',
		'gemini-1.5-flash-8b',
		'gemini-2.0-flash-001',
		'gemini-2.5-flash-preview-05-20',
		'gemini-2.5-pro-preview-05-06',
	];

	public function get_provider_name() {
		return Config::PROVIDER_GEMINI;
	}

	public function get_model_name() {
		if ( ! empty( $this->current_model ) ) {
			return $this->current_model;
		}
		$model = get_option( Config::OPTION_GEMINI_MODEL, Config::DEFAULT_GEMINI_MODEL );
		if ( ! empty( $model ) && in_array( $model, self::$valid_models, true ) ) {
			return $model;
		}
		return Config::DEFAULT_GEMINI_MODEL;
	}

 	public function generate_content( $post_content, $system_prompt = '' ) {
 		$api_key = get_option( Config::OPTION_GEMINI_KEY, '' );
 		if ( empty( $api_key ) ) {
 			throw new \Exception( 'Gemini API Key is missing. Configure it in AI Social Collage → Settings.' );
 		}

 		$configured_model = get_option( Config::OPTION_GEMINI_MODEL, Config::DEFAULT_GEMINI_MODEL );
 		$models_to_try = self::$valid_models;
 		if ( in_array( $configured_model, $models_to_try, true ) ) {
 			$models_to_try = array_unique( array_merge( [ $configured_model ], $models_to_try ) );
 		}

 		$last_error = '';
 		$last_http_code = 0;
 		$last_error_tag = '';
 		foreach ( $models_to_try as $model ) {
 			$this->current_model = $model;
 			try {
 				$payload = [
 					'contents' => [
 						[
 							'parts' => [
 								[ 'text' => $system_prompt . "\n\nNews Content:\n" . $post_content ],
 							],
 						],
 					],
 					'generationConfig' => [
 						'response_mime_type' => 'application/json',
 					],
 				];

 				$start_time = microtime( true );
 				$response = wp_remote_post(
 					"https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent",
 					[
 						'body' => wp_json_encode( $payload ),
 						'headers' => [
 							'Content-Type' => 'application/json',
 							'x-goog-api-key' => $api_key,
 						],
 						'timeout' => 30,
 					]
 				);
 				$execution_time = microtime( true ) - $start_time;

 				if ( is_wp_error( $response ) ) {
 					throw new \Exception( 'Gemini API Connection Error: ' . $response->get_error_message() );
 				}

 				$response_code = wp_remote_retrieve_response_code( $response );
 				$body = wp_remote_retrieve_body( $response );

 				Logger::debug( Config::LOG_ACTION_GEMINI_RESPONSE, null, $payload, (string) $response_code, $body, $execution_time );

 				if ( $response_code === 200 ) {
 					return $this->parse_generate_response( $body );
 				}

 				if ( $response_code === 401 || $response_code === 403 ) {
 					$error_info = APIErrorParser::parse( Config::PROVIDER_GEMINI, $response_code, $body );
 					throw new \Exception( 'Gemini API returned HTTP ' . $response_code . ': ' . mb_substr( $body, 0, 500 ) . ', error_type=' . $error_info->error_type, $response_code );
 				}

 				if ( $response_code === 429 ) {
 					$error_info = APIErrorParser::parse( Config::PROVIDER_GEMINI, 429, $body );
 					throw new \Exception( "Gemini API returned HTTP 429: rate limited, error_type={$error_info->error_type}", 429 );
 				}

 				$parsed_error = APIErrorParser::parse( Config::PROVIDER_GEMINI, $response_code, $body );
 				throw new \Exception( 'Gemini API returned HTTP ' . $response_code . ': ' . mb_substr( $body, 0, 500 ) . ', error_type=' . $parsed_error->error_type, $response_code );
 			} catch ( \Throwable $e ) {
 				$last_error     = $e->getMessage();
 				$last_http_code = $e->getCode() !== 0 ? $e->getCode() : $last_http_code;
 				if ( preg_match( '/error_type=([a-z_]+)/', $last_error, $etm ) ) {
 					$last_error_tag = $etm[1];
 				}
 				break;
 			}
 		}

 		$final_msg = 'Gemini: failed on model ' . $this->current_model . '. Last error: ' . $last_error;
 		if ( $last_error_tag !== '' ) {
 			$final_msg .= ', error_type=' . $last_error_tag;
 		}
 		throw new \Exception( $final_msg, $last_http_code );
 	}

	private function parse_generate_response( string $body ): array {
		$data = json_decode( $body, true );

		if ( ! is_array( $data ) ) {
			throw new \Exception( 'Gemini API returned invalid JSON response.' );
		}

		$result_text = '';
		if (
			isset( $data['candidates'][0]['content']['parts'] )
			&& is_array( $data['candidates'][0]['content']['parts'] )
			&& isset( $data['candidates'][0]['content']['parts'][0] )
			&& is_array( $data['candidates'][0]['content']['parts'][0] )
			&& isset( $data['candidates'][0]['content']['parts'][0]['text'] )
			&& is_string( $data['candidates'][0]['content']['parts'][0]['text'] )
		) {
			$result_text = $data['candidates'][0]['content']['parts'][0]['text'];
		}

		if ( empty( $result_text ) ) {
			throw new \Exception( 'Gemini API returned empty or malformed candidate response. Raw: ' . mb_substr( $body, 0, 500 ) );
		}

		// Strip markdown code fences (```json ... ```) some models add without response_format enforcement
		$result_text = preg_replace( '/^```(?:json)?\s*\n?(.*?)\n?```\s*$/s', '$1', $result_text );

		$result = json_decode( $result_text, true );
		if ( $result === null || ! is_array( $result ) ) {
			throw new \Exception( 'Gemini API response content is not valid JSON: ' . mb_substr( $result_text, 0, 200 ) );
		}

		$input_tokens = 0;
		$output_tokens = 0;
		if ( isset( $data['usageMetadata'] ) && is_array( $data['usageMetadata'] ) ) {
			$input_tokens = (int) ( $data['usageMetadata']['promptTokenCount'] ?? 0 );
			$output_tokens = (int) ( $data['usageMetadata']['candidatesTokenCount'] ?? 0 );
		}

		$result['_meta'] = [
			'input_tokens' => $input_tokens,
			'output_tokens' => $output_tokens,
		];

		return $result;
	}

	public function test_connection() {
		$api_key = get_option( Config::OPTION_GEMINI_KEY, '' );
		if ( empty( $api_key ) ) {
			return [ 'success' => false, 'error' => 'Gemini API Key is missing.' ];
		}
		$response = wp_remote_post(
			"https://generativelanguage.googleapis.com/v1beta/models/{$this->get_model_name()}:generateContent",
			[
				'body' => wp_json_encode( [
					'contents' => [ [ 'parts' => [ [ 'text' => 'Ping' ] ] ] ],
					'generationConfig' => [ 'maxOutputTokens' => 5, 'temperature' => 0 ],
				] ),
				'headers' => [
					'Content-Type' => 'application/json',
					'x-goog-api-key' => $api_key,
				],
				'timeout' => 30,
			]
		);
		if ( is_wp_error( $response ) ) {
			return [ 'success' => false, 'error' => $response->get_error_message() ];
		}
		$code = wp_remote_retrieve_response_code( $response );
		if ( $code === 200 ) {
			return [ 'success' => true, 'message' => 'Connection successful.' ];
		}
		return [ 'success' => false, 'error' => "HTTP {$code}" ];
	}

	public function analyze_image( $image_path, $prompt, $example_images = [] ) {
		$api_key = get_option( Config::OPTION_GEMINI_KEY, '' );
		if ( empty( $api_key ) ) {
			throw new \Exception( 'Gemini API Key is missing. Configure it in AI Social Collage → Settings.' );
		}

		if ( ! file_exists( $image_path ) ) {
			throw new \Exception( 'Image file does not exist: ' . $image_path );
		}

		$image_data = file_get_contents( $image_path );
		if ( ! $image_data ) {
			throw new \Exception( 'Failed to read image file: ' . $image_path );
		}

		$parts = [];

		if ( ! empty( $example_images ) && is_array( $example_images ) ) {
			foreach ( $example_images as $example_path ) {
				if ( ! file_exists( $example_path ) ) {
					continue;
				}
				$example_data = file_get_contents( $example_path );
				if ( $example_data ) {
					$parts[] = [
						'inlineData' => [
							'mimeType' => $this->get_image_mime_type( $example_path ),
							'data' => base64_encode( $example_data ),
						],
					];
				}
			}
		}

		$parts[] = [
			'inlineData' => [
				'mimeType' => $this->get_image_mime_type( $image_path ),
				'data' => base64_encode( $image_data ),
			],
		];

		$parts[] = [ 'text' => $prompt ];

		$payload = [
			'contents' => [
				[
					'parts' => $parts,
				],
			],
			'generationConfig' => [
				'response_mime_type' => 'application/json',
			],
		];

		$max_retries = 3;
		for ( $attempt = 1; $attempt <= $max_retries; $attempt++ ) {
			$start_time = microtime( true );
			$response = wp_remote_post(
				"https://generativelanguage.googleapis.com/v1beta/models/{$this->get_model_name()}:generateContent",
				[
					'body' => wp_json_encode( $payload ),
					'headers' => [
						'Content-Type' => 'application/json',
						'x-goog-api-key' => $api_key,
					],
					'timeout' => 60,
				]
			);

			if ( is_wp_error( $response ) ) {
				throw new \Exception( 'Gemini API Connection Error: ' . $response->get_error_message() );
			}

			$response_code = wp_remote_retrieve_response_code( $response );
			$body = wp_remote_retrieve_body( $response );
			$execution_time = microtime( true ) - $start_time;

			$log_payload = $payload;
			if ( isset( $log_payload['contents'][0]['parts'] ) && is_array( $log_payload['contents'][0]['parts'] ) ) {
				foreach ( $log_payload['contents'][0]['parts'] as &$part ) {
					if ( isset( $part['inlineData']['data'] ) ) {
						$part['inlineData']['data'] = '[BASE64_IMAGE_DATA_TRUNCATED]';
					}
				}
				unset( $part );
			}
			Logger::debug( Config::LOG_ACTION_GEMINI_RESPONSE, null, $log_payload, (string) $response_code, $body, $execution_time );

			if ( $response_code === 200 ) {
				return $this->parse_analyze_response( $body );
			}

			$error_info = APIErrorParser::parse( Config::PROVIDER_GEMINI, $response_code, $body );

			if ( ! $error_info->is_retryable || $attempt >= $max_retries ) {
				throw new \Exception( 'Gemini API returned HTTP ' . $response_code . ': ' . mb_substr( $body, 0, 500 ) );
			}

			$retry_after = $error_info->get_retry_after();
			// Embed the original error_type in the exception so AIProviderRegistry's
			// re-parse path (which receives an empty body) can recover the correct
			// classification. Without this, an RPD/quota_rpd 429 gets demoted to
			// TYPE_QUOTA_UNKNOWN because the body is dropped at this throw boundary,
			// which breaks daily-quarantine routing (tested via logs 41690/41692).
			$error_type_tag = 'error_type=' . $error_info->error_type;
			if ( $retry_after > 0 ) {
				Logger::info( 'gemini_image_retry_after', null, [
					'attempt' => $attempt,
					'retry_after' => $retry_after,
					'error_type' => $error_info->error_type,
				] );
				throw new \Exception( "HTTP 429 Gemini rate limited, retry_after={$retry_after}s, {$error_type_tag}", 429 );
			} else {
				$delay = pow( 2, $attempt );
				Logger::info( 'gemini_image_retry_backoff', null, [
					'attempt' => $attempt,
					'delay' => $delay,
					'error_type' => $error_info->error_type,
				] );
				throw new \Exception( "HTTP 429 Gemini rate limited, backoff={$delay}s, {$error_type_tag}", 429 );
			}
		}

		throw new \Exception( 'Gemini API analyze_image failed after ' . $max_retries . ' attempts.' );
	}

	private function parse_analyze_response( string $body ): array {
		$data = json_decode( $body, true );
		if ( ! is_array( $data ) ) {
			throw new \Exception( 'Gemini API returned invalid JSON response.' );
		}

		$result_text = '';
		if (
			isset( $data['candidates'][0]['content']['parts'] )
			&& is_array( $data['candidates'][0]['content']['parts'] )
			&& isset( $data['candidates'][0]['content']['parts'][0] )
			&& is_array( $data['candidates'][0]['content']['parts'][0] )
			&& isset( $data['candidates'][0]['content']['parts'][0]['text'] )
			&& is_string( $data['candidates'][0]['content']['parts'][0]['text'] )
		) {
			$result_text = $data['candidates'][0]['content']['parts'][0]['text'];
		}

		if ( empty( $result_text ) ) {
			throw new \Exception( 'Gemini API returned empty or malformed candidate response. Raw: ' . mb_substr( $body, 0, 500 ) );
		}

		$result = json_decode( $result_text, true );
		if ( $result === null || ! is_array( $result ) ) {
			$result = [];
		}

		$input_tokens = 0;
		$output_tokens = 0;
		if ( isset( $data['usageMetadata'] ) && is_array( $data['usageMetadata'] ) ) {
			$input_tokens = (int) ( $data['usageMetadata']['promptTokenCount'] ?? 0 );
			$output_tokens = (int) ( $data['usageMetadata']['candidatesTokenCount'] ?? 0 );
		}

		$result['_meta'] = [
			'input_tokens' => $input_tokens,
			'output_tokens' => $output_tokens,
		];

		return $result;
	}

	private function get_image_mime_type( $image_path ) {
		$extension = strtolower( pathinfo( $image_path, PATHINFO_EXTENSION ) );
		switch ( $extension ) {
			case 'jpg':
			case 'jpeg':
				return 'image/jpeg';
			case 'png':
				return 'image/png';
			case 'gif':
				return 'image/gif';
			case 'webp':
				return 'image/webp';
			default:
				return 'image/jpeg'; // Default fallback
		}
	}
}
