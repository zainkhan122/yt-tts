<?php

namespace SEO_Article_Generator\Validation;

/**
 * Domain Quality & Trust Policy
 *
 * Single source of truth for domain classification.
 * Replaces ad-hoc regex arrays in Validator, TruthValidator, and ScoringEngine.
 */
class Domain_Policy
{

	// Known safe software portals (managed whitelist)
	private const SAFE_PORTALS = array(
		'softonic.com',
		'filehippo.com',
		'download.cnet.com',
		'download.com',
		'uptodown.com',
		'majorgeeks.com',
		'sourceforge.net',
		'github.com',
		'microsoft.com', // Often acts as a portal for others
		'google.com',    // Google Play / Drive
		'videohelp.com',
	);

	// Trusted CDNs that are safe ONLY if they match the official vendor context
	// (This list is used for "is this a plausible download source?" checks)
	private const TRUSTED_CDNS = array(
		'amazonaws.com',
		'cloudfront.net',
		'akamaihd.net',
		'digitaloceanspaces.com',
		'googleapis.com',
		'windows.net',
		'githubusercontent.com',
		'dropboxstatic.com',
	);

	public const TYPE_OFFICIAL_ROOT      = 'OFFICIAL_ROOT_MATCH';
	public const TYPE_OFFICIAL_SUBDOMAIN = 'OFFICIAL_SUBDOMAIN';
	public const TYPE_SAFE_PORTAL        = 'SAFE_PORTAL';
	public const TYPE_TRUSTED_CDN        = 'TRUSTED_CDN';
	public const TYPE_UNKNOWN            = 'UNKNOWN';

	/**
	 * Classify a download URL relative to the official homepage.
	 *
	 * @param string $download_url The download link to check.
	 * @param string $homepage_url The official homepage to compare against.
	 * @return string One of the TYPE_ constants.
	 */
	public static function classify(string $download_url, string $homepage_url): string
	{ // phpcs:ignore
		$download_host = self::get_host($download_url);
		$homepage_host = self::get_host($homepage_url);

		if (empty($download_host)) {
			return self::TYPE_UNKNOWN;
		}

		// 1. Check for Official Root Match
		// Extract registrable domains (e.g., 'adobe.com' from 'get.adobe.com')
		$download_root = self::get_registrable_domain($download_host);
		$homepage_root = self::get_registrable_domain($homepage_host);

		if ($download_root && $homepage_root && $download_root === $homepage_root) {
			return self::TYPE_OFFICIAL_ROOT;
		}

		// 2. Check for Official Subdomain (e.g. dl.discordapp.net vs discord.com - harder,
		// but if we just check if download host ends with homepage host)
		// NOTE: This is loose. 'site.com' ends with 'mysite.com' is false.
		// 'sub.site.com' ends with 'site.com' is true.
		if ($homepage_host && str_ends_with($download_host, '.' . $homepage_host)) {
			return self::TYPE_OFFICIAL_SUBDOMAIN;
		}

		// 3. Check for Safe Portals
		if (self::is_safe_portal($download_url)) {
			return self::TYPE_SAFE_PORTAL;
		}

		// 4. Check for Trusted CDNs
		if (self::is_trusted_cdn($download_url)) {
			return self::TYPE_TRUSTED_CDN;
		}

		return self::TYPE_UNKNOWN;
	}

	/**
	 * Is this URL from a known safe portal?
	 */
	public static function is_safe_portal(string $url): bool
	{
		$host = self::get_host($url);
		if (! $host) {
			return false;
		}

		foreach (self::SAFE_PORTALS as $portal) {
			if (str_ends_with($host, $portal)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Is this URL from a known CDN?
	 */
	public static function is_trusted_cdn(string $url): bool
	{
		$host = self::get_host($url);
		if (! $host) {
			return false;
		}

		foreach (self::TRUSTED_CDNS as $cdn) {
			if (str_ends_with($host, $cdn)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Is this classified as an OFFICIAL source (Root or Subdomain)?
	 */
	public static function is_official(string $download_url, string $homepage_url): bool
	{
		$type = self::classify($download_url, $homepage_url);
		return in_array($type, array(self::TYPE_OFFICIAL_ROOT, self::TYPE_OFFICIAL_SUBDOMAIN), true);
	}

	/**
	 * Parse host from URL.
	 */
	private static function get_host(string $url): ?string
	{
		$parsed = parse_url($url);
		return isset($parsed['host']) ? strtolower($parsed['host']) : null;
	}

	/**
	 * Extract registrable domain (simplified).
	 * e.g., 'www.google.com' -> 'google.com'
	 * e.g., 'files.awesomesoftware.co.uk' -> 'awesomesoftware.co.uk'
	 *
	 * NOTE: A full public suffix list implementation is heavy.
	 * We will use a robust heuristic that covers 99% of cases:
	 * Last two parts for most, last three for .uk, .au, .jp etc.
	 */
	private static function get_registrable_domain(?string $host): ?string
	{
		if (! $host) {
			return null;
		}

		$parts = explode('.', $host);
		$count = count($parts);

		if ($count < 2) {
			return $host;
		}

		$tld = $parts[$count - 1];
		$sld = $parts[$count - 2];

		// Known ccTLDs with second-level registration (co.uk, com.au, etc.)
		// Simplified list for common software domains
		$double_tlds = array('uk', 'au', 'jp', 'br', 'nz', 'za', 'kr', 'cn');

		if (in_array($tld, $double_tlds) && in_array($sld, array('co', 'com', 'org', 'net', 'gov', 'ac'))) {
			// It's a double TLD, usually take last 3 parts
			if ($count >= 3) {
				return implode('.', array_slice($parts, -3));
			}
		}

		// Default: take last 2 parts
		return implode('.', array_slice($parts, -2));
	}
}
