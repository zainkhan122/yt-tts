<?php

/**
 * Video Studio API Client
 *
 * Abstraction layer for communicating with the MCQ Plugin.
 * Currently uses direct class calls for reliability when running on the same server,
 * but structured to support REST API switch in the future.
 *
 * @package    MCQ_Video_Studio
 * @subpackage Includes
 * @since      1.0.0
 */

if (! defined('ABSPATH')) {
    exit;
}

/**
 * Class VS_API_Client
 *
 * Client for consuming MCQ data services.
 *
 * @since 1.0.0
 */
class VS_API_Client
{

    private static $instance = null;

    public static function init()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Get list of available topics/exams.
     *
     * @FIX 1.5.5: counts are now DESCENDANT-INCLUSIVE (a parent topic's count includes
     *       its sub-topics' questions, matching what reserve_questions() will actually
     *       pull) and each row carries last_video_at for LRU topic rotation.
     *       Previously COUNT() matched topic_id exactly while sync stores questions
     *       under the DEEPEST term, so parent topics showed a misleadingly small pool
     *       and "enough questions" checks could wrongly skip them.
     *
     * @param string $type 'topic' or 'exam'.
     * @return array|WP_Error
     */
    public function get_sources($type = 'topic')
    {
        // @Refactored 2026-02-09: Use Custom Table Repository
        // Ignore $type 'exam' distinction for now, everything is in wp_vs_topics
        if (! class_exists('VS_MCQ_Repository')) {
            return new WP_Error('missing_class', 'VS_MCQ_Repository not found');
        }

        global $wpdb;
        $table_topics = $wpdb->prefix . 'vs_topics';
        $table_bank   = $wpdb->prefix . 'vs_mcq_bank';

        $topics = $wpdb->get_results("
            SELECT t.id, t.name, t.slug, t.parent_id, t.last_video_at, COUNT(q.id) as count 
            FROM $table_topics t 
            LEFT JOIN $table_bank q ON t.id = q.topic_id 
            GROUP BY t.id
            ORDER BY t.name ASC
        ");

        // Roll child counts up into every ancestor (single pass per level; the
        // hierarchy is shallow but the walk is depth-agnostic).
        $by_id = array();
        foreach ((array) $topics as $t) {
            $by_id[(int) $t->id] = array(
                'id'            => (int) $t->id,
                'name'          => $t->name,
                'slug'          => $t->slug,
                'parent_id'     => (int) $t->parent_id,
                'last_video_at' => $t->last_video_at,
                'count'         => (int) $t->count,
            );
        }
        foreach ($by_id as $id => $row) {
            if ($row['count'] <= 0) {
                continue;
            }
            $pid = $row['parent_id'];
            $guard = 0;
            while ($pid > 0 && isset($by_id[$pid]) && $guard++ < 20) {
                $by_id[$pid]['count'] += $row['count'];
                $pid = $by_id[$pid]['parent_id'];
            }
        }

        $data = array();
        foreach ($by_id as $row) {
            if ($row['count'] <= 0) {
                continue; // same contract as before: only topics with questions
            }
            $data[] = array(
                'id'            => $row['id'],
                'name'          => $row['name'],
                'slug'          => $row['slug'],
                'count'         => $row['count'],
                'last_video_at' => $row['last_video_at'],
            );
        }

        return $data;
    }

    /**
     * Reserve questions for a job.
     *
     * @FIX 1.5.5 (dedup/sub-topics/exams/cooldown — single reservation authority):
     *   - $topic_id accepts int|array and is expanded to descendant topic ids, so a
     *     parent-topic video draws from sub-topic questions too (sync stores rows
     *     under the deepest term; the old exact-match WHERE silently missed them).
     *   - $exam_filter (string|array of nm_exam slugs, back-compat: numeric/NULL =
     *     no filter) filters on the bank's exam_slugs column.
     *   - $opts['cooldown_days'] excludes questions used within the window (UTC),
     *     falling back to the least-used pool when the cool subset is too small.
     *   - Reservation stamps last_used_at (UTC) alongside usage_count so rotation,
     *     cooldowns and release-rollback all read one source of truth.
     *   - Ordering stays least-used-first (usage_count ASC) with last_used_at ASC and
     *     RAND() tie-breaks, preserving the existing round-robin dedup contract.
     *
     * @param int|array    $topic_id    Topic ID(s).
     * @param mixed        $exam_filter Exam slug(s), legacy numeric exam id or null.
     * @param int          $count       Number of questions.
     * @param string       $job_id      Job Identifier.
     * @param array        $opts        Optional. {cooldown_days:int}
     * @return array|WP_Error
     */
    public function reserve_questions($topic_id, $exam_filter, $count, $job_id, $opts = array())
    {
        if (! class_exists('VS_MCQ_Repository')) {
            return new WP_Error('missing_class', 'VS_MCQ_Repository not found');
        }

        global $wpdb;
        $table_bank = $wpdb->prefix . 'vs_mcq_bank';
        $repo       = VS_MCQ_Repository::get_instance();

        $topic_ids = $repo->expand_topic_ids($topic_id);
        if (empty($topic_ids)) {
            return new WP_Error('no_questions', 'No topic ids supplied for reservation.');
        }
        $placeholders = implode(',', array_fill(0, count($topic_ids), '%d'));

        // Exam filter: slugs only (legacy numeric exam ids are ignored, not errors).
        $exam_slugs = array();
        foreach ((array) $exam_filter as $ef) {
            if (is_string($ef) && !is_numeric($ef)) {
                $ef = sanitize_key($ef);
                if ($ef !== '') {
                    $exam_slugs[] = $ef;
                }
            }
        }
        $exam_sql = '';
        $exam_vals = array();
        if (!empty($exam_slugs)) {
            $clauses = array();
            foreach ($exam_slugs as $slug) {
                $clauses[] = 'FIND_IN_SET(%s, exam_slugs)';
                $exam_vals[] = $slug;
            }
            $exam_sql = ' AND (' . implode(' OR ', $clauses) . ')';
        }

        $limit = absint($count);
        if ($limit < 1) {
            $limit = 1;
        }

        $cooldown_days = isset($opts['cooldown_days']) ? (int) $opts['cooldown_days'] : 0;
        $cooldown_sql  = '';
        $cooldown_vals = array();
        if ($cooldown_days > 0) {
            $cutoff = gmdate('Y-m-d H:i:s', time() - ($cooldown_days * DAY_IN_SECONDS));
            $cooldown_sql = ' AND (last_used_at IS NULL OR last_used_at < %s)';
            $cooldown_vals[] = $cutoff;
        }

        $base_where = "topic_id IN ($placeholders) AND status = %s";
        $base_vals  = array_merge($topic_ids, array('approved'));

        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table_bank} WHERE $base_where$exam_sql$cooldown_sql ORDER BY COALESCE(usage_count, 0) ASC, last_used_at ASC, RAND() LIMIT %d",
            array_merge($base_vals, $exam_vals, $cooldown_vals, array($limit))
        ), ARRAY_A);

        // Cooldown fallback: if the cool pool cannot fill the video, top up from the
        // full least-used pool so a configured cooldown can never starve a run.
        if (!empty($cooldown_sql) && count($results) < $limit) {
            $have = array_map(function ($r) { return (int) $r['id']; }, $results);
            $extra = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM {$table_bank} WHERE $base_where$exam_sql ORDER BY COALESCE(usage_count, 0) ASC, last_used_at ASC, RAND() LIMIT %d",
                array_merge($base_vals, $exam_vals, array($limit))
            ), ARRAY_A);
            foreach ((array) $extra as $row) {
                if (count($results) >= $limit) {
                    break;
                }
                if (!in_array((int) $row['id'], $have, true)) {
                    $results[] = $row;
                    $have[] = (int) $row['id'];
                }
            }
        }

        if (empty($results)) {
            return new WP_Error('no_questions', 'No questions found for Topic ID ' . (is_array($topic_id) ? implode('+', $topic_ids) : $topic_id));
        }

        $now_utc = gmdate('Y-m-d H:i:s');
        foreach ($results as $row) {
            if (is_numeric($row['id'])) {
                $wpdb->query($wpdb->prepare(
                    "UPDATE {$table_bank} SET last_used_job_id = %s, usage_count = COALESCE(usage_count, 0) + 1, last_used_at = %s WHERE id = %d",
                    $job_id,
                    $now_utc,
                    $row['id']
                ));
            }
        }

        $questions = array();
        foreach ($results as $row) {
            $decoded_options = json_decode($row['options'], true);
            $questions[] = array(
                'id'             => $row['id'],
                'question'       => $row['question_text'],
                'options'        => is_array($decoded_options) ? $decoded_options : array(),
                'correct'        => intval($row['correct_index']),
                // @FIX 1.5.0 (SSOT): Preserve the source mapping + richer metadata so
                //       jobs rendered from reserved questions keep the link back to the
                //       source MCQ post (parent_post_id) and the explanation/difficulty
                //       the templates use.
                'parent_post_id' => isset( $row['parent_post_id'] ) ? (int) $row['parent_post_id'] : 0,
                'topic_id'       => isset( $row['topic_id'] ) ? (int) $row['topic_id'] : 0,
                'explanation'    => isset( $row['explanation'] ) ? (string) $row['explanation'] : '',
                'difficulty'     => isset( $row['difficulty'] ) ? (string) $row['difficulty'] : '',
                'exam_slugs'     => isset( $row['exam_slugs'] ) ? (string) $row['exam_slugs'] : '',
            );
        }

        return $questions;
    }

    /**
     * Release reservation on failure/cancel.
     *
     * @FIX 1.5.5: rollback is now COMPLETE. Previously only last_used_job_id was
     *       cleared while usage_count stayed incremented and last_used_at stayed
     *       stamped, so every failed/cancelled job permanently skewed the
     *       least-used rotation and poisoned cooldown windows.
     *
     * @param string $job_id Job ID.
     * @return int|WP_Error Rows released or error.
     */
    public function release_reservation($job_id)
    {
        global $wpdb;
        $table_bank = $wpdb->prefix . 'vs_mcq_bank';
        if ($wpdb->get_var("SHOW TABLES LIKE '{$table_bank}'") !== $table_bank) {
            return true;
        }
        return (int) $wpdb->query($wpdb->prepare(
            "UPDATE {$table_bank} SET last_used_job_id = NULL, usage_count = GREATEST(COALESCE(usage_count, 0) - 1, 0), last_used_at = NULL WHERE last_used_job_id = %s",
            $job_id
        ));
    }

    /**
     * Generate MCQs via Parent Plugin Gemini connection.
     *
     * @param string $topic
     * @param int    $count
     * @return array|WP_Error Array of raw MCQ data
     */
    public function generate_mcq_batch($topic, $count)
    {
        return $this->generate_mcq_batch_with_context($topic, $count, 'auto');
    }

    public function generate_mcq_batch_with_context($topic, $count, $context = 'auto')
    {
        if (! class_exists('NM_API_Client')) {
            // @MODIFIED 2026-02-18: Fallback to Local Generation (Independent Mode)
            // Use our own AI Handler to generate questions if Parent is missing.
            if (class_exists('VS_AJAX_AI_Quiz_Handler')) {
                $handler = VS_AJAX_AI_Quiz_Handler::get_instance();
                // Call public generation method
                $questions = $handler->generate_topic_quiz_data($topic, $count, $context);
                if (is_wp_error($questions)) {
                    return $questions;
                }
                return $questions;
            }
            return new WP_Error('dependency_missing', 'AI Handler not available.');
        }

        $api = NM_API_Client::get_instance();

        // Using the parent plugin's proven prompt engineering
        // Signature: generate_mcq_from_topic($topic_name, $parent_name, $num_questions, ...)
        $response = $api->generate_mcq_from_topic($topic, '', $count);

        if (! isset($response['success']) || ! $response['success']) {
            return new WP_Error('api_error', $response['error'] ?? 'Unknown API Error');
        }

        if (empty($response['data']['questions'])) {
            return new WP_Error('empty_response', 'AI returned no questions.');
        }

        return $response['data']['questions'];
    }
}
