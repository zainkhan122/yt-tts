<?php

/**
 * VisualManifestService
 *
 * Extracts source visuals from idea_text, emits deterministic placeholder tokens
 * for prompts, and expands tokens back into exact HTML/URLs after generation.
 *
 * @package DIT_TrendStudio
 */

namespace DIT\TrendStudio\Content;

if (!defined('ABSPATH')) {
    exit;
}

class VisualManifestService
{
    /**
     * Build visuals section and manifest from idea_text.
     * 
     * @MODIFIED 2026-02-13 - Added <img> extraction and $limit parameter for prompt optimization.
     *
     * @param string $idea_text
     * @param array  $manifest_out token=>html/url (by ref)
     * @param int    $limit        Max tokens to display in prompt (0 = unlimited). Manifest is always full.
     * @return string prompt section (may be empty)
     */
    public function build_visuals_section(string $idea_text, array &$manifest_out = [], int $limit = 0): string
    {
        $manifest_out = [];

        $idea_text = (string) $idea_text;
        if (trim($idea_text) === '') {
            return '';
        }

        $items = [];

        // Match iframes, blockquotes, and images
        // @MODIFIED 2026-02-15 - Unified and robustified regex (Matching ContentPipeline/Media_Passthrough hardening)
        // Handles data-src, lazy-load, and escaped JSON quotes.
        $pattern = '/<(iframe|blockquote)\b[^>]*>.*?<\/\1>|(<img[^>]+?\b(?:src|data-src|data-lazy-src)=\\\\?["\'](.*?)\\\\?["\'][^>]*>)/is';
        if (preg_match_all($pattern, $idea_text, $m)) {
            foreach ($m[0] as $html) {
                $items[] = stripslashes(trim($html));
            }
        }
        // bare URLs on their own line (oEmbed)
        foreach (preg_split('/\R/', $idea_text) as $line) {
            $line = trim((string) $line);
            if ($line !== '' && preg_match('~^https?://\S+$~i', $line)) {
                $items[] = stripslashes($line);
            }
        }

        $items = array_values(array_unique(array_filter($items)));
        if (empty($items)) {
            return '';
        }

        $section  = "\n## Source Visuals (DO NOT MODIFY)\n";
        $section .= "Use ONLY the placeholder tokens below inside 'bodyhtml'. Do NOT paste the HTML/URL. Tokens will be replaced server-side.\n";

        $count = 0;
        foreach ($items as $i => $item) {
            $token = '[VISUAL_' . $i . ']';
            $manifest_out[$token] = trim((string) $item);

            // Only add to prompt section if under limit (or no limit)
            if ($limit === 0 || $count < $limit) {
                $preview = preg_replace('/\s+/', ' ', trim((string) $item));
                $section .= "- {$token}: {$preview}\n";
                $count++;
            }
        }

        if ($limit > 0 && count($items) > $limit) {
            $section .= "... (Remaining " . (count($items) - $limit) . " visuals omitted from prompt for brevity but will be preserved)\n";
        }

        $section .= "RULE: In bodyhtml, put each token on its own line.\n";

        return $section;
    }

    /**
     * Expand VISUAL tokens back into exact HTML/URLs.
     *
     * @param mixed $data array|string
     * @param array $manifest token=>html/url
     * @return mixed
     */
    public function apply($data, array $manifest)
    {
        if (empty($manifest)) {
            return $data;
        }

        if (is_string($data)) {
            foreach ($manifest as $token => $value) {
                $trim = trim((string) $value);

                // For plain URLs: ensure oEmbed-friendly formatting
                if (preg_match('~^https?://~i', $trim) && stripos($trim, '<') === false) {
                    $replacement = "\n" . $trim . "\n";
                } else {
                    $replacement = "\n" . $value . "\n";
                }
                $data = str_replace($token, $replacement, $data);
            }

            // @MODIFIED 2026-02-14 - Strip orphaned [VISUAL_N] tokens that had no manifest entry.
            // AI may reference more tokens than source images exist (e.g. VISUAL_13 when only 0-12 exist).
            $data = preg_replace('/\[VISUAL_\d+\]/', '', $data);

            return $data;
        }

        if (is_array($data)) {
            foreach ($data as $k => $v) {
                $data[$k] = $this->apply($v, $manifest);
            }
            return $data;
        }

        if (is_object($data)) {
            // @MODIFIED 2026-02-13 - Recursively apply to object properties (Content_Schema support)
            foreach (get_object_vars($data) as $prop => $val) {
                $data->$prop = $this->apply($val, $manifest);
            }
            return $data;
        }

        return $data;
    }
}
