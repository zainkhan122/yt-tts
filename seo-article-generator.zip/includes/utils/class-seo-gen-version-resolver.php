<?php

/**
 * SeoGen_Version_Resolver — single source of truth for "what is the live,
 * authoritative version on this post right now".
 *
 * FILENAME NOTE: the file is named `class-seo-gen-version-resolver.php` (not
 * `class-version-resolver.php`) because the plugin's autoloader at
 * seo-article-generator.php:114-148 derives filenames from the class name via
 * `preg_replace('/([a-z])([A-Z])/', '$1-$2', $class_name)`, which splits
 * `SeoGen` into `Seo-Gen`. Renaming this file will break autoloading and cause
 * a FATAL "Class not found" at the first call site — see production incident
 * 2026-06-06 20:20:37 in seo-generator-2026-06-06.log.
 *
 * Used by:
 *   - Discovery_Engine       (staging-time is_newer_version() gate)
 *   - Discovery_Processor    (process_item_background + auto_finalize
 *                             re-check guards that catch the duplicate-update
 *                             race when a sibling discovery has already
 *                             finalized the same post)
 *
 * Version resolution strategy:
 *   - Structured meta sources (priorities 1-4) are collected as the "meta
 *     version". The title-parsed version (priority 5) is collected separately.
 *   - If BOTH meta and title versions are present, the NEWER one wins via
 *     Title_Analyzer::is_newer_version(). This handles the corruption case
 *     where a prior finalization updated post_title but _seo_gen_version was
 *     not written (sentinel-absent self-heal, hallucination filter mismatch,
 *     or save_schema() failure).
 *   - If only one source is present, it wins.
 *   - $fallback is the last resort.
 *
 * Sources consulted (in order of preference within each group):
 *   1) _seo_gen_version post meta (canonical)
 *   2) seogenversion post meta (legacy)
 *   3) seogenherodata['version'] (hero data)
 *   4) _seo_gen_hero_data['version'] (legacy hero data)
 *   5) post_title parsed via Title_Analyzer::extract()
 *   6) $fallback (caller-supplied)
 *
 * @package SEO_Article_Generator\Utils
 * @since   2026-06-06
 */

namespace SEO_Article_Generator\Utils;

use SEO_Article_Generator\Discovery\Title_Analyzer;

if (! defined('ABSPATH')) {
    exit;
}

final class SeoGen_Version_Resolver
{
    /**
     * Resolve the live, authoritative version on a post.
     *
     * @param int    $post_id  WordPress post ID. Values <= 0 return $fallback.
     * @param string $fallback Last-resort value used when no candidate yields
     *                         a usable version string.
     * @return string Trimmed version string, or '' when nothing is recoverable.
     */
    public static function current_version(int $post_id, string $fallback = ''): string
    {
        if ($post_id <= 0) {
            return trim($fallback);
        }

        // Collect structured meta candidates (priorities 1-4) and the
        // title-parsed candidate (priority 5) separately so we can compare
        // them. If the title version is NEWER than the meta version, the
        // title wins — this handles the common corruption case where a
        // prior finalization updated the post_title but _seo_gen_version
        // meta was not written (sentinel-absent self-heal, hallucination
        // filter mismatch, or save_schema() failure).
        $meta_version    = '';
        $title_version   = '';

        $c1 = trim((string) \get_post_meta($post_id, '_seo_gen_version', true));
        if ($c1 !== '' && strcasecmp($c1, 'unknown') !== 0) {
            $meta_version = $c1;
        }

        if ($meta_version === '') {
            $c2 = trim((string) \get_post_meta($post_id, 'seogenversion', true));
            if ($c2 !== '' && strcasecmp($c2, 'unknown') !== 0) {
                $meta_version = $c2;
            }
        }

        $hero_version = '';
        $hero_data = \SEO_Article_Generator\Plugin::get_instance()->get_hero_data($post_id);
        if (is_array($hero_data)) {
            $c3 = trim((string) ($hero_data['version'] ?? ''));
            if ($c3 !== '' && strcasecmp($c3, 'unknown') !== 0) {
                $hero_version = $c3;
                if ($meta_version === '') {
                    $meta_version = $c3;
                }
            }
        }

        // @FIX 2026-07-25: Cross-reference _seo_gen_version with seogenherodata['version'].
        // When both are present and differ, prefer the newer one. seogenherodata is
        // regenerated from schema on every save (see Schema_Sync_Service::save_schema()
        // fast-path fix), so it is the most reliable source. _seo_gen_version can drift
        // when title reconciliation overwrites it with a stale title-parsed version.
        if ($meta_version !== '' && $hero_version !== '' && strcasecmp($meta_version, $hero_version) !== 0) {
            if (Title_Analyzer::is_newer_version($hero_version, $meta_version)) {
                $meta_version = $hero_version;
            }
        }

        $post = \get_post($post_id);
        if ($post instanceof \WP_Post && trim((string) $post->post_title) !== '') {
            $parsed = (new Title_Analyzer())->extract((string) $post->post_title);
            if (is_array($parsed) && ! empty($parsed['version'])) {
                $c4 = trim((string) $parsed['version']);
                if ($c4 !== '' && strcasecmp($c4, 'unknown') !== 0) {
                    $title_version = $c4;
                }
            }
        }

        // @FIX 2026-07-26: Reject title-only versions that are BARE 4-digit years
        // when a real structured meta version (dotted or build) is present.
        //
        // Title_Analyzer::VERSION_PATTERN (class-title-analyzer.php:28) Form B and
        // extract_single() line 246-260 accept a bare 4-digit year like "2024" /
        // "2026" as a candidate "version" when the title is "<Product> <Year>"
        // (Microsoft OneNote 2026, Adobe Photoshop 2025, Office 2024, AutoCAD 2026,
        // VMware Workstation Pro 2026, Microsoft PC Manager 2024). Once that year
        // overrides the structured meta via the @FIX 2026-07-25 cross-reference at
        // lines 108-112, the live version becomes a stale brand year and
        // is_newer_version() compares a freshly-stageed dotted/build version like
        // "2607 Build 20228" against bare "2026" — equal-tier (both default 5),
        // build tie (0 vs 0) → returns false → row stamped skipped_not_newer.
        //
        // We only honor a bare-year title-version override when no better structured
        // meta candidate exists. This is consistent with the @FIX 2026-07-25 comment
        // at lines 103-112 (seogenherodata is the most reliable structured source).
        if ($title_version !== '' && $meta_version !== ''
            && preg_match('/^\d{4}$/', $title_version)
            && preg_match('/\d+\.\d+/', $meta_version)
        ) {
            $title_version = '';
        }

        // Decision: prefer the newer version when both sources agree on identity.
        // If meta_version is set and title_version is NEWER, the title wins
        // (the meta is stale from a prior finalization that updated the title
        // but not _seo_gen_version). If they are equal or the meta is newer,
        // use the meta (canonical structured source). If only one is set, use it.
        if ($meta_version !== '' && $title_version !== '') {
            if (Title_Analyzer::is_newer_version($title_version, $meta_version)) {
                return $title_version;
            }
            return $meta_version;
        }

        if ($meta_version !== '') {
            return $meta_version;
        }

        if ($title_version !== '') {
            return $title_version;
        }

        $fb = trim((string) $fallback);
        if ($fb !== '' && strcasecmp($fb, 'unknown') !== 0) {
            return $fb;
        }

        return '';
    }
}
