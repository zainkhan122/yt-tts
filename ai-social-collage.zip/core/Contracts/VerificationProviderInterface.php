<?php
namespace AiSocialCollage\Contracts;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

interface VerificationProviderInterface {

    public function get_provider_name(): string;

    public function analyze_image( string $image_path, string $prompt, array $options = [] ): array;

    public function get_model_name(): string;

    public function is_available(): bool;

    public function get_cost_estimate( int $image_count = 1 ): float;
}