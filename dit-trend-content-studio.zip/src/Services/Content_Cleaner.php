<?php

namespace DIT\TrendStudio\Services;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Content Cleaner Service
 * 
 * Sanitizes raw scraped HTML to remove layout garbage, ads, and trackers,
 * leaving only clean editorial content (Text, Images, Embeds).
 */
class Content_Cleaner
{
    /**
     * Allowed HTML tags
     * Everything else will be stripped or unwrapped.
     */
    private $allowed_tags = [
        'h1',
        'h2',
        'h3',
        'h4',
        'h5',
        'h6',
        'p',
        'br',
        'hr',
        'ul',
        'ol',
        'li',
        'blockquote',
        'img',
        'a',
        'iframe',
        'strong',
        'em',
        'b',
        'i',
        'table',
        'thead',
        'tbody',
        'tr',
        'th',
        'td',
        'figure',
        'figcaption'
    ];

    /**
     * Tags to completely remove (including content)
     */
    private $remove_tags = [
        'script',
        'style',
        'link',
        'meta',
        'noscript',
        'form',
        'input',
        'button',
        'svg'
    ];

    /**
     * Allowed iframe domains
     */
    private $allowed_embeds = [
        'youtube.com',
        'youtu.be',
        'twitter.com',
        'x.com',
        'instagram.com',
        'tiktok.com',
        'facebook.com',
        'vimeo.com',
        'pinterest.com',
        'pin.it'
    ];

    /**
     * Clean junk HTML
     *
     * @param string $html Raw HTML
     * @return string Cleaned HTML
     */
    public function clean(string $html): string
    {
        if (empty($html)) return '';

        // suppress warnings for malformed HTML
        $dom = new \DOMDocument();
        $html = mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8');
        @$dom->loadHTML($html, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);

        $xpath = new \DOMXPath($dom);

        // 1. Remove unwanted tags entirely
        foreach ($this->remove_tags as $tag_name) {
            $nodes = $xpath->query("//{$tag_name}");
            foreach ($nodes as $node) {
                $node->parentNode->removeChild($node);
            }
        }

        // 2. Remove comments
        foreach ($xpath->query('//comment()') as $comment) {
            $comment->parentNode->removeChild($comment);
        }

        // 3. Process all elements
        // We traverse backward to avoid tree modification issues
        $nodes = $xpath->query('//*');
        for ($i = $nodes->length - 1; $i >= 0; $i--) {
            $node = $nodes->item($i);

            // Skip text nodes (handled by parent logic usually, but here we query *)
            if (!($node instanceof \DOMElement)) continue;

            $tag = strtolower($node->nodeName);

            if (in_array($tag, $this->allowed_tags)) {
                // Keep tag, restrict attributes
                $this->clean_attributes($node);
            } else {
                // Unwrap: Replace node with its children
                $this->unwrap($node);
            }
        }

        // 4. Post-process clean up empty nodes
        $this->remove_empty_nodes($xpath);

        $html = trim($dom->saveHTML());

        // @MODIFIED 2026-02-09 - Remove stubborn empty paragraphs with breaks/spaces
        $html = preg_replace('/<p>\s*(?:<br\s*\/?>|&nbsp;|\s)*\s*<\/p>/ui', '', $html);

        return $html;
    }

    /**
     * Remove all attributes except allow-list
     */
    private function clean_attributes(\DOMElement $node)
    {
        $tag = strtolower($node->nodeName);
        $allowed_attrs = [];

        // Define allowed attributes per tag
        switch ($tag) {
            case 'img':
                // Fix lazy-loaded images: prefer data-src/data-original when src is empty/placeholder.
                $src = trim($node->getAttribute('src'));

                $is_placeholder = (
                    $src === '' ||
                    stripos($src, 'data:') === 0 ||
                    stripos($src, 'about:blank') === 0 ||
                    $src === '#' ||
                    preg_match('~(pixel|placeholder|spacer)\.(gif|png)~i', $src)
                );

                if ($is_placeholder) {
                    foreach (['data-src', 'data-lazy-src', 'data-original', 'data-url'] as $k) {
                        $cand = trim($node->getAttribute($k));
                        if ($cand && filter_var($cand, FILTER_VALIDATE_URL)) {
                            $node->setAttribute('src', $cand);
                            break;
                        }
                    }
                }

                // Preserve responsive sources if present (safe attributes)
                if (!$node->hasAttribute('srcset')) {
                    $data_srcset = trim($node->getAttribute('data-srcset'));
                    if ($data_srcset) {
                        $node->setAttribute('srcset', $data_srcset);
                    }
                }
                if (!$node->hasAttribute('sizes')) {
                    $data_sizes = trim($node->getAttribute('data-sizes'));
                    if ($data_sizes) {
                        $node->setAttribute('sizes', $data_sizes);
                    }
                }

                $allowed_attrs = [
                    'src',
                    'alt',
                    'title',
                    'width',
                    'height',
                    'srcset',
                    'sizes',
                    'loading',
                    'decoding',
                    'fetchpriority'
                ];
                break;
            case 'a':
                $allowed_attrs = ['href', 'title', 'target'];
                break;
            case 'iframe':
                // Keep safe, embed-critical attrs (no style/class to avoid layout garbage)
                $allowed_attrs = [
                    'src',
                    'width',
                    'height',
                    'allowfullscreen',
                    'loading',
                    'referrerpolicy',
                    'allow',
                    'title',
                    'frameborder'
                ];

                // Validate iframe source
                $src = $node->getAttribute('src');
                if (!$this->is_allowed_embed($src)) {
                    $node->parentNode->removeChild($node); // Remove unsafe iframes
                    return;
                }
                break;
            case 'blockquote':
                // Social embeds often rely on data-* attrs. Allow class/cite + all data-*.
                // Still safe because we are not allowing scripts/styles.
                $allowed_attrs = ['class', 'cite'];

                // Remove attributes not in list, except data-*
                $attrs = [];
                if ($node->hasAttributes()) {
                    foreach ($node->attributes as $attr) {
                        $attrs[] = $attr->name;
                    }
                }

                foreach ($attrs as $attr) {
                    if (strpos($attr, 'data-') === 0) {
                        continue; // allow all data-*
                    }
                    if (!in_array($attr, $allowed_attrs, true)) {
                        $node->removeAttribute($attr);
                    }
                }

                return; // IMPORTANT: we already removed attrs, do not run default removal below
            case 'figure':
                $allowed_attrs = ['class'];
                break;
            case 'figcaption':
                $allowed_attrs = ['class'];
                break;
            default:
                // Global allowed attributes? Maybe 'id' for anchors? 
                // For now, strict cleaning.
                $allowed_attrs = [];
        }

        // Remove attributes not in list
        $attrs = [];
        if ($node->hasAttributes()) {
            foreach ($node->attributes as $attr) {
                $attrs[] = $attr->name;
            }
        }

        foreach ($attrs as $attr) {
            if (!in_array($attr, $allowed_attrs)) {
                $node->removeAttribute($attr);
            }
        }
    }

    /**
     * Unwrap a node (replace it with its children)
     */
    private function unwrap(\DOMNode $node)
    {
        $parent = $node->parentNode;
        if (!$parent) return;

        while ($node->hasChildNodes()) {
            $child = $node->firstChild;
            $parent->insertBefore($child, $node);
        }
        $parent->removeChild($node);
    }

    /**
     * Check if iframe src is allowed
     */
    private function is_allowed_embed($src): bool
    {
        if (empty($src) || !is_string($src)) {
            return false;
        }

        $parsed = \wp_parse_url($src);
        $scheme = strtolower($parsed['scheme'] ?? '');
        $host   = strtolower($parsed['host'] ?? '');

        if (!in_array($scheme, ['http', 'https'], true)) {
            return false;
        }
        if ($host === '') {
            return false;
        }

        foreach ($this->allowed_embeds as $allowed) {
            $allowed = strtolower($allowed);

            if ($host === $allowed) {
                return true;
            }

            $len = strlen($allowed);
            if (strlen($host) > $len && substr($host, - ($len + 1)) === '.' . $allowed) {
                return true;
            }
        }

        return false;
    }

    /**
     * Remove empty P tags or unwrapped junk
     */
    private function remove_empty_nodes(\DOMXPath $xpath)
    {
        // Remove empty paragraphs
        // Excluding img/iframe/hr inside
        $nodes = $xpath->query("//p[not(normalize-space()) and not(img) and not(iframe)]");
        foreach ($nodes as $node) {
            $node->parentNode->removeChild($node);
        }
    }
    /**
     * Lighter cleaning for AI-generated content (focus on artifacts)
     * @MODIFIED 2026-03-09 - Added image preservation guard and DOM-aware fixes.
     *
     * @param string $html Raw generated HTML
     * @return string Cleaned HTML
     */
    public function clean_generated_content(string $html): string
    {
        if (empty($html)) {
            return '';
        }

        $original = $html;
        $before_img_count = preg_match_all('/<img\b/i', $html);

        // Standardize attribute quotes (AI often returns backslashed quotes)
        $html = preg_replace('/(\s(?:src|href|alt|title|class|width|height))=\\\\?["\'](.*?)\\\\?["\']/i', '$1="$2"', $html);

        // Fix broken image markup/artifacts
        $html = $this->fix_broken_image_artifacts($html);

        // Fix placeholder links
        $html = $this->unwrap_placeholder_links($html);

        $after_img_count = preg_match_all('/<img\b/i', $html);

        // CRITICAL GUARD: Revert if cleaning accidentally deleted images (Issue #FixSafeClean)
        if ($after_img_count < $before_img_count) {
            return trim($original);
        }

        return trim($html);
    }

    /**
     * Fix common AI image artifacts using DOMDocument for safety
     * @MODIFIED 2026-03-09 - Switched from regex to DOM parsing for attribute safety.
     *
     * @param string $html
     * @return string
     */
    private function fix_broken_image_artifacts(string $html): string
    {
        if (stripos($html, '<img') === false) {
            return $html;
        }

        // Use DOMDocument for robust attribute manipulation
        $dom = new \DOMDocument();
        // Load HTML with UTF-8 support and suppress errors for malformed AI segments
        $wrapped = '<?xml encoding="utf-8" ?>' . $html;
        libxml_use_internal_errors(true);
        @$dom->loadHTML($wrapped, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
        libxml_clear_errors();

        $images = $dom->getElementsByTagName('img');
        foreach ($images as $img) {
            /** @var \DOMElement $img */
            // Remove hallucinated fragments and artifacts
            $hallucinated_attrs = ['loading', 'decoding', 'async', 'lazy'];
            foreach ($hallucinated_attrs as $attr) {
                if ($img->hasAttribute($attr)) {
                    $img->removeAttribute($attr);
                }
            }

            // Ensure alt is present
            if (!$img->hasAttribute('alt')) {
                $img->setAttribute('alt', '');
            }
        }

        $result = $dom->saveHTML();
        // Remove xml header if DOM added it back
        $result = str_replace('<?xml encoding="utf-8" ?>', '', $result);

        return $result;
    }

    /**
     * Unwrap <a> tags that have placeholder href values.
     * Keep the anchor text, but remove the tag.
     *
     * @MODIFIED 2026-02-16
     * @MODIFIED 2026-03-09 - Fixed id extraction
     * @param string $html
     * @return string
     */
    private function unwrap_placeholder_links(string $html): string
    {
        if (stripos($html, '<a') === false) {
            return $html;
        }

        // Use DOMDocument to safely unwrap without breaking other tags
        $dom = new \DOMDocument();
        // UTF-8 support
        $wrapped = '<?xml encoding="UTF-8"><div id="dit-ts-cln-wrapper">' . $html . '</div>';
        @$dom->loadHTML($wrapped, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);

        $xpath = new \DOMXPath($dom);
        $anchors = $xpath->query('//a');

        $placeholders = ['#', 'http://#', 'https://#', 'about:blank', 'javascript:void(0)'];

        foreach ($anchors as $a) {
            /** @var \DOMElement $a */
            $href = trim($a->getAttribute('href'));
            $is_placeholder = in_array($href, $placeholders, true) || $href === '';

            if ($is_placeholder) {
                // Remove the <a> tag but keep its children (text/formatting)
                $parent = $a->parentNode;
                if ($parent) {
                    while ($a->hasChildNodes()) {
                        $child = $a->firstChild;
                        $parent->insertBefore($child, $a);
                    }
                    $parent->removeChild($a);
                }
            }
        }

        $root = $dom->getElementById('dit-ts-cln-wrapper');
        if (!$root) {
            return $html;
        }

        $cleaned = '';
        foreach ($root->childNodes as $node) {
            $cleaned .= $dom->saveHTML($node);
        }

        return $cleaned;
    }
}
