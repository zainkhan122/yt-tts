## Wave 1 (2026-08-31)
- haniumaimaz: haniandumaima.com | IG haniandumaimas (own sameAs) — STRONG
- style-up: generic results, NOTHING — retry q2 / manual
- florent: florentpakistan.com | IG florentpk (own sameAs) — STRONG
- xenia-formals: xeniaformals.pk (ZoomInfo official; .com alt Emporium Mall) — site MEDIUM, IG TBD harvest
- ajr-couture-abbas-jamil-rajpoot: ajrcouture.com | IG ajrcouture 141K (own sameAs) — STRONG
- ayzel-by-afrozeh: ayzel.pk | IG ayzelonline (own sameAs) — STRONG (sold on afrozeh.com but own site exists)
- afrozeh: USER-VERIFIED afrozeh.com | IG afrozehofficial
## Wave 2
- style-up: 2 queries, nothing brand-specific — MANUAL
- abyaan: candidates aabyaan.com (AABYAAN Faisalabad, IG aabyaanofficial) — spelling differs (Abyaan vs Aabyaan) — VERIFY/compare content else MANUAL
- elaf: IG elafofficialpk 122K (PK made-to-measure) — IG-ONLY; elaf_india_official = different (Surat manufacturer)
- rang-rasiya: rangrasiya.com.pk OWN STORE (support@rangrasiya.com.pk) — STRONG site, IG harvest TBD (overturns earlier parked reject)
- alizeh-fashion: alizeh.pk | IG alizehfashionofficial (own schema) — STRONG (tiny alizehfashion.pk 694f = different account)
## Wave 3
- ishq-e-rang: nothing (silkrang/ishaq/rangoon all different) — retry q / MANUAL
- esmel: esmelofficial.com | IG esmelofficial (own schema, Weavetex Trading, chikan suits) — STRONG
- faiza-faisal: faizafaisal.com | IG faizafaisalofficial (own schema) — STRONG
- farasha: no PK brand found (Farfasha=Qatar?, farashastyle=US stylist) — MANUAL
- fine-tex: nothing relevant (A-Tex bedsheets etc.) — MANUAL
## Wave 4
- faiza-saqlain: faizasaqlain.pk (X bio; VERIFY) | IG faizasaqlain_ 171K — STRONG
- freesia-premium: freesiapremium.com | IG freesiapremium (own schema) — STRONG
- sable-vogue: sablev.net | IG sablevogueofficial 220K (own schema+ZoomInfo) — STRONG
- la-elise: laeliseonline.com | IG laeliseonline (own schema, Model Town Lahore) — STRONG
- roheenaz: roheenaz.com | IG roheenaz.pk (own schema; founder Hassan Ahmad = same as Esmel/Weavetex) — STRONG
## Wave 5
- sahane: thesahane.com | IG sahanepk (own schema, sleepwear PK) — MEDIUM (also sahanestore.com/sahane.shop exist; VERIFY)
- inayat: inayatpremium.com | IG inayatpremium (own schema, wedding formals) — STRONG (prev inayat.com demote was right)
- hz: hztextiles.pk | IG hz_textiles (own schema "HZ Textiles Pk") — STRONG
- lakhany: still resellers only; site=lsmfabrics.com stands; IG needs targeted query
- lavish-premium: nothing (lavishe.pk = different brand) — retry/MANUAL
## Wave 6
- maryam-hussain: houseofmaryam.com = UK RETAILer carrying her, not brand site — retry IG query / MANUAL
- ahmad-raza: nothing (influencers) — MANUAL
- meerak: meerak.pk | IG meerak_official (own schema, Lahore factory) — STRONG (meeraki.com = different brand!)
- mina-hasan: minahasan.com | IG minahasanofficial (FB: Karachi boutique, info@minahasan.com) — STRONG, verify site
- lakhany: IG fabric_lsm (documented official in 2 articles, 2016-era) — include w/ note; site lsmfabrics.com stands
## Wave 7
- noorma-kaamal: IG n.kaamal (own FB states it) — IG-ONLY STRONG
- fabrich: IG fabrichofficialstore 18K (unstitched mens cloth) — IG-ONLY STRONG, no site found
- regalia-textiles: 3 different Regalias (regalia.pk 216f generic, regalia.clothing=Kenya, regaliaattire.com) — MANUAL w/ candidates
- manahil-lakhani: manahillakhani.com | IG manahillakhani_official (own schema) — STRONG
- brumano: shopbrumano.com | IG shopbrumano (own schema, Hyderabad PK menswear) — STRONG
## Wave 8
- zyna: nothing (Zainab Chottani/Iznik different) — retry / MANUAL
- alee-malic: aleemalic.com (Lahore, own contact) — STRONG site, IG harvest TBD
- menaal: ambiguous (menaalofficial_ 272f = UK reseller; manalsaleem different) — MANUAL
- al-siyaab: resellers only — retry IG query / MANUAL
- republic-womenswear: IG republicwomenswear (couture acct refs it as main) — IG-ONLY MEDIUM-STRONG
## Wave 9
- riaz-arts: riazarts.com (ZoomInfo official) | IG riazarts 29K (self-declared official) — STRONG
- saphron: ambiguous (saffronpk.com "Saffron" vs Saphron spelling; saff_rron=India) — MANUAL w/ candidates
- nairah: IG nairahpk 32K (luxury prints, Karachi) — IG-ONLY MEDIUM (no site)
- zarposh: all 3 candidates wrong/weak (Kashmir boutique 2.8K, empty 305f, template site) — MANUAL
- yashfa: yashfanoor.online (YASHFA NOOR luxury PK) — MEDIUM site, verify+IG harvest
## Wave 10
- al-zohaib: alzohaibstore.com | IG alzohaibtextile (own schema + LinkedIn) — STRONG
- casual-lite: resellers only — retry IG / MANUAL
- sardinia: sardinia.pk | IG sardinia.pk (own schema, Lahore) — STRONG (sardinia.com parked was right reject)
- meeral: IG meeralofficial 233K — IG-ONLY STRONG, no site
- scherezade: scherezade.pk | IG scherezadeofficial (own schema) — STRONG (parked reject overturned)
- NOTE sarazara.com = different brand (not sara-jahan)
## Wave 11
- seran: seran.com.pk (own store, founded 2020) — STRONG site, IG harvest TBD (seran.com parked demote was right)
- fresh-birds: IG freshbirds 133K (kids apparel PK) — IG-ONLY STRONG
- edge-republic: edge.pk (EDGE Republic sherwani/menswear) | IG edgerepublicofficial 48K — STRONG
- rashid-textiles: rashidtex.com | IG rashidtextile.official (own schema) — STRONG
- izel: IG izelapparel 208K Lahore | site izelapparel.com (Behance; VERIFY) — STRONG-ish
## Wave 12
- sundas-ahad: IG sundasahadofficial 2.5K (name-exact, worldwide shipping) — IG-ONLY MEDIUM
- maria-osama-khan: mariaosamakhan.com | IG mariaosamaofficial (own schema, Gulberg Lahore) — STRONG
- anayra-amal: anayraamal.com (designer brand own site) — STRONG site, IG harvest TBD
- atiya-irfan-studio: atiyairfan.com (own studio site, PK 2022) — STRONG site, IG harvest TBD
- ayla-studio: aylastudio.com | IG aylastudio_official (own schema) — STRONG
- abaanzohan (from wave-2 result): IG abaanzohan 20K women/kids PK — IG-ONLY STRONG
## Wave 13
- aylin-1: IG aylinfashions.official 22K (#aylin brand acct) — IG-ONLY MEDIUM
- bin-musab: nothing (Bin Tayyab = different) — retry / MANUAL
- cyanic: cyanic.pk | IG cyanicofficial.pk (own schema) — STRONG
- diara-couture: diaracouture.com | IG diaracouture (own schema) — STRONG
- alif-yay: nothing matches "Alif Yay" — retry / MANUAL
## Wave 14
- aisha-fatema: IG aishafatemaofficial 3.5K (Luxury Pret/Formals PK) — IG-ONLY STRONG
- erum-khan: erumkhanstores.com | IG erumkhancouture 857K (own schema, MM Alam Lahore) — STRONG
- fabiha-fatima: fabihafatima.pk | IG fabihafatima.official (own schema) — STRONG
- farah-agha: nothing name-exact — retry / MANUAL
- feathers: feathers.pk | IG feathers.com.pk (own schema) — STRONG
## Wave 15
- fozia-khalid: foziakhalid.com (ZoomInfo) | IG foziakhalid_official 106K (official@foziakhalid.com) — STRONG
- hanim: hanimofficial.com (own about; Sanaulla Intl also carries) — STRONG site, IG harvest TBD
- hijab-ul-ameer: nothing name-exact — MANUAL
- house-of-nyyra: nothing Nyyra-exact — retry / MANUAL
- ibraysha: nothing — retry / MANUAL
## Wave 16 notes
- RESTORE misaal-by-ayesha-somaya: misaalwear.com (title "Misaal Wear – www.misaalwear.com" — real PK brand site over-demoted by signal check), IG harvest TBD
- To MANUAL as confirmed foreign/parked (no re-search): alyra (BR payroll), fiona (loans), hem (design studio), rangeen (case mgmt), sprinkles (cupcakes), zaren, zuri (drones)
## Wave 16
- avyana: avyana.pk | IG avyanapk (own schema) — STRONG
- ay-textile: nothing — retry / MANUAL
- ayesha-closet: IG ayeshascloset.pk 17K (Karachi malls) — IG-ONLY STRONG
- azzal-by-ayesha-usman: ayeshaandusman.com (Ayesha & Usman Qamar label) — STRONG site, IG harvest TBD
- baby-nest: babynest.com.pk | IG babynest.pk (own schema) — STRONG
## Wave 17
- banafsheh: IG wearbanafsheh 5.4K (eastern wear) — IG-ONLY MEDIUM-STRONG
- bareeq: bareeqoutfits.com | IG bareeqofficial 43K (own schema) — STRONG
- bibayas: IG bibayaas 4K (Modest Wear Brand abayas PK) — IG-ONLY STRONG
- blanche-fashion: blancheglobal = SRI LANKA — retry PK query / MANUAL
- buraq: buraqfabrics.com | IG buraqfabrics.official (own schema) — STRONG
## Wave 18
- chandan-nagri: chandan.pk | IG chandannagriofficial (own schema) — STRONG
- damask-clothing-studio: damaskclothingstudio.com | IG damaskclothingstudio (own schema) — STRONG
- deck-up: deckupclothing.com | IG deckupclothing 55K (own schema, PECHS Karachi) — STRONG
- divinely-crafted: divinelycrafted.org | IG _divinely.crafted (own schema, Lahore abayas) — STRONG
- eman-butt: ambiguous (emanbuttofficial_ hinted) — retry / MANUAL
## Wave 19
- esra-fashion: IG esrafashion.pk 162K (#esrafashions) — IG-ONLY STRONG (esraa.in=India skip)
- ezra: ezra.co.in = India only — MANUAL
- fahza: nothing name-exact — retry / MANUAL
- fascino: fascino_bd = Bangladesh — MANUAL
- garnet-clothing-pret: garnetclothing.com (own PK store) — STRONG site, IG harvest TBD (garnetatelier.pk = maybe different)
## Wave 20
- gem-garments: gemgarments.com | IG gemgarments (own schema, Liberty Lahore menswear) — STRONG
- gulposh: candidates weak/India-Kashmir — MANUAL
- hana: nothing PK-specific — retry / MANUAL
- hareem-fatima: hareemfatima.pk | IG hareemfatimaonline (own schema) — STRONG
- huma-gul: humagul.pk | IG humagulofficial (own schema, Nowshera PK) — STRONG
## Wave 21
- imran-aftab: resellers only — MANUAL
- imran-ramzan: imranramzan.com | IG imranramzan.official (own schema, Lahore) — STRONG
- imrozia-premium: imroziaserene.com | IG imrozia_sereneoffical 23K (Imrozia|Serene brand; premium line) — STRONG-ish
- insiya-clothing: insiyaclothing.com (Insiya by Saira Jawad, Lahore) — STRONG site, IG harvest TBD
- iq-exclusive: nothing matching — MANUAL
## Wave 22
- ixample: nothing — MANUAL
- jahaan: jahaan.com.pk | IG jahaanofficialpk (own schema) — STRONG
- kahf-premium: kahfpremium.com (Lahore own site) — STRONG site, IG harvest TBD
- karashe: nothing name-exact (KAARA=different) — MANUAL
- khuwab-by-kazma: khuwabbykazma.com | IG khuwab_by_kazma (own schema, Karachi) — STRONG
## Wave 23
- la-khilaba: only marketplace listings — one retry / MANUAL
- madiha-gohar: only personal tiny accts — MANUAL
- maherposh: mehrposh.pk candidate BUT spelling differs (Maherposh vs Mehrposh) — MANUAL w/ candidate
- manahils: IG manahils_pk 4.9K (Luxury Women's Clothing) — IG-ONLY MEDIUM-STRONG (sunniamanahil=different)
- musferah-saad: musferahsaad.com | IG musferahsaadofficial (own schema, Lahore) — STRONG
## Wave 24
- nomi-nisar: nomiansari.com.pk candidate (Nomi ANSARI vs handle "nomi-nisar") — MANUAL w/ candidate (likely same, name differs)
- ombrella-official: ombrellaofficial.com | IG ombrellaofficial (own schema, Gulberg Lahore) — STRONG
- panache-apparel: IG panachepakistan 96K (self-declared official) — IG-ONLY STRONG
- pret-bee-1: nothing name-exact — retry / MANUAL
- rabias-textiles: nothing own-site — retry IG / MANUAL
## Wave 25
- rehan-n-muzammil: rehannmuzammil.com (luxury women's fashion) — STRONG site, IG harvest TBD
- ricamo: ricamo.com.pk | IG ricamobyhumera (own schema; ricamoindia=different) — STRONG
- ruby-suleiman: rubysuleiman.com (formals PK) — STRONG site, IG harvest TBD
- saira-sultana: nothing name-exact — retry / MANUAL
- stitch-vibes: stitchvibes.com | IG stitch.vibes_ 15K (own schema) — STRONG
## Wave 26
- stitching-cotton: stitchingcotton.com | IG stitchingcotton (own schema, Malir Karachi) — STRONG
- suntex-fabrics: suntexfabrics.com | IG suntexfabric (own schema) — STRONG
- syah: IG syahofficialstore 15K (SYAH ® worldwide) — IG-ONLY MEDIUM-STRONG
- tana-bana: tanabana.pk AND taanabaana.pk both PK, spellings differ — MANUAL w/ both candidates (thetanabana=India)
- the-great-master-tgm: IG tgmstore.pk 173K (The Great Masters eastern/modest) — IG-ONLY STRONG (tgmluxe.com maybe theirs, unproven)
## Wave 27
- threads-motifs: threadsandmotifs.com | IG threadsandmotifsofficial (own schema, Korangi Karachi) — STRONG
- tng: tngclothing.com "The New Generation" (US streetwear?) — uncertain — MANUAL w/ candidate
- unss-apparel: unsforall.com "UNS Shop" (PK influencers) — name mismatch UNS vs UNSS — MANUAL w/ candidate
- urban-cut: IG urbancut.pk 8.2K (URBAN CUT PRET) — IG-ONLY STRONG
- vs-textiles: vs.com.pk | IG vstextilemills 184K (own schema) — STRONG
## Wave 28
- waresha: IG waresha.clothes 12K (Designer Women's Apparel by Asif Embroidery est 1980) — IG-ONLY STRONG
- yards: yards.pk (own store, lawn collections) — STRONG site, IG harvest TBD
- zariya: zariyaclothing.com | IG zariyaclothing.pk 22K (own schema) — STRONG
- zauk: zaukstore.com | IG zaukofficial (own schema, Karachi) — STRONG (zouqfashion=India)
- zebtan: 3 weak/mismatched candidates (zebtan.pk=kitchen, zaibtan.online=hijab spelling, zebtancollection=jewellery) — MANUAL w/ candidates
## Retry wave 1
- ishq-e-rang: no own site/IG; Sanaulla sells "Farasha by Ishq e Rang" (Ishq-e-Rang's RTW line = Farasha) — MANUAL w/ note
- maryam-hussain: IG maryamhussaincouture 177f (self-declared official but tiny) — MANUAL w/ candidate
- al-siyaab: alsiyaab.com (Karachi own shop) — STRONG site, IG harvest TBD
- casual-lite: resellers only — MANUAL
- rabias-textiles: rabiasonline.com | IG rabiastextiles (own schema) — STRONG
## Retry wave 2
- la-khilaba: la-khilaba-modest-wear.myshopify.com (brand's OWN shopify, abayas) — MEDIUM-STRONG site, IG harvest TBD
- saira-sultana: resellers only (line = "Andaaz by Saira Sultana") — MANUAL
- style-up: 3 queries, nothing — MANUAL
- house-of-nyyra: nothing — MANUAL
- ibraysha: nothing — MANUAL
- daak-co: IG daakandco (from brave wave) — IG-ONLY MEDIUM-STRONG
