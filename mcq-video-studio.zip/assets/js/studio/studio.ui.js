/**
 * MCQ Video Studio - UI Module
 * 
 * Handles DOM bindings, event delegation, and UI state updates.
 * Split from studio.controller.js for maintainability.
 * 
 * @requires MCQVSLogger (studio.logger.js)
 * 
 * @version 8.8.0
 * @since 2026-02-01
 * @modified 2026-02-08 - Added Calendar Wizard for bulk scheduling
 */

(function (window) {
    'use strict';
    console.log('[MCQVS DEBUG] studio.ui.js loaded');

    const Logger = window.MCQVSLogger;

    class UIController {
        constructor(state, config, callbacks) {
            this.state = state;
            this.config = config;
            this.callbacks = callbacks || {};

            // @NEW 2026-02-08: Calendar wizard state
            this.calendarState = {
                currentStep: 1,
                wizardData: {},
                pollInterval: null,
                batches: [] // Recent batches for status tracking
            };

            if (Logger) {
                Logger.info('UI_INIT');
            }
        }

        /**
         * Initialize UI bindings
         */
        initialize() {
            if (this._initialized) { return; }
            this._initialized = true;

            // ---- Config normalization (legacy + modular) ----
            // Many modules (and older codepaths) expect "ajaxurl" lowercase; modular config uses "ajaxUrl".
            this.config = this.config || {};
            this.config.ajaxurl = this.config.ajaxurl || this.config.ajaxUrl || window.ajaxurl || '';
            this.config.ajaxUrl = this.config.ajaxUrl || this.config.ajaxurl;
            // Note: nonce may be empty in some contexts, handled gracefully by ajaxPost

            // Ensure shared state subtrees exist (templates + text effects parity)
            this.state.textEffects = this.state.textEffects || {
                enabled: true,
                currentStyle: 'classicBold',
                showPreview: true
            };

            // Wrap each binding so a single failure does not cascade
            const safeBind = (name, fn) => { try { fn.call(this); } catch (e) { if (Logger) Logger.error('BIND_FAIL', { name, error: e.message }); console.warn('[MCQVS UI] Bind failed:', name, e.message); } };

            safeBind('bindDataSourceControls', this.bindDataSourceControls);
            safeBind('bindQuestionSelectorControls', this.bindQuestionSelectorControls);
            safeBind('bindFormatToggleControls', this.bindFormatToggleControls);
            safeBind('bindAIGeneratorControls', this.bindAIGeneratorControls);
            safeBind('bindBatchControls', this.bindBatchControls);
            safeBind('bindQueueRunnerControls', this.bindQueueRunnerControls);
            safeBind('bindRenderNowControls', this.bindRenderNowControls);
            safeBind('bindTextEffectsControls', this.bindTextEffectsControls);
            safeBind('bindQuestionControls', this.bindQuestionControls);
            safeBind('bindTemplateControls', this.bindTemplateControls);
            safeBind('bindBrandingControls', this.bindBrandingControls);
            safeBind('bindTimingControls', this.bindTimingControls);
            safeBind('bindPreviewControls', this.bindPreviewControls);
            safeBind('bindExportControls', this.bindExportControls);
            safeBind('bindTabControls', this.bindTabControls);
            safeBind('bindCalendarWizardControls', this.bindCalendarWizardControls);
            safeBind('bindContentPlannerControls', this.bindContentPlannerControls);
            safeBind('bindTTSControls', this.bindTTSControls);
            safeBind('bindVoiceoverControls', this.bindVoiceoverControls);
            safeBind('bindAIToolControls', this.bindAIToolControls);
            safeBind('bindSEOControls', this.bindSEOControls);

            if (this.config.isDevelopment) {
                const required = [
                    '#templateGrid',
                    '.mcqvs-audio-suite',
                    '.mcqvs-audio-tabs',
                    '#audio-tab-music',
                    '#previewBtn',
                    '#downloadBtn'
                ];
                const missing = required.filter(sel => !document.querySelector(sel));
                if (missing.length) {
                    console.warn('[MCQVS UI] Markup contract missing:', missing);
                    if (window.MCQVSLogger) window.MCQVSLogger.warn('UI_MARKUP_CONTRACT_WARN', { missing });
                }
            }

            if (Logger) {
                Logger.info('UI_READY', {
                    tabsFound: !!document.querySelector('.mcqvs-audio-tabs'),
                    templateGridFound: !!document.getElementById('templateGrid'),
                    // @MODIFIED 2026-02-04: Check for upload button, not removed file input
                    logoUploadFound: !!document.getElementById('uploadLogoBtn')
                });
            }
        }

	// @NEW 2026-04-24: Video Format Toggle (Shorts/YouTube)
	bindFormatToggleControls() {
		const btns = document.querySelectorAll('.mcqvs-format-btn');
		if (!btns.length) return;

		btns.forEach(btn => {
			btn.addEventListener('click', () => {
				const format = btn.dataset.format;
				if (!format || format === this.state.videoFormat) return;

				btns.forEach(b => b.classList.remove('active'));
				btn.classList.add('active');

				if (this.callbacks.switchFormat) {
					this.callbacks.switchFormat(format);
				}

				this._persistVideoFormat(format);
			});
		});
	}

	_persistVideoFormat(format) {
		const ajaxUrl = this.config.ajaxurl || this.config.ajaxUrl || window.ajaxurl || '';
		const nonce = this.config.nonce || '';
		if (!ajaxUrl || !nonce) {
			if (Logger) Logger.warn('FORMAT_PERSIST_SKIP', { hasUrl: !!ajaxUrl, hasNonce: !!nonce, format });
			return;
		}

		const body = new URLSearchParams();
		body.set('action', 'mcqvs_save_video_format');
		body.set('nonce', nonce);
		body.set('format', format);

		fetch(ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: body.toString()
		}).catch(() => {});
	}

	// @NEW 2026-02-03: Data Source controls (Topic/Exam/Bank)
        bindDataSourceControls() {
            const sourceType = document.getElementById('sourceType');
            const loadBtn = document.getElementById('loadDataBtn');
            const sourceItem = document.getElementById('sourceItem');

            // @MODIFIED 2026-02-06: Robust error handling + loading state for data source dropdown
            if (sourceType) {
                sourceType.addEventListener('change', async () => {
                    const type = this.getSourceType();

                    // Show loading state
                    if (sourceItem) {
                        sourceItem.disabled = true;
                        sourceItem.innerHTML = '<option>Loading...</option>';
                    }

                    try {
                        if (this.callbacks.onLoadSources) {
                            await this.callbacks.onLoadSources(type);
                        }
                    } catch (error) {
                        console.error('[MCQVS] Failed to load sources:', error);
                        if (sourceItem) {
                            sourceItem.innerHTML = '<option value="">Load failed - try again</option>';
                        }
                        this.showNotification(`Failed to load ${type}s: ${error.message}`, 'error');
                    } finally {
                        if (sourceItem) {
                            sourceItem.disabled = false;
                        }
                    }
                });
            }

            if (loadBtn) {
                loadBtn.addEventListener('click', async (e) => {
                    e.preventDefault();

                    const type = this.getSourceType();
                    const id = this.getSourceItemId();

                    if (!id) {
                        this.showNotification('Please select an item to load', 'warning');
                        return;
                    }

                    const originalText = loadBtn.innerText;
                    loadBtn.disabled = true;
                    loadBtn.innerText = 'Loading...';

                    try {
                        if (this.callbacks.onLoadData) {
                            await this.callbacks.onLoadData({ type, id });
                        }
                    } catch (error) {
                        console.error('[MCQVS] Load Data Error:', error);
                        this.showNotification(`Failed to load questions: ${error && error.message ? error.message : 'Unknown error'}`, 'error');
                    } finally {
                        loadBtn.disabled = false;
                        loadBtn.innerText = originalText;
                    }
                });
            }
        }

        getSourceType() {
            const el = document.getElementById('sourceType');
            return (el && el.value) ? String(el.value) : 'topic';
        }

        getSourceItemId() {
            const el = document.getElementById('sourceItem');
            return (el && el.value) ? String(el.value) : '';
        }

        // Render items into #sourceItem
        renderSourceItems(items) {
            const select = document.getElementById('sourceItem');
            if (!select) return;

            const safe = Array.isArray(items) ? items : [];
            if (!safe.length) {
                select.innerHTML = '<option value="">No items found</option>';
                return;
            }

            select.innerHTML = safe
                .map(it => `<option value="${this.escapeHtml(String(it.id ?? ''))}">${this.escapeHtml(String(it.title ?? 'Untitled'))}</option>`)
                .join('');
        }

        // @NEW 2026-02-03: Sidebar Question Selector (drive export selection)
        bindQuestionSelectorControls() {
            // "Select All" toggle in sidebar header
            const toggleAll = document.getElementById('sidebarToggleAll');
            if (toggleAll) {
                toggleAll.addEventListener('change', (e) => {
                    const checked = e.target.checked;
                    this.state.selectedQuestions = checked ? this.state.questions.map((_, i) => i) : [];
                    this.renderQuestionSelectorList();
                    if (this.callbacks.onSelectedQuestionsChange) this.callbacks.onSelectedQuestionsChange();
                });
            }
            // Select Questions card buttons (PHP markup)
            const selectAllBtn = document.getElementById('selectAllQuestionsBtn');
            if (selectAllBtn) {
                selectAllBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    this.state.selectedQuestions = this.state.questions.map((_, i) => i);
                    this.renderQuestionSelectorList();
                    if (this.callbacks.onSelectedQuestionsChange) this.callbacks.onSelectedQuestionsChange();
                });
            }

            const deselectAllBtn = document.getElementById('deselectAllQuestionsBtn');
            if (deselectAllBtn) {
                deselectAllBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    this.state.selectedQuestions = [];
                    this.renderQuestionSelectorList();
                    if (this.callbacks.onSelectedQuestionsChange) this.callbacks.onSelectedQuestionsChange();
                });
            }

            // Delegation for individual checkboxes
            const list = document.getElementById('questionSelectorDropdown') || document.getElementById('sidebarQuestionList');
            if (list) {
                list.addEventListener('change', (e) => {
                    if (e.target.matches('.mcqvs-sidebar-checkbox')) {
                        const idx = parseInt(e.target.value, 10);
                        if (Number.isNaN(idx)) return;

                        const selected = new Set(this.state.selectedQuestions || []);
                        if (e.target.checked) selected.add(idx);
                        else selected.delete(idx);

                        this.state.selectedQuestions = Array.from(selected).sort((a, b) => a - b);

                        // Update count + checkbox states
                        this.renderQuestionSelectorList();

                        if (this.callbacks.onSelectedQuestionsChange) this.callbacks.onSelectedQuestionsChange();
                    }
                });
            }

            // @NEW 2026-02-11: Pagination controls
            const prevBtn = document.getElementById('prevQuestionsBtn');
            const nextBtn = document.getElementById('nextQuestionsBtn');

            if (prevBtn) {
                prevBtn.addEventListener('click', () => {
                    if (this.callbacks.onPrevPage) this.callbacks.onPrevPage();
                });
            }

            if (nextBtn) {
                nextBtn.addEventListener('click', () => {
                    if (this.callbacks.onNextPage) this.callbacks.onNextPage();
                });
            }
        }

        /**
         * Render question selector list with pagination
         * @MODIFIED 2026-02-11: Support paginated view of global questions pool
         */
        renderQuestionSelectorList() {
            const list = document.getElementById('questionSelectorDropdown') || document.getElementById('sidebarQuestionList');
            const container = document.getElementById('questionSelectorSection');
            const pageIndicator = document.getElementById('pageIndicator');
            const prevBtn = document.getElementById('prevQuestionsBtn');
            const nextBtn = document.getElementById('nextQuestionsBtn');

            if (!list) return;

            if (!this.state.questions.length) {
                list.innerHTML = '<div class="mcqvs-empty-state-small">No questions loaded</div>';
                if (container) container.style.display = 'none'; // Hide if empty
                return;
            }

            // Show container if we have questions
            if (container) {
                container.style.display = 'block';
                // Update count helper
                const countDisplay = document.getElementById('questionCountDisplay');
                const selectedCount = (this.state.selectedQuestions || []).length;
                if (countDisplay) countDisplay.textContent = `${selectedCount} selected`;

                // Optional legacy toggle (if present somewhere)
                const toggleAll = document.getElementById('sidebarToggleAll');
                if (toggleAll) {
                    const totalLoaded = this.state.questions.length;
                    toggleAll.checked = selectedCount > 0 && selectedCount === totalLoaded;
                    toggleAll.indeterminate = selectedCount > 0 && selectedCount < totalLoaded;
                }
            }

            // @NEW 2026-02-11: Pagination Logic
            const pageSize = this.state.pageSize || 10;
            const currentPage = this.state.currentPage || 1;
            const startIdx = (currentPage - 1) * pageSize;
            const endIdx = startIdx + pageSize;
            const pageQuestions = this.state.questions.slice(startIdx, endIdx);

            if (pageIndicator) {
                pageIndicator.textContent = `Page ${currentPage} (Showing ${startIdx + 1}-${Math.min(endIdx, this.state.questions.length)})`;
            }

            if (prevBtn) prevBtn.disabled = currentPage <= 1;
            if (nextBtn) {
                // If more items in memory OR we haven't reached end of topic (if we knew total, but for now just based on what's fetched)
                // The controller will decide if fetching more is possible.
                // For now, if current page is full, allow "Next" to trigger a fetch.
                nextBtn.disabled = pageQuestions.length < pageSize && this.state.questions.length <= endIdx;
            }

            const selected = new Set(this.state.selectedQuestions || []);
            list.innerHTML = pageQuestions.map((q, i) => {
                const globalIdx = startIdx + i;
                return `
                <label class="mcqvs-sidebar-item" style="display:flex; align-items:center; gap:8px; padding:4px 0; border-bottom:1px solid #eee;">
                    <input type="checkbox" class="mcqvs-sidebar-checkbox" value="${globalIdx}" ${selected.has(globalIdx) ? 'checked' : ''}>
                    <span class="mcqvs-sidebar-text text-truncate" style="font-size:12px; line-height:1.4;">${globalIdx + 1}. ${this.escapeHtml(q.question)}</span>
                </label>
            `;
            }).join('');
        }

        /**
         * Bind question CRUD controls
         */
        bindQuestionControls() {
            const addBtn = document.getElementById('addQuestionBtn');
            if (addBtn) {
                addBtn.addEventListener('click', () => {
                    if (this.callbacks.onAddQuestion) {
                        this.callbacks.onAddQuestion();
                    }
                });
            }

            const clearBtn = document.getElementById('clearQuestionsBtn');
            if (clearBtn) {
                clearBtn.addEventListener('click', () => {
                    if (confirm('Clear all questions?')) {
                        if (this.callbacks.onClearQuestions) {
                            this.callbacks.onClearQuestions();
                        }
                    }
                });
            }

            // Event delegation for question list
            const list = document.getElementById('questionsList');
            if (list) {
                list.addEventListener('click', (e) => {
                    const btn = e.target.closest('button');
                    if (!btn) return;

                    const item = btn.closest('.mcqvs-question-item');
                    if (!item) return;

                    const index = parseInt(item.dataset.index, 10);

                    if (btn.classList.contains('edit-question-btn')) {
                        if (this.callbacks.onEditQuestion) {
                            this.callbacks.onEditQuestion(index);
                        }
                    } else if (btn.classList.contains('delete-question-btn')) {
                        if (this.callbacks.onDeleteQuestion) {
                            this.callbacks.onDeleteQuestion(index);
                        }
                    }
                });
            }
        }

        /**
         * Bind template controls
         * @MODIFIED 2026-02-03: Support the new #templateGrid + category tabs, keep legacy support if present.
         */
        bindTemplateControls() {
            // NEW UI (current PHP): #templateGrid + .mcqvs-template-tabs
            const grid = document.getElementById('templateGrid');
            if (grid) {
                const tabContainer = document.querySelector('.mcqvs-template-tabs');

                if (tabContainer) {
                    tabContainer.addEventListener('click', (e) => {
                        const btn = e.target.closest('button[data-category]');
                        if (!btn) return;

                        tabContainer.querySelectorAll('button[data-category]').forEach(b => b.classList.remove('active'));
                        btn.classList.add('active');

                        const category = btn.dataset.category || 'all';
                        this.renderTemplateGrid(category);
                    });
                }

                grid.addEventListener('click', (e) => {
                    const card = e.target.closest('.mcqvs-template-card');
                    if (!card) return;

                    const templateId = card.dataset.template;
                    if (!templateId) return;

                    // Update hidden legacy input for compatibility with older code paths
                    const legacyInput = document.getElementById('templateSelect');
                    if (legacyInput) legacyInput.value = templateId;

                    if (this.callbacks.onSelectTemplate) {
                        this.callbacks.onSelectTemplate(templateId);
                    }

                    // Immediate UI feedback
                    grid.querySelectorAll('.mcqvs-template-card').forEach(c => {
                        c.classList.toggle('selected', c.dataset.template === templateId);
                    });
                });

                // Initial paint (deferred slightly to ensure lib is ready)
                this.deferTemplateGridRender('all');

                // @NEW 2026-02-07: Font Selector for manual override
                this.renderFontSelector();
            }
        } // @FIX 2026-02-04: Method properly closed here.

        /**
         * Render Font Selector (Manual Override)
         */
        renderFontSelector() {
            const grid = document.getElementById('templateGrid');
            if (!grid) return;

            const existing = document.getElementById('mcqvs-font-selector-container');
            if (existing) return;

            const container = document.createElement('div');
            container.id = 'mcqvs-font-selector-container';
            container.style.cssText = 'margin-bottom: 20px; padding: 15px; background: rgba(255,255,255,0.03); border-radius: 8px; border: 1px solid rgba(255,255,255,0.1);';

            const label = document.createElement('label');
            label.textContent = 'Override Font:';
            label.style.cssText = 'display:block; margin-bottom: 8px; font-weight: 600; color: #ccc; font-size: 13px;';

            const select = document.createElement('select');
            select.id = 'mcqvs-font-selector';
            select.style.cssText = 'width: 100%; padding: 8px; border-radius: 4px; border: 1px solid #444; background: #222; color: #fff;';

            const fonts = [
                { name: 'Default (Template Style)', value: '' },
                { name: 'Inter', value: 'Inter' },
                { name: 'Outfit', value: 'Outfit' },
                { name: 'Roboto', value: 'Roboto' },
                { name: 'Bangers (Comic)', value: 'Bangers' },
                { name: 'Permanent Marker', value: 'Permanent Marker' },
                { name: 'Orbitron (Sci-Fi)', value: 'Orbitron' },
                { name: 'Press Start 2P (Retro)', value: 'Press Start 2P' },
                { name: 'Creepster (Horror)', value: 'Creepster' },
                { name: 'Cinzel (Cinematic)', value: 'Cinzel' },
                { name: 'Audiowide', value: 'Audiowide' },
                { name: 'Open Sans', value: 'Open Sans' },
                { name: 'Lato', value: 'Lato' },
                { name: 'Playfair Display', value: 'Playfair Display' },
                { name: 'Quicksand', value: 'Quicksand' },
                { name: 'Rajdhani', value: 'Rajdhani' },
                { name: 'Electrolize', value: 'Electrolize' },
                { name: 'Nosifer', value: 'Nosifer' },
                { name: 'Exo 2', value: 'Exo 2' },
                { name: 'VT323', value: 'VT323' },
                { name: 'Share Tech Mono', value: 'Share Tech Mono' },
                { name: 'Patrick Hand', value: 'Patrick Hand' },
                { name: 'EB Garamond', value: 'EB Garamond' },
                { name: 'Fira Code', value: 'Fira Code' },
                { name: 'JetBrains Mono', value: 'JetBrains Mono' },
                { name: 'Bebas Neue', value: 'Bebas Neue' },
                { name: 'Oswald', value: 'Oswald' }
            ];

            fonts.forEach(f => {
                const opt = document.createElement('option');
                opt.value = f.value;
                opt.textContent = f.name;
                select.appendChild(opt);
            });

            // Restore state
            if (this.state.fontOverride) {
                select.value = this.state.fontOverride;
            }

            select.addEventListener('change', (e) => {
                const val = e.target.value;
                this.state.fontOverride = val;

                if (this.callbacks.onFontChange) {
                    this.callbacks.onFontChange(val);
                }
            });

            container.appendChild(label);
            container.appendChild(select);

            // Insert before the grid (or the tabs if present)
            const tabs = document.querySelector('.mcqvs-template-tabs');
            if (tabs) {
                tabs.parentNode.insertBefore(container, tabs.nextSibling);
            } else {
                grid.parentNode.insertBefore(container, grid);
            }
        }

        /**
         * Render template grid
         * @NEW 2026-02-03: Safe rendering (won't crash UI if template lib is missing/mismatched).
         * @MODIFIED 2026-02-04: Promoted to class method to fix nesting issue.
         */
        renderTemplateGrid(category = 'all') {
            const grid = document.getElementById('templateGrid');
            if (!grid) return;

            const lib = window.MCQVSVideoTemplates;
            const hasGetAll = lib && typeof lib.getAll === 'function';

            if (!hasGetAll) {
                if (Logger) Logger.error('TEMPLATE_LIB_MISSING_OR_INVALID', { hasLib: !!lib });
                grid.innerHTML = '<div class="mcqvs-empty-state">Template library not available.</div>';
                return;
            }

            const templates = lib.getAll() || {};
            const current = this.state.currentTemplate || (document.getElementById('templateSelect')?.value) || 'trivia';

            grid.innerHTML = '';

            grid.style.display = 'grid';
            grid.style.gridTemplateColumns = 'repeat(auto-fill, minmax(140px, 1fr))';
            grid.style.gap = '15px';
            grid.style.marginTop = '15px';

            const want = String(category || 'all').toLowerCase();
            let renderedCount = 0;
            Object.entries(templates).forEach(([id, tpl]) => {
                try {
                    const tplCategory = String(tpl?.category || '').toLowerCase();
                    if (want !== 'all' && tplCategory !== want) return;

                    const gradient = (typeof lib.getPreviewGradient === 'function')
                        ? lib.getPreviewGradient(id)
                        : 'linear-gradient(135deg, #333, #111)';

                    const card = document.createElement('div');
                    card.className = `mcqvs-template-card ${id === current ? 'selected' : ''}`;
                    card.dataset.template = id;

                    card.style.background = gradient;
                    card.style.borderRadius = '14px';
                    card.style.padding = '12px';
                    card.style.boxShadow = 'inset 0 0 0 1px rgba(255,255,255,0.12)';

                    const c1 = (tpl?.colors?.primary || '#333').toString();
                    const c2 = (tpl?.colors?.secondary || '#666').toString();
                    const c3 = (tpl?.colors?.accent || '#999').toString();

                    card.innerHTML = `
                    <div class="mcqvs-template-preview" style="
                        display:flex;
                        align-items:center;
                        gap:8px;
                        height:44px;
                        padding:0 12px;
                        border-radius:10px;
                        background: ${this.escapeHtml(gradient)};
                        box-shadow: inset 0 0 0 1px rgba(255,255,255,0.18);
                    ">
                        <span style="width:14px;height:14px;border-radius:999px;background:${c1};box-shadow:0 0 0 1px rgba(0,0,0,0.35)"></span>
                        <span style="width:14px;height:14px;border-radius:999px;background:${c2};box-shadow:0 0 0 1px rgba(0,0,0,0.35)"></span>
                        <span style="width:14px;height:14px;border-radius:999px;background:${c3};box-shadow:0 0 0 1px rgba(0,0,0,0.35)"></span>
                    </div>
                    <div class="mcqvs-template-name" style="margin-top:10px;color:${this.escapeHtml(tpl?.colors?.text || '#fff')};font-weight:600;text-shadow:0 1px 2px rgba(0,0,0,0.18)">
                        ${this.escapeHtml(tpl?.name || id)}
                    </div>
                `;

                    grid.appendChild(card);
                    renderedCount++;
                } catch (err) {
                    if (Logger) Logger.warn('TEMPLATE_CARD_SKIP', { id, error: err.message });
                }
            });

            if (Logger) Logger.debug('TEMPLATE_GRID_RENDERED', { category: want, count: renderedCount });
        }
        /**
         * Defer template grid render until MCQVSVideoTemplates is ready.
         * Fixes “weird/empty grid” caused by timing/race.
         */
        deferTemplateGridRender(category = 'all', attempt = 0) {
            const lib = window.MCQVSVideoTemplates;
            if (lib && typeof lib.getAll === 'function') {
                this.renderTemplateGrid(category);
                return;
            }
            if (attempt >= 40) {
                // Last attempt: render anyway to show the “library missing” state.
                this.renderTemplateGrid(category);
                return;
            }
            setTimeout(() => this.deferTemplateGridRender(category, attempt + 1), 50);
        }

        /**
         * AJAX helper (WordPress admin-ajax.php)
         * @MODIFIED 2026-02-26: Renamed to generic ajaxPost for Queue Runner compatibility.
         */
        async ajaxPost(action, payload = {}) {
            const url = this.config.ajaxurl || this.config.ajaxUrl || window.ajaxurl || '';
            if (!url) throw new Error('Missing AJAX URL');

            const body = new URLSearchParams();
            body.set('action', action);
            body.set('nonce', this.config.nonce || '');

            Object.entries(payload || {}).forEach(([k, v]) => {
                if (v === undefined || v === null) return;
                body.set(k, String(v));
            });

            const res = await fetch(url, {
                method: 'POST',
                credentials: 'same-origin',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                body: body.toString()
            });

            const json = await res.json().catch(() => null);
            if (!json) throw new Error('Invalid server response');
            return json;
        }

        /**
         * Alias for Calendar Wizard backward compatibility
         */
        _wizardAjaxPost(action, payload = {}) {
            return this.ajaxPost(action, payload);
        }

        /**
         * Normalize question shape (UI-side mirror of controller normalizeQuestion)
         */
        normalizeQuestion(q) {
            const out = (q && typeof q === 'object') ? { ...q } : {};

            out.question = String(out.question ?? out.text ?? '').trim() || 'Untitled question';

            const opt = out.options;
            if (Array.isArray(opt)) {
                out.options = [
                    String(opt[0] ?? 'Option A'),
                    String(opt[1] ?? 'Option B'),
                    String(opt[2] ?? 'Option C'),
                    String(opt[3] ?? 'Option D'),
                ];
            } else if (opt && typeof opt === 'object') {
                out.options = [
                    String(opt.a ?? opt.A ?? 'Option A'),
                    String(opt.b ?? opt.B ?? 'Option B'),
                    String(opt.c ?? opt.C ?? 'Option C'),
                    String(opt.d ?? opt.D ?? 'Option D'),
                ];
            } else {
                out.options = ['Option A', 'Option B', 'Option C', 'Option D'];
            }

            let correct = parseInt(out.correct, 10);
            if (Number.isNaN(correct) || correct < 0 || correct > 3) correct = 0;
            out.correct = correct;

            return out;
        }

        /**
         * Apply generated/loaded questions into shared state + refresh UI.
         */
        applyQuestions(questions, meta = {}) {
            const safe = Array.isArray(questions) ? questions.map(q => this.normalizeQuestion(q)) : [];
            this.state.questions = safe;
            this.state.selectedQuestions = safe.map((_, i) => i);

            // Optional metadata
            if (meta && typeof meta.quizName === 'string' && meta.quizName.trim()) {
                this.state.quizName = meta.quizName.trim();
                const el = document.getElementById('quizName');
                if (el) el.value = this.state.quizName;
            }

            // @NEW 2026-08-11: Apply AI-generated question-aware hook + hashtags
            //       (from News/Topic card responses). Only overrides the hook when the
            //       current one is empty or still the generic default, so a user's
            //       hand-written hook is never clobbered.
            if (meta && typeof meta.hook === 'string' && meta.hook.trim()) {
                const current = String(this.state.hookText || '').trim();
                const generic = current === '' || current === 'Can you score 5/5?' || current === 'Can you score 3/3?';
                if (generic) {
                    this.state.hookText = meta.hook.trim();
                    const hookEl = document.getElementById('hookText');
                    if (hookEl) hookEl.value = this.state.hookText;
                }
            }
            if (meta && typeof meta.hashtags === 'string' && meta.hashtags.trim()) {
                this.state.extraHashtags = meta.hashtags.trim();
            }

            // Refresh UI surfaces
            this.renderQuestionsList();
            this.renderQuestionSelectorList();

            // Optional: auto SEO after AI quiz generation
            if (meta && meta.triggerSEO && this.callbacks.onAfterQuizGenerated) {
                try {
                    const r = this.callbacks.onAfterQuizGenerated({
                        topic: this.state.quizName || (meta.quizName || ''),
                        source: meta.source || 'ai'
                    });
                    if (r && typeof r.catch === 'function') r.catch(() => { });
                } catch (_) { }
            }

            if (this.callbacks.onStateChange) this.callbacks.onStateChange();
        }

/**
         * AI generators: News quiz + Topic quiz
         * - Fixes: News Quiz button "does nothing"
         */
        bindAIGeneratorControls() {
            const newsBtn = document.getElementById('generateNewsQuizBtn');
            const newsInput = document.getElementById('newsTopicInput');
            const newsCount = document.getElementById('newsQuestionCount');
            const topicBtn = document.getElementById('generateTopicQuizBtn');
            const topicInput = document.getElementById('topicQuizInput');
            const topicCount = document.getElementById('topicQuestionCount');

            if (!newsBtn && !topicBtn) {
                console.warn('[MCQVS UI] Neither AI generator button found');
                if (Logger) Logger.warn('AI_BUTTONS_MISSING');
                return;
            }

            // News button — bound independently
            if (newsBtn) {
                if (Logger) Logger.info('AI_NEWS_BTN_BOUND');
                const setLoading = (loading) => {
                    newsBtn.disabled = loading;
                    newsBtn.textContent = loading ? 'Generating...' : 'Generate from News';
                };
                newsBtn.addEventListener('click', async () => {
                    const topic = (newsInput && newsInput.value) ? newsInput.value.trim() : '';
                    const raw = (newsCount && newsCount.value) ? parseInt(newsCount.value, 10) : 5;
                    const count = Number.isFinite(raw) ? Math.max(3, Math.min(30, raw)) : 5;

                    if (!topic) {
                        this.showNotification('Enter a news topic first.', 'error');
                        return;
                    }

                    setLoading(true);
                    try {
                        const resp = await this.ajaxPost('mcqvs_generate_news_quiz', { topic, count });
                        if (!resp.success) throw new Error(resp.data?.message || 'Failed to generate news quiz');

                        const qs = resp.data?.questions || [];
                        this.applyQuestions(qs, { quizName: topic, triggerSEO: true, source: 'news', hook: resp.data?.hook, hashtags: resp.data?.hashtags });

                        this.showNotification(`Generated ${qs.length} questions from news`, 'success');
                    } catch (e) {
                        this.showNotification(`News quiz failed: ${e.message}`, 'error');
                    } finally {
                        setLoading(false);
                    }
                });
            }

            // Topic button — bound independently
            if (topicBtn) {
                if (Logger) Logger.info('AI_TOPIC_BTN_BOUND');
                const setLoading = (loading) => {
                    topicBtn.disabled = loading;
                    topicBtn.textContent = loading ? 'Generating...' : 'Generate from Topic';
                };
                topicBtn.addEventListener('click', async () => {
                    const topic = (topicInput && topicInput.value) ? topicInput.value.trim() : '';
                    const raw = (topicCount && topicCount.value) ? parseInt(topicCount.value, 10) : 5;
                    const count = Number.isFinite(raw) ? Math.max(3, Math.min(30, raw)) : 5;
                    if (!topic) {
                        this.showNotification('Enter a topic first.', 'error');
                        return;
                    }

                    setLoading(true);
                    try {
                        const resp = await this.ajaxPost('mcqvs_generate_topic_quiz', { topic, count });
                        if (!resp.success) throw new Error(resp.data?.message || 'Failed to generate topic quiz');

                        const qs = resp.data?.questions || [];
                        this.applyQuestions(qs, { quizName: topic, triggerSEO: true, source: 'topic', hook: resp.data?.hook, hashtags: resp.data?.hashtags });

                        this.showNotification(`Generated ${qs.length} topic questions`, 'success');
                    } catch (e) {
                        this.showNotification(`Topic quiz failed: ${e.message}`, 'error');
                    } finally {
                        setLoading(false);
                    }
                });
            }
        }

        /**
         * Batch Generation (client-side)
         * - Fixes: Batch toggle “does nothing”
         * - Runs exports in chunks of 5 selected questions
         */
        bindBatchControls() {
            const toggle = document.getElementById('batchModeToggle');
            const controls = document.getElementById('batchControls');

            const startBtn = document.getElementById('startBatchBtn');
            const pauseBtn = document.getElementById('pauseBatchBtn');
            const resumeBtn = document.getElementById('resumeBatchBtn');
            const cancelBtn = document.getElementById('cancelBatchBtn');

            const progressEl = document.getElementById('batchProgress');
            const statusEl = document.getElementById('batchStatus');

            this._batch = this._batch || { running: false, paused: false, canceled: false };

            const setStatus = (txt) => { if (statusEl) statusEl.textContent = txt; };
            const setProgress = (pct) => { if (progressEl) progressEl.style.width = `${Math.max(0, Math.min(100, pct))}%`; };

            const show = (el, yes) => { if (el) el.style.display = yes ? '' : 'none'; };

            const sleep = (ms) => new Promise(r => setTimeout(r, ms));

            const waitIfPaused = async () => {
                while (this._batch.paused && !this._batch.canceled) {
                    await sleep(150);
                }
            };

            if (toggle) {
                toggle.addEventListener('change', () => {
                    const on = !!toggle.checked;
                    if (controls) controls.style.display = on ? '' : 'none';

                    // Reset UI state when turning off
                    if (!on) {
                        this._batch.running = false;
                        this._batch.paused = false;
                        this._batch.canceled = false;

                        setProgress(0);
                        setStatus('Ready');

                        show(pauseBtn, false);
                        show(resumeBtn, false);
                        show(cancelBtn, false);
                    }
                });
            }

            if (startBtn) {
                startBtn.addEventListener('click', async () => {
                    if (this._batch.running) return;

                    const selected = (Array.isArray(this.state.selectedQuestions) && this.state.selectedQuestions.length)
                        ? [...this.state.selectedQuestions]
                        : this.state.questions.map((_, i) => i);

                    if (!selected.length) {
                        this.showNotification('Select at least one question for batch.', 'error');
                        return;
                    }

                    if (!window.MCQVS_ExportManager) {
                        this.showNotification('Export module missing (MCQVS_ExportManager).', 'error');
                        return;
                    }

                    const chunkSize = 5;
                    this._batch.running = true;
                    this._batch.paused = false;
                    this._batch.canceled = false;

                    show(pauseBtn, true);
                    show(resumeBtn, false);
                    show(cancelBtn, true);

                    setProgress(0);
                    setStatus(`Starting batch (${selected.length} questions)…`);

                    try {
                        for (let i = 0; i < selected.length; i += chunkSize) {
                            if (this._batch.canceled) break;
                            await waitIfPaused();

                            const chunk = selected.slice(i, i + chunkSize);
                            const done = Math.min(i, selected.length);
                            const pct = Math.round((done / selected.length) * 100);

                            setProgress(pct);
                            setStatus(`Exporting chunk ${Math.floor(i / chunkSize) + 1}… (${done}/${selected.length})`);


                            // @NEW 2026-02-07: Show render progress for current chunk
                            // @MODIFIED 2026-02-23: Also update frame count + ETA (Fix 7)
                            let chunkStartTime = Date.now();
                            const onChunkData = (e) => {
                                const p = e.detail.percent;
                                const frame = e.detail.frame || 0;
                                const total = e.detail.total || 0;
                                setStatus(`Exporting chunk ${Math.floor(i / chunkSize) + 1}… (${done}/${selected.length}) [${p}%]`);

                                // Update frame/ETA detail row
                                const detailEl = document.getElementById('batchProgressDetail');
                                const frameEl = document.getElementById('batchFrameCount');
                                const etaEl = document.getElementById('batchETA');
                                if (detailEl) detailEl.style.display = 'flex';
                                if (frameEl) frameEl.textContent = `Frame: ${frame} / ${total}`;
                                if (etaEl && frame > 0 && total > 0) {
                                    const elapsed = (Date.now() - chunkStartTime) / 1000;
                                    const fps = frame / elapsed;
                                    const remaining = Math.max(0, (total - frame) / fps);
                                    const mins = Math.floor(remaining / 60);
                                    const secs = Math.floor(remaining % 60);
                                    etaEl.textContent = `ETA: ${mins}m ${secs}s`;
                                }
                            };
                            document.addEventListener('mcqvs:export:progress', onChunkData);

                            try {
                                // New exporter instance each chunk to avoid worker reuse edge-cases
                                // @MODIFIED 2026-02-09: Store active exporter for intra-chunk controls
                                this._activeExporter = new window.MCQVS_ExportManager(this.state, this.config);
                                if (this._batch.paused) this._activeExporter.pause(); // Catch race if paused before first chunk

                                // @NEW 2026-02-11: Pass part number (1-based index)
                                const partNum = Math.floor(i / chunkSize) + 1;
                                await this._activeExporter.startExport(chunk, { part: partNum });
                            } finally {
                                document.removeEventListener('mcqvs:export:progress', onChunkData);
                                this._activeExporter = null;
                            }

                            const done2 = Math.min(i + chunkSize, selected.length);
                            setProgress(Math.round((done2 / selected.length) * 100));
                            setStatus(`Completed ${done2}/${selected.length}`);
                        }

                        if (this._batch.canceled) {
                            setStatus('Batch canceled');
                            this.showNotification('Batch canceled.', 'info');
                        } else {
                            setStatus('Batch complete ✅');
                            this.showNotification('Batch complete.', 'success');
                        }
                    } catch (e) {
                        setStatus(`Batch failed: ${e.message}`);
                        this.showNotification(`Batch failed: ${e.message}`, 'error');
                    } finally {
                        this._batch.running = false;
                        show(pauseBtn, false);
                        show(resumeBtn, false);
                        show(cancelBtn, false);
                    }
                });
            }

            if (pauseBtn) {
                pauseBtn.addEventListener('click', () => {
                    if (!this._batch.running) return;
                    this._batch.paused = true;
                    show(pauseBtn, false);
                    show(resumeBtn, true);
                    setStatus('Paused');

                    // @NEW 2026-02-09: Propagate pause to worker
                    if (this._activeExporter) this._activeExporter.pause();
                });
            }

            if (resumeBtn) {
                resumeBtn.addEventListener('click', () => {
                    if (!this._batch.running) return;
                    this._batch.paused = false;
                    show(pauseBtn, true);
                    show(resumeBtn, false);
                    setStatus('Resumed');

                    // @NEW 2026-02-09: Propagate resume to worker
                    if (this._activeExporter) this._activeExporter.resume();
                });
            }

            if (cancelBtn) {
                cancelBtn.addEventListener('click', () => {
                    if (!this._batch.running) return;
                    this._batch.canceled = true;
                    this._batch.paused = false;
                    setStatus('Canceling…');

                    // @NEW 2026-02-09: Force immediate worker stop
                    if (this._activeExporter) this._activeExporter.cancel();

                    // Break the chunk loop if waiting
                    this._batch.running = false;
                });
            }
        }

        /**
         * @NEW 2026-07-04 (F5): "Render on Server" button — spawns Node.js + Playwright +
         *          Chromium headless render for the currently-loaded job (or a freshly
         *          built one). Posts `mcqvs_render_now` to the server, which calls
         *          `VS_Headless_Renderer::render_job()`.
         */
        bindRenderNowControls() {
            const btn = document.getElementById('renderNowBtn');
            const statusEl = document.getElementById('renderNowStatus');
            if (!btn) return;

            const showStatus = (msg, kind) => {
                if (!statusEl) return;
                statusEl.style.display = msg ? '' : 'none';
                statusEl.textContent = msg;
                statusEl.style.padding = '6px 8px';
                statusEl.style.borderRadius = '4px';
                if (kind === 'ok') {
                    statusEl.style.background = '#dcfce7';
                    statusEl.style.color = '#14532d';
                } else if (kind === 'err') {
                    statusEl.style.background = '#fee2e2';
                    statusEl.style.color = '#7f1d1d';
                } else {
                    statusEl.style.background = '#f1f5f9';
                    statusEl.style.color = '#0f172a';
                }
            };

            btn.addEventListener('click', async () => {
                btn.disabled = true;
                showStatus('Spawning server render…', 'pending');

                const questions = Array.isArray(this.state && this.state.questions) ? this.state.questions : [];
                if (!questions.length) {
                    showStatus('Load questions into the Studio first, then click again.', 'err');
                    btn.disabled = false;
                    return;
                }

                try {
                    // 1. Persist the current Studio state as a project + queued job so the
                    //    headless Chromium browser has something to pick up from wp_vs_jobs.
                    const cfg = window.MCQVS_Config || {};
                    const save = await this.ajaxPost('mcqvs_save_project', {
                        project_id: 0,
                        title: (cfg.quizName) || ('Studio Render ' + new Date().toISOString()),
                        template: (this.state && this.state.template) || 'trivia',
                        settings: JSON.stringify(this.state || {}),
                        questions: JSON.stringify(questions.map((q, i) => ({
                            question: q.question || q.question_text || ('Q' + (i + 1)),
                            options: q.options || [],
                            correct: typeof q.correct === 'number' ? q.correct : 0,
                            background: q.background || 'gradient'
                        })))
                    });

                    if (!save || !save.success || !save.data || !save.data.job_id) {
                        showStatus('Save project failed: ' + ((save && save.data) || 'unknown'), 'err');
                        btn.disabled = false;
                        return;
                    }

                    const jobId = save.data.job_id;

                    // 2. Tell the server to spawn the Node headless renderer.
                    const res = await this.ajaxPost('mcqvs_render_now', { job_id: jobId });
                    if (!res || !res.success) {
                        showStatus('Spawn failed: ' + ((res && res.data) || 'unknown'), 'err');
                        btn.disabled = false;
                        return;
                    }

                    showStatus('Render in progress. Job ' + jobId + ' is being processed on the server. Watch the Queue Auto-Runner above or the Logs tab for status.', 'ok');
                    // Mirror into the just-created state so the queue-runner UI sees it.
                    this.state.activeJobId = jobId;
                } catch (e) {
                    showStatus('Error: ' + (e && e.message ? e.message : String(e)), 'err');
                } finally {
                    btn.disabled = false;
                }
            });
        }

        /**
         * @NEW 2026-02-23: Queue Auto-Runner
         * Polls Content Planner jobs and renders them using the full Studio pipeline.
         * Completely separate from the existing Batch Generation controls.
         */
        bindQueueRunnerControls() {
            const toggle = document.getElementById('queueRunnerToggle');
            const controls = document.getElementById('queueRunnerControls');
            const statusEl = document.getElementById('queueRunnerStatus');
            const stopBtn = document.getElementById('stopQueueRunnerBtn');
            const progressContainer = document.getElementById('queueRunnerProgressContainer');
            const progressBar = document.getElementById('queueRunnerProgressBar');
            const progressPercent = document.getElementById('queueRunnerProgressPercent');
            const progressFrames = document.getElementById('queueRunnerProgressFrames');
            const progressETA = document.getElementById('queueRunnerProgressETA');
            const progressLabel = document.getElementById('queueRunnerProgressLabel');
            const jobCountEl = document.getElementById('queueRunnerJobCount');

            if (!toggle) return; // Not on Studio page

            this._queueRunner = {
                running: false,
                currentJobId: null,
                interval: null,
                startTime: null,
                exporter: null
            };

            const setStatus = (txt) => { if (statusEl) statusEl.textContent = 'Status: ' + txt; };
            const showProgress = (show) => { if (progressContainer) progressContainer.style.display = show ? '' : 'none'; };
            const showStop = (show) => { if (stopBtn) stopBtn.style.display = show ? '' : 'none'; };

            const updateProgress = (detail) => {
                if (!this._queueRunner.running) return;
                const percent = detail.percent || 0;
                const frame = detail.frame || 0;
                const total = detail.total || 0;

                if (progressBar) progressBar.style.width = percent + '%';
                if (progressPercent) progressPercent.textContent = percent + '%';
                if (progressFrames) progressFrames.textContent = `Frame: ${frame.toLocaleString()} / ${total.toLocaleString()}`;

                // ETA
                if (this._queueRunner.startTime && frame > 0) {
                    const elapsed = (Date.now() - this._queueRunner.startTime) / 1000;
                    const fps = frame / elapsed;
                    const remaining = total - frame;
                    const etaSec = fps > 0 ? Math.round(remaining / fps) : 0;
                    if (progressETA) {
                        progressETA.textContent = etaSec > 60
                            ? `ETA: ${Math.floor(etaSec / 60)}m ${etaSec % 60}s`
                            : `ETA: ${etaSec}s`;
                    }
                }
            };

            // Listen for export progress globally
            document.addEventListener('mcqvs:export:progress', (e) => updateProgress(e.detail));

            // beforeunload guard
            window.addEventListener('beforeunload', (e) => {
                if (this._queueRunner.running && this._queueRunner.currentJobId) {
                    e.preventDefault();
                    e.returnValue = 'A video is rendering. Closing will abort the export.';
                    return e.returnValue;
                }
            });

            // Restore toggle state
            const savedPref = localStorage.getItem('mcqvs_queue_runner_enabled') === 'true';
            toggle.checked = savedPref;
            if (controls) controls.style.display = savedPref ? '' : 'none';

            // Toggle handler
            toggle.addEventListener('change', () => {
                const on = toggle.checked;
                localStorage.setItem('mcqvs_queue_runner_enabled', on ? 'true' : 'false');
                if (controls) controls.style.display = on ? '' : 'none';

                if (on) {
                    this._queueRunner.running = true;
                    setStatus('Active - Polling...');
                    this.startQueueRunnerLoop();
                } else {
                    this._queueRunner.running = false;
                    if (this._queueRunner.interval) clearInterval(this._queueRunner.interval);
                    this._queueRunner.interval = null;
                    setStatus('Stopped');
                    showProgress(false);
                    showStop(false);
                }
            });

            // Stop button
            if (stopBtn) {
                stopBtn.addEventListener('click', async () => {
                    if (!this._queueRunner.currentJobId) return;

                    if (!confirm('Stop current render? Job will be reset to Ready.')) return;

                    try {
                        if (this._queueRunner.exporter && typeof this._queueRunner.exporter.cancel === 'function') {
                            this._queueRunner.exporter.cancel();
                        }
                        await this.ajaxPost('mcqvs_update_job_status', {
                            job_id: this._queueRunner.currentJobId,
                            status: 'ready_for_render'
                        });
                    } catch (e) {
                        console.error('Stop failed:', e);
                    }

                    this._queueRunner.currentJobId = null;
                    this._queueRunner.exporter = null;
                    showProgress(false);
                    showStop(false);
                    setStatus('Stopped. Job reset to Ready.');
                });
            }

            // Auto-start if pref was true
            if (savedPref) {
                this._queueRunner.running = true;
                setStatus('Restored - Polling...');
                this.startQueueRunnerLoop();
            }
        }

        /**
         * @NEW 2026-02-23: Queue Runner Loop - polls for jobs and renders them
         */
        startQueueRunnerLoop() {
            if (this._queueRunner.interval) clearInterval(this._queueRunner.interval);

            // Check immediately, then every 15s
            this.processNextQueueJob();
            this._queueRunner.interval = setInterval(() => this.processNextQueueJob(), 15000);
        }

        async processNextQueueJob() {
            if (!this._queueRunner.running || this._queueRunner.currentJobId) return;

            const statusEl = document.getElementById('queueRunnerStatus');
            const progressContainer = document.getElementById('queueRunnerProgressContainer');
            const progressBar = document.getElementById('queueRunnerProgressBar');
            const progressPercent = document.getElementById('queueRunnerProgressPercent');
            const progressFrames = document.getElementById('queueRunnerProgressFrames');
            const progressETA = document.getElementById('queueRunnerProgressETA');
            const progressLabel = document.getElementById('queueRunnerProgressLabel');
            const jobCountEl = document.getElementById('queueRunnerJobCount');
            const stopBtn = document.getElementById('stopQueueRunnerBtn');

            const setStatus = (txt) => { if (statusEl) statusEl.textContent = 'Status: ' + txt; };

            try {
                // 1. Poll for next job
                const res = await this.ajaxPost('mcqvs_get_next_pending_job');

                // Update job count
                if (res.success && res.data.jobs) {
                    if (jobCountEl) jobCountEl.textContent = `📋 ${res.data.jobs.length}${res.data.jobs.length >= 5 ? '+' : ''} jobs in queue`;
                }

                if (!res.success || !res.data.job) {
                    setStatus('Idle - Waiting for jobs...');
                    return;
                }

                const job = res.data.job;
                // IMPORTANT: backend expects VS_Job_Repository.job_id (string), NOT the auto-increment `id`
                const jobKey = job && (job.job_id || job.id);
                if (!jobKey) {
                    throw new Error('Invalid job payload (missing job_id)');
                }
                this._queueRunner.currentJobId = jobKey;

                // Parse topic name
                let topicName = 'Job #' + jobKey;
                try {
                    const settings = typeof job.settings === 'string' ? JSON.parse(job.settings) : job.settings;
                    topicName = settings.topic_name || topicName;
                } catch (_) { }

                setStatus(`Processing: ${topicName}...`);
                if (progressLabel) progressLabel.textContent = `Rendering: ${topicName}`;

                // 2. Mark as rendering
                await this.ajaxPost('mcqvs_update_job_status', { job_id: jobKey, status: 'rendering' });

                // 3. Show progress UI
                if (progressBar) progressBar.style.width = '0%';
                if (progressPercent) progressPercent.textContent = '0%';
                if (progressFrames) progressFrames.textContent = 'Frame: 0 / 0';
                if (progressETA) progressETA.textContent = 'ETA: Calculating...';
                if (progressContainer) progressContainer.style.display = '';
                if (stopBtn) stopBtn.style.display = '';
                this._queueRunner.startTime = Date.now();

                // 4. Load quiz data into Studio state
                const quizData = JSON.parse(job.quiz_data || '[]');
                const settings = JSON.parse(job.settings || '{}');

                // ============================================================
                // Apply per-job settings (Template / Font / Music / BG Video)
                // @MODIFIED 2026-03-05: Delegate to centralized applyJobSettings
                // ============================================================
                if (this.callbacks && typeof this.callbacks.applyJobSettings === 'function') {
                    await this.callbacks.applyJobSettings(settings);
                }

                // Normalize questions through the UI's normalizer
                const normalizedQs = quizData.map(q => this.normalizeQuestion(q));
                this.state.questions = normalizedQs;
                this.state.selectedQuestions = normalizedQs.map((_, i) => i);
                if (settings.topic_name) this.state.quizName = settings.topic_name;

                // Update quiz name UI
                const quizNameEl = document.getElementById('quizName');
                if (quizNameEl && settings.topic_name) quizNameEl.value = settings.topic_name;

                // Refresh questions list
                this.renderQuestionsList();
                this.renderQuestionSelectorList();

                // 5. Run export using the full ExportManager
                if (!window.MCQVS_ExportManager) {
                    throw new Error('ExportManager not available');
                }

                const exporter = new window.MCQVS_ExportManager(this.state, this.config);
                this._queueRunner.exporter = exporter;

                const indices = normalizedQs.map((_, i) => i);
                // Support multi-part jobs (if provided); default to 1
                const partNum = parseInt(settings.part_index || settings.part || settings.part_suffix || 1, 10) || 1;

                await exporter.startExport(indices, { part: partNum });

                // 6. Mark complete
                await this.ajaxPost('mcqvs_update_job_status', { job_id: jobKey, status: 'completed' });

                this._queueRunner.currentJobId = null;
                this._queueRunner.exporter = null;
                if (progressContainer) progressContainer.style.display = 'none';
                if (stopBtn) stopBtn.style.display = 'none';
                setStatus('Job Complete ✅ Resting 10s...');

                // Short rest before next job
                await new Promise(r => setTimeout(r, 10000));
                setStatus('Active - Polling...');

            } catch (e) {
                console.error('Queue Runner Error:', e);
                setStatus('Error: ' + e.message);

                if (this._queueRunner.currentJobId) {
                    try {
                        await this.ajaxPost('mcqvs_update_job_status', {
                            job_id: this._queueRunner.currentJobId,
                            status: 'failed',
                            error: e.message
                        });
                    } catch (_) { }
                    this._queueRunner.currentJobId = null;
                }

                this._queueRunner.exporter = null;
                if (progressContainer) progressContainer.style.display = 'none';
                if (stopBtn) stopBtn.style.display = 'none';
            }
        }

        /**
         * Text Effects + Live Preview
         * - Fixes: preview “not working”
         */
        bindTextEffectsControls() {
            const enable = document.getElementById('enableTextEffects');
            const style = document.getElementById('textEffectStyle');
            const showPreview = document.getElementById('showTextEffectPreview');
            const optionsRow = document.getElementById('textEffectsOptions');
            const previewWrap = document.getElementById('textEffectPreviewContainer');

            if (Logger) Logger.info('BIND_TEXT_EFFECTS');

            // Ensure state subtree exists — show preview by default
            this.state.textEffects = this.state.textEffects || { enabled: true, currentStyle: 'classicBold', showPreview: true };

            const syncVisibility = () => {
                const enabled = !!this.state.textEffects.enabled;
                if (optionsRow) optionsRow.style.opacity = enabled ? '1' : '0.5';

                const show = !!this.state.textEffects.showPreview;
                if (previewWrap) previewWrap.style.display = (enabled && show) ? 'block' : 'none';
            };

            if (enable) {
                enable.checked = !!this.state.textEffects.enabled;
                enable.addEventListener('change', () => {
                    this.state.textEffects.enabled = !!enable.checked;
                    syncVisibility();
                    this.renderTextEffectPreview();
                    if (this.callbacks.onStateChange) this.callbacks.onStateChange();
                });
            }

            if (style) {
                style.value = this.state.textEffects.currentStyle || 'classicBold';
                style.addEventListener('change', () => {
                    this.state.textEffects.currentStyle = style.value || 'classicBold';
                    this.renderTextEffectPreview();
                    if (this.callbacks.onStateChange) this.callbacks.onStateChange();
                });
            }

            if (showPreview) {
                showPreview.checked = !!this.state.textEffects.showPreview;
                showPreview.addEventListener('change', () => {
                    this.state.textEffects.showPreview = !!showPreview.checked;
                    syncVisibility();
                    this.renderTextEffectPreview();
                });
            }

            syncVisibility();

            // Defer initial preview render until MCQVS_TextEffects is ready
            this.deferTextEffectPreview();
        }

        deferTextEffectPreview(attempt = 0) {
            if (window.MCQVS_TextEffects && window.MCQVS_TextEffects.presets) {
                this.renderTextEffectPreview();
                return;
            }
            if (attempt >= 60) {
                if (Logger) Logger.warn('TEXT_EFFECTS_LIB_TIMEOUT');
                return;
            }
            setTimeout(() => this.deferTextEffectPreview(attempt + 1), 50);
        }

        renderTextEffectPreview() {
            const previewWrap = document.getElementById('textEffectPreviewContainer');
            const canvas = document.getElementById('textEffectPreviewCanvas');
            if (!previewWrap || previewWrap.style.display === 'none') return;
            if (!canvas) return;

            if (!window.MCQVS_TextEffects || !window.MCQVS_TextEffects.presets) {
                if (Logger) Logger.warn('TEXT_EFFECTS_LIB_MISSING');
                return;
            }

            const ctx = canvas.getContext('2d');
            if (!ctx) return;

            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = '#111';
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            const styleId = (this.state.textEffects && this.state.textEffects.currentStyle) ? this.state.textEffects.currentStyle : 'classicBold';
            const preset = window.MCQVS_TextEffects.presets[styleId] || window.MCQVS_TextEffects.presets.classicBold;

            const style = preset.question || preset.option || preset.hook || { fontSize: 42, fontWeight: '900', fill: '#fff' };

            window.MCQVS_TextEffects.drawStyledText(
                ctx,
                'Preview Text',
                canvas.width / 2,
                canvas.height / 2,
                Object.assign({}, style, { align: 'center', baseline: 'middle', maxWidth: canvas.width - 30 })
            );
        }

        /**
         * Escape HTML helper
         * @MODIFIED 2026-02-04: Promoted to class method (deduplicated).
         */
        escapeHtml(str) {
            const div = document.createElement('div');
            div.textContent = str;
            return div.innerHTML;
        }

        /**
         * Bind branding controls (logo + text fields).
         *
         * @MODIFIED 2026-02-03:
         * - Wire logo upload to WP Media Library button (#uploadLogoBtn) used by PHP markup.
         * - Keep legacy file input support (#brandLogoUpload) if present.
         * - Remove undefined callbacks/methods (onLogoUploadRequest/openMediaFrame/updateLogoPreview).
         * - Keep controller contract: callbacks.onLogoUpload(file), callbacks.onBackgroundUpload(file).
         */
        bindBrandingControls() {
            // Prevent double-binding if initialize() gets called twice (defensive).
            if (this._brandingBound) return;
            this._brandingBound = true;

            const notify = (msg, type = 'info') => {
                if (typeof this.showNotification === 'function') this.showNotification(msg, type);
            };

            const callStateChange = () => {
                if (this.callbacks.onStateChange) this.callbacks.onStateChange();
            };

            const bindText = (id, key) => {
                const el = document.getElementById(id);
                if (!el) return;
                el.addEventListener('input', (e) => {
                    this.state[key] = e.target.value;
                    callStateChange();
                });
            };

            // Text fields (match controller state keys)
            bindText('brandName', 'brandName');
            bindText('quizName', 'quizName');
            bindText('hookText', 'hookText');
            bindText('ctaText', 'ctaText');
            bindText('websiteUrl', 'websiteUrl');


            // CTA Style + Rank System wiring
            // - ctaStyle: subscribe|comment|follow|like|share|link|custom
            // - useRankCta: forces "Comment your score!" and disables custom CTA
            const ctaStyleEl =
                document.getElementById('ctaStyle') ||
                document.getElementById('ctaStyleSelect') ||
                document.querySelector('select[name="ctaStyle"]');

            const ctaTextEl =
                document.getElementById('ctaText') ||
                document.getElementById('ctaTextInput') ||
                document.querySelector('input[name="ctaText"]');

            const rankToggleEl =
                document.getElementById('useRankCta') ||
                document.getElementById('useRankSystemCta') ||
                document.getElementById('useRankSystemCTA') ||
                document.getElementById('rankSystemCtaToggle') ||
                document.querySelector('input[name="useRankSystemCta"]');

            const ctaRow = ctaTextEl
                ? (ctaTextEl.closest('.mcqvs-form-row') || ctaTextEl.closest('.form-field') || ctaTextEl.parentElement)
                : null;

            const syncCtaUi = () => {
                const rankOn = !!(rankToggleEl && rankToggleEl.checked);
                const styleVal = ctaStyleEl ? String(ctaStyleEl.value || '').toLowerCase().trim() : String(this.state.ctaStyle || 'subscribe');

                this.state.ctaStyle = styleVal || 'subscribe';
                this.state.useRankCta = rankOn;

                const isCustom = (this.state.ctaStyle === 'custom') && !rankOn;

                if (ctaRow) ctaRow.style.display = isCustom ? '' : 'none';
                if (ctaTextEl) ctaTextEl.disabled = rankOn || !isCustom;

                // Do not overwrite CTA text when rank is ON
                if (!rankOn) {
                    if (this.state.ctaStyle === 'custom') {
                        if (ctaTextEl) this.state.ctaText = String(ctaTextEl.value || '').trim();
                    } else if (this.state.ctaStyle === 'score') {
                        // @NEW 2026-08-11: dynamic score challenge — controller's
                        //       updateComputedValues() fills in the actual X/X total.
                        this.state.ctaText = 'Comment your score 👇';
                        if (ctaTextEl) ctaTextEl.value = this.state.ctaText;
                    } else if (ctaStyleEl) {
                        const opt = ctaStyleEl.options[ctaStyleEl.selectedIndex];
                        const preset = opt ? String(opt.textContent || '').trim() : '';
                        if (preset) {
                            this.state.ctaText = preset;
                            if (ctaTextEl) ctaTextEl.value = preset;
                        }
                    }
                }

                callStateChange();
            };

            if (ctaStyleEl) ctaStyleEl.addEventListener('change', syncCtaUi);
            if (rankToggleEl) rankToggleEl.addEventListener('change', syncCtaUi);
            if (ctaTextEl) ctaTextEl.addEventListener('input', () => {
                const rankOn = !!(rankToggleEl && rankToggleEl.checked);
                if (!rankOn && (String(this.state.ctaStyle || '').toLowerCase() === 'custom')) {
                    this.state.ctaText = String(ctaTextEl.value || '').trim();
                    callStateChange();
                }
            });

            // Initial sync
            try { syncCtaUi(); } catch (_) { }

            // Hook visibility toggle (visual only)
            const hookVisible = document.getElementById('hookVisibleToggle');
            if (hookVisible) {
                hookVisible.addEventListener('change', (e) => {
                    this.state.hookVisible = !!e.target.checked;
                    callStateChange();
                });
            }

            // --- Logo: read-only preview (upload/position managed in Settings → Assets) ---
            const logoPreview = document.getElementById('logoPreview');
            const logoEmptyMsg = document.getElementById('studioLogoEmptyMsg');
            const hydrateReadonlyLogo = () => {
                const src = (this.state && (this.state.brandLogoUrl || this.state.brandLogoDataUrl || '')).trim();
                if (logoPreview) {
                    if (src) {
                        logoPreview.src = src;
                        logoPreview.style.display = 'block';
                    } else {
                        logoPreview.src = '';
                        logoPreview.style.display = 'none';
                    }
                }
                if (logoEmptyMsg) {
                    logoEmptyMsg.style.display = src ? 'none' : '';
                }
            };
            hydrateReadonlyLogo();



            // --- Background upload (your PHP uses #bgVideoUpload). ---
            const bgInput = document.getElementById('bgVideoUpload');

            if (bgInput) {
                if (bgInput.tagName === 'INPUT' && bgInput.type === 'file') {
                    bgInput.addEventListener('change', (e) => {
                        const file = e.target.files && e.target.files[0];
                        if (!file) return;
                        if (this.callbacks.onBackgroundUpload) this.callbacks.onBackgroundUpload(file);
                        notify('Background selected.', 'success');
                    });
                }
            }

            // @NEW 2026-02-23: BG Video preset picker (Fix 2)
            const bgSelect = document.getElementById('bgVideoSelect');
            const bgPreview = document.getElementById('bgVideoPreview');
            if (bgSelect) {
                // Fetch video list from server
                const cfg = window.MCQVS_Config || {};
                if (cfg.ajaxUrl && cfg.nonce) {
                    const fd = new FormData();
                    fd.append('action', 'mcqvs_list_bg_videos');
                    fd.append('nonce', cfg.nonce);
                    fetch(cfg.ajaxUrl, { method: 'POST', body: fd })
                        .then(r => r.json())
                        .then(res => {
                            if (res.success && res.data.categories) {
                                const cats = res.data.categories;
                                for (const [cat, videos] of Object.entries(cats)) {
                                    const optgroup = document.createElement('optgroup');
                                    optgroup.label = cat;
                                    videos.forEach(v => {
                                        const opt = document.createElement('option');
                                        opt.value = v.url;
                                        const sizeMB = (v.size / (1024 * 1024)).toFixed(1);
                                        opt.textContent = `${v.filename} (${sizeMB} MB)`;
                                        optgroup.appendChild(opt);
                                    });
                                    bgSelect.appendChild(optgroup);
                                }
                            }
                        })
                        .catch(err => console.warn('[MCQVS] Failed to load BG videos:', err));
                }


                // Preview-only browsing. Apply happens on explicit button click.
                let applyBgBtn = document.getElementById('applyBgVideoBtn');
                if (!applyBgBtn) {
                    applyBgBtn = document.createElement('button');
                    applyBgBtn.id = 'applyBgVideoBtn';
                    applyBgBtn.type = 'button';
                    applyBgBtn.className = 'button button-primary';
                    applyBgBtn.style.marginTop = '10px';
                    applyBgBtn.textContent = 'Apply Background Video';
                    bgSelect.parentNode && bgSelect.parentNode.appendChild(applyBgBtn);
                }

                this._pendingBgVideoUrl = this._pendingBgVideoUrl || '';

                bgSelect.addEventListener('change', async () => {
                    const url = String(bgSelect.value || '').trim();
                    this._pendingBgVideoUrl = url;

                    // Preview ONLY (no apply + no toast spam)
                    if (!url) {
                        if (bgPreview) {
                            try { bgPreview.pause(); } catch (_) { }
                            bgPreview.style.display = 'none';
                            bgPreview.src = '';
                        }
                        return;
                    }

                    if (bgPreview) {
                        try { bgPreview.pause(); } catch (_) { }
                        bgPreview.src = url;
                        bgPreview.style.display = 'block';
                        bgPreview.currentTime = 0;
                        bgPreview.play().catch(() => { });
                    }
                });

                applyBgBtn.addEventListener('click', async (e) => {
                    e.preventDefault();
                    const url = String(this._pendingBgVideoUrl || '').trim();
                    if (!url) {
                        notify('Select a background video first.', 'warning');
                        return;
                    }

                    try {
                        notify('Applying background video...', 'info');
                        const resp = await fetch(url, { credentials: 'same-origin' });
                        if (!resp.ok) throw new Error(`Background fetch failed (${resp.status})`);
                        const blob = await resp.blob();
                        const file = new File([blob], 'bg-video.mp4', { type: blob.type || 'video/mp4' });
                        if (this.callbacks.onBackgroundUpload) this.callbacks.onBackgroundUpload(file);

                        // Stop preview after applying
                        if (bgPreview) {
                            try { bgPreview.pause(); } catch (_) { }
                            bgPreview.currentTime = 0;
                        }

                        notify('Background video applied.', 'success');
                    } catch (err) {
                        console.error('[MCQVS] Background apply failed:', err);
                        notify(`Failed to apply background video: ${err.message}`, 'error');
                    }
                });
            }
        }

        /**
         * Bind timing controls
         */
        bindTimingControls() {
            const timingFields = [
                'hookIntro',
                'questionAppear',
                'optionsAppear',
                'userThinkTime',
                'revealAnswer',
                'outroDuration'
            ];

            timingFields.forEach(field => {
                const input = document.getElementById(`timing-${field}`);
                if (input) {
                    input.addEventListener('input', (e) => {
                        const value = parseInt(e.target.value, 10);
                        if (!isNaN(value) && value >= 0) {
                            this.state.timing[field] = value;
                            this.updateTotalDuration();

                            // Keep Selection Questions card in sync (shows/hides automatically)
                            if (typeof this.renderQuestionSelectorList === 'function') {
                                this.renderQuestionSelectorList();
                            }
                            if (this.callbacks.onStateChange) {
                                this.callbacks.onStateChange();
                            }
                        }
                    });
                }
            });
        }

        /**
         * Bind preview controls
         */
        bindPreviewControls() {
            const previewBtn = document.getElementById('previewBtn');
            if (previewBtn) {
                previewBtn.addEventListener('click', () => {
                    if (this.callbacks.onPlay) this.callbacks.onPlay();
                });
            }
        }

        /**
         * Bind export controls
         */
        bindExportControls() {
            const exportBtn = document.getElementById('downloadBtn');
            if (exportBtn) {
                exportBtn.addEventListener('click', () => {
                    if (this.callbacks.onExport) {
                        this.callbacks.onExport();
                    }
                });
            }

            const cancelBtn = document.getElementById('cancelExportBtn');
            if (cancelBtn) {
                cancelBtn.addEventListener('click', () => {
                    if (this.callbacks.onCancelExport) {
                        this.callbacks.onCancelExport();
                    }
                });
            }

            // Select all checkbox
            const selectAll = document.getElementById('selectAllQuestions');
            if (selectAll) {
                selectAll.addEventListener('change', (e) => {
                    const checkboxes = document.querySelectorAll('.export-question-checkbox');
                    checkboxes.forEach(cb => cb.checked = e.target.checked);
                });
            }
        }

        /**
         * Bind tab controls
         * @MODIFIED 2026-02-03: Bind Audio Suite tabs explicitly; scoped to avoid collisions.
         * @MODIFIED 2026-02-04: Strict scoping & ID contract
         */
        bindTabControls() {
            const anyTab = document.querySelector('.mcqvs-audio-tab');
            if (!anyTab) return;

            const suite = anyTab.closest('.mcqvs-audio-suite');
            if (!suite) return;

            const tabsContainer = suite.querySelector('.mcqvs-audio-tabs');
            if (!tabsContainer) return;

            const tabs = tabsContainer.querySelectorAll('.mcqvs-audio-tab');
            const panels = suite.querySelectorAll('.mcqvs-audio-panel');

            if (!tabs.length || !panels.length) {
                if (Logger) Logger.warn('AUDIO_TABS_MISSING', { tabs: tabs.length, panels: panels.length });
                return;
            }

            const activate = (tabName) => {
                tabs.forEach(btn => btn.classList.toggle('active', btn.dataset.tab === tabName));

                panels.forEach(panel => {
                    const isActive = panel.id === `audio-tab-${tabName}`;
                    panel.classList.toggle('active', isActive);
                    panel.style.display = isActive ? 'block' : 'none';
                });

                if (Logger) Logger.debug('AUDIO_TAB_SWITCH', { tab: tabName });
            };

            tabs.forEach(btn => btn.addEventListener('click', () => activate(btn.dataset.tab)));

            const initial = tabsContainer.querySelector('.mcqvs-audio-tab.active')?.dataset.tab || tabs[0].dataset.tab;
            activate(initial);
        }

        /**
         * Update total duration display
         */
        updateTotalDuration() {
            const timing = this.state.timing || {};
            const totalQuestions = Array.isArray(this.state.questions) ? this.state.questions.length : 0;

            // @MODIFIED 2026-02-03: Use selectedQuestions if present (export parity)
            const selectedCount = Array.isArray(this.state.selectedQuestions) && this.state.selectedQuestions.length
                ? this.state.selectedQuestions.length
                : totalQuestions;

            const total =
                (timing.hookIntro || 0) +
                selectedCount * ((timing.questionAppear || 0) + (timing.optionsAppear || 0) + (timing.userThinkTime || 0) + (timing.revealAnswer || 0)) +
                (timing.outroDuration || 0);

            const seconds = Math.round(total / 1000);
            const minutes = Math.floor(seconds / 60);
            const remainingSeconds = seconds % 60;

            const display = document.getElementById('totalDuration');
            if (display) {
                display.textContent = `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
            }
        }

        /**
         * Render questions list
         */
        renderQuestionsList() {
            const list = document.getElementById('questionsList');
            if (!list) return;

            if (this.state.questions.length === 0) {
                list.innerHTML = '<p class="mcqvs-empty-state">No questions added yet. Click "Add Question" to start.</p>';
                return;
            }

            list.innerHTML = '';

            this.state.questions.forEach((q, index) => {
                const item = document.createElement('div');
                item.className = 'mcqvs-question-item';
                item.dataset.index = index;
                item.setAttribute('data-question-index', String(index));

                item.innerHTML = `
                    <div class="mcqvs-question-item-content">
                        <span class="mcqvs-question-number">#${index + 1}</span>
                        <span class="mcqvs-question-text">${this.escapeHtml(q.question)}</span>
                    </div>
                    <div class="mcqvs-question-item-actions">
                        <button class="edit-question-btn" type="button">Edit</button>
                        <button class="delete-question-btn" type="button">Delete</button>
                    </div>
                `;

                list.appendChild(item);
            });

            this.updateTotalDuration();
        }

        /**
         * Render export modal
         */
        renderExportModal() {
            const list = document.getElementById('exportQuestionsList');
            if (!list) return;

            list.innerHTML = '';

            this.state.questions.forEach((q, index) => {
                const item = document.createElement('label');
                item.className = 'mcqvs-export-question-item';

                item.innerHTML = `
                    <input type="checkbox" class="export-question-checkbox" value="${index}" checked>
                    <span>#${index + 1} - ${this.escapeHtml(q.question)}</span>
                `;

                list.appendChild(item);
            });
        }

        /**
         * Update export progress
         */
        updateExportProgress(percent, status) {
            const progressBar = document.getElementById('exportProgressBar');
            if (progressBar) progressBar.style.width = `${percent}%`;

            const percentDisplay = document.getElementById('exportPercentText');
            if (percentDisplay) percentDisplay.textContent = `${percent}%`;

            const statusDisplay = document.getElementById('exportStatusText');
            if (statusDisplay) statusDisplay.textContent = status || 'Processing...';
        }

        /**
         * Show notification
         */
        showNotification(message, type = 'info') {
            if (window.MCQVS_Toast && typeof window.MCQVS_Toast.show === 'function') {
                window.MCQVS_Toast.show(message, type);
                return;
            }

            const container = document.getElementById('mcqvs-notifications');
            if (!container) {
                console.log('[MCQVS]', `[${type.toUpperCase()}]`, message);
                return;
            }

            const notification = document.createElement('div');
            notification.className = `mcqvs-notification mcqvs-notification-${type}`;
            notification.textContent = message;

            container.appendChild(notification);

            setTimeout(() => {
                notification.style.opacity = '0';
                setTimeout(() => notification.remove(), 300);
            }, 3000);

            if (Logger) {
                Logger.debug('UI_NOTIFICATION', { message, type });
            }
        }

        /**
         * Show modal
         */
        showModal(modalId) {
            const modal = document.getElementById(modalId);
            if (modal) {
                modal.classList.add('active');
                document.body.classList.add('mcqvs-modal-open');
            }
        }

        /**
         * Hide modal
         */
        hideModal(modalId) {
            const modal = document.getElementById(modalId);
            if (modal) {
                modal.classList.remove('active');
                document.body.classList.remove('mcqvs-modal-open');
            }
        }

        /**
         * Clean up
         */
        destroy() {
            // @MODIFIED 2026-02-08: Cleanup calendar polling on destroy
            if (this.calendarState && this.calendarState.pollInterval) {
                clearInterval(this.calendarState.pollInterval);
                this.calendarState.pollInterval = null;
            }

            if (Logger) {
                Logger.info('UI_DESTROY');
            }
        }

        // ============================================================
        // @NEW 2026-02-08: HELPER METHODS FOR CALENDAR WIZARD
        // ============================================================

        /**
         * Show notification to user (simple alert for now)
         * @param {string} message - Message to display
         * @param {string} type - 'success', 'error', 'info'
         */
        _wizardShowNotification(message, type = 'info') {
            // (deprecated) kept for backward-compat; do not override main showNotification
            // TODO: Replace with WordPress admin notices or custom toast UI
            const prefix = {
                'success': '✅ ',
                'error': '❌ ',
                'info': 'ℹ️ '
            }[type] || '';

            let msg = message;
            if (typeof msg !== 'string') {
                msg = (msg && msg.message) ? msg.message : JSON.stringify(msg);
            }
            alert(prefix + msg);

            if (Logger) {
                Logger.info('NOTIFICATION_SHOWN', { message, type });
            }
        }

        /**
         * Escape HTML for safe rendering
         * @param {string} text - Text to escape
         * @returns {string} Escaped text
         */
        _wizardEscapeHtml(text) {
            if (!text) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        /**
         * AJAX POST helper
         * @param {string} action - WordPress AJAX action
         * @param {object} payload - Data to send
         * @returns {Promise} Response from server
         */
        async _wizardAjaxPost(action, payload = {}) {
            const url = this.config.ajaxurl || this.config.ajaxUrl || window.ajaxurl || '/wp-admin/admin-ajax.php';
            const nonce = this.config.nonce || '';

            const body = new URLSearchParams();
            body.append('action', action);
            body.append('nonce', nonce);

            // Add all payload properties
            for (const [key, value] of Object.entries(payload)) {
                body.append(key, value);
            }

            try {
                const response = await fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    },
                    body: body
                });

                if (!response.ok) {
                    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                }

                const json = await response.json();

                if (Logger) {
                    Logger.info('AJAX_RESPONSE', { action, success: json.success });
                }

                return json;
            } catch (error) {
                if (Logger) {
                    Logger.error('AJAX_ERROR', { action, error: error.message });
                }
                throw error;
            }
        }

        // ============================================================
        // @NEW 2026-02-08: CALENDAR WIZARD & BULK SCHEDULING
        // ============================================================

        /**
         * Bind Calendar Wizard controls (button + modal)
         */
        bindCalendarWizardControls() {
            console.log('[WIZARD DEBUG] bindCalendarWizardControls called');

            // Inject wizard button + modal on page load
            this.injectCalendarWizardUI();

            console.log('[WIZARD DEBUG] After injectCalendarWizardUI');

            // Bind open button
            const openBtn = document.getElementById('mcqvs-open-calendar-wizard');
            console.log('[WIZARD DEBUG] Open button found:', openBtn);
            if (openBtn) {
                openBtn.addEventListener('click', () => this.openCalendarWizard());
            }

            // Bind modal close
            document.addEventListener('click', (e) => {
                // @FIX 2026-02-08: Use closest() for proper event bubbling
                if (e.target.closest('.mcqvs-modal-close') ||
                    (e.target.id === 'mcqvs-calendar-wizard-modal' && !e.target.closest('.mcqvs-modal-content'))) {
                    this.closeCalendarWizard();
                }
            });

            // Bind wizard navigation
            document.addEventListener('click', (e) => {
                // @FIX 2026-02-16: STRICT check to prevent hijacking other buttons (like the Planner)
                // Only process if the click is INSIDE the wizard modal or involves a wizard control
                const isWizardClick = e.target.closest('#mcqvs-calendar-wizard-modal') || e.target.closest('.mcqvs-wizard-next') || e.target.closest('.mcqvs-wizard-prev') || e.target.closest('.mcqvs-wizard-submit');

                if (!isWizardClick) return;

                console.log('[WIZARD DEBUG] Click detected', {
                    target: e.target,
                    targetClass: e.target.className,
                    closestPrev: e.target.closest('.mcqvs-wizard-prev'),
                    closestNext: e.target.closest('.mcqvs-wizard-next'),
                    closestSubmit: e.target.closest('.mcqvs-wizard-submit')
                });

                // @FIX 2026-02-08: Use closest() instead of matches() to handle clicks on button text
                if (e.target.closest('.mcqvs-wizard-prev')) {
                    console.log('[WIZARD DEBUG] Navigating to previous step');
                    this.navigateWizardStep(-1);
                } else if (e.target.closest('.mcqvs-wizard-next')) {
                    console.log('[WIZARD DEBUG] Navigating to next step');
                    this.navigateWizardStep(1);
                } else if (e.target.closest('.mcqvs-wizard-submit')) {
                    console.log('[WIZARD DEBUG] Submitting bulk schedule');
                    this.submitBulkSchedule();
                }
            });

            // ESC key to close
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') {
                    const modal = document.getElementById('mcqvs-calendar-wizard-modal');
                    if (modal && modal.style.display !== 'none') {
                        this.closeCalendarWizard();
                    }
                }
            });

            // Try to load recent batches from localStorage on init
            this.loadRecentBatches();
        }

        /**
         * Inject Calendar Wizard UI into the page
         */
        injectCalendarWizardUI() {
            // Add button to page header (after h1)
            const header = document.querySelector('.wrap h1');
            if (header && !document.getElementById('mcqvs-open-calendar-wizard')) {
                const btn = document.createElement('button');
                btn.id = 'mcqvs-open-calendar-wizard';
                btn.className = 'button button-primary';
                btn.style.cssText = 'margin-left: 15px; vertical-align: middle;';
                btn.innerHTML = '📅 Schedule Bulk Videos';
                header.appendChild(btn);
            }

            // Add modal HTML
            if (!document.getElementById('mcqvs-calendar-wizard-modal')) {
                const modalHTML = this.getWizardModalHTML();
                document.body.insertAdjacentHTML('beforeend', modalHTML);
            }

            // Add jobs panel placeholder (rendered later when needed)
            if (!document.getElementById('mcqvs-scheduled-jobs-panel')) {
                const wrap = document.querySelector('.wrap');
                if (wrap) {
                    const panelHTML = `<div id="mcqvs-scheduled-jobs-panel" style="display:none; margin-top:30px;"></div>`;
                    wrap.insertAdjacentHTML('beforeend', panelHTML);
                }
            }
        }

        /**
         * Get wizard modal HTML structure
         */
        getWizardModalHTML() {
            return `
            <div id="mcqvs-calendar-wizard-modal" class="mcqvs-modal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.7); z-index:100000; align-items:center; justify-content:center;">
                <div class="mcqvs-modal-content" style="background:#1e1e1e; border-radius:12px; width:90%; max-width:700px; max-height:90vh; overflow-y:auto; box-shadow:0 8px 32px rgba(0,0,0,0.5);">
                    <div class="mcqvs-wizard-header" style="padding:20px 25px; border-bottom:1px solid #333; display:flex; justify-content:space-between; align-items:center;">
                        <h2 style="margin:0; color:#fff; font-size:20px;">📅 Bulk Video Scheduler</h2>
                        <button class="mcqvs-modal-close" style="background:transparent; border:none; color:#999; font-size:28px; cursor:pointer; padding:0; line-height:1;">×</button>
                    </div>

                    <div class="mcqvs-wizard-progress" style="padding:15px 25px; background:#252525; display:flex; gap:10px;">
                        <div class="mcqvs-step-indicator" data-step="1" style="flex:1; text-align:center; padding:8px; background:#333; border-radius:6px; color:#fff; font-size:13px; font-weight:600;">1. Topic</div>
                        <div class="mcqvs-step-indicator" data-step="2" style="flex:1; text-align:center; padding:8px; background:#333; border-radius:6px; color:#666; font-size:13px; font-weight:600;">2. Style</div>
                        <div class="mcqvs-step-indicator" data-step="3" style="flex:1; text-align:center; padding:8px; background:#333; border-radius:6px; color:#666; font-size:13px; font-weight:600;">3. Schedule</div>
                    </div>

                    <div class="mcqvs-wizard-steps" style="padding:25px;">
                        ${this.getWizardStepHTML(1)}
                        ${this.getWizardStepHTML(2)}
                        ${this.getWizardStepHTML(3)}
                    </div>

                    <div class="mcqvs-wizard-footer" style="padding:20px 25px; border-top:1px solid #333; display:flex; justify-content:space-between;">
                        <button class="mcqvs-wizard-prev button" style="display:none;">← Back</button>
                        <div style="flex:1;"></div>
                        <button class="mcqvs-wizard-next button button-primary">Next →</button>
                        <button class="mcqvs-wizard-submit button button-primary" style="display:none;">Schedule Videos</button>
                    </div>
                </div>
            </div>
            `;
        }

        /**
         * Get HTML for a specific wizard step
         */
        getWizardStepHTML(step) {
            const display = step === 1 ? 'block' : 'none';

            if (step === 1) {
                return `
                <div class="mcqvs-step" data-step="1" style="display:${display};">
                    <h3 style="color:#fff; margin-top:0;">Topic & Quantity</h3>
                    <div style="margin-bottom:20px;">
                        <label style="display:block; color:#ccc; margin-bottom:8px; font-weight:600;">Topic *</label>
                        <input type="text" id="wizard-topic" placeholder="e.g., World Geography, Biology Basics" style="width:100%; padding:10px; border-radius:6px; border:1px solid #444; background:#2a2a2a; color:#fff;" required />
                    </div>
                    <div style="display:grid; grid-template-columns:1fr 1fr; gap:15px;">
                        <div>
                            <label style="display:block; color:#ccc; margin-bottom:8px; font-weight:600;">Total Questions</label>
                            <input type="number" id="wizard-total-questions" value="30" min="5" max="100" style="width:100%; padding:10px; border-radius:6px; border:1px solid #444; background:#2a2a2a; color:#fff;" />
                        </div>
                        <div>
                            <label style="display:block; color:#ccc; margin-bottom:8px; font-weight:600;">Questions per Video</label>
                            <input type="number" id="wizard-questions-per-video" value="5" min="1" max="20" style="width:100%; padding:10px; border-radius:6px; border:1px solid #444; background:#2a2a2a; color:#fff;" />
                        </div>
                    </div>
                    <div style="margin-top:15px; padding:12px; background:rgba(59,130,246,0.1); border-left:3px solid #3b82f6; border-radius:4px; color:#93c5fd; font-size:14px;">
                        <strong>Preview:</strong> <span id="wizard-preview-text">Will create 6 videos</span>
                    </div>
                </div>
                `;
            } else if (step === 2) {
                return `
                <div class="mcqvs-step" data-step="2" style="display:${display};">
                    <h3 style="color:#fff; margin-top:0;">Styling (Optional)</h3>
                    <p style="color:#999; font-size:14px; margin-top:0;">Select a template, background, and music for all videos in this batch.</p>
                    <div style="margin-bottom:20px;">
                        <label style="display:block; color:#ccc; margin-bottom:8px; font-weight:600;">Template</label>
                        <select id="wizard-template" style="width:100%; padding:10px; border-radius:6px; border:1px solid #444; background:#2a2a2a; color:#fff;">
                            <option value="">Use current template</option>
                        </select>
                    </div>
                    <div style="margin-bottom:20px;">
                        <label style="display:block; color:#ccc; margin-bottom:8px; font-weight:600;">Background</label>
                        <select id="wizard-background" style="width:100%; padding:10px; border-radius:6px; border:1px solid #444; background:#2a2a2a; color:#fff;">
                            <option value="gradient">Gradient (default)</option>
                            <option value="">Use current background</option>
                        </select>
                    </div>
                    <div>
                        <label style="display:block; color:#ccc; margin-bottom:8px; font-weight:600;">Music</label>
                        <select id="wizard-music" style="width:100%; padding:10px; border-radius:6px; border:1px solid #444; background:#2a2a2a; color:#fff;">
                            <option value="">Use current music</option>
                        </select>
                    </div>
                </div>
                `;
            } else if (step === 3) {
                const tomorrow = new Date();
                tomorrow.setDate(tomorrow.getDate() + 1);
                const dateStr = tomorrow.toISOString().split('T')[0];

                return `
                <div class="mcqvs-step" data-step="3" style="display:${display};">
                    <h3 style="color:#fff; margin-top:0;">Schedule</h3>
                    <div style="margin-bottom:20px;">
                        <label style="display:block; color:#ccc; margin-bottom:8px; font-weight:600;">Start Date</label>
                        <input type="date" id="wizard-start-date" value="${dateStr}" style="width:100%; padding:10px; border-radius:6px; border:1px solid #444; background:#2a2a2a; color:#fff;" />
                    </div>
                    <div style="margin-bottom:20px;">
                        <label style="display:block; color:#ccc; margin-bottom:8px; font-weight:600;">Frequency</label>
                        <select id="wizard-frequency" style="width:100%; padding:10px; border-radius:6px; border:1px solid #444; background:#2a2a2a; color:#fff;">
                            <option value="daily">Daily</option>
                            <option value="every_3_days">Every 3 Days</option>
                            <option value="weekly">Weekly</option>
                            <option value="twice_weekly">Twice Weekly</option>
                        </select>
                    </div>
                    <div>
                        <label style="display:block; color:#ccc; margin-bottom:8px; font-weight:600;">Platform</label>
                        <select id="wizard-platform" style="width:100%; padding:10px; border-radius:6px; border:1px solid #444; background:#2a2a2a; color:#fff;">
                            <option value="all">All Platforms</option>
                            <option value="youtube">YouTube</option>
                            <option value="tiktok">TikTok</option>
                            <option value="instagram">Instagram</option>
                        </select>
                    </div>
                </div>
                `;
            }

            return '';
        }

        /**
         * Open the calendar wizard modal
         */
        openCalendarWizard() {
            console.log('[WIZARD DEBUG] openCalendarWizard called');
            const modal = document.getElementById('mcqvs-calendar-wizard-modal');
            console.log('[WIZARD DEBUG] Modal element:', modal);
            if (!modal) {
                console.error('[WIZARD DEBUG] Modal not found in DOM!');
                return;
            }

            // Reset to step 1
            this.calendarState.currentStep = 1;
            this.calendarState.wizardData = {};
            console.log('[WIZARD DEBUG] Reset to step 1');

            // Populate template dropdown from state
            this.populateWizardTemplateDropdown();

            // Show modal
            console.log('[WIZARD DEBUG] Setting modal display to flex');
            modal.style.display = 'flex';
            console.log('[WIZARD DEBUG] Modal display is now:', modal.style.display);
            this.updateWizardUI();

            // Auto-update preview on input change
            const totalInput = document.getElementById('wizard-total-questions');
            const perVideoInput = document.getElementById('wizard-questions-per-video');
            console.log('[WIZARD DEBUG] Input elements found:', { totalInput, perVideoInput });

            const updatePreview = () => {
                const total = parseInt(totalInput?.value || 30, 10);
                const perVideo = parseInt(perVideoInput?.value || 5, 10);
                const numVideos = Math.ceil(total / perVideo);
                const preview = document.getElementById('wizard-preview-text');
                if (preview) {
                    preview.textContent = `Will create ${numVideos} video${numVideos !== 1 ? 's' : ''}`;
                }
            };
            if (totalInput) totalInput.addEventListener('input', updatePreview);
            if (perVideoInput) perVideoInput.addEventListener('input', updatePreview);

            console.log('[WIZARD DEBUG] Modal should be visible now');
            if (Logger) Logger.info('CALENDAR_WIZARD_OPENED');
        }

        /**
         * Close the calendar wizard modal
         */
        closeCalendarWizard() {
            const modal = document.getElementById('mcqvs-calendar-wizard-modal');
            if (modal) modal.style.display = 'none';

            if (Logger) Logger.info('CALENDAR_WIZARD_CLOSED');
        }

        /**
         * Navigate wizard steps
         */
        navigateWizardStep(direction) {
            console.log('[WIZARD DEBUG] navigateWizardStep called', {
                direction,
                currentStep: this.calendarState.currentStep,
                newStep: this.calendarState.currentStep + direction
            });

            const newStep = this.calendarState.currentStep + direction;

            // Validate step 1 before proceeding
            if (this.calendarState.currentStep === 1 && direction > 0) {
                const topic = document.getElementById('wizard-topic')?.value.trim();
                console.log('[WIZARD DEBUG] Validating topic:', topic);
                if (!topic) {
                    console.log('[WIZARD DEBUG] Topic validation failed, showing notification');
                    this.showNotification('Please enter a topic.', 'error');
                    return;
                }
            }

            if (newStep < 1 || newStep > 3) {
                console.log('[WIZARD DEBUG] Invalid step range, returning');
                return;
            }

            this.calendarState.currentStep = newStep;
            console.log('[WIZARD DEBUG] Calling updateWizardUI with step:', newStep);
            this.updateWizardUI();
        }

        /**
         * Update wizard UI based on current step
         */
        updateWizardUI() {
            const step = this.calendarState.currentStep;

            // Update step indicators
            document.querySelectorAll('.mcqvs-step-indicator').forEach((el, i) => {
                const stepNum = i + 1;
                if (stepNum < step) {
                    el.style.background = '#10b981';
                    el.style.color = '#fff';
                } else if (stepNum === step) {
                    el.style.background = '#3b82f6';
                    el.style.color = '#fff';
                } else {
                    el.style.background = '#333';
                    el.style.color = '#666';
                }
            });

            // Show/hide steps
            document.querySelectorAll('.mcqvs-step').forEach(el => {
                el.style.display = el.dataset.step === String(step) ? 'block' : 'none';
            });

            // Update footer buttons
            const prevBtn = document.querySelector('.mcqvs-wizard-prev');
            const nextBtn = document.querySelector('.mcqvs-wizard-next');
            const submitBtn = document.querySelector('.mcqvs-wizard-submit');

            if (prevBtn) prevBtn.style.display = step > 1 ? '' : 'none';
            if (nextBtn) nextBtn.style.display = step < 3 ? '' : 'none';
            if (submitBtn) submitBtn.style.display = step === 3 ? '' : 'none';
        }

        /**
         * Populate template dropdown from current state
         */
        populateWizardTemplateDropdown() {
            const select = document.getElementById('wizard-template');
            if (!select) return;

            const lib = window.MCQVSVideoTemplates;
            if (lib && typeof lib.getAll === 'function') {
                const templates = lib.getAll();
                Object.entries(templates).forEach(([id, tpl]) => {
                    const option = document.createElement('option');
                    option.value = id;
                    option.textContent = tpl?.name || id;
                    select.appendChild(option);
                });
            }
        }

        /**
         * Submit bulk schedule request
         */
        async submitBulkSchedule() {
            const submitBtn = document.querySelector('.mcqvs-wizard-submit');
            if (!submitBtn) return;

            // Collect all form data
            const topic = document.getElementById('wizard-topic')?.value.trim();
            const totalQuestions = parseInt(document.getElementById('wizard-total-questions')?.value || 30, 10);
            const questionsPerVideo = parseInt(document.getElementById('wizard-questions-per-video')?.value || 5, 10);
            const template = document.getElementById('wizard-template')?.value || '';
            const background = document.getElementById('wizard-background')?.value || 'gradient';
            const music = document.getElementById('wizard-music')?.value || '';
            const startDate = document.getElementById('wizard-start-date')?.value || '';
            const frequency = document.getElementById('wizard-frequency')?.value || 'daily';
            const platform = document.getElementById('wizard-platform')?.value || 'all';

            // Validation
            if (!topic) {
                this.showNotification('Topic is required.', 'error');
                return;
            }

            if (totalQuestions < 5 || questionsPerVideo < 1) {
                this.showNotification('Invalid question counts.', 'error');
                return;
            }

            // Disable submit while processing
            submitBtn.disabled = true;
            submitBtn.textContent = 'Scheduling...';

            try {
                const settings = {
                    template: template || this.state.currentTemplate || 'trivia',
                    background: background,
                    music: music,
                    platform: platform
                };

                const response = await this.ajaxPost('mcqvs_bulk_schedule', {
                    topic: topic,
                    total_questions: totalQuestions,
                    questions_per_video: questionsPerVideo,
                    start_date: startDate,
                    frequency: frequency,
                    settings: JSON.stringify(settings)
                });

                console.log('[WIZARD DEBUG] AJAX response:', response);

                if (!response.success) {
                    console.error('[WIZARD DEBUG] Backend returned error:', response);
                    throw new Error(response.data?.message || 'Failed to schedule batch');
                }

                const batchId = response.data?.batch_id;
                console.log('[WIZARD DEBUG] Batch scheduled successfully:', batchId);
                this.showNotification(`✅ Batch scheduled! ID: ${batchId}`, 'success');

                // Add to recent batches
                this.addRecentBatch({
                    id: batchId,
                    topic: topic,
                    status: 'scheduled',
                    created_at: new Date().toISOString(),
                    total_questions: totalQuestions,
                    videos_count: Math.ceil(totalQuestions / questionsPerVideo)
                });

                // Close modal and show jobs panel
                this.closeCalendarWizard();
                this.renderScheduledJobsPanel();
                this.startBatchPolling();

                if (Logger) Logger.info('BULK_SCHEDULE_SUCCESS', { batch_id: batchId });
            } catch (error) {
                this.showNotification(`Failed: ${error.message}`, 'error');
                if (Logger) Logger.error('BULK_SCHEDULE_ERROR', { error: error.message });
            } finally {
                submitBtn.disabled = false;
                submitBtn.textContent = 'Schedule Videos';
            }
        }

        /**
         * Add a batch to recent batches list
         */
        addRecentBatch(batch) {
            this.calendarState.batches = this.calendarState.batches || [];

            // Remove if already exists (update)
            this.calendarState.batches = this.calendarState.batches.filter(b => b.id !== batch.id);

            // Add to top
            this.calendarState.batches.unshift(batch);

            // Keep only last 10
            this.calendarState.batches = this.calendarState.batches.slice(0, 10);

            // Persist to localStorage
            this.saveRecentBatches();
        }

        /**
         * Save batches to localStorage
         */
        saveRecentBatches() {
            try {
                localStorage.setItem('mcqvs_recent_batches', JSON.stringify(this.calendarState.batches));
            } catch (e) {
                // Ignore localStorage errors
            }
        }

        /**
         * Load batches from localStorage
         */
        loadRecentBatches() {
            try {
                const saved = localStorage.getItem('mcqvs_recent_batches');
                if (saved) {
                    this.calendarState.batches = JSON.parse(saved);
                    if (this.calendarState.batches.length > 0) {
                        // Render panel if we have batches
                        this.renderScheduledJobsPanel();
                        this.startBatchPolling();
                    }
                }
            } catch (e) {
                // Ignore localStorage errors
            }

            // Bind batch card clicks for auto-loading
            document.addEventListener('click', (e) => {
                const card = e.target.closest('.mcqvs-batch-card');
                if (card) {
                    const topicId = card.dataset.topicId;
                    const sourceType = card.dataset.sourceType;

                    if (topicId && sourceType) {
                        // 1. Set Dropdown Values
                        const typeSelect = document.getElementById('sourceType');
                        const itemSelect = document.getElementById('sourceItem');

                        if (typeSelect) {
                            typeSelect.value = sourceType;
                            // Trigger change to reload items (if needed) or manual load
                            // But we have the ID, so we can just set it if options exist
                            // Better: Trigger the Load flow directly
                        }

                        // 2. Load Data
                        if (window.studioController) {
                            console.log('[STUDIO] Auto-loading batch topic:', topicId);
                            // Visual feedback
                            card.style.borderColor = '#6366f1';

                            // Call load method directly if available, or simulate click
                            // We need to set the internal state or inputs
                            if (itemSelect) {
                                // We might need to refresh the source list first if it's not loaded
                                // For now, let's try to load directly using studioController
                                this.loadBatchIntoStudio(topicId, sourceType);
                            }
                        }
                    }
                }
            });
        }

        /**
         * Load batch data into studio (Bridge)
         */
        async loadBatchIntoStudio(id, type) {
            // Dispatch event for Controller to handle
            // Or if we have access to controller instance
            const loadBtn = document.getElementById('loadDataBtn');
            const typeSelect = document.getElementById('sourceType');
            const itemSelect = document.getElementById('sourceItem');

            if (typeSelect && itemSelect && loadBtn) {
                typeSelect.value = type;

                // We need to trigger source refresh, THEN select item, THEN click load
                // This is complex to coordinate DOM events. 
                // Easier: Let's assume the controller exposes a method or we listen for 'sourcesLoaded'

                // Step 1: Trigger Source Change
                typeSelect.dispatchEvent(new Event('change'));

                // Step 2: Wait for populate (hacky but functional)
                setTimeout(() => {
                    itemSelect.value = id;
                    if (itemSelect.value == id) {
                        loadBtn.click();
                        // Scroll to studio
                        document.getElementById('mcqvs-video-studio-app')?.scrollIntoView({ behavior: 'smooth' });
                    } else {
                        // Fallback if ID not in list (e.g. pagination or delay)
                        console.warn('Topic ID not found in list after refresh');
                    }
                }, 1500);
            }
        }

        /**
         * Render the scheduled jobs panel
         */
        renderScheduledJobsPanel() {
            const panel = document.getElementById('mcqvs-scheduled-jobs-panel');
            if (!panel) return;

            const batches = this.calendarState.batches || [];

            if (batches.length === 0) {
                panel.style.display = 'none';
                return;
            }

            panel.style.display = 'block';
            panel.innerHTML = `
                <div style="background:#1e1e1e; border-radius:12px; padding:20px; border:1px solid #333;">
                    <h3 style="margin:0 0 20px 0; color:#fff; display:flex; align-items:center; gap:10px;">
                        <span>📋 Scheduled Jobs</span>
                        <span style="font-size:14px; color:#666; font-weight:normal;">(${batches.length})</span>
                    </h3>
                    <div id="mcqvs-jobs-list" style="display:flex; flex-direction:column; gap:12px;">
                        ${batches.map(batch => this.getBatchCardHTML(batch)).join('')}
                    </div>
                </div>
            `;
        }

        /**
         * Get HTML for a single batch card
         */
        getBatchCardHTML(batch) {
            const statusEmoji = {
                'scheduled': '📅',
                'processing': '⏳',
                'completed': '✅',
                'failed': '⚠️'
            }[batch.status] || '❓';

            const statusColor = {
                'scheduled': '#6366f1',
                'processing': '#8b5cf6',
                'completed': '#10b981',
                'failed': '#ef4444'
            }[batch.status] || '#666';

            const timeAgo = this.getTimeAgo(batch.created_at);

            return `
                <div class="mcqvs-batch-card" 
                     data-batch-id="${this.escapeHtml(batch.id)}" 
                     data-topic-id="${batch.topic_id || ''}"
                     data-source-type="bank_topic"
                     style="background:#252525; border-radius:8px; padding:15px; border:1px solid #333; cursor:pointer; transition:all 0.2s;">
                    <div style="display:flex; justify-content:space-between; align-items:start;">
                        <div style="flex:1;">
                            <div style="display:flex; align-items:center; gap:10px; margin-bottom:8px;">
                                <span style="font-size:20px;">${statusEmoji}</span>
                                <strong style="color:#fff; font-size:15px;">${this.escapeHtml(batch.topic)}</strong>
                                <span style="padding:2px 8px; background:${statusColor}; color:#fff; border-radius:4px; font-size:11px; font-weight:600; text-transform:uppercase;">${batch.status}</span>
                            </div>
                            <div style="color:#999; font-size:13px;">
                                ${batch.videos_count || 0} video${(batch.videos_count || 0) !== 1 ? 's' : ''} • ${batch.total_questions || 0} questions • ${timeAgo}
                            </div>
                            <div style="color:#666; font-size:12px; margin-top:4px; font-family:monospace;">
                                ${this.escapeHtml(batch.id)}
                            </div>
                        </div>
                    </div>
                </div>
            `;
        }

        /**
         * Get time ago string
         */
        getTimeAgo(dateStr) {
            if (!dateStr) return 'Unknown time';
            try {
                const date = new Date(dateStr);
                const now = new Date();
                const diff = Math.floor((now - date) / 1000); // seconds

                if (diff < 60) return 'Just now';
                if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
                if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
                return `${Math.floor(diff / 86400)}d ago`;
            } catch (e) {
                return 'Unknown time';
            }
        }

        /**
         * Start polling batch status
         */
        startBatchPolling() {
            // Clear existing interval
            if (this.calendarState.pollInterval) {
                clearInterval(this.calendarState.pollInterval);
            }

            // Poll every 10 seconds
            this.calendarState.pollInterval = setInterval(() => {
                this.pollBatchStatus();
            }, 10000);

            // Also poll immediately
            this.pollBatchStatus();
        }

        /**
         * Poll batch status for all active batches
         */
        async pollBatchStatus() {
            const batches = this.calendarState.batches || [];
            const activeBatches = batches.filter(b =>
                b.status === 'scheduled' || b.status === 'processing'
            );

            if (activeBatches.length === 0) {
                // No active batches, stop polling
                if (this.calendarState.pollInterval) {
                    clearInterval(this.calendarState.pollInterval);
                    this.calendarState.pollInterval = null;
                }
                return;
            }

            // Poll each active batch
            for (const batch of activeBatches) {
                try {
                    const response = await this.ajaxPost('mcqvs_get_batch_status', {
                        batch_id: batch.id
                    });

                    if (response.success && response.data?.batch) {
                        const updated = response.data.batch;

                        // Update batch in state
                        const index = this.calendarState.batches.findIndex(b => b.id === batch.id);
                        if (index !== -1) {
                            this.calendarState.batches[index].status = updated.status || batch.status;

                            // Add job IDs if completed
                            if (updated.job_ids) {
                                this.calendarState.batches[index].job_ids = updated.job_ids;
                            }
                        }
                    }
                } catch (error) {
                    if (Logger) Logger.error('BATCH_POLL_ERROR', { batch_id: batch.id, error: error.message });
                }
            }

            // Re-render panel with updated statuses
            this.saveRecentBatches();
            this.renderScheduledJobsPanel();
        }

        // @NEW 2026-02-16: Content Planner Controls
        bindContentPlannerControls() {
            const planBtn = document.getElementById('plan30DaysBtn');
            const autoProcessToggle = document.getElementById('autoProcessToggle');

            if (planBtn) {
                planBtn.addEventListener('click', () => {
                    if (this.callbacks.onPlanContent) this.callbacks.onPlanContent();
                });
            }

            const generatePlanBtn = document.getElementById('generatePlanBtn');
            if (generatePlanBtn) {
                generatePlanBtn.addEventListener('click', () => {
                    const niche = document.getElementById('plannerNiche')?.value;
                    if (!niche) {
                        this.showNotification('Please enter a niche', 'error');
                        return;
                    }
                    if (this.callbacks.onGeneratePlan) this.callbacks.onGeneratePlan(niche);
                });
            }

            const approvePlanBtn = document.getElementById('approvePlanBtn');
            if (approvePlanBtn) {
                approvePlanBtn.addEventListener('click', () => {
                    const json = document.getElementById('plannerTopicsJson')?.value;
                    try {
                        const topics = JSON.parse(json);
                        if (this.callbacks.onApprovePlan) this.callbacks.onApprovePlan(topics);
                    } catch (e) {
                        this.showNotification('Invalid JSON format', 'error');
                    }
                });
            }

            if (autoProcessToggle) {
                autoProcessToggle.addEventListener('change', (e) => {
                    if (this.callbacks.onAutoProcessToggle) {
                        this.callbacks.onAutoProcessToggle(e.target.checked);
                    }
                });
            }
        }
        /**
         * @MODIFIED 2026-02-25: AI & Tools Sidebar Bindings (No SEO button)
         * - Generate Quiz: uses News/Topic card inputs
         * - AI Background: generates & applies a safe same-origin background
         * - Export/Import JSON + Capture Thumbnail
         */
        bindAIToolControls() {
            const quizBtn = document.getElementById('generateQuizBtn');
            const bgBtn = document.getElementById('generateBackgroundBtn');
            const exportBtn = document.getElementById('exportJsonBtn');
            const importInput = document.getElementById('importJsonInput');
            const thumbBtn = document.getElementById('captureThumbnailBtn');

            const runOnce = async (btn, fn) => {
                if (!btn) return;
                if (btn.dataset && btn.dataset.busy === '1') return;
                if (btn.dataset) btn.dataset.busy = '1';
                btn.disabled = true;
                try {
                    await fn();
                } finally {
                    btn.disabled = false;
                    if (btn.dataset) delete btn.dataset.busy;
                }
            };

            if (quizBtn) {
                quizBtn.addEventListener('click', () => runOnce(quizBtn, async () => {
                    if (this.callbacks.onGenerateAIQuiz) await this.callbacks.onGenerateAIQuiz();
                }));
            }

            if (bgBtn) {
                bgBtn.addEventListener('click', () => runOnce(bgBtn, async () => {
                    if (this.callbacks.onGenerateBackground) await this.callbacks.onGenerateBackground();
                }));
            }

            if (exportBtn) {
                exportBtn.addEventListener('click', () => {
                    try {
                        const snapshot = (this.callbacks.onExportProject) ? this.callbacks.onExportProject() : { state: this.state };
                        const blob = new Blob([JSON.stringify(snapshot, null, 2)], { type: 'application/json' });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        const base = (this.state.quizName || 'mcqvs-project').replace(/[^a-z0-9\-_]+/gi, '-').toLowerCase();
                        a.href = url;
                        a.download = `${base}.json`;
                        document.body.appendChild(a);
                        a.click();
                        a.remove();
                        URL.revokeObjectURL(url);
                        this.showNotification('Project exported', 'success');
                    } catch (e) {
                        this.showNotification('Export failed: ' + (e && e.message ? e.message : 'Unknown error'), 'error');
                    }
                });
            }

            if (importInput) {
                importInput.addEventListener('change', async (e) => {
                    const file = e.target.files && e.target.files[0];
                    if (!file) return;
                    try {
                        const txt = await file.text();
                        const data = JSON.parse(txt);
                        if (this.callbacks.onImportProject) {
                            await this.callbacks.onImportProject(data);
                        } else {
                            // fallback: questions only
                            if (data && data.questions) this.applyQuestions(data.questions, { quizName: data.quizName || '' });
                        }
                        this.showNotification('Project imported', 'success');
                    } catch (err) {
                        this.showNotification('Import failed: ' + (err && err.message ? err.message : 'Invalid file'), 'error');
                    } finally {
                        try { importInput.value = ''; } catch (_) { }
                    }
                });
            }

            if (thumbBtn) {
                thumbBtn.addEventListener('click', async () => {
                    try {
                        if (this.callbacks.onCaptureThumbnail) {
                            const dataUrl = await this.callbacks.onCaptureThumbnail();
                            if (!dataUrl) throw new Error('No thumbnail');
                            const a = document.createElement('a');
                            const base = (this.state.quizName || 'mcqvs-thumb').replace(/[^a-z0-9\-_]+/gi, '-').toLowerCase();
                            a.href = dataUrl;
                            a.download = `${base}.png`;
                            document.body.appendChild(a);
                            a.click();
                            a.remove();
                            this.showNotification('Thumbnail captured', 'success');
                        } else {
                            this.showNotification('Thumbnail capture not available', 'error');
                        }
                    } catch (e) {
                        this.showNotification('Thumbnail failed: ' + (e && e.message ? e.message : 'Unknown error'), 'error');
                    }
                });
            }
        }

        /**
         * @NEW 2026-02-25: SEO card bindings (High-Performer)
         */
        bindSEOControls() {
            const genBtn = document.getElementById('generateSEOBtn');
            const keywords = document.getElementById('seoKeywords');
            const autoToggle = document.getElementById('seoAutoGenerate');

            const results = document.getElementById('seoResults');
            const titleEl = document.getElementById('seoTitle');
            const descEl = document.getElementById('seoDescription');
            const tagsEl = document.getElementById('seoTags');

            const copyBtn = document.getElementById('copySEOBtn');
            const applyBtn = document.getElementById('applyToExportBtn');

            const setResults = (data) => {
                if (!data) return;
                const t = String(data.title || '').trim();
                const d = String(data.description || '').trim();
                const tags = Array.isArray(data.tags) ? data.tags : (typeof data.tags === 'string' ? data.tags.split(/\s*,\s*/).filter(Boolean) : []);

                if (titleEl) titleEl.value = t;
                if (descEl) descEl.value = d;
                if (tagsEl) tagsEl.value = tags.join(' ');

                this.state.seoMeta = { title: t, description: d, tags: tags };
                this.state.seoKeywords = keywords ? String(keywords.value || '').trim() : (this.state.seoKeywords || '');

                if (results) results.style.display = '';
            };

            const runOnce = async (btn, fn) => {
                if (!btn) return;
                if (btn.dataset && btn.dataset.busy === '1') return;
                if (btn.dataset) btn.dataset.busy = '1';
                btn.disabled = true;
                try {
                    await fn();
                } finally {
                    btn.disabled = false;
                    if (btn.dataset) delete btn.dataset.busy;
                }
            };

            if (genBtn) {
                genBtn.addEventListener('click', () => runOnce(genBtn, async () => {
                    if (!this.state.questions || !this.state.questions.length) {
                        this.showNotification('Generate or load questions first', 'error');
                        return;
                    }
                    const kw = keywords ? String(keywords.value || '').trim() : '';
                    if (this.callbacks.onGenerateSEOData) {
                        const data = await this.callbacks.onGenerateSEOData({ keywords: kw });
                        setResults(data);
                        this.showNotification('SEO data generated', 'success');
                    }
                }));
            }

            // @NEW 2026-08-11: "Copy Pinned Comment" — builds the comment text
            //       (hook + score challenge + site link) and copies it to the clipboard.
            const pinBtn = document.getElementById('copyPinnedCommentBtn');
            if (pinBtn) {
                pinBtn.addEventListener('click', async () => {
                    try {
                        const qTotal = (Array.isArray(this.state.selectedQuestions) && this.state.selectedQuestions.length)
                            ? this.state.selectedQuestions.length
                            : (Array.isArray(this.state.questions) ? this.state.questions.length : 0);
                        const hook = String(this.state.hookText || '').trim();
                        const brand = String(this.state.brandName || 'TheQuizWire').trim();
                        const site = String(this.state.websiteUrl || (window.location && window.location.origin) || '').trim();
                        const scoreLine = qTotal > 0 ? ('Can you score ' + qTotal + '/' + qTotal + '? Comment below 👇') : 'Comment your score below 👇';
                        const parts = [];
                        if (hook) parts.push(hook);
                        parts.push(scoreLine);
                        if (brand) parts.push('📚 More daily MCQs: ' + brand);
                        if (site) parts.push(site);
                        const text = parts.join('\n\n');
                        await navigator.clipboard.writeText(text);
                        this.showNotification('Pinned comment copied — paste under the video & pin it', 'success');
                    } catch (_) {
                        this.showNotification('Copy failed (browser blocked clipboard) — select & copy manually', 'error');
                    }
                });
            }

            if (copyBtn) {
                copyBtn.addEventListener('click', async () => {
                    const parts = [
                        titleEl ? titleEl.value : '',
                        descEl ? descEl.value : '',
                        tagsEl ? tagsEl.value : ''
                    ].filter(Boolean).join('\n\n');
                    if (!parts) {
                        this.showNotification('No SEO data to copy', 'error');
                        return;
                    }
                    try {
                        await navigator.clipboard.writeText(parts);
                        this.showNotification('Copied SEO to clipboard', 'success');
                    } catch (_) {
                        this.showNotification('Copy failed (browser blocked clipboard)', 'error');
                    }
                });
            }

            if (applyBtn) {
                applyBtn.addEventListener('click', () => {
                    const t = titleEl ? String(titleEl.value || '').trim() : '';
                    if (!t) {
                        this.showNotification('Generate SEO title first', 'error');
                        return;
                    }
                    this.state.quizName = t;
                    const qn = document.getElementById('quizName');
                    if (qn) qn.value = t;
                    if (this.callbacks.onStateChange) this.callbacks.onStateChange();
                    this.showNotification('Applied SEO title to project', 'success');
                });
            }

            // Keep keyword in state for persistence
            if (keywords) {
                keywords.addEventListener('input', () => {
                    this.state.seoKeywords = String(keywords.value || '').trim();
                    if (this.callbacks.onStateChange) this.callbacks.onStateChange();
                });
            }

            // Default auto-toggle behavior is read by controller via DOM (no binding needed).
            if (autoToggle && typeof autoToggle.checked === 'boolean') {
                // noop
            }

            // Hydrate UI from state if exists
            if (keywords && this.state.seoKeywords) keywords.value = String(this.state.seoKeywords || '');
            if (this.state.seoMeta && (this.state.seoMeta.title || this.state.seoMeta.description || (this.state.seoMeta.tags && this.state.seoMeta.tags.length))) {
                setResults(this.state.seoMeta);
            }
        }


        /**
         * @MODIFIED 2026-02-23: TTS Provider & API Persistence Bindings
         */
        bindTTSControls() {
            const provider = document.getElementById('ttsProvider');
            const saveBtn = document.getElementById('saveTtsSettingsBtn');

            // @FIX 2026-07-31: The <select> defaults to its FIRST <option> ('webspeech'),
            //       so its initial 'change' dispatch (below) would overwrite the controller's
            //       config-seeded provider (edge + saved default voice) with Web Speech —
            //       making the Voice dropdown show "Browser Default" and routing every TTS
            //       segment through browser voices (male hook + desync). Sync the <select> to
            //       the seeded provider (when it is a valid option) before that dispatch.
            if (provider) {
                const seededProv = String((this.state && this.state.voiceover && this.state.voiceover.provider) || '').trim();
                if (seededProv && Array.from(provider.options).some(o => o.value === seededProv)) {
                    provider.value = seededProv;
                }
            }

            if (provider) {
                provider.addEventListener('change', () => {
                    const val = provider.value;
                    // Toggle visibility of sub-settings
                    document.querySelectorAll('.tts-sub-settings').forEach(el => el.style.display = 'none');
                const subId = {
                    'google': 'googleTtsSettings',
                    'azure': 'azureTtsSettings',

                    'elevenlabs': 'elevenlabsTtsSettings'
                }[val];
                    if (subId) {
                        const subEl = document.getElementById(subId);
                        if (subEl) subEl.style.display = 'block';
                    }

                    // Keep voiceover settings in sync with provider choice
                    this.state.voiceover = this.state.voiceover || {};
                    this.state.voiceover.provider = val;
                    if (typeof this._refreshVoiceSelect === 'function') {
                        this._refreshVoiceSelect(val);
                    }
                    if (this.callbacks.onStateChange) this.callbacks.onStateChange();
                });

                // Trigger initial toggle
                provider.dispatchEvent(new Event('change'));
            }

            if (saveBtn) {
                saveBtn.addEventListener('click', async () => {
                    const settings = {
                        provider: document.getElementById('ttsProvider')?.value,
                        googleKey: document.getElementById('googleApiKey')?.value,
                        azureKey: document.getElementById('azureApiKey')?.value,
                        azureRegion: document.getElementById('azureRegion')?.value,

                        elevenlabsKey: document.getElementById('elevenlabsApiKey')?.value
                    };

                    saveBtn.disabled = true;
                    saveBtn.textContent = 'Saving...';

                    try {
                        if (this.callbacks.onSaveTtsSettings) {
                            await this.callbacks.onSaveTtsSettings(settings);
                            this.showNotification('AI Settings saved successfully', 'success');
                        }
                    } catch (e) {
                        this.showNotification(`Failed to save settings: ${e.message}`, 'error');
                    } finally {
                        saveBtn.disabled = false;
                        saveBtn.textContent = '💾 Save AI Settings';
                    }
                });
            }
        }

        /**
         * Voiceover (TTS) controls
         * - Enables narrated audio in EXPORT (server-side TTS)
         * - Uses provider selection from #ttsProvider
         */
        bindVoiceoverControls() {
            const enable = document.getElementById('enableVoiceoverToggle');
            const voiceSelect = document.getElementById('voiceSelect');
            const testBtn = document.getElementById('testVoiceBtn');

            const speakHook = document.getElementById('ttsSpeakHookToggle');
            const speakOptions = document.getElementById('ttsSpeakOptionsToggle');
            const speakAnswer = document.getElementById('ttsSpeakAnswerToggle');
            const speakCta = document.getElementById('ttsSpeakCtaToggle');

            const rateSlider = document.getElementById('ttsSpeechRate');
            const rateValue = document.getElementById('ttsSpeechRateValue');
            const answerPhrase = document.getElementById('ttsAnswerPhrase');

            // Ensure subtree exists
            // @FIX 2026-07-31: Defaults come from the WordPress settings
            //       (MCQVS_Config.tts.defaultVoice / .provider) so the studio honors the
            //       configured default voice. webspeech maps to 'edge' (server-side) so
            //       the selected voice is actually honored — webspeech cannot use Edge voices.
            // @FIX 2026-08-11: HONOR 'webspeech' (plugin default) in the Studio — preview
            //       uses browser SpeechSynthesis with no server. This fallback only runs if
            //       the controller seed hasn't populated state.voiceover yet; kept in sync
            //       (enabled:true, rate 1.2) with the controller + Content Planner defaults.
            this.state.voiceover = this.state.voiceover || (() => {
                const ttsCfg = (window.MCQVS_Config && window.MCQVS_Config.tts && typeof window.MCQVS_Config.tts === 'object')
                    ? window.MCQVS_Config.tts : {};
                let provider = String(ttsCfg.provider || 'webspeech').trim() || 'webspeech';
                // @FIX 1.4.9.49 (TTS SSOT): seed every knob from Settings — Studio
                // reflects the global config, never overrides it.
                return {
                    enabled: (ttsCfg.enabled !== undefined) ? !!ttsCfg.enabled : true,
                    provider: provider,
                    voice: String(ttsCfg.defaultVoice || '').trim() || 'en-US-AriaNeural',
                    rate: (ttsCfg.rate !== undefined) ? Number(ttsCfg.rate) : 1.2,
                    pitch: 0,
                    answerPhrase: 'correct answer is',
                    speakHook: (ttsCfg.speakHook !== undefined) ? !!ttsCfg.speakHook : true,
                    speakOptions: (ttsCfg.speakOptions !== undefined) ? !!ttsCfg.speakOptions : true,
                    speakAnswer: (ttsCfg.speakAnswer !== undefined) ? !!ttsCfg.speakAnswer : true,
                    speakCta: (ttsCfg.speakCta !== undefined) ? !!ttsCfg.speakCta : false
                };
            })();

            const callStateChange = () => {
                if (this.callbacks.onStateChange) this.callbacks.onStateChange();
            };

            const getProvider = () => {
                const p = document.getElementById('ttsProvider');
                return p ? String(p.value || 'edge') : String(this.state.voiceover.provider || 'edge');
            };

            const getVoiceList = (provider) => {
                const p = String(provider || '').trim() || 'edge';
                const tts = window.MCQVS_TTSManager;
                if (tts && tts.voices && tts.voices[p]) return tts.voices[p];
                // Minimal fallback lists
                if (p === 'google') return [{ id: 'en-US-Neural2-F', name: 'Neural2 Female (US)' }, { id: 'en-US-Neural2-D', name: 'Neural2 Male (US)' }];
                if (p === 'edge') return [
                    { id: 'en-US-AriaNeural', name: 'Aria (Female, US)' },
                    { id: 'en-US-GuyNeural', name: 'Guy (Male, US)' },
                    { id: 'en-US-JennyNeural', name: 'Jenny (Female, US)' },
                    { id: 'en-US-TonyNeural', name: 'Tony (Male, US)' },
                    { id: 'en-US-MichelleNeural', name: 'Michelle (Female, US)' },
                    { id: 'en-US-SaraNeural', name: 'Sara (Female, US)' },
                    { id: 'en-US-DavisNeural', name: 'Davis (Male, US)' },
                    { id: 'en-US-NancyNeural', name: 'Nancy (Female, US)' },
                    { id: 'en-GB-SoniaNeural', name: 'Sonia (Female, UK)' },
                    { id: 'en-GB-RyanNeural', name: 'Ryan (Male, UK)' },
                    { id: 'en-GB-LibbyNeural', name: 'Libby (Female, UK)' },
                    { id: 'en-GB-ThomasNeural', name: 'Thomas (Male, UK)' },
                    { id: 'en-AU-NatashaNeural', name: 'Natasha (Female, AU)' },
                    { id: 'en-AU-WilliamNeural', name: 'William (Male, AU)' },
                    { id: 'en-IN-NeerjaNeural', name: 'Neerja (Female, IN)' },
                    { id: 'en-IN-PrabhatNeural', name: 'Prabhat (Male, IN)' },
                    { id: 'en-CA-ClaraNeural', name: 'Clara (Female, CA)' },
                    { id: 'en-CA-LiamNeural', name: 'Liam (Male, CA)' },
                    { id: 'en-IE-EmilyNeural', name: 'Emily (Female, IE)' },
                ];

                if (p === 'webspeech') return [{ id: '__webspeech__', name: 'Browser default (Web Speech)' }];
                return [];
            };

            const populateVoices = (provider) => {
                if (!voiceSelect) return;

                const list = getVoiceList(provider);
                const current = String(this.state.voiceover.voice || '').trim();

                voiceSelect.innerHTML = '';
                list.forEach(v => {
                    const opt = document.createElement('option');
                    opt.value = v.id;
                    opt.textContent = v.name || v.id;
                    voiceSelect.appendChild(opt);
                });

                // keep current if possible
                if (current && Array.from(voiceSelect.options).some(o => o.value === current)) {
                    voiceSelect.value = current;
                } else {
                    // @FIX 2026-07-31: Prefer the configured default voice over the first
                    //       option so a provider switch never silently flips to an arbitrary
                    //       (often male) first voice in the list.
                    const cfgDefault = (window.MCQVS_Config && window.MCQVS_Config.tts && window.MCQVS_Config.tts.defaultVoice)
                        ? String(window.MCQVS_Config.tts.defaultVoice).trim() : '';
                    let fallback = '';
                    if (cfgDefault && Array.from(voiceSelect.options).some(o => o.value === cfgDefault)) {
                        fallback = cfgDefault;
                    } else if (voiceSelect.options.length) {
                        fallback = voiceSelect.options[0].value;
                    }
                    if (fallback) {
                        voiceSelect.value = fallback;
                        this.state.voiceover.voice = fallback;
                    }
                }
            };

            // Expose refresh for provider change handler
            this._refreshVoiceSelect = (provider) => populateVoices(provider);

            // Initial hydrate
            // @FIX 2026-07-31: `#ttsProvider` defaults to its FIRST <option> ('webspeech'), so
            //       reading it raw forces the voiceover into Web Speech even though the controller
            //       seeded `state.voiceover.provider` from the WP settings (edge + saved default
            //       voice). That made the Voice dropdown show "Browser Default" and ran every
            //       segment through browser TTS (male hook + desync). Sync the <select> to the
            //       seeded provider (when it is a valid option) BEFORE reading it, so the saved
            //       Edge TTS voice is honored instead.
            (() => {
                const provSel = document.getElementById('ttsProvider');
                const seededProv = String((this.state.voiceover && this.state.voiceover.provider) || '').trim();
                if (provSel && seededProv && Array.from(provSel.options).some(o => o.value === seededProv)) {
                    provSel.value = seededProv;
                }
            })();
            const initialProvider = getProvider();
            this.state.voiceover.provider = initialProvider;
            populateVoices(initialProvider);
            // Rate + answer phrase UI (exported voiceover settings)
            const clampRate = (v) => Math.max(0.6, Math.min(1.4, v));
            const setRateUi = (v) => {
                if (rateSlider) rateSlider.value = String(v);
                if (rateValue) rateValue.textContent = `${Number(v).toFixed(2)}x`;
            };

            if (rateSlider) {
                const initialRate = clampRate(Number(this.state.voiceover.rate) || 1.0);
                this.state.voiceover.rate = initialRate;
                setRateUi(initialRate);

                rateSlider.addEventListener('input', (e) => {
                    const v = clampRate(Number(e.target.value) || 1.0);
                    this.state.voiceover.rate = v;
                    setRateUi(v);
                    callStateChange();
                });
            }

            if (answerPhrase) {
                if (typeof this.state.voiceover.answerPhrase !== 'string') {
                    this.state.voiceover.answerPhrase = 'correct answer is';
                }
                answerPhrase.value = String(this.state.voiceover.answerPhrase || '');
                answerPhrase.addEventListener('input', (e) => {
                    this.state.voiceover.answerPhrase = String(e.target.value || '').trim();
                    callStateChange();
                });
            }


            if (enable) {
                enable.checked = !!this.state.voiceover.enabled;
                enable.addEventListener('change', (e) => {
                    this.state.voiceover.enabled = !!e.target.checked;
                    callStateChange();
                });
            }

            if (voiceSelect) {
                voiceSelect.addEventListener('change', (e) => {
                    this.state.voiceover.voice = String(e.target.value || '').trim();
                    callStateChange();
                });
            }

            if (speakHook) {
                speakHook.checked = (this.state.voiceover.speakHook !== false);
                speakHook.addEventListener('change', (e) => {
                    this.state.voiceover.speakHook = !!e.target.checked;
                    callStateChange();
                });
            }

            if (speakOptions) {
                speakOptions.checked = (this.state.voiceover.speakOptions !== false);
                speakOptions.addEventListener('change', (e) => {
                    this.state.voiceover.speakOptions = !!e.target.checked;
                    callStateChange();
                });
            }

            if (speakAnswer) {
                speakAnswer.checked = (this.state.voiceover.speakAnswer !== false);
                speakAnswer.addEventListener('change', (e) => {
                    this.state.voiceover.speakAnswer = !!e.target.checked;
                    callStateChange();
                });
            }

            if (speakCta) {
                speakCta.checked = !!this.state.voiceover.speakCta;
                speakCta.addEventListener('change', (e) => {
                    this.state.voiceover.speakCta = !!e.target.checked;
                    callStateChange();
                });
            }

            if (testBtn) {
                testBtn.addEventListener('click', async () => {
                    const provider = getProvider();
                    const voice = (voiceSelect && voiceSelect.value) ? String(voiceSelect.value) : String(this.state.voiceover.voice || '');

                    // Export voiceover requires server TTS; webspeech is preview-only
                    if (provider === 'webspeech') {
                        try {
                            const tts = window.MCQVS_TTSManager;
                            if (tts) {
                                tts.setProvider('webspeech');
                                await tts.speak('Can you score five out of five?');
                            }
                        } catch (_) { }
                        return;
                    }

        // @MODIFIED 2026-04-24: Edge is now its own free server provider — no remap needed
        const serverProvider = provider;

        try {
                        testBtn.disabled = true;
                        testBtn.textContent = 'Testing...';

                        const vo = this.state.voiceover || {};

                        const resp = await this.ajaxPost('mcqvs_generate_tts', {
                            text: 'Can you score five out of five?',
                            provider: serverProvider,
                            voice: voice,
                            rate: vo.rate,
                            pitch: vo.pitch
                        });

                        if (!resp || !resp.success || !resp.data || !resp.data.audio_url) {
                            throw new Error(resp?.data || 'TTS failed');
                        }

                        const a = new Audio(resp.data.audio_url);
                        await a.play();
                    } catch (e) {
                        this.showNotification(`TTS test failed: ${e.message}`, 'error');
                    } finally {
                        testBtn.disabled = false;
                        testBtn.textContent = 'Test Voice';
                    }
                });
            }

            // @FIX 1.4.9.58 (TTS SSOT): the Studio TTS panel is a READ-ONLY mirror of
            // Settings → Text-to-Speech. The user picks voice / provider / rate / what
            // to speak in Settings — Studio only displays those values, it must not
            // override them (previously the panel was an editable second source of
            // truth that drifted from Settings). Lock every control + add a note.
            const _lockTtsControls = () => {
                const ids = ['ttsProvider', 'voiceSelect', 'ttsSpeechRate', 'ttsSpeakHookToggle',
                    'ttsSpeakOptionsToggle', 'ttsSpeakAnswerToggle', 'ttsSpeakCtaToggle',
                    'enableVoiceoverToggle', 'ttsAnswerPhrase'];
                ids.forEach((id) => {
                    const el = document.getElementById(id);
                    if (el) el.disabled = true;
                });
                const tWrap = (voiceSelect && voiceSelect.closest('.form-row')) || voiceSelect;
                if (tWrap && !tWrap.querySelector('.mcqvs-tts-readonly-note')) {
                    const note = document.createElement('p');
                    note.className = 'description mcqvs-tts-readonly-note';
                    note.style.color = '#b26a00';
                    note.style.marginTop = '6px';
                    note.textContent = '🔒 Voiceover is managed in Settings → Text-to-Speech (voice, rate, what to speak). Studio reads those values for preview & export.';
                    tWrap.appendChild(note);
                }
            };
            _lockTtsControls();
        }

    } // End of UIController

    // Export (Modular namespace)
    window.MCQVSStudio = window.MCQVSStudio || {};
    window.MCQVSStudio.UIController = UIController;

})(window);
