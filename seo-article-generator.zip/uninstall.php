<?php

if (! defined('WP_UNINSTALL_PLUGIN')) {
	exit;
}

global $wpdb;

/**
 * Uninstall policy:
 * - Default: retain plugin data.
 * - Full purge only when explicitly enabled via SEO_GEN_PURGE_ON_UNINSTALL constant
 *   OR the 'seo_gen_purge_on_uninstall' option.
 */
$purge_on_uninstall_opt = \get_option('seo_gen_purge_on_uninstall', false);
$purge_all_data = (\defined('SEO_GEN_PURGE_ON_UNINSTALL') && SEO_GEN_PURGE_ON_UNINSTALL) || $purge_on_uninstall_opt;

if (! $purge_all_data) {
	return;
}

// v2.26.7: Secure Action Scheduler inclusion to prevent fatal errors during uninstall.
if (! class_exists('ActionScheduler')) {
	$as_path = __DIR__ . '/vendor/action-scheduler/action-scheduler.php';
	if (file_exists($as_path)) {
		require_once $as_path;
	}
}

// Ensure Installer is loaded for table name resolution
if (! class_exists('\SEO_Article_Generator\Installer')) {
	$installer_path = __DIR__ . '/includes/class-installer.php';
	if (file_exists($installer_path)) {
		require_once $installer_path;
	}
}

/**
 * Handle Multisite Purge
 * If multisite is active, loop through all blogs to ensure no orphaned data.
 */
    if (\is_multisite()) {
        $sites = \get_sites(array('fields' => 'ids', 'number' => 0));
        foreach ($sites as $site_id) {
            \switch_to_blog($site_id);
            seo_gen_execute_purge($wpdb, $purge_all_data);
            \restore_current_blog();
        }
    } else {
        seo_gen_execute_purge($wpdb, $purge_all_data);
    }

/**
 * Core purge execution logic.
 *
 * @param \wpdb $wpdb
 * @param bool $purge_all_data Whether to do full purge including postmeta
 */
function seo_gen_execute_purge($wpdb, $purge_all_data = true) {
    $action_group = 'seo-gen';
	$action_hooks = array(
		'seo_gen_canonical_cleanup',
		'seo_gen_daily_cleanup',
		'seo_gen_dailycleanup',
		'seo_gen_generation_job',
		'seo_gen_discovery_job',
		'seo_gen_process_discovery_item',
		'seo_gen_check_discovery_job',
		'seo_gen_passive_discovery',
		'seo_gen_active_ai_discovery',
		'seo_gen_process_article',
		'seo_gen_sideload_featured_image',
		'seo_gen_queue_worker',
		'seo_gen_queue_cleanup',
		'seo_gen_wp_auto_draft_poll',
		'seo_gen_auto_generation_cron',
		'seo_gen_delete_draft_post',
		'seo_gen_sync_openrouter_models',
		'seo_gen_sync_zen_models',
		'generate-article-job',
		'process-draft-job',
		'seo_gen_generationjob',
		'seo_gen_discoveryjob',
		'seo_gen_processarticle',
	);

	// 1. Clear queued work
	if (function_exists('as_unschedule_all_actions')) {
		foreach ($action_hooks as $hook) {
			\as_unschedule_all_actions($hook, array(), $action_group);
			\as_unschedule_all_actions($hook);
		}
	}

	foreach ($action_hooks as $hook) {
		while (($timestamp = \wp_next_scheduled($hook)) !== false) {
			\wp_unschedule_event($timestamp, $hook);
		}
	}

    // 2. Delete wp_options entries owned by this plugin.
    $option_names = $wpdb->get_col(
        $wpdb->prepare(
            "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s OR option_name LIKE %s",
            'seo_gen_%',
            'seogen_%',
            '_transient_seo_gen_%',
            '_transient_seogen_%',
            '_transient_timeout_seo_gen_%',
            '_transient_timeout_seogen_%'
        )
    );

	foreach ($option_names as $option_name) {
		\delete_option($option_name);
	}
	
    // 3. Delete site options on multisite.
    if (\is_multisite() && isset($wpdb->sitemeta)) {
        $site_option_names = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT meta_key FROM {$wpdb->sitemeta} WHERE meta_key LIKE %s OR meta_key LIKE %s OR meta_key LIKE %s OR meta_key LIKE %s OR meta_key LIKE %s",
                'seo_gen_%',
                'seogen_%',
                '_site_transient_seo_gen_%',
                '_site_transient_seogen_%',
                '_site_transient_timeout_seo_gen_%'
            )
        );

        foreach ($site_option_names as $meta_key) {
            \delete_site_option($meta_key);
        }
    }

    // 4. Delete plugin meta keys if they were stored with the plugin prefix.
    // CRITICAL: Only delete postmeta when PURGE_ON_UNINSTALL is true.
    // When false (default), preserve critical meta like _seo_gen_post_owned, seogenherodata, _seo_gen_hero_data.
    if ($purge_all_data) {
        $meta_targets = array(
            array('table' => $wpdb->postmeta, 'column' => 'meta_key'),
            array('table' => $wpdb->termmeta, 'column' => 'meta_key'),
            array('table' => $wpdb->commentmeta, 'column' => 'meta_key'),
            array('table' => $wpdb->usermeta, 'column' => 'meta_key'),
        );

        foreach ($meta_targets as $target) {
            $table = $target['table'];
            $column = $target['column'];
            if (empty($table)) continue;

            $sql = "DELETE FROM {$table} WHERE {$column} LIKE %s OR {$column} LIKE %s OR {$column} LIKE %s OR {$column} LIKE %s OR {$column} IN (%s, %s)";
            $wpdb->query($wpdb->prepare($sql, 'seo_gen_%', '_seo_gen_%', 'seogen_%', '_seogen_%', '_seo_last_verified', '_seo_reviewed_by'));
        }
    }

	// 5. Drop all plugin tables in this namespace.
	$table_like = $wpdb->esc_like($wpdb->prefix . 'seo_gen_') . '%';
	$tables     = $wpdb->get_col($wpdb->prepare('SHOW TABLES LIKE %s', $table_like));

	foreach ($tables as $table_name) {
		$wpdb->query("DROP TABLE IF EXISTS `" . \esc_sql($table_name) . "`");
	}

	// 6. Also drop the internal links table
	$links_table = \SEO_Article_Generator\Installer::table_links();
	$wpdb->query("DROP TABLE IF EXISTS `{$links_table}`");
	
	// Legacy links table
	$legacy_links = $wpdb->prefix . 'seo_internal_links';
	$wpdb->query("DROP TABLE IF EXISTS `{$legacy_links}`");

	$jobs_table = \SEO_Article_Generator\Installer::table_jobs();
	$wpdb->query("DROP TABLE IF EXISTS `{$jobs_table}`");
}

