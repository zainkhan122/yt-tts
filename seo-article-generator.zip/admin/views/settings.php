<?php

/**
 * Settings View
 *
 * @package SEO_Article_Generator
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Get current settings
$api_provider = get_option(\SEO_Article_Generator\Option_Registry::API_PROVIDER, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::API_PROVIDER]);
$provider_only_mode = (bool) get_option(\SEO_Article_Generator\Option_Registry::PROVIDER_ONLY_MODE, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::PROVIDER_ONLY_MODE]);

// Gemini model mode/custom/effective
$gemini_model_mode = get_option(\SEO_Article_Generator\Option_Registry::GEMINI_MODEL_MODE, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::GEMINI_MODEL_MODE]);
$gemini_custom_model = get_option(\SEO_Article_Generator\Option_Registry::GEMINI_CUSTOM_MODEL, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::GEMINI_CUSTOM_MODEL]);
$gemini_effective_model = get_option(\SEO_Article_Generator\Option_Registry::GEMINI_MODEL, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::GEMINI_MODEL]);
$gemini_models = \SEO_Article_Generator\AI\AI_Client::get_gemini_models();
$gemini_mode_is_custom = ($gemini_model_mode === 'custom');
if (!$gemini_mode_is_custom && !isset($gemini_models[$gemini_model_mode])) {
	$gemini_model_mode = \SEO_Article_Generator\AI\AI_Client::get_default_model_for_provider('gemini');
}

// @MODIFIED 2025-12-02 - Use multi-source key finder (fully qualified)
$gemini_api_key = \SEO_Article_Generator\AI\AI_Client::get_gemini_key();
$key_source = '';
if (!empty($gemini_api_key)) {
    if (get_option(\SEO_Article_Generator\Option_Registry::GEMINI_API_KEY, '')) {
        $key_source = 'this plugin';
    } else {
        $key_source = 'MCQ plugin';
    }
}

// @MODIFIED 2026-01-05 - Fix: Actually retrieve the perplexity api key so it shows in the UI
$perplexity_api_key = \SEO_Article_Generator\AI\AI_Client::get_perplexity_key();
$perplexity_model = \SEO_Article_Generator\AI\AI_Client::get_perplexity_model();
$validation_threshold = get_option(\SEO_Article_Generator\Option_Registry::VALIDATION_THRESHOLD, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::VALIDATION_THRESHOLD]);
$internal_link_count = (int) get_option(\SEO_Article_Generator\Option_Registry::INTERNAL_LINK_COUNT, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::INTERNAL_LINK_COUNT]);
$enable_logging = get_option(\SEO_Article_Generator\Option_Registry::ENABLE_LOGGING, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::ENABLE_LOGGING]);

// @MODIFIED 2026-02-19 - Fix: Actually retrieve the log retention so it shows in the UI
$log_retention = get_option(\SEO_Article_Generator\Option_Registry::LOG_RETENTION, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::LOG_RETENTION]);

// @MODIFIED 2026-03-03 - New settings retrieval
$active_tab = isset($_GET['stab']) ? sanitize_key($_GET['stab']) : 'general';
$publish_status = get_option(\SEO_Article_Generator\Option_Registry::DISCOVERY_PUBLISH_STATUS, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::DISCOVERY_PUBLISH_STATUS]);
$retention_days = (int) get_option(\SEO_Article_Generator\Option_Registry::DRAFT_RETENTION_DAYS, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::DRAFT_RETENTION_DAYS]);

// @MODIFIED 2026-03-04 - Scheduling settings retrieval
$enable_scheduling = get_option(\SEO_Article_Generator\Option_Registry::ENABLE_SCHEDULING, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::ENABLE_SCHEDULING]);
$publish_start = get_option(\SEO_Article_Generator\Option_Registry::PUBLISH_START, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::PUBLISH_START]);
$publish_end = get_option(\SEO_Article_Generator\Option_Registry::PUBLISH_END, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::PUBLISH_END]);
$posts_per_day = (int) get_option(\SEO_Article_Generator\Option_Registry::POSTS_PER_DAY, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::POSTS_PER_DAY]);
$active_days = get_option(\SEO_Article_Generator\Option_Registry::ACTIVE_DAYS, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::ACTIVE_DAYS]);
if (!is_array($active_days)) {
    $active_days = \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::ACTIVE_DAYS];
}

// @MODIFIED 2026-03-05 - Auto-Generation settings retrieval
$enable_auto_gen = get_option(\SEO_Article_Generator\Option_Registry::ENABLE_AUTO_GENERATION, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::ENABLE_AUTO_GENERATION]);
$auto_gen_interval = get_option(\SEO_Article_Generator\Option_Registry::AUTO_GENERATION_INTERVAL, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::AUTO_GENERATION_INTERVAL]);
if (!is_numeric($auto_gen_interval)) {
	$auto_gen_interval = (int) (\SEO_Article_Generator\Option_Registry::interval_to_seconds($auto_gen_interval) / MINUTE_IN_SECONDS);
}
$auto_gen_batch = (int) get_option(\SEO_Article_Generator\Option_Registry::AUTO_GENERATION_BATCH, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::AUTO_GENERATION_BATCH]);

// @MODIFIED 2026-03-05 - Configurable clumping protection retrieval
$publish_interval_min = (int) get_option(\SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MIN, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MIN]);
$publish_interval_max = (int) get_option(\SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MAX, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MAX]);

// @MODIFIED 2026-03-08 - Update generation delay settings retrieval
$update_delay_min = (int) get_option(\SEO_Article_Generator\Option_Registry::UPDATE_DELAY_MIN, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::UPDATE_DELAY_MIN]);
$update_delay_max = (int) get_option(\SEO_Article_Generator\Option_Registry::UPDATE_DELAY_MAX, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::UPDATE_DELAY_MAX]);
$updates_per_day = (int) get_option(\SEO_Article_Generator\Option_Registry::UPDATES_PER_DAY, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::UPDATES_PER_DAY]);

// @MODIFIED 2026-04-22 - Portable Version Discovery toggle
$enable_portable_discovery = get_option(\SEO_Article_Generator\Option_Registry::ENABLE_PORTABLE_DISCOVERY, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::ENABLE_PORTABLE_DISCOVERY]);
?>

<div class="wrap seo-gen-settings-wrap">
    <h1><?php \esc_html_e('SEO Generator Settings', 'seo-article-generator'); ?></h1>

    <?php \settings_errors('seo_gen_settings'); ?>

    <h2 class="nav-tab-wrapper js-settings-tabs" style="margin-top: 20px;">
        <a href="#sgd-pane-general" class="nav-tab <?php echo $active_tab === 'general' ? 'nav-tab-active' : ''; ?>" data-tab="general"><?php \esc_html_e('General', 'seo-article-generator'); ?></a>
        <a href="#sgd-pane-api" class="nav-tab <?php echo $active_tab === 'api' ? 'nav-tab-active' : ''; ?>" data-tab="api"><?php \esc_html_e('API Configuration', 'seo-article-generator'); ?></a>
        <a href="#sgd-pane-automation" class="nav-tab <?php echo $active_tab === 'automation' ? 'nav-tab-active' : ''; ?>" data-tab="automation"><?php \esc_html_e('Automation', 'seo-article-generator'); ?></a>
        <a href="#sgd-pane-health" class="nav-tab <?php echo $active_tab === 'health' ? 'nav-tab-active' : ''; ?>" data-tab="health"><?php \esc_html_e('System Health', 'seo-article-generator'); ?></a>
        <a href="#sgd-pane-social" class="nav-tab <?php echo $active_tab === 'social' ? 'nav-tab-active' : ''; ?>" data-tab="social"><?php \esc_html_e('Social Sharing', 'seo-article-generator'); ?></a>
        <a href="#sgd-pane-backfill" class="nav-tab <?php echo $active_tab === 'backfill' ? 'nav-tab-active' : ''; ?>" data-tab="backfill" style="background: #f0f6fc; color: #2271b1; font-weight: 600;"><?php \esc_html_e('Sentinel Backfill', 'seo-article-generator'); ?></a>
        <a href="#sgd-pane-migration" class="nav-tab <?php echo $active_tab === 'migration' ? 'nav-tab-active' : ''; ?>" data-tab="migration" style="background: #e8f5e9; color: #2e7d32; font-weight: 600;"><?php \esc_html_e('Canonical Slug Migration', 'seo-article-generator'); ?></a>
    </h2>

    <form method="post" action="" id="seo-gen-settings-form">
        <?php \wp_nonce_field('seo_gen_settings'); ?>
        <input type="hidden" name="stab" id="active_tab_input" value="<?php echo \esc_attr($active_tab); ?>">

        <!-- GENERAL TAB -->
        <div id="sgd-pane-general" class="sgd-pane <?php echo $active_tab === 'general' ? 'active' : ''; ?>">
            <h2><?php \esc_html_e('General Settings', 'seo-article-generator'); ?></h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="seo_gen_validation_threshold"><?php \esc_html_e('Validation Threshold', 'seo-article-generator'); ?></label>
                    </th>
                    <td>
                        <input type="number" name="seo_gen_validation_threshold" id="seo_gen_validation_threshold"
                            value="<?php echo \esc_attr($validation_threshold); ?>" min="0" max="100" step="1">
                        <p class="description">
                            <?php \esc_html_e('Minimum score required to pass validation (0-100)', 'seo-article-generator'); ?>
                        </p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="seo_gen_internal_link_count"><?php \esc_html_e('Maximum Internal Links Per Article', 'seo-article-generator'); ?></label>
                    </th>
                    <td>
                        <input type="number" name="seo_gen_internal_link_count" id="seo_gen_internal_link_count"
                            value="<?php echo \esc_attr($internal_link_count); ?>" min="0" max="3" step="1" class="small-text">
                        <p class="description">
                            <?php \esc_html_e('0 disables automatic internal links. 1 to 3 sets the maximum internal links added to each new OR updated article, placed contextually only in the intro, MOAT and Features sections (a link is added to a paragraph only when none is already present). Links are chosen from your published posts by brand name mentioned in the text; generic words and the hero/specs/download sections are never linked.', 'seo-article-generator'); ?>
                        </p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="seo_gen_enable_logging"><?php \esc_html_e('Enable Logging', 'seo-article-generator'); ?></label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="seo_gen_enable_logging" id="seo_gen_enable_logging" value="1" <?php \checked($enable_logging, true); ?>>
                            <?php \esc_html_e('Enable debug logging', 'seo-article-generator'); ?>
                        </label>
                        <p class="description">
                            <?php \esc_html_e('Log files are stored in wp-content/uploads/seo-generator-logs/', 'seo-article-generator'); ?>
                        </p>
                    </td>
                </tr>

                <tr id="log-retention-row" <?php echo !$enable_logging ? 'style="display:none;"' : ''; ?>>
                    <th scope="row">
                        <label for="seo_gen_log_retention"><?php \esc_html_e('Log Retention', 'seo-article-generator'); ?></label>
                    </th>
                    <td>
                        <input type="number" name="seo_gen_log_retention" id="seo_gen_log_retention" value="<?php echo \esc_attr($log_retention); ?>" min="0" step="1" class="small-text">
                        <span class="description"><?php \esc_html_e('days', 'seo-article-generator'); ?></span>
                        <p class="description">
                            <?php \esc_html_e('Automatically delete log files older than this many days. Set to 0 to keep logs indefinitely.', 'seo-article-generator'); ?>
                        </p>
                        <button type="submit" name="seo_gen_clear_logs" class="button button-link-delete" style="color: #d63638;" onclick="return confirm('<?php \esc_attr_e('Are you sure you want to delete ALL existing log files?', 'seo-article-generator'); ?>');">
                            <?php \esc_html_e('Clear all logs now', 'seo-article-generator'); ?>
                        </button>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="seo_gen_purge_on_uninstall"><?php \esc_html_e('Uninstall Policy', 'seo-article-generator'); ?></label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="seo_gen_purge_on_uninstall" id="seo_gen_purge_on_uninstall" value="1" <?php \checked(get_option(\SEO_Article_Generator\Option_Registry::PURGE_ON_UNINSTALL, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::PURGE_ON_UNINSTALL]), true); ?>>
                            <span style="color: #d63638; font-weight: 600;"><?php \esc_html_e('Purge all data on uninstall', 'seo-article-generator'); ?></span>
                        </label>
                        <p class="description">
                            <?php \esc_html_e('If enabled, deleting the plugin will permanently remove all plugin settings, internal data tables, and generation logs. Published articles will NOT be deleted.', 'seo-article-generator'); ?>
                        </p>
                    </td>
                </tr>
            </table>

            <?php // @MODIFIED 2026-03-09 - SEO Title Configuration Section 
            ?>
            <hr />
            <h2><?php \esc_html_e('SEO Title Configuration', 'seo-article-generator'); ?></h2>
            <p class="description"><?php \esc_html_e('Controls how post titles are generated for NEW posts. Existing post titles are only updated with the new version number.', 'seo-article-generator'); ?></p>
<?php
// @MODIFIED 2026-04-05 - Retrieve SEO title settings as allowed-style pool
$title_style = get_option(\SEO_Article_Generator\Option_Registry::TITLE_STYLE, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::TITLE_STYLE]);

if (!is_array($title_style)) {
    $title_style = array((string) $title_style);
}

$title_style = array_values(array_unique(array_filter(array_map('strval', $title_style), static function ($style) {
    return in_array($style, array('1', '2', '3'), true);
})));

if (empty($title_style)) {
    $title_style = \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::TITLE_STYLE];
}

$platform_threshold = (int) get_option(\SEO_Article_Generator\Option_Registry::PLATFORM_THRESHOLD, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::PLATFORM_THRESHOLD]);
?>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label><?php \esc_html_e('Allowed Title Styles', 'seo-article-generator'); ?></label>
                    </th>
                    <td>
                        <?php
                        $title_styles = array(
                            '1' => '{name} {version} Free Download for {platforms}',
                            '2' => '{name} {version} Download Free for {platforms}',
                            '3' => '{name} {version} Download for {platforms}',
                        );
                        foreach ($title_styles as $val => $template):
                        ?>
                            <label style="display:block; margin-bottom:8px;">
                                <input
                                    type="checkbox"
                                    name="seo_gen_title_style[]"
                                    value="<?php echo esc_attr($val); ?>"
                                    <?php \checked(in_array((string) $val, $title_style, true), true); ?>
                                >
                                <code><?php echo \esc_html($template); ?></code>
                            </label>
                        <?php endforeach; ?>
                        <p class="description">
                            <?php \esc_html_e('The generator will keep choosing randomly, but only from the checked styles.', 'seo-article-generator'); ?>
                        </p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="seo_gen_platform_threshold"><?php \esc_html_e('Platform List Threshold', 'seo-article-generator'); ?></label>
                    </th>
                    <td>
                        <input type="number" name="seo_gen_platform_threshold" id="seo_gen_platform_threshold"
                            value="<?php echo \esc_attr($platform_threshold); ?>" min="1" max="10" step="1" class="small-text">
                        <p class="description">
                            <?php \esc_html_e('If a software supports more platforms than this number, the title will use "for All Platforms" instead of listing them. Default: 3.', 'seo-article-generator'); ?>
                        </p>
                        <div style="margin-top:10px; padding:10px; background:#f0f6fc; border-left:3px solid #2271b1;">
                            <strong><?php \esc_html_e('Platform Rules:', 'seo-article-generator'); ?></strong>
                            <ul style="margin:6px 0 0 15px; list-style:disc;">
                                <li><?php \esc_html_e('Up to threshold (e.g. ≤3): "for Windows, macOS & Linux"', 'seo-article-generator'); ?></li>
                                <li><?php \esc_html_e('More than threshold: "for All Platforms"', 'seo-article-generator'); ?></li>
                                <li><?php \esc_html_e('1 PC OS + Mobile only: "for Windows and Mobile"', 'seo-article-generator'); ?></li>
                            </ul>
                        </div>
                    </td>
                </tr>
            </table>
        </div>

        <!-- API TAB -->
        <div id="sgd-pane-api" class="sgd-pane <?php echo $active_tab === 'api' ? 'active' : ''; ?>">
            <h2><?php \esc_html_e('API Configuration', 'seo-article-generator'); ?></h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="seo_gen_api_provider"><?php \esc_html_e('API Provider', 'seo-article-generator'); ?></label>
                    </th>
                    <td>
                         <select name="seo_gen_api_provider" id="seo_gen_api_provider">
                            <option value="gemini" <?php \selected($api_provider, 'gemini'); ?>>Google Gemini</option>
 				<option value="claude" <?php \selected($api_provider, 'claude'); ?> disabled>Claude (Coming Soon)</option>
                            <?php
                            $custom_providers_dropdown = \get_option(\SEO_Article_Generator\Option_Registry::CUSTOM_PROVIDERS, '[]');
                            if (\is_string($custom_providers_dropdown)) {
                                $custom_providers_dropdown = \json_decode($custom_providers_dropdown, true);
                            }
                            if (\is_array($custom_providers_dropdown) && !empty($custom_providers_dropdown)):
                            ?>
                            <optgroup label="<?php \esc_attr_e('Custom Providers', 'seo-article-generator'); ?>">
                                <?php foreach ($custom_providers_dropdown as $cp): ?>
                                <option value="<?php echo \esc_attr($cp['id'] ?? ''); ?>" <?php \selected($api_provider, $cp['id'] ?? ''); ?>><?php echo \esc_html(($cp['name'] ?? 'Unnamed') . ' (' . ($cp['id'] ?? '') . ')'); ?></option>
                                <?php endforeach; ?>
                            </optgroup>
                            <?php endif; ?>
                        </select>
                        <?php
                        // Surface the silent-omission case: a fully-keyed Gemini
                        // provider that will never be used because the active primary
                        // is a custom provider and Gemini is not in the routing chain.
                        // Reuses the authoritative router (AI_Client::get_active_providers)
                        // so the warning can never drift from real fallback behavior.
                        if ($api_provider !== 'gemini' && !$provider_only_mode && !empty($gemini_api_key)) {
                            $active_providers_for_notice = \SEO_Article_Generator\AI\AI_Client::get_active_providers();
                            if (!\in_array('gemini', $active_providers_for_notice, true)) {
                                ?>
                                <p class="description" style="color:#b32d2e; margin-top:8px;">
                                    <?php \esc_html_e('Gemini is configured with an API key but is not in your fallback chain — it will never be used as a backup when the selected provider\'s models exhaust. Add Gemini to your provider fallback order (or ensure it is enabled) to use it as a backstop.', 'seo-article-generator'); ?>
                                </p>
                                <?php
                            }
                        }
                        ?>
                    </td>
                </tr>

                <tr id="provider-only-mode-row">
                    <th scope="row">
                        <label for="seo_gen_provider_only_mode"><?php \esc_html_e('Provider Routing', 'seo-article-generator'); ?></label>
                    </th>
                    <td>
                        <label>
                            <input
                                type="checkbox"
                                name="seo_gen_provider_only_mode"
                                id="seo_gen_provider_only_mode"
                                value="1"
                                <?php \checked($provider_only_mode, true); ?>
                            >
                            <?php \esc_html_e('Use selected provider ONLY (disable auto-fallback to other providers).', 'seo-article-generator'); ?>
                        </label>

                        <p
                            id="seo_gen_provider_only_mode-note"
                            class="description"
                            style="<?php echo $provider_only_mode ? '' : 'display:none;'; ?>"
                        >
                            <?php \esc_html_e('Generation will fail on the selected provider instead of moving to OpenAI, Groq, or Perplexity.', 'seo-article-generator'); ?>
                        </p>
                    </td>
                </tr>

                <tr id="gemini-api-key-row" style="<?php echo $api_provider !== 'gemini' ? 'display:none;' : ''; ?>">
                    <th scope="row">
                        <label for="seo_gen_gemini_api_key"><?php \esc_html_e('Gemini API Key', 'seo-article-generator'); ?></label>
                    </th>
                    <td>
                        <div style="display:flex; align-items:center; gap:5px; margin-bottom:5px;">
<?php
$has_gemini_key = (string) get_option(\SEO_Article_Generator\Option_Registry::GEMINI_API_KEY, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::GEMINI_API_KEY]) !== '';
?>
                            <input type="password" name="seo_gen_gemini_api_key" id="seo_gen_gemini_api_key"
                                value="" class="regular-text"
                                placeholder="<?php echo esc_attr($has_gemini_key ? '••••••••' : 'Enter API key or leave empty to use MCQ plugin'); ?>">
                            <button type="button" class="button"
                                onclick="var x=document.getElementById('seo_gen_gemini_api_key'); if(x.type==='password'){x.type='text';this.textContent='Hide';}else{x.type='password';this.textContent='Show';}">Show</button>
                        </div>
                        <p class="description">
                            <?php if (!empty($key_source)): ?>
                                <span style="color: #46b450;">✓ Using API key from <strong><?php echo \esc_html($key_source); ?></strong></span><br>
                            <?php endif; ?>
                            <?php \printf(\esc_html__('Get your API key from %s or leave empty to use MCQ plugin key.', 'seo-article-generator'), '<a href="https://aistudio.google.com/app/apikey" target="_blank">Google AI Studio</a>'); ?>
                        </p>
                    </td>
                </tr>

<tr id="gemini-model-row" style="<?php echo $api_provider !== 'gemini' ? 'display:none;' : ''; ?>">
	<th scope="row">
		<label for="seo_gen_gemini_model_mode"><?php \esc_html_e('Gemini Model', 'seo-article-generator'); ?></label>
	</th>
	<td>
		<select name="seo_gen_gemini_model_mode" id="seo_gen_gemini_model_mode">
			<?php foreach ($gemini_models as $val => $label): ?>
			<option value="<?php echo \esc_attr($val); ?>" <?php \selected($gemini_model_mode, $val); ?>>
				<?php echo \esc_html($label); ?>
			</option>
			<?php endforeach; ?>
			<option value="custom" <?php \selected($gemini_model_mode, 'custom'); ?>>
				<?php \esc_html_e('Custom', 'seo-article-generator'); ?>
			</option>
		</select>
		<p class="description">
			<?php \esc_html_e('Select a verified Gemini model, or choose Custom only if you intentionally want to use a manually entered model ID.', 'seo-article-generator'); ?>
		</p>
		<div id="gemini-custom-model-wrap" style="margin-top:8px; <?php echo !$gemini_mode_is_custom ? 'display:none;' : ''; ?>">
			<label for="seo_gen_gemini_custom_model" class="screen-reader-text"><?php \esc_html_e('Custom Gemini Model ID', 'seo-article-generator'); ?></label>
			<input type="text" name="seo_gen_gemini_custom_model" id="seo_gen_gemini_custom_model" value="<?php echo \esc_attr($gemini_custom_model); ?>" class="regular-text" placeholder="gemini-2.5-flash" autocomplete="off" spellcheck="false">
			<p class="description">
				<?php \esc_html_e('Used only when Gemini Model is set to Custom. Enter an exact model ID. Invalid IDs will be rejected during save or runtime validation.', 'seo-article-generator'); ?>
			</p>
		</div>
		<p class="description" style="margin-top:8px;">
			<?php printf(\esc_html__('Effective stored Gemini model: %s', 'seo-article-generator'), \esc_html($gemini_effective_model)); ?>
		</p>
	</td>
</tr>

	<tr id="gemini-fallback-row" style="<?php echo $api_provider !== 'gemini' ? 'display:none;' : ''; ?>">
		<th scope="row">
			<label for="seo_gen_gemini_fallback"><?php \esc_html_e('Gemini Model Fallback Chain', 'seo-article-generator'); ?></label>
		</th>
		<td>
			<label>
				<input type="checkbox" name="seo_gen_gemini_fallback" id="seo_gen_gemini_fallback" value="1" <?php \checked(get_option(\SEO_Article_Generator\Option_Registry::GEMINI_FALLBACK, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::GEMINI_FALLBACK]), true); ?>>
				<?php \esc_html_e('Enable tiered fallback within Gemini models', 'seo-article-generator'); ?>
			</label>
			<p class="description" style="<?php echo get_option(\SEO_Article_Generator\Option_Registry::PROVIDER_ONLY_MODE, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::PROVIDER_ONLY_MODE]) ? 'color:red; font-weight:bold;' : ''; ?>">
				<?php \esc_html_e('Verified stable Gemini fallback chain: 3.5 Flash → 2.5 Flash → 2.0 Flash → 2.0 Flash 001. Pro models are excluded from fallback by design.', 'seo-article-generator'); ?>
			</p>
		</td>
	</tr>



	<tr id="test-api-row">
                    <th scope="row"><?php \esc_html_e('Test Connection', 'seo-article-generator'); ?></th>
                    <td>
                        <button type="button" class="button button-secondary" id="seo-gen-test-api">
                            <?php \esc_html_e('Test API Connection', 'seo-article-generator'); ?>
                        </button>
                        <span id="seo-gen-api-test-result" style="margin-left: 10px;"></span>
                        <p class="description">
                            <?php \esc_html_e('Tests connectivity to the currently selected API provider.', 'seo-article-generator'); ?>
                        </p>
                    </td>
                </tr>
            </table>

            <hr style="margin: 30px 0;" />
            <h2><?php \esc_html_e('Custom AI Providers', 'seo-article-generator'); ?></h2>
            <p class="description" style="margin-bottom: 15px;">
                <?php \esc_html_e('Add any OpenAI-compatible API endpoint (vLLM, Ollama, DeepSeek, custom proxy, etc.). Each provider can have multiple models with automatic intra-provider fallback.', 'seo-article-generator'); ?>
            </p>

            <div id="seo-gen-custom-providers-container">
                <?php
                $custom_providers = \get_option(\SEO_Article_Generator\Option_Registry::CUSTOM_PROVIDERS, '[]');
                if (\is_string($custom_providers)) {
                    $custom_providers = \json_decode($custom_providers, true);
                }
                $custom_providers = \is_array($custom_providers) ? $custom_providers : array();
                if (empty($custom_providers)):
                ?>
                <p class="description" id="seo-gen-no-custom-providers"><?php \esc_html_e('No custom providers configured yet. Click "Add Custom Provider" to get started.', 'seo-article-generator'); ?></p>
                <?php else:
                    foreach ($custom_providers as $idx => $profile):
                        $pid = \esc_attr($profile['id'] ?? '');
                        $pname = \esc_attr($profile['name'] ?? 'Unnamed');
                        $purl = \esc_attr($profile['api_url'] ?? '');
                        $pkey = !empty($profile['api_key']) ? '••••••••' : '';
                        $pweb = !empty($profile['enable_web_search']) ? '1' : '0';
                        $ptype = \esc_attr($profile['web_search_config']['type'] ?? 'none');
                        $pschema = !empty($profile['supports_json_schema']) ? '1' : '0';
                        $pfallback = !empty($profile['fallback_enabled']) ? '1' : '0';
                        $pmodels = $profile['models'] ?? array();
                ?>
                <div class="seo-gen-custom-provider-card" data-provider-id="<?php echo $pid; ?>" style="background: #fff; border: 1px solid #c3c4c7; border-radius: 4px; padding: 20px; margin-bottom: 15px; position: relative;">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
                        <h3 style="margin:0;"><?php echo \esc_html($pname); ?> <code style="font-weight:normal; color:#666;">(<?php echo $pid; ?>)</code></h3>
                        <button type="button" class="button button-link-delete seo-gen-remove-provider" data-provider-id="<?php echo $pid; ?>"><?php \esc_html_e('Remove', 'seo-article-generator'); ?></button>
                    </div>
                    <table class="form-table" style="margin-top:0;">
                        <tr>
                            <th scope="row"><label><?php \esc_html_e('Provider Name', 'seo-article-generator'); ?></label></th>
                            <td><input type="text" name="seo_gen_custom_providers[<?php echo $idx; ?>][name]" value="<?php echo $pname; ?>" class="regular-text" placeholder="My Custom API"></td>
                        </tr>
                        <tr>
                            <th scope="row"><label><?php \esc_html_e('API URL', 'seo-article-generator'); ?></label></th>
                            <td>
                                <input type="url" name="seo_gen_custom_providers[<?php echo $idx; ?>][api_url]" value="<?php echo $purl; ?>" class="large-text" placeholder="https://api.example.com/v1">
                                <p class="description"><?php \esc_html_e('OpenAI-compatible endpoint. The /chat/completions path is appended automatically.', 'seo-article-generator'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label><?php \esc_html_e('API Key', 'seo-article-generator'); ?></label></th>
                            <td>
                                <div style="display:flex; align-items:center; gap:5px;">
                                    <input type="password" name="seo_gen_custom_providers[<?php echo $idx; ?>][api_key]" value="" class="regular-text" placeholder="<?php echo $pkey ? '•••••••• (leave empty to keep existing)' : 'Enter API key'; ?>">
                                    <button type="button" class="button seo-gen-toggle-key" onclick="var x=this.previousElementSibling; if(x.type==='password'){x.type='text';this.textContent='Hide';}else{x.type='password';this.textContent='Show';}">Show</button>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label><?php \esc_html_e('Models', 'seo-article-generator'); ?></label></th>
                            <td>
                                <div class="seo-gen-model-list" data-idx="<?php echo $idx; ?>">
                                    <?php foreach ($pmodels as $mi => $m): ?>
                                    <div class="seo-gen-model-row" style="display:flex; gap:8px; margin-bottom:8px; align-items:center;">
                                        <input type="text" name="seo_gen_custom_providers[<?php echo $idx; ?>][models][<?php echo $mi; ?>][model_id]" value="<?php echo \esc_attr($m['model_id'] ?? ''); ?>" class="regular-text" placeholder="model-id" style="flex:1;">
                                        <input type="text" name="seo_gen_custom_providers[<?php echo $idx; ?>][models][<?php echo $mi; ?>][display_name]" value="<?php echo \esc_attr($m['display_name'] ?? ''); ?>" class="regular-text" placeholder="Display Name" style="flex:1;">
                                        <button type="button" class="button seo-gen-remove-model" title="<?php \esc_html_e('Remove model', 'seo-article-generator'); ?>">&times;</button>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                                <button type="button" class="button button-small seo-gen-add-model" data-idx="<?php echo $idx; ?>"><?php \esc_html_e('+ Add Model', 'seo-article-generator'); ?></button>
                                <p class="description"><?php \esc_html_e('First model is primary. Subsequent models are used for intra-provider fallback.', 'seo-article-generator'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label><?php \esc_html_e('Response Format', 'seo-article-generator'); ?></label></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="seo_gen_custom_providers[<?php echo $idx; ?>][supports_json_schema]" value="1" <?php \checked($pschema, '1'); ?>>
                                    <?php \esc_html_e('Supports JSON Schema (structured output). Disable if the endpoint returns 400 with json_schema.', 'seo-article-generator'); ?>
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label><?php \esc_html_e('Web Search', 'seo-article-generator'); ?></label></th>
                            <td>
                                <label style="display:block; margin-bottom:6px;">
                                    <input type="checkbox" class="seo-gen-ws-toggle" data-idx="<?php echo $idx; ?>" name="seo_gen_custom_providers[<?php echo $idx; ?>][enable_web_search]" value="1" <?php \checked($pweb, '1'); ?>>
                                    <?php \esc_html_e('Enable web search grounding', 'seo-article-generator'); ?>
                                </label>
                                <div class="seo-gen-ws-config" data-idx="<?php echo $idx; ?>" style="<?php echo $pweb !== '1' ? 'display:none;' : ''; ?>">
                                    <select name="seo_gen_custom_providers[<?php echo $idx; ?>][web_search_config][type]">
                                        <option value="none" <?php \selected($ptype, 'none'); ?>><?php \esc_html_e('None', 'seo-article-generator'); ?></option>
                                        <option value="google_search" <?php \selected($ptype, 'google_search'); ?>><?php \esc_html_e('Google Search (Gemini-style)', 'seo-article-generator'); ?></option>
                                        <option value="zhipuai" <?php \selected($ptype, 'zhipuai'); ?>><?php \esc_html_e('ZhipuAI Web Search', 'seo-article-generator'); ?></option>
                                        <option value="kimi" <?php \selected($ptype, 'kimi'); ?>><?php \esc_html_e('Kimi Web Search', 'seo-article-generator'); ?></option>
                                        <option value="minimax" <?php \selected($ptype, 'minimax'); ?>><?php \esc_html_e('MiniMax Web Search', 'seo-article-generator'); ?></option>
                                    </select>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label><?php \esc_html_e('Fallback', 'seo-article-generator'); ?></label></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="seo_gen_custom_providers[<?php echo $idx; ?>][fallback_enabled]" value="1" <?php \checked($pfallback, '1'); ?>>
                                    <?php \esc_html_e('Enable intra-provider model fallback (if primary model fails, try next model)', 'seo-article-generator'); ?>
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label><?php \esc_html_e('Test', 'seo-article-generator'); ?></label></th>
                            <td>
                                <button type="button" class="button button-secondary seo-gen-test-custom-provider" data-provider-id="<?php echo $pid; ?>"><?php \esc_html_e('Test Connection', 'seo-article-generator'); ?></button>
                                <span class="seo-gen-custom-test-result" style="margin-left:10px;"></span>
                            </td>
                        </tr>
                        <?php
                        $is_or_card = \SEO_Article_Generator\AI\Provider_Registry::get_instance()->is_openrouter_compatible( $profile['api_url'] ?? '' );
                        if ( $is_or_card ) :
                            $or_last_sync = \SEO_Article_Generator\AI\OpenRouter_Model_Sync::get_last_sync_time();
                            $or_sync_class = $or_last_sync > 0 ? 'sync-ok' : 'sync-warn';
                            $or_sync_text  = $or_last_sync > 0
                                ? \sprintf( \__('Last synced: %s ago', 'seo-article-generator'), \human_time_diff( $or_last_sync, \current_time( 'timestamp' ) ) )
                                : \__('Never synced', 'seo-article-generator');
                        ?>
                        <tr class="seo-gen-openrouter-sync-row">
                            <th scope="row"><label><?php \esc_html_e('Free Models', 'seo-article-generator'); ?></label></th>
                            <td>
                                <div class="openrouter-sync-status <?php echo \esc_attr( $or_sync_class ); ?>">
                                    <span class="dashicons dashicons-update"></span>
                                    <span class="openrouter-sync-text"><?php echo \esc_html( $or_sync_text ); ?></span>
                                </div>
                                <button type="button" class="button button-small openrouter-sync-btn"><?php \esc_html_e('Sync Free Models', 'seo-article-generator'); ?></button>
                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php
                        $is_zen_card = \SEO_Article_Generator\AI\Provider_Registry::get_instance()->is_zen_url( $profile['api_url'] ?? '' );
                        if ( $is_zen_card ) :
                            $zen_last_sync = \SEO_Article_Generator\AI\OpenCode_Zen_Model_Sync::get_last_sync_time();
                            $zen_sync_class = $zen_last_sync > 0 ? 'sync-ok' : 'sync-warn';
                            $zen_sync_text  = $zen_last_sync > 0
                                ? \sprintf( \__('Last synced: %s ago', 'seo-article-generator'), \human_time_diff( $zen_last_sync, \current_time( 'timestamp' ) ) )
                                : \__('Never synced', 'seo-article-generator');
                        ?>
                        <tr class="seo-gen-zen-sync-row">
                            <th scope="row"><label><?php \esc_html_e('Free Models', 'seo-article-generator'); ?></label></th>
                            <td>
                                <div class="zen-sync-status <?php echo \esc_attr( $zen_sync_class ); ?>">
                                    <span class="dashicons dashicons-update"></span>
                                    <span class="zen-sync-text"><?php echo \esc_html( $zen_sync_text ); ?></span>
                                </div>
                                <button type="button" class="button button-small zen-sync-btn"><?php \esc_html_e('Sync Zen Models', 'seo-article-generator'); ?></button>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </table>
                    <input type="hidden" name="seo_gen_custom_providers[<?php echo $idx; ?>][id]" value="<?php echo $pid; ?>">
                </div>
                <?php endforeach; endif; ?>
            </div>

            <button type="button" class="button button-secondary" id="seo-gen-add-custom-provider" style="margin-top:10px;">
                <?php \esc_html_e('+ Add Custom Provider', 'seo-article-generator'); ?>
            </button>

            <template id="seo-gen-custom-provider-template">
                <div class="seo-gen-custom-provider-card" data-idx="{{IDX}}" style="background: #fff; border: 1px solid #c3c4c7; border-radius: 4px; padding: 20px; margin-bottom: 15px; position: relative;">
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
                        <h3 style="margin:0;" class="seo-gen-card-title"><?php \esc_html_e('New Custom Provider', 'seo-article-generator'); ?></h3>
                        <button type="button" class="button button-link-delete seo-gen-remove-provider"><?php \esc_html_e('Remove', 'seo-article-generator'); ?></button>
                    </div>
                    <table class="form-table" style="margin-top:0;">
                        <tr>
                            <th scope="row"><label><?php \esc_html_e('Provider Name', 'seo-article-generator'); ?></label></th>
                            <td><input type="text" class="seo-gen-tpl-name regular-text" placeholder="My Custom API" name="seo_gen_custom_providers[{{IDX}}][name]"></td>
                        </tr>
                        <tr>
                            <th scope="row"><label><?php \esc_html_e('API URL', 'seo-article-generator'); ?></label></th>
                            <td>
                                <input type="url" class="seo-gen-tpl-url large-text" placeholder="https://api.example.com/v1" name="seo_gen_custom_providers[{{IDX}}][api_url]">
                                <p class="description"><?php \esc_html_e('OpenAI-compatible endpoint. The /chat/completions path is appended automatically.', 'seo-article-generator'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label><?php \esc_html_e('API Key', 'seo-article-generator'); ?></label></th>
                            <td>
                                <div style="display:flex; align-items:center; gap:5px;">
                                    <input type="password" class="seo-gen-tpl-key regular-text" placeholder="Enter API key" name="seo_gen_custom_providers[{{IDX}}][api_key]">
                                    <button type="button" class="button seo-gen-toggle-key" onclick="var x=this.previousElementSibling; if(x.type==='password'){x.type='text';this.textContent='Hide';}else{x.type='password';this.textContent='Show';}">Show</button>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label><?php \esc_html_e('Models', 'seo-article-generator'); ?></label></th>
                            <td>
                                <div class="seo-gen-model-list" data-idx="{{IDX}}">
                                    <div class="seo-gen-model-row" style="display:flex; gap:8px; margin-bottom:8px; align-items:center;">
                                        <input type="text" class="seo-gen-tpl-model-id regular-text" placeholder="model-id" style="flex:1;" name="seo_gen_custom_providers[{{IDX}}][models][0][model_id]">
                                        <input type="text" class="seo-gen-tpl-model-name regular-text" placeholder="Display Name" style="flex:1;" name="seo_gen_custom_providers[{{IDX}}][models][0][display_name]">
                                        <button type="button" class="button seo-gen-remove-model" title="<?php \esc_html_e('Remove model', 'seo-article-generator'); ?>">&times;</button>
                                    </div>
                                </div>
                                <button type="button" class="button button-small seo-gen-add-model" data-idx="{{IDX}}"><?php \esc_html_e('+ Add Model', 'seo-article-generator'); ?></button>
                                <p class="description"><?php \esc_html_e('First model is primary. Subsequent models are used for intra-provider fallback.', 'seo-article-generator'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label><?php \esc_html_e('Response Format', 'seo-article-generator'); ?></label></th>
                            <td>
                                <label>
                                    <input type="checkbox" class="seo-gen-tpl-schema" value="1" checked name="seo_gen_custom_providers[{{IDX}}][supports_json_schema]">
                                    <?php \esc_html_e('Supports JSON Schema (structured output). Disable if the endpoint returns 400 with json_schema.', 'seo-article-generator'); ?>
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label><?php \esc_html_e('Web Search', 'seo-article-generator'); ?></label></th>
                            <td>
                                <label style="display:block; margin-bottom:6px;">
                                    <input type="checkbox" class="seo-gen-ws-toggle" data-idx="{{IDX}}" value="1" name="seo_gen_custom_providers[{{IDX}}][enable_web_search]">
                                    <?php \esc_html_e('Enable web search grounding', 'seo-article-generator'); ?>
                                </label>
                                <div class="seo-gen-ws-config" data-idx="{{IDX}}" style="display:none;">
                                    <select class="seo-gen-tpl-wstype" name="seo_gen_custom_providers[{{IDX}}][web_search_config][type]">
                                        <option value="none"><?php \esc_html_e('None', 'seo-article-generator'); ?></option>
                                        <option value="google_search"><?php \esc_html_e('Google Search (Gemini-style)', 'seo-article-generator'); ?></option>
                                        <option value="zhipuai"><?php \esc_html_e('ZhipuAI Web Search', 'seo-article-generator'); ?></option>
                                        <option value="kimi"><?php \esc_html_e('Kimi Web Search', 'seo-article-generator'); ?></option>
                                        <option value="minimax"><?php \esc_html_e('MiniMax Web Search', 'seo-article-generator'); ?></option>
                                    </select>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><label><?php \esc_html_e('Fallback', 'seo-article-generator'); ?></label></th>
                            <td>
                                <label>
                                    <input type="checkbox" class="seo-gen-tpl-fallback" value="1" checked name="seo_gen_custom_providers[{{IDX}}][fallback_enabled]">
                                    <?php \esc_html_e('Enable intra-provider model fallback', 'seo-article-generator'); ?>
                                </label>
                            </td>
                        </tr>
                        <tr style="display:none;">
                            <td><input type="hidden" name="seo_gen_custom_providers[{{IDX}}][id]" value=""></td>
                        </tr>
                        <tr>
                            <th scope="row"><label><?php \esc_html_e('Test', 'seo-article-generator'); ?></label></th>
                            <td>
                                <button type="button" class="button button-secondary seo-gen-test-custom-provider"><?php \esc_html_e('Test Connection', 'seo-article-generator'); ?></button>
                                <span class="seo-gen-custom-test-result" style="margin-left:10px;"></span>
                            </td>
                        </tr>
                    </table>
                </div>
            </template>
        </div>

        <!-- AUTOMATION TAB -->
<div id="sgd-pane-automation" class="sgd-pane <?php echo $active_tab === 'automation' ? 'active' : ''; ?>">
<h2><?php \esc_html_e('Automation & Publishing', 'seo-article-generator'); ?></h2>
<?php
$discovery_enabled     = (bool) get_option(\SEO_Article_Generator\Option_Registry::DISCOVERY_ENABLED, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::DISCOVERY_ENABLED]);
$rss_discovery_enabled = (bool) get_option(\SEO_Article_Generator\Option_Registry::RSS_DISCOVERY_ENABLED, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::RSS_DISCOVERY_ENABLED]);
$ai_discovery_enabled  = (bool) get_option(\SEO_Article_Generator\Option_Registry::AI_DISCOVERY_ENABLED, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::AI_DISCOVERY_ENABLED]);
?>
<table class="form-table">
<tr>
<th scope="row">
<label for="seo_gen_discovery_enabled"><?php esc_html_e('Discovery Engine', 'seo-article-generator'); ?></label>
</th>
<td>
<label>
<input type="checkbox" name="seo_gen_discovery_enabled" id="seo_gen_discovery_enabled" value="1" <?php \checked($discovery_enabled, true); ?> />
<?php esc_html_e('Enable the Discovery engine', 'seo-article-generator'); ?>
</label>
<p class="description"><?php esc_html_e('Master switch used by the Discovery dashboard and scheduler.', 'seo-article-generator'); ?></p>
</td>
</tr>

<tr>
                     <th scope="row">
                         <label for="seo_gen_rss_discovery_enabled"><?php esc_html_e('RSS Discovery', 'seo-article-generator'); ?></label>
                     </th>
                     <td>
                         <label>
                             <input type="checkbox" name="seo_gen_rss_discovery_enabled" id="seo_gen_rss_discovery_enabled" value="1" <?php \checked($rss_discovery_enabled, true); ?> />
                             <?php esc_html_e('Enable RSS-based discovery scans', 'seo-article-generator'); ?>
                         </label>
                     </td>
                 </tr>

                 <tr>
                     <th scope="row">
                         <label for="seo_gen_ai_discovery_enabled"><?php esc_html_e('AI Discovery', 'seo-article-generator'); ?></label>
                     </th>
                     <td>
                         <label>
                             <input type="checkbox" name="seo_gen_ai_discovery_enabled" id="seo_gen_ai_discovery_enabled" value="1" <?php \checked($ai_discovery_enabled, true); ?> />
                             <?php esc_html_e('Enable AI-powered discovery scans', 'seo-article-generator'); ?>
                         </label>
                     </td>
                 </tr>

                <tr>
                    <th scope="row">
                        <label for="seo_gen_discovery_publish_status">
                            <?php esc_html_e('Discovery New-Post Publish Status', 'seo-article-generator'); ?>
                        </label>
                    </th>
                    <td>
                        <select name="seo_gen_discovery_publish_status" id="seo_gen_discovery_publish_status">
                            <option value="publish" <?php \selected($publish_status, 'publish'); ?>>
                                <?php esc_html_e('Publish Immediately', 'seo-article-generator'); ?>
                            </option>
                            <option value="draft" <?php \selected($publish_status, 'draft'); ?>>
                                <?php esc_html_e('Save as Draft', 'seo-article-generator'); ?>
                            </option>
                        </select>
                        <p class="description">
                            <?php esc_html_e('Applies only when Discovery creates a NEW post after approval. Existing-post updates always write back to the existing post; use the scheduling controls below to throttle when updates are finalized.', 'seo-article-generator'); ?>
                        </p>
                    </td>
                </tr>

                 <tr>
                     <th scope="row">
                         <label for="seo_gen_daily_quota"><?php \esc_html_e('Daily API Quota', 'seo-article-generator'); ?></label>
                     </th>
                     <td>
                         <input type="number" name="seo_gen_daily_quota" id="seo_gen_daily_quota" value="<?php echo (int) get_option(\SEO_Article_Generator\Option_Registry::DAILY_QUOTA, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::DAILY_QUOTA]); ?>" class="small-text">
                         <p class="description">
                             <?php \esc_html_e('Maximum number of AI search checks allowed per day across discovery tasks.', 'seo-article-generator'); ?>
                         </p>
                     </td>
                 </tr>

                <tr>
                    <th scope="row">
                        <label><?php \esc_html_e('Global Draft Retention', 'seo-article-generator'); ?></label>
                    </th>
                    <td>
                        <input type="number" name="seo_gen_draft_retention_days" value="<?php echo \esc_attr($retention_days); ?>" min="0" max="90" class="small-text" />
                        <?php \_e('days', 'seo-article-generator'); ?>
                        <p class="description">
                            <?php \_e('How long processed drafts (from both Discovery and WP Auto sources) remain before automatic deletion. Set to 0 to delete immediately. Recommended: 2 days.', 'seo-article-generator'); ?>
                        </p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label><?php \esc_html_e('Discovery Generation Sections', 'seo-article-generator'); ?></label>
                    </th>
                    <td>
                        <?php
                         $default_discovery_sections = \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::DISCOVERY_SECTIONS];

                        $allowed_discovery_sections = array(
                            'all',
                            'introduction',
                            'features',
                            'tech_specs',
                            'download',
                            'pros_cons',
                            'competitors',
                            'faqs',
                            'installation',
                            'moat',
                            'whats_new',
                            'hero',
                            'relatedsoftware',
                            'toc',
                        );

                         $discovery_sections = get_option(\SEO_Article_Generator\Option_Registry::DISCOVERY_SECTIONS, $default_discovery_sections);

                        if (!is_array($discovery_sections)) {
                            $discovery_sections = $default_discovery_sections;
                        }

                        $discovery_sections = array_values(
                            array_unique(
                                array_filter(
                                    array_map('strval', $discovery_sections),
                                    static function ($section) use ($allowed_discovery_sections) {
                                        return in_array($section, $allowed_discovery_sections, true);
                                    }
                                )
                            )
                        );

                        if (in_array('all', $discovery_sections, true)) {
                            $discovery_sections = array('all');
                        }

                        if (empty($discovery_sections)) {
                            $discovery_sections = $default_discovery_sections;
                        }
                        $available_sections = [
                            'introduction' => __('Introduction', 'seo-article-generator'),
                            'features'     => __('Features List', 'seo-article-generator'),
                            'tech_specs'   => __('Tech Specs', 'seo-article-generator'),
                            'download'     => __('Download Links', 'seo-article-generator'),
                            'pros_cons'    => __('Pros and Cons', 'seo-article-generator'),
                            'competitors'  => __('Competitor Table', 'seo-article-generator'),
                            'faqs'         => __('FAQs', 'seo-article-generator'),
                            'installation' => __('Installation Guide', 'seo-article-generator'),
                            'moat'         => __('Moat Content', 'seo-article-generator'),
                            'whats_new'    => __("What's New", 'seo-article-generator'),
                            'hero'         => __('Hero Meta Data', 'seo-article-generator'),
                            'relatedsoftware' => __('Related Software', 'seo-article-generator'),
                            'toc'          => __('Table of Contents', 'seo-article-generator'),
                        ];
                        ?>
                        <label style="display:block;margin-bottom:10px;">
                            <input type="checkbox" name="seo_gen_discovery_sections[]" value="all" <?php \checked(\in_array('all', $discovery_sections)); ?>>
                            <strong><?php \esc_html_e('Full Article (Recommended)', 'seo-article-generator'); ?></strong>
                        </label>
                        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px;">
                            <?php foreach ($available_sections as $value => $label): ?>
                                <label>
                                    <input type="checkbox" name="seo_gen_discovery_sections[]" value="<?php echo \esc_attr($value); ?>" <?php \checked(\in_array($value, $discovery_sections) || \in_array('all', $discovery_sections)); ?>>
                                    <?php echo \esc_html($label); ?>
                                </label>
                            <?php endforeach; ?>
                        </div>
                        <p class="description">
		<?php \esc_html_e('Sections to include when generating NEW posts or updating LEGACY posts via Discovery.', 'seo-article-generator'); ?>
		</p>
		</td>
		</tr>

		<tr>
		<th scope="row">
		<label for="<?php echo \esc_attr(\SEO_Article_Generator\Option_Registry::ENABLE_PORTABLE_DISCOVERY); ?>">
		<?php \esc_html_e('Portable Version Discovery', 'seo-article-generator'); ?>
		</label>
		</th>
		<td>
		<label>
		<input type="checkbox" name="<?php echo \esc_attr(\SEO_Article_Generator\Option_Registry::ENABLE_PORTABLE_DISCOVERY); ?>" id="<?php echo \esc_attr(\SEO_Article_Generator\Option_Registry::ENABLE_PORTABLE_DISCOVERY); ?>" value="1" <?php \checked($enable_portable_discovery, true); ?>>
		<?php \esc_html_e('Instruct AI to search for portable versions of software', 'seo-article-generator'); ?>
		</label>
		<p class="description">
		<?php \esc_html_e('When enabled, the AI will attempt to find portable/standalone editions (e.g. from PortableApps.com or GitHub releases). Disable if the AI is incorrectly using the software homepage as a portable download link.', 'seo-article-generator'); ?>
		</p>
	</td>
	</tr>

	<tr>
	<th scope="row">
	<label for="<?php echo \esc_attr(\SEO_Article_Generator\Option_Registry::DOWNLOAD_ALLOWLIST); ?>">
	<?php \esc_html_e('Download URL Allowlist', 'seo-article-generator'); ?>
	</label>
	</th>
	<td>
	<textarea name="<?php echo \esc_attr(\SEO_Article_Generator\Option_Registry::DOWNLOAD_ALLOWLIST); ?>" id="<?php echo \esc_attr(\SEO_Article_Generator\Option_Registry::DOWNLOAD_ALLOWLIST); ?>" rows="5" class="large-text code"><?php echo \esc_textarea((string) get_option(\SEO_Article_Generator\Option_Registry::DOWNLOAD_ALLOWLIST, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::DOWNLOAD_ALLOWLIST])); ?></textarea>
	<p class="description">
	<?php \esc_html_e('One entry per line. Full URLs (e.g. https://example.com/download) bypass the homepage collision guard. Bare domains (e.g. dl.google.com, portableapps.com) — with or without a path — also bypass the URL length filter and the homepage collision guard; use for trusted download hosts whose URLs contain tracking parameters. Subdomains are automatically included.', 'seo-article-generator'); ?>
	</p>
	</td>
	</tr>

	<tr>
	<th scope="row">
	<label for="<?php echo \esc_attr(\SEO_Article_Generator\Option_Registry::DOWNLOAD_DOMAIN_DENYLIST); ?>">
	<?php \esc_html_e('Download Domain Denylist', 'seo-article-generator'); ?>
	</label>
	</th>
	<td>
	<textarea name="<?php echo \esc_attr(\SEO_Article_Generator\Option_Registry::DOWNLOAD_DOMAIN_DENYLIST); ?>" id="<?php echo \esc_attr(\SEO_Article_Generator\Option_Registry::DOWNLOAD_DOMAIN_DENYLIST); ?>" rows="5" class="large-text code"><?php echo \esc_textarea((string) get_option(\SEO_Article_Generator\Option_Registry::DOWNLOAD_DOMAIN_DENYLIST, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::DOWNLOAD_DOMAIN_DENYLIST])); ?></textarea>
	<p class="description">
	<?php \esc_html_e('One domain per line. URLs from these domains will be rejected as affiliate/tracking links (e.g. prf.hn, awin1.com, shareasale.com). Covers PartnerStack, Awin, ShareASale, CJ, Impact, and other affiliate networks. Add new domains as encountered.', 'seo-article-generator'); ?>
	</p>
	</td>
	</tr>

	<tr>
	<th scope="row">
	<label><?php \esc_html_e('AI Update Sections', 'seo-article-generator'); ?></label>
	</th>
                    <td>
<?php
$default_update_sections = \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::UPDATE_SECTIONS];

                        $allowed_update_sections = array(
                            'introduction',
                            'features',
                            'tech_specs',
                            'download',
                            'pros_cons',
                            'competitors',
                            'faqs',
                            'installation',
                            'moat',
                            'hero',
                            'relatedsoftware',
                            'toc',
                            'whats_new',
                        );

                         $update_sections = get_option(\SEO_Article_Generator\Option_Registry::UPDATE_SECTIONS, $default_update_sections);

                        if (!is_array($update_sections)) {
                            $update_sections = $default_update_sections;
                        }

                        $update_sections = array_values(
                            array_unique(
                                array_filter(
                                    array_map('strval', $update_sections),
                                    static function ($section) use ($allowed_update_sections) {
                                        return in_array($section, $allowed_update_sections, true);
                                    }
                                )
                            )
                        );

                        if (empty($update_sections)) {
                            $update_sections = $default_update_sections;
                        }
                        $available_update_sections = [
                            'introduction'    => __('Introduction', 'seo-article-generator'),
                            'features'       => __('Features List', 'seo-article-generator'),
                            'tech_specs'     => __('Tech Specs', 'seo-article-generator'),
                            'download'       => __('Download Links', 'seo-article-generator'),
                            'pros_cons'      => __('Pros and Cons', 'seo-article-generator'),
                            'competitors'    => __('Competitor Table', 'seo-article-generator'),
                            'faqs'           => __('FAQs', 'seo-article-generator'),
                            'installation'   => __('Installation Guide', 'seo-article-generator'),
                            'moat'           => __('Moat Content', 'seo-article-generator'),
                            'whats_new'      => __("What's New", 'seo-article-generator'),
                            'hero'           => __('Hero Meta Data', 'seo-article-generator'),
                            'relatedsoftware' => __('Related Software', 'seo-article-generator'),
                        ];
                        ?>
                        <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px;">
                            <?php foreach ($available_update_sections as $value => $label): ?>
                                <label>
                                    <input type="checkbox" name="seo_gen_update_sections[]" value="<?php echo \esc_attr($value); ?>" <?php \checked(\in_array($value, $update_sections)); ?>>
                                    <?php echo \esc_html($label); ?>
                                </label>
                            <?php endforeach; ?>
                        </div>
                        <p class="description">
                            <?php \esc_html_e('Sections to update when an existing post already exists (Plugin Generated).', 'seo-article-generator'); ?>
                        </p>
                    </td>
                </tr>

                <!-- @MODIFIED 2026-03-05: Auto-Generation Settings -->
                <tr>
                    <th scope="row">
                        <label for="seo_gen_enable_auto_generation"><?php \esc_html_e('Auto-Generation', 'seo-article-generator'); ?></label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="seo_gen_enable_auto_generation" id="seo_gen_enable_auto_generation" value="1" <?php \checked($enable_auto_gen, true); ?>>
                            <?php \esc_html_e('Automatically process items from Staging to Generation', 'seo-article-generator'); ?>
                        </label>
                        <p class="description"><?php \esc_html_e('Enable System 1: Auto-approve staging items based on interval.', 'seo-article-generator'); ?></p>
                    </td>
                </tr>

                <tr class="auto-gen-row" <?php echo !$enable_auto_gen ? 'style="display:none;"' : ''; ?>>
                    <th scope="row">
                        <label for="seo_gen_auto_generation_interval"><?php \esc_html_e('Auto-Generation Interval', 'seo-article-generator'); ?></label>
                    </th>
                    <td>
                        <input type="number" name="seo_gen_auto_generation_interval" id="seo_gen_auto_generation_interval" value="<?php echo \esc_attr((int) $auto_gen_interval); ?>" min="5" max="1440" step="1" class="small-text">
                        <p class="description"><?php \esc_html_e('Interval in minutes (minimum 5, maximum 1440).', 'seo-article-generator'); ?></p>
                    </td>
                </tr>

                <tr class="auto-gen-row" <?php echo !$enable_auto_gen ? 'style="display:none;"' : ''; ?>>
                    <th scope="row">
                        <label for="seo_gen_auto_generation_batch"><?php \esc_html_e('Batch Size', 'seo-article-generator'); ?></label>
                    </th>
                    <td>
                        <input type="number" name="seo_gen_auto_generation_batch" id="seo_gen_auto_generation_batch" value="<?php echo \esc_attr($auto_gen_batch); ?>" min="1" max="10" step="1" class="small-text">
                        <p class="description">
                            <?php \esc_html_e('Number of items to process per interval (Max 10).', 'seo-article-generator'); ?>
                        </p>
                    </td>
</tr>

<!-- @MODIFIED 2026-04-24: Category & Tag Mapping Settings -->
<tr>
<th scope="row">
<label for="<?php echo \esc_attr(\SEO_Article_Generator\Option_Registry::CATEGORY_KEYWORD_MAP); ?>">
<?php \esc_html_e('Category Keyword Map', 'seo-article-generator'); ?>
</label>
</th>
<td>
<textarea name="<?php echo \esc_attr(\SEO_Article_Generator\Option_Registry::CATEGORY_KEYWORD_MAP); ?>" id="<?php echo \esc_attr(\SEO_Article_Generator\Option_Registry::CATEGORY_KEYWORD_MAP); ?>" rows="5" class="large-text code"><?php echo \esc_textarea((string) get_option(\SEO_Article_Generator\Option_Registry::CATEGORY_KEYWORD_MAP, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::CATEGORY_KEYWORD_MAP])); ?></textarea>
<p class="description">
<?php \esc_html_e('Override or extend the default keyword→category mapping. One rule per line. Format: keyword1, keyword2 => category-slug. Example: disk cleaner, privacy => security-privacy. These take priority over the built-in defaults.', 'seo-article-generator'); ?>
</p>
</td>
</tr>

<tr>
<th scope="row">
<label for="<?php echo \esc_attr(\SEO_Article_Generator\Option_Registry::TAG_BLOCKLIST); ?>">
<?php \esc_html_e('Tag Blocklist', 'seo-article-generator'); ?>
</label>
</th>
<td>
<textarea name="<?php echo \esc_attr(\SEO_Article_Generator\Option_Registry::TAG_BLOCKLIST); ?>" id="<?php echo \esc_attr(\SEO_Article_Generator\Option_Registry::TAG_BLOCKLIST); ?>" rows="3" class="large-text code"><?php echo \esc_textarea((string) get_option(\SEO_Article_Generator\Option_Registry::TAG_BLOCKLIST, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::TAG_BLOCKLIST])); ?></textarea>
<p class="description">
<?php \esc_html_e('Comma-separated generic tags to reject. These tags are never assigned to posts. Defaults include: software, download, free download, utility, app, application, etc.', 'seo-article-generator'); ?>
</p>
</td>
</tr>

<tr>
<th scope="row">
<label for="<?php echo \esc_attr(\SEO_Article_Generator\Option_Registry::TAG_MAX_COUNT); ?>">
<?php \esc_html_e('Max Tags Per Post', 'seo-article-generator'); ?>
</label>
</th>
<td>
<input type="number" name="<?php echo \esc_attr(\SEO_Article_Generator\Option_Registry::TAG_MAX_COUNT); ?>" id="<?php echo \esc_attr(\SEO_Article_Generator\Option_Registry::TAG_MAX_COUNT); ?>" value="<?php echo \esc_attr((string) get_option(\SEO_Article_Generator\Option_Registry::TAG_MAX_COUNT, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::TAG_MAX_COUNT])); ?>" min="3" max="20" step="1" class="small-text">
<p class="description">
<?php \esc_html_e('Maximum number of tags assigned to a post (minimum 3). Deterministic pipeline: categories-as-tags + software name + license type.', 'seo-article-generator'); ?>
</p>
</td>
</tr>

</table>

<hr />
<h2><?php \esc_html_e('Scheduling Settings', 'seo-article-generator'); ?></h2>
<p class="description">
                <?php \esc_html_e('Configure when newly discovered and updated posts should be published. Posts are only published (or updated) within the configured time range.', 'seo-article-generator'); ?>
            </p>

            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="seo_gen_enable_scheduling"><?php \esc_html_e('Enable Scheduling', 'seo-article-generator'); ?></label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="seo_gen_enable_scheduling" id="seo_gen_enable_scheduling" value="1" <?php \checked($enable_scheduling, true); ?>>
                            <?php \esc_html_e('Schedule new posts instead of immediate publishing', 'seo-article-generator'); ?>
                        </label>
                    </td>
                </tr>

                <tr class="scheduling-row" <?php echo !$enable_scheduling ? 'style="display:none;"' : ''; ?>>
                    <th scope="row">
                        <label for="seo_gen_publish_window"><?php \esc_html_e('Publishing Window', 'seo-article-generator'); ?></label>
                    </th>
                    <td>
                        <input type="time" name="seo_gen_publish_start" value="<?php echo \esc_attr($publish_start); ?>">
                        to
                        <input type="time" name="seo_gen_publish_end" value="<?php echo \esc_attr($publish_end); ?>">
                        <p class="description">
                            <?php \esc_html_e('Posts will only be scheduled within this time range.', 'seo-article-generator'); ?>
                        </p>
                    </td>
                </tr>

                <tr class="scheduling-row" <?php echo !$enable_scheduling ? 'style="display:none;"' : ''; ?>>
                    <th scope="row">
                        <label for="seo_gen_posts_per_day"><?php \esc_html_e('Max Posts Per Day', 'seo-article-generator'); ?></label>
                    </th>
                    <td>
                        <input type="number" name="seo_gen_posts_per_day" value="<?php echo \esc_attr($posts_per_day); ?>" min="1" step="1" class="small-text">
                        <p class="description">
                            <?php \esc_html_e('Maximum number of posts to schedule per day.', 'seo-article-generator'); ?>
                        </p>
                    </td>
                </tr>

                <tr class="scheduling-row" <?php echo !$enable_scheduling ? 'style="display:none;"' : ''; ?>>
                    <th scope="row">
                        <label><?php \esc_html_e('Clumping Protection', 'seo-article-generator'); ?></label>
                    </th>
                    <td>
                        <input type="number" name="seo_gen_publish_interval_min" value="<?php echo \esc_attr($publish_interval_min); ?>" min="1" step="1" class="small-text">
                        to
                        <input type="number" name="seo_gen_publish_interval_max" value="<?php echo \esc_attr($publish_interval_max); ?>" min="1" step="1" class="small-text">
                        <?php \esc_html_e('minutes between posts', 'seo-article-generator'); ?>
                        <p class="description">
                            <?php \esc_html_e('A random gap within this range (in minutes) will be added between scheduled NEW posts to prevent clumping and API rate limiting.', 'seo-article-generator'); ?>
                        </p>
                    </td>
                </tr>

<!-- @MODIFIED 2026-03-08: Update Generation Delay -->
<tr class="scheduling-row" <?php echo !$enable_scheduling ? 'style="display:none;"' : ''; ?>>
<th scope="row">
<label><?php \esc_html_e('Update Staggering', 'seo-article-generator'); ?></label>
</th>
<td>
<input type="number" name="seo_gen_update_delay_min" value="<?php echo (int) get_option(\SEO_Article_Generator\Option_Registry::UPDATE_DELAY_MIN, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::UPDATE_DELAY_MIN]); ?>" min="1" step="1" class="small-text">
to
<input type="number" name="seo_gen_update_delay_max" value="<?php echo (int) get_option(\SEO_Article_Generator\Option_Registry::UPDATE_DELAY_MAX, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::UPDATE_DELAY_MAX]); ?>" min="1" step="1" class="small-text">
<?php \esc_html_e('minutes delay', 'seo-article-generator'); ?>
</p>
</td>
</tr>

                <!-- @MODIFIED 2026-03-08: Daily Update Cap -->
                <tr class="scheduling-row" <?php echo !$enable_scheduling ? 'style="display:none;"' : ''; ?>>
                    <th scope="row">
                        <label for="seo_gen_updates_per_day"><?php \esc_html_e('Max Updates Per Day', 'seo-article-generator'); ?></label>
                    </th>
                    <td>
                        <input type="number" name="seo_gen_updates_per_day" id="seo_gen_updates_per_day" value="<?php echo \esc_attr($updates_per_day); ?>" min="1" step="1" class="small-text">
                        <p class="description">
                            <?php \esc_html_e('Maximum number of legacy or updated posts to process per day. Set to 15 by default.', 'seo-article-generator'); ?>
                        </p>
                    </td>
                </tr>

                <tr class="scheduling-row" <?php echo !$enable_scheduling ? 'style="display:none;"' : ''; ?>>
                    <th scope="row">
                        <label><?php \esc_html_e('Active Days', 'seo-article-generator'); ?></label>
                    </th>
                    <td>
                        <?php
                        $days = [
                            'mon' => __('Monday', 'seo-article-generator'),
                            'tue' => __('Tuesday', 'seo-article-generator'),
                            'wed' => __('Wednesday', 'seo-article-generator'),
                            'thu' => __('Thursday', 'seo-article-generator'),
                            'fri' => __('Friday', 'seo-article-generator'),
                            'sat' => __('Saturday', 'seo-article-generator'),
                            'sun' => __('Sunday', 'seo-article-generator'),
                        ];
                        foreach ($days as $key => $label):
                        ?>
                            <label style="margin-right: 15px;">
                                <input type="checkbox" name="seo_gen_active_days[]" value="<?php echo $key; ?>" <?php \checked(\in_array($key, $active_days), true); ?>>
                                <?php echo \esc_html($label); ?>
                            </label>
                        <?php endforeach; ?>
                    </td>
                </tr>
            </table>
        </div>

        <!-- HEALTH TAB -->
        <div id="sgd-pane-health" class="sgd-pane <?php echo $active_tab === 'health' ? 'active' : ''; ?>">
            <h2><?php \esc_html_e('System Health', 'seo-article-generator'); ?></h2>
            
            <!-- Dashboard Integration Section -->
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="seo_gen_dashboard_api_key"><?php \esc_html_e('Dashboard API Key', 'seo-article-generator'); ?></label>
                    </th>
                    <td>
                        <input type="text" name="seo_gen_dashboard_api_key" id="seo_gen_dashboard_api_key" 
                            class="regular-text code" value="<?php echo \esc_attr(get_option(\SEO_Article_Generator\Option_Registry::DASHBOARD_API_KEY, '')); ?>" placeholder="<?php \esc_attr_e('Auto-generate or enter manually', 'seo-article-generator'); ?>">
                        <p class="description">
                            <?php \esc_html_e('API key for the Universal Plugin Dashboard to access this site\'s metrics. Leave empty to auto-generate on save.', 'seo-article-generator'); ?>
                        </p>
                        <button type="button" class="button button-secondary" id="seo-gen-generate-dashboard-key">
                            <?php \esc_html_e('Generate New Key', 'seo-article-generator'); ?>
                        </button>
                    </td>
                </tr>
            </table>
            
            <hr />
            
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <?php \esc_html_e('Diagnostic Test', 'seo-article-generator'); ?>
                    </th>
                    <td>
                        <button type="button" class="button button-secondary" id="seo-gen-run-smoke-test">
                            <?php \esc_html_e('Run Comprehensive Smoke Test', 'seo-article-generator'); ?>
                        </button>
                        <p class="description">
                            <?php \esc_html_e('Runs automated tests covering PHP, database, file integrity, and more.', 'seo-article-generator'); ?>
                        </p>
                        <div id="smoke-test-results" style="display:none; margin-top: 20px;"></div>
                    </td>
                </tr>
            </table>
        </div>

        <!-- BACKFILL TAB -->
        <div id="sgd-pane-backfill" class="sgd-pane <?php echo $active_tab === 'backfill' ? 'active' : ''; ?>">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 20px;">
                <div>
                    <h2 style="border:none; padding-bottom:0;"><?php \esc_html_e('Sentinel Retroactive Backfill', 'seo-article-generator'); ?></h2>
                    <p class="description"><?php \esc_html_e('Scans legacy posts, standardizes canonical section markers, and marks migrated posts with a plugin content contract for reliable future updates.', 'seo-article-generator'); ?></p>
                </div>
                <div id="backfill-stats-summary" style="display:flex; gap:15px;">
                    <div class="backfill-stat-card alternative" id="bf-potential-card" style="background:#fcf8ed; border:1px solid #f0b849;">
                        <span class="label" style="color:#856404;"><?php \esc_html_e('Unidentified (Software)', 'seo-article-generator'); ?></span>
                        <span class="value" id="bf-stat-potential" style="color:#856404;">-</span>
                    </div>
                    <div class="backfill-stat-card" id="bf-missing-names-card" style="background:#f0f6fc; border:1px solid #2271b1;">
                        <span class="label" style="color:#1d2327;"><?php \esc_html_e('Missing Software Name', 'seo-article-generator'); ?></span>
                        <span class="value" id="bf-stat-missing-names" style="color:#2271b1;">-</span>
                    </div>
                    <div class="backfill-stat-card">
                        <span class="label"><?php \esc_html_e('Backfill Total', 'seo-article-generator'); ?></span>
                        <span class="value" id="bf-stat-total">-</span>
                    </div>
                    <div class="backfill-stat-card highlight">
                        <span class="label"><?php \esc_html_e('Pending', 'seo-article-generator'); ?></span>
                        <span class="value" id="bf-stat-pending">-</span>
                    </div>
                    <div class="backfill-stat-card" id="bf-failed-card" style="background:#fff0f0; border:1px solid #dc3232;">
                        <span class="label" style="color:#721c24;"><?php \esc_html_e('Needs Regen', 'seo-article-generator'); ?></span>
                        <span class="value" id="bf-stat-failed" style="color:#dc3232;">-</span>
                    </div>
                </div>
            </div>

            <div class="backfill-controls" style="background: #f6f7f7; padding: 20px; border: 1px solid #c3c4c7; border-radius: 4px; margin-bottom: 20px;">
                <div style="display:flex; flex-direction:column; gap:15px;">
                    <div style="display:flex; align-items:flex-start; gap:25px; border-bottom:1px solid #dcdcde; padding-bottom:15px; margin-bottom:5px; flex-wrap: wrap;">
                        <div style="display:flex; align-items:center; gap:8px; flex-wrap: wrap;">
                            <strong style="white-space: nowrap;"><?php \esc_html_e('1. Identify Legacy Posts:', 'seo-article-generator'); ?></strong>
                            <?php
                            $categories = get_categories(['hide_empty' => 0]);
                            $default_cat = (int) get_option(\SEO_Article_Generator\Option_Registry::DEFAULT_CATEGORY, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::DEFAULT_CATEGORY]);
                            ?>
                            <select id="bf-identify-cat" style="max-width:200px;">
                                <option value="0"><?php \esc_html_e('-- All Categories --', 'seo-article-generator'); ?></option>
                                <?php foreach($categories as $cat): ?>
                                    <option value="<?php echo (int) $cat->term_id; ?>" <?php selected($cat->term_id, $default_cat); ?>><?php echo esc_html($cat->name); ?></option>
                                <?php endforeach; ?>
                            </select>

                            <select id="bf-exclude-cats" multiple style="min-width:260px; min-height:90px;">
                                <?php foreach($categories as $cat): ?>
                                    <option value="<?php echo (int) $cat->term_id; ?>">
                                        <?php echo esc_html($cat->name); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div style="display:flex; align-items:center; gap:8px; flex-wrap: wrap; margin-left: auto;">
                            <button type="button" class="button" id="bf-identify-btn">
                                <?php \esc_html_e('Scan & Tag Software Posts', 'seo-article-generator'); ?>
                            </button>

                            <button type="button" class="button" id="bf-backfill-names-btn" style="background: #2271b1; color: #fff; border-color: #2271b1;">
                                <?php \esc_html_e('Backfill Software Names', 'seo-article-generator'); ?>
                            </button>

                            <button type="button" class="button" id="bf-purge-unknown-btn" style="color: #d63638; border-color: #d63638;">
                                <?php \esc_html_e( 'Purge Unknown-Version Tags', 'seo-article-generator' ); ?>
                            </button>
                        </div>
                    </div>
                    <p class="description" style="margin:6px 0 0 0;">
                        <?php \esc_html_e('Select one include category, and optionally exclude one or more categories from both identification and backfill.', 'seo-article-generator'); ?>
                    </p>

                    <div style="display:flex; align-items:center; gap:25px;">
                        <div style="display:flex; align-items:center; gap:8px;">
                            <strong><?php \esc_html_e('2. Run Backfill:', 'seo-article-generator'); ?></strong>
                            <label style="display:flex; align-items:center; gap:4px; margin-left:10px;">
                                <input type="checkbox" id="bf-dry-run" checked> 
                                <?php \esc_html_e('Dry Run', 'seo-article-generator'); ?>
                            </label>
                        </div>

                        <label style="display:flex; align-items:center; gap:8px;">
                            <?php \esc_html_e('Batch:', 'seo-article-generator'); ?>
                            <input type="number" id="bf-limit" value="25" min="1" max="25" style="width:60px;">
                        </label>

                        <div style="flex-grow:1; display:flex; gap:10px; justify-content:flex-end;">
                            <button type="button" class="button button-primary" id="bf-start-btn" style="min-width:140px; height:32px;">
                                <?php \esc_html_e('Start Backfill', 'seo-article-generator'); ?>
                            </button>
                            
                            <button type="button" class="button" id="bf-stop-btn" style="display:none; color: #d63638; border-color: #d63638; height:32px;">
                                <?php \esc_html_e('Stop', 'seo-article-generator'); ?>
                            </button>

                            <button type="button" class="button" id="bf-refresh-btn" style="height:32px;">
                                <?php \esc_html_e('Refresh Stats', 'seo-article-generator'); ?>
                            </button>

                            <button type="button" class="button" id="bf-clear-failed-btn" style="height:32px; color: #b35c00; border-color: #b35c00;">
                                <?php \esc_html_e('Clear Failed & Retry', 'seo-article-generator'); ?>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div id="bf-progress-container" style="display:none; margin-bottom:20px;">
                <div class="bf-progress-bar-wrap" style="height:24px; background:#dcdcde; border-radius:12px; position:relative; overflow:hidden;">
                    <div id="bf-progress-bar" style="height:100%; width:0%; background:#2271b1; transition: width 0.3s ease;"></div>
                    <span id="bf-progress-text" style="position:absolute; width:100%; text-align:center; top:0; line-height:24px; font-weight:600; color:#fff; text-shadow:0 1px 2px rgba(0,0,0,0.3);">0%</span>
                </div>
            </div>

            <div class="bf-console-wrap" style="background:#1d2327; color:#f0f0f1; border-radius:4px; padding:15px; font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace; font-size:12px; line-height:1.5;">
                <div style="margin-bottom:10px; color:#72aee6; font-weight:700; border-bottom:1px solid #3c434a; padding-bottom:5px;">
                    PROCESS LOG
                </div>
                <div id="bf-console" style="max-height:350px; overflow-y:auto; scroll-behavior:smooth;">
                    <div style="color:#8c8f94;">> System ready. Awaiting initialization...</div>
                </div>
            </div>
        </div>

        <!-- CANONICAL SLUG MIGRATION TAB -->
        <div id="sgd-pane-migration" class="sgd-pane <?php echo $active_tab === 'migration' ? 'active' : ''; ?>">
            <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 20px;">
                <div>
                    <h2 style="border:none; padding-bottom:0;"><?php \esc_html_e('Canonical Slug Migration', 'seo-article-generator'); ?></h2>
                    <p class="description"><?php \esc_html_e('Migrate versioned slugs (e.g., <code>mozilla-firefox-920-final</code>) to clean, evergreen slugs (e.g., <code>mozilla-firefox</code>) with Rank Math 301 redirects. Dry-run first, then batch migrate with rollback support.', 'seo-article-generator'); ?></p>
                </div>
                <div id="migration-status-summary" style="display:flex; gap:15px;">
                    <div class="migration-stat-card" id="mig-total-card" style="background:#f0f6fc; border:1px solid #2271b1;">
                        <span class="label" style="color:#1d2327;"><?php \esc_html_e('Versioned Posts', 'seo-article-generator'); ?></span>
                        <span class="value" id="mig-stat-total" style="color:#2271b1;">-</span>
                    </div>
                    <div class="migration-stat-card" id="mig-done-card" style="background:#e8f5e9; border:1px solid #2e7d32;">
                        <span class="label" style="color:#1b5e20;"><?php \esc_html_e('Migrated', 'seo-article-generator'); ?></span>
                        <span class="value" id="mig-stat-done" style="color:#2e7d32;">0</span>
                    </div>
                    <div class="migration-stat-card" id="mig-failed-card" style="background:#fff0f0; border:1px solid #dc3232;">
                        <span class="label" style="color:#721c24;"><?php \esc_html_e('Failed', 'seo-article-generator'); ?></span>
                        <span class="value" id="mig-stat-failed" style="color:#dc3232;">0</span>
                    </div>
                    <div class="migration-stat-card" id="mig-rollback-card" style="background:#f3e5f5; border:1px solid #7b1fa2;">
                        <span class="label" style="color:#4a148c;"><?php \esc_html_e('Rollback Ready', 'seo-article-generator'); ?></span>
                        <span class="value" id="mig-stat-rollback" style="color:#7b1fa2;"><?php \esc_html_e('Yes', 'seo-article-generator'); ?></span>
                    </div>
                </div>
            </div>

            <div class="migration-controls" style="background: #f6f7f7; padding: 20px; border: 1px solid #c3c4c7; border-radius: 4px; margin-bottom: 20px;">
                <div style="display:flex; flex-direction:column; gap:15px;">
                    <div style="display:flex; align-items:center; gap:25px; border-bottom:1px solid #dcdcde; padding-bottom:15px; margin-bottom:5px; flex-wrap: wrap;">
                        <div style="display:flex; align-items:center; gap:8px; flex-wrap: wrap;">
                            <strong style="white-space: nowrap;"><?php \esc_html_e('1. Preview Changes (Dry Run):', 'seo-article-generator'); ?></strong>
                            <label style="display:flex; align-items:center; gap:4px; margin-left:10px;">
                                <input type="number" id="mig-dry-run-limit" value="20" min="1" max="100" style="width:70px;">
                                <?php \esc_html_e('posts', 'seo-article-generator'); ?>
                            </label>
                            <button type="button" class="button" id="mig-dry-run-btn">
                                <?php \esc_html_e('Preview Migration', 'seo-article-generator'); ?>
                            </button>
                        </div>
                    </div>

                    <div id="mig-preview-table-wrap" style="display:none; margin-top:15px; overflow-x:auto;">
                        <table class="wp-list-table widefat fixed striped">
                            <thead>
                                <tr>
                                    <th><?php \esc_html_e('Post ID', 'seo-article-generator'); ?></th>
                                    <th><?php \esc_html_e('Title', 'seo-article-generator'); ?></th>
                                    <th><?php \esc_html_e('Old Slug (Versioned)', 'seo-article-generator'); ?></th>
                                    <th><?php \esc_html_e('New Slug (Clean)', 'seo-article-generator'); ?></th>
                                    <th><?php \esc_html_e('Will Migrate', 'seo-article-generator'); ?></th>
                                </tr>
                            </thead>
                            <tbody id="mig-preview-body"></tbody>
                        </table>
                    </div>

                    <div style="display:flex; align-items:center; gap:25px; border-top:1px solid #dcdcde; padding-top:15px; margin-top:10px; flex-wrap: wrap;">
                         <div style="display:flex; align-items:center; gap:8px;">
                             <strong><?php \esc_html_e('2. Run Migration:', 'seo-article-generator'); ?></strong>
                             <label style="display:flex; align-items:center; gap:4px; margin-left:10px;">
                                 <input type="number" id="mig-batch-size" value="10" min="1" max="50" style="width:70px;">
                                 <?php \esc_html_e('batch size', 'seo-article-generator'); ?>
                             </label>
                             <label style="display:flex; align-items:center; gap:4px; margin-left:15px;">
                                 <input type="checkbox" id="mig-disable-rm-redirects" value="1" <?php \checked(get_option(\SEO_Article_Generator\Option_Registry::DISABLE_RM_REDIRECTS, false), true); ?>>
                                 <?php \esc_html_e('Disable plugin redirects (let Rank Math handle them)', 'seo-article-generator'); ?>
                             </label>
                         </div>

                        <div style="flex-grow:1; display:flex; gap:10px; justify-content: flex-end; flex-wrap: wrap;">
                            <button type="button" class="button button-primary" id="mig-start-btn" style="min-width:140px; height:32px;">
                                <?php \esc_html_e('Start Migration', 'seo-article-generator'); ?>
                            </button>

                            <button type="button" class="button" id="mig-stop-btn" style="display:none; color: #d63638; border-color: #d63638; height:32px;">
                                <?php \esc_html_e('Stop', 'seo-article-generator'); ?>
                            </button>

                            <button type="button" class="button" id="mig-refresh-btn" style="height:32px;">
                                <?php \esc_html_e('Refresh Stats', 'seo-article-generator'); ?>
                            </button>

                            <button type="button" class="button" id="mig-update-links-btn" style="height:32px; color: #2271b1; border-color: #2271b1;">
                                <?php \esc_html_e('Update Internal Links', 'seo-article-generator'); ?>
                            </button>

                            <button type="button" class="button" id="mig-rollback-links-btn" style="display:none; height:32px; color: #b35c00; border-color: #b35c00;">
                                <?php \esc_html_e('Rollback Links', 'seo-article-generator'); ?>
                            </button>

                            <button type="button" class="button" id="mig-clear-redirs-btn" style="height:32px; color: #d63638; border-color: #d63638;">
                                <?php \esc_html_e('Clear All Redirections', 'seo-article-generator'); ?>
                            </button>

                            <button type="button" class="button" id="mig-rollback-btn" style="height:32px; color: #7b1fa2; border-color: #7b1fa2;">
                                <?php \esc_html_e('Rollback Migration', 'seo-article-generator'); ?>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div id="mig-progress-container" style="display:none; margin-bottom:20px;">
                <div class="mig-progress-bar-wrap" style="height:24px; background:#dcdcde; border-radius:12px; position:relative; overflow:hidden;">
                    <div id="mig-progress-bar" style="height:100%; width:0%; background:#2e7d32; transition: width 0.3s ease;"></div>
                    <span id="mig-progress-text" style="position:absolute; width:100%; text-align:center; top:0; line-height:24px; font-weight:600; color:#fff; text-shadow:0 1px 2px rgba(0,0,0,0.3);">0%</span>
                </div>
            </div>

            <div class="mig-console-wrap" style="background:#1d2327; color:#f0f0f1; border-radius:4px; padding:15px; font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace; font-size:12px; line-height:1.5;">
                <div style="margin-bottom:10px; color:#72aee6; font-weight:700; border-bottom:1px solid #3c434a; padding-bottom:5px;">
                    MIGRATION LOG
                </div>
                <div id="mig-console" style="max-height:350px; overflow-y:auto; scroll-behavior:smooth;">
                    <div style="color:#8c8f94;">> System ready. Run Dry Run to preview changes.</div>
                </div>
            </div>
        </div>

        <!-- SOCIAL SHARING TAB -->
        <div id="sgd-pane-social" class="sgd-pane <?php echo $active_tab === 'social' ? 'active' : ''; ?>">
            <h2><?php \esc_html_e('Jetpack Social Integration', 'seo-article-generator'); ?></h2>
            <p class="description">
                <?php \esc_html_e('Automatically share finalized posts to connected Jetpack Social accounts. Placeholders: {title}, {excerpt}, {tags}, {link}.', 'seo-article-generator'); ?>
            </p>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="seo_gen_jetpack_enabled"><?php \esc_html_e('Enable Jetpack Sharing', 'seo-article-generator'); ?></label></th>
                    <td>
                        <label>
                            <input type="checkbox" name="seo_gen_jetpack_enabled" id="seo_gen_jetpack_enabled" value="1" <?php \checked(get_option(\SEO_Article_Generator\Option_Registry::JETPACK_ENABLED, false), true); ?>>
                            <?php \esc_html_e('Enable sharing via Jetpack', 'seo-article-generator'); ?>
                        </label>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="seo_gen_jetpack_template"><?php \esc_html_e('Global Template', 'seo-article-generator'); ?></label></th>
                    <td>
                        <textarea name="seo_gen_jetpack_template" id="seo_gen_jetpack_template" class="large-text code" rows="4"><?php echo \esc_textarea(get_option(\SEO_Article_Generator\Option_Registry::JETPACK_TEMPLATE, "{title}\n\n{excerpt}\n\n{tags}\n\n{link}")); ?></textarea>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label><?php \esc_html_e('Per-Network Settings', 'seo-article-generator'); ?></label></th>
                    <td>
                        <p class="description" style="margin-bottom: 10px;">
                            <?php \esc_html_e('Enable or disable specific networks and set custom templates. Leave the template blank to use the Global Template.', 'seo-article-generator'); ?>
                        </p>
                        <?php
                        $networks = array('facebook', 'instagram', 'threads', 'linkedin', 'tumblr', 'mastodon', 'nextdoor', 'bluesky');
                        $enabled_networks = get_option(\SEO_Article_Generator\Option_Registry::JETPACK_NETWORKS, array());
                        $network_templates = get_option(\SEO_Article_Generator\Option_Registry::JETPACK_NETWORK_TEMPLATES, array());
                        
                        // If empty, default to all enabled for backward compatibility
                        if (empty($enabled_networks)) {
                            foreach ($networks as $n) { $enabled_networks[$n] = 1; }
                        }

                        foreach ($networks as $network) :
                            $is_enabled = !empty($enabled_networks[$network]);
                            $template = isset($network_templates[$network]) ? $network_templates[$network] : '';
                        ?>
                            <div style="margin-bottom: 15px; padding: 10px; border: 1px solid #ccc; background: #fff;">
                                <label style="font-weight: bold; display: block; margin-bottom: 5px;">
                                    <input type="checkbox" name="seo_gen_jetpack_networks[<?php echo \esc_attr($network); ?>]" value="1" <?php \checked($is_enabled, true); ?>>
                                    <?php echo \esc_html(ucfirst($network)); ?>
                                </label>
                                <textarea name="seo_gen_jetpack_network_templates[<?php echo \esc_attr($network); ?>]" class="large-text code" rows="2" placeholder="<?php \esc_attr_e('Leave blank to use Global Template', 'seo-article-generator'); ?>"><?php echo \esc_textarea($template); ?></textarea>
                            </div>
                        <?php endforeach; ?>
                    </td>
                </tr>
            </table>

            <hr style="margin: 30px 0;" />
            <h2><?php \esc_html_e('Buffer API Integration', 'seo-article-generator'); ?></h2>
            <p class="description">
                <?php \esc_html_e('Push posts to Buffer queue via GraphQL API.', 'seo-article-generator'); ?>
            </p>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="seo_gen_buffer_enabled"><?php \esc_html_e('Enable Buffer Integration', 'seo-article-generator'); ?></label></th>
                    <td>
                        <label>
                            <input type="checkbox" name="seo_gen_buffer_enabled" id="seo_gen_buffer_enabled" value="1" <?php \checked(get_option(\SEO_Article_Generator\Option_Registry::BUFFER_ENABLED, false), true); ?>>
                            <?php \esc_html_e('Enable pushing to Buffer', 'seo-article-generator'); ?>
                        </label>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="seo_gen_buffer_access_token"><?php \esc_html_e('Access Token', 'seo-article-generator'); ?></label></th>
                    <td>
                        <input type="password" name="seo_gen_buffer_access_token" id="seo_gen_buffer_access_token" class="regular-text" value="<?php echo \esc_attr(get_option(\SEO_Article_Generator\Option_Registry::BUFFER_ACCESS_TOKEN, '')); ?>">
                        <button type="button" class="button" onclick="var x=document.getElementById('seo_gen_buffer_access_token'); if(x.type==='password'){x.type='text';this.textContent='Hide';}else{x.type='password';this.textContent='Show';}">Show</button>
                         <button type="button" class="button button-secondary" id="seo_gen_buffer_fetch_channels"><?php \esc_html_e('Test Token & Fetch Channels', 'seo-article-generator'); ?></button>
                         <button type="button" class="button button-secondary" id="seo_gen_buffer_refresh_cache"><?php \esc_html_e('Refresh Channel Cache', 'seo-article-generator'); ?></button>
                         <span id="seo_gen_buffer_fetch_status" style="margin-left: 10px;"></span>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label><?php \esc_html_e('Connected Channels', 'seo-article-generator'); ?></label></th>
                    <td>
                        <table class="wp-list-table widefat fixed striped" id="seo_gen_buffer_channels_table">
                            <thead>
                                <tr>
                                    <th style="width: 13%;"><?php \esc_html_e('Network', 'seo-article-generator'); ?></th>
                                    <th style="width: 9%;"><?php \esc_html_e('Enabled', 'seo-article-generator'); ?></th>
                                    <th style="width: 33%;"><?php \esc_html_e('Template', 'seo-article-generator'); ?></th>
                                    <th style="width: 13%;"><?php \esc_html_e('Link Post', 'seo-article-generator'); ?></th>
                                    <th style="width: 14%;"><?php \esc_html_e('Link Handling', 'seo-article-generator'); ?></th>
                                    <th style="width: 18%;"><?php \esc_html_e('Pinterest Settings', 'seo-article-generator'); ?></th>
                                </tr>
                            </thead>
                            <tbody id="seo_gen_buffer_channels_body">
                                <?php
                                $enabled_channels = get_option(\SEO_Article_Generator\Option_Registry::BUFFER_ENABLED_CHANNELS, array());
                                $channel_types = get_option(\SEO_Article_Generator\Option_Registry::BUFFER_CHANNEL_TYPES, array());
                                $channel_templates = get_option(\SEO_Article_Generator\Option_Registry::BUFFER_CHANNEL_TEMPLATES, array());
                                $link_posts = get_option(\SEO_Article_Generator\Option_Registry::BUFFER_CHANNEL_LINK_POSTS, array());
                                $omit_links = get_option(\SEO_Article_Generator\Option_Registry::BUFFER_CHANNEL_OMIT_LINKS, array());
                                $obfuscate_links = get_option(\SEO_Article_Generator\Option_Registry::BUFFER_CHANNEL_OBFUSCATE_LINKS, array());
                                $pin_boards = get_option(\SEO_Article_Generator\Option_Registry::BUFFER_CHANNEL_PINTEREST_BOARDS, array());
                                $pin_titles = get_option(\SEO_Article_Generator\Option_Registry::BUFFER_CHANNEL_PINTEREST_TITLES, array());
                                
                                foreach ($channel_types as $id => $service) {
                                    $is_enabled = in_array($id, $enabled_channels);
                                    $template = isset($channel_templates[$id]) ? $channel_templates[$id] : '';
                                    $is_link = in_array($id, $link_posts);
                                    $is_omit = in_array($id, $omit_links);
                                    $is_obfuscate = in_array($id, $obfuscate_links);
                                    $pin_board = isset($pin_boards[$id]) ? $pin_boards[$id] : '';
                                    $pin_title = isset($pin_titles[$id]) ? $pin_titles[$id] : '';
                                    ?>
                                    <tr data-id="<?php echo esc_attr($id); ?>">
                                        <td>
                                            <strong><?php echo esc_html(ucfirst($service)); ?></strong><br>
                                            <small><?php echo esc_html($id); ?></small>
                                            <input type="hidden" name="seo_gen_buffer_channel_types[<?php echo esc_attr($id); ?>]" value="<?php echo esc_attr($service); ?>">
                                        </td>
                                        <td>
                                            <input type="checkbox" name="seo_gen_buffer_enabled_channels[]" value="<?php echo esc_attr($id); ?>" <?php checked($is_enabled); ?>>
                                        </td>
                                        <td>
                                            <textarea name="seo_gen_buffer_channel_templates[<?php echo esc_attr($id); ?>]" class="large-text" rows="3" placeholder="{title}&#10;&#10;{excerpt}&#10;&#10;{tags}&#10;&#10;{link}"><?php echo esc_textarea($template); ?></textarea>
                                        </td>
                                        <td>
                                            <label><input type="checkbox" name="seo_gen_buffer_channel_link_posts[]" value="<?php echo esc_attr($id); ?>" <?php checked($is_link); ?>> <?php _e('Send as Link Post', 'seo-article-generator'); ?></label>
                                        </td>
                                        <td>
                                            <label><input type="checkbox" name="seo_gen_buffer_channel_omit_links[]" value="<?php echo esc_attr($id); ?>" <?php checked($is_omit); ?>> <?php _e('Omit Link', 'seo-article-generator'); ?></label><br>
                                            <label><input type="checkbox" name="seo_gen_buffer_channel_obfuscate_links[]" value="<?php echo esc_attr($id); ?>" <?php checked($is_obfuscate); ?>> <?php _e('Obfuscate Link', 'seo-article-generator'); ?></label>
                                        </td>
                                        <td>
                                            <?php if ($service === 'pinterest') : ?>
                                                <input type="text" name="seo_gen_buffer_channel_pinterest_boards[<?php echo esc_attr($id); ?>]" value="<?php echo esc_attr($pin_board); ?>" placeholder="Board ID" class="regular-text" style="width: 100%; margin-bottom: 5px;"><br>
                                                <input type="text" name="seo_gen_buffer_channel_pinterest_titles[<?php echo esc_attr($id); ?>]" value="<?php echo esc_attr($pin_title); ?>" placeholder="Pin Title (default: {title})" class="regular-text" style="width: 100%;">
                                            <?php else: ?>
                                                <em>N/A</em>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php
                                }
                                ?>
                            </tbody>
                        </table>
                        <p class="description">
                            <?php \esc_html_e('Click "Test Token & Fetch Channels" to load your connected social accounts from Buffer. Check the "Enabled" box to activate a channel.', 'seo-article-generator'); ?>
                        </p>
                        <p class="description">
                            <?php \esc_html_e('Link Handling: "Omit Link" removes the post link entirely. "Obfuscate Link" renders {link} as e.g. https://www.site(.)com/post so SMN scanners do not flag it; the user removes the () to recover the real URL. Omit takes precedence over Obfuscate. Both suppress Buffer link attachments.', 'seo-article-generator'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="seo_gen_buffer_daily_limit"><?php \esc_html_e('Daily Limit', 'seo-article-generator'); ?></label></th>
                    <td>
                         <input type="number" name="seo_gen_buffer_daily_limit" id="seo_gen_buffer_daily_limit" class="small-text" value="<?php echo \esc_attr(get_option(\SEO_Article_Generator\Option_Registry::BUFFER_DAILY_LIMIT, 5)); ?>" min="0" max="100">
                         <p class="description"><?php \esc_html_e('Maximum Buffer shares per day. Set to 0 for unlimited.', 'seo-article-generator'); ?></p>
                    </td>
                </tr>
            </table>
        </div>

        <script>
        document.addEventListener('DOMContentLoaded', function() {
            var fetchBtn = document.getElementById('seo_gen_buffer_fetch_channels');
            if (fetchBtn) {
                fetchBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    var token = document.getElementById('seo_gen_buffer_access_token').value;
                    var statusEl = document.getElementById('seo_gen_buffer_fetch_status');
                    var tbody = document.getElementById('seo_gen_buffer_channels_body');
                    
                    if (!token) {
                        statusEl.innerHTML = '<span style="color:red;">Please enter an access token first.</span>';
                        return;
                    }
                    
                    statusEl.innerHTML = '<span style="color:orange;">Fetching channels...</span>';
                    
                    var params = new URLSearchParams({
                        action: 'seo_gen_buffer_fetch_profiles',
                        token: token,
                        _ajax_nonce: typeof seoGenData !== 'undefined' ? seoGenData.nonce : ''
                    });

                    fetch(typeof seoGenData !== 'undefined' ? seoGenData.ajax_url : ajaxurl, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: params
                    })
                        .then(function(response) {
                            if (!response.ok) {
                                throw new Error('HTTP error ' + response.status);
                            }
                            return response.json();
                        })
                        .then(function(res) {
                            if (!res.success) {
                                throw new Error(res.data ? res.data.message : 'Unknown error');
                            }
                            var data = res.data;
                            if (Array.isArray(data)) {
                                statusEl.innerHTML = '<span style="color:green;">Success! Found ' + data.length + ' channels. Save settings to persist.</span>';
                                
                                // Render new rows
                                data.forEach(function(channel) {
                                    var service = channel.service;
                                    var id = channel.id || channel._id;
                                    var name = channel.name || channel.formatted_username || channel.service_username;
                                    
                                    // Check if row already exists
                                    if (tbody.querySelector('tr[data-id="' + id + '"]')) {
                                        return;
                                    }
                                    
                                    var tr = document.createElement('tr');
                                    tr.setAttribute('data-id', id);
                                    
                                    var pinHtml = '<em>N/A</em>';
                                    if (service === 'pinterest') {
                                        pinHtml = '<input type="text" name="seo_gen_buffer_channel_pinterest_boards[' + id + ']" value="" placeholder="Board ID" class="regular-text" style="width: 100%; margin-bottom: 5px;"><br>' +
                                                  '<input type="text" name="seo_gen_buffer_channel_pinterest_titles[' + id + ']" value="" placeholder="Pin Title" class="regular-text" style="width: 100%;">';
                                    }
                                    
                                    tr.innerHTML = '<td><strong>' + service.charAt(0).toUpperCase() + service.slice(1) + ' (' + name + ')</strong><br><small>' + id + '</small>' +
                                                   '<input type="hidden" name="seo_gen_buffer_channel_types[' + id + ']" value="' + service + '"></td>' +
                                                   '<td><input type="checkbox" name="seo_gen_buffer_enabled_channels[]" value="' + id + '"></td>' +
                                                   '<td><textarea name="seo_gen_buffer_channel_templates[' + id + ']" class="large-text" rows="3" placeholder="{title}\\n\\n{excerpt}\\n\\n{tags}\\n\\n{link}"></textarea></td>' +
                                                   '<td><label><input type="checkbox" name="seo_gen_buffer_channel_link_posts[]" value="' + id + '"> Send as Link Post</label></td>' +
                                                   '<td><label><input type="checkbox" name="seo_gen_buffer_channel_omit_links[]" value="' + id + '"> Omit Link</label><br><label><input type="checkbox" name="seo_gen_buffer_channel_obfuscate_links[]" value="' + id + '"> Obfuscate Link</label></td>' +
                                                   '<td>' + pinHtml + '</td>';
                                    
                                    tbody.appendChild(tr);
                                });
                            } else {
                                statusEl.innerHTML = '<span style="color:red;">Invalid response from Buffer API.</span>';
                            }
                        })
                         .catch(function(err) {
                             statusEl.innerHTML = '<span style="color:red;">Error: ' + err.message + '</span>';
                         });
                 });
             }

             var refreshBtn = document.getElementById('seo_gen_buffer_refresh_cache');
             if (refreshBtn) {
                 refreshBtn.addEventListener('click', function(e) {
                     e.preventDefault();
                     if (!confirm('<?php echo \esc_js(__('Clear all Buffer transients and reload channels? This will force fresh data from the Buffer API on next use.', 'seo-article-generator')); ?>')) {
                         return;
                     }
                     var statusEl = document.getElementById('seo_gen_buffer_fetch_status');
                     var params = new URLSearchParams({
                         action: 'seo_gen_refresh_buffer_channels',
                         _ajax_nonce: typeof seoGenData !== 'undefined' ? seoGenData.nonce : ''
                     });
                     fetch(typeof seoGenData !== 'undefined' ? seoGenData.ajax_url : ajaxurl, {
                         method: 'POST',
                         headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                         body: params
                     })
                         .then(function(response) { return response.json(); })
                         .then(function(res) {
                             if (res.success) {
                                 statusEl.innerHTML = '<span style="color:green;">Cache cleared. ' + (res.data && res.data.length ? res.data.length + ' channels reloaded.' : '') + '</span>';
                             } else {
                                 statusEl.innerHTML = '<span style="color:red;">Error: ' + (res.data && res.data.message ? res.data.message : 'Failed') + '</span>';
                             }
                         })
                         .catch(function(err) {
                             statusEl.innerHTML = '<span style="color:red;">Error: ' + err.message + '</span>';
                         });
                 });
             }
         });
         </script>

        <p class="submit">
            <input type="submit" name="seo_gen_save_settings" class="button-primary" value="<?php \esc_attr_e('Save Settings', 'seo-article-generator'); ?>">
        </p>
    </form>
</div>

<style>
    /* @MODIFIED 2026-03-03: Settings Tabs styling */
    .sgd-pane {
        display: none;
        background: #fff;
        padding: 20px;
        border: 1px solid #ddd;
        border-top: none;
        box-shadow: 0 1px 1px rgba(0, 0, 0, 0.04);
    }

    .sgd-pane.active {
        display: block;
    }

    .seo-gen-settings-wrap h2 {
        margin-top: 0;
        padding-bottom: 15px;
        border-bottom: 1px solid #eee;
        color: #1d2327;
    }

    /* @MODIFIED 2026-01-06 v2.16.0: Smoke test results styling */
    .smoke-test-summary {
        padding: 15px;
        background: #f0f0f1;
        border-left: 4px solid #2271b1;
        margin-bottom: 20px;
    }

    .smoke-test-summary h3 {
        margin-top: 0;
    }

    .smoke-test-category {
        margin-bottom: 15px;
        padding: 10px;
        background: #fff;
        border-left: 4px solid #46b450;
    }

    .smoke-test-category.has-errors {
        border-left-color: #dc3232;
    }

    .smoke-test-category.smoke-test-skip {
        border-left-color: #f0b849;
        background: #fcf8ed;
    }

    .smoke-test-category h4 {
        margin-top: 0;
        margin-bottom: 10px;
    }

    .smoke-test-error {
        margin: 8px 0;
        padding: 8px;
        background: #fff0f0;
        border: 1px solid #dc3232;
        border-radius: 3px;
        font-size: 13px;
    }

    .smoke-test-info {
        margin: 8px 0;
        padding: 8px;
        background: #fcf8ed;
        border: 1px solid #f0b849;
        border-radius: 3px;
        font-size: 13px;
    }

    .smoke-test-error strong,
    .smoke-test-info strong {
        display: block;
        margin-bottom: 4px;
    }

    .smoke-test-progress {
        padding: 10px;
        background: #fcf8ed;
        border-left: 4px solid #f0b849;
        margin: 10px 0;
    }

    /* Sentinel Backfill Styles */
    .backfill-stat-card {
        background: #fff;
        border: 1px solid #c3c4c7;
        padding: 10px 15px;
        border-radius: 4px;
        min-width: 100px;
        text-align: center;
    }
    .backfill-stat-card.highlight {
        border-color: #2271b1;
        background: #f0f6fc;
    }
    .backfill-stat-card .label {
        display: block;
        font-size: 11px;
        text-transform: uppercase;
        color: #646970;
        margin-bottom: 2px;
    }
    .backfill-stat-card .value {
        font-size: 20px;
        font-weight: 700;
        color: #1d2327;
    }
.bf-log-entry { margin-bottom: 4px; border-bottom: 1px solid #2c3338; padding-bottom: 2px; }
.bf-log-entry .post-title { color: #f0f0f1; }
.bf-log-entry .status-updated { color: #46b450; font-weight: bold; }
.bf-log-entry .status-unchanged { color: #72aee6; }
.bf-log-entry .status-failed { color: #d63638; }

/* Backfill Controls Responsive Layout */
.backfill-controls .button {
    white-space: nowrap;
}

@media screen and (max-width: 1200px) {
    .backfill-controls > div > div {
        flex-direction: column !important;
        align-items: stretch !important;
    }
    .backfill-controls > div > div > div {
        width: 100%;
        justify-content: flex-start !important;
    }
    .backfill-controls select {
        width: 100%;
        max-width: 100%;
    }
}

/* Canonical Slug Migration Styles */
.migration-stat-card {
    background: #fff;
    border: 1px solid #c3c4c7;
    padding: 10px 15px;
    border-radius: 4px;
    min-width: 100px;
    text-align: center;
}
.migration-stat-card .label {
    display: block;
    font-size: 11px;
    text-transform: uppercase;
    color: #646970;
    margin-bottom: 2px;
}
.migration-stat-card .value {
    font-size: 20px;
    font-weight: 700;
    color: #1d2327;
}
.mig-log-entry { margin-bottom: 4px; border-bottom: 1px solid #2c3338; padding-bottom: 2px; }
.mig-log-entry .post-title { color: #f0f0f1; }
.mig-log-entry .status-updated { color: #46b450; font-weight: bold; }
.mig-log-entry .status-unchanged { color: #72aee6; }
.mig-log-entry .status-failed { color: #d63638; }

/* Migration Controls Responsive Layout */
.migration-controls .button {
    white-space: nowrap;
    opacity: 1 !important;
    transition: opacity 0.15s ease, background-color 0.15s ease;
}
.migration-controls .button:disabled {
    opacity: 0.65 !important;
    cursor: not-allowed;
}
.migration-controls .button[style*="display: none"] {
    display: none !important;
}

/* Prevent button text fade during AJAX */
.migration-controls .button.updating {
    position: relative;
}
.migration-controls .button.updating::after {
    content: attr(data-loading-text);
    position: absolute;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    background: inherit;
    color: inherit;
}

/* Migration Controls Responsive Layout */
@media screen and (max-width: 1200px) {
    .migration-controls > div > div {
        flex-direction: column !important;
        align-items: stretch !important;
    }
    .migration-controls > div > div > div {
        width: 100%;
        justify-content: flex-start !important;
    }
    .migration-controls select {
        width: 100%;
        max-width: 100%;
    }
}
</style>

<script type="text/javascript">
    jQuery(document).ready(function($) {
        // @MODIFIED 2026-03-03: Settings Tabs switching
        $('.js-settings-tabs .nav-tab').on('click', function(e) {
            e.preventDefault();
            var tab = $(this).data('tab');
            $('.js-settings-tabs .nav-tab').removeClass('nav-tab-active');
            $(this).addClass('nav-tab-active');
            $('.sgd-pane').removeClass('active');
            $('#sgd-pane-' + tab).addClass('active');
            $('#active_tab_input').val(tab);

            // Update URL for persistence
            if (window.history.replaceState) {
                var url = new URL(window.location.href);
                url.searchParams.set('stab', tab);
                window.history.replaceState({
                    path: url.href
                }, '', url.href);
            }
            // Specific initialization
            if (tab === 'backfill') {
                loadBackfillStats();
            }
            if (tab === 'migration') {
                loadMigrationStats();
            }
        });

        // Toggle log retention field
        $('#seo_gen_enable_logging').on('change', function() {
            $('#log-retention-row').toggle($(this).is(':checked'));
        });

        // Toggle provider-only mode note
        $('#seo_gen_provider_only_mode').on('change', function() {
            $('#seo_gen_provider_only_mode-note').toggle($(this).is(':checked'));
        });

        // Toggle scheduling rows
        $('#seo_gen_enable_scheduling').on('change', function() {
            $('.scheduling-row').toggle($(this).is(':checked'));
        });

        // @MODIFIED 2026-03-05: Toggle auto-gen rows
        $('#seo_gen_enable_auto_generation').on('change', function() {
            $('.auto-gen-row').toggle($(this).is(':checked'));
        });

	// Toggle provider-specific fields
	$('#seo_gen_api_provider').on('change', function() {
		var provider = $(this).val();
		$('#gemini-api-key-row, #gemini-model-row, #gemini-fallback-row').toggle(provider === 'gemini');
		$('#perplexity-api-key-row, #perplexity-model-row').toggle(provider === 'perplexity');
		$('#openai-api-key-row, #openai-model-row').toggle(provider === 'openai');
		$('#groq-api-key-row, #groq-model-row, #groq-fallback-row').toggle(provider === 'groq');
		$('#openrouter-api-key-row, #openrouter-model-row, #openrouter-fallback-row').toggle(provider === 'openrouter');
	});

	// Gemini custom model visibility toggle
	$(document).ready(function() {
		var modeSelect = document.getElementById('seo_gen_gemini_model_mode');
		var customWrap = document.getElementById('gemini-custom-model-wrap');
		var customInput = document.getElementById('seo_gen_gemini_custom_model');

		if (modeSelect && customWrap && customInput) {
			function syncGeminiCustomVisibility() {
				var isCustom = modeSelect.value === 'custom';
				customWrap.style.display = isCustom ? '' : 'none';
				customInput.disabled = !isCustom;
			}
			modeSelect.addEventListener('change', syncGeminiCustomVisibility);
			syncGeminiCustomVisibility();
		}
	});

        $('#seo-gen-test-api').on('click', function() {
            var button = $(this);
            var result = $('#seo-gen-api-test-result');
            var provider = $('#seo_gen_api_provider').val();

            // Get correct API key based on provider
            var apiKey = "";
            if (provider === "perplexity") {
                apiKey = $("#seo_gen_perplexity_api_key").val();
            } else if (provider === "openai") {
                apiKey = $("#seo_gen_openai_api_key").val();
            } else if (provider === "groq") {
                apiKey = $("#seo_gen_groq_api_key").val();
            } else if (provider === "openrouter") {
                apiKey = $("#seo_gen_openrouter_api_key").val();
            } else if (provider === "gemini") {
                apiKey = $("#seo_gen_gemini_api_key").val();
                // Allow testing when the field is empty but placeholder shows the saved key mask
                if (apiKey === "") {
                    apiKey = ($("#seo_gen_gemini_api_key").attr("placeholder") === "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022") ? "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022" : "";
                }
            } else {
                // Custom provider (prov_xxx): key lives in the provider card, not a standalone field.
                // Read it from the card; backend falls back to saved key if the input is empty.
                var $activeCard = $(".seo-gen-custom-provider-card[data-provider-id=\"" + provider + "\"]");
                if ($activeCard.length) {
                    apiKey = $activeCard.find("input[name*=\"[api_key]\"]").val();
                }
            }

            button.prop('disabled', true).text('<?php \esc_html_e('Testing...', 'seo-article-generator'); ?>');
            result.html('');

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'seo_gen_test_api',
                    nonce: '<?php echo \esc_js(\wp_create_nonce('seo_gen_nonce')); ?>',
                    provider: provider,
                    api_key: apiKey
                },
                success: function(response) {
                    if (response.success) {
                        result.html('<span style="color: green;">✓ ' + response.data.message + '</span>');
                    } else {
                        result.html('<span style="color: red;">✗ ' + response.data.message + '</span>');
                    }
                },
                error: function() {
                    result.html('<span style="color: red;">✗ Connection failed</span>');
                },
                complete: function() {
                    button.prop('disabled', false).text('<?php \esc_html_e('Test API Connection', 'seo-article-generator'); ?>');
                }
            });
        });

        // @MODIFIED 2026-01-06 v2.16.0: Smoke test runner
        $('#seo-gen-run-smoke-test').on('click', function() {
            var button = $(this);
            var resultsContainer = $('#smoke-test-results');

            button.prop('disabled', true).text('<?php \esc_html_e('Running tests...', 'seo-article-generator'); ?>');
            resultsContainer.html('<div class="smoke-test-progress">⏳ Running comprehensive smoke test (this may take 10-30 seconds)...</div>').show();

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                timeout: 60000, // 60 second timeout
                data: {
                    action: 'seo_gen_run_smoke_test',
                    nonce: '<?php echo \esc_js(\wp_create_nonce('seo_gen_nonce')); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        renderSmokeTestResults(response.data.results);
                    } else {
                        resultsContainer.html('<div style="padding: 10px; background: #fff0f0; border-left: 4px solid #dc3232;"><strong>Error:</strong> ' + response.data.message + '</div>');
                    }
                },
                error: function(xhr, status, error) {
                    resultsContainer.html('<div style="padding: 10px; background: #fff0f0; border-left: 4px solid #dc3232;"><strong>AJAX Error:</strong> ' + error + '</div>');
                },
                complete: function() {
                    button.prop('disabled', false).text('<?php \esc_html_e('Run Comprehensive Smoke Test', 'seo-article-generator'); ?>');
                }
            });
        });

        // Dashboard API Key Generator
        $('#seo-gen-generate-dashboard-key').on('click', function() {
            var button = $(this);
            var keyInput = $('#seo_gen_dashboard_api_key');
            
            button.prop('disabled', true).text('<?php \esc_html_e('Generating...', 'seo-article-generator'); ?>');
            
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'seo_gen_generate_dashboard_key',
                    nonce: '<?php echo \esc_js(\wp_create_nonce('seo_gen_nonce')); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        keyInput.val(response.data.key);
                        button.text('<?php \esc_html_e('Generated!', 'seo-article-generator'); ?>');
                        setTimeout(function() {
                            button.prop('disabled', false).text('<?php \esc_html_e('Generate New Key', 'seo-article-generator'); ?>');
                        }, 2000);
                    } else {
                        alert('Error: ' + response.data.message);
                        button.prop('disabled', false).text('<?php \esc_html_e('Generate New Key', 'seo-article-generator'); ?>');
                    }
                },
                error: function() {
                    alert('<?php \esc_html_e('AJAX error. Please try again.', 'seo-article-generator'); ?>');
                    button.prop('disabled', false).text('<?php \esc_html_e('Generate New Key', 'seo-article-generator'); ?>');
                }
            });
        });

        // --- SENTINEL BACKFILL LOGIC ---
        var isBackfilling = false;
        var backfillStats = { total: 0, completed: 0, pending: 0 };
        var stopBackfill = false;

        function loadBackfillStats() {
            logToConsole('Loading current stats...', 'info');

            var catId = parseInt($('#bf-identify-cat').val(), 10) || 0;
            var excludedCats = ($('#bf-exclude-cats').val() || []).map(function(v) {
                return parseInt(v, 10) || 0;
            }).filter(function(v) {
                return v > 0 && v !== catId;
            });

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'seo_gen_backfill_stats',
                    nonce: '<?php echo \esc_js(\wp_create_nonce('seo_gen_nonce')); ?>',
                    category_id: catId,
                    excluded_category_ids: excludedCats
                },
                success: function(response) {
                    if (response.success) {
                        backfillStats = response.data || {};

                        $('#bf-stat-total').text((parseInt(backfillStats.total, 10) || 0).toLocaleString());
                        $('#bf-stat-pending').text((parseInt(backfillStats.pending, 10) || 0).toLocaleString());
                        $('#bf-stat-potential').text((parseInt(backfillStats.potential, 10) || 0).toLocaleString());

                        var failed = parseInt(backfillStats.permanently_failed, 10) || 0;
                        $('#bf-stat-failed').text(failed.toLocaleString());

                        var missingNames = parseInt(backfillStats.missing_software_name, 10) || 0;
                        $('#bf-stat-missing-names').text(missingNames.toLocaleString());

                        if ((parseInt(backfillStats.potential, 10) || 0) > 0) {
                            $('#bf-potential-card').css('background', '#fff8e5').css('border-color', '#ffb900');
                        } else {
                            $('#bf-potential-card').css('background', '#f6f7f7').css('border-color', '#c3c4c7');
                        }

                        if (missingNames > 0) {
                            $('#bf-missing-names-card').css('background', '#f0f6fc').css('border-color', '#2271b1');
                        } else {
                            $('#bf-missing-names-card').css('background', '#f6f7f7').css('border-color', '#c3c4c7');
                        }

                        if (failed > 0) {
                            $('#bf-failed-card').css('background', '#fff0f0').css('border-color', '#dc3232');
                        } else {
                            $('#bf-failed-card').css('background', '#f6f7f7').css('border-color', '#c3c4c7');
                        }

                        updateBackfillProgress();
                    } else {
                        logToConsole('Stats Error: ' + (response.data ? (response.data.message || response.data.error) : 'Unknown'), 'error');
                    }
                },
                error: function() {
                    logToConsole('Connection Error: Could not reach server for stats.', 'error');
                }
            });
        }

        function updateBackfillProgress() {
            var total = parseInt(backfillStats.total, 10) || 0;
            var completed = parseInt(backfillStats.completed, 10) || 0;

            if (total <= 0) {
                $('#bf-progress-bar').css('width', '0%');
                $('#bf-progress-text').text('0%');
                return;
            }

            if (completed < 0) {
                completed = 0;
            }

            if (completed > total) {
                completed = total;
            }

            var percent = Math.min(100, Math.round((completed / total) * 100));
            $('#bf-progress-bar').css('width', percent + '%');
            $('#bf-progress-text').text(percent + '%');
        }

        $('#bf-identify-cat, #bf-exclude-cats').on('change', function() {
            loadBackfillStats();
        });

        function logToConsole(message, type) {
            var color = '#f0f0f1';
            if (type === 'success') color = '#46b450';
            if (type === 'error') color = '#d63638';
            if (type === 'info') color = '#72aee6';
            if (type === 'dry') color = '#f0b849';

            var timestamp = new Date().toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
            var entry = $('<div class="bf-log-entry"></div>')
                .append('<span style="color:#8c8f94; font-size:10px; margin-right:8px;">[' + escapeHtml(timestamp) + ']</span>')
                .append('<span style="color:' + color + ';">' + message + '</span>');
            
            var consoleEl = $('#bf-console');
            consoleEl.append(entry);
            consoleEl.scrollTop(consoleEl[0].scrollHeight);
        }

        // Manual Controls
        $('#bf-refresh-btn').on('click', function() {
            loadBackfillStats();
        });

        $('#bf-clear-failed-btn').on('click', function() {
            var button = $(this);
            if (!confirm('This will clear the failed status from posts that previously backfill failed, allowing them to be retried with the updated code. Continue?')) {
                return;
            }
            button.prop('disabled', true).text('Clearing...');
            logToConsole('Clearing failed backfill statuses...', 'info');

            var clearCatId = parseInt($('#bf-identify-cat').val(), 10) || 0;
            var clearExcludedCats = ($('#bf-exclude-cats').val() || []).map(function(v) {
                return parseInt(v, 10) || 0;
            }).filter(function(v) {
                return v > 0 && v !== clearCatId;
            });

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'seo_gen_clear_backfill_failures',
                    nonce: '<?php echo \esc_js(\wp_create_nonce('seo_gen_nonce')); ?>',
                    category_id: clearCatId,
                    excluded_category_ids: clearExcludedCats
                },
                success: function(response) {
                    if (response.success) {
                        var cleared = parseInt(response.data && response.data.cleared, 10) || 0;
                        logToConsole('Cleared ' + cleared + ' failed posts. Run backfill to process them.', 'success');
                        loadBackfillStats();
                    } else {
                        logToConsole('Error: ' + (response.data && response.data.message) || 'Unknown error', 'error');
                    }
                    button.prop('disabled', false).text('Clear Failed & Retry');
                },
                error: function() {
                    logToConsole('AJAX error while clearing failed posts.', 'error');
                    button.prop('disabled', false).text('Clear Failed & Retry');
                }
            });
        });

        $('#bf-clear-console').on('click', function() {
            $('#bf-console').empty().append('<div style="color:#8c8f94;">> Console cleared. Ready.</div>');
        });

        // Identification Step
        $('#bf-identify-btn').on('click', function() {
            var button = $(this);
            var catId = parseInt($('#bf-identify-cat').val(), 10) || 0;

            var excludedCats = ($('#bf-exclude-cats').val() || []).map(function(v) {
                return parseInt(v, 10) || 0;
            }).filter(function(v) {
                return v > 0 && v !== catId;
            });

            if (catId === 0 && excludedCats.length === 0) {
                logToConsole(
                    'You selected All Categories with no exclusions. Select at least one category to exclude (e.g. showbiz, Uncategorized) before scanning.',
                    'error'
                );
                button.prop('disabled', false).text('Scan & Tag Software Posts');
                return;
            }
            
            button.prop('disabled', true).text('Scanning...');
            logToConsole('Identification started for Category ID: ' + catId + (excludedCats.length ? ' | Excluding: ' + excludedCats.join(', ') : ''), 'info');

            function runIdentifyBatch(offset) {
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'seo_gen_identify_legacy_posts',
                        nonce: '<?php echo \esc_js(\wp_create_nonce('seo_gen_nonce')); ?>',
                        category_id: catId,
                        excluded_category_ids: excludedCats,
                        offset: 0,
                        limit: 25
                    },
                    success: function(res) {
                        if (!res.success) {
                            logToConsole('Identification Error ' + escapeHtml(String(res.data && (res.data.message || res.data.error) || 'Unknown')), 'error');
                            button.prop('disabled', false).text('Scan & Tag Software Posts');
                            return;
                        }

                        var batchCount      = parseInt(res.data.batch_count, 10) || 0;
                        var eligibleScanned = parseInt(res.data.scanned, 10) || 0;
                        var skippedCount    = parseInt(res.data.skipped, 10) || 0;

                        if (batchCount === 0) {
                            logToConsole('Identification complete.', 'success');
                            button.prop('disabled', false).text('Scan & Tag Software Posts');
                            loadBackfillStats();
                            return;
                        }

                        if ((parseInt(res.data.identified, 10) || 0) > 0) {
                            logToConsole('Identified ' + res.data.identified + ' software posts in this batch.', 'success');
                        } else if ((parseInt(res.data.ambiguous, 10) || 0) > 0) {
                            logToConsole('Ambiguous titles in this batch: ' + res.data.ambiguous + '.', 'error');
                        } else if (eligibleScanned > 0) {
                            logToConsole('Scanned ' + eligibleScanned + ' eligible posts, no new software matches found.', 'info');
                        } else if (skippedCount > 0) {
                            logToConsole('Skipped ' + skippedCount + ' non-plugin-owned posts in this batch.', 'info');
                        }

                        res.data.details.forEach(function(d) {
                            var status = String(d.status || '');
                            if (status === 'identified') {
                                logToConsole('Tagged ' + d.id + ' ' + escapeHtml(String(d.name)) + ' v' + escapeHtml(String(d.version)), 'success');
                                return;
                            }
                            if (status === 'ambiguous') {
                                logToConsole('Ambiguous ' + d.id + ' ' + escapeHtml(String(d.title)), 'error');
                                return;
                            }
                            if (status === 'skipped') {
                                logToConsole(
                                    'Skipped non-plugin-owned post [' + d.id + '] ' + escapeHtml(String(d.title || '')),
                                    'info'
                                );
                            }
                        });

                        runIdentifyBatch(0);
                    },
                    error: function() {
                        logToConsole('Connection Error during identification.', 'error');
                        button.prop('disabled', false).text('Scan & Tag Software Posts');
                    }
                });
            }

            runIdentifyBatch(0);
        });

        $('#bf-purge-unknown-btn').on('click', function () {
            if (!confirm('This will permanently remove incorrectly tagged ownership meta from gossip/non-software posts. Continue?')) {
                return;
            }

            var button = $(this);
            button.prop('disabled', true).text('Purging...');
            logToConsole('Starting purge of unknown-version ownership meta...', 'error');

            function runPurgeBatch() {
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'seo_gen_purge_unknown_ownership',
                        nonce: '<?php echo esc_js( wp_create_nonce( 'seo_gen_nonce' ) ); ?>'
                    },
                    success: function (res) {
                        if (!res.success) {
                            logToConsole('Purge error: ' + escapeHtml(String(res.data ? res.data.message : 'Unknown')), 'error');
                            button.prop('disabled', false).text('Purge Unknown-Version Tags');
                            return;
                        }

                        var purged = parseInt(res.data.purged) || 0;

                        if (purged > 0) {
                            logToConsole('Purged ' + purged + ' contaminated ownership records.', 'error');
                            res.data.details.forEach(function (d) {
                                logToConsole('Removed: [' + d.post_id + '] ' + escapeHtml(String(d.title || '')), 'info');
                            });
                            runPurgeBatch();
                        } else {
                            logToConsole('Purge complete. No contaminated records remaining.', 'success');
                            button.prop('disabled', false).text('Purge Unknown-Version Tags');
                            loadBackfillStats();
                        }
                    },
                    error: function () {
                        logToConsole('Connection error during purge.', 'error');
                        button.prop('disabled', false).text('Purge Unknown-Version Tags');
                    }
                });
            }

        runPurgeBatch();
    });

    /**
     * Backfill Software Names from Hero Data
     * Finds posts with _seo_gen_hero_data but missing _seo_gen_software_name
     * Extracts software_name from hero_data and writes it to postmeta
     */
    $('#bf-backfill-names-btn').on('click', function() {
        var button = $(this);
        if (button.prop('disabled')) return;

        if (!confirm('<?php echo \esc_js(\__('This will scan posts with hero_data and populate missing software_name meta. Continue?', 'seo-article-generator')); ?>')) {
            return;
        }

        button.prop('disabled', true).text('<?php echo \esc_js(\__('Backfilling...', 'seo-article-generator')); ?>');
        logToConsole('Starting software name backfill from hero_data...', 'info');

        var totalFixed = 0;
        var totalSkipped = 0;

        function runBackfillNamesBatch() {
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'seo_gen_backfill_software_name',
                    nonce: '<?php echo \esc_js(\wp_create_nonce('seo_gen_nonce')); ?>'
                },
                success: function(res) {
                    if (!res.success) {
                        logToConsole('Backfill error: ' + escapeHtml(String(res.data && res.data.message ? res.data.message : 'Unknown')), 'error');
                        button.prop('disabled', false).text('<?php echo \esc_js(\__('Backfill Software Names', 'seo-article-generator')); ?>');
                        return;
                    }

                    var fixed = parseInt(res.data.fixed) || 0;
                    var skipped = parseInt(res.data.skipped) || 0;
                    totalFixed += fixed;
                    totalSkipped += skipped;

                    // Log details for each post processed
                    if (res.data.details && res.data.details.length > 0) {
                        res.data.details.forEach(function(d) {
                            var msg = '[' + d.post_id + '] ' + escapeHtml(String(d.name));
                            if (d.source === 'herodata') {
                                logToConsole('Fixed from hero_data: ' + msg, 'success');
                            } else if (d.source === 'title_fallback') {
                                logToConsole('Fixed from title: ' + msg, 'warning');
                            } else {
                                logToConsole('Fixed: ' + msg, 'info');
                            }
                        });
                    }

                    if (fixed > 0) {
                        logToConsole('Batch complete. Fixed: ' + fixed + ', Skipped: ' + skipped, 'info');
                        // Continue if we hit the batch limit (200)
                        if (fixed >= 200) {
                            runBackfillNamesBatch();
                            return;
                        }
                    } else {
                        logToConsole('Backfill complete. Total Fixed: ' + totalFixed + ', Total Skipped: ' + totalSkipped, 'success');
                        button.prop('disabled', false).text('<?php echo \esc_js(\__('Backfill Software Names', 'seo-article-generator')); ?>');
                        loadBackfillStats();
                    }
                },
                error: function(xhr, status, error) {
                    logToConsole('Connection error during backfill: ' + escapeHtml(String(error)), 'error');
                    button.prop('disabled', false).text('<?php echo \esc_js(\__('Backfill Software Names', 'seo-article-generator')); ?>');
                }
            });
        }

        runBackfillNamesBatch();
    });

    // Initialize if already on tab
    if ('<?php echo $active_tab; ?>' === 'backfill') {
        loadBackfillStats();
    }

    $('#bf-start-btn').on('click', function() {
            if (isBackfilling) return;
            
            var limit = parseInt($('#bf-limit').val()) || 25;
            var dryRun = $('#bf-dry-run').is(':checked');
            var includeCatId = parseInt($('#bf-identify-cat').val(), 10) || 0;

            var excludedCats = ($('#bf-exclude-cats').val() || []).map(function(v) {
                return parseInt(v, 10) || 0;
            }).filter(function(v) {
                return v > 0 && v !== includeCatId;
            });

            if (includeCatId === 0 && excludedCats.length === 0) {
                logToConsole(
                    'You selected All Categories with no exclusions. Select at least one category to exclude before running backfill.',
                    'error'
                );
                return;
            }
            
            isBackfilling = true;
            stopBackfill = false;
            $(this).prop('disabled', true).addClass('button-disabled').text('Processing...');
            $('#bf-stop-btn').show();
            $('#bf-progress-container').fadeIn();
            
            logToConsole('Initialization started. Mode: ' + (dryRun ? 'DRY RUN' : 'LIVE RUN') + ' | Category: ' + includeCatId + (excludedCats.length ? ' | Excluding: ' + excludedCats.join(', ') : ''), 'info');
            
            processBackfillBatch(limit, dryRun, 0, includeCatId, excludedCats);
        });

        $('#bf-stop-btn').on('click', function() {
            stopBackfill = true;
            $(this).prop('disabled', true).text('Stopping...');
            logToConsole('Stop requested. Finishing batch...', 'error');
        });

        function processBackfillBatch(limit, dryRun, offset, catId, excludedCats) {
            if (stopBackfill) {
                isBackfilling = false;
                $('#bf-start-btn').prop('disabled', false).removeClass('button-disabled').text('Resume Backfill');
                $('#bf-stop-btn').hide().prop('disabled', false).text('Stop');
                logToConsole('Process halted by operator.', 'error');
                return;
            }

            // In live mode, offset is always 0 because posts are filtered out of the query as they are processed.
            // In dry mode, we must increment the offset to see the next batch.
            var currentOffset = dryRun ? offset : 0;

            console.log('SEO Gen: Processing batch at offset ' + currentOffset);

            $.ajax({
                url: typeof seoGenData !== 'undefined' && seoGenData.ajax_url ? seoGenData.ajax_url : ajaxurl,
                type: 'POST',
                timeout: 120000,
                data: {
                    action: 'seo_gen_inject_sentinels',
                    nonce: '<?php echo esc_js(wp_create_nonce('seo_gen_nonce')); ?>',
                    dry_run: dryRun,
                    limit: limit,
                    offset: currentOffset,
                    category_id: catId,
                    excluded_category_ids: excludedCats || []
                },
                success: function(response) {
                    if (response.success) {
                        var data = response.data;
                        
                        if (data.targeted_posts === 0) {
                            loadBackfillStats();

                            setTimeout(function() {
                                var pending = parseInt(backfillStats.pending, 10) || 0;

                                if (pending > 0) {
                                    logToConsole(
                                        'Batch query returned 0 eligible posts, but ' + pending + ' posts are still pending in the current scope. Stats and runner were not aligned before this point, or those posts are not plugin-owned candidates.',
                                        'error'
                                    );
                                } else {
                                    logToConsole('Scanning complete. All eligible posts updated or verified.', 'success');
                                }

                                finishBackfill();
                            }, 150);

                            return;
                        }

                        // Log results
                        data.details.forEach(function(item) {
                            var statusText = String(item.status || '').toUpperCase();
                            var statusClass = 'status-' + String(item.status || 'info');
                            var msg = '[' + item.post_id + '] <span class="post-title">' + escapeHtml(String(item.post_title || '')) + '</span> - ';
                            msg += '<span class="' + statusClass + '">' + escapeHtml(statusText) + '</span>';

                            if (item.injected && item.injected.length > 0) {
                                msg += ' | Sentinels: ' + escapeHtml(item.injected.join(', '));
                            }

                            if (typeof item.format_detected !== 'undefined') {
                                msg += ' | format=' + escapeHtml(String(item.format_detected));
                            }

                            if (Array.isArray(item.zones_detected)) {
                                msg += ' | zones_detected=' + escapeHtml(item.zones_detected.join(', ') || 'none');
                            }

                            if (Array.isArray(item.zones_missing)) {
                                msg += ' | zones_missing=' + escapeHtml(item.zones_missing.join(', ') || 'none');
                            }

                            if (typeof item.confidence !== 'undefined') {
                                msg += ' | confidence=' + escapeHtml(String(item.confidence));
                            }

                            if (item.reason) {
                                msg += ' | reason=' + escapeHtml(String(item.reason));
                            }

                            logToConsole(msg, item.status === 'updated' ? (dryRun ? 'dry' : 'success') : (item.status === 'failed' ? 'error' : 'info'));
                        });

                        // Update stats
                        loadBackfillStats();
                        
                        // Small delay to prevent UI lockup and save API quota
                        setTimeout(function() {
                            processBackfillBatch(limit, dryRun, offset + limit, catId, excludedCats);
                        }, 600);
                    } else {
                        console.error('SEO Gen Batch Error:', response);
                        logToConsole('Batch Error: ' + (response.data ? response.data.message : 'Unknown response'), 'error');
                        finishBackfill();
                    }
                },
                error: function(xhr, status, error) {
                    console.error('SEO Gen Batch AJAX Failure:', status, error);
                    if (status === 'timeout') {
                        logToConsole('Batch timed out after 120s. Reduce batch size to 3 and retry.', 'error');
                    } else {
                        logToConsole('Network Failure: ' + error, 'error');
                    }
                    finishBackfill();
                }
            });
        }

        function finishBackfill() {
            isBackfilling = false;
            $('#bf-start-btn').prop('disabled', false).removeClass('button-disabled').text('Start Backfill');
            $('#bf-stop-btn').hide();
            loadBackfillStats();
        }

        function renderSmokeTestResults(results) {
            var html = '';

            // Summary
            var summary = results.summary;
            var allPassed = (summary.failed === 0);
            var summaryColor = allPassed ? '#46b450' : '#dc3232';

            html += '<div class="smoke-test-summary" style="border-left-color: ' + summaryColor + ';">';
            html += '<h3>Test Summary</h3>';
            html += '<p><strong>Total Tests:</strong> ' + summary.total + '</p>';
            html += '<p><strong>Passed:</strong> <span style="color: green;">' + summary.passed + '</span></p>';
            html += '<p><strong>Failed:</strong> <span style="color: red;">' + summary.failed + '</span></p>';
            html += '<p><strong>Duration:</strong> ' + summary.duration + 'ms</p>';

            if (allPassed) {
                html += '<p style="color: green; font-weight: bold;">✅ All tests passed! Plugin is functioning correctly.</p>';
            } else {
                html += '<p style="color: red; font-weight: bold;">❌ Some tests failed. Please review errors below.</p>';
            }
            html += '</div>';

            // Categories
            var categoryNames = {
                'syntax': 'PHP Syntax',
                'database': 'Database Schema',
                'files': 'File Integrity',
                'hooks': 'Hook Registrations',
                'classes': 'Class & Method Existence',
                'renderers': 'Renderer Functionality',
                'ajax': 'AJAX Endpoints',
                'assets': 'Asset Files',
                'compatibility': 'WordPress Compatibility',
                'content_pipeline': 'Content Pipeline'
            };

            $.each(results.categories, function(categoryKey, categoryData) {
                var categoryName = categoryNames[categoryKey] || categoryKey;
                var hasErrors = (categoryData.failed > 0);
                var isSkipped = (categoryData.skipped === true);
                var categoryClass = hasErrors ? 'smoke-test-category has-errors' : 'smoke-test-category';

                // Mark skipped categories with different styling
                if (isSkipped) {
                    categoryClass = 'smoke-test-category smoke-test-skip';
                }

                html += '<div class="' + categoryClass + '">';
                html += '<h4>' + categoryName + ' Tests';
                if (isSkipped) {
                    html += ' <span style="color: #f0b849; font-size: 14px;">(Skipped)</span>';
                }
                html += '</h4>';

                html += '<p><strong>Passed:</strong> ' + categoryData.passed + ' / ' + categoryData.total;
                html += ' (<strong>Duration:</strong> ' + categoryData.duration + 'ms)</p>';

                // Show errors if any
                if (categoryData.errors && categoryData.errors.length > 0) {
                    var errorHeading = isSkipped ? 'Info:' : 'Errors:';
                    var errorColor = isSkipped ? '#f0b849' : '#dc3232';
                    html += '<div style="margin-top: 10px;"><h5 style="color: ' + errorColor + '; margin: 5px 0;">' + errorHeading + '</h5>';
                    $.each(categoryData.errors, function(index, error) {
                        var errorClass = isSkipped ? 'smoke-test-info' : 'smoke-test-error';
                        html += '<div class="' + errorClass + '">';
                        if (error.file) {
                            html += '<strong>File:</strong> ' + escapeHtml(error.file) + '<br>';
                        }
                        if (error.test) {
                            html += '<strong>Test:</strong> ' + escapeHtml(error.test) + '<br>';
                        }
                        html += '<strong>Error:</strong> ' + escapeHtml(error.error) + '<br>';
                        html += '<strong>Suggestion:</strong> ' + escapeHtml(error.suggestion);
                        html += '</div>';
                    });
                    html += '</div>';
                } else {
                    html += '<p style="color: #46b450;">✓ All checks passed</p>';
                }

                html += '</div>';
            });

            // Copy button
            html += '<p><button type="button" class="button" id="copy-smoke-test-results">📋 Copy Full Report</button></p>';

            $('#smoke-test-results').html(html);

            // Copy button handler
            $('#copy-smoke-test-results').on('click', function() {
                var reportText = 'SEO Article Generator - Smoke Test Report\n';
                reportText += '='.repeat(50) + '\n\n';
                reportText += 'Summary:\n';
                reportText += 'Total Tests: ' + summary.total + '\n';
                reportText += 'Passed: ' + summary.passed + '\n';
                reportText += 'Failed: ' + summary.failed + '\n';
                reportText += 'Duration: ' + summary.duration + 'ms\n\n';

                $.each(results.categories, function(categoryKey, categoryData) {
                    var categoryName = categoryNames[categoryKey] || categoryKey;
                    reportText += categoryName + ':\n';
                    reportText += '  Passed: ' + categoryData.passed + ' / ' + categoryData.total + '\n';

                    if (categoryData.errors && categoryData.errors.length > 0) {
                        reportText += '  Errors:\n';
                        $.each(categoryData.errors, function(index, error) {
                            reportText += '    - ' + error.error + '\n';
                            reportText += '      Suggestion: ' + error.suggestion + '\n';
                        });
                    }
                    reportText += '\n';
                });

                // Copy to clipboard
                var tempInput = $('<textarea>');
                $('body').append(tempInput);
                tempInput.val(reportText).select();
                document.execCommand('copy');
                tempInput.remove();

                $(this).text('✓ Copied!').prop('disabled', true);
                setTimeout(function() {
                    $('#copy-smoke-test-results').text('📋 Copy Full Report').prop('disabled', false);
                }, 2000);
            });
        }

        function escapeHtml(text) {
            if (typeof text !== 'string') return '';
            var map = {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            };
            return text.replace(/[&<>"']/g, function(m) {
                return map[m];
            });
        }

        // ===== CANONICAL SLUG MIGRATION =====
        var migrationStats = { total: 0, processed: 0, succeeded: 0, failed: 0 };
        var stopMigration = false;

        /**
         * Custom confirm dialog with proper text color (fixes dark mode issue
         * where native confirm() renders white text on white background).
         * Returns a Promise that resolves to true/false.
         */
        function seoGenConfirm(message, title) {
            title = title || 'Confirm Action';
            return new Promise(function(resolve) {
                var $dialog = $('<div class="seo-gen-confirm-dialog" style="display:none;"></div>')
                    .html('<div style="padding:20px; background:#fff; border:1px solid #ccc; border-radius:4px; max-width:450px; box-shadow:0 4px 20px rgba(0,0,0,0.3);">' +
                        '<h3 style="margin:0 0 12px; color:#1d2327; font-size:16px;">' + $('<div>').text(title).html() + '</h3>' +
                        '<p style="margin:0 0 20px; color:#1d2327; font-size:14px; line-height:1.5;">' + $('<div>').text(message).html() + '</p>' +
                        '<div style="text-align:right;">' +
                        '<button type="button" class="button seo-gen-cancel-btn" style="margin-right:8px; color:#1d2327; background:#f6f7f7; border:1px solid #ccc;">Cancel</button>' +
                        '<button type="button" class="button button-primary seo-gen-ok-btn" style="color:#fff; background:#2271b1; border:1px solid #2271b1;">OK</button>' +
                        '</div></div>')
                    .appendTo('body');

                $dialog.dialog({
                    modal: true,
                    autoOpen: true,
                    width: 'auto',
                    maxWidth: 500,
                    dialogClass: 'seo-gen-confirm-modal',
                    open: function() {
                        $('.ui-dialog-titlebar').hide();
                    },
                    buttons: null
                });

                $dialog.find('.seo-gen-ok-btn').on('click', function() {
                    $dialog.dialog('destroy').remove();
                    resolve(true);
                });
                $dialog.find('.seo-gen-cancel-btn').on('click', function() {
                    $dialog.dialog('destroy').remove();
                    resolve(false);
                });
                $dialog.on('keydown', function(e) {
                    if (e.key === 'Escape') {
                        $dialog.dialog('destroy').remove();
                        resolve(false);
                    }
                    if (e.key === 'Enter') {
                        $dialog.dialog('destroy').remove();
                        resolve(true);
                    }
                });
            });
        }

        function loadMigrationStats() {
            // Store original button text for restoration
            var startBtn = $('#mig-start-btn');
            if (!startBtn.data('original-text')) {
                startBtn.data('original-text', startBtn.text());
            }
            logToMigConsole('Loading migration stats...', 'info');

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'seo_gen_slug_state',
                    nonce: '<?php echo \esc_js(\wp_create_nonce('seo_gen_nonce')); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        var data = response.data || {};
                        migrationStats = {
                            total: parseInt(data.total || 0, 10),
                            processed: parseInt(data.processed || 0, 10),
                            succeeded: parseInt(data.succeeded || 0, 10),
                            failed: parseInt(data.failed || 0, 10)
                        };

                        $('#mig-stat-total').text(migrationStats.total.toLocaleString());
                        $('#mig-stat-done').text(migrationStats.succeeded.toLocaleString());
                        $('#mig-stat-failed').text(migrationStats.failed.toLocaleString());
                        $('#mig-stat-rollback').text(data.rollback_ready ? '<?php echo esc_js(__("Yes", "seo-article-generator")); ?>' : '<?php echo esc_js(__("No", "seo-article-generator")); ?>');

                        updateMigrationProgress();
                    } else {
                        logToMigConsole('Stats Error: ' + (response.data ? (response.data.message || response.data.error) : 'Unknown'), 'error');
                    }
                },
                error: function() {
                    logToMigConsole('Connection Error: Could not reach server for stats.', 'error');
                }
            });
        }

        function updateMigrationProgress() {
            var total = migrationStats.total || 0;
            var processed = migrationStats.processed || 0;

            if (total <= 0) {
                $('#mig-progress-bar').css('width', '0%');
                $('#mig-progress-text').text('0%');
                return;
            }

            if (processed < 0) processed = 0;
            if (processed > total) processed = total;

            var percent = Math.min(100, Math.round((processed / total) * 100));
            $('#mig-progress-bar').css('width', percent + '%');
            $('#mig-progress-text').text(percent + '%');
        }

        function logToMigConsole(message, type) {
            var color = '#f0f0f1';
            if (type === 'success') color = '#46b450';
            if (type === 'error') color = '#d63638';
            if (type === 'info') color = '#72aee6';
            if (type === 'dry') color = '#f0b849';

            var timestamp = new Date().toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
            var entry = $('<div class="bf-log-entry"></div>')
                .append('<span style="color:#8c8f94; font-size:10px; margin-right:8px;">[' + escapeHtml(timestamp) + ']</span>')
                .append('<span style="color:' + color + ';">' + message + '</span>');

            var consoleEl = $('#mig-console');
            consoleEl.append(entry);
            consoleEl.scrollTop(consoleEl[0].scrollHeight);
        }

        // Dry Run
        $('#mig-dry-run-btn').on('click', function() {
            var button = $(this);
            var limit = parseInt($('#mig-dry-run-limit').val(), 10) || 20;
            var originalText = button.text();

            button.prop('disabled', true).addClass('updating').attr('data-loading-text', '<?php \esc_js(__('Previewing...', 'seo-article-generator')); ?>').text('<?php \esc_js(__('Previewing...', 'seo-article-generator')); ?>');
            logToMigConsole('Starting dry run (limit: ' + limit + ')...', 'info');

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'seo_gen_slug_dry_run',
                    nonce: '<?php echo \esc_js(\wp_create_nonce('seo_gen_nonce')); ?>',
                    limit: limit
                },
                success: function(response) {
                    if (response.success) {
                        var data = response.data;
                        var preview = data.preview || [];

                        var tbody = $('#mig-preview-body');
                        tbody.empty();

                        if (preview.length === 0) {
                            tbody.append('<tr><td colspan="5" style="text-align:center; padding:20px; color:#8c8f94;"><?php \esc_js(__('No versioned posts found to migrate.', 'seo-article-generator')); ?></td></tr>');
                        } else {
                            $.each(preview, function(i, item) {
                                var row = $('<tr></tr>');
                                row.append('<td>' + item.post_id + '</td>');
                                row.append('<td>' + escapeHtml(item.title) + '</td>');
                                row.append('<td><code>' + escapeHtml(item.old_slug) + '</code></td>');
                                row.append('<td><code style="color:#2e7d32;">' + escapeHtml(item.new_slug) + '</code></td>');
                                row.append('<td><span class="dashicons dashicons-yes" style="color:#46b450;"></span></td>');
                                tbody.append(row);
                            });
                        }

                        $('#mig-preview-table-wrap').show();
                        $('#mig-stat-total').text((data.total_versioned || 0).toLocaleString());

                        logToMigConsole('Dry run complete: ' + preview.length + ' posts previewed of ' + (data.total_versioned || 0) + ' total versioned posts.', 'success');
                    } else {
                        logToMigConsole('Dry Run Error: ' + (response.data ? (response.data.message || response.data.error) : 'Unknown'), 'error');
                    }
                    button.prop('disabled', false).removeClass('updating').removeAttr('data-loading-text').text(originalText);
                },
                error: function() {
                    logToMigConsole('AJAX error during dry run.', 'error');
                    button.prop('disabled', false).removeClass('updating').removeAttr('data-loading-text').text(originalText);
                }
            });
        });

        // Run Migration — single post per AJAX call (avoids gateway timeouts)
        $('#mig-start-btn').on('click', function() {
            var button = $(this);
            var originalText = button.text();
            var disableRedirects = $('#mig-disable-rm-redirects').is(':checked');

            seoGenConfirm('<?php \esc_js(__('This will permanently change slugs and create 301 redirects. Run Dry Run first to preview changes. Continue?', 'seo-article-generator')); ?>', '<?php \esc_js(__('Start Migration', 'seo-article-generator')); ?>').then(function(confirmed) {
                if (!confirmed) {
                    return;
                }

                button.prop('disabled', true).addClass('updating').attr('data-loading-text', '<?php \esc_js(__('Migrating...', 'seo-article-generator')); ?>').text('<?php \esc_js(__('Migrating...', 'seo-article-generator')); ?>');
                $('#mig-stop-btn').show();
                stopMigration = false;
                var retryCount = 0;
                var maxRetries = 3;
                logToMigConsole('Starting migration (disable redirects: ' + (disableRedirects ? 'yes' : 'no') + ')...', 'info');

                function runNextPost() {
                    if (stopMigration) {
                        logToMigConsole('Migration stopped by user.', 'info');
                        $('#mig-start-btn').prop('disabled', false).removeClass('updating').removeAttr('data-loading-text').text(originalText);
                        $('#mig-stop-btn').hide();
                        loadMigrationStats();
                        return;
                    }

                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'seo_gen_slug_migrate',
                            nonce: '<?php echo \esc_js(\wp_create_nonce('seo_gen_nonce')); ?>',
                            disable_redirects: disableRedirects
                        },
                        success: function(response) {
                            retryCount = 0;
                            if (response.success) {
                                var data = response.data;
                                migrationStats = {
                                    total: parseInt(data.total || 0, 10),
                                    processed: parseInt(data.processed || 0, 10),
                                    succeeded: parseInt(data.succeeded || 0, 10),
                                    failed: parseInt(data.failed || 0, 10)
                                };

                                updateMigrationProgress();

                                if (data.batch_details && Array.isArray(data.batch_details)) {
                                    data.batch_details.forEach(function(item) {
                                        if (item.success) {
                                            var action = item.note || 'Migrated';
                                            logToMigConsole('Post #' + item.post_id + ': ' + item.old_slug + ' → ' + item.new_slug + ' (' + action + ') [301: ' + (item.redirect_created ? 'yes' : 'no') + ']', 'success');
                                        } else {
                                            logToMigConsole('Post #' + item.post_id + ' FAILED: ' + (item.error || 'Unknown error'), 'error');
                                        }
                                    });
                                }

                                if (data.has_more) {
                                    runNextPost();
                                } else {
                                    logToMigConsole('Migration complete! Total: ' + data.processed + ', Succeeded: ' + data.succeeded + ', Failed: ' + data.failed, 'success');
                                    $('#mig-start-btn').prop('disabled', false).removeClass('updating').removeAttr('data-loading-text').text(originalText);
                                    $('#mig-stop-btn').hide();
                                    loadMigrationStats();
                                }
                            } else {
                                var errMsg = (response.data ? (response.data.message || response.data.error) : 'Unknown');
                                logToMigConsole('Migration Error: ' + errMsg, 'error');
                                if (++retryCount <= maxRetries) {
                                    var delay = Math.pow(2, retryCount) * 1000;
                                    logToMigConsole('Retrying in ' + (delay / 1000) + 's... (attempt ' + retryCount + '/' + maxRetries + ')', 'info');
                                    setTimeout(runNextPost, delay);
                                } else {
                                    logToMigConsole('Max retries reached. Migration halted.', 'error');
                                    $('#mig-start-btn').prop('disabled', false).removeClass('updating').removeAttr('data-loading-text').text(originalText);
                                    $('#mig-stop-btn').hide();
                                    loadMigrationStats();
                                }
                            }
                        },
                        error: function() {
                            logToMigConsole('AJAX error during migration.', 'error');
                            if (++retryCount <= maxRetries) {
                                var delay = Math.pow(2, retryCount) * 1000;
                                logToMigConsole('Retrying in ' + (delay / 1000) + 's... (attempt ' + retryCount + '/' + maxRetries + ')', 'info');
                                setTimeout(runNextPost, delay);
                            } else {
                                logToMigConsole('Max retries reached. Migration halted.', 'error');
                                $('#mig-start-btn').prop('disabled', false).removeClass('updating').removeAttr('data-loading-text').text(originalText);
                                $('#mig-stop-btn').hide();
                                loadMigrationStats();
                            }
                        }
                    });
                }

                runNextPost();
            });
        });

        $('#mig-stop-btn').on('click', function() {
            stopMigration = true;
            logToMigConsole('Stop requested. Finishing current batch...', 'info');
            // Immediate UI feedback
            var startBtn = $('#mig-start-btn');
            var originalText = startBtn.data('original-text') || '<?php \esc_js(__('Start Migration', 'seo-article-generator')); ?>';
            startBtn.prop('disabled', false).removeClass('updating').removeAttr('data-loading-text').text(originalText);
            $(this).hide();
        });

        // Internal Links Update
        $('#mig-update-links-btn').on('click', function() {
            var button = $(this);
            var originalText = button.text();

            seoGenConfirm('<?php \esc_js(__('This will update internal links in post content to point to new clean slugs. A backup will be created for rollback. Continue?', 'seo-article-generator')); ?>', '<?php \esc_js(__('Update Internal Links', 'seo-article-generator')); ?>').then(function(confirmed) {
                if (!confirmed) {
                    return;
                }

                button.prop('disabled', true).addClass('updating').attr('data-loading-text', '<?php \esc_js(__('Updating...', 'seo-article-generator')); ?>').text('<?php \esc_js(__('Updating...', 'seo-article-generator')); ?>');
                $('#mig-rollback-links-btn').hide();
                stopMigration = false;
                logToMigConsole('Starting internal links update...', 'info');

                function runNextLinkUpdate() {
                    if (stopMigration) {
                        logToMigConsole('Links update stopped by user.', 'info');
                        $('#mig-update-links-btn').prop('disabled', false).removeClass('updating').removeAttr('data-loading-text').text(originalText);
                        return;
                    }

                    $.ajax({
                        url: ajaxurl,
                        type: 'POST',
                        data: {
                            action: 'seo_gen_update_links',
                            nonce: '<?php echo \esc_js(\wp_create_nonce('seo_gen_nonce')); ?>'
                        },
                        success: function(response) {
                            if (response.success) {
                                var data = response.data;

                                if (data.message) {
                                    logToMigConsole(data.message, 'error');
                                    button.prop('disabled', false).removeClass('updating').removeAttr('data-loading-text').text(originalText);
                                    return;
                                }

                                var last = data.last_result || {};
                                if (last.updated) {
                                    logToMigConsole('Post #' + last.post_id + ': updated ' + last.count + ' link(s)', 'success');
                                }

                                if (data.has_more) {
                                    runNextLinkUpdate();
                                } else {
                                    logToMigConsole('Links update complete! Processed: ' + data.processed + ', Updated: ' + data.updated, 'success');
                                    $('#mig-update-links-btn').prop('disabled', false).removeClass('updating').removeAttr('data-loading-text').text(originalText);
                                    $('#mig-rollback-links-btn').show();
                                    loadMigrationStats();
                                }
                            } else {
                                var errMsg = (response.data ? (response.data.message || response.data.error) : 'Unknown');
                                logToMigConsole('Links Update Error: ' + errMsg, 'error');
                                button.prop('disabled', false).removeClass('updating').removeAttr('data-loading-text').text(originalText);
                            }
                        },
                        error: function() {
                            logToMigConsole('AJAX error during links update.', 'error');
                            button.prop('disabled', false).removeClass('updating').removeAttr('data-loading-text').text(originalText);
                        }
                    });
                }

                runNextLinkUpdate();
            });
        });

        // Rollback Internal Links
        $('#mig-rollback-links-btn').on('click', function() {
            seoGenConfirm('<?php \esc_js(__('This will restore original post content for all updated links. Continue?', 'seo-article-generator')); ?>', '<?php \esc_js(__('Rollback Links', 'seo-article-generator')); ?>').then(function(confirmed) {
                if (!confirmed) {
                    return;
                }

                var button = $(this);
                var originalText = button.text();
                button.prop('disabled', true).addClass('updating').attr('data-loading-text', '<?php \esc_js(__('Rolling back...', 'seo-article-generator')); ?>').text('<?php \esc_js(__('Rolling back...', 'seo-article-generator')); ?>');
                logToMigConsole('Starting links rollback...', 'info');

                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'seo_gen_rollback_links',
                        nonce: '<?php echo \esc_js(\wp_create_nonce('seo_gen_nonce')); ?>'
                    },
                    success: function(response) {
                        if (response.success && response.data && response.data.success) {
                            logToMigConsole('Links rollback complete: restored=' + response.data.restored + ', failed=' + response.data.failed, 'success');
                            $('#mig-rollback-links-btn').hide();
                        } else {
                            var errMsg = (response.data && response.data.message) ? response.data.message : 'Unknown error';
                            logToMigConsole('Links Rollback Error: ' + errMsg, 'error');
                        }
                        button.prop('disabled', false).removeClass('updating').removeAttr('data-loading-text').text(originalText);
                        loadMigrationStats();
                    },
                    error: function() {
                        logToMigConsole('AJAX error during links rollback.', 'error');
                        button.prop('disabled', false).removeClass('updating').removeAttr('data-loading-text').text(originalText);
                    }
                });
            });
        });

        $('#mig-rollback-btn').on('click', function() {
            seoGenConfirm('<?php \esc_js(__('This will revert ALL migrated slugs to their original versioned URLs and remove the 301 redirects. This action cannot be undone after rollback. Continue?', 'seo-article-generator')); ?>', '<?php \esc_js(__('Rollback Migration', 'seo-article-generator')); ?>').then(function(confirmed) {
                if (!confirmed) {
                    return;
                }

                var button = $(this);
                var originalText = button.text();
                button.prop('disabled', true).addClass('updating').attr('data-loading-text', '<?php \esc_js(__('Rolling back...', 'seo-article-generator')); ?>').text('<?php \esc_js(__('Rolling back...', 'seo-article-generator')); ?>');
                logToMigConsole('Starting rollback...', 'info');

                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    timeout: 180000,
                    data: {
                        action: 'seo_gen_slug_rollback',
                        nonce: '<?php echo \esc_js(\wp_create_nonce('seo_gen_nonce')); ?>'
                    },
                    success: function(response) {
                        if (response.success && response.data && response.data.success !== false) {
                            var data = response.data;
                            // Log each post rollback detail
                            if (data.details && Array.isArray(data.details)) {
                                data.details.forEach(function(item) {
                                    if (item.success) {
                                        logToMigConsole('Post #' + item.post_id + ': restored ' + item.new_slug + ' → ' + item.old_slug + ' [301 redirect removed]', 'success');
                                    } else {
                                        logToMigConsole('Post #' + item.post_id + ' ROLLBACK FAILED: ' + (item.error || 'Unknown error'), 'error');
                                    }
                                });
                            }
                            logToMigConsole('Rollback complete: restored=' + data.restored + ', failed=' + data.failed, 'success');
                        } else {
                            var errMsg = (response.data && response.data.error) ? response.data.error : 'Unknown error';
                            logToMigConsole('Rollback Error: ' + errMsg, 'error');
                        }
                        loadMigrationStats();
                        button.prop('disabled', false).removeClass('updating').removeAttr('data-loading-text').text(originalText);
                    },
                    error: function() {
                        logToMigConsole('AJAX error during rollback.', 'error');
                        button.prop('disabled', false).removeClass('updating').removeAttr('data-loading-text').text(originalText);
                    }
                });
            });
        });

        $('#mig-refresh-btn').on('click', function() {
            loadMigrationStats();
        });

        // Clear All Redirections
        $('#mig-clear-redirs-btn').on('click', function() {
            var button = $(this);
            var originalText = button.text();

            seoGenConfirm('<?php \esc_js(__('This will DELETE ALL active and inactive Rank Math redirections. This cannot be undone. Continue?', 'seo-article-generator')); ?>', '<?php \esc_js(__('Clear All Redirections', 'seo-article-generator')); ?>').then(function(confirmed) {
                if (!confirmed) {
                    return;
                }

                button.prop('disabled', true).addClass('updating').attr('data-loading-text', '<?php \esc_js(__('Clearing...', 'seo-article-generator')); ?>').text('<?php \esc_js(__('Clearing...', 'seo-article-generator')); ?>');
                logToMigConsole('Clearing all Rank Math redirections...', 'info');

                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    timeout: 120000,
                    data: {
                        action: 'seo_gen_slug_clear_redirections',
                        nonce: '<?php echo \esc_js(\wp_create_nonce('seo_gen_nonce')); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            logToMigConsole('Cleared ' + response.data.deleted + ' redirections.', 'success');
                            loadMigrationStats();
                        } else {
                            logToMigConsole('Clear Redirections Error: ' + (response.data ? (response.data.message || response.data.error) : 'Unknown'), 'error');
                        }
                        button.prop('disabled', false).removeClass('updating').removeAttr('data-loading-text').text(originalText);
                    },
                    error: function() {
                        logToMigConsole('AJAX error during clear redirections.', 'error');
                        button.prop('disabled', false).removeClass('updating').removeAttr('data-loading-text').text(originalText);
                    }
                });
            });
        });

        // ===== CUSTOM PROVIDERS UI =====
        var seoGenCustomProviderIdx = <?php echo count($custom_providers); ?>;

        function seoGenAddProviderCard() {
            var tpl = jQuery('#seo-gen-custom-provider-template').html();
            var newIdx = seoGenCustomProviderIdx++;
            // Replace {{IDX}} placeholder with actual index in name and data-idx attributes
            tpl = tpl.replace(/\{\{IDX\}\}/g, newIdx);
            var $card = jQuery(tpl);
            $card.attr('data-idx', newIdx);
            // Ensure data-idx attributes for web search toggle and model management
            $card.find('.seo-gen-ws-toggle').attr('data-idx', newIdx);
            $card.find('.seo-gen-ws-config').attr('data-idx', newIdx);
            $card.find('.seo-gen-add-model').attr('data-idx', newIdx);
            $card.find('.seo-gen-model-list').attr('data-idx', newIdx);
            jQuery('#seo-gen-no-custom-providers').hide();
            jQuery('#seo-gen-custom-providers-container').append($card);
        }

        function seoGenRemoveProviderCard($card) {
            $card.remove();
            if (jQuery('.seo-gen-custom-provider-card').length === 0) {
                jQuery('#seo-gen-no-custom-providers').show();
            }
        }

        function seoGenAddModelRow(listIdx) {
            var modelIdx = jQuery('.seo-gen-model-list[data-idx="' + listIdx + '"] .seo-gen-model-row').length;
            var html = '<div class="seo-gen-model-row" style="display:flex; gap:8px; margin-bottom:8px; align-items:center;">'
                + '<input type="text" name="seo_gen_custom_providers[' + listIdx + '][models][' + modelIdx + '][model_id]" class="regular-text" placeholder="model-id" style="flex:1;">'
                + '<input type="text" name="seo_gen_custom_providers[' + listIdx + '][models][' + modelIdx + '][display_name]" class="regular-text" placeholder="Display Name" style="flex:1;">'
                + '<button type="button" class="button seo-gen-remove-model" title="Remove model">&times;</button>'
                + '</div>';
            jQuery('.seo-gen-model-list[data-idx="' + listIdx + '"]').append(html);
        }

        jQuery(document).on('click', '#seo-gen-add-custom-provider', function() {
            seoGenAddProviderCard();
        });

        jQuery(document).on('click', '.seo-gen-remove-provider', function() {
            if (confirm('<?php echo \esc_js(__('Remove this custom provider?', 'seo-article-generator')); ?>')) {
                seoGenRemoveProviderCard(jQuery(this).closest('.seo-gen-custom-provider-card'));
            }
        });

        jQuery(document).on('click', '.seo-gen-remove-model', function() {
            jQuery(this).closest('.seo-gen-model-row').remove();
        });

        jQuery(document).on('click', '.seo-gen-add-model', function() {
            var idx = jQuery(this).data('idx');
            if (typeof idx === 'undefined') {
                idx = jQuery(this).closest('.seo-gen-custom-provider-card').data('idx');
            }
            seoGenAddModelRow(idx);
        });

        jQuery(document).on('change', '.seo-gen-ws-toggle', function() {
            var idx = jQuery(this).data('idx');
            var $config = jQuery('.seo-gen-ws-config[data-idx="' + idx + '"]');
            if (this.checked) {
                $config.show();
            } else {
                $config.hide();
            }
        });

        jQuery(document).on('click', '.seo-gen-test-custom-provider', function() {
            var $btn = jQuery(this);
            var $result = $btn.siblings('.seo-gen-custom-test-result');
            var $card = $btn.closest('.seo-gen-custom-provider-card');
            var providerName = $card.find('input[name*="[name]"]').val() || 'Custom Provider';
            var apiUrl = $card.find('input[name*="[api_url]"]').val();
            var apiKey = $card.find('input[name*="[api_key]"]').val();
            var modelId = $card.find('input[name*="[model_id]"]').first().val();
            // @FIX 2026-05-22: pass saved provider ID so backend can retrieve encrypted key
            var providerId = $btn.data("provider-id") || $card.data("provider-id") || "";

            if (!apiUrl) {
                $result.html('<span style="color:red;"><?php echo \esc_js(__('API URL is required', 'seo-article-generator')); ?></span>');
                return;
            }
            if (!apiKey && !providerId) {
                $result.html('<span style="color:red;"><?php echo \esc_js(__('API Key is required', 'seo-article-generator')); ?></span>');
                return;
            }
            if (!modelId) {
                $result.html('<span style="color:red;"><?php echo \esc_js(__('At least one model ID is required', 'seo-article-generator')); ?></span>');
                return;
            }

            $btn.prop('disabled', true).text('<?php echo \esc_js(__('Testing...', 'seo-article-generator')); ?>');
            $result.html('');

            jQuery.ajax({
                url: (typeof seoGenData !== 'undefined' && seoGenData.ajax_url) ? seoGenData.ajax_url : ajaxurl,
                type: 'POST',
                timeout: 30000,
                data: {
                    action: 'seo_gen_test_custom_provider',
                    nonce: '<?php echo \esc_js(wp_create_nonce('seo_gen_nonce')); ?>',
                    api_url: apiUrl,
                    api_key: apiKey,
                    provider_id: providerId,
                    model_id: modelId,
                    provider_name: providerName
                },
                success: function(response) {
                    if (response.success) {
                        $result.html('<span style="color:green;">✓ ' + response.data.message + '</span>');
                    } else {
                        $result.html('<span style="color:red;">✗ ' + (response.data && response.data.message ? response.data.message : '<?php echo \esc_js(__('Connection failed', 'seo-article-generator')); ?>') + '</span>');
                    }
                },
                error: function() {
                    $result.html('<span style="color:red;"><?php echo \esc_js(__('Request failed', 'seo-article-generator')); ?></span>');
                },
                complete: function() {
                    $btn.prop('disabled', false).text('<?php echo \esc_js(__('Test Connection', 'seo-article-generator')); ?>');
                }
            });
        });

        // @MODIFIED 2026-07-12 - OpenRouter free model auto-sync button.
        // Inline (not external JS) so it always runs fresh even when the
        // cached admin JS is stale. Delegated so it works for dynamically
        // added provider cards too.
        jQuery(document).on('click', '.openrouter-sync-btn', function(e) {
            e.preventDefault();
            e.stopImmediatePropagation();

            var $btn = jQuery(this);
            var $card = $btn.closest('.seo-gen-custom-provider-card');
            var $status = $card.find('.openrouter-sync-status');
            var $text = $status.find('.openrouter-sync-text');

            if (!confirm('<?php echo \esc_js(__('Sync free models from OpenRouter? This appends new free models after your existing ones.', 'seo-article-generator')); ?>')) {
                return;
            }

            $btn.prop('disabled', true).text('<?php echo \esc_js(__('Syncing...', 'seo-article-generator')); ?>');
            $text.text('<?php echo \esc_js(__('Syncing models...', 'seo-article-generator')); ?>');
            $status.removeClass('sync-ok sync-warn').addClass('sync-warn');

            jQuery.post(ajaxurl, {
                action: 'seo_gen_sync_openrouter_models',
                nonce: '<?php echo \esc_js(\wp_create_nonce('seo_gen_nonce')); ?>'
            }, function(r) {
                if (r.success) {
                    $status.removeClass('sync-warn').addClass('sync-ok');
                    $text.text(r.data && r.data.message ? r.data.message : '<?php echo \esc_js(__('Sync complete.', 'seo-article-generator')); ?>');
                    alert(r.data && r.data.message ? r.data.message : '<?php echo \esc_js(__('Sync complete.', 'seo-article-generator')); ?>');
                    location.reload();
                } else {
                    $status.removeClass('sync-ok').addClass('sync-warn');
                    var msg = (r.data && r.data.message) ? r.data.message : '<?php echo \esc_js(__('Sync failed.', 'seo-article-generator')); ?>';
                    $text.text(msg);
                    alert('<?php echo \esc_js(__('Failed:', 'seo-article-generator')); ?> ' + msg);
                }
            }).fail(function(jqXHR, textStatus) {
                $text.text('<?php echo \esc_js(__('AJAX error.', 'seo-article-generator')); ?>');
                alert('<?php echo \esc_js(__('AJAX error:', 'seo-article-generator')); ?> ' + textStatus);
            }).always(function() {
                $btn.prop('disabled', false).text('<?php echo \esc_js(__('Sync Free Models', 'seo-article-generator')); ?>');
            });
        });

        // OpenCode Zen free model sync button — sibling of the OpenRouter sync.
        // Inline (not external JS) so it runs fresh even when admin JS is stale.
        // Delegated so it works for dynamically-added provider cards too.
        jQuery(document).on('click', '.zen-sync-btn', function(e) {
            e.preventDefault();
            e.stopImmediatePropagation();

            var $btn = jQuery(this);
            var $card = $btn.closest('.seo-gen-custom-provider-card');
            var $status = $card.find('.zen-sync-status');
            var $text = $status.find('.zen-sync-text');

            if (!confirm('<?php echo \esc_js(__('Sync free models from OpenCode Zen? This will REPLACE the current Zen model list with the whitelisted free IDs.', 'seo-article-generator')); ?>')) {
                return;
            }

            $btn.prop('disabled', true).text('<?php echo \esc_js(__('Syncing...', 'seo-article-generator')); ?>');
            $text.text('<?php echo \esc_js(__('Syncing models...', 'seo-article-generator')); ?>');
            $status.removeClass('sync-ok sync-warn').addClass('sync-warn');

            jQuery.post(ajaxurl, {
                action: 'seo_gen_sync_zen_models',
                nonce: '<?php echo \esc_js(\wp_create_nonce('seo_gen_nonce')); ?>'
            }, function(r) {
                if (r.success) {
                    $status.removeClass('sync-warn').addClass('sync-ok');
                    $text.text(r.data && r.data.message ? r.data.message : '<?php echo \esc_js(__('Sync complete.', 'seo-article-generator')); ?>');
                    alert(r.data && r.data.message ? r.data.message : '<?php echo \esc_js(__('Sync complete.', 'seo-article-generator')); ?>');
                    location.reload();
                } else {
                    $status.removeClass('sync-ok').addClass('sync-warn');
                    var msg = (r.data && r.data.message) ? r.data.message : '<?php echo \esc_js(__('Sync failed.', 'seo-article-generator')); ?>';
                    $text.text(msg);
                    alert('<?php echo \esc_js(__('Failed:', 'seo-article-generator')); ?> ' + msg);
                }
            }).fail(function(jqXHR, textStatus) {
                $text.text('<?php echo \esc_js(__('AJAX error.', 'seo-article-generator')); ?>');
                alert('<?php echo \esc_js(__('AJAX error:', 'seo-article-generator')); ?> ' + textStatus);
            }).always(function() {
                $btn.prop('disabled', false).text('<?php echo \esc_js(__('Sync Zen Models', 'seo-article-generator')); ?>');
            });
        });

        // DEBUG: Intercept form submission to see what's being submitted
        jQuery(document).on('submit', '#seo-gen-settings-form', function(e) {
            console.log('[FORM SUBMIT] Intercepting form submission...');
            var formData = jQuery(this).serializeArray();
            var customProviderFields = formData.filter(function(item) { return item.name && item.name.indexOf('seo_gen_custom_providers') === 0; });
            console.log('[FORM SUBMIT] Custom provider fields count:', customProviderFields.length);
            console.log('[FORM SUBMIT] Custom provider field names:', customProviderFields.map(function(item) { return item.name; }));
        });

    });
</script>
