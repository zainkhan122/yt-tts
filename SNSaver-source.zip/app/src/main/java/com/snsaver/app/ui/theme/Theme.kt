package com.snsaver.app.ui.theme
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
private val Dark=darkColorScheme(primary=Color(0xFF00D4AA),onPrimary=Color(0xFF00382C),primaryContainer=Color(0xFF00513F),background=Color(0xFF0B1210),surface=Color(0xFF0B1210),surfaceContainer=Color(0xFF151E1B),surfaceContainerHigh=Color(0xFF202A26),onSurface=Color(0xFFE0E6E1),onSurfaceVariant=Color(0xFFBBC9C1))
private val Light=lightColorScheme(primary=Color(0xFF006B54),primaryContainer=Color(0xFF70F8D1),background=Color(0xFFF5FBF7),surface=Color(0xFFF5FBF7),surfaceContainer=Color(0xFFE9F1EC))
@Composable
fun SNSaverTheme(
    dark: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) = MaterialTheme(
    colorScheme = if (dark) Dark else Light,
    typography = Typography(),
    content = content
)
