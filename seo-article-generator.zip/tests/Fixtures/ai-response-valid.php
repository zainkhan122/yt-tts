<?php

return array(
    'title' => 'VLC Media Player 4.0 Download for Windows, macOS, Linux Mar 2026',
    'meta_description' => 'Download VLC Media Player for Windows, macOS, and Linux with playback, codec, and streaming support in one lightweight app.',
    'introduction' => array(
        'VLC Media Player is a widely used media player built for local playback, streams, and broad codec compatibility.',
        'This release focuses on reliable playback, simple controls, and support across desktop platforms.',
    ),
    'features' => array(
        array('title' => 'Codec support', 'description' => 'Plays common media formats without extra codec packs.'),
        array('title' => 'Streaming tools', 'description' => 'Supports local network and internet stream playback.'),
        array('title' => 'Lightweight UI', 'description' => 'Keeps controls simple while still exposing advanced options.'),
        array('title' => 'Playlist handling', 'description' => 'Manages long playlists and remembers playback position.'),
    ),
    'faqs' => array(
        array('question' => 'Is VLC free?', 'answer' => 'Yes, VLC is free and open-source.'),
        array('question' => 'Does VLC support subtitles?', 'answer' => 'Yes, it supports embedded and external subtitles.'),
        array('question' => 'Can VLC stream media?', 'answer' => 'Yes, it can play and stream many network sources.'),
    ),
    'tech_specs' => array(
        'software_name' => 'VLC Media Player',
        'version' => '4.0',
        'developer' => 'VideoLAN',
        'homepage' => 'https://www.videolan.org/vlc/',
        'last_updated' => '2026-03-08',
        'license' => 'Open-source',
        'os_support' => 'Windows, macOS, Linux',
        'file_size' => '45 MB',
        'application_category' => 'VideoApplication',
    ),
    'system_requirements' => array(
        'minimum' => array(
            'os' => 'Windows 10 / macOS 12 / Ubuntu 22.04',
            'processor' => 'Dual-core processor',
            'memory' => '4 GB RAM',
            'storage' => '200 MB free space',
        ),
    ),
    'installation_guide' => array(
        'steps' => array(
            'Download the installer for your platform.',
            'Open the installer package.',
            'Follow the setup wizard and launch VLC.',
        ),
    ),
    'safety' => array(
        'verified_download' => true,
        'scan_result' => 'No threats detected',
    ),
    'download_section' => array(
        'links' => array(
            array(
                'platform' => 'Windows',
                'variant' => 'x64',
                'text' => 'Download VLC for Windows 64-bit',
                'url' => 'https://get.videolan.org/vlc/4.0/win64/vlc-4.0-win64.exe',
                'is_primary' => true,
            ),
            array(
                'platform' => 'macOS',
                'variant' => 'Universal',
                'text' => 'Download VLC for macOS',
                'url' => 'https://get.videolan.org/vlc/4.0/macosx/vlc-4.0.dmg',
                'is_primary' => false,
            ),
            array(
                'platform' => 'Linux',
                'variant' => 'Standard',
                'text' => 'Download VLC for Linux',
                'url' => 'https://get.videolan.org/vlc/4.0/linux/vlc-4.0.tar.gz',
                'is_primary' => false,
            ),
        ),
    ),
    'whats_new' => array(),
    'moat_data' => array(
        'content' => array('VLC stands out because it supports a huge range of codecs without extra setup.'),
    ),
    'html_content' => '<p>Placeholder content before formatter runs.</p>',
);
