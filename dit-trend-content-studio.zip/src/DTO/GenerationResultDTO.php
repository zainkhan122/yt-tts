<?php

namespace DIT\TrendStudio\DTO;

/**
 * Data Transfer Object representing the result of content generation.
 */
class GenerationResultDTO
{
    public string $headline = '';
    public array $sections = [];
    public int $wordCount = 0;
    public array $imageSuggestions = [];
    public ?int $featuredCollageId = null;
    public string $generationMethod = '';

    /**
     * Create from associative array.
     *
     * @param array $data
     * @return static
     */
    public static function fromArray(array $data): self
    {
        $dto = new self();
        $dto->headline          = $data['headline'] ?? '';
        $dto->sections          = $data['sections'] ?? [];
        $dto->wordCount         = (int) ($data['word_count'] ?? 0);
        $dto->imageSuggestions  = $data['image_suggestions'] ?? [];
        $dto->featuredCollageId = $data['_featured_collage_id'] ?? null;
        $dto->generationMethod  = $data['_generation_method'] ?? '';
        return $dto;
    }

    /**
     * Convert back to array. Keeps extra keys unmodified.
     *
     * @param array $extra Additional data to merge.
     * @return array
     */
    public function toArray(array $extra = []): array
    {
        $base = [
            'headline' => $this->headline,
            'sections' => $this->sections,
            'word_count' => $this->wordCount,
            'image_suggestions' => $this->imageSuggestions,
        ];
        if ($this->featuredCollageId !== null) {
            $base['_featured_collage_id'] = $this->featuredCollageId;
        }
        if (!empty($this->generationMethod)) {
            $base['_generation_method'] = $this->generationMethod;
        }
        return array_merge($base, $extra);
    }
}
