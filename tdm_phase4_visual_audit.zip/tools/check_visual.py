#!/usr/bin/env python3
"""Visual diversity + type lock + feasibility. Does not render.

  python3 tools/check_visual.py DIR

Exit 0 pass/warn, 1 usage, 3 fail. Never 2.
"""
from __future__ import annotations
import json
import sys
from pathlib import Path

ROOT = Path("/home/user")
sys.path.insert(0, str(ROOT / "tools"))
import visual_fp as fp  # noqa: E402
from plan_visual import plan, topic_id  # noqa: E402

GENERIC = fp.GENERIC


def main():
    args = sys.argv[1:]
    if not args:
        print("usage: check_visual.py DIR")
        sys.exit(1)
    base = Path(args[0]).resolve()
    if not base.exists():
        print("usage: check_visual.py DIR")
        sys.exit(1)
    tid = topic_id(base)
    vp_path = base / "visual_plan.json"
    vp = json.loads(vp_path.read_text()) if vp_path.exists() else plan(base)
    warns, fails = [], []

    html = None
    for cand in (base / "index.html",):
        if cand.exists():
            html = cand.read_text(encoding="utf-8", errors="ignore")
            break
    # s01 lives one level down
    if html is None:
        nested = list(base.glob("*/index.html"))
        if nested:
            html = nested[0].read_text(encoding="utf-8", errors="ignore")

    banned = fp.banned_sets()
    if html:
        ids = fp.ids_from_html(html)
        fonts = fp.fonts_from_html(html)
        if len(fonts) > 1:
            fails.append(f"type lock: multiple font-family {sorted(fonts)}")
        if tid not in ("s01", "s02"):
            for name, bset in banned.items():
                j = fp.jaccard(ids, bset)
                inter = ids & bset
                if j >= 0.35 and len(inter) >= 4:
                    fails.append(
                        f"composition clone of {name} jaccard={j:.2f} shared={sorted(inter)[:12]}"
                    )
        # s02 door ids
        if tid not in ("s02",) and {"d1", "d2", "d3", "d4", "d5", "d6"} <= ids:
            fails.append("new family reuses s02 door slab ids d1–d6")
    else:
        warns.append("no index.html — custom composition not present (fallback path)")

    needs_p = base / "beat_needs.json"
    if needs_p.exists():
        needs = json.loads(needs_p.read_text())
        needs = needs.get("needs") or needs
        hfs = [n.get("hf") for n in needs if n.get("hf")]
        consec = sum(1 for a, b in zip(hfs, hfs[1:]) if a == b)
        if consec:
            fails.append(f"{consec} consecutive beats share the same hf machine")
        if hfs and set(hfs) <= GENERIC and tid not in ("s01", "s02"):
            warns.append("only generic hf_compose scenes — not an identity")

    if vp.get("feasibility") not in ("stills_gsap", "stills_kenburns"):
        fails.append(f"feasibility {vp.get('feasibility')!r} is not something we can shoot")
    if vp.get("mode") not in ("character", "environment", "object", "mechanism", "symbol"):
        fails.append("mode missing")
    motif = (vp.get("motif") or "").lower()
    if tid not in ("s02",) and vp.get("mode") == "mechanism" and "door-slab" in motif:
        fails.append("cognitive mechanism motif still using s02 doors")

    print(f"check_visual topic={tid} mode={vp.get('mode')} identity={vp.get('identity_id')}")
    print(f"  motif={vp.get('motif')!r}")
    print(f"  type={vp.get('type')}")
    print(f"  feasibility={vp.get('feasibility')}")
    for w in warns:
        print("WARN", w)
    for f in fails:
        print("FAIL", f)
    if fails:
        sys.exit(3)
    print("PASS visual")
    sys.exit(0)


if __name__ == "__main__":
    main()
