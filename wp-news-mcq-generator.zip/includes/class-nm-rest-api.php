<?php

/**
 * REST API Controller
 *
 * Provides REST endpoints for question operations used by Video Studio.
 * Exposes atomic question reservation for companion plugins.
 *
 * @package    WP_News_MCQ_Generator
 * @subpackage Includes
 * @since      9.0.0
 */

if (! defined('ABSPATH')) {
	exit;
}

/**
 * Class NM_Rest_API
 *
 * REST API controller for MCQ question operations.
 *
 * @since 9.0.0
 */
class NM_Rest_API
{


	/**
	 * API namespace.
	 *
	 * @var string
	 */
	const NAMESPACE = 'nm-mcq/v1';

	/**
	 * Singleton instance.
	 *
	 * @var NM_Rest_API|null
	 */
	private static $instance = null;

	/**
	 * Initialize the REST API.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public static function init()
	{
		if (null === self::$instance) {
			self::$instance = new self();
		}
	}

	/**
	 * Constructor.
	 *
	 * @since 9.0.0
	 */
	private function __construct()
	{
		add_action('rest_api_init', array($this, 'register_routes'));
	}

	/**
	 * Register REST routes.
	 *
	 * @since 9.0.0
	 * @return void
	 */
	public function register_routes()
	{
		// GET /sources - List topics/exams.
		register_rest_route(
			self::NAMESPACE,
			'/sources',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array($this, 'get_sources'),
				'permission_callback' => array($this, 'check_admin_permission'),
				'args'                => array(
					'type' => array(
						'required'          => false,
						'default'           => 'topic',
						'sanitize_callback' => 'sanitize_text_field',
						'validate_callback' => function ($param) {
							return in_array($param, array('topic', 'exam'), true);
						},
					),
				),
			)
		);

		// GET /questions/eligible - Get unused questions.
		register_rest_route(
			self::NAMESPACE,
			'/questions/eligible',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array($this, 'get_eligible_questions'),
				'permission_callback' => array($this, 'check_admin_permission'),
				'args'                => array(
					'topic_id' => array(
						'required'          => true,
						'sanitize_callback' => 'absint',
					),
					'exam_id'  => array(
						'required'          => false,
						'sanitize_callback' => 'absint',
					),
					'limit'    => array(
						'required'          => false,
						'default'           => 50,
						'sanitize_callback' => 'absint',
					),
				),
			)
		);

		// POST /questions/reserve - Atomically reserve questions.
		register_rest_route(
			self::NAMESPACE,
			'/questions/reserve',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array($this, 'reserve_questions'),
				'permission_callback' => array($this, 'check_admin_permission'),
				'args'                => array(
					'topic_id' => array(
						'required'          => true,
						'sanitize_callback' => 'absint',
					),
					'exam_id'  => array(
						'required'          => false,
						'sanitize_callback' => 'absint',
					),
					'count'    => array(
						'required'          => true,
						'sanitize_callback' => 'absint',
						'validate_callback' => function ($param) {
							return $param >= 3 && $param <= 10;
						},
					),
					'job_id'   => array(
						'required'          => true,
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			)
		);

		// POST /questions/mark-used - Mark questions as used.
		register_rest_route(
			self::NAMESPACE,
			'/questions/mark-used',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array($this, 'mark_questions_used'),
				'permission_callback' => array($this, 'check_admin_permission'),
				'args'                => array(
					'question_ids' => array(
						'required'          => true,
						'validate_callback' => function ($param) {
							return is_array($param) && ! empty($param);
						},
					),
					'job_id'       => array(
						'required'          => true,
						'sanitize_callback' => 'sanitize_text_field',
					),
					'video_url'    => array(
						'required'          => false,
						'sanitize_callback' => 'esc_url_raw',
					),
				),
			)
		);

		// DELETE /questions/release - Release reserved questions.
		register_rest_route(
			self::NAMESPACE,
			'/questions/release',
			array(
				'methods'             => WP_REST_Server::DELETABLE,
				'callback'            => array($this, 'release_questions'),
				'permission_callback' => array($this, 'check_admin_permission'),
				'args'                => array(
					'job_id' => array(
						'required'          => true,
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			)
		);

		// ✅ NEW v8.9.7: Public Topic Search (Fallback for admin-ajax.php 403 blocks)
		register_rest_route(
			self::NAMESPACE,
			'/topics/search',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array($this, 'search_topics'),
				'permission_callback' => '__return_true', // Publicly accessible
				'args'                => array(
					'term' => array(
						'required'          => true,
						'sanitize_callback' => 'sanitize_text_field',
					),
				),
			)
		);

		// @MODIFIED v9.0.1: Public Quiz Generation (bypass admin-ajax.php 403 blocks)
		register_rest_route(
			self::NAMESPACE,
			'/quiz/generate',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array($this, 'generate_quiz'),
				'permission_callback' => '__return_true', // Publicly accessible
				'args'                => array(
					'topic_slug' => array(
						'required'          => true,
						'sanitize_callback' => 'sanitize_text_field',
					),
					'count'      => array(
						'required'          => false,
						'default'           => 10,
						'sanitize_callback' => 'absint',
						'validate_callback' => function ($param) {
							return $param >= 1 && $param <= 50;
						},
					),
				),
			)
		);

		// Register dashboard endpoints for Universal Plugin Dashboard
		$this->register_dashboard_endpoints();
	}

	/**
	 * Check if user has admin permission.
	 *
	 * @since 9.0.0
	 * @return bool|WP_Error True if allowed, error otherwise.
	 */
	public function check_admin_permission()
	{
		if (! current_user_can('manage_options')) {
			return new WP_Error(
				'rest_forbidden',
				__('You do not have permission to access this endpoint.', 'wp-news-mcq-generator'),
				array('status' => 403)
			);
		}
		return true;
	}

	/**
	 * GET /sources - List topics or exams with question counts.
	 *
	 * @since 9.0.0
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 */
	public function get_sources($request)
	{
		$type     = $request->get_param('type');
		$taxonomy = ('exam' === $type) ? 'nm_exam' : 'topic';

		$terms = get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => false,
				'orderby'    => 'count',
				'order'      => 'DESC',
			)
		);

		if (is_wp_error($terms)) {
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => $terms->get_error_message(),
				),
				500
			);
		}

		$data = array();
		foreach ($terms as $term) {
			$data[] = array(
				'id'    => $term->term_id,
				'name'  => $term->name,
				'slug'  => $term->slug,
				'count' => $term->count,
			);
		}

		return new WP_REST_Response(
			array(
				'success' => true,
				'data'    => $data,
			),
			200
		);
	}

	/**
	 * GET /questions/eligible - Get unused questions for a topic/exam.
	 *
	 * @since 9.0.0
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 */
	public function get_eligible_questions($request)
	{
		$topic_id = $request->get_param('topic_id');
		$exam_id  = $request->get_param('exam_id');
		$limit    = $request->get_param('limit');

		$tracker  = NM_Question_Usage_Tracker::get_instance();
		$eligible = $tracker->get_eligible_questions($topic_id, $exam_id, $limit);

		// Get question details.
		$questions = array();
		foreach ($eligible as $qid) {
			$post = get_post($qid);
			if ($post) {
				$questions[] = array(
					'id'       => $qid,
					'question' => $post->post_title,
					'options'  => get_post_meta($qid, 'mcq_options', true),
					'correct'  => get_post_meta($qid, 'mcq_answer', true),
				);
			}
		}

		return new WP_REST_Response(
			array(
				'success' => true,
				'data'    => array(
					'count'     => count($questions),
					'questions' => $questions,
				),
			),
			200
		);
	}

	/**
	 * POST /questions/reserve - Atomically reserve questions for a job.
	 *
	 * @since 9.0.0
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 */
	public function reserve_questions($request)
	{
		$topic_id = $request->get_param('topic_id');
		$exam_id  = $request->get_param('exam_id');
		$count    = $request->get_param('count');
		$job_id   = $request->get_param('job_id');

		$tracker  = NM_Question_Usage_Tracker::get_instance();
		$reserved = $tracker->reserve_questions($topic_id, $exam_id, $count, $job_id);

		if (is_wp_error($reserved)) {
			return new WP_REST_Response(
				array(
					'success' => false,
					'message' => $reserved->get_error_message(),
					'code'    => $reserved->get_error_code(),
				),
				400
			);
		}

		// Get question details for reserved IDs.
		$questions = array();
		foreach ($reserved as $qid) {
			$post = get_post($qid);
			if ($post) {
				$options       = get_post_meta($qid, 'mcq_options', true);
				$correct_text  = get_post_meta($qid, 'mcq_answer', true);
				$correct_index = 0;

		if (is_array($options)) {
				$idx_pos = 0;
				foreach ($options as $idx => $opt) {
					if ($idx === $correct_text) {
						$correct_index = $idx_pos;
						break;
					}
					++$idx_pos;
				}
			}

				$questions[] = array(
					'id'       => $qid,
					'question' => $post->post_title,
					'options'  => $options,
					'correct'  => $correct_index,
				);
			}
		}

		return new WP_REST_Response(
			array(
				'success' => true,
				'data'    => array(
					'job_id'              => $job_id,
					'reserved_count'      => count($reserved),
					'reserved_ids'        => $reserved,
					'questions'           => $questions,
					'reservation_expires' => gmdate('c', strtotime('+24 hours')),
				),
			),
			200
		);
	}

	/**
	 * POST /questions/mark-used - Mark reserved questions as used.
	 *
	 * @since 9.0.0
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 */
	public function mark_questions_used($request)
	{
		$question_ids = array_map('absint', $request->get_param('question_ids'));
		$job_id       = $request->get_param('job_id');
		$video_url    = $request->get_param('video_url');

		$tracker = NM_Question_Usage_Tracker::get_instance();
		$updated = $tracker->mark_used($question_ids, $job_id, $video_url);

		return new WP_REST_Response(
			array(
				'success'       => true,
				'updated_count' => $updated,
			),
			200
		);
	}

	/**
	 * DELETE /questions/release - Release reserved questions.
	 *
	 * @since 9.0.0
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 */
	public function release_questions($request)
	{
		$job_id = $request->get_param('job_id');

		$tracker  = NM_Question_Usage_Tracker::get_instance();
		$released = $tracker->release_reserved($job_id);

		return new WP_REST_Response(
			array(
				'success'        => true,
				'released_count' => $released,
			),
			200
		);
	}
	/**
	 * GET /topics/search - Publicly search for topics (Substring matching)
	 *
	 * @since 8.9.7
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function search_topics($request)
	{
		$search_term = $request->get_param('term');

		if (strlen($search_term) < 2) {
			return new WP_REST_Response(array('success' => true, 'data' => array()), 200);
		}

		$terms = get_terms(array(
			'taxonomy'   => 'topic',
			'search'     => $search_term,
			'hide_empty' => false, // Show all to help guests find topics
			'number'     => 10,
		));

		$results = array();
		if (! is_wp_error($terms) && ! empty($terms)) {
			foreach ($terms as $term) {
				$display_name = $term->name;

				// ✅ NEW v8.9.8: Topic Disambiguation (Add parent context)
				if (! empty($term->parent)) {
					$parent = get_term($term->parent, 'topic');
					if (! is_wp_error($parent) && ! empty($parent)) {
						$display_name .= ' - ' . $parent->name;
					}
				}

				$results[] = array(
					'name' => $display_name,
					'slug' => $term->slug,
				);
			}
		}

		return new WP_REST_Response(array(
			'success' => true,
			'data'    => $results,
			'count'   => count($results)
		), 200);
	}

	/**
	 * POST /quiz/generate - Publicly generate a quiz from a topic slug.
	 *
	 * @MODIFIED v9.0.1 - Migrated from admin-ajax.php to bypass 403 blocks
	 *
	 * @since 9.0.1
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function generate_quiz($request)
	{
		$topic_slug = $request->get_param('topic_slug');
		$count      = $request->get_param('count');

		$args = array(
			'post_type'      => 'mcq',
			'post_status'    => 'publish', // @MODIFIED v9.0.1: Safety guard — only published MCQs
			'posts_per_page' => $count,
			'orderby'        => 'rand',
		);

		if (! empty($topic_slug)) {
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'topic',
					'field'    => 'slug',
					'terms'    => $topic_slug,
				),
			);
		}

		$mcqs_query = new WP_Query($args);
		$mcqs_data  = array();

		if ($mcqs_query->have_posts()) {
			while ($mcqs_query->have_posts()) {
				$mcqs_query->the_post();
				$mcq_id           = get_the_ID();
				$options          = get_post_meta($mcq_id, 'mcq_options', true);
				$original_correct = get_post_meta($mcq_id, 'mcq_answer', true);
				$shuffled_data    = NM_AJAX_Frontend::nm_randomize_answer_options($options, $original_correct);
				$mcqs_data[]      = array(
					'question' => get_the_title(),
					'options'  => $shuffled_data['options'],
					'answer'   => $shuffled_data['answer'],
				);
			}
			wp_reset_postdata();
		}
return new WP_REST_Response(array(
			'success' => true,
			'data'    => $mcqs_data,
		), 200);
	}

	/**
	 * Register REST API endpoints for Universal Plugin Dashboard
	 *
	 * @return void
	 */
	public function register_dashboard_endpoints()
	{
		// Only register if REST API is available
		if (!function_exists('register_rest_route')) {
			return;
		}

		// Metrics endpoint
		register_rest_route('wp/v2', '/metrics', [
			'methods'             => 'GET',
			'callback'            => [$this, 'get_metrics'],
			'permission_callback' => [$this, 'verify_dashboard_key'],
		]);

		// Status endpoint
		register_rest_route('wp/v2', '/status', [
			'methods'             => 'GET',
			'callback'            => [$this, 'get_status'],
			'permission_callback' => [$this, 'verify_dashboard_key'],
		]);
	}

	/**
	 * Verify Dashboard API Key
	 *
	 * @param WP_REST_Request $request
	 * @return bool|WP_Error
	 */
	public function verify_dashboard_key($request)
	{
		$api_key = $request->get_header('X-Dashboard-Key');
		$expected_key = get_option('nm_dashboard_api_key', '');

		if (empty($expected_key)) {
			return new \WP_Error('unconfigured', 'Dashboard API key not configured', ['status' => 503]);
		}

		if (empty($api_key) || !hash_equals($expected_key, $api_key)) {
			return new \WP_Error('unauthorized', 'Invalid API key', ['status' => 401]);
		}

		return true;
	}

	/**
	 * REST API: Get plugin metrics for Universal Dashboard
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function get_metrics($request)
	{
		global $wpdb;

		// Total MCQs generated (published + draft)
		$total_mcqs = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'mcq' AND post_status IN ('publish', 'draft')");

		// Today's MCQs (created today in site timezone)
		$today_start = gmdate('Y-m-d 00:00:00', current_time('timestamp', true));
		$today_mcqs = $wpdb->get_var($wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'mcq' AND post_status IN ('publish', 'draft') AND post_date_gmt >= %s",
			$today_start
		));

		// Buffer shares today
		$buffer_shares_today = 0;
		if (class_exists('NM_Buffer_Integration')) {
			$buffer_shares_today = (int) $wpdb->get_var($wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->postmeta} pm
				 INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				 WHERE pm.meta_key = '_nm_buffer_share_history'
				 AND p.post_date_gmt >= %s",
				$today_start
			));
		}

		// Recent errors (last 50 failed generation events)
		$errors = $wpdb->get_results($wpdb->prepare(
			"SELECT error_message, ts as timestamp FROM {$wpdb->prefix}nm_generation_events
			 WHERE severity = 'error' AND error_message != ''
			 ORDER BY ts DESC LIMIT 50"
		));

		$error_logs = [];
		foreach ((array) $errors as $error) {
			$error_logs[] = [
				'message'   => $error->error_message,
				'timestamp' => $error->timestamp,
			];
		}

		// Health score based on success rate
		$total_generated = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'mcq' AND post_status = 'publish'");
		$total_errors = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}nm_generation_events WHERE severity = 'error'");
		$health_score = $total_generated > 0 ? max(0, 100 - round(($total_errors / max(1, $total_generated)) * 100)) : 100;

		// Generation stats
		$generation_stats = [];
		if (class_exists('NM_Generation_Logger')) {
			$generation_stats = NM_Generation_Logger::get_log_stats();
		}

		// Buffer stats
		$buffer_stats = [];
		if (class_exists('NM_Buffer_Integration')) {
			$buffer_integration = new NM_Buffer_Integration();
			if (method_exists($buffer_integration, 'get_dashboard_stats')) {
				$buffer_stats = $buffer_integration->get_dashboard_stats();
			}
		}

		// Queue stats
		$queue_stats = [];
		if (class_exists('NM_Cron_Manager')) {
			$queue_stats = [
				'pending' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'mcq' AND post_status = 'draft' AND meta_key = '_nm_ready_for_publish'"),
				'scheduled' => (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'mcq' AND post_status = 'future'"),
			];
		}

		return rest_ensure_response([
			'total_mcqs_generated' => (int) $total_mcqs,
			'today_mcqs'           => (int) $today_mcqs,
			'buffer_shares_today'  => (int) $buffer_shares_today,
			'error_logs'           => $error_logs,
			'health_score'         => (int) $health_score,
			'last_updated'         => current_time('c'),
			'plugin_version'       => NM_VERSION,
			'generation_stats'     => $generation_stats,
			'buffer_stats'         => $buffer_stats,
			'queue_stats'          => $queue_stats,
		]);
	}

	/**
	 * REST API: Get plugin status for Universal Dashboard
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function get_status($request)
	{
		global $wpdb;

		// Check database connectivity
		$db_status = 'connected';
		try {
			$wpdb->get_var('SELECT 1');
		} catch (\Throwable $e) {
			$db_status = 'error';
		}

		// Check AI provider availability
		$ai_status = 'unknown';
		$ai_details = [];
		$gemini_key = get_option('nm_gemini_api_key', '');
		$ai_status = !empty($gemini_key) ? 'available' : 'unavailable';
		$ai_details = [
			'gemini_configured' => !empty($gemini_key),
			'model'             => get_option('nm_gemini_model_name', 'gemini-2.5-flash-preview-09-2025'),
		];

		// Check scheduler
		$scheduler_status = 'unknown';
		if (class_exists('NM_Cron_Manager') && get_option('nm_scheduler_enabled', 0)) {
			$scheduler_status = 'active';
		}

		// Plugin version
		$version = NM_VERSION;

		// Uptime (time since plugin activated)
		$activated_ts = get_option('nm_activation_time', time());
		$uptime = time() - $activated_ts;

		return rest_ensure_response([
			'status'           => 'active',
			'version'          => $version,
			'php_version'      => PHP_VERSION,
			'wp_version'       => get_bloginfo('version'),
			'uptime_seconds'   => $uptime,
			'database'         => $db_status,
			'ai_providers'     => $ai_status,
			'ai_details'       => $ai_details,
			'scheduler'        => $scheduler_status,
			'last_checked'     => current_time('c'),
		]);
	}

}
