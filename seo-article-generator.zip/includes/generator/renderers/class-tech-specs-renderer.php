<?php

namespace SEO_Article_Generator\Generator\Renderers;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Handles rendering of Technical Specifications table
 */
class Tech_Specs_Renderer
{
    use \SEO_Article_Generator\Traits\Markdown_Processor;

    /**
     * Technical specifications as a Gutenberg table block.
     *
     * @param array $specs Technical specs
     * @return string HTML table
     */
    public function render($specs, $post_id = 0)
    {
        return serialize_blocks($this->render_blocks($specs, $post_id));
    }

    /**
     * Technical specifications as block array.
     *
     * @param array $specs   Technical specs
     * @param int   $post_id Post ID
     * @return array Block array
     */
    public function render_blocks($specs, $post_id = 0)
    {
        if (empty($specs) || !is_array($specs)) {
            return array();
        }

        // Use current request time — get_the_modified_date() reads the OLD post_modified
        // from DB because wp_update_post() hasn't run yet at render time.
        $specs['last_updated'] = \wp_date('F j, Y');

        $labels = array(
            'software_name' => 'Software Name',
            'file_name' => 'File Name',
            'file_type' => 'File Type',
            'version' => 'Version',
            'license' => 'License',
            'developer' => 'Developer',
            'publisher' => 'Publisher',
            'homepage' => 'Homepage',
            'file_size' => 'File Size',
            'language_support' => 'Language',
            'file_hash' => 'File Hash',
            'os_support' => 'OS Support',
            'last_updated' => 'Last Updated',
        );

        $rows_html = '';

        foreach ($specs as $key => $value) {
            if ($value === '' || $value === null) {
                continue;
            }

            // Normalization for file_size: ensure only the first segment is used if multiple sizes are found
            if ($key === 'file_size' && strpos($value, ',') !== false) {
                $parts = explode(',', $value);
                $value = trim($parts[0]);
            }

            $label = isset($labels[$key])
                ? $labels[$key]
                : ucwords(str_replace('_', ' ', $key));

            if ('homepage' === $key) {
                $cell = '<a href="' . \esc_url($value) . '" target="_blank" rel="noopener">' . \esc_html($value) . '</a>';
            } else {
                $cell = \wp_kses_post(self::process_markdown($value));
            }

            $rows_html .= '<tr><th>' . \esc_html($label) . '</th><td>' . $cell . '</td></tr>';
        }

        if ($rows_html === '') {
            return array();
        }

        $html  = '<figure class="wp-block-table is-style-stripes seo-gen-specs-table"><table><tbody>';
        $html .= $rows_html;
        $html .= '</tbody></table></figure>';

        return array(
            array(
                'blockName'    => 'core/table',
                'attrs'        => array('className' => 'is-style-stripes seo-gen-specs-table'),
                'innerBlocks'  => array(),
                'innerHTML'    => $html,
                'innerContent' => array($html),
            )
        );
    }
}
