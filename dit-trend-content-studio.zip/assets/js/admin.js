/**
 * DIT TrendStudio Admin JavaScript
 *
 * @package DIT_TrendStudio
 */

(function ($) {
  "use strict";

  var DitTsAdmin = {
    currentJobId: null,
    pollInterval: null,
    activeJobsSet: null,
    activeJobsPoll: null,
    pollAttempts: 0,

    init: function () {
      this.activeJobsSet = new Set(); // @MODIFIED 2026-02-24 - Dynamic job polling set
      this.bindEvents();
      this.initJobsList();
      this.checkPrefill();
      this.initCampaigns();
      this.initSettingsTabs(); // @MODIFIED 2026-02-10 - Initialize settings tabs
      this.initSmokeTestTab(); // @MODIFIED 2026-02-25 - Diagnostics tab renderer
        this.initCustomProviders(); // @MODIFIED 2026-04-29 - Custom provider cards
        this.initGenerationFormProviders(); // @MODIFIED 2026-04-30 - Per-job provider/model dropdowns
        this.initColorPickers(); // @MODIFIED 2026-04-20 - Social collage color pickers
    },

    checkPrefill: function () {
      var strategyJson = localStorage.getItem('dit_ts_prefill_strategy');
      if (!strategyJson) return;

      try {
        var data = JSON.parse(strategyJson);

        // Auto-fill fields
        if (data.idea_title) $('#idea_title').val(data.idea_title).css('background-color', '#e6fffa');
        if (data.primary_keyword) $('#primary_keyword').val(data.primary_keyword).css('background-color', '#e6fffa');
        if (data.editorial_angle) $('#editorial_angle').val(data.editorial_angle);
        if (data.search_intent) $('#search_intent').val(data.search_intent);

        // @MODIFIED 2026-05-25 - Prioritize editorial_persona over editorial_angle
        if (data.editorial_persona) {
          var personaMap = {
            'skeptic': 'skeptical',
            'enthusiast': 'enthusiast',
            'analyst': 'educational',
            'neutral': 'neutral',
            'contrarian': 'skeptical'
          };
          var mappedPersona = personaMap[data.editorial_persona] || data.editorial_persona;
          $('#editorial_angle').val(mappedPersona).css('background-color', '#e6fffa');
        } else if (data.editorial_angle) {
          $('#editorial_angle').val(data.editorial_angle);
        }

        if (data.secondary_keywords && Array.isArray(data.secondary_keywords)) {
          $('#secondary_keywords').val(data.secondary_keywords.join(', ')).css('background-color', '#e6fffa');
        }

        if (data.search_intent) {
          $('#search_intent').val(data.search_intent).css('background-color', '#e6fffa');
        }

        // Construct rich context for the 'Content / Context' field
        var context = "";
        if (data.target_audience) context += "Target Audience: " + data.target_audience + "\n\n";
        if (data.hooks && data.hooks.length) context += "Hooks:\n- " + data.hooks.join("\n- ") + "\n\n";
        if (data.structure_blueprint) {
          context += "Structure Blueprint (" + (data.structure_blueprint.type || 'Standard') + "):\n";
          if (data.structure_blueprint.required_sections) {
            $.each(data.structure_blueprint.required_sections, function (k, v) {
              context += "- " + k + ": " + v + "\n";
            });
          }
        }

        if (context) $('#idea_text').val(context).css('background-color', '#e6fffa');

        // Clear storage
        localStorage.removeItem('dit_ts_prefill_strategy');

        // Scroll to top
        $('html, body').animate({ scrollTop: 0 }, 500);

      } catch (e) {
        console.error("Failed to parse prefill strategy", e);
      }
    },

    bindEvents: function () {
      $("#dit-ts-generate-form").on("submit", this.handleGenerate.bind(this));
      $("#dit-ts-publish-btn").on("click", this.handlePublish.bind(this));
		$("#dit-ts-test-api").on("click", this.handleTestApi.bind(this));
      $("#dit-ts-import-now").on("click", this.handleImportNow.bind(this));
      $("#dit_ts_import_schedule").on(
        "change",
        this.toggleImportTime.bind(this)
      );
      // @MODIFIED 2026-02-24 - Delegate job row actions (supports dynamic row updates without reload)
      $(document).on("click", ".dit-ts-view-job", this.handleViewJob.bind(this));
      $("#dit-ts-copy-request").on("click", this.handleCopyRequest.bind(this));
      $("#dit-ts-copy-response").on("click", this.handleCopyResponse.bind(this));
      $("#dit-ts-copy-html").on("click", this.handleCopyHtml.bind(this));
      // @MODIFIED 2026-01-14 - Unified Analysis Button
      $("#dit-ts-analyze-btn").on("click", this.handleGapAnalysis.bind(this));
      // @MODIFIED 2026-01-25 - Clear Stuck Jobs
      $("#dit-ts-clear-stuck-jobs").on("click", this.handleClearStuckJobs.bind(this));
      // @MODIFIED 2026-01-27 - Clear All Jobs
      $("#dit-ts-clear-all-jobs").on("click", this.handleClearAllJobs.bind(this));
      // @MODIFIED 2026-02-24 - Manual Trash Purge (Delete trashed sources now)
      $("#dit-ts-purge-trash-now").on("click", this.handlePurgeTrashNow.bind(this));
      // @MODIFIED 2026-02-25 - Orphan Media Purge (delete attachments whose parent posts are missing)
      $("#dit-ts-purge-orphan-media-now").on("click", this.handlePurgeOrphanMediaNow.bind(this));
      // @MODIFIED 2026-02-25 - DANGER: Empty Trash (Global)
      $("#dit-ts-empty-trash-now").on("click", this.handleEmptyTrashNow.bind(this));

      // @MODIFIED 2026-02-25 - Smoke Test (Settings > Diagnostics)
      $("#dit-ts-run-smoke-test").on("click", this.handleRunSmokeTest.bind(this));
      $("#dit-ts-copy-smoke-test").on("click", this.handleCopySmokeTestJson.bind(this));

      // @MODIFIED 2026-01-29 - Productization: Preview and Regenerate
      $(document).on("click", ".dit-ts-preview-job", this.handlePreviewJob.bind(this));
      $(document).on("click", ".dit-ts-regenerate-job", this.handleRegenerateJob.bind(this));
      $(document).on("click", ".dit-ts-cancel-job", this.handleCancelJob.bind(this));
      $(document).on("click", ".dit-ts-force-run-job", this.handleForceRunJob.bind(this));
      // @MODIFIED 2026-02-09 - Repair Queue
      $(document).on("click", "#dit-ts-repair-queue", this.handleRepairQueue.bind(this));

      // @MODIFIED 2026-02-10 - Master AI Switch and Emergency Stop
      $("#dit-ts-master-automation-toggle").on("change", this.handleToggleAutomation.bind(this));
      $("#dit-ts-master-automation-toggle-btn").on("click", this.handleToggleAutomation.bind(this));
      $("#dit-ts-emergency-stop").on("click", this.handleEmergencyStop.bind(this));
            $("#dit-ts-reset-system").on("click", this.handleResetSystem.bind(this));
            $(document).on("click", ".dit-ts-deactivate-pause", this.handleDeactivateQuotaPause.bind(this));

      // @MODIFIED 2026-02-10 - Settings Tabs Event
      $(".dit-ts-tab-wrapper .nav-tab").on("click", this.handleTabClick.bind(this));

        // @MODIFIED 2026-04-20 - Password visibility toggle for API keys
        $(".dit-ts-toggle-password").on("click", this.handleTogglePassword.bind(this));

        // @MODIFIED 2026-04-29 - Custom provider card actions
        $("#dit-ts-add-custom-provider").on("click", this.handleAddCustomProvider.bind(this));
        $(document).on("click", ".dit-ts-provider-remove", this.handleRemoveCustomProvider.bind(this));
        $(document).on("click", ".dit-ts-provider-add-model", this.handleAddProviderModel.bind(this));
        $(document).on("click", ".dit-ts-provider-remove-model", this.handleRemoveProviderModel.bind(this));
        $(document).on("click", ".dit-ts-provider-test", this.handleTestCustomProvider.bind(this));
        $(document).on("click", ".dit-ts-openrouter-sync-btn", this.handleSyncOpenRouterModels.bind(this)); // @ADDED 2026-07-12 — OpenRouter free-model sync button
        $(document).on("click", ".dit-ts-opencode-sync-btn", this.handleSyncOpenCodeModels.bind(this)); // @ADDED 2026-07-17 — OpenCode Zen free-model sync button
        $(document).on("click", ".dit-ts-provider-move-up", this.handleMoveProviderUp.bind(this));
        $(document).on("click", ".dit-ts-provider-move-down", this.handleMoveProviderDown.bind(this));
        $(document).on("change", "#dit_ts_fallback_enable_cross_provider", this.toggleCrossProviderOrder.bind(this));
        $(document).on("change", "#dit_ts_fallback_enable_universal", this.toggleCrossProviderOrder.bind(this));
        $(document).on("click", ".dit-ts-provider-toggle-visibility", this.handleToggleProviderKeyVisibility.bind(this));
        $(document).on("change", ".provider-enable-web-search", this.handleToggleWebSearchConfig.bind(this));
        $(document).on("change", ".provider-ws-type", this.handleToggleWsType.bind(this));
        $(document).on("input", ".provider-name", this.handleProviderNameChange.bind(this));
        $(document).on("input", ".provider-id", this.handleProviderIdChange.bind(this));
        $(document).on("change", "#ai_strategy", this.handleGenerationStrategyChange.bind(this));
        $(document).on("change", "#custom_provider_id", this.handleGenerationProviderChange.bind(this));
        $(document).on("change", ".campaign-strategy", this.handleCampaignStrategyChange.bind(this));
        $(document).on("change", ".campaign-custom-provider", this.handleCampaignProviderChange.bind(this));
    },

    /**
     * Handle Settings Tab Click
     */
    handleTabClick: function (e) {
      e.preventDefault();
      var $tab = $(e.currentTarget);
      var tabId = $tab.data("tab");

      // Update UI
      $(".dit-ts-tab-wrapper .nav-tab").removeClass("nav-tab-active");
      $tab.addClass("nav-tab-active");

      $(".dit-ts-tab-content").removeClass("active");
      $("#tab-" + tabId).addClass("active");

      // Update Hidden Field
      $("#dit-ts-current-tab").val(tabId);

      // Update URL without reload
      var newUrl = window.location.href.split('&tab=')[0] + '&tab=' + tabId;
      window.history.pushState({ tab: tabId }, '', newUrl);
    },

    initSettingsTabs: function () {
      // Check if we are on settings page and have tabs
      if ($(".dit-ts-tab-wrapper").length === 0) return;

      // Ensure correct tab is shown on load (in case URL and hidden field differ)
      var currentTab = $("#dit-ts-current-tab").val() || 'apis';
      $(".dit-ts-tab-wrapper .nav-tab").removeClass("nav-tab-active");
      $('.dit-ts-tab-wrapper .nav-tab[data-tab="' + currentTab + '"]').addClass("nav-tab-active");

      $(".dit-ts-tab-content").removeClass("active");
      $("#tab-" + currentTab).addClass("active");
    },

    // @MODIFIED 2026-02-25 - Smoke Test tab init (render last results if present)
    initSmokeTestTab: function () {
      if ($("#tab-diagnostics").length === 0) return;

      var lastJson = $("#dit-ts-smoke-test-last-json").val();
      if (!lastJson) return;

      try {
        var data = JSON.parse(lastJson);
        this.renderSmokeTestResults(data);
      } catch (e) {
        // ignore
      }
    },

    // @MODIFIED 2026-02-25 - Run smoke test via AJAX
    handleRunSmokeTest: function (e) {
      e.preventDefault();

      var self = this;
      var $btn = $("#dit-ts-run-smoke-test");
      var $copy = $("#dit-ts-copy-smoke-test");
      var $out = $("#dit-ts-smoke-test-results");
      var $summary = $(".dit-ts-smoke-test-summary");

      $btn.prop("disabled", true).text("Running...");
      $copy.prop("disabled", true);
      $summary.text("");
      $out.html('<div class="dit-ts-smoke-loading">Running diagnostics...</div>');

      $.post(ditTsAdmin.ajaxUrl, {
        action: "dit_ts_run_smoke_test",
        nonce: ditTsAdmin.nonce,
      })
        .done(function (resp) {
          if (resp && resp.success) {
            self.renderSmokeTestResults(resp.data);
            self._lastSmokeTestJson = JSON.stringify(resp.data, null, 2);
            $copy.prop("disabled", false);
            self.showNotice("success", "Smoke test completed.");
          } else {
            var msg = (resp && resp.data && resp.data.message) ? resp.data.message : "Smoke test failed.";
            $out.html('<div class="notice notice-error"><p>' + self.escapeHtml(msg) + '</p></div>');
            self.showNotice("error", msg);
          }
        })
        .fail(function () {
          $out.html('<div class="notice notice-error"><p>Request failed.</p></div>');
          self.showNotice("error", "Smoke test request failed.");
        })
        .always(function () {
          $btn.prop("disabled", false).text("Run Smoke Test");
        });
    },

    // @MODIFIED 2026-02-25 - Copy smoke test JSON
    handleCopySmokeTestJson: function (e) {
      e.preventDefault();
      if (!this._lastSmokeTestJson) {
        var lastJson = $("#dit-ts-smoke-test-last-json").val();
        if (lastJson) {
          this._lastSmokeTestJson = lastJson;
        }
      }
      if (!this._lastSmokeTestJson) return;

      try {
        navigator.clipboard.writeText(this._lastSmokeTestJson);
        this.showNotice("success", "Smoke test JSON copied.");
      } catch (err) {
        // fallback
        var $tmp = $("<textarea>").val(this._lastSmokeTestJson).appendTo("body").select();
        document.execCommand("copy");
        $tmp.remove();
        this.showNotice("success", "Smoke test JSON copied.");
      }
    },

    // @MODIFIED 2026-02-25 - Render smoke test results (grouped table)
    renderSmokeTestResults: function (data) {
      var $out = $("#dit-ts-smoke-test-results");
      var $summary = $(".dit-ts-smoke-test-summary");
      var $copy = $("#dit-ts-copy-smoke-test");

      if (!data || !data.groups) {
        $out.html('<div class="notice notice-error"><p>Invalid smoke test payload.</p></div>');
        return;
      }

      var status = data.status || "warn";
      var s = data.summary || { pass: 0, warn: 0, fail: 0 };
      var runAt = data.run_at_gmt ? data.run_at_gmt : "";

      $summary.html(
        '<span class="dit-ts-pill ' + this.escapeHtml(status) + '">' + this.escapeHtml(status.toUpperCase()) + '</span>' +
        '<span class="dit-ts-smoke-counts">Pass: ' + (s.pass || 0) + ' | Warn: ' + (s.warn || 0) + ' | Fail: ' + (s.fail || 0) + (runAt ? (' | Run: ' + this.escapeHtml(runAt)) : '') + '</span>'
      );

      var html = '';
      html += '<table class="widefat striped dit-ts-smoke-table">';
      html += '<thead><tr><th>Check</th><th>Status</th><th>Details</th></tr></thead><tbody>';

      for (var i = 0; i < data.groups.length; i++) {
        var g = data.groups[i];
        html += '<tr class="dit-ts-smoke-group"><td colspan="3">' + this.escapeHtml(g.label || g.id || ("Group " + i)) + '</td></tr>';
        var checks = g.checks || [];
        for (var j = 0; j < checks.length; j++) {
          var c = checks[j];
          var st = (c.status || 'warn');
          html += '<tr>';
          html += '<td class="dit-ts-smoke-label">' + this.escapeHtml(c.label || c.id || '') + '</td>';
          html += '<td class="dit-ts-smoke-status"><span class="dit-ts-pill ' + this.escapeHtml(st) + '">' + this.escapeHtml(st.toUpperCase()) + '</span></td>';
          html += '<td class="dit-ts-smoke-details">' + this.escapeHtml(c.details || '') + '</td>';
          html += '</tr>';
        }
      }

      html += '</tbody></table>';
      $out.html(html);

      // enable copy if possible
      try {
        this._lastSmokeTestJson = JSON.stringify(data, null, 2);
        $copy.prop("disabled", false);
      } catch (e) {
        $copy.prop("disabled", true);
      }
    },

    /**
     * Handle Gap Analysis (Same Page)
     */
    handleGapAnalysis: function (e) {
      e.preventDefault();
      var $btn = $("#dit-ts-analyze-btn");
      var source = $("#dit_ts_gap_source").val();
      var mode = $("input[name='dit_ts_analysis_mode']:checked").val();

      if (!source) {
        alert("Please enter a URL or text content to analyze.");
        return;
      }

      $btn.prop("disabled", true).text("Analyzing Strategy...");

      $.post(ditTsAdmin.ajaxUrl, {
        action: 'dit_ts_analyze_gap',
        nonce: ditTsAdmin.nonce,
        source_url: source,
        mode: mode
      }).done(function (response) {
        if (response.success) {
          var data = response.data;
          // Auto-Populate Fields

          // 1. Topic
          if (data.topic) $("#idea_title").val(data.topic).css('background-color', '#e3f2fd'); // Highlight change

          // 2. Context / Notes
          var context = "";
          if (data.unique_angle) context += "Unique Angle: " + data.unique_angle + "\n\n";
          if (data.notes) context += data.notes;

          if (context) $("#idea_text").val(context).css('background-color', '#e3f2fd');

          // 3. Keywords
          if (data.focus_keyword) $("#primary_keyword").val(data.focus_keyword).css('background-color', '#e3f2fd');

          // 4. Source URL (Pass-through if it was a URL)
          if (source.startsWith('http')) {
            $("#source_urls").val(source);
          }

          // 5. Config Mappings (Best Effort)
          if (data.editorial_angle) {
            // Try to match value, else keep default
            var angle = data.editorial_angle === 'enthusiastic' ? 'enthusiast' : data.editorial_angle;
            $("#editorial_angle").val(angle);
          }

          if (data.search_intent) {
            $("#search_intent").val(data.search_intent);
          }

          // UI Feedback
          $btn.text("Strategy Applied!").removeClass('button-secondary').addClass('button-primary');
          setTimeout(function () { $btn.text("Analyze Strategy").removeClass('button-primary').addClass('button-secondary').prop("disabled", false); }, 3000);

          // Scroll down to form
          $('html, body').animate({
            scrollTop: $("#dit-ts-generate-form").offset().top - 50
          }, 500);

        } else {
          alert("Analysis Error: " + response.data);
          $btn.text("Analyze Strategy").prop("disabled", false);
        }
      }).fail(function () {
        alert("Analysis Request Failed (Server Error)");
        $btn.text("Analyze Strategy").prop("disabled", false);
      });
    },

    toggleImportTime: function () {
      var $timeWrapper = $("#dit-ts-import-time-wrapper");
      if ($("#dit_ts_import_schedule").val() === "daily") {
        $timeWrapper.show();
      } else {
        $timeWrapper.hide();
      }
    },

    /**
     * Handle password visibility toggle for API key fields
     * @MODIFIED 2026-04-20 - Add eye toggle for API key visibility
     */
    handleTogglePassword: function (e) {
      e.preventDefault();
      var $btn = $(e.currentTarget);
      var targetId = $btn.data("target");
      var $input = $("#" + targetId);

      if ($input.length === 0) return;

      if ($input.attr("type") === "password") {
        $input.attr("type", "text");
        $btn.find(".dashicons").removeClass("dashicons-visibility").addClass("dashicons-hidden");
        $btn.attr("aria-label", DitTsAdmin.strings.hideApiKey || "Hide API key");
      } else {
        $input.attr("type", "password");
        $btn.find(".dashicons").removeClass("dashicons-hidden").addClass("dashicons-visibility");
        $btn.attr("aria-label", DitTsAdmin.strings.showApiKey || "Show API key");
      }
    },

    handleViewJob: function (e) {
      e.preventDefault();
      var $btn = $(e.target);
      this.currentJobId = $btn.data("id");
      this.showStatus(ditTsAdmin.strings.generating);
      this.startPolling();
    },

    handleCopyRequest: function () {
      if (!this.currentPreviewData) return;
      var text = "";
      // Prefer raw_request, fallback to formatted input_data
      if (this.currentPreviewData.raw_request) {
        text = this.currentPreviewData.raw_request;
      } else if (this.currentPreviewData.input_data) {
        text = JSON.stringify(this.currentPreviewData.input_data, null, 2);
      }
      this.copyToClipboard(text);
      alert("Request copied to clipboard!");
    },

    handleCopyResponse: function () {
      if (!this.currentPreviewData) return;
      var text = this.currentPreviewData.raw_response || "No raw response data available.";
      this.copyToClipboard(text);
      alert("Response copied to clipboard!");
    },

    handleCopyHtml: function () {
      if (!this.currentPreviewData) return;
      var text = this.currentPreviewData.block_markup || "";
      this.copyToClipboard(text);
      alert("Block HTML copied to clipboard!");
    },

    copyToClipboard: function (text) {
      var $temp = $("<textarea>");
      $("body").append($temp);
      $temp.val(text).select();
      document.execCommand("copy");
      $temp.remove();
    },

    handleGenerate: function (e) {
      e.preventDefault();

      var $form = $(e.target);
      var $btn = $("#dit-ts-generate-btn");
      var $spinner = $form.find(".spinner");

      // Disable form
      $btn.prop("disabled", true);
      $spinner.addClass("is-active");

      // Get form data
      var formData = {
        action: "dit_ts_submit",
        nonce: ditTsAdmin.nonce,
      };

      // Collect form fields
      $form.find("input, select, textarea").each(function () {
        var $input = $(this);
        var name = $input.attr("name");
        if (name) {
          if ($input.attr("type") === "checkbox") {
            formData[name] = $input.is(":checked") ? $input.val() : "";
          } else if ($input.attr("type") === "radio") {
            if ($input.is(":checked")) formData[name] = $input.val();
          } else {
            formData[name] = $input.val();
          }
        }
      });

      // Submit - Step 1: Create Job (Pending)
      $.post(ditTsAdmin.ajaxUrl, formData)
        .done(function (response) {
          if (response.success) {
            DitTsAdmin.currentJobId = response.data.job_id;
            DitTsAdmin.showStatus("Initializing generation...");

            // Step 2: Force Run immediately (bypass queue wait)
            DitTsAdmin.forceRunJob(DitTsAdmin.currentJobId);

          } else {
            DitTsAdmin.showError(
              response.data.message || ditTsAdmin.strings.error
            );
            $btn.prop("disabled", false);
            $spinner.removeClass("is-active");
          }
        })
        .fail(function () {
          DitTsAdmin.showError(ditTsAdmin.strings.error);
          $btn.prop("disabled", false);
          $spinner.removeClass("is-active");
        });
    },

    forceRunJob: function (jobId) {
      DitTsAdmin.showStatus("Generating content (this may take 1-2 minutes)...");

      $.post(ditTsAdmin.ajaxUrl, {
        action: 'dit_ts_force_run_job',
        nonce: ditTsAdmin.nonce,
        job_id: jobId
      }).done(function (response) {
        if (response.success) {
          // Job done, verify status and load preview
          DitTsAdmin.checkStatus();
        } else {
          DitTsAdmin.showError("Generation Error: " + response.data);
          $("#dit-ts-generate-btn").prop("disabled", false);
          $(".spinner").removeClass("is-active");
        }
      }).fail(function () {
        // If force run times out or fails (e.g. gateway timeout), fall back to polling
        // because the job might still be running in background
        DitTsAdmin.showStatus("Taking longer than expected... switching to poll mode.");
        DitTsAdmin.startPolling();
      });
    },

    startPolling: function () {
      this.pollInterval = setInterval(function () {
        DitTsAdmin.checkStatus();
      }, 2000);
    },

    stopPolling: function () {
      if (this.pollInterval) {
        clearInterval(this.pollInterval);
        this.pollInterval = null;
      }
    },

    checkStatus: function () {
      $.post(ditTsAdmin.ajaxUrl, {
        action: "dit_ts_status",
        nonce: ditTsAdmin.nonce,
        job_id: this.currentJobId,
      }).done(function (response) {
        if (response.success) {
          var status = response.data.status;
          DitTsAdmin.updateProgress(status);

          if (status === "completed") {
            DitTsAdmin.stopPolling();

            // @FIX 2026-01-14 - Reset UI on completion
            $("#dit-ts-generate-btn").prop("disabled", false);
            $("#dit-ts-generate-form .spinner").removeClass("is-active");

            DitTsAdmin.loadPreview();
          } else if (status === "failed") {
            DitTsAdmin.stopPolling();

            // @FIX 2026-01-14 - Reset UI on failure
            $("#dit-ts-generate-btn").prop("disabled", false);
            $("#dit-ts-generate-form .spinner").removeClass("is-active");

            DitTsAdmin.showError(response.data.error || "Generation failed");
          }
        }
      });
    },

    showStatus: function (message) {
      var $status = $("#dit-ts-status");
      $status.show().find(".status-message").text(message);
      $("#dit-ts-preview").hide();
    },

    updateProgress: function (status) {
      var progress = status === "processing" ? 50 : 10;
      $("#dit-ts-status .progress").css("width", progress + "%");
    },

    loadPreview: function () {
      $.post(ditTsAdmin.ajaxUrl, {
        action: "dit_ts_preview",
        nonce: ditTsAdmin.nonce,
        job_id: this.currentJobId,
      }).done(function (response) {
        if (response.success) {
          DitTsAdmin.showPreview(response.data);
        } else {
          DitTsAdmin.showError(
            response.data.message || "Failed to load preview"
          );
        }
      });
    },

    showPreview: function (data) {
      var $preview = $("#dit-ts-preview");
      var $status = $("#dit-ts-status");
      this.currentPreviewData = data;

      $status.hide();
      $preview.show();

      // Set title
      $preview
        .find(".preview-title")
        .html("<h1>" + DitTsAdmin.escapeHtml(data.title) + "</h1>");

      // Set content
      $preview.find(".preview-html").html(data.html);

      // Set validation
      var $validation = $preview.find(".validation-results");
      $validation.empty();

      if (data.validation) {
        var statusClass = data.validation.passed
          ? "validation-passed"
          : "validation-failed";
        var statusText = data.validation.passed ? "✓ Passed" : "✗ Failed";
        $validation.append(
          '<p class="' + statusClass + '">' + statusText + "</p>"
        );

        if (data.validation.errors && data.validation.errors.length) {
          $validation.append('<ul class="errors"></ul>');
          data.validation.errors.forEach(function (err) {
            $validation
              .find(".errors")
              .append(
                '<li class="error">✗ ' + DitTsAdmin.escapeHtml(err) + "</li>"
              );
          });
        }

        if (data.validation.warnings && data.validation.warnings.length) {
          $validation.append('<ul class="warnings"></ul>');
          data.validation.warnings.forEach(function (warn) {
            $validation
              .find(".warnings")
              .append(
                '<li class="warning">⚠ ' + DitTsAdmin.escapeHtml(warn) + "</li>"
              );
          });
        }
      }
    },

    handlePublish: function () {
      var $btn = $("#dit-ts-publish-btn");
      $btn.prop("disabled", true).text("Saving...");

      // @MODIFIED 2025-12-27 - Only send job_id + title; server fetches canonical block_markup
      var title = $("#dit-ts-preview .preview-title h1").text();

      $.post(ditTsAdmin.ajaxUrl, {
        action: "dit_ts_publish",
        nonce: ditTsAdmin.nonce,
        job_id: this.currentJobId,
        title: title,
      })
        .done(function (response) {
          if (response.success) {
            window.location.href = response.data.edit_url;
          } else {
            DitTsAdmin.showError(response.data.message || "Failed to save");
            $btn.prop("disabled", false).text("Save as Draft");
          }
        })
        .fail(function () {
          DitTsAdmin.showError("Request failed");
          $btn.prop("disabled", false).text("Save as Draft");
        });
    },

    handleTestApi: function () {
      this.testConnection(
        "gemini",
        "#dit-ts-test-api",
        ".api-test-result",
        "#dit_ts_gemini_api_key"
      );
    },

    testConnection: function (provider, btnSelector, resultSelector, inputSelector) {
      var $btn = $(btnSelector);
      var $result = $(resultSelector);
      var apiKey = $(inputSelector).val();

      $btn.prop("disabled", true);
      $result.text("Testing...").removeClass("success error");

      $.post(ditTsAdmin.ajaxUrl, {
        action: "dit_ts_test_api",
        nonce: ditTsAdmin.nonce,
        api_key: apiKey,
        provider: provider
      })
        .done(function (response) {
          if (response.success) {
            $result.text("✓ Connected").addClass("success");
          } else {
            $result.text("✗ " + response.data.message).addClass("error");
          }
        })
        .fail(function () {
          $result.text("✗ Request failed").addClass("error");
        })
        .always(function () {
          $btn.prop("disabled", false);
        });
    },

    handleImportNow: function () {
      var $btn = $("#dit-ts-import-now");
      var $result = $(".import-result");

      $btn.prop("disabled", true);
      $result.text("Importing...").removeClass("success error");

      $.post(ditTsAdmin.ajaxUrl, {
        action: "dit_ts_import_ideas",
        nonce: ditTsAdmin.nonce,
      })
        .done(function (response) {
          if (response.success) {
            $result.text("✓ " + response.data.message).addClass("success");
          } else {
            $result.text("✗ " + response.data.message).addClass("error");
          }
        })
        .fail(function () {
          $result.text("✗ Request failed").addClass("error");
        })
        .always(function () {
          $btn.prop("disabled", false);
        });
    },

    // @MODIFIED 2026-01-25 - Clear Stuck Jobs handler
    handleClearStuckJobs: function () {
      var $btn = $("#dit-ts-clear-stuck-jobs");
      var $result = $(".clear-jobs-result");

      $btn.prop("disabled", true);
      $result.text("Clearing...").removeClass("success error");

      $.post(ditTsAdmin.ajaxUrl, {
        action: "dit_ts_clear_stuck_jobs",
        nonce: ditTsAdmin.nonce,
      })
        .done(function (response) {
          if (response.success) {
            $result.text("✓ " + response.data.message).addClass("success");
          } else {
            $result.text("✗ " + response.data.message).addClass("error");
          }
        })
        .fail(function () {
          $result.text("✗ Request failed").addClass("error");
        })
        .always(function () {
          $btn.prop("disabled", false);
        });
    },

    // @MODIFIED 2026-01-27 - Clear All Jobs handler
    handleClearAllJobs: function () {
      if (!confirm("Are you sure? This will permanently delete ALL active, completed, and failed jobs. This cannot be undone.")) {
        return;
      }

      var $btn = $("#dit-ts-clear-all-jobs");
      var $result = $(".clear-jobs-result");

      $btn.prop("disabled", true);
      $result.text("Nuking...").removeClass("success error");

      $.post(ditTsAdmin.ajaxUrl, {
        action: "dit_ts_clear_all_jobs",
        nonce: ditTsAdmin.nonce,
      })
        .done(function (response) {
          if (response.success) {
            $result.text("✓ " + response.data.message).addClass("success");
            // Refresh page after 1.5s to show empty state
            setTimeout(function () { location.reload(); }, 1500);
          } else {
            $result.text("✗ " + response.data.message).addClass("error");
          }
        })
        .fail(function () {
          $result.text("✗ Request failed").addClass("error");
        })
        .always(function () {
          $btn.prop("disabled", false);
        });
    },


    // @MODIFIED 2026-02-24 - Manual Trash Purge handler (permanently delete trashed sources)
    handlePurgeTrashNow: function () {
      if (!confirm('This will permanently delete plugin-marked source drafts currently in Trash. This cannot be undone. Continue?')) {
        return;
      }

      var $btn = $("#dit-ts-purge-trash-now");
      var $result = $(".trash-purge-result");

      $btn.prop("disabled", true);
      $result.text("Purging...").removeClass("success error");

      $.post(ditTsAdmin.ajaxUrl, {
        action: "dit_ts_purge_trash_now",
        nonce: ditTsAdmin.nonce,
      })
        .done(function (response) {
          if (response.success) {
            $result.text("✓ " + response.data.message).addClass("success");
          } else {
            $result.text("✗ " + (response.data && response.data.message ? response.data.message : "Failed")).addClass("error");
          }
        })
        .fail(function () {
          $result.text("✗ Request failed").addClass("error");
        })
        .always(function () {
          $btn.prop("disabled", false);
        });
    },

    // @MODIFIED 2026-02-25 - Manual Orphan Media Purge handler
    handlePurgeOrphanMediaNow: function () {
      if (!confirm('This will permanently delete orphan attachments whose parent posts no longer exist (only if they are not referenced elsewhere). Attachments in use will be DETACHED instead. Continue?')) {
        return;
      }

      var $btn = $("#dit-ts-purge-orphan-media-now");
      var $result = $(".orphan-media-purge-result");

      $btn.prop("disabled", true);
      $result.text("Purging orphan media...").removeClass("success error");

      $.post(ditTsAdmin.ajaxUrl, {
        action: "dit_ts_purge_orphan_media_now",
        nonce: ditTsAdmin.nonce,
      })
        .done(function (response) {
          if (response.success) {
            $result.text("✓ " + response.data.message).addClass("success");
          } else {
            $result.text("✗ " + (response.data && response.data.message ? response.data.message : "Failed")).addClass("error");
          }
        })
        .fail(function () {
          $result.text("✗ Request failed").addClass("error");
        })
        .always(function () {
          $btn.prop("disabled", false);
        });
    },


    // @MODIFIED 2026-02-25 - DANGER: Empty Trash (Global) batch loop
    handleEmptyTrashNow: function () {
      var confirmText = prompt("This will permanently delete ALL Trash items. Type DELETE to proceed:");
      if (confirmText !== "DELETE") {
        alert("Cancelled.");
        return;
      }

      var $btn = $("#dit-ts-empty-trash-now");
      var $result = $(".empty-trash-result");

      var includeMedia = $("#dit-ts-empty-trash-include-media").is(":checked") ? 1 : 0;
      var forceMedia = $("#dit-ts-empty-trash-force-media").is(":checked") ? 1 : 0;
      var batchSize = parseInt($("#dit-ts-empty-trash-batch-size").val(), 10) || 25;

      $btn.prop("disabled", true);
      $result.text("Running...").removeClass("success error");

      var deletedPosts = 0;
      var deletedMedia = 0;
      var detachedMedia = 0;

      var runBatch = function () {
        $.post(ditTsAdmin.ajaxUrl, {
          action: "dit_ts_empty_trash_now",
          nonce: ditTsAdmin.nonce,
          confirm: "DELETE",
          include_media: includeMedia,
          force_media: forceMedia,
          batch_size: batchSize
        })
          .done(function (response) {
            if (!response.success) {
              $result.text("✗ " + (response.data && response.data.message ? response.data.message : "Failed"))
                .addClass("error");
              $btn.prop("disabled", false);
              return;
            }

            deletedPosts += parseInt(response.data.deleted_posts || 0, 10);
            deletedMedia += parseInt(response.data.deleted_media || 0, 10);
            detachedMedia += parseInt(response.data.detached_media || 0, 10);

            $result
              .text("Deleted posts: " + deletedPosts + ", deleted media: " + deletedMedia + ", detached media: " + detachedMedia + ", remaining trash: " + (response.data.remaining || 0))
              .addClass("success");

            if (response.data.done) {
              $btn.prop("disabled", false);
              return;
            }

            runBatch();
          })
          .fail(function () {
            $result.text("✗ Request failed").addClass("error");
            $btn.prop("disabled", false);
          });
      };

      runBatch();
    },


    handleViewJob: function (e) {
      var jobId = $(e.target).data("job-id");
      // For now, redirect to main page and load preview
      // Could be improved with a modal
      window.location.href = ditTsAdmin.ajaxUrl.replace(
        "admin-ajax.php",
        "admin.php?page=dit-trend-studio&job=" + jobId
      );
    },

    showError: function (message) {
      var $status = $("#dit-ts-status");
      $status
        .show()
        .css("border-color", "#d63638")
        .find(".status-message")
        .text("Error: " + message);
      $status.find(".progress").css("width", "0");
    },

    /**
     * Show a WP admin notice without reloading.
     * @MODIFIED 2026-02-24 - Regenerate UX
     */
    showNotice: function (type, message) {
      var $wrap = $(".wrap.dit-ts-admin");
      if ($wrap.length === 0) return;

      var $area = $wrap.find(".dit-ts-notice-area");
      if ($area.length === 0) {
        $wrap.find("h1").first().after('<div class="dit-ts-notice-area"></div>');
        $area = $wrap.find(".dit-ts-notice-area");
      }

      var safeMessage = String(message || "");
      var cls = (type === "error") ? "notice-error" : "notice-success";
      var $notice = $('<div class="notice ' + cls + ' is-dismissible"><p></p></div>');
      $notice.find("p").text(safeMessage);
      $area.empty().append($notice);
    },

    setRowUpdating: function ($row, isUpdating) {
      if (!$row || $row.length === 0) return;
      $row.toggleClass("dit-ts-row-updating", !!isUpdating);
    },

    isActiveStatus: function (status) {
      return ['pending', 'queued', 'briefing', 'processing', 'researching', 'outlining', 'drafting', 'reviewing'].includes(status);
    },

    normalizeStatusLabel: function (status) {
      if (!status) return "Unknown";
      return status.charAt(0).toUpperCase() + status.slice(1);
    },

    /**
     * Apply server status payload to a job row (no reload).
     * @MODIFIED 2026-02-24 - Professional regenerate flow
     */
    applyJobUpdateToRow: function (jobId, data) {
      var $row = $("#job-row-" + jobId);
      if ($row.length === 0) return;

      var status = (data && data.status) ? String(data.status) : "pending";
      var message = (data && data.message) ? String(data.message) : "";
      var completedAt = (data && data.completed_at) ? String(data.completed_at) : "";
      var errorMsg = (data && data.error) ? String(data.error) : "";

      // Row class
      $row.removeClass(function (i, cls) {
        return (cls.match(/(^|\s)job-row-status-\S+/g) || []).join(' ');
      });
      $row.addClass("job-row-status-" + status);

      // Status badge + message
      var $statusCell = $row.find(".status-cell");
      var $badge = $statusCell.find(".job-status");
      $badge.attr("class", "job-status job-status-" + status).text(this.normalizeStatusLabel(status));

      var $msg = $statusCell.find(".job-status-message");
      if ($msg.length === 0) {
        $statusCell.append('<div class="job-status-meta"><span class="job-status-message" aria-live="polite"></span></div>');
        $msg = $statusCell.find(".job-status-message");
      }
      $msg.text(message);

      // Spinner
      if (this.isActiveStatus(status)) {
        if ($statusCell.find(".spinner").length === 0) {
          $statusCell.append(' <span class="spinner is-active"></span>');
        }
      } else {
        $statusCell.find(".spinner").remove();
        $statusCell.find(".dit-ts-force-run-job").remove();
      }

      // Completed cell (5th column)
      $row.find("td:nth-child(5)").text(completedAt ? completedAt : "—");

      // Actions cell: rebuild deterministically
      var $actions = $row.find("td:last-child");
      $actions.empty();

      var previewDisabled = status !== "completed";
      var regenLabel = (status === "completed") ? "Regenerate" : "Run";

      var $previewBtn = $('<button type="button" class="button button-small dit-ts-preview-job">Preview</button>');
      $previewBtn.attr("data-job-id", jobId);
      if (previewDisabled) $previewBtn.prop("disabled", true);

      var $regenBtn = $('<button type="button" class="button button-small dit-ts-regenerate-job"></button>');
      $regenBtn.attr("data-job-id", jobId).text(regenLabel);

      // Prevent accidental duplicate queueing while active
      if (this.isActiveStatus(status)) {
        $regenBtn.prop("disabled", true).text("Queued");
      }

      $actions.append($previewBtn).append(" ").append($regenBtn);

      if (this.isActiveStatus(status)) {
        var $cancelBtn = $('<button type="button" class="button button-small dit-ts-cancel-job" style="color:#d63638;border-color:#d63638;margin-left:4px;">Cancel</button>');
        $cancelBtn.attr("data-job-id", jobId);
        $actions.append(" ").append($cancelBtn);

        // "Stuck?" link after ~15s (5 polls)
        if (this.pollAttempts > 5 && $statusCell.find(".dit-ts-force-run-job").length === 0) {
          $statusCell.append('<br><a href="#" class="dit-ts-force-run-job" data-job-id="' + jobId + '" style="font-size:10px;color:#d63638;">(Stuck? Run Manually)</a>');
        }
      }

      if (status === "failed" && errorMsg) {
        var $details = $('<details class="error-details"><summary class="error-message">Error ▾</summary><pre class="error-full"></pre></details>');
        $details.find(".error-full").text(errorMsg);
        $actions.append($details);
      }
    },

    addJobToPolling: function (jobId) {
      if (!jobId) return;
      this.activeJobsSet.add(String(jobId));
      this.startJobsPolling();
      // Immediate refresh
      this.pollActiveJobs();
    },

    startJobsPolling: function () {
      var self = this;
      if (this.activeJobsPoll) return;

      this.activeJobsPoll = setInterval(function () {
        self.pollActiveJobs();
      }, 3000);
    },

    initJobsList: function () {
      var self = this;

      $(".job-row-status-pending, .job-row-status-queued, .job-row-status-briefing, .job-row-status-processing, .job-row-status-researching, .job-row-status-outlining, .job-row-status-drafting, .job-row-status-reviewing")
        .each(function () {
          var id = $(this).data("job-id");
          if (id) self.activeJobsSet.add(String(id));
        });

      if (this.activeJobsSet.size > 0) {
        this.startJobsPolling();
      }
    },

    pollActiveJobs: function () {
      var self = this;
      var ids = Array.from(this.activeJobsSet);

      if (!ids || ids.length === 0) {
        if (this.activeJobsPoll) {
          clearInterval(this.activeJobsPoll);
          this.activeJobsPoll = null;
        }
        return;
      }

      // Track polling attempts (stuck indicator)
      this.pollAttempts = (this.pollAttempts || 0) + 1;

      $.post(ditTsAdmin.ajaxUrl, {
        action: 'dit_ts_batch_status',
        nonce: ditTsAdmin.nonce,
        job_ids: ids
      }).done(function (response) {
        if (!response || !response.success) return;

        var updates = response.data || {};
        $.each(updates, function (id, data) {
          self.applyJobUpdateToRow(id, data);

          var status = (data && data.status) ? String(data.status) : "";
          if (status && !self.isActiveStatus(status)) {
            self.activeJobsSet.delete(String(id));
          }
        });
      });
    },

    /**
     * Preview a generated article in a new window. in a new window.
     */
    handlePreviewJob: function (e) {
      e.preventDefault();
      var $btn = $(e.currentTarget);
      var jobId = $btn.data("job-id");
      $btn.prop("disabled", true).text("Previewing...");
      $.post(ditTsAdmin.ajaxUrl, {
        action: "dit_ts_preview",
        nonce: ditTsAdmin.nonce,
        job_id: jobId
      }).done(function (resp) {
        if (resp.success) {
          var preview = resp.data;
          // @MODIFIED 2026-02-24 - Prefer rendered HTML preview; fall back to escaped block markup.
          var html = preview.html ? preview.html : (preview.block_markup ? "<pre>" + preview.block_markup.replace(/</g, "&lt;") + "</pre>" : "<pre>" + JSON.stringify(preview, null, 2) + "</pre>");
          var w = window.open("", "_blank");
          w.document.write(html);
          w.document.close();
        } else {
          alert("Preview error: " + (resp.data && resp.data.message ? resp.data.message : "Unknown error"));
        }
        $btn.prop("disabled", false).text("Preview");
      }).fail(function () {
        alert("Preview request failed.");
        $btn.prop("disabled", false).text("Preview");
      });
    },

    /**
     * Regenerate a job (reset and run).
     */
    handleRegenerateJob: function (e) {
      e.preventDefault();

      var self = this;
      var $btn = $(e.currentTarget);
      var jobId = $btn.data("job-id");
      var $row = $("#job-row-" + jobId);

      if (!jobId) return;

      self.setRowUpdating($row, true);

      // Immediate UI feedback (no reload)
      $btn.prop("disabled", true).text("Resetting...");
      if ($row.length) {
        $row.find(".job-status-message").text("Resetting job...");
      }

      $.post(ditTsAdmin.ajaxUrl, {
        action: "dit_ts_force_run_job",
        nonce: ditTsAdmin.nonce,
        job_id: jobId,
        reset: "1"
      }).done(function (resp) {
        if (resp && resp.success) {
          var msg = (resp.data && resp.data.message) ? resp.data.message : "Job reset and queued.";
          self.showNotice("success", msg);

          var job = (resp.data && resp.data.job) ? resp.data.job : { status: "pending", message: "Queued (waiting for worker)..." };
          self.applyJobUpdateToRow(jobId, job);
          self.addJobToPolling(jobId);
        } else {
          var err = (resp && resp.data && resp.data.message) ? resp.data.message : "Regenerate failed.";
          self.showNotice("error", err);
          self.applyJobUpdateToRow(jobId, { status: "failed", message: "Failed", error: err });
        }
      }).fail(function () {
        self.showNotice("error", "Regenerate request failed.");
      }).always(function () {
        self.setRowUpdating($row, false);
      });
    },

    /**
     * Cancel a stuck job.
     */
    handleCancelJob: function (e) {
      e.preventDefault();

      var self = this;
      if (!confirm("Cancel this job? It will be marked as failed.")) return;

      var $btn = $(e.currentTarget);
      var jobId = $btn.data("job-id");
      var $row = $("#job-row-" + jobId);

      if (!jobId) return;

      self.setRowUpdating($row, true);
      $btn.prop("disabled", true).text("Cancelling...");

      $.post(ditTsAdmin.ajaxUrl, {
        action: "dit_ts_cancel_job",
        nonce: ditTsAdmin.nonce,
        job_id: jobId
      }).done(function (resp) {
        if (resp && resp.success) {
          var msg = (resp.data && resp.data.message) ? resp.data.message : "Job cancelled.";
          self.showNotice("success", msg);

          var job = (resp.data && resp.data.job) ? resp.data.job : { status: "failed", message: "Failed" };
          self.applyJobUpdateToRow(jobId, job);
          self.activeJobsSet.delete(String(jobId));
        } else {
          var err = (resp && resp.data && resp.data.message) ? resp.data.message : "Cancel failed.";
          self.showNotice("error", err);
        }
      }).fail(function () {
        self.showNotice("error", "Cancel request failed.");
      }).always(function () {
        self.setRowUpdating($row, false);
      });
    },

    /**
     * Manually run a stuck job now (synchronous).
     * @MODIFIED 2026-02-24 - Fix stuck link wiring (jobs, not campaigns)
     */
    handleForceRunJob: function (e) {
      e.preventDefault();

      var self = this;
      var $link = $(e.currentTarget);
      var jobId = $link.data("job-id");
      var $row = $("#job-row-" + jobId);

      if (!jobId) return;
      if (!confirm("Run job #" + jobId + " now? This may take a few minutes and will keep this tab busy.")) return;

      self.setRowUpdating($row, true);
      $link.text("Running...").css("pointer-events", "none");

      $.post(ditTsAdmin.ajaxUrl, {
        action: "dit_ts_force_run_job",
        nonce: ditTsAdmin.nonce,
        job_id: jobId
      }).done(function (resp) {
        if (resp && resp.success) {
          self.showNotice("success", (resp.data && resp.data.message) ? resp.data.message : "Job started.");
          self.addJobToPolling(jobId);
        } else {
          var err = (resp && resp.data && resp.data.message) ? resp.data.message : "Manual run failed.";
          self.showNotice("error", err);
        }
      }).fail(function () {
        self.showNotice("error", "Manual run request failed.");
      }).always(function () {
        self.setRowUpdating($row, false);
      });
    },

    /**
     * Handle Manual Run for Stuck Jobs
     */
    handleForceRun: function (e) {
      e.preventDefault();
      var $btn = $(this);
      var $card = $btn.closest('.dit-ts-campaign-card');
      var campaignId = $card.data('id');
      var campaignName = $card.find('.campaign-name').val() || 'Campaign';

      if ($btn.hasClass('disabled')) return;

      if (!confirm('Run "' + campaignName + '" immediately? This will process 1 post.')) return;

      $btn.addClass('disabled').text('Running...');

      $.post(ajaxurl, {
        action: 'dit_ts_force_run_campaign',
        nonce: ditTsAdmin.nonce,
        campaign_id: campaignId
      }, function (res) {
        if (res.success) {
          $btn.text('Done!').removeClass('button-primary').addClass('button-disabled');
          setTimeout(function () {
            // Reset after 3s
            $btn.html('<span class="dashicons dashicons-controls-play"></span> Run').removeClass('disabled button-disabled').addClass('button-primary');
          }, 3000);
          alert('Success: ' + campaignName + ' triggered.');
        } else {
          var errorMsg = (res.data && res.data.message) ? res.data.message : (typeof res.data === 'string' ? res.data : JSON.stringify(res.data));
          alert('Error: ' + (errorMsg || 'Unknown error'));
          $btn.text('Retry').removeClass('disabled');
        }
      }).fail(function () {
        alert('Request Failed');
        $btn.text('Retry').removeClass('disabled');
      });
    },

    initCampaigns: function () {
      var $list = $('#dit-ts-campaigns-list');
      var $hiddenInput = $('#dit_ts_campaigns');
      var $addBtn = $('#dit-ts-add-campaign');
      var $form = $hiddenInput.closest('form');
      var self = this;

      // 1. Render existing
      try {
        var campaigns = JSON.parse($hiddenInput.val() || '[]');
        if (!Array.isArray(campaigns)) campaigns = [];

        campaigns.forEach(function (c) {
          DitTsAdmin.renderCampaignRow(c);
        });

        // Fetch stats if campaigns exist
        if (campaigns.length > 0) {
          self.fetchCampaignStats();
        }

      } catch (e) { console.error('Invalid campaign JSON', e); }

      // 2. Bind Add
      $addBtn.on('click', function () {
        DitTsAdmin.renderCampaignRow({
          id: 'new_' + Date.now(),
          name: '',
          category: '',
          dest_category: '',
          vertical: '',
          strategy: '',
          schedule: 'hourly',
          publish_status: 'publish',
          author: '', // @MODIFIED 2026-03-01
          tags: '',   // @MODIFIED 2026-03-01
          active: true
        });
        // Scroll to new item
        $('html, body').animate({
          scrollTop: $('.dit-ts-campaign-card').last().offset().top - 100
        }, 300);
      });

      // 3. Bind Actions (Delegated)
      $list.on('click', '.dit-ts-remove-campaign', function () {
        if (confirm('Remove this campaign? Effect will take place after save.')) {
          $(this).closest('.dit-ts-campaign-card').fadeOut(300, function () { $(this).remove(); });
        }
      });

      $list.on('click', '.dit-ts-run-campaign', this.handleForceRun);

      // 4. Bind Submit
      $form.on('submit', function () {
        var campaigns = [];
        $list.find('.dit-ts-campaign-card').each(function () {
          var $card = $(this);
          campaigns.push({
            id: $card.data('id'),
            name: $card.find('.campaign-name').val(),
            category: $card.find('.campaign-category').val(),
            'dest_category': $card.find('.campaign-dest-category-checkbox:checked').map(function () {
              return $(this).val();
            }).get(),
            vertical: $card.find('.campaign-vertical').val(),
            strategy: $card.find('.campaign-strategy').val(),
            custom_provider_id: $card.find('.campaign-custom-provider').val(),
            custom_model_id: $card.find('.campaign-custom-model').val(),
            cross_provider_fallback: $card.find('.campaign-cross-provider-fallback').is(':checked'),
            schedule: $card.find('.campaign-schedule').val(),
            publish_status: $card.find('.campaign-publish-status').val(),
            author: $card.find('.campaign-author').val(), // @MODIFIED 2026-03-01
            tags: $card.find('.campaign-tags').val(),     // @MODIFIED 2026-03-01
            active: $card.find('.campaign-active').is(':checked')
          });
        });
        $hiddenInput.val(JSON.stringify(campaigns));
      });
    },

    fetchCampaignStats: function () {
      $.ajax({
        url: ajaxurl,
        data: { action: 'dit_ts_get_campaign_stats' },
        success: function (res) {
          if (res.success) {
            var stats = res.data;
            $('#dit-ts-campaigns-list .dit-ts-campaign-card').each(function () {
              var id = $(this).data('id');
              if (stats[id]) {
                $(this).find('.campaign-next-run').html(
                  '<span class="dashicons dashicons-clock"></span> ' +
                  stats[id].next_run_human +
                  '<div class="ts-small-ts">' + stats[id].next_run_ts + '</div>'
                );
              }
            });
          }
        }
      });
    },

    renderCampaignRow: function (data) {
      var $list = $('#dit-ts-campaigns-list');

      // Vertical Options
      var vertOptions = [
        { val: 'showbiz', label: 'Showbiz - General' },
        { val: 'fashion', label: 'Fashion - General' },
        { val: 'beauty', label: 'Beauty' },
        { val: 'showbiz_pk', label: 'Showbiz - PK' },
        { val: 'fashion_pk', label: 'Fashion - PK' }
      ];
      var vertSelect = '<select class="campaign-vertical"><option value="">-- Default --</option>';
      vertOptions.forEach(function (opt) {
        var selected = data.vertical === opt.val ? 'selected' : '';
        vertSelect += '<option value="' + opt.val + '" ' + selected + '>' + opt.label + '</option>';
      });
      vertSelect += '</select>';

      // @MODIFIED 2026-02-14 - Multi-Category Destination Selection
      var destCategories = Array.isArray(data.dest_category) ? data.dest_category : (data.dest_category ? [data.dest_category] : []);
      var destSelect = '<div class="campaign-dest-categories-outer"><div class="campaign-dest-categories-container">';

      // Default Option Row
      var defaultChecked = (destCategories.length === 0 || (destCategories.length === 1 && destCategories[0] === "")) ? 'checked' : '';
      destSelect += '<div class="campaign-dest-cat-row row-default">' +
        '<input type="checkbox" class="campaign-dest-category-checkbox" id="cat-default-' + id + '" value="" ' + defaultChecked + '>' +
        '<label for="cat-default-' + id + '">-- Post Default --</label>' +
        '</div>';

      if (window.ditTsAdmin && ditTsAdmin.categories) {
        ditTsAdmin.categories.forEach(function (cat) {
          var isChecked = destCategories.includes(cat.id.toString()) ? 'checked' : '';
          destSelect += '<div class="campaign-dest-cat-row">' +
            '<input type="checkbox" class="campaign-dest-category-checkbox" id="cat-' + cat.id + '-' + id + '" value="' + cat.id + '" ' + isChecked + '>' +
            '<label for="cat-' + cat.id + '-' + id + '">' + cat.name + '</label>' +
            '</div>';
        });
      }
      destSelect += '</div></div>';

      // AI Strategy Options
		var strategyOptions = [
			{ val: '', label: '-- Global Default --' },
			{ val: 'gemini', label: 'Gemini (Google Search Grounding)' },
			{ val: 'custom', label: 'Custom Provider (OpenAI-Compatible)' }
		];
        var strategySelect = '<select class="campaign-strategy">';
        strategyOptions.forEach(function (opt) {
            var selected = data.strategy === opt.val ? 'selected' : '';
            strategySelect += '<option value="' + opt.val + '" ' + selected + '>' + opt.label + '</option>';
        });
        strategySelect += '</select>';

        var customProviderOptions = [{ val: '', label: '-- Default --' }];
        if (window.ditTsAdmin && ditTsAdmin.customProviders) {
            ditTsAdmin.customProviders.forEach(function (p) {
                customProviderOptions.push({ val: p.id, label: p.name || p.id });
            });
        }
        var customProviderSelect = '<select class="campaign-custom-provider" style="display:block;margin-top:4px;">';
        customProviderOptions.forEach(function (opt) {
            var selected = (data.custom_provider_id || '') === opt.val ? 'selected' : '';
            customProviderSelect += '<option value="' + opt.val + '" ' + selected + '>' + opt.label + '</option>';
        });
        customProviderSelect += '</select>';

        var customModelSelect = '<select class="campaign-custom-model" style="display:block;margin-top:4px;"><option value="">-- Default --</option>';
        if (data.custom_model_id) {
            customModelSelect += '<option value="' + DitTsAdmin.escapeHtml(data.custom_model_id) + '" selected>' + DitTsAdmin.escapeHtml(data.custom_model_id) + '</option>';
        }
        customModelSelect += '</select>';

        var crossFallbackChecked = data.cross_provider_fallback ? 'checked' : '';

      // Schedule Options
      var schedOptions = [
        { val: 'manual', label: 'Manual / Disabled' },
        { val: 'every_15_mins', label: 'Every 15 Mins' },
        { val: 'every_30_mins', label: 'Every 30 Mins' },
        { val: 'hourly', label: 'Every Hour' },
        { val: '2hours', label: 'Every 2 Hours' },
        { val: '3hours', label: 'Every 3 Hours' },
        { val: '4hours', label: 'Every 4 Hours' },
        { val: '5hours', label: 'Every 5 Hours' },
        { val: '6hours', label: 'Every 6 Hours' },
        { val: '7hours', label: 'Every 7 Hours' },
        { val: '8hours', label: 'Every 8 Hours' },
        { val: '9hours', label: 'Every 9 Hours' },
        { val: '10hours', label: 'Every 10 Hours' },
        { val: '11hours', label: 'Every 11 Hours' },
        { val: '12hours', label: 'Every 12 Hours' },
        { val: 'twice_daily', label: 'Twice Daily (12h)' },
        { val: 'daily', label: 'Once a Day (24h)' },
        { val: '48hours', label: 'Once in 2 Days (48h)' }
      ];
      var schedSelect = '<select class="campaign-schedule">';
      schedOptions.forEach(function (opt) {
        var selected = (data.schedule || 'hourly') === opt.val ? 'selected' : '';
        schedSelect += '<option value="' + opt.val + '" ' + selected + '>' + opt.label + '</option>';
      });
      schedSelect += '</select>';

      // @MODIFIED 2026-02-14 - Post status options
      var statusOptions = [
        { val: 'publish', label: 'Published / Scheduled' },
        { val: 'draft', label: 'Draft' }
      ];
      var statusSelect = '<select class="campaign-publish-status">';
      statusOptions.forEach(function (opt) {
        var selected = (data.publish_status || 'publish') === opt.val ? 'selected' : '';
        statusSelect += '<option value="' + opt.val + '" ' + selected + '>' + opt.label + '</option>';
      });
      statusSelect += '</select>';

      // @MODIFIED 2026-03-01 - Author Options
      var authorSelect = '<select class="campaign-author"><option value="">-- Source Author --</option>';
      if (window.ditTsAdmin && ditTsAdmin.authors) {
        ditTsAdmin.authors.forEach(function (usr) {
          var selected = (data.author == usr.id) ? 'selected' : '';
          authorSelect += '<option value="' + usr.id + '" ' + selected + '>' + usr.name + '</option>';
        });
      }
      authorSelect += '</select>';

      var checked = data.active ? 'checked' : '';
      var id = data.id || '';

      var card = '<div class="dit-ts-campaign-card" data-id="' + id + '">' +
        '<div class="col-main">' +
        '<div class="field-group">' +
        '<label>Campaign Name</label>' +
        '<input type="text" class="campaign-name" value="' + (data.name || '') + '" placeholder="e.g. Trendy Fashion">' +
        '</div>' +
        '<div class="field-group">' +
        '<label>Source Category (Slug)</label>' +
        '<input type="text" class="campaign-category" value="' + (data.category || '') + '" placeholder="e.g. fashion-news">' +
        '</div>' +
        '<div class="field-group">' + // @MODIFIED 2026-03-01
        '<label>Tags (comma separated)</label>' +
        '<input type="text" class="campaign-tags" value="' + (data.tags || '') + '" placeholder="e.g. fashion, trends">' +
        '</div>' +
        '</div>' +
        '<div class="col-routing">' +
        '<div class="field-group">' + // @MODIFIED 2026-03-01
        '<label>Post Author</label>' +
        authorSelect +
        '</div>' +
        '<div class="field-group">' +
        '<label>Target Vertical</label>' +
        vertSelect +
        '</div>' +
        '<div class="field-group">' +
        '<label>Destination Category</label>' +
        destSelect +
        '</div>' +
        '<div class="field-group">' +
        '<label>AI Strategy</label>' +
        strategySelect +
        '<div class="campaign-custom-provider-row" style="display:' + (data.strategy === 'custom' ? 'block' : 'none') + ';">' +
        '<label style="font-size:11px;margin-top:4px;">Provider</label>' +
        customProviderSelect +
        '</div>' +
        '<div class="campaign-custom-model-row" style="display:' + (data.strategy === 'custom' ? 'block' : 'none') + ';">' +
        '<label style="font-size:11px;margin-top:2px;">Model</label>' +
        customModelSelect +
        '</div>' +
        '<div class="campaign-cross-fallback-row" style="display:' + (data.strategy === 'custom' ? 'block' : 'none') + ';">' +
        '<label style="font-size:11px;margin-top:4px;"><input type="checkbox" class="campaign-cross-provider-fallback" ' + crossFallbackChecked + '> Cross-Provider Fallback</label>' +
        '</div>' +
        '</div>' +
        '</div>' +
        '<div class="col-schedule">' +
        '<div class="field-group">' +
        '<label>Frequency</label>' +
        schedSelect +
        '</div>' +
        '<div class="field-group">' +
        '<label>Publish Status</label>' +
        statusSelect +
        '</div>' +
        '</div>' +
        '<div class="col-status">' +
        '<label>Status & Active</label>' +
        '<div class="status-wrap">' +
        '<div class="campaign-next-run"><em>(Save to calc)</em></div>' +
        '<div class="active-toggle"><input type="checkbox" class="campaign-active" ' + checked + '> Active</div>' +
        '</div>' +
        '</div>' +
        '<div class="col-actions">' +
        '<button type="button" class="button button-primary dit-ts-run-campaign"><span class="dashicons dashicons-controls-play"></span> Run</button>' +
        '<button type="button" class="button button-link-delete dit-ts-remove-campaign">Remove</button>' +
        '</div>' +
        '</div>';

      $list.append(card);
    },

    /**
     * Handle Manual Queue Repair
     */
    handleRepairQueue: function (e) {
      e.preventDefault();
      var $btn = $("#dit-ts-repair-queue");
      var $result = $(".repair-result");

      $btn.addClass('disabled').text("Repairing...");
      $result.text("Running queue runner...").css("color", "#666");

      $.post(ditTsAdmin.ajaxUrl, {
        action: "dit_ts_process_queue",
        nonce: ditTsAdmin.nonce,
      })
        .done(function (response) {
          if (response.success) {
            $result.text("✓ " + response.data.message).css("color", "#166534");
            setTimeout(function () { location.reload(); }, 1500);
          } else {
            $result.text("✗ " + response.data.message).css("color", "#d63638");
            $btn.removeClass('disabled').text("Repair Now");
          }
        })
        .fail(function () {
          $result.text("✗ Request failed").css("color", "#d63638");
          $btn.removeClass('disabled').text("Repair Now");
        });
    },

    /**
     * Handle Master AI Automation Switch
     */
    handleToggleAutomation: function (e) {
      var $el = $(e.currentTarget);
      var isButton = $el.is('button');
      var enabled;

      if (isButton) {
        enabled = $el.data('enabled') == 1 ? 0 : 1;
        $el.find('.btn-text').text(enabled ? "SAVING..." : "PAUSING...");
      } else {
        enabled = e.target.checked ? 1 : 0;
        $("#dit-ts-automation-status-text").text(enabled ? "SAVING..." : "PAUSING...");
      }

      $.post(ditTsAdmin.ajaxUrl, {
        action: "dit_ts_toggle_ai_automation",
        nonce: ditTsAdmin.nonce,
        enabled: enabled,
      }).done(function (response) {
        if (response.success) {
          if (isButton) {
            $el.data('enabled', enabled);
            $el.removeClass('button-active button-paused').addClass(enabled ? 'button-active' : 'button-paused');
            $el.find('.btn-text').text(enabled ? "AI Automation: RUNNING" : "AI Automation: PAUSED");
            $el.find('.dashicons').removeClass('dashicons-controls-play dashicons-controls-pause')
              .addClass(enabled ? 'dashicons-controls-play' : 'dashicons-controls-pause');
          } else {
            var $statusText = $("#dit-ts-automation-status-text");
            $statusText.text(enabled ? "ACTIVE" : "PAUSED");
            if (!enabled) {
              $statusText.css("color", "#d63638");
            } else {
              $statusText.css("color", "inherit");
            }
          }
        } else {
          alert("Error: " + (response.data || "Unknown error"));
          if (!isButton) e.target.checked = !enabled;
        }
      }).fail(function () {
        alert("Request Failed. Check your connection or nonce.");
        if (!isButton) e.target.checked = !enabled;
      });
    },

    /**
     * Handle Emergency Stop (Cancel All)
     */
    handleEmergencyStop: function () {
      if (!confirm("EMERGENCY STOP: This will immediately cancel all pending and processing AI jobs and clear the background queue. Continue?")) {
        return;
      }

      var $btn = $("#dit-ts-emergency-stop");
      $btn.prop("disabled", true).text("Stopping Everything...");

      $.post(ditTsAdmin.ajaxUrl, {
        action: "dit_ts_cancel_all_jobs",
        nonce: ditTsAdmin.nonce,
      }).done(function (response) {
        if (response.success) {
          alert(response.data.message);
          location.reload();
        } else {
          alert("Error: " + (response.data || "Unknown error"));
          $btn.prop("disabled", false).text("Emergency Stop: Cancel All Jobs");
        }
      }).fail(function () {
        alert("Emergency Stop Request Failed.");
        $btn.prop("disabled", false).text("Emergency Stop: Cancel All Jobs");
      });
    },

    /**
     * Handle Manual System Reset
     * This is a powerful recovery tool for "Clear Quota Pause" and "Self-Locking" fixes.
     * 
     * @since 2.4.0
     */
    handleResetSystem: function (e) {
      e.preventDefault();
      var $btn = $("#dit-ts-reset-system");
      var $result = $(".reset-system-result");

      if (!confirm("RESET SYSTEM STATUS: This will clear all transient locks and cancel active jobs to fix 'System busy' deadlocks. Use this if the engine seems paralyzed. Continue?")) {
        return;
      }

      $btn.prop("disabled", true).addClass('loading');
      $result.text("Resetting system state...").css({ "color": "#2271b1", "font-weight": "600" });

      $.post(ditTsAdmin.ajaxUrl, {
        action: "dit_ts_reset_system",
        nonce: ditTsAdmin.nonce,
      })
        .done(function (response) {
          if (response.success) {
            $result.text("✓ " + (response.data.message || "System cleaned.")).css("color", "#166534");
            // Highlight that jobs were cancelled if applicable
            if (response.data.data && response.data.data.cancelled > 0) {
              $result.append("<br><small>Cancelled " + response.data.data.cancelled + " active jobs.</small>");
            }
            setTimeout(function () { location.reload(); }, 2000);
          } else {
            var msg = response.data && response.data.message ? response.data.message : "Reset failed.";
            $result.text("✗ " + msg).css("color", "#d63638");
            $btn.prop("disabled", false).removeClass('loading');
          }
        })
        .fail(function () {
          $result.text("✗ Request failed").css("color", "#d63638");
          $btn.prop("disabled", false).removeClass('loading');
        });
        },

        /**
         * Handle Deactivate Quota Pause button click
         *
         * @since 2026-04-22
         */
        handleDeactivateQuotaPause: function (e) {
            e.preventDefault();
            var $btn = $(e.currentTarget);
            var provider = $btn.data('provider');
            var $result = $('.deactivate-pause-result[data-provider="' + provider + '"]');

            if (!confirm("Deactivate the quota pause for " + provider.charAt(0).toUpperCase() + provider.slice(1) + "? This will resume API calls immediately.")) {
                return;
            }

            $btn.prop("disabled", true).addClass('loading');
            $result.text("Deactivating pause...").css({ "color": "#2271b1", "font-weight": "600" });

            $.post(ditTsAdmin.ajaxUrl, {
                action: "dit_ts_deactivate_quota_pause",
                nonce: ditTsAdmin.nonce,
                provider: provider,
            })
            .done(function (response) {
                if (response.success) {
                    $result.text("✓ " + (response.data.message || "Pause deactivated.")).css("color", "#166534");
                    setTimeout(function () { location.reload(); }, 1500);
                } else {
                    var msg = response.data && response.data.message ? response.data.message : "Deactivation failed.";
                    $result.text("✗ " + msg).css("color", "#d63638");
                    $btn.prop("disabled", false).removeClass('loading');
                }
            })
            .fail(function () {
                $result.text("✗ Request failed").css("color", "#d63638");
                $btn.prop("disabled", false).removeClass('loading');
            });
        },

        initCustomProviders: function () {
        var $list = $("#dit-ts-custom-providers-list");
        if ($list.length === 0) return;

        var $hidden = $("#dit_ts_custom_providers_json");
        var providers = [];

        if (window.ditTsAdmin && ditTsAdmin.customProviders && ditTsAdmin.customProviders.length > 0) {
            providers = ditTsAdmin.customProviders;
        } else {
            try { providers = JSON.parse($hidden.val() || "[]"); } catch (e) { providers = []; }
        }

        if (!Array.isArray(providers)) providers = [];

        var self = this;
        providers.forEach(function (p) {
            self.renderProviderCard(p, true);
        });

        this.refreshDefaultProviderDropdown();
        this.refreshCrossProviderOrder();

        var fallbackConfig = {};
        try { fallbackConfig = JSON.parse($("#dit_ts_custom_fallback_config_json").val() || "{}"); } catch (e) {}
        if (!fallbackConfig.enable_model_fallback) {
            $("#dit_ts_fallback_enable_model").prop("checked", false);
        }
        if (fallbackConfig.enable_cross_provider_fallback) {
            $("#dit_ts_fallback_enable_cross_provider").prop("checked", true);
            $("#dit-ts-cross-provider-order").show();
        }

        var $form = $hidden.closest("form");
        $form.on("submit", function () {
            self.syncProvidersToHidden();
            self.syncFallbackConfigToHidden();
        });
    },

    renderProviderCard: function (data, isExisting) {
        var $list = $("#dit-ts-custom-providers-list");
        var id = data.id || ("prov_" + Date.now() + "_" + Math.random().toString(36).substr(2, 5));
        var name = data.name || "";
        var apiUrl = data.api_url || "";
        var apiKey = data.api_key || "";
        var hasKey = (typeof data.api_key === "string" && data.api_key !== "") || apiKey === true;
        var enableWebSearch = !!data.enable_web_search;
        var wsConfig = data.web_search_config || { type: "none" };
        var models = data.models || [];
        var fallbackEnabled = data.fallback_enabled !== false;

        var card = '<div class="dit-ts-provider-card" data-provider-id="' + DitTsAdmin.escapeHtml(id) + '">';
        card += '<div class="provider-header">';
        card += '<h4><span class="provider-name-display">' + (name ? DitTsAdmin.escapeHtml(name) : "New Provider") + '</span> <code style="font-size:11px;color:#646970;">' + DitTsAdmin.escapeHtml(id) + '</code></h4>';
        card += '<div>';
        card += '<button type="button" class="button button-small dit-ts-provider-move-up" title="Move Up">&#9650;</button> ';
        card += '<button type="button" class="button button-small dit-ts-provider-move-down" title="Move Down">&#9660;</button> ';
        card += '<button type="button" class="button button-small dit-ts-provider-test" title="Test Connection"><span class="dashicons dashicons-admin-plugins" style="font-size:14px;width:14px;height:14px;margin-top:2px;"></span></button> ';
        card += '<button type="button" class="button button-link-delete dit-ts-provider-remove" title="Remove Provider"><span class="dashicons dashicons-trash" style="font-size:14px;width:14px;height:14px;margin-top:2px;color:#d63638;"></span></button>';
        card += "</div></div>";

        // @ADDED 2026-07-12 — OpenRouter free-model sync status + button (provider card)
        if (apiUrl && apiUrl.toLowerCase().indexOf("openrouter.ai") !== -1) {
            var orSync = window.ditTsAdmin && ditTsAdmin.openrouterLastSync ? ditTsAdmin.openrouterLastSync : 0;
            var orClass = orSync > 0 ? "sync-ok" : "sync-warn";
            var orText = orSync > 0
                ? "Last synced: " + DitTsAdmin.timeSince(orSync) + " ago"
                : "Never synced";
            card += '<div class="openrouter-sync-status ' + orClass + '">';
            card += '<span class="dashicons dashicons-update"></span>';
            card += '<span class="openrouter-sync-text">' + DitTsAdmin.escapeHtml(orText) + '</span>';
            card += "</div>";
            card += '<button type="button" class="button button-small dit-ts-openrouter-sync-btn" style="width:100%;margin-top:4px;">Sync Free Models</button>';
        }

        // @ADDED 2026-07-17 — OpenCode Zen free-model sync status + button (provider card)
        if (apiUrl && (apiUrl.toLowerCase().indexOf("opencode.ai") !== -1)) {
            var ocSync = window.ditTsAdmin && ditTsAdmin.opencodeLastSync ? ditTsAdmin.opencodeLastSync : 0;
            var ocClass = ocSync > 0 ? "sync-ok" : "sync-warn";
            var ocText = ocSync > 0
                ? "Last synced: " + DitTsAdmin.timeSince(ocSync) + " ago"
                : "Never synced";
            card += '<div class="opencode-sync-status ' + ocClass + '">';
            card += '<span class="dashicons dashicons-update"></span>';
            card += '<span class="opencode-sync-text">' + DitTsAdmin.escapeHtml(ocText) + '</span>';
            card += "</div>";
            card += '<button type="button" class="button button-small dit-ts-opencode-sync-btn" style="width:100%;margin-top:4px;">Sync OpenCode Models</button>';
        }

        card += '<div class="provider-fields">';

        card += '<div class="field-full"><label>Provider Name</label>';
        card += '<input type="text" class="provider-name" value="' + DitTsAdmin.escapeHtml(name) + '" placeholder="e.g. GLM via ZydIt"></div>';

        card += '<div><label>Provider ID (slug)</label>';
        card += '<input type="text" class="provider-id" value="' + DitTsAdmin.escapeHtml(id) + '" placeholder="auto-generated" ' + (isExisting ? 'readonly style="background:#f0f0f1;"' : '') + '></div>';

        card += '<div><label>API URL</label>';
        card += '<input type="url" class="provider-api-url" value="' + DitTsAdmin.escapeHtml(apiUrl) + '" placeholder="https://open.bigmodel.cn/api/paas/v4"></div>';

        card += '<div><label>API Key</label>';
        card += '<div style="display:flex;gap:4px;">';
        card += '<input type="password" class="provider-api-key" value="' + (hasKey && isExisting ? "••••••••" : DitTsAdmin.escapeHtml(typeof apiKey === "string" ? apiKey : "")) + '" placeholder="API Key" style="flex:1;">';
        card += '<button type="button" class="button dit-ts-provider-toggle-visibility" title="Show/Hide"><span class="dashicons dashicons-visibility" style="font-size:14px;width:14px;height:14px;margin-top:2px;"></span></button>';
        card += "</div></div>";

        card += '<div><label>Enable Web Search</label>';
        card += '<label><input type="checkbox" class="provider-enable-web-search" ' + (enableWebSearch ? "checked" : "") + '> Enable web search tool injection</label></div>';

        card += '<div class="web-search-config" style="' + (enableWebSearch ? "" : "display:none;") + '">';
        card += '<label>Search Type</label>';
        card += '<select class="provider-ws-type">';
        card += '<option value="none"' + (wsConfig.type === "none" ? " selected" : "") + '>None</option>';
        card += '<option value="zhipuai"' + (wsConfig.type === "zhipuai" ? " selected" : "") + '>ZhipuAI (ChatGLM)</option>';
        card += '<option value="kimi"' + (wsConfig.type === "kimi" ? " selected" : "") + '>Kimi (Moonshot)</option>';
        card += '<option value="minimax"' + (wsConfig.type === "minimax" ? " selected" : "") + '>MiniMax</option>';
        card += "</select>";

        card += '<div class="ws-zhipuai-options" style="margin-top:6px;' + (wsConfig.type === "zhipuai" ? "" : "display:none;") + '">';
        card += '<label>Search Engine</label>';
        card += '<select class="provider-ws-search-engine">';
        card += '<option value="search_pro"' + ((wsConfig.search_engine || "search_pro") === "search_pro" ? " selected" : "") + '>Search Pro</option>';
        card += '<option value="search_pro_lite"' + (wsConfig.search_engine === "search_pro_lite" ? " selected" : "") + '>Search Pro Lite</option>';
        card += "</select>";
        card += '<label style="margin-top:4px;">Result Count</label>';
        card += '<input type="number" class="provider-ws-search-count" value="' + (wsConfig.search_count || 10) + '" min="1" max="20" style="width:70px;">';
        card += "</div></div>";

        card += '<div><label>Model Fallback</label>';
        card += '<label><input type="checkbox" class="provider-fallback-enabled" ' + (fallbackEnabled ? "checked" : "") + '> Try next model on 429/403</label></div>';

        card += '<div class="field-full"><label>Models (fallback order: top = primary)</label>';
        card += '<div class="models-list">';
        if (models.length === 0) {
            card += DitTsAdmin.buildModelRow("", "");
        } else {
            models.forEach(function (m) {
                card += DitTsAdmin.buildModelRow(m.display_name || "", m.model_id || "");
            });
        }
        card += "</div>";
        card += '<button type="button" class="button button-small dit-ts-provider-add-model" style="margin-top:4px;">+ Add Model</button>';
        card += "</div>";

        card += '<div class="provider-actions"><span class="provider-test-result"></span></div>';
        card += "</div></div>";

        $list.append(card);
    },

    buildModelRow: function (displayName, modelId) {
        return '<div class="model-row">' +
            '<input type="text" class="model-display-name" value="' + DitTsAdmin.escapeHtml(displayName) + '" placeholder="Display Name" style="width:40%;">' +
            '<input type="text" class="model-id" value="' + DitTsAdmin.escapeHtml(modelId) + '" placeholder="Model ID (e.g. glm-4)" style="width:45%;">' +
            '<button type="button" class="button button-small dit-ts-provider-remove-model" title="Remove" style="color:#d63638;"><span class="dashicons dashicons-minus" style="font-size:14px;width:14px;height:14px;margin-top:1px;"></span></button>' +
            "</div>";
    },

    handleAddCustomProvider: function (e) {
        e.preventDefault();
        this.renderProviderCard({ id: "", name: "", api_url: "", api_key: "", enable_web_search: false, web_search_config: { type: "none" }, models: [], fallback_enabled: true }, false);
        $("html, body").animate({ scrollTop: $(".dit-ts-provider-card").last().offset().top - 100 }, 300);
    },

    handleRemoveCustomProvider: function (e) {
        e.preventDefault();
        if (!confirm("Remove this provider? Save settings to apply.")) return;
        $(e.currentTarget).closest(".dit-ts-provider-card").fadeOut(200, function () { $(this).remove(); DitTsAdmin.refreshDefaultProviderDropdown(); DitTsAdmin.refreshCrossProviderOrder(); });
    },

    handleAddProviderModel: function (e) {
        e.preventDefault();
        $(e.currentTarget).siblings(".models-list").append(DitTsAdmin.buildModelRow("", ""));
    },

    handleRemoveProviderModel: function (e) {
        e.preventDefault();
        var $list = $(e.currentTarget).closest(".models-list");
        if ($list.find(".model-row").length > 1) {
            $(e.currentTarget).closest(".model-row").remove();
        }
    },

    handleMoveProviderUp: function (e) {
        e.preventDefault();
        var $card = $(e.currentTarget).closest(".dit-ts-provider-card");
        var $prev = $card.prev(".dit-ts-provider-card");
        if ($prev.length) { $card.insertBefore($prev); this.refreshDefaultProviderDropdown(); }
    },

    handleMoveProviderDown: function (e) {
        e.preventDefault();
        var $card = $(e.currentTarget).closest(".dit-ts-provider-card");
        var $next = $card.next(".dit-ts-provider-card");
        if ($next.length) { $card.insertAfter($next); this.refreshDefaultProviderDropdown(); }
    },

    handleToggleProviderKeyVisibility: function (e) {
        e.preventDefault();
        var $btn = $(e.currentTarget);
        var $input = $btn.siblings(".provider-api-key");
        if ($input.attr("type") === "password") {
            $input.attr("type", "text");
            $btn.find(".dashicons").removeClass("dashicons-visibility").addClass("dashicons-hidden");
        } else {
            $input.attr("type", "password");
            $btn.find(".dashicons").removeClass("dashicons-hidden").addClass("dashicons-visibility");
        }
    },

    handleTestCustomProvider: function (e) {
        e.preventDefault();
        var $card = $(e.currentTarget).closest(".dit-ts-provider-card");
        var $result = $card.find(".provider-test-result");
        var apiKey = $card.find(".provider-api-key").val();
        var apiUrl = $card.find(".provider-api-url").val();
        var providerId = $card.find(".provider-id").val();

        if (apiKey === "••••••••") apiKey = "";
        if (!apiUrl) { $result.text("API URL required.").css("color", "#d63638"); return; }

        $(e.currentTarget).prop("disabled", true);
        $result.text("Testing...").css("color", "#666");

        $.post(ditTsAdmin.ajaxUrl, {
            action: "dit_ts_test_custom_provider",
            nonce: ditTsAdmin.nonce,
            provider_id: providerId,
            api_key: apiKey,
            api_url: apiUrl
        }).done(function (resp) {
            if (resp.success) {
                $result.text("✓ " + (resp.data || "Connected")).css("color", "#166534");
            } else {
                $result.text("✗ " + (resp.data && resp.data.message ? resp.data.message : resp.data || "Error")).css("color", "#d63638");
            }
        }).fail(function () {
            $result.text("✗ Request failed").css("color", "#d63638");
        }).always(function () {
            $(e.currentTarget).prop("disabled", false);
        });
    },

    /**
     * OpenRouter Sync Button — delegated click handler.
     * Fires for any `.dit-ts-openrouter-sync-btn` that was rendered inside
     * a provider card whose `api-url` contains "openrouter.ai".
     *
     * @ADDED 2026-07-12 — OpenRouter free-model sync (universal plan §4b).
     */
    handleSyncOpenRouterModels: function (e) {
        e.preventDefault();
        e.stopImmediatePropagation();
        var $btn = $(e.currentTarget);
        var $card = $btn.closest(".dit-ts-provider-card");
        var $status = $card.find(".openrouter-sync-status");
        var $text = $card.find(".openrouter-sync-text");

        if (!confirm("Pull the latest free models from OpenRouter?")) {
            return;
        }

        $btn.prop("disabled", true).text("Syncing...");
        $text.text("Syncing models...");
        $status.removeClass("sync-ok sync-warn").addClass("sync-warn");

        $.post(ditTsAdmin.ajaxUrl, {
            action: "dit_ts_sync_openrouter_models",
            nonce: ditTsAdmin.nonce
        })
        .done(function (resp) {
            if (resp.success) {
                $status.removeClass("sync-warn").addClass("sync-ok");
                $text.text(resp.data && resp.data.message ? resp.data.message : "Sync complete.");
                alert(resp.data && resp.data.message ? resp.data.message : "Sync complete.");
                location.reload();
            } else {
                $status.removeClass("sync-ok").addClass("sync-warn");
                $text.text("Failed: " + (resp.data && resp.data.message ? resp.data.message : resp.data || "Error"));
                alert("Failed: " + (resp.data && resp.data.message ? resp.data.message : resp.data || "Error"));
            }
        })
        .fail(function (j, t, e) {
            $text.text("AJAX error.");
            alert("AJAX error: " + (t || "unknown"));
        })
        .always(function () {
            $btn.prop("disabled", false).text("Sync Free Models");
        });
    },

    /**
     * OpenCode Zen Sync Button — delegated click handler.
     * Fires for any `.dit-ts-opencode-sync-btn` that was rendered inside
     * a provider card whose `api-url` contains "opencode.ai".
     *
     * @ADDED 2026-07-17 — OpenCode Zen free-model sync (parallel to OpenRouter).
     */
    handleSyncOpenCodeModels: function (e) {
        e.preventDefault();
        e.stopImmediatePropagation();
        var $btn = $(e.currentTarget);
        var $card = $btn.closest(".dit-ts-provider-card");
        var $status = $card.find(".opencode-sync-status");
        var $text = $card.find(".opencode-sync-text");

        if (!confirm("Pull the latest free models from OpenCode? This will REPLACE the current OpenCode model list.")) {
            return;
        }

        $btn.prop("disabled", true).text("Syncing...");
        $text.text("Syncing models...");
        $status.removeClass("sync-ok sync-warn").addClass("sync-warn");

        $.post(ditTsAdmin.ajaxUrl, {
            action: "dit_ts_sync_opencode_models",
            nonce: ditTsAdmin.nonce
        })
        .done(function (resp) {
            if (resp.success) {
                $status.removeClass("sync-warn").addClass("sync-ok");
                $text.text(resp.data && resp.data.message ? resp.data.message : "Sync complete.");
                alert(resp.data && resp.data.message ? resp.data.message : "Sync complete.");
                location.reload();
            } else {
                $status.removeClass("sync-ok").addClass("sync-warn");
                $text.text("Failed: " + (resp.data && resp.data.message ? resp.data.message : resp.data || "Error"));
                alert("Failed: " + (resp.data && resp.data.message ? resp.data.message : resp.data || "Error"));
            }
        })
        .fail(function (j, t, e) {
            $text.text("AJAX error.");
            alert("AJAX error: " + (t || "unknown"));
        })
        .always(function () {
            $btn.prop("disabled", false).text("Sync OpenCode Models");
        });
    },

    toggleCrossProviderOrder: function () {
        if ($("#dit_ts_fallback_enable_cross_provider").is(":checked") || $("#dit_ts_fallback_enable_universal").is(":checked")) {
            $("#dit-ts-cross-provider-order").show();
            this.refreshCrossProviderOrder();
        } else {
            $("#dit-ts-cross-provider-order").hide();
        }
    },

    refreshCrossProviderOrder: function () {
        var $ul = $("#dit-ts-cross-provider-sortable");
        var fallbackConfig = {};
        try { fallbackConfig = JSON.parse($("#dit_ts_custom_fallback_config_json").val() || "{}"); } catch (e) {}
        var savedOrder = fallbackConfig.cross_provider_order || [];

        $ul.empty();
        var providers = this.collectProvidersList();
        var ordered = [];
        savedOrder.forEach(function (id) {
            var p = providers.find(function (pr) { return pr.id === id; });
            if (p) ordered.push(p);
        });
        providers.forEach(function (p) {
            if (!ordered.find(function (o) { return o.id === p.id; })) ordered.push(p);
        });

        ordered.forEach(function (p) {
            $ul.append('<li data-id="' + DitTsAdmin.escapeHtml(p.id) + '">' + DitTsAdmin.escapeHtml(p.name || p.id) + '</li>');
        });

        // @MODIFIED 2026-06-01 - Initialize jQuery UI sortable on the cross-provider list
        if ($ul.length && typeof $ul.sortable === 'function') {
            if ($ul.sortable('instance')) {
                $ul.sortable('destroy');
            }
            $ul.sortable({
                axis: 'y',
                placeholder: 'dit-ts-sortable-placeholder',
                forcePlaceholderSize: true,
                tolerance: 'pointer',
                cancel: ''
            });
        }
    },

    collectProvidersList: function () {
        var list = [];
        // @MODIFIED 2026-06-01 - Only Gemini is a built-in non-custom provider; OpenRouter/Groq
        // were removed as standalone providers (use Custom Providers instead).
        list.push({ id: 'gemini', name: 'Gemini (Google)' });
        $(".dit-ts-provider-card").each(function () {
            var id = $(this).find(".provider-id").val() || $(this).data("provider-id");
            var name = $(this).find(".provider-name").val() || id;
            if (id) list.push({ id: id, name: name });
        });
        return list;
    },

    refreshDefaultProviderDropdown: function () {
        var $select = $("#dit_ts_custom_default_provider");
        var currentVal = $select.val();
        $select.find("option:not(:first)").remove();
        this.collectProvidersList().forEach(function (p) {
            var selected = p.id === currentVal ? " selected" : "";
            $select.append('<option value="' + DitTsAdmin.escapeHtml(p.id) + '"' + selected + '>' + DitTsAdmin.escapeHtml(p.name || p.id) + '</option>');
        });
    },

    syncProvidersToHidden: function () {
        var providers = [];
        $(".dit-ts-provider-card").each(function () {
            var $card = $(this);
            var id = $card.find(".provider-id").val() || $card.data("provider-id");
            if (!id) {
                var name = $card.find(".provider-name").val() || "provider";
                id = name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
                if (!id) id = "prov_" + Date.now();
                $card.find(".provider-id").val(id);
            }
            var apiKey = $card.find(".provider-api-key").val();
            if (apiKey === "••••••••") apiKey = "";

            var models = [];
            $card.find(".models-list .model-row").each(function () {
                var mid = $(this).find(".model-id").val();
                var mname = $(this).find(".model-display-name").val() || mid;
                if (mid) models.push({ display_name: mname, model_id: mid });
            });

            providers.push({
                id: id,
                name: $card.find(".provider-name").val(),
                api_url: $card.find(".provider-api-url").val(),
                api_key: apiKey,
                enable_web_search: $card.find(".provider-enable-web-search").is(":checked"),
                web_search_config: {
                    type: $card.find(".provider-ws-type").val() || "none",
                    search_engine: $card.find(".provider-ws-search-engine").val() || "search_pro",
                    search_count: parseInt($card.find(".provider-ws-search-count").val(), 10) || 10
                },
                models: models,
                fallback_enabled: $card.find(".provider-fallback-enabled").is(":checked")
            });
        });
        $("#dit_ts_custom_providers_json").val(JSON.stringify(providers));
    },

    syncFallbackConfigToHidden: function () {
        var order = [];
        $("#dit-ts-cross-provider-sortable li").each(function () {
            order.push($(this).data("id"));
        });
        var config = {
            enable_model_fallback: $("#dit_ts_fallback_enable_model").is(":checked"),
            enable_cross_provider_fallback: $("#dit_ts_fallback_enable_cross_provider").is(":checked"),
            enable_universal_fallback: $("#dit_ts_fallback_enable_universal").is(":checked"),
            cross_provider_order: order
        };
        $("#dit_ts_custom_fallback_config_json").val(JSON.stringify(config));
    },

    handleToggleWebSearchConfig: function (e) {
        var $card = $(e.currentTarget).closest(".dit-ts-provider-card");
        if ($(e.currentTarget).is(":checked")) {
            $card.find(".web-search-config").show();
        } else {
            $card.find(".web-search-config").hide();
        }
    },

    handleToggleWsType: function (e) {
        var $card = $(e.currentTarget).closest(".dit-ts-provider-card");
        var type = $(e.currentTarget).val();
        if (type === "zhipuai") {
            $card.find(".ws-zhipuai-options").show();
        } else {
            $card.find(".ws-zhipuai-options").hide();
        }
    },

    handleProviderNameChange: function (e) {
        var $card = $(e.currentTarget).closest(".dit-ts-provider-card");
        var name = $(e.currentTarget).val();
        $card.find(".provider-name-display").text(name || "New Provider");
    },

    handleProviderIdChange: function (e) {
        var $card = $(e.currentTarget).closest(".dit-ts-provider-card");
        var id = $(e.currentTarget).val();
        $card.attr("data-provider-id", id);
        $card.find("code").text(id);
    },

    initGenerationFormProviders: function () {
        if ($("#ai_strategy").length === 0) return;
        this.populateGenerationProviderDropdown();
        this.handleGenerationStrategyChange();
    },

    handleGenerationStrategyChange: function () {
        var strategy = $("#ai_strategy").val();
        if (strategy === "custom") {
            $("#dit-ts-custom-provider-row").show();
            $("#dit-ts-custom-model-row").show();
            this.populateGenerationProviderDropdown();
        } else {
            $("#dit-ts-custom-provider-row").hide();
            $("#dit-ts-custom-model-row").hide();
        }
    },

    populateGenerationProviderDropdown: function () {
        var $select = $("#custom_provider_id");
        if ($select.length === 0) return;
        var currentVal = $select.val();
        $select.find("option:not(:first)").remove();

        var providers = this.getCustomProvidersArray();
        providers.forEach(function (p) {
            var selected = p.id === currentVal ? " selected" : "";
            $select.append('<option value="' + DitTsAdmin.escapeHtml(p.id) + '"' + selected + '>' + DitTsAdmin.escapeHtml(p.name || p.id) + '</option>');
        });
    },

    handleGenerationProviderChange: function () {
        var providerId = $("#custom_provider_id").val();
        var $modelSelect = $("#custom_model_id");
        $modelSelect.find("option:not(:first)").remove();

        if (!providerId) return;

        var provider = this.findCustomProvider(providerId);
        if (!provider || !provider.models) return;

        provider.models.forEach(function (m) {
            var mid = m.model_id || "";
            var mname = m.display_name || mid;
            if (mid) {
                $modelSelect.append('<option value="' + DitTsAdmin.escapeHtml(mid) + '">' + DitTsAdmin.escapeHtml(mname) + '</option>');
            }
        });
    },

    getCustomProvidersArray: function () {
        if (window.ditTsAdmin && ditTsAdmin.customProviders && ditTsAdmin.customProviders.length > 0) {
            return ditTsAdmin.customProviders;
        }
        try {
            var raw = $("#dit_ts_custom_providers_json").val();
            var parsed = JSON.parse(raw || "[]");
            if (Array.isArray(parsed)) return parsed;
            if (typeof parsed === "object" && parsed !== null) return Object.values(parsed);
        } catch (e) {}
        return [];
    },

    findCustomProvider: function (id) {
        var providers = this.getCustomProvidersArray();
        return providers.find(function (p) { return p.id === id; }) || null;
    },

    handleCampaignStrategyChange: function (e) {
        var $card = $(e.currentTarget).closest(".dit-ts-campaign-card");
        var strategy = $(e.currentTarget).val();
        var $providerRow = $card.find(".campaign-custom-provider-row");
        var $modelRow = $card.find(".campaign-custom-model-row");
        var $fallbackRow = $card.find(".campaign-cross-fallback-row");

        if (strategy === "custom") {
            $providerRow.show();
            $modelRow.show();
            $fallbackRow.show();
            this.populateCampaignProviderDropdown($card);
        } else {
            $providerRow.hide();
            $modelRow.hide();
            $fallbackRow.hide();
        }
    },

    handleCampaignProviderChange: function (e) {
        var $card = $(e.currentTarget).closest(".dit-ts-campaign-card");
        var providerId = $(e.currentTarget).val();
        var $modelSelect = $card.find(".campaign-custom-model");
        $modelSelect.find("option:not(:first)").remove();

        if (!providerId) return;
        var provider = this.findCustomProvider(providerId);
        if (!provider || !provider.models) return;

        provider.models.forEach(function (m) {
            var mid = m.model_id || "";
            var mname = m.display_name || mid;
            if (mid) {
                $modelSelect.append('<option value="' + DitTsAdmin.escapeHtml(mid) + '">' + DitTsAdmin.escapeHtml(mname) + '</option>');
            }
        });
    },

    populateCampaignProviderDropdown: function ($card) {
        var $select = $card.find(".campaign-custom-provider");
        var currentVal = $select.val();
        $select.find("option:not(:first)").remove();

        var providers = this.getCustomProvidersArray();
        providers.forEach(function (p) {
            var selected = p.id === currentVal ? " selected" : "";
            $select.append('<option value="' + DitTsAdmin.escapeHtml(p.id) + '"' + selected + '>' + DitTsAdmin.escapeHtml(p.name || p.id) + '</option>');
        });
    },

    initColorPickers: function () {
        if (jQuery('.dit-color-picker').length > 0) {
            jQuery('.dit-color-picker').wpColorPicker();
        }
    },

    escapeHtml: function (text) {
      var div = document.createElement("div");
      div.textContent = text;
      return div.innerHTML;
    },

    /**
     * Human-readable duration between a Unix timestamp (seconds) and now.
     * Returns values like "3 minutes", "2 days", etc.
     *
     * @ADDED 2026-07-12 — OpenRouter sync status display.
     * @param {number} ts Unix timestamp in seconds (must be > 0).
     * @return {string}
     */
    timeSince: function (ts) {
      var nowSec = Math.floor(Date.now() / 1000);
      var diff = Math.max(0, nowSec - ts);
      if (diff < 60) return "less than a minute";
      if (diff < 3600) return Math.floor(diff / 60) + " minutes";
      if (diff < 86400) return Math.floor(diff / 3600) + " hours";
      if (diff < 2592000) return Math.floor(diff / 86400) + " days";
      return Math.floor(diff / 2592000) + " months";
    },

    // ─── Logs Page: Sidebar + Filtering + Pagination ───────────────────────
    initLogsPage: function () {
      if (!$("#dit-ts-log-file-list").length) return;

      var self = this;
      var currentFile    = $("#dit-ts-log-file-list li.active").data("file") || "";
      var currentPage    = 1;
      var perPage        = 200;
      var currentLevel   = "ALL";
      var currentSearch  = "";
      var isLoading      = false;

      function loadLogs() {
        if (!currentFile || isLoading) return;
        isLoading = true;

        var $tbody = $("#dit-ts-log-tbody");
        $tbody.html(
          '<tr><td colspan="5" class="dit-ts-logs-loading">' +
          '<span class="spinner is-active" style="float:none;"></span> ' +
          "Loading…</td></tr>"
        );
        $("#dit-ts-logs-empty").addClass("hidden");

        $.ajax({
          url: ditTsAdmin.ajaxUrl,
          type: "GET",
          data: {
            action:   "dit_ts_get_log_page",
            nonce:    ditTsAdmin.nonce,
            file:     currentFile,
            page_num: currentPage,
            per_page: perPage,
            level:    currentLevel,
            search:   currentSearch
          },
          success: function (resp) {
            isLoading = false;
            if (!resp.success) {
              $tbody.html(
                '<tr><td colspan="5" class="notice notice-error inline" style="float:none;margin:0;">' +
                self.escapeHtml(resp.data) + "</td></tr>"
              );
              return;
            }

            var d         = resp.data;
            var entries   = d.entries;
            var totalLines = d.total_lines;
            var totalPages = d.total_pages;

            var statsText;
            if (d.filtered) {
                statsText = entries.length + " / " + totalLines + " entries (filtered)";
            } else {
                statsText = entries.length + " / " + totalLines + " entries";
            }
            $("#dit-ts-log-stats").text(statsText);
            $("#dit-ts-total-pages").text(totalPages);
            $("#dit-ts-page-input").val(currentPage);

            // Toggle pagination buttons
            var isFirst = currentPage <= 1;
            var isLast  = currentPage >= totalPages;
            $("#dit-ts-logs-pagination .first-page").prop("disabled", isFirst);
            $("#dit-ts-logs-pagination .prev-page").prop("disabled", isFirst);
            $("#dit-ts-logs-pagination .next-page").prop("disabled", isLast);
            $("#dit-ts-logs-pagination .last-page").prop("disabled", isLast);

            if (!entries.length) {
              $tbody.empty();
              $("#dit-ts-logs-empty").removeClass("hidden");
              return;
            }

            var html = "";
            $.each(entries, function (i, e) {
              var lvl   = e.level ? e.level.toLowerCase() : "unknown";
              var cls   = lvl === "error" ? "failure" : (lvl === "warning" ? "warning" : "success");
              var ctxId = "log-ctx-" + (d.page - 1) * perPage + "-" + i;

              html += "<tr>";
              html += '<td class="column-linenum" style="color:#888;font-size:11px;">' + e.line_num + "</td>";
              html += '<td class="column-date" style="font-size:12px;">' + self.escapeHtml(e.time) + "</td>";
              html += '<td class="column-level"><span class="dit-ts-badge dit-ts-badge-' + cls + '">' + self.escapeHtml(e.level) + "</span></td>";
              html += '<td class="column-message">' + self.escapeHtml(e.message);

              if (e.context) {
                html += '<div id="' + ctxId + '" class="log-context hidden" style="margin-top:5px;">';
                html += '<pre style="background:#f0f0f1;padding:10px;overflow:auto;max-height:200px;font-size:11px;">' +
                  self.escapeHtml(JSON.stringify(e.context, null, 2)) + "</pre></div>";
              }

              html += "</td>";
              html += "<td>";
              if (e.context) {
                html += '<button type="button" class="button button-small toggle-context" data-target="' + ctxId + '">View JSON</button>';
              } else {
                html += '<span style="color:#aaa;">—</span>';
              }
              html += "</td>";
              html += "</tr>";
            });

            $tbody.html(html);
          },
          error: function () {
            isLoading = false;
            $tbody.html(
              '<tr><td colspan="5" class="notice notice-error inline" style="float:none;margin:0;">' +
              "Failed to load log entries.</td></tr>"
            );
          }
        });
      }

      // File selection
      $(document).on("click", ".dit-ts-log-file-item", function (e) {
        e.preventDefault();
        var $item = $(this);
        if ($item.hasClass("active")) return;
        $(".dit-ts-log-file-item").removeClass("active");
        $item.addClass("active");
        currentFile = $item.data("file");
        currentPage = 1;
        $("#dit-ts-current-file-name").text(currentFile);
        $("#dit-ts-download-log").attr(
          "href",
          ajaxurl + "?action=dit_ts_download_log_file&nonce=" + ditTsAdmin.nonce + "&file=" + encodeURIComponent(currentFile)
        );
        self.loadToggledContexts = {};
        loadLogs();
      });

      // Level filter
      $("#dit-ts-level-filter").on("change", function () {
        currentLevel = $(this).val();
        currentPage = 1;
        loadLogs();
      });

      // Search (debounced 300ms)
      var searchTimer = null;
      $("#dit-ts-log-search").on("input", function () {
        clearTimeout(searchTimer);
        searchTimer = setTimeout(function () {
          currentSearch = $("#dit-ts-log-search").val().trim();
          currentPage = 1;
          loadLogs();
        }, 300);
      });

      // Per-page
      $("#dit-ts-per-page-select").on("change", function () {
        perPage = parseInt($(this).val(), 10);
        currentPage = 1;
        loadLogs();
      });

      // Pagination buttons
      $("#dit-ts-logs-pagination .first-page").on("click", function () {
        if (currentPage > 1) { currentPage = 1; loadLogs(); }
      });
      $("#dit-ts-logs-pagination .prev-page").on("click", function () {
        if (currentPage > 1) { currentPage--; loadLogs(); }
      });
      $("#dit-ts-logs-pagination .next-page").on("click", function () {
        currentPage++; loadLogs();
      });
      $("#dit-ts-logs-pagination .last-page").on("click", function () {
        var totalPages = parseInt($("#dit-ts-total-pages").text(), 10) || 1;
        if (currentPage < totalPages) { currentPage = totalPages; loadLogs(); }
      });

      // Manual page input
      $("#dit-ts-page-input").on("keydown", function (e) {
        if (e.which === 13) {
          var v = parseInt($(this).val(), 10);
          var totalPages = parseInt($("#dit-ts-total-pages").text(), 10) || 1;
          v = Math.max(1, Math.min(v, totalPages));
          if (v !== currentPage) {
            currentPage = v;
            loadLogs();
          }
        }
      });

      // Toggle context JSON (delegated)
      $(document).on("click", ".toggle-context", function () {
        var target = $(this).data("target");
        $("#" + target).toggleClass("hidden");
        $(this).text(
          $(this).text() === "View JSON" ? "Hide JSON" : "View JSON"
        );
      });

      // Clear all logs
      $("#dit-ts-clear-logs").on("click", function () {
        if (!confirm("Delete ALL log files? This cannot be undone.")) return;
        var $btn = $(this);
        $btn.prop("disabled", true);
        $.ajax({
          url: ditTsAdmin.ajaxUrl,
          type: "POST",
          data: { action: "dit_ts_clear_logs", nonce: ditTsAdmin.nonce },
          success: function (resp) {
            if (resp.success) {
              location.reload();
            } else {
              alert("Failed: " + (resp.data && resp.data.message ? resp.data.message : "Unknown error"));
              $btn.prop("disabled", false);
            }
          },
          error: function () {
            alert("Failed to clear logs.");
            $btn.prop("disabled", false);
          }
        });
      });

      // Clear archived logs
      $("#dit-ts-clear-archived").on("click", function () {
        if (!confirm("Delete all archived logs (keep today)?")) return;
        var $btn = $(this);
        $btn.prop("disabled", true);
        $.ajax({
          url: ditTsAdmin.ajaxUrl,
          type: "POST",
          data: { action: "dit_ts_clear_archived_logs", nonce: ditTsAdmin.nonce },
          success: function (resp) {
            if (resp.success) {
              location.reload();
            } else {
              alert("Failed: " + (resp.data && resp.data.message ? resp.data.message : "Unknown error"));
              $btn.prop("disabled", false);
            }
          },
          error: function () {
            alert("Failed to clear archived logs.");
            $btn.prop("disabled", false);
          }
        });
      });

      // Set initial download link
      if (currentFile) {
        $("#dit-ts-download-log").attr(
          "href",
          ajaxurl + "?action=dit_ts_download_log_file&nonce=" + ditTsAdmin.nonce + "&file=" + encodeURIComponent(currentFile)
        );
      }

      // Initial load
      loadLogs();
    }
  };

  $(document).ready(function () {
    DitTsAdmin.init();
    DitTsAdmin.initLogsPage();
  });
})(jQuery);
