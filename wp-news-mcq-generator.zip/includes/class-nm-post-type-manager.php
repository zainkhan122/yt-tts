<?php

/**
 * Post Type Manager
 *
 * @package WP_News_MCQ_Generator
 * @version 1.2
 *
 * @MODIFIED: Added the save_mcq_post_unified() method, moved from helpers.php.
 */

if (! defined('ABSPATH')) {
	exit;
}

class NM_Post_Type_Manager
{


	/**
	 * Initialize the class and register hooks.
	 */
	public static function init()
	{
		// Register the post type and taxonomy on WordPress init
		add_action('init', array(self::class, 'register_post_types'));
		// ✅ NEW: Register Tags Taxonomy
		add_action('init', array(self::class, 'register_tag_taxonomy'));

		// ✅ NEW: Hook global ordering
		add_action('pre_get_posts', array(self::class, 'apply_global_mcq_ordering'));

		// Register the admin menu links for this CPT
		add_action('admin_menu', array(self::class, 'register_cpt_submenus'), 11);

		// ✅ Include MCQ post type in RSS feeds
		add_filter('pre_get_posts', array(self::class, 'include_mcq_in_feeds'));
	}

	/**
	 * Register admin submenus for All MCQs, Add New, and Topics
	 */
	public static function register_cpt_submenus()
	{
		// 1. All MCQs
		add_submenu_page(
			'nm_mcq_generator', // Parent Slug
			'All MCQs',
			'📝 All MCQs',
			'edit_posts',
			'edit.php?post_type=mcq'
		);

		// 2. Add New MCQ
		add_submenu_page(
			'nm_mcq_generator',
			'Add New MCQ',
			'➕ Add New MCQ',
			'edit_posts',
			'post-new.php?post_type=mcq'
		);

		// 3. Topics
		add_submenu_page(
			'nm_mcq_generator',
			'Topics',
			'🏷️ Topics',
			'manage_categories',
			'edit-tags.php?taxonomy=topic&post_type=mcq'
		);
		// 4. Exam Tags
		add_submenu_page(
			'nm_mcq_generator',
			'Exam Tags',
			'🎯 Exam Tags',
			'manage_categories',
			'edit-tags.php?taxonomy=nm_exam&post_type=mcq'
		);
	}

	/**
	 * Register all custom post types and taxonomies.
	 */
	public static function register_post_types()
	{
		self::register_mcq_post_type();
		self::register_topic_taxonomy();
		self::register_exam_taxonomy();
	}

	/**
	 * Registers the 'mcq' Custom Post Type
	 */
	private static function register_mcq_post_type()
	{
		$labels = array(
			'name'                  => _x('MCQs', 'Post type general name', 'wp-news-mcq-generator'),
			'singular_name'         => _x('MCQ', 'Post type singular name', 'wp-news-mcq-generator'),
			'menu_name'             => _x('MCQs', 'Admin Menu text', 'wp-news-mcq-generator'),
			'name_admin_bar'        => _x('MCQ', 'Add New on Toolbar', 'wp-news-mcq-generator'),
			'add_new'               => __('Add New', 'wp-news-mcq-generator'),
			'add_new_item'          => __('Add New MCQ', 'wp-news-mcq-generator'),
			'new_item'              => __('New MCQ', 'wp-news-mcq-generator'),
			'edit_item'             => __('Edit MCQ', 'wp-news-mcq-generator'),
			'view_item'             => __('View MCQ', 'wp-news-mcq-generator'),
			'all_items'             => __('All MCQs', 'wp-news-mcq-generator'),
			'search_items'          => __('Search MCQs', 'wp-news-mcq-generator'),
			'parent_item_colon'     => __('Parent MCQs:', 'wp-news-mcq-generator'),
			'not_found'             => __('No MCQs found.', 'wp-news-mcq-generator'),
			'not_found_in_trash'    => __('No MCQs found in Trash.', 'wp-news-mcq-generator'),
			'archives'              => _x('MCQ archives', 'The post type archive label', 'wp-news-mcq-generator'),
			'items_list_navigation' => _x('MCQs list navigation', 'Screen reader text', 'wp-news-mcq-generator'),
			'items_list'            => _x('MCQs list', 'Screen reader text', 'wp-news-mcq-generator'),
		);

		$args = array(
			'labels'             => $labels,
			'public'             => true,
			'publicly_queryable' => true,
			'show_ui'            => true,
			'show_in_menu'       => false,
			'query_var'          => true,
			'rewrite'            => array('slug' => 'mcq'),
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => false,
			'menu_position'      => 20,
			'menu_icon'          => 'dashicons-forms',
			'supports'           => array('title', 'editor', 'author', 'revisions', 'comments', 'publicize', 'thumbnail'),
			'show_in_rest'       => true,
		);

		register_post_type('mcq', $args);
	}

	/**
	 * Registers the 'topic' Custom Taxonomy
	 */
	private static function register_topic_taxonomy()
	{
		$labels = array(
			'name'              => _x('Topics', 'taxonomy general name', 'wp-news-mcq-generator'),
			'singular_name'     => _x('Topic', 'taxonomy singular name', 'wp-news-mcq-generator'),
			'search_items'      => __('Search Topics', 'wp-news-mcq-generator'),
			'all_items'         => __('All Topics', 'wp-news-mcq-generator'),
			'parent_item'       => __('Parent Topic', 'wp-news-mcq-generator'),
			'parent_item_colon' => __('Parent Topic:', 'wp-news-mcq-generator'),
			'edit_item'         => __('Edit Topic', 'wp-news-mcq-generator'),
			'update_item'       => __('Update Topic', 'wp-news-mcq-generator'),
			'add_new_item'      => __('Add New Topic', 'wp-news-mcq-generator'),
			'new_item_name'     => __('New Topic Name', 'wp-news-mcq-generator'),
			'menu_name'         => __('Topics', 'wp-news-mcq-generator'),
		);

		$args = array(
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'topic'),
			'show_in_rest'      => true,
		);

		register_taxonomy('topic', array('mcq', 'post'), $args);
	}
	/**
	 * Registers the 'nm_exam' Custom Taxonomy (Non-hierarchical like Tags)
	 */
	private static function register_exam_taxonomy()
	{
		$labels = array(
			'name'          => _x('Exams', 'taxonomy general name', 'wp-news-mcq-generator'),
			'singular_name' => _x('Exam', 'taxonomy singular name', 'wp-news-mcq-generator'),
			'search_items'  => __('Search Exams', 'wp-news-mcq-generator'),
			'all_items'     => __('All Exams', 'wp-news-mcq-generator'),
			'edit_item'     => __('Edit Exam', 'wp-news-mcq-generator'),
			'update_item'   => __('Update Exam', 'wp-news-mcq-generator'),
			'add_new_item'  => __('Add New Exam', 'wp-news-mcq-generator'),
			'new_item_name' => __('New Exam Name', 'wp-news-mcq-generator'),
			'menu_name'     => __('Exams', 'wp-news-mcq-generator'),
		);

		$args = array(
			'hierarchical'      => false, // Tag-like behavior (e.g. CSS, PMS, NTS)
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'query_var'         => true,
			'rewrite'           => array('slug' => 'exam'),
			'show_in_rest'      => true,
		);

		// @MODIFIED 9.4.0: Registered for 'post' too so evergreen pillar/roundup articles
		// can carry exam tags (e.g. CSS, PMS, NTS) and appear under /exam/<slug>/.
		register_taxonomy('nm_exam', array('mcq', 'post'), $args);
	}

	/**
	 * Register 'mcq_tag' taxonomy (Non-hierarchical, like tags).
	 */
	public static function register_tag_taxonomy()
	{
		$labels = array(
			'name'                       => _x('MCQ Tags', 'taxonomy general name', 'wp-news-mcq-generator'),
			'singular_name'              => _x('MCQ Tag', 'taxonomy singular name', 'wp-news-mcq-generator'),
			'search_items'               => __('Search Tags', 'wp-news-mcq-generator'),
			'popular_items'              => __('Popular Tags', 'wp-news-mcq-generator'),
			'all_items'                  => __('All Tags', 'wp-news-mcq-generator'),
			'parent_item'                => null,
			'parent_item_colon'          => null,
			'edit_item'                  => __('Edit Tag', 'wp-news-mcq-generator'),
			'update_item'                => __('Update Tag', 'wp-news-mcq-generator'),
			'add_new_item'               => __('Add New Tag', 'wp-news-mcq-generator'),
			'new_item_name'              => __('New Tag Name', 'wp-news-mcq-generator'),
			'separate_items_with_commas' => __('Separate tags with commas', 'wp-news-mcq-generator'),
			'add_or_remove_items'        => __('Add or remove tags', 'wp-news-mcq-generator'),
			'choose_from_most_used'      => __('Choose from the most used tags', 'wp-news-mcq-generator'),
			'not_found'                  => __('No tags found.', 'wp-news-mcq-generator'),
			'menu_name'                  => __('Tags', 'wp-news-mcq-generator'),
		);

		$args = array(
			'hierarchical'          => false,
			'labels'                => $labels,
			'show_ui'               => true,
			'show_admin_column'     => true,
			'update_count_callback' => '_update_post_term_count',
			'query_var'             => true,
			'rewrite'               => array('slug' => 'tag'),
			'show_in_rest'          => true,
		);

		register_taxonomy('mcq_tag', 'mcq', $args);
	}

	/**
	 * Include MCQ post type in RSS feeds
	 *
	 * By default, WordPress RSS feeds only include regular posts (post_type='post').
	 * This filter modifies feed queries to also include MCQs for Zapier/Buffer integration.
	 *
	 * @param WP_Query $query WordPress query object
	 * @return WP_Query Modified query object
	 */
	public static function include_mcq_in_feeds($query)
	{
		// Only modify the main feed query, not admin or other queries
		if ($query->is_feed() && $query->is_main_query() && ! is_admin()) {
			// Include both regular posts and MCQs in feeds
			$query->set('post_type', array('post', 'mcq'));
		}
		return $query;
	}

	/**
	 * ✅ NEW: Unified function to save any new MCQ post
	 * (Copied from helpers.php)
	 */
	public static function save_mcq_post_unified(array $mcq_data, array $args = array())
	{
		// Allow certain callers (e.g. CSV importer) to bypass strict content validation
		$skip_validation = ! empty($args['skip_validation']);

		// --- ✅ NEW v27: Server-Side Content Validation ---
		// Validate MCQ content BEFORE saving to database
		// This enforces character limits even when AI ignores prompt instructions
		if (! $skip_validation && class_exists('NM_Validator')) {
			$validation_result = NM_Validator::validate_mcq_content($mcq_data);

			if (! $validation_result['valid']) {
				// Log validation failure with detailed error info
				$error_summary    = implode(' | ', $validation_result['errors']);
				$question_preview = isset($mcq_data['question'])
					? mb_substr($mcq_data['question'], 0, 80) . '...'
					: '[no question]';

				sprintf(
					'[NM MCQ Validator] REJECTED MCQ - %s | Question: "%s"',
					$error_summary,
					$question_preview
				);

				// Optional: Integrate with generation logger if available
				if (class_exists('NM_Generation_Logger')) {
					NM_Generation_Logger::nm_log_activity(
						'MCQ Validation Failed: ' . $error_summary,
						'error',
						array(
							'errors'         => $validation_result['errors'],
							'question'       => $question_preview,
							'source_context' => $args['topic'] ?? 'unknown',
						)
					);
				}

				return new WP_Error('mcq_validation_failed', $error_summary); // Reject the MCQ
			}

			// Log warnings (if any) but still proceed with save
			if (! empty($validation_result['warnings'])) {
				$warning_summary = implode(' | ', $validation_result['warnings']);
				sprintf(
					'[NM MCQ Validator] WARNINGS - %s | Question: "%s"',
					$warning_summary,
					mb_substr($mcq_data['question'], 0, 60)
				);
			}
		}

		// --- Original Validation (backwards compatibility) ---
		if (empty($mcq_data['question']) || empty($mcq_data['options']) || empty($mcq_data['answer'])) {

			return new WP_Error('mcq_missing_data', 'Missing required MCQ data (question, options, or answer).');
		}

		// Determine Post Status
		$post_status       = 'publish'; // Default
		$is_smart_schedule = false;

		if (isset($args['post_status'])) {
			if ($args['post_status'] === 'smart_schedule') {
				$post_status       = 'draft';
				$is_smart_schedule = true;
			} elseif (in_array($args['post_status'], array('publish', 'draft', 'pending', 'private'))) {
				$post_status = $args['post_status'];
			}
		}

		// --- ✅ MODIFIED v7.3.7b: Fix "Pending" Status on Cron ---
		// Cron runs as User 0. User 0 cannot publish. We must assign an Admin author.
		$post_author = get_current_user_id();
		if (0 === $post_author) {
			// Find the first admin.
			$admins = get_users(
				array(
					'role'   => 'administrator',
					'number' => 1,
					'fields' => 'ID',
				)
			);
			if (! empty($admins)) {
				$post_author = $admins[0];
			}
		}

		// --- ✅ NEW v9.2.0: Random named-author assignment for E-E-A-T ---
		// When a named author list is configured (or Author-role users exist), assign a
		// random one so MCQs/articles aren't all attributed to a single admin/brand.
		// The brand name is used only as a last-resort fallback.
		if (class_exists('NM_News_Article_Generator') && method_exists('NM_News_Article_Generator', 'pick_random_author')) {
			// Only reassign if the caller didn't explicitly set an author_name.
			if (empty($mcq_data['author_name'])) {
				$picked = NM_News_Article_Generator::pick_random_author();
				if (! empty($picked['user_id'])) {
					$post_author = (int) $picked['user_id'];
				}
				if (! empty($picked['display_name'])) {
					$mcq_data['author_name'] = $picked['display_name'];
				}
			}
		}

		// Build base post args
		$post_args = array(
			'post_title'   => wp_strip_all_tags($mcq_data['question']),
			'post_content' => '', // Content is empty for MCQ post type
			'post_status'  => $post_status,
			'post_type'    => 'mcq',
			'post_author'  => $post_author,
		);

		// Preserve original publish date if provided (e.g. from CSV export)
		if (! empty($mcq_data['post_date'])) {
			$timestamp = strtotime($mcq_data['post_date']);

			if ($timestamp) {
				// Normalize to MySQL datetime and set both local and GMT dates
				$post_args['post_date']     = date('Y-m-d H:i:s', $timestamp);
				$post_args['post_date_gmt'] = get_gmt_from_date($post_args['post_date']);
			}
		}

		$post_id = wp_insert_post($post_args, true);

		if ($is_smart_schedule && $post_id && ! is_wp_error($post_id)) {
			update_post_meta($post_id, '_nm_ready_for_publish', 'yes');
			// Also add to the dedicated queue option for redundancy/performance if needed later
			// For now, the meta key is the source of truth for the scheduler query.
		}

		if (is_wp_error($post_id)) {
			return $post_id;
		}
		if (empty($post_id)) {
			return new WP_Error('mcq_insert_failed', 'wp_insert_post returned 0');
		}

        // --- Save Core MCQ Data ---
        update_post_meta($post_id, 'mcq_question', wp_strip_all_tags($mcq_data['question']));

        $normalized_options = array();
        if (is_array($mcq_data['options'])) {
            foreach ($mcq_data['options'] as $key => $value) {
                $normalized_options[strtoupper($key)] = $value;
            }
        }
        $normalized_answer = strtoupper($mcq_data['answer']);

        if (!isset($normalized_options[$normalized_answer])) {
            $answer_keys = array_keys($normalized_options);
            if (!empty($answer_keys)) {
                $first_key = reset($answer_keys);
                $normalized_answer = $first_key;
            }
        }

        update_post_meta($post_id, 'mcq_options', $normalized_options);
        update_post_meta($post_id, 'mcq_answer', $normalized_answer);
        update_post_meta($post_id, 'mcq_explanation', $mcq_data['explanation'] ?? '');

		// --- Save Exam Metadata (Difficulty & Cognitive Level) ---
		if (isset($mcq_data['difficulty']) && is_string($mcq_data['difficulty']) && $mcq_data['difficulty'] !== '') {
			update_post_meta($post_id, 'mcq_difficulty', sanitize_key($mcq_data['difficulty']));
		}
		if (isset($mcq_data['cognitive_level']) && is_string($mcq_data['cognitive_level']) && $mcq_data['cognitive_level'] !== '') {
			update_post_meta($post_id, 'mcq_cognitive_level', sanitize_key($mcq_data['cognitive_level']));
		}

		// --- ✅ NEW v7.3.7: Save E-A-T Metadata ---
		if (! empty($mcq_data['source_name'])) {
			update_post_meta($post_id, 'mcq_source_name', sanitize_text_field($mcq_data['source_name']));
		}
		if (! empty($mcq_data['source_url'])) {
			update_post_meta($post_id, 'mcq_source_url', esc_url_raw($mcq_data['source_url']));
		}
		if (! empty($mcq_data['author_name'])) {
			update_post_meta($post_id, 'mcq_author_name', sanitize_text_field($mcq_data['author_name']));
		} else {
			// ✅ NEW: Dynamically resolve author name for E-E-A-T
			$user = get_userdata($post_author);
			$display_name = $user ? $user->display_name : get_bloginfo('name');
			update_post_meta($post_id, 'mcq_author_name', sanitize_text_field($display_name));
		}
		if (! empty($mcq_data['fact_checked'])) {
			update_post_meta($post_id, 'mcq_fact_checked', sanitize_key($mcq_data['fact_checked']));
		}

		// --- Assign Topics ---
		$term_ids       = array();
		$parent_term_id = 0;

		// 1. Create/Get Parent Topic
		if (! empty($args['topic'])) {
			$parent_term = term_exists($args['topic'], 'topic');
			if (! $parent_term) {
				$parent_term = wp_insert_term($args['topic'], 'topic');
			}
			if (! is_wp_error($parent_term)) {
				$parent_term_id = (int) $parent_term['term_id'];
				$term_ids[]     = $parent_term_id;
			}
		}

		// 2. Create/Get Sub-Topic
		if (! empty($args['subtopic'])) {
			$child_term = term_exists($args['subtopic'], 'topic', $parent_term_id);
			if (! $child_term) {
				$child_term = wp_insert_term($args['subtopic'], 'topic', array('parent' => $parent_term_id));
			}
			if (! is_wp_error($child_term)) {
				$term_ids[] = (int) $child_term['term_id'];
			}
		}

		if (! empty($term_ids)) {
			wp_set_object_terms($post_id, array_unique($term_ids), 'topic');
		}

		// --- ✅ NEW: Assign Exam Tags (The Matrix Strategy) ---
		// Prioritize tags from AI ($mcq_data), fallback to Manual Args ($args)
		$exam_tags_input = $mcq_data['exam_tags'] ?? ($args['exam_tags'] ?? array());

		if (! empty($exam_tags_input)) {
			$exam_term_ids = array();
			// Handle both array and comma-separated string inputs
			$exams = is_array($exam_tags_input) ? $exam_tags_input : explode(',', $exam_tags_input);

			foreach ($exams as $exam_name) {
				$exam_name = trim($exam_name);
				if (empty($exam_name)) {
					continue;
				}

				$exam_term = term_exists($exam_name, 'nm_exam');
				if (! $exam_term) {
					$exam_term = wp_insert_term($exam_name, 'nm_exam');
				}

				if (! is_wp_error($exam_term)) {
					$exam_term_ids[] = (int) $exam_term['term_id'];
				}
			}

			if (! empty($exam_term_ids)) {
				wp_set_object_terms($post_id, array_unique($exam_term_ids), 'nm_exam');
			}
		}


		// ✅ MODIFIED: Added fallback logic to use parent topic/subtopic if tags are empty.
		// ✅ NEW: Set MCQ Tags (if provided from AI or manual input)
		$tags_input = $mcq_data['tags'] ?? ($args['tags'] ?? array());
		if (empty($tags_input)) {
			// Fallback: Use topic and subtopic as tags if no labels provided
			$tags_input = array();
			if (! empty($args['topic'])) {
				$tags_input[] = $args['topic'];
			}
			if (! empty($args['subtopic'])) {
				$tags_input[] = $args['subtopic'];
			}
		}

		if (! empty($tags_input)) {
			// Ensure it's an array
			$tags = is_array($tags_input) ? $tags_input : explode(',', $tags_input);
			// Santize
			$tags = array_map('sanitize_text_field', $tags);
			wp_set_object_terms($post_id, $tags, 'mcq_tag');
		}

		// --- Generate and Store Embedding ---
		// Prefer explicit API key from caller; otherwise use central NM_API_Client getter
		$api_key_for_embedding = $args['api_key'] ?? (
			class_exists('NM_API_Client') ? NM_API_Client::get_gemini_api_key() : ''
		);

		if (! empty($api_key_for_embedding) && class_exists('NM_API_Client') && class_exists('NM_Embedding_Database')) {

			// Use the shared API client to generate the embedding
			$client    = NM_API_Client::get_instance();
			$embedding = $client ? $client->get_embedding($mcq_data['question'], $api_key_for_embedding) : null;

        if ($embedding) {
                (new NM_Embedding_Database())->store_embedding($post_id, $mcq_data['question'], $embedding);
            }
        }

        if (class_exists('NM_Social_Image_Generator')) {
            NM_Social_Image_Generator::generate_after_save($post_id);
        }

        // @NEW 9.2.0: Auto-sync this new MCQ into the mcq-video-studio bank so the
        // video pipeline (Shorts) can use it with content_hash dedup. This fires
        // only for newly created MCQs, replacing the old manual migration step.
        // The mcq-vs plugin exposes a public helper if it is active.
        if (function_exists('mcqvs_sync_mcq_from_source')) {
            mcqvs_sync_mcq_from_source($post_id);
        } elseif (did_action('mcqvs_studio_loaded')) {
            // Fallback: if mcq-vs is loaded but the helper isn't defined (older build),
            // defer to a save_post_mcq hook in mcq-vs (registered separately).
            do_action('mcqvs_sync_mcq_created', $post_id, $mcq_data);
        }

        return $post_id;
	}
	/**
	 * Apply global display order to MCQ archives.
	 */
	public static function apply_global_mcq_ordering($query)
	{
		if (is_admin() || ! $query->is_main_query()) {
			return;
		}

		// @MODIFIED: Include is_home() and is_front_page() to fix homepage ordering
		if (
			(is_home() && $query->is_main_query()) ||
			(is_front_page() && $query->is_main_query()) ||
			is_post_type_archive('mcq') ||
			is_tax('topic') ||
			is_tax('nm_exam') ||
			is_tax('mcq_tag')
		) {
			// @MODIFIED: Changed fallback from 'rand' to 'date_desc' as SEO guardrail
			$global_order = get_option('nm_mcq_display_order', 'date_desc');

			if ($global_order === 'rand') {
				$query->set('orderby', 'rand');
			} elseif ($global_order === 'date_desc') {
				$query->set('orderby', 'date');
				$query->set('order', 'DESC');
			} elseif ($global_order === 'date_asc') {
				$query->set('orderby', 'date');
				$query->set('order', 'ASC');
			}
		}
	}
}