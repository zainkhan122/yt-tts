<?php
namespace AiSocialCollage\Services\ImageAI;

use AiSocialCollage\Config;
use AiSocialCollage\Contracts\ImageAIProviderInterface;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PlaceholderProvider implements ImageAIProviderInterface {

	public function generate_image( $prompt, $width = 1080, $height = 1350 ) {
		$brand = Config::get_brand_settings();
		$brand_name = $brand['brand_name'] ?: get_bloginfo( 'name' );
		$primary = $brand['primary_color'] ?: Config::DEFAULT_BRAND_PRIMARY_COLOR;
		$accent = $brand['accent_color'] ?: Config::DEFAULT_BRAND_ACCENT_COLOR;

		$headline = mb_substr( $prompt, 0, 60 );

		$svg = '<svg xmlns="http://www.w3.org/2000/svg" width="' . (int) $width . '" height="' . (int) $height . '">'
			. '<rect width="100%" height="100%" fill="' . esc_attr( $primary ) . '"/>'
			. '<rect x="40" y="' . ( (int) $height - 200 ) . '" width="200" height="6" fill="' . esc_attr( $accent ) . '" rx="3"/>'
			. '<text x="50%" y="45%" font-family="sans-serif" font-size="52" fill="#ffffff" text-anchor="middle" font-weight="700">' . esc_html( $headline ) . '</text>'
			. '<text x="50%" y="55%" font-family="sans-serif" font-size="28" fill="rgba(255,255,255,0.6)" text-anchor="middle">' . esc_html( $brand_name ) . '</text>'
			. '</svg>';

		$temp_dir = AI_SOCIAL_COLLAGE_PATH . 'assets/temp';
		if ( ! is_dir( $temp_dir ) ) {
			wp_mkdir_p( $temp_dir );
		}

		$svg_path = $temp_dir . '/placeholder_' . uniqid() . '.svg';
		$png_path = $temp_dir . '/ai_gen_' . uniqid() . '.png';

		file_put_contents( $svg_path, $svg );

		if ( class_exists( 'Imagick' ) ) {
			try {
				$imagick = new \Imagick();
				$imagick->setBackgroundColor( new \ImagickPixel( 'transparent' ) );
				$imagick->readImage( $svg_path );
				$imagick->setImageFormat( 'png' );
				$imagick->writeImage( $png_path );
				$imagick->clear();
				$imagick->destroy();
				@unlink( $svg_path );
				return $png_path;
			} catch ( \Exception $e ) {
				Logger::warning( 'placeholder_imagick_failed', null, [ 'error' => $e->getMessage() ] );
			}
		}

		@unlink( $svg_path );
		file_put_contents( $png_path, $this->generate_gd_placeholder( $width, $height, $headline, $brand_name, $primary, $accent ) );
		return $png_path;
	}

	private function generate_gd_placeholder( $width, $height, $headline, $brand_name, $primary, $accent ) {
		if ( ! function_exists( 'imagecreate' ) ) {
			return $this->generate_minimal_png( $width, $height, $primary );
		}

		$img = imagecreate( $width, $height );
		$bg = $this->hex_to_gd( $img, $primary );
		imagefill( $img, 0, 0, $bg );

		$text_color = imagecolorallocate( $img, 255, 255, 255 );
		$font_size = 36;
		$lines = $this->wrap_text( $headline, 22 );
		$y = (int) ( $height * 0.4 );
		foreach ( $lines as $line ) {
			imagestring( $img, 5, 50, $y, $line, $text_color );
			$y += 50;
		}

		$sub_color = imagecolorallocate( $img, 153, 153, 153 );
		imagestring( $img, 4, 50, (int) ( $height * 0.55 ), $brand_name, $sub_color );

		ob_start();
		imagepng( $img );
		$data = ob_get_clean();
		imagedestroy( $img );
		return $data;
	}

	private function generate_minimal_png( $width, $height, $primary ) {
		$r = hexdec( substr( $primary, 1, 2 ) );
		$g = hexdec( substr( $primary, 3, 2 ) );
		$b = hexdec( substr( $primary, 5, 2 ) );

		$img = imagecreatetruecolor( $width, $height );
		$bg = imagecolorallocate( $img, $r, $g, $b );
		imagefill( $img, 0, 0, $bg );

		ob_start();
		imagepng( $img );
		$data = ob_get_clean();
		imagedestroy( $img );
		return $data;
	}

	private function hex_to_gd( $img, $hex ) {
		$r = hexdec( substr( $hex, 1, 2 ) );
		$g = hexdec( substr( $hex, 3, 2 ) );
		$b = hexdec( substr( $hex, 5, 2 ) );
		return imagecolorallocate( $img, $r, $g, $b );
	}

	private function wrap_text( $text, $max_chars ) {
		$words = explode( ' ', $text );
		$lines = [];
		$current = '';
		foreach ( $words as $word ) {
			$test = $current ? $current . ' ' . $word : $word;
			if ( strlen( $test ) > $max_chars && $current ) {
				$lines[] = $current;
				$current = $word;
			} else {
				$current = $test;
			}
		}
		if ( $current ) {
			$lines[] = $current;
		}
		return $lines;
	}

	public function get_provider_name() {
		return Config::PROVIDER_IMAGE_PLACEHOLDER;
	}

	public function get_model_name() {
		return 'placeholder-svg';
	}
}
