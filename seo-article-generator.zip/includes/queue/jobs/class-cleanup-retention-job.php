<?php

/**
 * Cleanup Retention Job
 *
 * @package SEO_Article_Generator
 * @MODIFIED 2026-03-02 v2.19.0: Industrial Queue Architecture
 * @MODIFIED 2026-05-05: SSOT Unification — safety-net only, never deletes posts.
 *   AS single-action path is the sole deletion authority. This job only:
 *   1. NULLs dangling draft_post_id references (post already deleted or not owned)
 *   2. Re-schedules missing AS deletion actions for drafts that should have been deleted
 *      but whose AS actions were lost (deactivation, failure-path gap, etc.)
 *   Uses completed_at (not discovered_at) as the authoritative age reference.
 */

namespace SEO_Article_Generator\Queue\Jobs;

use SEO_Article_Generator\Queue\Abstract_Job;
use SEO_Article_Generator\Logger;

// Prevent direct access
if (! defined('ABSPATH')) {
	exit();
}

/**
 * Safety-net cleanup for draft_post_id references in the discovery table.
 * Does NOT delete posts — that is the sole responsibility of the
 * seo_gen_delete_draft_post AS action (Discovery_Engine::delete_draft_post).
 */
class Cleanup_Retention_Job extends Abstract_Job
{
	/**
	 * Execute retention cleanup (safety-net only).
	 *
	 * @return bool True on success.
	 */
	public function handle()
	{
		$logger = new Logger();

		global $wpdb;

		$retention_days = (int) \get_option(
			\SEO_Article_Generator\Option_Registry::DRAFT_RETENTION_DAYS,
			\SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::DRAFT_RETENTION_DAYS]
		);

		$table = \SEO_Article_Generator\Installer::table_discovery();
		$now_ts  = \SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts();

		$unlink_ids = array();
		$reschedule = array();

		$logger->info(sprintf(
			'Cleanup Retention Job started: retention_days=%d, cutoff_timestamp=%d',
			$retention_days,
			$retention_days > 0 ? ($now_ts - ($retention_days * DAY_IN_SECONDS)) : 0
		));

    // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name is safe (plugin-controlled constant)
    $rows = $wpdb->get_results(
        "SELECT id, draft_post_id, source_type, status, completed_at, job_id, heartbeat_at, discovered_at, scheduled_at
        FROM {$table}
        WHERE draft_post_id IS NOT NULL
        AND draft_post_id > 0"
    );

		if (empty($rows)) {
			return true;
		}

		$cutoff_ts = ($retention_days > 0)
			? ($now_ts - ($retention_days * DAY_IN_SECONDS))
			: 0;

		$terminal_statuses = array('done','skippedduplicate','skippednotnewer','failed','ignored','timeout');
		$eligible_draft_statuses = array('draft', 'auto-draft', 'pending', 'trash');

		foreach ($rows as $row) {
			$draft_id = (int) $row->draft_post_id;
			$row_id   = (int) $row->id;

			if ($draft_id <= 0) {
				continue;
			}

			$post = \get_post($draft_id);

			if (! $post) {
				$unlink_ids[] = $row_id;
				continue;
			}

			// STALE LOCK RECOVERY: Force-fail discovery items stuck in intermediate
			// non-terminal state for longer than the retention window, regardless of
			// heartbeat. This prevents draft pile-up when jobs crash without updating
			// status to a terminal value.
			//
			// FIX: Validate job progress before recovering locks. Do NOT recover
			// items whose associated job is still processing or has a recent heartbeat.
			if (! in_array($row->status, $terminal_statuses, true)) {
				$is_stale = false;

				$heartbeat_ts = ! empty($row->heartbeat_at) ? strtotime($row->heartbeat_at . ' UTC') : 0;
				$discovered_ts = strtotime($row->completed_at ? $row->completed_at . ' UTC' : ($row->discovered_at ? $row->discovered_at . ' UTC' : $post->post_date_gmt . ' UTC'));
				if (! $discovered_ts) {
					$discovered_ts = $now_ts;
				}

				// Check if the associated job is still alive before declaring stale
				if (! empty($row->job_id)) {
					$jobs_table = \SEO_Article_Generator\Installer::table_jobs();
					$job_row = $wpdb->get_row($wpdb->prepare(
						"SELECT status, heartbeat_at FROM {$jobs_table} WHERE id = %d LIMIT 1",
						(int) $row->job_id
					), ARRAY_A);

					if ($job_row) {
						$job_status = (string) ($job_row['status'] ?? '');
						$job_heartbeat = ! empty($job_row['heartbeat_at']) ? strtotime($job_row['heartbeat_at'] . ' UTC') : 0;

						// FIX: Detect deferred-finalization state — discovery row has a future
						// scheduled_at set by rearm_finalization(). The check-job from deferral
						// may have updated the job heartbeat, making the job appear active.
						// We must NOT skip these; they need stale-lock recovery to break the
						// deferral loop and re-schedule draft deletion.
						$is_deferred_finalization = (
							! in_array($row->status, $terminal_statuses, true)
							&& ! empty($row->scheduled_at)
							&& strtotime($row->scheduled_at . ' UTC') > $now_ts
						);

						// Job is still in active processing with recent heartbeat — do NOT recover
						// UNLESS the discovery is in a deferred-finalization state (scheduled_at in future)
						if (
							! $is_deferred_finalization
							&& in_array($job_status, array('processing', 'generating', 'validating'), true)
							&& $job_heartbeat > 0
							&& ($now_ts - $job_heartbeat) < (\SEO_Article_Generator\Jobs\Job_Handler::STALE_LEASE_SECONDS / 2)
						) {
							$this->logger->info(sprintf(
								'Cleanup retention: Skipping stale lock recovery for discovery %d — job %d is still active (status=%s, heartbeat=%ds ago).',
								$row_id, (int) $row->job_id, $job_status, $now_ts - $job_heartbeat
							));
							continue;
						}
					}
				}

				// No heartbeat update within retention window => stale (minimum 2 days to prevent instant fail if retention is 0)
				$stale_threshold = max(2 * DAY_IN_SECONDS, $retention_days * DAY_IN_SECONDS);
				if ($heartbeat_ts <= 0 || ($now_ts - $heartbeat_ts) > $stale_threshold) {
					if (($now_ts - $discovered_ts) > $stale_threshold) {
						$is_stale = true;
					}
				}

				// job_id points to a job that no longer exists => orphaned
				if (! $is_stale && ! empty($row->job_id)) {
					$job_exists = $wpdb->get_var($wpdb->prepare(
						"SELECT COUNT(*) FROM " . \SEO_Article_Generator\Installer::table_jobs() . " WHERE id = %d",
						(int) $row->job_id
					));
					if (! $job_exists) {
						$is_stale = true;
					}
				}

				if ($is_stale) {
					$wpdb->update(
						$table,
						array(
							'status' => 'failed',
							'error_message' => 'Stale lock recovered by cleanup retention job: heartbeat timeout / orphan job',
							'completed_at' => \SEO_Article_Generator\Utils\Plugin_Time::utc_mysql_now(),
							'job_id' => null,
							'queue_job_id' => null,
						),
						array('id' => $row_id),
						array('%s', '%s', '%s', '%d', '%d'),
						array('%d')
					);
					// Treat as terminal for the rest of this loop iteration
					$row->status = 'failed';
				}
			}

			$has_plugin_meta     = \get_post_meta($draft_id, '_seo_gen_hero_data', true);
			$has_wp_auto_processed = \get_post_meta($draft_id, 'seo_gen_processed', true);
			if (! $has_plugin_meta && ! $has_wp_auto_processed
				&& (!class_exists('\SEO_Article_Generator\Discovery\Post_Type_Classifier')
					|| \SEO_Article_Generator\Discovery\Post_Type_Classifier::classify($draft_id)
						!== \SEO_Article_Generator\Discovery\Post_Type_Classifier::TYPE_PLUGIN)) {
				// FIX: Schedule deletion before unlinking — the draft may be a WP-Auto orphan
				// whose seo_gen_processed meta was never written due to a failure path.
				$_draft_post = \get_post($draft_id);
				if ($_draft_post && in_array((string) $_draft_post->post_status, $eligible_draft_statuses, true)) {
					\SEO_Article_Generator\Discovery\Discovery_Engine::schedule_draft_deletion($draft_id, 0);
				}
				$unlink_ids[] = $row_id;
				continue;
			}

			$completed_ts = $row->completed_at ? strtotime($row->completed_at . ' UTC') : 0;
			$age_ts = ($completed_ts > 0) ? $completed_ts : strtotime($post->post_modified_gmt . ' UTC');
			if (! $age_ts) {
				$age_ts = strtotime($post->post_date_gmt . ' UTC');
			}

			if (! in_array($post->post_status, $eligible_draft_statuses, true)) {
				$unlink_ids[] = $row_id;
				continue;
			}

			if ($cutoff_ts > 0 && $age_ts >= $cutoff_ts) {
				continue;
			}

			$has_pending_action = \SEO_Article_Generator\Queue\AS_Registry::has_scheduled_action(
				\SEO_Article_Generator\Queue\AS_Registry::HOOK_DELETE_DRAFT,
				[$draft_id],
				\SEO_Article_Generator\Queue\AS_Registry::GROUP
			);

			if ($has_pending_action) {
				continue;
			}

			// No AS action is pending for a draft that has passed its retention window.
			// Re-schedule the deletion immediately. Do NOT unlink draft_post_id here — the reference
			// must survive until delete_draft_post() fires and NULLs it after actual deletion.
			$reschedule[] = $draft_id;
		}

		foreach ($reschedule as $draft_id) {
			\SEO_Article_Generator\Discovery\Discovery_Engine::schedule_draft_deletion($draft_id, 0);
			$logger->info(sprintf(
				'Cleanup Retention: Re-scheduled draft deletion for draft_id=%d (past %d-day retention window)',
				$draft_id, $retention_days
			));
		}

		if (! empty($unlink_ids)) {
			$unlink_ids = array_values(array_unique(array_map('intval', $unlink_ids)));
			$placeholders = implode(',', array_fill(0, count($unlink_ids), '%d'));

			$wpdb->query(
				$wpdb->prepare(
					"UPDATE {$table}
					 SET draft_post_id = NULL
					 WHERE id IN ({$placeholders})",
					$unlink_ids
				)
			);
			$logger->info(sprintf(
				'Cleanup Retention: Unlinked %d dangling draft_post_id references (posts already deleted or not plugin-owned): %s',
				count($unlink_ids), implode(',', $unlink_ids)
			));
		}

		// ── PHASE 2: Catch orphaned WP Auto drafts without discovery rows ────
		// These drafts were deferred by the WP Auto Poller (skipped_not_newer)
		// but never got a discovery table entry. They are invisible to the
		// discovery-based scan above. Find drafts in the SW category that:
		//   - Are older than retention_days
		//   - Have no discovery table row referencing them
		//   - Have WP Auto meta (wpautomaticurl/automatic_url)
		$orphan_deleted = 0;
		$wp_auto_cat = (int) \get_option(
			\SEO_Article_Generator\Option_Registry::WP_AUTO_CATEGORY_ID,
			\SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::WP_AUTO_CATEGORY_ID]
		);
		if ($wp_auto_cat > 0) {
			$cutoff_mysql = $now_ts > 0 ? gmdate('Y-m-d H:i:s', $now_ts - ($retention_days * DAY_IN_SECONDS)) : gmdate('Y-m-d H:i:s', strtotime("-{$retention_days} days"));

			$orphan_drafts = $wpdb->get_results($wpdb->prepare(
				"SELECT p.ID
				FROM {$wpdb->posts} p
				LEFT JOIN {$table} d ON d.draft_post_id = p.ID
				WHERE p.post_status IN ('draft', 'auto-draft', 'pending')
				AND p.post_type = 'post'
				AND p.post_date_gmt < %s
				AND d.id IS NULL
				AND EXISTS (
				    SELECT 1 FROM {$wpdb->term_relationships} tr
				    JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id
				    WHERE tr.object_id = p.ID
				    AND tt.term_id = %d
				    AND tt.taxonomy = 'category'
				)
				AND EXISTS (
				    SELECT 1 FROM {$wpdb->postmeta} pm
				    WHERE pm.post_id = p.ID
				    AND pm.meta_key IN ('wpautomaticurl', 'automatic_url', 'seo_gen_processed_status')
				)
				LIMIT 50",
				$cutoff_mysql,
				$wp_auto_cat
			));

			if (! empty($orphan_drafts)) {
				foreach ($orphan_drafts as $orphan) {
					$orphan_id = (int) $orphan->ID;
					if ($orphan_id > 0) {
						\SEO_Article_Generator\Discovery\Discovery_Engine::schedule_draft_deletion($orphan_id, 0);
						$orphan_deleted++;
					}
				}
				$logger->info(sprintf(
					'Cleanup Retention Phase 2: Scheduled deletion for %d orphaned WP Auto drafts (no discovery row, older than %d days)',
					$orphan_deleted, $retention_days
				));
			}
		}

		$logger->info(sprintf(
			'Cleanup Retention Job completed: re_scheduled=%d, unlinked=%d, orphaned_wp_auto=%d',
			count($reschedule), count($unlink_ids), $orphan_deleted
		));

		return true;
	}
}
