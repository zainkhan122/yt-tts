<?php

/**
 * Validator
 *
 * @package SEO_Article_Generator
 * @MODIFIED 2025-12-12 v1.9.0: Refactored to use Threshold_Config single source of truth
 */

namespace SEO_Article_Generator\Validation;

use SEO_Article_Generator\Validation_Exception;
use SEO_Article_Generator\Validation\ChangelogVerifier;
use SEO_Article_Generator\Traits\Type_Safety;
use SEO_Article_Generator\Generator\Download_Link_Helper;

// Prevent direct access
if (! defined('ABSPATH')) {
	exit;
}

/**
 * Validate generated articles
 */
class Validator
{
	use Type_Safety;

	/**
	 * Validation status constants
	 * @since 2.7.7
	 */
	public const STATUS_PASSED = 'passed';
	public const STATUS_PASSED_WITH_MANUAL_REVIEW = 'passed_with_manual_review';
	public const STATUS_FAILED = 'failed';

	/**
	 * Allowed license values (normalized lowercase).
	 * Uses word-boundary matching to avoid false positives like "non-free".
	 *
	 * @MODIFIED 2025-12-13 v2.0.2: Portal trust enforcement
	 */
	private const LICENSE_WHITELIST = array(
		'freeware',
		'free',        // @MODIFIED 2025-12-16 v2.3.3: Added common license terms
		'paid',        // @MODIFIED 2025-12-16 v2.3.3: Added common license terms
		'premium',     // @MODIFIED 2025-12-16 v2.3.3: Added common license terms
		'open-source',
		'open source',
		'opensource',
		'gpl',
		'mit',
		'apache',
		'bsd',
		'lgpl',
		'trial',
		'trialware',
		'shareware',
		'commercial',
		'freemium',
		'subscription',
		'proprietary',
		'public domain',
	);

	/**
	 * OS family normalization patterns.
	 *
	 * @MODIFIED 2025-12-13 v2.0.2: Portal trust enforcement
	 */
	private const OS_FAMILY_PATTERNS = array(
		'windows' => '/windows|win\s*\d+|win\s*xp|win\s*vista/i',
		'macos'   => '/mac\s*os|macos|os\s*x|darwin|catalina|monterey|ventura|sonoma/i',
		'linux'   => '/linux|ubuntu|debian|fedora|centos|arch|mint|redhat|suse/i',
		'android' => '/android/i',
		'ios'     => '/ios|iphone|ipad/i',
	);

	/**
	 * Trusted antivirus/scanner names for verified claims.
	 *
	 * @MODIFIED 2025-12-13 v2.0.2: Portal trust enforcement
	 */
	private const TRUSTED_SCANNERS = array(
		'virustotal',
		'malwarebytes',
		'windows defender',
		'kaspersky',
		'norton',
		'avast',
		'avg',
		'bitdefender',
		'eset',
		'mcafee',
		'sophos',
		'trend micro',
		'f-secure',
		'comodo',
		'clamav',
	);

	/**
	 * Trusted App Domains that are always valid download sources
	 * regardless of homepage mismatch.
	 *
	 * @since 2.13.7
	 */
	private const TRUSTED_APP_DOMAINS = array(
		'play.google.com',
		'apps.apple.com',
		'microsoft.com',
		'automattic.com',
		'github.com',
		'sourceforge.net',
		'gitlab.com',
		'bitbucket.org',
		'chrome.google.com',
		'addons.mozilla.org',
		'steamcommunity.com',
		'store.steampowered.com',
		'epicgames.com',
		'gog.com',
		'itch.io',
	);

	/**
	 * Required fields in article data
	 *
	 * @var array
	 */
	private $required_fields = array(
		'title',
		'meta_description',
		'introduction',
		'tech_specs',
		'features',
		'download_section',
		'system_requirements',
		'safety', // New DTO-backed field
	);

	/**
	 * Validate article
	 *
	 * @param array $article Article data
	 * @param array $input_data Original input data
	 * @return array Validation results
	 */
	public function validate($article, $input_data)
	{
		$errors   = array();
		$warnings = array();
		$requires_manual_review = false;

	$mode = 'blog';
	$cfg = Threshold_Config::get($mode);
		$excluded  = isset($input_data['excluded_sections']) ? (array) $input_data['excluded_sections'] : array();
		$is_update = ! empty($input_data['is_update']);

		foreach ($this->required_fields as $field) {
			if (in_array($field, $excluded, true)) {
				continue;
			}
			if (empty($article[$field])) {
				// @MODIFIED 2026-03-20: Lenient Update Policy
				// If it's an update, missing fields that aren't typically 
				// requested in most partial regens (like meta_description) 
				// should only be warnings, not errors, as they might be 
				// merged later or preserved from legacy content.
				if ($is_update && in_array($field, ['meta_description', 'title', 'safety', 'system_requirements', 'features'], true)) {
					$warnings[] = "Missing recommended field for update: {$field}";
				} else {
					$errors[] = "Missing required field: {$field}";
				}
			}
		}

		if (! empty($article['title'])) {
			$title_length = strlen($article['title']);
			$t_cfg        = $cfg['title'];
			if ($title_length < $t_cfg['warning_min'] || $title_length > $t_cfg['warning_max']) {
				$warnings[] = sprintf(
					'Title length is %d chars (optimal: %d-%d)',
					$title_length,
					$t_cfg['optimal_min'],
					$t_cfg['optimal_max']
				);
			}
		}

		if (! empty($input_data['editor_rating'])) {
			$rating = floatval($input_data['editor_rating']);
			if ($rating < 1 || $rating > 5) {
				$errors[] = 'Editor rating must be between 1 and 5';
			}
		}

		if (! empty($article['meta_description'])) {
			$meta_length = strlen($article['meta_description']);
			$m_cfg       = $cfg['meta_description'];

			if ($meta_length > 165) {
				// @MODIFIED 2026-03-21: Structural Priority - Meta length is now ALWAYS a warning.
				// Softened to 165 to match common industry guardrails while allowing slight overflow.
				$warnings[] = sprintf('Meta description slightly long: %d chars (target: %d). This is an SEO optimization warning, not a blocker.', $meta_length, $m_cfg['error_above']);
			} elseif ($meta_length < $m_cfg['warning_below']) {
				$lost_pts   = Threshold_Config::get_lost_points('meta_description', $meta_length, $mode);
				$warnings[] = sprintf(
					'Meta description short: %d chars (target: %d-%d%s)',
					$meta_length,
					$m_cfg['full_min'],
					$m_cfg['full_max'],
					$lost_pts > 0 ? ", losing {$lost_pts}/{$m_cfg['pts_full']} pts" : ''
				);
			}
		}

		if (! $is_update && ! in_array('features', $excluded, true)) {
			$f_cfg = $cfg['features'];
			if (! empty($article['features'])) {
				$feature_count = count($article['features']);
				if ($feature_count < $f_cfg['warning_below']) {
					$lost_pts = Threshold_Config::get_lost_points('features', $feature_count, $mode);
					$msg      = sprintf(
						'Only %d features (target: %d%s)',
						$feature_count,
						$f_cfg['full_count'],
						$lost_pts > 0 ? ", losing {$lost_pts}/{$f_cfg['pts_full']} pts" : ''
					);
					if ($feature_count < $f_cfg['error_below']) {
						$errors[] = $msg;
					} else {
						$warnings[] = $msg;
					}
				}
			} else {
				$errors[] = 'No features provided';
			}
		}

		if (! $is_update && ! in_array('faqs', $excluded, true)) {
			$faq_cfg = $cfg['faqs'];
			if (! empty($article['faqs'])) {
				$faq_count = count($article['faqs']);
				if ($faq_count < $faq_cfg['warning_below']) {
					$lost_pts = Threshold_Config::get_lost_points('faqs', $faq_count, $mode);
					$msg      = sprintf(
						'Only %d FAQs (target: %d%s)',
						$faq_count,
						$faq_cfg['full_count'],
						$lost_pts > 0 ? ", losing {$lost_pts}/{$faq_cfg['pts_full']} pts" : ''
					);
					if ($faq_count < $faq_cfg['error_below']) {
						$errors[] = $msg;
					} else {
						$warnings[] = $msg;
					}
				}

				if (! empty($article['focus_keyword'])) {
					$faq_keyword_count = $this->count_keyword_in_section($article['faqs'], $article['focus_keyword'], 'faq');
					if ($faq_keyword_count > $cfg['faq_keyword_max']) {
						$warnings[] = sprintf(
							'Focus keyword appears %d times in FAQs (robotic repetition, max: %d)',
							$faq_keyword_count,
							$cfg['faq_keyword_max']
						);
					}
				}

				if ($faq_count > 3) {
					$warnings[] = sprintf(
						'FAQ has %d items (target: 1-3, max: 3). Consider reducing.',
						$faq_count
					);
				}
			} else {
				$warnings[] = 'No FAQs provided (acceptable for simple utilities)';
			}
		}

		// @MODIFIED 2026-03-09: Direct normalization via Helper (Phase 2)
		$normalized_links = array();
		$fallback_platform = 'Windows';
		if (! empty($article['tech_specs']['os_support'])) {
			$parts = array_map('trim', explode(',', (string) $article['tech_specs']['os_support']));
			if (! empty($parts[0])) {
				$fallback_platform = Download_Link_Helper::normalize_platform_name($parts[0]);
			}
		}
		if (! empty($article['download_section']['links']) && is_array($article['download_section']['links'])) {
			$normalized_links = Download_Link_Helper::normalize_links($article['download_section']['links'], $fallback_platform);
		}

		if (! empty($article['tech_specs'])) {
			$specs = $article['tech_specs'];

			if (empty($specs['software_name'])) {
				$errors[] = 'Missing software name in tech specs';
			}

			if (empty($specs['version'])) {
				$msg = 'Missing version in tech specs';
				if ($this->is_manual_input_needed('tech_specs.version', $article)) {
					$warnings[] = $msg . ' (Manual Input Required)';
					$requires_manual_review = true;
				} else {
					$warnings[] = $msg;
				}
			}

			if (empty($specs['developer'])) {
				$msg = 'Missing developer in tech specs (trust signal)';
				if ($this->is_manual_input_needed('tech_specs.developer', $article)) {
					$warnings[] = $msg . ' (Manual Input Required)';
					$requires_manual_review = true;
				} else {
					$warnings[] = $msg;
				}
			}

			if (empty($specs['homepage'])) {
				$msg = 'Missing homepage URL in tech specs (trust signal)';
				if ($this->is_manual_input_needed('tech_specs.homepage', $article)) {
					$warnings[] = $msg . ' (Manual Input Required)';
					$requires_manual_review = true;
				} else {
					$warnings[] = $msg;
				}
			} elseif (! filter_var($specs['homepage'], FILTER_VALIDATE_URL)) {
				$msg = 'Invalid homepage URL in tech specs';
				$warnings[] = $msg;
			}

			if (empty($specs['last_updated'])) {
				$warnings[] = 'Missing last_updated date in tech specs';
			}

			if (empty($specs['license'])) {
				$msg = 'Missing license in tech specs (required for trust)';
				if ($this->is_manual_input_needed('tech_specs.license', $article)) {
					$warnings[] = $msg . ' (Manual Input Required)';
					$requires_manual_review = true;
				} else {
					$warnings[] = $msg;
				}
			} else {
				$license_normalized = strtolower(self::as_string($specs['license']));
				$license_valid      = false;
				foreach (self::LICENSE_WHITELIST as $allowed) {
					if (preg_match('/\b' . preg_quote($allowed, '/') . '\b/', $license_normalized)) {
						$license_valid = true;
						break;
					}
				}
				if (! $license_valid) {
					$msg = sprintf('License "%s" not recognized (use: freeware, open-source, trial, commercial, etc.)', $specs['license']);
					$warnings[] = $msg;
				}
			}

			// @MODIFIED 2026-03-09: Use Helper to check for valid downloads
			$has_download = Download_Link_Helper::has_valid_download($normalized_links);
			if (empty($specs['os_support'])) {
				if ($has_download) {
					$msg = 'Missing os_support in tech specs (required when download exists)';
					$warnings[] = $msg;
				}
			} else {
				$os_text    = strtolower(self::as_string($specs['os_support']));
				$os_matched = false;
				foreach (self::OS_FAMILY_PATTERNS as $pattern) {
					if (preg_match($pattern, $os_text)) {
						$os_matched = true;
						break;
					}
				}
				if (! $os_matched) {
					$msg = sprintf('os_support "%s" could not be normalized to known OS family (Windows, macOS, Linux, Android, iOS)', $specs['os_support']);
					$warnings[] = $msg;
				}
			}
		}

		if (! empty($article['whats_new'])) {
			$clVerify = ChangelogVerifier::verify($article);
			if (! $clVerify['ok']) {
				$msg = 'WhatsNew items present but changelog URL verification failed: ' . $clVerify['reason'];
				if ($this->is_manual_input_needed('tech_specs.changelogurl', $article)) {
					$warnings[] = $msg . ' (Manual Input Required)';
					$requires_manual_review = true;
				} else {
					$warnings[] = $msg;
				}
			}
		}

		if (! in_array('system_requirements', $excluded, true)) {
			if (! empty($article['system_requirements'])) {
				$sysreqs = $article['system_requirements'];
				if (empty($sysreqs['minimum'])) {
					$msg = 'System requirements missing minimum specs';
					$warnings[] = $msg;
				} else {
					$minspecs = $sysreqs['minimum'];
					if (empty($minspecs['os'])) {
						$msg = 'System requirements missing OS version';
						if (! empty($article['tech_specs']['os_support'])) {
							$warnings[] = $msg . ' (Hero section requirements line will be hidden - using tech_specs.os_support fallback)';
						} elseif ($this->is_manual_input_needed('system_requirements.minimum.os', $article)) {
							$warnings[] = $msg . ' (Manual Input Required)';
							$requires_manual_review = true;
						} else {
							$warnings[] = $msg;
						}
					}
				}
			} else {
				$msg = 'No system requirements provided';
				$warnings[] = $msg;
			}
		}

		if (! in_array('safety', $excluded, true)) {
			if (! empty($article['safety'])) {
				$safety_check = $this->validate_download_safety($article);
				if (! $safety_check['valid']) {
					$msg = $safety_check['message'];
					$warnings[] = $msg;
				}
			} else {
				$msg = 'Missing safety/trust data structure';
				$warnings[] = $msg;
			}
		}

		if (! $is_update && ! in_array('installation_guide', $excluded, true)) {
			$inst_cfg = $cfg['installation_steps'];
			if (! empty($article['installation_guide'])) {
				if (empty($article['installation_guide']['steps'])) {
					$msg = 'Installation guide missing steps';
					$warnings[] = $msg;
				} else {
					$step_count = count($article['installation_guide']['steps']);
					if ($step_count < $inst_cfg['full_count']) {
						$lost_pts = Threshold_Config::get_lost_points('installation_steps', $step_count, $mode);
						$msg      = sprintf(
							'Installation guide has %d steps (target: %d%s)',
							$step_count,
							$inst_cfg['full_count'],
							$lost_pts > 0 ? ", losing {$lost_pts}/{$inst_cfg['pts_full']} pts" : ''
						);
				if ($step_count < $inst_cfg['error_below']) {
						$errors[] = $msg;
					} else {
						$warnings[] = $msg;
					}
					}
				}
			} else {
				$msg = 'Missing installation guide';
				$warnings[] = $msg;
			}
		}

		// @MODIFIED 2026-03-09: Delegate primary link finding to Helper
		if (! in_array('download_section', $excluded, true)) {
			$download_url = Download_Link_Helper::find_primary_download_url($normalized_links);

			if ($download_url === '') {
				$msg = 'Missing real download link - this is required for quality content';
				if ($this->is_manual_input_needed('download_section.links', $article)) {
					$warnings[] = $msg . ' (Manual Input Required)';
					$requires_manual_review = true;
				} elseif ($is_update) {
					// @MODIFIED 2026-03-21: Structural Priority - Missing link is a warning for updates
					$warnings[] = $msg . ' (Update allowed to proceed with layout preservation)';
				} else {
					$errors[] = $msg;
				}
			}

			// Validate ALL links (no longer assume primary is the only one that matters)
			$invalid_secondary_count = 0;
			foreach ((array) ($article['download_section']['links'] ?? array()) as $link) {
				if (! is_array($link)) {
					$invalid_secondary_count++;
					continue;
				}
				$url = isset($link['url']) ? trim((string) $link['url']) : '';
				if ($url === '') {
					continue;
				}
				if (! empty($link['is_primary'])) {
					continue;
				}
				if (! Download_Link_Helper::is_valid_download_url($url)) {
					$invalid_secondary_count++;
				}
			}
			if ($invalid_secondary_count > 0) {
				$msg = sprintf('%d secondary download links are placeholder/invalid URLs', $invalid_secondary_count);
				$warnings[] = $msg;
			}

			foreach ($normalized_links as $classified_link) {
				if (($classified_link['classification_status'] ?? '') === 'needs_review') {
					$requires_manual_review = true;
					$warnings[] = 'Download classification needs review (OS or architecture uncertain): ' . $classified_link['url'];
				}
			}

			// Validate platforms
			$links_missing_platform = 0;
			foreach ($normalized_links as $link) {
				$platform = isset($link['platform']) ? Download_Link_Helper::normalize_platform_name($link['platform']) : 'Other';
				if ($platform === 'Other') {
					$links_missing_platform++;
				}
			}
			if ($links_missing_platform > 0) {
				$msg = sprintf('%d download links missing valid platform label (e.g., Windows, macOS, Linux)', $links_missing_platform);
				$warnings[] = $msg;
			}

			if ($download_url !== '' && ! empty($article['tech_specs']['homepage'])) {
				$download_host = parse_url($download_url, PHP_URL_HOST);
				$homepage_host = parse_url($article['tech_specs']['homepage'], PHP_URL_HOST);
				if ($download_host && $homepage_host) {
					$download_host = preg_replace('/^www\./i', '', strtolower($download_host));
					$homepage_host = preg_replace('/^www\./i', '', strtolower($homepage_host));
					$download_root = $this->extract_root_domain($download_host);
					$homepage_root = $this->extract_root_domain($homepage_host);
					$is_match      = ($download_root === $homepage_root);
					if (! $is_match) {
						foreach (self::TRUSTED_APP_DOMAINS as $trusted) {
							if (stripos($download_host, $trusted) !== false) {
								$is_match = true;
								break;
							}
						}
					}
					if (! $is_match) {
						$warnings[] = sprintf(
							'Download domain %s differs from homepage %s - verify this is an official mirror',
							$download_host,
							$homepage_host
						);
					}
				}
			}

			if ($download_url !== '') {
				if (empty($article['hero_section']) || ! is_array($article['hero_section'])) {
					$warnings[] = 'Download section exists but hero_section is empty; hero should display download CTA';
				}

				$has_min_os = false;
				if (! empty($article['system_requirements'])) {
					$sysreqs = $article['system_requirements'];
					if (is_object($sysreqs) && isset($sysreqs->minimum->os) && ! empty($sysreqs->minimum->os)) {
						$has_min_os = true;
					} elseif (is_array($sysreqs) && isset($sysreqs['minimum']['os']) && ! empty($sysreqs['minimum']['os'])) {
						$has_min_os = true;
					}
				}

				if (! $has_min_os) {
					$msg = 'Download exists but system requirements missing OS version; hero cannot show requirements line';
					if (! empty($article['tech_specs']['os_support'])) {
						$warnings[] = $msg . ' (Using tech_specs.os_support fallback)';
					} elseif ($this->is_manual_input_needed('system_requirements.minimum.os', $article)) {
						$warnings[] = $msg . ' (Manual Input Required)';
						$requires_manual_review = true;
					} else {
						$warnings[] = $msg;
					}
				}
			}
		}

		if (! $is_update && ! empty($article['html_content']) && ! empty($article['focus_keyword'])) {
			$density = $this->calculate_keyword_density($article['html_content'], $article['focus_keyword']);
			$k_cfg   = $cfg['keyword_density'];

			if ($density > $k_cfg['error_above']) {
				$warnings[] = sprintf('Keyword density %.2f%% is very high (potential keyword stuffing)', $density);
			} elseif ($density < $k_cfg['warning_low']) {
				$lost_pts   = Threshold_Config::get_lost_points('keyword_density', $density, $mode);
				$warnings[] = sprintf(
					'Keyword density low %.2f%% (optimal: %.1f-%.1f%%%s)',
					$density,
					$k_cfg['full_min'],
					$k_cfg['full_max'],
					$lost_pts > 0 ? ", losing {$lost_pts}/{$k_cfg['pts_full']} pts" : ''
				);
			} elseif ($density > $k_cfg['warning_high']) {
				$lost_pts   = Threshold_Config::get_lost_points('keyword_density', $density, $mode);
				$warnings[] = sprintf(
					'Keyword density high %.2f%% (optimal: %.1f-%.1f%%%s)',
					$density,
					$k_cfg['full_min'],
					$k_cfg['full_max'],
					$lost_pts > 0 ? ", losing {$lost_pts}/{$k_cfg['pts_full']} pts" : ''
				);
			} else {
				$lost_pts = Threshold_Config::get_lost_points('keyword_density', $density, $mode);
				if ($lost_pts > 0) {
					$warnings[] = sprintf(
						'Keyword density %.2f%% is suboptimal (optimal: %.1f-%.1f%%), losing %d pts',
						$density,
						$k_cfg['full_min'],
						$k_cfg['full_max'],
						$lost_pts
					);
				}
			}
		}

		if (! $is_update && ! empty($article['html_content'])) {
			$sentence_warnings = $this->check_sentence_length($article['html_content']);
			$warnings          = array_merge($warnings, $sentence_warnings);
		}

		if (! $is_update && ! empty($article['introduction']) && ! empty($article['features'])) {
			$robotic_warnings = $this->check_robotic_phrasing($article);
			$warnings          = array_merge($warnings, $robotic_warnings);
		}

		if (! $is_update && ! empty($article['moat_data']['content'])) {
			$article_features = isset($article['features']) ? $article['features'] : array();
			$moat_validation  = $this->validate_moat_quality($article['moat_data']['content'], $article_features);
			if (! $moat_validation['valid']) {
				$msg = $moat_validation['message'];
				$warnings[] = $msg;
			}
			if (! empty($moat_validation['warnings'])) {
				$warnings = array_merge($warnings, $moat_validation['warnings']);
			}
		}

		if (! $is_update && ! empty($article['moat_data']['content'])) {
			$moat_count = count($article['moat_data']['content']);
			if ($moat_count > 3) {
				$warnings[] = sprintf(
					'Moat has %d items (target: 1-3, max: 3). Consider reducing.',
					$moat_count
				);
			}
		}

		if (! $is_update && ! empty($article['html_content'])) {
			$text       = wp_strip_all_tags($article['html_content']);
			$word_count = str_word_count($text);
			$c_cfg      = $cfg['content_length'];

			if ($word_count < $c_cfg['error_below']) {
				// @MODIFIED 2026-03-21: Structural Priority - Content length is now a warning
				$warnings[] = sprintf('Content length %d words is below minimum %d. Structural integrity is prioritized over SEO length.', $word_count, $c_cfg['error_below']);
				if (defined('WP_DEBUG') && WP_DEBUG) {
					error_log(sprintf(
						'SEO-Gen Validator: Content length warning triggered (%d words) mode=%s software=%s',
						$word_count,
						$mode,
						isset($article['tech_specs']['software_name']) ? $article['tech_specs']['software_name'] : 'unknown'
					));
				}
			} elseif ($word_count < $c_cfg['full_min']) {
				$lost_pts   = Threshold_Config::get_lost_points('content_length', $word_count, $mode);
				$warnings[] = sprintf(
					'Content length %d words (target: %d-%d%s)',
					$word_count,
					$c_cfg['full_min'],
					$c_cfg['full_max'],
					$lost_pts > 0 ? ", losing {$lost_pts}/{$c_cfg['pts_full']} pts" : ''
				);
			} elseif ($word_count > $c_cfg['score_loss_above'] && $word_count <= $c_cfg['warning_above']) {
				$lost_pts   = Threshold_Config::get_lost_points('content_length', $word_count, $mode);
				$warnings[] = sprintf(
					'Content length %d words exceeds scoring range max for points (%d%s)',
					$word_count,
					$c_cfg['score_loss_above'],
					$lost_pts > 0 ? ", losing {$lost_pts}/{$c_cfg['pts_full']} pts" : ''
				);
			} elseif ($word_count > $c_cfg['warning_above']) {
				$warnings[] = sprintf('Content may be bloated: %d words (recommended max: %d)', $word_count, $c_cfg['warning_above']);
			}
		}

		$scoring_engine = new Scoring_Engine();
		$score          = $scoring_engine->calculate_score($article, $input_data, $mode);

	if ($is_update) {
		$score = 100; // Force passing score for structural-only updates
	}

	$threshold = Threshold_Config::get_mode_threshold($mode);
		$passed    = $score >= $threshold && empty($errors);

		// @MODIFIED: Factual Guard (Phase 3)
		if (! empty($article['primary_text'])) {
			$factual  = $this->factual_guard($article);
			$errors   = array_merge($errors, $factual['errors']);
			$warnings = array_merge($warnings, $factual['warnings']);
			// Re-evaluate passed status after factual guard
			$passed = $passed && empty($factual['errors']);
		}

		$result = array(
			'passed'          => $passed,
			'score'           => $score,
			'errors'          => $errors,
			'warnings'        => $warnings,
			'threshold'       => $threshold,
			'recommendations' => $this->get_recommendations($score, $errors, $warnings),
			'grouped'         => $this->group_issues($errors, $warnings, $requires_manual_review),
		);

		if ($passed && $requires_manual_review) {
			$result['status']      = self::STATUS_PASSED_WITH_MANUAL_REVIEW;
			$result['warnings'][] = 'Article passed validation but requires manual input for one or more verification fields.';
		} elseif ($passed) {
			$result['status'] = self::STATUS_PASSED;
		} else {
			$result['status'] = self::STATUS_FAILED;
		}

		return $result;
	}

	/**
	 * Calculate keyword density
	 *
	 * @param string $content HTML content
	 * @param string $keyword Focus keyword
	 * @return float Keyword density percentage
	 */
	private function calculate_keyword_density($content, $keyword)
	{
		// Strip HTML tags
		$text = wp_strip_all_tags($content);

		// Count total words
		$total_words = str_word_count($text);

		if ($total_words === 0) {
			return 0;
		}

		// Count keyword occurrences (case-insensitive)
		$keyword_count = substr_count(strtolower($text), strtolower($keyword));

		// Calculate density
		$density = ($keyword_count / $total_words) * 100;

		return round($density, 2);
	}

	/**
	 * Count keyword occurrences in a section (FAQs or Features)
	 *
	 * @MODIFIED 2025-12-08 v1.5.2: Added for anti-robotic keyword detection
	 *
	 * @param array  $section Section data (faqs or features array)
	 * @param string $keyword Focus keyword
	 * @param string $type    Section type ('faq' or 'feature')
	 * @return int Keyword count
	 */
	private function count_keyword_in_section($section, $keyword, $type)
	{
		$count         = 0;
		$keyword_lower = strtolower($keyword);

		foreach ($section as $item) {
			$text = '';
			if ($type === 'faq') {
				$text  = isset($item['question']) ? $item['question'] : '';
				$text .= ' ' . (isset($item['answer']) ? $item['answer'] : '');
			} elseif ($type === 'feature') {
				$text  = isset($item['name']) ? $item['name'] : '';
				$text .= ' ' . (isset($item['description']) ? $item['description'] : '');
			}

			$count += substr_count(strtolower($text), $keyword_lower);
		}

		return $count;
	}

	/**
	 * Get recommendations for improvement
	 *
	 * @param int   $score Validation score
	 * @param array $errors Errors
	 * @param array $warnings Warnings
	 * @return array Recommendations
	 */
	private function get_recommendations($score, $errors, $warnings)
	{
		$recommendations = array();

		if ($score < 70) {
			$recommendations[] = 'Score is below threshold - review and improve article';
		}

		if (! empty($errors)) {
			$recommendations[] = 'Fix all errors before publishing';
		}

		if (count($warnings) > 3) {
			$recommendations[] = 'Consider addressing multiple warnings for better quality';
		}

		if ($score >= 90) {
			$recommendations[] = 'Excellent quality! Ready to publish';
		} elseif ($score >= 70) {
			$recommendations[] = 'Good quality - review warnings and publish';
		}

		return $recommendations;
	}

	/**
	 * Check for overly long sentences
	 *
	 * @MODIFIED 2025-12-08 v1.5.3: Anti-robotic content check
	 *
	 * @param string $content HTML content
	 * @return array Warnings for long sentences
	 */
	private function check_sentence_length($content)
	{
		$warnings  = array();
		$text      = wp_strip_all_tags($content);
		$sentences = preg_split('/[.!?]+/', $text, -1, PREG_SPLIT_NO_EMPTY);
		$cfg       = Threshold_Config::get();
		$max_words = $cfg['sentence_max_words'];

		$long_count = 0;
		foreach ($sentences as $sentence) {
			$word_count = str_word_count(trim($sentence));
			if ($word_count > $max_words) {
				++$long_count;
			}
		}
		if ($long_count > 0) {
			$warnings[] = sprintf('%d sentence(s) exceed %d words (robotic feel)', $long_count, $max_words);
		}

		return $warnings;
	}

	/**
	 * Check for robotic keyword stuffing patterns
	 * @ADDED 2026-01-03 v2.13.0: Natural language quality gate
	 * 
	 * @param array $article Article data
	 * @return array Warning strings (NOT objects - validator expects plain strings)
	 */
	private function check_robotic_phrasing($article)
	{
		$warnings = [];

		$robotic_patterns = [
			'/initiate the .{0,50}(download|installation)/i' => 'Robotic phrase detected: "initiate the download/installation"',
			'/to get started with this (versatile |powerful )?tool/i' => 'Robotic phrase detected: "to get started with this tool"',
			'/download this (versatile |powerful )?(software|application|tool|program)/i' => 'Robotic phrase detected: "download this software/tool"',
		];

		// Check introduction
		if (!empty($article['introduction'])) {
			$intro_array = is_array($article['introduction']) ? $article['introduction'] : array($article['introduction']);
			foreach ($intro_array as $para) {
				$intro = self::as_string($para);
				foreach ($robotic_patterns as $pattern => $message) {
					if (preg_match($pattern, $intro)) {
						$warnings[] = $message . ' in introduction - rewrite for natural language';
						break; // One warning per paragraph is enough
					}
				}
			}
		}

		// Check feature names
		if (!empty($article['features']) && is_array($article['features'])) {
			foreach ($article['features'] as $idx => $feature) {
				if (!empty($feature['name'])) {
					$feature_name = self::as_string($feature['name']);
					foreach ($robotic_patterns as $pattern => $message) {
						if (preg_match($pattern, $feature_name)) {
							$warnings[] = $message . " in feature #{$idx}";
							break; // One warning per feature
						}
					}
				}
			}
		}

		return $warnings;
	}

	/**
	 * Validate moat content quality (anti-template enforcement)
	 * @ADDED 2026-01-03 v2.13.1: Moat quality gates to prevent generic settings/workflows
	 * @MODIFIED 2026-01-03 v2.13.2: Switched to scoring model instead of boolean gates
	 * 
	 * Scoring model per moat item:
	 * +2 strong signal: tech terms whitelist (H.264, CUDA, ARM64, etc.)
	 * +2 strong signal: depth-aware menu paths (4+ levels = +2, 2-3 = +1, 1 = +0.5)
	 * +1 medium signal: 2+ distinct non-installer file extensions
	 * +1 medium signal: feature/tool name match against article features
	 * -2 penalty: generic step phrases blacklist
	 * 
	 * Threshold: ≥2 per item, requires ≥2 items to pass
	 * 
	 * @param array $moat_items Array of moat content items
	 * @param array $article_features Optional features list for cross-validation
	 * @return array ['valid' => bool, 'message' => string, 'warnings' => array]
	 */
	private function validate_moat_quality($moat_items, $article_features = [])
	{
		$passed_count = 0;
		$failed_count = 0;
		$warnings = [];
		$failed_items = [];
		$score_details = [];

		// [FIX 1] Expanded tech terms to include photo, AI, and general software terminology
		$tech_terms = [
			'h.264', 'hevc', 'mp4', 'pdf', 'docx', 'cuda', 'arm64', 'bitrate', // Legacy
			'raw', 'ai', 'presets', 'layer', 'masking', 'rgb', 'cmyk', 'iso', // Photo/Design
			'vpn', 'proxy', 'dns', 'ip', 'encryption', 'ssl', // Network/Security
			'sync', 'cache', 'database', 'sql', 'macro', 'batch' // General/Productivity
		];

		$generic_patterns = [
			'/navigate to settings/i',
			'/go to settings/i',
			'/restart (the )?(app|application|program|software)/i',
			'/click (the )?(download button|settings (button|icon))/i',
			'/open (the )?menu/i',
			'/configure (the )?options/i',
		];

		foreach ($moat_items as $idx => $item) {
			$recipe = isset($item['recipe']) ? $item['recipe'] : '';
			$heading = isset($item['heading']) ? $item['heading'] : '';
			$combined = $recipe . ' ' . $heading;
			$score = 0;
			$signals = [];

			if (strlen($combined) < 50) {
				$failed_count++;
				$failed_items[] = sprintf('Item #%d too short', $idx + 1);
				$score_details[] = sprintf('Item #%d: 0 pts (too short)', $idx + 1);
				continue;
			}

			// PENALTY: Generic phrase blacklist (-2)
			$combined_str = self::as_string($combined);
			foreach ($generic_patterns as $pattern) {
				if (preg_match($pattern, $combined_str)) {
					$score -= 2;
					$signals[] = 'generic phrase (-2)';
					break; 
				}
			}

			// STRONG SIGNAL: Tech terms whitelist (+2)
			$tech_matches = 0;
			$combined_lower = strtolower($combined);
			foreach ($tech_terms as $term) {
				if (preg_match('/\b' . preg_quote($term, '/') . '\b/i', $combined_lower)) {
					$tech_matches++;
				}
			}
			if ($tech_matches > 0) {
				$score += 2;
				$signals[] = sprintf('tech terms (%d found, +2)', $tech_matches);
			}

			// [FIX 2] Flexible UI Depth: Check for '>', '->', or bolded UI elements (+2 max)
			$menu_depth = substr_count($combined, '>') + substr_count($combined, '->');
			$ui_bold_count = preg_match_all('/\*\*[^*]+\*\*/', $combined); // Catch markdown bolding like **Catalog**
			
			if ($menu_depth >= 2 || $ui_bold_count >= 3) {
				$score += 2;
				$signals[] = 'strong UI pathing (+2)';
			} elseif ($menu_depth === 1 || $ui_bold_count >= 1) {
				$score += 1;
				$signals[] = 'moderate UI pathing (+1)';
			}

			// [FIX 3] Feature matching: Replaced similar_text() with strpos() for accurate subset matching (+1)
			if (!empty($article_features)) {
				foreach ($article_features as $feature) {
					$feature_name = isset($feature['name']) ? strtolower(self::as_string($feature['name'])) : '';
					if (!empty($feature_name) && strpos($combined_lower, $feature_name) !== false) {
						$score += 1;
						$signals[] = 'feature match (+1)';
						break; 
					}
				}
			}

			if ($score >= 2) {
				$passed_count++;
				$score_details[] = sprintf('Item #%d: %.1f pts PASS (%s)', $idx + 1, $score, implode(', ', $signals));
			} else {
				$failed_count++;
				$failed_items[] = sprintf('Item #%d scored %.1f pts (need 2+): %s', $idx + 1, $score, implode(', ', $signals));
				$score_details[] = sprintf('Item #%d: %.1f pts FAIL (%s)', $idx + 1, $score, implode(', ', $signals));
			}
		}

		// @MODIFIED 2026-04-30: Changed from < 2 to < 1 to align with Threshold_Config moat.min_count=1
		if ($passed_count < 1) {
			return [
				'valid' => false,
				'message' => sprintf(
					'Moat content insufficient: only %d/%d items meet quality bar (need 1+ scoring ≥2 pts). Scores: %s',
					$passed_count, count($moat_items), implode('; ', $score_details)
				),
				'warnings' => [],
			];
		}

		if ($failed_count > 0) {
			$warnings[] = sprintf('%d moat item(s) below threshold: %s', $failed_count, implode('; ', $failed_items));
		}

		return ['valid' => true, 'message' => '', 'warnings' => $warnings];
	}

	/**
	 * Group issues by category for QA dashboard
	 *
	 * @MODIFIED 2025-12-08 v1.5.3: Categorized error/warning display
	 *
	 * @param array $errors Errors array
	 * @param array $warnings Warnings array
	 * @return array Grouped issues
	 */
	private function group_issues($errors, $warnings, $requires_manual_review = false)
	{
		$groups = array(
			'download'  => array(
				'errors'   => array(),
				'warnings' => array(),
			),
			'seo'       => array(
				'errors'   => array(),
				'warnings' => array(),
			),
			'content'   => array(
				'errors'   => array(),
				'warnings' => array(),
			),
			'structure' => array(
				'errors'   => array(),
				'warnings' => array(),
			),
		);

		$patterns = array(
			'download'  => array('download', 'link', 'primary'),
			'seo'       => array('keyword', 'density', 'meta', 'title'),
			'content'   => array('sentence', 'FAQ', 'feature', 'installation', 'rating', 'system', 'requirements'),
			'structure' => array('heading', 'field', 'missing', 'required', 'safety', 'hash'),
		);

		foreach ($errors as $error) {
			$category                        = $this->categorize_issue($error, $patterns);
			$groups[$category]['errors'][] = $error;
		}
		foreach ($warnings as $warning) {
			$category                          = $this->categorize_issue($warning, $patterns);
			$groups[$category]['warnings'][] = $warning;
		}

		return $groups;
	}

	/**
	 * Categorize an issue message
	 *
	 * @param string $message Issue message
	 * @param array  $patterns Category patterns
	 * @return string Category name
	 */
	private function categorize_issue($message, $patterns)
	{
		$lower = strtolower($message);
		foreach ($patterns as $category => $keywords) {
			foreach ($keywords as $kw) {
				if (strpos($lower, $kw) !== false) {
					return $category;
				}
			}
		}
		return 'structure';
	}

	/**
	 * Validate download safety based on domain/hash evidence.
	 *
	 * @MODIFIED 2025-12-11 v1.6.2: Moved from Article_Schema (clean separation).
 * @MODIFIED 2025-12-13 v2.0.2: Scanner whitelist enforcement.
 * Policy check: AI often hallucinates "verified: true". Verification requires proof.
 * Rule: Must match homepage domain OR have a trusted file hash + recognized scanner.
 *
 * @param array $article Article data
 * @return array ['valid' => bool, 'message' => string]
 */
	private function validate_download_safety($article)
	{
		$safety           = isset($article['safety']) ? $article['safety'] : array();
		$tech_specs       = isset($article['tech_specs']) ? $article['tech_specs'] : array();
		$download_section = isset($article['download_section']) ? $article['download_section'] : array();

		$verified_claimed = ! empty($safety['verified_download']);
		$has_hash         = ! empty($safety['file_hash']);

		// If not claimed as verified, nothing to dispute.
		if (! $verified_claimed) {
			return array(
				'valid'   => true,
				'message' => '',
			);
		}

		// @MODIFIED 2025-12-13 v2.0.2: Verified claims need hash + recognized scanner
		// Allow manual input for hash or verified_download to bypass this check
		$hash_manual_input = $this->is_manual_input_needed('safety.file_hash', $article);
		$verified_manual_input = $this->is_manual_input_needed('safety.verified_download', $article);

		if ($has_hash || $hash_manual_input) {
			// Check scanner whitelist only if hash is present and not manually input
			if ($has_hash && !$hash_manual_input) {
				$scanned_by = isset($safety['scanned_by']) ? $safety['scanned_by'] : array();
				if (! is_array($scanned_by)) {
					$scanned_by = array($scanned_by);
				}

				$has_trusted_scanner = false;
				foreach ($scanned_by as $scanner) {
					if (empty($scanner)) {
						continue;
					}
					$scanner_lower = strtolower(self::as_string($scanner));
					foreach (self::TRUSTED_SCANNERS as $trusted) {
						if (strpos($scanner_lower, $trusted) !== false) {
							$has_trusted_scanner = true;
							break 2;
						}
					}
				}

				if (! $has_trusted_scanner) {
					return array(
						'valid'   => false,
						'message' => 'Verified download claimed but no recognized scanner (required: VirusTotal, Malwarebytes, etc.)',
					);
				}
			}

			// Has hash (and scanner for Portal, or Lite allows without) OR hash is manually input
			return array(
				'valid'   => true,
				'message' => '',
			);
		}

		// No hash provided and not manually input. Check if download links match homepage domain.
		// This check is also bypassed if verified_download is manually input.
		if ($verified_manual_input) {
			return array(
				'valid'   => true,
				'message' => '',
			);
		}

		$homepage = isset($tech_specs['homepage']) ? $tech_specs['homepage'] : '';
		$links    = isset($download_section['links']) && is_array($download_section['links']) ? $download_section['links'] : array();

		if (empty($homepage) || empty($links)) {
			return array(
				'valid'   => false,
				'message' => 'Download claimed as verified but no hash or homepage to validate against',
			);
		}

		$home_host = \wp_parse_url($homepage, PHP_URL_HOST);
		if (! $home_host) {
			return array(
				'valid'   => false,
				'message' => 'Cannot parse homepage URL for verification',
			);
		}
		$home_root_domain = $this->extract_root_domain($home_host);

		$domain_match = false;
		foreach ($links as $link) {
			if (empty($link['url'])) {
				continue;
			}
			$link_host = \wp_parse_url($link['url'], PHP_URL_HOST);
			if (! $link_host) {
				continue;
			}

			$link_root_domain = $this->extract_root_domain($link_host);

			if ($link_root_domain === $home_root_domain) {
				$domain_match = true;
				break;
			}

			// Trusted CDNs
			if (preg_match('/(github\.com|sourceforge\.net|microsoft\.com|google\.com)/', self::as_string($link_host))) {
				$domain_match = true;
				break;
			}
		}

		if (! $domain_match) {
			return array(
				'valid'   => false,
				'message' => 'Download claimed as verified but link domain does not match homepage (possible AI hallucination)',
			);
		}

		return array(
			'valid'   => true,
			'message' => '',
		);
	}

	/**
	 * Extract root/registrable domain from a hostname.
	 * Handles subdomains and common TLD patterns (including country-code TLDs).
	 *
	 * @since 2.6.2: Added for improved domain matching (CDN/subdomain support)
	 *
	 * Examples:
	 * - download.hitpaw.com -> hitpaw.com
	 * - edimakor.hitpaw.com -> hitpaw.com
	 * - cdn.example.co.uk -> example.co.uk
	 *
	 * @param string $host Hostname to extract root domain from
	 * @return string Root domain
	 */
	private function extract_root_domain($host)
	{
		if (empty($host)) {
			return '';
		}

		$parts = explode('.', $host);
		$count = count($parts);

		if ($count <= 2) {
			// Already a root domain (e.g., example.com)
			return $host;
		}

		// Common country-code second-level domains (SLDs)
		// These require 3 parts for the root domain (e.g., example.co.uk)
		$country_slds = array(
			'co.uk',
			'org.uk',
			'me.uk',
			'ac.uk',
			'co.nz',
			'org.nz',
			'ac.nz',
			'com.au',
			'org.au',
			'net.au',
			'co.jp',
			'ne.jp',
			'or.jp',
			'co.in',
			'org.in',
			'net.in',
			'com.br',
			'org.br',
			'net.br',
			'co.za',
			'org.za',
		);

		// Check if last two parts form a country SLD
		$last_two = $parts[$count - 2] . '.' . $parts[$count - 1];
		if (in_array($last_two, $country_slds, true)) {
			// Return last 3 parts (e.g., example.co.uk)
			return implode('.', array_slice($parts, -3));
		}

		// Standard TLD - return last 2 parts (e.g., hitpaw.com)
		return implode('.', array_slice($parts, -2));
	}

	/**
	 * Check if a missing field is marked as needing manual input
	 *
	 * @param string $field_path Dot-notation field path
	 * @param array $article Article data
	 * @return bool
	 */
	public function is_manual_input_needed($field_path, $article)
	{
		$manual_fields = isset($article['needs_manual_input']) ? (array) $article['needs_manual_input'] : array();
		return in_array($field_path, $manual_fields, true);
	}

	/**
	 * Factual Guard: Compares AI output with ground truth.
	 *
	 * @param array $article Article data
	 * @return array ['errors' => array, 'warnings' => array]
	 */
	private function factual_guard($article)
	{
		$errors   = array();
		$warnings = array();
		$source   = $article['primary_text'] ?? '';

		if (empty($source)) {
			return array('errors' => $errors, 'warnings' => $warnings);
		}

		// 1. Version Check
		if (! empty($article['tech_specs']['version'])) {
			$v = preg_quote($article['tech_specs']['version'], '/');
			if (! preg_match("/\b{$v}\b/i", $source)) {
				$warnings[] = sprintf('Hallucination Risk: Version "%s" not found in source text.', $article['tech_specs']['version']);
			}
		}

		// 2. File Size Check
		if (! empty($article['tech_specs']['file_size'])) {
			$size = preg_quote($article['tech_specs']['file_size'], '/');
			if (! preg_match("/\b{$size}\b/i", $source)) {
				$warnings[] = sprintf('Hallucination Risk: File size "%s" not found in source text.', $article['tech_specs']['file_size']);
			}
		}

		return array('errors' => $errors, 'warnings' => $warnings);
	}
}
