<?php

/**
 * AJAX Manager - Admin
 *
 * Handles all AJAX requests for the wp-admin side of the plugin,
 * including dashboard charts, logs, and admin tools.
 *
 * @package WP_News_MCQ_Generator
 * @version 1.0
 */

if (! defined('ABSPATH')) {
	exit;
}

class NM_AJAX_Admin
{



	// ============================================================================
	// Admin Dashboard Handlers (WITH CACHING)
	// ============================================================================

	private static function bust_admin_caches($caches = array('all'))
	{
		$cache_keys = array(
			'admin_dashboard_stats',
			'admin_duplicate_stats',
			'admin_activity_stats',
			'admin_activity_log',
			'admin_system_health',
			'admin_top_topics',
			'admin_reported_mcqs',
			'admin_blueprint_stats',
		);

		if (in_array('all', $caches)) {
			foreach ($cache_keys as $key) {
				NM_Cache_Manager::delete($key);
			}
			return;
		}

		foreach ($caches as $key) {
			if (in_array($key, $cache_keys)) {
				NM_Cache_Manager::delete($key);
			}
		}
	}

	public static function nm_get_dashboard_stats()
	{
		check_ajax_referer('nm_ajax_dashboard');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		$cache_key   = 'admin_dashboard_stats';
		$flush_cache = ! empty($_POST['flush_cache']);

		// Only use cached data when flush_cache is NOT requested
		if (! $flush_cache) {
			$cached = NM_Cache_Manager::get($cache_key);
			if ($cached !== false) {
				NM_Response_Handler::success($cached);
				return;
			}
		}

		global $wpdb;
		$counts         = wp_count_posts('mcq');
		$total_mcqs     = intval($counts->publish) + intval($counts->draft);
		$reported_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = 'mcq_reported' AND meta_value = 'yes'");

		$coverage = 0;
		if (class_exists('NM_Embedding_Database')) {
			$emb      = (new NM_Embedding_Database())->get_statistics();
			$coverage = $emb['coverage_percentage'] ?? 0;
		}

		$events_table = $wpdb->prefix . 'nm_generation_events';
		$dup_24h      = 0;
		if ($wpdb->get_var("SHOW TABLES LIKE '{$events_table}'") === $events_table) {
			$dup_24h = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$events_table} WHERE event_type='duplicate' AND ts >= %s", gmdate('Y-m-d H:i:s', strtotime('-24 hours'))));
		}
		// Difficulty & Cognitive Level breakdown
		$difficulty_breakdown = array(
			'easy'    => 0,
			'medium'  => 0,
			'hard'    => 0,
			'unknown' => 0,
		);

		$cognitive_breakdown = array(
			'remember'   => 0,
			'understand' => 0,
			'apply'      => 0,
			'analyze'    => 0,
			'evaluate'   => 0,
			'unknown'    => 0,
		);

		// Always compute from post meta on published MCQs.
		// This keeps the dashboard independent of optimizer table state.
		$total_published = intval($counts->publish);

		// Difficulty counts from meta (case/space insensitive)
		$difficulty_keys = array('easy', 'medium', 'hard');
		foreach ($difficulty_keys as $key) {
			$difficulty_breakdown[$key] = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(*)
             FROM {$wpdb->postmeta} pm
             INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
             WHERE p.post_type = 'mcq'
               AND p.post_status = 'publish'
               AND pm.meta_key = 'mcq_difficulty'
               AND LOWER(TRIM(pm.meta_value)) = %s",
					$key
				)
			);
		}

		$sum_known_diff                  = $difficulty_breakdown['easy']
			+ $difficulty_breakdown['medium']
			+ $difficulty_breakdown['hard'];
		$difficulty_breakdown['unknown'] = max(0, $total_published - $sum_known_diff);

		// Cognitive level counts from meta (case/space insensitive)
		$cognitive_keys = array('remember', 'understand', 'apply', 'analyze', 'evaluate');
		foreach ($cognitive_keys as $key) {
			$cognitive_breakdown[$key] = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(*)
             FROM {$wpdb->postmeta} pm
             INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
             WHERE p.post_type = 'mcq'
               AND p.post_status = 'publish'
               AND pm.meta_key = 'mcq_cognitive_level'
               AND LOWER(TRIM(pm.meta_value)) = %s",
					$key
				)
			);
		}

		$sum_known_cl                   = $cognitive_breakdown['remember']
			+ $cognitive_breakdown['understand']
			+ $cognitive_breakdown['apply']
			+ $cognitive_breakdown['analyze']
			+ $cognitive_breakdown['evaluate'];
		$cognitive_breakdown['unknown'] = max(0, $total_published - $sum_known_cl);
		$stats                          = array(
			'total_mcqs'            => $total_mcqs,
			'published_mcqs'        => intval($counts->publish),
			'draft_mcqs'            => intval($counts->draft),
			'reported_mcqs'         => $reported_count,
			'duplicates_24h'        => $dup_24h,
			'embedding_coverage'    => round($coverage, 1),

			// Existing breakdowns
			'difficulty_breakdown'  => $difficulty_breakdown,
			'cognitive_breakdown'   => $cognitive_breakdown,

			// NEW: Duplicate Tool observability
			'duplicate_last_full'   => get_option('nm_duplicate_scan_last_run', ''),         // '' => Never
			'duplicate_last_cursor' => (int) get_option('nm_duplicate_scan_last_cursor', 0), // 0 => N/A
			'duplicate_threshold'   => (float) get_option('nm_similarity_threshold', 0.7),

			// NEW: Current Affairs config surfacing
			'ca_worker_batch'       => (int) get_option('nm_current_affairs_worker_batch', 1),
			'ca_max_queue'          => (int) get_option('nm_current_affairs_max_queue', 50),

			// Buffer API dashboard stats
			'buffer' => self::get_buffer_dashboard_stats(),

			// NEW: Daily Roundup articles dashboard card
			'daily_roundups' => self::get_daily_roundup_stats(),
		);

		NM_Cache_Manager::set($cache_key, $stats, 10 * MINUTE_IN_SECONDS);
		NM_Response_Handler::success($stats);
	}

	/**
	 * Gather Buffer API stats for the dashboard card.
	 */
	private static function get_buffer_dashboard_stats()
	{
		$channel_daily = get_option('nm_buffer_channel_daily', array());
		$today_data    = $channel_daily[gmdate('Y-m-d')] ?? array();

		$today_total    = $today_data['_total'] ?? 0;
		$today_last     = $today_data['_last'] ?? '';
		$today_channels = array();
		if (is_array($today_data)) {
			foreach ($today_data as $key => $val) {
				if (strpos((string) $key, '_') !== 0) {
					$today_channels[$key] = $val;
				}
			}
		}

		$lifetime = array('total' => 0, 'per_service' => array());
		if (class_exists('NM_Buffer_Integration')) {
			$lifetime = NM_Buffer_Integration::get_lifetime_stats();
		}

		return array(
			'enabled'           => (bool) get_option('nm_buffer_enabled', 0),
			'has_token'         => ! empty(get_option('nm_buffer_access_token', '')),
			'daily_limit'       => intval(get_option('nm_buffer_daily_limit', 5)),
			'today_total'       => $today_total,
			'today_last'        => $today_last,
			'today_channels'    => $today_channels,
			'lifetime_total'    => $lifetime['total'],
			'lifetime_services' => $lifetime['per_service'],
		);
	}

	/**
	 * Gather Daily Roundup article stats for the dashboard card.
	 *
	 * Daily roundups are 'post' type posts flagged with meta `_nm_article_type = 'daily_roundup'`.
	 * Returns: total count (all statuses), published today, and draft count.
	 *
	 * @return array { total, published_today, drafts }
	 */
	private static function get_daily_roundup_stats()
	{
		$args = array(
			'post_type'      => 'post',
			'post_status'    => array('publish', 'draft', 'pending', 'private'),
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'no_found_rows'  => true,
			'meta_key'       => '_nm_article_type',
			'meta_value'     => 'daily_roundup',
		);
		$query = new WP_Query($args);

		$total           = 0;
		$published_today = 0;
		$drafts          = 0;

		if (! empty($query->posts)) {
			$total = count($query->posts);
			$today = current_time('Y-m-d');

			foreach ($query->posts as $pid) {
				$status = get_post_status($pid);
				if ($status === 'draft' || $status === 'pending') {
					$drafts++;
				}
				if ($status === 'publish' && get_the_date('Y-m-d', $pid) === $today) {
					$published_today++;
				}
			}
		}

		return array(
			'total'           => $total,
			'published_today' => $published_today,
			'drafts'          => $drafts,
		);
	}

	public static function nm_get_duplicate_stats()
	{
		check_ajax_referer('nm_ajax_dashboard');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		$cache_key   = 'admin_duplicate_stats';
		$flush_cache = ! empty($_POST['flushdata']); // JS sends `flushdata`

		if (! $flush_cache) {
			$cached = NM_Cache_Manager::get($cache_key);
			if ($cached !== false) {
				NM_Response_Handler::success($cached);
				return;
			}
		}

		global $wpdb;
		$events_table = $wpdb->prefix . 'nm_generation_events';

		$exact    = 0;
		$fuzzy    = 0;
		$semantic = 0;

		if ($wpdb->get_var("SHOW TABLES LIKE '{$events_table}'") === $events_table) {

			// Group duplicate events by method over the last 7 days.
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT COALESCE(duplicate_method, 'unknown') AS m, COUNT(*) AS c
                 FROM {$events_table}
                 WHERE event_type = %s
                   AND ts >= %s
                 GROUP BY COALESCE(duplicate_method, 'unknown')",
					'duplicate',
					gmdate('Y-m-d H:i:s', strtotime('-7 days'))
				),
				ARRAY_A
			);

			foreach ($rows as $r) {
				$m     = strtolower($r['m']);
				$count = (int) $r['c'];

				if ($m === 'exact' || $m === 'exact title') {
					$exact += $count;
				} elseif ($m === 'fuzzy') {
					$fuzzy += $count;
				} else {
					// Treat all other methods as "semantic" bucket.
					$semantic += $count;
				}
			}
		}

		$total = $exact + $fuzzy + $semantic;
		$most  = 'N/A';

		if ($total > 0) {
			$maxv = max($exact, $fuzzy, $semantic);
			if ($maxv === $semantic) {
				$most = 'Semantic Match';
			} elseif ($maxv === $fuzzy) {
				$most = 'Fuzzy Match';
			} else {
				$most = 'Exact Match';
			}
		}

		// Keys must match your JS: d.exact, d.semantic, d.total, d.most_common
		$stats = array(
			'exact'       => $exact,
			'fuzzy'       => $fuzzy,
			'semantic'    => $semantic,
			'total'       => $total,
			'most_common' => $most,
		);

		NM_Cache_Manager::set($cache_key, $stats, 10 * MINUTE_IN_SECONDS);
		NM_Response_Handler::success($stats);
	}

	public static function nm_get_activity_stats()
	{
		check_ajax_referer('nm_ajax_dashboard');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		$cache_key = 'admin_activity_stats';
		$cached    = NM_Cache_Manager::get($cache_key);
		if ($cached !== false) {
			NM_Response_Handler::success($cached);
			return;
		}

		global $wpdb;
		$events_table      = $wpdb->prefix . 'nm_generation_events';
		$counts_by_hour    = array_fill(0, 24, 0);
		$duplicates_today  = 0;
		$today_start_local = current_time('Y-m-d 00:00:00');
		$today_start_utc   = get_gmt_from_date($today_start_local);

		if ($wpdb->get_var("SHOW TABLES LIKE '{$events_table}'") === $events_table) {
			// @MODIFIED: Added mcq_id IS NOT NULL to ensure only actual MCQ creations are counted
			// @MODIFIED: Exclude buffer share events (logged as 'created' with mcq_id) from creation stats
			$results = $wpdb->get_results($wpdb->prepare("SELECT ts FROM {$events_table} WHERE event_type = 'created' AND mcq_id IS NOT NULL AND source_type <> 'buffer' AND ts >= %s", $today_start_utc));
			if ($results) {
				foreach ($results as $row) {
					$local_timestamp = strtotime(get_date_from_gmt($row->ts));
					$hour_index      = (int) date('G', $local_timestamp);
					if (isset($counts_by_hour[$hour_index])) {
						++$counts_by_hour[$hour_index];
					}
				}
			}
			$duplicates_today = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$events_table} WHERE event_type = 'duplicate' AND ts >= %s", $today_start_utc));
		}

		$chart_labels = array();
		$chart_data   = array();
		$current_hour = (int) current_time('G');
		for ($i = 0; $i <= $current_hour; $i++) {
			$chart_labels[] = str_pad($i, 2, '0', STR_PAD_LEFT) . ':00';
			$chart_data[]   = $counts_by_hour[$i];
		}

		$total_today  = array_sum($counts_by_hour);
		$success_rate = ($total_today + $duplicates_today) > 0 ? round(($total_today / ($total_today + $duplicates_today)) * 100, 1) : 100;

		$stats = array(
			'hours'        => $chart_labels,
			'counts'       => $chart_data,
			'total'        => $total_today,
			'success_rate' => $success_rate,
		);
		NM_Cache_Manager::set($cache_key, $stats, 10 * MINUTE_IN_SECONDS);
		NM_Response_Handler::success($stats);
	}

	public static function nm_get_activity_log()
	{
		check_ajax_referer('nm_ajax_dashboard');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		$cache_key = 'admin_activity_log';
		$cached    = NM_Cache_Manager::get($cache_key);
		if ($cached !== false) {
			NM_Response_Handler::success($cached);
			return;
		}

		global $wpdb;
		$events_table = $wpdb->prefix . 'nm_generation_events';
		$entries      = array();

		if ($wpdb->get_var("SHOW TABLES LIKE '{$events_table}'") === $events_table) {
			$rows = $wpdb->get_results(
				"SELECT ts, event_type, severity, error_message, question_excerpt
     FROM {$events_table}
     WHERE error_message IS NULL
        OR error_message NOT LIKE '%CRON%'
     ORDER BY id DESC
     LIMIT 50",
				ARRAY_A
			);
			foreach ($rows as $r) {
				$type    = ($r['severity'] === 'error') ? 'error' : (($r['severity'] === 'duplicate') ? 'duplicate' : (($r['severity'] === 'success') ? 'success' : 'info'));
				$message = $r['error_message'];
				if (empty($message)) {
					$message = ucfirst($r['event_type']);
				}
				$entries[] = array(
					'time'     => get_date_from_gmt($r['ts'], 'Y-m-d H:i:s'),
					'type'     => $type,
					'message'  => esc_html($message),
					'question' => esc_html($r['question_excerpt']),
				);
			}
		}

		NM_Cache_Manager::set($cache_key, $entries, 10 * MINUTE_IN_SECONDS);
		NM_Response_Handler::success($entries);
	}

	public static function nm_get_system_health()
	{
		check_ajax_referer('nm_ajax_dashboard');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}


		$cache_key = 'admin_system_health';
		// ✅ Fix: Respect flush_cache param
		if (empty($_POST['flush_cache'])) {
			$cached = NM_Cache_Manager::get($cache_key);
			if ($cached !== false) {
				NM_Response_Handler::success($cached);
				return;
			}
		}

		global $wpdb;
		$embedding_db = class_exists('NM_Embedding_Database') ? (new NM_Embedding_Database()) : null;
		$stats        = $embedding_db ? $embedding_db->get_statistics() : array(
			'table_size_mb'       => 0,
			'total_embeddings'    => 0,
			'coverage_percentage' => 0,
		);

		$health = array(
			'wp_cron' => array(
				'label'   => 'WordPress Cron',
				'value'   => 'WP Cron Active',
				'status'  => 'good',
				'fixable' => false,
			),
		);
		if (defined('DISABLE_WP_CRON') && DISABLE_WP_CRON) {
			$health['wp_cron']['value']  = 'WP-CRON Disabled';
			$health['wp_cron']['status'] = 'warning';
			$health['wp_cron']['label']  = 'WordPress Cron (Note: Requires server cron)';
		}

		$plugin_crons = array(
			'cron_news'      => 'nm_generate_mcqs_cron',
			'cron_topic'     => 'nm_generate_mcqs_from_topics_cron',
			'cron_feed'      => 'nm_feed_import_cron',
			'cron_ca_feeder' => 'nm_generate_current_affairs_mcq_cron',
			'cron_ca_worker' => 'nm_ca_queue_worker_cron',
		);




		// Keep the pending check as it is useful
		$pending_user0_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'mcq' AND post_status = 'pending' AND post_author = 0");
		if ($pending_user0_count > 0) {
			$health['pending_mcqs'] = array(
				'label'   => 'Hidden MCQs (Pending Status)',
				'value'   => $pending_user0_count . ' MCQs hidden',
				'status'  => 'error',
				'fixable' => true,
			);
		}

		foreach ($plugin_crons as $key => $hook) {
			$timestamp = wp_next_scheduled($hook);
			$label     = ucwords(str_replace(array('cron_', '_'), ' ', $key));

			$is_enabled = true;
			if ($hook === 'nm_generate_mcqs_cron') {
				$is_enabled = get_option('nm_news_generation_enabled', 0) && get_option('nm_news_cron_schedule', 'hourly') !== 'disabled';
			}
			if ($hook === 'nm_generate_mcqs_from_topics_cron') {
				$is_enabled = get_option('nm_topic_generation_enabled', 0) && get_option('nm_topic_cron_schedule', 'hourly') !== 'disabled';
			}
			if ($hook === 'nm_feed_import_cron') {
				$is_enabled = get_option('nm_feed_importer_enabled', 0) && get_option('nm_feed_importer_cron_schedule', 'hourly') !== 'disabled';
			}
			if ($hook === 'nm_generate_current_affairs_mcq_cron' || $hook === 'nm_ca_queue_worker_cron') {
				$is_enabled = get_option('nm_current_affairs_enabled', 0);
			}

			if (! $is_enabled) {
				$health[$key] = array(
					'label'   => 'Cron: ' . $label,
					'value'   => 'Disabled',
					'status'  => 'good',
					'fixable' => false,
				);
				continue;
			}

			if ($timestamp) {
				if ($timestamp < time()) {
					$health[$key] = array(
						'label'   => 'Cron: ' . $label,
						'value'   => 'Stuck (Overdue)',
						'status'  => 'error',
						'fixable' => true,
					);
				} else {
					$time_until     = $timestamp - time();
					$display_time   = $time_until < 120 ? $time_until . ' seconds' : human_time_diff(time(), $timestamp);
					$health[$key] = array(
						'label'   => 'Cron: ' . $label,
						'value'   => 'Scheduled (' . $display_time . ')',
						'status'  => 'good',
						'fixable' => false,
					);
				}
			} else {
				$health[$key] = array(
					'label'   => 'Cron: ' . $label,
					'value'   => 'Not Scheduled',
					'status'  => 'error',
					'fixable' => true,
				);
			}
		}

		$health['db_size']    = array(
			'label'   => 'Embedding DB Size',
			'value'   => (float) $stats['table_size_mb'] . ' MB',
			'status'  => ((float) $stats['table_size_mb'] < 100 ? 'good' : 'warning'),
			'fixable' => false,
		);
		$health['embeddings'] = array(
			'label'   => 'Embedding Coverage',
			'value'   => (int) $stats['total_embeddings'] . ' (' . $stats['coverage_percentage'] . '%)',
			'status'  => ((float) $stats['coverage_percentage'] > 90 ? 'good' : 'warning'),
			'fixable' => false,
		);

		$events_table     = $wpdb->prefix . 'nm_generation_events';
		$mcqs_today_count = 0;
		if ($wpdb->get_var("SHOW TABLES LIKE '{$events_table}'") === $events_table) {
			$today_start_local = current_time('Y-m-d 00:00:00');
			$today_start_utc   = get_gmt_from_date($today_start_local);
			// @MODIFIED: Added mcq_id IS NOT NULL to ensure only actual MCQ creations are counted
			$mcqs_today_count  = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$events_table} WHERE event_type = 'created' AND mcq_id IS NOT NULL AND ts >= %s", $today_start_utc));
		}

		$health['mcqs_today'] = array(
			'label'   => 'MCQs Created Today',
			'value'   => $mcqs_today_count,
			'status'  => 'good',
			'fixable' => false,
		);

		// ✅ NEW: Current Affairs Queue Stats
		$queue_size  = (int) get_option('nm_ca_processing_queue_size', 0);
		$last_worker = get_option('nm_ca_worker_last_run', 0);
		$next_worker = wp_next_scheduled('nm_ca_queue_worker_cron');

		$health['ca_queue'] = array(
			'label'   => 'Current Affairs Queue',
			'value'   => $queue_size . ' items pending',
			'status'  => ($queue_size > 50 ? 'warning' : 'good'),
			'fixable' => false,
		);

		$health['ca_worker_last'] = array(
			'label'   => 'Worker Last Run',
			'value'   => $last_worker ? human_time_diff($last_worker) . ' ago' : 'Never',
			'status'  => ($last_worker && (time() - $last_worker) < 3600) ? 'good' : 'warning',
			'fixable' => false,
		);

		NM_Cache_Manager::set($cache_key, $health, 10 * MINUTE_IN_SECONDS);
		NM_Response_Handler::success($health);
	}

	// ✅ NEW: Blueprint Stats Handler
	public static function nm_get_blueprint_stats()
	{
		check_ajax_referer('nm_ajax_dashboard');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		$cache_key = 'admin_blueprint_stats';
		$cached    = NM_Cache_Manager::get($cache_key);
		if ($cached !== false) {
			NM_Response_Handler::success($cached);
			return;
		}

		// 1. Define Blueprints (This should ideally come from options, but hardcoded for now as per request context)
		$blueprints = array(
			'CSS Exam' => array(
				'target_hard'   => 70,
				'target_medium' => 30,
				'context'       => 'css',
			),
			'PMS Exam' => array(
				'target_hard'   => 60,
				'target_medium' => 40,
				'context'       => 'pms',
			),
			'NTS Exam' => array(
				'target_hard'   => 40,
				'target_medium' => 60,
				'context'       => 'nts',
			),
		);

		global $wpdb;
		$stats = array();

		foreach ($blueprints as $name => $bp) {
			// Fetch actual stats from last 30 days
			// Note: This assumes we can filter by context/category.
			// If context isn't stored directly, we might need to rely on category mapping or just global stats if context is missing.
			// For this implementation, we'll simulate "Context" filtering by checking if the term exists,
			// otherwise we fall back to global stats for demonstration or use a meta key if available.

			// REAL IMPLEMENTATION: Check for 'mcq_context' meta key which should be saved during generation
			$sql = "SELECT pm_diff.meta_value as difficulty, COUNT(*) as count
                    FROM {$wpdb->posts} p
                    JOIN {$wpdb->postmeta} pm_diff ON p.ID = pm_diff.post_id
                    JOIN {$wpdb->postmeta} pm_ctx ON p.ID = pm_ctx.post_id
                    WHERE p.post_type = 'mcq' 
                    AND p.post_status = 'publish'
                    AND p.post_date > %s
                    AND pm_diff.meta_key = 'mcq_difficulty'
                    AND pm_ctx.meta_key = 'mcq_context'
                    AND pm_ctx.meta_value = %s
                    GROUP BY pm_diff.meta_value";

			$results = $wpdb->get_results($wpdb->prepare($sql, date('Y-m-d H:i:s', strtotime('-30 days')), $bp['context']));

			$total      = 0;
			$hard_count = 0;

			foreach ($results as $row) {
				$count  = (int) $row->count;
				$total += $count;
				if (strtolower(trim($row->difficulty)) === 'hard') {
					$hard_count += $count;
				}
			}

			$actual_hard = $total > 0 ? round(($hard_count / $total) * 100) : 0;
			$drift       = abs($bp['target_hard'] - $actual_hard);

			$stats[] = array(
				'name'        => $name,
				'target_hard' => $bp['target_hard'],
				'actual_hard' => $actual_hard,
				'drift'       => $drift,
				'total_count' => $total,
			);
		}

		NM_Cache_Manager::set($cache_key, $stats, 10 * MINUTE_IN_SECONDS);
		NM_Response_Handler::success($stats);
	}

	// ✅ Buffer Dashboard Stats
	public static function nm_get_buffer_stats()
	{
		check_ajax_referer('nm_ajax_dashboard');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		$channel_daily = get_option('nm_buffer_channel_daily', array());
		$today_data    = $channel_daily[gmdate('Y-m-d')] ?? array();

		$today_total   = $today_data['_total'] ?? 0;
		$today_last    = $today_data['_last'] ?? '';
		$today_channels = array();
		foreach ($today_data as $key => $val) {
			if (strpos($key, '_') !== 0) {
				$today_channels[$key] = $val;
			}
		}

		$lifetime = array('total' => 0, 'per_service' => array());
		if (class_exists('NM_Buffer_Integration')) {
			$lifetime = NM_Buffer_Integration::get_lifetime_stats();
		}

		NM_Response_Handler::success(array(
			'enabled'        => (bool) get_option('nm_buffer_enabled', 0),
			'has_token'      => ! empty(get_option('nm_buffer_access_token', '')),
			'daily_limit'    => intval(get_option('nm_buffer_daily_limit', 5)),
			'today_total'    => $today_total,
			'today_last'     => $today_last,
			'today_channels' => $today_channels,
			'lifetime_total' => $lifetime['total'],
			'lifetime_services' => $lifetime['per_service'],
		));
	}

	public static function nm_refresh_buffer_channels()
	{
		check_ajax_referer('nm_refresh_buffer_channels');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		if (class_exists('NM_Buffer_Integration')) {
			NM_Buffer_Integration::clear_all_caches();
		}

		NM_Response_Handler::success(array('message' => 'Buffer caches cleared.'));
	}

	public static function nm_get_top_topics()
	{
		check_ajax_referer('nm_ajax_dashboard');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		$cache_key = 'admin_top_topics';
		$cached    = NM_Cache_Manager::get($cache_key);
		if ($cached !== false) {
			NM_Response_Handler::success($cached);
			return;
		}

		$terms  = get_terms(
			array(
				'taxonomy'   => 'topic',
				'orderby'    => 'count',
				'order'      => 'DESC',
				'number'     => 10,
				'hide_empty' => true,
			)
		);
		$topics = array();
		foreach ((array) $terms as $t) {
			if (is_wp_error($t)) {
				continue;
			}
			$topics[] = array(
				'name'  => esc_html($t->name),
				'count' => (int) $t->count,
			);
		}

		NM_Cache_Manager::set($cache_key, $topics, 10 * MINUTE_IN_SECONDS);
		NM_Response_Handler::success($topics);
	}

	public static function nm_get_reported_mcqs()
	{
		check_ajax_referer('nm_ajax_dashboard');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		$cache_key = 'admin_reported_mcqs';
		$cached    = NM_Cache_Manager::get($cache_key);
		if ($cached !== false) {
			NM_Response_Handler::success($cached);
			return;
		}

		$reported = get_posts(
			array(
				'post_type'      => 'mcq',
				'meta_key'       => 'mcq_reported',
				'meta_value'     => 'yes',
				'posts_per_page' => 10,
				'orderby'        => 'date',
				'order'          => 'DESC',
			)
		);
		$mcqs     = array();
		foreach ($reported as $p) {
			$mcqs[] = array(
				'title'     => esc_html(get_the_title($p->ID)),
				'count'     => (int) (get_post_meta($p->ID, 'mcq_report_count', true) ?: 1),
				'edit_link' => esc_url(get_edit_post_link($p->ID)),
			);
		}

		NM_Cache_Manager::set($cache_key, $mcqs, 10 * MINUTE_IN_SECONDS);
		NM_Response_Handler::success($mcqs);
	}

	public static function nm_clear_activity_log()
	{
		check_ajax_referer('nm_ajax_dashboard');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		global $wpdb;
		$cleared      = array(
			'database' => false,
			'options'  => false,
		);
		$events_table = $wpdb->prefix . 'nm_generation_events';

		if ($wpdb->get_var("SHOW TABLES LIKE '{$events_table}'") === $events_table) {
			$result = $wpdb->query("TRUNCATE TABLE {$events_table}");
			if ($result !== false) {
				$cleared['database'] = true;
			} else {
				NM_Response_Handler::error('Failed to clear activity log from database: ' . $wpdb->last_error, 'db_truncate_failed');
				return;
			}
		}

		update_option('nm_activity_log', array(), false);
		$cleared['options'] = true;

		// Bust relevant caches
		self::bust_admin_caches(array('admin_activity_log', 'admin_activity_stats'));

		NM_Response_Handler::success(
			array(
				'message' => 'Activity log cleared successfully',
				'cleared' => $cleared,
			)
		);
	}

	// ============================================================================
	// ✅ NEW: Dedicated Logs Page AJAX delegating to NM_Generation_Logger
	// ============================================================================

	/**
	 * Paginated, filtered log rows for the Logs admin page.
	 */
	public static function nm_get_logs_page()
	{
		check_ajax_referer('nm_ajax_dashboard');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		if (! class_exists('NM_Generation_Logger')) {
			NM_Response_Handler::error('Generation Logger is unavailable.', 'logger_missing');
			return;
		}

		$result = NM_Generation_Logger::query_logs(
			array(
				'severity'    => isset($_POST['severity']) ? sanitize_key(wp_unslash($_POST['severity'])) : '',
				'event_type'  => isset($_POST['event_type']) ? sanitize_key(wp_unslash($_POST['event_type'])) : '',
				'source_type' => isset($_POST['source_type']) ? sanitize_key(wp_unslash($_POST['source_type'])) : '',
				'search'      => isset($_POST['search']) ? sanitize_text_field(wp_unslash($_POST['search'])) : '',
				'per_page'    => isset($_POST['perPage']) ? (int) $_POST['perPage'] : NM_Generation_Logger::LOGS_PAGE_SIZE,
				'page'        => isset($_POST['page']) ? (int) $_POST['page'] : 1,
			)
		);

		NM_Response_Handler::success($result);
	}

	/**
	 * Aggregate counts shown above the Logs table.
	 */
	public static function nm_get_logs_stats()
	{
		check_ajax_referer('nm_ajax_dashboard');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		if (! class_exists('NM_Generation_Logger')) {
			NM_Response_Handler::error('Generation Logger is unavailable.', 'logger_missing');
			return;
		}

		NM_Response_Handler::success(NM_Generation_Logger::get_log_stats());
	}

	/**
	 * Purge logs by retention (mode=retention) or truncate (mode=all).
	 */
	public static function nm_purge_logs()
	{
		check_ajax_referer('nm_ajax_dashboard');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		if (! class_exists('NM_Generation_Logger')) {
			NM_Response_Handler::error('Generation Logger is unavailable.', 'logger_missing');
			return;
		}

		$mode = isset($_POST['mode']) ? sanitize_key(wp_unslash($_POST['mode'])) : 'retention';

		// Run the destructive action FIRST so the audit row we insert afterwards
		// survives when mode=all (TRUNCATE). For mode=retention the audit row is
		// 'now' so retention >= 1 day never deletes it.
		$result = ('all' === $mode)
			? NM_Generation_Logger::purge_all_logs()
			: NM_Generation_Logger::purge_old_logs();

		// Log AFTER the action so the trail is never erased by the same call.
		if (class_exists('NM_Generation_Logger')) {
			NM_Generation_Logger::nm_log_activity(
				'[LOGS] Manual purge from admin Logs page (mode=' . $mode . ') — deleted ' . (int) $result['events_deleted'] . ' events / ' . (int) $result['runs_deleted'] . ' runs',
				'warning'
			);
		}

		// Bust any activity caches the Admin Dashboard widget uses.
		self::bust_admin_caches(array('admin_activity_log', 'admin_activity_stats'));

		NM_Response_Handler::success($result);
	}

	/**
	 * Stream the filtered log as a CSV download.
	 */
	public static function nm_download_logs_csv()
	{
		// Suppress output buffering to avoid corrupting the file stream.
		while (ob_get_level() > 0) {
			ob_end_clean();
		}

		// Non-die form so we can send a clean response below.
		if (false === check_ajax_referer('nm_ajax_dashboard', '_ajax_nonce', false)) {
			status_header(403);
			nocache_headers();
			wp_die('Invalid or expired download link. Please reload the Logs page and click Download again.');
		}

		if (! current_user_can('manage_options')) {
			status_header(403);
			nocache_headers();
			wp_die('Access denied');
		}

		if (! class_exists('NM_Generation_Logger')) {
			status_header(500);
			nocache_headers();
			wp_die('Generation Logger unavailable.');
		}

		// Same input shape as the page AJAX; accept either GET or POST.
		$source = array();
		if (! empty($_POST)) {
			$source = $_POST;
		} elseif (! empty($_GET)) {
			$source = $_GET;
		}

		$csv = NM_Generation_Logger::build_logs_csv(
			array(
				'severity'    => isset($source['severity']) ? sanitize_key(wp_unslash($source['severity'])) : '',
				'event_type'  => isset($source['event_type']) ? sanitize_key(wp_unslash($source['event_type'])) : '',
				'source_type' => isset($source['source_type']) ? sanitize_key(wp_unslash($source['source_type'])) : '',
				'search'      => isset($source['search']) ? sanitize_text_field(wp_unslash($source['search'])) : '',
			)
		);

		nocache_headers();
		header('Content-Type: text/csv; charset=utf-8');
		header('Content-Disposition: attachment; filename="mcq-generation-log-' . gmdate('Ymd-His') . '.csv"');

		// Optional audit log.
		if (class_exists('NM_Generation_Logger')) {
			NM_Generation_Logger::nm_log_activity(
				'[LOGS] CSV download streamed from admin Logs page',
				'info'
			);
		}

		echo $csv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		exit;
	}

	// ============================================================================
	// Admin Generation & Backfill Handlers
	// ============================================================================

	public static function nm_run_generation_for_category_callback()
	{
		check_ajax_referer('nm_ajax_generate_nonce');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		$category = sanitize_text_field($_POST['category']);
		if (empty($category)) {
			NM_Response_Handler::error('Category not specified.', 'no_category');
			return;
		}

		// Check Global Smart Schedule Setting
		$smart_schedule_global = get_option('nm_scheduler_enabled', 0);
		$override_status       = $smart_schedule_global ? 'smart_schedule' : null;

		list($count, $log) = NM_Generation_Service::generate_mcqs_from_news_sync(array($category), $override_status);

		// Ensure scheduler is running if needed
		if ($smart_schedule_global && class_exists('NMPublicationScheduler')) {
			NMPublicationScheduler::maybe_schedule_first_event();
		}

		// Bust caches
		self::bust_admin_caches(array('admin_dashboard_stats', 'admin_activity_stats', 'admin_activity_log', 'admin_top_topics', 'admin_duplicate_stats'));

		NM_Response_Handler::success(
			array(
				'log'   => $log,
				'count' => $count,
			)
		);
	}

	public static function nm_run_generation_for_topic_callback()
	{
		check_ajax_referer('nm_ajax_generate_nonce');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		$topic_id = isset($_POST['topic_id']) ? intval($_POST['topic_id']) : 0;
		if (empty($topic_id)) {
			NM_Response_Handler::error('Topic ID not specified.', 'no_topic_id');
			return;
		}

		// Check Global Smart Schedule Setting
		$smart_schedule_global = get_option('nm_scheduler_enabled', 0);
		$override_status       = $smart_schedule_global ? 'smart_schedule' : null;

		list($count, $log) = NM_Generation_Service::generate_mcqs_from_topics_sync(array($topic_id), $override_status);

		// Ensure scheduler is running if needed
		if ($smart_schedule_global && class_exists('NMPublicationScheduler')) {
			NMPublicationScheduler::maybe_schedule_first_event();
		}

		// Bust caches
		self::bust_admin_caches(array('admin_dashboard_stats', 'admin_activity_stats', 'admin_activity_log', 'admin_top_topics', 'admin_duplicate_stats'));

		NM_Response_Handler::success(
			array(
				'log'   => $log,
				'count' => $count,
			)
		);
	}

	public static function nm_get_mcqs_without_embedding_callback()
	{
		check_ajax_referer('nm_ajax_dashboard');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		global $wpdb;
		$embedding_table = $wpdb->prefix . 'mcq_embeddings';

		$current_model = class_exists( 'NM_API_Client' ) ? NM_API_Client::get_embedding_model_name() : 'gemini-embedding-2';

		$query = $wpdb->prepare("
        SELECT p.ID
        FROM {$wpdb->posts} AS p
        LEFT JOIN {$embedding_table} AS e ON p.ID = e.post_id AND e.embedding_model = %s
        WHERE p.post_type = 'mcq'
          AND p.post_status IN ('publish', 'draft', 'pending')
          AND e.post_id IS NULL
        ORDER BY p.ID ASC
    ", $current_model);

		$ids = $wpdb->get_col($query);

		NM_Response_Handler::success($ids);
	}

	public static function nm_backfill_single_embedding_callback()
	{
		check_ajax_referer('nm_ajax_dashboard');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		$post_id = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
		if ($post_id === 0) {
			NM_Response_Handler::error('Invalid Post ID', 'invalid_id');
			return;
		}

		$gemini_api_key = NM_API_Client::get_gemini_api_key();
		if (empty($gemini_api_key)) {
			NM_Response_Handler::error('API key not set.', 'no_api_key');
			return;
		}

		$question_text = get_the_title($post_id);
		$embedding     = NM_API_Client::get_instance()->get_embedding($question_text, $gemini_api_key);

		if ($embedding) {
			(new NM_Embedding_Database())->store_embedding($post_id, $question_text, $embedding);
			// Bust cache
			self::bust_admin_caches(array('admin_dashboard_stats'));
			NM_Response_Handler::success();
		} else {
			// @DIAGNOSTIC: log the exact failure context for this MCQ so the
			// real upstream error (quota / 400 / bad input) is captured.
			if (class_exists('NM_Generation_Logger')) {
				NM_Generation_Logger::genlog_event(
					array(
						'event_type'    => 'error',
						'severity'      => 'error',
						'source_type'   => 'embedding',
						'source_ref'    => 'backfill_single',
						'mcq_id'        => $post_id,
						'error_code'    => 'embedding_failed',
						'error_message' => "Failed to generate embedding for MCQ #{$post_id}.",
						'meta'          => array(
							'model'         => class_exists('NM_API_Client') ? NM_API_Client::get_embedding_model_name() : 'unknown',
							'question_text' => $question_text,
						),
					)
				);
			}
			NM_Response_Handler::error("Failed for ID: {$post_id}.", 'embedding_failed');
		}
	}

	public static function nm_migrate_embeddings_callback()
	{
		check_ajax_referer('nm_ajax_dashboard');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		$db     = new NM_Embedding_Database();
		$result = $db->migrate_from_postmeta();

		// Bust cache
		self::bust_admin_caches(array('admin_dashboard_stats'));

		NM_Response_Handler::success($result);
	}

	public static function nm_get_embedding_stats_callback()
	{
		check_ajax_referer('nm_ajax_dashboard');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		$db    = new NM_Embedding_Database();
		$stats = $db->get_statistics();

		NM_Response_Handler::success($stats);
	}

	public static function nm_truncate_embeddings_callback()
	{
		check_ajax_referer('nm_ajax_dashboard');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		$db      = new NM_Embedding_Database();
		$success = $db->truncate_table();

		self::bust_admin_caches(array('admin_dashboard_stats'));

		NM_Response_Handler::success(array('truncated' => $success));
	}

	public static function nm_cleanup_orphaned_embeddings_callback()
	{
		check_ajax_referer('nm_ajax_dashboard');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		$db      = new NM_Embedding_Database();
		$deleted = $db->cleanup_orphaned_embeddings();

		// Bust cache
		self::bust_admin_caches(array('admin_dashboard_stats'));

		NM_Response_Handler::success(array('deleted' => $deleted));
	}

	// ============================================================================
	// Admin Tool Handlers
	// ============================================================================

	public static function nm_run_feed_import_callback()
	{
		check_ajax_referer('nm_admin_action', '_ajax_nonce');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		if (! class_exists('NM_Feed_Importer')) {
			NM_Response_Handler::error('Feed Importer class not found.', 'class_not_found');
			return;
		}

		try {
			// Check Global Smart Schedule Setting
			$smart_schedule_global = get_option('nm_scheduler_enabled', 0);
			$override_status       = $smart_schedule_global ? 'smart_schedule' : null;

			list($count, $log) = NM_Feed_Importer::run_import($override_status);

			// Ensure scheduler is running if needed
			if ($smart_schedule_global && class_exists('NMPublicationScheduler')) {
				NMPublicationScheduler::maybe_schedule_first_event();
			}
			// Bust caches
			self::bust_admin_caches(array('all'));
			NM_Response_Handler::success(
				array(
					'log'   => $log,
					'count' => $count,
				)
			);
		} catch (Exception $e) {
			NM_Response_Handler::error('Error: ' . $e->getMessage(), 'exception');
		}
	}

	public static function ajax_scan_batch_handler()
	{
		check_ajax_referer('nm_admin_nonce');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}
		set_time_limit(60);

		// NEW: mode can be 'full' (scan from 0) or 'since_last' (scan from last full scan cursor)
		$mode       = isset($_POST['mode']) ? sanitize_key($_POST['mode']) : 'full';
		$cursor     = isset($_POST['cursor']) ? intval($_POST['cursor']) : 0;
		$batch_size = isset($_POST['batch_size']) ? intval($_POST['batch_size']) : 200;
		$threshold  = floatval(get_option('nm_similarity_threshold', 0.7));

		global $wpdb;
		$embed_table = $wpdb->prefix . 'mcq_embeddings';

		// ✅ MODIFIED v7.3.11: Fixed total count calculation for incremental scans
		// BUG FIX: Was checking $_POST['cursor'] > 0 which failed on first batch of incremental scan
		$current_model = class_exists( 'NM_API_Client' ) ? NM_API_Client::get_embedding_model_name() : 'gemini-embedding-2';

		if ($mode === 'since_last') {
			$initial_cursor = (int) get_option('nm_duplicate_scan_last_cursor', 0);
			$total          = (int) $wpdb->get_var(
				$wpdb->prepare(
					"
                SELECT COUNT(DISTINCT p.ID)
                FROM {$wpdb->posts} p
                INNER JOIN {$embed_table} e ON p.ID = e.post_id
                WHERE p.post_type = 'mcq'
                  AND p.post_status IN ('publish', 'draft', 'pending')
                  AND e.embedding_model = %s
                  AND p.ID > %d
            ",
					$current_model,
					$initial_cursor
				)
			);
		} else {
			$total = (int) $wpdb->get_var(
				$wpdb->prepare(
					"
                SELECT COUNT(DISTINCT p.ID)
                FROM {$wpdb->posts} p
                INNER JOIN {$embed_table} e ON p.ID = e.post_id
                WHERE p.post_type = 'mcq'
                  AND p.post_status IN ('publish', 'draft', 'pending')
                  AND e.embedding_model = %s
            ",
					$current_model
				)
			);
		}

		// ---------------------------------------------------------------------
		// If this is the very first call (cursor=0) and mode='since_last',
		// initialize cursor from last full scan; fallback to full if no prior scan
		// ---------------------------------------------------------------------
		if ($cursor === 0 && $mode === 'since_last') {
			$metadata    = self::get_last_scan_metadata();
			$last_cursor = $metadata['last_cursor'];

			if ($last_cursor > 0) {
				// Resume from the last full scan
				$cursor = $last_cursor;
			} else {
				// No previous scan => force full mode
				$mode = 'full';
			}
		}

		// Fetch the batch
		$results = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT p.ID, p.post_title, e.embedding, pm_ans.meta_value AS correct_answer
             FROM {$wpdb->posts} p
             INNER JOIN {$embed_table} e ON p.ID = e.post_id
             INNER JOIN {$wpdb->postmeta} pm_ans
               ON p.ID = pm_ans.post_id AND pm_ans.meta_key = 'mcq_answer'
             WHERE p.post_type = 'mcq'
               AND p.post_status IN ('publish', 'draft', 'pending')
               AND e.embedding_model = %s
               AND p.ID > %d
             ORDER BY p.ID ASC
             LIMIT %d",
				$current_model,
				$cursor,
				$batch_size
			),
			ARRAY_A
		);

		// Group by answer, check similarity
		$by_answer = array();
		foreach ($results as $row) {
			$emb = json_decode($row['embedding'], true);
			if (! is_array($emb) || empty($emb)) {
				continue;
			}

			$post_id      = (int) $row['ID'];
			$correct_code = (string) $row['correct_answer'];
			$options_data = get_post_meta($post_id, 'mcq_options', true);
			$answer_text  = (is_array($options_data) && isset($options_data[$correct_code]))
				? trim($options_data[$correct_code])
				: trim($correct_code);

			$answer_key = strtolower($answer_text);
			if (! isset($by_answer[$answer_key])) {
				$by_answer[$answer_key] = array();
			}

			$by_answer[$answer_key][] = array(
				'id'                  => $post_id,
				'title'               => $row['post_title'],
				'embedding'           => $emb,
				'correct_answer_text' => $correct_code . '. ' . $answer_text,
				'edit_link'           => get_edit_post_link($post_id),
				'answer_display'      => $answer_text,
			);
		}

		// Find groups above threshold
		$groups = array();
		foreach ($by_answer as $answer => $mcqs) {
			if (count($mcqs) < 2) {
				continue;
			}

			$processed = array();
			for ($i = 0; $i < count($mcqs); $i++) {
				if (in_array($mcqs[$i]['id'], $processed)) {
					continue;
				}

				$group   = array();
				$all_ids = array();
				for ($j = $i + 1; $j < count($mcqs); $j++) {
					if (in_array($mcqs[$j]['id'], $processed)) {
						continue;
					}

					$sim = self::nm_fallback_cosine($mcqs[$i]['embedding'], $mcqs[$j]['embedding']);
					if ($sim >= $threshold) {
						if (empty($group)) {
							$group[]     = array(
								'id'                  => $mcqs[$i]['id'],
								'title'               => $mcqs[$i]['title'],
								'similarity'          => null,
								'correct_answer_text' => $mcqs[$i]['correct_answer_text'],
								'edit_link'           => $mcqs[$i]['edit_link'],
							);
							$all_ids[]   = $mcqs[$i]['id'];
							$processed[] = $mcqs[$i]['id'];
						}

						$group[]     = array(
							'id'                  => $mcqs[$j]['id'],
							'title'               => $mcqs[$j]['title'],
							'similarity'          => $sim,
							'correct_answer_text' => $mcqs[$j]['correct_answer_text'],
							'edit_link'           => $mcqs[$j]['edit_link'],
						);
						$all_ids[]   = $mcqs[$j]['id'];
						$processed[] = $mcqs[$j]['id'];
					}
				}

				if (! empty($group)) {
					$groups[] = array(
						'questions'   => $group,
						'all_ids'     => $all_ids,
						'answer_text' => $mcqs[$i]['answer_display'],
					);
				}
			}
		}

		// Determine next cursor and whether more rows exist
		$batch_count = count($results);
		$next_cursor = 0;
		if ($batch_count > 0) {
			$last_row    = end($results);
			$next_cursor = isset($last_row['ID']) ? intval($last_row['ID']) : 0;
			reset($results);
		}

		$has_more = ($batch_count === $batch_size && $next_cursor > 0);

		// If this is the end of a *full* scan, update last scan metadata
		if (! $has_more && $mode === 'full' && $next_cursor > 0) {
			self::update_last_scan_metadata($next_cursor);
		}

		NM_Response_Handler::success(
			array(
				'groups'          => $groups,
				'groups_in_batch' => count($groups),
				'has_more'        => $has_more,
				'next_cursor'     => $next_cursor,
				'batch_count'     => $batch_count,
				'total'           => $total,
				'mode'            => $mode, // Echo back the mode so JS knows which it's running
			)
		);
	}

	public static function ajax_consolidate_duplicates_handler()
	{
		check_ajax_referer('nm_admin_nonce');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		set_time_limit(60);
		$keep_id = isset($_POST['keep_id']) ? intval($_POST['keep_id']) : 0;
		$all_ids = isset($_POST['all_ids']) ? json_decode(stripslashes($_POST['all_ids']), true) : array();

		if (! $keep_id || ! is_array($all_ids)) {
			NM_Response_Handler::error('Invalid data', 'invalid_data');
			return;
		}

		$delete_ids = array_diff($all_ids, array($keep_id));
		if (empty($delete_ids)) {
			NM_Response_Handler::error('No questions to delete', 'no_deletions');
			return;
		}

		$keep_url       = get_permalink($keep_id);
		$deleted_count  = 0;
		$redirect_count = 0;

		foreach ($delete_ids as $delete_id) {
			$delete_id  = intval($delete_id);
			$delete_url = get_permalink($delete_id);
			$deleted    = wp_delete_post($delete_id, true);

			if ($deleted) {
				++$deleted_count;
				if (class_exists('RankMath') && method_exists('\RankMath\Redirections\DB', 'add')) {
					try {
						\RankMath\Redirections\DB::add(
							array(
								'url_to'      => $keep_url,
								'sources'     => array(
									array(
										'pattern'    => parse_url($delete_url, PHP_URL_PATH),
										'comparison' => 'exact',
									),
								),
								'header_code' => '301',
							)
						);
						++$redirect_count;
					} catch (Exception $e) { /* silent */
					}
				}
			}
		}

		if ($deleted_count > 0) {
			// Bust all caches
			self::bust_admin_caches(array('all'));
			NM_Response_Handler::success(array('message' => sprintf('Deleted %d question(s), created %d redirect(s)', $deleted_count, $redirect_count)));
		} else {
			NM_Response_Handler::error('Failed to delete', 'delete_failed');
		}
	}

	public static function nm_test_news_sources_callback()
	{
		// MUST match the nonce/action used on the News Sources page
		check_ajax_referer('nm_ajax_dashboard', '_ajax_nonce');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		if (! class_exists('NM_Advanced_News_Sources')) {
			NM_Response_Handler::error('News Sources class not found.', 'class_not_found');
			return;
		}

		$sources         = NM_Advanced_News_Sources::get_sources();
		$enabled_sources = isset($_POST['enabled_sources'])
			? array_map('sanitize_text_field', $_POST['enabled_sources'])
			: array_keys($sources);

		$results = array();

		foreach ($enabled_sources as $source_key) {
			if (! isset($sources[$source_key])) {
				continue;
			}
			$source   = $sources[$source_key];
			$articles = NM_Advanced_News_Sources::fetch_articles($source_key, 5);

			$results[] = array(
				'key'           => $source_key,
				'name'          => $source['name'],
				'success'       => ! empty($articles),
				'article_count' => count($articles),
				'message'       => ! empty($articles)
					? 'Successfully fetched articles'
					: 'Failed to fetch articles',
			);
		}

		NM_Response_Handler::success(array('results' => $results));
	}

	public static function nm_bulk_generate_batch()
	{
		@set_time_limit(120);
		check_ajax_referer('nm_bulk_generation', 'nm_bulk_nonce');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		$mcq_count_before = wp_count_posts('mcq')->publish;
		$generation_type  = sanitize_text_field($_POST['generation_type'] ?? 'mixed');
		$batch_size       = intval($_POST['batch_size'] ?? 2);
		$publish_status   = sanitize_text_field($_POST['publish_status'] ?? 'publish');
		$log              = array();
		$generated        = 0;

		try {
			$gemini_key = NM_API_Client::get_gemini_api_key();
			$gnews_key  = NM_API_Client::get_gnews_api_key();
			if (empty($gemini_key)) {
				NM_Response_Handler::error('Gemini API key missing', 'no_api_key');
				return;
			}

			$log[] = '🚀 Starting batch generation...';
			$log[] = 'Type: ' . ucfirst($generation_type) . " | Batch size: {$batch_size}";

			if (($generation_type === 'news' || $generation_type === 'mixed') && ! empty($gnews_key)) {
				$categories = isset($_POST['news_categories']) ? $_POST['news_categories'] : array('general');
				$category   = $categories[array_rand($categories)];
				$log[]      = '📰 Category: ' . ucfirst($category);
				if (class_exists('NM_Generation_Service')) {
					try {
						list($count, $generation_log) = NM_Generation_Service::generate_mcqs_from_news_sync(array($category));
						foreach ($generation_log as $entry) {
							if (strpos($entry, 'INFO:') === false) {
								$cleaned = trim(str_replace(array('SUCCESS:', 'ERROR:', 'GEMINI API'), '', $entry));
								if (! empty($cleaned) && ! in_array($cleaned, $log)) {
									$log[] = $cleaned;
								}
							}
						}
					} catch (Exception $e) {
						$log[] = '❌ Error: ' . $e->getMessage();
					}
				}
			} elseif ($generation_type === 'topics' && isset($_POST['topics'])) {
				$topics = array_map('intval', $_POST['topics']);
				if (! empty($topics)) {
					$topic_id = $topics[array_rand($topics)];
					$topic    = get_term($topic_id, 'topic');
					if ($topic && ! is_wp_error($topic)) {
						$log[] = '🏷️ Topic: ' . $topic->name;
						if (class_exists('NM_Generation_Service')) {
							try {
								list($count, $generation_log) = NM_Generation_Service::generate_mcqs_from_topics_sync(array($topic_id));
								foreach ($generation_log as $entry) {
									if (strpos($entry, 'INFO:') === false) {
										$cleaned = trim(str_replace(array('SUCCESS:', 'ERROR:'), '', $entry));
										if (! empty($cleaned) && ! in_array($cleaned, $log)) {
											$log[] = $cleaned;
										}
									}
								}
							} catch (Exception $e) {
								$log[] = '❌ Error: ' . $e->getMessage();
							}
						}
					}
				}
			}

			$mcq_count_after  = wp_count_posts('mcq')->publish;
			$actual_generated = $mcq_count_after - $mcq_count_before;

			// Check Global Smart Schedule Setting
			$smart_schedule_global = get_option('nm_scheduler_enabled', 0);

			if ($smart_schedule_global) {
				$publish_status = 'smart_schedule';
			}

			if ($actual_generated > 0 && ($publish_status === 'draft' || $publish_status === 'smart_schedule')) {
				$log[]       = '📌 Converting to ' . ($publish_status === 'draft' ? 'drafts' : 'smart queue') . '...';
				$recent_mcqs = get_posts(
					array(
						'post_type'      => 'mcq',
						'posts_per_page' => $actual_generated,
						'orderby'        => 'date',
						'order'          => 'DESC',
						'post_status'    => 'publish',
					)
				);
				foreach ($recent_mcqs as $mcq) {
					wp_update_post(
						array(
							'ID'          => $mcq->ID,
							'post_status' => 'draft',
						)
					);
					if ($publish_status === 'smart_schedule') {
						update_post_meta($mcq->ID, '_nm_ready_for_publish', 'yes');
					}
				}
				$log[] = '✅ Saved as ' . ($publish_status === 'draft' ? 'drafts' : 'ready for scheduler');

				// Ensure scheduler is running
				if ($publish_status === 'smart_schedule' && class_exists('NMPublicationScheduler')) {
					NMPublicationScheduler::maybe_schedule_first_event();
				}
			}

			$log[] = '───────────────────';
			if ($actual_generated > 0) {
				$log[] = "✅ Batch complete: {$actual_generated} MCQ(s) generated";
			} else {
				$log[] = '⚠️️ No MCQs created (duplicates or unsuitable content)';
			}

			// Bust all caches
			self::bust_admin_caches(array('all'));

			NM_Response_Handler::success(
				array(
					'generated' => $actual_generated,
					'log'       => $log,
				)
			);
		} catch (Exception $e) {
			NM_Response_Handler::error('Server error: ' . $e->getMessage(), 'exception', array('log' => $log));
		}
	}

	// ============================================================================
	// Private Helper Functions
	// ============================================================================

	/**
	 * Fallback cosine similarity calculation.
	 */
	private static function nm_fallback_cosine(array $vec1, array $vec2)
	{
		$dot_product = 0.0;
		$norm_a      = 0.0;
		$norm_b      = 0.0;
		$count       = min(count($vec1), count($vec2));

		if ($count === 0) {
			return 0.0;
		}

		for ($i = 0; $i < $count; $i++) {
			$v1           = (float) $vec1[$i];
			$v2           = (float) $vec2[$i];
			$dot_product += $v1 * $v2;
			$norm_a      += $v1 * $v1;
			$norm_b      += $v2 * $v2;
		}

		$magnitude = sqrt($norm_a) * sqrt($norm_b);
		if ($magnitude == 0) {
			return 0.0;
		}

		$similarity = $dot_product / $magnitude;
		return max(0, min(1, $similarity));
	}
	/**
	 * Get metadata about the last full duplicate scan.
	 *
	 * @return array ['last_cursor' => int, 'last_run' => string (timestamp)]
	 */
	private static function get_last_scan_metadata()
	{
		return array(
			'last_cursor' => (int) get_option('nm_duplicate_scan_last_cursor', 0),
			'last_run'    => get_option('nm_duplicate_scan_last_run', ''),
		);
	}

	/**
	 * Update last full scan metadata.
	 * Should only be called when a full scan completes successfully.
	 *
	 * @param int $cursor The last cursor processed (highest MCQ ID in final batch).
	 */
	private static function update_last_scan_metadata($cursor)
	{
		update_option('nm_duplicate_scan_last_cursor', (int) $cursor);
		update_option('nm_duplicate_scan_last_run', current_time('mysql'));
	}

	// ============================================================================
	// E-A-T Data Backfill
	// ============================================================================

	/**
	 * Backfill E-A-T data for all existing MCQs
	 * Sets: author_name = 'TheQuizWire', fact_checked = 'yes', difficulty = 'medium' (if empty)
	 */
	public static function nm_backfill_eat_data_callback()
	{
		check_ajax_referer('nm_ajax_dashboard');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		global $wpdb;

		// Get all MCQ post IDs
		$mcq_ids = $wpdb->get_col(
			"
            SELECT ID 
            FROM {$wpdb->posts} 
            WHERE post_type = 'mcq' 
            AND post_status = 'publish'
        "
		);

		if (empty($mcq_ids)) {
			NM_Response_Handler::error('No MCQs found to backfill.');
			return;
		}

		$total   = count($mcq_ids);
		$updated = 0;
		$skipped = 0;

		foreach ($mcq_ids as $post_id) {
			$updated_fields = array();

			// Set author_name if empty
			$author_name = get_post_meta($post_id, 'mcq_author_name', true);
			if (empty($author_name)) {
				$user = get_userdata(get_post_field('post_author', $post_id));
				$display_name = $user ? $user->display_name : get_bloginfo('name');
				update_post_meta($post_id, 'mcq_author_name', sanitize_text_field($display_name));
				$updated_fields[] = 'author';
			}

			// Set fact_checked if empty
			$fact_checked = get_post_meta($post_id, 'mcq_fact_checked', true);
			if (empty($fact_checked)) {
				update_post_meta($post_id, 'mcq_fact_checked', 'yes');
				$updated_fields[] = 'fact_checked';
			}

			// Set difficulty if empty
			$difficulty = get_post_meta($post_id, 'mcq_difficulty', true);
			if (empty($difficulty)) {
				update_post_meta($post_id, 'mcq_difficulty', 'medium');
				$updated_fields[] = 'difficulty';
			}

			if (! empty($updated_fields)) {
				++$updated;
			} else {
				++$skipped;
			}
		}

		// Clear relevant caches
		self::bust_admin_caches(array('admin_dashboard_stats'));

		NM_Response_Handler::success(
			array(
				'total'   => $total,
				'updated' => $updated,
				'skipped' => $skipped,
				'message' => sprintf(
					'Backfill complete: %d MCQs updated, %d already had E-A-T data.',
					$updated,
					$skipped
				),
			)
		);
	}

	// ============================================================================
	// System Health Fixes
	// ============================================================================

	/**
	 * Fixes stuck crons or other system health issues.
	 * Triggered by the "Fix" button in the System Health widget.
	 */
	public static function nm_ajax_reset_stuck_crons()
	{
		check_ajax_referer('nm_ajax_dashboard');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		$cron_key = sanitize_text_field($_POST['cron_key']);

		if ($cron_key === 'pending_mcqs') {
			global $wpdb;
			$current_user_id = get_current_user_id();

			// 1. Get all pending MCQs with author 0
			$post_ids = $wpdb->get_col(
				"SELECT ID FROM {$wpdb->posts} WHERE post_type = 'mcq' AND post_status = 'pending' AND post_author = 0"
			);

			if (empty($post_ids)) {
				NM_Response_Handler::success('No pending MCQs found to fix.');
				return;
			}

			$count = count($post_ids);

			// 2. Update status to 'publish' and author to current admin
			foreach ($post_ids as $pid) {
				$update_args = array(
					'ID'          => $pid,
					'post_status' => 'publish',
					'post_author' => $current_user_id,
				);
				wp_update_post($update_args);
			}

			// Clear caches
			self::bust_admin_caches(array('admin_dashboard_stats', 'admin_system_health'));

			NM_Response_Handler::success("Fixed {$count} MCQs. They are now published and assigned to you.");
			return;
		}

		// Handle Cron Resets (Generic)
		// ... existing logic implementation or placeholder ...
		// Since we didn't find specific cron logic before, we'll just return success for now for crons
		// to avoid breaking the UI if user clicks other fix buttons (though ideally we should implement that too if missing).
		// For now, let's assume this function was missing entirely and we are adding it primarily for 'pending_mcqs'.

		NM_Response_Handler::error('Fix handler not implemented for: ' . $cron_key);
	}

	public static function nm_sync_post_authors_callback()
	{
		check_ajax_referer('nm_admin_action');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		$args = array(
			'post_type'      => 'mcq',
			'post_status'    => array('publish', 'draft', 'pending'),
			'posts_per_page' => -1,
			'fields'         => 'ids',
		);

		$query = new WP_Query($args);
		$ids   = $query->posts;

		if (empty($ids)) {
			NM_Response_Handler::success(array('message' => 'No MCQs found to sync.'));
			return;
		}

		$updated_count = 0;
		$skipped_count = 0;

		foreach ($ids as $post_id) {
			$author_id    = get_post_field('post_author', $post_id);
			$current_meta = get_post_meta($post_id, 'mcq_author_name', true);

			// Logic: Sync if empty, "TheQuizWire", or "TheQuizWire Editorial Team"
			$is_default = (empty($current_meta) || $current_meta === 'TheQuizWire' || strpos($current_meta, 'Editorial Team') !== false);

			if ($is_default) {
				$user = get_userdata($author_id);
				$display_name = $user ? $user->display_name : get_bloginfo('name');

				update_post_meta($post_id, 'mcq_author_name', sanitize_text_field($display_name));
				$updated_count++;
			} else {
				$skipped_count++;
			}
		}

NM_Response_Handler::success(
			array(
				'message' => sprintf('Authors synced! Updated: %d, Skipped (already customized): %d', $updated_count, $skipped_count),
				'count'   => $updated_count,
			)
		);
	}

	/**
	 * AJAX: Assign a random named author to MCQs that don't yet have one.
	 *
	 * Pool = the "Named Article/MCQ Authors" list (nm_article_authors). If that
	 * list is empty we fall back to all Author-role users; if none exist we fall
	 * back to the first Administrator (brand byline) so the tool never fails.
	 *
	 * RULES:
	 * - SKIPS any MCQ whose post_author is already a named author (idempotent; only
	 *   fills gaps, so MCQs assigned from the News tab or a previous run are untouched).
	 * - BATCHED (default 25 per request) so large libraries never hit PHP time/memory
	 *   limits. The JS loops batches until `done` is true.
	 * - Uses a direct DB update for post_author (fast, no save-hook cascade) + keeps the
	 *   E-E-A-T byline meta in sync + clean_post_cache.
	 *
	 * @return void
	 */
	/**
	 * @NEW 9.5.5 AJAX: Convert previously generated posts (pillars / roundups /
	 * PDF archive pages) from classic HTML to Gutenberg block markup, in small
	 * resumable batches. Thin wrapper around
	 * NM_News_Article_Generator::convert_existing_posts_batch().
	 */
	public static function nm_convert_blocks_callback()
	{
		check_ajax_referer('nm_admin_action', '_ajax_nonce');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		if (function_exists('wp_raise_memory_limit')) {
			wp_raise_memory_limit('admin');
		}
		if (function_exists('set_time_limit')) {
			@set_time_limit(120);
		}

		try {
			if (! class_exists('NM_News_Article_Generator') || ! method_exists('NM_News_Article_Generator', 'convert_existing_posts_batch')) {
				NM_Response_Handler::error('Block conversion helper unavailable.');
				return;
			}

			$batch_size = isset($_POST['batch_size']) ? intval($_POST['batch_size']) : 25;
			$result     = NM_News_Article_Generator::convert_existing_posts_batch($batch_size);

			if (! empty($result['done'])) {
				$result['message'] = 'All generated posts are now stored as Gutenberg blocks.';
				self::bust_admin_caches(array('all'));
				if (class_exists('NM_Generation_Logger')) {
					NM_Generation_Logger::nm_log_activity('[BLOCKS] Batch conversion complete: generated posts migrated to Gutenberg block markup.', 'success');
				}
			}

			NM_Response_Handler::success($result);
		} catch (Throwable $e) {
			NM_Response_Handler::error('Block conversion failed: ' . $e->getMessage());
		}
	}

	public static function nm_assign_random_authors_callback()
	{
		check_ajax_referer('nm_admin_action', '_ajax_nonce');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		// Raise limits for this long-ish operation, then guard everything so a DB/edge
		// failure returns a clean JSON error instead of a PHP fatal / 500.
		if (function_exists('wp_raise_memory_limit')) {
			wp_raise_memory_limit('admin');
		}
		if (function_exists('set_time_limit')) {
			@set_time_limit(120);
		}

		try {

			// 1) Build the author pool (same source-of-truth as generation).
			$configured = get_option('nm_article_authors', array());
			$pool       = array();
			if (is_array($configured) && ! empty($configured)) {
				$pool = array_values(array_filter(array_map('absint', $configured)));
			}

			if (empty($pool)) {
				$authors = get_users(
					array(
						'role'   => 'author',
						'number' => 100,
						'fields' => 'ID',
					)
				);
				$pool = is_array($authors) ? array_map('absint', $authors) : array();
			}

			if (empty($pool)) {
				$admins = get_users(
					array(
						'role'   => 'administrator',
						'number' => 1,
						'fields' => 'ID',
					)
				);
				$pool = is_array($admins) ? array_map('absint', $admins) : array();
			}

			$pool = array_values(array_filter($pool));
			if (empty($pool)) {
				NM_Response_Handler::error('No authors found. Create Author-role users first.');
				return;
			}

			// Verify every pool member actually exists as a user.
			$valid_pool = array();
			foreach ($pool as $uid) {
				if (get_userdata($uid)) {
					$valid_pool[] = $uid;
				}
			}
			$valid_pool = array_values(array_unique($valid_pool));
			if (empty($valid_pool)) {
				NM_Response_Handler::error('Selected authors no longer exist. Re-save the author list.');
				return;
			}

			// 2) Small batch per request (user asked for "small batches").
			$batch_size = isset($_POST['batch_size']) ? intval($_POST['batch_size']) : 25;
			$batch_size = max(10, min(100, $batch_size));

			// 3) Query ONLY MCQs whose post_author is NOT already a named author.
			$query = new WP_Query(
				array(
					'post_type'      => 'mcq',
					'post_status'    => array('publish', 'draft', 'pending'),
					'posts_per_page' => $batch_size,
					'fields'         => 'ids',
					'orderby'        => 'ID',
					'order'          => 'ASC',
					'author__not_in' => $valid_pool, // skip already-assigned
					'no_found_rows'  => false,       // accurate found_posts = total still unassigned
				)
			);
			$total_remaining = (int) $query->found_posts;
			$ids             = $query->posts;

			if (empty($ids)) {
				// Nothing left to assign — all MCQs now have a named author.
				self::bust_admin_caches(array('all'));
				NM_Response_Handler::success(
					array(
						'done'      => true,
						'processed' => 0,
						'remaining' => 0,
						'total'     => 0,
						'message'   => 'All MCQs already have a named author. Nothing left to assign.',
					)
				);
				return;
			}

			// 4) Assign a random author to this batch, via a FAST direct DB update.
			global $wpdb;
			$updated    = 0;
			$per_author = array_fill_keys($valid_pool, 0);

			foreach ($ids as $post_id) {
				$post_id = (int) $post_id;

				// Safety: skip if it already has a pool author (query normally prevents it).
				$cur_author = (int) get_post_field('post_author', $post_id);
				if (in_array($cur_author, $valid_pool, true)) {
					continue;
				}

				$uid      = $valid_pool[ array_rand($valid_pool) ];
				$new_user = get_userdata($uid);

				// Direct DB update avoids the heavy save_post hook cascade (embedding,
				// social image, auto-sync, re-slugging) that made the old wp_update_post
				// path slow and error-prone on thousands of posts.
				$wpdb->update(
					$wpdb->posts,
					array(
						'post_author'           => $uid,
						'post_modified'         => current_time('mysql'),
						'post_modified_gmt'     => current_time('mysql', 1),
					),
					array('ID' => $post_id)
				);

				// Keep the E-E-A-T byline meta in sync.
				$display = $new_user ? $new_user->display_name : get_bloginfo('name');
				update_post_meta($post_id, 'mcq_author_name', sanitize_text_field($display));

				// Clear this post's cache so author archives reflect the change.
				if (function_exists('clean_post_cache')) {
					clean_post_cache($post_id);
				}

				$per_author[ $uid ]++;
				$updated++;
			}

			// Bust caches so dashboards/archives reflect the new authors.
			self::bust_admin_caches(array('all'));

			$remaining = max(0, $total_remaining - $updated);

			// Readable per-author breakdown for this batch.
			$breakdown = array();
			foreach ($valid_pool as $uid) {
				$u = get_userdata($uid);
				$breakdown[] = ( $u ? $u->display_name : '#' . $uid ) . ': ' . (int) $per_author[ $uid ];
			}

			NM_Response_Handler::success(
				array(
					'processed' => $updated,
					'remaining' => $remaining,
					'total'     => $total_remaining,
					'done'      => $remaining <= 0,
					'pool'      => $breakdown,
					'message'   => sprintf(
						'Assigned %d MCQ(s). %d still left. %s',
						$updated,
						$remaining,
						$remaining > 0 ? 'Continuing…' : 'All done!'
					),
				)
			);

		} catch (Throwable $e) {
			// Never surface a raw PHP fatal to the user; report cleanly so they can
			// simply re-click and it resumes (skip-already-assigned makes it safe).
			NM_Response_Handler::error(
				'Author assignment hit a server error on this batch. It was partially saved — click the button again to continue from where it left off.',
				'exception',
				array( 'exception' => $e->getMessage() )
			);
		}
	}

	/**
	 * AJAX: Run the Daily Current Affairs Roundup NOW (manual trigger on the News tab).
	 *
	 * Generates one roundup post covering all MCQs published today. Reuses the exact same
	 * logic as the scheduled cron. If one was already generated today, it returns that fact
	 * so the user knows (a roundup post is only created once per day).
	 *
	 * @return void
	 */
	public static function nm_run_daily_roundup_callback()
	{
		check_ajax_referer('nm_admin_action', '_ajax_nonce');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		// Guard: is article/daily-roundup generation enabled?
		if (! class_exists('NM_News_Article_Generator') || ! NM_News_Article_Generator::is_enabled()) {
			NM_Response_Handler::error('Daily roundup generation is disabled. Enable "Enable Daily Roundup" on the News tab and save settings first.');
			return;
		}

		$today = current_time('Y-m-d');
		$done_key = 'nm_daily_roundup_done_' . $today;

		// Already generated today?
		if (get_transient($done_key)) {
			NM_Response_Handler::success(
				array(
					'already_done' => true,
					'date'         => $today,
					'message'      => 'The daily roundup for ' . $today . ' has already been generated today. Only one is created per day.',
				)
			);
			return;
		}

		$result = NM_News_Article_Generator::generate_daily_roundup($today);
		if (is_wp_error($result)) {
			NM_Response_Handler::error('Daily roundup could not be generated: ' . $result->get_error_message());
			return;
		}

		set_transient($done_key, 1, DAY_IN_SECONDS + 600);

		$status = get_post_status($result);
		$edit   = get_edit_post_link($result);
		NM_Response_Handler::success(
			array(
				'post_id' => $result,
				'status'  => $status,
				'date'    => $today,
				'edit_url' => $edit ? $edit : '',
				'message' => 'Daily roundup created for ' . $today . ' (post #' . $result . ', status: ' . $status . '). It will be published via the Scheduler.',
			)
		);
	}

	/**
	 * AJAX: Run the Monthly PDF Archive NOW for all selected topics.
	 *
	 * Generates the PDFs for the target month (default = previous completed month)
	 * and updates each topic's evergreen archive page. Idempotent per (topic, month).
	 *
	 * @return void
	 */
	public static function nm_run_pdf_archive_callback()
	{
		check_ajax_referer('nm_admin_action', '_ajax_nonce');
		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		if (! class_exists('NM_Monthly_PDF_Archive')) {
			NM_Response_Handler::error('Monthly PDF Archive class not loaded.');
			return;
		}
		if (! NM_Monthly_PDF_Archive::is_enabled()) {
			NM_Response_Handler::error('Monthly PDF Archive is disabled. Enable it on the 📥 Monthly PDF tab and save settings first.');
			return;
		}

		// Allow an explicit month/year via POST; default to the target (previous) month.
		$year  = isset($_POST['year'])  ? (int) $_POST['year']  : 0;
		$month = isset($_POST['month']) ? (int) $_POST['month'] : 0;
		if ( $year < 2000 || $month < 1 || $month > 12 ) {
			list( $year, $month ) = NM_Monthly_PDF_Archive::target_month();
		}

		$topics = NM_Monthly_PDF_Archive::get_topics();
		if ( empty( $topics ) ) {
			NM_Response_Handler::error('No topics selected. Select at least one topic on the 📥 Monthly PDF tab and save.');
			return;
		}

		// Raise limits (PDF generation can be heavy with many MCQs).
		if ( function_exists( 'wp_raise_memory_limit' ) ) {
			wp_raise_memory_limit( 'admin' );
		}
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 180 );
		}

		$results = array();
		$errors  = array();
		foreach ( $topics as $term_id ) {
			$res = NM_Monthly_PDF_Archive::ensure_archive( $term_id, $year, $month );
			if ( ! empty( $res['error'] ) ) {
				$errors[] = $res['error'];
				continue;
			}
			$term = get_term( $term_id, 'topic' );
			$name = ( $term && ! is_wp_error( $term ) ) ? $term->name : '#' . $term_id;
			$results[] = array(
				'topic'     => $name,
				'page_id'   => $res['page_id'],
				'count'     => $res['count'],
				'pdf_url'   => $res['pdf_url'],
				'generated' => $res['generated'],
				'edit_url'  => isset( $res['page_id'] ) && $res['page_id'] ? get_edit_post_link( $res['page_id'] ) : '',
			);
		}

		// Bust dashboard caches.
		if ( method_exists( self::class, 'bust_admin_caches' ) ) {
			self::bust_admin_caches( array( 'all' ) );
		}

		$summary = array();
		foreach ( $results as $r ) {
			$summary[] = $r['topic'] . ': ' . ( $r['generated'] ? (int) $r['count'] . ' MCQs' : '0 MCQs' );
		}

		NM_Response_Handler::success(
			array(
				'results'  => $results,
				'errors'   => $errors,
				'year'     => $year,
				'month'    => $month,
				'message'  => sprintf(
					'Monthly PDF generation complete for %02d/%04d. %s%s',
					$month,
					$year,
					implode( '; ', $summary ),
					$errors ? ' Errors: ' . implode( '; ', $errors ) : ''
				),
			)
		);
	}

	/**
	 * AJAX: Generate Dashboard API Key
	 *
	 * @return void
	 */
	public static function nm_generate_dashboard_key()
	{
		check_ajax_referer('nm_admin_action', '_ajax_nonce');

		if (! NM_Response_Handler::require_capability('manage_options')) {
			return;
		}

		$key = wp_generate_password(32, false);
		update_option('nm_dashboard_api_key', $key, false);

		NM_Response_Handler::success(
			array(
				'key'     => $key,
				'message' => 'Dashboard API key generated successfully',
			)
		);
	}

}