# SEO Article Generator - WordPress Plugin

Professional WordPress plugin for automated SEO-optimized article generation using AI (Google Gemini), with intelligent internal linking, background job processing, and comprehensive validation.

## Features

### Core Functionality
- **AI-Powered Generation**: Uses Google Gemini API for high-quality article generation
- **Intelligent Internal Linking**: Automatically discovers and injects 3-5 relevant internal links from your sitemap
- **Background Processing**: Uses Action Scheduler to prevent timeouts on long-running AI calls
- **Quality Validation**: 100-point scoring system across 8 criteria ensures content quality
- **Structured Output**: AI returns JSON with enforced schema for consistency

### Content Quality
- SEO title optimization (50-60 chars)
- Meta description (150-160 chars)
- Keyword density targeting (1.5-3%)
- Technical specifications table
- Pros & Cons comparison
- Download section with clickable buttons
- 5-7 key features with benefits
- What's New section from changelog
- System requirements
- 3-5 FAQs targeting download intent

### Admin Interface
- Clean WordPress-integrated UI
- Real-time progress tracking with AJAX
- Article preview before publishing
- Validation score breakdown
- One-click publishing to drafts
- Sitemap CSV upload and management
- API connection testing

## Installation

### Requirements
- WordPress 5.8 or higher
- PHP 7.4 or higher
- MySQL 5.7+ / MariaDB 10.2+
- Google Gemini API key ([Get Free Key](https://aistudio.google.com/app/apikey))

### Steps

1. **Download Plugin**
   - Upload `seo-article-generator` folder to `/wp-content/plugins/`

2. **Activate Plugin**
   - Go to WordPress Admin → Plugins
   - Find "SEO Article Generator"
   - Click "Activate"

3. **Configure Settings**
   - Go to **SEO Generator → Settings**
   - Enter your Gemini API Key
   - Click "Test API Connection" to verify
   - Adjust validation threshold (default: 70)
   - Save settings

4. **Upload Sitemap**
   - Go to **SEO Generator → Sitemap Manager**
   - Upload your `softwareswave_sitemap.csv` file
   - Wait for import to complete

5. **Generate First Article**
   - Go to **SEO Generator → Generate Article**
   - Fill in software details:
     - Software Name (e.g., "VLC Media Player")
     - Version (e.g., "3.0.20")
     - File name (e.g., "vlc-setup.exe")
     - File size (e.g., "42 MB")
     - License type
     - Developer name
     - Homepage URL
     - OS support
     - Changelog/What's New
   - Click "Generate Article"
   - Wait for processing (20-60 seconds)
   - Review preview and validation score
   - Click "Save as Draft" to publish

## How It Works

### Generation Workflow

```
User Input → Background Job Created → Internal Links Found → 
AI API Call (JSON Schema) → Content Formatted → Validation → 
Preview Shown → Published as Draft
```

### Validation Scoring (100 Points Total)

| Criteria | Points | Description |
|----------|--------|-------------|
| Internal Links | 20 | 3+ softwareswave.com links |
| Download Section | 15 | Working download button |
| Keyword Density | 15 | 1.5-3% focus keyword |
| Meta Description | 10 | 150-160 chars optimal |
| Content Length | 15 | 500-700 words |
| FAQs | 10 | 3+ download-intent questions |
| Technical Specs | 10 | Complete tech table |
| Features | 5 | 5+ features with benefits |

### Sitemap CSV Format

Your CSV file must have these columns:

```csv
Title,URL
"VLC Media Player 3.0.20 Download",https://softwareswave.com/vlc-download
"WinRAR 7.0 Download",https://softwareswave.com/winrar-download
```

**Auto-Extracted Metadata:**
- Software type (from title keywords)
- Category classification
- Relevant keywords for matching

## API Key Setup

### Get Google Gemini API Key (Free)

1. Visit [Google AI Studio](https://aistudio.google.com/app/apikey)
2. Sign in with Google account
3. Click "Create API Key"
4. Copy the key
5. Paste in **SEO Generator → Settings**

**Free Tier Limits:**
- 60 requests per minute
- 1,500 requests per day
- More than enough for typical usage

## Troubleshooting

### "Generation Failed" Error
- Check API key is correct
- Test connection in Settings
- Check error logs in `wp-content/uploads/seo-generator-logs/`
- Verify you haven't exceeded API limits

### "No Internal Links Found"
- Upload sitemap CSV via Sitemap Manager
- Check sitemap has Title and URL columns
- Verify CSV imported successfully (check stats)

### "Validation Score Too Low"
- Review errors and warnings in preview
- Check if all required fields filled
- Regenerate article with better input data
- Lower validation threshold in Settings (not recommended)

### Plugin Timeout
- Plugin uses background jobs - shouldn't timeout
- If timeout occurs, check if Action Scheduler is loaded
- Check PHP max_execution_time setting

## File Structure

```
seo-article-generator/
├── seo-article-generator.php       # Main plugin file
├── includes/
│   ├── class-plugin.php            # Main controller
│   ├── class-installer.php         # Activation/DB setup
│   ├── class-error-handler.php     # Error management
│   ├── class-logger.php            # Logging system
│   ├── ai/
│   │   └── class-ai-client.php     # Gemini API client
│   ├── generator/
│   │   ├── class-article-generator.php    # Main orchestrator
│   │   └── class-content-formatter.php    # JSON to HTML
│   ├── links/
│   │   ├── class-link-finder.php          # Internal link discovery
│   │   └── class-sitemap-parser.php       # CSV import
│   ├── validation/
│   │   ├── class-validator.php            # Content validation
│   │   └── class-scoring-engine.php       # Quality scoring
│   └── jobs/
│       └── class-job-handler.php          # Background processing
├── admin/
│   ├── class-admin-menu.php        # Admin UI
│   └── views/                      # Page templates
└── assets/
    ├── js/                         # JavaScript
    └── css/                        # Stylesheets
```

## Database Tables

### `wp_seo_internal_links`
Caches sitemap for fast link discovery
- Fulltext indexes on keywords and titles
- Category and software type classification

### `wp_seo_generation_jobs`
Tracks background generation jobs
- Job status tracking
- Input/output data storage
- Error logging

## Logging

Logs are stored in: `wp-content/uploads/seo-generator-logs/`

**Log Levels:**
- DEBUG: Detailed information
- INFO: General events
- WARNING: Non-critical issues
- ERROR: Failures and exceptions

**Enable/Disable:**
Go to Settings → Enable Logging checkbox

## Performance

**Typical Generation Time:** 20-45 seconds
- Internal link discovery: 1-2 seconds
- AI generation: 15-30 seconds
- Validation: 1-2 seconds
- Total: ~20-40 seconds

**Resource Usage:**
- Memory: ~30-50 MB per generation
- Database: Minimal (cached sitemap)
- API Calls: 1 per article

## Security

- ✅ Nonce verification on all AJAX requests
- ✅ Capability checks (`edit_posts`, `manage_options`)
- ✅ Input sanitization on all user data
- ✅ SQL injection prevention via `$wpdb->prepare()`
- ✅ XSS prevention via `esc_html()`, `esc_url()`, `wp_kses_post()`
- ✅ API keys stored in WordPress options (encrypted recommended)

## Support

**Issues?**
- Check logs first
- Test API connection
- Verify sitemap uploaded correctly
- Check PHP error logs

**Feature Requests:**
- Bulk generation (coming soon)
- Claude API support (coming soon)
- Custom templates
- A/B testing

## Changelog

### Version 1.0.0 (2025-12-01)
- Initial release
- Google Gemini integration
- Background job processing
- Intelligent internal linking
- Quality validation system
- Admin interface
- Sitemap management

## License

GPL v2 or later

## Credits

Developed for SoftwaresWave.com

Uses:
- WordPress (GPL)
- Action Scheduler (GPL)
- Google Gemini API

---

**Ready to generate amazing SEO content automatically? Install now and try it!**
