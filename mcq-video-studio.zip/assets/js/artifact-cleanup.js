/**
 * Artifact Cleanup "Run cleanup now" button handler.
 *
 * Wired to the button in class-vs-settings.php inside render_headless_tab().
 * Uses the existing mcqvsSettings.localized nonce + ajaxUrl, so this script
 * must be enqueued together with the settings page that renders the button.
 */
(function ($) {
    'use strict';

    if (typeof mcqvsSettings === 'undefined') {
        return;
    }

    $(document).on('click', '#mcqvs-run-artifact-cleanup', function (e) {
        e.preventDefault();
        var $btn    = $(this);
        var $result = $('#mcqvs-artifact-cleanup-result');
        if ($btn.prop('disabled')) {
            return;
        }
        $btn.prop('disabled', true).text(mcqvsSettings.i18n.running || 'Running…');
        $result.text('');

        $.post(mcqvsSettings.ajaxUrl, {
            action: 'mcqvs_run_artifact_cleanup',
            nonce:  mcqvsSettings.nonce
        }).done(function (res) {
            if (res && res.success && res.data) {
                var s = res.data;
                var mb = (s.bytes / (1024 * 1024)).toFixed(2);
                $result.text(
                    'Prune complete: tts=' + s.tts +
                    ', covers=' + s.covers +
                    ', generated=' + s.generated +
                    ', exports=' + s.exports +
                    ', batch=' + s.batch +
                    ', render_temp=' + s.render_temp +
                    ', temp=' + s.temp +
                    ', bytes=' + mb + ' MB' +
                    ', dry_run=' + (s.dry_run ? 'yes' : 'no') +
                    ', took=' + s.duration_ms + ' ms'
                );
            } else {
                $result.text('Cleanup failed.');
            }
        }).fail(function () {
            $result.text('Cleanup request failed.');
        }).always(function () {
            $btn.prop('disabled', false).text('Run cleanup now');
        });
    });
})(jQuery);
