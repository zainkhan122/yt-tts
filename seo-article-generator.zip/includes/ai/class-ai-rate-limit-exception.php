<?php

namespace SEO_Article_Generator\AI;

use SEO_Article_Generator\AI_Exception;

class AI_Rate_Limit_Exception extends AI_Exception
{
    /** @var int */
    private $retry_after = 0;

    /** @var int */
    private $reset_at = 0;

    /** @var string */
    private $quota_type = 'minute';

    /** @var string */
    private $provider = '';

    /** @var API_Error_Info|null */
    private $error_info = null;

    public function __construct($message, $code = 429, array $data = array(), \Throwable $previous = null)
    {
        parent::__construct($message, $code, $previous);

        $this->retry_after = isset($data['retry_after']) ? (int) $data['retry_after'] : 0;
        $this->reset_at = isset($data['reset_at']) ? (int) $data['reset_at'] : 0;
        $this->quota_type = isset($data['quota_type']) ? (string) $data['quota_type'] : 'minute';
        $this->provider = isset($data['provider']) ? (string) $data['provider'] : '';

        if (isset($data['error_info']) && $data['error_info'] instanceof API_Error_Info) {
            $this->error_info = $data['error_info'];
            if ($this->retry_after === 0) {
                $this->retry_after = $data['error_info']->get_retry_delay_seconds();
            }
            if ($this->reset_at === 0) {
                $this->reset_at = $data['error_info']->get_reset_at_ts();
            }
            if ($this->provider === '' && $data['error_info']->get_provider() !== '') {
                $this->provider = $data['error_info']->get_provider();
            }
        }
    }

    public function get_retry_after(): int
    {
        return $this->retry_after;
    }

    public function get_reset_at(): int
    {
        return $this->reset_at;
    }

    public function get_quota_type(): string
    {
        return $this->quota_type;
    }

    public function get_provider(): string
    {
        return $this->provider;
    }

    public function get_error_info(): ?API_Error_Info
    {
        return $this->error_info;
    }

public function get_data(): array
    {
        $data = array(
            'retry_after' => $this->retry_after,
            'reset_at' => $this->reset_at,
            'quota_type' => $this->quota_type,
            'provider' => $this->provider,
        );
        if ($this->error_info !== null) {
            $data['error_info_array'] = $this->error_info->to_array();
        }
return $data;
    }
}
