/**
 * MCQVS Unified Logger
 *
 * 1. Prints pretty logs to Console.
 * 2. Writes logs to the in-app Debug DOM (if visible).
 * 3. SYNCs critical logs to the WordPress Backend via AJAX.
 *
 * @package MCQ_Video_Studio
 * @since 1.2.0
 */

(function (window) {
    "use strict";

    const MCQVS_Logger = {
        config: {
            ajaxUrl: null,
            nonce: null,
            debugEnabled: true
        },

        // @NEW 2026-01-30: In-memory ring buffer for support diagnostics
        _buffer: [],
        _bufferMax: 600,

        init: function (ajaxUrl, nonce) {
            this.config.ajaxUrl = ajaxUrl;
            this.config.nonce = nonce;

            // Global Error Handler (Catch crashes)
            window.onerror = (msg, url, line, col, error) => {
                this.error("Global JS Crash", {
                    message: msg,
                    location: `${url}:${line}:${col}`,
                    stack: error ? error.stack : 'N/A'
                });
            };

            // Global Promise Rejection Handler (Catch failed fetches)
            window.onunhandledrejection = (event) => {
                this.error("Unhandled Promise Rejection", {
                    reason: event.reason
                });
            };

            this.info("Logger Initialized", { mode: "Unified Telemetry" });
        },

        /**
         * Log Information (Local only, unless critical)
         */
        info: function (msg, context = {}) {
            this._push("info", msg, context);
            this._print("info", msg, context);
            this._writeToDOM("info", msg);
        },

        /**
         * Log Warning (Local + DOM)
         */
        warn: function (msg, context = {}) {
            this._push("warn", msg, context);
            this._print("warn", msg, context);
            this._writeToDOM("warn", msg);
        },

        /**
         * Log Error (Local + DOM + SERVER SYNC)
         */
        error: function (msg, context = {}) {
            this._push("error", msg, context);
            this._print("error", msg, context);
            this._writeToDOM("error", msg);
            this._syncToServer("error", msg, context);
        },

        /**
         * Log API Call (Use this for your AI Generators)
         * Sends full Raw Request/Response to Server Logger
         */
        api: function (endpoint, requestPayload, responsePayload, isError = false) {
            const level = isError ? "error" : "info";
            const msg = `API Call: ${endpoint}`;

            this._push(level, msg, { request: requestPayload, response: responsePayload, type: 'API_TRACE', endpoint });

            // Print locally
            this._print(level, msg, { request: requestPayload, response: responsePayload });
            this._writeToDOM(level, msg);

            // ALWAYS Sync API logs to server for inspection
            this._syncToServer(level, msg, {
                type: 'API_TRACE',
                endpoint: endpoint,
                request: requestPayload,
                response: responsePayload
            });
        },

        /**
         * Return a copy of buffered logs for support tickets.
         */
        getLogs: function () {
            return this._buffer.slice();
        },

        clearLogs: function () {
            this._buffer = [];
        },

        // --- Internals ---

        _print: function (level, msg, context) {
            if (!this.config.debugEnabled) return;
            const css = {
                info: "color: #00b894; font-weight: bold;",
                warn: "color: #fdcb6e; font-weight: bold;",
                error: "color: #d63031; font-weight: bold;"
            };
            console.log(`%c[MCQVS] ${msg}`, css[level], context);
        },

        _push: function (level, msg, context) {
            try {
                const entry = {
                    ts: new Date().toISOString(),
                    level: String(level || 'info'),
                    msg: String(msg || ''),
                    context: (context && typeof context === 'object') ? context : { value: context }
                };
                this._buffer.push(entry);
                if (this._buffer.length > this._bufferMax) {
                    this._buffer.splice(0, this._buffer.length - this._bufferMax);
                }
            } catch (e) {
                // Never break the app for logging
            }
        },

        _writeToDOM: function (level, msg) {
            const $console = jQuery("#debugLogEntries");
            if ($console.length) {
                const icon = level === 'error' ? '❌' : (level === 'warn' ? '⚠️' : 'ℹ️');
                const time = new Date().toLocaleTimeString();
                $console.append(`
                    <div class="log-entry ${level}" style="border-bottom:1px solid #333; padding:2px 0; font-family:monospace; font-size:11px;">
                        <span style="color:#666">[${time}]</span> ${icon} ${msg}
                    </div>
                `);
                // Auto-scroll
                const container = jQuery("#mcqvs-debug-console");
                if (container.length) container.scrollTop(container[0].scrollHeight);
            }
        },

        _syncToServer: function (level, msg, context) {
            if (!this.config.ajaxUrl) return;

            jQuery.post(this.config.ajaxUrl, {
                action: "mcqvs_remote_log",
                nonce: this.config.nonce,
                level: level,
                message: msg,
                context: JSON.stringify(context) // Serialize to pass safely
            });
        }
    };

    // Expose globally
    window.MCQVS_Logger = MCQVS_Logger;

})(window);
