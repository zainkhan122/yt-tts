<?php

/**
 * Schema Generator
 *
 * Generates schema.org markup for citations and AI disclosure.
 * Complements RankMath (which handles Article, FAQPage schemas).
 *
 * @package DIT_TrendStudio\SEO
 * @MODIFIED 2025-12-18 - Phase 5: Initial implementation for E-E-A-T compliance.
 */

namespace DIT\TrendStudio\Core\SEO; // @MODIFIED: Adjusted namespace to match Plugin.php usage

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Generates Citation schema and AI disclosure metadata.
 *
 * - Citation schema for source attribution
 * - AI disclosure meta tag (per Google's AI content guidelines)
 * - Image optimization attributes
 */
class Schema_Generator
{
    /**
     * Option key for AI disclosure setting
     */
    private const OPTION_AI_DISCLOSURE = 'dit_ts_ai_disclosure_enabled';

    /**
     * Option key for disclosure message
     */
    private const OPTION_DISCLOSURE_MESSAGE = 'dit_ts_ai_disclosure_message';

    /**
     * Default disclosure message
     */
    private const DEFAULT_DISCLOSURE_MESSAGE = 'This article was created with AI assistance and reviewed by our editorial team.';

    /**
     * Initialize hooks
     */
    public function __construct()
    {
        // Add schema to head
        add_action('wp_head', [$this, 'output_citation_schema'], 5);
        add_action('wp_head', [$this, 'output_ai_disclosure_meta'], 6);

        // Add disclosure banner to content
        add_filter('the_content', [$this, 'append_disclosure_banner'], 999);

        // NOTE: Image lazy-load optimization removed - Jetpack/WP Core handles this natively
    }

    /**
     * Output Citation schema JSON-LD for AI-generated posts.
     */
    public function output_citation_schema(): void
    {
        if (!is_singular('post')) {
            return;
        }

        $post_id = get_the_ID();
        if (!$post_id) {
            return;
        }

        // Check if this is an AI-generated post
        $job_id = get_post_meta($post_id, '_dit_ts_job_id', true);
        if (empty($job_id)) {
            return;
        }

        // Get sources from job output
        $sources = $this->get_sources_for_post($post_id);
        if (empty($sources)) {
            return;
        }

        $citations = [];
        foreach ($sources as $index => $source) {
            $url = $source['url'] ?? '';
            $label = $source['label'] ?? '';

            if (empty($url)) {
                continue;
            }

            $citations[] = [
                '@type'    => 'CreativeWork',
                'name'     => $label ?: $this->extract_domain($url),
                'url'      => $url,
                'position' => $index + 1,
            ];
        }

        if (empty($citations)) {
            return;
        }

        $schema = [
            '@context' => 'https://schema.org',
            '@type'    => 'ItemList',
            'name'     => 'Sources and Citations',
            'itemListElement' => $citations,
        ];

        echo '<script type="application/ld+json">' . wp_json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>' . "\n";
    }

    /**
     * Output AI disclosure meta tag.
     */
    public function output_ai_disclosure_meta(): void
    {
        if (!$this->is_ai_disclosure_enabled()) {
            return;
        }

        if (!is_singular('post')) {
            return;
        }

        $post_id = get_the_ID();
        if (!$post_id) {
            return;
        }

        // Only for AI-generated posts
        $job_id = get_post_meta($post_id, '_dit_ts_job_id', true);
        if (empty($job_id)) {
            return;
        }

        // Google's recommended AI content disclosure
        echo '<meta name="ai-generated" content="true">' . "\n";
        echo '<meta name="ai-disclosure" content="' . esc_attr($this->get_disclosure_message()) . '">' . "\n";
    }

    /**
     * Append disclosure banner to content.
     *
     * @param string $content Post content
     * @return string Modified content
     */
    public function append_disclosure_banner(string $content): string
    {
        if (!$this->is_ai_disclosure_enabled()) {
            return $content;
        }

        if (!is_singular('post') || !in_the_loop() || !is_main_query()) {
            return $content;
        }

        $post_id = get_the_ID();
        if (!$post_id) {
            return $content;
        }

        // Only for AI-generated posts
        $job_id = get_post_meta($post_id, '_dit_ts_job_id', true);
        if (empty($job_id)) {
            return $content;
        }

        $message = $this->get_disclosure_message();
        $banner = sprintf(
            '<div class="dit-ts-ai-disclosure"><span class="dit-ts-ai-icon">🤖</span> <span class="dit-ts-ai-text">%s</span></div>',
            esc_html($message)
        );

        // Append at end of content
        return $content . $banner;
    }

    /**
     * Add image optimization attributes.
     *
     * @param array    $attr       Attributes
     * @param \WP_Post $attachment Attachment post
     * @return array Modified attributes
     */
    public function add_image_optimizations(array $attr, $attachment): array
    {
        // Add loading="lazy" if not already set
        if (!isset($attr['loading'])) {
            $attr['loading'] = 'lazy';
        }

        // Add decoding="async" for better performance
        if (!isset($attr['decoding'])) {
            $attr['decoding'] = 'async';
        }

        // Add fetchpriority hint for above-the-fold images
        // (This would need additional context to determine, skipping for now)

        return $attr;
    }

    /**
     * Get sources for a post from its job data.
     *
     * @param int $post_id Post ID
     * @return array Sources array
     */
    private function get_sources_for_post(int $post_id): array
    {
        $job_id = get_post_meta($post_id, '_dit_ts_job_id', true);
        if (empty($job_id)) {
            return [];
        }

        global $wpdb;
        $table = $wpdb->prefix . 'dit_ts_jobs';

        $output_data = $wpdb->get_var($wpdb->prepare(
            "SELECT output_data FROM {$table} WHERE id = %d",
            $job_id
        ));

        if (empty($output_data)) {
            return [];
        }

        $data = json_decode($output_data, true);
        return $data['intelligence']['sources'] ?? $data['sources'] ?? [];
    }

    /**
     * Extract domain from URL.
     *
     * @param string $url URL
     * @return string Domain
     */
    private function extract_domain(string $url): string
    {
        $parsed = wp_parse_url($url);
        $host = $parsed['host'] ?? $url;
        return preg_replace('/^www\./', '', $host);
    }

    /**
     * Check if AI disclosure is enabled.
     *
     * @return bool
     */
    public function is_ai_disclosure_enabled(): bool
    {
        return false; // @MODIFIED 2026-01-14 - Hard disabled by user request
    }

    /**
     * Get disclosure message.
     *
     * @return string
     */
    public function get_disclosure_message(): string
    {
        return get_option(self::OPTION_DISCLOSURE_MESSAGE, self::DEFAULT_DISCLOSURE_MESSAGE);
    }

    /**
     * Register settings for admin page.
     */
    public static function register_settings(): void
    {
        register_setting('dit_ts_settings', self::OPTION_AI_DISCLOSURE, [
            'type'              => 'boolean',
            'default'           => false,
            'sanitize_callback' => 'rest_sanitize_boolean',
        ]);

        register_setting('dit_ts_settings', self::OPTION_DISCLOSURE_MESSAGE, [
            'type'              => 'string',
            'default'           => self::DEFAULT_DISCLOSURE_MESSAGE,
            'sanitize_callback' => 'sanitize_text_field',
        ]);
    }

    /**
     * Render settings fields for admin page.
     */
    public static function render_settings_fields(): void
    {
        $enabled = get_option(self::OPTION_AI_DISCLOSURE, true);
        $message = get_option(self::OPTION_DISCLOSURE_MESSAGE, self::DEFAULT_DISCLOSURE_MESSAGE);

?>
        <tr>
            <th scope="row"><?php esc_html_e('AI Disclosure', 'dit-trend-content-studio'); ?></th>
            <td>
                <label>
                    <input type="checkbox" name="<?php echo esc_attr(self::OPTION_AI_DISCLOSURE); ?>" value="1" <?php checked($enabled); ?>>
                    <?php esc_html_e('Enable AI disclosure banner on generated articles', 'dit-trend-content-studio'); ?>
                </label>
                <p class="description"><?php esc_html_e('Adds a disclosure banner and meta tags per Google\'s AI content guidelines.', 'dit-trend-content-studio'); ?></p>
            </td>
        </tr>
        <tr>
            <th scope="row"><?php esc_html_e('Disclosure Message', 'dit-trend-content-studio'); ?></th>
            <td>
                <input type="text" name="<?php echo esc_attr(self::OPTION_DISCLOSURE_MESSAGE); ?>" value="<?php echo esc_attr($message); ?>" class="regular-text">
                <p class="description"><?php esc_html_e('Message displayed in the AI disclosure banner.', 'dit-trend-content-studio'); ?></p>
            </td>
        </tr>
<?php
    }
}
