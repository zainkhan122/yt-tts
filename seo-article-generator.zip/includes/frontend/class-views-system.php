<?php

/**
 * Views System
 *
 * Handles post views for software posts with random seeding and lightweight tracking.
 *
 * @package SEO_Article_Generator
 * @since 2.15.0
 */

namespace SEO_Article_Generator\Frontend;

// Prevent direct access.
if (! defined('ABSPATH')) {
    exit;
}

/**
 * Views System class.
 *
 * @since 2.15.0
 */
class Views_System
{
    const META_VIEWS  = '_seo_gen_post_views';
    const AJAX_ACTION = 'seo_gen_track_view';

    /**
     * Initialize the views system.
     *
     * @since 2.15.0
     */
    public static function init()
    {
        // Moved off wp_head — beacon fires after page is fully delivered.
        add_action('wp_footer', [__CLASS__, 'inject_tracking_beacon']);

        // AJAX handlers for both logged-in and guest users.
        add_action('wp_ajax_'        . self::AJAX_ACTION, [__CLASS__, 'handle_track_view']);
        add_action('wp_ajax_nopriv_' . self::AJAX_ACTION, [__CLASS__, 'handle_track_view']);
    }

    /**
     * Inject a fire-and-forget beacon script into the footer.
     * navigator.sendBeacon() is non-blocking — zero TTFB impact.
     *
     * @since 2.16.0
     */
    public static function inject_tracking_beacon()
    {
        if (! is_single()) {
            return;
        }

        $post_id  = get_the_ID();
        if (! $post_id) {
            return;
        }

        $nonce    = wp_create_nonce(self::AJAX_ACTION);
        $ajax_url = esc_url(admin_url('admin-ajax.php'));
?>
        <script>
            (function() {
                if (!navigator.sendBeacon) {
                    return;
                }
                navigator.sendBeacon(
                    '<?php echo $ajax_url; ?>',
                    new URLSearchParams({
                        action: '<?php echo esc_js(self::AJAX_ACTION); ?>',
                        pid: '<?php echo (int) $post_id; ?>',
                        nonce: '<?php echo esc_js($nonce); ?>'
                    })
                );
            })();
        </script>
    <?php
    }

    /**
     * AJAX handler — processes the beacon request in the background.
     * Applies bot filtering, nonce verification, and atomic increment.
     *
     * @since 2.16.0
     */
    public static function handle_track_view()
    {
        // 1. Nonce check.
        $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
        if (! wp_verify_nonce($nonce, self::AJAX_ACTION)) {
            wp_die('', '', ['response' => 403]);
        }

        // 2. Validate post ID.
        $post_id = isset($_POST['pid']) ? (int) $_POST['pid'] : 0;
        if ($post_id < 1) {
            wp_die('', '', ['response' => 400]);
        }

        // 3. Silently drop bot requests — no count, no DB write.
        if (self::is_bot()) {
            wp_die('', '', ['response' => 204]);
        }

        // 4. Seed if this post has never been tracked.
        $current = get_post_meta($post_id, self::META_VIEWS, true);
        if ($current === '' || $current === false) {
            self::seed_views($post_id);
            wp_die('', '', ['response' => 204]);
        }

        // 5. Atomic SQL increment — eliminates race conditions entirely.
        //    update_post_meta() does read-modify-write; this does not.
        global $wpdb;
        $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$wpdb->postmeta}
                    SET meta_value = meta_value + 1
                  WHERE post_id  = %d
                    AND meta_key = %s",
                $post_id,
                self::META_VIEWS
            )
        );

        // 6. Manually bust object cache since we bypassed update_post_meta().
        wp_cache_delete($post_id, 'post_meta');

        wp_die('', '', ['response' => 204]);
    }

    /**
     * Detect common bots and crawlers by User-Agent string.
     * Keeps bot traffic from inflating counts or adding DB load.
     *
     * @since 2.16.0
     * @return bool
     */
    private static function is_bot(): bool
    {
        $ua = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');

        if (empty($ua)) {
            return true; // No UA = headless/automated — treat as bot.
        }

        $known_bots = [
            'googlebot',
            'bingbot',
            'slurp',
            'duckduckbot',
            'baiduspider',
            'yandexbot',
            'sogou',
            'exabot',
            'facebot',
            'ia_archiver',
            'semrushbot',
            'ahrefsbot',
            'mj12bot',
            'dotbot',
            'petalbot',
        ];

        foreach ($known_bots as $bot) {
            if (str_contains($ua, $bot)) {
                return true;
            }
        }

        return false;
    }

    // -------------------------------------------------------------------------
    // Everything below is UNCHANGED from 2.15.0
    // -------------------------------------------------------------------------

    /**
     * Get formatted views for a post.
     *
     * @since 2.15.0
     * @param int $post_id Post ID.
     * @return string Formatted view count (e.g., "1.2k").
     */
    public static function get_formatted_views(int $post_id): string
    {
        $views = self::get_raw_views($post_id);
        return self::format_number($views);
    }

    /**
     * Get raw view count, seeding if necessary.
     *
     * @since 2.15.0
     * @param int $post_id Post ID.
     * @return int Raw view count.
     */
    public static function get_raw_views(int $post_id): int
    {
        $views = get_post_meta($post_id, self::META_VIEWS, true);

        if ($views === '' || $views === false) {
            return self::seed_views($post_id);
        }

        return (int) $views;
    }

    /**
     * Seed views meta with a random number.
     *
     * @since 2.15.0
     * @param int $post_id Post ID.
     * @return int The seeded view count.
     */
    private static function seed_views(int $post_id): int
    {
        $views = mt_rand(1500, 45000);
        update_post_meta($post_id, self::META_VIEWS, $views);
        return $views;
    }

    /**
     * Format number to K/M format.
     *
     * @since 2.15.0
     * @param int $number Number to format.
     * @return string Formatted number.
     */
    private static function format_number(int $number): string
    {
        if ($number >= 1000000) {
            return round($number / 1000000, 1) . 'M';
        }
        if ($number >= 1000) {
            return round($number / 1000, 1) . 'k';
        }
        return (string) $number;
    }

    /**
     * Render views UI HTML for hero section.
     *
     * @since 2.15.0
     * @param int $post_id Post ID.
     * @return string HTML output.
     */
    public static function render_views_ui(int $post_id): string
    {
        $views_text = self::get_formatted_views($post_id);

        ob_start();
    ?>
        <div class="seo-gen-hero__views" title="<?php esc_attr_e('Total Views', 'seo-article-generator'); ?>">
            <svg class="seo-gen-hero__views-icon" viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
                <path d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z" />
            </svg>
            <span class="seo-gen-hero__views-count"><?php echo esc_html($views_text); ?></span>
        </div>
<?php
        return ob_get_clean();
    }
}
