<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Contracts\AIProviderInterface;
use AiSocialCollage\Database\ApiCallManager;
use AiSocialCollage\Logger;
use AiSocialCollage\Services\CustomProvider;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AIProviderRegistry {

	private static $context = [];

	public static function set_context( array $ctx ) {
		self::$context = $ctx;
	}

	public static function get_context() {
		return self::$context;
	}

	public static function execute( AIProviderInterface $provider, $post_content, $system_prompt = '', array $override_context = [] ) {
         $context = ! empty( $override_context ) ? $override_context : self::$context;
         if ( empty( $context['caller'] ) ) {
             $context['caller'] = 'unknown';
         }
         $provider_name = $provider->get_provider_name();
 		$model = $provider->get_model_name();

 	if ( ! Config::is_valid_provider( $provider_name ) ) {
 		Logger::error( 'unregistered_provider_attempt', null, [
 			'provider' => $provider_name,
 			'model' => $model,
 			'caller' => $context['caller'] ?? 'unknown',
 		], '403', 'Attempted to call unregistered provider' );
 		throw new \Exception( "Blocked: Provider '{$provider_name}' is not registered. All API calls must go through registered providers." );
 	}

 	if ( ProviderCooldown::is_misconfigured( $provider_name ) ) {
 		Logger::warning( 'provider_misconfigured_skip', $context['job_id'] ?? null, [
 			'provider' => $provider_name,
 			'caller' => $context['caller'] ?? 'unknown',
 		], '403', 'Provider marked as misconfigured' );
 		throw new \Exception( "Blocked: Provider '{$provider_name}' is marked as misconfigured. Skipping until cooldown expires." );
 	}

 	if ( ProviderCooldown::is_daily_quota_blocked( $provider_name ) ) {
 		$remaining = ProviderCooldown::get_daily_quota_remaining( $provider_name );
 		Logger::info( 'provider_daily_quota_skip', $context['job_id'] ?? null, [
 			'provider' => $provider_name,
 			'remaining' => $remaining,
 			'caller' => $context['caller'] ?? 'unknown',
 		], '429', 'Provider daily quota exhausted' );
 		throw new \Exception( "HTTP 429 Provider '{$provider_name}' daily quota exhausted. Resets in {$remaining}s." );
 	}

 	if ( ProviderCooldown::is_in_cooldown( $provider_name ) ) {
 		$remaining = ProviderCooldown::get_cooldown_remaining( $provider_name );
 		Logger::warning( 'provider_cooldown_skip', $context['job_id'] ?? null, [
 			'provider' => $provider_name,
 			'remaining' => $remaining,
 			'caller' => $context['caller'] ?? 'unknown',
 		], '429', 'Provider in cooldown' );
 		throw new \Exception( "HTTP 429 Provider '{$provider_name}' is in cooldown for {$remaining}s." );
 	}

 		$payload = [
 			'post_content_length' => mb_strlen( $post_content ),
 			'system_prompt_length' => mb_strlen( $system_prompt ),
 			'provider' => $provider_name,
 			'model' => $model,
 			'_nonce' => wp_generate_password( 12, false ),
 		];
 		if ( ! empty( $context['image_path'] ) ) {
 			$payload['image_path'] = $context['image_path'];
 		}

 		$request_hash = ApiCallManager::hash_request( $provider_name, $payload );

 		$quota_status = QuotaStateManager::get_quota_status( $provider_name );
 		$quota_allowed = QuotaStateManager::can_make_request( $provider_name );

 		$call_id = ApiCallManager::create_call( [
 			'job_id' => $context['job_id'] ?? null,
 			'provider' => $provider_name,
 			'model' => $model,
 			'request_hash' => $request_hash,
 			'request_payload' => $payload,
 			'quota_allowed' => $quota_allowed,
 			'status' => Config::API_CALL_PENDING,
 			'caller_context' => $context['caller'] ?? 'unknown',
 		] );

 		if ( $call_id === false ) {
 			Logger::warning( 'api_call_tracking_failed', $context['job_id'] ?? null, [
 				'provider' => $provider_name,
 				'request_hash' => $request_hash,
 			], '500', 'Failed to create API call tracking record. Proceeding without tracking.' );
 			$call_id = null;
 		}

 		Logger::debug( 'api_call_initiated', $context['job_id'] ?? null, [
 			'call_id' => $call_id,
 			'provider' => $provider_name,
 			'model' => $model,
 			'request_hash' => $request_hash,
 			'quota_status' => $quota_status,
 			'caller' => $context['caller'] ?? 'unknown',
 		], '200' );

 		$start_time = microtime( true );
 		$raw_response_body = '';

 		try {
 			if ( ! empty( $context['image_path'] ) && method_exists( $provider, 'analyze_image' ) ) {
 				$example_images = $context['example_images'] ?? [];
 				$result = $provider->analyze_image( $context['image_path'], $system_prompt, $example_images );
 			} else {
 				$result = $provider->generate_content( $post_content, $system_prompt );
 			}
 			$execution_time = microtime( true ) - $start_time;

 			$input_tokens = 0;
 			$output_tokens = 0;
 			$clean_result = $result;
 			if ( is_array( $result ) ) {
 				$input_tokens = isset( $result['_meta']['input_tokens'] ) ? (int) $result['_meta']['input_tokens'] : 0;
 				$output_tokens = isset( $result['_meta']['output_tokens'] ) ? (int) $result['_meta']['output_tokens'] : 0;
 				$clean_result = array_diff_key( $result, [ '_meta' => true ] );
 			}

 			if ( $call_id ) {
 				ApiCallManager::update_call( $call_id, [
 					'response_code' => '200',
 					'response_body' => wp_json_encode( $clean_result ),
 					'token_count_input' => $input_tokens,
 					'token_count_output' => $output_tokens,
 					'execution_time' => $execution_time,
 					'status' => Config::API_CALL_SUCCESS,
 				] );
 			}

 			$actual_requests = method_exists( $provider, 'get_actual_request_count' ) ? $provider->get_actual_request_count() : 1;

 			$actual_model = $provider->get_model_name();

 			ProviderCooldown::reset_auth_failure_count( $provider_name );

 			Logger::info( 'api_call_completed', $context['job_id'] ?? null, [
 				'call_id' => $call_id,
 				'provider' => $provider_name,
 				'model' => $actual_model,
 				'requested_model' => $model,
 				'actual_requests' => $actual_requests,
 				'execution_time' => round( $execution_time, 3 ),
 			], '200', '', $execution_time );

 			unset( $result['_meta'] );

 			return $result;

 		} catch ( \Throwable $e ) {
 			$execution_time = microtime( true ) - $start_time;

 			$http_code = 0;
 			if ( preg_match( '/HTTP (\d{3})/', $e->getMessage(), $m ) ) {
 				$http_code = (int) $m[1];
 			}

 			$error_body = '';
 			if ( preg_match( '/:\s*(\{.+)/s', $e->getMessage(), $em ) ) {
 				$error_body = $em[1];
 			}

 			if ( $call_id ) {
 				ApiCallManager::update_call( $call_id, [
 					'response_code' => (string) $http_code,
 					'response_body' => mb_substr( $e->getMessage(), 0, 500 ),
 					'execution_time' => $execution_time,
 					'status' => Config::API_CALL_FAILED,
 				] );
 			}

 			Logger::error( 'api_call_failed', $context['job_id'] ?? null, [
 				'call_id' => $call_id,
 				'provider' => $provider_name,
 				'model' => $model,
 				'error' => $e->getMessage(),
 			], (string) $http_code, $e->getMessage(), $execution_time );

 			throw new \Exception( $e->getMessage(), $http_code );
 		}
 	}

	public static function get_provider_instance( $provider_name, array $context = [] ) {
		if ( Config::is_custom_provider( $provider_name ) ) {
			$profile = Config::get_custom_profile( $provider_name );
			if ( ! $profile ) {
				throw new \Exception( "Custom provider '{$provider_name}' not found in saved profiles." );
			}
			$api_key = $profile['api_key'] ?? '';
			if ( empty( $api_key ) ) {
				throw new \Exception( "API key missing for custom provider '{$provider_name}'." );
			}
			return new CustomProvider( $api_key, $profile, $provider_name );
		}
		switch ( $provider_name ) {
			case Config::PROVIDER_GEMINI:
				return new GeminiProvider();
			case Config::PROVIDER_GROQ:
				return new GroqProvider();
			default:
				throw new \Exception( "Unknown provider: {$provider_name}. Cannot create instance." );
		}
	}

	public static function test_connection( $provider_name ) {
		$provider = self::get_provider_instance( $provider_name );
		return $provider->test_connection();
	}

	/**
	 * Build an ordered list of providers to try.
	 * Primary provider first, then all other registered providers.
	 */
	public static function get_fallback_chain( string $primary_provider ): array {
		$all = self::get_available_providers();
		$chain = [];

		if ( isset( $all[ $primary_provider ] ) ) {
			$chain[] = $primary_provider;
			unset( $all[ $primary_provider ] );
		}

		foreach ( $all as $name => $_label ) {
			$chain[] = $name;
		}

		return $chain;
	}

	/**
	 * Get all providers that are available (registered, not misconfigured, and have valid API key).
	 * Providers in cooldown are still included — they'll be skipped at call time.
	 * Providers without API keys are excluded to avoid wasting fallback attempts.
	 */
	private static function get_available_providers(): array {
		$registered = Config::get_registered_providers();
		$available = [];
		foreach ( $registered as $name => $label ) {
			if ( ProviderCooldown::is_misconfigured( $name ) ) {
				continue;
			}
			if ( ProviderCooldown::is_daily_quota_blocked( $name ) ) {
				Logger::debug( 'provider_skipped_daily_quota', null, [
					'provider' => $name,
					'reason' => 'Daily quota exhausted',
				] );
				continue;
			}
			if ( ! Config::has_valid_api_key( $name ) ) {
				Logger::debug( 'provider_skipped_no_api_key', null, [
					'provider' => $name,
					'reason' => 'No valid API key configured',
				] );
				continue;
			}
			if ( Config::is_custom_provider( $name ) ) {
				$profile = Config::get_custom_profile( $name );
				if ( is_array( $profile ) && empty( $profile['fallback_enabled'] ) ) {
					Logger::debug( 'provider_skipped_fallback_disabled', null, [
						'provider' => $name,
						'reason' => 'Fallback disabled in provider settings',
					] );
					continue;
				}
			}
			$available[ $name ] = $label;
		}
		return $available;
	}

	/**
 	 * Try the fallback chain: primary provider → next → next ...
 	 * Each provider is tried ONCE. Each model within a provider is tried ONCE.
 	 * On ANY error, immediately move to the next model/provider.
 	 * Returns result on first success, throws with all failures if all providers exhausted.
 	 */
 	public static function execute_with_fallback( $post_content, $system_prompt = '', string $primary_provider = '', array $context = [] ): array {
 		if ( empty( $primary_provider ) ) {
 			$primary_provider = Config::DEFAULT_STRATEGY;
 		}

 		$chain = self::get_fallback_chain( $primary_provider );
 		$all_failures = [];

 		if ( count( $chain ) <= 1 ) {
 			$all_registered = array_keys( Config::get_registered_providers() );
 			$excluded = array_diff( $all_registered, $chain );
 			$excluded_reasons = [];
 			foreach ( $excluded as $ex ) {
 				if ( ProviderCooldown::is_misconfigured( $ex ) ) {
 					$excluded_reasons[$ex] = 'misconfigured';
 				} elseif ( ! Config::has_valid_api_key( $ex ) ) {
 					$excluded_reasons[$ex] = 'no_api_key';
 				} else {
 					$excluded_reasons[$ex] = 'unknown';
 				}
 			}
 			Logger::warning( 'fallback_chain_single_provider', $context['job_id'] ?? null, [
 				'primary' => $primary_provider,
 				'chain' => $chain,
 				'excluded' => $excluded_reasons,
 				'caller' => $context['caller'] ?? 'unknown',
 			], '429', 'Fallback chain has only 1 provider — configure API keys for other providers' );
 		}

Logger::info( 'fallback_chain_initiated', $context['job_id'] ?? null, [
			'primary' => $primary_provider,
			'chain' => $chain,
			'caller' => $context['caller'] ?? 'unknown',
		], '200' );

		// DEDUPLICATION: Track providers that have permanently failed for this job.
		// On job retry (re-scheduled after transient failure), skip providers that
		// already failed with non-retryable errors (auth, model not found, request shape).
		$job_id = $context['job_id'] ?? 0;
		$permanent_failures = [];
		if ( $job_id ) {
			$permanent_failures = get_transient( 'ai_collage_job_perm_fail_' . (int) $job_id );
			if ( ! is_array( $permanent_failures ) ) {
				$permanent_failures = [];
			}
		}

		foreach ( $chain as $provider_name ) {
			// Skip providers that permanently failed in a previous attempt for this job.
			if ( in_array( $provider_name, $permanent_failures, true ) ) {
				Logger::info( 'fallback_skip_permanent_failure', $context['job_id'] ?? null, [
					'provider' => $provider_name,
				], '200' );
				continue;
			}
  			if ( ProviderCooldown::is_daily_quota_blocked( $provider_name ) ) {
  				$remaining = ProviderCooldown::get_daily_quota_remaining( $provider_name );
  				Logger::info( 'fallback_skip_daily_quota', $context['job_id'] ?? null, [
  					'provider' => $provider_name,
  					'remaining' => $remaining,
  				], '429' );
  				$all_failures[] = [
  					'provider' => $provider_name,
  					'error' => "Daily quota exhausted, resets in {$remaining}s",
  					'http_code' => 429,
  				];
  				continue;
  			}

  			if ( ProviderCooldown::is_in_cooldown( $provider_name ) ) {
 				$remaining = ProviderCooldown::get_cooldown_remaining( $provider_name );
 				Logger::info( 'fallback_skip_cooldown', $context['job_id'] ?? null, [
 					'provider' => $provider_name,
 					'remaining' => $remaining,
 				], '429' );
 				$all_failures[] = [
 					'provider' => $provider_name,
 					'error' => "In cooldown for {$remaining}s",
 					'http_code' => 429,
 				];
 				continue;
 			}

 			if ( ! Config::has_valid_api_key( $provider_name ) ) {
 				Logger::info( 'fallback_skip_no_api_key', $context['job_id'] ?? null, [
 					'provider' => $provider_name,
 				], '403' );
 				$all_failures[] = [
 					'provider' => $provider_name,
 					'error' => 'No API key configured',
 					'http_code' => 403,
 				];
 				continue;
 			}

 			try {
 				$provider_instance = self::get_provider_instance( $provider_name );
 			} catch ( \Throwable $e ) {
 				Logger::warning( 'fallback_provider_init_failed', $context['job_id'] ?? null, [
 					'provider' => $provider_name,
 					'error' => $e->getMessage(),
 				], '500' );
 				$all_failures[] = [
 					'provider' => $provider_name,
 					'error' => $e->getMessage(),
 					'http_code' => 0,
 				];
 				continue;
 			}

 			$initial_model = $provider_instance->get_model_name();
 			$last_error = '';
 			$http_code = 0;

 			try {
 				$result = self::execute( $provider_instance, $post_content, $system_prompt, $context );
 				return $result;
 			} catch ( \Throwable $e ) {
 				$last_error = $e->getMessage();
 				$http_code = (int) $e->getCode();
 				if ( $http_code === 0 && preg_match( '/HTTP (\d{3})/', $last_error, $m ) ) {
 					$http_code = (int) $m[1];
 				}

  			$error_body = '';
			if ( preg_match( '/:\s*(\{.+)/s', $last_error, $em ) ) {
				$error_body = $em[1];
			}

			// If GeminiProvider embedded the error_type in the exception message
			// (because the original response body was lost at the throw boundary),
			// recover it here so the fallback chain applies the correct cooldown
			// strategy. Without this, an RPD stays classified as quota_unknown.
			$preserved_error_type = '';
			if ( $provider_name === Config::PROVIDER_GEMINI && preg_match( '/error_type=([a-z_]+)/', $last_error, $etm ) ) {
				$preserved_error_type = $etm[1];
			}

			$error_info = APIErrorParser::parse( $provider_name, $http_code, $error_body, $last_error );

			// Override with preserved error_type when the parser lost fidelity
			// because it received an empty body on a re-parse path.
			if ( $preserved_error_type !== '' && in_array( $preserved_error_type, [
				APIErrorInfo::TYPE_QUOTA_RPD, APIErrorInfo::TYPE_QUOTA_RPM, APIErrorInfo::TYPE_QUOTA_TPM,
				APIErrorInfo::TYPE_SERVER_OVERLOADED, APIErrorInfo::TYPE_TRANSIENT, APIErrorInfo::TYPE_AUTH_FAILURE,
			], true ) ) {
				$error_info->error_type     = $preserved_error_type;
				$error_info->is_retryable    = true;
				$error_info->is_deterministic = false;
			}

 				Logger::warning( 'fallback_attempt_failed', $context['job_id'] ?? null, [
 					'provider' => $provider_name,
 					'model' => $provider_instance->get_model_name(),
 					'http_code' => $http_code,
 					'error_type' => $error_info->error_type,
 					'error' => $last_error,
 				], (string) $http_code );

   			if ( $error_info->error_type === APIErrorInfo::TYPE_AUTH_FAILURE ) {
   				ProviderCooldown::record_auth_failure( $provider_name );
   				if ( $error_info->is_retryable ) {
   					ProviderCooldown::set_cooldown( $provider_name, 120, $error_info->error_type );
   				}
   			} elseif ( $error_info->error_type === APIErrorInfo::TYPE_QUOTA_RPD ) {
   				$reset_at = $error_info->get_reset_at_ts();
   				if ( $reset_at <= 0 ) {
   					$reset_at = time() + 3600;
   				}
   				ProviderCooldown::set_daily_quota( $provider_name, $reset_at );
   			} elseif ( $error_info->is_retryable && ( $error_info->is_quota_error() || $error_info->error_type === APIErrorInfo::TYPE_TRANSIENT || $error_info->error_type === APIErrorInfo::TYPE_SERVER_OVERLOADED ) ) {
   				$retry_after = $error_info->get_retry_after();
   				if ( $retry_after <= 0 ) {
   					$retry_after = 90;
   				}

   				// SAFETY NET: If the API returned 429 with a long Retry-After
   				// suggesting "wait hours" but our parser failed to classify it
   				// as TYPE_QUOTA_RPD (e.g. Gemini's violation array was missing
   				// the 'per_day' marker, or a custom provider omitted RetryInfo),
   				// we escalate to set_daily_quota instead of capping at the
   				// generic 300s cooldown. Without this, a misclassified RPD
   				// would create a 5-min retry churn that defeats the entire
   				// v2 architecture. Threshold: any Retry-After over 600s with a
   				// 429 must be a daily-bucket quota, not a per-minute cap.
   				if ( $http_code === 429 && $retry_after > 600 && $error_info->error_type === APIErrorInfo::TYPE_QUOTA_UNKNOWN ) {
   					$escalated_reset = time() + min( $retry_after, 86400 );
   					ProviderCooldown::set_daily_quota( $provider_name, $escalated_reset );
   					Logger::warning( 'fallback_escalate_to_daily_quota', $context['job_id'] ?? null, [
   						'provider'         => $provider_name,
   						'retry_after'      => $retry_after,
   						'escalated_reset'  => $escalated_reset,
   						'reason'           => '429 with long Retry-After — escalating from short cooldown to daily quarantine',
   					], '429' );
   				} else {
   					ProviderCooldown::set_cooldown( $provider_name, $retry_after, $error_info->error_type );
   				}
   			}

$all_failures[] = [
					'provider' => $provider_name,
					'model' => $provider_instance->get_model_name(),
					'error' => $last_error,
					'http_code' => $http_code,
				];

				// Track permanent failures for this job to skip on retry.
				// Non-retryable errors: AUTH_FAILURE, MODEL_NOT_FOUND, REQUEST_SHAPE, UNKNOWN.
				// These will not succeed on retry, so mark them permanently failed for this job.
				if ( $job_id && ! $error_info->is_retryable ) {
					$permanent_failures[] = $provider_name;
					$permanent_failures = array_unique( $permanent_failures );
					set_transient( 'ai_collage_job_perm_fail_' . (int) $job_id, $permanent_failures, DAY_IN_SECONDS );
					Logger::info( 'fallback_record_permanent_failure', $job_id, [
						'provider' => $provider_name,
						'error_type' => $error_info->error_type,
					], '200' );
				}
			}
		}

 		$summary = array_map( function ( $f ) {
 			return "{$f['provider']}: {$f['error']}";
 		}, $all_failures );

 		$all_registered_names = array_keys( Config::get_registered_providers() );
 		$excluded_from_chain = array_diff( $all_registered_names, array_map( function( $f ) { return $f['provider']; }, $all_failures ) );
 		$excluded_reasons = [];
  		foreach ( $excluded_from_chain as $ex ) {
 			if ( ProviderCooldown::is_misconfigured( $ex ) ) {
 				$excluded_reasons[$ex] = 'misconfigured';
 			} elseif ( ProviderCooldown::is_daily_quota_blocked( $ex ) ) {
 				$excluded_reasons[$ex] = 'daily_quota_exhausted';
 			} elseif ( ProviderCooldown::is_in_cooldown( $ex ) ) {
 				$excluded_reasons[$ex] = 'in_cooldown';
 			} elseif ( ! Config::has_valid_api_key( $ex ) ) {
 				$excluded_reasons[$ex] = 'no_api_key';
 			} else {
 				$excluded_reasons[$ex] = 'skipped';
 			}
 		}

  		Logger::error( 'fallback_chain_exhausted', $context['job_id'] ?? null, [
 			'primary' => $primary_provider,
 			'total_providers_tried' => count( $all_failures ),
 			'failures' => $all_failures,
 			'excluded_providers' => $excluded_reasons,
 		], '500' );

 		set_transient( 'ai_collage_quota_panic_window', time(), 900 );

 		throw new \Exception( 'All providers failed. Tried ' . count( $all_failures ) . ' provider(s): ' . implode( ' | ', $summary ) );
 	}
}
