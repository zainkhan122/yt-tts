<?php

declare(strict_types=1);

namespace DIT\TrendStudio\Tests\Fakes;

use DIT\TrendStudio\Services\Content_Cleaner;

final class FakeContentCleaner extends Content_Cleaner
{
    public array $calls = [];

    public function __construct() {}

    public function clean(string $html): string
    {
        return $html;
    }

    public function clean_generated_content(string $html): string
    {
        $this->calls[] = $html;
        return $html;
    }
}
