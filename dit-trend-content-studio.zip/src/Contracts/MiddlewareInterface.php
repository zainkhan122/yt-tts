<?php

namespace DIT\TrendStudio\Contracts;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * MiddlewareInterface
 *
 * Contract for content processing steps in the generation pipeline.
 *
 * @package DIT_TrendStudio
 * @since 2.10.0
 */
interface MiddlewareInterface
{
    /**
     * Process the article data.
     *
     * @param array    $data     Article data (content, meta, etc.)
     * @param array    $context  Pipeline context (input_data, vertical, etc.)
     * @param callable $next     The next middleware core.
     * @return array Modified article data.
     */
    public function handle(array $data, array $context, callable $next): array;
}
