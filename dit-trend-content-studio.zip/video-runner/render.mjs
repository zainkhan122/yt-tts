#!/usr/bin/env node
/**
 * DIT Video Module — renderer v2
 *
 * Reads a manifest.json and produces final.mp4 (vertical 9:16 short):
 *   - Per-scene TTS: if manifest has scene_scripts[], each image gets its own
 *     audio (tight narration/image sync). Else a single full narration.mp3.
 *   - Varied Ken Burns motion: cycles zoom-in / zoom-out / pan per scene so it
 *     never looks like static images.
 *   - Crossfade transitions (xfade video + acrossfade audio) between scenes.
 *   - Heading (Urdu, top) + brand bar (logo+name, bottom) burned via puppeteer
 *     (proper RTL) with a graceful ffmpeg-only fallback when no Chrome.
 *   - No cropping: use_black_bars letterboxes any aspect ratio.
 *
 * Usage: node render.mjs <manifest.json>
 */
import { readFile, writeFile } from 'fs/promises';
import { existsSync, statSync, writeFileSync } from 'fs';
import { execFileSync } from 'child_process';
import { join } from 'path';
import { fileURLToPath } from 'url';

const manifestPath = process.argv[2];
if (!manifestPath) { console.error('Usage: node render.mjs <manifest.json>'); process.exit(1); }
const cfg = JSON.parse(await readFile(manifestPath, 'utf8'));
const { workdir, images, short_clips, scene_scripts, narration, heading, brand, heading_font_size, max_duration, use_black_bars, tts, video, env } = cfg;
const clipsShort = Array.isArray(short_clips) ? short_clips : [];

const out = (n) => join(workdir, n);
const run = (cmd, args, opts = {}) => execFileSync(cmd, args, { stdio: 'inherit', ...opts });
const esc = (s) => String(s || '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const W = video.width || 1080;
const H = video.height || 1920;
const FPS = video.fps || 30;
const FONT = brand.urdu_font || '';
const LATIN = brand.latin_font || '';
const headingFs = heading_font_size || 64;
const scripts = Array.isArray(scene_scripts) && scene_scripts.length ? scene_scripts : null;
let useScripts = false; // resolved in main() once scene count is known
const TRANS = 0.5; // crossfade seconds

// ---------- TTS (per-scene or single) ----------
function ttsOne(text, dest) {
  const py = env.python || 'python3';
  // dest may be absolute (per-scene) or relative (narration.mp3).
  const tf = dest.endsWith('.txt') ? dest : (dest.includes('/') ? dest + '.txt' : out(dest + '.txt'));
  writeFileSync(tf, text);
  try {
    if (tts.backend === 'kokoro') {
      run(py, [join(__dirname(), 'tts_kokoro.py'), tf, dest, tts.voice || 'af_heart', tts.speed || '1.15'], { stdio: 'inherit' });
    } else {
      run(py, [join(__dirname(), 'tts.py'), tf, dest, tts.voice || 'ur-PK-UzmaNeural', tts.speed || '1.15', 'ur-PK'], { stdio: 'inherit' });
    }
    return dest;
  } catch (e) {
    console.error('TTS failed for', dest, e.message);
    const dur = scripts ? 4 : (max_duration || 60);
    run(env.ffmpeg || 'ffmpeg', ['-y', '-f', 'lavfi', '-i', 'anullsrc=r=44100:cl=mono', '-t', String(dur), '-c:a', 'libmp3lame', '-b:a', '128k', dest]);
    return dest;
  }
}

// ---------- puppeteer overlay (TRANSPARENT: heading + brand bar only) ----------
// The image itself is rendered by ffmpeg (reliable). Puppeteer only produces a
// transparent PNG containing the Urdu heading + brand bar/logo, which ffmpeg
// composites on top of the image. This avoids Chrome failing to load file://
// CSS background images (which caused black frames).
let browser;
async function renderOverlayPng(idx) {
  const puppeteer = await importPuppeteer();
  if (!browser) {
    const launchOpts = { args: ['--no-sandbox', '--disable-gpu', '--hide-scrollbars', '--disable-dev-shm-usage'] };
    if (env.chrome) launchOpts.executablePath = env.chrome;
    browser = await puppeteer.launch(launchOpts);
  }
  const page = await browser.newPage();
  await page.setViewport({ width: W, height: H, deviceScaleFactor: 1 });
  const logo = brand.logo && existsSync(brand.logo) ? `<img class="logo" src="file://${brand.logo}">` : '';
  const html = `<!doctype html><html dir="rtl"><head><meta charset="utf-8"><style>
    html,body{margin:0;padding:0;width:${W}px;height:${H}px;overflow:hidden;background:transparent;font-family:${LATIN ? `'${LATIN}'` : 'sans-serif'};}
    .heading{position:absolute;left:30px;right:30px;top:150px;color:#fff;text-align:center;
      font-family:${FONT ? `'${FONT}'` : 'inherit'};font-size:${headingFs}px;font-weight:700;line-height:1.5;
      text-shadow:0 3px 12px rgba(0,0,0,.95),0 1px 2px rgba(0,0,0,.9);
      background:rgba(0,0,0,.25);padding:8px 14px;border-radius:12px;}
    .brandbar{position:absolute;left:22px;bottom:22px;display:flex;align-items:center;gap:12px;
      background:rgba(0,0,0,.55);padding:8px 16px 8px 10px;border-radius:999px;box-shadow:0 4px 16px rgba(0,0,0,.5);}
    .logo{width:48px;height:48px;border-radius:50%;object-fit:cover;background:#fff;}
    .brandname{color:#fff;font-size:26px;font-weight:800;letter-spacing:.4px;font-family:${LATIN ? `'${LATIN}'` : 'inherit'};}
  </style></head><body>
    ${heading ? `<div class="heading">${esc(heading)}</div>` : ''}
    ${brand.name ? `<div class="brandbar">${logo}<span class="brandname">${esc(brand.name)}</span></div>` : ''}
  </body></html>`;
  await page.setContent(html, { waitUntil: 'load' });
  await page.evaluate(() => new Promise((res) => {
    const imgs = Array.from(document.images);
    if (!imgs.length) return res();
    let n = 0; imgs.forEach(i => { if (i.complete && i.naturalHeight) { n++; if (n === imgs.length) res(); } else { i.onload = i.onerror = () => { n++; if (n === imgs.length) res(); }; } });
    setTimeout(res, 1500);
  }));
  const png = out(`ov-${idx}.png`);
  await page.screenshot({ path: png, omitBackground: true }); // transparent bg
  await page.close();
  return png;
}
async function importPuppeteer() { try { return await import('puppeteer'); } catch (_) { return await import('puppeteer-core'); } }

// ---------- short-clip scene (optional) ----------
// Download a short-form clip (IG Reel / YT Short / TikTok) via yt-dlp, crop to
// vertical with a blurred pillarbox (no cropping), and use it as a motion scene.
function isSmn(u) { return /(instagram|tiktok|facebook|fb\.watch)/i.test(u || ''); }

async function buildShortScene(clip) {
  const yt = env.ytdlp || 'yt-dlp';
  const src = out('short.mp4');
  const norm = out('short-norm.mp4');
  // Already short -> full download, low-res for speed.
  try {
    execFileSync(yt, ['--no-warnings', '-f', 'best[height<=720]/best', '--merge-output-format', 'mp4', '-o', src, clip.url], { stdio: 'ignore' });
  } catch (e) {
    console.error('short clip download failed', clip.url, e.message);
    return null;
  }
  if (!existsSync(src)) return null;
  const ff = env.ffmpeg || 'ffmpeg';
  const dur = 5;
  try {
    // Blur-pillarbox: fill background blurred, foreground full-width centered.
    execFileSync(ff, [
      '-y', '-i', src,
      '-filter_complex',
      `[0:v]split=2[bg][fg];[bg]scale=${W}:${H}:force_original_aspect_ratio=increase,crop=${W}:${H},boxblur=luma_radius=24:luma_power=1[bgv];` +
      `[fg]scale=${W}:-2[fgv];[bgv][fgv]overlay=(W-w)/2:(H-h)/2,setsar=1,fps=${FPS},trim=duration=${dur},setpts=PTS-STARTPTS[v]`,
      '-map', '[v]', '-t', String(dur),
      '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-r', String(FPS), '-crf', '21', '-an', '-movflags', '+faststart', norm,
    ], { stdio: 'ignore' });
  } catch (e) {
    console.error('short clip composite failed', e.message);
    return null;
  }
  if (!existsSync(norm)) return null;
  return { clip: norm, dur, idx: 'short', video: true };
}

// ---------- scene build ----------
async function buildScenes() {
  const imgCount = images.length;
  if (!imgCount && !clipsShort.length) throw new Error('No images or clips.');
  const total = Math.max(3, max_duration || 60);
  const per = Math.max(3, Math.floor(total / Math.min(imgCount, 10)));
  const count = Math.min(imgCount, Math.floor(total / per));
  const scenes = [];
  // Prepend short video clips as hook scenes (best effort).
  for (const clip of clipsShort) {
    const sc = await buildShortScene(clip);
    if (sc) scenes.push(sc);
  }
  for (let i = 0; i < count; i++) {
    scenes.push({ img: images[i], dur: per, idx: i });
  }
  for (const s of scenes) {
    if (s.video) continue; // already a ready clip
    try { s.overlay = await renderOverlayPng(s.idx); }
    catch (e) { console.error('puppeteer overlay failed', s.idx, e.message, '— text-only fallback will be skipped.'); s.overlay = ''; }
  }
  return scenes;
}

// ---------- varied Ken Burns motion ----------
// Returns the zoompan portion (single filter with all params) plus scale/crop prefix.
function motionFilter(frames, idx) {
  const zp = `zoompan=d=${frames}:s=${W}x${H}:fps=${FPS}`;
  let zx = `x='iw/2-(iw/zoom/2)'`;
  let zy = `y='ih/2-(ih/zoom/2)'`;
  let z;
  switch (idx % 4) {
    case 0: z = `z='min(zoom+0.0007,1.15)'`; break;              // zoom in
    case 1: z = `z='max(1.15-0.0007*on,1)'`; break;              // zoom out
    case 2: z = `z='min(zoom+0.0005,1.12)'`; zx = `x='iw/2-(iw/zoom/2)+${Math.round(0.03*W)}*on/${frames}'`; break; // pan right
    default: z = `z='min(zoom+0.0005,1.12)'`; zy = `y='ih/2-(ih/zoom/2)+${Math.round(0.03*H)}*on/${frames}'`; break; // pan down
  }
  return `scale=${W*2}:${H*2}:force_original_aspect_ratio=increase,crop=${W*2}:${H*2},${zp}:${z}:${zx}:${zy}`;
}

// ---------- audio per scene ----------
function renderSceneAudio(s) {
  if (!scripts) return;
  const text = scripts[s.idx] || '';
  const a = out(`audio-${s.idx}.mp3`);
  ttsOne(text, a);
  s.audio = a;
  // Size the scene to the narration so TTS never sounds cut off / mostly silence.
  s.dur = Math.max(3, Math.min(8, Math.ceil(audioDuration(a) + 1.2)));
}

// Probe the duration (seconds) of an audio file via ffprobe/ffmpeg.
function audioDuration(path) {
  if (!existsSync(path)) return 4;
  // ffprobe (clean).
  try {
    const ffprobe = env.ffprobe || 'ffprobe';
    const out = execFileSync(ffprobe, ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', path], { stdio: ['ignore','pipe','ignore'] }).toString().trim();
    const d = parseFloat(out);
    if (isFinite(d) && d > 0) return d;
  } catch (_) { /* fall through */ }
  // ffmpeg -i prints Duration to stderr and exits non-zero (no output file),
  // so read stderr from the thrown error.
  try {
    const ff = env.ffmpeg || 'ffmpeg';
    let out = '';
    try {
      out = execFileSync(ff, ['-hide_banner', '-i', path], { stdio: ['ignore','ignore','pipe'] }).toString();
    } catch (e) {
      out = (e.stderr && e.stderr.toString()) || '';
    }
    const m = out.match(/Duration: (\d+):(\d{2}):(\d{2}(?:\.\d+)?)/);
    return m ? (+m[1]*3600 + +m[2]*60 + +m[3]) : 4;
  } catch (_) { return 4; }
}

// ---------- per-scene render: IMAGE (ffmpeg) + overlay + motion + audio + fades ----------
// The image is always rendered by ffmpeg (guaranteed visible). If a puppeteer
// transparent overlay exists, it's composited on top. Each scene is a
// self-contained MP4 (video + its own audio) with fades so concat is smooth and
// scales to any scene count.
function renderScene(s, isFirst, isLast) {
  const ff = env.ffmpeg || 'ffmpeg';
  if (s.video) { s.clip = s.clip; return; } // ready-made clip scene
  const clip = out(`scene-${s.idx}.mp4`);
  const frames = Math.max(2, Math.round(s.dur * FPS));
  const hasOv = !!(s.overlay && existsSync(s.overlay));

  // Background = the IMAGE letterboxed (no crop) with Ken Burns motion.
  const bgMotion = `scale=${W}:${H}:force_original_aspect_ratio=decrease,pad=${W}:${H}:(ow-iw)/2:(oh-ih)/2:color=black,setsar=1,${motionFilter(frames, s.idx).replace(/^scale=[^,]+,crop=[^,]+,/,'')}`;

  const vFades = `${isFirst ? '' : `,fade=t=in:st=0:d=${TRANS}`}${isLast ? '' : `,fade=t=out:st=${(s.dur - TRANS).toFixed(2)}:d=${TRANS}`}`;
  const aFades = `${isFirst ? '' : `,afade=t=in:st=0:d=${TRANS}`}${isLast ? '' : `,afade=t=out:st=${(s.dur - TRANS).toFixed(2)}:d=${TRANS}`}`;

  const audioInput = (s.audio && existsSync(s.audio)) ? s.audio : null;

  const inputs = ['-i', s.img];
  const filters = [];
  if (hasOv) {
    inputs.push('-i', s.overlay);
    filters.push(`[0:v]${bgMotion},trim=duration=${s.dur},setpts=PTS-STARTPTS[v0]`);
    filters.push(`[1:v]format=rgba[ov]`);
    const ovFades = vFades ? ',' + vFades.replace(/^,/, '') : '';
    filters.push(`[v0][ov]overlay=0:0:format=auto${ovFades}[v]`);
  } else {
    filters.push(`[0:v]${bgMotion},trim=duration=${s.dur},setpts=PTS-STARTPTS${vFades}[v]`);
  }

  if (audioInput) {
    inputs.push('-i', audioInput);
    filters.push(`[${hasOv ? 2 : 1}:a]atrim=0:${s.dur},asetpts=PTS-STARTPTS,aformat=sample_rates=44100:channel_layouts=mono,aresample=async=1:first_pts=0${aFades},apad[a]`);
  }

  const args = ['-y', ...inputs, '-filter_complex', filters.join(';'), '-map', '[v]'];
  if (audioInput) {
    args.push('-map', '[a]', '-c:a', 'aac', '-ar', '44100', '-ac', '1', '-b:a', '128k');
  } else {
    args.push('-an');
  }
  args.push('-t', String(s.dur), '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-r', String(FPS), '-crf', '21', '-movflags', '+faststart', clip);
  run(ff, args);
  s.clip = clip;
}

// ---------- assemble: concat via demuxer (scales to any scene count) ----------
async function assemble(scenes) {
  const ff = env.ffmpeg || 'ffmpeg';
  const list = out('concat.txt');
  await writeFile(list, scenes.map(s => `file '${s.clip.replace(/'/g, "'\\''")}'`).join('\n') + '\n');

  if (scenes.length === 1 && !useScripts) {
    // single scene with a global narration: mux narration (in case audio path differs)
    const merged = scenes[0].clip;
    const audio = out('narration.mp3');
    if (existsSync(audio)) {
      run(ff, ['-y', '-i', merged, '-i', audio, '-map', '0:v', '-map', '1:a', '-c:v', 'copy', '-c:a', 'aac', '-ar', '44100', '-ac', '1', '-b:a', '128k', '-shortest', '-movflags', '+faststart', out('final.mp4')]);
      return;
    }
  }

  // Re-encode the concat (NOT -c copy) so all parts share identical metadata and
  // audio params, guaranteeing a clean output even with varied scene audio.
  run(ff, ['-y', '-f', 'concat', '-safe', '0', '-i', list,
    '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-r', String(FPS), '-crf', '20',
    '-c:a', 'aac', '-ar', '44100', '-ac', '1', '-b:a', '128k',
    '-movflags', '+faststart', out('final.mp4')]);
}

function __dirname() { return fileURLToPath(new URL('.', import.meta.url)); }

// ---------- main ----------
try {
  let scenes = await buildScenes();
  // If a short clip was prepended, the per-scene script count may not match the
  // scene count; fall back to a single flowing narration for safety.
  useScripts = scripts && (scripts.length === scenes.length);
  if (scripts && !useScripts) {
    console.warn('Scene/script count mismatch — using single narration.');
  }
  if (useScripts) {
    scenes.forEach(renderSceneAudio);
    // Ensure total duration stays within max_duration: trim trailing padding.
    const cap = Math.max(3, max_duration || 60);
    let total = scenes.reduce((a, s) => a + s.dur, 0);
    if (total > cap) {
      // Reduce each scene's padding evenly, keeping >= 3s (narration intact).
      const excess = total - cap;
      const paddingEach = scenes.reduce((a, s) => a + Math.max(0, s.dur - 3), 0);
      const cutEach = paddingEach > 0 ? excess / Math.min(scenes.length, paddingEach) : 0;
      scenes.forEach(s => { s.dur = Math.max(3, Math.round(s.dur - cutEach)); });
      total = scenes.reduce((a, s) => a + s.dur, 0);
      // Last resort: hard cap the final scene.
      if (total > cap && scenes.length) scenes[scenes.length-1].dur -= (total - cap);
    }
  } else {
    ttsOne(narration || '', out('narration.mp3'));
  }
  scenes.forEach((s, i) => renderScene(s, i === 0, i === scenes.length - 1));
  await assemble(scenes);
  if (browser) await browser.close();
  const size = existsSync(out('final.mp4')) ? statSync(out('final.mp4')).size : 0;
  if (size < 1000) throw new Error('Output too small.');
  console.log('OK', size);
  process.exit(0);
} catch (e) {
  if (browser) { try { await browser.close(); } catch (_) {} }
  console.error('RENDER ERROR', e.stack || e.message);
  process.exit(1);
}
