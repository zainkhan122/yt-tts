<?php
/**
 * AJAX Manager - User Dashboard
 *
 * Handles all AJAX requests for the logged-in user's dashboard,
 * including profile settings and stats.
 *
 * @package WP_News_MCQ_Generator
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class NM_AJAX_Dashboard {

	// ============================================================================
	// User Dashboard & Settings Handlers
	// ============================================================================

	public static function nm_update_user_profile_handler() {
		check_ajax_referer( 'nm_profile_update', '_wpnonce' );

		if ( ! NM_Response_Handler::require_login() ) {
			return;
		}

		$user_id      = get_current_user_id();
		$display_name = sanitize_text_field( $_POST['display_name'] ?? '' );
		$user_bio     = sanitize_textarea_field( $_POST['nm_user_bio'] ?? '' );
		$is_public    = intval( $_POST['nm_public_profile'] ?? 0 );

		if ( empty( $display_name ) ) {
			NM_Response_Handler::error( 'Display name is required', 'name_required' );
			return;
		}

		wp_update_user(
			array(
				'ID'           => $user_id,
				'display_name' => $display_name,
			)
		);
		update_user_meta( $user_id, 'nm_user_bio', $user_bio );
		update_user_meta( $user_id, 'nm_public_profile', $is_public );

		NM_Response_Handler::success( array( 'message' => 'Profile updated successfully' ) );
	}

	public static function nm_change_user_password_handler() {
		check_ajax_referer( 'nm_password_change', '_wpnonce' );

		if ( ! NM_Response_Handler::require_login() ) {
			return;
		}

		$user_id          = get_current_user_id();
		$user             = get_user_by( 'id', $user_id );
		$current_password = $_POST['current_password'] ?? '';
		$new_password     = $_POST['new_password'] ?? '';

		if ( empty( $current_password ) || empty( $new_password ) ) {
			NM_Response_Handler::error( 'Please fill all fields', 'fields_empty' );
			return;
		}

		if ( ! wp_check_password( $current_password, $user->user_pass, $user_id ) ) {
			NM_Response_Handler::error( 'Current password is incorrect', 'password_mismatch' );
			return;
		}

		if ( strlen( $new_password ) < 8 ) {
			NM_Response_Handler::error( 'New password must be at least 8 characters', 'password_short' );
			return;
		}

		wp_set_password( $new_password, $user_id );
		wp_set_auth_cookie( $user_id ); // Re-log in with new password

		NM_Response_Handler::success( array( 'message' => 'Password changed successfully' ) );
	}

	public static function nm_delete_user_account_handler() {
		check_ajax_referer( 'nm_dashboard_ajax_nonce', '_wpnonce' );

		if ( ! NM_Response_Handler::require_login() ) {
			return;
		}

		$user_id = get_current_user_id();

		if ( user_can( $user_id, 'manage_options' ) ) {
			NM_Response_Handler::error( 'Admins cannot be deleted from here.', 'admin_delete_self' );
			return;
		}

		require_once ABSPATH . 'wp-admin/includes/user.php';
		wp_delete_user( $user_id );
		wp_logout();

		NM_Response_Handler::success( array( 'message' => 'Account deleted successfully.' ) );
	}

	public static function nm_ajax_get_recent_activity() {
		check_ajax_referer( 'nm_dashboard_ajax_nonce', 'nonce' );

		if ( ! NM_Response_Handler::require_login() ) {
			return;
		}

		$user_id = get_current_user_id();
		global $wpdb;
		$table = $wpdb->prefix . 'nm_user_answers';

		$results = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT a.mcq_id, a.is_correct, a.answered_at, p.post_title 
             FROM {$table} a 
             JOIN {$wpdb->posts} p ON a.mcq_id = p.ID 
             WHERE a.user_id = %d 
             ORDER BY a.answered_at DESC 
             LIMIT 5",
				$user_id
			)
		);

		$activities = array();
		if ( $results ) {
			foreach ( $results as $row ) {
				$topics     = get_the_terms( $row->mcq_id, 'topic' );
				$topic_name = 'General';
				if ( ! empty( $topics ) && ! is_wp_error( $topics ) ) {
					$topic_name = $topics[0]->name;
				}
				$activities[] = array(
					'id'         => $row->mcq_id,
					'title'      => $row->post_title,
					'is_correct' => (bool) $row->is_correct,
					'topic'      => $topic_name,
					'time_ago'   => human_time_diff( strtotime( $row->answered_at ), current_time( 'timestamp' ) ) . ' ago',
					'url'        => get_permalink( $row->mcq_id ),
				);
			}
		}
		NM_Response_Handler::success( $activities );
	}

	public static function nm_ajax_get_performance_chart() {
		check_ajax_referer( 'nm_dashboard_ajax_nonce', 'nonce' );

		if ( ! NM_Response_Handler::require_login() ) {
			return;
		}

		$user_id = get_current_user_id();
		$history = self::nm_get_user_performance_history( $user_id, 7 );
		NM_Response_Handler::success( $history );
	}

	public static function nm_ajax_get_topic_progress() {
		check_ajax_referer( 'nm_dashboard_ajax_nonce', 'nonce' );

		if ( ! NM_Response_Handler::require_login() ) {
			return;
		}

		$user_id = get_current_user_id();
		global $wpdb;
		$answers_table = $wpdb->prefix . 'nm_user_answers';

		$results = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT t.name as topic_name, t.slug as topic_slug, t.term_id as topic_id, 
                    COUNT(a.id) as total_answered, SUM(a.is_correct) as total_correct 
             FROM {$answers_table} a 
             JOIN {$wpdb->term_relationships} tr ON a.mcq_id = tr.object_id 
             JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id 
             JOIN {$wpdb->terms} t ON tt.term_id = t.term_id 
             WHERE a.user_id = %d AND tt.taxonomy = 'topic' 
             GROUP BY t.term_id 
             ORDER BY total_answered DESC",
				$user_id
			)
		);

		$progress_data = array();
		if ( $results ) {
			foreach ( $results as $row ) {
				$term            = get_term( $row->topic_id, 'topic' );
				$total_in_topic  = ( $term && ! is_wp_error( $term ) ) ? $term->count : 0;
				$total_answered  = (int) $row->total_answered;
				$total_correct   = (int) $row->total_correct;
				$progress_data[] = array(
					'name'       => $row->topic_name,
					'accuracy'   => $total_answered > 0 ? round( ( $total_correct / $total_answered ) * 100 ) : 0,
					'percentage' => $total_in_topic > 0 ? round( ( $total_answered / $total_in_topic ) * 100 ) : 0,
					'completed'  => $total_answered,
					'total'      => $total_in_topic,
				);
			}
		}
		NM_Response_Handler::success( $progress_data );
	}

	// ============================================================================
	// Private Helper Functions
	// ============================================================================

	/**
	 * Gets user performance history for the dashboard chart.
	 */
	private static function nm_get_user_performance_history( $user_id, $days = 7 ) {
		global $wpdb;
		$history = array();
		$table   = $wpdb->prefix . 'nm_user_answers';

		for ( $i = 0; $i < $days; $i++ ) {
			$date  = date( 'Y-m-d', strtotime( "-{$i} days" ) );
			$stats = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT COUNT(*) as total, SUM(is_correct) as correct 
                 FROM {$table} 
                 WHERE user_id = %d AND DATE(answered_at) = %s",
					$user_id,
					$date
				)
			);

			$total    = (int) ( $stats->total ?? 0 );
			$correct  = (int) ( $stats->correct ?? 0 );
			$accuracy = $total > 0 ? round( ( $correct / $total ) * 100 ) : 0;

			$history[] = array(
				'date'     => date( 'M d', strtotime( $date ) ),
				'accuracy' => $accuracy,
				'total'    => $total,
			);
		}
		return array_reverse( $history );
	}
}
