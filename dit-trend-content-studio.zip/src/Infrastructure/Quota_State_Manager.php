<?php

/**
 * Quota State Manager
 *
 * Live per-provider+model quota tracking with predictive throttling.
 * Maintains sliding-window RPM counts, daily RPD counts, and TPM usage
 * derived from API response metadata. Enables the system to self-regulate
 * BEFORE hitting 429s instead of only reacting after them.
 *
 * Storage: WordPress transients (auto-expiring, no manual cleanup needed).
 *
 * @package DIT_TrendStudio
 * @since 2026-04-22
 */

namespace DIT\TrendStudio\Infrastructure;

if (!defined('ABSPATH')) {
    exit;
}

class Quota_State_Manager
{
    const GREEN = 'green';
    const YELLOW = 'yellow';
    const RED = 'red';

    private static $default_limits = [
	'gemini' => [
		'rpm' => 15,
		'rpd' => 1500,
		'tpm' => 1000000,
	],
	'custom' => [
		'rpm' => 10,
		'rpd' => 0,
		'tpm' => 0,
	],
    ];

    /**
     * Record a successful API call — update RPM/RPD/TPM counters.
     *
     * @param string $provider Provider slug
     * @param string $model    Model identifier (optional)
     * @param array  $usage    Token usage from response ['prompt_tokens'=>, 'candidates_tokens'=>, 'total_tokens'=>]
     */
    public static function record_success(string $provider, string $model = '', array $usage = []): void
    {
        $provider = sanitize_key($provider);
        $now = time();

        $state = self::load_state($provider);
        $state['last_success_at'] = $now;

        // Rotate RPM window
        if (!isset($state['rpm_window']['start']) || ($now - $state['rpm_window']['start']) >= 60) {
            $state['rpm_window']['start'] = $now;
            $state['rpm_window']['count'] = 0;
        }
        $state['rpm_window']['count']++;

        // Rotate RPD window
        $day_key = self::day_key($provider);
        if (($state['rpd_window']['day_key'] ?? '') !== $day_key) {
            $state['rpd_window'] = ['day_key' => $day_key, 'count' => 1];
        } else {
            $state['rpd_window']['count']++;
        }

        // Rotate TPM window
        if (!empty($usage['total_tokens'])) {
            if (!isset($state['tpm_window']['start']) || ($now - $state['tpm_window']['start']) >= 60) {
                $state['tpm_window']['start'] = $now;
                $state['tpm_window']['tokens'] = 0;
            }
            $state['tpm_window']['tokens'] += $usage['total_tokens'];
        }

        self::save_state($provider, $state);

        if (class_exists(__NAMESPACE__ . '\\Quota_Pause_Manager')) {
            Quota_Pause_Manager::reset_consecutive_on_success($provider);
        }

        Usage_Tracker::increment($provider);
    }

    /**
     * Calibrate state from a 429 error — update limits from API response data.
     *
     * @param string $provider Provider slug
     * @param array  $error_info Parsed error from API_Error_Parser
     */
    public static function calibrate_from_error(string $provider, array $error_info): void
    {
        $provider = sanitize_key($provider);
        $state = self::load_state($provider);
        $now = time();

        if ($error_info['quota_bucket'] === API_Error_Parser::RPM) {
            $state['rpm_window']['count'] = ($state['rpm_window']['limit'] ?? 0) ?: self::get_default_limit($provider, 'rpm');
        }
        if ($error_info['quota_bucket'] === API_Error_Parser::RPD) {
            $state['rpd_window']['count'] = ($state['rpd_window']['limit'] ?? 0) ?: self::get_default_limit($provider, 'rpd');
            if (!empty($error_info['reset_at'])) {
                $state['rpd_window']['reset_at'] = (int) $error_info['reset_at'];
            }
        }
        if ($error_info['quota_bucket'] === API_Error_Parser::TPM) {
            $state['tpm_window']['tokens'] = ($state['tpm_window']['limit'] ?? 0) ?: self::get_default_limit($provider, 'tpm');
        }

        if (!empty($error_info['rate_limit_limit'])) {
            $state['rpm_window']['limit'] = (int) $error_info['rate_limit_limit'];
        }
        if (!empty($error_info['rate_limit_remaining'])) {
            $state['rpm_window']['remaining'] = (int) $error_info['rate_limit_remaining'];
        }

        $state['last_error_at'] = $now;
        $state['last_error_type'] = $error_info['error_type'] ?? 'unknown';

        self::save_state($provider, $state);
    }

    /**
     * Get the health status for a provider's quota buckets.
     *
     * @param string $provider Provider slug
     * @return array Per-bucket health + recommended action
     */
    public static function get_health(string $provider): array
    {
        $provider = sanitize_key($provider);
        $state = self::load_state($provider);
        $now = time();

        $rpm_count = self::current_rpm_count($state, $now);
        $rpm_limit = $state['rpm_window']['limit'] ?? self::get_default_limit($provider, 'rpm');
        $rpm_pct = $rpm_limit > 0 ? ($rpm_count / $rpm_limit) : 0;

        $rpd_count = $state['rpd_window']['count'] ?? 0;
        $rpd_limit = $state['rpd_window']['limit'] ?? self::get_default_limit($provider, 'rpd');

        // @MODIFIED 2026-05-05 - Reset stale RPD count if the day has changed.
        // When the system was paused overnight, yesterday's 95% RPD persisted,
        // causing aggressive throttling even though the daily quota has fully reset.
        $day_key = self::day_key($provider);
        if (($state['rpd_window']['day_key'] ?? '') !== $day_key) {
            $state['rpd_window'] = ['day_key' => $day_key, 'count' => 0, 'limit' => $rpd_limit, 'reset_at' => 0];
            self::save_state($provider, $state);
            $rpd_count = 0;
        }

        $rpd_pct = $rpd_limit > 0 ? ($rpd_count / $rpd_limit) : 0;

        $tpm_tokens = self::current_tpm_tokens($state, $now);
        $tpm_limit = $state['tpm_window']['limit'] ?? self::get_default_limit($provider, 'tpm');
        $tpm_pct = $tpm_limit > 0 ? ($tpm_tokens / $tpm_limit) : 0;

        return [
            'rpm' => [
                'used' => $rpm_count,
                'limit' => $rpm_limit,
                'pct' => round($rpm_pct * 100, 1),
                'status' => self::pct_to_status($rpm_pct),
            ],
            'rpd' => [
                'used' => $rpd_count,
                'limit' => $rpd_limit,
                'pct' => round($rpd_pct * 100, 1),
                'status' => self::pct_to_status($rpd_pct),
                'reset_at' => (int) ($state['rpd_window']['reset_at'] ?? 0),
            ],
            'tpm' => [
                'used' => $tpm_tokens,
                'limit' => $tpm_limit,
                'pct' => round($tpm_pct * 100, 1),
                'status' => self::pct_to_status($tpm_pct),
            ],
            'recommended_interval' => self::calc_recommended_interval($provider, $rpm_pct, $rpd_pct),
            'is_near_limit' => ($rpm_pct > 0.85 || $rpd_pct > 0.85 || $tpm_pct > 0.85),
        ];
    }

    /**
     * Get recommended minimum interval (seconds) between API calls.
     * Increases as RPM usage grows to avoid hitting the ceiling.
     */
    public static function get_recommended_interval(string $provider): int
    {
        $health = self::get_health($provider);
        return $health['recommended_interval'];
    }

    /**
     * Should we self-throttle before making the next call?
     */
    public static function should_throttle(string $provider): bool
    {
        $health = self::get_health($provider);
        return $health['is_near_limit'];
    }

    /**
     * Wait until it's safe to make the next API call.
     * Called from AI_Network_Trait's enforce_rpm_throttle().
     */
    public static function wait_for_safe_slot(string $provider): void
    {
        $interval = self::get_recommended_interval($provider);
        $state = self::load_state($provider);
        $last = $state['last_success_at'] ?? $state['last_error_at'] ?? 0;
        $elapsed = time() - $last;
        $wait = max(0, $interval - $elapsed);

        if ($wait > 0) {
            sleep($wait);
        }
    }

    public static function get_state(string $provider): array
    {
        return self::load_state(sanitize_key($provider));
    }

    public static function clear_state(string $provider): void
    {
        delete_transient('dit_ts_' . sanitize_key($provider) . '_quota_state');
    }

    private static function load_state(string $provider): array
    {
        $key = "dit_ts_{$provider}_quota_state";
        $state = (array) get_transient($key);
        if (empty($state)) {
            $state = self::initial_state($provider);
        }
        return $state;
    }

    private static function save_state(string $provider, array $state): void
    {
        $key = "dit_ts_{$provider}_quota_state";
        set_transient($key, $state, 6 * HOUR_IN_SECONDS);
    }

	private static function initial_state(string $provider): array
	{
		if (!isset(self::$default_limits[$provider])) {
			$limits = apply_filters('dit_ts_quota_default_limits', ['rpm' => 10, 'rpd' => 0, 'tpm' => 0], $provider);
		} else {
			$limits = self::$default_limits[$provider];
		}
        $now = time();
        return [
            'rpm_window' => [
                'start' => $now,
                'count' => 0,
                'limit' => $limits['rpm'],
                'remaining' => null,
            ],
            'rpd_window' => [
                'day_key' => self::day_key($provider),
                'count' => 0,
                'limit' => $limits['rpd'],
                'reset_at' => 0,
            ],
            'tpm_window' => [
                'start' => $now,
                'tokens' => 0,
                'limit' => $limits['tpm'],
            ],
            'last_success_at' => 0,
            'last_error_at' => 0,
            'last_error_type' => '',
        ];
    }

    private static function current_rpm_count(array $state, int $now): int
    {
        $start = $state['rpm_window']['start'] ?? 0;
        if (($now - $start) >= 60) {
            return 0;
        }
        return (int) ($state['rpm_window']['count'] ?? 0);
    }

    private static function current_tpm_tokens(array $state, int $now): int
    {
        $start = $state['tpm_window']['start'] ?? 0;
        if (($now - $start) >= 60) {
            return 0;
        }
        return (int) ($state['tpm_window']['tokens'] ?? 0);
    }

    private static function day_key(string $provider): string
    {
        if ($provider === 'gemini') {
            try {
                $pt = new \DateTimeZone('America/Los_Angeles');
                return (new \DateTimeImmutable('now', $pt))->format('Y-m-d');
            } catch (\Throwable $e) {
                return gmdate('Y-m-d');
            }
        }
        return gmdate('Y-m-d');
    }

    private static function pct_to_status(float $pct): string
    {
        if ($pct >= 0.85) {
            return self::RED;
        }
        if ($pct >= 0.65) {
            return self::YELLOW;
        }
        return self::GREEN;
    }

    private static function calc_recommended_interval(string $provider, float $rpm_pct, float $rpd_pct): int
    {
        $base = ($provider === 'gemini') ? 5 : 3;

        if ($rpm_pct >= 0.90 || $rpd_pct >= 0.90) {
            return (int) ($base * 3);
        }
        if ($rpm_pct >= 0.70 || $rpd_pct >= 0.70) {
            return (int) ($base * 2);
        }
        if ($rpm_pct >= 0.50 || $rpd_pct >= 0.50) {
            return (int) ($base * 1.5);
        }
        return $base;
    }

    private static function get_default_limit(string $provider, string $bucket): int
    {
        return (int) ((self::$default_limits[$provider] ?? [])[$bucket] ?? 0);
    }
}
