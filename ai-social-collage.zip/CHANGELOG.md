# Changelog

## [3.2.0] - 2026-08-27

### Added
- **AI-generated YouTube Shorts title + description** — `yt_title` (≤70 chars, keyword front-loaded) and `yt_description` (primary keyword in first 100 chars + CTA + channel link) are now explicit fields returned by every AI rewrite result, stored as `_ai_collage_auto_meta[ai_yt_title]` / `[ai_yt_description]`, and consumed by `BufferIntegration` for the YouTube title GraphQL field and caption path respectively. Fallback chain: `ai_yt_title` → `ai_headline` → `post_title` for title; `ai_yt_description` → `ai_detailed_description` for caption.
- **`#Shorts` always prepended to YouTube hashtag block** — `BufferIntegration::share_to_account()` injects `#Shorts` as the leading hashtag when building the YouTube caption, guaranteeing Shorts shelf eligibility regardless of what the AI returns in `ai_hashtags`.

### Changed
- `ContentRewriter` prompt templates (English + Urdu) — added `yt_title` and `yt_description` fields to the JSON schema returned by the LLM for all categories (entertainment, tech, celebrity, controversy, emotional, inspirational, breaking, film, news, modern, impact, sports, politics).

### Files Modified
- `core/Services/ContentRewriter.php` — added `yt_title`/`yt_description` to `validate_rewrite_json()`, `normalize_ai_response_fields()` field_map, and all category prompt JSON schemas.
- `core/Actions/QueueProcessor.php` — added `ai_yt_title`/`ai_yt_description` to the `$ai_meta` array persisted to `_ai_collage_auto_meta`.
- `core/Services/BufferIntegration.php` — `build_metadata()` YouTube title priority: `ai_yt_title` first; channel-desc override: `ai_yt_description` for YouTube caption; `#Shorts` prepend applied to `ai_hashtags` block for YouTube channels.
- `core/Actions/QueueProcessor.php` — Gutenberg post-content blocks for both image and video pipelines now include `ai_yt_title` and `ai_yt_description` as labelled paragraph blocks (visible in WP editor, same pattern as existing `x_content` block), alongside the existing headline/description/hashtags/x_content/mentions blocks.

## [3.1.8] - 2026-08-26

### Fixed
- **Audio type classification relied on a single 5-second sample** — `detect_audio_type()` decided `voice` vs `music` from one window at 50% of the video, so reels with intro music before speech (or vocal music) could flip either way depending on where the sample landed. Log evidence 2026-08-25: all 4 music detections sat at `speech_ratio` 0.43–0.47, immediately against the 0.5 threshold.

### Added
- **Gray-zone re-sample in `VideoProcessor::detect_audio_type()`** — when `speech_ratio` lands in 0.40–0.60, a second sample is taken from a different position (25% of duration for normal videos, 50% for short clips with the first sample at 0), gated on `$offset + $sample_duration <= $duration` and a ≥1 s separation from the first window; both windows' `full_rms_db`/`speech_ratio` are averaged before classification. If no valid second position exists (very short clips), the single-sample decision stands.
- Re-sampled decisions log extra fields on `video_audio_type_detected`: `resampled: true` and the second window's `speech_ratio_2`.

### Files Modified
- `core/Services/VideoProcessor.php` — gray-zone re-sample + averaged classification inside `detect_audio_type()`; docblock updated.

## [3.1.7] - 2026-08-24

### Fixed
- **Duplicate `pending` rows accumulated forever in the jobs table** — `Migration::create_tables()` has defined `UNIQUE KEY post_id_status (post_id, status)` since 2.0, but `dbDelta` silently skipped adding it on populated tables (the `@` operator suppresses the failure). Production databases ended up with no unique constraint at all. Evidence 2026-08-24: post 29241 had rows `107984 + 3345` both in `pending` (same for 29247 / `108004 + 3346`, 29255 / `108025 + 3347`, 29259 / `108040 + 3348`). Side effect: `PostObserver`'s `INSERT ... ON DUPLICATE KEY UPDATE` was effectively a plain insert — every new RSS/draft import produced a duplicate pending row that the monitor never re-enqueued (it picks the lowest id first), so the new row sat as a permanent zombie.

### Added
- `Migration::upgrade_to_3_8()` — runs automatically on the next plugin load. Idempotent: returns immediately if `post_id_status` already exists. Otherwise dedupes (keeps lowest id per `(post_id, status)` pair) and adds the UNIQUE KEY via direct `ALTER TABLE` (bypassing the unreliable `@dbDelta` path). Emits `error_log` lines for the dedup count and the key-add outcome so admins can verify the upgrade ran.

### Files Modified
- `core/Database/Migration.php` — bumped `SCHEMA_VERSION` to `3.8`; added `upgrade_to_3_8()` and a version-3.8 block in `maybe_upgrade()`.

## [3.1.6] - 2026-08-24

### Fixed
- **Stuck `pending` jobs were never recovered or cleaned** — `JobManager::mark_stuck_jobs_failed()` only transitioned `rewriting`/`rendering` jobs to `failed`. A job stuck in `pending` (lost Action Scheduler action, silently failed enqueue) sat in the queue forever, and retention never removed it because `CleanupManager::clean_jobs()` only deleted `completed`/`failed`/`discarded` rows. `scheduled` jobs whose one-shot prime-time action was lost were likewise never deleted.

### Added
- `JobManager::purge_stuck_jobs()` — deletes `pending`/`scheduled` jobs whose `updated_at` is older than the job-retention window (defense-in-depth for jobs orphaned beyond the stuck-detection timeout). `ready_for_review` is excluded; `rewriting`/`rendering` are excluded (handled within minutes by `mark_stuck_jobs_failed()`).
- Pending-orphan recovery in `JobManager::mark_stuck_jobs_failed()` — a `pending` job older than the stuck timeout is now failed **only when it no longer owns a live (`pending`/`in-progress`) Action Scheduler action**. Pause-safe: `QueueProcessor::process_job()` defers pending jobs every 60s while the pipeline is paused, so paused jobs always own a live action and are never falsely failed (protects the `ajax_resume_pipeline()` re-enqueue flow). If a ghost action fires after the job was failed, `do_process_job()` safely no-ops on `STATUS_FAILED` (`job_already_failed_skip`).
- **Opt-in uninstall data wipe** — new `uninstall.php` removes everything the plugin generates: custom tables (`ai_collage_jobs`, `ai_collage_logs`, `ai_collage_api_calls`), generated attachments (`_is_ai_social_collage`), plugin-created posts (`_ai_collage_auto_meta`, `_ai_collage_rss_source_url`), all `_ai_collage_*` postmeta, all `ai_collage_*` options/transients (incl. health-check token), the plugin's Action Scheduler entries/orphaned claims, and its WP-Cron events. **Disabled by default** — runs only when "Delete Data on Uninstall" is checked in Settings → Retention. Plugin updates never trigger it; only plugin deletion does. Multisite-aware. Remote R2/Cloudinary objects are intentionally not touched (no external API calls during uninstall).

### Changes
- `CleanupManager::clean_jobs()` — no longer duplicates purge SQL. Delegates to `JobManager::purge_discarded_jobs()`, `purge_stuck_jobs()` and `purge_old_jobs()`, making `JobManager` the single CRUD authority for the jobs table (previously `purge_old_jobs()`/`purge_discarded_jobs()` were dead code).

### Files Modified
- `core/Database/JobManager.php` — pending-orphan recovery in `mark_stuck_jobs_failed()`; added `purge_stuck_jobs()`
- `core/Services/CleanupManager.php` — `clean_jobs()` delegates to JobManager purge methods
- `core/Config.php` — added `OPTION_DELETE_DATA_ON_UNINSTALL`, `DEFAULT_DELETE_DATA_ON_UNINSTALL`
- `core/View/Dashboard.php` — "Delete Data on Uninstall" checkbox in Settings → Retention + save handler
- `uninstall.php` — new: opt-in full data wipe on plugin deletion

## [3.1.5] - 2026-08-18

### Fixed
- **Urdu video heading text clipped on right side despite sufficient space** — Pango RTL rendering anchors text at the right edge of the canvas, causing the right bearing of Urdu Nastaliq characters to extend beyond the canvas boundary and be clipped during rasterization. A malformed `-border %dx%dx%d%d` geometry string meant post-trim padding was never applied correctly, compounding the issue. Additionally, `wrap_text_for_pango` used GD FreeType metrics for line-wrapping which underestimated HarfBuzz-shaped output width by 10-30%, causing lines to overflow `$max_width` after Pango rendering.

### Changes
- `VideoProcessor::render_text_to_png()` — Removed ineffective `×2.0` canvas multiplier (Pango always anchors RTL at right edge regardless of canvas width). Replaced malformed `-border` geometry with correct `-splice` commands for precise per-side padding. Added asymmetric right-side padding (5× left) to compensate for RTL right-bearing clipping. Added RTL right-margin spaces in Pango markup (3 spaces per line) to push text leftward so the right bearing falls within the canvas during rasterization — the core fix for right-side clipping.
- `VideoProcessor::wrap_text_for_pango()` — Added HarfBuzz safety margin: wraps Urdu text at 85% of `$max_width` instead of 100% to account for OpenType GSUB/GPOS shaping producing wider output than FreeType metrics.
- `VideoRenderer::fit_heading_to_area()` — Fixed width validation to compare against `$canvas_w` (not `$max_width`) when `$bg_color` is set, preventing unnecessary font-size reduction in the bg-composite path.

### Files Modified
- `core/Services/VideoProcessor.php` — Fixed `-splice` padding, removed `×2.0` multiplier, added HarfBuzz safety margin in `wrap_text_for_pango()`
- `core/Services/VideoRenderer.php` — Fixed width validation in `fit_heading_to_area()`

## [3.1.4] - 2026-08-18

### Fixed
- **Video poster/cover shows black screen instead of video content** — Social media platforms (WhatsApp, Instagram, Facebook) extract the first frame of the MP4 as the video cover. The composed video's first frame was a black canvas (from `color=c=black` in the FFmpeg filter chain) with heading/branding overlaid, causing the cover to appear as a black screen. The actual video content was only visible after pressing play.

### Added
- `VideoProcessor::prepend_poster_frame()` — After composing the video reel, extracts a representative frame at 25% of duration, creates a 0.5s clip from that frame using the FFmpeg `loop` filter, and concatenates it before the full video. This ensures the first frame of the output MP4 always shows actual video content. Gracefully falls back (leaves video unchanged) for videos shorter than 1 second or if FFmpeg post-processing fails.

### Files Modified
- `core/Services/VideoProcessor.php` — Added `prepend_poster_frame()` method; added call site in `compose_reel()` after successful composition
- `core/Services/CleanupManager.php` — Added `poster_clip_*.mp4` and `poster_final_*.mp4` to temp cleanup patterns

## [3.1.3] - 2026-08-17

### Added
- **User-editable post content routable to Buffer** — All placeholder fields (headline, hook, description, X-content, tags, mentions) are now editable in the Gutenberg editor and user changes are synced back to `META_AUTO_META` so Buffer shares the user-approved content.
- `BufferIntegration::parse_post_content_for_buffer()` — Parses Gutenberg blocks or classic editor content into structured fields for Buffer templates.
- `PostObserver::sync_user_edits_to_meta()` — `save_post` hook (priority 20) that extracts user edits from `post_content`/`post_title` and updates `META_AUTO_META`.
- Gutenberg block output in `QueueProcessor::step_render()` and `step_render_video()` — Posts now use native blocks (`<!-- wp:heading -->`, `<!-- wp:paragraph -->`, `<!-- wp:image -->`, `<!-- wp:video -->`) for mobile-friendly editing.

### Removed
- `the_content` filter in `ai-social-collage.php` — Removed placeholder replacement (`[heading]`, `[hook]`, etc.) that conflicted with Gutenberg blocks and broke mobile editing.

### Files Modified
- `core/Services/BufferIntegration.php` — Added `parse_post_content_for_buffer()`
- `core/Actions/QueueProcessor.php` — Gutenberg block output in `step_render()` and `step_render_video()`
- `core/Actions/PostObserver.php` — Added `sync_user_edits_to_meta()` hook
- `ai-social-collage.php` — Removed `the_content` filter

## [1.0.1] - 2026-08-16

### Fixed
- **TypeError in JobManager::sanitize_utf8_text()** - Method now accepts nullable string (`?string`) and handles null input gracefully. Added null coalescing in `update_job_data()` for `$headline` and `$hook` parameters.
- **JSON validation error "missing headline or hook in response"** - Added field normalization to handle AI model response variations (Gemini 2.5 Flash returns `title`/`post` instead of `headline`/`detailed_description`)

### Added
- `normalize_ai_response_fields()` static method in ContentRewriter.php - Maps common AI response field variations to canonical names:
  - `title`, `ai_headline`, `head_line`, `heading` → `headline`
  - `post`, `ai_detailed_description`, `description`, `body`, `content`, `article` → `detailed_description`
  - `ai_hook`, `lead`, `summary`, `intro`, `excerpt` → `hook`
  - `category`, `section`, `topic` → `eyebrow`
  - `emphasis`, `keyword`, `focus_word` → `emphasis_word`
  - `keywords`, `tags`, `entities` → `key_terms`
- Automatic hook derivation from `detailed_description` when hook is missing
- Retry logic with prompt correction in both `rewrite()` and `rewrite_with_fallback()` methods for:
  - JSON validation failures
  - Language/script detection issues (Roman Urdu, Latin chars in Urdu, etc.)
  - Inappropriate Urdu word detection
  - Non-Urdu script / corrupted Unicode detection

### Changed
- Both `rewrite()` and `rewrite_with_fallback()` now call field normalization BEFORE validation
- Both methods now retry up to 3 times with corrected prompts on validation/quality failures
- `JobManager::sanitize_utf8_text()` type hint changed from `string` to `?string` with null handling
- `JobManager::update_job_data()` now explicitly coalesces null headline/hook to empty strings

### Files Modified
- `core/Services/ContentRewriter.php`
- `core/Database/JobManager.php`