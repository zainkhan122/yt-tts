<?php
namespace AiSocialCollage\View;

use AiSocialCollage\Config;
use AiSocialCollage\Database\JobManager;
use AiSocialCollage\Database\ApiCallManager;
use AiSocialCollage\Database\Migration;
use AiSocialCollage\Logger;
use AiSocialCollage\Services\FeedIngester;
use AiSocialCollage\Services\AIProviderRegistry;
use AiSocialCollage\Services\CustomProvider;
use AiSocialCollage\Services\OpenRouterModelSync;
use AiSocialCollage\Services\OpenCodeZenModelSync;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Dashboard {

	const PAGE_SLUG_MAIN = 'ai-social-collage';
	const PAGE_SLUG_CAMPAIGNS = 'ai-social-collage-campaigns';
	const PAGE_SLUG_JOBS = 'ai-social-collage-jobs';
	const PAGE_SLUG_LOGS = 'ai-social-collage-logs';
	const PAGE_SLUG_BRAND = 'ai-social-collage-brand';
	const PAGE_SLUG_SOCIAL = 'ai-social-collage-social';
	const PAGE_SLUG_FEEDS = 'ai-social-collage-feeds';
	const PAGE_SLUG_SETTINGS = 'ai-social-collage-settings';

	public function __construct() {
		add_action( 'admin_menu', [ $this, 'register_menu' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_scripts' ] );
		add_action( 'admin_notices', [ $this, 'render_chromium_health_notice' ] );
		add_action( 'wp_ajax_ai_collage_save_campaigns', [ $this, 'ajax_save_campaigns' ] );
		add_action( 'wp_ajax_ai_collage_run_campaign', [ $this, 'ajax_run_campaign' ] );
		add_action( 'wp_ajax_ai_collage_download_logs', [ $this, 'ajax_download_logs' ] );
		add_action( 'wp_ajax_ai_collage_clear_logs', [ $this, 'ajax_clear_logs' ] );
		add_action( 'wp_ajax_ai_collage_delete_job', [ $this, 'ajax_delete_job' ] );
		add_action( 'wp_ajax_ai_collage_retry_job', [ $this, 'ajax_retry_job' ] );
		add_action( 'wp_ajax_ai_collage_delete_campaign', [ $this, 'ajax_delete_campaign' ] );
		add_action( 'wp_ajax_ai_collage_save_feeds', [ $this, 'ajax_save_feeds' ] );
		add_action( 'wp_ajax_ai_collage_delete_feed', [ $this, 'ajax_delete_feed' ] );
		add_action( 'wp_ajax_ai_collage_test_feed', [ $this, 'ajax_test_feed' ] );
		add_action( 'wp_ajax_ai_collage_poll_feed', [ $this, 'ajax_poll_feed' ] );
		add_action( 'wp_ajax_ai_collage_save_rss_settings', [ $this, 'ajax_save_rss_settings' ] );
		add_action( 'wp_ajax_ai_collage_stop_campaign', [ $this, 'ajax_stop_campaign' ] );
		add_action( 'wp_ajax_ai_collage_stop_all_campaigns', [ $this, 'ajax_stop_all_campaigns' ] );
		add_action( 'wp_ajax_ai_collage_test_custom_provider', [ $this, 'ajax_test_custom_provider' ] );
		add_action( 'wp_ajax_ai_collage_pause_pipeline', [ $this, 'ajax_pause_pipeline' ] );
		add_action( 'wp_ajax_ai_collage_resume_pipeline', [ $this, 'ajax_resume_pipeline' ] );
		add_action( 'wp_ajax_ai_collage_clear_stuck_jobs', [ $this, 'ajax_clear_stuck_jobs' ] );
		add_action( 'wp_ajax_nm_delete_buffer_drafts', [ $this, 'ajax_delete_buffer_drafts' ] );
		add_action( 'wp_ajax_ai_collage_reset_system', [ $this, 'ajax_reset_system' ] );
		add_action( 'wp_ajax_ai_collage_toggle_health_monitor_forced_run', [ $this, 'ajax_toggle_health_monitor_forced_run' ] );
		add_action( 'wp_ajax_ai_collage_force_recover_jobs', [ $this, 'ajax_force_recover_jobs' ] );
		add_action( 'wp_ajax_ai_collage_sync_openrouter_models', [ $this, 'ajax_sync_openrouter_models' ] );
		add_action( 'wp_ajax_ai_collage_sync_zen_models', [ $this, 'ajax_sync_zen_models' ] );
		add_action( 'wp_ajax_ai_collage_test_r2', [ $this, 'ajax_test_r2_connection' ] );
	}

	public function register_menu() {
		add_menu_page(
			'AI Social Collage',
			'AI Collage Pro',
			'manage_options',
			self::PAGE_SLUG_MAIN,
			[ $this, 'render_dashboard' ],
			'dashicons-share-alt',
			30
		);

		add_submenu_page( self::PAGE_SLUG_MAIN, 'Dashboard', 'Dashboard', 'manage_options', self::PAGE_SLUG_MAIN, [ $this, 'render_dashboard' ] );
		add_submenu_page( self::PAGE_SLUG_MAIN, 'Campaigns', 'Campaigns', 'manage_options', self::PAGE_SLUG_CAMPAIGNS, [ $this, 'render_campaigns_page' ] );
		add_submenu_page( self::PAGE_SLUG_MAIN, 'Jobs', 'Jobs', 'manage_options', self::PAGE_SLUG_JOBS, [ $this, 'render_jobs_page' ] );
		add_submenu_page( self::PAGE_SLUG_MAIN, 'Logs', 'Logs', 'manage_options', self::PAGE_SLUG_LOGS, [ $this, 'render_logs_page' ] );
		add_submenu_page( self::PAGE_SLUG_MAIN, 'Brand Kit', 'Brand Kit', 'manage_options', self::PAGE_SLUG_BRAND, [ $this, 'render_brand_page' ] );
		add_submenu_page( self::PAGE_SLUG_MAIN, 'Feeds', 'Feeds', 'manage_options', self::PAGE_SLUG_FEEDS, [ $this, 'render_feeds_page' ] );
		add_submenu_page( self::PAGE_SLUG_MAIN, 'Social', 'Social', 'manage_options', self::PAGE_SLUG_SOCIAL, [ $this, 'render_social_page' ] );
		add_submenu_page( self::PAGE_SLUG_MAIN, 'Settings', 'Settings', 'manage_options', self::PAGE_SLUG_SETTINGS, [ $this, 'render_settings_page' ] );
	}

	public function enqueue_scripts( $hook ) {
		$plugin_pages = [
			'toplevel_page_' . self::PAGE_SLUG_MAIN,
			'ai-social-collage_page_' . self::PAGE_SLUG_CAMPAIGNS,
			'ai-social-collage_page_' . self::PAGE_SLUG_JOBS,
			'ai-social-collage_page_' . self::PAGE_SLUG_LOGS,
			'ai-social-collage_page_' . self::PAGE_SLUG_BRAND,
			'ai-social-collage_page_' . self::PAGE_SLUG_FEEDS,
			'ai-social-collage_page_' . self::PAGE_SLUG_SOCIAL,
			'ai-social-collage_page_' . self::PAGE_SLUG_SETTINGS,
		];

		$is_plugin_page = false;
		foreach ( $plugin_pages as $page_hook ) {
			if ( $hook === $page_hook || stripos( $hook, 'ai-social-collage' ) !== false ) {
				$is_plugin_page = true;
				break;
			}
		}

		if ( ! $is_plugin_page ) {
			return;
		}

		wp_enqueue_media();

		$css_ver = filemtime( AI_SOCIAL_COLLAGE_PATH . 'assets/css/admin-dashboard.css' );
		$js_ver  = filemtime( AI_SOCIAL_COLLAGE_PATH . 'assets/js/admin-dashboard.js' );
		wp_enqueue_style( 'ai-collage-admin', AI_SOCIAL_COLLAGE_URL . 'assets/css/admin-dashboard.css', [], $css_ver );
		wp_enqueue_script( 'ai-collage-admin', AI_SOCIAL_COLLAGE_URL . 'assets/js/admin-dashboard.js', [ 'jquery' ], $js_ver, true );

$categories = get_categories( [ 'hide_empty' => false ] );
		if ( is_wp_error( $categories ) ) {
			$categories = [];
		}
		$cat_options = array_map( function ( $cat ) {
		return [ 'label' => $cat->name, 'value' => $cat->slug, 'term_id' => $cat->term_id ];
	}, $categories );

wp_localize_script( 'ai-collage-admin', 'aiCollageData', [
	'ajax_url' => admin_url( 'admin-ajax.php' ),
	'nonce' => wp_create_nonce( 'ai_collage_nonce' ),
	'download_token' => wp_create_nonce( 'ai_collage_download_logs' ),
	'home_url' => home_url( '/' ),
'categories' => $cat_options,
'templates' => Config::get_templates(),
'template_previews' => Config::get_template_previews(),
'platform_sizes' => Config::get_platform_sizes(),
'template_categories' => Config::get_template_categories(),
'template_languages' => array_combine( array_keys( Config::get_templates() ), array_map( function( $t ) { return Config::get_template_language( $t ); }, array_keys( Config::get_templates() ) ) ),
'image_providers' => Config::get_image_providers(),
'rss_frequencies' => Config::get_rss_frequencies(),
'default_gemini_model' => Config::DEFAULT_GEMINI_MODEL,
'default_groq_model' => Config::DEFAULT_GROQ_MODEL,
'current_gemini_model' => get_option( Config::OPTION_GEMINI_MODEL, Config::DEFAULT_GEMINI_MODEL ),
'current_groq_model' => get_option( Config::OPTION_GROQ_MODEL, Config::DEFAULT_GROQ_MODEL ),
'campaigns' => Config::get_option_array( Config::OPTION_CAMPAIGNS, [] ),
'web_search_types' => Config::get_web_search_types(),
'custom_providers' => Config::get_custom_providers(),
] );
	}

	private function jobs_table() {
		global $wpdb;
		return $wpdb->prefix . Config::TABLE_JOBS;
	}

	private function logs_table() {
		global $wpdb;
		return $wpdb->prefix . Config::TABLE_LOGS;
	}

	private function api_calls_table() {
		global $wpdb;
		return $wpdb->prefix . Config::TABLE_API_CALLS;
	}

	private function get_dashboard_stats() {
		global $wpdb;
		$jt = $this->jobs_table();
		$lt = $this->logs_table();
		$campaigns = Config::get_option_array( Config::OPTION_CAMPAIGNS, [] );

		$jobs_exists = $wpdb->get_var( "SHOW TABLES LIKE '$jt'" ) === $jt;
		$logs_exists = $wpdb->get_var( "SHOW TABLES LIKE '$lt'" ) === $lt;

		$status_counts = $jobs_exists ? JobManager::get_status_counts() : [];
		$total = array_sum( $status_counts );
		$completed = (int) ( $status_counts[ Config::STATUS_COMPLETED ] ?? 0 );
		$pending = (int) ( $status_counts[ Config::STATUS_PENDING ] ?? 0 );
		$rewriting = (int) ( $status_counts[ Config::STATUS_REWRITING ] ?? 0 );
		$rendering = (int) ( $status_counts[ Config::STATUS_RENDERING ] ?? 0 );
		$failed = (int) ( $status_counts[ Config::STATUS_FAILED ] ?? 0 );

		$total_logs   = $logs_exists ? (int) $wpdb->get_var( "SELECT COUNT(*) FROM `$lt`" ) : 0;
		$error_logs   = $logs_exists ? (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `$lt` WHERE log_level = %s", 'error' ) ) : 0;
		$warning_logs = $logs_exists ? (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `$lt` WHERE log_level = %s", 'warning' ) ) : 0;
		$active_campaigns = count( array_filter( $campaigns, function ( $c ) { return ! empty( $c['active'] ); } ) );
		$total_campaigns = count( $campaigns );

		$avg_exec = $logs_exists ? (float) $wpdb->get_var( "SELECT AVG(execution_time) FROM `$lt` WHERE execution_time > 0" ) : 0;
		$last_completed = $jobs_exists ? $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `$jt` WHERE status = %s ORDER BY updated_at DESC LIMIT 1", Config::STATUS_COMPLETED ) ) : null;

		$ai_collage_images_count = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id WHERE p.post_type = 'attachment' AND pm.meta_key = %s AND pm.meta_value = '1'",
				Config::META_IS_AI_COLLAGE
			)
		);

		$images_today = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id WHERE p.post_type = 'attachment' AND pm.meta_key = %s AND pm.meta_value = '1' AND p.post_date >= CURDATE()",
				Config::META_IS_AI_COLLAGE
			)
		);

		$log_retention = (int) get_option( Config::OPTION_LOG_RETENTION_DAYS, Config::DEFAULT_LOG_RETENTION_DAYS );
		$image_retention = (int) get_option( Config::OPTION_IMAGE_RETENTION_DAYS, Config::DEFAULT_IMAGE_RETENTION_DAYS );

		$api_stats = $jobs_exists ? ApiCallManager::get_summary_stats() : [ 'total' => 0, 'success' => 0, 'failed' => 0, 'blocked' => 0, 'total_input_tokens' => 0, 'total_output_tokens' => 0, 'avg_exec' => 0, 'by_provider' => [] ];

		$rss_ingested_total = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = %s",
				Config::META_RSS_SOURCE_URL
			)
		);

		$pipeline_paused = (bool) get_option( Config::OPTION_PIPELINE_PAUSED, false );
		$stuck_jobs = $jobs_exists ? JobManager::count_stuck_jobs( 30 ) : 0;
		$stuck_claims = 0;
		if ( function_exists( 'as_has_scheduled_action' ) ) {
			$as_table = $wpdb->prefix . 'actionscheduler_actions';
			if ( $wpdb->get_var( "SHOW TABLES LIKE '$as_table'" ) === $as_table ) {
				$stuck_claims = (int) $wpdb->get_var( $wpdb->prepare(
					"SELECT COUNT(*) FROM `$as_table` WHERE status = 'in-progress' AND hook = %s",
					Config::ACTION_PROCESS_JOB
				) );
			}
		}
		$as_healthy = function_exists( 'as_has_scheduled_action' );
		$cron_healthy = ! ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON );
		$chromium_health = Config::check_chromium_health();
		$feeds_config = Config::get_option_array( Config::OPTION_RSS_FEEDS, [] );
		$provider_counts = $logs_exists ? ApiCallManager::get_provider_counts( 30 ) : [];

		$viability_stats = $jobs_exists ? JobManager::get_viability_stats() : [ 'total_scored' => 0, 'avg_score' => 0, 'discarded_count' => 0, 'passed_count' => 0, 'score_distribution' => [] ];
		$viability_enabled = (bool) get_option( Config::OPTION_VIABILITY_SCORING_ENABLED, false );
		$log_only_mode = (bool) get_option( Config::OPTION_VIABILITY_LOG_ONLY_MODE, true );
		$viability_threshold = (int) get_option( Config::OPTION_VIABILITY_SCORE_THRESHOLD, 7 );

		$buffer_stats = $this->get_buffer_stats();

	return compact(
		'total', 'completed', 'pending', 'rewriting', 'rendering', 'failed',
		'total_logs', 'error_logs', 'warning_logs',
		'active_campaigns', 'total_campaigns', 'avg_exec', 'last_completed',
		'ai_collage_images_count', 'images_today', 'log_retention', 'image_retention',
		'api_stats', 'rss_ingested_total',
		'pipeline_paused', 'stuck_jobs', 'stuck_claims', 'as_healthy', 'cron_healthy', 'chromium_health',
		'feeds_config', 'provider_counts',
		'viability_stats', 'viability_enabled', 'log_only_mode', 'viability_threshold',
		'buffer_stats',
		'jt', 'lt', 'campaigns'
	);
	}

	private function get_buffer_stats() {
		$active = Config::get_active_buffer_accounts();
		$has_accounts = ! empty( $active );
		$enabled = $has_accounts || (bool) get_option( Config::OPTION_BUFFER_ENABLED, false );
		$has_token = $has_accounts || ! empty( get_option( Config::OPTION_BUFFER_ACCESS_TOKEN, '' ) );

		$cache = get_option( Config::OPTION_BUFFER_STATS_CACHE, [] );
		$draft_count = (int) ( $cache['draft_count'] ?? 0 );

		// Aggregate draft counts from per-account caches
		if ( $has_accounts ) {
			$total_drafts = 0;
			$total_daily_limit = 0;
			foreach ( $active as $acct_id => $acct ) {
				$acct_cache = get_option( Config::OPTION_BUFFER_ACCOUNT_TRACKER_PREFIX . $acct_id, [ 'date' => '', 'ids' => [] ] );
				$today = gmdate( 'Y-m-d' );
				if ( is_array( $acct_cache ) && ( $acct_cache['date'] ?? '' ) === $today ) {
					$total_drafts += count( $acct_cache['ids'] ?? [] );
				}
				$total_daily_limit += max( 0, (int) ( $acct['daily_limit'] ?? 5 ) );
			}
			return [
				'enabled'         => $enabled,
				'has_token'       => $has_token,
				'daily_limit'     => $total_daily_limit,
				'draft_retention' => (int) get_option( Config::OPTION_BUFFER_DRAFT_RETENTION_DAYS, Config::DEFAULT_BUFFER_DRAFT_RETENTION_DAYS ),
				'draft_count'     => $draft_count,
				'account_count'   => count( $active ),
			];
		}

		return [
			'enabled'         => $enabled,
			'has_token'       => $has_token,
			'daily_limit'     => (int) get_option( Config::OPTION_BUFFER_DAILY_LIMIT, 5 ),
			'draft_retention' => (int) get_option( Config::OPTION_BUFFER_DRAFT_RETENTION_DAYS, Config::DEFAULT_BUFFER_DRAFT_RETENTION_DAYS ),
			'draft_count'     => $draft_count,
			'account_count'   => 0,
		];
	}

	// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
	// 1. DASHBOARD PAGE
	// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

	public function render_dashboard() {
		$s = $this->get_dashboard_stats();
		extract( $s );
		?>
		<div class="ai-collage-admin-wrap">
			<div class="ai-collage-header">
				<h1>AI Social Collage Pro</h1>
				<p class="ai-collage-subtitle">Plugin Overview &mdash; Single Source of Truth</p>
			</div>

			<div class="ai-collage-content">
				<div class="ai-collage-dash-cards">
					<div class="dash-card dash-card-health">
						<div class="dash-card-header">System Health</div>
						<div class="dash-card-body">
							<div class="health-row <?php echo $as_healthy ? 'health-ok' : 'health-fail'; ?>">
								<span class="health-dot"></span>
								<span>Action Scheduler</span>
								<span class="health-msg"><?php echo $as_healthy ? 'Available' : 'Not found'; ?></span>
							</div>
							<div class="health-row <?php echo $cron_healthy ? 'health-ok' : 'health-fail'; ?>">
								<span class="health-dot"></span>
								<span>WP Cron</span>
								<span class="health-msg"><?php echo $cron_healthy ? 'Enabled' : 'Disabled'; ?></span>
							</div>
							<div class="health-row <?php echo $chromium_health['all_available'] ? 'health-ok' : 'health-fail'; ?>">
								<span class="health-dot"></span>
								<span>Chromium Render</span>
								<span class="health-msg"><?php echo $chromium_health['all_available'] ? 'Ready' : 'Issues found'; ?></span>
							</div>
							<?php if ( ! $chromium_health['all_available'] ) : ?>
							<div style="padding:4px 0 4px 14px;font-size:11px;color:#50575e;">
								<?php foreach ( [ 'exec' => 'PHP exec()', 'node' => 'Node.js', 'render_script' => 'Render script', 'chromium' => 'Chromium', 'puppeteer' => 'puppeteer-core' ] as $key => $label ) : ?>
								<div style="display:flex;align-items:center;gap:4px;padding:2px 0;">
									<span style="width:6px;height:6px;border-radius:50%;display:inline-block;flex-shrink:0;background:<?php echo $chromium_health[ $key ] ? '#00a32a' : '#d63638'; ?>;"></span>
									<span><?php echo esc_html( $label ); ?></span>
									<span style="margin-left:auto;font-weight:600;font-size:10px;color:<?php echo $chromium_health[ $key ] ? '#00a32a' : '#d63638'; ?>;"><?php echo $chromium_health[ $key ] ? 'OK' : 'Missing'; ?></span>
								</div>
								<?php endforeach; ?>
							</div>
							<?php endif; ?>
							<?php if ( $stuck_jobs > 0 || $stuck_claims > 0 ) : ?>
							<div class="health-row health-fail">
								<span class="health-dot"></span>
								<span>Stuck Items</span>
								<span class="health-msg"><?php echo esc_html( $stuck_jobs ); ?> jobs, <?php echo esc_html( $stuck_claims ); ?> claims</span>
							</div>
							<button type="button" class="button button-small clear-stuck-btn" style="margin: 6px 0 0 0; width:100%;text-align:center; background-color: #d63638; color: white; border-color: #d63638;">Restore System Health</button>
							<?php endif; ?>
							<button type="button" class="button pipeline-toggle-btn" data-paused="<?php echo $pipeline_paused ? '1' : '0'; ?>">
								<?php echo $pipeline_paused ? '▶ Resume Pipeline' : '⏸ Pause Pipeline'; ?>
							</button>
							<button type="button" class="button button-small reset-system-btn" style="margin: 6px 0 0 0; width:100%;text-align:center; background-color: #996800; color: white; border-color: #996800;">&#x21bb; Reset System</button>
							<button type="button" class="button button-small force-recover-btn" style="margin: 4px 0 0 0; width:100%;text-align:center; background-color: #d63638; color: white; border-color: #d63638;">Force Recover Stuck Jobs</button>
							<?php
							$forced_run_enabled = get_option( Config::OPTION_HEALTH_MONITOR_FORCED_RUN, '1' ) === '1';
							?>
							<div style="margin: 10px 0 0 0; padding: 8px; border: 1px solid #c3c4c7; border-radius: 4px; background: #f9f9f9;">
								<div style="display: flex; align-items: center; justify-content: space-between;">
									<span style="font-size: 12px; font-weight: 600;">Forced Queue Run</span>
									<label class="health-monitor-toggle" style="position: relative; display: inline-block; width: 36px; height: 20px; cursor: pointer;">
										<input type="checkbox" class="health-monitor-forced-run-toggle" value="1" <?php checked( $forced_run_enabled ); ?> style="opacity: 0; width: 0; height: 0;">
										<span class="slider" style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; background-color: <?php echo $forced_run_enabled ? '#00a32a' : '#ccc'; ?>; transition: 0.3s; border-radius: 20px;"></span>
										<span class="slider-round" style="position: absolute; content: ''; height: 16px; width: 16px; left: <?php echo $forced_run_enabled ? '18px' : '2px'; ?>; bottom: 2px; background-color: white; transition: 0.3s; border-radius: 50%;"></span>
									</label>
								</div>
								<p style="margin: 4px 0 0 0; font-size: 11px; color: #50575e;">
									When ON, health monitor forces AS queue to process pending jobs every 5 minutes.
								</p>
							</div>
						</div>
					</div>

					<div class="dash-card dash-card-api">
						<div class="dash-card-header">API Calls</div>
						<div class="dash-card-body">
							<div class="api-total"><?php echo esc_html( $api_stats['total'] ); ?></div>
							<div class="api-breakdown">
								<?php
								$prov_data = [];
								foreach ( $provider_counts as $row ) {
									$p = $row->provider ?: 'unknown';
									if ( ! isset( $prov_data[ $p ] ) ) {
										$prov_data[ $p ] = [ 'success' => 0, 'failed' => 0, 'blocked' => 0 ];
									}
									if ( isset( $prov_data[ $p ][ $row->status ] ) ) {
										$prov_data[ $p ][ $row->status ] += (int) $row->cnt;
									}
								}
								$registered_providers = Config::get_registered_providers();
								foreach ( $prov_data as $prov => $counts ) : 
									$display_name = isset( $registered_providers[ $prov ] ) ? $registered_providers[ $prov ] : ucfirst( $prov );
								?>
								<div class="api-prov">
									<span class="api-prov-name"><?php echo esc_html( $display_name ); ?></span>
									<span class="api-prov-success"><?php echo esc_html( $counts['success'] ); ?> ok</span>
									<span class="api-prov-failed"><?php echo esc_html( $counts['failed'] ); ?> fail</span>
								</div>
								<?php endforeach; ?>
								<?php if ( empty( $prov_data ) ) : ?>
								<div class="api-prov"><span class="api-prov-name">No calls yet</span></div>
								<?php endif; ?>
							</div>
						</div>
					</div>

					<div class="dash-card dash-card-images">
						<div class="dash-card-header">Generated Images</div>
						<div class="dash-card-body">
							<div class="img-count-big"><?php echo esc_html( $ai_collage_images_count ); ?></div>
							<div class="img-today"><?php echo esc_html( $images_today ); ?> today</div>
						</div>
					</div>

					<div class="dash-card dash-card-campaigns">
						<div class="dash-card-header">Campaigns</div>
						<div class="dash-card-body">
							<div class="cmp-count-big"><?php echo esc_html( $active_campaigns ); ?> / <?php echo esc_html( $total_campaigns ); ?></div>
							<div class="cmp-active">active of total</div>
							<div class="cmp-detail"><?php echo esc_html( $pending + $rewriting + $rendering ); ?> jobs in progress</div>
						</div>
					</div>

					<div class="dash-card dash-card-rss">
						<div class="dash-card-header">RSS Feeds</div>
						<div class="dash-card-body">
							<div class="rss-total"><?php echo esc_html( $rss_ingested_total ); ?> ingested</div>
							<div class="rss-feeds">
								<?php
								$active_feeds = 0;
								$feed_cats = [];
								foreach ( $feeds_config as $feed ) {
									if ( ! empty( $feed['active'] ) ) { $active_feeds++; }
									$cat = ! empty( $feed['category'] ) ? $feed['category'] : 'uncategorized';
									if ( ! isset( $feed_cats[ $cat ] ) ) { $feed_cats[ $cat ] = 0; }
									$feed_cats[ $cat ]++;
								}
								?>
								<span><?php echo esc_html( $active_feeds ); ?> active / <?php echo esc_html( count( $feeds_config ) ); ?> configured</span>
								<?php foreach ( $feed_cats as $cat => $cnt ) : ?>
								<div class="rss-cat"><?php echo esc_html( ucfirst( $cat ) ); ?>: <?php echo esc_html( $cnt ); ?></div>
								<?php endforeach; ?>
							</div>
						</div>
					</div>

					<div class="dash-card dash-card-social">
						<div class="dash-card-header">Social Shares</div>
						<div class="dash-card-body">
							<div class="social-status <?php echo $buffer_stats['enabled'] && $buffer_stats['has_token'] ? 'status-on' : 'status-off'; ?>">
								<?php echo $buffer_stats['enabled'] && $buffer_stats['has_token'] ? 'CONNECTED' : 'DISCONNECTED'; ?>
							</div>
							<?php if ( $buffer_stats['enabled'] && $buffer_stats['has_token'] ) : ?>
							<div class="social-stats-row">
								<span>Drafts: <strong><?php echo esc_html( $buffer_stats['draft_count'] ); ?></strong></span>
								<span>Limit: <strong><?php echo esc_html( $buffer_stats['daily_limit'] ); ?>/day</strong></span>
							</div>
							<div class="social-stats-row">
								<span>Retention: <strong><?php echo esc_html( $buffer_stats['draft_retention'] ); ?>d</strong></span>
								<?php if ( ! empty( $buffer_stats['account_count'] ) ) : ?>
								<span>Accounts: <strong><?php echo esc_html( $buffer_stats['account_count'] ); ?></strong></span>
								<?php endif; ?>
							</div>
							<button type="button" class="button button-secondary nm-delete-buffer-drafts" data-nonce="<?php echo esc_attr( wp_create_nonce( 'nm_delete_buffer_drafts' ) ); ?>">
								Delete All Drafts
							</button>
							<?php else : ?>
							<div class="social-disabled-msg">Configure Buffer API settings to enable social sharing.</div>
							<?php endif; ?>
						</div>
					</div>
				</div>

				<div class="ai-collage-meta-info">
					<div class="meta-info-item">
						<span class="dashicons dashicons-trash"></span>
						<span>Logs: <strong><?php echo esc_html( $total_logs ); ?></strong> (<?php echo esc_html( $error_logs ); ?>E / <?php echo esc_html( $warning_logs ); ?>W)</span>
					</div>
					<div class="meta-info-item">
						<span class="dashicons dashicons-clock"></span>
						<span>Retention: <strong><?php echo esc_html( $log_retention > 0 ? $log_retention . 'd' : 'âˆž' ); ?></strong> logs / <strong><?php echo esc_html( $image_retention > 0 ? $image_retention . 'd' : 'âˆž' ); ?></strong> images</span>
					</div>
					<div class="meta-info-item">
						<span class="dashicons dashicons-dashboard"></span>
						<span>T: <strong><?php echo esc_html( number_format( $api_stats['total_input_tokens'] + $api_stats['total_output_tokens'] ) ); ?></strong> | Avg: <strong><?php echo esc_html( $avg_exec > 0 ? round( $avg_exec, 2 ) : '0' ); ?>s</strong></span>
					</div>
					<div class="meta-info-item">
						<span class="dashicons dashicons-format-image"></span>
						<span>Last: <strong><?php echo $last_completed ? esc_html( Config::utc_to_site_display( $last_completed->updated_at ) ) : 'Never'; ?></strong></span>
					</div>
				</div>

			<div class="ai-collage-nav-grid">
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE_SLUG_CAMPAIGNS ) ); ?>" class="nav-grid-card">
						<span class="dashicons dashicons-megaphone"></span>
						<strong>Campaigns</strong>
						<span><?php echo esc_html( $active_campaigns . '/' . $total_campaigns ); ?> active</span>
					</a>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE_SLUG_JOBS ) ); ?>" class="nav-grid-card">
						<span class="dashicons dashicons-admin-page"></span>
						<strong>Jobs</strong>
						<span><?php echo esc_html( $pending + $rewriting + $rendering ); ?> in progress</span>
					</a>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE_SLUG_LOGS ) ); ?>" class="nav-grid-card<?php echo $error_logs > 0 ? ' nav-grid-has-alert' : ''; ?>">
						<span class="dashicons dashicons-list-view"></span>
						<strong>Logs</strong>
						<span><?php echo esc_html( $error_logs ); ?> errors</span>
					</a>
	<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE_SLUG_BRAND ) ); ?>" class="nav-grid-card">
		<span class="dashicons dashicons-palette"></span>
		<strong>Brand Kit</strong>
		<span>Colors &amp; fonts</span>
	</a>
	<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE_SLUG_FEEDS ) ); ?>" class="nav-grid-card">
		<span class="dashicons dashicons-rss"></span>
		<strong>Feeds</strong>
		<span><?php echo esc_html( $rss_ingested_total ); ?> ingested</span>
	</a>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE_SLUG_SOCIAL ) ); ?>" class="nav-grid-card">
						<span class="dashicons dashicons-share"></span>
						<strong>Social</strong>
						<span>Integrations</span>
					</a>
	<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE_SLUG_SETTINGS ) ); ?>" class="nav-grid-card">
	<span class="dashicons dashicons-admin-generic"></span>
	<strong>Settings</strong>
	<span>API &amp; retention</span>
	</a>
	</div>

<?php
global $wpdb;

// Fetch active campaigns for the compact table
$active_campaign_list = array_filter( $campaigns ?? [], function ( $c ) {
	return ! empty( $c['active'] );
});
?>
<div class="dashboard-sections">
	<div class="dashboard-section">
		<div class="section-header">
			<h3>Active Campaigns</h3>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE_SLUG_CAMPAIGNS ) ); ?>" class="button button-secondary button-small">Manage Campaigns</a>
		</div>
		<table class="widefat ai-collage-table">
			<thead><tr><th>Name</th><th>Frequency</th><th>Next Schedule</th><th>Status</th><th>Actions</th></tr></thead>
			<tbody>
			<?php if ( empty( $active_campaign_list ) ) : ?>
				<tr><td colspan="5">No active campaigns.</td></tr>
			<?php else : foreach ( array_slice( $active_campaign_list, 0, 5 ) as $c ) : ?>
				<tr>
					<td><strong><?php echo esc_html( $c['name'] ?? 'Untitled' ); ?></strong></td>
					<td><?php echo esc_html( $c['frequency'] ?? '-' ); ?></td>
					<td><?php
				$lr = (int) ( $c['last_run'] ?? 0 );
				if ( ! $lr && ! empty( $c['id'] ) ) {
					$lr = (int) get_transient( 'ai_collage_campaign_last_run_' . sanitize_key( (string) $c['id'] ) );
				}
				$freq      = $c['frequency'] ?? Config::FREQUENCY_1_HOUR;
				$interval  = Config::get_frequency_interval( $freq );
				$next_run  = $lr ? $lr + $interval : 0;
				$now_utc   = time();
				if ( $next_run > $now_utc ) {
					echo 'in ' . esc_html( human_time_diff( $now_utc, $next_run ) );
				} elseif ( $next_run ) {
					echo '<span style="color:#d4880f;">Overdue</span>';
				} else {
					echo 'Not started';
				}
				?></td>
					<td><span class="ai-collage-status ai-collage-status-<?php echo empty( $c['stopped'] ) ? 'active' : 'paused'; ?>"><?php echo empty( $c['stopped'] ) ? 'Active' : 'Paused'; ?></span></td>
					<td>
						<?php if ( empty( $c['stopped'] ) ) : ?>
							<button type="button" class="button button-small stop-campaign-btn" data-id="<?php echo esc_attr( $c['id'] ); ?>">Pause</button>
						<?php else : ?>
							<button type="button" class="button button-small start-campaign-btn" data-id="<?php echo esc_attr( $c['id'] ); ?>">Resume</button>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; endif; ?>
			</tbody>
		</table>
	</div>

	<div class="dashboard-section">
		<div class="section-header toggle-header" data-target="#recent-jobs-content">
			<h3>Recent Jobs <span class="toggle-icon dashicons dashicons-arrow-down"></span></h3>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE_SLUG_JOBS ) ); ?>" class="button button-secondary button-small">View All Jobs</a>
		</div>
		<div id="recent-jobs-content" class="section-toggleable">
			<table class="widefat ai-collage-table">
			<thead><tr><th>Post</th><th>Status</th><th>Campaign</th><th>Headline</th><th>Created</th></tr></thead>
			<tbody>
			<?php
			$recent = $wpdb->get_var( "SHOW TABLES LIKE '{$this->jobs_table()}'" ) === $this->jobs_table()
				? $wpdb->get_results( "SELECT * FROM `{$this->jobs_table()}` ORDER BY created_at DESC LIMIT 5" )
				: [];
			if ( empty( $recent ) ) : ?>
				<tr><td colspan="5">No jobs yet</td></tr>
			<?php else : foreach ( $recent as $j ) :
				$campaign = get_post_meta( $j->post_id, Config::META_CAMPAIGN_DATA, true );
				$campaign_name  = is_array( $campaign ) && ! empty( $campaign['name'] ) ? $campaign['name'] : '-';
				$campaign_strategy = is_array( $campaign ) && ! empty( $campaign['ai_strategy'] ) ? $campaign['ai_strategy'] : '';
				$strategy_label = '';
				if ( $campaign_strategy ) {
					$strategies = Config::get_strategies();
					$strategy_label = $strategies[ $campaign_strategy ] ?? $campaign_strategy;
				}
			?>
				<tr>
					<td><a href="<?php echo esc_url( get_edit_post_link( $j->post_id ) ); ?>">#<?php echo esc_html( $j->post_id ); ?></a></td>
					<td><span class="ai-collage-status ai-collage-status-<?php echo esc_attr( $j->status ); ?>"><?php echo esc_html( $j->status ); ?></span></td>
					<td><?php echo esc_html( $campaign_name ); ?><?php if ( $strategy_label ) : ?><br><small style="color:#666;"><?php echo esc_html( $strategy_label ); ?></small><?php endif; ?></td>
					<td><?php echo esc_html( $j->ai_headline ?: '-' ); ?></td>
					<td><?php echo esc_html( Config::utc_to_site_display( $j->created_at ) ); ?></td>
				</tr>
			<?php endforeach; endif; ?>
				</tbody>
			</table>
		</div>
	</div>

	<div class="dashboard-section">
		<div class="section-header toggle-header" data-target="#recent-logs-content">
			<h3>Recent Logs <span class="toggle-icon dashicons dashicons-arrow-down"></span></h3>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE_SLUG_LOGS ) ); ?>" class="button button-secondary button-small">View All Logs</a>
		</div>
		<div id="recent-logs-content" class="section-toggleable">
			<table class="widefat ai-collage-table">
				<thead><tr><th>Level</th><th>Action</th><th>Code</th><th>Time</th><th>Date</th></tr></thead>
				<tbody>
				<?php
				$recent_logs = $wpdb->get_var( "SHOW TABLES LIKE '{$this->logs_table()}'" ) === $this->logs_table()
					? $wpdb->get_results( "SELECT * FROM `{$this->logs_table()}` ORDER BY created_at DESC LIMIT 5" )
					: [];
				if ( empty( $recent_logs ) ) : ?>
					<tr><td colspan="5">No logs yet</td></tr>
				<?php else : foreach ( $recent_logs as $l ) : ?>
					<tr>
						<td><span class="ai-collage-log-level ai-collage-log-level-<?php echo esc_attr( $l->log_level ?? 'info' ); ?>"><?php echo esc_html( strtoupper( $l->log_level ?? 'info' ) ); ?></span></td>
						<td><?php echo esc_html( $l->action ); ?></td>
						<td><?php echo esc_html( $l->response_code ); ?></td>
						<td><?php echo esc_html( round( (float) $l->execution_time, 3 ) ); ?>s</td>
						<td><?php echo esc_html( Config::utc_to_site_display( $l->created_at ) ); ?></td>
					</tr>
				<?php endforeach; endif; ?>
				</tbody>
			</table>
		</div>
	</div>
</div>
			</div>
		</div>
		<?php
	}

	// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
	// 2. CAMPAIGNS PAGE
	// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

	public function render_campaigns_page() {
		$campaigns = Config::get_option_array( Config::OPTION_CAMPAIGNS, [] );
		$categories = get_categories( [ 'hide_empty' => false ] );
		?>
		<div class="ai-collage-admin-wrap">
			<div class="ai-collage-header">
				<h1>Campaigns</h1>
				<p class="ai-collage-subtitle">Manage your content sourcing and publishing campaigns</p>
			</div>

			<div class="ai-collage-content">
				<div class="campaign-headers">
					<div>Campaign &amp; Sourcing</div>
					<div>Vertical &amp; Destination</div>
					<div>Schedule &amp; Style</div>
					<div>Status</div>
					<div>Actions</div>
				</div>

<div id="campaigns-list">
	<?php if ( empty( $campaigns ) ) : ?>
	<div class="campaign-empty-state"><p>No campaigns. Click &ldquo;Add New Campaign&rdquo; to create one.</p></div>
	<?php else : foreach ( $campaigns as $campaign ) : ?>
					<div class="campaign-card" data-id="<?php echo esc_attr( $campaign['id'] ); ?>">
						<div class="campaign-grid">
							<div class="grid-col">
								<label>Campaign Name</label>
								<input type="text" name="name" value="<?php echo esc_attr( $campaign['name'] ?? '' ); ?>" class="campaign-name">
								<label>Source Category (Slug)</label>
								<input type="text" name="source_category" value="<?php echo esc_attr( $campaign['source_category'] ?? '' ); ?>" placeholder="e.g. showbiz">
								<label>Tags</label>
								<input type="text" name="tags" value="<?php echo esc_attr( $campaign['tags'] ?? '' ); ?>" placeholder="e.g. fashion, trends">
							</div>
							<div class="grid-col">
								<label>Target Vertical</label>
								<select name="target_vertical">
								<?php foreach ( Config::get_verticals() as $value => $label ) : ?>
									<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $campaign['target_vertical'] ?? '', $value ); ?>><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
								</select>
								<label>Destination Category</label>
								<select name="destination_category">
									<option value="0">-- Select --</option>
								<?php foreach ( $categories as $cat ) : ?>
									<option value="<?php echo esc_attr( $cat->term_id ); ?>" <?php selected( $campaign['destination_category'] ?? 0, $cat->term_id ); ?>><?php echo esc_html( $cat->name ); ?></option>
								<?php endforeach; ?>
								</select>
							</div>
							<div class="grid-col">
								<label>Frequency</label>
								<select name="frequency">
								<?php foreach ( Config::get_frequencies() as $label => $_secs ) : ?>
									<option value="<?php echo esc_attr( $label ); ?>" <?php selected( $campaign['frequency'] ?? '', $label ); ?>><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
								</select>
								<label>Publish Status</label>
								<select name="publish_status">
								<?php foreach ( Config::get_publish_statuses() as $value => $label ) : ?>
									<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $campaign['publish_status'] ?? Config::DEFAULT_PUBLISH_STATUS, $value ); ?>><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
								</select>
								<label>AI Strategy</label>
								<select name="ai_strategy">
								<?php foreach ( Config::get_strategies() as $value => $label ) : ?>
									<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $campaign['ai_strategy'] ?? Config::DEFAULT_STRATEGY, $value ); ?>><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
								</select>
								<label>Output Language</label>
								<select name="output_language">
									<option value="auto" <?php selected( $campaign['output_language'] ?? 'auto', 'auto' ); ?>>Auto — Detect from Source</option>
									<option value="en" <?php selected( $campaign['output_language'] ?? 'auto', 'en' ); ?>>English</option>
									<option value="ur" <?php selected( $campaign['output_language'] ?? 'auto', 'ur' ); ?>>Urdu (اردو)</option>
								</select>
<label>Template</label>
<div class="template-preview-wrapper">
<select name="template" class="template-select-with-preview">
<option value="auto" <?php selected( $campaign['template'] ?? Config::DEFAULT_TEMPLATE, 'auto' ); ?>>Auto — AI Selects Best Template</option>
<?php
// @MODIFIED: Grouped template dropdown with optgroup + language tag
$template_cats = Config::get_template_categories();
$cat_labels = [
'entertainment' => 'Entertainment (EN)',
'tech' => 'Tech (EN)',
'celebrity-urdu' => 'Celebrity Gossip (UR)',
'controversy-urdu' => 'Viral Controversy (UR)',
'film-action' => 'Film Teaser (EN)',
'emotional-urdu' => 'Emotional (UR)',
'breaking-urdu' => 'Breaking (UR)',
'news' => 'News',
'modern' => 'Modern',
'impact' => 'Impact',
];
$all_templates = Config::get_templates();
foreach ( $template_cats as $cat_key => $cat_tpls ) :
$group_label = $cat_labels[ $cat_key ] ?? esc_html( ucfirst( $cat_key ) );
?>
<optgroup label="<?php echo esc_attr( $group_label ); ?>">
<?php foreach ( $cat_tpls as $tpl_key ) :
$tpl_label = $all_templates[ $tpl_key ] ?? $tpl_key;
$lang_tag = strtoupper( Config::get_template_language( $tpl_key ) );
?>
<option value="<?php echo esc_attr( $tpl_key ); ?>" <?php selected( $campaign['template'] ?? Config::DEFAULT_TEMPLATE, $tpl_key ); ?>><?php echo esc_html( $tpl_label ); ?> [<?php echo esc_html( $lang_tag ); ?>]</option>
<?php endforeach; ?>
</optgroup>
<?php endforeach; ?>
</select>
<div class="template-preview-container">
<div class="template-preview-image" style="display: none;">
<img src="" alt="Template Preview" />
</div>
<div class="template-preview-placeholder">Select a template to preview</div>
						</div>
						</div>
						<div class="content-type-section" style="margin-top: 15px; padding-top: 15px; border-top: 1px solid #ddd;">
							<label>Content Type</label>
							<select name="content_type">
								<option value="auto" <?php selected( $campaign['content_type'] ?? 'auto', 'auto' ); ?>>Auto (detect from post)</option>
								<option value="image" <?php selected( $campaign['content_type'] ?? 'auto', 'image' ); ?>>Image Only (force collage)</option>
								<option value="video" <?php selected( $campaign['content_type'] ?? 'auto', 'video' ); ?>>Video Only (force video pipeline)</option>
							</select>
							<p class="description">Select 'Image Only' to prevent video detection for this campaign.</p>
						</div>
						<label>Headline Font</label>
						<select name="headline_font">
						<?php foreach ( Config::get_available_fonts() as $fname => $finfo ) : ?>
						<option value="<?php echo esc_attr( $fname ); ?>" <?php selected( $campaign['headline_font'] ?? '', $fname ); ?>><?php echo esc_html( $finfo['label'] ); ?></option>
						<?php endforeach; ?>
						</select>
						<div class="brand-override-toggle">
						<label><input type="checkbox" name="brand_override_enabled" value="1" <?php checked( ! empty( $campaign['brand_override_enabled'] ) ); ?>> Override Brand Settings</label>
						</div>
						<div class="brand-override-section"<?php echo empty( $campaign['brand_override_enabled'] ) ? ' style="display:none;"' : ''; ?>>
						<label>Primary / Key Term Color</label>
						<input type="color" name="primary_color" value="<?php echo esc_attr( ! empty( $campaign['primary_color'] ) ? $campaign['primary_color'] : Config::DEFAULT_BRAND_PRIMARY_COLOR ); ?>">
						<label>Secondary / Text Color</label>
						<input type="color" name="secondary_color" value="<?php echo esc_attr( ! empty( $campaign['secondary_color'] ) ? $campaign['secondary_color'] : Config::DEFAULT_BRAND_SECONDARY_COLOR ); ?>">
						<label>Accent / Alert Color</label>
						<input type="color" name="accent_color" value="<?php echo esc_attr( ! empty( $campaign['accent_color'] ) ? $campaign['accent_color'] : Config::DEFAULT_BRAND_ACCENT_COLOR ); ?>">
						<label>Emphasis Color (Yellow)</label>
						<input type="color" name="emphasis_color" value="<?php echo esc_attr( ! empty( $campaign['emphasis_color'] ) ? $campaign['emphasis_color'] : Config::DEFAULT_BRAND_EMPHASIS_COLOR ); ?>">
						<label>Key Term Color (Green)</label>
						<input type="color" name="key_term_color" value="<?php echo esc_attr( ! empty( $campaign['key_term_color'] ) ? $campaign['key_term_color'] : Config::DEFAULT_BRAND_KEY_TERM_COLOR ); ?>">
						<label>Breaking/Alert Color (Red)</label>
						<input type="color" name="breaking_color" value="<?php echo esc_attr( ! empty( $campaign['breaking_color'] ) ? $campaign['breaking_color'] : Config::DEFAULT_BRAND_BREAKING_COLOR ); ?>">
						<label>Text Backing Color (Dark)</label>
						<input type="color" name="text_backing_color" value="<?php echo esc_attr( ! empty( $campaign['text_backing_color'] ) ? $campaign['text_backing_color'] : Config::DEFAULT_BRAND_TEXT_BACKING_COLOR ); ?>">
						<label>Logo Position</label>
						<select name="logo_position">
							<option value="top-right" <?php selected( $campaign['logo_position'] ?? Config::DEFAULT_BRAND_LOGO_POSITION, 'top-right' ); ?>>Top Right</option>
							<option value="top-left" <?php selected( $campaign['logo_position'] ?? Config::DEFAULT_BRAND_LOGO_POSITION, 'top-left' ); ?>>Top Left</option>
							<option value="bottom-left" <?php selected( $campaign['logo_position'] ?? Config::DEFAULT_BRAND_LOGO_POSITION, 'bottom-left' ); ?>>Bottom Left</option>
							<option value="bottom-right" <?php selected( $campaign['logo_position'] ?? Config::DEFAULT_BRAND_LOGO_POSITION, 'bottom-right' ); ?>>Bottom Right</option>
						</select>
						<label>Body Font</label>
						<select name="font_body">
						<?php foreach ( Config::get_available_fonts() as $fname => $finfo ) : ?>
						<option value="<?php echo esc_attr( $fname ); ?>" <?php selected( $campaign['font_body'] ?? '', $fname ); ?>><?php echo esc_html( $finfo['label'] ); ?></option>
						<?php endforeach; ?>
						</select>
						</div>

						<div class="image-extraction-section">
						<label><input type="checkbox" name="image_extraction_enabled" value="1" <?php checked( ! empty( $campaign['image_extraction_enabled'] ) ); ?>> Extract &amp; Clean Source Image (remove logo/text overlays)</label>
						<div class="image-extraction-options"<?php echo empty( $campaign['image_extraction_enabled'] ) ? ' style="display:none;"' : ''; ?>>
						<label>Detection Mode</label>
						<select name="detection_mode">
							<option value="hybrid" <?php selected( $campaign['detection_mode'] ?? 'hybrid', 'hybrid' ); ?>>Hybrid (auto-detect, fallback to manual)</option>
							<option value="auto" <?php selected( $campaign['detection_mode'] ?? 'hybrid', 'auto' ); ?>>Auto-detect only</option>
							<option value="manual" <?php selected( $campaign['detection_mode'] ?? 'hybrid', 'manual' ); ?>>Manual zones</option>
						</select>
						<div class="manual-zone-config"<?php echo ( $campaign['detection_mode'] ?? 'hybrid' ) !== 'manual' ? ' style="display:none;"' : ''; ?>>
						<label>Logo Zone (X%, Y%, W%, H%)</label>
						<div class="zone-row">
						<?php
						$lz = $campaign['logo_zone'] ?? Config::DEFAULT_SOCIAL_ZONES['facebook_generic']['logo_zone'];
						?>
						<input type="number" step="0.01" min="0" max="1" name="logo_zone_x" value="<?php echo esc_attr( $lz['x'] ?? 0 ); ?>" placeholder="X" style="width:60px;">
						<input type="number" step="0.01" min="0" max="1" name="logo_zone_y" value="<?php echo esc_attr( $lz['y'] ?? 0 ); ?>" placeholder="Y" style="width:60px;">
						<input type="number" step="0.01" min="0" max="1" name="logo_zone_w" value="<?php echo esc_attr( $lz['w'] ?? 0.08 ); ?>" placeholder="W" style="width:60px;">
						<input type="number" step="0.01" min="0" max="1" name="logo_zone_h" value="<?php echo esc_attr( $lz['h'] ?? 0.05 ); ?>" placeholder="H" style="width:60px;">
						</div>
						<label>Text Zone (X%, Y%, W%, H%)</label>
						<div class="zone-row">
						<?php
						$tz = $campaign['text_zone'] ?? Config::DEFAULT_SOCIAL_ZONES['facebook_generic']['text_zone'];
						?>
						<input type="number" step="0.01" min="0" max="1" name="text_zone_x" value="<?php echo esc_attr( $tz['x'] ?? 0 ); ?>" placeholder="X" style="width:60px;">
						<input type="number" step="0.01" min="0" max="1" name="text_zone_y" value="<?php echo esc_attr( $tz['y'] ?? 0.60 ); ?>" placeholder="Y" style="width:60px;">
						<input type="number" step="0.01" min="0" max="1" name="text_zone_w" value="<?php echo esc_attr( $tz['w'] ?? 1.0 ); ?>" placeholder="W" style="width:60px;">
						<input type="number" step="0.01" min="0" max="1" name="text_zone_h" value="<?php echo esc_attr( $tz['h'] ?? 0.40 ); ?>" placeholder="H" style="width:60px;">
						</div>
						<label>Image Zone (X%, Y%, W%, H%)</label>
						<div class="zone-row">
						<?php
						$iz = $campaign['image_zone'] ?? Config::DEFAULT_SOCIAL_ZONES['facebook_generic']['image_zone'];
						?>
						<input type="number" step="0.01" min="0" max="1" name="image_zone_x" value="<?php echo esc_attr( $iz['x'] ?? 0 ); ?>" placeholder="X" style="width:60px;">
						<input type="number" step="0.01" min="0" max="1" name="image_zone_y" value="<?php echo esc_attr( $iz['y'] ?? 0 ); ?>" placeholder="Y" style="width:60px;">
						<input type="number" step="0.01" min="0" max="1" name="image_zone_w" value="<?php echo esc_attr( $iz['w'] ?? 1.0 ); ?>" placeholder="W" style="width:60px;">
						<input type="number" step="0.01" min="0" max="1" name="image_zone_h" value="<?php echo esc_attr( $iz['h'] ?? 0.60 ); ?>" placeholder="H" style="width:60px;">
						</div>
						</div>
						</div>
						</div>

						<div class="video-zone-section" style="margin-top:12px; padding:10px; border:1px solid #c3c4c7; border-radius:4px; background:#f9f9f9;">
						<label><input type="checkbox" name="video_zone_enabled" value="1" <?php checked( ! empty( $campaign['video_zone_enabled'] ) ); ?>> Configure Video Processing Zones</label>
						<div class="video-zone-options" <?php echo empty( $campaign['video_zone_enabled'] ) ? ' style="display:none;"' : ''; ?>>
						<label>Video Zone Mode</label>
						<select name="video_zone_mode">
							<option value="auto" <?php selected( $campaign['video_zone_mode'] ?? 'auto', 'auto' ); ?>>Auto (AI Detection)</option>
							<option value="manual" <?php selected( $campaign['video_zone_mode'] ?? 'auto', 'manual' ); ?>>Manual Zones</option>
						</select>
						<p class="description">"Auto" detects content area via AI. "Manual" uses your crop settings below.</p>
						<div class="manual-video-zone-config" <?php echo ( $campaign['video_zone_mode'] ?? 'auto' ) !== 'manual' ? ' style="display:none;"' : ''; ?>>
						<label>Video Crop — how much to trim from each side</label>
						<p class="description">Enter the percentage (0.00–1.00) to crop from each side. The inner area is kept.</p>
						<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:flex-end;">
						<?php
							$cz = $campaign['video_content_zone'] ?? [ 'x' => 0.0, 'y' => 0.0, 'w' => 1.0, 'h' => 1.0 ];
							$cz_top = floatval( $cz['y'] ?? 0 );
							$cz_left = floatval( $cz['x'] ?? 0 );
							$cz_w = floatval( $cz['w'] ?? 1.0 );
							$cz_h = floatval( $cz['h'] ?? 1.0 );
							$cz_right = max( 0, 1.0 - $cz_left - $cz_w );
							$cz_bottom = max( 0, 1.0 - $cz_top - $cz_h );
						?>
						<div style="text-align:center;">
							<label style="font-size:11px;font-weight:600;">Top</label>
							<input type="number" step="0.01" min="0" max="0.95" name="video_content_zone_top" value="<?php echo esc_attr( $cz_top ); ?>" class="video-zone-crop-input" style="width:60px;">
							<div style="font-size:10px;color:#666;">e.g. 0.12</div>
						</div>
						<div style="text-align:center;">
							<label style="font-size:11px;font-weight:600;">Right</label>
							<input type="number" step="0.01" min="0" max="0.95" name="video_content_zone_right" value="<?php echo esc_attr( $cz_right ); ?>" class="video-zone-crop-input" style="width:60px;">
							<div style="font-size:10px;color:#666;">e.g. 0.04</div>
						</div>
						<div style="text-align:center;">
							<label style="font-size:11px;font-weight:600;">Bottom</label>
							<input type="number" step="0.01" min="0" max="0.95" name="video_content_zone_bottom" value="<?php echo esc_attr( $cz_bottom ); ?>" class="video-zone-crop-input" style="width:60px;">
							<div style="font-size:10px;color:#666;">e.g. 0.04</div>
						</div>
						<div style="text-align:center;">
							<label style="font-size:11px;font-weight:600;">Left</label>
							<input type="number" step="0.01" min="0" max="0.95" name="video_content_zone_left" value="<?php echo esc_attr( $cz_left ); ?>" class="video-zone-crop-input" style="width:60px;">
							<div style="font-size:10px;color:#666;">e.g. 0.04</div>
						</div>
						</div>
						</div>
						</div>
						</div>

						<label>Platform Size</label>
		<div class="platform-size-row">
		<select name="platform_size">
		<?php foreach ( Config::get_platform_sizes() as $value => $size_info ) : ?>
			<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $campaign['platform_size'] ?? Config::DEFAULT_SIZE, $value ); ?>><?php echo esc_html( $size_info['label'] ); ?></option>
		<?php endforeach; ?>
		</select>
		<div class="aspect-ratio-indicator" title="<?php
			$cur_size = $campaign['platform_size'] ?? Config::DEFAULT_SIZE;
			$cur_dims = Config::get_platform_dimensions( $cur_size );
			echo esc_attr( $cur_dims['width'] . 'Ã—' . $cur_dims['height'] );
		?>"></div>
		</div>
							</div>
	<div class="grid-col status-col">
	<label>Status</label>
	<div class="status-box">
	<span class="dashicons dashicons-clock"></span>
	<span><?php echo ! empty( $campaign['stopped'] ) ? 'Stopped' : 'Managed by Cron'; ?></span>
	</div>
	<label>
	<input type="checkbox" name="active" value="1" <?php checked( $campaign['active'] ?? false, true ); ?>> Active
	</label>
	<?php if ( ! empty( $campaign['stopped'] ) ) : ?>
	<button type="button" class="button button-secondary start-campaign-btn" data-id="<?php echo esc_attr( $campaign['id'] ); ?>">Resume</button>
	<?php else : ?>
	<button type="button" class="button stop-campaign-btn" data-id="<?php echo esc_attr( $campaign['id'] ); ?>">Stop</button>
	<?php endif; ?>
	<input type="hidden" name="stopped" value="<?php echo ! empty( $campaign['stopped'] ) ? '1' : '0'; ?>">
	</div>
							<div class="grid-col actions-col">
								<button type="button" class="button button-primary run-btn" data-id="<?php echo esc_attr( $campaign['id'] ); ?>">Run</button>
								<button type="button" class="button button-link delete-btn" data-id="<?php echo esc_attr( $campaign['id'] ); ?>">Remove</button>
							</div>
						</div>
					</div>
				<?php endforeach; endif; ?>
				</div>

				<div class="dashboard-footer-actions">
					<button type="button" id="add-campaign" class="button button-secondary">+ Add New Campaign</button>
					<button type="button" id="save-campaigns" class="button button-primary">Save All Configurations</button>
				</div>
			</div>
		</div>
		<?php
	}

	// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
	// 3. JOBS PAGE
	// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

	public function render_jobs_page() {
		global $wpdb;
		$jt = $this->jobs_table();

		$jobs_exists = $wpdb->get_var( "SHOW TABLES LIKE '$jt'" ) === $jt;
		if ( ! $jobs_exists ) {
			Migration::ensure_tables();
			$jobs_exists = $wpdb->get_var( "SHOW TABLES LIKE '$jt'" ) === $jt;
		}

		$filter_status = isset( $_GET['job_status'] ) ? sanitize_text_field( $_GET['job_status'] ) : '';
		$current_page = max( 1, (int) ( $_GET['job_page'] ?? 1 ) );
		$per_page = 25;

		$where = '1=1';
		if ( ! empty( $filter_status ) && Config::is_valid_status( $filter_status ) ) {
			$where .= $wpdb->prepare( ' AND status = %s', $filter_status );
		}

		$total_jobs = $jobs_exists ? (int) $wpdb->get_var( "SELECT COUNT(*) FROM `$jt` WHERE $where" ) : 0;
		$total_pages = ceil( $total_jobs / $per_page );
		$offset = ( $current_page - 1 ) * $per_page;

		$jobs = $jobs_exists ? $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `$jt` WHERE $where ORDER BY created_at DESC LIMIT %d OFFSET %d", $per_page, $offset ) ) : [];

		$status_counts = $jobs_exists ? JobManager::get_status_counts() : [];
		?>
		<div class="ai-collage-admin-wrap">
			<div class="ai-collage-header">
				<h1>Jobs</h1>
				<p class="ai-collage-subtitle">View and manage all processing jobs</p>
			</div>

			<div class="ai-collage-content">
				<div class="ai-collage-jobs-stats">
					<?php foreach ( Config::get_all_job_statuses() as $status ) :
						$count = (int) ( $status_counts[ $status ] ?? 0 );
						$url = esc_url( add_query_arg( [ 'page' => self::PAGE_SLUG_JOBS, 'job_status' => $status ], admin_url( 'admin.php' ) ) );
					?>
					<a href="<?php echo $url; ?>" class="job-stat-card job-stat-<?php echo esc_attr( $status ); ?><?php echo $filter_status === $status ? ' job-stat-active' : ''; ?>">
						<span class="job-stat-number"><?php echo esc_html( $count ); ?></span>
						<span class="job-stat-label"><?php echo esc_html( ucfirst( $status ) ); ?></span>
					</a>
					<?php endforeach; ?>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE_SLUG_JOBS ) ); ?>" class="job-stat-card<?php echo empty( $filter_status ) ? ' job-stat-active' : ''; ?>">
						<span class="job-stat-number"><?php echo esc_html( array_sum( $status_counts ) ); ?></span>
						<span class="job-stat-label">All</span>
					</a>
				</div>

				<table class="widefat ai-collage-jobs-table">
					<thead>
						<tr>
							<th>ID</th>
							<th>Post</th>
							<th>Status</th>
							<th>Headline</th>
							<th>Hook</th>
							<th>Created</th>
							<th>Updated</th>
							<th>Actions</th>
						</tr>
					</thead>
					<tbody>
					<?php if ( empty( $jobs ) ) : ?>
						<tr><td colspan="8">No jobs found.</td></tr>
					<?php else : foreach ( $jobs as $j ) : ?>
						<tr>
							<td><?php echo esc_html( $j->id ); ?></td>
							<td><a href="<?php echo esc_url( get_edit_post_link( $j->post_id ) ); ?>"><?php echo esc_html( $j->post_id ); ?></a></td>
							<td><span class="ai-collage-status ai-collage-status-<?php echo esc_attr( $j->status ); ?>"><?php echo esc_html( $j->status ); ?></span></td>
							<td><?php echo esc_html( $j->ai_headline ?: '-' ); ?></td>
							<td><?php echo esc_html( $j->ai_hook ? mb_substr( $j->ai_hook, 0, 50 ) . ( mb_strlen( $j->ai_hook ) > 50 ? 'â€¦' : '' ) : '-' ); ?></td>
							<td><?php echo esc_html( Config::utc_to_site_display( $j->created_at ) ); ?></td>
							<td><?php echo esc_html( Config::utc_to_site_display( $j->updated_at ) ); ?></td>
							<td>
								<?php if ( $j->status === Config::STATUS_FAILED ) : ?>
								<button type="button" class="button button-small ai-collage-retry-job" data-id="<?php echo esc_attr( $j->id ); ?>" data-nonce="<?php echo esc_attr( wp_create_nonce( 'ai_collage_nonce' ) ); ?>">Retry</button>
								<?php endif; ?>
								<button type="button" class="button button-small button-link-delete ai-collage-delete-job" data-id="<?php echo esc_attr( $j->id ); ?>" data-nonce="<?php echo esc_attr( wp_create_nonce( 'ai_collage_nonce' ) ); ?>">Delete</button>
							</td>
						</tr>
					<?php endforeach; endif; ?>
					</tbody>
				</table>

				<?php if ( $total_pages > 1 ) : ?>
				<div class="ai-collage-logs-pagination">
					<?php
					$base_url = admin_url( 'admin.php' );
					$query_args = [ 'page' => self::PAGE_SLUG_JOBS, 'job_status' => $filter_status ];
					if ( $current_page > 1 ) :
						$query_args['job_page'] = $current_page - 1;
					?>
						<a href="<?php echo esc_url( add_query_arg( $query_args, $base_url ) ); ?>" class="button button-secondary">&laquo; Previous</a>
					<?php endif; ?>
					<span class="ai-collage-pagination-info">Page <?php echo esc_html( $current_page ); ?> of <?php echo esc_html( $total_pages ); ?> (<?php echo esc_html( $total_jobs ); ?> jobs)</span>
					<?php if ( $current_page < $total_pages ) :
						$query_args['job_page'] = $current_page + 1;
					?>
						<a href="<?php echo esc_url( add_query_arg( $query_args, $base_url ) ); ?>" class="button button-secondary">Next &raquo;</a>
					<?php endif; ?>
				</div>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
	// 4. LOGS PAGE
	// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

	public function render_logs_page() {
		global $wpdb;
		$lt = $this->logs_table();

		$logs_exists = $wpdb->get_var( "SHOW TABLES LIKE '$lt'" ) === $lt;
		if ( ! $logs_exists ) {
			Migration::ensure_tables();
			$logs_exists = $wpdb->get_var( "SHOW TABLES LIKE '$lt'" ) === $lt;
		}

		$log_retention = (int) get_option( Config::OPTION_LOG_RETENTION_DAYS, Config::DEFAULT_LOG_RETENTION_DAYS );
		$total_logs   = $logs_exists ? (int) $wpdb->get_var( "SELECT COUNT(*) FROM `$lt`" ) : 0;
		$error_count  = $logs_exists ? (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `$lt` WHERE log_level = %s", 'error' ) ) : 0;
		$warning_count = $logs_exists ? (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `$lt` WHERE log_level = %s", 'warning' ) ) : 0;
		$debug_count  = $logs_exists ? (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `$lt` WHERE log_level = %s", 'debug' ) ) : 0;
		$info_count   = $logs_exists ? (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `$lt` WHERE log_level = %s", 'info' ) ) : 0;

		$current_level = isset( $_GET['log_level'] ) ? sanitize_text_field( $_GET['log_level'] ) : '';
		$current_search = isset( $_GET['log_search'] ) ? sanitize_text_field( $_GET['log_search'] ) : '';
		$current_page = max( 1, (int) ( $_GET['log_page'] ?? 1 ) );
		$per_page = 50;

		$where = '1=1';
		if ( ! empty( $current_level ) && Logger::is_valid_level( $current_level ) ) {
			$where .= $wpdb->prepare( ' AND log_level = %s', $current_level );
		}
		if ( ! empty( $current_search ) ) {
			$where .= $wpdb->prepare( ' AND action LIKE %s', '%' . $wpdb->esc_like( $current_search ) . '%' );
		}

	$total_filtered = $logs_exists ? (int) $wpdb->get_var( "SELECT COUNT(*) FROM `$lt` WHERE $where" ) : 0;
	$total_pages = ceil( $total_filtered / $per_page );
	$offset = ( $current_page - 1 ) * $per_page;

	$logs = $logs_exists ? $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `$lt` WHERE $where ORDER BY created_at DESC LIMIT %d OFFSET %d", $per_page, $offset ) ) : [];
		?>
		<div class="ai-collage-admin-wrap">
			<div class="ai-collage-header">
				<h1>Logs</h1>
				<p class="ai-collage-subtitle">View, filter, and download system logs</p>
			</div>

			<div class="ai-collage-content">
				<div class="ai-collage-logs-stats">
					<div class="log-stat-card"><span class="log-stat-number"><?php echo esc_html( $total_logs ); ?></span><span class="log-stat-label">Total</span></div>
					<div class="log-stat-card log-stat-info"><span class="log-stat-number"><?php echo esc_html( $info_count ); ?></span><span class="log-stat-label">Info</span></div>
					<div class="log-stat-card log-stat-debug"><span class="log-stat-number"><?php echo esc_html( $debug_count ); ?></span><span class="log-stat-label">Debug</span></div>
					<div class="log-stat-card log-stat-warning"><span class="log-stat-number"><?php echo esc_html( $warning_count ); ?></span><span class="log-stat-label">Warning</span></div>
					<div class="log-stat-card log-stat-error"><span class="log-stat-number"><?php echo esc_html( $error_count ); ?></span><span class="log-stat-label">Error</span></div>
				</div>

				<div class="ai-collage-logs-toolbar">
					<form method="get" class="ai-collage-logs-filter-form">
						<input type="hidden" name="page" value="<?php echo esc_attr( self::PAGE_SLUG_LOGS ); ?>">
						<div class="logs-filter-group">
							<label for="log_level">Level:</label>
							<select name="log_level" id="log-level-filter">
								<option value="">All Levels</option>
								<?php foreach ( Config::get_log_levels() as $value => $label ) : ?>
								<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $current_level, $value ); ?>><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
							</select>
						</div>
						<div class="logs-filter-group">
							<label for="log_search">Search:</label>
							<input type="text" name="log_search" id="log-search" value="<?php echo esc_attr( $current_search ); ?>" placeholder="Filter by action name...">
						</div>
						<div class="logs-filter-group">
							<button type="submit" class="button button-secondary">Filter</button>
							<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE_SLUG_LOGS ) ); ?>" class="button button-link">Reset</a>
						</div>
					</form>

					<div class="ai-collage-logs-actions">
						<button type="button" id="ai-collage-download-logs" class="button button-secondary" data-nonce="<?php echo esc_attr( wp_create_nonce( 'ai_collage_nonce' ) ); ?>">
							<span class="dashicons dashicons-download"></span> Download CSV
						</button>
						<button type="button" id="ai-collage-clear-logs" class="button button-link-delete" data-nonce="<?php echo esc_attr( wp_create_nonce( 'ai_collage_nonce' ) ); ?>">
							<span class="dashicons dashicons-trash"></span> Clear All
						</button>
					</div>
				</div>

				<?php if ( $log_retention > 0 ) : ?>
				<div class="ai-collage-logs-notice">
					<span class="dashicons dashicons-info"></span>
					Logs older than <strong><?php echo esc_html( $log_retention ); ?> days</strong> are automatically deleted.
				</div>
				<?php endif; ?>

				<table class="widefat ai-collage-logs-table">
					<thead><tr><th>ID</th><th>Level</th><th>Job</th><th>Action</th><th>Code</th><th>Exec Time</th><th>Date</th><th>Details</th></tr></thead>
					<tbody>
					<?php if ( empty( $logs ) ) : ?>
						<tr><td colspan="8">No logs found.</td></tr>
					<?php else : foreach ( $logs as $l ) :
						$payload = maybe_unserialize( $l->request_payload );
						$response = maybe_unserialize( $l->raw_response );
						$has_payload = ! empty( $payload ) && $payload !== '';
						$has_response = ! empty( $response ) && $response !== '';
					?>
						<tr>
							<td><?php echo esc_html( $l->id ); ?></td>
							<td><span class="ai-collage-log-level ai-collage-log-level-<?php echo esc_attr( $l->log_level ?? 'info' ); ?>"><?php echo esc_html( strtoupper( $l->log_level ?? 'info' ) ); ?></span></td>
							<td><?php echo esc_html( $l->job_id ?: '-' ); ?></td>
							<td><?php echo esc_html( $l->action ); ?></td>
							<td><?php echo esc_html( $l->response_code ); ?></td>
							<td><?php echo esc_html( round( (float) $l->execution_time, 3 ) ); ?>s</td>
							<td><?php echo esc_html( Config::utc_to_site_display( $l->created_at ) ); ?></td>
							<td>
								<?php if ( $has_payload || $has_response ) : ?>
								<button type="button" class="button button-small ai-collage-log-detail-toggle" data-id="<?php echo esc_attr( $l->id ); ?>">View</button>
								<?php else : ?>&mdash;<?php endif; ?>
							</td>
						</tr>
						<tr class="ai-collage-log-detail-row" id="log-detail-<?php echo esc_attr( $l->id ); ?>" style="display:none;">
							<td colspan="8">
								<div class="ai-collage-log-detail-content">
									<?php if ( $has_payload ) : ?>
									<div class="log-detail-section">
										<strong>Request Payload:</strong>
										<pre><?php echo esc_html( is_array( $payload ) || is_object( $payload ) ? wp_json_encode( $payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) : (string) $payload ); ?></pre>
									</div>
									<?php endif; ?>
									<?php if ( $has_response ) : ?>
									<div class="log-detail-section">
										<strong>Response:</strong>
										<pre><?php echo esc_html( is_array( $response ) || is_object( $response ) ? wp_json_encode( $response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) : (string) $response ); ?></pre>
									</div>
									<?php endif; ?>
								</div>
							</td>
						</tr>
					<?php endforeach; endif; ?>
					</tbody>
				</table>

				<?php if ( $total_pages > 1 ) : ?>
				<div class="ai-collage-logs-pagination">
					<?php
					$base_url = admin_url( 'admin.php' );
					$query_args = [ 'page' => self::PAGE_SLUG_LOGS, 'log_level' => $current_level, 'log_search' => $current_search ];
					if ( $current_page > 1 ) :
						$query_args['log_page'] = $current_page - 1;
					?>
						<a href="<?php echo esc_url( add_query_arg( $query_args, $base_url ) ); ?>" class="button button-secondary">&laquo; Previous</a>
					<?php endif; ?>
					<span class="ai-collage-pagination-info">Page <?php echo esc_html( $current_page ); ?> of <?php echo esc_html( $total_pages ); ?> (<?php echo esc_html( $total_filtered ); ?> logs)</span>
					<?php if ( $current_page < $total_pages ) :
						$query_args['log_page'] = $current_page + 1;
					?>
						<a href="<?php echo esc_url( add_query_arg( $query_args, $base_url ) ); ?>" class="button button-secondary">Next &raquo;</a>
					<?php endif; ?>
				</div>
				<?php endif; ?>
			</div>
		</div>

		<script>
		jQuery(document).ready(function($){
			$('.ai-collage-log-detail-toggle').on('click', function(){
				var logId = $(this).data('id');
				var $row = $('#log-detail-' + logId);
				$row.toggle();
				$(this).text($row.is(':visible') ? 'Hide' : 'View');
			});
		});
		</script>
		<?php
	}

	// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
	// 5. BRAND PAGE
	// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

	public function render_brand_page() {
	if ( isset( $_POST['save_brand'] ) && check_admin_referer( 'ai_collage_brand_save' ) ) {
		update_option( Config::OPTION_BRAND_NAME, sanitize_text_field( $_POST['brand_name'] ?? '' ) );
		update_option( Config::OPTION_BRAND_URL, esc_url_raw( $_POST['brand_url'] ?? '' ) );
		update_option( Config::OPTION_BRAND_LOGO_ID, (int) ( $_POST['brand_logo_id'] ?? 0 ) );
		update_option( Config::OPTION_BRAND_LOGO_URL, esc_url_raw( $_POST['brand_logo_url'] ?? '' ) );
		update_option( Config::OPTION_BRAND_PRIMARY_COLOR, sanitize_hex_color( $_POST['primary_color'] ?? Config::DEFAULT_BRAND_PRIMARY_COLOR ) );
		update_option( Config::OPTION_BRAND_SECONDARY_COLOR, sanitize_hex_color( $_POST['secondary_color'] ?? Config::DEFAULT_BRAND_SECONDARY_COLOR ) );
		update_option( Config::OPTION_BRAND_ACCENT_COLOR, sanitize_hex_color( $_POST['accent_color'] ?? Config::DEFAULT_BRAND_ACCENT_COLOR ) );
		update_option( Config::OPTION_BRAND_EMPHASIS_COLOR, sanitize_hex_color( $_POST['emphasis_color'] ?? Config::DEFAULT_BRAND_EMPHASIS_COLOR ) );
		update_option( Config::OPTION_BRAND_KEY_TERM_COLOR, sanitize_hex_color( $_POST['key_term_color'] ?? Config::DEFAULT_BRAND_KEY_TERM_COLOR ) );
		update_option( Config::OPTION_BRAND_BREAKING_COLOR, sanitize_hex_color( $_POST['breaking_color'] ?? Config::DEFAULT_BRAND_BREAKING_COLOR ) );
		update_option( Config::OPTION_BRAND_TEXT_BACKING_COLOR, sanitize_hex_color( $_POST['text_backing_color'] ?? Config::DEFAULT_BRAND_TEXT_BACKING_COLOR ) );
		update_option( Config::OPTION_BRAND_LOGO_POSITION, sanitize_text_field( $_POST['logo_position'] ?? Config::DEFAULT_BRAND_LOGO_POSITION ) );
		update_option( Config::OPTION_BRAND_FONT_HEADLINE, sanitize_text_field( $_POST['font_headline'] ?? Config::DEFAULT_BRAND_FONT_HEADLINE ) );
		update_option( Config::OPTION_BRAND_FONT_BODY, sanitize_text_field( $_POST['font_body'] ?? Config::DEFAULT_BRAND_FONT_BODY ) );

		update_option( Config::OPTION_FONT_SIZE_PRESET, sanitize_text_field( $_POST['font_size_preset'] ?? Config::DEFAULT_FONT_SIZE_PRESET ) );
		update_option( Config::OPTION_HEADING_LINE_HEIGHT, sanitize_text_field( $_POST['heading_line_height'] ?? '' ) );
		update_option( Config::OPTION_HEADING_PADDING, sanitize_text_field( $_POST['heading_padding'] ?? '' ) );
		update_option( Config::OPTION_HEADING_BG_COLOR, sanitize_text_field( $_POST['heading_bg_color'] ?? '' ) );
		update_option( Config::OPTION_HEADING_TEXT_COLOR, sanitize_text_field( $_POST['heading_text_color'] ?? '' ) );

		update_option( Config::OPTION_DESC_LINE_HEIGHT, sanitize_text_field( $_POST['desc_line_height'] ?? '' ) );
		update_option( Config::OPTION_DESC_PADDING, sanitize_text_field( $_POST['desc_padding'] ?? '' ) );
		update_option( Config::OPTION_DESC_BG_COLOR, sanitize_text_field( $_POST['desc_bg_color'] ?? '' ) );
		update_option( Config::OPTION_DESC_TEXT_COLOR, sanitize_text_field( $_POST['desc_text_color'] ?? '' ) );

		update_option( Config::OPTION_BRAND_BAR_PADDING, sanitize_text_field( $_POST['brand_bar_padding'] ?? '' ) );
		update_option( Config::OPTION_BRAND_BAR_BG_COLOR, sanitize_text_field( $_POST['brand_bar_bg_color'] ?? '' ) );
		update_option( Config::OPTION_BRAND_BAR_TEXT_COLOR, sanitize_text_field( $_POST['brand_bar_text_color'] ?? '' ) );
		update_option( Config::OPTION_BRAND_BAR_FONT_SIZE, sanitize_text_field( $_POST['brand_bar_font_size'] ?? '' ) );
		update_option( Config::OPTION_BRAND_BAR_LETTER_SPACING, sanitize_text_field( $_POST['brand_bar_letter_spacing'] ?? '' ) );
		update_option( Config::OPTION_BRAND_BAR_ACCENT_LINE, isset( $_POST['brand_bar_accent_line'] ) ? '1' : '0' );

		update_option( Config::OPTION_BRAND_BAR_HEIGHT_PCT, floatval( $_POST['brand_bar_height_pct'] ?? 10.0 ) );
		update_option( Config::OPTION_BRAND_SEPARATOR_HEIGHT_PCT, floatval( $_POST['brand_separator_height_pct'] ?? 4.0 ) );
		update_option( Config::OPTION_HEADING_HEIGHT_PROPORTION, floatval( $_POST['heading_height_proportion'] ?? 10.0 ) );
		update_option( Config::OPTION_VIDEO_HEADING_FONT_SIZE, sanitize_text_field( $_POST['video_heading_font_size'] ?? Config::DEFAULT_VIDEO_HEADING_FONT_SIZE ) );
		update_option( Config::OPTION_VIDEO_HEADING_HEIGHT_PROPORTION, floatval( $_POST['video_heading_height_proportion'] ?? Config::DEFAULT_VIDEO_HEADING_HEIGHT_PROPORTION ) );
		update_option( Config::OPTION_VIDEO_HEADING_PADDING, sanitize_text_field( $_POST['video_heading_padding'] ?? Config::DEFAULT_VIDEO_HEADING_PADDING ) );
		update_option( Config::OPTION_DESC_HEIGHT_PROPORTION, floatval( $_POST['desc_height_proportion'] ?? 21.0 ) );
		$image_height_override_val = sanitize_text_field( $_POST['image_height_override'] ?? '' );
		update_option( Config::OPTION_IMAGE_HEIGHT_OVERRIDE, $image_height_override_val !== '' ? floatval( $image_height_override_val ) : '' );
		update_option( Config::OPTION_ENABLE_DESCRIPTION, isset( $_POST['enable_description'] ) ? '1' : '0' );

		update_option( Config::OPTION_LOGO_MAX_HEIGHT_BOTTOM, sanitize_text_field( $_POST['logo_max_height_bottom'] ?? '' ) );
		update_option( Config::OPTION_LOGO_MAX_WIDTH_BOTTOM, sanitize_text_field( $_POST['logo_max_width_bottom'] ?? '' ) );
		update_option( Config::OPTION_LOGO_MAX_HEIGHT_TOP, sanitize_text_field( $_POST['logo_max_height_top'] ?? '' ) );
		update_option( Config::OPTION_LOGO_MAX_WIDTH_TOP, sanitize_text_field( $_POST['logo_max_width_top'] ?? '' ) );

		$brand_notice = '<div class="notice notice-success"><p>Brand settings saved.</p></div>';
	}
	$brand = Config::get_brand_settings();
	$fonts = Config::get_available_fonts();
	?>
<div class="ai-collage-admin-wrap">
	<div class="ai-collage-header">
		<h1>Brand Kit</h1>
		<p class="ai-collage-subtitle">Configure brand identity, colors, and logo positioning</p>
	</div>
	<?php if ( ! empty( $brand_notice ) ) : ?>
	<div class="ai-collage-admin-notice"><?php echo $brand_notice; ?></div>
	<?php endif; ?>

	<div class="ai-collage-content">
				<form method="post">
					<?php wp_nonce_field( 'ai_collage_brand_save' ); ?>
					<h3>Brand Identity</h3>
					<table class="form-table">
						<tr><th>Brand URL</th><td><input type="url" name="brand_url" value="<?php echo esc_attr( $brand['brand_url'] ); ?>" class="regular-text" placeholder="<?php echo esc_attr( home_url() ); ?>"></td></tr>
<tr><th>Key Term Color (Primary)</th><td><input type="color" name="primary_color" value="<?php echo esc_attr( $brand['primary_color'] ); ?>"> <code><?php echo esc_html( $brand['primary_color'] ); ?></code></td></tr> <!-- @MODIFIED: Renamed from "Primary Color" to match DS semantics -->
<tr><th>General Text Color</th><td><input type="color" name="secondary_color" value="<?php echo esc_attr( $brand['secondary_color'] ); ?>"> <code><?php echo esc_html( $brand['secondary_color'] ); ?></code></td></tr> <!-- @MODIFIED: Renamed from "Secondary Color" to match DS semantics -->
<tr><th>Accent / Alert Color</th><td><input type="color" name="accent_color" value="<?php echo esc_attr( $brand['accent_color'] ); ?>"> <code><?php echo esc_html( $brand['accent_color'] ); ?></code></td></tr> <!-- @MODIFIED: Renamed from "Accent Color" to match DS semantics -->
<tr><th>Emphasis Color (Yellow)</th><td><input type="color" name="emphasis_color" value="<?php echo esc_attr( $brand['emphasis_color'] ); ?>"> <code><?php echo esc_html( $brand['emphasis_color'] ); ?></code></td></tr> <!-- @MODIFIED: Added emphasis color picker -->
<tr><th>Key Term Color (Green)</th><td><input type="color" name="key_term_color" value="<?php echo esc_attr( $brand['key_term_color'] ); ?>"> <code><?php echo esc_html( $brand['key_term_color'] ); ?></code></td></tr> <!-- @MODIFIED: Added key term color picker -->
<tr><th>Breaking/Alert Color (Red)</th><td><input type="color" name="breaking_color" value="<?php echo esc_attr( $brand['breaking_color'] ); ?>"> <code><?php echo esc_html( $brand['breaking_color'] ); ?></code></td></tr> <!-- @MODIFIED: Added breaking/alert color picker -->
<tr><th>Text Backing Color (Dark)</th><td><input type="color" name="text_backing_color" value="<?php echo esc_attr( $brand['text_backing_color'] ); ?>"> <code><?php echo esc_html( $brand['text_backing_color'] ); ?></code></td></tr> <!-- @MODIFIED: Added text backing color picker -->
		<tr> <!-- @MODIFIED: Added Logo Position dropdown -->
		<th>Logo Position</th>
		<td>
			<select name="logo_position">
				<option value="top-right" <?php selected( $brand['logo_position'], 'top-right' ); ?>>Top Right</option>
				<option value="top-left" <?php selected( $brand['logo_position'], 'top-left' ); ?>>Top Left</option>
				<option value="bottom-left" <?php selected( $brand['logo_position'], 'bottom-left' ); ?>>Bottom Left</option>
				<option value="bottom-right" <?php selected( $brand['logo_position'], 'bottom-right' ); ?>>Bottom Right</option>
			</select>
		</td>
		</tr>
		<tr>
							<th>Headline Font</th>
							<td><select name="font_headline"><?php foreach ( $fonts as $fname => $finfo ) : ?><option value="<?php echo esc_attr( $fname ); ?>" <?php selected( $brand['font_headline'], $fname ); ?>><?php echo esc_html( $finfo['label'] ); ?></option><?php endforeach; ?></select></td>
						</tr>
						<tr>
							<th>Body Font</th>
							<td><select name="font_body"><?php foreach ( $fonts as $fname => $finfo ) : ?><option value="<?php echo esc_attr( $fname ); ?>" <?php selected( $brand['font_body'], $fname ); ?>><?php echo esc_html( $finfo['label'] ); ?></option><?php endforeach; ?></select></td>
						</tr>
					</table>

					<h3>Card Layout</h3>
					<p class="description">Control the vertical balance between the image, text area, and brand bar. The layout is:</p>
					<div style="background:#f0f0f0;border:1px solid #ccc;border-radius:4px;padding:12px 16px;margin:8px 0 16px;font-size:12px;line-height:1.8;font-family:monospace;">
						<div style="background:#87ceeb;border:1px solid #5f9ea0;border-radius:3px;padding:4px 8px;text-align:center;">Image â€” <strong>Image Height %</strong></div>
						<div style="background:#333;color:#fff;border:1px solid #222;border-radius:3px;padding:4px 8px;margin-top:4px;text-align:center;">Text Area â€” fills remaining space<br>(heading + optional description)</div>
						<div style="background:#666;color:#fff;border:1px solid #444;border-radius:3px;padding:4px 8px;margin-top:4px;text-align:center;">Brand Bar â€” <strong>Brand Bar Height %</strong></div>
					</div>
					<table class="form-table">
						<tr>
							<th>Image Height %</th>
							<td>
								<input type="number" step="0.5" min="30" max="75" name="image_height_override" value="<?php echo esc_attr( $brand['image_height_override'] ); ?>" class="small-text"> %
								<p class="description">How much of the canvas the image occupies. Leave empty to auto-detect from source image aspect ratio. Recommended: <code>50â€“65</code>%.</p>
							</td>
						</tr>
						<tr>
							<th>Brand Bar Height %</th>
							<td>
								<input type="number" step="0.5" min="2" max="15" name="brand_bar_height_pct" value="<?php echo esc_attr( $brand['brand_bar_height_pct'] ); ?>" class="small-text"> %
								<p class="description">Height of the bottom brand bar. Default is <code>10</code>%.</p>
							</td>
						</tr>
						<tr>
							<th>Show Description</th>
							<td>
								<label>
									<input type="checkbox" name="enable_description" value="1" <?php checked( $brand['enable_description'], '1' ); ?>>
									Show description text below the headline.
								</label>
								<p class="description">When enabled, a description block appears below the headline. When disabled, the headline uses the full text area.</p>
							</td>
						</tr>
					</table>

					<h3>Logo Size Options</h3>
					<p class="description">Select the size of your logo for different positions on the collage. This handles responsiveness automatically.</p>
					<table class="form-table">
						<tr>
							<th>Bottom Bar Logo Size</th>
							<td>
								<select name="logo_max_height_bottom">
									<option value="clamp(12px,1.5cqh,18px)" <?php selected( $brand['logo_max_height_bottom'], 'clamp(12px,1.5cqh,18px)' ); ?>>Small</option>
									<option value="clamp(18px,2.5cqh,26px)" <?php selected( $brand['logo_max_height_bottom'], 'clamp(18px,2.5cqh,26px)' ); ?>>Medium (Default)</option>
									<option value="clamp(24px,3.5cqh,36px)" <?php selected( $brand['logo_max_height_bottom'], 'clamp(24px,3.5cqh,36px)' ); ?>>Large</option>
									<option value="clamp(32px,4.5cqh,48px)" <?php selected( $brand['logo_max_height_bottom'], 'clamp(32px,4.5cqh,48px)' ); ?>>Extra Large</option>
									<option value="<?php echo esc_attr( $brand['logo_max_height_bottom'] ); ?>" <?php if ( ! in_array( $brand['logo_max_height_bottom'], ['clamp(12px,1.5cqh,18px)','clamp(18px,2.5cqh,26px)','clamp(24px,3.5cqh,36px)','clamp(32px,4.5cqh,48px)'], true ) ) echo 'selected'; ?> style="display:none;">Custom</option>
								</select>
								<input type="hidden" name="logo_max_width_bottom" value="clamp(100px,25cqw,300px)">
							</td>
						</tr>
						<tr>
							<th>Top Corner Logo Size</th>
							<td>
								<select name="logo_max_height_top">
									<option value="clamp(16px,2cqh,24px)" <?php selected( $brand['logo_max_height_top'], 'clamp(16px,2cqh,24px)' ); ?>>Small</option>
									<option value="clamp(24px,3cqh,34px)" <?php selected( $brand['logo_max_height_top'], 'clamp(24px,3cqh,34px)' ); ?>>Medium (Default)</option>
									<option value="clamp(32px,4cqh,48px)" <?php selected( $brand['logo_max_height_top'], 'clamp(32px,4cqh,48px)' ); ?>>Large</option>
									<option value="clamp(48px,6cqh,72px)" <?php selected( $brand['logo_max_height_top'], 'clamp(48px,6cqh,72px)' ); ?>>Extra Large</option>
									<option value="<?php echo esc_attr( $brand['logo_max_height_top'] ); ?>" <?php if ( ! in_array( $brand['logo_max_height_top'], ['clamp(16px,2cqh,24px)','clamp(24px,3cqh,34px)','clamp(32px,4cqh,48px)','clamp(48px,6cqh,72px)'], true ) ) echo 'selected'; ?> style="display:none;">Custom</option>
								</select>
								<input type="hidden" name="logo_max_width_top" value="clamp(100px,25cqw,300px)">
							</td>
						</tr>
					</table>

				<h3>Typography Size Preset</h3>
				<p class="description">Choose a base size for heading and description text. The plugin auto-adapts for each article's length â€” this preset just shifts the scale.</p>
				<table class="form-table">
					<tr>
						<th>Text Size</th>
						<td>
							<select name="font_size_preset">
<?php foreach ( Config::SIZE_PRESETS as $preset_key => $preset_def ) : ?>
<option value="<?php echo esc_attr( $preset_key ); ?>" <?php selected( $brand['font_size_preset'] ?? 'auto', $preset_key === '' ? 'auto' : $preset_key ); ?>>
<?php echo esc_html( $preset_def['label'] ); ?>
</option>
<?php endforeach; ?>
</select>
							<p class="description">Current: <code><?php
								$current_preset = $brand['font_size_preset'] ?? '';
								$current_def = Config::SIZE_PRESETS[ $current_preset ] ?? Config::SIZE_PRESETS[''];
								echo esc_html( $current_def['label'] );
							?></code>. Urdu headlines benefit from "Large" or "Extra Large".</p>
						</td>
					</tr>
				</table>

				<h3>Advanced: Override Individual Properties</h3>
				<p class="description">For fine-tuning. Most sites only need the preset above.</p>

				<h4>Heading Styling</h4>
				<table class="form-table">
					<tr>
						<th>Line Height Override</th>
						<td>
<?php
$val = $brand['heading_line_height'];
$presets = ['', '1.1', '1.4', '1.6'];
$is_custom = ! in_array( $val, $presets, true );
?>
							<select onchange="var customInput = this.nextElementSibling; if(this.value !== 'custom') { customInput.value = this.value; customInput.style.display = 'none'; } else { customInput.style.display = 'inline-block'; customInput.value = ''; customInput.focus(); }">
								<option value="" <?php selected( $val, '' ); ?>>Default</option>
								<option value="1.1" <?php selected( $val, '1.1' ); ?>>Tight (1.1)</option>
								<option value="1.4" <?php selected( $val, '1.4' ); ?>>Normal (1.4)</option>
								<option value="1.6" <?php selected( $val, '1.6' ); ?>>Relaxed (1.6)</option>
								<option value="custom" <?php selected( $is_custom, true ); ?>>Custom...</option>
							</select>
							<input type="text" name="heading_line_height" value="<?php echo esc_attr( $val ); ?>" class="regular-text" style="width:100px; <?php echo $is_custom ? 'display:inline-block;' : 'display:none;'; ?>" placeholder="e.g. 1.2">
						</td>
					</tr>
					<tr>
						<th>Heading Padding</th>
						<td>
<?php
$val = $brand['heading_padding'];
$presets = ['', '0', '0 10px', '0 20px', '0 30px'];
$is_custom = ! in_array( $val, $presets, true );
?>
							<select onchange="var customInput = this.nextElementSibling; if(this.value !== 'custom') { customInput.value = this.value; customInput.style.display = 'none'; } else { customInput.style.display = 'inline-block'; customInput.value = ''; customInput.focus(); }">
								<option value="" <?php selected( $val, '' ); ?>>Default</option>
								<option value="0" <?php selected( $val, '0' ); ?>>None</option>
								<option value="0 10px" <?php selected( $val, '0 10px' ); ?>>Compact (0 10px)</option>
								<option value="0 20px" <?php selected( $val, '0 20px' ); ?>>Standard (0 20px)</option>
								<option value="0 30px" <?php selected( $val, '0 30px' ); ?>>Generous (0 30px)</option>
								<option value="custom" <?php selected( $is_custom, true ); ?>>Custom...</option>
							</select>
							<input type="text" name="heading_padding" value="<?php echo esc_attr( $val ); ?>" class="regular-text" style="width:120px; <?php echo $is_custom ? 'display:inline-block;' : 'display:none;'; ?>" placeholder="e.g. 0 20px">
						</td>
					</tr>
					<tr>
						<th>Background Color</th>
						<td>
<?php
$val = $brand['heading_bg_color'];
$presets = ['', 'transparent', 'rgba(0,0,0,0.6)', 'rgba(255,255,255,0.6)', '#000000', '#ffffff'];
$is_custom = ! in_array( $val, $presets, true );
?>
							<select onchange="var customInput = this.nextElementSibling; if(this.value !== 'custom') { customInput.value = this.value; customInput.style.display = 'none'; } else { customInput.style.display = 'inline-block'; customInput.value = ''; customInput.focus(); }">
								<option value="" <?php selected( $val, '' ); ?>>Default</option>
								<option value="transparent" <?php selected( $val, 'transparent' ); ?>>Transparent</option>
								<option value="rgba(0,0,0,0.6)" <?php selected( $val, 'rgba(0,0,0,0.6)' ); ?>>Semi-Transparent Dark</option>
								<option value="rgba(255,255,255,0.6)" <?php selected( $val, 'rgba(255,255,255,0.6)' ); ?>>Semi-Transparent Light</option>
								<option value="#000000" <?php selected( $val, '#000000' ); ?>>Solid Black</option>
								<option value="#ffffff" <?php selected( $val, '#ffffff' ); ?>>Solid White</option>
								<option value="custom" <?php selected( $is_custom, true ); ?>>Custom...</option>
							</select>
							<input type="text" name="heading_bg_color" value="<?php echo esc_attr( $val ); ?>" class="regular-text" style="width:140px; <?php echo $is_custom ? 'display:inline-block;' : 'display:none;'; ?>" placeholder="e.g. rgba(0,0,0,0.8)">
						</td>
					</tr>
					<tr>
						<th>Text Color</th>
						<td>
							<input type="color" name="heading_text_color" value="<?php echo esc_attr( $brand['heading_text_color'] ?: '#ffffff' ); ?>">
							<span class="description">Leave black/white or set a custom color.</span>
						</td>
					</tr>
				</table>

				<h4>Video Reel Heading (independent of collage)</h4>
				<p class="description">These controls apply ONLY to generated video reels. Image collage headings are unaffected by them. Leave empty = auto-adapt.</p>
				<table class="form-table">
					<tr>
						<th>Font Size</th>
						<td>
							<input type="number" min="20" max="400" name="video_heading_font_size" value="<?php echo esc_attr( $brand['video_heading_font_size'] ); ?>" class="small-text"> px
							<p class="description">Fixed heading font size for video reels only (at 1080 canvas width, auto-scaled for other sizes). Urdu Nastaliq reads well at <code>110&ndash;140</code>. Empty = auto-adaptive.</p>
						</td>
					</tr>
					<tr>
						<th>Space %</th>
						<td>
							<input type="number" step="0.5" min="5" max="60" name="video_heading_height_proportion" value="<?php echo esc_attr( $brand['video_heading_height_proportion'] ); ?>" class="small-text"> %
							<p class="description">Baseline space allocated to the video heading. On letterboxed (landscape/square) videos the heading may grow above this into the black bars, up to the canvas top minus padding.</p>
						</td>
					</tr>
					<tr>
						<th>Padding</th>
						<td>
							<input type="text" name="video_heading_padding" value="<?php echo esc_attr( $brand['video_heading_padding'] ); ?>" class="regular-text" style="width:220px;" placeholder="e.g. 0 20px">
							<p class="description">CSS shorthand (top right bottom left). Empty = use the shared Heading Padding. Vertical padding also bounds how far the heading may grow into the black bars.</p>
						</td>
					</tr>
				</table>

				<h4>Description Styling</h4>
				<table class="form-table">
					<tr>
						<th>Line Height Override</th>
						<td>
<?php
$val = $brand['desc_line_height'];
$presets = ['', '1.1', '1.4', '1.6'];
$is_custom = ! in_array( $val, $presets, true );
?>
							<select onchange="var customInput = this.nextElementSibling; if(this.value !== 'custom') { customInput.value = this.value; customInput.style.display = 'none'; } else { customInput.style.display = 'inline-block'; customInput.value = ''; customInput.focus(); }">
								<option value="" <?php selected( $val, '' ); ?>>Default</option>
								<option value="1.1" <?php selected( $val, '1.1' ); ?>>Tight (1.1)</option>
								<option value="1.4" <?php selected( $val, '1.4' ); ?>>Normal (1.4)</option>
								<option value="1.6" <?php selected( $val, '1.6' ); ?>>Relaxed (1.6)</option>
								<option value="custom" <?php selected( $is_custom, true ); ?>>Custom...</option>
							</select>
							<input type="text" name="desc_line_height" value="<?php echo esc_attr( $val ); ?>" class="regular-text" style="width:100px; <?php echo $is_custom ? 'display:inline-block;' : 'display:none;'; ?>" placeholder="e.g. 1.4">
						</td>
					</tr>
					<tr>
						<th>Description Padding</th>
						<td>
<?php
$val = $brand['desc_padding'];
$presets = ['', '0', '10px 10px', '10px 20px', '20px 30px'];
$is_custom = ! in_array( $val, $presets, true );
?>
							<select onchange="var customInput = this.nextElementSibling; if(this.value !== 'custom') { customInput.value = this.value; customInput.style.display = 'none'; } else { customInput.style.display = 'inline-block'; customInput.value = ''; customInput.focus(); }">
								<option value="" <?php selected( $val, '' ); ?>>Default</option>
								<option value="0" <?php selected( $val, '0' ); ?>>None</option>
								<option value="10px 10px" <?php selected( $val, '10px 10px' ); ?>>Compact (10px 10px)</option>
								<option value="10px 20px" <?php selected( $val, '10px 20px' ); ?>>Standard (10px 20px)</option>
								<option value="20px 30px" <?php selected( $val, '20px 30px' ); ?>>Generous (20px 30px)</option>
								<option value="custom" <?php selected( $is_custom, true ); ?>>Custom...</option>
							</select>
							<input type="text" name="desc_padding" value="<?php echo esc_attr( $val ); ?>" class="regular-text" style="width:120px; <?php echo $is_custom ? 'display:inline-block;' : 'display:none;'; ?>" placeholder="e.g. 10px 20px">
						</td>
					</tr>
					<tr>
						<th>Background Color</th>
						<td>
<?php
$val = $brand['desc_bg_color'];
$presets = ['', 'transparent', 'rgba(0,0,0,0.6)', 'rgba(255,255,255,0.6)', '#000000', '#ffffff'];
$is_custom = ! in_array( $val, $presets, true );
?>
							<select onchange="var customInput = this.nextElementSibling; if(this.value !== 'custom') { customInput.value = this.value; customInput.style.display = 'none'; } else { customInput.style.display = 'inline-block'; customInput.value = ''; customInput.focus(); }">
								<option value="" <?php selected( $val, '' ); ?>>Default</option>
								<option value="transparent" <?php selected( $val, 'transparent' ); ?>>Transparent</option>
								<option value="rgba(0,0,0,0.6)" <?php selected( $val, 'rgba(0,0,0,0.6)' ); ?>>Semi-Transparent Dark</option>
								<option value="rgba(255,255,255,0.6)" <?php selected( $val, 'rgba(255,255,255,0.6)' ); ?>>Semi-Transparent Light</option>
								<option value="#000000" <?php selected( $val, '#000000' ); ?>>Solid Black</option>
								<option value="#ffffff" <?php selected( $val, '#ffffff' ); ?>>Solid White</option>
								<option value="custom" <?php selected( $is_custom, true ); ?>>Custom...</option>
							</select>
							<input type="text" name="desc_bg_color" value="<?php echo esc_attr( $val ); ?>" class="regular-text" style="width:140px; <?php echo $is_custom ? 'display:inline-block;' : 'display:none;'; ?>" placeholder="e.g. rgba(0,0,0,0.5)">
						</td>
					</tr>
					<tr>
						<th>Text Color</th>
						<td>
							<input type="color" name="desc_text_color" value="<?php echo esc_attr( $brand['desc_text_color'] ?: '#eeeeee' ); ?>">
							<span class="description">Leave black/white or set a custom color.</span>
						</td>
					</tr>
				</table>

					<h3>Brand Bar Configuration</h3>
					<p class="description">Configure the bottom brand bar that appears on all auto-generated social collages. Includes logo, text, colors, and typography.</p>
					<table class="form-table">
						<tr>
							<th>Brand Text</th>
							<td>
								<input type="text" name="brand_name" value="<?php echo esc_attr( $brand['brand_name'] ); ?>" class="regular-text">
								<p class="description">Text displayed on the brand bar (e.g. site name, tagline, or "TREND STUDIO | FASHION").</p>
							</td>
						</tr>
						<tr>
							<th>Bar Background Color</th>
							<td>
								<input type="color" name="brand_bar_bg_color" value="<?php echo esc_attr( $brand['brand_bar_bg_color'] ?: '#000000' ); ?>">
							</td>
						</tr>
						<tr>
							<th>Bar Padding</th>
							<td>
<?php
$val = $brand['brand_bar_padding'];
$presets = ['', '0 10px', '0 20px', '0 30px'];
$is_custom = ! in_array( $val, $presets, true );
?>
								<select onchange="var customInput = this.nextElementSibling; if(this.value !== 'custom') { customInput.value = this.value; customInput.style.display = 'none'; } else { customInput.style.display = 'inline-block'; customInput.value = ''; customInput.focus(); }">
									<option value="" <?php selected( $val, '' ); ?>>Default</option>
									<option value="0 10px" <?php selected( $val, '0 10px' ); ?>>Compact (0 10px)</option>
									<option value="0 20px" <?php selected( $val, '0 20px' ); ?>>Standard (0 20px)</option>
									<option value="0 30px" <?php selected( $val, '0 30px' ); ?>>Generous (0 30px)</option>
									<option value="custom" <?php selected( $is_custom, true ); ?>>Custom...</option>
								</select>
								<input type="text" name="brand_bar_padding" value="<?php echo esc_attr( $val ); ?>" class="regular-text" style="width:120px; <?php echo $is_custom ? 'display:inline-block;' : 'display:none;'; ?>" placeholder="e.g. 0 20px">
							</td>
						</tr>
						<tr>
							<th>Bar Text Color</th>
							<td>
								<input type="color" name="brand_bar_text_color" value="<?php echo esc_attr( $brand['brand_bar_text_color'] ?: '#ffffff' ); ?>">
							</td>
						</tr>
						<tr>
							<th>Brand Logo</th>
							<td>
								<div style="display:flex;flex-direction:column;gap:12px;align-items:flex-start;">
									<div id="brand-logo-preview" style="background:#fff;padding:5px;border:1px solid #ccc;display:flex;align-items:center;justify-content:center;width:60px;height:60px;">
										<?php if ( ! empty( $brand['logo_url'] ) ) : ?>
										<img src="<?php echo esc_url( $brand['logo_url'] ); ?>" style="max-height:50px;max-width:50px;">
										<?php endif; ?>
									</div>
									<div style="display:flex;gap:6px;">
										<input type="hidden" name="brand_logo_id" id="brand-logo-id" value="<?php echo esc_attr( $brand['brand_logo_id'] ); ?>">
										<button type="button" class="button" id="upload-brand-logo">Select from Media Library</button>
										<button type="button" class="button" id="remove-brand-logo" style="<?php echo ( $brand['brand_logo_id'] > 0 || ! empty( $brand['brand_logo_url'] ) ) ? '' : 'display:none;'; ?>">Remove</button>
									</div>
									<div style="display:flex;gap:6px;align-items:center;width:100%;max-width:480px;">
										<label for="brand-logo-url" style="min-width:auto;margin:0 8px 0 0;">or URL:</label>
										<input type="url" name="brand_logo_url" id="brand-logo-url" value="<?php echo esc_attr( $brand['brand_logo_url'] ); ?>" placeholder="https://example.com/logo.png" style="flex:1;min-width:0;">
									</div>
								</div>
								<p class="description">Small logo displayed on the left side of the brand bar. Recommended: transparent PNG, 200x60px or similar. If both a media-library selection and a URL are provided, the URL takes precedence.</p>
							</td>
						</tr>
						<tr>
							<th>Bar Font Size</th>
							<td>
								<input type="number" name="brand_bar_font_size" value="<?php echo esc_attr( intval($brand['brand_bar_font_size']) ?: 24 ); ?>" class="small-text"> px
								<p class="description">Font size for brand bar text (12-48px). Default: 24px</p>
							</td>
						</tr>
						<tr>
							<th>Letter Spacing</th>
							<td>
								<input type="number" name="brand_bar_letter_spacing" value="<?php echo esc_attr( intval($brand['brand_bar_letter_spacing']) ?: 10 ); ?>" class="small-text"> px
								<p class="description">Space between characters in brand bar (0-30px). Default: 10px</p>
							</td>
						</tr>
						<tr>
							<th>Accent Line</th>
							<td>
								<label><input type="checkbox" name="brand_bar_accent_line" value="1" <?php checked( $brand['brand_bar_accent_line'], '1' ); ?>> Show accent line at top of brand bar</label>
							</td>
						</tr>
					</table>

					<p class="submit"><input type="submit" name="save_brand" class="button button-primary" value="Save Brand Settings"></p>
				</form>

				<script>
				jQuery(document).ready(function($){
					var frame;
					function renderPreview(url){
						if(url){
							$('#brand-logo-preview').html('<img src="'+url+'" style="max-height:50px;max-width:50px;">');
							$('#remove-brand-logo').show();
						} else {
							$('#brand-logo-preview').html('');
							$('#remove-brand-logo').hide();
						}
					}
					$('#upload-brand-logo').on('click', function(e){
						e.preventDefault();
						if(!frame){
							frame = wp.media({ title: 'Select Brand Logo', button: { text: 'Use as Logo' }, multiple: false });
							frame.on('select', function(){
								var attachment = frame.state().get('selection').first().toJSON();
								$('#brand-logo-id').val(attachment.id);
								$('#brand-logo-url').val('');
								renderPreview(attachment.url);
							});
						}
						frame.open();
					});
					$('#brand-logo-url').on('input', function(){
						var url = $(this).val().trim();
						if(url){
							$('#brand-logo-id').val(0);
							renderPreview(url);
						} else if($('#brand-logo-id').val() === '0' || $('#brand-logo-id').val() === ''){
							renderPreview('');
						}
					});
					$('#remove-brand-logo').on('click', function(){
						$('#brand-logo-id').val(0);
						$('#brand-logo-url').val('');
						renderPreview('');
					});
				});
				</script>
			</div>
		</div>
		<?php
	}

	// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
	// 6. FEEDS PAGE
	// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

	public function render_feeds_page() {
		$feeds = Config::get_rss_feeds();
		$rss_enabled = (bool) get_option( Config::OPTION_RSS_ENABLED, false );
		$rss_frequency = (int) get_option( Config::OPTION_RSS_FREQUENCY, Config::RSS_DEFAULT_FREQUENCY );
		$rss_max_per_run = (int) get_option( Config::OPTION_RSS_MAX_PER_RUN, Config::RSS_DEFAULT_MAX_PER_RUN );
		$categories = get_categories( [ 'hide_empty' => false ] );
		?>
		<div class="ai-collage-admin-wrap">
			<div class="ai-collage-header">
				<h1>RSS Feeds</h1>
				<p class="ai-collage-subtitle">Configure RSS feed sources for autonomous news ingestion</p>
			</div>

			<div class="ai-collage-content">
				<h3>Feed Settings</h3>
				<form id="rss-settings-form" method="post">
					<table class="form-table">
						<tr>
							<th>Enable RSS Ingestion</th>
							<td><label><input type="checkbox" id="rss-enabled" value="1" <?php checked( $rss_enabled ); ?>> Enable automatic RSS feed polling</label></td>
						</tr>
						<tr>
							<th>Poll Frequency</th>
							<td>
								<select id="rss-frequency">
									<?php foreach ( Config::get_rss_frequencies() as $seconds => $label ) : ?>
									<option value="<?php echo esc_attr( $seconds ); ?>" <?php selected( $rss_frequency, $seconds ); ?>><?php echo esc_html( $label ); ?></option>
									<?php endforeach; ?>
								</select>
							</td>
						</tr>
						<tr>
							<th>Max Items Per Run</th>
							<td>
								<input type="number" id="rss-max-per-run" value="<?php echo esc_attr( $rss_max_per_run ); ?>" class="small-text" min="1" max="50">
								<p class="description">Maximum items to ingest per feed per poll cycle</p>
							</td>
						</tr>
					</table>
					<button type="button" id="save-rss-settings" class="button button-primary">Save Feed Settings</button>
				</form>

				<h3 style="margin-top:30px;">Feed Sources</h3>
				<div id="feeds-list">
					<?php if ( empty( $feeds ) ) : ?>
					<div class="feed-card"><p>No RSS feeds configured. Click &ldquo;Add New Feed&rdquo; to add one.</p></div>
					<?php else : foreach ( $feeds as $feed ) : ?>
					<div class="campaign-card feed-card" data-id="<?php echo esc_attr( $feed['id'] ?? '' ); ?>">
						<div class="campaign-grid">
							<div class="grid-col">
								<label>Feed Name</label>
								<input type="text" name="feed_name" value="<?php echo esc_attr( $feed['name'] ?? '' ); ?>" class="feed-name" placeholder="e.g. BBC Urdu">
								<label>Feed URL</label>
								<input type="url" name="feed_url" value="<?php echo esc_attr( $feed['url'] ?? '' ); ?>" class="regular-text" placeholder="https://feeds.bbci.co.uk/urdu/rss.xml">
							</div>
							<div class="grid-col">
								<label>Language</label>
								<select name="feed_language">
									<option value="en" <?php selected( $feed['language'] ?? 'en', 'en' ); ?>>English</option>
									<option value="ur" <?php selected( $feed['language'] ?? 'en', 'ur' ); ?>>Urdu</option>
								</select>
								<label>Category</label>
								<select name="feed_category">
									<option value="0">-- None --</option>
									<?php foreach ( $categories as $cat ) : ?>
									<option value="<?php echo esc_attr( $cat->slug ); ?>" <?php selected( $feed['category'] ?? '', $cat->slug ); ?>><?php echo esc_html( $cat->name ); ?></option>
									<?php endforeach; ?>
								</select>
								<label>Campaign</label>
								<select name="feed_campaign_id">
									<option value="">-- None (use defaults) --</option>
									<?php
									$campaigns = Config::get_option_array( Config::OPTION_CAMPAIGNS, [] );
									foreach ( $campaigns as $c ) :
									?>
									<option value="<?php echo esc_attr( $c['id'] ); ?>" <?php selected( $feed['campaign_id'] ?? '', $c['id'] ); ?>><?php echo esc_html( $c['name'] ?? $c['id'] ); ?></option>
									<?php endforeach; ?>
								</select>
							</div>
							<div class="grid-col status-col">
								<label>Active</label>
								<label><input type="checkbox" name="feed_active" value="1" <?php checked( ! empty( $feed['active'] ) ); ?>> Enabled</label>
							<?php
								// Prefer the in-memory value (set when this code path was the writer),
								// fall back to the per-feed option written by CronScheduler::update_feed_last_poll
								// (atomic per-id update, avoids the GET-MODIFY-SAVE race on OPTION_RSS_FEEDS).
								$last_poll_display = (string) ( $feed['last_poll'] ?? '' );
								$last_poll_count_display = (int) ( $feed['last_poll_count'] ?? 0 );
								if ( '' === $last_poll_display && ! empty( $feed['id'] ) ) {
									$last_poll_display      = (string) get_option( 'ai_collage_feed_last_poll_' . sanitize_key( (string) $feed['id'] ), '' );
									$last_poll_count_display = (int) get_option( 'ai_collage_feed_last_poll_count_' . sanitize_key( (string) $feed['id'] ), 0 );
								}
							?>
						<?php if ( '' !== $last_poll_display ) : ?>
						<div style="font-size:12px;color:#666;margin-top:8px;">
							<span>Last poll: <?php echo esc_html( Config::utc_to_site_display( $last_poll_display ) ); ?></span><br>
								<span>Items: <?php echo esc_html( $last_poll_count_display ); ?></span>
							</div>
							<?php endif; ?>
							</div>
							<div class="grid-col actions-col">
								<button type="button" class="button button-secondary test-feed-btn" data-id="<?php echo esc_attr( $feed['id'] ?? '' ); ?>">Test</button>
								<button type="button" class="button button-secondary poll-feed-btn" data-id="<?php echo esc_attr( $feed['id'] ?? '' ); ?>">Poll Now</button>
								<button type="button" class="button button-link-delete remove-feed-btn" data-id="<?php echo esc_attr( $feed['id'] ?? '' ); ?>">Remove</button>
							</div>
						</div>
					</div>
					<?php endforeach; endif; ?>
				</div>

				<div class="dashboard-footer-actions" style="margin-top:20px;">
					<button type="button" id="add-feed" class="button button-secondary">+ Add New Feed</button>
					<button type="button" id="save-feeds" class="button button-primary">Save All Feeds</button>
				</div>
			</div>
		</div>
		<?php
	}

	// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
	// 7. SOCIAL PAGE (was 6)
	// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

	public function render_social_page() {
		?>
		<div class="ai-collage-admin-wrap">
			<div class="ai-collage-header">
				<h1>Social Media Integration</h1>
				<p class="ai-collage-subtitle">Connect third-party social plugins via the AI Social Collage Bridge API</p>
			</div>

			<div class="ai-collage-content">
				<p>When a collage image is generated, the plugin fires WordPress actions that any social plugin can hook into.</p>

				<table class="widefat" style="margin-top:20px;">
					<thead><tr><th>Platform</th><th>Action Hook</th><th>Status</th></tr></thead>
					<tbody>
					<?php foreach ( Config::get_social_platforms() as $key => $label ) : ?>
						<tr>
							<td><?php echo esc_html( $label ); ?></td>
							<td><code><?php echo esc_html( Config::SOCIAL_HOOK_PREFIX . $key ); ?></code></td>
							<td><?php echo has_action( Config::SOCIAL_HOOK_PREFIX . $key ) ? '<span style="color:green;">Connected</span>' : '<span style="color:#999;">Waiting for plugin</span>'; ?></td>
						</tr>
					<?php endforeach; ?>
						<tr>
							<td><strong>All Platforms</strong></td>
							<td><code><?php echo esc_html( Config::SOCIAL_HOOK_ALL ); ?></code></td>
							<td><?php echo has_action( Config::SOCIAL_HOOK_ALL ) ? '<span style="color:green;">Connected</span>' : '<span style="color:#999;">Waiting for plugin</span>'; ?></td>
						</tr>
					</tbody>
				</table>

	<h3 style="margin-top:30px;">Integration Code Examples</h3>

	<h4>FS Poster Integration</h4>
	<pre class="ai-collage-code-block">add_action( 'ai_social_collage_publish_to_facebook', function( $payload ) {
 $fs_data = \AiSocialCollage\Services\SocialBridge::get_fs_poster_format( $payload );
 do_action( 'fs_poster_add_custom_post', $fs_data );
});</pre>

	<h4>Bit Social Integration</h4>
	<pre class="ai-collage-code-block">add_action( 'ai_social_collage_publish_to_instagram', function( $payload ) {
 $bit_data = \AiSocialCollage\Services\SocialBridge::get_bit_social_format( $payload );
 do_action( 'bit_social_schedule_post', $bit_data );
});</pre>

	<h4>Platform-Adaptive Text (any plugin)</h4>
	<pre class="ai-collage-code-block">add_action( 'ai_social_collage_publish_to_twitter', function( $payload ) {
 // Use pre-built platform-specific text:
 $text = $payload['platform_texts']['twitter']; // 280 char limit
 // Or build your own from: $payload['headline'], $payload['detailed_description'], $payload['hashtags']
 your_custom_posting_function( $payload['image_path'], $text );
});</pre>

	<h4>Generic Integration (all platforms)</h4>
	<pre class="ai-collage-code-block">add_action( 'ai_social_collage_publish', function( $payload ) {
 // $payload contains: post_id, image_url, image_path,
 // headline, detailed_description, hashtags, platform_texts,
 // platform_size, metadata
 your_custom_posting_function( $payload );
});</pre>
			</div>
		</div>
		<?php
	}

	// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
	// 8. SETTINGS PAGE (with inner tabs, was 7)
	// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

	public function render_settings_page() {
		$active_tab = isset( $_GET['settings_tab'] ) ? sanitize_text_field( $_GET['settings_tab'] ) : 'api';
		$settings_notice = '';

	if ( isset( $_POST['save_api_settings'] ) && check_admin_referer( 'ai_collage_save_api' ) ) {
		update_option( Config::OPTION_GEMINI_KEY, sanitize_text_field( $_POST['gemini_key'] ?? '' ) );
		update_option( Config::OPTION_GROQ_KEY, sanitize_text_field( $_POST['groq_key'] ?? '' ) );
		update_option( Config::OPTION_SERP_API_KEY, sanitize_text_field( $_POST['serp_api_key'] ?? '' ) );
		update_option( Config::OPTION_CLOUDINARY_CLOUD_NAME, sanitize_text_field( $_POST['cloudinary_cloud_name'] ?? '' ) );
		update_option( Config::OPTION_CLOUDINARY_API_KEY, sanitize_text_field( $_POST['cloudinary_api_key'] ?? '' ) );
		update_option( Config::OPTION_CLOUDINARY_API_SECRET, sanitize_text_field( $_POST['cloudinary_api_secret'] ?? '' ) );
		$gemini_model = sanitize_text_field( $_POST['gemini_model'] ?? '' );
		$groq_model = sanitize_text_field( $_POST['groq_model'] ?? '' );
		update_option( Config::OPTION_GEMINI_MODEL, ! empty( $gemini_model ) ? $gemini_model : Config::DEFAULT_GEMINI_MODEL );
		update_option( Config::OPTION_GROQ_MODEL, ! empty( $groq_model ) ? $groq_model : Config::DEFAULT_GROQ_MODEL );
		if ( isset( $_POST['seo_gen_custom_providers_json'] ) ) {
			$raw = json_decode( wp_unslash( $_POST['seo_gen_custom_providers_json'] ), true );
			if ( is_array( $raw ) ) {
				Config::save_custom_providers( $raw );
			}
		}
		$settings_notice = '<div class="notice notice-success"><p>API settings saved.</p></div>';
	}

		if ( isset( $_POST['save_retention_settings'] ) && check_admin_referer( 'ai_collage_save_retention' ) ) {
			update_option( Config::OPTION_RETENTION_DAYS, (int) ( $_POST['retention_days'] ?? Config::DEFAULT_RETENTION_DAYS ) );
			update_option( Config::OPTION_LOG_RETENTION_DAYS, (int) ( $_POST['log_retention_days'] ?? Config::DEFAULT_LOG_RETENTION_DAYS ) );
			update_option( Config::OPTION_IMAGE_RETENTION_DAYS, (int) ( $_POST['image_retention_days'] ?? Config::DEFAULT_IMAGE_RETENTION_DAYS ) );
			update_option( Config::OPTION_GENERATED_POST_RETENTION_DAYS, (int) ( $_POST['generated_post_retention_days'] ?? Config::DEFAULT_GENERATED_POST_RETENTION_DAYS ) );
			update_option( Config::OPTION_SOURCE_POST_RETENTION_DAYS, (int) ( $_POST['source_post_retention_days'] ?? Config::DEFAULT_SOURCE_POST_RETENTION_DAYS ) );
			
			$gen_cats = isset( $_POST['generated_post_retention_categories'] ) && is_array( $_POST['generated_post_retention_categories'] ) ? array_map( 'intval', $_POST['generated_post_retention_categories'] ) : [];
			update_option( Config::OPTION_GENERATED_POST_RETENTION_CATEGORIES, $gen_cats );
			
			$src_cats = isset( $_POST['source_post_retention_categories'] ) && is_array( $_POST['source_post_retention_categories'] ) ? array_map( 'intval', $_POST['source_post_retention_categories'] ) : [];
			update_option( Config::OPTION_SOURCE_POST_RETENTION_CATEGORIES, $src_cats );

			update_option( Config::OPTION_DELETE_DATA_ON_UNINSTALL, ! empty( $_POST['delete_data_on_uninstall'] ) );

			$settings_notice = '<div class="notice notice-success"><p>Retention settings saved.</p></div>';
		}

	if ( isset( $_POST['save_advanced_settings'] ) && check_admin_referer( 'ai_collage_save_advanced' ) ) {
	update_option( Config::OPTION_SMART_AI_ENABLED, ! empty( $_POST['smart_ai_enabled'] ) );
	update_option( Config::OPTION_AUTO_COLOR_ENABLED, ! empty( $_POST['auto_color_enabled'] ) );
	update_option( Config::OPTION_SMART_CROP_ENABLED, ! empty( $_POST['smart_crop_enabled'] ) );
	update_option( Config::OPTION_SHOW_PLUGIN_CREDIT, ! empty( $_POST['show_plugin_credit'] ) );
	update_option( Config::OPTION_APPEND_TAGS_TO_POST, ! empty( $_POST['append_tags_to_post'] ) );
		$settings_notice = '<div class="notice notice-success"><p>Advanced settings saved.</p></div>';
	}

		if ( isset( $_POST['save_image_extraction_settings'] ) && check_admin_referer( 'ai_collage_save_image_extraction' ) ) {
			update_option( Config::OPTION_IMAGE_EXTRACTION_ENABLED, ! empty( $_POST['image_extraction_enabled'] ) );
			update_option( Config::OPTION_IMAGE_EXTRACTION_DEBUG, ! empty( $_POST['image_extraction_debug'] ) );
			update_option( Config::OPTION_VERIFICATION_ENABLED, ! empty( $_POST['image_verification_enabled'] ) );
			$chain = isset( $_POST['verification_provider_chain'] ) ? (array) json_decode( wp_unslash( $_POST['verification_provider_chain'] ), true ) : [];
			update_option( Config::OPTION_VERIFICATION_PROVIDER_CHAIN, $chain );
			update_option( Config::OPTION_VERIFICATION_CONFIDENCE_THRESHOLD, max( 0, min( 1, (float) ( $_POST['verification_threshold'] ?? 0.7 ) ) ) );
			update_option( Config::OPTION_HF_API_KEY, sanitize_text_field( $_POST['hf_api_key'] ?? '' ) );
			update_option( Config::OPTION_GOOGLE_VISION_KEY, sanitize_text_field( $_POST['google_vision_key'] ?? '' ) );
			$settings_notice = '<div class="notice notice-success"><p>Image extraction and verification settings saved.</p></div>';
		}

		if ( isset( $_POST['save_video_settings'] ) && check_admin_referer( 'ai_collage_save_video' ) ) {
			update_option( Config::OPTION_VIDEO_ENABLED, ! empty( $_POST['video_reel_enabled'] ) );
			update_option( Config::OPTION_VIDEO_MAX_DURATION, max( 10, min( 300, (int) ( $_POST['video_max_duration'] ?? 60 ) ) ) );
			$settings_notice = '<div class="notice notice-success"><p>Video reel settings saved.</p></div>';
		}

		if ( isset( $_POST['save_image_gen_settings'] ) && check_admin_referer( 'ai_collage_save_image_gen' ) ) {
			$provider = sanitize_text_field( $_POST['image_provider'] ?? Config::DEFAULT_IMAGE_PROVIDER );
			update_option( Config::OPTION_IMAGE_PROVIDER, Config::is_valid_image_provider( $provider ) ? $provider : Config::DEFAULT_IMAGE_PROVIDER );
			update_option( Config::OPTION_IMAGE_PROVIDER_KEY, sanitize_text_field( $_POST['image_provider_key'] ?? '' ) );
			update_option( Config::OPTION_IMAGE_PROVIDER_WORKER_URL, esc_url_raw( $_POST['image_worker_url'] ?? '' ) );
			$settings_notice = '<div class="notice notice-success"><p>Image generation settings saved.</p></div>';
		}

		if ( isset( $_POST['save_rss_settings'] ) && check_admin_referer( 'ai_collage_save_rss_settings' ) ) {
			$enabled = ! empty( $_POST['rss_enabled'] );
			update_option( Config::OPTION_RSS_ENABLED, $enabled );
			$rss_freq = (int) ( $_POST['rss_frequency'] ?? Config::RSS_DEFAULT_FREQUENCY );
			update_option( Config::OPTION_RSS_FREQUENCY, Config::is_valid_rss_frequency( $rss_freq ) ? $rss_freq : Config::RSS_DEFAULT_FREQUENCY );
			update_option( Config::OPTION_RSS_MAX_PER_RUN, max( 1, min( 50, (int) ( $_POST['rss_max_per_run'] ?? Config::RSS_DEFAULT_MAX_PER_RUN ) ) ) );
			if ( $enabled && function_exists( 'as_next_scheduled_action' ) && function_exists( 'as_schedule_recurring_action' ) ) {
				if ( ! as_next_scheduled_action( Config::ACTION_POLL_FEEDS, [], Config::AS_GROUP ) ) {
					as_schedule_recurring_action(
						time(),
						$rss_freq,
						Config::ACTION_POLL_FEEDS,
						[],
						Config::AS_GROUP
					);
				}
			}
			if ( ! $enabled && function_exists( 'as_unschedule_action' ) ) {
				as_unschedule_action( Config::ACTION_POLL_FEEDS, [], Config::AS_GROUP );
			}
			$settings_notice = '<div class="notice notice-success"><p>RSS settings saved.</p></div>';
		}

		if ( isset( $_POST['save_content_filter_settings'] ) && check_admin_referer( 'ai_collage_save_content_filter' ) ) {
			update_option( Config::OPTION_VIABILITY_SCORING_ENABLED, ! empty( $_POST['viability_scoring_enabled'] ) );
			update_option( Config::OPTION_VIABILITY_LOG_ONLY_MODE, ! empty( $_POST['viability_log_only_mode'] ) );
			update_option( Config::OPTION_VIABILITY_SCORE_THRESHOLD, max( 1, min( 10, (int) ( $_POST['viability_score_threshold'] ?? 7 ) ) ) );
			update_option( Config::OPTION_RSS_PREFILTER_THRESHOLD, max( 0, min( 100, (int) ( $_POST['rss_prefilter_threshold'] ?? Config::RSS_DEFAULT_PREFILTER_THRESHOLD ) ) ) );
			$block_keywords_raw = isset( $_POST['rss_block_keywords'] ) ? sanitize_textarea_field( wp_unslash( $_POST['rss_block_keywords'] ) ) : '';
			$block_keywords = array_filter( array_map( 'trim', explode( "\n", $block_keywords_raw ) ) );
			update_option( Config::OPTION_RSS_BLOCK_KEYWORDS, $block_keywords );
			update_option( Config::OPTION_RSS_MIN_CONTENT_LENGTH, max( 10, min( 5000, (int) ( $_POST['rss_min_content_length'] ?? Config::RSS_DEFAULT_MIN_CONTENT_LENGTH ) ) ) );
			$settings_notice = '<div class="notice notice-success"><p>Content filter settings saved.</p></div>';
		}

		// Jetpack Social settings save
		if ( isset( $_POST['save_jetpack_settings'] ) && check_admin_referer( 'ai_collage_save_jetpack' ) ) {
			update_option( Config::OPTION_JETPACK_ENABLED, ! empty( $_POST['jetpack_enabled'] ) );
			update_option( Config::OPTION_JETPACK_DISABLE_LINK, ! empty( $_POST['jetpack_disable_link'] ) );
			update_option( Config::OPTION_JETPACK_TEMPLATE, sanitize_textarea_field( wp_unslash( $_POST['jetpack_template'] ?? '' ) ) );

			$jetpack_networks = [];
			foreach ( Config::JETPACK_NETWORKS as $svc ) {
				$jetpack_networks[ $svc ] = ! empty( $_POST['jetpack_networks'][ $svc ] );
			}
			// Migrate old instagram setting to instagram-business for backward compatibility
			if ( ! isset( $jetpack_networks['instagram-business'] ) && ! empty( $_POST['jetpack_networks']['instagram'] ) ) {
				$jetpack_networks['instagram-business'] = true;
			}
			update_option( Config::OPTION_JETPACK_NETWORKS, $jetpack_networks );

			$global_template = sanitize_textarea_field( wp_unslash( $_POST['jetpack_template'] ?? '' ) );
			$network_templates_raw = $_POST['jetpack_network_templates'] ?? [];
			$network_templates = [];
			foreach ( Config::JETPACK_NETWORKS as $svc ) {
				$raw = sanitize_textarea_field( wp_unslash( $network_templates_raw[ $svc ] ?? '' ) );
				$network_templates[ $svc ] = ( ! empty( $raw ) && $raw !== $global_template ) ? $raw : '';
			}
			update_option( Config::OPTION_JETPACK_NETWORK_TEMPLATES, $network_templates );

			$network_hashtags_raw = $_POST['jetpack_network_hashtags'] ?? [];
			$network_hashtags = [];
			foreach ( Config::JETPACK_NETWORKS as $svc ) {
				$raw = sanitize_text_field( wp_unslash( $network_hashtags_raw[ $svc ] ?? '' ) );
				$network_hashtags[ $svc ] = ! empty( $raw ) ? $raw : '';
			}
			update_option( Config::OPTION_JETPACK_NETWORK_HASHTAGS, $network_hashtags );

			$settings_notice = '<div class="notice notice-success"><p>Jetpack Social settings saved.</p></div>';
		}

		// Buffer API settings save
		if ( isset( $_POST['save_buffer_settings'] ) && check_admin_referer( 'ai_collage_save_buffer' ) ) {
			$draft_retention = max( 0, min( 90, (int) ( $_POST['buffer_draft_retention_days'] ?? 2 ) ) );
			update_option( Config::OPTION_BUFFER_DRAFT_RETENTION_DAYS, $draft_retention );

			$accounts_json = wp_unslash( $_POST['buffer_accounts_json'] ?? '[]' );
			$accounts_raw = json_decode( $accounts_json, true );
			if ( is_array( $accounts_raw ) ) {
				Config::save_buffer_accounts( $accounts_raw );
			}

			// R2 Settings
			update_option( Config::OPTION_VIDEO_R2_BUFFER_AUTO, ! empty( $_POST['video_r2_buffer_auto'] ) );
			update_option( Config::OPTION_R2_ENDPOINT, esc_url_raw( $_POST['r2_endpoint'] ?? '' ) );
			update_option( Config::OPTION_R2_ACCESS_KEY, sanitize_text_field( $_POST['r2_access_key'] ?? '' ) );
			update_option( Config::OPTION_R2_SECRET_KEY, sanitize_text_field( $_POST['r2_secret_key'] ?? '' ) );
			update_option( Config::OPTION_R2_BUCKET, sanitize_text_field( $_POST['r2_bucket'] ?? '' ) );
			update_option( Config::OPTION_R2_PUBLIC_DOMAIN, esc_url_raw( $_POST['r2_public_domain'] ?? '' ) );

			// Sync legacy single-account options for backward compat
			$active = Config::get_active_buffer_accounts();
			$first = ! empty( $active ) ? reset( $active ) : null;
			if ( $first ) {
				update_option( Config::OPTION_BUFFER_ENABLED, ! empty( $first['enabled'] ) );
				update_option( Config::OPTION_BUFFER_ACCESS_TOKEN, sanitize_text_field( $first['api_key'] ?? '' ) );
				update_option( Config::OPTION_BUFFER_DAILY_LIMIT, max( 0, min( 50, (int) ( $first['daily_limit'] ?? 5 ) ) ) );
				update_option( Config::OPTION_BUFFER_DISABLE_LINK, ! empty( $first['disable_link'] ) );
				update_option( Config::OPTION_BUFFER_SHARE_MODE, sanitize_text_field( $first['share_mode'] ?? 'draft' ) );
				update_option( Config::OPTION_BUFFER_SHARE_TO_STORY, ! empty( $first['share_to_story'] ) );
				update_option( Config::OPTION_BUFFER_GLOBAL_TEMPLATE, sanitize_textarea_field( wp_unslash( $first['global_template'] ?? '' ) ) );
				update_option( Config::OPTION_BUFFER_CHANNELS, array_values( $first['channel_ids'] ?? [] ) );
				update_option( Config::OPTION_BUFFER_CHANNEL_TYPES, $first['channel_types'] ?? [] );
				update_option( Config::OPTION_BUFFER_CHANNEL_TEMPLATES, $first['channel_templates'] ?? [] );
				update_option( Config::OPTION_BUFFER_LINK_POSTS, $first['link_posts'] ?? [] );
				update_option( Config::OPTION_BUFFER_CHANNEL_HASHTAGS, $first['channel_hashtags'] ?? [] );
				update_option( Config::OPTION_BUFFER_PINTEREST_BOARDS, $first['pinterest_boards'] ?? [] );
				update_option( Config::OPTION_BUFFER_PINTEREST_TITLES, $first['pinterest_titles'] ?? [] );
				update_option( Config::OPTION_BUFFER_CHANNEL_STORY_TOGGLE, $first['channel_story_toggles'] ?? [] );
			} else {
				// Clear legacy options when all accounts removed
				update_option( Config::OPTION_BUFFER_ENABLED, false );
				update_option( Config::OPTION_BUFFER_ACCESS_TOKEN, '' );
				update_option( Config::OPTION_BUFFER_CHANNELS, [] );
			}

			// Clear all caches for all active accounts
			foreach ( $active as $acct_id => $acct ) {
				\AiSocialCollage\Services\BufferIntegration::clear_all_caches( $acct_id );
				\AiSocialCollage\Services\BufferIntegration::get_channels( $acct_id );
			}
			if ( empty( $active ) ) {
				\AiSocialCollage\Services\BufferIntegration::clear_all_caches();
			}
			if ( class_exists( '\AiSocialCollage\Actions\CronScheduler' ) && method_exists( '\AiSocialCollage\Actions\CronScheduler', 'refresh_buffer_stats' ) ) {
				\AiSocialCollage\Actions\CronScheduler::refresh_buffer_stats();
			}
			$settings_notice = '<div class="notice notice-success"><p>Buffer API settings saved.</p></div>';
		}
		?>
<div class="ai-collage-admin-wrap">
	<div class="ai-collage-header">
		<h1>Settings</h1>
		<p class="ai-collage-subtitle">Configure API keys, data retention, and advanced options</p>
	</div>
	<?php if ( ! empty( $settings_notice ) ) : ?>
	<div class="ai-collage-admin-notice"><?php echo $settings_notice; ?></div>
	<?php endif; ?>

	<div class="ai-collage-settings-tabs">
				<?php
		$settings_tabs = [
			'api' => 'API Keys',
			'image-gen' => 'Image Gen',
			'rss' => 'RSS',
			'content-filter' => 'Content Filter',
			'jetpack' => 'Jetpack Social',
			'buffer' => 'Buffer API',
			'retention' => 'Retention',
			'advanced' => 'Advanced',
		];
				foreach ( $settings_tabs as $slug => $label ) :
					$class = 'ai-collage-settings-tab' . ( $active_tab === $slug ? ' active' : '' );
					$url = esc_url( add_query_arg( [ 'page' => self::PAGE_SLUG_SETTINGS, 'settings_tab' => $slug ], admin_url( 'admin.php' ) ) );
					echo '<a href="' . $url . '" class="' . esc_attr( $class ) . '">' . esc_html( $label ) . '</a>';
				endforeach;
				?>
			</div>

			<div class="ai-collage-content">
				<?php if ( $active_tab === 'api' ) : ?>
				<h3>API Keys</h3>
				<form method="post">
					<?php wp_nonce_field( 'ai_collage_save_api' ); ?>
	<table class="form-table">
	<tr>
	<th>Gemini API Key</th>
	<td><input type="password" name="gemini_key" value="<?php echo esc_attr( get_option( Config::OPTION_GEMINI_KEY, '' ) ); ?>" class="regular-text"></td>
	</tr>
	<tr>
	<th>Gemini Model</th>
	<td>
	<input type="text" name="gemini_model" value="<?php echo esc_attr( get_option( Config::OPTION_GEMINI_MODEL, Config::DEFAULT_GEMINI_MODEL ) ); ?>" class="regular-text" placeholder="<?php echo esc_attr( Config::DEFAULT_GEMINI_MODEL ); ?>">
	<p class="description">Model ID used in the API URL (e.g. <code>gemini-2.0-flash</code>, <code>gemini-1.5-pro</code>, <code>gemini-2.5-flash-preview-05-20</code>). Leave default if unsure.</p>
	</td>
	</tr>
	<tr>
	<th>Groq API Key</th>
	<td><input type="password" name="groq_key" value="<?php echo esc_attr( get_option( Config::OPTION_GROQ_KEY, '' ) ); ?>" class="regular-text"></td>
	</tr>
	<tr>
	<th>Groq Model</th>
	<td>
	<input type="text" name="groq_model" value="<?php echo esc_attr( get_option( Config::OPTION_GROQ_MODEL, Config::DEFAULT_GROQ_MODEL ) ); ?>" class="regular-text" placeholder="<?php echo esc_attr( Config::DEFAULT_GROQ_MODEL ); ?>">
	<p class="description">Model ID sent in the chat payload (e.g. <code>llama3-8b-8192</code>, <code>llama-3.3-70b-versatile</code>, <code>mixtral-8x7b-32768</code>). Leave default if unsure.</p>
	</td>
	</tr>
	<tr>
	<th>SerpApi Key (Google Lens)</th>
	<td>
	<input type="password" name="serp_api_key" value="<?php echo esc_attr( get_option( Config::OPTION_SERP_API_KEY, '' ) ); ?>" class="regular-text">
	<p class="description">API key for SerpApi to perform Google Lens reverse image queries. Get a free key at <code>serpapi.com</code>.</p>
	</td>
	</tr>
	<tr>
	<th colspan="2" style="padding-top:20px;">
		<h4 style="margin:0;border-bottom:1px solid #ccc;padding-bottom:5px;">Cloudinary (Auto-Crop / g_auto)</h4>
	</th>
	</tr>
	<tr>
	<th>Cloud Name</th>
	<td><input type="text" name="cloudinary_cloud_name" value="<?php echo esc_attr( get_option( Config::OPTION_CLOUDINARY_CLOUD_NAME, '' ) ); ?>" class="regular-text"></td>
	</tr>
	<tr>
	<th>API Key</th>
	<td><input type="text" name="cloudinary_api_key" value="<?php echo esc_attr( get_option( Config::OPTION_CLOUDINARY_API_KEY, '' ) ); ?>" class="regular-text"></td>
	</tr>
	<tr>
	<th>API Secret</th>
	<td><input type="password" name="cloudinary_api_secret" value="<?php echo esc_attr( get_option( Config::OPTION_CLOUDINARY_API_SECRET, '' ) ); ?>" class="regular-text"></td>
	</tr>
	</table>
	<p class="submit"><input type="submit" name="save_api_settings" class="button button-primary" value="Save API Settings"></p>
	<div style="margin-top:20px;padding-top:20px;border-top:1px solid #c3c4c7;">
		<h3>Custom Providers (OpenAI-Compatible)</h3>
			<p class="description" style="margin-bottom:15px;">Add custom OpenAI Chat Completions-compatible endpoints (vLLM, Ollama, ZhipuAI, MiniMax, etc.). Provider IDs must not collide with builtin slugs.</p>
	<div id="sgd-custom-providers-list">
		<?php
		$custom_providers = Config::get_custom_providers();
		if ( empty( $custom_providers ) ) :
		?>
		<div class="custom-provider-empty" style="padding:15px;background:#f0f0f1;border:1px dashed #c3c4c7;border-radius:4px;margin-bottom:12px;">
			<p style="margin:0;">No custom providers configured. Click &ldquo;+ Add Custom Provider&rdquo; to add one.</p>
		</div>
		<?php else : foreach ( $custom_providers as $cp ) : ?>
		<div class="campaign-card custom-provider-card" data-id="<?php echo esc_attr( $cp['id'] ); ?>">
			<div class="campaign-grid">
				<div class="grid-col">
					<label>Provider Name</label>
					<input type="text" name="cp_name" value="<?php echo esc_attr( $cp['name'] ?? '' ); ?>" class="cp-name regular-text" placeholder="e.g. ZYDI vLLM">
					<label>Provider ID (read-only)</label>
					<input type="text" value="<?php echo esc_attr( $cp['id'] ); ?>" class="regular-text" readonly onclick="this.select();">
					<label>API URL</label>
					<input type="url" name="cp_api_url" value="<?php echo esc_attr( $cp['api_url'] ?? '' ); ?>" class="cp-api-url regular-text" placeholder="https://api.zydit.in/v1">
					<label>API Key</label>
					<input type="password" name="cp_api_key" value="<?php echo esc_attr( $cp['api_key'] ?? '' ); ?>" class="cp-api-key regular-text">
				</div>
				<div class="grid-col">
					<label>Web Search</label>
					<label><input type="checkbox" name="cp_enable_web_search" value="1" class="cp-enable-web-search" <?php checked( ! empty( $cp['enable_web_search'] ) ); ?>> Enable</label>
					<label>Web Search Type</label>
					<select name="cp_web_search_type" class="cp-web-search-type">
						<?php foreach ( Config::get_web_search_types() as $ws_val => $ws_label ) : ?>
						<option value="<?php echo esc_attr( $ws_val ); ?>" <?php selected( $cp['web_search_config']['type'] ?? Config::WEB_SEARCH_NONE, $ws_val ); ?>><?php echo esc_html( $ws_label ); ?></option>
						<?php endforeach; ?>
					</select>
					<label>Model Fallback</label>
					<label><input type="checkbox" name="cp_fallback_enabled" value="1" class="cp-fallback-enabled" <?php checked( ! empty( $cp['fallback_enabled'] ) ); ?>> Enable fallback across models</label>
					<label>Models</label>
					<div class="cp-models-list">
						<?php foreach ( ( $cp['models'] ?? [] ) as $m ) : ?>
						<div class="cp-model-row">
							<input type="text" name="cp_model_display" value="<?php echo esc_attr( $m['display_name'] ?? '' ); ?>" class="cp-model-display regular-text" placeholder="Display name">
							<input type="text" name="cp_model_id" value="<?php echo esc_attr( $m['model_id'] ?? '' ); ?>" class="cp-model-id regular-text" placeholder="Model ID">
							<button type="button" class="button button-small cp-remove-model" title="Remove model">&times;</button>
						</div>
						<?php endforeach; ?>
					</div>
					<button type="button" class="button button-small cp-add-model" style="margin-top:4px;">+ Add Model</button>
				</div>
				<div class="grid-col actions-col" style="justify-content:flex-start;align-items:flex-start;padding-top:24px;">
					<button type="button" class="button button-secondary cp-test-connection" data-id="<?php echo esc_attr( $cp['id'] ); ?>">Test Connection</button>
					<button type="button" class="button button-link-delete cp-remove-provider" data-id="<?php echo esc_attr( $cp['id'] ); ?>" style="margin-top:8px;">Remove Provider</button>
					<?php if ( strpos( $cp['api_url'] ?? '', 'openrouter.ai' ) !== false ) :
						$or_last_sync = OpenRouterModelSync::get_last_sync_time();
						$sync_class = $or_last_sync > 0 ? 'sync-ok' : 'sync-warn';
						$sync_text = $or_last_sync > 0 ? 'Last synced: ' . human_time_diff( $or_last_sync, current_time( 'timestamp' ) ) . ' ago' : 'Never synced';
					?>
					<div class="openrouter-sync-status <?php echo esc_attr( $sync_class ); ?>" style="margin-top:8px;width:100%;">
						<span class="dashicons dashicons-update"></span>
						<span class="openrouter-sync-text"><?php echo esc_html( $sync_text ); ?></span>
					</div>
					<button type="button" class="button button-small openrouter-sync-btn" style="margin-top:4px;width:100%;">Sync Free Models</button>
					<?php endif; ?>
					<?php if ( OpenCodeZenModelSync::is_zen_url( $cp['api_url'] ?? '' ) ) :
						$zen_last_sync = OpenCodeZenModelSync::get_last_sync_time();
						$zen_sync_class = $zen_last_sync > 0 ? 'sync-ok' : 'sync-warn';
						$zen_sync_text = $zen_last_sync > 0 ? 'Last synced: ' . human_time_diff( $zen_last_sync, current_time( 'timestamp' ) ) . ' ago' : 'Never synced';
					?>
					<div class="zen-sync-status <?php echo esc_attr( $zen_sync_class ); ?>" style="margin-top:8px;width:100%;">
						<span class="dashicons dashicons-update"></span>
						<span class="zen-sync-text"><?php echo esc_html( $zen_sync_text ); ?></span>
					</div>
					<button type="button" class="button button-small zen-sync-btn" style="margin-top:4px;width:100%;">Sync Zen Models</button>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php endforeach; endif; ?>
		</div>
		<button type="button" class="button button-secondary" id="sgd-add-custom-provider" style="margin-top:8px;">+ Add Custom Provider</button>
		<input type="hidden" name="seo_gen_custom_providers_json" id="seo_gen_custom_providers_json" value="<?php echo esc_attr( wp_json_encode( $custom_providers ) ); ?>">
	</div>
	<script>
	jQuery(document).on('click', '.openrouter-sync-btn', function(e){
		e.preventDefault();
		e.stopImmediatePropagation();
		var $btn=jQuery(this);
		var $card=$btn.closest('.custom-provider-card');
		var $status=$card.find('.openrouter-sync-status');
		var $text=$status.find('.openrouter-sync-text');
		if(!confirm('Sync free models from OpenRouter? This will add new free models and remove expired ones.')){return;}
		$btn.prop('disabled',true).text('Syncing\u2026');
		$text.text('Syncing models\u2026');
		$status.removeClass('sync-ok sync-warn').addClass('sync-warn');
		jQuery.post(aiCollageData.ajax_url,{action:'ai_collage_sync_openrouter_models',nonce:aiCollageData.nonce},function(r){
			if(r.success){$status.removeClass('sync-warn').addClass('sync-ok');$text.text(r.data.message);alert(r.data.message);location.reload();}
			else{$status.removeClass('sync-ok').addClass('sync-warn');$text.text('Sync failed: '+r.data);alert('Sync failed: '+r.data);}
		}).fail(function(j,t,e){$status.removeClass('sync-ok').addClass('sync-warn');$text.text('AJAX error.');alert('AJAX error: '+t+' - '+e);})
		.always(function(){$btn.prop('disabled',false).text('Sync Free Models');});
	});
	jQuery(document).on('click', '.zen-sync-btn', function(e){
		e.preventDefault();
		e.stopImmediatePropagation();
		var $btn=jQuery(this);
		var $card=$btn.closest('.custom-provider-card');
		var $status=$card.find('.zen-sync-status');
		var $text=$status.find('.zen-sync-text');
		if(!confirm('Sync free models from OpenCode Zen? This will REPLACE the current Zen model list with the latest free models.')){return;}
		$btn.prop('disabled',true).text('Syncing\u2026');
		$text.text('Syncing models\u2026');
		$status.removeClass('sync-ok sync-warn').addClass('sync-warn');
		jQuery.post(aiCollageData.ajax_url,{action:'ai_collage_sync_zen_models',nonce:aiCollageData.nonce},function(r){
			if(r.success){$status.removeClass('sync-warn').addClass('sync-ok');$text.text(r.data.message);alert(r.data.message);location.reload();}
			else{$status.removeClass('sync-ok').addClass('sync-warn');$text.text('Sync failed: '+r.data);alert('Sync failed: '+r.data);}
		}).fail(function(j,t,e){$status.removeClass('sync-ok').addClass('sync-warn');$text.text('AJAX error.');alert('AJAX error: '+t+' - '+e);})
		.always(function(){$btn.prop('disabled',false).text('Sync Zen Models');});
	});
	</script>
	</div>
</form>

<?php elseif ( $active_tab === 'image-gen' ) : ?>
	<h3>AI Image Generation</h3>
	<p class="description" style="margin-bottom:20px;">When a post has no featured image, the plugin will generate one using the selected provider. If the selected provider fails, it falls back to a branded placeholder. Select "None" to skip image generation entirely â€” posts without images will fail with a logged error.</p>
	<form method="post">
	<?php wp_nonce_field( 'ai_collage_save_image_gen' ); ?>
	<table class="form-table">
	<tr>
		<th>Image Provider</th>
		<td>
			<select name="image_provider">
			<?php foreach ( Config::get_image_providers() as $value => $label ) : ?>
				<option value="<?php echo esc_attr( $value ); ?>" <?php selected( get_option( Config::OPTION_IMAGE_PROVIDER, Config::DEFAULT_IMAGE_PROVIDER ), $value ); ?>><?php echo esc_html( $label ); ?></option>
			<?php endforeach; ?>
			</select>
			<p class="description">Select the AI image generation provider. "None" will skip generation and fail posts without images. "Branded Placeholder" always works with no API key.</p>
		</td>
	</tr>
	<tr id="image-provider-key-row">
		<th>API Key</th>
		<td>
			<input type="password" name="image_provider_key" value="<?php echo esc_attr( get_option( Config::OPTION_IMAGE_PROVIDER_KEY, '' ) ); ?>" class="regular-text">
			<p class="description">API key for the selected provider (not needed for Placeholder or None). Pollinations uses a <code>pk_</code> publishable key. Stability uses a personal access token.</p>
		</td>
	</tr>
	<tr id="cloudflare-worker-url-row">
		<th>Worker URL</th>
		<td>
			<input type="url" name="image_worker_url" value="<?php echo esc_attr( get_option( Config::OPTION_IMAGE_PROVIDER_WORKER_URL, '' ) ); ?>" class="regular-text" placeholder="https://your-worker.your-subdomain.workers.dev">
			<p class="description">Only for Cloudflare Worker AI â€” the URL of your deployed Worker endpoint.</p>
		</td>
	</tr>
	</table>
	<p class="submit"><input type="submit" name="save_image_gen_settings" class="button button-primary" value="Save Image Generation Settings"></p>
	</form>

	<script>
	jQuery(document).ready(function($){
		function toggleProviderFields(){
			var val = $('select[name=image_provider]').val();
			if(val === 'cloudflare-worker'){
				$('#cloudflare-worker-url-row').show();
			} else {
				$('#cloudflare-worker-url-row').hide();
			}
			if(val === 'none' || val === 'placeholder'){
				$('#image-provider-key-row').hide();
			} else {
				$('#image-provider-key-row').show();
			}
		}
		toggleProviderFields();
		$('select[name=image_provider]').on('change', toggleProviderFields);
	});
	</script>

	<?php elseif ( $active_tab === 'rss' ) : ?>
		<h3>RSS Ingestion</h3>
		<p class="description" style="margin-bottom:20px;">Enable automatic RSS feed polling to source news content. Configure individual feeds on the <a href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::PAGE_SLUG_FEEDS ) ); ?>">Feeds</a> page.</p>
		<form method="post">
			<?php wp_nonce_field( 'ai_collage_save_rss_settings' ); ?>
			<table class="form-table">
				<tr>
					<th>Enable RSS Polling</th>
					<td><label><input type="checkbox" name="rss_enabled" value="1" <?php checked( (bool) get_option( Config::OPTION_RSS_ENABLED, false ) ); ?>> Enable automatic RSS feed ingestion</label></td>
				</tr>
				<tr>
					<th>Poll Frequency</th>
					<td>
						<select name="rss_frequency">
							<?php foreach ( Config::get_rss_frequencies() as $seconds => $label ) : ?>
							<option value="<?php echo esc_attr( $seconds ); ?>" <?php selected( (int) get_option( Config::OPTION_RSS_FREQUENCY, Config::RSS_DEFAULT_FREQUENCY ), $seconds ); ?>><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</select>
						<p class="description">How often to poll RSS feeds for new content</p>
					</td>
				</tr>
				<tr>
					<th>Max Items Per Run</th>
					<td>
						<input type="number" name="rss_max_per_run" value="<?php echo esc_attr( get_option( Config::OPTION_RSS_MAX_PER_RUN, Config::RSS_DEFAULT_MAX_PER_RUN ) ); ?>" class="small-text" min="1" max="50">
						<p class="description">Maximum items to ingest per feed per poll cycle</p>
					</td>
				</tr>
			</table>
			<p class="submit"><input type="submit" name="save_rss_settings" class="button button-primary" value="Save RSS Settings"></p>
		</form>

	<?php elseif ( $active_tab === 'content-filter' ) : ?>
		<h3>Content Filter &amp; Viability Scoring</h3>
		<p class="description" style="margin-bottom:20px;">Two-layer filtering: deterministic pre-filter (zero API cost) runs before LLM-based viability scoring. Low-quality content is blocked or discarded before consuming quota.</p>
		<form method="post">
			<?php wp_nonce_field( 'ai_collage_save_content_filter' ); ?>
			<table class="form-table">
				<tr>
					<th colspan="2" style="border-bottom:1px solid #c3c4c7;padding-bottom:4px;">
						<strong>Layer 1: Deterministic Pre-Filter</strong>
						<p class="description" style="margin:4px 0 0;">Blocks content before any API calls based on keywords, length, and source reputation.</p>
					</th>
				</tr>
				<tr>
					<th>Pre-Filter Score Threshold</th>
					<td>
						<input type="number" name="rss_prefilter_threshold" value="<?php echo esc_attr( get_option( Config::OPTION_RSS_PREFILTER_THRESHOLD, Config::RSS_DEFAULT_PREFILTER_THRESHOLD ) ); ?>" class="small-text" min="0" max="100">
						<p class="description">Score below which content is blocked immediately. Default: <?php echo esc_html( Config::RSS_DEFAULT_PREFILTER_THRESHOLD ); ?> (0â€“100 scale).</p>
					</td>
				</tr>
				<tr>
					<th>Block Keywords</th>
					<td>
						<textarea name="rss_block_keywords" rows="6" class="large-text" placeholder="One keyword per line"><?php echo esc_textarea( implode( "\n", (array) get_option( Config::OPTION_RSS_BLOCK_KEYWORDS, Config::get_default_block_keywords() ) ) ); ?></textarea>
						<p class="description">One keyword or phrase per line. Case-insensitive matching against title + content.</p>
					</td>
				</tr>
				<tr>
					<th>Minimum Content Length</th>
					<td>
						<input type="number" name="rss_min_content_length" value="<?php echo esc_attr( get_option( Config::OPTION_RSS_MIN_CONTENT_LENGTH, Config::RSS_DEFAULT_MIN_CONTENT_LENGTH ) ); ?>" class="small-text" min="10" max="5000">
						<p class="description">Minimum character count for RSS item content. Default: <?php echo esc_html( Config::RSS_DEFAULT_MIN_CONTENT_LENGTH ); ?>.</p>
					</td>
				</tr>
				<tr>
					<th colspan="2" style="border-bottom:1px solid #c3c4c7;padding-bottom:4px;">
						<strong>Layer 2: LLM Viability Scoring</strong>
						<p class="description" style="margin:4px 0 0;">Uses AI to score content 1â€“10 based on emotional trigger, specificity, timeliness, and human impact.</p>
					</th>
				</tr>
				<tr>
					<th>Enable Viability Scoring</th>
					<td>
						<label><input type="checkbox" name="viability_scoring_enabled" value="1" <?php checked( (bool) get_option( Config::OPTION_VIABILITY_SCORING_ENABLED, false ) ); ?>> Run LLM viability check after pre-filter</label>
						<p class="description">Requires an active AI provider. Adds one extra API call per item.</p>
					</td>
				</tr>
				<tr>
					<th>Log-Only Mode</th>
					<td>
						<label><input type="checkbox" name="viability_log_only_mode" value="1" <?php checked( (bool) get_option( Config::OPTION_VIABILITY_LOG_ONLY_MODE, true ) ); ?>> Score and log only â€” do not discard content</label>
						<p class="description">Recommended for 2-week calibration. Scores are recorded but all content proceeds to rewrite.</p>
					</td>
				</tr>
				<tr>
					<th>Viability Score Threshold</th>
					<td>
						<input type="number" name="viability_score_threshold" value="<?php echo esc_attr( get_option( Config::OPTION_VIABILITY_SCORE_THRESHOLD, 7 ) ); ?>" class="small-text" min="1" max="10">
						<p class="description">Content scoring below this threshold is discarded (when Log-Only Mode is off). Default: 7/10.</p>
					</td>
				</tr>
			</table>
			<p class="submit"><input type="submit" name="save_content_filter_settings" class="button button-primary" value="Save Content Filter Settings"></p>
		</form>

	<?php elseif ( $active_tab === 'jetpack' ) : ?>
		<h3>Jetpack Social Integration</h3>
		<p class="description" style="margin-bottom:20px;">Share posts automatically to connected social accounts via Jetpack Social. Requires the Jetpack plugin or Jetpack Social standalone.</p>
		<form method="post">
			<?php wp_nonce_field( 'ai_collage_save_jetpack' ); ?>
			<table class="form-table">
				<tr>
					<th>Enable Jetpack Social</th>
					<td><label><input type="checkbox" name="jetpack_enabled" value="1" <?php checked( (bool) get_option( Config::OPTION_JETPACK_ENABLED, false ) ); ?>> Enable Jetpack Social auto-sharing</label></td>
				</tr>
				<tr>
					<th>Disable Post Link Sharing</th>
					<td><label><input type="checkbox" name="jetpack_disable_link" value="1" <?php checked( (bool) get_option( Config::OPTION_JETPACK_DISABLE_LINK, false ) ); ?>> Do not share the link of the post (only heading, description, tags, and image)</label></td>
				</tr>
				<tr>
					<th>Global Message Template</th>
					<td>
						<textarea name="jetpack_template" rows="5" class="large-text" placeholder="{headline}&#10;&#10;{description}&#10;&#10;{hashtags}&#10;&#10;{link}"><?php echo esc_textarea( get_option( Config::OPTION_JETPACK_TEMPLATE, "{headline}\n\n{description}\n\n{hashtags}\n\n{link}" ) ); ?></textarea>
						<p class="description">Available placeholders: <code>{headline}</code>, <code>{description}</code>, <code>{hashtags}</code>, <code>{link}</code>. Use <code>{X-CONTENT}</code> in X Custom Template to use formatted short description and tags.</p>
					</td>
				</tr>
				<tr>
					<th>Networks</th>
					<td>
						<?php
						$jetpack_networks = get_option( Config::OPTION_JETPACK_NETWORKS, array_fill_keys( Config::JETPACK_NETWORKS, true ) );
						foreach ( Config::JETPACK_NETWORKS as $svc ) :
							$display_name = $svc;
							if ( $svc === 'instagram-business' ) {
								$display_name = 'Instagram';
							} else {
								$display_name = ucfirst( $svc );
							}
						?>
						<label style="display:inline-block;margin-right:15px;margin-bottom:8px;">
							<input type="checkbox" name="jetpack_networks[<?php echo esc_attr( $svc ); ?>]" value="1" <?php checked( ! empty( $jetpack_networks[ $svc ] ) ); ?>>
							<?php echo esc_html( $display_name ); ?>
						</label>
						<?php endforeach; ?>
						<p class="description">Select which networks to share to.</p>
					</td>
				</tr>
			</table>
			<h3>Per-Network Message Templates</h3>
			<p class="description" style="margin-bottom:15px;">Leave empty to use the global template. Only set if you need a custom message for a specific network.</p>
			<?php
			$network_templates = get_option( Config::OPTION_JETPACK_NETWORK_TEMPLATES, [] );
			foreach ( Config::JETPACK_NETWORKS as $svc ) :
			?>
			<table class="form-table">
				<tr>
					<th><?php echo esc_html( ucfirst( $svc ) ); ?> Template</th>
					<td>
						<textarea name="jetpack_network_templates[<?php echo esc_attr( $svc ); ?>]" rows="3" class="large-text"><?php echo esc_textarea( $network_templates[ $svc ] ?? '' ); ?></textarea>
					</td>
				</tr>
			</table>
			<?php endforeach; ?>
			<h3>Per-Network Custom Hashtags</h3>
			<p class="description" style="margin-bottom:15px;">Override the global hashtags for specific networks. Leave empty to use auto-generated hashtags. Format: <code>#tag1 #tag2 #tag3</code></p>
			<?php
			$network_hashtags = get_option( Config::OPTION_JETPACK_NETWORK_HASHTAGS, [] );
			foreach ( Config::JETPACK_NETWORKS as $svc ) :
			?>
			<table class="form-table">
				<tr>
					<th><?php echo esc_html( ucfirst( $svc ) ); ?> Hashtags</th>
					<td>
						<input type="text" name="jetpack_network_hashtags[<?php echo esc_attr( $svc ); ?>]" value="<?php echo esc_attr( $network_hashtags[ $svc ] ?? '' ); ?>" class="regular-text" placeholder="#news #trending #viral">
						<p class="description">Custom hashtags for <?php echo esc_html( ucfirst( $svc ) ); ?>. Leave empty for auto-generated.</p>
					</td>
				</tr>
			</table>
			<?php endforeach; ?>
			<p class="submit"><input type="submit" name="save_jetpack_settings" class="button button-primary" value="Save Jetpack Social Settings"></p>
		</form>

	<?php elseif ( $active_tab === 'buffer' ) : ?>
		<h3>Buffer API Integration</h3>
		<p class="description" style="margin-bottom:20px;">Share posts to connected social channels via Buffer's GraphQL API. Add multiple Buffer accounts below. Each account shares independently with its own channel set and daily limit.</p>

		<form method="post" id="buffer-accounts-form">
			<?php wp_nonce_field( 'ai_collage_save_buffer' ); ?>

			<h3 style="margin-top:30px;padding-top:20px;border-top:1px solid #ddd;">Cloudflare R2 Settings (for Video Auto-Publish)</h3>
			<p class="description" style="margin-bottom:20px;">Configure Cloudflare R2 / S3-compatible storage for video uploads. When <strong>Video R2+Buffer Auto</strong> is enabled, completed video reels are automatically uploaded to R2 and shared to Buffer via the public R2 URL. Requires R2 public domain (Workers custom domain or public bucket URL).</p>
			<table class="form-table">
			<tr>
				<th>Enable Video R2+Buffer Auto</th>
				<td>
					<label><input type="checkbox" name="video_r2_buffer_auto" value="1" <?php checked( (bool) get_option( Config::OPTION_VIDEO_R2_BUFFER_AUTO, false ) ); ?>> Automatically upload video reels to R2 and share to Buffer</label>
					<p class="description">When enabled, video posts when published will be uploaded to Cloudflare R2 and queued for Buffer publishing at their scheduled time.</p>
				</td>
			</tr>
			<tr>
				<th>R2 Endpoint</th>
				<td><input type="url" name="r2_endpoint" value="<?php echo esc_attr( get_option( Config::OPTION_R2_ENDPOINT, '' ) ); ?>" class="regular-text" placeholder="https://<account-id>.r2.cloudflarestorage.com"></td>
			</tr>
			<tr>
				<th>R2 Access Key ID</th>
				<td><input type="text" name="r2_access_key" value="<?php echo esc_attr( get_option( Config::OPTION_R2_ACCESS_KEY, '' ) ); ?>" class="regular-text"></td>
			</tr>
			<tr>
				<th>R2 Secret Access Key</th>
				<td><input type="password" name="r2_secret_key" value="<?php echo esc_attr( get_option( Config::OPTION_R2_SECRET_KEY, '' ) ); ?>" class="regular-text"></td>
			</tr>
			<tr>
				<th>R2 Bucket Name</th>
				<td><input type="text" name="r2_bucket" value="<?php echo esc_attr( get_option( Config::OPTION_R2_BUCKET, '' ) ); ?>" class="regular-text"></td>
			</tr>
			<tr>
				<th>R2 Public Domain (CDN/Workers URL)</th>
				<td>
					<input type="url" name="r2_public_domain" value="<?php echo esc_attr( get_option( Config::OPTION_R2_PUBLIC_DOMAIN, '' ) ); ?>" class="regular-text" placeholder="https://cdn.yourdomain.com or https://pub-xxx.r2.dev">
					<p class="description"><strong>Required.</strong> Must be a public CDN/Workers custom domain or public bucket URL. <strong>Must NOT point to this WordPress site</strong> (videos would 404).</p>
				</td>
			</tr>
			<tr>
				<th>Test R2 Connection</th>
				<td>
					<button type="button" class="button button-secondary test-r2-connection" style="margin-right:10px;">Test R2 Connection</button>
					<span class="r2-test-result" style="margin-left:10px;"></span>
				</td>
			</tr>
		</table>

		<?php $buffer_accounts = Config::get_buffer_accounts(); ?>
			<input type="hidden" name="buffer_accounts_json" id="buffer_accounts_json" value="">
			<table class="form-table">
				<tr>
					<th>Draft Retention (Days)</th>
					<td>
						<input type="number" name="buffer_draft_retention_days" value="<?php echo esc_attr( get_option( Config::OPTION_BUFFER_DRAFT_RETENTION_DAYS, 2 ) ); ?>" class="small-text" min="0" max="90">
						<p class="description">Auto-delete old Buffer drafts/ideas after N days. 0 = disabled.</p>
					</td>
				</tr>
			</table>
			<div id="buffer-accounts-list">
				<?php if ( empty( $buffer_accounts ) ) : ?>
					<?php $buffer_accounts = [ [ 'id' => 'account_1', 'name' => 'Account 1', 'api_key' => '', 'enabled' => false, 'daily_limit' => 5, 'tiktok_daily_limit' => 10, 'share_mode' => 'draft', 'youtube_privacy' => 'public', 'queue_full_action' => 'publish_oldest', 'disable_link' => false, 'share_to_story' => false, 'global_template' => '', 'channel_ids' => [], 'channel_types' => [], 'channel_templates' => [], 'link_posts' => [], 'channel_hashtags' => [], 'pinterest_boards' => [], 'pinterest_titles' => [], 'youtube_titles' => [], 'youtube_categories' => [], 'channel_story_toggles' => [] ] ]; ?>
				<?php endif; ?>
				<?php foreach ( $buffer_accounts as $idx => $account ) :
					$acct_id = $account['id'] ?? 'account_' . ( $idx + 1 );
					$channels = ! empty( $account['api_key'] ) ? \AiSocialCollage\Services\BufferIntegration::get_channels( $acct_id ) : [];
				?>
				<div class="buffer-account-card" data-index="<?php echo esc_attr( $idx ); ?>" style="border:1px solid #c3c4c7;border-radius:4px;padding:15px;margin-bottom:15px;background:#fff;">
					<table class="form-table">
						<tr>
							<th>Enable</th>
							<td><label><input type="checkbox" class="buf-enabled" value="1" <?php checked( ! empty( $account['enabled'] ) ); ?>> Enable this account</label></td>
						</tr>
						<tr>
							<th>Account Name</th>
							<td><input type="text" class="buf-name regular-text" value="<?php echo esc_attr( $account['name'] ?? '' ); ?>" placeholder="e.g. Primary, Secondary"></td>
						</tr>
						<tr>
							<th>Account ID</th>
							<td><input type="text" class="buf-id regular-text" value="<?php echo esc_attr( $acct_id ); ?>" placeholder="unique_slug"> <p class="description">Unique identifier. Do not change after first save.</p></td>
						</tr>
						<tr>
							<th>API Access Token</th>
							<td>
								<input type="password" class="buf-api-key regular-text" value="<?php echo esc_attr( $account['api_key'] ?? '' ); ?>" placeholder="Bearer token from Buffer">
								<p class="description">Get from <a href="https://publish.buffer.com/settings/api" target="_blank">Buffer Settings</a>.</p>
							</td>
						</tr>
						<tr>
							<th>Daily Share Limit</th>
							<td><input type="number" class="buf-daily-limit small-text" value="<?php echo esc_attr( $account['daily_limit'] ?? 5 ); ?>" min="0" max="50"> <p class="description">0 = unlimited.</p></td>
						</tr>
						<tr>
							<th>TikTok Daily Limit</th>
							<td><input type="number" class="buf-tiktok-daily-limit small-text" value="<?php echo esc_attr( $account['tiktok_daily_limit'] ?? 10 ); ?>" min="0" max="25"> <p class="description">Max posts shared to TikTok per day. 0 = unlimited. Keep this below TikTok's API cap (~15-25 posts/24h) to avoid <code>spam_risk_too_many_posts</code> errors. Recommended: 10.</p></td>
						</tr>
						<tr>
							<th>Queue Full Action</th>
							<td>
								<select class="buf-queue-full-action">
									<?php foreach ( Config::BUFFER_QUEUE_FULL_ACTIONS as $action_key => $action_label ) : ?>
									<option value="<?php echo esc_attr( $action_key ); ?>" <?php selected( $account['queue_full_action'] ?? Config::DEFAULT_QUEUE_FULL_ACTION, $action_key ); ?>><?php echo esc_html( $action_label ); ?></option>
									<?php endforeach; ?>
								</select>
								<p class="description">When a channel has 10 scheduled posts (Buffer free-plan queue limit): <strong>Publish Oldest Scheduled Post Now</strong> posts the oldest queued post immediately to make room for the new share; <strong>Wait for a Free Slot</strong> defers the share and retries automatically once a slot frees up.</p>
							</td>
						</tr>
						<tr>
							<th>Share Mode</th>
							<td>
								<select class="buf-share-mode">
									<?php foreach ( Config::BUFFER_SHARE_MODES as $mode_key => $mode_label ) : ?>
									<option value="<?php echo esc_attr( $mode_key ); ?>" <?php selected( $account['share_mode'] ?? 'draft', $mode_key ); ?>><?php echo esc_html( $mode_label ); ?></option>
									<?php endforeach; ?>
								</select>
							</td>
						</tr>
						<tr>
							<th>YouTube Privacy</th>
							<td>
								<select class="buf-yt-privacy">
									<?php foreach ( Config::BUFFER_YOUTUBE_PRIVACY as $privacy_key => $privacy_label ) : ?>
									<option value="<?php echo esc_attr( $privacy_key ); ?>" <?php selected( $account['youtube_privacy'] ?? Config::DEFAULT_YOUTUBE_PRIVACY, $privacy_key ); ?>><?php echo esc_html( $privacy_label ); ?></option>
									<?php endforeach; ?>
								</select>
								<p class="description">Visibility of videos Buffer uploads to YouTube (Buffer's <code>YoutubePrivacy</code>, default Public). <strong>Private</strong> uploads invisibly and stays editable in YouTube Studio until you set it to Public there; <strong>Unlisted</strong> is link-only. YouTube channels follow the account Share Mode; this only controls their visibility on YouTube.</p>
							</td>
						</tr>
						<tr>
							<th>Disable Post Link</th>
							<td><label><input type="checkbox" class="buf-disable-link" value="1" <?php checked( ! empty( $account['disable_link'] ) ); ?>> Do not include post link</label></td>
						</tr>
						<tr>
							<th>Share to Story</th>
							<td><label><input type="checkbox" class="buf-share-to-story" value="1" <?php checked( ! empty( $account['share_to_story'] ) ); ?>> Enable sharing to Stories</label></td>
						</tr>
						<tr>
							<th>Global Template</th>
							<td>
								<textarea class="buf-global-template large-text" rows="3" placeholder="{headline}&#10;&#10;{description}&#10;&#10;{hashtags}&#10;&#10;{link}&#10;&#10;{mentions}"><?php echo esc_textarea( $account['global_template'] ?? '' ); ?></textarea>
<p class="description">Available placeholders: <code>{headline}</code>, <code>{description}</code>, <code>{hashtags}</code>, <code>{link}</code>, <code>{x_hashtags}</code>, <code>{x_description}</code>, <code>{mentions}</code>. Use <code>{X-CONTENT}</code> in X Custom Template to use formatted short description and tags (combines x_description + x_hashtags).</p>
<p class="description">Captions are auto-truncated to each channel's limit: Twitter <?php echo (int) Config::get_buffer_service_caption_limit( 'twitter' ); ?>, Threads <?php echo (int) Config::get_buffer_service_caption_limit( 'threads' ); ?>, Instagram <?php echo (int) Config::get_buffer_service_caption_limit( 'instagram' ); ?>, LinkedIn <?php echo (int) Config::get_buffer_service_caption_limit( 'linkedin' ); ?>, Pinterest <?php echo (int) Config::get_buffer_service_caption_limit( 'pinterest' ); ?>, TikTok <?php echo (int) Config::get_buffer_service_caption_limit( 'tiktok' ); ?>, Facebook <?php echo (int) Config::get_buffer_service_caption_limit( 'facebook' ); ?>. Hashtags at the end of a caption are kept as-is.</p>
							</td>
						</tr>
					</table>
					<?php if ( ! empty( $channels ) ) : ?>
					<h4 style="margin:10px 0 5px;border-bottom:1px solid #eee;padding-bottom:5px;">Channel Configuration</h4>
					<table class="widefat">
						<thead>
							<tr>
								<th>Enable</th>
								<th>Channel</th>
								<th>Service</th>
								<th>Post Type</th>
								<th>Template Override</th>
								<th>Hashtags</th>
								<th>Link Post</th>
								<th>Story</th>
							</tr>
						</thead>
						<tbody>
						<?php
						$accts_enabled  = $account['channel_ids'] ?? [];
						$accts_types    = $account['channel_types'] ?? [];
						$accts_templ    = $account['channel_templates'] ?? [];
						$accts_link     = $account['link_posts'] ?? [];
						$accts_ht       = $account['channel_hashtags'] ?? [];
						$accts_story    = $account['channel_story_toggles'] ?? [];
						$accts_story_templ = $account['channel_story_templates'] ?? [];
						$accts_boards   = $account['pinterest_boards'] ?? [];
						$accts_titles   = $account['pinterest_titles'] ?? [];
						$accts_yt_titles = $account['youtube_titles'] ?? [];
						$accts_yt_cats   = $account['youtube_categories'] ?? [];
						$valid_types_map = [
							'facebook'  => [ 'post', 'story', 'reel' ],
							'instagram' => [ 'post', 'story', 'reel' ],
							'twitter'   => [ 'post' ],
							'linkedin'  => [ 'post' ],
							'pinterest' => [ 'post' ],
							'youtube'   => [ 'post', 'video' ],
							'threads'   => [ 'post', 'story' ],
							'tiktok'    => [ 'post', 'video' ],
						];
						foreach ( $channels as $ch ) :
							$ch_id = $ch['id'] ?? '';
							$ch_name = $ch['name'] ?? '';
							$ch_svc = strtolower( $ch['service'] ?? '' );
						?>
							<tr>
								<td><input type="checkbox" class="buf-ch-enabled" value="<?php echo esc_attr( $ch_id ); ?>" <?php checked( in_array( $ch_id, $accts_enabled, true ) ); ?>></td>
								<td><?php echo esc_html( $ch_name ); ?></td>
								<td style="text-transform:capitalize;"><?php echo esc_html( $ch_svc ); ?></td>
								<td>
									<select class="buf-ch-type" data-ch="<?php echo esc_attr( $ch_id ); ?>">
										<?php
										$types = $valid_types_map[ $ch_svc ] ?? [ 'post' ];
										foreach ( $types as $type ) :
										?>
										<option value="<?php echo esc_attr( $type ); ?>" <?php selected( $accts_types[ $ch_id ] ?? 'post', $type ); ?>><?php echo esc_html( ucfirst( $type ) ); ?></option>
										<?php endforeach; ?>
									</select>
								</td>
								<td><textarea class="buf-ch-template" data-ch="<?php echo esc_attr( $ch_id ); ?>" rows="2" style="width:150px;" placeholder="{headline}&#10;&#10;{description}&#10;&#10;{hashtags}&#10;&#10;{link}&#10;&#10;{mentions}"><?php echo esc_textarea( $accts_templ[ $ch_id ] ?? '' ); ?></textarea><br><small style="color:#666;">Max caption: <?php echo (int) Config::get_buffer_service_caption_limit( $ch_svc ); ?> characters</small></td>
								<td><input type="text" class="buf-ch-hashtags" data-ch="<?php echo esc_attr( $ch_id ); ?>" value="<?php echo esc_attr( $accts_ht[ $ch_id ] ?? '' ); ?>" style="width:120px;" placeholder="#news"></td>
								<td>
									<?php if ( in_array( $ch_svc, [ 'facebook', 'linkedin' ], true ) ) : ?>
									<input type="checkbox" class="buf-ch-link" data-ch="<?php echo esc_attr( $ch_id ); ?>" value="1" <?php checked( ! empty( $accts_link[ $ch_id ] ) ); ?>>
									<?php else : ?>&mdash;<?php endif; ?>
								</td>
								<td>
									<?php if ( in_array( $ch_svc, [ 'instagram', 'facebook' ], true ) ) : ?>
									<label><input type="checkbox" class="buf-ch-story" data-ch="<?php echo esc_attr( $ch_id ); ?>" value="1" <?php checked( ! empty( $accts_story[ $ch_id ] ) ); ?>> Story</label>
									<br><input type="text" class="buf-ch-story-template" data-ch="<?php echo esc_attr( $ch_id ); ?>" value="<?php echo esc_attr( $accts_story_templ[ $ch_id ] ?? '' ); ?>" placeholder="{headline}&#10;{description}&#10;{hashtags}&#10;{link}&#10;{mentions}" style="width:120px;margin-top:4px;" title="Custom text template for the story post. Uses same placeholders as the main template.">
									<?php else : ?>&mdash;<?php endif; ?>
								</td>
							</tr>
							<?php if ( $ch_svc === 'pinterest' ) : ?>
							<tr>
								<td colspan="8" style="background:#f9f9f9;padding:8px 15px;">
									<label>Board:
										<select class="buf-ch-board" data-ch="<?php echo esc_attr( $ch_id ); ?>">
											<option value="">— Select —</option>
											<?php
											$boards = \AiSocialCollage\Services\BufferIntegration::get_pinterest_boards( $ch_id, $acct_id );
											foreach ( $boards as $board ) :
											?>
											<option value="<?php echo esc_attr( $board['serviceId'] ?? '' ); ?>" <?php selected( $accts_boards[ $ch_id ] ?? '', $board['serviceId'] ?? '' ); ?>><?php echo esc_html( $board['name'] ?? '' ); ?></option>
											<?php endforeach; ?>
										</select>
									</label>
									<label style="margin-left:10px;">Pin Title:
										<input type="text" class="buf-ch-pin-title" data-ch="<?php echo esc_attr( $ch_id ); ?>" value="<?php echo esc_attr( $accts_titles[ $ch_id ] ?? '{headline}' ); ?>" placeholder="{headline}&#10;{mentions}" style="width:180px;">
									</label>
								</td>
							</tr>
							<?php endif; ?>
							<?php if ( $ch_svc === 'youtube' ) : ?>
							<tr>
								<td colspan="8" style="background:#f9f9f9;padding:8px 15px;">
									<label>Video Title:
										<input type="text" class="buf-ch-yt-title" data-ch="<?php echo esc_attr( $ch_id ); ?>" value="<?php echo esc_attr( $accts_yt_titles[ $ch_id ] ?? '{headline}' ); ?>" placeholder="{headline}&#10;{mentions}" style="width:220px;">
									</label>
									<label style="margin-left:10px;">Category:
										<select class="buf-ch-yt-category" data-ch="<?php echo esc_attr( $ch_id ); ?>">
											<option value="">— Select —</option>
											<?php foreach ( Config::BUFFER_YOUTUBE_CATEGORIES as $cat_id => $cat_label ) : ?>
											<option value="<?php echo esc_attr( $cat_id ); ?>" <?php selected( $accts_yt_cats[ $ch_id ] ?? '', $cat_id ); ?>><?php echo esc_html( $cat_label ); ?></option>
											<?php endforeach; ?>
										</select>
									</label>
									<p class="description" style="margin-top:6px;">Title supports template placeholders (<code>{headline}</code>, <code>{description}</code>, <code>{mentions}</code>) and is limited to 100 characters. If no category is selected, Entertainment is used as a safe default.</p>
								</td>
							</tr>
							<?php endif; ?>
						<?php endforeach; ?>
						</tbody>
					</table>
					<?php else : ?>
					<p class="description" style="margin-top:8px;">No channels found for this account. Ensure the API key is valid and social accounts are connected in Buffer.</p>
					<?php endif; ?>
					<p style="margin-top:8px;"><button type="button" class="button button-secondary buf-remove-account">Remove Account</button></p>
				</div>
				<?php endforeach; ?>
			</div>
			<p style="margin-top:10px;"><button type="button" class="button button-secondary" id="buf-add-account">+ Add Buffer Account</button></p>
			<p class="submit"><input type="submit" name="save_buffer_settings" class="button button-primary" value="Save Buffer Settings"></p>
		</form>
		<script>
		jQuery(function($){
			function syncBufferAccountsToJson(){
				var accounts=[];
				$('#buffer-accounts-list .buffer-account-card').each(function(){
					var $c=$(this);
var channels=[],ch_types={},ch_templ={},ch_link={},ch_ht={},ch_story={},ch_story_templ={},ch_boards={},ch_titles={},ch_yt_titles={},ch_yt_cats={};
				$c.find('.buf-ch-enabled:checked').each(function(){channels.push($(this).val());});
				$c.find('.buf-ch-type').each(function(){ch_types[$(this).data('ch')]=$(this).val();});
				$c.find('.buf-ch-template').each(function(){var v=$(this).val().trim();if(v)ch_templ[$(this).data('ch')]=v;});
				$c.find('.buf-ch-link').each(function(){ch_link[$(this).data('ch')]=$(this).is(':checked');});
				$c.find('.buf-ch-hashtags').each(function(){var v=$(this).val().trim();if(v)ch_ht[$(this).data('ch')]=v;});
				$c.find('.buf-ch-story').each(function(){ch_story[$(this).data('ch')]=$(this).is(':checked');});
				$c.find('.buf-ch-story-template').each(function(){var v=$(this).val().trim();if(v)ch_story_templ[$(this).data('ch')]=v;});
				$c.find('.buf-ch-board').each(function(){var v=$(this).val();if(v)ch_boards[$(this).data('ch')]=v;});
				$c.find('.buf-ch-pin-title').each(function(){var v=$(this).val().trim();if(v)ch_titles[$(this).data('ch')]=v;});
				$c.find('.buf-ch-yt-title').each(function(){var v=$(this).val().trim();if(v)ch_yt_titles[$(this).data('ch')]=v;});
				$c.find('.buf-ch-yt-category').each(function(){var v=$(this).val();if(v)ch_yt_cats[$(this).data('ch')]=v;});
				accounts.push({
					id: $c.find('.buf-id').val().trim(),
					name: $c.find('.buf-name').val().trim(),
					api_key: $c.find('.buf-api-key').val().trim(),
					enabled: $c.find('.buf-enabled').is(':checked'),
					daily_limit: (function(){var v=parseInt($c.find('.buf-daily-limit').val(),10);return isNaN(v)?5:v;})(),
				tiktok_daily_limit: (function(){var v=parseInt($c.find('.buf-tiktok-daily-limit').val(),10);return isNaN(v)?10:v;})(),
					share_mode: $c.find('.buf-share-mode').val(),
					youtube_privacy: $c.find('.buf-yt-privacy').val() || 'public',
					queue_full_action: $c.find('.buf-queue-full-action').val(),
					disable_link: $c.find('.buf-disable-link').is(':checked'),
					share_to_story: $c.find('.buf-share-to-story').is(':checked'),
					global_template: $c.find('.buf-global-template').val(),
					channel_ids: channels,
					channel_types: ch_types,
					channel_templates: ch_templ,
					link_posts: ch_link,
					channel_hashtags: ch_ht,
					channel_story_toggles: ch_story,
					channel_story_templates: ch_story_templ,
					pinterest_boards: ch_boards,
					pinterest_titles: ch_titles,
					youtube_titles: ch_yt_titles,
					youtube_categories: ch_yt_cats,
				});
				});
				$('#buffer_accounts_json').val(JSON.stringify(accounts));
			}
			$('#buffer-accounts-form').on('submit',function(){syncBufferAccountsToJson();});
			$('#buf-add-account').on('click',function(){
				var idx=$('#buffer-accounts-list .buffer-account-card').length+1;
				var html='<div class="buffer-account-card" data-index="'+idx+'" style="border:1px solid #c3c4c7;border-radius:4px;padding:15px;margin-bottom:15px;background:#fff;">'
					+'<table class="form-table">'
					+'<tr><th>Enable</th><td><label><input type="checkbox" class="buf-enabled" value="1" checked> Enable this account</label></td></tr>'
					+'<tr><th>Account Name</th><td><input type="text" class="buf-name regular-text" value="Account '+idx+'"></td></tr>'
					+'<tr><th>Account ID</th><td><input type="text" class="buf-id regular-text" value="account_'+idx+'" placeholder="unique_slug"></td></tr>'
					+'<tr><th>API Access Token</th><td><input type="password" class="buf-api-key regular-text" placeholder="Bearer token from Buffer"></td></tr>'
					+'<tr><th>Daily Share Limit</th><td><input type="number" class="buf-daily-limit small-text" value="5" min="0" max="50"></td></tr>'
				+'<tr><th>TikTok Daily Limit</th><td><input type="number" class="buf-tiktok-daily-limit small-text" value="10" min="0" max="25"></td></tr>'
					+'<tr><th>Queue Full Action</th><td><select class="buf-queue-full-action"><?php foreach ( Config::BUFFER_QUEUE_FULL_ACTIONS as $ak => $al ) : ?><option value="<?php echo esc_js( $ak ); ?>"><?php echo esc_js( $al ); ?></option><?php endforeach; ?></select></td></tr>'
					+'<tr><th>Share Mode</th><td><select class="buf-share-mode"><?php foreach ( Config::BUFFER_SHARE_MODES as $mk => $ml ) : ?><option value="<?php echo esc_js( $mk ); ?>"><?php echo esc_js( $ml ); ?></option><?php endforeach; ?></select></td></tr>'
				+'<tr><th>YouTube Privacy</th><td><select class="buf-yt-privacy"><?php foreach ( Config::BUFFER_YOUTUBE_PRIVACY as $pk => $pl ) : ?><option value="<?php echo esc_js( $pk ); ?>"><?php echo esc_js( $pl ); ?></option><?php endforeach; ?></select></td></tr>'
					+'<tr><th>Disable Post Link</th><td><label><input type="checkbox" class="buf-disable-link"> Do not include post link</label></td></tr>'
					+'<tr><th>Share to Story</th><td><label><input type="checkbox" class="buf-share-to-story"> Enable sharing to Stories</label></td></tr>'
					+'<tr><th>Global Template</th><td><textarea class="buf-global-template large-text" rows="3" placeholder="{headline}\n\n{description}\n\n{hashtags}\n\n{link}\n\n{mentions}"></textarea></td></tr>'
					+'</table>'
					+'<p class="description" style="margin-top:8px;">Save first, then refresh to load channels for this account.</p>'
					+'<p style="margin-top:8px;"><button type="button" class="button button-secondary buf-remove-account">Remove Account</button></p>'
					+'</div>';
				$('#buffer-accounts-list').append(html);
			});
			$(document).on('click','.buf-remove-account',function(){
				if($('#buffer-accounts-list .buffer-account-card').length<=1){alert('At least one account is required.');return;}
				$(this).closest('.buffer-account-card').remove();
			});

			// Test R2 connection
			$(document).on('click', '.test-r2-connection', function(e){
				e.preventDefault();
				var $btn = $(this);
				var $result = $btn.siblings('.r2-test-result');
				$btn.prop('disabled', true).text('Testing...');
				$result.text('');
				$.post(aiCollageData.ajax_url, {
					action: 'ai_collage_test_r2',
					nonce: aiCollageData.nonce,
				}, function(res){
					if(res.success){
						$result.html('<span style="color:green;">✓ ' + (res.data.message || 'R2 connection test successful!') + '</span>');
					} else {
						$result.html('<span style="color:red;">✗ ' + (res.data || 'Test failed') + '</span>');
					}
				}).fail(function(){
					$result.html('<span style="color:red;">✗ AJAX error</span>');
				}).always(function(){
					$btn.prop('disabled', false).text('Test R2 Connection');
				});
			});
		});
		</script>

	<?php elseif ( $active_tab === 'retention' ) : ?>
				<h3>Data Retention</h3>
				<form method="post">
					<?php wp_nonce_field( 'ai_collage_save_retention' ); ?>
					<table class="form-table">
						<tr>
							<th>Log Retention (days)</th>
							<td>
								<input type="number" name="log_retention_days" value="<?php echo esc_attr( get_option( Config::OPTION_LOG_RETENTION_DAYS, Config::DEFAULT_LOG_RETENTION_DAYS ) ); ?>" class="small-text" min="0">
								<p class="description">Days to keep log entries. Default: <?php echo esc_html( Config::DEFAULT_LOG_RETENTION_DAYS ); ?>. 0 = keep forever</p>
							</td>
						</tr>
						<tr>
							<th>Image Retention (days)</th>
							<td>
								<input type="number" name="image_retention_days" value="<?php echo esc_attr( get_option( Config::OPTION_IMAGE_RETENTION_DAYS, Config::DEFAULT_IMAGE_RETENTION_DAYS ) ); ?>" class="small-text" min="0">
								<p class="description">Days to keep generated images. Default: <?php echo esc_html( Config::DEFAULT_IMAGE_RETENTION_DAYS ); ?>. 0 = keep forever</p>
							</td>
						</tr>
						<tr>
							<th>Job Data Retention (days)</th>
							<td>
								<input type="number" name="retention_days" value="<?php echo esc_attr( get_option( Config::OPTION_RETENTION_DAYS, Config::DEFAULT_RETENTION_DAYS ) ); ?>" class="small-text" min="0">
								<p class="description">Days to keep completed/failed job records. Default: <?php echo esc_html( Config::DEFAULT_RETENTION_DAYS ); ?>. 0 = keep forever</p>
							</td>
						</tr>
						<tr>
							<th>Generated Post Retention (days)</th>
							<td>
								<input type="number" name="generated_post_retention_days" value="<?php echo esc_attr( get_option( Config::OPTION_GENERATED_POST_RETENTION_DAYS, Config::DEFAULT_GENERATED_POST_RETENTION_DAYS ) ); ?>" class="small-text" min="0">
								<p class="description">Days to keep published posts processed by the AI. Default: <?php echo esc_html( Config::DEFAULT_GENERATED_POST_RETENTION_DAYS ); ?>. 0 = keep forever</p>
							</td>
						</tr>
						<tr>
							<th>Generated Post Retention Categories</th>
							<td>
								<select name="generated_post_retention_categories[]" multiple="multiple" style="width: 300px; height: 100px;">
									<?php 
									$selected_gen_cats = get_option( Config::OPTION_GENERATED_POST_RETENTION_CATEGORIES, [] );
									$categories = get_categories( [ 'hide_empty' => false ] );
									foreach ( $categories as $cat ) : 
									?>
									<option value="<?php echo esc_attr( $cat->term_id ); ?>" <?php echo in_array( $cat->term_id, $selected_gen_cats ) ? 'selected' : ''; ?>>
										<?php echo esc_html( $cat->name ); ?>
									</option>
									<?php endforeach; ?>
								</select>
								<p class="description">Select specific categories to restrict the Generated Post cleanup to. If none selected, applies to ALL generated posts.</p>
							</td>
						</tr>
						<tr>
							<th>Source Post Retention (days)</th>
							<td>
								<input type="number" name="source_post_retention_days" value="<?php echo esc_attr( get_option( Config::OPTION_SOURCE_POST_RETENTION_DAYS, Config::DEFAULT_SOURCE_POST_RETENTION_DAYS ) ); ?>" class="small-text" min="0">
								<p class="description">Days to keep unused draft posts (from RSS or Manual Campaigns). Default: <?php echo esc_html( Config::DEFAULT_SOURCE_POST_RETENTION_DAYS ); ?>. 0 = keep forever</p>
							</td>
						</tr>
						<tr>
							<th>Source Post Retention Categories</th>
							<td>
								<select name="source_post_retention_categories[]" multiple="multiple" style="width: 300px; height: 100px;">
									<?php 
									$selected_src_cats = get_option( Config::OPTION_SOURCE_POST_RETENTION_CATEGORIES, [] );
									foreach ( $categories as $cat ) : 
									?>
									<option value="<?php echo esc_attr( $cat->term_id ); ?>" <?php echo in_array( $cat->term_id, $selected_src_cats ) ? 'selected' : ''; ?>>
										<?php echo esc_html( $cat->name ); ?>
									</option>
									<?php endforeach; ?>
								</select>
								<p class="description">Select specific categories to restrict the Source Post cleanup to. If none selected, applies to ALL source posts.</p>
							</td>
						</tr>
						<tr>
							<th>Delete Data on Uninstall</th>
							<td>
								<label><input type="checkbox" name="delete_data_on_uninstall" value="1" <?php checked( (bool) get_option( Config::OPTION_DELETE_DATA_ON_UNINSTALL, Config::DEFAULT_DELETE_DATA_ON_UNINSTALL ) ); ?>> Permanently delete ALL plugin data when the plugin is deleted</label>
								<p class="description">Disabled by default — deleting the plugin keeps all tables, posts, images and settings. Plugin UPDATES never delete data; only plugin deletion does, and only when this box is checked.</p>
							</td>
						</tr>
					</table>
					<p class="submit"><input type="submit" name="save_retention_settings" class="button button-primary" value="Save Retention Settings"></p>
				</form>

				<?php elseif ( $active_tab === 'advanced' ) : ?>
				<h3>Advanced Options</h3>
				<form method="post">
					<?php wp_nonce_field( 'ai_collage_save_advanced' ); ?>
					<table class="form-table">
						<tr>
							<th>Smart AI Engine</th>
							<td><label><input type="checkbox" name="smart_ai_enabled" value="1" <?php checked( (bool) get_option( Config::OPTION_SMART_AI_ENABLED, true ) ); ?>> Enable color extraction &amp; focal point detection</label></td>
						</tr>
						<tr>
							<th>Auto Color from Image</th>
							<td><label><input type="checkbox" name="auto_color_enabled" value="1" <?php checked( (bool) get_option( Config::OPTION_AUTO_COLOR_ENABLED, true ) ); ?>> Extract dominant colors and apply to template</label></td>
						</tr>
				<tr>
					<th>Smart Crop</th>
					<td><label><input type="checkbox" name="smart_crop_enabled" value="1" <?php checked( (bool) get_option( Config::OPTION_SMART_CROP_ENABLED, true ) ); ?>> Detect focal point for image positioning</label></td>
				</tr>
	<tr>
	<th>Show Plugin Credit</th>
	<td><label><input type="checkbox" name="show_plugin_credit" value="1" <?php checked( (bool) get_option( Config::OPTION_SHOW_PLUGIN_CREDIT, false ) ); ?>> Display &ldquo;AI Social Collage&rdquo; credit watermark on generated images</label></td>
	</tr>
						<tr>
							<th>Append Tags to Post</th>
							<td><label><input type="checkbox" name="append_tags_to_post" value="1" <?php checked( (bool) get_option( Config::OPTION_APPEND_TAGS_TO_POST, false ) ); ?>> Append generated hashtags directly to the end of the published post content</label></td>
						</tr>
					</table>
					<p class="submit"><input type="submit" name="save_advanced_settings" class="button button-primary" value="Save Advanced Settings"></p>
				</form>

				<h3 style="margin-top:30px;">Social Media Image Extraction</h3>
				<form method="post">
					<?php wp_nonce_field( 'ai_collage_save_image_extraction' ); ?>
					<table class="form-table">
						<tr>
							<th>Enable Image Extraction</th>
							<td>
								<label><input type="checkbox" name="image_extraction_enabled" value="1" <?php checked( (bool) get_option( Config::OPTION_IMAGE_EXTRACTION_ENABLED, false ) ); ?>> Remove logos and text overlays from social media source images before collage generation</label>
								<p class="description">When enabled, the plugin will detect and crop logo/text zones from Facebook and other social media post images. Each campaign can override this setting individually.</p>
							</td>
						</tr>
						<tr>
							<th>Enable Image Verification</th>
							<td>
								<label><input type="checkbox" name="image_verification_enabled" value="1" <?php checked( (bool) get_option( Config::OPTION_VERIFICATION_ENABLED, false ) ); ?>> Verify final collage for remaining logos/text bands</label>
								<p class="description">After collage generation, sends the image to AI models to verify that source logos and text bands were properly removed. Logs any issues found.</p>
							</td>
						</tr>
						<tr>
							<th>Verification Provider Chain</th>
							<td>
								<textarea name="verification_provider_chain" rows="5" cols="50"><?php echo esc_textarea( wp_json_encode( get_option( Config::OPTION_VERIFICATION_PROVIDER_CHAIN, [] ), JSON_PRETTY_PRINT ) ); ?></textarea>
								<p class="description">JSON array of providers. Example: [{"id":"verification_hf","api_key":"YOUR_HF_KEY","model":"microsoft/trocr-base-large"}]</p>
							</td>
						</tr>
						<tr>
							<th>Confidence Threshold</th>
							<td>
								<input type="number" name="verification_threshold" min="0" max="1" step="0.1" value="<?php echo esc_attr( get_option( Config::OPTION_VERIFICATION_CONFIDENCE_THRESHOLD, 0.7 ) ); ?>">
								<p class="description">Minimum confidence score (0.0-1.0) to flag verification issues.</p>
							</td>
						</tr>
						<tr>
							<th>HF API Key</th>
							<td>
								<input type="password" name="hf_api_key" placeholder="hf_..." value="<?php echo esc_attr( get_option( Config::OPTION_HF_API_KEY, '' ) ); ?>">
								<p class="description">HuggingFace Inference API key for free vision models (10k tokens/day free).</p>
							</td>
						</tr>
						<tr>
							<th>Google Vision Key</th>
							<td>
								<input type="password" name="google_vision_key" placeholder="AIza..." value="<?php echo esc_attr( get_option( Config::OPTION_GOOGLE_VISION_KEY, '' ) ); ?>">
								<p class="description">Google Cloud Vision API key (optional fallback).</p>
							</td>
						</tr>
						<tr>
							<th>Debug Mode</th>
							<td>
								<label><input type="checkbox" name="image_extraction_debug" value="1" <?php checked( (bool) get_option( Config::OPTION_IMAGE_EXTRACTION_DEBUG, false ) ); ?>> Save zone visualization overlays to temp directory</label>
								<p class="description">Saves debug images showing detected logo, text, and image zone boundaries. Useful for tuning campaign zone settings. Debug images are cleaned automatically.</p>
							</td>
						</tr>
					</table>
					<p class="submit"><input type="submit" name="save_image_extraction_settings" class="button button-primary" value="Save Image Extraction Settings"></p>
				</form>

				<h3 style="margin-top:30px;">Video Reel Generation</h3>
				<form method="post">
					<?php wp_nonce_field( 'ai_collage_save_video' ); ?>
					<table class="form-table">
						<tr>
							<th>Enable Video Reels</th>
							<td>
								<label><input type="checkbox" name="video_reel_enabled" value="1" <?php checked( (bool) get_option( Config::OPTION_VIDEO_ENABLED, false ) ); ?>> Generate Instagram Reels from video source posts</label>
								<p class="description">When enabled, posts containing video links from Facebook, Instagram, or X/Twitter will be processed through the video reel pipeline. Auto-detects video content and creates portrait 1080×1920 reels with Urdu headings and brand bar. Requires FFmpeg on the server.</p>
							</td>
						</tr>
						<tr>
							<th>FFmpeg Status</th>
							<td>
								<?php
								$processor = new \AiSocialCollage\Services\VideoProcessor();
								$ref = new \ReflectionMethod( $processor, 'find_ffmpeg' );
								$ref->setAccessible( true );
								$ffmpeg_path = $ref->invoke( $processor );
								if ( $ffmpeg_path && is_executable( $ffmpeg_path ) ) {
									echo '<span style="color:green;font-weight:bold;">&#10003; Available</span> <code>' . esc_html( $ffmpeg_path ) . '</code>';
								} else {
									echo '<span style="color:red;font-weight:bold;">&#10007; Not Found</span> <p class="description">Install FFmpeg: <code>sudo apt install ffmpeg</code></p>';
								}
								?>
							</td>
						</tr>
						<tr>
							<th>Max Reel Duration</th>
							<td>
								<input type="number" name="video_max_duration" min="10" max="300" value="<?php echo esc_attr( get_option( Config::OPTION_VIDEO_MAX_DURATION, Config::DEFAULT_VIDEO_MAX_DURATION ) ); ?>"> seconds
								<p class="description">Maximum video length in seconds. Videos longer than this will be trimmed. Instagram Reels support up to 90 seconds.</p>
							</td>
						</tr>
					</table>
					<p class="submit"><input type="submit" name="save_video_settings" class="button button-primary" value="Save Video Settings"></p>
				</form>

				<h3>Plugin Info</h3>
				<table class="form-table">
					<tr><th>Plugin Version</th><td><code><?php echo esc_html( Config::VERSION ); ?></code></td></tr>
					<tr><th>Action Scheduler Group</th><td><code><?php echo esc_html( Config::AS_GROUP ); ?></code></td></tr>
					<tr><th>Cron Poll Interval</th><td><code><?php echo esc_html( Config::CRON_POLL_INTERVAL ); ?>s</code></td></tr>
					<tr><th>Quota Limit</th><td><code><?php echo esc_html( Config::QUOTA_MAX_REQUESTS ); ?> requests / <?php echo esc_html( Config::QUOTA_TIME_WINDOW ); ?>s</code></td></tr>
				</table>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•
	// AJAX HANDLERS
	// â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•â•

	public function ajax_save_campaigns() {
		check_ajax_referer( 'ai_collage_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( 'Insufficient permissions.' ); }

		$campaigns_raw = isset( $_POST['campaigns'] ) ? (array) $_POST['campaigns'] : [];
		$existing_campaigns = Config::get_option_array( Config::OPTION_CAMPAIGNS, [] );
		$existing_map = [];
		foreach ( $existing_campaigns as $ec ) {
			$existing_map[ (string) ( $ec['id'] ?? '' ) ] = $ec;
		}
		$clean = [];
		foreach ( $campaigns_raw as $c ) {
			$cid = sanitize_text_field( ! empty( $c['id'] ) ? $c['id'] : wp_generate_uuid4() );
			$existing_lr = (int) ( ( $existing_map[ $cid ]['last_run'] ?? 0 ) ?: 0 );
			$clean[] = [
		'id' => $cid,
		'name' => sanitize_text_field( $c['name'] ?? '' ),
		'source_category' => sanitize_title( $c['source_category'] ?? '' ),
		'tags' => sanitize_text_field( $c['tags'] ?? '' ),
		'target_vertical' => sanitize_text_field( $c['target_vertical'] ?? '' ),
		'destination_category' => (int) ( $c['destination_category'] ?? 0 ),
		'frequency' => sanitize_text_field( Config::get_campaign_value( $c, 'frequency', Config::FREQUENCY_1_HOUR ) ),
		'publish_status' => sanitize_text_field( Config::get_campaign_value( $c, 'publish_status', Config::DEFAULT_PUBLISH_STATUS ) ),
		'ai_strategy' => sanitize_text_field( Config::get_campaign_value( $c, 'ai_strategy', Config::DEFAULT_STRATEGY ) ),
		'template' => sanitize_text_field( Config::get_campaign_value( $c, 'template', Config::DEFAULT_TEMPLATE ) ),
		'output_language' => in_array( $c['output_language'] ?? '', [ 'en', 'ur' ], true ) ? $c['output_language'] : 'auto',
		'headline_font' => sanitize_text_field( $c['headline_font'] ?? '' ),
		'platform_size' => sanitize_text_field( Config::get_campaign_value( $c, 'platform_size', Config::DEFAULT_SIZE ) ),
		'active' => ! empty( $c['active'] ),
		'last_run' => $existing_lr,
		'brand_override_enabled' => ! empty( $c['brand_override_enabled'] ),
		'primary_color' => sanitize_hex_color( $c['primary_color'] ?? '' ),
		'secondary_color' => sanitize_hex_color( $c['secondary_color'] ?? '' ),
		'accent_color' => sanitize_hex_color( $c['accent_color'] ?? '' ),
		'emphasis_color' => sanitize_hex_color( $c['emphasis_color'] ?? '' ),
		'key_term_color' => sanitize_hex_color( $c['key_term_color'] ?? '' ),
		'breaking_color' => sanitize_hex_color( $c['breaking_color'] ?? '' ),
		'text_backing_color' => sanitize_hex_color( $c['text_backing_color'] ?? '' ),
		'logo_position' => sanitize_text_field( $c['logo_position'] ?? '' ),
		'font_body' => sanitize_text_field( $c['font_body'] ?? '' ),
		'stopped' => ! empty( $c['stopped'] ),
		'image_extraction_enabled' => ! empty( $c['image_extraction_enabled'] ),
		'detection_mode' => in_array( $c['detection_mode'] ?? '', [ 'auto', 'manual', 'hybrid' ], true ) ? $c['detection_mode'] : 'hybrid',
		'content_type' => in_array( $c['content_type'] ?? '', [ 'auto', 'image', 'video' ], true ) ? $c['content_type'] : 'auto',
		'logo_zone' => $this->sanitize_zone_config( $c, 'logo_zone', [ 'x' => 0.0, 'y' => 0.0, 'w' => 0.18, 'h' => 0.08 ] ),
		'text_zone' => $this->sanitize_zone_config( $c, 'text_zone', [ 'x' => 0.0, 'y' => 0.60, 'w' => 1.0, 'h' => 0.40 ] ),
		'image_zone' => $this->sanitize_zone_config( $c, 'image_zone', [ 'x' => 0.0, 'y' => 0.0, 'w' => 1.0, 'h' => 0.60 ] ),
		'video_zone_enabled' => ! empty( $c['video_zone_enabled'] ),
		'video_zone_mode' => in_array( $c['video_zone_mode'] ?? '', [ 'auto', 'manual' ], true ) ? $c['video_zone_mode'] : 'auto',
		'video_content_zone' => $this->sanitize_zone_config( $c, 'video_content_zone', [ 'x' => 0.0, 'y' => 0.0, 'w' => 1.0, 'h' => 1.0 ] ),
	];
		}
		update_option( Config::OPTION_CAMPAIGNS, $clean );
		wp_send_json_success( $clean );
	}

	public function ajax_run_campaign() {
		check_ajax_referer( 'ai_collage_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( 'Insufficient permissions.' ); }

		$pipeline_paused = (bool) get_option( Config::OPTION_PIPELINE_PAUSED, false );
		if ( $pipeline_paused ) {
			wp_send_json_error( 'Pipeline is paused. Resume it before manually running a campaign.' );
		}

		$campaign_id = sanitize_text_field( $_POST['campaign_id'] ?? '' );
		if ( empty( $campaign_id ) ) { wp_send_json_error( 'No campaign ID provided.' ); }

		$campaigns = Config::get_option_array( Config::OPTION_CAMPAIGNS, [] );
		$campaign = null;
		foreach ( $campaigns as $c ) {
			if ( $c['id'] === $campaign_id ) { $campaign = $c; break; }
		}
		if ( ! $campaign ) { wp_send_json_error( 'Campaign not found.' ); }

		$source_slug = sanitize_title( $campaign['source_category'] ?? '' );
		$args = [ 'post_type' => 'post', 'post_status' => [ 'draft', 'pending' ], 'posts_per_page' => 1, 'orderby' => 'date', 'order' => 'ASC' ];
		if ( ! empty( $source_slug ) ) { $args['category_name'] = $source_slug; }

		$query = new \WP_Query( $args );
		if ( ! $query->have_posts() ) { wp_send_json_error( 'No draft posts found in source category "' . esc_html( $source_slug ) . '".' ); }

		$post_id = $query->posts[0]->ID;
        if ( JobManager::job_exists_for_post( $post_id, true ) ) { wp_send_json_error( 'A job already exists for post #' . $post_id . '.' ); }

		update_post_meta( $post_id, Config::META_CAMPAIGN_DATA, $campaign );
		$job_id = JobManager::create_job( $post_id );
		if ( ! $job_id ) { wp_send_json_error( 'Failed to create job record.' ); }

		if ( function_exists( 'as_schedule_single_action' ) ) {
			as_schedule_single_action( time(), Config::ACTION_PROCESS_JOB, [ 'job_id' => $job_id ], Config::AS_GROUP );
		}

		Logger::info( Config::LOG_ACTION_MANUAL_RUN, $job_id, [ 'post_id' => $post_id, 'campaign' => $campaign['name'] ], '200' );
		wp_send_json_success( [ 'message' => 'Job #' . $job_id . ' queued for post #' . $post_id . '.', 'job_id' => $job_id, 'post_id' => $post_id ] );
	}

	public function ajax_delete_campaign() {
		check_ajax_referer( 'ai_collage_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( 'Insufficient permissions.' ); }

		$campaign_id = sanitize_text_field( $_POST['campaign_id'] ?? '' );
		if ( empty( $campaign_id ) ) { wp_send_json_error( 'No campaign ID provided.' ); }

		$campaigns = Config::get_option_array( Config::OPTION_CAMPAIGNS, [] );
		$filtered = array_filter( $campaigns, function ( $c ) use ( $campaign_id ) { return $c['id'] !== $campaign_id; } );
		update_option( Config::OPTION_CAMPAIGNS, array_values( $filtered ) );
		wp_send_json_success( [ 'message' => 'Campaign removed.' ] );
	}

	public function ajax_delete_job() {
		check_ajax_referer( 'ai_collage_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( 'Insufficient permissions.' ); }

		$job_id = (int) ( $_POST['job_id'] ?? 0 );
		if ( ! $job_id ) { wp_send_json_error( 'No job ID provided.' ); }

		global $wpdb;
		$wpdb->delete( $this->jobs_table(), [ 'id' => $job_id ], [ '%d' ] );
		wp_send_json_success( [ 'message' => 'Job deleted.' ] );
	}

	public function ajax_retry_job() {
		check_ajax_referer( 'ai_collage_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( 'Insufficient permissions.' ); }

		$job_id = (int) ( $_POST['job_id'] ?? 0 );
		if ( ! $job_id ) { wp_send_json_error( 'No job ID provided.' ); }

		$job = JobManager::get_job( $job_id );
		if ( ! $job ) { wp_send_json_error( 'Job not found.' ); }

		JobManager::update_status( $job_id, Config::STATUS_PENDING );
		delete_post_meta( (int) $job->post_id, '_ai_collage_job_created' );
		set_transient( 'ai_collage_queued_recent_' . (int) $job->post_id, time(), HOUR_IN_SECONDS );
		delete_transient( 'ai_collage_job_lock_' . (int) $job_id );

		if ( ! function_exists( 'as_schedule_single_action' ) ) {
			Logger::info( 'job_retry', $job_id, [ 'retried_by' => wp_get_current_user()->user_login ], '200' );
			wp_send_json_success( [ 'message' => 'Job #' . $job_id . ' re-queued for processing.' ] );
		}

		// Avoid duplicate Action Scheduler items; status was already flipped to
		// pending above so the existing action will resolve correctly.
		if ( \AiSocialCollage\Actions\QueueProcessor::check_pending_action_for_job( (int) $job_id ) ) {
			Logger::info( 'job_retry_skipped_already_pending', $job_id, [ 'retried_by' => wp_get_current_user()->user_login ], '200' );
			wp_send_json_success( [ 'message' => 'Job #' . $job_id . ' already has a pending Action Scheduler item; not re-enqueued.' ] );
			return;
		}

		as_schedule_single_action( time(), Config::ACTION_PROCESS_JOB, [ 'job_id' => $job_id ], Config::AS_GROUP );

		Logger::info( 'job_retry', $job_id, [ 'retried_by' => wp_get_current_user()->user_login ], '200' );
		wp_send_json_success( [ 'message' => 'Job #' . $job_id . ' re-queued for processing.' ] );
	}

	public static function serve_logs_download() {
		if ( ! is_user_logged_in() ) {
			wp_die( 'Login required.', '', [ 'response' => 401 ] );
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Insufficient permissions.', '', [ 'response' => 403 ] );
		}

		$token = isset( $_GET['token'] ) ? sanitize_text_field( wp_unslash( $_GET['token'] ) ) : '';
		if ( empty( $token ) || ! wp_verify_nonce( $token, 'ai_collage_download_logs' ) ) {
			wp_die( 'Invalid or missing token.', '', [ 'response' => 403 ] );
		}

		$instance = new self();

		global $wpdb;
		$lt = $instance->logs_table();

		$level = isset( $_GET['log_level'] ) ? sanitize_text_field( wp_unslash( $_GET['log_level'] ) ) : '';
		$search = isset( $_GET['log_search'] ) ? sanitize_text_field( wp_unslash( $_GET['log_search'] ) ) : '';

		$where_clauses = [ '1=1' ];
		$where_args = [];

		if ( ! empty( $level ) && Logger::is_valid_level( $level ) ) {
			$where_clauses[] = 'log_level = %s';
			$where_args[] = $level;
		}
		if ( ! empty( $search ) ) {
			$where_clauses[] = 'action LIKE %s';
			$where_args[] = '%' . $wpdb->esc_like( $search ) . '%';
		}

		$where_sql = implode( ' AND ', $where_clauses );

		ignore_user_abort( true );
		if ( function_exists( 'set_time_limit' ) ) { set_time_limit( 0 ); }

		while ( ob_get_level() ) { ob_end_clean(); }

		$filename = 'ai-collage-logs-' . gmdate( 'Y-m-d-H-i-s' ) . '.csv';
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		header( 'Content-Transfer-Encoding: binary' );
		header( 'Cache-Control: no-cache, no-store, must-revalidate' );
		header( 'Pragma: no-cache' );
		header( 'Expires: 0' );

		$output = fopen( 'php://output', 'w' );

		$safe_encode = function ( $value ) {
			if ( is_array( $value ) || is_object( $value ) ) {
				$json = wp_json_encode( $value, JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR );
				if ( false === $json ) {
					$json = json_encode( (array) $value, JSON_PARTIAL_OUTPUT_ON_ERROR ) ?: '';
				}
				return $json;
			}
			return (string) ( $value ?: '' );
		};

		fputcsv( $output, [ 'ID', 'Job ID', 'Action', 'Level', 'Response Code', 'Execution Time', 'Request Payload', 'Raw Response', 'Created At' ] );

		$limit = 10000;
		$total_exported = 0;
		$last_id = PHP_INT_MAX;
		$batch_size = 500;

		while ( $total_exported < $limit ) {
			$current_batch_size = min( $batch_size, $limit - $total_exported );

			$query_args = $where_args;
			$query_args[] = $last_id;

			$query = $wpdb->prepare(
				"SELECT id, job_id, action, log_level, response_code, execution_time, request_payload, raw_response, created_at FROM `$lt` WHERE $where_sql AND id < %d ORDER BY id DESC LIMIT $current_batch_size",
				$query_args
			);

			$rows = $wpdb->get_results( $query, ARRAY_A );
			if ( empty( $rows ) ) { break; }

			foreach ( $rows as $l ) {
				$payload = isset( $l['request_payload'] ) ? maybe_unserialize( $l['request_payload'] ) : '';
				$response = isset( $l['raw_response'] ) ? maybe_unserialize( $l['raw_response'] ) : '';
				fputcsv( $output, [
					$l['id'],
					$l['job_id'] ?: '',
					$l['action'],
					$l['log_level'] ?? 'info',
					$l['response_code'],
					round( (float) $l['execution_time'], 3 ),
					$safe_encode( $payload ),
					$safe_encode( $response ),
					$l['created_at'],
				] );
				$last_id = (int) $l['id'];
				$total_exported++;
			}

			if ( ob_get_level() > 0 ) { ob_flush(); }
			flush();

			if ( count( $rows ) < $current_batch_size ) { break; }
		}

		fclose( $output );
		exit;
	}

	public function ajax_download_logs() {
		check_ajax_referer( 'ai_collage_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Insufficient permissions.' ); }

		global $wpdb;
		$lt = $this->logs_table();

		$level = isset( $_POST['log_level'] ) ? sanitize_text_field( $_POST['log_level'] ) : '';
		$search = isset( $_POST['log_search'] ) ? sanitize_text_field( $_POST['log_search'] ) : '';

		$where_clauses = [ '1=1' ];
		$where_args = [];

		if ( ! empty( $level ) && Logger::is_valid_level( $level ) ) {
			$where_clauses[] = 'log_level = %s';
			$where_args[] = $level;
		}
		if ( ! empty( $search ) ) {
			$where_clauses[] = 'action LIKE %s';
			$where_args[] = '%' . $wpdb->esc_like( $search ) . '%';
		}

		$where_sql = implode( ' AND ', $where_clauses );

		ignore_user_abort( true );
		if ( function_exists( 'set_time_limit' ) ) { set_time_limit( 0 ); }

		while ( ob_get_level() ) { ob_end_clean(); }

		$filename = 'ai-collage-logs-' . date( 'Y-m-d-H-i-s' ) . '.csv';
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		header( 'Cache-Control: no-cache, no-store, must-revalidate' );
		header( 'Pragma: no-cache' );
		header( 'Expires: 0' );

		$output = fopen( 'php://output', 'w' );

		$safe_encode = function ( $value ) {
			if ( is_array( $value ) || is_object( $value ) ) {
				$json = wp_json_encode( $value, JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR );
				if ( false === $json ) {
					$json = json_encode( (array) $value, JSON_PARTIAL_OUTPUT_ON_ERROR ) ?: '';
				}
				return $json;
			}
			return (string) ( $value ?: '' );
		};

		fputcsv( $output, [ 'ID', 'Job ID', 'Action', 'Level', 'Response Code', 'Execution Time', 'Request Payload', 'Raw Response', 'Created At' ] );

		$limit = 10000;
		$total_exported = 0;
		$last_id = PHP_INT_MAX;
		$batch_size = 500;

		while ( $total_exported < $limit ) {
			$current_batch_size = min( $batch_size, $limit - $total_exported );

			$query_args = $where_args;
			$query_args[] = $last_id;

			$query = $wpdb->prepare(
				"SELECT id, job_id, action, log_level, response_code, execution_time, request_payload, raw_response, created_at FROM `$lt` WHERE $where_sql AND id < %d ORDER BY id DESC LIMIT $current_batch_size",
				$query_args
			);

			$rows = $wpdb->get_results( $query, ARRAY_A );
			if ( empty( $rows ) ) { break; }

			foreach ( $rows as $l ) {
				$payload = isset( $l['request_payload'] ) ? maybe_unserialize( $l['request_payload'] ) : '';
				$response = isset( $l['raw_response'] ) ? maybe_unserialize( $l['raw_response'] ) : '';
				fputcsv( $output, [
					$l['id'],
					$l['job_id'] ?: '',
					$l['action'],
					$l['log_level'] ?? 'info',
					$l['response_code'],
					round( (float) $l['execution_time'], 3 ),
					$safe_encode( $payload ),
					$safe_encode( $response ),
					$l['created_at'],
				] );
				$last_id = (int) $l['id'];
				$total_exported++;
			}

			if ( ob_get_level() > 0 ) { ob_flush(); }
			flush();

			if ( count( $rows ) < $current_batch_size ) { break; }
		}

		fclose( $output );
		exit;
	}

	public function ajax_clear_logs() {
		check_ajax_referer( 'ai_collage_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( 'Insufficient permissions.' ); }

		global $wpdb;
		$wpdb->query( "TRUNCATE TABLE `{$this->logs_table()}`" );
		Logger::info( 'logs_cleared', null, [ 'cleared_by' => wp_get_current_user()->user_login ] );
		wp_send_json_success( [ 'message' => 'All logs cleared.' ] );
	}

	public function ajax_save_feeds() {
		check_ajax_referer( 'ai_collage_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( 'Insufficient permissions.' ); }

		$feeds_raw = isset( $_POST['feeds'] ) ? (array) $_POST['feeds'] : [];
		$clean = [];
		foreach ( $feeds_raw as $f ) {
			$feed_id = sanitize_text_field( $f['id'] ?? wp_generate_uuid4() );
			$existing = Config::get_rss_feed( $feed_id );
			$clean[] = [
				'id' => $feed_id,
				'name' => sanitize_text_field( $f['name'] ?? '' ),
				'url' => esc_url_raw( $f['url'] ?? '' ),
				'language' => in_array( $f['language'] ?? '', [ 'en', 'ur' ], true ) ? $f['language'] : 'en',
				'category' => sanitize_text_field( $f['category'] ?? '' ),
				'campaign_id' => sanitize_text_field( $f['campaign_id'] ?? '' ),
				'active' => ! empty( $f['active'] ),
				'last_poll' => $existing['last_poll'] ?? '',
				'last_poll_count' => (int) ( $existing['last_poll_count'] ?? 0 ),
			];
		}
		update_option( Config::OPTION_RSS_FEEDS, $clean );
		wp_send_json_success( $clean );
	}

	public function ajax_delete_feed() {
		check_ajax_referer( 'ai_collage_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( 'Insufficient permissions.' ); }

		$feed_id = sanitize_text_field( $_POST['feed_id'] ?? '' );
		if ( empty( $feed_id ) ) { wp_send_json_error( 'No feed ID provided.' ); }

		$feeds = Config::get_option_array( Config::OPTION_RSS_FEEDS, [] );
		$filtered = array_filter( $feeds, function ( $f ) use ( $feed_id ) { return ( $f['id'] ?? '' ) !== $feed_id; } );
		update_option( Config::OPTION_RSS_FEEDS, array_values( $filtered ) );
		wp_send_json_success( [ 'message' => 'Feed removed.' ] );
	}

	public function ajax_test_feed() {
		check_ajax_referer( 'ai_collage_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( 'Insufficient permissions.' ); }

		$url = esc_url_raw( $_POST['feed_url'] ?? '' );
		if ( empty( $url ) ) { wp_send_json_error( 'No feed URL provided.' ); }

		$result = FeedIngester::test_feed( $url );
		if ( $result['success'] ) {
			wp_send_json_success( $result );
		} else {
			wp_send_json_error( 'Feed test failed: ' . $result['error'] );
		}
	}

	public function ajax_poll_feed() {
		check_ajax_referer( 'ai_collage_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( 'Insufficient permissions.' ); }

		$feed_id = sanitize_text_field( $_POST['feed_id'] ?? '' );
		if ( empty( $feed_id ) ) { wp_send_json_error( 'No feed ID provided.' ); }

		$feed = Config::get_rss_feed( $feed_id );
		if ( ! $feed ) { wp_send_json_error( 'Feed not found.' ); }

		$feed['max_items'] = (int) get_option( Config::OPTION_RSS_MAX_PER_RUN, Config::RSS_DEFAULT_MAX_PER_RUN );
		$results = FeedIngester::ingest_feed( $feed );
		$count = count( $results );

		if ( $count > 0 ) {
			// Atomic per-feed option writes; mirrors CronScheduler::update_feed_last_poll
			// and removes the GET-MODIFY-SAVE race on OPTION_RSS_FEEDS.
			update_option( 'ai_collage_feed_last_poll_' . sanitize_key( (string) $feed_id ), gmdate( 'Y-m-d H:i:s' ), false );
			update_option( 'ai_collage_feed_last_poll_count_' . sanitize_key( (string) $feed_id ), (int) $count, false );
		}

		wp_send_json_success( [ 'message' => "Ingested {$count} items from feed.", 'ingested' => $count ] );
	}

	public function ajax_save_rss_settings() {
		check_ajax_referer( 'ai_collage_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( 'Insufficient permissions.' ); }

		$enabled = ! empty( $_POST['rss_enabled'] );
		$frequency = (int) ( $_POST['rss_frequency'] ?? Config::RSS_DEFAULT_FREQUENCY );
		$max_per_run = max( 1, min( 50, (int) ( $_POST['rss_max_per_run'] ?? Config::RSS_DEFAULT_MAX_PER_RUN ) ) );

		update_option( Config::OPTION_RSS_ENABLED, $enabled );
		update_option( Config::OPTION_RSS_FREQUENCY, Config::is_valid_rss_frequency( $frequency ) ? $frequency : Config::RSS_DEFAULT_FREQUENCY );
		update_option( Config::OPTION_RSS_MAX_PER_RUN, $max_per_run );

		if ( $enabled && function_exists( 'as_next_scheduled_action' ) && function_exists( 'as_schedule_recurring_action' ) ) {
			if ( ! as_next_scheduled_action( Config::ACTION_POLL_FEEDS, [], Config::AS_GROUP ) ) {
				as_schedule_recurring_action(
					time(),
					$frequency,
					Config::ACTION_POLL_FEEDS,
					[],
					Config::AS_GROUP
				);
			}
		}
		if ( ! $enabled && function_exists( 'as_unschedule_action' ) ) {
			as_unschedule_action( Config::ACTION_POLL_FEEDS, [], Config::AS_GROUP );
		}

		wp_send_json_success( [ 'message' => 'RSS settings saved.' ] );
	}

	public function ajax_stop_campaign() {
		check_ajax_referer( 'ai_collage_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( 'Insufficient permissions.' ); }

		$campaign_id = sanitize_text_field( $_POST['campaign_id'] ?? '' );
		if ( empty( $campaign_id ) ) { wp_send_json_error( 'No campaign ID provided.' ); }

		$campaigns = Config::get_option_array( Config::OPTION_CAMPAIGNS, [] );
		$found = false;
		foreach ( $campaigns as &$c ) {
			if ( $c['id'] === $campaign_id ) {
				$c['stopped'] = true;
				$c['active'] = false;
				$found = true;
				break;
			}
		}
		unset( $c );

		if ( ! $found ) { wp_send_json_error( 'Campaign not found.' ); }

		update_option( Config::OPTION_CAMPAIGNS, $campaigns );
		Logger::info( Config::LOG_ACTION_CAMPAIGN_STOPPED, null, [ 'campaign_id' => $campaign_id, 'stopped_by' => wp_get_current_user()->user_login ], '200' );
		wp_send_json_success( [ 'message' => 'Campaign stopped.', 'campaign_id' => $campaign_id ] );
	}

	public function ajax_stop_all_campaigns() {
		check_ajax_referer( 'ai_collage_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( 'Insufficient permissions.' ); }

		$campaigns = Config::get_option_array( Config::OPTION_CAMPAIGNS, [] );
		$stopped_count = 0;
		foreach ( $campaigns as &$c ) {
			if ( ! empty( $c['active'] ) && empty( $c['stopped'] ) ) {
				$c['stopped'] = true;
				$c['active'] = false;
				$stopped_count++;
			}
		}
		unset( $c );

		update_option( Config::OPTION_CAMPAIGNS, $campaigns );
		Logger::info( Config::LOG_ACTION_CAMPAIGN_STOPPED, null, [ 'stopped_all' => true, 'count' => $stopped_count, 'stopped_by' => wp_get_current_user()->user_login ], '200' );
		wp_send_json_success( [ 'message' => sprintf( '%d campaign(s) stopped.', $stopped_count ), 'stopped_count' => $stopped_count ] );
	}

	public function ajax_test_custom_provider() {
		check_ajax_referer( 'ai_collage_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( 'Insufficient permissions.' ); }

		$provider_json = isset( $_POST['providers_json'] ) ? wp_unslash( $_POST['providers_json'] ) : '';
		$provider_id = sanitize_key( $_POST['provider_id'] ?? '' );
		if ( empty( $provider_id ) ) { wp_send_json_error( 'No provider ID provided.' ); }

		$providers = json_decode( $provider_json, true );
		if ( ! is_array( $providers ) ) {
			wp_send_json_error( 'Invalid provider data.' );
		}

		$profile = null;
		foreach ( $providers as $p ) {
			if ( ( $p['id'] ?? '' ) === $provider_id ) {
				$profile = $p;
				break;
			}
		}

		if ( ! $profile ) {
			wp_send_json_error( 'Provider profile not found.' );
		}

		$validated = Config::validate_custom_profile( $profile );
		if ( $validated === null ) {
			wp_send_json_error( 'Invalid provider profile. Check that API URL (https://) and at least one model are configured.' );
		}

		try {
			$api_key = $validated['api_key'] ?? '';
			if ( empty( $api_key ) ) {
				wp_send_json_error( 'API key is required.' );
			}
			$provider = new CustomProvider( $api_key, $validated, $provider_id );
			$result = $provider->test_connection();
			if ( $result['success'] ) {
				wp_send_json_success( $result );
			} else {
				wp_send_json_error( $result['error'] );
			}
		} catch ( \Exception $e ) {
			wp_send_json_error( $e->getMessage() );
		}
	}

	public function ajax_pause_pipeline() {
		check_ajax_referer( 'ai_collage_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( 'Insufficient permissions.' ); }
		update_option( Config::OPTION_PIPELINE_PAUSED, true );
		if ( function_exists( 'wp_cache_delete' ) ) { wp_cache_delete( 'alloptions', 'options' ); }
		Logger::info( Config::LOG_ACTION_PIPELINE_PAUSED, null, [ 'paused_by' => wp_get_current_user()->user_login ], '200' );
		wp_send_json_success( [ 'message' => 'Pipeline paused.' ] );
	}

	public function ajax_resume_pipeline() {
		check_ajax_referer( 'ai_collage_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( 'Insufficient permissions.' ); }
		update_option( Config::OPTION_PIPELINE_PAUSED, false );
		if ( function_exists( 'wp_cache_delete' ) ) { wp_cache_delete( 'alloptions', 'options' ); }
		$stuck_count = JobManager::mark_stuck_jobs_failed( 30 );
		if ( $stuck_count > 0 ) {
			Logger::info( Config::LOG_ACTION_STUCK_JOB_FAILED, null, [ 'count' => $stuck_count, 'resumed_by' => wp_get_current_user()->user_login ], '200' );
		}

		global $wpdb;
		$job_table = $wpdb->prefix . Config::TABLE_JOBS;
		$orphaned_jobs = $wpdb->get_results( "SELECT id, post_id FROM `$job_table` WHERE status IN ('pending','rewriting','rendering','scheduled')" );
		$reenqueued = 0;
		foreach ( $orphaned_jobs as $ojob ) {
			delete_post_meta( (int) $ojob->post_id, '_ai_collage_job_created' );
			delete_post_meta( (int) $ojob->post_id, Config::META_CAMPAIGN_DATA );
			delete_transient( 'ai_collage_queued_recent_' . (int) $ojob->post_id );
			delete_transient( 'ai_collage_job_lock_' . (int) $ojob->id );
			JobManager::update_status( (int) $ojob->id, Config::STATUS_PENDING );
			if ( function_exists( 'as_schedule_single_action' ) ) {
				if ( \AiSocialCollage\Actions\QueueProcessor::check_pending_action_for_job( (int) $ojob->id ) ) { continue; }
				$action_id = as_schedule_single_action( time(), Config::ACTION_PROCESS_JOB, [ 'job_id' => (int) $ojob->id ], Config::AS_GROUP );
				if ( $action_id ) {
					$reenqueued++;
					Logger::info( 'job_reenqueued_after_resume', (int) $ojob->id, [ 'post_id' => (int) $ojob->post_id ], '200' );
				}
			}
		}

		Logger::info( Config::LOG_ACTION_PIPELINE_RESUMED, null, [ 'resumed_by' => wp_get_current_user()->user_login, 'stuck_failed' => $stuck_count, 'reenqueued' => $reenqueued ], '200' );
		wp_send_json_success( [ 'message' => 'Pipeline resumed. ' . $stuck_count . ' stuck job(s) marked as failed, ' . $reenqueued . ' orphaned job(s) re-enqueued.' ] );
	}

	public function ajax_toggle_health_monitor_forced_run() {
		check_ajax_referer( 'ai_collage_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( 'Insufficient permissions.' ); }
		$enabled = isset( $_POST['enabled'] ) && $_POST['enabled'] === '1';
		delete_option( Config::OPTION_HEALTH_MONITOR_FORCED_RUN );
		update_option( Config::OPTION_HEALTH_MONITOR_FORCED_RUN, $enabled ? '1' : '0', false );
		if ( function_exists( 'wp_cache_delete' ) ) { wp_cache_delete( 'alloptions', 'options' ); }
		Logger::info( 'health_monitor_forced_run_toggled', null, [ 'enabled' => $enabled, 'toggled_by' => wp_get_current_user()->user_login ], '200' );
		wp_send_json_success( [ 'message' => $enabled ? 'Forced queue run enabled.' : 'Forced queue run disabled.', 'enabled' => $enabled ] );
	}

	public function ajax_clear_stuck_jobs() {
		check_ajax_referer( 'ai_collage_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( 'Insufficient permissions.' ); }
		$count = JobManager::mark_stuck_jobs_failed( 15 );
		$pipeline_was_paused = (bool) get_option( Config::OPTION_PIPELINE_PAUSED, false );
		if ( $pipeline_was_paused ) {
			update_option( Config::OPTION_PIPELINE_PAUSED, false );
			if ( function_exists( 'wp_cache_delete' ) ) { wp_cache_delete( 'alloptions', 'options' ); }
			Logger::info( Config::LOG_ACTION_PIPELINE_RESUMED, null, [ 'resumed_by' => 'ajax_clear_stuck_jobs' ], '200' );
		}

		global $wpdb;
		$job_table = $wpdb->prefix . Config::TABLE_JOBS;
		$orphaned_jobs = $wpdb->get_results( "SELECT id, post_id FROM `$job_table` WHERE status IN ('pending','rewriting','rendering','scheduled')" );
		$reenqueued = 0;
		foreach ( $orphaned_jobs as $ojob ) {
			delete_post_meta( (int) $ojob->post_id, '_ai_collage_job_created' );
			delete_transient( 'ai_collage_queued_recent_' . (int) $ojob->post_id );
			delete_transient( 'ai_collage_job_lock_' . (int) $ojob->id );
			JobManager::update_status( (int) $ojob->id, Config::STATUS_PENDING );
			if ( function_exists( 'as_schedule_single_action' ) ) {
				if ( \AiSocialCollage\Actions\QueueProcessor::check_pending_action_for_job( (int) $ojob->id ) ) { continue; }
				$action_id = as_schedule_single_action( time(), Config::ACTION_PROCESS_JOB, [ 'job_id' => (int) $ojob->id ], Config::AS_GROUP );
				if ( $action_id ) {
					$reenqueued++;
					Logger::info( 'job_reenqueued_after_clear_stuck', (int) $ojob->id, [ 'post_id' => (int) $ojob->post_id ], '200' );
				}
			}
		}

		Logger::info( Config::LOG_ACTION_STUCK_JOB_FAILED, null, [ 'count' => $count, 'cleared_by' => wp_get_current_user()->user_login ], '200' );
		wp_send_json_success( [ 'message' => 'System Health Restored! ' . $count . ' stuck job(s) resolved, ' . $reenqueued . ' orphan(s) re-enqueued, and global queue locks were cleared.' . ( $pipeline_was_paused ? ' Pipeline was paused; auto-resumed.' : '' ), 'count' => $count, 'reenqueued' => $reenqueued, 'pipeline_resumed' => $pipeline_was_paused ] );
	}

	public function ajax_force_recover_jobs() {
		check_ajax_referer( 'ai_collage_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( 'Insufficient permissions.' ); }

		$monitor = \AiSocialCollage\Services\QueueHealthMonitor::instance();
		$recovered = $monitor->force_recover_stuck_jobs();

		$stuck_claims = 0;
		if ( function_exists( 'as_has_scheduled_action' ) ) {
			global $wpdb;
			$as_table = $wpdb->prefix . 'actionscheduler_actions';
			if ( $wpdb->get_var( "SHOW TABLES LIKE '$as_table'" ) === $as_table ) {
				$stuck_claims = (int) $wpdb->query( $wpdb->prepare(
					"UPDATE `$as_table` SET status = 'pending', attempts = 0 WHERE status = 'in-progress' AND hook = %s AND last_attempt_gmt < DATE_SUB(UTC_TIMESTAMP(), INTERVAL 3 MINUTE)",
					Config::ACTION_PROCESS_JOB
				) );
			}
		}

		$pipeline_was_paused = (bool) get_option( Config::OPTION_PIPELINE_PAUSED, false );
		if ( $pipeline_was_paused ) {
			update_option( Config::OPTION_PIPELINE_PAUSED, false );
			if ( function_exists( 'wp_cache_delete' ) ) { wp_cache_delete( 'alloptions', 'options' ); }
		}

		$msg = 'Force recovery complete! ' . $recovered . ' stuck job(s) marked FAILED';
		if ( $stuck_claims > 0 ) {
			$msg .= ', ' . $stuck_claims . ' stuck claim(s) reset to pending';
		}
		$msg .= '.' . ( $pipeline_was_paused ? ' Pipeline was paused; auto-resumed.' : '' );

		Logger::info( 'force_recover_jobs_ajax', null, [
			'recovered'   => $recovered,
			'claims'      => $stuck_claims,
			'performed_by' => wp_get_current_user()->user_login,
		], '200' );

		wp_send_json_success( [ 'message' => $msg, 'recovered' => $recovered, 'claims' => $stuck_claims, 'pipeline_resumed' => $pipeline_was_paused ] );
	}

	public function ajax_sync_openrouter_models() {
		check_ajax_referer( 'ai_collage_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( 'Insufficient permissions.' ); }

		try {
			$result = OpenRouterModelSync::sync();
			if ( $result['success'] ) {
				wp_send_json_success( $result );
			} else {
				wp_send_json_error( $result['message'] );
			}
		} catch ( \Exception $e ) {
			wp_send_json_error( 'Sync failed: ' . $e->getMessage() );
		}
	}

	public function ajax_sync_zen_models() {
		check_ajax_referer( 'ai_collage_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( 'Insufficient permissions.' ); }

		try {
			$result = OpenCodeZenModelSync::sync();
			if ( $result['success'] ) {
				wp_send_json_success( $result );
			} else {
				wp_send_json_error( $result['message'] );
			}
		} catch ( \Exception $e ) {
			wp_send_json_error( 'Sync failed: ' . $e->getMessage() );
		}
	}

	public function ajax_test_r2_connection() {
		check_ajax_referer( 'ai_collage_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( 'Insufficient permissions.' ); }

		if ( ! class_exists( 'AiSocialCollage\Services\R2Storage' ) ) {
			wp_send_json_error( 'R2Storage class not found.' );
		}

		$r2 = new \AiSocialCollage\Services\R2Storage();
		$result = $r2->test_connection();

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( $result->get_error_message() );
		}

		wp_send_json_success( [ 'message' => 'R2 connection test successful!' ] );
	}

	public function ajax_reset_system() {
		check_ajax_referer( 'ai_collage_nonce', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) { wp_send_json_error( 'Insufficient permissions.' ); }

		try {
			global $wpdb;

			$stuck_count = JobManager::mark_stuck_jobs_failed( 15 );

			$as_table = $wpdb->prefix . 'actionscheduler_actions';
			$deleted = (int) $wpdb->query( $wpdb->prepare(
				"DELETE FROM `$as_table` WHERE hook = %s AND status IN ('pending','in-progress','failed')",
				Config::ACTION_PROCESS_JOB
			) );

			delete_transient( 'action_scheduler_run_queue' );

			\AiSocialCollage\Services\ProviderCooldown::reset_all();
			\AiSocialCollage\Services\QuotaStateManager::reset_all();

			$misconfig_preserved = 0;
			$all_providers = \AiSocialCollage\Config::get_registered_providers();
			foreach ( $all_providers as $pname => $_plabel ) {
				if ( \AiSocialCollage\Config::has_valid_api_key( $pname ) ) {
					continue;
				}
				\AiSocialCollage\Services\ProviderCooldown::mark_misconfigured( $pname );
				$misconfig_preserved++;
			}
			if ( $misconfig_preserved > 0 ) {
				Logger::warning( 'reset_preserved_misconfigured', null, [
					'count' => $misconfig_preserved,
					'note' => 'Providers without valid API keys re-marked as misconfigured after reset',
				] );
			}

			$pipeline_was_paused = (bool) get_option( Config::OPTION_PIPELINE_PAUSED, false );
			if ( $pipeline_was_paused ) {
				update_option( Config::OPTION_PIPELINE_PAUSED, false );
				if ( function_exists( 'wp_cache_delete' ) ) { wp_cache_delete( 'alloptions', 'options' ); }
			}

			$locks_deleted = 0;
			$reenqueued = 0;
			$meta_cleared = 0;
			$job_table = $wpdb->prefix . Config::TABLE_JOBS;
			$jobs_with_post = $wpdb->get_results( "SELECT id, post_id FROM `$job_table` WHERE status IN ('pending','rewriting','rendering','scheduled')" );
			foreach ( $jobs_with_post as $jp ) {
				delete_transient( 'ai_collage_job_lock_' . (int) $jp->id );
				delete_transient( 'ai_collage_queued_recent_' . (int) $jp->post_id );
				$locks_deleted++;
			}

			$wpdb->query( "DELETE FROM `{$wpdb->options}` WHERE option_name LIKE '_transient_ai_collage_queued_recent_%' OR option_name LIKE '_transient_timeout_ai_collage_queued_recent_%'" );

			$recoverable_jobs = $wpdb->get_results( "SELECT id, post_id FROM `$job_table` WHERE status IN ('pending','rewriting','rendering','scheduled')" );
			foreach ( $recoverable_jobs as $rjob ) {
				if ( function_exists( 'as_schedule_single_action' ) ) {
					if ( \AiSocialCollage\Actions\QueueProcessor::check_pending_action_for_job( (int) $rjob->id ) ) { continue; }
					$action_id = as_schedule_single_action( time(), Config::ACTION_PROCESS_JOB, [ 'job_id' => (int) $rjob->id ], Config::AS_GROUP );
					if ( $action_id ) {
						$wpdb->update( $job_table, [ 'updated_at' => gmdate( 'Y-m-d H:i:s' ) ], [ 'id' => (int) $rjob->id ], [ '%s' ], [ '%d' ] );
						$reenqueued++;
						Logger::info( 'job_reenqueued_after_reset', (int) $rjob->id, [ 'post_id' => (int) $rjob->post_id ], '200' );
					}
				}
			}

			$failed_posts = $wpdb->get_results( "SELECT id, post_id FROM `$job_table` WHERE status IN ('failed','discarded')" );
			foreach ( $failed_posts as $fjob ) {
				delete_post_meta( (int) $fjob->post_id, '_ai_collage_job_created' );
				delete_post_meta( (int) $fjob->post_id, Config::META_CAMPAIGN_DATA );
				delete_post_meta( (int) $fjob->post_id, Config::META_PREPROCESSED_IMAGE );
				$meta_cleared++;
			}

			Logger::info( 'system_reset_executed', null, [
				'stuck_failed'  => $stuck_count,
				'as_deleted'    => $deleted,
				'locks_cleared' => $locks_deleted,
				'reenqueued'    => $reenqueued,
				'meta_cleared'  => $meta_cleared,
				'reset_by'      => wp_get_current_user()->user_login,
			], '200' );

			$as_part = $deleted > 0
				? "{$deleted} AS action(s) deleted"
				: '0 pending AS actions (queue already clean)';
			wp_send_json_success( [
				'message' => "System reset complete. {$stuck_count} stuck job(s) failed, {$as_part}, {$locks_deleted} lock(s) cleared, {$reenqueued} job(s) re-enqueued, {$meta_cleared} stale meta cleared, cooldowns & quota state reset."
			] );
		} catch ( \Throwable $e ) {
			wp_send_json_error( 'Reset failed: ' . $e->getMessage() );
		}
	}

	public function ajax_delete_buffer_drafts() {
		check_ajax_referer( 'nm_delete_buffer_drafts', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Insufficient permissions.' );
		}

		$result = \AiSocialCollage\Services\BufferIntegration::delete_all_buffer_drafts();
		$deleted = $result['deleted'];
		$failed = $result['failed'];
		$total = $result['total'];

		$message = $deleted . ' Buffer draft(s) deleted.';
		if ( $failed > 0 ) {
			$message .= ' ' . $failed . ' failed to delete.';
		}
		if ( $total === 0 ) {
			$message = 'No Buffer drafts found to delete.';
		}

		wp_send_json_success( [ 'message' => $message, 'deleted' => $deleted, 'failed' => $failed, 'total' => $total ] );
	}

	public function render_chromium_health_notice() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$screen = get_current_screen();
		if ( $screen && strpos( $screen->id, 'ai-social-collage' ) !== false ) {
			return;
		}

		$health = Config::check_chromium_health();
		if ( $health['all_available'] ) {
			return;
		}

		$missing = [];
		$labels = [ 'exec' => 'PHP exec()', 'node' => 'Node.js', 'render_script' => 'Render script', 'chromium' => 'Chromium browser', 'puppeteer' => 'puppeteer-core module' ];
		foreach ( $labels as $key => $label ) {
			if ( ! $health[ $key ] ) {
				$missing[] = $label;
			}
		}
		?>
		<div class="notice notice-warning">
			<p><strong>AI Social Collage Pro:</strong> Chromium rendering dependencies missing â€”
			<?php echo esc_html( implode( ', ', $missing ) ); ?>.
			Headless browser rendering will fall back to Pango/GD.
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=ai-social-collage' ) ); ?>">View System Health</a></p>
		</div>
		<?php
	}

	private function sanitize_zone_config( array $c, string $prefix, array $defaults ): array {
		if ( isset( $c[ $prefix ] ) && is_array( $c[ $prefix ] ) ) {
			$zone = $c[ $prefix ];
			return [
				'x' => max( 0.0, min( 1.0, (float) ( $zone['x'] ?? $defaults['x'] ) ) ),
				'y' => max( 0.0, min( 1.0, (float) ( $zone['y'] ?? $defaults['y'] ) ) ),
				'w' => max( 0.01, min( 1.0, (float) ( $zone['w'] ?? $defaults['w'] ) ) ),
				'h' => max( 0.01, min( 1.0, (float) ( $zone['h'] ?? $defaults['h'] ) ) ),
			];
		}

		// Video content zone: new Top/Right/Bottom/Left crop inputs → x/y/w/h
		if ( $prefix === 'video_content_zone' && isset( $c[ $prefix . '_top' ] ) ) {
			$top    = max( 0.0, min( 0.95, (float) ( $c[ $prefix . '_top' ] ?? 0 ) ) );
			$right  = max( 0.0, min( 0.95, (float) ( $c[ $prefix . '_right' ] ?? 0 ) ) );
			$bottom = max( 0.0, min( 0.95, (float) ( $c[ $prefix . '_bottom' ] ?? 0 ) ) );
			$left   = max( 0.0, min( 0.95, (float) ( $c[ $prefix . '_left' ] ?? 0 ) ) );
			// Clamp so left + right < 1.0 and top + bottom < 1.0
			if ( $left + $right >= 1.0 ) { $left = 0.0; $right = 0.0; }
			if ( $top + $bottom >= 1.0 ) { $top = 0.0; $bottom = 0.0; }
			return [
				'x' => $left,
				'y' => $top,
				'w' => max( 0.01, 1.0 - $left - $right ),
				'h' => max( 0.01, 1.0 - $top - $bottom ),
			];
		}

		$x_key = $prefix . '_x';
		$y_key = $prefix . '_y';
		$w_key = $prefix . '_w';
		$h_key = $prefix . '_h';

		if ( isset( $c[ $x_key ] ) ) {
			return [
				'x' => max( 0.0, min( 1.0, (float) ( $c[ $x_key ] ?? $defaults['x'] ) ) ),
				'y' => max( 0.0, min( 1.0, (float) ( $c[ $y_key ] ?? $defaults['y'] ) ) ),
				'w' => max( 0.01, min( 1.0, (float) ( $c[ $w_key ] ?? $defaults['w'] ) ) ),
				'h' => max( 0.01, min( 1.0, (float) ( $c[ $h_key ] ?? $defaults['h'] ) ) ),
			];
		}

		return $defaults;
	}
}
