<?php

/**
 * Mock Exam Feature
 *
 * Creates a professional mock exam interface with timer, progress tracking,
 * and results analysis. Stores results to database for logged-in users.
 *
 * @since 7.3.8
 * @package WP_News_MCQ_Generator
 */

if (! defined('ABSPATH')) {
	exit;
}

class NM_Mock_Exam
{


	/**
	 * Initialize the mock exam feature
	 */
	public static function init()
	{
		// Register shortcode
		add_shortcode('nm_mock_exam', array(self::class, 'render_shortcode'));

		// Enqueue assets
		add_action('wp_enqueue_scripts', array(self::class, 'enqueue_exam_assets'));

		// AJAX handlers
		add_action('wp_ajax_nm_save_exam_result', array(self::class, 'save_exam_result'));
		add_action('wp_ajax_nopriv_nm_save_exam_result', array(self::class, 'save_exam_result_guest'));
		add_action('wp_ajax_nm_get_exam_history', array(self::class, 'get_exam_history'));

		// Create database table on activation
		register_activation_hook(__FILE__, array(self::class, 'create_exam_table'));
	}

	/**
	 * Create database table for exam results
	 */
	public static function create_exam_table()
	{
		global $wpdb;
		$table_name      = $wpdb->prefix . 'nm_exam_results';
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) DEFAULT NULL,
            exam_type varchar(100) NOT NULL,
            topic_slugs text DEFAULT NULL,
            total_questions int NOT NULL,
            correct_answers int NOT NULL,
            score_percentage decimal(5,2) NOT NULL,
            time_taken int DEFAULT NULL,
            completed_at datetime NOT NULL,
            answers_data longtext DEFAULT NULL,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY completed_at (completed_at)
        ) $charset_collate;";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta($sql);
	}

	/**
	 * Enqueue CSS and JS for mock exam
	 */
	public static function enqueue_exam_assets()
	{
		// Only enqueue if shortcode is present
		global $post;
		if (is_a($post, 'WP_Post') && has_shortcode($post->post_content, 'nm_mock_exam')) {
			wp_enqueue_style(
				'nm-mock-exam',
				NM_PLUGIN_URL . 'assets/css/mock-exam.css',
				array(),
				filemtime(NM_PLUGIN_PATH . 'assets/css/mock-exam.css')
			);

			wp_enqueue_script(
				'nm-mock-exam',
				NM_PLUGIN_URL . 'assets/js/mock-exam.js',
				array('jquery'),
				filemtime(NM_PLUGIN_PATH . 'assets/js/mock-exam.js'),
				true
			);

			wp_localize_script(
				'nm-mock-exam',
				'nmExamData',
				array(
					'ajaxurl'    => admin_url('admin-ajax.php'),
					'nonce'      => wp_create_nonce('nm_exam_nonce'),
					'isLoggedIn' => is_user_logged_in(),
				)
			);
		}
	}

	/**
	 * Render the mock exam shortcode
	 *
	 * @param array $atts Shortcode attributes
	 * @return string HTML output
	 */
	public static function render_shortcode($atts)
	{
		$atts = shortcode_atts(
			array(
				'topic'         => '',
				'questions'     => 25,
				'time_limit'    => 30,
				'difficulty'    => 'mixed',
				'passing_score' => 70,
				'title'         => 'Mock Examination',
			),
			$atts
		);

		// Get exam questions
		$questions = self::get_exam_questions($atts);

		if (empty($questions)) {
			return '<div class="nm-exam-error">No questions available for this exam configuration.</div>';
		}

		ob_start();
?>
		<div id="nm-mock-exam-container"
			data-questions='<?php echo htmlspecialchars(json_encode($questions), ENT_QUOTES, 'UTF-8'); ?>'
			data-time-limit="<?php echo esc_attr($atts['time_limit']); ?>"
			data-passing-score="<?php echo esc_attr($atts['passing_score']); ?>"
			data-topic="<?php echo esc_attr($atts['topic']); ?>">

			<!-- Start Screen -->
			<div id="nm-exam-start-screen" class="nm-exam-screen active">
				<div class="nm-exam-header">
					<h1><?php echo esc_html($atts['title']); ?></h1>
					<div class="nm-exam-info">
						<div class="nm-exam-info-item">
							<span class="nm-exam-icon">📝</span>
							<div>
								<strong><?php echo count($questions); ?> Questions</strong>
								<p>Multiple Choice</p>
							</div>
						</div>
						<div class="nm-exam-info-item">
							<span class="nm-exam-icon">⏱️</span>
							<div>
								<strong><?php echo $atts['time_limit']; ?> Minutes</strong>
								<p>Time Limit</p>
							</div>
						</div>
						<div class="nm-exam-info-item">
							<span class="nm-exam-icon">🎯</span>
							<div>
								<strong><?php echo $atts['passing_score']; ?>% to Pass</strong>
								<p>Passing Score</p>
							</div>
						</div>
					</div>
				</div>
				<div class="nm-exam-instructions">
					<h3>Instructions</h3>
					<ul>
						<li>Read each question carefully before selecting your answer</li>
						<li>You can navigate between questions using Next/Previous buttons</li>
						<li>Review and change answers before final submission</li>
						<li>Timer will start when you click "Start Exam"</li>
						<li><?php echo is_user_logged_in() ? 'Your results will be saved to your account' : 'Login to save your exam results'; ?></li>
					</ul>
				</div>
				<button id="nm-start-exam-btn" class="nm-exam-btn-primary">Start Exam</button>
			</div>

			<!-- Exam Screen -->
			<div id="nm-exam-question-screen" class="nm-exam-screen">
				<div class="nm-exam-top-bar">
					<div class="nm-exam-timer">
						<span class="nm-timer-icon">⏱️</span>
						<span id="nm-exam-timer-display">00:00</span>
					</div>
					<div class="nm-exam-progress">
						<span id="nm-exam-current-q">1</span> / <span id="nm-exam-total-q"><?php echo count($questions); ?></span>
					</div>
				</div>

				<div id="nm-exam-question-container" class="nm-exam-question-wrapper">
					<!-- Questions will be dynamically loaded here -->
				</div>

				<div class="nm-exam-navigation">
					<button id="nm-exam-prev-btn" class="nm-exam-btn-secondary" disabled>← Previous</button>
					<button id="nm-exam-flag-btn" class="nm-exam-btn-flag">🚩 Flag</button>
					<button id="nm-exam-next-btn" class="nm-exam-btn-secondary">Next →</button>
					<button id="nm-exam-submit-btn" class="nm-exam-btn-primary" style="display: none;">Submit Exam</button>
				</div>
			</div>

			<!-- Results Screen -->
			<div id="nm-exam-results-screen" class="nm-exam-screen">
				<div class="nm-exam-results-header">
					<h2>Exam Results</h2>
					<div id="nm-exam-score-display" class="nm-score-circle">
						<div class="nm-score-percentage">0%</div>
						<div class="nm-score-label">Score</div>
					</div>
					<div id="nm-exam-pass-status" class="nm-pass-status"></div>
				</div>

				<div class="nm-exam-stats">
					<div class="nm-exam-stat">
						<span class="nm-stat-value" id="nm-stat-correct">0</span>
						<span class="nm-stat-label">Correct</span>
					</div>
					<div class="nm-exam-stat">
						<span class="nm-stat-value" id="nm-stat-incorrect">0</span>
						<span class="nm-stat-label">Incorrect</span>
					</div>
					<div class="nm-exam-stat">
						<span class="nm-stat-value" id="nm-stat-time">0:00</span>
						<span class="nm-stat-label">Time Taken</span>
					</div>
				</div>

				<div id="nm-exam-review-container" class="nm-exam-review">
					<!-- Review will be dynamically loaded here -->
				</div>

				<div class="nm-exam-actions">
					<button id="nm-exam-retry-btn" class="nm-exam-btn-primary">Retry Exam</button>
					<button id="nm-exam-share-btn" class="nm-exam-btn-secondary">Share Results</button>
				</div>
			</div>
		</div>
<?php
		return ob_get_clean();
	}

	/**
	 * Get questions for the exam based on criteria
	 *
	 * @param array $atts Exam attributes
	 * @return array Array of question objects
	 */
	private static function get_exam_questions($atts)
	{
		$args = array(
			'post_type'      => 'mcq',
			'post_status'    => 'publish',
			'posts_per_page' => (int) $atts['questions'],
			'orderby'        => 'rand',
		);

		// Filter by topic if specified
		if (! empty($atts['topic'])) {
			$topics            = array_map('trim', explode(',', $atts['topic']));
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'topic',
					'field'    => 'slug',
					'terms'    => $topics,
				),
			);
		}

		// Filter by difficulty if specified
		if ($atts['difficulty'] !== 'mixed') {
			$args['meta_query'] = array(
				array(
					'key'     => 'mcq_difficulty',
					'value'   => $atts['difficulty'],
					'compare' => '=',
				),
			);
		}

		$query     = new WP_Query($args);
		$questions = array();

		if ($query->have_posts()) {
			while ($query->have_posts()) {
				$query->the_post();
				$post_id = get_the_ID();

				$questions[] = array(
					'id'          => $post_id,
					'question'    => get_the_title(),
					'options'     => get_post_meta($post_id, 'mcq_options', true),
					'answer'      => get_post_meta($post_id, 'mcq_answer', true),
					'explanation' => get_post_meta($post_id, 'mcq_explanation', true),
				);
			}
			wp_reset_postdata();
		}

		return $questions;
	}

	/**
	 * Save exam result (AJAX handler for logged-in users)
	 */
	public static function save_exam_result()
	{
		check_ajax_referer('nm_exam_nonce', 'nonce');

		if (! is_user_logged_in()) {
			wp_send_json_error(array('message' => 'You must be logged in to save results'));
			return;
		}

		$user_id = get_current_user_id();
		$data    = array(
			'user_id'          => $user_id,
			'exam_type'        => sanitize_text_field($_POST['exam_type'] ?? 'general'),
			'topic_slugs'      => sanitize_text_field($_POST['topics'] ?? ''),
			'total_questions'  => (int) ($_POST['total'] ?? 0),
			'correct_answers'  => (int) ($_POST['correct'] ?? 0),
			'score_percentage' => (float) ($_POST['percentage'] ?? 0),
			'time_taken'       => (int) ($_POST['time_taken'] ?? 0),
			'completed_at'     => current_time('mysql'),
			'answers_data'     => wp_json_encode($_POST['answers'] ?? array()),
		);

		global $wpdb;
		$table  = $wpdb->prefix . 'nm_exam_results';
		$result = $wpdb->insert($table, $data);

		if ($result) {
			wp_send_json_success(
				array(
					'message'   => 'Result saved successfully',
					'result_id' => $wpdb->insert_id,
				)
			);
		} else {
			wp_send_json_error(array('message' => 'Failed to save result'));
		}
	}

	/**
	 * Handle exam results for non-logged-in users
	 */
	public static function save_exam_result_guest()
	{
		// For guests, we just return success without saving to database
		wp_send_json_success(array('message' => 'Login to save your results permanently'));
	}

	/**
	 * Get exam history for current user
	 */
	public static function get_exam_history()
	{
		check_ajax_referer('nm_exam_nonce', 'nonce');

		if (! is_user_logged_in()) {
			wp_send_json_error(array('message' => 'Not logged in'));
			return;
		}

		global $wpdb;
		$user_id = get_current_user_id();
		$table   = $wpdb->prefix . 'nm_exam_results';

		$results = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM $table WHERE user_id = %d ORDER BY completed_at DESC LIMIT 10",
				$user_id
			),
			ARRAY_A
		);

		wp_send_json_success($results);
	}
}
?>