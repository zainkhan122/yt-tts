<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OpenRouterModelSync {

	const API_URL = 'https://openrouter.ai/api/v1/models';
	const SYNC_WINDOW_DAYS = 3;

	private static $BLOCKED_MODALITIES = [ 'audio', 'image', 'video', 'embeddings' ];

	private static $BLOCKED_MODEL_PREFIXES = [
		'google/lyria',
		'google/imagen',
		'openai/dall-e',
		'stable-diffusion',
		'midjourney',
	];

	public static function sync(): array {
		$providers = Config::get_custom_providers();
		if ( empty( $providers ) ) {
			return [ 'success' => false, 'message' => 'No custom providers configured.' ];
		}

		$or_provider = null;
		$or_index = -1;
		foreach ( $providers as $i => $p ) {
			$url = $p['api_url'] ?? '';
			if ( strpos( $url, 'openrouter.ai' ) !== false ) {
				$or_provider = $p;
				$or_index = $i;
				break;
			}
		}

		if ( $or_provider === null ) {
			return [ 'success' => false, 'message' => 'No OpenRouter custom provider found (URL must contain openrouter.ai).' ];
		}

		$api_models = self::fetch_free_models();
		if ( $api_models === null ) {
			return [ 'success' => false, 'message' => 'Failed to fetch models from OpenRouter API.' ];
		}

		if ( empty( $api_models ) ) {
			return [ 'success' => false, 'message' => 'No free models returned from OpenRouter API.' ];
		}

		$current_models = $or_provider['models'] ?? [];
		$current_ids = array_column( $current_models, 'model_id' );

		$api_ids = array_column( $api_models, 'model_id' );

		$added = [];
		$removed = [];
		$expiring = [];

		$future_cutoff = time() + ( self::SYNC_WINDOW_DAYS * DAY_IN_SECONDS );

		foreach ( $current_models as $m ) {
			$mid = $m['model_id'] ?? '';
			if ( $mid === '' ) {
				continue;
			}
			if ( ! in_array( $mid, $api_ids, true ) ) {
				$removed[] = $mid;
				continue;
			}
			foreach ( $api_models as $am ) {
				if ( $am['model_id'] === $mid && ! empty( $am['expiration_date'] ) ) {
					$exp_ts = strtotime( $am['expiration_date'] );
					if ( $exp_ts !== false && $exp_ts < $future_cutoff ) {
						$expiring[] = $mid;
						$removed[] = $mid;
					}
					break;
				}
			}
		}

		foreach ( $api_models as $am ) {
			$mid = $am['model_id'] ?? '';
			if ( $mid === '' ) {
				continue;
			}
			if ( ! in_array( $mid, $current_ids, true ) && ! in_array( $mid, $removed, true ) ) {
				$added[] = $am;
			}
		}

		if ( empty( $added ) && empty( $removed ) ) {
			update_option( Config::OPTION_OPENROUTER_LAST_SYNC, time(), false );
			return [
				'success' => true,
				'message' => 'No changes. Models are up to date.',
				'added' => 0,
				'removed' => 0,
				'expiring' => 0,
				'total' => count( $current_models ),
			];
		}

		$new_models = [];
		foreach ( $current_models as $m ) {
			$mid = $m['model_id'] ?? '';
			if ( ! in_array( $mid, $removed, true ) ) {
				$new_models[] = $m;
			}
		}

		foreach ( $added as $am ) {
			$new_models[] = [
				'display_name' => $am['name'] ?? $am['model_id'],
				'model_id' => $am['model_id'],
			];
		}

		if ( empty( $new_models ) ) {
			return [ 'success' => false, 'message' => 'Sync would result in zero models. Aborting to prevent blank provider.' ];
		}

		$providers[ $or_index ]['models'] = $new_models;

		$clean = [];
		foreach ( $providers as $profile ) {
			$validated = Config::validate_custom_profile( $profile );
			if ( $validated !== null ) {
				$clean[] = $validated;
			}
		}
		update_option( Config::OPTION_CUSTOM_PROVIDERS, wp_json_encode( $clean ) );

		update_option( Config::OPTION_OPENROUTER_LAST_SYNC, time(), false );

		$log_data = [
			'provider_id' => $or_provider['id'] ?? '',
			'added' => array_column( $added, 'model_id' ),
			'removed' => $removed,
			'expiring' => $expiring,
			'total_after' => count( $new_models ),
		];
		Logger::info( Config::LOG_ACTION_OPENROUTER_SYNC, null, $log_data, '200' );

		return [
			'success' => true,
			'message' => sprintf(
				'Sync complete: %d added, %d removed (%d expiring within %d days). Total models: %d',
				count( $added ),
				count( $removed ),
				count( $expiring ),
				self::SYNC_WINDOW_DAYS,
				count( $new_models )
			),
			'added' => count( $added ),
			'removed' => count( $removed ),
			'expiring' => count( $expiring ),
			'total' => count( $new_models ),
		];
	}

	private static function fetch_free_models(): ?array {
		$url = add_query_arg( [
			'output_modalities' => 'text',
			'input_modalities' => 'text',
			'max_price' => '0',
		], self::API_URL );

		$response = wp_remote_get( $url, [
			'timeout' => 30,
			'headers' => [
				'Accept' => 'application/json',
			],
		] );

		if ( is_wp_error( $response ) ) {
			Logger::warning( Config::LOG_ACTION_OPENROUTER_SYNC, null, [
				'error' => $response->get_error_message(),
				'phase' => 'fetch',
			], '500' );
			return null;
		}

		$code = wp_remote_retrieve_response_code( $response );
		$raw = wp_remote_retrieve_body( $response );

		if ( $code !== 200 ) {
			Logger::warning( Config::LOG_ACTION_OPENROUTER_SYNC, null, [
				'http_code' => $code,
				'phase' => 'fetch',
			], (string) $code );
			return null;
		}

		$data = json_decode( $raw, true );
		if ( ! is_array( $data ) || empty( $data['data'] ) || ! is_array( $data['data'] ) ) {
			return null;
		}

		$free = [];
		foreach ( $data['data'] as $model ) {
			$id = $model['id'] ?? '';
			if ( $id === '' ) {
				continue;
			}

			$pricing = $model['pricing'] ?? [];
			$prompt_price = $pricing['prompt'] ?? '1';
			$completion_price = $pricing['completion'] ?? '1';

			if ( (string) $prompt_price !== '0' || (string) $completion_price !== '0' ) {
				continue;
			}

			$arch = $model['architecture'] ?? [];
			$output_mods = $arch['output_modalities'] ?? [];
			$modality_str = $arch['modality'] ?? '';

			if ( is_array( $output_mods ) ) {
				$has_non_text = false;
				foreach ( $output_mods as $mod ) {
					if ( strtolower( $mod ) !== 'text' ) {
						$has_non_text = true;
						break;
					}
				}
				if ( $has_non_text ) {
					continue;
				}
			}

			if ( is_string( $modality_str ) && strpos( $modality_str, 'text' ) === false ) {
				continue;
			}

			$id_lower = strtolower( $id );
			$blocked = false;
			foreach ( self::$BLOCKED_MODEL_PREFIXES as $prefix ) {
				if ( strpos( $id_lower, $prefix ) === 0 ) {
					$blocked = true;
					break;
				}
			}
			if ( $blocked ) {
				continue;
			}

			$free[] = [
				'model_id' => $id,
				'name' => $model['name'] ?? $id,
				'expiration_date' => $model['expiration_date'] ?? null,
				'context_length' => $model['context_length'] ?? 0,
			];
		}

		return $free;
	}

	public static function get_last_sync_time(): int {
		return (int) get_option( Config::OPTION_OPENROUTER_LAST_SYNC, 0 );
	}

	public static function has_openrouter_provider(): bool {
		$providers = Config::get_custom_providers();
		foreach ( $providers as $p ) {
			$url = $p['api_url'] ?? '';
			if ( strpos( $url, 'openrouter.ai' ) !== false ) {
				return true;
			}
		}
		return false;
	}
}
