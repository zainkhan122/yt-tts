<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ImageAcquisitionService {

	/**
	 * Social-media platforms whose images are almost always reposts of the same collage.
	 * Any Google Lens result whose download URL or page link originates from these domains
	 * is rejected before download — they will never be a clean editorial original.
	 */
	private static $SOCIAL_MEDIA_BLACKLIST = [
		'instagram.com',
		'cdninstagram.com',
		'fbcdn.net',
		'facebook.com',
		'twitter.com',
		'x.com',
		'twimg.com',
		'tiktok.com',
		'tiktokcdn.com',
		'pinterest.com',
		'pinimg.com',
		'youtube.com',
		'youtu.be',
		'ytimg.com',
		'snapchat.com',
		'whatsapp.com',
		'threads.net',
		'bereal.com',
	];

	/**
	 * News/media domain patterns. Results from these domains get a scoring boost
	 * so they rank above social-media reposts of equivalent resolution.
	 */
	private static $NEWS_DOMAIN_PATTERNS = [
		'geo.tv', 'geo.com.pk', 'arynews.tv', 'dunyanews.tv', 'samaa.tv',
		'express.pk', 'jang.com.pk', 'dawn.com', 'thenews.com.pk',
		'pakistantoday.com.pk', 'nation.com.pk', 'bolnews.com',
		'bbc.', 'reuters.com', 'apnews.com', 'afp.com',
		'gettyimages.com', 'shutterstock.com', 'alamy.com',
	];


	/**
	 * Main pipeline wrapper for acquiring clean original images
	 *
	 * @param int    $post_id The post ID.
	 * @param string $source_image_url The raw source image URL.
	 * @return string Verified clean image local path or original image URL.
	 */
	public static function acquire_clean_image( int $post_id, string $source_image_url ) {
		if ( empty( $source_image_url ) ) {
			return $source_image_url;
		}

		// @MODIFIED: Zero-Cost Check — save Gemini tokens if SerpApi is not configured
		$serp_api_key = get_option( Config::OPTION_SERP_API_KEY, '' );
		if ( empty( $serp_api_key ) ) {
			Logger::warning( 'image_acquisition_no_serp_key', $post_id, [ 'reason' => 'SerpApi Key is empty. Configure it in settings.' ] );
			return $source_image_url;
		}

		$local_source_path = self::resolve_local_path( $source_image_url );
		if ( empty( $local_source_path ) || ! file_exists( $local_source_path ) ) {
			// Download it locally first to perform analysis
			$local_source_path = self::download_to_temp( $source_image_url );
			if ( ! $local_source_path || ! file_exists( $local_source_path ) ) {
				return $source_image_url;
			}
		}

		// Step 1: Run Visual Analysis (Gemini Call 2)
		$analysis = self::analyze_image_visually( $local_source_path, $post_id );
		$has_celebrities = ! empty( $analysis['celebrities'] ) && is_array( $analysis['celebrities'] );

		// @MODIFIED: No longer exit early when no celebrities — Google Lens works on any image type
		if ( ! $has_celebrities ) {
			Logger::info( 'image_acquisition_no_celebrities', $post_id, [ 'reason' => 'No human entities detected visually. Falling back to post keywords for Lens verification.' ] );
		}

		// Step 2: Query Google Lens via SerpApi
		Logger::info( 'image_acquisition_started', $post_id, [
			'entities' => $has_celebrities ? $analysis['celebrities'] : [ 'keyword_fallback' ],
		] );
		
		// Encode source URL correctly. If it's a local VPS file path, SerpApi needs a public URL.
		// Google Lens SerpApi requires a publicly accessible URL.
		$public_url = $source_image_url;
		if ( strpos( $source_image_url, 'http' ) !== 0 ) {
			// Convert local path to attachment URL if possible
			$attachment_id = attachment_url_to_postid( $source_image_url );
			if ( $attachment_id ) {
				$public_url = wp_get_attachment_url( $attachment_id );
			} else {
				// Handle plugin's temp directory images (like preprocessed crops)
				$temp_dir = wp_normalize_path( AI_SOCIAL_COLLAGE_PATH . 'assets/temp' );
				$normalized_source = wp_normalize_path( $source_image_url );
				if ( strpos( $normalized_source, $temp_dir ) === 0 ) {
					$relative_path = str_replace( $temp_dir, '', $normalized_source );
					$relative_path = ltrim( $relative_path, '/\\' );
					$public_url = AI_SOCIAL_COLLAGE_URL . 'assets/temp/' . $relative_path;
				}
			}
		}

		// If public_url is still not a valid public http link, we cannot perform reverse image search
		if ( empty( $public_url ) || strpos( $public_url, 'http' ) !== 0 ) {
			Logger::warning( 'image_acquisition_no_public_url', $post_id, [ 'path' => $source_image_url ] );
			return $source_image_url;
		}

		$query_url = "https://serpapi.com/search.json?engine=google_lens&url=" . urlencode( $public_url ) . "&api_key=" . urlencode( $serp_api_key ) . "&auto_crop=true";
		$response = wp_remote_get( $query_url, [ 'timeout' => 25 ] );

		if ( is_wp_error( $response ) ) {
			Logger::error( 'serp_api_lens_failed', $post_id, [ 'error' => $response->get_error_message() ] );
			return $source_image_url;
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		$visual_matches = $data['visual_matches'] ?? [];
		if ( empty( $visual_matches ) ) {
			Logger::info( 'image_acquisition_no_visual_matches', $post_id );
			return $source_image_url;
		}

		// ── STEP 3: Candidate Filtering and Scoring ───────────────────────────
		// Problem: Google Lens returns the SAME Instagram collage image reposted by
		// other Instagram accounts or pages. We need multi-layer rejection to prevent
		// accepting the identical text-band image we are trying to replace.
		//
		// LAYER 1 (URL): Reject any result whose download URL or page link is from a
		//   social media platform — these are reposts, never clean editorial originals.
		// LAYER 2 (URL fingerprint): Reject results whose URL filename stem matches the
		//   source URL (same image, different account/domain).
		// LAYER 3 (post-download hash): Reject if MD5 of downloaded file = MD5 of source.
		// LAYER 4 (post-download dimensions): Reject if downloaded image has identical
		//   dimensions as the source (same collage reposted at same size).
		// SCORING: Boost news/media domain results so they rank above generic social reposts.

		$post_keywords = [];
		if ( ! $has_celebrities ) {
			$post       = get_post( $post_id );
			$post_title = $post ? $post->post_title : '';
			$post_content = $post ? $post->post_content : '';
			$post_keywords = self::extract_keywords( $post_title . ' ' . $post_content );
		}

		// Pre-compute source fingerprints for LAYER 2/3/4 comparisons.
		$source_md5        = file_exists( $local_source_path ) ? md5_file( $local_source_path ) : '';
		$source_filename   = pathinfo( parse_url( $source_image_url, PHP_URL_PATH ), PATHINFO_FILENAME );
		$source_host       = strtolower( parse_url( $source_image_url, PHP_URL_HOST ) ?? '' );
		$source_dimensions = @getimagesize( $local_source_path );
		$source_w          = $source_dimensions ? (int) $source_dimensions[0] : 0;
		$source_h          = $source_dimensions ? (int) $source_dimensions[1] : 0;

		$verified_candidates = [];

		foreach ( $visual_matches as $idx => $match ) {
			$title        = $match['title'] ?? '';
			$link         = $match['link']  ?? '';
			$full_res_url = $match['image'] ?? '';
			$thumbnail_url = $match['thumbnail'] ?? '';
			$download_url  = ! empty( $full_res_url ) ? $full_res_url : $thumbnail_url;

			if ( empty( $download_url ) ) {
				continue;
			}

			// ── LAYER 1: Social-media domain blacklist (zero-cost, URL-only) ─────
			$download_host = strtolower( parse_url( $download_url, PHP_URL_HOST ) ?? '' );
			$link_host     = strtolower( parse_url( $link, PHP_URL_HOST ) ?? '' );
			$is_social     = false;
			foreach ( self::$SOCIAL_MEDIA_BLACKLIST as $blocked_domain ) {
				if (
					str_contains( $download_host, $blocked_domain ) ||
					str_contains( $link_host, $blocked_domain )
				) {
					$is_social = true;
					break;
				}
			}
			if ( $is_social ) {
				Logger::debug( 'image_acquisition_social_blocked', $post_id, [
					'reason' => 'Social media domain — same collage repost',
					'host'   => $download_host ?: $link_host,
					'pos'    => $idx + 1,
				] );
				continue;
			}

			// ── LAYER 2: URL filename fingerprint (zero-cost) ────────────────────
			// If the candidate filename stem is identical to the source filename stem
			// and they share the same CDN host, it is the same file.
			$candidate_filename = pathinfo( parse_url( $download_url, PHP_URL_PATH ), PATHINFO_FILENAME );
			if (
				! empty( $source_filename ) &&
				! empty( $candidate_filename ) &&
				$candidate_filename === $source_filename &&
				$download_host === $source_host
			) {
				Logger::debug( 'image_acquisition_same_filename', $post_id, [
					'reason'   => 'Identical filename stem and CDN host — same image',
					'filename' => $candidate_filename,
					'pos'      => $idx + 1,
				] );
				continue;
			}

			// ── Keyword / celebrity verification (existing logic) ────────────────
			$match_verified = false;
			if ( $has_celebrities ) {
				foreach ( $analysis['celebrities'] as $celebrity ) {
					if ( mb_stripos( $title, $celebrity ) !== false ) {
						$match_verified = true;
						break;
					}
				}
			} else {
				if ( empty( $post_keywords ) ) {
					$match_verified = true;
				} else {
					$match_title_lower = mb_strtolower( $title, 'UTF-8' );
					foreach ( $post_keywords as $keyword ) {
						if ( mb_strpos( $match_title_lower, $keyword ) !== false ) {
							$match_verified = true;
							break;
						}
					}
				}
			}

			if ( ! $match_verified ) {
				continue;
			}

			// ── Scoring: prefer news/media domains ───────────────────────────────
			$domain_score = 0;
			foreach ( self::$NEWS_DOMAIN_PATTERNS as $news_pattern ) {
				if ( str_contains( $download_host, $news_pattern ) || str_contains( $link_host, $news_pattern ) ) {
					$domain_score = 1000; // large fixed boost, equivalent to ~1MP extra
					break;
				}
			}

			$is_google_thumbnail_proxy = (
				str_contains( $download_url, 'encrypted-tbn' ) &&
				str_contains( $download_url, 'gstatic.com' )
			);

			$img_width  = isset( $match['image_width'] )  ? intval( $match['image_width'] )  : 0;
			$img_height = isset( $match['image_height'] ) ? intval( $match['image_height'] ) : 0;
			$img_pixels = $img_width * $img_height;

			$verified_candidates[] = [
				'download_url'        => $download_url,
				'title'               => $title,
				'link'                => $link,
				'is_thumbnail_proxy'  => $is_google_thumbnail_proxy,
				'width'               => $img_width,
				'height'              => $img_height,
				'pixels'              => $img_pixels,
				'domain_score'        => $domain_score,
				'position'            => $idx + 1,
			];
		}

		if ( empty( $verified_candidates ) ) {
			// BUG FIX 3: Accurate log message — reflect the actual verification path used.
			$fail_reason = $has_celebrities
				? 'No visual matches contained celebrity names'
				: 'No visual matches matched post keywords';
			Logger::warning( 'image_acquisition_failed_verification', $post_id, [
				'reason' => $fail_reason,
				'candidates_checked' => count( $visual_matches ),
			] );
			return $source_image_url;
		}

		// Sort by: domain_score (news domains first) + pixels (largest resolution).
		// This ensures a 2MP Getty image beats a 3MP Instagram repost.
		usort( $verified_candidates, function ( $a, $b ) {
			$score_a = $a['pixels'] + $a['domain_score'];
			$score_b = $b['pixels'] + $b['domain_score'];
			return $score_b <=> $score_a;
		} );

		$best_candidate = $verified_candidates[0];

		// Warn if the best available image is only a thumbnail proxy.
		if ( $best_candidate['is_thumbnail_proxy'] ) {
			Logger::warning( 'image_acquisition_thumbnail_only', $post_id, [
				'reason' => 'Best verified match is a Google thumbnail proxy (not full-res). Resolution data missing from SerpAPI response.',
				'url' => $best_candidate['download_url'],
				'title' => $best_candidate['title'],
			] );
		}

		// ── STEP 4: Download and post-download validation ─────────────────────
		// Walk through candidates in score order. For each, download and apply
		// LAYER 3 (hash) and LAYER 4 (dimensions) checks before accepting.
		$MIN_ACCEPTABLE_WIDTH  = 400;
		$MIN_ACCEPTABLE_HEIGHT = 400;

		foreach ( $verified_candidates as $candidate ) {

			// Pre-download resolution gate (uses SerpAPI-reported dimensions).
			if (
				$candidate['pixels'] > 0 &&
				( $candidate['width'] < $MIN_ACCEPTABLE_WIDTH || $candidate['height'] < $MIN_ACCEPTABLE_HEIGHT )
			) {
				Logger::debug( 'image_acquisition_pre_download_too_small', $post_id, [
					'dimensions' => $candidate['width'] . 'x' . $candidate['height'],
					'url'        => $candidate['download_url'],
				] );
				continue;
			}

			$local_image = self::download_to_temp( $candidate['download_url'] );
			if ( ! $local_image || ! file_exists( $local_image ) ) {
				Logger::debug( 'image_acquisition_download_failed_candidate', $post_id, [
					'url' => $candidate['download_url'],
			] );
				continue;
			}

			// ── LAYER 3: File hash — reject identical file ───────────────────────
			if ( ! empty( $source_md5 ) ) {
				$candidate_md5 = md5_file( $local_image );
				if ( $candidate_md5 === $source_md5 ) {
					@unlink( $local_image );
					Logger::warning( 'image_acquisition_identical_hash', $post_id, [
						'reason' => 'Downloaded file is byte-for-byte identical to source (same collage reposted)',
						'url'    => $candidate['download_url'],
					] );
					continue;
				}
			}

			// ── LAYER 4: Dimension match — reject same-size collage reposts ──────
			// Same dimensions strongly indicates the same collage image reposted.
			// Allow up to 2px tolerance for JPEG re-encoding artefacts.
			$candidate_size = @getimagesize( $local_image );
			if ( $candidate_size && $source_w > 0 && $source_h > 0 ) {
				$cw = (int) $candidate_size[0];
				$ch = (int) $candidate_size[1];
				if ( abs( $cw - $source_w ) <= 2 && abs( $ch - $source_h ) <= 2 ) {
					@unlink( $local_image );
					Logger::warning( 'image_acquisition_same_dimensions', $post_id, [
						'reason'            => 'Downloaded image has identical dimensions to source — likely same collage reposted',
						'source_dimensions' => $source_w . 'x' . $source_h,
						'candidate_dims'    => $cw . 'x' . $ch,
						'url'               => $candidate['download_url'],
					] );
					continue;
				}
				// Post-download resolution gate.
				if ( $cw < $MIN_ACCEPTABLE_WIDTH || $ch < $MIN_ACCEPTABLE_HEIGHT ) {
					@unlink( $local_image );
					Logger::debug( 'image_acquisition_post_download_too_small', $post_id, [
						'dimensions' => $cw . 'x' . $ch,
						'url'        => $candidate['download_url'],
					] );
					continue;
				}
			}

			// ── All checks passed — accept this candidate ────────────────────────
			Logger::info( 'image_acquisition_verified', $post_id, [
				'title'               => $candidate['title'],
				'match_source'        => $candidate['link'],
				'clean_image_url'     => $candidate['download_url'],
				'resolution'          => $candidate['width'] . 'x' . $candidate['height'],
				'domain_score'        => $candidate['domain_score'],
				'is_thumbnail_proxy'  => $candidate['is_thumbnail_proxy'],
				'candidates_checked'  => count( $verified_candidates ),
				'verification_method' => $has_celebrities ? 'celebrity' : 'keyword_fallback',
			] );
			return $local_image;
		}

		// All candidates exhausted — no clean image found after all checks.
		Logger::warning( 'image_acquisition_all_candidates_rejected', $post_id, [
			'reason'             => 'Every Google Lens result was a social media repost, identical hash, or same dimensions as source.',
			'candidates_checked' => count( $verified_candidates ),
		] );
		return $source_image_url;
	}

	/**
	 * Run Gemini to analyze the image details (Call 2)
	 */
	private static function analyze_image_visually( string $image_path, int $post_id ) {
		try {
			$provider = AIProviderRegistry::get_provider_instance( Config::PROVIDER_GEMINI );
		} catch ( \Throwable $e ) {
			Logger::warning( 'visual_analysis_failed_provider', $post_id, [ 'error' => $e->getMessage() ] );
			return [ 'celebrities' => [] ];
		}

		$prompt = "
			Analyze this image and return valid JSON containing the identified celebrity names:
			{
				\"celebrities\": [\"Full name of celebrity 1\", \"Full name of celebrity 2\"],
				\"isCollage\": true/false,
				\"splitType\": \"vertical/horizontal/none\"
			}
			Note: Return ONLY valid JSON. Do not include markdown code blocks. If no celebrity is found, return empty array.
		";

		$context = [
			'job_id' => null,
			'post_id' => $post_id,
			'caller' => 'ImageAcquisitionService::analyze_image_visually',
			'image_path' => $image_path,
		];

		try {
			$result = AIProviderRegistry::execute( $provider, '', $prompt, $context );
			return is_array( $result ) ? $result : [ 'celebrities' => [] ];
		} catch ( \Exception $e ) {
			Logger::warning( 'visual_analysis_failed', $post_id, [ 'error' => $e->getMessage() ] );
			return [ 'celebrities' => [] ];
		}
	}

	private static function resolve_local_path( $image_url ) {
		if ( empty( $image_url ) ) {
			return '';
		}
		if ( file_exists( $image_url ) ) {
			return $image_url;
		}
		$upload_dir = wp_upload_dir();
		$base_url = $upload_dir['baseurl'];
		$base_dir = $upload_dir['basedir'];
		if ( strpos( $image_url, $base_url ) === 0 ) {
			return str_replace( $base_url, $base_dir, $image_url );
		}
		$attachment_id = attachment_url_to_postid( $image_url );
		if ( $attachment_id ) {
			$path = get_attached_file( $attachment_id );
			if ( $path && file_exists( $path ) ) {
				return $path;
			}
		}
		return '';
	}

	private static function download_to_temp( $url ) {
		if ( ! function_exists( 'download_url' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		
		$temp_dir = AI_SOCIAL_COLLAGE_PATH . 'assets/temp';
		if ( ! is_dir( $temp_dir ) ) {
			wp_mkdir_p( $temp_dir );
		}

		$downloaded = download_url( $url, 30 );
		if ( is_wp_error( $downloaded ) ) {
			return null;
		}

		$local_copy = $temp_dir . '/ris_clean_' . uniqid( 'ris_', true ) . '_' . getmypid() . '.jpg';
		if ( @copy( $downloaded, $local_copy ) ) {
			@unlink( $downloaded );
			return $local_copy;
		}

		@unlink( $downloaded );
		return null;
	}

	/**
	 * @MODIFIED: Extract meaningful keywords from text for non-celebrity Lens match verification.
	 *
	 * @param string $text Source text (title + content).
	 * @return array Unique keywords longer than 3 characters, excluding common stop words.
	 */
	private static function extract_keywords( string $text ): array {
		if ( empty( $text ) ) {
			return [];
		}

		$text = html_entity_decode( strip_tags( $text ), ENT_QUOTES, 'UTF-8' );
		$text = mb_strtolower( $text, 'UTF-8' );
		$text = preg_replace( '/[^\p{L}\p{N}\s]+/u', ' ', $text );
		$words = preg_split( '/\s+/u', $text, -1, PREG_SPLIT_NO_EMPTY );

		$stop_words = [
			'the', 'and', 'for', 'with', 'from', 'this', 'that', 'will', 'once', 'again',
			'during', 'also', 'have', 'has', 'had', 'are', 'was', 'were', 'been',
			'about', 'into', 'over', 'after', 'before', 'then', 'them', 'they', 'their',
			'your', 'some', 'more', 'most', 'such', 'very', 'only', 'than', 'under',
		];

		$keywords = [];
		foreach ( $words as $word ) {
			if ( mb_strlen( $word, 'UTF-8' ) > 3 && ! in_array( $word, $stop_words, true ) ) {
				$keywords[] = $word;
			}
		}

		return array_unique( $keywords );
	}
}
