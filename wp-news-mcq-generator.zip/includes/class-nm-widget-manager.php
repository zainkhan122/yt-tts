<?php

/**
 * Widget Manager
 *
 * This class replaces the procedural 8-widget.php file.
 * It registers all plugin widgets.
 *
 * @version 1.0
 */

if (! defined('ABSPATH')) {
	exit;
}

class NM_Widget_Manager
{


	/**
	 * Initialize the widget hooks
	 */
	public static function init()
	{
		add_action('widgets_init', array(self::class, 'register_widgets'));
	}

	/**
	 * Register all plugin widgets
	 */
	public static function register_widgets()
	{
		// ✅ v7.3.13: NEW Flexible Taxonomy Widget (Industry Standard)
		register_widget('NM_Flexible_Taxonomy_Widget');

		// Legacy widgets (kept for backward compatibility, will be deprecated in v8.0)
		register_widget('NM_MCQ_Topic_Widget');
		register_widget('NM_Featured_Topics_Widget');

		// Other widgets
		register_widget('NM_Dark_Mode_Toggle_Widget');

		// @NEW 9.2.0: Latest News / Current Affairs widget (drives traffic to the
		// generated roundup articles + their Shorts).
		register_widget('NM_Latest_News_Widget');
	}
}

/**
 * @NEW 9.2.0: Latest News / Current Affairs Widget.
 *
 * Lists the most recent generated roundup articles (post type 'post' marked
 * _nm_article_generated) with title, excerpt, featured image, and a link to any
 * linked YouTube Short. This surfaces the indexable editorial layer in the
 * sidebar/homepage and drives the "newsroom" feel + traffic.
 */
class NM_Latest_News_Widget extends WP_Widget
{
	public function __construct()
	{
		parent::__construct(
			'nm_latest_news_widget',
			'📰 Latest News / Current Affairs',
			array(
				'description' => 'Lists the latest generated news roundup articles (with optional linked Shorts).',
			)
		);
	}

	public function widget($args, $instance)
	{
		$title     = ! empty($instance['title']) ? $instance['title'] : 'Latest News';
		$count     = isset($instance['count']) ? max(1, min(10, (int) $instance['count'])) : 5;
		$show_img  = ! empty($instance['show_image']);
		$show_short = ! empty($instance['show_short']);

		echo $args['before_widget'];
		if ($title) {
			echo $args['before_title'] . esc_html($title) . $args['after_title'];
		}

		$articles = get_posts(
			array(
				'post_type'      => 'post',
				'post_status'    => 'publish',
				'posts_per_page' => $count,
				'orderby'        => 'date',
				'order'          => 'DESC',
				'meta_key'       => '_nm_article_generated',
				'meta_value'     => 'yes',
			)
		);

		if (empty($articles)) {
			echo '<p>' . esc_html__('No news articles yet.', 'wp-news-mcq-generator') . '</p>';
			echo $args['after_widget'];
			return;
		}

		echo '<ul class="nm-latest-news-list" style="list-style:none;margin:0;padding:0;">';
		foreach ($articles as $a) {
			$permalink = get_permalink($a->ID);
			$short_url = get_post_meta($a->ID, '_nm_article_short_url', true);
			echo '<li style="margin-bottom:14px;padding-bottom:10px;border-bottom:1px solid rgba(0,0,0,.08);">';
			if ($show_img && has_post_thumbnail($a->ID)) {
				echo '<a href="' . esc_url($permalink) . '" style="display:block;margin-bottom:6px;">' . get_the_post_thumbnail($a->ID, 'thumbnail', array('style' => 'border-radius:6px;max-width:100%;height:auto;')) . '</a>';
			}
			echo '<a href="' . esc_url($permalink) . '" style="text-decoration:none;font-weight:600;">' . esc_html(get_the_title($a->ID)) . '</a>';
			$excerpt = get_the_excerpt($a->ID);
			if ($excerpt) {
				echo '<p style="margin:4px 0 0;font-size:.9em;color:#555;">' . esc_html(wp_trim_words($excerpt, 18)) . '</p>';
			}
			if ($show_short && $short_url) {
				echo '<a href="' . esc_url($short_url) . '" target="_blank" rel="noopener" style="display:inline-block;margin-top:6px;font-size:.85em;color:#c4302b;">▶ Watch Short</a>';
			}
			echo '</li>';
		}
		echo '</ul>';

		echo $args['after_widget'];
	}

	public function form($instance)
	{
		$title      = isset($instance['title']) ? $instance['title'] : 'Latest News';
		$count      = isset($instance['count']) ? (int) $instance['count'] : 5;
		$show_image = ! empty($instance['show_image']);
		$show_short = ! empty($instance['show_short']);
		?>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('title')); ?>">Title:</label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('count')); ?>">Number to show:</label>
			<input class="small-text" id="<?php echo esc_attr($this->get_field_id('count')); ?>" name="<?php echo esc_attr($this->get_field_name('count')); ?>" type="number" min="1" max="10" value="<?php echo esc_attr($count); ?>">
		</p>
		<p>
			<input id="<?php echo esc_attr($this->get_field_id('show_image')); ?>" name="<?php echo esc_attr($this->get_field_name('show_image')); ?>" type="checkbox" value="1" <?php checked($show_image, true); ?>>
			<label for="<?php echo esc_attr($this->get_field_id('show_image')); ?>">Show featured image</label>
		</p>
		<p>
			<input id="<?php echo esc_attr($this->get_field_id('show_short')); ?>" name="<?php echo esc_attr($this->get_field_name('show_short')); ?>" type="checkbox" value="1" <?php checked($show_short, true); ?>>
			<label for="<?php echo esc_attr($this->get_field_id('show_short')); ?>">Show "Watch Short" link</label>
		</p>
		<?php
	}

	public function update($new_instance, $old_instance)
	{
		$instance              = $old_instance;
		$instance['title']     = sanitize_text_field($new_instance['title'] ?? 'Latest News');
		$instance['count']     = isset($new_instance['count']) ? max(1, min(10, (int) $new_instance['count'])) : 5;
		$instance['show_image'] = ! empty($new_instance['show_image']);
		$instance['show_short'] = ! empty($new_instance['show_short']);
		return $instance;
	}
}

/**
 * WIDGET 1: All Topics (Shows ALL categories)
 * (Copied from 8-widget.php)
 */
class NM_MCQ_Topic_Widget extends WP_Widget
{


	public function __construct()
	{
		parent::__construct(
			'nm_mcq_topic_widget',
			'📚 MCQ Topics (All) - Legacy',
			array('description' => 'LEGACY: Use "Flexible Taxonomy Widget" instead. Shows ALL main topics.')
		);
	}

	public function widget($args, $instance)
	{
		echo $args['before_widget'];

		$title = apply_filters('widget_title', $instance['title'] ?? 'All Topics');
		if (! empty($title)) {
			echo $args['before_title'] . $title . $args['after_title'];
		}

		$parent_topics = get_terms(
			array(
				'taxonomy'   => 'topic',
				'parent'     => 0,
				'hide_empty' => true,
				'orderby'    => 'name',
			)
		);

		if (! empty($parent_topics) && ! is_wp_error($parent_topics)) {
			echo '<ul class="nm-topic-list nm-all-topics">';
			foreach ($parent_topics as $parent) {
				if ($parent->count > 0) {
					echo '<li><a href="' . esc_url(get_term_link($parent)) . '" class="nm-topic-link">';
					echo '<span class="nm-topic-name">' . esc_html($parent->name) . '</span>';
					echo '<span class="nm-topic-count">' . intval($parent->count) . '</span>';
					echo '</a></li>';
				}
			}
			echo '</ul>';
		}

		echo $args['after_widget'];
	}

	public function form($instance)
	{
		$title = ! empty($instance['title']) ? $instance['title'] : 'All Topics';
?>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('title')); ?>">Title:</label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>"
				name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text"
				value="<?php echo esc_attr($title); ?>">
		</p>
		<p style="background: #e3f2fd; padding: 10px; border-radius: 3px; border-left: 4px solid #2196f3;">
			<strong>📚 All Topics</strong><br /><em>Shows ALL main topics automatically</em>
		</p>
	<?php
	}

	public function update($new_instance, $old_instance)
	{
		return array('title' => strip_tags($new_instance['title'] ?? ''));
	}
}


/**
 * WIDGET 2: Featured Topics (Shows ONLY selected)
 * (Copied from 8-widget.php)
 */
class NM_Featured_Topics_Widget extends WP_Widget
{


	public function __construct()
	{
		parent::__construct(
			'nm_featured_topics_widget',
			'⭐ MCQ Topics (Featured) - Legacy',
			array('description' => 'LEGACY: Use "Flexible Taxonomy Widget" instead. Shows selected topics.')
		);
	}

	public function widget($args, $instance)
	{
		echo $args['before_widget'];

		$title = apply_filters('widget_title', $instance['title'] ?? 'Featured Topics');
		if (! empty($title)) {
			echo $args['before_title'] . $title . $args['after_title'];
		}

		$featured_ids = ! empty($instance['featured_topics']) ? (array) $instance['featured_topics'] : array();

		if (empty($featured_ids)) {
			echo '<p style="color: #999;"><em>No featured topics configured</em></p>';
			echo $args['after_widget'];
			return;
		}

		$featured_topics = get_terms(
			array(
				'taxonomy'   => 'topic',
				'include'    => array_map('intval', $featured_ids),
				'hide_empty' => true,
				'orderby'    => 'name',
			)
		);

		if (! empty($featured_topics) && ! is_wp_error($featured_topics)) {
			echo '<ul class="nm-topic-list nm-featured-topics">';
			foreach ($featured_topics as $topic) {
				if ($topic->count > 0) {
					echo '<li><a href="' . esc_url(get_term_link($topic)) . '" class="nm-topic-link">';
					echo '<span class="nm-topic-name">' . esc_html($topic->name) . '</span>';
					echo '<span class="nm-topic-count">' . intval($topic->count) . '</span>';
					echo '</a></li>';
				}
			}
			echo '</ul>';
		}

		echo $args['after_widget'];
	}

	public function form($instance)
	{
		$title        = ! empty($instance['title']) ? $instance['title'] : 'Featured Topics';
		$featured_ids = ! empty($instance['featured_topics']) ? (array) $instance['featured_topics'] : array();

		$all_topics = get_terms(
			array(
				'taxonomy'   => 'topic',
				'parent'     => 0,
				'hide_empty' => false,
				'orderby'    => 'name',
			)
		);
	?>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('title')); ?>">Title:</label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>"
				name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text"
				value="<?php echo esc_attr($title); ?>">
		</p>

		<p>
			<label><strong>Select Featured Topics:</strong></label>
		<div style="background: #fafafa; padding: 12px; border: 1px solid #ddd; border-radius: 4px; max-height: 250px; overflow-y: auto;">
			<?php if (! empty($all_topics) && ! is_wp_error($all_topics)) : ?>
				<?php foreach ($all_topics as $topic) : ?>
					<div style="margin: 8px 0; display: flex; align-items: center;">
						<input type="checkbox" id="<?php echo esc_attr($this->get_field_id('topic_' . $topic->term_id)); ?>"
							name="<?php echo esc_attr($this->get_field_name('featured_topics')); ?>[]"
							value="<?php echo intval($topic->term_id); ?>"
							<?php echo in_array($topic->term_id, $featured_ids) ? 'checked' : ''; ?>
							style="margin-right: 8px; cursor: pointer;" />
						<label for="<?php echo esc_attr($this->get_field_id('topic_' . $topic->term_id)); ?>"
							style="cursor: pointer; margin: 0; flex: 1;">
							<?php echo esc_html($topic->name); ?>
							<span style="color: #999; font-size: 12px;">(<?php echo intval($topic->count); ?>)</span>
						</label>
					</div>
				<?php endforeach; ?>
			<?php endif; ?>
		</div>
		</p>

		<p style="background: #fff3e0; padding: 10px; border-radius: 3px; border-left: 4px solid #ff9800;">
			<strong>⭐ Featured Topics</strong><br /><em>Check topics to display</em>
		</p>
	<?php
	}

	public function update($new_instance, $old_instance)
	{
		$featured = ! empty($new_instance['featured_topics']) ? array_map('intval', (array) $new_instance['featured_topics']) : array();
		return array(
			'title'           => strip_tags($new_instance['title'] ?? ''),
			'featured_topics' => $featured,
		);
	}
}

/**
 * ✅ NEW v7.3.13: FLEXIBLE TAXONOMY WIDGET
 * Industry-standard, scalable widget supporting ALL taxonomies (Topics, Exams, etc.)
 * with "All" or "Selected" display modes.
 */
class NM_Flexible_Taxonomy_Widget extends WP_Widget
{


	/**
	 * Get available taxonomies configuration
	 */
	private static function get_available_taxonomies()
	{
		return array(
			'topic'   => array(
				'label'        => 'Topics',
				'icon'         => '📚',
				'hierarchical' => true,
			),
			'nm_exam' => array(
				'label'        => 'Exams',
				'icon'         => '📝',
				'hierarchical' => false,
			),
			'mcq_tag' => array(
				'label'        => 'Tags',
				'icon'         => '🏷️',
				'hierarchical' => false,
			),
		);
	}

	public function __construct()
	{
		parent::__construct(
			'nm_flexible_taxonomy_widget',
			'🎯 Flexible Taxonomy Widget',
			array('description' => 'Display Topics, Exams, or any taxonomy - All or Selected items. Industry-standard & scalable.')
		);
	}

	/**
	 * Frontend widget display
	 */
	public function widget($args, $instance)
	{
		echo $args['before_widget'];

		// Title
		$title = apply_filters('widget_title', $instance['title'] ?? '');
		if (! empty($title)) {
			echo $args['before_title'] . $title . $args['after_title'];
		}

		// Get settings
		$taxonomy       = $instance['taxonomy'] ?? 'topic';
		$display_mode   = $instance['display_mode'] ?? 'all';
		$selected_terms = ! empty($instance['selected_terms']) ? (array) $instance['selected_terms'] : array();
		$show_count     = ! empty($instance['show_count']);
		$show_empty     = ! empty($instance['show_empty']);
		$orderby        = $instance['orderby'] ?? 'name';
		$limit          = intval($instance['limit'] ?? 0);

		// Build term query args
		$term_args = array(
			'taxonomy'   => $taxonomy,
			'hide_empty' => ! $show_empty,
			'orderby'    => $orderby,
		);

		// @MODIFIED v7.3.14: ONLY add parent filter in "Selected" mode with hierarchical taxonomies
		// In "All" mode, show ALL topics (parents + children) like legacy widget
		$taxonomies = self::get_available_taxonomies();
		if ($display_mode === 'selected' && ! empty($taxonomies[$taxonomy]['hierarchical'])) {
			// In selected mode, parent filter is handled by selected_terms, so no need for parent=0
		} elseif ($display_mode === 'all' && ! empty($taxonomies[$taxonomy]['hierarchical'])) {
			// REMOVED: parent=0 restriction - now shows ALL topics including subtopics
			// This matches the legacy "All Topics" widget behavior
		}

		// Selected mode: filter by IDs
		if ($display_mode === 'selected' && ! empty($selected_terms)) {
			$term_args['include'] = array_map('intval', $selected_terms);
		}

		// Limit
		if ($limit > 0) {
			$term_args['number'] = $limit;
		}

		// Get terms
		$terms = get_terms($term_args);

		// Display
		if (! empty($terms) && ! is_wp_error($terms)) {
			// ✅ v7.3.13: Use legacy CSS classes for consistent styling
			$list_class = ($display_mode === 'selected') ? 'nm-featured-topics' : 'nm-all-topics';

			echo '<ul class="nm-topic-list ' . esc_attr($list_class) . '">';
			foreach ($terms as $term) {
				$term_link = get_term_link($term);
				if (is_wp_error($term_link)) {
					continue;
				}

				if ($term->count > 0 || $show_empty) {
					echo '<li>';
					echo '<a href="' . esc_url($term_link) . '" class="nm-topic-link">';
					// Filter underscores for Exams only
					$display_name = ('nm_exam' === $taxonomy) ? str_replace('_', ' ', $term->name) : $term->name;
					echo '<span class="nm-topic-name">' . esc_html($display_name) . '</span>';

					if ($show_count) {
						echo '<span class="nm-topic-count">' . intval($term->count) . '</span>';
					}

					echo '</a>';
					echo '</li>';
				}
			}
			echo '</ul>';
		} else {
			// Empty state
			$tax_label = $taxonomies[$taxonomy]['label'] ?? 'items';
			echo '<p style="color: #999; font-style: italic; padding: 10px 0;">No ' . esc_html(strtolower($tax_label)) . ' found.</p>';
		}

		echo $args['after_widget'];
	}

	/**
	 * Admin widget form
	 */
	public function form($instance)
	{
		// Get current values
		$title          = ! empty($instance['title']) ? $instance['title'] : '';
		$taxonomy       = ! empty($instance['taxonomy']) ? $instance['taxonomy'] : 'topic';
		$display_mode   = ! empty($instance['display_mode']) ? $instance['display_mode'] : 'all';
		$selected_terms = ! empty($instance['selected_terms']) ? (array) $instance['selected_terms'] : array();
		$show_count     = isset($instance['show_count']) ? (bool) $instance['show_count'] : true;
		$show_empty     = isset($instance['show_empty']) ? (bool) $instance['show_empty'] : false;
		$orderby        = ! empty($instance['orderby']) ? $instance['orderby'] : 'name';
		$limit          = isset($instance['limit']) ? intval($instance['limit']) : 0;

		$taxonomies = self::get_available_taxonomies();
	?>

		<!-- Title -->
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><strong>Title:</strong></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>"
				name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text"
				value="<?php echo esc_attr($title); ?>">
		</p>

		<!-- Taxonomy Selection -->
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('taxonomy')); ?>"><strong>Taxonomy:</strong></label>
			<select class="widefat" id="<?php echo esc_attr($this->get_field_id('taxonomy')); ?>"
				name="<?php echo esc_attr($this->get_field_name('taxonomy')); ?>">
				<?php foreach ($taxonomies as $tax_slug => $tax_data) : ?>
					<option value="<?php echo esc_attr($tax_slug); ?>" <?php selected($taxonomy, $tax_slug); ?>>
						<?php echo esc_html($tax_data['icon'] . ' ' . $tax_data['label']); ?>
					</option>
				<?php endforeach; ?>
			</select>
			<br><small style="color: #d63638;">Note: Click Save/Update to refresh the list below.</small>
		</p>

		<!-- Display Mode -->
		<p>
			<label><strong>Display Mode:</strong></label><br />
			<label style="display: inline-block; margin-right: 15px;">
				<input type="radio" name="<?php echo esc_attr($this->get_field_name('display_mode')); ?>"
					value="all" <?php checked($display_mode, 'all'); ?>>
				All
			</label>
			<label style="display: inline-block;">
				<input type="radio" name="<?php echo esc_attr($this->get_field_name('display_mode')); ?>"
					value="selected" <?php checked($display_mode, 'selected'); ?>>
				Selected
			</label>
		</p>

		<!-- Term Selection (for "Selected" mode) -->
		<div style="<?php echo $display_mode === 'selected' ? '' : 'opacity: 0.5;'; ?>">
			<p>
				<label><strong>Select Items:</strong></label>
			<div style="background: #fafafa; padding: 12px; border: 1px solid #ddd; border-radius: 4px; max-height: 200px; overflow-y: auto;">
				<?php
				// @MODIFIED: Smart filtering based on taxonomy type
				// - Topics (Hierarchical): Show ONLY top-level (parent=0)
				// - Exams (Non-Hierarchical): Show ALL (ignore parent)
				$term_args = array(
					'taxonomy'   => $taxonomy,
					'hide_empty' => false,
					'orderby'    => 'name',
				);

				if (is_taxonomy_hierarchical($taxonomy)) {
					$term_args['parent'] = 0; // Force top-level only for hierarchical types
				}

				$all_terms = get_terms($term_args);

				if (! empty($all_terms) && ! is_wp_error($all_terms)) :
					foreach ($all_terms as $term) :
				?>
						<div style="margin: 6px 0;">
							<label style="cursor: pointer; display: block;">
								<input type="checkbox"
									name="<?php echo esc_attr($this->get_field_name('selected_terms')); ?>[]"
									value="<?php echo intval($term->term_id); ?>"
									<?php echo in_array($term->term_id, $selected_terms) ? 'checked' : ''; ?>
									style="margin-right: 6px;">
								<?php echo esc_html($term->name); ?>
								<span style="color: #999; font-size: 11px;">(<?php echo intval($term->count); ?>)</span>
							</label>
						</div>
				<?php
					endforeach;
				else :
					echo '<em style="color: #999;">No items available for this taxonomy.</em>';
				endif;
				?>
			</div>
			</p>
		</div>

		<!-- Options -->
		<p>
			<label><strong>Options:</strong></label><br />
			<label style="display: block; margin: 5px 0;">
				<input type="checkbox" name="<?php echo esc_attr($this->get_field_name('show_count')); ?>"
					value="1" <?php checked($show_count, true); ?>>
				Show item count
			</label>
			<label style="display: block; margin: 5px 0;">
				<input type="checkbox" name="<?php echo esc_attr($this->get_field_name('show_empty')); ?>"
					value="1" <?php checked($show_empty, true); ?>>
				Show empty items
			</label>
		</p>

		<!-- Sorting -->
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('orderby')); ?>"><strong>Order by:</strong></label>
			<select class="widefat" id="<?php echo esc_attr($this->get_field_id('orderby')); ?>"
				name="<?php echo esc_attr($this->get_field_name('orderby')); ?>">
				<option value="name" <?php selected($orderby, 'name'); ?>>Name (A-Z)</option>
				<option value="count" <?php selected($orderby, 'count'); ?>>Count (High to Low)</option>
			</select>
		</p>

		<!-- Limit -->
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('limit')); ?>"><strong>Limit:</strong></label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('limit')); ?>"
				name="<?php echo esc_attr($this->get_field_name('limit')); ?>" type="number"
				value="<?php echo esc_attr($limit); ?>" min="0" step="1"
				placeholder="0 = unlimited">
			<small style="color: #666;">0 = Show all items</small>
		</p>

		<!-- Info Box -->
		<div style="background: #e3f2fd; padding: 12px; border-radius: 4px; border-left: 4px solid #2196f3; margin-top: 15px;">
			<strong style="color: #1565c0;">🎯 Flexible Taxonomy Widget</strong><br />
			<small style="color: #555; line-height: 1.5;">
				Supports Topics, Exams, and future taxonomies. Use "All" mode to show everything,
				or "Selected" mode to handpick specific items. Pro-level, scalable, industry-standard.
			</small>
		</div>

	<?php
	}

	/**
	 * Save widget settings
	 */
	public function update($new_instance, $old_instance)
	{
		$instance = array();

		$instance['title']          = ! empty($new_instance['title']) ? strip_tags($new_instance['title']) : '';
		$instance['taxonomy']       = ! empty($new_instance['taxonomy']) ? sanitize_key($new_instance['taxonomy']) : 'topic';
		$instance['display_mode']   = ! empty($new_instance['display_mode']) ? sanitize_key($new_instance['display_mode']) : 'all';
		$instance['selected_terms'] = ! empty($new_instance['selected_terms']) ? array_map('intval', (array) $new_instance['selected_terms']) : array();
		$instance['show_count']     = ! empty($new_instance['show_count']);
		$instance['show_empty']     = ! empty($new_instance['show_empty']);
		$instance['orderby']        = ! empty($new_instance['orderby']) ? sanitize_key($new_instance['orderby']) : 'name';
		$instance['limit']          = isset($new_instance['limit']) ? absint($new_instance['limit']) : 0;

		return $instance;
	}
}
/**
 * ✅ NEW: WIDGET 3: Dark Mode Toggle
 * This creates the "💡 Dark Mode Toggle" widget.
 */
class NM_Dark_Mode_Toggle_Widget extends WP_Widget
{


	public function __construct()
	{
		parent::__construct(
			'nm_dark_mode_toggle_widget',
			'💡 Dark Mode Toggle',
			array('description' => 'Displays the site-wide dark mode toggle button.')
		);
	}

	/**
	 * Renders the widget on the frontend.
	 */
	public function widget($args, $instance)
	{
		echo $args['before_widget'];

		// We don't show the widget title by default, as it's usually just an icon
		if (! empty($instance['title'])) {
			echo $args['before_title'] . apply_filters('widget_title', $instance['title']) . $args['after_title'];
		}

		// This is the same HTML from the (now removed) menu injection
		// The CSS and JS will find it and style it.
		echo '
            <div class="nm-theme-toggle-container">
                <button type"button" id="nm-theme-toggle-btn" class="nm-theme-toggle-btn" title="Toggle theme">
                    <span class="nm-theme-icon-light">☀️</span>
                    <span class="nm-theme-icon-dark">🌙</span>
                </button>
            </div>
        ';

		echo $args['after_widget'];
	}

	/**
	 * Renders the widget form in the admin.
	 */
	public function form($instance)
	{
		$title = ! empty($instance['title']) ? $instance['title'] : '';
	?>
		<p>
			<label for="<?php echo esc_attr($this->get_field_id('title')); ?>">Title (optional):</label>
			<input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>"
				name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text"
				value="<?php echo esc_attr($title); ?>">
		</p>
		<p style="background: #f0f0f0; padding: 10px; border-radius: 3px; border-left: 4px solid #667eea;">
			<em>This widget adds the theme toggle button. The title is usually left blank.</em>
		</p>
<?php
	}

	/**
	 * Updates the widget settings.
	 */
	public function update($new_instance, $old_instance)
	{
		return array('title' => strip_tags($new_instance['title'] ?? ''));
	}
}
?>