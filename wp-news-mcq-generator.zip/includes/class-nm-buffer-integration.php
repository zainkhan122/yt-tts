<?php

/**
 * Buffer API Integration Class
 *
 * Handles direct Buffer GraphQL API v2 integration for auto-sharing MCQs
 * to connected social media channels, bypassing Jetpack Publicize.
 *
 * API Reference: https://developers.buffer.com
 * Endpoint: https://api.buffer.com
 * Auth: Bearer token in Authorization header
 *
 * Flow:
 *   1. Get organization ID  → query { account { organizations { id } } }
 *   2. Get channels          → query { channels(input: { organizationId }) { id name service } }
 *   3. Create post per channel → mutation { createPost(input: { channelId, text, mode }) }
 *
 * @package WP_News_MCQ_Generator
 */

if (! defined('ABSPATH')) {
    exit;
}

class NM_Buffer_Integration
{

    private static $api_endpoint = 'https://api.buffer.com';

    public static function init()
    {
        add_action('transition_post_status', array(self::class, 'maybe_share_to_buffer'), 20, 3);
        add_action('admin_notices', array(self::class, 'admin_notice_missing_credentials'));
    }

    public static function is_enabled()
    {
        $enabled = (bool) get_option('nm_buffer_enabled', 0);
        $token   = get_option('nm_buffer_access_token', '');
        return $enabled && ! empty($token);
    }

    public static function admin_notice_missing_credentials()
    {
        $enabled = get_option('nm_buffer_enabled', 0);
        $token   = get_option('nm_buffer_access_token', '');

        if ($enabled && empty($token)) {
            echo '<div class="notice notice-warning is-dismissible">';
            echo '<p><strong>Buffer API Integration:</strong> Please set your Buffer Access Token in <em>MCQ Settings &rarr; Social</em> to enable auto-sharing.</p>';
            echo '</div>';
        }
    }

    public static function maybe_share_to_buffer($new_status, $old_status, $post)
    {
        if ($post->post_type !== 'mcq') {
            return;
        }

        if ($new_status !== 'publish' || $old_status === 'publish') {
            return;
        }

        if (! self::is_enabled()) {
            self::log_buffer_event('warning', 'skipped', 'Buffer sharing is disabled or token is missing in settings.', $post->ID);
            return;
        }

        if (! self::check_daily_limit($post->ID)) {
            self::log_buffer_event('warning', 'skipped', 'Daily Buffer share limit reached — skipping.', $post->ID);
            return;
        }

        self::log_buffer_event('info', 'info', 'Starting share.', $post->ID);

        $image_url = self::get_share_image_url($post->ID);

        $channels = self::get_buffer_channels();
        if (empty($channels)) {
            self::log_buffer_event('warning', 'error', 'No Buffer channels found.', $post->ID);
            return;
        }

        foreach ($channels as $channel_id => $channel_data) {
            if (! empty($channel_data['disabled'])) {
                continue;
            }

            // Check if channel is enabled in settings.
            if (! self::is_channel_enabled($channel_id)) {
                $service = $channel_data['service'] ?? 'unknown';
                self::log_buffer_event('info', 'skipped', 'Channel not enabled in settings.', $post->ID, $service . ':' . $channel_id);
                continue;
            }

            $channel_message = self::build_share_message($post, $channel_id, $channel_data);
            $result = self::create_buffer_post($channel_id, $channel_data, $channel_message, $image_url, $post->ID);
            if ($result) {
                $service = $channel_data['service'] ?? 'unknown';
                self::log_buffer_event('success', 'created', 'Shared successfully.', $post->ID, $service . ':' . $channel_id);
            }
        }
    }

    private static function build_share_message($post, $channel_id = '', $channel_data = array())
    {
        $default_template = "{question}\n\n{options}\n{link}\n\nLearn daily with thequizwire.com\n\nFollow WhatsApp Channel \n[Link of Channel]\n\nFollow YouTube Channel \n\n[Link of YT channel]\n\n#TheQuizWire #MCQs {tags}\n\nthequizwire GK MCQs";
        $template = get_option('nm_jetpack_template', $default_template);

        // Check for per-channel template override.
        if (! empty($channel_id)) {
            $channel_templates = get_option('nm_buffer_channel_templates', array());
            if (! empty($channel_templates[$channel_id])) {
                $template = $channel_templates[$channel_id];
            }
        }

        $question = html_entity_decode(strip_tags($post->post_title));

        $options_array = get_post_meta($post->ID, 'mcq_options', true);
        $options_text  = "";
        if (is_array($options_array)) {
            foreach (array('A', 'B', 'C', 'D') as $opt) {
                if (!empty($options_array[$opt])) {
                    $options_text .= $opt . ".\n" . html_entity_decode(strip_tags($options_array[$opt])) . "\n\n";
                }
            }
        }

        $link = set_url_scheme(get_permalink($post->ID), 'https');

        $tags  = wp_get_post_terms($post->ID, 'mcq_tag', array('fields' => 'names'));
        $exams = wp_get_post_terms($post->ID, 'nm_exam', array('fields' => 'names'));

        $all_tags  = array_merge((array)$tags, (array)$exams);
        $hashtags  = array();
        foreach ($all_tags as $t) {
            $cleaned = preg_replace('/[^a-zA-Z0-9]/', '', $t);
            if (!empty($cleaned)) {
                $hashtags[] = '#' . $cleaned;
            }
        }
        $tags_text = !empty($hashtags) ? implode(' ', $hashtags) : "";

        $message = str_replace(
            array('{question}', '{options}', '{link}', '{tags}'),
            array($question, trim($options_text), $link, $tags_text),
            $template
        );

        $message = preg_replace("/\n{3,}/", "\n\n", trim($message));

        return $message;
    }

    private static function get_share_image_url($post_id)
    {
        $stored_url = get_post_meta($post_id, '_nm_social_image_url', true);
        if ($stored_url) {
            return set_url_scheme($stored_url, 'https');
        }

        if (class_exists('NM_Social_Image_Generator')) {
            $version = get_post_meta($post_id, '_nm_social_image_version', true);
            if ($version) {
                $upload_dir = wp_upload_dir();
                $file_path  = $upload_dir['basedir'] . '/nm-social/mcq-' . $post_id . '-' . $version . '.webp';
                if (file_exists($file_path)) {
                    return set_url_scheme($upload_dir['baseurl'] . '/nm-social/mcq-' . $post_id . '-' . $version . '.webp', 'https');
                }
            }
        }

        $thumbnail_id = get_post_thumbnail_id($post_id);
        if ($thumbnail_id) {
            $thumbnail_url = wp_get_attachment_image_url($thumbnail_id, 'full');
            if ($thumbnail_url) {
                return set_url_scheme($thumbnail_url, 'https');
            }
        }

        $default_image_id = get_option('nm_default_social_image', 0);
        if ($default_image_id) {
            $default_url = wp_get_attachment_image_url($default_image_id, 'full');
            if ($default_url) {
                return set_url_scheme($default_url, 'https');
            }
        }

        return false;
    }

    private static function check_daily_limit($post_id)
    {
        $limit = intval(get_option('nm_buffer_daily_limit', 5));
        if ($limit === 0) {
            return true;
        }

        $today   = gmdate('Y-m-d');
        $tracker = get_option('nm_buffer_pub_tracker', array('date' => '', 'ids' => array()));

        // Defensive: if tracker is corrupted (not an array), reset it.
        if (! is_array($tracker)) {
            $tracker = array('date' => '', 'ids' => array());
        }

        if ($tracker['date'] !== $today) {
            $tracker = array('date' => $today, 'ids' => array());
            update_option('nm_buffer_pub_tracker', $tracker);
        }

        if (in_array($post_id, $tracker['ids'])) {
            return true;
        }

        if (count($tracker['ids']) >= $limit) {
            self::log_buffer_event('warning', 'skipped', 'Daily limit (' . $limit . ') reached.', $post_id);
            return false;
        }

        $tracker['ids'][] = $post_id;
        update_option('nm_buffer_pub_tracker', $tracker);

        return true;
    }

    /**
     * Perform a GraphQL request against the Buffer API.
     *
     * Per Buffer docs:
     *   POST https://api.buffer.com
     *   Headers: Content-Type: application/json, Authorization: Bearer TOKEN
     *   Body: { "query": "...", "variables": { ... } }
     *
     * @param string $query     GraphQL query or mutation string.
     * @param array  $variables Optional GraphQL variables.
     * @return array|false      The 'data' key of the response, or false on error.
     */
    private static function graphql_request($query, $variables = array())
    {
        $token = get_option('nm_buffer_access_token', '');
        if (empty($token)) {
            return false;
        }

        $payload = array('query' => $query);
        if (! empty($variables)) {
            $payload['variables'] = $variables;
        }

        $response = wp_remote_post(
            self::$api_endpoint,
            array(
                'timeout' => 30,
                'headers' => array(
                    'Content-Type'  => 'application/json',
                    'Authorization' => 'Bearer ' . $token,
                ),
                'body'    => json_encode($payload),
            )
        );

        if (is_wp_error($response)) {
            self::log_buffer_event('error', 'error', 'GraphQL request failed — ' . $response->get_error_message());
            return false;
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        if ($code === 401) {
            self::log_buffer_event('error', 'error', '401 Unauthorized — API key is invalid or revoked.');
            return false;
        }

        if (! empty($body['errors'])) {
            $msgs = array_map(function ($e) {
                return $e['message'];
            }, $body['errors']);
            self::log_buffer_event('error', 'error', 'GraphQL errors — ' . implode('; ', $msgs));
            return false;
        }

        return ! empty($body['data']) ? $body['data'] : false;
    }

    /**
     * Get the organization ID for the Buffer account.
     *
     * Per Buffer docs "Your First Post" Step 1:
     *   query GetOrganizations { account { organizations { id name } } }
     *
     * @return string|false Organization ID or false on failure.
     */
    private static function get_organization_id()
    {
        $cached = get_transient('nm_buffer_org_id');
        if ($cached !== false) {
            return $cached;
        }

        $query = <<<'GRAPHQL'
query GetOrganizations {
  account {
    organizations {
      id
      name
    }
  }
}
GRAPHQL;

        $data = self::graphql_request($query);
        if (
            empty($data)
            || empty($data['account']['organizations'])
            || ! is_array($data['account']['organizations'])
        ) {
            self::log_buffer_event('error', 'error', 'Could not retrieve organizations from Buffer API.');
            return false;
        }

        $first_org = current($data['account']['organizations']);
        $org_id    = $first_org['id'] ?? null;
        if (empty($org_id)) {
            self::log_buffer_event('error', 'error', 'No organization ID found in Buffer API response.');
            return false;
        }

        set_transient('nm_buffer_org_id', $org_id, HOUR_IN_SECONDS);

        return $org_id;
    }

    /**
     * Get Buffer Channels (connected social accounts).
     *
     * Per Buffer docs "Your First Post" Step 2:
     *   query GetChannels {
     *     channels(input: { organizationId: "..." }) { id name service }
     *   }
     *
     * The channels query requires an input object with organizationId — NOT a bare argument.
     */
    private static function get_buffer_channels()
    {
        $token = get_option('nm_buffer_access_token', '');
        if (empty($token)) {
            return array();
        }

        $cache_key = 'nm_buffer_channels';
        $cached    = get_transient($cache_key);
        if ($cached !== false) {
            return $cached;
        }

        $organization_id = self::get_organization_id();
        if (empty($organization_id)) {
            return array();
        }

        // Per Buffer docs: channels(input: { organizationId: "..." }) { id name service }
        // We embed the org ID directly into the query string to avoid variable-passing issues
        // with the input object type.
        $safe_org_id = sanitize_text_field($organization_id);

        $query = <<<GRAPHQL
query GetChannels {
  channels(input: { organizationId: "$safe_org_id" }) {
    id
    name
    displayName
    service
    avatar
    isQueuePaused
  }
}
GRAPHQL;

        $data = self::graphql_request($query);
        if (
            empty($data)
            || empty($data['channels'])
            || ! is_array($data['channels'])
        ) {
            self::log_buffer_event('error', 'error', 'Could not retrieve channels from Buffer API.');
            return array();
        }

        $channels = array();
        foreach ($data['channels'] as $channel) {
            if (! empty($channel['id'])) {
                $channels[$channel['id']] = array(
                    'name'          => $channel['name'] ?? 'Unknown',
                    'displayName'   => $channel['displayName'] ?? '',
                    'service'       => $channel['service'] ?? 'unknown',
                    'avatar'        => $channel['avatar'] ?? '',
                    'isQueuePaused' => $channel['isQueuePaused'] ?? false,
                    'disabled'      => false,
                );
            }
        }

        set_transient($cache_key, $channels, HOUR_IN_SECONDS);

        return $channels;
    }

    /**
     * Create a Buffer post for a specific channel using the createPost mutation.
     *
     * The sharing mode is resolved per channel from settings:
     *   - now   → customScheduled + dueAt (5 min from now) so it publishes
     *             near-immediately rather than waiting for the next queue slot.
     *   - queue → addToQueue (uses the channel's posting schedule).
     *   - draft → addToQueue + saveToDraft so the post is saved as a draft.
     *
     * See: https://developers.buffer.com/guides/posts-and-scheduling.html
     *
     * Note: assets.videos and metadata.linkAttachment are mutually exclusive.
     */
    private static function create_buffer_post($channel_id, $channel_data, $text, $image_url, $post_id)
    {
        $safe_channel_id = sanitize_text_field($channel_id);
        $service          = $channel_data['service'] ?? 'unknown';

        $post_text   = self::adapt_text_for_service($text, $service);
        $escaped_text = self::graphql_escape_string($post_text);

        // Instagram requires at least one image — skip if none available.
        if ($service === 'instagram' && empty($image_url)) {
            self::log_buffer_event('warning', 'skipped', 'Instagram requires an image — none available.', $post_id, $service . ':' . $channel_id);
            return false;
        }

        $input_parts = array();
        $input_parts[] = 'text: "' . $escaped_text . '"';
        $input_parts[] = 'channelId: "' . $safe_channel_id . '"';
        $input_parts[] = 'schedulingType: automatic';

        // Determine the sharing mode for this channel (now|queue|draft).
        $channel_mode = self::get_channel_mode($channel_id);
        $input_parts  = array_merge($input_parts, self::build_mode_input_parts($channel_mode));

        // Add service-specific metadata.
        // - Facebook: requires type, optional linkAttachment for link posts.
        // - Instagram: requires type AND shouldShareToFeed (Boolean!).
        // - LinkedIn: optional linkAttachment for link posts.
        $link_posts = get_option('nm_buffer_channel_link_posts', array());
        $is_link_post = ! empty($link_posts[$channel_id]);

        // Attach image as asset or link post based on channel settings.
        // - Instagram: REQUIRED image asset (hard API requirement).
        // - Facebook/LinkedIn: If link post enabled, also attach linkAttachment.
        // - Twitter/X: Image asset (link preview from URL in text also works).
        // NOTE: Facebook link posts MUST NOT include assets with linkAttachment — Buffer rejects the combination.
        if (! empty($image_url) && ! ($service === 'facebook' && $is_link_post)) {
            $escaped_url = self::graphql_escape_string($image_url);
            $input_parts[] = 'assets: [ { image: { url: "' . $escaped_url . '" } } ]';
        }

        if ($service === 'instagram') {
            $post_type = self::get_channel_post_type($channel_id, 'instagram');
            $input_parts[] = 'metadata: { instagram: { type: ' . $post_type . ', shouldShareToFeed: true } }';
        } elseif ($service === 'facebook') {
            $post_type = self::get_channel_post_type($channel_id, 'facebook');
            if ($is_link_post) {
                $escaped_link = self::graphql_escape_string(set_url_scheme(get_permalink($post_id), 'https'));
                $input_parts[] = 'metadata: { facebook: { type: ' . $post_type . ', linkAttachment: { url: "' . $escaped_link . '" } } }';
            } else {
                $input_parts[] = 'metadata: { facebook: { type: ' . $post_type . ' } }';
            }
        } elseif ($service === 'linkedin' && $is_link_post) {
            $escaped_link = self::graphql_escape_string(set_url_scheme(get_permalink($post_id), 'https'));
            $input_parts[] = 'metadata: { linkedin: { linkAttachment: { url: "' . $escaped_link . '" } } }';
        } elseif ($service === 'pinterest') {
            // Pinterest metadata per Buffer API docs:
            //   PinterestPostMetadataInput { title: String, url: String, boardServiceId: String }
            // The url field is the pin destination link; documented as accepted but not
            // persisted in current API version (roadmap item — may be fixed later).
            // Image is sent via the top-level assets array.
            $pin_title = self::build_pinterest_title($post_id, $channel_id);
            $pin_title_escaped = self::graphql_escape_string(mb_substr($pin_title, 0, 100));
            $pin_link = set_url_scheme(get_permalink($post_id), 'https');
            $pin_link_escaped = self::graphql_escape_string($pin_link);
            $pinterest_boards = get_option('nm_buffer_channel_pinterest_boards', array());
            $board_service_id = ! empty($pinterest_boards[$channel_id]) ? $pinterest_boards[$channel_id] : '';
            if (! empty($board_service_id)) {
                $input_parts[] = 'metadata: { pinterest: { title: "' . $pin_title_escaped . '", url: "' . $pin_link_escaped . '", boardServiceId: "' . self::graphql_escape_string($board_service_id) . '" } }';
            } else {
                $input_parts[] = 'metadata: { pinterest: { title: "' . $pin_title_escaped . '", url: "' . $pin_link_escaped . '" } }';
            }
        }

        $input_block = implode(', ', $input_parts);

        $mutation = <<<GRAPHQL
mutation CreateBufferPost {
  createPost(input: { $input_block }) {
    ... on PostActionSuccess {
      post {
        id
        text
        dueAt
      }
    }
    ... on MutationError {
      message
    }
  }
}
GRAPHQL;

        $data = self::graphql_request($mutation);

        if ($data === false) {
            return false;
        }

        if (! empty($data['createPost']['message'])) {
            self::log_buffer_event('error', 'error', 'createPost error on ' . $service . ' - ' . $data['createPost']['message'], $post_id, $service . ':' . $channel_id);
            return false;
        }

        $history = get_post_meta($post_id, '_nm_buffer_share_history', true);
        if (! is_array($history)) {
            $history = array();
        }
        $history[] = array(
            'channel_id' => $channel_id,
            'service'    => $service,
            'post_id'    => $data['createPost']['post']['id'] ?? '',
            'due_at'     => $data['createPost']['post']['dueAt'] ?? '',
            'shared_at'  => gmdate('Y-m-d H:i:s'),
        );
        update_post_meta($post_id, '_nm_buffer_share_history', $history);

        // Track per-channel daily stats for dashboard.
        self::record_channel_share($service);

        // After successful feed post, check if story sharing is enabled for this channel.
        $story_channels = get_option('nm_buffer_channel_share_story', array());
        if (! empty($story_channels[$channel_id]) && in_array($service, array('instagram', 'facebook'), true)) {
            self::create_story_post($channel_id, $channel_data, $image_url, $post_id);
        }

        return true;
    }

    /**
     * Create an additional story-only post for Instagram or Facebook.
     *
     * Triggered after a successful feed post when the per-channel
     * "Also share as story" toggle is enabled. The story post contains
     * only the image asset with no text or link — stories do not support
     * clickable links, and the user requested image-only stories.
     *
     * @param string $channel_id  The Buffer channel ID.
     * @param array  $channel_data Channel data array.
     * @param string $image_url   The social image URL.
     * @param int    $post_id     The MCQ post ID.
     * @return bool True on success, false on failure (logged, non-fatal).
     */
    private static function create_story_post($channel_id, $channel_data, $image_url, $post_id)
    {
        $safe_channel_id = sanitize_text_field($channel_id);
        $service = $channel_data['service'] ?? 'unknown';

        if (empty($image_url)) {
            self::log_buffer_event('warning', 'skipped', 'Cannot create story — no image available.', $post_id, $service . ':' . $channel_id);
            return false;
        }

        // Instagram Stories require 9:16 aspect ratio — the feed image (1200x630)
        // would be stretched full-screen and become unreadable. Generate a
        // dedicated story image padded to 1080x1920. Facebook handles landscape
        // images gracefully via letterboxing, so the feed image is fine there.
        $story_image_url = $image_url;
        if ($service === 'instagram' && class_exists('NM_Social_Image_Generator')) {
            $generated = NM_Social_Image_Generator::get_or_generate_story_image($post_id);
            if (! empty($generated)) {
                $story_image_url = $generated;
            }
        }

        $input_parts = array();
        $input_parts[] = 'text: " "';
        $input_parts[] = 'channelId: "' . $safe_channel_id . '"';
        $input_parts[] = 'schedulingType: automatic';

        // Apply the channel's sharing mode. In 'now' mode the story is offset
        // 6 minutes from now (feed post is at 5 min) to avoid simultaneous posting.
        $channel_mode = self::get_channel_mode($channel_id);
        $input_parts  = array_merge($input_parts, self::build_mode_input_parts($channel_mode, 360));

        $escaped_url = self::graphql_escape_string($story_image_url);
        $input_parts[] = 'assets: [ { image: { url: "' . $escaped_url . '" } } ]';

        if ($service === 'instagram') {
            $input_parts[] = 'metadata: { instagram: { type: story, shouldShareToFeed: false } }';
        } elseif ($service === 'facebook') {
            $input_parts[] = 'metadata: { facebook: { type: story } }';
        }

        $input_block = implode(', ', $input_parts);

        $mutation = <<<GRAPHQL
mutation CreateStoryPost {
  createPost(input: { $input_block }) {
    ... on PostActionSuccess {
      post {
        id
        text
        dueAt
      }
    }
    ... on MutationError {
      message
    }
  }
}
GRAPHQL;

        $data = self::graphql_request($mutation);

        if ($data === false) {
            self::log_buffer_event('error', 'error', 'Story creation failed — GraphQL request failed.', $post_id, $service . ':' . $channel_id);
            return false;
        }

        if (! empty($data['createPost']['message'])) {
            self::log_buffer_event('error', 'error', 'Story creation failed — ' . $data['createPost']['message'], $post_id, $service . ':' . $channel_id);
            return false;
        }

        // Track in share history with type: story.
        $history = get_post_meta($post_id, '_nm_buffer_share_history', true);
        if (! is_array($history)) {
            $history = array();
        }
        $history[] = array(
            'channel_id' => $channel_id,
            'service'    => $service,
            'type'       => 'story',
            'post_id'    => $data['createPost']['post']['id'] ?? '',
            'due_at'     => $data['createPost']['post']['dueAt'] ?? '',
            'shared_at'  => gmdate('Y-m-d H:i:s'),
        );
        update_post_meta($post_id, '_nm_buffer_share_history', $history);

        self::log_buffer_event('success', 'created', 'Story created successfully.', $post_id, $service . ':' . $channel_id);

        return true;
    }

    /**
     * Record a channel share in the daily stats counter.
     * Used by the dashboard card to show per-channel sharing totals.
     */
    private static function record_channel_share($service)
    {
        $channel_daily = get_option('nm_buffer_channel_daily', array());
        $today = gmdate('Y-m-d');

        if (! isset($channel_daily[$today]) || ! is_array($channel_daily[$today])) {
            $channel_daily[$today] = array();
        }

        if (! isset($channel_daily[$today][$service])) {
            $channel_daily[$today][$service] = 0;
        }
        $channel_daily[$today][$service]++;

        $channel_daily[$today]['_total']  = ($channel_daily[$today]['_total'] ?? 0) + 1;
        $channel_daily[$today]['_last']   = gmdate('Y-m-d H:i:s');

        // Keep only last 30 days.
        if (count($channel_daily) > 30) {
            $channel_daily = array_slice($channel_daily, -30, null, true);
        }

        update_option('nm_buffer_channel_daily', $channel_daily);
    }

    /**
     * Get lifetime share totals across all posts.
     * Queries _nm_buffer_share_history meta on all posts.
     *
     * @return array { total: int, per_service: array }
     */
    public static function get_lifetime_stats()
    {
        global $wpdb;
        $results = $wpdb->get_results(
            "SELECT meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_nm_buffer_share_history'"
        );

        $total       = 0;
        $per_service = array();

        if (! empty($results)) {
            foreach ($results as $row) {
                $history = maybe_unserialize($row->meta_value);
                if (! is_array($history)) {
                    continue;
                }
                foreach ($history as $entry) {
                    $svc = $entry['service'] ?? 'unknown';
                    $per_service[$svc] = ($per_service[$svc] ?? 0) + 1;
                    $total++;
                }
            }
        }

        arsort($per_service);
        return array('total' => $total, 'per_service' => $per_service);
    }

    /**
     * Fetch Pinterest boards for a channel from Buffer API.
     *
     * Per Buffer API docs:
     *   query GetChannelWithSubprofiles {
     *     channel(input: { id: "CHANNEL_ID" }) {
     *       metadata {
     *         ... on PinterestMetadata {
     *           boards { serviceId name }
     *         }
     *       }
     *     }
     *   }
     *
     * @param string $channel_id The Buffer channel ID.
     * @return array Associative array of board_service_id => board_name, or empty.
     */
    public static function get_pinterest_boards($channel_id)
    {
        $cache_key = 'nm_buffer_pinterest_boards_' . $channel_id;
        $cached    = get_transient($cache_key);
        if ($cached !== false) {
            return $cached;
        }

        $safe_id = sanitize_text_field($channel_id);
        $query = <<<GRAPHQL
query GetPinterestBoards {
  channel(input: { id: "$safe_id" }) {
    metadata {
      ... on PinterestMetadata {
        boards {
          serviceId
          name
        }
      }
    }
  }
}
GRAPHQL;

        $data = self::graphql_request($query);
        if (
            empty($data)
            || empty($data['channel']['metadata']['boards'])
            || ! is_array($data['channel']['metadata']['boards'])
        ) {
            self::log_buffer_event('error', 'error', 'Could not retrieve Pinterest boards for channel.', null, 'pinterest:' . $channel_id);
            return array();
        }

        $boards = array();
        foreach ($data['channel']['metadata']['boards'] as $board) {
            if (! empty($board['serviceId'])) {
                $boards[$board['serviceId']] = $board['name'] ?? 'Unknown';
            }
        }

        // Cache for 15 minutes.
        set_transient($cache_key, $boards, 900);

        return $boards;
    }

    /**
     * Compile a Pinterest pin title from per-channel template or default.
     *
     * Uses same template tags as build_share_message: {question}, {options}, {link}, {tags}.
     * Pinterest title is capped at 100 characters per Buffer API limits.
     *
     * @param int    $post_id    The post ID.
     * @param string $channel_id Optional channel ID for per-channel template.
     * @return string Compiled pin title (max 100 chars).
     */
    public static function build_pinterest_title($post_id, $channel_id = '')
    {
        $post = get_post($post_id);
        if (! $post) {
            return '';
        }

        $default_title = '{question}';
        $pinterest_titles = get_option('nm_buffer_channel_pinterest_titles', array());
        $template = ! empty($channel_id) && ! empty($pinterest_titles[$channel_id])
            ? $pinterest_titles[$channel_id]
            : $default_title;

        $question = html_entity_decode(strip_tags($post->post_title));

        $options_array = get_post_meta($post->ID, 'mcq_options', true);
        $options_text  = "";
        if (is_array($options_array)) {
            $lines = array();
            foreach (array('A', 'B', 'C', 'D') as $opt) {
                if (! empty($options_array[$opt])) {
                    $lines[] = $opt . '. ' . html_entity_decode(strip_tags($options_array[$opt]));
                }
            }
            $options_text = implode(' | ', $lines);
        }

        $link = set_url_scheme(get_permalink($post->ID), 'https');

        $tags  = wp_get_post_terms($post->ID, 'mcq_tag', array('fields' => 'names'));
        $exams = wp_get_post_terms($post->ID, 'nm_exam', array('fields' => 'names'));

        $all_tags  = array_merge((array)$tags, (array)$exams);
        $hashtags  = array();
        foreach ($all_tags as $t) {
            $cleaned = preg_replace('/[^a-zA-Z0-9]/', '', $t);
            if (! empty($cleaned)) {
                $hashtags[] = '#' . $cleaned;
            }
        }
        $tags_text = ! empty($hashtags) ? implode(' ', $hashtags) : "";

        $title = str_replace(
            array('{question}', '{options}', '{link}', '{tags}'),
            array($question, trim($options_text), $link, $tags_text),
            $template
        );

        $title = preg_replace("/\n+/", ' ', trim($title));
        $title = mb_substr($title, 0, 100);

        return $title;
    }

    /**
     * Clear all cached Buffer API data (transients).
     *
     * Called by the Refresh Channels AJAX handler so the next page load
     * fetches fresh organization, channel, and Pinterest board data.
     */
    public static function clear_all_caches()
    {
        global $wpdb;

        // Known transients.
        delete_transient('nm_buffer_org_id');
        delete_transient('nm_buffer_channels');

        // Settings-page channel cache keyed by token hash.
        $token_hash = md5(get_option('nm_buffer_access_token', ''));
        delete_transient('nm_buffer_channels_' . $token_hash);

        // Delete all Pinterest board transients (prefix scan via wp_options table).
        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
                $wpdb->esc_like('_transient_nm_buffer_pinterest_boards_') . '%'
            )
        );
        // Also delete the timeout transients.
        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
                $wpdb->esc_like('_transient_timeout_nm_buffer_pinterest_boards_') . '%'
            )
        );
    }

    /**
     * Adapt the share text for a specific social service.
     *
     * - Twitter/X: 280 character limit — truncate with link preserved.
     * - Facebook: No special limit, use full text.
     * - Instagram: 2,200 char limit, use full text.
     * - LinkedIn: 3,000 char limit, use full text.
     * - Others: Use full text.
     */
    private static function adapt_text_for_service($text, $service)
    {
        if ($service === 'twitter') {
            // Twitter/X limit is 280 characters.
            if (mb_strlen($text) > 280) {
                // Try to preserve the link (last line starting with https://).
                $lines       = explode("\n", $text);
                $link_line   = '';
                $content_lines = array();

                foreach ($lines as $line) {
                    if (preg_match('/^https?:\/\//', trim($line))) {
                        $link_line = trim($line);
                    } else {
                        $content_lines[] = $line;
                    }
                }

                $link_len     = ! empty($link_line) ? mb_strlen($link_line) + 1 : 0;
                $max_content  = 280 - $link_len - 3;
                $content      = implode("\n", $content_lines);

                if (mb_strlen($content) > $max_content) {
                    $content = mb_substr($content, 0, $max_content) . '...';
                }

                $text = $content;
                if (! empty($link_line)) {
                    $text .= "\n" . $link_line;
                }
            }
        }

        return $text;
    }

    /**
     * Escape a string for safe embedding inside a GraphQL string literal.
     */
    private static function graphql_escape_string($string)
    {
        return str_replace(
            array('\\', '"', "\n", "\r"),
            array('\\\\', '\\"', '\\n', ''),
            $string
        );
    }

    /**
     * Get the configured post type for a channel from settings.
     * Defaults to 'post' if not configured.
     *
     * @param string $channel_id The Buffer channel ID.
     * @param string $service    The service name (facebook, instagram, etc).
     * @return string The post type (post, story, reel).
     */
    private static function get_channel_post_type($channel_id, $service)
    {
        $channel_types = get_option('nm_buffer_channel_types', array());

        if (! empty($channel_types[$channel_id])) {
            return $channel_types[$channel_id];
        }

        // Default to 'post' if not configured.
        return 'post';
    }

    /**
     * Get the configured sharing mode for a channel from settings.
     *
     * Buffer API supports three sharing modes:
     *   - now        → mode: customScheduled + dueAt (5 min from now) → shares ASAP
     *   - queue      → mode: addToQueue (uses the channel's posting schedule)
     *   - draft      → mode: addToQueue + saveToDraft: true (saves as draft)
     *
     * Defaults to 'now' for backwards compatibility.
     *
     * @param string $channel_id The Buffer channel ID.
     * @return string The sharing mode (now|queue|draft).
     */
    private static function get_channel_mode($channel_id)
    {
        $channel_modes = get_option('nm_buffer_channel_modes', array());

        if (! empty($channel_modes[$channel_id]) && in_array($channel_modes[$channel_id], array('now', 'queue', 'draft'), true)) {
            return $channel_modes[$channel_id];
        }

        // Default to immediate sharing for backwards compatibility.
        return 'now';
    }

    /**
     * Build the scheduling input parts (mode, dueAt, saveToDraft) for the
     * createPost mutation based on the channel's configured sharing mode.
     *
     * Per Buffer API docs (https://developers.buffer.com/guides/posts-and-scheduling.html):
     *   - Share ASAP : mode: customScheduled + dueAt: "<ISO 8601 UTC>"
     *   - Add to Queue: mode: addToQueue (no dueAt)
     *   - Draft      : mode: addToQueue + saveToDraft: true
     *
     * @param string $mode      The sharing mode (now|queue|draft).
     * @param int    $offset_seconds Seconds from now for the dueAt timestamp in
     *                              'now' mode. Defaults to 300 (5 minutes).
     * @return array Array of GraphQL input parts.
     */
    private static function build_mode_input_parts($mode, $offset_seconds = 300)
    {
        $parts = array();

        switch ($mode) {
            case 'draft':
                // Per official "Create Draft Post" example, drafts require
                // mode: addToQueue plus the saveToDraft: true flag.
                $parts[] = 'mode: addToQueue';
                $parts[] = 'saveToDraft: true';
                break;

            case 'queue':
                $parts[] = 'mode: addToQueue';
                break;

            case 'now':
            default:
                // Schedule post a few minutes from now for near-immediate publishing.
                // Per Buffer docs, mode: customScheduled + dueAt sets an exact time.
                $due_at = gmdate('Y-m-d\TH:i:s', time() + $offset_seconds) . '.000Z';
                $parts[] = 'dueAt: "' . $due_at . '"';
                $parts[] = 'mode: customScheduled';
                break;
        }

        return $parts;
    }

    /**
     * Check if a channel is enabled for auto-sharing in settings.
     *
     * @param string $channel_id The Buffer channel ID.
     * @return bool True if enabled, false otherwise.
     */
    private static function is_channel_enabled($channel_id)
    {
        $enabled_channels = get_option('nm_buffer_enabled_channels', array());

        // If no channels configured, enable all (backwards compatibility).
        if (empty($enabled_channels)) {
            return true;
        }

        return in_array($channel_id, $enabled_channels, true);
    }

    /**
     * Get list of enabled channel IDs from settings.
     *
     * @return array Array of enabled channel IDs.
     */
    private static function get_enabled_channels()
    {
        $enabled_channels = get_option('nm_buffer_enabled_channels', array());

        // If empty, return empty array (will use all channels as fallback).
        if (! is_array($enabled_channels)) {
            return array();
        }

        return $enabled_channels;
    }

    /**
     * Validate post type for a service. Returns valid type or default.
     *
     * @param string $service   The service name.
     * @param string $post_type The requested post type.
     * @return string Valid post type for the service.
     */
    private static function validate_post_type($service, $post_type)
    {
        // Define valid post types per service.
        $valid_types = array(
            'facebook'  => array('post', 'story', 'reel'),
            'instagram' => array('post', 'story', 'reel'),
            'twitter'   => array('post'), // Twitter only supports post.
            'linkedin'  => array('post'),
            'pinterest' => array('post'),
            'youtube'   => array('post', 'video'),
            'threads'   => array('post', 'story'),
            'tiktok'    => array('post', 'video'),
        );

        $service_lower = strtolower($service);
        $valid = $valid_types[$service_lower] ?? array('post');

        if (! in_array($post_type, $valid, true)) {
            return 'post'; // Default to post if invalid.
        }

        return $post_type;
    }

    /**
     * Log a buffer event to the audit trail via NM_Generation_Logger.
     *
     * @param string $severity         info|success|warning|error|duplicate
     * @param string $event_type       info|created|error|skipped
     * @param string $message          Human-readable log message.
     * @param int    $mcq_id           Optional MCQ post ID.
     * @param string $channel_service  Optional "service:channel_id" reference.
     * @param array  $extra            Extra meta fields.
     */
    private static function log_buffer_event($severity, $event_type, $message, $mcq_id = null, $channel_service = null, $extra = array())
    {
        if (! class_exists('NM_Generation_Logger')) {
            return;
        }
        NM_Generation_Logger::genlog_event(array_merge(array(
            'severity'      => $severity,
            'event_type'    => $event_type,
            'source_type'   => 'buffer',
            'source_ref'    => $channel_service,
            'mcq_id'        => $mcq_id,
            'error_message' => $message,
        ), $extra));
    }

    /**
     * Public method to get channels for settings page.
     * Returns cached channels or fetches fresh if needed.
     *
     * @return array Array of channel data indexed by channel ID.
     */
    public static function get_channels_for_settings()
    {
        $transient_key = 'nm_buffer_channels_' . md5(get_option('nm_buffer_access_token', ''));
        $cached = get_transient($transient_key);

        if (false !== $cached) {
            return $cached;
        }

        $channels = self::get_buffer_channels();

        // Cache for 15 minutes.
        set_transient($transient_key, $channels, 900);

        return $channels;
    }
}
