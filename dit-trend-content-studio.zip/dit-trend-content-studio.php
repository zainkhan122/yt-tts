<?php

/**
 * Plugin Name: DIT Trend Content Studio
 * Plugin URI:  https://www.dailyinfotainment.com
 * Description: Social Media Content Generator
 * Version:           2.28.0
 * Author:            Zain Khan
 * Author URI:        https://dailyinfotainment.com
 * Text Domain:       dit-trend-content-studio
 * License:           GPL-2.0-or-later
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Requires at least: 5.8
 * Requires PHP: 7.4
 *
 * @package     DIT_TrendStudio
 * @copyright   2025
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define Plugin Constants
if (!defined('DIT_TS_VERSION')) {
    define('DIT_TS_VERSION', '2.28.0');
}
define('DIT_TS_PLUGIN_FILE', __FILE__);
define('DIT_TS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('DIT_TS_PLUGIN_URL', plugin_dir_url(__FILE__));
define('DIT_TS_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Include Composer Autoloader
if (file_exists(DIT_TS_PLUGIN_DIR . 'vendor/autoload.php')) {
    require_once DIT_TS_PLUGIN_DIR . 'vendor/autoload.php';
}

// Load BC Shims FIRST - provides class aliases before autoloader runs
require_once DIT_TS_PLUGIN_DIR . 'src/Core/Compat.php';

/**
 * Autoloader for plugin classes
 * @MODIFIED 2025-12-13 - Forked from SEO Article Generator, updated namespace to DIT\TrendStudio
 * @FIXED 2026-04-02 - Removed broken legacy fallback paths (includes/admin don't exist)
 *
 * @param string $class The fully-qualified class name.
 */ // Autoloader
spl_autoload_register(function ($class) {
    // Project-specific namespace prefix
    $prefix = 'DIT\\TrendStudio\\';

    // Ignore anything outside our namespace
    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    // Remove the namespace prefix
    $relative_class = substr($class, $len);

    // ------------------------------------------------------------------
    // PSR-4: map namespace to src/ and append ".php"
    // This is the ONLY valid path now - src/ contains all classes
    $psr4_path = DIT_TS_PLUGIN_DIR . 'src/' . str_replace('\\', '/', $relative_class) . '.php';
    if (file_exists($psr4_path)) {
        require $psr4_path;
        return;
    }

    // Class not found - log debug message only (don't spam on every missing class)
    // Compat.php should provide aliases for legacy class names
    if (defined('WP_DEBUG') && WP_DEBUG) {
        // Only log if class doesn't exist after trying to load
        if (!class_exists($class, false) && !interface_exists($class, false)) {
            error_log(sprintf(
                'DIT TrendStudio: Autoloader could not find class "%s". Expected file: %s',
                $class,
                $psr4_path
            ));
        }
    }
});

// Load Vendor Autoloader (Composer) - load again to ensure priority
if (file_exists(DIT_TS_PLUGIN_DIR . 'vendor/autoload.php')) {
    require_once DIT_TS_PLUGIN_DIR . 'vendor/autoload.php';
}

// @MODIFIED 2026-02-24 - Preload schema DTOs to avoid autoload edge cases (Class Not Found)
// @MODIFIED 2026-04-24 - Preload Infrastructure classes used cross-namespace (API_Error_Parser, etc.)
$schema_files = array(
	DIT_TS_PLUGIN_DIR . 'src/Schema/Content_Schema.php',
	DIT_TS_PLUGIN_DIR . 'src/Schema/Content_Blocks.php',
	DIT_TS_PLUGIN_DIR . 'src/Infrastructure/API_Error_Parser.php',
	DIT_TS_PLUGIN_DIR . 'src/Infrastructure/Backoff_Strategy.php',
	DIT_TS_PLUGIN_DIR . 'src/Infrastructure/Quota_Reset_Calculator.php',
	DIT_TS_PLUGIN_DIR . 'src/Infrastructure/Quota_State_Manager.php',
	DIT_TS_PLUGIN_DIR . 'src/Infrastructure/Quota_Pause_Manager.php',
	// Contracts — interfaces required by implements declarations; must exist before class loading
	DIT_TS_PLUGIN_DIR . 'src/Contracts/MiddlewareInterface.php',
	DIT_TS_PLUGIN_DIR . 'src/Contracts/AIProviderInterface.php',
	DIT_TS_PLUGIN_DIR . 'src/Contracts/ContentGeneratorInterface.php',
	DIT_TS_PLUGIN_DIR . 'src/Contracts/TrendSourceInterface.php',
	// Pipeline — critical generation-path classes (MiddlewarePipe + middleware)
	DIT_TS_PLUGIN_DIR . 'src/Pipeline/MiddlewarePipe.php',
	DIT_TS_PLUGIN_DIR . 'src/Pipeline/Middleware/CleanResponseMiddleware.php',
	DIT_TS_PLUGIN_DIR . 'src/Pipeline/Middleware/SwapVisualsMiddleware.php',
	DIT_TS_PLUGIN_DIR . 'src/Pipeline/Middleware/MediaAlignmentMiddleware.php',
	// DTOs — used as type hints and instantiated in generation hot path
	DIT_TS_PLUGIN_DIR . 'src/DTO/GenerationRequestDTO.php',
	DIT_TS_PLUGIN_DIR . 'src/DTO/GenerationResultDTO.php',
	DIT_TS_PLUGIN_DIR . 'src/DTO/TrendDTO.php',
	// AI — static call targets in every provider client and prompt builder
	DIT_TS_PLUGIN_DIR . 'src/AI/StructuredOutputSchema.php',
	DIT_TS_PLUGIN_DIR . 'src/AI/AI_Style_Guard.php',
	// Database — referenced during activation and init hooks
	DIT_TS_PLUGIN_DIR . 'src/Database/Queue_Table.php',
	// Trait — used by all 6 AI provider clients; in every generation hot path
	DIT_TS_PLUGIN_DIR . 'src/Infrastructure/AI_Network_Trait.php',
	// Interfaces — implemented by source providers and personas
	DIT_TS_PLUGIN_DIR . 'src/Sources/Source_Provider.php',
	DIT_TS_PLUGIN_DIR . 'src/Content/Personas/PersonaInterface.php',
	// Exception — thrown/caught across 15+ files including circuit breaker
	DIT_TS_PLUGIN_DIR . 'src/AI_Exception.php',
	// Logger — most-referenced infrastructure class; instantiated early
	DIT_TS_PLUGIN_DIR . 'src/Infrastructure/Logger.php',
);
foreach ($schema_files as $schema_file) {
    if (file_exists($schema_file)) {
        try {
            require_once $schema_file;
        } catch (\Throwable $t) {
            error_log('DIT TrendStudio: Preload failed for ' . $schema_file . ': ' . $t->getMessage() . ' in ' . $t->getFile() . ':' . $t->getLine());
        }
    } elseif (defined('WP_DEBUG') && WP_DEBUG) {
        error_log('DIT TrendStudio: Missing required schema file: ' . $schema_file);
    }
}


// Load Action Scheduler immediately (before plugins_loaded hook fires)
    // This ensures it registers its own hooks in time
    if (!class_exists('ActionScheduler')) {
        // @MODIFIED 2026-02-21 - Moved Action Scheduler to vendor folder for better organization
        $action_scheduler = DIT_TS_PLUGIN_DIR . 'vendor/action-scheduler/action-scheduler.php';

        if (file_exists($action_scheduler)) {
            require_once $action_scheduler;
        } else {
            // Soft dependency: Log warning but proceed with fallback
            error_log('DIT TrendStudio: Action Scheduler not found in vendor folder.');
        }
    }

/* Removed deprecated dit_trend_studio_init() function. Use dit_ts_init() instead. */
/**
 * Initialize the TrendStudio plugin.
 *
 * Hooked to the plugins_loaded action to ensure all dependencies are available.
 * This function instantiates the Core\Plugin singleton and calls its init() method.
 * If the Core\Plugin class cannot be found, an admin notice is logged.
 *
 * @return void
 */
function dit_ts_init()
{
    try {
        // Ensure the core plugin class exists. If not, surface an error.
        if (!class_exists('DIT\\TrendStudio\\Core\\Plugin')) {
            throw new Exception('Core Plugin class not found. Your installation may be incomplete.');
        }
        // Initialize the main plugin controller
        $plugin = DIT\TrendStudio\Core\Plugin::get_instance();
        $plugin->init();
    } catch (Exception $e) {
        // Log initialization failure
        error_log('DIT TrendStudio initialization failed: ' . $e->getMessage());
        // Display admin notice if user has permissions
        add_action('admin_notices', function () use ($e) {
            if (current_user_can('manage_options')) {
                printf(
                    '<div class="notice notice-error"><p><strong>DIT TrendStudio Error:</strong> %s</p></div>',
                    esc_html($e->getMessage())
                );
            }
        });
    }
}

add_action('plugins_loaded', 'dit_ts_init');

/**
 * Activation hook
 * @MODIFIED 2025-12-13 - Forked from SEO Article Generator
 */
function dit_ts_activate()
{
    try {
        $installer_file = DIT_TS_PLUGIN_DIR . 'src/Core/Bootstrap.php';
        if (file_exists($installer_file)) {
            require_once $installer_file;
        }

        // Check requirements
        if (!version_compare(PHP_VERSION, '7.4', '>=')) {
            deactivate_plugins(plugin_basename(__FILE__));
            wp_die('DIT Trend Studio requires PHP 7.4 or higher.');
        }

        // @MODIFIED 2026-07-20 - Flush OPcache so updated PHP files take effect immediately
        if (function_exists('opcache_reset')) {
            @opcache_reset();
        }

        DIT\TrendStudio\Core\Bootstrap::activate();
    } catch (\Throwable $e) {
        if (function_exists('error_log')) {
            error_log('DIT TrendStudio ACTIVATION FATAL: ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
        }
        wp_die(
            'Plugin activation failed: ' . esc_html($e->getMessage()) . '<br><br>File: ' . esc_html($e->getFile()) . '<br>Line: ' . $e->getLine(),
            'DIT TrendStudio Activation Error',
            array('back_link' => true)
        );
    }
}
register_activation_hook(__FILE__, 'dit_ts_activate');

/**
 * Deactivation hook
 * @MODIFIED 2025-12-13 - Forked from SEO Article Generator
 */
function dit_ts_deactivate()
{
    require_once DIT_TS_PLUGIN_DIR . 'src/Core/Bootstrap.php';
    DIT\TrendStudio\Core\Bootstrap::deactivate();
}
register_deactivation_hook(__FILE__, 'dit_ts_deactivate');

/**
 * DIT Video Shorts module (optional, additive).
 *
 * Boots the self-contained Video module if its classes are present. Fully
 * guarded: if anything fails, it logs (WP_DEBUG only) and DIT continues
 * unchanged. This module does NOT modify any DIT pipeline logic.
 */
add_action('plugins_loaded', function () {
    if (class_exists('\\DIT\\TrendStudio\\Video\\Module')) {
        try {
            \DIT\TrendStudio\Video\Module::instance();
        } catch (\Throwable $e) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log('DIT Video module init failed (non-fatal): ' . $e->getMessage());
            }
        }
    }
}, 25);
