<?php

namespace SEO_Article_Generator\AI;

if (!defined('ABSPATH')) {
    exit;
}

class AI_Task_Schema_Validator
{
    public static function validate(string $task, array $data, array $schema = []): array
    {
        $schema = !empty($schema) ? $schema : self::get_default_schema($task);
        $errors = [];
        $normalized = self::validate_node($data, $schema, '$', $errors);

        return [
            'ok'     => empty($errors),
            'data'   => $normalized,
            'errors' => $errors,
            'schema' => $schema,
        ];
    }

    public static function get_default_schema(string $task): array
    {
        switch ($task) {
            case 'update_probe':
                return [
                    'type'                 => 'object',
                    'additionalProperties' => false,
                    'required'             => ['latestversion', 'changelogurl', 'hasupdate'],
                    'properties'           => [
                        'latestversion' => ['type' => 'string', 'allowEmpty' => true, 'default' => ''],
                        'changelogurl'  => ['type' => 'string', 'allowEmpty' => true, 'default' => ''],
                        'hasupdate'     => ['type' => 'boolean', 'default' => false],
                    ],
                ];

            case 'section_enrichment':
                return [
                    'type'                 => 'object',
                    'additionalProperties' => false,
                    'required'             => ['whatsnew', 'features', 'moat'],
                    'properties'           => [
                        'whatsnew' => [
                            'type'       => 'string',
                            'allowEmpty' => true,
                            'default'    => '',
                        ],
                        'features' => [
                            'type'    => 'array',
                            'default' => [],
                            'items'   => [
                                'type'                 => 'object',
                                'additionalProperties' => false,
                                'required'             => ['title', 'description'],
                                'properties'           => [
                                    'title'       => ['type' => 'string', 'allowEmpty' => false, 'default' => ''],
                                    'description' => ['type' => 'string', 'allowEmpty' => false, 'default' => ''],
                                ],
                            ],
                        ],
                        'moat' => [
                            'type'                 => 'object',
                            'default'              => [],
                            'additionalProperties' => false,
                            'required'             => ['title', 'content'],
                            'properties'           => [
                                'title'   => ['type' => 'string', 'allowEmpty' => true, 'default' => ''],
                                'content' => ['type' => 'string', 'allowEmpty' => true, 'default' => ''],
                            ],
                        ],
                    ],
                ];

	case 'single_section':
		return [
			'type' => 'object',
			'additionalProperties' => false,
			'required' => ['content'],
			'properties' => [
				'content' => ['type' => 'string', 'allowEmpty' => true, 'default' => ''],
			],
		];

	default:
		return [
			'type' => 'object',
			'additionalProperties' => false,
			'properties' => [],
		];
	}
	}

	private static function validate_node($value, array $schema, string $path, array &$errors)
	{
        $type = $schema['type'] ?? 'mixed';

        switch ($type) {
            case 'object':
                return self::validate_object($value, $schema, $path, $errors);

            case 'array':
                return self::validate_array($value, $schema, $path, $errors);

            case 'string':
                return self::normalize_string($value, $schema, $path, $errors);

            case 'boolean':
                return self::normalize_boolean($value, $schema, $path, $errors);

            case 'number':
                return self::normalize_number($value, $schema, $path, $errors);

            default:
                return $value;
        }
    }

    private static function validate_object($value, array $schema, string $path, array &$errors): array
    {
        if (!is_array($value) || !self::is_assoc($value)) {
            $errors[] = $path . ' must be an object';
            $value = [];
        }

        $properties = $schema['properties'] ?? [];
        $required = $schema['required'] ?? [];
        $additional = $schema['additionalProperties'] ?? true;
        $normalized = [];

        foreach ($properties as $key => $propertySchema) {
            $childPath = $path . '.' . $key;

            if (array_key_exists($key, $value)) {
                $normalized[$key] = self::validate_node($value[$key], $propertySchema, $childPath, $errors);
                continue;
            }

            if (in_array($key, $required, true)) {
                if (array_key_exists('default', $propertySchema)) {
                    $normalized[$key] = $propertySchema['default'];
                } else {
                    $normalized[$key] = null;
                    $errors[] = $childPath . ' is required';
                }
                continue;
            }

            if (array_key_exists('default', $propertySchema)) {
                $normalized[$key] = $propertySchema['default'];
            }
        }

        if ($additional) {
            foreach ($value as $key => $raw) {
                if (!array_key_exists($key, $properties)) {
                    $normalized[$key] = $raw;
                }
            }
        }

        return $normalized;
    }

    private static function validate_array($value, array $schema, string $path, array &$errors): array
    {
        if (!is_array($value) || self::is_assoc($value)) {
            if ($value === null || $value === '') {
                return $schema['default'] ?? [];
            }

            $errors[] = $path . ' must be an array';
            return $schema['default'] ?? [];
        }

        $itemSchema = $schema['items'] ?? ['type' => 'mixed'];
        $normalized = [];

        foreach ($value as $index => $item) {
            $normalized[] = self::validate_node($item, $itemSchema, $path . '[' . $index . ']', $errors);
        }

        return $normalized;
    }

    private static function normalize_string($value, array $schema, string $path, array &$errors): string
    {
        if ($value === null) {
            return (string)($schema['default'] ?? '');
        }

        if (is_bool($value)) {
            $value = $value ? 'true' : 'false';
        } elseif (is_scalar($value)) {
            $value = (string)$value;
        } else {
            $errors[] = $path . ' must be a string';
            return (string)($schema['default'] ?? '');
        }

        $value = trim($value);
        $allowEmpty = $schema['allowEmpty'] ?? true;

        if (!$allowEmpty && $value === '') {
            $errors[] = $path . ' cannot be empty';
        }

        if (!empty($schema['enum']) && !in_array($value, (array)$schema['enum'], true)) {
            $errors[] = $path . ' must be one of: ' . implode(', ', (array)$schema['enum']);
            return (string)($schema['default'] ?? '');
        }

        return $value;
    }

    private static function normalize_boolean($value, array $schema, string $path, array &$errors): bool
    {
        if (is_bool($value)) {
            return $value;
        }

        if (is_numeric($value)) {
            return (bool)((int)$value);
        }

        if (is_string($value)) {
            $normalized = strtolower(trim($value));

            if (in_array($normalized, ['1', 'true', 'yes', 'y'], true)) {
                return true;
            }

            if (in_array($normalized, ['0', 'false', 'no', 'n', ''], true)) {
                return false;
            }
        }

        $errors[] = $path . ' must be a boolean';
        return (bool)($schema['default'] ?? false);
    }

    private static function normalize_number($value, array $schema, string $path, array &$errors)
    {
        if (is_numeric($value)) {
            return $value + 0;
        }

        $errors[] = $path . ' must be numeric';
        return $schema['default'] ?? 0;
    }

    private static function is_assoc(array $array): bool
    {
        if ($array === []) {
            return true;
        }

        return array_keys($array) !== range(0, count($array) - 1);
    }
}
