<?php

/**
 * MCQ Exporter Class
 * Export MCQs by topic, exam, date range, status with CSV/XML/JSON options
 *
 * @package WP_News_MCQ_Generator
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class NM_MCQ_Exporter {

	private static $instance = null;

	public static function init() {
		if ( self::$instance === null ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu', array( $this, 'add_export_menu' ), 13 );
		add_action( 'wp_ajax_nm_get_topics', array( $this, 'ajax_get_topics' ) );
		add_action( 'wp_ajax_nm_get_exams', array( $this, 'ajax_get_exams' ) );
		add_action( 'admin_init', array( $this, 'handle_export_request' ) );
	}

	public function handle_export_request() {
		if ( ! isset( $_GET['page'] ) || $_GET['page'] !== 'nm-mcq-export' ) {
			return;
		}

		if ( ! isset( $_POST['export_mcqs'] ) || ! isset( $_POST['nm_export_nonce'] ) ) {
			return;
		}

		if ( ! wp_verify_nonce( $_POST['nm_export_nonce'], 'nm_export_mcqs' ) ) {
			wp_die( 'Security check failed' );
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Access denied' );
		}

		$filters = array(
			'from_date'      => sanitize_text_field( $_POST['from_date'] ?? '' ),
			'to_date'        => sanitize_text_field( $_POST['to_date'] ?? '' ),
			'topics'         => array_map( 'sanitize_text_field', (array) ( $_POST['topics'] ?? array() ) ),
			'exams'          => array_map( 'sanitize_text_field', (array) ( $_POST['exams'] ?? array() ) ),
			'status'         => array_map( 'sanitize_text_field', (array) ( $_POST['status'] ?? array( 'publish' ) ) ),
			'filter_logic'   => sanitize_text_field( $_POST['filter_logic'] ?? 'OR' ),
			'format'         => sanitize_text_field( $_POST['format'] ?? 'csv' ),
			'include_images' => (bool) ( $_POST['include_images'] ?? false ),
		);

		$this->do_export( $filters );
	}

	public function add_export_menu() {
		add_submenu_page(
			'nm_mcq_generator',
			'Export MCQs',
			'📤 Export MCQs',
			'manage_options',
			'nm-mcq-export',
			array( $this, 'render_export_page' )
		);
	}

	public function render_export_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Access denied' );
		}

		$preview_results = null;
		if ( isset( $_POST['preview_mcqs'] ) && isset( $_POST['nm_export_nonce'] ) ) {
			check_admin_referer( 'nm_export_mcqs', 'nm_export_nonce' );
			$preview_results = $this->get_mcq_preview_results( $_POST );
		}
		?>
		<div class="wrap">
			<h1>📤 Export MCQs</h1>
			<p>Export MCQs filtered by date, topics, exams, and status. Choose CSV, XML, or JSON format.</p>

			<div class="nm-export-card" style="background: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); margin: 20px 0;">
				<form method="post" action="" id="nm-export-form">
					<?php wp_nonce_field( 'nm_export_mcqs', 'nm_export_nonce' ); ?>

					<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px; margin-bottom: 25px;">
						<div>
							<h3>📅 Date Range</h3>
							<div style="display: flex; gap: 15px; align-items: end;">
								<div>
									<label>From:</label><br>
									<input type="date" name="from_date" value="<?php echo esc_attr( $_POST['from_date'] ?? '' ); ?>" style="width: 180px;">
								</div>
								<div>
									<label>To:</label><br>
									<input type="date" name="to_date" value="<?php echo esc_attr( $_POST['to_date'] ?? '' ); ?>" style="width: 180px;">
								</div>
							</div>
							<p style="font-size: 12px; color: #666; margin-top: 5px;">Leave empty for all dates</p>
						</div>

						<div>
							<h3>📋 Status</h3>
							<?php
							$statuses        = array( 'publish', 'draft', 'future', 'trash' );
							$selected_status = $_POST['status'] ?? array( 'publish' );
							foreach ( $statuses as $status ) {
								$checked = in_array( $status, (array) $selected_status, true ) ? 'checked' : '';
								echo '<label style="display: block; margin-bottom: 5px;"><input type="checkbox" name="status[]" value="' . esc_attr( $status ) . '" ' . $checked . '> ' . esc_html( ucfirst( $status ) ) . '</label>';
							}
							?>
						</div>

						<div>
							<h3>🔗 Filter Logic</h3>
							<p style="font-size: 12px; color: #666; margin-bottom: 10px;">When both Topics and Exams are selected:</p>
							<?php
							$filter_logic = $_POST['filter_logic'] ?? 'OR';
							?>
							<label style="display: block; margin-bottom: 8px;">
								<input type="radio" name="filter_logic" value="OR" <?php checked( $filter_logic, 'OR' ); ?>>
								<strong>OR</strong> - MCQs with selected topic <em>OR</em> selected exam
							</label>
							<label style="display: block;">
								<input type="radio" name="filter_logic" value="AND" <?php checked( $filter_logic, 'AND' ); ?>>
								<strong>AND</strong> - MCQs with selected topic <em>AND</em> selected exam
							</label>
							<p style="font-size: 11px; color: #999; margin-top: 5px;">💡 Use OR for broader results, AND for precise filtering</p>
						</div>
					</div>

					<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px; margin-bottom: 25px;">
						<div>
							<h3>🏷️ Topics <span id="topic-count">(Loading...)</span></h3>
							<div style="margin-bottom: 8px;">
								<button type="button" id="select-all-topics" class="button button-small" style="margin-right: 5px;">✓ Select All</button>
								<button type="button" id="clear-topics" class="button button-small">✗ Clear</button>
							</div>
							<select name="topics[]" id="topics-select" multiple style="width: 100%; height: 150px; border: 1px solid #ddd; border-radius: 4px; padding: 10px;">
								<option>Loading topics...</option>
							</select>
							<p style="font-size: 12px; color: #666; margin-top: 5px;">
								<strong>Tip:</strong> Leave empty to export ALL topics. Hold Ctrl/Cmd to select multiple.
							</p>
						</div>

						<div>
							<h3>📚 Exams <span id="exam-count">(Loading...)</span></h3>
							<div style="margin-bottom: 8px;">
								<button type="button" id="select-all-exams" class="button button-small" style="margin-right: 5px;">✓ Select All</button>
								<button type="button" id="clear-exams" class="button button-small">✗ Clear</button>
							</div>
							<select name="exams[]" id="exams-select" multiple style="width: 100%; height: 150px; border: 1px solid #ddd; border-radius: 4px; padding: 10px;">
								<option>Loading exams...</option>
							</select>
							<p style="font-size: 12px; color: #666; margin-top: 5px;">
								<strong>Tip:</strong> Leave empty to export ALL exams. Hold Ctrl/Cmd to select multiple.
							</p>
						</div>
					</div>

					<div style="margin-bottom: 25px;">
						<h3>📄 Export Format</h3>
						<?php
						$formats         = array(
							'csv'  => 'CSV (Excel)',
							'xml'  => 'XML (WordPress)',
							'json' => 'JSON (API)',
						);
						$selected_format = $_POST['format'] ?? 'csv';
						foreach ( $formats as $key => $label ) {
							$checked = $selected_format === $key ? 'checked' : '';
							echo '<label style="display: inline-block; margin-right: 20px; margin-bottom: 10px;"><input type="radio" name="format" value="' . esc_attr( $key ) . '" ' . $checked . '> <strong>' . esc_html( $label ) . '</strong></label>';
						}
						?>
						<label style="margin-left: 20px;">
							<input type="checkbox" name="include_images" value="1" <?php checked( $_POST['include_images'] ?? 0 ); ?>>
							Include image URLs
						</label>
					</div>

					<div style="display: flex; gap: 15px; justify-content: flex-start;">
						<button type="submit" name="preview_mcqs" value="1" class="button button-secondary" style="padding: 12px 24px; font-size: 14px;">
							👁️ Preview Results
						</button>
						<button type="submit" name="export_mcqs" value="1" class="button button-primary" style="padding: 12px 24px; font-size: 14px;">
							📤 Export Now
						</button>
					</div>
				</form>
			</div>

			<?php if ( $preview_results ) : ?>
				<div class="nm-preview-card" style="background: #f8f9fa; padding: 25px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #28a745;">
					<h3>📊 Preview Results: <strong><?php echo number_format( $preview_results['total'] ); ?></strong> MCQs match your filters</h3>
					<p><strong>Sample MCQs:</strong></p>
					<div style="max-height: 300px; overflow-y: auto;">
						<table class="wp-list-table widefat fixed striped">
							<thead>
								<tr>
									<th>ID</th>
									<th>Title</th>
									<th>Topics</th>
									<th>Exams</th>
									<th>Date</th>
									<th>Status</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ( array_slice( $preview_results['sample'], 0, 10 ) as $mcq ) : ?>
									<tr>
										<td><?php echo (int) $mcq->ID; ?></td>
										<td style="max-width: 300px;"><?php echo esc_html( $mcq->post_title ); ?></td>
										<td><?php echo $this->format_terms( $mcq->ID, 'topic' ); ?></td>
										<td><?php echo $this->format_terms( $mcq->ID, 'nm_exam' ); ?></td>
										<td><?php echo date( 'M j, Y', strtotime( $mcq->post_date ) ); ?></td>
										<td><span class="nm-status-badge status-<?php echo esc_attr( $mcq->post_status ); ?>"><?php echo esc_html( $mcq->post_status ); ?></span></td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					</div>
				</div>
			<?php endif; ?>

			<div style="background: #e7f3ff; padding: 20px; border-radius: 8px; font-size: 13px;">
				<h4>💡 Tips:</h4>
				<ul>
					<li><strong>CSV:</strong> Best for Excel/Google Sheets analysis</li>
					<li><strong>XML:</strong> WordPress import compatible</li>
					<li><strong>JSON:</strong> API/programmatic use</li>
					<li>Large exports (>10k MCQs) may take 2-5 minutes</li>
					<li><strong>Export All:</strong> Leave Topics and Exams empty to export everything</li>
				</ul>
			</div>
		</div>

		<style>
			.nm-status-badge {
				padding: 4px 8px;
				border-radius: 12px;
				font-size: 11px;
				font-weight: 600;
				text-transform: uppercase;
			}

			.status-publish {
				background: #d4edda;
				color: #155724;
			}

			.status-draft {
				background: #fff3cd;
				color: #856404;
			}

			.status-future {
				background: #cce5ff;
				color: #004085;
			}

			.status-trash {
				background: #f8d7da;
				color: #721c24;
			}

			.button-small {
				padding: 4px 10px !important;
				height: auto !important;
				line-height: 1.4 !important;
				font-size: 12px !important;
			}
		</style>

		<script>
			jQuery(document).ready(function($) {
				// Load topics
				$.post(ajaxurl, {
					action: 'nm_get_topics'
				}).done(function(response) {
					if (response.success && Array.isArray(response.data)) {
						if (response.data.length > 0) {
							$('#topics-select').html(response.data.map(function(t) {
								return '<option value="' + t.slug + '">' + t.name + ' (' + t.count + ')</option>';
							}).join(''));
							$('#topic-count').text('(' + response.data.length + ' topics)');
						} else {
							$('#topics-select').html('<option>No topics found</option>');
							$('#topic-count').text('(0 topics)');
						}
					} else {
						$('#topics-select').html('<option>Error loading topics</option>');
						$('#topic-count').text('(Error)');
					}
				});

				// Load exams
				$.post(ajaxurl, {
					action: 'nm_get_exams'
				}).done(function(response) {
					if (response.success && Array.isArray(response.data)) {
						if (response.data.length > 0) {
							$('#exams-select').html(response.data.map(function(e) {
								return '<option value="' + e.slug + '">' + e.name + ' (' + e.count + ')</option>';
							}).join(''));
							$('#exam-count').text('(' + response.data.length + ' exams)');
						} else {
							$('#exams-select').html('<option>No exams found</option>');
							$('#exam-count').text('(0 exams)');
						}
					} else {
						$('#exams-select').html('<option>Error loading exams</option>');
						$('#exam-count').text('(Error)');
					}
				});

				// Select All / Clear Topics
				$('#select-all-topics').on('click', function() {
					$('#topics-select option').prop('selected', true);
				});

				$('#clear-topics').on('click', function() {
					$('#topics-select option').prop('selected', false);
				});

				// Select All / Clear Exams
				$('#select-all-exams').on('click', function() {
					$('#exams-select option').prop('selected', true);
				});

				$('#clear-exams').on('click', function() {
					$('#exams-select option').prop('selected', false);
				});
			});
		</script>
		<?php
	}

	private function get_mcq_preview_results( $post_data ) {
		$filters = array(
			'from_date'    => sanitize_text_field( $post_data['from_date'] ?? '' ),
			'to_date'      => sanitize_text_field( $post_data['to_date'] ?? '' ),
			'topics'       => array_map( 'sanitize_text_field', (array) ( $post_data['topics'] ?? array() ) ),
			'exams'        => array_map( 'sanitize_text_field', (array) ( $post_data['exams'] ?? array() ) ),
			'status'       => array_map( 'sanitize_text_field', (array) ( $post_data['status'] ?? array( 'publish' ) ) ),
			'filter_logic' => sanitize_text_field( $post_data['filter_logic'] ?? 'OR' ),
		);

		$query        = $this->build_mcq_query( $filters );
		$total_query  = new WP_Query(
			array_merge(
				$query,
				array(
					'fields'         => 'ids',
					'posts_per_page' => -1,
					'no_found_rows'  => false,
				)
			)
		);
		$sample_posts = get_posts( array_merge( $query, array( 'posts_per_page' => 10 ) ) );

		return array(
			'total'  => $total_query->found_posts,
			'sample' => $sample_posts,
		);
	}

	private function build_mcq_query( $filters ) {
		$args = array(
			'post_type'      => 'mcq',
			'post_status'    => $filters['status'],
			'posts_per_page' => -1,
		);

		if ( ! empty( $filters['from_date'] ) || ! empty( $filters['to_date'] ) ) {
			$args['date_query'] = array( 'inclusive' => true );

			if ( ! empty( $filters['from_date'] ) ) {
				$args['date_query']['after'] = $filters['from_date'];
			}
			if ( ! empty( $filters['to_date'] ) ) {
				$args['date_query']['before'] = $filters['to_date'];
			}
		}

		if ( ! empty( $filters['topics'] ) ) {
			$args['tax_query'][] = array(
				'taxonomy' => 'topic',
				'field'    => 'slug',
				'terms'    => $filters['topics'],
				'operator' => 'IN',
			);
		}

		if ( ! empty( $filters['exams'] ) ) {
			$args['tax_query'][] = array(
				'taxonomy' => 'nm_exam',
				'field'    => 'slug',
				'terms'    => $filters['exams'],
				'operator' => 'IN',
			);
		}

		if ( ! empty( $args['tax_query'] ) ) {
			$args['tax_query']['relation'] = isset( $filters['filter_logic'] ) ? $filters['filter_logic'] : 'OR';
		}

		return $args;
	}

	private function do_export( $filters ) {
		$query = $this->build_mcq_query( $filters );
		$mcqs  = get_posts( $query );

		if ( empty( $mcqs ) ) {
			wp_die(
				'No MCQs found matching your filters. Please adjust your criteria and try again. <br><br><a href="' .
					esc_url( admin_url( 'admin.php?page=nm-mcq-export' ) ) .
					'" class="button">← Go Back</a>'
			);
		}

		$format   = $filters['format'];
		$filename = 'mcqs-export-' . date( 'Y-m-d-His' ) . '.' . $format;

		switch ( $format ) {
			case 'csv':
				$this->export_csv( $mcqs, $filters['include_images'], $filename );
				break;
			case 'xml':
				$this->export_xml( $mcqs, $filename );
				break;
			case 'json':
				$this->export_json( $mcqs, $filters['include_images'], $filename );
				break;
		}
	}

	private function export_csv( $mcqs, $include_images, $filename ) {
		if ( ob_get_level() ) {
			ob_end_clean();
		}

		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		header( 'Cache-Control: max-age=0' );
		header( 'Pragma: no-cache' );
		header( 'Expires: 0' );

		$output = fopen( 'php://output', 'w' );

		// UTF-8 BOM for Excel
		fprintf( $output, chr( 0xEF ) . chr( 0xBB ) . chr( 0xBF ) );

		$headers = $this->get_csv_headers( $include_images );
		fputcsv( $output, $headers );

		foreach ( $mcqs as $mcq ) {
			$row = $this->get_mcq_csv_row( $mcq, $include_images );
			fputcsv( $output, $row );
		}

		fclose( $output );
		exit;
	}

	private function get_csv_headers( $include_images ) {
		$headers = array(
			'MCQ_ID',
			'Question',
			'Options',
			'Correct Answer',
			'Explanation',
			'Difficulty',
			'Cognitive Level',
			'Status',
			'Date Published',
			'Topics',
			'Exams',
			'Source URL',
			'Source Name',
			'Author',
			'Fact Checked',
			'Featured Image URL',
			'Permalink',
		);

		if ( $include_images ) {
			$headers[] = 'All Image URLs';
		}

		return $headers;
	}

	private function get_mcq_csv_row( $mcq, $include_images ) {
		$topics = $this->format_terms( $mcq->ID, 'topic' );
		$exams  = $this->format_terms( $mcq->ID, 'nm_exam' );

		// Get MCQ metadata
		$options         = get_post_meta( $mcq->ID, 'mcq_options', true );
		$answer          = get_post_meta( $mcq->ID, 'mcq_answer', true );
		$explanation     = get_post_meta( $mcq->ID, 'mcq_explanation', true );
		$difficulty      = get_post_meta( $mcq->ID, 'mcq_difficulty', true );
		$cognitive_level = get_post_meta( $mcq->ID, 'mcq_cognitive_level', true );
		// E‑A‑T metadata
		$source_url   = get_post_meta( $mcq->ID, 'mcq_source_url', true );
		$source_name  = get_post_meta( $mcq->ID, 'mcq_source_name', true );
		$author_name  = get_post_meta( $mcq->ID, 'mcq_author_name', true );
		$fact_checked = get_post_meta( $mcq->ID, 'mcq_fact_checked', true );

		// Format options as A) Option1 | B) Option2 | C) Option3 | D) Option4
		$formatted_options = '';
		if ( is_array( $options ) ) {
			$option_letters = array( 'A', 'B', 'C', 'D' );
			$formatted      = array();

			foreach ( $options as $index => $option ) {
				$letter      = $option_letters[ $index ] ?? $index;
				$formatted[] = $letter . ') ' . $option;
			}

			$formatted_options = implode( ' | ', $formatted );
		}

				$row = array(
					$mcq->ID,
					$mcq->post_title,
					$formatted_options,
					$answer,
					$explanation,
					$difficulty ?: 'N/A',
					$cognitive_level ?: 'N/A',
					$mcq->post_status,
					$mcq->post_date,
					$topics,
					$exams,
					$source_url ?: '',
					$source_name ?: '',
					$author_name ?: '',
					$fact_checked ?: '',
					get_the_post_thumbnail_url( $mcq->ID, 'full' ) ?: '',
					get_permalink( $mcq->ID ),
				);

				if ( $include_images ) {
					$row[] = $this->get_all_image_urls( $mcq->post_content );
				}

				return $row;
	}

	private function format_terms( $post_id, $taxonomy ) {
		$terms = wp_get_post_terms( $post_id, $taxonomy, array( 'fields' => 'names' ) );
		return $terms ? implode( ', ', $terms ) : '';
	}

	private function get_all_image_urls( $content ) {
		preg_match_all( '/https?:\/\/[^"\']+\.(jpg|jpeg|png|gif|webp)(\?[^\s"]*)?/i', $content, $matches );
		return implode( ', ', $matches[0] );
	}

	public function ajax_get_topics() {
		$topics = get_terms(
			array(
				'taxonomy'   => 'topic',
				'hide_empty' => false,
				'number'     => 0,
			)
		);

		if ( is_wp_error( $topics ) ) {
			wp_send_json_error( array( 'message' => 'Failed to load topics' ) );
			return;
		}

		$formatted = array();
		foreach ( $topics as $term ) {
			$formatted[] = array(
				'id'    => $term->term_id,
				'name'  => $term->name,
				'slug'  => $term->slug,
				'count' => $term->count,
			);
		}
		wp_send_json_success( $formatted );
	}

	public function ajax_get_exams() {
		$exams = get_terms(
			array(
				'taxonomy'   => 'nm_exam',
				'hide_empty' => false,
				'number'     => 0,
			)
		);

		if ( is_wp_error( $exams ) ) {
			wp_send_json_error( array( 'message' => 'Failed to load exams' ) );
			return;
		}

		$formatted = array();
		foreach ( $exams as $term ) {
			$formatted[] = array(
				'id'    => $term->term_id,
				'name'  => $term->name,
				'slug'  => $term->slug,
				'count' => $term->count,
			);
		}
		wp_send_json_success( $formatted );
	}

	private function export_xml( $mcqs, $filename ) {
		if ( ob_get_level() ) {
			ob_end_clean();
		}

		header( 'Content-Type: application/xml; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		header( 'Cache-Control: max-age=0' );
		header( 'Pragma: no-cache' );
		header( 'Expires: 0' );

		echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
		echo '<rss version="2.0" xmlns:excerpt="http://wordpress.org/export/1.2/excerpt/" xmlns:content="http://purl.org/rss/1.0/modules/content/" xmlns:wfw="http://wellformedweb.org/CommentAPI/" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:wp="http://wordpress.org/export/1.2/">' . "\n";
		echo '<channel>' . "\n";
		echo '<title>' . esc_html( get_bloginfo( 'name' ) ) . '</title>' . "\n";
		echo '<link>' . esc_url( get_bloginfo( 'url' ) ) . '</link>' . "\n";
		echo '<generator>News MCQ Generator ' . esc_html( NM_VERSION ) . '</generator>' . "\n";

		foreach ( $mcqs as $mcq ) {
			echo '<item>' . "\n";
			echo '<title><![CDATA[' . $mcq->post_title . ']]></title>' . "\n";
			echo '<link>' . esc_url( get_permalink( $mcq->ID ) ) . '</link>' . "\n";
			echo '<pubDate>' . mysql2date( 'D, d M Y H:i:s +0000', $mcq->post_date_gmt ) . '</pubDate>' . "\n";
			echo '<dc:creator><![CDATA[' . get_the_author_meta( 'display_name', $mcq->post_author ) . ']]></dc:creator>' . "\n";
			echo '<content:encoded><![CDATA[' . $mcq->post_content . ']]></content:encoded>' . "\n";
			echo '<excerpt:encoded><![CDATA[' . $mcq->post_excerpt . ']]></excerpt:encoded>' . "\n";
			echo '<wp:post_id>' . (int) $mcq->ID . '</wp:post_id>' . "\n";
			echo '<wp:post_date><![CDATA[' . $mcq->post_date . ']]></wp:post_date>' . "\n";
			echo '<wp:post_type><![CDATA[mcq]]></wp:post_type>' . "\n";
			echo '<wp:status><![CDATA[' . $mcq->post_status . ']]></wp:status>' . "\n";

			$topics = wp_get_post_terms( $mcq->ID, 'topic' );
			foreach ( $topics as $topic ) {
				echo '<category domain="topic" nicename="' . esc_attr( $topic->slug ) . '"><![CDATA[' . $topic->name . ']]></category>' . "\n";
			}

			$exams = wp_get_post_terms( $mcq->ID, 'nm_exam' );
			foreach ( $exams as $exam ) {
				echo '<category domain="nm_exam" nicename="' . esc_attr( $exam->slug ) . '"><![CDATA[' . $exam->name . ']]></category>' . "\n";
			}

			echo '</item>' . "\n";
		}

		echo '</channel>' . "\n";
		echo '</rss>';
		exit;
	}

	private function export_json( $mcqs, $include_images, $filename ) {
		if ( ob_get_level() ) {
			ob_end_clean();
		}

		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		header( 'Cache-Control: max-age=0' );
		header( 'Pragma: no-cache' );
		header( 'Expires: 0' );

		$export_data = array(
			'version'     => NM_VERSION,
			'site'        => get_bloginfo( 'name' ),
			'export_date' => current_time( 'mysql' ),
			'mcq_count'   => count( $mcqs ),
			'mcqs'        => array(),
		);

		foreach ( $mcqs as $mcq ) {
						$mcq_data = array(
							'id'              => $mcq->ID,
							'question'        => $mcq->post_title,
							'options'         => get_post_meta( $mcq->ID, 'mcq_options', true ),
							'correct_answer'  => get_post_meta( $mcq->ID, 'mcq_answer', true ),
							'explanation'     => get_post_meta( $mcq->ID, 'mcq_explanation', true ),
							'difficulty'      => get_post_meta( $mcq->ID, 'mcq_difficulty', true ),
							'cognitive_level' => get_post_meta( $mcq->ID, 'mcq_cognitive_level', true ),
							// E‑A‑T metadata
							'source_url'      => get_post_meta( $mcq->ID, 'mcq_source_url', true ),
							'source_name'     => get_post_meta( $mcq->ID, 'mcq_source_name', true ),
							'author_name'     => get_post_meta( $mcq->ID, 'mcq_author_name', true ),
							'fact_checked'    => get_post_meta( $mcq->ID, 'mcq_fact_checked', true ),
							'status'          => $mcq->post_status,
							'date'            => $mcq->post_date,
							'author'          => get_the_author_meta( 'display_name', $mcq->post_author ),
							'permalink'       => get_permalink( $mcq->ID ),
							'topics'          => wp_get_post_terms( $mcq->ID, 'topic', array( 'fields' => 'names' ) ),
							'exams'           => wp_get_post_terms( $mcq->ID, 'nm_exam', array( 'fields' => 'names' ) ),
							'featured_image'  => get_the_post_thumbnail_url( $mcq->ID, 'full' ) ?: null,
						);

						if ( $include_images ) {
							$mcq_data['all_images'] = $this->get_all_image_urls( $mcq->post_content );
						}

						$export_data['mcqs'][] = $mcq_data;
		}

		echo json_encode( $export_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
		exit;
	}
}
