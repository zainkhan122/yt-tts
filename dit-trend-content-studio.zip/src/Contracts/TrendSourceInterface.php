<?php

namespace DIT\TrendStudio\Contracts;

/**
 * Contract for trend or idea sources. Providers implementing this
 * interface are responsible for returning arrays of ideas or trend
 * records that can be consumed by the content generation pipeline.
 */
interface TrendSourceInterface
{
    /**
     * Fetch a list of ideas or trends from the source.
     *
     * @param array $params Optional provider-specific parameters.
     * @return array List of associative arrays or DTOs describing ideas.
     */
    public function fetchIdeas(array $params = []): array;
}
