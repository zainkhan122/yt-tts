<?php
/**
 * AI Social Collage — Mentions Pipeline DRY-RUN (image + video paths, full chain)
 *
 * Replays the FULL mentions producer→consumer chain against the REAL modified code:
 *
 *   PRODUCERS
 *   1. ContentRewriter::validate_rewrite_json()  (mentions preserved/normalized)
 *   2. ContentRewriter::sanitize_ai_output()     (mentions survive sanitization)
 *   3. QueueProcessor auto_meta build            (ai_mentions stored, verbatim snippet)
 *
 *   CONSUMERS
 *   4. QueueProcessor IMAGE post-content compiler (verbatim snippet w/ new block)
 *   5. QueueProcessor VIDEO post-content compiler (verbatim snippet w/ new block)
 *   6. BufferIntegration share_to_account mentions load + compile_template {mentions}
 *
 *   SSOT / CROSS-FILE CHECKS
 *   7. Same data shape (array of @handles) at every hop; string/malformed input
 *      degrades to [] instead of fatally erroring
 *   8. No caption remnants (reverted changes stay reverted)
 *
 * Run:  php tests/test-mentions-dryrun.php
 */

if ( $argc > 1 ) {
    // Optional: php tests/test-mentions-dryrun.php /path/to/ai_response.json
    // to replay a REAL AI response captured earlier.
    $real_file = $argv[1];
    if ( ! file_exists( $real_file ) ) {
        fwrite( STDERR, "Data file not found: {$real_file}\n" );
        exit( 2 );
    }
    $real_ai = json_decode( file_get_contents( $real_file ), true );
}

// ───────────────────────────────────────────────────────────────────────────
//  WORDPRESS FUNCTION STUBS + IN-MEMORY STORE
// ───────────────────────────────────────────────────────────────────────────

$GLOBALS['__post_meta'] = [];
$GLOBALS['__options']   = [];

define( 'ABSPATH', __DIR__ . '/../' );
define( 'HOUR_IN_SECONDS', 3600 );
define( 'MINUTE_IN_SECONDS', 60 );

function __meta_get( $pid, $key ) {
    return $GLOBALS['__post_meta'][ (int) $pid ][ $key ] ?? false;
}
function __meta_set( $pid, $key, $val ) {
    $GLOBALS['__post_meta'][ (int) $pid ][ $key ] = $val;
}

if ( ! function_exists( 'get_post_meta' ) ) {
    function get_post_meta( $post_id, $key = '', $single = false ) {
        return __meta_get( $post_id, $key );
    }
}
if ( ! function_exists( 'update_post_meta' ) ) {
    function update_post_meta( $post_id, $meta_key, $meta_value, $prev_value = '' ) {
        __meta_set( $post_id, $meta_key, $meta_value );
        return true;
    }
}
if ( ! function_exists( 'get_post' ) ) {
    function get_post( $post_id ) {
        $obj = new stdClass();
        $obj->ID           = (int) $post_id;
        $obj->post_title   = 'Dry run post ' . (int) $post_id;
        $obj->post_content = 'Dry run content';
        $obj->post_status  = 'publish';
        $obj->post_type    = 'post';
        return $obj;
    }
}
if ( ! function_exists( 'get_post_field' ) ) {
    function get_post_field( $field, $post_id ) {
        if ( $field === 'post_title' ) return 'Dry run post ' . (int) $post_id;
        if ( $field === 'post_content' ) return 'Dry run content';
        return '';
    }
}
if ( ! function_exists( 'get_option' ) ) {
    function get_option( $key, $default = false ) {
        return array_key_exists( $key, $GLOBALS['__options'] ) ? $GLOBALS['__options'][ $key ] : $default;
    }
}
if ( ! function_exists( 'update_option' ) ) {
    function update_option( $key, $value, $autoload = true ) {
        $GLOBALS['__options'][ $key ] = $value;
        return true;
    }
}
if ( ! function_exists( 'delete_option' ) ) {
    function delete_option( $key ) {
        unset( $GLOBALS['__options'][ $key ] );
        return true;
    }
}
if ( ! function_exists( 'get_transient' ) ) { function get_transient( $k ) { return false; } }
if ( ! function_exists( 'set_transient' ) ) { function set_transient() {} }
if ( ! function_exists( 'delete_transient' ) ) { function delete_transient() {} }
if ( ! function_exists( 'is_wp_error' ) ) { function is_wp_error( $t ) { return $t instanceof WP_Error; } }
if ( ! function_exists( 'wp_trim_words' ) ) { function wp_trim_words( $t, $n = 30 ) { $w = preg_split('/\s+/', trim( strip_tags( $t ) ) ); return implode( ' ', array_slice( $w, 0, $n ) ); } }
if ( ! function_exists( 'wp_strip_all_tags' ) ) { function wp_strip_all_tags( $t ) { return strip_tags( (string) $t ); } }
if ( ! function_exists( 'wpautop' ) ) { function wpautop( $t ) { return $t; } }
if ( ! function_exists( 'current_time' ) ) { function current_time( $type = 'mysql' ) { return $type === 'mysql' ? date( 'Y-m-d H:i:s' ) : time(); } }
if ( ! function_exists( 'mb_check_encoding' ) ) { function mb_check_encoding( $s, $enc = null ) { return true; } }
if ( ! function_exists( 'wp_json_encode' ) ) { function wp_json_encode( $d ) { return json_encode( $d, JSON_UNESCAPED_UNICODE ); } }

$GLOBALS['wpdb'] = new class {
    public $prefix = 'wp_';
    public function get_var( $q ) { return null; }
    public function insert( $t, $d, $f = [] ) { return true; }
    public function update( $t, $d, $w, $f = [], $fw = [] ) { return true; }
    public function prepare( $q, ...$a ) { return $q; }
    public function query( $q ) { return 0; }
    public function get_row( $q ) { return null; }
    public function get_results( $q ) { return []; }
    public function esc_like( $s ) { return $s; }
};
global $wpdb;

class WP_Error {
    private $code, $msg;
    public function __construct( $code = '', $msg = '' ) { $this->code = $code; $this->msg = $msg; }
    public function get_error_message() { return $this->msg; }
}

// ───────────────────────────────────────────────────────────────────────────
//  LOAD REAL MODIFIED PLUGIN CLASSES
// ───────────────────────────────────────────────────────────────────────────

$base = __DIR__ . '/../core/';
require_once $base . 'Config.php';
require_once $base . 'Logger.php';
require_once $base . 'Services/ContentRewriter.php';
require_once $base . 'Services/SocialBridge.php';
require_once $base . 'Services/BufferIntegration.php';

use AiSocialCollage\Config;
use AiSocialCollage\Services\ContentRewriter;
use AiSocialCollage\Services\BufferIntegration;

// BufferIntegration depends on these being loadable for reflection of
// share_to_account internals; load them for full fidelity where referenced.
foreach ( [
    $base . 'Services/JetpackSocial.php',
    $base . 'Services/AutoHashtagGenerator.php',
] as $dep ) {
    if ( file_exists( $dep ) ) {
        require_once $dep;
    }
}

function reflect_call( string $class, string $method, array $args ) {
    $ref = new \ReflectionMethod( $class, $method );
    $ref->setAccessible( true );
    return $ref->invokeArgs( null, $args );
}

// ───────────────────────────────────────────────────────────────────────────
//  ASSERT HARNESS
// ───────────────────────────────────────────────────────────────────────────

$passed = 0;
$failed = 0;
$failMsg = [];

function assert_eq( string $name, $actual, $expected, string $detail = '' ) {
    global $passed, $failed, $failMsg;
    $ok = ( $actual === $expected ) || ( is_array( $expected ) && is_array( $actual ) && $actual == $expected );
    if ( $ok ) {
        $passed++;
        echo "  PASS  {$name}\n";
    } else {
        $failed++;
        $m = "  FAIL  {$name}";
        if ( $detail ) $m .= " — {$detail}";
        $m .= " expected=" . var_export( $expected, true ) . " actual=" . var_export( $actual, true );
        $failMsg[] = $m;
        echo "{$m}\n";
    }
}
function assert_true( string $name, $condition, string $detail = '' ) {
    global $passed, $failed, $failMsg;
    if ( $condition ) {
        $passed++;
        echo "  PASS  {$name}\n";
    } else {
        $failed++;
        $m = "  FAIL  {$name}" . ( $detail ? " — {$detail}" : '' );
        $failMsg[] = $m;
        echo "{$m}\n";
    }
}

function section( string $title ) {
    echo "\n══════════════════════════════════════════════════════════════\n";
    echo "  {$title}\n";
    echo "══════════════════════════════════════════════════════════════\n";
}

// ───────────────────────────────────────────────────────────────────────────
//  0. REVERT VERIFICATION — NO CAPTION REMNANTS
// ───────────────────────────────────────────────────────────────────────────

section( '0. CAPTION REVERT VERIFICATION' );

$config_src = file_get_contents( $base . 'Config.php' );
$buffer_src = file_get_contents( $base . 'Services/BufferIntegration.php' );
$revert_ok  = true;

foreach ( [ 'META_ORIGINAL_CAPTION', 'original_caption', '\{caption\}' ] as $remnant ) {
    $found_in_config = strpos( $config_src, $remnant ) !== false;
    $found_in_buffer = strpos( $buffer_src, $remnant ) !== false;
    if ( $found_in_config || $found_in_buffer ) {
        $revert_ok = false;
        $failMsg[] = "Caption remnant '{$remnant}' still present (config=" . var_export( $found_in_config, true ) . ", buffer=" . var_export( $found_in_buffer, true ) . ')';
    }
}
assert_true( 'No caption remnants in Config.php / BufferIntegration.php', $revert_ok );
assert_eq(
    'compile_template signature has only 8 params (no caption)',
    ( new \ReflectionMethod( BufferIntegration::class, 'compile_template' ) )->getNumberOfParameters(),
    8,
    'compile_template must stay at 8 params after the revert'
);

// ───────────────────────────────────────────────────────────────────────────
//  1. PRODUCER: validate_rewrite_json preserves + normalizes mentions
// ───────────────────────────────────────────────────────────────────────────

section( '1. PRODUCER — ContentRewriter::validate_rewrite_json' );

$ai_response = [
    'headline'             => 'Test Headline',
    'hook'                 => 'Test hook',
    'detailed_description' => 'Full description',
    'hashtags'             => [ '#TestNews', '#Testing' ],
    'x_description'        => 'X desc',
    'x_hashtags'           => [ '#XTag' ],
    'mentions'             => [ '@holy_land_makkah', '@another_handle' ],
];
if ( isset( $real_ai ) ) {
    $ai_response = $real_ai;
    echo '  NOTE: replaying REAL AI response from ' . $argv[1] . "\n";
}

$validated = ContentRewriter::validate_rewrite_json( $ai_response, 'news' );
assert_true( 'mentions preserved through validate_rewrite_json', is_array( $validated ) && isset( $validated['mentions'] ) );
assert_eq( 'mentions equal input array (with @ prefix)', $validated['mentions'] ?? null, $ai_response['mentions'] ?? null );

// Malformed / degenerate shapes must degrade gracefully, not throw
$no_mentions = ContentRewriter::validate_rewrite_json(
    [ 'headline' => 'Headline', 'hook' => 'Hook', 'mentions' => 'string-not-array' ],
    'news'
);
assert_eq( 'mentions as non-array string → []', $no_mentions['mentions'] ?? null, [] );

// ───────────────────────────────────────────────────────────────────────────
//  FALLBACK: extract_mentions_from_content when AI returns empty mentions
// ───────────────────────────────────────────────────────────────────────────

$source_with_mentions = 'Check out @maryamnawazofficial @govtofpunjabpk @punjabpolicecpo for more info';
$fallback_mentions = ContentRewriter::extract_mentions_from_content( $source_with_mentions );
assert_eq( 'extract_mentions_from_content finds @handles', $fallback_mentions, [ '@maryamnawazofficial', '@govtofpunjabpk', '@punjabpolicecpo' ] );

// Test handles with dots and hyphens (Instagram/Twitter valid chars)
$source_with_special = 'Follow @user.name @test-user @another_handle @mixed.name-user for updates';
$special_mentions = ContentRewriter::extract_mentions_from_content( $source_with_special );
assert_eq( 'extract_mentions_from_content finds handles with dots/hyphens', $special_mentions, [ '@user.name', '@test-user', '@another_handle', '@mixed.name-user' ] );

$validated_with_fallback = ContentRewriter::validate_rewrite_json(
    [ 'headline' => 'Test', 'hook' => 'Hook', 'mentions' => [] ],
    'news',
    $source_with_mentions
);
assert_true( 'validate_rewrite_json falls back to source content mentions', ! empty( $validated_with_fallback['mentions'] ) );
assert_eq( 'fallback mentions match extracted', $validated_with_fallback['mentions'], [ '@maryamnawazofficial', '@govtofpunjabpk', '@punjabpolicecpo' ] );

$source_no_mentions = 'No mentions in this content';
$no_fallback = ContentRewriter::validate_rewrite_json(
    [ 'headline' => 'Test', 'hook' => 'Hook', 'mentions' => [] ],
    'news',
    $source_no_mentions
);
assert_eq( 'no mentions in source → empty array', $no_fallback['mentions'], [] );

$mixed = ContentRewriter::validate_rewrite_json(
    [
        'headline' => 'Headline',
        'hook'     => 'Hook',
        'mentions' => [ '@with_at', 'noprefix', '', '@with_at', '   ' ],
    ],
    'news'
);
assert_eq(
    'missing @ prefix normalized, empty/deduped entries removed',
    $mixed['mentions'] ?? null,
    [ '@with_at', '@noprefix' ]
);

$long = ContentRewriter::validate_rewrite_json(
    [
        'headline' => 'Headline',
        'hook'     => 'Hook',
        'mentions' => [ '@m1', '@m2', '@m3', '@m4', '@m5', '@m6', '@m7', '@m8', '@m9', '@m10', '@m11' ],
    ],
    'news'
);
assert_eq( 'mentions capped at 10', $long['mentions'] ?? null, [ '@m1', '@m2', '@m3', '@m4', '@m5', '@m6', '@m7', '@m8', '@m9', '@m10' ] );

// ───────────────────────────────────────────────────────────────────────────
//  2. PRODUCER: sanitize_ai_output must not strip mentions
// ───────────────────────────────────────────────────────────────────────────

section( '2. PRODUCER — sanitize_ai_output' );

$sanitized = ContentRewriter::sanitize_ai_output( $validated, 'en' );
assert_true( 'mentions survive sanitize_ai_output', isset( $sanitized['mentions'] ) );
assert_eq( 'mentions unchanged by sanitize', $sanitized['mentions'], $validated['mentions'] );

// ───────────────────────────────────────────────────────────────────────────
//  3. STORE: QueueProcessor auto_meta build (verbatim from QueueProcessor.php:469-480)
// ───────────────────────────────────────────────────────────────────────────

section( '3. STORE — QueueProcessor auto_meta build (verbatim snippet)' );

$post_id = 50001;
$ai_data = $sanitized;
$ai_meta = [
    'suggested_template'      => $ai_data['suggested_template'] ?? Config::DEFAULT_TEMPLATE,
    'suggested_category'      => $ai_data['suggested_category'] ?? 'news',
    'ai_language'             => 'en',
    'ai_hashtags'             => $ai_data['hashtags'] ?? [],
    'ai_headline'             => $ai_data['headline'] ?? '',
    'ai_hook'                 => $ai_data['hook'] ?? '',
    'ai_detailed_description' => $ai_data['detailed_description'] ?? '',
    'ai_x_hashtags'           => $ai_data['x_hashtags'] ?? [],
    'ai_x_description'        => $ai_data['x_description'] ?? '',
    'ai_mentions'             => $ai_data['mentions'] ?? [],
];
update_post_meta( $post_id, Config::META_AUTO_META, $ai_meta );

$stored = get_post_meta( $post_id, Config::META_AUTO_META );
assert_true( 'meta stored', is_array( $stored ) );
assert_eq( 'ai_mentions persisted in META_AUTO_META', $stored['ai_mentions'] ?? null, $validated['mentions'] ?? [] );

// ───────────────────────────────────────────────────────────────────────────
//  4. CONSUMER: QueueProcessor IMAGE post-content compiler (verbatim snippet
//     incl. new mentions block at QueueProcessor.php:840-847)
// ───────────────────────────────────────────────────────────────────────────

section( '4. CONSUMER — QueueProcessor IMAGE post compiler (verbatim snippet)' );

$auto_meta  = $stored;
$job        = (object) [ 'ai_detailed_description' => $ai_data['detailed_description'] ?? '', 'ai_hook' => $ai_data['hook'] ?? '' ];

$post_content = '';
if ( $attachment_id ?? 0 > 0 ) {}
$post_content .= wpautop( ! empty( $job->ai_detailed_description ) ? $job->ai_detailed_description : $job->ai_hook );

// OPTION_APPEND_TAGS_TO_POST OFF in this scenario → no hashtag block, but the
// mentions block is INDEPENDENT of that option (matches the fix).
if ( (bool) get_option( Config::OPTION_APPEND_TAGS_TO_POST, false ) ) {
    $ai_hashtags = $auto_meta['ai_hashtags'] ?? [];
    if ( is_array( $ai_hashtags ) && ! empty( $ai_hashtags ) ) {
        $tag_strings = [];
        foreach ( array_slice( $ai_hashtags, 0, 5 ) as $tag ) {
            $tag_strings[] = '#' . preg_replace( '/[^\p{L}\p{N}]/u', '', ltrim( $tag, '#' ) );
        }
        $hashtags_str = implode( ' ', $tag_strings );
        if ( ! empty( $hashtags_str ) ) {
            $post_content .= "\n\n" . $hashtags_str;
        }
    }
}

if ( ! empty( $auto_meta['x_content'] ) ) {
    $post_content .= "\n\n" . $auto_meta['x_content'];
}

// ── NEW MENTIONS BLOCK (verbatim from QueueProcessor.php:840-847) ─────────
$ai_mentions = $auto_meta['ai_mentions'] ?? [];
if ( is_array( $ai_mentions ) && ! empty( $ai_mentions ) ) {
    $mentions_str = implode( ' ', array_slice( $ai_mentions, 0, 10 ) );
    if ( ! empty( $mentions_str ) ) {
        $post_content .= "\n\n" . $mentions_str;
    }
}
// ───────────────────────────────────────────────────────────────────────────

assert_true( 'image post_content contains mentions', strpos( $post_content, '@holy_land_makkah' ) !== false );
assert_true( 'image post_content contains BOTH mentions', strpos( $post_content, '@holy_land_makkah @another_handle' ) !== false );
assert_true( 'mentions appended AFTER description', strpos( $post_content, $ai_data['detailed_description'] ) < strpos( $post_content, '@holy_land_makkah' ) );

// ───────────────────────────────────────────────────────────────────────────
//  5. CONSUMER: QueueProcessor VIDEO post-content compiler (verbatim snippet
//     incl. new mentions block at QueueProcessor.php:1270-1277)
// ───────────────────────────────────────────────────────────────────────────

section( '5. CONSUMER — QueueProcessor VIDEO post compiler (verbatim snippet)' );

$post_content_v = '';
$post_content_v .= wpautop( ! empty( $job->ai_detailed_description ) ? $job->ai_detailed_description : $job->ai_hook );

if ( (bool) get_option( Config::OPTION_APPEND_TAGS_TO_POST, false ) ) {
    $ai_hashtags = $auto_meta['ai_hashtags'] ?? [];
    if ( is_array( $ai_hashtags ) && ! empty( $ai_hashtags ) ) {
        $tag_strings = [];
        foreach ( array_slice( $ai_hashtags, 0, 5 ) as $tag ) {
            $tag_strings[] = '#' . preg_replace( '/[^\p{L}\p{N}]/u', '', ltrim( $tag, '#' ) );
        }
        $hashtags_str = implode( ' ', $tag_strings );
        if ( ! empty( $hashtags_str ) ) {
            $post_content_v .= "\n\n" . $hashtags_str;
        }
    }
}

if ( ! empty( $auto_meta['x_content'] ) ) {
    $post_content_v .= "\n\n" . $auto_meta['x_content'];
}

// ── NEW MENTIONS BLOCK (verbatim from QueueProcessor.php:1270-1277) ────────
$ai_mentions = $auto_meta['ai_mentions'] ?? [];
if ( is_array( $ai_mentions ) && ! empty( $ai_mentions ) ) {
    $mentions_str = implode( ' ', array_slice( $ai_mentions, 0, 10 ) );
    if ( ! empty( $mentions_str ) ) {
        $post_content_v .= "\n\n" . $mentions_str;
    }
}
// ───────────────────────────────────────────────────────────────────────────

assert_true( 'video post_content contains mentions', strpos( $post_content_v, '@holy_land_makkah @another_handle' ) !== false );

// Empty mentions ⇒ no trailing junk block
$empty_meta = $auto_meta;
$empty_meta['ai_mentions'] = [];
$pc_empty = "Base";
$ai_mentions = $empty_meta['ai_mentions'] ?? [];
if ( is_array( $ai_mentions ) && ! empty( $ai_mentions ) ) {
    $mentions_str = implode( ' ', array_slice( $ai_mentions, 0, 10 ) );
    if ( ! empty( $mentions_str ) ) {
        $pc_empty .= "\n\n" . $mentions_str;
    }
}
assert_eq( 'empty ai_mentions → no mentions junk appended', $pc_empty, 'Base' );

// ───────────────────────────────────────────────────────────────────────────
//  6. CONSUMER: BufferIntegration — mentions load + {mentions} placeholder
// ───────────────────────────────────────────────────────────────────────────

section( '6. CONSUMER — BufferIntegration {mentions} template' );

// Verbatim from BufferIntegration.php:192-195
$mentions = '';
if ( ! empty( $auto_meta['ai_mentions'] ) && is_array( $auto_meta['ai_mentions'] ) ) {
    $mentions = implode( ' ', array_slice( $auto_meta['ai_mentions'], 0, 10 ) );
}

$template = "{headline}\n\n{description}\n\n{hashtags}\n\n{link}\n\n{mentions}";
$compiled = reflect_call( BufferIntegration::class, 'compile_template', [ $template, 'Head', 'Desc', '#Tag', 'https://x.test', '#xh', 'XDesc', $mentions ] );

assert_true( 'Buffer template renders {mentions}', strpos( $compiled, '@holy_land_makkah @another_handle' ) !== false );
assert_eq( 'hashtags still rendered', strpos( $compiled, '#Tag' ) !== false, true );
assert_eq( 'headline still rendered', strpos( $compiled, 'Head' ) !== false, true );

// ───────────────────────────────────────────────────────────────────────────
//  7. SSOT / CROSS-FILE SHAPE CONSISTENCY
// ───────────────────────────────────────────────────────────────────────────

section( '7. SSOT consistency — same array<@handle> shape at every hop' );

$hop_shapes = [
    'validate_rewrite_json'      => $validated['mentions'] ?? [],
    'sanitize_ai_output'         => $sanitized['mentions'] ?? [],
    'META_AUTO_META stored'      => $stored['ai_mentions'] ?? [],
    'Buffer {mentions} (joined)' => array_values( array_filter( array_map( 'trim', explode( ' ', $mentions ) ) ) ),
    'image post_content tokens'  => array_values( array_filter( array_map( 'trim', explode( ' ', str_replace( "\n", ' ', $post_content ) ) ), static fn( $t ) => strpos( $t, '@' ) === 0 ) ),
    'video post_content tokens'  => array_values( array_filter( array_map( 'trim', explode( ' ', str_replace( "\n", ' ', $post_content_v ) ) ), static fn( $t ) => strpos( $t, '@' ) === 0 ) ),
];

$base_set        = (array) ( $validated['mentions'] ?? [] );
$all_consistent  = true;
foreach ( $hop_shapes as $hop => $shape ) {
    $is_subset = empty( array_diff( $shape, $base_set ) ) && empty( array_diff( $base_set, $shape ) );
    if ( ! $is_subset ) {
        $all_consistent = false;
        $failMsg[] = "SSOT mismatch at hop '{$hop}': " . var_export( $shape, true ) . ' vs base ' . var_export( $base_set, true );
    }
}
assert_true( 'Every hop carries the exact same @handle set', $all_consistent );

// ───────────────────────────────────────────────────────────────────────────
//  SUMMARY
// ───────────────────────────────────────────────────────────────────────────

echo "\n══════════════════════════════════════════════════════════════\n";
echo "  RESULT: {$passed} passed, {$failed} failed\n";
echo "══════════════════════════════════════════════════════════════\n\n";

if ( ! empty( $failMsg ) ) {
    foreach ( $failMsg as $m ) {
        echo "  — {$m}\n";
    }
    exit( 1 );
}
exit( 0 );