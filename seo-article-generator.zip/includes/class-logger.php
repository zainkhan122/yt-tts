<?php

/**
 * Logger
 *
 * @package SEO_Article_Generator
 */

namespace SEO_Article_Generator;

// Prevent direct access
if (! defined('ABSPATH')) {
    exit;
}

/**
 * Logging system for debugging and monitoring
 */
class Logger
{
    /**
     * Log levels
     */
    const LEVEL_DEBUG = 'DEBUG';
    const LEVEL_INFO = 'INFO';
    const LEVEL_WARNING = 'WARNING';
    const LEVEL_ERROR = 'ERROR';

    /**
     * Log file path
     *
     * @var string
     */
    private $log_file;

    /**
     * Whether logging is enabled
     *
     * @var bool
     */
    private $enabled;

    /**
     * Constructor
     */
    public function __construct()
    {
        $upload_dir = \wp_upload_dir();
        $log_dir = $upload_dir['basedir'] . '/seo-generator-logs';

        if (! file_exists($log_dir)) {
            \wp_mkdir_p($log_dir);
            file_put_contents($log_dir . '/.htaccess', 'Deny from all');
        }

        $utc_now = Utils\Plugin_Time::utc_mysql_now();

        $this->log_file = $log_dir . '/seo-generator-' . substr($utc_now, 0, 10) . '.log';
        $this->enabled  = (bool) \get_option('seo_gen_enable_logging', true);

        if ($this->enabled) {
            $retention = (int) \get_option('seo_gen_log_retention', 7);
            if ($retention > 0) {
                $this->clear_old_logs($retention);
            }
        }
    }

    /**
     * Log debug message
     *
     * @param string $message Log message
     * @param array  $context Additional context
     * @return void
     */
    public function debug($message, $context = array())
    {
        $this->log(self::LEVEL_DEBUG, $message, $context);
    }

    /**
     * Log info message
     *
     * @param string $message Log message
     * @param array  $context Additional context
     * @return void
     */
    public function info($message, $context = array())
    {
        $this->log(self::LEVEL_INFO, $message, $context);
    }

    /**
     * Log warning message
     *
     * @param string $message Log message
     * @param array  $context Additional context
     * @return void
     */
    public function warning($message, $context = array())
    {
        $this->log(self::LEVEL_WARNING, $message, $context);
    }

    /**
     * Log error message
     *
     * @param string $message Log message
     * @param array  $context Additional context
     * @return void
     */
    public function error($message, $context = array())
    {
        $this->log(self::LEVEL_ERROR, $message, $context);
    }

    /**
     * Mask sensitive keys in context (API keys, tokens, etc.)
     *
     * @param array $context
     * @return array
     */
    private function mask_secrets($context)
    {
        if (empty($context)) {
            return $context;
        }

        $sensitive_keys = array(
            'api_key',
            'key',
            'token',
            'password',
            'secret',
            'authorization',
            'Gemini-Key',
            'X-API-Key'
        );

        foreach ($context as $key => &$value) {
            if (is_array($value)) {
                $value = $this->mask_secrets($value);
            } elseif (is_string($value)) {
                $is_sensitive = false;
                foreach ($sensitive_keys as $sk) {
                    if (stripos($key, $sk) !== false) {
                        $is_sensitive = true;
                        break;
                    }
                }

                if ($is_sensitive && strlen($value) > 8) {
                    $value = substr($value, 0, 4) . '...' . substr($value, -4);
                }
            }
        }

        return $context;
    }

    /**
     * Write log entry
     *
     * @param string $level Log level
     * @param string $message Log message
     * @param array  $context Additional context
     * @return void
     */
    private function log($level, $message, $context = array())
    {
        if (! $this->enabled) {
            return;
        }

        $context = $this->mask_secrets($context);

        $timestamp   = Utils\Plugin_Time::utc_mysql_now();
        $context_str = ! empty($context) ? ' ' . wp_json_encode($context) : '';

        $log_entry = sprintf(
            "[%s] [%s] %s%s\n",
            $timestamp,
            $level,
            $message,
            $context_str
        );

        error_log($log_entry, 3, $this->log_file);

        if (defined('WP_DEBUG') && WP_DEBUG && in_array($level, [self::LEVEL_WARNING, self::LEVEL_ERROR], true)) {
            error_log("SEO Generator: [{$level}] {$message}");
        }
    }

    /**
     * Get recent log entries
     *
     * @param int $lines Number of lines to retrieve
     * @return array
     */
    public function get_recent_logs($lines = 100)
    {
        if (! file_exists($this->log_file)) {
            return array();
        }

        // Read last N lines from log file
        $file = new \SplFileObject($this->log_file, 'r');
        $file->seek(PHP_INT_MAX);
        $last_line = $file->key();
        $start_line = max(0, $last_line - $lines);

        $log_entries = array();
        $file->seek($start_line);

        while (! $file->eof()) {
            $line = trim($file->fgets());
            if ($line) {
                $log_entries[] = $line;
            }
        }

        return $log_entries;
    }

    /**
     * Clear old log files
     *
     * @param int $days_to_keep Number of days to keep logs
     * @return int Number of files deleted
     */
    public function clear_old_logs($days_to_keep = 7)
    {
        $upload_dir = \wp_upload_dir();
        $log_dir = $upload_dir['basedir'] . '/seo-generator-logs';

        if (! file_exists($log_dir)) {
            return 0;
        }

        $deleted = 0;
        $cutoff_time = time() - ($days_to_keep * \DAY_IN_SECONDS);

        $files = glob($log_dir . '/seo-generator-*.log');
        foreach ($files as $file) {
            if (filemtime($file) < $cutoff_time) {
                if (unlink($file)) {
                    $deleted++;
                }
            }
        }

        return $deleted;
    }

    /**
     * Delete all log files
     *
     * @return int Number of files deleted
     */
    public function clear_all_logs()
    {
        $upload_dir = \wp_upload_dir();
        $log_dir = $upload_dir['basedir'] . '/seo-generator-logs';

        if (! file_exists($log_dir)) {
            return 0;
        }

        $deleted = 0;
        $files = glob($log_dir . '/seo-generator-*.log');
        foreach ($files as $file) {
            if (unlink($file)) {
                $deleted++;
            }
        }

        return $deleted;
    }

    /**
     * Get list of all log files
     *
     * @return array Array of log file names and sizes
     */
    public function get_log_files()
    {
        $upload_dir = \wp_upload_dir();
        $log_dir = $upload_dir['basedir'] . '/seo-generator-logs';

        if (! file_exists($log_dir)) {
            return array();
        }

        $files = glob($log_dir . '/seo-generator-*.log');
        $log_files = array();

        foreach ($files as $file) {
            $log_files[] = array(
                'name' => basename($file),
                'path' => $file,
                'date' => str_replace(array('seo-generator-', '.log'), '', basename($file)),
                'size' => \size_format(filesize($file)),
                'mtime' => filemtime($file)
            );
        }

        // Sort by date descending
        usort($log_files, function ($a, $b) {
            return $b['mtime'] - $a['mtime'];
        });

        return $log_files;
    }

    /**
     * Read content of a specific log file
     *
     * @param string $filename Log filename
     * @return string
     */
    public function read_log_file($filename)
    {
        $upload_dir = \wp_upload_dir();
        $log_dir = $upload_dir['basedir'] . '/seo-generator-logs';
        $file_path = $log_dir . '/' . \sanitize_file_name($filename);

        if (! file_exists($file_path) || strpos($file_path, 'seo-generator-') === false) {
            return '';
        }

        return file_get_contents($file_path);
    }

    /**
     * Delete a specific log file
     * 
     * @MODIFIED 2026-03-04: Added for "Delete This Log" button functionality
     *
     * @param string $filename Log filename
     * @return bool True on success, false on failure
     */
    public function delete_log_file($filename)
    {
        $upload_dir = \wp_upload_dir();
        $log_dir = $upload_dir['basedir'] . '/seo-generator-logs';
        $file_path = $log_dir . '/' . \sanitize_file_name((string)$filename);

        // Security check: ensure file exists and is a log file within the log directory
        if (! file_exists($file_path) || strpos((string)$filename, 'seo-generator-') === false || strpos((string)$filename, '.log') === false) {
            return false;
        }

        return unlink($file_path);
    }

    /**
     * Get log file path
     *
     * @return string
     */
	public function get_log_file()
	{
		return $this->log_file;
	}

	/**
	 * Count total lines in an external log file.
	 *
	 * @param string $file_path Absolute path to the external log file.
	 * @return int Total line count, or 0 on failure.
	 */
	public function count_external_log_lines($file_path)
	{
		$file_path = (string) $file_path;

		if ($file_path === '' || strpos($file_path, '..') !== false) {
			return 0;
		}

		if (!file_exists($file_path) || !is_readable($file_path)) {
			return 0;
		}

		$count = 0;
		$handle = fopen($file_path, 'rb');
		if ($handle === false) {
			return 0;
		}

		while (!feof($handle)) {
			$chunk = fread($handle, 8192);
			$count += substr_count($chunk, "\n");
		}
		fclose($handle);

		return $count;
	}

	/**
	 * Read a paginated slice of lines from an external log file.
	 *
	 * @param string $file_path   Absolute path to the external log file.
	 * @param int    $page        1-based page number.
	 * @param int    $lines_per_page Lines per page (default 100).
	 * @return array Associative array with 'lines', 'total_lines', 'page', 'total_pages', or empty array on failure.
	 */
	public function read_external_log_paginated($file_path, $page = 1, $lines_per_page = 100)
	{
		$file_path = (string) $file_path;
		$page = max(1, (int) $page);
		$lines_per_page = max(10, min(500, (int) $lines_per_page));

		if ($file_path === '' || strpos($file_path, '..') !== false) {
			return array();
		}

		$ext = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
		if ($ext !== 'log' && $ext !== 'txt') {
			return array();
		}

		if (!file_exists($file_path) || !is_readable($file_path)) {
			return array();
		}

		$total_lines = $this->count_external_log_lines($file_path);
		$total_pages = $total_lines > 0 ? (int) ceil($total_lines / $lines_per_page) : 1;

		if ($page > $total_pages) {
			$page = $total_pages;
		}

		$start_line = ($page - 1) * $lines_per_page;

		$file = new \SplFileObject($file_path, 'rb');
		$file->seek($start_line);

		$lines = array();
		$count = 0;
		while (!$file->eof() && $count < $lines_per_page) {
			$line = $file->fgets();
			if ($line === false && $file->eof()) {
				break;
			}
			$lines[] = rtrim($line, "\r\n");
			$count++;
		}
		$file = null;

		return array(
			'lines'        => $lines,
			'total_lines'  => $total_lines,
			'page'         => $page,
			'total_pages'  => $total_pages,
			'per_page'     => $lines_per_page,
		);
	}

	/**
	 * Get metadata about an external log file.
	 *
	 * @param string $file_path Absolute path to the external log file.
	 * @return array|null Associative array with 'size' and 'mtime', or null if invalid.
	 */
	public function get_external_log_info($file_path)
	{
		$file_path = (string) $file_path;

		if ($file_path === '' || strpos($file_path, '..') !== false) {
			return null;
		}

		if (!file_exists($file_path) || !is_readable($file_path)) {
			return null;
		}

		return array(
			'size'  => \size_format(filesize($file_path)),
			'mtime' => \date_i18n(\get_option('date_format') . ' ' . \get_option('time_format'), filemtime($file_path)),
		);
	}
}
