<?php
/**
 * Comprehensive Test for [BEST PLAN] Modifications
 * Specifically targeting the 7 failed posts from logs.txt
 */

namespace {
    if (!defined('ABSPATH')) {
        define('ABSPATH', dirname(__DIR__) . '/');
    }

    if (!defined('WP_DEBUG')) {
        define('WP_DEBUG', false);
    }

    // Mock WordPress functions
    if (!function_exists('get_option')) {
        function get_option($option, $default = false) {
            $options = [
		'seo_gen_validation_threshold' => 75
            ];
            return $options[$option] ?? $default;
        }
    }
    if (!function_exists('wp_strip_all_tags')) {
        function wp_strip_all_tags($string, $remove_breaks = false) {
            $string = preg_replace('@<(script|style)[^>]*?>.*?</\\1>@si', '', $string);
            $string = strip_tags($string);
            if ($remove_breaks) {
                $string = preg_replace('/[\r\n\t ]+/', ' ', $string);
            }
            return trim($string);
        }
    }
    if (!function_exists('wp_parse_url')) {
        function wp_parse_url($url, $c = -1) {
            return parse_url($url, $c);
        }
    }
    if (!function_exists('wp_parse_str')) {
        function wp_parse_str($s, &$r) {
            parse_str($s, $r);
        }
    }
    if (!function_exists('sanitize_text_field')) {
        function sanitize_text_field($s) {
            return trim(strip_tags(stripslashes($s)));
        }
    }
    if (!function_exists('esc_url_raw')) {
        function esc_url_raw($u) {
            return $u;
        }
    }
}

namespace SEO_Article_Generator\Traits {
    if (!trait_exists('SEO_Article_Generator\Traits\Type_Safety')) {
        require_once dirname(__DIR__) . '/includes/traits/trait-type-safety.php';
    }
}

namespace SEO_Article_Generator\Generator {
    if (!class_exists('SEO_Article_Generator\Generator\Download_Link_Helper')) {
        require_once dirname(__DIR__) . '/includes/generator/class-download-link-helper.php';
    }
    if (!class_exists('SEO_Article_Generator\Generator\Phrase_Variator')) {
        class Phrase_Variator {
            public static function get_alternatives($phrase) { return [$phrase]; }
        }
    }
}

namespace SEO_Article_Generator\Validation {
    if (!class_exists('SEO_Article_Generator\Validation\Threshold_Config')) {
        require_once dirname(__DIR__) . '/includes/validation/class-threshold-config.php';
    }
    if (!class_exists('SEO_Article_Generator\Validation\ChangelogVerifier')) {
        class ChangelogVerifier {
            public function verify($changelog, $version) { return true; }
        }
    }
    if (!class_exists('SEO_Article_Generator\Validation\Scoring_Engine')) {
        class Scoring_Engine {
            public function calculate_score($article, $input_data, $mode) { return 100; }
            public function get_download_section_score($article) { return 15; }
        }
    }
}

namespace SEO_Article_Generator {
    if (!class_exists('SEO_Article_Generator\Validation_Exception')) {
        class Validation_Exception extends \Exception {}
    }
}

namespace SEO_Article_Generator\Tests {
    require_once dirname(__DIR__) . '/includes/validation/class-validator.php';
    require_once dirname(__DIR__) . '/includes/generator/class-surgical-patcher.php';

    use SEO_Article_Generator\Validation\Validator;
    use SEO_Article_Generator\Generator\Surgical_Patcher;

    function run_test($name, $callback) {
        echo "Testing: {$name}... ";
        try {
            $callback();
            echo "✅ PASSED\n";
        } catch (\Exception $e) {
            echo "❌ FAILED: " . $e->getMessage() . "\n" . $e->getTraceAsString() . "\n";
        }
    }

    // =========================================================================
    // TEST CASE 1: Validator Structural Priority (Meta Description Length)
    // Targets: Directory Opus (Failed with "Meta description too long: 165 chars")
    // =========================================================================
    run_test("Validator: Meta Description Length (Error -> Warning)", function() {
        $validator = new Validator();
        $article = [
            'title' => 'Test Software',
            'introduction' => 'This is a long introduction that meets the minimum length requirements for a portal-grade content. It should be at least a few sentences long to avoid length errors.',
            'tech_specs' => [
                'software_name' => 'Test Software',
                'version' => '1.0.0'
            ],
            'meta_description' => str_repeat('a', 170), // > 160
            'html_content' => '<p>Some content for the article body. It should be enough to satisfy any other basic checks.</p>',
            'download_section' => ['links' => [['url' => 'https://test.com', 'text' => 'Download']]],
            'features' => ['Feature 1', 'Feature 2', 'Feature 3', 'Feature 4', 'Feature 5'],
            'system_requirements' => 'Win 10',
            'faqs' => [['q' => 'A?', 'a' => 'B.']],
            'safety' => 'Safe'
        ];
        $input_data = ['is_update' => true];
        
        $result = $validator->validate($article, $input_data);
        
        if (!$result['passed']) {
            throw new \Exception("Validation failed despite Meta Desc being a warning. Errors: " . implode(', ', $result['errors']));
        }
        
        $has_warning = false;
        foreach ($result['warnings'] as $warning) {
            if (strpos($warning, 'Meta description too long') !== false || strpos($warning, 'Meta description slightly long') !== false) {
                $has_warning = true;
                break;
            }
        }
        
        if (!$has_warning) {
            throw new \Exception("Warning for long meta description not found. Warnings found: " . implode(', ', $result['warnings']));
        }
    });

    // =========================================================================
    // TEST CASE 2: Validator Structural Priority (Missing Links on Update)
    // Targets: Brave Browser, MX Player, KLS Backup 2025
    // =========================================================================
    run_test("Validator: Missing Download Links on Update (Error -> Warning)", function() {
        $validator = new Validator();
        $article = [
            'title' => 'MX Player',
            'introduction' => 'This is an introduction for the software update. It should be descriptive enough for validation.',
            'tech_specs' => [
                'software_name' => 'MX Player',
                'version' => '2.10.1'
            ],
            'meta_description' => 'A valid meta description for the software update.',
            'html_content' => '<p>Some content for the article update.</p>',
            'download_section' => ['links' => []], // EMPTY LINKS
            'features' => ['F1', 'F2', 'F3', 'F4', 'F5'],
            'system_requirements' => 'Android',
            'faqs' => [['q' => 'Q?', 'a' => 'A.']],
            'safety' => 'Safe'
        ];
        $input_data = ['is_update' => true];
        
        $result = $validator->validate($article, $input_data);
        
        if (!$result['passed']) {
            throw new \Exception("Validation failed for missing links on update. Errors: " . implode(', ', $result['errors']));
        }
        
        $has_warning = false;
        foreach ($result['warnings'] as $warning) {
            if (strpos($warning, 'No download links found') !== false || strpos($warning, 'Missing real download link') !== false) {
                $has_warning = true;
                break;
            }
        }
        
        if (!$has_warning) {
            throw new \Exception("Warning for missing links not found. Warnings: " . implode(', ', $result['warnings']));
        }
    });

    // =========================================================================
    // TEST CASE 3: Surgical Patcher (Range Overlap Fix) - SKIPPED
    // =========================================================================
    echo "Testing: Surgical_Patcher: dedupe_ranges with Overlaps... ⏩ SKIPPED (Block-based parser doesn't use ranges)\n";

    // =========================================================================
    // TEST CASE 4: Smart Injection after Introduction - SKIPPED
    // =========================================================================
    echo "Testing: Surgical_Patcher: Smart Injection after Introduction... ⏩ SKIPPED (Block-based parser doesn't use signatures)\n";

    echo "\n--- ALL TESTS COMPLETED ---\n";
}
