<?php

/**
 * Dashboard View
 * 
 * @var int $api_usage
 * @var int $posts_generated_today
 * @var int $total_posts
 * @var int $errors_today
 * @var array $recent_jobs
 * @var array $recent_errors
 * @var array $social_shares_data
 */

defined('ABSPATH') || exit;
?>

<div class="wrap dit-ts-dashboard">
    <h1 style="display: none;"></h1>
    <hr class="wp-header-end" style="display: none;">
    <div class="dit-ts-header">
        <h2 style="margin: 0; font-size: 24px; font-weight: 600; color: #1d2327;"><?php _e('TrendStudio Dashboard', 'dit-trend-content-studio'); ?></h2>
        <div class="dit-ts-actions">
            <!-- @MODIFIED 2026-02-10 - Fixed status persistence: Match option name used in Plugin.php toggle handler -->
            <?php
            $automation_enabled = (int) get_option('dit_ts_enable_ai_automation', 1);
            $toggle_class = $automation_enabled ? 'button-active' : 'button-paused';
            $toggle_text = $automation_enabled ? __('AI Automation: RUNNING', 'dit-trend-content-studio') : __('AI Automation: PAUSED', 'dit-trend-content-studio');
            ?>
            <button type="button" class="button dit-ts-master-toggle <?php echo esc_attr($toggle_class); ?>" id="dit-ts-master-automation-toggle-btn" data-enabled="<?php echo $automation_enabled; ?>">
                <span class="dashicons <?php echo $automation_enabled ? 'dashicons-controls-play' : 'dashicons-controls-pause'; ?> dit-ts-btn-icon"></span>
                <span class="btn-text"><?php echo esc_html($toggle_text); ?></span>
            </button>

            <button type="button" class="button button-link-delete" id="dit-ts-emergency-stop" style="color: #d63638; border: 1px solid #f87171; background: #fff;">
                <span class="dashicons dashicons-no-alt dit-ts-btn-icon"></span>
                <?php _e('Emergency Stop', 'dit-trend-content-studio'); ?>
            </button>

            <!-- Link to the old generator page -->
            <a href="<?php echo esc_url(admin_url('admin.php?page=dit-trend-studio-generator')); ?>" class="button button-primary">
                <?php _e('Generate New Article', 'dit-trend-content-studio'); ?>
            </a>
            <a href="<?php echo esc_url(admin_url('admin.php?page=dit-ts-settings')); ?>" class="button button-secondary">
                <?php _e('Settings', 'dit-trend-content-studio'); ?>
            </a>
        </div>
    </div>

    <!-- Stats Grid -->
    <div class="dit-ts-stats-grid">
        <!-- Posts Today -->
        <div class="dit-ts-card">
            <div class="dit-ts-stat-label"><?php _e('Posts Created Today', 'dit-trend-content-studio'); ?></div>
            <div class="dit-ts-stat-value"><?php echo esc_html(number_format_i18n($posts_generated_today)); ?></div>
            <div class="dit-ts-stat-sub"><?php _e('24h Window', 'dit-trend-content-studio'); ?></div>
        </div>

        <!-- Total Articles -->
        <div class="dit-ts-card">
            <div class="dit-ts-stat-label"><?php _e('Total Articles', 'dit-trend-content-studio'); ?></div>
            <div class="dit-ts-stat-value"><?php echo esc_html(number_format_i18n($total_posts)); ?></div>
            <div class="dit-ts-stat-sub">
<?php _e('Lifetime', 'dit-trend-content-studio'); ?>
                <span style="display:inline-block; margin-left:8px; padding-left:8px; border-left:1px solid #ddd; color: #64748b;">
                    <?php printf(__('Job History: %s MB', 'dit-trend-content-studio'), $table_size_mb ?: '0'); ?>
                </span>
            </div>
        </div>

<?php /* DIT Video Shorts card (optional module) — safe no-op if module inactive. */ ?>
<?php if (class_exists('\\DIT\\TrendStudio\\Video\\Module')) :
    try {
        $dv_module = \DIT\TrendStudio\Video\Module::instance();
        if ($dv_module->settings->is_active()) {
            global $wpdb;
            $dv_total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key='_dit_ts_video_ready' AND meta_value='1'");
            $dv_queued = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key='_dit_ts_video_queued' AND meta_value='1'");
            ?>
            <div class="dit-ts-card" style="border-color:#7c3aed;">
                <div class="dit-ts-stat-label"><?php _e('Video Shorts Generated', 'dit-trend-content-studio'); ?></div>
                <div class="dit-ts-stat-value" style="color:#7c3aed;"><?php echo esc_html(number_format_i18n($dv_total)); ?></div>
                <div class="dit-ts-stat-sub"><?php printf(__('%s queued · %s', 'dit-trend-content-studio'), esc_html(number_format_i18n($dv_queued)), esc_html__('DIT Video', 'dit-trend-content-studio')); ?></div>
            </div>
            <?php
        }
    } catch (\Throwable $dv_err) {
        // no-op: module must never break the dashboard
    }
endif; ?>

<!-- API Usage -->
<?php
$usage_color = $total_api_calls_today > 1000 ? '#d63638' : ($total_api_calls_today > 100 ? '#2271b1' : 'inherit');
$usage_text_color = $total_api_calls_today > 1000 ? '#d63638' : 'inherit';
$has_quota_pause = !empty($quota_pauses);
?>
<div class="dit-ts-card" style="<?php echo $total_api_calls_today > 1000 ? 'border-color: #d63638;' : ''; ?><?php echo $has_quota_pause ? 'border-color: #d63638; background: #fef2f2;' : ''; ?>">
<div class="dit-ts-stat-label"><?php _e('API Usage (All Providers)', 'dit-trend-content-studio'); ?></div>
<div class="dit-ts-stat-value" style="color: <?php echo $usage_text_color; ?>; font-size: 24px;">
<?php echo esc_html(number_format_i18n($total_api_calls)); ?>
<span style="display:block; font-size: 14px; color: #64748b; font-weight: normal; margin-top: 4px;">
<?php printf(__('Today: %s', 'dit-trend-content-studio'), number_format_i18n($total_api_calls_today)); ?>
</span>
</div>
<?php if ($has_quota_pause) : ?>
<div class="dit-ts-quota-pause-alert" style="margin-top: 12px; padding: 10px; background: #fff5f5; border: 1px solid #fca5a5; border-radius: 4px;">
<?php foreach ($quota_pauses as $slug => $pause) : ?>
<div style="margin-bottom: 8px;">
<span class="dashicons dashicons-warning" style="color: #d63638; vertical-align: middle; font-size: 16px; margin-right: 4px;"></span>
<strong style="color: #d63638;"><?php echo esc_html($pause['label']); ?>: <?php esc_html_e('Quota Paused', 'dit-trend-content-studio'); ?></strong>
<div style="font-size: 11px; color: #64748b; margin: 2px 0 0 20px;">
<?php
$reason_labels = [
    'daily_quota_exhausted' => __('Daily quota exhausted', 'dit-trend-content-studio'),
    'quota_probe_failed' => __('Probe failed (retrying)', 'dit-trend-content-studio'),
    'quota_runtime_hit' => __('Runtime quota hit', 'dit-trend-content-studio'),
    'quota' => __('Quota limit reached', 'dit-trend-content-studio'),
];
echo esc_html($reason_labels[$pause['reason']] ?? $pause['reason']);
echo ' &mdash; ' . sprintf(__('Resumes in %s', 'dit-trend-content-studio'), $pause['remaining']);
?>
</div>
<button type="button" class="button button-small dit-ts-deactivate-pause" data-provider="<?php echo esc_attr($slug); ?>" style="margin-top: 6px; color: #b91c1c; border-color: #fca5a5;">
<span class="dashicons dashicons-controls-play" style="font-size: 14px; width: 14px; height: 14px; vertical-align: middle; margin-right: 2px;"></span>
<?php esc_html_e('Deactivate Pause', 'dit-trend-content-studio'); ?>
</button>
<span class="deactivate-pause-result" data-provider="<?php echo esc_attr($slug); ?>" style="display: block; font-size: 11px; margin-top: 4px;"></span>
</div>
<?php endforeach; ?>
</div>
<?php endif; ?>
<div class="dit-ts-usage-breakdown" style="margin-top: 15px; border-top: 1px solid #eee; padding-top: 10px;">
                <table style="width: 100%; font-size: 11px; color: #64748b;">
                    <?php foreach ($all_api_stats as $slug => $stats) : ?>
                        <tr>
                            <td style="padding: 2px 0;"><?php echo esc_html($stats['label']); ?></td>
                            <td style="text-align: right; padding: 2px 0; font-weight: 500;">
                                <?php echo number_format($stats['today']); ?> / <?php echo number_format($stats['total']); ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            </div>
        </div>

        <!-- Health/Errors -->
    <div class="dit-ts-card" style="<?php echo ($errors_today > 0 || $as_health === 'Stalled') ? 'border-color: #f87171;' : (($as_health === 'Warning') ? 'border-color: #f59e0b;' : ''); ?>">
        <div class="dit-ts-stat-label"><?php _e('System Health', 'dit-trend-content-studio'); ?></div>
        <div class="dit-ts-stat-value" style="<?php echo ($errors_today > 0 || $as_health === 'Stalled') ? 'color: #d63638;' : (($as_health === 'Warning') ? 'color: #f59e0b;' : 'color: #166534;'); ?>">
            <?php
            if ($errors_today > 0) {
                echo esc_html($errors_today) . ' ' . __('Errors', 'dit-trend-content-studio');
            } else {
                echo esc_html($as_health);
            }
            ?>
        </div>
        <div class="dit-ts-stat-sub">
            <?php
            // @MODIFIED 2026-04-18 - Show health details and server cron mode indicator
            if (!empty($as_health_details)) {
                echo '<span style="color:#666;">' . esc_html($as_health_details) . '</span><br>';
            }

            if ($as_health === 'Stalled') {
                _e('Scheduler Stalled', 'dit-trend-content-studio');
                echo '<br><a href="#" id="dit-ts-repair-queue" style="color:#d63638; text-decoration:underline;">' . __('Repair Now', 'dit-trend-content-studio') . '</a>';
                echo '<span class="repair-result" style="display:block; font-size:11px; margin-top:4px;"></span>';
            } elseif ($as_health === 'Warning') {
                _e('Monitor queue activity', 'dit-trend-content-studio');
            } elseif ($errors_today > 0) {
                _e('Errors Reported Today', 'dit-trend-content-studio');
            } else {
                _e('Scheduler & API: OK', 'dit-trend-content-studio');
            }

            // @MODIFIED 2026-02-12 - Emergency Reset Button
            echo '<div style="margin-top:12px; padding-top:12px; border-top:1px solid #eee;">';
            echo '<button type="button" class="button button-small" id="dit-ts-reset-system" title="' . esc_attr__('Clears all locks and transcripts to fix "busy" errors.', 'dit-trend-content-studio') . '">';
            echo '<span class="dashicons dashicons-rest" style="font-size:16px; width:16px; height:16px; margin-top:2px;"></span> ';
            echo __('Reset System Status', 'dit-trend-content-studio');
            echo '</button>';
            echo '<span class="reset-system-result" style="display:block; font-size:11px; margin-top:4px;"></span>';
            echo '</div>';
            ?>
        </div>
    </div>

    <!-- Active Campaigns -->
    <div class="dit-ts-card" style="grid-column: span 2;">
        <div class="dit-ts-stat-label"><?php _e('Active Campaigns', 'dit-trend-content-studio'); ?></div>
        <div class="dit-ts-campaign-list" style="margin-top:10px;">
            <?php
            $campaigns = json_decode(get_option('dit_ts_campaigns', '[]'), true);
            $active_count = 0;
            if (!empty($campaigns)) {
                echo '<table style="width:100%; font-size:13px; text-align:left;">';
                foreach ($campaigns as $c) {
                    if (empty($c['active']) || empty($c['id'])) continue;
                    $active_count++;

                    $next_run = 'Not Scheduled';
                    if (function_exists('as_next_scheduled_action')) {
                        $ts = as_next_scheduled_action('dit_ts_run_campaign', ['campaign_id' => $c['id']], 'dit_ts_campaigns');
                        if ($ts) {
                            $next_run = sprintf(__('In %s', 'dit-trend-content-studio'), human_time_diff($ts));
                        }
                    }

                    echo '<tr>';
                    echo '<td style="padding:4px 0;"><strong>' . esc_html($c['name']) . '</strong></td>';
                    echo '<td style="color:#666;">' . esc_html(ucfirst(str_replace('_', ' ', $c['schedule'] ?? 'manual'))) . '</td>';
                    echo '<td style="text-align:right; color:#2271b1;">' . esc_html($next_run) . '</td>';
                    echo '</tr>';
                }
                echo '</table>';
            }

            if ($active_count === 0) {
                echo '<p style="color:#888; font-style:italic;">' . __('No active campaigns.', 'dit-trend-content-studio') . '</p>';
            }
            ?>
        </div>
    </div>

    <!-- Next Scheduled Post -->
         <div class="dit-ts-card">
             <div class="dit-ts-stat-label"><?php _e('Next Schedule', 'dit-trend-content-studio'); ?></div>
             <div class="dit-ts-stat-value" style="font-size: 24px;">
                 <?php
                 // Find nearest scheduled time across all campaigns
                 $nearest_next = 0;
                 if (function_exists('as_next_scheduled_action')) {
                     $campaigns_for_next = json_decode(get_option('dit_ts_campaigns', '[]'), true);
                     if (!empty($campaigns_for_next)) {
                         foreach ($campaigns_for_next as $c_next) {
                             if (empty($c_next['active']) || empty($c_next['id'])) continue;
                             $ts_next = as_next_scheduled_action('dit_ts_run_campaign', ['campaign_id' => $c_next['id']], 'dit_ts_campaigns');
                             if ($ts_next && ($nearest_next === 0 || $ts_next < $nearest_next)) {
                                 $nearest_next = $ts_next;
                             }
                         }
                     }
                 }
                 $next_run_display = $nearest_next;
                 if ($next_run_display) {
                     echo esc_html(wp_date(get_option('time_format'), $next_run_display));
                 } else {
                     echo '<span style="font-size:16px; color:#a7aaad;">' . __('Not Scheduled', 'dit-trend-content-studio') . '</span>';
                 }
                 ?>
             </div>
             <div class="dit-ts-stat-sub">
                 <?php
                 if ($next_run_display && is_numeric($next_run_display)) {
                     $diff = human_time_diff($next_run_display);
                     echo sprintf(__('In %s', 'dit-trend-content-studio'), $diff);
                 } else {
                     _e('Check Settings', 'dit-trend-content-studio');
                 }
                 ?>
             </div>
         </div>

         <!-- Social Shares Card -->
         <!-- @MODIFIED 2026-06-07 - Enhanced layout: monthly label, provider color dots, totals row -->
         <div class="dit-ts-card">
             <div class="dit-ts-card-header" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
                 <div class="dit-ts-stat-label" style="margin:0;"><?php _e('Social Shares', 'dit-trend-content-studio'); ?></div>
                 <div style="font-size:11px; color:#94a3b8;"><?php echo esc_html(date('M Y')); ?></div>
             </div>
             <div class="dit-ts-social-shares-summary">
                 <table style="width: 100%; font-size: 12px; border-collapse: collapse;">
                     <thead>
                         <tr style="text-align: left; color: #64748b; border-bottom: 2px solid #e2e8f0;">
                             <th style="padding-bottom: 6px; width: 40%;"><?php _e('Platform', 'dit-trend-content-studio'); ?></th>
                             <th style="padding-bottom: 6px; text-align: center; width: 30%;"><span style="color: #8b5cf6;">&#9679;</span> <?php _e('Jetpack', 'dit-trend-content-studio'); ?></th>
                             <th style="padding-bottom: 6px; text-align: center; width: 30%;"><span style="color: #059669;">&#9679;</span> <?php _e('Buffer', 'dit-trend-content-studio'); ?></th>
                         </tr>
                     </thead>
                     <tbody>
                         <?php
                         $total_jetpack = 0;
                         $total_buffer = 0;
                         foreach ($social_shares_data as $platform => $counts) :
                             $platform_label = ucfirst($platform);
                             if ($platform === 'twitter') $platform_label = 'X (Twitter)';
                             $total_jetpack += $counts['jetpack'];
                             $total_buffer += $counts['buffer'];
                         ?>
                             <tr style="border-bottom: 1px solid #f8fafc;">
                                 <td style="padding: 8px 0; font-weight: 500; text-transform: capitalize;"><?php echo esc_html($platform_label); ?></td>
                                 <td style="text-align: center; padding: 8px 0; font-weight: 600; color: #8b5cf6;"><?php echo esc_html($counts['jetpack']); ?></td>
                                 <td style="text-align: center; padding: 8px 0; font-weight: 600; color: #059669;"><?php echo esc_html($counts['buffer']); ?></td>
                             </tr>
                         <?php endforeach; ?>
                         <?php if (!empty($social_shares_data)) : ?>
                             <tr style="border-top: 2px solid #e2e8f0; font-weight: 700;">
                                 <td style="padding: 8px 0;"><?php _e('Total', 'dit-trend-content-studio'); ?></td>
                                 <td style="text-align: center; padding: 8px 0; color: #8b5cf6; font-size: 13px;"><?php echo esc_html($total_jetpack); ?></td>
                                 <td style="text-align: center; padding: 8px 0; color: #059669; font-size: 13px;"><?php echo esc_html($total_buffer); ?></td>
                             </tr>
                         <?php endif; ?>
                     </tbody>
                 </table>
                 <?php if (empty($social_shares_data)) : ?>
                     <div style="text-align:center; padding: 15px 0; color: #94a3b8; font-size: 12px;">
                         <?php _e('No social shares recorded this month.', 'dit-trend-content-studio'); ?>
                     </div>
                 <?php endif; ?>
             </div>
         </div>
     </div>
 
     <!-- Main Content Grid -->

    <div class="dit-ts-section-grid">


        <!-- Recent Activity -->
        <div class="dit-ts-panel">
            <div class="dit-ts-panel-header">
                <h2><?php _e('Recent Generation Activity', 'dit-trend-content-studio'); ?></h2>
                <a href="<?php echo esc_url(admin_url('admin.php?page=dit-trend-studio-generator')); ?>" style="font-size:12px; text-decoration:none;">View All</a>
            </div>
            <div class="dit-ts-panel-body">
                <?php if (empty($recent_jobs)) : ?>
                    <div class="dit-ts-empty-state">
                        <p><?php _e('No recent activity found.', 'dit-trend-content-studio'); ?></p>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=dit-trend-studio-generator')); ?>" class="button button-small">
                            <?php _e('Start Generation', 'dit-trend-content-studio'); ?>
                        </a>
                    </div>
                <?php else : ?>
                    <table class="dit-ts-table">
                        <thead>
                            <tr>
                                <th><?php _e('Date', 'dit-trend-content-studio'); ?></th>
                                <th><?php _e('Title', 'dit-trend-content-studio'); ?></th>
                                <th><?php _e('Status', 'dit-trend-content-studio'); ?></th>
                                <th><?php _e('Action', 'dit-trend-content-studio'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_jobs as $job) :
                                $input = json_decode($job['input_data'], true);
                                $title = $input['idea_title'] ?? __('(No Title)', 'dit-trend-content-studio');
                                $status_class = $job['status'];
                                $post_id = $job['post_id'] ?? 0;
                            ?>
                                <tr>
                                    <td><?php echo esc_html(mysql2date(get_option('date_format') . ' ' . get_option('time_format'), $job['completed_at'] ?: $job['created_at'])); ?></td>
                                    <td><strong><?php echo esc_html(wp_trim_words($title, 8)); ?></strong></td>
                                    <td>
                                        <span class="dit-ts-pill <?php echo esc_attr($status_class); ?>">
                                            <?php echo esc_html(ucfirst($job['status'])); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <?php if ($post_id && $job['status'] === 'completed') : ?>
                                            <a href="<?php echo esc_url(get_edit_post_link($post_id)); ?>" class="dit-ts-link-btn" target="_blank">
                                                <?php _e('Edit Post', 'dit-trend-content-studio'); ?> &rarr;
                                            </a>
                                        <?php elseif ($job['status'] === 'failed') : ?>
                                            <span style="color:#d63638; font-size:12px;"><?php _e('Failed', 'dit-trend-content-studio'); ?></span>
                                        <?php else: ?>
                                            <span style="color:#a7aaad;">-</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <!-- Error Log Digest -->
        <div class="dit-ts-panel">
            <div class="dit-ts-panel-header">
                <h2><?php _e('Today\'s Issues', 'dit-trend-content-studio'); ?></h2>
                <a href="<?php echo esc_url(admin_url('admin.php?page=dit-ts-logs')); ?>" style="font-size:12px; text-decoration:none;">Full Log</a>
            </div>
            <div class="dit-ts-panel-body">
                <?php if (empty($recent_errors)) : ?>
                    <div class="dit-ts-empty-state" style="padding: 30px;">
                        <span style="font-size: 24px;">✅</span>
                        <p><?php _e('No system errors reported today.', 'dit-trend-content-studio'); ?></p>
                    </div>
                <?php else : ?>
                    <ul class="dit-ts-log-list">
                        <?php foreach (array_slice($recent_errors, 0, 5) as $error) : ?>
                            <li class="dit-ts-log-item">
                                <?php echo esc_html(substr($error, 0, 100)) . '...'; ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>

    </div>
</div>
