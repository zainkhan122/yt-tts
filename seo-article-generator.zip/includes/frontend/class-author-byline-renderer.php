<?php

/**
 * E-E-A-T Author Byline Renderer
 * 
 * Renders author attribution with credentials for frontend display.
 * NOTE: Frontend hook integration required - see implementation plan.
 *
 * @package SEO_Article_Generator
 * @since   2.2.0
 */

namespace SEO_Article_Generator\Frontend;

use SEO_Article_Generator\EEAT\Author_Profile_Manager;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Author Byline Renderer
 * @MODIFIED 2025-12-16 v2.2.0: Created for E-E-A-T frontend display
 */
class Author_Byline_Renderer
{

    private $author_manager;

    public function __construct()
    {
        $this->author_manager = new Author_Profile_Manager();
    }

    /**
     * Render complete author byline
     */
    public function render_byline($post_id, $position = 'footer', array $hero_data = array())
    {
        if (empty($hero_data)) {
            $plugin = \SEO_Article_Generator\Plugin::get_instance();
            $hero_data = $plugin->get_hero_data($post_id) ?: array();
        }

        $post = get_post($post_id);

        if (! $post) {
            return '';
        }

        $profile_manager = class_exists('SEO_Article_Generator\\EEAT\\Author_Profile_Manager')
            ? new \SEO_Article_Generator\EEAT\Author_Profile_Manager()
            : null;

        $author_profile = $profile_manager ? $profile_manager->get_author_profile((int) $post->post_author) : null;
        $reviewer_id    = (int) get_post_meta($post_id, '_seo_reviewed_by', true);
        $reviewer_profile = ($profile_manager && $reviewer_id > 0)
            ? $profile_manager->get_author_profile($reviewer_id)
            : null;

        $author_name   = $author_profile['name'] ?? '';
        $reviewer_name = $reviewer_profile['name'] ?? '';
        $verified_date = $hero_data['last_verified_date'] ?? '';

        if (! $author_profile) {
            return '';
        }

        ob_start();
?>
        <div class="seo-author-byline seo-author-byline--<?php echo esc_attr($position); ?>">

            <div class="seo-author-avatar">
                <a href="<?php echo esc_url($author_profile['posts_url']); ?>">
                    <img
                        src="<?php echo esc_url($author_profile['avatar_url']); ?>"
                        alt="<?php echo esc_attr($author_name); ?>"
                        width="60"
                        height="60" />
                </a>
            </div>

            <div class="seo-author-info">
                <div class="seo-author-name">
                    <a href="<?php echo esc_url($author_profile['posts_url']); ?>">
                        <?php echo esc_html($author_name); ?>
                    </a>

                    <?php if ($author_profile['verified']) : ?>
                        <span class="seo-verified-badge" title="Verified Author">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="#00a32a">
                                <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z" />
                            </svg>
                            Verified
                        </span>
                    <?php endif; ?>
                </div>

                <?php if ($author_profile['title']) : ?>
                    <div class="seo-author-title">
                        <?php echo esc_html($author_profile['title']); ?>
                    </div>
                <?php endif; ?>

                <?php if ($author_profile['credentials'] && $position === 'footer') : ?>
                    <div class="seo-author-credentials">
                        <?php echo esc_html($author_profile['credentials']); ?>
                    </div>
                <?php endif; ?>

                <?php if ($author_profile['bio'] && $position === 'footer') : ?>
                    <div class="seo-author-bio">
                        <?php echo esc_html(wp_trim_words($author_profile['bio'], 50)); ?>
                    </div>
                <?php endif; ?>

                <?php if (! empty($author_profile['social_links']) && $position === 'footer') : ?>
                    <div class="seo-author-social">
                        <?php foreach ($author_profile['social_links'] as $platform => $url) : ?>
                            <a
                                href="<?php echo esc_url($url); ?>"
                                target="_blank"
                                rel="noopener"
                                class="seo-social-link seo-social-link--<?php echo esc_attr($platform); ?>"
                                title="<?php echo esc_attr(ucfirst($platform)); ?>">
                                <?php echo $this->get_social_icon($platform); ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

        </div>
    <?php
        return ob_get_clean();
    }

    /**
     * Render compact byline (for article header)
     */
    public function render_compact_byline($post_id)
    {
        $post = get_post($post_id);
        $author = $this->author_manager->get_author_profile($post->post_author);

        $reviewed_by = get_post_meta($post_id, '_seo_reviewed_by', true);
        $reviewer = $reviewed_by ? $this->author_manager->get_author_profile($reviewed_by) : null;

        ob_start();
    ?>
        <div class="seo-article-meta">
            <span class="seo-meta-item seo-meta-author">
                By <a href="<?php echo esc_url($author['posts_url']); ?>">
                    <?php echo esc_html($author['name']); ?>
                </a>
                <?php if ($author['verified']) : ?>
                    <span class="seo-verified-icon" title="Verified Author">✓</span>
                <?php endif; ?>
            </span>

            <?php if ($reviewer) : ?>
                <span class="seo-meta-item seo-meta-reviewer">
                    Reviewed by <a href="<?php echo esc_url($reviewer['posts_url']); ?>">
                        <?php echo esc_html($reviewer['name']); ?>
                    </a>
                </span>
            <?php endif; ?>

            <span class="seo-meta-item seo-meta-date">
                <time datetime="<?php echo esc_attr(get_the_date('c', $post_id)); ?>">
                    <?php echo esc_html(get_the_date('F j, Y', $post_id)); ?>
                </time>
            </span>
        </div>
<?php
        return ob_get_clean();
    }

    /**
     * Get social icon SVG
     */
    private function get_social_icon($platform)
    {
        $icons = [
            'twitter'  => '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>',
            'linkedin' => '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>',
            'github'   => '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/></svg>',
            'website'  => '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M12 0c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm1 16.057v-3.057h2.994c-.059 1.143-.212 2.24-.456 3.279-.823-.12-1.674-.188-2.538-.222zm1.957 2.162c-.499 1.33-1.159 2.497-1.957 3.456v-3.62c.666.028 1.319.081 1.957.164zm-1.957-7.219v-3.015c.868-.034 1.721-.103 2.548-.224.238 1.027.389 2.111.446 3.239h-2.994zm0-5.014v-3.661c.806.969 1.471 2.15 1.971 3.496-.642.084-1.3.137-1.971.165zm2.703-3.267c1.237.496 2.354 1.228 3.29 2.146-.642.234-1.311.442-2.019.607-.344-.992-.775-1.91-1.271-2.753zm-7.241 13.56c-.244-1.039-.398-2.136-.456-3.279h2.994v3.057c-.865.034-1.714.102-2.538.222zm2.538 1.776v3.62c-.798-.959-1.458-2.126-1.957-3.456.638-.083 1.291-.136 1.957-.164zm-2.994-7.055c.057-1.128.207-2.212.446-3.239.827.121 1.68.19 2.548.224v3.015h-2.994zm1.024-5.179c.5-1.346 1.165-2.527 1.97-3.496v3.661c-.671-.028-1.329-.081-1.97-.165zm-2.005-.35c-.708-.165-1.377-.373-2.018-.607.937-.918 2.053-1.65 3.29-2.146-.496.844-.927 1.762-1.272 2.753zm-.549 1.918c-.264 1.151-.434 2.36-.492 3.611h-3.933c.165-1.658.739-3.197 1.617-4.518.88.361 1.816.67 2.808.907zm.009 9.262c-.988.236-1.92.542-2.797.9-.89-1.328-1.471-2.879-1.637-4.551h3.934c.058 1.265.231 2.488.5 3.651zm.553 1.917c.342.976.768 1.881 1.257 2.712-1.223-.49-2.326-1.211-3.256-2.115.636-.229 1.299-.435 1.999-.597zm9.924 0c.7.163 1.362.367 1.999.597-.931.903-2.034 1.625-3.257 2.116.489-.832.915-1.737 1.258-2.713zm.553-1.917c.27-1.163.442-2.386.501-3.651h3.934c-.167 1.672-.748 3.223-1.638 4.551-.877-.358-1.81-.664-2.797-.9zm.501-5.651c-.058-1.251-.229-2.46-.492-3.611.992-.237 1.929- 546 2.809-.907.877 1.321 1.451 2.86 1.616 4.518h-3.933z"/></svg>',
        ];

        return $icons[$platform] ?? '';
    }
}
