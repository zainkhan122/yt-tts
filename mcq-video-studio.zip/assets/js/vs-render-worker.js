/**
 * MCQ Video Studio - WebCodecs Worker v2.0
 * 
 * @MODIFIED 2026-01-18: Phase 2 - Consolidated video + Audio support
 * - All questions render into ONE video (not separate downloads)
 * - Audio track encoded with AudioEncoder
 * 
 * Architecture: Canvas → VideoFrame → VideoEncoder (GPU H.264) → mp4-muxer → MP4
 *              AudioBuffer → AudioData → AudioEncoder (AAC) → mp4-muxer → MP4
 */

// 1. Environment Monkey-Patching (DOM Trap Fix)
self.window = self;
	self.document = {
	createElement: function (tag) {
		if (tag === 'canvas') {
			const w = (self.__MCQVS_CONFIG__ && self.__MCQVS_CONFIG__.width) || 1080;
			const h = (self.__MCQVS_CONFIG__ && self.__MCQVS_CONFIG__.height) || 1920;
			return new OffscreenCanvas(w, h);
		}
		return {};
	},
	fonts: self.fonts
};

// @NEW 2026-01-22: Polyfill roundRect for Worker Canvas (Parity Safety)
if (typeof OffscreenCanvasRenderingContext2D !== 'undefined' && !OffscreenCanvasRenderingContext2D.prototype.roundRect) {
    OffscreenCanvasRenderingContext2D.prototype.roundRect = function (x, y, w, h, radii) {
        if (!radii) radii = 0;
        if (typeof radii === 'number') radii = { tl: radii, tr: radii, br: radii, bl: radii };
        else if (Array.isArray(radii)) radii = { tl: radii[0], tr: radii[0], br: radii[0], bl: radii[0] }; // simplified

        this.beginPath();
        this.moveTo(x + radii.tl, y);
        this.lineTo(x + w - radii.tr, y);
        this.quadraticCurveTo(x + w, y, x + w, y + radii.tr);
        this.lineTo(x + w, y + h - radii.br);
        this.quadraticCurveTo(x + w, y + h, x + w - radii.br, y + h);
        this.lineTo(x + radii.bl, y + h);
        this.quadraticCurveTo(x, y + h, x, y + h - radii.bl);
        this.lineTo(x, y + radii.tl);
        this.quadraticCurveTo(x, y, x + radii.tl, y);
        this.closePath();
    };
}


/**
 * Structured logging to main thread
 */
function mcqvsLog(level, msg, data) {
    try {
        self.postMessage({ type: 'LOG', level: level || 'info', msg: msg || '', data: data || null });
    } catch (e) {
        // fallback
        try { console.log('[Worker LOG fail]', e); } catch (_) { }
    }
}

// 2. Import Dependencies
console.log("[Worker] Importing scripts (WebCodecs Edition v2)...");
// @MODIFIED 2026-02-07: Parse version from URL to enable cache-busting of dependencies
const _params = new URLSearchParams(self.location.search);
const v = _params.get('v') || self.__MCQVS_VERSION || '7.4.3';
// Build an absolute base URL from the worker script URL (avoids path issues with spaces/query strings)
const __MCQVS_BASE_JS__ = (function () {
    const href = String(self.location && self.location.href ? self.location.href : "");
    const noQuery = href.split("?")[0];
    return noQuery.replace(/[^\/]+$/, ""); // strip filename, keep trailing /
})();

importScripts(
    __MCQVS_BASE_JS__ + 'mp4-muxer/mp4-muxer.min.js',
    __MCQVS_BASE_JS__ + 'vs-animation-engine.js?v=' + v,
    __MCQVS_BASE_JS__ + 'vs-text-effects.js?v=' + v,
    __MCQVS_BASE_JS__ + 'vs-video-templates.js?v=' + v,
    __MCQVS_BASE_JS__ + 'vs-template-manager.js?v=' + v,
    __MCQVS_BASE_JS__ + 'vs-unified-renderer.js?v=' + v
);

// 3. State & Context
let config = {};
let assets = {};
let canvas = null;
let ctx = null;
let stopSignal = false;
let pauseSignal = false;
self.__MCQVS_CONFIG__ = config;

// Phase 4: reset one-shot FX triggers per export job
try { if (self.__MCQVS_FX_FIRED && self.__MCQVS_FX_FIRED.clear) self.__MCQVS_FX_FIRED.clear(); } catch (e) { }

// 4. Message Handler
self.onmessage = async function (e) {
    const { type, data } = e.data;

    try {
        switch (type) {
            case 'INIT':
                await initWorker(data);
                break;
            // @PATCH 2026-02-03: Backward-compat message routing
            case 'START_BATCH':
            case 'STARTBATCH':
                await runConsolidatedExport(data);
                break;
            case 'SELF_TEST_FRAME':
                await selfTestFrame(data);
                break;
            case 'ABORT':
            case 'CANCEL':
                console.warn("[Worker] Abort received");
                stopSignal = true;
                pauseSignal = false; // Ensure we jump out of any pause wait
                break;
            case 'PAUSE': // @NEW 2026-02-09
                console.log("[Worker] Pause received");
                pauseSignal = true;
                break;
            case 'RESUME': // @NEW 2026-02-09
                console.log("[Worker] Resume received");
                pauseSignal = false;
                break;
        }
    } catch (err) {
        console.error("[Worker] Fatal Error:", err);
        mcqvsLog('error', 'Fatal Error', { message: err && err.message, stack: err && err.stack });
        self.postMessage({
            type: 'ERROR',
            data: {
                error: err.message,
                stack: err.stack,
                phase: 'worker_main'
            }
        });
    }
};

async function initWorker(data) {
	config = data.config;
	assets = data.assets || {};
	canvas = data.canvas;
	self.__MCQVS_CONFIG__ = config;
	// @NEW 2026-02-02: Store version for deterministic importScripts
	self.__MCQVS_VERSION = config.version || '7.4.3';

	// SNR FIX: Debug logo asset transfer
	console.log('[Worker] Logo asset received:', assets.logoImage ? `ImageBitmap (${assets.logoImage.width}x${assets.logoImage.height})` : 'MISSING');

	// @MODIFIED 2026-04-24: Use config dimensions (format-aware) instead of hardcoded 1080x1920
	if (canvas) {
		const initW = Number(config.width) || 1080;
		const initH = Number(config.height) || 1920;
		canvas.width = initW;
		canvas.height = initH;
	}
    // Keep assetsUrl for other features.
    self.MCQVS_ASSETS_URL = config.assetsUrl;
    // @NEW 2026-02-11: Diagnostic logging for font parity
    console.log('[Worker] Registered fonts:', Array.from(self.fonts?.keys() || []));
    console.log('[Worker] logoPosition config:', config.logoPosition);

    // Configure Context
    // @FIX 2026-01-18: Removed desynchronized for WebCodecs compatibility (fixes texture readback error)
    if (canvas) {
        ctx = canvas.getContext('2d', {
            alpha: false,
            willReadFrequently: true // Required for VideoFrame creation
        });
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = 'high';
    }

    // @MODIFIED 2026-02-02: Font Loading with descriptor-based matching (Typography Parity)
    if (data.fonts && data.fonts.length > 0) {
        console.log("[Worker] Loading " + data.fonts.length + " fonts...");
        for (const font of data.fonts) {
            try {
                const descriptor = {
                    weight: font.weight || 'normal', // Use passed weight (e.g. 'bold', '900')
                    style: font.style || 'normal'
                };

                // If buffer provided (future: async fetch), use it; otherwise rely on system fonts
                if (font.buffer) {
                    const fontFace = new FontFace(font.name, font.buffer, descriptor);
                    await fontFace.load();
                    self.fonts.add(fontFace);
                    console.log("[Worker] Font loaded: " + font.name + " (" + descriptor.weight + ")");
                } else {
                    // Metadata-only: Worker will use system fonts matching family+weight
                    console.log("[Worker] Font metadata received: " + font.name + " (" + descriptor.weight + ") - using system font");
                }
            } catch (e) {
                console.warn("[Worker] Font load failed: " + font.name, e);
            }
        }

        // @MODIFIED 2026-02-14: Explicitly wait for fonts to be ready in the typeface cache
        // Added Race protection (10s) to prevent 'fonts.ready' hanging the whole worker init
        if (self.fonts && self.fonts.ready) {
            console.log("[Worker] Waiting for self.fonts.ready (with 10s timeout)...");
            await Promise.race([
                self.fonts.ready,
                new Promise(resolve => setTimeout(resolve, 10000))
            ]);
            console.log("[Worker] self.fonts.ready signal received or timed out");
        }
    }

    console.log("[Worker] WebCodecs Worker v2 initialized successfully");
    self.postMessage({ type: 'INIT_COMPLETE' });
}

/**
 * Self-test: initialize template manager + renderer and render exactly 1 frame.
 * Returns a deterministic checksum (best-effort) to prove the pipeline is alive.
 */
async function selfTestFrame(data) {
    try {
        if (!canvas || !ctx) {
            throw new Error('Worker canvas context not initialized (INIT required)');
        }

        const templateId = (data && data.templateId) ? String(data.templateId) : 'corporate';
        const plan = data && data.renderPlan ? data.renderPlan : null;
        if (!plan || !plan.scenes || !plan.scenes.length) {
            throw new Error('renderPlan missing or empty');
        }

        // Reset one-shot FX triggers
        try { if (self.__MCQVS_FX_FIRED && self.__MCQVS_FX_FIRED.clear) self.__MCQVS_FX_FIRED.clear(); } catch (e) { }

        if (!self.MCQVS_TemplateManager || typeof self.MCQVS_TemplateManager.getTemplate !== 'function') {
            throw new Error('TemplateManager missing');
        }
        const template = self.MCQVS_TemplateManager.getTemplate(templateId);
        if (!template) throw new Error('Template not found: ' + templateId);

        // @MODIFIED 2026-01-30: Fix worker self-test render (Unified API)
        const scene0 = plan.scenes[0];
        const scene0c = (scene0 && scene0.content) ? scene0.content : {};

        // UnifiedRenderer API: new MCQVS_UnifiedRenderer().render(ctx, state, assets)
        if (!self.MCQVS_UnifiedRenderer || typeof self.MCQVS_UnifiedRenderer !== 'function') {
            throw new Error('UnifiedRenderer missing');
        }

        const ur = new self.MCQVS_UnifiedRenderer();

        const state = {
            activeScene: scene0,
            ...scene0c,

            currentSceneId: String(scene0.id || 'scene0'),
            currentTemplate: templateId,

            elapsed: 0,
            prevElapsed: 0,
            elapsedInScene: 0,
            animationPhase: 'intro',

            fxEvents: Array.isArray(plan.fxEvents) ? plan.fxEvents : [],
            timing: (scene0 && scene0.timing) ? scene0.timing : null,

            showSafeZone: false,
            config: config || {}
        };

        ctx.clearRect(0, 0, canvas.width, canvas.height);
        await ur.render(ctx, state, (assets || {}));

        // Compute a small checksum to verify non-empty draw.
        // Note: getImageData can be slow; we sample a small strip.
        let checksum = 0;
        try {
            const w = Math.min(128, canvas.width);
            const h = Math.min(64, canvas.height);
            const img = ctx.getImageData(0, 0, w, h);
            const d = img.data;
            for (let i = 0; i < d.length; i += 17) {
                checksum = (checksum + d[i]) % 1000000007;
            }
        } catch (e) {
            checksum = 0;
        }

        self.postMessage({ type: 'SELF_TEST_OK', data: { checksum: checksum } });
    } catch (err) {
        mcqvsLog('error', 'SELF_TEST_FAIL', { message: err && err.message, stack: err && err.stack });
        self.postMessage({ type: 'SELF_TEST_FAIL', error: err && err.message ? err.message : String(err) });
    }
}
/**
 * @MODIFIED 2026-01-18: Consolidated export - ALL questions in ONE video
 */
async function runConsolidatedExport(batchData) {
    stopSignal = false;
    const { debugMode, audioData, renderPlan } = batchData;

    // Access mp4-muxer from global scope
    const { Muxer, ArrayBufferTarget } = Mp4Muxer;

    const plan = renderPlan;
    if (!plan || !Array.isArray(plan.scenes) || plan.scenes.length === 0) {
        throw new Error("Missing/invalid renderPlan in batch data");
    }

    // Single source of truth for timing
    const fps = Number(plan.fps || 30);
    const frameMs = (typeof plan.frameMs === 'number' && plan.frameMs > 0) ? plan.frameMs : (1000 / fps);
    const videoWidth = Number(plan.width || 1080);
    const videoHeight = Number(plan.height || 1920);
    const totalMs = Number(plan.totalMs || 0);
    if (!totalMs || totalMs <= 0) {
        throw new Error("renderPlan.totalMs missing/invalid");
    }

    // @NEW 2026-02-12: Synchronize canvas dimensions with plan (Fixes potential "compressed" font issues)
    if (canvas) {
        if (canvas.width !== videoWidth || canvas.height !== videoHeight) {
            console.log(`[Worker] Resizing canvas from ${canvas.width}x${canvas.height} to ${videoWidth}x${videoHeight}`);
            canvas.width = videoWidth;
            canvas.height = videoHeight;
        }
    }

    // Normalize scenes (sorted, with start/end)
    const scenes = plan.scenes
        .map(s => ({
            id: String(s.id || ""),
            type: String(s.type || "unknown"),
            startMs: (typeof s.startMs === "number") ? s.startMs : 0,
            durMs: (typeof s.durMs === "number") ? s.durMs : 0,
            endMs: (typeof s.endMs === "number") ? s.endMs : ((typeof s.startMs === "number" && typeof s.durMs === "number") ? (s.startMs + s.durMs) : 0),
            content: s.content || {},
            timing: s.timing || null
        }))
        .sort((a, b) => a.startMs - b.startMs);

    // Audio (already mixed on main thread): { left: Float32Array, right: Float32Array }
    const sampleRate = 44100;
    const hasAudio = audioData && audioData.left && audioData.right;

    try {
        self.postMessage({ type: 'JOB_START', jobId: 'consolidated' });
        self.postMessage({ type: 'STATUS', message: 'Preparing encoders...' });

        // Setup muxer with correct dimensions/timebase BEFORE encoders
        const muxerConfig = {
            target: new ArrayBufferTarget(),
            video: {
                codec: 'avc',
                width: videoWidth,
                height: videoHeight,
                frameRate: fps
            },
            fastStart: 'in-memory',
            firstTimestampBehavior: 'offset'
        };

        if (hasAudio) {
            muxerConfig.audio = {
                codec: 'aac',
                numberOfChannels: 2,
                sampleRate: sampleRate
            };
        }

        const muxer = new Muxer(muxerConfig);

        self.postMessage({ type: 'STATUS', message: 'Muxer configured...' });

        // VideoEncoder
        let videoEncoderError = null;
        const videoEncoder = new VideoEncoder({
            output: (chunk, meta) => muxer.addVideoChunk(chunk, meta),
            error: (e) => {
                console.error("[Worker] VideoEncoder error:", e);
                mcqvsLog('error', 'VideoEncoder reported error', { msg: e && e.message });
                videoEncoderError = e;
            }
        });

        self.postMessage({ type: 'STATUS', message: 'VideoEncoder configured...' });

        const videoEncoderConfig = {
            codec: 'avc1.4d002a',
            width: videoWidth,
            height: videoHeight,
            bitrate: 2500000,
            framerate: fps,
            hardwareAcceleration: 'prefer-software'
        };

        self.postMessage({ type: 'STATUS', message: 'Checking VideoEncoder config support...' });
        const support = await VideoEncoder.isConfigSupported(videoEncoderConfig);
        self.postMessage({ type: 'STATUS', message: 'VideoEncoder support check complete. Supported: ' + support.supported });
        if (!support.supported) {
            throw new Error("VideoEncoder configuration not supported");
        }
        videoEncoder.configure(videoEncoderConfig);
        self.postMessage({ type: 'STATUS', message: 'VideoEncoder initialized.' });

        // AudioEncoder (optional)
        let audioEncoder = null;
        let audioEncoderError = null;
        if (hasAudio) {
            audioEncoder = new AudioEncoder({
                output: (chunk, meta) => muxer.addAudioChunk(chunk, meta),
                error: (e) => {
                    console.error("[Worker] AudioEncoder error:", e);
                    mcqvsLog('error', 'AudioEncoder reported error', { msg: e && e.message });
                    audioEncoderError = e;
                }
            });

            const audioEncoderConfig = {
                codec: 'mp4a.40.2',
                sampleRate: sampleRate,
                numberOfChannels: 2,
                bitrate: 128000
            };

            const aSupport = await AudioEncoder.isConfigSupported(audioEncoderConfig);
            if (!aSupport.supported) {
                throw new Error("AudioEncoder configuration not supported");
            }
            audioEncoder.configure(audioEncoderConfig);
        }

        // Renderer
        const renderer = new MCQVS_UnifiedRenderer();

        // Frame loop (deterministic clock)
        const totalFrames = Math.ceil(totalMs / frameMs);
        let sceneIdx = 0;

        self.postMessage({ type: 'STATUS', message: 'Starting frame loop (Total: ' + totalFrames + ')' });
        for (let f = 0; f < totalFrames; f++) {
            self.postMessage({ type: 'STATUS', message: 'Frame ' + f + ': Start' });
            if (f === 0) self.postMessage({ type: 'STATUS', message: 'Rendering frame 0...' });

            if (stopSignal) throw new Error("Aborted by user");
            if (videoEncoderError) throw videoEncoderError;

            self.postMessage({ type: 'STATUS', message: 'Frame ' + f + ': Checking backpressure (Q=' + videoEncoder.encodeQueueSize + ')' });

            // Backpressure guard (prevents freezes/crashes on long exports)
            while (videoEncoder.encodeQueueSize > 3) {
                await new Promise(r => setTimeout(r, 1));
                if (stopSignal) throw new Error("Aborted by user");
                if (videoEncoderError) throw videoEncoderError;
            }

            // @MODIFIED 2026-02-09: Intra-frame pause check (allow processing messages)
            self.postMessage({ type: 'STATUS', message: 'Frame ' + f + ': Checking pause' });
            while (pauseSignal && !stopSignal) {
                await new Promise(r => setTimeout(r, 100));
            }

            self.postMessage({ type: 'STATUS', message: 'Frame ' + f + ': Pre-render logic' });
            const timelineMs = f * frameMs;
            const prevMs = (f > 0) ? ((f - 1) * frameMs) : 0;

            // Advance active scene
            while (sceneIdx < scenes.length - 1 && timelineMs >= scenes[sceneIdx].endMs) {
                sceneIdx++;
            }
            const scene = scenes[sceneIdx] || scenes[scenes.length - 1];

            const elapsedInScene = Math.max(0, timelineMs - scene.startMs);
            const timing = scene.timing || config.timing || null;

            // Phase logic must match main-thread preview
            let animationPhase = 'idle';
            if (scene.type === 'hook') {
                animationPhase = 'hook';
            } else if (scene.type === 'outro') {
                animationPhase = 'outro';
            } else if (scene.type === 'question') {
                const introEnd = Number(timing?.questionPhases?.intro || 1000);
                const revealDur = Number(timing?.questionPhases?.reveal || 3000);
                const qTotal = Number(timing?.questionTotal || scene.durMs || 12000);
                const revealStart = (timing._revealStartRel !== undefined)
                    ? timing._revealStartRel
                    : Math.max(0, qTotal - revealDur);

                if (elapsedInScene < introEnd) animationPhase = 'question_intro';
                else if (elapsedInScene < revealStart) animationPhase = 'question';
                else animationPhase = 'reveal';
            }

            const renderState = {
                time: timelineMs,
                activeScene: scene,
                ...(scene.content || {}),
                currentSceneId: scene.id,
                elapsed: timelineMs,
                elapsedInScene: elapsedInScene,
                prevElapsed: prevMs,

                // Visual ownership: renderer consumes renderPlan.fxEvents
                fxEvents: Array.isArray(plan.fxEvents) ? plan.fxEvents : [],
                animationPhase: animationPhase,
                currentTemplate: String(plan.templateId || config.templateId || 'corporate'),

                // Branding / config
                brandName: config.brandName,
                quizName: config.quizName,
                // @FIX 2026-08-11: hookText/hookVisible were missing from the worker
                // frame state, so the hook-first cover (drawCover) fell back to the
                // classic title-card layout in worker exports. Now matches preview/export.
                hookText: config.hookText || 'Can you score 5/5?',
                hookVisible: (config.hookVisible !== false),
                coverConfig: config.coverConfig || null,
                brandLogoImage: assets.logoImage,
                logoPosition: config.logoPosition || 'all',
                // @NEW 2026-08-11: Explanation bar toggle (default OFF — only when explicitly true).
                showExplanation: config.showExplanation === true,
                websiteUrl: config.websiteUrl || '',
                useRankSystemCTA: config.useRankSystemCTA || false,

                // Backgrounds
                bgImage: assets.bgImage || null,
                bgVideoFrames: assets.bgVideoFrames || null,
                // @NEW 2026-02-08: Playback speed control
                bgVideoFrameDur: config.bgVideoFrameDur || 33.33,

                showSafeZone: false,
                timing: timing,
		templateColors: config.templateColors || null,
		templateFonts: config.templateFonts || null,
		templateEffects: config.templateEffects || null,
		brandColor: config.brandColor || null,
		subHookText: config.subHookText || '',
		// @NEW 2026-02-07: Respect font override in export
		fontOverride: plan.fontOverride || config.fontOverride || null,
		textEffects: config.textEffects || null,

                // Determinism hints (optional)
                frameMs: frameMs,
                frameIndex: f,
                seed: plan.createdAt || plan.seed || 0
            };

        // Clear frame
        ctx.clearRect(0, 0, videoWidth, videoHeight);

        // @NEW 2026-04-22: Seed the animation engine for deterministic FX per frame
        if (typeof MCQVS_AnimationEngine !== 'undefined' && MCQVS_AnimationEngine.setSeed) {
            MCQVS_AnimationEngine.setSeed((renderState.seed || 0) + f * 7919);
        }

        // Render
            self.postMessage({ type: 'STATUS', message: 'Frame ' + f + ': Calling renderer.render' });
            await renderer.render(ctx, renderState, assets || {});
            self.postMessage({ type: 'STATUS', message: 'Frame ' + f + ': Renderer complete' });

            // Encode
            if (f === 0) self.postMessage({ type: 'STATUS', message: 'Encoding frame 0...' });
            const tsUs = Math.round(timelineMs * 1000);
            const frame = new VideoFrame(canvas, { timestamp: tsUs });
            videoEncoder.encode(frame, { keyFrame: (f % 60 === 0) });
            frame.close();
            if (f === 0) self.postMessage({ type: 'STATUS', message: 'Frame 0 encoded.' });
            self.postMessage({ type: 'STATUS', message: 'Frame ' + f + ': Encode pushed' });

            if (f % 15 === 0 || f === totalFrames - 1) {
                // @MODIFIED 2026-02-07: Send progress regardless of debugMode
                self.postMessage({ type: 'PROGRESS', data: { frame: f, totalFrames: totalFrames } });
            }
        }
        self.postMessage({ type: 'STATUS', message: 'Frame loop finished.' });

        // Encode audio after video frames (muxer supports interleaving)
        if (audioEncoder) {
            if (audioEncoderError) throw audioEncoderError;

            const left = audioData.left;
            const right = audioData.right;
            const totalAudioFrames = Math.min(left.length, right.length);
            const chunkFrames = 2048;

            for (let off = 0; off < totalAudioFrames; off += chunkFrames) {
                if (stopSignal) throw new Error("Aborted by user");
                if (audioEncoderError) throw audioEncoderError;

                const frames = Math.min(chunkFrames, totalAudioFrames - off);
                const buf = new Float32Array(frames * 2);
                buf.set(left.subarray(off, off + frames), 0);
                buf.set(right.subarray(off, off + frames), frames);

                const tsUs = Math.round((off / sampleRate) * 1000000);
                const audioFrame = new AudioData({
                    format: 'f32-planar',
                    sampleRate: sampleRate,
                    numberOfFrames: frames,
                    numberOfChannels: 2,
                    timestamp: tsUs,
                    data: buf.buffer
                });

                audioEncoder.encode(audioFrame);
                audioFrame.close();

                // Backpressure
                while (audioEncoder.encodeQueueSize > 6) {
                    await new Promise(r => setTimeout(r, 1));
                    if (stopSignal) throw new Error("Aborted by user");
                    if (audioEncoderError) throw audioEncoderError;
                }
            }
            self.postMessage({ type: 'STATUS', message: 'Audio loop finished. Flushing audioEncoder...' });
            // @FIX 2026-07-14: Race flush() against a 60s timeout. Chrome is
            //                 known to wedge WebCodecs VideoEncoder/AudioEncoder
            //                 flush() indefinitely under GPU memory pressure
            //                 or after a prior encoder error — without this
            //                 race, the worker sits in an await that never
            //                 resolves, the main-thread startWorkerProcessing
            //                 Promise never settles (its 600s ceiling patches
            //                 the symptom, not the cause), and the job wedges.
            //                 A 60s timeout is generous: encode-flush normally
            //                 completes in <2s; 60s indicates an actual hang.
            await Promise.race([
                audioEncoder.flush(),
                new Promise((_, rej) => setTimeout(() => rej(new Error('audioEncoder.flush() timed out after 60s')), 60000))
            ]);
            self.postMessage({ type: 'STATUS', message: 'audioEncoder flushed. Closing...' });
            audioEncoder.close();
        }

        self.postMessage({ type: 'STATUS', message: 'Flushing videoEncoder...' });
        await Promise.race([
            videoEncoder.flush(),
            new Promise((_, rej) => setTimeout(() => rej(new Error('videoEncoder.flush() timed out after 60s')), 60000))
        ]);
        self.postMessage({ type: 'STATUS', message: 'videoEncoder flushed. Closing...' });
        videoEncoder.close();

        self.postMessage({ type: 'STATUS', message: 'Finalizing muxer...' });
        muxer.finalize();
        self.postMessage({ type: 'STATUS', message: 'Muxer finalized. Getting buffer...' });
        const buffer = muxer.target.buffer;
        self.postMessage({ type: 'STATUS', message: 'Buffer obtained (' + buffer.byteLength + ' bytes). Posting JOB_COMPLETE...' });

        self.postMessage({
            type: 'JOB_COMPLETE',
            data: {
                jobId: 'consolidated',
                video: buffer
            }
        }, [buffer]);

        self.postMessage({ type: 'BATCH_COMPLETE' });
    } catch (err) {
        console.error("[Worker] Export Error:", err);
        self.postMessage({
            type: 'ERROR',
            data: {
                error: err && err.message ? err.message : String(err),
                stack: err && err.stack,
                phase: 'consolidated_export'
            }
        });
    }
}


/**
 * Determine animation phase based on scene type and elapsed time
 * @MODIFIED 2026-04-23: Aligned with inline phase logic (question_intro/question/reveal)
 */
function determinePhase(sceneType, elapsedInScene, timing, scene = null) {
  if (sceneType === 'hook') {
    return 'hook';
  }
  if (sceneType === 'outro') {
    return 'outro';
  }
  if (sceneType === 'question') {
    const introEnd = Number(timing?.questionPhases?.intro || 1000);
    const revealDur = Number(timing?.questionPhases?.reveal || 3000);
    const qTotal = Number(timing?.questionTotal || (scene && scene.durMs) || 12000);
    const revealStart = (timing._revealStartRel !== undefined)
        ? timing._revealStartRel
        : Math.max(0, qTotal - revealDur);

    if (elapsedInScene < introEnd) return 'question_intro';
    else if (elapsedInScene < revealStart) return 'question';
    else return 'reveal';
  }
  return 'idle';
}



/**
 * @NEW 2026-01-23: Worker Background Renderer
 * Handles Video/Image/Gradient fallback for consistency
 */
// LEGACY - Worker Background Renderer (DEPRECATED - backgrounds handled by TemplateManager.drawBackground)
// UnifiedRenderer passes bgImage/bgVideoFrames in state/assets to templates.
function drawWorkerBackground(ctx, state, assets) {
    if (console && console.debug) {
        console.debug('MCQVS Worker: drawWorkerBackground is deprecated. Backgrounds are rendered in templates.');
    }
    // Paranoid trap (Worker safe)
    if (self.MCQVS_Logger) {
        try { self.MCQVS_Logger.warn('DEPRECATED_CALL_WORKER', { function: 'drawWorkerBackground' }); } catch (e) { }
    }
}
