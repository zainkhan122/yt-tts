<?php

namespace SEO_Article_Generator\Discovery;

use SEO_Article_Generator\AI\AI_Client;
use SEO_Article_Generator\Jobs\Job_Handler;
use SEO_Article_Generator\Logger;
use SEO_Article_Generator\Utils\Plugin_Time;
use SEO_Article_Generator\Utils\SeoGen_Version_Resolver;
use SEO_Article_Generator\Queue\AS_Registry;
use SEO_Article_Generator\Installer;
use SEO_Article_Generator\Discovery\Post_Type_Classifier;

if (! \defined('ABSPATH')) {
	exit();
}

// Ensure TypeClassifier is available regardless of bootstrap path
if ( ! class_exists( Post_Type_Classifier::class, false ) ) {
	require_once __DIR__ . '/class-post-type-classifier.php';
}

if ( ! class_exists( Title_Analyzer::class, false ) ) {
	require_once __DIR__ . '/class-title-analyzer.php';
}

if ( ! class_exists( Discovery_Engine::class, false ) ) {
	require_once __DIR__ . '/class-discovery-engine.php';
}

/**
 * Bootstraps the Discovery Engine, Admin Menus, and AJAX hooks
 *
 * @MODIFIED 2026-03-01 - Initial implementation for Discovery Bootstrap
 */
class Discovery_Bootstrap
{
	/**
	 * @var Discovery_Bootstrap|null
	 */
	private static $instance = null;

	/**
	 * @var bool
	 */
	private $initialized = false;

	/**
	 * Get the singleton instance.
	 */
	public static function get_instance(): self
	{
		if (null === self::$instance) {
			self::$instance = new self();
		}
		return self::$instance;
	}



	/**
	 * @var Logger
	 */
	private $logger;

	/**
	 * @var Discovery_Engine|null
	 */
	private $engine;

	/**
	 * @var int
	 */
	private $engine_bootstrap_retry_after_utc = 0;

	/**
	 * @var string
	 */
	private $engine_bootstrap_last_reason = '';

	/**
	 * Get the engine bootstrap block transient key.
	 */
	private function get_engine_bootstrap_block_key(): string
	{
		return 'seo_gen_engine_bootstrap_block_' . \get_current_blog_id();
	}

	/**
	 * Get the engine bootstrap block from transient.
	 */
    private function get_engine_bootstrap_block(): array
    {
        $value = \get_transient($this->get_engine_bootstrap_block_key());

        return is_array($value) ? $value : array(
            'retry_after_utc' => 0,
            'reason' => '',
        );
    }

    /**
     * Public read accessor for engine bootstrap pause state.
     *
     * @return array
     */
    public function get_engine_bootstrap_pause_info(): array
    {
        $shared_block = $this->get_engine_bootstrap_block();
        $retry_after_utc = (int) ($shared_block['retry_after_utc'] ?? 0);
        $now_utc = Plugin_Time::now_utc_ts();

        return array(
            'paused' => $retry_after_utc > $now_utc,
            'retry_after_utc' => $retry_after_utc,
            'retry_after' => $retry_after_utc > $now_utc ? max(60, $retry_after_utc - $now_utc) : 0,
            'reason' => (string) ($shared_block['reason'] ?? ''),
        );
    }

    /**
     * Set the engine bootstrap block.
     */
    private function set_engine_bootstrap_block(int $retry_after_seconds, string $reason): void
	{
		$retry_after_seconds = max(60, $retry_after_seconds);
		$until               = Plugin_Time::now_utc_ts() + $retry_after_seconds;

		$this->engine_bootstrap_retry_after_utc = $until;
		$this->engine_bootstrap_last_reason     = $reason;

		\set_transient(
			$this->get_engine_bootstrap_block_key(),
			array(
				'retry_after_utc' => $until,
				'reason'          => $reason,
			),
			$retry_after_seconds
		);
	}

	/**
	 * Clear the engine bootstrap block.
	 */
	private function clear_engine_bootstrap_block(): void
	{
		$this->engine_bootstrap_retry_after_utc = 0;
		$this->engine_bootstrap_last_reason     = '';
		\delete_transient($this->get_engine_bootstrap_block_key());
	}

	/**
	 * @var callable|null Lazy factory for AI client resolution.
	 */
	private $ai_client_factory = null;

	/**
	 * @var Discovery_Processor
	 */
	private $processor;

	/**
	 * @var Job_Handler
	 */
	private $job_handler;

	/**
	 * @var AS_Registry
	 */
	private $as_registry;

	/**
	 * True while the external heartbeat cron endpoint is the request origin.
	 * Set in handle_external_heartbeat() so schedule_discovery_jobs() can
	 * short-circuit its inner Meta-Watchdog directa-invocation branch and
	 * avoid re-running the same handlers in parallel on the same request.
	 *
	 * @var bool
	 */
	private $heartbeat_active = false;

	/**
	 * Get the centralized Action Scheduler group.
	 * 
	 * @return string
	 */
	private static function as_group(): string
	{
		return AS_Registry::GROUP;
	}

	/**
	 * Constructor
	 *
	 * @MODIFIED 2026-03-01 - Initialize dependencies and discovery components
	 */
	public function __construct($job_handler = null, $logger = null, $processor = null, callable $ai_client_factory = null)
	{
		$plugin = \SEO_Article_Generator\Plugin::get_instance();

		$this->job_handler = $job_handler ?: $plugin->get_job_handler();
		$this->logger      = $logger ?: $plugin->get_logger();
		$this->processor   = $processor ?: $plugin->get_discovery_processor();
		$this->as_registry = new AS_Registry($this->processor);

		$this->ai_client_factory = $ai_client_factory ?: static function () use ($plugin) {
			return $plugin->get_ai_client();
		};
	}

	private function clear_dashboard_snapshot_transients(): void
	{
		\delete_transient('seo_gen_dashboard_snapshot_' . \get_current_blog_id());
		\delete_transient('seo_gen_scanner_snap_' . \get_current_blog_id());
		\delete_transient('seo_gen_as_queue_count');
	}

    private function get_discovery_error_message(int $discovery_id): string
    {
        global $wpdb;

        return (string) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT error_message
                 FROM " . Installer::table_discovery() . "
                 WHERE id = %d",
                $discovery_id
            )
        );
    }

	/**
	 * Lazily resolve the Discovery_Engine.
	 *
	 * PHASE 5 FIX: Use canonical provider status DTO as single authority.
	 * Local bootstrap block is a transient cache mirror, not independent.
	 *
	 * @return Discovery_Engine|null
	 */
	private function get_engine(): ?Discovery_Engine
	{
		if ($this->engine instanceof Discovery_Engine) {
			return $this->engine;
		}

		// PHASE 5 FIX: Read canonical status ONCE - use it for all decisions
		$status = AI_Client::get_provider_status();
		$now_utc = Plugin_Time::now_utc_ts();

		// Use canonical status fields - no local derivation
		$is_paused = !empty($status['paused']);
		$has_routable = !empty($status['routable']);
		$canonical_reason = (string) ($status['reason'] ?? '');
		$canonical_until = (int) ($status['until'] ?? 0);

		// If canonical status says we're unblocked, clear any stale local cache
		if (!$is_paused && $has_routable) {
			$this->clear_engine_bootstrap_block();
		}

		// If canonical status says we're blocked, mirror it to local cache and return null
		if ($is_paused && !$has_routable) {
			// Only refresh local cache if canonical reason differs or cache is stale
			$shared_block = $this->get_engine_bootstrap_block();
			$cached_until = (int) ($shared_block['retry_after_utc'] ?? 0);
			$cached_reason = (string) ($shared_block['reason'] ?? '');

			// @FIX 2026-04-19 CORRECTED: invert guard so unblocked path falls through
			if ($cached_until > 0 && $cached_until <= $now_utc) {
				$this->clear_engine_bootstrap_block();
				$status = AI_Client::get_provider_status();
				$is_paused  = !empty($status['paused']);
				$has_routable = !empty($status['routable']);
				if ($is_paused || !$has_routable) {
					// Still blocked after re-evaluation â€” respect it
					return null;
				}
				// Provider is now clear â€” fall through to engine creation below
			} elseif ($cached_until > $now_utc || $cached_reason !== $canonical_reason) {
				$retry_after = max(60, (int) ($status['min_retry_after'] ?? 60));
				$this->set_engine_bootstrap_block($retry_after, $canonical_reason);
				$this->logger->warning('Discovery engine bootstrap deferred: ' . $canonical_reason);
				return null;
			} else {
				return null;
			}
		}

		// Canonical status says we're good - create engine
		try {
			$factory   = $this->ai_client_factory;
			$ai_client = $factory ? $factory() : null;

			if (! $ai_client) {
				throw new \RuntimeException('No AI client available for discovery.');
			}

			$this->engine = new Discovery_Engine($this->logger, $ai_client);
			$this->clear_engine_bootstrap_block();

			return $this->engine;
		} catch (\Throwable $e) {
			$this->logger->error('Discovery engine bootstrap failed: ' . $e->getMessage());
			return null;
		}
	}

	public function is_discovery_paused(): bool
	{
		return ! (bool) \get_option(
			\SEO_Article_Generator\Option_Registry::DISCOVERY_ENABLED,
			\SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::DISCOVERY_ENABLED]
		);
	}

	private function get_scheduler_health_snapshot(): array
	{
		global $wpdb;

		$jobs_table    = Installer::table_jobs();
		$active_job_id = (int) $wpdb->get_var(
			"SELECT id
			 FROM {$jobs_table}
			 WHERE status IN ('processing', 'generating', 'validating')
			 ORDER BY id ASC
			 LIMIT 1"
		);

		if ($this->is_discovery_paused()) {
			return array(
				'state'        => 'paused',
				'label'        => 'Paused',
				'icon'         => 'â¸',
				'description'  => 'Scheduler Paused',
				'color'        => '#f0ad4e',
				'border_color' => '#f0ad4e',
				'worker_next'  => 0,
				'active_job_id'=> $active_job_id,
			);
		}

		$worker_next = AS_Registry::get_next_run_uncached(AS_Registry::HOOK_QUEUE_WORKER);
		$is_healthy  = $worker_next > 0;

		return array(
			'state'        => $is_healthy ? 'healthy' : 'stalled',
			'label'        => $is_healthy ? 'Healthy' : 'Stalled',
			'icon'         => $is_healthy ? '✓' : '✗',
			'description'  => $is_healthy ? 'Scheduler Active' : 'Scheduler Stalled',
			'color'        => $is_healthy ? '#46b450' : '#dc3232',
			'border_color' => $is_healthy ? '#ddd' : '#dc3232',
			'worker_next'  => (int) $worker_next,
			'active_job_id'=> $active_job_id,
		);
	}

	public function get_dashboard_health_snapshot(): array
	{
		return $this->get_scheduler_health_snapshot();
	}

	private function get_site_day_bounds_utc(): array
	{
		$tz          = \wp_timezone();
		$now_local   = new \DateTimeImmutable('now', $tz);
		$start_local = $now_local->setTime(0, 0, 0);
		$end_local   = $start_local->modify('+1 day');
		$utc         = new \DateTimeZone('UTC');

		return array(
			'start_utc_mysql' => $start_local->setTimezone($utc)->format('Y-m-d H:i:s'),
			'end_utc_mysql'   => $end_local->setTimezone($utc)->format('Y-m-d H:i:s'),
		);
}

private function get_discovery_day_snapshot(): array
	{
		global $wpdb;

		$table  = Installer::table_discovery();
		$bounds = $this->get_site_day_bounds_utc();

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT status, COUNT(*) AS total
				 FROM {$table}
				 WHERE completed_at >= %s
				   AND completed_at < %s
				 GROUP BY status",
				$bounds['start_utc_mysql'],
				$bounds['end_utc_mysql']
			),
			ARRAY_A
		);

		$today = array(
			'done'    => 0,
			'failed'  => 0,
			'timeout' => 0,
		);

		foreach ((array) $rows as $row) {
			$status = (string) ($row['status'] ?? '');
			$total  = (int) ($row['total'] ?? 0);

			if (isset($today[$status])) {
				$today[$status] = $total;
			}
		}

		return array(
			'done_today'   => $today['done'],
			'failed_today' => $today['failed'] + $today['timeout'],
		);
	}

	private function get_dashboard_activity_snapshot(): array
	{
		global $wpdb;

		$table  = Installer::table_discovery();
		$bounds = $this->get_site_day_bounds_utc();

		$sql_base = "SELECT
				CASE
					WHEN type = 'new' THEN 'new'
					ELSE 'updated'
				END AS activity_kind,
				COUNT(*) AS total
			 FROM {$table}
			 WHERE status = 'done'";

		$today_rows = $wpdb->get_results(
			$wpdb->prepare(
				$sql_base . " AND completed_at >= %s AND completed_at < %s GROUP BY activity_kind",
				$bounds['start_utc_mysql'],
				$bounds['end_utc_mysql']
			),
			ARRAY_A
		);

		$all_rows = $wpdb->get_results(
			$sql_base . " GROUP BY activity_kind",
			ARRAY_A
		);

		$out = array(
			'new_posts_today'      => 0,
			'updated_posts_today'  => 0,
			'new_posts_total'      => 0,
			'updated_posts_total'  => 0,
		);

		foreach ((array) $today_rows as $row) {
			$kind  = (string) ($row['activity_kind'] ?? '');
			$total = (int) ($row['total'] ?? 0);

			if ($kind === 'new') {
				$out['new_posts_today'] = $total;
			} elseif ($kind === 'updated') {
				$out['updated_posts_today'] = $total;
			}
		}

		foreach ((array) $all_rows as $row) {
			$kind  = (string) ($row['activity_kind'] ?? '');
			$total = (int) ($row['total'] ?? 0);

			if ($kind === 'new') {
				$out['new_posts_total'] = $total;
			} elseif ($kind === 'updated') {
				$out['updated_posts_total'] = $total;
			}
		}

		return $out;
	}

	private function get_discovery_retention_config(): array
	{
		return array(
			'manual_history_hours' => 72,
			'terminal_retention_days' => 60,
			'terminal_statuses' => array('done', 'failed', 'timeout', 'skippednotnewer', 'skippedduplicate', 'ignored'),
		);
	}

	private function get_scanner_controls_snapshot(): array
	{
		$sources = get_option('seo_gen_discovery_sources', array());
		if (! is_array($sources)) {
			$sources = array();
		}

		$state_hash = md5(wp_json_encode(array(
			'discovery_paused' => $this->is_discovery_paused() ? 1 : 0,
			'rss_enabled' => (int) \get_option(
				\SEO_Article_Generator\Option_Registry::RSS_DISCOVERY_ENABLED,
				\SEO_Article_Generator\Option_Registry::defaults()[ \SEO_Article_Generator\Option_Registry::RSS_DISCOVERY_ENABLED ]
			),
			'ai_enabled'  => (int) \get_option(
				\SEO_Article_Generator\Option_Registry::AI_DISCOVERY_ENABLED,
				\SEO_Article_Generator\Option_Registry::defaults()[ \SEO_Article_Generator\Option_Registry::AI_DISCOVERY_ENABLED ]
			),
			'plugin_filter'    => (int) get_option(Discovery_Engine::PLUGIN_FILTER_OPTION, 0),
			'sources'          => array_map(static function ($source) {
				return array(
					'id'         => (string) ($source['id'] ?? ''),
					'feed_url'   => (string) ($source['feed_url'] ?? ''),
					'status'     => (string) ($source['status'] ?? ''),
					'campaign_id'=> (int) ($source['campaign_id'] ?? 0),
				);
			}, $sources),
		)));

		$cache_key = 'seo_gen_scanner_snap_' . get_current_blog_id();
		$cached    = get_transient($cache_key);

		if (is_array($cached) && (string) ($cached['_state_hash'] ?? '') === $state_hash) {
			unset($cached['_state_hash']);
			return $cached;
		}

		$discovery_paused  = $this->is_discovery_paused();
		$defaults    = \SEO_Article_Generator\Option_Registry::defaults();
		$rss_enabled = (int) \get_option(
			\SEO_Article_Generator\Option_Registry::RSS_DISCOVERY_ENABLED,
			$defaults[ \SEO_Article_Generator\Option_Registry::RSS_DISCOVERY_ENABLED ]
		) === 1;
		$ai_enabled  = (int) \get_option(
			\SEO_Article_Generator\Option_Registry::AI_DISCOVERY_ENABLED,
			$defaults[ \SEO_Article_Generator\Option_Registry::AI_DISCOVERY_ENABLED ]
		) === 1;
		$has_sources       = ! empty($sources);
		$next_runs         = $this->get_next_scheduled_run_data();
		$api_pause         = $this->get_api_pause_info();
		$ai_engine         = $this->get_engine();
		$ai_available      = $ai_engine instanceof Discovery_Engine;
		$ai_blocked_reason = '';

		if ( $discovery_paused ) {
			$ai_blocked_reason = 'Discovery is paused.';
		} elseif ( ! $ai_enabled ) {
			$ai_blocked_reason = 'AI discovery is disabled.';
		} elseif ( ! $ai_available ) {
			$ai_blocked_reason = ! empty( $api_pause['reason'] )
				? (string) $api_pause['reason']
				: 'No routable AI provider is available.';
		}

		$result = [
			'rss' => [
				'enabled'           => $rss_enabled,
				'available'         => $has_sources ? 1 : 0,
				'effective_enabled' => ( $rss_enabled && ! $discovery_paused && $has_sources ) ? 1 : 0,
				'next_run'          => (int) ( $next_runs['rss'] ?? 0 ),
				'next_run_human'    => (string) ( $next_runs['rss_human'] ?? 'N/A' ),
				'blocked_reason'    => ! $has_sources
					? 'No RSS sources configured.'
					: ( $discovery_paused ? 'Discovery is paused.' : '' ),
			],
			'ai'  => [
				'enabled'           => $ai_enabled,
				'available'         => $ai_available ? 1 : 0,
				'effective_enabled' => ( $ai_enabled && ! $discovery_paused && $ai_available ) ? 1 : 0,
				'next_run'          => (int) ( $next_runs['ai'] ?? 0 ),
				'next_run_human'    => (string) ( $next_runs['ai_human'] ?? 'N/A' ),
				'blocked_reason'    => $ai_blocked_reason,
			],
			'wp_auto' => [
				'configured' => (int) \get_option( \SEO_Article_Generator\Option_Registry::WP_AUTO_CATEGORY_ID, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::WP_AUTO_CATEGORY_ID] ) > 0,
				'next_run'       => (int) AS_Registry::get_next_run( AS_Registry::HOOK_WP_AUTO_DRAFT_POLL ),
				'next_run_human' => AS_Registry::get_next_run( AS_Registry::HOOK_WP_AUTO_DRAFT_POLL )
					? human_time_diff(
						Plugin_Time::now_utc_ts(),
						AS_Registry::get_next_run( AS_Registry::HOOK_WP_AUTO_DRAFT_POLL )
					  )
					: 'N/A',
			],
			'plugin_filter' => [
				'enabled' => (int) get_option( Discovery_Engine::PLUGIN_FILTER_OPTION, 0 ),
				'label'   => (int) get_option( Discovery_Engine::PLUGIN_FILTER_OPTION, 0 ) === 1 ? 'On' : 'Off',
				'message' => (int) get_option( Discovery_Engine::PLUGIN_FILTER_OPTION, 0 ) === 1
					? 'Plugin-generated discoveries are held in Failed until zones are added and this filter is disabled.'
					: 'All discovery types can process normally again.',
			],
		];

		$result['_state_hash'] = $state_hash;

		set_transient($cache_key, $result, 30);

		unset($result['_state_hash']);
		return $result;
	}

private function get_completed_rows_snapshot(array $items = array()): array
{
	global $wpdb;

	$table = Installer::table_discovery();
	$jobs = Installer::table_jobs();

	$bounds = $this->get_site_day_bounds_utc();

	if (empty($items)) {
		$today_items = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT d.id, d.software_name, d.discovered_version, d.current_version, d.changelog, d.type, d.status, d.existing_post_id, d.job_id, d.error_message, d.discovered_at, d.completed_at, d.source_url, j.hallucination_count, j.failed_sections_count, j.validation_errors_count, j.validation_results
				FROM {$table} d
				LEFT JOIN {$jobs} j ON d.job_id = j.id
				WHERE d.status = 'done' AND d.completed_at >= %s AND d.completed_at < %s
				ORDER BY d.completed_at DESC LIMIT 100",
				$bounds['start_utc_mysql'],
				$bounds['end_utc_mysql']
			),
			ARRAY_A
		);

		$history_items = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT d.id, d.software_name, d.discovered_version, d.current_version, d.changelog, d.type, d.status, d.existing_post_id, d.job_id, d.error_message, d.discovered_at, d.completed_at, d.source_url, j.hallucination_count, j.failed_sections_count, j.validation_errors_count, j.validation_results
				FROM {$table} d
				LEFT JOIN {$jobs} j ON d.job_id = j.id
				WHERE d.status = 'done' AND (d.completed_at < %s OR d.completed_at >= %s)
				ORDER BY d.completed_at DESC LIMIT 100",
				$bounds['start_utc_mysql'],
				$bounds['end_utc_mysql']
			),
			ARRAY_A
		);

		$today_rows = array_map(array($this, 'normalize_dashboard_row'), (array) $today_items);
		$history_rows = array_map(array($this, 'normalize_dashboard_row'), (array) $history_items);

		return array(
			'today_count' => count($today_rows),
			'history_count' => count($history_rows),
			'total_visible' => count($today_rows) + count($history_rows),
			'today_rows' => $today_rows,
			'history_rows' => $history_rows,
		);
	}

	$today_rows = array();
	$history_rows = array();

	foreach ((array) $items as $item) {
		$row = is_array($item) ? $item : (is_object($item) ? get_object_vars($item) : array());
		$completed_at = (string) ($row['completed_at'] ?? '');

		if ($completed_at >= $bounds['start_utc_mysql'] && $completed_at < $bounds['end_utc_mysql']) {
			$today_rows[] = $row;
		} else {
			$history_rows[] = $row;
		}
	}

	return array(
		'today_count' => count($today_rows),
		'history_count' => count($history_rows),
		'total_visible' => count((array) $items),
		'today_rows' => $today_rows,
		'history_rows' => $history_rows,
);
}

	private function render_completed_rows_html(array $snapshot): array
	{
		if ( ! \function_exists('seo_gen_render_done_row')) {
			\ob_start();
			require_once \SEO_GEN_PLUGIN_DIR . 'admin/views/discovery-dashboard.php';
			\ob_end_clean();
		}

		$today_html = '';
		foreach ((array) ($snapshot['today_rows'] ?? array()) as $item) {
			$today_html .= \seo_gen_render_done_row($item);
		}

		$history_html = '';
		foreach ((array) ($snapshot['history_rows'] ?? array()) as $item) {
			$history_html .= \seo_gen_render_done_row($item);
		}

		return array(
			'today_html'   => $today_html,
			'history_html' => $history_html,
		);
	}

	private function get_scanner_cards_snapshot(): array
	{
		return $this->get_scanner_controls_snapshot();
	}

	private function get_sources_snapshot(): array
	{
		$sources = \get_option('seo_gen_discovery_sources', array());

		if (! \is_array($sources)) {
			$sources = array();
		}

		$counts = array(
			'total'     => 0,
			'untested'  => 0,
			'failed'    => 0,
			'thin'      => 0,
			'success'   => 0,
			'wpauto_ok' => 0,
		);

		foreach ($sources as $source) {
			$counts['total']++;

			$status = \sanitize_key($source['status'] ?? 'untested');
			$chars  = (int) ($source['test_chars'] ?? 0);
			$type   = self::normalize_source_type((string) ($source['scraper_type'] ?? 'auto'));
			$camp   = (int) ($source['campaign_id'] ?? 0);

			if ($status === 'success' && $chars > 0 && $chars < 300) {
				$status = 'thin';
			}

			if (! isset($counts[$status])) {
				$status = 'untested';
			}

			$counts[$status]++;

			if (\in_array($type, array('rssfeed', 'multiscraper', 'articlescraper'), true) && $camp > 0) {
				$counts['wpauto_ok']++;
			}
		}

		$has_configured = $counts['total'] > 0;
		$has_usable     = $counts['success'] > 0;

		return array(
			'counts'         => $counts,
			'has_configured' => $has_configured,
			'has_usable'     => $has_usable,
			'state'          => ! $has_configured ? 'empty' : ($has_usable ? 'ready' : 'unverified'),
			'label'          => ! $has_configured ? 'No Sources' : ($has_usable ? 'Ready' : 'Needs Testing'),
			'summary'        => \sprintf(
				'%d total • %d ready • %d untested • %d failed',
				(int) $counts['total'],
				(int) $counts['success'],
				(int) $counts['untested'],
				(int) $counts['failed']
			),
		);
	}

	public function get_dashboard_sources_snapshot(): array
	{
		return $this->get_sources_snapshot();
	}

	private function normalize_dashboard_row(array $row): array
	{
		$stored_type       = (string) ($row['type'] ?? '');
		$existing_post_id  = max(0, (int) ($row['existing_post_id'] ?? 0));

		// If the discovery table says "new", it IS a new post regardless of
		// what Post_Type_Classifier says about the final post.  Skip re-canonicalization
		// so "New Post" survives in the Generation Activities card and Completed tab.
		if ($stored_type === Post_Type_Classifier::TYPE_NEW) {
			$canonical_type    = Post_Type_Classifier::TYPE_NEW;
			$canonical_post_id = $existing_post_id;
		} else {
			$contract = Discovery_Engine::canonicalize_discovery_contract(
				$stored_type,
				$existing_post_id
			);
			$canonical_type    = (string) $contract['type'];
			$canonical_post_id = (int) $contract['existing_post_id'];
		}

		$software_name = isset($row['software_name'])
			? trim(\wp_strip_all_tags((string) $row['software_name']))
			: '';

		if ($software_name === '' && $canonical_post_id > 0) {
			$post_title = \get_the_title($canonical_post_id);
			if (is_string($post_title) && trim($post_title) !== '') {
				$software_name = trim(\wp_strip_all_tags($post_title));
			}
		}

		if ($software_name === '') {
			$software_name = \__('Untitled', 'seo-article-generator');
		}

		if ($canonical_type === Post_Type_Classifier::TYPE_NEW) {
			$display_type = Post_Type_Classifier::TYPE_NEW;
		} elseif ($canonical_post_id <= 0) {
			$display_type = Post_Type_Classifier::TYPE_NEW;
		} elseif (in_array(
			$canonical_type,
			array(
				Post_Type_Classifier::TYPE_PLUGIN,
				Post_Type_Classifier::TYPE_PLUGIN_LEGACY,
				Post_Type_Classifier::TYPE_LEGACY,
			),
			true
		)) {
			$display_type = $canonical_type;
		} else {
			$display_type = Post_Type_Classifier::TYPE_LEGACY;
		}

		$row['software_name']    = $software_name;
		$row['existing_post_id'] = $canonical_post_id;
		$row['type']             = $display_type;
		$row['typeui']           = array(
			'key'   => $display_type,
			'label' => match ($display_type) {
				Post_Type_Classifier::TYPE_NEW           => 'New Post',
				Post_Type_Classifier::TYPE_PLUGIN        => 'Plugin Update',
				Post_Type_Classifier::TYPE_PLUGIN_LEGACY => 'Plugin Update (Legacy Format)',
				default                                  => 'Legacy Update',
			},
			'class' => match ($display_type) {
				Post_Type_Classifier::TYPE_NEW           => 'new',
				Post_Type_Classifier::TYPE_PLUGIN        => 'plugin',
				Post_Type_Classifier::TYPE_PLUGIN_LEGACY => 'plugin-legacy',
				default                                  => 'legacy',
			},
		);

		// FIX F4 (Phase 3A): a failed/timeout item whose per-item breaker has
		// tripped is parked — rescan will no longer re-pend it; it only moves
		// via an explicit Retry / Run Now / Dismiss. Exposed for the badge.
		$row['parked'] = in_array((string) ($row['status'] ?? ''), array('failed', 'timeout'), true)
			&& (int) ($row['consecutive_failures'] ?? 0) >= Discovery_Processor::MAX_CONSECUTIVE_FAILURES;

		$row['display_status']   = $this->get_pipeline_display_status((object) $row);
		$row['allowed_actions']  = $this->get_row_actions_for_status((string) ($row['status'] ?? ''));

		$validationResults = array();
		if (!empty($row['validation_results']) && is_string($row['validation_results'])) {
			$decodedValidation = json_decode($row['validation_results'], true);
			if (is_array($decodedValidation)) {
				$validationResults = $decodedValidation;
			}
		}

		$validationErrors = array();
		if (!empty($validationResults['errors']) && is_array($validationResults['errors'])) {
			foreach ($validationResults['errors'] as $error) {
				if (is_string($error) && trim($error) !== '') {
					$validationErrors[] = trim($error);
				}
			}
		}

    $row['validation_results'] = $validationResults;
    $row['validation_error_items'] = array_values(array_unique($validationErrors));

	// Fix: Preserve scheduled_at for display - operators need to see staggered timing
	// The display_status logic in get_pipeline_display_status_item() handles formatting
	// and fallback to AS registry, so we pass the raw value through unchanged.

	$row_current_version = isset( $row['current_version'] ) ? trim( (string) $row['current_version'] ) : '';
	$row_status          = strtolower( (string) ( $row['status'] ?? '' ) );
	$terminal_statuses   = array( 'done', 'failed', 'timeout', 'skippednotnewer', 'skippedduplicate', 'ignored' );
	$is_terminal         = in_array( $row_status, $terminal_statuses, true );

	// For active discoveries (pending â†’ finalizing), always resolve the live
	// post-state version so operators see "what is the post right now" â€” the
	// discovery-table snapshot may be stale if the post meta was updated by a
	// prior finalization or external edit since staging time.
	//
	// For terminal discoveries (done/failed/timeout), preserve the frozen
	// snapshot so the dashboard "was X" semantics remain intact â€” the
	// discovered_version column shows the new version, current_version shows
	// the pre-update version.
	//
	// Sentinel or empty values are always resolved regardless of status.
	if ( $canonical_post_id > 0 && ( ! $is_terminal || $row_current_version === '' || $row_current_version === '0.0.0' ) ) {
		$resolved_version = SeoGen_Version_Resolver::current_version( $canonical_post_id );
		if ( $resolved_version !== '' ) {
			$row['current_version'] = $resolved_version;
		}
	}

	return $row;
	}

	private function build_dashboard_snapshot(): array
	{
		// FINDING-12 FIX: Add transient caching layer to collapse burst polling from multiple admin tabs
		$cache_key = 'seo_gen_dashboard_snapshot_' . \get_current_blog_id();
		$cached   = \get_transient($cache_key);
		if (is_array($cached)) {
			return $cached;
		}

		global $wpdb;

		$table = Installer::table_discovery();
		$jobs  = Installer::table_jobs();

		$cols = implode(', ', array(
			'd.id',
			'd.software_name',
			'd.discovered_version',
			'd.current_version',
			'd.changelog',
			'd.type',
			'd.status',
			'd.existing_post_id',
			'd.job_id',
			'd.error_message',
			'd.discovered_at',
			'd.completed_at',
			'd.source_url',
			'd.scheduled_at',
			'd.consecutive_failures',
			'd.last_failure_at',
		));

		$pending = $wpdb->get_results(
			"SELECT {$cols} FROM {$table} d WHERE d.status = 'pending' ORDER BY d.discovered_at DESC",
			ARRAY_A
		);

		$pipeline = $wpdb->get_results(
			"SELECT {$cols}, j.status AS job_status, j.error_message AS job_error
			 FROM {$table} d
			 LEFT JOIN {$jobs} j ON d.job_id = j.id
			 WHERE d.status IN ('queued','processing','generating','finalizing','deferred')
			 ORDER BY d.discovered_at ASC",
			ARRAY_A
		);

		$failed = $wpdb->get_results(
			"SELECT {$cols}, j.status AS job_status, j.error_message AS job_error
			 FROM {$table} d
			 LEFT JOIN {$jobs} j ON d.job_id = j.id
			 WHERE d.status IN ('failed','timeout')
			 ORDER BY d.discovered_at DESC
			 LIMIT 100",
			ARRAY_A
		);

		$failed_total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} d WHERE d.status IN ('failed','timeout')");

		$completed = $wpdb->get_results(
			"SELECT {$cols}, j.hallucination_count, j.failed_sections_count, j.validation_errors_count, j.validation_results
			 FROM {$table} d
			 LEFT JOIN {$jobs} j ON d.job_id = j.id
			 WHERE d.status = 'done'
			 ORDER BY d.completed_at DESC
			 LIMIT 100",
			ARRAY_A
		);

		$completed_total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} d WHERE d.status = 'done'");

		$pending   = array_map(array($this, 'normalize_dashboard_row'), (array) $pending);
		$pipeline  = array_map(array($this, 'normalize_dashboard_row'), (array) $pipeline);
		$failed    = array_map(array($this, 'normalize_dashboard_row'), (array) $failed);
		$completed = array_map(array($this, 'normalize_dashboard_row'), (array) $completed);

		$completed_snapshot_raw = $this->get_completed_rows_snapshot($completed);
		$completed_html          = $this->render_completed_rows_html($completed_snapshot_raw);

		$completed_snapshot = array(
			'rows'  => $completed,
			'count' => count($completed),
			'total'      => $completed_total,
			'truncated'  => $completed_total > count($completed),
			'groups' => array(
				'today' => array(
					'count' => max(0, (int) ($completed_snapshot_raw['today_count'] ?? 0)),
					'html'  => (string) ($completed_html['today_html'] ?? ''),
				),
				'history' => array(
					'count' => max(0, (int) ($completed_snapshot_raw['history_count'] ?? 0)),
					'html'  => (string) ($completed_html['history_html'] ?? ''),
				),
			),
		);

		$is_paused = $this->is_discovery_paused();

		// PHASE 6 FIX: Derive status counts from already-fetched arrays â€” no redundant GROUP BY query
		$derived_status = array(
			'pending'   => count($pending),
			'queued'    => 0,
			'processing' => 0,
			'generating' => 0,
			'finalizing' => 0,
			'done'      => $completed_total,
			'failed'    => 0,
			'timeout'   => 0,
		);
		foreach ($pipeline as $p) {
			$s = $p['status'] ?? '';
			if (isset($derived_status[$s])) $derived_status[$s]++;
		}
		$derived_status['failed']  = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} d WHERE d.status = 'failed'");
		$derived_status['timeout'] = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} d WHERE d.status = 'timeout'");
		$status = array(
			'enabled' => $is_paused ? 0 : 1,
			'label'  => $is_paused ? 'Paused' : 'Running',
			'icon'   => $is_paused ? 'â¸' : 'âœ“',
			'raw'    => $derived_status,
			'cards'  => array(
				'pending'  => $derived_status['pending'],
				'pipeline' => count($pipeline),
				'done'    => $completed_total,
				'failed'  => $failed_total,
			),
		);

		$today              = $this->get_discovery_day_snapshot();

		if (!\function_exists('seo_gen_render_pipeline_table') || !\function_exists('seo_gen_render_pending_table') || !\function_exists('seo_gen_render_failed_table')) {
			\ob_start();
			require_once \SEO_GEN_PLUGIN_DIR . 'admin/views/discovery-dashboard.php';
			\ob_end_clean();
		}

		$snapshot = array(
			'discovery' => array(
				'enabled' => ! $this->is_discovery_paused() ? 1 : 0,
				'label'   => ! $this->is_discovery_paused() ? 'Running' : 'Paused',
			),
			'tabs' => array(
				'pending'  => count($pending),
				'pipeline' => count($pipeline),
				'done'     => (int) ($status['cards']['done'] ?? 0),
				'failed'   => (int) ($status['cards']['failed'] ?? 0),
			),
			'cards' => array(
				'counts'    => (array) ($status['cards'] ?? array()),
				'today'     => $today,
				'activity'  => $this->get_dashboard_activity_snapshot(),
				'health'    => $this->get_dashboard_health_snapshot(),
				'api'       => array(
					'stats' => $this->get_dashboard_api_call_stats(),
					'pause' => $this->get_api_pause_info(),
				),
				'scanners'  => $this->get_scanner_cards_snapshot(),
				'sources'   => $this->get_sources_snapshot(),
				'next_runs' => $this->get_next_scheduled_run_data(),
				'as_queue'  => (int) $this->get_as_queue_count(),
				'shares'    => self::get_social_shares_snapshot(),
			),
			'lists' => array(
				'pending' => array(
					'rows'  => $pending,
					'count' => count($pending),
					'html'  => \seo_gen_render_pending_table($pending, $this->is_discovery_paused()),
				),
				'pipeline' => array(
					'rows'  => $pipeline,
					'count' => count($pipeline),
					'html'  => \seo_gen_render_pipeline_table($pipeline, $this->is_discovery_paused()),
				),
				'failed' => array(
					'rows'          => $failed,
					'count'         => count($failed),
					'total'         => $failed_total,
					'truncated'     => $failed_total > count($failed),
					'html'          => \seo_gen_render_failed_table($failed, $this->is_discovery_paused()),
				),
				'completed' => $completed_snapshot,
			),
		);

		$snapshot_to_cache = $snapshot;
		foreach (['pending', 'pipeline', 'failed'] as $list_key) {
			if (!empty($snapshot_to_cache['lists'][$list_key]['rows'])) {
				$snapshot_to_cache['lists'][$list_key]['rows'] = array_map(
					static function (array $row): array {
						unset($row['changelog']);
						return $row;
					},
					$snapshot_to_cache['lists'][$list_key]['rows']
				);
			}
		}
		if (!empty($snapshot_to_cache['lists']['completed']['rows'])) {
			$snapshot_to_cache['lists']['completed']['rows'] = array_map(
				static function (array $row): array {
					unset($row['changelog']);
					return $row;
				},
				$snapshot_to_cache['lists']['completed']['rows']
			);
		}

		\set_transient($cache_key, $snapshot_to_cache, 10);

		return $snapshot;
	}

	public function get_dashboard_snapshot(): array
	{
		return $this->build_dashboard_snapshot();
	}

	public function get_dashboard_ui_snapshot(): array
	{
		return $this->build_dashboard_snapshot();
	}

	/**
	 * Returns aggregated social share counts from Buffer and Jetpack post meta.
	 *
	 * @return array{total: int, buffer_total: int, jetpack_total: int, by_platform: array<string, array{buffer: int, jetpack: int}>}
	 */
	public static function get_social_shares_snapshot(): array
	{
		global $wpdb;

		$buffer_total    = 0;
		$jetpack_total   = 0;
		$by_platform     = array();
		$cutoff_date     = gmdate('Y-m-d H:i:s', strtotime('-30 days'));

		// --- Buffer shares from _seo_gen_buffer_share_history post meta ---
		$buffer_rows = $wpdb->get_col(
			"SELECT meta_value FROM {$wpdb->postmeta}
			 WHERE meta_key = '_seo_gen_buffer_share_history'
			   AND meta_value IS NOT NULL
			   AND meta_value != ''
			 LIMIT 5000"
		);

		foreach ($buffer_rows as $raw) {
			// WordPress postmeta stores arrays as PHP serialized strings (a:...), NOT JSON
			// Use maybe_unserialize() to handle both serialized and JSON (defensive)
			$history = is_string($raw) ? maybe_unserialize($raw) : null;
			if (!is_array($history)) {
				continue;
			}
			foreach ($history as $entry) {
				$shared_at = isset($entry['shared_at']) ? $entry['shared_at'] : '';
				if (empty($shared_at) || $shared_at < $cutoff_date) {
					continue;
				}
				$service = isset($entry['service']) ? strtolower($entry['service']) : 'unknown';
				if (empty($entry['channel_id'])) {
					continue;
				}
				$buffer_total++;
				if (!isset($by_platform[$service])) {
					$by_platform[$service] = array('buffer' => 0, 'jetpack' => 0);
				}
				$by_platform[$service]['buffer']++;
			}
		}

		// --- Jetpack shares from _wpas_done_* post meta (last 30 days only) ---
		$jetpack_done_posts = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT DISTINCT pm.post_id
				 FROM {$wpdb->postmeta} pm
				 INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				 WHERE pm.meta_key LIKE '_wpas_done_%%'
				   AND p.post_date_gmt > %s
				 LIMIT 5000",
				$cutoff_date
			)
		);

		if (!empty($jetpack_done_posts)) {
			$placeholders = implode(',', array_fill(0, count($jetpack_done_posts), '%d'));
			$prepared_query = $wpdb->prepare(
				"SELECT DISTINCT meta_key FROM {$wpdb->postmeta}
				 WHERE meta_key LIKE '_wpas_done_%%'
				 AND post_id IN ({$placeholders})
				 LIMIT 5000",
				...$jetpack_done_posts
			);
			$done_keys = $wpdb->get_col($prepared_query);

			$conn_service_map = array();
			if (class_exists('\Jetpack\Publicize') && method_exists('\Jetpack\Publicize', 'get_connections')) {
				try {
					$publicize = new \Jetpack\Publicize();
					foreach ($jetpack_done_posts as $pid) {
						$conns = $publicize->get_connections('post', (int) $pid);
						foreach ($conns as $conn) {
							$conn_id = $conn['id'] ?? $conn['connection_id'] ?? '';
							$service = strtolower($conn['service_name'] ?? '');
							if (!empty($conn_id) && !empty($service)) {
								$conn_service_map[$conn_id] = $service;
							}
						}
					}
				} catch (\Throwable $e) {
					// Jetpack unavailable â€” fall through to _wpas_done_all
				}
			}

			if (!empty($done_keys)) {
				$counts_query = $wpdb->prepare(
					"SELECT post_id, meta_key FROM {$wpdb->postmeta}
					 WHERE meta_key LIKE '_wpas_done_%'
					 AND post_id IN ({$placeholders})
					 LIMIT 10000",
					...$jetpack_done_posts
				);
				$counts = $wpdb->get_results($counts_query, ARRAY_A);

				$seen_pairs = array();
				foreach ((array) $counts as $row) {
					$pid   = (int) $row['post_id'];
					$mkey  = $row['meta_key'];
					$pair  = $pid . ':' . $mkey;
					if (isset($seen_pairs[$pair])) {
						continue;
					}
					$seen_pairs[$pair] = true;

					$service = '';
					if (preg_match('/^_wpas_done_(.+)$/', $mkey, $m)) {
						$conn_id = $m[1];
						if (isset($conn_service_map[$conn_id])) {
							$service = $conn_service_map[$conn_id];
						}
					}
					if (empty($service)) {
						$service = 'unknown';
					}
					$jetpack_total++;
					if (!isset($by_platform[$service])) {
						$by_platform[$service] = array('buffer' => 0, 'jetpack' => 0);
					}
					$by_platform[$service]['jetpack']++;
				}
			}
		}

		arsort($by_platform);

		return array(
			'total'         => $buffer_total + $jetpack_total,
			'buffer_total'  => $buffer_total,
			'jetpack_total' => $jetpack_total,
			'by_platform'   => $by_platform,
		);
	}

	/**
	 * Best-effort dashboard snapshot for post-mutation AJAX responses.
	 *
	 * If the full snapshot build throws (e.g. stale class reference, DB
	 * disconnect, or schema mismatch), return a minimal safe payload so
	 * that a successful state mutation is not turned into a failed AJAX
	 * response by an unrelated dashboard bug.
	 */
	private function safe_dashboard_ui_snapshot(): array
	{
		// Clear bootstrap cache unconditionally before reading
		$this->clear_dashboard_snapshot_transients();

		// N2 FIX: Always flush cache before post-mutation snapshot so it reflects the new state
		if (isset($this->processor) && is_object($this->processor)) {
			$this->processor->invalidate_dashboard_caches();
		}

		try {
			return $this->get_dashboard_ui_snapshot();
		} catch (\Throwable $e) {
			$this->logger->error(
				'Dashboard snapshot build failed after state mutation: ' . $e->getMessage(),
				array('trace' => $e->getTraceAsString())
			);

			return array(
				'discovery' => array(
					'enabled' => $this->is_discovery_paused() ? 0 : 1,
					'label'   => $this->is_discovery_paused() ? 'Paused' : 'Running',
				),
				'tabs'  => array(
					'pending'  => 0,
					'pipeline' => 0,
					'done'     => 0,
					'failed'   => 0,
				),
				'cards' => array(
					'counts'   => array(
						'pending'  => 0,
						'pipeline' => 0,
						'done'     => 0,
						'failed'   => 0,
					),
					'today'    => array(
						'done_today'   => 0,
						'failed_today' => 0,
					),
					'activity' => array(
						'new_posts_today'     => 0,
						'updated_posts_today' => 0,
						'new_posts_total'     => 0,
						'updated_posts_total' => 0,
					),
					'health'   => $this->get_dashboard_health_snapshot(),
					'api'      => array(
						'stats' => array(),
						'pause' => array(),
					),
					'scanners' => array(),
					'sources'  => array(),
					'next_runs'=> array(),
					'as_queue' => 0,
				),
				'lists' => array(
					'pending' => array(
						'rows'  => array(),
						'count' => 0,
						'html'  => '',
					),
					'pipeline' => array(
						'rows'  => array(),
						'count' => 0,
						'html'  => '',
					),
					'failed' => array(
						'rows'  => array(),
						'count' => 0,
						'html'  => '',
					),
					'completed' => array(
						'rows'  => array(),
						'count' => 0,
						'groups' => array(
							'today' => array(
								'count' => 0,
								'html'  => '',
							),
							'history' => array(
								'count' => 0,
								'html'  => '',
							),
						),
					),
				),
				'snapshot_error' => true,
			);
		}
	}

	private function get_row_actions_for_status(string $status): array
	{
		$status = strtolower(trim($status));

		return array(
			'approve' => ($status === 'pending'),
			'ignore'  => in_array($status, array('pending', 'failed', 'timeout', 'done'), true),
			'retry'   => in_array($status, array('failed', 'timeout'), true),
			'run_now' => in_array($status, array('queued', 'processing', 'generating', 'finalizing', 'failed', 'timeout', 'deferred'), true),
			'kill'    => in_array($status, array('queued', 'processing', 'generating', 'finalizing', 'deferred'), true),
		);
	}

	private function get_pipeline_display_status($item): array
	{
		$status       = (string) ($item->status ?? '');
		$job_status   = (string) ($item->job_status ?? '');
		$job_id       = (int) ($item->job_id ?? 0);
		$scheduled_at = (string) ($item->scheduled_at ?? '');
		$scheduled_ts = $scheduled_at !== '' ? strtotime($scheduled_at . ' UTC') : 0;
		$now_utc      = Plugin_Time::now_utc_ts();

		// Registry-first for active pipeline states - check AS before row mirror
		$registry_ts = 0;
		if (in_array($status, array('queued', 'processing', 'generating', 'finalizing', 'deferred'), true)) {
			if (! empty($item->id) && class_exists('SEO_Article_Generator\Queue\AS_Registry') && method_exists('SEO_Article_Generator\Queue\AS_Registry', 'get_next_item_run')) {
				$registry_ts = (int) \SEO_Article_Generator\Queue\AS_Registry::get_next_item_run((int) $item->id);
			}

			// Use only item-specific schedule, not broad hook fallback
			if ($registry_ts > 0) {
				$scheduled_ts = $registry_ts;
			}
		}

		$label = ucfirst($status);
		$class = $status;

		// Handle generating + jobid=0 as transitional identity, not generic generating forever
		if ($status === 'generating' && $job_id <= 0) {
			if ($scheduled_ts > $now_utc) {
				$label = 'Preparing Job';
				$class = 'processing';
			} else {
				$label = 'Reconciling Job';
				$class = 'waiting';
			}
			return array(
				'label' => $label,
				'class' => $class,
			);
		}

		if ($status === 'generating') {
			$jobLifecycle    = array();
			$jobId           = (int) ($item->job_id ?? 0);
			// PHASE 6 FIX: Use canonical provider status instead of Processor::get_generation_gate()
			$status_dto = AI_Client::get_provider_status();
			$gate = array(
				'ok' => !$status_dto['paused'],
				'temporary' => !empty($status_dto['temporary_blocked']),
				'reason' => $status_dto['reason'] ?? '',
				'retryafter' => $status_dto['min_retry_after'] ?? 0,
			);

			if ($jobId > 0 && isset($this->job_handler) && is_object($this->job_handler) && method_exists($this->job_handler, 'get_job_lifecycle_status')) {
				$jobLifecycle   = (array) $this->job_handler->get_job_lifecycle_status($jobId);
				$combined       = (string) ($jobLifecycle['combined_status'] ?? '');
				$shouldFinalize = ! empty($jobLifecycle['should_finalize']);
				$shouldContinue = ! empty($jobLifecycle['should_continue']);

				if ($scheduled_ts > $now_utc) {
					if ($shouldFinalize || $combined === 'completed') {
						$label = 'Waiting to Publish';
						$class = 'waiting';
					} elseif (! empty($gate['temporary'])) {
						$label = 'Quota Paused';
						$class = 'waiting';
					} else {
						$label = 'Waiting AI Queue';
						$class = 'waiting';
					}
				} elseif (in_array($combined, array('deferred', 'pending'), true)) {
					if (! empty($gate['temporary'])) {
						$label = 'Quota Paused';
						$class = 'waiting';
					} elseif ($shouldContinue) {
						$label = 'Waiting AI Queue';
						$class = 'waiting';
					} else {
						$label = 'Generating';
						$class = 'generating';
					}
				}
			}
		} elseif ($status === 'processing') {
			$label = 'Preparing';
			$class = 'processing';
		} elseif ($status === 'finalizing') {
			$label = 'Finalizing';
			$class = 'finalizing';
		}

		return array(
			'label' => $label,
			'class' => $class,
		);
	}

	private function reject_if_discovery_paused(string $action_label): void
	{
		if (! $this->is_discovery_paused()) {
			return;
		}

		\wp_send_json_error([
			'message' => sprintf('Discovery is paused. Resume it before %s.', $action_label),
			'paused'  => true,
		], 409);
	}

	/**
	 * Initialize hooks
	 *
	 * @MODIFIED 2026-03-01 - Register cron, menu, and AJAX hooks
	 */
	public function init()
	{
		if ($this->initialized) {
			return;
		}
		$this->initialized = true;

		// Register Action Scheduler listeners via centralized registry
		$this->as_registry->register();

		// Register non-AS hooks (job_finished, draft_processing, auto_gen cron)
		$this->processor->register_hooks();

		// Schedule Jobs using Action Scheduler
		\add_action('init', array($this, 'schedule_discovery_jobs'));

		// External heartbeat cron endpoint (?seo_gen_heartbeat=1&secret=<SECRET>).
		// Fires on `init` so it runs before any template rendering and before WP-Cron,
		// then exit()s. This is the server-independent watchdog trigger the operator
		// pings via their VPS crontab (mirrors WP Automatic's ?wp_automatic=cron).
		\add_action('init', array($this, 'handle_external_heartbeat'), 5);

		// Admin Menu & UI
		\add_action('admin_menu', array($this, 'register_admin_menu'));
		\add_action('admin_enqueue_scripts', array($this, 'enqueue_assets'));

		// AJAX endpoints
		\add_action('wp_ajax_seo_gen_approve_discovery', array($this, 'ajax_approve_item'));
		\add_action('wp_ajax_seo_gen_ignore_discovery', array($this, 'ajax_ignore_item'));

		// @MODIFIED 2026-03-02 - Added new discovery controls & pipeline status polling
		\add_action('wp_ajax_seo_gen_run_discovery_manual', array($this, 'ajax_run_discovery_manual'));
		\add_action('wp_ajax_seo_gen_active_ai_discovery', array($this, 'ajax_run_discovery_manual_ai_alias'));
		\add_action('wp_ajax_seo_gen_toggle_discovery', array($this, 'ajax_toggle_discovery'));
		\add_action('wp_ajax_seo_gen_clear_discovery_jobs', array($this, 'ajax_clear_discovery_jobs'));
		\add_action('wp_ajax_seo_gen_download_log', array($this, 'ajax_download_log'));

		// @MODIFIED 2026-03-02 - Pipeline & Retry AJAX (Dashboard Visibility rewrite)
		\add_action('wp_ajax_seo_gen_pipeline_status', array($this, 'ajax_pipeline_status'));
		\add_action('wp_ajax_seo_gen_retry_discovery', array($this, 'ajax_retry_item'));
		\add_action('wp_ajax_seo_gen_kill_pipeline_item', array($this, 'ajax_kill_pipeline_item'));

		// @MODIFIED 2026-03-02 - Source Manager AJAX
		\add_action('wp_ajax_seo_gen_add_source',              array($this, 'ajax_add_source'));
		\add_action('wp_ajax_seo_gen_update_source',           array($this, 'ajax_update_source'));
		\add_action('wp_ajax_seo_gen_delete_source',           array($this, 'ajax_delete_source'));
		\add_action('wp_ajax_seo_gen_test_source',             array($this, 'ajax_test_source'));
		\add_action('wp_ajax_seo_gen_create_wp_auto_campaign', array($this, 'ajax_create_wp_auto_campaign'));

		// @MODIFIED 2026-03-02 - One-time migration from legacy RSS settings
		$this->maybe_migrate_sources();

		// One-time discovery contract migration (type + existing_post_id coherence)
		if (method_exists($this, 'maybe_run_discovery_contract_migration')) {
			$this->maybe_run_discovery_contract_migration();
		}

		// @MODIFIED 2026-03-02 - WP Auto draft polling & settings
		\add_action('wp_ajax_seo_gen_save_wp_auto_settings', array($this, 'ajax_save_wp_auto_settings'));

		// Map Engine hooks transparently to the Engine without eagerly instantiating it
		\add_action('seo_gen_passive_discovery', function() { $e = $this->get_engine(); if ($e) $e->run_rss_discovery(); });
		\add_action('seo_gen_active_ai_discovery', function() { $e = $this->get_engine(); if ($e) $e->run_ai_update_checks(); });
		\add_action('seo_gen_wp_auto_draft_poll', function() { $e = $this->get_engine(); if ($e) $e->run_wp_auto_draft_poll(); });
		\add_action('seo_gen_delete_draft_post', function($id) { $e = $this->get_engine(); if ($e) $e->delete_draft_post($id); });



		// @MODIFIED 2026-03-02 v2.19.0 - Industrial Queue Architecture: Worker + Cron Mutex
		\add_action('seo_gen_queue_worker', array($this, 'run_queue_worker'));
		\add_action('seo_gen_queue_cleanup', array($this, 'run_queue_cleanup'));
		\add_action('seo_gen_overdue_recovery', array($this, 'run_overdue_recovery'));
		// @MODIFIED 2026-06-01 v2.29.0 - Publish Watchdog: force-publishes plugin-owned posts stuck in 'future'
		\add_action(AS_Registry::HOOK_PUBLISH_WATCHDOG, array($this, 'run_publish_watchdog'));

		// @MODIFIED 2026-07-23 - Sync Finalizer: DB-driven deferred slot detector.
		// Replaces AS/WP-Cron dependency for staggered finalization dispatch.
		// Runs every 60s and queries scheduled_at <= NOW() directly.
		// String literals used instead of AS_Registry constants to avoid fatal on
		// servers where class-as-registry.php hasn't been synced with 2026-07-23 constants.
		\add_action('seo_gen_sync_finalizer', array($this, 'run_sync_finalizer'));
		\add_action('seo_gen_force_finalize', array($this, 'run_force_finalize'), 10, 3);

		// @MODIFIED 2026-07-12 - OpenRouter free model auto-sync (recurring every 3 days)
		\add_action(AS_Registry::HOOK_SYNC_OPENROUTER, array($this, 'sync_openrouter_models'));

		// OpenCode Zen free model auto-sync (sibling of OpenRouter sync, recurring every 3 days)
		\add_action(AS_Registry::HOOK_SYNC_ZEN, array($this, 'sync_zen_models'));

		// @MODIFIED 2026-03-03 - AS Queue Reset (emergency recovery)
		\add_action('wp_ajax_seo_gen_reset_as_queue', array($this, 'ajax_reset_as_queue'));

		// @MODIFIED 2026-03-18 - Deep Health Check + Diag button handler
		\add_action('wp_ajax_seogenhealthcheck', array($this, 'ajaxhealthcheck'));

	// REMOVED: ajax_dashboard_api_snapshot method does not exist â€” hook was orphaned causing fatal on AJAX poll

		// @MODIFIED 2026-03-04 - API Cooldown Reset
		\add_action('wp_ajax_seo_gen_reset_api_cooldown', array($this, 'ajax_reset_api_cooldown'));

		// @MODIFIED 2026-03-18 - Scanner Toggles
		\add_action('wp_ajax_seo_gen_toggle_scanner_mode', array($this, 'ajax_toggle_scanner_mode'));

		// @MODIFIED 2026-04-07 - Plugin Type Filter Toggle
		\add_action('wp_ajax_seo_gen_toggle_plugin_filter', array($this, 'ajax_toggle_plugin_filter'));

		// @MODIFIED 2026-03-05 - Auto-Generation Cron & AJAX
		\add_action('wp_ajax_seo_gen_save_auto_gen_settings', array($this, 'ajax_save_auto_gen_settings'));
		\add_action('seo_gen_settings_saved', array($this, 'schedule_discovery_jobs'));

		// @MODIFIED 2026-03-09: Bulk Retry, Purge, and Clear History AJAX
		\add_action('wp_ajax_seo_gen_retry_all_failed', array($this, 'ajax_retry_all_failed'));
		\add_action('wp_ajax_seo_gen_purge_discovery_history', array($this, 'ajax_purge_discovery_history'));
		\add_action('wp_ajax_seo_gen_clear_discovery_history', array($this, 'ajax_clear_discovery_history'));
		\add_action('wp_ajax_seo_gen_purge_processed_drafts', array($this, 'ajax_purge_processed_drafts'));

		// @MODIFIED 2026-03-23: WP Auto Poller AJAX
		\add_action('wp_ajax_seo_gen_trigger_wp_auto_poll', array($this, 'ajax_trigger_wp_auto_poll'));
		\add_action('wp_ajax_seo_gen_clear_wp_auto_log',    array($this, 'ajax_clear_wp_auto_log'));
		\add_action('wp_ajax_seogen_wp_auto_snapshot',      array($this, 'ajax_wp_auto_snapshot'));

		// @MODIFIED 2026-07 - External heartbeat cron admin controls
		\add_action('wp_ajax_seo_gen_regenerate_heartbeat_secret', array($this, 'ajax_regenerate_heartbeat_secret'));
		\add_action('wp_ajax_seo_gen_test_heartbeat',              array($this, 'ajax_test_heartbeat'));

		// @MODIFIED 2026-03-10: Manual Queue Run AJAX
		\add_action('wp_ajax_seo_gen_run_queue_now', array($this, 'ajax_run_queue_now'));
		\add_action('wp_ajax_seo_gen_run_item_now',  array($this, 'ajax_run_item_now'));

		// Centralized AS registration removed (duplicate)


		// @MODIFIED 2026-03-18 - AS Queue initialization (ensures tables exist)
		// Guard with did_action to prevent redundant initialization on every admin page load.
		if (!\did_action('action_scheduler_init') && \class_exists('ActionScheduler_DataController')) {
			try {
				\ActionScheduler_DataController::init();
			} catch (\Throwable $e) {
				$this->logger->error("Failed to initialize Action Scheduler DataStore: " . $e->getMessage());
			}
		}

// One-time migration: Fix batch size option typo
if (!\get_option(\SEO_Article_Generator\Option_Registry::MIGRATION_BATCH_TYPO_DONE)) {
	$typo_batch = \get_option('seo_gen_autogeneration_batch');
	if (false !== $typo_batch) {
		\update_option('seo_gen_auto_generation_batch', (int) $typo_batch);
		\delete_option('seo_gen_autogeneration_batch');
	}
	\update_option(\SEO_Article_Generator\Option_Registry::MIGRATION_BATCH_TYPO_DONE, '1');
}
	}

	/**
	 * One-time migration from legacy seo_gen_discovery_feeds textarea to seo_gen_discovery_sources array.
	 */
	private function maybe_migrate_sources()
	{
		$legacy_feeds = \get_option('seo_gen_discovery_feeds');
		if (empty($legacy_feeds)) {
			return;
		}

		$current_sources = \get_option('seo_gen_discovery_sources', []);
		if (!\is_array($current_sources)) {
			$current_sources = [];
		}

		$normalized_existing = false;
		foreach ($current_sources as &$source) {
			if (isset($source['scraper_type'])) {
				$normalized = $this->normalize_source_type((string) $source['scraper_type']);
				if ($normalized !== $source['scraper_type']) {
					$source['scraper_type'] = $normalized;
					$normalized_existing = true;
				}
			}
		}
		unset($source);

		if ($normalized_existing) {
			\update_option('seo_gen_discovery_sources', $current_sources);
		}

		$feeds =\array_filter(\array_map('trim',\explode("\n", $legacy_feeds)));
		if (empty($feeds)) {
			// If it's just whitespace, clear it and return
			\delete_option('seo_gen_discovery_feeds');
			return;
		}

		$added = 0;
		foreach ($feeds as $feed_url) {
			// Skip if already exists
			$exists = false;
			foreach ($current_sources as $src) {
				if (isset($src['feed_url']) && $src['feed_url'] === $feed_url) {
					$exists = true;
					break;
				}
			}

			if (!$exists) {
				$domain = \parse_url($feed_url, PHP_URL_HOST);
				$current_sources[] = [
					'id'            => \uniqid(),
					'label'         => $domain ?: 'Imported Feed',
					'feed_url'      => $feed_url,
					'scraper_type'  => 'auto',
					'status'        => 'pending',
					'last_tested'   => 0,
					'test_note'     => 'Migrated from legacy settings',
					'campaign_id'   => 0
				];
				$added++;
			}
		}

		if ($added > 0) {
			\update_option('seo_gen_discovery_sources', $current_sources);
		}

		// Clear the legacy option so we don't keep migrating
		\delete_option('seo_gen_discovery_feeds');
	}

	/**
	 * One-time migration: canonicalize type + existing_post_id for all discovery rows.
	 * Runs once, then sets seo_gen_discovery_contract_migration to '2026-04-02-1'.
	 */
	private function maybe_run_discovery_contract_migration(): void
	{
		$version = (string) \get_option('seo_gen_discovery_contract_migration', '');

		if ($version === '2026-04-02-2') {
			return;
		}

		global $wpdb;
		$table = Installer::table_discovery();

		$rows = $wpdb->get_results(
			"SELECT id, type, existing_post_id FROM {$table}",
			ARRAY_A
		);

		$repaired = 0;
		foreach ((array) $rows as $row) {
			$contract = Discovery_Engine::canonicalize_discovery_contract(
				(string) ($row['type'] ?? 'legacy'),
				(int) ($row['existing_post_id'] ?? 0)
			);

			if (
				(string) ($row['type'] ?? '') === $contract['type'] &&
				(int) ($row['existing_post_id'] ?? 0) === (int) $contract['existing_post_id']
			) {
				continue;
			}

			$wpdb->update(
				$table,
				array(
					'type'             => $contract['type'],
					'existing_post_id' => (int) $contract['existing_post_id'],
				),
				array('id' => (int) $row['id']),
				array('%s', '%d'),
				array('%d')
			);

			$repaired++;
		}

		if ($repaired > 0) {
			$this->logger->info("Discovery contract migration repaired {$repaired} rows.");
		}

		\update_option('seo_gen_discovery_contract_migration', '2026-04-02-2', false);
	}



	/**
	 * AJAX: Save WP Auto integration settings.
	 */
	public function ajax_save_wp_auto_settings(): void
	{
		\check_ajax_referer('seo_gen_nonce', 'nonce');
		if (! \current_user_can('manage_options')) {
			\wp_send_json_error(['message' => \__('Unauthorized', 'seo-article-generator')]);
		}

		$category_id    = \absint($_POST['wp_auto_category_id']  ?? 0);

		\update_option('seo_gen_wp_auto_category_id',  $category_id);

		// If category just configured, ensure poller is scheduled
		if ($category_id > 0) {
			AS_Registry::schedule_recurring_wp_auto_poll(15 * \MINUTE_IN_SECONDS);
		}

		// If category cleared, unschedule the poller
		if ($category_id === 0) {
			AS_Registry::unschedule_all(AS_Registry::HOOK_WP_AUTO_DRAFT_POLL);
		}

		// Calculate and return next poll time for UI feedback
		$next_poll = AS_Registry::get_next_run(AS_Registry::HOOK_WP_AUTO_DRAFT_POLL);
		$next_poll_formatted = $next_poll
			? Plugin_Time::site_datetime((int) $next_poll)
			: 'Not scheduled';

		\wp_send_json_success( array(
			'message'  => \__( 'Settings saved.', 'seo-article-generator' ),
			'snapshot' => $this->safe_dashboard_ui_snapshot(),
		) );
	}

	/**
	 * Ensure a single run of a hook at exactly the desired timestamp.
	 * Reschedules only if the current run drifts by more than 60 seconds.
	 */
	private function ensure_single_run(string $hook, int $desired_ts, callable $scheduler): void
	{
		$current = AS_Registry::get_next_run($hook);

		if ($current && \abs($current - $desired_ts) <= 60) {
			return;
		}

		AS_Registry::unschedule_all($hook);
		$scheduler($desired_ts);
	}

	/**
	 * Schedule passive, active, and auto-gen discovery tasks.
	 *
	 * Phase 3 invariants:
	 * - Static guard ensures this fires at most ONCE per PHP request, regardless
	 *   of how many callers trigger it (init, seo_gen_settings_saved, set_discovery_enabled,
	 *   ajax_toggle_scanner_mode, ajax_reset_api_cooldown). Without the guard, every
	 *   settings-save fires it twice (once via direct call, once via the hook).
	 * - All get_option() calls use Option_Registry constants and their canonical defaults.
	 * - is_discovery_paused() is the sole pause authority â€” no raw DISCOVERY_ENABLED read here.
	 *
	 * @MODIFIED 2026-03-01 - Added recurring job scheduling
	 */
	public function schedule_discovery_jobs( $force = false )
	{
		static $ran_this_request = false;
		if ( $ran_this_request && ! $force ) {
			return;
		}
		$ran_this_request = true;

		// Skip on post edit screens â€” schedule integrity is irrelevant here
		// and this method runs ~12-15 DB queries (AS schedule checks + option reads).
		global $pagenow;
		if ( ! $force && \is_admin() && in_array( $pagenow, array( 'post.php', 'post-new.php' ), true ) ) {
			return;
		}

		$midnight = Plugin_Time::next_site_midnight_utc_ts( Plugin_Time::now_utc_ts() );
		$defaults  = \SEO_Article_Generator\Option_Registry::defaults();

		// Cleanup is safe to keep scheduled even while paused.
		$this->ensure_single_run(
			AS_Registry::HOOK_QUEUE_CLEANUP,
			$midnight + ( 3 * \HOUR_IN_SECONDS ),
			static fn( int $ts ) => AS_Registry::schedule_cleanup( $ts )
		);

		if ( $this->is_discovery_paused() ) {
			AS_Registry::unschedule_all( AS_Registry::HOOK_PASSIVE_DISCOVERY );
			AS_Registry::unschedule_all( AS_Registry::HOOK_ACTIVE_DISCOVERY );
			AS_Registry::unschedule_all( AS_Registry::HOOK_WP_AUTO_DRAFT_POLL );
			AS_Registry::unschedule_all( AS_Registry::HOOK_AUTO_GEN_CRON );
			return;
		}

		$rss_enabled = (int) \get_option(
			\SEO_Article_Generator\Option_Registry::RSS_DISCOVERY_ENABLED,
			$defaults[ \SEO_Article_Generator\Option_Registry::RSS_DISCOVERY_ENABLED ]
		) === 1;

		$ai_enabled = (int) \get_option(
			\SEO_Article_Generator\Option_Registry::AI_DISCOVERY_ENABLED,
			$defaults[ \SEO_Article_Generator\Option_Registry::AI_DISCOVERY_ENABLED ]
		) === 1;

		if ($rss_enabled) {
			$this->ensure_single_run(
				AS_Registry::HOOK_PASSIVE_DISCOVERY,
				$midnight,
				static fn(int $ts) => AS_Registry::schedule_passive_discovery($ts)
			);
		} else {
			AS_Registry::unschedule_all(AS_Registry::HOOK_PASSIVE_DISCOVERY);
		}

		if ($ai_enabled) {
			$this->ensure_single_run(
				AS_Registry::HOOK_ACTIVE_DISCOVERY,
				$midnight + (2 * \HOUR_IN_SECONDS),
				static fn(int $ts) => AS_Registry::schedule_active_discovery($ts)
			);
		} else {
			AS_Registry::unschedule_all(AS_Registry::HOOK_ACTIVE_DISCOVERY);
		}

    if ((int) \get_option('seo_gen_wp_auto_category_id', 0) > 0) {
      $this->ensure_recurring_wp_auto_poll(15 * \MINUTE_IN_SECONDS);
    }

    // FINDING 3 FIX / Audit Enhancement 1: meta-watchdog verifies BOTH existence
    // AND interval of the recurring actions that power recovery. If a recurring
    // AS action was lost or its interval drifted, recreate it deterministically.
    // PASSING handler: when WP-Cron is disabled, directly invoke on overdue.
    //
    // HEARTBEAT GUARD: When the external heartbeat cron is the request origin,
    // handle_external_heartbeat() already invokes all four handlers explicitly.
    // Passing null for the handler here means ensure_recurring_watchdog() will
    // NOT directly invoke the handler (no double work), but it STILL re-arms the
    // recurring action when overdue so the AS schedule stays alive and the health
    // card reports Healthy. Execution is owned by the heartbeat's Phase 3.
    $queue_worker_handler        = $this->heartbeat_active ? null : array( $this, 'run_queue_worker' );
    $overdue_recovery_handler    = $this->heartbeat_active ? null : array( $this, 'run_overdue_recovery' );
    $sync_finalizer_handler      = $this->heartbeat_active ? null : array( $this, 'run_sync_finalizer' );
    $publish_watchdog_handler    = $this->heartbeat_active ? null : array( $this, 'run_publish_watchdog' );

    $this->ensure_recurring_watchdog( AS_Registry::HOOK_QUEUE_WORKER, 60, 30, $queue_worker_handler );

    // Audit Enhancement 1: Overdue post recovery - meta-watchdog checks every 60s (matches heartbeat).
    $this->ensure_recurring_watchdog( 'seo_gen_overdue_recovery', 60, 60, $overdue_recovery_handler );

    // @MODIFIED 2026-07-23 - Sync Finalizer: DB-driven deferred slot dispatch.
    // Runs every 60s; bypasses AS single-action dependency for staggered finalization.
    // String literal used instead of AS_Registry::HOOK_SYNC_FINALIZER constant
    // to avoid fatal on servers where class-as-registry.php hasn't been synced.
    $this->ensure_recurring_watchdog( 'seo_gen_sync_finalizer', 60, 10, $sync_finalizer_handler );

    // v2.29.0: Publish Watchdog - force-publishes plugin-owned posts stuck in 'future'.
    // Faster than WP-Cron's 5-min default and survives DISABLE_WP_CRON hosts.
    if ( (int) \get_option( \SEO_Article_Generator\Option_Registry::ENABLE_PUBLISH_WATCHDOG, 1 ) ) {
        $pw_interval = (int) \get_option(
            \SEO_Article_Generator\Option_Registry::PUBLISH_WATCHDOG_INTERVAL,
            \SEO_Article_Generator\Option_Registry::defaults()[ \SEO_Article_Generator\Option_Registry::PUBLISH_WATCHDOG_INTERVAL ]
        );
        $pw_interval = max( 60, $pw_interval );
        $this->ensure_recurring_watchdog( AS_Registry::HOOK_PUBLISH_WATCHDOG, $pw_interval, 10, $publish_watchdog_handler );
        } else {
            AS_Registry::unschedule_all( AS_Registry::HOOK_PUBLISH_WATCHDOG );
        }

        // @MODIFIED 2026-07-12 - OpenRouter free model auto-sync.
        // Only schedule when an OpenRouter-compatible provider exists.
        if ( \SEO_Article_Generator\AI\OpenRouter_Model_Sync::has_openrouter_provider() ) {
            $this->ensure_recurring_watchdog(
                AS_Registry::HOOK_SYNC_OPENROUTER,
                1 * \DAY_IN_SECONDS,
                1 * \DAY_IN_SECONDS,
                array( $this, 'sync_openrouter_models' )
            );
        } else {
            AS_Registry::unschedule_all( AS_Registry::HOOK_SYNC_OPENROUTER );
        }

        // OpenCode Zen free model auto-sync â€” sibling of the OpenRouter sync.
        // Only schedule when a Zen-compatible provider (api_url host = opencode.ai) exists.
        if ( \SEO_Article_Generator\AI\OpenCode_Zen_Model_Sync::has_zen_provider() ) {
            $this->ensure_recurring_watchdog(
                AS_Registry::HOOK_SYNC_ZEN,
                1 * \DAY_IN_SECONDS,
                1 * \DAY_IN_SECONDS,
                array( $this, 'sync_zen_models' )
            );
        } else {
            AS_Registry::unschedule_all( AS_Registry::HOOK_SYNC_ZEN );
        }

    // Auto-generation cron watchdog: protects seo_gen_auto_generation_cron from
    // silent AS runner failures on shared hosting. Without this, items stuck in
    // 'pending' status never auto-approve because the cron fires once and dies.
    if ( isset( $this->processor ) && is_object( $this->processor ) && method_exists( $this->processor, 'run_auto_generation' ) ) {
        $auto_gen_interval_raw = (int) \get_option(
            \SEO_Article_Generator\Option_Registry::AUTO_GENERATION_INTERVAL,
            \SEO_Article_Generator\Option_Registry::defaults()[ \SEO_Article_Generator\Option_Registry::AUTO_GENERATION_INTERVAL ]
        );
        $auto_gen_interval_sec = \SEO_Article_Generator\Option_Registry::interval_to_seconds( $auto_gen_interval_raw );
        $this->ensure_recurring_watchdog(
            AS_Registry::HOOK_AUTO_GEN_CRON,
            $auto_gen_interval_sec,
            30,
            array( $this->processor, 'run_auto_generation' )
        );
    }

    $this->reschedule_auto_gen_cron();
	}

	/**
	 * Meta-watchdog: guarantee a recurring AS action exists AND runs at the
	 * expected interval. This is the single authority that keeps the other
	 * watchdogs (queue worker, overdue recovery, publish watchdog) alive.
	 *
	 * If the action is missing OR its interval has drifted, it is unscheduled
	 * and re-created. Uses existing AS_Registry APIs only â€” no new authority.
	 *
	 * @since 2.30.x (Audit Enhancement 1)
	 *
	 * @param string $hook     Action Scheduler hook.
	 * @param int    $interval Expected interval in seconds.
	 * @param int    $offset   Initial offset when (re)creating.
	 */
	private function ensure_recurring_watchdog( string $hook, int $interval, int $offset, ?callable $handler = null ): void {
		// [FIX] Use the UNCACHED next-run. The cached get_next_run() returns a
		// 15s stale transient that survives unschedule_all(), so after a delete
		// the watchdog believes the action still exists and never recreates it,
		// leaving get_next_run_uncached() (health card) returning 0 -> Stalled.
		// Querying the store directly makes existence/overdue detection truthful.
		$next              = AS_Registry::get_next_run_uncached( $hook );
		$current_interval  = AS_Registry::get_recurring_interval( $hook );
		$recreated         = false;

		// â”€â”€ CHURN FIX â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
		// as_next_scheduled_action() (used internally by get_next_run()) uses
		// an object cache that can return stale false while the action EXISTS
		// in the DB store. get_recurring_interval() queries the store directly
		// and DOES find the action (interval > 0). When next=0 but interval>0
		// the action is healthy â€” skip recreate to eliminate the spam churn
		// that was generating hundreds of "Re-ensured" log lines per minute.
		//
		// Three cases:
		//   A) next=0, interval=0  â†’ action genuinely missing â†’ recreate
		//   B) next=0, interval>0  â†’ action exists, get_next_run() cache stale
		//                            â†’ skip recreate (action is healthy)
		//   C) next>0, intervalâ‰ $interval â†’ interval drift â†’ recreate
		// â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
		if ( $next === 0 && $current_interval === 0 ) {
			// Case A: action genuinely does not exist
			// Safety: verify with has_scheduled_action which checks recurring
			// definitions, not just pending instances (avoids false positive
			// when instance is RUNNING and get_recurring_interval returns 0).
			$action_exists = AS_Registry::has_scheduled_action( $hook, array(), AS_Registry::GROUP );
			if ( ! $action_exists ) {
				AS_Registry::unschedule_all( $hook );
				AS_Registry::ensure_recurring_action( $offset, $interval, $hook, array() );
				$recreated = true;

				if ( $this->logger ) {
					$this->logger->info(
						sprintf(
							'[Meta-Watchdog] Re-created missing recurring action %s at %ds (was next=%d, interval=%d).',
							$hook,
							$interval,
							(int) $next,
							(int) $current_interval
						)
					);
				}
			} else {
				// Action exists but no pending instance â€” prime the cache
				// so subsequent get_next_run() calls don't return 0.
				$fresh_next = AS_Registry::get_next_run_uncached( $hook );
				if ( $fresh_next > 0 ) {
					$cache_key = 'as_nxt_' . md5( $hook . serialize( array() ) . '0' );
					set_transient( $cache_key, $fresh_next, 15 );
				}
			}
		} elseif ( $current_interval !== 0 && $current_interval !== $interval ) {
			// Case C: interval drift â€” recreate with correct interval
			AS_Registry::unschedule_all( $hook );
			AS_Registry::ensure_recurring_action( $offset, $interval, $hook, array() );
			$recreated = true;

			if ( $this->logger ) {
				$this->logger->info(
					sprintf(
						'[Meta-Watchdog] Re-ensured recurring action %s: interval drift %dsâ†’%ds (was next=%d).',
						$hook,
						(int) $current_interval,
						$interval,
						(int) $next
					)
				);
			}
		}
		// Case B (next=0, interval>0): action exists, get_next_run() cache
		// is stale â€” do nothing. The heartbeat will invoke the handler
		// directly and the AS runner will drain any pending tick.

		// OVERDUE DIRECT-EXECUTION: When WP-Cron is disabled the AS runner never
		// fires pending actions. The action sits with scheduled_at in the past
		// while ensure_recurring_watchdog above only checks existence/interval.
		// Detect when the action is overdue beyond interval+grace and directly
		// invoke the handler so the plugin is never starved by a silent AS runner.
		// The handler's own mutex (if any) prevents overlap with other invocations.
		// Skip if the action was just recreated above (stale $next would be misleading).
		// DEBOUNCE: Only recreate if last recreation was more than $interval ago
		// to prevent the log flood from repeated OVERDUE detections.
		// OVERDUE RE-ARM: detect a frozen/overdue recurring action and recreate
		// it with a fresh future schedule. This MUST run regardless of whether a
		// direct-invoke $handler was supplied (when the heartbeat already drives
		// execution, $handler is null but the recurring action still needs to be
		// kept alive so get_next_run_uncached() reports Healthy). The handler is
		// only directly invoked when one was actually provided.
		if ( $next > 0 && ! $recreated ) {
			$now            = \SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts();
			$grace          = \max( 60, (int) ( $interval * 0.5 ) );
			$overdue_cutoff = $now - ( $interval + $grace );

			if ( $next < $overdue_cutoff ) {
				// Debounce: check when we last recreated this action.
				$debounce_key  = 'seo_gen_watchdog_recreated_' . md5( $hook );
				$last_created  = (int) \get_transient( $debounce_key );

				if ( $last_created === false || ( $now - $last_created ) > $interval ) {
					// Recreate for future cycles. Clear the cached next-run
					// transient FIRST so ensure_recurring_action() does not read
					// the stale pre-unschedule value and skip recreation
					// (the same trap fixed in AS_Registry::ensure_recurring_action).
					AS_Registry::unschedule_all( $hook );
					$cache_key = 'as_nxt_' . md5( $hook . serialize( array() ) . '0' );
					\delete_transient( $cache_key );
					AS_Registry::ensure_recurring_action( $offset, $interval, $hook, array() );
					\set_transient( $debounce_key, $now, $interval );

					if ( $this->logger ) {
						$this->logger->info(
							sprintf(
								'[Meta-Watchdog] OVERDUE: %s was next=%d, now=%d (interval=%ds, grace=%ds). Re-armed recurring action.',
								$hook,
								(int) $next,
								(int) $now,
								$interval,
								$grace
							)
						);
					}

					// Only directly invoke the handler when one was supplied.
					// Skipped when the heartbeat already drives execution.
					if ( $handler ) {
						\call_user_func( $handler );
					}
				}
			}
		}
	}

	/**
	 * Ensure the WP Auto Draft Poll recurring action exists AND is not stuck.
	 *
	 * Unlike ensure_recurring_action() (which returns early whenever any pending
	 * instance exists), this also detects an OVERDUE pending instance â€” a
	 * recurring tick whose scheduled time is already in the past but has not been
	 * executed by Action Scheduler. Such a stuck instance makes get_next_run()
	 * report a stale past time and prevents the next tick from advancing. When
	 * the pending instance is overdue beyond the interval (+grace), it is
	 * unscheduled and recreated deterministically.
	 *
	 * @param int $interval Expected interval in seconds (15 * MINUTE_IN_SECONDS).
	 */
	private function ensure_recurring_wp_auto_poll(int $interval): void
	{
		$interval = \max(60, (int) $interval);
		$hook    = AS_Registry::HOOK_WP_AUTO_DRAFT_POLL;
		$next    = AS_Registry::get_next_run($hook);

		if ($next === 0) {
			AS_Registry::ensure_recurring_action(15, $interval, $hook, array());
			return;
		}

		$now            = \SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts();
		$grace          = 5 * \MINUTE_IN_SECONDS;
		$overdue_cutoff = $now - ($interval + $grace);

		if ($next < $overdue_cutoff) {
			AS_Registry::unschedule_all($hook);
			AS_Registry::ensure_recurring_action(15, $interval, $hook, array());

			if ($this->logger) {
				$this->logger->info(
					sprintf(
						'[WP-Auto Poll] Recreated overdue/stuck recurring action (was next=%d, now=%d, interval=%d).',
						(int) $next,
						(int) $now,
						(int) $interval
					)
				);
			}

			// DRIFT FIX: The recurring action is recreated at now+15, but on
			// shared hosting WP-Cron only fires on page loads. The recreated
			// action sits pending until the next page load triggers AS runner,
			// causing 1-2 hour gaps between poller runs instead of 15 minutes.
			// Directly invoke the poller here so it runs immediately on the
			// page load that detects the overdue condition. The mutex inside
			// run_wp_auto_draft_poll() prevents overlap with AS-fired instances.
			$engine = $this->get_engine();
			if ($engine) {
				$engine->run_wp_auto_draft_poll();
			}
		}
	}

	/**
	 * Reschedule the auto-generation cron based on current settings.
	 *
	 * @since 2.23.0
	 */
	public function reschedule_auto_gen_cron($force = false)
	{
		if (! \function_exists('as_next_scheduled_action')) {
			return;
		}

		$defaults = \SEO_Article_Generator\Option_Registry::defaults();
		$enabled  = \get_option(
			\SEO_Article_Generator\Option_Registry::ENABLE_AUTO_GENERATION,
			$defaults[ \SEO_Article_Generator\Option_Registry::ENABLE_AUTO_GENERATION ]
		);
		$interval = \get_option(
			\SEO_Article_Generator\Option_Registry::AUTO_GENERATION_INTERVAL,
			$defaults[ \SEO_Article_Generator\Option_Registry::AUTO_GENERATION_INTERVAL ]
		);

		$next_run = AS_Registry::get_next_run(AS_Registry::HOOK_AUTO_GEN_CRON);
		$last_applied_interval = \get_option(
			\SEO_Article_Generator\Option_Registry::AUTO_GENERATION_APPLIED_INTERVAL,
			$defaults[ \SEO_Article_Generator\Option_Registry::AUTO_GENERATION_APPLIED_INTERVAL ]
		);

if (!$force) {
		if ($enabled && $next_run && $last_applied_interval === $interval) {
			return;
		}
		if (!$enabled && !$next_run) {
			return;
		}
	}

	AS_Registry::unschedule_all(AS_Registry::HOOK_AUTO_GEN_CRON);

		if ($enabled) {
			$seconds = \SEO_Article_Generator\Option_Registry::interval_to_seconds( $interval );

			AS_Registry::schedule_recurring_auto_gen(Plugin_Time::now_utc_ts() + $seconds, $seconds);

		if ($last_applied_interval !== $interval || $force || !$next_run) {
			$logging_enabled = \get_option(
				\SEO_Article_Generator\Option_Registry::ENABLE_LOGGING,
				\SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::ENABLE_LOGGING]
			);
			if ($logging_enabled) {
				$this->logger->info("[Auto-Gen] Cron scheduled: every {$interval} minutes.");
			}
			\update_option( \SEO_Article_Generator\Option_Registry::AUTO_GENERATION_APPLIED_INTERVAL, $interval );
		}
		} else {
			\delete_option( \SEO_Article_Generator\Option_Registry::AUTO_GENERATION_APPLIED_INTERVAL );
		}
	}

	/**
	 * AJAX: Save Auto-Generation settings and reschedule cron.
	 *
	 * @since 2.23.0
	 */
	public function ajax_save_auto_gen_settings(): void
	{
		\check_ajax_referer('seo_gen_nonce', 'nonce');
		if (! \current_user_can('manage_options')) {
			\wp_send_json_error(['message' => \__('Unauthorized', 'seo-article-generator')]);
		}

		$enabled  = isset($_POST['seo_gen_enable_auto_generation']) ? (bool) $_POST['seo_gen_enable_auto_generation'] : false;
		$interval = \absint($_POST['seo_gen_auto_generation_interval'] ?? 60);
		if ($interval < 5) { $interval = 5; }
		if ($interval > 1440) { $interval = 1440; }
		$batch    = \absint($_POST['seo_gen_auto_generation_batch'] ?? 2);

		\update_option( \SEO_Article_Generator\Option_Registry::ENABLE_AUTO_GENERATION,   $enabled );
		\update_option( \SEO_Article_Generator\Option_Registry::AUTO_GENERATION_INTERVAL,  $interval );
		\update_option( \SEO_Article_Generator\Option_Registry::AUTO_GENERATION_BATCH,     $batch );

		$this->reschedule_auto_gen_cron(true);

		\wp_send_json_success( array(
			'message'  => \__( 'Auto-generation settings saved.', 'seo-article-generator' ),
			'snapshot' => $this->safe_dashboard_ui_snapshot(),
		) );
	}

	/**
	 * Register the Submenu under the main plugin menu
	 *
	 * @MODIFIED 2026-03-01 - Added Discovery Dashboard submenu
	 */
	public function register_admin_menu()
	{
		\add_submenu_page(
			'seo-generator',
			\__('Discovery Staging', 'seo-article-generator'),
			\__('Discovery Dashboard', 'seo-article-generator'),
			'manage_options',
			'seo-gen-discovery',
			array($this, 'render_dashboard')
		);
	}

	/**
	 * Enqueue UI scripts for the dashboard
	 */
	public function enqueue_assets($hook)
	{
		if ($hook !== 'seo-generator_page_seo-gen-discovery') {
			return;
		}

		// We use dashicons and standard WP styles, no external CSS/JS needed for now
		// AJAX logic is inlined in the view for simplicity as per plan
	}

	/**
	 * Render the UI
	 * 
	 * @MODIFIED 2026-03-02 - Pass stats to view
	 */
	public function render_dashboard()
	{
		$tab         = isset($_GET['stab']) ? \sanitize_key($_GET['stab']) : 'pending';
		$ai_provider = \get_option('seo_gen_api_provider', 'gemini');
		$stats       = \SEO_Article_Generator\Usage_Tracker::get_all_stats();

		// Calculate additional stats
		$posts_today = $this->get_posts_generated_today();
		$next_run    = $this->get_next_scheduled_run();

		$view_path = \SEO_GEN_PLUGIN_DIR . 'admin/views/discovery-dashboard.php';
		if (\file_exists($view_path)) {
			include $view_path;
		} else {
			echo '<div class="wrap"><h1>Discovery Dashboard</h1><p>View file not found.</p></div>';
		}
	}

	/**
	 * Get live activity stats for discovery (New Posts & Updates)
	 * 
	 * @return array{new_posts: int, updates: int}
	 */
	private function get_posts_generated_today(): array
	{
		return $this->get_dashboard_completed_activity_stats();
	}

	/**
	 * Get next scheduled run time
	 */
	private function get_next_scheduled_run()
	{
		return [
			'rss' => AS_Registry::get_next_run(AS_Registry::HOOK_PASSIVE_DISCOVERY),
			'ai'  => AS_Registry::get_next_run(AS_Registry::HOOK_ACTIVE_DISCOVERY)
		];
	}

	/**
	 * Get count of pending/failed AS actions for this plugin.
	 * 
	 * @return int
	 * @since 2.5.1
	 */
	private function get_as_queue_count(): int
	{
		$cache_key = 'seo_gen_as_queue_count';
		$cached    = \get_transient($cache_key);

		if (false !== $cached) {
			return (int) $cached;
		}

		if (!class_exists('\ActionScheduler') || !method_exists('\ActionScheduler', 'store')) {
			return 0;
		}

		$store = \ActionScheduler::store();

		if (!method_exists($store, 'query_actions')) {
			return 0;
		}

		$pending = (int) $store->query_actions(array(
			'group'   => self::as_group(),
			'status'  => \ActionScheduler_Store::STATUS_PENDING,
			'orderby' => 'none',
		), 'count');

		$failed = (int) $store->query_actions(array(
			'group'   => self::as_group(),
			'status'  => \ActionScheduler_Store::STATUS_FAILED,
			'orderby' => 'none',
		), 'count');

		$total = $pending + $failed;

		\set_transient($cache_key, $total, 30);

		return $total;
	}

	/**
	 * Normalize source type keys to the canonical backend values.
	 */
	public static function normalize_source_type(string $type): string
	{
		$type = \sanitize_key($type);

		$map = [
			'auto'            => 'auto',
			'native'          => 'native',
			'rss_feed'        => 'rssfeed',
			'rssfeed'         => 'rssfeed',
			'multi_scraper'   => 'multiscraper',
			'multiscraper'    => 'multiscraper',
			'article_scraper' => 'articlescraper',
			'articlescraper'  => 'articlescraper',
		];

		return $map[$type] ?? 'auto';
	}

	/**
	 * Dashboard card stats must count completed items only,
	 * using the same site-day/UTC conversion every time.
	 *
	 * [PERFORMANCE] Cached for 2 minutes as these counts are expensive.
	 *
	 * @return array{
	 *   new_posts:int,
	 *   updates:int,
	 *   new_posts_total:int,
	 *   updates_total:int
	 * }
	 */
	public function get_dashboard_completed_activity_stats(): array
	{
		return $this->get_dashboard_activity_snapshot();
	}

	public function get_dashboard_api_call_stats(): array
	{
		if (class_exists('\\SEO_Article_Generator\\AI\\AI_Client')
			&& method_exists('\\SEO_Article_Generator\\AI\\AI_Client', 'get_dashboard_metrics')) {

			$raw = \SEO_Article_Generator\AI\AI_Client::get_dashboard_metrics();

			$stats = array(
				'today'          => (int) ($raw['success_today'] ?? 0),
				'total'          => (int) ($raw['success_total'] ?? 0),
				'attempts_today' => (int) ($raw['attempts_today'] ?? 0),
				'attempts_total' => (int) ($raw['attempts_total'] ?? 0),
				'success_today'  => (int) ($raw['success_today'] ?? 0),
				'success_total'  => (int) ($raw['success_total'] ?? 0),
				'failures_today' => (int) ($raw['failures_today'] ?? 0),
				'failures_total' => (int) ($raw['failures_total'] ?? 0),
				'providers'      => (array) ($raw['providers'] ?? array()),
			);
		} elseif ( ! class_exists( '\\SEO_Article_Generator\\Usage_Tracker' ) ) {
			$stats = array(
				'today'          => 0,
				'total'          => 0,
				'attempts_today' => 0,
				'attempts_total' => 0,
				'success_today'  => 0,
				'success_total'  => 0,
				'failures_today' => 0,
				'failures_total' => 0,
				'providers'      => array(),
			);
		} else {

			$raw   = \SEO_Article_Generator\Usage_Tracker::get_all_stats();
			$map   = array();
			$today = 0;
			$total = 0;

			foreach ( (array) $raw as $row ) {
				$provider = \sanitize_key( (string) ( $row['provider'] ?? $row['id'] ?? '' ) );
				if ( in_array( $provider, array( 'google', 'google-gemini' ), true ) ) {
					$provider = 'gemini';
				}
				if ( '' === $provider ) {
					continue;
				}
				$pt = (int) ( $row['today'] ?? 0 );
				$pa = (int) ( $row['total'] ?? 0 );
				$map[ $provider ] = array(
					'attempts_today' => 0,
					'attempts_total' => 0,
					'success_today'  => $pt,
					'success_total'  => $pa,
					'failures_today' => 0,
					'failures_total' => 0,
				);
				$today += $pt;
				$total += $pa;
			}

			$stats = array(
				'today'          => $today,
				'total'          => $total,
				'attempts_today' => 0,
				'attempts_total' => 0,
				'success_today'  => $today,
				'success_total'  => $total,
				'failures_today' => 0,
				'failures_total' => 0,
				'providers'      => $map,
			);
		}

		$quota = array(
			'enabled'   => 0,
			'limit'     => 0,
			'used'      => 0,
			'remaining' => 0,
			'day'       => Plugin_Time::site_today_ymd(),
		);

		if (class_exists('\\SEO_Article_Generator\\AI\\AI_Client')
			&& method_exists('\\SEO_Article_Generator\\AI\\AI_Client', 'get_daily_quota_status')) {
			$quota = \SEO_Article_Generator\AI\AI_Client::get_daily_quota_status();
		}

		$stats['quota'] = array(
			'enabled'   => !empty($quota['enabled']) ? 1 : 0,
			'limit'     => max(0, (int) ($quota['limit'] ?? 0)),
			'used'      => max(0, (int) ($quota['used'] ?? 0)),
			'remaining' => max(0, (int) ($quota['remaining'] ?? 0)),
			'day'       => (string) ($quota['day'] ?? Plugin_Time::site_today_ymd()),
		);

		return $stats;
	}

	/**
	 * AJAX Handler: Run discovery manually
	 */
	/**
	 * AJAX Handler: Run discovery manually
	 * @MODIFIED 2026-04-09: Wrapped in scanner mutex guard.
	 */
	public function ajax_run_discovery_manual()
	{
		\check_ajax_referer("seo_gen_nonce", "nonce");
		if (!\current_user_can("manage_options")) {
			\wp_send_json_error(\__("Unauthorized", "seo-article-generator"));
		}

		$this->reject_if_discovery_paused("starting queue or generation work");

		$type = isset($_POST["type"]) ? \sanitize_text_field($_POST["type"]) : "rss";
		$scanner_type = ($type === "ai") ? "ai_scout" : "rss";

		$this->ajax_scanner_guard($scanner_type, function($engine) use ($type) {
			$this->logger->info("Manual discovery run triggered via AJAX. Type: {$type}");
			if ($type === "ai") {
				if ( "1" !== (string) \get_option( \SEO_Article_Generator\Option_Registry::AI_DISCOVERY_ENABLED, \SEO_Article_Generator\Option_Registry::defaults()[ \SEO_Article_Generator\Option_Registry::AI_DISCOVERY_ENABLED ] ) ) {
					throw new \Exception(__("AI Discovery is disabled. Enable it in Settings."));
				}
				$engine->run_ai_update_checks();
			} else {
				$engine->run_rss_discovery();
			}
		});

		\wp_send_json_success(array(
			"message"  => __("Discovery run completed.", "seo-article-generator"),
			"snapshot" => $this->safe_dashboard_ui_snapshot(),
		));
	}

	/**
	 * Backward-compatible alias: maps legacy seo_gen_active_ai_discovery AJAX
	 * call to seo_gen_run_discovery_manual with type=ai.
	 *
	 * Catches stale cached admin pages that still post the old action name.
	 */
	public function ajax_run_discovery_manual_ai_alias()
	{
		$_POST['type'] = 'ai';
		$this->ajax_run_discovery_manual();
	}

	/**
	 * AJAX Handler: Toggle individual scanner modes (RSS / AI Scout)
	 *
	 * Phase 2 invariants:
	 * - Scanner state is writable even when discovery is globally paused (takes effect on unpause).
	 * - update_option() for scanner keys uses Option_Registry constants â€” no raw strings.
	 * - After toggling, if both scanners are now disabled AND global discovery is enabled,
	 *   set_discovery_enabled(false) is called so the full pause cascade fires (hooks unscheduled,
	 *   pipeline suspended, caches cleared). Raw schedule_discovery_jobs() alone is not sufficient.
	 * - If discovery is already paused, scanner state is saved silently â€” no cascade needed.
	 */
	public function ajax_toggle_scanner_mode()
	{
		\check_ajax_referer('seo_gen_nonce', 'nonce');
		if (! \current_user_can('manage_options')) {
			\wp_send_json_error(\__('Unauthorized', 'seo-article-generator'));
		}

		// Removed: reject_if_discovery_paused() â€” scanner state must be settable while paused.
		// It takes effect when discovery is unpaused. Blocking it here deadlocks the UI.

		$type    = isset($_POST['type']) ? \sanitize_key($_POST['type']) : '';
		$enabled = isset($_POST['enabled']) ? (int) $_POST['enabled'] : 0;

		if ($type === 'rss') {
			\update_option( \SEO_Article_Generator\Option_Registry::RSS_DISCOVERY_ENABLED, $enabled );
		} elseif ($type === 'ai') {
			\update_option( \SEO_Article_Generator\Option_Registry::AI_DISCOVERY_ENABLED, $enabled );
		} else {
			\wp_send_json_error(array('message' => \__('Invalid scanner type.', 'seo-article-generator')));
			return;
		}

		// Combined-disable cascade:
		// If both scanners are now off AND global discovery is still marked enabled,
		// trigger the full pause path so the queue worker and AS hooks are actually stopped.
		// If discovery is already paused, skip â€” set_discovery_enabled() would be a no-op
		// and safe_dashboard_ui_snapshot() will reflect the current state accurately.
		$rss_enabled = (int) \get_option(
			\SEO_Article_Generator\Option_Registry::RSS_DISCOVERY_ENABLED,
			\SEO_Article_Generator\Option_Registry::defaults()[ \SEO_Article_Generator\Option_Registry::RSS_DISCOVERY_ENABLED ]
		);
		$ai_enabled = (int) \get_option(
			\SEO_Article_Generator\Option_Registry::AI_DISCOVERY_ENABLED,
			\SEO_Article_Generator\Option_Registry::defaults()[ \SEO_Article_Generator\Option_Registry::AI_DISCOVERY_ENABLED ]
		);
		$both_disabled      = ( $rss_enabled === 0 && $ai_enabled === 0 );
		$discovery_active   = ! $this->is_discovery_paused();

		if ( $both_disabled && $discovery_active ) {
			// Full pause cascade: unschedules hooks, suspends pipeline, clears caches.
			$this->set_discovery_enabled( false );
		} else {
			// At least one scanner is on (or discovery is already paused): just reschedule.
			$this->schedule_discovery_jobs();
			if ( isset($this->processor) && is_object($this->processor) ) {
				$this->processor->invalidate_dashboard_caches();
			}
		}

		\wp_send_json_success(array(
			'message'  => \__('Scanner setting updated.', 'seo-article-generator'),
			'snapshot' => $this->safe_dashboard_ui_snapshot(),
		));
	}

	/**
	 * AJAX Handler: Toggle plugin-generated post filter.
	 *
	 * @since 2.24.0
	 */
	public function ajax_toggle_plugin_filter(): void
	{
		\check_ajax_referer('seo_gen_nonce', 'nonce');

		if (! \current_user_can('manage_options')) {
			\wp_send_json_error(
				array('message' => __('Unauthorized', 'seo-article-generator')),
				403
			);
		}

		$enabled = isset($_POST['enabled']) ? (int) $_POST['enabled'] : 0;
		\update_option(Discovery_Engine::PLUGIN_FILTER_OPTION, $enabled ? 1 : 0, false);

		if ($enabled === 1 && isset($this->processor) && is_object($this->processor) && method_exists($this->processor, 'fail_plugin_filtered_pending_items')) {
			$this->processor->fail_plugin_filtered_pending_items();
		}

		if (isset($this->processor) && is_object($this->processor) && method_exists($this->processor, 'invalidate_dashboard_caches')) {
			$this->processor->invalidate_dashboard_caches();
		}

		\wp_send_json_success(array(
			'message'  => $enabled
				? __('Plugin-generated discoveries will stay visible in Failed until you disable the filter.', 'seo-article-generator')
				: __('All discovery types can process normally again.', 'seo-article-generator'),
			'snapshot' => $this->safe_dashboard_ui_snapshot(),
		));
	}

	private function set_discovery_enabled(bool $enabled): array
	{
		if ($enabled) {
			\update_option(\SEO_Article_Generator\Option_Registry::DISCOVERY_ENABLED, 1);
			$this->schedule_discovery_jobs();

			$affected = 0;
			if (isset($this->processor) && is_object($this->processor) && method_exists($this->processor, 'resume_pipeline')) {
				$affected = (int) $this->processor->resume_pipeline();
			}
			if (isset($this->processor) && is_object($this->processor)) {
				if (method_exists($this->processor, 'after_history_mutation_reconcile')) {
					$this->processor->after_history_mutation_reconcile();
				} elseif (method_exists($this->processor, 'invalidate_dashboard_caches')) {
					$this->processor->invalidate_dashboard_caches();
				}
			}
			$this->clear_dashboard_snapshot_transients();

			return array(
				'message'       => __('Discovery resumed and pipeline actions were re-armed.', 'seo-article-generator'),
				'enabled'       => 1,
				'affected_items'=> (int) $affected,
			);
		}

		\update_option(\SEO_Article_Generator\Option_Registry::DISCOVERY_ENABLED, 0);
		AS_Registry::unschedule_all(AS_Registry::HOOK_PASSIVE_DISCOVERY);
		AS_Registry::unschedule_all(AS_Registry::HOOK_ACTIVE_DISCOVERY);
		AS_Registry::unschedule_all(AS_Registry::HOOK_WP_AUTO_DRAFT_POLL);
		AS_Registry::unschedule_all(AS_Registry::HOOK_QUEUE_WORKER);
		AS_Registry::unschedule_all(AS_Registry::HOOK_AUTO_GEN_CRON);

		$affected = 0;
		if (isset($this->processor) && is_object($this->processor) && method_exists($this->processor, 'suspend_pipeline')) {
			$affected = (int) $this->processor->suspend_pipeline();
		}
		if (isset($this->processor) && is_object($this->processor)) {
			if (method_exists($this->processor, 'after_history_mutation_reconcile')) {
				$this->processor->after_history_mutation_reconcile();
			} elseif (method_exists($this->processor, 'invalidate_dashboard_caches')) {
				$this->processor->invalidate_dashboard_caches();
			}
		}
		$this->clear_dashboard_snapshot_transients();

		return array(
			'message'       => __('Discovery paused and pipeline actions were frozen.', 'seo-article-generator'),
			'enabled'       => 0,
			'affected_items'=> (int) $affected,
		);
	}

	/**
	 * AJAX Handler: Toggle discovery system
	 */
	public function ajax_toggle_discovery()
	{
		\check_ajax_referer('seo_gen_nonce', 'nonce');

		if (! \current_user_can('manage_options')) {
			\wp_send_json_error(['message' => __('Unauthorized', 'seo-article-generator')], 403);
		}

		$enabled = isset($_POST['enabled']) ? (int) $_POST['enabled'] : 1;

		\wp_send_json_success(
			array_merge(
				$this->set_discovery_enabled((bool) $enabled),
				array('snapshot' => $this->safe_dashboard_ui_snapshot())
			)
		);
	}

	/**
	 * AJAX Handler: Clear stuck/pending jobs
	 *
	 * @MODIFIED 2026-03-06: Unified with deep reset.
	 */
	public function ajax_clear_discovery_jobs()
	{
		\check_ajax_referer('seo_gen_nonce', 'nonce');
		if (!\current_user_can('manage_options')) {
			\wp_send_json_error(array('message' => 'Unauthorized'));
		}

		global $wpdb;

		$table = Installer::table_discovery();

		$this->reset_wp_auto_drafts();

		$ids = $wpdb->get_col(
			"SELECT id
			 FROM {$table}
			 WHERE status IN ('pending','failed','timeout','skippednotnewer')"
		);

		$deleted = 0;

		if (!empty($ids)) {
			$id_list_str = implode(',', array_map('intval', $ids));

			$job_ids = $wpdb->get_col(
				"SELECT job_id
				 FROM {$table}
				 WHERE id IN ({$id_list_str})
				   AND job_id > 0"
			);

			if (!empty($job_ids)) {
				foreach ($job_ids as $jid) {
					if ($this->job_handler && method_exists($this->job_handler, 'force_cancel_job')) {
						$this->job_handler->force_cancel_job((int) $jid, 'Discovery jobs cleared by user.');
					}
				}
			}

			foreach ((array) $ids as $id) {
				AS_Registry::cancel_item_actions((int) $id);
			}

			$deleted = (int) $wpdb->query(
				"DELETE FROM {$table}
				 WHERE id IN ({$id_list_str})"
			);
		}

		if (isset($this->processor) && is_object($this->processor)) {
			if (method_exists($this->processor, 'after_history_mutation_reconcile')) {
				$this->processor->after_history_mutation_reconcile();
			} elseif (method_exists($this->processor, 'invalidate_dashboard_caches')) {
				$this->processor->invalidate_dashboard_caches();
			}
		}
		$this->clear_dashboard_snapshot_transients();

		\wp_send_json_success(array(
			'message'  => sprintf(
				__('Cleared %d items, cancelled scheduled follow-ups, and reset processed flags for all category drafts.', 'seo-article-generator'),
				(int) $deleted
			),
			'deleted'  => (int) $deleted,
			'snapshot' => $this->safe_dashboard_ui_snapshot(),
		));
	}

	/**
	 * AJAX Handler: Download log file
	 */
	public function ajax_download_log()
	{
		// Nonce check via GET for direct link download
		if (!isset($_GET['_wpnonce']) || !\wp_verify_nonce($_GET['_wpnonce'], 'seo_gen_download_log')) {
			\wp_die(\__('Security check failed.', 'seo-article-generator'));
		}

		if (!\current_user_can('manage_options')) {
			\wp_die(\__('Unauthorized', 'seo-article-generator'));
		}

		// @MODIFIED 2026-03-10: Support downloading specific log files
		$filename = isset($_GET['log_file']) ? \sanitize_file_name($_GET['log_file']) : '';

		if ($filename && \strpos($filename, 'seo-generator-') !== false) {
			$upload_dir = \wp_upload_dir();
			$log_dir = $upload_dir['basedir'] . '/seo-generator-logs';
			$log_file = $log_dir . '/' . $filename;
		} else {
			$log_file = $this->logger->get_log_file();
		}

		if (!\file_exists($log_file)) {
			\wp_die(\__('Log file does not exist.', 'seo-article-generator'));
		}

		if (\ob_get_level()) {
			\ob_end_clean();
		}

		\header('Content-Description: File Transfer');
		\header('Content-Type: text/plain');
		\header('Content-Disposition: attachment; filename="' . \basename($log_file) . '"');
		\header('Expires: 0');
		\header('Cache-Control: must-revalidate');
		\header('Pragma: public');
		\header('Content-Length: ' . \filesize($log_file));

		\readfile($log_file);
		exit();
	}

	/**
	 * AJAX Handler: Approve and queue an item
	 *
	 * @MODIFIED 2026-03-01 - Added AJAX approval handler with security checks
	 */
	public function ajax_approve_item()
	{
		\check_ajax_referer('seo_gen_nonce', 'nonce');
		if (! \current_user_can('manage_options')) {
			\wp_send_json_error(\__('Unauthorized', 'seo-article-generator'));
		}

		$this->reject_if_discovery_paused('starting queue or generation work');

		$discovery_id = isset($_POST['id']) ? \absint($_POST['id']) : 0;

		$ok = $this->processor->approve_item($discovery_id, \get_current_user_id());

		if ($ok) {
			\wp_send_json_success(
				array(
					'message'  => \__('Added to Generation Queue!', 'seo-article-generator'),
					'queued'   => true,
					'snapshot' => $this->safe_dashboard_ui_snapshot(),
				)
			);
		} else {
            $error = $this->get_discovery_error_message($discovery_id);

            \wp_send_json_error(
                array(
                    'message' => $error !== ''
                        ? $error
                        : __('Failed to process item. Check plugin logs for details.', 'seo-article-generator'),
                )
            );
		}
	}

	/**
	 * AJAX Handler: Ignore/Dismiss an item
	 *
	 * Status-dependent behavior:
	 *   failed / timeout â†’ re-stage to pending (item returns to staging queue)
	 *   pending / done   â†’ permanent ignore (item is buried)
	 *
	 * @MODIFIED 2026-05-07 - Status-dependent dismiss: failed/timeout re-queues to pending
	 */
	public function ajax_ignore_item()
	{
		\check_ajax_referer('seo_gen_nonce', 'nonce');
		if (! \current_user_can('manage_options')) {
			\wp_send_json_error(\__('Unauthorized', 'seo-article-generator'));
		}

		$discovery_id = isset($_POST['id']) ? \absint($_POST['id']) : 0;
		if ($discovery_id <= 0) {
			\wp_send_json_error(array('message' => \__('Invalid item ID.', 'seo-article-generator')));
			return;
		}

		global $wpdb;
		$table = Installer::table_discovery();

		// Read current item state to decide target behavior
		$current = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT id, status, job_id FROM {$table} WHERE id = %d LIMIT 1",
				$discovery_id
			)
		);

		if (! $current) {
			\wp_send_json_error(array('message' => \__('Item not found.', 'seo-article-generator')));
			return;
		}

		$current_status = (string) $current->status;
		$linked_job_id  = (int) $current->job_id;

		// Dismiss from failed/timeout re-stages to pending so the item cycles
		// back through the normal pipeline. All other statuses (pending, done)
		// are permanently ignored.
		if (in_array($current_status, array('failed', 'timeout'), true)) {
			$update_data = array(
				'status'        => 'pending',
				'error_message' => null,
				'scheduled_at'  => null,
				'heartbeat_at'  => null,
				'job_id'        => null,
				'queue_job_id'  => null,
				'completed_at'  => null,
				// FIX F4 (Phase 3A): dismissing back to pending is an explicit
				// operator override — clear the breaker so the item can cycle again.
				'consecutive_failures'  => 0,
				'last_failure_at'       => null,
			);
			$format      = array('%s', '%s', '%s', '%s', '%d', '%d', '%s', '%d', '%s');
		} else {
			$update_data = array(
				'status'        => 'ignored',
				'error_message' => 'Killed manually by user.',
				'scheduled_at'  => null,
				'heartbeat_at'  => null,
				'job_id'        => null,
				'queue_job_id'  => null,
				'completed_at'  => Plugin_Time::utc_mysql_now(),
			);
			$format      = array('%s', '%s', '%s', '%s', '%d', '%d', '%s');
		}

		$updated = $wpdb->update(
			$table,
			$update_data,
			array('id' => $discovery_id),
			$format,
			array('%d')
		);

		if (false === $updated) {
			\wp_send_json_error(array('message' => \__('Failed to dismiss item.', 'seo-article-generator')));
			return;
		}

		// Cancel pending AS pipeline actions only for permanent ignores.
		// Failed/timeout items already had their AS actions cancelled by mark_discovery_failure().
		if (! in_array($current_status, array('failed', 'timeout'), true)) {
			AS_Registry::cancel_item_actions((int) $discovery_id);
		}

		// Force-cancel live job only for active items (pending/done).
		// Failed/timeout items have job_id already nulled by mark_discovery_failure().
		if (
			! in_array($current_status, array('failed', 'timeout'), true)
			&& $linked_job_id > 0
			&& $this->job_handler
		) {
			try {
				$this->job_handler->force_cancel_job((int) $linked_job_id, 'Discovery item dismissed by user.');
			} catch (\Throwable $e) {
				$this->logger->warning(
					'ajax_ignore_item: job_handler abort failed for job ' . $linked_job_id .
					' (discovery ' . $discovery_id . '): ' . $e->getMessage()
				);
			}
		}

		if (isset($this->processor) && is_object($this->processor) && method_exists($this->processor, 'invalidate_dashboard_caches')) {
			$this->processor->invalidate_dashboard_caches();
		}
		$this->clear_dashboard_snapshot_transients();

		\wp_send_json_success(array(
			'message'  => \__('Item dismissed.', 'seo-article-generator'),
			'snapshot' => $this->safe_dashboard_ui_snapshot(),
		));
	}

	/**
	 * AJAX: Return current pipeline HTML + count for live refresh.
	 *
	 * @MODIFIED 2026-03-02 [BUG-AJAX-PIPELINE] Fixed critical HTML pollution.
	 *
	 * ROOT CAUSE: require_once 'discovery-dashboard.php' executed the entire view,
	 * echoing ~30 KB of HTML+CSS+JS directly into the AJAX response before
	 *\wp_send_json_success() â€” corrupting the JSON payload on every poll.
	 * PHP logged this as a "syntax error in discovery-sources-manager.php:29"
	 * because that file's first non-PHP line (<div ...>) was the first thing PHP
	 * encountered after the malformed JSON handshake was attempted.
	 *
	 * FIX: Buffer all output during the include so the HTML is discarded,
	 * leaving only our explicit\wp_send_json_success() response on stdout.
	 *
	 * @MODIFIED 2026-03-02 - Pipeline & Retry AJAX (Dashboard Visibility rewrite)
	 */
	public function ajax_pipeline_status()
	{
		\check_ajax_referer('seo_gen_nonce', 'nonce');

		if (!\current_user_can('manage_options')) {
			\wp_send_json_error(array('message' => 'Unauthorized'), 403);
		}

		if (!\function_exists('seo_gen_render_pipeline_table')) {
			ob_start();
			require_once \SEO_GEN_PLUGIN_DIR . 'admin/views/discovery-dashboard.php';
			ob_end_clean();
		}

		\wp_send_json_success(array(
			'snapshot' => $this->safe_dashboard_ui_snapshot(),
		));
	}

/**
	 * Get live activity stats for AJAX refresh (unifies with dashboard.php logic)
	 */
	public function get_live_activity_stats(): array
	{
		$stats = $this->get_dashboard_completed_activity_stats();

		return [
			'new_posts' => (int) ($stats['new_posts_today'] ?? 0),
			'updates'   => (int) ($stats['updated_posts_today'] ?? 0),
		];
	}

	/**
	 * Get next scheduled run time data (timestamps + human diffs)
	 */
	private function get_next_scheduled_run_data()
	{
		$data = array('rss' => 0, 'ai' => 0, 'rss_human' => 'N/A', 'ai_human' => 'N/A');

		// Finding 6: Use centralized registry lookups
		$rss = AS_Registry::get_next_run(AS_Registry::HOOK_PASSIVE_DISCOVERY);
		$ai  = AS_Registry::get_next_run(AS_Registry::HOOK_ACTIVE_DISCOVERY);

		$now_utc = Plugin_Time::now_utc_ts();

		$data['rss'] = $rss ? (int) $rss : 0;
		$data['ai']  = $ai ? (int) $ai : 0;

		$data['rss_human'] = $rss ? \human_time_diff($now_utc, $rss) : 'N/A';
		$data['ai_human']  = $ai ? \human_time_diff($now_utc, $ai) : 'N/A';

		return $data;
	}


	/**
	 * AJAX: Reset a failed/timeout item back to 'pending' so it can be re-approved.
	 *
	 * @MODIFIED 2026-03-02 - Implemented for Pipeline Visibility rewrite
	 */
	public function ajax_retry_item()
	{
		\check_ajax_referer('seo_gen_nonce', 'nonce');
		if (!\current_user_can('manage_options')) {
			\wp_send_json_error(['message' => 'Unauthorized']);
		}

		$this->reject_if_discovery_paused('retrying failed items');

		$id = isset($_POST['id']) ? \absint($_POST['id']) : 0;
		if (!$id) {
			\wp_send_json_error(['message' => \__('Invalid ID', 'seo-article-generator')]);
		}

		if ($this->processor->retry_item($id, \get_current_user_id() ?: 1)) {
		\wp_send_json_success(array(
			'message'  => 'Item re-queued for processing.',
			'snapshot' => $this->safe_dashboard_ui_snapshot(),
		));
		} else {
            $error = $this->get_discovery_error_message($id);

            \wp_send_json_error([
                'message' => $error !== '' ? $error : 'Failed to retry item.',
            ]);
		}
	}

	/**
	 * AJAX: Kill a stuck pipeline item (moves it to failed tab).
	 */
	public function ajax_kill_pipeline_item()
	{
		\check_ajax_referer('seo_gen_nonce', 'nonce');
		if (!\current_user_can('manage_options')) {
			\wp_send_json_error(['message' => 'Unauthorized']);
		}

		$id = isset($_POST['id']) ? \absint($_POST['id']) : 0;
		if (!$id) {
			\wp_send_json_error(['message' => \__('Invalid ID', 'seo-article-generator')]);
		}

		$user_id = \get_current_user_id() ? (int) \get_current_user_id() : 1;
		$ok = $this->processor->kill_pipeline_item($id, $user_id);

		if (! $ok) {
			\wp_send_json_error(array(
				'message' => __('Failed to kill item. It may no longer be in a killable pipeline state.', 'seo-article-generator'),
			));
		}

		\wp_send_json_success(array(
			'message'  => __('Item marked failed and scheduled follow-ups cancelled. In-flight generation, if already running, will stop on next lifecycle check.', 'seo-article-generator'),
			'snapshot' => $this->safe_dashboard_ui_snapshot(),
		));
	}

	// =========================================================================
	// SOURCE MANAGER AJAX HANDLERS
	// =========================================================================

	/**
	 * AJAX: Add a new feed source
	 */
	public function ajax_add_source()
	{
		\check_ajax_referer('seo_gen_nonce', 'nonce');
		if (! \current_user_can('manage_options')) {
			\wp_send_json_error(['message' => \__('Unauthorized.', 'seo-article-generator')]);
		}

		$feed_url = \esc_url_raw(\trim($_POST['feed_url'] ?? ''));
		$label    = \sanitize_text_field($_POST['label'] ?? '');
		$type = $this->normalize_source_type((string) ($_POST['type'] ?? 'auto'));

		if (empty($feed_url) || ! \filter_var($feed_url, FILTER_VALIDATE_URL)) {
			\wp_send_json_error(['message' => \__('Please enter a valid feed URL (must start with http:// or https://).', 'seo-article-generator')]);
		}

		$parsed = \parse_url($feed_url);
		$domain = $parsed['host'] ?? '';

		$sources = \get_option('seo_gen_discovery_sources', []);
		if (! \is_array($sources)) {
			$sources = [];
		}

		// Block duplicate feed URLs
		foreach ($sources as $s) {
			if ($s['feed_url'] === $feed_url) {
				\wp_send_json_error(['message' => \__('This feed URL is already in the source list.', 'seo-article-generator')]);
			}
		}

		$new_source = [
			'id'           => \wp_generate_uuid4(),
			'feed_url'     => $feed_url,
			'label'        => $label ?: $domain,
			'domain'       => $domain,
			'scraper_type' => $type,
			'campaign_id'  => 0,
			'status'       => 'untested',
			'last_tested'  => 0,
			'test_chars'   => 0,
			'test_note'    => '',
		];

		$sources[] = $new_source;
		\update_option('seo_gen_discovery_sources', $sources);

		// Sync: keep seo_gen_discovery_feeds (plain newline-delimited text) up to date
		$existing_feeds = \get_option('seo_gen_discovery_feeds', '');
		$feed_lines     = \array_filter(\array_map('trim', \explode("\n", $existing_feeds)));
		if (! \in_array($feed_url, $feed_lines, true)) {
			$feed_lines[] = $feed_url;
			\update_option('seo_gen_discovery_feeds', \implode("\n", $feed_lines));
		}

		\wp_send_json_success(['message' => 'Source added.', 'source' => $new_source]);
	}

	/**
	 * AJAX: Update an existing source
	 */
	public function ajax_update_source()
	{
		\check_ajax_referer('seo_gen_nonce', 'nonce');
		if (! \current_user_can('manage_options')) {
			\wp_send_json_error(['message' => 'Unauthorized.']);
		}

		$id       = \sanitize_key($_POST['id'] ?? '');
		$feed_url = \esc_url_raw(\trim($_POST['feed_url'] ?? ''));
		$label    = \sanitize_text_field($_POST['label'] ?? '');
		$type = $this->normalize_source_type((string) ($_POST['type'] ?? 'auto'));

		$sources = \get_option('seo_gen_discovery_sources', []);
		$updated = false;
		$old_url = '';

		foreach ($sources as &$source) {
			if ($source['id'] === $id) {
				$old_url                = $source['feed_url'];
				$source['feed_url']     = $feed_url;
				$source['label']        = $label ?: (\parse_url($feed_url, PHP_URL_HOST) ?? $label);
				$source['domain']       = \parse_url($feed_url, PHP_URL_HOST) ?? $source['domain'];
				$source['scraper_type'] = $type;
				$source['status']       = 'untested';
				$source['test_note']    = '';
				$source['last_tested']  = 0;
				$updated = true;
				break;
			}
		}
		unset($source);

		if (! $updated) {
			\wp_send_json_error(['message' => \__('Source not found.', 'seo-article-generator')]);
		}

		\update_option('seo_gen_discovery_sources', $sources);

		// Sync feeds if URL changed
		if ($old_url && $old_url !== $feed_url) {
			$feed_lines = \array_filter(\array_map('trim', \explode("\n", \get_option('seo_gen_discovery_feeds', ''))));
			$feed_lines = \array_values(\array_diff($feed_lines, [$old_url]));
			if (! \in_array($feed_url, $feed_lines, true)) {
				$feed_lines[] = $feed_url;
			}
			\update_option('seo_gen_discovery_feeds', \implode("\n", $feed_lines));
		}

		\wp_send_json_success(['message' => 'Source updated.']);
	}

	/**
	 * AJAX: Delete a source
	 */
	public function ajax_delete_source()
	{
		\check_ajax_referer('seo_gen_nonce', 'nonce');
		if (! \current_user_can('manage_options')) {
			\wp_send_json_error(['message' => 'Unauthorized.']);
		}

		$id = \sanitize_key($_POST['id'] ?? '');
		if (empty($id)) {
			\wp_send_json_error(['message' => \__('Missing source ID.', 'seo-article-generator')]);
		}

		$sources     = \get_option('seo_gen_discovery_sources', []);
		$removed_url = '';

		$filtered = \array_filter($sources, function ($s) use ($id, &$removed_url) {
			if ($s['id'] === $id) {
				$removed_url = $s['feed_url'];
				return false;
			}
			return true;
		});

		if (\count($filtered) === \count($sources)) {
			\wp_send_json_error(['message' => \__('Source not found.', 'seo-article-generator')]);
		}

		\update_option('seo_gen_discovery_sources', \array_values($filtered));

		if ($removed_url) {
			$feed_lines = \array_filter(\array_map('trim', \explode("\n", \get_option('seo_gen_discovery_feeds', ''))));
			$feed_lines = \array_values(\array_diff($feed_lines, [$removed_url]));
			\update_option('seo_gen_discovery_feeds', \implode("\n", $feed_lines));
		}

		\wp_send_json_success(['message' => 'Source removed.']);
	}

	/**
	 * AJAX: Test a scraper strategy
	 */
	public function ajax_test_source()
	{
		\check_ajax_referer('seo_gen_nonce', 'nonce');
		if (! \current_user_can('manage_options')) {
			\wp_send_json_error(['message' => 'Unauthorized.']);
		}

		$id           = \sanitize_key($_POST['id'] ?? '');
		$feed_url     = \esc_url_raw(\trim($_POST['feed_url'] ?? ''));
		$scraper_type = $this->normalize_source_type((string) ($_POST['scraper_type'] ?? 'auto'));
		$campaign_id  = \absint($_POST['campaign_id'] ?? 0);

		if (empty($feed_url)) {
			\wp_send_json_error(['message' => 'Missing feed URL.']);
		}

		require_once \ABSPATH . \WPINC . '/feed.php';
		$rss = \fetch_feed($feed_url);
		if (\is_wp_error($rss)) {
			if ($id) $this->update_source_test_status($id, 'failed', 0, 'Cannot fetch RSS: ' . $rss->get_error_message());
			\wp_send_json_error(['message' => \__('Cannot fetch RSS feed: ', 'seo-article-generator') . $rss->get_error_message()]);
		}

		$items = $rss->get_items(0, 3);
		if (empty($items)) {
			if ($id) $this->update_source_test_status($id, 'failed', 0, 'RSS feed is empty.');
			\wp_send_json_error(['message' => \__('RSS feed is empty.', 'seo-article-generator')]);
		}

		$test_url   = '';
		$test_title = '';
		foreach ($items as $item) {
			$permalink = $item->get_permalink();
			if (! empty($permalink) && \filter_var($permalink, FILTER_VALIDATE_URL)) {
				$test_url   = $permalink;
				$test_title = $item->get_title();
				break;
			}
		}

		if (empty($test_url)) {
			if ($id) $this->update_source_test_status($id, 'failed', 0, 'No valid permalink found in feed items.');
			\wp_send_json_error(['message' => \__('No valid permalink found in the first 3 items.', 'seo-article-generator')]);
		}

		$result    = null;
		$tier_used = 'unknown';

		switch ($scraper_type) {
			case 'native':
				$result    = \SEO_Article_Generator\Integration\WP_Automatic_Bridge::tier1_native_fetch_public($test_url);
				$tier_used = 'Native (wp_remote_get)';
				break;

			case 'rssfeed':
			case 'multiscraper':
			case 'articlescraper':
				if (! \SEO_Article_Generator\Integration\WP_Automatic_Bridge::is_available()) {
					if ($id) $this->update_source_test_status($id, 'failed', 0, 'WP Automatic plugin not active.');
					\wp_send_json_error(['message' => \__('WP Automatic plugin is not active or not yet initialized.', 'seo-article-generator')]);
				}
				$wp_auto_type_map = [
					'rssfeed'        => 'Feed',
					'multiscraper'   => 'Multi',
					'articlescraper' => 'Article',
				];
				$wp_type = $wp_auto_type_map[$scraper_type] ?? 'Multi';
				$result  = \SEO_Article_Generator\Integration\WP_Automatic_Bridge::tier2_wp_automatic_public($test_url, $wp_type, $campaign_id > 0 ? $campaign_id : null);
				$tier_used = 'WP Automatic ' . $wp_type;
				break;

			default: // 'auto'
				$result    = \SEO_Article_Generator\Integration\WP_Automatic_Bridge::scrape_url($test_url);
				$tier_used = 'Auto (priority)';
				break;
		}

		if (! $result || empty($result['content'])) {
			$note = 'No content returned for: ' . $test_url;
			if ($id) $this->update_source_test_status($id, 'failed', 0, $note);
			\wp_send_json_error(['message' => \__('Scraper returned empty content.', 'seo-article-generator'), 'test_url' => $test_url]);
		}

		$clean_text = \wp_strip_all_tags($result['content']);
		$chars      = \strlen($clean_text);
		$preview    = \substr($clean_text, 0, 400);
		$note       = $chars . ' chars via ' . $tier_used;
		$status     = $chars >= 300 ? 'success' : 'thin';

		if ($id) {
			$this->update_source_test_status($id, $status, $chars, $note, array(
				'tier'           => $tier_used,
				'test_url'       => $test_url,
				'test_title'     => $test_title,
				'campaign_ready' => \in_array($scraper_type, array('rssfeed', 'multiscraper', 'articlescraper'), true)
					? ($campaign_id > 0)
					: true,
			));
		}

		\wp_send_json_success([
			'status'      => $status,
			'char_count'  => $chars,
			'tier_used'   => $tier_used,
			'test_url'    => $test_url,
			'test_title'  => $test_title,
			'preview'     => $preview,
			'sufficient'  => $chars >= 300,
			'message'     => $chars >= 300 ? 'Source test passed.' : 'Source returned thin content.',
		]);
	}

	/**
	 * AJAX: Create a WP Automatic campaign
	 */
	public function ajax_create_wp_auto_campaign()
	{
		\check_ajax_referer('seo_gen_nonce', 'nonce');
		if (! \current_user_can('manage_options')) {
			\wp_send_json_error(['message' => \__('Unauthorized.', 'seo-article-generator')]);
		}

		if (! \SEO_Article_Generator\Integration\WP_Automatic_Bridge::is_available()) {
			\wp_send_json_error(['message' => \__('WP Automatic plugin is not active or not yet initialized.', 'seo-article-generator')]);
		}

		$id           = \sanitize_key($_POST['id'] ?? '');
		$feed_url     = \esc_url_raw(\trim($_POST['feed_url'] ?? ''));
		$scraper_type = $this->normalize_source_type((string) ($_POST['scraper_type'] ?? 'auto'));
		$label        = \sanitize_text_field($_POST['label'] ?? 'SEO-Gen Source');

		if (empty($feed_url)) {
			\wp_send_json_error(['message' => 'Missing feed URL.']);
		}

		$camp_type_map = [
			'rssfeed'        => 'Feed',
			'multiscraper'   => 'Multi',
			'articlescraper' => 'Article',
		];
		$wp_auto_camp_type = $camp_type_map[$scraper_type] ?? 'Multi';

		$campaign_title = 'SEO-Gen | ' . $label;

		global $wpdb;
		$existing_id = $wpdb->get_var($wpdb->prepare("SELECT ID FROM {$wpdb->posts} WHERE post_title = %s AND post_type = 'wp_automatic' LIMIT 1", $campaign_title));

		if ($existing_id) {
			\wp_delete_post((int) $existing_id, true);
		}

		$campaign_id = \wp_insert_post([
			'post_title'  => $campaign_title,
			'post_type'   => 'wp_automatic',
			'post_status' => 'publish',
		]);

		if (! $campaign_id || \is_wp_error($campaign_id)) {
			\wp_send_json_error(['message' => \__('Failed to create campaign.', 'seo-article-generator')]);
		}

		\update_post_meta($campaign_id, 'camp_type',        $wp_auto_camp_type);
		\update_post_meta($campaign_id, 'camp_url',         $feed_url);
		\update_post_meta($campaign_id, 'cg_post_status',   'draft');
		\update_post_meta($campaign_id, 'cg_update_record', 'yes');
		\update_post_meta($campaign_id, 'camp_keyword',     '');
		\update_post_meta($campaign_id, 'cg_post_author',   (string) \get_current_user_id());
		\update_post_meta($campaign_id, 'camp_active',      'yes');

		if ($wp_auto_camp_type === 'Feed') {
			\update_post_meta($campaign_id, 'camp_feed_url',    $feed_url);
			\update_post_meta($campaign_id, 'camp_items',       '10');
			\update_post_meta($campaign_id, 'camp_full_text',   'yes');
			\update_post_meta($campaign_id, 'camp_translate',   'no');
			\update_post_meta($campaign_id, 'camp_spin',        'no');
		}

		if (\in_array($wp_auto_camp_type, ['Multi', 'Article'], true)) {
			\update_post_meta($campaign_id, 'camp_spin',      'no');
			\update_post_meta($campaign_id, 'camp_translate', 'no');
		}

		$sources = \get_option('seo_gen_discovery_sources', []);
		foreach ($sources as &$source) {
			if ($source['id'] === $id) {
				$source['campaign_id'] = (int) $campaign_id;
				$source['status']      = 'untested';
				break;
			}
		}
		unset($source);
		\update_option('seo_gen_discovery_sources', $sources);

		$edit_url = \admin_url('edit.php?post_type=wp_automatic&action=edit&id=' . $campaign_id);

		\wp_send_json_success([
			'campaign_id' => $campaign_id,
			'edit_url'    => $edit_url,
			'message'     => \sprintf(\__('Campaign "%s" created. Fine-tune it in WP Automatic, then test.', 'seo-article-generator'), $campaign_title),
		]);
	}

	/**
	 * Private helper: Update source test status with enriched metadata.
	 */
	private function update_source_test_status(string $id, string $status, int $chars, string $note, array $meta = array()): void
	{
		$sources = \get_option('seo_gen_discovery_sources', array());

		if (! \is_array($sources)) {
			$sources = array();
		}

		foreach ($sources as &$source) {
			if (($source['id'] ?? '') !== $id) {
				continue;
			}

			$source['status']        = \sanitize_key($status);
			$source['last_tested']   = Plugin_Time::now_utc_ts();
			$source['test_chars']    = (int) $chars;
			$source['test_note']     = \mb_substr((string) $note, 0, 200);
			$source['last_tier']     = \sanitize_text_field((string) ($meta['tier'] ?? ''));
			$source['last_test_url'] = \esc_url_raw((string) ($meta['test_url'] ?? ''));
			$source['last_test_title'] = \sanitize_text_field((string) ($meta['test_title'] ?? ''));
			$source['campaign_ready'] = ! empty($meta['campaign_ready']) ? 1 : 0;
			break;
		}
		unset($source);

		\update_option('seo_gen_discovery_sources', $sources);
	}

	// =========================================================================
	// AS Queue Reset â€” Emergency Recovery
	// @MODIFIED 2026-03-03
	// =========================================================================

	/**
	 * AJAX: Clear all pending/failed SEO-Gen AS actions and reset cooldowns.
	 *
	 * Intended as an emergency recovery button from the Dashboard health card.
	 * It does NOT delete running actions; only 'pending' and 'failed' ones.
	 *
	 * @return void
	 */
			public function ajax_reset_as_queue()
	{
		\check_ajax_referer('seo_gen_nonce', 'nonce');
		if (! \current_user_can('manage_options')) {
			\wp_send_json_error(['message' => \__('Unauthorized', 'seo-article-generator')]);
		}

		try {
			$this->logger->info("AS Queue Reset triggered via AJAX.");
			global $wpdb;

			// Suppress DB errors to guarantee a clean JSON response
			$prev_suppress = $wpdb->suppress_errors(true);
			$deleted = 0;

			$as_actions = $wpdb->prefix . 'actionscheduler_actions';
			$as_groups  = $wpdb->prefix . 'actionscheduler_groups';

        if ($wpdb->get_var("SHOW TABLES LIKE '{$as_actions}'")) {
            $deleted = (int) $wpdb->query(
                $wpdb->prepare(
                    "DELETE a FROM {$as_actions} a
                    INNER JOIN {$as_groups} g ON a.group_id = g.group_id
                    WHERE g.slug = %s
                    AND a.status IN ('pending','failed')",
                    self::as_group()
                )
            );
        }

        // COMPREHENSIVE AS PURGE: Clean ALL seo-gen actions including orphans
        $purged_as_actions = \SEO_Article_Generator\Queue\AS_Registry::purge_all_seo_gen_actions();

        // 2. Clear known transients explicitly (Object Cache safe)
			if (class_exists('\\SEO_Article_Generator\\AI\\AI_Client')) {
				\SEO_Article_Generator\AI\AI_Client::reset_all_cooldowns();
			}

			// 3. Clear base keys
			\delete_transient('seo_gen_api_cooldown');
			\delete_transient('seo_gen_api_error_count');
			\delete_option('seo_gen_api_pause_reason');

			// 4. Reset active generation jobs safely.
			// Never bulk-fail pending/deferred jobs; that violates the job/queue CAS contract.
			$cancelled_jobs = 0;

			if ($wpdb->get_var("SHOW TABLES LIKE '" . $wpdb->esc_like(Installer::table_jobs()) . "'")) {
				$active_job_ids = $wpdb->get_col(
					"SELECT id
					 FROM " . Installer::table_jobs() . "
					 WHERE status IN ('processing','generating','validating')"
				);

				foreach ((array) $active_job_ids as $active_job_id) {
					if ($this->job_handler && method_exists($this->job_handler, 'force_cancel_job')) {
						if ($this->job_handler->force_cancel_job(
							(int) $active_job_id,
							'Job force-reset via dashboard queue cleared.'
						)) {
							$cancelled_jobs++;
						}
					}
				}

				$repo = new \SEO_Article_Generator\Queue\Job_Repository($wpdb);
				$repo->cleanup_stale_reservations();
			}

			$wpdb->suppress_errors($prev_suppress);
			if (\function_exists('wp_cache_flush')) \wp_cache_flush();

// 5. Reconcile discovery rows orphaned by queue reset
			$fixed = 0;

			if (isset($this->processor) && is_object($this->processor)) {
				if (method_exists($this->processor, 'reconcile_after_queue_reset')) {
					$fixed = (int) $this->processor->reconcile_after_queue_reset();
				}
				if (method_exists($this->processor, 'after_history_mutation_reconcile')) {
					$this->processor->after_history_mutation_reconcile();
				} elseif (method_exists($this->processor, 'invalidate_dashboard_caches')) {
					$this->processor->invalidate_dashboard_caches();
				}
			}

			$this->schedule_discovery_jobs();
			$this->reschedule_auto_gen_cron(true);

			AS_Registry::schedule_unique_single_action(
				Plugin_Time::now_utc_ts() + 1,
				AS_Registry::HOOK_QUEUE_WORKER,
				array()
			);

			$this->clear_dashboard_snapshot_transients();
			\delete_transient('seo_gen_as_queue_count');

			$msg = sprintf(
				__('Cleared %d SQL actions, purged %d AS actions, safely cancelled %d active jobs, and reconciled %d discovery items.', 'seo-article-generator'),
				(int) $deleted,
				(int) $purged_as_actions,
				(int) $cancelled_jobs,
				(int) $fixed
			);

			$this->logger->info('AS Reset: ' . $msg);

			\wp_send_json_success(array(
				'message'  => $msg,
				'snapshot' => $this->safe_dashboard_ui_snapshot(),
			));
		} catch (\Throwable $e) {
			$this->logger->error("AS Queue Reset failed: " . $e->getMessage());
			\wp_send_json_error(['message' => $e->getMessage()]);
		} finally {
			global $wpdb;
			$wpdb->suppress_errors(true);
		}
	}

	// =========================================================================
	// Industrial Queue Architecture â€” Worker & Cleanup
	// =========================================================================

	private function acquire_lock($lock_key)
	{
		$now = (string)Plugin_Time::now_utc_ts();
		if (\add_option($lock_key, $now, '', 'no')) {
			return true;
		}
		$existing = \get_option($lock_key);
		// ARCHITECTURAL FIX: Reduce stale lock window from 120s to 60s.
		// Matches AS worker timeout; faster recovery from worker death.
		if ($existing && (Plugin_Time::now_utc_ts() - (int) $existing) > 60) {
			\delete_option($lock_key);
			return \add_option($lock_key, $now, '', 'no');
		}
		return false;
	}

	private function release_lock($lock_key) { \delete_option($lock_key); }

	public function run_queue_worker()
	{
		// FIX TIMEOUT PROTECTION: raise PHP time limit so the handler cannot be
		// killed mid-run and marked STATUS_FAILED by AS. Without this, recurring
		// actions get killed after 5 consecutive failures (AS 3.9.3 threshold).
		$php_tl_qw = (int) ini_get( 'max_execution_time' );
		if ( $php_tl_qw > 0 ) {
			@set_time_limit( max( 60, $php_tl_qw ) );
		}

		$paused = $this->is_discovery_paused();
		$cleanup_types = array(
			\SEO_Article_Generator\Queue\Job_Types::CLEANUP_DISCOVERY,
			\SEO_Article_Generator\Queue\Job_Types::CLEANUP_RETENTION,
		);

		$lock_key = 'seo_gen_queue_worker_lock';
		if (! $this->acquire_lock($lock_key)) {
			return;
		}

		try {
			global $wpdb;

			$repo = new \SEO_Article_Generator\Queue\Job_Repository($wpdb);

			$repo->cleanup_stale_reservations();
			$repo->cleanup_stale_queued_jobs();

			$worker = new \SEO_Article_Generator\Queue\Queue_Worker($repo, $this->logger);
			$worker_result = $worker->run(45, $paused ? $cleanup_types : array());

			$sql = "SELECT COUNT(*)
				 FROM " . Installer::table_queue() . "
				 WHERE status = %s
				   AND available_at <= %s";
			$params = array(
				\SEO_Article_Generator\Queue\Job_Repository::STATUS_QUEUED,
				Plugin_Time::utc_mysql_now(),
			);

			if ($paused) {
				$sql .= ' AND type IN (' . implode(',', array_fill(0, count($cleanup_types), '%s')) . ')';
				$params = array_merge($params, $cleanup_types);
			}

			$open_ready = (int) $wpdb->get_var(
				$wpdb->prepare($sql, $params)
			);

		if ($open_ready > 0) {
			// ARCHITECTURAL FIX (next=1 corruption): The previous self-arming used
			// args=['wakeup_<microtime>']. Because the recurring queue_worker action
			// uses args=[], unschedule_all($hook, []) leaves the single wakeup action
			// behind. get_next_run() then returns its now-stale scheduled_at, producing
			// the persistent "next=1" OVERDUE feedback loop seen in production logs.
			// Fix: use args=[] (matching the recurring action) AND route through the
			// unique scheduler so a pending recurring/single instance short-circuits
			// instead of stacking another orphan row. If a recurring tick is already
			// pending, has_scheduled_action() returns true and we skip the single arm.
			if ( \SEO_Article_Generator\Queue\AS_Registry::is_ready_public() ) {
				\SEO_Article_Generator\Queue\AS_Registry::schedule_unique_single_action(
					\SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts() + 1,
					\SEO_Article_Generator\Queue\AS_Registry::HOOK_QUEUE_WORKER,
					array()
				);
			}

			$this->logger->info(
				'Queue Worker re-armed itself for remaining ready jobs.',
				array('queued_ready' => $open_ready)
			);
		}

			// â”€â”€ Deferred Finalization Watchdog â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
			// One-shot HOOK_CHECK_JOB actions depend on WP-Cron to fire. If WP-Cron is
			// disabled or the AS action was lost, a deferred item stays stuck in
			// 'generating' with a past scheduled_at and stale heartbeat indefinitely.
			// This watchdog runs every ~60s (via the recurring queue worker) and
			// re-schedules a check job for any such orphaned item â€” limited to 5 per
			// cycle to avoid DB pressure.
			$disc_table   = Installer::table_discovery();
			$uid           = \get_current_user_id() ? (int) \get_current_user_id() : 1;
			$window_min = (int) \get_option(
				\SEO_Article_Generator\Option_Registry::OVERDUE_RECOVERY_WINDOW_MIN,
				\SEO_Article_Generator\Option_Registry::defaults()[ \SEO_Article_Generator\Option_Registry::OVERDUE_RECOVERY_WINDOW_MIN ]
			);
			$stale_cutoff = gmdate( 'Y-m-d H:i:s', strtotime( '-' . max( 1, $window_min ) . ' minutes' ) );

			// @MODIFIED 2026-07-23 - Deferred items are now owned by run_sync_finalizer()
			// (seo_gen_sync_finalizer, every 60s). This watchdog is scoped to 'generating'
			// items only â€” those whose HOOK_PROCESS_ITEM was lost and need re-arming.
			// Scoping prevents double-scheduling between the Watchdog and Sync Finalizer,
			// and ensures 'deferred' items get DB-driven dispatch (no WP-Cron dependency).
			$orphaned = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT id, job_id FROM {$disc_table}
					 WHERE status = 'generating'
					   AND scheduled_at IS NOT NULL
					   AND scheduled_at <= %s
					   AND (heartbeat_at IS NULL OR heartbeat_at <= %s)
					 ORDER BY scheduled_at ASC
					 LIMIT 5",
					Plugin_Time::utc_mysql_now(),
					$stale_cutoff
				)
			);

			if ( ! empty( $orphaned ) ) {
				$rescheduled = 0;
				foreach ( (array) $orphaned as $orphan ) {
					$oid  = (int) $orphan->id;
					$ojid = (int) $orphan->job_id;
					if ( $oid > 0 && $ojid > 0 ) {
						// FIX POLL-STORM GUARD: skip if a HOOK_CHECK_JOB is already pending
						// for this item regardless of attempt value (mirrors run_sync_finalizer).
						$next_check_ts_qw = \SEO_Article_Generator\Queue\AS_Registry::get_next_check_job_for_item( $oid, $ojid );
						if ( $next_check_ts_qw > 0 ) {
							continue;
						}

						if ( \SEO_Article_Generator\Queue\AS_Registry::schedule_check_job( $oid, $ojid, $uid, 1, 30 ) ) {
							++$rescheduled;
						}
					}
				}
				if ( $rescheduled > 0 ) {
					$this->logger->info(
						"[Deferred Finalization Watchdog] Re-scheduled {$rescheduled} orphaned check job(s)."
					);
				}
			}
		} catch (\Throwable $e) {
			$this->logger->error('Queue Worker error: ' . $e->getMessage());
			$worker_result = array('reserved' => 0, 'completed' => 0, 'failed' => 0);
		} finally {
			$this->release_lock($lock_key);
		}

		return $worker_result;
	}

	public function run_queue_cleanup()
	{
		try {
			global $wpdb;
			// @MODIFIED 2026-04-07: Fixed class name and method name
			$repo    = new \SEO_Article_Generator\Queue\Job_Repository($wpdb);
			$deleted = $repo->purge_old_jobs(14); // 14-day history

			$disc_table = Installer::table_discovery();
			$now_utc    = Plugin_Time::utc_mysql_now();

			// Use retention config for terminal cleanup instead of hardcoded 72 hours
			$retention = $this->get_discovery_retention_config();
			$terminal_days = max(1, (int) ($retention['terminal_retention_days'] ?? 60));

			// FIX: Before deleting terminal discovery rows, schedule deletion for any
			// drafts that still reference live drafts. Without this, the retention job
			// loses the only mapping between orphaned drafts and the discovery system
			// after the row is deleted, leaving drafts permanently orphaned.
			$orphan_drafts = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT draft_post_id FROM {$disc_table}
					 WHERE draft_post_id IS NOT NULL AND draft_post_id > 0
					   AND status IN ('done','failed','timeout','skippednotnewer','skippedduplicate','ignored')
					   AND (
					       (completed_at IS NOT NULL AND completed_at < DATE_SUB(%s, INTERVAL %d DAY))
					       OR
					       (completed_at IS NULL AND discovered_at < DATE_SUB(%s, INTERVAL %d DAY))
					   )",
					$now_utc,
					$terminal_days,
					$now_utc,
					$terminal_days
				)
			);
			foreach ((array) $orphan_drafts as $orphan_id) {
				$orphan_id = (int) $orphan_id;
				if ($orphan_id > 0 && \get_post($orphan_id)) {
					Discovery_Engine::schedule_draft_deletion($orphan_id, 0);
				}
			}

			$disc_deleted = $wpdb->query(
				$wpdb->prepare(
					"DELETE FROM {$disc_table}
					 WHERE status IN ('done','failed','timeout','skippednotnewer','skippedduplicate','ignored')
					   AND (
					       (completed_at IS NOT NULL AND completed_at < DATE_SUB(%s, INTERVAL %d DAY))
					       OR
					       (completed_at IS NULL AND discovered_at < DATE_SUB(%s, INTERVAL %d DAY))
					   )",
					$now_utc,
					$terminal_days,
					$now_utc,
					$terminal_days
				)
			);
			$this->logger->info('[Queue Cleanup] Purged jobs: ' . $deleted . ', discovery: ' . $disc_deleted);
		} catch (\Throwable $e) {
			$this->logger->error('[Queue Cleanup] Error: ' . $e->getMessage());
		}
	}

	/**
	 * HOOK: seo_gen_sync_finalizer - DB-driven dispatch for deferred staggered items
	 *
	 * Runs every 60s to find items stuck in 'deferred' whose scheduled_at has passed.
	 * Bypasses AS/WP-Cron unreliability by using the recurring queue worker's
	 * reliable tick as the trigger, then scheduling standard check_jobs.
	 *
	 * @since 2026-07-23
	 */
	public function run_sync_finalizer() {
		// FIX TIMEOUT PROTECTION: raise PHP time limit so the handler cannot be
		// killed mid-run and marked STATUS_FAILED by AS.
		$php_tl_sf = (int) ini_get( 'max_execution_time' );
		if ( $php_tl_sf > 0 ) {
			@set_time_limit( max( 60, $php_tl_sf ) );
		}

		try {
			global $wpdb;
			$disc_table = Installer::table_discovery();
			$uid = \get_current_user_id() ? (int) \get_current_user_id() : 1;

			// @MODIFIED 2026-07-23 - Find deferred items whose stagger slot has passed.
			// heartbeat_at IS NULL OR stale (older than 300s) ensures items with
			// stale heartbeats from failed claims are also picked up instead of
			// staying invisible until the 15-minute overdue_recovery cycle.
			$stale_heartbeat_cutoff = \gmdate( 'Y-m-d H:i:s', \time() - 300 );
			$overdue = $wpdb->get_results($wpdb->prepare(
				"SELECT id, job_id FROM {$disc_table}
				 WHERE status = 'deferred'
				   AND scheduled_at IS NOT NULL
				   AND scheduled_at <= %s
				   AND (heartbeat_at IS NULL OR heartbeat_at <= %s)
				 ORDER BY scheduled_at ASC
				 LIMIT 10",
				Plugin_Time::utc_mysql_now(),
				$stale_heartbeat_cutoff
			));

		if ( ! empty( $overdue ) ) {
			$rearmed = 0;
			foreach ( (array) $overdue as $row ) {
				$oid  = (int) $row->id;
				$ojid = (int) $row->job_id;
				if ( $oid > 0 && $ojid > 0 ) {
					// FIX POLL-STORM GUARD: skip if a HOOK_CHECK_JOB is already pending
					// for this item regardless of attempt value. Previous guard probed
					// attempt=1 only, which missed checks rescheduled by
					// check_and_finalize_job() with attempt > 1.
					$next_check_ts = AS_Registry::get_next_check_job_for_item( $oid, $ojid );

					// FIX STALE CHECK REPLACEMENT: if the existing check-job is pending
					// but its scheduled timestamp is far in the past, WP-Cron is broken
					// and the action will never fire on its own. Unsubscribe the stale
					// row and re-arm a fresh check-job.
					if ( $next_check_ts > 0 ) {
						$now_ts_stale = \SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts();
						$stale_cutoff_stale = $now_ts_stale - 90;
						if ( $next_check_ts < $stale_cutoff_stale ) {
							AS_Registry::unschedule_check_jobs_for_item( $oid );
							$next_check_ts = 0;
						} else {
							continue;
						}
					}

					// Per-item jitter prevents AS action clustering when multiple
					// deferred items are discovered in the same cycle.
					$jitter = $oid % 5; // 0-4 second stagger
					if ( AS_Registry::schedule_check_job( $oid, $ojid, $uid, 1, $jitter ) ) {
						++$rearmed;
					}
				}
			}
			if ( $rearmed > 0 ) {
				$this->logger->info(
					'[Sync Finalizer] Re-armed ' . $rearmed . ' deferred check job(s).'
				);
			}
		}
		} catch ( \Throwable $e ) {
			$this->logger->error( '[Sync Finalizer] Error: ' . $e->getMessage() );
		}
	}

	/**
	 * HOOK: seo_gen_force_finalize - Async finalization callback for staggered Overdue Recovery
	 *
	 * Called by run_overdue_recovery after scheduling a staggered finalization.
	 * Uses force=true to bypass the window gate. cancel_item_actions() does NOT
	 * cancel this action since it is a separate hook from HOOK_CHECK_JOB.
	 *
	 * @param int $discovery_id
	 * @param int $job_id
	 * @param int $user_id
	 */
	public function run_force_finalize( $discovery_id, $job_id, $user_id ) {
		if ( $this->is_discovery_paused() ) {
			$this->logger->info( '[Force Finalize] Pipeline paused; skipping discovery ' . (int) $discovery_id );
			return;
		}

		$item = $this->processor->claim_item_for_finalization(
			(int) $discovery_id,
			(int) $job_id,
			false
		);

		if ( $item ) {
			$this->processor->auto_finalize( $item, (int) $job_id, (int) $user_id, true );
		} else {
			$this->logger->warning(
				'[Force Finalize] Claim failed for discovery ' . (int) $discovery_id .
				' job ' . (int) $job_id . ' â€” already processed or wrong status.'
			);
		}
	}

	/**
	 * HOOK: seo_gen_overdue_recovery - Auto-recovers posts stuck in "generating" with passed scheduled_at
	 * 
	 * Runs every 15 min via Action Scheduler to find and restart overdue posts.
	 * 
	 * @since 2.24.0
	 */
	public function run_overdue_recovery()
	{
		// FIX TIMEOUT PROTECTION: raise PHP time limit so the handler cannot be
		// killed mid-run and marked STATUS_FAILED by AS.
		$php_tl_or = (int) ini_get( 'max_execution_time' );
		if ( $php_tl_or > 0 ) {
			@set_time_limit( max( 60, $php_tl_or ) );
		}

		try {
			global $wpdb;
			$table = Installer::table_discovery();
			$now_utc = Plugin_Time::utc_mysql_now();
			
        // Audit Enhancement 4: window sourced from Option_Registry (single source of truth).
        $window_min = (int) \get_option(
            \SEO_Article_Generator\Option_Registry::OVERDUE_RECOVERY_WINDOW_MIN,
            \SEO_Article_Generator\Option_Registry::defaults()[ \SEO_Article_Generator\Option_Registry::OVERDUE_RECOVERY_WINDOW_MIN ]
        );
        $window_min   = max( 1, $window_min );
        $stale_cutoff = gmdate( 'Y-m-d H:i:s', strtotime( '-' . $window_min . ' minutes' ) );
        $overdue = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, job_id, status, scheduled_at, error_message, heartbeat_at, discovered_at
                FROM {$table}
                WHERE (
                    (status = 'generating' AND scheduled_at IS NOT NULL AND scheduled_at <= %s AND (heartbeat_at IS NULL OR heartbeat_at <= %s))
                    OR (status = 'finalizing' AND (scheduled_at IS NULL OR scheduled_at <= %s) AND (heartbeat_at IS NULL OR heartbeat_at <= %s))
                    OR (status = 'queued' AND (
                        (scheduled_at IS NOT NULL AND scheduled_at <= %s)
                        OR (scheduled_at IS NULL AND heartbeat_at IS NOT NULL AND heartbeat_at <= %s)
                        OR (scheduled_at IS NULL AND heartbeat_at IS NULL AND discovered_at <= %s)
                    ))
                    OR (status = 'processing' AND (heartbeat_at IS NULL OR heartbeat_at <= %s))
                    OR (status = 'deferred' AND scheduled_at IS NOT NULL AND scheduled_at <= %s)
                )
                ORDER BY COALESCE(scheduled_at, heartbeat_at, discovered_at) ASC
                LIMIT 50",
                $now_utc, $stale_cutoff, $now_utc, $stale_cutoff, $now_utc, $stale_cutoff, $stale_cutoff, $stale_cutoff, $now_utc
            )
        );
			
			if (empty($overdue)) {
				return;
			}
			
			$uid = \get_current_user_id() ? (int) \get_current_user_id() : 1;
			$recovered = 0;

			// â”€â”€ Separate statuses for targeted recovery â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
			$deferred_items     = array();
			$non_deferred_items = array();
			$queued_items       = array();
			foreach ( (array) $overdue as $row ) {
				if ( (string) $row->status === 'deferred' ) {
					$deferred_items[] = $row;
				} elseif ( (string) $row->status === 'queued' ) {
					$queued_items[] = $row;
				} else {
					$non_deferred_items[] = $row;
				}
			}

			// Resolve processor dependency once for all recovery paths (deferred
			// AND non-deferred). Previously $processor was only defined inside the
			// deferred_items block, causing the zombie-recovery check in the
			// non-deferred path (line ~4297) to silently fail with an undefined
			// variable warning â€” leaving finalizing items in an infinite reset loop.
			$processor = $this->processor;
			$as_stale_threshold_sec = $window_min * 60;

			// â”€â”€ Handle deferred items: stagger-finalize via async dispatch â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
			// An overdue deferred item missed its staggered slot. Since Sync Finalizer
			// (seo_gen_sync_finalizer) handles DB-driven dispatch every 60s, Overdue
			// Recovery now schedules staggered finalization to avoid batch-publish collapse.
			// Using seo_gen_force_finalize hook ensures cancel_item_actions() does NOT
			// remove this action (it only cancels HOOK_PROCESS_ITEM/HOOK_CHECK_JOB).
			if ( ! empty( $deferred_items ) ) {

				// Defensive: if the processor dependency is missing for any reason,
				// fall back to re-arming a normal check-job per item instead of
				// fataling the entire recovery loop.
				if ( ! ( $processor instanceof \SEO_Article_Generator\Discovery\Discovery_Processor ) ) {
					foreach ( $deferred_items as $row ) {
						$item_id = (int) $row->id;
						$job_id  = (int) $row->job_id;
						$updated = $wpdb->update(
							$table,
							array(
								'status'       => 'generating',
								'error_message'=> null,
								'scheduled_at' => null,
								'heartbeat_at' => null,
								'poll_count'   => 0,
							),
							array( 'id' => $item_id ),
							array( '%s', '%s', '%s', '%s', '%d' ),
							array( '%d' )
						);
						if ( (int) $updated === 1 ) {
							AS_Registry::schedule_check_job( $item_id, $job_id, $uid, 1, 30 );
							$recovered++;
							$this->logger->warning(
								sprintf( '[Overdue Recovery] Deferred item %d: processor unavailable, re-armed check-job.', $item_id )
							);
						}
					}
				} else {
				foreach ( $deferred_items as $row ) {
					$item_id = (int) $row->id;
					$job_id  = (int) $row->job_id;

					// Guard: only force-finalize if the job actually completed.
					// (Deferred items should always have a completed job, but never
					// assume â€” re-arm a normal check-job instead if not.)
					$job_state = $wpdb->get_var(
						$wpdb->prepare(
							'SELECT status FROM ' . Installer::table_jobs() . ' WHERE id = %d',
							$job_id
						)
					);

					if ( (string) $job_state !== 'completed' ) {
						// Not ready â€” let the normal check-job path handle it.
						$updated = $wpdb->update(
							$table,
							array(
								'status'       => 'generating',
								'error_message'=> null,
								'scheduled_at' => null,
								'heartbeat_at' => null,
								'poll_count'   => 0,
							),
							array( 'id' => $item_id ),
							array( '%s', '%s', '%s', '%s', '%d' ),
							array( '%d' )
						);
						if ( (int) $updated === 1 ) {
							AS_Registry::schedule_check_job( $item_id, $job_id, $uid, 1, 30 );
							$recovered++;
							$this->logger->info(
								sprintf( '[Overdue Recovery] Deferred item %d: job not completed, re-armed check-job.', $item_id )
							);
						}
						continue;
					}

					// Claim to finalizing + schedule staggered finalization.
					// Pre-claim ensures only one recovery path processes this item.
					$claimed = $processor->claim_item_for_finalization( $item_id, $job_id );
					if ( ! $claimed ) {
						$this->logger->warning(
							sprintf( '[Overdue Recovery] Deferred item %d: claim failed, skipping.', $item_id )
						);
						continue;
					}

					$recovered++;
					$this->logger->info(
						sprintf(
							'[Overdue Recovery] Deferred item %d: scheduling staggered finalization (overdue slot missed).',
							$item_id
						)
					);

					// Stagger delay: 2-6 seconds based on item_id to prevent
					// all overdue items from publishing in the same second.
					// seo_gen_force_finalize is a separate hook; cancel_item_actions
					// inside claim_item_for_finalization only cancels HOOK_PROCESS_ITEM
					// and HOOK_CHECK_JOB, NOT this scheduled action.
					$stagger_delay = ((int) $row->id % 5) + 2; // 2-6 seconds
					$scheduled_ok  = false;

					try {
						// Validate the returned action_id â€” as_schedule_single_action
						// silently returns 0/false when AS is degraded (DB write fails,
						// table locked, post-store invalid) WITHOUT throwing. Without
						// this check the row would sit in 'finalizing' with no force
						// finalize ever firing until the next Overdue Recovery tick
						// re-discovers it ~900s later.
						if ( AS_Registry::is_ready_public() ) {
							$action_id = \as_schedule_single_action(
								Plugin_Time::now_utc_ts() + $stagger_delay,
								AS_Registry::HOOK_FORCE_FINALIZE,
								[ $item_id, $job_id, $uid ],
								AS_Registry::GROUP,
								false,
								10
							);
							$scheduled_ok = \is_numeric( $action_id ) && (int) $action_id > 0;
						}
					} catch ( \Throwable $e ) {
						$this->logger->error(
							sprintf( '[Overdue Recovery] Deferred item %d stagger-schedule error: %s', $item_id, $e->getMessage() )
						);
					}

					if ( $scheduled_ok ) {
						continue;
					}

					// Failure path: AS returned no action_id (silent degradation)
					// OR threw. The row is already in 'finalizing' with scheduled_at
					// NULL'd by claim_item_for_finalization(). Try synchronous
					// finalization first; on failure, re-arm a HOOK_CHECK_JOB so the
					// next 60s Sync Finalizer tick re-finalizes via the standard
					// chain instead of waiting 900s for Overdue Recovery.
					$this->logger->warning(
						sprintf(
							'[Overdue Recovery] Deferred item %d: force-finalize schedule failed â€” attempting synchronous finalization.',
							$item_id
						)
					);
					try {
						$processor->auto_finalize( $claimed, $job_id, $uid, true );
					} catch ( \Throwable $e ) {
						$this->logger->error(
							sprintf(
								'[Overdue Recovery] Deferred item %d synchronous finalize failed: %s â€” re-arming check-job for next Sync Finalizer tick.',
								$item_id,
								$e->getMessage()
							)
						);
						// Revert to 'generating' so the 60s Sync Finalizer (seo_gen_sync_finalizer)
						// picks it back up via the standard deferred-dispatch loop, instead of
						// leaving it orphaned in 'finalizing' until the 900s Overdue Recovery tick.
						$reverted = $wpdb->update(
							$table,
							array(
								'status'       => 'generating',
								'scheduled_at' => Plugin_Time::utc_mysql_from_utc_ts( Plugin_Time::now_utc_ts() + 60 ),
								'heartbeat_at' => null,
								'poll_count'   => 0,
								'error_message'=> sprintf( 'Force-finalize schedule failed: %s', $e->getMessage() ),
							),
							array( 'id' => $item_id, 'status' => 'finalizing' ),
							array( '%s', '%s', '%s', '%d', '%s' ),
							array( '%d', '%s' )
						);
						if ( (int) $reverted === 1 ) {
							AS_Registry::schedule_check_job( $item_id, $job_id, $uid, 1, 65 );
						}
					}
				}
				} // end else (processor available)
			}

			// FIX ARCHITECTURAL FALLBACK: deferred items past their slot that have
			// no pending check-job (sync_finalizer path is dead) must finalize
			// synchronously here, otherwise they wait until the next Overdue
			// Recovery tick â€” which itself may be dead.
			foreach ( (array) $deferred_items as $row ) {
				$df_item_id = (int) $row->id;
				$df_job_id  = (int) $row->job_id;

				if ( $df_item_id <= 0 || $df_job_id <= 0 ) {
					continue;
				}

				$pending_check_df = AS_Registry::get_next_check_job_for_item( $df_item_id, $df_job_id );
				if ( $pending_check_df > 0 ) {
					continue;
				}

				if ( ! ( $processor instanceof \SEO_Article_Generator\Discovery\Discovery_Processor ) ) {
					continue;
				}

				$job_state_df = (string) $wpdb->get_var(
					$wpdb->prepare(
						'SELECT status FROM ' . Installer::table_jobs() . ' WHERE id = %d',
						$df_job_id
					)
				);

				if ( $job_state_df !== 'completed' ) {
					continue;
				}

				$claimed_df = $processor->claim_item_for_finalization( $df_item_id, $df_job_id );
				if ( ! $claimed_df ) {
					continue;
				}

				try {
					$processor->auto_finalize( $claimed_df, $df_job_id, $uid, true );
					$recovered++;
					$this->logger->info(
						sprintf(
							'[Overdue Recovery] Deferred item %d: synchronous fallback finalization (no pending check-job for sync_finalizer).',
							$df_item_id
						)
					);
				} catch ( \Throwable $e_df ) {
					$this->logger->error(
						sprintf(
							'[Overdue Recovery] Deferred item %d synchronous fallback finalize failed: %s',
							$df_item_id,
							$e_df->getMessage()
						)
					);
				}
			}

			// â”€â”€ Handle non-deferred items (generating/finalizing/processing) â”€â”€â”€â”€â”€â”€â”€â”€
		foreach ((array) $non_deferred_items as $item) {
			$item_id     = (int) $item->id;
			$item_status = (string) $item->status;

			// FIX ZOMBIE RECOVERY: a 'generating'/'finalizing' discovery whose underlying
			// AI job is already 'completed' is a zombie â€” the check-job chain cannot
			// finalize it once poll_count hits MAX_POLL_ATTEMPTS, and the previous
			// unconditional reset at the bottom of this loop just rolled it back to
			// 'generating' forever. Mirrors run_item_now() semantics so automated
			// recovery matches what the admin Run Now button does.
			// Works WITHOUT $processor instance (heartbeat cron context).
			if ( in_array( $item_status, array( 'generating', 'finalizing' ), true )
				&& (int) $item->job_id > 0
			) {
				// NEW: Skip if already 'done' â€” prevents race with check_and_finalize_job
				// which may have already finalized this item in a concurrent run.
				$current_status = (string) $wpdb->get_var(
					$wpdb->prepare(
						'SELECT status FROM ' . Installer::table_discovery() . ' WHERE id = %d',
						$item_id
					)
				);
				if ( $current_status === 'done' ) {
					continue;
				}

				$zombie_job_state = (string) $wpdb->get_var(
					$wpdb->prepare(
						'SELECT status FROM ' . Installer::table_jobs() . ' WHERE id = %d',
						(int) $item->job_id
					)
				);
				if ( $zombie_job_state === 'completed' ) {
					// Claim directly via DB (replicates claim_item_for_finalization logic)
					$jobs_table = Installer::table_jobs();
					$expected_queue_job_id = (int) $wpdb->get_var(
						$wpdb->prepare(
							"SELECT queue_job_id FROM {$jobs_table} WHERE id = %d",
							(int) $item->job_id
						)
					);

					$claimable_statuses = array( 'queued', 'processing', 'generating', 'failed', 'timeout', 'finalizing', 'deferred' );
					$status_sql = "'" . implode( "','", array_map( 'esc_sql', $claimable_statuses ) ) . "'";

					$claimed = false;
					if ( $expected_queue_job_id > 0 ) {
						$claimed = (bool) $wpdb->query(
							$wpdb->prepare(
								"UPDATE {$table}
								 SET status = 'finalizing',
								     heartbeat_at = %s,
								     scheduled_at = NULL,
								     error_message = NULL
								 WHERE id = %d
								   AND status IN ({$status_sql})
								   AND (
								        job_id = %d
								        OR (job_id = 0 AND queue_job_id = %d)
								   )",
								Plugin_Time::utc_mysql_now(),
								$item_id,
								(int) $item->job_id,
								$expected_queue_job_id
							)
						);
					} else {
						$claimed = (bool) $wpdb->query(
							$wpdb->prepare(
								"UPDATE {$table}
								 SET status = 'finalizing',
								     heartbeat_at = %s,
								     scheduled_at = NULL,
								     error_message = NULL
								 WHERE id = %d
								   AND status IN ({$status_sql})
								   AND job_id = %d",
								Plugin_Time::utc_mysql_now(),
								$item_id,
								(int) $item->job_id
							)
						);
					}

					if ( $claimed ) {
						// Cancel any pending check/process actions for this item
						\SEO_Article_Generator\Queue\AS_Registry::cancel_item_actions( $item_id );

						// Schedule staggered force_finalize (same as deferred path)
						$stagger_delay = ((int) $item_id % 5) + 2; // 2-6 seconds
						$scheduled_ok = false;
						try {
							if ( \SEO_Article_Generator\Queue\AS_Registry::is_ready_public() ) {
								$action_id = \as_schedule_single_action(
									Plugin_Time::now_utc_ts() + $stagger_delay,
									\SEO_Article_Generator\Queue\AS_Registry::HOOK_FORCE_FINALIZE,
									[ $item_id, (int) $item->job_id, $uid ],
									\SEO_Article_Generator\Queue\AS_Registry::GROUP,
									false,
									10
								);
								$scheduled_ok = \is_numeric( $action_id ) && (int) $action_id > 0;
							}
						} catch ( \Throwable $e ) {
							$this->logger->error(
								sprintf( '[Overdue Recovery] Zombie item %d stagger-schedule error: %s', $item_id, $e->getMessage() )
							);
						}

						if ( $scheduled_ok ) {
							$recovered++;
							$this->logger->info(
								sprintf(
									'[Overdue Recovery] Zombie item %d (%s): underlying job completed â€” scheduled staggered finalize.',
									$item_id,
									$item_status
								)
							);
							continue;
						}

						// Fallback: synchronous finalize if processor available
						if ( $processor instanceof \SEO_Article_Generator\Discovery\Discovery_Processor ) {
							try {
								$claimed_item = $this->get_item( $item_id );
								if ( $claimed_item ) {
									$processor->auto_finalize( $claimed_item, (int) $item->job_id, $uid, true );
									$recovered++;
									$this->logger->info(
										sprintf(
											'[Overdue Recovery] Zombie item %d (%s): underlying job completed â€” synchronous finalize.',
											$item_id,
											$item_status
										)
									);
									continue;
								}
							} catch ( \Throwable $e_z ) {
								$this->logger->error(
									sprintf(
										'[Overdue Recovery] Zombie item %d synchronous finalize failed: %s',
										$item_id,
										$e_z->getMessage()
									)
								);
							}
						}

						// If both async and sync failed, revert to generating so sync_finalizer picks it up
						$wpdb->update(
							$table,
							array(
								'status'       => 'generating',
								'scheduled_at' => Plugin_Time::utc_mysql_from_utc_ts( Plugin_Time::now_utc_ts() + 60 ),
								'heartbeat_at' => null,
								'poll_count'   => 0,
								'error_message'=> 'Zombie recovery: force-finalize schedule failed',
							),
							array( 'id' => $item_id, 'status' => 'finalizing' ),
							array( '%s', '%s', '%s', '%d', '%s' ),
							array( '%d', '%s' )
						);
						\SEO_Article_Generator\Queue\AS_Registry::schedule_check_job( $item_id, (int) $item->job_id, $uid, 1, 65 );
					}
				}
			}

			// Only respect the stagger transient when heartbeat_at is still fresh
			// (meaning a deferred check job is actively alive). A stale/NULL heartbeat
			// means the check job itself has become unresponsive â€” the transient is
			// stale and must NOT block recovery.
			$heartbeat_fresh = ! empty( $item->heartbeat_at ) && strtotime( $item->heartbeat_at ) > $stale_cutoff;
			if ( $heartbeat_fresh && \get_transient( 'seo_gen_update_stagger_done_' . $item_id ) !== false ) {
				continue;
			}

			// Audit Enhancement 2/3: a 'processing' row whose HOOK_PROCESS_ITEM was
			// lost is stuck forever (overdue_recovery previously ignored it). If no
			// pending process action exists, re-issue it via the existing API.
			if ($item_status === 'processing') {
				$has_process = \SEO_Article_Generator\Queue\AS_Registry::has_scheduled_action(
					\SEO_Article_Generator\Queue\AS_Registry::HOOK_PROCESS_ITEM,
					array( $item_id, $uid ),
					\SEO_Article_Generator\Queue\AS_Registry::GROUP
				);
				if (! $has_process) {
					\SEO_Article_Generator\Queue\AS_Registry::schedule_process_item( $item_id, $uid, 5 );
					$recovered++;
					$this->logger->info( '[Overdue Recovery] Re-scheduled lost process action for discovery ' . $item_id );
				}
				continue;
			}

			// For 'generating' items that are stale: reset to 'queued' so they re-enter the pipeline.
			// For 'finalizing' items: do NOT reset here. If job completed, zombie recovery above
			// handled it. If job NOT completed, let the normal check-job chain handle it.
			// Resetting finalizing->generating causes infinite re-finalization loops.
			if ( $item_status === 'generating' ) {
				// FIX E (2026-09-06): the 09-05 root cause. The SQL above matches a
				// generating row the instant its next check-job runs even 1s late
				// (heartbeat_at is NULL for the whole generating phase, so the
				// window offers zero grace). Resetting here zeroed poll_count AND —
				// via the queued branch — spawned a duplicate AI job every tick
				// (2752 dupes on 09-05). Never reset a row whose job is alive;
				// just make sure its check-job is armed.
				$overdue_job_id = (int) ( $item->job_id ?? 0 );
				$overdue_alive  = false;
				if ( $overdue_job_id > 0 ) {
					try {
						$overdue_jh = ( isset( $this->job_handler ) && is_object( $this->job_handler ) && method_exists( $this->job_handler, 'get_job_lifecycle_status' ) )
							? $this->job_handler
							: new Job_Handler( $this->logger );
						$overdue_life     = (array) $overdue_jh->get_job_lifecycle_status( $overdue_job_id );
						$overdue_combined = (string) ( $overdue_life['combined_status'] ?? '' );
						// reconcile_failed is owned by snapshot recovery; polls handle it.
						$overdue_alive = ! empty( $overdue_life['should_continue'] )
							|| ! empty( $overdue_life['should_finalize'] )
							|| $overdue_combined === 'reconcile_failed';
					} catch ( \Throwable $e_overdue_life ) {
						$this->logger->warning( '[Overdue Recovery] lifecycle read failed for discovery ' . $item_id . ' job ' . $overdue_job_id . ': ' . $e_overdue_life->getMessage() );
					}
				}

				if ( $overdue_alive ) {
					// Job healthy — re-arm the check-job only if none is pending, then leave the row alone.
					$overdue_next = 0;
					try {
						$overdue_next = (int) AS_Registry::get_next_check_job_for_item( $item_id, $overdue_job_id );
					} catch ( \Throwable $e_overdue_next ) {
						$overdue_next = 0;
					}
					if ( $overdue_next <= 0 ) {
						AS_Registry::schedule_check_job( $item_id, $overdue_job_id, $uid, 1, 30 );
						$wpdb->update(
							$table,
							array( 'scheduled_at' => Plugin_Time::utc_mysql_from_utc_ts( Plugin_Time::now_utc_ts() + 30 ) ),
							array( 'id' => $item_id ),
							array( '%s' ),
							array( '%d' )
						);
						$this->logger->info( '[Overdue Recovery] Discovery ' . $item_id . ' generating with live job ' . $overdue_job_id . ' — check-job re-armed, no reset.' );
					}
					continue;
				}

				// Job dead/missing — but respect a grace window so slow polls under
				// load (heartbeats averaged 175s on 09-05) don't thrash the row.
				// The Step-A window (job_id=0, fresh schedule) must never reset:
				// Step C lands milliseconds later.
				$overdue_sched_ts = ! empty( $item->scheduled_at ) ? (int) strtotime( (string) $item->scheduled_at ) : 0;
				if ( $overdue_job_id <= 0 && $overdue_sched_ts > 0 && ( Plugin_Time::now_utc_ts() - $overdue_sched_ts ) < 600 ) {
					continue;
				}
				if ( $overdue_sched_ts > 0 && ( Plugin_Time::now_utc_ts() - $overdue_sched_ts ) < 300 ) {
					continue;
				}

				$target_status = 'queued';
				$updated = $wpdb->update(
					$table,
					array(
						'status' => $target_status,
						'error_message' => null,
						'scheduled_at' => null,
						'heartbeat_at' => null,
						'poll_count' => 0,
					),
					array('id' => $item_id),
					array('%s', '%s', '%s', '%s', '%d'),
					array('%d')
				);

				if ((int) $updated === 1) {
					if (!\SEO_Article_Generator\Queue\AS_Registry::schedule_check_job($item_id, (int) $item->job_id, $uid, 1, 30)) {
						$this->logger->warning('[Overdue Recovery] Failed to re-schedule check job for discovery ' . $item_id);
					}
					$recovered++;
					$this->logger->info( '[Overdue Recovery] Recovered discovery ' . $item_id . ' from status ' . $item_status . ' to ' . $target_status );
				}
			} else {
				// item_status === 'finalizing' but job not completed â€” skip, let check-job handle
				$this->logger->info( '[Overdue Recovery] Skipping finalizing item ' . $item_id . ' â€” job not completed, check-job will handle.' );
			}
		}
			
// â”€â”€ Handle queued items: stale schedule or missing AS action â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
		// Queued items whose scheduled_at has passed, heartbeat is stale, or that
		// have been waiting too long with no timestamps at all need forced recovery.
		// This is the SSOT path â€” the heartbeat no longer competes here.
		// FIX (2026-08-27): The previous logic skipped items where AS action existed
		// but was not yet "stale" (age < 30 min). Since the AS runner never picks up
		// these actions, items stayed stuck in 'queued' forever. Now we process ALL
		// queued items whose scheduled time has passed (guaranteed by the SQL query)
		// directly via process_item_background(), regardless of AS action status.
		if ( ! empty( $queued_items ) ) {
			foreach ( (array) $queued_items as $qrow ) {
				$qid = (int) $qrow->id;

				if ( $processor instanceof \SEO_Article_Generator\Discovery\Discovery_Processor ) {
					try {
						$processor->process_item_background( $qid );
						$recovered++;
						$this->logger->info(
							sprintf(
								'[Overdue Recovery] Queued item %d: direct process_item_background() triggered (scheduled_at=%s).',
								$qid,
								isset( $qrow->scheduled_at ) ? $qrow->scheduled_at : 'NULL'
							)
						);
					} catch ( \Throwable $e_q ) {
						$this->logger->error(
							sprintf(
								'[Overdue Recovery] Queued item %d direct processing failed: %s',
								$qid,
								$e_q->getMessage()
							)
						);

						// FIX C (2026-09-06): Don't leave the row in 'queued' — it will
						// re-enter the Overdue Recovery loop on the next tick, causing
						// infinite re-processing. Mark as failed so it stops the cycle.
						// FIX C2 (2026-09-06): route through the failure SSOT instead of
						// a raw write (Fix C skipped AS-cancel, last_job_id, draft
						// re-schedule, cache invalidate and transient clear). Raw write
						// kept only as a last resort when the processor is unavailable.
						if ( $processor instanceof \SEO_Article_Generator\Discovery\Discovery_Processor ) {
							$processor->fail_item_from_recovery( $qid, 'Overdue Recovery process_item_background failed: ' . $e_q->getMessage() );
						} else {
							global $wpdb;
							$wpdb->update(
								Installer::table_discovery(),
								array(
									'status'        => 'failed',
									'error_message' => 'Overdue Recovery process_item_background failed: ' . $e_q->getMessage(),
									'poll_count'    => 0,
								),
								array( 'id' => $qid )
							);
						}
					}
				}
			}
		}

			// HEARTBEAT ENHANCEMENT: also re-arm pipeline items whose per-item
			// HOOK_PROCESS_ITEM was lost. The block above only catches items
			// already in 'generating'/'finalizing'/'processing'/'deferred';
			// 'queued' items with a missing process action would sit idle
			// forever. Reusing the heartbeat recovery method keeps the
			// duplicate-watchdog authority problem off the table.
			$rearmed_lost = $this->recover_lost_process_actions();
			if ( $rearmed_lost > 0 ) {
				$recovered += $rearmed_lost;
			}

			if ($recovered > 0) {
				$this->logger->info('[Overdue Recovery] Recovered ' . $recovered . ' overdue posts.');
			}
		} catch (\Throwable $e) {
			$this->logger->error('[Overdue Recovery] Error: ' . $e->getMessage());
		}
	}

	/**
	 * External Heartbeat Cron Endpoint.
	 *
	 * PROBLEM: Action Scheduler's queue runner depends on WP-Cron. When
	 * DISABLE_WP_CRON=true (or WP-Cron is silently broken), AS recurring
	 * actions never fire and the plugin starves. The Meta-Watchdog
	 * (ensure_recurring_watchdog) only fires on page loads, so during idle
	 * periods items sit in 'queued'/'generating' indefinitely.
	 *
	 * SOLUTION: Mirrors WP Automatic's ?wp_automatic=cron external-cron
	 * pattern. The site admin installs ONE system cron job on the VPS
	 * (or cron.org / easycron.com) that pings this endpoint every minute:
	 *
	 *   curl -s "https://www.softwareswave.com/?seo_gen_heartbeat=1&secret=<SECRET>"
	 *
	 * On each ping, this method:
	 *   1) Validates an optional shared-secret token (auto-generated).
	 *   2) Clears transient caches that hide overdue state from the watchdogs.
	 *   3) Triggers Action Scheduler's internal runner directly so any
	 *      pending single/recurring actions that were waiting on WP-Cron are
	 *      dispatched here, not starved.
	 *   4) Runs all four watchdogs sequentially (queue worker, sync finalizer,
	 *      publish watchdog, overdue recovery). Each has its own atomic MySQL
	 *      lock, so they never overlap with each other or with page-load runs.
	 *   5) Recovers items whose per-item HOOK_PROCESS_ITEM AS action was lost
	 *      (the source of pipeline items stuck forever in 'processing').
	 *
	 * Idempotent: each handler acquires its own lock and the locks auto-expire
	 * (60s option lock / MySQL GET_LOCK session-bound). Safe to hit every 60s
	 * from crontab.
	 *
	 * Registration: ?seo_gen_heartbeat=1&secret=<SECRET> â€” validated on
	 * `init` so it fires before WP-Cron / AS runner init and before any page
	 * template loads. Returns a minimal text/plain status, then exit()s.
	 *
	 * @since 2.30.x (Heartbeat Enhancement)
	 */
	public function handle_external_heartbeat(): void {
		// Query-var gate: only fire on the dedicated heartbeat var.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( empty( $_GET['seo_gen_heartbeat'] ) ) {
			return;
		}

		// Abort on AJAX / XML-RPC / REST contexts â€” only run on real cron.
		if ( ( defined( 'DOING_AJAX' ) && DOING_AJAX )
			|| ( defined( 'DOING_CRON' ) && DOING_CRON )
			|| ( defined( 'REST_REQUEST' ) && REST_REQUEST )
			|| ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST )
		) {
			return;
		}

		// â”€â”€ Secret validation â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
		// Without a secret anyone could force the watchdogs to fire and burn
		// API quota. Lazily generate + persist a 32-char token on first use
		// so admin only needs to read it once from the plugin option.
		$secret = (string) \get_option( \SEO_Article_Generator\Option_Registry::EXTERNAL_CRON_SECRET, '' );
		if ( '' === $secret ) {
			$secret = \wp_generate_password( 32, false );
			\update_option( \SEO_Article_Generator\Option_Registry::EXTERNAL_CRON_SECRET, $secret, false );
		}

		$provided = isset( $_GET['secret'] ) ? (string) $_GET['secret'] : '';
		if ( '' !== $secret && ! \hash_equals( $secret, $provided ) ) {
			\status_header( 403 );
			\nocache_headers();
			\header( 'Content-Type: text/plain; charset=utf-8' );
			echo 'heartbeat: forbidden';
			exit;
		}

		// â”€â”€ Run the heartbeat under a global MySQL lock to prevent two
		// overlapping cron pings (e.g. from VPS cron + cron.org) from
		// running simultaneously and racing on the same discovery row.
		global $wpdb;
		$heartbeat_lock = 'seogen_heartbeat_' . (int) \get_current_blog_id();
		if ( 1 !== (int) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 5)', $heartbeat_lock ) ) ) {
			\status_header( 429 );
			\nocache_headers();
			\header( 'Content-Type: text/plain; charset=utf-8' );
			echo 'heartbeat: already-running';
			exit;
		}

		// Mark request as a heartbeat (prevents schedule_discovery_jobs from
		// running its own watchdogs on this request â€” overlapping would waste
		// locks and produce duplicate OVERDUE logs).
		$this->heartbeat_active = true;

		// Force bypass of browser/origin caches. Operator must additionally
		// add the bypass URL `*/?seo_gen_heartbeat=*` in WP Cloudflare Super
		// Page Cache â†’ Excluded URLs (and/or a Cloudflare Page Rule for the
		// same pattern). The plugin here only emits standard no-cache
		// headers; we do NOT tamper with the cache plugin's runtime flags.
		\nocache_headers();
		\header( 'Content-Type: text/plain; charset=utf-8' );

		$started = microtime( true );
		$report  = array();

		// â”€â”€ Phase 1: clear transient caches ONLY for genuinely overdue actions â”€â”€
		// get_next_run() caches results in 15s transients. Clearing unconditionally
		// causes Case B churn (next=0, interval>0) in ensure_recurring_watchdog().
		// Only clear when an action is truly overdue beyond interval+grace.
		// The cache-key here MUST match the key AS_Registry::get_next_run()
		// reads/writes. That key is built as:
		//   md5( $hook . serialize( $args ) . ( $overdue_as_now ? '1' : '0' ) )
		// The pending actions for these hooks are scheduled with args=[] and
		// get_next_run is always called with overdue_as_now=false â†’ suffix '0'.
		// serialize([]) returns 'a:0:{}' (verified). Real key suffix is therefore
		// 'a:0:{}0' (no separator). The previous code used literal 'a:0:{};0'
		// â€” including a semicolon that doesn't exist in the real key â€” producing
		// a phantom transient name that nothing ever writes. That made this
		// Phase 1 a no-op: the heartbeat reported each watchdog phase as "ran"
		// while the stale-cache invalidation it claimed to do never happened.
		$hooks_to_check = array(
			'seo_gen_queue_worker',
			'seo_gen_sync_finalizer',
			'seo_gen_publish_watchdog',
			'seo_gen_overdue_recovery',
		);
		$now          = Plugin_Time::now_utc_ts();
		$caches_cleared = 0;
		foreach ( $hooks_to_check as $hook ) {
			$next     = AS_Registry::get_next_run_uncached( $hook );
			$interval = AS_Registry::get_recurring_interval( $hook );
			if ( $next > 0 && $interval > 0 ) {
				$grace = max( 60, (int) ( $interval * 0.5 ) );
				if ( $next < $now - ( $interval + $grace ) ) {
					// Build the SAME key AS_Registry::get_next_run uses to populate
					// the transient. Without this, the watchdog's get_next_run()
					// keeps returning the overdue (past) timestamp instead of 0,
					// so the meta-watchdog's OVERDUE branch never detects that the
					// action needs recreating and the meta-watchdog quietly no-ops.
					$cache_key = 'as_nxt_' . md5( $hook . serialize( array() ) . '0' );
					\delete_transient( $cache_key );
					++$caches_cleared;
				}
			}
		}
		// Report the actual cache-clear outcome so Phase 1 is honest in the audit
		// log instead of always saying "ran" regardless of whether anything was
		// cleared. 0 means "nothing was overdue" â€” a legitimate state, not a
		// hidden failure of a no-op cache key construction.
		$report['phase1_cache_cleared'] = $caches_cleared;

		// â”€â”€ Phase 2: trigger Action Scheduler's internal runner directly â”€
		// This drains any pending AS single/recurring actions that were
		// scheduled but never fired (because WP-Cron is offline). Instead of
		// waiting for the AS runner to be triggered by WP-Cron, we invoke it
		// synchronously here. The runner processes a limited batch per call
		// (default 25s) to avoid PHP timeout. Safe to call every 60s.
		try {
			if ( \class_exists( '\ActionScheduler' ) && \method_exists( '\ActionScheduler', 'runner' ) ) {
				$runner = \ActionScheduler::runner();
				if ( \is_object( $runner ) && \method_exists( $runner, 'run' ) ) {
					// ActionScheduler_QueueRunner::run( $context ) takes a label
					// string used only in log entries (default 'WP Cron'). It is
					// NOT a class name to instantiate. The previous call passed
					// 'ActionScheduler_QueueRunner' which just mislabelled every
					// AS log line. Use a descriptive heartbeat label so the audit
					// trail in wc_action_scheduler_logs is traceable back to this
					// endpoint. run() returns the number of actions processed â€”
					// surface that count in the report so the operator can see
					// whether Phase 2 actually drained work each tick instead of
					// seeing the always-'ran' placeholder.
					$processed = $runner->run( 'SEO-Gen Heartbeat' );
					$report['as_runner'] = (int) $processed;
				} else {
					$report['as_runner'] = 'runner-unavailable';
				}
			} else {
				$report['as_runner'] = 'as-not-initialized';
			}
		} catch ( \Throwable $e ) {
			$report['as_runner'] = 'error: ' . $e->getMessage();
			if ( $this->logger ) {
				$this->logger->error( '[Heartbeat] AS runner error: ' . $e->getMessage() );
			}
		}

		// â”€â”€ Phase 3: run all four watchdogs sequentially â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
		// Each handler acquires its own atomic lock (option lock or MySQL
		// GET_LOCK), so overlap with concurrent page-load invocations or
		// another heartbeat ping is a no-op (lock returns false, handler
		// returns early). We call them in dependency order so the work
		// produced by one watchdog is immediately consumed by the next.
		//
		// SUPPORTED ?action= SUBSETS (so a single cron URL can be filtered
		// to a specific phase on hardware-constrained hosts; default = all):
		//   worker         -> run_queue_worker only
		//   finalizer      -> run_sync_finalizer only
		//   publish        -> run_publish_watchdog only
		//   recovery       -> run_overdue_recovery only
		//   wpautopoll     -> run_wp_auto_draft_poll only (15-min WPA integration)
		//   autogen        -> run_auto_generation (needs processor, gated internally)
		//   (default/none) -> all of the above in dependency order
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$action_filter = isset( $_GET['action'] ) ? (string) $_GET['action'] : '';
		$valid_actions = array( 'worker', 'finalizer', 'publish', 'recovery', 'wpautopoll', 'autogen' );
		$run_all       = '' === $action_filter || ! in_array( $action_filter, $valid_actions, true );

		if ( $run_all || 'worker' === $action_filter ) {
			try {
				$worker_result = $this->run_queue_worker();
				$report['queue_worker'] = $worker_result;
			} catch ( \Throwable $e ) {
				$report['queue_worker'] = 'error: ' . $e->getMessage();
			}
		}

		// â”€â”€ Daily Cleanup (independent of AS) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
		// run_daily_cleanup() is registered on the dead HOOK_DAILY_CLEANUP AS
		// action. Run it via heartbeat so draft cleanup, retention jobs, and
		// orphan cleanup execute regardless of AS state. Throttled to once per
		// DAY_IN_SECONDS via transient.
		if ( $run_all || 'worker' === $action_filter ) {
			$dc_key = 'seo_gen_heartbeat_daily_cleanup_last';
			$dc_last = (int) \get_transient( $dc_key );
			$dc_now  = \SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts();
			if ( $dc_last === false || ( $dc_now - $dc_last ) > \DAY_IN_SECONDS ) {
				try {
					$plugin = \SEO_Article_Generator\Plugin::get_instance();
					if ( $plugin && \method_exists( $plugin, 'run_daily_cleanup' ) ) {
						$plugin->run_daily_cleanup();
						\set_transient( $dc_key, $dc_now, \DAY_IN_SECONDS );
						$report['daily_cleanup'] = 'ran';
					} else {
						$report['daily_cleanup'] = 'plugin-unavailable';
					}
				} catch ( \Throwable $e ) {
					$report['daily_cleanup'] = 'error: ' . $e->getMessage();
				}
			} else {
				$report['daily_cleanup'] = 'throttled';
			}
		}

		if ( $run_all || 'finalizer' === $action_filter ) {
			try {
				$this->run_sync_finalizer();
				$report['sync_finalizer'] = 'ran';
			} catch ( \Throwable $e ) {
				$report['sync_finalizer'] = 'error: ' . $e->getMessage();
			}
		}

		if ( $run_all || 'publish' === $action_filter ) {
			try {
				$this->run_publish_watchdog();
				$report['publish_watchdog'] = 'ran';
			} catch ( \Throwable $e ) {
				$report['publish_watchdog'] = 'error: ' . $e->getMessage();
			}
		}

		if ( $run_all || 'recovery' === $action_filter ) {
			try {
				$this->run_overdue_recovery();
				$report['overdue_recovery'] = 'ran';
			} catch ( \Throwable $e ) {
				$report['overdue_recovery'] = 'error: ' . $e->getMessage();
			}
		}

		// â”€â”€ WP Auto Draft Poll (900s) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
		// The recurring AS action seo_gen_wp_auto_draft_poll depends on the
		// AS runner. If WP-Cron is off and the operator has a configured
		// WPA category, the poll never fires â€” drafts pile up unprocessed.
		// Heartbeat fires it directly when the WPA integration is enabled.
		if ( $run_all || 'wpautopoll' === $action_filter ) {
			try {
				$wp_auto_cat = (int) \get_option( 'seo_gen_wp_auto_category_id', 0 );
				if ( $wp_auto_cat > 0 ) {
					$engine = $this->get_engine();
					if ( $engine && \method_exists( $engine, 'run_wp_auto_draft_poll' ) ) {
						$engine->run_wp_auto_draft_poll();
						$report['wp_auto_poll'] = 'ran';
					} else {
						$report['wp_auto_poll'] = 'engine-unavailable';
					}
				} else {
					$report['wp_auto_poll'] = 'disabled';
				}
			} catch ( \Throwable $e ) {
				$report['wp_auto_poll'] = 'error: ' . $e->getMessage();
			}
		}

		// â”€â”€ Auto Generation Cron (configurable interval) â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
		// Triggers batch article generation from the auto-gen queue. Gated
		// internally by the processor (pipeline paused, daily quota, etc.).
		// We only fire it if ENABLE_AUTO_GENERATION is on â€” no API quota
		// burn when the operator has it disabled.
		if ( $run_all || 'autogen' === $action_filter ) {
			try {
				$auto_gen_enabled = (int) \get_option(
					\SEO_Article_Generator\Option_Registry::ENABLE_AUTO_GENERATION,
					\SEO_Article_Generator\Option_Registry::defaults()[ \SEO_Article_Generator\Option_Registry::ENABLE_AUTO_GENERATION ]
				);
				if ( $auto_gen_enabled === 1 && $this->processor ) {
					$report['auto_gen'] = $this->processor->run_auto_generation();
				} else {
					$report['auto_gen'] = 'disabled';
				}
			} catch ( \Throwable $e ) {
				$report['auto_gen'] = 'error: ' . $e->getMessage();
			}
		}

		// ── Phase 4: per-item stale-action recovery (lost HOOK_PROCESS_ITEM) ────
		// Items stuck in 'processing' with NO pending process action never advance.
		// 'queued' items are now handled by run_overdue_recovery() (SSOT).
		// This phase re-arms lost AS actions for processing items whose
		// HOOK_PROCESS_ITEM was lost (purge, table repair, migration).
		if ( $run_all || 'recovery' === $action_filter ) {
			try {
				$stale_rearmed = $this->recover_lost_process_actions();
				$report['lost_process_rearmed'] = $stale_rearmed;
			} catch ( \Throwable $e ) {
				$report['lost_process_rearmed'] = 'error: ' . $e->getMessage();
			}
		}

		// â”€â”€ Phase 5: pending item aging recovery â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
		// Items stuck in 'pending' beyond the aging threshold are silently blocked
		// by run_auto_generation() exit paths (quota, gate, lock). Without this,
		// the draft retention timer deletes the source draft before content is
		// generated â€” silent data loss. This phase detects aged pending items,
		// cancels their scheduled draft deletion to buy time, and logs the blockage.
		if ( $run_all || 'recovery' === $action_filter ) {
			try {
				$aged_recovered = $this->recover_aged_pending_items();
				$report['aged_pending_recovered'] = $aged_recovered;
			} catch ( \Throwable $e ) {
				$report['aged_pending_recovered'] = 'error: ' . $e->getMessage();
			}
		}

		// â”€â”€ Phase 5c: pipeline reconciliation â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
		// Detects discovery items stuck in 'queued'/'generating' where the
		// corresponding queue job + ticket are both 'completed'. This closes
		// the gap left by lost HOOK_CHECK_JOB actions or finalization failures.
		if ( $run_all || 'recovery' === $action_filter ) {
			try {
				$reconciled = $this->reconcile_completed_pipeline_items();
				$report['pipeline_reconciled'] = $reconciled;
			} catch ( \Throwable $e ) {
				$report['pipeline_reconciled'] = 'error: ' . $e->getMessage();
			}
		}

		// Release the global heartbeat lock so the next cron ping can run.
		$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $heartbeat_lock ) );

		$elapsed_ms = (int) ( ( microtime( true ) - $started ) * 1000 );

		// Always log the heartbeat at INFO level so the operator has a
		// deterministic audit trail that cron fired (independent of page-load).
		if ( $this->logger ) {
			$this->logger->info(
				sprintf(
					'[Heartbeat] external cron fired. elapsed=%dms report=%s',
					$elapsed_ms,
					\wp_json_encode( $report )
				)
			);
		}

		// Persist last-fire metadata so the admin UI can render "Last fired:
		// 35s ago â€” Status: OK" without needing to parse the log file. Both
		// are written with autoload=false (rare reads, never on the hot path).
		\update_option( \SEO_Article_Generator\Option_Registry::EXTERNAL_CRON_LAST_FIRE, Plugin_Time::now_utc_ts(), false );
		\update_option( \SEO_Article_Generator\Option_Registry::EXTERNAL_CRON_LAST_REPORT, \wp_json_encode( $report ), false );

		// Minimal plain-text response (the operator only needs a 200 + a sanity
		// line to confirm cron is live). 200 OK is enough for wrap-up.
		echo 'heartbeat: ok in ' . $elapsed_ms . 'ms â€” ' . \wp_json_encode( $report );
		exit;
	}

/**
	 * Recover pipeline items whose HOOK_PROCESS_ITEM AS action was lost.
	 *
	 * The Meta-Watchdog + ensure_recurring_action only verifies the recurring
	 * worker/finalizer actions exist; they do NOT verify per-item process
	 * actions. When an item's scheduled HOOK_PROCESS_ITEM is lost (DB repair,
	 * purge_all_seo_gen_actions, AS table migration), the item stays in
	 * 'processing' forever — the queue worker never picks it up
	 * because no process_item_background() is scheduled.
	 *
	 * This method is called from the external heartbeat cron and from
	 * run_overdue_recovery(). It is idempotent: only re-arms items with NO
	 * pending process action, and uses the existing schedule_process_item
	 * API (which itself unschedules before scheduling).
	 *
	 * @return int Number of items re-armed.
	 */
	private function recover_lost_process_actions(): int {
		global $wpdb;
		$table = Installer::table_discovery();
		$uid   = \get_current_user_id() ? (int) \get_current_user_id() : 1;

		// Find items in 'processing' whose HOOK_PROCESS_ITEM was lost
		// (AS purge, table repair, runner never fired) and need re-arming.
		//
		// STALENESS SIGNAL: heartbeat_at is set by process_item_background() at
		//                   claim time. A stale heartbeat means the process died.
		$window_min = (int) \get_option(
			\SEO_Article_Generator\Option_Registry::OVERDUE_RECOVERY_WINDOW_MIN,
			\SEO_Article_Generator\Option_Registry::defaults()[ \SEO_Article_Generator\Option_Registry::OVERDUE_RECOVERY_WINDOW_MIN ]
		);
		$window_min     = max( 1, $window_min );
		$stale_cutoff   = gmdate( 'Y-m-d H:i:s', strtotime( '-' . $window_min . ' minutes' ) );

		$candidates = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, scheduled_at FROM {$table}
				 WHERE status = 'processing'
				   AND (heartbeat_at IS NULL OR heartbeat_at <= %s)
				 ORDER BY id ASC
				 LIMIT 50",
				$stale_cutoff
			)
		);

		if ( empty( $candidates ) ) {
			return 0;
		}

		// Threshold: if a pending AS action's scheduled_at is older than this,
		// the runner is not executing it â€” treat as orphaned and re-arm.
		$as_stale_threshold_sec = $window_min * 60;

		$rearmed = 0;
		foreach ( (array) $candidates as $row ) {
			$item_id = (int) $row->id;

			// Probe AS: is there a pending HOOK_PROCESS_ITEM for this item?
			$has_pending = \SEO_Article_Generator\Queue\AS_Registry::has_scheduled_action(
				\SEO_Article_Generator\Queue\AS_Registry::HOOK_PROCESS_ITEM,
				array( $item_id, $uid ),
				\SEO_Article_Generator\Queue\AS_Registry::GROUP
			);

			if ( $has_pending ) {
				// FIX: Action exists but may be overdue (runner never fires it).
				// Query AS store for the action's actual scheduled time (not discovery's scheduled_at).
				$as_next_run = \SEO_Article_Generator\Queue\AS_Registry::get_next_run_uncached(
					\SEO_Article_Generator\Queue\AS_Registry::HOOK_PROCESS_ITEM,
					array( $item_id, $uid ),
					false
				);

				if ( $as_next_run > 0 ) {
					$age_sec = time() - $as_next_run;
					if ( $age_sec > $as_stale_threshold_sec ) {
						// Action is stale â€” unschedule the orphan and re-arm.
						\SEO_Article_Generator\Queue\AS_Registry::unschedule_all(
							\SEO_Article_Generator\Queue\AS_Registry::HOOK_PROCESS_ITEM,
							array( $item_id, $uid )
						);
						\SEO_Article_Generator\Queue\AS_Registry::schedule_process_item( $item_id, $uid, 5 );
						++$rearmed;

						if ( $this->logger ) {
							$this->logger->info(
								sprintf(
									'[Heartbeat] Re-armed overdue HOOK_PROCESS_ITEM for discovery %d (AS action was %ds old, threshold=%ds).',
									$item_id,
									$age_sec,
									$as_stale_threshold_sec
								)
							);
						}
						continue;
					}
				}
				// Action is pending and not stale â€” skip.
				continue;
			}

			// Re-arm via the established API â€” it unschedules any stale
			// process action first (idempotent), then schedules a fresh one.
			\SEO_Article_Generator\Queue\AS_Registry::schedule_process_item( $item_id, $uid, 5 );
			++$rearmed;

			if ( $this->logger ) {
				$this->logger->info(
					sprintf(
						'[Heartbeat] Re-armed lost HOOK_PROCESS_ITEM for discovery %d (processing item with no pending AS action).',
						$item_id
					)
				);
			}
		}

		return $rearmed;
	}

	/**
	 * Recover pipeline items stuck in 'pending' beyond the aging threshold.
	 *
	 * The ONLY code path that advances 'pending' â†’ 'queued' is
	 * run_auto_generation(), which silently returns early when:
	 *   - Pipeline is paused
	 *   - Auto-generation is disabled
	 *   - Autogen lock is busy
	 *   - Daily API quota is exhausted
	 *   - Generation gate is blocked
	 *
	 * In all these cases the heartbeat report says "auto_gen":"ran" but
	 * no pending items are actually approved. Without this recovery phase,
	 * the draft retention timer (schedule_draft_deletion at staging time)
	 * deletes the source draft while the discovery is still 'pending' â€”
	 * a silent data loss.
	 *
	 * This method:
	 *   1. Finds pending items older than PENDING_AGING_THRESHOLD_MIN (default 120min)
	 *   2. If the source draft still exists, cancels the scheduled deletion
	 *   3. Logs the blockage at WARNING level for operator visibility
	 *   4. If auto-gen is currently unblocked, re-approves the item
	 *   5. If the draft was already deleted, marks the discovery as failed
	 *
	 * @return int Number of aged pending items processed.
	 */
	private function recover_aged_pending_items(): int {
		global $wpdb;
		$table = Installer::table_discovery();
		$uid   = \get_current_user_id() ? (int) \get_current_user_id() : 1;

		$threshold_min = (int) \get_option(
			\SEO_Article_Generator\Option_Registry::PENDING_AGING_THRESHOLD_MIN,
			\SEO_Article_Generator\Option_Registry::defaults()[ \SEO_Article_Generator\Option_Registry::PENDING_AGING_THRESHOLD_MIN ]
		);
		$threshold_min = max( 30, $threshold_min );
		$aging_cutoff  = gmdate( 'Y-m-d H:i:s', strtotime( '-' . $threshold_min . ' minutes' ) );

		$candidates = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, software_name, draft_post_id, source_type, discovered_at
				FROM {$table}
				WHERE status = 'pending' AND discovered_at <= %s
				ORDER BY discovered_at ASC
				LIMIT 50",
				$aging_cutoff
			)
		);

		if ( empty( $candidates ) ) {
			return 0;
		}

		$recovered = 0;

		foreach ( (array) $candidates as $row ) {
			$item_id       = (int) $row->id;
			$draft_post_id = (int) ( $row->draft_post_id ?? 0 );
			$source_type   = (string) ( $row->source_type ?? '' );
			$software      = (string) ( $row->software_name ?? 'Unknown' );
			$discovered_at = (string) ( $row->discovered_at ?? '' );

			// Calculate age in hours for logging.
			$age_hours = 0;
			if ( $discovered_at !== '' ) {
				$discovered_ts = strtotime( $discovered_at . ' UTC' );
				if ( $discovered_ts !== false ) {
					$age_hours = (int) round( ( time() - $discovered_ts ) / HOUR_IN_SECONDS );
				}
			}

			// â”€â”€ Check 1: Does the source draft still exist? â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
			$draft_exists = $draft_post_id > 0 && \get_post( $draft_post_id );

			if ( ! $draft_exists && $draft_post_id > 0 ) {
				// Draft was already deleted by the retention timer.
				// Mark the discovery as failed â€” orphaned, cannot generate.
				$wpdb->update(
					$table,
					array(
						'status'        => 'failed',
						'error_message' => sprintf(
							'Source draft %d deleted before generation. Orphaned by retention timer after %dh in pending.',
							$draft_post_id,
							$age_hours
						),
						'completed_at'  => \SEO_Article_Generator\Utils\Plugin_Time::utc_mysql_now(),
						'scheduled_at'  => null,
						'heartbeat_at'  => null,
					),
					array( 'id' => $item_id ),
					array( '%s', '%s', '%s', '%s', '%s' ),
					array( '%d' )
				);

				if ( $this->logger ) {
					$this->logger->warning(
						sprintf(
							'[Aging Recovery] Discovery %d orphaned: draft %d already deleted after %dh in pending. Marking failed. Software: %s',
							$item_id,
							$draft_post_id,
							$age_hours,
							$software
						)
					);
				}
				++$recovered;
				continue;
			}

			// â”€â”€ Check 2: Draft exists â€” cancel the scheduled deletion â”€â”€â”€â”€â”€
			// The retention timer would kill the draft while we're still pending.
			if ( $draft_exists && $source_type === 'wp_automatic' ) {
				\SEO_Article_Generator\Queue\AS_Registry::unschedule_all(
					\SEO_Article_Generator\Queue\AS_Registry::HOOK_DELETE_DRAFT,
					array( $draft_post_id )
				);

				if ( $this->logger ) {
					$this->logger->warning(
						sprintf(
							'[Aging Recovery] Discovery %d stuck in pending for %dh. Draft %d deletion cancelled to prevent data loss. Software: %s',
							$item_id,
							$age_hours,
							$draft_post_id,
							$software
						)
					);
				}
			}

			// â”€â”€ Check 3: Can we re-approve now? â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
			// Only attempt if auto-gen is enabled and not paused.
			$auto_gen_enabled = (int) \get_option(
				\SEO_Article_Generator\Option_Registry::ENABLE_AUTO_GENERATION,
				\SEO_Article_Generator\Option_Registry::defaults()[ \SEO_Article_Generator\Option_Registry::ENABLE_AUTO_GENERATION ]
			);

			if ( $auto_gen_enabled === 1 && ! $this->is_discovery_paused() ) {
				// Try to approve â€” this will succeed if the gate/quota is now clear.
				if ( $this->processor && method_exists( $this->processor, 'approve_item' ) ) {
					$this->processor->approve_item( $item_id, $uid, 5 );
					if ( $this->logger ) {
						$this->logger->info(
							sprintf(
								'[Aging Recovery] Discovery %d re-approved after %dh in pending. Software: %s',
								$item_id,
								$age_hours,
								$software
							)
						);
					}
				}
			}

			++$recovered;
		}

		return $recovered;
	}

	/**
	 * Check whether current server local time falls within the configured
	 * publish window (default 15:00â€“23:00 local).
	 */
	private function is_within_publish_window(): bool {
		$window_start = (int) \get_option(
			\SEO_Article_Generator\Option_Registry::PUBLISH_WINDOW_START,
			15
		);
		$window_end = (int) \get_option(
			\SEO_Article_Generator\Option_Registry::PUBLISH_WINDOW_END,
			23
		);

		$server_offset = (int) \get_option( 'gmt_offset', 0 );
		$local_hour    = (int) \date( 'G', \time() + $server_offset * \HOUR_IN_SECONDS );

		return $local_hour >= $window_start && $local_hour < $window_end;
	}

	/**
	 * Seconds from now until the next publish window opening.
	 * Always returns at least 60 to avoid zero-delay scheduling.
	 */
	private function get_seconds_until_next_window(): int {
		$window_start = (int) \get_option(
			\SEO_Article_Generator\Option_Registry::PUBLISH_WINDOW_START,
			15
		);

		$server_offset = (int) \get_option( 'gmt_offset', 0 );
		$local_ts      = \time() + $server_offset * \HOUR_IN_SECONDS;
		$local_hour    = (int) \date( 'G', $local_ts );

		$now_local_midnight = $local_ts
			- ( $local_hour * \HOUR_IN_SECONDS + (int) \date( 'i', $local_ts ) * \MINUTE_IN_SECONDS );

		if ( $local_hour >= $window_start ) {
			$next_window_ts = $now_local_midnight + 24 * \HOUR_IN_SECONDS + $window_start * \HOUR_IN_SECONDS;
		} else {
			$next_window_ts = $now_local_midnight + $window_start * \HOUR_IN_SECONDS;
		}

		$next_window_utc = $next_window_ts - $server_offset * \HOUR_IN_SECONDS;
		$now_utc         = \time();

		return max( 60, (int) ( $next_window_utc - $now_utc ) );
	}

	/**
	 * Reconcile pipeline items where job+queue completed but discovery is stuck.
	 *
	 * When a job completes and the queue ticket is completed, but the discovery
	 * item remains in 'queued' or 'generating' (e.g., HOOK_CHECK_JOB was lost,
	 * or finalization failed), this method detects the inconsistency and advances
	 * the discovery item to finalization or completion.
	 *
	 * @return int Number of items reconciled.
	 */
	private function reconcile_completed_pipeline_items(): int {
		global $wpdb;
		$table     = Installer::table_discovery();
		$jobs_tbl  = \SEO_Article_Generator\Installer::table_jobs();
		$queue_tbl = \SEO_Article_Generator\Installer::table_queue();

		// Find discovery items stuck in pipeline where the queue job is completed.
		// Chain: discovery.job_id â†’ jobs.id â† queue.reference_id
		$candidates = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT d.id, d.status AS disc_status, q.status AS queue_status, q.completed_at
				FROM {$table} d
				INNER JOIN {$jobs_tbl} j ON j.id = d.job_id
				INNER JOIN {$queue_tbl} q ON q.reference_id = j.id
				WHERE d.status IN ('queued', 'generating')
				  AND q.status = %s
				  AND q.completed_at IS NOT NULL
				ORDER BY q.completed_at ASC
				LIMIT 20",
				\SEO_Article_Generator\Queue\Job_Repository::STATUS_COMPLETED
			)
		);

		if ( empty( $candidates ) ) {
			return 0;
		}

		$reconciled = 0;

		foreach ( (array) $candidates as $row ) {
			$item_id = (int) $row->id;

			// Use the processor to advance the item â€” same path as the manual
			// "Run Queue Now" button which handles all state transitions.
			// FIX: Automated reconciliation must respect the publish window.
			// run_item_now uses force=true which bypasses the window gate, so
			// we check here and defer outside-window items instead.
			if ( $this->processor && method_exists( $this->processor, 'run_item_now' ) ) {
				$_is_update = false;
				$_item_for_check = $this->processor->get_item( $item_id );
				if ( $_item_for_check && ! empty( $_item_for_check->existing_post_id ) ) {
					$_is_update = true;
				}

				if ( $_is_update && ! $this->is_within_publish_window() ) {
					$_job_id_for_check = (int) ( $_item_for_check->job_id ?? 0 );
					if ( $_job_id_for_check > 0 ) {
						$_resume_delay = $this->get_seconds_until_next_window();
						\SEO_Article_Generator\Queue\AS_Registry::schedule_check_job(
							$item_id,
							$_job_id_for_check,
							1,
							1,
							$_resume_delay
						);
					}
					$this->logger->info( sprintf(
						'[Pipeline Reconciliation] Discovery %d: outside publish window. Deferred %ds to next window.',
						$item_id,
						$this->get_seconds_until_next_window()
					) );
				} else {
					$this->processor->run_item_now( $item_id );
				}
				++$reconciled;

				if ( $this->logger ) {
					$this->logger->info(
						sprintf(
							'[Pipeline Reconciliation] Discovery %d reconciled: job+queue completed but discovery stuck in %s.',
							$item_id,
							$row->disc_status
						)
					);
				}
			}
		}

		return $reconciled;
	}

	/**
	 * HOOK: seo_gen_publish_watchdog
	 *
	 * Force-publishes plugin-owned posts whose post_date_gmt is in the past
	 * but whose post_status is still 'future' (WP-Cron missed them or is
	 * disabled on the host). Runs every PUBLISH_WATCHDOG_INTERVAL seconds
	 * (default 120s) via Action Scheduler. SSOT for ownership is
	 * Post_Type_Classifier::is_plugin_owned() â€” the watchdog is a no-op for
	 * posts that are not ours.
	 *
	 * @since 2.29.0
	 */
	/**
	 * Scheduled callback: sync free OpenRouter models into the OpenRouter
	 * custom provider. Respects the discovery pause gate and logs failures.
	 *
	 * @MODIFIED 2026-07-12 - OpenRouter free model auto-sync
	 */
	public function sync_openrouter_models(): void {
		// Pipeline pause gate â€” skip cron sync when discovery is paused,
		// but still allow the manual (AJAX) sync to run.
		if ( $this->is_discovery_paused() ) {
			return;
		}

		$result = \SEO_Article_Generator\AI\OpenRouter_Model_Sync::sync();

		if ( ! $result['success'] && $result['message'] !== 'No OpenRouter custom provider found.' ) {
			if ( $this->logger ) {
				$this->logger->warning(
					'[OpenRouter Sync] ' . $result['message'],
					array(
						'action'  => \SEO_Article_Generator\Option_Registry::LOG_ACTION_OPENROUTER_SYNC,
						'result'  => $result,
						'source' => 'cron',
					)
				);
			}
		}
	}

	/**
	 * Scheduled callback: sync free OpenCode Zen models into the OpenCode Zen
	 * custom provider. Sibling of sync_openrouter_models() â€” full-replace
	 * strategy via OpenCode_Zen_Model_Sync::sync(). Respects the discovery
	 * pause gate and logs failures.
	 */
	public function sync_zen_models(): void {
		// Pipeline pause gate â€” skip cron sync when discovery is paused,
		// but still allow the manual (AJAX) sync to run.
		if ( $this->is_discovery_paused() ) {
			return;
		}

		$result = \SEO_Article_Generator\AI\OpenCode_Zen_Model_Sync::sync();

		if ( ! $result['success'] && $result['message'] !== 'No OpenCode Zen custom provider found (URL must contain opencode.ai).' ) {
			if ( $this->logger ) {
				$this->logger->warning(
					'[OpenCode Zen Sync] ' . $result['message'],
					array(
						'action'  => \SEO_Article_Generator\Option_Registry::LOG_ACTION_ZEN_SYNC,
						'result'  => $result,
						'source' => 'cron',
					)
				);
			}
		}
	}

	public function run_publish_watchdog(): void {
		global $wpdb;

		// FIX TIMEOUT PROTECTION: raise PHP time limit so the handler cannot be
		// killed mid-run and marked STATUS_FAILED by AS.
		$php_tl_pw = (int) ini_get( 'max_execution_time' );
		if ( $php_tl_pw > 0 ) {
			@set_time_limit( max( 60, $php_tl_pw ) );
		}

		// Atomic per-blog MySQL lock â€” same idiom as
		// Discovery_Processor::acquire_autogen_lock() and run_overdue_recovery.
		$lock_name = 'seogen_publish_watchdog_' . (int) \get_current_blog_id();
		if ( 1 !== (int) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 5)', $lock_name ) ) ) {
			return;
		}

		$defaults = \SEO_Article_Generator\Option_Registry::defaults();

		try {
			$now_utc_mysql = \SEO_Article_Generator\Utils\Plugin_Time::utc_mysql_now();
			$disc_table    = \SEO_Article_Generator\Installer::table_discovery();

			// Audit Enhancement 5: also recover plugin-owned 'pending' posts whose
			// generation already completed (discovery row in 'done'/'finalizing') but
			// which never transitioned to publish. 'future' posts keep the original
			// behaviour. Ownership is still gated by Post_Type_Classifier below.
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT p.ID, p.post_status, d.ID AS discovery_id, d.existing_post_id
					  FROM {$wpdb->posts} p
					  LEFT JOIN {$disc_table} d
					    ON d.existing_post_id = p.ID
					   AND d.status IN ('done','finalizing')
					  WHERE p.post_type = 'post'
					    AND p.post_date_gmt IS NOT NULL
					    AND p.post_date_gmt <= %s
					    AND (
					        p.post_status = 'future'
					        OR (p.post_status = 'pending' AND d.ID IS NOT NULL)
					    )
					  ORDER BY p.post_date_gmt ASC
					  LIMIT 25",
					$now_utc_mysql
				)
			);

			if ( empty( $rows ) ) {
				return;
			}

			$published = 0;
			$warnings  = 0;
			$skipped_limit = 0;

			foreach ( (array) $rows as $row ) {
				$post_id = (int) $row->ID;

				// TOCTOU guard â€” re-read current status.
				$current = \get_post( $post_id );
				if ( ! $current || ! \in_array( $current->post_status, array( 'future', 'pending' ), true ) ) {
					continue;
				}

				// SSOT ownership check â€” only force-publish posts we own.
				$post_type = \SEO_Article_Generator\Discovery\Post_Type_Classifier::classify( $post_id );
				if ( ! \SEO_Article_Generator\Discovery\Post_Type_Classifier::is_plugin_owned( $post_type ) ) {
					continue;
				}

				// Check daily limits before force-publishing.
				$is_update = (int) ( $row->existing_post_id ?? 0 ) > 0;
				$limit_reached = $this->is_daily_publish_limit_reached( $is_update );
				if ( $limit_reached ) {
					$skipped_limit++;
					$this->logger->info(
						sprintf(
							'[Publish Watchdog] Skipped post %d: daily %s limit reached.',
							$post_id,
							$is_update ? 'update' : 'post'
						)
					);
					continue;
				}

				// wp_publish_post() handles future â†’ publish transition,
				// all status hooks, and updates post_date to NOW.
				$result = \wp_publish_post( $post_id );
				if ( \is_wp_error( $result ) || ! $result ) {
					$warnings++;
					$this->logger->warning(
						sprintf(
							'[Publish Watchdog] Failed to force-publish post %d: %s',
							$post_id,
							\is_wp_error( $result ) ? $result->get_error_message() : 'wp_publish_post returned falsy'
						)
					);
					continue;
				}

				// Best-effort: close the corresponding discovery row so the
				// post leaves the "generating/finalizing" UI. Plugin-owned
				// posts without a discovery row are unaffected.
				$wpdb->update(
					\SEO_Article_Generator\Installer::table_discovery(),
					array(
						'status'        => 'done',
						'completed_at'  => $now_utc_mysql,
						'error_message' => null,
					),
					array( 'existing_post_id' => $post_id ),
					array( '%s', '%s', '%s' ),
					array( '%d' )
				);

				$this->logger->info(
					sprintf(
						'[Publish Watchdog] Force-published post %d (was %s).',
						$post_id,
						$current->post_status
					)
				);

				$published++;
			}

			if ( $published > 0 || $warnings > 0 || $skipped_limit > 0 ) {
				$this->logger->info(
					sprintf(
						'[Publish Watchdog] Force-published %d overdue post(s), %d warning(s), %d skipped (daily limit).',
						$published,
						$warnings,
						$skipped_limit
					)
				);
			}
		} catch ( \Throwable $e ) {
			$this->logger->error( '[Publish Watchdog] Fatal: ' . $e->getMessage() );
		} finally {
			$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock_name ) );
		}
	}

	/**
	 * Check if daily publish limit is reached for new posts or updates.
	 *
	 * @param bool $is_update Whether this is an update (true) or new post (false).
	 * @return bool True if limit reached, false otherwise.
	 */
	private function is_daily_publish_limit_reached( bool $is_update ): bool {
		global $wpdb;

		$defaults = \SEO_Article_Generator\Option_Registry::defaults();
		$site_tz  = \wp_timezone();
		$today    = new \DateTimeImmutable( 'now', $site_tz );
		$ymd_local = $today->format( 'Y-m-d' );

		if ( $is_update ) {
			$max_daily = (int) \get_option( \SEO_Article_Generator\Option_Registry::UPDATES_PER_DAY, $defaults[ \SEO_Article_Generator\Option_Registry::UPDATES_PER_DAY ] );
			// Count updates scheduled/completed today via discovery table
			$count = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(DISTINCT d.id)
					 FROM {$wpdb->posts} p
					 INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = 'seogenjobid'
					 LEFT JOIN " . \SEO_Article_Generator\Installer::table_discovery() . " d ON d.existing_post_id = p.ID
					 WHERE p.post_type = 'post'
					   AND p.post_status IN ('publish','future')
					   AND p.post_date >= %s
					   AND p.post_date < %s
					   AND d.existing_post_id > 0",
					$ymd_local . ' 00:00:00',
					$ymd_local . ' 23:59:59'
				)
			);
		} else {
			$max_daily = (int) \get_option( \SEO_Article_Generator\Option_Registry::POSTS_PER_DAY, $defaults[ \SEO_Article_Generator\Option_Registry::POSTS_PER_DAY ] );
			// Count new posts scheduled/published today
			$count = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(DISTINCT p.ID)
					 FROM {$wpdb->posts} p
					 INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = 'seogenjobid'
					 LEFT JOIN " . \SEO_Article_Generator\Installer::table_discovery() . " d ON d.existing_post_id = p.ID
					 WHERE p.post_type = 'post'
					   AND p.post_status IN ('publish','future')
					   AND p.post_date >= %s
					   AND p.post_date < %s
					   AND (d.existing_post_id IS NULL OR d.existing_post_id = 0)",
					$ymd_local . ' 00:00:00',
					$ymd_local . ' 23:59:59'
				)
			);
		}

		return $count >= $max_daily;
	}

/**
	 * AJAX: Reset the global API cooldown transient.
	 */
	public function ajax_reset_api_cooldown()
	{
		\check_ajax_referer('seo_gen_nonce', 'nonce');
		if (! \current_user_can('manage_options')) {
			\wp_send_json_error(['message' => 'Unauthorized']);
		}

		global $wpdb;

		// 1. Clear provider cooldown transients.
		if (class_exists('\\SEO_Article_Generator\\AI\\AI_Client')) {
			\SEO_Article_Generator\AI\AI_Client::reset_all_cooldowns();
		}

		// Also clear the in-process engine bootstrap block so get_engine() re-evaluates.
		$this->clear_engine_bootstrap_block();
		$this->engine = null;

		// 2. Identify only discovery items whose pipeline actions should be rebuilt.
		$discovery_table = Installer::table_discovery();
		$jobs_table = Installer::table_jobs();
		$rows = $wpdb->get_results(
			"
			SELECT d.id
			FROM {$discovery_table} d
			LEFT JOIN {$jobs_table} j ON j.id = d.job_id
			WHERE d.status IN ('queued','processing','generating','finalizing','failed','timeout','deferred')
			  AND (
			        j.status = 'deferred'
			     OR d.error_message LIKE '%quota%'
			     OR d.error_message LIKE '%cooldown%'
			     OR d.error_message LIKE '%rate limit%'
			     OR d.error_message LIKE '%system busy%'
			     OR d.error_message LIKE '%pipeline paused%'
			     OR j.error_message LIKE '%quota%'
			     OR j.error_message LIKE '%cooldown%'
			     OR j.error_message LIKE '%rate limit%'
			     OR j.error_message LIKE '%system busy%'
			     OR j.error_message LIKE '%pipeline paused%'
			  )
			",
			ARRAY_A
		);

		$blocked_item_ids = array_values(array_unique(array_map('intval', array_column((array) $rows, 'id'))));

		// Purge only item-scoped process/poll actions for blocked discoveries.
		$purged_as_actions = AS_Registry::purge_item_pipeline_actions($blocked_item_ids);

		// 3. Flush object cache.
		if (\function_exists('wp_cache_flush')) {
			\wp_cache_flush();
		}

		$this->logger->info(
			'API Gateway: Targeted API Reset triggered by user. Item actions purged: ' . $purged_as_actions,
			array('blocked_item_ids' => $blocked_item_ids)
		);

		// 4. Revive deferred jobs whose gate is now clear.
		if ($this->job_handler && method_exists($this->job_handler, 'revive_cooldown_jobs')) {
			$this->job_handler->revive_cooldown_jobs();
		}

    // 5. Re-arm scheduler so affected items get fresh actions.
    $this->schedule_discovery_jobs( true ); // Force re-arm after API reset

		// 6. Re-arm processor pipeline for queued / resumable items - final recovery authority
		if (isset($this->processor) && is_object($this->processor)) {
			if (method_exists($this->processor, 'resume_pipeline')) {
				$this->processor->resume_pipeline();
			}

			// Force item-by-item reconcile for targeted reset items
			if (!empty($blocked_item_ids) && method_exists($this->processor, 'reconcile_item_status')) {
				foreach ((array) $blocked_item_ids as $blocked_item_id) {
					$this->processor->reconcile_item_status((int) $blocked_item_id);
				}
			}

			if (method_exists($this->processor, 'invalidate_dashboard_caches')) {
				$this->processor->invalidate_dashboard_caches();
			}
		}


		// 6. Re-arm processor pipeline for queued / resumable items - final recovery authority
		if (isset($this->processor) && is_object($this->processor)) {
			if (method_exists($this->processor, 'resume_pipeline')) {
				$this->processor->resume_pipeline();
			}

			// Force item-by-item reconcile for targeted reset items
			if (!empty($blocked_item_ids) && method_exists($this->processor, 'reconcile_item_status')) {
				foreach ((array) $blocked_item_ids as $blocked_item_id) {
					$this->processor->reconcile_item_status((int) $blocked_item_id);
				}
			}

			if (method_exists($this->processor, 'invalidate_dashboard_caches')) {
				$this->processor->invalidate_dashboard_caches();
			}
		}

		$this->clear_dashboard_snapshot_transients();
		$this->reschedule_auto_gen_cron(true);

		\wp_send_json_success(array(
			'message' => 'API cooldown cleared. Blocked pipeline items were re-armed without purging unrelated scheduler actions.',
			'snapshot' => $this->safe_dashboard_ui_snapshot(),
		));
}

	public function ajaxhealthcheck(): void
	{
		\check_ajax_referer('seo_gen_nonce', 'nonce');

		if (! \current_user_can('manage_options')) {
			\wp_send_json_error(array(
				'message' => \__('Unauthorized', 'seo-article-generator'),
			), 403);
		}

		global $wpdb;

		try {
			$actions_table = $wpdb->prefix . 'actionscheduler_actions';
			$groups_table  = $wpdb->prefix . 'actionscheduler_groups';

			$tableactions = ((string) $wpdb->get_var(
				$wpdb->prepare('SHOW TABLES LIKE %s', $actions_table)
			) === $actions_table) ? 'OK' : 'MISSING';

			$tablegroups = ((string) $wpdb->get_var(
				$wpdb->prepare('SHOW TABLES LIKE %s', $groups_table)
			) === $groups_table) ? 'OK' : 'MISSING';

			$groupid = 0;
			if ($tablegroups === 'OK') {
				$groupid = (int) $wpdb->get_var(
					$wpdb->prepare(
						"SELECT group_id FROM {$groups_table} WHERE slug = %s LIMIT 1",
						self::as_group()
					)
				);
			}

			$pending = 0;
			if (\class_exists('\ActionScheduler') && \method_exists('\ActionScheduler', 'store')) {
				$store = \ActionScheduler::store();

				if ($store && \method_exists($store, 'query_actions')) {
					$pending = (int) $store->query_actions(
						array(
							'group'   => self::as_group(),
							'status'  => \ActionScheduler_Store::STATUS_PENDING,
							'orderby' => 'none',
						),
						'count'
					);
				}
			}

			$workernext = (int) AS_Registry::get_next_run_uncached(AS_Registry::HOOK_QUEUE_WORKER);

			if ($workernext <= 0 && ! $this->is_discovery_paused()) {
				$this->schedule_discovery_jobs();
				$workernext = (int) AS_Registry::get_next_run_uncached(AS_Registry::HOOK_QUEUE_WORKER);
			}

			$debug = array(
				'library'      => \class_exists('\ActionScheduler') ? 'OK' : 'MISSING',
				'store'        => \class_exists('\ActionScheduler_Store') ? 'OK' : 'MISSING',
				'tableactions' => $tableactions,
				'tablegroups'  => $tablegroups,
				'groupid'      => $groupid,
				'pending'      => $pending,
				'workernext'   => $workernext,
				'recentfailed' => array(),
			);

			\wp_send_json_success(array_merge($debug, array(
				'debug' => $debug,
			)));
		} catch (\Throwable $e) {
			$this->logger->error('AS Health Check failed: ' . $e->getMessage());

			\wp_send_json_error(array(
				'message' => $e->getMessage(),
			), 500);
		}
	}

	public function ajax_retry_all_failed()
	{
		\check_ajax_referer('seo_gen_nonce', 'nonce');
		if (! \current_user_can('manage_options')) {
			\wp_send_json_error(['message' => 'Unauthorized']);
		}

		$this->reject_if_discovery_paused('retrying failed items');

		global $wpdb;
		$table = Installer::table_discovery();

		$items = $wpdb->get_results(
			"SELECT id FROM $table WHERE status IN ('failed', 'timeout') ORDER BY discovered_at ASC"
		);

		if (empty($items)) {
			\wp_send_json_success(['message' => 'No failed items to retry.']);
		}

		$uid   = \get_current_user_id() ? (int) \get_current_user_id() : 1;
		$count = 0;
		$gap   = 90;
		$slot  = 0;

		foreach ($items as $row) {
			$delay_seconds = 1 + ( $slot * $gap );

			if ($this->processor->smart_recover_item((int) $row->id, $uid, $delay_seconds)) {
				$count++;
				$slot++;
			}
		}

		if ($count > 0) {
			$this->logger->info("[Bulk Retry] User triggered SMART retry for {$count} items with stagger.", array('count' => $count, 'gap' => $gap));
		}

		\wp_send_json_success(array(
			'message'  => \sprintf('Success: %d items added back to sequence with stagger using SSOT recovery.', $count),
			'count'    => $count,
			'snapshot' => $this->safe_dashboard_ui_snapshot(),
		));
	}

	/**
	 * AJAX: Purge Discovery History (Truncate table).
	 *
	 * @MODIFIED 2026-03-06
	 */
	public function ajax_purge_discovery_history()
	{
		\check_ajax_referer('seo_gen_nonce', 'nonce');
		if (! \current_user_can('manage_options')) {
			\wp_send_json_error(['message' => 'Unauthorized']);
		}

		global $wpdb;
		$table = Installer::table_discovery();

        $job_ids = $wpdb->get_col("SELECT job_id FROM {$table} WHERE job_id > 0 AND status IN ('queued', 'processing', 'generating', 'finalizing', 'deferred')");
        if (!empty($job_ids)) {
            foreach ($job_ids as $jid) {
                if ($this->job_handler && method_exists($this->job_handler, 'force_cancel_job')) {
                    $this->job_handler->force_cancel_job((int) $jid, 'Discovery history purged by user.');
                }
            }
        }

        // COMPREHENSIVE AS PURGE: Clean ALL seo-gen actions including orphans
        $purged_as_actions = \SEO_Article_Generator\Queue\AS_Registry::purge_all_seo_gen_actions();

        $wpdb->query("TRUNCATE TABLE {$table}");

        // @MODIFIED 2026-03-06: Unified deep reset.
        $this->reset_wp_auto_drafts();

        // Use processor as single authority for post-mutation cleanup
        if (isset($this->processor) && is_object($this->processor)) {
            if (method_exists($this->processor, 'after_history_mutation_reconcile')) {
                $this->processor->after_history_mutation_reconcile();
            } elseif (method_exists($this->processor, 'invalidate_dashboard_caches')) {
                $this->processor->invalidate_dashboard_caches();
            }
        }

        $this->logger->info('Purge Discovery history truncated by user. AS actions purged=' . (int) $purged_as_actions);

		\wp_send_json_success(array(
			'message'  => 'Discovery history cleared. Existing posts are still protected from duplication by the engine logic.',
			'snapshot' => $this->safe_dashboard_ui_snapshot(),
		));
	}

	/**
	 * AJAX: Clear Discovery History (Manual History Purge - items > 24h).
	 *
	 * @MODIFIED 2026-03-09
	 */
	public function ajax_clear_discovery_history()
	{
		\check_ajax_referer('seo_gen_nonce', 'nonce');
		if (! \current_user_can('manage_options')) {
			\wp_send_json_error(['message' => 'Unauthorized']);
		}

		global $wpdb;

		$cfg   = $this->get_discovery_retention_config();
		$table = Installer::table_discovery();
		$now   = Plugin_Time::utc_mysql_now();

		$status_sql = "'" . implode("','", \array_map('esc_sql', $cfg['terminal_statuses'])) . "'";

		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT id
				 FROM {$table}
				 WHERE status IN ({$status_sql})
				   AND (
						(completed_at IS NOT NULL AND completed_at < DATE_SUB(%s, INTERVAL %d HOUR))
					 OR (completed_at IS NULL AND discovered_at < DATE_SUB(%s, INTERVAL %d HOUR))
				   )",
				$now,
				(int) $cfg['manual_history_hours'],
				$now,
				(int) $cfg['manual_history_hours']
			)
		);

		$deleted = 0;

		if ( ! empty($ids)) {
			$id_list_str = implode(',', \array_map('intval', $ids));
			$job_ids = $wpdb->get_col("SELECT job_id FROM {$table} WHERE id IN ({$id_list_str}) AND job_id > 0");
			if (!empty($job_ids)) {
				foreach ($job_ids as $jid) {
					if ($this->job_handler && method_exists($this->job_handler, 'force_cancel_job')) {
						$this->job_handler->force_cancel_job((int) $jid, 'Discovery history cleared by user.');
					}
				}
			}

			foreach ($ids as $id) {
				AS_Registry::cancel_item_actions((int) $id);
			}

			$id_list = implode(',', \array_map('intval', $ids));
			$deleted = (int) $wpdb->query("DELETE FROM {$table} WHERE id IN ({$id_list})");
		}

		// Use processor as single authority for post-mutation cleanup
		if (isset($this->processor) && is_object($this->processor)) {
			if (method_exists($this->processor, 'after_history_mutation_reconcile')) {
				$this->processor->after_history_mutation_reconcile();
			} elseif (method_exists($this->processor, 'invalidate_dashboard_caches')) {
				$this->processor->invalidate_dashboard_caches();
			}
		}

		\wp_send_json_success(array(
			'message'  => \sprintf(
				\__('History cleared. %d terminal items older than %d hours were removed.', 'seo-article-generator'),
				$deleted,
				(int) $cfg['manual_history_hours']
			),
			'deleted'  => $deleted,
			'snapshot' => $this->safe_dashboard_ui_snapshot(),
		));
	}

	/**
	 * Shared preflight guard for all "run now" AJAX handlers.
	 * Reads slot counts from DB directly (no object-cache skew).
	 * Sends a JSON error and exits if slots are full.
	 */
	private function preflight_gate_check_or_die(): void {
		$gate    = \SEO_Article_Generator\Core\Admission_Gate::get_instance();
		$metrics = $gate->get_inflight_metrics_uncached();

		if ( $metrics['generations'] >= $metrics['max_gen'] ) {
			\wp_send_json_error( [
				'message'  => \sprintf(
					\__( 'All %d generation slots are occupied. Items are queued and will process automatically.', 'seo-article-generator' ),
					$metrics['max_gen']
				),
				'deferred' => true,
			] );
		}
	}

	/**
	 * AJAX Handler: Run all items in the pipeline immediately.
	 *
	 * @MODIFIED 2026-03-10 - New manual queue trigger.
	 * @MODIFIED 2026-04-09: Added DB-direct preflight check.
	 */
	public function ajax_run_queue_now(): void
	{
		\check_ajax_referer('seo_gen_nonce', 'nonce');
		if (! \current_user_can('manage_options')) {
			\wp_send_json_error(['message' => \__('Unauthorized', 'seo-article-generator')]);
		}

		$this->reject_if_discovery_paused('starting queue or generation work');
		$this->preflight_gate_check_or_die();

		$count = $this->processor->run_queue_now();

		\wp_send_json_success(array(
			'message'  => \sprintf(\__('Manual run staged %d items with stagger.', 'seo-article-generator'), $count),
			'count'    => (int) $count,
			'snapshot' => $this->safe_dashboard_ui_snapshot(),
		));
	}

	/**
	 * AJAX Handler: Run a single pipeline item immediately.
	 *
	 * @MODIFIED 2026-03-10 - New manual item trigger.
	 * @MODIFIED 2026-04-09: Added DB-direct preflight check.
	 */
	public function ajax_run_item_now(): void
	{
		\check_ajax_referer('seo_gen_nonce', 'nonce');
		if (! \current_user_can('manage_options')) {
			\wp_send_json_error(['message' => \__('Unauthorized', 'seo-article-generator')]);
		}

		$this->reject_if_discovery_paused('starting queue or generation work');
		$this->preflight_gate_check_or_die();

		$id = \absint($_POST['id'] ?? 0);
		if ($this->processor->run_item_now($id)) {
			\wp_send_json_success(array(
				'message'  => \__('Item processing started.', 'seo-article-generator'),
				'snapshot' => $this->safe_dashboard_ui_snapshot(),
			));
		} else {
			\wp_send_json_error(['message' => \__('Failed to trigger item. Check if it is still in the pipeline.', 'seo-article-generator')]);
		}
	}

	private function count_wp_auto_unprocessed_drafts(int $category_id): int
	{
		if ($category_id <= 0) {
			return 0;
		}

		$cat_ids = $this->get_wp_auto_category_ids();

		if (empty($cat_ids)) {
			return 0;
		}

		$posts = \get_posts(array(
			'post_type'              => 'post',
			'post_status'            => 'draft',
			'posts_per_page'         => -1,
			'fields'                 => 'ids',
			'category__in'           => $cat_ids,
			'meta_query'             => array(
				'relation' => 'AND',
				array(
					'key'     => 'seo_gen_processed',
					'compare' => 'NOT EXISTS',
				),
				array(
					'key'     => 'seo_gen_processed_status',
					'compare' => 'NOT EXISTS',
				),
			),
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
			'no_found_rows'          => true,
		));

		return \is_array($posts) ? \count($posts) : 0;
	}

	public function get_dashboard_wp_auto_snapshot(): array
	{
		$category_id    = (int) \get_option('seo_gen_wp_auto_category_id', 0);
		$next_poll      = AS_Registry::get_next_run(AS_Registry::HOOK_WP_AUTO_DRAFT_POLL, array(), true);
		$raw_next_poll  = AS_Registry::get_next_run(AS_Registry::HOOK_WP_AUTO_DRAFT_POLL);
		$pending_drafts = $this->count_wp_auto_unprocessed_drafts($category_id);

		$configured = $category_id > 0;
		$scheduled  = $next_poll > 0;

		// Overdue: a pending poll instance exists but its scheduled time is in
		// the past (Action Scheduler has not executed it). Surface this so the
		// UI shows "running late" instead of a stale clock time.
		$next_poll_overdue = $raw_next_poll > 0
			&& $raw_next_poll < \SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts();

		$state = ! $configured ? 'inactive' : ($scheduled ? 'scheduled' : 'broken');
		$label = ! $configured ? 'Not Configured' : ($scheduled ? 'Active' : 'Broken');

		return array(
			'state'              => $state,
			'label'              => $label,
			'category_id'        => $category_id,
			'configured'         => $configured ? 1 : 0,
			'scheduled'          => $scheduled ? 1 : 0,
			'next_poll'          => $next_poll ? (int) $next_poll : 0,
			'next_poll_raw'      => $raw_next_poll ? (int) $raw_next_poll : 0,
			'next_poll_overdue'  => $next_poll_overdue ? 1 : 0,
			'next_poll_text'     => $next_poll ? Plugin_Time::site_datetime((int) $next_poll) : 'Not scheduled',
			'pending_drafts'     => (int) $pending_drafts,
		);
	}

	public function ajax_wp_auto_snapshot(): void
	{
		\check_ajax_referer('seo_gen_nonce', 'nonce');

		if (! \current_user_can('manage_options')) {
			\wp_send_json_error(array('message' => \__('Unauthorized', 'seo-article-generator')), 403);
		}

		\wp_send_json_success(array(
			'snapshot' => $this->get_dashboard_wp_auto_snapshot(),
		));
	}

	public function get_wp_auto_category_ids(): array
	{
		$category_id = (int) \get_option('seo_gen_wp_auto_category_id', 0);
		if ($category_id <= 0) {
			return [];
		}

		$child_ids = \get_term_children($category_id, 'category');
		if (!is_array($child_ids)) {
			$child_ids = [];
		}

		$cat_ids   = array_map('intval', array_merge([$category_id], $child_ids));
		$cat_ids   = array_values(array_unique(array_filter($cat_ids)));

		return $cat_ids;
	}

	private function get_wp_auto_draft_ids(): array
	{
		$cat_ids = $this->get_wp_auto_category_ids();
		if (empty($cat_ids)) {
			return [];
		}

		$posts = \get_posts([
			'post_type'      => 'post',
			'post_status'    => 'draft',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'category__in'   => $cat_ids,
		]);

		return array_map('intval', (array) $posts);
	}

	private function clear_wp_auto_draft_meta(array $meta_keys): int
	{
		global $wpdb;

		$post_ids = $this->get_wp_auto_draft_ids();
		if (empty($post_ids) || empty($meta_keys)) {
			return 0;
		}

		$post_in = implode(',', array_map('intval', $post_ids));
		$key_in  = "'" . implode("','", array_map('esc_sql', $meta_keys)) . "'";

		return (int) $wpdb->query(
			"DELETE FROM {$wpdb->postmeta}
			 WHERE post_id IN ({$post_in})
			   AND meta_key IN ({$key_in})"
		);
	}

	/**
	 * Shared helper: Reset WP Auto drafts in the configured category.
	 * Clears processed metadata and cancels pending deletion actions.
	 */
	private function reset_wp_auto_drafts(): int
	{
		$post_ids = $this->get_wp_auto_draft_ids();
		if (empty($post_ids)) {
			return 0;
		}

		// 1. Clear metadata (Now including error log for a truly "fresh" start)
		$this->clear_wp_auto_draft_meta([
			'seo_gen_processed',
			'seo_gen_processed_status',
			'seo_gen_error_log',
			'seo_gen_throttle_until',
		]);

		// 2. Cancel scheduled deletions
		foreach ($post_ids as $post_id) {
			AS_Registry::unschedule_all(AS_Registry::HOOK_DELETE_DRAFT, [(int) $post_id]);
		}

		$this->logger->info(\sprintf("[WP Auto Reset] Synchronized reset for %d drafts.", \count($post_ids)));
		return \count($post_ids);
	}

	/**
	 * AJAX Handler: Manually trigger the WP Auto draft poll
	 * 
	 * @since 2.5.5
	 */
	/**
	 * AJAX Handler: Manually trigger the WP Auto draft poll
	 * 
	 * @since 2.5.5
	 * @MODIFIED 2026-04-09: Wrapped in scanner mutex guard.
	 */
	public function ajax_trigger_wp_auto_poll()
	{
		\check_ajax_referer("seo_gen_nonce", "nonce");
		if (!\current_user_can("manage_options")) {
			\wp_send_json_error(["message" => "Unauthorized"]);
		}

		$this->reject_if_discovery_paused("running WP Auto draft polling");

		$this->ajax_scanner_guard("wp_auto", function($engine) {
			$this->logger->info("Manual WP Auto poll triggered via AJAX.");
			$engine->run_wp_auto_draft_poll();
		});

		\wp_send_json_success( array(
			'message'          => \__( 'Poll completed.', 'seo-article-generator' ),
			'snapshot'         => $this->safe_dashboard_ui_snapshot(),
			'wp_auto_snapshot' => $this->get_dashboard_wp_auto_snapshot(),
		) );
	}

	public function ajax_clear_wp_auto_log()
	{
		\check_ajax_referer('seo_gen_nonce', 'nonce');
		if (!\current_user_can('manage_options')) {
			\wp_send_json_error(['message' => 'Unauthorized']);
		}

		$reset_count = $this->reset_wp_auto_drafts();

		$this->logger->info("[WP Auto] Cleared processed history via unified reset helper.");

		\wp_send_json_success( array(
			'message'          => \sprintf(
				\__( 'Processed draft history cleared for %d drafts.', 'seo-article-generator' ),
				$reset_count
			),
			'reset_count'      => $reset_count,
			'snapshot'         => $this->safe_dashboard_ui_snapshot(),
			'wp_auto_snapshot' => $this->get_dashboard_wp_auto_snapshot(),
		) );
	}

	/**
	 * AJAX: Regenerate the external heartbeat cron secret.
	 *
	 * Rotates the shared-secret token for the ?seo_gen_heartbeat=1&secret=<...>
	 * endpoint. After rotation, the operator must update their VPS crontab /
	 * cron.org URL with the new secret â€” the old secret returns 403.
	 *
	 * @since 2.30.x (Heartbeat Enhancement)
	 */
	public function ajax_regenerate_heartbeat_secret() {
		\check_ajax_referer( 'seo_gen_nonce', 'nonce' );
		if ( ! \current_user_can( 'manage_options' ) ) {
			\wp_send_json_error( array( 'message' => 'Unauthorized' ) );
		}

		$new_secret = \wp_generate_password( 32, false );
		\update_option( \SEO_Article_Generator\Option_Registry::EXTERNAL_CRON_SECRET, $new_secret, false );

		if ( $this->logger ) {
			$this->logger->info( '[Heartbeat] Secret regenerated by admin.' );
		}

		$home_url = \home_url( '/' );
		$command = \sprintf(
			'curl -s "%s?seo_gen_heartbeat=1&secret=%s"',
			\trailingslashit( $home_url ),
			$new_secret
		);

		\wp_send_json_success( array(
			'message'  => \__( 'Heartbeat secret regenerated. Update your crontab with the new URL below.', 'seo-article-generator' ),
			'secret'   => $new_secret,
			'url'      => \trailingslashit( $home_url ) . '?seo_gen_heartbeat=1&secret=' . $new_secret,
			'command'  => $command,
			'snapshot' => $this->safe_dashboard_ui_snapshot(),
		) );
	}

	/**
	 * AJAX: Test-fire the heartbeat endpoint from the admin UI.
	 *
	 * Performs an internal wp_remote_get against the heartbeat URL with the
	 * current secret so the operator can verify the endpoint works without
	 * leaving the dashboard. Returns the plain-text response body so the
	 * operator sees the watchdog report.
	 *
	 * @since 2.30.x (Heartbeat Enhancement)
	 */
	public function ajax_test_heartbeat() {
		\check_ajax_referer( 'seo_gen_nonce', 'nonce' );
		if ( ! \current_user_can( 'manage_options' ) ) {
			\wp_send_json_error( array( 'message' => 'Unauthorized' ) );
		}

		$secret = (string) \get_option( \SEO_Article_Generator\Option_Registry::EXTERNAL_CRON_SECRET, '' );
		if ( '' === $secret ) {
			$secret = \wp_generate_password( 32, false );
			\update_option( \SEO_Article_Generator\Option_Registry::EXTERNAL_CRON_SECRET, $secret, false );
		}

		// FIX 7a: Append a per-call cache-buster (`&now=<unix_micros>`) to
		// the Test Now URL. Without it, the operator's "Test Now" calls all
		// hash to the SAME Cloudflare cache key as the homepage ping â€” CF
		// returns the 2-hour-old cached body, `handle_external_heartbeat`
		// never runs on this call, and the response is "OK" but stale.
		// The cache-buster guarantees each Test-Now URL is a fresh cache key
		// that CF has never seen, forcing it to call origin. The plugin's
		// own endpoint ignores the `now` parameter (forward-compatible).
		$test_cache_buster = (string) ( \microtime( true ) );
		$url = \add_query_arg(
			array(
				'seo_gen_heartbeat' => '1',
				'secret'            => $secret,
				'now'               => $test_cache_buster,
			),
			\home_url( '/' )
		);

		// Tell wp_remote_get to bypass any local upstream cache. The
		// `Cache-Control: no-store` request header is honored by Cloudflare
		// in most configurations and provides a defense-in-depth signal
		// alongside the `now` URL cache-buster above.
		$response = \wp_remote_get(
			$url,
			array(
				'timeout'    => 60,
				'sslverify'  => false,
				'headers'     => array(
					'Cache-Control' => 'no-store',
					'Pragma'        => 'no-cache',
				),
			)
		);

		if ( \is_wp_error( $response ) ) {
			\wp_send_json_error( array(
				'message' => 'Heartbeat test failed: ' . $response->get_error_message(),
			) );
		}

		$code = (int) \wp_remote_retrieve_response_code( $response );
		$body = (string) \wp_remote_retrieve_body( $response );

		// When the remote request succeeds (heartbeat endpoint responded),
		// update the option directly so the admin UI reflects the fresh
		// timestamp without requiring a page reload. This also handles the
		// case where Cloudflare/cache serves a stale response to wp_remote_get
		// while handle_external_heartbeat() never actually ran.
		//
		// FIX 6: The original `strpos($body,'heartbeat: ok')===0` check
		// silently failed whenever a cache-protection plugin (e.g. WP CF
		// Super Cache) prepended whitespace to the body, an HTML pre-amble,
		// or a cached-homepage response was returned. Use case-insensitive
		// substring match anywhere in the body and ALWAYS log when the
		// success branch was rejected so the operator can trace the cache
		// corruption. Without this branch, "Test Now" reported success in
		// the UI while leaving `EXTERNAL_CRON_LAST_FIRE` stale forever.
		$timestamp = 0;
		if ( $code === 200 ) {
			$body_lower = \strtolower( $body );
			if ( \strpos( $body_lower, 'heartbeat: ok' ) !== false
				&& \strpos( $body_lower, 'heartbeat: forbidden' ) === false
				&& \strpos( $body_lower, 'heartbeat: already-running' ) === false
			) {
				$timestamp = \SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts();
				\update_option( \SEO_Article_Generator\Option_Registry::EXTERNAL_CRON_LAST_FIRE, $timestamp, false );
				\update_option( \SEO_Article_Generator\Option_Registry::EXTERNAL_CRON_LAST_REPORT, \wp_json_encode( array( 'source' => 'test_button', 'body' => $body ) ), false );
			} else {
				// Silent failure trace: log the rejected CI response so the
				// operator can see exactly what CF/cache returned. Avoids the
				// pattern where "Test Now" reported success in the UI but the
				// last-fire option stayed 0.
				$grabbed_preview = \substr( $body, 0, 240 );
				if ( $this->logger ) {
					$this->logger->info(
						\sprintf(
							'[Heartbeat/TestNow] rejected remote response (code=%d). body_preview=%s',
							$code,
							$grabbed_preview
						)
					);
				}
				// Still surface it to the operator via the last_report
				// transient so the JS-side pre block shows the cached body.
				\update_option(
					\SEO_Article_Generator\Option_Registry::EXTERNAL_CRON_LAST_REPORT,
					\wp_json_encode(
						array(
							'source'  => 'test_button_rejected',
							'code'    => $code,
							'body'    => $body,
							'hint'    => 'Cached/cloudflare response â€” see Cloudflare Page Rule for seo_gen_heartbeat',
						)
					),
					false
				);
			}
		}

		\wp_send_json_success( array(
			'message'   => \sprintf( 'Heartbeat test complete (HTTP %d).', $code ),
			'code'      => $code,
			'body'      => $body,
			'timestamp' => $timestamp,
		) );
	}

	/**
	 * Shared helper: Get comprehensive API pause status across all providers.
	 * PHASE 5 FIX: Thin wrapper around canonical AI_Client::getProviderStatus().
	 * No local recomputation - use only the DTO from AI_Client.
	 */
	public function get_api_pause_info(): array
	{
		if (! class_exists('\\SEO_Article_Generator\\AI\\AI_Client')) {
			return array(
				'paused' => 1,
				'resume_diff' => '',
				'reason' => 'AI client unavailable',
				'until' => Plugin_Time::now_utc_ts() + \DAY_IN_SECONDS,
				'providers_detail' => array(),
				'enabled_count' => 0,
				'routable' => array(),
				'temporary_blocked' => array(),
				'hard_blocked' => array(),
				'min_retry_after' => 0,
				'bootstrap_provider' => '',
			);
		}

		// PHASE 5 FIX: Consume canonical DTO directly - no local derivation
		$status = \SEO_Article_Generator\AI\AI_Client::get_provider_status();

		$now_utc = Plugin_Time::now_utc_ts();
		$until = (int) ($status['until'] ?? 0);

		// @FIX 2026-04-19: If the 'until' timestamp is in the past, treat as unpaused
		// regardless of what the DTO says - this clears stale transient artefacts.
		if ($until > 0 && $until <= $now_utc) {
			$status['paused'] = 0;
			$status['resume_diff'] = '';
			$status['reason'] = '';
			// Actively clear the stale block so it doesn't re-infect get_engine()
			$this->clear_engine_bootstrap_block();
		}

		return array(
			'paused' => (int) ($status['paused'] ?? 0),
			'resume_diff' => (string) ($status['resume_diff'] ?? ''),
			'reason' => (string) ($status['reason'] ?? ''),
			'until' => $until,
			'providers_detail' => (array) ($status['providers_detail'] ?? array()),
			'enabled_count' => (int) ($status['enabled_count'] ?? 0),
			'routable' => (array) ($status['routable'] ?? array()),
			'temporary_blocked' => (array) ($status['temporary_blocked'] ?? array()),
			'hard_blocked' => (array) ($status['hard_blocked'] ?? array()),
			'min_retry_after' => (int) ($status['min_retry_after'] ?? 0),
			'bootstrap_provider' => (string) ($status['bootstrap_provider'] ?? ''),
		);
	}

	private function ajax_scanner_guard(string $type, callable $work): void
	{
		$engine = $this->get_engine();
		if (!$engine) {
			$diagnostics = $this->get_engine_init_failure_diagnostics();
			\wp_send_json_error([
				"message" => "Discovery Engine could not be initialized.",
				"diagnostics" => $diagnostics,
			]);
		}
		
		if (!$engine->acquire_scanner_mutex($type)) {
			\wp_send_json_error(["message" => "Another scan (" . $type . ") is already in progress. Please wait."]);
		}

		try {
			$work($engine);
		} finally {
			$engine->release_scanner_mutex($type);
		}
	}

	private function get_engine_init_failure_diagnostics(): array
	{
		$diagnostics = array(
			"last_reason" => $this->engine_bootstrap_last_reason,
			"retry_after_utc" => $this->engine_bootstrap_retry_after_utc,
			"now_utc" => Plugin_Time::now_utc_ts(),
		);

		$block = $this->get_engine_bootstrap_block();
		if (!empty($block)) {
			$diagnostics["bootstrap_block"] = $block;
		}

		// PHASE 5 FIX: Use get_provider_status() as single source of truth
		$provider_status = AI_Client::get_provider_status();
		if (!empty($provider_status)) {
			$diagnostics["provider_status"] = $provider_status;
		}

		if (empty($diagnostics["last_reason"]) && empty($block["retry_after_utc"])) {
			$diagnostics["hint"] = "Check API key configuration and provider settings in plugin settings.";
		} elseif (!empty($block["retry_after_utc"]) && $block["retry_after_utc"] > $diagnostics["now_utc"]) {
			$diagnostics["hint"] = "A temporary block is active. Wait for cooldown period or check system logs.";
		} elseif (!empty($diagnostics["last_reason"])) {
			$diagnostics["hint"] = "Previous initialization attempt failed. Check WordPress error log for details.";
		}

		return $diagnostics;
	}

	/**
	 * AJAX: Purge processed WP-Auto draft posts.
	 *
	 * Deletes draft posts that have been processed by the plugin (have seo_gen_processed
	 * or _seo_gen_hero_data meta) or whose discovery row is in a terminal state.
	 * Also re-schedules pending deletion actions for orphaned drafts.
	 *
	 * @since 2.25.0
	 */
	public function ajax_purge_processed_drafts()
	{
		\check_ajax_referer('seo_gen_nonce', 'nonce');
		if (! \current_user_can('manage_options')) {
			\wp_send_json_error(['message' => 'Unauthorized']);
		}

		global $wpdb;

		$table      = Installer::table_discovery();
		$deleted    = 0;
		$rescheduled = 0;

		// 1. Find all draft posts linked to discovery rows
		$linked_drafts = $wpdb->get_results(
			"SELECT d.id AS discovery_id, d.draft_post_id, d.status AS disc_status
			 FROM {$table} d
			 INNER JOIN {$wpdb->posts} p ON p.ID = d.draft_post_id
			 WHERE d.draft_post_id IS NOT NULL AND d.draft_post_id > 0
			   AND p.post_status IN ('draft', 'auto-draft', 'pending')"
		);

		if (! empty($linked_drafts)) {
			foreach ($linked_drafts as $row) {
				$draft_id    = (int) $row->draft_post_id;
				$disc_status = (string) $row->disc_status;
				$terminal    = in_array($disc_status, array('done','failed','timeout','skippednotnewer','skippedduplicate','ignored'), true);

				// Delete draft if its discovery row is terminal, or if it has plugin meta
				$has_plugin_meta       = (bool) \get_post_meta($draft_id, '_seo_gen_hero_data', true);
				$has_wp_auto_processed = (bool) \get_post_meta($draft_id, 'seo_gen_processed', true);

				if ($terminal || $has_plugin_meta || $has_wp_auto_processed) {
					$engine = $this->get_engine();
					if ($engine) {
						$engine->delete_draft_post($draft_id);
					} else {
						\wp_delete_post($draft_id, true);
					}
					$deleted++;
				}
			}
		}

		// 2. Find orphaned drafts: drafts that exist but have no discovery link
		//    and were created by WP-Auto (have wpautomaticurl or automatic_url meta)
		$orphan_drafts = $wpdb->get_results(
			"SELECT p.ID
			 FROM {$wpdb->posts} p
			 LEFT JOIN {$table} d ON d.draft_post_id = p.ID
			 WHERE p.post_status IN ('draft', 'auto-draft', 'pending')
			   AND p.post_type = 'post'
			   AND d.id IS NULL
			   AND ( EXISTS (
			       SELECT 1 FROM {$wpdb->postmeta} pm
			       WHERE pm.post_id = p.ID
			         AND pm.meta_key IN ('wpautomaticurl', 'automatic_url', 'seo_gen_processed')
			   ) )"
		);

		if (! empty($orphan_drafts)) {
			foreach ($orphan_drafts as $orphan) {
				$engine = $this->get_engine();
				if ($engine) {
					$engine->delete_draft_post((int) $orphan->ID);
				} else {
					\wp_delete_post((int) $orphan->ID, true);
				}
				$deleted++;
			}
		}

		// 3. Re-schedule any remaining draft deletions for drafts still in discovery
		$remaining = $wpdb->get_col(
			"SELECT draft_post_id FROM {$table}
			 WHERE draft_post_id IS NOT NULL AND draft_post_id > 0"
		);
		foreach ((array) $remaining as $did) {
			$did = (int) $did;
			if ($did > 0 && \get_post($did)) {
				Discovery_Engine::schedule_draft_deletion($did, 0);
				$rescheduled++;
			}
		}

		// Invalidate caches
		if (isset($this->processor) && is_object($this->processor)) {
			if (method_exists($this->processor, 'invalidate_dashboard_caches')) {
				$this->processor->invalidate_dashboard_caches();
			}
		}

		$this->logger->info(sprintf(
			'Processed draft purge: %d drafts deleted, %d deletion actions re-scheduled.',
			$deleted,
			$rescheduled
		));

		\wp_send_json_success(array(
			'message'  => \sprintf(
				'%d processed draft posts deleted. %d deletion actions re-scheduled for remaining drafts.',
				$deleted,
				$rescheduled
			),
			'deleted'     => $deleted,
			'rescheduled' => $rescheduled,
			'snapshot'    => $this->safe_dashboard_ui_snapshot(),
		));
	}
}
