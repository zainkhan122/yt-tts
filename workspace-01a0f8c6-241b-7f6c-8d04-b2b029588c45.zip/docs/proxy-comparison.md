# Proxy Fallback — Free Services Compared + Best Plan (2026-10-01)

All numbers verified against each provider's own site/docs on 2026-10-01 — none from memory.

## Our workload (the yardstick)

- ~21–22 feed fetches per run × 4 runs/day ≈ **85 fetches/day ≈ 2,550/month** if EVERY
  fetch needed a proxy. Realistically near-zero: the proxy fires only after a direct
  fetch **and** its retry both fail (v3.5.6 hardening handles most cases).
- Plain JSON fetch, **no JavaScript rendering needed** (rendering is what makes proxies
  expensive — we never use it).
- Plugin fetches sequentially (one request at a time).

## The comparison

| # | Service | Free tier (verified) | Plain fetch cost | Covers our 2,550/mo? | Verdict |
|---|---|---|---|---|---|
| 1 | **ScrapingAnt** | **10,000 credits/mo**, recurring, no card | 1 credit | ✅ 4× headroom | **PRIMARY** — biggest verified recurring tier; failed requests cost 0 credits; free plan allows 1 concurrent request (we're sequential — fine) |
| 2 | **ZenRows** | 5,000 credits/mo, recurring, no card | 1 credit (premium proxy 10) | ✅ 2× headroom | **BACKUP** — different company, different IP pool; ⚠️ bills 404 responses as successes (our 404-guard neutralizes this) |
| 3 | **Crawlbase** | "up to 5,000 free" per their site (older docs say 1,000) | 1 request | ⚠️ 40–200% | Wired in plugin, but verify your actual quota after signup before relying on it |
| 4 | **ScraperAPI** | 1,000 credits/mo | 1 credit | ❌ 40% | Wired; fine as a spare |
| 5 | **ScrapingBee** | 1,000 credits (signup) | 1 credit | ❌ 40% | Wired; fine as a spare |
| 6 | Scrape.do | 1,000 credits/mo | 1 credit | ❌ 40% | Compared but NOT wired (endpoint format not re-verified this session) |
| 7 | **Own Cloudflare Worker** | **100,000 requests/DAY** (≈3M/mo) | 0 credits | ✅ 1,000× headroom | **THE FOREVER LAYER** — you own it, no third party reads your feeds, no terms can change on you. One-time 10-min deploy. Code: `config/cf-worker-relay.js` |

Why not free public proxy lists: unreliable, die weekly, and a tampered feed could
inject garbage into your posts. The plugin JSON-validates every proxy response, but a
flaky proxy still means missed posts.

## The best plan (layered — any single failure can't take you down)

```
Layer 0  Direct fetch (free, unlimited)      v3.5.6 hardened: browser UA, 2s pacing, retry
Layer 1  ScrapingAnt  (10k/mo, 1 credit)     fires only when direct+retry both fail
Layer 2  ZenRows      (5k/mo, 1 credit)      fires when ScrapingAnt also fails
Layer 3  Own Worker   (100k/DAY, free)       the layer nobody can take away — recommended
```

Credit guards built into the plugin (v3.5.8):
- **404/410 feeds are never proxied** — the collection is dead; a proxy can't help and
  ZenRows *bills* 404s.
- **Circuit breaker**: 3 straight proxy failures in one run → proxying stops until the
  next run (protects credits when the store itself is down).
- One attempt per provider per feed, max 2 providers.
- Every rescue/failure is logged: `[NET] proxy rescues: scrapingant 2, zenrows 1`.

## Setup steps (15 minutes total)

1. **Update plugin** to v3.5.8 (paste-over `php/collection-post-generator.php`).
2. **ScrapingAnt**: app.scrapingant.com/signup (no card) → copy API key →
   Settings → DIT Fashion PG → Proxy fallback → **Primary: ScrapingAnt** + key.
3. **ZenRows**: zenrows.com free plan (no card) → **Backup: ZenRows** + key.
4. **Optional but recommended (Layer 3)**: deploy the Worker —
   a. workers.cloudflare.com → free account → Create Worker → name `dit-relay` → Edit code →
      paste `config/cf-worker-relay.js` → change the SECRET to a long random string → Deploy.
   b. Test in browser: `https://dit-relay.<your-subdomain>.workers.dev/relay/SECRET/?url=https://sanaullastore.com/collections/mushq/products.json?limit=250`
      → must show JSON.
   c. Plugin → Primary: **Custom relay / own Worker**, template:
      `https://dit-relay.<your-subdomain>.workers.dev/relay/SECRET/?url={URL}` (key stays empty).
5. Watch the log: `[NET]` lines show what was rescued and by whom.

## Honest caveats

- **No free tier is contractually forever.** ZenRows already changed its pricing
  structure once. That's exactly WHY the plan is layered: ScrapingAnt dying → ZenRows
  covers; both dying → your Worker covers; the Worker is the only layer whose terms
  you control (it's your own Cloudflare account).
- The Worker relays only to `sanaullastore.com` (hard-coded allowlist — it can never be
  abused as an open proxy). Keep the SECRET long.
- Don't tick "premium proxies" unless standard requests fail — it's 10 credits instead
  of 1 on ZenRows.
- Still paste me the next run log: if `[NET]` shows heavy proxy use, the host-IP block
  is fully in effect; if it shows nothing, Layer 0 is winning on its own.
