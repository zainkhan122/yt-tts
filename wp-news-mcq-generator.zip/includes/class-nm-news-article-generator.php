<?php

/**
 * News Roundup Article Generator
 *
 * Generates one SEO / AIO / LLMO optimized "news roundup" article per news batch,
 * assigns a random named author (Author-role users), links to the topic hub and the
 * MCQs it spawned, and stores RankMath-compatible SEO meta + FAQ schema.
 *
 * @package wp-news-mcq-generator
 * @since   9.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class NM_News_Article_Generator {

	/**
	 * Option key controlling auto-publish of generated articles.
	 * 1 = publish immediately; 0 = save as draft.
	 */
	const OPTION_AUTO_PUBLISH = 'nm_article_auto_publish';

	/**
	 * Option key storing the selected author user IDs (array). Empty = fall back to
	 * any user with the 'author' role, then to the brand fallback.
	 */
	const OPTION_AUTHORS = 'nm_article_authors';

	/**
	 * Option key controlling whether article generation is enabled at all.
	 */
	const OPTION_ENABLED = 'nm_article_generation_enabled';

	/**
	 * @FIX 9.3.3: Daily cap on generated roundup articles. The Current Affairs pipeline
	 * (the ACTIVE news pipeline) runs its worker every ~5 min, so without a cap it would
	 * generate a new article every few minutes (hundreds/day). Default 2/day matches the
	 * original "1 article per news batch (twice a day)" intent.
	 */
	const OPTION_DAILY_LIMIT = 'nm_article_daily_limit';

	/**
	 * Singleton.
	 */
	private static $instance = null;

	public static function init() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_filter( 'rank_math/json_ld', array( $this, 'inject_article_schema' ), 99, 2 );
		// @NEW 9.2.0: Prepend a YouTube Short embed to generated articles that have a
		// short URL stored (set by the mcq-video-studio system in Phase 4). This runs on
		// the frontend so it also works for shorts linked after the article is published.
		add_filter( 'the_content', array( $this, 'prepend_short_embed_to_article' ), 10 );
	}

	/**
	 * Prepend a YouTube Short embed to the front of a generated article when a short
	 * URL has been linked to it via _nm_article_short_url.
	 */
	public function prepend_short_embed_to_article( $content ) {
		if ( ! is_singular( 'post' ) || ! get_post_meta( get_the_ID(), '_nm_article_generated', true ) ) {
			return $content;
		}
		$short_url = get_post_meta( get_the_ID(), '_nm_article_short_url', true );
		if ( empty( $short_url ) ) {
			return $content;
		}
		$youtube_id = self::extract_youtube_id( $short_url );
		if ( ! $youtube_id ) {
			return $content;
		}
		$embed = '<h2>Watch the Video</h2><div class="nm-article-short-embed" style="position:relative;width:100%;max-width:400px;aspect-ratio:9/16;margin:0 auto 20px;">'
			. '<iframe src="https://www.youtube-nocookie.com/embed/' . esc_attr( $youtube_id ) . '" title="Related video" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen style="position:absolute;top:0;left:0;width:100%;height:100%;border:0;"></iframe>'
			. '</div>';
		return $embed . $content;
	}

	/**
	 * Whether article generation is enabled in settings.
	 */
	public static function is_enabled() {
		return (bool) get_option( self::OPTION_ENABLED, 0 );
	}

	/**
	 * Whether generated articles should be auto-published.
	 */
	public static function auto_publish_enabled() {
		return (bool) get_option( self::OPTION_AUTO_PUBLISH, 0 );
	}

	/**
	 * Daily cap on generated roundup articles (default 2).
	 */
	public static function daily_limit() {
		return max( 1, (int) get_option( self::OPTION_DAILY_LIMIT, 2 ) );
	}

	/**
	 * How many roundup articles were generated today.
	 */
	public static function count_today() {
		$key   = 'nm_article_daily_' . gmdate( 'Y-m-d' );
		return (int) get_transient( $key );
	}

	/**
	 * Whether we are still under today's article cap.
	 */
	public static function can_generate_today() {
		return self::count_today() < self::daily_limit();
	}

	/**
	 * Record that a roundup article was generated today (increments the daily counter).
	 */
	public static function record_generated_today() {
		$key = 'nm_article_daily_' . gmdate( 'Y-m-d' );
		$n   = self::count_today() + 1;
		set_transient( $key, $n, DAY_IN_SECONDS + 600 );
	}

	/**
	 * @NEW 9.5.2: Get-or-create a core category by name/slug and return its term ID.
	 *
	 * Used to file generated content under content-type categories ("Study Guides",
	 * "Daily Roundups") instead of leaving posts in "Uncategorized". We intentionally
	 * do NOT mirror topic terms as categories — the `topic` taxonomy already owns the
	 * topical archives and duplicate category archives would compete with them.
	 *
	 * @param string $name Category display name.
	 * @param string $slug Category slug.
	 * @return int Term ID, or 0 on failure.
	 */
	public static function ensure_category( $name, $slug ) {
		$existing = term_exists( $slug, 'category' );
		if ( ! $existing ) {
			$existing = term_exists( $name, 'category' );
		}
		if ( $existing ) {
			return is_array( $existing ) ? (int) $existing['term_id'] : (int) $existing;
		}
		$created = wp_insert_term( $name, 'category', array( 'slug' => $slug ) );
		if ( is_wp_error( $created ) ) {
			return 0;
		}
		return (int) $created['term_id'];
	}

	/**
	 * Pick a random author user.
	 *
	 * Priority:
	 *   1. Explicitly configured author IDs (OPTION_AUTHORS).
	 *   2. Any WP user with the 'author' role.
	 *   3. The first administrator (brand fallback via get_bloginfo name).
	 *
	 * @return array { user_id, display_name } (display_name falls back to brand name).
	 */
	public static function pick_random_author() {
		$configured = get_option( self::OPTION_AUTHORS, array() );
		$user_ids   = array();

		if ( is_array( $configured ) && ! empty( $configured ) ) {
			$user_ids = array_map( 'absint', $configured );
			$user_ids = array_values( array_filter( $user_ids ) );
		}

		if ( empty( $user_ids ) ) {
			// Fallback: any user with the 'author' role.
			$authors = get_users(
				array(
					'role'    => 'author',
					'number'  => 100,
					'fields'  => 'ID',
					'orderby' => 'ID',
				)
			);
			$user_ids = is_array( $authors ) ? array_map( 'absint', $authors ) : array();
		}

		if ( empty( $user_ids ) ) {
			// Brand fallback: first admin as post_author, but display the brand name.
			$admins = get_users(
				array(
					'role'   => 'administrator',
					'number' => 1,
					'fields' => 'ID',
				)
			);
			$admin_id = ! empty( $admins ) ? (int) $admins[0] : 0;
			return array(
				'user_id'      => $admin_id,
				'display_name' => get_bloginfo( 'name' ),
			);
		}

		$user_id = $user_ids[ array_rand( $user_ids ) ];
		$user    = get_userdata( $user_id );
		$name    = $user ? $user->display_name : get_bloginfo( 'name' );

		return array(
			'user_id'      => $user_id,
			'display_name' => $name,
		);
	}

	/**
	 * Generate a roundup article for a news batch.
	 *
	 * @param array $articles Array of { title, description, url, source_name, category }.
	 * @param array $mcqs     Array of generated MCQs { post_id, question, topic, subtopic, permalink }.
	 * @return int|WP_Error   Post ID on success, WP_Error on failure / skip.
	 */
	public static function generate_for_batch( array $articles = array(), array $mcqs = array() ) {
		if ( ! self::is_enabled() ) {
			return new WP_Error( 'article_disabled', 'Article generation is disabled in settings.' );
		}
		if ( empty( $articles ) && empty( $mcqs ) ) {
			return new WP_Error( 'empty_batch', 'No stories/MCQs to base the article on.' );
		}

		if ( ! class_exists( 'NM_API_Client' ) ) {
			return new WP_Error( 'no_api', 'NM_API_Client unavailable.' );
		}
		$api_key = NM_API_Client::get_gemini_api_key();
		if ( empty( $api_key ) ) {
			return new WP_Error( 'no_key', 'Gemini API key missing.' );
		}

		$client = NM_API_Client::get_instance();
		if ( ! method_exists( $client, 'generate_news_article_from_batch' ) ) {
			return new WP_Error( 'no_method', 'Article generation method not available in API client.' );
		}

		// Derive a topic hint from the most common topic among the generated MCQs.
		$topic_hint = '';
		$topic_counts = array();
		foreach ( $mcqs as $m ) {
			if ( ! empty( $m['topic'] ) ) {
				$topic_counts[ $m['topic'] ] = ( isset( $topic_counts[ $m['topic'] ] ) ? $topic_counts[ $m['topic'] ] : 0 ) + 1;
			}
		}
		if ( $topic_counts ) {
			arsort( $topic_counts );
			$topic_hint = (string) key( $topic_counts );
		}

		// @FIX 9.2.0: Route article generation through the SAME retry/fallback system the
		// MCQ generation uses (NM_Generation_Service::call_api_with_retry + is_permanent_error),
		// so transient API errors retry with backoff and permanent errors fail fast. This keeps
		// article generation consistent with every other Gemini call in the plugin.
		if ( method_exists( 'NM_Generation_Service', 'call_api_with_retry' ) ) {
			$result = NM_Generation_Service::call_api_with_retry(
				array( $client, 'generate_news_article_from_batch' ),
				array( $articles, $mcqs, array( 'topic' => $topic_hint ) ),
				3
			);
		} else {
			$result = $client->generate_news_article_from_batch( $articles, $mcqs, array( 'topic' => $topic_hint ) );
		}
		if ( empty( $result['success'] ) || empty( $result['data'] ) ) {
			return new WP_Error( 'gen_failed', isset( $result['error'] ) ? $result['error'] : 'Article generation failed.' );
		}

		$data = $result['data'];

		// Pick author.
		$author = self::pick_random_author();

		// Build article content: body + MCQ links + FAQ (for schema) + internal links.
		// @FIX 9.5.2: Related MCQs are rendered via shortcode at view time (published
		// posts only). Batch MCQs are typically still drafts queued for the Scheduler —
		// the old baked pretty-permalinks 404'd until (or unless) they were published.
		$batch_ids = array();
		foreach ( $mcqs as $m ) {
			if ( ! empty( $m['post_id'] ) ) {
				$batch_ids[] = (int) $m['post_id'];
			}
		}
		$content = self::build_content(
			$data,
			$mcqs,
			$batch_ids ? array( 'related_shortcode' => '[nm_related_mcqs ids="' . implode( ',', array_unique( $batch_ids ) ) . '" count="10"]' ) : array()
		);

		// Resolve/ensure the topic term so we can attach it.
		$topic_term_id = 0;
		if ( $topic_hint !== '' ) {
			$term = term_exists( $topic_hint, 'topic' );
			if ( ! $term ) {
				$term = wp_insert_term( $topic_hint, 'topic' );
			}
			if ( ! is_wp_error( $term ) ) {
				$topic_term_id = (int) $term['term_id'];
			}
		}

		// Post status.
		// @FIX 9.3.6 (Scheduler SSOT): When the Scheduler Tab (smart scheduler) is enabled,
		// articles MUST follow its timing workflow (draft + _nm_ready_for_publish), even if
		// "publish immediately" is ticked in the News tab. This mirrors how MCQs are queued
		// by save_mcq_post_unified, so both content types publish on the same human-like
		// schedule.
		$is_smart_schedule = (bool) get_option( 'nm_scheduler_enabled', 0 );
		if ( $is_smart_schedule ) {
			$post_status = 'draft';
		} else {
			$post_status = self::auto_publish_enabled() ? 'publish' : 'draft';
		}

		$post_id = wp_insert_post(
			array(
				'post_type'    => 'post',
				'post_status'  => $post_status,
				'post_title'   => $data['title'],
				'post_name'    => $data['slug'],
				'post_content' => $content,
				'post_excerpt' => $data['excerpt'],
				'post_author'  => $author['user_id'],
			),
			true
		);

		if ( is_wp_error( $post_id ) || empty( $post_id ) ) {
			return is_wp_error( $post_id ) ? $post_id : new WP_Error( 'insert_failed', 'wp_insert_post failed for article.' );
		}

		// If the smart scheduler is active, queue this article for scheduled publishing
		// (mirrors the MCQ smart_schedule path). Otherwise it stays draft (review) or
		// publish (immediate) per the News-tab setting.
		if ( $is_smart_schedule ) {
			update_post_meta( $post_id, '_nm_ready_for_publish', 'yes' );
		}

		// Attach topic term.
		if ( $topic_term_id > 0 ) {
			wp_set_object_terms( $post_id, array( $topic_term_id ), 'topic' );
		}

		// @NEW 9.5.2: File under the "Daily Roundups" category (was: Uncategorized).
		$cat_id = self::ensure_category( 'Daily Roundups', 'daily-roundups' );
		if ( $cat_id ) {
			wp_set_post_categories( $post_id, array( $cat_id ), false );
		}

		// Store metadata.
		update_post_meta( $post_id, '_nm_article_generated', 'yes' );
		update_post_meta( $post_id, '_nm_blocks_converted', 'yes' ); // @NEW 9.5.5: born as blocks
		update_post_meta( $post_id, 'mcq_author_name', sanitize_text_field( $author['display_name'] ) );
		update_post_meta( $post_id, '_nm_article_auto_published', $post_status === 'publish' ? 'yes' : 'no' );
		if ( ! empty( $data['excerpt'] ) ) {
			update_post_meta( $post_id, 'rank_math_description', sanitize_text_field( $data['excerpt'] ) );
			update_post_meta( $post_id, '_yoast_wpseo_metadesc', sanitize_text_field( $data['excerpt'] ) );
		}
		// FAQ for RankMath FAQ schema (and our own fallback JSON-LD).
		if ( ! empty( $data['faq'] ) && is_array( $data['faq'] ) ) {
			update_post_meta( $post_id, '_nm_article_faq', $data['faq'] );
			// RankMath FAQ block data.
			$rm_faq = array();
			foreach ( $data['faq'] as $item ) {
				$rm_faq[] = array(
					'question' => $item['q'],
					'answer'   => $item['a'],
				);
			}
			update_post_meta( $post_id, 'rank_math_faq_block_off', 'off' );
			update_post_meta( $post_id, 'rank_math_faq_block_title', 'Frequently Asked Questions' );
			update_post_meta( $post_id, 'rank_math_faq_block_content', wp_json_encode( $rm_faq ) );
		}

		// Link back the spawned MCQs (store their permalinks for the schema/links).
		$linked_mcq_ids = array();
		foreach ( $mcqs as $m ) {
			if ( ! empty( $m['post_id'] ) ) {
				$linked_mcq_ids[] = (int) $m['post_id'];
			}
		}
		if ( $linked_mcq_ids ) {
			update_post_meta( $post_id, '_nm_article_mcqs', array_unique( $linked_mcq_ids ) );
		}

		// @FIX 9.3.5: Generate a DEDICATED article featured image (Design 2 — Frosted Band,
		// MCQ-matched colors/typography) with the article title + logo/brand + dynamic topic
		// tag + "Read the Full Brief →" CTA. Falls back to the first MCQ's social image only
		// if GD/WebP are unavailable.
		if ( class_exists( 'NM_Social_Image_Generator' ) && method_exists( 'NM_Social_Image_Generator', 'generate_article_image' ) ) {
			$img = NM_Social_Image_Generator::generate_article_image( $post_id );
			if ( empty( $img ) ) {
				self::maybe_set_featured_image( $post_id, $mcqs );
			}
		} else {
			self::maybe_set_featured_image( $post_id, $mcqs );
		}

		return $post_id;
	}

	/**
	 * @FIX 9.4.1: Generate ONE daily current-affairs roundup article covering ALL MCQs
	 * published on a given day, grouped by topic. This replaces the per-batch tiny
	 * "roundups" (which only ever covered 1–2 MCQs) with a true end-of-day roundup.
	 *
	 * @param string $date Y-m-d (default: today).
	 * @return int|WP_Error Post ID on success.
	 */
	public static function generate_daily_roundup( $date = '' ) {
		if ( ! self::is_enabled() ) {
			return new WP_Error( 'article_disabled', 'Article generation is disabled in settings.' );
		}
		if ( $date === '' ) {
			$date = current_time( 'Y-m-d' );
		}

		// Collect that day's published MCQs.
		$mcqs_by_topic = self::collect_mcqs_for_date( $date );
		if ( empty( $mcqs_by_topic ) ) {
			return new WP_Error( 'no_mcqs', 'No MCQs were published on ' . $date . '.' );
		}

		if ( ! class_exists( 'NM_API_Client' ) ) {
			return new WP_Error( 'no_api', 'NM_API_Client unavailable.' );
		}
		$api_key = NM_API_Client::get_gemini_api_key();
		if ( empty( $api_key ) ) {
			return new WP_Error( 'no_key', 'Gemini API key missing.' );
		}

		$client = NM_API_Client::get_instance();
		if ( ! method_exists( $client, 'generate_daily_roundup_from_mcqs' ) ) {
			return new WP_Error( 'no_method', 'Daily roundup method not available in API client.' );
		}

		if ( method_exists( 'NM_Generation_Service', 'call_api_with_retry' ) ) {
			$result = NM_Generation_Service::call_api_with_retry(
				array( $client, 'generate_daily_roundup_from_mcqs' ),
				array( $mcqs_by_topic, $date ),
				3
			);
		} else {
			$result = $client->generate_daily_roundup_from_mcqs( $mcqs_by_topic, $date );
		}
		if ( empty( $result['success'] ) || empty( $result['data'] ) ) {
			return new WP_Error( 'gen_failed', isset( $result['error'] ) ? $result['error'] : 'Daily roundup generation failed.' );
		}
		$data = $result['data'];

		// Flatten all of the day's MCQs (for the related-MCQ links + metadata).
		$all_mcqs = array();
		foreach ( $mcqs_by_topic as $items ) {
			foreach ( $items as $m ) {
				$all_mcqs[] = $m;
			}
		}

		$author  = self::pick_random_author();

		// @FIX 9.5.2: Dynamic related-MCQ shortcode (published posts only at render time).
		$day_ids = array();
		foreach ( $all_mcqs as $m ) {
			if ( ! empty( $m['post_id'] ) ) {
				$day_ids[] = (int) $m['post_id'];
			}
		}
		$content = self::build_content(
			$data,
			$all_mcqs,
			$day_ids ? array( 'related_shortcode' => '[nm_related_mcqs ids="' . implode( ',', array_unique( $day_ids ) ) . '" count="15"]' ) : array()
		);

		// Post status (Scheduler SSOT same as generate_for_batch).
		$is_smart_schedule = (bool) get_option( 'nm_scheduler_enabled', 0 );
		$post_status       = $is_smart_schedule ? 'draft' : ( self::auto_publish_enabled() ? 'publish' : 'draft' );

		$post_id = wp_insert_post(
			array(
				'post_type'    => 'post',
				'post_status'  => $post_status,
				'post_title'   => $data['title'],
				'post_name'    => $data['slug'],
				'post_content' => $content,
				'post_excerpt' => $data['excerpt'],
				'post_author'  => $author['user_id'],
			),
			true
		);

		if ( is_wp_error( $post_id ) || empty( $post_id ) ) {
			return is_wp_error( $post_id ) ? $post_id : new WP_Error( 'insert_failed', 'wp_insert_post failed for daily roundup.' );
		}

		if ( $is_smart_schedule ) {
			update_post_meta( $post_id, '_nm_ready_for_publish', 'yes' );
		}

		// @NEW 9.5.2: File under the "Daily Roundups" category (was: Uncategorized).
		$cat_id = self::ensure_category( 'Daily Roundups', 'daily-roundups' );
		if ( $cat_id ) {
			wp_set_post_categories( $post_id, array( $cat_id ), false );
		}

		// Metadata + FAQ + Rank Math SEO.
		update_post_meta( $post_id, '_nm_article_generated', 'yes' );
		update_post_meta( $post_id, '_nm_blocks_converted', 'yes' ); // @NEW 9.5.5: born as blocks
		update_post_meta( $post_id, '_nm_article_type', 'daily_roundup' );
		update_post_meta( $post_id, '_nm_roundup_date', $date );
		update_post_meta( $post_id, 'mcq_author_name', sanitize_text_field( $author['display_name'] ) );
		update_post_meta( $post_id, '_nm_article_auto_published', $post_status === 'publish' ? 'yes' : 'no' );
		if ( ! empty( $data['excerpt'] ) ) {
			update_post_meta( $post_id, 'rank_math_description', sanitize_text_field( $data['excerpt'] ) );
			update_post_meta( $post_id, '_yoast_wpseo_metadesc', sanitize_text_field( $data['excerpt'] ) );
		}
		if ( ! empty( $data['faq'] ) && is_array( $data['faq'] ) ) {
			update_post_meta( $post_id, '_nm_article_faq', $data['faq'] );
			$rm_faq = array();
			foreach ( $data['faq'] as $item ) {
				if ( ! empty( $item['q'] ) && ! empty( $item['a'] ) ) {
					$rm_faq[] = array( 'question' => $item['q'], 'answer' => $item['a'] );
				}
			}
			if ( $rm_faq ) {
				update_post_meta( $post_id, 'rank_math_faq_block_off', 'off' );
				update_post_meta( $post_id, 'rank_math_faq_block_title', 'Frequently Asked Questions' );
				update_post_meta( $post_id, 'rank_math_faq_block_content', wp_json_encode( $rm_faq ) );
			}
		}

		// Link all of the day's MCQs.
		$linked_ids = array();
		foreach ( $all_mcqs as $m ) {
			if ( ! empty( $m['post_id'] ) ) {
				$linked_ids[] = (int) $m['post_id'];
			}
		}
		if ( $linked_ids ) {
			update_post_meta( $post_id, '_nm_article_mcqs', array_unique( $linked_ids ) );
		}

		// Featured image.
		if ( class_exists( 'NM_Social_Image_Generator' ) && method_exists( 'NM_Social_Image_Generator', 'generate_article_image' ) ) {
			NM_Social_Image_Generator::generate_article_image( $post_id );
		}

		if ( class_exists( 'NM_Generation_Logger' ) ) {
			NM_Generation_Logger::nm_log_activity(
				sprintf( '[DAILY ROUNDUP] Created roundup for %s (post #%d, %d MCQs, author "%s", status=%s).', $date, $post_id, count( $all_mcqs ), $author['display_name'], $post_status ),
				'success'
			);
		}

		return $post_id;
	}

	/**
	 * Collect all MCQs PUBLISHED on a given date, grouped by topic.
	 *
	 * IMPORTANT: MCQs are generated as Drafts and published later by the Scheduler. The
	 * Scheduler's publish path stamps post_date to the actual publish time (see
	 * NMPublicationScheduler::publish_one_from_queue → 'post_date' => current_time).
	 * We therefore filter by post_date on the publish status, so the roundup covers
	 * every MCQ that WENT LIVE that day — NOT every MCQ merely generated that day.
	 *
	 * @param string $date Y-m-d.
	 * @return array [ topic => [ {post_id, question, answer, source_name, topic}, ... ] ]
	 */
	private static function collect_mcqs_for_date( $date ) {
		$query = new WP_Query(
			array(
				'post_type'      => 'mcq',
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'date_query'     => array(
					array(
						'column' => 'post_date', // = publish date (set at publish time by the Scheduler)
						'year'   => (int) substr( $date, 0, 4 ),
						'month'  => (int) substr( $date, 5, 2 ),
						'day'    => (int) substr( $date, 8, 2 ),
					),
				),
			)
		);

		$by_topic = array();
		foreach ( $query->posts as $pid ) {
			$pid       = (int) $pid;
			$answer    = '';
			$ans_code  = get_post_meta( $pid, 'mcq_answer', true );
			$options   = get_post_meta( $pid, 'mcq_options', true );
			if ( is_array( $options ) && isset( $options[ $ans_code ] ) ) {
				$answer = trim( (string) $options[ $ans_code ] );
			} else {
				$answer = trim( (string) $ans_code );
			}

			// Topic: first term.
			$topic = 'Current Affairs';
			$terms = get_the_terms( $pid, 'topic' );
			if ( $terms && ! is_wp_error( $terms ) && ! empty( $terms ) ) {
				$topic = $terms[0]->name;
			}

			$by_topic[ $topic ][] = array(
				'post_id'     => $pid,
				'question'    => get_the_title( $pid ),
				'answer'      => $answer,
				'source_name' => (string) get_post_meta( $pid, 'mcq_source_name', true ),
				'topic'       => $topic,
			);
		}

		return $by_topic;
	}

	/**
	 * Cron handler for the daily roundup. Runs once per day (scheduled in NM_Cron_Manager).
	 * Generates ONE roundup for the previous/current day's MCQs, once per day.
	 */
	public static function run_daily_roundup_cron() {
		if ( ! self::is_enabled() ) {
			return;
		}

		// Only generate ONE roundup per calendar day.
		$today_key = 'nm_daily_roundup_done_' . current_time( 'Y-m-d' );
		if ( get_transient( $today_key ) ) {
			return;
		}

		$result = self::generate_daily_roundup( current_time( 'Y-m-d' ) );
		if ( is_wp_error( $result ) ) {
			if ( class_exists( 'NM_Generation_Logger' ) ) {
				NM_Generation_Logger::nm_log_activity(
					'[DAILY ROUNDUP] Skipped: ' . $result->get_error_message(),
					'info'
				);
			}
			return;
		}

		// Mark done so it doesn't run again today.
		set_transient( $today_key, 1, DAY_IN_SECONDS + 600 );
		if ( class_exists( 'NM_Generation_Logger' ) ) {
			NM_Generation_Logger::nm_log_activity(
				'[DAILY ROUNDUP] Daily roundup cron completed (post #' . $result . ').',
				'success'
			);
		}
	}

	/**
	 * Build the final article HTML: body + a "Related MCQs" section with links +
	 * an FAQ section (mirrors schema).
	 *
	 * @FIX 9.3.4 (robustness):
	 *   - Convert markdown links [text](url) in the model's content to real <a> tags.
	 *   - Strip the model's own in-content FAQ block so we don't end up with a DUPLICATE
	 *     FAQ (we always emit ONE FAQ section + FAQPage schema from $data['faq']).
	 *   - Clean markdown artifacts from related-MCQ question text (the model sometimes
	 *     returns question text with leading "In)" / "In]" style markers).
	 *
	 * @MODIFIED 9.4.0: Made public so NM_Topic_Pillar_Generator can reuse the exact same
	 * content sanitisation (markdown links, FAQ dedupe, related-MCQ links, hub link).
	 */
	public static function build_content( array $data, array $mcqs, array $args = array() ) {
		$body = isset( $data['content'] ) ? trim( $data['content'] ) : '';
		if ( $body === '' ) {
			return '';
		}

		// --- Fix A: Convert markdown links to HTML before sanitizing ---
		// [text](url) -> <a href="url">text</a> (basic, safe; urls validated by wp_kses_post).
		$body = preg_replace_callback(
			'/\[([^\]]+)\]\(\s*(https?:\/\/[^\s\)]+)\s*\)/i',
			function ( $m ) {
				return '<a href="' . esc_url( $m[2] ) . '" rel="noopener" target="_blank">' . esc_html( $m[1] ) . '</a>';
			},
			$body
		);

		// --- Fix B: Strip the model's own in-content FAQ block (duplicate with ours) ---
		// @FIX 9.5.2: Also catches "Common Questions & Answers" (and "Q&A") variants the
		// old prompt requested, which produced a DOUBLE FAQ in published pillars.
		// Removes the heading ... up to the next <h2> (or end), keeping one FAQ below.
		$body = preg_replace(
			'/<h2[^>]*>\s*(?:FAQs?|Frequently Asked Questions|Common Questions\s*(?:&(?:amp;)?|and)?\s*(?:Answers)?|Questions\s*(?:&(?:amp;)?|and)\s*Answers)\s*<\/h2>.*?(?=<h2|$)/is',
			'',
			$body
		);
		// Also drop a lone trailing "FAQ" heading without content.
		$body = preg_replace( '/<h2[^>]*>\s*FAQs?\s*<\/h2>\s*$/is', '', $body );

		// --- Fix C: Strip the model's own "Related/Practice MCQs" section (we emit ours) ---
		$body = preg_replace(
			'/<h2[^>]*>\s*(?:Related|Practice)[^<]*MCQs?\s*<\/h2>.*?(?=<h2|$)/is',
			'',
			$body
		);

		// --- Fix D: Strip the model's own "Explore more … / Browse more …" topic link ---
		// Covers both clean HTML paragraphs and leftover malformed markdown from the model.
		$body = preg_replace(
			'/<p>\s*<a\s+[^>]*href=["\'][^"\']*\/topic\/[^"\']*["\'][^>]*>\s*(?:Explore|Browse|See)\s+more.*?<\/a>.*?<\/p>/is',
			'',
			$body
		);
		$body = preg_replace(
			'/\[(?:Explore|Browse|See)\s+more\](?:\([^)]*\))?[^<\n]{0,80}/is',
			'',
			$body
		);

		// --- @FIX 9.5.2 Fix E: Strip in-content bylines the model sometimes emits ---
		// e.g. "<h2>By TheQuizWire Editorial Team</h2>" or "<p>By John Doe</p>" at the top.
		// Bylines are rendered by the site template, never inside post_content.
		$body = preg_replace( '/<h[23][^>]*>\s*By\s+[^<]{2,80}<\/h[23]>/i', '', $body );
		$body = preg_replace( '/\A\s*<p>\s*By\s+[A-Z][^<]{1,60}<\/p>/', '', $body );

		// Ensure the body HTML is safe-ish (allow headings/paragraphs/lists/links).
		$body = wp_kses_post( $body );

		// --- @FIX 9.5.2 Fix F: Balance the HTML ---
		// wp_kses_post() sanitizes but does NOT balance tags; stray closing </p> tags
		// from the model were reaching published posts.
		if ( function_exists( 'force_balance_tags' ) ) {
			$body = force_balance_tags( $body );
		}

		// --- Related MCQs ---
		// @FIX 9.5.2: Prefer a DYNAMIC shortcode (resolved at render time against
		// published MCQs only) over baked <a> links. Baked links went stale and could
		// 404 (the roundup path used to bake pretty permalinks to still-draft MCQs).
		$related_html = '';
		if ( ! empty( $args['related_shortcode'] ) && is_string( $args['related_shortcode'] ) ) {
			$related_html = $args['related_shortcode'];
		} elseif ( ! empty( $mcqs ) ) {
			// Fallback: bake links, but ONLY to already-published MCQs.
			$links = array();
			foreach ( array_slice( $mcqs, 0, 10 ) as $m ) {
				$pid = isset( $m['post_id'] ) ? (int) $m['post_id'] : 0;
				if ( ! $pid || get_post_status( $pid ) !== 'publish' ) {
					continue;
				}
				$url = self::get_mcq_permalink( $pid );
				if ( ! $url ) {
					continue;
				}
				$q = isset( $m['question'] ) ? $m['question'] : get_the_title( $pid );
				$links[] = '<li><a href="' . esc_url( $url ) . '">' . esc_html( self::clean_mcq_question( $q ) ) . '</a></li>';
			}
			if ( $links ) {
				$related_html = '<h2>Related Practice MCQs</h2><p>Test yourself on these related questions:</p><ul>' . implode( "\n", $links ) . '</ul>';
			}
		}

		// --- FAQ section (from data) - matches FAQ schema. Single source of truth. ---
		$faq_html = '';
		if ( ! empty( $data['faq'] ) && is_array( $data['faq'] ) ) {
			$items = '';
			foreach ( $data['faq'] as $item ) {
				if ( empty( $item['q'] ) || empty( $item['a'] ) ) {
					continue;
				}
				$items .= '<h3>' . esc_html( $item['q'] ) . '</h3><p>' . esc_html( $item['a'] ) . '</p>';
			}
			if ( $items ) {
				$faq_html = '<h2>Frequently Asked Questions</h2>' . $items;
			}
		}

		// --- Topic hub CTA ---
		// @FIX 9.5.3: Moved from the very END of the page (after the FAQ, where nobody
		// scrolls) to directly AFTER the Related MCQs block, and upgraded from a bare
		// topic-name link to a real call-to-action: "Read the latest {Topic} MCQs Now →".
		// The pillar path passes the topic explicitly via $args['topic_term_id'] so the
		// CTA renders even when the $mcqs list is empty.
		$topic_hub_link = '';
		$cta_term       = null;

		if ( ! empty( $args['topic_term_id'] ) ) {
			$t = get_term( (int) $args['topic_term_id'], 'topic' );
			if ( $t && ! is_wp_error( $t ) ) {
				$cta_term = $t;
			}
		}
		if ( ! $cta_term ) {
			// Fallback: derive from the batch MCQs (most common topic name).
			$topic_counts = array();
			foreach ( $mcqs as $m ) {
				if ( ! empty( $m['topic'] ) ) {
					$topic_counts[ $m['topic'] ] = ( $topic_counts[ $m['topic'] ] ?? 0 ) + 1;
				}
			}
			if ( $topic_counts ) {
				arsort( $topic_counts );
				$term = get_term_by( 'name', (string) key( $topic_counts ), 'topic' );
				if ( $term && ! is_wp_error( $term ) ) {
					$cta_term = $term;
				}
			}
		}
		if ( $cta_term ) {
			$hub_url = get_term_link( $cta_term );
			if ( $hub_url && ! is_wp_error( $hub_url ) ) {
				$topic_hub_link = '<p class="nm-topic-cta"><a href="' . esc_url( $hub_url ) . '">'
					. '<strong>Read the latest ' . esc_html( $cta_term->name ) . ' MCQs Now &rarr;</strong></a></p>';
			}
		}

		// @FIX 9.5.3: CTA sits right under the Related MCQs block (high-visibility slot);
		// the FAQ closes the page for schema completeness.
		$assembled = $body . "\n\n" . $related_html . "\n\n" . $topic_hub_link . "\n\n" . $faq_html;

		// @NEW 9.5.4: Emit Gutenberg BLOCK markup instead of raw/classic HTML, so
		// generated posts open as native blocks (heading/paragraph/list/shortcode)
		// in the editor rather than one legacy "Classic" blob.
		return self::convert_html_to_blocks( $assembled );
	}

	/**
	 * @NEW 9.5.4: Convert sanitized flat HTML into Gutenberg block markup.
	 *
	 * Strict, validity-first strategy — only element shapes whose block save-output we
	 * can reproduce EXACTLY are converted to native core blocks:
	 *   - <h1>–<h6> (no attributes)        → core/heading
	 *   - <p> (no attrs, or class only)    → core/paragraph (class → "className")
	 *   - <ul>/<ol> with plain <li>s       → core/list + core/list-item
	 *   - bare [shortcode]                 → core/shortcode
	 * Anything else (inline styles, divs, tables, nested lists, unknown tags) is
	 * wrapped in a core/html (Custom HTML) block — still a valid block, never an
	 * "invalid content" warning, and no content is ever dropped. Stray text runs
	 * between elements become paragraphs.
	 *
	 * Already-converted content (containing "<!-- wp:") is passed through untouched.
	 *
	 * @param string $html Flat HTML.
	 * @return string Gutenberg block markup.
	 */
	public static function convert_html_to_blocks( $html ) {
		$html = trim( (string) $html );
		if ( $html === '' ) {
			return '';
		}
		if ( strpos( $html, '<!-- wp:' ) !== false ) {
			return $html; // already block markup
		}

		$blocks  = array();
		$pattern = '/<(h[1-6]|p|ul|ol)\b([^>]*)>(.*?)<\/\1>|\[[a-zA-Z][a-zA-Z0-9_-]*(?:\s[^\]]*)?\]/is';
		$offset  = 0;

		if ( preg_match_all( $pattern, $html, $matches, PREG_OFFSET_CAPTURE | PREG_SET_ORDER ) ) {
			foreach ( $matches as $m ) {
				$full  = $m[0][0];
				$start = $m[0][1];

				// Text/markup BETWEEN recognized elements.
				if ( $start > $offset ) {
					$between = trim( substr( $html, $offset, $start - $offset ) );
					if ( $between !== '' ) {
						$blocks[] = self::stray_chunk_to_block( $between );
					}
				}
				$offset = $start + strlen( $full );

				// Bare shortcode → core/shortcode.
				if ( ! isset( $m[1] ) || $m[1][0] === '' ) {
					$blocks[] = "<!-- wp:shortcode -->\n" . $full . "\n<!-- /wp:shortcode -->";
					continue;
				}

				$tag   = strtolower( $m[1][0] );
				$attrs = trim( $m[2][0] );
				$inner = $m[3][0];

				$blocks[] = self::element_to_block( $tag, $attrs, $inner, $full );
			}
		}

		// Trailing chunk after the last recognized element.
		if ( $offset < strlen( $html ) ) {
			$tail = trim( substr( $html, $offset ) );
			if ( $tail !== '' ) {
				$blocks[] = self::stray_chunk_to_block( $tail );
			}
		}

		if ( empty( $blocks ) ) {
			return "<!-- wp:html -->\n" . $html . "\n<!-- /wp:html -->";
		}

		return implode( "\n\n", $blocks );
	}

	/**
	 * Map one recognized top-level element to a core block (or core/html fallback).
	 */
	private static function element_to_block( $tag, $attrs, $inner, $full ) {
		// Any inline style / id / data attrs → Custom HTML (guaranteed valid).
		$has_style = stripos( $attrs, 'style=' ) !== false;

		// Headings: only attribute-free headings map cleanly.
		if ( $tag[0] === 'h' && strlen( $tag ) === 2 ) {
			if ( $attrs !== '' ) {
				return "<!-- wp:html -->\n" . $full . "\n<!-- /wp:html -->";
			}
			$level = (int) $tag[1];
			$json  = $level === 2 ? '' : ' {"level":' . $level . '}';
			return '<!-- wp:heading' . $json . " -->\n<{$tag} class=\"wp-block-heading\">" . $inner . "</{$tag}>\n<!-- /wp:heading -->";
		}

		if ( $tag === 'p' ) {
			if ( $attrs === '' ) {
				return "<!-- wp:paragraph -->\n<p>" . $inner . "</p>\n<!-- /wp:paragraph -->";
			}
			// class-only paragraphs (e.g. nm-topic-cta) → className attribute.
			if ( ! $has_style && preg_match( '/^class=(["\'])([^"\']*)\1$/i', $attrs, $cm ) ) {
				return '<!-- wp:paragraph {"className":' . wp_json_encode( $cm[2] ) . "} -->\n<p class=\"" . esc_attr( $cm[2] ) . '">' . $inner . "</p>\n<!-- /wp:paragraph -->";
			}
			return "<!-- wp:html -->\n" . $full . "\n<!-- /wp:html -->";
		}

		if ( $tag === 'ul' || $tag === 'ol' ) {
			// Nested lists / styled lists / attributed <li>s → Custom HTML.
			if ( $attrs !== '' || preg_match( '/<(ul|ol)\b/i', $inner ) || preg_match( '/<li\s[^>]*>/i', $inner ) ) {
				return "<!-- wp:html -->\n" . $full . "\n<!-- /wp:html -->";
			}
			if ( ! preg_match_all( '/<li>(.*?)<\/li>/is', $inner, $items ) ) {
				return "<!-- wp:html -->\n" . $full . "\n<!-- /wp:html -->";
			}
			$li_blocks = array();
			foreach ( $items[1] as $li ) {
				$li_blocks[] = "<!-- wp:list-item -->\n<li>" . trim( $li ) . "</li>\n<!-- /wp:list-item -->";
			}
			$json = $tag === 'ol' ? ' {"ordered":true}' : '';
			return '<!-- wp:list' . $json . " -->\n<{$tag} class=\"wp-block-list\">" . implode( "\n", $li_blocks ) . "</{$tag}>\n<!-- /wp:list -->";
		}

		return "<!-- wp:html -->\n" . $full . "\n<!-- /wp:html -->";
	}

	/**
	 * Wrap a stray chunk (text or unrecognized markup between elements) in a block.
	 */
	private static function stray_chunk_to_block( $chunk ) {
		if ( strpos( $chunk, '<' ) === false ) {
			// Pure text → paragraph.
			return "<!-- wp:paragraph -->\n<p>" . $chunk . "</p>\n<!-- /wp:paragraph -->";
		}
		return "<!-- wp:html -->\n" . $chunk . "\n<!-- /wp:html -->";
	}

	/**
	 * @NEW 9.5.5: Convert ONE batch of previously generated posts (pillars, roundups,
	 * PDF archive pages) from classic HTML to Gutenberg block markup.
	 *
	 * Idempotent and resumable: every processed post is stamped with
	 * `_nm_blocks_converted`, so re-running (or resuming after a timeout) only touches
	 * the remainder. Posts already in block markup are stamped and skipped unchanged.
	 *
	 * @param int $batch_size Posts per batch (1–100).
	 * @return array { processed, converted, skipped, remaining, done }
	 */
	public static function convert_existing_posts_batch( $batch_size = 25 ) {
		$batch_size = max( 1, min( 100, (int) $batch_size ) );

		$q = new WP_Query(
			array(
				'post_type'      => array( 'post', 'page' ),
				'post_status'    => array( 'publish', 'draft', 'pending', 'private', 'future' ),
				'posts_per_page' => $batch_size,
				'fields'         => 'ids',
				'orderby'        => 'ID',
				'order'          => 'ASC',
				'no_found_rows'  => false, // accurate found_posts = total still unconverted
				'meta_query'     => array(
					'relation' => 'AND',
					array(
						'key'     => '_nm_blocks_converted',
						'compare' => 'NOT EXISTS',
					),
					array(
						'relation' => 'OR',
						array( 'key' => '_nm_article_generated', 'value' => 'yes' ),
						array( 'key' => '_nm_pillar_generated', 'value' => 'yes' ),
						array( 'key' => '_nm_pdf_topic_term_id', 'compare' => 'EXISTS' ),
					),
				),
			)
		);

		$total     = (int) $q->found_posts;
		$converted = 0;
		$skipped   = 0;

		foreach ( $q->posts as $pid ) {
			$pid     = (int) $pid;
			$content = (string) get_post_field( 'post_content', $pid );

			if ( trim( $content ) !== '' && strpos( $content, '<!-- wp:' ) === false ) {
				$new = self::convert_html_to_blocks( $content );
				if ( $new !== $content ) {
					wp_update_post(
						array(
							'ID'           => $pid,
							'post_content' => $new,
						)
					);
					$converted++;
				} else {
					$skipped++;
				}
			} else {
				$skipped++; // empty or already block markup
			}

			update_post_meta( $pid, '_nm_blocks_converted', 'yes' );

			if ( function_exists( 'clean_post_cache' ) ) {
				clean_post_cache( $pid );
			}
		}

		$processed = count( $q->posts );

		return array(
			'processed' => $processed,
			'converted' => $converted,
			'skipped'   => $skipped,
			'remaining' => max( 0, $total - $processed ),
			'done'      => ( $total - $processed ) <= 0,
		);
	}

	/**
	 * @FIX 9.4.1: Get a clean permalink for an MCQ, using the pretty /mcq/slug/ form even
	 * for drafts (get_permalink() returns "?post_type=mcq&p=ID" for non-published posts).
	 */
	private static function get_mcq_permalink( $post_id ) {
		$post = get_post( (int) $post_id );
		if ( ! $post || $post->post_type !== 'mcq' ) {
			return '';
		}
		$url = get_permalink( $post_id );
		if ( $url && strpos( $url, '?post_type=' ) === false ) {
			return $url;
		}
		// Draft / non-pretty fallback: build from the rewrite slug + post_name.
		$slug = trim( (string) $post->post_name );
		if ( $slug === '' ) {
			return '';
		}
		return home_url( '/mcq/' . $slug . '/' );
	}

	/**
	 * @FIX 9.3.4: Clean an MCQ question string for display in links/lists.
	 * Strips leading "In)" / "In]" / "A." style markers and leftover markdown/HTML that
	 * the model sometimes prepends (the "Related Practice MCQs" anchor was garbled).
	 */
	private static function clean_mcq_question( $question ) {
		$q = trim( (string) $question );
		// Remove leading markers like "In)", "In]", "A)", "1." , "(In)" etc.
		$q = preg_replace( '/^(\s*[\[\(]?\s*(In|Option)\s*[\]\)]\s*:?\s*|\s*[\[\(]?\s*[A-D1-9]\s*[\]\)\.]\s*)+/i', '', $q );
		// Strip any leftover markdown or HTML tags.
		$q = preg_replace( '/\[|\]|\(|\)/', ' ', $q );
		// Strip stray URLs (the model sometimes embeds ?post_type=mcq&p= links in text).
		$q = preg_replace( '#https?://[^\s]+#i', '', $q );
		$q = wp_strip_all_tags( $q );
		$q = preg_replace( '/\s{2,}/', ' ', $q );
		return trim( $q );
	}

	/**
	 * Extract a YouTube video ID from a youtube.com / youtu.be / shorts URL.
	 */
	private static function extract_youtube_id( $url ) {
		$url = trim( (string) $url );
		if ( $url === '' ) {
			return '';
		}
		// /shorts/<id>
		if ( preg_match( '#youtube\.com/shorts/([A-Za-z0-9_-]{6,})#', $url, $m ) ) {
			return $m[1];
		}
		// youtu.be/<id>
		if ( preg_match( '#youtu\.be/([A-Za-z0-9_-]{6,})#', $url, $m ) ) {
			return $m[1];
		}
		// v=<id> or /watch?v=<id>
		if ( preg_match( '#[?&]v=([A-Za-z0-9_-]{6,})#', $url, $m ) ) {
			return $m[1];
		}
		return '';
	}

	/**
	 * Reuse the first MCQ's generated social image as the article featured image.
	 */
	private static function maybe_set_featured_image( $post_id, array $mcqs ) {
		if ( get_post_thumbnail_id( $post_id ) ) {
			return;
		}
		foreach ( $mcqs as $m ) {
			if ( empty( $m['post_id'] ) ) {
				continue;
			}
			$thumb_id = get_post_thumbnail_id( (int) $m['post_id'] );
			if ( $thumb_id ) {
				set_post_thumbnail( $post_id, $thumb_id );
				return;
			}
		}
	}

	/**
	 * Get a "real author vibe" avatar for a user.
	 *
	 * Priority:
	 *   1. A locally uploaded avatar (user meta `nm_local_avatar_url`) — set via the
	 *      author management screen or any local-avatar plugin.
	 *   2. Gravatar from the user's email (auto — just give each author an email with
	 *      a Gravatar and it "just works").
	 *   3. A generated initials avatar (SVG data URI) as a clean fallback.
	 *
	 * @param int $user_id
	 * @param int $size
	 * @return string URL.
	 */
	public static function get_author_avatar_url( $user_id = 0, $size = 80 ) {
		$user_id = absint( $user_id );
		$size    = max( 20, absint( $size ) );
		$email   = '';
		$name    = '';

		if ( $user_id > 0 ) {
			$u     = get_userdata( $user_id );
			$email = $u ? $u->user_email : '';
			$name  = $u ? $u->display_name : '';
		}

		// 1) Local avatar (optional, user meta override).
		$local = $user_id ? get_user_meta( $user_id, 'nm_local_avatar_url', true ) : '';
		if ( $local ) {
			return set_url_scheme( $local );
		}

		// 2) Gravatar (auto from email). `d=mp` = mystery-person fallback.
		if ( is_email( $email ) ) {
			$hash = md5( strtolower( trim( $email ) ) );
			return 'https://www.gravatar.com/avatar/' . $hash . '?s=' . $size . '&d=mp&r=g';
		}

		// 3) Initials avatar (self-contained SVG data URI).
		return self::initials_avatar_url( $name, $size );
	}

	/**
	 * Generate a clean initials avatar as an SVG data URI (no external service).
	 */
	public static function initials_avatar_url( $name = '', $size = 80 ) {
		$initials = '';
		$name     = trim( (string) $name );
		if ( $name !== '' ) {
			$parts = preg_split( '/\s+/', $name );
			if ( count( $parts ) >= 2 ) {
				$initials = mb_strtoupper( mb_substr( $parts[0], 0, 1 ) . mb_substr( end( $parts ), 0, 1 ) );
			} else {
				$initials = mb_strtoupper( mb_substr( $parts[0], 0, 2 ) );
			}
		}
		if ( $initials === '' ) {
			$initials = '?';
		}

		// Pick a stable background hue from the initials.
		$hue = ( abs( crc32( $initials ) ) % 360 );
		$bg  = 'hsl(' . $hue . ', 60%, 42%)';

		$svg = '<svg xmlns="http://www.w3.org/2000/svg" width="' . $size . '" height="' . $size . '" viewBox="0 0 100 100">'
			. '<rect width="100" height="100" rx="50" fill="' . esc_attr( $bg ) . '"/>'
			. '<text x="50" y="50" dy="0.35em" font-family="Arial, sans-serif" font-size="40" font-weight="bold" fill="#ffffff" text-anchor="middle">'
			. esc_html( $initials ) . '</text></svg>';
		return 'data:image/svg+xml;charset=utf-8,' . rawurlencode( $svg );
	}

	/**
	 * Inject an Article/NewsArticle + FAQ schema via Rank Math's json_ld filter when
	 * Rank Math is active. Falls back to emitting our own JSON-LD in wp_head if not.
	 */
	public function inject_article_schema( $data, $jsonld ) {
		if ( ! is_singular( 'post' ) || ! get_post_meta( get_the_ID(), '_nm_article_generated', true ) ) {
			return $data;
		}

		$post_id = get_the_ID();
		$author  = get_post_meta( $post_id, 'mcq_author_name', true ) ?: get_the_author();
		$source  = '';
		$mcq_ids = get_post_meta( $post_id, '_nm_article_mcqs', true );

		// Prefer Article; if Rank Math already set one, leave it (avoid duplicate type).
		if ( isset( $data['Article'] ) ) {
			$data['Article']['author'] = array(
				'@type' => 'Person',
				'name'  => $author,
			);
		} else {
			$data['Article'] = array(
				'@type'            => 'Article',
				'@id'              => get_permalink( $post_id ) . '#article',
				'headline'         => get_the_title( $post_id ),
				'description'      => get_the_excerpt( $post_id ),
				'datePublished'    => get_the_date( 'c', $post_id ),
				'dateModified'     => get_the_modified_date( 'c', $post_id ),
				'author'           => array( '@type' => 'Person', 'name' => $author ),
				'publisher'        => array( '@type' => 'Organization', 'name' => get_bloginfo( 'name' ) ),
				'mainEntityOfPage' => get_permalink( $post_id ),
			);
		}

		// FAQPage schema from stored FAQ.
		$faq = get_post_meta( $post_id, '_nm_article_faq', true );
		if ( is_array( $faq ) && ! empty( $faq ) ) {
			$faq_entries = array();
			foreach ( $faq as $item ) {
				if ( empty( $item['q'] ) || empty( $item['a'] ) ) {
					continue;
				}
				$faq_entries[] = array(
					'@type'          => 'Question',
					'name'           => $item['q'],
					'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $item['a'] ),
				);
			}
			if ( $faq_entries ) {
				$data['FAQPage'] = array(
					'@type' => 'FAQPage',
					'mainEntity' => $faq_entries,
				);
			}
		}

		return $data;
	}
}
