<?php

/**
 * AJAX Handler for Studio Assets and TTS Settings
 *
 * @package MCQ_Video_Studio
 */

if (! defined('ABSPATH')) {
    exit;
}

class VS_AJAX_Asset_Handler
{

    private static $instance = null;

    public static function get_instance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * AJAX: Save Studio Assets to User Meta
     */
    public function ajax_save_studio_assets()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        $assets_raw = isset($_POST['assets']) ? wp_unslash($_POST['assets']) : '[]';
        $assets_decoded = json_decode($assets_raw, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            VS_Error_Logger::get_instance()->log('Asset Library: Invalid JSON', 'error', array('error' => json_last_error_msg()));
            wp_send_json_error('Invalid JSON format');
        }

        $assets_clean = wp_json_encode($assets_decoded);
        update_user_meta(get_current_user_id(), 'MCQVS_studio_asset_library', $assets_clean);

        wp_send_json_success(array('message' => 'Assets saved to cloud'));
    }

    /**
     * AJAX: Get Studio Assets from User Meta
     */
    public function ajax_get_studio_assets()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        $assets = get_user_meta(get_current_user_id(), 'MCQVS_studio_asset_library', true);
        wp_send_json_success(array('assets' => $assets ?: '[]'));
    }

    /**
     * AJAX: Save TTS Settings
     */
    public function ajax_save_tts_settings()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        // Backward compatible input keys (legacy controller vs modular UI)
        $provider       = sanitize_text_field($_POST['provider'] ?? ($_POST['tts_provider'] ?? ''));
        $google_key     = sanitize_text_field($_POST['googleKey'] ?? ($_POST['google_cloud_tts_key'] ?? ''));
        $azure_key      = sanitize_text_field($_POST['azureKey'] ?? ($_POST['azure_tts_key'] ?? ''));
        $azure_region   = sanitize_text_field($_POST['azureRegion'] ?? ($_POST['azure_tts_region'] ?? ''));

        $elevenlabs_key = sanitize_text_field($_POST['elevenlabsKey'] ?? ($_POST['elevenlabs_api_key'] ?? ''));

        update_option('MCQVS_video_studio_tts_provider', $provider);
        update_option('mcqvs_tts_provider', $provider);
        update_option('mcqvs_google_cloud_tts_key', $google_key);
        update_option('mcqvs_azure_tts_key', $azure_key);
        update_option('mcqvs_azure_tts_region', $azure_region);
        update_option('mcqvs_elevenlabs_api_key', $elevenlabs_key);

        wp_send_json_success(array('message' => 'Settings saved successfully'));
    }
}
