<?php

/**
 * MCQ Video Studio
 *
 * Companion plugin for News MCQ Generator - generates quiz videos with automation.
 *
 * @package     MCQ_Video_Studio
 * @version 1.4.9.2
 * @since       1.0.0
 *
 * @wordpress-plugin
 * Plugin Name: MCQ Video Studio
 * Plugin URI:  https://applehowtotips.com
 * Description: Generate quiz videos from MCQ Plugin questions with automation and social uploads
 * Version: 1.5.2
 * @MODIFIED 2026-07-31: drawCover() layout parity — preview/export now matches cover editor exactly
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Author:      MCP Developers
 * Author URI:  https://applehowtotips.com
 * License:     GPL-2.0+
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain: mcq-video-studio
 * Domain Path: /languages
 */

if (! defined('ABSPATH')) {
	exit;
}

// Prevent loading if already loaded (for when moved outside MCQ Plugin folder)
if (defined('MCQVS_VERSION')) {
	return;
}

define('MCQVS_VERSION', '1.5.2');
// @NEW 2026-02-02: Debug flag for cache-busting (set to false for production)
define('MCQVS_DEV_MODE', defined('WP_DEBUG') && WP_DEBUG);
// @NEW 2026-02-03: Active flag for Modular Studio Architecture
define('MCQVS_USE_MODULAR_STUDIO', true);
define('MCQVS_PLUGIN_FILE', __FILE__);
define('MCQVS_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('MCQVS_PLUGIN_URL', plugin_dir_url(__FILE__));

/**
 * Get URL to assets root (external if configured, else plugin's built-in assets).
 *
 * @param string $path Optional sub-path to append (e.g. 'fonts/Inter-Bold.ttf').
 * @return string Absolute URL.
 */
function mcqvs_assets_url( $path = '' ) {
    $external = get_option( 'mcqvs_external_assets_url', '' );
    if ( ! empty( $external ) ) {
        $base = trailingslashit( $external );
        if ( '' === $path ) {
            return $base;
        }
        return $base . ltrim( $path, '/' );
    }
    return MCQVS_PLUGIN_URL . 'assets/' . ltrim( $path, '/' );
}

/**
 * Get filesystem path to assets root (external if configured, else plugin's built-in assets).
 *
 * @param string $path Optional sub-path to append.
 * @return string Filesystem path.
 */
function mcqvs_assets_dir( $path = '' ) {
    $external = get_option( 'mcqvs_external_assets_path', '' );
    $base = ! empty( $external ) ? trailingslashit( $external ) : MCQVS_PLUGIN_DIR . 'assets/';
    if ( '' === $path ) {
        return $base;
    }
    return $base . ltrim( $path, '/' );
}

// @NEW 2026-02-09: Action Scheduler is now a required external dependency.
 // The plugin expects WooCommerce Action Scheduler (or standalone AS plugin) to be active.
 // If not available, an admin notice will be shown and scheduling features will be disabled.

/**
 * Initialize Video Studio after MCQ Plugin is loaded.
 *
 * @since 1.0.0
 */
function mcqvs_init()
{
	if (!get_option('mcqvs_did_init_log')) {
		error_log('MCQVS: Initializing plugin...');
		update_option('mcqvs_did_init_log', '1', 'no');
	}

	// @NEW 2026-04: Load Schema Definitions FIRST (before any repository uses it)
	require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-schema.php';

	// @NEW 2026-06-26: Provider Registry (loaded BEFORE any AI handler uses get_working_model/get_api_key)
	require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-provider-registry.php';

	// @NEW 2026-01-09: Central Error Logging (required by Core)
	require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-error-logger.php';
	require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-log-viewer.php';

	// NEW: Load Content Planner EARLY (for proper page rendering)
	require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-content-planner.php';

	// Excel/CSV Importer for Content Planner
	require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-excel-importer.php';

	// Load Handlers BEFORE Core (Core constructor needs them)
	require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-ajax-studio-handler.php';
	require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-ajax-ai-quiz-handler.php';
	require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-ajax-tts-handler.php';
	require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-ajax-ai-tools-handler.php';
	require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-ajax-asset-handler.php';
	require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-ajax-stock-handler.php';
	require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-ajax-batch-handler.php';
	require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-ajax-branding-handler.php';
  require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-ajax-video-url-handler.php';

 // Load Core (handlers are now available)
	require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-core.php';
	require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-artifact-cleanup.php';

	// Load Phase 2: Automation & API
	require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-api-client.php';

	// @NEW 2026-02-09: Migration Tool
	require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-migrator.php';
	VS_Migrator::init();

	// @NEW 2026-08-13 (Phase 4): Full Auto-Video Scheduler system.
	require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-video-scheduler.php';
	VS_Video_Scheduler::init();

require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-job-repository.php';
	require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-automation-engine.php';
	require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-buffer-client.php';
	// @FIX 2026-07-31: Invalidate cached Buffer org/channels whenever the access
	//   token is saved, so a different account never reuses stale cache.
	// @FIX 2026-08-01 (multi-account): Also run legacy migration to keep the
	//   synthetic 'default' account in sync when the legacy token changes.
	add_action('update_option_mcqvs_buffer_access_token', array('VS_Buffer_Client', 'clear_channels_cache'), 10, 3);
	add_action('add_option_mcqvs_buffer_access_token', array('VS_Buffer_Client', 'clear_channels_cache'), 10, 2);
	add_action('update_option_mcqvs_buffer_access_token', array('VS_Buffer_Account_Registry', 'ensure_legacy_migrated'), 10, 3);
	add_action('add_option_mcqvs_buffer_access_token', array('VS_Buffer_Account_Registry', 'ensure_legacy_migrated'), 10, 2);

	// @FIX 2026-08-08: Buffer accounts are managed exclusively via AJAX. The Settings
	// form must NEVER be able to empty/overwrite them (a stale hidden snapshot or any
	// rogue write would otherwise wipe every account on a routine "Save Settings").
	add_filter('pre_update_option_mcqvs_buffer_accounts', 'mcqvs_buffer_accounts_protect', 10, 2);
	function mcqvs_buffer_accounts_protect($value, $old_value)
	{
		$decoded     = is_string($value) ? json_decode($value, true) : $value;
		$old_decoded = is_string($old_value) ? json_decode($old_value, true) : $old_value;
		$is_empty    = !is_array($decoded) || empty($decoded);
		$old_has_data = is_array($old_decoded) && !empty($old_decoded);
		if ($is_empty && $old_has_data) {
			return $old_value;
		}
		return $value;
	}
	require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-r2-storage.php';

// @NEW 2026-04-22: Headless Renderer for autonomous server-side video rendering
require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-headless-renderer.php';

// @FIX 2026-07-17: Behind Cloudflare (confirmed: cdn-cgi/zaraz + cloudflareinsights in
//   render page-diag), PHP receives HTTP on the origin so is_ssl() returns false even
//   though admin URLs are minted with 'https'. That scheme mismatch makes the headless
//   auth path emit a non-secure AUTH_COOKIE while wp-login.php expects SECURE_AUTH_COOKIE,
//   re-triggering the wp-login.php?...&reauth=1 loop. Honor the proxy protocol header so
//   is_ssl() is correct for the render pipeline (and the rest of admin).
if (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && 'https' === strtolower($_SERVER['HTTP_X_FORWARDED_PROTO'])) {
	$_SERVER['HTTPS'] = 'on';
}

// @NEW 2026-07-18 (server-side render): The browser-free Node renderer (render-node.js)
//   is the only render path. It does not use Chromium/Playwright and never touches
//   admin-ajax or WP nonces, so no cookie/session-token auth hooks are registered.
//   The legacy Chromium/Playwright path (render.js) has been removed as dead bloat.

// @NEW 2026-01-10: Project Repository for DB-stored projects
	require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-project-repository.php';

	// @NEW 2026-02-08: Bulk Scheduler for Content Calendar
	require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-bulk-scheduler.php';

	// Load Phase 3: Settings UI
	require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-settings.php';

	// @MODIFIED 2026-01-06: Load comprehensive smoke test system
	require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-smoke-test.php';

	// @NEW 2026-02-02: Installer for table creation
	require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-installer.php';

	// Version Check & Table Creation (Self-healing for embedded mode)
	// Output buffering for table creation
	$needs_install = (get_option('mcqvs_version') !== MCQVS_VERSION);

	// @FIX 2026-07-06: Also create tables if wp_vs_logs doesn't exist yet.
	// The old version check only compared MCQVS_VERSION (1.4.9.1), so installs
	// that were already on 1.4.9.1 never ran VS_Installer::install() and never
	// got the wp_vs_logs table. Self-heal by detecting the missing table.
	if (!$needs_install) {
		global $wpdb;
		$logs_table = $wpdb->prefix . 'vs_logs';
		if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $logs_table)) !== $logs_table) {
			$needs_install = true;
		}
	}

  if ($needs_install) {
    // @FIX 1.4.9.41 (data-loss): snapshot user data BEFORE the version change
    // runs, so `mcqvs_safety_backup` always holds the previous install's data
    // (survives even the delete-folder ZIP update flow).
    mcqvs_backup_user_data(get_option('mcqvs_version'));
    // @FIX: VS_Installer::install() is the single source of truth for all plugin tables.
    // Removed VS_Job_Repository::create_table() and VS_Project_Repository::create_tables()
    // because both were unconditional precursors that ran dbDelta before VS_Installer ran
    // dbDelta again — causing "Multiple primary key defined" on every re-activation.
    ob_start();
    VS_Installer::install();
    ob_end_clean();
    update_option('mcqvs_version', MCQVS_VERSION);
  }

	// @NEW 2026-07-19: Auto-install render-service npm deps (canvas+ws) so
	//                    plugin deploys no longer require manual `npm install`.
	VS_Installer::maybe_install_render_deps();

	// Init Classes
	VS_Core::init();
	VS_API_Client::init();
	VS_Job_Repository::init();
	VS_Automation_Engine::init();
	VS_Artifact_Cleanup::init();
	VS_Settings::init();

	// @MODIFIED 2026-01-06: Initialize comprehensive smoke test system
	VS_Smoke_Test::init();

	// @NEW 202 6-02-08: Initialize Bulk Scheduler (registers Action Scheduler hooks)
	VS_Bulk_Scheduler::init();

	// Signal that Video Studio is fully initialized
	do_action('mcqvs_studio_loaded');
}
// Primary sync hook
// Primary sync hook
add_action('mcqvs_init_sync', 'mcqvs_init', 10);
// Fallback for legacy MCQ Plugin handshake
add_action('nm_mcq_plugin_loaded', 'mcqvs_init', 10);

// @MODIFIED 2026-02-18: Independent Initialization Fallback
add_action('plugins_loaded', function () {
	if (!did_action('mcqvs_init_sync') && !did_action('nm_mcq_plugin_loaded')) {
		mcqvs_init();
	}
}, 20);

// Smoke test loading removed (file was missing and causing fatal errors)

// ============================================================
// @NEW 2026-01-10: Scoped COOP/COEP Headers for SharedArrayBuffer
// Only applies to Video Studio admin page - not site-wide
// Required for FFmpeg.wasm multi-threaded mode
// ============================================================
add_action('admin_init', 'mcqvs_add_isolation_headers', 1);

/**
 * Add Cross-Origin isolation headers on Video Studio page only.
 * 
 * This enables SharedArrayBuffer which is required for FFmpeg.wasm
 * multi-threaded mode. Headers are scoped to prevent breaking
 * other admin pages, embeds, and third-party integrations.
 *
 * @since 1.2.0
 */
function mcqvs_add_isolation_headers()
{
 // Only apply on our specific admin pages that need SharedArrayBuffer
 // @FIX: Removed 'mcqvs-self-test' (not a registered page slug); added 'mcqvs-content-planner'
 // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$page = isset($_GET['page']) ? sanitize_key($_GET['page']) : '';
	// @FIX (audit): `mcqvs-render` is the headless render-runner page. It relies on
	//        WebCodecs + a Web Worker (vs-render-worker.js) which require cross-origin
	//        isolation (SharedArrayBuffer). Without COOP/COEP headers the page can never
	//        enter isolation, so ExportManager.spawnWorker() never initializes and
	//        `window.__MCQVSRenderRunnerReady` is never set — render.js's 30s readiness
	//        gate then times out with `runner_failed_to_bootstrap` (exit 5). Mirror the
	//        same slugs the Studio editor uses, since both run the same encode pipeline.
	$needs_coep = in_array($page, array('mcqvs-dashboard', 'mcqvs-settings', 'mcqvs-editor', 'mcqvs-content-planner', 'mcqvs-render'), true);
 // Also apply on health tab (self-test uses SharedArrayBuffer for worker encoding)
 if (!$needs_coep && $page === 'mcqvs-settings' && isset($_GET['tab']) && $_GET['tab'] === 'health') {
 $needs_coep = true;
 }
 if (!$needs_coep) {
 return;
 }

	// Headers must be sent before any output
	add_action('send_headers', function () {
		// Cross-Origin-Opener-Policy: Isolates browsing context
		header('Cross-Origin-Opener-Policy: same-origin');

		// Cross-Origin-Embedder-Policy: Requires CORP/CORS on resources
		header('Cross-Origin-Embedder-Policy: require-corp');

		// Allow our own assets and WordPress admin assets
		header('Cross-Origin-Resource-Policy: same-origin');
	}, 1);
}

/**
 * Display admin notice if MCQ Plugin is not active.
 *
 * @since 1.0.0
 */
function mcqvs_dependency_notice()
{
	// @MODIFIED 2026-02-18: Independence Update
	// Only show notice if: 
	// 1. Parent is missing AND
	// 2. Local API key is NOT configured.
	$local_key = get_option('mcqvs_gemini_api_key', '');

	if (!empty($local_key)) {
		return;
	}

	if (! current_user_can('manage_options')) {
		return;
	}

	if (get_option('mcqvs_dismissed_dependency_notice', false)) {
		return;
	}

	printf(
		'<div class="notice notice-warning is-dismissible" data-mcqvs-dismiss="dependency"><p><strong>%s</strong> %s</p></div>',
		esc_html__('MCQ Video Studio:', 'mcq-video-studio'),
		esc_html__('Running in independent mode. Please configure your Gemini API Key in Video Studio > Settings > API Settings.', 'mcq-video-studio')
	);
}
add_action('admin_notices', 'mcqvs_dependency_notice');

/**
 * Admin notice if Action Scheduler is not available.
 *
 * @since 1.5.3
 */
function mcqvs_action_scheduler_notice()
{
    if (!current_user_can('manage_options')) {
        return;
    }

    // If AS is available, clear the activation flag and don't show notice.
    if (function_exists('as_schedule_single_action')) {
        delete_option('mcqvs_as_missing_on_activation');
        return;
    }

    if (get_option('mcqvs_dismissed_as_notice', false)) {
        return;
    }

    // Check if this notice was triggered by activation.
    $activated = get_option('mcqvs_as_missing_on_activation', false);
    $msg = $activated
        ? esc_html__('MCQ Video Studio was activated but Action Scheduler is not available. Please install and activate the "Action Scheduler" plugin (standalone or via WooCommerce) for background processing, bulk scheduling, and video automation features.', 'mcq-video-studio')
        : esc_html__('Action Scheduler is required but not active. Please install and activate the "Action Scheduler" plugin (standalone or via WooCommerce) for background processing, bulk scheduling, and video automation features.', 'mcq-video-studio');

    printf(
        '<div class="notice notice-error is-dismissible" data-mcqvs-dismiss="as_missing"><p><strong>%s</strong> %s</p></div>',
        esc_html__('MCQ Video Studio:', 'mcq-video-studio'),
        $msg
    );
}
add_action('admin_notices', 'mcqvs_action_scheduler_notice');

/**
 * Plugin Activation Hook
 * Forces table creation and version update.
 */
function mcqvs_activate_plugin()
{
	// @NEW 2026-02-09: Check for Action Scheduler dependency.
	if (!function_exists('as_schedule_single_action')) {
		// Defer the notice to admin_notices (activation redirect hasn't happened yet).
		update_option('mcqvs_as_missing_on_activation', true);
	}

	// @NEW 2026-04: Schema must be loaded first
	require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-schema.php';
	require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-job-repository.php';
	require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-project-repository.php';
	require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-installer.php';
	require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-headless-renderer.php';

	// @FIX 1.4.9.41 (data-loss): take the safety snapshot before anything runs
	// so the backup always holds the pre-activation state.
	mcqvs_backup_user_data(get_option('mcqvs_version'));

	delete_option('mcqvs_db_enum_fix_136');
	delete_option('mcqvs_db_varchar_migration');
	delete_option('mcqvs_publish_columns_migration');

  // @FIX: VS_Installer::install() is now idempotent (skips tables that already exist).
  // The two preceding calls were unconditionally invoking dbDelta on vs_jobs,
  // vs_projects, and vs_project_questions before VS_Installer did the same —
  // causing ALTER TABLE ... CHANGE COLUMN id ... PRIMARY KEY to fire against
  // tables that were just created, producing "Multiple primary key defined".
  VS_Installer::install();

	update_option('mcqvs_version', MCQVS_VERSION);

	// @NEW 2026-05: Seed the headless render service user up-front so the first
	//                invocation doesn't fail with "Render user not configured".
	if (class_exists('VS_Headless_Renderer')) {
		VS_Headless_Renderer::ensure_render_user();
	}

	// @NEW 2026-01-30: Require a browser-run Self-Test after activation.
	// The full render/encode pipeline (WebCodecs/canvas/audio decode) cannot run in PHP on activation.
	update_option('mcqvs_selftest_status', 'required'); // required|pass|fail
	update_option('mcqvs_selftest_last_run', 0);
	update_option('mcqvs_selftest_last_report', '');

	// @NEW 2026-07-19: Auto-install render-service npm deps (canvas+ws) so
	//                    plugin deploys no longer require manual `npm install`.
	VS_Installer::maybe_install_render_deps();
}
register_activation_hook(__FILE__, 'mcqvs_activate_plugin');

function mcqvs_deactivate_plugin()
{
    // @FIX 1.4.9.45 (data-loss): Snapshot user data FIRST. Deactivation is the
    // first step of the ZIP-update flow (deactivate → delete folder → upload →
    // activate) and runs BEFORE the old uninstall.php. If that old uninstall —
    // or anything else — wipes options (the Gemini API key was a real casualty),
    // the snapshot taken here still holds the real values, and the dashboard's
    // "Restore Safety Backup" button refills them after reactivation.
    if (function_exists('mcqvs_backup_user_data')) {
        mcqvs_backup_user_data(get_option('mcqvs_version'));
    }

    wp_clear_scheduled_hook('vs_daily_schedule_event');
    wp_clear_scheduled_hook('vs_headless_render_cron');
    wp_clear_scheduled_hook('vs_publish_scheduled_cron');
    // @NEW: Cancel the self-healing telemetry prune event so it doesn't fire on a deactivated plugin.
    wp_clear_scheduled_hook('mcqvs_daily_telemetry_prune');
    // @NEW 2026-08-09: Cancel the artifact-prune daily cron.
    wp_clear_scheduled_hook('mcqvs_daily_artifact_prune');

    delete_option('mcqvs_did_init_log');
    delete_option('mcqvs_did_core_init_log');

    // @FIX 2026-08-12 (data-loss): NEVER delete user-generated data on deactivation.
    // `mcqvs_content_plan`, `mcqvs_content_plan_pending_batches`, `mcqvs_batch_tracker`
    // and every `mcqvs_batch_%` option (Content Planner topics, pending batches, bulk-
    // scheduler batches AND `mcqvs_batch_job_%` batch jobs) were wiped on every
    // deactivate → reactivate cycle, which erased the Content Planner dashboard,
    // the batch tracker, and all generated batch questions. Those are user data —
    // deactivation must only clear volatile transients/crons, never content.

    if (function_exists('as_unschedule_all_actions')) {
        as_unschedule_all_actions('vs_process_bulk_schedule');
        as_unschedule_all_actions('mcqvs_process_topic_batch');
        as_unschedule_all_actions('vs_generate_mcq_batch');
        as_unschedule_all_actions('vs_headless_render_cron');
        as_unschedule_all_actions('vs_publish_scheduled_cron');
        // @FIX (cross-file audit): Ensure per-job render-claim actions are cleared on
        //              deactivation, otherwise reactivation can inherit pending claims
        //              pointing at jobs from a prior install/config.
        as_unschedule_all_actions('mcqvs_render_claim');
    }

    global $wpdb;
    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_mcqvs_job_lock_%' OR option_name LIKE '_transient_mcqvs_render_pid_%' OR option_name LIKE '_transient_mcqvs_render_auth_%' OR option_name LIKE '_transient_mcqvs_render_auth_verified_%'");
    // @FIX (cross-file audit): Also clear the monotonic-spawn transient stamped by
    //              `VS_Headless_Renderer::render_job()` so reactivation starts from a clean slate.
    $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", '_transient_mcqvs_render_started_%'));
    // NOTE (1.4.9.40): `mcqvs_batch_%` options are intentionally NOT deleted here anymore —
    // they hold user data (bulk-scheduler batches + batch jobs) and were wiped on every
    // deactivate → reactivate cycle.

    // @FIX: Drop the always-growing per-day telemetry counters so they don't bloat `wp_options`
    //       across long-lived installs. We deliberately do NOT delete user credentials
    //       (`mcqvs_gemini_api_key`, `mcqvs_*_api_key`, etc.) — those are persistent settings.
    $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s", 'mcqvs_api_count_%', 'mcqvs_videos_created_%'));
    $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", '_transient_mcqvs_auth_attempts_%'));

    // Drop volatile logs table on deactivation (re-created on next activation)
    $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}vs_logs");

    // @FIX: Migration flags were previously orphaned on each deactivation cycle. The activation
    //       path `delete_option`s them anyway, but explicit cleanup here keeps DB rows trimmed.
    delete_option('mcqvs_db_enum_fix_136');
    delete_option('mcqvs_db_varchar_migration');
    delete_option('mcqvs_publish_columns_migration');
    delete_option('mcqvs_model_provider_column_migration');
    delete_option('mcqvs_dismissed_dependency_notice');
    delete_option('mcqvs_dismissed_selftest_notice');
    delete_option('mcqvs_rotation_state');

    // @NEW 2026-06-26: Reset active provider to Gemini on deactivation so reactivation doesn't
    //                  try to call a deleted custom provider. Keep `mcqvs_custom_providers`
    //                  intact — user configs are persistent settings, not cache.
    $current_provider = get_option('mcqvs_api_provider', 'gemini');
    if ($current_provider !== '' && $current_provider !== 'gemini' && strpos((string)$current_provider, 'gemini') !== 0) {
        $custom_raw = get_option('mcqvs_custom_providers', '[]');
        $exists = false;
        if (is_string($custom_raw)) {
            $decoded = json_decode($custom_raw, true);
            if (is_array($decoded)) {
                foreach ($decoded as $p) {
                    if (isset($p['id']) && $p['id'] === $current_provider) { $exists = true; break; }
                }
            }
        }
        if (!$exists) {
            update_option('mcqvs_api_provider', 'gemini');
        }
    }
}
register_deactivation_hook(__FILE__, 'mcqvs_deactivate_plugin');

/**
 * Plugin Uninstall Hook
 * Runs on "Delete" from Plugins page AND via uninstall.php direct access.
 * Cleans up all DB tables, all Action Scheduler actions, all scheduled hooks,
 * all transients, and all plugin options so the plugin folder can be deleted.
 */
/**
 * @FIX 1.4.9.41 (data-loss): Snapshot ALL user data + settings that must never
 * be lost into `mcqvs_safety_backup`. Taken automatically on every activation /
 * version bump (covers the ZIP-replace update flow too, via mcqvs_init) so that
 * if anything ever wipes data again, one click restores it.
 *
 * Captured: Content Planner (topics + pending pointer), batch tracker, every
 * `mcqvs_batch_%` option (bulk-scheduler batches + batch jobs), the Artifact
 * Cleanup Retention (days) options + dry-run flag, Buffer accounts, API
 * provider + custom providers + Gemini key.
 *
 * @param string $from_version Version being upgraded from ('' on fresh install).
 */
function mcqvs_backup_user_data($from_version = '')
{
    $backup = array(
        'version'          => (string) $from_version,
        'time'             => gmdate('c'),
        'content_plan'     => get_option('mcqvs_content_plan'),
        'pending_batches'  => get_option('mcqvs_content_plan_pending_batches'),
        'batch_tracker'    => get_option('mcqvs_batch_tracker'),
        'buffer_accounts'  => get_option('mcqvs_buffer_accounts'),
        'api_provider'     => get_option('mcqvs_api_provider'),
        'custom_providers' => get_option('mcqvs_custom_providers'),
        'gemini_api_key'   => get_option('mcqvs_gemini_api_key'),
    );

    // Artifact Cleanup Retention (days) settings + dry-run flag.
    foreach (array('tts', 'covers', 'generated', 'exports', 'batch', 'render_temp', 'temp', 'dry_run') as $key) {
        $backup['retention_' . $key] = get_option('mcqvs_artifact_retention_' . $key);
    }

    // All bulk-scheduler batches + batch jobs (dynamic option names).
    global $wpdb;
    $batch_options = array();
    $rows = $wpdb->get_col(
        $wpdb->prepare(
            "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
            'mcqvs_batch_%'
        )
    );
    if (is_array($rows)) {
        foreach ($rows as $name) {
            if ($name === 'mcqvs_batch_tracker') {
                continue; // already captured above
            }
            $batch_options[$name] = get_option($name);
        }
    }
    $backup['batch_options'] = $batch_options;

    // Never autoload — this is a safety copy, not hot data.
    update_option('mcqvs_safety_backup', wp_json_encode($backup), false);
}

/**
 * @FIX 1.4.9.41 (data-loss): One-click restore from `mcqvs_safety_backup`.
 * SAFE MERGE: only refills values that are currently MISSING/empty — existing
 * data is never overwritten, so a restore can't clobber newer work.
 *
 * @return array Summary for the UI.
 */
function mcqvs_restore_safety_backup()
{
    $raw = get_option('mcqvs_safety_backup', '');
    if (empty($raw)) {
        return array('restored' => 0, 'skipped' => 0, 'from' => '', 'version' => '', 'message' => 'No safety backup found — nothing to restore.');
    }
    $b = json_decode($raw, true);
    if (!is_array($b)) {
        return array('restored' => 0, 'skipped' => 0, 'from' => '', 'version' => '', 'message' => 'Safety backup is corrupted (not valid JSON).');
    }

    $restored = 0;
    $skipped = 0;

    $singles = array(
        'content_plan'     => 'mcqvs_content_plan',
        'pending_batches'  => 'mcqvs_content_plan_pending_batches',
        'batch_tracker'    => 'mcqvs_batch_tracker',
        'buffer_accounts'  => 'mcqvs_buffer_accounts',
        'api_provider'     => 'mcqvs_api_provider',
        'custom_providers' => 'mcqvs_custom_providers',
        'gemini_api_key'   => 'mcqvs_gemini_api_key',
    );
    foreach ($singles as $bk => $opt) {
        if (!array_key_exists($bk, $b)) {
            continue;
        }
        $current = get_option($opt);
        if ($current === false || $current === '' || $current === array()) {
            update_option($opt, $b[$bk]);
            $restored++;
        } else {
            $skipped++;
        }
    }

    // Retention settings — restore only when the option row is missing.
    foreach (array('tts', 'covers', 'generated', 'exports', 'batch', 'render_temp', 'temp', 'dry_run') as $key) {
        $bk  = 'retention_' . $key;
        $opt = 'mcqvs_artifact_retention_' . $key;
        if (!array_key_exists($bk, $b)) {
            continue;
        }
        if (get_option($opt) === false) {
            update_option($opt, $b[$bk]);
            $restored++;
        } else {
            $skipped++;
        }
    }

    // Batch options — re-create any that are missing (never overwrite).
    if (is_array($b['batch_options'] ?? null)) {
        foreach ($b['batch_options'] as $name => $val) {
            if (get_option($name) === false) {
                update_option($name, $val);
                $restored++;
            } else {
                $skipped++;
            }
        }
    }

    return array(
        'restored' => $restored,
        'skipped'  => $skipped,
        'from'     => (string) ($b['time'] ?? ''),
        'version'  => (string) ($b['version'] ?? ''),
        'message'  => "Restored {$restored} missing value(s) from backup taken " . (($b['time'] ?? '') ?: 'at an unknown time') . "; {$skipped} value(s) already present were left untouched.",
    );
}

/**
 * @FIX 1.4.9.45 (data-loss): Single source of truth for "should uninstall destroy
 * ALL plugin data?". Default is KEEP (false). Two opt-ins, either one purges:
 *   1. define('MCQVS_PURGE_DATA_ON_UNINSTALL', true); // wp-config.php
 *   2. Settings > Data > "Delete all plugin data on uninstall" checkbox
 *      (option `mcqvs_purge_data_on_uninstall`, default 0 = keep).
 *
 * @return bool
 */
function mcqvs_purge_data_on_uninstall()
{
    if (defined('MCQVS_PURGE_DATA_ON_UNINSTALL') && MCQVS_PURGE_DATA_ON_UNINSTALL) {
        return true;
    }
    if (function_exists('get_option')) {
        return (bool) get_option('mcqvs_purge_data_on_uninstall', false);
    }
    return false;
}

/**
 * @FIX 1.4.9.53 (global STOP): true when the dashboard "Stop Everything" button has
 * been pressed. Every pipeline entry point (render queue, publish scheduler, daily
 * scheduler, job processor, render-claim handler, AI batch handler, Buffer push,
 * Content Planner approve) checks this and bails early. Data is never touched.
 *
 * @return bool
 */
function mcqvs_is_global_stopped()
{
    if (function_exists('get_option')) {
        return !empty(get_option('mcqvs_global_stop', 0));
    }
    return false;
}

/**
 * @FIX 1.4.9.53: Timestamp the STOP was pressed (0 = not stopped).
 *
 * @return int
 */
function mcqvs_global_stop_time()
{
    if (function_exists('get_option')) {
        return (int) get_option('mcqvs_global_stop', 0);
    }
    return 0;
}

function mcqvs_uninstall_plugin()
{
    if (!defined('ABSPATH')) {
        return;
    }

    global $wpdb;

    // @FIX 2026-08-12 (data-loss): NEVER destroy user data on uninstall by default.
    // The plugin update flow (deactivate → delete folder → upload new ZIP) runs this
    // uninstall hook, which previously wiped EVERYTHING — Content Planner data, batch
    // tracker, the generated-Qs table `vs_mcq_bank`, jobs/projects, the Artifact
    // Cleanup retention settings, API keys, and the whole uploads/mcq-video-studio/
    // tree. To truly purge the site on a permanent removal, opt in explicitly via
    //   define('MCQVS_PURGE_DATA_ON_UNINSTALL', true);   // wp-config.php
    //   OR Settings > Data > "Delete all plugin data on uninstall" (default: KEEP).
    // Without it, deactivation only clears crons + volatile transients — all
    // questions, plans, settings and uploads are preserved.
    $purge = mcqvs_purge_data_on_uninstall();

    if (function_exists('as_unschedule_all_actions')) {
        as_unschedule_all_actions('vs_process_bulk_schedule');
        as_unschedule_all_actions('mcqvs_process_topic_batch');
        as_unschedule_all_actions('vs_generate_mcq_batch');
        as_unschedule_all_actions('vs_headless_render_cron');
        as_unschedule_all_actions('vs_publish_scheduled_cron');
        as_unschedule_all_actions('mcqvs_render_claim');
        as_unschedule_all_actions('mcqvs_kill_orphan_render');
    }

    wp_clear_scheduled_hook('vs_daily_schedule_event');
    wp_clear_scheduled_hook('vs_headless_render_cron');
    wp_clear_scheduled_hook('vs_publish_scheduled_cron');
    wp_clear_scheduled_hook('mcqvs_daily_telemetry_prune');

    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_mcqvs_job_lock_%' OR option_name LIKE '_transient_mcqvs_render_pid_%' OR option_name LIKE '_transient_mcqvs_render_auth_%' OR option_name LIKE '_transient_mcqvs_render_auth_verified_%'");
    $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", '_transient_mcqvs_render_started_%'));
    $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s", 'mcqvs_api_count_%', 'mcqvs_videos_created_%'));
    $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", '_transient_mcqvs_auth_attempts_%'));

    // Volatile logs table only — user-data tables are purged only when opted in.
    $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}vs_logs");

    // ---- Destructive cleanup: only when MCQVS_PURGE_DATA_ON_UNINSTALL === true ----
    if ($purge) {
        $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", 'mcqvs_batch_%'));

        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}vs_topics");
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}vs_mcq_bank");
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}vs_exam_calendar");
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}vs_jobs");
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}vs_projects");
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}vs_project_questions");

        delete_option('mcqvs_db_version');
        delete_option('mcqvs_db_enum_fix_136');
        delete_option('mcqvs_db_varchar_migration');
        delete_option('mcqvs_publish_columns_migration');
        delete_option('mcqvs_model_provider_column_migration');
        delete_option('mcqvs_batch_tracker');
        delete_option('mcqvs_content_plan');
        delete_option('mcqvs_content_plan_pending_batches');
        delete_option('mcqvs_selftest_status');
        delete_option('mcqvs_selftest_last_run');
        delete_option('mcqvs_selftest_last_report');
        delete_option('mcqvs_dismissed_dependency_notice');
        delete_option('mcqvs_dismissed_selftest_notice');
        delete_option('mcqvs_rotation_state');
        delete_option('mcqvs_did_init_log');
        delete_option('mcqvs_did_core_init_log');
        delete_option('mcqvs_api_provider');
        delete_option('mcqvs_custom_providers');
        delete_option('mcqvs_gemini_api_key');
        delete_option('mcqvs_external_assets_url');
        delete_option('mcqvs_buffer_accounts');
        delete_option('mcqvs_version');

        // @NEW 2026-08-09: Artifact cleanup retention options + dry-run flag.
        delete_option('mcqvs_artifact_retention_tts');
        delete_option('mcqvs_artifact_retention_covers');
        delete_option('mcqvs_artifact_retention_generated');
        delete_option('mcqvs_artifact_retention_exports');
        delete_option('mcqvs_artifact_retention_batch');
        delete_option('mcqvs_artifact_retention_render_temp');
        delete_option('mcqvs_artifact_retention_temp');
        delete_option('mcqvs_artifact_retention_dry_run');

        // @NEW 2026-08-09: Drop the entire uploads/mcq-video-studio/ tree on full
        // uninstall. Symlinks are not followed (matches VS_Artifact_Cleanup::rrmdir).
        if (function_exists('wp_upload_dir')) {
            $uploads = wp_upload_dir();
            if (empty($uploads['error']) && ! empty($uploads['basedir'])) {
                $root = $uploads['basedir'] . '/mcq-video-studio';
                if (is_dir($root)) {
                    try {
                        $iter = new RecursiveIteratorIterator(
                            new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS),
                            RecursiveIteratorIterator::CHILD_FIRST
                        );
                        foreach ($iter as $entry) {
                            try {
                                $is_link = $entry->isLink();
                            } catch (\Throwable $e) {
                                $is_link = false;
                            }
                            if ($is_link) {
                                @unlink($entry->getPathname());
                                continue;
                            }
                            if ($entry->isDir()) {
                                @rmdir($entry->getPathname());
                            } else {
                                @unlink($entry->getPathname());
                            }
                        }
                        @rmdir($root);
                    } catch (\Throwable $e) {
                        // best-effort: ignore
                    }
                }
            }
        }
    }
}
register_uninstall_hook(__FILE__, 'mcqvs_uninstall_plugin');

/**
 * Admin notice prompting Self-Test on activation or after failure.
 */
function mcqvs_selftest_admin_notice()
{
	if (!is_admin() || !current_user_can('manage_options')) {
		return;
	}

	$status = get_option('mcqvs_selftest_status', 'required');
	if ($status === 'pass') {
		return;
	}

	if (get_option('mcqvs_dismissed_selftest_notice', false)) {
		return;
	}

	// Only show on relevant admin screens to avoid spamming.
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$page = isset($_GET['page']) ? sanitize_text_field(wp_unslash($_GET['page'])) : '';
	$allowed_pages = array('mcqvs-dashboard', 'mcqvs-settings', 'mcqvs-logs', 'mcqvs-editor', 'mcqvs-content-planner', 'plugins.php', 'index.php');
	if ($page && !in_array($page, $allowed_pages, true)) {
		return;
	}

	$last_run = (int) get_option('mcqvs_selftest_last_run', 0);
	$when = $last_run ? gmdate('Y-m-d H:i:s', $last_run) . ' UTC' : 'never';
	$link = admin_url('admin.php?page=mcqvs-settings&tab=health&subtab=client');

	$cls = ($status === 'fail') ? 'notice notice-error' : 'notice notice-warning';
	$title = ($status === 'fail')
		? __('MCQ Video Studio: Self-Test failed', 'mcq-video-studio')
		: __('MCQ Video Studio: Self-Test required', 'mcq-video-studio');

	$msg = ($status === 'fail')
		? sprintf(__('A previous Self-Test failed (last run: %s). Run the Self-Test to see details and fix parity/encode issues.', 'mcq-video-studio'), esc_html($when))
		: __('Run the Self-Test to verify templates, assets, worker rendering and MP4 encoding before production use.', 'mcq-video-studio');

	echo '<div class="' . esc_attr($cls) . ' is-dismissible" data-mcqvs-dismiss="selftest"><p><strong>' . esc_html($title) . '</strong><br>' . esc_html($msg) . '</p>';
	echo '<p><a class="button button-primary" href="' . esc_url($link) . '">' . esc_html__('Run Self-Test', 'mcq-video-studio') . '</a></p>';
	echo '</div>';
}
add_action('admin_notices', 'mcqvs_selftest_admin_notice');

function mcqvs_dismiss_admin_notice_ajax()
{
	check_ajax_referer('mcqvs_dismiss_notice', 'nonce');
	$key = isset($_POST['dismiss_key']) ? sanitize_text_field(wp_unslash($_POST['dismiss_key'])) : '';
	$allowed = array(
		'dependency' => 'mcqvs_dismissed_dependency_notice',
		'selftest'   => 'mcqvs_dismissed_selftest_notice',
		'as_missing' => 'mcqvs_dismissed_as_notice',
	);
	if (isset($allowed[$key])) {
		update_option($allowed[$key], true);
		wp_send_json_success();
	}
	wp_send_json_error();
}
add_action('wp_ajax_mcqvs_dismiss_notice', 'mcqvs_dismiss_admin_notice_ajax');

function mcqvs_enqueue_notice_dismiss_script()
{
	if (!is_admin() || !current_user_can('manage_options')) {
		return;
	}
	$ajax_url = admin_url('admin-ajax.php');
	$nonce = wp_create_nonce('mcqvs_dismiss_notice');
	echo "<script>\n";
	echo "(function(){";
	echo "document.querySelectorAll('[data-mcqvs-dismiss]').forEach(function(n){";
	echo "n.addEventListener('click',function(e){";
	echo "if(!e.target.classList.contains('notice-dismiss'))return;";
	echo "var k=this.getAttribute('data-mcqvs-dismiss');";
	echo "e.preventDefault();";
	echo "var fd=new FormData();fd.append('action','mcqvs_dismiss_notice');fd.append('nonce','" . esc_js($nonce) . "');fd.append('dismiss_key',k);";
	echo "fetch('" . esc_url($ajax_url) . "',{method:'POST',body:fd});";
	echo "});});";
	echo "})();";
	echo "</script>";
}
add_action('admin_footer', 'mcqvs_enqueue_notice_dismiss_script');

// ==================================================================================
// @NEW 2026-08-13 (mcq ↔ mcq-video-studio integration): Auto-sync a newly created
// MCQ from the source MCQ plugin into the video studio bank, with content_hash dedup.
// Called from NM_Post_Type_Manager::save_mcq_post_unified() via mcqvs_sync_mcq_from_source().
// ==================================================================================
function mcqvs_sync_mcq_from_source( $source_post_id ) {
	$source_post_id = absint( $source_post_id );
	if ( $source_post_id <= 0 ) {
		return;
	}
	$post = get_post( $source_post_id );
	if ( ! $post || 'mcq' !== $post->post_type ) {
		return;
	}
	if ( ! class_exists( 'VS_MCQ_Repository' ) ) {
		return;
	}

	// Extract data (mirrors VS_Migrator but reads the already-populated meta).
	$question_text = get_post_meta( $source_post_id, 'mcq_question', true );
	if ( empty( $question_text ) ) {
		$question_text = $post->post_title;
	}
	if ( empty( $question_text ) ) {
		return;
	}

	$options_raw = get_post_meta( $source_post_id, 'mcq_options', true );
	if ( ! is_array( $options_raw ) ) {
		return;
	}
	// Normalize to a flat 0..3 indexed array of strings.
	$flat = array();
	foreach ( array( 'A', 'B', 'C', 'D' ) as $letter ) {
		if ( isset( $options_raw[ $letter ] ) && '' !== trim( (string) $options_raw[ $letter ] ) ) {
			$flat[] = trim( (string) $options_raw[ $letter ] );
		}
	}
	if ( count( $flat ) < 2 ) {
		return;
	}

	// Resolve correct_index from stored answer letter.
	$answer_letter = strtoupper( (string) get_post_meta( $source_post_id, 'mcq_answer', true ) );
	$correct_index = array_search( $answer_letter, array( 'A', 'B', 'C', 'D' ), true );
	if ( false === $correct_index || $correct_index >= count( $flat ) ) {
		$correct_index = 0;
	}

	// Map the topic term(s) to a bank topic_id, preserving the MCQ's exact topic.
	// The 'topic' taxonomy is hierarchical (parent + child/subtopic). Prefer the most
	// specific term (a child/subtopic) so the bank question clearly belongs to the
	// precise topic it was generated under; fall back to the first (parent) term.
	$topic_id = 0;
	$terms    = get_the_terms( $source_post_id, 'topic' );
	if ( $terms && ! is_wp_error( $terms ) && ! empty( $terms ) ) {
		$chosen = null;
		foreach ( $terms as $t ) {
			if ( ! empty( $t->parent ) ) {
				$chosen = $t; // child/subtopic = most specific
				break;
			}
		}
		if ( ! $chosen ) {
			$chosen = reset( $terms );
		}
		if ( $chosen && ! empty( $chosen->name ) ) {
			$topic_id = (int) VS_MCQ_Repository::get_instance()->create_topic( $chosen->name, 'subject' );
			// Record the exam tags on the source post so the video system can filter by
			// exam later (bank is topic-keyed; exam is reachable via the source post too).
			$exams = get_the_terms( $source_post_id, 'nm_exam' );
			if ( $exams && ! is_wp_error( $exams ) && ! empty( $exams ) ) {
				$exam_slugs = array();
				foreach ( $exams as $e ) {
					$exam_slugs[] = sanitize_key( $e->slug );
				}
				update_post_meta( $source_post_id, '_nm_mcqvs_exams', $exam_slugs );
			}
		}
	}

	$repo   = VS_MCQ_Repository::get_instance();
	$result = $repo->insert_mcq(
		array(
			'question_text'  => $question_text,
			'options'        => $flat,
			'correct_index'  => $correct_index,
			'topic_id'       => $topic_id,
			'parent_post_id' => $source_post_id,
			'difficulty'     => (string) get_post_meta( $source_post_id, 'mcq_difficulty', true ) ?: 'medium',
			'explanation'    => (string) get_post_meta( $source_post_id, 'mcq_explanation', true ),
			'source_ref'     => 'mcq_plugin_post_' . $source_post_id,
			'status'         => 'approved',
		)
	);

	if ( is_wp_error( $result ) ) {
		// duplicate_mcq is the normal, expected path — not an error.
		if ( 'duplicate_mcq' !== $result->get_error_code() && class_exists( 'VS_Error_Logger' ) ) {
			VS_Error_Logger::get_instance()->log(
				'MCQVS auto-sync failed for source post ' . $source_post_id . ': ' . $result->get_error_message(),
				'warning'
			);
		}
		return;
	}

	// Mark the source post as synced so we don't re-sync on every save.
	update_post_meta( $source_post_id, '_mcqvs_migrated', 1 );
}

// Also hook the legacy action (belt & braces) so older mcq plugin builds that fire
// `mcqvs_sync_mcq_created` still get the auto-sync.
add_action( 'mcqvs_sync_mcq_created', 'mcqvs_sync_mcq_from_source', 10, 1 );
