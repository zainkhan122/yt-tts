/**
 * MCQ Video Studio - Unified Renderer
 * 
 * @version 1.1.0
 * @description Shared rendering engine for both Main Thread (Preview) and Web Worker (Export).
 * Ensures 100% visual parity by using the exact same code for drawing frames.
 * 
 * Usage:
 * const renderer = new MCQVS_UnifiedRenderer();
 * renderer.render(ctx, state, assets);
 */

(function (global) {
    class MCQVS_UnifiedRenderer {
        constructor() {
            this.version = "1.0.0";
        }

        /**
         * Main Render Loop
         * @param {CanvasRenderingContext2D} ctx - Context (Canvas or OffscreenCanvas)
         * @param {Object} state - Render state (time, config, active scene)
         * @param {Object} assets - Images, Fonts, Video Frames
         */
        /**
         * Main Render Loop
         * @param {CanvasRenderingContext2D} ctx - Context (Canvas or OffscreenCanvas)
         * @param {Object} state - Render state (time, config, active scene)
         * @param {Object} assets - Images, Fonts, Video Frames
         */
  async render(ctx, state, assets) {
    const cw = (ctx.canvas && ctx.canvas.width) || 1080;
    const ch = (ctx.canvas && ctx.canvas.height) || 1920;
    const cx = cw / 2;
    const cy = ch / 2;

    // 1. Clear Canvas & Reset Transform (Safety)
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, cw, ch);

    // 2. Determine Active Scene Logic
    // Note: Caller is responsible for determining 'activeScene' based on time
    // and populating state.currentSceneId, state.elapsedInScene, state.animationPhase
    const activeScene = state.activeScene;
    if (!activeScene) {
      // Fallback: Clear Black
      ctx.fillStyle = "#000000";
      ctx.fillRect(0, 0, cw, ch);
      return;
    }

            // 3. Setup Camera / Animations
            // ------------------------------------------
            ctx.save(); // [SAVE 1] Camera Scope

            // ============================================================
            // PHASE 5 2026-01-30: RenderPlan-driven production FX
            // (flash / timer glow / screen shake)
            // ============================================================
            // @MODIFIED 2026-02-26: Prefer absolute state.time for FX lookups
            const _nowMs = Number((state.time != null ? state.time : state.elapsed) || 0);
            const _fx = Array.isArray(state.fxEvents) ? state.fxEvents : [];
            let _flash = null;
            let _glow = null;
            let _shake = null;

            for (const ev of _fx) {
                if (!ev || ev.atMs == null || !ev.type) continue;
                const at = Number(ev.atMs);
                const dur = Number(ev.durationMs != null ? ev.durationMs : 0);
                if (dur <= 0) continue;
                if (_nowMs < at || _nowMs > (at + dur)) continue;
                if (ev.type === 'flash') _flash = ev;
                if (ev.type === 'timer_glow') _glow = ev;
                if (ev.type === 'screen_shake') _shake = ev;
            }

            // Camera Shake (if AnimationEngine available)
  if (global.MCQVS_AnimationEngine && global.MCQVS_AnimationEngine.camera) {
    global.MCQVS_AnimationEngine.camera.applyTransform(ctx, cx, cy, state.elapsed);
  }

            // Additional RenderPlan-driven screen shake (template-defined)
            if (_shake) {
                const mag = Number(_shake.magnitude != null ? _shake.magnitude : 12);
                const t = (_nowMs - Number(_shake.atMs)) / 1000;
                // Deterministic pseudo-jitter (sin/cos) for parity across preview/export
                const dx = Math.sin(t * 53.3) * mag * (1 - Math.min(1, t / (Number(_shake.durationMs) / 1000)));
                const dy = Math.cos(t * 47.7) * mag * (1 - Math.min(1, t / (Number(_shake.durationMs) / 1000)));
                ctx.translate(dx, dy);
            }

            // Zoom Effect (Question Phase Only)
            // @MODIFIED 2026-01-31: Key off scene identity instead of animationPhase to eliminate competing clocks
            const zoomDuration = state.timing?.questionPhases?.intro || 1000;
            let zoomApplied = false;

            if (state.elapsedInScene < zoomDuration && (activeScene.type === "question")) {
                const scale = 1 + Math.min(1, state.elapsedInScene / zoomDuration) * 0.05;
    ctx.save(); // [SAVE 2] Zoom Scope
    ctx.translate(cx, cy);
    ctx.scale(scale, scale);
    ctx.translate(-cx, -cy);
                zoomApplied = true;
            }

            // 4. Render Core Content via Template Manager
            // ------------------------------------------
            if (global.MCQVS_TemplateManager) {
                const tmplId = state.currentTemplate || "trivia";
                const template = global.MCQVS_TemplateManager.getTemplate(tmplId);

                // GUARD: Prevent accidental double-rendering if stub exists on context (unlikely but paranoid)
                // Note: UnifiedRenderer class local methods are not context methods, but we check 'this' just in case.
                if (typeof this.drawQuestionTimer === 'function' && this.drawQuestionTimer.toString().includes('console.debug')) {
                    // Stub detected, safe to proceed
                } else if (typeof this.drawQuestionTimer === 'function') {
                    // Logic detected! This means someone reverted the stub. Warn.
                    console.warn("[UnifiedRenderer] Warning: drawQuestionTimer seems active. Double rendering risk.");
                }

                // Ensure assets are strictly passed
                const renderAssets = {
                    logoImage: state.brandLogoImage || assets.logoImage, // Handle both main thread and worker keys
                    bgImage: state.bgImage || assets.bgImage,
                    bgVideoFrames: state.bgVideoFrames || assets.bgVideoFrames,
                    splitScreenVideo: state.splitScreenVideo || assets.splitScreenVideo // @NEW 2026-01-26
                };

                // @NEW 2026-02-01: AssetCache Integration (Async Fallback)
                if (!renderAssets.bgImage && state.bgImageUrl && global.MCQVSAssetCache) {
                    try {
                        const cached = await global.MCQVSAssetCache.get(state.bgImageUrl);
                        if (cached && (cached instanceof Image || cached instanceof ImageBitmap || cached.ready)) {
                            renderAssets.bgImage = cached;
                        }
                    } catch (e) {
                        // Cache miss or fail, ignore
                    }
                }

                // @NEW 2026-01-26: Render Split Screen Video (Bottom Half Overlay)
                if (renderAssets.splitScreenVideo) {
                    try {
                        // Support both HTMLVideoElement (Preview) and ImageBitmap/Frame (Worker)
                        ctx.drawImage(renderAssets.splitScreenVideo, 0, ch / 2, cw, ch / 2);
                    } catch (e) {
                        // Ignore if not ready
                    }
                }

                // Pass template-specific styling explicitly
                // Worker might have them in 'config', Main in 'this.state'
                // We assume 'state' passed here is already flattened/normalized

                // @FIX 2026-01-26: Crash Diagnostic for Export
                try {
                    template.render(ctx, state, renderAssets);
                } catch (err) {
                    console.error("[Unified Renderer] Template Render Failed:", err);
                    console.error("State Snapshot:", JSON.stringify({
                        phase: state.animationPhase,
                        sceneId: state.currentSceneId,
                        template: tmplId,
                        hasAssets: !!assets
                    }));
                    // Draw Error Fallback
ctx.fillStyle = "red";
ctx.font = `${Math.round(Math.min(cw,ch) * 0.037)}px sans-serif`;
ctx.textAlign = "left";
ctx.textBaseline = "top";
ctx.fillText("Render Error: " + err.message, Math.round(cw * 0.05), Math.round(ch * 0.5));
                    throw err; // Re-throw to surfacing top-level error
                }

} else {
ctx.fillStyle = "#333";
ctx.fillRect(Math.round(cw * 0.1), Math.round(ch * 0.05), Math.round(cw * 0.8), Math.round(ch * 0.9));
ctx.fillStyle = "white";
ctx.font = `${Math.round(Math.min(cw,ch) * 0.037)}px sans-serif`;
ctx.textAlign = "center";
ctx.textBaseline = "middle";
ctx.fillText("Template Manager Missing", cw / 2, ch / 2);
}

            // 5. Particle / FX Events (Plan-driven)
            // ------------------------------------------
            // Phase 4: Effects must be driven by RenderPlan cue events, not inferred timing.
            // This eliminates re-trigger drift and allows templates to schedule rich FX safely.
            if (global.MCQVS_AnimationEngine && global.MCQVS_AnimationEngine.particles) {
                // @MODIFIED 2026-02-26: Prefer absolute state.time for FX lookups
                const now = Number((state.time != null ? state.time : state.elapsed) || 0);
                const prev = Number(state.prevElapsed != null ? state.prevElapsed : Math.max(0, now - 34)); // ~1 frame fallback

                // One-shot FX triggers across frames
                global.__MCQVS_FX_FIRED = global.__MCQVS_FX_FIRED || new Set();

                const fxEvents = Array.isArray(state.fxEvents) ? state.fxEvents : [];
                for (const ev of fxEvents) {
                    if (!ev || ev.atMs == null || !ev.type) continue;
                    const at = Number(ev.atMs);
                    if (at < prev || at > now) continue;

                    // @MODIFIED 2026-02-07: Added sceneId to key to ensure FX fires for each question (Fixes "Only Q1" bug)
                    const key = `${state.currentSceneId}:${ev.type}:${at}:${ev.kind || ""}`;
                    if (global.__MCQVS_FX_FIRED.has(key)) continue;
                    global.__MCQVS_FX_FIRED.add(key);

if (ev.type === "particles_burst") {
const burstX = (ev.x != null) ? Number(ev.x) : cx;
const burstY = (ev.y != null) ? Number(ev.y) : cy;
const kind = ev.kind || "sparkles";
if (kind === "sparkles") {
global.MCQVS_AnimationEngine.particles.burst(burstX, burstY, "stars", 150);
global.MCQVS_AnimationEngine.particles.burst(burstX, burstY, "sparks", 100);
} else if (kind === "confetti") {
global.MCQVS_AnimationEngine.particles.burst(burstX, burstY, "confetti", 40);
} else {
global.MCQVS_AnimationEngine.particles.burst(burstX, burstY, String(kind), 30);
}
                    }
                }

                global.MCQVS_AnimationEngine.particles.setCurrentTime(now);
                global.MCQVS_AnimationEngine.particles.update();
                global.MCQVS_AnimationEngine.particles.draw(ctx);
            }

            // ------------------------------------------
            // PHASE 5: Non-particle FX overlays (flash + timer glow)
            // Drawn after core content to keep templates clean.
            // ------------------------------------------
            if (_flash) {
                const dur = Number(_flash.durationMs || 320);
                const t = Math.max(0, Math.min(1, (_nowMs - Number(_flash.atMs)) / dur));
                const intensity = Number(_flash.intensity != null ? _flash.intensity : 0.65);
                // Fast decay to avoid washing the frame
                const a = (1 - t) * intensity;
                if (a > 0.01) {
      ctx.save();
      ctx.globalAlpha = a;
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, cw, ch);
      ctx.restore();
                }
            }

            if (_glow) {
                const dur = Number(_glow.durationMs || 240);
                const t = Math.max(0, Math.min(1, (_nowMs - Number(_glow.atMs)) / dur));
                const intensity = Number(_glow.intensity != null ? _glow.intensity : 0.75);
                const color = String(_glow.color || "#00f0ff");
                // Pulse curve (0->1->0)
                const p = Math.sin(Math.PI * (1 - t));
                const a = p * intensity;
                if (a > 0.02) {
                    // Approximate timer region. Templates may differ,
                    // but this covers the default timer pill area without needing template hooks.
                    const isLandscape = cw > ch;
                    let x = isLandscape ? Math.round(cw * 0.89) : Math.round(cw * 0.305);
                    let y = isLandscape ? Math.round(ch * 0.87) : Math.round(ch * 0.833);
                    let w = isLandscape ? Math.round(cw * 0.07) : Math.round(cw * 0.389);
                    let h = isLandscape ? Math.round(ch * 0.055) : Math.round(ch * 0.068);
                    let r = isLandscape ? 14 : 18;
                    // @MODIFIED 2026-01-31: Fixed reference error (activeTimerGlow -> _glow)
                    if (_glow && _glow.rect && typeof _glow.rect === "object") {
                        const rr = _glow.rect;
                        x = Number.isFinite(rr.x) ? rr.x : x;
                        y = Number.isFinite(rr.y) ? rr.y : y;
                        w = Number.isFinite(rr.w) ? rr.w : w;
                        h = Number.isFinite(rr.h) ? rr.h : h;
                        r = Number.isFinite(rr.r) ? rr.r : r;
                    }
                    ctx.save();
                    ctx.globalAlpha = a;
                    ctx.shadowColor = color;
                    ctx.shadowBlur = 28;
                    ctx.lineWidth = 6;
                    ctx.strokeStyle = color;
                    // Rounded rect stroke
                    ctx.beginPath();
                    ctx.moveTo(x + r, y);
                    ctx.lineTo(x + w - r, y);
                    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
                    ctx.lineTo(x + w, y + h - r);
                    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
                    ctx.lineTo(x + r, y + h);
                    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
                    ctx.lineTo(x, y + r);
                    ctx.quadraticCurveTo(x, y, x + r, y);
                    ctx.closePath();
                    ctx.stroke();
                    ctx.restore();
                }
            }

            // 6. Restore Camera
            // ------------------------------------------
            if (zoomApplied) ctx.restore(); // [RESTORE 2]
            ctx.restore(); // [RESTORE 1]

            // 7. Overlays (Absolute Positioning)
            // ------------------------------------------

            // A. Transitions
            if (global.MCQVS_AnimationEngine && global.MCQVS_AnimationEngine.transitions) {
                // @FIX 2026-01-28: Ensure strict function call to prevent infinite loop
    if (global.MCQVS_AnimationEngine.transitions.isActive()) {
      global.MCQVS_AnimationEngine.transitions.apply(ctx, cw, ch, state.elapsed);
    }
  }

  // B. Kinetic Text
  if (global.MCQVS_AnimationEngine && global.MCQVS_AnimationEngine.overlays) {
    global.MCQVS_AnimationEngine.overlays.updateAndDraw(ctx, cw, ch, state.elapsed);
  }

            // C. Corner Logo (Watermark)
            // @REMOVED 2026-01-27: Handled by TemplateManager (Restored Parity)
            // if (state.brandLogoImage || assets.logoImage...) { ... }

            // D. Question Timer (Pill)
            // @REMOVED 2026-01-27: Handled by TemplateManager (Bar Style Parity)
            // if (activeScene.type === 'question') { ... }

            // E. Safe Zone (Debug/UI)
            if (state.showSafeZone) {
                this.drawSafeZone(ctx);
            }
        }

        /**
         * Draw Corner Logo
         */
  drawCornerLogo(ctx, logoImage) {
    if (!logoImage) return;
    const cw = (ctx.canvas && ctx.canvas.width) || 1080;
    const size = 150;
    const padding = 40;
    const x = cw - size - padding;
            const y = 40; // Top Right

            ctx.save();
            ctx.globalAlpha = 0.8;
            ctx.shadowColor = "rgba(0,0,0,0.5)";
            ctx.shadowBlur = 10;
            try {
                ctx.drawImage(logoImage, x, y, size, size);
            } catch (e) { /* Ignore if not loaded */ }
            ctx.restore();
        }

        /**
         * Draw Question Timer (Pill Style)
         * Matches vs-video-studio.js implementation exactly
         */
        // LEGACY - UnifiedRenderer Question Timer (DEPRECATED)
        // Timer visuals are owned by TemplateManager.drawQuestion.
        drawQuestionTimer(ctx, elapsedInScene, revealStartMs) {
            if (console && console.debug) {
                console.debug('MCQVS UnifiedRenderer: drawQuestionTimer is deprecated. Timer is rendered in templates.');
            }
        }

        /**
         * Draw Safe Zone Overlay
         */
	drawSafeZone(ctx) {
		const cw = (ctx.canvas && ctx.canvas.width) || 1080;
		const ch = (ctx.canvas && ctx.canvas.height) || 1920;
		const isLandscape = cw > ch;
		ctx.save();
		ctx.setTransform(1, 0, 0, 1, 0, 0);

		ctx.fillStyle = "rgba(255, 0, 0, 0.2)";
		ctx.strokeStyle = "rgba(255, 0, 0, 0.6)";
		ctx.lineWidth = 4;

		if (isLandscape) {
			// YouTube safe zones
			const rightW = Math.round(cw * 0.04);
			const leftW = Math.round(cw * 0.04);
			const bottomH = Math.round(ch * 0.10);
			const topH = Math.round(ch * 0.06);

			ctx.fillRect(cw - rightW, 0, rightW, ch);
			ctx.strokeRect(cw - rightW, 0, rightW, ch);
			ctx.fillRect(0, 0, leftW, ch);
			ctx.strokeRect(0, 0, leftW, ch);
			ctx.fillRect(0, ch - bottomH, cw, bottomH);
			ctx.strokeRect(0, ch - bottomH, cw, bottomH);
			ctx.fillRect(0, 0, cw, topH);
			ctx.strokeRect(0, 0, cw, topH);

			ctx.fillStyle = "rgba(255, 255, 255, 0.9)";
			ctx.font = "bold 30px sans-serif";
			ctx.textAlign = "center";
			ctx.fillText("TOP UI", cw / 2, Math.round(topH * 0.5));
			ctx.fillText("CAPTIONS & UI", cw / 2, ch - Math.round(bottomH * 0.5));
} else {
// Shorts safe zones (proportional)
const rightW = Math.round(cw * 0.148);
const rightTop = Math.round(ch * 0.286);
const rightH = Math.round(ch * 0.521);
ctx.fillRect(cw - rightW, rightTop, rightW, rightH);
ctx.strokeRect(cw - rightW, rightTop, rightW, rightH);

const bottomH = Math.round(ch * 0.219);
ctx.fillRect(0, ch - bottomH, cw, bottomH);
ctx.strokeRect(0, ch - bottomH, cw, bottomH);

const topH = Math.round(ch * 0.115);
ctx.fillRect(0, 0, cw, topH);
ctx.strokeRect(0, 0, cw, topH);

ctx.fillStyle = "rgba(255, 255, 255, 0.9)";
ctx.font = "bold 30px sans-serif";
ctx.textAlign = "center";
ctx.fillText("TOP UI", cw / 2, Math.round(topH * 0.5));
ctx.fillText("CAPTIONS & UI", cw / 2, ch - Math.round(bottomH * 0.48));
}

		ctx.restore();
	}
    }

    // Export to Global
    global.MCQVS_UnifiedRenderer = MCQVS_UnifiedRenderer;
    // @MODIFIED 2026-01-30: Alias for worker sanity check
    global.UnifiedRenderer = MCQVS_UnifiedRenderer;

})(self); // 'self' works in both Window and Worker
