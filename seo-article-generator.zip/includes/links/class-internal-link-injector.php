<?php
/**
 * Deterministic Internal Link Injector
 *
 * @package SEO_Article_Generator
 *
 * @since 2.34.11
 *
 * Replaces the unreliable AI-token internal linker (which depended on the AI
 * emitting [SEOGEN_LINK_n]...[/SEOGEN_LINK_n] placeholders in the exact zone).
 * This injector runs on the FINAL rendered block HTML and adds contextual
 * internal links entirely in deterministic PHP — no AI dependency.
 *
 * Hard rules (operator-specified):
 *  - Links are added ONLY in three zones: intro (id="intro"),
 *    MOAT (id="moat-content") and Features (id="key-features").
 *  - Hero, download portal, tech specs, what's new, FAQ, install/troubleshoot,
 *    headings, tables, list markup and HTML/JSON/attributes are never touched.
 *  - A paragraph receives a link ONLY if it does not already contain one.
 *  - A post never contains more than the configured cap (default 3) internal
 *    links in those zones in total, including pre-existing links — so updates
 *    never stack links beyond the cap. One link per paragraph.
 *  - Anchors are short, contextual brand names that genuinely appear in the
 *    prose verbatim. Generic/platform/common words (Windows, Linux, Desktop,
 *    Browser, Connect, PDF Reader...) are never used as anchors.
 *  - Never links a post to itself; never repeats a target URL.
 *  - Idempotent: running twice adds nothing. If there is no safe contextual
 *    spot the content is returned byte-identical (leave-unchanged philosophy).
 */

namespace SEO_Article_Generator\Links;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Internal_Link_Injector
 */
class Internal_Link_Injector {

	/**
	 * Stable anchor ids the renderer emits, in document order, for the three
	 * linkable zones plus the first boundary that must NOT be linked.
	 *
	 * @var string[]
	 */
	private $zone_headings = array(
		'intro'                   => 'intro',
		'moat-content'            => 'moat',
		'key-features'            => 'features',
		'whats-new'               => null, // hard stop for the features zone
		'technical-specifications' => null,
		'download-portal'         => null,
		'hero'                    => null,
		'system-requirements'     => null,
	);

	/**
	 * Logger.
	 *
	 * @var \SEO_Article_Generator\Logger|null
	 */
	private $logger;

	/**
	 * Constructor.
	 *
	 * @param mixed $logger Logger instance.
	 */
	public function __construct( $logger = null ) {
		$this->logger = $logger;
	}

	/**
	 * Generic / platform / common-noun words that must NEVER be used as an
	 * anchor, even when they happen to be a post slug.
	 *
	 * @return string[] Lower-cased words.
	 */
	private function generic_words(): array {
		return array(
			'browser', 'safe', 'box', 'download', 'manager', 'tool', 'free', 'pro',
			'plus', 'rom', 'app', 'apps', 'software', 'web', 'internet', 'security',
			'cleaner', 'editor', 'player', 'studio', 'office', 'drive', 'mail',
			'notes', 'reader', 'writer', 'viewer', 'master', 'utility', 'system',
			'optimizer', 'converter', 'recorder', 'maker', 'creator', 'burner',
			'finder', 'guard', 'shield', 'defender', 'scan', 'fast', 'quick',
			'easy', 'smart', 'total', 'ultra', 'data', 'file', 'files', 'disk',
			'media', 'photo', 'video', 'audio', 'image', 'pdf', 'doc', 'text',
			'start', 'stop', 'run', 'get', 'set', 'new', 'old', 'one', 'go', 'up',
			'now', 'pc', 'win', 'windows', 'linux', 'macos', 'mac', 'android',
			'ios', 'ubuntu', 'debian', 'chromeos', 'desktop', 'mobile', 'server',
			'connect', 'connection', 'capture', 'backup', 'sync', 'transfer',
			'remote', 'access', 'support', 'portal', 'home', 'page', 'site',
			'net', 'link', 'update', 'upgrade', 'installer', 'install', 'setup',
			'professional', 'enterprise', 'standard', 'ultimate', 'personal',
			'business', 'picture', 'camera', 'sound', 'voice', 'music', 'movie',
			'film', 'game', 'gaming', 'network', 'vpn', 'proxy', 'firewall',
			'antivirus', 'virus', 'malware', 'spyware', 'recovery', 'repair',
			'fix', 'boost', 'tune', 'clean', 'wipe', 'erase', 'format', 'clone',
			'platform', 'platforms', 'edition', 'version', 'latest', 'portable',
		);
	}

	/**
	 * Distinctive single-word software brands that are unambiguous in prose.
	 * Single-word anchors outside this list are rejected.
	 *
	 * @return string[] Lower-cased brand names.
	 */
	private function brand_whitelist(): array {
		return array(
			'chrome', 'firefox', 'edge', 'vivaldi', 'opera', 'brave', 'sandboxie',
			'telegram', 'signal', 'discord', 'slack', 'spotify', 'winrar',
			'obsidian', 'notion', 'trello', 'zoom', 'skype', 'vlc', 'gimp',
			'inkscape', 'blender', 'audacity', 'handbrake', 'qbittorrent',
			'utorrent', 'bitcomet', 'filezilla', 'putty', 'wireshark', 'nmap',
			'docker', 'virtualbox', 'vmware', 'wine', 'keepass', 'thunderbird',
			'libreoffice', 'openoffice', 'drupal', 'wordpress', 'joomla',
			'photoshop', 'illustrator', 'dreamweaver', 'coreldraw', 'evernote',
			'dropbox', 'onedrive', 'mega', 'floorp', 'librewolf', 'waterfox',
			'notepad', 'sandbox', '7-zip', 'epic', 'sandboxie', 'goodsnyc',
			'vivaldi', 'sandboxie',
		);
	}

	/**
	 * Main entry point: inject contextual internal links into final HTML.
	 *
	 * @param string $content       Final rendered post_content (block HTML).
	 * @param string $current_name  Clean name of the current software.
	 * @param int    $exclude_post  Current post id (never link to itself).
	 * @param array  $opts          Optional overrides (max_links, dry_run).
	 * @return string Content, possibly with internal links added.
	 */
	public function inject( string $content, string $current_name, int $exclude_post = 0, array $opts = array() ): string {
		$max_links = isset( $opts['max_links'] )
			? max( 0, (int) $opts['max_links'] )
			: $this->configured_max();

		if ( $max_links <= 0 || trim( $content ) === '' ) {
			return $content;
		}

		try {
			return $this->inject_inner( $content, $current_name, $exclude_post, $max_links, ! empty( $opts['dry_run'] ) );
		} catch ( \Throwable $e ) {
			// Never break publishing because of linking. Leave content intact.
			if ( $this->logger ) {
				$this->logger->warning( 'Internal link injector aborted; content left unchanged: ' . $e->getMessage() );
			}
			return $content;
		}
	}

	/**
	 * Dry-run helper: returns [content, log] without callers needing to pass flags.
	 *
	 * @param string $content      Final HTML.
	 * @param string $current_name Current software name.
	 * @param int    $exclude_post Current post id.
	 * @param int    $max_links    Cap.
	 * @return array{content:string,log:array}
	 */
	public function dry_run( string $content, string $current_name, int $exclude_post = 0, int $max_links = 3 ): array {
		$log = array();
		$out = $this->inject_inner( $content, $current_name, $exclude_post, max( 1, $max_links ), true, $log );
		return array( 'content' => $out, 'log' => $log );
	}

	/**
	 * Configured cap.
	 *
	 * @return int
	 */
	private function configured_max(): int {
		$default = \SEO_Article_Generator\Option_Registry::defaults();
		$val     = (int) \get_option(
			\SEO_Article_Generator\Option_Registry::INTERNAL_LINK_COUNT,
			$default[ \SEO_Article_Generator\Option_Registry::INTERNAL_LINK_COUNT ] ?? 3
		);
		return max( 0, $val );
	}

	/**
	 * Real implementation.
	 *
	 * @param string $content      HTML.
	 * @param string $current_name Current software name.
	 * @param int    $exclude_post Current post id.
	 * @param int    $max_links    Cap.
	 * @param bool   $dry_run      Collect log only.
	 * @param array  $log_out      By-reference log.
	 * @return string
	 */
	private function inject_inner( string $content, string $current_name, int $exclude_post, int $max_links, bool $dry_run, array &$log_out = array() ): string {
		$log = array(
			'allowed_paragraphs'       => 0,
			'zones_seen'               => array(),
			'candidate_targets'        => 0,
			'existing_links_in_zones'  => 0,
			'budget'                   => $max_links,
			'placed'                   => array(),
			'skipped'                  => array(),
			'total_placed'             => 0,
		);

		$paragraphs = $this->allowed_paragraphs( $content );
		$log['allowed_paragraphs'] = count( $paragraphs );
		$log['zones_seen']         = array_values( array_unique( array_map( function ( $p ) {
			return $p['zone'];
		}, $paragraphs ) ) );

		if ( empty( $paragraphs ) ) {
			$log_out = $log;
			return $content;
		}

		// Existing internal links already inside the allowed zones count toward
		// the total cap so updates never stack beyond the limit.
		$existing = 0;
		foreach ( $paragraphs as $p ) {
			$existing += preg_match_all( '#<a\b[^>]*href\s*=#i', $p['html'] );
		}
		$log['existing_links_in_zones'] = $existing;
		$budget = max( 0, $max_links - $existing );
		$log['budget'] = $budget;

		if ( $budget <= 0 ) {
			$log_out = $log;
			$this->maybe_log( $log, $current_name );
			return $content;
		}

		$candidates = $this->get_candidates( $exclude_post, $current_name );
		$log['candidate_targets'] = count( $candidates );

		$edits     = array(); // block start offset => new html
		$ends      = array(); // block start offset => block end offset
		$used_urls = array();
		$placed    = 0;

		foreach ( $paragraphs as $p ) {
			if ( $placed >= $budget ) {
				break;
			}
			$ends[ $p['start'] ] = $p['end'];
			$text_only = html_entity_decode( wp_strip_all_tags( $p['html'] ), ENT_QUOTES, 'UTF-8' );

			foreach ( $candidates as $cand ) {
				if ( $placed >= $budget ) {
					break;
				}
				$url = $cand['url'];
				if ( isset( $used_urls[ $url ] ) ) {
					continue;
				}
				// Never re-link a URL already present anywhere in the post.
				if ( strpos( $content, $url ) !== false ) {
					continue;
				}

				$matched = false;
				foreach ( $cand['anchors'] as $anchor ) {
					if ( ! $this->phrase_present( $text_only, $anchor ) ) {
						continue;
					}
					$result = $this->insert_into_paragraph( $p['html'], $anchor, $url );
					if ( $result[0] === false ) {
						$log['skipped'][] = array(
							'zone'   => $p['zone'],
							'anchor' => $anchor,
							'target' => $cand['name'],
							'why'    => $result[1],
						);
						continue;
					}
					$edits[ $p['start'] ] = $result[0];
					$used_urls[ $url ]   = true;
					$placed++;
					$matched             = true;
					$log['placed'][]     = array(
						'zone'   => $p['zone'],
						'anchor' => $anchor,
						'target' => $cand['name'],
						'url'    => $url,
					);
					break;
				}
				if ( $matched ) {
					break; // one link per paragraph.
				}
			}
		}

		$log['total_placed'] = $placed;

		if ( $dry_run ) {
			$log_out = $log;
			// Do not modify content in dry-run; still return original.
			return $content;
		}

		if ( empty( $edits ) ) {
			$log_out = $log;
			$this->maybe_log( $log, $current_name );
			return $content;
		}

		// Apply edits back-to-front so offsets stay valid.
		$new_content = $content;
		krsort( $edits );
		foreach ( $edits as $start => $html ) {
			$end         = $ends[ $start ];
			$new_content = substr( $new_content, 0, $start ) . $html . substr( $new_content, $end );
		}

		$log_out = $log;
		$this->maybe_log( $log, $current_name );
		return $new_content;
	}

	/**
	 * Whether a phrase appears as a standalone (proper-noun for single words)
	 * token in the text.
	 *
	 * @param string $text   Plain text.
	 * @param string $phrase Anchor phrase.
	 * @return bool
	 */
	private function phrase_present( string $text, string $phrase ): bool {
		if ( $phrase === '' ) {
			return false;
		}
		// Single-word anchors must appear capitalised (brand), never lowercase.
		if ( str_word_count( $phrase ) === 1 ) {
			if ( mb_strpos( $text, $phrase ) === false ) {
				return false;
			}
		} else {
			if ( mb_stripos( $text, $phrase ) === false ) {
				return false;
			}
		}
		return $this->word_boundary_ok( $text, $phrase );
	}

	/**
	 * Boundary check so we never link a substring inside a larger word.
	 *
	 * @param string $text   Text.
	 * @param string $phrase Phrase.
	 * @return bool
	 */
	private function word_boundary_ok( string $text, string $phrase ): bool {
		$hay_lc = mb_strtolower( $text );
		$needle = mb_strtolower( $phrase );
		$at     = mb_strpos( $hay_lc, $needle );
		if ( $at === false ) {
			return false;
		}
		$before = $at > 0 ? mb_substr( $text, $at - 1, 1 ) : '';
		$after  = mb_substr( $text, $at + mb_strlen( $needle ), 1 );
		$is_word = function ( $c ) {
			return preg_match( '/[\p{L}\p{N}_\-]/u', $c );
		};
		if ( $before !== '' && $is_word( $before ) ) {
			return false;
		}
		if ( $after !== '' && $is_word( $after ) ) {
			return false;
		}
		return true;
	}

	/**
	 * Insert an anchor link into ONE paragraph block's <p> text, skipping tags.
	 *
	 * @param string $block_html Full wp:paragraph block HTML.
	 * @param string $anchor     Anchor text.
	 * @param string $url        Target URL.
	 * @return array{0:false|string,1:string} [new_html_or_false, reason]
	 */
	private function insert_into_paragraph( string $block_html, string $anchor, string $url ): array {
		if ( preg_match( '#(<p\b[^>]*>)(.*)(</p>)#s', $block_html, $pm, PREG_OFFSET_CAPTURE ) ) {
			$inner_start = $pm[2][1];
			$inner_len   = strlen( $pm[2][0] );
			$inner       = $pm[2][0];
		} else {
			return array( false, 'no <p> wrapper' );
		}

		// Paragraph already carries a link -> never add another to it.
		if ( preg_match( '#<a\b[^>]*href\s*=#i', $inner ) ) {
			return array( false, 'paragraph already has a link' );
		}

		$pos      = 0;
		$len      = strlen( $inner );
		$inserted = false;
		$out      = '';

		while ( $pos < $len ) {
			$lt = strpos( $inner, '<', $pos );
			if ( $lt === false ) {
				$lt = $len;
			}
			$text = substr( $inner, $pos, $lt - $pos );

			if ( ! $inserted ) {
				$replacement = $this->wrap_first_occurrence( $text, $anchor, $url );
				if ( $replacement[0] ) {
					$text     = $replacement[1];
					$inserted = true;
				}
			}
			$out .= $text;

			if ( $lt >= $len ) {
				break;
			}
			$gt = strpos( $inner, '>', $lt );
			if ( $gt === false ) {
				$out .= substr( $inner, $lt );
				break;
			}
			$out .= substr( $inner, $lt, $gt - $lt + 1 ); // copy tag verbatim.
			$pos  = $gt + 1;
		}

		if ( ! $inserted ) {
			return array( false, 'anchor not present as standalone text' );
		}

		$new_block = substr( $block_html, 0, $inner_start ) . $out . substr( $block_html, $inner_start + $inner_len );
		return array( $new_block, 'ok' );
	}

	/**
	 * Wrap the first standalone occurrence of the anchor in a text segment.
	 *
	 * @param string $text   Plain-text segment (no tags).
	 * @param string $anchor Anchor.
	 * @param string $url    URL.
	 * @return array{0:bool,1:string} [changed, new_text]
	 */
	private function wrap_first_occurrence( string $text, string $anchor, string $url ): array {
		if ( $text === '' ) {
			return array( false, $text );
		}
		$needle_lc = mb_strtolower( $anchor );
		$text_lc   = mb_strtolower( $text );
		$at        = mb_strpos( $text_lc, $needle_lc );
		if ( $at === false ) {
			return array( false, $text );
		}
		// Single-word brand must be capitalised in source.
		if ( str_word_count( $anchor ) === 1 ) {
			$case_at = mb_strpos( $text, $anchor );
			if ( $case_at === false ) {
				return array( false, $text );
			}
			$at = $case_at;
		}
		// Boundary check within this segment.
		$before = $at > 0 ? mb_substr( $text, $at - 1, 1 ) : '';
		$after  = mb_substr( $text, $at + mb_strlen( $anchor ), 1 );
		$is_word = function ( $c ) {
			return preg_match( '/[\p{L}\p{N}_\-]/u', $c );
		};
		if ( ( $before !== '' && $is_word( $before ) ) || ( $after !== '' && $is_word( $after ) ) ) {
			return array( false, $text );
		}

		$actual = mb_substr( $text, $at, mb_strlen( $anchor ) ); // preserve original casing.
		$link   = '<a href="' . esc_url( $url ) . '">' . esc_html( $actual ) . '</a>';
		$new    = mb_substr( $text, 0, $at ) . $link . mb_substr( $text, $at + mb_strlen( $anchor ) );
		return array( true, $new );
	}

	/**
	 * Return wp:paragraph blocks that fall inside one of the allowed zones.
	 *
	 * @param string $content Block HTML.
	 * @return array<int,array{start:int,end:int,html:string,zone:string}>
	 */
	private function allowed_paragraphs( string $content ): array {
		$bounds = array();
		foreach ( array_keys( $this->zone_headings ) as $anchor_id ) {
			if ( preg_match( '/id="' . preg_quote( $anchor_id, '/' ) . '"/', $content, $m, PREG_OFFSET_CAPTURE ) ) {
				$bounds[] = array( 'off' => $m[0][1], 'anchor' => $anchor_id );
			}
		}
		usort( $bounds, function ( $a, $b ) {
			return $a['off'] <=> $b['off'];
		} );

		$paragraphs = array();
		if ( preg_match_all( '#<!-- wp:paragraph\b.*?-->#s', $content, $opens, PREG_OFFSET_CAPTURE ) ) {
			foreach ( $opens[0] as $om ) {
				$block_start = $om[1];
				$close       = strpos( $content, '<!-- /wp:paragraph -->', $block_start );
				if ( $close === false ) {
					continue;
				}
				$block_end = $close + strlen( '<!-- /wp:paragraph -->' );

				// Determine the zone of this block = last heading at/before it.
				$zone = null;
				foreach ( $bounds as $b ) {
					if ( $b['off'] <= $block_start ) {
						$zone = $this->zone_headings[ $b['anchor'] ];
					} else {
						break;
					}
				}
				if ( $zone !== null ) {
					$paragraphs[] = array(
						'start' => $block_start,
						'end'   => $block_end,
						'html'  => substr( $content, $block_start, $block_end - $block_start ),
						'zone'  => $zone,
					);
				}
			}
		}
		return $paragraphs;
	}

	/**
	 * Fetch published post candidates from the live DB, with usable anchors.
	 *
	 * @param int    $exclude_post Current post id.
	 * @param string $current_name Current software clean name.
	 * @return array<int,array{name:string,url:string,anchors:string[]}>
	 */
	private function get_candidates( int $exclude_post, string $current_name ): array {
		$posts = get_posts( array(
			'post_type'        => 'post',
			'post_status'      => 'publish',
			'posts_per_page'   => 1000,
			'post__not_in'     => $exclude_post > 0 ? array( $exclude_post ) : array(),
			'no_found_rows'    => true,
			'suppress_filters' => false,
			'orderby'          => 'date',
			'order'            => 'DESC',
		) );

		$current_lc    = mb_strtolower( trim( $current_name ) );
		$generic       = $this->generic_words();
		$brands        = $this->brand_whitelist();
		$candidates    = array();
		$seen_names    = array();

		foreach ( $posts as $post ) {
			$url = get_permalink( $post->ID );
			if ( ! $url ) {
				continue;
			}
			// Prefer the clean software slug to derive a short brand name.
			$slug = $post->post_name;
			$name = $this->clean_name( $slug, $post->post_title );
			if ( $name === '' ) {
				continue;
			}
			if ( mb_strtolower( $name ) === $current_lc ) {
				continue;
			}
			$key = mb_strtolower( $name );
			if ( isset( $seen_names[ $key ] ) ) {
				continue;
			}

			$anchors = $this->anchor_variants( $name, $generic, $brands );
			if ( empty( $anchors ) ) {
				continue; // no safe, distinctive anchor for this post.
			}
			$seen_names[ $key ] = true;
			$candidates[]       = array(
				'name'    => $name,
				'url'     => $url,
				'anchors' => $anchors,
			);
		}

		// Prefer multi-word (specific) brand names first; stable order.
		usort( $candidates, function ( $a, $b ) {
			$sa = str_word_count( $a['name'] );
			$sb = str_word_count( $b['name'] );
			if ( $sb !== $sa ) {
				return $sb <=> $sa;
			}
			return strcmp( $a['name'], $b['name'] );
		} );

		return $candidates;
	}

	/**
	 * Derive a clean software display name from slug (fallback to title).
	 *
	 * @param string $slug  Post slug.
	 * @param string $title Post title (fallback).
	 * @return string
	 */
	private function clean_name( string $slug, string $title ): string {
		$name = ucwords( str_replace( '-', ' ', trim( $slug ) ) );
		$name = trim( preg_replace( '/\s+/', ' ', $name ) );
		if ( $name === '' ) {
			// Strip SEO suffix from title ("X Download ... - Softwares Wave").
			$title = preg_split( '/\s+(Download|Free Download|\|)\s*/i', $title );
			$name  = trim( $title[0] ?? '' );
			// Remove a trailing version pattern.
			$name  = trim( preg_replace( '/\b\d+(\.\d+)+.*$/', '', $name ) );
		}
		return $name;
	}

	/**
	 * Build usable anchor variants for a brand name.
	 *
	 * @param string   $name    Clean brand name.
	 * @param string[] $generic Generic words.
	 * @param string[] $brands  Single-word brand whitelist.
	 * @return string[] Longest-first unique anchors.
	 */
	private function anchor_variants( string $name, array $generic, array $brands ): array {
		$name  = trim( preg_replace( '/\s+/', ' ', $name ) );
		$parts = preg_split( '/\s+/', $name );
		$variants = array();

		if ( str_word_count( $name ) <= 3 ) {
			$variants[] = $name;
		}
		if ( count( $parts ) >= 2 ) {
			$tail1 = end( $parts );
			if ( in_array( mb_strtolower( $tail1 ), $brands, true ) && ! in_array( mb_strtolower( $tail1 ), $generic, true ) ) {
				$variants[] = $tail1;
			}
			$tail2 = implode( ' ', array_slice( $parts, -2 ) );
			if ( str_word_count( $tail2 ) >= 2 ) {
				$variants[] = $tail2;
			}
		} elseif ( count( $parts ) === 1 ) {
			if ( in_array( mb_strtolower( $name ), $brands, true ) ) {
				$variants[] = $name;
			}
		}

		$variants = array_unique( $variants );
		// Every usable anchor needs at least one distinctive (non-generic) token.
		$variants = array_values( array_filter( $variants, function ( $v ) use ( $generic ) {
			foreach ( preg_split( '/\s+/', mb_strtolower( $v ) ) as $w ) {
				if ( $w !== '' && ! in_array( $w, $generic, true ) ) {
					return true;
				}
			}
			return false;
		} ) );
		usort( $variants, function ( $a, $b ) {
			return mb_strlen( $b ) <=> mb_strlen( $a );
		} );
		return array_values( $variants );
	}

	/**
	 * Emit a concise log line.
	 *
	 * @param array  $log          Log.
	 * @param string $current_name Current software.
	 * @return void
	 */
	private function maybe_log( array $log, string $current_name ): void {
		if ( ! $this->logger ) {
			return;
		}
		$anchors = array();
		foreach ( $log['placed'] as $p ) {
			$anchors[] = '[' . $p['zone'] . '] "' . $p['anchor'] . '" -> ' . $p['target'];
		}
		$this->logger->info( 'Internal link injection for "' . $current_name . '": placed ' . $log['total_placed']
			. ' (budget ' . $log['budget'] . ', existing ' . $log['existing_links_in_zones']
			. ', candidates ' . $log['candidate_targets'] . ')' . ( $anchors ? ' — ' . implode( '; ', $anchors ) : '' ) );
	}
}
