<?php

/**
 * Settings page view
 *
 * @package DIT_TrendStudio
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

settings_errors('dit_ts_settings');
if (isset($_GET['settings-updated']) && $_GET['settings-updated'] === 'true') {
    echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__('Settings saved.', 'dit-trend-content-studio') . '</p></div>';
}
?>
<div class="wrap dit-ts-admin">
    <h1><?php esc_html_e('Trend Studio Settings', 'dit-trend-content-studio'); ?></h1>

    <?php
    // @MODIFIED 2026-02-10 - Settings Tabs Configuration
    $tabs = [
        'apis'       => __('APIs', 'dit-trend-content-studio'),
        'images'     => __('Images', 'dit-trend-content-studio'),
        'trends'     => __('Trends Discovery', 'dit-trend-content-studio'),
        'campaigns'  => __('Campaigns', 'dit-trend-content-studio'),
        'scheduling' => __('Scheduling', 'dit-trend-content-studio'),
        'automation' => __('Automation', 'dit-trend-content-studio'),
        'content'    => __('Content', 'dit-trend-content-studio'),
        'social'     => __('Social', 'dit-trend-content-studio'),
        // @MODIFIED 2026-02-25 - Smoke test diagnostics tab
        'diagnostics' => __('Diagnostics', 'dit-trend-content-studio'),
    ];
    $active_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'apis'; // Use $_GET for tab selection
    ?>

    <nav class="nav-tab-wrapper dit-ts-tab-wrapper">
        <?php foreach ($tabs as $tab_id => $tab_label) : ?>
            <a href="?page=dit-ts-settings&tab=<?php echo esc_attr($tab_id); ?>"
                class="nav-tab <?php echo $active_tab === $tab_id ? 'nav-tab-active' : ''; ?>"
                data-tab="<?php echo esc_attr($tab_id); ?>">
                <?php echo esc_html($tab_label); ?>
            </a>
        <?php endforeach; ?>
    </nav>

    <form method="post" action="" id="dit-ts-settings-form">
        <?php wp_nonce_field('dit_ts_settings'); ?>
        <input type="hidden" name="tab" id="dit-ts-current-tab" value="<?php echo esc_attr($active_tab); ?>">

        <div id="tab-apis" class="dit-ts-tab-content <?php echo $active_tab === 'apis' ? 'active' : ''; ?>">
            <h2 class="title"><?php esc_html_e('API Configuration', 'dit-trend-content-studio'); ?></h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="dit_ts_gemini_api_key"><?php esc_html_e('Gemini API Key', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <div class="dit-ts-password-field">
                            <input type="password" name="dit_ts_gemini_api_key" id="dit_ts_gemini_api_key"
                                class="regular-text"
                                value="<?php echo esc_attr(get_option('dit_ts_gemini_api_key', '')); ?>">
                            <button type="button" class="button dit-ts-toggle-password" data-target="dit_ts_gemini_api_key" aria-label="<?php esc_attr_e('Show API key', 'dit-trend-content-studio'); ?>">
                                <span class="dashicons dashicons-visibility"></span>
                            </button>
                        </div>
                        <button type="button" class="button" id="dit-ts-test-api">
                            <?php esc_html_e('Test Connection', 'dit-trend-content-studio'); ?>
                        </button>
                        <span class="api-test-result"></span>

                        <span class="api-test-result"></span>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="dit_ts_ai_strategy"><?php esc_html_e('Default AI Provider', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
		<?php $strategy = get_option('dit_ts_ai_strategy', 'gemini'); ?>
		<select name="dit_ts_ai_strategy" id="dit_ts_ai_strategy">
			<option value="gemini" <?php selected($strategy, 'gemini'); ?>><?php esc_html_e('Gemini (Google Search Grounding)', 'dit-trend-content-studio'); ?></option>
			<option value="custom" <?php selected($strategy, 'custom'); ?>><?php esc_html_e('Custom Provider (OpenAI-Compatible)', 'dit-trend-content-studio'); ?></option>
		</select>
                        <p class="description">
                            <?php esc_html_e('Choose which AI models handle the research and writing pipeline.', 'dit-trend-content-studio'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="dit_ts_gemini_model"><?php esc_html_e('AI Model Selection', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <?php $selected_model = get_option('dit_ts_gemini_model', 'gemini-2.0-flash'); ?>
                        <select name="dit_ts_gemini_model" id="dit_ts_gemini_model" style="width: 100%; max-width: 400px;">
                            <option value="gemini-2.0-flash" <?php selected($selected_model, 'gemini-2.0-flash'); ?>><?php esc_html_e('Gemini 2.0 Flash (Fastest / Recommended)', 'dit-trend-content-studio'); ?></option>
                            <option value="gemini-2.0-flash-lite-preview-02-05" <?php selected($selected_model, 'gemini-2.0-flash-lite-preview-02-05'); ?>><?php esc_html_e('Gemini 2.0 Flash-Lite (Preview / Ultra-Fast)', 'dit-trend-content-studio'); ?></option>
                            <option value="gemini-2.0-flash-thinking-exp-01-21" <?php selected($selected_model, 'gemini-2.0-flash-thinking-exp-01-21'); ?>><?php esc_html_e('Gemini 2.0 Flash Thinking (Deep Reasoning)', 'dit-trend-content-studio'); ?></option>
                            <option value="gemini-1.5-flash" <?php selected($selected_model, 'gemini-1.5-flash'); ?>><?php esc_html_e('Gemini 1.5 Flash (Reliable Workhorse)', 'dit-trend-content-studio'); ?></option>
                            <option value="gemini-1.5-pro" <?php selected($selected_model, 'gemini-1.5-pro'); ?>><?php esc_html_e('Gemini 1.5 Pro (Analytical / High Quality)', 'dit-trend-content-studio'); ?></option>
                            <option value="gemini-2.0-pro-exp-02-05" <?php selected($selected_model, 'gemini-2.0-pro-exp-02-05'); ?>><?php esc_html_e('Gemini 2.0 Pro Experimental (Absolute Highest Quality)', 'dit-trend-content-studio'); ?></option>
                        </select>

                        <div style="margin-top: 15px;">
                            <label for="dit_ts_gemini_model_custom" style="display: block; font-weight: 600; margin-bottom: 5px;"><?php esc_html_e('Custom Model ID (Override)', 'dit-trend-content-studio'); ?></label>
                            <input type="text" name="dit_ts_gemini_model_custom" id="dit_ts_gemini_model_custom"
                                class="regular-text" style="width: 100%; max-width: 400px;"
                                value="<?php echo esc_attr(get_option('dit_ts_gemini_model_custom', '')); ?>"
                                placeholder="e.g. gemini-1.5-flash-latest">
                            <p class="description"><?php esc_html_e('If entered, this will override the dropdown selection above.', 'dit-trend-content-studio'); ?></p>
                        </div>

                        <div style="margin-top: 15px;">
                            <label for="dit_ts_gemini_api_version" style="display: block; font-weight: 600; margin-bottom: 5px;"><?php esc_html_e('API Version', 'dit-trend-content-studio'); ?></label>
                            <?php $api_version = get_option('dit_ts_gemini_api_version', 'v1beta'); ?>
                            <select name="dit_ts_gemini_api_version" id="dit_ts_gemini_api_version" style="width: 100%; max-width: 400px;">
                                <option value="v1beta" <?php selected($api_version, 'v1beta'); ?>>v1beta (Latest Features / Default)</option>
                                <option value="v1" <?php selected($api_version, 'v1'); ?>>v1 (Stable / Production)</option>
                            </select>
                            <p class="description"><?php esc_html_e('Switch to "v1" if your selected model reports as "not found" in v1beta.', 'dit-trend-content-studio'); ?></p>
                        </div>
                        <div class="description" style="margin-top: 10px; line-height: 1.5;">
                            <ul style="list-style: disc; margin-left: 20px;">
                                <li><strong><?php esc_html_e('Flash Models', 'dit-trend-content-studio'); ?></strong>: <?php esc_html_e('High speed, high quota (RPM), and strong Live Search grounding. Best for daily production.', 'dit-trend-content-studio'); ?></li>
                                <li><strong><?php esc_html_e('Pro Models', 'dit-trend-content-studio'); ?></strong>: <?php esc_html_e('Higher reasoning quality but significantly lower rate limits on free tiers. May trigger 429 errors in high-volume schedules.', 'dit-trend-content-studio'); ?></li>
                                <li><strong><?php esc_html_e('Thinking Model', 'dit-trend-content-studio'); ?></strong>: <?php esc_html_e('Reason through complex instructions before writing. Excellent for nuanced editorial requirements.', 'dit-trend-content-studio'); ?></li>
                                <li><strong><?php esc_html_e('Grounding', 'dit-trend-content-studio'); ?></strong>: <?php esc_html_e('All selected models support Google Search grounding (Live Search).', 'dit-trend-content-studio'); ?></li>
                            </ul>
                        </div>
                    </td>
                </tr>
<style>
.dit-ts-provider-card{border:1px solid #ccd0d4;border-radius:4px;padding:16px;margin-bottom:12px;background:#fff;position:relative;}
.dit-ts-provider-card .provider-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;padding-bottom:8px;border-bottom:1px solid #eee;}
.dit-ts-provider-card .provider-header h4{margin:0;font-size:14px;}
.dit-ts-provider-card .provider-fields{display:grid;grid-template-columns:1fr 1fr;gap:10px;}
.dit-ts-provider-card .provider-fields .field-full{grid-column:1/-1;}
.dit-ts-provider-card .provider-fields label{display:block;font-weight:600;margin-bottom:3px;font-size:12px;}
.dit-ts-provider-card .provider-fields input,.dit-ts-provider-card .provider-fields select{width:100%;max-width:100%;}
.dit-ts-provider-card .models-list{margin-top:8px;}
.dit-ts-provider-card .model-row{display:flex;gap:6px;margin-bottom:4px;align-items:center;}
.dit-ts-provider-card .model-row input{flex:1;}
.dit-ts-provider-card .web-search-config{margin-top:8px;padding:8px;background:#f9f9f9;border-radius:3px;}
.dit-ts-provider-card .provider-actions{margin-top:10px;display:flex;gap:6px;align-items:center;}
.dit-ts-sortable-list{list-style:none;padding:0;margin:0;}
.dit-ts-sortable-list li{padding:6px 10px;background:#f6f7f7;border:1px solid #dcdcde;margin-bottom:2px;cursor:move;border-radius:3px;font-size:13px;}
.dit-ts-sortable-list li:hover{background:#f0f0f1;}
.dit-ts-sortable-placeholder{height:32px;background:#e5f5fa;border:1px dashed #72aee6;margin-bottom:2px;border-radius:3px;}
.dit-ts-sortable-list li.ui-sortable-helper{background:#e5f5fa;border-color:#72aee6;box-shadow:0 2px 6px rgba(0,0,0,0.12);}
@media(max-width:782px){.dit-ts-provider-card .provider-fields{grid-template-columns:1fr;}}
/* @ADDED 2026-07-12 — OpenRouter sync status styles */
.openrouter-sync-status{display:flex;align-items:center;gap:6px;padding:6px 8px;background:#f6f7f7;border:1px solid #dcdcde;border-radius:4px;font-size:11px;color:#50575e;}
.openrouter-sync-status .dashicons{font-size:12px;width:12px;height:12px;flex-shrink:0;}
.openrouter-sync-status.sync-ok{border-color:#00a32a;background:#f0faf1;}
.openrouter-sync-status.sync-ok .dashicons{color:#00a32a;}
.openrouter-sync-status.sync-warn{border-color:#dba617;background:#fdf8e8;}
.openrouter-sync-status.sync-warn .dashicons{color:#dba617;}
.openrouter-sync-text{flex:1;}
/* @ADDED 2026-07-17 — OpenCode Zen sync status styles (parallel to OpenRouter) */
.opencode-sync-status{display:flex;align-items:center;gap:6px;padding:6px 8px;background:#f6f7f7;border:1px solid #dcdcde;border-radius:4px;font-size:11px;color:#50575e;margin-top:6px;}
.opencode-sync-status .dashicons{font-size:12px;width:12px;height:12px;flex-shrink:0;}
.opencode-sync-status.sync-ok{border-color:#00a32a;background:#f0faf1;}
.opencode-sync-status.sync-ok .dashicons{color:#00a32a;}
.opencode-sync-status.sync-warn{border-color:#dba617;background:#fdf8e8;}
.opencode-sync-status.sync-warn .dashicons{color:#dba617;}
.opencode-sync-text{flex:1;}
</style>
 <!-- Custom Providers Configuration -->
<tr>
 <th scope="row">
  <label><?php esc_html_e('Custom Providers', 'dit-trend-content-studio'); ?></label>
 </th>
 <td>
  <div id="dit-ts-custom-providers-list" class="dit-ts-custom-providers-list">
  </div>
  <button type="button" class="button" id="dit-ts-add-custom-provider"><?php esc_html_e('Add Provider', 'dit-trend-content-studio'); ?></button>
  <input type="hidden" name="dit_ts_custom_providers_json" id="dit_ts_custom_providers_json" value="<?php echo esc_attr(wp_json_encode(\DIT\TrendStudio\Infrastructure\AI_Provider_Factory::get_custom_providers())); ?>">
  <p class="description">
   <?php esc_html_e('Configure multiple OpenAI-compatible providers (GLM, Kimi, MiniMax, DeepSeek, etc.). Each provider can have multiple models with fallback order.', 'dit-trend-content-studio'); ?>
  </p>
 </td>
</tr>
<tr>
 <th scope="row">
  <label for="dit_ts_custom_default_provider"><?php esc_html_e('Default Provider', 'dit-trend-content-studio'); ?></label>
 </th>
 <td>
  <select name="dit_ts_custom_default_provider" id="dit_ts_custom_default_provider">
   <option value=""><?php esc_html_e('— First Available —', 'dit-trend-content-studio'); ?></option>
  </select>
  <p class="description"><?php esc_html_e('Which custom provider to use by default when strategy is "custom" and no per-job selection is made.', 'dit-trend-content-studio'); ?></p>
 </td>
</tr>
<tr>
 <th scope="row">
  <label><?php esc_html_e('Fallback Configuration', 'dit-trend-content-studio'); ?></label>
 </th>
 <td>
  <label>
                <input type="checkbox" id="dit_ts_fallback_enable_model" value="1" <?php
                $fb_cfg = get_option('dit_ts_custom_fallback_config', []);
                $fb_model = is_array($fb_cfg) && isset($fb_cfg['enable_model_fallback']) ? $fb_cfg['enable_model_fallback'] : true;
                checked($fb_model);
                ?>>
   <?php esc_html_e('Enable Model Fallback (Level 1) — try next model in the same provider on 429/403', 'dit-trend-content-studio'); ?>
  </label>
  <br>
  <label style="margin-top: 6px; display: inline-block;">
                <input type="checkbox" id="dit_ts_fallback_enable_cross_provider" value="1" <?php
                $fb_cross = is_array($fb_cfg) && !empty($fb_cfg['enable_cross_provider_fallback']);
                checked($fb_cross);
                ?>>
   <?php esc_html_e('Enable Cross-Provider Fallback (Level 2) — try another provider when all models exhausted', 'dit-trend-content-studio'); ?>
  </label>
  <br>
  <label style="margin-top: 6px; display: inline-block;">
                <input type="checkbox" id="dit_ts_fallback_enable_universal" value="1" <?php
                $fb_universal = is_array($fb_cfg) && !empty($fb_cfg['enable_universal_fallback']);
                checked($fb_universal);
                ?>>
   <?php esc_html_e('Enable Universal Provider Fallback — try ALL configured providers before giving up', 'dit-trend-content-studio'); ?>
  </label>
  <p class="description" style="margin-top: 4px; margin-left: 20px; font-style: italic;">
   <?php esc_html_e('When ON, if the primary provider fails, the system automatically tries every other configured provider (Custom, Gemini) with their full model chains. Supersedes Level 1 &amp; Level 2 above.', 'dit-trend-content-studio'); ?>
  </p>
  <div id="dit-ts-cross-provider-order" style="margin-top: 10px; display: none;">
   <label style="font-weight: 600; margin-bottom: 4px; display: block;"><?php esc_html_e('Cross-Provider Priority Order:', 'dit-trend-content-studio'); ?></label>
   <ul id="dit-ts-cross-provider-sortable" class="dit-ts-sortable-list" style="max-width: 350px;">
   </ul>
   <p class="description"><?php esc_html_e('Drag to reorder. First provider is tried first during cross-provider fallback.', 'dit-trend-content-studio'); ?></p>
  </div>
  <input type="hidden" name="dit_ts_custom_fallback_config_json" id="dit_ts_custom_fallback_config_json" value="<?php echo esc_attr(wp_json_encode(get_option('dit_ts_custom_fallback_config', ['enable_model_fallback' => true, 'enable_cross_provider_fallback' => false, 'enable_universal_fallback' => false, 'cross_provider_order' => []]))); ?>">
 </td>
</tr>


                <!-- @MODIFIED 2026-06-01 - Removed OpenRouter + Groq standalone configuration (use Custom Providers instead) -->


<tr>
<th scope="row"><?php esc_html_e('Rank Math Integration', 'dit-trend-content-studio'); ?></th>
                    <td>
                        <label for="dit_ts_enable_schema_bridge">
                            <input name="dit_ts_enable_schema_bridge" type="checkbox" id="dit_ts_enable_schema_bridge"
                                value="1" <?php checked(1, get_option('dit_ts_enable_schema_bridge', 1)); ?>>
                            <?php esc_html_e('Enable Automatic Review Schema', 'dit-trend-content-studio'); ?>
                        </label>
                        <p class="description">
                            <?php esc_html_e('If checked, we will auto-inject "Star Ratings" and "Pros/Cons" schema into Rank Math for Commercial articles.', 'dit-trend-content-studio'); ?>
                            <br><strong><?php esc_html_e('Uncheck this', 'dit-trend-content-studio'); ?></strong> <?php esc_html_e('if you prefer to build schema manually in Rank Math.', 'dit-trend-content-studio'); ?>
                        </p>
                    </td>
                </tr>

                <!-- @MODIFIED 2026-02-17 - Phase 4: Structured Output -->
                <tr>
                    <th scope="row">
                        <label for="dit_ts_ai_enforce_structured_output"><?php _e('Structured Output Enforcement', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="dit_ts_ai_enforce_structured_output" id="dit_ts_ai_enforce_structured_output" value="1"
                                <?php checked(get_option('dit_ts_ai_enforce_structured_output', true)); ?>>
                            <?php _e('Enforce strict JSON schema on AI providers (Gemini responseSchema / Perplexity response_format).', 'dit-trend-content-studio'); ?>
                        </label>
                        <p class="description"><?php _e('Prevents the AI from "hallucinating" invalid formats. Highly recommended.', 'dit-trend-content-studio'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="dit_ts_ai_compact_schema_in_prompt"><?php _e('Compact Schema in Prompt', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="dit_ts_ai_compact_schema_in_prompt" id="dit_ts_ai_compact_schema_in_prompt" value="1"
                                <?php checked(get_option('dit_ts_ai_compact_schema_in_prompt', true)); ?>>
                            <?php _e('Send minimal schema in prompt to save tokens (relies on provider enforcement).', 'dit-trend-content-studio'); ?>
                        </label>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="dit_ts_ai_json_repair_attempts"><?php _e('JSON Auto-Repair Attempts', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <input type="number" name="dit_ts_ai_json_repair_attempts" id="dit_ts_ai_json_repair_attempts"
                            class="small-text" min="0" max="5"
                            value="<?php echo esc_attr(get_option('dit_ts_ai_json_repair_attempts', 1)); ?>">
                        <p class="description"><?php _e('If the AI outputs invalid JSON, how many times should we ask it to self-correct? Set to 0 to disable.', 'dit-trend-content-studio'); ?></p>
                    </td>
                </tr>
            </table>
        </div>

        <!-- @MODIFIED 2025-12-14 - Image Suggestion API keys -->
        <div id="tab-images" class="dit-ts-tab-content <?php echo $active_tab === 'images' ? 'active' : ''; ?>">
            <h2 class="title"><?php esc_html_e('Image Suggestions', 'dit-trend-content-studio'); ?></h2>
            <p class="description">
                <?php esc_html_e('Free stock photo APIs for per-section image suggestions. Both are free with registration.', 'dit-trend-content-studio'); ?>
            </p>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="dit_ts_unsplash_api_key"><?php esc_html_e('Unsplash Access Key', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <input type="password" name="dit_ts_unsplash_api_key" id="dit_ts_unsplash_api_key"
                            class="regular-text"
                            value="<?php echo esc_attr(get_option('dit_ts_unsplash_api_key', '')); ?>">
                        <p class="description">
                            <?php esc_html_e('Get free API key from unsplash.com/developers', 'dit-trend-content-studio'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="dit_ts_pexels_api_key"><?php esc_html_e('Pexels API Key', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <input type="password" name="dit_ts_pexels_api_key" id="dit_ts_pexels_api_key"
                            class="regular-text"
                            value="<?php echo esc_attr(get_option('dit_ts_pexels_api_key', '')); ?>">
                        <p class="description">
                            <?php esc_html_e('Get free API key from pexels.com/api', 'dit-trend-content-studio'); ?>
                        </p>
                    </td>
                </tr>
                </tr>
            </table>

            <h2 class="title"><?php esc_html_e('Visual Sourcing APIs (Google Lens / Web)', 'dit-trend-content-studio'); ?></h2>
            <p class="description">
                <?php esc_html_e('Used for auto-fetching reference images before generation.', 'dit-trend-content-studio'); ?>
            </p>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="dit_ts_image_api_provider"><?php esc_html_e('Image Provider', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <select name="dit_ts_image_api_provider" id="dit_ts_image_api_provider">
                            <?php $img_prov = get_option('dit_ts_image_api_provider', 'serpapi'); ?>
                            <option value="serpapi" <?php selected($img_prov, 'serpapi'); ?>><?php esc_html_e('SerpApi (Google Lens / Images)', 'dit-trend-content-studio'); ?></option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="dit_ts_serpapi_key"><?php esc_html_e('SerpApi Key', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <input type="password" name="dit_ts_serpapi_key" id="dit_ts_serpapi_key" class="regular-text" value="<?php echo esc_attr(get_option('dit_ts_serpapi_key', '')); ?>">
                    </td>
                </tr>


            </table>

        </div>

        <div id="tab-trends" class="dit-ts-tab-content <?php echo $active_tab === 'trends' ? 'active' : ''; ?>">
            <h2 class="title"><?php esc_html_e('Trend Discovery APIs', 'dit-trend-content-studio'); ?></h2>
            <p class="description">
                <?php esc_html_e('Free-tier APIs for automated trend discovery. Sign up for free API keys to enable automatic idea imports.', 'dit-trend-content-studio'); ?>
            </p>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="dit_ts_newsapi_key"><?php esc_html_e('NewsAPI Access Key', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <input type="password" name="dit_ts_newsapi_key" id="dit_ts_newsapi_key"
                            class="regular-text"
                            value="<?php echo esc_attr(get_option('dit_ts_newsapi_key', '')); ?>">
                        <p class="description">
                            <?php esc_html_e('Free tier: 100 requests/day. Get your API key from newsapi.org (instant approval).', 'dit-trend-content-studio'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="dit_ts_social_searcher_key"><?php esc_html_e('Social Searcher API Key', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <input type="password" name="dit_ts_social_searcher_key" id="dit_ts_social_searcher_key"
                            class="regular-text"
                            value="<?php echo esc_attr(get_option('dit_ts_social_searcher_key', '')); ?>">
                        <p class="description">
                            <?php esc_html_e('Free tier: 400 requests/day. Get your API key from social-searcher.com/api', 'dit-trend-content-studio'); ?>
                        </p>
                    </td>
                </tr>
            </table>

            <h2 class="title"><?php esc_html_e('RSS Feeds (Optional)', 'dit-trend-content-studio'); ?></h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="dit_ts_rss_feeds"><?php esc_html_e('RSS Feed URLs', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <textarea name="dit_ts_rss_feeds" id="dit_ts_rss_feeds" rows="5" class="large-text"
                            placeholder="<?php esc_attr_e('One URL per line', 'dit-trend-content-studio'); ?>"><?php echo esc_textarea(get_option('dit_ts_rss_feeds', '')); ?></textarea>
                        <p class="description">
                            <?php esc_html_e('Optional. Enter RSS feed URLs, one per line. Example: https://rss.nytimes.com/services/xml/rss/nyt/FashionandStyle.xml', 'dit-trend-content-studio'); ?>
                        </p>
                    </td>
                </tr>
            </table>
        </div>

        <!-- @MODIFIED 2026-02-08 - Multi-Campaign Management -->
        <div id="tab-campaigns" class="dit-ts-tab-content <?php echo $active_tab === 'campaigns' ? 'active' : ''; ?>">
            <h2 class="title"><?php esc_html_e('Multi-Campaign Configuration', 'dit-trend-content-studio'); ?></h2>
            <p class="description">
                <?php esc_html_e('Configure parallel pipelines. Each campaign processes drafts from a specific category using a target content vertical (persona).', 'dit-trend-content-studio'); ?>
            </p>
            <div id="dit-ts-campaigns-list" class="dit-ts-campaigns-list">
                <div class="dit-ts-campaign-header-row">
                    <div class="col-main"><?php esc_html_e('Campaign & Sourcing', 'dit-trend-content-studio'); ?></div>
                    <div class="col-routing"><?php esc_html_e('Vertical & Destination', 'dit-trend-content-studio'); ?></div>
                    <div class="col-schedule"><?php esc_html_e('Schedule', 'dit-trend-content-studio'); ?></div>
                    <div class="col-status"><?php esc_html_e('Status', 'dit-trend-content-studio'); ?></div>
                    <div class="col-actions"><?php esc_html_e('Actions', 'dit-trend-content-studio'); ?></div>
                </div>
                <!-- Cards Populated by JS -->
            </div>
            <button type="button" class="button" id="dit-ts-add-campaign"><?php esc_html_e('Add Campaign', 'dit-trend-content-studio'); ?></button>
            <input type="hidden" name="dit_ts_campaigns" id="dit_ts_campaigns" value="<?php echo esc_attr(get_option('dit_ts_campaigns', '[]')); ?>">
        </div>
        <!-- @MODIFIED 2026-02-10 - Removed extra spacing -->

        <div id="tab-scheduling" class="dit-ts-tab-content <?php echo $active_tab === 'scheduling' ? 'active' : ''; ?>">
            <h2 class="title"><?php esc_html_e('Publishing Schedule', 'dit-trend-content-studio'); ?></h2>
            <p class="description">
                <?php esc_html_e('Configure when AI-generated posts should be delivered. If enabled, posts will be staggered using random intervals within the window.', 'dit-trend-content-studio'); ?>
            </p>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="dit_ts_enable_scheduling"><?php esc_html_e('Enable Scheduling', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="dit_ts_enable_scheduling" id="dit_ts_enable_scheduling" value="1"
                                <?php checked(get_option('dit_ts_enable_scheduling', false)); ?>>
                            <?php esc_html_e('Spread posts across a schedule (instead of immediate Drafts)', 'dit-trend-content-studio'); ?>
                        </label>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="dit_ts_posts_per_day"><?php esc_html_e('Max Posts Per Day', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <input type="number" name="dit_ts_posts_per_day" id="dit_ts_posts_per_day"
                            class="small-text" min="1" max="50"
                            value="<?php echo esc_attr(get_option('dit_ts_posts_per_day', 5)); ?>">
                        <p class="description"><?php esc_html_e('Upper limit for automated publishing per 24h.', 'dit-trend-content-studio'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label><?php esc_html_e('Daily Time Window', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <input type="time" name="dit_ts_publish_start" id="dit_ts_publish_start"
                            value="<?php echo esc_attr(get_option('dit_ts_publish_start', '09:00')); ?>">
                        <?php esc_html_e('to', 'dit-trend-content-studio'); ?>
                        <input type="time" name="dit_ts_publish_end" id="dit_ts_publish_end"
                            value="<?php echo esc_attr(get_option('dit_ts_publish_end', '20:00')); ?>">
                        <p class="description"><?php esc_html_e('Posts will ONLY be shared between these hours (Site Time).', 'dit-trend-content-studio'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label><?php esc_html_e('Random Interval', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
<input type="number" name="dit_ts_min_interval" id="dit_ts_min_interval"
 class="small-text" min="1" max="1440"
 value="<?php echo esc_attr(get_option('dit_ts_min_interval', 60)); ?>">
 <?php esc_html_e('to', 'dit-trend-content-studio'); ?>
 <input type="number" name="dit_ts_max_interval" id="dit_ts_max_interval"
 class="small-text" min="1" max="1440"
 value="<?php echo esc_attr(get_option('dit_ts_max_interval', 240)); ?>">
 <?php esc_html_e('Minutes', 'dit-trend-content-studio'); ?>
 <p class="description"><?php esc_html_e('Minimum and maximum minutes between staggered posts.', 'dit-trend-content-studio'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="dit_ts_media_visual_limit"><?php _e('Max Visuals to Process', 'dit-trend-content-studio'); ?></label></th>
                    <td>
                        <input type="number" name="dit_ts_media_visual_limit" id="dit_ts_media_visual_limit" value="<?php echo esc_attr(get_option('dit_ts_media_visual_limit', 15)); ?>" class="small-text" min="1" max="30">
                        <p class="description"><?php _e('Maximum number of images to select from source content (Default: 15). Lower values save tokens but may miss context.', 'dit-trend-content-studio'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="dit_ts_media_selection_mode"><?php _e('Media Selection Mode', 'dit-trend-content-studio'); ?></label></th>
                    <td>
                        <select name="dit_ts_media_selection_mode" id="dit_ts_media_selection_mode">
                            <option value="smart" <?php selected(get_option('dit_ts_media_selection_mode', 'smart'), 'smart'); ?>><?php _e('Smart Selection (Recommended)', 'dit-trend-content-studio'); ?></option>
                            <option value="legacy" <?php selected(get_option('dit_ts_media_selection_mode', 'smart'), 'legacy'); ?>><?php _e('Legacy (First N)', 'dit-trend-content-studio'); ?></option>
                        </select>
                        <p class="description"><?php _e('Smart Selection scores images based on uniqueness, size, and context. Legacy simply takes the first N images found.', 'dit-trend-content-studio'); ?></p>
                    </td>
                </tr>

                <!-- @MODIFIED 2026-02-25 - Rewrite media localization controls -->
                <tr>
                    <th scope="row"><label for="dit_ts_media_localize_external"><?php _e('Localize External Images (Rewrite)', 'dit-trend-content-studio'); ?></label></th>
                    <td>
                        <label>
                            <input type="checkbox" name="dit_ts_media_localize_external" id="dit_ts_media_localize_external" value="1"
                                <?php checked(get_option('dit_ts_media_localize_external', true)); ?>>
                            <?php esc_html_e('Download hotlinked images to Media Library during rewrite', 'dit-trend-content-studio'); ?>
                        </label>
                        <p class="description"><?php _e('Prevents external hotlinks and makes rename/cap/cleanup deterministic.', 'dit-trend-content-studio'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="dit_ts_media_local_image_mode"><?php _e('Local Image Handling (Rewrite)', 'dit-trend-content-studio'); ?></label></th>
                    <td>
                        <?php $lm = get_option('dit_ts_media_local_image_mode', 'clone'); ?>
                        <select name="dit_ts_media_local_image_mode" id="dit_ts_media_local_image_mode">
                            <option value="clone" <?php selected($lm, 'clone'); ?>><?php _e('Clone (safe / non-destructive)', 'dit-trend-content-studio'); ?></option>
                            <option value="transfer_exclusive" <?php selected($lm, 'transfer_exclusive'); ?>><?php _e('Transfer if Exclusive (no duplicates)', 'dit-trend-content-studio'); ?></option>
                            <option value="transfer_force" <?php selected($lm, 'transfer_force'); ?>><?php _e('FORCE Transfer (danger: can break reused media)', 'dit-trend-content-studio'); ?></option>
                            <option value="keep" <?php selected($lm, 'keep'); ?>><?php _e('Keep (do nothing for local images)', 'dit-trend-content-studio'); ?></option>
                        </select>
                        <p class="description" style="color:#a00; font-weight:500;">
                            <?php _e('Transfer modes reuse the SAME attachment and allow file renames. Use ONLY if your source drafts are truly unique and disposable.', 'dit-trend-content-studio'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="dit_ts_media_placement_mode"><?php esc_html_e('Media Placement Mode', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <?php $pm = get_option('dit_ts_media_placement_mode', 'token_matcher'); ?>
                        <select name="dit_ts_media_placement_mode" id="dit_ts_media_placement_mode">
                            <option value="token_matcher" <?php selected($pm, 'token_matcher'); ?>>
                                <?php esc_html_e('Tokens + Matcher (default)', 'dit-trend-content-studio'); ?>
                            </option>
                            <option value="structured_blocks" <?php selected($pm, 'structured_blocks'); ?>>
                                <?php esc_html_e('Structured Blocks (pro)', 'dit-trend-content-studio'); ?>
                            </option>
                        </select>
                        <p class="description">
                            <?php esc_html_e('Structured Blocks outputs sections[].blocks with visual_ref/embed_ref so the plugin places media deterministically.', 'dit-trend-content-studio'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="dit_ts_enable_retina_collage"><?php _e('Retina Collages (2x)', 'dit-trend-content-studio'); ?></label></th>
                    <td>
                        <label>
                            <input type="checkbox" name="dit_ts_enable_retina_collage" id="dit_ts_enable_retina_collage" value="1"
                                <?php checked(get_option('dit_ts_enable_retina_collage', true)); ?>>
                            <?php esc_html_e('Generate collages at 1400x824 (2x scale) for high-resolution displays.', 'dit-trend-content-studio'); ?>
                        </label>
                        <p class="description">
                            <?php esc_html_e('If unchecked, collages will be generated at 700x412 (1x scale).', 'dit-trend-content-studio'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label><?php esc_html_e('Active Days', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <?php
                        $active_days = get_option('dit_ts_active_days', ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun']);
                        $days = [
                            'mon' => __('Mon', 'dit-trend-content-studio'),
                            'tue' => __('Tue', 'dit-trend-content-studio'),
                            'wed' => __('Wed', 'dit-trend-content-studio'),
                            'thu' => __('Thu', 'dit-trend-content-studio'),
                            'fri' => __('Fri', 'dit-trend-content-studio'),
                            'sat' => __('Sat', 'dit-trend-content-studio'),
                            'sun' => __('Sun', 'dit-trend-content-studio'),
                        ];
                        foreach ($days as $slug => $label) : ?>
                            <label style="margin-right: 10px;">
                                <input type="checkbox" name="dit_ts_active_days[]" value="<?php echo esc_attr($slug); ?>"
                                    <?php checked(in_array($slug, $active_days)); ?>>
                                <?php echo esc_html($label); ?>
                            </label>
                        <?php endforeach; ?>
                    </td>
                </tr>
            </table>
        </div>

        <div id="tab-automation" class="dit-ts-tab-content <?php echo $active_tab === 'automation' ? 'active' : ''; ?>">
            <h2 class="title"><?php esc_html_e('Import Settings', 'dit-trend-content-studio'); ?></h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="dit_ts_import_schedule"><?php esc_html_e('Auto Import Schedule', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <select name="dit_ts_import_schedule" id="dit_ts_import_schedule">
                            <?php $schedule = get_option('dit_ts_import_schedule', 'daily'); ?>
                            <option value="manual" <?php selected($schedule, 'manual'); ?>><?php esc_html_e('Manual Only', 'dit-trend-content-studio'); ?></option>
                            <option value="every_15_mins" <?php selected($schedule, 'every_15_mins'); ?>><?php esc_html_e('Every 15 Minutes', 'dit-trend-content-studio'); ?></option>
                            <option value="every_30_mins" <?php selected($schedule, 'every_30_mins'); ?>><?php esc_html_e('Every 30 Minutes', 'dit-trend-content-studio'); ?></option>
                            <option value="hourly" <?php selected($schedule, 'hourly'); ?>><?php esc_html_e('Hourly', 'dit-trend-content-studio'); ?></option>
                            <option value="daily" <?php selected($schedule, 'daily'); ?>><?php esc_html_e('Daily', 'dit-trend-content-studio'); ?></option>
                        </select>

                        <span id="dit-ts-import-time-wrapper" style="<?php echo $schedule !== 'daily' ? 'display:none;' : ''; ?>">
                            <label for="dit_ts_import_time" style="margin-left: 10px; margin-right: 5px;"><?php esc_html_e('at', 'dit-trend-content-studio'); ?></label>
                            <input type="time" name="dit_ts_import_time" id="dit_ts_import_time"
                                value="<?php echo esc_attr(get_option('dit_ts_import_time', '02:00')); ?>">
                        </span>

                        <button type="button" class="button" id="dit-ts-import-now" style="margin-left: 10px;">
                            <?php esc_html_e('Import Now', 'dit-trend-content-studio'); ?>
                        </button>
                        <span class="import-result"></span>

                        <!-- @MODIFIED 2026-01-25 - Clear Stuck Jobs button -->
                        <button type="button" class="button button-secondary" id="dit-ts-clear-stuck-jobs" style="margin-left: 10px;">
                            <?php esc_html_e('Clear Stuck Jobs', 'dit-trend-content-studio'); ?>
                        </button>
                        <!-- @MODIFIED 2026-01-27 - Added Clear All Jobs button -->
                        <button type="button" class="button button-link-delete" id="dit-ts-clear-all-jobs" style="margin-left: 10px; color: #a00;">
                            <?php esc_html_e('Clear All Jobs', 'dit-trend-content-studio'); ?>
                        </button>
                        <span class="clear-jobs-result"></span>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="dit_ts_import_draft_category"><?php esc_html_e('Draft Post Category Filter', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <input type="text" name="dit_ts_import_draft_category" id="dit_ts_import_draft_category"
                            class="regular-text"
                            value="<?php echo esc_attr(get_option('dit_ts_import_draft_category', '')); ?>"
                            placeholder="<?php esc_attr_e('e.g. showbiz', 'dit-trend-content-studio'); ?>">
                        <p class="description">
                            <?php esc_html_e('Optional. Only import draft posts from this category slug. Leave empty to import all drafts.', 'dit-trend-content-studio'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="dit_ts_worker_limit"><?php esc_html_e('Worker Pool Limit', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <input type="number" name="dit_ts_worker_limit" id="dit_ts_worker_limit"
                            class="small-text" min="1" max="10"
                            value="<?php echo esc_attr(get_option('dit_ts_worker_limit', 1)); ?>">
                        <p class="description">
                            <?php esc_html_e('Max concurrent generations. Set to 1 for safety, 3-5 for high-speed batch processing (requires high AI quota).', 'dit-trend-content-studio'); ?>
                        </p>
                    </td>
                </tr>
            </table>

            <h2 class="title"><?php esc_html_e('Maintenance & Cleanup', 'dit-trend-content-studio'); ?></h2>
            <table class="form-table">
                <!-- @MODIFIED 2026-02-15 - Automated Draft Cleanup -->
                <tr>
                    <th scope="row">
                        <label for="dit_ts_enable_draft_cleanup"><?php esc_html_e('Automated Draft Cleanup', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="dit_ts_enable_draft_cleanup" id="dit_ts_enable_draft_cleanup" value="1"
                                <?php checked(get_option('dit_ts_enable_draft_cleanup', false)); ?>>
                            <?php esc_html_e('Enable automatic deletion of old drafts', 'dit-trend-content-studio'); ?>
                        </label>
                        <p class="description">
                            <?php esc_html_e('Permanently deletes trashed source drafts that have been marked as processed by Trend Studio (after a successful publish). Uses the threshold below for scheduled cleanup.', 'dit-trend-content-studio'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="dit_ts_draft_cleanup_age_days"><?php esc_html_e('Cleanup Threshold (Days)', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <input type="number" name="dit_ts_draft_cleanup_age_days" id="dit_ts_draft_cleanup_age_days"
                            class="small-text" min="1" max="30"
                            value="<?php echo esc_attr(get_option('dit_ts_draft_cleanup_age_days', 7)); ?>">
                        <p class="description">
                            <?php esc_html_e('Drafts older than this many days will be deleted.', 'dit-trend-content-studio'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="dit_ts_draft_cleanup_delete_media"><?php esc_html_e('Delete Associated Media', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="dit_ts_draft_cleanup_delete_media" id="dit_ts_draft_cleanup_delete_media" value="1"
                                <?php checked(get_option('dit_ts_draft_cleanup_delete_media', false)); ?>>
                            <?php esc_html_e('Permanently delete all images/attachments linked to the draft', 'dit-trend-content-studio'); ?>
                        </label>
                        <p class="description" style="color: #a00; font-weight: 500;">
                            <?php esc_html_e('Warning: This will permanently remove images from your site that are only attached to the draft being deleted.', 'dit-trend-content-studio'); ?>
                        </p>
                    </td>
                </tr>

                <!-- @MODIFIED 2026-02-24 - Manual Trash Purge Button -->
                <tr>
                    <th scope="row">
                        <?php esc_html_e('Trash Purge', 'dit-trend-content-studio'); ?>
                    </th>
                    <td>
                        <button type="button" class="button button-secondary" id="dit-ts-purge-trash-now">
                            <?php esc_html_e('Purge Trashed Sources Now', 'dit-trend-content-studio'); ?>
                        </button>
                        <span class="trash-purge-result"></span>
                        <p class="description">
                            <?php esc_html_e('Manually runs the cleanup routine and permanently deletes plugin-marked source drafts currently in Trash (ignores age threshold). Requires "Automated Draft Cleanup" to be enabled.', 'dit-trend-content-studio'); ?>
                        </p>
                    </td>
                </tr>

                <!-- @MODIFIED 2026-02-25 - Orphan Media Purge Button -->
                <tr>
                    <th scope="row">
                        <?php esc_html_e('Orphan Media Cleanup', 'dit-trend-content-studio'); ?>
                    </th>
                    <td>
                        <button type="button" class="button button-secondary" id="dit-ts-purge-orphan-media-now">
                            <?php esc_html_e('Purge Orphan Media Now', 'dit-trend-content-studio'); ?>
                        </button>
                        <span class="orphan-media-purge-result"></span>
                        <p class="description">
                            <?php esc_html_e('Deletes orphan attachments whose parent posts no longer exist (only if not referenced anywhere else). Attachments in use will be detached instead. Requires "Delete Associated Media" to be enabled.', 'dit-trend-content-studio'); ?>
                        </p>
                    </td>
                </tr>


                <!-- @MODIFIED 2026-02-25 - DANGER: Empty Trash (Global) -->
                <tr>
                    <th scope="row">
                        <?php esc_html_e('DANGER: Empty Trash (Global)', 'dit-trend-content-studio'); ?>
                    </th>
                    <td>
                        <label style="display:block; margin-bottom:8px;">
                            <input type="checkbox" id="dit-ts-empty-trash-include-media" checked>
                            <?php esc_html_e('Delete associated media (attachments) too', 'dit-trend-content-studio'); ?>
                        </label>

                        <label style="display:block; margin-bottom:8px; color:#a00; font-weight:600;">
                            <input type="checkbox" id="dit-ts-empty-trash-force-media">
                            <?php esc_html_e('FORCE delete media even if reused elsewhere (can break posts)', 'dit-trend-content-studio'); ?>
                        </label>

                        <label style="display:block; margin-bottom:8px;">
                            <?php esc_html_e('Batch size', 'dit-trend-content-studio'); ?>:
                            <input type="number" id="dit-ts-empty-trash-batch-size" value="25" min="5" max="50" style="width:90px;">
                        </label>

                        <button type="button" class="button button-danger" id="dit-ts-empty-trash-now">
                            <?php esc_html_e('Empty Trash Now (Type DELETE)', 'dit-trend-content-studio'); ?>
                        </button>
                        <span class="empty-trash-result"></span>

                        <p class="description" style="color:#a00; font-weight:600;">
                            <?php esc_html_e('This permanently deletes ALL items currently in Trash (posts/pages/custom types). Media deletion is guarded: reused attachments are detached unless FORCE is enabled.', 'dit-trend-content-studio'); ?>
                        </p>
                    </td>
                </tr>

            </table>
        </div>

        <div id="tab-content" class="dit-ts-tab-content <?php echo $active_tab === 'content' ? 'active' : ''; ?>">
            <h2 class="title"><?php esc_html_e('Content Settings', 'dit-trend-content-studio'); ?></h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="dit_ts_editorial_tone"><?php esc_html_e('Custom Editorial Tone', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <textarea name="dit_ts_editorial_tone" id="dit_ts_editorial_tone" rows="4" class="large-text"
                            placeholder="<?php esc_attr_e('e.g. Write in a sophisticated, slightly witty voice like Vogue. Focus on craftsmanship over price.', 'dit-trend-content-studio'); ?>"><?php echo esc_textarea(get_option('dit_ts_editorial_tone', '')); ?></textarea>
                        <p class="description">
                            <?php esc_html_e('Optional. Provide specific instructions to the AI regarding the writing style, persona, or tone for your articles.', 'dit-trend-content-studio'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="dit_ts_content_vertical"><?php esc_html_e('Default Vertical', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <select name="dit_ts_content_vertical" id="dit_ts_content_vertical">
                            <?php $vertical = get_option('dit_ts_content_vertical', 'showbiz'); ?>
                            <option value="showbiz" <?php selected($vertical, 'showbiz'); ?>><?php esc_html_e('Showbiz - General', 'dit-trend-content-studio'); ?></option>
                            <option value="fashion" <?php selected($vertical, 'fashion'); ?>><?php esc_html_e('Fashion - General', 'dit-trend-content-studio'); ?></option>
                            <option value="beauty" <?php selected($vertical, 'beauty'); ?>><?php esc_html_e('Beauty', 'dit-trend-content-studio'); ?></option>
                            <option value="showbiz_pk" <?php selected($vertical, 'showbiz_pk'); ?>><?php esc_html_e('Showbiz - PK', 'dit-trend-content-studio'); ?></option>
                            <option value="fashion_pk" <?php selected($vertical, 'fashion_pk'); ?>><?php esc_html_e('Fashion - PK', 'dit-trend-content-studio'); ?></option>
                        </select>
                    </td>
                </tr>
                <!-- Collage Settings (Moved from Images Tab) -->
                <tr>
                    <th scope="row">
                        <label for="dit_ts_collage_retina"><?php esc_html_e('Collage: High Res', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="dit_ts_collage_retina" id="dit_ts_collage_retina" value="1"
                                <?php checked(get_option('dit_ts_collage_retina', true)); ?>>
                            <?php esc_html_e('Generate at 1400x824 (2x scale)', 'dit-trend-content-studio'); ?>
                        </label>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="dit_ts_collage_bottom_text"><?php esc_html_e('Collage: Bottom Bar', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <input type="text" name="dit_ts_collage_bottom_text" id="dit_ts_collage_bottom_text"
                            class="widefat"
                            value="<?php echo esc_attr(get_option('dit_ts_collage_bottom_text', 'DailyInfoTainment.Com')); ?>"
                            placeholder="e.g. DailyInfoTainment.Com">
                        <p class="description">
                            <?php esc_html_e('Text for the professional bottom bar.', 'dit-trend-content-studio'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="dit_ts_enable_ai_images"><?php esc_html_e('AI-Generated Visuals', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="dit_ts_enable_ai_images" id="dit_ts_enable_ai_images" value="1"
                                <?php checked(get_option('dit_ts_enable_ai_images', false)); ?>>
                            <?php esc_html_e('Automatically generate images using Google Nano Banana (Imagen 3)', 'dit-trend-content-studio'); ?>
                        </label>
                        <p class="description">
                            <?php esc_html_e('Requires a valid Gemini API key. Images will be generated automatically based on section context.', 'dit-trend-content-studio'); ?>
                        </p>
                    </td>
                </tr>
                <!-- @MODIFIED 2025-12-26 - Phase 4: Strict Inline Citations setting -->
                <tr>
                    <th scope="row">
                        <label for="dit_ts_strict_inline_citations"><?php esc_html_e('Strict Inline Citations', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="dit_ts_strict_inline_citations" id="dit_ts_strict_inline_citations" value="1"
                                <?php checked(get_option('dit_ts_strict_inline_citations', false)); ?>>
                            <?php esc_html_e('Require [N] inline citations for every factual claim', 'dit-trend-content-studio'); ?>
                        </label>
                        <p class="description">
                            <?php esc_html_e('When enabled, the AI will add numbered inline citations [1], [2], etc. to every factual claim. Uncited claims will trigger a repair pass.', 'dit-trend-content-studio'); ?>
                        </p>
                    </td>
                </tr>
                <!-- @MODIFIED 2026-02-14 - Social Media Blacklist -->
                <tr>
                    <th scope="row">
                        <label for="dit_ts_smn_blacklist"><?php esc_html_e('Social Media Blacklist', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <textarea name="dit_ts_smn_blacklist" id="dit_ts_smn_blacklist" rows="5" class="large-text"
                            placeholder="<?php esc_attr_e('Enter URLs or usernames to block (one per line). Example: youtube.com/channel/UC123...', 'dit-trend-content-studio'); ?>"><?php echo esc_textarea(get_option('dit_ts_smn_blacklist', '')); ?></textarea>
                        <p class="description">
                            <?php esc_html_e('Any embedded content matching these terms (including Channel URLs) will be removed from generated posts.', 'dit-trend-content-studio'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="dit_ts_enable_logging"><?php esc_html_e('Enable Logging', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <label>
                            <input type="checkbox" name="dit_ts_enable_logging" id="dit_ts_enable_logging" value="1"
                                <?php checked(get_option('dit_ts_enable_logging', true)); ?>>
                            <?php esc_html_e('Log plugin activity for debugging', 'dit-trend-content-studio'); ?>
                        </label>
                    </td>
                </tr>
            </table>
        </div>

        <?php
        // @MODIFIED 2026-02-25 - Persist last smoke test JSON for rendering without rerun
        $last_smoke_json = (string) get_option('dit_ts_last_smoke_test', '');
        ?>

        <div id="tab-diagnostics" class="dit-ts-tab-content <?php echo $active_tab === 'diagnostics' ? 'active' : ''; ?>">
            <h2 class="title"><?php esc_html_e('Diagnostics & Smoke Test', 'dit-trend-content-studio'); ?></h2>

            <!-- Dashboard Integration Section -->
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="dit_ts_dashboard_api_key"><?php esc_html_e('Dashboard API Key', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <input type="text" name="dit_ts_dashboard_api_key" id="dit_ts_dashboard_api_key"
                            class="regular-text code" value="<?php echo esc_attr(get_option('dit_ts_dashboard_api_key', '')); ?>" placeholder="<?php esc_attr_e('Auto-generate or enter manually', 'dit-trend-content-studio'); ?>">
                        <p class="description">
                            <?php esc_html_e('API key for the Universal Plugin Dashboard to access this site\'s metrics. Leave empty to auto-generate on save.', 'dit-trend-content-studio'); ?>
                        </p>
                        <button type="button" class="button button-secondary" id="dit-ts-generate-dashboard-key">
                            <?php esc_html_e('Generate New Key', 'dit-trend-content-studio'); ?>
                        </button>
                    </td>
                </tr>
            </table>

            <hr />

            <p class="description">
                <?php esc_html_e('Runs a non-destructive diagnostic suite to validate file integrity, autoloadability, DB schema, scheduling hooks, and the local (no API calls) content pipeline stages.', 'dit-trend-content-studio'); ?>
            </p>

            <textarea id="dit-ts-smoke-test-last-json" style="display:none;"><?php echo esc_textarea($last_smoke_json); ?></textarea>

            <p>
                <button type="button" class="button button-primary" id="dit-ts-run-smoke-test">
                    <?php esc_html_e('Run Smoke Test', 'dit-trend-content-studio'); ?>
                </button>
                <button type="button" class="button" id="dit-ts-copy-smoke-test" disabled>
                    <?php esc_html_e('Copy JSON', 'dit-trend-content-studio'); ?>
                </button>
                <span class="dit-ts-smoke-test-summary"></span>
            </p>

            <div id="dit-ts-smoke-test-results"></div>
        </div>

<div id="tab-social" class="dit-ts-tab-content <?php echo $active_tab === 'social' ? 'active' : ''; ?>">
    <h2 class="title"><?php esc_html_e('Social Media Integration', 'dit-trend-content-studio'); ?></h2>
    <p class="description">
        <?php esc_html_e('Manage automatic social media message formatting for plugins like Jetpack Social.', 'dit-trend-content-studio'); ?>
    </p>
    <table class="form-table">
        <tr>
            <th scope="row">
                <label for="dit_ts_enable_social_collage"><?php esc_html_e('Auto-Generate Social Collages', 'dit-trend-content-studio'); ?></label>
            </th>
            <td>
                <label>
                    <input type="checkbox" name="dit_ts_enable_social_collage" id="dit_ts_enable_social_collage" value="1" <?php checked(get_option('dit_ts_enable_social_collage', false), true); ?>>
                    <?php esc_html_e('Automatically generate a 4:5 Urdu social collage when a post is published.', 'dit-trend-content-studio'); ?>
                </label>
            </td>
        </tr>
        <tr>
<th scope="row">
<label for="dit_ts_jetpack_enabled"><?php esc_html_e('Enable Jetpack Integration', 'dit-trend-content-studio'); ?></label>
</th>
<td>
<label>
<input type="checkbox" name="dit_ts_jetpack_enabled" id="dit_ts_jetpack_enabled" value="1"
<?php checked(get_option('dit_ts_jetpack_enabled', false)); ?>>
<?php esc_html_e('Automatically populate Jetpack Social message with Urdu content.', 'dit-trend-content-studio'); ?>
</label>
</td>
</tr>
<tr>
<th scope="row">
<label for="dit_ts_jetpack_template"><?php esc_html_e('Social Sharing Template', 'dit-trend-content-studio'); ?></label>
</th>
<td>
<?php
$default_template = "{urdu_head}\n\n{urdu_desc}\n\n{hashtags}\n\n{link}";
$template = get_option('dit_ts_jetpack_template', $default_template);
?>
<textarea name="dit_ts_jetpack_template" id="dit_ts_jetpack_template" rows="8" class="large-text"
placeholder="<?php echo esc_attr($default_template); ?>"><?php echo esc_textarea($template); ?></textarea>
<p class="description">
<?php esc_html_e('Placeholder tags: {urdu_head}, {urdu_desc}, {hashtags}, {link}', 'dit-trend-content-studio'); ?>
</p>
</td>
</tr>
</table>

<h3 style="margin-top: 30px;"><?php esc_html_e('Link Whisper Integration', 'dit-trend-content-studio'); ?></h3>
<p class="description">
    <?php esc_html_e('Auto-inject contextual internal links into generated posts via Link Whisper Premium. Requires Link Whisper Premium to be installed and active.', 'dit-trend-content-studio'); ?>
</p>
<table class="form-table">
    <tr>
        <th scope="row">
            <label for="dit_ts_lw_integration_enabled"><?php esc_html_e('Enable Link Whisper Integration', 'dit-trend-content-studio'); ?></label>
        </th>
        <td>
            <label>
                <input type="checkbox" name="dit_ts_lw_integration_enabled" id="dit_ts_lw_integration_enabled" value="1" <?php checked(get_option('dit_ts_lw_integration_enabled', 0), 1); ?>>
                <?php esc_html_e('Inject contextual internal links into generated posts using Link Whisper\'s NLP engine.', 'dit-trend-content-studio'); ?>
            </label>
        </td>
    </tr>
    <tr>
        <th scope="row">
            <label for="dit_ts_lw_max_links_per_post"><?php esc_html_e('Max Links Per Post', 'dit-trend-content-studio'); ?></label>
        </th>
        <td>
            <input type="number" min="1" max="10" name="dit_ts_lw_max_links_per_post" id="dit_ts_lw_max_links_per_post" value="<?php echo esc_attr(get_option('dit_ts_lw_max_links_per_post', 2)); ?>" class="small-text">
            <p class="description"><?php esc_html_e('Cap on internal links the bridge will insert into a single post. Default: 2.', 'dit-trend-content-studio'); ?></p>
        </td>
    </tr>
    <tr>
        <th scope="row">
            <label for="dit_ts_lw_skip_callouts"><?php esc_html_e('Skip Editorial Callouts', 'dit-trend-content-studio'); ?></label>
        </th>
        <td>
            <label>
                <input type="checkbox" name="dit_ts_lw_skip_callouts" id="dit_ts_lw_skip_callouts" value="1" <?php checked(get_option('dit_ts_lw_skip_callouts', 1), 1); ?>>
                <?php esc_html_e('Do not insert links inside the editor\'s "dit-ts-callout" group block.', 'dit-trend-content-studio'); ?>
            </label>
        </td>
    </tr>
</table>

<h3 style="margin-top: 30px;"><?php esc_html_e('Jetpack Network Controls', 'dit-trend-content-studio'); ?></h3>
<p class="description">
    <?php esc_html_e('Customize which Jetpack-connected social networks to share to and define unique messages for each.', 'dit-trend-content-studio'); ?>
</p>
<table class="form-table">
    <?php
    $jetpack_networks = [
        'facebook'  => 'Facebook',
        'instagram' => 'Instagram',
        'threads'   => 'Threads',
        'linkedin'  => 'LinkedIn',
        'tumblr'    => 'Tumblr',
        'mastodon'  => 'Mastodon',
        'nextdoor'  => 'Nextdoor',
        'bluesky'   => 'Bluesky',
    ];
    $enabled_networks = get_option('dit_ts_jetpack_networks', []);
    $network_templates = get_option('dit_ts_jetpack_network_templates', []);

    // If main Jetpack is enabled, but no per-network options are saved, default all to enabled for BC
    $jetpack_global_enabled = get_option('dit_ts_jetpack_enabled', false);
    if ($jetpack_global_enabled && empty($enabled_networks)) {
        foreach ($jetpack_networks as $key => $name) {
            $enabled_networks[$key] = true;
        }
    }
    ?>
    <?php foreach ($jetpack_networks as $key => $name) : ?>
        <tr>
            <th scope="row">
                <label for="dit_ts_jetpack_networks_<?php echo esc_attr($key); ?>">
                    <?php echo esc_html($name); ?>
                </label>
            </th>
            <td>
                <fieldset>
                    <label>
                        <input type="checkbox"
                               name="dit_ts_jetpack_networks[<?php echo esc_attr($key); ?>]"
                               id="dit_ts_jetpack_networks_<?php echo esc_attr($key); ?>"
                               value="1"
                            <?php checked(isset($enabled_networks[$key]) ? $enabled_networks[$key] : false); ?>>
                        <?php esc_html_e('Enable sharing to ' . $name, 'dit-trend-content-studio'); ?>
                    </label>
                    <br><br>
                    <label for="dit_ts_jetpack_network_templates_<?php echo esc_attr($key); ?>">
                        <?php esc_html_e('Custom Message for ' . $name, 'dit-trend-content-studio'); ?>:
                    </label>
                    <?php
                    // Only show the ACTUAL saved per-network template — never pre-fill with global
                    // so that saving doesn't accidentally overwrite with the global template
                    $network_template = $network_templates[$key] ?? '';
                    ?>
                    <textarea name="dit_ts_jetpack_network_templates[<?php echo esc_attr($key); ?>]"
                              id="dit_ts_jetpack_network_templates[<?php echo esc_attr($key); ?>]"
                              rows="4" class="large-text"
                              placeholder="<?php echo esc_attr($default_template); ?>"><?php echo esc_textarea($network_template); ?></textarea>
                    <p class="description">
                        <?php esc_html_e('Leave empty to use the global template above. Only enter a value here if you want a DIFFERENT message for this network. Placeholder tags: {urdu_head}, {urdu_desc}, {hashtags}, {link}', 'dit-trend-content-studio'); ?>
                    </p>
                </fieldset>
            </td>
        </tr>
    <?php endforeach; ?>
</table>

<hr>
<h2><?php esc_html_e('Buffer API Integration', 'dit-trend-content-studio'); ?></h2>
<p class="description">
    <?php esc_html_e('Share posts to social media via Buffer. Can be used alongside Jetpack for multi-platform distribution.', 'dit-trend-content-studio'); ?>
</p>

<?php include DIT_TS_PLUGIN_DIR . 'src/Admin/Views/buffer-settings.php'; ?>

<hr>
<h2><?php esc_html_e('Social Collage Aesthetics', 'dit-trend-content-studio'); ?></h2>
<p class="description"><?php esc_html_e('Configure the exact branding colors and typography used specifically for the Urdu text bands on your social media collages.', 'dit-trend-content-studio'); ?></p>
<table class="form-table">
<?php
$font_dir = DIT_TS_PLUGIN_DIR . 'assets/fonts/';
$available_fonts = glob($font_dir . '*.ttf') ?: [];
$current_font = get_option('dit_ts_social_font', 'NotoNastaliqUrdu-Regular.ttf');
?>
<tr>
<th scope="row"><label for="dit_ts_social_font"><?php esc_html_e('Urdu Font Face', 'dit-trend-content-studio'); ?></label></th>
<td>
<select name="dit_ts_social_font" id="dit_ts_social_font">
<?php foreach ($available_fonts as $font_path): $font_file = basename($font_path); ?>
<option value="<?php echo esc_attr($font_file); ?>" <?php selected($current_font, $font_file); ?>>
<?php echo esc_html($font_file); ?>
</option>
<?php endforeach; ?>
</select>
<p class="description"><?php esc_html_e('Select the specific TTF file used to render HD Nastaliq or Arabic text.', 'dit-trend-content-studio'); ?></p>
</td>
</tr>
<tr>
<th scope="row"><label for="dit_ts_social_heading_bg"><?php esc_html_e('Heading Band Background', 'dit-trend-content-studio'); ?></label></th>
<td>
<input type="text" name="dit_ts_social_heading_bg" id="dit_ts_social_heading_bg"
value="<?php echo esc_attr(get_option('dit_ts_social_heading_bg', '#0f1c34')); ?>"
class="dit-color-picker" data-default-color="#0f1c34" />
</td>
</tr>
<tr>
<th scope="row"><label for="dit_ts_social_heading_color"><?php esc_html_e('Heading Text Color', 'dit-trend-content-studio'); ?></label></th>
<td>
<input type="text" name="dit_ts_social_heading_color" id="dit_ts_social_heading_color"
value="<?php echo esc_attr(get_option('dit_ts_social_heading_color', '#ffffff')); ?>"
class="dit-color-picker" data-default-color="#ffffff" />
</td>
</tr>
<tr>
<th scope="row"><label for="dit_ts_social_desc_bg"><?php esc_html_e('Description Band Background', 'dit-trend-content-studio'); ?></label></th>
<td>
<input type="text" name="dit_ts_social_desc_bg" id="dit_ts_social_desc_bg"
value="<?php echo esc_attr(get_option('dit_ts_social_desc_bg', '#500f19')); ?>"
class="dit-color-picker" data-default-color="#500f19" />
</td>
</tr>
            <tr>
                <th scope="row"><label for="dit_ts_social_desc_color"><?php esc_html_e('Description Text Color', 'dit-trend-content-studio'); ?></label></th>
                <td>
                    <input type="text" name="dit_ts_social_desc_color" id="dit_ts_social_desc_color"
                           value="<?php echo esc_attr(get_option('dit_ts_social_desc_color', '#ffffff')); ?>"
                           class="dit-color-picker" data-default-color="#ffffff" />
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="dit_ts_social_h_size"><?php esc_html_e('Heading Font Size', 'dit-trend-content-studio'); ?></label></th>
                <td>
                    <input type="number" name="dit_ts_social_h_size" id="dit_ts_social_h_size"
                           value="<?php echo esc_attr(get_option('dit_ts_social_h_size', 36)); ?>"
                           min="14" max="72" step="1" style="width: 80px;" /> px
                    <p class="description"><?php esc_html_e('Font size for the heading band (14-72px). Default: 36px', 'dit-trend-content-studio'); ?></p>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="dit_ts_social_d_size"><?php esc_html_e('Description Font Size', 'dit-trend-content-studio'); ?></label></th>
                <td>
                    <input type="number" name="dit_ts_social_d_size" id="dit_ts_social_d_size"
                           value="<?php echo esc_attr(get_option('dit_ts_social_d_size', 26)); ?>"
                           min="14" max="72" step="1" style="width: 80px;" /> px
                            <p class="description"><?php esc_html_e('Font size for the description band (14-72px). Default: 26px', 'dit-trend-content-studio'); ?></p>
                        </td>
                    </tr>
                </table>

                <hr>
                <h3><?php esc_html_e('Section Proportions', 'dit-trend-content-studio'); ?></h3>
                <p class="description"><?php esc_html_e('Control how much of the social collage height each section occupies. Values are approximate percentages — the system normalizes them so they always sum to 100%. Default: Image 50% / Heading 20% / Description 20% / Brand Bar 10%.', 'dit-trend-content-studio'); ?></p>
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="dit_ts_social_image_pct"><?php esc_html_e('Image Area Height', 'dit-trend-content-studio'); ?></label></th>
                        <td>
                            <input type="number" name="dit_ts_social_image_pct" id="dit_ts_social_image_pct"
                                   value="<?php echo esc_attr(get_option('dit_ts_social_image_pct', 50)); ?>"
                                   min="10" max="80" step="1" style="width: 80px;" /> %
                            <p class="description"><?php esc_html_e('Height for the top image section (10-80%). Default: 50%', 'dit-trend-content-studio'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="dit_ts_social_heading_pct"><?php esc_html_e('Heading Band Height', 'dit-trend-content-studio'); ?></label></th>
                        <td>
                            <input type="number" name="dit_ts_social_heading_pct" id="dit_ts_social_heading_pct"
                                   value="<?php echo esc_attr(get_option('dit_ts_social_heading_pct', 20)); ?>"
                                   min="5" max="50" step="1" style="width: 80px;" /> %
                            <p class="description"><?php esc_html_e('Height for the heading band (5-50%). Default: 20%', 'dit-trend-content-studio'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="dit_ts_social_desc_pct"><?php esc_html_e('Description Band Height', 'dit-trend-content-studio'); ?></label></th>
                        <td>
                            <input type="number" name="dit_ts_social_desc_pct" id="dit_ts_social_desc_pct"
                                   value="<?php echo esc_attr(get_option('dit_ts_social_desc_pct', 20)); ?>"
                                   min="5" max="50" step="1" style="width: 80px;" /> %
                            <p class="description"><?php esc_html_e('Height for the description band (5-50%). Default: 20%', 'dit-trend-content-studio'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="dit_ts_social_bar_pct"><?php esc_html_e('Brand Bar Height', 'dit-trend-content-studio'); ?></label></th>
                        <td>
                            <input type="number" name="dit_ts_social_bar_pct" id="dit_ts_social_bar_pct"
                                   value="<?php echo esc_attr(get_option('dit_ts_social_bar_pct', 10)); ?>"
                                   min="5" max="30" step="1" style="width: 80px;" /> %
                            <p class="description"><?php esc_html_e('Height for the bottom brand bar (5-30%). Default: 10%', 'dit-trend-content-studio'); ?></p>
                        </td>
                    </tr>
            <tr>
                <th scope="row"><label for="dit_ts_social_radius"><?php esc_html_e('Corner Radius', 'dit-trend-content-studio'); ?></label></th>
                <td>
                    <input type="number" name="dit_ts_social_radius" id="dit_ts_social_radius"
                           value="<?php echo esc_attr(get_option('dit_ts_social_radius', 0)); ?>"
                           min="0" max="60" step="2" style="width: 80px;" /> px
                    <p class="description"><?php esc_html_e('Rounded corners for image tiles (0-60px). Default: 0px', 'dit-trend-content-studio'); ?></p>
                </td>
            </tr>
        </table>

<!-- @MODIFIED 2026-05-05 - Brand Bar Configuration section -->
<hr>
<h3><?php esc_html_e('Brand Bar Configuration', 'dit-trend-content-studio'); ?></h3>
<p class="description"><?php esc_html_e('Configure the bottom brand bar that appears on all auto-generated social collages. Includes logo, text, colors, and typography.', 'dit-trend-content-studio'); ?></p>
<table class="form-table">
    <tr>
        <th scope="row"><label for="dit_ts_brand_bar_text"><?php esc_html_e('Brand Text', 'dit-trend-content-studio'); ?></label></th>
        <td>
            <input type="text" name="dit_ts_brand_bar_text" id="dit_ts_brand_bar_text"
                   value="<?php echo esc_attr(get_option('dit_ts_brand_bar_text', get_bloginfo('name'))); ?>"
                   class="regular-text" placeholder="<?php echo esc_attr(get_bloginfo('name')); ?>" />
            <p class="description"><?php esc_html_e('Text displayed on the brand bar (e.g. site name, tagline, or "TREND STUDIO | FASHION").', 'dit-trend-content-studio'); ?></p>
        </td>
    </tr>
    <tr>
        <th scope="row"><label for="dit_ts_brand_bar_color"><?php esc_html_e('Bar Background Color', 'dit-trend-content-studio'); ?></label></th>
        <td>
            <input type="text" name="dit_ts_brand_bar_color" id="dit_ts_brand_bar_color"
                   value="<?php echo esc_attr(get_option('dit_ts_brand_bar_color', '#1a1a2e')); ?>"
                   class="dit-color-picker" data-default-color="#1a1a2e" />
        </td>
    </tr>
    <tr>
        <th scope="row"><label for="dit_ts_brand_bar_text_color"><?php esc_html_e('Bar Text Color', 'dit-trend-content-studio'); ?></label></th>
        <td>
            <input type="text" name="dit_ts_brand_bar_text_color" id="dit_ts_brand_bar_text_color"
                   value="<?php echo esc_attr(get_option('dit_ts_brand_bar_text_color', '#ffffff')); ?>"
                   class="dit-color-picker" data-default-color="#ffffff" />
        </td>
    </tr>
    <tr>
        <th scope="row"><label for="dit_ts_brand_logo_id"><?php esc_html_e('Brand Logo', 'dit-trend-content-studio'); ?></label></th>
        <td>
            <?php
            $logo_id = (int) get_option('dit_ts_brand_logo_id', 0);
            $logo_url = $logo_id ? wp_get_attachment_url($logo_id) : '';
            ?>
            <input type="hidden" name="dit_ts_brand_logo_id" id="dit_ts_brand_logo_id" value="<?php echo esc_attr($logo_id); ?>" />
            <div id="dit-ts-brand-logo-preview" style="margin-bottom: 8px;">
                <?php if ($logo_url): ?>
                    <img src="<?php echo esc_url($logo_url); ?>" style="max-height: 50px; border: 1px solid #ddd; padding: 4px; border-radius: 3px;" />
                <?php endif; ?>
            </div>
            <button type="button" class="button" id="dit-ts-brand-logo-upload"><?php esc_html_e('Select Logo', 'dit-trend-content-studio'); ?></button>
            <button type="button" class="button" id="dit-ts-brand-logo-remove" <?php echo $logo_id ? '' : 'style="display:none;"'; ?>><?php esc_html_e('Remove', 'dit-trend-content-studio'); ?></button>
            <p class="description"><?php esc_html_e('Small logo displayed on the left side of the brand bar. Recommended: transparent PNG, 200x60px or similar.', 'dit-trend-content-studio'); ?></p>
        </td>
    </tr>
    <tr>
        <th scope="row"><label for="dit_ts_brand_bar_font_size"><?php esc_html_e('Bar Font Size', 'dit-trend-content-studio'); ?></label></th>
        <td>
            <input type="number" name="dit_ts_brand_bar_font_size" id="dit_ts_brand_bar_font_size"
                   value="<?php echo esc_attr(get_option('dit_ts_brand_bar_font_size', 24)); ?>"
                   min="12" max="48" step="1" style="width: 80px;" /> px
            <p class="description"><?php esc_html_e('Font size for brand bar text (12-48px). Default: 24px', 'dit-trend-content-studio'); ?></p>
        </td>
    </tr>
    <tr>
        <th scope="row"><label for="dit_ts_brand_bar_letter_spacing"><?php esc_html_e('Letter Spacing', 'dit-trend-content-studio'); ?></label></th>
        <td>
            <input type="number" name="dit_ts_brand_bar_letter_spacing" id="dit_ts_brand_bar_letter_spacing"
                   value="<?php echo esc_attr(get_option('dit_ts_brand_bar_letter_spacing', 10)); ?>"
                   min="0" max="30" step="1" style="width: 80px;" /> px
            <p class="description"><?php esc_html_e('Space between characters in brand bar (0-30px). Default: 10px', 'dit-trend-content-studio'); ?></p>
        </td>
    </tr>
    <tr>
        <th scope="row"><label><?php esc_html_e('Accent Line', 'dit-trend-content-studio'); ?></label></th>
        <td>
            <label>
                <input type="checkbox" name="dit_ts_brand_bar_accent_line" value="1" <?php checked(get_option('dit_ts_brand_bar_accent_line', false)); ?> />
                <?php esc_html_e('Show gold accent line at top of brand bar', 'dit-trend-content-studio'); ?>
            </label>
        </td>
    </tr>
</table>
<script>
jQuery(function($){
    $('#dit-ts-brand-logo-upload').on('click', function(e){
        e.preventDefault();
        var frame = wp.media({title:'Select Brand Logo',button:{text:'Use as Logo'},multiple:false,library:{type:'image'}});
        frame.on('select', function(){
            var att = frame.state().get('selection').first().toJSON();
            $('#dit_ts_brand_logo_id').val(att.id);
            $('#dit-ts-brand-logo-preview').html('<img src="'+att.url+'" style="max-height:50px;border:1px solid #ddd;padding:4px;border-radius:3px;" />');
            $('#dit-ts-brand-logo-remove').show();
        });
        frame.open();
    });
    $('#dit-ts-brand-logo-remove').on('click', function(e){
        e.preventDefault();
        $('#dit_ts_brand_logo_id').val('0');
        $('#dit-ts-brand-logo-preview').html('');
        $(this).hide();
    });

    // Dashboard API Key Generator
    $('#dit-ts-generate-dashboard-key').on('click', function() {
        var button = $(this);
        var keyInput = $('#dit_ts_dashboard_api_key');

        button.prop('disabled', true).text('<?php esc_html_e('Generating...', 'dit-trend-content-studio'); ?>');

        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'dit_ts_generate_dashboard_key',
                nonce: ditTsAdmin.nonce
            },
            success: function(response) {
                if (response.success) {
                    keyInput.val(response.data.key);
                    button.text('<?php esc_html_e('Generated!', 'dit-trend-content-studio'); ?>');
                    setTimeout(function() {
                        button.prop('disabled', false).text('<?php esc_html_e('Generate New Key', 'dit-trend-content-studio'); ?>');
                    }, 2000);
                } else {
                    alert('Error: ' + response.data.message);
                    button.prop('disabled', false).text('<?php esc_html_e('Generate New Key', 'dit-trend-content-studio'); ?>');
                }
            },
            error: function() {
                alert('<?php esc_html_e('AJAX error. Please try again.', 'dit-trend-content-studio'); ?>');
                button.prop('disabled', false).text('<?php esc_html_e('Generate New Key', 'dit-trend-content-studio'); ?>');
            }
        });
    });

    $('#dit-ts-brand-logo-remove').on('click', function(e){
        e.preventDefault();
        $('#dit_ts_brand_logo_id').val('0');
        $('#dit-ts-brand-logo-preview').html('');
        $(this).hide();
    });
});
</script>

<div style="margin-top: 20px; padding: 15px; background: #fff; border: 1px solid #ccd0d4; border-radius: 4px;">
<h4><?php \esc_html_e('What happens after approval?', 'dit-trend-content-studio'); ?></h4>
<p><?php \esc_html_e('When you click "Sync & Close" in the Social Queue, TrendStudio will:', 'dit-trend-content-studio'); ?></p>
<ol>
<li><?php \esc_html_e('Synchronize Urdu assets and metadata for social sharing.', 'dit-trend-content-studio'); ?></li>
<li><?php \esc_html_e('Update the Jetpack message field using the template above.', 'dit-trend-content-studio'); ?></li>
<li><?php \esc_html_e('The post remains as Published or Scheduled (it is NO LONGER forced to draft status).', 'dit-trend-content-studio'); ?></li>
</ol>
<p class="description" style="margin-top: 10px; border-top: 1px solid #eee; padding-top: 10px; font-style: italic;">
<?php \esc_html_e('Note: Social collage generation is now decoupled and can be done manually via the Collage Maker.', 'dit-trend-content-studio'); ?>
</p>
</div>
</div>

<p class="submit">
<input type="submit" name="dit_ts_save_settings" class="button button-primary"
value="<?php esc_attr_e('Save Settings', 'dit-trend-content-studio'); ?>">
</p>
</form>
</div>