<?php
namespace SEO_Article_Generator\Queue;

use SEO_Article_Generator\Discovery\Discovery_Processor;
use function add_action;
use function add_filter;
use function has_action;
use function did_action;
use function is_admin;
use function current_user_can;
use function wp_send_json_success;
use function wp_send_json_error;
use function get_current_user_id;
use function check_ajax_referer;
use function wp_remote_post;
use function wp_remote_retrieve_body;
use function wp_remote_retrieve_response_code;
use function wp_json_encode;
use function is_wp_error;
use function update_post_meta;
use function get_post_meta;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Define DAY_IN_SECONDS if not already defined by WordPress
if ( ! defined( 'DAY_IN_SECONDS' ) ) {
	define( 'DAY_IN_SECONDS', 86400 );
}

final class AS_Registry {
	public const GROUP                    = 'seo-gen';
	
	// Discovery Pipeline Hooks
	public const HOOK_PROCESS_ITEM        = 'seo_gen_process_discovery_item';
	public const HOOK_CHECK_JOB           = 'seo_gen_check_discovery_job';
	public const HOOK_SIDELOAD_IMAGE      = 'seo_gen_sideload_featured_image';

	// Engine / Scanner Hooks
	public const HOOK_PASSIVE_DISCOVERY   = 'seo_gen_passive_discovery';
	public const HOOK_ACTIVE_DISCOVERY    = 'seo_gen_active_ai_discovery';
	public const HOOK_WP_AUTO_DRAFT_POLL  = 'seo_gen_wp_auto_draft_poll';

	// Queue / Maintenance Hooks
	public const HOOK_QUEUE_WORKER        = 'seo_gen_queue_worker';
	public const HOOK_QUEUE_CLEANUP       = 'seo_gen_queue_cleanup';
	public const HOOK_AUTO_GEN_CRON       = 'seo_gen_auto_generation_cron';
	public const HOOK_DAILY_CLEANUP       = 'seo_gen_canonical_cleanup';
	public const HOOK_DELETE_DRAFT       = 'seo_gen_delete_draft_post';
	public const HOOK_PUBLISH_WATCHDOG   = 'seo_gen_publish_watchdog';
	public const HOOK_SYNC_OPENROUTER     = 'seo_gen_sync_openrouter_models';
	public const HOOK_SYNC_ZEN             = 'seo_gen_sync_zen_models';
	// @MODIFIED 2026-07-23 - Sync Finalizer + Force Finalize hooks.
	// HOOK_FORCE_FINALIZE is intentionally EXCLUDED from cancel_item_actions()
	// because its lifecycle is decoupled from the per-item process/check-job cycle.
	public const HOOK_SYNC_FINALIZER     = 'seo_gen_sync_finalizer';
	public const HOOK_FORCE_FINALIZE    = 'seo_gen_force_finalize';

	/**
	 * @var Discovery_Processor
	 */
	private $processor;

	public function __construct( ?Discovery_Processor $processor = null ) {
		if ( $processor ) {
			$this->processor = $processor;
		}
	}

	public function register(): void
	{
		if (! $this->processor) {
			return;
		}

		// Process-item actions are now item-scoped, and carry the triggering User ID for attribution.
		$this->add_listener(self::HOOK_PROCESS_ITEM, array($this->processor, 'process_item_background'), 10, 2);
		$this->add_listener(self::HOOK_CHECK_JOB, array($this->processor, 'check_and_finalize_job'), 10, 4);
		$this->add_listener(self::HOOK_SIDELOAD_IMAGE, array($this->processor, 'sideload_featured_image'), 10, 5);
	}

	private function add_listener( string $hook, $callback, int $priority = 10, int $accepted_args = 1 ): void {
		if ( false === has_action( $hook, $callback ) ) {
			add_action( $hook, $callback, $priority, $accepted_args );
		}
	}

	// --- Discovery Schedulers ---

	public static function schedule_process_item(int $item_id, int $user_id = 0, int $delay_seconds = 0): bool
	{
		$timestamp = \SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts() + \max(0, $delay_seconds);

		// Hard-normalize identity to the discovery item only.
		self::unschedule_item_by_id($item_id);

		return self::schedule_unique_single_action(
			$timestamp,
			self::HOOK_PROCESS_ITEM,
			array((int) $item_id, (int) $user_id)
		);
	}

	public static function schedule_check_job( int $item_id, int $job_id, int $user_id, int $attempt, int $delay_seconds = 20 ): bool {
		if ( ! self::is_ready() || ! \function_exists( 'as_schedule_single_action' ) ) {
			return false;
		}
		// Unconditional: cancel any existing check-job for this item first,
		// then schedule a fresh one. This prevents the dedup key from blocking
		// re-scheduling when the same [item_id, job_id, attempt] tuple is still
		// pending from a previous poll cycle (the "12 seconds overdue" loop).
    self::unschedule_check_jobs_for_item( $item_id );
    // FINDING 5 FIX: Add deterministic per-item sub-second spread to prevent AS action clustering.
    // Multiple schedule_check_job() calls in same request with identical delays will now
    // land on different timestamps (item_id % 59 gives 0-58s spread).
    $anti_cluster_offset = $item_id % 59;
    $action_id = \as_schedule_single_action(
      \SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts() + max( 1, $delay_seconds ) + $anti_cluster_offset,
      self::HOOK_CHECK_JOB,
      [ (int) $item_id, (int) $job_id, (int) $user_id, (int) $attempt ],
      self::GROUP,
      false,
      10
    );
		return \is_numeric( $action_id ) && (int) $action_id > 0;
	}

	public static function schedule_sideload( int $post_id, string $image_url, string $logo_url, int $discovery_id, int $user_id, int $delay_seconds = 5 ): bool {
		return self::schedule_unique_single_action( \SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts() + max( 0, $delay_seconds ), self::HOOK_SIDELOAD_IMAGE, [ (int) $post_id, $image_url, $logo_url, (int) $discovery_id, (int) $user_id ] );
	}

	// --- Engine Schedulers ---

	public static function schedule_passive_discovery( int $timestamp ): bool {
		return self::schedule_unique_single_action( $timestamp, self::HOOK_PASSIVE_DISCOVERY, [] );
	}

	public static function schedule_active_discovery( int $timestamp ): bool {
		return self::schedule_unique_single_action( $timestamp, self::HOOK_ACTIVE_DISCOVERY, [] );
	}

	// --- Recurring Schedulers ---

	public static function schedule_recurring_worker( int $interval = 60 ): void {
		self::schedule_unique_recurring_action( \SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts() + 10, $interval, self::HOOK_QUEUE_WORKER, [] );
	}

	public static function schedule_recurring_wp_auto_poll( int $interval = 900 ): void {
		self::schedule_unique_recurring_action( \SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts() + 15, $interval, self::HOOK_WP_AUTO_DRAFT_POLL, [] );
	}

	public static function schedule_recurring_auto_gen( int $timestamp, int $interval ): void {
		self::schedule_unique_recurring_action( $timestamp, $interval, self::HOOK_AUTO_GEN_CRON, [] );
	}

	public static function schedule_daily_cleanup( int $timestamp ): void {
		self::schedule_unique_recurring_action( $timestamp, \DAY_IN_SECONDS, self::HOOK_DAILY_CLEANUP, [] );
	}

	public static function schedule_publish_watchdog( int $interval = 120 ): void {
		$interval = max( 60, (int) $interval );
		self::schedule_unique_recurring_action(
			\SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts() + 10,
			$interval,
			self::HOOK_PUBLISH_WATCHDOG,
			[]
		);
	}

	/**
	 * Ensure a recurring action exists with exactly the right parameters.
	 * If it exists, we assume the interval is already set correctly.
	 */
	public static function ensure_recurring_action(int $offset, int $interval, string $hook, array $args): bool
	{
		if (!self::is_ready()) {
			return false;
		}

		// [FIX] Use the UNCACHED next-run. The cached get_next_run() keeps a
		// 15s transient that survives unschedule_all(), so immediately after a
		// delete this would falsely report the action as still present and skip
		// recreation — leaving the recurring hook with zero pending instances
		// (health card flips to "Stalled"). Query the store directly instead.
		$current = self::get_next_run_uncached($hook, $args);

		if ($current > 0) {
			return true;
		}

		return self::schedule_unique_recurring_action(\SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts() + max(0, $offset), $interval, $hook, $args);
	}

	public static function schedule_delete_draft(int $post_id, int $delay_seconds): bool
	{
		$delay_seconds = max(0, $delay_seconds);

		return self::schedule_unique_single_action(
			\SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts() + $delay_seconds,
			self::HOOK_DELETE_DRAFT,
			[(int) $post_id]
		);
	}

	public static function schedule_cleanup( int $timestamp ): void {
		self::schedule_unique_single_action( $timestamp, self::HOOK_QUEUE_CLEANUP, [] );
	}

	// --- Query Helpers ---

	public static function get_next_item_run(int $item_id): int
	{
		if (!\function_exists('as_get_scheduled_actions')) {
			return 0;
		}

		$actions = \as_get_scheduled_actions([
			'hook'   => self::HOOK_PROCESS_ITEM,
			'status' => 'pending',
			'group'  => self::GROUP,
		], 'ids');

		$next = 0;

		foreach ($actions as $action_id) {
			$action = \ActionScheduler::store()->fetch_action($action_id);
			if (!$action || \is_a($action, 'ActionScheduler_NullAction')) {
				continue;
			}

			$args = $action->get_args();
			if (!isset($args[0]) || (int) $args[0] !== $item_id) {
				continue;
			}

			$schedule = $action->get_schedule();
			if ($schedule && \method_exists($schedule, 'get_date')) {
				$date = $schedule->get_date();
				if ($date && \method_exists($date, 'getTimestamp')) {
					$ts = (int) $date->getTimestamp();
					if ($ts > 0 && ($next === 0 || $ts < $next)) {
						$next = $ts;
					}
				}
			}
		}

		return $next;
	}

	/**
	 * Next scheduled run (UTC timestamp) for a hook.
	 *
	 * @param string $hook Action Scheduler hook.
	 * @param array  $args Action args (dedup identity).
	 * @param bool   $overdue_as_now When true, a pending action whose scheduled
	 *                               time is already in the past is reported as
	 *                               "now" instead of a stale past timestamp.
	 *                               Used by display edges so the UI never shows
	 *                               a clock time that already elapsed.
	 * @return int UTC timestamp, or 0 if nothing is scheduled.
	 */
public static function get_next_run(string $hook, array $args = array(), bool $overdue_as_now = false): int
{
	$cache_key = 'as_nxt_' . md5($hook . serialize($args) . ($overdue_as_now ? '1' : '0'));
	$cached = get_transient($cache_key);
	if (false !== $cached) {
		return (int) $cached;
	}

	if (\function_exists('as_next_scheduled_action')) {
		$next = \as_next_scheduled_action($hook, $args, self::GROUP);
		if ($next) {
			$next = (int) $next;
			if ($overdue_as_now && $next < \SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts()) {
				$result = \SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts();
			} else {
				$result = $next;
			}
			set_transient($cache_key, $result, 15);
			return $result;
		}
	}

	$result = self::get_next_run_uncached($hook, $args, $overdue_as_now);
	set_transient($cache_key, $result, 15);
	return $result;
}

	public static function get_next_run_uncached(string $hook, array $args = array(), bool $overdue_as_now = false): int
	{
		if (
			! self::is_ready() ||
			! \class_exists('\ActionScheduler') ||
			! \method_exists('\ActionScheduler', 'store')
		) {
			return 0;
		}

		$store = \ActionScheduler::store();

		if (! \method_exists($store, 'query_actions') || ! \method_exists($store, 'fetch_action')) {
			return 0;
		}

		$ids = $store->query_actions([
			'hook'    => $hook,
			'args'    => $args,
			'group'   => self::GROUP,
			'status'  => \ActionScheduler_Store::STATUS_PENDING,
			'orderby' => 'none',
			'per_page'=> 20,
		], 'select');

		$next = 0;

		if ($overdue_as_now) {
			$now_ts = \SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts();
		}

		foreach ((array) $ids as $action_id) {
			$action = $store->fetch_action($action_id);
			if (! $action || \is_a($action, 'ActionScheduler_NullAction')) {
				continue;
			}

			// [LINT-FIX] Guard with method_exists for ActionScheduler property access
			$schedule = $action->get_schedule();
			if ($schedule && \method_exists($schedule, 'get_date')) {
				$date = $schedule->get_date();
				if ($date && \method_exists($date, 'getTimestamp')) {
					$ts = (int) $date->getTimestamp();
					if ($ts > 0 && ($next === 0 || $ts < $next)) {
						$next = $ts;
					}
				}
			}
		}

		if ($overdue_as_now && $next > 0 && $next < $now_ts) {
			return $now_ts;
		}

		return $next;
	}

	/**
	 * Return the interval (seconds) of an existing recurring action, or 0.
	 *
	 * Used by the meta-watchdog (Discovery_Bootstrap::ensure_recurring_watchdog)
	 * to detect interval drift on the recurring AS actions that power the other
	 * watchdogs. A 0 return means no recurring action is currently scheduled.
	 *
	 * @since 2.30.x (Audit Enhancement 1)
	 */
	public static function get_recurring_interval( string $hook, array $args = array() ): int {
		if (
			! self::is_ready()
			|| ! \class_exists( '\ActionScheduler' )
			|| ! \method_exists( '\ActionScheduler', 'store' )
		) {
			return 0;
		}

		$store = \ActionScheduler::store();

		if ( ! \method_exists( $store, 'query_actions' ) || ! \method_exists( $store, 'fetch_action' ) ) {
			return 0;
		}

		$ids = $store->query_actions(
			array(
				'hook'   => $hook,
				'args'   => $args,
				'group'  => self::GROUP,
				'status' => \ActionScheduler_Store::STATUS_PENDING,
				'orderby' => 'none',
				'per_page' => 5,
			),
			'select'
		);

		foreach ( (array) $ids as $action_id ) {
			$action = $store->fetch_action( $action_id );
			if ( ! $action || \is_a( $action, 'ActionScheduler_NullAction' ) ) {
				continue;
			}
			$schedule = $action->get_schedule();
			if ( $schedule && \method_exists( $schedule, 'interval_in_seconds' ) ) {
				$interval = (int) $schedule->interval_in_seconds();
				if ( $interval > 0 ) {
					return $interval;
				}
			}
		}

		return 0;
	}

	public static function unschedule_all( string $hook, array $args = [] ): void {
		if ( ! \function_exists( 'as_unschedule_all_actions' ) ) {
			return;
		}
		\as_unschedule_all_actions( $hook, $args, self::GROUP );
	}

	public static function unschedule_item(int $item_id, int $user_id = 0): void
	{
		self::unschedule_item_by_id($item_id);
	}

	/**
	 * Force-unschedule any process action for this item, regardless of other args.
	 */
	public static function unschedule_item_by_id( int $item_id ): void {
		if ( ! \function_exists( 'as_get_scheduled_actions' ) || ! \function_exists( 'as_unschedule_action' ) ) {
			return;
		}

		$actions = \as_get_scheduled_actions( [
			'hook'   => self::HOOK_PROCESS_ITEM,
			'status' => 'pending',
			'group'  => self::GROUP,
		], 'ids' );

		foreach ( $actions as $action_id ) {
			$action = \ActionScheduler::store()->fetch_action( $action_id );
			if ( ! $action || \is_a( $action, 'ActionScheduler_NullAction' ) ) continue;
			$args = $action->get_args();
			if ( isset( $args[0] ) && (int) $args[0] === $item_id ) {
				\as_unschedule_action( self::HOOK_PROCESS_ITEM, $args, self::GROUP );
			}
		}
	}

	/**
	 * Unschedule all pending check-job polls for a specific item.
	 */
	public static function unschedule_check_jobs_for_item(int $item_id): void
	{
		if (!\function_exists('as_get_scheduled_actions') || !\function_exists('as_unschedule_action')) {
			return;
		}

		$actions = \as_get_scheduled_actions([
			'hook'   => self::HOOK_CHECK_JOB,
			'status' => 'pending',
			'group'  => self::GROUP,
		], 'ids');

		foreach ($actions as $action_id) {
			$action = \ActionScheduler::store()->fetch_action($action_id);
			if (!$action || \is_a($action, 'ActionScheduler_NullAction')) {
				continue;
			}

			$args = $action->get_args();
			if (isset($args[0]) && (int) $args[0] === $item_id) {
				\as_unschedule_action(self::HOOK_CHECK_JOB, $args, self::GROUP);
			}
		}
	}

	/**
	 * FIX POLL-STORM GUARD: Returns the next scheduled timestamp for ANY
	 * pending check-job poll on this item, regardless of attempt value.
	 * Previous sync_finalizer guard hardcoded attempt=1 which missed checks
	 * rescheduled by check_and_finalize_job() with attempt > 1, leading to
	 * duplicate check-job scheduling on long-deferred items.
	 *
	 * @param int $item_id Discovery row id.
	 * @param int $job_id  Job row id.
	 * @return int UTC timestamp of next pending check-job for this item, or 0 if none.
	 */
	public static function get_next_check_job_for_item( int $item_id, int $job_id ): int {
		if ( ! self::is_ready() || ! \function_exists( 'as_get_scheduled_actions' ) ) {
			return 0;
		}

		$actions = \as_get_scheduled_actions([
			'hook'     => self::HOOK_CHECK_JOB,
			'status'   => 'pending',
			'group'    => self::GROUP,
			'per_page' => 50,
		], 'ids' );

		$next = 0;
		foreach ( (array) $actions as $action_id ) {
			$action = \ActionScheduler::store()->fetch_action( $action_id );
			if ( ! $action || \is_a( $action, 'ActionScheduler_NullAction' ) ) {
				continue;
			}

			$args = $action->get_args();
			if ( ! isset( $args[0] ) || (int) $args[0] !== $item_id ) {
				continue;
			}
			// Also match job_id when present in args to avoid catching sibling-item checks.
			if ( isset( $args[1] ) && (int) $args[1] !== $job_id ) {
				continue;
			}

			$schedule = $action->get_schedule();
			if ( ! $schedule ) {
				continue;
			}

			$ts = 0;
			if ( method_exists( $schedule, 'getTimestamp' ) ) {
				$ts = (int) $schedule->getTimestamp();
			} elseif ( method_exists( $schedule, 'get_date' ) ) {
				$date = $schedule->get_date();
				$ts   = $date ? (int) $date->getTimestamp() : 0;
			}

			if ( $ts > 0 && ( $next === 0 || $ts < $next ) ) {
				$next = $ts;
			}
		}

		return $next;
	}

	/**
	 * Cancel every item-scoped scheduled action (process + poll).
	 */
	public static function cancel_item_actions(int $item_id): void
	{
		self::unschedule_item_by_id($item_id);
		self::unschedule_check_jobs_for_item($item_id);
	}

	// --- Core AS Wrappers ---

	public static function schedule_unique_single_action( int $timestamp, string $hook, array $args ): bool {
		if ( ! self::is_ready() || ! \function_exists( 'as_schedule_single_action' ) ) {
			return false;
		}
		if ( self::has_scheduled_action( $hook, $args, self::GROUP ) ) {
			return true;
		}
		$action_id = \as_schedule_single_action( $timestamp, $hook, $args, self::GROUP, false, 10 );
		return \is_numeric( $action_id ) && (int) $action_id > 0;
	}

	public static function schedule_unique_recurring_action( int $timestamp, int $interval, string $hook, array $args ): bool {
		if ( ! self::is_ready() || ! \function_exists( 'as_schedule_recurring_action' ) ) {
			return false;
		}
		if ( self::has_scheduled_action( $hook, $args, self::GROUP ) ) {
			return true;
		}
		$action_id = \as_schedule_recurring_action( $timestamp, $interval, $hook, $args, self::GROUP, false, 10 );
		return \is_numeric( $action_id ) && (int) $action_id > 0;
	}

	public static function has_scheduled_action( string $hook, array $args, string $group ): bool {
		if ( \function_exists( 'as_has_scheduled_action' ) ) {
			return (bool) \as_has_scheduled_action( $hook, $args, $group );
		}
		if ( \function_exists( 'as_next_scheduled_action' ) ) {
			return false !== \as_next_scheduled_action( $hook, $args, $group );
		}
		return false;
	}

	/**
	 * Force-reschedule the queue worker unconditionally.
	 * Use after raw-SQL bulk deletes that bypass the AS object cache.
	 */
	public static function force_schedule_worker(int $interval = 60): int
	{
		if (!self::is_ready() || !\function_exists('as_schedule_recurring_action')) {
			return 0;
		}

		// Unschedule first to clear any stale AS cache entry
		self::unschedule_all(self::HOOK_QUEUE_WORKER);

		$action_id = \as_schedule_recurring_action(
			\SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts() + 10,
			$interval,
			self::HOOK_QUEUE_WORKER,
			[],
			self::GROUP,
			false,
			10
		);

		if (!\is_numeric($action_id) || (int) $action_id <= 0) {
			return 0;
		}

		return self::get_next_run_uncached(self::HOOK_QUEUE_WORKER);
	}

    /**
     * Purge ALL SEO-gen AS actions regardless of status or args.
     * Use during reset/repair/purge operations to eliminate orphans.
     */
    public static function purge_all_seo_gen_actions(): int
    {
        if (!self::is_ready()) {
            return 0;
        }

        $hooks = [
            self::HOOK_PROCESS_ITEM,
            self::HOOK_CHECK_JOB,
            self::HOOK_SIDELOAD_IMAGE,
            self::HOOK_DELETE_DRAFT,
            self::HOOK_PUBLISH_WATCHDOG,
            self::HOOK_PASSIVE_DISCOVERY,
            self::HOOK_ACTIVE_DISCOVERY,
            self::HOOK_WP_AUTO_DRAFT_POLL,
        ];

        $purged = 0;

        foreach ($hooks as $hook) {
            // Cancel by hook+group (catches ALL actions regardless of args/status)
            if (\function_exists('as_cancel_scheduled_actions')) {
                $purged += \as_cancel_scheduled_actions([
                    'hook' => $hook,
                    'group' => self::GROUP,
                ]);
            }
        }

        // Also delete any remaining via direct query for orphaned actions
        if (\function_exists('as_get_scheduled_actions')) {
            $actions = \as_get_scheduled_actions([
                'group' => self::GROUP,
                'per_page' => -1,
            ], 'ids');

            if (!empty($actions)) {
                foreach ($actions as $action_id) {
                    if (\function_exists('as_unschedule_action')) {
                        \as_unschedule_action($action_id);
                        $purged++;
                    }
                }
            }
        }

        // Force cache clear
        if (\function_exists('wp_cache_flush')) {
            \wp_cache_flush();
        }

        return $purged;
    }

public static function purge_item_pipeline_actions(array $item_ids): int
	{
		if (! self::is_ready() || empty($item_ids)) {
			return 0;
		}

		$item_ids = array_values(array_unique(array_map('intval', $item_ids)));
		$purged = 0;

		foreach ($item_ids as $item_id) {
			if ($item_id <= 0) {
				continue;
			}

			if (\function_exists('as_get_scheduled_actions') && \function_exists('as_unschedule_action')) {
				$actions = \as_get_scheduled_actions([
					'group' => self::GROUP,
					'status' => 'pending',
					'hook' => self::HOOK_PROCESS_ITEM,
					'per_page'=> -1,
				], 'ids');

				foreach ((array) $actions as $action_id) {
					$action = \ActionScheduler::store()->fetch_action($action_id);
					if (! $action || \is_a($action, 'ActionScheduler_NullAction')) {
						continue;
					}

					$args = $action->get_args();
					if (isset($args[0]) && (int) $args[0] === $item_id) {
						\as_unschedule_action(self::HOOK_PROCESS_ITEM, $args, self::GROUP);
						$purged++;
					}
				}

				$actions = \as_get_scheduled_actions([
					'group' => self::GROUP,
					'status' => 'pending',
					'hook' => self::HOOK_CHECK_JOB,
					'per_page'=> -1,
				], 'ids');

				foreach ((array) $actions as $action_id) {
					$action = \ActionScheduler::store()->fetch_action($action_id);
					if (! $action || \is_a($action, 'ActionScheduler_NullAction')) {
						continue;
					}

					$args = $action->get_args();
					if (isset($args[0]) && (int) $args[0] === $item_id) {
						\as_unschedule_action(self::HOOK_CHECK_JOB, $args, self::GROUP);
						$purged++;
					}
				}
			}
		}

		return $purged;
	}

	public static function is_ready_public(): bool
	{
		return self::is_ready();
	}

	private static function is_ready(): bool {
		if ( function_exists( 'did_action' ) && did_action( 'action_scheduler_init' ) ) {
			return true;
		}
		if ( \class_exists('\ActionScheduler') && \method_exists('\ActionScheduler', 'is_initialized' ) ) {
			return \ActionScheduler::is_initialized();
		}
		return false;
	}
}

