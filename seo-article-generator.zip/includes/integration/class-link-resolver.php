<?php

namespace SEO_Article_Generator\Integration;

if (! defined('ABSPATH')) {
	exit;
}

/**
 * Link_Resolver
 *
 * Deterministic PHP-based link classification to prevent AI hallucinations.
 * Handles platform detection, link type inference, and URL normalization.
 */
require_once __DIR__ . '/../generator/class-download-content.php';

final class Link_Resolver
{
	private const PLATFORM_PRIORITY = array(
		'Windows'  => 1,
		'macOS'    => 2,
		'Linux'    => 3,
		'Android'  => 5,
		'iOS'      => 6,
	);

	private const TRUSTED_STORE_HOSTS = array(
		'play.google.com' => array('platform' => 'Android', 'type' => 'store'),
		'apps.apple.com' => array('platform' => 'iOS', 'type' => 'store'),
		'itunes.apple.com' => array('platform' => 'iOS', 'type' => 'store'),
		'apps.microsoft.com' => array('platform' => 'Windows', 'type' => 'store'),
		'commerce.adobe.com' => array('platform' => 'Windows', 'type' => 'portal'),
		'creative.adobe.com' => array('platform' => 'Windows', 'type' => 'portal'),
	);

	private const CONFIDENCE_FLOOR_DEFAULT  = 0.70;
	private const CONFIDENCE_FLOOR_OFFICIAL = 0.65;

	private const TRACKING_QUERY_KEYS = array(
		'utm_source',
		'utm_medium',
		'utm_campaign',
		'utm_term',
		'utm_content',
		'fbclid',
		'gclid',
		'mc_cid',
		'mc_eid',
		'ref',
		'ref_src'
	);

	private const NON_DOWNLOAD_PATH_FRAGMENTS = array(
		'/release-notes',
		'/releases',
		'/changelog',
		'/history',
		'/latest-updates',
		'/news',
		'/blog',
		'/support',
		'/docs',
		'/documentation',
		'/pricing',
		'/buy',
		'/purchase',
		'/checkout'
	);

	private const SCHEME_BLOCKLIST = array(
		'mailto:',
		'javascript:',
		'data:',
		'vbscript:',
	);

	private const DOMAIN_BLOCKLIST = array(
		'facebook.com',
		'twitter.com',
		'linkedin.com',
		'pinterest.com',
		't.co',
	);

	private const NOISY_HOSTS = array(
		'x.com',
		'instagram.com',
		'reddit.com',
		'youtube.com',
		'youtu.be'
	);

	/** Staging and processing share the same existing-post recovery contract.
	 * Body is current evidence; stored schema is fallback only when no anchors survive.
	 * An explicitly empty canonical snapshot must not resurrect older compatibility meta.
	 */
	public static function recover_existing_post_links(int $post_id, string $software_name = ''): array
	{
		$helper = \SEO_Article_Generator\Generator\Download_Link_Helper::class;
		$snapshot = \get_post_meta($post_id, '_seo_gen_article_snapshot', true);
		$has_snapshot = is_array($snapshot) && is_array($snapshot['download_section'] ?? null) && array_key_exists('links', $snapshot['download_section']);
		$stored = $has_snapshot ? (array)$snapshot['download_section']['links'] : (array)\get_post_meta($post_id, '_canonical_download_links', true);
		$edits = \get_post_meta($post_id, '_seo_gen_download_edits', true);
		if ($has_snapshot && !$stored && !empty($edits['explicit_empty'])) return array();
		$html = (string)\get_post_field('post_content', $post_id, 'raw');
		$scope = \SEO_Article_Generator\Generator\Download_Content::inspect($html, $software_name);
		if ($scope['found']) {
			$resolved = self::resolve_from_html($scope['html'], array('software_name'=>$software_name));
			// A recognized empty zone is authoritative; never fall back outside it.
			return $helper::normalize_links($helper::respect_manual_removals($resolved['links'], $post_id), 'Other');
		}
		if ($scope['kind'] !== 'malformed_blocks') {
			// Legacy unstructured body: require product evidence, not any binary in the post.
			$resolved = self::resolve_from_html($html, array('software_name'=>$software_name));
			$known = array_fill_keys(array_column($stored, 'url'), true);
			$bounded = array_filter($resolved['links'], static function($r) use ($software_name,$known) {
				if (isset($known[$r['url']])) return true;
				$name = preg_replace('/[^a-z0-9]/i', '', $software_name);
				$own = preg_replace('/[^a-z0-9]/i', '', $r['text'].' '.(string)parse_url($r['url'], PHP_URL_PATH));
				return strlen($name) >= 4 && stripos($own, $name) !== false;
			});
			if ($bounded) return $helper::normalize_links($helper::respect_manual_removals(array_values($bounded),$post_id),'Other');
		}
		return $helper::normalize_links($helper::respect_manual_removals($stored, $post_id), 'Other');
	}

	public static function resolve_from_html(string $html, array $args = array()): array
	{
		$result = array(
			'links' => array(),
			'rejected_links' => array(),
			'metadata_links' => array(),
			'grounding_hints' => array(),
			'target_platforms' => array(),
			'os_support' => '',
		);

		if (trim($html) === '') {
			return $result;
		}

		$source_url    = (string) ($args['source_url'] ?? '');
		$software_name = (string) ($args['software_name'] ?? '');
		$source_host   = self::host($source_url);

		$dom = self::load_dom($html);
		$xpath = $dom ? new \DOMXPath($dom) : null;

		$candidates = self::extract_candidates($dom, $xpath, $html);
		$deduped = array();

		foreach ($candidates as $candidate) {
			$resolved = self::classify_candidate($candidate, $source_host, $software_name);
			if (empty($resolved['normalized_url'])) {
				continue;
			}

			$key = $resolved['normalized_url'];
			if (! isset($deduped[$key]) || self::is_better($resolved, $deduped[$key])) {
				$deduped[$key] = $resolved;
			}
		}

	foreach (array_values($deduped) as $item) {
		if (! empty($item['approved'])) {
			$result['links'][] = $item;
		} else {
			$result['rejected_links'][] = $item;
		}
	}

	// @ADDED 2026-05-08: Recover metadata links (homepage, changelog) from rejected links
	// before they are discarded. These are structurally important URLs that don't qualify
	// as download links but are needed for homepage_url and changelog_url downstream.
	$result['metadata_links'] = self::extract_metadata_links($result['rejected_links']);

		$approved_before = $result['links'];
		$result['links'] = \SEO_Article_Generator\Generator\Download_Link_Helper::normalize_links($result['links'], 'Other');
		$accepted_urls = array_column($result['links'], 'url');
		foreach ($approved_before as $row) {
			if (!in_array($row['url'], $accepted_urls, true)) {
				$row['approved'] = false; $row['is_primary'] = false;
				$row['rejected_reason'] = 'shared_download_validation';
				$result['rejected_links'][] = $row;
			}
		}

		$platforms = array();
		foreach ($result['links'] as $link) {
			if (! empty($link['platform']) && $link['platform'] !== 'Other') {
				$platforms[$link['platform']] = true;
				$key = strtolower($link['platform']);
				if (! isset($result['grounding_hints'][$key])) {
					$result['grounding_hints'][$key] = array();
				}
				$result['grounding_hints'][$key][] = array(
					'url'        => $link['url'],
					'variant'    => $link['variant'],
					'link_type'  => $link['link_type'],
					'confidence' => $link['confidence'],
					'is_primary' => $link['is_primary'],
				);
			}
		}

		$platform_keys = array_keys($platforms);
		$priority = array(
			'Windows' => 0,
			'macOS'   => 1,
			'Linux'   => 2,
			'Android' => 3,
			'iOS'     => 4,
		);
		usort(
			$platform_keys,
			static function ( $a, $b ) use ( $priority ) {
				$p_a = isset( $priority[ $a ] ) ? $priority[ $a ] : 999;
				$p_b = isset( $priority[ $b ] ) ? $priority[ $b ] : 999;

				if ( $p_a !== $p_b ) {
					return $p_a - $p_b;
				}

				return strcasecmp( $a, $b );
			}
		);

		$result['target_platforms'] = $platform_keys;
		$result['os_support']       = implode(', ', $result['target_platforms']);

		// DIAGNOSTIC: Log summary of link resolution
		if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
			$total_candidates = count( $candidates );
			$total_approved   = count( $result['links'] );
			$total_rejected   = count( $result['rejected_links'] );
			error_log( sprintf(
				'[LinkResolver] SUMMARY: source_host=%s | software=%s | candidates=%d | approved=%d | rejected=%d | platforms=%s',
				$source_host,
				$software_name,
				$total_candidates,
				$total_approved,
				$total_rejected,
				implode( ', ', $result['target_platforms'] )
			) );
			// Log rejection reasons breakdown
			$reason_counts = array();
			foreach ( $result['rejected_links'] as $rejected ) {
				$r = $rejected['rejected_reason'] ?? 'unknown';
				$reason_counts[ $r ] = ( $reason_counts[ $r ] ?? 0 ) + 1;
			}
			if ( ! empty( $reason_counts ) ) {
				error_log( '[LinkResolver] REJECTION BREAKDOWN: ' . wp_json_encode( $reason_counts ) );
			}
		}

		return $result;
	}

	/**
	 * F12 (Phase 3C, 2.32.26): canonical per-OS link bundle (platform_matrix).
	 * Sole caller is Deterministic_Update_Builder::build_from_source(), which
	 * itself has zero production callers — this output does not currently
	 * reach any payload. Kept for the deferred deterministic OS backfill.
	 */
	public static function build_canonical_bundle(array $links, array $args = array()): array
	{
		$approved = array_values(array_filter($links, static function ($row): bool {
			return ! empty($row['approved']) && ! empty($row['url']);
		}));

		$platform_matrix = array();
		$portable_links  = array();
		$store_links     = array();
		$direct_links    = array();

		foreach ($approved as $row) {
			$platform = (string) ($row['platform'] ?? 'Other');
			if (! isset($platform_matrix[$platform])) {
				$platform_matrix[$platform] = array();
			}

			$platform_matrix[$platform][] = array(
				'label'      => (string) ($row['text'] ?? 'Download'),
				'url'        => (string) ($row['url'] ?? ''),
				'variant'    => (string) ($row['variant'] ?? ''),
				'link_type'  => (string) ($row['link_type'] ?? ''),
				'is_primary' => ! empty($row['is_primary']),
			);

			$variant   = strtolower((string) ($row['variant'] ?? ''));
			$link_type = strtolower((string) ($row['link_type'] ?? ''));

			if ($variant === 'portable') {
				$portable_links[] = $row;
			}

			if ($link_type === 'store') {
				$store_links[] = $row;
			}

			if ($link_type === 'direct' || $link_type === 'portal') {
				$direct_links[] = $row;
			}
		}

		$primary = '';
		foreach ($approved as $row) {
			if (! empty($row['is_primary']) && ! empty($row['url'])) {
				$primary = (string) $row['url'];
				break;
			}
		}
		if ($primary === '' && ! empty($approved[0]['url'])) {
			$primary = (string) $approved[0]['url'];
		}

		return array(
			'primary_download_url' => $primary,
			'download_count'       => count($approved),
			'all_links'            => $approved,
			'platform_matrix'      => $platform_matrix,
			'portable_links'       => $portable_links,
			'store_links'          => $store_links,
			'direct_links'         => $direct_links,
			'os_support'           => implode(', ', array_keys($platform_matrix)),
			'source_url'           => (string) ($args['source_url'] ?? ''),
			'software_name'        => (string) ($args['software_name'] ?? ''),
		);
	}

	private static function extract_metadata_links(array $rejected_links): array
	{
		$metadata = array();
		$homepage_text_pat = '/\b(?:homepage|home\s*page|official\s*(?:page|site|website|url)|product\s*page)\b/i';
		$changelog_text_pat = '/\b(?:changelog|changes|release\s*notes|what[\s\'-]*s\s*new|update\s*log|fixed\s*issues|version\s*history)\b/i';
		$changelog_url_pat = '~/(?:changelog|releases?|release-?notes|update-?log|whats-?new|fixed-?issues|kb/fixed|history)~i';

		foreach ($rejected_links as $link) {
			$url = (string) ($link['url'] ?? '');
			$text = (string) ($link['text'] ?? '');
			$reason = (string) ($link['rejected_reason'] ?? '');
			if ($url === '' || !filter_var($url, FILTER_VALIDATE_URL)) {
				continue;
			}
			$is_homepage = preg_match($homepage_text_pat, $text);
			$is_changelog = preg_match($changelog_text_pat, $text) || preg_match($changelog_url_pat, $url);
			if ($is_homepage) {
				$metadata[] = array('url' => $url, 'type' => 'homepage', 'text' => $text);
			} elseif ($is_changelog) {
				$metadata[] = array('url' => $url, 'type' => 'changelog', 'text' => $text);
			}
		}

		return $metadata;
	}

	private static function extract_candidates($dom, $xpath, string $html): array
	{
		$candidates = array();

		$add = static function (array $row) use (&$candidates): void {
			if (empty($row['url'])) {
				return;
			}
			$candidates[] = $row;
		};

		if ($dom) {
			$data_attrs = array('data-href', 'data-url', 'data-link', 'data-download', 'data-download-url', 'data-direct-url', 'data-portal-url');

			foreach ($dom->getElementsByTagName('a') as $node) {
				$href = trim($node->getAttribute('href'));
				if ($href === '') {
					foreach ($data_attrs as $attr) {
						$val = trim($node->getAttribute($attr));
						if ($val !== '') {
							$href = $val;
							break;
						}
					}
				}

				$add(array(
					'url'     => $href,
					'text'    => self::normalize_text($node->textContent),
					'context' => self::collect_context($node),
					'source'  => 'anchor',
				));
			}

			foreach ($dom->getElementsByTagName('button') as $node) {
				foreach ($data_attrs as $attr) {
					$val = trim($node->getAttribute($attr));
					if ($val !== '') {
						$add(array(
							'url'     => $val,
							'text'    => self::normalize_text($node->textContent),
							'context' => self::collect_context($node),
							'source'  => 'button:' . $attr,
						));
						break;
					}
				}
			}

			if ($xpath) {
				$query = '//*[@data-download-url or @data-direct-url or @data-portal-url or @data-url or @data-href]';
				$nodes = $xpath->query($query);
				if ($nodes) {
					foreach ($nodes as $node) {
						if (! $node instanceof \DOMElement) {
							continue;
						}
						foreach (array('data-download-url', 'data-direct-url', 'data-portal-url', 'data-url', 'data-href') as $attr) {
							$val = trim($node->getAttribute($attr));
							if ($val !== '') {
								$add(array(
									'url'     => $val,
									'text'    => self::normalize_text($node->textContent),
									'context' => self::collect_context($node),
									'source'  => 'data-attr:' . $attr,
								));
							}
						}
					}
				}
			}
		}

		if (empty($candidates)) {
			if (preg_match_all('/(?:href|data-download-url|data-direct-url|data-portal-url|data-url|data-href)=["\'](https?:\/\/[^"\'> ]+)["\']/i', $html, $m)) {
				foreach ($m[1] as $url) { // Fixed corrupted index from plan.txt
					$add(array(
						'url'     => $url,
						'text'    => '',
						'context' => '',
						'source'  => 'regex',
					));
				}
			}
		}

		return $candidates;
	}

	private static function classify_candidate(array $candidate, string $source_host, string $software_name = ''): array
	{
		$raw_url = trim((string) ($candidate['url'] ?? ''));
		$text    = self::normalize_text((string) ($candidate['text'] ?? ''));
		$context = (string) ($candidate['context'] ?? '');

		$url = self::normalize_url($raw_url);
		$host = self::host($url);

		if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
			error_log( '[LinkResolver] classify_candidate: CHECKING url=' . $url . ' | host=' . $host . ' | text=' . substr($text, 0, 80) . ' | software=' . $software_name );
		}

		$row = array(
			'url'            => $url,
			'normalized_url' => $url,
			'text'           => $text,
			'context'        => $context,
			'source'         => (string) ($candidate['source'] ?? ''),
			'source_host'    => $host,
			'platform'       => '',
			'variant'        => '',
			'link_type'      => '',
			'confidence'     => 0.0,
			'is_primary'     => false,
			'approved'       => false,
			'rejected_reason' => '',
		);

		if ($url === '' || ! filter_var($url, FILTER_VALIDATE_URL)) {
			$row['rejected_reason'] = 'invalid_url';
			self::log_rejection($row, 'invalid_url', 'URL failed FILTER_VALIDATE_URL or is empty');
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				error_log( '[LinkResolver] classify_candidate: REJECTED url=' . $raw_url . ' | reason=invalid_url | normalized=' . $url );
			}
			return $row;
		}

		// @ADDED 2026-06-06: Compute allowlist flag once per candidate. Soft
		// rejections below consult this flag and skip when the URL's host
		// (or exact URL) is in the admin-configured download allowlist. Hard
		// rejections (invalid_url, noisy_or_social, affiliate_domain,
		// invalid_download_url) remain unconditional — they are correctness
		// invariants, not heuristics.
		$is_allowlisted = class_exists('\\SEO_Article_Generator\\Generator\\Download_Link_Helper')
			&& \SEO_Article_Generator\Generator\Download_Link_Helper::is_url_in_allowlist($url);

		if (self::is_noisy_or_social($url, $host)) {
			$row['rejected_reason'] = 'noisy_or_social';
			self::log_rejection($row, 'noisy_or_social', 'Host matches social/noisy blocklist');
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				error_log( '[LinkResolver] classify_candidate: REJECTED url=' . $url . ' | reason=noisy_or_social | host=' . $host );
			}
			return $row;
		}

		if (\SEO_Article_Generator\Generator\Download_Link_Helper::is_affiliate_url($url)) {
			$row['rejected_reason'] = 'affiliate_domain';
			self::log_rejection($row, 'affiliate_domain', 'URL matches affiliate network denylist');
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				error_log( '[LinkResolver] classify_candidate: REJECTED url=' . $url . ' | reason=affiliate_domain');
			}
			return $row;
		}

		if (! \SEO_Article_Generator\Generator\Download_Link_Helper::is_valid_download_url($url)) {
			$row['rejected_reason'] = 'invalid_download_url';
			self::log_rejection($row, 'invalid_download_url', 'URL failed is_valid_download_url() (placeholder, non-download extension, or invalid scheme)');
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				error_log( '[LinkResolver] classify_candidate: REJECTED url=' . $url . ' | reason=invalid_download_url');
			}
			return $row;
		}

		if (self::is_non_download_path($url) && ! $is_allowlisted) {
			$row['rejected_reason'] = 'non_download_page';
			self::log_rejection($row, 'non_download_page', 'URL path matches non-download fragment (release-notes, blog, docs, etc.)');
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				error_log( '[LinkResolver] classify_candidate: REJECTED url=' . $url . ' | reason=non_download_page');
			}
			return $row;
		}

		// Guard: Reject bare root domains and homepages as download links.
		$parsed_url = wp_parse_url( $url );
		$path_clean = isset( $parsed_url['path'] ) ? trim( $parsed_url['path'], '/' ) : '';
		// Strip language code prefixes (e.g., en-US, en, fr, de, etc.)
		$path_clean = preg_replace( '~^(?:[a-z]{2}(?:-[a-z]{2})?)/?~i', '', $path_clean );
		
		if ( ( $path_clean === '' || in_array( strtolower( $path_clean ), array( 'index.html', 'index.php', 'index.htm', 'home', 'main' ), true ) )
			&& ! preg_match( '/\b(?:download|get|install|setup|trial)\b/i', $url . ' ' . $text )
			&& ! $is_allowlisted
		) {
			$row['rejected_reason'] = 'homepage_link';
			self::log_rejection($row, 'homepage_link', 'URL resolves to bare root domain or homepage without download keyword');
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				error_log( '[LinkResolver] classify_candidate: REJECTED url=' . $url . ' | reason=homepage_link | path_clean=' . $path_clean . ' | text=' . substr($text, 0, 60));
			}
			return $row;
		}

		// Reject links with clear buy/pricing/cart intent in the anchor text (unless it's a trial/free link)
		$text_lc = strtolower($text);
		if (preg_match('/\b(buy now|buy|purchase|pricing|checkout|add to cart|order now|get deal|special offer|discount|shop|coupon|save \d+\%|off)\b/i', $text_lc)) {
			if (strpos($text_lc, 'trial') === false && strpos($text_lc, 'free') === false && ! $is_allowlisted) {
				$row['rejected_reason'] = 'buy_intent_text';
				self::log_rejection($row, 'buy_intent_text', 'Anchor text contains buy/purchase intent without trial/free');
				return $row;
			}
		}

		// Guard: Reject changelog / release-notes anchor texts upstream.
		// Mirrors $changelog_text_pat already used in extract_metadata_links().
		// "Changes in paint.net 5.1.12 (2026-03-08):" or "Release Notes" are changelog links, not downloads.
		if ( preg_match(
			'/\b(?:changelog|changes?\b|release\s*notes?|what[\s\'-]*s\s+new|update\s*log|fixed\s+issues|version\s*history)\b/i',
			$text
		) && ! $is_allowlisted ) {
			$row['rejected_reason'] = 'changelog_link';
			self::log_rejection($row, 'changelog_link', 'Anchor text matches changelog/release-notes pattern');
			return $row;
		}
		// Changelog URL path guard — anchors with (?:/|$|\?) to avoid matching /releases/download/ on GitHub.
		if ( preg_match( '~/(?:changelog|release-?notes|update-?log|whats-?new|fixed-?issues|kb/fixed|history)(?:/|$|\?)~i', $url )
			&& ! preg_match( '~/releases?/download/~i', $url )
			&& ! $is_allowlisted
		) {
			$row['rejected_reason'] = 'changelog_link';
			self::log_rejection($row, 'changelog_link', 'URL path matches changelog/release-notes pattern');
			return $row;
		}

		// Guard: Reject homepage / official-page labeled links upstream.
		// Mirrors $homepage_text_pat already used in extract_metadata_links().
		// Checks both $text (anchor text may be the URL itself) and $context (the "Homepage –" label
		// is a text node BEFORE the <a> tag — collect_context() captures it via parent <p> walk).
		$combined_hp = strtolower( $text . ' ' . $context );
		if ( preg_match(
			'/\b(?:homepage|home\s*page|official\s*(?:page|site|website|url)|product\s*page)\b/i',
			$combined_hp
		) && ! $is_allowlisted ) {
			$row['rejected_reason'] = 'homepage_link';
			self::log_rejection($row, 'homepage_link', 'Anchor text or context contains homepage/official-page label');
			return $row;
		}

		// Guard: Reject plugin / addon / extension sub-download anchors.
		// "Download Plugins" or "Download Addon" are category pages, not the primary software download.
		// Text-only (not context) to avoid false positives from surrounding paragraph text.
		if ( preg_match(
			'/\bdownload\s+(?:plugins?|add-?ons?|extensions?|themes?|skins?|mods?|templates?)\b/i',
			$text
		) && ! $is_allowlisted && ! preg_match('/\.(?:exe|msi|zip|7z)(?:$|[?#])/i', $url)) {
			$row['rejected_reason'] = 'addon_download';
			self::log_rejection($row, 'addon_download', 'Anchor text matches plugin/addon/extension download pattern');
			return $row;
		}

		$selector = \SEO_Article_Generator\Generator\Download_Link_Helper::selector_evidence($url, $text, $software_name);
		$link_type = $selector !== '' ? 'portal' : self::detect_link_type($url, $host, $text, $context, $source_host);
		$row['download_evidence'] = $selector;
		$row['classification_context'] = $context;
		$row['link_type'] = $link_type;
		$row = \SEO_Article_Generator\Generator\Download_Link_Helper::classify_record($row);
		$platform = $row['platform'];
		$variant = $row['variant'];

		if (! in_array($link_type, array('direct', 'store', 'portal'), true)) {
			if (! $is_allowlisted) {
				$row['rejected_reason'] = 'not_download_type:' . $link_type;
				self::log_rejection($row, 'not_download_type:' . $link_type, 'Link type is "' . $link_type . '" — not a direct/store/portal download');
				if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
					error_log( '[LinkResolver] classify_candidate: REJECTED url=' . $url . ' | reason=not_download_type | link_type=' . $link_type);
				}
				return $row;
			}
			// Allowlist bypass: still require download signals — a bare repo page
			// or project page should not leak into download links just because
			// the host is allowlisted (e.g. github.com).
			$has_download_ext  = (bool) preg_match( '/\.(exe|msi|msix|dmg|pkg|deb|rpm|apk|appimage|zip|7z|rar|tar\.gz|tar\.xz|tar\.bz2|tgz|iso|ipa|sh|run|bin)(?:$|[?#])/i', $url );
			$has_download_text = (bool) preg_match( '/\b(?:download|get\s+for|installer|offline\s+installer|direct\s+link|portable|trial)\b/i', $text . ' ' . $context );
			if ( ! $has_download_ext && ! $has_download_text ) {
				$row['rejected_reason'] = 'allowlisted_non_download';
				self::log_rejection( $row, 'allowlisted_non_download', 'Allowlisted host but URL has no download extension and no download keywords in text/context' );
				if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
					error_log( '[LinkResolver] classify_candidate: REJECTED url=' . $url . ' | reason=allowlisted_non_download | text=' . substr( $text, 0, 60 ) );
				}
				return $row;
			}
		}

		if ($platform === '' && ! $is_allowlisted) {
			$row['rejected_reason'] = 'ambiguous_platform';
			self::log_rejection($row, 'ambiguous_platform', 'detect_platform() returned empty — no OS keyword in URL, text, or context');
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				error_log( '[LinkResolver] classify_candidate: REJECTED url=' . $url . ' | reason=ambiguous_platform');
			}
			return $row;
		}

		$is_official = self::is_official_host($host, $source_host, $software_name);
		$confidence  = self::score(
			$url,
			$host,
			$text,
			$context,
			$source_host,
			$platform,
			$variant,
			$link_type,
			$software_name
		);

		$row['confidence'] = $confidence;
		$row['is_primary'] = false; // Assigned once, after the complete candidate set is known.

		// Tiered threshold: official domains earn a 5-point grace margin
		$threshold = $is_official
			? self::CONFIDENCE_FLOOR_OFFICIAL
			: self::CONFIDENCE_FLOOR_DEFAULT;

		if ($confidence < $threshold && ! $is_allowlisted && $selector === '') {
			$row['rejected_reason'] = 'low_confidence';
			self::log_rejection($row, 'low_confidence', sprintf(
				'Confidence %.2f below threshold %.2f (official=%s, platform=%s, variant=%s, type=%s)',
				$confidence, $threshold, $is_official ? 'yes' : 'no', $platform, $variant, $link_type
			));
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				error_log( '[LinkResolver] classify_candidate: REJECTED url=' . $url . ' | reason=low_confidence | confidence=' . $confidence . ' | threshold=' . $threshold . ' | is_official=' . ($is_official ? 'yes' : 'no') . ' | platform=' . $platform . ' | variant=' . $variant . ' | link_type=' . $link_type);
			}
			return $row;
		}

		$row['approved'] = true;
		// Proven source download intent survives later homepage/changelog metadata collisions.
		$row['_bypass_homepage_guard'] = true;

		// DIAGNOSTIC: Log approved links
		if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
			error_log( sprintf(
				'[LinkResolver] APPROVED: url=%s | platform=%s | variant=%s | type=%s | confidence=%.2f | official=%s | text=%s',
				$url, $platform, $variant, $link_type, $confidence, $is_official ? 'yes' : 'no', substr( $text, 0, 80 )
			) );
		}

		return $row;
	}

	/**
	 * DIAGNOSTIC: Log rejected links with full context.
	 * Only fires when SEO_GEN_DEBUG_LINKS constant is defined and truthy.
	 */
	private static function log_rejection(array $row, string $reason, string $detail = ''): void
	{
		if ( ! defined( 'SEO_GEN_DEBUG_LINKS' ) || ! SEO_GEN_DEBUG_LINKS ) {
			return;
		}
		error_log( sprintf(
			'[LinkResolver] REJECTED: url=%s | reason=%s | detail=%s | host=%s | text=%s | context=%s',
			$row['url'] ?? '',
			$reason,
			$detail,
			$row['source_host'] ?? '',
			substr( $row['text'] ?? '', 0, 80 ),
			substr( $row['context'] ?? '', 0, 80 )
		) );
	}

	private static function is_official_host(
		string $host,
		string $source_host,
		string $software_name
	): bool {
		if ($source_host !== '' && self::host_matches($host, $source_host)) {
			return true;
		}
		if ($software_name !== '') {
			$clean = strtolower(preg_replace('/[^a-z0-9]/i', '', $software_name));
			if (strlen($clean) >= 4 && strpos($host, $clean) !== false) {
				return true;
			}
		}
		return false;
	}

	private static function detect_link_type(string $url, string $host, string $text, string $context, string $source_host): string
	{
		if (isset(self::TRUSTED_STORE_HOSTS[$host])) {
			return self::TRUSTED_STORE_HOSTS[$host]['type'];
		}

	if (preg_match('/\.(exe|msi|msix|msp|appx|dmg|pkg|deb|rpm|apk|appimage|zip|7z|rar|tar\.gz|tar\.xz|tar\.bz2|tgz|iso|ipa|sh|run|bin)(?:$|[?#])/i', $url)) {
		return 'direct';
	}

		if ($source_host !== '' && self::host_matches($host, $source_host)) {
			$combined = strtolower($text . ' ' . $context . ' ' . $url);
			if (preg_match('/\b(download|get for|installer|offline installer|direct link|portable|trial)\b/i', $combined)) {
				return 'portal';
			}
		}

		if (strpos($host, 'github.com') !== false && preg_match('#/releases(?:/download|/latest)?#i', $url)) {
			return 'direct';
		}

		if (strpos($host, 'sourceforge.net') !== false && preg_match('#/projects/.+/files/.+/(download)?#i', $url)) {
			return 'direct';
		}

		// @ADDED 2026-03-18: Classify official-site /download/ paths as portal
		// regardless of anchor text.
		if (preg_match('~/download(?:/[^/]*)*(?:\?|$|#)~i', $url)) {
			return 'portal';
		}

		// Microsoft Store / App Guard
		if ($host === 'www.microsoft.com' && preg_match('#/(en-[a-z]+/)?(p|store)/#i', $url)) {
			return 'store';
		}

		if (preg_match('/\b(download|get for|installer|offline installer|portable|trial)\b/i', strtolower($text . ' ' . $context))) {
			return 'portal';
		}

		return 'other';
	}

	private static function score(
		string $url,
		string $host,
		string $text,
		string $context,
		string $source_host,
		string $platform,
		string $variant,
		string $link_type,
		string $software_name = ''
	): float {
		$score = 0.0;

		if ($platform !== '') {
			$score += 0.25;
		}
		if ($variant  !== '') {
			$score += 0.05;
		}

		if ($link_type === 'direct') {
			$score += 0.30;
		} elseif ($link_type === 'store') {
			$score += 0.30;
		} elseif ($link_type === 'portal') {
			$score += 0.18;
		}

		// Official domain bonus raised from 0.20 → 0.25
		$is_official = false;
		if ($source_host !== '' && self::host_matches($host, $source_host)) {
			$is_official = true;
			$score += 0.25;
		} elseif ($software_name !== '') {
			$clean_name = strtolower(preg_replace('/[^a-z0-9]/i', '', $software_name));
			if (strlen($clean_name) >= 4 && strpos($host, $clean_name) !== false) {
				$is_official = true;
				$score += 0.25;
			}
		}

		if (isset(self::TRUSTED_STORE_HOSTS[$host])) {
			$score += 0.20;
		}

		if (preg_match(
			'/\b(download|get for|installer|offline installer|direct link|portable|trial)\b/i',
			strtolower($text . ' ' . $context)
		)) {
			$score += 0.10;
		}
		if (preg_match('/\.(exe|msi|msix|msp|appx|dmg|pkg|deb|rpm|apk|appimage|zip|7z|rar|tar\.gz|tar\.xz|tar\.bz2|tgz|iso|ipa|sh|run|bin)(?:$|[?#])/i', $url)) {
			$score += 0.10;
		}
		if (preg_match('~/download(?:/[^/]*)*(?:\?|$|#)~i', $url)) {
			$score += 0.10;
		}
		if ($software_name !== '' && stripos($text . ' ' . $context, $software_name) !== false) {
			$score += 0.20;
		}

		return min(1.0, round($score, 2));
	}

	private static function is_better(array $a, array $b): bool
	{
		if ((bool)$a['approved'] !== (bool)$b['approved']) {
			return ! empty($a['approved']);
		}
		if ((float)$a['confidence'] !== (float)$b['confidence']) {
			return (float)$a['confidence'] > (float)$b['confidence'];
		}
		return strlen((string)$a['context']) > strlen((string)$b['context']);
	}

	private static function sort_links(array $a, array $b): int
	{
		$pa = self::PLATFORM_PRIORITY[$a['platform']] ?? 99;
		$pb = self::PLATFORM_PRIORITY[$b['platform']] ?? 99;

		if ($pa !== $pb) {
			return $pa <=> $pb;
		}

		$conf_cmp = $b['confidence'] <=> $a['confidence'];
		if ($conf_cmp !== 0) {
			return $conf_cmp;
		}

		return strcmp($a['url'], $b['url']);
	}

	private static function collect_context(\DOMNode $node): string
	{
		$current = $node->parentNode;
		while ($current instanceof \DOMElement) {
			$name = strtolower($current->nodeName);
			if (in_array($name, array('div','section','article','main','aside','body','ul','ol','table'), true)) break;
			if (in_array($name, array('p','li','td','h1','h2','h3','h4','h5','h6'), true)) {
				if ($current->getElementsByTagName('a')->length > 1) return '';
				return self::normalize_text($current->textContent);
			}
			$current = $current->parentNode;
		}
		return '';
	}

	private static function normalize_url(string $url): string
	{
		return trim(html_entity_decode($url, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
	}

	public static function is_noisy_or_social(string $url, string $host): bool
	{
		// Scheme block: only valid at position 0 of the raw URL
		foreach (self::SCHEME_BLOCKLIST as $scheme) {
			if (stripos($url, $scheme) === 0) {
				return true;
			}
		}

		// Domain block: host_matches() uses exact + subdomain comparison
		foreach (self::DOMAIN_BLOCKLIST as $blocked) {
			if (self::host_matches($host, $blocked)) {
				return true;
			}
		}

		// NOISY_HOSTS: exact host / subdomain (x.com, instagram.com, etc.)
		foreach (self::NOISY_HOSTS as $noisy) {
			if (self::host_matches($host, $noisy)) {
				return true;
			}
		}

		return false;
	}

	public static function is_non_download_path(string $url): bool
	{
		$path = (string) wp_parse_url($url, PHP_URL_PATH);
		$path_lc = strtolower($path);
		if (preg_match('/\.(?:exe|msi|msix|msp|dmg|pkg|deb|rpm|apk|ipa|appimage|zip|7z|tar\.gz|tar\.xz|tar\.bz2|iso)$/i', $path)) return false;
		if (self::host($url) === 'github.com' && preg_match('~^/[^/]+/[^/]+/releases(?:/(?:latest|tag/[^/]+))?/?$~i', $path)) return false;

		foreach (self::NON_DOWNLOAD_PATH_FRAGMENTS as $fragment) {
			if (stripos($path_lc, $fragment) === false) {
				continue;
			}
			// Special exemption: /releases is a non-download path (e.g. GitHub release LISTING pages),
			// but /releases/download/ is a direct binary download — do NOT block it.
			if ($fragment === '/releases' && stripos($path_lc, '/releases/download/') !== false) {
				continue;
			}
			return true;
		}

		$query = (string) wp_parse_url($url, PHP_URL_QUERY);
		if ($query !== '') {
			$buy_keywords = array('buy', 'purchase', 'checkout', 'pricing', 'cart', 'shop', 'order');
			foreach ($buy_keywords as $term) {
				if (stripos($query, $term) !== false) {
					return true;
				}
			}
		}
		return false;
	}

	private static function host_matches(string $host, string $source_host): bool
	{
		if ($host === '' || $source_host === '') {
			return false;
		}
		return $host === $source_host || substr($host, -strlen('.' . $source_host)) === '.' . $source_host;
	}

	public static function host(string $url): string
	{
		$host = wp_parse_url($url, PHP_URL_HOST);
		return is_string($host) ? strtolower($host) : '';
	}

	private static function load_dom(string $html): ?\DOMDocument
	{
		if (trim($html) === '') {
			return null;
		}
		$dom = new \DOMDocument();
		libxml_use_internal_errors(true);
		$loaded = $dom->loadHTML('<?xml encoding="utf-8" ?>' . $html, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
		libxml_clear_errors();
		return $loaded ? $dom : null;
	}

	private static function normalize_text(string $text): string
	{
		$text = html_entity_decode(wp_strip_all_tags($text), ENT_QUOTES | ENT_HTML5, 'UTF-8');
		$text = preg_replace('/\s+/u', ' ', $text);
		return trim((string) $text);
	}
}
