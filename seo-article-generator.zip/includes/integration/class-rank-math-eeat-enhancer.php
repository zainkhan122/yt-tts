<?php

/**
 * Rank Math E-E-A-T Schema Enhancer
 *
 * Extends Rank Math's JSON-LD output with author credentials, editorial oversight,
 * and verification signals while preserving a safe public author URL.
 *
 * @package SEO_Article_Generator
 * @since   2.2.0
 */

namespace SEO_Article_Generator\Integration;

use SEO_Article_Generator\EEAT\Author_Profile_Manager;

if (!defined('ABSPATH')) {
    exit;
}

class RankMath_EEAT_Enhancer
{
    /**
     * @var Author_Profile_Manager
     */
    private $author_manager;

    public function __construct()
    {
        $this->author_manager = new Author_Profile_Manager();
    }

    public function register_hooks(): void
    {
        add_filter('rank_math/json_ld', [$this, 'enhance_schema'], 99, 2);
    }

    /**
     * Main Rank Math JSON-LD filter.
     *
     * @param mixed $data
     * @param mixed $jsonld
     * @return mixed
     */
    public function enhance_schema($data, $jsonld)
    {
        if (!is_array($data)) {
            return $data;
        }

        $post_id = $this->get_post_id($jsonld);
        if ($post_id <= 0) {
            return $data;
        }

        // [ISSUE-5 FIX] Inject FAQPage JSON-LD if post has FAQs
        $data = $this->inject_faqpage_jsonld($data, $post_id);

        $author_id = (int) \get_post_field('post_author', $post_id);
        if ($author_id <= 0) {
            return $data;
        }

        $author_profile = $this->author_manager->get_author_profile($author_id);
        $author_profile = $this->normalize_profile((array) $author_profile, $author_id);

        if (empty($author_profile['name'])) {
            return $data;
        }

        $canonical_author = $this->build_person_schema($author_profile, $author_id);

        if (isset($data['@graph']) && is_array($data['@graph'])) {
            foreach ($data['@graph'] as $index => $node) {
                if (!is_array($node)) {
                    continue;
                }

                if ($this->is_person_node($node) && $this->person_node_matches_author($node, $author_profile, $author_id)) {
                    $data['@graph'][$index] = $this->merge_person_node($node, $canonical_author);
                    continue;
                }

                $data['@graph'][$index] = $this->enhance_schema_item(
                    $node,
                    $post_id,
                    $author_id,
                    $author_profile,
                    $canonical_author
                );
            }

            // Flatten nested node-lists (e.g. Rank Math TOC block emits SiteNavigationElements
            // as a nested array) and decode HTML entities in string properties.
            // This does NOT modify or reorder any RM-owned node content.
            $data['@graph'] = $this->flatten_graph(array_values($data['@graph']));

            return $data;
        }

        return $this->enhance_schema_item($data, $post_id, $author_id, $author_profile, $canonical_author);
    }

    /**
     * Inject FAQPage JSON-LD into @graph if post has FAQs.
     *
     * Loads FAQs from the canonical article schema snapshot (_seo_gen_article_snapshot).
     * This ensures FAQPage schema is present even when Rank Math FAQ block
     * doesn't output JSON-LD (e.g., when block is not yet processed by RM).
     *
     * @param array $data    Rank Math JSON-LD data
     * @param int   $post_id Post ID
     * @return array Modified JSON-LD data
     */
    private function inject_faqpage_jsonld(array $data, int $post_id): array
    {
        // Only inject for plugin-owned posts with FAQs
        if (!class_exists('SEO_Article_Generator\Services\Schema_Sync_Service')) {
            return $data;
        }

        if (!\SEO_Article_Generator\Services\Schema_Sync_Service::has_schema($post_id)) {
            return $data;
        }

        $schema = \SEO_Article_Generator\Services\Schema_Sync_Service::load_schema($post_id);
        if (!$schema) {
            return $data;
        }

        $faqs = $schema->faqs ?? [];
        if (empty($faqs) || !is_array($faqs)) {
            return $data;
        }

        // Build FAQPage node
        $faqPage = [
            '@type'     => 'FAQPage',
            'mainEntity' => [],
        ];

        $faqIndex = 0;
        foreach ($faqs as $faq) {
            $question = isset($faq['question']) ? trim((string) $faq['question']) : '';
            $answer   = isset($faq['answer']) ? trim((string) $faq['answer']) : '';

            if ($question === '' || $answer === '') {
                continue;
            }

            // Strip HTML from answer for JSON-LD
            $cleanAnswer = wp_strip_all_tags($answer);
            $cleanAnswer = wpautop($cleanAnswer);
            $cleanAnswer = trim($cleanAnswer);

            $faqPage['mainEntity'][] = [
                '@type'          => 'Question',
                'name'           => $question,
                'acceptedAnswer' => [
                    '@type' => 'Answer',
                    'text'  => $cleanAnswer,
                ],
            ];

            if (++$faqIndex >= 10) {
                break; // Limit to 10 FAQs
            }
        }

        if (empty($faqPage['mainEntity'])) {
            return $data;
        }

        // Ensure @graph exists
        if (!isset($data['@graph']) || !is_array($data['@graph'])) {
            $data['@graph'] = [];
        }

        // Check if FAQPage already exists in graph
        foreach ($data['@graph'] as $node) {
            if (is_array($node) && isset($node['@type'])) {
                $node_types = is_array($node['@type']) ? $node['@type'] : [$node['@type']];
                if (in_array('FAQPage', $node_types, true)) {
                    return $data; // Already present
                }
            }
        }

        // Add FAQPage to graph
        $data['@graph'][] = $faqPage;

        return $data;
    }

    /**
     * Enhance article-like schema items only.
     */
    private function enhance_schema_item(array $schema, int $post_id, int $author_id, array $author_profile, array $canonical_author): array
    {
        if (!$this->is_article_like_schema($schema)) {
            return $schema;
        }

        $schema['author'] = $this->normalize_author_property(
            $schema['author'] ?? null,
            $canonical_author,
            $author_profile,
            $author_id
        );

        $schema = $this->add_editorial_oversight($schema, $post_id);
        $schema = $this->add_fact_checker($schema, $post_id);
        $schema = $this->add_verification_date($schema, $post_id);
        $schema = $this->add_transparency_signals($schema, $post_id);

        return $schema;
    }

    /**
     * Only Article-like nodes should get EEAT person properties.
     */
    private function is_article_like_schema(array $schema): bool
    {
        if (!isset($schema['@type'])) {
            return false;
        }

        $types = $this->normalize_types($schema['@type']);
        if (!$types) {
            return false;
        }

        $software_types = ['SoftwareApplication', 'Software', 'WebApplication', 'MobileApplication'];
        $article_types  = ['Article', 'TechArticle', 'NewsArticle', 'BlogPosting'];

        if (array_intersect($software_types, $types) && !array_intersect($article_types, $types)) {
            return false;
        }

        return (bool) array_intersect($article_types, $types);
    }

    /**
     * Normalize author field to one canonical safe Person object.
     *
     * @param mixed $existing
     * @return mixed
     */
    private function normalize_author_property($existing, array $canonical_author, array $profile, int $author_id)
    {
        if (empty($existing)) {
            return $canonical_author;
        }

        if (is_string($existing)) {
            return $canonical_author;
        }

        if (is_array($existing) && $this->looks_like_single_person_object($existing)) {
            if ($this->person_object_matches_profile($existing, $profile, $author_id)) {
                return $this->merge_person_node($existing, $canonical_author);
            }

            return $canonical_author;
        }

        if (is_array($existing)) {
            $out = [];
            $matched = false;

            foreach ($existing as $item) {
                if (!is_array($item)) {
                    continue;
                }

                if ($this->looks_like_single_person_object($item) && $this->person_object_matches_profile($item, $profile, $author_id)) {
                    $out[] = $this->merge_person_node($item, $canonical_author);
                    $matched = true;
                    continue;
                }

                $out[] = $item;
            }

            if (!$matched) {
                array_unshift($out, $canonical_author);
            }

            $out = $this->dedupe_person_list($out);

            return count($out) === 1 ? $out[0] : array_values($out);
        }

        return $canonical_author;
    }

    /**
     * Add reviewer/editor.
     */
    private function add_editorial_oversight(array $schema, int $post_id): array
    {
        $reviewed_by = \get_post_meta($post_id, '_seo_reviewed_by', true);

        $reviewed_by = (int) $reviewed_by;
        if ($reviewed_by <= 0) {
            return $schema;
        }

        $reviewer_profile = $this->author_manager->get_author_profile($reviewed_by);
        $reviewer_profile = $this->normalize_profile((array) $reviewer_profile, $reviewed_by);

        if (empty($reviewer_profile['name'])) {
            return $schema;
        }

        $editor = $this->build_person_schema($reviewer_profile, $reviewed_by, 'Editor');

        if (empty($schema['editor'])) {
            $schema['editor'] = $editor;
            return $schema;
        }

        if (is_array($schema['editor']) && $this->looks_like_single_person_object($schema['editor'])) {
            if ($this->same_person_identity($schema['editor'], $editor)) {
                $schema['editor'] = $this->merge_person_node($schema['editor'], $editor);
            } else {
                $schema['editor'] = [$schema['editor'], $editor];
            }
            return $schema;
        }

        if (is_array($schema['editor'])) {
            $schema['editor'] = $this->append_person_to_collection($schema['editor'], $editor);
            return $schema;
        }

        $schema['editor'] = $editor;
        return $schema;
    }

    /**
     * Add fact checker as contributor.
     */
    private function add_fact_checker(array $schema, int $post_id): array
    {
        $fact_checked_by = \get_post_meta($post_id, '_seo_fact_checked_by', true);

        $fact_checked_by = (int) $fact_checked_by;
        if ($fact_checked_by <= 0) {
            return $schema;
        }

        $fact_checker_profile = $this->author_manager->get_author_profile($fact_checked_by);
        $fact_checker_profile = $this->normalize_profile((array) $fact_checker_profile, $fact_checked_by);

        if (empty($fact_checker_profile['name'])) {
            return $schema;
        }

        $fact_checker = $this->build_person_schema($fact_checker_profile, $fact_checked_by, 'Fact Checker');

        if (empty($schema['contributor'])) {
            $schema['contributor'] = $fact_checker;
            return $schema;
        }

        if (is_array($schema['contributor']) && $this->looks_like_single_person_object($schema['contributor'])) {
            if ($this->same_person_identity($schema['contributor'], $fact_checker)) {
                $schema['contributor'] = $this->merge_person_node($schema['contributor'], $fact_checker);
            } else {
                $schema['contributor'] = [
                    $schema['contributor'],
                    $fact_checker,
                ];
            }

            return $schema;
        }

        if (is_array($schema['contributor'])) {
            $schema['contributor'] = $this->append_person_to_collection($schema['contributor'], $fact_checker);
            return $schema;
        }

        $schema['contributor'] = $fact_checker;
        return $schema;
    }

    /**
     * Update dateModified when verification date is newer.
     */
    private function add_verification_date(array $schema, int $post_id): array
    {
        $hero_data = \SEO_Article_Generator\Plugin::get_instance()->get_hero_data($post_id);
        $last_verified = is_array($hero_data) ? ($hero_data['last_verified_date'] ?? '') : '';

        if (!$last_verified) {
            return $schema;
        }

        $verified_ts = \strtotime((string) $last_verified);
        $current_ts  = !empty($schema['dateModified']) ? \strtotime((string) $schema['dateModified']) : 0;

        if ($verified_ts && $verified_ts > $current_ts) {
            $schema['dateModified'] = \date('c', $verified_ts);
        }

        return $schema;
    }

    /**
     * Add transparency properties.
     */
    private function add_transparency_signals(array $schema, int $post_id): array
    {
        $hero_data = \SEO_Article_Generator\Plugin::get_instance()->get_hero_data($post_id);
        $last_verified = is_array($hero_data) ? ($hero_data['last_verified_date'] ?? '') : '';

        if (!$last_verified) {
            return $schema;
        }

        $additional = [];

        if (isset($schema['additionalProperty'])) {
            if ($this->looks_like_single_property_value($schema['additionalProperty'])) {
                $additional[] = $schema['additionalProperty'];
            } elseif (is_array($schema['additionalProperty'])) {
                foreach ($schema['additionalProperty'] as $item) {
                    if (is_array($item)) {
                        $additional[] = $item;
                    }
                }
            }
        }

        $additional = $this->upsert_property_value($additional, [
            '@type' => 'PropertyValue',
            'name'  => 'lastFactChecked',
            'value' => (string) $last_verified,
        ]);

        $verification_notes = \get_post_meta($post_id, '_seo_verification_notes', true);
        if ($verification_notes && \strlen((string) $verification_notes) > 20) {
            $additional = $this->upsert_property_value($additional, [
                '@type' => 'PropertyValue',
                'name'  => 'editorialNote',
                'value' => \wp_trim_words((string) $verification_notes, 30),
            ]);
        }

        if (!empty($additional)) {
            $schema['additionalProperty'] = $additional;
        }

        return $schema;
    }

    /**
     * Canonical identity for Person nodes.
     * Stable @id + safe public author URL.
     */
    private function resolve_public_person_identity(array $profile, int $user_id): array
    {
        $identity = [
            '@id' => \home_url('/#person-' . $user_id),
        ];

        $author_url = \get_author_posts_url($user_id);
        if (!empty($author_url)) {
            $identity['url'] = \esc_url_raw($author_url);
        }

        return $identity;
    }

    /**
     * Build safe Person schema.
     */
    private function build_person_schema(array $profile, int $user_id, string $fallback_job = ''): array
    {
        $identity = $this->resolve_public_person_identity($profile, $user_id);

        $person = [
            '@type' => 'Person',
            '@id'   => $identity['@id'],
            'name'  => \trim((string) ($profile['name'] ?? '')),
        ];

        if (!empty($identity['url'])) {
            $person['url'] = $identity['url'];
        }

        if (!empty($profile['avatar_url'])) {
            $avatar_url = \esc_url_raw((string) $profile['avatar_url']);
            $person['image'] = [
                '@id'  => $avatar_url,
                '@type' => 'ImageObject',
                'url'  => $avatar_url,
            ];
        }

        if (!empty($profile['title'])) {
            $person['jobTitle'] = (string) $profile['title'];
        } elseif ($fallback_job !== '') {
            $person['jobTitle'] = $fallback_job;
        }

        if (!empty($profile['bio'])) {
            $person['description'] = (string) $profile['bio'];
        } elseif (!empty($profile['description'])) {
            $person['description'] = (string) $profile['description'];
        }

        if (!empty($profile['credentials'])) {
            $person['knowsAbout'] = 'Software Applications and Technology';
            $person['hasCredential'] = [
                '@type'              => 'EducationalOccupationalCredential',
                'credentialCategory' => 'Professional Experience',
                'description'        => (string) $profile['credentials'],
            ];
        }

        if (!empty($profile['social_links']) && is_array($profile['social_links'])) {
            $same_as = array_values(array_filter(array_map('esc_url_raw', $profile['social_links'])));
            if (!empty($same_as)) {
                $person['sameAs'] = $same_as;
            }
        }

        if (!empty($profile['verified'])) {
            $person['identifier'] = [
                '@type'      => 'PropertyValue',
                'propertyID' => 'verified',
                'value'      => 'true',
            ];
        }

        return $person;
    }

    /**
     * Merge node into canonical person.
     */
    private function merge_person_node(array $node, array $canonical_person): array
    {
        $merged = array_merge($node, $canonical_person);

        $merged['@type'] = 'Person';
        $merged['@id']   = $canonical_person['@id'];
        $merged['name']  = $canonical_person['name'];

        if (isset($canonical_person['url'])) {
            $merged['url'] = $canonical_person['url'];
        }

        if (isset($canonical_person['image'])) {
            $merged['image'] = $canonical_person['image'];
        }

        if (isset($canonical_person['jobTitle'])) {
            $merged['jobTitle'] = $canonical_person['jobTitle'];
        }

        if (isset($canonical_person['description'])) {
            $merged['description'] = $canonical_person['description'];
        }

        if (isset($canonical_person['knowsAbout'])) {
            $merged['knowsAbout'] = $canonical_person['knowsAbout'];
        }

        if (isset($canonical_person['hasCredential'])) {
            $merged['hasCredential'] = $canonical_person['hasCredential'];
        }

        if (isset($canonical_person['sameAs'])) {
            $merged['sameAs'] = $canonical_person['sameAs'];
        }

        if (isset($canonical_person['identifier'])) {
            $merged['identifier'] = $canonical_person['identifier'];
        }

        return $merged;
    }

    /**
     * Determine whether a graph Person node is the post author.
     */
    private function person_node_matches_author(array $node, array $profile, int $author_id): bool
    {
        $node_id   = isset($node['@id']) ? (string) $node['@id'] : '';
        $node_url  = isset($node['url']) ? (string) $node['url'] : '';
        $node_name = isset($node['name']) ? \trim((string) $node['name']) : '';

        $identity = $this->resolve_public_person_identity($profile, $author_id);

        if ($node_id !== '' && \rtrim($node_id, '/') === \rtrim((string) $identity['@id'], '/')) {
            return true;
        }

        if (!empty($identity['url']) && $node_url !== '' && \rtrim($node_url, '/') === \rtrim((string) $identity['url'], '/')) {
            return true;
        }

        foreach ($this->build_author_archive_needles($author_id) as $needle) {
            if ($needle === '') {
                continue;
            }

            if (
                ($node_id !== '' && \stripos($node_id, $needle) !== false) ||
                ($node_url !== '' && \stripos($node_url, $needle) !== false)
            ) {
                return true;
            }
        }

        $user = \get_userdata($author_id);

        $candidate_names = array_filter([
            (string) ($profile['name'] ?? ''),
            $user ? (string) $user->display_name : '',
        ]);

        foreach ($candidate_names as $candidate_name) {
            if ($node_name !== '' && \strcasecmp($node_name, \trim($candidate_name)) === 0) {
                return true;
            }
        }

        return false;
    }

    /**
     * Match inline author/editor/contributor person objects.
     */
    private function person_object_matches_profile(array $person, array $profile, int $author_id): bool
    {
        return $this->person_node_matches_author($person, $profile, $author_id);
    }

    /**
     * Legacy archive-slug match patterns for old schema nodes.
     */
    private function build_author_archive_needles(int $author_id): array
    {
        $user = \get_userdata($author_id);
        if (!$user) {
            return [];
        }

        $slugs = array_unique(array_filter([
            (string) $user->user_nicename,
            (string) $user->user_login,
            \rawurlencode((string) $user->user_nicename),
            \rawurlencode((string) $user->user_login),
        ]));

        $needles = [];
        foreach ($slugs as $slug) {
            $needles[] = '/author/' . $slug;
        }

        return array_values(array_unique(array_filter($needles)));
    }

    /**
     * Append a person to a list without duplicates.
     */
    private function append_person_to_collection(array $existing, array $person): array
    {
        $out = [];
        $matched = false;

        foreach ($existing as $item) {
            if (!is_array($item)) {
                continue;
            }

            if ($this->looks_like_single_person_object($item) && $this->same_person_identity($item, $person)) {
                $out[] = $this->merge_person_node($item, $person);
                $matched = true;
            } else {
                $out[] = $item;
            }
        }

        if (!$matched) {
            $out[] = $person;
        }

        return array_values($this->dedupe_person_list($out));
    }

    /**
     * Deduplicate list of person objects by @id or name.
     */
    private function dedupe_person_list(array $items): array
    {
        $seen = [];
        $out  = [];

        foreach ($items as $item) {
            if (!is_array($item)) {
                continue;
            }

            $key = '';
            if (!empty($item['@id'])) {
                $key = 'id:' . (string) $item['@id'];
            } elseif (!empty($item['name'])) {
                $key = 'name:' . \mb_strtolower(\trim((string) $item['name']));
            } else {
                $out[] = $item;
                continue;
            }

            if (isset($seen[$key])) {
                $out[$seen[$key]] = array_merge($out[$seen[$key]], $item);
                continue;
            }

            $seen[$key] = count($out);
            $out[] = $item;
        }

        return $out;
    }

    /**
     * Compare person identity.
     */
    private function same_person_identity(array $a, array $b): bool
    {
        $a_id = isset($a['@id']) ? (string) $a['@id'] : '';
        $b_id = isset($b['@id']) ? (string) $b['@id'] : '';

        if ($a_id !== '' && $b_id !== '' && \rtrim($a_id, '/') === \rtrim($b_id, '/')) {
            return true;
        }

        $a_url = isset($a['url']) ? (string) $a['url'] : '';
        $b_url = isset($b['url']) ? (string) $b['url'] : '';

        if ($a_url !== '' && $b_url !== '' && \rtrim($a_url, '/') === \rtrim($b_url, '/')) {
            return true;
        }

        $a_name = isset($a['name']) ? \trim((string) $a['name']) : '';
        $b_name = isset($b['name']) ? \trim((string) $b['name']) : '';

        return ($a_name !== '' && $b_name !== '' && \strcasecmp($a_name, $b_name) === 0);
    }

    /**
     * Normalize profile input.
     */
    private function normalize_profile(array $profile, int $author_id): array
    {
        $profile['name'] = \trim((string) ($profile['name'] ?? ''));
        if ($profile['name'] === '') {
            $profile['name'] = (string) \get_the_author_meta('display_name', $author_id);
        }

        if (empty($profile['bio']) && !empty($profile['description'])) {
            $profile['bio'] = (string) $profile['description'];
        }

        if (!empty($profile['avatar_url'])) {
            $profile['avatar_url'] = \esc_url_raw((string) $profile['avatar_url']);
        }

        if (!empty($profile['social_links']) && is_array($profile['social_links'])) {
            $profile['social_links'] = array_values(array_filter(array_map('esc_url_raw', $profile['social_links'])));
        }

        return $profile;
    }

    /**
     * Get post ID in frontend/admin/AJAX/REST contexts.
     *
     * @param mixed $jsonld
     */
    private function get_post_id($jsonld): int
    {
        $post_id = 0;

        if ($jsonld && is_object($jsonld) && method_exists($jsonld, 'get_post_id')) {
            $post_id = (int) $jsonld->get_post_id();
        }

        if ($post_id <= 0) {
            $post_id = (int) \get_the_ID();
        }

        if ($post_id <= 0) {
            $post_id = (int) \get_queried_object_id();
        }

        return $post_id;
    }

    /**
     * True when object is a Person node in the graph.
     *
     * @param mixed $node
     */
    private function is_person_node($node): bool
    {
        if (!is_array($node) || !isset($node['@type'])) {
            return false;
        }

        return in_array('Person', $this->normalize_types($node['@type']), true);
    }

    /**
     * True when array looks like a single person object.
     */
    private function looks_like_single_person_object(array $node): bool
    {
        if (isset($node['@type'])) {
            $types = $this->normalize_types($node['@type']);
            if (in_array('Person', $types, true)) {
                return true;
            }
        }

        return isset($node['name']) || isset($node['@id']) || isset($node['url']);
    }

    /**
     * Normalize @type to array.
     *
     * @param mixed $types
     * @return string[]
     */
    private function normalize_types($types): array
    {
        if (is_string($types) && $types !== '') {
            return [$types];
        }

        if (is_array($types)) {
            return array_values(array_filter(array_map('strval', $types)));
        }

        return [];
    }

    /**
     * Treat a single PropertyValue object as one item.
     *
     * @param mixed $value
     */
    private function looks_like_single_property_value($value): bool
    {
        return is_array($value) && (
            isset($value['@type']) ||
            isset($value['name']) ||
            isset($value['value'])
        );
    }

    /**
     * Upsert additionalProperty by name.
     */
    private function upsert_property_value(array $items, array $incoming): array
    {
        $incoming_name = isset($incoming['name']) ? (string) $incoming['name'] : '';
        if ($incoming_name === '') {
            return $items;
        }

        foreach ($items as $index => $item) {
            if (!is_array($item)) {
                continue;
            }

            if (!empty($item['name']) && \strcasecmp((string) $item['name'], $incoming_name) === 0) {
                $items[$index] = array_merge($item, $incoming);
                return $items;
            }
        }

        $items[] = $incoming;
        return $items;
    }

    /**
     * Flatten nested arrays inside @graph.
     * Rank Math's TOC block emits SiteNavigationElement entries as a single
     * nested array item instead of individual graph nodes.
     * Does NOT reorder, modify, or remove any RM-owned nodes.
     */
    private function flatten_graph(array $graph): array
    {
        $flat = [];
        foreach ($graph as $item) {
            if (!is_array($item)) {
                $flat[] = $item;
                continue;
            }

            // A nested node-list: sequential array whose entries are all arrays
            // with @type set, but the container itself has no @type or @id.
            $is_node_list = !isset($item['@type'])
                && !isset($item['@id'])
                && !empty($item)
                && array_values($item) === $item
                && isset($item[0]);

            if ($is_node_list) {
                foreach ($item as $sub_node) {
                    if (is_array($sub_node)) {
                        $flat[] = $this->decode_schema_node_strings($sub_node);
                    }
                }
            } else {
                $flat[] = $this->decode_schema_node_strings($item);
            }
        }
        return $flat;
    }

    /**
     * Decode HTML entities in top-level scalar string values of a schema node.
     * Only touches immediate string properties — never recurses into nested objects
     * so RM's structured sub-nodes are not mutated.
     */
private function decode_schema_node_strings(array $node): array
    {
        foreach ($node as $key => $value) {
            if (is_string($value)) {
                $node[$key] = html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            } elseif (is_array($value)) {
                $node[$key] = $this->decode_schema_node_strings($value);
            }
}

        return $node;
    }
}
