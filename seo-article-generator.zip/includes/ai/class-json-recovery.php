<?php

namespace SEO_Article_Generator\AI;

use SEO_Article_Generator\AI_Exception;

if (! defined('ABSPATH')) {
	exit;
}

class JSON_Recovery
{
	private static $zws_pattern;

	public static function decode(string $text, string $provider = '', $logger = null): array
	{
		if ($text === '') {
			throw new AI_Exception('Failed to parse AI response as JSON: empty input');
		}

		$attempts = array(
			array('label' => 'direct',            'method' => 'layer_direct'),
			array('label' => 'control_chars',     'method' => 'layer_control_chars'),
			array('label' => 'utf8_fix',          'method' => 'layer_utf8_fix'),
			array('label' => 'unicode_junk',      'method' => 'layer_unicode_junk'),
			array('label' => 'refence_restrip',   'method' => 'layer_fence_restrip'),
			array('label' => 'double_decode',     'method' => 'layer_double_decode'),
			array('label' => 'structural_rescue', 'method' => 'layer_structural_rescue'),
		);

		$first_error = null;

		foreach ($attempts as $i => $attempt) {
			$result = self::{$attempt['method']}($text);
			if ($result['ok']) {
				if ($i > 0 && $logger) {
					$logger->info(sprintf(
						'JSON_Recovery: Layer %d (%s) rescued %s response. First error was: %s',
						$i + 1,
						$attempt['label'],
						$provider,
						$first_error ?? 'unknown'
					));
				}
				return $result['data'];
			}
			if ($first_error === null) {
				$first_error = $result['error'];
			}
			
			// DEBUG: Log each failed layer
			if ($logger) {
				$logger->debug('JSON_Recovery layer failed', [
					'provider' => $provider,
					'layer' => $attempt['label'],
					'error' => $result['error'],
				]);
			}
		}

		throw new AI_Exception('Failed to parse AI response as JSON: ' . ($first_error ?? 'all recovery layers exhausted'));
	}

	private static function layer_direct(string $text): array
	{
		$decoded = \json_decode($text, true);
		if (\json_last_error() === JSON_ERROR_NONE && \is_array($decoded)) {
			return array('ok' => true, 'data' => $decoded);
		}
		return array('ok' => false, 'error' => \json_last_error_msg());
	}

	private static function layer_control_chars(string $text): array
	{
		$cleaned = \preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $text);
		if ($cleaned === $text) {
			return array('ok' => false, 'error' => 'Control char strip made no changes');
		}
		$decoded = \json_decode($cleaned, true);
		if (\json_last_error() === JSON_ERROR_NONE && \is_array($decoded)) {
			return array('ok' => true, 'data' => $decoded);
		}
		return array('ok' => false, 'error' => \json_last_error_msg());
	}

	private static function layer_utf8_fix(string $text): array
	{
		if (\function_exists('mb_convert_encoding')) {
			$cleaned = \mb_convert_encoding($text, 'UTF-8', 'UTF-8');
		} elseif (\function_exists('iconv')) {
			$cleaned = \iconv('UTF-8', 'UTF-8//IGNORE', $text);
		} else {
			$cleaned = \utf8_encode($text);
		}
		if ($cleaned === $text) {
			return array('ok' => false, 'error' => 'UTF-8 fix made no changes');
		}
		$decoded = \json_decode($cleaned, true);
		if (\json_last_error() === JSON_ERROR_NONE && \is_array($decoded)) {
			return array('ok' => true, 'data' => $decoded);
		}
		return array('ok' => false, 'error' => \json_last_error_msg());
	}

	private static function layer_unicode_junk(string $text): array
	{
		if (self::$zws_pattern === null) {
			self::$zws_pattern =
				'/[\xEF\xBB\xBF]'           // BOM
				. '|[\xE2\x80\x8B]'          // U+200B ZERO-WIDTH SPACE
				. '|[\xE2\x80\x8C]'          // U+200C ZERO-WIDTH NON-JOINER
				. '|[\xE2\x80\x8D]'          // U+200D ZERO-WIDTH JOINER
				. '|[\xE2\x80\x8E]'          // U+200E LEFT-TO-RIGHT MARK
				. '|[\xE2\x80\x8F]'          // U+200F RIGHT-TO-LEFT MARK
				. '|[\xE2\x80\xAD]'          // U+202D LEFT-TO-RIGHT OVERRIDE
				. '|[\xE2\x80\xAE]'          // U+202E RIGHT-TO-LEFT OVERRIDE
				. '|[\xC2\xAD]'              // U+00AD SOFT HYPHEN
				. '|[\xE2\x80\xA0]'          // U+2020 DAGGER (sometimes injected)
				. '|[\xEE\x80\x80-\xEE\xBF\xBF]/u'; // PUUA-PUAB
		}
		$cleaned = \preg_replace(self::$zws_pattern, '', $text);
		if ($cleaned === $text) {
			return array('ok' => false, 'error' => 'Unicode junk strip made no changes');
		}
		$decoded = \json_decode($cleaned, true);
		if (\json_last_error() === JSON_ERROR_NONE && \is_array($decoded)) {
			return array('ok' => true, 'data' => $decoded);
		}
		return array('ok' => false, 'error' => \json_last_error_msg());
	}

	private static function layer_fence_restrip(string $text): array
	{
		$cleaned = $text;
		if (\preg_match('/```(?:json)?\s*([\s\S]*?)```/i', $cleaned, $m)) {
			$cleaned = $m[1];
		}
		$trimmed = \trim($cleaned);
		if (! \preg_match('/^[\{\[]/', $trimmed)) {
			$start = \strpos($trimmed, '{');
			$end = \strrpos($trimmed, '}');
			if ($start !== false && $end !== false && $end > $start) {
				$cleaned = \substr($trimmed, $start, $end - $start + 1);
			}
		}
		if ($cleaned === $text) {
			return array('ok' => false, 'error' => 'Fence restrip made no changes');
		}
		$decoded = \json_decode($cleaned, true);
		if (\json_last_error() === JSON_ERROR_NONE && \is_array($decoded)) {
			return array('ok' => true, 'data' => $decoded);
		}
		return array('ok' => false, 'error' => \json_last_error_msg());
	}

	private static function layer_double_decode(string $text): array
	{
		$inner = \json_decode($text, true);
		if (\json_last_error() !== JSON_ERROR_NONE || !\is_string($inner)) {
			return array('ok' => false, 'error' => 'Not a double-encoded string');
		}
		$decoded = \json_decode($inner, true);
		if (\json_last_error() === JSON_ERROR_NONE && \is_array($decoded)) {
			return array('ok' => true, 'data' => $decoded);
		}
		return array('ok' => false, 'error' => \json_last_error_msg());
	}

	private static function layer_structural_rescue(string $text): array
	{
		$result = array();
		$n = \strlen($text);
		$pos = 0;

		while ($pos < $n) {
			$key_start = \strpos($text, '"', $pos);
			if ($key_start === false) {
				break;
			}
			$key_end = \strpos($text, '"', $key_start + 1);
			if ($key_end === false) {
				break;
			}
			$key = \substr($text, $key_start + 1, $key_end - $key_start - 1);
			$colon = \strpos($text, ':', $key_end + 1);
			if ($colon === false) {
				break;
			}
			$val_start = $colon + 1;
			$scan = $val_start;
			while ($scan < $n && $text[$scan] === ' ') {
				$scan++;
			}
			if ($scan >= $n) {
				break;
			}
			$ch = $text[$scan];
			$val_end = $scan;
			if ($ch === '"') {
				$esc = false;
				for ($i = $scan + 1; $i < $n; $i++) {
					if ($esc) {
						$esc = false;
						continue;
					}
					if ($text[$i] === '\\') {
						$esc = true;
						continue;
					}
					if ($text[$i] === '"') {
						$val_end = $i;
						break;
					}
				}
				if ($val_end === $scan) {
					break;
				}
				$raw = \substr($text, $scan, $val_end - $scan + 1);
				$decoded_val = \json_decode($raw, true);
				if (\json_last_error() === JSON_ERROR_NONE) {
					$result[$key] = $decoded_val;
				}
				$pos = $val_end + 1;
			} elseif ($ch === '[' || $ch === '{') {
				$close = ($ch === '[') ? ']' : '}';
				$depth = 1;
				$in_str = false;
				$esc2 = false;
				for ($i = $scan + 1; $i < $n; $i++) {
					$c = $text[$i];
					if ($esc2) {
						$esc2 = false;
						continue;
					}
					if ($c === '\\' && $in_str) {
						$esc2 = true;
						continue;
					}
					if ($c === '"' && !$esc2) {
						$in_str = !$in_str;
						continue;
					}
					if ($in_str) {
						continue;
					}
					if ($c === $ch) {
						$depth++;
					} elseif ($c === $close) {
						$depth--;
						if ($depth === 0) {
							$val_end = $i;
							break;
						}
					}
				}
				if ($depth !== 0) {
					$pos = $scan + 1;
					continue;
				}
				$raw = \substr($text, $scan, $val_end - $scan + 1);
				$decoded_val = \json_decode($raw, true);
				if (\json_last_error() === JSON_ERROR_NONE && \is_array($decoded_val)) {
					$result[$key] = $decoded_val;
				}
				$pos = $val_end + 1;
			} elseif ($ch === 't' || $ch === 'f') {
				$word = ($ch === 't') ? 'true' : 'false';
				$seg = \substr($text, $scan, 5);
				if (\strpos($seg, $word) === 0) {
					$result[$key] = ($ch === 't');
					$pos = $scan + \strlen($word);
				} else {
					$pos = $scan + 1;
				}
			} elseif ($ch === 'n') {
				if (\substr($text, $scan, 4) === 'null') {
					$result[$key] = null;
					$pos = $scan + 4;
				} else {
					$pos = $scan + 1;
				}
			} elseif ($ch === '-' || ($ch >= '0' && $ch <= '9')) {
				$num_end = $scan;
				while ($num_end < $n && \strpos('-+.eE0123456789', $text[$num_end]) !== false) {
					$num_end++;
				}
				$raw_num = \substr($text, $scan, $num_end - $scan);
				if (\is_numeric($raw_num)) {
					$result[$key] = \strpos($raw_num, '.') !== false ? (float) $raw_num : (int) $raw_num;
				}
				$pos = $num_end;
			} else {
				$pos = $scan + 1;
			}
		}

		if (! empty($result)) {
			$result['_recovery_partial'] = true;
			return array('ok' => true, 'data' => $result);
		}

		return array('ok' => false, 'error' => 'Structural rescue found no extractable key-value pairs');
	}
}
