<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class BrandingRemover {
    public function remove_branding( $image_path, $branding_elements ) {
        $temp_dir = dirname( $image_path ) . '/branding_removed/';
        if ( ! file_exists( $temp_dir ) ) {
            wp_mkdir_p( $temp_dir );
        }
        
        $output_path = $temp_dir . 'cleaned_' . basename( $image_path );
        
        // Use ImageMagick to remove detected branding areas
        $command = $this->build_imagemagick_command( $image_path, $output_path, $branding_elements );
        exec( $command, $output, $return_code );
        
        if ( $return_code === 0 && file_exists( $output_path ) ) {
            Logger::info( Config::LOG_ACTION_BRANDING_REMOVED, null, [
                'input_path' => $image_path,
                'output_path' => $output_path,
                'elements_processed' => count( $branding_elements['logos'] ?? [] ) + count( $branding_elements['text_elements'] ?? [] ),
            ], '200' );
            return $output_path;
        }
        
        // Fallback to AI inpainting if available
        return $this->ai_inpaint_branding( $image_path, $branding_elements );
    }
    
    private function build_imagemagick_command( $input_path, $output_path, $elements ) {
        $command = escapeshellcmd( Config::IM_CONVERT_PATH ) . " '{$input_path}' ";
        
        $process_element = function($el) use (&$command) {
            $pos = isset( $el['position'] ) ? strtolower($el['position']) : '';
            if (empty($pos)) return;
            
            // If it's already a valid IM geometry (e.g., 100x100+10+10)
            if ( preg_match('/^\d+%?x\d+%?\+\d+\+\d+$/', $pos) ) {
                $command .= "-region {$pos} -blur 0x15 +region ";
                return;
            }
            
            // Map semantic position to gravity and region size
            $gravity = 'Center';
            $size = '25%x25%'; // Default corner size
            
            if (strpos($pos, 'top') !== false) {
                if (strpos($pos, 'left') !== false) { $gravity = 'NorthWest'; }
                elseif (strpos($pos, 'right') !== false) { $gravity = 'NorthEast'; }
                else { $gravity = 'North'; $size = '100%x15%'; }
            }
            elseif (strpos($pos, 'bottom') !== false) {
                if (strpos($pos, 'left') !== false) { $gravity = 'SouthWest'; }
                elseif (strpos($pos, 'right') !== false) { $gravity = 'SouthEast'; }
                else { $gravity = 'South'; $size = '100%x18%'; }
            }
            elseif (strpos($pos, 'left') !== false) { $gravity = 'West'; }
            elseif (strpos($pos, 'right') !== false) { $gravity = 'East'; }
            
            $command .= "-gravity {$gravity} -region {$size} -blur 0x15 +region ";
        };

        if ( isset( $elements['logos'] ) ) {
            foreach ( $elements['logos'] as $logo ) {
                $process_element($logo);
            }
        }
        
        if ( isset( $elements['text_elements'] ) ) {
            foreach ( $elements['text_elements'] as $text ) {
                $process_element($text);
            }
        }

        if ( isset( $elements['patterns'] ) ) {
            foreach ( $elements['patterns'] as $pattern ) {
                // Patterns without positions fall back to a generic bottom text band blur
                $pos = isset( $pattern['position'] ) ? $pattern['position'] : 'bottom';
                $pattern['position'] = $pos;
                $process_element($pattern);
            }
        }
        
        // Reset gravity at the end
        $command .= "+gravity '{$output_path}'";
        
        return $command;
    }
    
    private function ai_inpaint_branding( $image_path, $branding_elements ) {
        // Fallback AI inpainting would go here
        // For now, return original path
        Logger::warning( 'ai_inpainting_not_implemented', null, [
            'image_path' => $image_path,
            'elements_count' => count( $branding_elements ),
        ], '501' );
        
        return $image_path;
    }
}