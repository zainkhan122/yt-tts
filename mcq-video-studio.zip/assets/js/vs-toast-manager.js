/**
 * MCQVS Toast Manager (Professional UI)
 * - Safe (no innerHTML injection)
 * - Accessible (ARIA live region)
 * - Stack + auto-dismiss + close button
 * - No external CSS dependency (injects its own)
 */

(function (window, document) {
    'use strict';

    if (!window || !document) return;

    var STYLE_ID = 'mcqvs-toast-styles';
    var WRAP_ID = 'mcqvs-toast-wrap';

    var DEFAULT_DURATION = 3200;
    var MAX_VISIBLE = 4;

    function ensureStyles() {
        if (document.getElementById(STYLE_ID)) return;

        var css = [
            ':root{',
            '  --mcqvs-toast-bg: rgba(15,23,42,.92);',
            '  --mcqvs-toast-border: rgba(148,163,184,.22);',
            '  --mcqvs-toast-text: rgba(255,255,255,.92);',
            '  --mcqvs-toast-muted: rgba(255,255,255,.70);',
            '  --mcqvs-toast-shadow: 0 20px 50px rgba(0,0,0,.35);',
            '  --mcqvs-toast-radius: 14px;',
            '  --mcqvs-toast-gap: 10px;',
            '  --mcqvs-toast-w: 380px;',
            '}',

            '#' + WRAP_ID + '{',
            '  position: fixed;',
            '  right: 18px;',
            '  bottom: 18px;',
            '  z-index: 2147483647;', // @MODIFIED 2026-02-07: Max Z-Index for visibility
            '  display: flex;',
            '  flex-direction: column;',
            '  gap: var(--mcqvs-toast-gap);',
            '  width: min(var(--mcqvs-toast-w), calc(100vw - 36px));',
            '  pointer-events: none;',
            '}',

            '.mcqvs-toast{',
            '  pointer-events: auto;',
            '  display: grid;',
            '  grid-template-columns: 34px 1fr 34px;',
            '  align-items: start;',
            '  gap: 10px;',
            '  padding: 12px 12px 10px 12px;',
            '  border-radius: var(--mcqvs-toast-radius);',
            '  background: var(--mcqvs-toast-bg);',
            '  border: 1px solid var(--mcqvs-toast-border);',
            '  box-shadow: var(--mcqvs-toast-shadow);',
            '  backdrop-filter: blur(10px);',
            '  -webkit-backdrop-filter: blur(10px);',
            '  transform: translateY(10px);',
            '  opacity: 0;',
            '  animation: mcqvsToastIn .18s ease-out forwards;',
            '}',

            '.mcqvs-toast[data-type="success"]{ --mcqvs-accent: #22c55e; }',
            '.mcqvs-toast[data-type="error"]{   --mcqvs-accent: #ef4444; }',
            '.mcqvs-toast[data-type="warning"]{ --mcqvs-accent: #f59e0b; }',
            '.mcqvs-toast[data-type="info"]{    --mcqvs-accent: #38bdf8; }',
            '.mcqvs-toast{ border-left: 4px solid var(--mcqvs-accent); }',

            '.mcqvs-toast__icon{',
            '  width: 34px; height: 34px;',
            '  border-radius: 10px;',
            '  display: grid; place-items: center;',
            '  background: rgba(255,255,255,.06);',
            '  color: var(--mcqvs-accent);',
            '}',

            '.mcqvs-toast__body{ min-width: 0; }',
            '.mcqvs-toast__title{',
            '  font: 600 13px/1.2 Inter, Roboto, Outfit, sans-serif;',
            '  color: var(--mcqvs-toast-muted);',
            '  margin: 2px 0 4px 0;',
            '  letter-spacing: .2px;',
            '}',
            '.mcqvs-toast__msg{',
            '  font: 600 14px/1.35 Inter, Roboto, Outfit, sans-serif;',
            '  color: var(--mcqvs-toast-text);',
            '  margin: 0;',
            '  word-break: break-word;',
            '}',

            '.mcqvs-toast__close{',
            '  width: 34px; height: 34px;',
            '  border: 0;',
            '  background: transparent;',
            '  border-radius: 10px;',
            '  cursor: pointer;',
            '  color: rgba(255,255,255,.75);',
            '  display: grid; place-items: center;',
            '}',

            '.mcqvs-toast__close:hover{ background: rgba(255,255,255,.06); color: #fff; }',
            '.mcqvs-toast__close:focus{ outline: 2px solid rgba(56,189,248,.55); outline-offset: 2px; }',

            '.mcqvs-toast__progress{',
            '  grid-column: 1 / -1;',
            '  height: 2px;',
            '  background: rgba(255,255,255,.10);',
            '  border-radius: 999px;',
            '  overflow: hidden;',
            '  margin-top: 10px;',
            '}',
            '.mcqvs-toast__progress > i{',
            '  display: block;',
            '  height: 100%;',
            '  width: 100%;',
            '  background: var(--mcqvs-accent);',
            '  transform-origin: left center;',
            '  transform: scaleX(1);',
            '  animation: mcqvsToastProg linear forwards;',
            '  animation-duration: var(--mcqvs-toast-duration, 3200ms);',
            '}',

            '.mcqvs-toast.is-leaving{ animation: mcqvsToastOut .16s ease-in forwards; }',

            '@keyframes mcqvsToastIn{ to{ opacity:1; transform: translateY(0); } }',
            '@keyframes mcqvsToastOut{ to{ opacity:0; transform: translateY(10px); } }',
            '@keyframes mcqvsToastProg{ to{ transform: scaleX(0); } }',

            '@media (prefers-reduced-motion: reduce){',
            '  .mcqvs-toast{ animation: none; opacity:1; transform:none; }',
            '  .mcqvs-toast__progress > i{ animation: none; }',
            '}'
        ].join('\n');

        var style = document.createElement('style');
        style.id = STYLE_ID;
        style.type = 'text/css';
        style.appendChild(document.createTextNode(css));
        document.head.appendChild(style);
    }

    function ensureWrap() {
        var wrap = document.getElementById(WRAP_ID);
        if (wrap) return wrap;

        wrap = document.createElement('div');
        wrap.id = WRAP_ID;
        wrap.setAttribute('aria-live', 'polite');
        wrap.setAttribute('aria-relevant', 'additions text');
        document.body.appendChild(wrap);
        return wrap;
    }

    function iconSvg(type) {
        // minimalist inline SVG (no dependencies)
        var path = '';
        if (type === 'success') path = 'M9.2 16.6 5.6 13l1.4-1.4 2.2 2.2 5-5L15.6 10z';
        else if (type === 'error') path = 'M7.3 7.3 12 12m0 0 4.7 4.7M12 12 16.7 7.3M12 12 7.3 16.7';
        else if (type === 'warning') path = 'M12 7v5m0 3h.01M10.3 4.5h3.4L19 18H5z';
        else path = 'M12 7h.01M11 10h2v6h-2z';

        var vb = (type === 'warning') ? '0 0 24 24' : '0 0 24 24';
        return '<svg width="18" height="18" viewBox="' + vb + '" fill="none" xmlns="http://www.w3.org/2000/svg">' +
            '<path d="' + path + '" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>' +
            '</svg>';
    }

    function normalizeArgs(message, type, duration) {
        // Support:
        // 1) show("text", "success", 3000)
        // 2) show({ message, type, duration, title })
        var opts = {};

        if (message && typeof message === 'object' && (message.message || message.text)) {
            opts.message = String(message.message || message.text || '');
            opts.type = String(message.type || 'info');
            opts.duration = message.duration;
            opts.title = message.title;
            return opts;
        }

        opts.message = String(message || '');
        opts.type = String(type || 'info');
        opts.duration = duration;
        return opts;
    }

    function clampType(t) {
        var x = String(t || 'info').toLowerCase();
        if (x === 'success' || x === 'error' || x === 'warning' || x === 'info') return x;
        return 'info';
    }

    function dismissToast(toastEl) {
        if (!toastEl || toastEl._mcqvsDismissed) return;
        toastEl._mcqvsDismissed = true;

        toastEl.classList.add('is-leaving');
        window.setTimeout(function () {
            if (toastEl && toastEl.parentNode) toastEl.parentNode.removeChild(toastEl);
        }, 170);
    }

    function enforceMaxVisible(wrap) {
        var children = wrap.children;
        while (children.length > MAX_VISIBLE) {
            dismissToast(children[0]);
        }
    }

    function show(message, type, duration) {
        ensureStyles();
        var wrap = ensureWrap();

        var opts = normalizeArgs(message, type, duration);
        var t = clampType(opts.type);
        var dur = Number(opts.duration);
        // @MODIFIED 2026-02-08: Support 0 as sticky (infinite)
        if (dur === 0) {
            // Keep infinite
        } else if (!isFinite(dur) || dur < 800) {
            dur = DEFAULT_DURATION;
        }

        var toast = document.createElement('div');
        toast.className = 'mcqvs-toast';
        toast.setAttribute('data-type', t);
        toast.style.setProperty('--mcqvs-toast-duration', String(dur) + 'ms');

        var icon = document.createElement('div');
        icon.className = 'mcqvs-toast__icon';
        icon.innerHTML = iconSvg(t); // static SVG only

        var body = document.createElement('div');
        body.className = 'mcqvs-toast__body';

        var title = document.createElement('div');
        title.className = 'mcqvs-toast__title';
        title.textContent = opts.title ? String(opts.title) : (
            t === 'success' ? 'Success' :
                t === 'error' ? 'Error' :
                    t === 'warning' ? 'Warning' : 'Info'
        );

        var msg = document.createElement('p');
        msg.className = 'mcqvs-toast__msg';
        msg.textContent = opts.message;

        body.appendChild(title);
        body.appendChild(msg);

        var closeBtn = document.createElement('button');
        closeBtn.type = 'button';
        closeBtn.className = 'mcqvs-toast__close';
        closeBtn.setAttribute('aria-label', 'Dismiss notification');
        closeBtn.innerHTML =
            '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">' +
            '<path d="M7 7l10 10M17 7 7 17" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>' +
            '</svg>';

        closeBtn.addEventListener('click', function () {
            dismissToast(toast);
        });

        var prog = document.createElement('div');
        prog.className = 'mcqvs-toast__progress';
        var bar = document.createElement('i');
        prog.appendChild(bar);

        toast.appendChild(icon);
        toast.appendChild(body);
        toast.appendChild(closeBtn);
        toast.appendChild(prog);

        wrap.appendChild(toast);
        enforceMaxVisible(wrap);

        // @MODIFIED 2026-02-08: Only auto-dismiss if duration > 0
        var timer = null;
        if (dur > 0) {
            timer = window.setTimeout(function () {
                dismissToast(toast);
            }, dur);
        }

        toast.addEventListener('mouseenter', function () {
            // Optional: keep it visible while hovered (professional UX)
            if (timer) { window.clearTimeout(timer); timer = null; }
        });

        toast.addEventListener('mouseleave', function () {
            if (!toast._mcqvsDismissed) {
                timer = window.setTimeout(function () { dismissToast(toast); }, 1200);
            }
        });

        return toast;
    }

    function dismissAll() {
        var wrap = document.getElementById(WRAP_ID);
        if (!wrap) return;
        var items = Array.prototype.slice.call(wrap.children);
        for (var i = 0; i < items.length; i++) dismissToast(items[i]);
    }

    // Public API (keep it stable so existing code doesn't break)
    var api = {
        show: show,
        success: function (msg, dur) { return show(msg, 'success', dur); },
        error: function (msg, dur) { return show(msg, 'error', dur); },
        warning: function (msg, dur) { return show(msg, 'warning', dur); },
        info: function (msg, dur) { return show(msg, 'info', dur); },
        dismissAll: dismissAll,

        // @NEW 2026-02-07: Explicit progress toast helper
        progress: function (title, startPct) {
            var t = show({ title: title, message: 'Starting...', type: 'info', duration: 0 }, 'info', 0);

            // Remove CSS animation to allow manual control
            var bar = t.querySelector('.mcqvs-toast__progress > i');
            if (bar) {
                bar.style.animation = 'none';
                bar.style.width = '100%';
                bar.style.transform = 'scaleX(' + ((startPct || 0) / 100) + ')';
            }

            return {
                updateProgress: function (pct, msg) {
                    if (t._mcqvsDismissed) return;
                    if (msg) {
                        var mEl = t.querySelector('.mcqvs-toast__msg');
                        if (mEl) mEl.textContent = msg;
                    }
                    if (bar) {
                        bar.style.transform = 'scaleX(' + Math.max(0, Math.min(1, pct / 100)) + ')';
                    }
                },
                dismiss: function () {
                    dismissToast(t);
                },
                element: t
            };
        }
    };

    window.MCQVS_ToastManager = api;
    window.MCQVS_Toast = api;
    window.NMToast = api;

})(window, document);
