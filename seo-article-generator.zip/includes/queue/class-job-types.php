<?php

/**
 * Job Type Constants
 *
 * @package SEO_Article_Generator
 * @MODIFIED 2026-03-02 v2.19.0: Industrial Queue Architecture
 */

namespace SEO_Article_Generator\Queue;

// Prevent direct access
if (! defined('ABSPATH')) {
    exit;
}

/**
 * Defines all valid queue job type identifiers.
 */
class Job_Types
{
    const PROCESS_DRAFT      = 'process_draft';
    const CLEANUP_DISCOVERY  = 'cleanup_discovery';
    const CLEANUP_RETENTION  = 'cleanup_retention';
    const GENERATE_ARTICLE   = 'generate_article';

    /**
     * Prevent instantiation.
     */
    private function __construct() {}
}
