<?php

namespace SEO_Article_Generator\Tests\Fakes;

/**
 * Mock AI Client for testing
 */
class Mock_AI_Client extends \SEO_Article_Generator\AI\AI_Client
{
    private $responses = array();

    public function __construct($logger = null)
    {
        if (!$logger) {
            $logger = new Null_Logger();
        }
        // Initialize parent to ensure $this->logger and other properties are set
        parent::__construct('gemini', 'mock-key', $logger);
    }

    public function queue_response($response)
    {
        $this->responses[] = $response;
    }

    /**
     * Override generate_article to return queued responses
     */
    public function generate_article($prompt_data)
    {
        if (empty($this->responses)) {
            throw new \RuntimeException('No mock responses queued in Mock_AI_Client for generate_article');
        }
        return array_shift($this->responses);
    }

    /**
     * Override execute_safe_request to provide a default extraction response
     * and avoid consuming the article generation queue.
     */
    public function execute_safe_request($endpoint, $args, $provider)
    {
        // Extract prompt to see what's being asked
        $body_decoded = json_decode($args['body'] ?? '', true);
        $prompt = '';
        
        if (isset($body_decoded['contents'][0]['parts'][0]['text'])) {
            $prompt = $body_decoded['contents'][0]['parts'][0]['text'];
        } elseif (isset($body_decoded['messages'])) {
            $last_msg = end($body_decoded['messages']);
            $prompt = $last_msg['content'] ?? '';
        }

        // Default response for Context_Extractor
        $extracted_data = array(
            'software_name'       => 'VLC Media Player',
            'version'             => '4.0',
            'category'            => 'Video Player',
            'existing_features'   => array('Play Video', 'Play Audio'),
            'is_existing_article' => false,
            'homepage'            => 'https://www.videolan.org/vlc/'
        );

        // Try to be more "real" by extracting software name from prompt if possible
        if (preg_match('/INPUT TEXT:\s*(.*?)(?:\n|$)/i', $prompt, $matches)) {
            $software = trim($matches[1]);
            if ($software !== '' && strlen($software) < 100) {
                $extracted_data['software_name'] = $software;
            }
        }

        $body = array(
            'candidates' => array(
                array(
                    'content' => array(
                        'parts' => array(
                            array(
                                'text' => json_encode($extracted_data)
                            )
                        )
                    )
                )
            )
        );

        return array(
            'body'     => json_encode($body),
            'response' => array('code' => 200),
            'headers'  => array('content-type' => 'application/json'),
        );
    }

    public function test_connection()
    {
        return array('status' => 'ok', 'model' => 'mock-model');
    }
}
