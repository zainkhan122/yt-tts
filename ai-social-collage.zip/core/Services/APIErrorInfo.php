<?php
namespace AiSocialCollage\Services;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class APIErrorInfo {

	const TYPE_QUOTA_RPD         = 'quota_rpd';
	const TYPE_QUOTA_RPM         = 'quota_rpm';
	const TYPE_QUOTA_TPM         = 'quota_tpm';
	const TYPE_QUOTA_UNKNOWN     = 'quota_unknown';
	const TYPE_AUTH_FAILURE      = 'auth_failure';
	const TYPE_MODEL_NOT_FOUND   = 'model_not_found';
	const TYPE_REQUEST_SHAPE     = 'request_shape';
	const TYPE_SERVER_OVERLOADED = 'server_overloaded';
	const TYPE_TRANSIENT         = 'transient';
	const TYPE_UNKNOWN           = 'unknown';

	public string $error_type;
	public bool $is_retryable;
	public bool $is_deterministic;
	public int $retry_after;
	public int $reset_at;
	public string $raw_message;
	public string $provider;

	public function __construct( string $error_type, string $raw_message, string $provider = '' ) {
		$this->error_type    = $error_type;
		$this->raw_message   = $raw_message;
		$this->provider      = $provider;
		$this->retry_after   = 0;
		$this->reset_at      = 0;

		$this->is_retryable    = self::classify_retryable( $error_type );
		$this->is_deterministic = self::classify_deterministic( $error_type );
	}

	private static function classify_retryable( string $type ): bool {
		switch ( $type ) {
			case self::TYPE_QUOTA_RPD:
			case self::TYPE_QUOTA_RPM:
			case self::TYPE_QUOTA_TPM:
			case self::TYPE_QUOTA_UNKNOWN:
			case self::TYPE_SERVER_OVERLOADED:
			case self::TYPE_TRANSIENT:
				return true;
			default:
				return false;
		}
	}

	private static function classify_deterministic( string $type ): bool {
		switch ( $type ) {
			case self::TYPE_AUTH_FAILURE:
			case self::TYPE_MODEL_NOT_FOUND:
			case self::TYPE_REQUEST_SHAPE:
				return true;
			default:
				return false;
		}
	}

	public function is_quota_error(): bool {
		return in_array( $this->error_type, [
			self::TYPE_QUOTA_RPD,
			self::TYPE_QUOTA_RPM,
			self::TYPE_QUOTA_TPM,
			self::TYPE_QUOTA_UNKNOWN,
			self::TYPE_SERVER_OVERLOADED,
		], true );
	}

	public function is_daily_quota(): bool {
		return $this->error_type === self::TYPE_QUOTA_RPD;
	}

	public function get_retry_after(): int {
		return $this->retry_after;
	}

	public function get_reset_at_ts(): int {
		return $this->reset_at;
	}
}
