<?php

/**
 * Duplicate Tool Class
 *
 * @version 2.1 - Ported V23 UI
 * @MODIFIED: Replaced render_page with the advanced batch-scanning UI from V23's 11-duplicate-tool.php.
 * @MODIFIED: AJAX handlers are now in NM_AJAX_Manager.
 * @MODIFIED: Standardized AJAX nonce to 'nm_ajax_dashboard'.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class NM_Duplicate_Tool {


	/**
	 * Initialize hooks
	 */
	public static function init() {
		// Register the submenu page
		add_action( 'admin_menu', array( self::class, 'register_submenu' ), 14 );
	}

	/**
	 * Register the submenu page
	 */
	public static function register_submenu() {
		add_submenu_page(
			'nm_mcq_generator',   // Parent Slug
			'Similar Questions',  // Page Title
			'🔗 Similar Questions', // Menu Title
			'manage_options',     // Capability
			'nm_similar_questions', // Menu Slug
			array( self::class, 'render_page' ) // Callback
		);
	}

	/**
	 * ✅ MODIFIED: Renders the advanced V23 page
	 */
	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Access denied' );
		}

		$threshold = floatval( get_option( 'nm_similarity_threshold', 0.7 ) );

		global $wpdb;
		$total_count = $wpdb->get_var(
			"
    SELECT COUNT(DISTINCT p.ID)
    FROM {$wpdb->posts} p
    INNER JOIN {$wpdb->prefix}mcq_embeddings e ON p.ID = e.post_id
    WHERE p.post_type = 'mcq'
      AND p.post_status IN ('publish', 'draft', 'pending')
"
		);

		// Fetch last full scan metadata for display
		$last_scan_meta      = array(
			'last_cursor' => (int) get_option( 'nm_duplicate_scan_last_cursor', 0 ),
			'last_run'    => get_option( 'nm_duplicate_scan_last_run', '' ),
		);
		$last_run_display    = ! empty( $last_scan_meta['last_run'] )
			? date( 'Y-m-d H:i:s', strtotime( $last_scan_meta['last_run'] ) )
			: 'Never';
		$last_cursor_display = $last_scan_meta['last_cursor'] > 0
			? number_format( $last_scan_meta['last_cursor'] )
			: 'N/A';
		?>

		<div class="nm-duplicate-tool-wrap">
			<p><strong>Total MCQs with embeddings:</strong> <?php echo number_format( $total_count ); ?></p>

			<!-- NEW: Last full scan info -->
			<p style="margin-top: 10px; font-size: 13px; color: #666;">
				<strong>Last full scan:</strong> <?php echo esc_html( $last_run_display ); ?>
				(cursor: <?php echo esc_html( $last_cursor_display ); ?>)
			</p>

			<!-- NEW: Scan mode selector -->
			<p style="margin-top: 15px;">
				<label><strong>Scan mode:</strong></label><br />
				<label style="margin-right: 20px;">
					<input type="radio" name="nm_scan_mode" value="full" checked />
					Scan all MCQs
				</label>
				<label>
					<input type="radio" name="nm_scan_mode" value="since_last" />
					Scan only new since last full scan
				</label>
			</p>

			<!-- Threshold dropdown -->
			<p style="margin-top: 15px;">
				<label for="nm-similarity-threshold"><strong>Similarity Threshold:</strong></label>
				<select id="nm-similarity-threshold">
					<option value="0.95">95% (Very strict)</option>
					<option value="0.9">90%</option>
					<option value="0.85">85%</option>
					<option value="0.8">80%</option>
					<option value="0.75" selected>75% (Recommended)</option>
					<option value="0.7">70%</option>
					<option value="0.65">65%</option>
					<option value="0.6">60%</option>
				</select>
			</p>

			<button id="nm-start-scan-btn" class="button button-primary" style="margin-top: 15px;">🔍 Scan Again</button>
			<button id="nm-stop-scan-btn" class="button" style="margin-top: 15px; margin-left: 10px; display:none;">⏸️ Stop Scan</button>

			<div id="nm-progress-container" style="display:none; margin-top: 20px;">
				<p id="nm-scanning-status" style="font-weight: bold; color: #135e96;">Ready to scan...</p>
				<div class="nm-progress-bar-bg">
					<div id="nm-progress-bar" class="nm-progress-bar-fill">0%</div>
				</div>
				<p id="nm-progress-text">Scanned 0 / 0</p>
				<p id="nm-progress-stats" style="margin-top: 5px; font-size: 12px; color: #666;"></p>
			</div>

			<div id="nm-similar-questions-results" style="display:none; margin-top: 20px;"></div>

			<div id="nm-consolidate-notice" class="notice notice-info" style="display:none; margin-top: 20px;">
				<p></p>
			</div>
		</div>

		<style>
			.nm-similar-questions-wrap {
				max-width: 1200px;
			}

			.nm-scan-controls {
				margin: 20px 0;
			}

			.nm-progress-bar-bg {
				width: 100%;
				height: 30px;
				background: #f0f0f1;
				border-radius: 15px;
				overflow: hidden;
				border: 1px solid #c3c4c7;
			}

			.nm-progress-bar-fill {
				height: 100%;
				background: linear-gradient(90deg, #2271b1, #135e96);
				width: 0%;
				transition: width 0.3s ease;
				display: flex;
				align-items: center;
				justify-content: center;
				color: white;
				font-weight: bold;
			}

			.nm-similar-group {
				background: #fff;
				border: 1px solid #c3c4c7;
				padding: 20px;
				margin-top: 20px;
				border-radius: 4px;
			}

			.nm-similar-group h3 {
				margin-top: 0;
				padding-bottom: 10px;
				border-bottom: 2px solid #dc3545;
			}

			.nm-similar-group ul {
				margin: 10px 0 0 0;
				padding: 0;
				list-style: none;
			}

			.nm-similar-group li {
				display: flex;
				justify-content: space-between;
				align-items: center;
				padding: 15px;
				margin: 10px 0;
				background: #f8f9fa;
				border-left: 3px solid #2271b1;
				border-radius: 3px;
			}

			.nm-question-details {
				flex-grow: 1;
				margin-right: 15px;
			}

			.nm-correct-answer {
				font-size: 0.9em;
				color: #555;
				margin-top: 8px;
				padding: 8px;
				background: #fff;
				border-radius: 3px;
			}

			.nm-similarity-badge {
				display: inline-block;
				padding: 4px 10px;
				border-radius: 10px;
				font-size: 11px;
				font-weight: 600;
				color: white;
				margin-left: 10px;
			}

			.nm-sim-high {
				background: #dc3545;
			}

			.nm-keep-btn {
				background: #28a745;
				border-color: #28a745;
				color: white;
				font-weight: 600;
			}
		</style>

		<script type="text/javascript">
			jQuery(document).ready(function($) {
				'use strict';

				const startBtn = $('#nm-start-scan-btn');
				const stopBtn = $('#nm-stop-scan-btn');
				const progressContainer = $('#nm-progress-container');
				const progressBar = $('#nm-progress-bar');
				const progressText = $('#nm-progress-text');
				const progressStats = $('#nm-progress-stats');
				const scanningStatus = $('#nm-scanning-status');
				const resultsContainer = $('#nm-similar-questions-results');
				const notice = $('#nm-consolidate-notice');

				// ✅ MODIFIED: Using the standard dashboard nonce
				const securityToken = '<?php echo wp_create_nonce( 'nm_admin_nonce' ); ?>';

				let scanStopped = false;
				let allGroups = [];
				const BATCH_SIZE = 200;

				// NEW: local scan state (cursor + scanned counter + batch index)
				let currentCursor = 0;
				let scannedTotal = 0;
				let batchIndex = 0;

				startBtn.on('click', function() {
					// Read selected mode
					var scanMode = $('input[name="nm_scan_mode"]:checked').val();

					// If "since_last" is selected but there's no prior full scan, auto-switch to full
					<?php if ( $last_scan_meta['last_cursor'] === 0 ) : ?>
						if (scanMode === 'since_last') {
							alert('No previous full scan found. Switching to "Scan all MCQs" mode.');
							scanMode = 'full';
							$('input[name="nm_scan_mode"][value="full"]').prop('checked', true);
						}
					<?php endif; ?>

					scanStopped = false;
					allGroups = [];
					currentCursor = 0;
					scannedTotal = 0;
					batchIndex = 0;

					// ✅ Reset and update UI state
					startBtn.hide();
					stopBtn.show();
					progressContainer.show();
					resultsContainer.html('').hide();
					notice.hide();
					progressBar.css('width', '0%').text('0%');
					progressText.html('Scanned 0 / 0');
					progressStats.text('');
					scanningStatus.text('🔄 Scanning...').css('color', '#135e96');

					// Start from cursor = 0 (no ID yet processed), passing mode
					scanBatch(currentCursor, scanMode);
				});
				stopBtn.on('click', function() {
					scanStopped = true;
					stopBtn.prop('disabled', true).text('⏸️ Stopping...');
				});

				function scanBatch(cursor, mode) {
					if (scanStopped) {
						stopBtn.hide();
						startBtn.show().text('▶️ Resume');
						progressText.text('⏸️ Paused');
						return;
					}

					currentCursor = cursor;

					$.ajax({
						url: ajaxurl,
						type: 'POST',
						data: {
							action: 'nm_scan_batch', // This handler is in NMAJAXAdmin
							_wpnonce: securityToken,
							cursor: currentCursor,
							batch_size: BATCH_SIZE,
							mode: mode // NEW: pass the scan mode
						},
						success: function(response) {
							if (!response.success) {
								alert('Error: ' + (response.data.message || 'Unknown'));
								resetUI();
								return;
							}

							const data = response.data;

							// NEW: track how many rows we have scanned so far on the client
							scannedTotal += data.batch_count;
							batchIndex++;

							const total = data.total;
							const progress = total > 0 ? Math.round((scannedTotal / total) * 100) : 100;

							progressBar.css('width', progress + '%').text(progress + '%');
							progressText.html(
								`📊 Scanned <strong>${scannedTotal.toLocaleString()}</strong> of <strong>${total.toLocaleString()}</strong>`
							);
							progressStats.text(
								`Found ${data.groups_in_batch} groups in batch ${batchIndex}`
							);

							if (data.groups && data.groups.length > 0) {
								allGroups = allGroups.concat(data.groups);
							}

							if (data.has_more && !scanStopped && data.next_cursor) {
								// Continue from the last ID we just processed, passing mode along
								setTimeout(() => scanBatch(data.next_cursor, mode), 500);
							} else {
								finishScan();
							}
						},
						error: function(xhr, status, error) {
							console.error('Scan error:', error);
							alert('❌ Server error. Check console.');
							resetUI();
						}
					});
				}

				function finishScan() {
					// ✅ MODIFIED v7.3.11: Improved UI state management on scan completion
					stopBtn.hide();
					startBtn.show().text('🔄 Scan Again');
					scanningStatus.text('✅ Scan complete!').css('color', '#28a745');

					if (allGroups.length > 0) {
						let totalDuplicates = 0;
						allGroups.forEach(g => totalDuplicates += g.questions.length);

						progressText.html(`✅ <strong>Complete!</strong> Found ${totalDuplicates} similar question(s) in ${allGroups.length} group(s)`);

						let html = `<h2 style="color: #dc3545; margin-top: 30px;">⚠️ Found ${totalDuplicates} Similar Questions</h2>`;

						allGroups.forEach(function(group, index) {
							html += `<div class="nm-similar-group" id="group-${index}" data-group-ids='${JSON.stringify(group.all_ids)}'>`;
							html += `<h3>Group ${index + 1} <span style="color: #666; font-weight: normal;">(${group.questions.length} questions, answer: "${group.answer_text}")</span></h3>`;
							html += '<ul>';
							group.questions.forEach(function(q) {
								const simPercent = q.similarity ? Math.round(parseFloat(q.similarity) * 100) : 100;
								html += `<li>
								<div class="nm-question-details">
									<div>
										<a href="${q.edit_link}" target="_blank">${q.title}</a>
										${q.similarity ? `<span class="nm-similarity-badge nm-sim-high">${simPercent}%</span>` : '<span class="nm-similarity-badge nm-sim-high">Reference</span>'}
									</div>
									<div style="margin-top: 5px; font-size: 12px; color: #666;">ID: ${q.id}</div>
									<div class="nm-correct-answer"><strong>✓ Answer:</strong> ${q.correct_answer_text}</div>
								</div>
								<button class="button nm-keep-btn" data-keep-id="${q.id}">✓ Keep This</button>
							</li>`;
							});
							html += '</ul></div>';
						});
						resultsContainer.html(html).show();
					} else {
						progressText.html('✅ <strong>Complete!</strong> No duplicates found.');
						resultsContainer.html('<div class="notice notice-success" style="padding: 20px; margin-top: 20px;"><h2>✅ Excellent!</h2><p>All MCQs are unique!</p></div>').show();
					}
				}

				function resetUI() {
					// ✅ MODIFIED v7.3.11: Complete UI state reset
					stopBtn.hide();
					startBtn.show().text('🔍 Scan Again');
					scanningStatus.text('Ready to scan...').css('color', '#135e96');
					progressBar.css('width', '0%').text('0%');
					progressText.html('Scanned 0 / 0');
					progressStats.text('');
				}

				resultsContainer.on('click', '.nm-keep-btn', function() {
					const btn = $(this);
					if (!confirm('⚠️ PERMANENT\n\nDelete all other questions in this group and create 301 redirects?\n\nCannot be undone!')) {
						return;
					}

					const groupDiv = btn.closest('.nm-similar-group');
					const keepId = btn.data('keep-id');
					const allIds = groupDiv.data('group-ids');

					groupDiv.css('opacity', '0.5');
					btn.text('⏳ Deleting...').prop('disabled', true);

					$.ajax({
						url: ajaxurl,
						type: 'POST',
						timeout: 30000,
						data: {
							action: 'nm_consolidate_duplicates', // This handler is in NM_AJAX_Manager
							_wpnonce: securityToken,
							keep_id: keepId,
							all_ids: JSON.stringify(allIds)
						},
						success: function(response) {
							if (response.success) {
								notice.find('p').html('<strong>✅</strong> ' + response.data.message);
								notice.show();
								groupDiv.slideUp(500, function() {
									$(this).remove();
									if ($('.nm-similar-group').length === 0) {
										resultsContainer.html('<div class="notice notice-success" style="padding: 20px;"><h2>✅ Done!</h2><p>All duplicates consolidated.</p></div>');
									}
								});
							} else {
								alert('❌ ' + (response.data && response.data.message ? response.data.message : 'Failed'));
								groupDiv.css('opacity', '1');
								btn.text('✓ Keep This').prop('disabled', false);
							}
						},
						error: function(xhr, status, error) {
							console.error('AJAX ERROR:', {
								status,
								error,
								response: xhr.responseText
							});
							alert('❌ Server error: ' + status + '\n\nCheck browser console (F12) for details.');
							groupDiv.css('opacity', '1');
							btn.text('✓ Keep This').prop('disabled', false);
						}
					});
				});
			});
		</script>
		<?php
	}
}
?>
