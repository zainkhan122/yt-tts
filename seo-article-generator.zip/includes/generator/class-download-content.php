<?php
namespace SEO_Article_Generator\Generator;

if (!defined('ABSPATH')) { exit; }

/**
 * Download-only content boundary shared by recovery and accepted manual edits.
 * Uses byte ranges: content outside the selected zones is never reserialized.
 * Malformed/ambiguous content is not rewritten. No HTTP, DB or AI dependencies.
 */
final class Download_Content {
    public static function inspect(string $html, string $software = ''): array {
        $ranges = array(); $block_ranges = array(); $stack = array(); $broken = false;
        preg_match_all('~<!--\s*(/?)wp:([a-z0-9_-]+(?:/[a-z0-9_-]+)?)\b(.*?)-->~is', $html, $tokens, PREG_SET_ORDER | PREG_OFFSET_CAPTURE);
        foreach ($tokens as $t) {
            $name = $t[2][0]; $start = $t[0][1]; $end = $start + strlen($t[0][0]);
            if ($t[1][0] === '/') {
                $open = array_pop($stack);
                if (!$open || $open['name'] !== $name) { $broken = true; continue; }
                $block_ranges[] = array($open['start'], $end);
                if ($open['target']) $ranges[] = array($open['start'], $end);
                continue;
            }
            $attrs = json_decode(trim(preg_replace('~/\s*$~', '', $t[3][0])), true);
            $attrs = is_array($attrs) ? $attrs : array();
            $target = ($name === 'seo-gen/section' && in_array($attrs['zone'] ?? '', array('download','download_section','downloads'), true))
                || (in_array($name, array('group','core/group'), true) && preg_match('/(?:^|\s)seo-gen-download-portal(?:\s|$)/', (string) ($attrs['className'] ?? '')));
            if (preg_match('~/\s*$~', $t[3][0])) {
                if ($target) $ranges[] = array($start, $end);
            } else $stack[] = array('name'=>$name, 'start'=>$start, 'target'=>$target);
        }
        if ($stack) $broken = true;
        if ($ranges) return self::result($html, $ranges, !$broken, 'blocks');
        if ($broken) return self::result($html, array(), false, 'malformed_blocks');

        // Legacy marked wrappers (balanced, quote-aware div/section scan).
        $stack = array(); $broken = false;
        preg_match_all('~<(/?)(div|section)\b(?:[^>"\']|"[^"]*"|\'[^\']*\')*>~is', $html, $tags, PREG_SET_ORDER | PREG_OFFSET_CAPTURE);
        foreach ($tags as $t) {
            $name = strtolower($t[2][0]); $start = $t[0][1]; $end = $start + strlen($t[0][0]);
            if ($t[1][0] === '/') {
                $open = array_pop($stack);
                if (!$open || $open['name'] !== $name) { $broken = true; continue; }
                if ($open['target']) $ranges[] = array($open['start'], $end);
            } else {
                $target = (bool) preg_match('~\b(?:data-seo-gen-zone\s*=\s*["\']download["\']|class\s*=\s*["\'][^"\']*\bseo-gen-download-portal\b[^"\']*["\'])~i', $t[0][0]);
                $stack[] = array('name'=>$name, 'start'=>$start, 'target'=>$target);
            }
        }
        if ($stack) $broken = true;
        if ($ranges) return self::result($html, $ranges, !$broken && self::whole_blocks($ranges,$block_ranges), 'legacy_wrapper');
        // Comment sentinels terminate at the next sentinel, not at arbitrary anchors.
        preg_match_all('~(?:<p[^>]*>\s*)?<!--\s*seo-gen-zone:([a-z0-9_-]+)\s*-->(?:\s*</p>)?~i', $html, $marks, PREG_SET_ORDER | PREG_OFFSET_CAPTURE);
        foreach ($marks as $i=>$m) {
            if (in_array($m[1][0], array('download','download_section','downloads'), true))
                $ranges[] = array($m[0][1], $marks[$i+1][0][1] ?? strlen($html));
        }
        if ($ranges) return self::result($html, $ranges, self::whole_blocks($ranges,$block_ranges), 'legacy_sentinel');
        // Unstructured legacy HTML: a product download heading bounds the scope.
        preg_match_all('~<h([1-6])\b[^>]*>(.*?)</h\1\s*>~is', $html, $heads, PREG_SET_ORDER | PREG_OFFSET_CAPTURE);
        foreach ($heads as $i=>$h) {
            $label = trim(html_entity_decode(strip_tags($h[2][0]), ENT_QUOTES, 'UTF-8'));
            $generic = preg_match('/^downloads?(?:\s+(?:zone|portal|links))?\s*:?[\s]*$/i', $label);
            $product = $software !== '' && preg_match('/^downloads?\s+'.preg_quote($software, '/').'\b/i', $label);
            if (!$generic && !$product) continue;
            $end = strlen($html);
            for ($j=$i+1; $j<count($heads); $j++) {
                if ((int)$heads[$j][1][0] <= (int)$h[1][0]) { $end=$heads[$j][0][1]; break; }
            }
            $ranges[] = array($h[0][1], $end);
        }
        // Heading-only scopes inside arbitrary Gutenberg blocks are safe to read but
        // not to splice; that could leave unmatched enclosing block comments.
        return self::result($html, $ranges, self::whole_blocks($ranges,$block_ranges) && !$broken, $ranges ? 'legacy_heading' : 'unscoped');
    }

    /** A byte splice may contain whole blocks, but cannot cut through their boundaries. */
    private static function whole_blocks(array $ranges, array $blocks): bool {
        foreach ($ranges as $r) foreach ($blocks as $b) {
            if (($r[0] > $b[0] && $r[0] < $b[1]) || ($r[1] > $b[0] && $r[1] < $b[1])) return false;
        }
        return true;
    }

    private static function result(string $html, array $ranges, bool $safe, string $kind): array {
        usort($ranges, static function($a,$b) { return ($a[0] <=> $b[0]) ?: ($b[1] <=> $a[1]); });
        $outer = array();
        foreach ($ranges as $r) {
            if ($outer && $r[0] < $outer[count($outer)-1][1]) {
                if ($r[1] > $outer[count($outer)-1][1]) $safe = false;
                continue;
            }
            $outer[] = $r;
        }
        $parts = array(); foreach ($outer as $r) $parts[] = substr($html, $r[0], $r[1]-$r[0]);
        return array('found'=>(bool)$outer, 'safe'=>$safe, 'kind'=>$kind, 'ranges'=>$outer, 'html'=>implode("\n", $parts));
    }

    /** Replace only recognized zones; explicit empty remains an authoritative empty block. */
    public static function replace(string $html, Article_Schema $schema): array {
        $scope = self::inspect($html, (string)$schema->tech_specs->software_name);
        if (trim($html) !== '' && (!$scope['found'] || !$scope['safe'])) {
            return array('ok'=>false, 'content'=>$html, 'reason'=>'download_zone_not_safely_identified');
        }
        $body = (new Renderers\Download_Renderer())->render($schema->download_section, '', array(), $schema->tech_specs->to_array());
        $replacement = '<!-- wp:seo-gen/section {"zone":"download"} -->'.$body.'<!-- /wp:seo-gen/section -->';
        $ranges = $scope['ranges'];
        if (!$ranges) return array('ok'=>true, 'content'=>$replacement, 'reason'=>'empty_post');
        // Duplicate recognized zones are consolidated, without touching unrelated bytes.
        for ($i=count($ranges)-1; $i>=0; $i--) {
            $r = $ranges[$i];
            $html = substr($html,0,$r[0]).($i===0 ? $replacement : '').substr($html,$r[1]);
        }
        return array('ok'=>true, 'content'=>$html, 'reason'=>$scope['kind']);
    }
}
