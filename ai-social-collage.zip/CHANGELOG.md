# Changelog

## [3.2.9] - 2026-09-04

### Fixed
- **Posts re-processed after manual job deletion** — `ajax_delete_job()` deleted only the job row from the database but left `_ai_collage_job_created` and `_ai_collage_campaign_data` post meta intact. The next `poll_campaigns()` cycle found the draft via meta query (`_ai_collage_job_created` NOT EXISTS), `has_completed_job_for_post()` returned `false` (job row was deleted), and a new job was created — re-processing the same post.
  - `core/View/Dashboard.php` — `ajax_delete_job()` now cleans post meta (`_ai_collage_job_created`, `_ai_collage_campaign_data`) and transient (`ai_collage_queued_recent_`) before deleting the job row.
  - `core/Database/JobManager.php` — `delete_job()` now cleans post meta and transient before deleting the job row.
  - `core/Database/JobManager.php` — `has_completed_job_for_post()` now verifies the WP post still exists before checking the job row. If the post is gone but job rows remain, they are auto-deleted and `false` is returned.
  - `core/Database/JobManager.php` — `job_exists_for_post()` now verifies the WP post still exists before checking job rows. Orphaned job rows for deleted posts are auto-cleaned.

### Files Modified
- `core/View/Dashboard.php` — `ajax_delete_job()` meta cleanup
- `core/Database/JobManager.php` — `delete_job()`, `has_completed_job_for_post()`, `job_exists_for_post()` post-existence guards + meta cleanup

### Fixed (cont.)
- **Posts shared multiple times to same Buffer channel** — The v3.2.9 fix attempted to dedup before the channel loop, but the closure captured an undefined `$service` variable and every dedup key was built against the empty service suffix, so it never matched any record produced by `record_share()`. The dedup is now applied AFTER the per-channel `foreach` has built `$batch_jobs`, where `is_story` is known. Each job is matched against `(channel_id, service, is_story)` where `is_story` is decoded from the `_story` suffix `record_share()` writes. A successful feed-post no longer blocks a pending story retry (and vice versa).
  - `core/Services/BufferIntegration.php` — Replaced the broken pre-loop dedup with a post-build dedup against `META_BUFFER_SHARE_HISTORY`. The `record_share()` history now drives a real `array_filter($batch_jobs)` keyed on `<channel>|<service>|<is_story:0|1>`.
  - `core/Services/BufferIntegration.php` — Dropped the misleading `?? false` on `is_video_attachment()` (return type is already `bool`).
  - `core/Services/BufferIntegration.php` — Split `PENDING_MAX_RETRY_ATTEMPTS` into two constants: `2` for transient errors and `5` for `queue_full` deferrals (Buffer's "10 scheduled" cap is rate-driven, not a fault). Threaded the new `defer_reason` argument through `defer_pending_share()` so queue-full entries get the higher budget.
  - `core/Database/JobManager.php` and `core/View/Dashboard.php` — `delete_job()` and `ajax_delete_job()` now clear `META_BUFFER_SHARE_HISTORY` and any pending entry in `OPTION_BUFFER_PENDING_SHARES` for that post. Without this SSOT update, the new dedup would silently block every channel on a re-queued job and a stale retry_count could short-circuit the new share.
  - `core/Services/BufferIntegration.php` — **F5 (silent 429 abandonment fix).** `api_request()` used to `usleep()` for the full `Retry-After` duration (Buffer returns up to 74218s = 20+ hours on 429 storms). That blocked the PHP request until the WP timeout, so the per-job result loop never ran and `defer_pending_share()` was never called — the post was silently abandoned. The inline retry sleep is now hard-capped at 30 seconds (`RETRY_SLEEP_CEILING_US`); longer delays break out of the loop and return the 429 to the caller, which routes the per-job result through the deferred path with `defer_reason: 'rate_limited'`. The deferred entry is picked up by the 5-minute `ACTION_RETRY_BUFFER_PENDING` cron. `defer_pending_share()` recognises `rate_limited` alongside `queue_full` and uses the higher `PENDING_MAX_RETRY_ATTEMPTS_QUEUE` budget (5 attempts) for both rate-driven deferrals.

## [3.2.8] - 2026-09-04

### Fixed
- **Muted videos could be left dead silent (no replacement music)** — `VideoProcessor::compose_reel()` only injected replacement music when a configured track existed; if `Config::get_replacement_music_path()` returned `''` (feature toggled off or configured file missing), the `else` branch emitted `-an`, deleting the source audio and adding nothing. Now muting ALWAYS resolves a track (falling back to the bundled `State_of_Affairs.mp3`), and if no track exists anywhere the source audio is preserved instead of producing a silent reel.
- **Speech with background music/ambience was misclassified as `music` and muted** — `detect_audio_type()` used a single 5s middle sample and a hard `speech_ratio > 0.5` cut; political speeches with hall reverb, crowd noise, or a music bed dropped below 0.5 and were destroyed + replaced with generic music. Reworked to:
  - Sample multiple windows spread across the clip (1–4 windows by duration) and decide by majority vote, so a musical intro/outro no longer flips the whole reel.
  - Add a **bass feature** (`bass_ratio`, energy <200 Hz vs full) to separate music beds from speech.
  - Return a third state **`ambiguous`** (grey-zone 0.35–0.60 or tie): treated as "preserve original audio" in `VideoRenderer` rather than muting.
  - `Config::get_replacement_music_path()` now takes an `$allow_fallback` flag and falls back to the bundled default track.

### Files Modified
- `core/Config.php` — `get_replacement_music_path()` signature + fallback-to-bundled logic
- `core/Services/VideoProcessor.php` — multi-window voting + bass feature in `detect_audio_type()`; `analyze_audio_sample()` returns `bass_rms_db`/`bass_ratio`; `compose_reel()` guarantees non-silent mute
- `core/Services/VideoRenderer.php` — `ambiguous` preserved; always resolves fallback music on mute

## [3.2.7] - 2026-09-04

### Fixed
- **Queue and Lifecycle Fixes** (audit patches 1.1 / 4.1 / 4.3 / 2.1):
  - `core/Actions/QueueProcessor.php` — **[1.1]** `do_process_job()` referenced undefined `$lock_key` inside the duplicate-guard branch (`job_skipped_post_already_completed`), throwing under the catch-all and flipping a discard into FAILED + retry. The lock key is now derived from the job ID, matching `process_job()`'s key format.
  - `core/Actions/CronScheduler.php` — **[4.1]** `run_publish_scheduler()` called non-existent `JobManager::init()`, fataling every 15-min run and permanently disabling the scheduled-video Buffer publish path. All JobManager CRUD is static; now calls `JobManager::get_jobs_ready_for_publish()` / `JobManager::update_job_fields()` statically.
  - `core/Services/QueueHealthMonitor.php` — **[4.3]** `fix_stale_running_actions()` flipped live jobs back to PENDING after only 3 minutes (video renders routinely run 3–9 min) and unconditionally deleted the job's CAS lock, inviting a second concurrent run. Stale threshold is now `max(10, ceil(4 × RENDER_WATCHDOG_TIMEOUT / 60))` minutes, and the job-status flip + lock break are gated on the job lock being genuinely stale (≥300s or absent), reusing the F13 lock-payload semantics. A live worker with a stale AS claim is left untouched and logged via `queue_stale_action_job_lock_alive`.
  - `core/Database/JobManager.php` — **[2.1]** `purge_old_jobs()` deleted COMPLETED jobs by age alone. `has_completed_job_for_post()` is the duplicate guard at every enqueue point, so purging the row first un-guarded the post and a later save re-generated it. COMPLETED jobs are now purged only when their WP post no longer exists; FAILED/DISCARDED purge on age as before.

### Files Modified
- `core/Actions/QueueProcessor.php` — fix 1.1
- `core/Actions/CronScheduler.php` — fix 4.1
- `core/Services/QueueHealthMonitor.php` — fix 4.3
- `core/Database/JobManager.php` — fix 2.1

## [3.2.6] - 2026-09-03

### Added
- **Import/Export Settings** — Full plugin configuration (API keys, brand kit, campaigns, RSS feeds, R2 credentials, Buffer multi-account, Jetpack, custom providers, retention, video settings, etc.) can now be exported as a portable `.json` file and imported on a fresh site for a 100% identical configuration. The Backup tab is added under Settings with preview diff before commit.
- `core/Services/SettingsTransfer.php` — new service class handling export/import with secret redaction, SHA-256 integrity check, forward-compatible option capture via `ai_collage_%` wildcard, and atomic transaction on import.
- `core/Config.php` — added `OPTION_LAST_EXPORT` and `OPTION_LAST_IMPORT` audit trail options.
- `core/View/Dashboard.php` — registered `wp_ajax_ai_collage_export_settings` / `wp_ajax_ai_collage_import_settings`; added `ajax_export_settings()` / `ajax_import_settings()` handlers; added "Backup" sub-tab in Settings page with activity log.
- `assets/js/admin-dashboard.js` — added client-side preview/commit handlers for import with diff table and export form submission.

### Security
- Export secrets redaction (opt-in checkbox) masks all API keys / tokens / secrets in the downloaded file.
- Import enforces `manage_options` capability, nonce verification, 5 MB size cap, SHA-256 hash verification, schema version refusal (prevents future-schema imports), and dry-run preview by default (user must explicitly confirm overwrite).
- No temporary files written to disk; export streamed directly to browser; import processes upload in-memory.

### Files Modified
- `core/Config.php` — added `OPTION_LAST_EXPORT`, `OPTION_LAST_IMPORT` constants
- `core/Services/SettingsTransfer.php` — new file
- `core/View/Dashboard.php` — AJAX hooks, handlers, Settings tab UI
- `assets/js/admin-dashboard.js` — Backup tab JS handlers

## [3.2.5] - 2026-09-02

### Added
- **Per-campaign source video logo removal with user-specified region and brand logo overlay at same location** — When a campaign has `video_logo_removal_enabled` set AND the user provides the exact logo rectangle as 4 percentages (X, Y, Width, Height of source video), the video pipeline runs a single-pass FFmpeg `removelogo` pass over the source video using a mask matching that exact region. The brand logo placed later by `compose_reel()` is then scaled and positioned at the same X/Y/W/H region (mapped from source-video percentages to fitted-canvas pixels, accounting for letterbox padding), so it covers the inpainted area exactly. If the user does not provide all 4 coordinates, removal is skipped, a warning is logged, and the original video passes through with the brand logo placed via the existing brand-setting position logic. Manual zones (`video_content_zone`) remain authoritative for content cropping and are unaffected. **Normal video pipeline (toggle OFF or no campaign zone set) is completely unchanged** — the existing brand-setting-driven top-corner logo placement is preserved.

### Removed
- **Dead video-logo-removal constants** — `OPTION_VIDEO_LOGO_REMOVAL_ENABLED`, `OPTION_VIDEO_SOURCE_LOGO_POSITION`, `OPTION_VIDEO_LOGO_REMOVAL_MASK_W`, `OPTION_VIDEO_LOGO_REMOVAL_MASK_H`, `DEFAULT_VIDEO_SOURCE_LOGO_POSITION`, `DEFAULT_VIDEO_LOGO_REMOVAL_MASK_W`, `DEFAULT_VIDEO_LOGO_REMOVAL_MASK_H` from `Config.php` were declared but never read. Source-logo-removal config flows entirely through the campaign array (per-campaign), not via global WordPress options.
- **Source Logo Position dropdown** — was a UI convenience for top-left/top-right but the X/Y/W/H coordinates fully describe any position; dropdown added no value and was confusing.

### Files Modified
- `core/Config.php` — removed 7 dead video-logo-removal constants
- `core/Services/VideoProcessor.php` — `remove_logo_with_removelogo()` requires all 4 coordinates and hard-fails if any is missing; `compose_reel()` accepts a new `array $logo_zone = []` parameter; when a valid zone is provided, the top-corner brand logo is scaled to `zone.w * fitted_w` × `zone.h * fitted_h` and placed at `(W-fitted_w)/2 + zone.x * fitted_w`, `video_content_top + zone.y * fitted_h` (exact match of the source-logo region); otherwise the existing top-left/top-right padding-based placement is used unchanged
- `core/Services/VideoRenderer.php` — removed read of `video_source_logo_position`; reads `video_logo_zone` from campaign data and passes it to `compose_reel()`
- `core/View/Dashboard.php` — added 4 number inputs (X, Y, W, H) in the campaign card; removed the Source Logo Position dropdown; save handler stores `video_logo_zone` as `null` when the form fields are empty
- `assets/js/admin-dashboard.js` — updated JS-built card template to match PHP render (4 inputs, no dropdown); save handlers return `null` for `video_logo_zone` if any field is empty/zero/non-numeric

## [3.2.4] - 2026-09-02

### Added
- **Replacement music injection for muted videos** — When `detect_audio_type()` classifies source audio as music and mutes it, the system now overlays a configurable replacement music track from `assets/music/` instead of producing silent output. Uses FFmpeg `aloop`+`atrim` to loop-track to video duration at 70% volume. Configurable via `ai_collage_replacement_music_enabled` (default: true) and `ai_collage_replacement_music_file` (default: `State_of_Affairs.mp3`) options. Falls back to `-an` (silent) if replacement file is missing or feature disabled.

### Files Modified
- `core/Config.php` — added `OPTION_REPLACEMENT_MUSIC_ENABLED`, `OPTION_REPLACEMENT_MUSIC_FILE`, `DEFAULT_REPLACEMENT_MUSIC_FILE` constants and `get_replacement_music_path()` helper
- `core/Services/VideoProcessor.php` — extended `compose_reel()` with `$replacement_music_path` parameter; added FFmpeg filter chain for looping replacement music when muting
- `core/Services/VideoRenderer.php` — passes `Config::get_replacement_music_path()` to `compose_reel()`
- `core/View/Dashboard.php` — added Replacement Music toggle + filename input + file status indicator in Settings > Advanced tab; saves both options via existing `save_advanced_settings` handler

## [3.2.3] - 2026-09-01

### Fixed
- **Generated posts incorrectly deleted by daily cleanup** — Cleanup used `post_date_gmt` (original source post ingestion date) instead of AI generation date. Source posts ingested days ago but AI-processed today were treated as "older than retention" and deleted. Added `_ai_collage_generated_at` meta set when AI meta is written, and updated cleanup to query this meta field with DATETIME comparison.

### Files Modified
- `core/Config.php` — added `META_GENERATED_AT` constant
- `core/Actions/QueueProcessor.php` — set `_ai_collage_generated_at` when AI meta is persisted
- `core/Services/CleanupManager.php` — changed `clean_generated_posts()` to filter by `META_GENERATED_AT` meta instead of `post_date_gmt`

## [3.2.2] - 2026-08-29

### Fixed
- **Duplicate post processing via rescue loops** — Added `has_completed_job_for_post()` check across 4 entry points (`JobManager`, `QueueProcessor::do_process_job()`, `PostObserver::detect_new_post()`, `CronScheduler::queue_oldest_draft()`) to prevent the same `post_id` from being re-processed when a prior job already reached `COMPLETED` status. This resolves the `direct_processing_*` cycle (Job 3470) and `queue_orphaned_db_jobs_reenqueued {count: 20, 18}` events where stuck posts were repeatedly rescued and re-enqueued without dedup. Three surgical edits only — no new tables, columns, or migrations.

### Files Modified
- `core/Database/JobManager.php` — added `has_completed_job_for_post()` method
- `core/Actions/QueueProcessor.php` — added post-level completion guard in `do_process_job()`
- `core/Actions/PostObserver.php` — added post-level completion guard in `detect_new_post()`
- `core/Actions/CronScheduler.php` — added post-level completion guard in `queue_oldest_draft()`

## [3.2.1] - 2026-08-28

### Fixed
- **YouTube description now renders each section on its own line** — the `yt_description` prompt (English + Urdu, all categories) was changed from "Then add CTA... Then hashtags" (space-joined, single-line) to an explicit instruction that the description, CTA, link and hashtags must each be placed on a separate line using the real newline character `\n`. This fixes the reported issue where the whole YouTube description appeared on one line in the Buffer-published post.
- **Defensive YouTube description line-break normalizer** — `BufferIntegration::format_yt_description()` was added and applied to both the `{yt_description}` placeholder (`$yt_description`) and the YouTube channel `{description}` override (`$channel_desc`). It guarantees the channel link (`https://...`) and the trailing `#hashtags` block are isolated on their own lines (blank-line separated) even if the AI model omits newlines, independent of `normalize_text()`/`graphql_escape()` which already preserve real newlines in the GraphQL payload.

### Files Modified
- `core/Services/ContentRewriter.php` — all `yt_description` prompt lines (en/ur) now mandate per-section newlines.
- `core/Services/BufferIntegration.php` — added `format_yt_description()`; wired into `$yt_description` build and YouTube `$channel_desc` override in `share_to_account()`.

## [3.2.0] - 2026-08-27

### Added
- **AI-generated YouTube Shorts title + description** — `yt_title` (≤70 chars, keyword front-loaded) and `yt_description` (primary keyword in first 100 chars + CTA + channel link) are now explicit fields returned by every AI rewrite result, stored as `_ai_collage_auto_meta[ai_yt_title]` / `[ai_yt_description]`, and consumed by `BufferIntegration` for the YouTube title GraphQL field and caption path respectively. Fallback chain: `ai_yt_title` → `ai_headline` → `post_title` for title; `ai_yt_description` → `ai_detailed_description` for caption.
- **`#Shorts` always prepended to YouTube hashtag block** — `BufferIntegration::share_to_account()` injects `#Shorts` as the leading hashtag when building the YouTube caption, guaranteeing Shorts shelf eligibility regardless of what the AI returns in `ai_hashtags`.

### Changed
- `ContentRewriter` prompt templates (English + Urdu) — added `yt_title` and `yt_description` fields to the JSON schema returned by the LLM for all categories (entertainment, tech, celebrity, controversy, emotional, inspirational, breaking, film, news, modern, impact, sports, politics).

### Files Modified
- `core/Services/ContentRewriter.php` — added `yt_title`/`yt_description` to `validate_rewrite_json()`, `normalize_ai_response_fields()` field_map, and all category prompt JSON schemas.
- `core/Actions/QueueProcessor.php` — added `ai_yt_title`/`ai_yt_description` to the `$ai_meta` array persisted to `_ai_collage_auto_meta`.
- `core/Services/BufferIntegration.php` — `build_metadata()` YouTube title priority: `ai_yt_title` first; channel-desc override: `ai_yt_description` for YouTube caption; `#Shorts` prepend applied to `ai_hashtags` block for YouTube channels.
- `core/Actions/QueueProcessor.php` — Gutenberg post-content blocks for both image and video pipelines now include `ai_yt_title` and `ai_yt_description` as labelled paragraph blocks (visible in WP editor, same pattern as existing `x_content` block), alongside the existing headline/description/hashtags/x_content/mentions blocks.

## [3.1.8] - 2026-08-26

### Fixed
- **Audio type classification relied on a single 5-second sample** — `detect_audio_type()` decided `voice` vs `music` from one window at 50% of the video, so reels with intro music before speech (or vocal music) could flip either way depending on where the sample landed. Log evidence 2026-08-25: all 4 music detections sat at `speech_ratio` 0.43–0.47, immediately against the 0.5 threshold.

### Added
- **Gray-zone re-sample in `VideoProcessor::detect_audio_type()`** — when `speech_ratio` lands in 0.40–0.60, a second sample is taken from a different position (25% of duration for normal videos, 50% for short clips with the first sample at 0), gated on `$offset + $sample_duration <= $duration` and a ≥1 s separation from the first window; both windows' `full_rms_db`/`speech_ratio` are averaged before classification. If no valid second position exists (very short clips), the single-sample decision stands.
- Re-sampled decisions log extra fields on `video_audio_type_detected`: `resampled: true` and the second window's `speech_ratio_2`.

### Files Modified
- `core/Services/VideoProcessor.php` — gray-zone re-sample + averaged classification inside `detect_audio_type()`; docblock updated.

## [3.1.7] - 2026-08-24

### Fixed
- **Duplicate `pending` rows accumulated forever in the jobs table** — `Migration::create_tables()` has defined `UNIQUE KEY post_id_status (post_id, status)` since 2.0, but `dbDelta` silently skipped adding it on populated tables (the `@` operator suppresses the failure). Production databases ended up with no unique constraint at all. Evidence 2026-08-24: post 29241 had rows `107984 + 3345` both in `pending` (same for 29247 / `108004 + 3346`, 29255 / `108025 + 3347`, 29259 / `108040 + 3348`). Side effect: `PostObserver`'s `INSERT ... ON DUPLICATE KEY UPDATE` was effectively a plain insert — every new RSS/draft import produced a duplicate pending row that the monitor never re-enqueued (it picks the lowest id first), so the new row sat as a permanent zombie.

### Added
- `Migration::upgrade_to_3_8()` — runs automatically on the next plugin load. Idempotent: returns immediately if `post_id_status` already exists. Otherwise dedupes (keeps lowest id per `(post_id, status)` pair) and adds the UNIQUE KEY via direct `ALTER TABLE` (bypassing the unreliable `@dbDelta` path). Emits `error_log` lines for the dedup count and the key-add outcome so admins can verify the upgrade ran.

### Files Modified
- `core/Database/Migration.php` — bumped `SCHEMA_VERSION` to `3.8`; added `upgrade_to_3_8()` and a version-3.8 block in `maybe_upgrade()`.

## [3.1.6] - 2026-08-24

### Fixed
- **Stuck `pending` jobs were never recovered or cleaned** — `JobManager::mark_stuck_jobs_failed()` only transitioned `rewriting`/`rendering` jobs to `failed`. A job stuck in `pending` (lost Action Scheduler action, silently failed enqueue) sat in the queue forever, and retention never removed it because `CleanupManager::clean_jobs()` only deleted `completed`/`failed`/`discarded` rows. `scheduled` jobs whose one-shot prime-time action was lost were likewise never deleted.

### Added
- `JobManager::purge_stuck_jobs()` — deletes `pending`/`scheduled` jobs whose `updated_at` is older than the job-retention window (defense-in-depth for jobs orphaned beyond the stuck-detection timeout). `ready_for_review` is excluded; `rewriting`/`rendering` are excluded (handled within minutes by `mark_stuck_jobs_failed()`).
- Pending-orphan recovery in `JobManager::mark_stuck_jobs_failed()` — a `pending` job older than the stuck timeout is now failed **only when it no longer owns a live (`pending`/`in-progress`) Action Scheduler action**. Pause-safe: `QueueProcessor::process_job()` defers pending jobs every 60s while the pipeline is paused, so paused jobs always own a live action and are never falsely failed (protects the `ajax_resume_pipeline()` re-enqueue flow). If a ghost action fires after the job was failed, `do_process_job()` safely no-ops on `STATUS_FAILED` (`job_already_failed_skip`).
- **Opt-in uninstall data wipe** — new `uninstall.php` removes everything the plugin generates: custom tables (`ai_collage_jobs`, `ai_collage_logs`, `ai_collage_api_calls`), generated attachments (`_is_ai_social_collage`), plugin-created posts (`_ai_collage_auto_meta`, `_ai_collage_rss_source_url`), all `_ai_collage_*` postmeta, all `ai_collage_*` options/transients (incl. health-check token), the plugin's Action Scheduler entries/orphaned claims, and its WP-Cron events. **Disabled by default** — runs only when "Delete Data on Uninstall" is checked in Settings → Retention. Plugin updates never trigger it; only plugin deletion does. Multisite-aware. Remote R2/Cloudinary objects are intentionally not touched (no external API calls during uninstall).

### Changes
- `CleanupManager::clean_jobs()` — no longer duplicates purge SQL. Delegates to `JobManager::purge_discarded_jobs()`, `purge_stuck_jobs()` and `purge_old_jobs()`, making `JobManager` the single CRUD authority for the jobs table (previously `purge_old_jobs()`/`purge_discarded_jobs()` were dead code).

### Files Modified
- `core/Database/JobManager.php` — pending-orphan recovery in `mark_stuck_jobs_failed()`; added `purge_stuck_jobs()`
- `core/Services/CleanupManager.php` — `clean_jobs()` delegates to JobManager purge methods
- `core/Config.php` — added `OPTION_DELETE_DATA_ON_UNINSTALL`, `DEFAULT_DELETE_DATA_ON_UNINSTALL`
- `core/View/Dashboard.php` — "Delete Data on Uninstall" checkbox in Settings → Retention + save handler
- `uninstall.php` — new: opt-in full data wipe on plugin deletion

## [3.1.5] - 2026-08-18

### Fixed
- **Urdu video heading text clipped on right side despite sufficient space** — Pango RTL rendering anchors text at the right edge of the canvas, causing the right bearing of Urdu Nastaliq characters to extend beyond the canvas boundary and be clipped during rasterization. A malformed `-border %dx%dx%d%d` geometry string meant post-trim padding was never applied correctly, compounding the issue. Additionally, `wrap_text_for_pango` used GD FreeType metrics for line-wrapping which underestimated HarfBuzz-shaped output width by 10-30%, causing lines to overflow `$max_width` after Pango rendering.

### Changes
- `VideoProcessor::render_text_to_png()` — Removed ineffective `×2.0` canvas multiplier (Pango always anchors RTL at right edge regardless of canvas width). Replaced malformed `-border` geometry with correct `-splice` commands for precise per-side padding. Added asymmetric right-side padding (5× left) to compensate for RTL right-bearing clipping. Added RTL right-margin spaces in Pango markup (3 spaces per line) to push text leftward so the right bearing falls within the canvas during rasterization — the core fix for right-side clipping.
- `VideoProcessor::wrap_text_for_pango()` — Added HarfBuzz safety margin: wraps Urdu text at 85% of `$max_width` instead of 100% to account for OpenType GSUB/GPOS shaping producing wider output than FreeType metrics.
- `VideoRenderer::fit_heading_to_area()` — Fixed width validation to compare against `$canvas_w` (not `$max_width`) when `$bg_color` is set, preventing unnecessary font-size reduction in the bg-composite path.

### Files Modified
- `core/Services/VideoProcessor.php` — Fixed `-splice` padding, removed `×2.0` multiplier, added HarfBuzz safety margin in `wrap_text_for_pango()`
- `core/Services/VideoRenderer.php` — Fixed width validation in `fit_heading_to_area()`

## [3.1.4] - 2026-08-18

### Fixed
- **Video poster/cover shows black screen instead of video content** — Social media platforms (WhatsApp, Instagram, Facebook) extract the first frame of the MP4 as the video cover. The composed video's first frame was a black canvas (from `color=c=black` in the FFmpeg filter chain) with heading/branding overlaid, causing the cover to appear as a black screen. The actual video content was only visible after pressing play.

### Added
- `VideoProcessor::prepend_poster_frame()` — After composing the video reel, extracts a representative frame at 25% of duration, creates a 0.5s clip from that frame using the FFmpeg `loop` filter, and concatenates it before the full video. This ensures the first frame of the output MP4 always shows actual video content. Gracefully falls back (leaves video unchanged) for videos shorter than 1 second or if FFmpeg post-processing fails.

### Files Modified
- `core/Services/VideoProcessor.php` — Added `prepend_poster_frame()` method; added call site in `compose_reel()` after successful composition
- `core/Services/CleanupManager.php` — Added `poster_clip_*.mp4` and `poster_final_*.mp4` to temp cleanup patterns

## [3.1.3] - 2026-08-17

### Added
- **User-editable post content routable to Buffer** — All placeholder fields (headline, hook, description, X-content, tags, mentions) are now editable in the Gutenberg editor and user changes are synced back to `META_AUTO_META` so Buffer shares the user-approved content.
- `BufferIntegration::parse_post_content_for_buffer()` — Parses Gutenberg blocks or classic editor content into structured fields for Buffer templates.
- `PostObserver::sync_user_edits_to_meta()` — `save_post` hook (priority 20) that extracts user edits from `post_content`/`post_title` and updates `META_AUTO_META`.
- Gutenberg block output in `QueueProcessor::step_render()` and `step_render_video()` — Posts now use native blocks (`<!-- wp:heading -->`, `<!-- wp:paragraph -->`, `<!-- wp:image -->`, `<!-- wp:video -->`) for mobile-friendly editing.

### Removed
- `the_content` filter in `ai-social-collage.php` — Removed placeholder replacement (`[heading]`, `[hook]`, etc.) that conflicted with Gutenberg blocks and broke mobile editing.

### Files Modified
- `core/Services/BufferIntegration.php` — Added `parse_post_content_for_buffer()`
- `core/Actions/QueueProcessor.php` — Gutenberg block output in `step_render()` and `step_render_video()`
- `core/Actions/PostObserver.php` — Added `sync_user_edits_to_meta()` hook
- `ai-social-collage.php` — Removed `the_content` filter

## [1.0.1] - 2026-08-16

### Fixed
- **TypeError in JobManager::sanitize_utf8_text()** - Method now accepts nullable string (`?string`) and handles null input gracefully. Added null coalescing in `update_job_data()` for `$headline` and `$hook` parameters.
- **JSON validation error "missing headline or hook in response"** - Added field normalization to handle AI model response variations (Gemini 2.5 Flash returns `title`/`post` instead of `headline`/`detailed_description`)

### Added
- `normalize_ai_response_fields()` static method in ContentRewriter.php - Maps common AI response field variations to canonical names:
  - `title`, `ai_headline`, `head_line`, `heading` → `headline`
  - `post`, `ai_detailed_description`, `description`, `body`, `content`, `article` → `detailed_description`
  - `ai_hook`, `lead`, `summary`, `intro`, `excerpt` → `hook`
  - `category`, `section`, `topic` → `eyebrow`
  - `emphasis`, `keyword`, `focus_word` → `emphasis_word`
  - `keywords`, `tags`, `entities` → `key_terms`
- Automatic hook derivation from `detailed_description` when hook is missing
- Retry logic with prompt correction in both `rewrite()` and `rewrite_with_fallback()` methods for:
  - JSON validation failures
  - Language/script detection issues (Roman Urdu, Latin chars in Urdu, etc.)
  - Inappropriate Urdu word detection
  - Non-Urdu script / corrupted Unicode detection

### Changed
- Both `rewrite()` and `rewrite_with_fallback()` now call field normalization BEFORE validation
- Both methods now retry up to 3 times with corrected prompts on validation/quality failures
- `JobManager::sanitize_utf8_text()` type hint changed from `string` to `?string` with null handling
- `JobManager::update_job_data()` now explicitly coalesces null headline/hook to empty strings

### Files Modified
- `core/Services/ContentRewriter.php`
- `core/Database/JobManager.php`