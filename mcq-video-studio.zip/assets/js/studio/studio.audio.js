/**
 * MCQ Video Studio - Audio Module
 * 
 * Handles audio library, SFX, background music, and ducking.
 * Split from studio.controller.js for maintainability.
 * 
 * @requires MCQVSLogger (studio.logger.js)
 * @requires MCQVS_AudioManager (assets/js/mcqvs-audio-manager.js)
 * 
 * @version 8.7.1
 * @since 2026-02-01
 */

(function (window) {
    'use strict';

    const _getLogger = () => (typeof window !== 'undefined' ? window.MCQVSLogger : null) || null;

    class AudioController {
        constructor(state, config) {
            this.state = state;
            this.config = config;
            this.audioManager = window.MCQVS_AudioManager;

            // Custom audio tracks
            this.customSFX = {
                tick: null,
                correct: null,
                wrong: null
            };

            this.customMusic = null;
            this.previewAudio = null;
            // Deterministic preview transport (PlanBuilder + AudioRouter)
            this._audioRouter = null;
            this._renderPlan = null;
            this._planDirty = true;
            this._lastTickMs = 0;
            this._transportPlaying = false;

            // Track SFX clones + delayed timers
            this._activeSfxClones = [];
            this._pendingSfxTimers = [];

            // ============================================================
            // Voiceover Preview Transport (TTS in Preview)
            // ============================================================
            this._vo = {
                events: [],
                nextIdx: 0,
                cache: new Map(),
                inFlight: new Map(),
                activeAudio: null,
                isSpeaking: false
            };

            if (_getLogger()) {
                _getLogger().info('AUDIO_INIT', {
                    audioEnabled: state.audioEnabled,
                    sfxEnabled: state.sfxEnabled
                });
            }
        }

        /**
         * Initialize audio suite
         */
        initialize() {
            this.fixLocalPaths();
            this.renderSoundLibraries();
            this.bindEventHandlers();

            if (_getLogger()) {
                _getLogger().info('AUDIO_SUITE_READY');
            }
        }
        // ============================================================
        // Deterministic Preview Audio (NLE-like transport)
        // ============================================================

        _getBasePath() {
            // @MODIFIED 2026-02-14: Robust absolute path resolution for WP Admin
            const base = (this.config && this.config.audio && this.config.audio.basePath)
                || (this.config && this.config.assetsUrl)
                || (window.MCQVSConfig && window.MCQVSConfig.assetsUrl)
                || './assets/';
            return base.replace(/\/+$/, '') + '/';
        }

        getSfxUrl(name) {
            const n = String(name || '').trim();
            if (!n) return null;

            if (this.customSFX && this.customSFX[n] && this.customSFX[n].src) return this.customSFX[n].src;

            const lib = window.MCQVS_AudioLibrary;
            if (lib && lib.sfx && Array.isArray(lib.sfx[n]) && lib.sfx[n][0] && lib.sfx[n][0].url) return lib.sfx[n][0].url;

            // @MODIFIED 2026-02-14: Use absolute path from _getBasePath
            return this._getBasePath() + 'audio/sfx/' + n + '.mp3';
        }

        getMusicUrl() {
            const u = String(this.state?.bgMusicUrl || '').trim();
            // @MODIFIED 2026-02-06: Prevent loading 'undefined' or null string
            if (!u || u === 'undefined' || u === 'null') return null;

            // @DEBUG 2026-02-07: Verify URL
            // if (Logger) Logger.debug('AUDIO_GET_MUSIC_URL', { url: u });

            return u;
        }

        _buildRenderPlan() {
            if (!window.MCQVS_PlanBuilder || typeof window.MCQVS_PlanBuilder.buildFromState !== 'function') return null;

            const templateId = this.state.templateId || this.state.currentTemplate || 'trivia';
            const fps = Number(this.state.fps || 30);
  const width = Number(this.state.width || (window.StudioController?.RESOLUTION?.width) || 1080);
  const height = Number(this.state.height || (window.StudioController?.RESOLUTION?.height) || 1920);

            const sfxMap = {
                tick: this.getSfxUrl('tick'),
                correct: this.getSfxUrl('correct'),
                wrong: this.getSfxUrl('wrong'),
                reveal: this.getSfxUrl('reveal'),
                transition: this.getSfxUrl('transition'),
                whoosh: this.getSfxUrl('whoosh'),
                success: this.getSfxUrl('success')
            };

            const assetConfig = {
                musicUrl: this.getMusicUrl(),
                sfx: sfxMap
            };

            return window.MCQVS_PlanBuilder.buildFromState(this.state, {
                fps, width, height, templateId, sfxMap, assetConfig
            });
        }

        async _ensureRouter() {
            if (this._audioRouter) return this._audioRouter;
            if (!window.MCQVS_AudioRouter) return null;

            this._audioRouter = new window.MCQVS_AudioRouter({
                deterministic: true,
                lookaheadMs: 180,
                minLatencyMs: 15,
                gainRampMs: 40,
                getPlan: () => this._renderPlan,
                getFlags: () => ({
                    audioEnabled: !!this.state.audioEnabled,
                    sfxEnabled: !!this.state.sfxEnabled,
                    musicEnabled: !!this.state.musicEnabled,
                }),
                getSfxUrl: (name) => this.getSfxUrl(name),
                getMusicUrl: () => this.getMusicUrl(),
                playSfx: (name, opts) => this.playSFX(name, opts),
            });

            return this._audioRouter;
        }

        async rebuildPlan() {
            // @NEW 2026-06-29: Single source of truth. The StudioController owns
            // state.renderPlan and validates it (assertValid + timeline.configure).
            // Use that exact plan here so audio + video cannot drift. Fall back to a
            // local build only if the controller has not produced one yet (boot path).
            //
            // Honor _planDirty so callers that flip state without expecting a rebuild
            // (e.g. UI sync cosmetic updates) skip the redundant fetch+prime round-trip.
            // Any operation that mutates render-relevant state must call invalidatePlan()
            // to force a rebuild on the next playFrom/tick cycle.
            const authoritative = this.state && this.state.renderPlan;
            const haveAuthoritative = !!(authoritative && typeof authoritative === 'object');

            if (haveAuthoritative && !this._planDirty) {
                // Fresh state.renderPlan, no invalidation flag â€” reroute without rebuilding.
                this._renderPlan = authoritative;
            } else {
                this._renderPlan = haveAuthoritative ? authoritative : this._buildRenderPlan();
                if (this._renderPlan) this.state.renderPlan = this._renderPlan;
                this._planDirty = false;
            }

            const r = await this._ensureRouter();
            if (r) { try { await r.prime(); } catch (_) { } }
        }

        async playFrom(timelineMs = 0) {
            this.syncFromUI();
            // Voiceover is an independent transport â€” don't bail when master audio is off.
            if (!this.state.audioEnabled && !this._voiceoverEnabled()) return;

            await this.rebuildPlan();
            const r = await this._ensureRouter();
            if (!r) return;

            this._lastTickMs = Math.max(0, Number(timelineMs) || 0);

            // Mark transport playing (used for deterministic music loop + voiceover)
            this._transportPlaying = true;

            // Build voiceover schedule from current plan (also when master audio is off,
            // otherwise preview TTS would never fire â€” only export would hear it).
            try {
                if (this._renderPlan) {
                    this._vo.events = this._buildVoiceoverEvents(this._renderPlan);
                    this._resetVoiceoverCursor(this._lastTickMs);
                    this._prefetchVoiceover(this._lastTickMs);
                }
            } catch (_) { }

            // Router also reads audioEnabled â€” pause the audio side without breaking the VO transport.
            const _needsRouter = this.state.audioEnabled;
            if (r && _needsRouter) await r.play(this._lastTickMs);
        }

        pauseAt(timelineMs = 0) {
            const t = Math.max(0, Number(timelineMs) || 0);
            this._lastTickMs = t;

            // Deterministic: pause router + hard-stop all currently playing HTMLAudio clones
            if (this._audioRouter) {
                try { this._audioRouter.pause(t); } catch (_) { }
            }
            this._transportPlaying = false;
            this._stopVoiceover();
            this.stopAll();
        }

        stopAll() {
            this._lastTickMs = 0;
            if (this._audioRouter) { try { this._audioRouter.stop(); } catch (_) { } }
            this.stop(); // existing legacy stop (customMusic/audioManager)

            // @MODIFIED 2026-02-23: Robust deterministic cleanup
            this._transportPlaying = false;
        }

        /**
         * Hard stop all music and SFX
         * @MODIFIED 2026-02-14: Added missing stop() method to fix TypeError
         * @MODIFIED 2026-02-23: Added explicit halt for clones and pending timers
         */
        stop() {
            if (this.customMusic) {
                try {
                    this.customMusic.pause();
                    this.customMusic.currentTime = 0;
                } catch (_) { }
            }

            // Stop active clones managed by this controller
            if (Array.isArray(this._activeSfxClones)) {
                this._activeSfxClones.forEach(clone => {
                    try { clone.pause(); clone.currentTime = 0; } catch (_) { }
                });
                this._activeSfxClones = [];
            }

            // Clear pending timers
            if (Array.isArray(this._pendingSfxTimers)) {
                this._pendingSfxTimers.forEach(id => clearTimeout(id));
                this._pendingSfxTimers = [];
            }

            if (this.audioManager && typeof this.audioManager.stopAll === 'function') {
                try { this.audioManager.stopAll(); } catch (_) { }
            }
        }

        async seekTo(timelineMs = 0) {
            const t = Math.max(0, Number(timelineMs) || 0);
            this._lastTickMs = t;
            const r = await this._ensureRouter();
            if (r) await r.seek(t);

            this._stopVoiceover();
            try { this._resetVoiceoverCursor(t); } catch (_) { }
        }

        async tick(timelineMs = 0, isManual = false) {
            const t = Math.max(0, Number(timelineMs) || 0);
            const prev = this._lastTickMs;
            this._lastTickMs = t;

            const r = await this._ensureRouter();
            if (!r) return;
            await r.tick(t, prev, !!isManual);

            try { this._tickVoiceover(t, prev, !!isManual); } catch (_) { }
        }

        // ============================================================
        // Voiceover Preview Helpers (TTS in Preview)
        // ============================================================

        _ajaxPost(action, payload = {}) {
            const url =
                (this.config && (this.config.ajaxurl || this.config.ajaxUrl)) ||
                (window.MCQVS_Config && (window.MCQVS_Config.ajaxurl || window.MCQVS_Config.ajaxUrl)) ||
                (window.MCQVSConfig && (window.MCQVSConfig.ajaxurl || window.MCQVSConfig.ajaxUrl)) ||
                window.ajaxurl || '';

            const nonce =
                (this.config && this.config.nonce) ||
                (window.MCQVS_Config && window.MCQVS_Config.nonce) ||
                (window.MCQVSConfig && window.MCQVSConfig.nonce) ||
                '';

            if (!url) return Promise.reject(new Error('Missing AJAX URL'));

            const body = new URLSearchParams();
            body.set('action', action);
            if (nonce) body.set('nonce', nonce);

            Object.entries(payload || {}).forEach(([k, v]) => {
                if (v === undefined || v === null) return;
                body.set(k, String(v));
            });

            return fetch(url, {
                method: 'POST',
                credentials: 'same-origin',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                body: body.toString()
            }).then(async (res) => {
                const json = await res.json().catch(() => null);
                if (!json) throw new Error('Invalid server response');
                return json;
            });
        }

        _stopVoiceover() {
            try {
                if (this._vo) this._vo.isSpeaking = false;
                // @FIX 2026-07-24: Clear the overlap guard so next TTS can fire.
                if (this._vo) this._vo.activeUntilMs = 0;
                // @MODIFIED 2026-02-26: Comprehensive narration stop (Audio + WebSpeech)
                // Stop any HTMLAudioElement-based narration
                if (this._vo && this._vo.activeAudio) {
                    try { this._vo.activeAudio.pause(); } catch (_) { }
                    try { this._vo.activeAudio.currentTime = 0; } catch (_) { }
                    this._vo.activeAudio = null;
                }

                // Stop any WebSpeech narration (or TTSManager playback)
                try {
                    const tts = window.MCQVS_TTSManager;
                    if (tts && typeof tts.stop === 'function') tts.stop();
                } catch (_) { }

                try {
                    if (window.speechSynthesis && typeof window.speechSynthesis.cancel === 'function') {
                        window.speechSynthesis.cancel();
                    }
                } catch (_) { }
            } catch (_) { }
        }

        _resetVoiceoverCursor(timelineMs) {
            const t = Math.max(0, Number(timelineMs) || 0);
            const ev = Array.isArray(this._vo && this._vo.events) ? this._vo.events : [];
            let i = 0;
            while (i < ev.length && Number(ev[i].timeMs || 0) < t) i++;
            this._vo.nextIdx = i;
        }

        _prefetchVoiceover() {
            const vo = this.state && this.state.voiceover ? this.state.voiceover : null;
            if (!vo || !vo.enabled) return;

            const ev = Array.isArray(this._vo && this._vo.events) ? this._vo.events : [];
            const i = Math.max(0, this._vo.nextIdx || 0);
            for (let k = i; k < Math.min(ev.length, i + 2); k++) {
                const e = ev[k];
                if (e && e.text) this._ensureVoiceoverAudioUrl(e.text).catch(() => { });
            }
        }

        /**
         * @FIX 1.4.9.58 (TTS PREVIEW LAG): pre-generate EVERY voiceover segment before
         * playback starts. Previously only the next 2 segments were prefetched, so the
         * timeline reached question 2/3 while its TTS was still being generated server-
         * side (Edge TTS AJAX per segment) — the video ran ahead of the narration. Now
         * the play button shows "TTS being generated…" until all segments are cached,
         * then playback starts and the narration follows the timeline exactly (the
         * existing no-overlap guard + cache make each segment play at its cue time).
         *
         * @returns {Promise<number>} count of segments prepared (0 if voiceover off /
         *                            webspeech — browser TTS needs no pre-generation).
         */
        async prewarmAllVoiceover() {
            const vo = this.state && this.state.voiceover ? this.state.voiceover : null;
            if (!vo || !vo.enabled) return 0;
            const provider = String(vo.provider || 'edge').trim().toLowerCase();
            if (provider === 'webspeech') return 0; // browser TTS — nothing to prefetch

            if (this._renderPlan) {
                try {
                    this._vo.events = this._buildVoiceoverEvents(this._renderPlan);
                    this._resetVoiceoverCursor(0);
                } catch (_) { }
            }
            const ev = Array.isArray(this._vo && this._vo.events) ? this._vo.events : [];
            const tasks = ev
                .filter((e) => e && e.text && String(e.text).trim())
                .map((e) => this._ensureVoiceoverAudioUrl(e.text));
            const results = await Promise.allSettled(tasks);
            return results.filter((r) => r.status === 'fulfilled').length;
        }

        _tickVoiceover(t, prev, isManual) {
            if (isManual) return;
            if (!this._transportPlaying) return;

            const vo = this.state && this.state.voiceover ? this.state.voiceover : null;
            if (!vo || !vo.enabled) return;
            // @NEW 2026-06-29: Voiceover is an independent audio source.
            // It should keep playing even when master audio (music + SFX) is off.
            if (!this.state.audioEnabled && !this._voiceoverEnabled()) return;

            const ev = Array.isArray(this._vo && this._vo.events) ? this._vo.events : [];
            let i = Math.max(0, this._vo.nextIdx || 0);

            // Seek / Backwards check
            if (prev > t) {
                this._resetVoiceoverCursor(t);
                i = Math.max(0, this._vo.nextIdx || 0);
            }

            // @FIX 2026-07-24 TTS_OVERLAP: Wait for the currently-playing TTS audio
            // to actually finish before starting the next segment. Previously, the
            // timeline fired the next cue at its scheduled timeMs even if the previous
            // TTS audio was still playing, causing overlapping audio between questions.
            // We track _vo.activeUntilMs (timeline ms when current audio ends) in
            // _playVoiceoverText and _stopVoiceover. If the next event's scheduled time
            // is earlier than activeUntilMs, push the cursor forward but DO NOT fire
            // until the timeline catches up to activeUntilMs.
            const activeUntil = Number(this._vo && this._vo.activeUntilMs || 0);

            let fired = false;
            while (i < ev.length) {
                const e = ev[i];
                const tm = Number(e.timeMs || 0);

                // If we haven't reached the event yet, stop looking
                if (t < tm) break;

                // If a previous TTS is still playing and this event is scheduled before
                // the previous audio finishes, hold off firing. The cursor stays put so
                // the event will fire once the timeline reaches activeUntil (or audio ends).
                if (tm < activeUntil && t < activeUntil) {
                    break;
                }

                // If we cross the threshold, play it
                if (e.text && e.text.trim()) {
                    console.log('[TTS] Reading segment:', i, e.text.substring(0, 30));
                    // Capture the event's scheduled time so _playVoiceoverText can
                    // compute activeUntilMs relative to the timeline.
                    this._playVoiceoverText(e.text, tm)
                        .catch((err) => { console.warn('[TTS] playVoiceoverText failed:', err); });
                    fired = true;
                }

                // Advance cursor and STOP. We only play ONE segment per tick to prevent stacking.
                i++;
                this._vo.nextIdx = i;
                break;
            }
            // Suppress unused-variable warning when no event fired this tick.
            void fired;
        }

        _buildVoiceoverEvents(plan) {
            const vo = this.state && this.state.voiceover ? this.state.voiceover : {};

            const events = [];
            const scenes = (plan && Array.isArray(plan.scenes)) ? plan.scenes : [];
            let qSeq = 0;

            const normalize = (s) => String(s || '').replace(/\s{2,}/g, ' ').trim();

            for (const sc of scenes) {
                if (!sc) continue;
                const start = Number(sc.startMs || 0);

                if (sc.type === 'hook' && vo.speakHook !== false) {
                    const txt = normalize(this.state.hookText);
                    if (txt) events.push({ timeMs: start + 50, text: txt, kind: 'hook' });
                    continue;
                }

                if (sc.type === 'outro' && vo.speakCta) {
                    const txt = normalize(this.state.computedCtaText || this.state.ctaText);
                    if (txt) events.push({ timeMs: start + 200, text: txt, kind: 'cta' });
                    continue;
                }

                if (sc.type === 'question') {
                    qSeq++;
                    const c = sc.content || {};
                    const endMs = Number(sc.endMs || (start + Number(sc.durMs || 12000)));
                    const revealMs = Number(sc.timing?.questionPhases?.reveal || 3000);
                    const revealStart = Math.max(0, endMs - revealMs);

                    // @FIX 2026-07-24: Match server-renderer.js + studio.export.js text
                    // exactly. Removing the "Options:" prefix removes an extra spoken
                    // word that was not measured by the WPM estimator, causing audio
                    // length to exceed the timer.
                    const qText = `Question ${qSeq}. ${normalize(c.question)}.`;
                    let qReadTimeMs = start + 80;
                    if (vo.speakOptions !== false && Array.isArray(c.options)) {
                        const safe = [c.options[0], c.options[1], c.options[2], c.options[3]].map(v => v || '').filter(Boolean);
                        let line = qText;
                        if (safe.length) {
                            if (c.options[0]) line += ` ${normalize(c.options[0])}.`;
                            if (c.options[1]) line += ` ${normalize(c.options[1])}.`;
                            if (c.options[2]) line += ` ${normalize(c.options[2])}.`;
                            if (c.options[3]) line += ` ${normalize(c.options[3])}.`;
                        }
                        events.push({ timeMs: qReadTimeMs, text: line, type: 'q_read', kind: 'q_read', sceneId: sc.id });
                    } else {
                        events.push({ timeMs: qReadTimeMs, text: qText, type: 'question', kind: 'q_read', sceneId: sc.id });
                    }

                    // @FIX 2026-07-24: Match server-renderer.js reveal cue placement.
                    // The actual TTS duration is unknown at event-build time; the
                    // _tickVoiceover overlap guard below prevents stacking.
                    const earliestRevealCue = qReadTimeMs + 250;

                    if (vo.speakAnswer !== false) {
                        const idx = Math.max(0, Math.min(3, parseInt(c.correct || 0)));
                        const letter = String.fromCharCode(65 + idx);
                        const opt = (c.options && c.options[idx]) ? normalize(c.options[idx]) : '';

                        const phraseTplRaw = String(vo.answerPhrase || 'correct answer is');
                        let ansText = '';
                        if (phraseTplRaw && /\s/.test(phraseTplRaw)) {
                            if (/\{letter\}|\{option\}|\{text\}/i.test(phraseTplRaw)) {
                                ansText = phraseTplRaw
                                    .replace(/\{letter\}/gi, letter)
                                    .replace(/\{option\}|\{text\}/gi, opt);
                                if (!/\{option\}|\{text\}/i.test(phraseTplRaw) && opt) {
                                    ansText = `${ansText} ${opt}.`;
                                }
                            } else {
                                ansText = `${phraseTplRaw} ${opt}.`;
                            }
                        } else {
                            ansText = `${phraseTplRaw} ${opt}.`;
                        }
                        ansText = normalize(ansText);

                        // Match server-renderer.js reveal cue clamp (line 199)
                        const revealCueTime = Math.min(
                            Math.max(revealStart + 20, earliestRevealCue),
                            Math.max(earliestRevealCue, endMs - 100)
                        );
                        events.push({ timeMs: revealCueTime, text: ansText, type: 'answer', kind: 'reveal', sceneId: sc.id });
                    }
                }
            }

            return events.sort((a, b) => a.timeMs - b.timeMs);
        }

        _voiceoverEnabled() {
            const vo = this.state && this.state.voiceover;
            return !!(vo && vo.enabled);
        }

        _ensureVoiceoverAudioUrl(text) {
        const vo = this.state && this.state.voiceover ? this.state.voiceover : {};
        const provider = String(vo.provider || 'edge').trim();

        const voice = String(vo.voice || 'en-US-AriaNeural').trim();
            const rate = Number(vo.rate || 1.05);
            const pitch = Number(vo.pitch || 0);

            const cleanText = String(text || '').trim();
            if (!cleanText) return Promise.resolve('');

            const key = `${provider}|${voice}|${rate}|${pitch}|${cleanText}`;

            if (this._vo.cache && this._vo.cache.has(key)) return Promise.resolve(this._vo.cache.get(key));
            if (this._vo.inFlight && this._vo.inFlight.has(key)) return this._vo.inFlight.get(key);

            const p = this._ajaxPost('mcqvs_generate_tts', { text: cleanText, provider, voice, rate, pitch })
                .then((resp) => {
                    if (!resp || !resp.success || !resp.data || !resp.data.audio_url) {
                        throw new Error((resp && resp.data && resp.data.message) ? resp.data.message : 'TTS failed');
                    }
                    if (this._vo.cache) this._vo.cache.set(key, resp.data.audio_url);
                    return resp.data.audio_url;
                })
                .finally(() => {
                    if (this._vo.inFlight) this._vo.inFlight.delete(key);
                });

            if (this._vo.inFlight) this._vo.inFlight.set(key, p);
            return p;
        }

        // @FIX 2026-07-31: Pick a browser SpeechSynthesis voice that best matches the
        //       configured default TTS voice (so previews don't default to the browser's
        //       male first-voice). Preference: configured voice name match → female neural
        //       voices → any Google/Microsoft English → any English voice.
        _pickWebSpeechVoice(vo) {
            try {
                if (!('speechSynthesis' in window)) return null;
                const voices = speechSynthesis.getVoices() || [];
                const englishVoices = voices.filter((v) => v.lang && v.lang.toLowerCase().startsWith('en'));
                if (!englishVoices.length) return null;

                const configured = String((vo && vo.voice) || '').trim().toLowerCase();
                // Match on the voice SHORT-NAME only (e.g. "aria" from "en-US-AriaNeural");
                // the language/locale prefix ("en", "us") matches every English voice and
                // would re-select the browser's default male voice.
                const extractShortName = (id) => {
                    const parts = String(id || '').split('-');
                    let name = parts[parts.length - 1] || '';
                    name = name.replace(/\d+$/i, '').replace(/neural$/i, '');
                    return name.toLowerCase() || '';
                };
                const shortName = extractShortName(configured);
                const matchConfigured = shortName
                    ? englishVoices.find((v) => {
                          const hay = String(v.name + ' ' + (v.voiceURI || '')).toLowerCase();
                          return hay.includes(shortName) ||
                              new RegExp('\\b' + shortName + '\\b').test(hay.replace(/[^a-z0-9]/g, ' '));
                      })
                    : null;
                if (matchConfigured) return matchConfigured;

                const femaleHints = ['aria', 'jenny', 'michelle', 'sonia', 'libby', 'maisie', 'natasha', 'neerja', 'clara', 'emily', 'ana', 'zira', 'hazel', 'heera', 'amy', 'jane', 'zoe', 'susan', 'katherine', 'google us english'];
                const matchFemale =
                    englishVoices.find((v) => femaleHints.some((hint) => v.name.toLowerCase().includes(hint))) ||
                    englishVoices.find((v) => /\(female\)/i.test(v.name));
                if (matchFemale) return matchFemale;

                return englishVoices.find((v) => v.name.includes('Google') || v.name.includes('Microsoft')) ||
                    englishVoices[0] || null;
            } catch (_) {
                return null;
            }
        }

        async _playVoiceoverText(text, cueTimeMs) {
            const cleanText = String(text || '').trim();
            if (!cleanText) return;

            const vo = this.state && this.state.voiceover ? this.state.voiceover : {};
            const providerRaw = String(vo.provider || 'edge').trim().toLowerCase();
            const cueStart = Math.max(0, Number(cueTimeMs) || 0);

		// @MODIFIED 2026-02-26: Provider "webspeech" is preview-only: use browser TTS so it works without API keys.
	if (providerRaw === 'webspeech') {
			this._stopVoiceover();

			try {
				const tts = window.MCQVS_TTSManager;
				if (tts && typeof tts.setProvider === 'function' && typeof tts.speak === 'function') {
					tts.setProvider('webspeech');
					const rate = Number(vo.rate || 1.0);
				if (this._vo) { this._vo.isSpeaking = true; this._vo._speakingSince = Date.now(); }
				const clear = () => { if (this._vo) { this._vo.isSpeaking = false; this._vo._speakingSince = 0; } };

				// @FIX 2026-07-31: Feed the TTS_OVERLAP guard so it can hold back the
				//       NEXT segment while browser speech is still playing. Previously
				//       activeUntilMs was never set, so the guard in _tickVoiceover never
				//       held — the next cue fired on schedule, MCQVS_TTSManager._speaking
				//       dropped it, and TTS progressively fell behind the timer/questions.
				//       Use the plugin's own WPM estimator (same one auto-fit uses) capped
				//       at the cue gap, so we only push when the segment is genuinely long.
				if (this._vo) {
					const estMs = (typeof tts.estimateDuration === 'function')
						? Number(tts.estimateDuration(cleanText)) || 0
						: 0;
					this._vo.activeUntilMs = Math.max(this._vo.activeUntilMs || 0, cueStart + Math.min(estMs, 12000));
				}

				const wordCount = cleanText.split(/\s+/).filter(Boolean).length;
				const maxDurationMs = Math.max(5000, Math.ceil((wordCount / 2.5) * 1000 * 1.5) + 3000);
				const safetyTimer = setTimeout(() => {
					console.warn('[TTS] Safety timeout triggered for:', cleanText.substring(0, 30));
					try { if (window.speechSynthesis) window.speechSynthesis.cancel(); } catch (_) {}
					clear();
				}, maxDurationMs);

				await tts.speak(cleanText, { rate: rate, pitch: 1.0 })
					.then(() => { clearTimeout(safetyTimer); clear(); })
					.catch(() => { clearTimeout(safetyTimer); clear(); });
					return;
				}
			} catch (_) { }

		try {
			if ('speechSynthesis' in window) {
				const u = new SpeechSynthesisUtterance(cleanText);
				u.rate = Math.max(0.6, Math.min(1.4, Number(vo.rate || 1.0)));
				u.pitch = 1.0;
				const wVoice = this._pickWebSpeechVoice(vo);
				if (wVoice) u.voice = wVoice;
				if (this._vo) { this._vo.isSpeaking = true; this._vo._speakingSince = Date.now(); }
				if (this._vo) {
					const ttsFb = window.MCQVS_TTSManager;
					const estMsFb = (ttsFb && typeof ttsFb.estimateDuration === 'function')
						? Number(ttsFb.estimateDuration(cleanText)) || 0
						: 0;
					this._vo.activeUntilMs = Math.max(this._vo.activeUntilMs || 0, cueStart + Math.min(estMsFb, 12000));
				}
				const clear = () => { if (this._vo) { this._vo.isSpeaking = false; this._vo._speakingSince = 0; } };
				u.onended = clear;
				u.onerror = clear;
				window.speechSynthesis.cancel();
				window.speechSynthesis.speak(u);

				const wordCount = cleanText.split(/\s+/).filter(Boolean).length;
				const maxDurationMs = Math.max(5000, Math.ceil((wordCount / 2.5) * 1000 * 1.5) + 3000);
				setTimeout(() => {
					if (this._vo && this._vo.isSpeaking) {
						console.warn('[TTS] Fallback safety timeout triggered for:', cleanText.substring(0, 30));
						try { window.speechSynthesis.cancel(); } catch (_) {}
						clear();
					}
				}, maxDurationMs);
			}
		} catch (_) { }

                return;
            }

            // Server-generated TTS (Google / Azure / ElevenLabs / Edge)
            const url = await this._ensureVoiceoverAudioUrl(cleanText);
            if (url) {
                this._stopVoiceover();

                const a = new Audio(url);
                a.preload = 'auto';
                a.volume = 1.0;

                if (this._vo) {
                    this._vo.activeAudio = a;
                    this._vo.isSpeaking = true;
                    this._vo._speakingSince = Date.now();
                    // @FIX 2026-07-31: Feed the TTS_OVERLAP guard with the measured audio
                    //       length so the next cue is held until this segment actually ends
                    //       (previously activeUntilMs was never set, so the guard never held
                    //       and segments could overlap/drop, desyncing TTS from the timer).
                    this._vo.activeUntilMs = Math.max(this._vo.activeUntilMs || 0, cueStart + 400);
                    const onMeta = () => {
                        const durMs = Number.isFinite(a.duration) ? Math.round(a.duration * 1000) : 0;
                        if (durMs > 0 && this._vo) {
                            this._vo.activeUntilMs = Math.max(this._vo.activeUntilMs || 0, cueStart + durMs + 150);
                        }
                    };
                    a.addEventListener('loadedmetadata', onMeta, { once: true });
                    if (a.readyState >= 1) onMeta();
                }

                const clear = () => {
                    if (this._vo) {
                        this._vo.isSpeaking = false;
                        this._vo.activeAudio = null;
                        this._vo._speakingSince = 0;
                    }
                };

                a.onended = clear;
                a.onerror = clear;

                try { await a.play(); } catch (_) { clear(); }
                return;
            }

            // @FALLBACK 2026-07-01: Server TTS failed (Node.js missing/API unreachable),
            // use browser SpeechSynthesis so preview is never silent.
            console.warn('[TTS] Server TTS failed, falling back to browser SpeechSynthesis');
            try {
                if ('speechSynthesis' in window) {
                    this._stopVoiceover();
                    const u = new SpeechSynthesisUtterance(cleanText);
                    u.rate = Math.max(0.6, Math.min(1.4, Number(vo.rate || 1.0)));
                    u.pitch = 1.0;
                    const wVoice = this._pickWebSpeechVoice(vo);
                    if (wVoice) u.voice = wVoice;
                    if (this._vo) { this._vo.isSpeaking = true; this._vo._speakingSince = Date.now(); }
                    // @FIX 2026-07-31: Feed the overlap guard from the fallback path too.
                    if (this._vo) {
                        const tts = window.MCQVS_TTSManager;
                        const estMs = (tts && typeof tts.estimateDuration === 'function')
                            ? Number(tts.estimateDuration(cleanText)) || 0
                            : 0;
                        this._vo.activeUntilMs = Math.max(this._vo.activeUntilMs || 0, cueStart + Math.min(estMs, 12000));
                    }
                    const clear = () => { if (this._vo) { this._vo.isSpeaking = false; this._vo._speakingSince = 0; } };
                    u.onended = clear;
                    u.onerror = clear;
                    window.speechSynthesis.cancel();
                    window.speechSynthesis.speak(u);

                    const wordCount = cleanText.split(/\s+/).filter(Boolean).length;
                    const maxDurationMs = Math.max(5000, Math.ceil((wordCount / 2.5) * 1000 * 1.5) + 3000);
                    setTimeout(() => {
                        if (this._vo && this._vo.isSpeaking) {
                            console.warn('[TTS] Fallback safety timeout triggered for:', cleanText.substring(0, 30));
                            try { window.speechSynthesis.cancel(); } catch (_) {}
                            clear();
                        }
                    }, maxDurationMs);
                }
            } catch (_) { }
        }
        getAudioLibrary() {
            // @MODIFIED 2026-02-14: Prioritize dynamic library from server config (Auto-Sync)
            const configLib = this.config && this.config.audio && this.config.audio.library;
            if (configLib) {
                // @FIX 2026-02-14: Sync global for backward compatibility with renderSoundLibraries
                window.MCQVS_AudioLibrary = configLib;
                return configLib;
            }

            // Prefer explicit window export, fallback to global identifier if bundled that way.
            // eslint-disable-next-line no-undef
            let lib = window.MCQVS_AudioLibrary || (typeof MCQVSAudioLibrary !== 'undefined' ? MCQVSAudioLibrary : null);

            // @PARITY 2026-02-04: Inject Default Library if missing (Legacy Port)
            if (!lib) {
                const base = this._getBasePath();
                lib = {
                    sfx: {
                        tick: [
                            { id: "tick_local", name: "Clock Tick", url: base + "audio/sfx/tick.mp3" }
                        ],
                        correct: [
                            { id: "correct_local", name: "Success Chime", url: base + "audio/sfx/correct.mp3" },
                            { id: "success_local", name: "Victory", url: base + "audio/sfx/success.mp3" }
                        ],
                        wrong: [
                            { id: "wrong_local", name: "Error Buzz", url: base + "audio/sfx/wrong.mp3" }
                        ],
                        reveal: [
                            { id: "reveal_local", name: "Answer Reveal", url: base + "audio/sfx/reveal.mp3" }
                        ],
                        transition: [
                            { id: "transition_local", name: "Scene Transition", url: base + "audio/sfx/transition.mp3" },
                            { id: "whoosh_local", name: "Whoosh", url: base + "audio/sfx/whoosh.mp3" }
                        ]
                    },
                    music: [
                        { id: "chill_local", name: "Chill Vibes", url: base + "audio/music/chill-loop.mp3" },
                        { id: "chill2_local", name: "Chill Vibes 2", url: base + "audio/music/chill-loop-2.mp3" },
                        { id: "epic_local", name: "Epic Theme", url: base + "audio/music/epic-loop.mp3" },
                        { id: "tense_local", name: "Tense Atmosphere", url: base + "audio/music/tense-loop.mp3" },
                        { id: "upbeat_local", name: "Upbeat Energy", url: base + "audio/music/upbeat-loop.mp3" }
                    ]
                };
                // Expose it back to window
                window.MCQVS_AudioLibrary = lib;

                if (_getLogger()) _getLogger().info('AUDIO_LIB_RESTORED', { tracks: lib.music.length });
            }
            return lib;
        }

        /**
         * Fix local paths in audio library
         */
        fixLocalPaths() {
            const basePath = this._getBasePath();
            const lib = this.getAudioLibrary();
            if (!lib) return;

            const fixPath = (items) => {
                if (!items) return;
                items.forEach(item => {
                    if (item.url && item.url.startsWith('./assets/')) {
                        item.url = item.url.replace('./assets/', basePath);
                    }
                });
            };

            fixPath(lib.sfx?.tick);
            fixPath(lib.sfx?.correct);
            fixPath(lib.sfx?.wrong);
            fixPath(lib.music);
        }

        /**
         * Render sound libraries
         */
        renderSoundLibraries() {
            // @FIX 2026-02-14: Use getAudioLibrary() instead of window.MCQVS_AudioLibrary
            const lib = this.getAudioLibrary();
            if (!lib) return;

            this.renderSoundLibrary('tick', lib.sfx?.tick || []);
            this.renderSoundLibrary('correct', lib.sfx?.correct || []);
            this.renderSoundLibrary('wrong', lib.sfx?.wrong || []);
            this.renderSoundLibrary('reveal', lib.sfx?.reveal || []);
            this.renderSoundLibrary('transition', lib.sfx?.transition || []);
            this.renderMusicLibrary(lib.music || []);
        }

        /**
         * Render sound library for specific type
         */
        renderSoundLibrary(type, sounds) {
            const container = document.getElementById(`sfx-${type}-options`);
            if (!container) return;

            container.innerHTML = '';

            sounds.forEach(sound => {
                const card = this.createSoundCard(sound, type);
                container.appendChild(card);
            });
        }

        /**
         * Create sound card element
         */
        createSoundCard(sound, type) {
            const card = document.createElement('div');
            card.className = 'mcqvs-sound-card';
            card.dataset.id = sound.id;
            card.dataset.type = type;

            card.innerHTML = `
                <div class="mcqvs-sound-card-name">${sound.name}</div>
                <div class="mcqvs-sound-card-controls">
                    <button class="mcqvs-sound-play-btn" type="button">â–¶</button>
                    <button class="mcqvs-sound-select-btn" type="button">Select</button>
                </div>
            `;

            // Play button
            card.querySelector('.mcqvs-sound-play-btn')?.addEventListener('click', (e) => {
                e.stopPropagation();
                this.playSound(sound.url, e.target);
            });

            const onSelect = (e) => {
                if (e) e.stopPropagation();
                if (type === 'music') this.selectMusic(sound.url, card);  // FIX 2026-02-03
                else this.selectSound(type, sound.url, card);
            };

            card.querySelector('.mcqvs-sound-select-btn')?.addEventListener('click', onSelect);
            card.addEventListener('click', onSelect);

            return card;
        }

        /**
         * Play sound preview
         */
        playSound(url, btn) {
            // Stop any currently playing preview
            if (this.previewAudio) {
                this.previewAudio.pause();
                this.previewAudio.currentTime = 0;
            }

            // Create and play new audio
            this.previewAudio = new Audio(url);
            btn.textContent = 'â¸';

            this.previewAudio.play().catch(err => {
                if (_getLogger()) {
                    _getLogger().warn('AUDIO_PREVIEW_FAIL', { error: err.message });
                }
                btn.textContent = 'â–¶';
            });

            this.previewAudio.onended = () => {
                btn.textContent = 'â–¶';
            };

            // Pause on second click
            btn.onclick = (e) => {
                e.stopPropagation();
                if (this.previewAudio && !this.previewAudio.paused) {
                    this.previewAudio.pause();
                    btn.textContent = 'â–¶';
                }
            };
        }

        /**
         * Select sound and update state
         */
        selectSound(type, url, card) {
            // Update UI
            document.querySelectorAll(`.mcqvs-sound-card[data-type="${type}"]`).forEach(c => {
                c.classList.remove('selected');
                c.querySelector('.mcqvs-sound-select-btn').textContent = 'Select';
            });

            card.classList.add('selected');
            card.querySelector('.mcqvs-sound-select-btn').textContent = 'âœ“ Selected';

            // Update state
            if (!this.state.sfxUrls || typeof this.state.sfxUrls !== 'object') this.state.sfxUrls = {};
            this.state.sfxUrls[type] = url;

            document.dispatchEvent(new CustomEvent('mcqvs:audio:changed'));

            if (_getLogger()) {
                _getLogger().info('AUDIO_SFX_SELECT', { type, url });
            }
        }

        /**
         * Render background music library
         */
        renderMusicLibrary(tracks) {
            // FIX 2026-02-03: Strict selector + always-visible music grid.
            const container = document.querySelector('#audio-tab-music .mcqvs-sound-group');
            if (!container) return;

            let musicGrid = document.getElementById('music-options');

            if (!musicGrid) {
                musicGrid = document.createElement('div');
                musicGrid.className = 'mcqvs-sound-options';
                musicGrid.id = 'music-options';

                // FIX 2026-02-03: Do not inherit "hidden by default" behavior from SFX libraries.
                musicGrid.style.display = 'grid';
                musicGrid.style.gridTemplateColumns = 'repeat(2, minmax(0, 1fr))';
                musicGrid.style.gap = '10px';

                // Insert above the upload row (if present), else at top.
                const uploadRow = container.querySelector('.mcqvs-custom-upload');
                container.insertBefore(musicGrid, uploadRow || container.firstChild);
            } else {
                musicGrid.innerHTML = '';
                musicGrid.style.display = 'grid';
            }

            if (!Array.isArray(tracks) || tracks.length === 0) {
                musicGrid.innerHTML = '<div class="mcqvs-empty-state">No bundled background music found. Upload a track below.</div>';
                return;
            }

            tracks.forEach(track => {
                const card = this.createSoundCard(track, 'music');
                musicGrid.appendChild(card);
            });
        }

        selectMusic(url, card) {
            // @MODIFIED 2026-02-14: STOP existing playback before switching
            if (this.customMusic) {
                try { this.customMusic.pause(); this.customMusic.currentTime = 0; } catch (_) { }
            }
            if (this.previewAudio) {
                try { this.previewAudio.pause(); this.previewAudio.currentTime = 0; } catch (_) { }
            }

            // Update UI
            document.querySelectorAll('.mcqvs-sound-card[data-type="music"]').forEach(c => {
                c.classList.remove('selected');
                const selBtn = c.querySelector('.mcqvs-sound-select-btn');
                if (selBtn) selBtn.textContent = 'Select';

                // Reset play buttons too
                const playBtn = c.querySelector('.mcqvs-sound-play-btn');
                if (playBtn) playBtn.textContent = 'â–¶';
            });

            card.classList.add('selected');
            const btn = card.querySelector('.mcqvs-sound-select-btn');
            if (btn) btn.textContent = 'âœ“ Selected';

            // Update state
            this.customMusic = new Audio(url);
            this.customMusic.preload = 'auto';
            this.customMusic.loop = true;
            // Prime decode/buffer on user gesture to minimize start lag
            try {
                this.customMusic.muted = true;
                const p = this.customMusic.play();
                if (p && typeof p.then === 'function') {
                    p.then(() => {
                        this.customMusic.pause();
                        this.customMusic.currentTime = 0;
                        this.customMusic.muted = false;
                    }).catch(() => { this.customMusic.muted = false; });
                } else {
                    this.customMusic.muted = false;
                }
            } catch (_) { }
            this.customMusic.addEventListener('ended', () => {
                if (this._transportPlaying && this.state.audioEnabled && this.state.musicEnabled) {
                    try { this.customMusic.currentTime = 0; this.customMusic.play().catch(() => { }); } catch (_) { }
                }
            });
            this.state.backgroundMusic = 'custom';
            this.state.bgMusicUrl = url;

            if (_getLogger()) {
                _getLogger().info('AUDIO_MUSIC_SELECT', { url });
            }
        }

        /**
         * Handle custom SFX upload
         */
        handleCustomUpload(file, type) {
            if (!file) return;

            const url = URL.createObjectURL(file);

            // Clear selection
            document.querySelectorAll(`.mcqvs-sound-card[data-type="${type}"]`).forEach(c => {
                c.classList.remove('selected');
                c.querySelector('.mcqvs-sound-select-btn').textContent = 'Select';
            });

            // Update state
            this.customSFX[type] = new Audio(url);

            if (_getLogger()) {
                _getLogger().info('AUDIO_CUSTOM_UPLOAD', { type });
            }
        }

        /**
         * Play SFX with gating
         */
        playSFX(name, options = {}) {
            if (!this.state.audioEnabled || !this.state.sfxEnabled) {
                return;
            }

            // Check if user has selected custom sound
            if (this.customSFX[name]) {
                try {
                    const sound = this.customSFX[name];
                    if (sound.readyState >= 2 && sound.duration > 0) {
                        const clone = sound.cloneNode();
                        clone.volume = options.volume || 0.7;

                        // track clone
                        this._activeSfxClones.push(clone);
                        const cleanup = () => {
                            const i = this._activeSfxClones.indexOf(clone);
                            if (i >= 0) this._activeSfxClones.splice(i, 1);
                        };
                        clone.addEventListener('ended', cleanup, { once: true });
                        clone.addEventListener('pause', cleanup, { once: true });

                        clone.play().catch(e => {
                            cleanup();

                            if (_getLogger()) {
                                _getLogger().warn('AUDIO_SFX_PLAY_FAIL', { name, error: e.message });
                            }
                        });
                        return;
                    }
                } catch (e) {
                    if (_getLogger()) {
                        _getLogger().warn('AUDIO_CUSTOM_SFX_FAIL', { name, error: e.message });
                    }
                }
            }

            // Fallback to AudioManager
            if (this.audioManager) {
                this.audioManager.playSFX(name, options);
            }
        }

        /**
         * Sync audio state from UI
         */
        syncFromUI() {
            const masterToggle = document.getElementById('enableMasterAudioToggle');
            const sfxToggle = document.getElementById('enableSFXToggle');
            const musicToggle = document.getElementById('enableMusicToggle');

            if (masterToggle) {
                this.state.audioEnabled = masterToggle.checked;
            }

            if (sfxToggle && this.state.audioEnabled) {
                this.state.sfxEnabled = sfxToggle.checked;
            }

            if (musicToggle && this.state.audioEnabled) {
                this.state.musicEnabled = musicToggle.checked;
            }

            // Update AudioManager volumes
            if (this.audioManager) {
                this.audioManager.setVolume('sfx', this.state.sfxEnabled ? 1 : 0);
                this.audioManager.setVolume('music', this.state.musicEnabled ? 1 : 0);
            }
            // Hard stop currently playing audio when toggles go OFF
            if (!this.state.audioEnabled) {
                this.stop();
                return;
            }
            if (!this.state.sfxEnabled && this.audioManager && typeof this.audioManager.stopSFX === 'function') {
                try { this.audioManager.stopSFX(); } catch (_) { }
            }
            if (!this.state.musicEnabled) {
                try { if (this.customMusic) { this.customMusic.pause(); this.customMusic.currentTime = 0; } } catch (_) { }
                try { if (this.audioManager && typeof this.audioManager.stopMusic === 'function') this.audioManager.stopMusic(200); } catch (_) { }
            }

            if (_getLogger()) {
                _getLogger().debug('AUDIO_STATE_SYNC', {
                    audioEnabled: this.state.audioEnabled,
                    sfxEnabled: this.state.sfxEnabled,
                    musicEnabled: this.state.musicEnabled
                });
            }
        }

        /**
         * Bind event handlers
         */
        bindEventHandlers() {
            // Master audio toggle
            const masterToggle = document.getElementById('enableMasterAudioToggle');
            if (masterToggle) {
                masterToggle.addEventListener('change', () => this.syncFromUI());
            }

            // SFX toggle
            const sfxToggle = document.getElementById('enableSFXToggle');
            if (sfxToggle) {
                sfxToggle.addEventListener('change', () => this.syncFromUI());
            }

            // Music toggle
            const musicToggle = document.getElementById('enableMusicToggle');
            if (musicToggle) {
                musicToggle.addEventListener('change', () => this.syncFromUI());
            }

            // Custom uploads
            const uploadTick = document.getElementById('upload-tick');
            if (uploadTick) {
                uploadTick.addEventListener('change', (e) => {
                    this.handleCustomUpload(e.target.files[0], 'tick');
                });
            }

            const uploadCorrect = document.getElementById('upload-correct');
            if (uploadCorrect) {
                uploadCorrect.addEventListener('change', (e) => {
                    this.handleCustomUpload(e.target.files[0], 'correct');
                });
            }

            const uploadWrong = document.getElementById('upload-wrong');
            if (uploadWrong) {
                uploadWrong.addEventListener('change', (e) => {
                    this.handleCustomUpload(e.target.files[0], 'wrong');
                });
            }

            // @NEW 2026-07-02: Reveal + Transition custom uploads
            const uploadReveal = document.getElementById('upload-reveal');
            if (uploadReveal) {
                uploadReveal.addEventListener('change', (e) => {
                    this.handleCustomUpload(e.target.files[0], 'reveal');
                });
            }

            const uploadTransition = document.getElementById('upload-transition');
            if (uploadTransition) {
                uploadTransition.addEventListener('change', (e) => {
                    this.handleCustomUpload(e.target.files[0], 'transition');
                });
            }

            // Library toggle buttons
            document.querySelectorAll('.toggle-sound-library').forEach(btn => {
                btn.addEventListener('click', function () {
                    const target = this.dataset.target;
                    const el = document.getElementById(target);
                    if (el) {
                        el.style.display = el.style.display === 'none' ? 'block' : 'none';
                    }
                });
            });

            // @NEW 2026-02-03: Background music upload (matches PHP id="bgMusicUpload")
            const bgMusicUpload = document.getElementById('bgMusicUpload');
            if (bgMusicUpload) {
                bgMusicUpload.addEventListener('change', (e) => {
                    this.handleMusicUpload(e.target.files[0]);
                });
            }
        }

        /**
         * Handle custom background music upload
         * @NEW 2026-02-03: Enables BG music upload from the Music tab.
         * @PATCH 2026-02-03: handleMusicUpload must create an Audio element (start() expects .play()).
         */
        handleMusicUpload(file) {
            if (!file) return;

            // @MODIFIED 2026-02-14: STOP existing playback
            if (this.customMusic) {
                try { this.customMusic.pause(); this.customMusic.currentTime = 0; } catch (_) { }
            }

            const url = URL.createObjectURL(file);

            // Create audio element (match selectMusic behavior)
            this.customMusic = new Audio(url);
            this.customMusic.preload = 'auto';
            this.customMusic.loop = true;
            // Prime decode/buffer on user gesture
            try {
                this.customMusic.muted = true;
                const p = this.customMusic.play();
                if (p && typeof p.then === 'function') {
                    p.then(() => {
                        this.customMusic.pause();
                        this.customMusic.currentTime = 0;
                        this.customMusic.muted = false;
                    }).catch(() => { this.customMusic.muted = false; });
                } else {
                    this.customMusic.muted = false;
                }
            } catch (_) { }
            this.customMusic.addEventListener('ended', () => {
                if (this._transportPlaying && this.state.audioEnabled && this.state.musicEnabled) {
                    try { this.customMusic.currentTime = 0; this.customMusic.play().catch(() => { }); } catch (_) { }
                }
            });

            // Keep state consistent with preview/export logic
            this.state.bgMusicUrl = url;
            this.state.backgroundMusic = 'custom';

            // Clear any selected music cards (if library is rendered)
            document.querySelectorAll('.mcqvs-sound-card[data-type="music"]').forEach(c => {
                c.classList.remove('selected');
                const btn = c.querySelector('.mcqvs-sound-select-btn');
                if (btn) btn.textContent = 'Select';
            });

            if (_getLogger()) _getLogger().info('MUSIC_UPLOAD', { name: file.name, size: file.size, url });
        }
        invalidatePlan() { this._planDirty = true; }




        destroy() {
            this.stopAll();
            if (this.previewAudio) {
                try { this.previewAudio.pause(); } catch (_) { }
                this.previewAudio = null;
            }
            // Deterministic transport reset
            this._renderPlan = null;
            this._audioRouter = null;
            this._lastTickMs = 0;

            if (_getLogger()) {
                _getLogger().info('AUDIO_DESTROY');
            }
        }
    }

    // Export
    window.MCQVS_AudioController = AudioController;

})(window);
