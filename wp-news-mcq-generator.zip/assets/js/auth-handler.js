/**
 * Authentication Handler
 * Handles login, registration, password reset.
 * @package WP_News_MCQ_Generator
 * @version 1.4 - Removed Avatar Upload JS
 *
 * @MODIFIED:
 * - Removed the 'nm-edit-avatar-btn' click handler.
 * - Removed the 'handleAvatarUpload' function.
 */

(function($) {
    'use strict';
    
    const AuthHandler = {
        
        mediaFrame: null, // This is no longer used but safe to keep as null

        init: function() {
            this.bindEvents();
            this.checkAuthState();
        },
        
        bindEvents: function() {
            // Registration form
            $(document).on('submit', '#nm-register-form', this.handleRegistration.bind(this));
            
            // Login form
            $(document).on('submit', '#nm-login-form', this.handleLogin.bind(this));
            
            // Logout
            $(document).on('click', '.nm-logout-btn', this.handleLogout.bind(this));
            
            // Forgot password
            $(document).on('submit', '#nm-forgot-password-form', this.handleForgotPassword.bind(this));
            
            // Reset password
            $(document).on('submit', '#nm-reset-password-form', this.handleResetPassword.bind(this));
            
            // Password visibility toggle
            $(document).on('click', '.nm-toggle-password', this.togglePasswordVisibility);
            
            // Password strength indicator
            $(document).on('keyup', 'input[type="password"][name="password"]', this.checkPasswordStrength);

            // ✅ MODIFIED: Avatar upload handler is fully removed.
            
        },
        
        handleRegistration: function(e) {
            e.preventDefault();
            
            const form = $(e.currentTarget);
            const submitBtn = form.find('button[type="submit"]');
            const formData = {
                action: 'nm_user_register',
                nonce: nmAuthData.nonce,
                username: form.find('[name="username"]').val(),
                email: form.find('[name="email"]').val(),
                password: form.find('[name="password"]').val(),
                confirm_password: form.find('[name="confirm_password"]').val(),
                display_name: form.find('[name="display_name"]').val()
            };
            
            submitBtn.prop('disabled', true).text('Registering...');
            form.find('.nm-error-message').remove();
            
            $.ajax({
                url: nmAuthData.ajaxurl,
                type: 'POST',
                data: formData,
                success: function(response) {
                    if (response.success) {
                        form.before('<div class="nm-success-message">' + response.data.message + '</div>');
                        setTimeout(function() {
                            window.location.href = response.data.redirect || nmAuthData.loginUrl;
                        }, 1500);
                    } else {
                        form.before('<div class="nm-error-message">' + response.data.message + '</div>');
                        submitBtn.prop('disabled', false).text('Register');
                    }
                },
                error: function() {
                    form.before('<div class="nm-error-message">An error occurred. Please try again.</div>');
                    submitBtn.prop('disabled', false).text('Register');
                }
            });
        },
        
        handleLogin: function(e) {
            e.preventDefault();
            
            const form = $(e.currentTarget);
            const submitBtn = form.find('button[type="submit"]');
            const formData = {
                action: 'nm_user_login',
                nonce: nmAuthData.nonce,
                username: form.find('[name="username"]').val(),
                password: form.find('[name="password"]').val(),
                remember: form.find('[name="remember"]').is(':checked')
            };
            
            submitBtn.prop('disabled', true).text('Logging in...');
            form.find('.nm-error-message').remove();
            
            $.ajax({
                url: nmAuthData.ajaxurl,
                type: 'POST',
                data: formData,
                success: function(response) {
                    if (response.success) {
                        form.before('<div class="nm-success-message">' + response.data.message + '</div>');
                        
                        setTimeout(function() {
                            window.location.href = response.data.redirect || nmAuthData.dashboardUrl;
                        }, 1000);
                    } else {
                        form.before('<div class="nm-error-message">' + response.data.message + '</div>');
                        submitBtn.prop('disabled', false).text('Login');
                    }
                },
                error: function() {
                    form.before('<div class="nm-error-message">An error occurred. Please try again.</div>');
                    submitBtn.prop('disabled', false).text('Login');
                }
            });
        },
        
        handleLogout: function(e) {
            e.preventDefault();
            
            if (!confirm('Are you sure you want to logout?')) {
                return;
            }
            
            $.ajax({
                url: nmAuthData.ajaxurl,
                type: 'POST',
                data: {
                    action: 'nm_user_logout',
                    nonce: nmAuthData.nonce
                },
                success: function(response) {
                    if (response.success) {
                        window.location.href = response.data.redirect || nmAuthData.loginUrl;
                    }
                }
            });
        },
        
        handleForgotPassword: function(e) {
            e.preventDefault();
            
            const form = $(e.currentTarget);
            const submitBtn = form.find('button[type="submit"]');
            const formData = {
                action: 'nm_user_forgot_password',
                nonce: nmAuthData.nonce,
                email: form.find('[name="email"]').val()
            };
            
            submitBtn.prop('disabled', true).text('Sending...');
            form.find('.nm-error-message, .nm-success-message').remove();
            
            $.ajax({
                url: nmAuthData.ajaxurl,
                type: 'POST',
                data: formData,
                success: function(response) {
                    if (response.success) {
                        form.before('<div class="nm-success-message">' + response.data.message + '</div>');
                        form[0].reset();
                    } else {
                        form.before('<div class="nm-error-message">' + response.data.message + '</div>');
                    }
                    submitBtn.prop('disabled', false).text('Send Reset Link');
                },
                error: function() {
                    form.before('<div class="nm-error-message">An error occurred. Please try again.</div>');
                    submitBtn.prop('disabled', false).text('Send Reset Link');
                }
            });
        },
        
        handleResetPassword: function(e) {
            e.preventDefault();
            
            const form = $(e.currentTarget);
            const submitBtn = form.find('button[type="submit"]');
            const formData = {
                action: 'nm_user_reset_password',
                nonce: nmAuthData.nonce,
                email: form.find('[name="email"]').val(),
                key: form.find('[name="key"]').val(),
                password: form.find('[name="password"]').val(),
                confirm_password: form.find('[name="confirm_password"]').val()
            };
            
            submitBtn.prop('disabled', true).text('Resetting...');
            form.find('.nm-error-message').remove();
            
            $.ajax({
                url: nmAuthData.ajaxurl,
                type: 'POST',
                data: formData,
                success: function(response) {
                    if (response.success) {
                        form.before('<div class="nm-success-message">' + response.data.message + '</div>');
                        
                        setTimeout(function() {
                            window.location.href = response.data.redirect || nmAuthData.loginUrl;
                        }, 2000);
                    } else {
                        form.before('<div class="nm-error-message">' + response.data.message + '</div>');
                        submitBtn.prop('disabled', false).text('Reset Password');
                    }
                },
                error: function() {
                    form.before('<div class="nm-error-message">An error occurred. Please try again.</div>');
                    submitBtn.prop('disabled', false).text('Reset Password');
                }
            });
        },
        
        /**
         * ✅ MODIFIED: Avatar upload function fully REMOVED.
         */

        togglePasswordVisibility: function() {
            const input = $(this).siblings('input');
            const icon = $(this).find('i');
            
            if (input.attr('type') === 'password') {
                input.attr('type', 'text');
                icon.removeClass('fa-eye').addClass('fa-eye-slash');
            } else {
                input.attr('type', 'password');
                icon.removeClass('fa-eye-slash').addClass('fa-eye');
            }
        },
        
        checkPasswordStrength: function() {
            const password = $(this).val();
            const strengthMeter = $('.nm-password-strength');
            
            if (!strengthMeter.length) {
                $(this).after('<div class="nm-password-strength"></div>');
            }
            
            let strength = 0;
            let message = '';
            let color = '';
            
            if (password.length >= 8) strength++;
            if (password.match(/[a-z]/)) strength++;
            if (password.match(/[A-Z]/)) strength++;
            if (password.match(/[0-9]/)) strength++;
            if (password.match(/[^a-zA-Z0-9]/)) strength++;
            
            switch (strength) {
                case 0:
                case 1:
                    message = 'Very Weak';
                    color = '#e74c3c';
                    break;
                case 2:
                    message = 'Weak';
                    color = '#e67e22';
                    break;
                case 3:
                    message = 'Medium';
                    color = '#f39c12';
                    break;
                case 4:
                    message = 'Strong';
                    color = '#2ecc71';
                    break;
                case 5:
                    message = 'Very Strong';
                    color = '#27ae60';
                    break;
            }
            
            $('.nm-password-strength').text(message).css('color', color);
        },
        
        checkAuthState: function() {
            // Redirect logged-in users away from auth pages
            const currentPath = window.location.pathname;
            const isLoggedIn = $('body').hasClass('logged-in');
            
            if (isLoggedIn && (currentPath.includes('/mcq-login') || currentPath.includes('/mcq-register'))) {
                window.location.href = nmAuthData.dashboardUrl;
            }
        }
    };
    
    // Initialize on document ready
    $(document).ready(function() {
        AuthHandler.init();
    });
    
})(jQuery);