<?php

/**
 * Collage Maker – Admin Controller
 *
 * Handles page registration, asset enqueueing, and AJAX endpoints for
 * both the legacy server-side grid generator and the client-side Split Card canvas.
 *
 * @package DIT_TrendStudio
 * @since 2.13.0
 * @refactor 2026-03-01
 *   – Fixed broken Google Fonts v2 URL (:wght;700 → :wght@400;600;700).
 *   – Fixed ajax_save_canvas_collage accepting only PNG; now handles
 *     webp/jpeg data URLs correctly so the export format selector works.
 *   – Removed hardcoded PNG prefix length from base64 decode.
 *   – Added Noto Sans Urdu as fallback webfont entry.
 *   – Namespaced webFonts labels to match JS font-select values.
 */

namespace DIT\TrendStudio\Admin;

use DIT\TrendStudio\Core\Plugin;
use DIT\TrendStudio\Services\Collage_Generator;

if (! defined('ABSPATH')) {
    exit;
}

class Collage_Admin
{

    /** @var \DIT\TrendStudio\Infrastructure\Logger */
    private $logger;

    /** @var Collage_Generator */
    private $generator;

    public function __construct($logger)
    {
        $this->logger    = $logger;
        $this->generator = new Collage_Generator($logger);
    }

    public function init()
    {
        add_action('wp_ajax_dit_ts_generate_collage',    [$this, 'ajax_generate_collage']);
        add_action('wp_ajax_dit_ts_save_canvas_collage', [$this, 'ajax_save_canvas_collage']);
        add_action('wp_ajax_dit_ts_save_brand_logo',     [$this, 'ajax_save_brand_logo']);
        add_action('admin_enqueue_scripts',               [$this, 'enqueue_assets']);
    }

    /**
     * Enqueue styles and scripts only on the collage maker admin page.
     *
     * @param string $hook Current admin page hook.
     */
    public function enqueue_assets($hook)
    {
        if (strpos($hook, 'dit-ts-collage-maker') === false) {
            return;
        }

        $plugin = Plugin::get_instance();

        wp_enqueue_media();

        /*
     * Google Fonts — Urdu / Arabic webfonts.
     *
     * IMPORTANT: Syntax must be :wght@ (not :wght; or :wght,).
     * Using the wrong separator returns a 400 from Google and silently
     * loads nothing — the canvas then falls back to system fonts.
     *
     * Weights loaded:
     *   400 = body text
     *   700 = headings and brand bar
     *
     * Noto Nastaliq Urdu  — Primary Urdu Nastaliq calligraphic style.
     * Noto Naskh Arabic   — Cleaner Naskh; also works for Urdu.
     * Noto Sans Urdu      — Simple sans-serif fallback at small sizes.
     */
        wp_enqueue_style(
            'dit-ts-collage-webfonts',
            'https://fonts.googleapis.com/css2?'
                . 'family=Noto+Nastaliq+Urdu:wght@400;700'
                . '&family=Noto+Naskh+Arabic:wght@400;700'
                . '&family=Noto+Sans+Urdu:wght@400;700'
                . '&display=swap',
            [],
            null
        );

        wp_enqueue_style(
            'dit-ts-collage',
            DIT_TS_PLUGIN_URL . 'assets/css/collage.css',
            ['dit-ts-collage-webfonts'],
            $plugin->get_asset_version('assets/css/collage.css')
        );

    wp_enqueue_script(
        'dit-ts-collage',
        DIT_TS_PLUGIN_URL . 'assets/js/collage.js',
        ['jquery', 'jquery-ui-sortable'],
        $plugin->get_asset_version('assets/js/collage.js'),
        true
    );

        // Locally installed TTF fonts (legacy grid export).
        $font_files = glob(DIT_TS_PLUGIN_DIR . 'assets/fonts/*.ttf') ?: [];
        $fonts      = array_map(
            function ($path) {
                $filename = basename($path);
                return [
                    'name'     => basename($path, '.ttf'),
                    'url'      => DIT_TS_PLUGIN_URL . 'assets/fonts/' . $filename,
                    'filename' => $filename,
                ];
            },
            $font_files
        );
        usort($fonts, function ($a, $b) {
            return strcmp($a['name'], $b['name']);
        });

        /*
     * webFonts list — consumed by JS to populate the font selector.
     * Values must exactly match the font-family names registered by
     * the Google Fonts stylesheet above.
     */
        $web_fonts = [
            ['label' => 'Noto Nastaliq Urdu (اردو نستعلیق)', 'family' => 'Noto Nastaliq Urdu'],
            ['label' => 'Noto Naskh Arabic (نسخ عربي)',      'family' => 'Noto Naskh Arabic'],
            ['label' => 'Noto Sans Urdu (اردو سادہ)',         'family' => 'Noto Sans Urdu'],
        ];

        wp_localize_script(
            'dit-ts-collage',
            'ditTsCollage',
            [
                'ajaxUrl'  => admin_url('admin-ajax.php'),
                'nonce'    => wp_create_nonce('dit_ts_collage_nonce'),
                'fonts'    => $fonts,
                'webFonts' => $web_fonts,
                'defaults' => [
                    'brandText' => (string) get_option('dit_ts_collage_bottom_text', get_bloginfo('name')),
                    'logoId'    => (int)    get_option('dit_ts_brand_logo_id', 0),
                    'logoUrl'   => (string) wp_get_attachment_url(get_option('dit_ts_brand_logo_id', 0)),
                ],
                'layouts'  => [
                    1 => Collage_Generator::get_available_layouts(1),
                    2 => Collage_Generator::get_available_layouts(2),
                    3 => Collage_Generator::get_available_layouts(3),
                    4 => Collage_Generator::get_available_layouts(4),
                    5 => Collage_Generator::get_available_layouts(5),
                    6 => Collage_Generator::get_available_layouts(6),
                ],
            ]
        );
    }


    /**
     * Render the collage maker admin page.
     */
    public function render_page()
    {
        include DIT_TS_PLUGIN_DIR . 'src/Admin/Views/collage.php';
    }

    // -------------------------------------------------------------------------
    // AJAX: Server-side grid collage (legacy)
    // -------------------------------------------------------------------------

    public function ajax_generate_collage()
    {
        check_ajax_referer('dit_ts_collage_nonce', 'nonce');

        if (! current_user_can('edit_posts')) {
            wp_send_json_error('Unauthorized');
        }

        $raw_ids = isset($_POST['images']) ? (array) $_POST['images'] : [];
        if (empty($raw_ids)) {
            wp_send_json_error('No images selected');
        }

        // Generator expects full URLs, not attachment IDs.
        $images = [];
        foreach ($raw_ids as $raw_id) {
            $att_id = absint($raw_id);
            if (! $att_id) {
                continue;
            }
            $url = wp_get_attachment_url($att_id);
            if ($url) {
                $images[] = $url;
            }
        }

        if (empty($images)) {
            wp_send_json_error('Could not resolve attachment URLs from the provided IDs.');
        }

        $crops_raw = isset($_POST['crops']) ? (array) $_POST['crops'] : [];
        $crops     = [];

        foreach ($crops_raw as $i => $c) {
            if (! is_array($c)) {
                continue;
            }
            $crops[(int) $i] = [
                'x'         => max(0.0, min(100.0, isset($c['x']) ? (float) $c['x'] : 50.0)),
                'y'         => max(0.0, min(100.0, isset($c['y']) ? (float) $c['y'] : 50.0)),
                'scale'     => max(0.5, min(5.0,   isset($c['scale']) ? (float) $c['scale'] : 1.0)),
                'full_crop' => ! empty($c['full_crop']),
            ];
        }

        $options = [
            'vertical'      => sanitize_text_field($_POST['vertical']      ?? 'general'),
            'bottom_text'   => sanitize_textarea_field($_POST['bottom_text'] ?? ''),
            'is_retina'     => filter_var($_POST['is_retina'] ?? false, FILTER_VALIDATE_BOOLEAN),
            'border_color'  => sanitize_text_field($_POST['border_color']  ?? '#000000'),
            'font_file'     => '',
            'font_size'     => (int) ($_POST['font_size']     ?? 24),
            'letter_spacing' => (int) ($_POST['letter_spacing'] ?? 10),
            'layout'        => sanitize_text_field($_POST['layout']        ?? ''),
            'aspect_ratio'  => sanitize_text_field($_POST['aspect_ratio']  ?? 'legacy'),
            'corner_radius' => (int) ($_POST['corner_radius'] ?? 0),
            'blur_intensity' => (int) ($_POST['blur_intensity'] ?? 5),
            'text_align'    => sanitize_text_field($_POST['text_align']    ?? 'center'),
            'line_height'   => (float) ($_POST['line_height'] ?? 1.2),
            'custom_width'  => (int) ($_POST['custom_width']  ?? 800),
            'custom_height' => (int) ($_POST['custom_height'] ?? 800),
            'format'        => sanitize_text_field($_POST['format']        ?? 'webp'),
            'crops'         => $crops,
        ];

        if (! empty($_POST['font_filename'])) {
            $filename = basename(sanitize_text_field($_POST['font_filename']));
            $path     = DIT_TS_PLUGIN_DIR . 'assets/fonts/' . $filename;
            if (file_exists($path)) {
                $options['font_file'] = $path;
            }
        }

        $title = ! empty($_POST['collage_title'])
            ? sanitize_text_field($_POST['collage_title'])
            : 'Collage ' . gmdate('Y-m-d H:i:s');

        $attachment_id = $this->generator->create_collage($images, $title, $options);

        if (is_wp_error($attachment_id)) {
            wp_send_json_error($attachment_id->get_error_message());
        }

        wp_send_json_success([
            'id'  => $attachment_id,
            'url' => wp_get_attachment_url($attachment_id),
        ]);
    }

	// -------------------------------------------------------------------------
	// AJAX: Save client-side Split Card canvas to Media Library
	// -------------------------------------------------------------------------

    /**
     * Accept a canvas data URL (PNG, WEBP or JPEG), convert via GD, and save
     * to the Media Library.
     *
     * FIX 2026-03-01:
     *   The previous code hard-checked for `data:image/png;base64,` and also
     *   used strlen('data:image/png;base64,') as a fixed offset to strip the
     *   header before base64-decoding.  This meant:
     *     – Selecting "webp" or "jpg" export format always returned
     *       "Only PNG canvas payload is supported".
     *     – Even if you manually forced PNG, a different-length prefix would
     *       corrupt the base64 stream.
     *   Fix: parse the data URL header dynamically to extract MIME and strip
     *   the correct prefix length.
     *
     * @return void
     */
    public function ajax_save_canvas_collage()
    {
        check_ajax_referer('dit_ts_collage_nonce', 'nonce');

        if (! current_user_can('edit_posts')) {
            wp_send_json_error('Unauthorized');
        }

        $data_url = isset($_POST['data_url']) ? (string) $_POST['data_url'] : '';

        if ($data_url === '' || strpos($data_url, 'data:image/') !== 0) {
            wp_send_json_error('Invalid image payload');
        }

        // ── Parse data URL header dynamically ──────────────────────────────────
        // Format: data:<mime>;base64,<data>
        $comma_pos = strpos($data_url, ',');
        if ($comma_pos === false) {
            wp_send_json_error('Malformed data URL');
        }

        $header    = substr($data_url, 0, $comma_pos);  // e.g. "data:image/webp;base64"
        $b64       = substr($data_url, $comma_pos + 1); // everything after the comma

        // Extract MIME from header
        preg_match('/^data:([a-zA-Z0-9\/+\-]+);/', $header, $mime_matches);
        $canvas_mime = isset($mime_matches[1]) ? strtolower($mime_matches[1]) : '';

        $allowed_canvas_mimes = ['image/png', 'image/webp', 'image/jpeg'];
        if (! in_array($canvas_mime, $allowed_canvas_mimes, true)) {
            wp_send_json_error('Unsupported canvas MIME type: ' . esc_html($canvas_mime));
        }
        // ── End parse ──────────────────────────────────────────────────────────

        // Output format requested by the user (may differ from canvas MIME)
        $format = sanitize_text_field($_POST['format'] ?? 'webp');
        if (! in_array($format, ['webp', 'jpg', 'jpeg', 'png'], true)) {
            $format = 'webp';
        }
        if ($format === 'jpeg') {
            $format = 'jpg';
        }

        $title = ! empty($_POST['collage_title'])
            ? sanitize_text_field($_POST['collage_title'])
            : 'Collage ' . gmdate('Y-m-d H:i:s');

        $bytes = base64_decode($b64);
        if ($bytes === false || $bytes === '') {
            wp_send_json_error('Failed to decode image');
        }

        // Refuse oversized payloads (12 MB raw decoded)
        if (strlen($bytes) > 12 * 1024 * 1024) {
            wp_send_json_error('Image too large (max 12 MB)');
        }

        if (! function_exists('imagecreatefromstring')) {
            wp_send_json_error('GD extension is not available on this server');
        }

        $img = @imagecreatefromstring($bytes);
        if (! $img) {
            wp_send_json_error('GD could not decode the image payload');
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $tmp = wp_tempnam('dit-ts-canvas');
        if (! $tmp) {
            imagedestroy($img);
            wp_send_json_error('Failed to create temporary file');
        }

        $out_file = $tmp . '.' . $format;
        @rename($tmp, $out_file);

        $saved     = false;
        $save_mime = 'image/webp';

        if ($format === 'png') {
            $saved     = imagepng($img, $out_file, 9);
            $save_mime = 'image/png';
        } elseif ($format === 'jpg') {
            // Flatten transparency to white before JPEG encode
            $bg    = imagecreatetruecolor(imagesx($img), imagesy($img));
            $white = imagecolorallocate($bg, 255, 255, 255);
            imagefill($bg, 0, 0, $white);
            imagecopy($bg, $img, 0, 0, 0, 0, imagesx($img), imagesy($img));
            $saved     = imagejpeg($bg, $out_file, 90);
            $save_mime = 'image/jpeg';
            imagedestroy($bg);
        } else {
            // webp (default)
            $saved     = imagewebp($img, $out_file, 90);
            $save_mime = 'image/webp';
        }

        imagedestroy($img);

        if (! $saved || ! file_exists($out_file)) {
            @unlink($out_file);
            wp_send_json_error('GD failed to write output image');
        }

        $file_array = [
            'name'     => sanitize_title($title) . '-collage.' . $format,
            'tmp_name' => $out_file,
            'type'     => $save_mime,
            'error'    => 0,
            'size'     => (int) (@filesize($out_file) ?: 0),
        ];

        $attachment_id = media_handle_sideload($file_array, 0, $title);
        @unlink($out_file);

        if (is_wp_error($attachment_id)) {
            wp_send_json_error($attachment_id->get_error_message());
        }

        wp_send_json_success([
            'id'  => (int) $attachment_id,
            'url' => wp_get_attachment_url($attachment_id),
        ]);
    }

    /**
     * AJAX: Save brand logo ID as a global setting.
     * 
     * @MODIFIED 2026-03-13 - Enables unified logo across manual and auto collages.
     */
    public function ajax_save_brand_logo()
    {
        check_ajax_referer('dit_ts_collage_nonce', 'nonce');

        if (!current_user_can('edit_posts')) {
            wp_send_json_error('Unauthorized');
        }

        $logo_id = isset($_POST['logo_id']) ? absint($_POST['logo_id']) : 0;
        
        // Update both options if necessary to ensure consistency
        update_option('dit_ts_brand_logo_id', $logo_id);
        
        wp_send_json_success(['message' => 'Brand logo saved globally.']);
    }
}
