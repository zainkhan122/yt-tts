<?php

namespace SEO_Article_Generator\Integration;

if (! defined('ABSPATH')) {
	exit;
}

/**
 * Stub for missing RankMath_Migration class
 * 
 * NOTE: The original implementation of this class was lost during a previous refactor.
 * This stub prevents fatal errors in Plugin.php and Ajax_Router.php.
 */
class RankMath_Migration
{
	/**
	 * AJAX handler for starting migration
	 */
	public static function ajax_start_migration()
	{
		\wp_send_json_error(array(
			'message' => 'RankMath_Migration class is currently a stub. Restoration from deep backup required.',
		));
	}

	/**
	 * AJAX handler for processing a batch
	 */
	public static function ajax_process_batch()
	{
		\wp_send_json_error(array(
			'message' => 'RankMath_Migration class is currently a stub.',
		));
	}
}
