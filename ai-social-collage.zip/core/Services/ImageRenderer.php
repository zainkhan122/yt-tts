<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Contracts\ImageGeneratorInterface;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) exit;

class ImageRenderer implements ImageGeneratorInterface {

	private static $pango_available = null;

public function generate( array $job_data ) {
$start_time = microtime( true );

$smart_ai_enabled = (bool) get_option( Config::OPTION_SMART_AI_ENABLED, true );
if ( $smart_ai_enabled ) {
$job_data = SmartAI::enhance_job_data( $job_data );
} else {
if ( empty( $job_data['brand'] ) ) {
$job_data['brand'] = Config::get_brand_settings();
}
$job_data['colors'] = [
'primary' => $job_data['brand']['primary_color'],
'secondary' => $job_data['brand']['secondary_color'],
'accent' => $job_data['brand']['accent_color'],
'dark_text' => false,
'overlay_opacity' => 0.7,
];
$job_data['focal_point'] = [
'x' => 540, 'y' => 450, 'x_percent' => 0.5,
'y_percent' => 0.3333, 'css_position' => '50% 33%',
];
}

$this->fill_missing_color_keys( $job_data );

do_action( Config::ACTION_BEFORE_RENDER, $job_data );

$source_w = ! empty( $job_data['source_width'] ) ? (int) $job_data['source_width'] : 0;
$source_h = ! empty( $job_data['source_height'] ) ? (int) $job_data['source_height'] : 0;

if ( $source_w > 0 && $source_h > 0 ) {
	$aspect_ratio = $source_h / $source_w;
	$job_data['width'] = 1080;
	if ( $aspect_ratio > 0.7 ) {
		$job_data['height'] = 1350;
	} else {
		$job_data['height'] = 1080;
	}
} else {
	$campaign = [];
	if ( ! empty( $job_data['post_id'] ) ) {
		$campaign = get_post_meta( $job_data['post_id'], Config::META_CAMPAIGN_DATA, true ) ?: [];
	}
	$platform_size = Config::get_campaign_value( $campaign, 'platform_size', Config::DEFAULT_SIZE );
	$dimensions = Config::get_platform_dimensions( $platform_size );

	$job_data['width'] = $dimensions['width'];
	$job_data['height'] = $dimensions['height'];
}

if ( ! isset( $job_data['image_zone'] ) ) {
	$job_data['image_zone'] = $campaign['image_zone'] ?? null;
}
if ( ! isset( $job_data['text_zone'] ) ) {
	$job_data['text_zone'] = $campaign['text_zone'] ?? null;
}
if ( ! isset( $job_data['logo_zone'] ) ) {
	$job_data['logo_zone'] = $campaign['logo_zone'] ?? null;
}

$template = $job_data['template'] ?? Config::DEFAULT_TEMPLATE;

// Try Chromium rendering first
$image_path = null;
$chromium_failed = false;
try {
$image_path = $this->render_html_template( $template, $job_data );
} catch ( \Exception $e ) {
$chromium_failed = true;
Logger::warning( 'chromium_render_failed', $job_data['job_id'] ?? 0, [
'error' => $e->getMessage(),
'fallback_to_pango' => true
], '500' );
}

// Normalize flag: null return (no exception) is still a failure
$chromium_failed = $chromium_failed || is_null( $image_path );

// Fallback to Pango if Chromium failed
if ( $chromium_failed || ! file_exists( $image_path ) ) {
Logger::info( 'chromium_fallback_to_pango', $job_data['job_id'] ?? 0, [
'chromium_failed' => $chromium_failed
], '200' );
$image_path = $this->render_pango( $job_data );
}

$execution_time = microtime( true ) - $start_time;

if ( ! $image_path || ! file_exists( $image_path ) ) {
Logger::error( Config::LOG_ACTION_RENDER_ERROR, $job_data['job_id'] ?? 0, $job_data, '500', 'Render produced no image', $execution_time );
throw new \Exception( 'Image rendering produced no output.' );
}

Logger::info( Config::LOG_ACTION_RENDER_SUCCESS, $job_data['job_id'] ?? 0, $job_data, '200', $image_path, $execution_time );

try {
$attachment_id = $this->sideload_image_to_media_library( $image_path, $job_data['post_id'] );
} finally {
if ( file_exists( $image_path ) ) {
@unlink( $image_path );
}
}

do_action( Config::ACTION_AFTER_RENDER, $job_data, $attachment_id );

return $attachment_id;
}

	private function fill_missing_color_keys( array &$job_data ) {
		$brand = $job_data['brand'] ?? Config::get_brand_settings();
		$colors = $job_data['colors'] ?? [];

		$defaults = [
			'primary'         => $brand['primary_color'] ?? Config::DEFAULT_BRAND_PRIMARY_COLOR,
			'secondary'       => $brand['secondary_color'] ?? Config::DEFAULT_BRAND_SECONDARY_COLOR,
			'accent'          => $brand['accent_color'] ?? Config::DEFAULT_BRAND_ACCENT_COLOR,
			'emphasis'        => $brand['emphasis_color'] ?? Config::DEFAULT_BRAND_EMPHASIS_COLOR,
			'key_term'        => $brand['key_term_color'] ?? Config::DEFAULT_BRAND_KEY_TERM_COLOR,
			'breaking'        => $brand['breaking_color'] ?? Config::DEFAULT_BRAND_BREAKING_COLOR,
			'text_backing'    => $brand['text_backing_color'] ?? Config::DEFAULT_BRAND_TEXT_BACKING_COLOR,
			'dark_text'       => false,
			'overlay_opacity' => 0.7,
		];

		foreach ( $defaults as $key => $default ) {
			if ( ! isset( $colors[ $key ] ) || $colors[ $key ] === '' ) {
				$colors[ $key ] = $default;
			}
		}

		$job_data['colors'] = $colors;
	}

	// ── HTML TEMPLATE RENDERING (Chromium/Puppeteer) ───────────────────────

	private function render_html_template( string $template, array $job_data ): ?string {
		$renderer = new HtmlTemplateRenderer();
		return $renderer->render( $template, $job_data );
	}

	// ── PANGO/GD PATH (legacy — kept for fallback) ─────────────────────────

	private function render_pango( array $job_data ) {
		if ( self::$pango_available === null ) {
			self::$pango_available = self::check_pango_available();
		}
		if ( ! self::$pango_available ) {
			return null;
		}

		$width = (int) ( $job_data['width'] ?? 1080 );
		$height = (int) ( $job_data['height'] ?? 1350 );
		$language = $job_data['language'] ?? 'en';
		$brand = $job_data['brand'] ?? Config::get_brand_settings();
		$colors = $job_data['colors'] ?? [];
		$focal = $job_data['focal_point'] ?? [];

		$primary_color = $colors['primary'] ?? Config::DEFAULT_BRAND_PRIMARY_COLOR;
		$accent_color = $colors['accent'] ?? Config::DEFAULT_BRAND_ACCENT_COLOR;
		$emphasis_color = $colors['emphasis'] ?? Config::DEFAULT_BRAND_EMPHASIS_COLOR;
		$secondary_color = $colors['secondary'] ?? Config::DEFAULT_BRAND_SECONDARY_COLOR;
		$text_backing_color = $colors['text_backing'] ?? Config::DEFAULT_BRAND_TEXT_BACKING_COLOR;
		$dark_text = $colors['dark_text'] ?? false;
		$overlay_opacity = floatval( $colors['overlay_opacity'] ?? 0.7 );
		$css_position = $focal['css_position'] ?? '50% 33%';

		$text_color = $dark_text ? '#1a1a1a' : '#ffffff';
		$headline = $job_data['headline'] ?? '';
		$hook = $job_data['hook'] ?? '';
		// REMOVED: Urdu hook clearing to ensure required description text is generated
		$image_url = $job_data['image_url'] ?? '';

		$headline_font = $brand['font_headline'] ?? Config::DEFAULT_BRAND_FONT_HEADLINE;
		$body_font = $brand['font_body'] ?? Config::DEFAULT_BRAND_FONT_BODY;

		$headline_font_path = $this->resolve_font_path( $headline_font );
		$body_font_path = $this->resolve_font_path( $body_font );

		$padding = (int) max( 24, min( $width * 0.055, $height * 0.055 ) );
		$base_short = min( $width, $height );
		$headline_char_count = mb_strlen( $headline, 'UTF-8' );
		$hook_char_count = mb_strlen( $hook, 'UTF-8' );
		$is_urdu = ( $language === 'ur' );

		$base_headline_size = HtmlTemplateRenderer::compute_adaptive_font_size( $headline_char_count, $is_urdu, 'headline' );
		$base_hook_size = HtmlTemplateRenderer::compute_adaptive_font_size( $hook_char_count, $is_urdu, 'hook' );

		$scale_factor = $width / 1080.0;
		$headline_size = (int) round( $base_headline_size * $scale_factor );
		$hook_size = (int) round( $base_hook_size * $scale_factor );
		$headline_max_w = $width - ( $padding * 2 );
		$hook_max_w = $width - ( $padding * 2 );

		$headline_png = $this->pango_render( $headline, $headline_font, $headline_font_path, $headline_size, $emphasis_color, $headline_max_w, $language );
		$hook_png = $this->pango_render( $hook, $body_font, $body_font_path, $hook_size, $secondary_color, $hook_max_w, $language );

		$compositor = new ImageMagickCompositor();
		$template = $job_data['template'] ?? Config::DEFAULT_TEMPLATE;
		$output_path = $compositor->render($template, $job_data, $headline_png, $hook_png);

		if ($headline_png) imagedestroy($headline_png);
		if ($hook_png) imagedestroy($hook_png);

		return $output_path;
	}

	private function ensure_fontconfig() {
		$fonts_dir = AI_SOCIAL_COLLAGE_PATH . 'assets/fonts';
		$fc_file = $fonts_dir . '/fonts.conf';
		$abs = realpath( $fonts_dir );
		if ( ! $abs ) return '';

		$expected_dir = str_replace( '\\', '/', $abs );

		if ( file_exists( $fc_file ) ) {
			$existing = file_get_contents( $fc_file );
			if ( $existing !== false && strpos( $existing, $expected_dir ) !== false ) {
				return $fc_file;
			}
		}

		$xml = '<?xml version="1.0"?>' . "\n"
			. '<!DOCTYPE fontconfig SYSTEM "fonts.dtd">' . "\n"
			. '<fontconfig>' . "\n"
			. '  <dir>' . htmlspecialchars( $abs, ENT_XML1 ) . '</dir>' . "\n"
			. '</fontconfig>';
		if ( file_put_contents( $fc_file, $xml ) ) {
			return $fc_file;
		}
		return '';
	}

	private function pango_render( $text, $font_family, $font_path, $font_size, $fill_color, $max_width, $language ) {
		if ( empty( $text ) || trim( $text ) === '' ) {
			return null;
		}

		$pango_size = $font_size * 1024;
		$escaped_text = htmlspecialchars( $text, ENT_XML1 | ENT_QUOTES, 'UTF-8' );
		$escaped_font_family = htmlspecialchars( $font_family, ENT_XML1 | ENT_QUOTES, 'UTF-8' );
		$escaped_color = htmlspecialchars( $fill_color, ENT_XML1 | ENT_QUOTES, 'UTF-8' );

		$fc_file = $this->ensure_fontconfig();
		$old_fc = getenv( 'FONTCONFIG_FILE' );
		if ( $fc_file ) {
			putenv( 'FONTCONFIG_FILE=' . $fc_file );
		}

		$markup = sprintf(
			'<span font_family="%s" size="%d" foreground="%s">%s</span>',
			$escaped_font_family,
			$pango_size,
			$escaped_color,
			$escaped_text
		);

		$tmp_dir = AI_SOCIAL_COLLAGE_PATH . 'assets/temp';
		if ( ! is_dir( $tmp_dir ) ) {
			wp_mkdir_p( $tmp_dir );
		}

		$tmp_markup = $tmp_dir . '/pango-markup_' . uniqid() . '.tmp';
		if ( ! file_put_contents( $tmp_markup, $markup ) ) {
			@unlink( $tmp_markup );
			if ( $old_fc !== false ) putenv( 'FONTCONFIG_FILE=' . $old_fc );
			return null;
		}

		$tmp_png = $tmp_dir . '/pango-output_' . uniqid() . '.tmp.png';

		putenv( 'MAGICK_TEMPORARY_PATH=' . $tmp_dir );

		$rtl_define = $language === 'ur' ? ' -define pango:direction=rtl' : '';

		$cmd = sprintf(
			'%s -background none -alpha on%s -size %dx pango:@%s PNG32:%s',
			escapeshellarg( Config::IM_CONVERT_PATH ),
			$rtl_define,
			$max_width,
			escapeshellarg( $tmp_markup ),
			escapeshellarg( $tmp_png )
		);

		@exec( $cmd . ' 2>&1', $out, $ret );

		@unlink( $tmp_markup );
		if ( $old_fc !== false ) putenv( 'FONTCONFIG_FILE=' . $old_fc );

    if ( $ret === 0 && file_exists( $tmp_png ) && filesize( $tmp_png ) >= 50 ) {
        $png = @imagecreatefrompng( $tmp_png );
        @unlink( $tmp_png );
        if ( $png ) {
            return $png;
        }
    }

    @unlink( $tmp_png );

    return $this->gd_text_fallback( $text, $font_path, $font_size, $fill_color, $max_width, $language );
}

	private function gd_text_fallback( $text, $font_path, $font_size, $fill_color, $max_width, $language ) {
		if ( ! file_exists( $font_path ) || ! function_exists( 'imagettftext' ) ) {
			return null;
		}

		$lines = $this->wrap_text_gd( $text, $font_path, $font_size, $max_width );
		$is_urdu = ( $language === 'ur' || stripos( $font_path, 'nastaliq' ) !== false );
		$multiplier = $is_urdu ? 2.0 : 1.5;
		$line_height = (int) ( $font_size * $multiplier );
		$ascender_pad = $is_urdu ? (int) ( $font_size * 0.5 ) : 5;
		$total_height = count( $lines ) * $line_height + $ascender_pad + 10;

		$img = imagecreatetruecolor( $max_width, $total_height );
		imagesavealpha( $img, true );
		imagealphablending( $img, true );
		$transparent = imagecolorallocatealpha( $img, 0, 0, 0, 127 );
		imagefill( $img, 0, 0, $transparent );

		$rgb = $this->hex_to_rgb( $fill_color );
		$text_alloc = imagecolorallocate( $img, $rgb['r'], $rgb['g'], $rgb['b'] );

		$y = $font_size + $ascender_pad;
		foreach ( $lines as $line ) {
			imagettftext( $img, $font_size, 0, 5, $y, $text_alloc, $font_path, $line );
			$y += $line_height;
		}

		return $img;
	}

	private function wrap_text_gd( $text, $font_path, $font_size, $max_width ) {
		$words = preg_split( '/\s+/u', $text, -1, PREG_SPLIT_NO_EMPTY );
		$lines = [];
		$current = '';

		foreach ( $words as $word ) {
			$test = $current === '' ? $word : $current . ' ' . $word;
			$bbox = imagettfbbox( $font_size, 0, $font_path, $test );
			$w = $bbox[2] - $bbox[0];
			if ( $w > $max_width && $current !== '' ) {
				$lines[] = $current;
				$current = $word;
			} else {
				$current = $test;
			}
		}
		if ( $current !== '' ) {
			$lines[] = $current;
		}

		return $lines ?: [ $text ];
	}

	private function draw_featured_image( $canvas, $image_url, $width, $height, $css_position, $overlay_opacity, $overlay_color ) {
		$image_path = $this->resolve_local_image( $image_url );
		if ( ! $image_path || ! file_exists( $image_path ) ) {
			return false;
		}

		$src = @imagecreatefromjpeg( $image_path );
		if ( ! $src ) {
			$src = @imagecreatefrompng( $image_path );
		}
		if ( ! $src ) {
			return false;
		}

		$src_w = imagesx( $src );
		$src_h = imagesy( $src );
		if ( $src_w === 0 || $src_h === 0 ) {
			imagedestroy( $src );
			return false;
		}

		$scale = max( $width / $src_w, $height / $src_h );
		$scaled_w = (int) ( $src_w * $scale );
		$scaled_h = (int) ( $src_h * $scale );

		$pos = explode( ' ', $css_position );
		$x_pct = isset( $pos[0] ) ? (float) rtrim( $pos[0], '%' ) / 100 : 0.5;
		$y_pct = isset( $pos[1] ) ? (float) rtrim( $pos[1], '%' ) / 100 : 0.33;

		$dst_x = (int) ( $width / 2 - $scaled_w * $x_pct );
		$dst_y = (int) ( $height / 2 - $scaled_h * $y_pct );

		imagecopyresampled( $canvas, $src, $dst_x, $dst_y, 0, 0, $scaled_w, $scaled_h, $src_w, $src_h );
		imagedestroy( $src );

		return true;
	}

	private function draw_gradient_overlay( $canvas, $width, $height, $overlay_top, $overlay_color_hex, $opacity ) {
		$rgb = $this->hex_to_rgb( $overlay_color_hex );
		$overlay_h = $height - $overlay_top;
		$steps = min( $overlay_h, 100 );

		for ( $i = 0; $i < $steps; $i++ ) {
			$ratio = $i / $steps;
			$alpha = (int) ( 127 * ( 1 - ( $ratio * $opacity ) ) );
			$y = $overlay_top + (int) ( $ratio * $overlay_h );
			$bar_h = max( 1, (int) ( $overlay_h / $steps ) + 1 );
			$color = imagecolorallocatealpha( $canvas, $rgb['r'], $rgb['g'], $rgb['b'], $alpha );
			imagefilledrectangle( $canvas, 0, $y, $width, $y + $bar_h, $color );
		}
	}

	private function draw_brand_bar( $canvas, $brand, $width, $height, $padding, $text_color, $accent_color, $language ) {
		$brand_name = $brand['brand_name'] ?? '';
		$brand_url = $brand['brand_url'] ?? '';
		$logo_url = $brand['logo_url'] ?? '';
		$logo_position = $brand['logo_position'] ?? Config::DEFAULT_BRAND_LOGO_POSITION;

		$bar_height_pct = floatval( $brand['brand_bar_height_pct'] ?? Config::DEFAULT_BRAND_BAR_HEIGHT_PCT );
		$bar_h = max( 1, (int) round( $height * $bar_height_pct / 100 ) );
		$bar_y = $height - $bar_h;

		$bg_css = ! empty( $brand['brand_bar_bg_color'] ) ? $brand['brand_bar_bg_color'] : Config::DEFAULT_BRAND_BAR_BG_COLOR;
		if ( preg_match( '/^rgba\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*([\d.]+)\s*\)$/i', $bg_css, $m ) ) {
			$bg_rgb = [ 'r' => (int) $m[1], 'g' => (int) $m[2], 'b' => (int) $m[3] ];
			$bg_alpha = (int) round( ( 1 - (float) $m[4] ) * 127 );
		} else {
			$bg_rgb = $this->hex_to_rgb( $bg_css );
			$bg_alpha = 120;
		}
		$bar_bg = imagecolorallocatealpha( $canvas, $bg_rgb['r'], $bg_rgb['g'], $bg_rgb['b'], $bg_alpha );
		imagefilledrectangle( $canvas, 0, $bar_y, $width, $height, $bar_bg );

		$show_accent = ( isset( $brand['brand_bar_accent_line'] ) && $brand['brand_bar_accent_line'] === '1' );
		if ( $show_accent ) {
			$line_rgb = $this->hex_to_rgb( $accent_color );
			$line_alloc = imagecolorallocatealpha( $canvas, $line_rgb['r'], $line_rgb['g'], $line_rgb['b'], 60 );
			imagefilledrectangle( $canvas, 0, $bar_y, $width, $bar_y + 1, $line_alloc );
		}

		$font_size = intval( $brand['brand_bar_font_size'] ?? Config::DEFAULT_BRAND_BAR_FONT_SIZE );
		$font_path = $this->resolve_font_path( $language === 'ur' ? 'Noto Nastaliq Urdu' : 'Inter' );
		if ( $font_path && file_exists( $font_path ) ) {
			$rgb = $this->hex_to_rgb( $text_color );
			$brand_alloc = imagecolorallocatealpha( $canvas, $rgb['r'], $rgb['g'], $rgb['b'], 80 );
			imagettftext( $canvas, $font_size, 0, $padding, $bar_y + (int) ( $bar_h / 2 ) + (int) ( $font_size / 3 ), $brand_alloc, $font_path, $brand_name );
		}
	}

	private function composite_png( $canvas, $png, $x, $y ) {
		imagealphablending( $canvas, true );
		imagesavealpha( $canvas, true );
		imagecopy( $canvas, $png, $x, $y, 0, 0, imagesx( $png ), imagesy( $png ) );
	}

	private function png_height( $png ) {
		return imagesy( $png );
	}

	private function resolve_font_path( $font_family ) {
		$map = [
			'Noto Nastaliq Urdu' => 'NotoNastaliqUrdu-Regular.ttf',
			'Noto Nastaliq Urdu Medium' => 'NotoNastaliqUrdu-Medium.ttf',
			'Jameel Noori Nastaliq' => 'JameelNooriNastaliq.ttf',
			'Nafees Web Naskh' => 'NafeesWebNaskh.ttf',
			'Noto Sans Arabic' => 'NotoSansArabic-Regular.ttf',
		];
		$file = $map[ $font_family ] ?? '';
		if ( $file === '' ) {
			return '';
		}
		$path = AI_SOCIAL_COLLAGE_PATH . 'assets/fonts/' . $file;
		if ( file_exists( $path ) ) {
			return $path;
		}
		Logger::warning( 'font_file_missing', null, [ 'font' => $font_family, 'path' => $path ], '200' );
		$system_fallbacks = [
			'/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
			'/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf',
		];
		foreach ( $system_fallbacks as $fb ) {
			if ( file_exists( $fb ) ) return $fb;
		}
		return '';
	}

	private function resolve_local_image( $url ) {
		$upload_dir = wp_upload_dir();
		if ( strpos( $url, $upload_dir['baseurl'] ) === 0 ) {
			return str_replace( $upload_dir['baseurl'], $upload_dir['basedir'], $url );
		}
		$attachment_id = attachment_url_to_postid( $url );
		if ( $attachment_id ) {
			$path = get_attached_file( $attachment_id );
			if ( $path && file_exists( $path ) ) {
				return $path;
			}
		}
		return null;
	}

	private function hex_to_rgb( $hex ) {
		$hex = ltrim( $hex, '#' );
		if ( strlen( $hex ) !== 6 || ! ctype_xdigit( $hex ) ) {
			return [ 'r' => 0, 'g' => 0, 'b' => 0 ];
		}
		return [
			'r' => hexdec( substr( $hex, 0, 2 ) ),
			'g' => hexdec( substr( $hex, 2, 2 ) ),
			'b' => hexdec( substr( $hex, 4, 2 ) ),
		];
	}

    private static function check_pango_available() {
        if ( ! function_exists( 'exec' ) ) {
            return false;
        }
        $disabled = explode( ',', ini_get( 'disable_functions' ) );
        if ( in_array( 'exec', array_map( 'trim', $disabled ), true ) ) {
            return false;
        }
        if ( file_exists( Config::IM_CONVERT_PATH ) ) {
            return true;
        }
        @exec( 'which convert 2>/dev/null', $output, $ret );
        if ( $ret === 0 && ! empty( $output ) && file_exists( trim( $output[0] ) ) ) {
            return true;
        }
        return false;
    }

	private function sideload_image_to_media_library( $file_path, $post_id ) {
		if ( ! function_exists( 'media_handle_sideload' ) ) {
			require_once( ABSPATH . 'wp-admin/includes/media.php' );
			require_once( ABSPATH . 'wp-admin/includes/file.php' );
			require_once( ABSPATH . 'wp-admin/includes/image.php' );
		}

		$file_array = [
			'name' => basename( $file_path ),
			'tmp_name' => $file_path
		];

		$attachment_id = media_handle_sideload( $file_array, $post_id );

		if ( is_wp_error( $attachment_id ) ) {
			throw new \Exception( 'Failed to attach image to Media Library: ' . $attachment_id->get_error_message() );
		}

		update_post_meta( $attachment_id, Config::META_IS_AI_COLLAGE, '1' );

		return $attachment_id;
	}
}
