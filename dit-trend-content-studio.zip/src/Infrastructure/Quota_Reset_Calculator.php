<?php

/**
 * Quota Reset Calculator
 *
 * Provider-specific quota reset helpers.
 *
 * Gemini API Requests-per-day (RPD) quotas reset at midnight Pacific time.
 * Ref: https://ai.google.dev/gemini-api/docs/rate-limits
 *
 * @package DIT_TrendStudio
 * @since 2.15.18
 * @MODIFIED 2026-02-26 - Added Gemini RPD reset calculator (midnight PT).
 */

namespace DIT\TrendStudio\Infrastructure;

if (!defined('ABSPATH')) {
    exit;
}

class Quota_Reset_Calculator
{
    /**
     * Compute the next Gemini RPD reset timestamp (midnight Pacific).
     *
     * @param int $now_ts Unix timestamp (defaults to now).
     * @return int Unix timestamp of the next reset moment.
     */
    public static function gemini_next_rpd_reset_ts(int $now_ts = 0): int
    {
        $now_ts = ($now_ts > 0) ? $now_ts : time();

        try {
            $pt = new \DateTimeZone('America/Los_Angeles');
            $now = (new \DateTimeImmutable('@' . $now_ts))->setTimezone($pt);
            $next = $now->modify('tomorrow')->setTime(0, 0, 0);
            return (int) $next->getTimestamp();
        } catch (\Throwable $e) {
            // Conservative fallback: 12h ahead (forces probe/backoff to recover).
            return (int) ($now_ts + 12 * 3600);
        }
    }

    /**
     * Format a timestamp in the site's timezone.
     *
     * @param int $ts
     * @return string
     */
    public static function format_in_wp_tz(int $ts): string
    {
        if ($ts <= 0) {
            return '';
        }

        try {
            $tz = function_exists('wp_timezone') ? wp_timezone() : new \DateTimeZone('UTC');
            $dt = (new \DateTimeImmutable('@' . $ts))->setTimezone($tz);
            return (string) $dt->format('Y-m-d H:i:s T');
        } catch (\Throwable $e) {
            return (string) gmdate('Y-m-d H:i:s', $ts) . ' UTC';
        }
    }

    /**
     * Format a timestamp in an arbitrary timezone.
     *
     * @param int    $ts
     * @param string $tz_string IANA timezone id (e.g. America/Los_Angeles).
     * @return string
     *
     * @since 2.15.21
     * @MODIFIED 2026-02-27 - Support displaying Gemini reset/retry in PT + local.
     */
    public static function format_in_tz(int $ts, string $tz_string): string
    {
        if ($ts <= 0 || $tz_string === '') {
            return '';
        }

        try {
            $tz = new \DateTimeZone($tz_string);
            $dt = (new \DateTimeImmutable('@' . $ts))->setTimezone($tz);
            return (string) $dt->format('Y-m-d H:i:s T');
        } catch (\Throwable $e) {
            return self::format_in_wp_tz($ts);
        }
    }
}
