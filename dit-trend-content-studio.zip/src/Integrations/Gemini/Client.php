<?php

/**
 * AI Client
 *
 * @package DIT_TrendStudio
 * @MODIFIED 2025-12-13 - Forked from SEO Article Generator, new prompt for magazine content
 * @MODIFIED 2025-12-13 - Removed unused $provider parameter (class is Gemini-specific)
 * @MODIFIED 2025-12-13 - Added generate_from_research() for Perplexity integration
 */

namespace DIT\TrendStudio\Integrations\Gemini;

use DIT\TrendStudio\AI_Exception;
use DIT\TrendStudio\Infrastructure\Logger;
use DIT\TrendStudio\Infrastructure\API_Error_Parser;
use DIT\TrendStudio\Infrastructure\Quota_State_Manager;
use DIT\TrendStudio\Infrastructure\Quota_Pause_Manager;
use DIT\TrendStudio\Infrastructure\Backoff_Strategy;
use DIT\TrendStudio\Security\Sanitizer;
use DIT\TrendStudio\Contracts\AIProviderInterface;
use DIT\TrendStudio\Content\PromptSchemaBuilder;
use DIT\TrendStudio\Content\VisualManifestService;
use DIT\TrendStudio\AI\StructuredOutputSchema;
use DIT\TrendStudio\Infrastructure\AI_Network_Trait;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * AI API client for Gemini integration
 */
class Client implements AIProviderInterface
{
    use AI_Network_Trait {
        check_circuit_breaker as protected trait_check_circuit_breaker;
        record_circuit_success as protected trait_record_circuit_success;
        record_circuit_failure as protected trait_record_circuit_failure;
    }

    /**
     * API key
     *
     * @var string
     */
    private bool $is_retry_attempt = false;
    private $api_key;

    /**
     * Logger instance
     *
     * @var Logger
     */
    private $logger;

    /**
     * Provider-agnostic prompt/schema builder
     * @var PromptSchemaBuilder
     */
    private $promptSchema;

    /**
     * Deterministic visuals token service
     * @var VisualManifestService
     */
    private $visuals;

    /**
     * Increment Gemini API call count.
     * @deprecated 2.5.0 Use Usage_Tracker::increment('gemini')
     */
    private static function increment_call_count()
    {
        \DIT\TrendStudio\Infrastructure\Usage_Tracker::increment('gemini');
    }

    /**
     * Retrieve the total Gemini API call count.
     *
     * @return int
     */
    public static function get_call_count(): int
    {
        $stats = \DIT\TrendStudio\Infrastructure\Usage_Tracker::get_stats('gemini');
        return $stats['total'];
    }

    /**
     * Retrieve today's Gemini API call count.
     *
     * @return int
     */
    public static function get_daily_call_count(): int
    {
        $stats = \DIT\TrendStudio\Infrastructure\Usage_Tracker::get_stats('gemini');
        return $stats['today'];
    }

    // @MODIFIED 2026-02-09 - Removed hardcoded GEMINI_API_URL and GEMINI_IMAGE_API_URL constants
    // Model selection is now dynamic via get_model_id() and get_image_model_id()

    /**
     * Get dynamic Gemini Model ID from settings
     * @since 2.2.0
     * @MODIFIED 2026-02-10 - Added custom model ID override
     */
    public static function get_model_id()
    {
        $custom_id = get_option('dit_ts_gemini_model_custom', '');
        if (!empty($custom_id)) {
            return $custom_id;
        }
        return get_option('dit_ts_gemini_model', 'gemini-2.0-flash');
    }

    /**
     * Get dynamic Gemini API Version from settings
     * @since 2.5.0
     */
    public static function get_api_version()
    {
        return get_option('dit_ts_gemini_api_version', 'v1beta');
    }

    /**
     * Get dynamic Gemini Image Model ID from settings
     * @since 2.2.0
     */
    public static function get_image_model_id()
    {
        // Fallback to flash if not set
        return get_option('dit_ts_gemini_image_model', 'gemini-2.0-flash');
    }

    /**
     * Get Gemini API key from multiple sources
     *
     * @return string API key or empty string
     */
    public static function get_gemini_key()
    {
        // Try plugin option first
        $key = get_option('dit_ts_gemini_api_key', '');
        if (!empty($key)) {
            return $key;
        }

        // Try environment variable
        $env_key = getenv('GEMINI_API_KEY');
        if (!empty($env_key)) {
            return $env_key;
        }

        // Try wp-config constant
        if (\defined('GEMINI_API_KEY')) {
            return \GEMINI_API_KEY;
        }

        return '';
    }

    /**
     * Constructor
     *
     * @param string $api_key API key
     * @param Logger $logger  Logger instance
     */
    public function __construct($api_key, Logger $logger)
    {
        $this->api_key       = $api_key;
        $this->logger        = $logger;
        $this->provider_slug = 'gemini'; // @MODIFIED 2026-02-14 - Identify for global retries

        $this->promptSchema = new PromptSchemaBuilder($logger);
        $this->visuals      = new VisualManifestService();
    }

    /**
     * Get the name of the model being used by this provider.
     *
     * @return string
     */
    public function get_model(): string
    {
        return self::get_model_id();
    }

    /**
     * Generate article using AI
     *
     * @param array $prompt_data Structured prompt data
     * @return array AI response data
     * @throws AI_Exception If API call fails
     */
    public function generate_article($prompt_data)
    {
        return $this->call_gemini_api($prompt_data);
    }

    /**
     * Generate article from structured prompt data (interface alias).
     *
     * This method proxies to generate_article() for backward compatibility.
     *
     * @param array $promptData Structured prompt data.
     * @return array AI response data.
     */
	public function generate(array $promptData): array
	{
		return $this->generate_article($promptData);
	}

    /**
     * Generate generic JSON from a custom prompt (Utility Method)
     * @since 1.8.0 - Enables Gap Analyzer and other utility agents
     *
     * @param string $prompt The full prompt text
     * @return array Parsed JSON response
     * @throws AI_Exception If API call fails
     */
    public function generate_custom_json(string $prompt): array
    {
        $this->logger->info('Calling Gemini API for custom JSON generation');

        $body = [
            'contents' => [
                ['parts' => [['text' => $prompt]]]
            ],
            'generationConfig' => [
                'temperature' => 0.4, // Lower temperature for analytical tasks
                'topP' => 0.9,
                'topK' => 40,
                'maxOutputTokens' => 65536,
                'responseMimeType' => 'application/json',
                'thinkingConfig'  => array('thinkingBudget' => 0),
            ],
            'safetySettings' => [
                ['category' => 'HARM_CATEGORY_HARASSMENT', 'threshold' => 'BLOCK_ONLY_HIGH'],
                ['category' => 'HARM_CATEGORY_HATE_SPEECH', 'threshold' => 'BLOCK_ONLY_HIGH'],
                ['category' => 'HARM_CATEGORY_SEXUALLY_EXPLICIT', 'threshold' => 'BLOCK_ONLY_HIGH'],
                ['category' => 'HARM_CATEGORY_DANGEROUS_CONTENT', 'threshold' => 'BLOCK_ONLY_HIGH'],
            ],
        ];

        $model_id = self::get_model_id();
        $api_version = self::get_api_version();
        $url = "https://generativelanguage.googleapis.com/{$api_version}/models/{$model_id}:generateContent?key=" . $this->api_key;
        $request_body = wp_json_encode($body);

        $attempt = 0;
        $code    = 0;
        $body    = '';

        while ($attempt < 3) {
            $attempt++;

            $response = $this->call_api_with_retry($url, [
                'headers' => ['Content-Type' => 'application/json'],
                'body'    => $request_body,
            ]);

            if (is_wp_error($response)) {
                // Error already logged by trait
                throw new AI_Exception('Gemini custom JSON failed: ' . $response->get_error_message());
            }

            $code = (int) wp_remote_retrieve_response_code($response);
            $body = (string) wp_remote_retrieve_body($response);

            // @MODIFIED 2026-02-18: Handle 404 Deprecation & 429 "Limit 0" Fallback
            $is_404_not_found = ($code === 404 && (strpos($body, 'models/') !== false || strpos($body, 'NOT_FOUND') !== false));
            $is_429_limit_zero = ($code === 429 && strpos($body, 'limit: 0') !== false);

            if (!$this->is_retry_attempt && ($is_404_not_found || $is_429_limit_zero)) {
                $reason = $is_404_not_found ? "Model Not Found (404)" : "Quota Limit Zero (429)";
                $this->logger->warning("Gemini {$reason} detected in custom JSON. Switching to fallback model 'gemini-2.0-flash' and retrying.", [
                    'original_model' => $model_id,
                    'error_body' => substr($body, 0, 300)
                ]);

                // Force switch model and update settings
                update_option('dit_ts_gemini_model_custom', '');
                update_option('dit_ts_gemini_model', 'gemini-2.0-flash');
                $model_id = 'gemini-2.0-flash';
                $this->is_retry_attempt = true;

                // Re-calculate URL with new model
                $api_version = self::get_api_version();
                $url = "https://generativelanguage.googleapis.com/{$api_version}/models/{$model_id}:generateContent?key=" . rawurlencode((string) $this->api_key);

                continue;
            }

            if ($code === 200) {
                break;
            }

            $this->logger->error('Gemini API error', ['code' => $code, 'body' => $body]);
            throw new AI_Exception("API returned {$code}: " . substr($body, 0, 500));
        }

        $data = json_decode($body, true);
        $text = $data['candidates'][0]['content']['parts'][0]['text'] ?? '';
        $finish_reason = $data['candidates'][0]['finishReason'] ?? '';

        if (empty($text)) {
            throw new AI_Exception('Empty response from API');
        }

        try {
            $parsed_data = $this->parse_json_response($text, '', '', $finish_reason);
        } catch (AI_Exception $e) {
            // Check if truncation or parse error, try regeneration
            if (strpos($e->getMessage(), 'Incomplete AI response') !== false || strpos($e->getMessage(), 'Failed to parse AI response') !== false) {
                $this->logger->warning('Initial parsing failed for custom JSON, attempting strict regeneration', ['error' => $e->getMessage()]);

                try {
                    $new_text = $this->regenerateAsStrictJson($body);
                    $parsed_data = $this->parse_json_response($new_text);
                } catch (\Exception $retry_e) {
                    throw $e;
                }
            } else {
                throw $e;
            }
        }

        // Return rich object with debug data
        return [
            'data' => $parsed_data,
            'raw_request' => $request_body,
            'raw_response' => $body
        ];
    }

    /**
     * Generate custom JSON from a prompt (interface alias).
     *
     * @param string $prompt
     * @return array
     */
    public function generateCustomJson(string $prompt): array
    {
        $result = $this->generate_custom_json($prompt);
        // Only count on actual success — errors (503, 429, etc.) don't increment the counter.
        \DIT\TrendStudio\Infrastructure\Usage_Tracker::increment('gemini');
        return $result;
    }

    /**
     * Generate an editorial image using Gemini 3 Pro (Multimodal).
     * @since 1.7.0
     * @MODIFIED 2026-01-26 - Switched to Gemini 3 generateContent endpoint (Option A)
     *
     * @param string $prompt The image generation prompt.
     * @param string $aspect_ratio Optional. Default '16:9'.
     * @return string|bool Binary image data on success, false on failure.
     * @throws AI_Exception If API call fails.
     */
    public function generate_image(string $prompt, string $aspect_ratio = '16:9')
    {
        $this->logger->info('Calling Gemini Image API (Gemini 3 Pro)', ['prompt' => $prompt]);

        // Construct Gemini 3 Multimodal Payload
        $body = [
            'contents' => [
                ['parts' => [['text' => $prompt]]]
            ],
            'generationConfig' => [
                'response_modalities' => ['IMAGE'],
                'speechConfig' => ['voiceConfig' => ['prebuiltVoiceConfig' => ['voiceName' => 'Puck']]] // Required dummy field for some reason in early previews, safe to omit usually but checking docs
            ]
        ];

        // Simplified generationConfig for standard Gemini 3 image request
        $body['generationConfig'] = [
            'response_modalities' => ['IMAGE'],
            // Aspect ratio logic would go here if supported by generationConfig, 
            // but Gemini 3 usually infers from prompt or needs specific param structure.
            // For now, sticking to basic prompt-based generation.
        ];

        // Append Aspect Ratio instruction to prompt since Gemini 3 is multimodal
        $enhanced_prompt = $prompt . " Aspect Ratio: " . $aspect_ratio;
        $body['contents'][0]['parts'][0]['text'] = $enhanced_prompt;


        $api_version = self::get_api_version();
        $url = "https://generativelanguage.googleapis.com/{$api_version}/models/" . self::get_image_model_id() . ":generateContent?key=" . $this->api_key;

        // @MODIFIED 2026-02-14 - Use global retry trait
        $response = $this->call_api_with_retry($url, [
            'headers' => [
                'Content-Type' => 'application/json',
            ],
            'body' => json_encode($body)
        ]);

        if (is_wp_error($response)) {
            throw new AI_Exception("Gemini Image API Error: " . $response->get_error_message());
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);

        if ($code !== 200) {
            $this->logger->error('Gemini Image API error', ['code' => $code, 'body' => $body]);
            throw new AI_Exception("Image API returned {$code}: " . substr($body, 0, 500));
        }

        $data = json_decode($body, true);

        // Parse Gemini 3 Image Response (Inline Base64)
        // Structure: candidates[0].content.parts[0].inlineData.data
        $image_base64 = '';
        if (isset($data['candidates'][0]['content']['parts'])) {
            foreach ($data['candidates'][0]['content']['parts'] as $part) {
                if (isset($part['inlineData']['mimeType']) && strpos($part['inlineData']['mimeType'], 'image') !== false) {
                    $image_base64 = $part['inlineData']['data'];
                    break;
                }
            }
        }

        if (empty($image_base64)) {
            $this->logger->warning('No image data found in Gemini response', ['response_keys' => array_keys($data)]);
            return false;
        }

        return base64_decode($image_base64);
    }

    /**
     * Generate content from research data (interface alias).
     *
     * This proxies to the provider-specific generate_from_research() method.
     *
     * @param array $promptData
     * @param array $researchData
     * @return array
     */
	public function generateFromResearch(array $promptData, array $researchData): array
	{
		return $this->generate_from_research($promptData, $researchData);
	}

    /**
     * Generate article from pre-researched data (no grounding needed)
     *
     * @MODIFIED 2025-12-13 - Added for Perplexity integration
     *
     * @param array $prompt_data   Prompt data with idea_title, idea_text, etc.
     * @param array $research_data Research data from Perplexity with research_content and sources
     * @return array Generated article data
     * @throws AI_Exception If API call fails
     */
    public function generate_from_research(array $prompt_data, array $research_data): array
    {
        $visual_manifest = $prompt_data['source_visual_map'] ?? []; // @MODIFIED 2026-02-15 - Use global map if available
        $output_schema   = '';

        // If manifest already provided, don't let visuals service re-scan (which would fail on tokenized text)
        $service = empty($visual_manifest) ? $this->visuals : null;

        $bundle = $this->promptSchema->build_writing_bundle(
            $prompt_data,
            $research_data,
            $visual_manifest,
            $output_schema,
            $service,
            10
        );

        $this->logger->info('Calling Gemini API for writing from research');

        return $this->call_gemini_api_unified($bundle, $visual_manifest);
    }

    /**
     * Call Gemini API
     * Unified Gemini API Caller
     */
    private function call_gemini_api_unified(array $bundle, array $visual_manifest): array
    {
        $prompt        = (string) ($bundle['user_prompt'] ?? '');
        $system_prompt = (string) ($bundle['system_prompt'] ?? '');
        $output_schema = (string) ($bundle['output_schema'] ?? '');

        if (empty($this->api_key)) {
            throw new AI_Exception('Gemini API key is missing.');
        }

        $model_id    = self::get_model_id();
        $api_version = self::get_api_version();
        $url = "https://generativelanguage.googleapis.com/{$api_version}/models/{$model_id}:generateContent?key=" . \rawurlencode((string) $this->api_key);

        $max_tokens = 65536;

        $body = array(
            'contents' => array(
                array(
                    'role'  => 'user',
                    'parts' => array(array('text' => $prompt)),
                ),
            ),
            'generationConfig' => array(
                'temperature'     => 0.7,
                'topP'            => 0.9,
                'topK'            => 40,
                'maxOutputTokens' => $max_tokens,
                // @FIXED 2026-07-04 - Disable thinking to prevent output token budget theft.
                // Gemini 2.5 Flash defaults to dynamic thinking which consumes up to 24K tokens
                // from maxOutputTokens, leaving only ~8K for actual JSON output → truncation.
                // See: https://github.com/googleapis/python-genai/issues/782
                'thinkingConfig'  => array('thinkingBudget' => 0),
            ),
            'safetySettings' => array(
                array('category' => 'HARM_CATEGORY_HARASSMENT', 'threshold' => 'BLOCK_ONLY_HIGH'),
                array('category' => 'HARM_CATEGORY_HATE_SPEECH', 'threshold' => 'BLOCK_ONLY_HIGH'),
                array('category' => 'HARM_CATEGORY_SEXUALLY_EXPLICIT', 'threshold' => 'BLOCK_ONLY_HIGH'),
                array('category' => 'HARM_CATEGORY_DANGEROUS_CONTENT', 'threshold' => 'BLOCK_ONLY_HIGH'),
            ),
        );

        // Inject System Instruction if supported (v1beta/v1)
        if (!empty($system_prompt)) {
            $body['system_instruction'] = array(
                'parts' => array(
                    array('text' => $system_prompt)
                )
            );
        }

        // Provider-side schema enforcement (optional)
        $enforce = (bool) \get_option('dit_ts_ai_enforce_structured_output', true);
        if ($enforce && $output_schema !== '') {
            $mode = \DIT\TrendStudio\AI\StructuredOutputSchema::detect_mode_from_output_schema($output_schema);
            $body['generationConfig']['responseSchema']   = \DIT\TrendStudio\AI\StructuredOutputSchema::gemini_article_schema($mode);
            $body['generationConfig']['responseMimeType'] = 'application/json';
        }

        // Search grounding (optional)
        // @MODIFIED 2026-02-22 - Skip tools when responseMimeType is 'application/json' (Gemini rejects this combo with 400)
        // This was causing every API call to fail once and retry without tools, wasting half the quota budget.
        $enable_grounding = (bool) \get_option('dit_ts_gemini_enable_grounding', true);
        $has_json_mode    = !empty($body['generationConfig']['responseMimeType'])
            && $body['generationConfig']['responseMimeType'] === 'application/json';
        if ($enable_grounding && !$has_json_mode) {
            $body['tools'] = array(
                array('googleSearch' => new \stdClass()),
            );
        }

        // Schema/tools fallback (only relevant when BOTH are present)
        $fallback_mode = (string) \get_option('dit_ts_gemini_schema_tools_fallback', 'drop_tools'); // drop_tools | drop_schema
        if ($fallback_mode !== 'drop_tools' && $fallback_mode !== 'drop_schema') {
            $fallback_mode = 'drop_tools';
        }

        $attempt = 0;
        $code = 0;
        $body_response = '';

        while ($attempt < 3) {
            $attempt++;

            $response = $this->call_api_with_retry($url, array(
                'headers' => array('Content-Type' => 'application/json'),
                'body' => \wp_json_encode($body),
                'timeout' => 120,
            ), 1);

            if (\is_wp_error($response)) {
                throw new AI_Exception('Gemini transport error: ' . $response->get_error_message(), array(
                    'wp_error_code' => $response->get_error_code(),
                    'url' => $this->redact_url_for_logs($url),
                ));
            }

            $code = (int) \wp_remote_retrieve_response_code($response);
            $body_response = (string) \wp_remote_retrieve_body($response);

            // @MODIFIED 2026-02-18: Handle 404 Deprecation & 429 "Limit 0" Fallback
            // @MODIFIED 2026-02-26: Exclude DAILY quota exhaustion from model fallback (avoid changing settings).
            $is_404_not_found = ($code === 404 && (\strpos($body_response, 'models/') !== false || \strpos($body_response, 'NOT_FOUND') !== false));
            $is_429_limit_zero = (
                $code === 429 &&
                \strpos($body_response, 'limit: 0') !== false &&
                \strpos($body_response, 'generate_content_free_tier_requests') === false &&
                \stripos($body_response, 'requests per day') === false
            );

            if (!$this->is_retry_attempt && ($is_404_not_found || $is_429_limit_zero)) {
                if ($model_id === 'gemini-2.0-flash') {
                    $this->logger->error("Gemini fallback model 'gemini-2.0-flash' also hit hard quota/404. Terminating request.");
                    break;
                }

                $reason = $is_404_not_found ? "Model Not Found (404)" : "Quota Limit Zero (429)";
                $this->logger->warning("Gemini {$reason} detected. Switching to fallback model 'gemini-2.0-flash' and retrying.", [
                    'original_model' => $model_id,
                    'error_body' => \substr($body_response, 0, 300)
                ]);

                \update_option('dit_ts_gemini_model_custom', '');
                \update_option('dit_ts_gemini_model', 'gemini-2.0-flash');
                $model_id = 'gemini-2.0-flash';
                $this->is_retry_attempt = true;

                $api_version = self::get_api_version();
                $url = "https://generativelanguage.googleapis.com/{$api_version}/models/{$model_id}:generateContent?key=" . \rawurlencode((string) $this->api_key);

                continue;
            }

        if ($code === 200) {
            // @MODIFIED 2026-04-22 - Three-Layer Intelligence: consume usageMetadata
            // to feed Quota_State_Manager for predictive throttling
            $parsed = \json_decode($body_response, true);
            // @FIXED 2026-04-24 - Guard all Three-Layer classes with class_exists to prevent
            // fatal "Class not found" when autoloader fails to resolve Infrastructure\* from Gemini namespace
            if (class_exists(API_Error_Parser::class)) {
                $usage = API_Error_Parser::extract_gemini_usage($parsed);
                if (class_exists(Quota_State_Manager::class)) {
                    Quota_State_Manager::record_success('gemini', $model_id, $usage);
                }
                if (class_exists(Quota_Pause_Manager::class)) {
                    Quota_Pause_Manager::reset_consecutive_on_success('gemini');
                }
            }
            // @MODIFIED 2026-06-07 - Clear consecutive 503 counter on success
            delete_transient('dit_ts_gemini_consecutive_503');
            break;
        }

        // @MODIFIED 2026-04-22 - Three-Layer Intelligence:
        // 1. API_Error_Parser: parse structured error JSON
        // 2. Quota_State_Manager: calibrate state from error, update counters
        // 3. Backoff_Strategy: calculate optimal delay from error + quota state
        // @FIXED 2026-04-24 - Wrap entire block in class_exists guard; fall through to
        // simple AI_Exception on 429/403/503 when layers are unavailable
        // @MODIFIED 2026-04-29 - Added 503 handling for service_unavailable (high demand)
        // 503 = Google server overload, not a quota error. Soft error — skip all
        // quota tracking, state calibration, and pause logic. Just log and throw.
        // @MODIFIED 2026-06-07 - Track consecutive 503s to trigger cross-provider fallback.
        if ($code === 503) {
            $c503_key = 'dit_ts_gemini_consecutive_503';
            $consecutive_503 = (int) get_transient($c503_key);
            $consecutive_503++;
            set_transient($c503_key, $consecutive_503, HOUR_IN_SECONDS);

            $this->logger->warning("Gemini 503 service unavailable (soft error). Consecutive 503s: {$consecutive_503}.");

            $ctx_503 = array(
                'reason' => 'service_unavailable',
                'provider' => 'gemini',
                'http_code' => 503,
                'error_class' => 'service_unavailable',
                'consecutive_503s' => $consecutive_503,
            );

            // @MODIFIED 2026-07-17 - Restore 3-consecutive threshold (matches Scheduler.php comment at line ~1170).
            // A single transient 503 is a soft Google-side demand spike; allow backoff + retry on next job tick.
            // Only burn the model pool after 3+ consecutive 503s within the 1-hour transient window.
            // @FIXED source-of-truth conflict: was flagged all_models_exhausted on count==1 per 2026-07-14 modifier,
            // contradicting the original 2026-06-07 3-consecutive design.
            if ($consecutive_503 >= 3) {
                $ctx_503['all_models_exhausted'] = true;
                $this->logger->warning("Gemini 503: 3+ consecutive 503s reached ({$consecutive_503}). Flagging for cross-provider fallback.");
            } else {
                $this->logger->info("Gemini 503: transient spike (consecutive={$consecutive_503}). Deferring cross-provider fallback until 3+ consecutive.");
            }

            throw new AI_Exception("Gemini API returned 503: service_unavailable", $ctx_503);
        }

        if (in_array($code, [429, 403], true)) {
            $has_layers = class_exists(API_Error_Parser::class)
                && class_exists(Quota_State_Manager::class)
                && class_exists(Backoff_Strategy::class)
                && class_exists(Quota_Pause_Manager::class);

            if ($has_layers) {
                $headers = \wp_remote_retrieve_headers($response);
                $error_info = API_Error_Parser::parse('gemini', $code, $body_response, (array) $headers);

                Quota_State_Manager::calibrate_from_error('gemini', $error_info);

                $quota_health = Quota_State_Manager::get_health('gemini');
                $consecutive = Quota_Pause_Manager::get_consecutive_daily_quota_429s('gemini');
                $delay = Backoff_Strategy::calculate($error_info, $quota_health, $consecutive + 1);
                $reason = Backoff_Strategy::get_reason($error_info);

                if ($error_info['is_quota_zero']) {
                    throw new AI_Exception(
                        'Gemini hard quota block (quota=0). Model not allowed on this plan.',
                        array(
                            'reason' => 'model_quota_zero',
                            'provider' => 'gemini',
                            'http_code' => (int) $code,
                            'error_class' => $error_info['error_type'],
                            'quota_bucket' => $error_info['quota_bucket'],
                            'error_body' => \substr($body_response, 0, 500),
                        )
                    );
                }

                if (Backoff_Strategy::should_pause($error_info, $consecutive)) {
                    Quota_Pause_Manager::pause('gemini', $reason, 3600, 86400);
                    throw new AI_Exception(
                        'Gemini daily quota exhausted. Provider paused until reset.',
                        array(
                            'reason' => $reason,
                            'provider' => 'gemini',
                            'pause_until' => Quota_Pause_Manager::get_pause_until('gemini'),
                            'http_code' => (int) $code,
                            'error_class' => $error_info['error_type'],
                            'quota_bucket' => $error_info['quota_bucket'],
                            'retry_after' => $delay,
                            'error_body' => \substr($body_response, 0, 500),
                        )
                    );
                }

                if ($error_info['error_type'] === 'daily_quota') {
                    Quota_Pause_Manager::record_daily_quota_429('gemini', $reason, 3600, 86400, 3);
                }

                throw new AI_Exception(
                    "Gemini rate limit ({$error_info['error_type']}). Backing off {$delay}s.",
                    array(
                        'reason' => $reason,
                        'provider' => 'gemini',
                        'consecutive_count' => $consecutive + 1,
                        'retry_after' => $delay,
                        'error_class' => $error_info['error_type'],
                        'quota_bucket' => $error_info['quota_bucket'],
                        'http_code' => (int) $code,
                        'all_models_exhausted' => true,
                        'error_body' => \substr($body_response, 0, 500),
                    )
                );
            }

            // Fallback: layers unavailable, throw simple rate-limit exception
            $this->logger->warning('Gemini rate limit (layers unavailable), failing job.', [
                'code' => $code,
                'body' => \substr($body_response, 0, 500),
            ]);
            throw new AI_Exception(
                "Gemini API returned {$code}: " . \substr($body_response, 0, 500),
                array(
                    'provider' => 'gemini',
                    'http_code' => (int) $code,
                    'all_models_exhausted' => true,
                )
            );
        }

            // If we used BOTH tools + responseSchema, retry once by dropping one side if error indicates conflict.
            if (
                $attempt === 1 &&
                $enforce &&
                !empty($body['generationConfig']['responseSchema']) &&
                !empty($body['tools'])
            ) {
                $msg = '';
                $err_json = \json_decode($body_response, true);
                if (\is_array($err_json)) {
                    $msg = (string) ($err_json['error']['message'] ?? $err_json['error']['status'] ?? '');
                }
                if ($msg === '') {
                    $msg = $body_response;
                }

                $m = \strtolower($msg);
                $looks_like_schema_tools_conflict =
                    (\strpos($m, 'responseschema') !== false || \strpos($m, 'response schema') !== false || \strpos($m, 'response mime type') !== false) &&
                    (\strpos($m, 'tool') !== false || \strpos($m, 'googlesearch') !== false || \strpos($m, 'google search') !== false);

                if ($looks_like_schema_tools_conflict || ($code === 400 && $m === '')) {
                    $this->logger->warning('Gemini schema/tools conflict detected; retrying with fallback.', array(
                        'fallback_mode' => $fallback_mode,
                        'code' => $code,
                        'msg' => \substr($m, 0, 240),
                    ));

                    if ($fallback_mode === 'drop_tools') {
                        unset($body['tools']);
                    } else {
                        unset($body['generationConfig']['responseSchema']);
                        unset($body['generationConfig']['responseMimeType']);
                    }

                    continue;
                }
            }
        } // end while ($attempt < 3)

        // Safety net: if we exhausted all attempts and still don't have 200
        if ($code !== 200) {
            $this->logger->error('Gemini API error', array('code' => $code, 'body' => $body_response));
            throw new AI_Exception("API returned {$code}: " . \substr($body_response, 0, 500));
        }

        $json = \json_decode($body_response, true);
        if (\json_last_error() !== JSON_ERROR_NONE || !\is_array($json)) {
            throw new AI_Exception(
                'Gemini API returned an invalid JSON envelope (transport/API layer).',
                array(
                    'error'           => \json_last_error_msg(),
                    'response_length' => \strlen((string) $body_response),
                    'text_preview'    => \substr((string) $body_response, 0, 5000),
                )
            );
        }

        // @MODIFIED 2026-03-06 - Explicitly check for prompt/content blocking (e.g. PROHIBITED_CONTENT)
        if (isset($json['promptFeedback']['blockReason'])) {
            $reason = $json['promptFeedback']['blockReason'];
            $this->logger->warning("Gemini blocked prompt (Reason: {$reason})", array(
                'code' => $code,
                'json' => $json,
            ));
            throw new AI_Exception("Gemini blocked prompt (Reason: {$reason}).", array(
                'code' => $code,
                'block_reason' => $reason,
            ));
        }

		$text = $json['candidates'][0]['content']['parts'][0]['text'] ?? '';
		if (!\is_string($text) || \trim($text) === '') {
			throw new AI_Exception('Empty response text from Gemini (no candidate text).', array(
				'code' => $code,
			));
		}

		$sources_index = [];
		$grounding_meta = $json['candidates'][0]['groundingMetadata'] ?? [];
		if (\is_array($grounding_meta) && !empty($grounding_meta['groundingChunks'])) {
			foreach ($grounding_meta['groundingChunks'] as $i => $chunk) {
				$web = $chunk['web'] ?? [];
				$uri = $web['uri'] ?? '';
				$title = $web['title'] ?? '';
				if ($uri !== '') {
					$sources_index[] = [
						'id' => $i + 1,
						'label' => $title !== '' ? $title : ('Source ' . ($i + 1)),
						'url' => $uri,
					];
				}
			}
		}

		// @MODIFIED 2026-07-04 - Extract finishReason to detect MAX_TOKENS truncation
		$finish_reason = $json['candidates'][0]['finishReason'] ?? '';
		if ($finish_reason !== '' && $finish_reason !== 'STOP') {
			$this->logger->info('Gemini finishReason', ['finishReason' => $finish_reason]);
		}

		// Parse JSON from response
		$this->logger->info('Gemini Raw Text for Parsing', ['text' => \substr($text, 0, 1000) . (\strlen($text) > 1000 ? '...' : '')]);
		$article = $this->parse_json_response($text, $prompt, $output_schema, $finish_reason);

		if (!empty($sources_index) && \is_array($article)) {
			$article['_sources_index'] = $sources_index;
		}

		return $this->apply_visual_manifest($article, $visual_manifest);
    }

    /**
     * Call Gemini API (Legacy Wrapper)
     */
    private function call_gemini_api($prompt_data)
    {
        $visual_manifest = $prompt_data['source_visual_map'] ?? [];
        $output_schema = '';
        
        $built = $this->build_gemini_prompt($prompt_data, $visual_manifest);
        $prompt = is_array($built) ? (string) ($built['prompt'] ?? '') : (string) $built;
        $visual_manifest = is_array($built) ? (array) ($built['visual_manifest'] ?? $visual_manifest) : $visual_manifest;
        $output_schema   = is_array($built) ? (string) ($built['output_schema'] ?? '') : '';

        $this->logger->info('Calling Gemini API for magazine content generation');

        $bundle = [
            'user_prompt' => $prompt,
            'system_prompt' => '', // Legacy path doesn't use system prompt
            'output_schema' => $output_schema,
        ];

        $article = $this->call_gemini_api_unified($bundle, $visual_manifest);

	if (empty($article['social_assets']) && empty($article['social_asset'])) {
		$this->logger->warning('Gemini response is missing social_assets key', ['keys' => array_keys($article)]);
	} else {
		// @MODIFIED 2026-05-08 - Normalize singular 'social_asset' to canonical plural 'social_assets'
		if (!empty($article['social_asset']) && empty($article['social_assets'])) {
			$article['social_assets'] = $article['social_asset'];
			$this->logger->info('Gemini returned social_asset (singular); normalized to social_assets', ['assets' => $article['social_assets']]);
		} else {
			$this->logger->info('Gemini social_assets found in response', ['assets' => $article['social_assets']]);
		}
	}

        return $this->apply_visual_manifest($article, $visual_manifest);
    }

    /**
     * Build Gemini prompt for elite magazine content
     * @since 1.6.0
     *
     * @param array $prompt_data
     * @param array $existing_manifest
     * @return array
     */
    private function build_gemini_prompt($prompt_data, array $existing_manifest = [])
    {
        $visual_manifest = $existing_manifest;
        $output_schema = '';

        // If we have an existing manifest, we should NOT pass the visuals service 
        // to re-scan the text (as it's likely already tokenized). 
        // We will instead use the PromptBuilder's pre-rendered list if available.
        $service = empty($existing_manifest) ? $this->visuals : null;

        $prompt = $this->promptSchema->buildMagazinePrompt(
            is_array($prompt_data) ? $prompt_data : [],
            $visual_manifest,
            $output_schema,
            $service,
            10 // @MODIFIED 2026-02-13 - Cap AI visual tokens to exactly 10
        );

        // If service was skipped, inject the pre-rendered visual assets from prompt_data
        if ($service === null && !empty($prompt_data['visual_assets'])) {
            $prompt = str_replace('## Topic', $prompt_data['visual_assets'] . "\n\n## Topic", $prompt);
        }

        return [
            'prompt' => $prompt,
            'visual_manifest' => $visual_manifest,
            'output_schema' => $output_schema,
        ];
    }

    /**
     * Build visuals section for prompt and extract manifest
     * 
     * @param string $idea_text Source text
     * @param array $visual_manifest Reference to manifest array
     * @return string Visuals prompt section
     */
    private function build_visuals_section(string $idea_text, array &$visual_manifest): string
    {
        return $this->visuals->build_visuals_section($idea_text, $visual_manifest);
    }


    /**
     * If the model outputs VISUAL placeholder tokens, replace them with the exact
     * extracted media HTML. This makes media passthrough deterministic while
     * staying backward compatible with responses that already include the media.
     *
     * @param mixed $data Parsed article payload (array or string)
     * @param array $visual_manifest Map of token => html
     * @return mixed Article with tokens expanded
     */
    private function apply_visual_manifest($data, array $visual_manifest)
    {
        return $this->visuals->apply($data, $visual_manifest);
    }


    /**
     * Regenerate response with strict JSON-only prompt (for truncation recovery or repair)
     * @since 2.2.0
     *
     * @param string $input Input text (Prompt or Corrupted JSON)
     * @param string $output_schema Schema hint
     * @param string $mode 'repair' or 'prompt'
     * @return string Cleaned response text
     */
    private function regenerateAsStrictJson(string $input, string $output_schema = '', string $mode = 'repair'): string
    {
        $api_key = self::get_gemini_key();
        if (empty($api_key)) {
            return '';
        }

        // Always use the same configured model used by primary generation.
        // This prevents repair from silently falling back to a model with quota=0.
        $model = self::get_model_id();

        $api_version = self::get_api_version();
        $endpoint = "https://generativelanguage.googleapis.com/{$api_version}/models/{$model}:generateContent?key=" . rawurlencode($api_key);

        $schema_hint = '';
        if ($output_schema !== '') {
            $schema_hint = "\n\nSCHEMA (must match exactly):\n" . $output_schema;
        }

        if ($mode === 'prompt') {
            $prompt = "Generate the response again as STRICT JSON ONLY." . $schema_hint .
                "\n\nORIGINAL INSTRUCTIONS:\n{$input}\n\nReturn ONLY the JSON object. No markdown, no commentary.";
        } else {
            $prompt = "You are a strict JSON repair utility. Convert the input below into ONE valid JSON object." . $schema_hint .
                "\n\nINPUT TO REPAIR:\n{$input}\n\nReturn ONLY the JSON object. No markdown, no commentary.";
        }

        $payload = array(
            'contents' => array(
                array(
                    'role'  => 'user',
                    'parts' => array(array('text' => $prompt)),
                ),
            ),
            'generationConfig' => array(
                'temperature'      => 0.0,
                'topP'             => 0.1,
                'topK'             => 1,
                'maxOutputTokens'  => 65536,
                'responseMimeType' => 'application/json',
                'thinkingConfig'   => array('thinkingBudget' => 0),
            ),
        );

        $args = array(
            'headers' => array('Content-Type' => 'application/json'),
            'body'    => wp_json_encode($payload),
            'timeout' => 60,
        );

        $response = $this->call_api_with_retry($endpoint, $args);
        if (is_wp_error($response)) {
            return '';
        }

        $body = wp_remote_retrieve_body($response);
        $json = json_decode($body, true);
        $text = $json['candidates'][0]['content']['parts'][0]['text'] ?? '';

        return is_string($text) ? trim($text) : '';
    }

    /**
     * Decode JSON with lenient parsing (handles code fences, trailing commas, etc.)
     * @since 2.2.0
     *
     * @param string $text Raw AI response text
     * @return array Parsed JSON data
     * @throws AI_Exception If parsing fails
     */
    private function decodeJsonLenient(string $text): array
    {
        $data = Sanitizer::parse($text);

        if ($data === null) {
            throw new AI_Exception(
                'Failed to parse JSON response using lenient decoder. ' .
                    'Error: ' . Sanitizer::get_last_error()
            );
        }

        return $data;
    }

    /**
     * Parse JSON response from AI
     *
     * @param string $text Raw response text
     * @param string $original_prompt Original prompt (for regeneration)
     * @param string $output_schema Schema hint (for regeneration)
     * @param string $finish_reason Gemini finishReason (STOP, MAX_TOKENS, SAFETY, etc.)
     * @return array Parsed article data
     * @throws AI_Exception If parsing fails
     */
    private function parse_json_response($text, string $original_prompt = '', string $output_schema = '', string $finish_reason = '')
    {
        $raw   = (string) $text;
        $clean = Sanitizer::clean($raw);
        $last_rejected_payload = null; // @MODIFIED 2026-02-08 - Track rejected payload

        $trunc = $this->detect_truncation($raw); // Check raw first to avoid clean masking it

        // @MODIFIED 2026-07-04 - Detect MAX_TOKENS finish reason from Gemini response
        // When finishReason is MAX_TOKENS, the response is truncated regardless of parse success
        if ($finish_reason === 'MAX_TOKENS') {
            $trunc['is_truncated'] = true;
            $this->logger->warning('Gemini finishReason=MAX_TOKENS detected — forcing truncation recovery', [
                'raw_length' => strlen($raw),
            ]);
        }

        // 1) Fast path: robust sanitizer parse (fence stripping + JSON block scan)
        try {
            $parsed = Sanitizer::parse($clean);
            if (is_array($parsed)) {
                // @MODIFIED 2026-02-09 - Handle truncated block metadata from Sanitizer
                // If Sanitizer found a truncated block that scores better than any complete block
                if (isset($parsed['_is_truncated_block'])) {
                    // Before we accept "truncated", first try decoding the full cleaned payload.
                    $full_try = json_decode($clean, true);
                    if (json_last_error() === JSON_ERROR_NONE && is_array($full_try)) {
                        return $full_try;
                    }

                    $this->logger->warning('Sanitizer flagged truncation, but full decode failed; proceeding to local repair.', [
                        'json_error' => json_last_error_msg(),
                    ]);

                    $trunc['is_truncated'] = true;
                    $clean = $parsed['raw'];
                } else {

                    if ($output_schema === '' || !$this->looks_like_empty_article_payload($parsed)) {
                        return $parsed;
                    }
                    $last_rejected_payload = $parsed; // Capture valid but empty payload
                    $this->logger->warning('Parsed JSON looks like an empty schema/template; attempting regeneration.', [
                        'headline' => (string)($parsed['headline'] ?? $parsed['title'] ?? ''),
                        'sections' => is_array($parsed['sections'] ?? null) ? count($parsed['sections']) : 0,
                    ]);

                    // @MODIFIED 2026-02-09 - Drastically increase backoff for 1 RPM Free tier
                    // If we got a valid JSON but it looks empty, AI might need a longer breath.
                    sleep(20);
                }
            }
        } catch (\Throwable $e) {
            // continue to recovery attempts
        }

        // 2) @MODIFIED 2026-02-08 - Prioritize Repair over Retry to save tokens/quota
        // If truncated, try Local Repair first
        if ($trunc['is_truncated']) {
            $this->logger->warning('Triggering Local JSON Repair for truncated response', ['length' => strlen($clean)]);

            $repaired = $this->repair_json_locally($clean);
            try {
                // Use standard decode first to avoid aggressive sanitizer stripping if repair was successful
                $parsed = json_decode($repaired, true);
                if (json_last_error() === JSON_ERROR_NONE && is_array($parsed)) {
                    if ($output_schema === '' || !$this->looks_like_empty_article_payload($parsed)) {
                        $this->logger->info('Local JSON Repair Successful');
                        return $parsed;
                    }
                    $last_rejected_payload = $parsed;
                } else {
                    $this->logger->warning('Local JSON Repair: Standard decode failed', [
                        'error' => json_last_error_msg(),
                        'repaired_tail' => substr($repaired, -200)
                    ]);
                }

                // Fallback to sanitizer if standard decode fails
                $parsed = Sanitizer::parse($repaired);
                if (is_array($parsed)) {
                    // @MODIFIED 2026-07-17 - Sanitizer metadata-wrap guard.
                    // When local repair closes a truncated payload but mid-string truncation remains,
                    // Sanitizer::parse() returns a metadata wrapper with '_is_truncated_block' set
                    // (the raw block it could not fully decode). Previously this fell through
                    // looks_like_empty_article_payload() which logged the misleading
                    // 'Rejected payload: Received Sanitizer metadata...' warning AND captured
                    // the metadata into $last_rejected_payload — risking that the best-effort
                    // return path at the bottom of parse_json_response() would surface Sanitizer
                    // metadata to downstream consumers as if it were a parsed article.
                    // Now: silently discard the metadata-wrap and fall through to AI Repair,
                    // which is the correct recovery path per the existing pipeline design.
                    if (isset($parsed['_is_truncated_block'])) {
                        $this->logger->info('Local JSON Repair still truncated after Sanitizer fallback; deferring to AI Repair.', [
                            'repaired_length' => strlen($repaired),
                        ]);
                    } elseif ($output_schema === '' || !$this->looks_like_empty_article_payload($parsed)) {
                        $this->logger->info('Local JSON Repair Successful (via Sanitizer)');
                        return $parsed;
                    } else {
                        $last_rejected_payload = $parsed;
                    }
                }
            } catch (\Throwable $e) {
                $this->logger->warning('Local JSON Repair failed to produce valid JSON', ['error' => $e->getMessage()]);
            }

            // Fall through to AI Repair (step 3) and Full Regeneration (step 4) below.
            // The 2026-06-21 premature throw was removed — remote repair has a high success rate
            // on truncated responses and should not be skipped.
        }

        // 3) AI Repair (Strict JSON Mode) - Still cheaper than full regen
        // Only do this if we have something to repair
        if (!empty($clean)) {
            $strict = $this->regenerateAsStrictJson($clean, $output_schema, 'repair');
            if (is_string($strict) && $strict !== '') {
                try {
                    $parsed = Sanitizer::parse($strict);
                    if (is_array($parsed)) {
                        if ($output_schema === '' || !$this->looks_like_empty_article_payload($parsed)) {
                            return $parsed;
                        }
                        $last_rejected_payload = $parsed;
                    }
                } catch (\Throwable $e) {
                    // continue
                }
            }
        }

        // 4) Last Resort: Full Regeneration from Prompt
        // @MODIFIED 2026-02-08: Only retry if truncated. Parse errors on complete responses = our bug, not AI's.
        if (!empty($original_prompt) && $trunc['is_truncated']) {
            $this->logger->info("Truncated response detected. Retrying full generation (Last Resort)...");
            $strict = $this->regenerateAsStrictJson($original_prompt, $output_schema, 'prompt');

            if (is_string($strict) && $strict !== '') {
                try {
                    $parsed = Sanitizer::parse($strict);
                    if (is_array($parsed)) {
                        if ($output_schema === '' || !$this->looks_like_empty_article_payload($parsed)) {
                            return $parsed;
                        }
                        $last_rejected_payload = $parsed;
                    }
                } catch (\Throwable $e) {
                    // continue
                }
            }
        } elseif (!$trunc['is_truncated'] && empty($last_rejected_payload)) {
            // @MODIFIED 2026-02-08: Critical - Parser failed on COMPLETE response
            // This is a code bug (fence stripping, etc), NOT an AI failure. Do not retry.
            $this->logger->error('Parser failed on complete response - this is a code bug, not AI failure', [
                'raw_length' => strlen($raw),
                'clean_length' => strlen($clean),
                'raw_preview' => substr($raw, 0, 300),
            ]);
        }

        $err = json_last_error_msg();

        if ($last_rejected_payload !== null) {
            if (!$this->looks_like_empty_article_payload($last_rejected_payload)) {
                $this->logger->warning('Returning best-effort JSON payload to avoid 429 rate limit loop');
                return $last_rejected_payload;
            }
            $this->logger->warning('Best-effort payload rejected: empty article detected. Throwing to trigger fallback.');
        }

        // @MODIFIED 2026-02-09 - Verbose logging for debugging (User Request)
        $this->logger->error('JSON Parsing Failed. Full Raw Response:', [
            'response_length' => strlen($raw),
            'raw_content' => $raw, // Dump full content
            'parser_error' => $err,
            'sanitizer_error' => Sanitizer::get_last_error(),
        ]);

        throw new AI_Exception(
            'Failed to parse AI response as JSON.',
            array(
                'error'           => $err,
                'response_length' => strlen($raw),
                'last_parser_error' => Sanitizer::get_last_error(),
            )
        );
    }


    /**
     * Detect when the model returned a valid JSON object that is essentially an empty schema/template.
     *
     * We only apply this gate when an output schema was provided (i.e., article generation).
     *
     * @since 2026-02-06
     */
    private function looks_like_empty_article_payload(array $data): bool
    {
        // Fail-closed if metadata array from Sanitizer leaked here
        if (isset($data['_is_truncated_block'])) {
            $this->logger->warning('Rejected payload: Received Sanitizer metadata instead of parsed article.');
            return true;
        }

        // 1. Check for Narrative Content
        $narrative = $data['story_narrative'] ?? $data['article_body'] ?? $data['content'] ?? $data['dek'] ?? '';
        $narrative_len = is_string($narrative) ? strlen(trim(strip_tags(preg_replace('/<!--.*?-->/s', '', $narrative)))) : 0;

        // 2. Check Sections
        $sections_len = 0;
        $sections = $data['sections'] ?? [];
        if (is_array($sections)) {
            foreach ($sections as $s) {
                if (!is_array($s)) continue;
                $body = (string)($s['body_html'] ?? $s['bodyhtml'] ?? $s['body'] ?? $s['content'] ?? '');
                $clean_body = preg_replace('/<!--.*?-->/s', '', $body);
                $clean_body = strip_tags($clean_body);
                $sections_len += strlen(trim($clean_body));
            }
        }

        $total_text_len = max($narrative_len, $sections_len);

        // 3. Check for Placeholder Headline
        $headline = (string)($data['headline'] ?? $data['title'] ?? '');
        $is_placeholder_headline = (
            stripos($headline, 'A sophisticated') !== false ||
            stripos($headline, 'non-clickbait') !== false ||
            stripos($headline, 'SEO-optimized') !== false ||
            strlen(trim($headline)) < 5
        );

        // 4. Decision Logic
        if ($total_text_len > 400 && !$is_placeholder_headline) {
            return false; // Valid
        }

        if ($is_placeholder_headline && $total_text_len < 100) {
            $this->logger->warning('Rejected payload: Placeholder headline.', ['headline' => $headline, 'len' => $total_text_len]);
            return true;
        }

        if ($total_text_len < 40) {
            $json_str = json_encode($data);
            if ($json_str !== false && strlen($json_str) > 5000 && $total_text_len > 10) {
                $this->logger->info('Accepting large payload despite low text count');
                return false;
            }
            return true;
        }

        return false;
    }

    /**
     * Attempt local repair of truncated JSON strings
     * Closes strings, arrays, and objects based on stack analysis
     * 
     * @since 2.2.0
     * @param string $json Truncated JSON
     * @return string Repaired JSON
     */
    private function repair_json_locally(string $json): string
    {
        // 1. Partial UTF-8 Repair
        while (!mb_check_encoding($json, 'UTF-8')) {
            $json = substr($json, 0, -1);
            if ($json === '') return '{}';
        }

        $len = strlen($json);
        $in_string = false;
        $escape = false;
        $unicode_state = 0; // 0=none, 1=\u, 2=\uX, 3=\uXX, 4=\uXXX
        $stack = []; // Expected closing chars

        for ($i = 0; $i < $len; $i++) {
            $char = $json[$i];

            if ($in_string) {
                if ($escape) {
                    $escape = false;
                    if ($char === 'u') {
                        $unicode_state = 1;
                    }
                    continue;
                }

                if ($unicode_state > 0) {
                    if (preg_match('/^[a-fA-F0-9]$/', $char)) {
                        $unicode_state++;
                        if ($unicode_state === 5) {
                            $unicode_state = 0;
                        }
                        continue;
                    } else {
                        $unicode_state = 0;
                        // Fall through to process char
                    }
                }

                if ($char === '\\') {
                    $escape = true;
                } elseif ($char === '"') {
                    $in_string = false;
                }
                continue;
            }

            if ($char === '"') {
                $in_string = true;
            } elseif ($char === '{') {
                $stack[] = '}';
            } elseif ($char === '[') {
                $stack[] = ']';
            } elseif ($char === '}' || $char === ']') {
                if (!empty($stack)) {
                    $expected = end($stack);
                    if ($char === $expected) {
                        array_pop($stack);
                    }
                }
            }
        }

        // 2. Repair: Close String if open
        if ($in_string) {
            // Clean up incomplete escape sequences at the end
            if ($escape) {
                // Ends with backslash
                $json = substr($json, 0, -1);
            } elseif ($unicode_state > 0) {
                // Ends with incomplete unicode escape (\u, \uX, etc.)
                // unicode_state=1 corresponds to \u (2 chars)
                // Remove unicode_state + 1 chars
                $json = substr($json, 0, - ($unicode_state + 1));
            }
            $json .= '"';
        }

        // 3. Repair: Handle Trailing Syntax (Context Aware)
        // Remove trailing comma (common truncation point)
        $json = preg_replace('/,\s*$/', '', $json);

        $trimmed = rtrim($json);
        if ($trimmed !== '') {
            $last_char = substr($trimmed, -1);

            // If ends in :, we are missing value
            if ($last_char === ':') {
                $json .= ' ""';
            }
            // If ends in " (string closed), we might be a Key without a Value in an Object
            elseif ($last_char === '"') {
                // Check if we are inside an object
                if (!empty($stack) && end($stack) === '}') {
                    // Determine if this string is a Key (needs value) or a Value (needs nothing)
                    // We check the non-whitespace char BEFORE the string.
                    if (preg_match('/([{,])\s*("[^"\\\\]*(?:\\\\.[^"\\\\]*)*")\s*$/', $json)) {
                        $json .= ': ""';
                    }
                }
            }
        }

        // 4. Close Stack
        while ($closer = array_pop($stack)) {
            $json .= $closer;
        }

        return $json;
    }

    /**
     * Orchestrates the repair of a truncated JSON string.
     * Locates the start of the JSON and then calls local repair.
     *
     * @since 2.2.0
     * @param string $text Raw response text, potentially with preamble.
     * @return string Repaired JSON string.
     */
    private function repair_truncated_json($text)
    {
        // 1. Strip Preamble (Everything before first { or [)
        $start_brace = strpos($text, '{');
        $start_bracket = strpos($text, '[');

        if ($start_brace !== false || $start_bracket !== false) {
            if ($start_brace === false) $start = $start_bracket;
            elseif ($start_bracket === false) $start = $start_brace;
            else $start = min($start_brace, $start_bracket);

            $text = substr($text, $start);
        }

        $repaired = $this->repair_json_locally($text);

        // Sanity check: If we just closed a truncated string but not the object, try again?
        // repair_json_locally handles the stack, so it should be fine.

        $this->logger->info("Local JSON Repair result", [
            'original_length' => strlen($text),
            'repaired_length' => strlen($repaired),
            'tail' => substr($repaired, -50)
        ]);

        return $repaired;
    }

    /**
     * Detect if API response appears truncated
     * 
     * @param string $text Raw response text
     * @return array Truncation detection results
     */
    private function detect_truncation($text)
    {
        $text = trim($text);
        $len = strlen($text);

        if ($len === 0) {
            return array(
                'is_truncated' => true,
                'brace_balance' => 0,
                'ends_mid_string' => false,
                'reason' => 'empty_response'
            );
        }

        // Check brace/bracket balance
        $open_braces = substr_count($text, '{');
        $close_braces = substr_count($text, '}');
        $open_brackets = substr_count($text, '[');
        $close_brackets = substr_count($text, ']');

        $brace_balance = ($open_braces - $close_braces) + ($open_brackets - $close_brackets);

        // Check if ends mid-string (unclosed quote after last colon)
        $ends_mid_string = false;
        $last_50 = substr($text, -50);

        // Pattern: ends with an unclosed string value (e.g., "key": "value without closing quote)
        if (preg_match('/:\s*"[^"]*$/s', $last_50)) {
            $ends_mid_string = true;
        }

        // Check if last character suggests truncation
        $last_char = substr($text, -1);
        $suspicious_ending = !in_array($last_char, array('}', ']', '"', 'e', 'l')); // Valid JSON endings

        $is_truncated = (
            $brace_balance > 0 ||
            $ends_mid_string ||
            ($suspicious_ending && $brace_balance !== 0)
        );

        return array(
            'is_truncated' => $is_truncated,
            'brace_balance' => $brace_balance,
            'ends_mid_string' => $ends_mid_string,
            'suspicious_ending' => $suspicious_ending,
            'last_char' => $last_char
        );
    }

    // @MODIFIED 2026-02-14 - legacy call_api_with_retry removed, handled by AI_Network_Trait

    /**
     * Test API connection
     *
     * @return array Test results
     * @throws AI_Exception If test fails
     */
    public function test_connection()
    {
        $api_version = self::get_api_version();
        $url = "https://generativelanguage.googleapis.com/{$api_version}/models?key=" . $this->api_key;

        $response = \wp_remote_get($url, array('timeout' => 30));

        if (\is_wp_error($response)) {
            throw new AI_Exception('Connection failed: ' . $response->get_error_message());
        }

        $code = \wp_remote_retrieve_response_code($response);

        if ($code !== 200) {
            throw new AI_Exception('API returned error code: ' . $code);
        }

        return array(
            'status' => 'connected',
            'provider' => 'gemini',
        );
    }

    /**
     * Quota probe
     *
     * Sends a minimal generateContent request to check whether the provider quota
     * has actually recovered (avoids guessing reset windows).
     *
     * @since 2.15.11
     * @MODIFIED 2026-02-25 - Added provider quota probe.
     */
    public function probe_quota(): bool
    {
        $api_version = self::get_api_version();
        $model = $this->get_model();

        // models/ prefix handling
        if (strpos($model, 'models/') !== 0) {
            $model = 'models/' . $model;
        }

        $url = "https://generativelanguage.googleapis.com/{$api_version}/{$model}:generateContent?key=" . $this->api_key;

        $payload = array(
            'contents' => array(
                array(
                    'role'  => 'user',
                    'parts' => array(
                        array('text' => 'Reply with OK.'),
                    ),
                ),
            ),
            'generationConfig' => array(
                'maxOutputTokens' => 4,
                'temperature'     => 0.0,
            ),
        );

        $args = array(
            'headers' => array('Content-Type' => 'application/json'),
            'body'    => wp_json_encode($payload),
            'timeout' => 30,
        );

        $response = $this->call_api_with_retry($url, $args, 0);
        if (\is_wp_error($response)) {
            return false;
        }

        $code = (int) \wp_remote_retrieve_response_code($response);
        if ($code === 200) {
            return true;
        }

        return false;
    }
    /**
     * Build writing prompt for research-based articles
     * 
     * @param array $prompt_data
     * @param array $research_data
     * @param array $visual_manifest Reference
     * @param string $output_schema_out Reference
     * @return string
     */
    private function build_writing_prompt(array $prompt_data, array $research_data, array &$visual_manifest = array(), string &$output_schema_out = ''): string
    {
        return $this->promptSchema->buildFromResearchPrompt(
            $prompt_data,
            $research_data,
            $visual_manifest,
            $output_schema_out,
            $this->visuals,
            10 // @MODIFIED 2026-02-13 - Cap AI visual tokens to exactly 10
        );
    }

    /**
     * Check circuit breaker before making API call
     * @since 2.4.0
     * @MODIFIED 2026-02-14 - Wrap global circuit breaker with Daily Quota check
     *
     * @throws AI_Exception if circuit is open
     */
    protected function check_circuit_breaker(): void
    {
        // 1. Check any active quota pause first (Longest duration block)
        // @MODIFIED 2026-05-05 - Use is_daily_quota_exhausted() which now checks ALL pause reasons
        if ($this->is_daily_quota_exhausted()) {
            $until = 0;
            $reset_at = 0;
            $reason = 'daily_quota_exhausted';
            if (class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Pause_Manager')) {
                $until = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::get_pause_until('gemini');
                $reset_at = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::get_reset_at('gemini');
                $reason = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::get_reason('gemini') ?: 'daily_quota_exhausted';
            }

            $until_str = '';
            $reset_str = '';
            if (class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Reset_Calculator')) {
                if ($until > 0) {
                    $until_str = \DIT\TrendStudio\Infrastructure\Quota_Reset_Calculator::format_in_wp_tz($until);
                }
                if ($reset_at > 0) {
                    $reset_str = \DIT\TrendStudio\Infrastructure\Quota_Reset_Calculator::format_in_wp_tz($reset_at);
                }
            }

            $msg = 'Gemini Quota Pause Active (' . $reason . ') - API paused.';
            if ($reset_str !== '') {
                $msg .= ' Quota resets at: ' . $reset_str . '.';
            }
            if ($until_str !== '') {
                $msg .= ' Next retry after: ' . $until_str . '.';
            }

            $this->logger->warning('API Call Blocked: ' . $msg);

            throw new AI_Exception(
                $msg,
                array(
                    'reason' => $reason,
                    'provider' => 'gemini',
                    'pause_until' => (int) $until,
                    'reset_at' => (int) $reset_at,
                )
            );
        }

        // 2. Call global circuit breaker logic from Trait
        $this->trait_check_circuit_breaker();
    }

    /**
     * Record successful API call (reset circuit)
     * @since 2.4.0
     */
    protected function record_circuit_success(): void
    {
        // Simply proxy to Trait logic
        // (If Gemini eventually needs custom success logic, it goes here)
        $this->trait_record_circuit_success();
    }

    /**
     * Record failed API call (increment circuit counter)
     * @since 2.4.0
     */
    protected function record_circuit_failure(): void
    {
        // Simply proxy to Trait logic
        $this->trait_record_circuit_failure();
    }

    /**
     * Mark Gemini Daily Quota as exhausted
     * @since 2.5.0
     */
 private function mark_daily_quota_exhausted(): void
 {
 if (class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Pause_Manager')) {
 \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::pause('gemini', 'daily_quota_exhausted', 3600, 86400);
 }

 delete_transient('dit_ts_gemini_quota_pause');
 delete_transient('dit_ts_gemini_daily_quota_exhausted');
 }

    /**
     * Check if Gemini Daily Quota is exhausted
     * @since 2.5.0
     * @MODIFIED 2026-05-05 - Check any active quota pause, not just daily_quota_exhausted reason.
     * A quota_runtime_hit or rpm_sustained pause from yesterday also blocks pre-flight.
     * @return bool
     */
    public function is_daily_quota_exhausted(): bool
    {
        if (class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Pause_Manager')) {
            return \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::is_paused('gemini');
        }

        return false;
    }
}
