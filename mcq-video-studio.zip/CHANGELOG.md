# Changelog


## [1.5.3] - 2026-08-17 — Background video now plays full duration (was 2s loop)
- **Background videos in generated videos now play the full selected video instead of looping a 2-second clip.** Root cause: `extractBgVideoFrames()` in `render-service/render-core/media-prep.js` hardcoded `-frames:v 60` (60 frames @ 30fps = 2 seconds). For a typical 5-question Shorts (~40s), the background looped every 2 seconds (20+ loops).
- **Fix: dynamic frame extraction based on actual render duration.**
  - `extractBgVideoFrames()` now accepts optional `totalMs` parameter; calculates required frames as `Math.min(18000, Math.ceil(totalMs / frameDur))` (capped at ~10 min @ 30fps).
  - `prepareMedia()` passes `opts.totalMs` (from initial `built.totalMs`) to extract enough frames upfront.
  - `render-node.js`: after `rebuildPlanWithAdaptiveTiming()` extends the timeline (e.g., TTS forces 2s → 40s), re-extracts background frames for the new `built.totalMs` if coverage is insufficient (mirrors the existing pattern for `media.sfx`/`media.duckWindows` re-derivation).
- **Result:** background video plays continuously for the full render duration (or loops only if the source video is shorter than the render). No more 2-second loops.
- **Plugin version bumped to 1.5.3** (cache-busts all changed assets). Full plugin ZIP: `mcqvs-v1.5.3.zip`.


## [1.5.4] - 2026-08-18 — CSV import now supports background video randomization
- **BG-Video import fallback:** When CSV does not include a `bg_video` column, imported topics now randomly assign a background video by scanning `assets/bg-videos/` folder for `.mp4` files. Picks one at random - no name matching needed, works with any videos user has placed in that folder. Users can still override per-row by providing a `bg_video` column with a full path/URL.
- **Modified files:** `includes/class-vs-excel-importer.php`, `CHANGELOG.md`
- **How it works:** Scans `assets/bg-videos/*.mp4` at import time, selects randomly, stores filename. Renderer resolves via `basename()` against the same folder.

## [1.5.2] - 2026-08-13 — CRITICAL: jobs with any future publish_at wait for their render window (Bank/sidebar + CSV), Buffer story-tick OFF + dropdown=Story → auto-Reel, story-tick persistence
- **CRITICAL — Jobs with ANY future `publish_at` now wait for their render window (was calendar-only).** Jobs created through the LINEAR path (CSV import with `publish_start_date`, "Add Topic from Bank"/sidebar) computed a `publish_at` but stayed `ready_for_render`, so they rendered and hit Buffer immediately — ignoring `scheduled_at` entirely. `create_job_for_topic()` in `includes/class-vs-content-planner.php` now gates on any future `publish_at`: the job is parked in `pending` with `scheduled_at = publish_at − 60 min` (default render buffer up from 30), and the `vs_process_job_event` transition event is scheduled for EVERY pending job the create path produces (the `$topic_publish_date` gate is dropped). The calendar-drag re-stamp path uses the same 60-min default.
- **Buffer: story tick OFF + dropdown = Story → auto-Reel (FB/IG).** If the user explicitly turns OFF the per-channel "post to story" tick but the dropdown is set to `story`, the post now falls back to `reel` instead of posting as a Story (avoids "Video must be no longer than 1 minute" errors when the user wants Reels). Tick ON still forces Story.
- **Story tick no longer "comes back" on refresh.** `update_account()` in `includes/class-vs-buffer-client.php` now syncs the sanitized per-channel story map to the legacy global option `mcqvs_buffer_channel_post_to_story` for the default account (the push pipeline reads that option), and `assets/js/settings.js` now sends an explicit `1`/`0` for EVERY enabled channel — an all-unchecked map serializes as `{}` and was silently dropped by jQuery before.
- **Buffer retry re-queue uses the same 60-min render-buffer default** so a re-queued job keeps its render window.
- Related, already shipped: the resume-skip-overdue logic, calendar drag re-stamp, and per-channel Buffer captions remain intact under this version.


## [1.4.9.58] - 2026-08-12 — Studio TTS read-only mirror of Settings, TTS pre-generated before play (no lag), unreadable template text + topic-name + double-CTA + dashboard-row fixes
- **Studio TTS panel is now a READ-ONLY mirror of Settings → Text-to-Speech.** Voice, provider, rate, speak-hook/options/answer/cta and the master enable toggle are locked (disabled) with a note: "🔒 Voiceover is managed in Settings → Text-to-Speech… Studio reads those values for preview & export." The voice you select in Settings is what Studio uses — no more second source of truth drifting from Settings.
- **Play button pre-generates ALL TTS before starting playback — no more lag/overlap.** Previously only the next 2 segments were prefetched, so the timeline reached question 2/3 while its TTS was still being generated server-side (the video ran ahead of the narration). Now clicking ▶ with a server TTS provider shows **"⏳ TTS…"** on the play button (with a "Generating voiceover — will auto-play when ready" tip) until every segment is cached, then playback starts and the narration follows the timeline exactly (existing no-overlap guard + cache). Browser TTS (webspeech) needs no prewarm and plays instantly.
- **Space Odyssey / Science Lab unreadable text fixed (landscape).** The landscape question text was wrapped using the FULL band width but drawn to the right of the difficulty pill — long lines ran under/over the badge and got clipped (OCR showed "MEDUMI" and mangled words). The difficulty badge is now sized FIRST and the question wraps within the remaining width (textAvailW), so the badge is clean and every line is inside the band. Verified by rendering both templates portrait + landscape: badges read clean, all words present.
- **Topic name no longer one tiny line.** The quiz-name badge (portrait + landscape) previously forced a single line that shrank until it fit (unreadable for long topics). It now wraps to up to 2 lines at a larger base font, centered in the badge. Verified: "Space Exploration Quiz" wraps cleanly.
- **No more double CTA in the outro.** When the CTA is the score challenge ("Comment your score 👇 5/5?"), the outro sub-line no longer repeats "Comment your score below! 👇" — it now says "👇 Drop your score in the comments!" (distinct, not a duplicate).
- **No hardcoded CTA in the Studio editor.** The CTA Text field default is now "Comment your score 👇" (was "Subscribe for More!"), and the custom-CTA row is hidden unless the user picks Custom Text + turns Rank off. CSV has no CTA column, so imported videos use the same "Comment your score 👇" default via the score CTA.
- **Dashboard header is one compact row.** Removed the Settings and Open Studio buttons (they're in the left admin menu) — the header now shows: **[⏹ Stop Everything / ▶ Resume]** (single toggle), **Restore Safety Backup**, **Reset Plugin**. No more 2-row wrap.
- **Plugin version bumped to 1.4.9.58** (cache-busts all changed assets). Full plugin ZIP: `mcqvs-v1.4.9.58.zip`.


## [1.4.9.57] - 2026-08-12 — Removed-template fallback (old jobs referencing minimalist/quizwire re-render with trivia instead of a blank template)
- **Regression fix found in a self-audit.** After removing the `minimalist`/`quizwire` templates, any ALREADY-QUEUED job (or job settings) still referencing them resolved to an empty default template config → the renderer drew a black background with hardcoded white text. Two SSOT fixes:
  - `MCQVS_VideoTemplates.apply()` now falls back to `trivia` (safe dark template) when the requested id no longer exists — covers browser preview, worker export, Studio, and any path that calls apply().
  - `server-renderer.buildPlanAndState()` normalizes the returned `templateId` to `trivia` when the requested template is unknown, and persists it back into `settings.template` — so the plan builder, cues, and the final `getTemplate()` render all use the fallback consistently.
  - Verified: jobs with `template: quizwire`, `minimalist`, or any unknown id all resolve to `trivia` and render OCR-readable frames (no blank/black template). The TTS timing verification still passes unchanged (NO OVERLAP, all reads fully spoken).
- **Plugin version bumped to 1.4.9.57** (cache-busts all changed assets). Full plugin ZIP: `mcqvs-v1.4.9.57.zip`.


## [1.4.9.56] - 2026-08-12 — TTS fully adaptive again (no more cut-off reads), minimalist + quizwire templates removed, full rebuild
- **TTS timing restored to fully-adaptive (the core fix you asked for).** A question's scene is now sized to the ACTUAL TTS it must speak — full read (question + options, per the checked speak settings) + a short gap + the full reveal (correct answer) — with **NO truncating per-question cap**.
  - The 1.4.9.52 "overlap fix" had introduced a read-budget clamp that **cut the reading mid-option** whenever read + reveal exceeded 12.5s (which happens with options spoken aloud, especially at rate 1.0 from CSV imports) — you heard "TTS reaches the 3rd option then Q2 starts". That clamp is gone; the ceiling is now a 90s/question pathological guard that never truncates normal narration.
  - **Verified with REAL Edge TTS** (rate 1.2, speakOptions ON, 2 questions): Q1 read fully spoken (13.21s / full 12.94s), Q1 reveal, then Q2 read starts only after Q1's reveal ended — **NO OVERLAP: true, ALL READS FULLY SPOKEN: true**. The final MP4 (34.42s) matches the adapted timeline exactly, audio muxed.
  - The mixer's no-overlap net + per-segment trims remain as safety (they're no-ops when timing is correct).
  - **Browser Studio-export port aligned** (`studio.export.js`): same no-truncation rule, so browser export and Content Planner/headless renders agree.
- **CSV-import TTS now honors your Settings (rate 1.2 etc.).** The importer hardcoded `rate => 1.0` and ignored the speak toggles, so CSV jobs ran slower/longer than every other pipeline (which then tripped the old cap). It now reads `mcqvs_tts_rate`, `mcqvs_tts_enabled`, `mcqvs_tts_speak_hook/options/answer/cta` from Settings (CSV columns still override when provided) — so "TTS time is calculated per the checked settings" is true across all pipelines.
- **`minimalist` and `quizwire` templates removed completely.** Both white-background templates (the readability-problem pair) are deleted from `vs-video-templates.js`, the FX/SFX contract list, the schema/group lists, the template-manager special-case, the CSV importer allow-list, Content Planner's template dropdown + auto-guess map/rotation pool, and the self-test template select. Fallbacks everywhere point to safe dark templates (`corporate`/`trivia`); any existing job/CSV that referenced `quizwire` or `minimalist` now falls back gracefully (importer → `corporate`; auto-guess pool no longer includes them). **Verified: 16 templates remain, all render + OCR readable (corporate, elegant, neon, science, history, retro80s, trivia…), no regressions.**
- **Plugin version bumped to 1.4.9.56** (cache-busts all changed assets). This release is also shipped as a **full plugin ZIP** (`mcqvs-v1.4.9.56.zip`) for a clean VPS update.


## [1.4.9.55] - 2026-08-12 — STOP/Resume + log timestamps now show site-local time, not UTC
- **"⏹ STOPPED" chip on the Dashboard now shows site-local time** — previously it rendered the raw UTC `gmdate('M j, H:i')` (e.g. "Aug 12, 17:36" when the site is UTC+5). It now uses `wp_date(get_option('date_format') . ' ' . get_option('time_format'), $ts)` — the exact same formatting every other visible timestamp in the plugin uses (pipeline card, calendar, buffer status), so it matches what the user set in Settings → General → Timezone.
- **GLOBAL STOP / GLOBAL RESUME log messages now log site-local time** (`wp_date`) instead of the raw UTC `$now`.
- **Log export now exports site-local timestamps** — the log viewer's "Copy All / export" previously wrote the raw UTC `ts`; it now uses the already-computed `ts_display` (PHP `wp_date`), matching what the on-screen log table shows.
- **Plugin version bumped to 1.4.9.55** (cache-busts all changed assets).


## [1.4.9.54] - 2026-08-12 — Resume now SKIPS overdue calendar jobs (publish date passed while stopped) — no late flood
- **When you Resume after the pipeline was stopped for 1+ days, overdue jobs are no longer dumped onto social in a burst.** New behavior (user-chosen "Skip overdue, keep future"):
  - On Resume, every job whose `publish_at` is in the PAST while the pipeline was stopped is marked **`cancelled`** with the reason *"Skipped on resume: publish date passed while pipeline was stopped."* — the missed window is skipped, nothing posts late.
  - Covers all three states that could have posted late: `pending` (never rendered), `ready_for_render` (never rendered), and `completed`-but-unpublished (rendered before the stop, publish passed).
  - **Never touched:** jobs already published (`published_channels` set), jobs with no `publish_at` (buffer-queued, no date concept), and all future-dated jobs — future jobs keep their original schedule exactly.
  - The remaining `pending` jobs (future only) are still re-queued via `vs_process_job_event`; `ready_for_render` future jobs render on the next queue tick.
- **Verified with a state-matrix test:** overdue pending/ready/completed-unpublished → cancelled (3 rows); already-published, no-date, future pending/ready/completed → all untouched. `php -l` + `node --check` clean.
- **Resume confirm dialog updated** to state that overdue jobs are skipped.
- **Plugin version bumped to 1.4.9.54** (cache-busts all changed assets).


## [1.4.9.53] - 2026-08-12 — Dashboard "⏹ Stop Everything" / "▶ Resume" (global STOP, non-destructive)
- **New red "⏹ Stop Everything" button on the Dashboard header** (next to Reset Plugin), swapping to a green **"▶ Resume"** + red "STOPPED {time}" chip while active. Scope (user-confirmed):
  - **Kills ALL live render processes** (`render-node.js` PIDs via the existing `kill_pid` + PID transients) and resets every mid-render/uploading job **back to `ready_for_render`** with partial `video_url`/`video_path`/`started_at` cleared — so Resume re-renders them from scratch (nothing lost).
  - **Cancels every queue/cron/action**: Action Scheduler recurring + single (`vs_headless_render_cron`, `vs_publish_scheduled_cron`, `vs_process_bulk_schedule`, `mcqvs_process_topic_batch` + `vs_generate_mcq_batch` AI generation, `mcqvs_render_claim`, `mcqvs_kill_orphan_render`, `mcqvs_cleanup_batch_tracker`, `mcqvs_render_liveness`, telemetry/artifact prunes, `vs_process_job_event`) and all WP crons (`vs_daily_schedule_event`, `mcqvs_orphan_kill_cron`, etc.).
  - **Persistent `mcqvs_global_stop` flag** + far-future `mcqvs_render_queue_pause_until` transient, checked at EVERY entry point: `run_daily_scheduler`, `process_job`, `run_headless_render_queue`, `handle_render_claim_action`, `run_publish_scheduler`, `handle_topic_batch_background`, `approve_topic_plan_internal`, `ajax_approve_topic_plan` (rejects with a clear message), and `VS_Buffer_Client::push_job_to_buffer` (no new Buffer posts — already-sent posts can't be recalled, documented).
  - **Studio browser Auto-Runner** halts on its next poll via `MCQVS_Config.globalStopped`; Content Planner blocks "Start AI Generation" while stopped.
  - **NON-destructive**: no tables truncated, no options deleted, no data lost (that's Reset's job).
- **"▶ Resume" (manual only):** clears the flag + pause, re-registers all crons (idempotent), and re-schedules `vs_process_job_event` for every pending job (future → WP cron, past/now → async) so the queue resumes exactly where it stopped. Ready-to-render jobs render on the next queue tick.
- **Verified:** stop-flag helper + guard logic unit-tested (default off → set → engines bail → resume clears → timestamp recorded); `php -l` + `node --check` clean on all touched files.
- **Plugin version bumped to 1.4.9.53** (cache-busts all changed assets).


## [1.4.9.52] - 2026-08-12 — White-on-white template fixed, server renders now honor hook/cover OFF, TTS overlap eliminated (3 layers), Studio hook toggle persists
- **White-on-white template fixed (CRITICAL).** The `minimalist` template (white `#FAFAFA` background + white solid cards) used the `minimalClean` text-effect preset, whose question/option/hook fills were `#FFFFFF` — **white text on white = invisible** in every pipeline that applies text effects (Studio preview, browser export, worker). `minimalClean` fills are now dark (`#1A1A1A`), matching the template's dark text color. Verified by rendering through the real pipeline: minimalist question + hook OCR fully readable before/after. (quizwire was already fixed in 1.4.9.27 with `quizwireBold`.)
- **Server/headless renders now actually honor "Show Hook Text On Video = OFF" and "Show Cover Page = OFF" (CRITICAL).** Root cause: `buildPlanAndState` built a correctly-gated playlist, but then preferred `MCQVS_PlanBuilder.buildFromState(...)` — and the object it passed **did not include `hookVisible` or `coverConfig`**. plan.builder's own gates saw `undefined` and re-added the cover + hook scenes regardless of settings → the generated video showed the hook even though the Content Planner toggle was unchecked and the job settings said `hookVisible: false`. Now both fields are passed. Verified: hook ON/cover ON, hook OFF/cover ON, hook ON/cover OFF, hook OFF/cover OFF all produce the correct scene list (hook OFF + cover OFF → video starts directly with Q1 — confirmed with a full render + OCR).
- **TTS overlap eliminated (the "Q1 answer still talking when Q2 starts" bug) — three layers:**
  1. `computeAdaptiveTiming` now caps the **read** contribution to the per-scene budget (`maxQuestionMs − 80 − 300ms gap − reveal window`). Previously the read was capped at 14s while the scene was capped at 12.5s — with long reads (options spoken aloud at slower rates) the scene got truncated but the reveal cue was anchored to the FULL measured read, so the answer TTS started AFTER the scene ended and played over the next question's reading. Verified: a 15s read now yields scene 12.5s with reveal at 9.32s ending 12.32s (inside), where it previously landed at ~15.4s (2.9s into Q2).
  2. `rebuildPlanWithAdaptiveTiming` anchors `_revealStartRel` to the **budget-capped** read (same math), and stores `_revealTtsMs`.
  3. render-node Phase 3 clamps the reveal cue inside the scene and computes a `trimSec` per segment (read trimmed to end ~50ms before the reveal; reveal/hook/cta trimmed to end ~50ms before their scene ends); the **audio mixer now sorts voice segments and never lets a later segment start while an earlier one is still playing** (cursorEndSec push — parity with the browser export guarantee), plus applies the per-segment trim. Result: **two voices can never overlap in the mix**, even in cap edge cases.
- **Studio "Show Hook Text On Video" no longer resets to ON on refresh.** It seeds from the same persisted option as the Content Planner (`mcqvs_planner_hook_visible`, exposed as `MCQVS_Config.defaultHookVisible`); the editor checkbox renders from the option; and the CSV import persists the toggles at import time as a belt-and-braces (single source of truth across Content Planner + Studio).
- **Server text-effects SSOT:** `buildPlanAndState` now sets `textEffects.currentStyle` from the template (browser did this via `apply()`), so the server uses the same preset as preview/export instead of falling back to classicBold.
- **Plugin version bumped to 1.4.9.52** (cache-busts all changed assets).


## [1.4.9.51] - 2026-08-12 — THE calendar-drag fix that actually works: topic lookup was broken by slug-vs-name
- **Root cause of "dragged to today but Pipeline card still shows old dates" — found and fixed.** `VS_MCQ_Repository::get_topic($id_or_slug)` looked up `WHERE slug = <value>` verbatim. Topics are stored with `slug = sanitize_title(name)` (e.g. `5-fascinating-facts-about-the-human-brain`), but the calendar drag-save (and `create_job_for_topic`) passed the **human-readable name**. So the lookup returned `null` → `topic_id = 0` → the job re-stamp silently skipped every topic → `jobs_restamped` stayed 0 → Pipeline card never changed. Confirmed by direct test: `get_topic("5 Fascinating Facts About the Human Brain")` → NULL; `get_topic("5-fascinating-facts-about-the-human-brain")` → id 7.
  - **Fix:** `get_topic()` now tries the value as-is, then `sanitize_title(value)`, so both slugs and raw names resolve. One change fixes every caller (calendar drag-save, `create_job_for_topic`, bulk scheduler, CSV import bank sync).
- **Verified end-to-end with the exact bug scenario (in-memory DB):** topic "5 Fascinating Facts About the Human Brain" has a pending job with `publish_at = 2026-08-13 13:20:00` (Aug 13 18:20 PKT). Calendar drag → save with `publish_date=2026-08-12, publish_time=18:20` → **`jobs_restamped: 1`**, job `publish_at = 2026-08-12 13:20:00` (Aug 12 18:20 PKT), `scheduled_at = 2026-08-12 12:50:00` (publish − 30 min render buffer), and the `vs_process_job_event` cron re-scheduled (async enqueue when the time already passed — correct).
- **Why topics on a date appear "pending":** that is **by design**, not a bug. When a topic has a publish date, its job is created with status `pending` and `scheduled_at = publish_at − 30 min` (the render buffer). The calendar's gray dot is the job waiting for its render window to open; at `scheduled_at` it transitions to `ready_for_render`, renders, and only then publishes. The Pipeline card shows it as "Queued"/"Scheduled" until then. After the 1.4.9.51 fix, a topic dragged to Aug 12 will show **Aug 12** in the Pipeline card (pending = waiting for its render slot, on the correct day).
- **Plugin version bumped to 1.4.9.51** (cache-busts all changed assets).


## [1.4.9.50] - 2026-08-12 — Calendar drag now re-stamps existing jobs (Pipeline card reflects new dates) + toggle persistence confirmed
- **CRITICAL E2E fix — dragging a topic to a new date in the Content Planner calendar now updates the Pipeline Jobs card immediately.** The Pipeline card reads `vs_jobs.publish_at`, but `ajax_save_calendar_assignments()` only rewrote the `mcqvs_content_plan` option — so jobs created earlier (e.g. by CSV import) kept their old dates and the card showed stale "today/upcoming" rows.
  - New `VS_Job_Repository::get_schedulable_jobs_by_topic($topic_id)` — returns PENDING / READY_FOR_RENDER jobs for a topic (never completed/rendered/failed jobs).
  - The calendar save handler now, for every changed topic: resolves `vs_topics.id` by name, re-computes `publish_at` (site timezone → UTC via the existing `compute_publish_at`), updates `publish_at` + `scheduled_at` (publish − render buffer) columns, syncs the job settings metadata (`_render_at`, `publish_date`, `publish_time`), and **reschedules the `vs_process_job_event` cron** so a PENDING job still transitions to READY_FOR_RENDER at the new time.
  - Verified with an in-memory DB: drag to Aug 12 → job1 `publish_at` = `2026-08-12 18:20:00`, job2 = `2026-08-12 19:50:00`, a COMPLETED job untouched, pending job's cron rescheduled. The AJAX response now also returns `jobs_restamped` for UI/audit.
- **Content Planner "Show Hook Text On Video" / "Show Cover Page" toggles — confirmed persisting.** The option-backed render (`checked(get_option('mcqvs_planner_hook_visible', true))`), the `mcqvs_planner_save_toggles` endpoint and the JS change-save binding are all in place (this was shipped in 1.4.9.49). The earlier log you pasted (`"hook_visible": true`, "Chunking 76 topics…", "Auto-approval triggered…") matches the **pre-1.4.9.48 deployed build** — i.e. the fixes exist in the repo but hadn't been applied to the VPS yet. This patch (1.4.9.50) includes all of 1.4.9.48/1.4.9.49/1.4.9.50 changes; **apply it and hard-refresh (Ctrl/Cmd+Shift+R)** — the asset version bump (`get_asset_version()`) cache-busts the JS.
- **Plugin version bumped to 1.4.9.50** (cache-busts all changed assets).


## [1.4.9.49] - 2026-08-12 — TTS SSOT (Settings drive everything; Studio only reads) + planner toggle persistence + CSV import precedence fixes
- **TTS is now single-source-of-truth in Settings — Studio just reads it.**
  - **New Settings > Text-to-Speech options:** Enable Voiceover (TTS) master switch (`mcqvs_tts_enabled`), Speech Rate (`mcqvs_tts_rate`, default 1.2), Read Hook Aloud (`mcqvs_tts_speak_hook`), Read Answer Aloud (`mcqvs_tts_speak_answer`), Read CTA Aloud (`mcqvs_tts_speak_cta`) — alongside the existing voice, provider, rotation and Speak-Options settings.
  - Studio seeds its voiceover state from `MCQVS_Config.tts` (which now exposes enabled/rate/speakHook/speakAnswer/speakCta) — the Studio TTS panel **reflects Settings**, it does not override them.
  - Content Planner defaults (`get_studio_render_defaults`) and the headless-renderer fallback both read the same Settings options → every pipeline (Studio preview / Studio export / Content Planner / headless node) uses identical TTS config.
- **CRITICAL TTS bug fixed — browser voice name leaking into Edge TTS.** The logs showed `"voice": "Microsoft David - English (United States)"` — a **browser Web Speech voice name** — being sent to `edge-tts-helper`, which rejected it (~0.3s, empty response, ERROR entries in the log). Fixed in three layers:
  - PHP `generate_edge_tts()` now validates the voice against the known Edge voice list; anything else falls back to the Settings default voice (`mcqvs_tts_default_voice`) → `en-US-AriaNeural`.
  - Headless renderer normalizes a persisted job's `voiceover.voice` the same way before it reaches the node renderer.
  - Node `media-prep.js` `generateTts()`/`generateTtsBatch()` now run every voice through `normalizeEdgeVoice()` (must match `^[a-z]{2}-[A-Z]{2}-[A-Za-z]+Neural$`, else `en-US-AriaNeural`) — so even a bad voice from a saved job can't produce a silent 0.3s failure.
- **Content Planner "Show Hook Text On Video" no longer resets on page load.** The toggle state now persists to options (`mcqvs_planner_hook_visible`, `mcqvs_planner_cover_enabled`) via a small AJAX (`mcqvs_planner_save_toggles`), and the checkboxes render from those options. Toggling hook OFF for a CSV import that carries hooks now actually works.
  - **Buffer share is NOT affected:** the hook visibility toggle only controls the on-video hook scene; the `{hook}` used in the Buffer caption / pinned comment is stored separately in job settings and still flows through.
- **CSV import precedence fixed (CSV wins, sidebar is fallback):**
  - `hookVisible` fallback now honors the sidebar toggle (`import_settings['hook_visible']`) instead of hardcoding `true` — so "CSV has hooks but I don't want them on video" works.
  - `save_mode` fallback honors the sidebar control instead of hardcoding `r2_buffer`.
  - Template / schedule were already CSV-first (only used when the CSV lacks them) — unchanged.
- **Plugin version bumped to 1.4.9.49** (cache-busts all changed assets).


## [1.4.9.48] - 2026-08-12 — Content Planner E2E: cover/hook controls for CSV, CSV processed synchronously (no fake AI batches), Pipeline Jobs populated instantly, batch-card fixes
- **NEW "Show Cover Page (thumbnail card)" toggle** in Content Planner sidebar (parity with Studio's coverConfig). Default ON; off = skip the 1s cover scene so videos start with the hook or first question. Wired end-to-end:
  - CSV import (`mcqvs_import_topics_from_excel`) reads `cover_enabled` + `hook_visible` from the upload POST (previously hook was hardcoded ON and there was NO cover control in Content Planner at all).
  - Threaded through `cover_config => ['enabled' => bool]` → batch styles → `create_job_for_topic()` → job settings → renderer (plan.builder / server-renderer / export all gate the cover scene on `coverConfig.enabled !== false` — SSOT preserved).
  - The "Start AI Generation" sidebar flow sends the same toggles via `mcqvs_approve_topic_plan`.
  - Import preview notes now reflect the actual toggles/format/schedule chosen.
- **CSV imports are now processed SYNCHRONOUSLY — no fake "AI batches".** CSV topics carry their questions (`_inline_questions`), so no Gemini call is needed; the import handler now creates the jobs immediately instead of enqueuing async Action Scheduler batches that could sit pending forever. Result:
  - Dashboard → **Pipeline Jobs (Active & Recent) shows today's + upcoming videos instantly** after import (jobs exist with `scheduled_at`/`publish_at` → the existing today/overdue/future priority ordering in `get_recent_pipeline_jobs()` kicks in).
  - The "AI Generation Progress" card no longer shows 9 pending batches for a CSV import (only topics WITHOUT inline questions — plain topic-name CSVs — still use the async AI path).
- **Batch card fixes:**
  - `_batch_id` (a UUID metadata key) is excluded from the batches list + summary counts — no more "Batch #NaN / unknown / pending / 10" rows. Also returned separately as `active_batch_id`.
  - Banner label changed from "AI Generation: X/Y batches done" to "Background processing: X/Y batches done" (accurate for CSV imports).
- **Import handler hardened:** `set_time_limit(300)` + memory raise for large CSVs (sync bank insert + job creation).
- **Plugin version bumped to 1.4.9.48** (cache-busts all changed assets).


## [1.4.9.47] - 2026-08-12 — CSV questions now reach Saved Questions Bank / Studio Editor / Qs card (synchronous bank insert)
- **CRITICAL — imported CSV questions only appeared in the plan, not in the bank.** All three views — Content Planner **Saved Questions Bank**, the **Qs card**, and the **Studio Editor** data source — read `vs_mcq_bank`. The CSV import stored topics + `_inline_questions` in the `mcqvs_content_plan` option, but questions only reached the bank indirectly, when the background Action Scheduler batch (`mcqvs_process_topic_batch`) ran and created jobs. If that async batch never fired (WP-Cron off / AS not processing / job creation delayed), the questions appeared **nowhere** — not in the bank, not in Studio, not in the Qs card.
- **Fix: questions are inserted into `vs_mcq_bank` synchronously during import.** `ajax_import_topics_from_excel()` now iterates every imported topic's `_inline_questions`, resolves/creates the `vs_topics` row, and `insert_mcq()`s each question (status `approved`, source_ref `csv_import`) before the plan is saved — so the bank rows exist the moment import completes, independent of any background job. The plan topics also carry `_bank_question_ids` for traceability.
- **No duplicates on re-import.** `insert_mcq()` dedupes on `content_hash`; a second import of the same file reuses the existing bank IDs. Verified: importing Aug-26-videos-v3.csv twice → bank stays at exactly 500 rows.
- **Verified end-to-end with an in-memory DB:** 500 parsed rows → 100 grouped topics → **500 bank rows, 100 topic rows, 0 invalid indexes, 500/500 four-option, 500/500 approved**.
- **Bonus fix — CSV hashtags/hook no longer wiped in the batch path.** `handle_topic_batch_background()` hard-coded the CSV-resolved envelope's `hashtags`/`hook` to `''`, discarding the per-topic metadata the importer persists. It now carries the topic item's own values through to job settings (captions + pinned comment keep the CSV tags).
- **Plugin version bumped to 1.4.9.47** (cache-busts all changed assets).


## [1.4.9.46] - 2026-08-12 — CSV/Excel import: BOM crash fix + quote handling + hashtags preserved (v3 CSV)
- **CRITICAL — "Preview failed: No topics found in the uploaded file" on BOM-prefixed CSVs.** Files saved by Excel/Google Sheets often start with a UTF-8 BOM (`\xEF\xBB\xBF`). It corrupted the FIRST header cell — `topic` became `\xEF\xBB\xBFtopic` — so every row failed the `!empty($topic_data['topic'])` gate and the whole file parsed to 0 topics. `parse_excel_content()` now strips a leading BOM before any parsing. Verified with the real `Aug-26-videos-v3.csv`: **0 topics before, 500 topics after**, 0 validation errors, 100 grouped plan topics × 5 inline questions each, dates normalized to `Y-m-d`, template/hook/difficulty mapped.
- **Quoted CSV fields no longer keep their quote characters.** `parse_csv_line()` now treats `"` as a delimiter (and handles escaped `""` inside quoted fields), so `"humanbody,biology,quiz"` parses as `humanbody,biology,quiz` instead of carrying literal quotes into captions/CTAs.
- **CSV `hashtags` now reach the content plan.** They were parsed from the file but dropped in `process_legacy_excel_content()` — so v3 hashtags never reached the Buffer caption `{hashtags}` placeholder or the pinned-comment copy. Now 100/100 imported topics carry their tags.
- **Plugin version bumped to 1.4.9.46** (cache-busts all changed assets).


## [1.4.9.45] - 2026-08-12 — Settings > Data: keep/delete on uninstall (default KEEP) + Gemini API key protected across updates
- **New Settings > Data tab** with an explicit "Delete all plugin data on uninstall" checkbox — **default KEEP (recommended)**. While unchecked, deactivating or updating the plugin keeps ALL data (Content Planner, batch tracker, generated questions, jobs, retention settings, API keys, Buffer accounts, uploads). When checked, a permanent uninstall deletes all plugin tables, options and uploads. This is now a real setting, not just a wp-config constant:
  - `mcqvs_purge_data_on_uninstall` option (registered with the Settings API, native to the new Data tab).
  - The purge decision is one helper, `mcqvs_purge_data_on_uninstall()`, honored by `mcqvs_uninstall_plugin()`, `uninstall.php` and `VS_Installer::uninstall()` — purging requires the constant OR the option; default is keep.
- **Gemini API key no longer can be lost on update.**
  - Root cause: the ZIP-update flow (deactivate → delete folder → upload) runs the OLD uninstall.php at delete time; pre-1.4.9.40 uninstalls wiped everything including `mcqvs_gemini_api_key`. Current uninstalls are gated, but there was no safety net for the transition.
  - **Deactivation now takes the safety backup FIRST** — `mcqvs_deactivate_plugin()` snapshots all user data (including the API key) the moment the update flow starts, *before* any uninstall runs. After reactivation, one click on **Restore Safety Backup** (Dashboard header or Settings > Data) refills any missing values — API keys included.
  - The Data tab also shows the last backup timestamp/version for transparency.
- **Plugin version bumped to 1.4.9.45** (cache-busts all changed assets).


## [1.4.9.44] - 2026-08-12 — "npm not found" fixed: installs now run through node's bundled npm, portable-Node auto-retry
- **Root cause of the failed One-Click Setup:** the VPS has Node at `/usr/bin/node` but **npm only in the SSH user's shell profile** (nvm-style install). PHP's `shell_exec` runs as the web user without that profile, so `which npm` returned nothing and the installer aborted with "npm binary not found" — even though Node itself was fine.
- **The installer no longer depends on `npm` being on PATH at all.** `run_npm_install()` now resolves the npm invocation in this order (verified end-to-end):
  1. `npm` on PATH (common case).
  2. **Node's bundled npm** — `node <npm-cli.js> install`. Found by resolving the node binary (configured path → `which node` → plugin-provisioned portable node → `readlink -f`) and locating its `npm-cli.js` (official dists, nvm symlinks, Debian's `/usr/share/nodejs`). Tested: with npm hidden from PATH, the generated command installed canvas 3.2.3 + ffmpeg-static 7.0.2 + ws in ~2s, binaries present, `require('canvas')` OK.
  3. `bash -lc` login shell (sources the user profile where nvm lives) as a last resort.
- **One-Click Setup now auto-retries with a portable Node.** If the first npm attempt fails, Setup downloads a portable Node into `uploads/mcq-video-studio/runtime/`, points `mcqvs_node_path` at it, and re-runs `npm install` — so even a bare-binary node install with no npm anywhere gets a working stack with zero SSH.
- **Health-check message updated** to point at "Setup Server Environment" (one-click, no SSH) instead of a manual cd/npm hint.
- **Plugin version bumped to 1.4.9.44** (cache-busts all changed assets).


## [1.4.9.43] - 2026-08-12 — Self-sufficient: one-click environment setup (no SSH), ffmpeg bundled via npm, portable Node provisioning
- **The headless renderer is now self-sufficient — no VPS/SSH steps after updates.**
  - **FFmpeg is now bundled via npm.** `render-service` ships `ffmpeg-static` (a static FFmpeg 7.0.2 binary, `node_modules/ffmpeg-static/ffmpeg`) installed automatically by the same `npm install` that installs canvas. `auto_detect_ffmpeg()` falls back to it, so the plugin never depends on a system ffmpeg. Verified: a fresh install → full render (1080×1920 h264 MP4, 13.13s, 315 frames) using **only the npm-bundled ffmpeg**.
  - **One-click "Setup Server Environment" button** (Settings > Headless, replacing the old "run this over SSH" block): provisions **Node.js** (portable linux-x64/arm64 download into `uploads/mcq-video-studio/runtime/`, sets `mcqvs_node_path`, extracted via PHP PharData — verified working on Node v22.23.2), force-runs `npm install` (canvas 3.x N-API prebuild + ffmpeg-static + ws), then verifies node/canvas/ffmpeg/fonts. Entirely from the admin UI.
  - **Load-time auto-heal now covers ffmpeg too** — `maybe_install_render_deps()` checks canvas AND ffmpeg readiness and re-runs `npm install` if either is missing, so every plugin update self-heals in the background (canvas 3.x + ffmpeg-static are pure binary downloads — no compiling, no system packages, no `setup-vps.sh`).
- **What this means in practice:** after installing 1.4.9.43 once, plugin updates never require SSH — Node is detected (or auto-provisioned), canvas and ffmpeg are npm-managed, and the "Test Headless Setup" check goes green automatically.
- **Plugin version bumped to 1.4.9.43** (cache-busts all changed assets).


## [1.4.9.42] - 2026-08-12 — canvas 3.x (fixes "node_canvas: MISSING" on Node ≥ 22), stale-broken-canvas auto-clean
- **The headless renderer now ships `canvas ^3.2.3` instead of `^2.11.2`.** Root cause of the recurring "MISSING (cd render-service && npm install)" on the VPS:
  1. npm ≥ 12 blocked canvas's install script → `node_modules/canvas` existed but **no `build/` directory at all** (node-pre-gyp never ran, no native binary).
  2. Even with the script allowed, **canvas 2.11.2 has no prebuilt binary for Node ≥ 22** (its prebuilds stop at node-v120 / Node 21; Node 22 = ABI 127) → node-pre-gyp falls back to compiling from source, which needs `build-essential` + cairo/pango/jpeg/gif dev libraries on the server.
  - **canvas 3.2.3 ships N-API v7 prebuilds** (`napi-v7-linux-x64`) — ABI-stable, one binary works on Node 18/20/22/24+, downloads in seconds, no compile, no system packages. Engine floor bumped to Node ≥ 18.12.
  - Verified end-to-end with **Node v22.23.2 (the VPS's exact version) + canvas 3.2.3** through the real `render-node.js`: full shorts render (hook + question + reveal + score CTA outro) produced a valid MP4; OCR of extracted frames shows readable text across templates — quizwire ("Which planet is known as the Red Planet?" + EASY + 4 options; "Comment your score 👇 1/1?"), neon (gradient bg, MEDIUM badge), space (Orbitron/Exo-2 custom fonts). No renderer code changes were needed — the shared template engine is fully 3.x-compatible.
- **Auto-installer now forces stale canvas out.** If the native binary is missing, `maybe_install_render_deps()` removes `node_modules/canvas` + `package-lock.json` before `npm install`, so npm resolves the packaged `^3.2.3` instead of treating the broken 2.x folder as up-to-date; `npm rebuild canvas` remains the second-chance fallback.
- **Plugin version bumped to 1.4.9.42** (cache-busts all changed assets).


## [1.4.9.41] - 2026-08-12 — More data-loss hardening: safety backup + restore button, batch-completion no longer wipes the planner, dead-code uninstall gated
- **One-click "Restore Safety Backup" button** (Dashboard header, next to Reset Plugin):
  - Every activation / version change now auto-snapshots ALL user data into `mcqvs_safety_backup` (taken BEFORE the version bump runs, so it always holds the previous install's data — covers the delete-folder ZIP update flow via `mcqvs_init` too).
  - Captured: Content Planner topics + pending pointer, batch tracker, every `mcqvs_batch_%` option (bulk-scheduler batches + batch jobs), all Artifact Cleanup **Retention (days)** options + dry-run flag, Buffer accounts, API provider + custom providers + Gemini key.
  - Restore is a **safe merge**: it only refills values that are currently MISSING/empty — existing data is never overwritten (so it can't clobber newer work). Verified with a full simulated wipe: 17 values restored; existing values left untouched.
- **Batch completion no longer wipes the Content Planner / batch history.** `handle_cleanup_batch_tracker()` + the inline fallback previously deleted `mcqvs_content_plan` (ALL topics) and `mcqvs_batch_tracker` the moment every batch finished — a partially-failed batch silently lost its topics, and the dashboard's batch/state view emptied. Now: the runtime pending-batch pointer is dropped, the topic plan is cleared ONLY when every batch truly completed (avoids duplicate regeneration), and the batch tracker is kept as history. If any batch failed/is retrying, the topic plan survives.
- **`VS_Installer::uninstall()` gated** behind the same `MCQVS_PURGE_DATA_ON_UNINSTALL` constant as the uninstall hook — it drops ALL tables (incl. `vs_mcq_bank`) and deletes Content Planner data, so nothing can invoke it accidentally.
- **Headless-test canvas message now shows the exact render-service path** — `require('canvas')` must run FROM `render-service/` (a `node -e` from the home dir fails even when canvas is installed).
- **Plugin version bumped to 1.4.9.41** (cache-busts all changed assets).


## [1.4.9.40] - 2026-08-12 — Data-loss fixes (settings/dashboard wiped on reactivation) + npm 12 canvas auto-heal
- **Deactivation no longer deletes user data.** `mcqvs_deactivate_plugin()` was deleting `mcqvs_content_plan`, `mcqvs_content_plan_pending_batches`, `mcqvs_batch_tracker` and every `mcqvs_batch_%` option (bulk-scheduler batches AND `mcqvs_batch_job_%` batch jobs). Every deactivate → reactivate cycle wiped the Content Planner dashboard, the batch tracker and all generated batch questions. Now deactivation only clears crons, Action Scheduler actions and volatile transients (job locks, render PIDs/auth, spawn stamps, telemetry counters). Content Planner topics, pending batches, batch tracker and batch questions all survive reactivation.
- **Uninstall no longer destroys data by default.** The plugin update flow (deactivate → delete folder → upload new ZIP) runs `uninstall.php`/the uninstall hook, which previously wiped EVERYTHING: the Artifact Cleanup **Retention (days) settings**, the generated-Qs table `vs_mcq_bank`, `vs_jobs`/`vs_projects`/`vs_project_questions`, API keys, Content Planner data and the whole `uploads/mcq-video-studio/` tree. All of that is now gated behind an explicit opt-in:
  ```php
  define('MCQVS_PURGE_DATA_ON_UNINSTALL', true); // wp-config.php — only for a permanent, full removal
  ```
  Without the flag, uninstall clears only crons, Action Scheduler actions, volatile transients and the (recreatable) `vs_logs` table — all questions, plans, settings, keys and uploads are preserved. Applied to both `mcqvs_uninstall_plugin()` and the standalone `uninstall.php` copy.
- **node-canvas auto-heal for npm ≥ 12.** npm 12 blocks dependency install scripts by default: `npm install` leaves `node_modules/canvas` present but **without the native binary** (node-pre-gyp never ran), so the headless test reported `node_canvas: MISSING` even right after a successful install. Fixes:
  - `render-service/package.json` now ships `"allowScripts": { "canvas": true }` so npm ≥ 12 runs canvas's install script (npm ≤ 11 ignores the field — harmless).
  - `VS_Installer::maybe_install_render_deps()` no longer treats "canvas folder exists" as installed — it verifies the native binding `build/Release/canvas.node` and, if missing, re-runs install and then `npm rebuild canvas` to force node-pre-gyp. Verified: deleting the binding → `require('canvas')` fails → `npm rebuild canvas` restores it → `require('canvas')` OK.
  - Headless-test health check now reports the specific case: `BROKEN — canvas folder exists but the native binary is missing…` with the exact manual fix (`cd render-service && npm install-scripts approve canvas && npm rebuild canvas`).
- **Plugin version bumped to 1.4.9.40** (cache-busts all changed assets).


## [1.4.9.39] - 2026-08-11 — New landscape (16:9) layout: Option-3 "Question band + 2x2 grid"
- **Landscape question layout completely redesigned** (the previous landscape was a cramped left/right mirror of portrait):
  - **Header (drawBranding):** `[logo][Brand]` left · **quiz name CENTERED** (was a right-side badge) · top-right reserved for the counter pill.
  - **"Q n/total" counter pill top-right** — shows the question number, not a score (a video can't self-score); reserves space so a corner logo (top-right, per `logoPosition`) never collides.
  - **Question band** (full width, rounded, per-template card style) with auto-fit + proper multi-line wrapping and the difficulty badge inside it.
  - **2×2 option grid** with letter tiles (A–D), per-template accent colors, wrapped option text that shrinks to fit, and a **green correct-highlight (tile + border) on reveal**.
  - **No per-question CTA** — the "Comment your score 👇 X/X?" challenge lives only in the outro (score CTA from 1.4.9.36).
  - Timer bar (bottom) + countdown pill (bottom-right) + post-reveal explanation bar all retained.
- **Wired to everything**: runs in the shared `vs-template-manager.js` → works identically in Studio preview, worker export, and the node/headless pipeline (Content Planner). Per-template fonts, colors, card styles, logo positions, TTS timing, difficulty, explanation all flow through the same engine.
- **Verified (rendered all 15 templates through the full 1920×1080 node path):**
  - multi-line question readable on all templates; all 4 options readable; quiz name centered; pill shows Q1/5 … Q5/5; no per-question CTA; reveal green highlight on the correct cell (14,344 green px on correct, 0 on others); long options wrap.
  - Portrait (9:16) layout unchanged — regression-checked.
- **Plugin version bumped to 1.4.9.39** (cache-busts all changed assets).


## [1.4.9.38] - 2026-08-11 — Browser Studio-export timing port aligned with node pipeline (drift fix)
- **The 25s/question cap drift is fixed** — browser Studio-export now matches Content Planner / headless (node) renders exactly:
  - Format-aware caps in `studio.export.js computeAdaptiveTiming` port: **shorts max 12.5s/question (was 25s!), min 5.2s; youtube 8s/25s** — identical to `server-renderer.js computeAdaptiveTiming`. Previously a browser export of the same quiz could be up to ~2x longer than the Content Planner render.
  - **Hook-scene extension added** to the export port (mirrors node): if hook TTS outgrows hookIntro, the hook scene grows to fit (cap 4s) so hook audio never spills into Q1.
  - **Hook TTS cue now carries `sceneId`** in `_buildVoiceoverCues`, so it re-anchors to the (possibly extended) rebuilt hook scene — parity with render-node Phase 3 placement.
  - The export placement loop was already sequential with a `cursorEndSec` guard (a delayed segment waits for the previous to finish) — confirmed it's the same no-overlap guarantee as the node mixer.
- **"What if a question's TTS is longer than the scene?" — auto-align confirmed**: both pipelines measure TTS from the **actual decoded audio duration** (`buf.duration` in export; ffprobe in node) — not an estimate — and `computeAdaptiveTiming` **extends the scene to fit** (read + 300ms gap + reveal window), up to the 12.5s shorts cap. A long question simply makes that scene longer; the reveal and answer-TTS fire after the reading finishes (320ms gap), so nothing overlaps and nothing is cut except beyond the hard cap.
- **Plugin version bumped to 1.4.9.38** (cache-busts all changed assets).


## [1.4.9.37] - 2026-08-11 — TTS batching safety fixes (no lag/overlap) + pre-existing overlap fixes
- **CRITICAL batching fixes (the two bugs that could ruin TTS)**:
  - `generateTtsBatch()` was returning a **Promise** but `generateAndMeasureTts` consumed it synchronously — every segment was skipped and it silently fell back to the slow per-segment path (perf win lost + a wasted batch spawn per video). Now **synchronous** (spawnSync is sync) so the caller gets the WAV array directly.
  - `-map` used the **original segment index** instead of the ffmpeg **input ordinal** — if segment N failed, the NEXT segment's WAV conversion failed too and that segment's TTS was **dropped from the mix** (the lag/overlap symptom). Now `-map <inputOrdinal>:a` mapped from position in the existing-inputs list. Verified: forced mid-segment failure → `OK, NULL, OK, OK` (neighbors survive).
- **Pre-existing overlap sources fixed (verified 0 overlaps in the final mix)**:
  - **Hook TTS outgrew the hook scene** (hook TTS ~1.8s vs fixed 1.2s scene) → hook audio spilled into Q1's reading. `computeAdaptiveTiming` now extends the hook scene to fit its TTS (capped 4s); the hook cue now carries a `sceneId` and render-node Phase 3 re-anchors it to the (possibly extended) hook scene start.
  - **Reveal TTS spilled into the next question** when the 11s/question cap truncated a slow question's scene. Shorts cap raised **11s → 12.5s** (read + 300ms gap + reveal window ≈ 2.3s) so the reveal always finishes inside its own scene. Videos stay ~40s — the cap only binds when TTS is genuinely slow.
- **Verified with a real 2-question, 5-segment Edge TTS run through the full pipeline**: final audio placement sorted by start time shows **0 overlapping segments**, each read→reveal gap = **320ms** (clean), all WAVs present. Batch mode also verified: 4/4 WAVs in order, mid-failure leaves neighbors intact.
- **Plugin version bumped to 1.4.9.37** (cache-busts all changed assets).
- Note (pre-existing, not fixed here): the browser Studio-export timing port still uses a 25s/question cap vs the node pipeline's 12.5s — a parity gap that only affects batch-export length, not TTS correctness. Flagged for a future pass.


## [1.4.9.36] - 2026-08-11 — Perf: TTS batching + static-bg cache · bg-video fix (all pipelines) · score-CTA
- **PERF — TTS batching (biggest render wall-time win)**:
  - `edge-tts-helper.js` now supports **batch mode** (`--texts=JSON` + `--outputs=JSON`) — synthesizes many segments in ONE node process (sequential per segment, 3 retries each, per-segment success reporting).
  - `media-prep.js` new `generateTtsBatch()`: one node spawn for all segments + **one multi-input ffmpeg** conversion (`-i a.mp3 -i b.mp3 … -map 0:a …`). A 5-question short (~12–20 TTS segments) went from **24–40 process spawns to ~2**.
  - `server-renderer.js generateAndMeasureTts()` uses the batch in chunks of 8, with a per-segment fallback path if batching ever fails (never breaks rendering). Verified: 2 segments → 1 node + 1 ffmpeg, both WAVs produced.
- **PERF — static-background cache**:
  - `vs-template-manager.js drawBackground()` now draws static (non-animated, no video/image) template backgrounds **once to an offscreen canvas** keyed by template+size+colors, then blits with one `drawImage` per frame. Animated gradients, bg videos and bg images are NEVER cached. Verified: static cached, frames identical, animated templates not cached.
- **BUG — background videos now render in ALL pipelines**:
  - Content Planner → headless was silently falling back to the gradient when the bg-video local path didn't resolve (fragile URL-prefix match broke on www/non-www, http/https, or `esc_url_raw` encoding differences). `class-vs-headless-renderer.php` now also resolves the local file by **filename** (basename of the `bg_video` value) against `assets/bg-videos/` AND `uploads/mcq-video-studio/bg-videos/` — the URL-prefix match is kept as a secondary path. Verified end-to-end: `bgVideoPath` set → 60 frames extracted → rendered frame shows the video.
- **VIRAL — score-challenge CTA (comments = #1 seed-test signal)**:
  - New **`score`** CTA style: outro shows "🎯 Comment your score 👇 X/X?" with the real question total + a trophy icon + always-on "Comment your score below! 👇" line. New Studio CTA preset option (default selected for shorts).
  - Wired everywhere: Studio controller `updateComputedValues()`, `studio.ui.js` sync, `render-runner.js` default, Content Planner `get_studio_render_defaults()` (ctaStyle `score`, ctaText "Comment your score 👇"), and the **server renderer** fills the X/X total server-side (no JS controller on the headless path). Verified: outro renders "Comment your score 👇 2/2?".
  - **"📌 Copy Pinned Comment"** button in the Studio editor — copies `{hook} + Can you score X/X? Comment below 👇 + brand + site link` to the clipboard to paste-and-pin under each published short.
- **Plugin version bumped to 1.4.9.36** (cache-busts all changed assets).


## [1.4.9.35] - 2026-08-11 — CRITICAL: server font-weight registration fix (Space/Science unreadable)
- **Root cause (fully traced)**: `buildPlanAndState` (server-renderer) populated `settings.templateFonts` via `MCQVS_VideoTemplates.apply()` but **never persisted `settings.templateFontWeights`** (only the fallback branch did). Then `render-node.js` → `prepareMedia` → `prepareFonts` received `templateFontWeights = null`, so it registered **every font at weight 700 ONLY**. Templates/text-presets that request weight **900** (Science Lab = Exo 2 classicBold question weight 900; Space Odyssey = Orbitron; also corporate/neon/tech/fire/etc.) made node-canvas fall back to a broken tiny default font → question text, some options and the brand name misrendered ("unreadable"). The browser preview worked because the browser @font-face declares all weights.
- **Fix 1**: `server-renderer.js buildPlanAndState()` now writes `settings.templateFontWeights` in the `apply()` branch (persisting the template's real weights).
- **Fix 2 (defense in depth)**: `media-prep.js prepareFonts()` now always registers the full **400/700/900** set for every font family (all bundled fonts are single-weight files; registering all three buckets with the same file is harmless and makes any template or text preset work regardless of requested weight).
- **Verified through the FULL real pipeline** (build → prepareMedia → unified renderer → PNG):
  - Science Lab: question, brand, ALL 4 options readable (was: garbled).
  - Space Odyssey: question, brand, ALL 4 options readable (was: first option only).
  - Regression check: corporate, neon, tech, fire — all 4 options + question + brand readable.
- **Plugin version bumped to 1.4.9.35** (cache-busts all changed assets).


## [1.4.9.34] - 2026-08-11 — Remove system fonts, use bundled fonts everywhere
- **No more system-font dependence — every template font is now a bundled, registered font**:
  - **Minimalist secondary**: `Arial` (system) → **Lato** (bundled `Lato-Bold.ttf`, already in server fontMap + browser @font-face). Browser @font-face now declares Lato at 400/600/700 (was bold-only) so the weight-600 request never falls back.
  - **elegantSerif text preset** (History template): hardcoded `Georgia, "Times New Roman", serif` (system serif) → **"EB Garamond"** (bundled `EBGaramond-Bold.ttf`). Browser @font-face now declares EB Garamond at 400/700/900 (was bold-only).
  - **Template-manager fallbacks**: `"Arial"` defaults → `"Inter"` (2 spots). Cover-editor legacy draw `Arial, sans-serif` → `Inter, sans-serif` (2 spots).
  - The `80px sans-serif` in `drawCTAEmoji` are intentional — they render emoji glyphs (thumbs/like/share/comment/follow/link), which need the system emoji font, not a bundled text font. Left as-is.
- **Verified**: full-system-font scan returns ZERO matches (no Georgia/Times/Helvetica/Verdana/Tahoma/Arial anywhere in JS/PHP/render). Render-tested minimalist (Lato) and history (EB Garamond) — both OCR-readable.
- **Plugin version bumped to 1.4.9.34** (cache-busts all changed assets).


## [1.4.9.33] - 2026-08-11 — All-template readiness audit + server font-weight fix
- **Full readiness audit of all 18 templates** (fonts, background animation, readability) — verified by rendering every template through the real server pipeline (fonts registered via media-prep) at two timestamps and OCR-checking:
  - All 18 templates render the question + options **OCR-readable** (question text ~104-106px tall — not tiny).
  - Backgrounds: 12 templates animate (`animated: true`, meshGradient — confirmed t1→t2 pixel diff 26-33); 6 are static by design (`animated: false`: minimalist, elegant, horror, classroom, history, quizwire).
  - Quizwire + minimalist use light backgrounds (readable dark text — quizwireBold / minimalClean); all others dark backgrounds with light/neon text.
- **Server font-weight registration fixed (latent "unreadable text" bug)**:
  - Root cause: templates request non-standard weights (`corporate/minimalist/neon/space/nature/science/tech/trivia` use `500`/`600`), but `prepareFonts` only registered weights from `weightFileMap` + hardcoded `700`. node-canvas then fell back to a tiny default font for those weights — the same class of bug as the earlier Science/Exo 2 issue, but for any template using a weight-500/600 family.
  - Fix: `prepareFonts` now normalizes every requested weight to the 400/700/900 buckets we actually register (500/600 → nearest bucket). Verified: corporate (weight 500) renders question OCR-readable with the fix.
- **Browser @font-face completeness**: added **Roboto Mono** (used by Science Lab + Electric) `@font-face` 400/700 — it was registered server-side but missing in the browser CSS, so Science/Electric previews would fall back. All 27 template font families are now shipped + server-registered + browser-registered (Arial is a system font, always available).
- **Plugin version bumped to 1.4.9.33** (cache-busts all changed assets).


## [1.4.9.32] - 2026-08-11 — Template readability fixes (retro80s, Science) + per-topic template pipeline
- **Science Lab template readability fixed**:
  - Root cause: the template's primary font **'Exo 2' did not exist anywhere** — no `.ttf` in `assets/fonts`, no entry in the server `fontMap` (`media-prep.js`), and no `@font-face` in the browser CSS (`class-vs-core.php`). Both browser and server fell back to a default font (and the `bold` request on a missing family triggers the known node-canvas tiny-font bug), so questions and the brand text were unreadable in every pipeline.
  - Fix: shipped **Exo2-Regular.ttf** (OFL) in `assets/fonts`, added `'Exo 2': 'Exo2-Regular.ttf'` to the server `fontMap`, and added `@font-face` (400 + 700) to the browser CSS. Verified: Science Lab now renders "Which planet is known as the Red Planet?" cleanly in Exo 2, OCR-readable.
- **Retro 80s template readability fixed**:
  - Root cause 1: the brutalist cards were **hardcoded white** (`_drawBrutalistCard` fill `#ffffff`), and the retroArcade preset draws magenta `#FF00FF` question text with a 30px magenta glow on that white card → poor contrast + glow washout.
  - Root cause 2: **'Press Start 2P'** is a very wide display pixel font — long questions auto-shrunk to tiny unreadable sizes.
  - Fix: `_drawBrutalistCard` now accepts a `fillColor` (default white for back-compat); retro80s passes dark `#0D0221` so neon text pops. Fonts changed to **Orbitron** (primary, readable + retro-futuristic, ships locally) + **VT323** (options). RetroArcade glow blurs tightened (30→14, 20→10, 35→16) to remove washout. Verified: OCR-readable question + options on dark cards.
- **Per-topic template now respected end-to-end**:
  - **CSV**: new `template` column added to `Aug-26-videos-v3.csv` (per-topic, mapped by niche/topic keywords → science/history/nature/space/tech/sports/elegant/quizwire). The importer already supported the column; its `$available_templates` allow-list **excluded** science/nature/space/quizwire/retro80s — now includes all 18 readable templates (fallback changed from 'corporate' to the brand 'quizwire').
  - **Content Planner auto-rotate**: new `VS_Content_Planner::guess_template_for_topic($topic, $niche)` — when no template is set (no CSV column, no per-topic style, no batch style), the template is derived from topic keywords/niche (history→history, space→space, animals→nature, science→science, tech→tech, sports→sports, food/landmarks→elegant, else deterministic rotation). `create_job_for_topic()` now uses it instead of the silent `'trivia'` default.
  - Chain verified: CSV `template` → importer (allow-list) → `$item_styles['template']` → job settings → headless renderer → server-renderer `templateId` → `MCQVS_VideoTemplates.apply` + `getTemplate`.
- **Plugin version bumped to 1.4.9.32** (cache-busts all changed assets; new Exo2-Regular.ttf ships in the zip).


## [1.4.9.31] - 2026-08-11 — Cover card WYSIWYG: full pipeline parity (brand header + quiz name + timer)
- **Video Cover card now renders through the FULL `template.render()` pipeline** for BOTH modes (`scene` and `first_q_mid`), exactly like the preview (`_renderAt` → unified renderer → `template.render`) and the headless server render.
  - Root cause: the card previously called `drawBackground()` + `drawQuestion()` / `drawCover()` directly, which **bypassed the branding layer, corner logo and post-processing** — so in `first_q_mid` mode the card showed only the bare question card while the preview/server frame showed brand header ("TheQuizWire"), quiz name, difficulty badge and timer.
  - Fix: `vs-cover-editor.js _renderPreview()` now builds a full render state (branding, template colors/fonts/effects, textEffects, logoPosition, coverConfig, per-scene timing) and calls `_tpl.render(ctx, state, assets)` — the same entry point the real renderers use. `first_q_mid` renders the first question at 50% of its duration; `scene` renders the cover scene.
  - Verified (render + OCR at 270×480): `first_q_mid` card now shows brand header + quiz name + EASY badge + question + options (matches the preview screenshot); `scene` card shows the hook-first cover.
- **Server-extracted cover PNG was already correct** (it grabs a frame from the fully-rendered video, which includes branding) — the mismatch was card-only. Now all three (card, preview, server PNG) are identical for the same timestamp.
- **Plugin version bumped to 1.4.9.31** (cache-busts all changed assets).


## [1.4.9.30] - 2026-08-11 — Hidden hook / disabled cover: first question starts immediately (ALL pipelines)
- **Root cause**: the hook SCENE was added to every playlist whenever hook text existed, even when `hookVisible === false` — the scene rendered nothing (blank ~1.2s) but still consumed timeline time, so the first question always started late. (The cover scene was already gated correctly on `coverConfig.enabled`.)
- **Fixes (SSOT across all playlist builders + duration math)**:
  - `plan.builder.js` (browser preview), `server-renderer.js` (node headless), `studio.export.js buildPlaylistForExport` (worker export + browser-headless runner): the hook scene is now only added when `hookVisible !== false`.
  - `studio.controller.js` `totalDurationMs` and `studio.preview.js getTotalDurationMs`: hidden hook contributes **0** time.
  - Content Planner → headless already carries `hookVisible`; the removed hook scene also removes the hook TTS event (no spoken hook over Q1).
- **Verified all 4 combos** (browser + server builders):
  - cover ON + hook ON → cover@0, hook@1000, Q1@2200 (unchanged)
  - cover ON + hook OFF → cover@0, **Q1@1000** (no dead hook gap)
  - cover OFF + hook ON → hook@0, Q1@1200 (unchanged)
  - cover OFF + hook OFF → **Q1@0ms** (first question starts immediately)
- **Plugin version bumped to 1.4.9.30** (cache-busts all changed assets).


## [1.4.9.29] - 2026-08-11 — Reveal animation fix + "first question mid-timer" cover mode
- **Reveal animation now works in the Studio preview (and worker export)**:
  - Root cause: the QuizWire template was missing from the `_mcqvsAttachContracts` list in `vs-video-templates.js`, so it had no `getCuePoints()`. The plan builder's FX attachment silently skipped when `templateCfg.getCuePoints` was missing → the plan carried **no `fxEvents`** → the unified renderer never fired reveal particles/shake/timer-glow (and the audio router got no SFX/ducking) in preview, while server renders (which have their own fallback) did.
  - Fix 1: added `quizwire` to the contracts list (canonical FX/SFX with per-template intensities).
  - Fix 2 (robust): `plan.builder.js` now derives `fxEvents`/`sfxEvents`/`duckWindows` from `plan.cues` as a fallback whenever a template lacks `getCuePoints` — so ANY future template gets reveal FX without a contract entry. Verified: quizwire plan now carries 16 fx events incl. 2 `particles_burst`, tick/glow/shake, plus SFX + duck windows.
- **NEW "First question (mid-timer)" cover mode** (`cover_config.mode`):
  - `scene` (default): cover = branded cover scene at frame 0 (current behavior).
  - `first_q_mid`: the cover image = the frame at **50% of the first question's duration** (all 4 options + half timer — the quiz content itself becomes the poster).
  - **Video Cover card** (`vs-cover-editor.js`): new "Cover Image Source" dropdown (scene / first_q_mid). The card preview renders the real first-question frame at mid-timer via the template manager (WYSIWYG — what you see is what the server extracts). Config persisted via `mcqvs_save_cover_config`.
  - **Content Planner / headless**: `render-node.js` cover-PNG extraction now seeks to the first-question midpoint when `mode === 'first_q_mid'` (verified: q1 start 2200ms + half of 7700ms → extract at 6.050s), else frame 0.
  - PHP `ajax_save_cover_config` / `ajax_get_cover_config` accept + default `mode` (`scene`).
- **Plugin version bumped to 1.4.9.29** (cache-busts all changed assets).


## [1.4.9.28] - 2026-08-11 — Studio preview: browser-speech TTS (no-server option)
- **Studio preview can now use browser SpeechSynthesis with ZERO server dependency**:
  - Root cause: the plugin's default TTS provider is `webspeech`, but the Studio controller seeded the voiceover with `webspeech → edge` mapping, so every preview hit the server (and only fell back to browser speech after a failed AJAX round-trip — slow, and silent if Node/ffmpeg is missing on the server).
  - Now the Studio **honors `webspeech`**: `studio.controller.js` (TTSManager init + voiceover seed) and the `studio.ui.js` fallback seed keep `webspeech` as-is, with `enabled: true` and `rate 1.2`. Preview plays instantly via `MCQVS_TTSManager`/`speechSynthesis` — no server. Pause/Stop still cancels it (`_stopVoiceover` stops WebSpeech + audio). The `#ttsProvider` dropdown lets you switch to edge/google/azure for server TTS anytime.
  - **Content Planner / headless are NOT affected**: they still normalize `webspeech → edge` server-side (`class-vs-content-planner.php` `get_studio_render_defaults()`, `class-vs-headless-renderer.php`) and the export path in `studio.ui.js` already forces server TTS when the provider is webspeech (preview-only). Rendered videos always use server TTS.
- **Plugin version bumped to 1.4.9.28** (cache-busts all changed assets).


## [1.4.9.27] - 2026-08-11 — QuizWire readability fix + Studio TTS defaults
- **QuizWire Brand template readability fixed (sidebar + preview + rendered video)**:
  - Root cause: the `classicBold` text-effect preset fills ALL text WHITE (designed for dark glass cards). QuizWire uses white solid cards → white-on-white, unreadable everywhere.
  - Added a new **`quizwireBold`** text-effect preset (`vs-text-effects.js`): near-black `#111111` question/option/hook text with a subtle shadow, red `#E50914` timer, dark correct answer (white card + green border). Matches the channel's Canva design (white bg / black text / red accent).
  - `QuizWire Brand` template now uses `textEffect: "quizwireBold"`. Render-verified: question, hook and reveal scenes all OCR-readable on the white card (was white-on-white).
  - **Sidebar template cards** now use `tpl.colors.text` for the template name instead of hardcoded white — light templates (QuizWire, Minimalist) show dark names, dark templates keep white. (Also improves Minimalist, which had the same latent issue.)
- **TTS fully working in Studio preview**:
  - Root cause of "no TTS": Studio seeded `voiceover.enabled: false`. Now defaults to **true** (matches Content Planner/headless defaults — SSOT) with **rate 1.2** (matches server default).
  - Verified the full chain: `playPreview()` → `audio.playFrom()` builds voiceover events (respecting speakHook/speakOptions/speakAnswer/speakCta), starts music+SFX via the router; `pausePreview()` → `audio.pauseAt()` cancels TTS + pauses music/SFX; `stopPreview()` → `audio.stopAll()`. Edge TTS via AJAX (`mcqvs_generate_tts`), webspeech fallback for browsers, overlap guard prevents TTS stacking.
  - The TTS panel toggle still works to turn voiceover off per-project.
- **Plugin version bumped to 1.4.9.27** (cache-busts all changed assets).


## [1.4.9.26] - 2026-08-11 — Cover editor WYSIWYG + "Disable Video Cover" fix
- **Cover card now matches the actual video (WYSIWYG)**: the Studio "Video Cover" card was hand-rolling its own logo+brand+quizName layout that never matched `TemplateManager.drawCover()` (hook-first), so it looked different from the preview. `vs-cover-editor.js _renderPreview()` now calls the REAL `drawCover()` via `MCQVS_TemplateManager.getTemplate(...)` with a state mirroring the controller (hookText, quizName, brand, template colors/fonts, coverConfig, logo). The card now shows the exact hook-first cover the video will have. Falls back to the legacy draw if the template manager isn't loaded.
- **"Disable Video Cover" now actually works in the preview**: the toggle set `state.coverConfig.enabled=false` but only called `_renderAt(0)` on the CACHED plan, so the cover scene persisted. `_pushToController()` now calls `_invalidateRenderPlan()` so the next render REBUILDS the plan without the cover scene (verified: enabled → `cover,hook,question,outro`; disabled → `hook,question,outro`).
- **SSOT — cover gating consistent across ALL render paths** (was only honored by plan.builder):
  - `studio.export.js buildPlaylistForExport()` now adds the 1000ms cover scene gated on `coverConfig.enabled !== false` (was the only path that never added it).
  - `server-renderer.js buildPlanAndState()` now gates the cover scene on `settings.cover_config.enabled !== false` (was unconditional — server renders would have kept the cover even when disabled).
- `refreshFromState()` syncs `hookText` so the card updates when the hook text changes.
- **Plugin version bumped to 1.4.9.26** (cache-busts all changed assets).


## [1.4.9.25] - 2026-08-11 — Emoji-safe on-screen text + CSV BOM
- **Emoji in CSV hooks — supported, with a safety net**:
  - Importer already handles UTF-8 emoji (string-based parsing; `sanitize_text_field` preserves multibyte). CSV regenerated with a **UTF-8 BOM** so Excel on Windows reads it as UTF-8 (not garbled ANSI) — emoji verified intact after round-trip.
  - Captions/titles: emoji **fully supported** on IG/FB/YT (Buffer `{hook}` placeholder uses the original string).
  - On-screen video: node-canvas **cannot reliably render color emoji or flags** (monochrome at best, tofu boxes on minimal VPS fonts — verified by render test: 0 colorful pixels). Added new setting **Settings > Defaults & Scheduling > "Strip Emoji from On-Screen Text"** (default ON) that strips emoji from the hook text AND explanation text before the server render payload is built (`class-vs-headless-renderer.php`). Captions/YouTube titles are NOT affected — they keep the emoji.
  - The strip keeps terminal `?`/`!` (curiosity hooks intact) and collapses leftover whitespace. Verified: `🏝️ The island 3 countries share — can you name it?` → on-screen `The island 3 countries share — can you name it?`, caption keeps `🏝️`.
  - If you install a color emoji font (`fonts-noto-color-emoji`) on the render VPS, turn the setting off to keep emoji on-screen.
  - Browser preview/export path (Studio) is unaffected — browsers render emoji natively in color.
- **Settings canonical lists updated**: `mcqvs_tts_speak_options`, `mcqvs_show_explanation`, `mcqvs_strip_emoji_on_screen` added to the global hidden-settings list AND the correct per-tab skip lists (`api` tab for the TTS option; `buffer` tab for the two Defaults & Scheduling options) — prevents cross-tab save data loss.
- **Plugin version bumped to 1.4.9.25** (cache-busts the settings.js/css + all changed assets).


## [1.4.9.24] - 2026-08-11 — Version bump + SSOT audit fixes
- **Plugin version bumped to 1.4.9.24** (Version header + `MCQVS_VERSION`). All 63 `wp_enqueue_script`/`wp_enqueue_style` calls were audited: every plugin asset versions with `get_asset_version()` (= `MCQVS_VERSION` in production, `time()` in dev); the two third-party libs (jszip, mp4-muxer) are pinned to their library versions (correct); settings.css/settings.js use filemtime-based `get_asset_file_version()` (busts on edit). Bumping to 1.4.9.24 therefore cache-busts every changed JS/CSS in production.
- **SSOT audit — timing now consistent across ALL pipelines** (was divergent):
  - Base shorts timing aligned everywhere to **7700ms/question** (questionAppear 600 + optionsAppear 500 + userThinkTime 4600 + reveal 2000), hook 1200ms, outro 3200ms:
    `studio.controller.js` state defaults, `server-renderer.js` + `render-node.js` server fallbacks (questionTotal 7700, phases {600, 5100, 2000}), `plan.builder.js` fallback, `studio.export.js` `getTimingForWorker()` fallbacks (were stale 2000/1500/3000/1000/8000/5000), `render-runner.js` seed timing (was stale 12s/question → browser-headless queue renders would have stayed long!), `class-vs-timeline-manager.js` default, `vs-self-test.js` sample.
  - YouTube/long-form fallbacks intentionally keep the classic roomy timing (2000/12000/5000) — correct per-format divergence, not a bug.
- **Cover duration bug fixed**: my previous "~1s cover" was actually 1 frame (`Math.round(1000/fps)` ≈ 42ms) — shorter than the original 2-frame cover. Now a true **1000ms** in `server-renderer.js` + `plan.builder.js` (SSOT), so IG/FB/TikTok/YT can actually capture frame-0 as the poster/thumbnail.
- **Hook SSOT (AI path → on-screen) fixed**: the Content Planner AI path stored the real hook in `settings['hook']` but left `hookText` at the generic default — the video rendered "Can you score 5/5?" while the caption got the real hook. Now `create_job_for_topic()` promotes a real hook over the generic default, and `class-vs-headless-renderer.php` treats generic defaults as empty (prefers the topic hook). CSV path unchanged (CSV hook → hookText already).
- **Headless voiceover fallback aligned**: `class-vs-headless-renderer.php` fallback voiceover now uses `rate 1.2` + configurable `mcqvs_tts_speak_options` (was hardcoded 1.0/true) — matches `get_studio_render_defaults()` (SSOT).
- Verified: `normalizeQuestion()` spreads `{...q}` so `difficulty`/`explanation` survive into Studio; `studio.audio.js` honors `vo.speakOptions`; Buffer `$replace_vals` is defined before per-channel caption resolution and flows as `placeholder_data` to the YouTube title; export plans use `buildFromState` (cover scene included) so preview/export agree.


## [1.4.9.23] - 2026-08-11 — Viral Shorts tuning + logo fixes
- **Plugin version bumped to 1.4.9.23** (`Version:` header + `MCQVS_VERSION`) so production cache-busting serves the new JS.
- **New "QuizWire Brand" template**: signature white/black/red high-contrast look matching the channel's Canva cover (Inter bold, sharp solid cards, red accent). Added to `vs-video-templates.js` (category: professional, id `quizwire`) — pure addition, existing 17 templates untouched. Select it in the Studio template picker (and optionally set as your default template for new projects).
- **Format-aware pacing (Shorts vs Long-form)**: `server-renderer.js`, `render-node.js`, `studio.controller.js`, `plan.builder.js` now use Shorts-first defaults (hook 1.2s, ~7.2s/question, 3.2s outro → a 5-Q Short lands ~40s) while long-form (`youtube` format) keeps the classic roomy timing. `computeAdaptiveTiming()` got format-aware caps: Shorts min 5.2s / max 11s per question (was 8s/25s) so slow TTS can't balloon a Short; long-form unchanged. Verified: 5-Q Short with mixed TTS now renders ~32s.
- **Faster default TTS rate**: Content Planner voiceover default `rate` 1.0 → 1.2 (+20%) to keep question scenes short.
- **Configurable "Speak Options Aloud"**: New Settings > Text-to-Speech checkbox `mcqvs_tts_speak_options` (default ON). When OFF, the 4 answer options are no longer read aloud (question + answer still spoken) — the largest TTS time saver. Consumed by `get_studio_render_defaults()` and seeded into the Studio voiceover defaults via `MCQVS_Config.tts.speakOptions`. Uses hidden-`0` pattern so unchecking actually persists.
- **Question-aware hooks + hashtags**:
  - Batch Content Planner prompt now requires the hook to be derived from one of the generated questions (not a generic phrase) and caps questions at 12 words.
  - News Card (`ajax_generate_news_quiz`) now returns `{hook, hashtags, questions}` (object schema) — hooks derived from headlines/questions; Studio auto-fills the hook text and merges hashtags into SEO tags.
  - Topic Card (`ajax_generate_topic_quiz`) generates a question-aware hook + hashtags via one extra AI call after questions exist (fails soft — never blocks generation). CSV-imported topics still skip AI entirely (CSV supplies hook/hashtags).
- **Hook-first cover (frame-0)**: `drawCover()` in `vs-template-manager.js` now renders the HOOK text as the hero (with legibility band + small brand footer) instead of the quiz-name badge, so the first frame is a curiosity scroll-stopper and a viable thumbnail for IG/FB/TikTok/YT. Falls back to the classic logo+brand+quizName layout when no hook exists. Cover scene extended from ~83ms (2 frames) to ~1s so social platforms can capture it. Render-verified at 9:16 and 16:9 (Youtube format) with node-canvas.
- **Logo fixes**:
  - (Gap 1) `studio.export.js` worker config now passes `logoPosition` (was missing → worker always rendered as `all`).
  - (Gap 2) `render-runner.js` `applyJobSettings()` now actually loads the logo image into `state.brandLogoImage` (was never loaded → logo absent in browser-headless renders), with a CORS-safe loader that retries without `crossOrigin`.
  - `vs-render-worker.js` frame state now includes `hookText`/`hookVisible` so the hook-first cover renders identically in worker exports.
- **AI prompt quality overhaul** (MCQ generation + hooks):
  - All three generation prompts (batch Content Planner, single Topic Card, News Card) now require: ALL four options plausible (never silly), FACT ACCURACY (never invent figures/dates/people), at least one surprising "wow" fact, questions ordered EASY → MEDIUM → HARD, and concise questions (12 words batch/topic, 15 news). Exam list expanded to CSS/PMS/NTS/FPSC/PPSC.
  - New optional `difficulty` + `explanation` fields in all three response schemas; normalized and preserved through batch/topic/news formatting (legacy responses without them still work — fully backward compatible).
  - Manual "Generate Hooks" tool (`ajax_generate_hooks`) now accepts the actual quiz questions (`questions` POST field) and derives hooks from the most surprising fact, no longer topic-name-only.
  - Hooks now must avoid spoiling the answer.
- **`difficulty` + `explanation` now actually USED in the video** (previously preserved but unrendered):
  - New `_drawDifficultyBadge()` in `vs-template-manager.js` renders an EASY/MEDIUM/HARD pill on every question card (green/amber/red), using the AI/CSV `difficulty` field. Portrait + landscape, render-verified.
  - New `_drawExplanationBar()` renders a one-line 💡 learning bar at the bottom ~0.65s into the reveal (uses the AI `explanation` field) — the "teach after the answer" moment. Portrait + landscape, render-verified.
  - CSV-imported questions already carried `difficulty` (importer stored it); AI prompts now return both fields; all three generation paths preserve them.
- **Buffer caption placeholders upgraded + honest audit**:
  - New placeholders: `{firstquestion}` (first question teaser from quiz_data), `{link}` (site URL — falls back to `home_url()` = thequizwire.com), `{part}` / `{part_total}` (series numbering from Content Planner).
  - Shared `VS_Buffer_Client::substitute_placeholders()` used by the global caption, per-channel captions, AND the YouTube title (which previously advertised `{topic}` etc. in Settings but never actually substituted them — now fixed).
  - Default caption template upgraded to include the first-question teaser + site link (drives traffic to thequizwire.com). Installations still on the legacy default are auto-migrated on next push; custom templates are untouched. Unknown placeholders are preserved (never stripped).
  - Settings help texts updated to document the full placeholder set.
- **"Show Answer Explanations" toggle** (Settings > Defaults & Scheduling):
  - New `mcqvs_show_explanation` setting, **default OFF** (ultra-minimal Shorts — the on-screen 💡 explanation bar is hidden by default).
  - Wired through every render path: `class-vs-core.php` config → Studio editor seed, `studio.export.js` worker config, `vs-render-worker.js` frame state, `render-runner.js` (browser-headless), `server-renderer.js` (node headless), `class-vs-headless-renderer.php` settings whitelist (uses `array_key_exists` so an explicit `false` isn't swallowed by `empty()`), and `class-vs-content-planner.php` job defaults.
  - `_drawExplanationBar()` in `vs-template-manager.js` now only renders when `state.showExplanation === true`. Difficulty badge is independent and always shows. Render-verified: OFF = bar area empty, ON = bar appears.
- **Sample content CSV upgraded** (`Aug-26-videos-v2.csv`): added `hook` + `hashtags` columns for every topic (kills the random-hook fallback), reordered every topic's questions EASY→HARD, and added 10 Pakistan / Current Affairs topics (50 questions) — the channel's exam-prep niche that the original CSV had zero of. Original questions untouched.


## [1.4.9.22] - 2026-08-10
- **Per-Channel Buffer Caption Templates (Pencil Icon)**: Each enabled channel in a Buffer account card now has a `&#9998;` pencil button. Clicking it expands an inline editor row containing a textarea scoped to that channel only. The same `{topic}`, `{score}`, `{total}`, `{hook}`, `{hashtags}` placeholders as the account-level template are supported. An empty per-channel template falls back to the account-level caption. Templates are stored in the new `channel_captions` map inside `mcqvs_buffer_accounts` (registry) or the new legacy option `mcqvs_buffer_channel_captions`. UI is rendered server-side from the registry getters so the source of truth matches what the push pipeline reads at runtime.
- **Per-Channel "Post to Stories" Tick (Facebook + Instagram only)**: The channels table inside each account card now has a `Story` column. For services that support story posts on Buffer (`facebook`, `instagram`), a checkbox appears; ticking it forces `post_type=story` on every push to that channel regardless of the `Post Type` dropdown. Threads was removed from the story-capable list — Buffer does not support Threads stories (only regular posts). Other services (Twitter/X, YouTube, TikTok, LinkedIn, etc.) show `—`. Persisted in the new `channel_post_to_story` map on the account row.
- **YouTube Title + Category Fields Only Render When a YouTube Channel Exists**: The account-level `YouTube Title` text input and `YouTube Category` dropdown (already present per account) are now wrapped in a conditional that only emits the form rows when at least one channel on the account has `service === 'youtube'`. Accounts without a YouTube channel no longer show the rows — exactly the "YT title input / category to appear ONLY if YT is added" requirement.
- **Service-Aware Caption Truncation (Twitter/X 280, Threads 500, Bluesky 300, Mastodon 500, Pinterest 500, etc.)**: `VS_Buffer_Client::truncate_caption_for_service()` resolves the per-service character cap from a new constant table (`get_service_char_limits()`) and applies whitespace-aware word-boundary truncation with a trailing ellipsis so the pushed text never exceeds the Buffer-side limit. Truncation happens per channel inside `create_update()`, after the per-channel caption override (if any) has been applied, so a Twitter/X channel gets its own shortened caption even when an Instagram channel receives the full-length version of the same post. Fixes the original failure mode: "Invalid post: Twitter / X posts cannot exceed 280 characters."
- **YouTube Title Hard Cap (100 chars)**: The same helper accepts the sentinel `__youtube_title__` so the account-level YouTube title is truncated to 100 characters at push time. YouTube's description (the post `text`) is bounded by the per-service cap (5000).
- **Threads Post Type Corrected**: `get_valid_post_types()` previously listed `'threads' => array('post', 'story')`. Threads on Buffer is `post`-only — the `story` entry was removed from both the PHP map and the JS map (`settings.js`) so the `Post Type` dropdown never offers a type Buffer would reject.
- **Service Char-Counter UX**: The per-channel caption editor shows a live `X / limit` counter underneath the textarea while typing (red once over the limit). Pure UX; the actual truncation still happens server-side.
- **Live Char-Counter Initialization**: On page load the existing saved per-channel captions have their counter refreshed once so previously-saved long captions are immediately visible as over-limit rather than waiting for the user to type.
- **Sanitized Per-Channel Maps (Registry Helpers)**: `VS_Buffer_Account_Registry` gains private `sanitize_channel_captions_map()` and `sanitize_channel_story_map()`. These coerce JSON strings → arrays, drop empty / malformed entries. `add_account()` / `update_account()` accept the two new maps so the AJAX save handler can persist them in a single round-trip.
- **Backward Compatibility**: Existing single-account Buffer installs auto-migrate to `channel_captions = []`, `channel_post_to_story = []` via `ensure_legacy_migrated()`. New Settings API registrations (`mcqvs_buffer_channel_captions`, `mcqvs_buffer_channel_post_to_story`) are added so the legacy single-account Settings form can persist the same maps when no registry accounts exist.


## [1.4.9.21] - 2026-08-09
- **Render Claim/Spawn Race Fix (jobs randomly failing with `render_process_died (pid=0, no completion marker)`)**: Root cause: `VS_Job_Repository::claim_job_for_render()` flips the row to `RENDERING` in the DB first and only THEN schedules the `mcqvs_render_claim` Action Scheduler action which actually spawns `render-node.js` and stamps `mcqvs_render_pid_`. A concurrent `vs_headless_render_cron` tick sweeping `RENDERING` rows inside that sub-second window interpreted "rendering + no pid + no completion marker" as a dead render and failed the job ~1s after claim — the spawn action then fired to find the job already `FAILED`. Fixed by a 180s spawn-grace window keyed on `started_at` (UTC), applied in both places:
  1. `VS_Automation_Engine::run_headless_render_queue()` — the render completion sweep now skips `RENDERING` rows whose `started_at` is younger than 180s (pending spawn).
  2. `VS_Headless_Renderer::reap_dead_render()` — defense-in-depth: when no pid transient exists and `started_at` is younger than 180s, returns without reaping.
  The pid-based reaping branches remain fully active, so a node process that spawned and died is still reaped with its real exit code / node error; the existing `exit_hint===0` auto-retry still fires for genuinely externally-killed renders after the grace window.


## [1.4.9.20] - 2026-08-07
- **True Concurrency Cap for Rendering**: `VS_Automation_Engine::run_headless_render_queue()` now enforces a real concurrency limit. Previously `mcqvs_render_concurrency` (default 1) only capped how many jobs were claimed per 5-min tick, so a second render would start every tick even while the first was still rendering — renders overlapped despite concurrency=1. The queue now counts active `RENDERING` jobs and, when the cap is reached, skips claiming new renders that tick (the completion sweep, auto-cleaner and job recovery still run). With concurrency=1, videos render strictly one at a time; the rest wait in `READY_FOR_RENDER`.
- **Rendering Card Shows ALL Active Renders**: The Dashboard "Pipeline Status → Rendering" card previously showed only the first rendering job's progress bar. It now lists every job currently in `RENDERING` state (up to 50), each with its own topic label and progress bar.
- **Per-Job Progress Bar Colors**: Each rendering job now gets a distinct bar color from a 6-color palette — in the Rendering card (assigned in render order) and in the "Pipeline Jobs" table (stable hash of `job_id`). Concurrent renders are individually trackable at a glance. Progress polling (`mcqvs_get_render_progress`) already updates all bars independently.


## [1.4.9.19] - 2026-08-07
- **Auto-Cleaner No Longer Kills Waiting Calendar Jobs**: `VS_Job_Repository::clear_stuck_jobs()` measured PENDING staleness against `created_at` (import time), so every calendar-scheduled CSV job (7–31 Aug) whose render time was >2h in the future was swept to `failed` 2 hours after import. The PENDING sweep now keys on `scheduled_at` (the job's actual due processing time). Jobs waiting for their scheduled slot are untouched; only PENDING jobs whose scheduled_at passed >2h ago (genuinely stuck) are failed.
- **Auto-Recovery of Mistakenly-Failed Jobs**: New `VS_Job_Repository::recover_failed_jobs($force)` heals only rows carrying the auto-cleaner `[stuck-fail@` marker (bounded by `retry_count <= 2`, or `$force` for the manual button). Calendar jobs with a future `scheduled_at` are restored to `PENDING`, jobs with `quiz_data` to `READY_FOR_RENDER`, and the marker is stripped from `error_message`. `VS_Automation_Engine::run_headless_render_queue()` calls it on every 5-min tick and re-schedules `vs_process_job_event` for recovered PENDING jobs so the PENDING→READY_FOR_RENDER transition still fires at the right time.
- **Manual "Recover Failed Jobs" Button**: New sidebar button on the Content Planner page next to "Process Pending Batches Now" (with JS handler) calls the new `mcqvs_recover_failed_jobs` AJAX endpoint, forcing recovery of ALL auto-cleaned failed jobs immediately and re-scheduling their processing — including jobs whose slot already passed (they render now) and future-dated jobs (they wait until their slot).
- **Process Pending Batches Now (role unchanged)**: The existing button only runs the Action Scheduler queue (`do_action('action_scheduler_run_queue', 'mcqvs_planner')`) for AI question-generation batches. It does not reset failed jobs or start headless renders; use the new "Recover Failed Jobs" button for failed job recovery.


## [1.4.9.18] - 2026-08-05
- **CSV Import with MCQ Questions**: Excel/CSV importer now accepts per-row MCQ columns (`question`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_answer`) alongside `topic`, `publish_date`, and `publish_time`. Multiple CSV rows that share the same topic+date+time collapse into a single Content Plan entry whose `_inline_questions[]` carries the full question set. AI/Gemini is skipped for fully-CSV-imported topics and called only for mixed imports that still need generation.
- **CSV Correct Answer Normalization**: New `VS_Excel_Importer::normalize_correct_answer()` accepts `A`/`B`/`C`/`D`, 1-based index, 0-based index, or literal option text. Unresolvable cells are tagged with `_mcq_error` on the entry and the question is dropped (the rest of the row is still imported).
- **Intra-CSV Duplicate Detection**: The importer now dedups MCQ rows inside a single CSV using the same `md5(trim($question_text))` hash as `VS_MCQ_Repository::insert_mcq()`. Duplicates are skipped with an `_mcq_error` note, avoiding wasted bank inserts and job attempts.
- **Content Plan Save Round-Trip Fix**: `ajax_save_topic_plan()` now passthrough-preserves `niche`, `difficulty`, `platform`, `videos_per_topic`, `questions_per_video`, `save_mode`, `brandName`, `quizName`, `logoPath`, `logoPosition`, `hookText`, `hookVisible`, `publish_frequency`, `frequency`, `buffer_channels`, `_inline_questions`, `voiceover`, and `_calendar_assigned`. Previously, a user clicking "Save" in the planner UI would silently drop these fields, forcing the next batch run to re-call Gemini and lose the user's explicit answers + schedule.
- **Batch Worker CSV Path**: `VS_Content_Planner::handle_topic_batch_background()` now partitions topics into CSV-supplied vs AI-required, suppressing Gemini for the CSV path. Per-topic `_inline_questions[]` is normalized into the same `{questions, hashtags, hook}` envelope the AI path returns, so the rest of the pipeline (`create_job_for_topic()` → `vs_jobs.quiz_data` + `vs_mcq_bank`) works unchanged.

## [1.4.9.17] - 2026-08-04
- **Outro Font Weight Registration Fix (Brand + CTA tiny/unreadable)**: Root cause: `prepareFonts()` in `media-prep.js` only registered weight `'700'` for all fonts. Templates define custom weights (e.g., corporate: `normal: "500", bold: "700", heavy: "900"`). When `drawOutro` used non-700 weights for rank/URL text, node-canvas fell back to tiny system fonts. Fixed by:
  1. `server-renderer.js` now extracts `tpl.fonts.weights` → `settings.templateFontWeights`
  2. `media-prep.js::prepareFonts()` accepts 4th param `templateFontWeights`, registers each font at ALL needed weights (falls back to base Bold file for missing variants)
  3. Removed duplicate `fillText` for CTA in `vs-template-manager.js`
  4. Cleaned up debug `console.log` statements from render pipeline

## [1.4.9.16] - 2026-08-03
- **Outro Branding Readability Fix (Logo + Brand Name + CTA too small/unreadable)**: Fixed three issues in `vs-template-manager.js::drawOutro()`:
  1. Logo was not drawn in outro when `logoPosition = 'corner'` (default/top-right) — added `'corner'` to the draw condition so logo appears in outro for all position modes.
  2. Brand name minimum font size raised from 16px → 28px (was clamping to unreadable 16px on 1080p+ when text was long).
  3. CTA minimum font size raised from 14px → 22px (same clamp issue). Both minimums now ensure legibility on Shorts/vertical while still allowing clamp for very long strings.
- **Headless Renderer Font Registration Fix**: Content Planner videos rendered via headless Node.js service were using fallback "Inter" font instead of template-defined primary font (e.g. "Outfit" for trivia, "Fira Code" for tech). Root cause: two issues:
  1. **PHP→Node key mismatch**: `class-vs-headless-renderer.php` sent `currentTemplate` but `server-renderer.js` read `settings.template` (defaulting to 'trivia'). Fixed: PHP now sends both `template` and `currentTemplate`.
  2. `server-renderer.js::buildPlanAndState()` did not extract `templateFonts` from the template definition, so `media-prep.js::prepareFonts()` only registered "Inter". Fixed by extracting `templateFonts` (primary + secondary) from `MCQVS_VideoTemplates` after modules load and injecting into settings.
  3. `media-prep.js`: Fixed bug where `fontOverride` was parsed but not added to font families Set (line 98: missing `families.add()`).

## [1.4.9.15] - 2026-08-03
- **Calendar Date/Time as Render Trigger**: Content Planner now uses per-topic calendar assignments (`publish_date` + `publish_time`) to schedule video rendering. Jobs with calendar dates are created with status `PENDING` and `scheduled_at` = `publish_at` minus render buffer (default 30 min, configurable via `mcqvs_render_buffer_minutes`). The automation engine transitions them to `READY_FOR_RENDER` at the scheduled time, so videos render just-in-time for their publish slot.
- **Topic Editor Date/Time Columns**: The Generated Topics table now includes **Publish Date** and **Publish Time** columns per row. These sync with the Monthly Content Calendar — editing in the table updates the calendar and vice versa. When approving, per-topic dates are passed to the batch worker and used for render scheduling.
- **MCQ Editor (View/Edit Questions, Options, Correct Answers)**: New "✏️ Edit Questions" button on each job card in the queue opens a modal to view and edit all questions for that job. Features: add/remove questions, edit question text, modify 4 options per question, select correct answer via radio buttons. Changes are saved to both `vs_jobs.quiz_data` and the MCQ Bank (`vs_mcq_bank`) for reuse.
- **AI Batch Error Handling Improvements**: Added "Retry Failed Topics" button per batch in the progress tracker. Failed topics from a batch can be re-queued individually via new `mcqvs_retry_failed_topics` AJAX handler. Batch tracker now stores styles for retry, and partial failures are visible in the progress UI.
- **New AJAX Handlers**: `mcqvs_get_job_questions`, `mcqvs_update_job_questions`, `mcqvs_retry_failed_topics`.
- **New MCQ Repository Method**: `update_mcq()` for editing existing bank questions.
- **Automation Engine Fix**: `process_job()` now handles PENDING jobs with pre-populated `quiz_data` (Content Planner calendar-scheduled) by transitioning them to `READY_FOR_RENDER`.

## [1.4.9.14] - 2026-08-02
- **Multi-Account Buffer Support**: The plugin now supports multiple Buffer accounts. Each account has its own access token, enabled channels, daily limit, caption template, and scheduling mode.
  - New option `mcqvs_buffer_accounts` stores all accounts as a JSON array keyed by account ID (auto-generated short hash `acct_XXXXXXXX` with user-supplied label).
  - Legacy single-token installs automatically migrate to a "Default Account" (`id=default`) so existing configurations work unchanged.
  - `VS_Buffer_Client::push_job_to_buffer()` now fans out to all active accounts (per-account locks, daily limits, caches). Job-level `settings.buffer_account_id` can restrict a job to a specific account.
  - New `VS_Buffer_Account_Registry` class manages accounts (CRUD, lazy migration, per-account token/cache resolution).
  - Settings UI: new "Buffer Accounts" subsection with table (label, enabled, daily limit, scheduling mode, caption template, set-as-default, delete) and "Add Account" form.
  - New AJAX handlers: `mcqvs_add_buffer_account`, `mcqvs_save_buffer_account`, `mcqvs_delete_buffer_account`, `mcqvs_set_default_buffer_account`, `mcqvs_refresh_buffer_account_channels`.
  - Per-account caches: `mcqvs_buffer_account_{id}_org_id`, `mcqvs_buffer_account_{id}_channels_data`, `mcqvs_buffer_account_{id}_channel_ids`, `mcqvs_buffer_pub_tracker_{id}`.
  - Uninstall cleans up `mcqvs_buffer_accounts` and all per-account caches.
  - Content Planner: `buffer_account_id` now stored in job settings when `save_mode === r2_buffer`.

## [1.4.9.13] - 2026-08-01
- **Outro Brand Text Tiny in Content Planner Videos (Font Weight SSOT)**: `drawOutro()` hardcoded font weight `900` (Black) for the brand name, but `media-prep.js` only registers template fonts (Outfit/Inter) at weight `700` (Bold). On Windows node-canvas (Cairo-based), requesting an unregistered weight causes the font to silently fall back to a tiny default system font, making the brand name unreadable in server-rendered videos while the Studio Editor (browser, Google Fonts loaded) renders correctly. Changed all 3 occurrences of `900` to `bold` (CSS keyword = 700, which IS registered). This matches the CTA line which already used `bold`.

## [1.4.9.12] - 2026-08-01
- **AI Hashtags + Hook for Video Topics**: The Content Planner batch-quiz AI prompt (`VS_AJAX_AI_Quiz_Handler::generate_batch_topic_quiz_data`) now asks the model to return, per topic, 3–5 highly relevant social-media hashtags (single words, no `#`, comma/space separated) and one short viral hook line (max 8 words, starting with a relevant emoji). The response schema was extended with `hashtags` + `hook`, and both are normalized server-side by the new `VS_AJAX_AI_Quiz_Handler::normalize_hashtags()` and `normalize_hook()` (strips `**`, backticks, leading `-/*/#`, dedupes + lowercases tags, prefixes `#`, caps at 5 tags / 120 chars, preserves emoji).
- **`{hashtags}` + `{hook}` Buffer Placeholders**: Per-topic share metadata is now persisted into `job_settings` by `VS_Content_Planner::create_job_for_topic()`. `VS_Buffer_Client::push_job_to_buffer()` now replaces `{hook}` and `{hashtags}` in the caption template alongside the existing `{topic}`/`{score}`/`{total}`. Empty values (legacy/automation jobs) are stripped cleanly so no literal placeholders or dangling blank lines reach social networks.
- **Buffer Caption Template**: Default caption template updated to a multi-line format (`{hook}`, `{topic}`, score line, `{hashtags}`), and the Settings > Buffer placeholder help text now documents `{hook}` and `{hashtags}`. The caption field is a `<textarea>` with `sanitize_textarea_field`, so newlines already render correctly on all Buffer-connected SMNs.


- **Timer Pill Countdown**: Rewrote `_drawTimerPill()` to show the full computed countdown (e.g. 14s, 16s) from scene start instead of hiding during TTS. The pill now displays `Math.ceil((revealStart - elapsed) / 1000)` at all times and adds a pulsing blink effect (color oscillation + glow pulse) in the final 5 seconds before reveal — matching the tick/glow FX events.
- **Reveal Animation SSOT (Server vs Studio)**: Fixed the fallback FX mapping in `server-renderer.js` and `studio.export.js` `realignCueDerivedEvents()` to use canonical values from `vs-video-templates.getCuePoints()`. Previously the fallback doubled particle bursts (AND logic on `reveal_start` + `reveal_correct`), hardcoded `intensity: 1` (over-bright glow) and `magnitude: 6` (weak shake) instead of per-template values, and emitted timer_glow without a `rect`. Now uses OR logic for particles, resolves `timerGlowIntensity`/`shakeMag` from the active template's `config.opts`, matching the canonical `getCuePoints` output.
- **Global Cache Busting**: Settings page assets (`settings.css`, `settings.js`) used `filemtime()` for versioning while all other 30+ enqueues used `get_asset_version()` (`time()` in dev, `MCQVS_VERSION` in prod). Added `get_asset_version()` to `VS_Settings` class so settings assets follow the same cache-busting strategy as the rest of the plugin.

## [1.4.9.10] - 2026-07-31
- **Cover Topic Font Too Small**: The quiz name badge on the cover used an auto-shrink formula capped at 36px, while the brand name rendered at ~88px (1080w). Topic text now starts at the brand font size and only shrinks to 50% of it when word-wrapping demands it. Applies to both `drawCover()` (server render) and the cover editor preview.
- **Outro Brand Name Unreadable**: `drawOutro()` overrode `OUTRO_BRAND_FONT` with `cw * 0.045` (~49px), making the brand name and CTA nearly invisible on mobile. Now uses the layout constant `OUTRO_BRAND_FONT` (~90px portrait / ~59px landscape) with auto-shrink for long names.
- **Timer Pill Shows "5" During TTS Reading**: The countdown pill appeared immediately at "5" via `Math.min(5000, revealStart - elapsed)` — displaying "5" for the entire TTS reading window (7–8s for long questions), then counting down, creating a visual rush. The pill now hides until the final 5 seconds before reveal, then counts 5→1 in real time, staying in sync with the tick/glow events.

## [1.4.9.9] - 2026-07-31
- **TTS Voice Dropdown showed "Browser Default" instead of the saved default voice**: The Studio `#ttsProvider` `<select>` defaults to its first `<option>` (`webspeech`), and `bindTTSControls()` read that raw value on load, overwriting the controller's config-seeded provider (edge + saved default voice). This routed every TTS segment through browser Web Speech and made the Voice dropdown show "Browser Default". `bindTTSControls()` now syncs the `<select>` to the seeded provider before its initial change dispatch; `bindVoiceoverControls()` does the same before hydrating the voice list. The Studio now defaults to Edge TTS with the saved default voice.
- **Hook spoken by male voice while questions used the default voice**: The hook is the first TTS segment; at t≈0 `speechSynthesis.getVoices()` is often empty (voices load asynchronously via `voiceschanged`), so no voice was set and the browser's default male voice spoke the hook, while later segments matched the configured voice once voices loaded. `MCQVS_TTSManager` now waits briefly (`_waitForVoices`, ≤500ms) before selecting a voice, so the hook and questions use the same voice.
- **TTS desync (lagging behind timer/questions)**: The TTS overlap guard in `_tickVoiceover` reads `_vo.activeUntilMs`, but nothing ever set it to a positive value — the guard was dead. Browser speech running past a cue's scheduled time made the next segment fire early, `MCQVS_TTSManager._speaking` dropped it, and audio fell progressively behind the timer. `_playVoiceoverText` now feeds `activeUntilMs` from the measured audio duration (server TTS) or the plugin's WPM estimator (web speech), so the guard holds the next cue until the current one finishes.

## [1.4.9.8] - 2026-07-31
- **Studio Init Failure ("Missing modules: MCQVS_TemplateManager")**: `mcqvs-studio-controller` now declares `mcqvs-template-manager` and `mcqvs-tts-manager` as explicit dependencies (Studio editor + System Health pages). Previously `MCQVS_TemplateManager` was only loaded via the shared enqueue block with no ordering guarantee relative to the controller, so a stale/reordered bundle left `window.MCQVS_TemplateManager` undefined and aborted studio initialization after the 3.5s dependency wait.

## [1.4.9.7] - 2026-07-31
- **TTS Default Voice (all pipelines)**: The configured "Default TTS Voice" (Settings > Text-to-Speech) is now honored by every pipeline. Previously `MCQVS_Config.tts.defaultVoice` was localized to the browser but never read by any JS, so the Studio Editor, headless render-runner, and Web Speech preview all fell back to a hardcoded `en-US-AriaNeural` or the browser's default (often male) first English voice. Fixes:
  - `studio.controller.js`: `state.voiceover` is seeded from `config.tts.defaultVoice` / `config.tts.provider` on first load; `webspeech` maps to `edge` (server-side) so the chosen voice is actually honored, and `MCQVS_TTSManager.init()` is now called with the localized `ajaxUrl`/`nonce`/provider/voice so server TTS and web-speech preview use the configured defaults.
  - `studio.ui.js`: voiceover defaults + voice-dropdown fallback prefer the configured default voice over the first option.
  - `render-runner.js`: default `state.voiceover` reads `MCQVS_Config.tts.defaultVoice`.
  - `vs-tts-manager.js` + `studio.audio.js`: Web Speech voice selection now prefers a voice matching the configured Edge short-name (e.g. "aria"), then female neural voices, then any Google/Microsoft English voice — never the browser's default male voice.
- **Background Video Missing in Rendered/Downloaded Video**: Fixes the "preview shows the bg video but the exported/renderer MP4 doesn't" bug.
  - `studio.controller.js` `extractVideoFrames`: frames are now drawn at the OUTPUT resolution (1080x1920 / 1920x1080) as JPEG instead of the source's native size (4K stock videos produced 90 full-res PNG data-URLs that OOM'd `createImageBitmap()` during export → silent gradient fallback). Also sets `state.bgVideoUrl` and clears a stale `state.bgImage` when a video is applied.
  - `render-runner.js`: bg video frames are downscaled and `state.bgVideoFrameDur` now uses the actual source duration (was hardcoded 120s/loop → slow-motion background); video replaces any stale image background.
  - `studio.export.js` `ensureBgVideoFrames`: clears stale `bgImage` after successful video-frame extraction and fixes the seek/double-resolve race that captured blank frames.
  - `media-prep.js` (server renderer): accepts the planner's native `bg_video` key and logs a clear warning instead of silently degrading to the gradient when frames cannot be extracted.
  - `class-vs-headless-renderer.php`: resolves a local `bgVideoPath` for bg videos under the plugin's `assets/bg-videos/` dir so the Node renderer reads from disk instead of an HTTP round-trip that silently failed on servers with self-signed certs / blocked outbound requests.

## [1.4.9.6] - 2026-07-31
- **Cover Parity Fix**: Rewrote `drawCover()` in `vs-template-manager.js` to use the same layout proportions as the cover editor canvas — logo at 28%, brand at 42%/36%, quiz badge at 54%/48%, matching font sizes, badge padding, border width, and corner radius. The preview and exported video now render the exact same cover as the cover editor panel.

## [1.4.9.5] - 2026-07-31
- **Cover Parity**: Bridged cover editor settings (bg_color, badge_style, brand_size, show_logo) to the main video preview and export — `drawCover()` in template manager now reads `state.coverConfig`, ensuring the cover badge, background, and logo match exactly between the cover editor, studio preview, and rendered video.
- **Cover Editor**: Cover config is now pushed to controller state on every change and on save, so the studio preview updates in real-time.
- **Export Pipeline**: Worker render state now includes `coverConfig` from the export config, ensuring exported videos use the same cover settings.
- **Content Planner**: Added `cover_config` to job settings so automated Content Planner renders inherit cover appearance.
- **Headless Renderer**: Passes `cover_config` through normalized settings to the render payload.
- **Render Runner**: Applies `cover_config` from job settings to the render state.

## [1.4.9.4] - 2026-07-31
- **Cover Editor**: Fixed cover badge showing global branding quiz_name (e.g. "Biology") instead of actual topic name — now polls `#quizName` input for programmatic value changes so topic updates are reflected immediately.
- **Template Manager**: Fixed `drawCover()` multi-line quiz name wrapping — `_wrapQuizText` helper was defined outside `VideoTemplate` class, causing `this._wrapQuizText()` to silently fail and fall back to single-line font shrink.
- **Headless Renderer**: Fixed `quizName` fallback to prefer per-job `topic_name` over global branding `quiz_name` (which is a category like "Biology", not the actual topic).
- **Video Cover**: Fixed Background Color not refreshing when the active template changes; cover preview now resolves colors from the selected template and live-updates on template switch.
- **Video Cover**: Added native color picker + clickable swatch palette derived from the current template's `primary/secondary/accent` colors, with an "Auto" reset to fall back to template defaults.
- **Video Cover**: Added "Template: <name>" caption under the color picker so users see which template's palette is active.

## [1.4.8.6] - 2026-02-26
- Studio: Fixed "ajaxPost is not a function" error in Queue Auto-Runner by adding proper alias.
- Branding: Improved logo persistence by prioritizing local data cache over remote URL during restoration.
- Branding: Added anonymous CORS support for logo images to prevent canvas tainting in the renderer.
- Branding: Softened error handling for logo loading to prevent accidental state clearing on transient errors.

## [1.4.8.5] - 2026-02-26
- Branding: Fixed Branding card preview not updating immediately after logo selection.
- Branding: Fixed Logo not restoring into preview after refresh when using URL-based logos.
- Branding: Improved state restoration robustness for logos (handles both URL and DataURL).
- Branding: Prevented potential localStorage quota failures by limiting persisted data URL size.

## [1.4.8.4] - 2026-02-26
- Audio: Improved TTS continuity in preview. Segments are now grouped to prevent mid-sentence truncation.
- Audio: Added `isSpeaking` state tracking to prevent overlapping narration segments.
- Fixed: AI Settings saving error (`ajaxPost` fallback).
- Fixed: FX/Sparkles synchronization in preview (switched to absolute timeline time).
- Fixed: Particle type names corrected to `stars` and `sparks` for reveal FX.
- Feature: Added WebSpeech support for TTS preview-only narration (works without API keys).
- Fixed: `_stopVoiceover` now correctly stops both HTML5 Audio and browser WebSpeech.

## [1.4.8.2] - 2026-02-26
- Audio: Prefetch voiceover narration for upcoming scenes to reduce lag.
- Audio: Implemented `_buildVoiceoverEvents` for deterministic narration timing.
- Fixed: Critical Studio UI startup hang caused by script loading race conditions.
- Fixed: Initializing Studio Controller now waits up to 3.5s for dependent globals.
- Fixed: Added visible error banner if Studio failure occurs on boot.
- Changed: Softened development markup contract checks to warnings to prevent initialization aborts.

## [1.4.8] - 2026-02-26
## [1.4.3] - 2026-02-25
- Fixed Smoke Test "Network Error" caused by private property access in Core.
- Fixed early AJAX registration for Smoke Test engine.
- Cleaned up Studio Controller syntax and brace balance.
- Removed braces from comments to avoid interference with counting scripts.

## [1.4.1] - 2026-02-25
### Fixed
- **Studio Interface**: Fixed critical bug where Studio UI data sources ('Data Source' and 'Templates' cards) and AI tools failed to load due to incorrectly bound AJAX actions in `class-vs-core.php`.
- **Core Refactoring**: Cleaned up over 300 lines of redundant proxy methods that were polluting the core class.

## [1.4.0] - 2026-02-23
### Added
- **UI/UX**: Professional Canvas Styling system (Glassmorphism, Neon Glow, Brutalist Retro).
- **Core**: Modular `VideoTemplate` rendering helpers for high-end video aesthetics.
- **Templates**: Extended all major templates (Corporate, Elegant, Neon, Retro) with professional canvas configurations.

### Fixed
- **Audio Stability**: Fixed audio sync and "leakage" issues where sounds would continue after stopping preview.
- **Audio Manager Refactor**: Consolidated `stopSFX` and harmonized internal tracking (Set vs Array) to prevent runtime errors and ensure complete cleanup.
- **Improved Stopping**: Added explicit halt for all active SFX clones and pending timers in Studio Audio controller.
- **AI Settings Wiring**: Wired up "AI & Services Settings" and "AI & Tools" cards in Studio UI; API keys and tool triggers are now functional.

## [1.3.5] - 2026-02-19
## [1.3.3] - 2026-02-19
### Fixed
- **Content Planner**: Fixed "undefined" JSON error in Auto-Runner.
- **Content Planner**: Fixed "Topic #1" issue—newly generated topics now correctly display their AI-assigned names in the queue.
- **Content Planner**: Added persistence for "Enable Auto-Runner" toggle (remembers your choice after refresh).
- **Core**: Enhanced `VS_Job_Repository` to prevent race conditions during job creation.
- **Content Planner**: Fixed critical 500 error in Content Planner scheduling by allowing string-based topics.
- **Content Planner**: Wired Content Planner logs to the internal `VS_Error_Logger` for better dashboard visibility.
- **Content Planner**: Fixed issue where Content Planner would schedule "0 jobs" silently.
- **Content Planner**: Added timeout protection and better error logging for bulk scheduling.
- **Core**: Restored missing `VS_Job_Repository` dependency in Core.
- **Video Download**: Restored missing `downloadVideo` method in `ExportManager` that was causing a JavaScript error after export.
- **Download Fallback**: Implemented automatic `<a>` tag fallback for browsers where `showSaveFilePicker` is blocked or unsupported.
- **UI Bug**: Fixed raw HTML snippet display in the download toast message.

## [1.3.0] - 2026-02-16
### Fixed
- **Audio Overlap**: Fixed a race condition in `MCQVS_AudioRouter` where buffer fetches could complete after playback was stopped, leading to orphaned audio.
- **Unstoppable Playback**: Implemented re-entry locks and mid-flight state verification to ensure "Stop" kills all pending audio immediately.

## [1.4.0] - 2026-02-16
### Added
- **Flexible Batch Planner**: Pivot from monolithic 30-day planner to a flexible batch system.
  - Dedicated "Content Planner" page (`admin.php?page=mcqvs-content-planner`).
  - **Batch Styles**: define Template, Font, Music, and Save Strategy per batch.
  - **Auto-Runner**: Browser-based background worker to process the "Ready" queue sequentially.
- **Hybrid Save Strategy**:
  - **Local Download**: Videos saved to Downloads folder with sorted names (`[Topic] - Part X.mp4`).
  - **VPS Upload**: Option to upload rendered videos directly to `uploads/mcq-video-studio/generated/` for server hosting.
- **Multi-Niche Support**: Generate topics for multiple niches at once (comma-separated).

## [1.2.9] - 2026-02-14
- ADDED: Auto-sync for `assets/audio/music` and `assets/audio/sfx` folders; MP3 files are now dynamically discovered and loaded into the library.
- FIXED: Music overlapping issue where multiple tracks could play simultaneously in the Library.
- FIXED: Unplanned music playback when scrubbing or pausing the timeline.
- FIXED: Path resolution for audio assets to prevent 404 errors in production/admin environments.

## [1.2.8] - 2026-02-14
- FIXED: `Uncaught TypeError: this.stop is not a function` in `studio.audio.js` when pausing/stopping preview.
- FIXED: 404 error for audio assets in WordPress admin by enforcing absolute path resolution.
- IMPROVED: Export worker initialization reliability with font loading race protection and increased timeout.

## [1.2.7] - 2026-02-12
### Added
- **Studio Editor (Pagination)**: Implemented "Next" and "Previous" buttons for question selection.
  - Allows browsing large topics/banks in batches of 10 items.
  - Automated next-page fetching: Fetches additional questions from the database only when needed.
  - Global Selection Persistence: Selected questions are remembered across multiple pages and included in the final video/batch export.
- **Backend**: Updated AJAX studio handler to support `limit` and `offset` for optimized data fetching.

## [1.2.7] - 2026-02-09
### Fixed
- **Studio Editor**: Fixed "Stuck on Loading" issue in the new Studio Editor page (`mcqvs-editor`).
  - Added `mcqvs-editor` slug to asset enqueueing logic in `class-vs-core.php`.
  - Ensured `MCQVSConfig` localization is applied to the new editor page.
- **Batch Export**: Implemented intra-chunk **Pause** and **Cancel** functionality.
  - Users can now pause/resume or cancel rendering in real-time, rather than waiting for 5-question chunks to complete.
  - Propagated signals to WebCodecs worker for immediate response.

## [1.2.6] - 2026-02-06
### Fixed
- **Preview Render**: Fixed critical bug where questions/hook/outro were not rendering in preview - only background video played.
  - Root cause 1: `timeline.engine.js` `getActiveScene()` returns `{scene, index}` wrapper but caller expected scene directly.
  - Root cause 2: Duplicate `buildFromState` function in `plan.builder.js` (removed dead code).
- **Reveal Phase**: Fixed correct answer not highlighting during reveal phase in preview.
  - Added `animationPhase` calculation matching export worker logic.
  - Added `fxEvents` and `prevElapsed` to renderState for sparkle particle support.
  - Ensures perfect preview/export parity for reveal timing.
- **Data Source Loading**: Fixed UI getting stuck when selecting Topic/Exam in Data Source dropdown.
  - Added async/await error handling to prevent unhandled promise rejections.
  - Added loading indicator ("Loading...") while fetching sources.
  - Added error notification if AJAX call fails.
- **Code Quality**: Removed duplicate function definition in `plan.builder.js`.

## [1.2.5] - 2026-02-02
### Security & Stability Hardening
- **Cache-Busting**: Replaced all `time()`/`Date.now()` with strict versioning + `MCQVS_DEV_MODE` debug flag.
- **Config**: Unified `mcqvsStudioConfig` keys into `MCQVS_Config` with runtime validation.
- **Export**: Added `checkCapabilities()` preflight (WebCodecs/Worker/OffscreenCanvas).
- **Memory**: Fixed event listener leaks in `studio.export.js`.
- **Determinism**: `prepareFonts()` now extracts loaded fonts from `document.fonts` for Preview/Export parity.
- **Hotfix**: Enqueued missing modular scripts (`timeline.engine.js`, `plan.builder.js`, etc.) on the main Studio page to fix UI initialization failure.

## [8.7.1] - 2026-02-01
### Refactor
- **Modular Architecture**: Split monolithic `studio.controller.js` into 6 focused modules (`studio.logger.js`, `studio.preview.js`, `studio.export.js`, `studio.audio.js`, `studio.ui.js`).
- **Performance**: Main controller size reduced from ~258KB to ~30KB, improving load times.
- **Logging**: Implemented `MCQVS_Logger` for structured telemetry, eliminating `console.log` spam.
- **Enqueue**: Updated asset loading to support parallel module execution.

## [Unreleased]
### Added
- **Unified Renderer**: Implemented `vs-unified-renderer.js` to share 100% of drawing logic between Preview (Canvas) and Export (Worker). This eliminates styling mismatches, missing scenes, and logic fragmentation.
- **Preview Parity**: Features like Sparkles, Camera Shake, Kinetic Text, and Safe Zones now work identically in exports.
- **System Health**: Merged "Smoke Test" (Server) and "Self-Test" (Client) into a unified "System Health" menu item `mcqvs-system-health`.
  - Moved server-side smoke test UI to "Server Smoke Test" tab.
  - Moved client-side self-test UI to "Client Self-Test" tab.
  - Refactored `vs-smoke-test-runner.js` to run independently of `settings.js`.
### Added
- **Unified Renderer**: Implemented `vs-unified-renderer.js` to share 100% of drawing logic between Preview (Canvas) and Export (Worker). This eliminates styling mismatches, missing scenes, and logic fragmentation.
- **Preview Parity**: Features like Sparkles, Camera Shake, Kinetic Text, and Safe Zones now work identically in exports.
- **Debug Scaffolding**: Added transient logging to trace render pipeline issues (removed in final build).

### Fixed
- **Quiz Generation**: Removed redundant `generateNewsQuiz` method and duplicate event bindings. Fixed `count` parameter type handling.
- **Refactor**: Normalized DOM queries in `generateNewsQuiz` and `generateTopicQuiz` to use cached element references.
- **Blank Output**: Fixed regression where `activeScene` content was not being passed to the legacy Template Manager, causing blank question slides.
- **Double Branding**: Fixed duplicate "Q" logo rendering (was being drawn by both the Renderer and the Template).
- **Warped Logo**: Fixed "glitched" logo rendering caused by unreset canvas transforms.
- **Font Fallback**: Fixed serif font issue by forcing "Inter" preload and adding robust CSS font stack fallbacks.
- **Micro-Animations**: Restored Particle/Sparkle burst effect on answer reveal.
- **Audio Sticking**: Fixed bug where music/SFX continued playing after clicking "Stop".
- **Visual Polish**: Increased Branding font size (80px), added High-Contrast shadows, and implemented CTA Icon rendering (Bell/Like/Share) for Outro scenes.
- **Split Screen Support**: Added missing renderer logic to support Split Screen Video overlays (Bottom Half) in Unified Renderer.
- **Export Diagnostic**: Added detailed error logging and fail-safe for Template rendering during export.
- **Worker Cache Busting**: Forced fresh reload of worker dependencies to prevent stale code execution errors.
- **Global Cache Busting**: Updated all asset enqueues to use current timestamp `time()` instead of `filemtime()`. This ensures immediate propagation of code changes in the browser (stops "stuck" errors).
- **Export Fidelity**: Fixed missing Quiz Name, Branding, and CTA text in exported videos by ensuring all config properties are passed to the Worker.
- **Font Rendering**: Fixed font fallback issue in Export by aligning Template weight requests (Bold/700) with loaded font resources.
- **CTA Logic**: Fixed race condition in UI handlers that caused custom text to persist even when a preset was selected.
- **Preview Parity**: Fixed Missing quiz name and CTA style in Preview mode by updating the Main Thread render state to match Worker logic.
- **Font Selection Export**: Fixed bug where exported video ignored selected Template Fonts (e.g. Outfit) and defaulted to Inter, by properly passing style config to the Unified Renderer.
- **Preview Auto-Stop**: Fixed infinite black screen loop after Outro by enforcing strictly timed stop logic when playlist duration is exceeded.
- Fixed critical bug where batch exported videos had incorrect audio duration (audio was generated for all questions instead of the current batch chunk).
- Fixed issue where "News Quiz" button was unresponsive.
- **Export Timer Parity**: Fixed issue where short TTS audio caused the video clip to shrink (e.g. 4s), breaking the visual countdown timer. Export now respects the minimum configured duration (10s).
- **Export Progress UI**: Fixed "NaN%" progress display by standardizing variable names between Worker and Main Thread.
- **Renderer Parity**: Standardized `vs-render-worker.js` and `vs-self-test.js` to use the unified renderer API (`MCQVS_UnifiedRenderer`) with identical state shapes, ensuring self-tests accurately reflect production export behavior.
- **Timer Glow Effect**: Fixed `ReferenceError: activeTimerGlow is not defined` in `vs-unified-renderer.js` by correcting variable reference from `activeTimerGlow` to `_glow` (line 221).
- **AI Scene Export**: Fixed AI-generated quizzes (News/Topic) exporting as outro-only videos by adding missing `duration` and `timing` properties to scene objects in `handleAIQuizResponse()`. Also added unified debug state tracking and source-based quiz title logic.

## [7.4.2] - 2026-01-24
### Fixed
- **CTA Presets**: Fixed bug where selecting a CTA preset didn't update the text (Added `getAllCTA` method).
- **Preview Parity**: Fixed Outro branding size and CTA text mismatch in Preview to match Export.
- **Scene Logic**: Fixed Preview scene lookup to correctly find Hook and Outro scenes.
- **Sparkle Sync**: Synchronized particle bursts to trigger exactly on answer reveal (Preview & Export).
- **Preview Engine**: Fixed missing particle rendering (sparkles were invisible).
- **Audio Control**: Fixed background music not stopping when Preview is stopped.
- **CTA Initialization**: Fixed CTA text not loading correct preset until changed (Added DOM Sync).
- **State Synchronization**: Added robust DOM-to-State sync on Preview Start to ensure Logo Position and Quiz Details are always current.
- **WebCodecs Export Engine**: Replaced FFmpeg.wasm with hardware-accelerated WebCodecs API + mp4-muxer.
  - 10-20x faster video encoding via GPU H.264
  - No SharedArrayBuffer/COOP/COEP headers required
  - Streaming output (lower memory usage)
- **Consolidated Video Export**: Multiple selected questions now render as ONE video (instead of separate downloads per question).
- **Audio Support**: Background music mixed via OfflineAudioContext and encoded with AudioEncoder (AAC-LC @ 128 kbps).
- **Exam Quiz Generator**: New feature to generate high-quality, exam-focused MCQs directly from a topic (bypassing news search).
- **Prompt Engineering**: Improved AI prompts to prioritize concise, timeless General Knowledge questions.
- **Strict Mode**: Added strict filtering to prevent trivial meta-questions (e.g., "Which website reported this?") in news quizzes.
- **Resource Manager**: New `MCQVS_ResourceManager` module for tracking and cleaning up Blob URLs to prevent memory leaks during batch exports.
- **Cancel Export**: Users can now cancel in-progress batch exports via a "Cancel" button with full resource cleanup.
- **Abort Controller**: Export loop now checks for cancellation signal before each frame, allowing graceful early termination.

## [1.2.3] - 2026-01-17
### Fixed
- **Randomization Logic**: Enhanced answer detection for numeric answer keys (e.g., "Option 1", "2"). Fixed regression where such answers caused fallback to the first option being marked correct, ensuring proper randomization for all input formats.

## [1.2.2] - 2026-01-13
### Changed
- **Directory Structure**: Cleaned up root directory by moving `Implementation Plans` to `documentation/` and `File Modified` debris to `backups/`.

## [1.2.1] - 2026-01-12
### Changed
- **Topic/Exam Limit**: Limited number of questions fetched for a selected topic or exam to the latest 10 (previously 50).
- **Sorting**: Enforced date-based sorting (DESC) to ensure only the most recent questions are displayed in the Video Studio.
- **Randomization Logic**: Fixed critical bug where answers defaulted to "Option A" (Index 0) when stored answers didn't exactly match option text. Added smart matching for "Answer: A" vs "Option A".
- **Double Highlight Fix**: resolved issue where two answers were highlighted by prioritizing numeric index over legacy text match and removing hardcoded fallbacks.

## [1.2.0] - 2026-01-10 (Client-Only Export Refactor)
### Removed
- **Server-Side Batch Rendering**: Removed entire server frame upload path (~325 lines JS, 7 AJAX endpoints).
  - Deleted: `startServerBatch`, `captureAndUploadFrames`, `triggerServerEncoding`, `pollJobStatus`, `pauseServerBatch`, `resumeServerBatch`, `cancelServerBatch` functions.
  - Removed: `serverRenderMode` state, DOM references, event bindings.
  - Removed: AJAX actions `mcqvs_start_batch_job`, `mcqvs_upload_frame_chunk`, `mcqvs_process_batch_job`, `mcqvs_get_job_status`, `mcqvs_pause_batch_job`, `mcqvs_resume_batch_job`, `mcqvs_cancel_batch_job`.
- **UI Elements**: Removed server render toggle, pause/resume/cancel buttons from batch controls.

### Changed
- **Export Path**: Client-only FFmpeg.wasm export is now the sole rendering path.
- **Deprecation**: `class-vs-ajax-batch-handler.php` marked deprecated; only `ajax_check_ffmpeg()` remains in active use.
- **Chunked Encoding**: Refactored `renderBatchJob` to encode in 5-second segments (150 frames), preventing browser memory exhaustion.
  - Frames deleted from MEMFS after each segment encode.
  - Segments concatenated via FFmpeg concat demuxer with identical codec params.
  - Added segment progress logging to console.
- **FFmpeg Audio Mixing**: Implemented timeline-based SFX placement in exported videos.
  - Added `buildAudioMixCommand` helper to build complex filtergraph.
  - Added `calculateSFXEvents` to generate SFX timestamps from timeline.
  - SFX positioned via `adelay` filter; mixed via `amix` with BG music at 0.3 volume.
  - Supports tick, reveal, correct, wrong, and success SFX.
- **COOP/COEP Headers**: Enabled SharedArrayBuffer for FFmpeg.wasm multi-threading.
  - Headers scoped to Video Studio admin page only (not site-wide).
  - Added `ajax_proxy_asset` endpoint for cross-origin resources with domain whitelist.
  - CORP header added to proxied assets for COEP compliance.
- **AI JSON Mode**: Improved AI quiz generation reliability.
  - Added `mcqvs_gemini_model_id` setting (default: gemini-1.5-flash).
  - Implemented JSON response mode with `response_schema` for structured output.
  - Added `validate_quiz_questions()` - ensures 4 options and valid correct index.
  - Added retry-on-invalid strategy (max 2 retries on validation failure).
- **DB Projects**: Replaced localStorage with database storage.
  - Created `wp_vs_projects` and `wp_vs_project_questions` tables.
  - Added AJAX handlers: `save_project`, `load_project`, `list_projects`, `delete_project`.
  - Projects linked to user_id with full CRUD support.
- **E2E Tests**: Added Playwright test suite (`video-gen.spec.ts`).
  - Tests: page load, UI elements, COOP/COEP, project functionality.

### Technical Notes
- This is part of a larger refactor (Milestone 2 of 7) to improve rendering reliability and reduce code complexity.
- Server-side rendering was removed because it introduced network latency, serialization overhead, and potential timeouts.

## [1.1.2] - 2026-01-08
### Fixed
- **Hotfix (Sync Crash)**: Resolved fatal error in kinetic scanner caused by incorrect `currentQuestionIndex` mapping during non-contiguous question selections.
- **Hotfix (Timeline)**: Fixed `progress is not defined` ReferenceError in `updateTimelineUI` that flooded console during playback.
- **Hotfix (CTA)**: Fixed CTA displaying preset text instead of custom text by respecting `getCTAText()` logic in template manager.
- **Hotfix (Contrast)**: Corrected unreadable text on highlighted answers by changing "correct" text style to White (#FFFFFF) across all 10 presets.
- **Hotfix (Backgrounds)**: Fixed template renderer ignoring user-selected background videos/images; custom backgrounds now render correctly.
- **Hotfix (Layout)**: Implemented **Layout V4**. Reduced max font size (60px) and pushed text down further (Y=180 offset) to fully eliminate title overlap and "too big" text issues.
- **Hotfix (Audio)**: **Hard-Gated SFX**. Added a strict check in the audio engine to block all SFX playback calls when the SFX volume is 0 (or toggle is off), resolving the "sound leakage" issue.
- **Hotfix (Audio)**: Fixed regression where splitting toggles caused the internal "Master Audio" state to remain disabled, preventing music playback.
- **Hotfix (Video)**: Forced background video autoplay (muted) in preview mode to bypass browser autoplay policies and ensure rendering.
- **Hotfix (Audio)**: Added **Dedicated SFX Toggle**. Users can now mute SFX independently of Background Music.
- **Hotfix (UX)**: Added immediate "Video Loaded" visual feedback label when a background video is selected.
- **Hotfix (Text)**: Implemented **Auto-Fit Typography** for questions. Long text now automatically scales down to fit the card without overflowing.
- **Hotfix (Timer)**: Fixed Question Timer rendering and positioned it at the bottom of the card (`Q -> Answers -> Timer`) for better visual flow.
- **Hotfix (Video)**: Added safety checks for background video buffering (`readyState`) to prevent black screens during loading/preview.
- **Hotfix (Audio)**: Fixed silent background music in preview by adding explicit play/pause logic synchronized with the preview state.
- **Hotfix (Export)**: Implemented Server-Side Audio Merging in FFmpeg pipeline. Exports now include looped background music mixed with the video.
- **Hotfix (Video)**: Fixed background video not appearing in exports by enforcing frame-exact synchronization during the recording phase.
- **Feature (UI)**: Added visual **Timer Progress Bar** to the question card.
- **Hotfix (UI)**: Restored missing "Enable Audio" toggle switch in the Audio Suite panel.
- **Debug Console**: Implemented professional upfront error logging and live diagnostic monitor.
- **Performance**: Implemented Layout Caching for kinetic text to eliminate frame-rate jitter and FPS drops.
- **Playback Logic**: Fixed duration mismatch by syncing the rendering loop and timeline with selected questions.
- **UI Polish**: Resolved trailing slash glitch in the timeline time display.
- **Rendering Hardening**: Centralized all timing constants (`state.timing`) to ensure preview and export use identical durations.
- **Transformation Stacking**: Audited and ensured all ctx.save/restore calls are properly balanced.

### Added
- **Server-Side FFmpeg Pipeline**: Full implementation of browser-to-server video generation with ZIP extraction, cron-based encoding, and frame cleanup.

## [1.1.4] - 2026-01-08 (Release Candidate Polish)
### Fixed (UX/Controls)
- **Audio Controls**: Resolved conflict where duplicate HTML IDs broke the "Enable Audio" toggle. Renamed internal ID to `enableMasterAudioToggle`.
- **SFX Gating**: Implemented strict state checking (`sfxEnabled`). Toggling SFX off now strictly blocks all sound effect triggers preventing "leakage".
- **Visual Timer**: Added visible per-question timer with a polished "Pill Style" overlay. Counts down specifically to the answer reveal moment, ensuring perfect synchronization. Rendered as an absolute overlay to persist through camera/zoom effects.
- **Audio Logic**: Refactored SFX and Music control for strict separation of concerns. SFX now routed through a single gated method. Music playback prevents restart loops via idempotency checks.
- **Visual Timer**: **Relocated to Y=820** and resized to **420x130px**.
- **Layout Engine**: Implemented **Dynamic Card Height** calculation to prevent long answers from overflowing.
- **Answer Layout**: Increased vertical spacing (140px). **Removed A/B/C/D prefixes**.
- **Legibility**: Switched to **Dark Glass Background** (High Opacity) for superior text contrast. Enforced black text on correct answers.
- **Audio Logic**: Fixed `PREVIEW_START` custom music bug. **Fixed `PREVIEW_STOP` to strictly stop custom music tracks.**
- **Video Background**: **Increased overlay opacity to 0.6** for better text readability. Fixed upload routing bug.
- **Sync**: Added **500ms fade-in to CTA visual** to better synchronize with TTS audio delay.

## [1.1.3] - 2026-01-08 (Security Hardening)
### Security
- **Critical (Zip Slip)**: Patched directory traversal vulnerability in Batch Handler frame upload (`ajax_upload_frame_chunk`). Added strict validation for ZIP entries.
- **Critical (Command Injection)**: Patched potential shell injection in FFmpeg version check (`ajax_check_ffmpeg`) by escaping shell commands.
- **High (Path Traversal)**: Hardened `resolve_audio_path` and `process_ffmpeg_job` to normalize paths and escape all shell arguments, preventing filesystem traversal.

### Fixed
- **Reliability (Config)**: Fixed "Studio Config missing" console error by explicitly localizing `mcqvsStudioConfig` for the `mcqvs-asset-library` dependency.
- **Reliability (Keys)**: Solved "Split-Brain" option key issue. Admin settings now save with canonical `mcqvs_` prefix, while readers (TTS/Core) fallback to legacy `MCQVS_` keys if needed.

## [8.7.1] - 2026-02-01
### Changed - Modular Architecture
- Split monolithic `studio.controller.js` (258KB) into 6 focused modules:
  - `studio.logger.js` (8KB) - Structured logging
  - `studio.preview.js` (60KB) - Canvas rendering
  - `studio.export.js` (80KB) - Worker export
  - `studio.audio.js` (40KB) - Audio management
  - `studio.ui.js` (50KB) - DOM bindings
  - `studio.controller.js` (30KB) - Orchestrator

### Fixed
- Replaced 400+ console.log calls with structured `MCQVSLogger`
- Removed duplicate catch blocks (syntax errors)
- Improved maintainability (50KB files vs 258KB monolith)

## [1.2.4] - 2026-02-01
- **CRITICAL**: Fixed video download not triggering (Added JOBCOMPLETE handler).
- **CRITICAL**: Fixed Main Thread Parity (Added `roundRect` polyfill).
- **Security**: Removed risky domains (Vimeo, Wikimedia) from Asset Proxy.
- **Security**: Added strict Content-Type validation for all proxied assets.
- **Security**: Added strict input validation for Topic Quiz generation.
- **Reliability**: Added exponential backoff retry logic for AI generation.
- **Reliability**: Integrated `MCQVSAssetCache` in Unified Renderer for robust asset resolution.
- **Reliability**: Fixed `audio.router.js` logger calls (Stopped swallowing errors).
- **Maintenance**: Audit of `console.log` usage (Replaced with structured `MCQVS_Logger`).
- **Maintenance**: Removed deprecated code (`drawQuestionTimer`, `drawOutroBranding`, `.old` files).
- **Feature**: Added Export Progress persistence via LocalStorage.

## [1.1.2] - 2026-01-08
### Fixed
- **Rendering Sync**: Fixed state desync between real-time loop and template manager to prevent Q&A mixing.
- **Stability**: Quantized frame timing to 30fps to eliminate jitter and "jerking" in preview.
- **Performance**: Removed high-cost canvas backdrop filters that caused flickering in several browsers.
- **Scene Continuity**: Standardized 12s durations for all question scenes to prevent drift.

## [1.1.0] - 2026-01-07
### Fixed
- **Preview Layout**: Enforced side-by-side layout on desktop and responsive stacking on mobile.
- **Timer**: Fixed timer display to show "Current / Total" correctly during preview.
- **UI Styling**: Enhanced fonts and gradients for preview CTA and controls.

## [8.7.0] - 2026-01-07
### Added
- Professional Audio Suite with local library and custom uploads.
- Timeline controller for precise scrubbing.
- Template browser with categories and color previews.

### Changed
- Refactored entire UI to "Dev MCQ VS" layout.
