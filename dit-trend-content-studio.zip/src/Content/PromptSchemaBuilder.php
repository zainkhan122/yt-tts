<?php

/**
 * PromptSchemaBuilder
 *
 * Centralizes duplicated schema + prompt logic across providers.
 *
 * @package DIT_TrendStudio
 */

namespace DIT\TrendStudio\Content;

use DIT\TrendStudio\Infrastructure\Logger;

if (!defined('ABSPATH')) {
  exit;
}

class PromptSchemaBuilder
{
  /**
   * Optional logger for debug instrumentation.
   *
   * @var Logger|null
   */
  private $logger;

  /**
   * @MODIFIED 2026-02-17 - Phase 4.1.1: Accept Logger to prevent constructor fatals.
   *
   * @param Logger|null $logger
   */
  public function __construct(?Logger $logger = null)
  {
    $this->logger = $logger;
  }

	/**
	* Build a writing prompt bundle (system + user) using the schema rules
	* shared across all providers.
	*
	* @param array $prompt_data
	* @param array $research_data
	* @param array $visual_manifest_out (by ref) token=>raw html/url
	* @param string $output_schema_out (by ref)
	* @return array {system_prompt,user_prompt,output_schema,visual_manifest}
	*/
	public function build_writing_bundle(
    array $prompt_data,
    array $research_data,
    array &$visual_manifest_out = [],
    string &$output_schema_out = '',
    $visuals_service = null,
    int $visual_limit = 0
  ): array {
    $vertical  = (string) ($prompt_data['vertical'] ?? 'showbiz');
    $category  = (string) ($prompt_data['category'] ?? '');

    // @MODIFIED 2026-02-17 - Phase 4.1.1: Respect placement mode in schema and optionally compact schema in prompt.
    $pmode = (string) get_option('dit_ts_media_placement_mode', 'token_matcher');
    $pmode = in_array($pmode, ['token_matcher', 'structured_blocks'], true) ? $pmode : 'token_matcher';

    $output_schema = $this->build_output_schema($vertical, $category, $pmode);
    $output_schema_out = $output_schema;

    $schema_for_prompt = $output_schema;
    $enforce = (bool) get_option('dit_ts_ai_enforce_structured_output', true);
    $editorial_angle     = (string) ($prompt_data['editorial_angle'] ?? 'neutral');
    $search_intent       = (string) ($prompt_data['search_intent'] ?? 'mixed');
    $structure_blueprint = (array)  ($prompt_data['structure_blueprint'] ?? []);

    $role_desc = (string) ($prompt_data['role_definition'] ?? '');
    if ($role_desc === '') {
      $blueprint = PromptBlueprint::getBlueprint($search_intent, $vertical);
      $role_desc = $blueprint['role'] ?? ('You are an Elite Executive Editor at a major global ' . ucfirst($vertical) . ' magazine.');
    }
    $style_guide = (string) ($prompt_data['style_guide'] ?? '');

    $tone = (string) get_option('dit_ts_editorial_tone', '');
    $tone_instruction = ($tone !== '') ? "\n## Custom Editorial Tone\n{$tone}\n" : '';

    $seo_instruction = $this->get_seo_instruction($prompt_data);

    $angle_instruction     = $this->get_editorial_angle_instruction($editorial_angle);
    $structure_instruction = $this->get_structure_instruction($structure_blueprint, $search_intent);

    $idea_text = (string) ($prompt_data['idea_text'] ?? $prompt_data['topic'] ?? '');
    $title     = (string) ($prompt_data['title'] ?? $prompt_data['headline'] ?? $prompt_data['topic'] ?? '');

    // Visual assets: prefer pipeline-provided token map (PromptBuilder -> visual_assets).
    // NOTE: Pipeline tokenizes idea_text early, so extracting <img> tags here is unreliable.
    $visuals_section = '';
    $visual_assets = (string) ($prompt_data['visual_assets'] ?? '');
    if ($visual_assets !== '') {
      $visuals_section = "\n## Visual Assets\n{$visual_assets}\n";
    } elseif (!empty($prompt_data['_visuals_section'])) {
      $visuals_section = (string) $prompt_data['_visuals_section'];
    } elseif ($visuals_service && method_exists($visuals_service, 'build_visuals_section')) {
      // Fallback only for non-tokenized flows
      $visuals_section = $visuals_service->build_visuals_section($idea_text, $visual_manifest_out, $visual_limit);
    }


    // @MODIFIED 2026-02-17 - Phase 4: Pass placement mode to schema generation
    $pmode = (string) get_option('dit_ts_media_placement_mode', 'token_matcher');
    $output_schema = $this->build_output_schema($vertical, $category, $pmode);
    $output_schema_out = $output_schema;

    $research_content = (string) ($research_data['research_content'] ?? '');
    $sources_text = $this->render_sources_md((array) ($research_data['sources'] ?? []));

    $formatting_rules = (string) ($prompt_data['formatting_rules'] ?? '');
    $formatting_instruction = ($formatting_rules !== '') ? "\n## Formatting Rules\n{$formatting_rules}\n" : '';

    $system_prompt = <<<SYS
Role:
{$role_desc}
{$angle_instruction}

Style Guide:
{$style_guide}
{$formatting_instruction}

{$this->get_editorial_standards($vertical)}

You are an expert editor and investigative writer.
Return VALID JSON ONLY (no markdown fences, no commentary).
You must follow the exact output schema provided.
SYS;

    $user_prompt = <<<PROMPT
# Role
{$role_desc}
{$angle_instruction}

# Style Guide
{$style_guide}

# Task
Generate an in-depth, magazine-style feature based on the provided research.
{$tone_instruction}
{$seo_instruction}
{$structure_instruction}
{$formatting_instruction}

## Topic
Title: {$title}
Context: {$idea_text}
{$visuals_section}

## Research Data (The Truth)
{$research_content}

## Verified Sources
{$sources_text}

# Output Requirements
Return a JSON object with this exact structure:

{$output_schema}

# Editorial Standards (CRITICAL)
{$this->get_editorial_standards($vertical)}

# HTML Styling
- bodyhtml: Allowed tags: <strong>, <em>, <a>, <ul>, <li>, <ol>, <blockquote>, <img>, <iframe>, <table>, <h3>.
- Strictly NO Markdown: do NOT use **text**. Use <strong>text</strong>.
- Do NOT wrap in <p> tags; provide raw text with formatting.
- If you use <h3>, it MUST be on its own line between paragraphs.
- @MODIFIED 2026-02-13: Use RAW HTML tags. Do NOT escape them (use <strong>, NOT &lt;strong&gt;).
- @MODIFIED 2026-02-16: PLACEHOLDER LINK RULE: If a specific URL is not provided in research, DO NOT create a link. NEVER use '#' or invented domains.

# Important
- Return ONLY the JSON object.
PROMPT;

    return [
      'system_prompt'   => $system_prompt,
      'user_prompt'     => $user_prompt,
      'output_schema'   => $output_schema,
      'visual_manifest' => $visual_manifest_out,
    ];
  }

  /**
   * Build Gemini prompt for elite magazine content (Grounding Mode)
   * @MODIFIED 2026-02-13 - Added $visual_limit parameter.
   */
  public function buildMagazinePrompt(
    array $prompt_data,
    array &$visual_manifest_out = [],
    string &$output_schema_out = '',
    $visuals_service = null,
    int $visual_limit = 0
  ): string {
    $vertical  = (string) ($prompt_data['vertical'] ?? 'showbiz');
    $category  = (string) ($prompt_data['category'] ?? '');
    $title     = (string) ($prompt_data['idea_title'] ?? '');
    $idea_text = (string) ($prompt_data['idea_text'] ?? '');

    $editorial_angle     = (string) ($prompt_data['editorial_angle'] ?? 'neutral');
    $search_intent       = (string) ($prompt_data['search_intent'] ?? 'mixed');
    $structure_blueprint = (array)  ($prompt_data['structure_blueprint'] ?? []);

    $role_desc = (string) ($prompt_data['role_definition'] ?? '');
    if ($role_desc === '') {
      $blueprint = PromptBlueprint::getBlueprint($search_intent, $vertical);
      $role_desc = $blueprint['role'] ?? ('You are an Elite Executive Editor at a major global ' . ucfirst($vertical) . ' magazine.');
    }
    $style_guide = (string) ($prompt_data['style_guide'] ?? '');

    $tone = (string) get_option('dit_ts_editorial_tone', '');
    $tone_instruction = ($tone !== '') ? "\n## Custom Editorial Tone\n{$tone}\n" : '';

    $seo_instruction = $this->get_seo_instruction($prompt_data);

    $angle_instruction     = $this->get_editorial_angle_instruction($editorial_angle);
    $structure_instruction = $this->get_structure_instruction($structure_blueprint, $search_intent);

    // Visual assets: prefer pipeline-provided token map (PromptBuilder -> visual_assets).
    // NOTE: Pipeline tokenizes idea_text early, so extracting <img> tags here is unreliable.
    $visuals_section = '';
    $visual_assets = (string) ($prompt_data['visual_assets'] ?? '');
    if ($visual_assets !== '') {
      $visuals_section = "\n## Visual Assets\n{$visual_assets}\n";
    } elseif (!empty($prompt_data['_visuals_section'])) {
      $visuals_section = (string) $prompt_data['_visuals_section'];
    } elseif ($visuals_service && method_exists($visuals_service, 'build_visuals_section')) {
      // Fallback only for non-tokenized flows
      $visuals_section = $visuals_service->build_visuals_section($idea_text, $visual_manifest_out, $visual_limit);
    }


    // @MODIFIED 2026-02-17 - Phase 4: Pass placement mode to schema generation
    $pmode = (string) get_option('dit_ts_media_placement_mode', 'token_matcher');
    $output_schema = $this->build_output_schema($vertical, $category, $pmode);
    $output_schema_out = $output_schema;

    $formatting_rules = (string) ($prompt_data['formatting_rules'] ?? '');
    $formatting_instruction = ($formatting_rules !== '') ? "\n## Formatting Rules\n{$formatting_rules}\n" : '';

    return <<<PROMPT
# Role
{$role_desc}
{$angle_instruction}

# Style Guide
{$style_guide}

# Task
Generate an in-depth, magazine-style feature. Use Google Search grounding to verify facts.
{$tone_instruction}
{$seo_instruction}
{$structure_instruction}
{$formatting_instruction}

## Topic
Title: {$title}
Context: {$idea_text}
{$visuals_section}

# Output Requirements
Return a JSON object with this exact structure:

{$output_schema}

# Editorial Standards (CRITICAL)
{$this->get_editorial_standards($vertical)}

# HTML Styling
- bodyhtml: Allowed tags: <strong>, <em>, <a>, <ul>, <li>, <ol>, <blockquote>, <img>, <iframe>, <table>, <h3>.
- Strictly NO Markdown: do NOT use **text**. Use <strong>text</strong>.
- Do NOT wrap in <p> tags; provide raw text with formatting.
- If you use <h3>, it MUST be on its own line between paragraphs.
- @MODIFIED 2026-02-13: Use RAW HTML tags. Do NOT escape them (use <strong>, NOT &lt;strong&gt;).

# Important
- Return ONLY the JSON object.
PROMPT;
  }

  /**
   * Build writing prompt from pre-researched content.
   * @MODIFIED 2026-02-13 - Added $visual_limit support.
   */
  public function buildFromResearchPrompt(
    array $prompt_data,
    array $research_data,
    array &$visual_manifest_out = [],
    string &$output_schema_out = '',
    $visuals_service = null,
    int $visual_limit = 0
  ): string {
	// This is essentially the same as writing bundle but returns just the user prompt string
    // Unified bundle builder now handles visuals if service provided

    $bundle = $this->build_writing_bundle(
      $prompt_data,
      $research_data,
      $visual_manifest_out,
      $output_schema_out,
      $visuals_service,
      $visual_limit
    );

    return $bundle['user_prompt'];
  }

  /**
   * Hard gate: block publishing if body is empty / sections missing.
   * Call this AFTER decoding provider JSON, BEFORE formatting/publishing.
   */
    public function assert_non_empty_article(array $article): void
    {
        $sections = $article['sections'] ?? null;

        // Accept legacy "content_blocks" only if it has meaningful paragraph content
        if (!is_array($sections) || count($sections) === 0) {
            $blocks = $article['content_blocks'] ?? [];
            if (is_array($blocks) && $this->blocks_have_meaningful_text($blocks)) {
                return;
            }

            throw new \RuntimeException('Hard gate: AI returned empty body (no sections/content). Refusing to publish.');
        }

        $total = 0;
        foreach ($sections as $s) {
            if (!is_array($s)) {
                continue;
            }
            $body = (string) ($s['bodyhtml'] ?? $s['body_html'] ?? $s['body'] ?? '');
            $plain = trim(strip_tags(preg_replace('/<!--.*?-->/s', '', $body)));
            $total += strlen($plain);
        }

        // @MODIFIED 2026-04-25 - Vertical-aware minimum word count gate
        $vertical = (string) ($article['vertical'] ?? 'general');
        $min_chars = 200; // default
        if ($vertical === 'fashion_pk') {
            $min_chars = 2500; // ~500 words minimum for fashion features
        } elseif ($vertical === 'showbiz_pk') {
            $min_chars = 1500; // ~300 words minimum for showbiz
        }

        if ($total < $min_chars) {
            throw new \RuntimeException('Hard gate: AI returned too little body text for vertical "' . $vertical . '" (got ' . $total . ' chars, need ' . $min_chars . '). Refusing to publish.');
        }
    }

  private function blocks_have_meaningful_text(array $blocks): bool
  {
    $total = 0;
    foreach ($blocks as $b) {
      if (!is_array($b)) {
        continue;
      }

      $t = (string) ($b['type'] ?? '');
      $payload = (string) ($b['html'] ?? $b['content'] ?? $b['text'] ?? '');

      if ($t === 'p' || $t === 'paragraph' || $t === 'intro') {
        $total += strlen(trim(strip_tags($payload)));
      }
    }

    return $total >= 200;
  }

  private function build_output_schema(string $vertical, string $category, string $pmode = 'token_matcher'): string
  {
    // @MODIFIED 2026-02-17 - Phase 4.1.1: Structured blocks schema path.
    if ($pmode === 'structured_blocks') {
      return $this->build_output_schema_structured_blocks($vertical, $category);
    }

    // Keep schema consistent with your Gemini client expectations.
    // Keep schema consistent with your Gemini client expectations.
    if ($vertical === 'showbiz_pk') {
            $pk_body_instruction = "@MODIFIED 2026-02-15: Write 4 short paragraphs in one continuous narrative, based strictly on the provided source context. Follow the STRUCTURE ANCHORS and IMAGE PLACEMENT RULES provided in the structural blueprint exactly. Place tokens [VISUAL_N] as instructed.";

            $pk_body_instruction .= "\n\nLANGUAGE (CRITICAL): Write the ENTIRE article body (headline, dek, sections bodyhtml) in ENGLISH ONLY. Do NOT write in Roman Urdu, Urdu script, or any mixed language. All prose must be in English. The social_assets section is the ONLY exception — that section must be in Urdu script.";

      $pk_body_instruction .= "\n\nHARD TRUTH RULE: Do NOT add facts not explicitly present.\nEVIDENCE RULE: Include 2-6 verbatim snippets in 'source_snippets'.\nCELEBRITY LINK RULE (Showbiz): If the research identifies a celebrity profile URL, you MUST link it once in the narrative using ONLY the celebrity name as anchor (e.g. <a href=\"...\">Ahsan Khan</a>). NEVER show the handle or raw URL in the text.\nMEDIA EMBED RULE (Global): For standalone media posts (Instagram posts, YouTube videos, X/Twitter posts, TikTok videos) found in the research or SOURCE CONTEXT, you MUST wrap them in [embed]URL[/embed] for standalone block placement. Do NOT use <a> tags for media posts.";

      return <<<JSON
{
  "headline": "A sophisticated, search-optimized headline (60-80 chars)",
  "dek": "A compelling narrative hook (100-150 chars)",
  "category": "{$category}",
  "primary_keyword": "Generate a 2-4 word focus keyword based on the article topic",
  "tags": ["tag1", "tag2", "tag3"],
  "hero_image": "",
  "hero_image_alt": "",
  "image_attribution": {"credit":"", "license":"Unknown", "source_url":""},
  "meta_description": "Search-optimized meta description (150-160 chars)",
  "vertical": "{$vertical}",
  "source_snippets": [
    "2-6 verbatim snippets copied from the SOURCE CONTEXT (max 20 words each). No paraphrase. No invention."
  ],
  "sections": [
    {
      "heading": "Introduction",
      "bodyhtml": "{$pk_body_instruction}",
      "verification_status": "UNVERIFIED"
    }
  ],
  "sources": [],
  "internal_links": [],
  "social_assets": {$this->get_social_assets_schema($category)}
}
JSON;
    }

    if ($vertical === 'fashion_pk') {
            $pk_body_instruction = "@MODIFIED 2026-02-16: Write a Pakistani fashion feature using these anchors: Paragraph 1 (campaign hook), Paragraph 2 (collection overview), Paragraph 3 (Dress Showcase as multiple <h3> + description blocks), Paragraph 4 (shopping details). Follow the IMAGE PLACEMENT RULES in the structural blueprint exactly. Place tokens [VISUAL_N] as instructed.";

            $pk_body_instruction .= "\n\nLANGUAGE (CRITICAL): Write the ENTIRE article body (headline, story_narrative, meta_tags) in ENGLISH ONLY. Do NOT write in Roman Urdu, Urdu script, or any mixed language. All prose must be in English. The social_assets section is the ONLY exception — that section must be in Urdu script.";

      $pk_body_instruction .= "\n\nHARD TRUTH RULE: Do NOT add facts not explicitly present.\nEVIDENCE RULE: Include 2-6 verbatim snippets in 'source_snippets'.\nCELEBRITY LINK RULE (Fashion): If linking to a celebrity or designer profile, use ONLY the name as anchor (e.g. <a href=\"...\">Sania Maskatiya</a>). NEVER show handles or URLs. DO NOT link if URL is missing.\nMEDIA EMBED RULE (Global): For standalone media posts (Instagram, YouTube, etc.), you MUST wrap them in [embed]URL[/embed] for standalone block placement. Do NOT use <a> tags for media posts.\nHTML RULE: Wrap ALL paragraphs in <p> tags.";

      return <<<JSON
{
  "headline": "A sophisticated, search-optimized headline (60-80 chars)",
  "dek": "A compelling narrative hook (100-150 chars)",
  "category": "{$category}",
  "primary_keyword": "Generate a 2-4 word focus keyword based on the article topic",
  "tags": ["tag1", "tag2", "tag3"],
  "hero_image": "",
  "hero_image_alt": "",
  "image_attribution": {"credit":"", "license":"Unknown", "source_url":""},
  "meta_description": "Search-optimized meta description (150-160 chars)",
  "vertical": "{$vertical}",
  "source_snippets": [
    "2-6 verbatim snippets copied from the SOURCE CONTEXT (max 20 words each). No paraphrase. No invention."
  ],
  "sections": [
    {
      "heading": "Introduction",
      "bodyhtml": "{$pk_body_instruction}",
      "verification_status": "UNVERIFIED"
    }
  ],
  "sources": [],
  "internal_links": [],
  "social_assets": {$this->get_social_assets_schema($category)}
}
JSON;
    }

        return <<<JSON
{
"headline": "A sophisticated, non-clickbait headline (60-80 chars)",
"dek": "A compelling narrative hook that bridges the headline and intro (100-150 chars)",
"category": "{$category}",
"primary_keyword": "Generate a 2-4 word focus keyword based on the article topic",
"tags": ["tag1", "tag2", "tag3"],
"hero_image": "",
"hero_image_alt": "Professional editorial description for hero image",
"image_attribution": {
"credit": "Name/Agency",
"license": "Unknown",
"source_url": ""
},
"meta_description": "Search-optimized meta description with editorial flair (150-160 chars)",
"vertical": "{$vertical}",
"content_blocks": {
"the_scoop": ["Viral point 1", "Viral point 2"],
"what_to_buy": [{"type": "Product type", "why": "Reason", "suits": "Who it suits"}],
"how_to_wear": ["Styling tip 1", "Styling tip 2", "Styling tip 3"]
},
"sections": [
{
"heading": "SEMANTIC HEADER (NOT 'Introduction')",
"bodyhtml": "LANGUAGE (CRITICAL): Write the ENTIRE article body in ENGLISH ONLY. Do NOT write in Roman Urdu, Urdu script, or any mixed language. The social_assets section is the ONLY exception — that section must be in Urdu script. Content...",
"verification_status": "UNVERIFIED",
"suggested_image_search": "...",
"editorial_callout": {
"title": "EDITOR'S INSIGHT / THE SCOOP",
"content": "A high-value tip, expert quote, or background fact."
}
}
],
"sources": [{"url": "...", "label": "..."}],
"internal_links": [],
"social_assets": {$this->get_social_assets_schema($category)}
}
JSON;
  }

  /**
   * Generates category-aware prompt instructions for Social Assets.
   */
  /**
   * @MODIFIED 2026-05-05 - Rewritten with strict word-count constraints and
   * natural Pakistani Urdu register to prevent rendering overflow and robotic tone.
   */
  private function get_social_assets_schema(string $category): string
  {
    $cat_lower = strtolower($category);
    if (strpos($cat_lower, 'fashion') !== false || strpos($cat_lower, 'style') !== false || strpos($cat_lower, 'beauty') !== false) {
      // --- FASHION/STYLE (Corrected) ---
      $heading = "ایک مختصر اور شاعرانہ اردو سرخی لکھیں (4 سے 7 الفاظ)۔ سرخی ایسی ہو جو کپڑوں کی خوبصورتی اور احساس کو بیان کرے۔ مثال کے طور پر: 'رنگ جو دل سے بولیں' یا 'دھاگوں میں بنی کہانی'۔ برانڈ کا نام نہ دہرائیں۔";
      $desc = "ایک شائستہ اور دلکش اردو پیراگراف لکھیں (20 سے 35 الفاظ)۔ ساخت: (1) کپڑوں کے احساس یا بناوٹ پر ایک جملہ۔ (2) کلیکشن کا دلکش تعارف۔ (3) کال ٹو ایکشن: 'مکمل تفصیلات کے لیے ہمارے بائیو میں موجود لنک پر کلک کریں'۔ انگریزی الفاظ سے پرہیز کریں۔";
      $hashtags = '["#fashion", "#style", "#pakistan", "#designerwear", "#luxuryfashion"] (MUST BE IN ENGLISH ONLY)';
    } else {
      // --- NEWS/SHOWBIZ (Corrected) ---
      $heading = "ایک جاندار اور مختصر اردو سرخی لکھیں (5 سے 8 الفاظ)۔ لہجہ مستند صحافی جیسا ہو، سنسنی خیزی سے پاک۔ انگریزی الفاظ (جیسے 'Conflict', 'Role') استعمال نہ کریں۔ شخصیات کے ناموں کا درست املا (جیسے 'فیصل' نہ کہ 'فاضل') لازمی ہے۔";
      $desc = "ایک مختصر اور جامع پیراگراف لکھیں (25 سے 40 الفاظ)۔ ساخت: (1) خبر کا خلاصہ (2) اس کی اہمیت (3) کال ٹو ایکشن: 'مکمل تفصیلات کے لیے لنک پر کلک کریں'۔ عام بول چال والی شائستہ اردو استعمال کریں۔ انگریزی اور غلط العام الفاظ (جیسے 'پلا نے') سے پرہیز کریں۔";
      $hashtags = '["#news", "#showbiz", "#pakistan"] (MUST BE IN ENGLISH ONLY)';
    }

    return <<<JSON
{
    "urdu_heading": "{$heading}",
    "urdu_description": "{$desc}",
    "hashtags": {$hashtags}
  }
JSON;
  }

  private function render_sources_md(array $sources): string
  {
    if (empty($sources)) {
      return '';
    }
    $out = '';
    foreach ($sources as $s) {
      if (!is_array($s)) {
        continue;
      }
      $url = (string) ($s['url'] ?? '');
      if ($url === '') {
        continue;
      }
      $label = (string) ($s['label'] ?? $url);
      $out .= "- [{$label}]({$url})\n";
    }
    return trim($out);
  }

  private function get_editorial_standards(string $vertical): string
  {
    return <<<STANDARDS
- Voice: Sophisticated, authoritative. Avoid generic AI fluff.
- E-E-A-T: Demonstrate expertise and trustworthiness.
- Sourcing: Attribute major claims to provided sources/research.
- Flow: Logical transitions and tight paragraphs.
- No Fluff: Every sentence must add value.
STANDARDS;
  }

  private function get_editorial_angle_instruction(string $angle): string
  {
    switch ($angle) {
      case 'contrarian':
        return "Your angle is CONTRARIAN. Challenge the popular narrative with facts.";
      case 'analytical':
        return "Your angle is ANALYTICAL. Deconstruct causes, trends, and evidence.";
      case 'human_interest':
        return "Your angle is HUMAN INTEREST. Focus on people and emotion with factual grounding.";
      case 'insider':
        return "Your angle is INSIDER. Use correct industry jargon (explain briefly).";
      case 'skeptical':
        return "Your angle is SKEPTICAL. Verify claims and highlight inconsistencies.";
      case 'optimistic':
        return "Your angle is OPTIMISTIC. Focus on solutions and positive outcomes.";
      case 'neutral':
      default:
        return "Maintain a balanced, objective, journalistic tone.";
    }
  }

  private function get_structure_instruction(array $blueprint, string $intent): string
  {
    $sections = $blueprint['required_sections'] ?? $blueprint;

    if (!empty($sections) && is_array($sections)) {
      $steps = "";
      $i = 1;
      foreach ($sections as $label => $desc) {
        if (is_array($desc)) {
          continue;
        }
        $steps .= "{$i}. " . (is_string($label) ? "{$label}: " : "") . "{$desc}\n";
        $i++;
      }
      return "\n## Structural Blueprint (Follow strictly)\n" . trim($steps) . "\n";
    }

    if ($intent === 'transactional') {
      return "\n## Suggested Structure\n1. Hook\n2. Solution\n3. Key Benefits\n4. Alternatives\n5. Verdict\n";
    }

    return "";
  }

  /**
   * Generates SEO targeting instructions if keywords are present.
   */
	private function get_seo_instruction(array $prompt_data): string
	{
		$primary = (string) ($prompt_data['primary_keyword'] ?? '');
		$secondary = (array) ($prompt_data['secondary_keywords'] ?? []);

		if ($primary === '' && empty($secondary)) {
			// No user-provided keywords - AI must determine optimal focus keyword
			return "\n## SEO Targeting (CRITICAL)\nYou MUST determine the optimal primary focus keyword for this article based on the content and topic.\n- Include it in 'primary_keyword' field as a short phrase (2-4 words)\n- Use it naturally in the headline and meta_description\n- DO NOT keyword stuff\n";
		}

		$out = "\n## SEO Targeting (CRITICAL)\n";
		if ($primary !== '') {
			$out .= "Primary keyword: {$primary}\n";
		}
		if (!empty($secondary)) {
			$out .= "Secondary keywords: " . implode(', ', $secondary) . "\n";
		}
		$out .= "RULE: Use keywords naturally. Do NOT keyword stuff. Prioritize readability.\n";
		$out .= "Include the primary keyword in 'primary_keyword' field.\n";

		return $out;
	}

	public static function get_web_search_instructions(string $search_type): string
	{
		switch ($search_type) {
		case 'zhipuai':
			return "\n## Web Search Instructions\nYou have access to real-time web search results. Use the search results to verify facts, find current information, and support your claims. Cite sources using bracketed reference numbers [1], [2], etc. corresponding to the search result order. Do NOT fabricate citations — only cite sources actually returned by the search. Incorporate search findings naturally into your narrative without breaking flow.\n";

		case 'kimi':
			return "\n## Web Search Instructions\nWeb search is enabled for this request. Use any search results provided to ground your response in verifiable, current information. Reference sources inline where appropriate. If search results contradict common assumptions, prioritize the search data. Do NOT invent URLs or source references that were not provided.\n";

		case 'minimax':
			return "\n## Web Search Instructions\nWeb search is active. Base factual claims on the search results returned. Cite the source URL or title when referencing specific findings. If no search results are returned for a query, rely on your training data but clearly indicate the information is unverified.\n";

		default:
			return '';
		}
	}

	/**
   * @MODIFIED 2026-02-17 - Phase 4.1.1: Compact schema stub for prompt (token reduction).
   */
  private function build_compact_output_schema_stub(string $vertical, string $category, string $pmode): string
  {
    if ($pmode === 'structured_blocks') {
      return <<<JSON
{
  "headline": "",
  "dek": "",
  "category": "{$category}",
  "primary_keyword": "Generate a 2-4 word focus keyword based on the article topic",
  "vertical": "{$vertical}",
  "meta_description": "",
  "tags": [],
  "source_snippets": [],
  "sections": [
    {
      "heading": "Introduction",
      "verification_status": "UNVERIFIED",
      "blocks": [
        {"type":"p","html":"<p>...</p>"},
        {"type":"visual_ref","id":0},
        {"type":"embed_ref","url":"https://..."}
      ]
    }
  ],
  "sources": [],
  "internal_links": [],
  "social_assets": {$this->get_social_assets_schema($category)}
}
JSON;
    }

    return <<<JSON
{
  "headline": "",
  "dek": "",
  "category": "{$category}",
  "primary_keyword": "Generate a 2-4 word focus keyword based on the article topic",
  "vertical": "{$vertical}",
  "meta_description": "",
  "tags": [],
  "source_snippets": [],
  "sections": [
    {
      "heading": "Introduction",
      "bodyhtml": "",
      "verification_status": "UNVERIFIED"
    }
  ],
  "sources": [],
  "internal_links": [],
  "social_assets": {$this->get_social_assets_schema($category)}
}
JSON;
  }

  /**
   * @MODIFIED 2026-02-17 - Phase 4.1.1: Schema for structured blocks mode aligned with PostComposer.
   */
  private function build_output_schema_structured_blocks(string $vertical, string $category): string
  {
    return <<<JSON
{
  "headline": "Headline (60-80 chars)",
  "dek": "Hook (100-150 chars)",
  "category": "{$category}",
  "vertical": "{$vertical}",
  "meta_description": "Meta description (150-160 chars)",
  "tags": ["tag1","tag2"],
  "source_snippets": [
    "2-6 verbatim snippets from SOURCE CONTEXT (max 20 words each)."
  ],
  "sections": [
    {
      "heading": "Introduction",
      "verification_status": "UNVERIFIED",
      "blocks": [
        {"type":"p","html":"<p>Paragraph about a specific dress/person.</p>"},
        {"type":"visual_ref","id":0,"caption":""},
        {"type":"h","level":3,"text":"Optional H3"},
        {"type":"p","html":"<p>Another paragraph.</p>"},
        {"type":"embed_ref","url":"https://..."}
      ]
    }
  ],
  "sources": [],
  "internal_links": [],
  "social_assets": {$this->get_social_assets_schema($category)}
}
JSON;
  }
  /**
   * Build a compact output schema stub for the prompt.
   *
   * @MODIFIED 2026-02-17 - Phase 4.1: Reduce token usage when provider-side enforcement is enabled.
   */
  public function build_compact_output_schema(string $mode = 'token_matcher'): string
  {
    if ($mode === 'structured_blocks') {
      return '{ "headline": "string", "sections": [ { "heading": "string", "blocks": [ { "type": "paragraph|heading|visual_ref", "html": "string", "id": "visual_id" } ] } ], "social_assets": { "urdu_heading": "string", "urdu_description": "string", "hashtags": ["English hashtags only"] } }';
    }
    return '{ "headline": "string", "sections": [ { "heading": "string", "bodyhtml": "string (with [VISUAL_N] tokens)" } ], "social_assets": { "urdu_heading": "string", "urdu_description": "string", "hashtags": ["English hashtags only"] } }';
  }
}
