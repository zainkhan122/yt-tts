<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Gamification System for MCQ Plugin
 * Handles points, badges, achievements, streaks, levels
 *
 * @package WP_News_MCQ_Generator
 * @version 1.0
 */

class NM_Gamification {

	private static $instance = null;

	// Point values
	const POINTS_PER_CORRECT       = 10;
	const POINTS_PER_QUIZ_COMPLETE = 50;
	const POINTS_DAILY_LOGIN       = 5;
	const POINTS_STREAK_BONUS      = 10; // Per day of streak
	const POINTS_PERFECT_SCORE     = 100;
	const POINTS_SHARE_RESULT      = 20;
	const POINTS_REFERRAL          = 200;

	// Level thresholds
	private static $level_thresholds = array(
		1  => 0,
		2  => 100,
		3  => 300,
		4  => 600,
		5  => 1000,
		6  => 1500,
		7  => 2200,
		8  => 3000,
		9  => 4000,
		10 => 5500,
		11 => 7500,
		12 => 10000,
		13 => 13000,
		14 => 17000,
		15 => 22000,
		16 => 28000,
		17 => 35000,
		18 => 43000,
		19 => 52000,
		20 => 65000,
	);

	public static function init() {
		if ( self::$instance === null ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		// Track quiz completion
		add_action( 'wp_ajax_nm_submit_quiz', array( $this, 'handle_quiz_submission' ) );

		// Get user stats
		add_action( 'wp_ajax_nm_get_user_stats', array( $this, 'get_user_stats' ) );

		// Share achievement
		add_action( 'wp_ajax_nm_share_achievement', array( $this, 'handle_share' ) );
	}

	/**
	 * Award points to user
	 *
	 * @param int    $user_id User ID
	 * @param int    $points Points to award
	 * @param string $reason Reason for points
	 * @return int New total points
	 */
	public static function award_points( $user_id, $points, $reason = '' ) {
		$current   = (int) get_user_meta( $user_id, 'nm_total_points', true );
		$new_total = $current + $points;

		update_user_meta( $user_id, 'nm_total_points', $new_total );

		// Clear cache safely
		if ( method_exists( 'NM_Cache_Manager', 'clear_group' ) ) {
			NM_Cache_Manager::clear_group( 'user_' . $user_id );
		}


		return $new_total;
	}
	/**
	 * Deduct points from user
	 */
	public static function deduct_points( $user_id, $points, $reason = '' ) {
		$current_points = (int) get_user_meta( $user_id, 'nm_total_points', true );
		$new_points     = max( 0, $current_points - $points ); // Don't go negative

		update_user_meta( $user_id, 'nm_total_points', $new_points );

		self::log_points_transaction( $user_id, -$points, $reason );

		return $new_points;
	}

	/**
	 * Log points transaction
	 */
	private static function log_points_transaction( $user_id, $points, $reason ) {
		global $wpdb;
		$table = $wpdb->prefix . 'nm_points_log';

		$wpdb->insert(
			$table,
			array(
				'user_id'    => $user_id,
				'points'     => $points,
				'reason'     => $reason,
				'created_at' => current_time( 'mysql' ),
			),
			array( '%d', '%d', '%s', '%s' )
		);
	}

	/**
	 * Check and update user level
	 */
	private static function check_level_up( $user_id, $old_points, $new_points ) {
		$old_level = self::get_level_from_points( $old_points );
		$new_level = self::get_level_from_points( $new_points );

		if ( $new_level > $old_level ) {
			update_user_meta( $user_id, 'nm_level', $new_level );

			// Award level up bonus
			$bonus = $new_level * 50;
			self::award_points( $user_id, $bonus, "level_up_to_{$new_level}" );

			// Trigger achievement check
			self::check_achievements( $user_id );

			// Send notification
			self::send_level_up_notification( $user_id, $new_level );
		}
	}

	/**
	 * Get user level from points
	 */
	public static function get_level_from_points( $points ) {
		$level = 1;

		foreach ( self::$level_thresholds as $lvl => $threshold ) {
			if ( $points >= $threshold ) {
				$level = $lvl;
			} else {
				break;
			}
		}

		return $level;
	}

	/**
	 * Get points needed for next level
	 */
	public static function get_points_to_next_level( $current_points ) {
		$current_level = self::get_level_from_points( $current_points );
		$next_level    = $current_level + 1;

		if ( ! isset( self::$level_thresholds[ $next_level ] ) ) {
			return 0; // Max level reached
		}

		return self::$level_thresholds[ $next_level ] - $current_points;
	}

	/**
	 * Handle quiz submission
	 */
	public function handle_quiz_submission() {
		check_ajax_referer( 'nm_auth_nonce', 'nonce' );

		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array( 'message' => 'Please login first.' ) );
		}

		$user_id    = get_current_user_id();
		$answers    = $_POST['answers'] ?? array(); // Array of [mcq_id => selected_answer]
		$time_taken = (int) ( $_POST['time_taken'] ?? 0 );
		$quiz_topic = NM_Security_Manager::sanitize_text( $_POST['topic'] ?? '' );

		$total_questions = count( $answers );
		$correct_count   = 0;
		$wrong_count     = 0;
		$points_earned   = 0;

		// Process each answer
		foreach ( $answers as $mcq_id => $selected_answer ) {
			$mcq_id         = (int) $mcq_id;
			$correct_answer = get_post_meta( $mcq_id, 'mcq_answer', true );

			$is_correct = ( $selected_answer === $correct_answer );

			if ( $is_correct ) {
				++$correct_count;
				$points_earned += self::POINTS_PER_CORRECT;
			} else {
				++$wrong_count;
			}

			// Log answer
			$this->log_user_answer( $user_id, $mcq_id, $selected_answer, $is_correct );
		}

		// Quiz completion bonus
		$points_earned += self::POINTS_QUIZ_COMPLETE;

		// Perfect score bonus
		if ( $correct_count === $total_questions && $total_questions > 0 ) {
			$points_earned += self::POINTS_PERFECT_SCORE;
			self::unlock_achievement( $user_id, 'perfectionist' );
		}

		// Speed bonus (if quiz completed in under 1 minute per question)
		$time_limit = $total_questions * 60;
		if ( $time_taken > 0 && $time_taken < $time_limit ) {
			$speed_bonus    = 50;
			$points_earned += $speed_bonus;
		}

		// Award points
		$total_points = self::award_points( $user_id, $points_earned, "quiz_completion_{$quiz_topic}" );

		// Update stats
		$total_quizzes = (int) get_user_meta( $user_id, 'nm_total_quizzes', true ) + 1;
		$total_correct = (int) get_user_meta( $user_id, 'nm_correct_answers', true ) + $correct_count;
		$total_wrong   = (int) get_user_meta( $user_id, 'nm_wrong_answers', true ) + $wrong_count;

		update_user_meta( $user_id, 'nm_total_quizzes', $total_quizzes );
		update_user_meta( $user_id, 'nm_correct_answers', $total_correct );
		update_user_meta( $user_id, 'nm_wrong_answers', $total_wrong );

		// Check achievements
		self::check_achievements( $user_id );

		// Calculate accuracy
		$accuracy = $total_questions > 0 ? round( ( $correct_count / $total_questions ) * 100, 2 ) : 0;

		wp_send_json_success(
			array(
				'correct'               => $correct_count,
				'wrong'                 => $wrong_count,
				'total'                 => $total_questions,
				'accuracy'              => $accuracy,
				'points_earned'         => $points_earned,
				'total_points'          => $total_points,
				'level'                 => get_user_meta( $user_id, 'nm_level', true ),
				'achievements_unlocked' => get_user_meta( $user_id, 'nm_recent_achievements', true ) ?? array(),
			)
		);
	}

	/**
	 * Log user answer
	 */
	private function log_user_answer( $user_id, $mcq_id, $selected_answer, $is_correct ) {
		global $wpdb;
		$table = $wpdb->prefix . 'nm_user_answers';

		$wpdb->insert(
			$table,
			array(
				'user_id'         => $user_id,
				'mcq_id'          => $mcq_id,
				'selected_answer' => $selected_answer,
				'is_correct'      => $is_correct ? 1 : 0,
				'answered_at'     => current_time( 'mysql' ),
			),
			array( '%d', '%d', '%s', '%d', '%s' )
		);
	}

	/**
	 * Check and unlock achievements
	 */
	public static function check_achievements( $user_id ) {
		$achievements   = self::get_achievement_definitions();
		$unlocked       = get_user_meta( $user_id, 'nm_achievements', true ) ?: array();
		$newly_unlocked = array();

		foreach ( $achievements as $key => $achievement ) {
			if ( in_array( $key, $unlocked ) ) {
				continue; // Already unlocked
			}

			$condition_met = call_user_func( $achievement['condition'], $user_id );

			if ( $condition_met ) {
				$unlocked[]       = $key;
				$newly_unlocked[] = $achievement;

				// Award points for achievement
				self::award_points( $user_id, $achievement['points'], "achievement_{$key}" );
			}
		}

		if ( ! empty( $newly_unlocked ) ) {
			update_user_meta( $user_id, 'nm_achievements', $unlocked );
			update_user_meta( $user_id, 'nm_recent_achievements', $newly_unlocked );

			// Send notification
			self::send_achievement_notification( $user_id, $newly_unlocked );
		}
	}

	/**
	 * Unlock specific achievement
	 */
	public static function unlock_achievement( $user_id, $achievement_key ) {
		$unlocked = get_user_meta( $user_id, 'nm_achievements', true ) ?: array();

		if ( ! in_array( $achievement_key, $unlocked ) ) {
			$unlocked[] = $achievement_key;
			update_user_meta( $user_id, 'nm_achievements', $unlocked );

			$achievements = self::get_achievement_definitions();
			if ( isset( $achievements[ $achievement_key ] ) ) {
				self::award_points( $user_id, $achievements[ $achievement_key ]['points'], "achievement_{$achievement_key}" );
			}
		}
	}

	/**
	 * Check and update login streak
	 */
	public static function check_login_streak( $user_id ) {
		$last_login = get_user_meta( $user_id, 'nm_last_login_date', true );
		$today      = date( 'Y-m-d' );

		if ( $last_login === $today ) {
			return; // Already logged in today
		}

		$yesterday      = date( 'Y-m-d', strtotime( '-1 day' ) );
		$current_streak = (int) get_user_meta( $user_id, 'nm_current_streak', true );
		$longest_streak = (int) get_user_meta( $user_id, 'nm_longest_streak', true );

		if ( $last_login === $yesterday ) {
			// Continue streak
			++$current_streak;
		} else {
			// Streak broken, start new
			$current_streak = 1;
		}

		update_user_meta( $user_id, 'nm_current_streak', $current_streak );
		update_user_meta( $user_id, 'nm_last_login_date', $today );

		// Update longest streak
		if ( $current_streak > $longest_streak ) {
			update_user_meta( $user_id, 'nm_longest_streak', $current_streak );
		}

		// Award streak points
		$streak_points = self::POINTS_DAILY_LOGIN + ( $current_streak * self::POINTS_STREAK_BONUS );
		self::award_points( $user_id, $streak_points, "daily_login_streak_{$current_streak}" );

		// Check streak achievements
		if ( $current_streak === 7 ) {
			self::unlock_achievement( $user_id, 'week_warrior' );
		} elseif ( $current_streak === 30 ) {
			self::unlock_achievement( $user_id, 'monthly_master' );
		} elseif ( $current_streak === 100 ) {
			self::unlock_achievement( $user_id, 'century_streak' );
		}
	}

	/**
	 * Achievement definitions
	 */
	public static function get_achievement_definitions() {
		return array(
			'welcome_aboard'   => array(
				'name'        => 'Welcome Aboard!',
				'description' => 'Registered an account',
				'icon'        => '🎉',
				'points'      => 50,
				'condition'   => function ( $user_id ) {
					return true; // Auto-unlocked on registration
				},
			),
			'first_quiz'       => array(
				'name'        => 'First Steps',
				'description' => 'Completed your first quiz',
				'icon'        => '🏁',
				'points'      => 100,
				'condition'   => function ( $user_id ) {
					return (int) get_user_meta( $user_id, 'nm_total_quizzes', true ) >= 1;
				},
			),
			'quiz_master_10'   => array(
				'name'        => 'Quiz Enthusiast',
				'description' => 'Completed 10 quizzes',
				'icon'        => '📚',
				'points'      => 200,
				'condition'   => function ( $user_id ) {
					return (int) get_user_meta( $user_id, 'nm_total_quizzes', true ) >= 10;
				},
			),
			'quiz_master_50'   => array(
				'name'        => 'Quiz Champion',
				'description' => 'Completed 50 quizzes',
				'icon'        => '🏆',
				'points'      => 500,
				'condition'   => function ( $user_id ) {
					return (int) get_user_meta( $user_id, 'nm_total_quizzes', true ) >= 50;
				},
			),
			'quiz_master_100'  => array(
				'name'        => 'Quiz Legend',
				'description' => 'Completed 100 quizzes',
				'icon'        => '👑',
				'points'      => 1000,
				'condition'   => function ( $user_id ) {
					return (int) get_user_meta( $user_id, 'nm_total_quizzes', true ) >= 100;
				},
			),
			'perfectionist'    => array(
				'name'        => 'Perfectionist',
				'description' => 'Achieved 100% score on a quiz',
				'icon'        => '💯',
				'points'      => 150,
				'condition'   => function ( $user_id ) {
					return true; // Unlocked when condition met
				},
			),
			'week_warrior'     => array(
				'name'        => 'Week Warrior',
				'description' => '7-day login streak',
				'icon'        => '🔥',
				'points'      => 300,
				'condition'   => function ( $user_id ) {
					return (int) get_user_meta( $user_id, 'nm_current_streak', true ) >= 7;
				},
			),
			'monthly_master'   => array(
				'name'        => 'Monthly Master',
				'description' => '30-day login streak',
				'icon'        => '⭐',
				'points'      => 1000,
				'condition'   => function ( $user_id ) {
					return (int) get_user_meta( $user_id, 'nm_current_streak', true ) >= 30;
				},
			),
			'century_streak'   => array(
				'name'        => 'Century Club',
				'description' => '100-day login streak',
				'icon'        => '💎',
				'points'      => 5000,
				'condition'   => function ( $user_id ) {
					return (int) get_user_meta( $user_id, 'nm_current_streak', true ) >= 100;
				},
			),
			'knowledge_seeker' => array(
				'name'        => 'Knowledge Seeker',
				'description' => 'Answered 100 questions correctly',
				'icon'        => '🎓',
				'points'      => 400,
				'condition'   => function ( $user_id ) {
					return (int) get_user_meta( $user_id, 'nm_correct_answers', true ) >= 100;
				},
			),
			'expert_level_10'  => array(
				'name'        => 'Expert',
				'description' => 'Reached Level 10',
				'icon'        => '🌟',
				'points'      => 800,
				'condition'   => function ( $user_id ) {
					return (int) get_user_meta( $user_id, 'nm_level', true ) >= 10;
				},
			),
			'master_level_20'  => array(
				'name'        => 'Master',
				'description' => 'Reached Level 20',
				'icon'        => '🚀',
				'points'      => 2000,
				'condition'   => function ( $user_id ) {
					return (int) get_user_meta( $user_id, 'nm_level', true ) >= 20;
				},
			),
			'social_butterfly' => array(
				'name'        => 'Social Butterfly',
				'description' => 'Shared 10 results on social media',
				'icon'        => '🦋',
				'points'      => 300,
				'condition'   => function ( $user_id ) {
					return (int) get_user_meta( $user_id, 'nm_shares_count', true ) >= 10;
				},
			),
		);
	}

	/**
	 * Get user stats
	 */
	public function get_user_stats() {
		check_ajax_referer( 'nm_auth_nonce', 'nonce' );

		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array( 'message' => 'Please login first.' ) );
		}

		$user_id = get_current_user_id();

		$stats = array(
			'points'          => (int) get_user_meta( $user_id, 'nm_total_points', true ),
			'level'           => (int) get_user_meta( $user_id, 'nm_level', true ),
			'current_streak'  => (int) get_user_meta( $user_id, 'nm_current_streak', true ),
			'longest_streak'  => (int) get_user_meta( $user_id, 'nm_longest_streak', true ),
			'total_quizzes'   => (int) get_user_meta( $user_id, 'nm_total_quizzes', true ),
			'correct_answers' => (int) get_user_meta( $user_id, 'nm_correct_answers', true ),
			'wrong_answers'   => (int) get_user_meta( $user_id, 'nm_wrong_answers', true ),
			'achievements'    => get_user_meta( $user_id, 'nm_achievements', true ) ?: array(),
			'badges'          => get_user_meta( $user_id, 'nm_badges', true ) ?: array(),
		);

		// Calculate accuracy
		$total_answered    = $stats['correct_answers'] + $stats['wrong_answers'];
		$stats['accuracy'] = $total_answered > 0 ? round( ( $stats['correct_answers'] / $total_answered ) * 100, 2 ) : 0;

		// Points to next level
		$stats['points_to_next_level'] = self::get_points_to_next_level( $stats['points'] );

		wp_send_json_success( $stats );
	}

	/**
	 * Handle social share
	 */
	public function handle_share() {
		check_ajax_referer( 'nm_auth_nonce', 'nonce' );

		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array( 'message' => 'Please login first.' ) );
		}

		$user_id  = get_current_user_id();
		$platform = NM_Security_Manager::sanitize_text( $_POST['platform'] ?? '' );

		// Award points for sharing (once per day per platform)
		$last_share_key = "nm_last_share_{$platform}";
		$last_share     = get_user_meta( $user_id, $last_share_key, true );
		$today          = date( 'Y-m-d' );

		if ( $last_share !== $today ) {
			self::award_points( $user_id, self::POINTS_SHARE_RESULT, "social_share_{$platform}" );
			update_user_meta( $user_id, $last_share_key, $today );

			// Increment share count
			$shares = (int) get_user_meta( $user_id, 'nm_shares_count', true ) + 1;
			update_user_meta( $user_id, 'nm_shares_count', $shares );

			// Check achievement
			self::check_achievements( $user_id );

			wp_send_json_success( array( 'message' => 'Thanks for sharing! +' . self::POINTS_SHARE_RESULT . ' points' ) );
		} else {
			wp_send_json_success( array( 'message' => 'Already shared on ' . $platform . ' today' ) );
		}
	}

	/**
	 * Send level up notification
	 */
	private static function send_level_up_notification( $user_id, $level ) {
		// This can be extended to send email/push notifications
		update_user_meta(
			$user_id,
			'nm_pending_notification',
			array(
				'type'  => 'level_up',
				'level' => $level,
				'time'  => current_time( 'mysql' ),
			)
		);
	}

	/**
	 * Send achievement notification
	 */
	private static function send_achievement_notification( $user_id, $achievements ) {
		// This can be extended to send email/push notifications
		update_user_meta( $user_id, 'nm_pending_achievement_notification', $achievements );
	}

	/**
	 * Create database tables
	 */
	public static function create_tables() {
		global $wpdb;
		$charset_collate = $wpdb->get_charset_collate();

		// Points log table
		$sql1 = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}nm_points_log (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id bigint(20) UNSIGNED NOT NULL,
            points int(11) NOT NULL,
            reason varchar(255) DEFAULT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY created_at (created_at)
        ) $charset_collate;";

		// User answers log table
		$sql2 = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}nm_user_answers (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id bigint(20) UNSIGNED NOT NULL,
            mcq_id bigint(20) UNSIGNED NOT NULL,
            selected_answer varchar(10) NOT NULL,
            is_correct tinyint(1) NOT NULL DEFAULT 0,
            answered_at datetime NOT NULL,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY mcq_id (mcq_id),
            KEY answered_at (answered_at)
        ) $charset_collate;";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql1 );
		dbDelta( $sql2 );
	}
}
