<?php
/**
 * COMPETITOR COMPARISON TABLE RENDERER
 *
 * @MODIFIED 2026-06-14 — Gutenberg block recovery fix (class-competitor-renderer.php):
 *
 * WHY: The block comment attributes were encoded using bare wp_json_encode()
 * without the post-processing strtr() that WordPress core's
 * serialize_block_attributes() applies. Core's encoding converts -- to
 * \u002d\u002d, < to \u003c, & to \u0026, etc. Without this, the stored
 * attrs would not round-trip correctly through Gutenberg's parser.
 *
 * WHAT CHANGED:
 * 1. Added strtr() post-processing after wp_json_encode() to match WordPress
 *    core's serialize_block_attributes() encoding pattern exactly.
 *    Replaces: \\, --, <, >, &, " with their \uXXXX equivalents.
 *
 * FILES: class-competitor-renderer.php (this file)
 */

namespace SEO_Article_Generator\Generator\Renderers;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Handles rendering of competitor comparison tables
 */
class Competitor_Renderer
{
    use \SEO_Article_Generator\Traits\Markdown_Processor;

    /**
     * Render the competitor comparison block
     *
     * @param array $competitors Array of competitor data
     * @param array $article_data Full article data
     * @return string Complete wp:table block markup
     */
    public function render($competitors, $article_data)
    {
        if (empty($competitors)) {
            return '';
        }

        // Extract main software values from article_data
        $software_name = isset($article_data['tech_specs']['software_name'])
            ? $article_data['tech_specs']['software_name']
            : 'This Software';

        // Detect format
        $uses_new_format = isset($competitors[0]['comparison_fields']) && is_array($competitors[0]['comparison_fields']);

        // Build table HTML — figure wrapper is required by core/table block spec;
        // custom className and seo-gen-* classes provide comparison styling
        $table_html = '<table class="seo-gen-comparison-table">';

        if ($uses_new_format) {
            $table_html .= $this->build_comparison_table_new_format($competitors, $article_data, $software_name);
        } else {
            $table_html .= $this->build_comparison_table_legacy_format($competitors, $article_data, $software_name);
        }

        $table_html .= '</table>';

        // Wrap in wp:table block structure
        // Note: hasFixedLayout helps with consistent column widths
        $is_fixed   = isset($article_data['hasFixedLayout']) ? (bool)$article_data['hasFixedLayout'] : true;
        $class_name = 'seo-gen-comparison-table-block' . ($is_fixed ? ' has-fixed-layout' : '');

        $block_attrs = \strtr(
            \wp_json_encode(array(
                'hasFixedLayout' => $is_fixed,
                'className' => 'seo-gen-comparison-table-block',
            ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            array(
                '\\\\' => '\\u005c',
                '--'   => '\\u002d\\u002d',
                '<'    => '\\u003c',
                '>'    => '\\u003e',
                '&'    => '\\u0026',
                '\\"'  => '\\u0022',
            )
        );

        $html = '<!-- wp:table ' . $block_attrs . ' -->' . "\n";
        $html .= '<figure class="wp-block-table ' . \esc_attr($class_name) . '">' . "\n";
        $html .= $table_html . "\n";
        $html .= '</figure>' . "\n";
        $html .= '<!-- /wp:table -->';

        return $html;
    }

    /**
     * Build comparison table body for new format (dynamic fields from AI).
     */
    private function build_comparison_table_new_format($competitors, $article_data, $software_name)
    {
        $explicit_order = [];
        if (!empty($article_data['comparison_field_order']) && is_array($article_data['comparison_field_order'])) {
            foreach ($article_data['comparison_field_order'] as $field_name) {
                $field_name = trim((string) $field_name);
                if ($field_name !== '' && !in_array($field_name, $explicit_order, true)) {
                    $explicit_order[] = $field_name;
                }
            }
        }

        $discovered_order = $this->extract_field_order_from_competitors($competitors);
        $field_order = $explicit_order;

        foreach ($discovered_order as $field_name) {
            if (!in_array($field_name, $field_order, true)) {
                $field_order[] = $field_name;
            }
        }

        // Header row
        $html = '<thead><tr>';
        $html .= '<th>Feature</th>';
        $html .= '<th>' . \wp_kses_post(self::process_markdown($software_name)) . '</th>';
        foreach ($competitors as $competitor) {
            $html .= '<th>' . \wp_kses_post(self::process_markdown($competitor['name'] ?? 'Alternative')) . '</th>';
        }
        $html .= '</tr></thead>';

        $html .= '<tbody>';

        // Build field value lookup
        $competitor_values = [];
        foreach ($competitors as $idx => $competitor) {
            $competitor_values[$idx] = [];
            if (isset($competitor['comparison_fields']) && is_array($competitor['comparison_fields'])) {
                foreach ($competitor['comparison_fields'] as $field_data) {
                    $field_name = $field_data['field'] ?? '';
                    $competitor_values[$idx][$field_name] = $field_data['value'] ?? 'N/A';
                }
            }
        }

        // Data rows
        foreach ($field_order as $field_name) {
            $html .= '<tr>';
            $html .= '<td><strong>' . esc_html($field_name) . '</strong></td>';

            $main_value = $this->get_main_software_value_from_ai($field_name, $article_data);
            $icon = $this->get_comparison_icon($field_name, $main_value);
            $html .= '<td>' . $icon . wp_kses_post(self::process_markdown($main_value)) . '</td>';

            foreach ($competitors as $idx => $competitor) {
                $value = $competitor_values[$idx][$field_name] ?? 'N/A';
                $icon = $this->get_comparison_icon($field_name, $value);
                $html .= '<td>' . $icon . \wp_kses_post(self::process_markdown($value)) . '</td>';
            }
            $html .= '</tr>';
        }

        // Verdict row
        $has_verdicts = false;
        foreach ($competitors as $competitor) {
            if (!empty($competitor['verdict'])) {
                $has_verdicts = true;
                break;
            }
        }

        if ($has_verdicts) {
            $html .= '<tr>';
            $html .= '<td><strong>Our Pick</strong></td>';
            $html .= '<td>Best overall</td>';
            foreach ($competitors as $competitor) {
                $verdict = isset($competitor['verdict']) && $competitor['verdict'] !== ''
                    ? \wp_kses_post(self::process_markdown($competitor['verdict']))
                    : '';
                $html .= '<td>' . $verdict . '</td>';
            }
            $html .= '</tr>';
        }

        $html .= '</tbody>';
        return $html;
    }

    /**
     * Build comparison table body for legacy format.
     */
    private function build_comparison_table_legacy_format($competitors, $article_data, $software_name)
    {
        $tech_specs = $article_data['tech_specs'] ?? [];
        $main_price    = $tech_specs['price'] ?? $tech_specs['pricing'] ?? $tech_specs['cost']
            ?? ($article_data['download_section']['price'] ?? '')
            ?: 'Unknown';
        $main_license  = $tech_specs['license'] ?? 'Free';
        $main_platforms = $tech_specs['os_support'] ?? 'Windows';
        $main_file_size = $tech_specs['file_size'] ?? 'Unknown';
        $main_open_source = $this->infer_open_source($main_license);

        // Header row
        $html = '<thead><tr>';
        $html .= '<th>Feature</th>';
        $html .= '<th>' . \esc_html($software_name) . '</th>';
        foreach ($competitors as $competitor) {
            $html .= '<th>' . \esc_html($competitor['name'] ?? 'Alternative') . '</th>';
        }
        $html .= '</tr></thead><tbody>';

        // Price row
        $html .= '<tr>';
        $html .= '<td><strong>Price</strong></td>';
        $is_free = (stripos($main_price, 'free') !== false || stripos($main_price, 'open') !== false);
        $html .= '<td>' . ($is_free ? '✅ ' : '💰 ') . \esc_html($main_price) . '</td>';
        foreach ($competitors as $competitor) {
            $price = $competitor['price'] ?? 'Unknown';
            $icon = (stripos($price, 'free') !== false) ? '✅ ' : '💰 ';
            $html .= '<td>' . $icon . \esc_html($price) . '</td>';
        }
        $html .= '</tr>';

        // Platform row
        $html .= '<tr>';
        $html .= '<td><strong>Platforms</strong></td>';
        $html .= '<td>' . \esc_html($main_platforms) . '</td>';
        foreach ($competitors as $competitor) {
            $platforms = isset($competitor['platforms']) && is_array($competitor['platforms'])
                ? implode(', ', array_map('\\esc_html', $competitor['platforms']))
                : ($competitor['platforms'] ?? 'Unknown');
            $html .= '<td>' . $platforms . '</td>';
        }
        $html .= '</tr>';

        // Open Source row
        $html .= '<tr>';
        $html .= '<td><strong>Open Source</strong></td>';
        $html .= '<td>' . ($main_open_source ? '✅ Yes' : '❌ No') . '</td>';
        foreach ($competitors as $competitor) {
            $open = isset($competitor['open_source']) && $competitor['open_source'];
            $html .= '<td>' . ($open ? '✅ Yes' : '❌ No') . '</td>';
        }
        $html .= '</tr>';

        // File Size row
        $html .= '<tr>';
        $html .= '<td><strong>File Size</strong></td>';
        $html .= '<td>' . \esc_html($main_file_size) . '</td>';
        foreach ($competitors as $competitor) {
            $size = $competitor['file_size'] ?? 'Unknown';
            $html .= '<td>' . \esc_html($size) . '</td>';
        }
        $html .= '</tr>';

        // Verdict row
        $html .= '<tr>';
        $html .= '<td><strong>Our Pick</strong></td>';
        $html .= '<td>Best overall</td>';
        foreach ($competitors as $competitor) {
            $verdict = isset($competitor['verdict']) && $competitor['verdict'] !== ''
                ? \esc_html($competitor['verdict'])
                : '';
            $html .= '<td>' . $verdict . '</td>';
        }
        $html .= '</tr>';

        $html .= '</tbody>';
        return $html;
    }

    private function extract_field_order_from_competitors($competitors)
    {
        $ordered_fields = [];
        $seen_fields    = [];

        foreach ($competitors as $competitor) {
            if (!empty($competitor['comparison_fields']) && is_array($competitor['comparison_fields'])) {
                foreach ($competitor['comparison_fields'] as $field_data) {
                    $field_name = $field_data['field'] ?? '';
                    if ($field_name !== '' && !isset($seen_fields[$field_name])) {
                        $ordered_fields[]         = $field_name;
                        $seen_fields[$field_name] = true;
                    }
                }
            }
        }

        return !empty($ordered_fields) ? $ordered_fields : ['Price', 'Platform'];
    }

    private function get_main_software_value_from_ai($field_name, $article_data)
    {
        if (!empty($article_data['main_software_comparison']) && is_array($article_data['main_software_comparison'])) {
            foreach ($article_data['main_software_comparison'] as $field_data) {
                if (!empty($field_data['field']) && !empty($field_data['value'])) {
                    if (strtolower($field_data['field']) === strtolower($field_name)) {
                        return $field_data['value'];
                    }
                }
            }
        }
        return $this->get_main_software_value($field_name, $article_data);
    }

    private function get_main_software_value($field_name, $article_data)
    {
        $tech_specs = $article_data['tech_specs'] ?? [];
        $field_lower = strtolower($field_name);

        if (in_array($field_lower, ['price', 'pricing', 'cost'])) {
            $price = $tech_specs['price'] ?? $tech_specs['pricing'] ?? $tech_specs['cost'] ?? '';
            if ($price !== '') {
                return $price;
            }
            $download_price = $article_data['download_section']['price'] ?? '';
            return $download_price !== '' ? $download_price : 'Unknown';
        }
        if (in_array($field_lower, ['platform', 'platforms', 'os support', 'os'])) {
            return $tech_specs['os_support'] ?? 'Windows';
        }
        if (in_array($field_lower, ['file size', 'size', 'download size'])) {
            return $tech_specs['file_size'] ?? '—';
        }
        if (in_array($field_lower, ['open source', 'open-source'])) {
            $license = $tech_specs['license'] ?? '';
            return $this->infer_open_source($license) ? 'Yes' : 'No';
        }
        if (in_array($field_lower, ['version', 'latest version'])) {
            return $tech_specs['version'] ?? '—';
        }
        if (strpos($field_lower, 'learning curve') !== false) {
            return 'Medium';
        }
        if (strpos($field_lower, 'portable') !== false) {
            return 'Yes';
        }
        return '—';
    }

    private function get_comparison_icon($field_name, $value)
    {
        $value_lower = strtolower($value);
        $field_lower = strtolower($field_name);

        if (in_array($field_lower, ['price', 'pricing', 'cost'])) {
            if (strpos($value_lower, 'free') !== false) {
                return '✅ ';
            }
            return '💰 ';
        }

        if (in_array($value_lower, ['yes', 'true', 'included', 'built-in', 'supported'])) {
            return '✅ ';
        }
        if (in_array($value_lower, ['no', 'false', 'none', 'limited', 'n/a'])) {
            return '❌ ';
        }

        return '';
    }

    private function infer_open_source($license)
    {
        return (stripos($license, 'open source') !== false || stripos($license, 'gpl') !== false || stripos($license, 'mit') !== false);
    }
}
