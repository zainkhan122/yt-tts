/**
 * AI Background Studio (Deprecated - OpenAI/DALL-E 3 removed)
 */

(function (window, $) {
  "use strict";

  const MCQVS_AIBackgroundStudio = {
    config: {
      ajaxurl: "",
      nonce: "",
    },

    init: function (config) {
      this.config = { ...this.config, ...config };
      console.log("[NM AI Background] Initialized");
    },

    /**
     * Generate an AI background (removed - no longer available)
     */
    generate: async function () {
      throw new Error("AI background generation is no longer available.");
    },

    /**
     * Apply a URL to the background
     * @param {string} url
     * @param {object} studio - Reference to the main MCQVS_Studio
     */
    applyToStudio: function (url, studio) {
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.onload = () => {
        studio.state.bgImage = img;
        studio.state.useVideoBg = false;
        console.log("[NM AI Background] Applied to studio");
      };
      img.src = url;
    },
  };

  window.MCQVS_AIBackgroundStudio = MCQVS_AIBackgroundStudio;
})(window, jQuery);
