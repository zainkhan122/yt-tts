/**
 * MCQ Video Studio - Main Controller (Orchestrator)
 * 
 * @requires MCQVSLogger (studio.logger.js)
 * @requires MCQVS_PreviewManager (studio.preview.js)
 * @requires MCQVS_ExportManager (studio.export.js)
 * @requires MCQVS_AudioController (studio.audio.js)
 * @requires MCQVS_UIController (studio.ui.js)
 * 
 * Orchestrator for modular studio architecture.
 * Reduced from 258KB to ~30KB by extracting modules.
 * 
 * @version 8.7.1
 * @since 2026-02-01
 * 
 * Architecture:
 * - studio.logger.js: Structured logging system
 * - studio.preview.js: Canvas rendering & animation (60KB)
 * - studio.export.js: Web Worker export pipeline (80KB)
 * - studio.audio.js: Audio management & library (40KB)
 * - studio.ui.js: DOM bindings & event handlers (50KB)
 * - studio.controller.js: This orchestrator (30KB)
 */

(function (window, $) {
    'use strict';

    const Logger = window.MCQVSLogger;

class StudioController {
	// @NEW 2026-06-29: Converted from ES2022 `static RESOLUTION = { width: 1080, height: 1920 }`
	// to ES2017-compatible static assignment below to keep the IIFE-wrapped script parseable
	// by older/minified linters (was: "Unexpected Token =") without changing behavior.

	// @NEW 2026-04-24: Dynamic resolution from config (format-aware)
	getResolution() {
		const cs = this.config && this.config.canvasSize;
		if (cs && cs.width && cs.height) return { width: Number(cs.width), height: Number(cs.height) };
		return StudioController.RESOLUTION;
	}

	// @NEW 2026-04-24: Switch video format at runtime
	switchFormat(format) {
		if (format !== 'shorts' && format !== 'youtube') return;
		const sizes = { shorts: { width: 1080, height: 1920 }, youtube: { width: 1920, height: 1080 } };
		const newSize = sizes[format];
		this.config.canvasSize = newSize;
		this.state.videoFormat = format;
		this.state.width = newSize.width;
		this.state.height = newSize.height;

		if (this._canvas) {
			this._canvas.width = newSize.width;
			this._canvas.height = newSize.height;
		}

		this._invalidateRenderPlan();

		if (this.audio && typeof this.audio.invalidatePlan === 'function') {
			this.audio.invalidatePlan();
		}

		const previewScreen = document.getElementById('previewScreen');
		if (previewScreen) {
			previewScreen.classList.toggle('mcqvs-format-youtube', format === 'youtube');
		}

		if (Logger) Logger.info('FORMAT_SWITCHED', { format, width: newSize.width, height: newSize.height });

		this._reinitPreview();
	}

    constructor(config) {
            // @NEW 2026-02-02: Validate required config keys before init
            this.validateConfig(config);
            this.config = config;

            // @NEW 2026-02-25: SEO generator init (uses mcqvs_generate_seo endpoint)
            try {
                if (window.MCQVS_SEOGenerator && typeof window.MCQVS_SEOGenerator.init === 'function') {
                    window.MCQVS_SEOGenerator.init({
                        ajaxUrl: (config && (config.ajaxUrl || config.ajaxurl)) ? (config.ajaxUrl || config.ajaxurl) : (window.ajaxurl || ''),
                        nonce: (config && config.nonce) ? config.nonce : ''
                    });
                }
            } catch (_) { }

            // @FIX 2026-07-31: Seed MCQVS_TTSManager with the localized config so its
            //       server TTS (mcqvs_generate_tts AJAX) and web-speech fallback use the
            //       configured default voice/provider. Previously init() was never called,
            //       so config.ajaxUrl/nonce stayed empty and every TTS request fell back to
            //       the browser's default (often male) English voice.
            // @FIX 2026-08-11: HONOR 'webspeech' here (Studio preview only). The plugin's
            //       default TTS provider is webspeech, so previewing should work with ZERO
            //       server dependencies (browser SpeechSynthesis). Previously this forced
            //       webspeech→edge, so preview always hit the server (and only fell back to
            //       browser speech after a failed AJAX round-trip). Content Planner and the
            //       headless renderer are NOT affected — they normalize webspeech→edge
            //       server-side (get_studio_render_defaults / class-vs-headless-renderer).
            try {
                if (window.MCQVS_TTSManager && typeof window.MCQVS_TTSManager.init === 'function') {
                    const ttsCfg = (config && config.tts && typeof config.tts === 'object') ? config.tts : {};
                    let provider = String(ttsCfg.provider || 'webspeech').trim() || 'webspeech';
                    // Keep webspeech as-is for the Studio preview (no-server browser TTS).
                    window.MCQVS_TTSManager.init({
                        ajaxUrl: (config && (config.ajaxUrl || config.ajaxurl)) ? (config.ajaxUrl || config.ajaxurl) : (window.ajaxurl || ''),
                        nonce: (config && config.nonce) ? config.nonce : '',
                        provider: provider,
                        voice: String(ttsCfg.defaultVoice || '').trim() || 'en-US-AriaNeural'
                    });
                }
            } catch (_) { }

            // Core state
            this.state = {
                questions: [],
                currentTemplate: 'trivia',
                templateId: 'trivia', // canonical for preview/export parity
                fontOverride: null,   // @NEW 2026-02-07: Manual font selection
                timing: {
                    // @FIX 2026-08-11: Shorts-first defaults (25-40s sweet spot).
                    // hook 1.2s + ~7.8s/question + 3.2s outro. Long-form users can
                    // raise values in the Studio timing panel (auto-fit TTS still applies).
                    hookIntro: 1200,
                    questionAppear: 600,
                    optionsAppear: 500,

                    // reading/thinking time — keep tight so a 5-Q Short lands ~40s
                    userThinkTime: 4600,

                    // reveal window stays 2s (so revealStart = 0.6+0.5+5.2 = 6.3s w/ 2s reveal)
                    revealAnswer: 2000,

                    outroDuration: 3200
                },

                audioEnabled: true,
                sfxEnabled: true,
                musicEnabled: true,
                brandName: 'TheQuizWire',
                quizName: '',
                // @NEW 2026-02-25: SEO metadata (High-Performer)
                seoKeywords: '',
                seoMeta: { title: '', description: '', tags: [] },
                hookText: 'Can you score 5/5?',
                // @FIX 1.4.9.52: seed from the persisted planner option
                // (MCQVS_Config.defaultHookVisible) so the Studio toggle reflects the
                // user's last choice instead of resetting to ON on every page load.
                hookVisible: (config && config.defaultHookVisible !== undefined) ? !!config.defaultHookVisible : true,
                ctaText: 'Subscribe for more!',
                ctaStyle: 'score', // score|subscribe|comment|follow|like|share|link|custom (score = Comment your score X/X)
                useRankCta: false,
                computedCtaText: '',
                websiteUrl: '',
                brandLogoImage: null,
                brandLogoDataUrl: '', // persisted logo
                brandLogoUrl: '', // persisted logo URL (preferred)
                logoPosition: 'all',  // TemplateManager expects: 'corner' | 'outro' | 'all'
                // @NEW 2026-08-11: Explanation bar toggle — seeded from Settings >
                // Defaults & Scheduling > Show Answer Explanations (default OFF).
                showExplanation: !!(config && config.showExplanation),
		bgImage: null,
		bgVideoFrames: null,
		bgColor: '#000000',

		// @NEW 2026-04-24: Video format (shorts/youtube) + canvas dimensions
		videoFormat: (config && config.videoFormat) || 'shorts',
		width: (config && config.canvasSize && config.canvasSize.width) || 1080,
		height: (config && config.canvasSize && config.canvasSize.height) || 1920,

                // @RESTORED 2026-02-03: Legacy Feature Parity
                // @NEW 2026-02-03: Sidebar selection is export source of truth
                selectedQuestions: [],

                // @NEW 2026-02-11: Pagination
                currentPage: 1,
                pageSize: 10,

                // Job Manager State
                jobHistory: JSON.parse(localStorage.getItem('mcqvs_studio_jobs') || '[]'),
                activeJobId: null,
                activeProjectId: null,
                // Multi-Scene Story Logic
                scenes: [],
                currentSceneId: null,
                sceneHistory: [],
                // Kinetic Overlays State
                overlays: [],
                activeKeywords: new Set(),
                // ============================================================
                // Voiceover (TTS) - exported into the final MP4 (server-side TTS)
                // ============================================================
                // @FIX 2026-07-31: Seed voiceover defaults from the WordPress
                //       settings (MCQVS_Config.tts.defaultVoice / .provider) instead
                //       of hardcoded Aria/edge. The settings page states this voice
                //       is used across the ENTIRE plugin when rotation is disabled —
                //       the studio must honor it on first load. webspeech is
                //       preview-only (browser voice, often male) and cannot honor the
                //       configured Edge default voice, so map it to 'edge' exactly as
                //       the content planner / headless renderer do.
                voiceover: (() => {
                    const ttsCfg = (config && config.tts && typeof config.tts === 'object') ? config.tts : {};
                    // @FIX 2026-08-11: Honor 'webspeech' (plugin default) so Studio preview
                    //       uses browser SpeechSynthesis with NO server dependency. The
                    //       #ttsProvider dropdown lets the user switch to edge/google/azure
                    //       for server TTS. Export + Content Planner/headless are unaffected
                    //       (webspeech is preview-only; export forces server TTS).
                    let provider = String(ttsCfg.provider || 'webspeech').trim() || 'webspeech';
                    const defaultVoice = String(ttsCfg.defaultVoice || '').trim() || 'en-US-AriaNeural';
                    // @FIX 2026-08-11: Honor the "Speak options aloud" plugin setting
                    //                  (mcqvs_tts_speak_options) when seeding the Studio
                    //                  voiceover so Studio matches the automation pipeline.
                    const speakOptionsDefault = (ttsCfg.speakOptions !== undefined) ? !!ttsCfg.speakOptions : true;
                    // @FIX 1.4.9.49 (TTS SSOT): every knob reads from Settings
                    // (mcqvs_tts_enabled / _rate / _speak_hook / _speak_answer /
                    // _speak_cta). Studio only SEEDS from settings — it never
                    // overrides the global defaults; the panel reflects them.
                    return {
                        enabled: (ttsCfg.enabled !== undefined) ? !!ttsCfg.enabled : true,
                        provider: provider,
                        voice: defaultVoice,
                        rate: (ttsCfg.rate !== undefined) ? Number(ttsCfg.rate) : 1.2,
                        pitch: 0,
                        answerPhrase: 'correct answer is',
                        speakHook: (ttsCfg.speakHook !== undefined) ? !!ttsCfg.speakHook : true,
                        speakOptions: speakOptionsDefault,
                        speakAnswer: (ttsCfg.speakAnswer !== undefined) ? !!ttsCfg.speakAnswer : true,
                        speakCta: (ttsCfg.speakCta !== undefined) ? !!ttsCfg.speakCta : false,
                        autoFitTiming: true
                    };
                })()
            };

            // Module instances
            this.preview = null;
            this.audio = null;
            this.ui = null;
            this.export = null;

            if (Logger) {
                Logger.info('CONTROLLER_INIT', { version: '8.7.1' });
            }
        }

        /**
         * Initialize studio
         */
        async initialize() {
            console.log('[MCQVS DEBUG] Controller initialize() started');

            // Step 1 — load dependencies
            try {
                await this.loadDependencies();
                console.log('[MCQVS DEBUG] loadDependencies OK');
            } catch (e) {
                console.error('[MCQVS DEBUG] loadDependencies FAILED:', e.message);
                if (Logger) Logger.error('INIT_STEP_DEPENDENCIES', { error: e.message });
                throw e;
            }

            // Step 2 — Asset Library
            try {
                if (window.MCQVS_AssetLibrary) {
                    await window.MCQVS_AssetLibrary.init(this.config);
                }
                console.log('[MCQVS DEBUG] AssetLibrary init OK');
            } catch (e) {
                console.warn('[MCQVS DEBUG] AssetLibrary init skipped:', e.message);
            }

            // Step 3 — modules
            try {
                this.initializeModules();
                console.log('[MCQVS DEBUG] initializeModules OK');
            } catch (e) {
                console.error('[MCQVS DEBUG] initializeModules FAILED:', e.message);
                if (Logger) Logger.error('INIT_STEP_MODULES', { error: e.message });
                throw e;
            }

            // Step 4 — load state
            try {
                this.loadState();
                console.log('[MCQVS DEBUG] loadState OK');
            } catch (e) {
                console.warn('[MCQVS DEBUG] loadState failed:', e.message);
            }

            // Step 5 — branding
            try {
                await this.loadBrandingFromServer();
                console.log('[MCQVS DEBUG] loadBrandingFromServer OK');
            } catch (e) {
                console.warn('[MCQVS DEBUG] loadBrandingFromServer failed:', e.message);
            }

            // Step 6 — setup UI
            try {
                this.setupUI();
                console.log('[MCQVS DEBUG] setupUI OK');
            } catch (e) {
                console.error('[MCQVS DEBUG] setupUI FAILED:', e.message);
                if (Logger) Logger.error('INIT_STEP_SETUPUI', { error: e.message });
                throw e;
            }

            // Step 7 — data source
            try {
                const defaultType = (this.ui && this.ui.getSourceType) ? this.ui.getSourceType() : 'topic';
                await this.loadSourceItems(defaultType);
                console.log('[MCQVS DEBUG] loadSourceItems OK');
            } catch (e) {
                console.warn('[MCQVS DEBUG] loadSourceItems failed:', e.message);
            }

            // Step 8 — ready
            try {
                this.onReady();
                console.log('[MCQVS DEBUG] CONTROLLER_READY');
                if (Logger) Logger.info('CONTROLLER_READY');
            } catch (e) {
                console.warn('[MCQVS DEBUG] onReady failed:', e.message);
            }
        }

        /**
         * Load required dependencies
         */
        async loadDependencies() {
            // @HOTFIX 2026-02-26: wait briefly for WP script globals (race/caching can delay them)
            const requiredModules = [
                'MCQVS_ExportManager',
                'MCQVS_AudioController',
                'MCQVS_PreviewPlayer',
                'MCQVS_TimelineEngine',
                'MCQVS_PlanBuilder',
                'MCQVS_UnifiedRenderer',
                'MCQVSVideoTemplates',
                'MCQVS_TemplateManager'
            ];

            const deadlineMs = Date.now() + 3500;
            let missing = [];

            while (Date.now() < deadlineMs) {
                missing = requiredModules.filter(m => !window[m]);

                if (!window.MCQVSStudio || !window.MCQVSStudio.UIController) {
                    if (!missing.includes('MCQVSStudio.UIController')) missing.push('MCQVSStudio.UIController');
                }

                if (!missing.length) {
                    if (Logger) Logger.info('DEPENDENCIES_LOADED');
                    return;
                }

                await new Promise(r => setTimeout(r, 50));
            }

            console.error('[MCQVS] Critical Dependency Failure:', missing);
            throw new Error(`Missing modules: ${missing.join(', ')}`);
        }

        /**
         * Initialize modules
         */
        initializeModules() {
            // Preview module
            // ============================
            // Preview Orchestration v2
            // preview.player.js + timeline.engine.js
            // ============================
            this._canvas = document.getElementById('previewCanvas');
            this._ctx = this._canvas ? this._canvas.getContext('2d', { alpha: false, desynchronized: true }) : null;

	if (this._canvas) {
		const res = this.getResolution();
		this._canvas.width = res.width;
		this._canvas.height = res.height;
	}

            this._renderer = new window.MCQVS_UnifiedRenderer();
            this._timeline = new window.MCQVS_TimelineEngine();
            this._player = new window.MCQVS_PreviewPlayer({ controller: this, timelineEngine: this._timeline });

            this._renderPlan = null;
            this._renderPlanDirty = true;
            this._previewRenderPlan = null;
            this._previewPlanDirty = true;

            // Compatibility facade used by existing controller code
            this.preview = {
                isPlaying: false,
                currentTime: 0,
                renderFrame: (ms) => this._renderAt(Number(ms) || 0, true),
                start: () => this.playPreview(),
                pause: () => this.pausePreview(),
                resume: () => this.playPreview(),
                stop: () => this.stopPreview()
            };

            // End handler (do NOT reset to 0; just stop transport)
            try {
                document.addEventListener('mcqvs:preview:ended', () => {
                    if (this.audio && typeof this.audio.stopAll === 'function') this.audio.stopAll();
                    const btn = document.getElementById('timelinePlayBtn');
                    if (btn) btn.classList.remove('playing');
                });
            } catch (_) { }


            // Audio module
            this.audio = new window.MCQVS_AudioController(this.state, this.config);
            this.audio.initialize();

            // UI module
            this.ui = new window.MCQVSStudio.UIController(this.state, this.config, {
                // @NEW 2026-02-03: Data Source pipeline
                onLoadSources: (type) => this.loadSourceItems(type),
                onLoadData: ({ type, id }) => this.loadStudioData(type, id),

                // @NEW 2026-02-03: Selection drives export
                onSelectedQuestionsChange: () => this.handleStateChange(),

                onAddQuestion: () => this.addQuestion(),
                onEditQuestion: (idx) => this.editQuestion(idx),
                onDeleteQuestion: (idx) => this.deleteQuestion(idx),
                onClearQuestions: () => this.clearQuestions(),
                onSelectTemplate: (tpl) => this.selectTemplate(tpl),
                onStateChange: () => this.handleStateChange(),
                onLogoUpload: (file) => this.handleLogoUpload(file),
                onSaveBranding: () => this.saveBrandingToServer(),
                onBackgroundUpload: (file) => this.handleBackgroundUpload(file),
                onPlay: () => this.playPreview(),
                onPause: () => this.pausePreview(),
                onStop: () => this.stopPreview(),
                onExport: () => this.startExport(),
                onCancelExport: () => this.cancelExport(),
		// @NEW 2026-02-07: Font Override
		onFontChange: (font) => this.handleFontChange(font),

		// @NEW 2026-04-24: Video Format Toggle
		switchFormat: (format) => this.switchFormat(format),

                // @NEW 2026-02-11: Pagination
                // @NEW 2026-02-11: Pagination
                onPrevPage: () => this.handlePrevPage(),
                onNextPage: () => this.handleNextPage(),

                // @NEW 2026-02-16: Auto-Runner
                onAutoProcessToggle: (enabled) => this.toggleAutoProcess(enabled),
                onPlanContent: () => this.ui.showModal('contentPlannerModal'),
                onGeneratePlan: (niche) => this.handleGeneratePlan(niche),
                onApprovePlan: (topics) => this.handleApprovePlan(topics),

                // @NEW 2026-03-05: Centralized job settings for Auto-Runner
                applyJobSettings: (settings) => this.applyJobSettings(settings),

                // @NEW 2026-02-23: AI Settings & Tools Callbacks
                onSaveTtsSettings: (settings) => this.handleSaveTtsSettings(settings),

                // AI tools
                onGenerateAIQuiz: () => this.handleGenerateAIQuiz_sidebar(),
                onGenerateBackground: () => this.handleGenerateBackground_sidebar(),

                // SEO card
                onGenerateSEOData: (payload) => this.handleGenerateSEO(payload),
                onAfterQuizGenerated: (meta) => this.handleAfterQuizGenerated(meta),

                // Project tools
                onExportProject: () => this.exportProjectSnapshot(),
                onImportProject: (data) => this.importProjectSnapshot(data),
                onCaptureThumbnail: () => this.captureThumbnail()
            });
            this.ui.initialize();

            // @MODIFIED 2026-02-08: Removed duplicate export progress listener (handled in startExport)
            // Was causing double-toasts + raw HTML artifacts.

            // Export module (lazy-loaded on demand)
            // Created in startExport()

            if (Logger) {
                Logger.info('MODULES_INITIALIZED');
            }
        }

        /**
         * Setup UI
         */
        setupUI() {
            this.ui.renderQuestionsList();
            this.ui.updateTotalDuration();

            // Set initial values
            this.syncUIFromState();

            // One-time DOM bindings not handled in UIController yet
            this.bindTimelineUI();
            this.bindDiagnosticsUI();

            // Initial timeline sync
            this.updateComputedValues();
            this.syncTimelineMetrics();
            this.updateTimelineUI(0);

            // Initial preview paint (and auto-seek to first question if Hook is hidden)
            try {
                let t0 = 0;
                const plan = this._ensureRenderPlan ? this._ensureRenderPlan() : null;
                const firstQ = plan && Array.isArray(plan.scenes) ? plan.scenes.find(sc => sc && sc.type === 'question') : null;
                if (firstQ && this.state && this.state.hookVisible === false) {
                    t0 = Number(firstQ.startMs) || 0;
                }
                const scrub = document.getElementById('timelineScrubber');
                if (scrub) scrub.value = String(Math.max(0, Math.floor(t0)));
                if (this._renderAt) this._renderAt(t0, true);
                this.updateTimelineUI(t0);
            } catch (_) { }
        }

        /**
         * Sync UI from state
         */
        syncUIFromState() {
            const fields = {
                'brandName': this.state.brandName,
                'quizName': this.state.quizName,
                'hookText': this.state.hookText,
                'ctaText': this.state.ctaText,
                'websiteUrl': this.state.websiteUrl
            };

            Object.entries(fields).forEach(([id, value]) => {
                const el = document.getElementById(id);
                if (el) el.value = value || '';
            });

            // Hook visibility (visual only)
            const hookVis = document.getElementById('hookVisibleToggle');
            if (hookVis) hookVis.checked = (this.state.hookVisible !== false);

            // Timing fields
            Object.entries(this.state.timing).forEach(([key, value]) => {
                const el = document.getElementById(`timing-${key}`);
                if (el) el.value = value;
            });

            // Audio toggles
            const audioToggle = document.getElementById('enableMasterAudioToggle');
            if (audioToggle) audioToggle.checked = this.state.audioEnabled;

            const sfxToggle = document.getElementById('enableSFXToggle');
            if (sfxToggle) sfxToggle.checked = this.state.sfxEnabled;

            const musicToggle = document.getElementById('enableMusicToggle');
            if (musicToggle) musicToggle.checked = this.state.musicEnabled;

            // Voiceover (TTS)
            const vo = this.state.voiceover || {};
            const voEnabled = document.getElementById('enableVoiceoverToggle');
            if (voEnabled) voEnabled.checked = !!vo.enabled;

            const speakHook = document.getElementById('ttsSpeakHookToggle');
            if (speakHook) speakHook.checked = (vo.speakHook !== false);

            const speakOpts = document.getElementById('ttsSpeakOptionsToggle');
            if (speakOpts) speakOpts.checked = (vo.speakOptions !== false);

            const speakAns = document.getElementById('ttsSpeakAnswerToggle');
            if (speakAns) speakAns.checked = (vo.speakAnswer !== false);

            const speakCta = document.getElementById('ttsSpeakCtaToggle');
            if (speakCta) speakCta.checked = !!vo.speakCta;

            const voiceSel = document.getElementById('voiceSelect');
            if (voiceSel && vo.voice) voiceSel.value = String(vo.voice);

            const ttsProv = document.getElementById('ttsProvider');
            if (ttsProv && vo.provider) {
                ttsProv.value = String(vo.provider);
                // Ensure sub-settings visibility updates
                try { ttsProv.dispatchEvent(new Event('change')); } catch (_) { }
            }
            this.syncLogoCardUIFromState();
        }

        /**
         * Handle state change
         */
        handleStateChange() {
            // Normalize derived timing BEFORE persisting
            this.updateComputedValues();
            this._invalidateRenderPlan();

            // Audio plan depends on timing/template/selection
            if (this.audio && typeof this.audio.invalidatePlan === 'function') {
                this.audio.invalidatePlan();
            }

            // Save state (persist normalized timing + derived fields)
            this.saveState();



            // Sync timeline bounds (questions/timing changed)
            this.syncTimelineMetrics();

            // Trigger preview update at current scrub position (do NOT reset to 0)
            if (this.preview && !this.preview.isPlaying) {
                const scrub = document.getElementById('timelineScrubber');
                const t = scrub ? (Number(scrub.value) || 0) : 0;
                this.preview.renderFrame(t);
                this.updateTimelineUI(t);
            }
        }

        /**
         * Update computed values
         */

        /**
         * Update computed values
         * - Normalizes timing
         * - Computes CTA text (style + rank system)
         * - OPTION 2: Auto-fit timing to voiceover so narration never clips
         */
        updateComputedValues() {
            // ========================
            // CTA resolution
            // ========================
            const style = String(this.state.ctaStyle || '').trim().toLowerCase() || 'subscribe';
            const useRank = !!this.state.useRankCta;

            let baseCta = 'Subscribe for more!';
            if (useRank) {
                baseCta = 'Comment your score!';
            } else if (style === 'score') {
                // @NEW 2026-08-11: dynamic score challenge — includes the question total.
                const qTotal = (Array.isArray(this.state.selectedQuestions) && this.state.selectedQuestions.length)
                    ? this.state.selectedQuestions.length
                    : (Array.isArray(this.state.questions) ? this.state.questions.length : 0);
                baseCta = 'Comment your score 👇 ' + (qTotal > 0 ? qTotal + '/' + qTotal + '?' : 'below!');
            } else if (style === 'comment') {
                baseCta = 'Comment your score!';
            } else if (style === 'follow') {
                baseCta = 'Follow for more!';
            } else if (style === 'custom') {
                baseCta = String(this.state.ctaText || '').trim() || 'Subscribe for more!';
            }

            this.state.computedCtaText = String(baseCta)
                .replace('{brand}', this.state.brandName || '')
                .replace('{quiz}', this.state.quizName || '');

            // ========================
            // Timing normalization
            // ========================
            const t = this.state.timing || (this.state.timing = {});

            // NOTE: Number('') === 0. Empty-string persistence can silently zero out durations.
            const ms = (v, d, min = null) => {
                const n = Number(v);
                if (!Number.isFinite(n)) return d;
                if (min != null && n < min) return d;
                return n;
            };
            const msAllowZero = (v, d) => {
                const n = Number(v);
                if (!Number.isFinite(n) || n < 0) return d;
                return n;
            };

            // Allow skipping hook/outro; keep question phases sane
            // @FIX 2026-08-11: Shorts-first fallbacks (matches the new state.timing defaults).
            t.hookIntro = msAllowZero(t.hookIntro, 1200);
            t.outroDuration = msAllowZero(t.outroDuration, 3200);
            t.questionAppear = msAllowZero(t.questionAppear, 600);
            t.optionsAppear = msAllowZero(t.optionsAppear, 500);

            let thinkMs = ms(t.userThinkTime, 4600, 500);
            let revealMs = ms(t.revealAnswer, 2000, 200);

            // ========================
            // OPTION 2: Auto-fit timing to voiceover (global worst-case)
            // ========================
            const vo = (this.state && this.state.voiceover) ? this.state.voiceover : null;
            const autoFit = !!(vo && vo.enabled && vo.autoFitTiming !== false);

            let didAutoBump = false;
            if (autoFit) {
                const rate = Number.isFinite(Number(vo.rate)) ? Number(vo.rate) : 1.0;

                const normalize = (s) => String(s || '')
                    .replace(/<[^>]+>/g, ' ')
                    .replace(/[\r\n\t]+/g, ' ')
                    .replace(/\s{2,}/g, ' ')
                    .trim();

                const countWords = (s) => {
                    const txt = normalize(s);
                    if (!txt) return 0;
                    return txt.split(/\s+/).filter(Boolean).length;
                };

                // Conservative speaking speed (over-estimate to avoid clipping)
                const baseWpm = 150;
                const r = Math.max(0.6, Math.min(1.4, rate));
                const wps = Math.max(1.2, (baseWpm / 60) * r);

                const estimateMs = (text) => {
                    const txt = normalize(text);
                    if (!txt) return 0;
                    const wc = countWords(txt);
                    const punct = (txt.match(/[.!?]/g) || []).length;
                    const sec = (wc / wps) + 0.35 + Math.min(1.5, punct * 0.16);
                    // 15% safety margin
                    return Math.max(800, Math.ceil(sec * 1000 * 1.15));
                };

                const letter = (i) => ['A', 'B', 'C', 'D'][Number(i) || 0] || 'A';

                const qsAll = Array.isArray(this.state.questions) ? this.state.questions : [];
                const sel = (Array.isArray(this.state.selectedQuestions) && this.state.selectedQuestions.length)
                    ? this.state.selectedQuestions
                    : qsAll.map((_, i) => i);

                let maxReadMs = 0;
                let maxAnsMs = 0;

                sel.forEach((idx, seq) => {
                    const q = qsAll[Number(idx)] || null;
                    if (!q) return;

                    const qText = normalize(q.question || q.text || '');
                    const opts = Array.isArray(q.options) ? q.options.map(o => normalize(o)) : [];
                    const correct = Number.isInteger(q.correct) ? q.correct : (parseInt(q.correct, 10) || 0);

                    // Export parity: "Question N" + options in same segment
                    let line = qText ? `Question ${seq + 1}. ${qText}.` : `Question ${seq + 1}.`;
                    if (vo.speakOptions !== false && opts.length) {
                        if (opts[0]) line += ` ${opts[0]}.`;
                        if (opts[1]) line += ` ${opts[1]}.`;
                        if (opts[2]) line += ` ${opts[2]}.`;
                        if (opts[3]) line += ` ${opts[3]}.`;
                    }
                    line = normalize(line);

                    const readMs = estimateMs(line);
                    if (readMs > maxReadMs) maxReadMs = readMs;

                    if (vo.speakAnswer !== false && opts.length) {
                        const ltr = letter(correct);
                        const optText = opts[Math.max(0, Math.min(3, correct))] || '';
                        const tplRaw = (typeof vo.answerPhrase === 'string') ? vo.answerPhrase : '';
                        const tpl = normalize(tplRaw) || 'correct answer is';

                        let ansText = '';
                        if (tplRaw && /\s/.test(tplRaw)) {
                            if (/\{letter\}|\{option\}|\{text\}/i.test(tplRaw)) {
                                ansText = tplRaw
                                    .replace(/\{letter\}/gi, ltr)
                                    .replace(/\{option\}|\{text\}/gi, optText);
                                ansText = normalize(ansText);
                            } else {
                                ansText = normalize(`${tpl} ${optText}.`);
                            }
                        } else {
                            ansText = normalize(`${tpl} ${optText}.`);
                        }

                        const ansMs = estimateMs(ansText);
                        if (ansMs > maxAnsMs) maxAnsMs = ansMs;
                    }
                });

                // Fit hook/outro if narrated
                if (vo.speakHook !== false) {
                    const hookMs = estimateMs(this.state.hookText || '');
                    if (hookMs && t.hookIntro < hookMs + 500) {
                        t.hookIntro = hookMs + 500;
                        didAutoBump = true;
                    }
                }

                if (vo.speakCta) {
                    const ctaMs = estimateMs(this.state.computedCtaText || this.state.ctaText || '');
                    if (ctaMs && t.outroDuration < ctaMs + 600) {
                        t.outroDuration = ctaMs + 600;
                        didAutoBump = true;
                    }
                }

                // Fit question reading window (time before reveal start)
                const preRevealMs = (Number(t.questionAppear) || 0) + (Number(t.optionsAppear) || 0);
                const neededThink = Math.max(0, (maxReadMs + 300) - preRevealMs);
                if (neededThink > thinkMs) {
                    thinkMs = neededThink;
                    didAutoBump = true;
                }

                // Fit answer into reveal window
                const neededReveal = Math.max(200, maxAnsMs + 250);
                if (neededReveal > revealMs) {
                    revealMs = neededReveal;
                    didAutoBump = true;
                }
            }

            // Assign normalized (possibly auto-bumped) timing
            t.userThinkTime = thinkMs;
            t.revealAnswer = revealMs;

            // Derive questionTotal so PlanBuilder remains consistent
            // @FIX 2026-07-01: Snap questionTotal to frame boundary so state.timing.questionTotal
            // agrees with render-plan.js scene.durMs. Without this, consumers that read
            // state.timing.questionTotal (export worker, template-manager, preview) see the
            // unsnapped value (e.g. 16592) while SFX cues use the snapped value (16600),
            // causing an 8ms SFX-vs-visual desync on every question.
            const _fps = Number(this.state.fps || 30);
            const _frameMs = 1000 / _fps;
            const _snapMs = (ms) => Math.max(0, Math.round(Number(ms || 0) / _frameMs)) * _frameMs;
            t.questionTotal = _snapMs(Math.max(800,
                (Number(t.questionAppear) || 0) +
                (Number(t.optionsAppear) || 0) +
                (Number(t.userThinkTime) || 0) +
                (Number(t.revealAnswer) || 0)
            ));
            t.hookIntro = _snapMs(t.hookIntro);
            t.outroDuration = _snapMs(t.outroDuration);

            // Keep compatibility
            t.questionPhases = t.questionPhases && typeof t.questionPhases === 'object' ? t.questionPhases : {};
            t.questionPhases.intro = Number(t.questionAppear) || 0;
            t.questionPhases.reveal = Number(t.revealAnswer) || 0;
            t.questionPhases.reading = Math.max(0,
                (Number(t.questionTotal) || 0) - (Number(t.questionAppear) || 0) - (Number(t.revealAnswer) || 0)
            );

            // Total duration
            const sel2 = Array.isArray(this.state.selectedQuestions) ? this.state.selectedQuestions : [];
            const qCount = sel2.length ? sel2.length : (this.state.questions || []).length;
            // @FIX 2026-08-11: When the hook is hidden, it contributes NO time — the
            //       first question starts immediately (matches the scene lists now that
            //       the hook scene is omitted). Mirrors plan.builder/server/export.
            const _hookMs = (this.state.hookVisible !== false) ? (Number(t.hookIntro) || 0) : 0;
            this.state.totalDurationMs =
                _hookMs +
                (qCount * (Number(t.questionTotal) || 0)) +
                (Number(t.outroDuration) || 0);

            // If auto-fit bumped timing, sync UI fields so user sees the real values.
            if (autoFit && didAutoBump) {
                try {
                    const setVal = (id, v) => {
                        const el = document.getElementById(id);
                        if (el) el.value = String(Math.max(0, Math.floor(Number(v) || 0)));
                    };
                    setVal('timing-userThinkTime', t.userThinkTime);
                    setVal('timing-revealAnswer', t.revealAnswer);
                    setVal('timing-hookIntro', t.hookIntro);
                    setVal('timing-outroDuration', t.outroDuration);
                } catch (_) { }
            }
        }


        // ============================================================
        // @RESTORED 2026-02-03: FEATURE PARITY (Job History)
        // ============================================================

        loadJobHistory() {
            try {
                const stored = localStorage.getItem('mcqvs_studio_jobs');
                this.state.jobHistory = stored ? JSON.parse(stored) : [];
            } catch (e) {
                if (Logger) Logger.warn('JOB_HISTORY_LOAD_FAIL', e);
                this.state.jobHistory = [];
            }
        }

        // @NEW 2026-04: Track active job/project for video_url updates
        setActiveJob(jobId) {
            this.state.activeJobId = jobId;
        }

        setActiveProject(projectId) {
            this.state.activeProjectId = projectId;
        }

        saveJob(job) {
            this.state.jobHistory.unshift(job);
            // Keep last 50
            if (this.state.jobHistory.length > 50) this.state.jobHistory.length = 50;
            localStorage.setItem('mcqvs_studio_jobs', JSON.stringify(this.state.jobHistory));
            if (Logger) Logger.info('JOB_SAVED', { id: job.id });
        }

        // ============================================================
        // @RESTORED 2026-02-03: FEATURE PARITY (Overlays & Scenes)
        // ============================================================

        addOverlay(overlay) {
            this.state.overlays.push(overlay);
            this.handleStateChange();
        }

        clearOverlays() {
            this.state.overlays = [];
            this.handleStateChange();
        }

        addScene(scene) {
            this.state.scenes.push(scene);
            // Basic API compatibility
        }

        /**
         * Question CRUD
         */
        addQuestion() {
            this.state.questions.push({
                question: 'New Question',
                options: ['Option A', 'Option B', 'Option C', 'Option D'],
                correct: 0
            });

            this.ui.renderQuestionsList();
            this.handleStateChange();

            if (Logger) {
                Logger.info('QUESTION_ADD', { total: this.state.questions.length });
            }
        }

        editQuestion(index) {
            const q = this.state.questions[index];
            if (!q) return;

            // Open edit modal (implement modal UI)
            this.ui.showModal('editQuestionModal');

            // Populate form
            document.getElementById('editQuestionText').value = q.question;
            q.options.forEach((opt, i) => {
                const el = document.getElementById(`editOption${i + 1}`);
                if (el) el.value = opt;
            });
            document.getElementById('editCorrectAnswer').value = q.correct;

            // Store edit index
            this.editingIndex = index;

            if (Logger) {
                Logger.info('QUESTION_EDIT_START', { index });
            }
        }

        saveQuestionEdit() {
            if (this.editingIndex === undefined) return;

            const q = this.state.questions[this.editingIndex];
            q.question = document.getElementById('editQuestionText').value;

            q.options = [];
            for (let i = 1; i <= 4; i++) {
                const el = document.getElementById(`editOption${i}`);
                if (el) q.options.push(el.value);
            }

            q.correct = parseInt(document.getElementById('editCorrectAnswer').value, 10);

            this.ui.renderQuestionsList();
            this.ui.hideModal('editQuestionModal');
            this.handleStateChange();

            if (Logger) {
                Logger.info('QUESTION_EDIT_SAVE', { index: this.editingIndex });
            }

            this.editingIndex = undefined;
        }

        deleteQuestion(index) {
            if (!confirm('Delete this question?')) return;

            this.state.questions.splice(index, 1);
            this.ui.renderQuestionsList();
            this.handleStateChange();

            if (Logger) {
                Logger.info('QUESTION_DELETE', { index, remaining: this.state.questions.length });
            }
        }

        clearQuestions() {
            this.state.questions = [];
            this.ui.renderQuestionsList();
            this.handleStateChange();

            if (Logger) {
                Logger.info('QUESTIONS_CLEAR');
            }
        }

        /**
         * Template selection
         */
        selectTemplate(template) {
            this.state.currentTemplate = template;
            this.state.templateId = template;

            // Update UI
            document.querySelectorAll('.mcqvs-template-card').forEach(card => {
                card.classList.toggle('selected', card.dataset.template === template);
            });

            // @FIX 2026-02-07: Apply template schema (colors/fonts/effects) to state
            if (window.MCQVSVideoTemplates) {
                window.MCQVSVideoTemplates.apply(template, this.state);
            }

            // @NEW 2026-02-07: Force update to apply font override if present
            if (this.state.fontOverride) {
                // Keep the override active
            }

            this.handleStateChange();
            if (this.ui) this.ui.showNotification('Template applied', 'success'); // [PATCH 2026-02-03]

            if (Logger) {
                Logger.info('TEMPLATE_SELECT', { template, fontOverride: this.state.fontOverride });
            }
        }

        /**
         * Handle manual font change
         * @NEW 2026-02-07
         */
        handleFontChange(font) {
            this.state.fontOverride = font;
            this.handleStateChange();

            if (Logger) {
                Logger.info('FONT_OVERRIDE_CHANGE', { font });
            }
        }

        /**
         * Asset uploads
         */
        async handleLogoUpload(file) {
            if (!file) return;

            try {
                const dataUrl = await this.fileToDataURL(file);
                const img = new Image();

                await new Promise((resolve, reject) => {
                    img.onload = resolve;
                    img.onerror = reject;
                    img.src = dataUrl;
                });

                this.state.brandLogoImage = img;
                this.state.brandLogoDataUrl = dataUrl;

                // Ensure the Branding card updates immediately (it was only updating after refresh)
                // @MODIFIED 2026-02-26: Force UI sync after upload
                if (typeof this.syncLogoCardUIFromState === 'function') this.syncLogoCardUIFromState();

                this.handleStateChange();

                // @MODIFIED 2026-02-27: Force immediate save so branding is NEVER lost even if quota is tight
                this.saveState();

                // Persist branding on server too (fixes refresh loss)
                this.saveBrandingToServer().catch(() => { });

                this.ui.showNotification('Logo uploaded successfully', 'success');

                if (Logger) {
                    Logger.info('LOGO_UPLOAD', { size: file.size });
                }

            } catch (error) {
                if (Logger) {
                    Logger.error('LOGO_UPLOAD_FAIL', { error: error.message });
                }
                this.ui.showNotification('Logo upload failed', 'error');
            }
        }

        async handleBackgroundUpload(file) {
            if (!file) return;

            try {
                const dataUrl = await this.fileToDataURL(file);

                // Check if video or image
                if (file.type.startsWith('video/')) {
                    await this.extractVideoFrames(dataUrl);

                    // @FIX 2026-07-31: A video background replaces any previously set
                    //       image background (AI-generated or earlier upload). Leaving a
                    //       stale bgImage could make the template fall back to it when
                    //       frame extraction is incomplete, producing a video whose
                    //       rendered background does not match the preview.
                    this.state.bgImage = null;

                    // Critical: refresh preview/state after bg video frames are ready [PATCH 2026-02-03]
                    this.handleStateChange();

                    this.ui.showNotification('Background video processed', 'success');
                } else {
                    const img = new Image();
                    await new Promise((resolve, reject) => {
                        img.onload = resolve;
                        img.onerror = reject;
                        img.src = dataUrl;
                    });
                    this.state.bgImage = img;
                    this.ui.showNotification('Background image uploaded', 'success');
                }

                this.handleStateChange();

                if (Logger) {
                    Logger.info('BACKGROUND_UPLOAD', {
                        size: file.size,
                        type: file.type
                    });
                }

            } catch (error) {
                if (Logger) {
                    Logger.error('BACKGROUND_UPLOAD_FAIL', { error: error.message });
                }
                this.ui.showNotification('Background upload failed', 'error');
            }
        }

    // @NEW 2026-03-05: Centralized setting application for Auto-Runner / Batch
    async applyJobSettings(settings) {
        if (!settings || typeof settings !== 'object') return;

        if (Logger) Logger.info('APPLY_JOB_SETTINGS', { settings });

        // 1. Clear previous job-specific state (Safety)
        this.state.bgVideoFrames = null;
        this.state.bgImage = null;
        this.state.bgVideoUrl = null;
        this.state.fontOverride = null;

        // 2. Template
        if (settings.template) {
            this.selectTemplate(String(settings.template));
        }

        // 3. Font
        if (settings.font) {
            this.handleFontChange(String(settings.font));
        }

        // 4. Music
        if (settings.music) {
            const base = (this.config.assetsUrl || (this.config.rootUrl + 'assets/') || (window.MCQVSConfig && window.MCQVSConfig.assetsUrl) || '').replace(/\/+$/, '');
            const file = String(settings.music).toLowerCase().endsWith('.mp3') ? settings.music : `${settings.music}.mp3`;
            this.state.bgMusicUrl = base ? `${base}/audio/music/${file}` : settings.music;
            this.state.musicEnabled = true;
        }

        // 5. Background Video (Direct URL support for Auto-Runner)
        if (settings.bg_video) {
            const url = String(settings.bg_video).trim();
            if (url) {
                this.state.bgVideoUrl = url;
                try {
                    await this.extractVideoFrames(url);
                } catch (e) {
                    console.warn('[MCQVS] BG video extraction failed:', e);
                }
            }
        }

        // 6. Save Mode (delivery pipeline: local / r2 / r2_buffer)
        if (settings.save_mode) {
            this.state.saveMode = settings.save_mode;
        }

        this.handleStateChange();
    }

        /**
         * Extract frames from video
         * @MODIFIED 2026-03-05: Added error handling and direct URL support
         */
        async extractVideoFrames(videoUrl) {
            return new Promise((resolve, reject) => {
                const video = document.createElement('video');
                video.crossOrigin = 'anonymous'; // Handle remote URLs [PATCH 2026-03-05]
                video.src = videoUrl;
                video.muted = true;
                video.playsInline = true;

                const canvas = document.createElement('canvas');
                const ctx = canvas.getContext('2d');

                // @FIX 2026-07-31: Draw extracted frames at the OUTPUT resolution
                //       (1080x1920 / 1920x1080) instead of the source's native size.
                //       Stock bg videos are often 4K; 90 full-resolution PNG data-URLs
                //       blew up memory so `createImageBitmap()` in prepareAssets() failed
                //       during export — the preview showed the video but the downloaded
                //       MP4 fell back to the template gradient (silent missing background).
                const res = (typeof this.getResolution === 'function') ? this.getResolution() : { width: 1080, height: 1920 };
                const outW = Math.max(1, Number(res.width) || 1080);
                const outH = Math.max(1, Number(res.height) || 1920);

                const frames = [];
                let frameCount = 0;
                const maxFrames = 60;

                const timeout = setTimeout(() => {
                    video.onloadedmetadata = null;
                    video.onseeked = null;
                    reject(new Error('Video frame extraction timed out'));
                }, 30000);

                video.onloadedmetadata = () => {
                    canvas.width = outW;
                    canvas.height = outH;

                    const duration = Math.max(0.1, Number(video.duration) || 1);
                    const interval = duration / maxFrames;

                    this.state.bgVideoFrameDur = interval * 1000;
                    // @FIX 2026-07-31: Persist the source so the export path can re-extract
                    //       frames at the correct resolution if the in-memory ones are lost.
                    this.state.bgVideoUrl = String(videoUrl || '');

                    const captureFrame = () => {
                        if (frameCount >= maxFrames) {
                            clearTimeout(timeout);
                            this.state.bgVideoFrames = frames;
                            resolve();
                            return;
                        }
                        video.currentTime = Math.min(duration, frameCount * interval);
                    };

                    const next = () => {
                        frameCount++;
                        captureFrame();
                    };

                    video.onseeked = () => {
                        try {
                            ctx.drawImage(video, 0, 0, outW, outH);
                            const img = new Image();
                            img.onload = next;
                            img.onerror = next;
                            // JPEG keeps each frame small enough for the export worker to
                            // convert all frames via createImageBitmap without OOM.
                            img.src = canvas.toDataURL('image/jpeg', 0.82);
                        } catch (e) {
                            next();
                        }
                    };

                    captureFrame();
                };

                video.onerror = (e) => {
                    clearTimeout(timeout);
                    reject(new Error('Video load error'));
                };
            });
        }

        /**
         * File to data URL
         */
        fileToDataURL(file) {
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = () => resolve(reader.result);
                reader.onerror = reject;
                reader.readAsDataURL(file);
            });
        }
        _invalidateRenderPlan() {
            this._renderPlanDirty = true;
            this._previewPlanDirty = true;
            if (this.audio && typeof this.audio.invalidatePlan === 'function') this.audio.invalidatePlan();
        }

        _ensureRenderPlan() {
            if (!this._renderPlanDirty && this._renderPlan) return this._renderPlan;

            try {
		this._renderPlan = window.MCQVS_PlanBuilder.buildFromState(this.state, {
			fps: 30,
			width: this.getResolution().width,
			height: this.getResolution().height,
                    templateId: this.state.templateId || 'trivia',
                    currentTemplate: this.state.templateId || this.state.currentTemplate || 'trivia',
                    assetConfig: {
                        musicUrl: this.state.bgMusicUrl || null,
                        sfx: (this.state.sfxUrls || {})
                    }
                });

                // @NEW 2026-06-29: Persist the canonical plan to state so the audio module
                // and exporter consume the EXACT same plan (single source of truth).
                if (this._renderPlan) this.state.renderPlan = this._renderPlan;

                // Validate hard
                if (window.MCQVS_RenderPlanValidator && typeof window.MCQVS_RenderPlanValidator.assertValid === 'function') {
                    window.MCQVS_RenderPlanValidator.assertValid(this._renderPlan);
                }

                // Configure deterministic timeline engine
                this._timeline.configure({ frameMs: this._renderPlan.frameMs, totalMs: this._renderPlan.totalMs });

                this._renderPlanDirty = false;
                return this._renderPlan;

            } catch (e) {
                this._renderPlan = null;
                this._renderPlanDirty = false;
                if (Logger) Logger.warn('PREVIEW_PLAN_FAIL', { error: e.message });
                return null;
            }
        }

        /**
         * Return the canonical render plan for preview.
         * Preview does not play TTS audio, so the baseline timing is correct.
         * Cached to avoid redundant validation on every frame.
         */
        _getPreviewPlan() {
            const canonical = this._ensureRenderPlan();
            if (!canonical) return null;
            if (!this._previewPlanDirty && this._previewRenderPlan) return this._previewRenderPlan;

            // @FIX 2026-07-30: Preview does not play TTS audio, so no timing adjustment
            //                   is needed. The canonical plan (baseline _revealStartRel =
            //                   durMs - revealMs) already has correct visual timing for
            //                   preview. Deep-clone is unnecessary — return canonical directly.
            this._previewRenderPlan = canonical;
            this._previewPlanDirty = false;
            return canonical;
        }

  _getBgImageAt(timeMs) {
    const frames = Array.isArray(this.state?.bgVideoFrames) ? this.state.bgVideoFrames : null;
    let bgImage = this.state?.bgImage || null;

    if (frames && frames.length) {
      const frameDuration = Number(this.state?.bgVideoFrameDur) > 0 ? Number(this.state.bgVideoFrameDur) : 33.33;
      const idx = Math.floor((Math.max(0, Number(timeMs) || 0)) / frameDuration) % frames.length;
      bgImage = frames[idx] || bgImage;
    }
    return bgImage;
  }

        /**
         * Called by PreviewPlayer every tick.
         * @param {number} timelineMs
         * @param {boolean} isManual
         */
    _renderAt(timelineMs, isManual) {
        if (!this._ctx || !this._renderer || !this._timeline) return;

        // @NEW 2026-04-22: Seed animation engine for deterministic preview/renderer parity
        try {
            if (window.MCQVS_AnimationEngine && MCQVS_AnimationEngine.setSeed) {
                const frameIndex = Math.floor(timelineMs / 33.33);
                MCQVS_AnimationEngine.setSeed(frameIndex * 7919);
            }
        } catch (_) { }

        const plan = this._getPreviewPlan();
            if (!plan) return;

            // Reset one-shot FX triggers on each play (Preview/Export parity)
            try { if (window.__MCQVS_FX_FIRED && window.__MCQVS_FX_FIRED.clear) window.__MCQVS_FX_FIRED.clear(); } catch (_) { }

            const t = Math.max(0, Number(timelineMs) || 0);
            this.preview.currentTime = t;

            // End-of-timeline stop (deterministic)
            if (plan.totalMs > 0 && t >= plan.totalMs) {
                this.preview.currentTime = plan.totalMs;
                this.preview.isPlaying = false;

                if (this._player && this._player.isRunning()) this._player.stop();
                if (this.audio && typeof this.audio.stopAll === 'function') this.audio.stopAll();

                this.updateTimelineUI(plan.totalMs);

                try {
                    document.dispatchEvent(new CustomEvent('mcqvs:preview:ended', { detail: { time: plan.totalMs } }));
                } catch (_) { }

                return;
            }

            // @MODIFIED 2026-02-06: Fix scene extraction - getActiveScene returns scene/index wrapper
            const sceneResult = this._timeline.getActiveScene(plan.scenes, t);
            const scene = sceneResult ? sceneResult.scene : null;
            const within = scene ? Math.max(0, t - (Number(scene.startMs) || 0)) : t;

            // @MODIFIED 2026-02-06: Calculate animation phase (Preview/Export Parity)
            // Determines reveal state for correct answer highlighting
            let animationPhase = 'idle';
            if (scene) {
                if (scene.type === 'hook') {
                    animationPhase = 'hook';
                } else if (scene.type === 'outro') {
                    animationPhase = 'outro';
                } else if (scene.type === 'cover') {
                    animationPhase = 'cover';
                } else if (scene.type === 'question') {
                    const timing = scene.timing || this.state.timing || {};
                    const introEnd = Number(timing.questionPhases?.intro || 1000);
                    const revealDur = Number(timing.questionPhases?.reveal || 3000);
                    const qTotal = Number(timing.questionTotal || scene.durMs || 12000);
                    const revealStart = (timing._revealStartRel !== undefined)
                        ? timing._revealStartRel
                        : Math.max(0, qTotal - revealDur);

                    if (within < introEnd) {
                        animationPhase = 'question_intro';
                    } else if (within < revealStart) {
                        animationPhase = 'question';
                    } else {
                        animationPhase = 'reveal';
                    }
                }
            }

            const renderState = {
                // timebase
                time: t,
                elapsed: t, // @MODIFIED 2026-02-26: Use absolute time for FX parity
                elapsedInScene: within,
                fps: plan.fps || 30,
                frameIndex: Math.floor(t / (1000 / 30)),

                // template + branding
                templateId: this.state.templateId || 'trivia',
                currentTemplate: this.state.templateId || this.state.currentTemplate || 'trivia',
                brandName: this.state.brandName || '',
                quizName: this.state.quizName || '',
                brandColor: this.state.brandColor || '#FFD700',
                ctaText: this.state.ctaText || '',
                computedCtaText: this.state.computedCtaText || '',
                ctaPreset: this.state.ctaStyle || 'subscribe',
                useRankSystemCTA: !!this.state.useRankCta,
                websiteUrl: this.state.websiteUrl || '',
                logoPosition: (['corner', 'outro', 'all'].includes(String(this.state.logoPosition || 'all').toLowerCase())) ? String(this.state.logoPosition || 'all').toLowerCase() : 'all',
                brandLogoImage: this.state.brandLogoImage || null,
                logoImage: this.state.brandLogoImage || null, // back-compat
                brandLogoUrl: String(this.state.brandLogoUrl || '').trim(),
                brandLogoDataUrl: String(this.state.brandLogoDataUrl || '').trim(),
                fontOverride: this.state.fontOverride || null, // @FIX 2026-02-07: Pass font override to renderer

                // @FIX: Pass Critical Content & Style Data
                hookText: this.state.hookText || '',
                subHookText: this.state.subHookText || '',
                templateColors: this.state.templateColors,
                templateFonts: this.state.templateFonts,
                templateEffects: this.state.templateEffects,
                textEffects: this.state.textEffects,

                // background (video frames drive bgImage)
                bgImage: this._getBgImageAt(t),

                // scene info expected by templates
                currentSceneId: scene ? scene.id : 'hook',
                activeScene: scene ? { type: scene.type, id: scene.id, content: (scene.content || {}) } : { type: 'hook', id: 'hook', content: {} },

                // @MODIFIED 2026-02-26: Add animation phase and FX events (Preview/Export Parity)
                animationPhase: animationPhase,
                fxEvents: Array.isArray(plan.fxEvents) ? plan.fxEvents : [],
                // @MODIFIED 2026-02-26: Use plan's frameMs or fallback
                prevElapsed: Math.max(0, t - (plan.frameMs || (1000 / 30))),  // Previous frame time for FX triggers

            // @FIX 2026-07-01: Prefer scene.timing (has frame-aligned questionTotal + _revealStartRel
            // from render-plan.js) over this.state.timing (also snapped after Fix 1b, but lacks _revealStartRel).
            // This ensures template-manager timer bar and pill use the same ms as SFX cues.
                timing: (scene && scene.timing) ? scene.timing : (this.state.timing || {}),

                // @FIX: Pass coverConfig so drawCover() uses the same settings as export
                coverConfig: this.state.coverConfig || null,
            };

            // Render
            try {
                this._renderer.render(this._ctx, renderState, { bgImage: renderState.bgImage, logoImage: renderState.logoImage });
            } catch (e) {
                if (Logger) Logger.warn('PREVIEW_RENDER_FAIL', { error: e.message });
            }

            // Timeline UI + deterministic audio transport
            this.updateTimelineUI(t);
            if (this.audio && typeof this.audio.tick === 'function') this.audio.tick(t, !!isManual);
        }


        /**
         * Preview controls
         */
	// @NEW 2026-04-24: Reinitialize preview after format switch
	_reinitPreview() {
		const wasPlaying = this._player && this._player.isPlaying;
		if (wasPlaying) {
			try { this._player.pause(); } catch (_) { }
		}

		if (this._player && typeof this._player.destroy === 'function') {
			try { this._player.destroy(); } catch (_) { }
		}

		if (this._canvas) {
			const res = this.getResolution();
			this._canvas.width = res.width;
			this._canvas.height = res.height;
		}

		this._timeline = new window.MCQVS_TimelineEngine();
		this._player = new window.MCQVS_PreviewPlayer({ controller: this, timelineEngine: this._timeline });

		this._invalidateRenderPlan();

		if (wasPlaying) {
			this.playPreview();
		} else if (this._canvas && this._ctx) {
			this._renderAt(0, true);
		}
	}

	async playPreview() {
            if (!this._player || !this._timeline) return;

            // Ensure plan exists + configured
            const plan = this._ensureRenderPlan();
            if (!plan) return;
            // @FIX 1.4.9.58 (TTS PREVIEW LAG): when voiceover is enabled with a server
            // TTS provider, generate ALL segments BEFORE starting playback so the
            // narration follows the timeline exactly (no lag, no overlap). The play
            // button shows a busy tip until ready.
            const btn = document.getElementById('timelinePlayBtn');
            const voCfg = this.state && this.state.voiceover ? this.state.voiceover : null;
            const needPrewarm = !!(voCfg && voCfg.enabled && String(voCfg.provider || 'edge').toLowerCase() !== 'webspeech');
            if (needPrewarm && this.audio && typeof this.audio.prewarmAllVoiceover === 'function') {
                if (this._ttsPrewarming) return; // already prewarming — ignore double-clicks
                this._ttsPrewarming = true;
                const oldHtml = btn ? btn.innerHTML : '';
                const oldTitle = btn ? btn.title : '';
                if (btn) { btn.disabled = true; btn.innerHTML = '⏳ TTS…'; btn.title = 'Generating voiceover — will auto-play when ready'; }
                try {
                    const n = await this.audio.prewarmAllVoiceover();
                    if (Logger) Logger.info('PREVIEW_TTS_PREWARMED', { segments: n });
                } catch (_) { /* play anyway; per-segment generation still works */ }
                this._ttsPrewarming = false;
                if (btn) { btn.disabled = false; btn.innerHTML = oldHtml; btn.title = oldTitle; }
            }

            // Start from current scrub value (NLE behavior)
            const scrub = document.getElementById('timelineScrubber');
            let t = scrub ? (Number(scrub.value) || 0) : (Number(this.preview.currentTime) || 0);

            // If Hook is configured as "voice-only" (hidden), start at the first question.
            if (t === 0 && this.state && this.state.hookVisible === false) {
                try {
                    const plan0 = this._ensureRenderPlan();
                    const firstQ0 = plan0 && Array.isArray(plan0.scenes) ? plan0.scenes.find(sc => sc && sc.type === 'question') : null;
                    if (firstQ0) t = Number(firstQ0.startMs) || 0;
                    if (scrub) scrub.value = String(Math.max(0, Math.floor(t)));
                } catch (_) { }
            }

            this._timeline.seek(t);
            this.preview.currentTime = t;

            if (this.audio && typeof this.audio.playFrom === 'function') this.audio.playFrom(t);

            this.preview.isPlaying = true;
            this._player.play();

            if (btn) btn.classList.add('playing');

            if (Logger) Logger.info('PREVIEW_PLAY', { t });
        }


        pausePreview() {
            if (!this._player || !this._timeline) return;

            const t = Number(this.preview.currentTime) || 0;

            this.preview.isPlaying = false;
            this._player.stop(); // stops RAF but preserves timeline time

            if (this.audio && typeof this.audio.pauseAt === 'function') this.audio.pauseAt(t);

            const btn = document.getElementById('timelinePlayBtn');
            if (btn) btn.classList.remove('playing');

            if (Logger) Logger.info('PREVIEW_PAUSE', { t });
        }


        stopPreview() {
            if (!this._player || !this._timeline) return;

            this.preview.isPlaying = false;
            this._player.stop();
            this._timeline.reset(0);

            if (this.audio && typeof this.audio.stopAll === 'function') this.audio.stopAll();

            this.preview.currentTime = 0;
            this._renderAt(0, true);

            const btn = document.getElementById('timelinePlayBtn');
            if (btn) btn.classList.remove('playing');

            const scrub = document.getElementById('timelineScrubber');
            if (scrub) scrub.value = 0;

            this.updateTimelineUI(0);

            if (Logger) Logger.info('PREVIEW_STOP');
        }

        // ============================================================
        // Timeline UI (Preview sync)
        // ============================================================

        bindTimelineUI() {
            if (this._timelineBound) return;
            this._timelineBound = true;

            const scrub = document.getElementById('timelineScrubber');
            const playBtn = document.getElementById('timelinePlayBtn');

            if (playBtn) {
                playBtn.addEventListener('click', () => {
                    if (!this.preview) return;

                    if (this.preview.isPlaying) {
                        this.pausePreview();
                        return;
                    }

                    // Resume from scrubber time
                    const t = scrub ? (Number(scrub.value) || 0) : (this.preview.currentTime || 0);
                    this.preview.currentTime = t;

                    if (this.audio && typeof this.audio.playFrom === 'function') this.audio.playFrom(t);
                    else this.audio.start();

                    this.preview.resume();
                    playBtn.classList.add('playing');
                });
            }

            if (scrub) {
                let wasPlaying = false;

                scrub.addEventListener('pointerdown', () => {
                    wasPlaying = !!(this.preview && this.preview.isPlaying);
                    if (wasPlaying) this.pausePreview();
                });

                scrub.addEventListener('input', () => {
                    const t = Number(scrub.value) || 0;

                    if (this._player) {
                        this.preview.currentTime = t;
                        this._player.scrubTo(t);
                    } else if (this.preview && typeof this.preview.renderFrame === 'function') {
                        this.preview.renderFrame(t);
                    }


                    // Deterministic scrub: seek without triggering SFX
                    if (this.audio && typeof this.audio.tick === 'function') this.audio.tick(t, true);
                    else if (this.audio && typeof this.audio.seekTo === 'function') this.audio.seekTo(t);

                    this.updateTimelineUI(t);
                });

                scrub.addEventListener('change', () => {
                    // if user was playing before scrub, resume from new time
                    if (!wasPlaying || !this.preview) return;

                    const t = Number(scrub.value) || 0;
                    if (this.audio && typeof this.audio.playFrom === 'function') this.audio.playFrom(t);
                    else if (this.audio && typeof this.audio.start === 'function') this.audio.start();

                    this.preview.resume();
                    const btn = document.getElementById('timelinePlayBtn');
                    if (btn) btn.classList.add('playing');
                });
            }
        }

        startTimelineLoop() {
            if (this._timelineRaf) cancelAnimationFrame(this._timelineRaf);

            const tick = () => {
                if (!this.preview || !this.preview.isPlaying) {
                    this._timelineRaf = 0;
                    return;
                }

                const t = Number(this.preview.currentTime) || 0;
                this.updateTimelineUI(t);
                if (this.audio && typeof this.audio.tick === 'function') this.audio.tick(t, false);

                this._timelineRaf = requestAnimationFrame(tick);
            };

            this._timelineRaf = requestAnimationFrame(tick);
        }

        stopTimelineLoop(reset) {
            if (this._timelineRaf) {
                cancelAnimationFrame(this._timelineRaf);
                this._timelineRaf = 0;
            }
            if (reset) this.updateTimelineUI(0);
        }

        syncTimelineMetrics() {
            const scrub = document.getElementById('timelineScrubber');
            const totalEl = document.getElementById('timelineTotalDuration');

            const total = Number(this.state.totalDurationMs) || (
                (this.state.timing.hookIntro || 0) +
                (((Array.isArray(this.state.selectedQuestions) && this.state.selectedQuestions.length) ? this.state.selectedQuestions.length : (this.state.questions || []).length) * (this.state.timing.questionTotal || 0)) +
                (this.state.timing.outroDuration || 0)
            );

            if (scrub) {
                scrub.max = String(Math.max(0, Math.floor(total)));
                if (Number(scrub.value) > Number(scrub.max)) scrub.value = scrub.max;
            }
            if (totalEl) totalEl.textContent = this.formatTime(total);
        }

        updateTimelineUI(ms) {
            const scrub = document.getElementById('timelineScrubber');
            const curEl = document.getElementById('timelineCurrentTime');
            const totalEl = document.getElementById('timelineTotalDuration');

            const total = Number(this.state.totalDurationMs) || 0;
            const t = Math.max(0, Math.min(Number(ms) || 0, total || (Number(scrub && scrub.max) || 0)));

            if (scrub) scrub.value = String(Math.floor(t));
            if (curEl) curEl.textContent = this.formatTime(t);
            if (totalEl && total) totalEl.textContent = this.formatTime(total);
        }

        formatTime(ms) {
            const s = Math.max(0, Math.floor((Number(ms) || 0) / 1000));
            const mm = String(Math.floor(s / 60)).padStart(2, '0');
            const ss = String(s % 60).padStart(2, '0');
            return `${mm}:${ss}`;
        }

        // ============================================================
        // Diagnostics UI (buttons)
        // ============================================================

        bindDiagnosticsUI() {
            if (this._diagBound) return;
            this._diagBound = true;

            const out = document.getElementById('mcqvsDiagOutput');
            const refreshBtn = document.getElementById('mcqvsDiagRefreshBtn');
            const copyJsonBtn = document.getElementById('mcqvsDiagCopyJsonBtn');
            const copyLogsBtn = document.getElementById('mcqvsDiagCopyLogsBtn');
            const downloadBtn = document.getElementById('mcqvsDiagDownloadJsonBtn');
            const downloadLogsBtn = document.getElementById('mcqvsDiagDownloadLogsBtn');
            const clearLogsBtn = document.getElementById('mcqvsDiagClearLogsBtn');

            const collect = () => {
                const diag = (window.MCQVS_Diagnostics && typeof window.MCQVS_Diagnostics.collect === 'function')
                    ? window.MCQVS_Diagnostics.collect(this)
                    : { error: 'MCQVS_Diagnostics missing' };

                const txt = JSON.stringify(diag, null, 2);
                if (out) out.value = txt;
                return diag;
            };

            if (refreshBtn) refreshBtn.addEventListener('click', (e) => {
                e.preventDefault();
                collect();
                if (this.ui) this.ui.showNotification('Diagnostics refreshed', 'success');
            });

            if (copyJsonBtn) copyJsonBtn.addEventListener('click', async (e) => {
                e.preventDefault();
                if (!out) return;
                await this.copyToClipboard(out.value || '');
                if (this.ui) this.ui.showNotification('Diagnostics JSON copied', 'success');
            });

            async function fetchServerLogs() {
                try {
                    const response = await fetch(window.mcqvsSettings && window.mcqvsSettings.ajaxUrl, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: 'action=mcqvs_get_diagnostics_logs&nonce=' + (window.mcqvsSettings && window.mcqvsSettings.nonce)
                    });
                    const result = await response.json();
                    return result.success ? result.data.logs : [];
                } catch (e) {
                    return [];
                }
            }

            if (copyLogsBtn) copyLogsBtn.addEventListener('click', async (e) => {
                e.preventDefault();
                const diag = collect();
                const tail = (diag && diag.logs && Array.isArray(diag.logs.tail)) ? diag.logs.tail : [];

                let combined = tail;
                const legacy = window.MCQVS_Logger;
                if ((!combined || !combined.length) && legacy && typeof legacy.getLogs === 'function') {
                    try {
                        const legacyLogs = legacy.getLogs() || [];
                        if (legacyLogs.length) combined = legacyLogs.slice(-80);
                    } catch (_) { }
                }

                const serverLogs = await fetchServerLogs();
                if (Array.isArray(serverLogs) && serverLogs.length) {
                    combined = combined.length ? combined.concat(serverLogs) : serverLogs;
                }

                if (!combined.length) {
                    if (this.ui) this.ui.showNotification('No logs to copy yet — open a preview or run an export to populate the buffer.', 'info');
                    return;
                }

                const header = [
                    `MCQVS Diagnostic Logs — ${new Date().toISOString()}`,
                    `Source: ${diag && diag.collectedAt ? 'Diagnostics' : 'fallback'} — ${combined.length} entries`,
                    '------------------------------------------------------------'
                ].join('\n');

                const body = combined.map((e) => {
                    const ts = e && (e.timestamp || e.ts) ? new Date(e.timestamp || e.ts).toISOString() : 'n/a';
                    const level = String(e && (e.level || 'INFO')).toUpperCase();
                    const event = String(e && (e.event || e.msg || ''));
                    const ctx = (e && e.data && Object.keys(e.data).length) ? ' ' + JSON.stringify(e.data) : (e && e.context && Object.keys(e.context).length) ? ' ' + JSON.stringify(e.context) : '';
                    return `${ts}  [${level}]  ${event}${ctx}`;
                }).join('\n');

                await this.copyToClipboard(`${header}\n${body}\n`);
                if (this.ui) this.ui.showNotification(`${combined.length} log entries copied`, 'success');
            });

            const _collectLogsList = async () => {
                const diag = collect();
                const tail = (diag && diag.logs && Array.isArray(diag.logs.tail)) ? diag.logs.tail : [];
                let combined = tail;
                const legacy = window.MCQVS_Logger;
                if ((!combined || !combined.length) && legacy && typeof legacy.getLogs === 'function') {
                    try {
                        const legacyLogs = legacy.getLogs() || [];
                        if (legacyLogs.length) combined = legacyLogs.slice(-80);
                    } catch (_) { }
                }

                const serverLogs = await fetchServerLogs();
                if (Array.isArray(serverLogs) && serverLogs.length) {
                    combined = combined.length ? combined.concat(serverLogs) : serverLogs;
                }
                return { diag, combined };
            };

            if (downloadLogsBtn) downloadLogsBtn.addEventListener('click', async (e) => {
                e.preventDefault();
                const { diag, combined } = await _collectLogsList();
                if (!combined.length) {
                    if (this.ui) this.ui.showNotification('No logs to download yet — open a preview or run an export to fill the buffer.', 'info');
                    return;
                }
                const envelope = {
                    source: 'mcqvs-diag-logs',
                    collectedAt: new Date().toISOString(),
                    runtime: {
                        url: diag && diag.renderPlan ? 'preview/diagnostics populated' : 'empty',
                        logsCount: combined.length
                    },
                    logs: combined
                };
                const blob = new Blob([JSON.stringify(envelope, null, 2)], { type: 'application/json;charset=utf-8' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `mcqvs-logs-${Date.now()}.json`;
                document.body.appendChild(a);
                a.click();
                a.remove();
                setTimeout(() => URL.revokeObjectURL(url), 500);
                if (this.ui) this.ui.showNotification(`Logs downloaded (${combined.length} entries)`, 'success');
            });

            if (downloadBtn) downloadBtn.addEventListener('click', (e) => {
                e.preventDefault();
                if (!out) return;

                const blob = new Blob([out.value || ''], { type: 'application/json;charset=utf-8' });
                const url = URL.createObjectURL(blob);

                const a = document.createElement('a');
                a.href = url;
                a.download = `mcqvs-diagnostics-${Date.now()}.json`;
                document.body.appendChild(a);
                a.click();
                a.remove();

                setTimeout(() => URL.revokeObjectURL(url), 500);
            });

            if (clearLogsBtn) clearLogsBtn.addEventListener('click', (e) => {
                e.preventDefault();

                // best-effort clear in logger (if exposed)
                const L = window.MCQVSLogger;
                if (L && typeof L.clear === 'function') L.clear();
                if (L && typeof L.clearLogs === 'function') L.clearLogs();

                if (out) out.value = '';

                // Actually truncate the server-side vs_logs table.
                const cfg = (window.MCQVSConfig || window.MCQVS_Config || {});
                const ajaxUrl = cfg.ajaxUrl || (window.mcqvsSettings && window.mcqvsSettings.ajaxUrl);
                const nonce = cfg.nonce || (window.mcqvsSettings && window.mcqvsSettings.nonce);
                if (!ajaxUrl || !nonce) {
                    if (this.ui) this.ui.showNotification('Logs cleared (local only — server nonce missing)', 'info');
                    return;
                }
                fetch(ajaxUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: 'action=mcqvs_clear_logs&nonce=' + encodeURIComponent(nonce)
                })
                    .then((r) => r.json())
                    .then((res) => {
                        if (this.ui) this.ui.showNotification(res && res.success ? 'Logs cleared' : 'Logs clear failed', res && res.success ? 'success' : 'error');
                    })
                    .catch(() => {
                        if (this.ui) this.ui.showNotification('Logs cleared (local only — server unreachable)', 'info');
                    });
            });
        }

        async copyToClipboard(text) {
            try {
                if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
                    await navigator.clipboard.writeText(text);
                    return true;
                }
            } catch (_) { /* fall through */ }

            // Fallback
            try {
                const ta = document.createElement('textarea');
                ta.value = text;
                ta.style.position = 'fixed';
                ta.style.left = '-9999px';
                document.body.appendChild(ta);
                ta.select();
                document.execCommand('copy');
                ta.remove();
                return true;
            } catch (_) {
                return false;
            }
        }

        /**
         * Export
         */
        async startExport() {
            if (this.state.questions.length === 0) {
                this.ui.showNotification('Add questions first', 'error');
                return;
            }

            try {
                // Show export modal
                this.ui.renderExportModal();
                this.ui.showModal('exportModal');

                // Get selected questions
                // @MODIFIED 2026-02-03: Export selection comes from sidebar selector
                const selected = (Array.isArray(this.state.selectedQuestions) && this.state.selectedQuestions.length)
                    ? [...this.state.selectedQuestions]
                    : this.state.questions.map((_, i) => i);

                if (selected.length === 0) {
                    throw new Error('Select at least one question');
                }

                // Create export manager
                this.export = new window.MCQVS_ExportManager(this.state, this.config);

                // Setup progress listener
                this._exportToast = null;

                // @MODIFIED 2026-02-08: Show progress toast IMMEDIATELY (0%) for instant feedback
                if (window.MCQVS_ToastManager && window.MCQVS_ToastManager.progress) {
                    this._exportToast = window.MCQVS_ToastManager.progress('Rendering Video', 0);
                }

                document.addEventListener('mcqvs:export:progress', (e) => {
                    const pct = e.detail.percent;
                    this.ui.updateExportProgress(pct, 'Exporting...');

                    // @MODIFIED 2026-02-08: Use correct API (updateProgress) on the wrapper object
                    if (this._exportToast && typeof this._exportToast.updateProgress === 'function') {
                        this._exportToast.updateProgress(pct, `Rendering... ${pct}%`);

                        // Auto-dismiss at 100% (handled by success notification usually, but good to clean up)
                        if (pct >= 100) {
                            setTimeout(() => {
                                if (this._exportToast && typeof this._exportToast.dismiss === 'function') {
                                    this._exportToast.dismiss();
                                    this._exportToast = null;
                                }
                            }, 500);
                        }
                    }
                });

                // Start export
                await this.export.startExport(selected);

        this.ui.showNotification('Video exported successfully!', 'success');
        this.ui.hideModal('exportModal');

        // @NEW 2026-04: Update job/project video_url in database after successful export
        try {
            const jobId = this.state.activeJobId || null;
            const projectId = this.state.activeProjectId || null;
            const saveMode = this.state.saveMode || 'local';

            // For local mode, just update status. For r2/r2_buffer, handleJobComplete already sent the blob.
            if ((jobId || projectId) && saveMode === 'local') {
                await this.ajaxPost('mcqvs_update_video_url', {
                    job_id: jobId,
                    project_id: projectId,
                    save_mode: saveMode
                });
                if (Logger) Logger.info('VIDEO_URL_UPDATED', { job_id: jobId, project_id: projectId, save_mode: saveMode });
            }
        } catch (e) {
            console.warn('[MCQVS] Failed to update video_url:', e);
        }

                if (Logger) {
                    Logger.info('EXPORT_SUCCESS', { questionCount: selected.length });
                }

            } catch (error) {
                if (Logger) {
                    Logger.error('EXPORT_FAIL', { error: error.message });
                }
                this.ui.showNotification(`Export failed: ${error.message}`, 'error');
            }
        }

        cancelExport() {
            if (this.export) {
                this.export.cancel();
            }

            this.ui.hideModal('exportModal');

            if (Logger) {
                Logger.info('EXPORT_CANCEL');
            }
        }

        // @NEW 2026-02-03: WP AJAX helper (admin-ajax.php)
        // @UPDATED 2026-02-06: Robust AJAX helper (matches studio.ui.js parity)
        async ajaxPost(action, payload = {}) {
            const url = this.config.ajaxurl || this.config.ajaxUrl || window.ajaxurl || '';
            if (!url) throw new Error('Missing AJAX URL');

            const body = new URLSearchParams();
            body.set('action', action);
            body.set('nonce', this.config.nonce || '');

            Object.entries(payload || {}).forEach(([k, v]) => {
                if (v === undefined || v === null) return;
                body.set(k, String(v));
            });

            const res = await fetch(url, {
                method: 'POST',
                credentials: 'same-origin',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                body: body.toString()
            });

            const text = await res.text();
            try {
                const json = JSON.parse(text);
                return json;
            } catch (e) {
                // Log the raw HTML response for debugging
                console.error('[MCQVS] Invalid JSON Response:', text.substring(0, 500));
                throw new Error('Invalid server response (check console)');
            }
        }

        // ============================================================
        // Server-backed Branding Persistence (uses existing WP AJAX)
        // Actions: mcqvs_get_branding, mcqvs_save_branding
        // ============================================================
        async loadBrandingFromServer() {
            try {
                const resp = await this.ajaxPost('mcqvs_get_branding', {});
                if (!resp || !resp.success || !resp.data) return;

                const b = resp.data || {};
                const logo = String(b.logo_url || '').trim();
                const posRaw = String(b.logo_pos || '').toLowerCase().trim();

                // only apply server branding if local state doesn't already have it
                if (logo && !String(this.state.brandLogoUrl || '').trim() && !String(this.state.brandLogoDataUrl || '').trim()) {
                    this.state.brandLogoUrl = logo;
                    this.restoreBrandLogoFromDataUrl(logo);
                }

                // normalize positions into our contract: corner|outro|all
                if (posRaw) {
                    const pos =
                        (posRaw === 'corner' || posRaw === 'outro' || posRaw === 'all') ? posRaw :
                            (posRaw === 'top-right' || posRaw === 'topright' || posRaw === 'top_right') ? 'corner' :
                                'all';
                    this.state.logoPosition = pos;
                }

                // optional fields
                if (b.brand_name && !String(this.state.brandName || '').trim()) this.state.brandName = String(b.brand_name);
                if (b.quiz_name && !String(this.state.quizName || '').trim()) this.state.quizName = String(b.quiz_name);
                if (b.cta_text && !String(this.state.ctaText || '').trim()) this.state.ctaText = String(b.cta_text);

            } catch (e) {
                if (Logger) Logger.warn('BRANDING_SERVER_LOAD_FAIL', { error: e.message });
            }
        }

        async saveBrandingToServer() {
            try {
                // @MODIFIED 2026-08-10: logo_url and logo_pos are now managed exclusively
                // in Settings → Assets. The Studio Editor must NOT send these fields here
                // because the server handler does a full replacement — sending an empty
                // logo_url would wipe the logo uploaded via the Settings Assets tab.
                const resp = await this.ajaxPost('mcqvs_save_branding', {
                    cta_text: String(this.state.ctaText || ''),
                    brand_name: String(this.state.brandName || 'TheQuizWire'),
                    quiz_name: String(this.state.quizName || ''),
                });

                if (!resp || !resp.success) {
                    throw new Error(resp && resp.data ? (resp.data.message || 'Branding save failed') : 'Branding save failed');
                }
            } catch (e) {
                if (Logger) Logger.warn('BRANDING_SERVER_SAVE_FAIL', { error: e.message });
            }
        }

        // @NEW 2026-02-03: Load Topic/Exam/Bank list into #sourceItem
        async loadSourceItems(type) {
            const safeType = String(type || 'topic');

            const resp = await this.ajaxPost('mcqvs_get_studio_sources', { type: safeType });
            if (!resp || !resp.success) {
                throw new Error(resp && resp.data ? (resp.data.message || 'Failed to load sources') : 'Failed to load sources');
            }

            // resp.data is expected to be array of data like legacy flow
            this.ui.renderSourceItems(resp.data);
            if (Logger) Logger.info('SOURCES_LOADED', { type: safeType, count: Array.isArray(resp.data) ? resp.data.length : 0 });
        }

        // @NEW 2026-02-11: Pagination Handlers
        async handleNextPage() {
            const nextIdx = this.state.currentPage * this.state.pageSize;

            // If we don't have enough questions in memory for the next page, fetch them
            if (this.state.questions.length <= nextIdx) {
                const type = (this.ui && this.ui.getSourceType) ? this.ui.getSourceType() : 'topic';
                const id = (this.ui && this.ui.getSourceItemId) ? this.ui.getSourceItemId() : '';

                if (!id) return;

                try {
                    const resp = await this.ajaxPost('mcqvs_get_studio_data', {
                        type,
                        id,
                        limit: this.state.pageSize,
                        offset: nextIdx
                    });

                    if (resp && resp.success && Array.isArray(resp.data.questions)) {
                        const newQs = resp.data.questions.map(q => this.normalizeQuestion(q));
                        if (newQs.length > 0) {
                            this.state.questions = [...this.state.questions, ...newQs];
                            this.state.currentPage++;
                        } else {
                            this.ui.showNotification('No more questions found', 'info');
                        }
                    }
                } catch (e) {
                    this.ui.showNotification('Failed to fetch next page', 'error');
                }
            } else {
                this.state.currentPage++;
            }

            this.ui.renderQuestionSelectorList();
        }

        handlePrevPage() {
            if (this.state.currentPage > 1) {
                this.state.currentPage--;
                this.ui.renderQuestionSelectorList();
            }
        }
        // @NEW 2026-02-03: Load questions for selected item (normalized)
        // @FIX 2026-02-25: Never fail silently (UI awaits + controller catches + always repaints)
        async loadStudioData(type, id) {
            const safeType = String(type || 'topic');
            const safeId = String(id || '');

            if (!safeId) {
                if (this.ui) this.ui.showNotification('Please select an item to load', 'warning');
                return;
            }

            // Reset pagination on fresh load
            this.state.currentPage = 1;

            try {
                if (this.ui) this.ui.showNotification('Loading questions...', 'info');

                const resp = await this.ajaxPost('mcqvs_get_studio_data', {
                    type: safeType,
                    id: safeId,
                    limit: this.state.pageSize,
                    offset: 0
                });

                if (!resp || !resp.success) {
                    throw new Error(resp && resp.data ? (resp.data.message || 'Failed to load questions') : 'Failed to load questions');
                }

                const rawQuestions = (resp.data && Array.isArray(resp.data.questions)) ? resp.data.questions : [];
                const questions = rawQuestions.map(q => this.normalizeQuestion(q));

                this.state.questions = questions;
                this.state.selectedQuestions = questions.map((_, i) => i);

                if (resp.data && resp.data.title && typeof resp.data.title === 'string') {
                    this.state.quizName = resp.data.title;
                    const quizNameEl = document.getElementById('quizName');
                    if (quizNameEl) quizNameEl.value = this.state.quizName;
                }

                // Minimal scenes (future parity)
                this.state.scenes = questions.map((q, i) => ({
                    id: `q${i}`,
                    type: 'question',
                    content: q,
                    timing: { ...this.state.timing }
                }));

                if (this.ui) this.ui.showNotification(`Loaded ${questions.length} questions`, 'success');
                if (Logger) Logger.info('DATA_LOADED', { type: safeType, id: safeId, count: questions.length });

            } catch (error) {
                // Force a visible on-canvas message even if Hook text was hidden
                try {
                    this.state.hookVisible = true;
                    this.state.hookText = `Load failed: ${error && error.message ? error.message : 'Unknown error'}`;
                } catch (_) { }

                if (Logger) Logger.error('DATA_LOAD_FAIL', { type: safeType, id: safeId, error: error.message });
                if (this.ui) this.ui.showNotification(`Load failed: ${error.message}`, 'error');

            } finally {
                // Always refresh UI + preview regardless of outcome
                try { this.ui && this.ui.renderQuestionsList && this.ui.renderQuestionsList(); } catch (_) { }
                try { this.ui && this.ui.renderQuestionSelectorList && this.ui.renderQuestionSelectorList(); } catch (_) { }

                this.handleStateChange();

                // Auto-seek to first question if Hook is hidden
                try {
                    const plan = this._ensureRenderPlan();
                    const firstQ = plan && Array.isArray(plan.scenes) ? plan.scenes.find(sc => sc && sc.type === 'question') : null;
                    if (firstQ && this.state && this.state.hookVisible === false) {
                        const t0 = Number(firstQ.startMs) || 0;
                        const scrub = document.getElementById('timelineScrubber');
                        if (scrub) scrub.value = String(Math.max(0, Math.floor(t0)));
                        this._renderAt(t0, true);
                        this.updateTimelineUI(t0);
                    }
                } catch (_) { }
            }
        }

        // @NEW 2026-02-03: Normalize question shape (matches legacy normalizeQuestion intent) (matches legacy normalizeQuestion intent)
        normalizeQuestion(q) {
            if (!q || typeof q !== 'object') {
                return { question: 'Invalid question', options: ['A', 'B', 'C', 'D'], correct: 0 };
            }

            const out = { ...q };

            // question text
            out.question = (out.question ?? out.text ?? '').toString().trim() || 'Untitled question';

            // options: accept array/object/legacy fields
            const fromArray = (arr) => ([
                (arr && arr[0] != null) ? String(arr[0]) : 'Option A',
                (arr && arr[1] != null) ? String(arr[1]) : 'Option B',
                (arr && arr[2] != null) ? String(arr[2]) : 'Option C',
                (arr && arr[3] != null) ? String(arr[3]) : 'Option D'
            ]);

            if (Array.isArray(out.options)) out.options = fromArray(out.options);
            else if (Array.isArray(out.answers)) out.options = fromArray(out.answers);
            else if (out.options && typeof out.options === 'object') {
                // object -> array in stable A-D order
                out.options = [
                    String(out.options.A ?? out.optionA ?? 'Option A'),
                    String(out.options.B ?? out.optionB ?? 'Option B'),
                    String(out.options.C ?? out.optionC ?? 'Option C'),
                    String(out.options.D ?? out.optionD ?? 'Option D')
                ];
            } else {
                out.options = ['Option A', 'Option B', 'Option C', 'Option D'];
            }

            // correct: clamp 0..3, allow "A"/"B"/etc.
            let c = out.correct;
            if (typeof c === 'string') {
                const s = c.toLowerCase();
                if (s.includes('a')) c = 0;
                else if (s.includes('b')) c = 1;
                else if (s.includes('c')) c = 2;
                else if (s.includes('d')) c = 3;
                else c = parseInt(s, 10);
            }
            c = Number.isInteger(c) ? c : 0;
            if (c < 0 || c > 3) c = 0;
            out.correct = c;

            return out;
        }

        /**
         * State persistence
         */
        saveState() {
            try {
                const serialized = JSON.stringify({
                    stateVersion: 3,
                    questions: [],
                    questionCount: Array.isArray(this.state.questions) ? this.state.questions.length : 0,

                    template: this.state.templateId || this.state.currentTemplate,
                    timing: this.state.timing,
                    audio: {
                        enabled: this.state.audioEnabled,
                        sfx: this.state.sfxEnabled,
                        music: this.state.musicEnabled,
                        // @MODIFIED 2026-02-06: Persist music URL and volume
                        bgMusicUrl: this.state.bgMusicUrl || '',
                        musicVolume: this.state.musicVolume || 0.3
                    },
                    voiceover: this.state.voiceover || {},
                    branding: {
                        brandName: this.state.brandName,
                        quizName: this.state.quizName,
                        hookText: this.state.hookText,
                        hookVisible: (this.state.hookVisible !== false),
                        ctaText: this.state.ctaText,
                        websiteUrl: this.state.websiteUrl,
                        brandColor: this.state.brandColor || null,
                        logoPosition: this.state.logoPosition || 'all',

                        // MUST persist this (Image is not serializable)
                        // NOTE: Do NOT persist huge base64 blobs in localStorage (quota is ~5MB). Keep URL as the durable ref.
                        // @MODIFIED 2026-02-26: Add quota safety check
                        brandLogoDataUrl: (this.state.brandLogoDataUrl && String(this.state.brandLogoDataUrl).length <= 250000) ? this.state.brandLogoDataUrl : '',
brandLogoUrl: this.state.brandLogoUrl || ''
},

seo: {
keywords: this.state.seoKeywords || '',
meta: this.state.seoMeta || { title: '', description: '', tags: [] }
},
format: {
videoFormat: this.state.videoFormat || 'shorts',
width: this.state.width || 1080,
height: this.state.height || 1920
}
});


                localStorage.setItem('mcqvs_studio_state', serialized);

                // Persist branding separately so it survives any future storage quota issues.
                try {
                    localStorage.setItem('mcqvs_studio_branding', JSON.stringify({
                        brandName: this.state.brandName || '',
                        quizName: this.state.quizName || '',
                        hookText: this.state.hookText || '',
                        hookVisible: (this.state.hookVisible !== false),
                        ctaText: this.state.ctaText || '',
                        websiteUrl: this.state.websiteUrl || '',
                        brandColor: this.state.brandColor || null,
                        logoPosition: this.state.logoPosition || 'all',
                        brandLogoUrl: this.state.brandLogoUrl || '',
                        brandLogoDataUrl: (this.state.brandLogoDataUrl && String(this.state.brandLogoDataUrl).length <= 250000) ? this.state.brandLogoDataUrl : ''
                    }));
                } catch (_) { }


                if (Logger) {
                    Logger.debug('STATE_SAVE');
                }

            } catch (error) {
                if (Logger) {
                    Logger.warn('STATE_SAVE_FAIL', { error: error.message });
                }
            }
        }

        syncLogoCardUIFromState() {
            const logoPreview = document.getElementById('logoPreview');
            const removeLogoBtn = document.getElementById('removeLogoBtn');
            const logoUrlInput = document.getElementById('brandLogoUrl');
            const logoPos = document.getElementById('logoPosition');

            const src = (this.state.brandLogoUrl || this.state.brandLogoDataUrl || '').trim();

            if (logoPreview) {
                if (src) {
                    logoPreview.src = src;
                    logoPreview.style.display = 'block';
                } else {
                    logoPreview.src = '';
                    logoPreview.style.display = 'none';
                }
            }

            if (logoUrlInput) {
                logoUrlInput.value = (this.state.brandLogoUrl || '').trim();
            }

            if (removeLogoBtn) {
                removeLogoBtn.style.display = src ? 'inline-block' : 'none';
            }

            // Normalize contract: corner|outro|all
            const lpRaw = String(this.state.logoPosition || 'all').toLowerCase().trim();
            const lp = (lpRaw === 'corner' || lpRaw === 'outro') ? lpRaw : 'all';
            this.state.logoPosition = lp;
            if (logoPos) logoPos.value = lp;

            // If UI has a URL but preview renderer needs an Image(), bootstrap it.
            if (src && !this.state.brandLogoImage) {
                try { this.restoreBrandLogoFromDataUrl(src); } catch (_) { }
            }
        }

        restoreBrandLogoFromDataUrl(dataUrl) {
            const url = String(dataUrl || '').trim();
            if (!url) {
                this.state.brandLogoDataUrl = '';
                this.state.brandLogoUrl = '';
                this.state.brandLogoImage = null;
                return;
            }

            // @MODIFIED 2026-02-26: Differentiate between Data URL and standard URL
            if (url.startsWith('data:')) {
                this.state.brandLogoDataUrl = url;
            } else {
                this.state.brandLogoUrl = url;
                // DO NOT clear brandLogoDataUrl here; we want to keep the cache if it exists
                // but if we are restoring from a URL, we want to try to use it to bootstrap the Image()
            }

            const img = new Image();
            // @MODIFIED 2026-02-26: Set crossOrigin to prevent tainted canvas in renderer
            img.crossOrigin = 'anonymous';

            img.onload = () => {
                try {
                    this.state.brandLogoImage = img;
                    this.syncLogoCardUIFromState();

                    // Repaint preview immediately (does not restart playback)
                    if (this.preview && !this.preview.isPlaying) {
                        const scrub = document.getElementById('timelineScrubber');
                        const t = scrub ? (Number(scrub.value) || 0) : 0;

                        this.preview.renderFrame(t);
                        this.updateTimelineUI(t);

                        // apply toggles deterministically while paused
                        // @FIX 2026-02-16: Handle async promise rejection from audio.tick safely
                        if (this.audio && typeof this.audio.tick === 'function') {
                            this.audio.tick(t, true).catch(err => {
                                if (Logger) Logger.warn('AUDIO_TICK_FAIL_ON_LOGO', { error: err ? err.message : 'Unknown' });
                            });
                        }
                    }
                } catch (e) {
                    if (Logger) Logger.error('LOGO_RESTORE_FAIL', { error: e.message });
                }
            };
            img.onerror = () => {
                // If stored value is invalid/corrupt, do not keep retrying forever
                this.state.brandLogoImage = null;
                // @MODIFIED 2026-02-26: Do NOT wipe state on a single error (could be transient)
                // this.state.brandLogoDataUrl = '';
                // this.state.brandLogoUrl = '';
                // if (typeof this.saveState === 'function') this.saveState();
            };

            img.src = url;
        }

        loadState() {
            try {
                // Restore branding first (separate key avoids storage quota issues)
                try {
                    const b = localStorage.getItem('mcqvs_studio_branding');
                    if (b) {
                        const branding = JSON.parse(b);
                        if (branding && typeof branding === 'object') {
                            // shallow assign only known fields
                            this.state.brandName = (branding.brandName != null) ? branding.brandName : this.state.brandName;
                            this.state.quizName = (branding.quizName != null) ? branding.quizName : this.state.quizName;
                            this.state.hookText = (branding.hookText != null) ? branding.hookText : this.state.hookText;
                            this.state.hookVisible = (branding.hookVisible !== false);
                            this.state.ctaText = (branding.ctaText != null) ? branding.ctaText : this.state.ctaText;
                            this.state.websiteUrl = (branding.websiteUrl != null) ? branding.websiteUrl : this.state.websiteUrl;
                            this.state.brandColor = (branding.brandColor != null) ? branding.brandColor : this.state.brandColor;
                            this.state.logoPosition = (branding.logoPosition != null) ? branding.logoPosition : this.state.logoPosition;
                            this.state.brandLogoUrl = (branding.brandLogoUrl != null) ? branding.brandLogoUrl : this.state.brandLogoUrl;
                            this.state.brandLogoDataUrl = (branding.brandLogoDataUrl != null) ? branding.brandLogoDataUrl : this.state.brandLogoDataUrl;

                            const logoSrc = String(this.state.brandLogoDataUrl || this.state.brandLogoUrl || '').trim();
                            if (logoSrc) {
                                try { this.restoreBrandLogoFromDataUrl(logoSrc); } catch (_) { }
                            }
                        }
                    }
                } catch (_) { }

                const serialized = localStorage.getItem('mcqvs_studio_state');
                if (!serialized) {
                    // @FIX: Apply default template for new sessions
                    if (window.MCQVSVideoTemplates) {
                        window.MCQVSVideoTemplates.apply('trivia', this.state);
                    }
                    return;
                }

                const saved = JSON.parse(serialized);

                // Restore questions (disabled). Questions are loaded from Data Source to avoid localStorage quota issues.
                this.state.questions = Array.isArray(this.state.questions) ? this.state.questions : [];

                // Restore template
                if (saved.template) {
                    this.state.currentTemplate = saved.template;
                    this.state.templateId = saved.template;

                    // @FIX: Re-apply template configuration to populate colors/fonts
                    if (window.MCQVSVideoTemplates) {
                        window.MCQVSVideoTemplates.apply(saved.template, this.state);
                    } else {
                        console.error('MCQVS: Template Engine missing during loadState');
                    }
                }

                // Restore timing
                if (saved.timing) {
                    Object.assign(this.state.timing, saved.timing);
                }
                // Migration: older builds persisted 5s/7s think windows. Upgrade to 10s once (do NOT clobber custom values).
                const v = Number(saved.stateVersion || 0);
                if (v < 3) {
                    const t = this.state.timing || (this.state.timing = {});

                    const revealMs = Number.isFinite(Number(t.revealAnswer))
                        ? Number(t.revealAnswer)
                        : (t.questionPhases && Number.isFinite(Number(t.questionPhases.reveal)))
                            ? Number(t.questionPhases.reveal)
                            : 3000;

                    const thinkMs = Number.isFinite(Number(t.userThinkTime))
                        ? Number(t.userThinkTime)
                        : (Number.isFinite(Number(t.questionTotal)) ? (Number(t.questionTotal) - revealMs) : NaN);

                    // Only upgrade known-bad legacy values (your current bug is 5000).
                    if (thinkMs === 5000 || thinkMs === 7000) {
                        t.userThinkTime = 10000;
                    }

                    // Keep reveal sane
                    if (!Number.isFinite(Number(t.revealAnswer)) || Number(t.revealAnswer) <= 0) {
                        t.revealAnswer = 3000;
                    }
                }


                // Restore audio
                if (saved.audio) {
                    this.state.audioEnabled = saved.audio.enabled;
                    this.state.sfxEnabled = saved.audio.sfx;
                    this.state.musicEnabled = saved.audio.music;
                    // @MODIFIED 2026-02-06: Restore persistence
                    this.state.bgMusicUrl = saved.audio.bgMusicUrl || '';
                    this.state.musicVolume = Number.isFinite(Number(saved.audio.musicVolume)) ? Number(saved.audio.musicVolume) : 0.3;
                }

                // Restore voiceover (TTS)
                if (saved.voiceover && typeof saved.voiceover === 'object') {
                    this.state.voiceover = Object.assign({}, (this.state.voiceover || {}), saved.voiceover);
                }

                // Restore branding
                if (saved.branding) {
                    Object.assign(this.state, saved.branding);
                    // Restore persisted logo safely (priority: brandLogoDataUrl > brandLogoUrl > legacy)
                    // @MODIFIED 2026-02-26: Prioritize local cache (DataURL) for immediate display
                    const logoUrl =
                        (saved.branding && (saved.branding.brandLogoDataUrl || saved.branding.brandLogoUrl)) ? (saved.branding.brandLogoDataUrl || saved.branding.brandLogoUrl) :
                            (saved.branding && saved.branding.logoDataUrl) ? saved.branding.logoDataUrl :
                                (saved && (saved.brandLogoDataUrl || saved.brandLogoUrl)) ? (saved.brandLogoDataUrl || saved.brandLogoUrl) :
                                    '';

                    this.restoreBrandLogoFromDataUrl(logoUrl);



                }


                // Restore SEO
if (saved.seo && typeof saved.seo === 'object') {
this.state.seoKeywords = String(saved.seo.keywords || '').trim();
this.state.seoMeta = saved.seo.meta || { title: '', description: '', tags: [] };
}

if (saved.format && typeof saved.format === 'object') {
const fmt = saved.format.videoFormat;
if (fmt === 'youtube' || fmt === 'shorts') {
this.state.videoFormat = fmt;
this.state.width = Number(saved.format.width) || (fmt === 'youtube' ? 1920 : 1080);
this.state.height = Number(saved.format.height) || (fmt === 'youtube' ? 1080 : 1920);
if (this.config) {
this.config.canvasSize = { width: this.state.width, height: this.state.height };
}
const previewScreen = document.getElementById('previewScreen');
if (previewScreen) previewScreen.classList.toggle('mcqvs-format-youtube', fmt === 'youtube');
document.querySelectorAll('.mcqvs-format-btn').forEach(b => {
b.classList.toggle('active', b.dataset.format === fmt);
});
if (this._canvas) {
this._canvas.width = this.state.width;
this._canvas.height = this.state.height;
}
}
}

                // Ensure derived timing (questionTotal) is consistent after loading/migration
                this.updateComputedValues();
                this.saveState(); // persist migration + derived values

                if (Logger) {
                    Logger.info('STATE_LOAD', { questionCount: this.state.questions.length });
                }

            } catch (error) {
                if (Logger) {
                    Logger.warn('STATE_LOAD_FAIL', { error: error.message });
                }
            }
        }

        /**
         * Ready callback
         */
        onReady() {
            // Emit ready event
            const event = new CustomEvent('mcqvs:studio:ready', {
                detail: { controller: this }
            });
            document.dispatchEvent(event);
        }

        /**
         * @NEW 2026-02-02: Validate required config keys
         * Fails fast if critical keys are missing
         */
        validateConfig(config) {
            if (!config) {
                throw new Error('MCQVS_Config is missing - script localization failed');
            }

            const required = ['rootUrl', 'assetsUrl', 'version'];
            const missing = required.filter(k => !config[k]);

            if (missing.length > 0) {
                const err = `MCQVS_Config missing required keys: ${missing.join(', ')}`;
                if (Logger) Logger.error('CONFIG_INVALID', { missing });
                throw new Error(err);
            }

            if (Logger) {
                Logger.info('CONFIG_VALID', {
                    version: config.version,
                    isDevelopment: config.isDevelopment || false
                });
            }
        }

        /**
         * Destroy controller
         */
        destroy() {
            if (this.preview) {
                this.preview.destroy();
            }

            if (this.audio) {
                this.audio.destroy();
            }

            if (this.ui) {
                this.ui.destroy();
            }

            if (this.export) {
                this.export.destroy();
            }

            if (Logger) {
                Logger.info('CONTROLLER_DESTROY');
            }
        }
    // @NEW 2026-02-16: Auto-Runner Loop
    async _autoRunnerLoop() {
        if (this._isAutoRunning) return;
        this._isAutoRunning = true;

        while (this.state.autoProcessEnabled) {
            try {
                // @FIX 1.4.9.53 (global STOP): halt when the dashboard "Stop
                // Everything" is active (server flag exposed via MCQVS_Config).
                // The server also kills live renders + cancels all queues, so
                // this only stops the browser-side runner from picking up new
                // jobs on its next poll.
                const cfgStopped = !!(window.MCQVS_Config && window.MCQVS_Config.globalStopped);
                if (cfgStopped) {
                    this.state.autoProcessEnabled = false;
                    if (this.notify) this.notify('Pipeline stopped — click Resume on the Dashboard to continue.', 'error');
                    break;
                }
                // Check if idle
                if (this._exportInProgress || (this.export && this.export.isExporting)) {
                    await new Promise(r => setTimeout(r, 5000));
                    continue;
                }

                let jobData = null;

                // @FIX: Headless mode — claim the specific job indicated by URL param.
                //       Accept jobs in pending, ready_for_render, OR rendering status.
                //       The PHP headless path (handle_render_claim_action) already set
                //       the status to 'rendering' and spawned this Node.js process
                //       before the browser loaded. If we only accept pending/ready,
                //       the auto-runner falls back to the empty queue and sits idle
                //       forever while render.js polls for a completion that never comes.
                if (this._headlessTargetJobId) {
                    const targetId = this._headlessTargetJobId;
                    this._headlessTargetJobId = null;
                    const statusRes = await this.ajaxPost('mcqvs_get_job_status', { job_id: targetId });
                    if (statusRes && statusRes.success && statusRes.data) {
                        const existingStatus = statusRes.data.status;
                        if (existingStatus === 'pending' || existingStatus === 'ready_for_render') {
                            await this.ajaxPost('mcqvs_update_job_status', {
                                job_id: targetId,
                                status: 'rendering'
                            });
                            jobData = statusRes.data;
                        } else if (existingStatus === 'rendering') {
                            // Already claimed by PHP headless path — proceed with render
                            jobData = statusRes.data;
                        } else {
                            console.warn('[MCQVS] Headless target job ' + targetId + ' is not claimable (status=' + existingStatus + '). Falling back to queue.');
                        }
                    }
                }

                if (!jobData) {
                    const job = await this.ajaxPost('mcqvs_get_next_pending_job');
                    if (job && job.success && job.data.job) {
                        jobData = job.data.job;
                        await this.ajaxPost('mcqvs_update_job_status', {
                            job_id: jobData.job_id,
                            status: 'rendering'
                        });
                    }
                }

                if (jobData) {

                    // Set active job ID for upload callback
                    this.state.activeJobId = jobData.job_id;

                    // Load data
                    // Normalized question data is in quiz_data column
                    const questions = JSON.parse(jobData.quiz_data || '[]');
                    this.state.questions = questions.map(q => this.normalizeQuestion(q));
                    this.state.selectedQuestions = this.state.questions.map((_, i) => i);

                    // Apply settings (topic name, save_mode etc)
                    const settings = JSON.parse(jobData.settings || '{}');
                    if (settings.topic_name) this.state.quizName = settings.topic_name;

                    // Apply all job settings including save_mode
                    await this.applyJobSettings(settings);

                    // Start Export
                    // We need to wait for it to finish.
                    // The export manager emits events, but here we trigger it and wait for the Promise.
                    this._exportInProgress = true;
                    try {
                        await this.startExport();
                    } catch (exportErr) {
                        console.error('Auto-Runner Export Error:', exportErr);
                        try {
                            await this.ajaxPost('mcqvs_update_job_status', {
                                job_id: jobData.job_id,
                                status: 'failed',
                                error: exportErr.message || 'Export threw an exception'
                            });
                        } catch (_) {}
                    } finally {
                        this._exportInProgress = false;
                    }

                    // Mark completed — only if save_mode is local
                    // For r2/r2_buffer, the upload handler will mark completion
                    const saveMode = this.state.saveMode || 'local';
                    if (saveMode === 'local') {
                        await this.ajaxPost('mcqvs_update_job_status', {
                            job_id: jobData.job_id,
                            status: 'completed'
                        });
                    }

                    // Wait before next
                    await new Promise(r => setTimeout(r, 10000));
                } else {
                    // No jobs, wait 30s
                    await new Promise(r => setTimeout(r, 30000));
                }

            } catch (e) {
                console.error('Auto-Runner Error:', e);
                // Wait before retry
                await new Promise(r => setTimeout(r, 30000));
            }
        }

        this._isAutoRunning = false;
    }

        // NOTE: Removed duplicate stub `_autoRunnerLoop()` which overwrote the real implementation.

        // @NEW 2026-02-16: Content Planner Logic
        async handleGeneratePlan(niche) {
            try {
                // Show loading
                document.getElementById('plannerResults').style.display = 'none';
                this.ui.showNotification('Generating 30-day plan... This may take ~10s', 'info');

                const res = await this.ajaxPost('mcqvs_generate_topic_plan', { niche });
                if (res.success && res.data.topics) {
                    const topics = res.data.topics;
                    const json = JSON.stringify(topics, null, 2);

                    document.getElementById('plannerTopicsJson').value = json;
                    document.getElementById('plannerResults').style.display = 'block';
                    this.ui.showNotification('Plan generated! Review below.', 'success');
                } else {
                    this.ui.showNotification(res.data.message || 'Generation failed', 'error');
                }
            } catch (e) {
                console.error(e);
                this.ui.showNotification('Error generating plan', 'error');
            }
        }

        async handleApprovePlan(topics) {
            if (!confirm(`Schedule ${topics.length} videos? This will create pending jobs.`)) return;

            try {
                this.ui.showNotification('Scheduling jobs... Please wait.', 'info');
                // We need to save the plan first, then approve
                // Or just send approval with topics? The approve endpoint fetches from option.
                // Let's save first to be safe.
                await this.ajaxPost('mcqvs_save_topic_plan', { topics: JSON.stringify(topics) });

                const res = await this.ajaxPost('mcqvs_approve_topic_plan');
                if (res.success) {
                    this.ui.showNotification(`Successfully scheduled ${res.data.count} jobs!`, 'success');
                    this.ui.hideModal('contentPlannerModal');
                    // Refresh job list if we had one
                } else {
                    this.ui.showNotification(res.data.message || 'Scheduling failed', 'error');
                }
            } catch (e) {
                console.error(e);
                this.ui.showNotification('Error scheduling jobs', 'error');
            }
        }

        toggleAutoProcess(enabled) {
            this.state.autoProcessEnabled = enabled;
            if (enabled) {
                this._autoRunnerLoop();
            }
        }

        // ============================================================
        // @NEW 2026-02-23: AI SETTINGS & TOOLS HANDLERS
        // ============================================================

        /**
         * Save TTS Settings via AJAX
         */
        async handleSaveTtsSettings(settings) {
            if (Logger) Logger.info('SAVE_TTS_SETTINGS_START', settings);

            // @MODIFIED 2026-02-26: handleSaveTtsSettings calls this.ajaxPost, not this.ui.ajaxPost
            const resp = await this.ajaxPost('mcqvs_save_tts_settings', {
                // Back-compat: accept both old and new key names server-side
                provider: settings.provider,
                googleKey: settings.googleKey,
                azureKey: settings.azureKey,
                azureRegion: settings.azureRegion,
                elevenlabsKey: settings.elevenlabsKey,

                tts_provider: settings.provider,
                google_cloud_tts_key: settings.googleKey,
                azure_tts_key: settings.azureKey,
                azure_tts_region: settings.azureRegion,
                elevenlabs_api_key: settings.elevenlabsKey
            });

            if (!resp.success) {
                throw new Error(resp.data?.message || 'Failed to save settings');
            }

            if (Logger) Logger.info('SAVE_TTS_SETTINGS_SUCCESS');
            return resp.data;
        }
        /**
         * Trigger AI Quiz generation from sidebar
         * @MODIFIED 2026-02-25: Uses News/Topic card inputs (no hidden defaults).
         */
        async handleGenerateAIQuiz_sidebar() {
            if (Logger) Logger.info('SIDEBAR_GENERATE_QUIZ');

            const topicInput = document.getElementById('topicQuizInput');
            const topicCount = document.getElementById('topicQuestionCount');
            const newsInput = document.getElementById('newsTopicInput');
            const newsCount = document.getElementById('newsQuestionCount');

            const topicVal = topicInput ? String(topicInput.value || '').trim() : '';
            const newsVal = newsInput ? String(newsInput.value || '').trim() : '';

            const clampCount = (v, d = 5) => {
                const n = parseInt(v, 10);
                if (!Number.isFinite(n)) return d;
                return Math.max(3, Math.min(30, n));
            };

            // Priority: Topic card (if filled), otherwise News card
            if (topicVal) {
                const count = clampCount(topicCount ? topicCount.value : 5, 5);
                const resp = await this.ui.ajaxPost('mcqvs_generate_topic_quiz', { topic: topicVal, count });

                if (resp.success && resp.data?.questions) {
                    this.ui.applyQuestions(resp.data.questions, { quizName: topicVal, triggerSEO: true, source: 'topic', hook: resp.data?.hook, hashtags: resp.data?.hashtags });
                    this.ui.showNotification(`Generated ${resp.data.questions.length} questions`, 'success');
                } else {
                    this.ui.showNotification(resp.data?.message || 'Generation failed', 'error');
                }
                return;
            }

            if (newsVal) {
                const count = clampCount(newsCount ? newsCount.value : 5, 5);
                const resp = await this.ui.ajaxPost('mcqvs_generate_news_quiz', { topic: newsVal, count });

                if (resp.success && resp.data?.questions) {
                    this.ui.applyQuestions(resp.data.questions, { quizName: newsVal, triggerSEO: true, source: 'news', hook: resp.data?.hook, hashtags: resp.data?.hashtags });
                    this.ui.showNotification(`Generated ${resp.data.questions.length} questions`, 'success');
                } else {
                    this.ui.showNotification(resp.data?.message || 'Generation failed', 'error');
                }
                return;
            }

            this.ui.showNotification('Enter a Topic or News term first (left panel).', 'error');
        }
        /**
         * Trigger AI Background generation
         * @MODIFIED 2026-02-25: Sends {prompt} and expects same-origin URL from server (sideloaded).
         */
        async handleGenerateBackground_sidebar() {
            if (Logger) Logger.info('SIDEBAR_GENERATE_BG');
            const prompt = (this.state.quizName || this.state.hookText || 'Abstract Pattern').trim() || 'Abstract Pattern';

            this.ui.showNotification('Generating AI Background...', 'info');
            const resp = await this.ui.ajaxPost('mcqvs_generate_ai_background', { prompt });

            if (resp.success && resp.data?.url) {
                const img = new Image();
                img.onload = () => {
                    this.state.bgImage = img;
                    this._invalidateRenderPlan();
                    this.handleStateChange();
                    this.ui.showNotification('Background updated', 'success');
                };
                img.onerror = () => {
                    this.ui.showNotification('Background load failed', 'error');
                };
                img.src = resp.data.url;
            } else {
                this.ui.showNotification(resp.data?.message || 'Background generation failed', 'error');
            }
        }
        /**
         * Generate SEO metadata (High-Performer card)
         */
        async handleGenerateSEO(payload = {}) {
            const kw = (payload && typeof payload.keywords === 'string') ? payload.keywords.trim() : (this.state.seoKeywords || '').trim();

            const platformEl = document.getElementById('exportPlatform');
            const platform = platformEl ? String(platformEl.value || 'tiktok') : 'tiktok';

            const topic = (this.state.quizName || 'General Knowledge').trim() || 'General Knowledge';

            const indices = (Array.isArray(this.state.selectedQuestions) && this.state.selectedQuestions.length)
                ? this.state.selectedQuestions
                : this.state.questions.map((_, i) => i);
            const qs = indices.map(i => this.state.questions[i]).filter(Boolean);

            if (!qs.length) {
                throw new Error('No questions available');
            }

            // In-flight dedupe
            if (this._seoInFlight) return this._seoInFlight;

            this._seoInFlight = (async () => {
                const gen = window.MCQVS_SEOGenerator;
                if (!gen || typeof gen.generate !== 'function') {
                    throw new Error('SEO generator not loaded');
                }

                const data = await gen.generate(topic, qs, { platform, keywords: kw });

                const out = {
                    title: String(data && data.title ? data.title : '').trim(),
                    description: String(data && data.description ? data.description : '').trim(),
                    tags: Array.isArray(data && data.tags) ? data.tags : []
                };

                // @NEW 2026-08-11: Merge the question-aware hashtags returned by the
                //       News/Topic AI cards into the SEO tag set (deduped, #-normalized)
                //       so the auto SEO keeps the AI's topic tags instead of dropping them.
                if (typeof this.state.extraHashtags === 'string' && this.state.extraHashtags.trim()) {
                    const extra = String(this.state.extraHashtags)
                        .split(/[\s,;|]+/)
                        .map(t => {
                            let tag = String(t || '').trim().replace(/^#+/, '').replace(/[^A-Za-z0-9_]/g, '');
                            return tag ? '#' + tag.toLowerCase() : '';
                        })
                        .filter(Boolean);
                    const seen = {};
                    const merged = [];
                    out.tags.concat(extra).forEach(t => {
                        const key = String(t || '').toLowerCase();
                        if (key && !seen[key]) { seen[key] = true; merged.push(t); }
                    });
                    out.tags = merged.slice(0, 12);
                }

                this.state.seoKeywords = kw;
                this.state.seoMeta = out;

                // Hydrate UI fields immediately
                try {
                    const results = document.getElementById('seoResults');
                    const titleEl = document.getElementById('seoTitle');
                    const descEl = document.getElementById('seoDescription');
                    const tagsEl = document.getElementById('seoTags');
                    if (titleEl) titleEl.value = out.title;
                    if (descEl) descEl.value = out.description;
                    if (tagsEl) tagsEl.value = out.tags.join(' ');
                    if (results) results.style.display = '';
                } catch (_) { }

                if (typeof this.saveState === 'function') this.saveState();

                return out;
            })();

            try {
                return await this._seoInFlight;
            } finally {
                this._seoInFlight = null;
            }
        }

        /**
         * Auto SEO generation after AI quiz generation (if enabled)
         */
        async handleAfterQuizGenerated(meta = {}) {
            try {
                const auto = document.getElementById('seoAutoGenerate');
                if (auto && auto.checked === false) return;

                const kwEl = document.getElementById('seoKeywords');
                const kw = kwEl ? String(kwEl.value || '').trim() : (this.state.seoKeywords || '').trim();

                await this.handleGenerateSEO({ keywords: kw });
            } catch (e) {
                // Do not hard-fail quiz generation if SEO fails
                try { this.ui.showNotification('SEO auto-gen failed: ' + (e && e.message ? e.message : 'Unknown'), 'error'); } catch (_) { }
            }
        }

        /**
         * Export a project snapshot (JSON)
         */
        exportProjectSnapshot() {
            const snapshot = {
                schema: 'mcqvs_project',
                version: 1,
                exportedAt: new Date().toISOString(),
                data: {
                    questions: this.state.questions || [],
                    selectedQuestions: this.state.selectedQuestions || [],
                    template: this.state.templateId || this.state.currentTemplate || 'trivia',
                    timing: this.state.timing || {},
                    audio: {
                        enabled: !!this.state.audioEnabled,
                        sfx: !!this.state.sfxEnabled,
                        music: !!this.state.musicEnabled,
                        bgMusicUrl: this.state.bgMusicUrl || '',
                        musicVolume: this.state.musicVolume || 0.3
                    },
                    voiceover: this.state.voiceover || {},
                    branding: {
                        brandName: this.state.brandName || '',
                        quizName: this.state.quizName || '',
                        hookText: this.state.hookText || '',
                        hookVisible: (this.state.hookVisible !== false),
                        ctaText: this.state.ctaText || '',
                        websiteUrl: this.state.websiteUrl || '',
                        brandColor: this.state.brandColor || null,
                        logoPosition: this.state.logoPosition || 'all',
                        brandLogoDataUrl: this.state.brandLogoDataUrl || '',
                        brandLogoUrl: this.state.brandLogoUrl || ''
                    },
                    seo: {
                        keywords: this.state.seoKeywords || '',
                        meta: this.state.seoMeta || { title: '', description: '', tags: [] }
                    }
                }
            };
            return snapshot;
        }

        /**
         * Import a project snapshot (JSON)
         */
        async importProjectSnapshot(payload) {
            const obj = payload && payload.schema === 'mcqvs_project' ? payload.data : payload;
            if (!obj || typeof obj !== 'object') throw new Error('Invalid project file');

            if (Array.isArray(obj.questions)) this.state.questions = obj.questions;
            if (Array.isArray(obj.selectedQuestions)) this.state.selectedQuestions = obj.selectedQuestions;

            const tpl = String(obj.template || this.state.templateId || 'trivia');
            this.state.templateId = tpl;
            this.state.currentTemplate = tpl;
            if (window.MCQVSVideoTemplates && typeof window.MCQVSVideoTemplates.apply === 'function') {
                window.MCQVSVideoTemplates.apply(tpl, this.state);
            }

            if (obj.timing) Object.assign(this.state.timing || (this.state.timing = {}), obj.timing);

            if (obj.audio) {
                this.state.audioEnabled = !!obj.audio.enabled;
                this.state.sfxEnabled = !!obj.audio.sfx;
                this.state.musicEnabled = !!obj.audio.music;
                this.state.bgMusicUrl = obj.audio.bgMusicUrl || '';
                this.state.musicVolume = Number.isFinite(Number(obj.audio.musicVolume)) ? Number(obj.audio.musicVolume) : (this.state.musicVolume || 0.3);
            }

            if (obj.voiceover && typeof obj.voiceover === 'object') {
                this.state.voiceover = Object.assign({}, (this.state.voiceover || {}), obj.voiceover);
            }

            // @NEW 2026-04: Track active project for video_url updates
            this.state.activeProjectId = this.state.currentProjectId || null;

            if (obj.branding && typeof obj.branding === 'object') {
                Object.assign(this.state, obj.branding);
                // Restore logo image object
                const logoUrl = String(obj.branding.brandLogoDataUrl || obj.branding.brandLogoUrl || '').trim();
                if (logoUrl) this.restoreBrandLogoFromDataUrl(logoUrl);
            }

            if (obj.seo) {
                this.state.seoKeywords = String(obj.seo.keywords || '').trim();
                this.state.seoMeta = obj.seo.meta || { title: '', description: '', tags: [] };
            }

            // Sync UI surfaces
            this.syncUIFromState();
            if (this.ui) {
                this.ui.renderQuestionsList();
                this.ui.renderQuestionSelectorList();
            }

            this.handleStateChange();
            if (typeof this.saveState === 'function') this.saveState();
        }

        /**
         * Capture current preview canvas as PNG data URL
         */
        async captureThumbnail() {
            const canvas = document.getElementById('previewCanvas');
            if (!canvas) throw new Error('Preview canvas not found');
            try {
                return canvas.toDataURL('image/png');
            } catch (e) {
                throw new Error('Canvas is tainted by cross-origin media. Use same-origin assets or proxy.');
            }
        }

    }

    // Export
    window.MCQVS_StudioController = StudioController;

    // Auto-initialize if config present
    if (window.MCQVS_Config) {
console.log('[MCQVS DEBUG] MCQVS_Config FOUND, registering DOMContentLoaded');
document.addEventListener('DOMContentLoaded', async () => {
    console.log('[MCQVS DEBUG] DOMContentLoaded fired — starting StudioController');
    try {
        const controller = new StudioController(window.MCQVS_Config);
        console.log('[MCQVS DEBUG] StudioController constructed');
        await controller.initialize();
        window.MCQVS_Controller = controller;

        // @NEW 2026-04-22: Auto-start rendering when loaded by headless Chrome
        const urlParams = new URLSearchParams(window.location.search);
        const autoRunJob = urlParams.get('auto_run_job') || urlParams.get('job_id');
        if (autoRunJob && urlParams.get('auto_run')) {
            console.log('[MCQVS] Headless mode: Auto-starting render for job', autoRunJob);
            controller.state.autoProcessEnabled = true;
            controller._headlessTargetJobId = autoRunJob;
            controller._autoRunnerLoop();
        }
    } catch (e) {
        console.error('[MCQVS] Studio init failed:', e);
        try {
            const banner = document.createElement('div');
            banner.style.cssText = 'margin:12px 0;padding:12px 14px;border-left:4px solid #dc3232;background:#fff;box-shadow:0 1px 2px rgba(0,0,0,0.06);';
            banner.innerHTML =
                '<strong>MCQ Video Studio failed to initialize.</strong>' +
                '<div style="margin-top:6px;">' + (e?.message || 'Unknown error') + '</div>' +
                '<div style="margin-top:6px;color:#555;">Open DevTools Console for details.</div>';
            (document.querySelector('.wrap') || document.body).prepend(banner);
        } catch (_) { }
    }
});
}

// @NEW 2026-06-29: ES2017-compatible replacement for `static RESOLUTION = {...}`.
// Lives outside the `if (window.MCQVS_Config)` block so the constant is always defined.
StudioController.RESOLUTION = { width: 1080, height: 1920 };

    console.log('[MCQVS DEBUG] studio.controller.js finished loading');
    })(window, jQuery);
