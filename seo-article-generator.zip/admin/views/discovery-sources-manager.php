<?php

/**
 * Source Manager View Component
 *
 * This file renders the source management interface within the Discovery Dashboard.
 * 
 * @package SEO_Article_Generator\Discovery
 * @version 2026-03-02
 */

if (!defined('ABSPATH')) exit;

// Get current sources
$sources = get_option('seo_gen_discovery_sources', []);
if (!is_array($sources)) $sources = [];

$scraper_types = [
    'auto'            => 'Auto (WP Automatic Priority, Native Fallback)',
    'native'          => 'Native-Only (wp_remote_get)',
    'rssfeed'         => 'WP Automatic | RSS Feed Campaign',
    'multiscraper'    => 'WP Automatic | Visual Multi-Scraper',
    'articlescraper'  => 'WP Automatic | Single Page Scraper',
];
?>

<div class="sgd-sources-container">

    <div style="margin-bottom:20px; display:flex; justify-content:space-between; align-items:center;">
        <h2 style="margin:0;">Manage Feed Sources</h2>
        <button id="sgd-open-add-source" class="sgd-btn">Add New Source</button>
    </div>

    <!-- ============================================================ -->
    <!-- SOURCES TABLE -->
    <!-- ============================================================ -->
    <table class="sgd-table" id="sgd-sources-table">
        <thead>
            <tr>
                <th>Source Label</th>
                <th>Strategy</th>
                <th>Last Tested</th>
                <th>Status</th>
                <th>Campaign</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($sources)): ?>
                <tr class="sgd-no-sources">
                    <td colspan="6" style="text-align:center; padding:30px; color:#777;">
                        No sources configured. Add a feed URL to start discovering content.
                    </td>
                </tr>
            <?php else: ?>
                <?php foreach ($sources as $source):
                    $campaign_id    = !empty($source['campaign_id']) ? (int)$source['campaign_id'] : 0;
                    $source_type    = isset($source['scraper_type']) ? \SEO_Article_Generator\Discovery\Discovery_Bootstrap::normalize_source_type((string) $source['scraper_type']) : 'auto';
                    $status         = \sanitize_key((string) ($source['status'] ?? 'untested'));
                    $test_chars     = (int) ($source['test_chars'] ?? 0);
                    $last_tier      = (string) ($source['last_tier'] ?? '');
                    $campaign_ready = ! empty($source['campaign_ready']) || $campaign_id > 0;

                    if ($status === 'success' && $test_chars > 0 && $test_chars < 300) {
                        $status = 'thin';
                    }

                    $status_labels = array(
                        'success'  => 'Ready',
                        'thin'     => 'Thin',
                        'failed'   => 'Failed',
                        'untested' => 'Untested',
                    );

                    $status_label = $status_labels[$status] ?? 'Untested';
                ?>
                    <tr data-id="<?php echo esc_attr($source['id']); ?>">
                        <td>
                            <strong><?php echo esc_html($source['label']); ?></strong>
                            <div style="font-size:11px; color:#aaa;"><?php echo esc_html($source['feed_url']); ?></div>
                        </td>
                        <td>
                            <span class="type-pill <?php echo esc_attr($source_type); ?>">
                                <?php echo esc_html($scraper_types[$source_type] ?? $source_type); ?>
                            </span>
                        </td>
                        <td style="font-size:12px; color:#777;">
                            <?php echo !empty($source['last_tested']) ? \human_time_diff((int)$source['last_tested'], \SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts()) . ' ago' : 'Never'; ?>
                        </td>
                        <td>
                            <span class="sgd-badge-status <?php echo esc_attr($status); ?>">
                                <?php echo esc_html($status_label); ?>
                            </span>

                            <?php if (! empty($source['test_note'])) : ?>
                                <div style="font-size:10px; color:#999; margin-top:2px; max-width:180px; overflow:hidden; text-overflow:ellipsis;"
                                     title="<?php echo esc_attr($source['test_note']); ?>">
                                    <?php echo esc_html($source['test_note']); ?>
                                </div>
                            <?php endif; ?>

                            <?php if ($last_tier) : ?>
                                <div style="font-size:10px; color:#777; margin-top:2px;">
                                    Tier: <?php echo esc_html($last_tier); ?>
                                </div>
                            <?php endif; ?>

                            <?php if (in_array($source_type, array('rssfeed', 'multiscraper', 'articlescraper'), true) && ! $campaign_ready) : ?>
                                <div style="font-size:10px; color:#c62828; margin-top:2px;">
                                    Campaign missing
                                </div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($campaign_id): ?>
                                <a href="<?php echo esc_url(admin_url('post.php?post=' . $campaign_id . '&action=edit')); ?>" target="_blank" class="sgd-btn sgd-btn-tiny">Open #<?php echo $campaign_id; ?></a>
                            <?php else: ?>
                                <span style="color:#ccc; font-size:11px;">None</span>
                            <?php endif; ?>
                        </td>
                        <td style="white-space:nowrap;">
                            <button class="sgd-btn sgd-btn-tiny sgd-test-source" data-id="<?php echo esc_attr($source['id']); ?>" data-feed="<?php echo esc_attr($source['feed_url']); ?>" data-type="<?php echo esc_attr($source_type); ?>" data-camp="<?php echo (int)$campaign_id; ?>">Test</button>
                            <button class="sgd-btn sgd-btn-tiny sgd-edit-source"
                                data-id="<?php echo esc_attr($source['id']); ?>"
                                data-feed="<?php echo esc_attr($source['feed_url']); ?>"
                                data-label="<?php echo esc_attr($source['label']); ?>"
                                data-type="<?php echo esc_attr($source_type); ?>">Edit</button>
                            <button class="sgd-btn sgd-btn-tiny sgd-delete-source" data-id="<?php echo esc_attr($source['id']); ?>">Dismiss</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>

    <div style="margin-top:15px; font-size:12px; color:#888;">
        <p><strong>Note on Scraper Priority:</strong> The 'Auto' strategy tries <span style="color:#555;">WP Automatic</span> first. If that returns thin or empty content, it falls back to <span style="color:#555;">Native</span> extraction.</p>
    </div>

</div>

<!-- ============================================================ -->
<!-- MODAL: ADD/EDIT SOURCE -->
<!-- ============================================================ -->
<div id="sgd-source-modal" class="sgd-modal" style="display:none; position:fixed; z-index:99999; left:0; top:0; width:100%; height:100%; background:rgba(0,0,0,0.5);">
    <div style="background:#fff; width:500px; margin:100px auto; border-radius:8px; box-shadow:0 10px 30px rgba(0,0,0,0.22); overflow:hidden;">
        <div style="padding:15px 20px; background:#f8f9fa; border-bottom:1px solid #eee; display:flex; justify-content:space-between; align-items:center;">
            <h3 id="sgd-modal-title" style="margin:0;">Add New Source</h3>
            <span id="sgd-close-modal" style="cursor:pointer; font-size:20px;">&times;</span>
        </div>
        <div style="padding:20px;">
            <form id="sgd-source-form">
                <input type="hidden" id="sgd-f-id" value="">

                <div style="margin-bottom:15px;">
                    <label style="display:block; margin-bottom:5px; font-weight:600;">Feed URL (RSS/Atom)*</label>
                    <input type="url" id="sgd-f-feed" style="width:100%; padding:8px;" placeholder="https://example.com/feed/" required>
                </div>

                <div style="margin-bottom:15px;">
                    <label style="display:block; margin-bottom:5px; font-weight:600;">Site Label</label>
                    <input type="text" id="sgd-f-label" style="width:100%; padding:8px;" placeholder="Optional Site Name">
                </div>

                <div style="margin-bottom:20px;">
                    <label style="display:block; margin-bottom:5px; font-weight:600;">Scraper Strategy</label>
                    <select id="sgd-f-type" style="width:100%; padding:8px;">
                        <?php foreach ($scraper_types as $key => $lbl): ?>
                            <option value="<?php echo esc_attr($key); ?>"><?php echo esc_html($lbl); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <p style="font-size:11px; color:#777; margin-top:5px;">Select "Auto" for the recommended three-tier cascade.</p>
                </div>

                <div style="display:flex; justify-content:flex-end;">
                    <button type="button" id="sgd-cancel-modal" class="sgd-btn" style="background:#f8f9fa!important; color:#333!important; margin-right:8px; border:1px solid #ddd!important;">Cancel</button>
                    <button type="submit" class="sgd-btn" style="background:#2271b1!important;">Save Source</button>
                </div>
            </form>
        </div>
    </div>
</div>

<style>
    .sgd-btn-tiny {
        padding: 4px 8px !important;
        font-size: 11px !important;
        height: auto !important;
        line-height: 1 !important;
    }

    .sgd-modal input,
    .sgd-modal select {
        border: 1px solid #ced4da;
        border-radius: 4px;
    }

    .type-pill {
        display: inline-block;
        padding: 2px 8px;
        border-radius: 12px;
        font-size: 10px;
        font-weight: 600;
        text-transform: uppercase;
    }

    .type-pill.auto {
        background: #e7f3ff;
        color: #007bff;
    }

    .type-pill.native {
        background: #f0f0f0;
        color: #666;
    }

    .type-pill.rssfeed,
    .type-pill.multiscraper,
    .type-pill.articlescraper {
        background: #fff3e0;
        color: #ef6c00;
    }

    .sgd-badge-status.thin {
        background: #fff3cd;
        color: #856404;
    }
    .sgd-badge-status.success {
        background: #d4edda;
        color: #155724;
    }
    .sgd-badge-status.failed {
        background: #f8d7da;
        color: #721c24;
    }
    .sgd-badge-status.untested {
        background: #eef2f7;
        color: #5a6b7d;
    }
</style>

<script>
    jQuery(document).ready(function($) {
        var nonce = '<?php echo wp_create_nonce("seo_gen_nonce"); ?>';
        var ajaxUrl = ajaxurl;

        // Open Modal
        $('#sgd-open-add-source').on('click', function() {
            $('#sgd-modal-title').text('Add New Source');
            $('#sgd-f-id').val('');
            $('#sgd-f-feed').val('');
            $('#sgd-f-label').val('');
            $('#sgd-f-type').val('auto');
            $('#sgd-source-modal').fadeIn(200);
        });

        // Edit button
        $(document).on('click', '.sgd-edit-source', function() {
            var btn = $(this);
            $('#sgd-modal-title').text('Edit Source');
            $('#sgd-f-id').val(btn.data('id'));
            $('#sgd-f-feed').val(btn.data('feed'));
            $('#sgd-f-label').val(btn.data('label'));
            $('#sgd-f-type').val(btn.data('type'));
            $('#sgd-source-modal').fadeIn(200);
        });

        // Close Modal
        $('#sgd-close-modal, #sgd-cancel-modal').on('click', function() {
            $('#sgd-source-modal').fadeOut(200);
        });

        // Handle Form Submit
        $('#sgd-source-form').on('submit', function(e) {
            e.preventDefault();
            var id = $('#sgd-f-id').val();
            var action = id ? 'seo_gen_update_source' : 'seo_gen_add_source';

            var data = {
                action: action,
                nonce: nonce,
                id: id,
                feed_url: $('#sgd-f-feed').val(),
                label: $('#sgd-f-label').val(),
                type: $('#sgd-f-type').val()
            };

            $.post(ajaxUrl, data, function(res) {
                if (res.success) {
                    location.reload();
                } else {
                    alert('Error: ' + res.data.message);
                }
            });
        });

        // Handle Delete
        $(document).on('click', '.sgd-delete-source', function() {
            if (!confirm('Remove this source? It will no longer discover new items.')) return;
            var id = $(this).data('id');
            $.post(ajaxUrl, {
                action: 'seo_gen_delete_source',
                nonce: nonce,
                id: id
            }, function(res) {
                if (res.success) {
                    location.reload();
                } else {
                    alert('Error: ' + res.data.message);
                }
            });
        });

        // Handle Test
        $(document).on('click', '.sgd-test-source', function() {
            var btn = $(this);
            var id = btn.data('id');
            var originalText = btn.text();

            btn.text('Testing...').prop('disabled', true);

            $.post(ajaxUrl, {
                action: 'seo_gen_test_source',
                nonce: nonce,
                id: id,
                feed_url: btn.data('feed'),
                scraper_type: btn.data('type'),
                campaign_id: btn.data('camp')
            }, function(res) {
                if (res.success) {
                    var msg = res.data.message || 'Test passed.';
                    if (!res.data.sufficient) {
                        msg += '\n\nWarning: Thin content (' + res.data.char_count + ' chars).';
                    }
                    alert(msg + '\n\nTier: ' + res.data.tier_used + '\nLength: ' + res.data.char_count + ' chars\n\nPreview:\n' + res.data.preview + '...');
                    location.reload();
                } else {
                    // If failed due to "WP Automatic Campaign Missing" and type is set to a WP Auto type
                    var type = btn.data('type');
                    if (['rssfeed', 'multiscraper', 'articlescraper'].indexOf(type) !== -1) {
                        if (confirm('WP Automatic campaign is not created for this source yet. Would you like to create it now?')) {
                            createCampaign(id, btn.data('feed'), type, btn.closest('tr').find('strong').text());
                            return;
                        }
                    }
                    alert('Test Failed: ' + res.data.message);
                }
                btn.text(originalText).prop('disabled', false);
            });
        });

        function createCampaign(id, feedUrl, type, label) {
            $.post(ajaxUrl, {
                action: 'seo_gen_create_wp_auto_campaign',
                nonce: nonce,
                id: id,
                feed_url: feedUrl,
                scraper_type: type,
                label: label
            }, function(res) {
                if (res.success) {
                    alert(res.data.message + '\n\nPlease open the campaign and verify selectors before testing again.');
                    window.open(res.data.edit_url, '_blank');
                    location.reload();
                } else {
                    alert('Failed to create campaign: ' + res.data.message);
                }
            });
        }
    });
</script>
