<?php

/**
 * Excerpt Optimizer
 *
 * Generates SEO-optimized meta descriptions from article content.
 * Includes keyword density check and character limit enforcement.
 *
 * @package DIT_TrendStudio\SEO
 * @MODIFIED 2026-02-15 - Restored from legacy backups and modernized for v2.8+
 */

namespace DIT\TrendStudio\SEO;

use DIT\TrendStudio\Integrations\Gemini\Client as AI_Client;
use DIT\TrendStudio\Infrastructure\Logger;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Generates optimized excerpts/meta descriptions for articles.
 */
class Excerpt_Optimizer
{
    /**
     * Optimal meta description length range
     */
    private const MIN_LENGTH = 120;
    private const MAX_LENGTH = 160;

    /**
     * AI Client
     *
     * @var AI_Client|null
     */
    private ?AI_Client $ai_client = null;

    /**
     * Logger
     *
     * @var Logger
     */
    private Logger $logger;

    /**
     * Constructor
     *
     * @param Logger $logger Logger instance
     */
    public function __construct(Logger $logger)
    {
        $this->logger = $logger;
    }

    /**
     * Set AI client for AI-powered optimization.
     *
     * @param AI_Client $client AI client
     * @return self
     */
    public function with_ai_client(AI_Client $client): self
    {
        $this->ai_client = $client;
        return $this;
    }

    /**
     * Generate optimized excerpt from article content.
     *
     * @param array  $article      Article data with 'headline', 'dek', 'sections'
     * @param string $focus_keyword Optional focus keyword for SEO
     * @param string $unique_angle  The unique angle/hook for this content
     * @return array ['excerpt' => string, 'score' => int, 'suggestions' => array]
     */
    public function generate(array $article, string $focus_keyword = '', string $unique_angle = ''): array
    {
        $headline = $article['headline'] ?? '';
        $dek = $article['dek'] ?? '';
        $first_section = $article['sections'][0]['body_html'] ?? '';

        // Try AI-powered generation first
        if ($this->ai_client) {
            try {
                return $this->generate_with_ai($headline, $dek, $first_section, $focus_keyword, $unique_angle);
            } catch (\Exception $e) {
                $this->logger->warning('AI excerpt generation failed, using fallback: ' . $e->getMessage());
            }
        }

        // Fallback to rule-based extraction
        return $this->generate_fallback($headline, $dek, $first_section, $focus_keyword);
    }

    /**
     * Generate excerpt using AI.
     *
     * @param string $headline      Article headline
     * @param string $dek           Subheadline
     * @param string $first_section First section content
     * @param string $focus_keyword Focus keyword
     * @param string $unique_angle  Unique angle
     * @return array Excerpt result
     */
    private function generate_with_ai(
        string $headline,
        string $dek,
        string $first_section,
        string $focus_keyword,
        string $unique_angle
    ): array {
        $content_preview = wp_strip_all_tags($first_section);
        $content_preview = substr($content_preview, 0, 500);

        $prompt = <<<PROMPT
Write a meta description for this article. Requirements:
- Exactly 140-155 characters
- Include the focus keyword naturally (if provided)
- Compelling and click-worthy
- Highlight the unique angle/value proposition
- No clickbait or false promises

Headline: {$headline}
Subheadline: {$dek}
Focus Keyword: {$focus_keyword}
Unique Angle: {$unique_angle}
Content Preview: {$content_preview}

Output ONLY the meta description text, nothing else.
PROMPT;

        // @MODIFIED 2026-02-15 - Use modernized Gemini Client methods
        $model_id = AI_Client::get_model_id();
        $api_version = AI_Client::get_api_version();
        $url = "https://generativelanguage.googleapis.com/{$api_version}/models/{$model_id}:generateContent?key=" . AI_Client::get_gemini_key();

        $body = [
            'contents' => [
                ['parts' => [['text' => $prompt]]]
            ],
            'generationConfig' => [
                'temperature'     => 0.7,
                'maxOutputTokens' => 200,
            ],
        ];

        $response = wp_remote_post($url, [
            'headers' => ['Content-Type' => 'application/json'],
            'body'    => wp_json_encode($body),
            'timeout' => 30,
        ]);

        if (is_wp_error($response)) {
            throw new \Exception('API request failed');
        }

        $data = json_decode(wp_remote_retrieve_body($response), true);
        $excerpt = trim($data['candidates'][0]['content']['parts'][0]['text'] ?? '');

        // Clean up any quotes or extra formatting
        $excerpt = trim($excerpt, '"\'');

        return $this->analyze_excerpt($excerpt, $focus_keyword);
    }

    /**
     * Generate excerpt using rule-based fallback.
     *
     * @param string $headline      Headline
     * @param string $dek           Dek
     * @param string $first_section First section
     * @param string $focus_keyword Focus keyword
     * @return array Excerpt result
     */
    private function generate_fallback(
        string $headline,
        string $dek,
        string $first_section,
        string $focus_keyword
    ): array {
        // Priority: dek > first sentence of content > truncated headline
        $excerpt = '';

        if (!empty($dek) && strlen($dek) >= self::MIN_LENGTH) {
            $excerpt = $dek;
        } else {
            // Extract first sentence from content
            $text = wp_strip_all_tags($first_section);
            $sentences = preg_split('/(?<=[.!?])\s+/', $text, 3, PREG_SPLIT_NO_EMPTY);

            if (!empty($sentences)) {
                $excerpt = $sentences[0];
                // Add second sentence if too short
                if (strlen($excerpt) < self::MIN_LENGTH && !empty($sentences[1])) {
                    $excerpt .= ' ' . $sentences[1];
                }
            }
        }

        // Ensure length limits
        if (strlen($excerpt) > self::MAX_LENGTH) {
            $excerpt = $this->smart_truncate($excerpt, self::MAX_LENGTH);
        }

        // Minimum fallback
        if (strlen($excerpt) < self::MIN_LENGTH) {
            $excerpt = $this->smart_truncate($headline . '. ' . $dek, self::MAX_LENGTH);
        }

        return $this->analyze_excerpt($excerpt, $focus_keyword);
    }

    /**
     * Analyze excerpt and provide score + suggestions.
     *
     * @param string $excerpt       The excerpt
     * @param string $focus_keyword Focus keyword
     * @return array Analysis result
     */
    private function analyze_excerpt(string $excerpt, string $focus_keyword): array
    {
        $score = 100;
        $suggestions = [];

        $length = strlen($excerpt);

        // Length check
        if ($length < self::MIN_LENGTH) {
            $score -= 20;
            $suggestions[] = "Too short ({$length} chars). Aim for " . self::MIN_LENGTH . "-" . self::MAX_LENGTH . ".";
        } elseif ($length > self::MAX_LENGTH) {
            $score -= 15;
            $suggestions[] = "Too long ({$length} chars). May be truncated in SERPs.";
        }

        // Keyword check
        if (!empty($focus_keyword)) {
            $keyword_lower = strtolower($focus_keyword);
            $excerpt_lower = strtolower($excerpt);

            if (strpos($excerpt_lower, $keyword_lower) === false) {
                $score -= 25;
                $suggestions[] = "Focus keyword '{$focus_keyword}' not found in excerpt.";
            } elseif (strpos($excerpt_lower, $keyword_lower) > 50) {
                $score -= 10;
                $suggestions[] = "Keyword appears late. Place it earlier for better CTR.";
            }
        }

        // CTA/engagement check
        $engagement_words = ['discover', 'learn', 'find out', 'explore', 'get', 'see', 'read'];
        $has_engagement = false;
        foreach ($engagement_words as $word) {
            if (stripos($excerpt, $word) !== false) {
                $has_engagement = true;
                break;
            }
        }
        if (!$has_engagement) {
            $score -= 10;
            $suggestions[] = "Consider adding an action word (discover, learn, explore).";
        }

        // Clamp score
        $score = max(0, min(100, $score));

        return [
            'excerpt'     => $excerpt,
            'length'      => $length,
            'score'       => $score,
            'grade'       => $this->score_to_grade($score),
            'suggestions' => $suggestions,
        ];
    }

    /**
     * Smart truncate text at word boundary.
     *
     * @param string $text   Text to truncate
     * @param int    $length Max length
     * @return string Truncated text
     */
    private function smart_truncate(string $text, int $length): string
    {
        if (strlen($text) <= $length) {
            return $text;
        }

        $text = substr($text, 0, $length);
        $last_space = strrpos($text, ' ');

        if ($last_space !== false && $last_space > $length * 0.7) {
            $text = substr($text, 0, $last_space);
        }

        return rtrim($text, '.,!? ') . '...';
    }

    /**
     * Convert score to letter grade.
     *
     * @param int $score Score
     * @return string Grade
     */
    private function score_to_grade(int $score): string
    {
        if ($score >= 90) return 'A';
        if ($score >= 80) return 'B';
        if ($score >= 70) return 'C';
        if ($score >= 60) return 'D';
        return 'F';
    }

    /**
     * Apply excerpt to post.
     *
     * @param int    $post_id Post ID
     * @param string $excerpt Excerpt text
     * @return bool Success
     */
    public function apply_to_post(int $post_id, string $excerpt): bool
    {
        $result = wp_update_post([
            'ID'           => $post_id,
            'post_excerpt' => $excerpt,
        ]);

        if (is_wp_error($result)) {
            $this->logger->error('Failed to update post excerpt: ' . $result->get_error_message());
            return false;
        }

        // Also set Yoast/RankMath meta description if available
        update_post_meta($post_id, '_yoast_wpseo_metadesc', $excerpt);
        update_post_meta($post_id, 'rank_math_description', $excerpt);

        $this->logger->info("Excerpt applied to post {$post_id}");
        return true;
    }
}
