<?php

/**
 * Hero Renderer
 * @MODIFIED 2025-12-14 v2.1.0: App Store Style layout with logo, specs grid, trust footer
 *
 * @package SEO_Article_Generator
 */

namespace SEO_Article_Generator\Generator;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Renders hero section HTML from structured data
 */
class Hero_Renderer
{
    use \SEO_Article_Generator\Traits\Markdown_Processor;

    /**
     * Render hero section HTML
     * @MODIFIED 2025-12-14 v2.1.0: App Store style with 3-column grid layout
     *
     * @param array $data Hero data from post meta
     * @return string HTML output
     */
    public function render($data)
    {
        // Validate required fields
        if (empty($data['software_name'])) {
            return '';
        }

        // Extract data with fallbacks
        // @MODIFIED 2026-01-06: Added markdown processing
        $software_name = wp_kses_post(self::process_markdown($data['software_name']));
        $version = isset($data['version']) ? wp_kses_post(self::process_markdown($data['version'])) : '';
        // @MODIFIED 2025-12-16 v2.3.2: Fixed empty string handling - always fall back to 'Free'
        $license = '';
        if (!empty($data['license_details'])) {
            $license = wp_kses_post(self::process_markdown($data['license_details']));
        } elseif (!empty($data['license'])) {
            $license = wp_kses_post(self::process_markdown($data['license']));
        } else {
            $license = 'Free';
        }
        $file_size = isset($data['file_size']) ? wp_kses_post(self::process_markdown($data['file_size'])) : '';
        // @MODIFIED 2026-03-08: Use Rating_System as the single source for ratings (seeded or user).
        // FIX: In Gutenberg block context, get_the_ID() may fail - use data['post_id'] if available
        $post_id = ! empty( $data['post_id'] ) ? $data['post_id'] : ( function_exists( 'get_the_ID' ) ? get_the_ID() : null );

        // [SSOT-FIX Drift #1] Honor editor_rating precedence before reading live rating.
        // Mirrors Hero_Data_Provider::from_schema() line 96: editor_rating > 0 ? editor_rating
        // : live_average. Without this, the front-end hero renders live average even when
        // an editor has set a deliberate manual override via the Hero Meta Box, producing
        // visible UI drift from seogenherodata['rating'] and failing Google Structured Data
        // guidelines (JSON-LD aggregateRating must match the visible UI).
        $editor_rating = isset( $data['editor_rating'] ) ? (float) $data['editor_rating'] : 0.0;
        if ( $editor_rating <= 0 && $post_id ) {
            // Fallback: read editor_rating from seogenherodata (Hero Meta Box storage)
            // or, if absent, from the schema snapshot (AI-set override). Same two-source
            // precedence rule used by Rank_Math_Schema_Handler::refresh_schema_on_rating_update().
            $hero_meta = \get_post_meta( (int) $post_id, 'seogenherodata', true );
            if ( is_array( $hero_meta ) && ! empty( $hero_meta['editor_rating'] ) ) {
                $editor_rating = (float) $hero_meta['editor_rating'];
            } elseif ( class_exists( '\SEO_Article_Generator\Services\Schema_Sync_Service' )
                && \SEO_Article_Generator\Services\Schema_Sync_Service::has_schema( (int) $post_id ) ) {
                $schema = \SEO_Article_Generator\Services\Schema_Sync_Service::load_schema( (int) $post_id );
                if ( $schema instanceof \SEO_Article_Generator\Generator\Article_Schema && $schema->editor_rating > 0 ) {
                    $editor_rating = (float) $schema->editor_rating;
                }
            }
        }

        if ($post_id && class_exists('SEO_Article_Generator\\Frontend\\Rating_System')) {
            $rating_data = \SEO_Article_Generator\Frontend\Rating_System::get_rating_data($post_id);
            $rating_count = (string) $rating_data['count'];
            // [SSOT-FIX Drift #1] editor_rating overrides live average (mirrors from_schema precedence).
            $rating = $editor_rating > 0 ? $editor_rating : (float) $rating_data['average'];
        } else {
            $rating_count = isset($data['rating_count']) ? esc_html($data['rating_count']) : '';
            // [SSOT-FIX Drift #1] Fallback path also honors editor_rating from $data.
            $rating = $editor_rating > 0 ? $editor_rating : ( isset($data['rating']) ? floatval($data['rating']) : 0.0 );
        }
        $download_links = (isset($data['download_links']) && is_array($data['download_links']))
            ? $data['download_links']
            : array();

        // App Store style fields (v2.1.0)
        $logo_url = isset($data['logo_url']) ? esc_url($data['logo_url']) : '';
        // Fallback: use the post's featured image if logo_url was not stored.
        if ( $logo_url === '' && $post_id && has_post_thumbnail( $post_id ) ) {
            $logo_url = (string) get_the_post_thumbnail_url( $post_id, 'full' );
            if ( $logo_url ) {
                $logo_url = esc_url( $logo_url );
            }
        }
        $publisher = isset($data['publisher']) ? wp_kses_post(self::process_markdown($data['publisher'])) : '';
	$category = isset($data['category']) && $data['category'] !== '' ? wp_kses_post(self::process_markdown($data['category'])) : (isset($data['application_category']) && $data['application_category'] !== '' ? wp_kses_post(self::process_markdown($data['application_category'])) : '');

        // ── FIX: Convert raw category slugs to Professional Title Case ──
        if ( ! empty( $category ) ) {
            // Explode by comma in case the AI returns multiple categories (e.g., "document-management, office-suite")
            $category_array = explode( ',', $category );
            
            // Format each slug: Replace hyphens/underscores with spaces, then Capitalize Words
            $formatted_categories = array_map( function( $cat ) {
                return ucwords( str_replace( ['-', '_'], ' ', trim( $cat ) ) );
            }, $category_array );

            // Re-join them with a clean comma and space
            $display_category = implode( ', ', $formatted_categories );
        } else {
            $display_category = '';
        }
        // ─────────────────────────────────────────────────────────────

        $last_updated = isset($data['last_updated']) ? wp_kses_post(self::process_markdown($data['last_updated'])) : '';
        // @MODIFIED 2026-01-30: Cleaned platform string/list for Icon display (Merged with Links)
        $min_os_raw = isset($data['min_os']) ? $data['min_os'] : '';
        $platform_list = $this->get_platform_list($min_os_raw, $download_links);
        // Fallback for non-standard platforms or empty list
        $min_os_text = empty($platform_list) ? wp_kses_post(self::process_markdown($min_os_raw)) : '';

        // Trust badges - ONLY show if explicitly set by Truth Validator
        $security_badge = !empty($data['security_badge'])
            ? wp_kses_post(self::process_markdown($data['security_badge']))
            : '';

        // [CANONICAL-FIX] Finding 3: Resolve identity live from native WP state
        // Primary Author derivation (always follows post_author ID)
        $author_profile = null;
        if (class_exists('SEO_Article_Generator\\EEAT\\Author_Profile_Manager')) {
            $profile_manager = new \SEO_Article_Generator\EEAT\Author_Profile_Manager();
            $post_obj = get_post($post_id);
            if ($post_obj) {
                $author_profile = $profile_manager->get_author_profile($post_obj->post_author);
            }
        }
        $author_name = $author_profile ? wp_kses_post($author_profile['name']) : '';

        // Reviewer derivation (resolved from _seo_reviewed_by ID)
        $reviewer_id = (int) get_post_meta($post_id, '_seo_reviewed_by', true);
        $reviewer_profile = null;
        if ($reviewer_id > 0 && isset($profile_manager)) {
            $reviewer_profile = $profile_manager->get_author_profile($reviewer_id);
        }
        $reviewer_name = $reviewer_profile ? wp_kses_post($reviewer_profile['name']) : '';

        // [CANONICAL-FIX] Finding 2: Read strictly from seogenherodata['last_verified_date']
        $last_verified = isset($data['last_verified_date']) ? $data['last_verified_date'] : '';

        // Find primary download link and alternates using the helper for consistency
        $primary_link = \SEO_Article_Generator\Generator\Download_Link_Helper::get_primary_link($download_links);
        $alternate_links = array();

        if ($primary_link) {
            foreach ($download_links as $link) {
                if ($link['url'] !== $primary_link['url']) {
                    $alternate_links[] = $link;
                }
            }
        }

        // Generate initials for fallback logo
        $initials = $this->generate_initials(wp_strip_all_tags($software_name));

        // Start HTML output
        ob_start();
?>
        <!-- @MODIFIED 2025-12-14 v2.1.0: App Store Style Hero -->
        <div class="seo-gen-hero seo-gen-hero--appstore" role="banner">
            <div class="seo-gen-hero__inner">
                <!-- Logo Column -->
                <div class="seo-gen-hero__logo">
                    <?php if ($logo_url): ?>
                        <img src="<?php echo $logo_url; ?>" alt="<?php echo esc_attr(wp_strip_all_tags($software_name)); ?> logo" class="seo-gen-hero__logo-img">
                    <?php else: ?>
                        <div class="seo-gen-hero__logo-initials"><?php echo esc_html($initials); ?></div>
                    <?php endif; ?>
                </div>

                <!-- Info Column -->
                <div class="seo-gen-hero__info">
                    <h2 class="seo-gen-hero__title"><?php echo $software_name; ?></h2>
                    <?php if ($publisher || $category): ?>
                        <p class="seo-gen-hero__publisher">
                            <?php if ($publisher): ?><?php echo $publisher; ?><?php endif; ?>
                            <?php if ($publisher && $category): ?>
                                <span class="seo-gen-hero__publisher-sep">•</span>
                            <?php endif; ?>
                            <?php if ($category): ?><?php echo esc_html($display_category); ?><?php endif; ?>
                        </p>
                    <?php endif; ?>
                    <!-- @since 2.7.3: Interactive user rating widget in meta -->
                    <?php
                    // FIX: In Gutenberg block context, get_the_ID() may fail - use cached $post_id from earlier
                    if ( empty( $post_id ) && function_exists( 'get_the_ID' ) ) {
                        $post_id = get_the_ID();
                    }
                    if ($post_id && class_exists('SEO_Article_Generator\\Frontend\\Rating_System')) {
                        echo \SEO_Article_Generator\Frontend\Rating_System::render_rating_ui($post_id);
                    } else {
                        // Fallback to static stars if no ratings yet
                    ?><div class="seo-gen-hero__rating"><?php echo $this->render_rating_stars($rating); ?></div><?php
                                                                                                            }
                                                                                                                ?>

                    <!-- @MODIFIED 2026-01-06 v2.15.0: Post Views Component -->
                    <?php
                    if ($post_id && class_exists('SEO_Article_Generator\\Frontend\\Views_System')) {
                        echo \SEO_Article_Generator\Frontend\Views_System::render_views_ui($post_id);
                    }
                    ?>
                </div>

                <!-- CTA Column -->
                <?php if ($primary_link): ?>
                    <div class="seo-gen-hero__cta">
                        <?php
	// @MODIFIED 2026-01-02 v2.11.1: Show variant in primary CTA
	// @MODIFIED 2026-05-07: Normalize variant before display — raw variant
	// can contain duplicate tokens (e.g. "x64 Professional x64 Trial") that
	// format_download_text() deduplicates for alternate links but CTA bypassed.
	$primary_platform = isset($primary_link['platform']) ? $primary_link['platform'] : 'Windows';
	$primary_variant_raw = isset($primary_link['variant']) ? $primary_link['variant'] : '';
	$primary_variant = $primary_variant_raw !== '' ? \SEO_Article_Generator\Generator\Download_Link_Helper::normalize_variant_name($primary_variant_raw) : '';
	$primary_display = $primary_platform;
                        if (!empty($primary_variant) && $primary_variant !== 'Standard') {
                            $primary_display .= ' (' . $primary_variant . ')';
                        }
                        ?>
                        <a href="<?php echo esc_url($primary_link['url']); ?>" class="seo-gen-hero__btn seo-gen-hero__btn--primary"
                            rel="nofollow noopener" target="_blank">
                            <svg class="seo-gen-hero__btn-icon" viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
                                <path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z" />
                            </svg>
                            Get for <?php echo esc_html($primary_display); ?>
                        </a>

                        <?php if (!empty($alternate_links)): ?>
                            <!-- @MODIFIED 2026-01-30: Moved Also Download For to CTA column -->
                            <?php
                            $grouped_alts = \SEO_Article_Generator\Generator\Download_Link_Helper::group_links_by_platform($alternate_links);
                            ?>
                            <div class="seo-gen-hero__alt-downloads">
                                <details class="seo-gen-heroalt-details">
                                    <summary class="seo-gen-heroalt-summary">
                                        Also Download For
                                        <svg class="seo-gen-heroalt-chevron" viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
                                            <path d="M7 10l5 5 5-5z" />
                                        </svg>
                                    </summary>
                                    <div class="seo-gen-heroalt-content">
                                        <?php foreach ($grouped_alts as $platform => $links): ?>
                                            <div class="seo-gen-heroalt-group">
                                                <div class="seo-gen-heroalt-platform"><?php echo $this->get_platform_icon($platform); ?><strong><?php echo esc_html($platform); ?>:</strong></div>
				<ul class="seo-gen-heroalt-list"><?php foreach ($links as $alt_link): ?><?php
				// @MODIFIED 2026-04-24: SSOT preservation — prefer stored text from seogenherodata
				// over deterministic regeneration. Only regenerate when no stored text exists.
				$alt_existing_text = !empty($alt_link['text']) ? trim((string) $alt_link['text']) : '';
				$alt_text = \SEO_Article_Generator\Generator\Download_Link_Helper::format_download_text($alt_link, $software_name, $alt_existing_text);
				?><li class="seo-gen-heroalt-item"><a href="<?php echo esc_url($alt_link['url']); ?>" class="seo-gen-heroalt-link" rel="nofollow noopener" target="_blank"><?php echo esc_html($alt_text); ?></a></li><?php endforeach; ?></ul>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </details>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Specs Grid -->
            <!-- @MODIFIED 2025-12-16 v2.3.2: Reordered to VERSION, SIZE, UPDATED, LICENSE -->
            <div class="seo-gen-hero__specs">
                <?php if (!empty($platform_list) || !empty($min_os_text)): ?>
                    <div class="seo-gen-hero__spec">
                        <span class="seo-gen-hero__spec-label">Platform</span>
                        <span class="seo-gen-hero__spec-value">
                            <?php if (!empty($platform_list)): ?>
                                <div class="seo-gen-hero__platform-icons">
                                    <?php foreach ($platform_list as $plat): ?>
                                        <span class="seo-gen-hero__platform-icon" title="<?php echo esc_attr($plat); ?>">
                                            <?php echo $this->get_platform_icon($plat); ?>
                                        </span>
                                    <?php endforeach; ?>
                                </div>
                            <?php else: ?>
                                <?php echo $min_os_text; ?>
                            <?php endif; ?>
                        </span>
                    </div>
                <?php endif; ?>
                <?php if ($version): ?>
                    <div class="seo-gen-hero__spec">
                        <span class="seo-gen-hero__spec-label">Version</span>
                        <span class="seo-gen-hero__spec-value"><?php echo $version; ?></span>
                    </div>
                <?php endif; ?>
                <?php if ($file_size): ?>
                    <div class="seo-gen-hero__spec">
                        <span class="seo-gen-hero__spec-label">Size</span>
                        <span class="seo-gen-hero__spec-value"><?php echo $file_size; ?></span>
                    </div>
                <?php endif; ?>
                <?php if ($last_updated): ?>
                    <div class="seo-gen-hero__spec">
                        <span class="seo-gen-hero__spec-label">Updated</span>
                        <span class="seo-gen-hero__spec-value"><?php echo $last_updated; ?></span>
                    </div>
                <?php endif; ?>
                <?php if ($license): ?>
                    <div class="seo-gen-hero__spec">
                        <span class="seo-gen-hero__spec-label">License</span>
                        <span class="seo-gen-hero__spec-value"><?php echo $license; ?></span>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Footer: Alt Links + Trust -->
            <div class="seo-gen-hero__footer">
                <!-- @MODIFIED 2026-01-30: Moved alt links to CTA column above -->

                <!-- @since 2.6.1: Security badge always displays manual text -->
                <?php if ($security_badge): ?>
                    <div class="seo-gen-hero__trust-badge"><?php echo $security_badge; ?></div>
                <?php endif; ?>

                <?php if ($reviewer_name || $last_verified): ?>
                    <!-- @MODIFIED 2025-12-15 v2.2.0: E-E-A-T author attribution -->
                    <div class="seo-gen-hero__attribution">
                        <?php if ($reviewer_name): ?>
                            <span class="seo-gen-hero__author">Reviewed by <?php echo $reviewer_name; ?></span>
                        <?php endif; ?>
                        <?php
                        $verified_label = '';
                        if (!empty($last_verified)) {
                            $verified_ts = strtotime($last_verified);
                            if ($verified_ts) {
                                $verified_label = wp_date('M Y', $verified_ts);
                            }
                        }
                        ?>
                        <?php if ($verified_label): ?>
                            <span class="seo-gen-hero__verified">Verified: <?php echo esc_html($verified_label); ?></span>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>


            </div>
        </div>
<?php
        return ob_get_clean();
    }

    /**
     * Render fallback HTML when block is not registered
     *
     * @param array $data Hero data
     * @return string Fallback HTML
     */
    public function render_fallback($data)
    {
        $html = '<div class="seo-gen-hero-fallback">';
        $html .= $this->render($data);
        $html .= '</div>';
        return $html;
    }

    /**
     * Render rating stars
     *
     * @param float $rating Rating value (0-5)
     * @return string HTML for stars
     */
    private function render_rating_stars($rating)
    {
        if ($rating <= 0) {
            return '';
        }

        $full_stars = floor($rating);
        $half_star = ($rating - $full_stars) >= 0.5;
        $empty_stars = 5 - $full_stars - ($half_star ? 1 : 0);

        $html = '<span class="seo-gen-hero__stars">';

        // Full stars
        for ($i = 0; $i < $full_stars; $i++) {
            $html .= '<span class="seo-gen-hero__star seo-gen-hero__star--full">★</span>';
        }

        // Half star
        if ($half_star) {
            $html .= '<span class="seo-gen-hero__star seo-gen-hero__star--half">★</span>';
        }

        // Empty stars
        for ($i = 0; $i < $empty_stars; $i++) {
            $html .= '<span class="seo-gen-hero__star seo-gen-hero__star--empty">☆</span>';
        }

        $html .= ' <span class="seo-gen-hero__rating-value">' . number_format($rating, 1) . '</span>';
        $html .= '</span>';

        return $html;
    }

    /**
     * Generate initials from software name for fallback logo
     * @MODIFIED 2025-12-14 v2.1.0: New method for App Store style
     *
     * @param string $name Software name
     * @return string 1-2 character initials
     */
    private function generate_initials($name)
    {
        $words = preg_split('/\s+/', trim($name));

        if (count($words) >= 2) {
            // Use first letter of first two words
            return strtoupper(substr($words[0], 0, 1) . substr($words[1], 0, 1));
        }

        // Single word: use first two letters
        return strtoupper(substr($name, 0, 2));
    }

    /**
     * Get SVG icon for platform
     * @since 2.7.4
     *
     * @param string $platform Platform name
     * @return string SVG icon HTML
     */
    private function get_platform_icon($platform)
    {
        $platform_lower = strtolower((string)$platform);

        // Windows icon
        if (strpos($platform_lower, 'windows') !== false || strpos($platform_lower, 'win32') !== false || strpos($platform_lower, 'win64') !== false || preg_match('/\bwin\b/', $platform_lower)) {
            return '<svg class="seo-gen-platform-svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24"><path d="M0 3.449L9.75 2.1v9.451H0zm10.949-1.45L24 0v11.4H10.949zM0 12.6h9.75v9.451L0 20.699zM10.949 12.6H24V24l-12.9-1.801z"/></svg>';
        }

        // iOS / iPhone / iPad icon (check before macOS)
        if (strpos($platform_lower, 'ios') !== false || strpos($platform_lower, 'iphone') !== false || strpos($platform_lower, 'ipad') !== false) {
            return '<svg class="seo-gen-platform-svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24"><path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/></svg>';
        }

        // macOS / Apple icon
        if (strpos($platform_lower, 'mac') !== false || strpos($platform_lower, 'apple') !== false || strpos($platform_lower, 'osx') !== false || strpos($platform_lower, 'darwin') !== false) {
            return '<svg class="seo-gen-platform-svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24"><path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/></svg>';
        }

        // Android icon
        if (strpos($platform_lower, 'android') !== false || strpos($platform_lower, 'apk') !== false) {
            return '<svg class="seo-gen-platform-svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24"><path d="M17.6 9.48l1.84-3.18c.16-.31.04-.69-.26-.85-.29-.15-.65-.06-.83.22l-1.88 3.24a11.463 11.463 0 00-8.94 0L5.65 5.67c-.19-.29-.58-.38-.87-.2-.28.18-.37.54-.22.83L6.4 9.48A10.78 10.78 0 003 18h18a10.78 10.78 0 00-3.4-8.52zM7 15.25a1.25 1.25 0 110-2.5 1.25 1.25 0 010 2.5zm10 0a1.25 1.25 0 110-2.5 1.25 1.25 0 010 2.5z"/></svg>';
        }

        // Chrome OS / Chromebook icon
        if (strpos($platform_lower, 'chrome') !== false || strpos($platform_lower, 'chromebook') !== false || strpos($platform_lower, 'chromeos') !== false) {
            return '<svg class="seo-gen-platform-svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.42 0-8-3.58-8-8 0-1.85.63-3.55 1.69-4.9L12 12v6c0 1.1-.9 2-2 2zm6.31-3.1L12 12l5.69-9.9C19.37 3.55 20 5.25 20 7.1c0 4.42-3.58 8-8 8 0 1.1.9 2 2 2z"/></svg>';
        }

        // Linux icon (generic Tux for all distros)
        if (strpos($platform_lower, 'linux') !== false || strpos($platform_lower, 'ubuntu') !== false || strpos($platform_lower, 'debian') !== false || strpos($platform_lower, 'centos') !== false || strpos($platform_lower, 'fedora') !== false || strpos($platform_lower, 'arch') !== false || strpos($platform_lower, 'mint') !== false || strpos($platform_lower, 'redhat') !== false || strpos($platform_lower, 'suse') !== false || strpos($platform_lower, 'manjaro') !== false) {
            return '<svg class="seo-gen-platform-svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24"><path d="M12.504 0c-.155 0-.315.008-.48.021-4.226.333-3.105 4.807-3.17 6.298-.076 1.092-.3 1.953-1.05 3.02-.885 1.051-2.127 2.75-2.716 4.521-.278.832-.41 1.684-.287 2.489a.424.424 0 00-.11.135c-.26.268-.45.6-.663.839-.199.199-.485.267-.797.4-.313.136-.658.269-.864.68-.09.189-.136.394-.132.602 0 .199.027.4.055.536.058.399.116.728.04.97-.249.68-.28 1.145-.106 1.484.174.334.535.47.94.601.81.2 1.91.135 2.774.6.926.466 1.866.67 2.616.47.526-.116.97-.464 1.208-.946.587-.003 1.23-.269 2.26-.334.699-.058 1.574.267 2.577.2.025.134.063.198.114.333l.003.003c.391.778 1.113 1.132 1.884 1.071.771-.06 1.592-.536 2.257-1.306.631-.765 1.683-1.084 2.378-1.503.348-.199.629-.469.649-.853.023-.4-.2-.811-.714-1.376v-.097l-.003-.003c-.17-.2-.25-.535-.338-.926-.085-.401-.182-.786-.492-1.046h-.003c-.059-.054-.123-.067-.188-.135a.357.357 0 00-.19-.064c.431-1.278.264-2.55-.173-3.694-.533-1.41-1.465-2.638-2.175-3.483-.796-1.005-1.576-1.957-1.56-3.368.026-2.152.236-6.133-3.544-6.139z"/></svg>';
        }

        // FreeBSD icon
        if (strpos($platform_lower, 'freebsd') !== false || strpos($platform_lower, 'bsd') !== false) {
            return '<svg class="seo-gen-platform-svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/></svg>';
        }

        // Portable / ZIP / Archive icon
        if (strpos($platform_lower, 'portable') !== false || strpos($platform_lower, 'zip') !== false || strpos($platform_lower, 'archive') !== false || strpos($platform_lower, 'tar') !== false || strpos($platform_lower, '7z') !== false) {
            return '<svg class="seo-gen-platform-svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24"><path d="M20 6h-8l-2-2H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-6 10H6v-2h8v2zm4-4H6v-2h12v2z"/></svg>';
        }

        // Web / Online / Browser icon
        if (strpos($platform_lower, 'web') !== false || strpos($platform_lower, 'online') !== false || strpos($platform_lower, 'browser') !== false) {
            return '<svg class="seo-gen-platform-svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/></svg>';
        }

        // Generic download icon fallback
        return '<svg class="seo-gen-platform-svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24"><path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/></svg>';
    }

    /**
     * Get list of detected platforms from raw string AND download links
     * @since 2.8.0
     * @param string $raw Raw platform text (min_os)
     * @param array $links Download links array
     * @return array List of platform names
     */
    private function get_platform_list($raw, $links = [])
    {
        $platforms = [];
        $raw_lower = strtolower((string)$raw);

        // Priority map for matching
        $map = [
            'windows' => 'Windows',
            'mac'     => 'macOS',
            'apple'   => 'macOS',
            'osx'     => 'macOS',
            'linux'   => 'Linux',
            'ubuntu'  => 'Linux',
            'android' => 'Android',
            'apk'     => 'Android',
            'ios'     => 'iOS',
            'iphone'  => 'iOS',
            'ipad'    => 'iOS'
        ];

        // 1. If we have links, derive platforms PRIMARILY from links
        // This ensures the icons match what the user can actually download
        if (!empty($links) && is_array($links)) {
            foreach ($links as $link) {
                if (empty($link['platform'])) continue;
                $plat_lower = strtolower($link['platform']);
                foreach ($map as $key => $label) {
                    if (strpos($plat_lower, $key) !== false) {
                        if (!in_array($label, $platforms)) {
                            $platforms[] = $label;
                        }
                    }
                }
            }
        }

        // 2. If no links or empty platforms derived from links, fallback to raw string
        if (empty($platforms) && !empty($raw)) {
            foreach ($map as $key => $label) {
                if (strpos($raw_lower, $key) !== false) {
                    if (!in_array($label, $platforms)) {
                        $platforms[] = $label;
                    }
                }
            }
        }

        // 3. SECURE FIX: Both macOS and iOS use the Apple icon. 
        // Showing both [Apple] [Apple] is confusing. 
        // We will deduplicate based on the icon they produce.
        $final_platforms = [];
        $seen_icons = [];

        foreach ($platforms as $plat) {
            $icon = $this->get_platform_icon($plat);
            // Ignore the generic fallback icon for deduplication purposes
            if (strpos($icon, '<svg') !== false) {
                if (!in_array($icon, $seen_icons)) {
                    $seen_icons[] = $icon;
                    $final_platforms[] = $plat;
                }
            } else {
                $final_platforms[] = $plat;
            }
        }

        return $final_platforms;
    }
}
