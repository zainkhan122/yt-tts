<?php
namespace SEO_Article_Generator\Queue\Jobs;

use SEO_Article_Generator\Queue\Abstract_Job;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Process_Draft_Job extends Abstract_Job {

	private const LOCK_TTL = 600;

	public function handle() {
		$draft_id = (int) $this->reference_id;

		if ( ! $this->lock_draft( $draft_id ) ) {
			return true;
		}

		try {
			$heartbeat = function (): void {
				$this->renew_lock();
			};

			/**
			 * Hand off to the real processor.
			 * Replace with your concrete service class if it already exists.
			 */
			do_action( 'seo_gen_process_draft_job', $draft_id, $heartbeat, $this );

			return true;
		} finally {
			$this->unlock_draft( $draft_id );
		}
	}

	private function get_worker_id(): string {
		static $worker_id = null;

		if ( null === $worker_id ) {
			$pid       = function_exists( 'getmypid' ) ? (string) getmypid() : '0';
			$worker_id = $pid . '_' . bin2hex( random_bytes( 4 ) );
		}

		return $worker_id;
	}

	private function lock_draft( int $draft_id ): bool {
		$key      = 'seo_gen_draft_lock_' . $draft_id;
		$workerId = $this->get_worker_id();
		$value    = $workerId . '|' . time();

		if ( add_option( $key, $value, '', false ) ) {
			return true;
		}

		$existing = get_option( $key );
		if ( ! is_string( $existing ) || '' === $existing ) {
			return false;
		}

		$parts = explode( '|', $existing );
		$ts    = isset( $parts[1] ) ? (int) $parts[1] : 0;

		if ( ( time() - $ts ) > self::LOCK_TTL ) {
			delete_option( $key );
			return add_option( $key, $value, '', false );
		}

		return false;
	}

	protected function renew_lock(): void {
		$draft_id = (int) $this->reference_id;
		$key      = 'seo_gen_draft_lock_' . $draft_id;
		$workerId = $this->get_worker_id();
		$value    = $workerId . '|' . time();
		$existing = get_option( $key );

		if ( is_string( $existing ) && 0 === strpos( $existing, $workerId . '|' ) ) {
			update_option( $key, $value, false );
		}
	}

	private function unlock_draft( int $draft_id ): void {
		$key      = 'seo_gen_draft_lock_' . $draft_id;
		$workerId = $this->get_worker_id();
		$existing = get_option( $key );

		if ( is_string( $existing ) && 0 === strpos( $existing, $workerId . '|' ) ) {
			delete_option( $key );
		}
	}
}
