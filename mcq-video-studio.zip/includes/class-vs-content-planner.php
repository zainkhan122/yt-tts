<?php

/**
 * Content Planner
 *
 * Handles 30-day topic planning and batched question generation via Gemini.
 *
 * @package    MCQ_Video_Studio
 * @subpackage Includes
 * @since      2.0.0
 */

if (! defined('ABSPATH')) {
    exit;
}

if (!class_exists('VS_Job_Repository')) {
    require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-job-repository.php';
}

if (!class_exists('VS_Job_Status')) {
    require_once MCQVS_PLUGIN_DIR . 'includes/class-vs-schema.php';
}

class VS_Content_Planner
{
    private static $instance = null;
    private $ai_quiz_handler;

    public static function get_instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function __construct()
    {
        // @NEW 2026-02-19: Action Scheduler Integration for background batch processing
        add_action('mcqvs_process_topic_batch', array($this, 'handle_topic_batch_background'), 10, 4);

        // @NEW 2026-02-19: Manual Queue Maintenance
        add_action('wp_ajax_mcqvs_clear_stuck_jobs', array($this, 'ajax_clear_stuck_jobs'));
        // @NEW 2026-02-23: Clear ALL jobs (not just stuck)
        add_action('wp_ajax_mcqvs_clear_all_jobs', array($this, 'ajax_clear_all_jobs'));
        add_action('wp_ajax_mcqvs_run_worker', array($this, 'ajax_run_worker'));
        // @NEW 2026-08-07: Manual recovery of auto-cleaned failed jobs
        add_action('wp_ajax_mcqvs_recover_failed_jobs', array($this, 'ajax_recover_failed_jobs'));
        
        // @NEW 2026-07-06: Pipeline verification audit
        add_action('wp_ajax_mcqvs_audit_pipeline', array($this, 'ajax_audit_pipeline'));

        // @NEW 2026-07-10: Saved-Question-Bank discovery (Content Planner parity with Studio Data Source Card)
        add_action('wp_ajax_mcqvs_planner_get_bank_topics', array($this, 'ajax_planner_get_bank_topics'));
        add_action('wp_ajax_mcqvs_planner_get_topic_questions', array($this, 'ajax_planner_get_topic_questions'));
        add_action('wp_ajax_mcqvs_planner_compose_video', array($this, 'ajax_planner_compose_video'));

        // @FIX: Delayed batch tracker cleanup hook
        add_action('mcqvs_cleanup_batch_tracker', array($this, 'handle_cleanup_batch_tracker'));

        // @NEW 2026-07-26: Calendar Content Scheduler
        add_action('wp_ajax_mcqvs_planner_get_calendar_data', array($this, 'ajax_get_calendar_data'));
        add_action('wp_ajax_mcqvs_planner_save_calendar_assignments', array($this, 'ajax_save_calendar_assignments'));
        add_action('wp_ajax_mcqvs_planner_auto_assign_calendar', array($this, 'ajax_auto_assign_calendar'));

        // @NEW 2026-07-30: Excel/CSV File Import
        add_action('wp_ajax_mcqvs_preview_excel_import', array($this, 'ajax_preview_excel_import'));
        add_action('wp_ajax_mcqvs_import_topics_from_excel', array($this, 'ajax_import_topics_from_excel'));
        // @FIX 1.4.9.49: Persist the planner sidebar toggles (hook visible, cover)
        // so they survive page reloads — they previously reset to checked every load.
        add_action('wp_ajax_mcqvs_planner_save_toggles', array($this, 'ajax_planner_save_toggles'));

        // @NEW 2026-07-30: Cancel/clear pending AI generation batches
        add_action('wp_ajax_mcqvs_cancel_pending_batches', array($this, 'ajax_cancel_pending_batches'));

        // @NEW 2026-08-03: MCQ Editor - Get/Update job questions
        add_action('wp_ajax_mcqvs_get_job_questions', array($this, 'ajax_get_job_questions'));
        add_action('wp_ajax_mcqvs_update_job_questions', array($this, 'ajax_update_job_questions'));

        // @NEW 2026-08-03: Retry failed topics from batch
        add_action('wp_ajax_mcqvs_retry_failed_topics', array($this, 'ajax_retry_failed_topics'));

        // @NEW 2026-08-17: Delete calendar assignment (and optionally job)
        add_action('wp_ajax_mcqvs_planner_delete_calendar_assignment', array($this, 'ajax_delete_calendar_assignment'));
    }

    /**
     * AJAX: Generate 30-Day Topic Plan
     */
    public function ajax_generate_topic_plan()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        $niche_input = sanitize_text_field($_POST['niche'] ?? 'General Knowledge');
        // @NEW 2026-02-19: Custom video count per niche
        $video_count = isset($_POST['video_count']) ? absint($_POST['video_count']) : 30;

        // @NEW 2026-02-16: Support multiple comma-separated niches
        $niches = array_map('trim', explode(',', $niche_input));
        $niche_str = implode(', ', $niches);

        // Prepare Prompt
        // @MODIFIED 2026-02-23: Enforce ≤5 word titles + per-niche even distribution (Fix 1+5)
        $niche_count = count($niches);
        $per_niche = max(1, (int) ceil($video_count / $niche_count));
        $prompt = "Generate EXACTLY {$per_niche} high-engagement quiz video topic TITLES for EACH of these niches: {$niche_str}.\n";
        $prompt .= "RULES:\n";
        $prompt .= "- Each title MUST be 5 words or fewer\n";
        $prompt .= "- Distribute topics EVENLY across all niches\n";
        $prompt .= "- Make titles catchy hooks, not full sentences\n";
        $prompt .= "Return ONLY a raw JSON array of strings. No markdown. Example: [\"Topic 1\", \"Topic 2\"]";

        try {
            // @MODIFIED 2026-02-18: Independent API Key & Model Logic
            $api_key = get_option('mcqvs_gemini_api_key', '');
            $model   = get_option('mcqvs_gemini_model_id', 'gemini-3-flash-preview');

            // Fallback to Parent Plugin if local key missing
            if (empty($api_key) && class_exists('NM_API_Client')) {
                $api_key = NM_API_Client::get_gemini_api_key();
            }

            if (empty($api_key)) {
                throw new Exception('Gemini API Key missing. Please check Video Studio > Settings.');
            }

            // Centralized URL construction pattern from proven handler
            $url = 'https://generativelanguage.googleapis.com/v1beta/models/' . $model . ':generateContent?key=' . $api_key;

            $start_time = microtime(true);
            $response = wp_remote_post(
                $url,
                array(
                    'headers' => array('Content-Type' => 'application/json'),
                    'body'    => json_encode(array(
                        'contents' => array(
                            array('parts' => array(array('text' => $prompt)))
                        )
                    )),
                    'timeout' => 30
                )
            );
            $duration = microtime(true) - $start_time;

            // @NEW 2026-02-16: Central API Logging (Architecture match)
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log_api($url, 'POST', array('prompt' => $prompt), $response, $duration);
            }

            if (is_wp_error($response)) {
                throw new Exception($response->get_error_message());
            }

            $http_code = wp_remote_retrieve_response_code($response);
            if ($http_code >= 400) {
                $body = wp_remote_retrieve_body($response);
                $data = json_decode($body, true);
                $error_msg = $data['error']['message'] ?? $data['message'] ?? "Gemini API HTTP Error: {$http_code}";
                throw new Exception($error_msg);
            }

            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);

            if (isset($data['error'])) {
                throw new Exception($data['error']['message'] ?? 'Gemini API Error');
            }

            if (!isset($data['candidates'][0]['content']['parts'][0]['text'])) {
                $finish_reason = $data['candidates'][0]['finishReason'] ?? 'unknown';
                throw new Exception("Gemini API returned no content. Finish reason: {$finish_reason}");
            }

            $raw_text = $data['candidates'][0]['content']['parts'][0]['text'];

            // Robust cleaning via existing patterns
            $raw_text = trim(preg_replace('/```(json)?/', '', $raw_text));
            $topics = json_decode($raw_text, true);

            if (!is_array($topics)) {
                throw new Exception('Failed to parse AI response. Raw: ' . substr($raw_text, 0, 100));
            }

            // Enforce requested count deterministically (AI may over-generate)
            $topics = array_values(array_filter($topics, fn($t) => is_string($t) && trim($t) !== ''));
            $desired_total = max(1, (int) $video_count);
            if (count($topics) > $desired_total) {
                $topics = array_slice($topics, 0, $desired_total);
            }

            // Save to option for review
            update_option('mcqvs_content_plan', $topics);

            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log_pipeline(
                    'topic.generated',
                    'completed',
                    'topic-plan',
                    'Topic generation complete: ' . count($topics) . ' topics for niches: ' . $niche_str,
                    'info',
                    array('topics' => $topics, 'niches' => $niches, 'video_count' => $video_count, 'per_niche' => $per_niche)
                );
            }

            wp_send_json_success(array('topics' => $topics));
        } catch (Exception $e) {
            wp_send_json_error(array('message' => $e->getMessage()));
        }
    }

    /**
     * AJAX: Save/Update Topic Plan (User edits)
     */
    public function ajax_save_topic_plan()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        $raw_topics = stripslashes($_POST['topics'] ?? '');
        $topics = !empty($raw_topics) ? json_decode($raw_topics, true) : [];

        if (!is_array($topics)) {
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log('ajax_save_topic_plan Failed: JSON decode resulted in non-array.', 'error', array('raw_topics' => substr($raw_topics, 0, 500), 'json_error' => json_last_error_msg()));
            }
            wp_send_json_error('Invalid topics format');
        }

        // Sanitize (support both old string array and new object array)
        $safe_topics = array();
        foreach ($topics as $topic) {
            if (is_array($topic)) {
                $safe_topic = array(
                    'topic'    => sanitize_text_field($topic['topic'] ?? ''),
                    'template' => sanitize_text_field($topic['template'] ?? ''),
                    'font'     => sanitize_text_field($topic['font'] ?? ''),
                    'music'    => sanitize_text_field($topic['music'] ?? '')
                );
                // @NEW 2026-07-26: Persist calendar scheduling fields
                if (!empty($topic['publish_date'])) {
                    $safe_topic['publish_date'] = sanitize_text_field($topic['publish_date']);
                }
                if (!empty($topic['publish_time'])) {
                    $safe_topic['publish_time'] = sanitize_text_field($topic['publish_time']);
                }
                if (!empty($topic['bg_video'])) {
                    $safe_topic['bg_video'] = sanitize_text_field($topic['bg_video']);
                }
                // @NEW 2026-08-05: Preserve CSV-imported metadata across user save round-trips.
                // Without this, the next batch run would re-call Gemini and lose the user's
                // explicit answers + schedule. Fields are stored as-is (already sanitized at
                // parse time) and re-validated downstream by VS_Validation_Service.
                // @FIX 2026-08-17: Also preserve bank-composed fields (_bank_composed, _job_id)
                // so unassigned-topic delete doesn't break calendar chip delete for bank topics.
                foreach (array('niche', 'difficulty', 'platform', 'videos_per_topic', 'questions_per_video',
                               'save_mode', 'brandName', 'quizName', 'logoPath', 'logoPosition',
                               'hookText', 'hashtags', 'publish_frequency', 'frequency',
                               '_bank_composed', '_job_id', '_publish_day_offset', '_publish_start_date', '_publish_offset') as $passthrough) {
                    if (isset($topic[$passthrough]) && $topic[$passthrough] !== '') {
                        $safe_topic[$passthrough] = $topic[$passthrough];
                    }
                }
                if (isset($topic['hookVisible'])) {
                    $safe_topic['hookVisible'] = (bool) $topic['hookVisible'];
                }
                foreach (array('buffer_channels', '_inline_questions', 'voiceover') as $arr_field) {
                    if (isset($topic[$arr_field]) && is_array($topic[$arr_field])) {
                        $safe_topic[$arr_field] = $topic[$arr_field];
                    }
                }
                if (!empty($topic['_calendar_assigned'])) {
                    $safe_topic['_calendar_assigned'] = true;
                }
                // Remove empty overrides
                foreach ($safe_topic as $key => $val) {
                    if ($key !== 'topic' && $val === '') {
                        unset($safe_topic[$key]);
                    }
                }
                // If only 'topic' is left, save as flat string for efficiency/backward compat
                $safe_topics[] = (count($safe_topic) === 1 && isset($safe_topic['topic'])) ? $safe_topic['topic'] : $safe_topic;
            } else {
                $safe_topics[] = sanitize_text_field($topic);
            }
        }

        update_option('mcqvs_content_plan', $safe_topics);

        // @NEW 2026-08-03: Sync calendar assignments with topic plan
        // Update calendar data to match topic plan date/time assignments
        $this->sync_calendar_with_plan($safe_topics);

        wp_send_json_success();
    }

    /**
     * Sync calendar assignments with topic plan.
     * Called after saving topic plan to keep calendar in sync.
     */
    private function sync_calendar_with_plan($topics)
    {
        $calendar_data = get_option('mcqvs_calendar_assignments', array());
        if (!is_array($calendar_data)) {
            $calendar_data = array();
        }

        foreach ($topics as $index => $topic) {
            if (is_array($topic) && !empty($topic['publish_date'])) {
                $calendar_data[$index] = array(
                    'index'         => $index,
                    'topic'         => is_array($topic) ? ($topic['topic'] ?? '') : $topic,
                    'publish_date'  => $topic['publish_date'] ?? '',
                    'publish_time'  => $topic['publish_time'] ?? '09:00',
                );
            }
        }

        update_option('mcqvs_calendar_assignments', $calendar_data);
    }

    /**
     * Helper: Scan Assets (Fonts, Music) & Templates
     */
    private function get_available_assets()
    {
        $data = array(
            'templates' => array(
                // @MODIFIED 2026-02-19: Synced with assets/js/vs-video-templates.js
                'corporate'   => 'Corporate',
                'elegant'     => 'Elegant',
                'neon'        => 'Neon Nights',
                'fire'        => 'Fire & Heat',
                'electric'    => 'Electric Blue',
                'horror'      => 'Horror',
                'space'       => 'Space Odyssey',
                'nature'      => 'Nature',
                'retro80s'    => 'Retro 80s',
                'cyberpunk'   => 'Cyberpunk',
                'classroom'   => 'Classroom',
                'science'     => 'Science Lab',
                'history'     => 'History',
                'tech'        => 'Tech Mastery',
                'sports'      => 'Sports Arena',
                'trivia'      => 'General Trivia'
            ),
            'fonts' => array(),
            'music' => array()
        );

        // Scan Fonts
        $font_dir = mcqvs_assets_dir( 'fonts/' );
        if (is_dir($font_dir)) {
            $files = glob($font_dir . '*.ttf');
            foreach ($files as $f) {
                $name = basename($f, '.ttf');
                // Cleanup name (e.g. "Roboto-Bold" -> "Roboto Bold")
                $clean_name = str_replace(array('-', '_', 'Regular', 'Bold'), array(' ', ' ', '', ''), $name);
                $data['fonts'][$name] = trim($clean_name);
            }
        }

        // Scan Music
        $music_dir = mcqvs_assets_dir( 'audio/music/' );
        if (is_dir($music_dir)) {
            $files = glob($music_dir . '*.mp3');
            foreach ($files as $f) {
                $name = basename($f, '.mp3');
                $clean_name = ucwords(str_replace(array('-', '_'), ' ', $name));
                // URL for preview? For now just ID/Name
                $data['music'][$name] = $clean_name;
            }
        }

        return $data;
    }

    /**
     * Approve Plan & Generate Questions (Batched)
     */
    public function ajax_approve_topic_plan()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        // @FIX 1.4.9.53 (global STOP): reject new AI generation while stopped.
        if (function_exists('mcqvs_is_global_stopped') && mcqvs_is_global_stopped()) {
            wp_send_json_error('Pipeline is STOPPED. Click "Resume" on the Dashboard before starting AI generation.');
        }

        // Extend timeout for heavy batch operations
        if (function_exists('set_time_limit')) {
            set_time_limit(300);
        }

        // Get approved topics
        $topics = get_option('mcqvs_content_plan', []);
        if (empty($topics) || !is_array($topics)) {
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log('ajax_approve_topic_plan Failed: mcqvs_content_plan is empty or invalid type.', 'error', array('retrieved_value' => is_scalar($topics) ? $topics : gettype($topics)));
            }
            wp_send_json_error('No topics in plan. Please generate topics first. (Ensure you clicked Save first).');
        }

        // @MODIFIED 2026-07-30: Only process topics with an assigned calendar publish_date
        // @FIX 2026-08-05: CSV-imported topics may carry authoritative _inline_questions[]
        // without an explicit publish_date — those must NOT be dropped here. The batch
        // worker's compute_publish_at() linear-fallback path picks up _publish_day_offset.
        // @FIX 2026-08-17: Exclude _bank_composed topics — job already created via
        // Saved Questions Bank compose; they appear in calendar as draggable chips
        // but should not be re-processed by AI batch.
        $topics = array_values(array_filter($topics, function ($t) {
            if (!is_array($t)) return false;
            if (!empty($t['_bank_composed'])) return false; // Already has job
            if (!empty($t['publish_date'])) return true;
            if (!empty($t['_inline_questions']) && is_array($t['_inline_questions'])) return true;
            if (isset($t['_publish_day_offset'])) return true;
            return false;
        }));
        if (empty($topics)) {
            wp_send_json_error('No topics have calendar dates assigned. Use the Calendar to assign dates first.');
        }

        // @MODIFIED 2026-04-22: Configurable batch size from settings (default 10, was hardcoded 5)
        $ai_batch_size = absint(get_option('mcqvs_ai_batch_size', 10));
        if ($ai_batch_size < 3) $ai_batch_size = 10;
        $chunks = array_chunk($topics, $ai_batch_size);
        $total_batches = count($chunks);

        if (class_exists('VS_Error_Logger')) {
            VS_Error_Logger::get_instance()->log('Approve & Schedule: Chunking ' . count($topics) . ' topics for background processing.', 'info', array('source' => 'Content Planner'));
            VS_Error_Logger::get_instance()->log_pipeline(
                'planner.styles',
                'completed',
                'topic-plan',
                'Style config: template=' . sanitize_text_field($_POST['style_template'] ?? 'default') . ', font=' . sanitize_text_field($_POST['style_font'] ?? 'default') . ', music=' . sanitize_text_field($_POST['style_music'] ?? 'default') . ', bg_video=' . sanitize_text_field($_POST['style_bg_video'] ?? 'default') . ', save_mode=' . sanitize_text_field($_POST['save_mode'] ?? 'local'),
                'info',
                array(
                    'template'           => sanitize_text_field($_POST['style_template'] ?? ''),
                    'font'               => sanitize_text_field($_POST['style_font'] ?? ''),
                    'music'              => sanitize_text_field($_POST['style_music'] ?? ''),
                    'bg_video'           => sanitize_text_field($_POST['style_bg_video'] ?? ''),
                    'save_mode'          => sanitize_text_field($_POST['save_mode'] ?? 'local'),
                    'questions_count'    => isset($_POST['questions_count']) ? absint($_POST['questions_count']) : 5,
                    'videos_per_topic'   => isset($_POST['videos_per_topic']) ? absint($_POST['videos_per_topic']) : 1,
                    'publish_start_date' => sanitize_text_field($_POST['publish_start_date'] ?? ''),
                    'publish_time'       => sanitize_text_field($_POST['publish_time'] ?? '09:00'),
                    'publish_frequency'  => sanitize_text_field($_POST['publish_frequency'] ?? 'daily'),
                    'buffer_channels'    => stripslashes($_POST['buffer_channels'] ?? '[]'),
                    'total_topics'       => count($topics),
                    'total_batches'      => $total_batches,
                )
            );
        }
        
        // Extract styles once for reuse in AS actions and fallback
        $styles = array(
            'template' => sanitize_text_field($_POST['style_template'] ?? ''),
            'font' => sanitize_text_field($_POST['style_font'] ?? ''),
            'music' => sanitize_text_field($_POST['style_music'] ?? ''),
            'bg_video' => sanitize_text_field($_POST['style_bg_video'] ?? ''),
            'hookVisible' => isset($_POST['hook_visible']) ? sanitize_text_field($_POST['hook_visible']) !== '0' : true,
            'hookText' => sanitize_text_field($_POST['style_hook_text'] ?? ''),
            'save_mode' => sanitize_text_field($_POST['save_mode'] ?? 'local'),
            // @FIX: Store video format per-job so headless renderer uses it instead of global option.
            //       Content Planner defaults to 'shorts' (portrait) — user can override via sidebar.
            'video_format' => sanitize_text_field($_POST['style_video_format'] ?? 'shorts'),
            // @FIX 1.4.9.48: Cover Page toggle (parity with CSV import + Studio).
            'cover_config' => array('enabled' => !isset($_POST['cover_enabled']) || sanitize_text_field($_POST['cover_enabled']) !== '0'),
            'videos_per_topic' => isset($_POST['videos_per_topic']) ? absint($_POST['videos_per_topic']) : 1,
            'questions_count' => isset($_POST['questions_count']) ? absint($_POST['questions_count']) : 5,
            'publish_start_date' => sanitize_text_field($_POST['publish_start_date'] ?? ''),
            'publish_time' => sanitize_text_field($_POST['publish_time'] ?? '09:00'),
            'publish_frequency' => sanitize_text_field($_POST['publish_frequency'] ?? 'daily'),
            'buffer_channels' => stripslashes($_POST['buffer_channels'] ?? '[]'),
        );

        $queued = 0;

        foreach ($chunks as $index => $chunk) {
            // Enqueue background processing for each chunk
            if (function_exists('as_enqueue_async_action')) {
                // Action Scheduler passes array elements as individual arguments to the callback
                as_enqueue_async_action('mcqvs_process_topic_batch', array(
                    $chunk,
                    $index + 1,
                    $total_batches,
                    $styles
                ), 'mcqvs_planner');
                $queued++;
            } else {
                // Fallback: Synchronous processing (not recommended for large lists)
                $this->process_topic_batch_internal($chunk, $styles);
                $queued++;
            }
        }

        // @FIX: The headless render queue binds to `parent_batch_id` (a 36-char UUID)
        //       stored in `mcqvs_content_plan_pending_batches`. Previously this option
        //       was written as the *integer batch count*, which forced every first job
        //       creation to mint a fresh UUID and orphaned prior jobs. Reuse the
        //       existing active batch UUID when one is set (so re-submits extend the
        //       same batch instead of orphaning prior jobs); otherwise mint a fresh one.
        $batch_uuid = get_option('mcqvs_content_plan_pending_batches', '');
        if (!is_string($batch_uuid) || strlen($batch_uuid) !== 36) {
            $batch_uuid = function_exists('wp_generate_uuid4') ? wp_generate_uuid4() : sprintf(
                '%08x-%04x-%04x-%04x-%012x',
                wp_rand(0, 0xffffffff),
                wp_rand(0, 0xffff),
                wp_rand(0, 0xffff),
                wp_rand(0, 0xffff),
                wp_rand(0, 0xffffffffffff)
            );
            update_option('mcqvs_content_plan_pending_batches', $batch_uuid);
        }
        // Initialize batch tracker so UI can show progress immediately
        $tracker = array();
        // Store the active batch UUID so the queue's stale-batch check can validate it.
        $tracker['_batch_id'] = $batch_uuid;
        // @FIX: match DB datetime columns which are stored in UTC (see VS_Job_Repository).
        $utc_now = gmdate('Y-m-d H:i:s');
        for ($i = 0; $i < $total_batches; $i++) {
            $tracker[$i + 1] = array(
                'status' => 'pending',
                'topics' => count($chunks[$i]),
                'time'   => $utc_now,
            );
        }
        update_option('mcqvs_batch_tracker', $tracker);

        wp_send_json_success(array(
            'message' => "Queued {$queued} batches ({$total_batches} total). Jobs will appear in the queue shortly.",
            'count' => count($topics)
        ));
    }

    /**
     * Internal: Approve topic plan and queue batches (no AJAX checks).
     * Used by CSV import auto-approval.
     *
     * @since 2026-08-06
     * @param array $topics Topics to approve
     * @param array $styles Style/settings for batch processing
     */
    private function approve_topic_plan_internal($topics, $styles)
    {
        // @FIX 1.4.9.53 (global STOP): don't enqueue new AI batches while stopped.
        if (function_exists('mcqvs_is_global_stopped') && mcqvs_is_global_stopped()) {
            return;
        }
        if (empty($topics) || !is_array($topics)) {
            return;
        }

        // Filter for calendar-assigned topics (same logic as AJAX version)
        $topics = array_values(array_filter($topics, function ($t) {
            if (!is_array($t)) return false;
            if (!empty($t['publish_date'])) return true;
            if (!empty($t['_inline_questions']) && is_array($t['_inline_questions'])) return true;
            if (isset($t['_publish_day_offset'])) return true;
            return false;
        }));
        if (empty($topics)) {
            return;
        }

        // Configurable batch size
        $ai_batch_size = absint(get_option('mcqvs_ai_batch_size', 10));
        if ($ai_batch_size < 3) $ai_batch_size = 10;
        $chunks = array_chunk($topics, $ai_batch_size);
        $total_batches = count($chunks);

        if (class_exists('VS_Error_Logger')) {
            VS_Error_Logger::get_instance()->log('Auto-Approve: Chunking ' . count($topics) . ' topics for background processing.', 'info', array('source' => 'Content Planner CSV Import'));
        }

        // Generate/reuse batch UUID
        $batch_uuid = get_option('mcqvs_content_plan_pending_batches', '');
        if (!is_string($batch_uuid) || strlen($batch_uuid) !== 36) {
            $batch_uuid = function_exists('wp_generate_uuid4') ? wp_generate_uuid4() : sprintf(
                '%08x-%04x-%04x-%04x-%012x',
                wp_rand(0, 0xffffffff),
                wp_rand(0, 0xffff),
                wp_rand(0, 0xffff),
                wp_rand(0, 0xffff),
                wp_rand(0, 0xffffffffffff)
            );
            update_option('mcqvs_content_plan_pending_batches', $batch_uuid);
        }

        // Initialize batch tracker
        $tracker = array();
        $tracker['_batch_id'] = $batch_uuid;
        $utc_now = gmdate('Y-m-d H:i:s');
        for ($i = 0; $i < $total_batches; $i++) {
            $tracker[$i + 1] = array(
                'status' => 'pending',
                'topics' => count($chunks[$i]),
                'time'   => $utc_now,
            );
        }
        update_option('mcqvs_batch_tracker', $tracker);

        // Enqueue background processing for each chunk
        foreach ($chunks as $index => $chunk) {
            if (function_exists('as_enqueue_async_action')) {
                as_enqueue_async_action('mcqvs_process_topic_batch', array(
                    $chunk,
                    $index + 1,
                    $total_batches,
                    $styles
                ), 'mcqvs_planner');
            } else {
                // Fallback: Synchronous processing
                $this->process_topic_batch_internal($chunk, $styles);
            }
        }
    }

    /**
     * @NEW 2026-02-19: Get status of background batches for UI progress bar
     */
    public function ajax_get_batch_status()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');

        $tracker = get_option('mcqvs_batch_tracker', array());

        // @FIX 1.4.9.48: Exclude metadata keys (e.g. '_batch_id' — a 36-char UUID)
        // from the batches list. Previously they were returned as fake batch rows,
        // rendering as "Batch #NaN / unknown" in the AI card.
        $filtered = array();
        $numeric_batches = array();
        if (is_array($tracker)) {
            foreach ($tracker as $idx => $data) {
                if (is_string($idx) && strpos($idx, '_') === 0) {
                    continue; // metadata keys like _batch_id
                }
                $filtered[$idx] = $data;
                $numeric_batches[$idx] = $data;
            }
        }

        wp_send_json_success(array(
            'batches' => $filtered,
            // summary counts only real (non-metadata) batches
            'summary' => array(
                'completed' => count(array_filter($numeric_batches, fn($b) => ($b['status'] ?? '') === 'completed')),
                'failed'    => count(array_filter($numeric_batches, fn($b) => ($b['status'] ?? '') === 'failed')),
                'retrying'  => count(array_filter($numeric_batches, fn($b) => ($b['status'] ?? '') === 'rate_limited')),
                'pending'   => count(array_filter($numeric_batches, fn($b) => ($b['status'] ?? '') === 'pending')),
            ),
            'active_batch_id' => is_array($tracker) && !empty($tracker['_batch_id']) ? (string) $tracker['_batch_id'] : '',
        ));
    }
    /**
     * This runs in the background to handle the AI calls.
     */
    public function handle_topic_batch_background($topics, $batch_index, $total_batches, $styles)
    {
        // @FIX 1.4.9.53 (global STOP): bail when the dashboard Stop Everything flag is set.
        if (function_exists('mcqvs_is_global_stopped') && mcqvs_is_global_stopped()) {
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log('Background: Batch skipped (global STOP active)', 'info', array('batch_index' => $batch_index));
            }
            return;
        }

        // @FIX: Use UTC consistently with `VS_Job_Repository` datetime columns.
        $utc_now = gmdate('Y-m-d H:i:s');

        if (class_exists('VS_Error_Logger')) {
            VS_Error_Logger::get_instance()->log("Background: Processing Batch {$batch_index}/{$total_batches} (" . count($topics) . " topics).", 'info', array('source' => 'Content Planner'));
        }

        $ai_handler = VS_AJAX_AI_Quiz_Handler::get_instance();

        // @NEW 2026-08-05: Partition topics into "CSV-supplied" (use _inline_questions as-is)
        // and "AI-required" (call Gemini). Existing AI path is untouched for the latter.
        $topic_strings = array();
        $inline_topic_map = array();
        foreach ($topics as $t) {
            $name = is_array($t) ? ($t['topic'] ?? '') : $t;
            if ($name === '') {
                continue;
            }
            $topic_strings[] = $name;
            if (is_array($t) && !empty($t['_inline_questions']) && is_array($t['_inline_questions'])) {
                $inline_topic_map[$name] = $t['_inline_questions'];
            }
        }

        $videos_per_topic = max(1, absint($styles['videos_per_topic'] ?? 1));
        $questions_per_video = max(1, absint($styles['questions_count'] ?? 5));
        $total_questions_per_topic = $questions_per_video * $videos_per_topic;

        $ai_topic_strings = array();
        foreach ($topic_strings as $n) {
            if (!isset($inline_topic_map[$n]) || empty($inline_topic_map[$n])) {
                $ai_topic_strings[] = $n;
            }
        }

        if (!empty($ai_topic_strings)) {
            $batch_results = $ai_handler->generate_batch_topic_quiz_data($ai_topic_strings, $total_questions_per_topic);
        } else {
            $batch_results = array();
        }

        // Build a unified results map: CSV-supplied first (authoritative), AI fills the rest.
        $unified_results = array();
        foreach ($inline_topic_map as $name => $qs) {
            $unified_results[$name] = $qs;
        }
        if (is_array($batch_results) && !is_wp_error($batch_results) && !empty($batch_results)) {
            foreach ($batch_results as $ai_topic => $qs) {
                $key = is_string($ai_topic) ? $ai_topic : '';
                if ($key === '' || isset($unified_results[$key])) {
                    continue;
                }
                $unified_results[$key] = $qs;
            }
        }
        $batch_results = $unified_results;

        if (is_wp_error($batch_results)) {
            $error_code = $batch_results->get_error_code();
            $error_msg = $batch_results->get_error_message();

            $is_rate_limited = (strpos($error_msg, 'rate_limited:') === 0);
            $retryable = ($is_rate_limited || $error_code === 'api_error');

            $tracker = get_option('mcqvs_batch_tracker', array());
            $tracker[$batch_index] = array(
                'status'    => $retryable ? 'rate_limited' : 'failed',
                'error'     => $error_msg,
                'time'      => $utc_now,
                'topics'    => count($topic_strings),
                'retryable' => $retryable,
                'styles'    => $styles,
            );
            update_option('mcqvs_batch_tracker', $tracker);

            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log("Background: Batch {$batch_index} FAILED. " . $error_msg, 'error', array(
                    'code'   => $error_code,
                    'topics' => $topics,
                    'will_retry' => $retryable,
                ));
            }

            if ($retryable && function_exists('as_schedule_single_action')) {
                $retry_count = absint($tracker[$batch_index]['_retry_count'] ?? 0);
                $delay = min(600, max(120, $retry_count * 300));
                $tracker[$batch_index]['_retry_count'] = $retry_count + 1;
                $tracker[$batch_index]['_next_retry_at'] = gmdate('Y-m-d H:i:s', time() + $delay);
                update_option('mcqvs_batch_tracker', $tracker);

                as_schedule_single_action(
                    time() + $delay,
                    'mcqvs_process_topic_batch',
                    array($topics, $batch_index, $total_batches, $styles),
                    'mcqvs_planner'
                );
                if (class_exists('VS_Error_Logger')) {
                    VS_Error_Logger::get_instance()->log("Background: Scheduled retry for batch {$batch_index} in {$delay}s (attempt #{$tracker[$batch_index]['_retry_count']})", 'info');
                }
            }
            return;
        }

        if (!is_array($batch_results) || empty($batch_results)) {
            $tracker = get_option('mcqvs_batch_tracker', array());
            $tracker[$batch_index] = array(
                'status'  => 'failed',
                'error'   => 'AI returned empty results',
                'topics'  => count($topic_strings),
                'time'    => $utc_now,
                'styles'  => $styles,
            );
            update_option('mcqvs_batch_tracker', $tracker);

            VS_Error_Logger::get_instance()->log("Background: Batch {$batch_index} returned empty results.", 'error', array(
                'source' => 'Content Planner',
                'batch'  => $batch_index,
            ));
            return;
        }

        $success_count = 0;
        $failed_topics = array();

            // @MODIFIED 2026-06-25: Removed global reset for staggered scheduling.
            // Staggering is now handled by local offset within each batch.
            // @FIX 2026-07-10: Persist max_offset in batch tracker so a partial retry
            // (e.g. AS duplicate action or manual re-submit) resumes from the correct
            // offset instead of 0, avoiding publish_at collisions with existing jobs.
            $tracker = get_option('mcqvs_batch_tracker', array());
            $current_batch_stagger_offset = absint($tracker[$batch_index]['max_offset'] ?? 0);

        // @MODIFIED 2026-02-19: Robust fuzzy matching for topics
        $normalized_results = array();
        foreach ($batch_results as $ai_topic => $qs) {
            $normalized_results[strtolower(trim($ai_topic, " \t\n\r\0\x0B.?!"))] = $qs;
        }

        foreach ($topics as $topic_item) {
            $topic = is_array($topic_item) ? $topic_item['topic'] : $topic_item;
            $lookup_key = strtolower(trim($topic, " \t\n\r\0\x0B.?!"));

            // @NEW 2026-08-05: CSV-supplied path. _inline_questions[] is the canonical
            // payload — no AI fuzzy-match needed. Normalize shape to the same
            // {questions,hashtags,hook} envelope the AI path returns.
            // @FIX 1.4.9.47: Preserve the CSV's own hashtags + hook — previously
            // hard-coded to '' here, which wiped the per-topic metadata that
            // process_legacy_excel_content() now carries on the topic item.
            if (is_array($topic_item) && !empty($topic_item['_inline_questions']) && is_array($topic_item['_inline_questions'])) {
                $resolved = array(
                    'questions' => $topic_item['_inline_questions'],
                    'hashtags'  => !empty($topic_item['hashtags']) ? $topic_item['hashtags'] : '',
                    'hook'      => !empty($topic_item['hookText']) ? $topic_item['hookText'] : (!empty($topic_item['hook']) ? $topic_item['hook'] : ''),
                );
            } else {
                $resolved = $normalized_results[$lookup_key] ?? null;
            }

            if (!$resolved) {
                $failed_topics[] = $topic;
                continue;
            }

            // @NEW 2026-08-01: Batch results now carry per-topic share metadata.
            //       Backward compatible with the legacy shape (plain questions array).
            if (is_array($resolved) && isset($resolved['questions'])) {
                $questions = $resolved['questions'];
                $topic_hashtags = isset($resolved['hashtags']) ? $resolved['hashtags'] : '';
                $topic_hook = isset($resolved['hook']) ? $resolved['hook'] : '';
            } else {
                $questions = $resolved;
                $topic_hashtags = '';
                $topic_hook = '';
            }

            if (!$questions) {
                $failed_topics[] = $topic;
                continue;
            }

            $item_styles = is_array($topic_item) ? $topic_item : array();

            // @NEW 2026-08-01: Per-topic AI share metadata overrides nothing global —
            //       these are AI-generated per-topic values passed straight to the job.
            $item_styles['hashtags'] = $topic_hashtags;
            $item_styles['hook'] = $topic_hook;

        // @FIX: Per-topic values override global defaults. Empty per-topic values fall back to global batch styles.
        foreach (array('template', 'font', 'music', 'bg_video') as $key) {
            if (empty($item_styles[$key]) && !empty($styles[$key])) {
                $item_styles[$key] = $styles[$key];
            }
        }
        // @FIX: Per-topic hookVisible/hookText override batch defaults.
        if (!isset($item_styles['hookVisible']) && isset($styles['hookVisible'])) {
            $item_styles['hookVisible'] = $styles['hookVisible'];
        }
        if (empty($item_styles['hookText']) && !empty($styles['hookText'])) {
            $item_styles['hookText'] = $styles['hookText'];
        }
        // @FIX 1.4.9.48: thread cover_config from batch styles down to each job so
        // the sidebar "Show Cover Page" toggle reaches create_job_for_topic() →
        // job settings → renderer (cover scene gated by coverConfig.enabled).
        if (!isset($item_styles['cover_config']) && isset($styles['cover_config'])) {
            $item_styles['cover_config'] = $styles['cover_config'];
        }
        // @FIX 1.4.9.48: per-topic video format passthrough (sidebar format selector).
        if (empty($item_styles['video_format']) && !empty($styles['video_format'])) {
            $item_styles['video_format'] = $styles['video_format'];
        }

        if (class_exists('VS_Error_Logger')) {
            VS_Error_Logger::get_instance()->log_pipeline(
                'job.style_resolved',
                'completed',
                $topic,
                "Style for '{$topic}': template={$item_styles['template']}, font={$item_styles['font']}, music={$item_styles['music']}, bg_video={$item_styles['bg_video']}",
                'info',
                array(
                    'topic'     => $topic,
                    'template'  => $item_styles['template'] ?? '',
                    'font'      => $item_styles['font'] ?? '',
                    'music'     => $item_styles['music'] ?? '',
                    'bg_video'  => $item_styles['bg_video'] ?? '',
                    'save_mode' => $item_styles['save_mode'] ?? 'local',
                )
            );
        }

        // @NEW 2026-05-07: Merge publish scheduling params from batch-level styles
        $item_styles['publish_start_date'] = $styles['publish_start_date'] ?? '';
        $item_styles['publish_time'] = $styles['publish_time'] ?? '09:00';
        $item_styles['publish_frequency'] = $styles['publish_frequency'] ?? 'daily';
        $item_styles['buffer_channels'] = $styles['buffer_channels'] ?? '[]';
        $item_styles['save_mode'] = $styles['save_mode'] ?? 'local';
        // @FIX: Pass video_format from batch styles to job settings so headless renderer uses per-job format
        if (!empty($styles['video_format'])) {
            $item_styles['video_format'] = $styles['video_format'];
        }

        // @NEW 2026-07-26: Calendar date pass-through — per-topic date overrides batch linear scheduling
        if (!empty($topic_item['publish_date'])) {
            $item_styles['publish_date'] = $topic_item['publish_date'];
        }
        if (!empty($topic_item['publish_time'])) {
            $item_styles['publish_time'] = $topic_item['publish_time'];
        }

        // @MODIFIED 2026-06-25: Calculate publish_at offset locally per job within batch.
        $item_styles['_publish_day_offset'] = $current_batch_stagger_offset;
        $local_videos_created_for_topic = 0; // Initialize a counter for videos generated by this specific topic item.

            // Multi-part topic support
            if ($videos_per_topic > 1) {
                $chunks = array_chunk($questions, $questions_per_video);
                // Only create the requested number of parts
                $chunks = array_slice($chunks, 0, $videos_per_topic);

                foreach ($chunks as $partIndex => $chunkQs) {
                    $part_styles = $item_styles;
                    $part_styles['part_index'] = $partIndex + 1;
                    $part_styles['part_total'] = $videos_per_topic;

                    $job_id = $this->create_job_for_topic($topic, $chunkQs, $part_styles);
                    if ($job_id) {
                        $success_count++;
                        $local_videos_created_for_topic++;
                    } else {
                        $failed_topics[] = $topic . ' (Part ' . ($partIndex + 1) . ' DB Fail)';
                    }
                }
                $current_batch_stagger_offset += $local_videos_created_for_topic; // Increment local offset for the next topic/video.

            } else {
                $job_id = $this->create_job_for_topic($topic, $questions, $item_styles);
                if ($job_id) {
                    $success_count++;
                    $current_batch_stagger_offset++; // Increment for single video.
                } else {
                    $failed_topics[] = $topic . " (DB Fail)";
                }
            }
        }

        // @NEW 2026-02-19: Update successful batch in tracker
        $tracker = get_option('mcqvs_batch_tracker', array());
        $total_jobs_expected = count($topics) * $videos_per_topic;
        $tracker[$batch_index] = array(
            'status'     => 'completed',
            'success'    => $success_count,
            'total_jobs' => $total_jobs_expected,
            'failed'     => $failed_topics,
            'styles'     => $styles,
            'max_offset' => $current_batch_stagger_offset,
            'time'       => $utc_now
        );
        update_option('mcqvs_batch_tracker', $tracker);

        $tracker_all = get_option('mcqvs_batch_tracker', array());
        $all_done = true;
        $now_ts = time();
        foreach ($tracker_all as $b) {
            $st = $b['status'] ?? '';
            if ($st === 'pending') {
                $all_done = false; break;
            }
            if ($st === 'rate_limited') {
                // @FIX 2026-07-06: Check _next_retry_at instead of batch_time
                $next_retry = $b['_next_retry_at'] ?? '';
                if (!empty($next_retry)) {
                    $retry_ts = strtotime($next_retry . ' UTC');
                    if ($retry_ts && $retry_ts > $now_ts) {
                        $all_done = false; break;
                    }
                } else {
                    // Fallback: if no retry time recorded, check batch_time
                    $batch_time = strtotime(($b['time'] ?? 'now') . ' UTC');
                    if ($batch_time > strtotime('-1 hour')) {
                        $all_done = false; break;
                    }
                }
            }
        }
        if ($all_done) {
            // @FIX: Use delayed cleanup to prevent race conditions with concurrent batch workers.
            // Schedule cleanup 5 minutes from now instead of immediate deletion.
            if (function_exists('as_schedule_single_action')) {
                as_schedule_single_action(time() + 300, 'mcqvs_cleanup_batch_tracker', array(), 'mcqvs_planner');
            } else {
                // @FIX 1.4.9.41 (data-loss): same safe cleanup as the scheduled
                // handler — runtime pointer only, topic plan kept on failure,
                // batch tracker (history) always kept.
                $this->cleanup_after_all_batches();
            }
        }

        if (class_exists('VS_Error_Logger')) {
            $level = ($success_count === $total_jobs_expected) ? 'info' : 'warning';
            VS_Error_Logger::get_instance()->log("Background: Batch {$batch_index} Complete. Created {$success_count}/{$total_jobs_expected} jobs.", $level, array(
                'source' => 'Content Planner',
                'failed' => $failed_topics
            ));
            VS_Error_Logger::get_instance()->log_pipeline(
                'batch.completed',
                $level,
                "batch-{$batch_index}",
                "Batch {$batch_index}/{$total_batches} complete: {$success_count} jobs created, " . count($failed_topics) . ' failed',
                $level,
                array(
                    'batch_index'      => $batch_index,
                    'total_batches'    => $total_batches,
                    'success_count'    => $success_count,
                    'total_jobs'       => $total_jobs_expected,
                    'failed_topics'    => $failed_topics,
                    'topics_processed' => $topic_strings,
                )
            );
        }
    }

    /**
     * Fallback for systems without Action Scheduler
     */
    private function process_topic_batch_internal($topics, $styles = array())
    {
        if (empty($styles)) {
            $styles = array(
                'template' => sanitize_text_field($_POST['style_template'] ?? ''),
                'font' => sanitize_text_field($_POST['style_font'] ?? ''),
                'music' => sanitize_text_field($_POST['style_music'] ?? ''),
                'bg_video' => sanitize_text_field($_POST['style_bg_video'] ?? ''),
                'save_mode' => sanitize_text_field($_POST['save_mode'] ?? 'local'),
                'video_format' => sanitize_text_field($_POST['style_video_format'] ?? 'shorts'),
                'videos_per_topic' => isset($_POST['videos_per_topic']) ? absint($_POST['videos_per_topic']) : 1,
                'questions_count' => isset($_POST['questions_count']) ? absint($_POST['questions_count']) : 5,
                'publish_start_date' => sanitize_text_field($_POST['publish_start_date'] ?? ''),
                'publish_time' => sanitize_text_field($_POST['publish_time'] ?? '09:00'),
                'publish_frequency' => sanitize_text_field($_POST['publish_frequency'] ?? 'daily'),
                'buffer_channels' => stripslashes($_POST['buffer_channels'] ?? '[]'),
            );
        }
        $this->handle_topic_batch_background($topics, 1, 1, $styles);
    }

    /**
     * Render the Content Planner Page
     */
    public function render_page()
    {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }

        // Enqueue Assets specific to this page if not done in core
        // (Usually handled by VS_Core::enqueue_assets via hook)

        $assets = $this->get_available_assets();

        // Compute current scheduler state for the pipeline-awareness banner
        $job_repo_planner = VS_Job_Repository::init();
        $planner_pipeline = $job_repo_planner->get_status_breakdown();
        $planner_headless_enabled = (bool) get_option('mcqvs_headless_rendering_enabled', false);
        $planner_auto_pub_enabled  = (bool) get_option('mcqvs_auto_publish_enabled', false);
        $planner_buffer_token     = (bool) get_option('mcqvs_buffer_access_token', '');
        $planner_pending_batches  = (int) get_option('mcqvs_content_plan_pending_batches', 0);
        $planner_renderer_live    = $planner_headless_enabled || $planner_pipeline['rendering'] > 0;

?>
        <div class="wrap mcqvs-wrapper">
            <h1 class="wp-heading-inline">📅 Content Planner (Flexible Batch)</h1>
            <hr class="wp-header-end">

            <!-- Pipeline Awareness Banner (always visible — no visibility drift between files) -->
            <div id="mcqvs-planner-pipeline-banner" class="postbox" style="padding:14px 18px; margin-top:14px; border-left:4px solid #2271b1; background:#f0f6ff;">
                <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                    <strong style="font-size:13px;">🔄 Pipeline Status:</strong>
                    <span id="plannerBannerPipeline">— refreshing…</span>
                </div>
                <p id="plannerBannerGuidance" style="margin:8px 0 0 0;font-size:12px;color:#1e293b;">
                    Approve & Schedule will: 1) AI-generate quiz questions for topics, 2) queue render jobs, 3) either headless-render on the VPS, or wait for the Queue Auto-Runner inside the Studio Editor. Track progress in the <a href="<?php echo esc_url(admin_url('admin.php?page=mcqvs-dashboard')); ?>">Dashboard</a>.
                </p>
            </div>

            <div class="mcqvs-planner-layout" style="display:flex; gap:20px; margin-top:20px;">

                <!-- Sidebar: Batch Settings -->
                <div class="mcqvs-planner-sidebar" style="width:300px; flex-shrink:0;">
                    <div class="postbox" style="padding:15px;">
                        <h2 class="hndle">Batch Settings</h2>

                        <!-- Batch Style Form -->
                        <div class="form-field">
                            <label>Video Format</label>
                            <select id="plannerVideoFormat" style="width:100%;">
                                <option value="shorts" selected>📱 Shorts (1080×1920)</option>
                                <option value="youtube">🖥️ YouTube (1920×1080)</option>
                            </select>
                            <p class="description">Controls layout orientation for all videos in this batch.</p>
                        </div>

                        <div class="form-field" style="margin-top:15px;">
                            <label>Video Template</label>
                            <select id="plannerTemplate" style="width:100%;">
                                <?php foreach ($assets['templates'] as $id => $name) : ?>
                                    <option value="<?php echo esc_attr($id); ?>"><?php echo esc_html($name); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-field" style="margin-top:15px;">
                            <label>Font Style</label>
                            <select id="plannerFont" style="width:100%;">
                                <option value="">Default (Template)</option>
                                <?php foreach ($assets['fonts'] as $id => $name) : ?>
                                    <option value="<?php echo esc_attr($id); ?>"><?php echo esc_html($name); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-field" style="margin-top:15px;">
                            <label>Background Music</label>
                            <select id="plannerMusic" style="width:100%;">
                                <option value="">No Music</option>
                                <?php foreach ($assets['music'] as $id => $name) : ?>
                                    <option value="<?php echo esc_attr($id); ?>"><?php echo esc_html($name); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-field" style="margin-top:15px;">
                            <label>Hook Text</label>
                            <input type="text" id="plannerHookText" value="Can you score 5/5?" style="width:100%;" placeholder="e.g. Can you score 5/5?">
                            <p class="description">Text shown at the start of each video. Leave default to use global setting.</p>
                        </div>

                        <div class="form-field" style="margin-top:10px;">
                            <label>Hook Text Presets</label>
                            <select id="plannerHookPreset" style="width:100%;">
                                <option value="">-- Select a preset --</option>
                                <option value="Only Geniuses Get 5/5">Only Geniuses Get 5/5</option>
                                <option value="Can You Beat This Quiz?">Can You Beat This Quiz?</option>
                                <option value="99% Get This Wrong">99% Get This Wrong</option>
                                <option value="How Many Can You Get Right?">How Many Can You Get Right?</option>
                                <option value="Your Brain Will Trick You">Your Brain Will Trick You</option>
                                <option value="Do Not Answer Too Fast">Do Not Answer Too Fast</option>
                                <option value="Can You Get All 5?">Can You Get All 5?</option>
                                <option value="Bet You Cannot Score 5/5">Bet You Cannot Score 5/5</option>
                                <option value="Expert-Level Quiz">Expert-Level Quiz</option>
                                <option value="Only 1 Percent Can Pass">Only 1 Percent Can Pass</option>
                            </select>
                            <p class="description">Quick-select a hook text preset. Overrides the custom text above.</p>
                        </div>

                        <div class="form-field" style="margin-top:15px;">
                            <label class="toggle-label">
                                <input type="checkbox" id="plannerHookVisible" <?php checked(get_option('mcqvs_planner_hook_visible', true)); ?>>
                                Show Hook Text On Video
                            </label>
                            <p class="description">Turn off to exclude the hook scene from generated videos. The hook is still used in the Buffer caption / pinned comment — this only affects the on-screen hook scene.</p>
                        </div>

                        <!-- @FIX 1.4.9.48: NEW Cover Page toggle — parity with Studio's coverConfig.
                             CSV imports and AI batches both honor this (cover scene gated by
                             coverConfig.enabled !== false across all render pipelines). -->
                        <div class="form-field" style="margin-top:10px;">
                            <label class="toggle-label">
                                <input type="checkbox" id="plannerCoverEnabled" <?php checked(get_option('mcqvs_planner_cover_enabled', true)); ?>>
                                Show Cover Page (thumbnail card)
                            </label>
                            <p class="description">Turn off to skip the 1s cover scene — videos then start directly with the hook or first question. Frame 0 is used as the platform thumbnail.</p>
                        </div>

                        <!-- @NEW 2026-02-23: Background Video batch default (Fix 2) -->
                        <div class="form-field" style="margin-top:15px;">
                            <label>Background Video</label>
                            <select id="plannerBgVideo" style="width:100%;">
                                <option value="">None (no background video)</option>
                                <!-- Populated dynamically via AJAX -->
                            </select>
                            <video id="plannerBgVideoPreview" style="display:none; width:100%; max-height:120px; border-radius:6px; margin-top:6px; object-fit:cover;" muted loop></video>
                        </div>

                        <hr>

                        <div class="form-field" style="margin-top:15px;">
                            <label>Save Strategy</label>
                            <select id="saveStrategy" style="width:100%;">
                                <option value="local">Download Locally (Browser)</option>
                                <option value="r2">Upload to Cloudflare R2</option>
                                <option value="r2_buffer">R2 + Auto-Post via Buffer</option>
                            </select>
                            <p class="description">
                                <strong>Local:</strong> Videos save via browser download.<br>
                                <strong>R2:</strong> Videos upload to Cloudflare R2 automatically (requires R2 settings).<br>
                                <strong>R2 + Buffer:</strong> Upload to R2, then auto-post to social media via Buffer (requires R2 + Buffer settings).
                            </p>
                        </div>

                        <hr>

                        <!-- @NEW 2026-05-07: Publish Scheduling Controls -->
                        <div style="margin-top:15px; border-top:1px solid #ddd; padding-top:15px;">
                            <h3 style="margin-top:0;">📅 Publish Schedule</h3>

                            <div class="form-field">
                                <label>Publish Start Date</label>
                                <input type="date" id="plannerPublishStartDate" style="width:100%;">
                                <p class="description">When to start publishing videos to social media.</p>
                            </div>

                            <div class="form-field" style="margin-top:10px;">
                                <label>Publish Time</label>
                                <input type="time" id="plannerPublishTime" value="09:00" style="width:100%;">
                                <p class="description">Time of day to publish each video (site timezone: <?php echo esc_html(wp_timezone_string()); ?>).</p>
                            </div>

                            <div class="form-field" style="margin-top:10px;">
                                <label>Publish Frequency</label>
                                <select id="plannerPublishFrequency" style="width:100%;">
                                    <option value="daily">1 video per day</option>
                                    <option value="twice_daily">2 videos per day (morning + evening)</option>
                                    <option value="every_3_days">1 video every 3 days</option>
                                    <option value="weekly">1 video per week</option>
                                    <option value="asap">All ASAP (no spacing)</option>
                                </select>
                                <p class="description">How often to publish videos to social media via Buffer.</p>
                            </div>

                            <div class="form-field" style="margin-top:10px;">
                                <label>Buffer Channels</label>
                                <select id="plannerBufferChannels" multiple style="width:100%; min-height:60px;">
                                    <?php
                                    $saved_raw = get_option('mcqvs_buffer_channels', '[]');
                                    $saved_channels = is_array($saved_raw) ? $saved_raw : (array) json_decode((string) $saved_raw, true);
                                    if (!is_array($saved_channels)) $saved_channels = array();

                                    $channels_raw = get_option('mcqvs_buffer_channels_data', '[]');
                                    $channels_data = is_array($channels_raw) ? $channels_raw : (array) json_decode((string) $channels_raw, true);
                                    if (!is_array($channels_data)) $channels_data = array();

                                    if (!empty($channels_data)) :
                                        foreach ($channels_data as $ch) :
                                            $ch_id = is_array($ch) ? ($ch['id'] ?? '') : '';
                                            $ch_name = is_array($ch) ? ($ch['displayName'] ?? $ch['name'] ?? 'Unknown') : '';
                                            $ch_service = is_array($ch) ? ($ch['service'] ?? '') : '';
                                            $selected = in_array($ch_id, $saved_channels) ? 'selected' : '';
                                            if ($ch_id) :
                                    ?>
                                    <option value="<?php echo esc_attr($ch_id); ?>" <?php echo $selected; ?>><?php echo esc_html("{$ch_service}: {$ch_name}"); ?></option>
                                    <?php
                                            endif;
                                        endforeach;
                                    else :
                                        echo '<option value="" disabled>' . esc_html__('No channels found. Refresh channels in Settings > Buffer.', 'mcq-video-studio') . '</option>';
                                    endif;
                                    ?>
                                </select>
                                <p class="description">Hold Ctrl/Cmd to select multiple. Only used when save mode = R2 + Buffer.</p>
                            </div>
                        </div>

                        <hr>

                        <!-- @NEW 2026-02-19: Batch Scale Controls -->
                        <div style="margin-top:15px; border-top:1px solid #ddd; padding-top:15px;">
                            <div class="form-field">
                                <label>Videos per Topic</label>
                                <input type="number" id="plannerVideosPerTopic" value="1" min="1" max="10" style="width:100%;">
                            </div>
                            <p class="description">How many videos to produce for EACH topic (each video will contain the Questions-per-Video amount).</p>

                            <div class="form-field">
                                <label>Questions per Video</label>
                                <input type="number" id="plannerQuestionCount" value="5" min="1" max="20" style="width:100%;">
                            </div>
                            <p class="description">How many MCQ questions to include in EACH video.</p>

                            <div style="display:flex; gap:8px; margin-top:10px; align-items:center;">
                                <button type="button" id="btnRunWorker" class="button button-small">Process Pending Batches Now</button>
                                <button type="button" id="btnRecoverFailed" class="button button-small">Recover Failed Jobs</button>
                            </div>
                            <?php $has_plan_topics = !empty(get_option('mcqvs_content_plan', [])); ?>
                            <button type="button" id="btnStartAIGenerationSidebar" class="button button-primary" style="width:100%; margin-top:10px;<?php echo $has_plan_topics ? '' : ' display:none;'; ?>">
                                🎬 Start AI Question Generation
                            </button>
                            <button type="button" id="btnCancelGeneration" class="button" style="width:100%; margin-top:6px; display:none;">
                                🛑 Cancel Pending AI Generation
                            </button>
                            <p class="description" style="margin-top:8px; color:#666; font-size:11px;">💡 To render videos, enable the <strong>Queue Auto-Runner</strong> on the <strong>Video Studio</strong> page.</p>
                        </div>
                    </div>
                </div>

                <!-- Main: Topic Planner -->
                <div class="mcqvs-planner-main" style="flex-grow:1;">

                    <!-- Planning Interface -->
                    <div class="postbox" style="padding:20px;">
                        <h2>Plan New Content</h2>
                        <div class="form-row">
                            <label style="font-weight:600; display:block; margin-bottom:5px;">Target Niches (Comma Separated)</label>
                            <input type="text" id="plannerNicheInput" placeholder="e.g. 90s Nostalgia, World Capitals, Science Facts" style="width:100%; padding:8px;">
                        </div>

                        <!-- @NEW 2026-02-19: Planning Scale Controls -->
                        <div class="form-row" style="margin-top:15px; display:flex; gap:15px;">
                            <div style="flex:1;">
                                <label style="font-weight:600; display:block; margin-bottom:5px;">Videos per Niche</label>
                                <input type="number" id="plannerVideoCount" value="30" min="1" max="100" style="width:100%; padding:8px;">
                                <p class="description">Total video topics to generate.</p>
                            </div>
                        </div>

                        <div style="margin-top:15px; display:flex; gap:10px;">
                            <button type="button" id="btnGeneratePlan" class="button button-primary button-large">
                                ✨ Generate Topics (AI)
                            </button>
                            <button type="button" id="btnClearPlan" class="button">Clear</button>
                        </div>

                        <!-- Results Editor -->
                        <div id="plannerResultsArea" style="margin-top:20px; display:none;">
                            <h3>Generated Topics</h3>
                            <p class="description">Review and customize each topic's settings before approving.</p>

                            <table class="wp-list-table widefat fixed striped" style="margin-top:15px; width:100%;">
                                <thead>
                                    <tr>
                                        <th style="width:25%;">Topic</th>
                                        <th style="width:10%;">Template</th>
                                        <th style="width:8%;">Font</th>
                                        <th style="width:10%;">Music</th>
                                        <th style="width:10%;">BG Video</th>
                                        <th style="width:10%;">Hook Text</th>
                                        <th style="width:6%;">Hook</th>
                                        <!-- @NEW 2026-08-03: Calendar date/time columns -->
                                        <th style="width:10%;">Publish Date</th>
                                        <th style="width:8%;">Publish Time</th>
                                        <th style="width:40px;"></th>
                                    </tr>
                                </thead>
                                <tbody id="plannerResultsTableBody">
                                    <!-- Populated by JS -->
                                </tbody>
                            </table>

                            <div style="margin-top:15px; display:flex; justify-content:space-between; align-items:center;">
                                <button type="button" id="btnAddTopic" class="button">➕ Add Topic</button>
                                <button type="button" id="btnApprovePlan" class="button button-primary button-large">
                                    ✅ Approve & Schedule Jobs
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- @NEW 2026-07-26: Monthly Content Calendar -->
                    <div class="postbox" style="margin-top:20px; padding:20px;">
                        <h2 style="margin:0 0 10px 0;">📅 Monthly Content Calendar</h2>
                        <p class="description" style="margin:0 0 12px 0;">
                            Assign topics to specific dates and times for scheduled publishing. Drag topics onto calendar days, or use Auto-Assign.
                        </p>

                        <div style="display:flex; gap:12px; flex-wrap:wrap; align-items:flex-end; margin-bottom:15px;">
                            <div style="flex:1; min-width:150px;">
                                <label style="font-weight:600; display:block; margin-bottom:3px;">Auto-Assign Start Date</label>
                                <input type="date" id="calStartDate" style="width:100%;">
                            </div>
                            <div style="flex:1; min-width:150px;">
                                <label style="font-weight:600; display:block; margin-bottom:3px;">Frequency</label>
                                <select id="calFrequency" style="width:100%;">
                                    <option value="daily">1x Daily</option>
                                    <option value="2x_daily">2x Daily</option>
                                    <option value="3x_daily">3x Daily</option>
                                    <option value="4x_daily">4x Daily</option>
                                    <option value="twice_daily">Twice Daily (legacy)</option>
                                    <option value="every_3_days">Every 3 Days</option>
                                    <option value="weekly">Weekly</option>
                                    <option value="asap">ASAP</option>
                                </select>
                            </div>
                            <div style="flex:1; min-width:120px;">
                                <label style="font-weight:600; display:block; margin-bottom:3px;">Publish Time</label>
                                <input type="time" id="calPublishTime" value="09:00" style="width:100%;">
                                <p class="description" style="font-size:10px; margin-top:3px;">Default slot time (overridden by per-slot times below)</p>
                            </div>
                            <div>
                                <button type="button" id="btnCalAutoAssign" class="button button-primary" style="margin-top:19px;">Auto-Assign Dates</button>
                            </div>
                            <div>
                                <button type="button" id="btnCalSaveAssignments" class="button" style="margin-top:19px; display:none;">Save Changes</button>
                            </div>
                        </div>

                        <div style="display:flex; gap:20px;">
                            <!-- Calendar Grid -->
                            <div style="flex:3;">
                                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
                                    <button type="button" id="btnCalPrev" class="button button-small">&laquo; Prev</button>
                                    <strong id="calMonthLabel" style="font-size:14px;"></strong>
                                    <button type="button" id="btnCalNext" class="button button-small">Next &raquo;</button>
                                </div>
                                <div id="mcqvsCalendarGrid">
                                    <p style="text-align:center;color:#999;">Loading calendar...</p>
                                </div>
                            </div>

                            <!-- Unassigned Topics Sidebar -->
                            <div style="flex:1; min-width:200px; max-width:280px;">
                                <h3 style="margin-top:0; font-size:13px;">Unassigned Topics</h3>
                                <p class="description" style="font-size:11px;">Drag to calendar or click 📅 to assign a date + time.</p>
                                <div id="calUnassignedTopics" style="max-height:400px; overflow-y:auto;">
                                    <p style="color:#999;font-size:12px;">Generate topics first.</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- @NEW 2026-07-10: Saved Questions Bank — Data Source Card for Content Planner -->
                    <div class="postbox" style="margin-top:20px; padding:20px;">
                        <h2 style="margin:0 0 10px 0;">📚 Saved Questions Bank</h2>
                        <p class="description" style="margin:0 0 12px 0;">
                            Browse previously generated questions saved in the dedicated bank.
                            Select questions to compose a fresh video job from existing content.
                        </p>

                        <div style="display:flex; gap:12px; flex-wrap:wrap; align-items:flex-end; margin-bottom:12px;">
                            <div style="flex:1; min-width:220px;">
                                <label style="font-weight:600; display:block; margin-bottom:3px;">Source Filter</label>
                                <select id="plannerBankSourceFilter" style="width:100%;">
                                    <option value="all">All Sources</option>
                                    <option value="topic">Topic Card</option>
                                    <option value="news">News Card</option>
                                    <option value="planner_batch">Content Planner</option>
                                    <option value="subject">Legacy</option>
                                </select>
                            </div>
                            <div style="flex:2; min-width:280px;">
                                <label style="font-weight:600; display:block; margin-bottom:3px;">Select Topic</label>
                                <select id="plannerBankTopicSelect" style="width:100%;">
                                    <option value="">— Select a topic —</option>
                                    <!-- Populated dynamically via AJAX -->
                                </select>
                            </div>
                            <div>
                                <button type="button" id="btnPlannerBankRefresh" class="button" style="margin-top:19px;">↻ Refresh</button>
                            </div>
                        </div>

                        <div id="plannerBankQuestionStatus" style="color:#888; font-size:12px; margin-bottom:8px;"></div>

                        <table class="wp-list-table widefat fixed striped" id="plannerBankQuestionsTable" style="width:100%; display:none;">
                            <thead>
                                <tr>
                                    <th style="width:30px;"><input type="checkbox" id="plannerBankSelectAll"></th>
                                    <th style="width:55%;">Question</th>
                                    <th style="width:10%;">Options</th>
                                    <th style="width:15%;">Source</th>
                                    <th style="width:10%;">Created</th>
                                </tr>
                            </thead>
                            <tbody id="plannerBankQuestionsBody">
                                <!-- Populated by JS -->
                            </tbody>
                        </table>

                        <div id="plannerBankNoResults" style="display:none; text-align:center; color:#999; padding:15px; border:1px dashed #ccc; border-radius:4px; margin-top:8px;">
                            No questions found for this topic.
                        </div>

                        <div id="plannerBankActionBar" style="display:none; margin-top:12px; gap:10px; align-items:center;">
                            <span id="plannerBankSelectedCount" style="font-size:12px; color:#666;"></span>
                            <button type="button" id="btnPlannerComposeVideo" class="button button-primary">
                                🎬 Generate Video From Selection
                            </button>
                        </div>
                    </div>

                    <!-- Pending Queue Preview -->
                    <div class="postbox" style="margin-top:20px; padding:20px;">
                        <div style="display:flex; justify-content:space-between; align-items:center;">
                            <h2 style="margin:0;">Scheduled Queue</h2>
                            <span id="queueSummary" style="font-size:12px; color:#666; font-weight:600;"></span>
                        </div>
                        <p class="description">Jobs waiting for the Auto-Runner.</p>
                        <!-- Dynamic Queue List -->
                        <div id="plannerQueueList">
                            <p>Loading queue...</p>
                        </div>
                    </div>

                    <!-- @NEW 2026-07-30: Excel/CSV Import Section -->
                    <div class="postbox" style="margin-top:20px; padding:20px; border:2px solid #2271b1; background:#f0f7ff;">
                        <h2 style="margin:0 0 12px 0; color:#2271b1;">📁 Import Content from Excel/CSV</h2>
                        <p class="description" style="margin:0 0 15px 0;">
                            Upload an Excel (.xls, .xlsx) or CSV file with topics and descriptions.
                            The system will automatically parse topics and apply smart scheduling based on your requirements (3 videos daily, 6PM-11PM, R2+Buffer mode, TTS, etc.).
                        </p>

                        <div style="display:flex; gap:15px; align-items:flex-end; flex-wrap:wrap;">
                            <div style="flex:1; min-width:280px;">
                                <label style="font-weight:600; display:block; margin-bottom:5px;">File Upload</label>
                                <input type="file" id="excelFileInput" accept=".xlsx,.xls,.csv" style="width:100%; padding:8px; border:1px solid #ccc; border-radius:4px;">
                                <p class="description" style="font-size:11px; margin-top:4px;">Maximum file size: 10MB. Supports simple CSV with Topic/Description columns.</p>
                            </div>

                            <div style="display:flex; gap:10px;">
                                <button type="button" id="btnPreviewImport" class="button button-secondary" style="margin-top:19px;">📄 Preview Import</button>
                                <button type="button" id="btnImportExcel" class="button button-primary" style="margin-top:19px; display:none;">✅ Import Topics</button>
                            </div>
                        </div>

                        <div id="importProgress" style="margin-top:15px; display:none;">
                            <div style="display:flex; align-items:center; gap:10px;">
                                <span id="progressText">Processing file...</span>
                                <div style="flex:1; background:#e0e0e0; height:20px; border-radius:10px; overflow:hidden;">
                                    <div id="progressBar" style="background:#2271b1; height:100%; width:0%; transition:width 0.3s;"></div>
                                </div>
                                <span id="progressPercent">0%</span>
                            </div>
                        </div>

                        <div id="importResults" style="margin-top:15px; display:none;">
                            <div id="previewSection" style="background:#fff; border:1px solid #ddd; border-radius:4px; padding:15px;">
                                <h3 style="margin:0 0 10px 0; color:#2271b1;">📊 Import Preview</h3>
                                <div id="previewContent">
                                    <p style="color:#666; font-style:italic;">Select a file and click Preview to see how topics will be imported.</p>
                                </div>
                            </div>

                            <div id="smartDefaultsNotice" style="background:#e8f5e8; border:1px solid #c3e6c3; border-radius:4px; padding:12px; margin-top:10px; display:none;">
                                <h4 style="margin:0 0 8px 0; color:#2e7d32;">🤖 Smart Defaults Applied</h4>
                                <ul style="margin:0; padding-left:20px; font-size:12px; color:#555;">
                                    <li>⏰ <strong>Scheduling:</strong> 3 videos daily, 6PM-11PM with 15-minute variations</li>
                                    <li>📝 <strong>Style:</strong> Font auto-selected, template auto-picked by topic/niche (corporate, elegant, neon, science, nature, space, history, tech, sports, trivia, retro80s, cyberpunk, classroom, fire, electric, horror)</li>
                                    <li>🔊 <strong>Audio:</strong> TTS only (no background music)</li>
                                    <li>🎬 <strong>Video:</strong> 1 video per topic, 5 questions per video</li>
                                    <li>💾 <strong>Save:</strong> R2 + Buffer (all 3 buffer channels)</li>
                                    <li>🎨 <strong>Branding:</strong> TheQuizWire brand, logo position: all</li>
                                    <li>🎭 <strong>Hooks:</strong> Randomized from 10 TTS-friendly options</li>
                                </ul>
                                <div style="margin-top:12px; padding-top:12px; border-top:1px solid #c3e6c3; text-align:center;">
                                    <p style="font-size:12px; color:#555; margin:0 0 8px 0;">
                                        Topics with dates/times in CSV are auto-scheduled. Topics without dates: assign in calendar, then click below.
                                    </p>
                                    <button type="button" id="btnStartAIGeneration" class="button button-primary button-large" style="display:none;">
                                        🎬 Start AI Question Generation
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>

        </div>

    <?php
    }

    /**
     * AJAX: Import Topics from Excel/CSV File
     *
     * Allows bulk import of topics from Excel/CSV files for efficient content planning.
     * Supports automatic calendar-based scheduling and preserves all topic settings.
     *
     * @since 1.0.0
     */
    public function ajax_import_topics_from_excel()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        // @FIX 1.4.9.48: CSV topics are processed synchronously (bank insert + job
        // creation) so large files can exceed PHP's default execution limit.
        if (function_exists('set_time_limit')) {
            @set_time_limit(300);
        }
        @ini_set('memory_limit', '512M');
        if (function_exists('wp_raise_memory_limit')) {
            wp_raise_memory_limit('admin');
        }

        // Check if file was uploaded
        if (empty($_FILES['excel_file'])) {
            wp_send_json_error('No file uploaded');
        }

        $file = $_FILES['excel_file'];
        $allowed_ext = array('xls', 'xlsx', 'csv');
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

        if (! in_array($ext, $allowed_ext)) {
            wp_send_json_error('Invalid file type. Only XLS, XLSX, and CSV files are allowed.');
        }

        // For now, we'll process the uploaded file using VS_Excel_Importer
        // Note: You'll need to handle file upload properly for production
        // This is a simplified implementation for demonstration

        if (! class_exists('VS_Excel_Importer')) {
            wp_send_json_error('Excel importer class not found');
        }

        // Extract file content (in production, you'd save and parse properly)
        if (! empty($file['tmp_name']) && file_exists($file['tmp_name'])) {
            $file_content = file_get_contents($file['tmp_name']);
        } else {
            wp_send_json_error('Unable to read uploaded file');
        }

        try {
            // Parse Excel/CSV content
            $parsed_data = VS_Excel_Importer::parse_excel_content($file_content);

            if (empty($parsed_data) || isset($parsed_data['error'])) {
                if (isset($parsed_data['error'])) {
                    wp_send_json_error($parsed_data['error']);
                } else {
                    wp_send_json_error('No topics found in the uploaded file');
                }
            }

            // @FIX 1.4.9.52: persist the sidebar toggles at import time too, so the
            // user's choice survives a page refresh even if the change-save AJAX was
            // interrupted. Single source of truth: mcqvs_planner_hook_visible /
            // mcqvs_planner_cover_enabled (read by the checkbox render + Studio seed).
            if (isset($_POST['hook_visible'])) {
                update_option('mcqvs_planner_hook_visible', sanitize_text_field($_POST['hook_visible']) !== '0');
            }
            if (isset($_POST['cover_enabled'])) {
                update_option('mcqvs_planner_cover_enabled', sanitize_text_field($_POST['cover_enabled']) !== '0');
            }

            // Prepare import settings from POST data with smart defaults
            // @FIX 1.4.9.48: read the sidebar controls (hook visible, cover page,
            // template, format, save mode, schedule) so CSV imports honor them —
            // previously hook_visible was hardcoded true and there was no cover
            // control at all in Content Planner (Studio had both).
            $import_settings = array(
                'publish_frequency' => sanitize_text_field($_POST['publish_frequency'] ?? 'daily'),
                'videos_per_day' => 3,
                'video_per_topic' => isset($_POST['video_per_topic']) ? max(1, absint($_POST['video_per_topic'])) : 1,
                'questions_per_video' => isset($_POST['questions_per_video']) ? max(1, absint($_POST['questions_per_video'])) : 5,
                'save_mode' => sanitize_text_field($_POST['save_mode'] ?? 'r2_buffer'),
                'brand_name' => 'TheQuizWire',
                'logo_position' => 'all',
                'buffer_channels' => VS_Buffer_Client::get_valid_saved_channel_ids(),
                // @FIX 2026-08-11: brand template is the fallback when no template is set.
                'template' => sanitize_text_field($_POST['style_template'] ?? 'trivia'),
                'publish_time' => sanitize_text_field($_POST['publish_time'] ?? '09:00'),
                // @FIX 1.4.9.48: sidebar toggle — "Show Hook Text On Video"
                'hook_visible' => isset($_POST['hook_visible']) ? sanitize_text_field($_POST['hook_visible']) !== '0' : true,
                // @FIX 1.4.9.48: NEW sidebar toggle — "Show Cover Page" (default ON,
                // matches Studio coverConfig.enabled !== false semantics).
                'cover_enabled' => isset($_POST['cover_enabled']) ? sanitize_text_field($_POST['cover_enabled']) !== '0' : true,
                // @FIX 1.4.9.48: per-job format (shorts/youtube) from sidebar.
                'video_format' => sanitize_text_field($_POST['style_video_format'] ?? 'shorts'),
            );

            $legacy_result = VS_Excel_Importer::process_legacy_excel_content($parsed_data, $import_settings);

            // @FIX 1.4.9.47 (CRITICAL): Persist CSV questions into the Saved
            // Questions Bank (vs_mcq_bank) SYNCHRONOUSLY during import. All three
            // views — the Content Planner "Saved Questions Bank", the Qs card, and
            // the Studio Editor data source — read vs_mcq_bank, but the questions
            // only used to reach it indirectly, when the background Action Scheduler
            // batch ran and created jobs. If that async batch never fired (WP-Cron
            // off, AS not processing), imported questions appeared nowhere. Now they
            // are bank rows the moment import completes; the later batch's own
            // insert_mcq() calls simply dedupe on content_hash and reuse the ids.
            if (!empty($legacy_result) && class_exists('VS_MCQ_Repository')) {
                $mcq_repo = VS_MCQ_Repository::get_instance();
                foreach ($legacy_result as &$topic_item) {
                    if (empty($topic_item['topic']) || empty($topic_item['_inline_questions']) || !is_array($topic_item['_inline_questions'])) {
                        continue;
                    }
                    $topic_name = (string) $topic_item['topic'];
                    $existing = $mcq_repo->get_topic($topic_name);
                    $topic_id = ($existing && !empty($existing['id'])) ? (int) $existing['id'] : 0;
                    if ($topic_id <= 0) {
                        $topic_id = (int) $mcq_repo->create_topic($topic_name, 'planner_topic', 0);
                    }
                    if ($topic_id <= 0) {
                        continue;
                    }
                    $bank_ids = array();
                    foreach ($topic_item['_inline_questions'] as $q) {
                        $q_text = isset($q['question']) ? (string) $q['question'] : '';
                        if ($q_text === '') {
                            continue;
                        }
                        $opts = (isset($q['options']) && is_array($q['options'])) ? array_values($q['options']) : array('', '', '', '');
                        $result = $mcq_repo->insert_mcq(array(
                            'question_text'   => $q_text,
                            'options'         => $opts,
                            'correct_index'   => isset($q['correct']) ? (int) $q['correct'] : 0,
                            'topic_id'        => $topic_id,
                            'status'          => 'approved',
                            'source_ref'      => 'csv_import',
                            'difficulty'      => !empty($q['difficulty']) ? $q['difficulty'] : 'medium',
                            'parent_post_id'  => null,
                        ));
                        if (is_wp_error($result)) {
                            if ($result->get_error_code() === 'duplicate_mcq') {
                                $err_data = $result->get_error_data();
                                if (!empty($err_data['id'])) {
                                    $bank_ids[] = (int) $err_data['id'];
                                }
                            }
                            // Validation failures (too long / bad index) are skipped,
                            // mirroring Studio's tolerate-and-continue behavior.
                        } else {
                            $bank_ids[] = (int) $result;
                        }
                    }
                    if (!empty($bank_ids)) {
                        $topic_item['_bank_question_ids'] = $bank_ids;
                    }
                }
                unset($topic_item);
            }

            $existing_plan = get_option('mcqvs_content_plan', array());
            if (!is_array($existing_plan)) $existing_plan = array();
            $merged_plan = array_merge($existing_plan, $legacy_result);
            update_option('mcqvs_content_plan', $merged_plan);

            // @NEW 2026-08-06: Auto-trigger approval for CSV-imported topics that have calendar dates.
            // This fulfills "auto add topics as per date, time on calendar and rendering of videos to start".
            $has_calendar_topics = false;
            foreach ($legacy_result as $t) {
                if (is_array($t) && (!empty($t['publish_date']) || !empty($t['_inline_questions']))) {
                    $has_calendar_topics = true;
                    break;
                }
            }

            if ($has_calendar_topics) {
                // Use the same defaults as the preview/import settings
                // @FIX 1.4.9.48: cover_config threaded through so the renderer's
                // cover scene is gated by the sidebar toggle (enabled !== false).
                $approve_styles = array(
                    'template'           => $import_settings['template'] ?? 'corporate',
                    'font'               => '',
                    'music'              => '',
                    'bg_video'           => '',
                    'save_mode'          => $import_settings['save_mode'] ?? 'r2_buffer',
                    'questions_count'    => $import_settings['questions_per_video'] ?? 5,
                    'videos_per_topic'   => $import_settings['video_per_topic'] ?? 1,
                    'video_format'       => $import_settings['video_format'] ?? 'shorts',
                    'publish_start_date' => $import_settings['start_date'] ?? gmdate('Y-m-d'),
                    'publish_time'       => $import_settings['publish_time'] ?? '09:00',
                    'publish_frequency'  => $import_settings['publish_frequency'] ?? 'daily',
                    'buffer_channels'    => wp_json_encode($import_settings['buffer_channels'] ?? VS_Buffer_Client::get_valid_saved_channel_ids()),
                    'hookVisible'        => $import_settings['hook_visible'] ?? true,
                    'hookText'           => '',
                    'cover_config'       => array('enabled' => !empty($import_settings['cover_enabled'])),
                );

                // @FIX 1.4.9.48 (CRITICAL E2E): CSV topics already carry their
                // questions (_inline_questions) — NO AI is needed. Process them
                // SYNCHRONOUSLY right here so jobs are created immediately and:
                //   • Dashboard → Pipeline Jobs shows today's/upcoming videos at once
                //   • the "AI Generation Progress" card is NOT polluted with fake
                //     pending AI batches (CSV never calls Gemini)
                //   • no dependency on Action Scheduler / WP-Cron ticking
                // Topics WITHOUT inline questions (topic-name-only CSVs) still go
                // through the async AI batch path below.
                $csv_topics = array_values(array_filter($legacy_result, function ($t) {
                    return is_array($t) && !empty($t['_inline_questions']) && is_array($t['_inline_questions']);
                }));
                $ai_topics  = array_values(array_filter($legacy_result, function ($t) {
                    return !(is_array($t) && !empty($t['_inline_questions']) && is_array($t['_inline_questions']));
                }));

                $jobs_created_sync = 0;
                if (!empty($csv_topics)) {
                    // Guard against very large CSVs — process synchronously in
                    // chunks but never hand CSV questions to the AI path.
                    $before = array_sum((array) VS_Job_Repository::init()->get_status_breakdown());
                    $this->process_topic_batch_internal($csv_topics, $approve_styles);
                    $after = array_sum((array) VS_Job_Repository::init()->get_status_breakdown());
                    $jobs_created_sync = max(0, (int) $after - (int) $before);
                }

                if (!empty($ai_topics)) {
                    // Only topics that actually need AI question generation are
                    // queued as async AI batches.
                    $this->approve_topic_plan_internal($ai_topics, $approve_styles);
                }

                if (class_exists('VS_Error_Logger')) {
                    VS_Error_Logger::get_instance()->log(
                        "Auto-approval for CSV import: {$jobs_created_sync} jobs created synchronously (no AI), " . count($ai_topics) . " topics queued for AI.",
                        'info',
                        array(
                            'source_file' => $file['name'],
                            'topics_count' => count($legacy_result),
                            'jobs_created_sync' => $jobs_created_sync,
                            'ai_topics' => count($ai_topics),
                            'styles' => $approve_styles,
                        )
                    );
                }
            }

            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log(
                    "Topics imported successfully: " . count($parsed_data) . " topics from Excel upload",
                    'info',
                    array(
                        'source_file' => $file['name'],
                        'topics_count' => count($parsed_data),
                        'settings' => $import_settings,
                        'upload_ip' => $_SERVER['REMOTE_ADDR'] ?? '',
                    )
                );
            }

            wp_send_json_success(array(
                'message' => "Successfully imported " . count($legacy_result) . " topics from file '{$file['name']}'",
                'topics_count' => count($legacy_result),
                'processed_topics' => $legacy_result,
                'mode' => 'imported',
            ));

        } catch (Exception $e) {
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log(
                    "Failed to import Excel file: " . $e->getMessage(),
                    'error',
                    array(
                        'file' => $file['name'] ?? '',
                        'error' => $e->getMessage(),
                        'trace' => $e->getTraceAsString(),
                    )
                );
            }
            wp_send_json_error('Failed to process file: ' . $e->getMessage());
        }
    }

    /**
     * AJAX: Cancel pending AI generation batches and clear the tracker.
     *
     * @since 1.0.0
     */
    public function ajax_cancel_pending_batches()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        $cancelled = 0;
        if (function_exists('as_unschedule_all_actions')) {
            $cancelled = as_unschedule_all_actions('mcqvs_process_topic_batch', array(), 'mcqvs_planner');
        }

        delete_option('mcqvs_content_plan_pending_batches');
        delete_option('mcqvs_batch_tracker');

        if (class_exists('VS_Error_Logger')) {
            VS_Error_Logger::get_instance()->log(
                'Cancelled pending AI generation batches',
                'info',
                array('unscheduled_actions' => $cancelled)
            );
        }

        wp_send_json_success(array(
            'message' => "Cancelled {$cancelled} pending AI batches. You can start fresh.",
            'cancelled' => $cancelled,
        ));
    }

    /**
     * Direct method to auto-assign calendar for imported topics (bypassing AJAX)
     *
     * @since 1.0.0
     * @param array $topics Array of topic data from Excel/CSV
     * @param array $settings Import settings
     * @return array Result of auto-assignment
     */
    private function ajax_auto_assign_calendar_direct($topics, $settings)
    {
        // Convert topics to expected format for calendar assignment
        $plan = array();
        $per_day = isset($settings['videos_per_day']) ? max(1, (int) $settings['videos_per_day']) : 1;

        foreach ($topics as $index => $topic_data) {
            // Extract topic name (allow various field names)
            $topic_name = '';
            if (is_array($topic_data)) {
                $topic_name = $topic_data['topic'] ?? $topic_data['topic_name'] ?? '';
                // Preserve additional fields
                $topic_info = $topic_data;
                $topic_info['topic'] = $topic_name;
            } else {
                $topic_name = $topic_data;
                $topic_info = array('topic' => $topic_name);
            }

            if (empty($topic_name)) {
                continue;
            }

            // Calculate day offset
            $day_index = intdiv($index, $per_day);
            $slot_index = $index % $per_day;

            // Create calendar entry
            $item = $topic_info;
            if (! is_array($item)) {
                $item = array('topic' => $topic_name);
            }

            // @FIX: If topic already has explicit publish_date + publish_time (from CSV), preserve it
            if (!empty($item['publish_date']) && !empty($item['publish_time']) && !empty($item['_calendar_assigned'])) {
                $plan[] = $item;
                continue;
            }

            // Set default scheduling time if provided
            if (! empty($settings['start_date'])) {
                $start_date = new DateTime($settings['start_date']);
                $start_date->modify("+{$day_index} days");
                $item['publish_date'] = $start_date->format('Y-m-d');

                // Set slot-specific time if multiple per day
                $time = '09:00'; // Default
                if ($per_day > 1) {
                    $minutes_per_slot = 24 * 60 / $per_day;
                    $slot_minutes = $slot_index * $minutes_per_slot;
                    $hour = floor($slot_minutes / 60);
                    $minute = $slot_minutes % 60;
                    $time = sprintf("%02d:%02d", $hour, $minute);
                }

                if (! empty($settings['publish_time'])) {
                    $time = $settings['publish_time'];
                }

                $item['publish_time'] = $time;
            }

            // Add style settings
            if (! empty($settings['template'])) {
                $item['template'] = $settings['template'];
            }

            if (! empty($settings['font'])) {
                $item['font'] = $settings['font'];
            }

            if (! empty($settings['music'])) {
                $item['music'] = $settings['music'];
            }

            if (! empty($settings['bg_video'])) {
                $item['bg_video'] = $settings['bg_video'];
            }

            // Calculate day offset for processing
            $item['_publish_day_offset'] = $day_index;

            // Add settings that should be preserved across topics
            $item['_all_topics'] = $topics; // Store all topics for reference

            $plan[] = $item;
        }

        // Save to content plan option
        update_option('mcqvs_content_plan', $plan);

        return array(
            'plan' => $plan,
            'mode' => 'scheduled',
            'start_date' => $settings['start_date'] ?? '',
            'frequency' => $settings['publish_frequency'] ?? 'daily',
            'per_day' => $per_day,
            'total_topics' => count($plan),
        );
    }

    /**
     * AJAX: Validate and preview Excel/CSV import
     *
     * Previews the contents of an Excel/CSV file without actually importing it.
     * Useful for users to verify file contents before bulk import.
     *
     * @since 1.0.0
     */
    /**
     * @FIX 1.4.9.49: Persist the planner sidebar toggles (hook visible, cover page)
     * so they don't reset to checked on every page load. Import + approve already
     * read the live DOM values; this just stores the user's preference.
     */
    public function ajax_planner_save_toggles()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }
        if (isset($_POST['hook_visible'])) {
            update_option('mcqvs_planner_hook_visible', sanitize_text_field($_POST['hook_visible']) !== '0');
        }
        if (isset($_POST['cover_enabled'])) {
            update_option('mcqvs_planner_cover_enabled', sanitize_text_field($_POST['cover_enabled']) !== '0');
        }
        wp_send_json_success(array(
            'hook_visible'  => (bool) get_option('mcqvs_planner_hook_visible', true),
            'cover_enabled' => (bool) get_option('mcqvs_planner_cover_enabled', true),
        ));
    }

    public function ajax_preview_excel_import()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        // Check if file was uploaded
        if (empty($_FILES['excel_file'])) {
            wp_send_json_error('No file uploaded');
        }

        $file = $_FILES['excel_file'];
        $allowed_ext = array('xls', 'xlsx', 'csv');
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

        if (! in_array($ext, $allowed_ext)) {
            wp_send_json_error('Invalid file type. Only XLS, XLSX, and CSV files are allowed.');
        }

        if (! empty($file['tmp_name']) && file_exists($file['tmp_name'])) {
            $file_content = file_get_contents($file['tmp_name']);
        } else {
            wp_send_json_error('Unable to read uploaded file');
        }

        try {
            // Parse topics using VS_Excel_Importer
            if (! class_exists('VS_Excel_Importer')) {
                wp_send_json_error('Excel importer class not found');
            }

            $parsed_topics = VS_Excel_Importer::parse_excel_content($file_content);

            if (empty($parsed_topics) || isset($parsed_topics['error'])) {
                if (isset($parsed_topics['error'])) {
                    wp_send_json_error($parsed_topics['error']);
                } else {
                    wp_send_json_error('No topics found in the uploaded file');
                }
            }

            // Prepare preview settings (with start_date so user sees scheduled preview)
            // @FIX 1.4.9.48: mirror the sidebar controls the upload sent so the
            // preview notes reflect what will actually be applied on import.
            $preview_settings = array(
                'start_date' => gmdate('Y-m-d'),
                'publish_time' => sanitize_text_field($_POST['publish_time'] ?? '09:00'),
                'publish_frequency' => sanitize_text_field($_POST['publish_frequency'] ?? 'daily'),
                'videos_per_day' => 3,
                'video_per_topic' => isset($_POST['video_per_topic']) ? max(1, absint($_POST['video_per_topic'])) : 1,
                'questions_per_video' => isset($_POST['questions_per_video']) ? max(1, absint($_POST['questions_per_video'])) : 5,
                'save_mode' => sanitize_text_field($_POST['save_mode'] ?? 'r2_buffer'),
                'brand_name' => 'TheQuizWire',
                'logo_position' => 'all',
                'buffer_channels' => VS_Buffer_Client::get_valid_saved_channel_ids(),
                'template' => sanitize_text_field($_POST['style_template'] ?? 'trivia'),
                'hook_visible' => isset($_POST['hook_visible']) ? sanitize_text_field($_POST['hook_visible']) !== '0' : true,
                'cover_enabled' => isset($_POST['cover_enabled']) ? sanitize_text_field($_POST['cover_enabled']) !== '0' : true,
                'video_format' => sanitize_text_field($_POST['style_video_format'] ?? 'shorts'),
            );

            // If CSV topics already have publish_date/publish_time, don't override them in preview
            $processed_topics = VS_Excel_Importer::process_legacy_excel_content($parsed_topics, $preview_settings);

            $validation = VS_Excel_Importer::validate_topics($parsed_topics);

            // Determine if CSV has explicit dates/times
            $has_csv_dates = false;
            foreach ($processed_topics as $pt) {
                if (is_array($pt) && !empty($pt['publish_date']) && !empty($pt['publish_time']) && !empty($pt['_calendar_assigned'])) {
                    $has_csv_dates = true;
                    break;
                }
            }

            // Build notes conditionally
            // @FIX 1.4.9.48: reflect the actual sidebar toggles (hook + cover).
            $notes = array(
                'Font is auto-selected based on template',
                'Background video skipped (not working)',
                'Music skipped (TTS will be used)',
            );

            if (!empty($preview_settings['cover_enabled'])) {
                $notes[] = 'Cover page: ON (1s thumbnail card at start)';
            } else {
                $notes[] = 'Cover page: OFF — video starts directly with hook/question';
            }
            if (!empty($preview_settings['hook_visible'])) {
                $notes[] = 'Hook text: ON';
            } else {
                $notes[] = 'Hook text: OFF — question 1 starts immediately';
            }

            if ($has_csv_dates) {
                $notes[] = 'Scheduling: Using dates/times from CSV (auto-scheduled)';
            } else {
                $notes[] = 'Scheduling: ' . strtoupper($preview_settings['publish_frequency'] ?? 'daily') . ', ' . ($preview_settings['publish_time'] ?? '09:00') . ' (from sidebar)';
            }
            
            $notes[] = 'Save mode: ' . strtoupper($preview_settings['save_mode'] ?? 'r2_buffer');
            $notes[] = 'Brand: TheQuizWire';
            $notes[] = 'Format: ' . (($preview_settings['video_format'] ?? 'shorts') === 'youtube' ? 'YouTube 1920×1080' : 'Shorts 1080×1920');
            $notes[] = 'Questions: imported from CSV (no AI generation needed)';

            wp_send_json_success(array(
                'topics' => $parsed_topics,
                'processed_topics' => $processed_topics,
                'settings' => $preview_settings,
                'validation' => $validation,
                'topics_count' => count($parsed_topics),
                'preview_count' => count($processed_topics),
                'file_name' => $file['name'],
                'notes' => $notes,
            ));

        } catch (Exception $e) {
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log(
                    "Failed to preview Excel file: " . $e->getMessage(),
                    'error',
                    array(
                        'file' => $file['name'] ?? '',
                        'error' => $e->getMessage(),
                        'trace' => $e->getTraceAsString(),
                    )
                );
            }
            wp_send_json_error('Failed to preview file: ' . $e->getMessage());
        }
    }

    /**
     * Get global Studio render defaults for automatic content planner rendering.
     *
     * Reads branding (MCQVS_studio_branding), TTS provider, and builds a
     * voiceover config object that matches the browser Studio UI state.
     * Used by create_job_for_topic() and VS_Automation_Engine::run_daily_scheduler()
     * so preview, manual download, and automatic renders are identical.
     *
     * @return array Settings keys expected by VS_Headless_Renderer::render_job() normalization.
     */
    /**
     * @NEW 2026-08-11: Auto-pick a template for a topic/niche when none was explicitly set
     *       (CSV column, per-topic style or batch style all empty). This stops every
     *       Content Planner job from defaulting to 'trivia' — each topic now gets a
     *       thematically appropriate, readable template so the shorts look distinct.
     *
     * @param string $topic
     * @param string $niche  Optional niche label from the CSV/topic.
     * @return string Template id.
     */
    public static function guess_template_for_topic($topic, $niche = '')
    {
        $text = strtolower(trim((string) $topic) . ' ' . trim((string) $niche));

        $map = array(
            'science'    => array('science', 'physics', 'chemistry', 'biology', 'element', 'blood', 'brain', 'heart', 'skin', 'kidney', 'eye', 'human', 'plant', 'medicine', 'vaccine', 'dna', 'organ', 'cell'),
            'history'    => array('history', 'ancient', 'rome', 'egypt', 'civilization', 'empire', 'war', 'explorer', 'leader', 'greek', 'byzantine', 'viking', 'medieval', 'ottoman', 'persian', 'pharaoh', 'wwi', 'wwii', 'world war'),
            'nature'     => array('animal', 'bird', 'ocean', 'sea', 'nature', 'rainforest', 'weather', 'lightning', 'volcano', 'dinosaur', 'wildlife', 'desert', 'fish', 'mammal', 'insect', 'forest', 'mountain'),
            'space'      => array('space', 'planet', 'moon', 'solar', 'universe', 'star', 'saturn', 'jupiter', 'mars', 'galaxy', 'comet', 'asteroid', 'nebula'),
            'tech'       => array('tech', 'invention', 'it compan', 'computer', 'internet', 'software', 'ai ', 'robot', 'digital', 'founder', 'semiconductor', 'chip'),
            'sports'     => array('sport', 'olympic', 'record', 'football', 'cricket', 'fifa', 'nba', 'nfl', 'athlete', 'world cup'),
            'elegant'    => array('food', 'landmark', 'castle', 'art', 'museum', 'wonder', 'city', 'cuisine', 'dessert', 'monument'),
            'geography'  => array('geography', 'island', 'river', 'capital', 'border', 'time zone', 'country', 'continent', 'ocean'),
            'trivia'     => array('gk', 'quiz', 'trivia', 'general knowledge', 'current affair'),
        );

        foreach ($map as $tpl => $keys) {
            foreach ($keys as $k) {
                if (strpos($text, $k) !== false) {
                    return $tpl;
                }
            }
        }

        // Deterministic rotation across the readable set when nothing matched.
        $pool = array('history', 'nature', 'science', 'space', 'tech');
        $idx = abs(crc32($text)) % count($pool);
        return $pool[$idx];
    }

    public static function get_studio_render_defaults()
    {
        $branding = get_option('MCQVS_studio_branding', array());

        // Resolve voiceover provider: webspeech requires a browser, so switch to edge for server-side.
        $raw_provider = get_option('mcqvs_tts_provider', 'webspeech');
        $server_provider = ($raw_provider === 'webspeech') ? 'edge' : $raw_provider;

        $voiceover = array(
            // @FIX 1.4.9.49 (TTS SSOT): every knob reads from Settings — the Studio
            // seeds the same values, so Content Planner / headless / Studio agree.
            'enabled'              => (bool) get_option('mcqvs_tts_enabled', true),
            'provider'             => $server_provider,
            'voice'                => class_exists('VS_Settings') ? VS_Settings::get_next_rotation_voice() : 'en-US-AriaNeural',
            // @FIX 2026-08-11: Faster TTS (+20%) keeps question scenes short so a 5-Q
            //                  Short lands in the 25-40s window; users can still tune
            //                  rate per job in Studio.
            'rate'                 => (float) get_option('mcqvs_tts_rate', 1.2),
            'pitch'                => 0.0,
            'speakHook'            => (bool) get_option('mcqvs_tts_speak_hook', true),
            // @NEW 2026-08-11: Configurable — see Settings > Text-to-Speech > Speak Options Aloud.
            'speakOptions'         => get_option('mcqvs_tts_speak_options', true) ? true : false,
            'speakAnswer'          => (bool) get_option('mcqvs_tts_speak_answer', true),
            'speakCta'             => (bool) get_option('mcqvs_tts_speak_cta', false),
            'answerPhrase'         => 'correct answer is',
            'webspeechCapturedAudio' => true,
        );

        return array(
            'hookText'      => 'Can you score 5/5?',
            'hookVisible'   => true,
            'ctaText'       => sanitize_text_field($branding['cta_text'] ?? 'Comment your score 👇'),
            // @FIX 2026-08-11: score-challenge CTA is the shorts default (comments = #1
            //       seed-test signal). The renderer fills the X/X total dynamically.
            'ctaStyle'      => sanitize_text_field($branding['cta_style'] ?? 'score'),
            'brandName'     => sanitize_text_field($branding['brand_name'] ?? 'Quiz Master'),
            'quizName'      => sanitize_text_field($branding['quiz_name'] ?? ''),
            'logoPath'      => esc_url_raw($branding['logo_url'] ?? ''),
            'logoPosition'  => sanitize_text_field($branding['logo_pos'] ?? 'all'),
            'voiceover'     => $voiceover,
            'sfxEnabled'    => true,
            // @NEW 2026-08-11: Explanation bar toggle (default OFF — ultra-minimal Shorts).
            'showExplanation' => get_option('mcqvs_show_explanation', false) ? true : false,
        );
    }

    /**
     * Helper: Create Job
     */
    private function create_job_for_topic($topic, $questions, $item_styles = array())
    {
        $job_repo = VS_Job_Repository::init();

        $mcq_repo = VS_MCQ_Repository::get_instance();
        $existing = $mcq_repo->get_topic($topic);
        if ($existing && !empty($existing['id'])) {
            $topic_id = (int) $existing['id'];
        } else {
            $topic_id = $mcq_repo->create_topic($topic, 'planner_topic', 0);
            if ($topic_id === 0) {
                $topic_id = 0;
            }
        }

        $part_index = isset($item_styles['part_index']) ? absint($item_styles['part_index']) : 0;
        $part_total = isset($item_styles['part_total']) ? absint($item_styles['part_total']) : 0;

        $topic_label = $topic;
        if ($part_total > 1 && $part_index > 0) {
            $topic_label = $topic . ' - Part ' . $part_index . '/' . $part_total;
        }

        // @FIX: Merge global Studio defaults (branding, voiceover, sfx, hook/cta)
        //       so automatic renders match preview and manual download exactly.
        $studio_defaults = self::get_studio_render_defaults();

// @FIX 2026-08-07: CSV columns may be named 'hook' (alias for hookText). Also need
            // to sync hookText → hook so Buffer caption template ({hook} placeholder)
            // can use the CSV-provided hook. If AI already set 'hook', don't override.
            if (!empty($item_styles['hookText']) && empty($item_styles['hook'])) {
                $item_styles['hook'] = $item_styles['hookText'];
            }

            // @FIX 2026-08-11: SSOT reverse sync — the AI path stores the real hook in
            //       item_styles['hook'] but leaves hookText at the generic default, so the
            //       on-screen hook scene would render "Can you score 5/5?" while the caption
            //       gets the real hook. Promote the real hook to hookText so video and
            //       caption always agree.
            $generic_hooks = array('Can you score 5/5?', 'Can you score 3/3?');
            if (!empty($item_styles['hook']) && (empty($item_styles['hookText']) || in_array($item_styles['hookText'], $generic_hooks, true))) {
                $item_styles['hookText'] = sanitize_text_field($item_styles['hook']);
            }

            $job_settings = array(
                'topic_name' => $topic_label,
                'topic_base' => $topic,
                'part_index' => $part_index,
                'part_total' => $part_total,
                // @NEW 2026-08-01: AI-generated per-topic share metadata for Buffer captions.
                //       Normalized at generation time; empty means "omit from caption".
                'hashtags'   => isset($item_styles['hashtags']) ? sanitize_text_field($item_styles['hashtags']) : '',
                'hook'       => isset($item_styles['hook']) ? sanitize_text_field($item_styles['hook']) : '',
            // @FIX 2026-08-11: Auto-pick template by topic/niche when not explicitly set
            //       (CSV `template` column, per-topic style or batch style). No more
            //       silent 'trivia' default — every job gets a themed, readable template.
            'template' => sanitize_text_field(
                !empty($item_styles['template'])
                    ? $item_styles['template']
                    : self::guess_template_for_topic($topic, isset($item_styles['niche']) ? $item_styles['niche'] : '')
            ),
            'font' => sanitize_text_field($item_styles['font'] ?? ''),
            'music' => sanitize_text_field($item_styles['music'] ?? ''),
            'bg_video' => sanitize_text_field($item_styles['bg_video'] ?? ''),
            'save_mode' => sanitize_text_field($item_styles['save_mode'] ?? 'local'),
            // Branding (from MCQVS_studio_branding option)
            'hookText'   => sanitize_text_field($item_styles['hookText'] ?? $studio_defaults['hookText']),
            'hookVisible' => isset($item_styles['hookVisible']) ? (bool) $item_styles['hookVisible'] : $studio_defaults['hookVisible'],
            'ctaText'    => sanitize_text_field($item_styles['ctaText'] ?? $studio_defaults['ctaText']),
            'brandName'  => sanitize_text_field($item_styles['brandName'] ?? $studio_defaults['brandName']),
            // @FIX: Default quizName to the topic label (per-topic) instead of the
            //       global branding quiz_name (e.g. "Biology"). The global is a
            //       Studio-wide branding overlay; content-planner jobs should show
            //       the actual topic name unless explicitly overridden.
            'quizName'   => sanitize_text_field($item_styles['quizName'] ?? $topic_label ?: $studio_defaults['quizName']),
            'logoPath'   => esc_url_raw($item_styles['logoPath'] ?? $studio_defaults['logoPath']),
            'logoPosition' => sanitize_text_field($item_styles['logoPosition'] ?? $studio_defaults['logoPosition'] ?? 'all'),
            // Voiceover (server-side TTS: edge provider, not webspeech)
            'voiceover'  => !empty($item_styles['voiceover']) ? $item_styles['voiceover'] : $studio_defaults['voiceover'],
            // SFX
            'sfxEnabled' => !empty($item_styles['sfxEnabled']) ? (bool) $item_styles['sfxEnabled'] : $studio_defaults['sfxEnabled'],
            // @NEW 2026-08-11: Explanation bar toggle (Settings > Defaults & Scheduling, default OFF).
            'showExplanation' => isset($item_styles['showExplanation']) ? (bool) $item_styles['showExplanation'] : $studio_defaults['showExplanation'],
            // Cover config (bg_color, badge_style, brand_size, show_logo)
            // @FIX 2026-08-13 (COVER E2E): ALWAYS set cover_config.enabled so the
            //       renderer's cover-scene gate (coverConfig.enabled !== false) is
            //       deterministic. Some job-creation paths (e.g. Saved Questions Bank →
            //       Generate Video / ajax_planner_compose_video) never thread a
            //       cover_config, leaving coverCfg.enabled undefined — the renderer then
            //       ALWAYS added the cover scene regardless of the "Show Cover Page"
            //       toggle. Fall back to the persisted planner toggle as the single
            //       source of truth so every job honors the user's choice.
            'cover_config' => (function () use ($item_styles) {
                $cc = (!empty($item_styles['cover_config']) && is_array($item_styles['cover_config']))
                    ? $item_styles['cover_config']
                    : array();
                if (!isset($cc['enabled'])) {
                    $cc['enabled'] = (bool) get_option('mcqvs_planner_cover_enabled', true);
                }
                return $cc;
            })(),
            // @FIX: Per-job video format so headless renderer uses this instead of global mcqvs_video_format.
            //       Defaults to 'shorts' (Content Planner's primary use case).
            'save_mode_video_format' => sanitize_text_field($item_styles['video_format'] ?? 'shorts'),
        );

        $delivery_mode = get_option('mcqvs_delivery_mode', 'local');
        if (!empty($item_styles['save_mode']) && in_array($item_styles['save_mode'], array('local', 'r2', 'r2_buffer'), true)) {
            $job_settings['save_mode'] = $item_styles['save_mode'];
        } else {
            $job_settings['save_mode'] = $delivery_mode;
        }

        // @NEW 2026-05-07: Compute publish_at from scheduling parameters
        // @FIX 2026-07-06: Prevent state loss on batch retry by storing compute intent
        // @MODIFIED 2026-07-26: Calendar-aware scheduling — per-topic publish_date overrides linear offset.
        // Flexible frequency: supports N videos per day (e.g. 2x_daily = 2, 3x_daily = 3).
        $publish_at = null;
        $topic_publish_date = $item_styles['publish_date'] ?? '';
        $publish_time = $item_styles['publish_time'] ?? '09:00';
        $publish_frequency = $item_styles['publish_frequency'] ?? 'daily';

        if (!empty($topic_publish_date)) {
            // CALENDAR PATH: Topic has explicit date + time from the calendar UI or CSV import.
            // Use per-topic time; only fall back to global if genuinely empty.
            if (empty($publish_time)) {
                $global_time = get_option('mcqvs_default_publish_time', '');
                if (!empty($global_time)) {
                    $publish_time = $global_time;
                }
            }
            // Compute UTC from site-local time using the site's timezone setting.
            $publish_at = self::compute_publish_at($topic_publish_date, $publish_time, 'daily', 0);
            $job_settings['publish_time'] = $publish_time;
            $job_settings['_publish_computed_at'] = gmdate('Y-m-d H:i:s');
            $job_settings['_calendar_assigned'] = true;
        } else {
            // LINEAR PATH: Fallback to existing offset-based scheduling for backward compat.
            // Supports flexible frequency: "2x_daily", "3x_daily" etc. parsed as N-per-day.
            $publish_start_date = $item_styles['publish_start_date'] ?? '';
            if (!empty($publish_start_date)) {
                $publish_day_offset = absint($item_styles['_publish_day_offset'] ?? 0);
                if (empty($publish_time)) {
                    $global_time = get_option('mcqvs_default_publish_time', '');
                    if (!empty($global_time)) {
                        $publish_time = $global_time;
                    }
                }
                if (empty($publish_frequency) || $publish_frequency === 'daily') {
                    $global_freq = get_option('mcqvs_publish_frequency', '');
                    if (!empty($global_freq)) {
                        $publish_frequency = $global_freq;
                    }
                }
                $publish_at = self::compute_publish_at($publish_start_date, $publish_time, $publish_frequency, $publish_day_offset);
                $job_settings['publish_frequency'] = $publish_frequency;
                $job_settings['publish_time'] = $publish_time;
                // @FIX: Stamp compute intent to detect stale publish_at on retries
                $job_settings['_publish_computed_at'] = gmdate('Y-m-d H:i:s');
                $job_settings['_publish_start_date'] = $publish_start_date;
                $job_settings['_publish_offset'] = $publish_day_offset;
            }
        }

        // Buffer channel selection (used when save_mode === r2_buffer for publish step)
        if ($job_settings['save_mode'] === 'r2_buffer') {
            $buffer_channels_json = $item_styles['buffer_channels'] ?? '';
            $buffer_channels = json_decode($buffer_channels_json, true);
            if (is_array($buffer_channels) && !empty($buffer_channels)) {
                $job_settings['buffer_channels'] = $buffer_channels;
            } elseif (empty($buffer_channels)) {
                $saved_channels = json_decode(get_option('mcqvs_buffer_channels', '[]'), true);
                if (is_array($saved_channels) && !empty($saved_channels)) {
                    $job_settings['buffer_channels'] = $saved_channels;
                }
            }
            // @NEW 2026-08-01 (multi-account): Store which Buffer account this job targets.
            // Empty = fan out to all active accounts.
            $buffer_account_id = $item_styles['buffer_account_id'] ?? '';
            if ($buffer_account_id !== '') {
                $job_settings['buffer_account_id'] = sanitize_key($buffer_account_id);
            }
        }

        // @FIX (cross-file audit): Stamp every job in this batch with the same `parent_batch_id`
        //       so the headless renderer queue (`run_headless_render_queue`) can filter by
        //       "active batch" instead of picking up stray `READY_FOR_RENDER` rows from a
        //       previous retry-cycle. Uses the existing `vs_jobs.parent_batch_id` column +
        //       `idx_parent_batch` index — no schema migration needed.
        $batch_uuid = get_option('mcqvs_content_plan_pending_batches', '');
        if (!is_string($batch_uuid) || strlen($batch_uuid) !== 36) {
            $batch_uuid = function_exists('wp_generate_uuid4') ? wp_generate_uuid4() : sprintf(
                '%08x-%04x-%04x-%04x-%012x',
                wp_rand(0, 0xffffffff),
                wp_rand(0, 0xffff),
                wp_rand(0, 0xffff),
                wp_rand(0, 0xffff),
                wp_rand(0, 0xffffffffffff)
            );
            update_option('mcqvs_content_plan_pending_batches', $batch_uuid);
        }
        $job_settings['_parent_batch_id'] = $batch_uuid;

        $job_data = array(
            'topic_id' => $topic_id,
            'question_count' => count($questions),
            'platform' => 'all',
            'status' => VS_Job_Status::READY_FOR_RENDER,
            'quiz_data' => wp_json_encode($questions),
            'settings' => wp_json_encode($job_settings),
            'scheduled_at' => gmdate('Y-m-d H:i:s'),
            'parent_batch_id' => $batch_uuid,
        );
        // @FIX 2026-07-22: Persist publish_at at job creation so server-rendered
        // r2_buffer jobs are visible to the publish scheduler. Without this,
        // jobs sit in 'completed' forever because get_jobs_ready_for_publish()
        // requires publish_at IS NOT NULL.
        if (!empty($publish_at)) {
            $job_data['publish_at'] = $publish_at;
        }
        // @NEW 2026-08-03: Calendar-based render scheduling.
        // If topic has explicit calendar date, schedule render to complete BEFORE publish time.
        // We set scheduled_at to publish_at minus a render buffer (default 30 minutes).
        // The job will stay in PENDING until scheduled_at, then transition to READY_FOR_RENDER.
        if (!empty($topic_publish_date) && !empty($publish_at)) {
            $render_buffer_minutes = absint(get_option('mcqvs_render_buffer_minutes', 30));
            if ($render_buffer_minutes < 5) $render_buffer_minutes = 30;
            $render_at = gmdate('Y-m-d H:i:s', strtotime($publish_at . ' UTC') - ($render_buffer_minutes * 60));
            $job_data['status'] = VS_Job_Status::PENDING;
            $job_data['scheduled_at'] = $render_at;
            $job_settings['_calendar_render_scheduled'] = true;
            $job_settings['_render_at'] = $render_at;
            $job_data['settings'] = wp_json_encode($job_settings);
        }
        $job_id = $job_repo->create_job($job_data);

        if (is_wp_error($job_id)) {
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log("Failed to create job record for topic '{$topic}'.", 'error', array(
                    'topic' => $topic,
                    'error' => $job_id->get_error_message(),
                    'source' => 'Content Planner'
                ));
            }
            return false;
        }

        // @FIX 2026-08-06: Schedule vs_process_job_event for calendar-scheduled PENDING jobs
        // so they transition to READY_FOR_RENDER at their scheduled_at time.
        // Without this, jobs stuck in PENDING forever (headless queue only picks READY_FOR_RENDER).
        if (!empty($topic_publish_date) && !empty($publish_at) && $job_data['status'] === VS_Job_Status::PENDING) {
            $scheduled_at = $job_data['scheduled_at'] ?? '';
            if ($scheduled_at) {
                // Schedule at or slightly before scheduled_at to ensure timely transition
                $cron_time = strtotime($scheduled_at . ' UTC');
                if ($cron_time > time()) {
                    wp_schedule_single_event($cron_time, 'vs_process_job_event', array($job_id));
                } else {
                    // If scheduled_at is in the past, trigger immediately via AS or WP cron
                    if (function_exists('as_enqueue_async_action')) {
                        as_enqueue_async_action('vs_process_job_event', array($job_id), 'mcq-video-studio');
                    } else {
                        wp_schedule_single_event(time(), 'vs_process_job_event', array($job_id));
                    }
                }
                if (class_exists('VS_Error_Logger')) {
                    VS_Error_Logger::get_instance()->log_pipeline(
                        'job.cron_scheduled',
                        'completed',
                        $job_id,
                        "Scheduled vs_process_job_event for calendar job at {$scheduled_at}",
                        'info',
                        array('job_id' => $job_id, 'scheduled_at' => $scheduled_at, 'publish_at' => $publish_at)
                    );
                }
            }
        }

        // @NEW 2026-07-10: Persist generated MCQs into dedicated bank so they survive failed jobs
        // and can be reused by the new Content Planner Data Source Card.
        // Mirrors the Topic Card / News Card contract in class-vs-ajax-ai-quiz-handler.php.
        // Tolerates validation failures to match Studio behavior (no batch abort).
        $bank_question_ids = array();
        $bank_saved_count  = 0;
        $bank_skipped_dup  = 0;
        if ($topic_id > 0 && !empty($questions) && is_array($questions)) {
            $batch_uuid = isset($job_settings['_parent_batch_id']) ? (string) $job_settings['_parent_batch_id'] : '';
            foreach ($questions as $q) {
                if (!is_array($q)) {
                    continue;
                }
                $q_text = isset($q['question']) ? (string) $q['question'] : '';
                if ($q_text === '') {
                    continue;
                }
                $opts = isset($q['options']) && is_array($q['options']) ? array_values($q['options']) : array('', '', '', '');
                $result = $mcq_repo->insert_mcq(array(
                    'question_text'   => $q_text,
                    'options'         => $opts,
                    'correct_index'   => isset($q['correct']) ? (int) $q['correct'] : 0,
                    'topic_id'        => (int) $topic_id,
                    'status'          => 'approved',
                    'source_ref'      => 'planner_batch',
                    'difficulty'      => 'medium',
                    'parent_post_id'  => null,
                ));
                if (is_wp_error($result)) {
                    if ($result->get_error_code() === 'duplicate_mcq') {
                        $err_data = $result->get_error_data();
                        if (!empty($err_data['id'])) {
                            $bank_question_ids[] = (int) $err_data['id'];
                        }
                        $bank_skipped_dup++;
                    } elseif (class_exists('VS_Error_Logger')) {
                        VS_Error_Logger::get_instance()->log('Planner: skipped MCQ (validation/insert error)', 'warning', array(
                            'topic'       => $topic,
                            'error_code'  => $result->get_error_code(),
                            'error'       => $result->get_error_message(),
                            'source'      => 'Content Planner',
                        ));
                    }
                } else {
                    $bank_question_ids[] = (int) $result;
                    $bank_saved_count++;
                }
            }
            // Persist bank IDs on job settings so audits / replay can trace them.
            if (!empty($bank_question_ids)) {
                $job_settings['bank_question_ids'] = $bank_question_ids;
                $job_settings['bank_source_ref']   = 'planner_batch';
                $job_settings['bank_saved_count']  = $bank_saved_count;
                $job_settings['bank_skipped_dup']  = $bank_skipped_dup;
                if (!empty($batch_uuid)) {
                    $job_settings['bank_batch_id'] = $batch_uuid;
                }
                $job_repo->update_job_fields($job_id, array(
                    'settings' => wp_json_encode($job_settings),
                ));
            }
            if (class_exists('VS_Error_Logger') && ($bank_saved_count > 0 || $bank_skipped_dup > 0)) {
                VS_Error_Logger::get_instance()->log_pipeline(
                    'bank.persisted',
                    'completed',
                    $job_id,
                    "Saved {$bank_saved_count} MCQs to bank (skipped {$bank_skipped_dup} duplicates) for topic '{$topic}'",
                    'info',
                    array(
                        'job_id'           => $job_id,
                        'topic'            => $topic,
                        'topic_id'         => $topic_id,
                        'saved_count'      => $bank_saved_count,
                        'skipped_dup'      => $bank_skipped_dup,
                        'bank_question_ids'=> $bank_question_ids,
                    )
                );
            }
        }

        // @NEW 2026-05-07: Set publish_at on the job record
        // @FIX 2026-07-06: Verify publish_at intent matches before updating
        if ($publish_at) {
            $existing_job = $job_repo->get_job($job_id);
            $existing_settings = is_string($existing_job['settings'] ?? '') ? json_decode($existing_job['settings'], true) : ($existing_job['settings'] ?? array());
            $intent_matches = true;
            
            if (!empty($existing_settings['_publish_start_date']) && $existing_settings['_publish_start_date'] !== $publish_start_date) {
                $intent_matches = false;
                if (class_exists('VS_Error_Logger')) {
                    VS_Error_Logger::get_instance()->log("publish_at intent mismatch for job {$job_id}: start_date changed from {$existing_settings['_publish_start_date']} to {$publish_start_date}. Recomputing.", 'warning', array('job_id' => $job_id));
                }
            }
            if (!empty($existing_settings['_publish_offset']) && $existing_settings['_publish_offset'] !== $publish_day_offset) {
                $intent_matches = false;
                if (class_exists('VS_Error_Logger')) {
                    VS_Error_Logger::get_instance()->log("publish_at intent mismatch for job {$job_id}: offset changed from {$existing_settings['_publish_offset']} to {$publish_day_offset}. Recomputing.", 'warning', array('job_id' => $job_id));
                }
            }
            
            // Only update if intent matches OR this is first creation (no existing intent)
            if ($intent_matches || empty($existing_settings['_publish_computed_at'])) {
                $job_repo->update_publish_at($job_id, $publish_at);
            } elseif (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log("Skipped publish_at update for job {$job_id}: existing intent is current.", 'info', array('job_id' => $job_id));
            }
        }

        if (class_exists('VS_Error_Logger')) {
            VS_Error_Logger::get_instance()->log("Successfully created Job {$job_id} for topic '{$topic}'.", 'info', array(
                'job_id' => $job_id,
                'topic' => $topic,
                'publish_at' => $publish_at,
                'source' => 'Content Planner'
            ));
            VS_Error_Logger::get_instance()->log_pipeline(
                'job.settings',
                'completed',
                $job_id,
                "Job {$job_id} settings: template={$job_settings['template']}, font={$job_settings['font']}, music={$job_settings['music']}, bg_video={$job_settings['bg_video']}, save_mode={$job_settings['save_mode']}, publish_at=" . (!empty($publish_at) ? wp_date('Y-m-d H:i:s', strtotime($publish_at . ' UTC')) . ' (site local) / ' . $publish_at . ' (UTC)' : 'null'),
                'info',
                array(
                    'job_id'          => $job_id,
                    'settings'        => $job_settings,
                    'publish_at'      => $publish_at,
                    'question_count'  => count($questions),
                )
            );
        }

        return $job_id;
    }

    public static function compute_publish_at($start_date, $publish_time, $frequency, $offset_days = 0)
    {
        // @FIX 2026-08-03: Always use the WordPress site timezone (Settings > General > Timezone)
        //       for publish_at computation. The separate mcqvs_publish_timezone setting caused
        //       mismatches between what users entered (site local time) and what was stored/displayed.
        //       wp_timezone() returns a proper DateTimeZone object handling BOTH named timezones
        //       AND manual UTC offsets (e.g. UTC+5). wp_timezone_string() returns 'UTC+05:00'
        //       for manual offsets which can throw on some PHP builds; wp_timezone() never does.
        try {
            $user_tz = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('UTC');
        } catch (Exception $e) {
            $user_tz = new DateTimeZone('UTC');
        }

        try {
            $dt = new DateTime($start_date . ' ' . $publish_time . ':00', $user_tz);
        } catch (Exception $e) {
            return null;
        }

        $video_ordinal = absint($offset_days);

        // @MODIFIED 2026-07-26: Flexible frequency — supports "Nx_daily" (e.g. 2x_daily, 3x_daily).
        // Parses the leading number, divides the day into N equal slots.
        if (preg_match('/^(\d+)x[_\s]?daily$/i', $frequency, $m)) {
            $per_day = max(1, (int) $m[1]);
            $day_index = intdiv($video_ordinal, $per_day);
            $slot_index = $video_ordinal % $per_day;
            $slot_interval = floor(DAY_IN_SECONDS / $per_day);
            $offset_seconds = ($day_index * DAY_IN_SECONDS) + ($slot_index * $slot_interval);
        } else {
            switch ($frequency) {
                case 'twice_daily':
                    $day_index = intdiv($video_ordinal, 2);
                    $slot_index = $video_ordinal % 2;
                    $offset_seconds = ($day_index * DAY_IN_SECONDS) + ($slot_index * 12 * HOUR_IN_SECONDS);
                    break;
                case 'every_3_days':
                    $offset_seconds = $video_ordinal * 3 * DAY_IN_SECONDS;
                    break;
                case 'weekly':
                    $offset_seconds = $video_ordinal * WEEK_IN_SECONDS;
                    break;
                case 'asap':
                    $offset_seconds = 0;
                    break;
                case 'daily':
                default:
                    $offset_seconds = $video_ordinal * DAY_IN_SECONDS;
                    break;
            }
        }

        $dt->modify("+{$offset_seconds} seconds");
        $dt->setTimezone(new DateTimeZone('UTC'));
        return $dt->format('Y-m-d H:i:s');
    }



    /**
     * AJAX: Get calendar view data — topics assigned to dates for a given month.
     * @NEW 2026-07-26
     */
    public function ajax_get_calendar_data()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        $month = absint($_POST['month'] ?? gmdate('n'));
        $year  = absint($_POST['year']  ?? gmdate('Y'));

        if ($month < 1 || $month > 12 || $year < 2020 || $year > 2030) {
            wp_send_json_error('Invalid month/year');
        }

        $plan = get_option('mcqvs_content_plan', array());
        if (!is_array($plan)) $plan = array();

        $assignments = array();
        foreach ($plan as $idx => $item) {
            $topic_name = is_string($item) ? $item : ($item['topic'] ?? '');
            $pub_date   = is_array($item) ? ($item['publish_date'] ?? '') : '';
            $pub_time   = is_array($item) ? ($item['publish_time'] ?? '09:00') : '09:00';

            if (empty($topic_name)) continue;

            $assignments[] = array(
                'index'            => $idx,
                'topic'            => $topic_name,
                'publish_date'     => $pub_date,
                'publish_time'     => $pub_time,
                'template'         => is_array($item) ? ($item['template'] ?? '') : '',
                'font'             => is_array($item) ? ($item['font'] ?? '') : '',
                'music'            => is_array($item) ? ($item['music'] ?? '') : '',
                'bg_video'         => is_array($item) ? ($item['bg_video'] ?? '') : '',
                // @NEW 2026-08-17: Include bank-composed flags for frontend delete handling
                '_bank_composed'   => is_array($item) && !empty($item['_bank_composed']),
                '_job_id'          => is_array($item) ? ($item['_job_id'] ?? '') : '',
            );
        }

        // Fetch existing jobs for this month to show publish status on calendar
        global $wpdb;
        $table = $wpdb->prefix . 'vs_jobs';
        $start = sprintf('%04d-%02d-01', $year, $month);
        $days_in_month = date('t', mktime(0, 0, 0, $month, 1, $year));
        $end = sprintf('%04d-%02d-%02d 23:59:59', $year, $month, $days_in_month);

        $jobs = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT j.job_id, j.status, j.publish_at, j.settings, j.video_url,
                        COALESCE(t.name, CONCAT('Topic #', j.topic_id)) AS topic_name
                 FROM {$table} j
                 LEFT JOIN {$wpdb->prefix}vs_topics t ON j.topic_id = t.id
                 WHERE j.publish_at BETWEEN %s AND %s
                 ORDER BY j.publish_at ASC",
                $start, $end
            ),
            ARRAY_A
        );

        wp_send_json_success(array(
            'assignments' => $assignments,
            'jobs'        => $jobs ?: array(),
            'month'       => $month,
            'year'        => $year,
        ));
    }

    /**
     * AJAX: Save calendar date assignments for topics.
     * @NEW 2026-07-26
     */
    public function ajax_save_calendar_assignments()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        $assignments_raw = $_POST['assignments'] ?? '';
        $assignments = json_decode(stripslashes($assignments_raw), true);
        if (!is_array($assignments)) {
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log(
                    'save_calendar: invalid assignments data',
                    'error',
                    array('raw' => substr($assignments_raw, 0, 500), 'json_err' => json_last_error_msg())
                );
            }
            wp_send_json_error('Invalid assignments data');
        }

        $plan = get_option('mcqvs_content_plan', array());
        if (!is_array($plan)) $plan = array();

        $saved = 0;
        $jobs_restamped = 0;
        $topics_resolved = 0;

        foreach ($assignments as $a) {
            $idx = absint($a['index'] ?? -1);
            if ($idx < 0 || $idx >= count($plan)) continue;

            $item = $plan[$idx];
            if (is_string($item)) {
                $item = array('topic' => $item);
            }

            if (!empty($a['publish_date'])) {
                $item['publish_date'] = sanitize_text_field($a['publish_date']);
                $item['publish_time'] = sanitize_text_field($a['publish_time'] ?? '09:00');
                $saved++;
            } else {
                unset($item['publish_date']);
                unset($item['publish_time']);
            }
            $plan[$idx] = $item;

            // @FIX 1.4.9.50 (E2E): the Pipeline Jobs card reads vs_jobs.publish_at,
            // NOT the plan option. Dragging a topic to a new date previously only
            // updated mcqvs_content_plan, so the card kept showing the OLD date.
            // Now we re-stamp every schedulable job for that topic: publish_at,
            // scheduled_at (publish - render buffer) and the vs_process_job_event
            // cron, so today's/upcoming rows reflect the drag immediately.
            if (!empty($item['topic'])) {
                $topic_name = (string) $item['topic'];
                $topic_id = 0;
                if (class_exists('VS_MCQ_Repository')) {
                    $t = VS_MCQ_Repository::get_instance()->get_topic($topic_name);
                    $topic_id = ($t && !empty($t['id'])) ? (int) $t['id'] : 0;
                }
                if ($topic_id > 0) {
                    $topics_resolved++;
                    $jobs = VS_Job_Repository::init()->get_schedulable_jobs_by_topic($topic_id);
                    if (!empty($jobs)) {
                        $publish_at = self::compute_publish_at(
                            isset($item['publish_date']) ? $item['publish_date'] : gmdate('Y-m-d'),
                            isset($item['publish_time']) ? $item['publish_time'] : '09:00',
                            isset($item['publish_frequency']) ? $item['publish_frequency'] : 'daily',
                            0
                        );
                        if (!empty($publish_at)) {
                            $render_buffer_minutes = absint(get_option('mcqvs_render_buffer_minutes', 30));
                            if ($render_buffer_minutes < 5) $render_buffer_minutes = 30;
                            $render_at = gmdate('Y-m-d H:i:s', strtotime($publish_at . ' UTC') - ($render_buffer_minutes * 60));

                            foreach ($jobs as $job) {
                                $job_id = $job['job_id'];
                                $job_repo = VS_Job_Repository::init();
                                // publish_at + scheduled_at columns
                                $job_repo->update_publish_at($job_id, $publish_at);
                                $job_repo->update_job_fields($job_id, array('scheduled_at' => $render_at));
                                $jobs_restamped++;

                                // keep job settings' calendar metadata in sync
                                $jsettings = is_string($job['settings']) ? json_decode($job['settings'], true) : (is_array($job['settings']) ? $job['settings'] : array());
                                if (is_array($jsettings)) {
                                    $jsettings['_render_at'] = $render_at;
                                    $jsettings['_calendar_render_scheduled'] = true;
                                    if (isset($item['publish_date'])) $jsettings['publish_date'] = $item['publish_date'];
                                    if (isset($item['publish_time'])) $jsettings['publish_time'] = $item['publish_time'];
                                    $job_repo->update_job_fields($job_id, array('settings' => wp_json_encode($jsettings)));
                                }

                                // reschedule the pending -> ready_for_render transition
                                if (($job['status'] ?? '') === VS_Job_Status::PENDING) {
                                    if (function_exists('wp_clear_scheduled_hook')) {
                                        wp_clear_scheduled_hook('vs_process_job_event', array($job_id));
                                    }
                                    $cron_time = strtotime($render_at . ' UTC');
                                    if ($cron_time > time()) {
                                        wp_schedule_single_event($cron_time, 'vs_process_job_event', array($job_id));
                                    } else {
                                        if (function_exists('as_enqueue_async_action')) {
                                            as_enqueue_async_action('vs_process_job_event', array($job_id), 'mcq-video-studio');
                                        } else {
                                            wp_schedule_single_event(time(), 'vs_process_job_event', array($job_id));
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        $updated = update_option('mcqvs_content_plan', $plan);
        if (class_exists('VS_Error_Logger')) {
            VS_Error_Logger::get_instance()->log(
                'save_calendar: completed',
                'info',
                array(
                    'saved'           => $saved,
                    'updated'         => $updated,
                    'plan_count'      => count($plan),
                    'topics_resolved' => $topics_resolved,
                    'jobs_restamped'  => $jobs_restamped,
                )
            );
        }
        wp_send_json_success(array(
            'saved'          => $saved,
            'jobs_restamped' => $jobs_restamped,
        ));
    }

    /**
     * AJAX: Auto-assign topics to calendar dates based on flexible frequency.
     * Supports N-per-day: "2x_daily", "3x_daily", etc.
     * @NEW 2026-07-26
     */
    public function ajax_auto_assign_calendar()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        $start_date   = sanitize_text_field($_POST['start_date'] ?? '');
        $frequency    = sanitize_text_field($_POST['frequency'] ?? 'daily');
        $publish_time = sanitize_text_field($_POST['publish_time'] ?? '09:00');
        $times_json   = stripslashes($_POST['times_per_day'] ?? '');

        if (empty($start_date)) {
            wp_send_json_error('Start date is required');
        }

        $plan = get_option('mcqvs_content_plan', array());
        if (!is_array($plan) || empty($plan)) {
            wp_send_json_error('No topics in plan');
        }

        // @FIX 2026-08-03: Always use WordPress site timezone for consistency
        try {
            $user_tz = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('UTC');
        } catch (Exception $e) {
            $user_tz = new DateTimeZone('UTC');
        }

        // Parse per-day slot count from frequency or custom times array
        $per_day = 1;
        if (preg_match('/^(\d+)x[_\s]?daily$/i', $frequency, $m)) {
            $per_day = max(1, (int) $m[1]);
        } elseif ($frequency === 'twice_daily') {
            $per_day = 2;
        }

        // Custom times per day (e.g. ["09:00", "17:00"])
        $custom_times = json_decode($times_json, true);
        if (!is_array($custom_times) || empty($custom_times)) {
            // Generate evenly-spaced default times
            $custom_times = array();
            $slot_interval = floor(24 / $per_day);
            for ($s = 0; $s < $per_day; $s++) {
                $hour = ($s * $slot_interval) + 9; // Start at 09:00
                if ($hour >= 24) $hour -= 24;
                $custom_times[] = sprintf('%02d:00', $hour);
            }
        }

        $dt = new DateTime($start_date . ' ' . $custom_times[0] . ':00', $user_tz);

        $slot_counter = 0;
        foreach ($plan as $idx => $item) {
            $topic_name = is_string($item) ? $item : ($item['topic'] ?? '');
            if (empty($topic_name)) continue;

            // @FIX: Skip topics that already have explicit publish_date + publish_time
            // (e.g. imported from CSV with per-topic scheduling)
            if (is_array($item) && !empty($item['publish_date']) && !empty($item['publish_time'])
                && !empty($item['_calendar_assigned'])) {
                continue;
            }

            $day_index = intdiv($slot_counter, $per_day);
            $slot_index = $slot_counter % $per_day;

            $offset_seconds = $day_index * DAY_IN_SECONDS;

            $assigned = clone $dt;
            $assigned->modify("+{$offset_seconds} seconds");

            // Use the slot-specific time
            $slot_time = $custom_times[$slot_index] ?? $custom_times[0];
            list($h, $min) = explode(':', $slot_time);
            $assigned->setTime((int) $h, (int) $min, 0);
            $assigned->setTimezone($user_tz);

            if (is_string($item)) {
                $item = array('topic' => $item);
            }
            $item['publish_date'] = $assigned->format('Y-m-d');
            $item['publish_time'] = $assigned->format('H:i');
            $plan[$idx] = $item;

            $slot_counter++;
        }

        update_option('mcqvs_content_plan', $plan);
        wp_send_json_success(array(
            'assigned'  => $slot_counter,
            'start'     => $start_date,
            'frequency' => $frequency,
            'per_day'   => $per_day,
        ));
    }

    /**
     * AJAX: Delete a calendar assignment by plan index.
     * For bank-composed topics (_bank_composed=true), also deletes the associated job.
     * @NEW 2026-08-17
     */
    public function ajax_delete_calendar_assignment()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        $index = isset($_POST['index']) ? absint($_POST['index']) : -1;
        $delete_job = isset($_POST['delete_job']) ? (bool) $_POST['delete_job'] : false;

        $plan = get_option('mcqvs_content_plan', array());
        if (!is_array($plan) || $index < 0 || $index >= count($plan)) {
            wp_send_json_error('Invalid index');
        }

        $item = $plan[$index];
        $topic_name = is_array($item) ? ($item['topic'] ?? '') : $item;
        $job_id = is_array($item) ? ($item['_job_id'] ?? '') : '';
        $is_bank_composed = is_array($item) && !empty($item['_bank_composed']);

        // Remove from plan
        array_splice($plan, $index, 1);
        update_option('mcqvs_content_plan', $plan);

        $job_deleted = false;
        // If bank-composed and delete_job requested, delete the associated job
        if ($is_bank_composed && $delete_job && $job_id) {
            if (class_exists('VS_Job_Repository')) {
                $job_repo = VS_Job_Repository::init();
                // Clear any scheduled cron before deleting
                if (function_exists('wp_clear_scheduled_hook')) {
                    wp_clear_scheduled_hook('vs_process_job_event', array($job_id));
                }
                $job_deleted = (bool) $job_repo->delete_job($job_id);
            }
        }

        // Also unassign any jobs for this topic if not bank-composed (standard behavior)
        if (!$is_bank_composed && !empty($topic_name)) {
            $topic_id = 0;
            if (class_exists('VS_MCQ_Repository')) {
                $t = VS_MCQ_Repository::get_instance()->get_topic($topic_name);
                $topic_id = ($t && !empty($t['id'])) ? (int) $t['id'] : 0;
            }
            if ($topic_id > 0) {
                $jobs = VS_Job_Repository::init()->get_schedulable_jobs_by_topic($topic_id);
                if (!empty($jobs)) {
                    foreach ($jobs as $job) {
                        $job_repo = VS_Job_Repository::init();
                        $job_repo->update_publish_at($job['job_id'], null);
                        $job_repo->update_job_fields($job['job_id'], array('scheduled_at' => gmdate('Y-m-d H:i:s')));
                        // Clear calendar metadata
                        $jsettings = is_string($job['settings']) ? json_decode($job['settings'], true) : (is_array($job['settings']) ? $job['settings'] : array());
                        if (is_array($jsettings)) {
                            unset($jsettings['_render_at'], $jsettings['_calendar_render_scheduled'], $jsettings['publish_date'], $jsettings['publish_time']);
                            $job_repo->update_job_fields($job['job_id'], array('settings' => wp_json_encode($jsettings)));
                        }
                        // Clear any scheduled cron
                        if (function_exists('wp_clear_scheduled_hook')) {
                            wp_clear_scheduled_hook('vs_process_job_event', array($job['job_id']));
                        }
                    }
                }
            }
        }

        if (class_exists('VS_Error_Logger')) {
            VS_Error_Logger::get_instance()->log(
                'delete_calendar_assignment: completed',
                'info',
                array(
                    'index'           => $index,
                    'topic'           => $topic_name,
                    'was_bank_composed' => $is_bank_composed,
                    'job_deleted'     => $job_deleted,
                )
            );
        }

        wp_send_json_success(array(
            'message' => 'Calendar assignment deleted' . ($job_deleted ? ' and job removed' : ''),
            'job_deleted' => $job_deleted,
        ));
    }

    /**
     * AJAX: Upload Rendered Video (VPS Mode)
     */
    public function ajax_upload_rendered_video()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('upload_files')) {
            wp_send_json_error('Access denied');
        }

        if (empty($_FILES['video_blob'])) {
            wp_send_json_error('No file data');
        }

        $job_id = sanitize_text_field($_POST['job_id'] ?? '');
        $topic_slug = sanitize_title($_POST['topic_slug'] ?? 'video');
        $part = sanitize_text_field($_POST['part_suffix'] ?? '1');

        // Handle File upload
        $file = $_FILES['video_blob'];

        // Validation
        $mime = mime_content_type($file['tmp_name']);
        if ($mime !== 'video/mp4') {
            wp_send_json_error('Invalid file type');
        }

        // Directory: uploads/mcq-video-studio/generated/{Topic_Slug}/
        $upload_dir = wp_upload_dir();
        $base_dir = $upload_dir['basedir'] . '/mcq-video-studio/generated/' . $topic_slug;

        if (!file_exists($base_dir)) {
            wp_mkdir_p($base_dir);
        }

        $filename = $topic_slug . '_Part_' . $part . '_' . time() . '.mp4';
        $target_path = $base_dir . '/' . $filename;

        if (move_uploaded_file($file['tmp_name'], $target_path)) {
            $url = $upload_dir['baseurl'] . '/mcq-video-studio/generated/' . $topic_slug . '/' . $filename;
            wp_send_json_success(array('url' => $url));
        } else {
            wp_send_json_error('Failed to move uploaded file');
        }
    }

    /**
     * AJAX: Get Next Pending Job (Auto-Runner)
     */
    public function ajax_get_next_pending_job()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('edit_posts')) {
            wp_send_json_error('Access denied');
        }

        // @FIX 2026-07-09: When headless rendering is enabled, the browser-side
        //       auto-runner must NOT claim jobs. The headless render queue
        //       (run_headless_render_queue → handle_render_claim_action → render_job)
        //       is the sole claimant. Without this guard, an open Studio Editor
        //       tab steals every job via AJAX polling before the AS cron fires,
        //       sets it to 'rendering', then the browser export silently hangs —
        //       leaving the job trapped in RENDERING forever.
        $headless_enabled = (bool) get_option('mcqvs_headless_rendering_enabled', false);
        if ($headless_enabled) {
            wp_send_json_error('Headless rendering enabled — job claim deferred to render queue.');
        }

        $job_repo = VS_Job_Repository::init();

        $ready_jobs = $job_repo->get_jobs_by_status(VS_Job_Status::READY_FOR_RENDER, 5);
        $pending = $job_repo->get_pending_jobs(5);

        $jobs = array_merge($ready_jobs, $pending);

        $claimed = null;
        foreach ($jobs as $candidate) {
            $jid = $candidate['job_id'];
            $candidate_status = $candidate['status'];

            if (!VS_Job_Status::can_transition($candidate_status, VS_Job_Status::RENDERING)) {
                continue;
            }

            if ($job_repo->acquire_job_lock($jid, 300)) {
                $job_repo->update_status($jid, VS_Job_Status::RENDERING);
                $claimed = $candidate;
                break;
            }
        }

        if (!empty($claimed)) {
            $all_jobs = $job_repo->get_jobs_by_status(VS_Job_Status::READY_FOR_RENDER, 5);
            $more_pending = $job_repo->get_pending_jobs(5);
            $remaining = array_merge($all_jobs, $more_pending);

            wp_send_json_success(array(
                'jobs' => $remaining,
                'job'  => $claimed
            ));
        } else {
            wp_send_json_error('No pending jobs');
        }
    }

    /**
     * AJAX: Clear Stuck Jobs
     */
    public function ajax_clear_stuck_jobs()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Forbidden');
        }

        $job_repo = VS_Job_Repository::init();
        $stuck_threshold = absint(get_option('mcqvs_render_timeout', 900));
        // @FIX (cross-file audit 2026-07-09): Match the ≥600 floor from render_job()
        //              so the manual "Clear Stuck Jobs" button doesn't sweep renders
        //              that still have budget remaining.
        if ($stuck_threshold < 600) {
            $stuck_threshold = 900;
        }
        $stuck_threshold = max(60, $stuck_threshold);
        $cleared = $job_repo->clear_stuck_jobs(ceil(($stuck_threshold + 120) / 60));

        wp_send_json_success(array('message' => "Stuck jobs cleared ({$cleared} affected)."));
    }

    /**
     * AJAX: Clear ALL jobs from DB.
     * @NEW 2026-02-23: Complete queue purge (Fix 3)
     */
    public function ajax_clear_all_jobs()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Forbidden');
        }

        global $wpdb;
        $table = VS_Job_Repository::get_table_name();
        $deleted = $wpdb->query("DELETE FROM {$table}");

        wp_send_json_success(array(
            'message' => sprintf('All jobs cleared (%d removed).', $deleted),
            'deleted' => (int) $deleted,
        ));
    }

    /**
     * AJAX: Update Job Status (Auto-Runner)
     */
    public function ajax_update_job_status()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('edit_posts')) {
            wp_send_json_error('Access denied');
        }

        $job_id = sanitize_text_field($_POST['job_id'] ?? '');
        $status = sanitize_text_field($_POST['status'] ?? '');
        $error  = sanitize_text_field($_POST['error'] ?? '');

        if (empty($job_id) || empty($status)) {
            wp_send_json_error('Missing parameters');
        }

        $repo = VS_Job_Repository::init();

        $args = array();
        if ($error) $args['error_message'] = $error;

        $existing = $repo->get_job($job_id);
        if (!$existing) {
            wp_send_json_error('Job not found');
        }
        if (!VS_Job_Status::can_transition($existing['status'], $status)) {
            wp_send_json_error('Invalid transition: ' . $existing['status'] . ' -> ' . $status);
        }
        $updated = $repo->update_status($job_id, $status, $args);

        if ($updated !== false) {
            wp_send_json_success();
        } else {
            wp_send_json_error('DB update failed');
        }
    }

    /**
     * AJAX: Run Background Worker (Manual Trigger)
     */
    public function ajax_run_worker()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Forbidden');
        }

        if (function_exists('as_enqueue_async_action')) {
            // Force Action Scheduler to run its queue
            do_action('action_scheduler_run_queue', 'mcqvs_planner');
            wp_send_json_success(array('message' => 'Worker triggered. Background jobs should process now.'));
        } else {
            wp_send_json_error('Action Scheduler not available.');
        }
    }

    /**
     * AJAX: Manually heal auto-cleaned failed jobs and re-schedule their
     * vs_process_job_event so they render at their scheduled time.
     */
    public function ajax_recover_failed_jobs()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        $job_repo = VS_Job_Repository::init();
        $recovered = $job_repo->recover_failed_jobs(true);

        $scheduled = 0;
        foreach ($recovered as $rj) {
            if ($rj['status'] !== VS_Job_Status::PENDING) {
                continue;
            }
            $cron_time = strtotime($rj['scheduled_at'] . ' UTC');
            if ($cron_time > time()) {
                wp_schedule_single_event($cron_time, 'vs_process_job_event', array($rj['job_id']));
            } elseif (function_exists('as_enqueue_async_action')) {
                as_enqueue_async_action('vs_process_job_event', array($rj['job_id']), 'mcq-video-studio');
            } else {
                wp_schedule_single_event(time(), 'vs_process_job_event', array($rj['job_id']));
            }
            $scheduled++;
        }

        wp_send_json_success(array(
            'message'   => sprintf('Recovered %d failed job(s); %d re-scheduled for processing.', count($recovered), $scheduled),
            'recovered' => count($recovered),
            'scheduled' => $scheduled,
        ));
    }

    /**
     * @NEW 2026-07-06: Pipeline Verification Audit
     * Checks for mismatches, stale states, and silent failures across the pipeline.
     * 
     * @return array Audit results with issues found
     */
    public static function audit_pipeline_integrity()
    {
        $issues = array();
        $warnings = array();
        $info = array();

        if (!class_exists('VS_Job_Repository')) {
            return array('error' => 'VS_Job_Repository not available');
        }

        $job_repo = VS_Job_Repository::init();

        // Check 1: Jobs with publish_at but missing intent metadata
        global $wpdb;
        $table = $job_repo::get_table_name();
        
        $jobs_with_publish = $wpdb->get_results(
            "SELECT job_id, settings, publish_at FROM {$table} 
             WHERE publish_at IS NOT NULL AND publish_at != '0000-00-00 00:00:00' 
             AND status = 'completed'", 
            ARRAY_A
        );

        foreach ($jobs_with_publish as $job) {
            $settings = is_string($job['settings'] ?? '') ? json_decode($job['settings'], true) : ($job['settings'] ?? array());
            if (!is_array($settings)) {
                $issues[] = array(
                    'type' => 'missing_settings',
                    'job_id' => $job['job_id'],
                    'message' => "Job has publish_at but settings cannot be decoded"
                );
                continue;
            }

            if (!empty($job['publish_at']) && empty($settings['_publish_computed_at'])) {
                $warnings[] = array(
                    'type' => 'missing_intent_metadata',
                    'job_id' => $job['job_id'],
                    'message' => "Job has publish_at but missing _publish_computed_at metadata (pre-2026-07-06 or manual create)"
                );
            }

            // Check 2: Verify publish_at alignment
            if (!empty($settings['_publish_computed_at']) && !empty($settings['_publish_start_date'])) {
                $recalc = self::compute_publish_at(
                    $settings['_publish_start_date'],
                    $settings['publish_time'] ?? '09:00',
                    $settings['publish_frequency'] ?? 'daily',
                    $settings['_publish_offset'] ?? 0
                );

                if ($recalc && $recalc !== $job['publish_at']) {
                    $issues[] = array(
                        'type' => 'publish_at_mismatch',
                        'job_id' => $job['job_id'],
                        'message' => "publish_at mismatch: stored={$job['publish_at']}, recalculated={$recalc}",
                        'stored' => $job['publish_at'],
                        'recalculated' => $recalc
                    );
                }
            }
        }

        // Check 3: Check for stale rate_limited batches
        $tracker = get_option('mcqvs_batch_tracker', array());
        $now_ts = time();
        foreach ($tracker as $batch_idx => $batch) {
            if (($batch['status'] ?? '') === 'rate_limited') {
                $next_retry = $batch['_next_retry_at'] ?? '';
                if (empty($next_retry)) {
                    $warnings[] = array(
                        'type' => 'missing_retry_time',
                        'batch_index' => $batch_idx,
                        'message' => "Batch {$batch_idx} is rate_limited but has no _next_retry_at"
                    );
                } else {
                    $retry_ts = strtotime($next_retry . ' UTC');
                    if ($retry_ts && $retry_ts < $now_ts - 3600) {
                        $warnings[] = array(
                            'type' => 'stale_rate_limit',
                            'batch_index' => $batch_idx,
                            'message' => "Batch {$batch_idx} rate_limited since {$next_retry} (>1 hour ago), may need manual intervention"
                        );
                    }
                }
            }
        }

        // Check 4: Jobs stuck in uploading without video_url
        $uploading_without_url = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT job_id, started_at, created_at FROM {$table} 
                 WHERE status = %s AND (video_url IS NULL OR video_url = '') 
                 AND started_at < DATE_SUB(NOW(), INTERVAL 30 MINUTE)",
                VS_Job_Status::UPLOADING
            ),
            ARRAY_A
        );

        foreach ($uploading_without_url as $job) {
            $issues[] = array(
                'type' => 'stuck_uploading',
                'job_id' => $job['job_id'],
                'message' => "Job stuck in UPLOADING for >30min without video_url"
            );
        }

        // Check 5: R2 config consistency
        $r2_modes = $wpdb->get_results(
            "SELECT COUNT(*) as cnt, job_id FROM {$table} 
             WHERE settings LIKE '%\"r2\"%' OR settings LIKE '%\"r2_buffer\"%'
             LIMIT 1",
            ARRAY_A
        );

        if (!empty($r2_modes) && $r2_modes[0]['cnt'] > 0) {
            $public_domain = trim((string) get_option('mcqvs_r2_public_domain', ''));
            if (empty($public_domain)) {
                $issues[] = array(
                    'type' => 'r2_config_missing',
                    'job_count' => $r2_modes[0]['cnt'],
                    'message' => "{$r2_modes[0]['cnt']} jobs configured for R2 but mcqvs_r2_public_domain is not set"
                );
            }
        }

        // Check 6: Buffer lock contention check (jobs with lock transients but not published)
        if (class_exists('VS_Job_Status')) {
            $recent_completed = $job_repo->get_jobs_by_status(VS_Job_Status::COMPLETED, 100);
            $lock_issues = array();
            foreach ($recent_completed as $job) {
                if (empty($job['published_channels'])) {
                    $lock_key = 'mcqvs_job_lock_' . $job['job_id'];
                    // Check if lock still exists (shouldn't)
                    if (false !== get_transient($lock_key)) {
                        $lock_issues[] = $job['job_id'];
                    }
                }
            }
            if (!empty($lock_issues)) {
                $warnings[] = array(
                    'type' => 'stale_locks',
                    'job_ids' => $lock_issues,
                    'message' => count($lock_issues) . " completed jobs still have active locks"
                );
            }
        }

        $info[] = array(
            'type' => 'jobs_audited',
            'total_with_publish' => count($jobs_with_publish),
            'message' => "Audited " . count($jobs_with_publish) . " jobs with publish_at"
        );

        return array(
            'issues' => $issues,
            'warnings' => $warnings,
            'info' => $info,
            'summary' => array(
                'total_issues' => count($issues),
                'total_warnings' => count($warnings),
            )
        );
    }

    /**
     * Delayed cleanup of batch tracker after all batches complete.
     * @FIX: Prevents race condition with concurrent Action Scheduler workers.
     * @FIX 1.4.9.41 (data-loss): no longer wipes user data on completion.
     */
    public function handle_cleanup_batch_tracker()
    {
        $this->cleanup_after_all_batches();
    }

    /**
     * @FIX 1.4.9.41 (data-loss): cleanup of post-batch runtime state WITHOUT
     * destroying user data.
     *
     * Old behavior deleted `mcqvs_content_plan` (ALL submitted topics) and
     * `mcqvs_batch_tracker` (batch history) the moment every batch finished —
     * so a batch that partially FAILED silently lost its topics, and the
     * dashboard's batch/state view emptied out.
     *
     * New behavior:
     *  1. `mcqvs_content_plan_pending_batches` — runtime pointer to the active
     *     batch; the batch is finished, so this is safe to drop.
     *  2. `mcqvs_content_plan` — cleared ONLY when every tracked batch
     *     completed cleanly (all topics became jobs; clearing prevents
     *     accidental duplicate regeneration). If any batch failed, is
     *     rate-limited or still pending, the topic plan is KEPT so no
     *     topics are ever lost.
     *  3. `mcqvs_batch_tracker` — batch history is user data; it is KEPT so
     *     the dashboard keeps showing past batches.
     */
    private function cleanup_after_all_batches()
    {
        delete_option('mcqvs_content_plan_pending_batches');

        $tracker = get_option('mcqvs_batch_tracker', array());
        $all_completed = true;
        if (is_array($tracker)) {
            foreach ($tracker as $b) {
                $st = $b['status'] ?? '';
                if ($st !== 'completed') {
                    $all_completed = false;
                    break;
                }
            }
        }
        if ($all_completed) {
            delete_option('mcqvs_content_plan');
        }
        // Batch tracker intentionally kept (history).
    }

    /**
     * @NEW 2026-07-06: AJAX endpoint for pipeline verification
     */
    public function ajax_audit_pipeline()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        $audit_result = self::audit_pipeline_integrity();
        wp_send_json_success($audit_result);
    }

    /**
     * AJAX: List topics available in the Saved Questions Bank.
     * Returns topics with ≥1 approved MCQ in the bank (mirrors Studio Data Source Card contract).
     * @NEW 2026-07-10
     */
    public function ajax_planner_get_bank_topics()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        global $wpdb;
        $table_topics = $wpdb->prefix . 'vs_topics';
        $table_bank   = $wpdb->prefix . 'vs_mcq_bank';

        $topics = $wpdb->get_results("
            SELECT t.id, t.name, t.type, COUNT(q.id) as count
            FROM {$table_topics} t
            LEFT JOIN {$table_bank} q ON t.id = q.topic_id
            WHERE q.status = 'approved' OR q.status IS NULL
            GROUP BY t.id
            ORDER BY t.name ASC
        ");

        $data = array();
        foreach ($topics as $t) {
            // Show only topics that actually carry questions
            if ((int) $t->count === 0) {
                continue;
            }
            $data[] = array(
                'id'    => (int) $t->id,
                'title' => $t->name,
                'type'  => $t->type,
                'count' => (int) $t->count,
            );
        }

        wp_send_json_success($data);
    }

    /**
     * AJAX: Fetch all bank questions for a given topic.
     * Output mirrors Studio format, reusing VS_MCQ_Repository::find.
     * @NEW 2026-07-10
     */
    public function ajax_planner_get_topic_questions()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        $topic_id = isset($_POST['topic_id']) ? absint($_POST['topic_id']) : 0;
        if ($topic_id === 0) {
            wp_send_json_error('Missing topic_id');
        }

        if (!class_exists('VS_MCQ_Repository')) {
            wp_send_json_error('Repository missing');
        }

        $repo  = new VS_MCQ_Repository();
        $limit = isset($_POST['limit']) ? absint($_POST['limit']) : 50;
        $offset = isset($_POST['offset']) ? absint($_POST['offset']) : 0;

        $rows = $repo->find(array(
            'topic_id' => $topic_id,
            'status'   => 'approved',
            'limit'    => $limit,
            'offset'   => $offset,
        ));

        $questions = array();
        foreach ($rows as $row) {
            $questions[] = array(
                'id'            => (int) $row['id'],
                'question'      => $row['question_text'],
                'options'       => json_decode($row['options']),
                'correct'       => (int) $row['correct_index'],
                'background'    => 'gradient',
                'source_ref'    => $row['source_ref'] ?? 'unknown',
                'created_at'    => $row['created_at'] ?? '',
            );
        }

        $topic_row = $repo->get_topic($topic_id);
        $title = $topic_row ? $topic_row['name'] : 'Unknown Topic';

        wp_send_json_success(array(
            'questions' => $questions,
            'title'     => $title,
            'count'     => count($questions),
        ));
    }

    /**
     * AJAX: Compose a video job from hand-picked bank questions.
     * The user selects specific question_ids + a topic; this creates a VS_Job
     * exactly as if it had come through the normal approve-pipeline path.
     * @NEW 2026-07-10
     */
    public function ajax_planner_compose_video()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        $topic_id = isset($_POST['topic_id']) ? absint($_POST['topic_id']) : 0;
        if ($topic_id === 0) {
            wp_send_json_error('Missing topic_id');
        }

        $question_ids_raw = $_POST['question_ids'] ?? '';
        if (is_string($question_ids_raw)) {
            $question_ids = json_decode(stripslashes($question_ids_raw), true);
        } elseif (is_array($question_ids_raw)) {
            $question_ids = $question_ids_raw;
        } else {
            $question_ids = array();
        }

        if (!is_array($question_ids) || empty($question_ids)) {
            wp_send_json_error('Please select at least one question.');
        }

        if (!class_exists('VS_MCQ_Repository')) {
            wp_send_json_error('Repository missing');
        }

        $repo = new VS_MCQ_Repository();

        // Fetch each question by ID from bank, restricted to the submitted topic_id
        // so users can't mix questions from unrelated topics into a single video job.
        $selected = array();
        foreach ($question_ids as $qid) {
            $rows = $repo->find(array(
                'id'       => absint($qid),
                'topic_id' => $topic_id,
                'status'   => 'approved',
                'limit'    => 1,
            ));
            if (!empty($rows[0])) {
                $row = $rows[0];
                $selected[] = array(
                    'id'         => 'bank_' . $row['id'],
                    'question'   => $row['question_text'],
                    'options'    => json_decode($row['options'], true),
                    'correct'    => (int) $row['correct_index'],
                    'background' => 'gradient',
                );
            }
        }

        if (empty($selected)) {
            wp_send_json_error('No valid questions found for the selected IDs.');
        }

        // Get topic name
        $topic_row = $repo->get_topic($topic_id);
        if (!$topic_row) {
            wp_send_json_error('Topic not found.');
        }
        $topic_name = $topic_row['name'];

        // Build styles from POST (same contract as approve_topic_plan)
        $styles = array(
            'template'           => sanitize_text_field($_POST['style_template'] ?? 'trivia'),
            'font'               => sanitize_text_field($_POST['style_font'] ?? ''),
            'music'              => sanitize_text_field($_POST['style_music'] ?? ''),
            'bg_video'           => sanitize_text_field($_POST['style_bg_video'] ?? ''),
            'save_mode'          => sanitize_text_field($_POST['save_mode'] ?? 'local'),
            'hookVisible'        => isset($_POST['hook_visible']) ? sanitize_text_field($_POST['hook_visible']) !== '0' : true,
            'hookText'           => sanitize_text_field($_POST['style_hook_text'] ?? ''),
            'videos_per_topic'   => 1,
            'questions_count'    => count($selected),
            'publish_start_date' => sanitize_text_field($_POST['publish_start_date'] ?? ''),
            'publish_time'       => sanitize_text_field($_POST['publish_time'] ?? '09:00'),
            'publish_frequency'  => sanitize_text_field($_POST['publish_frequency'] ?? 'daily'),
            'buffer_channels'    => stripslashes($_POST['buffer_channels'] ?? '[]'),
        );

        // @FIX: Map publish_start_date to publish_date so create_job_for_topic uses calendar path
        if (!empty($styles['publish_start_date'])) {
            $styles['publish_date'] = $styles['publish_start_date'];
        }

        // Reuse existing job creation machinery — no duplicate logic
        $job_id = $this->create_job_for_topic($topic_name, $selected, $styles);

        if (!$job_id) {
            wp_send_json_error('Failed to create the video job.');
        }

        // @FIX: Also add to mcqvs_content_plan so the topic appears as a draggable
        // calendar chip (not just a frozen job dot). Mark as _bank_composed so
        // ajax_approve_topic_plan skips it (job already created).
        $plan = get_option('mcqvs_content_plan', array());
        if (!is_array($plan)) $plan = array();

        // Compute the calendar date/time from styles (same logic as create_job_for_topic)
        $publish_date = '';
        $publish_time = $styles['publish_time'] ?? '09:00';
        if (!empty($styles['publish_start_date'])) {
            // For bank compose, publish_start_date is the explicit date from sidebar
            $publish_date = $styles['publish_start_date'];
        }

        $plan_entry = array(
            'topic'              => $topic_name,
            'publish_date'       => $publish_date,
            'publish_time'       => $publish_time,
            'template'           => $styles['template'] ?? '',
            'font'               => $styles['font'] ?? '',
            'music'              => $styles['music'] ?? '',
            'bg_video'           => $styles['bg_video'] ?? '',
            '_bank_composed'     => true,
            '_job_id'            => $job_id,
            '_inline_questions'  => $selected, // So batch worker uses these questions if ever re-processed
            '_calendar_assigned' => !empty($publish_date),
        );
        $plan[] = $plan_entry;
        update_option('mcqvs_content_plan', $plan);

        wp_send_json_success(array(
            'message'   => 'Video job created successfully.',
            'job_id'    => $job_id,
            'questions' => count($selected),
            'topic'     => $topic_name,
            'plan_index' => count($plan) - 1, // Index for frontend reference
        ));
    }

    /**
     * AJAX: Get questions for a specific job (for MCQ Editor)
     * @NEW 2026-08-03
     */
    public function ajax_get_job_questions()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        $job_id = sanitize_text_field($_POST['job_id'] ?? '');
        if (empty($job_id)) {
            wp_send_json_error('Missing job_id');
        }

        if (!class_exists('VS_Job_Repository')) {
            wp_send_json_error('Job repository not found');
        }

        $job_repo = VS_Job_Repository::init();
        $job = $job_repo->get_job($job_id);

        if (!$job) {
            wp_send_json_error('Job not found');
        }

        $questions = array();
        $quiz_data = is_string($job['quiz_data'] ?? '') ? json_decode($job['quiz_data'], true) : ($job['quiz_data'] ?? array());
        $quiz_data = is_array($quiz_data) ? $quiz_data : array();

        if (!empty($quiz_data)) {
            foreach ($quiz_data as $index => $q) {
                $questions[] = array(
                    'index'     => $index,
                    'id'        => $q['id'] ?? 'q_' . $index,
                    'question'  => $q['question'] ?? '',
                    'options'   => $q['options'] ?? array('', '', '', ''),
                    'correct'   => isset($q['correct']) ? (int) $q['correct'] : 0,
                    'background'=> $q['background'] ?? 'gradient',
                );
            }
        }

        $settings = is_string($job['settings'] ?? '') ? json_decode($job['settings'], true) : ($job['settings'] ?? array());
        $topic_name = $settings['topic_name'] ?? $settings['topic_base'] ?? 'Unknown Topic';

        wp_send_json_success(array(
            'job_id'    => $job_id,
            'topic'     => $topic_name,
            'questions' => $questions,
            'status'    => $job['status'],
            'publish_at'=> $job['publish_at'] ?? null,
        ));
    }

    /**
     * AJAX: Update questions for a specific job (from MCQ Editor)
     * @NEW 2026-08-03
     */
    public function ajax_update_job_questions()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        $job_id = sanitize_text_field($_POST['job_id'] ?? '');
        if (empty($job_id)) {
            wp_send_json_error('Missing job_id');
        }

        $questions_raw = stripslashes($_POST['questions'] ?? '');
        $questions = json_decode($questions_raw, true);

        if (!is_array($questions)) {
            wp_send_json_error('Invalid questions format');
        }

        // Validate each question
        foreach ($questions as $index => $q) {
            if (!isset($q['question']) || trim($q['question']) === '') {
                wp_send_json_error("Question $index: question text is required");
            }
            if (!isset($q['options']) || !is_array($q['options']) || count($q['options']) !== 4) {
                wp_send_json_error("Question $index: exactly 4 options are required");
            }
            if (!isset($q['correct']) || $q['correct'] < 0 || $q['correct'] > 3) {
                wp_send_json_error("Question $index: correct index must be 0-3");
            }
            // Sanitize
            $questions[$index]['question'] = sanitize_text_field($q['question']);
            $questions[$index]['options'] = array_map('sanitize_text_field', $q['options']);
            $questions[$index]['correct'] = (int) $q['correct'];
            $questions[$index]['background'] = $q['background'] ?? 'gradient';
            $questions[$index]['id'] = $q['id'] ?? 'q_' . $index;
        }

        if (!class_exists('VS_Job_Repository')) {
            wp_send_json_error('Job repository not found');
        }

        $job_repo = VS_Job_Repository::init();
        $job = $job_repo->get_job($job_id);

        if (!$job) {
            wp_send_json_error('Job not found');
        }

        // Update the job's quiz_data
        $result = $job_repo->update_job_fields($job_id, array(
            'quiz_data' => wp_json_encode($questions),
        ));

        if ($result === false) {
            wp_send_json_error('Failed to update job questions');
        }

        // Also update MCQ bank if topic_id exists
        $topic_id = (int) $job['topic_id'];
        if ($topic_id > 0 && class_exists('VS_MCQ_Repository')) {
            $mcq_repo = VS_MCQ_Repository::get_instance();
            foreach ($questions as $q) {
                $mcq_repo->insert_mcq(array(
                    'question_text' => $q['question'],
                    'options'       => $q['options'],
                    'correct_index' => $q['correct'],
                    'topic_id'      => $topic_id,
                    'status'        => 'approved',
                    'source_ref'    => 'planner_batch',
                    'difficulty'    => 'medium',
                ));
            }
        }

        wp_send_json_success(array(
            'message' => 'Questions updated successfully',
            'count'   => count($questions),
        ));
    }

    /**
     * AJAX: Retry failed topics from a specific batch
     * @NEW 2026-08-03
     */
    public function ajax_retry_failed_topics()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        $batch_index = isset($_POST['batch_index']) ? absint($_POST['batch_index']) : 0;
        if ($batch_index <= 0) {
            wp_send_json_error('Invalid batch index');
        }

        $tracker = get_option('mcqvs_batch_tracker', array());
        $batch_data = $tracker[$batch_index] ?? array();

        if (empty($batch_data['failed']) || !is_array($batch_data['failed'])) {
            wp_send_json_error('No failed topics to retry');
        }

        $failed_topics = $batch_data['failed'];
        $styles = $batch_data['styles'] ?? array();

        // Re-queue the failed topics
        if (function_exists('as_enqueue_async_action')) {
            as_enqueue_async_action('mcqvs_process_topic_batch', array(
                $failed_topics,
                $batch_index,
                $batch_data['total_batches'] ?? 1,
                $styles,
            ), 'mcqvs_planner');

            // Update tracker status
            $tracker[$batch_index]['status'] = 'pending';
            $tracker[$batch_index]['time'] = gmdate('Y-m-d H:i:s');
            update_option('mcqvs_batch_tracker', $tracker);

            wp_send_json_success(array(
                'message' => 'Retry queued for ' . count($failed_topics) . ' failed topics',
                'count'   => count($failed_topics),
            ));
        } else {
            wp_send_json_error('Action Scheduler not available');
        }
    }
}
