<?php
namespace AiSocialCollage\Services\ImageAI;

use AiSocialCollage\Config;
use AiSocialCollage\Contracts\ImageAIProviderInterface;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class StabilityProvider implements ImageAIProviderInterface {

	private $api_key;

	public function __construct( $api_key = '' ) {
		$this->api_key = $api_key;
	}

	public function generate_image( $prompt, $width = 1080, $height = 1350 ) {
		if ( empty( $this->api_key ) ) {
			throw new \Exception( 'Stability AI requires an API key.' );
		}

		$body = wp_json_encode( [
			'text_prompts' => [ [ 'text' => $prompt, 'weight' => 1 ] ],
			'cfg_scale' => 7,
			'width' => min( $width, 1024 ),
			'height' => min( $height, 1024 ),
			'steps' => 30,
			'samples' => 1,
		] );

		$response = wp_remote_post( 'https://api.stability.ai/v1/generation/stable-diffusion-xl-1024-v1-0/text-to-image', [
			'timeout' => 120,
			'headers' => [
				'Content-Type' => 'application/json',
				'Accept' => 'application/json',
				'Authorization' => 'Bearer ' . $this->api_key,
			],
			'body' => $body,
		] );

		if ( is_wp_error( $response ) ) {
			Logger::error( 'stability_image_error', null, [ 'error' => $response->get_error_message() ], '500' );
			throw new \Exception( 'Stability AI request failed: ' . $response->get_error_message() );
		}

		$code = wp_remote_retrieve_response_code( $response );
		$result = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( $code !== 200 || empty( $result['artifacts'][0]['base64'] ) ) {
			$err = $result['message'] ?? 'Unknown error';
			Logger::error( 'stability_image_error', null, [ 'code' => $code, 'error' => $err ], '500' );
			throw new \Exception( "Stability AI error: {$err}" );
		}

		$image_data = base64_decode( $result['artifacts'][0]['base64'] );
		if ( empty( $image_data ) ) {
			throw new \Exception( 'Stability AI returned invalid base64 image data' );
		}

		return $this->save_temp_image( $image_data );
	}

	private function save_temp_image( $data ) {
		$temp_dir = AI_SOCIAL_COLLAGE_PATH . 'assets/temp';
		if ( ! is_dir( $temp_dir ) ) {
			wp_mkdir_p( $temp_dir );
		}

		$filename = 'ai_gen_' . uniqid() . '.png';
		$path = $temp_dir . '/' . $filename;
		file_put_contents( $path, $data );

		return $path;
	}

	public function get_provider_name() {
		return Config::PROVIDER_IMAGE_STABILITY;
	}

	public function get_model_name() {
		return 'stable-diffusion-xl-1024';
	}
}
