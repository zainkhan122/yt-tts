<?php

/**
 * Sitemap Manager View
 *
 * @package SEO_Article_Generator
 */

// Prevent direct access
if (! defined('ABSPATH')) {
    exit;
}

// @MODIFIED 2025-12-02 - Use fully qualified class names (no namespace in views)
$logger = new \SEO_Article_Generator\Logger();
$parser = new \SEO_Article_Generator\Links\Sitemap_Parser($logger);
$stats = $parser->get_stats();
?>

<div class="wrap">
    <h1><?php esc_html_e('Sitemap Manager', 'seo-article-generator'); ?></h1>

    <div class="seo-gen-sitemap-section">
        <h2><?php esc_html_e('Upload Sitemap CSV', 'seo-article-generator'); ?></h2>
        <p><?php esc_html_e('Upload a CSV file containing your internal links. The CSV must have "Title" and "URL" columns.', 'seo-article-generator'); ?></p>

        <form id="seo-gen-sitemap-form" enctype="multipart/form-data">
            <input type="file" name="sitemap_file" id="sitemap_file" accept=".csv" required>
            <button type="submit" class="button button-primary"><?php esc_html_e('Upload and Import', 'seo-article-generator'); ?></button>
        </form>

        <div id="seo-gen-sitemap-result" style="margin-top: 20px;"></div>
    </div>

    <div class="seo-gen-sitemap-stats" style="margin-top: 40px;">
        <h2><?php esc_html_e('Current Sitemap Statistics', 'seo-article-generator'); ?></h2>

        <table class="widefat">
            <thead>
                <tr>
                    <th><?php esc_html_e('Metric', 'seo-article-generator'); ?></th>
                    <th><?php esc_html_e('Value', 'seo-article-generator'); ?></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><strong><?php esc_html_e('Total Links', 'seo-article-generator'); ?></strong></td>
                    <td><?php echo esc_html(number_format($stats['total_links'])); ?></td>
                </tr>
            </tbody>
        </table>

        <?php if (! empty($stats['categories'])) : ?>
            <h3 style="margin-top: 30px;"><?php esc_html_e('Top Categories', 'seo-article-generator'); ?></h3>
            <table class="widefat">
                <thead>
                    <tr>
                        <th><?php esc_html_e('Category', 'seo-article-generator'); ?></th>
                        <th><?php esc_html_e('Count', 'seo-article-generator'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($stats['categories'] as $category) : ?>
                        <tr>
                            <td><?php echo esc_html($category['software_type']); ?></td>
                            <td><?php echo esc_html(number_format($category['count'])); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<script type="text/javascript">
    var ajaxurl = '<?php echo esc_js(admin_url('admin-ajax.php')); ?>';
    jQuery(document).ready(function($) {
        $('#seo-gen-sitemap-form').on('submit', function(e) {
            e.preventDefault();

            var formData = new FormData();
            var file = $('#sitemap_file')[0].files[0];

            if (!file) {
                alert('<?php esc_html_e('Please select a CSV file', 'seo-article-generator'); ?>');
                return;
            }

            formData.append('action', 'seo_gen_upload_sitemap');
            formData.append('nonce', '<?php echo esc_js(wp_create_nonce('seo_gen_nonce')); ?>');
            formData.append('sitemap_file', file);

            var result = $('#seo-gen-sitemap-result');
            result.html('<p><?php esc_html_e('Uploading and processing...', 'seo-article-generator'); ?></p>');

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        result.html('<div class="notice notice-success"><p>' + response.data.message + '</p></div>');
                        // Reload page after 2 seconds to show new stats
                        setTimeout(function() {
                            location.reload();
                        }, 2000);
                    } else {
                        result.html('<div class="notice notice-error"><p>' + response.data.message + '</p></div>');
                    }
                },
                error: function() {
                    result.html('<div class="notice notice-error"><p><?php esc_html_e('Upload failed', 'seo-article-generator'); ?></p></div>');
                }
            });
        });
    });
</script>
