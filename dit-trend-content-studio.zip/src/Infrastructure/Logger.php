<?php

/**
 * Logger
 *
 * @package DIT_TrendStudio
 * @MODIFIED 2025-12-13 - Forked from SEO Article Generator
 */

namespace DIT\TrendStudio\Infrastructure;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * PSR-3 compatible logger (simplified)
 */
class Logger
{
    /**
     * Log levels
     */
    const LEVEL_DEBUG = 'DEBUG';
    const LEVEL_INFO = 'INFO';
    const LEVEL_WARNING = 'WARNING';
    const LEVEL_ERROR = 'ERROR';

    /**
     * Log file path
     *
     * @var string
     */
    private $log_file;

    /**
     * Whether logging is enabled
     *
     * @var bool
     */
    private $enabled;

    /**
     * Constructor
     */
    public function __construct()
    {
        $upload_dir = wp_upload_dir();
        $log_dir = $upload_dir['basedir'] . '/dit-ts-logs';

        // Create log directory if it doesn't exist
        if (!file_exists($log_dir)) {
            wp_mkdir_p($log_dir);
            // Create .htaccess to prevent direct access
            file_put_contents($log_dir . '/.htaccess', 'Deny from all');
        }

        $this->log_file = $log_dir . '/dit-ts-' . date('Y-m-d') . '.log';
        $this->enabled = (bool) get_option('dit_ts_enable_logging', true);
    }

    /**
     * Log debug message
     *
     * @param string $message Log message
     * @param array  $context Additional context
     * @return void
     */
    public function debug($message, $context = array())
    {
        $this->log(self::LEVEL_DEBUG, $message, $context);
    }

    /**
     * Log info message
     *
     * @param string $message Log message
     * @param array  $context Additional context
     * @return void
     */
    public function info($message, $context = array())
    {
        $this->log(self::LEVEL_INFO, $message, $context);
    }

    /**
     * Log warning message
     *
     * @param string $message Log message
     * @param array  $context Additional context
     * @return void
     */
    public function warning($message, $context = array())
    {
        $this->log(self::LEVEL_WARNING, $message, $context);
    }

    /**
     * Log error message
     *
     * @param string $message Log message
     * @param array  $context Additional context
     * @return void
     */
    public function error($message, $context = array())
    {
        $this->log(self::LEVEL_ERROR, $message, $context);
    }

    /**
     * Write log entry
     *
     * @param string $level Log level
     * @param string $message Log message
     * @param array  $context Additional context
     * @return void
     */
    private function log($level, $message, $context = array())
    {
        if (!$this->enabled) {
            return;
        }

        $timestamp = current_time('Y-m-d H:i:s');
        if (!empty($context)) {
            // Mask secrets: API keys, tokens, secrets, passwords, etc.
            foreach ($context as $k => &$v) {
                if (preg_match('/(api_key|apikey|token|secret|key|password)/i', $k)) {
                    $v = '***';
                }
            }
            $context_str = ' ' . wp_json_encode($context);
        } else {
            $context_str = '';
        }
        $log_entry = sprintf(
            "[%s] [%s] %s%s\n",
            $timestamp,
            $level,
            $message,
            $context_str
        );

        // Write to file
        error_log($log_entry, 3, $this->log_file);

        // Also write to WordPress debug log if WP_DEBUG is enabled
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("DIT TrendStudio: [{$level}] {$message}");
        }
    }

    /**
     * Get recent log entries
     * @MODIFIED 2026-01-30 - Added level filter
     *
     * @param int $lines Number of lines to retrieve
     * @param string|null $level_filter Only return logs of this level (e.g. 'ERROR')
     * @return array
     */
    public function get_recent_logs($lines = 100, $level_filter = null)
    {
        if (!file_exists($this->log_file)) {
            return array();
        }

        // Read last N lines from log file
        $file = new \SplFileObject($this->log_file, 'r');
        $file->seek(PHP_INT_MAX);
        $last_line = $file->key();
        $start_line = max(0, $last_line - $lines);

        $log_entries = array();
        $file->seek($start_line);

        while (!$file->eof()) {
            $line = trim($file->fgets());
            if ($line) {
                // Filter by level if specified
                if ($level_filter !== null) {
                    // Check if line contains the level (format: [timestamp] [LEVEL] message)
                    if (strpos($line, "[{$level_filter}]") === false) {
                        continue; // Skip this line
                    }
                }
                $log_entries[] = $line;
            }
        }

        return $log_entries;
    }

    /**
     * Clear old log files
     *
     * @param int $days_to_keep Number of days to keep logs
     * @return int Number of files deleted
     */
    public function clear_old_logs($days_to_keep = 30)
    {
        $upload_dir = wp_upload_dir();
        $log_dir = $upload_dir['basedir'] . '/dit-ts-logs';

        if (!file_exists($log_dir)) {
            return 0;
        }

        $deleted = 0;
        $cutoff_time = time() - ($days_to_keep * DAY_IN_SECONDS);

        $files = glob($log_dir . '/dit-ts-*.log');
        foreach ($files as $file) {
            if (filemtime($file) < $cutoff_time) {
                if (unlink($file)) {
                    $deleted++;
                }
            }
        }

        return $deleted;
    }

 	/**
 	 * Get log file path
 	 *
 	 * @return string
 	 */
 	public function get_log_file()
 	{
 		return $this->log_file;
 	}

 	/**
 	 * Delete all log files in the log directory
 	 *
 	 * @return int Number of files deleted
 	 */
 	public function clear_all_log_files()
 	{
 		$upload_dir = wp_upload_dir();
 		$log_dir = $upload_dir['basedir'] . '/dit-ts-logs';

 		if (!file_exists($log_dir)) {
 			return 0;
 		}

 		$deleted = 0;
 		$files = glob($log_dir . '/dit-ts-*.log');
 		foreach ($files as $file) {
 			if (unlink($file)) {
 				$deleted++;
 			}
 		}

 		return $deleted;
 	}

 	/**
 	 * Get all available log files sorted newest first
 	 *
 	 * @return array { filename, date, size, path }
 	 */
 	public function get_available_log_files()
 	{
 		$upload_dir = wp_upload_dir();
 		$log_dir = $upload_dir['basedir'] . '/dit-ts-logs';

 		if (!file_exists($log_dir)) {
 			return array();
 		}

 		$files = glob($log_dir . '/dit-ts-*.log');
 		if (empty($files)) {
 			return array();
 		}

 		$logs = array();
 		foreach ($files as $file) {
 			$logs[] = array(
 				'filename' => basename($file),
 				'date'     => date('Y-m-d', filemtime($file)),
 				'size'     => filesize($file),
 				'path'     => $file,
 			);
 		}

 		usort($logs, function ($a, $b) {
 			return strcmp($b['filename'], $a['filename']);
 		});

 		return $logs;
 	}

	/**
	 * Read a page of lines from an arbitrary file using seek — no full-file parse.
	 * @ADDED 2026-04-24
	 *
	 * @param string $file_path Absolute path to the file.
	 * @param int    $page      1-based page number.
	 * @param int    $per_page  Lines per page (default 100).
	 * @return array { 'lines' => string[], 'total_lines' => int, 'total_pages' => int, 'page' => int }
	 */
 	public static function read_file_page($file_path, $page = 1, $per_page = 100)
 	{
 		$real = realpath($file_path);
 		if (!$real || !is_file($real) || !is_readable($real)) {
 			return array('lines' => array(), 'total_lines' => 0, 'total_pages' => 0, 'page' => (int) $page);
 		}

 		$file = new \SplFileObject($real, 'r');
 		$file->seek(PHP_INT_MAX);
 		$last_index = $file->key();
 		$total_lines = $last_index + 1;

 		if ($total_lines <= 0) {
 			return array('lines' => array(), 'total_lines' => 0, 'total_pages' => 0, 'page' => 1);
 		}

 		$total_pages = (int) ceil($total_lines / $per_page);
 		$page = max(1, min((int) $page, $total_pages));

 		$start = ($page - 1) * $per_page;
 		$end   = min($start + $per_page, $total_lines);

 		$lines = array();
 		$file->seek($start);
 		$pos = $start;

 		while ($pos < $end && !$file->eof()) {
 			$line = trim($file->fgets());
 			if ($line !== '') {
 				$lines[] = $line;
 			}
 			$pos++;
 		}

 		return array(
 			'lines'       => $lines,
 			'total_lines' => $total_lines,
 			'total_pages' => $total_pages,
 			'page'        => $page,
 		);
 	}

 	/**
 	 * List non-empty lines of a log file with their line numbers.
 	 * Returns array of [ [line_num, raw], ... ] for all non-empty lines.
 	 * @ADDED 2026-05-31
 	 *
 	 * @param string $file_path Absolute path to the file.
 	 * @return array
 	 */
 	public static function read_all_nonempty_lines($file_path)
 	{
 		$real = realpath($file_path);
 		if (!$real || !is_file($real) || !is_readable($real)) {
 			return array();
 		}

 		$file = new \SplFileObject($real, 'r');
 		$result = array();
 		$line_num = 0;

 		while (!$file->eof()) {
 			$raw = $file->fgets();
 			$line_num++;
 			$trimmed = trim($raw);
 			if ($trimmed !== '') {
 				$result[] = array('line_num' => $line_num, 'raw' => $trimmed);
 			}
 		}

 		return $result;
 	}
}
