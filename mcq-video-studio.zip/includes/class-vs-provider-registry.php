<?php

if (! defined('ABSPATH')) {
    exit;
}

class VS_Provider_Registry
{

    private static $instance = null;

    private array $builtin = array();

    private array $custom = array();

    public static function get_instance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        $this->builtin = array(
            'gemini' => array(
                'name'                => 'Google Gemini',
                'key_option'          => 'mcqvs_gemini_api_key',
                'model_option'        => 'mcqvs_gemini_model_id',
                'default_model'       => 'gemini-3-flash-preview',
                'models'              => array(
                    'gemini-3-flash-preview' => 'Gemini 3 Flash Preview',
                    'gemini-2.5-flash'       => 'Gemini 2.5 Flash',
                    'gemini-2.0-flash'       => 'Gemini 2.0 Flash',
                ),
                'endpoint'             => 'https://generativelanguage.googleapis.com/v1beta',
                'auth_type'            => 'query_key',
                'supports_web_search'  => true,
                'web_search_type'      => 'google_search',
                'supports_json_schema' => false,
            ),

        );

        $saved = get_option('mcqvs_custom_providers', '[]');
        if (is_string($saved)) {
            $saved = json_decode($saved, true);
        }
        $this->custom = is_array($saved) ? $saved : array();

        $this->custom = apply_filters('mcqvs_register_custom_providers', $this->custom);
    }

    public function get_all_ids()
    {
        $custom_ids = array_map(function ($profile) {
            return $profile['id'];
        }, $this->custom);
        return array_merge(array_keys($this->builtin), $custom_ids);
    }

    public function is_custom($id)
    {
        return !isset($this->builtin[$id]);
    }

    public function get_provider_config($id)
    {
        if ($this->is_custom($id)) {
            return $this->get_custom_profile($id);
        }
        return $this->builtin[$id] ?? array();
    }

    public function get_api_key($id)
    {
        if ($this->is_custom($id)) {
            $profile = $this->get_custom_profile($id);
            return $profile['api_key'] ?? '';
        }
        $key_option = $this->builtin[$id]['key_option'] ?? '';
        $val = get_option($key_option, '');
        // @FIX 1.5.1 (SSOT): NO fallback to the parent MCQ plugin's key. mcq-video-studio
        // uses its OWN key only, per the plugin's independent API/fallback system.
        return $val;
    }

    public function get_rotation_api_key($provider_id)
    {
        return $this->get_api_key($provider_id);
    }

    public function get_working_model($id)
    {
        if ($this->is_custom($id)) {
            $profile = $this->get_custom_profile($id);
            $models = array_values((array)($profile['models'] ?? array()));
            return isset($models[0]['model_id']) ? $models[0]['model_id'] : '';
        }
        $model_option = $this->builtin[$id]['model_option'] ?? '';
        if ($model_option) {
            $saved = get_option($model_option, '');
            if ($saved !== '' && $saved !== false) {
                return $saved;
            }
        }
        return $this->builtin[$id]['default_model'] ?? '';
    }

    public function get_supported_models($id)
    {
        if ($this->is_custom($id)) {
            $profile = $this->get_custom_profile($id);
            $models = array();
            foreach ((array)($profile['models'] ?? array()) as $m) {
                if (!empty($m['model_id'])) {
                    $models[$m['model_id']] = $m['display_name'] ?? $m['model_id'];
                }
            }
            return $models;
        }

        $base = $this->builtin[$id]['models'] ?? array();

        if ($id === 'gemini') {
            $custom = get_option('mcqvs_gemini_custom_models', '');
            if (is_string($custom) && $custom !== '') {
                $decoded = json_decode($custom, true);
                if (is_array($decoded)) {
                    foreach ($decoded as $entry) {
                        $mid = sanitize_text_field($entry['model_id'] ?? '');
                        if ($mid !== '' && !isset($base[$mid])) {
                            $base[$mid] = sanitize_text_field($entry['display_name'] ?? $mid);
                        }
                    }
                }
            }
        }

        return $base;
    }

    public function get_endpoint($id)
    {
        if ($this->is_custom($id)) {
            $profile = $this->get_custom_profile($id);
            return rtrim($profile['api_url'] ?? '', '/');
        }
        return $this->builtin[$id]['endpoint'] ?? '';
    }

    /**
     * Map a request URL back to a provider id for telemetry tagging.
     *
     * Compares the URL host against each built-in and custom provider's
     * configured endpoint host. Returns the provider id, or '' when no
     * registered provider matches (caller falls back to 'other'/'buffer').
     *
     * @param string $url
     * @return string
     */
    public function identify_provider_from_url($url)
    {
        $host = wp_parse_url($url, PHP_URL_HOST);
        if (empty($host)) {
            return '';
        }
        foreach ($this->builtin as $id => $cfg) {
            $ep_host = wp_parse_url($cfg['endpoint'] ?? '', PHP_URL_HOST);
            if ($ep_host !== '' && strpos($host, $ep_host) !== false) {
                return $id;
            }
        }
        foreach ($this->custom as $profile) {
            $ep = rtrim($profile['api_url'] ?? '', '/');
            $ep_host = wp_parse_url($ep, PHP_URL_HOST);
            if ($ep_host !== '' && strpos($host, $ep_host) !== false) {
                return isset($profile['id']) ? $profile['id'] : '';
            }
        }
        return '';
    }

    public function get_auth_type($id)
    {
        if ($this->is_custom($id)) {
            return 'bearer';
        }
        return $this->builtin[$id]['auth_type'] ?? 'bearer';
    }

    public function supports_json_schema($id)
    {
        if ($this->is_custom($id)) {
            $profile = $this->get_custom_profile($id);
            return !empty($profile['supports_json_schema']);
        }
        return $this->builtin[$id]['supports_json_schema'] ?? false;
    }

    public function supports_web_search($id)
    {
        if ($this->is_custom($id)) {
            $profile = $this->get_custom_profile($id);
            return !empty($profile['enable_web_search']) && ($profile['web_search_config']['type'] ?? 'none') !== 'none';
        }
        return $this->builtin[$id]['supports_web_search'] ?? false;
    }

    public function get_web_search_type($id)
    {
        if ($this->is_custom($id)) {
            $profile = $this->get_custom_profile($id);
            return $profile['web_search_config']['type'] ?? 'none';
        }
        return $this->builtin[$id]['web_search_type'] ?? 'none';
    }

    public function get_builtin_custom_models($provider_id)
    {
        if ($provider_id !== 'gemini') {
            return array();
        }
        $raw = get_option('mcqvs_gemini_custom_models', '');
        if (is_string($raw) && $raw !== '') {
            $decoded = json_decode($raw, true);
            if (is_array($decoded)) {
                return $decoded;
            }
        }
        return array();
    }

    public function save_builtin_custom_models($provider_id, $models)
    {
        if ($provider_id !== 'gemini') {
            return;
        }
        $sanitized = array();
        foreach ((array)$models as $m) {
            $mid = sanitize_text_field($m['model_id'] ?? '');
            if ($mid !== '') {
                $sanitized[] = array(
                    'model_id'     => $mid,
                    'display_name' => sanitize_text_field($m['display_name'] ?? $mid),
                );
            }
        }
        update_option('mcqvs_gemini_custom_models', wp_json_encode($sanitized));
    }

    public function get_custom_profile($id)
    {
        foreach ($this->custom as $profile) {
            if (($profile['id'] ?? '') === $id) {
                return $profile;
            }
        }
        return array();
    }

    public function get_custom_providers()
    {
        return $this->custom;
    }

    public function get_builtin_providers()
    {
        return $this->builtin;
    }

    public function save_custom_providers($providers)
    {
        $sanitized = array();
        foreach ($providers as $profile) {
            $sanitized[] = $this->validate_custom_profile($profile);
        }
        update_option('mcqvs_custom_providers', wp_json_encode($sanitized));
        $this->custom = $sanitized;
    }

    public function validate_custom_profile($profile)
    {
        $sanitized = array();
        $sanitized['id'] = sanitize_key($profile['id'] ?? 'prov_' . time() . '_' . wp_generate_password(5, false));
        $sanitized['name'] = sanitize_text_field($profile['name'] ?? 'Unnamed Provider');
        $sanitized['api_url'] = esc_url_raw($profile['api_url'] ?? '');
        $sanitized['api_key'] = sanitize_text_field($profile['api_key'] ?? '');
        $sanitized['enable_web_search'] = !empty($profile['enable_web_search']);
        $sanitized['fallback_enabled'] = !empty($profile['fallback_enabled']);
        $sanitized['web_search_config'] = array(
            'type'          => sanitize_text_field($profile['web_search_config']['type'] ?? 'none'),
            'search_engine' => sanitize_text_field($profile['web_search_config']['search_engine'] ?? 'search_pro'),
            'search_count'  => min(20, max(1, (int)($profile['web_search_config']['search_count'] ?? 10))),
        );
        $sanitized['supports_json_schema'] = !empty($profile['supports_json_schema']);

        $models = array();
        foreach ((array)($profile['models'] ?? array()) as $m) {
            if (!empty($m['model_id'])) {
                $models[] = array(
                    'model_id'     => sanitize_text_field($m['model_id']),
                    'display_name' => sanitize_text_field($m['display_name'] ?? $m['model_id']),
                );
            }
        }
        $sanitized['models'] = $models;

        return $sanitized;
    }

    public function build_api_url($provider_id, $model = '')
    {
        $active = $provider_id ?: get_option('mcqvs_api_provider', 'gemini');

        if ($active === 'gemini') {
            $api_key = $this->get_api_key('gemini');
            $use_model = $model ?: $this->get_working_model('gemini');
            return "https://generativelanguage.googleapis.com/v1beta/models/{$use_model}:generateContent?key=" . $api_key;
        }

        $endpoint = $this->get_endpoint($active);
        return rtrim($endpoint, '/') . '/chat/completions';
    }

    public function build_rotation_url($provider_id, $model)
    {
        if ($provider_id === 'gemini') {
            $api_key = $this->get_api_key('gemini');
            return "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key=" . $api_key;
        }

        $endpoint = $this->get_endpoint($provider_id);
        return rtrim($endpoint, '/') . '/chat/completions';
    }

    public function build_rotation_headers($provider_id, $url = '')
    {
        if ($provider_id === 'gemini') {
            return array('Content-Type' => 'application/json');
        }

        $api_key = $this->get_api_key($provider_id);
        $headers = array(
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type'  => 'application/json',
        );

        if (strpos($url, 'openrouter.ai') !== false) {
            $headers['HTTP-Referer'] = get_site_url();
            $headers['X-Title']      = get_bloginfo('name');
        }

        return $headers;
    }

    public function build_request_body($provider_id, $messages, $model = '', $extra = array())
    {
        $active = $provider_id ?: get_option('mcqvs_api_provider', 'gemini');
        if ($active === '' || $active === 'gemini') {
            $active = 'gemini';
        }

        $use_model = $model ?: $this->get_working_model($active);

        if ($active === 'gemini') {
            $contents = array();
            $system_text = '';
            $user_parts = array();
            foreach ($messages as $msg) {
                if (($msg['role'] ?? '') === 'system') {
                    $system_text = $msg['content'];
                } else {
                    $user_parts[] = array('text' => $msg['content']);
                }
            }
            $content_parts = $user_parts;
            if ($system_text) {
                $system_instruction = array('parts' => array(array('text' => $system_text)));
            }

            $body = array(
                'contents' => array(array('parts' => $content_parts)),
            );
            if (!empty($system_instruction)) {
                $body['systemInstruction'] = $system_instruction;
            }
            if (!empty($extra['response_schema'])) {
                $body['generationConfig'] = array(
                    'response_mime_type' => 'application/json',
                    'response_schema'    => $extra['response_schema'],
                );
            } elseif (!empty($extra['json_mode'])) {
                $body['generationConfig'] = array(
                    'response_mime_type' => 'application/json',
                );
            }
            return $body;
        }

        $body = array(
            'model'       => $use_model,
            'messages'    => $messages,
            'stream'      => false,
            'temperature' => 0.2,
            'max_tokens'  => 8192,
        );

        if (!empty($extra['json_mode'])) {
            $has_array_schema = !empty($extra['response_schema']) && strtoupper($extra['response_schema']['type'] ?? '') === 'ARRAY';

            if ($this->supports_json_schema($active) && !empty($extra['response_schema'])) {
                $body['response_format'] = array(
                    'type'       => 'json_schema',
                    'json_schema' => array(
                        'name'   => 'structured_response',
                        'schema' => $this->normalize_schema_types($extra['response_schema']),
                    ),
                );
            } elseif ($has_array_schema) {
                // json_object mode constrains to single {} object, which
                // conflicts with ARRAY schemas. Omit response_format and
                // rely on explicit prompt instructions + fallback parser.
            } else {
                $body['response_format'] = array('type' => 'json_object');
            }
        }

        $body = apply_filters('mcqvs_custom_provider_request_body', $body, $active, $use_model);

        return $body;
    }

    public function execute_request($provider_id, $url, $body, $timeout = 120)
    {
        $active = $provider_id ?: get_option('mcqvs_api_provider', 'gemini');
        if ($active === '' || $active === 'gemini') {
            $active = 'gemini';
        }

        if ($active === 'gemini') {
            return wp_remote_post($url, array(
                'body'    => wp_json_encode($body),
                'headers' => array('Content-Type' => 'application/json'),
                'timeout' => $timeout,
            ));
        }

        $api_key = $this->get_api_key($active);
        $headers = array(
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type'  => 'application/json',
        );

        if (strpos($url, 'openrouter.ai') !== false) {
            $headers['HTTP-Referer'] = get_site_url();
            $headers['X-Title']      = get_bloginfo('name');
        }

        return wp_remote_post($url, array(
            'headers' => $headers,
            'body'    => wp_json_encode($body),
            'timeout' => $timeout,
        ));
    }

    public function extract_content($provider_id, $response_body)
    {
        $active = $provider_id ?: get_option('mcqvs_api_provider', 'gemini');
        if ($active === '' || $active === 'gemini') {
            $active = 'gemini';
        }

        $data = is_array($response_body) ? $response_body : json_decode($response_body, true);
        if (!is_array($data)) {
            return '';
        }

        if ($active === 'gemini') {
            return $data['candidates'][0]['content']['parts'][0]['text'] ?? '';
        }

        $message = $data['choices'][0]['message'] ?? array();
        $content = $message['content'] ?? '';

        if (empty($content) && !empty($message['tool_calls'])) {
            $tool_args = array();
            foreach ($message['tool_calls'] as $tc) {
                $args = $tc['function']['arguments'] ?? '';
                if ($args !== '') {
                    $tool_args[] = $args;
                }
            }
            if (!empty($tool_args)) {
                $content = implode("\n", $tool_args);
            }
        }

        return $content;
    }

    /**
     * Convert Gemini UPPERCASE schema type names to OpenAI lowercase format.
     */
    private function normalize_schema_types($schema)
    {
        if (!is_array($schema)) {
            return $schema;
        }

        $type_map = array(
            'ARRAY'   => 'array',
            'OBJECT'  => 'object',
            'STRING'  => 'string',
            'INTEGER' => 'integer',
            'BOOLEAN' => 'boolean',
            'NUMBER'  => 'number',
        );

        $result = array();
        foreach ($schema as $key => $value) {
            if ($key === 'type' && is_string($value)) {
                $result[$key] = $type_map[strtoupper($value)] ?? $value;
            } elseif (is_array($value)) {
                $result[$key] = $this->normalize_schema_types($value);
            } else {
                $result[$key] = $value;
            }
        }
        return $result;
    }

    public function get_rotation_state()
    {
        $state = get_option('mcqvs_rotation_state', '');
        if (is_string($state) && $state !== '') {
            $decoded = json_decode($state, true);
            if (is_array($decoded)) {
                $decoded['failures'] = is_array($decoded['failures'] ?? null) ? $decoded['failures'] : array();
                $decoded['cooldown_until'] = is_array($decoded['cooldown_until'] ?? null) ? $decoded['cooldown_until'] : array();
                $decoded['consecutive_failures'] = isset($decoded['consecutive_failures']) ? (int) $decoded['consecutive_failures'] : 0;
                return $decoded;
            }
        }
        return array(
            'current_index'          => 0,
            'last_provider'          => '',
            'last_model'             => '',
            'failures'               => array(),
            'cooldown_until'         => array(),
            'consecutive_failures'   => 0,
            'updated_at'             => 0,
        );
    }

    private function save_rotation_state($state)
    {
        $state['updated_at'] = time();
        update_option('mcqvs_rotation_state', wp_json_encode($state));
    }

    public function get_rotation_queue()
    {
        $queue = array();
        $active = get_option('mcqvs_api_provider', 'gemini');

        $provider_order = array();
        if (!empty($active)) {
            $provider_order[] = $active;
        }

        $builtin = $this->get_builtin_providers();
        foreach (array_keys($builtin) as $id) {
            if (!in_array($id, $provider_order, true)) {
                $provider_order[] = $id;
            }
        }

        $custom = $this->get_custom_providers();
        foreach ($custom as $profile) {
            $pid = $profile['id'] ?? '';
            if ($pid !== '' && !in_array($pid, $provider_order, true)) {
                $provider_order[] = $pid;
            }
        }

        foreach ($provider_order as $pid) {
            $is_builtin = isset($builtin[$pid]);
            $models = $this->get_supported_models($pid);

            if ($is_builtin) {
                $key_option = $builtin[$pid]['key_option'] ?? '';
                $prefix = $builtin[$pid]['name'] ?? $pid;
            } else {
                $key_option = '';
                $profile_data = $this->get_custom_profile($pid);
                $prefix = $profile_data['name'] ?? 'Custom';
                if (empty($models) && !empty($profile_data['api_url'])) {
                    $models = array('default' => $prefix . ' (default)');
                }
            }

            foreach ($models as $model_id => $label) {
                $queue[] = array(
                    'provider'   => $pid,
                    'model'      => $model_id,
                    'label'      => $prefix . ' / ' . $label,
                    'key_option' => $key_option,
                );
            }
        }

        return apply_filters('mcqvs_rotation_queue', $queue, $active);
    }

    public function get_next_model($context = 'auto')
    {
        $queue = $this->get_rotation_queue();
        if (empty($queue)) {
            return array('provider' => 'gemini', 'model' => $this->get_working_model('gemini'));
        }

        $state = $this->get_rotation_state();
        $failures = $state['failures'];
        $cooldown_until = $state['cooldown_until'];
        $max_failures_per_slot = 3;
        $now = time();

        $current_index = isset($state['current_index']) ? (int) $state['current_index'] : 0;
        if ($current_index >= count($queue)) {
            $current_index = 0;
        }

        $queue_size = count($queue);
        $attempts = 0;
        $tried_providers = array();

        while ($attempts < $queue_size) {
            $slot = $queue[$current_index];
            $slot_key = $slot['provider'] . '::' . $slot['model'];
            $provider_key = $slot['provider'];

            $tried_providers[$provider_key] = true;

            // @FIX 1.5.1 (PER-MODEL COOLDOWN): a 429/503 on ONE model must NOT cool down
            // the whole provider (e.g. OpenRouter with many models). Cooldown is keyed by
            // provider::model, so only that exact model is skipped and the next model in
            // the same provider is tried.
            if (isset($cooldown_until[$slot_key]) && $cooldown_until[$slot_key] > $now) {
                $current_index = ($current_index + 1) % $queue_size;
                $attempts++;
                continue;
            }

            if (isset($cooldown_until[$slot_key]) && $cooldown_until[$slot_key] <= $now) {
                unset($cooldown_until[$slot_key]);
                $state['cooldown_until'] = $cooldown_until;
                $failures[$slot_key] = 0;
                $this->save_rotation_state($state);
            }

            $slot_fail_count = isset($failures[$slot_key]) ? (int) $failures[$slot_key] : 0;
            $provider_fail_count = isset($failures[$provider_key]) ? (int) $failures[$provider_key] : 0;

            if ($slot_fail_count < $max_failures_per_slot) {
                $state['current_index'] = ($current_index + 1) % $queue_size;
                $state['last_provider'] = $slot['provider'];
                $state['last_model'] = $slot['model'];
                $this->save_rotation_state($state);

                return array(
                    'provider' => $slot['provider'],
                    'model'    => $slot['model'],
                    'label'    => $slot['label'],
                );
            }

            $failures[$slot_key] = 0;
            $current_index = ($current_index + 1) % $queue_size;
            $attempts++;
        }

        $unique_providers = array();
        foreach ($queue as $q) {
            $unique_providers[$q['provider']] = true;
        }

        if (count($tried_providers) < count($unique_providers)) {
            $reset_index = isset($state['current_index']) ? (int) $state['current_index'] : 0;
            if ($reset_index >= $queue_size) {
                $reset_index = 0;
            }
            $state['failures'] = array();
            $state['current_index'] = ($reset_index + 1) % max(1, $queue_size);
            $this->save_rotation_state($state);

            $next_slot = $queue[$reset_index];
            return array(
                'provider' => $next_slot['provider'],
                'model'    => $next_slot['model'],
                'label'    => $next_slot['label'],
            );
        }

        $state['failures'] = array();
        $state['current_index'] = 0;
        $this->save_rotation_state($state);

        $slot = $queue[0];
        return array(
            'provider' => $slot['provider'],
            'model'    => $slot['model'],
            'label'    => $slot['label'],
        );
    }

    public function record_failure($provider, $model, $error_code = '')
    {
        $state = $this->get_rotation_state();
        if (!isset($state['failures']) || !is_array($state['failures'])) {
            $state['failures'] = array();
        }
        if (!isset($state['cooldown_until']) || !is_array($state['cooldown_until'])) {
            $state['cooldown_until'] = array();
        }

        $slot_key = $provider . '::' . $model;
        $state['failures'][$slot_key] = isset($state['failures'][$slot_key]) ? (int) $state['failures'][$slot_key] + 1 : 1;
        $state['failures'][$provider] = isset($state['failures'][$provider]) ? (int) $state['failures'][$provider] + 1 : 1;

        $err_code_normalized = strtolower((string) $error_code);
        $is_quota_or_rate = in_array($err_code_normalized, array('rate_limited', '429', 'quota_exhausted', 'resource_exhausted', 'api_error'), true)
            || in_array((int) $error_code, array(429, 503), true);

        $cooldown_seconds = 0;
        if ($is_quota_or_rate) {
            $cooldown_seconds = (int) get_option('mcqvs_provider_failure_cooldown', 600);
            if ($cooldown_seconds < 60) {
                $cooldown_seconds = 600;
            }
        }

        if ($cooldown_seconds > 0) {
            // @FIX 1.5.1 (PER-MODEL COOLDOWN): cooldown is keyed by provider::model so a
            // throttled model doesn't take the whole provider (e.g. OpenRouter) offline.
            $state['cooldown_until'][$slot_key] = time() + $cooldown_seconds;
            $state['consecutive_failures'] = isset($state['consecutive_failures']) ? (int) $state['consecutive_failures'] + 1 : 1;
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log(
                    "Model '{$slot_key}' failed (code={$error_code}). Cooling down for {$cooldown_seconds}s. Will try other models/providers.",
                    'warning',
                    array('provider' => $provider, 'model' => $model, 'slot' => $slot_key, 'cooldown_seconds' => $cooldown_seconds, 'consecutive_failures' => $state['consecutive_failures'])
                );
            }
        }

        $this->save_rotation_state($state);

        if ($cooldown_seconds === 0 && class_exists('VS_Error_Logger')) {
            VS_Error_Logger::get_instance()->log(
                "Provider '{$provider}' model '{$model}' failed (code={$error_code}).",
                'warning',
                array('provider' => $provider, 'model' => $model, 'error_code' => $error_code)
            );
        }
    }

    public function record_success($provider, $model)
    {
        $state = $this->get_rotation_state();
        if (!isset($state['failures']) || !is_array($state['failures'])) {
            $state['failures'] = array();
        }
        $slot_key = $provider . '::' . $model;
        if (isset($state['failures'][$slot_key]) && (int) $state['failures'][$slot_key] > 0) {
            $state['failures'][$slot_key] = max(0, (int) $state['failures'][$slot_key] - 1);
        }
        if (isset($state['failures'][$provider]) && (int) $state['failures'][$provider] > 0) {
            $state['failures'][$provider] = max(0, (int) $state['failures'][$provider] - 1);
        }
        // @FIX 1.5.1: clear the per-model cooldown on success (provider::model key).
        if (isset($state['cooldown_until'][$slot_key])) {
            unset($state['cooldown_until'][$slot_key]);
        }
        $state['consecutive_failures'] = 0;
        $this->save_rotation_state($state);
    }

    public function reset_failures()
    {
        $state = $this->get_rotation_state();
        $state['failures'] = array();
        $state['cooldown_until'] = array();
        $state['consecutive_failures'] = 0;
        $state['current_index'] = 0;
        $this->save_rotation_state($state);
    }

    /**
     * @NEW 2026-07-05: Get visible rotation state for the Dashboard / Debug surface.
     * @return array
     */
    public function get_rotation_status()
    {
        $state = $this->get_rotation_state();
        $queue = $this->get_rotation_queue();
        $unique_providers = array();
        foreach ($queue as $slot) {
            $provider = $slot['provider'];
            $slot_key = $slot['provider'] . '::' . $slot['model'];
            if (!isset($unique_providers[$provider])) {
                $unique_providers[$provider] = array(
                    'provider' => $provider,
                    'label' => $slot['label'],
                    'models' => array(),
                    'failures' => isset($state['failures'][$provider]) ? (int) $state['failures'][$provider] : 0,
                    'cooldown_until' => 0,
                );
            }
            // @FIX 1.5.1: track per-model cooldown; expose the highest for the provider row
            // and the per-model detail on each model.
            $model_cooldown = isset($state['cooldown_until'][$slot_key]) ? (int) $state['cooldown_until'][$slot_key] : 0;
            if ($model_cooldown > $unique_providers[$provider]['cooldown_until']) {
                $unique_providers[$provider]['cooldown_until'] = $model_cooldown;
            }
            $unique_providers[$provider]['models'][] = array(
                'model' => $slot['model'],
                'label' => $slot['label'],
                'failures' => isset($state['failures'][$slot_key]) ? (int) $state['failures'][$slot_key] : 0,
                'cooldown_until' => $model_cooldown,
            );
        }
        return array(
            'providers' => array_values($unique_providers),
            'current_index' => isset($state['current_index']) ? (int) $state['current_index'] : 0,
            'last_provider' => isset($state['last_provider']) ? $state['last_provider'] : '',
            'last_model' => isset($state['last_model']) ? $state['last_model'] : '',
            'consecutive_failures' => isset($state['consecutive_failures']) ? (int) $state['consecutive_failures'] : 0,
        );
    }

    public function test_connection($provider_id)
    {
        $active = $provider_id ?: get_option('mcqvs_api_provider', 'gemini');
        if ($active === '' || $active === 'gemini') {
            $active = 'gemini';
        }

        $api_key = $this->get_api_key($active);
        if (empty($api_key)) {
            return new WP_Error('no_key', 'API key not configured for provider: ' . $active);
        }

        if ($active === 'gemini') {
            $model = $this->get_working_model('gemini');
            $url = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key=" . $api_key;
            $body = array(
                'contents' => array(array('parts' => array(array('text' => 'Ping')))),
                'generationConfig' => array('maxOutputTokens' => 5),
            );
            $response = wp_remote_post($url, array(
                'body'    => wp_json_encode($body),
                'headers' => array('Content-Type' => 'application/json'),
                'timeout' => 30,
            ));
        } else {
            $endpoint = $this->get_endpoint($active);
            $model = $this->get_working_model($active);
            $url = rtrim($endpoint, '/') . '/chat/completions';
            $headers = array(
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json',
            );
            if (strpos($url, 'openrouter.ai') !== false) {
                $headers['HTTP-Referer'] = get_site_url();
                $headers['X-Title']      = get_bloginfo('name');
            }
            $body = array(
                'model'      => $model,
                'messages'   => array(array('role' => 'user', 'content' => 'Ping')),
                'max_tokens' => 5,
                'temperature'=> 0,
                'stream'     => false,
            );
            $response = wp_remote_post($url, array(
                'headers' => $headers,
                'body'    => wp_json_encode($body),
                'timeout' => 30,
            ));
        }

        if (is_wp_error($response)) {
            return new WP_Error('connection_failed', 'Connection failed: ' . $response->get_error_message());
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            $raw = wp_remote_retrieve_body($response);
            $err_data = json_decode($raw, true);
            $err_msg = $err_data['error']['message'] ?? substr($raw, 0, 200);
            return new WP_Error('api_error', "API returned {$code}: " . $err_msg);
        }

        return array(
            'status'   => 'connected',
            'model'    => $model ?? $this->get_working_model($active),
            'provider' => $active,
        );
    }
}
