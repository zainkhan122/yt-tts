<?php

/**
 * Log Viewer for Video Studio
 *
 * Renders the dedicated admin Logs page.
 *
 * Storage: wp_vs_logs (persistent DB, configurable retention 1-30 days).
 * Previous transient-based storage is retired.
 *
 * Features:
 *   - Summary cards (total, errors, warnings, info, retention window count)
 *   - Filterable, searchable, sortable table with AJAX pagination
 *   - Expandable rows showing full API request + response payload
 *   - Bulk-select with JSON + CSV download
 *   - Clear logs / prune now buttons
 *   - Server time display + storage stats
 *
 * @package MCQ_Video_Studio
 * @since   1.0.0
 * @modified 2026-07-06: Full rewrite — persistent DB storage, professional UI.
 */

if (! defined('ABSPATH')) {
    exit;
}

class VS_Log_Viewer
{
    private static $instance = null;

    public static function get_instance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    // ------------------------------------------------------------------
    //  HOOKS
    // ------------------------------------------------------------------

    public function init()
    {
        add_action('wp_ajax_mcqvs_clear_logs',  array($this, 'ajax_clear_logs'));
        add_action('wp_ajax_mcqvs_list_logs',    array($this, 'ajax_list_logs'));
        add_action('wp_ajax_mcqvs_log_detail',   array($this, 'ajax_log_detail'));
        add_action('wp_ajax_mcqvs_delete_logs',  array($this, 'ajax_delete_logs'));
        add_action('wp_ajax_mcqvs_prune_logs',   array($this, 'ajax_prune_logs'));
    }

    public function add_menu_page()
    {
        // Deprecated — Logs submenu is registered in VS_Core.
    }

    // ------------------------------------------------------------------
    //  AJAX: List logs with filters
    // ------------------------------------------------------------------

    public function ajax_list_logs()
    {
        check_ajax_referer('mcqvs_log_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        $args = array(
            'level'  => isset($_GET['level'])  ? sanitize_text_field($_GET['level'])   : '',
            'source' => isset($_GET['source']) ? sanitize_text_field($_GET['source'])  : '',
            'search' => isset($_GET['search']) ? sanitize_text_field($_GET['search'])  : '',
            'from'   => isset($_GET['from'])   ? sanitize_text_field($_GET['from'])    : '',
            'to'     => isset($_GET['to'])     ? sanitize_text_field($_GET['to'])      : '',
            'limit'  => isset($_GET['limit'])  ? absint($_GET['limit'])               : 100,
            'offset' => isset($_GET['offset']) ? absint($_GET['offset'])              : 0,
            'order'  => isset($_GET['order'])  ? sanitize_text_field($_GET['order'])   : 'DESC',
        );

        // Enforce max limit
        if ($args['limit'] > 1000) $args['limit'] = 1000;

        $logger = VS_Error_Logger::get_instance();
        $result = $logger->get_logs_filtered($args);

        // Decode context_json for each row; strip large blob fields (node_log_output)
        // from the list view to keep the JSON payload small. Full context is available
        // in the single-row detail view (ajax_log_detail).
        $rows = array();
        foreach ($result['rows'] as $r) {
            $context = json_decode($r['context_json'], true);
            if (is_array($context) && array_key_exists('node_log_output', $context)) {
                $context['node_log_output'] = null;
            }
            $r['context']     = $context;
            $r['context_json'] = null;
            // @FIX 2026-08-03: Convert UTC timestamp to site local time for display
            // @FIX 2026-08-04: Use wp_date() to respect WordPress site timezone
            $r['ts_display']  = wp_date('Y-m-d H:i:s', strtotime($r['ts'] . ' UTC'));
            $rows[] = $r;
        }

        $settings = array(
            'retention_days' => (int) get_option('mcqvs_log_retention_days', 7),
            'visible_count'  => (int) get_option('mcqvs_log_visible_count', 25),
            'max_total'      => (int) get_option('mcqvs_log_max_total', 5000),
        );

        wp_send_json_success(array(
            'rows'     => $rows,
            'total'    => $result['total'],
            'settings' => $settings,
        ));
    }

    // ------------------------------------------------------------------
    //  AJAX: Single log detail
    // ------------------------------------------------------------------

    public function ajax_log_detail()
    {
        check_ajax_referer('mcqvs_log_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        $id = isset($_GET['id']) ? absint($_GET['id']) : 0;
        if ($id <= 0) {
            wp_send_json_error('Invalid ID');
        }

        $row = VS_Error_Logger::get_instance()->get_log($id);
        if (!$row) {
            wp_send_json_error('Log not found');
        }

        $row['context'] = json_decode($row['context_json'], true);
        unset($row['context_json']);

        wp_send_json_success($row);
    }

    // ------------------------------------------------------------------
    //  AJAX: Bulk delete by IDs
    // ------------------------------------------------------------------

    public function ajax_delete_logs()
    {
        check_ajax_referer('mcqvs_log_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        $ids = isset($_POST['ids']) ? array_map('absint', (array) $_POST['ids']) : array();
        $ids = array_filter($ids, function ($v) { return $v > 0; });

        if (empty($ids)) {
            wp_send_json_error('No IDs provided');
        }

        $deleted = VS_Error_Logger::get_instance()->delete_logs($ids);
        wp_send_json_success(array('deleted' => $deleted));
    }

    // ------------------------------------------------------------------
    //  AJAX: Prune (manual trigger)
    // ------------------------------------------------------------------

    public function ajax_prune_logs()
    {
        check_ajax_referer('mcqvs_log_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        VS_Error_Logger::get_instance()->prune_daily_telemetry();
        wp_send_json_success(array('message' => 'Pruning complete.'));
    }

    // ------------------------------------------------------------------
    //  AJAX: Clear all logs
    // ------------------------------------------------------------------

    public function ajax_clear_logs()
    {
        // Accept the unified studio nonce (used by the Studio Editor diagnostics
        // "Clear Logs" button) as well as the legacy log-viewer nonce so the
        // action works from both surfaces.
        if (
            ! check_ajax_referer('mcqvs_studio_nonce', 'nonce', false) &&
            ! check_ajax_referer('mcqvs_log_nonce', 'nonce', false)
        ) {
            wp_send_json_error('Invalid nonce');
        }
        if (! current_user_can('manage_options')) {
            wp_send_json_error();
        }

        VS_Error_Logger::get_instance()->clear_logs();
        wp_send_json_success();
    }

    // ------------------------------------------------------------------
    //  PAGE RENDER
    // ------------------------------------------------------------------

    public function render_page($is_tab = false)
    {
        if (! current_user_can('manage_options')) {
            wp_die('Access Denied');
        }

        $logger       = VS_Error_Logger::get_instance();
        $stats        = $logger->get_stats();
        $retention    = $logger->retention_days();
        $visible      = (int) get_option('mcqvs_log_visible_count', 25);
        $has_table    = $logger->table_exists();

        $nonce        = wp_create_nonce('mcqvs_log_nonce');
        $ajax_url     = admin_url('admin-ajax.php');
        $server_time  = current_time('Y-m-d H:i:s');

        ?>
        <div class="<?php echo $is_tab ? 'vs-tab-content' : 'wrap'; ?>" id="mcqvs-log-viewer-root">
        <?php if (!$is_tab) : ?>
            <h1 class="wp-heading-inline"><?php esc_html_e('Error Logs', 'mcq-video-studio'); ?></h1>
            <hr class="wp-header-end">
        <?php endif; ?>

        <style>
            /* ---- Cards ---- */
            .mcqvs-log-cards{display:grid;grid-template-columns:repeat(5,1fr);gap:12px;margin:16px 0 20px}
            .mcqvs-log-card{background:#fff;border:1px solid #e2e4e9;border-radius:8px;padding:14px 16px;position:relative;transition:box-shadow .15s}
            .mcqvs-log-card:hover{box-shadow:0 2px 8px rgba(0,0,0,.06)}
            .mcqvs-log-card-icon{width:32px;height:32px;border-radius:7px;display:flex;align-items:center;justify-content:center;font-size:14px;margin-bottom:8px}
            .mcqvs-log-card-icon.grey{background:#f1f5f9;color:#64748b}
            .mcqvs-log-card-icon.red{background:#fee2e2;color:#dc2626}
            .mcqvs-log-card-icon.amber{background:#fef3c7;color:#d97706}
            .mcqvs-log-card-icon.blue{background:#dbeafe;color:#2563eb}
            .mcqvs-log-card-icon.green{background:#dcfce7;color:#16a34a}
            .mcqvs-log-card-label{font-size:10px;font-weight:600;color:#64748b;text-transform:uppercase;letter-spacing:.5px;margin-bottom:3px}
            .mcqvs-log-card-val{font-size:22px;font-weight:700;color:#1e293b;line-height:1}
            .mcqvs-log-card-sub{font-size:11px;color:#94a3b8;margin-top:4px}

            /* ---- Toolbar ---- */
            .mcqvs-log-toolbar{display:flex;flex-wrap:wrap;align-items:center;gap:10px;margin-bottom:14px;background:#fff;border:1px solid #e2e4e9;border-radius:8px;padding:12px 16px}
            .mcqvs-log-toolbar select,.mcqvs-log-toolbar input[type=text],.mcqvs-log-toolbar input[type=date]{font-size:13px;padding:5px 8px;border:1px solid #d1d5db;border-radius:4px;height:30px}
            .mcqvs-log-toolbar select{min-width:110px}
            .mcqvs-log-toolbar input[type=text]{min-width:200px}
            .mcqvs-log-toolbar input[type=date]{min-width:130px}
            .mcqvs-log-sep{width:1px;height:24px;background:#e2e4e9;flex-shrink:0}
            .mcqvs-log-toolbar .button{height:30px;line-height:28px;padding:0 12px;font-size:12px;border-radius:4px}
            .mcqvs-log-toolbar .mcqvs-log-bulk{display:none;align-items:center;gap:6px}
            .mcqvs-log-toolbar .mcqvs-log-bulk.active{display:flex}
            .mcqvs-log-toolbar .mcqvs-log-bulk .count{font-size:11px;color:#64748b}
            .mcqvs-log-toolbar .mcqvs-log-meta{margin-left:auto;font-size:11px;color:#94a3b8;white-space:nowrap}

            /* ---- Table ---- */
            .mcqvs-log-table{width:100%;border-collapse:collapse;background:#fff;border:1px solid #e2e4e9;border-radius:8px;overflow:hidden;margin-bottom:14px}
            .mcqvs-log-table thead{background:#f8fafc;border-bottom:2px solid #e2e4e9}
            .mcqvs-log-table th{text-align:left;padding:10px 12px;font-size:11px;font-weight:600;color:#64748b;text-transform:uppercase;letter-spacing:.5px;cursor:pointer;user-select:none;white-space:nowrap}
            .mcqvs-log-table th:hover{color:#334155}
            .mcqvs-log-table th .sort-arrow{font-size:9px;margin-left:3px;opacity:.4}
            .mcqvs-log-table th.sorted .sort-arrow{opacity:1}
            .mcqvs-log-table td{padding:10px 12px;font-size:12px;border-bottom:1px solid #f1f5f9;vertical-align:top}
            .mcqvs-log-table tr:last-child td{border-bottom:none}
            .mcqvs-log-table tr:hover{background:#f8fafc}
            .mcqvs-log-table tr.selected{background:#eff6ff}
            .mcqvs-log-table .cb-col{width:32px;text-align:center;vertical-align:middle}
            .mcqvs-log-table .cb-col input{margin:0}

            /* Level badges */
            .mcqvs-lvl{display:inline-block;padding:2px 8px;border-radius:10px;font-size:10px;font-weight:600;text-transform:uppercase;letter-spacing:.3px}
            .mcqvs-lvl-error{background:#fee2e2;color:#dc2626}
            .mcqvs-lvl-warning{background:#fef3c7;color:#d97706}
            .mcqvs-lvl-info{background:#dbeafe;color:#2563eb}
            .mcqvs-lvl-debug{background:#f1f5f9;color:#64748b}

            /* Source badges */
            .mcqvs-src{display:inline-block;padding:2px 6px;border-radius:3px;font-size:10px;font-weight:600}
            .mcqvs-src-server{background:#dbeafe;color:#2563eb}
            .mcqvs-src-client{background:#f3e8ff;color:#9333ea}

            /* Expand row */
            .mcqvs-expand-btn{cursor:pointer;color:#2563eb;font-size:11px;border:none;background:none;padding:0;font-weight:600}
            .mcqvs-expand-btn:hover{text-decoration:underline}
            .mcqvs-detail-row{display:none}
            .mcqvs-detail-row.open{display:table-row}
            .mcqvs-detail-row td{padding:0 12px 12px 40px;background:#fafbfc;border-bottom:1px solid #e2e4e9}
            .mcqvs-detail-card{background:#fff;border:1px solid #e2e4e9;border-radius:6px;padding:14px;margin-top:6px}
            .mcqvs-detail-card-title{font-size:11px;font-weight:700;color:#334155;margin-bottom:8px;text-transform:uppercase;letter-spacing:.4px}
            .mcqvs-detail-pre{background:#1e293b;color:#e2e8f0;padding:12px 14px;border-radius:6px;overflow-x:auto;max-height:320px;font-family:'JetBrains Mono','Fira Code',monospace;font-size:11px;line-height:1.6;white-space:pre-wrap;word-wrap:break-word;margin:0}
            .mcqvs-detail-pre .json-key{color:#7dd3fc}
            .mcqvs-detail-pre .json-string{color:#86efac}
            .mcqvs-detail-pre .json-num{color:#fbbf24}
            .mcqvs-detail-pre .json-bool{color:#c084fc}
            .mcqvs-detail-pre .json-null{color:#94a3b8}

            /* Pagination */
            .mcqvs-log-pager{display:flex;align-items:center;gap:8px;justify-content:center;margin:16px 0}
            .mcqvs-log-pager .button{padding:4px 10px;font-size:12px}
            .mcqvs-log-pager .button.disabled{opacity:.45;cursor:default;pointer-events:none}
            .mcqvs-log-pager .mcqvs-pager-info{font-size:12px;color:#64748b}

            /* Empty state */
            .mcqvs-log-empty{text-align:center;padding:40px 20px;color:#94a3b8;font-size:14px}
            .mcqvs-log-empty-icon{font-size:36px;margin-bottom:10px;opacity:.3}

            /* Responsive */
            @media(max-width:960px){.mcqvs-log-cards{grid-template-columns:repeat(3,1fr)}}
            @media(max-width:640px){.mcqvs-log-cards{grid-template-columns:1fr 1fr}.mcqvs-log-toolbar{flex-direction:column;align-items:stretch}}
        </style>

        <!-- Summary cards -->
        <div class="mcqvs-log-cards">
            <div class="mcqvs-log-card">
                <div class="mcqvs-log-card-icon grey">&#128196;</div>
                <div class="mcqvs-log-card-label"><?php esc_html_e('Total Stored', 'mcq-video-studio'); ?></div>
                <div class="mcqvs-log-card-val"><?php echo number_format_i18n($stats['total']); ?></div>
                <div class="mcqvs-log-card-sub"><?php printf(esc_html__('Max: %s', 'mcq-video-studio'), number_format_i18n((int) get_option('mcqvs_log_max_total', 5000))); ?></div>
            </div>
            <div class="mcqvs-log-card">
                <div class="mcqvs-log-card-icon red">&#9888;</div>
                <div class="mcqvs-log-card-label"><?php esc_html_e('Errors', 'mcq-video-studio'); ?></div>
                <div class="mcqvs-log-card-val"><?php echo number_format_i18n($stats['errors']); ?></div>
            </div>
            <div class="mcqvs-log-card">
                <div class="mcqvs-log-card-icon amber">&#128295;</div>
                <div class="mcqvs-log-card-label"><?php esc_html_e('Warnings', 'mcq-video-studio'); ?></div>
                <div class="mcqvs-log-card-val"><?php echo number_format_i18n($stats['warnings']); ?></div>
            </div>
            <div class="mcqvs-log-card">
                <div class="mcqvs-log-card-icon blue">&#8505;</div>
                <div class="mcqvs-log-card-label"><?php esc_html_e('Info', 'mcq-video-studio'); ?></div>
                <div class="mcqvs-log-card-val"><?php echo number_format_i18n($stats['info']); ?></div>
            </div>
            <div class="mcqvs-log-card">
                <div class="mcqvs-log-card-icon green">&#128197;</div>
                <div class="mcqvs-log-card-label"><?php printf(esc_html__('Within %d Days', 'mcq-video-studio'), $retention); ?></div>
                <div class="mcqvs-log-card-val"><?php echo number_format_i18n($stats['within_retention']); ?></div>
                <div class="mcqvs-log-card-sub"><?php esc_html_e('Visible in retention window', 'mcq-video-studio'); ?></div>
            </div>
        </div>

        <!-- Toolbar -->
        <div class="mcqvs-log-toolbar" id="mcqvs-log-toolbar">
            <select id="mcqvs-f-level">
                <option value=""><?php esc_html_e('All levels', 'mcq-video-studio'); ?></option>
                <option value="error"><?php esc_html_e('Error', 'mcq-video-studio'); ?></option>
                <option value="warning"><?php esc_html_e('Warning', 'mcq-video-studio'); ?></option>
                <option value="info"><?php esc_html_e('Info', 'mcq-video-studio'); ?></option>
            </select>
            <select id="mcqvs-f-source">
                <option value=""><?php esc_html_e('All sources', 'mcq-video-studio'); ?></option>
                <option value="SERVER"><?php esc_html_e('Server', 'mcq-video-studio'); ?></option>
                <option value="CLIENT"><?php esc_html_e('Client (JS)', 'mcq-video-studio'); ?></option>
            </select>
            <input type="text" id="mcqvs-f-search" placeholder="<?php esc_attr_e('Search message\u2026', 'mcq-video-studio'); ?>" />
            <input type="date" id="mcqvs-f-from" title="<?php esc_attr_e('From date', 'mcq-video-studio'); ?>" />
            <input type="date" id="mcqvs-f-to" title="<?php esc_attr_e('To date', 'mcq-video-studio'); ?>" />
            <div class="mcqvs-log-sep"></div>
            <button type="button" class="button button-secondary" id="mcqvs-f-apply"><?php esc_html_e('Filter', 'mcq-video-studio'); ?></button>
            <button type="button" class="button" id="mcqvs-f-reset" style="color:#64748b"><?php esc_html_e('Reset', 'mcq-video-studio'); ?></button>
            <div class="mcqvs-log-sep"></div>
            <button type="button" class="button button-primary" id="mcqvs-dl-selected" title="<?php esc_attr_e('Download selected as JSON', 'mcq-video-studio'); ?>"><?php esc_html_e('Download', 'mcq-video-studio'); ?></button>
            <button type="button" class="button button-primary" id="mcqvs-dl-all" title="<?php esc_attr_e('Download all filtered results', 'mcq-video-studio'); ?>"><?php esc_html_e('Download All', 'mcq-video-studio'); ?></button>
            <button type="button" class="button" id="mcqvs-copy-all" style="background:#f0fdf4;border-color:#86efac;color:#166534;" title="<?php esc_attr_e('Copy all filtered logs with full details to clipboard', 'mcq-video-studio'); ?>">&#128203; <?php esc_html_e('Copy All', 'mcq-video-studio'); ?></button>
            <div class="mcqvs-log-bulk" id="mcqvs-bulk">
                <span class="count"><strong id="mcqvs-sel-count">0</strong> <?php esc_html_e('selected', 'mcq-video-studio'); ?></span>
                <button type="button" class="button" id="mcqvs-bulk-delete" style="color:#dc2626"><?php esc_html_e('Delete selected', 'mcq-video-studio'); ?></button>
            </div>
            <span class="mcqvs-log-meta">
                <span id="mcqvs-server-time"><?php echo esc_html($server_time); ?></span> &mdash;
                <a href="<?php echo esc_url(admin_url('admin.php?page=mcqvs-settings&tab=logs')); ?>"><?php esc_html_e('Settings', 'mcq-video-studio'); ?></a>
            </span>
        </div>

        <!-- Action buttons (below toolbar) -->
        <div style="display:flex;gap:8px;margin-bottom:12px;">
            <button type="button" class="button button-secondary" id="mcqvs-clear-logs">&#128465; <?php esc_html_e('Clear All Logs', 'mcq-video-studio'); ?></button>
            <button type="button" class="button button-secondary" id="mcqvs-prune-logs">&#9940; <?php esc_html_e('Prune Now', 'mcq-video-studio'); ?></button>
            <button type="button" class="button button-secondary" id="mcqvs-refresh-logs">&#8635; <?php esc_html_e('Refresh', 'mcq-video-studio'); ?></button>
        </div>

        <!-- Table -->
        <div id="mcqvs-log-table-wrap">
            <div class="mcqvs-log-empty" id="mcqvs-loading"><div class="mcqvs-log-empty-icon">&#8987;</div><?php esc_html_e('Loading logs\u2026', 'mcq-video-studio'); ?></div>
        </div>

        <!-- Pagination -->
        <div class="mcqvs-log-pager" id="mcqvs-log-pager"></div>

        <script>
        (function(){
            var $ = jQuery,
                nonce    = <?php echo wp_json_encode($nonce); ?>,
                ajaxUrl  = <?php echo wp_json_encode($ajax_url); ?>,
                defaultVisible = <?php echo (int) $visible; ?>,
                // State
                state = { level:'', source:'', search:'', from:'', to:'', limit: defaultVisible, offset:0, order:'DESC', sort:'ts' },
                allRows = [],
                totalRows = 0,
                selectedIds = {};

            // ---------- Utilities ----------
            function esc(s){ return $('<span>').text(s).html(); }

            function formatCtx(obj){
                if(!obj) return '<em>No context</em>';
                var s = JSON.stringify(obj, null, 2);
                s = esc(s);
                // Basic syntax colouring
                s = s.replace(/"([^"]+)"(?=\s*:)/g, '<span class="json-key">"$1"</span>');
                s = s.replace(/:\s*"([^"]*?)"/g, ': <span class="json-string">"$1"</span>');
                s = s.replace(/:\s*(\d+\.?\d*)/g, ': <span class="json-num">$1</span>');
                s = s.replace(/:\s*(true|false)/g, ': <span class="json-bool">$1</span>');
                s = s.replace(/:\s*(null)/g, ': <span class="json-null">$1</span>');
                return '<pre class="mcqvs-detail-pre">'+s+'</pre>';
            }

            function sourceBadge(src){
                src = (src||'SERVER').toUpperCase();
                var cls = src.indexOf('CLIENT') >= 0 ? 'mcqvs-src-client' : 'mcqvs-src-server';
                var label = src.indexOf('CLIENT') >= 0 ? 'CLIENT' : 'SERVER';
                return '<span class="mcqvs-src '+cls+'">'+label+'</span>';
            }

            function levelBadge(level){
                level = (level||'info').toLowerCase();
                var cls = 'mcqvs-lvl-'+level;
                return '<span class="mcqvs-lvl '+cls+'">'+esc(level.toUpperCase())+'</span>';
            }

            // ---------- Fetch logs ----------
            function fetchLogs(cb){
                var params = {
                    action: 'mcqvs_list_logs',
                    nonce:  nonce,
                    level:  state.level,
                    source: state.source,
                    search: state.search,
                    from:   state.from,
                    to:     state.to,
                    limit:  state.limit,
                    offset: state.offset,
                    order:  state.order
                };
                $.get(ajaxUrl, params, function(res){
                    if(!res.success){ alert('Failed to load logs'); return; }
                    allRows   = res.data.rows;
                    totalRows = res.data.total;
                    if(res.data.settings){
                        defaultVisible = res.data.settings.visible_count || 25;
                        if(state.limit === 0) state.limit = defaultVisible;
                    }
                    if(cb) cb();
                }, 'json');
            }

            // ---------- Render table ----------
            function renderTable(){
                var $wrap = $('#mcqvs-log-table-wrap');
                if(allRows.length === 0){
                    $wrap.html('<div class="mcqvs-log-empty"><div class="mcqvs-log-empty-icon">&#128196;</div><?php echo esc_js(__('No logs found for the selected filters.', 'mcq-video-studio')); ?></div>');
                    renderPager();
                    return;
                }

                var sortArrow = function(col){
                    var arrow = '&#9650;';
                    if(state.sort === col && state.order === 'DESC') arrow = '&#9660;';
                    else if(state.sort !== col) arrow = '&#9650;&#9660;';
                    var cls = state.sort === col ? ' sorted' : '';
                    return '<span class="sort-arrow">'+arrow+'</span>';
                };

                var html = '<table class="mcqvs-log-table"><thead><tr>';
                html += '<th class="cb-col"><input type="checkbox" id="mcqvs-select-all" /></th>';
                html += '<th data-col="ts">Timestamp '+sortArrow('ts')+'</th>';
                html += '<th data-col="level">Level '+sortArrow('level')+'</th>';
                html += '<th data-col="source">Source</th>';
                html += '<th>Message</th>';
                html += '<th style="width:60px"></th>';
                html += '</tr></thead><tbody>';

                for(var i=0;i<allRows.length;i++){
                    var r = allRows[i];
                    var ctxPreview = '';
                    if(r.context){
                        var keys = Object.keys(r.context);
                        if(keys.length <= 3){ ctxPreview = esc(keys.join(', ')); }
                        else { ctxPreview = esc(keys.slice(0,3).join(', '))+' +'+(keys.length-3)+' more'; }
                    }
                    var checked = selectedIds[r.id] ? ' checked' : '';
                    var selCls  = selectedIds[r.id] ? ' selected' : '';
                    html += '<tr class="mcqvs-log-row'+selCls+'" data-id="'+r.id+'">';
                    html += '<td class="cb-col"><input type="checkbox" class="mcqvs-row-cb" value="'+r.id+'"'+checked+' /></td>';
                    html += '<td style="white-space:nowrap;font-size:11px;color:#64748b">'+esc(r.ts)+'</td>';
                    html += '<td>'+levelBadge(r.level)+'</td>';
                    html += '<td>'+sourceBadge(r.source)+'</td>';
                    html += '<td style="max-width:500px;overflow:hidden;text-overflow:ellipsis">'+esc(r.message)+'</td>';
                    html += '<td><button type="button" class="mcqvs-expand-btn" data-idx="'+i+'">&#9654; Details</button></td>';
                    html += '</tr>';
                    // Detail row (hidden by default)
                    html += '<tr class="mcqvs-detail-row" id="mcqvs-detail-'+r.id+'">';
                    html += '<td colspan="6">';
                    html += '<div class="mcqvs-detail-card">';
                    if(r.context){
                        html += '<div class="mcqvs-detail-card-title">Context / Payload</div>';
                        html += formatCtx(r.context);
                    }
                    if(r.request_uri){
                        html += '<div class="mcqvs-detail-card-title" style="margin-top:10px">Request URI</div>';
                        html += '<div style="font-size:11px;color:#64748b;margin-bottom:6px">'+esc(r.request_uri)+'</div>';
                    }
                    if(r.user_id){
                        html += '<div class="mcqvs-detail-card-title" style="margin-top:10px">User</div>';
                        html += '<div style="font-size:11px;color:#64748b">User ID: '+esc(r.user_id)+'</div>';
                    }
                    html += '</div>';
                    html += '</td></tr>';
                }
                html += '</tbody></table>';
                $wrap.html(html);
                renderPager();
                updateBulk();
            }

            // ---------- Pager ----------
            function renderPager(){
                var pages  = Math.ceil(totalRows / state.limit),
                    cur    = Math.floor(state.offset / state.limit) + 1,
                    $pager = $('#mcqvs-log-pager');
                if(totalRows <= state.limit || pages <= 1){ $pager.html(''); return; }

                var html = '';
                html += '<button class="button mcqvs-pg-btn'+(cur<=1?' disabled':'')+'" data-page="'+(cur-1)+'">&#8249; Prev</button>';
                html += '<span class="mcqvs-pager-info"><?php echo esc_js(__('Page', 'mcq-video-studio')); ?> '+cur+' / '+pages+' &mdash; '+totalRows+' <?php echo esc_js(__('total', 'mcq-video-studio')); ?></span>';
                html += '<button class="button mcqvs-pg-btn'+(cur>=pages?' disabled':'')+'" data-page="'+(cur+1)+'">Next &#8250;</button>';
                $pager.html(html);
            }

            // ---------- Bulk selection ----------
            function updateBulk(){
                var count = Object.keys(selectedIds).length;
                $('#mcqvs-sel-count').text(count);
                if(count > 0){ $('#mcqvs-bulk').addClass('active'); }
                else { $('#mcqvs-bulk').removeClass('active'); }
            }

            function toggleSelectAll(){
                var checked = $('#mcqvs-select-all').is(':checked');
                if(checked){
                    for(var i=0;i<allRows.length;i++) selectedIds[allRows[i].id] = true;
                } else {
                    selectedIds = {};
                }
                renderTable();
            }

            // ---------- Events ----------
            $(document).on('click','.mcqvs-expand-btn',function(){
                var id = $(this).closest('tr').data('id');
                $('#mcqvs-detail-'+id).toggleClass('open');
                var txt = $(this).closest('tr').next().hasClass('open') ? '&#9660; Collapse' : '&#9654; Details';
                $(this).html(txt);
            });

            $(document).on('change','.mcqvs-row-cb',function(){
                var id = $(this).val();
                if($(this).is(':checked')){ selectedIds[id]=true; }
                else { delete selectedIds[id]; }
                $(this).closest('tr').toggleClass('selected', $(this).is(':checked'));
                updateBulk();
            });

            $('#mcqvs-select-all').on('change', toggleSelectAll);

            // Sort
            $(document).on('click','.mcqvs-log-table th[data-col]',function(){
                var col = $(this).data('col');
                if(col === 'source') return; // no sort on source
                if(state.sort === col){ state.order = state.order==='DESC'?'ASC':'DESC'; }
                else { state.sort = col; state.order = 'DESC'; }
                state.offset = 0;
                fetchLogs(renderTable);
            });

            // Pager
            $(document).on('click','.mcqvs-pg-btn',function(){
                var page = $(this).data('page');
                state.offset = (page-1) * state.limit;
                fetchLogs(renderTable);
                $('html,body').animate({scrollTop:$('#mcqvs-log-viewer-root').offset().top - 40},200);
            });

            // Filter apply
            $('#mcqvs-f-apply').on('click',function(){
                state.level  = $('#mcqvs-f-level').val();
                state.source = $('#mcqvs-f-source').val();
                state.search = $('#mcqvs-f-search').val();
                state.from   = $('#mcqvs-f-from').val();
                state.to     = $('#mcqvs-f-to').val();
                state.offset = 0;
                selectedIds = {};
                fetchLogs(renderTable);
            });

            // Reset
            $('#mcqvs-f-reset').on('click',function(){
                $('#mcqvs-f-level').val('');
                $('#mcqvs-f-source').val('');
                $('#mcqvs-f-search').val('');
                $('#mcqvs-f-from').val('');
                $('#mcqvs-f-to').val('');
                state = { level:'', source:'', search:'', from:'', to:'', limit:defaultVisible, offset:0, order:'DESC', sort:'ts' };
                selectedIds = {};
                fetchLogs(renderTable);
            });

            // Search on Enter
            $('#mcqvs-f-search').on('keydown',function(e){
                if(e.keyCode===13){ $('#mcqvs-f-apply').trigger('click'); }
            });

            // Refresh
            $('#mcqvs-refresh-logs').on('click',function(){ fetchLogs(renderTable); });

            // Clear All
            $('#mcqvs-clear-logs').on('click',function(){
                if(!confirm('<?php echo esc_js(__('Clear ALL logs? This cannot be undone.', 'mcq-video-studio')); ?>')) return;
                var $btn = $(this).prop('disabled',true);
                $.post(ajaxUrl,{action:'mcqvs_clear_logs',nonce:nonce},function(res){
                    if(res.success){ selectedIds={}; fetchLogs(renderTable); }
                    else { alert('Failed'); }
                    $btn.prop('disabled',false);
                },'json');
            });

            // Prune Now
            $('#mcqvs-prune-logs').on('click',function(){
                var $btn = $(this).prop('disabled',true).text('<?php echo esc_js(__('Pruning\u2026', 'mcq-video-studio')); ?>');
                $.post(ajaxUrl,{action:'mcqvs_prune_logs',nonce:nonce},function(res){
                    $btn.prop('disabled',false).text('<?php echo esc_js(__('Prune Now', 'mcq-video-studio')); ?>');
                    fetchLogs(renderTable);
                },'json');
            });

            // Delete selected
            $('#mcqvs-bulk-delete').on('click',function(){
                var ids = Object.keys(selectedIds);
                if(ids.length === 0) return;
                if(!confirm(ids.length + ' <?php echo esc_js(__('logs will be deleted. Continue?', 'mcq-video-studio')); ?>')) return;
                var $btn = $(this).prop('disabled',true);
                $.post(ajaxUrl,{action:'mcqvs_delete_logs',nonce:nonce,ids:ids},function(res){
                    if(res.success){ selectedIds={}; fetchLogs(renderTable); }
                    else { alert('Failed'); }
                    $btn.prop('disabled',false);
                },'json');
            });

            // ---------- Download helpers ----------
            function buildPayload(ids){
                var rows = [];
                if(ids && ids.length > 0){
                    for(var i=0;i<allRows.length;i++){
                        if(ids.indexOf(String(allRows[i].id)) >= 0) rows.push(allRows[i]);
                    }
                } else {
                    rows = allRows;
                }
                return { source:'mcqvs-logs', exportedAt:new Date().toISOString(), filters:state, totalExported:rows.length, logs:rows };
            }

            function downloadJSON(payload, filename){
                var blob = new Blob([JSON.stringify(payload,null,2)],{type:'application/json;charset=utf-8'});
                var url = URL.createObjectURL(blob);
                var a = document.createElement('a');
                a.href=url; a.download=filename;
                document.body.appendChild(a); a.click(); a.remove();
                setTimeout(function(){ URL.revokeObjectURL(url); },500);
            }

            function downloadCSV(rows){
                if(!rows.length) return;
                var cols = ['id','ts','level','source','message','context_json','user_id','request_uri'];
                var lines = [cols.join(',')];
                for(var i=0;i<rows.length;i++){
                    var r = rows[i];
                    var line = cols.map(function(c){
                        var v = r[c];
                        if(v===null||v===undefined) return '';
                        v = String(v).replace(/"/g,'""');
                        if(v.indexOf(',')>=0||v.indexOf('"')>=0||v.indexOf("\n")>=0) v='"'+v+'"';
                        return v;
                    });
                    lines.push(line.join(','));
                }
                var blob = new Blob([lines.join("\n")],{type:'text/csv;charset=utf-8'});
                var url = URL.createObjectURL(blob);
                var a = document.createElement('a');
                a.href=url; a.download='mcqvs-logs-'+Date.now()+'.csv';
                document.body.appendChild(a); a.click(); a.remove();
                setTimeout(function(){ URL.revokeObjectURL(url); },500);
            }

            // Download selected
            $('#mcqvs-dl-selected').on('click',function(){
                var ids = Object.keys(selectedIds);
                if(ids.length === 0){
                    alert('<?php echo esc_js(__('Select rows first.', 'mcq-video-studio')); ?>');
                    return;
                }
                var payload = buildPayload(ids);
                downloadJSON(payload, 'mcqvs-logs-selected-'+Date.now()+'.json');
            });

            // Download all
            $('#mcqvs-dl-all').on('click',function(){
                if(allRows.length === 0){
                    alert('<?php echo esc_js(__('No logs to download.', 'mcq-video-studio')); ?>');
                    return;
                }
                // Fetch ALL filtered rows (not just current page)
                var params = {
                    action:'mcqvs_list_logs', nonce:nonce,
                    level:state.level, source:state.source, search:state.search,
                    from:state.from, to:state.to, limit:10000, offset:0, order:state.order
                };
                var $btn = $(this).prop('disabled',true).text('<?php echo esc_js(__('Fetching\u2026', 'mcq-video-studio')); ?>');
                $.get(ajaxUrl,params,function(res){
                    $btn.prop('disabled',false).text('<?php echo esc_js(__('Download All', 'mcq-video-studio')); ?>');
                    if(!res.success||!res.data||!res.data.rows) return;
                    var payload = buildPayload(null);
                    payload.logs = res.data.rows;
                    payload.totalExported = res.data.rows.length;
                    downloadJSON(payload, 'mcqvs-logs-all-'+Date.now()+'.json');
                },'json');
            });

            // Copy all filtered logs with full details to clipboard
            $('#mcqvs-copy-all').on('click',function(){
                var $btn = $(this).prop('disabled',true).text('<?php echo esc_js(__('Copying\u2026', 'mcq-video-studio')); ?>');
                var params = {
                    action:'mcqvs_list_logs', nonce:nonce,
                    level:state.level, source:state.source, search:state.search,
                    from:state.from, to:state.to, limit:10000, offset:0, order:state.order
                };
                $.get(ajaxUrl,params,function(res){
                    if(!res.success||!res.data||!res.data.rows||res.data.rows.length===0){
                        $btn.prop('disabled',false).text('📋 Copy All');
                        alert('<?php echo esc_js(__('No logs to copy.', 'mcq-video-studio')); ?>');
                        return;
                    }
                    var lines = [];
                    var rows = res.data.rows;
                    lines.push('═══════════════════════════════════════════════════════════════');
                    lines.push('  MCQ Video Studio — Full Log Export');
                    lines.push('  Exported: ' + new Date().toLocaleString());
                    lines.push('  Total entries: ' + rows.length);
                    lines.push('  Filters: level=' + (state.level||'all') + '  source=' + (state.source||'all') + '  search="' + (state.search||'') + '"');
                    lines.push('═══════════════════════════════════════════════════════════════');
                    lines.push('');
                    for(var i=0;i<rows.length;i++){
                        var r = rows[i];
                        lines.push('───────────────────────────────────────────────────────────────');
                        lines.push('  #' + (i+1) + '  [' + (r.level||'?').toUpperCase() + ']  ' + (r.source||'SERVER'));
                        // @FIX 1.4.9.55: export site-local time (ts_display, computed by
                        // PHP via wp_date) instead of the raw UTC ts — matches how every
                        // other visible timestamp in the plugin is shown.
                        lines.push('  Time: ' + (r.ts_display || r.ts || ''));
                        lines.push('  Message: ' + (r.message||''));
                        if(r.user_id) lines.push('  User ID: ' + r.user_id);
                        if(r.request_uri) lines.push('  URI: ' + r.request_uri);
                        if(r.context && typeof r.context === 'object'){
                            lines.push('  ── Context / Payload ──');
                            var ctxStr = JSON.stringify(r.context, null, 2);
                            var ctxLines = ctxStr.split('\n');
                            for(var j=0;j<ctxLines.length;j++){
                                lines.push('  ' + ctxLines[j]);
                            }
                        }
                        lines.push('');
                    }
                    lines.push('═══════════════════════════════════════════════════════════════');
                    lines.push('  End of log export');
                    lines.push('═══════════════════════════════════════════════════════════════');
                    var text = lines.join('\n');
                    if(navigator.clipboard&&navigator.clipboard.writeText){
                        navigator.clipboard.writeText(text).then(function(){
                            $btn.prop('disabled',false).html('✅ Copied! ('+rows.length+' logs)');
                            setTimeout(function(){ $btn.html('📋 Copy All'); },3000);
                        },function(){
                            fallbackCopy(text,$btn);
                        });
                    } else {
                        fallbackCopy(text,$btn);
                    }
                },'json');
            });

            function fallbackCopy(text,$btn){
                var ta=document.createElement('textarea');
                ta.value=text;
                ta.style.cssText='position:fixed;left:-9999px;top:-9999px;';
                document.body.appendChild(ta);
                ta.select();
                try{
                    document.execCommand('copy');
                    $btn.prop('disabled',false).html('✅ Copied!');
                    setTimeout(function(){ $btn.html('📋 Copy All'); },3000);
                }catch(e){
                    $btn.prop('disabled',false).html('📋 Copy All');
                    alert('<?php echo esc_js(__('Copy failed. Please select all text manually.', 'mcq-video-studio')); ?>');
                }
                document.body.removeChild(ta);
            }

            // ---------- Init ----------
            fetchLogs(renderTable);

        })();
        </script>
        </div>
        <?php
    }
}
