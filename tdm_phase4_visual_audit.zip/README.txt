The Deeper Mind — Phase 4 visual-planning audit pack
Includes visual_fp.py (imported by check_visual.py).
Generated visual_plan.json and beat_needs.json are from videos/short_s02.
