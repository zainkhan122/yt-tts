document.addEventListener('DOMContentLoaded', () => {
  'use strict';

  // --- App version ---
  try {
    const version = chrome.runtime.getManifest().version;
    document.querySelectorAll('.app-version').forEach(el => {
      el.textContent = 'V' + version;
    });
  } catch (e) {
    console.error('Could not read version from manifest:', e);
  }

  // --- Check if on Share Dialog ---
  function isOnShareDialog() {
    // Check for share dialog elements that only exist on the share dialog
    const shareDialog = document.querySelector('div[role="dialog"]');
    const groupSearch = document.querySelector('#group-search-input');
    const shareToGroupTitle = document.querySelector('h2.section-title');
    // On a share dialog: has group search + share title + dialog role
    // On Facebook Page timeline: no share dialog, just post content
    return !!(shareDialog && groupSearch && shareToGroupTitle);
  }
  
  // --- Wrong Location Overlay ---
  // The overlay is kept hidden by default; it is shown only by content scripts
  // when the user needs guidance (e.g., on Facebook Page timeline without share dialog).
  // We do NOT auto-show it here to avoid covering the popup UI with a dark background.
  const wrongOverlay = document.getElementById('wrong-location-overlay');
  wrongOverlay.classList.add('hidden');

  // --- Custom Tooltip Functionality ---
  const removeDefaultTooltips = () => {
    document.querySelectorAll('.info-icon[title]').forEach(icon => {
      const title = icon.getAttribute('title');
      if (title && !icon.getAttribute('data-image-tooltip')) {
        icon.setAttribute('data-tooltip', title);
        icon.removeAttribute('title');
      }
    });
  };
  
  removeDefaultTooltips();
  
  function initializeTooltips() {
    removeDefaultTooltips();
    
    const textTooltipModal = document.createElement('div');
    textTooltipModal.className = 'tooltip-modal hidden';
    textTooltipModal.innerHTML = `
      <div class="tooltip-modal-content text-tooltip-content">
        <button class="tooltip-close-btn">✕</button>
        <div class="tooltip-text-content"></div>
      </div>
    `;
    document.body.appendChild(textTooltipModal);
    
    const textTooltipContent = textTooltipModal.querySelector('.tooltip-text-content');
    const textTooltipCloseBtn = textTooltipModal.querySelector('.tooltip-close-btn');
    
    textTooltipCloseBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      textTooltipModal.classList.add('hidden');
    });
    
    textTooltipModal.addEventListener('click', (e) => {
      if (e.target === textTooltipModal) {
        textTooltipModal.classList.add('hidden');
      }
    });
    
    let textMouseDownTarget = null;
    textTooltipContent.addEventListener('mousedown', (e) => {
      textMouseDownTarget = e.target;
    });
    textTooltipContent.addEventListener('mouseup', (e) => {
      if (textMouseDownTarget === e.target) {
        textTooltipModal.classList.add('hidden');
      }
      textMouseDownTarget = null;
    });
    
    const imageTooltipModal = document.createElement('div');
    imageTooltipModal.className = 'tooltip-modal hidden';
    imageTooltipModal.innerHTML = `
      <div class="tooltip-modal-content">
        <button class="tooltip-close-btn">✕</button>
        <img class="tooltip-image" src="" alt="Info">
      </div>
    `;
    document.body.appendChild(imageTooltipModal);

    const tooltipImage = imageTooltipModal.querySelector('.tooltip-image');
    const tooltipCloseBtn = imageTooltipModal.querySelector('.tooltip-close-btn');

    tooltipCloseBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      imageTooltipModal.classList.add('hidden');
    });

    imageTooltipModal.addEventListener('click', (e) => {
      if (e.target === imageTooltipModal) {
        imageTooltipModal.classList.add('hidden');
      }
    });

    let imageMouseDownTarget = null;
    tooltipImage.addEventListener('mousedown', (e) => {
      imageMouseDownTarget = e.target;
      e.stopPropagation();
    });
    tooltipImage.addEventListener('mouseup', (e) => {
      if (imageMouseDownTarget === e.target) {
        imageTooltipModal.classList.add('hidden');
      }
      imageMouseDownTarget = null;
      e.stopPropagation();
    });

    const infoIcons = document.querySelectorAll('.info-icon');
    infoIcons.forEach(icon => {
      const imageTooltipSrc = icon.getAttribute('data-image-tooltip');
      const tooltipText = icon.getAttribute('data-tooltip');
      icon.style.cursor = 'pointer';
      
      if (imageTooltipSrc) {
        icon.addEventListener('click', (e) => {
          e.stopPropagation();
          tooltipImage.src = imageTooltipSrc;
          imageTooltipModal.classList.remove('hidden');
        });
      } else if (tooltipText) {
        icon.addEventListener('click', (e) => {
          e.stopPropagation();
          textTooltipContent.textContent = tooltipText;
          textTooltipModal.classList.remove('hidden');
        });
      }
    });
  }
  
  setTimeout(initializeTooltips, 100);

  // --- Element References ---
  // Main containers
  const mainContent = document.getElementById('main-content');
  const shareContainer = document.getElementById('share-container');
  const settingsContainer = document.getElementById('settings-container');
  const statusDiv = document.getElementById('status');
  const authStatusDiv = document.getElementById('auth-status');
  
  // Settings UI
  const settingsIcon = document.getElementById('settingsIcon');
  const addressBookIcon = document.getElementById('addressBookIcon');
  
  // API Key Section
  const apiKeySection = document.getElementById('api-key-section');
  const apiKeyInput = document.getElementById('apiKeyInput');
  const saveApiKeyButton = document.getElementById('saveApiKeyButton');
  const getApiKeyButton = document.getElementById('getApiKeyButton');
  
  // Automation Section
  const automationSection = document.getElementById('automation-section');
  const automationTabButton = document.getElementById('automationTabButton');
  const apiKeyTabButton = document.getElementById('apiKeyTabButton');
  const automationTabContent = document.getElementById('automation-section');
  const apiKeyTabContent = document.getElementById('api-key-tab-content');
  
  // Auto-share automation elements
  const autoShareEnabled = document.getElementById('auto-share-enabled');
  const autoShareStartTime = document.getElementById('auto-share-start-time');
  const autoShareEndTime = document.getElementById('auto-share-end-time');
  const autoSharePageUrl = document.getElementById('auto-share-page-url');
  const autoShareGroupsPerPost = document.getElementById('auto-share-groups-per-post');
  const autoShareDelayMin = document.getElementById('auto-share-delay-min');
  const autoShareDelayMax = document.getElementById('auto-share-delay-max');
  const autoShareStatus = document.getElementById('auto-share-status');
  const saveAutoShareConfig = document.getElementById('save-auto-share-config');
  const testAutoShare = document.getElementById('test-auto-share');
  
  // Share elements
  const postContent = document.getElementById('post-content');
  const shareButton = document.getElementById('share-button');
  const scheduleButton = document.getElementById('schedule-button');
  const showAllGroupsButton = document.getElementById('show-all-groups-button');
  const groupSearchInput = document.getElementById('group-search-input');
  const searchClearBtn = document.getElementById('search-clear-btn');
  const refreshGroupsButton = document.getElementById('refresh-groups-button');
  const groupCount = document.getElementById('group-count');
  const toggleChosenGroups = document.getElementById('toggle-chosen-groups');
  const selectAllGroups = document.getElementById('select-all-groups');
  const groupList = document.getElementById('group-list');
  const shareDelay = document.getElementById('share-delay');
  const randomizeDelay = document.getElementById('randomize-delay');
  const scheduleButtonEl = document.getElementById('schedule-button');
  const progressContainer = document.getElementById('progress-container');
  const progressBar = document.getElementById('progress-bar');
  const progressText = document.getElementById('progress-text');
  const progressCount = document.getElementById('progress-count');
  
  // Signature
  const signatureToggleBtn = document.getElementById('signature-toggle-btn');
  const signatureContainer = document.getElementById('signature-container');
  const signatureText = document.getElementById('signature-text');
  const signatureEnabled = document.getElementById('signature-enabled');
  const signatureSaveBtn = document.getElementById('signature-save-btn');
  const savePostPresetBtn = document.getElementById('save-post-preset-btn');
  
  // Group search
  const groupSearchInputEl = document.getElementById('group-search-input');
  const searchClearBtnEl = document.getElementById('search-clear-btn');
  
  // Schedule modal
  const scheduleModal = document.getElementById('schedule-modal');
  const closeScheduleModal = document.getElementById('close-schedule-modal');
  const scheduleInfoView = document.getElementById('schedule-info-view');
  const scheduleInfoOk = document.getElementById('schedule-info-ok');
  const schedulePickerView = document.getElementById('schedule-picker-view');
  const scheduleDateInput = document.getElementById('schedule-date');
  const scheduleTimeSelect = document.getElementById('schedule-time');
  const scheduleValidationMsg = document.getElementById('schedule-validation-msg');
  const cancelSchedulePicker = document.getElementById('cancel-schedule-picker');
  const confirmSchedule = document.getElementById('confirm-schedule');
  
  // Address book
  const addressBookIconEl = document.getElementById('addressBookIcon');
  const addressBookModal = document.getElementById('address-book-modal');
  const closeAddressBookModal = document.getElementById('close-address-book-modal');
  const modalAddressList = document.getElementById('modal-address-list');
  const useAddressBtn = document.getElementById('use-address');
  
  // Group presets
  const savePresetModal = document.getElementById('save-preset-modal');
  const closeSavePresetModal = document.getElementById('close-save-preset-modal');
  const presetQuestionView = document.getElementById('preset-question-view');
  const presetFormView = document.getElementById('preset-form-view');
  const presetAnswerNo = document.getElementById('preset-answer-no');
  const presetAnswerYes = document.getElementById('preset-answer-yes');
  const presetName = document.getElementById('preset-name');
  const cancelSavePreset = document.getElementById('cancel-save-preset');
  const confirmSavePreset = document.getElementById('confirm-save-preset');
  const presetsManagerModal = document.getElementById('presets-manager-modal');
  const closePresetsManager = document.getElementById('close-presets-manager');
  const presetsListContainer = document.getElementById('presets-list-container');
  const emptyPresetsState = document.querySelector('.empty-presets-state');
  const groupPresetsIcon = document.getElementById('groupPresetsIcon');
  
  // One click templates
  const oneClickTemplatesIcon = document.getElementById('oneClickTemplatesIcon');
  const createOneClickModal = document.getElementById('create-one-click-modal');
  const closeCreateOneClick = document.getElementById('close-create-one-click');
  const oneClickTemplateName = document.getElementById('one-click-template-name');
  const oneClickGroupPreset = document.getElementById('one-click-group-preset');
  const oneClickPostTemplate = document.getElementById('one-click-post-template');
  const saveOneClickBtn = document.getElementById('save-one-click-template');
  const cancelOneClickBtn = document.getElementById('cancel-one-click-template');
  const oneClickManagerModal = document.getElementById('one-click-manager-modal');
  const closeOneClickManager = document.getElementById('close-one-click-manager');
  const oneClickTemplatesList = document.getElementById('one-click-templates-list');
  const emptyOneClickState = document.querySelector('.empty-one-click-state');
  const createNewOneClick = document.getElementById('create-new-one-click');
  
  // AI Content
  const aiMagicBtn = document.getElementById('ai-magic-btn');
  const aiContentModal = document.getElementById('ai-content-modal');
  const closeAiModal = document.getElementById('close-ai-modal');
  const aiPrompt = document.getElementById('ai-prompt');
  const aiPromptSettingsBtn = document.getElementById('ai-prompt-settings-btn');
  const aiSystemPromptContainer = document.getElementById('ai-system-prompt-container');
  const aiSystemPrompt = document.getElementById('ai-system-prompt');
  const aiSaveSystemPrompt = document.getElementById('ai-save-system-prompt');
  const aiResetSystemPrompt = document.getElementById('ai-reset-system-prompt');
  const aiVariationCount = document.getElementById('ai-variation-count');
  const aiGenerateBtn = document.getElementById('ai-generate-btn');
  const aiResultsContainer = document.getElementById('ai-results-container');
  const aiStatus = document.getElementById('ai-status');
  const aiApplyBtn = document.getElementById('ai-apply-btn');
  const aiSystemPromptInput = document.getElementById('ai-system-prompt');
  
  // Schedule modal element aliases (used in schedule functions)
  const scheduleModalEl = scheduleModal;
  const closeScheduleModalEl = closeScheduleModal;
  const scheduleInfoViewEl = scheduleInfoView;
  const scheduleInfoOkEl = scheduleInfoOk;
  const schedulePickerViewEl = schedulePickerView;
  const scheduleDateInputEl = scheduleDateInput;
  const scheduleTimeSelectEl = scheduleTimeSelect;
  const scheduleValidationMsgEl = scheduleValidationMsg;
  const cancelSchedulePickerEl = cancelSchedulePicker;
  const confirmScheduleEl = confirmSchedule;
  
  // Group search element aliases
  const searchClearBtnEl2 = searchClearBtn;
  
  // Signature element aliases
  const signatureContainerEl = signatureContainer;
  const signatureTextEl = signatureText;
  const signatureEnabledEl = signatureEnabled;
  const signatureSaveBtnEl = signatureSaveBtn;
  const savePostPresetBtnEl = savePostPresetBtn;
  
  // Status (already declared at line 131)
  
  // --- Utility Functions ---
  function showStatus(message, type, isAuthStatus = false) {
    const targetDiv = isAuthStatus ? authStatusDiv : statusDiv;
    if (!targetDiv) return;
    targetDiv.textContent = message;
    targetDiv.className = `status ${type}`;
    targetDiv.classList.remove('hidden');
  }

  function loadGroups() {
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      if (!tabs.length) return;
      
      chrome.tabs.sendMessage(tabs[0].id, { type: 'get_groups' }, (response) => {
        if (chrome.runtime.lastError || !response?.success) {
          console.log('Groups not loaded yet. Open Facebook and click "Load All" in the group search area.');
          return;
        }
        
        const groups = response.groups || [];
        if (groupList) {
          groupList.innerHTML = '';
          groups.forEach((group, index) => {
            const div = document.createElement('div');
            div.className = 'group-item';
            const checkbox = document.createElement('input');
            checkbox.type = 'checkbox';
            checkbox.id = 'group_' + (group.id ? 'id' + group.id : 'row' + index);
            checkbox.value = group.name;
            if (group.id) checkbox.dataset.groupId = group.id;
            const label = document.createElement('label');
            label.htmlFor = checkbox.id;
            label.textContent = group.name;
            div.appendChild(checkbox);
            div.appendChild(label);
            groupList.appendChild(div);
          });
        }
        if (groupCount) {
          groupCount.textContent = `${groups.length} groups found`;
        }
        updateShareButtonCount();
        updateToggleChosenButton();
      });
    });
  }

  // --- View Management ---
  function showView(view) {
    // Hide all main views
    if (mainContent) mainContent.classList.add('hidden');
    shareContainer.classList.add('hidden');
    settingsContainer.classList.add('hidden');
    
    // Hide templates view if it exists
    const templatesView = document.getElementById('templates-view');
    if (templatesView) templatesView.classList.add('hidden');
    
    if (view === 'main') {
      shareContainer.classList.remove('hidden');
      loadGroups();
    } else if (view === 'settings') {
      settingsContainer.classList.remove('hidden');
      showTab('automation'); // Default to Automation tab
    } else if (view === 'templates') {
      if (typeof loadTemplatesView === 'function') loadTemplatesView();
    }
  }

  function showTab(tabName) {
    // Tab contents
    const automationTabContent = document.getElementById('automation-section');
    const apiKeyTabContent = document.getElementById('api-key-tab-content');
    // Tab buttons
    const automationTabButton = document.getElementById('automationTabButton');
    const apiKeyTabButton = document.getElementById('apiKeyTabButton');
    
    if (tabName === 'automation') {
      automationTabContent.classList.remove('hidden');
      apiKeyTabContent.classList.add('hidden');
      automationTabButton.classList.add('active');
      apiKeyTabButton.classList.remove('active');
    } else if (tabName === 'api-key') {
      automationTabContent.classList.add('hidden');
      apiKeyTabContent.classList.remove('hidden');
      automationTabButton.classList.remove('active');
      apiKeyTabButton.classList.add('active');
    }
  }

  // --- Settings Icon Handler ---
  settingsIcon.addEventListener('click', () => {
    chrome.storage.local.get(['geminiApiKey'], (result) => {
      const { geminiApiKey } = result;
      if (!shareContainer.classList.contains('hidden')) {
        if (geminiApiKey && apiKeyInput) {
          apiKeyInput.value = geminiApiKey;
        }
        showView('settings');
      } else {
        showView('main');
      }
    });
  });

  // --- Main Settings Button Handler ---
  const settingsBtnMain = document.getElementById('settings-btn-main');
  if (settingsBtnMain) {
    settingsBtnMain.addEventListener('click', () => {
      chrome.storage.local.get(['geminiApiKey'], (result) => {
        const { geminiApiKey } = result;
        if (geminiApiKey && apiKeyInput) {
          apiKeyInput.value = geminiApiKey;
        }
        showView('settings');
      });
    });
  }

  // --- Back to Main Button ---
  const backToMainBtn = document.getElementById('back-to-main-btn');
  if (backToMainBtn) {
    backToMainBtn.addEventListener('click', () => {
      showView('main');
    });
  }

  addressBookIcon.addEventListener('click', () => {
    showView('templates');
  });

  // --- Tab switching ---
  automationTabButton.addEventListener('click', () => showTab('automation'));
  apiKeyTabButton.addEventListener('click', () => showTab('api-key'));

  // --- Auto-share Automation ---
  async function saveAutoShareConfigHandler() {
    let delayMin = parseInt(autoShareDelayMin.value, 10) || 10;
    let delayMax = parseInt(autoShareDelayMax.value, 10) || 20;
    if (delayMax < delayMin) delayMax = delayMin;
    
    const config = {
      enabled: autoShareEnabled.checked,
      timeStart: autoShareStartTime.value,
      timeEnd: autoShareEndTime.value,
      fbPageUrl: autoSharePageUrl.value.trim(),
      groupsPerPost: parseInt(autoShareGroupsPerPost.value, 10) || 5,
      delayMin: delayMin,
      delayMax: delayMax
    };
    
    chrome.storage.local.set({ autoShareConfig: config }, () => {
      showStatus('Auto-share configuration saved!', 'success');
      
      if (config.enabled && config.fbPageUrl) {
        chrome.runtime.sendMessage({ type: 'start_auto_share' }, (response) => {
          updateAutoShareStatus(config.enabled);
        });
      } else {
        updateAutoShareStatus(config.enabled);
      }
    });
  }
  
  function updateAutoShareStatus(enabled) {
    if (autoShareStatus) {
      autoShareStatus.textContent = `Status: ${enabled ? 'Enabled' : 'Disabled'}`;
      autoShareStatus.className = enabled ? 'auto-share-status' : 'auto-share-status';
    }
  }
  
  async function loadAutoShareConfig() {
    return new Promise((resolve) => {
      chrome.storage.local.get(['autoShareConfig'], (result) => {
        const config = result.autoShareConfig || getDefaultAutoShareConfig();
        if (autoShareEnabled) autoShareEnabled.checked = config.enabled;
        if (autoShareStartTime) autoShareStartTime.value = config.timeStart;
        if (autoShareEndTime) autoShareEndTime.value = config.timeEnd;
        if (autoSharePageUrl) autoSharePageUrl.value = config.fbPageUrl;
        if (autoShareGroupsPerPost) autoShareGroupsPerPost.value = config.groupsPerPost || 5;
        if (autoShareDelayMin) autoShareDelayMin.value = config.delayMin || 10;
        if (autoShareDelayMax) autoShareDelayMax.value = config.delayMax || 20;
        updateAutoShareStatus(config.enabled);
        resolve(config);
      });
    });
  }
  
  function getDefaultAutoShareConfig() {
    return {
      enabled: false,
      timeStart: '15:00',
      timeEnd: '23:00',
      fbPageUrl: '',
      groupsPerPost: 5,
      delayMin: 10,
      delayMax: 20
    };
  }
  
  // Load config on startup
  loadAutoShareConfig();
  
  // Check and update status
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.autoShareConfig) {
      updateAutoShareStatus(changes.autoShareConfig.newValue.enabled);
    }
  });
  
  // --- Address Book Modal ---
  addressBookIconEl?.addEventListener('click', () => {
    addressBookModal.classList.remove('hidden');
    loadAddresses();
  });
  
  function loadAddresses() {
    chrome.storage.local.get(['addressBook'], (result) => {
      const addresses = result.addressBook || [];
      if (modalAddressList) {
        modalAddressList.innerHTML = addresses.map((addr, i) => 
          `<div class="address-item" data-index="${i}">${addr.name}: ${addr.value.substring(0, 50)}</div>`
        ).join('');
      }
    });
  }
  
  closeAddressBookModal?.addEventListener('click', () => {
    addressBookModal.classList.add('hidden');
  });
  
  useAddressBtn?.addEventListener('click', () => {
    // TODO: implement address selection
    addressBookModal.classList.add('hidden');
  });
  
  addressBookModal?.addEventListener('click', (e) => {
    if (e.target === addressBookModal) addressBookModal.classList.add('hidden');
  });

  // Auto-share button handlers
  if (saveAutoShareConfig) {
    saveAutoShareConfig.addEventListener('click', saveAutoShareConfigHandler);
  }
  
  if (testAutoShare) {
    testAutoShare.addEventListener('click', async () => {
      if (!autoSharePageUrl?.value.trim()) {
        showStatus('Please enter a Facebook Page URL first.', 'error');
        return;
      }
      showStatus('Testing post fetch...', 'loading');
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs.length > 0) {
          chrome.tabs.sendMessage(tabs[0].id, { 
            type: 'fetch_page_posts', 
            pageUrl: autoSharePageUrl.value.trim() 
          }, (response) => {
            if (response?.posts) {
              showStatus(`Found ${response.posts.length} posts from page.`, 'success');
            } else {
              showStatus('No posts found or error fetching.', 'error');
            }
          });
        } else {
          showStatus('Please open Facebook first.', 'error');
        }
      });
    });
  }
  
  // --- Group Presets ---
  async function getGroupPresets() {
    return new Promise(resolve => 
      chrome.storage.local.get(['groupPresets'], r => resolve(r.groupPresets || []))
    );
  }
  
  async function saveGroupPresets(presets) {
    return new Promise(resolve => 
      chrome.storage.local.set({ groupPresets: presets }, resolve)
    );
  }
  
  function showPresetsManager() {
    getGroupPresets().then(presets => {
      if (presets.length === 0) {
        presetsListContainer.innerHTML = '';
        emptyPresetsState.classList.remove('hidden');
      } else {
        emptyPresetsState.classList.add('hidden');
        presetsListContainer.innerHTML = presets.map(p => `
          <div class="preset-card" data-preset-id="${p.id}">
            <div class="preset-header">
              <span class="preset-name">${p.name}</span>
              <span class="preset-count">${p.groups.length} groups</span>
            </div>
            <div class="preset-actions">
              <button class="preset-use-btn" data-id="${p.id}">Use</button>
              <button class="preset-delete-btn" data-id="${p.id}">Delete</button>
            </div>
          </div>
        `).join('');
        
        presetsListContainer.querySelectorAll('.preset-use-btn').forEach(btn => {
          btn.addEventListener('click', () => applyPreset(btn.dataset.id));
        });
        presetsListContainer.querySelectorAll('.preset-delete-btn').forEach(btn => {
          btn.addEventListener('click', () => deletePreset(btn.dataset.id));
        });
      }
      presetsManagerModal.classList.remove('hidden');
    });
  }
  
  async function applyPreset(presetId) {
    const presets = await getGroupPresets();
    const preset = presets.find(p => p.id === presetId);
    if (!preset) return;
    
    presetsManagerModal.classList.add('hidden');
    
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      if (!tabs.length) return;
      
      chrome.tabs.sendMessage(tabs[0].id, { type: 'show_all_groups' }, async (response) => {
        if (chrome.runtime.lastError || !response?.success) {
          showStatus('Error: Make sure the share dialog is open on Facebook.', 'error');
          return;
        }
        
        await new Promise(r => setTimeout(r, 2000));
        
        chrome.tabs.sendMessage(tabs[0].id, { type: 'get_groups' }, (groupsResponse) => {
          if (!groupsResponse?.groups?.length) {
            showStatus('Failed to load groups.', 'error');
            return;
          }
          
          const presetRefs = (preset.groups || []).map(g => 
            (g && typeof g === 'object') ? { name: String(g.name || ''), id: g.id ? String(g.id) : null }
            : { name: String(g || ''), id: null });
          const inPreset = (group) => presetRefs.some(ref => 
            (ref.id && group.id) ? ref.id === String(group.id) : ref.name === group.name);
          
          if (groupList) {
            groupList.innerHTML = '';
            groupsResponse.groups.forEach((group, index) => {
              const div = document.createElement('div');
              div.className = 'group-item';
              const checkbox = document.createElement('input');
              checkbox.type = 'checkbox';
              checkbox.id = 'group_' + (group.id ? 'id' + group.id : 'row' + index);
              checkbox.value = group.name;
              if (group.id) checkbox.dataset.groupId = group.id;
              checkbox.checked = inPreset(group);
              const label = document.createElement('label');
              label.htmlFor = checkbox.id;
              label.textContent = group.name;
              div.appendChild(checkbox);
              div.appendChild(label);
              groupList.appendChild(div);
            });
          }
          
          const shareButton = document.getElementById('share-button');
          const selectedCount = preset.groups.length;
          if (shareButton && selectedCount > 0) {
            shareButton.textContent = `Share to ${selectedCount} Selected Group${selectedCount > 1 ? 's' : ''}`;
          }
          
          presetsManagerModal.classList.add('hidden');
        });
      });
    });
  }
  
  async function deletePreset(presetId) {
    const presets = await getGroupPresets();
    const preset = presets.find(p => p.id === presetId);
    if (!preset) return;
    if (!confirm(`Delete preset "${preset.name}"?`)) return;
    
    await saveGroupPresets(presets.filter(p => p.id !== presetId));
    showPresetsManager();
    showStatus(`Preset "${preset.name}" deleted.`, 'success');
  }
  
  groupPresetsIcon?.addEventListener('click', showPresetsManager);
  closePresetsManager?.addEventListener('click', () => presetsManagerModal.classList.add('hidden'));
  presetsManagerModal?.addEventListener('click', (e) => {
    if (e.target === presetsManagerModal) presetsManagerModal.classList.add('hidden');
  });
  
  function updatePresetsBadge() {
    getGroupPresets().then(presets => {
      if (presets.length > 0) {
        groupPresetsIcon.classList.add('has-presets');
        groupPresetsIcon.setAttribute('data-preset-count', presets.length);
      } else {
        groupPresetsIcon.classList.remove('has-presets');
        groupPresetsIcon.removeAttribute('data-preset-count');
      }
    });
  }
  
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes.groupPresets) return;
    updatePresetsBadge();
    if (!presetsManagerModal.classList.contains('hidden')) showPresetsManager();
  });
  
  updatePresetsBadge();

  // --- Save Preset Modal ---
  async function showSavePresetModal(selectedGroups) {
    const presets = await getGroupPresets();
    const selectedKeys = selectedGroups.map(g => g.id ? `id:${g.id}` : `name:${g.name}`).sort();
    const exactMatch = presets.find(p => {
      const keys = (p.groups || []).map(g => g.id ? `id:${g.id}` : `name:${g.name}`).sort();
      return keys.length === selectedKeys.length && keys.every((k, i) => k === selectedKeys[i]);
    });
    
    if (exactMatch) {
      if (confirm(`Preset "${exactMatch.name}" already exists. Update it?`)) {
        const updated = presets.map(p => p.id === exactMatch.id ? { ...p, groups: selectedGroups } : p);
        await saveGroupPresets(updated);
        showStatus(`Updated preset: ${exactMatch.name}`, 'success');
      }
      return;
    }
    
    presetQuestionView.classList.add('hidden');
    presetFormView.classList.remove('hidden');
    presetName.value = '';
    presetName.focus();
    
    document.getElementById('preset-groups-count').textContent = `${selectedGroups.length} groups selected`;
    document.getElementById('preset-groups-list').innerHTML = selectedGroups.map(g => 
      `<div>${g.name}</div>`
    ).join('');
    
    savePresetModal.classList.remove('hidden');
  }
  
  cancelSavePreset?.addEventListener('click', () => {
    savePresetModal.classList.add('hidden');
  });
  
  confirmSavePreset?.addEventListener('click', async () => {
    const name = presetName.value.trim();
    if (!name) { showStatus('Please enter a preset name', 'error'); return; }
    
    const selectedGroups = selectedGroupRefs();
    const presets = await getGroupPresets();
    if (presets.some(p => p.name === name)) {
      if (!confirm(`Preset "${name}" exists. Replace?`)) return;
      await saveGroupPresets(presets.filter(p => p.name !== name));
    }
    presets.push({ id: Date.now().toString(), name, groups: selectedGroups, createdAt: new Date().toISOString() });
    await saveGroupPresets(presets);
    savePresetModal.classList.add('hidden');
    showStatus(`Saved preset: ${name}`, 'success');
    updatePresetsBadge();
  });
  
  closeSavePresetModal?.addEventListener('click', () => savePresetModal.classList.add('hidden'));
  savePresetModal?.addEventListener('click', (e) => { if (e.target === savePresetModal) savePresetModal.classList.add('hidden'); });
  presetAnswerNo?.addEventListener('click', () => savePresetModal.classList.add('hidden'));
  presetAnswerYes?.addEventListener('click', () => {
    presetQuestionView.classList.add('hidden');
    presetFormView.classList.remove('hidden');
    presetName.focus();
  });

  // --- One Click Templates ---
  // (Keep existing initialization from one_click_templates.js)
  if (typeof initializeOneClickTemplates === 'function') {
    setTimeout(() => initializeOneClickTemplates(showView), 200);
  }

  // --- AI Content ---
  // (Keep existing initialization from ai_content.js)
  // aiContent.js handles its own initialization

  // --- Schedule Modal ---
  function openScheduleModal() {
    const selectedGroups = selectedGroupRefs();
    if (selectedGroups.length === 0) {
      showStatus('Please select at least one group before scheduling.', 'error');
      return;
    }
    scheduleInfoViewEl.classList.remove('hidden');
    schedulePickerViewEl.classList.add('hidden');
    scheduleValidationMsgEl.classList.add('hidden');
    scheduleModalEl.classList.remove('hidden');
  }
  
  function closeSchedule() {
    scheduleModalEl.classList.add('hidden');
  }
  
  function formatDateForFacebook(dateString) {
    const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    const [year, month, day] = dateString.split('-');
    return `${months[parseInt(month, 10) - 1]} ${parseInt(day, 10)}, ${year}`;
  }
  
  function initScheduleDateDefaults() {
    const defaultDt = new Date(Date.now() + 2 * 60 * 60 * 1000);
    const roundedMin = Math.ceil(defaultDt.getMinutes() / 5) * 5;
    defaultDt.setMinutes(roundedMin, 0, 0);
    
    const toISO = (d) => d.toISOString().split('T')[0];
    scheduleDateInputEl.min = toISO(new Date());
    scheduleDateInputEl.value = toISO(defaultDt);
    
    const defaultValue = `${String(defaultDt.getHours()).padStart(2, '0')}:${String(defaultDt.getMinutes()).padStart(2, '0')}`;
    for (const opt of scheduleTimeSelectEl.options) {
      if (opt.value === defaultValue) { opt.selected = true; break; }
    }
  }
  
  function buildTimeOptions() {
    for (let h = 0; h < 24; h++) {
      for (let m = 0; m < 60; m += 5) {
        const period = h < 12 ? 'AM' : 'PM';
        const displayHour = h === 0 ? 12 : h > 12 ? h - 12 : h;
        const displayMin = String(m).padStart(2, '0');
        const display = `${displayHour}:${displayMin} ${period}`;
        const value24 = `${String(h).padStart(2, '0')}:${displayMin}`;
        const opt = document.createElement('option');
        opt.value = value24;
        opt.textContent = display;
        opt.dataset.display = display;
        scheduleTimeSelectEl.appendChild(opt);
      }
    }
  }
  
  scheduleButtonEl?.addEventListener('click', () => openScheduleModal());
  closeScheduleModalEl?.addEventListener('click', closeSchedule);
  scheduleModalEl?.addEventListener('click', (e) => { if (e.target === scheduleModalEl) closeSchedule(); });
  scheduleInfoOkEl?.addEventListener('click', () => {
    initScheduleDateDefaults();
    scheduleInfoViewEl.classList.add('hidden');
    schedulePickerViewEl.classList.remove('hidden');
  });
  cancelSchedulePickerEl?.addEventListener('click', closeSchedule);
  
  confirmScheduleEl?.addEventListener('click', () => {
    const dateValue = scheduleDateInputEl.value;
    const timeValue = scheduleTimeSelectEl.value;
    
    if (!dateValue || !timeValue) {
      scheduleValidationMsgEl.textContent = 'Please select both a date and a time.';
      scheduleValidationMsgEl.classList.remove('hidden');
      return;
    }
    
    const [hh, mm] = timeValue.split(':').map(Number);
    const scheduledDt = new Date(dateValue);
    scheduledDt.setHours(hh, mm, 0, 0);
    const minFuture = new Date(Date.now() + 60 * 60 * 1000);
    
    if (scheduledDt <= minFuture) {
      scheduleValidationMsgEl.textContent = 'Scheduled time must be at least 1 hour in the future.';
      scheduleValidationMsgEl.classList.remove('hidden');
      return;
    }
    
    scheduleValidationMsgEl.classList.add('hidden');
    const scheduledDate = formatDateForFacebook(dateValue);
    const timeOption = scheduleTimeSelectEl.selectedOptions[0];
    const scheduledTime = timeOption.dataset.display;
    
    const selectedGroups = selectedGroupRefs();
    if (selectedGroups.length === 0) {
      scheduleValidationMsgEl.textContent = 'No groups selected.';
      scheduleValidationMsgEl.classList.remove('hidden');
      return;
    }
    
    const postContent = document.getElementById('post-content').value.trim();
    const delayInput = document.getElementById('share-delay');
    let delaySeconds = parseInt(delayInput.value, 10);
    if (isNaN(delaySeconds) || delaySeconds < 5) delaySeconds = 5;
    const randomizeDelay = document.getElementById('randomize-delay').checked;
    
    chrome.storage.local.get(['postSignature', 'signatureEnabled'], (signatureResult) => {
      const signature = signatureResult.signatureEnabled && signatureResult.postSignature 
        ? signatureResult.postSignature.trim() : null;
      
      closeSchedule();
      
      showStatus(`Scheduling ${selectedGroups.length} group${selectedGroups.length > 1 ? 's' : ''}...`, 'loading');
      
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs.length > 0) {
          chrome.tabs.sendMessage(tabs[0].id, { 
            type: 'schedule_to_groups',
            groups: selectedGroups,
            postContent: postContent,
            postVariations: null,
            postSignature: signature,
            delay: delaySeconds,
            randomizeDelay: randomizeDelay,
            scheduledDate: scheduledDate,
            scheduledTime: scheduledTime
          }, (response) => {
            if (!response) {
              showStatus('No response from page. Make sure the Facebook share dialog is open first.', 'error');
            } else if (response.success && !response.partialSuccess) {
              showStatus(`✅ Successfully scheduled to all ${selectedGroups.length} group${selectedGroups.length > 1 ? 's' : ''}!`, 'success');
            } else if (response.success && response.partialSuccess) {
              showStatus(`⚠️ ${response.message}`, 'error');
            } else {
              showStatus(response.message || 'An error occurred during scheduling.', 'error');
            }
          });
        }
      });
    });
  });
  
  // Build time options on load
  buildTimeOptions();

  // --- Address Book Icon Handler ---
  addressBookIcon?.addEventListener('click', () => {
    showView('templates');
  });

  // --- Group Search ---
  groupSearchInputEl?.addEventListener('input', () => {
    const searchTerm = groupSearchInputEl.value.toLowerCase();
    groupList.querySelectorAll('.group-item').forEach(item => {
      const label = item.querySelector('label');
      if (label) {
        item.style.display = label.textContent.toLowerCase().includes(searchTerm) ? '' : 'none';
      }
    });
    searchClearBtnEl2.style.display = searchTerm ? '' : 'none';
  });
  
  searchClearBtnEl2?.addEventListener('click', () => {
    groupSearchInputEl.value = '';
    groupSearchInputEl.dispatchEvent(new Event('input'));
  });

  // --- Select All Groups ---
  selectAllGroups?.addEventListener('change', () => {
    groupList.querySelectorAll('input[type="checkbox"]').forEach(cb => {
      cb.checked = selectAllGroups.checked;
    });
    updateShareButtonCount();
  });

  // --- Toggle Chosen Groups ---
  toggleChosenGroups?.addEventListener('click', () => {
    const showingChosen = toggleChosenGroups.textContent === 'Show Chosen';
    groupList.querySelectorAll('.group-item').forEach(item => {
      const checkbox = item.querySelector('input[type="checkbox"]');
      if (showingChosen && !checkbox.checked) item.style.display = 'none';
      else item.style.display = '';
    });
    toggleChosenGroups.textContent = showingChosen ? 'Show All' : 'Show Chosen';
  });

  // --- Share Button ---
  function selectedGroupRefs() {
    const refs = [];
    groupList.querySelectorAll('input[type="checkbox"]:checked').forEach(cb => {
      refs.push({ name: cb.value, id: cb.dataset.groupId || null });
    });
    return refs;
  }
  
  function updateShareButtonCount() {
    const count = groupList.querySelectorAll('input[type="checkbox"]:checked').length;
    if (count > 0) {
      shareButton.textContent = `Share to ${count} Selected Group${count > 1 ? 's' : ''}`;
    } else {
      shareButton.textContent = 'Share to Selected Groups';
    }
  }
  
  function updateToggleChosenButton() {
    const checked = groupList.querySelectorAll('input[type="checkbox"]:checked').length;
    if (checked > 0) {
      toggleChosenGroups.classList.remove('hidden');
      toggleChosenGroups.textContent = 'Show Chosen';
    } else {
      toggleChosenGroups.classList.add('hidden');
    }
  }
  
  // --- First-time share check ---
  chrome.storage.local.get(['hasSharedBefore'], (result) => {
    if (!result.hasSharedBefore) {
      showStatus('⚠️ First time sharing? Refresh Facebook if issues occur.', 'warning');
    }
  });
  
  // --- Progress updates from content script ---
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === 'share_progress') {
      const percentage = (request.current / request.total) * 100;
      progressBar.style.width = percentage + '%';
      progressText.textContent = `Sharing to ${request.groupName}...`;
      progressCount.textContent = `${request.current}/${request.total}`;
    }
  });

  // --- Initialize ---
  buildTimeOptions();
  updatePresetsBadge();
  showView('main');

}); // End DOMContentLoaded