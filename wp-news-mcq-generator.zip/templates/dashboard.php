<?php
/**
 * User Dashboard Template - v4.8 Hardened with XSS Prevention
 * @package WP_News_MCQ_Generator
 *
 * @MODIFIED: Added esc_html(), esc_url(), and esc_attr() to all dynamic output.
 * @MODIFIED: Used wp_kses_post() for user bio.
 */

if (!defined('ABSPATH')) exit;

if (!is_user_logged_in()) {
    wp_redirect(home_url('/mcq-login/'));
    exit;
}

$user_id = get_current_user_id();
$current_user = get_user_by('id', $user_id);

// Get key stats
$user_attempts = intval(get_user_meta($user_id, 'nm_total_attempts', true)) ?: 0;
$user_correct = intval(get_user_meta($user_id, 'nm_total_correct', true)) ?: 0;
$user_accuracy = $user_attempts > 0 ? round(($user_correct / $user_attempts) * 100) : 0;
$user_points = intval(get_user_meta($user_id, 'nm_total_points', true)) ?: 0;
$user_level = intval(get_user_meta($user_id, 'nm_level', true)) ?: 1;

// Get profile data
$user_bio = get_user_meta($user_id, 'nm_user_bio', true);
$is_public_profile = get_user_meta($user_id, 'nm_public_profile', true);

get_header();

$is_astra = function_exists('astra_page_layout');
if ($is_astra) :
?>
    <div id="primary" <?php astra_primary_class(); ?>>
        <?php astra_primary_content_top(); ?>
<?php endif; ?>


<div class="nm-dashboard-wrapper">
    
    <div class="nm-user-header">
        <div class="nm-user-info">
            
            <img src="<?php echo esc_url(get_avatar_url($user_id, array('size' => 100))); ?>" 
                 alt="<?php echo esc_attr($current_user->display_name); ?>" 
                 class="nm-user-avatar"
                 loading="lazy">
            
            <div class="nm-user-details">
                <h1 class="nm-user-name"><?php echo esc_html($current_user->display_name); ?></h1>
                <p class="nm-user-email"><?php echo esc_html($current_user->user_email); ?></p>
                <p class="nm-user-bio"><?php echo wp_kses_post($user_bio ?: 'No bio added yet. Click ⚙️ Settings to add one!'); ?></p>
            </div>
        </div>
        <a href="<?php echo esc_url(wp_logout_url(home_url())); ?>" class="nm-logout-btn">
            <span class="nm-logout-icon">🚪</span> Logout
        </a>
    </div>

    <div class="nm-stats-grid">
        <div class="nm-stat-card">
            <div class="nm-stat-icon">📝</div>
            <div class="nm-stat-content">
                <span class="nm-stat-value"><?php echo (int) $user_attempts; ?></span>
                <span class="nm-stat-label">Total Attempts</span>
            </div>
        </div>

        <div class="nm-stat-card">
            <div class="nm-stat-icon">✅</div>
            <div class="nm-stat-content">
                <span class="nm-stat-value"><?php echo (int) $user_correct; ?></span>
                <span class="nm-stat-label">Correct Answers</span>
            </div>
        </div>

        <div class="nm-stat-card">
            <div class="nm-stat-icon">🎯</div>
            <div class="nm-stat-content">
                <span class="nm-stat-value"><?php echo (int) $user_accuracy; ?>%</span>
                <span class="nm-stat-label">Accuracy</span>
            </div>
        </div>

        <div class="nm-stat-card">
            <div class="nm-stat-icon">⭐</div>
            <div class="nm-stat-content">
                <span class="nm-stat-value"><?php echo (int) $user_points; ?></span>
                <span class="nm-stat-label">Total Points</span>
            </div>
        </div>
    </div>

    <div class="nm-dashboard-tabs">
        <button class="nm-tab-btn active" data-tab="overview" type="button">
            📊 Overview
        </button>
        <button class="nm-tab-btn" data-tab="performance" type="button">
            📈 Performance
        </button>
        <button class="nm-tab-btn" data-tab="progress" type="button">
            📚 Topic Progress
        </button>
        <button class="nm-tab-btn" data-tab="settings" type="button">
            ⚙️ Settings
        </button>
    </div>

    <div class="nm-dashboard-content"> 
        
        <div class="nm-tab-panel active" data-panel="overview">
            <div class="nm-overview-grid">
                <div class="nm-overview-section">
                    <h3>Quick Summary</h3>
                    <div class="nm-summary-item">
                        <label>Success Rate:</label>
                        <span class="nm-highlight"><?php echo (int) $user_accuracy; ?>%</span>
                    </div>
                    <div class="nm-summary-item">
                        <label>Questions Answered:</label>
                        <span class="nm-highlight"><?php echo (int) $user_attempts; ?></span>
                    </div>
                    <div class="nm-summary-item">
                        <label>Correct Answers:</label>
                        <span class="nm-highlight"><?php echo (int) $user_correct; ?></span>
                    </div>
                    <div class="nm-summary-item">
                        <label>Incorrect:</label>
                        <span class="nm-highlight">
                            <?php echo (int) ($user_attempts - $user_correct); ?>
                        </span>
                    </div>
                    <div class="nm-summary-item">
                        <label>Level:</label>
                        <span class="nm-highlight">LVL <?php echo (int) $user_level; ?></span>
                    </div>
                </div>

                <div class="nm-overview-section">
                    <h3>📌 Recent Activity</h3>
                    <div id="nm-recent-activity" class="nm-activity-feed">
                        <div class="nm-spinner-wrapper">
                            <div class="nm-spinner"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="nm-tab-panel" data-panel="performance">
            <div class="nm-overview-grid">
                <div class="nm-overview-section">
                    <h2>📈 Performance (Last 7 Days)</h2>
                    <p class="nm-panel-subtitle">Your quiz accuracy over time.</p>
                    <div class="nm-chart-container">
                        <canvas id="nm-performance-chart" height="300"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <div class="nm-tab-panel" data-panel="progress">
            <div class="nm-overview-grid">
                <div class="nm-overview-section">
                    <h2>📚 Topic Progress</h2>
                    <p class="nm-panel-subtitle">Your performance broken down by topic.</p>

                    <div class="nm-table-wrapper">
                        <table class="nm-progress-table">
                            <thead>
                                <tr>
                                    <th>Topic Name</th>
                                    <th>Accuracy</th>
                                    <th>Progress</th>
                                    <th>Completed</th>
                                </tr>
                            </thead>
                            <tbody id="nm-topic-progress-body">
                                 <tr>
                                    <td colspan="4">
                                        <div class="nm-spinner-wrapper" style="padding: 40px 0;">
                                            <div class="nm-spinner"></div>
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="nm-tab-panel" data-panel="settings">
            <div class="nm-overview-grid">
                <div class="nm-overview-section">
                    <h2>⚙️ Account Settings</h2>
                    <p class="nm-panel-subtitle">Manage your profile and preferences</p>

                    <div class="nm-settings-section">
                        <h3>👤 Profile Settings</h3>
                        <form id="nm-profile-form" class="nm-settings-form">
                            <?php wp_nonce_field('nm_profile_update', '_wpnonce'); ?>
                            
                            <div class="nm-form-group">
                                <label for="display_name">Display Name <span class="nm-required">*</span></label>
                                <input type="text" 
                                       id="display_name" 
                                       name="display_name" 
                                       value="<?php echo esc_attr($current_user->display_name); ?>" 
                                       required 
                                       maxlength="50"
                                       placeholder="Your name">
                            </div>

                            <div class="nm-form-group">
                                <label for="nm_user_bio">Bio (Optional)</label>
                                <textarea id="nm_user_bio" 
                                          name="nm_user_bio" 
                                          maxlength="500" 
                                          rows="4" 
                                          placeholder="Tell us about yourself..."><?php echo esc_textarea($user_bio); ?></textarea>
                                <small class="nm-help-text">Maximum 500 characters</small>
                            </div>

                            <div class="nm-form-group nm-checkbox-group">
                                <label>
                                    <input type="checkbox" 
                                           name="nm_public_profile" 
                                           value="1" 
                                           <?php checked($is_public_profile, '1'); ?>>
                                    <span>Make my profile public (for leaderboards)</span>
                                </label>
                            </div>

                            <button type="submit" class="nm-btn nm-btn-primary">
                                ✅ Update Profile
                            </button>
                        </form>
                    </div>

                    <div class="nm-settings-section">
                        <h3>🔐 Change Password</h3>
                        <form id="nm-password-form" class="nm-settings-form">
                            <?php wp_nonce_field('nm_password_change', '_wpnonce'); ?>
                            
                            <div class="nm-form-group">
                                <label for="current_password">Current Password <span class="nm-required">*</span></label>
                                <input type="password" 
                                       id="current_password" 
                                       name="current_password" 
                                       required
                                       autocomplete="current-password"
                                       placeholder="Enter your current password">
                            </div>

                            <div class="nm-form-group">
                                <label for="new_password">New Password <span class="nm-required">*</span></label>
                                <input type="password" 
                                       id="new_password" 
                                       name="new_password" 
                                       required 
                                       minlength="8"
                                       autocomplete="new-password"
                                       placeholder="Minimum 8 characters">
                                <small class="nm-help-text">Must be at least 8 characters</small>
                            </div>

                            <div class="nm-form-group">
                                <label for="confirm_password">Confirm New Password <span class="nm-required">*</span></label>
                                <input type="password" 
                                       id="confirm_password" 
                                       name="confirm_password" 
                                       required
                                       minlength="8"
                                       autocomplete="new-password"
                                       placeholder="Re-enter your new password">
                            </div>

                            <button type="submit" class="nm-btn nm-btn-primary">
                                🔄 Change Password
                            </button>
                        </form>
                    </div>

                    <div class="nm-settings-section nm-danger-zone">
                        <h3>⚠️ Danger Zone</h3>
                        <p>Once you delete your account, there is no going back. This action is irreversible.</p>
                        <button id="nm-delete-account-btn" class="nm-btn nm-btn-danger" type="button">
                            🗑️ Delete My Account
                        </button>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>

<?php 
if ($is_astra) :
?>
        <?php astra_primary_content_bottom(); ?>
    </div><?php if (astra_page_layout() == 'right-sidebar'): ?>
        <?php get_sidebar(); ?>
    <?php endif; ?>
<?php endif; ?>
<?php get_footer(); ?>