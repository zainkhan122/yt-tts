<?php
namespace SEO_Article_Generator\Generator;

define('ABSPATH', dirname(__FILE__));

require_once 'b:/plugin/New App/seo-article-generator/includes/generator/class-surgical-patcher.php';

// Mock Phrase_Variator
class Phrase_Variator {
    public static $alternatives = [];
}

$html = '
<p><!-- seo-gen-zone:moat --></p>
<h2 class="wp-block-heading" id="moat-content">Pro Tips</h2>
<h3 class="wp-block-heading">Sub 1</h3>
<p>Content 1</p>
<h3 class="wp-block-heading">Sub 2</h3>
<p>Content 2</p>

<p><!-- seo-gen-zone:changelog --></p>

<!-- wp:heading -->
<h2 class="wp-block-heading" id="whats-new">Changelog Highlights in This Version</h2>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list">
<li>Update 1</li>
</ul>
<!-- /wp:list -->

<p><!-- seo-gen-zone:tech_specs --></p>
<h2 class="wp-block-heading" id="technical-specifications">Specs</h2>
';

$class = new \ReflectionClass('SEO_Article_Generator\Generator\Surgical_Patcher');
$get_zone_signatures = $class->getMethod('get_zone_signatures');
$get_zone_signatures->setAccessible(true);
$signatures = $get_zone_signatures->invoke(null);

$find_zone = $class->getMethod('find_zone');
$find_zone->setAccessible(true);

echo "--- MOAT CHECK (REAL SIG) ---\n";
$loc_moat = $find_zone->invoke(null, $html, $signatures['moat_content']);
$found_moat = substr($html, $loc_moat['start'], $loc_moat['length']);
echo "Found moat length: " . strlen($found_moat) . "\n";
if (strpos($found_moat, 'Sub 2') === false) {
    echo "BUG: Moat truncated at H3.\n";
} else {
    echo "SUCCESS: Full moat found (Sub 2 included).\n";
}

echo "\n--- CHANGELOG CHECK (REAL SIG) ---\n";
$loc_changelog = $find_zone->invoke(null, $html, $signatures['whats_new']);
$found_changelog = substr($html, $loc_changelog['start'], $loc_changelog['length']);
echo "Found changelog length: " . strlen($found_changelog) . "\n";
echo "Content ends with: [" . substr($found_changelog, -20) . "]\n";
if (strpos($found_changelog, 'tech_specs') !== false) {
    echo "BUG: Changelog absorbed next sentinel.\n";
} else {
    echo "SUCCESS: Changelog boundary correct (no next sentinel).\n";
}
