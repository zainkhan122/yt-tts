<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Database\ApiCallManager;
use AiSocialCollage\Database\JobManager;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CleanupManager {

	public function __construct() {
		add_action( 'init', [ $this, 'schedule_daily_cleanup' ] );
		add_action( Config::ACTION_DAILY_CLEANUP, [ $this, 'execute_cleanup' ] );
		add_action( 'before_delete_post', [ $this, 'handle_post_deletion' ], 10, 1 );
	}

	public function schedule_daily_cleanup() {
		if ( function_exists( 'as_next_scheduled_action' ) && ! as_next_scheduled_action( Config::ACTION_DAILY_CLEANUP, [], Config::AS_GROUP ) ) {
			as_schedule_recurring_action( time(), DAY_IN_SECONDS, Config::ACTION_DAILY_CLEANUP, [], Config::AS_GROUP );
		}
	}

public function execute_cleanup() {
$log_retention = (int) get_option( Config::OPTION_LOG_RETENTION_DAYS, Config::DEFAULT_LOG_RETENTION_DAYS );
$image_retention = (int) get_option( Config::OPTION_IMAGE_RETENTION_DAYS, Config::DEFAULT_IMAGE_RETENTION_DAYS );
$legacy_retention = (int) get_option( Config::OPTION_RETENTION_DAYS, Config::DEFAULT_RETENTION_DAYS );

$logs_deleted = 0;
if ( $log_retention <= 0 && $legacy_retention <= 0 ) {
	$logs_deleted = $this->clean_logs( $legacy_retention > 0 ? $legacy_retention : 0 );
} else {
	$logs_deleted = $this->clean_logs( $log_retention > 0 ? $log_retention : $legacy_retention );
}

$jobs_deleted = $this->clean_jobs( $legacy_retention > 0 ? $legacy_retention : max( $log_retention, $image_retention ) );

$images_deleted = 0;
if ( $image_retention <= 0 && $legacy_retention <= 0 ) {
	$images_deleted = $this->clean_images( $legacy_retention > 0 ? $legacy_retention : 0 );
} else {
	$images_deleted = $this->clean_images( $image_retention > 0 ? $image_retention : $legacy_retention );
}

$api_call_retention = $log_retention > 0 ? $log_retention : $legacy_retention;
$api_calls_deleted = 0;
if ( $api_call_retention > 0 ) {
	$api_calls_deleted = ApiCallManager::purge_old_calls( $api_call_retention );
}

$temp_deleted = $this->clean_temp_files();
$locks_cleared = $this->clean_stale_locks();
$social_meta_cleaned = $this->clean_social_meta();
$buffer_drafts_deleted = $this->clean_buffer_drafts();

$gen_retention = (int) get_option( Config::OPTION_GENERATED_POST_RETENTION_DAYS, Config::DEFAULT_GENERATED_POST_RETENTION_DAYS );
$gen_deleted = 0;
if ( $gen_retention > 0 ) {
	$gen_deleted = $this->clean_generated_posts( $gen_retention );
}

$src_retention = (int) get_option( Config::OPTION_SOURCE_POST_RETENTION_DAYS, Config::DEFAULT_SOURCE_POST_RETENTION_DAYS );
$src_deleted = 0;
if ( $src_retention > 0 ) {
	$src_deleted = $this->clean_source_posts( $src_retention );
}

update_option( Config::OPTION_LAST_CLEANUP_RUN, gmdate( 'Y-m-d H:i:s' ), false );

Logger::info( Config::LOG_ACTION_DAILY_CLEANUP, null, [
'log_retention_days' => $log_retention,
'image_retention_days' => $image_retention,
'legacy_retention_days' => $legacy_retention,
'gen_retention_days' => $gen_retention,
'src_retention_days' => $src_retention,
'deleted' => [
	'logs' => $logs_deleted,
	'jobs' => $jobs_deleted,
	'images' => $images_deleted,
	'api_calls' => $api_calls_deleted,
	'generated_posts' => $gen_deleted,
	'source_posts' => $src_deleted,
	'temp_files' => $temp_deleted,
	'stale_locks' => $locks_cleared,
	'social_meta' => $social_meta_cleaned,
	'buffer_drafts' => $buffer_drafts_deleted,
],
] );
}

	private function clean_stale_locks() {
		global $wpdb;
		$pattern = '_transient_ai_collage_job_lock_';
		$like = $wpdb->esc_like( $pattern );
		$keys = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
				$like . '%'
			)
		);
		// Must match QueueProcessor's set_transient TTL of 900s (15min).
		// Anything older than that is truly stale (process_job has either
		// completed or its finally-block released the lock). The previous 300s
		// threshold caused race conditions during long AI rewrite / crop
		// passes that legitimately hold the lock for several minutes.
		$stale_threshold = 900;
		$cleared = 0;
		foreach ( $keys as $option_name ) {
			if ( strpos( $option_name, '_transient_timeout_' ) === 0 ) {
				continue;
			}
			$transient_key = substr( $option_name, 11 );
			$lock_time = get_transient( $transient_key );
			if ( $lock_time !== false && ( time() - (int) $lock_time ) > $stale_threshold ) {
				delete_transient( $transient_key );
				$cleared++;
				Logger::warning( 'stale_lock_cleaned', null, [ 'key' => $transient_key, 'age_seconds' => time() - (int) $lock_time ] );
			}
		}
		return $cleared;
	}

	private function clean_logs( $days ) {
		if ( $days <= 0 ) {
			return 0;
		}
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_LOGS;

		$sql = $wpdb->prepare(
			"DELETE FROM {$table_name} WHERE created_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY)",
			$days
		);

		$deleted = (int) $wpdb->query( $sql );
		Logger::info( 'logs_cleaned', null, [ 'deleted_count' => $deleted, 'retention_days' => $days ], '200' );
		return $deleted;
	}

	private function clean_jobs( $days ) {
		if ( $days <= 0 ) {
			return 0;
		}

		// All jobs-table DELETEs live in JobManager (single CRUD authority).
		// 1. discarded: short retention (25% of window, min 3 days).
		// 2. pending/scheduled stuck beyond the retention window (lost AS actions).
		// 3. completed/failed older than the retention window.
		$discarded_days = max( 3, (int) ( $days * 0.25 ) );

		$deleted  = JobManager::purge_discarded_jobs( $discarded_days );
		$deleted += JobManager::purge_stuck_jobs( $days );
		$deleted += JobManager::purge_old_jobs( $days );

		Logger::info( 'jobs_cleaned', null, [ 'deleted_count' => $deleted, 'retention_days' => $days ], '200' );
		return $deleted;
	}

private function clean_images( $days ) {
if ( $days <= 0 ) {
return 0;
}
$date_query = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );

	// @MODIFIED: Increased batch from 100 to 500 to handle high-volume sites.
	// Sites generating >100 collages/day would accumulate an ever-growing backlog.
	$query = new \WP_Query( [
	'post_type' => 'attachment',
	'post_status' => 'inherit',
	'posts_per_page' => 500,
	'meta_query' => [
	[
	'key' => Config::META_IS_AI_COLLAGE,
	'value' => '1',
	'compare' => '='
	]
	],
	'date_query' => [
	[
	'column' => 'post_date_gmt',
	'before' => $date_query
	]
	],
	'fields' => 'ids'
	] );

$deleted_count = 0;
if ( ! empty( $query->posts ) ) {
foreach ( $query->posts as $attachment_id ) {
$this->delete_r2_object_for_attachment( $attachment_id );
wp_delete_attachment( $attachment_id, true );
$deleted_count++;
}
}
Logger::info( 'images_cleaned', null, [ 'deleted_count' => $deleted_count, 'retention_days' => $days ], '200' );
return $deleted_count;
}

	/**
	 * @MODIFIED: Recursive temp file cleanup.
	 *
	 * Cleans ALL temp files including:
	 *   - assets/temp/* (ris_clean_*, preprocessed_img_*, template_*, render_*, ai_gen_*, etc.)
	 *   - assets/temp/subdirectories (branding_removed/cleaned_*, logo_cropped_*, debug_zones_*, etc.)
	 *   - wp_upload_dir()/social_media_temp/* (created by SocialMediaDownloader, was NEVER cleaned before)
	 *   - Chromium /tmp/scoped_dir* and /tmp/test.* files
	 *
	 * Uses recursive glob to catch subdirectories (branding_removed/, etc.) that the old
	 * single-level glob('$dir/*') missed.
	 */
	private function clean_temp_files() {
		$deleted_count      = 0;
		$subdir_deleted     = 0;
		$chromium_deleted   = 0;
		$test_file_deleted  = 0;
		$video_deleted      = 0;

		// All plugin temp directories to clean recursively.
		$temp_dirs = [
			AI_SOCIAL_COLLAGE_PATH . 'assets/temp',
		];

		// @MODIFIED: Also clean the social_media_temp directory created by SocialMediaDownloader.
		// Previously NEVER cleaned — this was the highest-risk cleanup leak.
		$upload_dir = wp_upload_dir();
		$social_media_temp = $upload_dir['path'] . '/social_media_temp';
		if ( is_dir( $social_media_temp ) ) {
			$temp_dirs[] = $social_media_temp;
		}

		$cutoff = time() - DAY_IN_SECONDS;

		foreach ( $temp_dirs as $dir ) {
			if ( ! is_dir( $dir ) ) {
				continue;
			}

			// @MODIFIED: Use RecursiveDirectoryIterator instead of single-level glob.
			// Old code: glob( $dir . '/*' ) — only cleaned top-level files, missed subdirectories.
			try {
				$iterator = new \RecursiveIteratorIterator(
					new \RecursiveDirectoryIterator( $dir, \RecursiveDirectoryIterator::SKIP_DOTS ),
					\RecursiveIteratorIterator::CHILD_FIRST
				);

				foreach ( $iterator as $fileinfo ) {
					$filepath = $fileinfo->getPathname();

					if ( $fileinfo->isFile() ) {
						if ( filemtime( $filepath ) < $cutoff ) {
							if ( @unlink( $filepath ) ) {
								$deleted_count++;
							}
						}
					} elseif ( $fileinfo->isDir() ) {
						// Remove empty subdirectories (e.g. branding_remoned/ after files are deleted).
						if ( @rmdir( $filepath ) ) {
							$subdir_deleted++;
						}
					}
				}
			} catch ( \Exception $e ) {
				Logger::warning( 'temp_cleanup_scan_error', null, [
					'dir' => $dir,
					'error' => $e->getMessage(),
				] );
			}
		}

		// Clean video temp files (video_reel_*, poster_clip_*, poster_final_*)
		$video_temp_dir = AI_SOCIAL_COLLAGE_PATH . 'assets/temp';
		if ( is_dir( $video_temp_dir ) ) {
			$video_patterns = [
				'video_reel_*.mp4',
				'video_reel_*_trimmed.mp4',
				'video_reel_*_cropped.mp4',
				'video_reel_*_scaled.mp4',
				'video_reel_*_reel.mp4',
				'video_reel_*.tmp',
				'poster_clip_*.mp4',
				'poster_final_*.mp4',
			];
			foreach ( $video_patterns as $pattern ) {
				$files = glob( $video_temp_dir . '/' . $pattern );
				if ( ! empty( $files ) ) {
					foreach ( $files as $file ) {
						if ( is_file( $file ) && filemtime( $file ) < $cutoff ) {
							if ( @unlink( $file ) ) {
								$video_deleted++;
							}
						}
					}
				}
			}
		}

		// Clean Chromium user data directories and test files in /tmp
		if ( is_dir( '/tmp' ) ) {
			// Clean Chromium scoped_dir* directories (older than 2 hours)
			$chromium_files = glob( '/tmp/scoped_dir*' );
			if ( ! empty( $chromium_files ) ) {
				$chromium_cutoff = time() - ( 2 * HOUR_IN_SECONDS );
				foreach ( $chromium_files as $chromium_dir ) {
					if ( is_dir( $chromium_dir ) && filemtime( $chromium_dir ) < $chromium_cutoff ) {
						@array_map( 'unlink', glob( "$chromium_dir/*.*" ) );
						@rmdir( $chromium_dir );
						$chromium_deleted++;
					}
				}
			}

			// Clean test files (older than 24 hours)
			$test_files = glob( '/tmp/test.*' );
			if ( ! empty( $test_files ) ) {
				$test_cutoff = time() - DAY_IN_SECONDS;
				foreach ( $test_files as $file ) {
					if ( is_file( $file ) && filemtime( $file ) < $test_cutoff ) {
						@unlink( $file );
						$test_file_deleted++;
					}
				}
			}
		}

		$total_deleted = $deleted_count + $chromium_deleted + $test_file_deleted + $video_deleted;

		Logger::info( 'temp_files_cleaned', null, [
			'deleted_count'       => $total_deleted,
			'plugin_temp_count'   => $deleted_count,
			'subdirs_removed'     => $subdir_deleted,
			'chromium_dirs_count' => $chromium_deleted,
			'test_files_count'    => $test_file_deleted,
			'video_files_count'   => $video_deleted,
		] );

		$this->clean_orphaned_preprocessed_meta();
		$this->clean_orphaned_r2_meta();

		return $total_deleted;
	}

	private function clean_orphaned_r2_meta() {
		global $wpdb;
		$cleaned = 0;

		// Clean orphaned _ai_collage_r2_url from attachment meta
		$attachments = get_posts( [
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'posts_per_page' => 500,
			'meta_query'     => [
				[
					'key'     => '_ai_collage_r2_url',
					'compare' => 'EXISTS',
				],
			],
			'fields'         => 'ids',
		] );

		if ( ! empty( $attachments ) ) {
			foreach ( $attachments as $attachment_id ) {
				$r2_url = get_post_meta( $attachment_id, '_ai_collage_r2_url', true );
				if ( empty( $r2_url ) ) {
					delete_post_meta( $attachment_id, '_ai_collage_r2_url' );
					$cleaned++;
				}
			}
		}

		// Clean orphaned video_url from jobs table (jobs that are failed/discarded/old)
		if ( class_exists( 'AiSocialCollage\Database\JobManager' ) ) {
			$retention = (int) get_option( Config::OPTION_RETENTION_DAYS, Config::DEFAULT_RETENTION_DAYS );
			if ( $retention > 0 ) {
				$cutoff = gmdate( 'Y-m-d H:i:s', time() - ( $retention * DAY_IN_SECONDS ) );
				$jobs_table = $wpdb->prefix . Config::TABLE_JOBS;
				$deleted = $wpdb->query( $wpdb->prepare(
					"UPDATE `$jobs_table` SET video_url = NULL WHERE video_url IS NOT NULL AND video_url != '' AND updated_at < %s AND status IN (%s, %s, %s)",
					$cutoff,
					Config::STATUS_FAILED,
					Config::STATUS_DISCARDED,
					Config::STATUS_COMPLETED
				) );
				if ( $deleted ) {
					Logger::info( 'r2_job_video_url_cleaned', null, [ 'count' => $deleted ], '200' );
				}
			}
		}

		if ( $cleaned > 0 ) {
			Logger::debug( 'r2_meta_cleaned', null, [ 'cleaned_count' => $cleaned ] );
		}
	}

	private function clean_orphaned_preprocessed_meta() {
		$query = new \WP_Query( [
			'post_type'      => 'post',
			'post_status'    => 'any',
			'posts_per_page' => -1,
			'meta_query'     => [
				[
					'key'     => Config::META_PREPROCESSED_IMAGE,
					'compare' => 'EXISTS',
				],
			],
			'fields'         => 'ids',
		] );

		if ( empty( $query->posts ) ) {
			return;
		}

		$cleaned = 0;
		foreach ( $query->posts as $post_id ) {
			$preprocessed_path = get_post_meta( $post_id, Config::META_PREPROCESSED_IMAGE, true );
			if ( empty( $preprocessed_path ) || ! file_exists( $preprocessed_path ) ) {
				delete_post_meta( $post_id, Config::META_PREPROCESSED_IMAGE );
				$cleaned++;
			}
		}

		if ( $cleaned > 0 ) {
			Logger::debug( 'preprocessed_meta_cleaned', null, [
				'cleaned_count' => $cleaned,
			] );
		}
	}

 	private function clean_social_meta() {
 		global $wpdb;

 		$max_age = (int) get_option( Config::OPTION_RETENTION_DAYS, Config::DEFAULT_RETENTION_DAYS );
 		if ( $max_age <= 0 ) {
 			return;
 		}
 		$cutoff = gmdate( 'Y-m-d H:i:s', time() - ( $max_age * DAY_IN_SECONDS ) );

		$old_posts = $wpdb->get_col( $wpdb->prepare(
			"SELECT DISTINCT post_id
			FROM {$wpdb->postmeta}
			WHERE meta_key IN (%s, %s, %s, %s)
			AND post_id IN (
				SELECT ID FROM {$wpdb->posts}
				WHERE post_date_gmt <= %s AND post_status = 'publish'
			)
			LIMIT 200",
			Config::META_JETPACK_MESSAGE,
			Config::META_JETPACK_IMAGE,
			Config::META_JETPACK_OPTIONS,
			Config::META_BUFFER_SHARE_HISTORY,
			$cutoff
		) );

		if ( empty( $old_posts ) ) {
			return;
		}

		$cleaned = 0;
		foreach ( $old_posts as $post_id ) {
			$post_id = (int) $post_id;

			$share_history = get_post_meta( $post_id, Config::META_BUFFER_SHARE_HISTORY, true );
			if ( is_array( $share_history ) && count( $share_history ) > 0 ) {
				$old_history = array_filter( $share_history, function ( $entry ) use ( $cutoff ) {
					$shared_at = $entry['shared_at'] ?? '';
					return ! empty( $shared_at ) && $shared_at < $cutoff;
				} );

				if ( count( $old_history ) < count( $share_history ) ) {
					if ( ! empty( $old_history ) ) {
						update_post_meta( $post_id, Config::META_BUFFER_SHARE_HISTORY, array_values( $old_history ) );
					} else {
						delete_post_meta( $post_id, Config::META_BUFFER_SHARE_HISTORY );
					}
					$cleaned++;
				}
			}

			$jetpack_done = $wpdb->get_col( $wpdb->prepare(
				"SELECT meta_key FROM {$wpdb->postmeta}
				WHERE post_id = %d AND meta_key LIKE %s",
				$post_id,
				$wpdb->esc_like( Config::META_JETPACK_MESSAGE ) . '_%'
			) );

			foreach ( $jetpack_done as $key ) {
				delete_post_meta( $post_id, $key );
				$cleaned++;
			}
		}

		if ( $cleaned > 0 ) {
			Logger::info( 'social_meta_cleaned', null, [
				'cleaned_count' => $cleaned,
			] );
		}
		return $cleaned;
	}

	private function clean_buffer_drafts() {
		$buffer_retention = (int) get_option( Config::OPTION_BUFFER_DRAFT_RETENTION_DAYS, Config::DEFAULT_BUFFER_DRAFT_RETENTION_DAYS );
		if ( $buffer_retention <= 0 ) {
			return 0;
		}

		if ( ! Config::is_buffer_enabled() ) {
			return 0;
		}

		$deleted = 0;
		try {
			$deleted = BufferIntegration::cleanup_old_drafts( $buffer_retention );
			if ( $deleted > 0 ) {
				Logger::info( 'buffer_drafts_cleanup', null, [
					'deleted_count' => $deleted,
					'retention_days' => $buffer_retention,
				], '200', 'Cleaned up ' . $deleted . ' old Buffer drafts' );
			}
		} catch ( \Throwable $e ) {
			Logger::warning( 'buffer_drafts_cleanup_failed', null, [
				'error' => $e->getMessage(),
			] );
		}
		return $deleted;
	}

 	private function delete_post_media( $post_id ) {
 		$attachment_ids = [];

 		$thumbnail_id = get_post_thumbnail_id( $post_id );
 		if ( $thumbnail_id ) {
 			$is_ai = get_post_meta( $thumbnail_id, Config::META_IS_AI_COLLAGE, true );
 			if ( $is_ai ) {
 				$attachment_ids[] = (int) $thumbnail_id;
 			}
 		}

 		$attachments = get_posts( [
 			'post_type'      => 'attachment',
 			'posts_per_page' => -1,
 			'post_parent'    => $post_id,
 			'fields'         => 'ids',
 			'meta_query'     => [
 				'relation' => 'OR',
 				[
 					'key'   => Config::META_IS_AI_COLLAGE,
 					'value' => '1',
 				],
 				// Raw source videos never carry META_IS_AI_COLLAGE; remove them too.
 				[
 					'key'   => Config::META_SOURCE_VIDEO,
 					'value' => '1',
 				],
 			],
 		] );

 		foreach ( $attachments as $attachment_id ) {
 			$attachment_ids[] = (int) $attachment_id;
 		}
 		$attachment_ids = array_unique( $attachment_ids );

 		foreach ( $attachment_ids as $attachment_id ) {
 			$this->delete_r2_object_for_attachment( $attachment_id );
 			wp_delete_attachment( $attachment_id, true );
 		}
 	}

 	/**
 	 * Delete the R2 object referenced by an attachment's _ai_collage_r2_url meta.
 	 * The meta is removed only when the remote object was deleted.
 	 */
 	private function delete_r2_object_for_attachment( $attachment_id ) {
 		$r2_url = get_post_meta( (int) $attachment_id, '_ai_collage_r2_url', true );
 		if ( empty( $r2_url ) || ! is_string( $r2_url ) ) {
 			return;
 		}
 		$key = ltrim( (string) wp_parse_url( $r2_url, PHP_URL_PATH ), '/' );
 		if ( $key === '' ) {
 			return;
 		}
 		try {
 			if ( ! class_exists( 'AiSocialCollage\Services\R2Storage' ) ) {
 				return;
 			}
 			$storage = new R2Storage();
 			$result  = $storage->delete_object( $key );
 			if ( is_wp_error( $result ) ) {
 				Logger::warning( 'r2_object_delete_failed', (int) $attachment_id, [
 					'key'   => $key,
 					'error' => $result->get_error_message(),
 				] );
 				return;
 			}
 			Logger::info( 'r2_object_deleted_for_attachment', (int) $attachment_id, [ 'key' => $key ], '200' );
 			delete_post_meta( (int) $attachment_id, '_ai_collage_r2_url' );
 		} catch ( \Throwable $e ) {
 			Logger::warning( 'r2_object_delete_exception', (int) $attachment_id, [
 				'key'   => $key,
 				'error' => $e->getMessage(),
 			] );
 		}
 	}

 	private function clean_generated_posts( $days ) {
 		$categories = get_option( Config::OPTION_GENERATED_POST_RETENTION_CATEGORIES, [] );
 		$date_query = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );
 		$total_deleted = 0;

 		do {
 			$args = [
 				'post_type'      => 'post',
 				'post_status'    => 'any',
 				'posts_per_page' => 200,
 				'fields'         => 'ids',
 				'date_query'     => [
 					[
 						'column' => 'post_date_gmt',
 						'before' => $date_query,
 					],
 				],
 				'meta_query'     => [
 					[
 						'key'     => Config::META_AUTO_META,
 						'compare' => 'EXISTS',
 					],
 				],
 			];

 			if ( ! empty( $categories ) && is_array( $categories ) ) {
 				$args['category__in'] = $categories;
 			}

 			$query = new \WP_Query( $args );

 			if ( empty( $query->posts ) ) {
 				break;
 			}

 			foreach ( $query->posts as $post_id ) {
 				// $this->delete_post_media( $post_id ); // Removed to prevent double-execution via before_delete_post hook
 				wp_delete_post( $post_id, true );
 				$total_deleted++;
 			}

 			if ( count( $query->posts ) < 200 ) {
 				break;
 			}
 		} while ( true );

  		if ( $total_deleted > 0 ) {
  			Logger::info( 'generated_posts_cleaned', null, [ 'deleted_count' => $total_deleted, 'retention_days' => $days ], '200' );
  		}

  		return $total_deleted;
  	}

 	private function clean_source_posts( $days ) {
 		$categories = get_option( Config::OPTION_SOURCE_POST_RETENTION_CATEGORIES, [] );
 		$date_query = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );
 		$total_deleted = 0;

 		do {
 			$args = [
 				'post_type'      => 'post',
 				'post_status'    => 'any',
 				'posts_per_page' => 200,
 				'fields'         => 'ids',
 				'date_query'     => [
 					[
 						'column' => 'post_date_gmt',
 						'before' => $date_query,
 					],
 				],
 				'meta_query'     => [
 					'relation' => 'AND',
 					[
 						'relation' => 'OR',
 						[
 							'key'     => Config::META_RSS_SOURCE_URL,
 							'compare' => 'EXISTS',
 						],
 						[
 							'key'     => Config::META_CAMPAIGN_DATA,
 							'compare' => 'EXISTS',
 						],
 					],
 					[
 						'key'     => Config::META_AUTO_META,
 						'compare' => 'NOT_EXISTS',
 					],
 				],
 			];

 			if ( ! empty( $categories ) && is_array( $categories ) ) {
 				$args['category__in'] = $categories;
 			}

 			$query = new \WP_Query( $args );

 			if ( empty( $query->posts ) ) {
 				break;
 			}

 			foreach ( $query->posts as $post_id ) {
 				// $this->delete_post_media( $post_id ); // Removed to prevent double-execution via before_delete_post hook
 				wp_delete_post( $post_id, true );
 				$total_deleted++;
 			}

 			if ( count( $query->posts ) < 200 ) {
 				break;
 			}
 		} while ( true );

  		if ( $total_deleted > 0 ) {
  			Logger::info( 'source_posts_cleaned', null, [ 'deleted_count' => $total_deleted, 'retention_days' => $days ], '200' );
  		}

  		return $total_deleted;
  	}

  	public function handle_post_deletion( $post_id ) {
  		global $wpdb;
  		$jobs_table = $wpdb->prefix . Config::TABLE_JOBS;
  		$wpdb->query( $wpdb->prepare(
  			"DELETE FROM {$jobs_table} WHERE post_id = %d",
  			$post_id
  		) );

  		$this->delete_post_media( $post_id );
  	}
}
