<?php
/**
* Plugin Name: AI Social Collage Pro
 * Description: AI-driven news pipeline with RSS ingestion, auto-template selection, platform-adaptive social posting, and Pango-rendered social collages with Nastaliq font support.
 * Version: 3.1.3
 * Author: Snr WP Engineer
 * Text Domain: ai-social-collage
 * 
 * Changelog:
 * 3.1.3 - 2026-08-17
 *   - User-editable post content routable to Buffer (headline, hook, description, X-content, tags, mentions)
 *   - Gutenberg block output for mobile-friendly editing
 *   - Removed conflicting the_content filter
 * 3.1.2 - 2026-08-01
 *   - NEW: Buffer scheduled-slots management (reactive, zero overhead on normal shares).
 *     When a channel hits the 10-post queue limit, the plugin either auto-publishes the
 *     oldest scheduled post to make room (publish_oldest) or defers the share and retries
 *     automatically when a slot frees (wait). Per-account "Queue Full Action" setting.
 *     Scheduled-posts data is fetched ONLY on first error, cached for 5 min, and cleared
 *     on successful share so the next error triggers a fresh fetch.
 *   - New cron hook ai_social_collage_retry_buffer_pending_shares fires every 5 min for deferred retries.
 * 3.1.1 - 2026-07-31
 *   - CRITICAL FIX: Buffer sharing was sending the raw source video instead of the
 *         rendered reel. PostObserver/CronScheduler queried video attachments with
 *         ORDER BY menu_order ASC, returning the source (lower ID) instead of the
 *         AI-generated reel. Now only META_IS_AI_COLLAGE attachments are accepted;
 *         no fallback to source video.
 *   - FIX: Video logo positioning was hardcoded at fixed 20px padding regardless of
 *         canvas dimensions. Now scales proportionally (2% width, 1.2% height) and
 *         respects logo_position setting (top-left/top-right) with FFmpeg dynamic
 *         right-alignment (W-w-padding).
 * 3.1.0 - 2026-05-24
 *   - FIX: Google Lens reverse search now works on all images (not just celebrity photos).
 *         Falls back to post-keyword matching when no celebrities detected.
 *   - FIX: Images in templates now use "cover" sizing instead of "contain" to fill the
 *         full canvas width, eliminating side bars.
 *   - FIX: Urdu and English font sizes increased significantly (headings up to 84px,
 *         descriptions minimum raised to 24px) so text fills the container.
 *   - FIX: Text container now uses "center" vertical alignment instead of "flex-start",
 *         eliminating empty black voids at bottom of collage.
*/

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ── Constants ───────────────────────────────────────────────────────────────
define( 'AI_SOCIAL_COLLAGE_PATH',    plugin_dir_path( __FILE__ ) );
define( 'AI_SOCIAL_COLLAGE_URL',     plugin_dir_url( __FILE__ ) );  // FIX #9/#14: define URL constant here, not reconstructed in Dashboard
define( 'AI_SOCIAL_COLLAGE_VERSION', '3.1.3' );

// ── Autoloader ──────────────────────────────────────────────────────────────
if ( file_exists( AI_SOCIAL_COLLAGE_PATH . 'vendor/autoload.php' ) ) {
    require_once AI_SOCIAL_COLLAGE_PATH . 'vendor/autoload.php';
}

// ── Action Scheduler ────────────────────────────────────────────────────────
// Only load our own bundled copy if nothing else on the site has already
// provided Action Scheduler. Another plugin (or a standalone install) may ship
// a newer version, and Action Scheduler resolves to the HIGHEST registered
// version at plugins_loaded:0 — so deferring to an existing copy keeps a single
// canonical library in charge instead of racing two of them.
//
// The bundled files stay on disk as a fallback: if the other plugin is
// deactivated, this plugin still works. If you want them physically removed,
// delete vendor/woocommerce/action-scheduler/ ONLY if another Action Scheduler
// is guaranteed to stay active — ~39 of the 80 as_*() calls in this plugin are
// unguarded and will fatal if no copy of the library is present at all.
$_as_path          = AI_SOCIAL_COLLAGE_PATH . 'vendor/woocommerce/action-scheduler/action-scheduler.php';
$_as_already_there = function_exists( 'as_schedule_single_action' );

if ( ! $_as_already_there && file_exists( $_as_path ) ) {
    require_once $_as_path;
    define( 'AI_SOCIAL_COLLAGE_AS_SOURCE', 'bundled' );
} else {
    define( 'AI_SOCIAL_COLLAGE_AS_SOURCE', $_as_already_there ? 'external' : 'none' );
}

// Loud, obvious warning if NEITHER copy is available — otherwise every queue
// operation fails silently with "undefined function as_*()".
if ( 'none' === AI_SOCIAL_COLLAGE_AS_SOURCE ) {
    add_action( 'admin_notices', function () {
        if ( ! current_user_can( 'manage_options' ) ) { return; }
        echo '<div class="notice notice-error"><p><strong>AI Social Collage:</strong> '
            . 'Action Scheduler is not available — neither the bundled copy nor another '
            . 'plugin is providing it. Background job processing will not work. Reinstall '
            . 'the plugin or activate a plugin that ships Action Scheduler.</p></div>';
    } );
}

use AiSocialCollage\Database\Migration;

// ── Activation ──────────────────────────────────────────────────────────────
register_activation_hook( __FILE__, function () {
	Migration::create_tables();
	if ( ! get_option( \AiSocialCollage\Config::OPTION_RSS_FEEDS ) ) {
		update_option( \AiSocialCollage\Config::OPTION_RSS_FEEDS, \AiSocialCollage\Config::get_default_rss_feeds() );
	}
	\AiSocialCollage\Services\QueueHealthMonitor::get_or_create_health_check_token();
} );

// ── Deactivation ────────────────────────────────────────────────────────────
register_deactivation_hook( __FILE__, function () {
    if ( function_exists( 'as_unschedule_all_actions' ) ) {
        as_unschedule_all_actions( '', [], \AiSocialCollage\Config::AS_GROUP );
    }
    wp_clear_scheduled_hook( 'ai_social_collage_native_health_check' );
    global $wpdb;
    $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_ai_collage_%'" );
    $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_ai_collage_%'" );
} );

// ── Bootstrap ───────────────────────────────────────────────────────────────
add_action( 'plugins_loaded', function () {
	Migration::ensure_tables();
	Migration::maybe_upgrade();
	\AiSocialCollage\Services\QueueHealthMonitor::instance()->init();
	new \AiSocialCollage\Actions\CronScheduler();
	new \AiSocialCollage\Actions\QueueProcessor();
	new \AiSocialCollage\Actions\PostObserver();
	new \AiSocialCollage\View\Dashboard();
	new \AiSocialCollage\Services\CleanupManager();
	new \AiSocialCollage\Services\JetpackSocial();
} );

// ── Direct log-download endpoint (bypasses admin-ajax.php) ──────────────────
add_action( 'init', function () {
	if ( empty( $_GET['ai_collage_download_logs'] ) || '1' !== (string) $_GET['ai_collage_download_logs'] ) {
		return;
	}
	\AiSocialCollage\View\Dashboard::serve_logs_download();
} );

add_action( 'admin_init', function () {
	Migration::ensure_tables();
} );

add_filter( 'wpseo_metadesc', function ( $desc ) {
	if ( empty( $desc ) ) {
		$post_id = get_the_ID();
		$auto_meta = get_post_meta( $post_id, '_ai_collage_auto_meta', true );
		if ( ! empty( $auto_meta['ai_hook'] ) ) {
			return wp_strip_all_tags( $auto_meta['ai_hook'] );
		}
	}
	return $desc;
}, 10, 1 );
