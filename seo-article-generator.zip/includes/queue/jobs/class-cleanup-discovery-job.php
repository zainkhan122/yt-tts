<?php

/**
 * Cleanup Discovery Job
 *
 * @package SEO_Article_Generator
 * @MODIFIED 2026-03-02 v2.19.0: Industrial Queue Architecture
 */

namespace SEO_Article_Generator\Queue\Jobs;

use SEO_Article_Generator\Queue\Abstract_Job;
use SEO_Article_Generator\Utils\Plugin_Time;

// Prevent direct access
if (! defined('ABSPATH')) {
    exit();
}

/**
 * Purges old 'done', 'skippednotnewer', 'skippedduplicate', and 'ignored' 
 * rows from the seo_gen_discovery table that are older than 60 days.
 */
class Cleanup_Discovery_Job extends Abstract_Job
{
    /**
     * @MODIFIED 2026-03-02: 60-day cleanup window for discovery rows.
     *
     * @return bool True on success.
     */
    public function handle()
    {
        // FINDING-13 FIX: Delegate to the canonical authority in DiscoveryProcessor, which:
        // 1. Respects the seogen_discovery_terminal_retention_days filter.
        // 2. Cancels orphaned AS actions before deleting rows.
        // 3. Uses the correct retention config (not hardcoded 60 days).
        if (class_exists('SEO_Article_Generator\Discovery\Discovery_Processor')) {
            $processor = new \SEO_Article_Generator\Discovery\Discovery_Processor();
            $deleted = $processor->purge_old_items();
            return $deleted >= 0; // purge_old_items returns int, 0 is valid
        }

        // Fallback: legacy path with AS action cleanup.
        global $wpdb;

        $table = \SEO_Article_Generator\Installer::table_discovery();

        $cutoff = \SEO_Article_Generator\Utils\Plugin_Time::utc_mysql_from_utc_ts(
            \SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts() - (60 * DAY_IN_SECONDS)
        );

        $ids = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT id
                 FROM {$table}
                 WHERE status IN ('failed', 'timeout', 'skippednotnewer', 'skippedduplicate', 'ignored')
                   AND (
                        completed_at <= %s
                        OR (completed_at IS NULL AND discovered_at <= %s)
                   )",
                $cutoff,
                $cutoff
            )
        );

        if (!empty($ids)) {
            foreach ($ids as $id) {
                \SEO_Article_Generator\Queue\AS_Registry::cancel_item_actions((int) $id);
            }
            $id_list = implode(',', array_map('intval', $ids));
            $wpdb->query("DELETE FROM {$table} WHERE id IN ($id_list)");
        }

        return true;
    }
}
