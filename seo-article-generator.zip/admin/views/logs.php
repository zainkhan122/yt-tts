<?php

/**
 * Logs View
 */

namespace SEO_Article_Generator\Admin;

if (! defined('ABSPATH')) {
	exit;
}

$logger = $this->logger;
$log_files = $logger->get_log_files();
$current_file = isset($_GET['log_file']) ? sanitize_text_field($_GET['log_file']) : (isset($log_files[0]) ? $log_files[0]['name'] : '');
$log_content = $current_file ? $logger->read_log_file($current_file) : '';
$debug_log_path = (string) \get_option(\SEO_Article_Generator\Option_Registry::DEBUG_LOG_PATH, '');
$active_tab = isset($_GET['tab']) && $_GET['tab'] === 'debug' ? 'debug' : 'plugin';

$debug_log_info = null;
if ($debug_log_path !== '') {
	$debug_log_info = $logger->get_external_log_info($debug_log_path);
}

?>

<div class="wrap seo-gen-wrap">
<h1><?php \_e('AI Generation Logs', 'seo-article-generator'); ?></h1>

<div class="seo-gen-logs-tabs">
	<button type="button" class="seo-gen-logs-tab <?php echo $active_tab === 'plugin' ? 'active' : ''; ?>" data-tab="plugin"><?php \_e('Plugin Logs', 'seo-article-generator'); ?></button>
	<button type="button" class="seo-gen-logs-tab <?php echo $active_tab === 'debug' ? 'active' : ''; ?>" data-tab="debug"><?php \_e('Debug Log', 'seo-article-generator'); ?></button>
</div>

<div class="seo-gen-logs-tab-content" id="seo-gen-tab-plugin" style="<?php echo $active_tab !== 'plugin' ? 'display:none' : ''; ?>">
<div class="seo-gen-logs-container">
<div class="seo-gen-logs-sidebar">
<h3><?php \_e('Available Logs', 'seo-article-generator'); ?></h3>
<ul class="seo-gen-log-list">
<?php if (empty($log_files)) : ?>
<li><?php \_e('No logs found.', 'seo-article-generator'); ?></li>
<?php else : ?>
<?php foreach ($log_files as $file) : ?>
<li class="<?php echo ($current_file === $file['name']) ? 'active' : ''; ?>">
<a href="<?php echo \admin_url('admin.php?page=seo-generator-logs&tab=' . $active_tab . '&log_file=' . \urlencode($file['name'])); ?>">
<span class="log-date"><?php echo esc_html($file['date']); ?></span>
<span class="log-size"><?php echo esc_html($file['size']); ?></span>
</a>
</li>
<?php endforeach; ?>
<?php endif; ?>
</ul>
</div>

<div class="seo-gen-logs-main">
<div class="seo-gen-logs-header">
<h2><?php echo esc_html($current_file); ?></h2>
<div class="seo-gen-logs-actions">
<a href="<?php echo \admin_url('admin-ajax.php?action=seo_gen_download_log&log_file=' . \urlencode($current_file) . '&_wpnonce=' . \wp_create_nonce('seo_gen_download_log')); ?>" class="button button-primary" title="<?php \esc_attr_e('Download full log file', 'seo-article-generator'); ?>">📥 <?php \_e('Download', 'seo-article-generator'); ?></a>
<button type="button" class="button" id="seo-gen-copy-logs"><?php \_e('Copy to Clipboard', 'seo-article-generator'); ?></button>
<button type="button" class="button button-danger" id="seo-gen-clear-current" data-file="<?php echo \esc_attr($current_file); ?>"><?php \_e('Delete This Log', 'seo-article-generator'); ?></button>
</div>
</div>

<div class="seo-gen-log-content-wrapper">
<?php if ($log_content) : ?>
<pre id="seo-gen-log-viewer"><?php echo \htmlspecialchars((string)$log_content, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); ?></pre>
<?php else : ?>
<p class="description"><?php echo $current_file ? \__('This log file is empty.', 'seo-article-generator') : \__('Select a log file to view its content.', 'seo-article-generator'); ?></p>
<?php endif; ?>
</div>
</div>
</div>
</div>

<div class="seo-gen-logs-tab-content" id="seo-gen-tab-debug" style="<?php echo $active_tab !== 'debug' ? 'display:none' : ''; ?>">
<div class="seo-gen-debug-log-container">
<div class="seo-gen-debug-log-path-bar">
<label for="seo-gen-debug-log-path"><strong><?php \_e('Debug Log Path:', 'seo-article-generator'); ?></strong></label>
<input type="text" id="seo-gen-debug-log-path" class="regular-text" value="<?php echo \esc_attr($debug_log_path); ?>" placeholder="/web/logs/my site/debug.log" />
<button type="button" class="button" id="seo-gen-save-debug-path"><?php \_e('Save Path', 'seo-article-generator'); ?></button>
<button type="button" class="button button-primary" id="seo-gen-load-debug-log"><?php \_e('Load', 'seo-article-generator'); ?></button>
<?php if ($debug_log_info) : ?>
<span class="seo-gen-debug-log-meta"><?php echo \esc_html($debug_log_info['size']); ?> &mdash; <?php echo \esc_html($debug_log_info['mtime']); ?></span>
<?php endif; ?>
</div>

	<div class="seo-gen-debug-log-header">
	<h2><?php \_e('WordPress Debug Log', 'seo-article-generator'); ?></h2>
	<div class="seo-gen-logs-actions">
	<a href="<?php echo \esc_url(\admin_url('admin-ajax.php?action=seo_gen_download_debug_log&_wpnonce=' . \wp_create_nonce('seo_gen_download_debug_log'))); ?>" class="button button-primary" id="seo-gen-download-debug-log" title="<?php \esc_attr_e('Download debug.log', 'seo-article-generator'); ?>">📥 <?php \_e('Download', 'seo-article-generator'); ?></a>
	<button type="button" class="button" id="seo-gen-copy-debug-log"><?php \_e('Copy to Clipboard', 'seo-article-generator'); ?></button>
	</div>
	</div>

	<div class="seo-gen-log-content-wrapper">
	<?php if ($debug_log_path !== '' && $debug_log_info) : ?>
	<pre id="seo-gen-debug-log-viewer"></pre>
	<?php elseif ($debug_log_path !== '' && !$debug_log_info) : ?>
	<p class="description"><?php \_e('The specified debug log file was not found or is not readable. Please check the path.', 'seo-article-generator'); ?></p>
	<?php else : ?>
	<p class="description"><?php \_e('Enter the absolute path to your debug.log file above and click Load to view its content.', 'seo-article-generator'); ?></p>
	<?php endif; ?>
	</div>

	<div class="seo-gen-debug-log-pagination" id="seo-gen-debug-log-pagination" style="display:none;">
	<button type="button" class="button" id="seo-gen-debug-prev" disabled><?php \_e('← Prev', 'seo-article-generator'); ?></button>
	<span id="seo-gen-debug-page-info"></span>
	<button type="button" class="button" id="seo-gen-debug-next" disabled><?php \_e('Next →', 'seo-article-generator'); ?></button>
	</div>
</div>
</div>
</div>

<style>
.seo-gen-logs-tabs {
display: flex;
border-bottom: 1px solid #ccd0d4;
margin-top: 10px;
background: #f6f7f7;
position: relative;
z-index: 2;
}

.seo-gen-logs-tab {
padding: 10px 20px;
border: 1px solid #ccd0d4;
border-bottom: none;
background: #f6f7f7;
color: #646970;
cursor: pointer;
font-size: 13px;
font-weight: 600;
margin-right: -1px;
transition: background 0.15s, color 0.15s;
position: relative;
z-index: 1;
}

.seo-gen-logs-tab:hover {
	background: #fff;
	color: #2271b1;
}

.seo-gen-logs-tab.active {
background: #fff;
color: #1d2327;
border-bottom: 1px solid #fff;
margin-bottom: -1px;
z-index: 3;
}

.seo-gen-logs-container {
	display: flex;
	background: #fff;
	border: 1px solid #ccd0d4;
	box-shadow: 0 1px 1px rgba(0, 0, 0, .04);
	height: 700px;
}

.seo-gen-logs-sidebar {
	width: 250px;
	border-right: 1px solid #ccd0d4;
	background: #f6f7f7;
	overflow-y: auto;
}

.seo-gen-logs-sidebar h3 {
	padding: 10px 15px;
	margin: 0;
	border-bottom: 1px solid #ccd0d4;
	background: #fff;
}

.seo-gen-log-list {
	margin: 0;
	padding: 0;
	list-style: none;
}

.seo-gen-log-list li {
	margin: 0;
	border-bottom: 1px solid #e5e5e5;
}

.seo-gen-log-list li a {
	display: flex;
	justify-content: space-between;
	padding: 12px 15px;
	text-decoration: none;
	color: #2c3338;
}

.seo-gen-log-list li.active {
	background: #fff;
	border-left: 4px solid #2271b1;
}

.seo-gen-log-list li.active a {
	margin-left: -4px;
}

.seo-gen-log-list li a:hover {
	background: #fff;
}

.log-size {
	color: #646970;
	font-size: 11px;
}

.seo-gen-logs-main {
	flex: 1;
	display: flex;
	flex-direction: column;
	overflow: hidden;
}

.seo-gen-logs-header {
	display: flex;
	justify-content: space-between;
	align-items: center;
	padding: 10px 20px;
	border-bottom: 1px solid #ccd0d4;
	background: #fff;
}

.seo-gen-logs-header h2 {
	margin: 0;
	font-size: 14px;
}

.seo-gen-log-content-wrapper {
	flex: 1;
	overflow: auto;
	padding: 20px;
	background: #2c3338;
}

#seo-gen-log-viewer,
#seo-gen-debug-log-viewer {
	margin: 0;
	color: #dcdc40;
	font-family: monospace;
	white-space: pre-wrap;
	word-break: break-all;
}

.seo-gen-logs-actions .button-primary {
	color: #fff !important;
	background: #2271b1 !important;
	border-color: #2271b1 !important;
}

.seo-gen-logs-actions .button-primary:hover {
	background: #135e96 !important;
	border-color: #135e96 !important;
	color: #fff !important;
}

.button-danger {
	color: #d63638 !important;
	border-color: #d63638 !important;
}

.button-danger:hover {
	background: #d63638 !important;
	color: #fff !important;
}

.seo-gen-debug-log-container {
	background: #fff;
	border: 1px solid #ccd0d4;
	box-shadow: 0 1px 1px rgba(0, 0, 0, .04);
	display: flex;
	flex-direction: column;
	height: 700px;
}

.seo-gen-debug-log-path-bar {
	display: flex;
	align-items: center;
	gap: 8px;
	padding: 12px 20px;
	border-bottom: 1px solid #ccd0d4;
	background: #f6f7f7;
	flex-wrap: wrap;
}

.seo-gen-debug-log-path-bar label {
	white-space: nowrap;
}

.seo-gen-debug-log-path-bar input {
	flex: 1;
	min-width: 250px;
}

.seo-gen-debug-log-meta {
	color: #646970;
	font-size: 12px;
	font-style: italic;
}

.seo-gen-debug-log-header {
	display: flex;
	justify-content: space-between;
	align-items: center;
	padding: 10px 20px;
	border-bottom: 1px solid #ccd0d4;
	background: #fff;
}

.seo-gen-debug-log-header h2 {
	margin: 0;
	font-size: 14px;
}

.seo-gen-debug-log-pagination {
	display: flex;
	align-items: center;
	justify-content: center;
	gap: 12px;
	padding: 10px 20px;
	border-top: 1px solid #ccd0d4;
	background: #f6f7f7;
}

#seo-gen-debug-page-info {
	color: #50575e;
	font-size: 13px;
}
</style>
