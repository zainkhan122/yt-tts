<?php

/**
 * AJAX Manager - Frontend
 *
 * Handles all AJAX requests for the public-facing side of the plugin,
 * including quiz loading, answer tracking, and reporting.
 *
 * @package WP_News_MCQ_Generator
 * @version 1.0
 */

if (! defined('ABSPATH')) {
	exit;
}

class NM_AJAX_Frontend
{


	// ============================================================================
	// Frontend MCQ Handlers
	// ============================================================================

	/**
	 * Get the pretty permalink for an MCQ post.
	 *
	 * WordPress's get_permalink() can return ugly URLs (?post_type=mcq&p=ID) when:
	 * - The post doesn't have a proper slug
	 * - Called in AJAX context before rewrite rules are fully loaded
	 * - The post_name is empty or auto-draft
	 *
	 * This helper ensures we always return the pretty permalink format.
	 *
	 * @param int $post_id The post ID.
	 * @return string The pretty permalink URL.
	 */
	public static function get_mcq_permalink($post_id)
	{
		$post = get_post($post_id);
		if (! $post || $post->post_type !== 'mcq') {
			return get_permalink($post_id);
		}

		// Never write to DB on frontend requests.
		// Just compute a safe slug for URL construction.
		// @MODIFIED v9.0.3 - Removed wp_update_post to prevent frontend writes
		$computed_slug = $post->post_name;
		if (empty($computed_slug) || strpos($computed_slug, 'auto-draft') !== false) {
			$computed_slug = sanitize_title($post->post_title);
		}

		// Build the permalink manually using the MCQ rewrite slug
		$permalink = get_permalink($post_id);

		// Check if we got an ugly permalink (contains ?post_type= or ?p=)
		if (strpos($permalink, '?post_type=') !== false || strpos($permalink, '?p=') !== false) {
			// Manually construct the pretty permalink
			$base_url = trailingslashit(home_url());
			$slug     = $computed_slug;

			// If still no slug, use the post ID as fallback
			if (empty($slug)) {
				$slug = sanitize_title($post->post_title);
				if (empty($slug)) {
					$slug = $post_id;
				}
			}

			// Use the registered rewrite slug for MCQ post type
			$permalink = $base_url . 'mcq/' . $slug . '/';
		}

		return $permalink;
	}

	/**
	 * Fetches a random set of MCQs based on filters.
	 * Used by the main [display_mcqs] shortcode.
	 */
	public static function nm_fetch_mcqs_callback()
	{
		check_ajax_referer('nm_mcq_nonce', 'nonce');

		$count         = NM_Security_Manager::sanitize_integer($_POST['count'] ?? 5);
		$topic         = NM_Security_Manager::sanitize_text($_POST['topic'] ?? '');
		$tag           = NM_Security_Manager::sanitize_text($_POST['tag'] ?? '');
		$subtopic      = NM_Security_Manager::sanitize_text($_POST['subtopic'] ?? '');

		// If a subtopic is selected, it takes precedence for the query (as it's more specific)
		if (! empty($subtopic)) {
			$topic = $subtopic;
		}

		$exclude_ids   = isset($_POST['exclude_ids']) ? array_map('intval', (array) $_POST['exclude_ids']) : array();
		$difficulty    = NM_Security_Manager::sanitize_text($_POST['difficulty'] ?? '');
		$cognitive_lvl = NM_Security_Manager::sanitize_text($_POST['cognitive_level'] ?? '');
		$exam          = NM_Security_Manager::sanitize_text($_POST['exam'] ?? '');
		$month         = NM_Security_Manager::sanitize_text($_POST['month'] ?? '');

		$mcqs_data = self::nm_get_mcqs(
			array(
				'count'           => $count,
				'topic'           => $topic,
				'tag'             => $tag,
				'exclude_ids'     => $exclude_ids,
				'month'           => $month,
				'difficulty'      => $difficulty,
				'cognitive_level' => $cognitive_lvl,
				'exam'            => $exam,
			)
		);

		// IMPORTANT: send JSON back to the browser
		if (! is_array($mcqs_data)) {
			$mcqs_data = array();
		}

		NM_Response_Handler::success($mcqs_data);
	}
	/**
	 * Fetches sub-topics for the filter dropdown.
	 */
	public static function nm_fetch_sub_topics_callback()
	{
		check_ajax_referer('nm_mcq_nonce', 'nonce');

		$parent_id = NM_Security_Manager::sanitize_integer($_POST['parent_id'] ?? 0);
		if ($parent_id === 0) {
			NM_Response_Handler::success(array());
			return;
		}

		$cache_key        = 'nm_subtopics_' . $parent_id;
		$cached_subtopics = NM_Cache_Manager::get($cache_key);

		if ($cached_subtopics !== false) {
			NM_Response_Handler::success($cached_subtopics);
			return;
		}

		$sub_topics      = get_terms(
			array(
				'taxonomy'   => 'topic',
				'hide_empty' => true,
				'parent'     => $parent_id,
			)
		);
		$sub_topics_data = array();

		if (! is_wp_error($sub_topics) && ! empty($sub_topics)) {
			foreach ($sub_topics as $term) {
				$sub_topics_data[] = array(
					'slug' => $term->slug,
					'name' => $term->name,
				);
			}
		}

		NM_Cache_Manager::set($cache_key, $sub_topics_data, 21600); // 6-hour cache
		NM_Response_Handler::success($sub_topics_data);
	}

	/**
	 * Handles the "Report" button click on an MCQ.
	 */
	public static function nm_report_mcq_callback()
	{
		check_ajax_referer('nm_mcq_nonce', 'nonce');

		if (! isset($_POST['post_id']) || ! isset($_POST['reason'])) {
			NM_Response_Handler::error('Invalid data provided.', 'invalid_data');
			return;
		}

		$post_id = NM_Security_Manager::sanitize_integer($_POST['post_id']);
		$reason  = NM_Security_Manager::sanitize_textarea($_POST['reason']);

		update_post_meta($post_id, 'mcq_reported', 'yes');
		update_post_meta($post_id, 'mcq_report_reason', $reason);

		// Bust admin cache for reported MCQs
		NM_Cache_Manager::delete('admin_reported_mcqs');
		NM_Cache_Manager::delete('admin_dashboard_stats');

		NM_Response_Handler::success(array('message' => 'Question reported successfully.'));
	}

	/**
	 * Handles "Load More" on taxonomy pages (Topic archives).
	 * Returns fully rendered HTML cards using render_mcq_card().
	 */
	public static function nm_ajax_load_more_mcqs()
	{
		check_ajax_referer('nm_load_more_nonce', 'nonce');

		$topic_slug = sanitize_text_field($_POST['topic'] ?? '');
		$offset     = intval($_POST['offset'] ?? 0);
		$month      = sanitize_text_field($_POST['month'] ?? '');

		if (empty($topic_slug)) {
			NM_Response_Handler::error('Invalid parameters', 'invalid_params');
			return;
		}

		// --- Build WP_Query Args ---
		// @MODIFIED: Changed fallback from 'rand' to 'date_desc' as SEO guardrail
		$global_order = get_option('nm_mcq_display_order', 'date_desc');
		$orderby      = 'rand';
		$order        = 'DESC';

		if ($global_order === 'date_desc') {
			$orderby = 'date';
			$order   = 'DESC';
		} elseif ($global_order === 'date_asc') {
			$orderby = 'date';
			$order   = 'ASC';
		}

		$mcqs_query_args = array(
			'post_type'      => 'mcq',
			'post_status'    => 'publish',
			'posts_per_page' => 10,
			'offset'         => $offset,
			'tax_query'      => array(
				array(
					'taxonomy' => 'topic',
					'field'    => 'slug',
					'terms'    => $topic_slug,
				),
			),
			'orderby'        => $orderby,
			'order'          => $order,
		);

		if (! empty($month) && $month !== 'all') {
			$date_parts = explode('-', $month);
			if (count($date_parts) === 2) {
				$mcqs_query_args['date_query'] = array(
					array(
						array(
							'year'  => intval($date_parts[0]),
							'month' => intval($date_parts[1]),
						),
					),
				);
				$mcqs_query_args['orderby']    = 'date';
			}
		}

		$mcqs_query = new WP_Query($mcqs_query_args);
		$mcqs_data  = array();

		if ($mcqs_query->have_posts()) {
			// Prime meta cache for Load More queries
			$post_ids = wp_list_pluck($mcqs_query->posts, 'ID');
			update_postmeta_cache($post_ids);

			while ($mcqs_query->have_posts()) {
				$mcqs_query->the_post();

				$mcq_id           = get_the_ID();
				$options          = get_post_meta($mcq_id, 'mcq_options', true);
				$original_correct = get_post_meta($mcq_id, 'mcq_answer', true);
				$shuffled_data    = self::nm_randomize_answer_options($options, $original_correct);

				$mcqs_data[] = array(
					'id'          => $mcq_id,
					'question'    => get_the_title(),
					'options'     => $shuffled_data['options'],
					'answer'      => $shuffled_data['answer'],
					'explanation' => get_post_meta($mcq_id, 'mcq_explanation', true),
					'permalink'   => self::get_mcq_permalink($mcq_id),
				);
			}
			wp_reset_postdata();
		}

		// Render unified Topic-style cards
		ob_start();
		$question_num = $offset + 1;
		$term         = get_term_by('slug', $topic_slug, 'topic');

		foreach ($mcqs_data as $mcq) {
			$post_id        = $mcq['id'];
			$options        = $mcq['options'];
			$correct_answer = $mcq['answer'];
			$explanation    = $mcq['explanation'];

			if (! is_array($options) || empty($correct_answer)) {
				++$question_num;
				continue;
			}

			$card_data = array(
				'post_id'     => $post_id,
				'question'    => $mcq['question'],
				'options'     => $options,
				'answer'      => $correct_answer,
				'explanation' => $explanation,
				'permalink'   => $mcq['permalink'],
				'author'      => get_post_meta($post_id, 'mcq_author_name', true),
				'difficulty'  => get_post_meta($post_id, 'mcq_difficulty', true),
				'factchecked' => get_post_meta($post_id, 'mcq_fact_checked', true),
				'topic_name'  => $term ? '📚 ' . $term->name : '',
			);

			echo NM_Shortcode_Manager::render_mcq_card($card_data, $question_num);
			++$question_num;
		}

		$html = ob_get_clean();

		// --- Build Total Query Args (to check if there are more) ---
		$total_query_args = array(
			'post_type'      => 'mcq',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'post_status'    => 'publish',
			'tax_query'      => array(
				array(
					'taxonomy' => 'topic',
					'field'    => 'slug',
					'terms'    => $topic_slug,
				),
			),
		);

		if (! empty($month) && $month !== 'all') {
			$date_parts = explode('-', $month);
			if (count($date_parts) === 2) {
				$total_query_args['date_query'] = array(
					array(
						array(
							'year'  => intval($date_parts[0]),
							'month' => intval($date_parts[1]),
						),
					),
				);
			}
		}

		$total_query = new WP_Query($total_query_args);

		NM_Response_Handler::success(
			array(
				'html'     => $html,
				'has_more' => ($total_query->found_posts > ($offset + count($mcqs_data))),
			)
		);
	}
	// ============================================================================
	// Quiz Shortcode Handlers
	// ============================================================================

	public static function nm_search_topics_callback()
	{
		// @MODIFIED v8.9.6: Use manual nonce verification to provide detailed guest error
		if (! isset($_POST['nonce']) || ! wp_verify_nonce($_POST['nonce'], 'nm_quiz_nonce')) {
			NM_Response_Handler::error('Security check failed. Please refresh the page.', 'nonce_failure');
			return;
		}

		$search_term = NM_Security_Manager::sanitize_text($_POST['search_term'] ?? '');
		if (strlen($search_term) < 2) {
			NM_Response_Handler::success(array());
			return;
		}

		// @MODIFIED v8.9.6: Changed 'hide_empty' to false to diagnose visibility issues for guests
		$terms   = get_terms(
			array(
				'taxonomy'   => 'topic',
				'search'     => $search_term,
				'hide_empty' => false,
				'number'     => 10,
			)
		);
		$results = array();

		if (! is_wp_error($terms) && ! empty($terms)) {
			foreach ($terms as $term) {
				$results[] = array(
					'name' => $term->name,
					'slug' => $term->slug,
				);
			}
		}

		if (empty($results)) {
			NM_Response_Handler::success(array(), 'No matching topics found.');
		} else {
			NM_Response_Handler::success($results);
		}
	}

	public static function nm_generate_quiz_callback()
	{
		check_ajax_referer('nm_quiz_nonce', 'nonce');

		$count      = NM_Security_Manager::sanitize_integer($_POST['count'] ?? 10);
		$topic_slug = NM_Security_Manager::sanitize_text($_POST['topic_slug'] ?? '');

		$args = array(
			'post_type'      => 'mcq',
			'post_status'    => 'publish', // @MODIFIED v9.0.1: Safety guard — only published MCQs
			'posts_per_page' => $count,
			'orderby'        => 'rand',
		);

		if (! empty($topic_slug)) {
			$args['tax_query'] = array(
				array(
					'taxonomy' => 'topic',
					'field'    => 'slug',
					'terms'    => $topic_slug,
				),
			);
		}

		$mcqs_query = new WP_Query($args);
		$mcqs_data  = array();

		if ($mcqs_query->have_posts()) {
			while ($mcqs_query->have_posts()) {
				$mcqs_query->the_post();
				$mcq_id           = get_the_ID();
				$options          = get_post_meta($mcq_id, 'mcq_options', true);
				$original_correct = get_post_meta($mcq_id, 'mcq_answer', true);
				$shuffled_data    = self::nm_randomize_answer_options($options, $original_correct);
				$mcqs_data[]      = array(
					'question' => get_the_title(),
					'options'  => $shuffled_data['options'],
					'answer'   => $shuffled_data['answer'],
				);
			}
			wp_reset_postdata();
		}

		NM_Response_Handler::success($mcqs_data);
	}

	public static function nm_log_quiz_activity_handler()
	{
		check_ajax_referer('nm_quiz_nonce', 'nonce');

		if (! NM_Response_Handler::require_login()) {
			return;
		}

		$user_id         = get_current_user_id();
		$topic_slug      = NM_Security_Manager::sanitize_text($_POST['topic'] ?? '');
		$total_questions = NM_Security_Manager::sanitize_integer($_POST['total_questions'] ?? 0);
		$correct_answers = NM_Security_Manager::sanitize_integer($_POST['correct_answers'] ?? 0);

		$correct = intval(get_user_meta($user_id, 'nm_total_correct', true));
		$total   = intval(get_user_meta($user_id, 'nm_total_attempts', true));

		$correct += $correct_answers;
		$total   += $total_questions;

		update_user_meta($user_id, 'nm_total_correct', $correct);
		update_user_meta($user_id, 'nm_total_attempts', $total);

		if (class_exists('NM_Gamification')) {
			$points_earned = ($correct_answers * NM_Gamification::POINTS_PER_CORRECT) + NM_Gamification::POINTS_PER_QUIZ_COMPLETE;
			if ($points_earned > 0) {
				NM_Gamification::award_points($user_id, $points_earned, "quiz_complete: {$topic_slug}");
			}
		}

		$accuracy = $total > 0 ? round(($correct / $total) * 100) : 0;

		NM_Response_Handler::success(
			array(
				'message'  => 'Quiz tracked',
				'total'    => $total,
				'correct'  => $correct,
				'accuracy' => $accuracy,
			)
		);
	}

	// ============================================================================
	// Unified Answer Tracking (from single-mcq.php / taxonomy-topic.php)
	// ============================================================================

	public static function nm_track_answer_callback()
	{
		check_ajax_referer('nm_mcq_nonce', 'nonce');

		if (! NM_Response_Handler::require_login()) {
			return;
		}

		$post_id         = isset($_POST['post_id']) ? intval($_POST['post_id']) : 0;
		$was_correct     = isset($_POST['was_correct']) ? ($_POST['was_correct'] == 1 ? 1 : 0) : 0;
		$selected_answer = NM_Security_Manager::sanitize_text($_POST['selected_answer'] ?? '');

		if ($post_id > 0) {
			$user_id = get_current_user_id();
			self::nm_log_user_answer_activity($user_id, $post_id, $was_correct, $selected_answer);
			NM_Response_Handler::success(array('message' => 'Progress tracked.'));
		} else {
			NM_Response_Handler::error('Invalid MCQ ID.', 'invalid_id');
		}
	}

	// ============================================================================
	// Private Helper Functions (Moved from old AJAX Manager)
	// ============================================================================

	/**
	 * Logs a single user answer and updates stats.
	 */
	public static function nm_log_user_answer_activity($user_id, $mcq_id, $is_correct, $selected_answer = '')
	{
		global $wpdb;
		if (! $user_id || ! $mcq_id) {
			return false;
		}

		$table = $wpdb->prefix . 'nm_user_answers';
		$wpdb->insert(
			$table,
			array(
				'user_id'         => $user_id,
				'mcq_id'          => $mcq_id,
				'selected_answer' => $selected_answer,
				'is_correct'      => $is_correct ? 1 : 0,
				'answered_at'     => current_time('mysql'),
			),
			array('%d', '%d', '%s', '%d', '%s')
		);

		$correct = intval(get_user_meta($user_id, 'nm_total_correct', true));
		$total   = intval(get_user_meta($user_id, 'nm_total_attempts', true));

		$correct += ($is_correct ? 1 : 0);
		$total   += 1;

		update_user_meta($user_id, 'nm_total_correct', $correct);
		update_user_meta($user_id, 'nm_total_attempts', $total);

		if (class_exists('NM_Gamification')) {
			$points_to_award = $is_correct ? NM_Gamification::POINTS_PER_CORRECT : 0;
			if ($points_to_award > 0) {
				NM_Gamification::award_points($user_id, $points_to_award, 'correct_answer');
			}
		}
		return true;
	}
	/**
	 * Gets MCQ data from the database.
	 *
	 * - Unfiltered random loads (no topic, exam, month, or cognitive filter)
	 *   use the optimized nm_mcq_data table with a short transient cache.
	 * - Any request that has Topic, Exam, Difficulty, Cognitive, or Month
	 *   always goes through the standard WP_Query path (nm_get_mcqs_standard),
	 *   so all filters are applied reliably.
	 */
	public static function nm_get_mcqs($args = array())
	{

		$defaults = array(
			'count'           => 5,
			'topic'           => '',
			'exam'            => '',
			'exclude_ids'     => array(),
			'month'           => '',
			'difficulty'      => '',
			'cognitive_level' => '',
		);

		$args = wp_parse_args($args, $defaults);

		$optimizer_available = class_exists('NM_Database_Optimizer')
			&& get_option('nm_optimizer_initial_sync_done');

		$has_topic_or_exam = ! empty($args['topic']) || ! empty($args['exam']);
		$has_month_filter  = ! empty($args['month']) && $args['month'] !== 'all';
		$has_cognitive     = ! empty($args['cognitive_level']);

		// ---------------------------------------------------------------------
		// Case 1: Truly unfiltered homepage loads (only count + optional difficulty)
		// ---------------------------------------------------------------------
		// @MODIFIED: Force standard WP_Query path for consistent global ordering.
		// Bypassing optimizer to ensure "Newest/Oldest" settings work correctly.
		$can_use_homepage_cache = false;
		/* $optimizer_available
			&& empty($args['exclude_ids']) // only first homepage batch uses cached optimizer
			&& ! $has_topic_or_exam
			&& ! $has_month_filter
			&& ! $has_cognitive; */

		if ($can_use_homepage_cache) {

			// Cache key depends on a global version + count + difficulty + display order
			$version       = (int) get_option('nm_mcq_list_cache_version', 1);
			// @MODIFIED: Include display_order in cache key to avoid serving random lists when newest is requested
			$display_order = get_option('nm_mcq_display_order', 'rand');
			$cache_key     = 'nm_mcqs_opt_v' . $version . '_' . (int) $args['count'] . '_' . sanitize_key($args['difficulty']) . '_' . $display_order;
			$cached    = get_transient($cache_key);

			if ($cached !== false && is_array($cached)) {
				// Ensure cached optimizer results also use unified Topic-style cards
				return self::nm_add_card_html_to_mcqs($cached, $args['exclude_ids']);
			}

			$opt_args = array(
				'count'           => (int) $args['count'],
				'topic'           => '',
				'exam'            => '',
				'difficulty'      => $args['difficulty'],
				'cognitive_level' => '',
				'exclude_ids'     => $args['exclude_ids'],
				// @MODIFIED: Pass global display order to optimizer
				'orderby'         => ($display_order === 'date_desc') ? 'latest' : (($display_order === 'date_asc') ? 'oldest' : 'random'),
			);

			$mcqs_data = NM_Database_Optimizer::get_mcqs_optimized($opt_args);

			// Safety: fall back to standard path if optimizer misbehaves
			if (! is_array($mcqs_data) || empty($mcqs_data)) {
				$mcqs_data = self::nm_get_mcqs_standard($args);
			} else {
				// Attach unified Topic-style card HTML so optimizer results
				// look exactly like render_mcq_card() output.
				$mcqs_data = self::nm_add_card_html_to_mcqs($mcqs_data, $args['exclude_ids']);
			}

			// Cache for 60 seconds to smooth burst traffic
			if (is_array($mcqs_data) && ! empty($mcqs_data)) {
				set_transient($cache_key, $mcqs_data, 60);
			}

			return $mcqs_data;
		}

		// ---------------------------------------------------------------------
		// All filtered / dated views use the standard WP_Query path
		// ---------------------------------------------------------------------
		return self::nm_get_mcqs_standard($args);
	}

	/**
	 * Standard WP_Query to fetch MCQs.
	 * Now supports topic, exam, difficulty, and cognitive_level filters.
	 */
	public static function nm_get_mcqs_standard($args)
	{
		// @MODIFIED: Changed fallback from 'rand' to 'date_desc' as SEO guardrail
		$global_order = get_option('nm_mcq_display_order', 'date_desc');
		$orderby      = 'rand';
		$order        = 'DESC';

		if ($global_order === 'date_desc') {
			$orderby = 'date';
			$order   = 'DESC';
		} elseif ($global_order === 'date_asc') {
			$orderby = 'date';
			$order   = 'ASC';
		}

		$query_args = array(
			'post_type'      => 'mcq',
			'posts_per_page' => intval($args['count']),
			'post__not_in'   => array_map('intval', $args['exclude_ids']),
			'orderby'        => $orderby,
			'order'          => $order,
		);

		// Topic + Exam taxonomy filters
		$tax_query = array();

		if (! empty($args['topic'])) {
			$tax_query[] = array(
				'taxonomy' => 'topic',
				'field'    => 'slug',
				'terms'    => sanitize_text_field($args['topic']),
			);
		}

		if (! empty($args['exam'])) {
			// Filter by exam taxonomy (nm_exam) using the exam slug
			$tax_query[] = array(
				'taxonomy' => 'nm_exam',
				'field'    => 'slug',
				'terms'    => sanitize_text_field($args['exam']),
			);
		}

		if (! empty($args['tag'])) {
			// Filter by tag taxonomy (mcq_tag) using the tag slug
			$tax_query[] = array(
				'taxonomy' => 'mcq_tag',
				'field'    => 'slug',
				'terms'    => sanitize_text_field($args['tag']),
			);
		}

		if (! empty($tax_query)) {
			$query_args['tax_query'] = $tax_query;
		}

		// Month / date filter
		if (! empty($args['month']) && $args['month'] !== 'all') {
			$date_parts = explode('-', $args['month']);
			if (count($date_parts) === 2) {
				$query_args['date_query'] = array(
					array(
						array(
							'year'  => intval($date_parts[0]),
							'month' => intval($date_parts[1]),
						),
					),
				);
				$query_args['orderby']    = 'date';
				$query_args['order']      = 'DESC';
			}
		}

		// Difficulty / Cognitive level meta filters
		$meta_query = array();

		if (! empty($args['difficulty'])) {
			$meta_query[] = array(
				'key'   => 'mcq_difficulty',
				'value' => sanitize_key($args['difficulty']),
			);
		}

		if (! empty($args['cognitive_level'])) {
			$meta_query[] = array(
				'key'   => 'mcq_cognitive_level',
				'value' => sanitize_key($args['cognitive_level']),
			);
		}

		if (! empty($meta_query)) {
			$query_args['meta_query'] = $meta_query;
		}

		$mcqs_query = new WP_Query($query_args);
		$mcqs_data  = array();

		if ($mcqs_query->have_posts()) {
			// Prime meta cache to eliminate N+1 queries
			$post_ids = wp_list_pluck($mcqs_query->posts, 'ID');
			update_postmeta_cache($post_ids);

			// Use existing exclude_ids to keep numbering continuous (for Load More)
			$start_number = is_array($args['exclude_ids'] ?? null) ? count($args['exclude_ids']) : 0;
			$question_num = $start_number + 1;

			while ($mcqs_query->have_posts()) {
				$mcqs_query->the_post();

				$mcq_id           = get_the_ID();
				$options          = get_post_meta($mcq_id, 'mcq_options', true);
				$original_correct = get_post_meta($mcq_id, 'mcq_answer', true);
				$shuffled_data    = self::nm_randomize_answer_options($options, $original_correct);

				$question    = get_the_title();
				$answer      = $shuffled_data['answer'];
				$explanation = get_post_meta($mcq_id, 'mcq_explanation', true);
				$permalink   = self::get_mcq_permalink($mcq_id);

				// Build shared card data for unified rendering
				$card_data = array(
					'post_id'     => $mcq_id,
					'question'    => $question,
					'options'     => $shuffled_data['options'],
					'answer'      => $answer,
					'explanation' => $explanation,
					'permalink'   => $permalink,
					'author'      => get_post_meta($mcq_id, 'mcq_author_name', true),
					'difficulty'  => get_post_meta($mcq_id, 'mcq_difficulty', true),
					'factchecked' => get_post_meta($mcq_id, 'mcq_fact_checked', true),
					'published_date' => get_the_date('d M Y', $mcq_id),
					// Generic homepage/exam loads do not label topic; taxonomy pages handle that separately
					'topic_name'  => '',
				);

				$card_html = NM_Shortcode_Manager::render_mcq_card($card_data, $question_num);

				$mcqs_data[] = array(
					'id'          => $mcq_id,
					'question'    => $question,
					'options'     => $shuffled_data['options'],
					'answer'      => $answer,
					'explanation' => $explanation,
					'permalink'   => $permalink,
					// Tell frontend.js this is a fully rendered card
					'is_card'     => true,
					'html'        => $card_html,
				);

				++$question_num;
			}
			wp_reset_postdata();
		}

		return $mcqs_data;
	}
	/**
	 * Attach unified Topic-style card HTML to MCQ data arrays.
	 * Used by the optimized homepage path so it matches render_mcq_card() output.
	 */
	private static function nm_add_card_html_to_mcqs(array $mcqs_data, array $exclude_ids = array())
	{
		$start_number = count($exclude_ids);
		$question_num = $start_number + 1;
		$result       = array();

		foreach ($mcqs_data as $mcq) {

			// If this record already has a pre-rendered card, keep it as-is.
			if (! empty($mcq['is_card']) && ! empty($mcq['html'])) {
				$result[] = $mcq;
				++$question_num;
				continue;
			}

			$post_id = isset($mcq['id']) ? intval($mcq['id']) : 0;
			if (! $post_id) {
				$result[] = $mcq;
				++$question_num;
				continue;
			}

			$question    = $mcq['question'] ?? get_the_title($post_id);
			$options     = $mcq['options'] ?? array();
			$answer      = $mcq['answer'] ?? '';
			$explanation = $mcq['explanation'] ?? '';
			$permalink   = $mcq['permalink'] ?? self::get_mcq_permalink($post_id);

			$card_data = array(
				'post_id'     => $post_id,
				'question'    => $question,
				'options'     => $options,
				'answer'      => $answer,
				'explanation' => $explanation,
				'permalink'   => $permalink,
				'author'      => get_post_meta($post_id, 'mcq_author_name', true),
				'difficulty'  => get_post_meta($post_id, 'mcq_difficulty', true),
				'factchecked' => get_post_meta($post_id, 'mcq_fact_checked', true),
				'published_date' => get_the_date('d M Y', $post_id),
				'topic_name'  => $mcq['topic_name'] ?? '',
			);

			$card_html = NM_Shortcode_Manager::render_mcq_card($card_data, $question_num);

			$mcq['is_card'] = true;
			$mcq['html']    = $card_html;

			$result[] = $mcq;
			++$question_num;
		}

		return $result;
	}
	/**
	 * Register hooks that bust homepage MCQ list cache when MCQs change.
	 * Must run on every request (frontend/admin) so publishing triggers it.
	 */
	public static function register_cache_busting_hooks()
	{
		// Fire on both new publishes and updates that keep status 'publish'
		add_action('transition_post_status', array(__CLASS__, 'on_transition_post_status'), 10, 3);
	}

	/**
	 * Bump cache version when an MCQ is published/updated.
	 */
	public static function on_transition_post_status($new_status, $old_status, $post)
	{
		if (empty($post) || ! ($post instanceof WP_Post)) {
			return;
		}

		if ($post->post_type !== 'mcq') {
			return;
		}

		// Ignore autosaves/revisions
		if (wp_is_post_autosave($post->ID) || wp_is_post_revision($post->ID)) {
			return;
		}

		// Only bump when the MCQ ends up published (new publish OR update)
		if ($new_status === 'publish') {
			$v = (int) get_option('nm_mcq_list_cache_version', 1);
			update_option('nm_mcq_list_cache_version', $v + 1, false);
		}
	}

	/**
	 * Randomizes the A, B, C, D order of options.
	 */
	public static function nm_randomize_answer_options($options, $correct_answer)
	{
		$shuffled_options   = array();
		$new_correct_answer = 'A';

		if (! is_array($options) || empty($options)) {
			return array(
				'options' => $options,
				'answer'  => $correct_answer,
			);
		}

		$correct_answer_text = isset($options[$correct_answer]) ? $options[$correct_answer] : '';
		$values              = array_values($options);
		shuffle($values);

		$new_keys = array('A', 'B', 'C', 'D');

		foreach ($values as $index => $value) {
			if (isset($new_keys[$index])) {
				$shuffled_options[$new_keys[$index]] = $value;
				if ($value === $correct_answer_text) {
					$new_correct_answer = $new_keys[$index];
				}
			}
		}
		return array(
			'options' => $shuffled_options,
			'answer'  => $new_correct_answer,
		);
	}
}
