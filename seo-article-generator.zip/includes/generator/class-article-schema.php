<?php

/**
 * Article schema value object.
 *
 * Central, normalized structure for AI article data.
 *
 * @package SEO_Article_Generator
 */

namespace SEO_Article_Generator\Generator;

// Prevent direct access.
if (!defined('ABSPATH')) {
    exit;
}

use SEO_Article_Generator\Schema\Tech_Specs;
use SEO_Article_Generator\Schema\Safety_Data;
use SEO_Article_Generator\Schema\System_Reqs;
use SEO_Article_Generator\Traits\Type_Safety;


/**
 * Represents the structured article data used across the plugin.
 *
 * This class provides:
 * - A single canonical schema for article data.
 * - Normalization of AI output into a predictable structure.
 * - Conversion to array for existing consumers (Validator, Scoring_Engine, Content_Formatter).
 * - Safe section-wise merging for partial regeneration.
 */
class Article_Schema
{
    use Type_Safety;

    /**
     * Canonical Registry of all content sections.
     * Central source of truth for: keys, aliases, default headings, and anchor IDs.
     * 
     * @since 2.30.0
     */
    public const SECTION_REGISTRY = [
        'hero' => [
            'property'          => 'hero_section',
            'order'             => 10,
            'aliases'           => ['hero', 'hero_section', 'herosection'],
            'default'           => '',
            'anchor'            => 'hero',
            'merge_strategy'    => 'full',
            'validation_fields' => ['hero_section'],
            'data_attr'         => 'hero',
            'block_class'       => null,
            'legacy_class'      => null,
            'anchor_patterns'   => [],
        ],
        'introduction' => [
            'property'          => 'introduction',
            'order'             => 20,
            'aliases'           => ['introduction', 'intro'],
            'default'           => '',
            'anchor'            => 'intro',
            // @MODIFIED 2026-07-28: preserve_non_empty (soft-fail section).
            // Note: introduction property is array OR string depending on AI shape;
            // preserve_non_empty handles both.
            'merge_strategy'    => 'preserve_non_empty',
            'validation_fields' => ['introduction', 'title', 'meta_description'],
            'data_attr'         => 'introduction',
            'block_class'       => null,
            'legacy_class'      => null,
            'anchor_patterns'   => [],
        ],
        'moat' => [
            'property'          => 'moat_data',
            'order'             => 30,
            'aliases'           => ['moat', 'moat_data', 'moat_content', 'moat-content', 'moatdata'],
            'default'           => 'Quick Start & Pro Tips',
            'anchor'            => 'moat-content',
            // @MODIFIED 2026-07-28: preserve_non_empty (soft-fail section).
            // Moat data provides quick start and pro tips; non-critical but valuable content.
            'merge_strategy'    => 'preserve_non_empty',
            'validation_fields' => ['moat_data', 'software_type'],
            'data_attr'         => 'moat',
            'block_class'       => 'seo-gen-moat-content',
            'legacy_class'      => 'seo-gen-moat-steps',
            'anchor_patterns'   => [
                '/\bid="moat-content"/i',
                '/\bid="moat[^\"]*content[^\"]*"/i',
            ],
        ],
        'download' => [
            'property'          => 'download_section',
            'order'             => 40,
            'aliases'           => ['download', 'downloads', 'download_section', 'downloadsection'],
            'default'           => 'Download App',
            'anchor'            => 'download-portal',
            // @MODIFIED 2026-07-28: preserve_non_empty (soft-fail section).
            // Notes: This section MUST be mandatory. Download links are essential for user conversion.
            'merge_strategy'    => 'full',
            'validation_fields' => ['download_section'],
            'data_attr'         => 'download',
            'block_class'       => 'seo-gen-download-portal',
            'legacy_class'      => 'seo-gen-multi-platform-downloads',
            'anchor_patterns'   => [
                '/\bid="download[^"]*"/i',
            ],
        ],
        'hero' => [
            'property'          => 'hero_section',
            'order'             => 10,
            'aliases'           => ['hero', 'hero_section', 'herosection'],
            'default'           => '',
            'anchor'            => 'hero',
            // @MODIFIED 2026-07-28: preserve_non_empty (soft-fail section).
            // Notes: This section MUST be mandatory. Hero section enforces instance-specific requirements.
            'merge_strategy'    => 'full',
            'validation_fields' => ['hero_section'],
            'data_attr'         => 'hero',
            'block_class'       => null,
            'legacy_class'      => null,
            'anchor_patterns'   => [],
        ],
        'tech_specs' => [
            'property'          => 'tech_specs',
            'order'             => 50,
            'aliases'           => ['tech_specs', 'techspecs', 'technical_specs', 'technical specs', 'technicalSpecs', 'tech specs'],
            'default'           => 'Technical Specifications',
            'anchor'            => 'technical-specifications',
            // @MODIFIED 2026-07-28: preserve_non_empty (soft-fail section).
            // Tech specs vary by software; AI may omit or produce minimal content.
            'merge_strategy'    => 'preserve_non_empty',
            'validation_fields' => ['tech_specs'],
            'data_attr'         => 'tech_specs',
            'block_class'       => 'seo-gen-specs-table',
            'legacy_class'      => null,
            'anchor_patterns'   => [],
        ],
        'system_requirements' => [
            'property'          => 'system_requirements',
            'order'             => 60,
            'aliases'           => ['system_requirements', 'systemrequirements', 'system-requirements', 'system requirements', 'requirements'],
            'default'           => 'System Requirements',
            'anchor'            => 'system-requirements',
            // @MODIFIED 2026-07-28: preserve_non_empty (soft-fail section).
            'merge_strategy'    => 'preserve_non_empty',
            'validation_fields' => ['system_requirements'],
            'data_attr'         => 'system_requirements',
            'block_class'       => null,
            'legacy_class'      => null,
            'anchor_patterns'   => [
                '/\bid="system-requirements"/i',
            ],
        ],
        'features' => [
            'property'          => 'features',
            'order'             => 70,
            'aliases'           => ['features', 'key_features', 'key-features'],
            'default'           => 'Key Features',
            'anchor'            => 'key-features',
            // @MODIFIED 2026-07-28: preserve_non_empty (soft-fail section).
            'merge_strategy'    => 'preserve_non_empty',
            'validation_fields' => ['features', '_features_note'],
            'data_attr'         => 'features',
            'block_class'       => 'seo-gen-features-list',
            'legacy_class'      => null,
            'anchor_patterns'   => [
                '/\bid="key-features[^"]*"/i',
            ],
        ],
        'whats_new' => [
            'property'          => 'whats_new',
            'order'             => 80,
            'aliases'           => ['whats_new', 'whatsnew', 'whats-new', "what's_new", 'changelog'],
            'alias_prefixes'    => ['what-s-new-in-version', 'whats-new-in-version'],
            'default'           => "What's New",
            'anchor'            => 'whats-new',
            // @MODIFIED 2026-07-28: preserve_non_empty — when AI omits/returns
            // a thin whats_new the soft-fail gate lets the article proceed
            // (see class-article-generator.php partial-success gate). Merge
            // must NOT clobber the base schema's prior whats_new with [].
            'merge_strategy'    => 'preserve_non_empty',
            'validation_fields' => ['whats_new'],
            'data_attr'         => 'changelog',
            'block_class'       => 'seo-gen-whats-new-section',
            'legacy_class'      => null,
            'anchor_patterns'   => [
                '/\bid="what[s\-]*new[^"]*"/i',
            ],
        ],
        'pros_cons' => [
            'property'          => 'pros_cons',
            'order'             => 90,
            'aliases'           => ['pros_cons', 'proscons', 'pros-cons', 'pros-and-cons', 'pros_and_cons', 'strengths-and-weaknesses'],
            'default'           => 'Pros & Cons',
            'anchor'            => 'pros-cons',
            // @MODIFIED 2026-07-28: preserve_non_empty (soft-fail section).
            'merge_strategy'    => 'preserve_non_empty',
            'validation_fields' => ['pros_cons'],
            'data_attr'         => 'pros_cons',
            'block_class'       => null,
            'legacy_class'      => null,
            'anchor_patterns'   => [
                '/\bid="pros[^"]*cons[^"]*"/i',
                '/\bid="(?:strengths[^"]*weaknesses|advantages[^"]*disadvantages)[^"]*"/i',
            ],
        ],
        'installation' => [
            'property'          => 'installation_guide',
            'order'             => 100,
            'aliases'           => ['installation', 'installation_guide', 'installationguide'],
            'default'           => 'Installation Guide',
            'anchor'            => 'installation',
            // @MODIFIED 2026-07-28: preserve_non_empty (soft-fail section).
            // NOTE: 'troubleshooting' also writes to installation_guide but
            // has its own dedicated 'nested_common_issues' strategy that
            // already handles the empty case.
            'merge_strategy'    => 'preserve_non_empty',
            'validation_fields' => ['installation_guide'],
            'data_attr'         => 'installation',
            'block_class'       => 'seo-gen-accordion-block',
            'legacy_class'      => 'seo-gen-installation-guide',
            'anchor_patterns'   => [
                '/\bid="(?:installation|install[^"]*)"/i',
            ],
        ],
        'troubleshooting' => [
            'property'          => 'installation_guide',
            'order'             => 110,
            'aliases'           => ['troubleshooting'],
            'default'           => 'Troubleshooting',
            'anchor'            => 'troubleshooting',
            'merge_strategy'    => 'nested_common_issues',
            'validation_fields' => ['installation_guide.common_issues'],
            'data_attr'         => 'troubleshooting',
            'block_class'       => null,
            'legacy_class'      => null,
            'anchor_patterns'   => [
                '/\bid="troublesho[^"]*"/i',
            ],
        ],
        'video' => [
            'property'          => 'video_url',
            // @MODIFIED 2026-08-24: Moved from 120 (fixed bottom, before FAQs) to 75
            // so the Video block renders immediately AFTER the Features section
            // (order 70). Content_Formatter::to_html() pins it directly after
            // 'features' so the middle-tier shuffle cannot relocate it.
            'order'             => 75,
            'aliases'           => ['video', 'video_url', 'videourl'],
            'default'           => 'Video Tutorial',
            'anchor'            => 'video-tutorial',
            // @MODIFIED 2026-07-28: preserve_non_empty (soft-fail section).
            // Video tutorials are non-critical content that can be safely omitted.
            'merge_strategy'    => 'preserve_non_empty',
            'validation_fields' => ['video_url'],
            'data_attr'         => 'video',
            'block_class'       => null,
            'legacy_class'      => null,
            'anchor_patterns'   => [
                '/\bid="video[^"]*"/i',
            ],
        ],
        'faqs' => [
            'property'          => 'faqs',
            'order'             => 130,
            'aliases'           => ['faqs', 'faq'],
            'default'           => 'Frequently Asked Questions',
            'anchor'            => 'faq',
            // @MODIFIED 2026-07-28: preserve_non_empty (soft-fail section).
            // Notes: FAQ section now follows the same pattern as other soft-fail sections.
            // Generic questions are valuable but non-critical for user engagement.
            'merge_strategy'    => 'preserve_non_empty',
            'validation_fields' => ['faqs', '_faqs_note'],
            'data_attr'         => 'faq',
            'block_class'       => 'wp-block-rank-math-faq-block',
            'legacy_class'      => null,
            'anchor_patterns'   => [],
        ],
        'competitors' => [
            'property'          => 'competitors',
            'order'             => 140,
            'aliases'           => ['competitors', 'alternatives'],
            'default'           => 'Alternatives & Competitors',
            'anchor'            => 'competitors',
            // @MODIFIED 2026-07-28: preserve_non_empty (soft-fail section).
            'merge_strategy'    => 'preserve_non_empty',
            'validation_fields' => ['competitors', 'comparison_field_order', 'main_software_comparison'],
            'data_attr'         => 'competitors',
            'block_class'       => 'seo-gen-comparison-table-block',
            'legacy_class'      => 'seo-gen-comparison-section',
            'anchor_patterns'   => [
                '/\bid="(?:competitor|alternative|compare)[^"]*"/i',
            ],
        ],
        'related_software' => [
            'property'          => 'related_software',
            'order'             => 150,
            'aliases'           => ['related_software', 'relatedsoftware'],
            'default'           => 'You May Also Like',
            'anchor'            => 'related',
            // @MODIFIED 2026-07-28: preserve_non_empty (soft-fail section).
            'merge_strategy'    => 'preserve_non_empty',
            'validation_fields' => ['related_software'],
            'data_attr'         => 'related_software',
            'block_class'       => null,
            'legacy_class'      => null,
            'anchor_patterns'   => [],
        ],
    ];

    // Whitelist of sections allowed to be overridden via partial regeneration
    // is now derived dynamically from SECTION_REGISTRY.


    /** @var string */
    public $title = '';

    /** @var string */
    public $meta_description = '';

    /** @var string */
    public $slug = '';

    /** @var string */
    public $focus_keyword = '';

    /** @var array */
    public $long_tail_keywords = array();

    /** @var array */
    public $keyword_variations = array();

    /** @var array */
    public $introduction = array();

    /** @var Tech_Specs */
    public $tech_specs;

    /** @var Safety_Data */
    public $safety;

    /** @var string */
    public $category = '';

    /** @var array */
    public $pros_cons = array();

    /** @var array */
    public $download_section = array();

    /** @var string */
    public $video_url = '';

    /** @var array */
    public $features = array();

    /** @var array */
    public $whats_new = array();

    /** @var System_Reqs */
    public $system_requirements;

    /** @var array */
    public $installation_guide = array();

    /** @var array */
    public $faqs = array();

    /** @var array */
    public $competitors = array();

    /** @var array */
    public $tags = array();

    /** @var array */
    public $related_software = array();

    /** @var array */
    public $hero_section = array();

    // @MODIFIED 2025-12-15 v2.1.0: Moat content for strategic differentiation
    /** @var string|null Software type classification (COMPLEX_ENGINE|SIMPLE_UTILITY) */
    public $software_type = null;

    /** @var array Moat content data (settings recipes or quick start guides) */
    public $moat_data = array();

    /**
     * Raw HTML content (post‑formatted).
     *
     * This is populated after Content_Formatter runs and is used by Validator/Scoring_Engine.
     *
     * @var string
     */
    public $html_content = '';

    /**
     * Optional editor rating (1–5).
     *
     * @var float
     */
    public $editor_rating = 0.0;

    /**
     * Grounding truth content from the source page.
     * Used for hallucination detection and data validation.
     *
     * @var string
     */
    public $primary_text = '';

    /**
     * Optional rating count (e.g. 2300 for "2.3k").
     * @var int
     */
    public $rating_count = 0;

    /**
     * Arbitrary extra data for forward compatibility.
     *
     * @var array
     */
    public $extra = array();

    public function get($section)
    {
        return $this->get_section_payload((string) $section);
    }

    public static function get_ordered_section_keys(): array
    {
        $keys = array_keys(self::SECTION_REGISTRY);

        usort(
            $keys,
            static function ($a, $b) {
                $oa = self::SECTION_REGISTRY[$a]['order'] ?? 1000;
                $ob = self::SECTION_REGISTRY[$b]['order'] ?? 1000;

                if ($oa === $ob) {
                    return strcmp($a, $b);
                }

                return $oa <=> $ob;
            }
        );

        return $keys;
    }

    public static function normalize_sections(array $sections, array $passthrough = []): array
    {
        $normalized = [];
        $allowedPassthrough = [];

        foreach ($passthrough as $value) {
            if (!is_string($value)) {
                continue;
            }

            $value = strtolower(trim($value));
            if ($value !== '') {
                $allowedPassthrough[] = $value;
            }
        }

        foreach ($sections as $section) {
            if (!is_string($section)) {
                continue;
            }

            $section = strtolower(trim($section));
            if ($section === '') {
                continue;
            }

            if (in_array($section, $allowedPassthrough, true)) {
                $normalized[] = $section;
                continue;
            }

            $canonical = self::get_canonical_key($section);
            if ($canonical !== null) {
                $normalized[] = $canonical;
            }
        }

        return array_values(array_unique($normalized));
    }

    public static function get_validation_field_list(array $sections): array
    {
        $fields = [];

        foreach ($sections as $section) {
            $fields = array_merge($fields, self::get_validation_fields((string) $section));
        }

        return array_values(array_unique($fields));
    }

    public static function remove_field_path(array &$data, string $field_path): void
    {
        if ($field_path === '') {
            return;
        }

        if (strpos($field_path, '.') === false) {
            unset($data[$field_path]);
            return;
        }

        $segments = explode('.', $field_path);
        $last     = array_pop($segments);
        $cursor   =& $data;

        foreach ($segments as $segment) {
            if (!isset($cursor[$segment]) || !is_array($cursor[$segment])) {
                return;
            }
            $cursor =& $cursor[$segment];
        }

        unset($cursor[$last]);
    }

    public function get_section_payload(string $section)
    {
        $key = self::get_canonical_key($section);

        if (!$key) {
            return $this->extra[$section] ?? null;
        }

        switch ($key) {
            case 'troubleshooting':
                return (is_array($this->installation_guide) && isset($this->installation_guide['common_issues']) && is_array($this->installation_guide['common_issues']))
                    ? $this->installation_guide['common_issues']
                    : [];

            default:
                $property = self::SECTION_REGISTRY[$key]['property'] ?? null;

                if ($property && property_exists($this, $property)) {
                    return $this->{$property};
                }

                return $this->extra[$section] ?? null;
        }
    }

    /**
     * Get the canonical version from tech_specs (Single Source of Truth).
     *
     * @since 2.38.0
     * @return string Canonical version string.
     */
    public function get_canonical_version(): string
    {
        return $this->tech_specs->version ?? $this->version ?? '';
    }

	/**
	 * Get the canonical key for a section name or alias.
	 * 
	 * @param string $name Section name or alias.
	 * @return string|null Canonical key.
	 */
	public static function get_canonical_key(string $name): ?string {
		$name = strtolower(trim($name));

		if ($name === '') {
			return null;
		}

		if (isset(self::SECTION_REGISTRY[$name])) {
			return $name;
		}

		$normalized = str_replace([' ', '_'], '-', $name);

		foreach (self::SECTION_REGISTRY as $key => $config) {
			$candidates = array_merge([$key], (array) ($config['aliases'] ?? []));

			foreach ($candidates as $candidate) {
				if (!is_string($candidate)) {
					continue;
				}

				$candidate = strtolower(trim($candidate));
				if ($candidate === '') {
					continue;
				}

				if ($name === $candidate) {
					return $key;
				}

				if ($normalized === str_replace([' ', '_'], '-', $candidate)) {
					return $key;
				}
			}

			foreach ((array) ($config['alias_prefixes'] ?? []) as $prefix) {
				if (!is_string($prefix)) {
					continue;
				}

				$prefix = strtolower(trim($prefix));
				if ($prefix === '') {
					continue;
				}

				$prefix = str_replace([' ', '_'], '-', $prefix);

				if (strpos($normalized, $prefix) === 0) {
					return $key;
				}
			}
		}

		return null;
	}

	/**
	 * Get the alias map (alias -> canonical key).
	 * 
	 * @return array Alias map.
	 */
	public static function get_alias_map(): array {
		$map = [];

		foreach (self::SECTION_REGISTRY as $key => $config) {
			$candidates = array_merge([$key], (array) ($config['aliases'] ?? []));

			foreach ($candidates as $candidate) {
				if (!is_string($candidate)) {
					continue;
				}

				$candidate = strtolower(trim($candidate));
				if ($candidate === '') {
					continue;
				}

				$map[$candidate] = $key;
				$map[str_replace([' ', '_'], '-', $candidate)] = $key;
			}
		}

		return $map;
	}

	/**
	 * Canonicalize the `seo-gen/hero` block comment in $html to the parser-safe form.
	 *
	 * Why this exists:
	 *  - WP core's `parse_blocks()` and Gutenberg JS's default parser are strict:
	 *    they only accept `<!-- wp:seo-gen/hero /-->` (no whitespace between `/` and `-->`).
	 *    A space variant `<!-- wp:seo-gen/hero / -->` demotes the block to a freeform
	 *    `null` block, after which wpautop wraps it in `<p>…</p>` and the hero block
	 *    disappears from the editor and the frontend.
	 *  - WP core's `serialize_blocks()` already emits the canonical form for self-closing
	 *    blocks, but legacy DB rows, third-party imports, and Gutenberg JS round-trips
	 *    can still leave the space form or a `<p>`-wrapped form in post_content.
	 *  - Surgical_Patcher (update path), Publish_Payload_Builder (publish boundary),
	 *    and Content_Formatter (new-post path) all need the same normalization at the
	 *    same logical points. This helper is the single source of truth so they cannot
	 *    drift again.
	 *
	 * Two regexes are applied, in this order:
	 *  1. Strip a surrounding `<p>…</p>` wrapper (whitespace-tolerant).
	 *  2. Collapse any `<!-- wp:seo-gen/hero … -->` variant (with or without a space
	 *     between `/` and `-->`) to the exact canonical form.
	 *
	 * The function is idempotent: running it on already-canonical content is a no-op.
	 *
	 * @since 2.34.0
	 * @param string $html Post content (or any HTML fragment) to canonicalize.
	 * @return string $html with the hero block comment in canonical form.
	 */
	public static function canonicalize_hero_block_comment( string $html ): string {
		if ( $html === '' || strpos( $html, 'wp:seo-gen/hero' ) === false ) {
			return $html;
		}

		// Pass 1: strip a <p>…</p> wrapper around the hero comment.
		$html = preg_replace(
			'~<p>\s*<!--\s*wp:seo-gen/hero\s*/?\s*-->\s*</p>~i',
			'<!-- wp:seo-gen/hero /-->',
			$html
		);

		// Pass 2: collapse any space-slash variant to the canonical no-space form.
		$html = preg_replace(
			'~<!--\s+wp:seo-gen/hero\s*/?\s*-->~i',
			'<!-- wp:seo-gen/hero /-->',
			$html
		);

		return $html;
	}

	/**
	 * Get the marker specs for all zones.
	 * 
	 * @return array Marker specs.
	 */
	public static function get_marker_specs(): array {
		$specs = [];

		foreach (self::SECTION_REGISTRY as $key => $config) {
			$specs[$key] = [
				'data_attr'          => $config['data_attr'] ?? null,
				'block_class'        => $config['block_class'] ?? null,
				'legacy_class'       => $config['legacy_class'] ?? null,
				'anchor_id'          => $config['anchor'] ?? null,
				'anchor_id_patterns' => (array) ($config['anchor_patterns'] ?? []),
			];
		}

		return $specs;
	}

	/**
	 * Get the storage property name for a canonical key or alias.
	 */
	public static function get_storage_property(string $section): ?string {
		$key = self::get_canonical_key($section);
		return $key ? self::SECTION_REGISTRY[$key]['property'] : null;
	}

	/**
	 * Get the default heading for a canonical key or alias.
	 */
	public static function get_default_heading(string $section): string {
		$key = self::get_canonical_key($section);
		return $key ? self::SECTION_REGISTRY[$key]['default'] : '';
	}

	/**
	 * Get validation fields associated with a canonical key or alias.
	 * 
	 * @param string $section Section key or alias.
	 * @return array Validation fields.
	 */
	public static function get_validation_fields(string $section): array {
		$key = self::get_canonical_key($section);
		return $key ? (self::SECTION_REGISTRY[$key]['validation_fields'] ?? [$key]) : [];
	}

	/**
	 * Get the anchor ID for a canonical key or alias.
	 */
	public static function get_anchor(string $section): string {
		$key = self::get_canonical_key($section);
		return $key ? self::SECTION_REGISTRY[$key]['anchor'] : '';
	}

	public static function get_zone_alias_map(): array
	{
		return self::get_alias_map();
	}

	public static function get_zone_marker_specs(): array
	{
		return self::get_marker_specs();
	}

    /**
     * Article_Schema constructor.
     *
     * @param array $data Normalized article data.
     */
    public function __construct($data = array())
    {
        $data = self::normalize_contract(is_array($data) ? $data : array());
        // @MODIFIED 2025-12-11 v1.6.1: Data Integrity - Strict scalar type checks
        // Prevents "Array" string conversion issues.
        $this->title = isset($data['title']) ? self::as_string($data['title']) : '';
        $this->meta_description = isset($data['meta_description']) ? self::as_string($data['meta_description']) : '';
        $this->slug = isset($data['slug']) ? self::as_string($data['slug']) : '';
        $this->focus_keyword = isset($data['focus_keyword']) ? self::as_string($data['focus_keyword']) : '';

        $this->long_tail_keywords = self::ensure_array($data, 'long_tail_keywords');
        $this->keyword_variations = self::ensure_array($data, 'keyword_variations');
        $this->introduction = self::ensure_array($data, 'introduction');

        // Hydrate DTOs
        $this->tech_specs = Tech_Specs::from_array(isset($data['tech_specs']) ? $data['tech_specs'] : []);
        $this->system_requirements = System_Reqs::from_array(isset($data['system_requirements']) ? $data['system_requirements'] : []);
        $this->safety = Safety_Data::from_array(isset($data['safety']) ? $data['safety'] : []);

        // Promoted fields
        $this->category = isset($data['category']) ? self::as_string($data['category']) : '';

        $this->pros_cons = self::ensure_array($data, 'pros_cons');
        $this->download_section = self::ensure_array($data, 'download_section');
        $this->video_url = isset($data['video_url']) ? self::as_string($data['video_url']) : '';
        $this->features = self::ensure_array($data, 'features');
        $this->whats_new = self::ensure_array($data, 'whats_new');
        $this->installation_guide = self::ensure_array($data, 'installation_guide');
        $this->faqs = self::ensure_array($data, 'faqs');
        $this->competitors = self::ensure_array($data, 'competitors');
        $this->tags = self::ensure_array($data, 'tags');
        $this->related_software = self::ensure_array($data, 'related_software');
        $this->hero_section = self::ensure_array($data, 'hero_section');
        $this->html_content = isset($data['html_content']) ? self::as_string($data['html_content']) : '';

        // @MODIFIED 2025-12-15 v2.1.0: Moat content fields
        $this->software_type = isset($data['software_type']) ? self::as_string($data['software_type']) : null;
        $this->moat_data = self::ensure_array($data, 'moat_data');

        // Editor rating is optional and may come from input or AI.
        // Ensure float cast doesn't fail on arrays/objects
        if (isset($data['editor_rating']) && is_numeric($data['editor_rating'])) {
            $this->editor_rating = (float) $data['editor_rating'];
        }
        $this->rating_count        = isset($data['rating_count']) ? (int)$data['rating_count'] : 0;
        $this->primary_text        = isset($data['primary_text']) ? self::as_string($data['primary_text']) : '';


        $this->extra = array();
        $known_keys  = array(
            'title',
            'meta_description',
            'slug',
            'focus_keyword',
            'long_tail_keywords',
            'keyword_variations',
            'introduction',
            'category',
            'tags',
            'html_content',
            'editor_rating',
            'rating_count',
            'primary_text',
        );

        // Add all storage properties from registry
        foreach (self::SECTION_REGISTRY as $config) {
            $known_keys[] = $config['property'];
        }
        $known_keys = array_unique($known_keys);

        foreach ($data as $key => $value) {
            if (!in_array($key, $known_keys, true)) {
                $this->extra[$key] = $value;
            }
        }
    }

    /**
     * Create schema from raw AI array (already decoded JSON).
     *
     * @param array $data Raw AI array.
     * @return Article_Schema
     * @throws \InvalidArgumentException If data is not an array.
     */
    public static function from_ai_array($data)
    {
        // @MODIFIED 2025-12-11 v1.6.1: Hard Failure on invalid input
        if (!is_array($data)) {
            // Throw exception to fail loudly instead of silently creating empty posts.
            // Caller must catch or let it bubble to global error handler.
            throw new \InvalidArgumentException('Article_Schema::from_ai_array expected array, received ' . gettype($data));
        }

        // @MODIFIED 2025-12-11 v1.6.2: Safety verification moved to Validator (clean separation)
        $data = self::normalize($data);

        return new self($data);
    }

    /**
     * Create schema from generic array (e.g. DB output_data).
     *
     * @param array $data Raw array.
     * @return Article_Schema
     */
    public static function from_array($data)
    {
        if (!is_array($data)) {
            $data = array();
        }

        // @MODIFIED 2025-12-11 v1.6.2: Unify normalization path with from_ai_array
        // Ensures DB-loaded schemas have identical structure to AI-loaded ones.
        $data = self::normalize($data);

        return new self($data);
    }

    /**
     * Export schema to array compatible with existing consumers.
     *
     * @return array
     */
    public function to_array()
    {
        $data = array(
            'title' => $this->title,
            'meta_description' => $this->meta_description,
            'slug' => $this->slug,
            'focus_keyword' => $this->focus_keyword,

            'long_tail_keywords' => $this->long_tail_keywords,
            'keyword_variations' => $this->keyword_variations,
            'introduction' => $this->introduction,

            // Serialize DTOs
            'tech_specs' => $this->tech_specs->to_array(),
            'system_requirements' => $this->system_requirements->to_array(),
            'safety' => $this->safety->to_array(),
            'category' => $this->category,

            'pros_cons' => $this->pros_cons,
            'download_section' => $this->download_section,
            'video_url' => $this->video_url,
            'features' => $this->features,
            'whats_new' => $this->whats_new,
            'installation_guide' => $this->installation_guide,
            'faqs' => $this->faqs,
            'competitors' => $this->competitors,
            'tags' => $this->tags,
            'related_software' => $this->related_software,
            'hero_section' => $this->hero_section,
            'html_content' => $this->html_content,

            // @MODIFIED 2025-12-11 v1.6.1: Always output editor_rating to prevent data loss
            'editor_rating' => $this->editor_rating,

            // @MODIFIED 2025-12-15 v2.1.0: Moat content export
            'software_type' => $this->software_type,
            'moat_data' => $this->moat_data,
        );

        // Merge extra fields back in
        // Policy: Schema properties are Single Source of Truth.
        // If extra has a key that conflicts with Schema, Schema wins.
        // If extra has a key that is NOT in Schema, it is preserved.
        foreach ($this->extra as $key => $value) {
            if (!array_key_exists($key, $data)) {
                $data[$key] = $value;
            }
        }

        return $data;
    }

    /**
     * Merge sections from another schema into this one for partial regeneration.
     *
     * @param Article_Schema $source   Schema to take updated sections from.
     * @param array          $sections Section names to replace.
     * @return void
     */
    public function apply_section_overrides(Article_Schema $source, $sections)
    {
        if (!is_array($sections) || empty($sections)) {
            return;
        }

        foreach ($sections as $section) {
			$key = self::get_canonical_key($section);
			
            // Whitelist Check: If it's not in the registry, we don't allow partial overrides
            if (! $key) {
                // Also allow some special internal keys if needed, but registry is the goal
                if ($section === 'comparison_field_order' || $section === 'main_software_comparison') {
					$this->extra[$section] = $source->extra[$section] ?? null;
				}
                continue;
            }

            $property = self::SECTION_REGISTRY[$key]['property'];
            $strategy = self::SECTION_REGISTRY[$key]['merge_strategy'] ?? 'full';

            if (property_exists($this, $property)) {
                switch ($strategy) {
				case 'nested_moat':
					// FIXED 2026-04-30: Merge ALL source content items, not just [0].
					// An empty $source->moat_data means moat was NOT regenerated this pass —
					// preserve the base schema's moat unconditionally.
					if (!empty($source->moat_data)) {
						if (!empty($source->moat_data['content']) && !empty($this->moat_data['content'])) {
							// Merge all source items, capped at 3 to respect 1-3 target max
							$max_moat = 3;
							$this->moat_data['content'] = array_values(
								array_merge(
									array_slice($this->moat_data['content'], 0, $max_moat),
									array_slice($source->moat_data['content'], 0, $max_moat - count($this->moat_data['content']))
								)
							);
							if (!empty($source->software_type)) {
								$this->software_type = $source->software_type;
							}
						} else {
							// Full replace only when source has actual content
							$this->moat_data    = $source->moat_data;
							$this->software_type = $source->software_type;
						}
					}
					// If $source->moat_data is empty, $this->moat_data is preserved as-is.
					break;

					case 'nested_tech_specs':
						$base_data = $this->to_array();
						$base_specs = isset($base_data['tech_specs']) && is_array($base_data['tech_specs'])
							? $base_data['tech_specs']
							: array();

						$incoming_specs = is_object($source->tech_specs) && method_exists($source->tech_specs, 'to_array')
							? $source->tech_specs->to_array()
							: array();

						$base_data['tech_specs'] = self::merge_assoc_preserving_non_empty($base_specs, $incoming_specs);

						$this->replace_with_normalized_array($base_data);
						break;

                    case 'nested_common_issues':
                        // specialized merge for troubleshooting zone (part of installation_guide property)
                        if (isset($source->installation_guide['common_issues'])) {
                            if (!is_array($this->installation_guide)) {
                                $this->installation_guide = [];
                            }
                            $this->installation_guide['common_issues'] = $source->installation_guide['common_issues'];
                        }
                        break;

                    // @MODIFIED 2026-07-28: preserve_non_empty merge strategy.
                    // Mirrors the gate contract in class-article-generator.php
                    // (L1829-1891): SOFT-fail sections (whats_new, features,
                    // pros_cons, installation, faqs, related_software, etc.)
                    // may proceed with thin/empty AI content. In that case,
                    // merged_clone() MUST NOT clobber the base schema's
                    // existing value with the empty source value, otherwise
                    // the publish would silently delete prior section content.
                    // Strategy: overwrite $this->$property ONLY when $source
                    // value is non-empty (passes array_has_meaningful_content
                    // for arrays, or is a non-empty string for scalars).
                    // Falls through to no-op (preserves base) when source is
                    // empty/thin. For nested_moat/nested_tech_specs/nested_common_issues
                    // sections this strategy is NOT used — those have their
                    // own dedicated logic that already handles the empty case.
                    //
                    // @MODIFIED 2026-07-28 (audit): also handles DTO objects
                    // (system_requirements, tech_specs[via nested_tech_specs],
                    // safety). Calls to_array() if the incoming value exposes
                    // that method, then checks for meaningful content.
                    case 'preserve_non_empty':
                        $incoming = $source->{$property};
                        // @MODIFIED 2026-07-28 (audit): DTO unwrap. system_requirements
                        // and safety are DTOs, not arrays. Without this guard, the
                        // is_array() check below would always be false and the
                        // `!== null && !== ''` fall-through would unconditionally
                        // overwrite the base DTO with AI's (possibly thin) DTO.
                        if (is_object($incoming) && method_exists($incoming, 'to_array')) {
                            $incoming = $incoming->to_array();
                        }
                        if (is_array($incoming)) {
                            if (!empty($incoming) && self::array_has_meaningful_content_for_merge($incoming)) {
                                $this->{$property} = $source->{$property};
                            }
                            // else: keep $this->{$property} (base preserved)
                        } elseif (is_string($incoming)) {
                            if (strlen(trim($incoming)) >= 10) {
                                $this->{$property} = $source->{$property};
                            }
                            // else: keep base
                        } elseif (is_numeric($incoming) && (float) $incoming !== 0.0) {
                            $this->{$property} = $source->{$property};
                        }
                        // else: null/empty/bool(false) — keep base
                        break;

                    case 'full':
                    default:
						$this->$property = $source->$property;
						break;
				}
            } elseif (array_key_exists($section, $source->extra)) {
                $this->extra[$section] = $source->extra[$section];
            }
        }
    }

	private static function merge_assoc_preserving_non_empty(array $base, array $incoming): array
	{
		foreach ($incoming as $key => $value) {
			if (is_array($value)) {
				$base[$key] = self::merge_assoc_preserving_non_empty(
					isset($base[$key]) && is_array($base[$key]) ? $base[$key] : array(),
					$value
				);
				continue;
			}

			if ($value === null) {
				continue;
			}

			if (is_string($value) && trim($value) === '') {
				continue;
			}

			$base[$key] = $value;
		}

		return $base;
	}

	private function replace_with_normalized_array(array $data): void
	{
		$reloaded = self::from_array($data);

		foreach (get_object_vars($reloaded) as $prop => $value) {
			$this->{$prop} = $value;
		}
	}

	/**
	 * Recursively check if an array contains meaningful content.
	 *
	 * Mirrors Article_Generator::array_has_meaningful_content() (private),
	 * exposed here so apply_section_overrides() can determine whether to
	 * honor or ignore an incoming section value under the
	 * 'preserve_non_empty' merge strategy.
	 *
	 * @since 2.37.0
	 * @param array $array The array to inspect.
	 * @return bool True if any nested value is a non-empty string (>=3 chars),
	 *              a non-empty numeric, or a non-empty array with content.
	 */
	public static function array_has_meaningful_content_for_merge(array $array): bool {
		if (empty($array)) {
			return false;
		}
		foreach ($array as $value) {
			if (is_string($value) && strlen(trim($value)) >= 3) {
				return true;
			}
			if (is_array($value) && self::array_has_meaningful_content_for_merge($value)) {
				return true;
			}
			if (is_numeric($value) && (float) $value !== 0.0 && (string) $value !== '') {
				return true;
			}
		}
		return false;
	}

    /**
     * Sync platform metadata with actual download links.
     * Prevents drift between SEO title/hero and the resolved links.
     * 
     * @since 2.19.0
     */
    public function sync_platforms(): void
    {
        if (empty($this->download_section['links'])) {
            return;
        }

        $detected_platforms = array();
        foreach ($this->download_section['links'] as $link) {
            if (!empty($link['platform'])) {
                $detected_platforms[] = $link['platform'];
            }
        }

        if (!empty($detected_platforms)) {
            $this->tech_specs->os_support = implode(', ', array_unique($detected_platforms));
        }
    }

    /**
     * Static helper to produce a merged clone without mutating originals.
     *
     * @param Article_Schema $base     Base schema.
     * @param Article_Schema $override Schema with updated sections.
     * @param array          $sections Sections to replace (see apply_section_overrides).
     * @return Article_Schema
     */
    public static function merged_clone(Article_Schema $base, Article_Schema $override, $sections)
    {
        // Clone via array roundtrip to avoid reference issues.
        $new = new self($base->to_array());
        $new->apply_section_overrides($override, $sections);

        // Preserve extra fields from override that are not in base (e.g., _canonical_download_links).
        // These are critical for downstream consumers like buildHeroMetaInput.
        foreach ($override->extra as $key => $value) {
            if (!isset($new->extra[$key])) {
                $new->extra[$key] = $value;
            }
        }

        return $new;
    }

    /**
     * Normalize data structure.
     * Centralized repair logic for AI and DB paths.
     *
     * @MODIFIED 2025-12-11 v1.6.2: Renamed from normalize_ai_data. Used by both from_ai_array and from_array.
     * @param array $data
     * @return array
     */
    private static function normalize($data)
    {
        // [PERSIST-FIX] Strip debug/validation-only keys before any persistence
        // path. _validation and _debug are runtime-only diagnostics from
        // Article_Generator::generate() and must never reach the snapshot
        // meta (seogenherodata / _seo_gen_article_snapshot). Without this
        // strip, every post snapshot carries 2-20KB of debug payload that
        // bloats wp_postmeta and confuses downstream readers.
        unset(
            $data['_validation'],
            $data['_debug'],
            $data['_actual_provider'],
            $data['_actual_model']
        );

        // Coerce SEO string fields — AI sometimes wraps these in arrays
        if (isset($data['focus_keyword']) && !is_string($data['focus_keyword'])) {
            if (is_array($data['focus_keyword']) && !empty($data['focus_keyword'])) {
                $data['focus_keyword'] = (string) reset($data['focus_keyword']);
            } else {
                $data['focus_keyword'] = is_scalar($data['focus_keyword']) ? (string) $data['focus_keyword'] : '';
            }
        }

        if (isset($data['meta_description']) && !is_string($data['meta_description'])) {
            if (is_array($data['meta_description']) && !empty($data['meta_description'])) {
                $data['meta_description'] = (string) reset($data['meta_description']);
            } else {
                $data['meta_description'] = is_scalar($data['meta_description']) ? (string) $data['meta_description'] : '';
            }
        }

        // Basic normalization for nested structures that AI might omit.
        if (!isset($data['tech_specs']) || !is_array($data['tech_specs'])) {
            $data['tech_specs'] = array();
        }

        // @MODIFIED 2025-12-17 v2.4.4: Sync fields between root and tech_specs
        // @MODIFIED 2025-12-19: Expanded sync for all hero fields and category
        $field_fallbacks = ['software_name', 'version', 'license', 'file_size', 'developer', 'publisher', 'homepage', 'changelogurl', 'category'];
        foreach ($field_fallbacks as $field) {
            // Root -> Tech Specs
            if ((empty($data['tech_specs'][$field]) || $data['tech_specs'][$field] === '') && !empty($data[$field])) {
                $data['tech_specs'][$field] = $data[$field];
            }
            // Tech Specs -> Root
            if ((empty($data[$field]) || $data[$field] === '') && !empty($data['tech_specs'][$field])) {
                $data[$field] = $data['tech_specs'][$field];
            }
        }

// @MODIFIED 2026-05-21: CRITICAL FIX - Prevent data loss in bidirectional sync
	// This ensures AI-generated presentation data is honored by Hero_Data_Provider
	// @MODIFIED 2026-04-19: Added 'category' to hero_overrides to prevent fallback to 'Windows'
	$hero_overrides = ['license_details', 'security_badge', 'rating', 'logo_url', 'author_name', 'last_verified_date', 'category'];
	foreach ($hero_overrides as $field) {
		if (!isset($data['hero_section']) || !is_array($data['hero_section'])) {
			$data['hero_section'] = array();
		}
		
		// CRITICAL FIX: Only sync root -> hero_section if hero_section is empty for this field
		// Prevents data loss when both have data
		if (!empty($data[$field]) && empty($data['hero_section'][$field])) {
			$data['hero_section'][$field] = $data[$field];
		}
		
		// CRITICAL FIX: Only sync hero_section -> root if root is empty for this field
		// Prevents overwriting valid root data with hero_section data
		if (empty($data[$field]) && !empty($data['hero_section'][$field])) {
			$data[$field] = $data['hero_section'][$field];
		}
	}

        // Also populate title from software_name if title is missing
        if (empty($data['title']) && !empty($data['tech_specs']['software_name'])) {
            $data['title'] = $data['tech_specs']['software_name'];
        }

        if (!isset($data['system_requirements']) || !is_array($data['system_requirements'])) {
            $data['system_requirements'] = array();
        }

        if (!isset($data['safety']) || !is_array($data['safety'])) {
            $data['safety'] = array();
        }

        if (!isset($data['pros_cons']) || !is_array($data['pros_cons'])) {
            $data['pros_cons'] = array(
                'pros' => array(),
                'cons' => array(),
            );
        } else {
            if (!isset($data['pros_cons']['pros']) || !is_array($data['pros_cons']['pros'])) {
                $data['pros_cons']['pros'] = array();
            }
            if (!isset($data['pros_cons']['cons']) || !is_array($data['pros_cons']['cons'])) {
                $data['pros_cons']['cons'] = array();
            }
        }

        if (!isset($data['download_section']) || !is_array($data['download_section'])) {
            $data['download_section'] = array();
        }
        if (!isset($data['download_section']['links']) || !is_array($data['download_section']['links'])) {
            $data['download_section']['links'] = array();
        }

        if (!isset($data['installation_guide']) || !is_array($data['installation_guide'])) {
            $data['installation_guide'] = array();
        }

        // @MODIFIED 2025-12-14 v2.0.4: Migration fallback for legacy file_hash placement
        // Older jobs wrote hash to tech_specs only, but Portal validation checks safety.file_hash.
        // Copy from tech_specs to safety if safety is missing the hash.
        if (empty($data['safety']['file_hash']) && !empty($data['tech_specs']['file_hash'])) {
            $data['safety']['file_hash'] = $data['tech_specs']['file_hash'];
        }

        // @MODIFIED 2025-12-15 v2.1.0: Moat content normalization
        if (!isset($data['software_type'])) {
            $data['software_type'] = null;
        }
        if (!isset($data['moat_data']) || !is_array($data['moat_data'])) {
            $data['moat_data'] = array();
        }
        // Ensure moat_data.content is array
        if (isset($data['moat_data']['content']) && !is_array($data['moat_data']['content'])) {
            $data['moat_data']['content'] = array();
        }

        // @REMOVED 2026-08-26 [DATA-PRESERVE]: SIMPLE_UTILITY no longer force-empties
        // moat_data/faqs here. normalize() runs on EVERY Article_Schema construction,
        // including Schema_Sync_Service::load_schema(). Once software_type was persisted
        // to _seo_gen_article_snapshot by any past run, this block silently wiped the
        // stored faqs/moat_data on every load: it corrupted the canonical snapshot,
        // destroyed merged_clone()'s preservation base in Publish_Payload_Builder (so
        // unregenerated sections could never be inherited again), and removed Rank Math
        // FAQ schema output. The fresh-payload equivalent now lives exclusively at
        // generation time (class-article-generator.php, SIMPLE_UTILITY exclusion block),
        // where wiping is safe because nothing has been persisted yet.

        return $data;
    }

    /**
     * Generate hero section data from strictly typed properties.
     * Use this to enforce Single Source of Truth.
     *
     * @return array Hero section data.
     */
    public function generate_hero_data()
    {
        // Use Tech_Specs DTO
        $geo_tech = $this->tech_specs; // It is a Tech_Specs object

        $rating_count = 0;
        $rating_avg   = 0.0;
        global $post;
        $post_id = isset($post->ID) ? $post->ID : 0;
        if ($post_id && class_exists('SEO_Article_Generator\\Frontend\\Rating_System')) {
            $rating_data  = \SEO_Article_Generator\Frontend\Rating_System::get_rating_data($post_id);
            $rating_count = $rating_data['count'];
            $rating_avg   = $rating_data['average'];
        }

        $hero_data = array(
            'software_name' => $geo_tech->software_name ?: $this->title, // Fallback
            'version' => $geo_tech->version,
            'license' => $geo_tech->license ?: 'Free',
            'license_details' => '', // Not in Tech Specs DTO yet, keep empty or map from extra
            'file_size' => $geo_tech->file_size,
            // @since 2.30.0: Prioritize editor rating, fallback to user average
		'rating' => $this->editor_rating > 0 ? $this->editor_rating : ($rating_avg > 0 ? $rating_avg : 0),
            'rating_count' => $rating_count,
            // @MODIFIED 2025-12-15 v2.2.0: Neutral default - security claims require evidence
            'security_badge' => 'Download Available',
            'download_links' => array(),
        );

        // @MODIFIED 2025-12-15 v2.2.0: Evidence-based security badge (Google E-E-A-T compliance)
        // Only upgrade from neutral default if safety data supports the claim
        if ($this->safety && $this->safety->verified_download && !empty($this->safety->file_hash)) {
            $hero_data['security_badge'] = '✓ Verified & Secure';
        } elseif ($this->safety && $this->safety->verified_download) {
            $hero_data['security_badge'] = '✓ Publisher Verified';
        }
        // Otherwise stays as 'Download Available' (neutral, honest default)

        // Map Download Section links
        if (!empty($this->download_section['links']) && is_array($this->download_section['links'])) {
            $primary_found = false;

            foreach ($this->download_section['links'] as $index => $link) {
                if (empty($link['platform']) || empty($link['url'])) {
                    continue;
                }

                // Mark first link as primary if none specified
                $is_primary = isset($link['is_primary']) ? $link['is_primary'] : (!$primary_found && $index === 0);

                if ($is_primary) {
                    $primary_found = true;
                }

		$hero_data['download_links'][] = array(
					'platform' => $link['platform'],
					'url' => $link['url'],
					'variant' => isset($link['variant']) ? $link['variant'] : '',
					'file_type' => isset($link['file_type']) ? $link['file_type'] : '',
					'version' => isset($link['version']) ? $link['version'] : '',
					'channel' => isset($link['channel']) ? $link['channel'] : '',
					'text' => isset($link['text']) ? $link['text'] : '',
					'is_primary' => $is_primary,
				);
            }
        }

        return $hero_data;
    }



    /**
     * Ensure a key in an array is returned as an array.
     *
     * @param array  $source Source array.
     * @param string $key    Key name.
     * @return array
     */
    /**
     * Apply factual overrides from Hero Meta Box back to the schema snapshot.
     *
     * @since 2.8.5
     * @param array $overrides Factual data overrides.
     */
	public function apply_hero_overrides(array $overrides): void
	{
		// 1. Software Name
		if (!empty($overrides['software_name'])) {
			$this->title = $overrides['software_name'];
		}

		// 2. Version
		if (!empty($overrides['version'])) {
			$this->tech_specs->version = $overrides['version'];
		}

		// 3. Category
		if (!empty($overrides['category'])) {
			$this->category = $overrides['category'];
		}

		// @MODIFIED 2026-05-03: REMOVED download_links override path.
		// @MODIFIED 2026-06-18: RESTORED — Download links are synced from hero meta box
		// back to download_section['links'] in Schema_Sync_Service::apply_hero_overrides()
		// before this method is called. This method only handles the download_section
		// when download_links are explicitly passed in overrides (which they are NOT —
		// they are stripped by Schema_Sync_Service). The actual sync happens in
		// apply_hero_overrides() where normalized links are written to $schema->download_section.
	}

    private static function ensure_array($source, $key)
    {
        if (!is_array($source)) {
            return array();
        }

        if (!isset($source[$key])) {
            return array();
        }

        if (!is_array($source[$key])) {
            // Wrap scalar into array for safety.
            return array($source[$key]);
        }

        return $source[$key];
    }
private static function scalar_to_string($value): string
{
    if (is_string($value)) {
        return trim($value);
    }

    if (is_numeric($value) || is_bool($value)) {
        return trim((string) $value);
    }

    return '';
}

private static function normalize_string_list($value): array
{
    if (!is_array($value)) {
        $value = $value === null || $value === '' ? array() : array($value);
    }

    $out = array();

    foreach ($value as $item) {
        $text = self::scalar_to_string($item);
        if ($text !== '') {
            $out[] = $text;
        }
    }

    return array_values($out);
}

public static function normalize_feature_item($item): ?array
{
    if (is_string($item) || is_numeric($item) || is_bool($item)) {
        $text = self::scalar_to_string($item);
        return $text === '' ? null : array(
            'name'        => '',
            'description' => $text,
        );
    }

    if (!is_array($item)) {
        return null;
    }

    $name = self::scalar_to_string($item['name'] ?? $item['title'] ?? $item['label'] ?? '');
    $desc = self::scalar_to_string($item['description'] ?? $item['desc'] ?? $item['text'] ?? $item['value'] ?? '');

    if ($name === '' && $desc === '') {
        return null;
    }

    return array_merge($item, array(
        'name'        => $name,
        'description' => $desc,
    ));
}

private static function normalize_features($value): array
{
    if (!is_array($value)) {
        $value = $value === null || $value === '' ? array() : array($value);
    }

    $out = array();

    foreach ($value as $item) {
        $normalized = self::normalize_feature_item($item);
        if ($normalized !== null) {
            $out[] = $normalized;
        }
    }

    return array_values($out);
}

private static function normalize_faqs($value): array
{
    if (!is_array($value)) {
        $value = $value === null || $value === '' ? array() : array($value);
    }

    $out = array();

    foreach ($value as $item) {
        if (is_string($item) || is_numeric($item) || is_bool($item)) {
            $text = self::scalar_to_string($item);
            if ($text !== '') {
                $out[] = array(
                    'question' => $text,
                    'answer'   => '',
                );
            }
            continue;
        }

        if (!is_array($item)) {
            continue;
        }

        $question = self::scalar_to_string($item['question'] ?? $item['q'] ?? $item['title'] ?? '');
        $answer   = self::scalar_to_string($item['answer'] ?? $item['a'] ?? $item['description'] ?? $item['text'] ?? '');

        if ($question === '' && $answer === '') {
            continue;
        }

        $out[] = array(
            'question' => $question,
            'answer'   => $answer,
        );
    }

    return array_values($out);
}

private static function normalize_related_software($value): array
{
    if (!is_array($value)) {
        $value = $value === null || $value === '' ? array() : array($value);
    }

    $looks_like_single_assoc =
        isset($value['name']) || isset($value['url']) || isset($value['title']) || isset($value['link']);

    if ($looks_like_single_assoc) {
        $value = array($value);
    }

    $out = array();

    foreach ($value as $item) {
        if (is_string($item)) {
            $name = self::scalar_to_string($item);
            if ($name !== '') {
                $out[] = array(
                    'name' => $name,
                    'url'  => '',
                );
            }
            continue;
        }

        if (!is_array($item)) {
            continue;
        }

        $name = self::scalar_to_string($item['name'] ?? $item['title'] ?? '');
        $url  = self::scalar_to_string($item['url'] ?? $item['link'] ?? '');

        if ($name === '' && $url === '') {
            continue;
        }

        $out[] = array(
            'name' => $name,
            'url'  => $url,
        );
    }

    return array_values($out);
}

private static function normalize_pros_cons($value): array
{
    if (!is_array($value)) {
        $value = array();
    }

    $pros = self::normalize_string_list($value['pros'] ?? array());
    $cons = self::normalize_string_list($value['cons'] ?? array());

    if (empty($pros) && empty($cons) && !empty($value)) {
        foreach ($value as $item) {
            $text = self::scalar_to_string($item);
            if ($text !== '') {
                $pros[] = $text;
            }
        }
    }

    return array(
        'pros' => array_values($pros),
        'cons' => array_values($cons),
    );
}

private static function normalize_competitors($value): array
{
    if (!is_array($value)) {
        $value = $value === null || $value === '' ? array() : array($value);
    }

    $out = array();

    foreach ($value as $item) {
        if (is_string($item)) {
            $name = self::scalar_to_string($item);
            if ($name !== '') {
                $out[] = array(
                    'name'              => $name,
                    'comparison_fields' => array(),
                );
            }
            continue;
        }

        if (!is_array($item)) {
            continue;
        }

        $name = self::scalar_to_string($item['name'] ?? $item['title'] ?? '');
        $fields = array();

        $raw_fields = $item['comparison_fields'] ?? array();
        if (is_array($raw_fields)) {
            foreach ($raw_fields as $field) {
                if (is_string($field)) {
                    $field_name = self::scalar_to_string($field);
                    if ($field_name !== '') {
                        $fields[] = array(
                            'field' => $field_name,
                            'value' => '',
                        );
                    }
                    continue;
                }

                if (!is_array($field)) {
                    continue;
                }

                $field_name = self::scalar_to_string($field['field'] ?? $field['name'] ?? '');
                $field_value = self::scalar_to_string($field['value'] ?? $field['description'] ?? '');

                if ($field_name === '' && $field_value === '') {
                    continue;
                }

                $fields[] = array(
                    'field' => $field_name,
                    'value' => $field_value,
                );
            }
        }

        if ($name === '' && empty($fields)) {
            continue;
        }

        $out[] = array(
            'name'              => $name,
            'comparison_fields' => $fields,
        );
    }

    return array_values($out);
}

private static function normalize_installation_guide($value): array
{
    if (!is_array($value)) {
        $value = array();
    }

    $out = $value;

    $out['steps'] = self::normalize_string_list($value['steps'] ?? array());

    $common_issues = $value['common_issues'] ?? array();
    if (!is_array($common_issues)) {
        $common_issues = $common_issues === null || $common_issues === '' ? array() : array($common_issues);
    }

    $normalized_issues = array();

    foreach ($common_issues as $issue) {
        if (is_string($issue)) {
            $text = self::scalar_to_string($issue);
            if ($text !== '') {
                $normalized_issues[] = array(
                    'issue'    => $text,
                    'solution' => '',
                );
            }
            continue;
        }

        if (!is_array($issue)) {
            continue;
        }

        $issue_text = self::scalar_to_string($issue['issue'] ?? $issue['problem'] ?? $issue['title'] ?? '');
        $solution   = self::scalar_to_string($issue['solution'] ?? $issue['fix'] ?? $issue['answer'] ?? $issue['description'] ?? '');

        if ($issue_text === '' && $solution === '') {
            continue;
        }

        $normalized_issues[] = array(
            'issue'    => $issue_text,
            'solution' => $solution,
        );
    }

    $out['common_issues'] = array_values($normalized_issues);

    return $out;
}
    private static function normalize_contract(array $data): array
{
    $map = array(
        'hero_section'       => array('hero_section', 'herosection', 'hero'),
        'download_section'   => array('download_section', 'downloadsection', 'download', 'downloads'),
        'tech_specs'         => array('tech_specs', 'techspecs', 'technical_specs'),
        'whats_new'          => array('whats_new', 'whatsnew', 'changelog'),
        'pros_cons'          => array('pros_cons', 'proscons'),
        'installation_guide' => array('installation_guide', 'installationguide'),
        'related_software'   => array('related_software', 'relatedsoftware'),
        'meta_description'   => array('meta_description', 'metadescription'),
        'focus_keyword'      => array('focus_keyword', 'focuskeyword'),
        'video_url'          => array('video_url', 'videourl'),
        'software_type'      => array('software_type', 'softwaretype'),
        'moat_data'          => array('moat_data', 'moat', 'moat_content', 'moatdata', 'moat-content'),
    );

    foreach ($map as $canonical => $aliases) {
        // Only skip if canonical key already has a non-empty value
        if (isset($data[$canonical]) && $data[$canonical] !== '' && $data[$canonical] !== null) {
            continue;
        }
        foreach ($aliases as $alias) {
            if ($alias === $canonical) {
                continue;
            }
            if (isset($data[$alias]) && $data[$alias] !== '' && $data[$alias] !== null) {
                $data[$canonical] = $data[$alias];
                break;
            }
        }
    }

    if (!isset($data['download_section']) || !is_array($data['download_section'])) {
        $data['download_section'] = array();
    }

    $raw_links = array();

    if (isset($data['download_section']['links']) && is_array($data['download_section']['links'])) {
        $raw_links = $data['download_section']['links'];
    } elseif (isset($data['downloadsectionlinks']) && is_array($data['downloadsectionlinks'])) {
        $raw_links = $data['downloadsectionlinks'];
    } elseif (isset($data['download_links'])) {
        if (is_array($data['download_links'])) {
            $raw_links = $data['download_links'];
        } elseif ($data['download_links'] !== null && $data['download_links'] !== '') {
            $raw_links = array($data['download_links']);
        }
    }

    $normalized_links = array();

    foreach ($raw_links as $raw_link) {
        if (is_string($raw_link)) {
            $raw_link = array('url' => $raw_link);
        }

        if (!is_array($raw_link)) {
            continue;
        }

        $url = '';
        if (!empty($raw_link['url']) && is_string($raw_link['url'])) {
            $url = (string) $raw_link['url'];
        } elseif (!empty($raw_link['link']) && is_string($raw_link['link'])) {
            $url = (string) $raw_link['link'];
        }

        if ($url === '') {
            continue;
        }

		$normalized_links[] = array(
			'platform' => (string) ($raw_link['platform'] ?? ''),
			'url' => $url,
			'variant' => (string) ($raw_link['variant'] ?? ($raw_link['type'] ?? '')),
			'file_type' => (string) ($raw_link['file_type'] ?? ''),
			'version' => (string) ($raw_link['version'] ?? ''),
			'channel' => (string) ($raw_link['channel'] ?? ''),
			'text' => (string) ($raw_link['text'] ?? ''),
			'is_primary' => !empty($raw_link['is_primary']) || !empty($raw_link['isprimary']) || !empty($raw_link['primary']) ? 1 : 0,
			'_portal_fallback' => !empty($raw_link['_portal_fallback']),
		);
    }

    $has_primary = false;
    foreach ($normalized_links as $i => $link) {
        if (!empty($link['is_primary']) && !$has_primary) {
            $has_primary = true;
            $normalized_links[$i]['is_primary'] = 1;
        } else {
            $normalized_links[$i]['is_primary'] = 0;
        }
    }
    if (!$has_primary && !empty($normalized_links)) {
        $normalized_links[0]['is_primary'] = 1;
    }

    $data['download_section']['links'] = $normalized_links;

    unset($data['downloadsectionlinks'], $data['download_links']);

    $data['introduction']        = self::normalize_string_list($data['introduction'] ?? array());
    $data['whats_new']           = self::normalize_string_list($data['whats_new'] ?? array());
    $data['features']            = self::normalize_features($data['features'] ?? array());
    $data['faqs']                = self::normalize_faqs($data['faqs'] ?? array());
    $data['pros_cons']           = self::normalize_pros_cons($data['pros_cons'] ?? array());
    $data['related_software']    = self::normalize_related_software($data['related_software'] ?? array());
    $data['competitors']         = self::normalize_competitors($data['competitors'] ?? array());
    $data['installation_guide']  = self::normalize_installation_guide($data['installation_guide'] ?? array());

    if (!isset($data['hero_section']) || !is_array($data['hero_section'])) {
        $data['hero_section'] = array();
    }

	if (!isset($data['moat_data']) || !is_array($data['moat_data'])) {
		$data['moat_data'] = array();
	}

	if (!isset($data['moat_data']['content']) && isset($data['moat_data']['steps']) && is_array($data['moat_data']['steps'])) {
		$heading = $data['moat_data']['heading'] ?? '';
		$data['moat_data'] = array('heading' => $heading, 'content' => $data['moat_data']['steps']);
	}

	if (isset($data['moat_data']['content']) && is_array($data['moat_data']['content'])) {
        $mapped_content = array();
        foreach ($data['moat_data']['content'] as $item) {
             if (is_array($item) || (is_string($item) && trim($item) !== '')) {
                 $mapped_content[] = $item;
             }
        }
        $data['moat_data']['content'] = $mapped_content;
    }

    if (!isset($data['comparison_field_order']) || !is_array($data['comparison_field_order'])) {
        $data['comparison_field_order'] = self::normalize_string_list($data['comparison_field_order'] ?? array());
    } else {
        $data['comparison_field_order'] = self::normalize_string_list($data['comparison_field_order']);
    }

    if (!isset($data['main_software_comparison']) || !is_array($data['main_software_comparison'])) {
        $data['main_software_comparison'] = array();
    } else {
        $msc = array();
        foreach ($data['main_software_comparison'] as $row) {
            if (is_string($row)) {
                $field = self::scalar_to_string($row);
                if ($field !== '') {
                    $msc[] = array('field' => $field, 'value' => '');
                }
                continue;
            }

            if (!is_array($row)) {
                continue;
            }

            $field = self::scalar_to_string($row['field'] ?? $row['name'] ?? '');
            $value = self::scalar_to_string($row['value'] ?? $row['description'] ?? '');

            if ($field === '' && $value === '') {
                continue;
            }

            $msc[] = array(
                'field' => $field,
                'value' => $value,
            );
        }
        $data['main_software_comparison'] = array_values($msc);
    }

    return $data;
}
}

