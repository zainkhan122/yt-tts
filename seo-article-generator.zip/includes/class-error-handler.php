<?php

/**
 * Error Handler
 *
 * @package SEO_Article_Generator
 */

namespace SEO_Article_Generator;

// Prevent direct access
if (! defined('ABSPATH')) {
    exit;
}

/**
 * Custom exception for AI-related errors
 */
class AI_Exception extends \Exception
{
    public function __construct($message = '', $code = 0, \Throwable $previous = null)
    {
        parent::__construct($message, (int) $code, $previous);
    }
}

/**
 * Custom exception for validation errors
 */
class Validation_Exception extends \Exception {}

/**
 * Custom exception for database errors
 */
class Database_Exception extends \Exception {}

/**
 * Custom exception for file upload errors
 */
class File_Upload_Exception extends \Exception {}

/**
 * Centralized error handling
 */
class Error_Handler
{
    /**
     * Logger instance
     *
     * @var Logger
     */
    private $logger;

    /**
     * Allowed plugin root paths (normalized, no trailing slash)
     *
     * @var string[]
     */
    private $scope_roots = array();

    /**
     * Set allowed scope roots for log filtering.
     *
     * Only errors/exceptions/fatals whose origin file lives under one of
     * these directories are written into this plugin's log files.
     *
     * @param string[] $roots Absolute directory paths
     * @return void
     */
    public function set_scope_roots(array $roots): void
    {
        $normalized = array();

        foreach ($roots as $root) {
            $root = wp_normalize_path((string) $root);
            $root = rtrim($root, '/\\');

            if ($root !== '') {
                $normalized[] = $root;
            }
        }

        $this->scope_roots = array_values(array_unique($normalized));
    }

    /**
     * Check whether a file path belongs to this plugin's scope.
     *
     * @param string $file Absolute file path
     * @return bool
     */
    private function is_plugin_path($file): bool
    {
        $file = wp_normalize_path((string) $file);

        if ($file === '') {
            return false;
        }

        foreach ($this->scope_roots as $root) {
            if ($file === $root || strpos($file, $root . '/') === 0) {
                return true;
            }
        }

        return false;
    }

    /**
     * Check whether an error type is fatal.
     *
     * @param int $type PHP error constant
     * @return bool
     */
    private function is_fatal_type(int $type): bool
    {
        return in_array($type, array(E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR, E_RECOVERABLE_ERROR), true);
    }

    /**
     * Initialize error handler
     *
     * @return void
     */
    public function init()
    {
        // Set custom error handler only in plugin context
        set_error_handler(array($this, 'handle_error'), E_ALL);
        set_exception_handler(array($this, 'handle_exception'));
        register_shutdown_function(array($this, 'handle_shutdown'));
    }

    /**
     * Handle PHP errors
     *
     * @param int    $errno Error number
     * @param string $errstr Error message
     * @param string $errfile Error file
     * @param int    $errline Error line
     * @return bool
     */
    public function handle_error($errno, $errstr, $errfile, $errline)
    {
        // Don't handle suppressed errors
        if (! (error_reporting() & $errno)) {
            return false;
        }

        // STRICT: only plugin-originating PHP errors go into plugin logs.
        if (!$this->is_plugin_path($errfile)) {
            return false;
        }

        $error_types = array(
            E_ERROR => 'ERROR',
            E_WARNING => 'WARNING',
            E_PARSE => 'PARSE',
            E_NOTICE => 'NOTICE',
            E_CORE_ERROR => 'CORE_ERROR',
            E_CORE_WARNING => 'CORE_WARNING',
            E_COMPILE_ERROR => 'COMPILE_ERROR',
            E_COMPILE_WARNING => 'COMPILE_WARNING',
            E_USER_ERROR => 'USER_ERROR',
            E_USER_WARNING => 'USER_WARNING',
            E_USER_NOTICE => 'USER_NOTICE',
            E_STRICT => 'STRICT',
            E_RECOVERABLE_ERROR => 'RECOVERABLE_ERROR',
            E_DEPRECATED => 'DEPRECATED',
            E_USER_DEPRECATED => 'USER_DEPRECATED',
        );

        $type = isset($error_types[$errno]) ? $error_types[$errno] : 'UNKNOWN';

        // Log the error
        if ($this->logger) {
            $this->logger->error("[{$type}] {$errstr} in {$errfile}:{$errline}");
        }

        // Also send to PHP error_log for visibility during development
        error_log("[SEO GEN PHP ERROR] [{$type}] {$errstr} in {$errfile}:{$errline}");

        // Always return false to allow standard PHP error handling (no suppression)
        return false;
    }

    /**
     * Handle uncaught exceptions
     *
     * @param \Throwable $exception Exception object
     * @return void
     */
    public function handle_exception($exception)
    {
        if (!$exception instanceof \Throwable) {
            return;
        }

        // STRICT: use ONLY the exception origin file.
        if (!$this->is_plugin_path($exception->getFile())) {
            return;
        }

        $message = sprintf(
            'Uncaught exception: %s in %s:%d',
            $exception->getMessage(),
            $exception->getFile(),
            $exception->getLine()
        );

        if ($this->logger) {
            $this->logger->error($message);
            $this->logger->error('Stack trace: ' . $exception->getTraceAsString());
        }

        // Also log to PHP error_log so nothing is truly silent
        error_log('[SEO GEN EXCEPTION] ' . $message);
        error_log('[SEO GEN EXCEPTION TRACE] ' . $exception->getTraceAsString());

        // Display user-friendly error for AJAX
        if (defined('DOING_AJAX') && DOING_AJAX) {
            wp_send_json_error(array(
                'message' => $this->get_user_friendly_message($exception),
            ));
        }
    }

    /**
     * Handle fatal errors on shutdown
     *
     * @return void
     */
    public function handle_shutdown()
    {
        $error = error_get_last();

        if (empty($error) || !is_array($error)) {
            return;
        }

        $type = isset($error['type']) ? (int) $error['type'] : 0;
        $file = isset($error['file']) ? (string) $error['file'] : '';
        $line = isset($error['line']) ? (int) $error['line'] : 0;
        $message = isset($error['message']) ? (string) $error['message'] : '';

        if (!$this->is_fatal_type($type)) {
            return;
        }

        // STRICT: fatal must originate from this plugin.
        if (!$this->is_plugin_path($file)) {
            return;
        }

        if ($this->logger) {
            $this->logger->error(
                sprintf(
                    'Fatal error: %s in %s:%d',
                    $message,
                    $file,
                    $line
                )
            );
        }

        error_log(sprintf(
            '[SEO GEN FATAL] %s in %s:%d',
            $message,
            $file,
            $line
        ));

        $active = \get_option('seo_gen_active_job');
        if (is_array($active) && !empty($active['job_id'])) {
            global $wpdb;

            $job_id = (int) $active['job_id'];
            $reason = sprintf(
                'Fatal error: %s in %s:%d',
                $message,
                $file,
                $line
            );

            $wpdb->update(
                \SEO_Article_Generator\Installer::table_jobs(),
                array(
                    'status'        => 'failed',
                    'error_message' => $reason,
                    'completed_at'  => Utils\Plugin_Time::utc_mysql_now(),
                ),
                array(
                    'id'     => $job_id,
                    'status' => 'processing',
                ),
                array('%s', '%s', '%s'),
                array('%d', '%s')
            );

            if (\function_exists('as_unschedule_all_actions')) {
                \as_unschedule_all_actions(
                    'seo_gen_process_article',
                    array('job_id' => $job_id),
                    \SEO_Article_Generator\Queue\AS_Registry::GROUP
                );
            }

            \delete_option('seo_gen_active_job');
            \delete_option('seo_gen_processing_mutex');
        }
    }

    /**
     * Get user-friendly error message
     *
     * @param \Throwable $exception Exception object
     * @return string
     */
    private function get_user_friendly_message($exception)
    {
        if ($exception instanceof AI_Exception) {
            return 'Failed to connect to API AI service. Please check your API key and try again.';
        }

        if ($exception instanceof Validation_Exception) {
            return $exception->getMessage();
        }

        if ($exception instanceof Database_Exception) {
            return 'A database error occurred. Please try again or contact support.';
        }

        if ($exception instanceof File_Upload_Exception) {
            return $exception->getMessage();
        }

        return 'An unexpected error occurred. Please try again.';
    }

    /**
     * Set logger instance
     *
     * @param Logger $logger Logger instance
     * @return void
     */
    public function set_logger($logger)
    {
        $this->logger = $logger;
    }
}
