<?php

/**
 * Pipeline Health Monitor
 * 
 * Automatically detects and prevents pipeline failures before they occur.
 * Runs at each pipeline stage to ensure smooth operation.
 * 
 * @package DIT\TrendStudio\Infrastructure
 */

namespace DIT\TrendStudio\Infrastructure;

use DIT\TrendStudio\AI_Exception;
use DIT\TrendStudio\Source_Exception;
use DIT\TrendStudio\Validation_Exception;

class Pipeline_Health_Monitor
{

    private $logger;
    private $auto_fix_enabled;
    private $metrics = [];

    public function __construct($logger = null)
    {
        $this->logger = $logger ?? new \WP_Error();
        $this->auto_fix_enabled = apply_filters('dit_ts_auto_fix_enabled', true);
    }

    /**
     * Check system health before starting job
     * Auto-fixes configuration issues
     */
    public function preflight_check()
    {
        $issues = [];

        // Issue #037: Memory check
        $memory_issue = $this->check_memory_limit();
        if ($memory_issue) {
            if ($this->auto_fix_enabled) {
                $this->fix_memory_limit();
            } else {
                $issues[] = $memory_issue;
            }
        }

        // Issue #038: Execution time check
        $timeout_issue = $this->check_execution_time();
        if ($timeout_issue && $this->auto_fix_enabled) {
            $this->fix_execution_time();
        }

        // Issue #001: API rate limit check
        $rate_limit_issue = $this->check_api_rate_limits();
        if ($rate_limit_issue && !$this->auto_fix_enabled) {
            $issues[] = $rate_limit_issue;
        }

        // Issue #040: Clear corrupted cache
        $this->clear_corrupted_cache();

        return empty($issues);
    }

    /**
     * Issue #037: Ensure sufficient memory
     */
    private function check_memory_limit()
    {
        $current = $this->parse_memory_limit(ini_get('memory_limit'));
        $required = 256 * 1024 * 1024; // 256MB

        if ($current < $required) {
            return [
                'issue' => '#037',
                'message' => 'Insufficient memory',
                'current' => $current / 1024 / 1024 . 'MB',
                'required' => '256MB',
            ];
        }

        return null;
    }

    private function fix_memory_limit()
    {
        @ini_set('memory_limit', '256M');
        $this->log_auto_fix('#037', 'Increased memory limit to 256MB');
    }

    /**
     * Issue #038: Ensure sufficient execution time
     */
    private function check_execution_time()
    {
        $limit = (int) ini_get('max_execution_time');

        if ($limit > 0 && $limit < 300) {
            return [
                'issue' => '#038',
                'message' => 'Insufficient execution time',
                'current' => $limit . 's',
                'required' => '300s',
            ];
        }

        return null;
    }

    private function fix_execution_time()
    {
        @set_time_limit(300);
        $this->log_auto_fix('#038', 'Increased execution time to 300s');
    }

    /**
     * Issue #001 & #011: Check API rate limits before making requests
     */
    private function check_api_rate_limits()
    {
        // NewsAPI rate limit (100/day)
        $newsapi_count = (int) get_option('newsapi_daily_count', 0);
        if ($newsapi_count >= 95) {
            $this->log_auto_fix('#001', 'NewsAPI approaching rate limit, will use fallback');
            update_option('dit_ts_use_newsapi', false); // Temporarily disable
            return null; // Auto-fixed
        }

        // Gemini rate limit (15 RPM)
        $last_request = get_transient('gemini_last_request_time');
        if ($last_request && (time() - $last_request) < 4) {
            $wait = 4 - (time() - $last_request);
            $this->log_auto_fix('#011', "Rate limit throttle: waiting {$wait}s");
            sleep($wait);
        }

        return null; // Auto-handled
    }

    /**
     * Issue #040: Clear corrupted cache entries
     */
    private function clear_corrupted_cache()
    {
        global $wpdb;

        // Find suspicious transients (very old or malformed)
        $wpdb->query(
            "DELETE FROM {$wpdb->options} 
             WHERE option_name LIKE '_transient_gemini_%' 
             AND CHAR_LENGTH(option_value) < 10"
        );
    }

    /**
     * Validate research quality before sending to AI
     * Issues #003, #004, #005
     */
    public function validate_research($research_data)
    {
        $fixes_applied = [];

        // Issue #003: Ensure minimum research content
        if (
            empty($research_data['research_content']) ||
            str_word_count(strip_tags($research_data['research_content'])) < 500
        ) {

            if ($this->auto_fix_enabled) {
                $research_data = $this->enrich_research($research_data);
                $fixes_applied[] = '#003: Enriched sparse research';
            } else {
                throw new Source_Exception('Insufficient research data');
            }
        }

        // Issue #004: Remove script noise
        if (
            stripos($research_data['research_content'], '<script') !== false ||
            stripos($research_data['research_content'], 'advertisement') !== false
        ) {

            $research_data['research_content'] = $this->remove_script_noise($research_data['research_content']);
            $fixes_applied[] = '#004: Removed script/ad noise';
        }

        // Issue #005: Fix encoding issues
        if (mb_detect_encoding($research_data['research_content'], 'UTF-8', true) === false) {
            $research_data['research_content'] = $this->normalize_encoding($research_data['research_content']);
            $fixes_applied[] = '#005: Fixed encoding';
        }

        if (!empty($fixes_applied)) {
            $this->log_auto_fix('Research Validation', implode(', ', $fixes_applied));
        }

        return $research_data;
    }

    /**
     * Issue #003: Enrich sparse research
     */
    private function enrich_research($research_data)
    {
        // Try fallback sources
        $topic = $research_data['topic'] ?? '';

        if (empty($topic)) {
            return $research_data;
        }

        // Use cached similar topics
        $similar_cache = get_transient('research_cache_' . md5($topic));
        if ($similar_cache && str_word_count(strip_tags($similar_cache)) >= 500) {
            $research_data['research_content'] = $similar_cache;
            return $research_data;
        }

        // If still insufficient, mark for manual review but don't fail
        $research_data['requires_review'] = true;
        $research_data['review_reason'] = 'Insufficient research data';

        return $research_data;
    }

    /**
     * Issue #004: Remove script noise from scraped content
     */
    private function remove_script_noise($html)
    {
        $dom = new \DOMDocument();
        @$dom->loadHTML($html, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
        $xpath = new \DOMXPath($dom);

        // Remove scripts, styles, noscripts
        $noise = $xpath->query('//script | //noscript | //style');
        foreach ($noise as $node) {
            $node->parentNode->removeChild($node);
        }

        // Remove ad containers
        $ad_classes = ['advertisement', 'ad-container', 'sidebar', 'promo-box', 'newsletter'];
        foreach ($ad_classes as $class) {
            $nodes = $xpath->query("//*[contains(@class, '$class')]");
            foreach ($nodes as $node) {
                $node->parentNode->removeChild($node);
            }
        }

        return $dom->saveHTML();
    }

    /**
     * Issue #005: Normalize encoding to UTF-8
     */
    private function normalize_encoding($text)
    {
        $encoding = mb_detect_encoding($text, ['UTF-8', 'ISO-8859-1', 'Windows-1252', 'ASCII'], true);

        if ($encoding !== 'UTF-8') {
            $text = mb_convert_encoding($text, 'UTF-8', $encoding ?: 'ISO-8859-1');
        }

        // Normalize Unicode (NFC form)
        if (class_exists('Normalizer')) {
            $text = \Normalizer::normalize($text, \Normalizer::FORM_C);
        }

        // Remove zero-width characters
        $text = preg_replace('/[\x{200B}-\x{200D}\x{FEFF}]/u', '', $text);

        return $text;
    }

    /**
     * Validate prompt before API call
     * Issues #006, #007, #050
     */
    public function validate_prompt($prompt_data, $vertical)
    {
        $fixes_applied = [];

        // Issue #006: Check required variables
        $required = $this->get_required_variables($vertical);
        foreach ($required as $key) {
            if (empty($prompt_data[$key])) {
                if ($this->auto_fix_enabled) {
                    $prompt_data[$key] = $this->generate_default_value($key, $prompt_data);
                    $fixes_applied[] = "#006: Added default for $key";
                } else {
                    throw new Validation_Exception("Missing required prompt variable: $key");
                }
            }
        }

        // Issue #007 & #050: Check token count
        $token_count = $this->estimate_token_count(json_encode($prompt_data));
        if ($token_count > 30000) {
            $prompt_data = $this->truncate_research_safely($prompt_data, 25000);
            $fixes_applied[] = '#007: Truncated research to fit token limit';
        }

        if (!empty($fixes_applied)) {
            $this->log_auto_fix('Prompt Validation', implode(', ', $fixes_applied));
        }

        return $prompt_data;
    }

    /**
     * Validate API response before processing
     * Issues #013, #014, #015, #016
     */
    public function validate_api_response($response_text)
    {
        $fixes_applied = [];

        // Issue #013: Detect truncation
        if ($this->is_truncated($response_text)) {
            $this->log_auto_fix('#013', 'Detected truncation, will request regeneration');
            throw new AI_Exception('Response truncated - will regenerate with strictJson');
        }

        // Issue #015: Normalize unicode
        $normalized = $this->normalize_unicode($response_text);
        if ($normalized !== $response_text) {
            $response_text = $normalized;
            $fixes_applied[] = '#015: Normalized Unicode';
        }

        // Issue #014: Fix nested quotes
        $fixed_quotes = $this->fix_nested_quotes($response_text);
        if ($fixed_quotes !== $response_text) {
            $response_text = $fixed_quotes;
            $fixes_applied[] = '#014: Fixed nested quotes';
        }

        if (!empty($fixes_applied)) {
            $this->log_auto_fix('Response Validation', implode(', ', $fixes_applied));
        }

        return $response_text;
    }

    /**
     * Validate parsed JSON data
     * Issues #016, #017
     */
    public function validate_parsed_data($data, $prompt_data)
    {
        $fixes_applied = [];

        // Issue #016: Normalize array types
        $array_fields = ['sections', 'tags', 'sources', 'internal_links', 'source_snippets'];
        foreach ($array_fields as $field) {
            if (isset($data[$field]) && !is_array($data[$field])) {
                $data[$field] = [$data[$field]];
                $fixes_applied[] = "#016: Converted $field to array";
            } elseif (!isset($data[$field])) {
                $data[$field] = [];
            }
            // Ensure sequential array
            $data[$field] = array_values($data[$field]);
        }

        // Issue #017: Fill missing required fields
        $required = ['headline', 'dek', 'sections', 'vertical', 'category'];
        foreach ($required as $field) {
            if (empty($data[$field])) {
                $data[$field] = $this->generate_default_value($field, $prompt_data);
                $fixes_applied[] = "#017: Added default for $field";
            }
        }

        if (!empty($fixes_applied)) {
            $this->log_auto_fix('Data Validation', implode(', ', $fixes_applied));
        }

        return $data;
    }

    /**
     * Validate and fix content quality
     * Issues #018, #019, #049
     */
    public function validate_content_quality($article)
    {
        $fixes_applied = [];

        // Issue #018: Remove template language
        $content = $article['sections'][0]['bodyhtml'] ?? '';
        $cleaned = $this->remove_template_language($content);
        if ($cleaned !== $content) {
            $article['sections'][0]['bodyhtml'] = $cleaned;
            $fixes_applied[] = '#018: Removed template language';
        }

        // Issue #019 & #049: Validate numbers against sources
        $suspicious_numbers = $this->validate_numbers($content, $article['source_snippets'] ?? []);
        if (!empty($suspicious_numbers)) {
            // Flag for review but don't fail
            $article['requires_review'] = true;
            $article['review_reason'] = 'Unverified numbers detected: ' . implode(', ', $suspicious_numbers);
            $fixes_applied[] = '#049: Flagged unverified numbers for review';
        }

        if (!empty($fixes_applied)) {
            $this->log_auto_fix('Content Quality', implode(', ', $fixes_applied));
        }

        return $article;
    }

    /**
     * Validate media URLs before use
     * Issues #025, #026
     */
    public function validate_media_urls($article)
    {
        $fixes_applied = [];

        // Issue #025: Validate hero image
        if (!empty($article['hero_image'])) {
            $validated = $this->validate_image_url($article['hero_image']);
            if ($validated !== $article['hero_image']) {
                $article['hero_image'] = $validated;
                $fixes_applied[] = '#025: Used fallback for broken image';
            }
        }

        // Issue #026: Optimize YouTube thumbnails
        $content = $article['sections'][0]['bodyhtml'] ?? '';
        $optimized = $this->optimize_youtube_thumbnails($content);
        if ($optimized !== $content) {
            $article['sections'][0]['bodyhtml'] = $optimized;
            $fixes_applied[] = '#026: Optimized YouTube thumbnails';
        }

        if (!empty($fixes_applied)) {
            $this->log_auto_fix('Media Validation', implode(', ', $fixes_applied));
        }

        return $article;
    }

    // ========================================================================
    // Helper Methods
    // ========================================================================

    private function parse_memory_limit($limit)
    {
        if ($limit === '-1') return PHP_INT_MAX;

        $unit = strtolower(substr($limit, -1));
        $value = (int) $limit;

        switch ($unit) {
            case 'g':
                return $value * 1024 * 1024 * 1024;
            case 'm':
                return $value * 1024 * 1024;
            case 'k':
                return $value * 1024;
            default:
                return $value;
        }
    }

    private function get_required_variables($vertical)
    {
        $required_map = [
            'showbiz' => ['idea_title', 'idea_text', 'category'],
            'fashion' => ['idea_title', 'idea_text', 'category'],
            'tech' => ['idea_title', 'idea_text', 'category'],
        ];

        return $required_map[$vertical] ?? ['idea_title', 'idea_text'];
    }

    private function generate_default_value($key, $context)
    {
        $defaults = [
            'idea_title' => 'Untitled Article',
            'idea_text' => '',
            'headline' => $context['idea_title'] ?? 'Untitled',
            'dek' => substr($context['idea_text'] ?? '', 0, 150),
            'vertical' => $context['vertical'] ?? 'showbiz',
            'category' => 'general',
            'primary_keyword' => $context['idea_title'] ?? '',
        ];

        return $defaults[$key] ?? '';
    }

    private function estimate_token_count($text)
    {
        return (int) (mb_strlen($text) / 4);
    }

    private function truncate_research_safely($prompt_data, $max_tokens)
    {
        if (isset($prompt_data['research_content'])) {
            $current = $this->estimate_token_count($prompt_data['research_content']);
            if ($current > $max_tokens) {
                $ratio = $max_tokens / $current;
                $target_length = (int) (mb_strlen($prompt_data['research_content']) * $ratio);
                $prompt_data['research_content'] = mb_substr($prompt_data['research_content'], 0, $target_length);
            }
        }

        return $prompt_data;
    }

    private function is_truncated($text)
    {
        $signals = [
            'incomplete_json' => !preg_match('/\}\s*$/', trim($text)),
            'unclosed_quotes' => substr_count($text, '"') % 2 !== 0,
            'unclosed_brackets' => substr_count($text, '{') !== substr_count($text, '}'),
        ];

        return array_sum($signals) >= 2;
    }

    private function normalize_unicode($text)
    {
        $replacements = [
            "\u{2018}" => "'",
            "\u{2019}" => "'",
            "\u{201C}" => '"',
            "\u{201D}" => '"',
            "\u{2013}" => '-',
            "\u{2014}" => '--',
        ];

        return str_replace(array_keys($replacements), array_values($replacements), $text);
    }

    private function fix_nested_quotes($json_string)
    {
        return preg_replace_callback(
            '/"([^"\\\\]*(?:\\\\.[^"\\\\]*)*)"/',
            function ($matches) {
                $content = $matches[1];
                $fixed = preg_replace('/(?<!\\\\)"/', '\\"', $content);
                return '"' . $fixed . '"';
            },
            $json_string
        );
    }

    private function remove_template_language($content)
    {
        $banned_patterns = [
            '/\bin conclusion\b/i',
            '/\bstay tuned\b/i',
            '/\bmoving forward\b/i',
            '/\bat the end of the day\b/i',
        ];

        foreach ($banned_patterns as $pattern) {
            $content = preg_replace($pattern, '', $content);
        }

        return $content;
    }

    private function validate_numbers($content, $source_snippets)
    {
        preg_match_all('/\b(\d+(?:,\d{3})*(?:\.\d+)?)\s*(million|billion|%|followers)?\b/i', $content, $matches);

        $suspicious = [];
        foreach ($matches[0] as $i => $full_match) {
            $number = $matches[1][$i];

            if ($number < 100) continue; // Skip small numbers

            $found = false;
            foreach ($source_snippets as $snippet) {
                if (stripos($snippet, $number) !== false) {
                    $found = true;
                    break;
                }
            }

            if (!$found) {
                $suspicious[] = $full_match;
            }
        }

        return $suspicious;
    }

    private function validate_image_url($url, $fallbacks = [])
    {
        $response = wp_remote_head($url, ['timeout' => 10]);

        if (wp_remote_retrieve_response_code($response) === 200) {
            return $url;
        }

        // Use placeholder
        return 'https://via.placeholder.com/1200x630?text=Image+Not+Available';
    }

    private function optimize_youtube_thumbnails($content)
    {
        return preg_replace_callback(
            '/img\.youtube\.com\/vi\/([^\/]+)\/(default|hqdefault|sddefault)\.jpg/',
            function ($matches) {
                $video_id = $matches[1];
                // Try maxres first
                $maxres = "https://img.youtube.com/vi/{$video_id}/maxresdefault.jpg";
                $response = wp_remote_head($maxres, ['timeout' => 5]);

                if (wp_remote_retrieve_response_code($response) === 200) {
                    return str_replace($matches[0], "img.youtube.com/vi/{$video_id}/maxresdefault.jpg", $matches[0]);
                }

                return $matches[0];
            },
            $content
        );
    }

    private function log_auto_fix($issue, $message)
    {
        if (is_a($this->logger, 'WP_Error')) {
            error_log("[TrendStudio Auto-Fix] {$issue}: {$message}");
        } else {
            $this->logger->info("Auto-fix applied", [
                'issue' => $issue,
                'fix' => $message,
            ]);
        }

        $this->metrics[] = [
            'timestamp' => time(),
            'issue' => $issue,
            'fix' => $message,
        ];
    }

    /**
     * Get metrics for admin dashboard
     */
    public function get_metrics()
    {
        return $this->metrics;
    }
}
