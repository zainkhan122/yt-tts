<?php

/**
 * AJAX Handler for AI Tools (Hooks, SEO, Backgrounds)
 *
 * @package MCQ_Video_Studio
 */

if (! defined('ABSPATH')) {
    exit;
}

class VS_AJAX_AI_Tools_Handler
{

    private static $instance = null;

    public static function get_instance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * @NEW 2026-02-18: Get Authoritative Working Model
     * @MODIFIED 2026-06-26: Route through the active AI provider.
     *                      Falls back to Gemini classic endpoint if no provider is selected.
     */
    private function get_working_model()
    {
        $active = get_option('mcqvs_api_provider', 'gemini');
        if (class_exists('VS_Provider_Registry') && !empty($active)) {
            try {
                return VS_Provider_Registry::get_instance()->get_working_model($active);
            } catch (\Exception $e) {
                // keep legacy Gemini fallback
            }
        }
        return get_option('mcqvs_gemini_model_id', 'gemini-3-flash-preview');
    }

    /**
     * @NEW 2026-02-18: Independent Key Logic (Local > Parent)
     */
    private function get_api_key()
    {
        $api_key = get_option('mcqvs_gemini_api_key', '');
        if (empty($api_key)) {
            $api_key = get_option('nm_gemini_api_key', '');
        }
        return $api_key;
    }

    /**
     * AJAX: Generate Viral Hooks
     */
    public function ajax_generate_hooks()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error(__('Access denied', 'mcq-video-studio'));
        }

        // @NEW 2026-02-25: Short transient lock to prevent duplicate background jobs
        $lock_key = 'mcqvs_ai_bg_lock_' . md5($_POST['prompt'] ?? '');
        if (get_transient($lock_key)) {
            wp_send_json_error(__('Background generation already in progress. Please wait.', 'mcq-video-studio'));
        }
        set_transient($lock_key, 1, 15);

        $topic          = sanitize_text_field($_POST['topic'] ?? '');
        $question_count = absint($_POST['question_count'] ?? 5);
        // @NEW 2026-08-11: Accept the actual quiz questions (JSON array of {question})
        //       so the hooks reference the most surprising fact instead of the topic name.
        $questions_raw  = isset($_POST['questions']) ? wp_unslash($_POST['questions']) : '';
        $questions_ctx  = '';
        if (is_string($questions_raw) && $questions_raw !== '') {
            $qarr = json_decode($questions_raw, true);
            if (is_array($qarr)) {
                $lines = array();
                foreach (array_slice($qarr, 0, 8) as $qi => $qq) {
                    $qtxt = is_array($qq) ? (string) ($qq['question'] ?? '') : (string) $qq;
                    if ($qtxt !== '') $lines[] = ($qi + 1) . '. ' . $qtxt;
                }
                if (!empty($lines)) $questions_ctx = implode("\n", $lines);
            }
        }

        $registry = class_exists('VS_Provider_Registry') ? VS_Provider_Registry::get_instance() : null;

        if ($registry) {
            $rotation = $registry->get_next_model('hooks');
            $active_provider = $rotation['provider'];
            $model = $rotation['model'];
            $api_key = $registry->get_rotation_api_key($active_provider);
        } else {
            $active_provider = 'gemini';
            $model = get_option('mcqvs_gemini_model_id', 'gemini-3-flash-preview');
            $api_key = $this->get_api_key();
        }

        if (empty($api_key)) {
            $defaults = array(
                "Can you score $question_count/$question_count?",
                'Only 1% get this right!',
                'Test your knowledge NOW!',
                'Are you a GENIUS?',
                'Most people FAIL this quiz!',
            );
            wp_send_json_success(array('hooks' => $defaults, 'source' => 'fallback'));
        }

        $prompt = "You are a viral-shorts copywriter. Generate 5 high-retention hook texts for a $question_count-question quiz about \"$topic\".\n";
        if ($questions_ctx !== '') {
            $prompt .= "The quiz questions are:\n{$questions_ctx}\n";
        }
        $prompt .= "Use modern social media psychology frameworks: Curiosity Gaps, Negative Constraints, Specific Stakes.\n"
            . "Each hook: max 8 words, ONE relevant emoji at the start, derived from the MOST surprising question or fact above (never generic, never spoiling the answer).\n"
            . "Return ONLY a JSON array of strings: [\"hook1\", \"hook2\", \"hook3\", \"hook4\", \"hook5\"]";

        $url = $registry ? $registry->build_rotation_url($active_provider, $model) : "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key=" . $api_key;
        if ($registry) {
            $request_body = $registry->build_request_body(
                $active_provider,
                array(array('role' => 'user', 'content' => $prompt)),
                $model,
                array('json_mode' => true)
            );
        } else {
            $request_body = array('contents' => array(array('parts' => array(array('text' => $prompt)))));
        }
        $post_args = array(
            'body'    => json_encode($request_body),
            'timeout' => 15,
        );
        if ($registry) {
            $post_args['headers'] = $registry->build_rotation_headers($active_provider, $url);
        } else {
            $post_args['headers'] = array('Content-Type' => 'application/json');
        }
        $start_time = microtime(true);
        $response = wp_remote_post($url, $post_args);
        $duration = microtime(true) - $start_time;

        // @NEW 2026-01-09: Central API Logging
        VS_Error_Logger::get_instance()->log_api($url, 'POST', array('prompt' => $prompt), $response, $duration);

        if (is_wp_error($response)) {
            wp_send_json_success(array('hooks' => array("Can you score $question_count/$question_count?", 'Only 1% get this right!'), 'source' => 'fallback'));
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        $raw_text = '';
        if (isset($body['candidates'][0]['content']['parts'][0]['text'])) {
            $raw_text = $body['candidates'][0]['content']['parts'][0]['text'];
        } elseif (isset($body['choices'][0]['message']['content'])) {
            $raw_text = $body['choices'][0]['message']['content'];
        }
        if (empty($raw_text) && $registry) {
            $raw_text = $registry->extract_content($active_provider, $body);
        }
        $json_text = preg_replace('/```(json)?/', '', $raw_text);
        $hooks = json_decode(trim($json_text), true);

        if (! $hooks || ! is_array($hooks)) {
            wp_send_json_success(array('hooks' => array('Are you a GENIUS?', 'Most people FAIL this quiz!'), 'source' => 'fallback'));
        }

        wp_send_json_success(array('hooks' => $hooks, 'source' => 'ai'));
    }

    /**
     * AJAX: Generate SEO Metadata
     */
    public function ajax_generate_seo()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error(__('Access denied', 'mcq-video-studio'));
        }

        // @FIX 1.6.0 (prompt SSOT, owner-approved): the prompt is now BUILT
        // SERVER-SIDE from structured arguments so the browser Studio and the
        // automatic Video Scheduler can never drift apart. Legacy raw-prompt
        // POSTs are still honored for older clients.
        $topic = isset($_POST['topic']) ? sanitize_text_field(wp_unslash($_POST['topic'])) : '';
        if ($topic !== '') {
            $questions = array();
            $raw_q = isset($_POST['questions']) ? wp_unslash($_POST['questions']) : array(); // phpcs:ignore
            if (is_string($raw_q)) {
                $raw_q = json_decode($raw_q, true);
            }
            if (is_array($raw_q)) {
                foreach ($raw_q as $rq) {
                    if (is_array($rq) && !empty($rq['question'])) {
                        $questions[] = array('question' => sanitize_text_field((string) $rq['question']));
                    } elseif (is_string($rq) && trim($rq) !== '') {
                        $questions[] = array('question' => sanitize_text_field($rq));
                    }
                }
            }
            $platform = isset($_POST['platform']) ? sanitize_key($_POST['platform']) : 'shorts';
            $keywords = isset($_POST['keywords']) ? sanitize_text_field(wp_unslash($_POST['keywords'])) : '';
            $prompt   = self::build_seo_prompt($topic, $questions, $platform, $keywords);
        } else {
            $prompt = isset($_POST['prompt']) ? sanitize_textarea_field(wp_unslash($_POST['prompt'])) : '';
        }

        if (strlen($prompt) > 30000) {
            wp_send_json_error(__('Prompt too large for AI processing.', 'mcq-video-studio'));
        }

        $seo_lock = 'mcqvs_seo_lock_' . md5($prompt);
        if (get_transient($seo_lock)) {
            wp_send_json_error(__('SEO generation already in progress. Please wait.', 'mcq-video-studio'));
        }
        set_transient($seo_lock, 1, 10);

        $result = $this->request_seo_completion($prompt);
        delete_transient($seo_lock);

        if (is_wp_error($result)) {
            wp_send_json_success(self::fallback_seo_meta());
        }

        wp_send_json_success(array_merge($result, array('source' => 'ai')));
    }

    /**
     * SSOT SEO prompt builder (single authority for browser + auto jobs).
     *
     * @NEW 1.6.0 — owner-approved prompt restructure: adds the `youtube_long`
     * platform context implementing the 2026 YouTube metadata rules (keyword
     * in first 50-60 title chars, keyword in first description lines, 200-300
     * word description with CTA + site link, 3-5 hashtags at the END because
     * >15 makes YouTube ignore ALL of them, 5-8 backend tag phrases).
     * Legacy tiktok/shorts/reels contexts keep their proven wording.
     *
     * @param string $topic     Topic / quiz name.
     * @param array  $questions List of arrays with 'question' (or plain strings).
     * @param string $platform  tiktok|shorts|reels|youtube_long.
     * @param string $keywords  Optional target keywords.
     * @return string
     */
    public static function build_seo_prompt($topic, $questions, $platform = 'shorts', $keywords = '')
    {
        $q_lines = array();
        $i = 0;
        foreach ((array) $questions as $q) {
            if ($i >= 5) {
                break;
            }
            $text = is_array($q) ? (string) ($q['question'] ?? '') : (string) $q;
            $text = trim($text);
            if ($text === '') {
                continue;
            }
            $i++;
            $q_lines[] = $i . '. ' . $text;
        }
        $q_context = implode("\n", $q_lines);

        $platform_context = array(
            'tiktok'       => 'TikTok rewards long, keyword-rich descriptions (up to 4000 chars) for search rankings.',
            'shorts'       => 'YouTube Shorts needs high-density hashtags and concise titles (impactful 50-60 chars).',
            'reels'        => 'Instagram Reels favors aesthetic descriptions and niche trending hashtags.',
            'youtube_long' => 'YouTube LONG-FORM (2026 rules): title max 100 chars with the primary keyword inside the FIRST 50-60 chars plus a benefit/curiosity hook; description 200-300 words with the primary keyword in the FIRST 1-2 sentences, a clear value summary, a call-to-action visiting ' . home_url() . ' for free practice MCQs and PDFs, and EXACTLY 3-5 hashtags placed at the VERY END (first 3 display above the title; more than 15 makes YouTube ignore ALL hashtags); plus 5-8 hidden backend tag phrases (comma-separated keywords, max 500 chars total) starting with the exact primary keyword.',
        );
        $platform_context_str = $platform_context[$platform] ?? $platform_context['shorts'];

        if ($platform === 'youtube_long') {
            return "You are a YouTube SEO specialist for educational quiz channels (exam prep: CSS, PMS, FPSC, competitive exams).\n\nCONTENT CONTEXT:\nTopic: {$topic}\nQuestions in this video:\n{$q_context}\n\nTARGET KEYWORDS: {$keywords}\nPLATFORM RULES: {$platform_context_str}\n\nTASK: Return JSON ONLY (no markdown, no code blocks) with exactly these keys:\n1. \"title\": string, <=70 chars, keyword-first, one power word, NO hashtags, no clickbait lies.\n2. \"description\": string, 200-300 words, keyword in first sentence, ends with a CTA line linking " . home_url() . " then a blank line then 3-5 hashtags (include one branded hashtag #TheQuizWire).\n3. \"hashtags\": array of 3-5 strings each starting with '#'.\n4. \"tags\": array of 5-8 keyword phrases (no '#').\nTone: professional, exam-focused, encouraging.";
        }

        return "\n                You are a world-class Social Media Growth Expert specializing in {$platform}.\n                \n                CONTENT CONTEXT:\n                Topic: {$topic}\n                Questions:\n                {$q_context}\n                \n                STRATEGIC FOCUS:\n                Target Keywords: {$keywords}\n                Platform Context: {$platform_context_str}\n                \n                TASK: Generate viral, search-optimized metadata in JSON format.\n                \n                STRUCTURE:\n                1. \"title\": \n                   - @FIX 2026-10-04 (owner-approved QUESTION-FIRST formula): the title IS the FIRST QUESTION of the video, verbatim - that is the curiosity gap. Max 70 chars, keep the question mark, strip any option prefixes.\n                   - Add at most ONE emoji at the end. NEVER category labels like \"5 Questions About X\" or \"X Quiz\" - they create no gap.\n                   - The same rule applies for TikTok and Reels.\n                \n                2. \"description\": \n                   - Start with a \"Psychological Hook\" (curiosity gap).\n                   - Incorporate \"Target Keywords\" naturally for algorithm indexing.\n                   - Include a \"Soft CTA\" (e.g., \"Check the comments to see if you are a genius\").\n                   - Length: 3-5 sentences (SEO intensive).\n                \n                3. \"tags\": \n                   - Use the \"3-3-3 Hierarchy\":\n                     - 3 Broad (e.g., #quiz, #trivia, #challenge)\n                     - 3 Niche (related to the topic: {$topic})\n                     - 3 Search-Specific (based on Keywords: {$keywords})\n                   - Return as an array of strings.\n                \n                Tone: Challenging, high-IQ, slightly mysterious.\n                JSON ONLY. NO MARKDOWN. NO CODE BLOCKS.\n            ";
    }

    /**
     * Provider-rotation SEO completion request (shared by AJAX + auto jobs).
     *
     * @NEW 1.6.0 extracted from ajax_generate_seo so server-side job creation
     * uses the exact same keys/models/logging as the Studio button.
     *
     * @param string $prompt
     * @return array|WP_Error Normalized seo meta array on success.
     */
    public function request_seo_completion($prompt)
    {
        $registry = class_exists('VS_Provider_Registry') ? VS_Provider_Registry::get_instance() : null;

        if ($registry) {
            $rotation = $registry->get_next_model('seo');
            $active_provider = $rotation['provider'];
            $model = $rotation['model'];
            $api_key = $registry->get_rotation_api_key($active_provider);
        } else {
            $active_provider = 'gemini';
            $model = get_option('mcqvs_gemini_model_id', 'gemini-3-flash-preview');
            $api_key = $this->get_api_key();
        }

        if (empty($api_key)) {
            return new WP_Error('no_api_key', 'No SEO provider API key configured.');
        }

        $url = $registry ? $registry->build_rotation_url($active_provider, $model) : "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key=" . $api_key;
        if ($registry) {
            $request_body = $registry->build_request_body(
                $active_provider,
                array(array('role' => 'user', 'content' => $prompt)),
                $model,
                array('json_mode' => true)
            );
        } else {
            $request_body = array('contents' => array(array('parts' => array(array('text' => $prompt)))));
        }
        $post_args = array(
            'body'    => json_encode($request_body),
            'timeout' => 20,
        );
        if ($registry) {
            $post_args['headers'] = $registry->build_rotation_headers($active_provider, $url);
        } else {
            $post_args['headers'] = array('Content-Type' => 'application/json');
        }
        $start_time = microtime(true);
        $response = wp_remote_post($url, $post_args);
        $duration = microtime(true) - $start_time;

        // Central API Logging (unchanged behavior)
        if (class_exists('VS_Error_Logger')) {
            VS_Error_Logger::get_instance()->log_api($url, 'POST', array('prompt' => $prompt), $response, $duration);
        }

        if (is_wp_error($response)) {
            return $response;
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        $raw_text = '';
        if (isset($body['candidates'][0]['content']['parts'][0]['text'])) {
            $raw_text = $body['candidates'][0]['content']['parts'][0]['text'];
        } elseif (isset($body['choices'][0]['message']['content'])) {
            $raw_text = $body['choices'][0]['message']['content'];
        }
        if (empty($raw_text) && $registry) {
            $raw_text = $registry->extract_content($active_provider, $body);
        }
        $json_text = preg_replace('/```(json)?/', '', (string) $raw_text);
        $result = json_decode(trim($json_text), true);

        if (! $result || ! is_array($result)) {
            return new WP_Error('bad_ai_json', 'AI returned unparsable SEO metadata.');
        }

        return self::normalize_seo_meta($result);
    }

    /**
     * Server-side SEO metadata generation for auto video jobs.
     *
     * @NEW 1.6.0 Called by VS_Video_Scheduler::build_video_jobs() ONCE at job
     * creation (questions/topic/format known; stable across retries/re-pushes).
     *
     * @param string $topic
     * @param array  $questions Reserved question rows.
     * @param array  $opts {platform, keywords}
     * @return array Normalized seo meta (source: ai|fallback).
     */
    public function generate_seo_meta($topic, $questions, $opts = array())
    {
        $platform = sanitize_key($opts['platform'] ?? 'shorts');
        $keywords = sanitize_text_field($opts['keywords'] ?? '');
        $prompt = self::build_seo_prompt((string) $topic, (array) $questions, $platform, $keywords);
        $result = $this->request_seo_completion($prompt);
        if (is_wp_error($result)) {
            $fb = self::fallback_seo_meta();
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log('SEO generation failed (' . $result->get_error_message() . '); using fallback metadata.', 'warning');
            }
            return $fb;
        }
        return $result;
    }

    /**
     * Normalize AI seo payload to the SSOT shape consumed by Buffer + YT publisher.
     *
     * @NEW 1.6.0
     * @param array $result
     * @return array {title, description, hashtags[], tags[], source}
     */
    public static function normalize_seo_meta($result)
    {
        $title = isset($result['title']) ? sanitize_text_field((string) $result['title']) : '';
        $description = isset($result['description']) ? sanitize_textarea_field((string) $result['description']) : '';
        $hashtags = array();
        $raw_tags = $result['hashtags'] ?? ($result['tags'] ?? array());
        foreach ((array) $raw_tags as $t) {
            $t = trim(sanitize_text_field((string) $t));
            if ($t === '') {
                continue;
            }
            $hashtags[] = (strpos($t, '#') === 0) ? $t : '#' . $t;
        }
        $hashtags = array_values(array_unique($hashtags));
        // YouTube ignores ALL hashtags above 15 — hard cap at 5 per 2026 guidance.
        $hashtags = array_slice($hashtags, 0, 5);
        $tags = array();
        foreach ((array) ($result['tags'] ?? array()) as $t) {
            $t = trim(sanitize_text_field((string) $t));
            if ($t !== '') {
                $tags[] = $t;
            }
        }
        $tags = array_slice(array_values(array_unique($tags)), 0, 8);
        return array(
            'title'       => $title,
            'description' => $description,
            'hashtags'    => $hashtags,
            'tags'        => $tags,
            'source'      => 'ai',
        );
    }

    /**
     * Offline-safe fallback metadata (same shape as normalize_seo_meta).
     *
     * @NEW 1.6.0
     * @return array
     */
    public static function fallback_seo_meta()
    {
        return array(
            'title'       => 'Only 1% Can Pass This! 🧠',
            'description' => 'Test your knowledge with these impossible questions! Don\'t forget to comment your score!',
            'hashtags'    => array('#quiz', '#trivia', '#viral'),
            'tags'        => array(),
            'source'      => 'fallback',
        );
    }

}
