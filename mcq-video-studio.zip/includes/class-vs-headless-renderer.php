<?php

/**
 * Headless Renderer — PHP Bridge to Node.js/Puppeteer Render Service
 *
 * Spawns the Node.js render process as a background child process.
 * Handles auth token generation, process management, and logging.
 *
 * Architecture:
 *   PHP calls VS_Headless_Renderer::render_job($job_id)
 *   → generates one-time auth token
 *   → spawns: node render.js --job=X --url=Y --nonce=Z --auth-token=T
 *   → Node.js + Puppeteer + Headless Chrome renders the video
 *   → JS auto-runner uploads blob to PHP → R2 → Buffer
 *   → Process exits
 *
 * @package MCQ_Video_Studio
 * @subpackage Includes
 * @since 1.0.0
 */

if (! defined('ABSPATH')) {
    exit;
}

class VS_Headless_Renderer
{
    private static $instance = null;

    public static function get_instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Convert a logo URL into a local filesystem path the Node media-prep can read.
     *
     * Priority:
     *   1. WordPress upload URL  -> wp_upload_dir() basedir
     *   2. Plugin assets URL     -> MCQVS_PLUGIN_DIR (brand-logo copied by the Assets tab)
     *   3. Anything else (external CDN) -> returned unchanged; Node downloads it.
     *
     * Scheme (http/https) is stripped before comparison so behind-proxy setups where
     * the public scheme differs from the server scheme still resolve locally.
     *
     * @param string $logo_url
     * @return string
     */
    /**
     * @NEW 2026-08-11: Strip emoji from text that will be DRAWN on the video canvas.
     * node-canvas cannot reliably render color emoji or flag glyphs (monochrome at
     * best, tofu boxes on minimal VPS fonts), so hooks containing emoji are cleaned
     * before they reach the renderer. Captions/titles are NOT affected — they use
     * the original string (Buffer {hook} placeholder).
     *
     * @param string $text
     * @return string
     */
    private static function strip_emoji_for_screen($text)
    {
        $text = trim((string) $text);
        if ($text === '') {
            return '';
        }
        // Emoji blocks: pictographs, emoticons, dingbats, misc symbols, transport,
        // geometric/arrows, enclosing keycap, variation selectors (U+FE00-FE0F),
        // regional indicators (flags), skin tones, ZWJ, ©/® standalone.
        $cleaned = preg_replace(
            '/[\x{1F000}-\x{1FAFF}\x{2600}-\x{27BF}\x{2B00}-\x{2BFF}\x{FE00}-\x{FE0F}\x{1F1E6}-\x{1F1FF}\x{1F3FB}-\x{1F3FF}\x{200D}\x{20E3}\x{3030}\x{00A9}\x{00AE}]/u',
            '',
            $text
        );
        if (null === $cleaned) {
            return $text; // malformed UTF-8 — leave as-is (sanitizer already validated upstream)
        }
        // Collapse whitespace left by removed glyphs. Keep terminal ? ! (curiosity
        // hooks depend on them) — only drop dangling separators at the very edges.
        $cleaned = preg_replace('/\s{2,}/', ' ', $cleaned);
        $cleaned = trim($cleaned, " \t\n\r\0\x0B");
        $cleaned = trim($cleaned, "-–—:;,.");
        $cleaned = trim($cleaned, "…");
        return $cleaned;
    }

    private static function normalize_logo_path($logo_url)
    {
        $logo_url = trim((string) $logo_url);
        if ('' === $logo_url) {
            return '';
        }

        $candidate = strtolower(preg_replace('~^https?://~i', '', $logo_url));

        // 1) WordPress uploads -> local uploads dir.
        $upload_dir = wp_upload_dir();
        $base_url   = trailingslashit($upload_dir['baseurl']);
        $base_no_scheme = strtolower(preg_replace('~^https?://~i', '', $base_url));
        if (strpos($candidate, $base_no_scheme) === 0) {
            $relative = substr(preg_replace('~^https?://~i', '', $logo_url), strlen($base_no_scheme));
            $local = $upload_dir['basedir'] . '/' . $relative;
            // @FIX 2026-08-13 (LOGO E2E): if the mapped local uploads file does not
            //       actually exist (CDN'd uploads, moved media, host/DNS drift, or the
            //       file lives on a separate storage), do NOT hand Node a dead path —
            //       return the original URL instead so Node downloads it over HTTP.
            return (is_file($local)) ? $local : $logo_url;
        }

        // 2) Plugin assets URL -> local plugin dir.
        if (defined('MCQVS_PLUGIN_URL') && defined('MCQVS_PLUGIN_DIR')) {
            $plugin_base_url = trailingslashit(MCQVS_PLUGIN_URL);
            $plugin_base_no_scheme = strtolower(preg_replace('~^https?://~i', '', $plugin_base_url));
            if (strpos($candidate, $plugin_base_no_scheme) === 0) {
                $relative = substr(preg_replace('~^https?://~i', '', $logo_url), strlen($plugin_base_no_scheme));
                $local = MCQVS_PLUGIN_DIR . $relative;
                // Same hardening as uploads: verify the copied brand-logo file exists on
                // disk (the Assets tab writes it into assets/images/). If it is missing,
                // fall back to the URL so Node's media-prep downloads it — otherwise the
                // logo silently vanishes from every headless render.
                return (is_file($local)) ? $local : $logo_url;
            }
        }

        // 3) External URL -> return as-is (Node media-prep downloads it).
        return $logo_url;
    }

    /**
     * @FIX 2026-07-09: Auto-authenticate headless render sessions via cookie.
     *
     *       render.js sets a browser cookie `mcqvs_render_auth=<token>` before
     *       loading the Studio page. No PHP code was reading this cookie — the
     *       Studio page gate (`current_user_can('manage_options')`) killed the
     *       headless browser session immediately, so the auto-runner never ran
     *       and every headless render silently failed.
     *
     *       Hook into 'init' at priority 1 (before any page gate) to read the
     *       cookie, verify the token against the transient, and log the render
     *       service user in for the duration of the request.
     */
    /**
     * Shared resolver used by both the `init` handler and the `determine_current_user`
     * filter. Returns the mcqvs_render user ID when a valid render auth token is present
     * on a render endpoint, otherwise 0.
     *
     * @return int
     */
    private static function resolve_render_user_id()
    {
        $token = '';
        if (!empty($_COOKIE['mcqvs_render_auth'])) {
            $token = sanitize_text_field(wp_unslash($_COOKIE['mcqvs_render_auth']));
        } elseif (!empty($_GET['auth_token'])) {
            $token = sanitize_text_field(wp_unslash($_GET['auth_token']));
        }
        if (empty($token)) {
            return 0;
        }

        // @FIX 2026-07-14: accept the token on the auto_run page AND on the render-service
        //        AJAX actions. The original gate required $_GET['auto_run'] which only exists
        //        on the page request, so every AJAX poll stayed anonymous and WP returned
        //        HTTP 400 (no wp_ajax_nopriv_* handler), stranding renders in `rendering`.
        $is_render_endpoint = false;
        if (!empty($_GET['auto_run'])) {
            $is_render_endpoint = true;
        } elseif (!empty($_GET['action'])) {
            $render_actions = array(
                'mcqvs_get_job_status',
                'mcqvs_update_job_status',
                'mcqvs_upload_rendered_video',
                'mcqvs_get_studio_sources',
                'mcqvs_get_studio_data',
                'mcqvs_remote_log',
            );
            $is_render_endpoint = in_array(sanitize_key($_GET['action']), $render_actions, true);
        } elseif (!empty($_POST['action'])) {
            $render_actions_post = array(
                'mcqvs_get_job_status',
                'mcqvs_update_job_status',
                'mcqvs_upload_rendered_video',
                'mcqvs_remote_log',
            );
            $is_render_endpoint = in_array(sanitize_key($_POST['action']), $render_actions_post, true);
        }
        if (!$is_render_endpoint) {
            return 0;
        }

        $job_id = sanitize_text_field($_GET['job_id'] ?? $_GET['auto_run_job'] ?? $_POST['job_id'] ?? '');
        if (empty($job_id)) {
            return 0;
        }

        if (!self::verify_auth_token($job_id, $token)) {
            return 0;
        }
        return (int) self::ensure_render_user();
    }

    /**
     * @FIX (audit): Accept the auth token from BOTH the cookie AND the URL query
     *        string. The original gate required $_COOKIE['mcqvs_render_auth'], which is
     *        silently dropped on sites behind Cloudflare (or any proxy that strips
     *        cookies) and by some Playwright secure/httpOnly cookie configurations. When
     *        the cookie is missing the request is anonymous, WP redirects admin.php to
     *        wp-login.php, render_runner_page() never runs, and the 30s readiness gate
     *        times out. Reading the URL token (added by render_job via add_query_arg)
     *        makes the headless pipeline survive cookie loss. The token is still bound
     *        to a one-time job-scoped transient, so accepting it from the URL is safe.
     */
    public static function maybe_auth_from_cookie()
    {
        // @FIX (2026-07-16 ROOT CAUSE): This runs on `init` (priority 1). WP defines
        //        WP_ADMIN only inside wp-admin/admin.php, which loads AFTER wp-settings.php
        //        fires `init`, so is_admin() is FALSE here. The old `!is_admin()` guard made
        //        this return early on EVERY request — the token was never verified, the user
        //        was never elevated, and auth_redirect() (at admin_init) saw an anonymous
        //        request and sent the headless browser to wp-login.php. That is the 30s
        //        readiness timeout. We drop the is_admin() guard and rely on the positive
        //        endpoint check inside resolve_render_user_id().
        $render_user_id = self::resolve_render_user_id();
        if (!empty($render_user_id)) {
            wp_set_current_user($render_user_id);

            // @FIX (ROOT CAUSE 2026-07-17): auth_redirect() (admin_init) validates the
            //        real wordpress_logged_in_* cookie directly via wp_validate_auth_cookie()
            //        and IGNORES determine_current_user. On the FIRST headless page load the
            //        browser carries only mcqvs_render_auth, so auth_redirect() sees no valid
            //        WP cookie and redirects to wp-login.php?...&reauth=1.
            //
            //        We therefore mint a deterministic, job-scoped logged-in cookie and
            //        inject it into $_COOKIE for THIS request so auth_redirect()'s own
            //        wp_validate_auth_cookie() passes now. The token embedded in the cookie
            //        is registered directly in the render user's session store below (the
            //        same meta WP's WP_Session_Tokens reads), so wp_validate_auth_cookie()
            //        accepts it without us ever calling wp_set_auth_cookie()/WP_Session_Tokens
            //        (which on this host fatals at init priority 1 with a class-not-found).
            //
            //        CRITICAL: the token is DETERMINISTIC for the (user, job) pair, so the
            //        page load (mints the studio nonce) and every AJAX poll (verifies it)
            //        compute the identical wp_get_session_token() and the nonce verifies.
            //
            //        If the browser already replayed a valid WP cookie (subsequent AJAX
            //        polls), do nothing — the token is already stable and we must not
            //        overwrite $_COOKIE with a new value.
            $already_authed = false;
            if (!empty($_COOKIE[LOGGED_IN_COOKIE])) {
                $validated = wp_validate_auth_cookie($_COOKIE[LOGGED_IN_COOKIE], 'logged_in');
                if ((int) $validated === (int) $render_user_id) {
                    $already_authed = true;
                }
            }

            if (!$already_authed) {
                $job_id = sanitize_text_field($_GET['job_id'] ?? $_GET['auto_run_job'] ?? $_POST['job_id'] ?? '');
                $token  = self::render_session_token($render_user_id, $job_id);
                self::register_render_session($render_user_id, $token);
                $expiration = time() + 2 * HOUR_IN_SECONDS;
                $_COOKIE[LOGGED_IN_COOKIE] = wp_generate_auth_cookie($render_user_id, $expiration, 'logged_in', $token);
                if (is_ssl()) {
                    $_COOKIE[SECURE_AUTH_COOKIE] = wp_generate_auth_cookie($render_user_id, $expiration, 'secure_auth', $token);
                } else {
                    $_COOKIE[AUTH_COOKIE] = wp_generate_auth_cookie($render_user_id, $expiration, 'auth', $token);
                }
            }

            // @DEBUG (2026-07-18): Temporary diagnostics to pin the 403 nonce mismatch.
            //        Logs the resolved user, the session token WP will use for nonces, and
            //        whether the cookie was freshly minted. Remove once root cause confirmed.
            if (class_exists('VS_Error_Logger')) {
                $dbg_token = '';
                $dbg_cookie = $_COOKIE[LOGGED_IN_COOKIE] ?? '';
                $parsed = !empty($dbg_cookie) ? wp_parse_auth_cookie($dbg_cookie, 'logged_in') : false;
                if (is_array($parsed)) {
                    $dbg_token = $parsed['token'] ?? '';
                }
                VS_Error_Logger::get_instance()->log(
                    'render.auth.debug',
                    'info',
                    array(
                        'phase'        => !empty($_POST['action']) ? 'ajax' : 'page',
                        'action'       => sanitize_key($_POST['action'] ?? $_GET['action'] ?? ''),
                        'user_id'      => (int) $render_user_id,
                        'already_auth' => $already_authed ? 1 : 0,
                        'session_token'=> $dbg_token,
                        'cookie_set'   => !empty($dbg_cookie) ? 1 : 0,
                        'is_ssl'       => is_ssl() ? 1 : 0,
                    )
                );
            }
        }
    }

    /**
     * @FIX (2026-07-17): Deterministic session token for a render lifecycle.
     *        Derived from the render user + job id so it is identical on the render page
     *        request (nonce mint) and every AJAX poll (nonce verify). Not guessable without
     *        the site's auth salt.
     *
     * @param int    $user_id
     * @param string $job_id
     * @return string 43-char session token.
     */
    private static function render_session_token($user_id, $job_id)
    {
        $material = 'mcqvs_render_session|' . (int) $user_id . '|' . (string) $job_id;
        return substr(wp_hash($material, 'auth'), 0, 43);
    }

    /**
     * @FIX (2026-07-17): Register the deterministic render session token by writing it
     *        DIRECTLY into the render user's `session_tokens` user meta in the exact shape
     *        WP_Session_Tokens expects (keyed by hash('sha256', $token)). We avoid calling
     *        WP_Session_Tokens / wp_set_auth_cookie because on this host those fatally
     *        class-not-found at init priority 1. wp_validate_auth_cookie() (used by
     *        auth_redirect) reads this same meta via the real WP_Session_Tokens instance
     *        later, so the injected cookie validates. Idempotent + TTL-aware.
     *
     * @param int    $user_id
     * @param string $session_token
     */
    private static function register_render_session($user_id, $session_token)
    {
        $key      = function_exists('hash') ? hash('sha256', $session_token) : $session_token;
        $sessions = get_user_meta((int) $user_id, 'session_tokens', true);
        if (!is_array($sessions)) {
            $sessions = array();
        }
        // Already present and unexpired → nothing to do.
        if (!empty($sessions[$key]) && !empty($sessions[$key]['expiration']) && $sessions[$key]['expiration'] > time()) {
            return;
        }
        $now = time();
        foreach ($sessions as $k => $s) {
            if (empty($s['expiration']) || $s['expiration'] < $now) {
                unset($sessions[$k]);
            }
        }
        $sessions[$key] = array(
            'expiration' => $now + 2 * HOUR_IN_SECONDS,
            'login'      => $now,
            'ip'         => isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : '',
            'ua'         => 'MCQVS-Render-Service',
        );
        update_user_meta((int) $user_id, 'session_tokens', $sessions);
    }

    /**
     * @FIX (2026-07-16): Belt-and-suspenders. Hook the same resolution onto
     *        `determine_current_user` (WP's canonical current-user lookup, which runs
     *        before auth_redirect). This guarantees the render user wins even if another
     *        caller resets the current user between `init` and `auth_redirect`. Only fires
     *        for render endpoints carrying a valid token, so normal admin requests are
     *        untouched ($user_id passed through unchanged).
     *
     * @param int|false $user_id
     * @return int|false
     */
    public static function filter_determine_render_user($user_id)
    {
        $render_user_id = self::resolve_render_user_id();
        if (!empty($render_user_id)) {
            return $render_user_id;
        }
        return $user_id;
    }

    /**
     * Render a single job via headless Chrome.
     *
     * @param string $job_id The job ID to render.
     * @return bool|WP_Error True on success, WP_Error on failure.
     */
	public function render_job($job_id)
	{
		$node_path = get_option('mcqvs_node_path', '/usr/bin/node');
		if (empty($node_path)) {
			$node_path = '/usr/bin/node';
		}
		$ffmpeg_path = get_option('mcqvs_ffmpeg_path', '');
		if (empty($ffmpeg_path)) {
			$ffmpeg_path = self::auto_detect_ffmpeg();
		}
		if (empty($ffmpeg_path)) {
			return new WP_Error('no_ffmpeg', 'FFmpeg not found. Set mcqvs_ffmpeg_path in Settings > Headless, or install ffmpeg on the host.');
		}
		$timeout = absint(get_option('mcqvs_render_timeout', 900));
		// @FIX (cross-file audit 2026-07-07): Existing installs persist a 180s render
		//              timeout from the previous default. New evidence (logs at 5–10 min
		//              before orphan-kill fires, render.js self-exits at the timeout value,
		//              encoding+upload alone takes > 3 min) shows 180s is too short.
		//              Migrate legacy persisted values < 600s up to 900s on the fly so this
		//              call site behaves correctly without forcing each admin to re-save.
		if ($timeout < 600) {
			$timeout = 900;
		}

        // @FIX 2026-07-06: Pre-flight R2 public domain check to prevent stuck jobs
        if (class_exists('VS_Job_Repository')) {
            $job_repo = VS_Job_Repository::init();
            $job = $job_repo->get_job($job_id);
            if ($job) {
                $settings = is_string($job['settings'] ?? '') ? json_decode($job['settings'], true) : ($job['settings'] ?? array());
                $save_mode = $settings['save_mode'] ?? get_option('mcqvs_delivery_mode', 'local');
                if (in_array($save_mode, array('r2', 'r2_buffer'), true)) {
                    $public_domain = trim((string) get_option('mcqvs_r2_public_domain', ''));
                    if (empty($public_domain)) {
                        $err_msg = "R2 public domain not configured. Set 'mcqvs_r2_public_domain' in Settings > Cloudflare R2 to avoid stuck jobs.";
                        if (class_exists('VS_Error_Logger')) {
                            VS_Error_Logger::get_instance()->log($err_msg, 'error', array('job_id' => $job_id, 'save_mode' => $save_mode));
                        }
                        // Fail the job immediately instead of spawning a render that will fail later
                        $job_repo->update_status($job_id, VS_Job_Status::FAILED, array('error_message' => $err_msg));
                        return new WP_Error('r2_config_missing', $err_msg);
                    }
                }
            }
        }

        $render_script = MCQVS_PLUGIN_DIR . 'render-service/render-node.js';
        if (!file_exists($render_script)) {
            return new WP_Error('missing_script', 'Render service script not found: ' . $render_script);
        }

        if (!file_exists($node_path) || !is_executable($node_path)) {
            return new WP_Error('missing_node', 'Node.js not found at: ' . $node_path . '. Configure in Settings > Headless Rendering.');
        }

        // @FIX 2026-07-18 (server-side render): Pre-flight the Node render deps.
        //              render-node.js requires `canvas` (node-canvas) for frame drawing.
        //              Previously the dependency was Playwright/Chrome; that path is gone.
        //              Fail fast if node-canvas is missing so the job is marked FAILED now
        //              instead of wedging in `rendering` until the orphan-kill fires.
        // @FIX 2026-07-19: The old is_dir() heuristic returned false positives when
        //              canvas was installed via symlink or under a different layout.
        //              Use the same `node -e "require('canvas')"` probe the Settings
        //              diagnostic uses — authoritative cross-platform check.
        $rs_dir  = dirname($render_script);
        // @FIX 2026-07-31: `process.chdir()` inside a `node -e` eval does NOT update
        //              `module.paths` — require() still resolves from the startup cwd
        //              (see require stack "<home>/[eval]"), so the probe always reported
        //              "Cannot find module 'canvas'" even when node-canvas was installed.
        //              Use the shell `cd ... && node -e` form, matching the Settings
        //              diagnostic (ajax_test_headless) which sets the real cwd before
        //              Node starts. Verified on Node 22/25.
        $canvas_probe = @shell_exec('cd ' . escapeshellarg($rs_dir) . ' && ' . escapeshellarg($node_path) . ' -e "require(\'canvas\');console.log(\'ok\')" 2>&1');
        if (trim((string) $canvas_probe) !== 'ok') {
            $err_msg = 'Render dependency missing — run `cd render-service && npm install --omit=dev` on the server (requires node-canvas).';
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log($err_msg, 'error', array('job_id' => $job_id, 'probe_output' => trim((string) $canvas_probe)));
            }
            return new WP_Error('missing_render_deps', $err_msg);
        }

        // ── Build the job payload JSON (no admin-ajax, no nonce, no browser) ──
        $job_repo = class_exists('VS_Job_Repository') ? VS_Job_Repository::init() : null;
        if (!$job_repo) {
            return new WP_Error('no_repo', 'Job repository unavailable.');
        }
        $job = $job_repo->get_job($job_id);
        if (!$job) {
            return new WP_Error('no_job', 'Job not found: ' . $job_id);
        }

        $settings   = is_string($job['settings'] ?? '') ? json_decode($job['settings'], true) : ($job['settings'] ?? array());
        $settings   = is_array($settings) ? $settings : array();
        $quiz_data  = is_string($job['quiz_data'] ?? '') ? json_decode($job['quiz_data'], true) : ($job['quiz_data'] ?? array());
        $quiz_data  = is_array($quiz_data) ? $quiz_data : array();
        // Normalize legacy {ids:[...]} form to full question objects.
        $quiz_data  = VS_Job_Repository::normalize_quiz_data($job['quiz_data'] ?? '', class_exists('VS_MCQ_Repository') ? new VS_MCQ_Repository() : null);
        if (empty($quiz_data)) {
            $err_msg = 'Job has no questions to render.';
            $job_repo->update_status($job_id, VS_Job_Status::FAILED, array('error_message' => $err_msg));
            return new WP_Error('no_questions', $err_msg);
        }

        $video_format = get_option('mcqvs_video_format', 'shorts');
        if (!empty($settings['save_mode_video_format'])) {
            $video_format = $settings['save_mode_video_format'];
        }
        $is_youtube = ($video_format === 'youtube');
        $width  = $is_youtube ? 1920 : 1080;
        $height = $is_youtube ? 1080 : 1920;

        // @FIX 2026-07-21: Scale render timeout to frame count so long renders are not
        //       killed by the orphan-kill before they finish. Shorts @24fps with N
        //       questions produces ~N*384 frames (~16s per question).
        //       Each frame takes ~1.3s to render (canvas + TTS download + ffmpeg
        //       compositing). Added per-question overhead for voiceover + encoding
        //       buffer. The previous 1.0 sec/frame + 120s was too tight — a 5-question
        //       shorts render needed ~2360s but was given only 2040s, causing a kill
        //       at 91% progress (elapsed=2148s > budget=2100s).
        // @FIX 2026-07-21: Hard 60-minute (3600s) floor on top of the frame-based
        //       estimate. The cron orphan-kill budget is now per_job_timeout+120,
        //       so a 3600s timeout means the cron kill would not fire until 62 min
        //       — comfortably past the slowest realistic render while still protecting
        //       against true hangs. The frame-based formula can still scale higher
        //       for jobs with many questions.
        $question_count = count($quiz_data);
        $is_youtube_fps = ($video_format === 'youtube') ? 30 : 24;
        $estimated_frames = $question_count * 16 * $is_youtube_fps;
        $sec_per_frame = 1.3;
        $encode_buffer = 180;
        $frame_timeout = (int) ceil($estimated_frames * $sec_per_frame) + $encode_buffer;
        $timeout = max((int) $timeout, $frame_timeout, 3600);

        // @NORMALIZE (2026-07-18): Map planner's persisted keys to renderer-expected names.
        // The content planner saves: template, font, music, bg_video, save_mode.
        // The server renderer reads: bgVideoUrl, bgMusicUrl, fontOverride, voiceover, sfxEnabled, etc.
        $assets_url = MCQVS_PLUGIN_URL . 'assets/js';
        $normalized_settings = array();
        if (!empty($settings['template'])) {
            $normalized_settings['template'] = $settings['template'];
            $normalized_settings['currentTemplate'] = $settings['template'];
        }
        if (!empty($settings['font'])) $normalized_settings['fontOverride'] = $settings['font'];
        if (!empty($settings['music'])) {
            $musicFile = strtolower(rtrim($settings['music'], '.mp3')) . '.mp3';
            // @FIX: Build the music URL through mcqvs_assets_url() so external assets are
            //       honoured. The previous code used MCQVS_PLUGIN_URL . 'assets/js/audio/music/'
            //       (note the bogus 'assets/js' prefix from $assets_url), a folder that does
            //       not exist — so every headless render's music download 404'd / failed.
            $normalized_settings['bgMusicUrl'] = mcqvs_assets_url('audio/music/') . $musicFile;
            $normalized_settings['musicEnabled'] = true;
            // @FIX: Resolve the local filesystem path for music under assets/audio/music/
            //       so the Node renderer reads from disk instead of an HTTP round-trip that
            //       silently failed on servers with self-signed certs / blocked outbound
            //       requests (mirrors the bg_video local-path optimization below).
            $music_local = mcqvs_assets_dir('audio/music/') . $musicFile;
            if (@file_exists($music_local)) {
                $normalized_settings['bgMusicPath'] = $music_local;
            }
        }
        if (!empty($settings['bg_video'])) {
            $normalized_settings['bgVideoUrl'] = esc_url_raw($settings['bg_video']);
            // @FIX 2026-07-31: Also resolve the local filesystem path when the bg video
            //       lives under the plugin's assets/bg-videos dir. The Node media-prep
            //       reads it from disk instead of an HTTP round-trip, which silently failed
            //       on servers with self-signed certs / blocked outbound requests and left
            //       the rendered video with no background at all.
            // @FIX 2026-08-11 (ROBUST): the URL-prefix match above is fragile — it breaks
            //       when the site host differs (www vs non-www, http vs https), when the
            //       plugin URL changed after the job was created, or when esc_url_raw
            //       encodes characters differently. Add a FILENAME-based fallback: take the
            //       basename of the bg_video value (URL or bare filename), decode it, and
            //       look for that file in assets/bg-videos/ (and uploads/mcq-video-studio/
            //       bg-videos/ for setups that keep them there). This resolves the local
            //       path regardless of host/encoding so Content Planner renders the video
            //       from disk instead of a blocked HTTP fetch.
            $bg_local_dirs = array(
                mcqvs_assets_dir('bg-videos/'),
                trailingslashit(wp_upload_dir()['basedir']) . 'mcq-video-studio/bg-videos/',
            );
            $bg_filename = '';
            $raw_bg = trim((string) $settings['bg_video']);
            if ($raw_bg !== '') {
                // strip query/fragment, then take basename
                $raw_bg = preg_replace('/[?#].*$/', '', $raw_bg);
                $bg_filename = rawurldecode(basename($raw_bg));
            }
            if ($bg_filename !== '') {
                foreach ($bg_local_dirs as $bg_local) {
                    $bg_path = $bg_local . $bg_filename;
                    if (@file_exists($bg_path)) {
                        $normalized_settings['bgVideoPath'] = $bg_path;
                        break;
                    }
                }
            }
            // Keep the URL-prefix match as a secondary path (full relative path preserved).
            if (empty($normalized_settings['bgVideoPath'])) {
                $bg_local = mcqvs_assets_dir('bg-videos/');
                $bg_url_base = mcqvs_assets_url('bg-videos/');
                $bg_url_lower = strtolower($normalized_settings['bgVideoUrl']);
                $bg_base_lower = strtolower(trailingslashit($bg_url_base));
                if (strpos($bg_url_lower, $bg_base_lower) === 0) {
                    $bg_relative = rawurldecode(substr($normalized_settings['bgVideoUrl'], strlen(trailingslashit($bg_url_base))));
                    $bg_path = $bg_local . $bg_relative;
                    if (@file_exists($bg_path)) {
                        $normalized_settings['bgVideoPath'] = $bg_path;
                    }
                }
            }
        }
        if (!empty($settings['voiceover'])) {
            $vo = $settings['voiceover'];
            // @FIX: Switch webspeech provider to edge for server-side TTS (webspeech requires browser).
            if (is_array($vo) && !empty($vo['provider']) && $vo['provider'] === 'webspeech') {
                $vo['provider'] = 'edge';
                $vo['webspeechCapturedAudio'] = true;
            }
            // @FIX 1.4.9.49 (TTS SSOT): a saved browser Web Speech voice name (e.g.
            // "Microsoft David - English (United States)") must never reach Edge TTS —
            // fall back to the Settings default voice when the voice isn't a known Edge ID.
            if (is_array($vo) && !empty($vo['voice'])) {
                $voice = (string) $vo['voice'];
                if (class_exists('VS_Settings')) {
                    $allowed = VS_Settings::get_edge_english_voices();
                    if (!isset($allowed[$voice]) && $voice !== '__webspeech__') {
                        $default = get_option('mcqvs_tts_default_voice', 'en-US-AriaNeural');
                        $vo['voice'] = isset($allowed[$default]) ? $default : 'en-US-AriaNeural';
                    }
                } elseif (!preg_match('/^[a-z]{2}-[A-Z]{2}-[A-Za-z]+Neural$/', $voice)) {
                    $vo['voice'] = 'en-US-AriaNeural';
                }
            }
            $normalized_settings['voiceover'] = $vo;
        }
        if (!empty($settings['sfxEnabled'])) $normalized_settings['sfxEnabled'] = (bool) $settings['sfxEnabled'];
        if (!empty($settings['logoPath'])) {
            $normalized_settings['logoPath'] = self::normalize_logo_path($settings['logoPath']);
        }
        if (!empty($settings['bgImagePath'])) $normalized_settings['bgImagePath'] = $settings['bgImagePath'];
        if (!empty($settings['hookText'])) $normalized_settings['hookText'] = $settings['hookText'];
        // @FIX: Persist hook visibility — Content Planner jobs default to visible when unset.
        if (array_key_exists('hookVisible', $settings)) {
            $normalized_settings['hookVisible'] = (bool) $settings['hookVisible'];
        }
        if (!empty($settings['ctaText'])) $normalized_settings['ctaText'] = $settings['ctaText'];
        // @NEW 2026-08-11: Explanation bar toggle (default OFF — array_key_exists so an
        // explicit false isn't swallowed by empty()).
        if (array_key_exists('showExplanation', $settings)) {
            $normalized_settings['showExplanation'] = !empty($settings['showExplanation']);
        }
        if (!empty($settings['brandName'])) $normalized_settings['brandName'] = $settings['brandName'];
        if (!empty($settings['quizName'])) $normalized_settings['quizName'] = $settings['quizName'];
        if (!empty($settings['publish_at'])) $normalized_settings['publish_at'] = $settings['publish_at'];
        if (!empty($settings['timing'])) $normalized_settings['timing'] = $settings['timing'];
        if (!empty($settings['logoPosition'])) $normalized_settings['logoPosition'] = sanitize_text_field($settings['logoPosition']);
        // Cover config (bg_color, badge_style, brand_size, show_logo)
        if (!empty($settings['cover_config']) && is_array($settings['cover_config'])) {
            $normalized_settings['cover_config'] = $settings['cover_config'];
        }

        // @FIX: Fallback — read missing branding fields from global MCQVS_studio_branding
        //       so every headless render inherits the studio's branding even if the job
        //       was created by an older code path that didn't persist these fields.
        if (empty($normalized_settings['brandName']) || empty($normalized_settings['ctaText']) || empty($normalized_settings['quizName']) || empty($normalized_settings['logoPath']) || empty($normalized_settings['logoPosition'])) {
            $branding = get_option('MCQVS_studio_branding', array());
            if (empty($normalized_settings['brandName']) && !empty($branding['brand_name'])) {
                $normalized_settings['brandName'] = sanitize_text_field($branding['brand_name']);
            }
            if (empty($normalized_settings['quizName'])) {
                // @FIX: Prefer per-job topic_name over global branding quiz_name (e.g. "Biology")
                if (!empty($settings['topic_name'])) {
                    $normalized_settings['quizName'] = sanitize_text_field($settings['topic_name']);
                } elseif (!empty($branding['quiz_name'])) {
                    $normalized_settings['quizName'] = sanitize_text_field($branding['quiz_name']);
                }
            }
            if (empty($normalized_settings['ctaText']) && !empty($branding['cta_text'])) {
                $normalized_settings['ctaText'] = sanitize_text_field($branding['cta_text']);
            }
            if (empty($normalized_settings['ctaStyle']) && !empty($branding['cta_style'])) {
                $normalized_settings['ctaStyle'] = sanitize_text_field($branding['cta_style']);
            }
            if (empty($normalized_settings['logoPath']) && !empty($branding['logo_url'])) {
                $normalized_settings['logoPath'] = self::normalize_logo_path(esc_url_raw($branding['logo_url']));
            }
            if (empty($normalized_settings['logoPosition']) && !empty($branding['logo_pos'])) {
                $normalized_settings['logoPosition'] = sanitize_text_field($branding['logo_pos']);
            }
        }

        // @FIX: Fallback — provide default voiceover config for server-side TTS
        //       when no voiceover was persisted in job settings.
        // @FIX 2026-08-11: rate 1.2 + configurable speakOptions — matches the Content
        //       Planner defaults (get_studio_render_defaults) so every server path
        //       renders identically (SSOT).
        if (empty($normalized_settings['voiceover'])) {
            $raw_provider = get_option('mcqvs_tts_provider', 'webspeech');
            $server_provider = ($raw_provider === 'webspeech') ? 'edge' : $raw_provider;
            // @FIX 1.4.9.49 (TTS SSOT): all knobs read from Settings so every
            // server path matches Content Planner + Studio defaults exactly.
            $normalized_settings['voiceover'] = array(
                'enabled'                => (bool) get_option('mcqvs_tts_enabled', true),
                'provider'               => $server_provider,
                'voice'                  => class_exists('VS_Settings') ? VS_Settings::get_next_rotation_voice() : 'en-US-AriaNeural',
                'rate'                   => (float) get_option('mcqvs_tts_rate', 1.2),
                'pitch'                  => 0.0,
                'speakHook'              => (bool) get_option('mcqvs_tts_speak_hook', true),
                'speakOptions'           => get_option('mcqvs_tts_speak_options', true) ? true : false,
                'speakAnswer'            => (bool) get_option('mcqvs_tts_speak_answer', true),
                'speakCta'               => (bool) get_option('mcqvs_tts_speak_cta', false),
                'answerPhrase'           => 'correct answer is',
                'webspeechCapturedAudio' => true,
            );
        }

        // @FIX: Default hook text for server parity with browser preview.
        // @FIX 2026-08-11: SSOT — the per-topic AI/CSV `hook` must win over the generic
        //       default. Treat the generic defaults as "empty" so a real topic hook
        //       (Content Planner AI path, which stores it in settings['hook']) reaches
        //       the on-screen hook scene instead of "Can you score 5/5?".
        $generic_hooks = array('Can you score 5/5?', 'Can you score 3/3?');
        $current_hook = isset($normalized_settings['hookText']) ? $normalized_settings['hookText'] : '';
        if (empty($current_hook) || in_array($current_hook, $generic_hooks, true)) {
            $topic_hook = isset($settings['hook']) ? $settings['hook'] : '';
            if (!empty($topic_hook) && !in_array($topic_hook, $generic_hooks, true)) {
                $normalized_settings['hookText'] = sanitize_text_field($topic_hook);
            } elseif (empty($current_hook)) {
                $normalized_settings['hookText'] = 'Can you score 5/5?';
            }
        }

        // @NEW 2026-08-11: Strip emoji from the ON-SCREEN hook (Settings > Defaults &
        // Scheduling > Strip Emoji from On-Screen Text, default ON). node-canvas can't
        // render color emoji/flags — the caption ({hook}) still keeps the emoji because
        // Buffer reads settings['hook'] (the original), not this normalized hookText.
        // Explanation text is drawn on-screen too (showExplanation), so strip it there
        // as well — keeps every on-screen glyph renderable on a minimal VPS.
        if (get_option('mcqvs_strip_emoji_on_screen', true)) {
            $normalized_settings['hookText'] = self::strip_emoji_for_screen($normalized_settings['hookText']);
            if (!empty($quiz_data) && is_array($quiz_data)) {
                foreach ($quiz_data as &$qitem) {
                    if (is_array($qitem) && !empty($qitem['explanation'])) {
                        $qitem['explanation'] = self::strip_emoji_for_screen($qitem['explanation']);
                    }
                }
                unset($qitem);
            }
        }

        // @FIX: Enable SFX by default for server parity with browser preview.
        if (!isset($normalized_settings['sfxEnabled'])) {
            $normalized_settings['sfxEnabled'] = true;
        }

        $payload = array(
            'job_id'         => $job_id,
            'questions'      => $quiz_data,
            'settings'       => $normalized_settings,
            'videoFormat'    => $video_format,
            'width'          => $width,
            'height'         => $height,
            'timeout'        => $timeout,
            'ffmpeg_bin'     => $ffmpeg_path,
            'assets_js_dir'  => MCQVS_PLUGIN_DIR . 'assets/js',
            'assets_url'     => $assets_url,
            'origin'         => wp_parse_url(home_url(), PHP_URL_SCHEME) . '://' . wp_parse_url(home_url(), PHP_URL_HOST),
            'out_path'       => get_temp_dir() . 'mcqvs_' . $job_id . '.mp4',
        );

        $payload_path = get_temp_dir() . 'mcqvs_payload_' . $job_id . '.json';
        if (false === @file_put_contents($payload_path, wp_json_encode($payload))) {
            return new WP_Error('payload_write', 'Could not write job payload to ' . $payload_path);
        }

        $status_path = get_temp_dir() . 'mcqvs_status_' . $job_id . '.json';
        $log_path    = get_temp_dir() . 'mcqvs_renderlog_' . $job_id . '.log';
        @unlink($status_path);

        if (class_exists('VS_Error_Logger')) {
            VS_Error_Logger::get_instance()->log_pipeline(
                'render.config',
                'completed',
                $job_id,
                "Server render config for {$job_id}: timeout={$timeout}s, format={$video_format}, ffmpeg={$ffmpeg_path}, node={$node_path}, log_path={$log_path}",
                'info',
                array(
                    'job_id'        => $job_id,
                    'node_path'     => $node_path,
                    'ffmpeg_path'   => $ffmpeg_path,
                    'timeout'       => $timeout,
                    'video_format'  => $video_format,
                    'render_script' => $render_script,
                    'log_path'      => $log_path,
                )
            );
        }

        // ── Spawn the browser-free Node renderer ──
        // It writes progress + final status to $status_path and the MP4 to out_path.
        // We capture the child PID so the existing orphan-kill / liveness probes
        // still reap it. stdout/stderr go to a log file for diagnostics.
        // Env vars (status/log file paths) are exported inline so the child
        // Node process reads them via process.env (shell_exec does not inherit PHP env).
        $cmd = 'MCQVS_STATUS_FILE=' . escapeshellarg($status_path)
             . ' MCQVS_LOG_FILE=' . escapeshellarg($log_path)
             . ' MCQVS_EXIT_FILE=' . escapeshellarg('/tmp/mcqvs_exit_' . $job_id) . ' '
             . escapeshellarg($node_path) . ' ' . escapeshellarg($render_script)
             . ' --payload=' . escapeshellarg($payload_path)
             . ' > ' . escapeshellarg($log_path) . ' 2>&1 & echo $!';

        $output = shell_exec($cmd);
        $pid    = absint(trim($output));

        if (empty($pid)) {
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log("Server render SPAWN FAILED: job={$job_id} — shell_exec returned empty PID", 'error', array('job_id' => $job_id));
            }
            return new WP_Error('spawn_failed', 'Failed to spawn render process. Check Node.js path and permissions.');
        }

        if (class_exists('VS_Error_Logger')) {
            VS_Error_Logger::get_instance()->log("Server render spawned: job={$job_id} pid={$pid}", 'info', array('job_id' => $job_id, 'pid' => $pid));
        }

        set_transient('mcqvs_render_pid_' . $job_id, $pid, $timeout + 300);
        set_transient('mcqvs_render_exit_' . $job_id, 0, $timeout + 300);
        set_transient('mcqvs_render_started_' . $job_id, microtime(true), $timeout + 300);
        set_transient('mcqvs_render_payload_' . $job_id, $payload_path, $timeout + 3600);
        set_transient('mcqvs_render_status_' . $job_id, $status_path, $timeout + 3600);
        set_transient('mcqvs_render_log_' . $job_id, $log_path, $timeout + 3600);
        set_transient('mcqvs_render_out_' . $job_id, $payload['out_path'], $timeout + 3600);
        set_transient('mcqvs_render_timeout_' . $job_id, $timeout, $timeout + 3600);

        // Keep the AS orphan-kill + early liveness probes (they already key off the
        // pid transient and only act when the PID is confirmed dead, so they are
        // safe for the new process).
        if (function_exists('as_schedule_single_action')) {
            as_schedule_single_action(time() + $timeout + 120, 'mcqvs_kill_orphan_render', array((int) $pid, $job_id), 'mcq-video-studio');
        } elseif (function_exists('wp_schedule_single_event')) {
            wp_schedule_single_event(time() + $timeout + 120, 'mcqvs_kill_orphan_render', array((int) $pid, $job_id));
        }
        if (function_exists('as_schedule_single_action')) {
            as_schedule_single_action(time() + 30, 'mcqvs_render_liveness', array($job_id), 'mcq-video-studio');
        } elseif (function_exists('wp_schedule_single_event')) {
            wp_schedule_single_event(time() + 30, 'mcqvs_render_liveness', array($job_id));
        }

        return true;
    }

    /**
     * @NEW 2026-07-18 (server-side render): Finalize a completed server render.
     *              Called by the queue's completion sweep after the Node renderer
     *              exits 0 and writes its status JSON + MP4. Reuses the exact same
     *              upload/finalize logic the browser path used (VS_AJAX_Video_URL_Handler),
     *              but from a file on disk instead of an uploaded blob, so no
     *              admin-ajax nonce is ever involved.
     *
     * @param string $job_id
     * @return bool|WP_Error
     */
    public static function finalize_server_render($job_id)
    {
        $finalize_lock_key = 'mcqvs_finalizing_' . $job_id;
        if (get_transient($finalize_lock_key)) {
            return new WP_Error('already_finalizing', 'Job ' . $job_id . ' is already being finalized.');
        }
        set_transient($finalize_lock_key, 1, 120);

        $job_repo = class_exists('VS_Job_Repository') ? VS_Job_Repository::init() : null;
        if ($job_repo) {
            $existing = $job_repo->get_job($job_id);
            if (!$existing || $existing['status'] !== VS_Job_Status::RENDERING) {
                delete_transient($finalize_lock_key);
                return new WP_Error('wrong_status', 'Job no longer rendering.');
            }
        }

        $status_path = get_transient('mcqvs_render_status_' . $job_id);
        if (empty($status_path) || !@is_readable($status_path)) {
            delete_transient($finalize_lock_key);
            return new WP_Error('no_status', 'Render status file missing for ' . $job_id);
        }
        $status = json_decode(@file_get_contents($status_path), true);
        if (!is_array($status) || ($status['status'] ?? '') !== 'completed' || empty($status['video_path'])) {
            $reason = $status['error'] ?? 'unknown';
            delete_transient($finalize_lock_key);
            return new WP_Error('render_incomplete', 'Render did not complete: ' . $reason);
        }
        $video_path = $status['video_path'];
        if (!@is_readable($video_path) || @filesize($video_path) === 0) {
            delete_transient($finalize_lock_key);
            return new WP_Error('empty_video', 'Rendered video missing or empty at ' . $video_path);
        }

        // @NEW 2026-07-30: Read cover image path from status (extracted by render-node.js).
        $cover_path = !empty($status['cover_path']) && @is_readable($status['cover_path']) && @filesize($status['cover_path']) > 0
            ? $status['cover_path']
            : '';

        if (!$job_repo) {
            delete_transient($finalize_lock_key);
            return new WP_Error('no_repo', 'Job repository unavailable.');
        }
        $job = $job_repo->get_job($job_id);
        $settings    = is_string($job['settings'] ?? '') ? json_decode($job['settings'], true) : ($job['settings'] ?? array());
        $settings    = is_array($settings) ? $settings : array();
        $save_mode   = $settings['save_mode'] ?? get_option('mcqvs_delivery_mode', 'local');

        $node_log_output = '';
        $log_file_path = get_transient('mcqvs_render_log_' . $job_id);
        if (!empty($log_file_path)) {
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log_pipeline(
                    'render.log_debug',
                    'info',
                    $job_id,
                    "Reading render log: path={$log_file_path}, readable=" . (@is_readable($log_file_path) ? 'yes' : 'no') . ", size=" . (@filesize($log_file_path) ?: 0),
                    'info',
                    array('job_id' => $job_id, 'log_path' => $log_file_path)
                );
            }
            if (@is_readable($log_file_path)) {
                if (@filesize($log_file_path) > 1048576) {
                    $node_log_output = @file_get_contents($log_file_path, false, null, -1048576);
                } else {
                    $node_log_output = @file_get_contents($log_file_path);
                }
                if (class_exists('VS_Error_Logger')) {
                    VS_Error_Logger::get_instance()->log_pipeline(
                        'render.log_read',
                        'info',
                        $job_id,
                        "Read render log: length=" . strlen($node_log_output) . " chars",
                        'info',
                        array('job_id' => $job_id, 'log_length' => strlen($node_log_output), 'preview' => substr($node_log_output, 0, 200))
                    );
                }
            } else {
                if (class_exists('VS_Error_Logger')) {
                    VS_Error_Logger::get_instance()->log_pipeline(
                        'render.log_missing',
                        'warning',
                        $job_id,
                        "Render log file not readable at path: {$log_file_path}",
                        'warning',
                        array('job_id' => $job_id, 'log_path' => $log_file_path)
                    );
                }
            }
        } else {
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log_pipeline(
                    'render.log_missing',
                    'warning',
                    $job_id,
                    "Render log transient missing for {$job_id}",
                    'warning',
                    array('job_id' => $job_id)
                );
            }
        }

        if (class_exists('VS_AJAX_Video_URL_Handler')) {
            $url = VS_AJAX_Video_URL_Handler::upload_local_file_for_job($job_id, $video_path, $save_mode);
            if (is_wp_error($url)) {
                $job_repo->update_status($job_id, VS_Job_Status::FAILED, array('error_message' => $url->get_error_message()));
                $job_repo->release_job_lock($job_id);
                delete_transient($finalize_lock_key);
                return $url;
            }
            $job_repo->update_status($job_id, VS_Job_Status::UPLOADING);
            $job_repo->update_video_url($job_id, $url);

            // @NEW 2026-07-30: Upload cover image if render service extracted one.
            if (!empty($cover_path)) {
                $cover_url = self::upload_cover_image($job_id, $cover_path, $save_mode);
                if (!is_wp_error($cover_url)) {
                    $settings['cover_image_url'] = $cover_url;
                    $job_repo->update_job_fields($job_id, array('settings' => wp_json_encode($settings)));
                    if (class_exists('VS_Error_Logger')) {
                        VS_Error_Logger::get_instance()->log_pipeline(
                            'cover.uploaded',
                            'completed',
                            $job_id,
                            "Cover image uploaded for {$job_id}: {$cover_url}",
                            'info',
                            array('job_id' => $job_id, 'cover_url' => $cover_url)
                        );
                    }
                } else {
                    if (class_exists('VS_Error_Logger')) {
                        VS_Error_Logger::get_instance()->log_pipeline(
                            'cover.upload_failed',
                            'warning',
                            $job_id,
                            "Cover image upload failed for {$job_id}: " . $cover_url->get_error_message(),
                            'warning',
                            array('job_id' => $job_id, 'error' => $cover_url->get_error_message())
                        );
                    }
                }
            }

            $job_repo->update_status($job_id, VS_Job_Status::COMPLETED, array('video_url' => $url));
            if (class_exists('VS_Error_Logger')) {
                if (class_exists('VS_Error_Logger')) {
                    VS_Error_Logger::get_instance()->log_pipeline(
                        'render.log_final',
                        'info',
                        $job_id,
                        "About to log job.completed with node_log_output length=" . strlen($node_log_output),
                        'info',
                        array('job_id' => $job_id, 'log_length' => strlen($node_log_output))
                    );
                }
                VS_Error_Logger::get_instance()->log_pipeline(
                    'job.completed',
                    'completed',
                    $job_id,
                    "Server render finalized for {$job_id} (mode: {$save_mode})",
                    'info',
                    array(
                        'job_id' => $job_id,
                        'video_url' => $url,
                        'cover_url' => $settings['cover_image_url'] ?? '',
                        'method' => 'server-node',
                        'save_mode' => $save_mode,
                        'publish_at' => $settings['publish_at'] ?? '',
                        'video_size' => @filesize($video_path),
                        'node_log_output' => $node_log_output,
                    )
                );
            }
            $job_repo->release_job_lock($job_id);

            // @FIX (cross-file audit 2026-07-19): Server-rendered `r2_buffer` jobs must also
            //       be pushed to Buffer on completion. finalize_server_render previously set
            //       video_url + status=completed but NEVER triggered a Buffer push, while the
            //       browser-upload path (class-vs-ajax-video-url-handler.php:184) does. The
            //       publish cron (get_jobs_ready_for_publish) requires publish_at IS NOT NULL,
            //       so any r2_buffer job without a scheduled publish_at was permanently stuck
            //       (completed, never published). Reuse VS_Buffer_Client exactly like the
            //       automation cron does, so the two completion paths behave identically.
            if ($save_mode === 'r2_buffer' && class_exists('VS_Buffer_Client')) {
                $push_now = true;
                if (!empty($settings['publish_at']) && $settings['publish_at'] !== '0000-00-00 00:00:00') {
                    try {
                        $publish_dt = new DateTime($settings['publish_at'], new DateTimeZone('UTC'));
                        $now_dt     = new DateTime('now', new DateTimeZone('UTC'));
                        if ($publish_dt > $now_dt) {
                            $push_now = false;
                        }
                    } catch (Exception $e) {
                        $push_now = true;
                    }
                }
                if ($push_now) {
                    $buffer_result = VS_Buffer_Client::push_job_to_buffer($job_id, $url, $job);
                    if (is_wp_error($buffer_result)) {
                        VS_Error_Logger::get_instance()->log_pipeline(
                            'buffer.push',
                            'failed',
                            $job_id,
                            "Buffer push failed for job {$job_id} (server-render path): " . $buffer_result->get_error_message(),
                            'error',
                            array('job_id' => $job_id, 'video_url' => $url, 'error' => $buffer_result->get_error_message(), 'node_log_output' => $node_log_output)
                        );
                    } else {
                        VS_Error_Logger::get_instance()->log_pipeline(
                            'buffer.push',
                            'completed',
                            $job_id,
                            "Buffer push completed for job {$job_id} (server-render path)",
                            'info',
                            array('job_id' => $job_id, 'video_url' => $url, 'result' => $buffer_result, 'node_log_output' => $node_log_output)
                        );
                    }
                } else {
                    VS_Error_Logger::get_instance()->log_pipeline(
                        'buffer.push',
                        'skipped',
                        $job_id,
                        "Buffer push deferred to scheduled publish_at for job {$job_id} (server-render path)",
                        'info',
                        array('job_id' => $job_id, 'publish_at' => $settings['publish_at'], 'node_log_output' => $node_log_output)
                    );
                }
            }

            self::cleanup_render_artifacts($job_id);
            delete_transient($finalize_lock_key);
            return true;
        }

        delete_transient($finalize_lock_key);
        return new WP_Error('no_handler', 'VS_AJAX_Video_URL_Handler unavailable.');
    }

    /**
     * @NEW 2026-07-30: Upload a cover image file (PNG) extracted from frame 0 of a rendered video.
     * Supports local and R2 delivery paths.
     *
     * @param string $job_id
     * @param string $cover_path Absolute path to the cover PNG.
     * @param string $save_mode  'local' | 'r2' | 'r2_buffer'
     * @return string|WP_Error Public URL or error.
     */
    public static function upload_cover_image($job_id, $cover_path, $save_mode = 'local')
    {
        $cover_path = wp_normalize_path(trim((string) $cover_path));
        $cover_path = realpath($cover_path);
        if (false === $cover_path || !@is_readable($cover_path)) {
            return new WP_Error('cover_not_readable', 'Cover file not readable: ' . $cover_path);
        }

        $delivery  = get_option('mcqvs_delivery_mode', 'local');
        $mode      = in_array($save_mode, array('local', 'r2', 'r2_buffer'), true) ? $save_mode : $delivery;

        if ($mode === 'local') {
            $upload_dir = wp_upload_dir();
            $base_dir = $upload_dir['basedir'] . '/mcq-video-studio/covers';
            if (!file_exists($base_dir)) {
                wp_mkdir_p($base_dir);
            }
            $filename = 'cover_' . sanitize_file_name($job_id) . '_' . time() . '.png';
            $target_path = $base_dir . '/' . $filename;
            if (!@copy($cover_path, $target_path)) {
                return new WP_Error('cover_copy_failed', 'Failed to copy cover image to uploads directory.');
            }
            return $upload_dir['baseurl'] . '/mcq-video-studio/covers/' . $filename;
        }

        // R2 upload path
        $r2_enabled = !empty(get_option('mcqvs_r2_endpoint', '')) && !empty(get_option('mcqvs_r2_access_key', ''));
        if (($mode === 'r2' || $mode === 'r2_buffer') && $r2_enabled) {
            if (!class_exists('VS_R2_Storage')) {
                return new WP_Error('no_r2_storage', 'VS_R2_Storage class not found.');
            }
            $key = 'covers/' . sanitize_file_name($job_id) . '_' . time() . '.png';
            $r2 = new VS_R2_Storage();
            $r2_url = $r2->upload_file($cover_path, $key, 'image/png');
            if (is_wp_error($r2_url)) {
                return $r2_url;
            }
            return $r2_url;
        }

        // Fallback to local
        $upload_dir = wp_upload_dir();
        $base_dir = $upload_dir['basedir'] . '/mcq-video-studio/covers';
        if (!file_exists($base_dir)) {
            wp_mkdir_p($base_dir);
        }
        $filename = 'cover_' . sanitize_file_name($job_id) . '_' . time() . '.png';
        $target_path = $base_dir . '/' . $filename;
        if (!@copy($cover_path, $target_path)) {
            return new WP_Error('cover_copy_failed', 'Failed to copy cover image.');
        }
        return $upload_dir['baseurl'] . '/mcq-video-studio/covers/' . $filename;
    }

    /**
     * @NEW 2026-07-18: Remove transient payload/status files for a finished job.
     */
    public static function cleanup_render_artifacts($job_id)
    {
        foreach (array(
            'mcqvs_render_payload_',
            'mcqvs_render_status_',
            'mcqvs_render_out_',
            'mcqvs_render_pid_',
            'mcqvs_render_started_',
            'mcqvs_render_exit_',
            'mcqvs_render_auth_',
            'mcqvs_render_auth_verified_',
            'mcqvs_render_log_',
            'mcqvs_render_timeout_',
            'mcqvs_liveness_scheduled_',
            'mcqvs_finalizing_',
        ) as $k) {
            delete_transient($k . $job_id);
        }
    }

    /**
     * Render multiple jobs sequentially via headless Chrome.
     *
     * @param array $job_ids Array of job IDs to render.
     * @return array Results per job.
     */
    public function render_jobs($job_ids)
    {
        $concurrency = absint(get_option('mcqvs_render_concurrency', 1));
        $results = array();

        if ($concurrency <= 1) {
            foreach ($job_ids as $job_id) {
                $results[$job_id] = $this->render_job($job_id);
            }
        } else {
            $chunks = array_chunk($job_ids, $concurrency);
            $timeout = absint(get_option('mcqvs_render_timeout', 900));
            if ($timeout < 600) { $timeout = 900; }
            foreach ($chunks as $chunk) {
                foreach ($chunk as $job_id) {
                    $results[$job_id] = $this->render_job($job_id);
                }
                $chunk_pids = array();
                foreach ($chunk as $job_id) {
                    $pid = get_transient('mcqvs_render_pid_' . $job_id);
                    if ($pid) { $chunk_pids[] = absint($pid); }
                }
                $waited = 0;
                while ($waited < $timeout && !empty($chunk_pids)) {
                    $still_running = false;
                    foreach ($chunk_pids as $pid) {
                        if (self::is_pid_running($pid)) {
                            $still_running = true;
                            break;
                        }
                    }
                    if (!$still_running) {
                        break;
                    }
                    sleep(5);
                    $waited += 5;
                }
            }
        }

        return $results;
    }

    /**
     * Cross-platform PID alive probe.
     *
     * @FIX: `kill -0` is POSIX-only and silently reports dead on Windows. Use posix_kill when
     *       available and fall back to `tasklist` on Windows.
     *
     * @param int $pid
     * @return bool
     */
    public static function is_pid_running($pid)
    {
        $pid = absint($pid);
        if ($pid <= 0) {
            return false;
        }
        if (function_exists('posix_kill')) {
            // posix_kill returns true only when the signal can actually be delivered.
            return @posix_kill($pid, 0);
        }
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            $out = @shell_exec('tasklist /FI "PID eq ' . $pid . '" /NH 2>NUL');
            return is_string($out) && strpos($out, (string) $pid) !== false;
        }
        // Last-ditch fallback for hosts with posix extension disabled.
        $out = @shell_exec('kill -0 ' . $pid . ' 2>/dev/null');
        return is_string($out) && trim($out) === '';
    }

    /**
     * @NEW 2026-07-18: Best-effort read of the node render status JSON so the
     *      PHP side can surface live progress during a long-but-valid render
     *      (otherwise the job sits silently at `rendering` with zero log output).
     *
     * @param string $job_id
     * @return array|null {status, progress, error}
     */
    private static function read_render_progress($job_id)
    {
        $status_file = get_transient('mcqvs_render_status_' . $job_id);
        if (empty($status_file) || !@is_readable($status_file)) {
            return null;
        }
        $s = json_decode(@file_get_contents($status_file), true);
        if (!is_array($s)) {
            return null;
        }
        return array(
            'status'   => $s['status'] ?? '',
            'progress' => isset($s['progress']) ? (int) $s['progress'] : -1,
            'error'    => $s['error'] ?? '',
        );
    }

    /**
     * @NEW 2026-07-18: Collect the REAL failure detail for a dead render from the
     *      node-side artifacts, so a timeout/hang is never logged as a blind
     *      "no completion marker". Pulls: the exit-code stamp (/tmp/mcqvs_exit_<job>),
     *      the status JSON (status/error when status=failed), and the tail of the
     *      node render log (mcqvs_renderlog_<job>.log).
     *
     * @param string $job_id
     * @return array {exit_hint, node_error, log_tail (full log content)}
     */
    private static function collect_render_failure($job_id)
    {
        $exit_hint = 0;
        $exit_file = '/tmp/mcqvs_exit_' . $job_id;
        if (@is_readable($exit_file)) {
            $exit_hint = (int) trim(@file_get_contents($exit_file));
        }
        $node_error = '';
        $status_file = get_transient('mcqvs_render_status_' . $job_id);
        if (!empty($status_file) && @is_readable($status_file)) {
            $s = json_decode(@file_get_contents($status_file), true);
            if (is_array($s) && ($s['status'] ?? '') === 'failed') {
                $node_error = is_string($s['error'] ?? '') ? $s['error'] : '';
            }
        }
        $log_tail = '';
        $log_file = get_transient('mcqvs_render_log_' . $job_id);
        if (!empty($log_file)) {
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log_pipeline(
                    'render.log_debug',
                    'info',
                    $job_id,
                    "Reading failure render log: path={$log_file}, readable=" . (@is_readable($log_file) ? 'yes' : 'no') . ", size=" . (@filesize($log_file) ?: 0),
                    'info',
                    array('job_id' => $job_id, 'log_path' => $log_file)
                );
            }
            if (@is_readable($log_file)) {
                if (@filesize($log_file) > 1048576) {
                    $log_tail = @file_get_contents($log_file, false, null, -1048576);
                } else {
                    $log_tail = @file_get_contents($log_file);
                }
            } else {
                if (class_exists('VS_Error_Logger')) {
                    VS_Error_Logger::get_instance()->log_pipeline(
                        'render.log_missing',
                        'warning',
                        $job_id,
                        "Failure render log file not readable at path: {$log_file}",
                        'warning',
                        array('job_id' => $job_id, 'log_path' => $log_file)
                    );
                }
            }
        } else {
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log_pipeline(
                    'render.log_missing',
                    'warning',
                    $job_id,
                    "Failure render log transient missing for {$job_id}",
                    'warning',
                    array('job_id' => $job_id)
                );
            }
        }
        return array('exit_hint' => $exit_hint, 'node_error' => $node_error, 'log_tail' => $log_tail);
    }

    /**
     * Format a human-readable failure message from the collected detail.
     *
     * @param int    $pid
     * @param int    $exit_hint
     * @param string $node_error
     * @return string
     */
    private static function format_render_failure_message($pid, $exit_hint, $node_error)
    {
        $msg = 'render_process_died (pid=' . (int) $pid . ', no completion marker)';
        if (!empty($exit_hint)) {
            if ($exit_hint === 5) {
                $msg .= ' [exit=5: bad_payload]';
            } elseif ($exit_hint === 3) {
                $msg .= ' [exit=3: render_timeout]';
            } elseif ($exit_hint === 2) {
                $msg .= ' [exit=2: ffmpeg_or_missing_dep]';
            } elseif ($exit_hint === 4) {
                $msg .= ' [exit=4: internal_render_error]';
            }
        }
        if (!empty($node_error)) {
            $msg .= ' — ' . $node_error;
        }
        return $msg;
    }

    /**
     * Check if a render process is still running.
     *
     * @param string $job_id
     * @return bool
     */
    public function is_render_running($job_id)
    {
        $pid = get_transient('mcqvs_render_pid_' . $job_id);
        if (!$pid) return false;

        // @FIX: Use the cross-platform probe so Windows hosts don't falsely report a dead child.
        $running = self::is_pid_running(absint($pid));

        if (!$running) {
            delete_transient('mcqvs_render_pid_' . $job_id);
        }

        return $running;
    }

    /**
     * Build the Studio Editor URL with auto-run parameters.
     *
     * @param string $job_id
     * @return string
     */
    private function build_studio_url($job_id)
    {
        return admin_url('admin.php?page=mcqvs-editor&auto_run=1&job_id=' . urlencode($job_id), 'https');
    }

    /**
     * Generate a one-time auth token for headless browser cookie auth.
     *
     * @param string $job_id
     * @return string
     */
    private function generate_auth_token($job_id)
    {
        $token = wp_generate_password(32, false);
        set_transient('mcqvs_render_auth_' . $job_id, $token, 300);
        return $token;
    }

    /**
     * Verify a render auth token (called by AJAX on the Studio page).
     *
     * @param string $job_id
     * @param string $token
     * @return bool
     */
    public static function verify_auth_token($job_id, $token)
    {
        $verified_key = 'mcqvs_render_auth_verified_' . $job_id;
        if (get_transient($verified_key)) {
            return true;
        }

        $expected = get_transient('mcqvs_render_auth_' . $job_id);
        if ($expected && hash_equals($expected, $token)) {
            set_transient($verified_key, true, 300);
            delete_transient('mcqvs_render_auth_' . $job_id);
            return true;
        }
        return false;
    }

    /**
     * @FIX: `mcqvs_render_user_id` was read but never written — every headless render
     *       401'd with "Render user not configured". Auto-create an "mcqvs_render"
     *       subscriber-style user if absent and seed the option.
     *
     * @FIX F3+F4+F6 (2026-07-04): Grant the dedicated headless service user the
     *              minimum capability set needed to bypass the Studio page gate and
     *              the manage_options-gated AJAX endpoints. Safe in practice: the
     *              user cannot log in interactively (random 48-char password).
     *
     * @return int User ID (0 on failure).
     */
    public static function ensure_render_user()
    {
        $existing_id = absint(get_option('mcqvs_render_user_id', 0));
        if ($existing_id && get_userdata($existing_id)) {
            // Always re-assert role grant so a downgrade via WP-CLI/db doesn't break the pipeline.
            self::elevate_render_user_caps($existing_id);
            return $existing_id;
        }
        $username = 'mcqvs_render';
        if (username_exists($username)) {
            $u = get_user_by('login', $username);
            if ($u) {
                update_option('mcqvs_render_user_id', $u->ID);
                self::elevate_render_user_caps((int) $u->ID);
                return (int) $u->ID;
            }
        }
        $user_id = wp_insert_user(array(
            'user_login'   => $username,
            'user_pass'    => wp_generate_password(48, true, true),
            'user_email'   => 'render@' . wp_parse_url(home_url(), PHP_URL_HOST),
            'display_name' => 'MCQ Render Service',
            'role'         => 'subscriber',
            'show_admin_bar_front' => false,
        ));
        if (is_wp_error($user_id)) {
            return 0;
        }
        update_option('mcqvs_render_user_id', (int) $user_id);
        self::elevate_render_user_caps((int) $user_id);
        return (int) $user_id;
    }

    /**
     * @FIX F3+F4+F6 (2026-07-04): Grant the render service user the capabilities required
     *              to bypass:
     *                - `render_studio_page` wp_die gate (manage_options)
     *                - `mcqvs_get_studio_sources/data`, `mcqvs_get_job_status`,
     *                  `mcqvs_save_project`, etc. AJAX (mostly manage_options)
     *                - Studio JS auto-runner's polled endpoints
     *              We do NOT grant `unfiltered_html` or any single-site/capability that
     *              could let a leaked token damage normal content. The user cannot log in
     *              interactively (random password + no admin bar / role UI hint).
     *
     * @param int $user_id
     */
    private static function elevate_render_user_caps($user_id)
    {
        $user_id = (int) $user_id;
        if ($user_id <= 0) return;
        $user = get_userdata($user_id);
        if (!$user) return;

        // Always start from a known low-privilege role so toggling on/off is predictable.
        if (!in_array('subscriber', (array) $user->roles, true)
            && !in_array('contributor', (array) $user->roles, true)
            && !in_array('administrator', (array) $user->roles, true)) {
            $user->set_role('subscriber');
        }

        // Add granular capabilities instead of bumping to administrator.
        // This is the minimum set required by Studio + headless polling endpoints.
        $caps = array(
            'manage_options',       // Studio page gate
            'edit_posts',           // project/job endpoints
            'read',                 // general WP read
            'read_private_posts',
            'level_0',
            'level_1',
        );
        foreach ($caps as $cap) {
            if (!$user->has_cap($cap)) {
                $user->add_cap($cap, true);
            }
        }
    }

    /**
     * @FIX (cross-file audit): Scrub --auth-token='…' and --nonce='…' from a spawn command
     *              before logging. Without this, every successful and failed headless spawn
     *              leaks the one-time Studio bypass token + WP nonce into wp_vs_logs.
     *
     * Replacement keeps the value positions visible (so failures remain debuggable) without
     * disclosing the secrets themselves.
     *
     * @param string $cmd
     * @return string
     */
    public static function scrub_secrets_from_cmd($cmd)
    {
        if (!is_string($cmd) || $cmd === '') {
            return '';
        }
        $patterns = array(
            "/(--auth-token=)(?:'[^']*'|\"[^\"]*\"|\\S+)/",
            "/(--nonce=)(?:'[^']*'|\"[^\"]*\"|\\S+)/",
            "/(--password=)(?:'[^']*'|\"[^\"]*\"|\\S+)/i",
        );
        $replacements = array(
            '$1[REDACTED]',
            '$1[REDACTED]',
            '$1[REDACTED]',
        );
        $scrubbed = preg_replace($patterns, $replacements, $cmd);
        return is_string($scrubbed) ? $scrubbed : '';
    }

    /**
     * @FIX: Probe common system Chromium locations so the plugin works on hosts
     *       where Chrome isn't managed by Puppeteer's local node_modules.
     *
     * @return string Absolute path to chrome binary, or empty string if not found.
     */
    public static function auto_detect_chrome()
    {
        $candidates = array(
            '/usr/bin/chromium',
            '/usr/bin/chromium-browser',
            '/usr/bin/google-chrome',
            '/usr/bin/google-chrome-stable',
            '/snap/bin/chromium',
            '/usr/local/lib/puppeteer/.local-chromium/linux-*/chrome-linux/chrome',
        );
        foreach ($candidates as $p) {
            if (strpos($p, '*') !== false) {
                $matches = glob($p);
                if (!empty($matches)) {
                    return $matches[0];
                }
            } elseif (file_exists($p)) {
                return $p;
            }
        }
        $which = trim((string) @shell_exec('which chromium 2>/dev/null'));
        if (!empty($which) && file_exists($which)) {
            return $which;
        }
        return '';
    }

    /**
     * @NEW 2026-07-18 (server-side render): Resolve the FFmpeg binary path.
     *              Mirrors auto_detect_chrome() — option wins, then common
     *              absolute locations, then PATH `which`. Used by the new
     *              browser-free Node renderer (render-node.js) which pipes raw
     *              frames to FFmpeg for H.264/MP4 encoding.
     *
     * @return string Absolute path to the ffmpeg binary, or empty string.
     */
    public static function auto_detect_ffmpeg()
    {
        $opt = get_option('mcqvs_ffmpeg_path', '');
        if (!empty($opt) && @is_executable($opt)) {
            return $opt;
        }
        $candidates = array(
            '/usr/bin/ffmpeg',
            '/usr/local/bin/ffmpeg',
            '/opt/homebrew/bin/ffmpeg',
            'C:\\ffmpeg\\bin\\ffmpeg.exe',
            'C:\\ProgramData\\chocolatey\\bin\\ffmpeg.exe',
        );
        foreach ($candidates as $p) {
            if (@is_executable($p)) {
                return $p;
            }
        }
        $which = trim((string) @shell_exec('which ffmpeg 2>/dev/null'));
        if (!empty($which) && @is_executable($which)) {
            return $which;
        }
        // @FIX 1.4.9.43 (self-sufficient): the renderer's own `npm install`
        // provisions a static ffmpeg via the `ffmpeg-static` package
        // (render-service/node_modules/ffmpeg-static/ffmpeg), so the plugin
        // never depends on a system ffmpeg. Find it as the last fallback.
        $npm_ffmpeg = MCQVS_PLUGIN_DIR . 'render-service/node_modules/ffmpeg-static/ffmpeg';
        if (@is_executable($npm_ffmpeg)) {
            return $npm_ffmpeg;
        }
        return '';
    }

    /**
     * @FIX F7 (2026-07-04): Single source of truth for the default Playwright browsers
     *              directory. Both `render_job()` and `ajax_test_headless()` resolve
     *              through this so the green "Test Setup" check is guaranteed to use
     *              the same Playwright install the live render will.
     *
     * @return string Absolute path to the PLAYWRIGHT_BROWSERS_PATH dir.
     */
    public static function default_playwright_browsers_path()
    {
        // 1. Environment wins (lets ops override per-command-line).
        $env = function_exists('getenv') ? (string) getenv('PLAYWRIGHT_BROWSERS_PATH') : '';
        if (!empty($env)) {
            return $env;
        }

        // 2. POSIX: derive from the current OS user.
        if (function_exists('posix_getpwuid') && function_exists('posix_geteuid')) {
            $info = posix_getpwuid(posix_geteuid());
            if (!empty($info['name'])) {
                return '/home/' . $info['name'] . '/.cache/ms-playwright';
            }
        }

        // 3. Common fallbacks.
        if (is_dir('/root/.cache/ms-playwright')) {
            return '/root/.cache/ms-playwright';
        }
        return '/home/Yo_Yo_Khan/.cache/ms-playwright';
    }

    /**
     * @FIX: Hard-kill an orphan headless render process after timeout+grace.
     *              Now also updates the job row to FAILED with a clear timeout reason,
     *              logs renderer duration (start→kill) and releases the lifecycle transient.
     *
     * @param int    $pid
     * @param string $job_id
     */
    /**
     * @NEW 2026-07-07: Best-effort SIGKILL of a renderer PID with no DB side effects.
     *              Used by the dashboard "Reset Stuck Pipeline" button. Cross-platform
     *              (POSIX kill / Windows taskkill). Safe to call when the PID is already
     *              dead — it simply no-ops.
     */
    public static function kill_pid($pid)
    {
        $pid = (int) $pid;
        if ($pid <= 0) {
            return false;
        }
        if (! self::is_pid_running($pid)) {
            return false; // Already gone; nothing to kill.
        }
        if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
            @shell_exec('taskkill /F /PID ' . $pid . ' 2>NUL');
        } else {
            if (function_exists('posix_kill')) {
                @posix_kill($pid, 9);
            } else {
                @shell_exec('kill -9 ' . $pid . ' 2>/dev/null');
            }
        }
        return true;
    }

    /**
     * @FIX 2026-07-13: Early "PID is already dead" reaper.
     *              Reuses the same log-scan recovery already used by the +timeout+120s
     *              orphan-kill, but ONLY acts when the child PID is confirmed dead —
     *              so it is safe to schedule at +30s and can never murder a still-alive
     *              render.
     *
     * @param string $job_id
     * @param int    $pid
     */
    public static function reap_dead_render($job_id, $pid = 0)
    {
        if (empty($job_id)) {
            return;
        }
        // Guard: if the child is still alive, never reap — let it finish normally.
        $pid_transient = (int) get_transient('mcqvs_render_pid_' . $job_id);
        if ($pid_transient > 0 && self::is_pid_running($pid_transient)) {
            if (class_exists('VS_Error_Logger')) {
                $prog = self::read_render_progress($job_id);
                $msg = 'Render alive (pid=' . $pid_transient . ')';
                if ($prog) {
                    $msg .= ', node_status=' . $prog['status'] . ', progress=' . $prog['progress'] . '%';
                    if (!empty($prog['error'])) { $msg .= ', node_error=' . $prog['error']; }
                }
                VS_Error_Logger::get_instance()->log_pipeline('render.liveness', 'info', $job_id, $msg, 'info', array('job_id' => $job_id, 'pid' => $pid_transient, 'progress' => $prog ? $prog['progress'] : null));
            }
            // @FIX 2026-07-19: Reschedule the liveness check so alive renders
            //        get periodic heartbeats instead of a single +30s shot.
            //        Stops rescheduling after 2 hours (72 * 100s ≈ 2h cap via
            //        the pid transient TTL which was set at spawn to timeout+300s).
            //        Guard against runaway scheduling by checking a dedup transient.
            $reschedule_key = 'mcqvs_liveness_scheduled_' . $job_id;
            if (!get_transient($reschedule_key)) {
                set_transient($reschedule_key, 1, 150);
                if (function_exists('as_schedule_single_action')) {
                    as_schedule_single_action(time() + 100, 'mcqvs_render_liveness', array($job_id), 'mcq-video-studio');
                } elseif (function_exists('wp_schedule_single_event')) {
                    wp_schedule_single_event(time() + 100, 'mcqvs_render_liveness', array($job_id));
                }
            }
            return;
        }
        if (!empty($pid) && self::is_pid_running((int) $pid)) {
            return;
        }

        // @FIX: The liveness reaper (mcqvs_render_liveness) calls this with $pid = 0.
        //       Surface the real tracked child PID in logs instead of a misleading 0.
        $effective_pid = (!empty($pid) && is_numeric($pid) && (int) $pid > 0) ? (int) $pid : $pid_transient;

        $repo = class_exists('VS_Job_Repository') ? VS_Job_Repository::init() : null;
        if (!$repo) {
            return;
        }
        // @FIX 2026-07-14: Read the exit-code stamp that render.js wrote via the
        //              spawn wrapper. Best-effort; missing/empty file is fine.
        $exit_file = "/tmp/mcqvs_exit_{$job_id}";
        $exit_hint = 0;
        if (@is_readable($exit_file)) {
            $exit_hint = (int) trim(@file_get_contents($exit_file));
            if ($exit_hint > 0) {
                set_transient('mcqvs_render_exit_' . $job_id, $exit_hint, 3600);
            }
            @unlink($exit_file);
        }
        $existing = $repo->get_job($job_id);
        if (!$existing || $existing['status'] !== VS_Job_Status::RENDERING) {
            delete_transient('mcqvs_render_pid_' . $job_id);
            delete_transient('mcqvs_render_started_' . $job_id);
            return;
        }
        // @FIX 2026-08-09: Spawn grace. A job freshly claimed by claim_job_for_render()
        //       has status RENDERING but no pid transient yet — the mcqvs_render_claim
        //       AS action spawns render-node.js and stamps mcqvs_render_pid_ shortly
        //       after. Without this, a concurrent sweep failed such jobs as
        //       "render_process_died (pid=0, no completion marker)" before the spawn
        //       ever ran. The pid-based branches below remain fully active: a node
        //       process that spawned and died still has its pid transient, so it is
        //       reaped normally with the real exit/node error.
        if ($pid_transient <= 0) {
            $reap_started_at = strtotime((string) ($existing['started_at'] ?? '') . ' UTC');
            if ($reap_started_at > 0 && (time() - $reap_started_at) < 180) {
                return;
            }
        }

        // @NEW 2026-07-18 (server-side render): If the Node renderer already wrote a
        //              completion status file, finalize it now (upload + status
        //              transition). This is the happy path — the renderer exited 0
        //              and produced an MP4; no need to wait for the orphan window.
        $status_file = get_transient('mcqvs_render_status_' . $job_id);
        $node_error = '';
        if (!empty($status_file) && @is_readable($status_file)) {
            $s = json_decode(@file_get_contents($status_file), true);
            if (is_array($s)) {
                if (($s['status'] ?? '') === 'completed' && !empty($s['video_path'])) {
                    $fin = self::finalize_server_render($job_id);
                    if (!is_wp_error($fin)) {
                        return;
                    }
                    if (is_wp_error($fin) && $fin->get_error_code() === 'already_finalizing') {
                        return;
                    }
                    // finalize failed — fall through to mark failed below.
                    if (class_exists('VS_Error_Logger')) {
                        VS_Error_Logger::get_instance()->log_pipeline('render.finalize_failed', 'failed', $job_id, 'Server render finalize failed: ' . $fin->get_error_message(), 'error', array('job_id' => $job_id));
                    }
                } elseif (($s['status'] ?? '') === 'failed') {
                    // @FIX: Surface the real node-side failure reason render-node.js
                    //       already wrote into the status JSON. Previously only the
                    //       'completed' branch was read, so every internal render error
                    //       (exit=4) was discarded as a generic "render_process_died".
                    $node_error = is_string($s['error'] ?? '') ? $s['error'] : '';
                }
            }
        }

        if (class_exists('VS_Automation_Engine') && method_exists('VS_Automation_Engine', 'recover_completed_render_public')) {
            $recovery = VS_Automation_Engine::recover_completed_render_public($job_id);
            if (is_array($recovery) && ($recovery['action'] ?? '') === 'completed') {
                $extra = !empty($recovery['video_url']) ? array('video_url' => $recovery['video_url']) : array();
                $repo->update_status($job_id, VS_Job_Status::COMPLETED, $extra);
                $repo->release_job_lock($job_id);
                delete_transient('mcqvs_render_pid_' . $job_id);
                delete_transient('mcqvs_render_started_' . $job_id);
                delete_transient('mcqvs_render_exit_' . $job_id);
                if (class_exists('VS_Error_Logger')) {
                    VS_Error_Logger::get_instance()->log_pipeline('render.completed', 'completed', $job_id, "Render completed (worker exited, log scan recovered) for {$job_id}", 'info', array('job_id' => $job_id, 'recovered_via' => 'reap_dead_render'));
                }
                return;
            }
        }

        // @FIX: Auto-retry ONLY when the Node renderer never wrote an exit code
        //       (exit_hint === 0). That is the genuinely-transient case: the process
        //       was killed externally (OOM / SIGKILL / web-server restart) before it
        //       could self-report. Every explicit render-node.js code (2 ffmpeg/dep,
        //       4 internal, 5 bad payload) is deterministic and must NOT be retried —
        //       looping a malformed payload or a dependency failure through the
        //       5-min claim cycle just wastes cycles. Bounded by retry_count so a
        //       persistent fault cannot loop forever; the next cycle re-claims it.
        //       NOTE: the legacy comment said "exit=5 bootstrap"; in the live
        //       render-node.js, 5 means bad payload, so it is intentionally excluded.
        if ($exit_hint === 0) {
            $retries = (int) ($existing['retry_count'] ?? 0);
            if ($retries < 2) {
                // Two valid transitions: rendering -> failed -> ready_for_render.
                $repo->update_status($job_id, VS_Job_Status::FAILED, array('error_message' => 'retry_external_kill #' . ($retries + 1)));
                $repo->update_status($job_id, VS_Job_Status::READY_FOR_RENDER, array('retry_count' => $retries + 1, 'error_message' => ''));
                $repo->release_job_lock($job_id);
                delete_transient('mcqvs_render_pid_' . $job_id);
                delete_transient('mcqvs_render_started_' . $job_id);
                delete_transient('mcqvs_render_exit_' . $job_id);
                if (class_exists('VS_Error_Logger')) {
                    VS_Error_Logger::get_instance()->log_pipeline(
                        'render.retry',
                        'info',
                        $job_id,
                        "Render killed externally (no exit code); auto-retry #{$retries} scheduled for {$job_id}",
                        'info',
                        array('job_id' => $job_id, 'retry' => $retries + 1)
                    );
                }
                return;
            }
        }

        // @FIX 2026-07-14: render.js now exits with code 5 on readiness failure
        //              (render-runner failed to bootstrap). Render that reason
        //              into the error_message so the dashboard surfaces a real
        //              cause instead of the generic render_process_died.
        $reason_text = 'render_process_died (pid=' . (int) $effective_pid . ', no completion marker)';
        $exit_code_text = '';
        if (!empty($exit_hint)) {
            if ($exit_hint === 5) {
                $exit_code_text = ' [exit=5: bad_payload]';
            } elseif ($exit_hint === 3) {
                $exit_code_text = ' [exit=3: render_timeout]';
            } elseif ($exit_hint === 2) {
                $exit_code_text = ' [exit=2: ffmpeg_or_missing_dep]';
            } elseif ($exit_hint === 4) {
                $exit_code_text = ' [exit=4: internal_render_error]';
            }
        }
        // @NEW 2026-07-18: also surface the tail of the node render log so the
        //      failure is fully triageable from the WP log export alone.
        $fail = self::collect_render_failure($job_id);
        if (class_exists('VS_Error_Logger')) {
            VS_Error_Logger::get_instance()->log_pipeline('render.killed', 'failed', $job_id, "Render process died without completion marker for {$job_id}{$exit_code_text} -> marked failed", 'warning', array('job_id' => $job_id, 'pid' => (int) $effective_pid, 'reason' => 'render_process_died_no_marker', 'exit_hint' => $exit_hint, 'node_error' => $fail['node_error'], 'node_log_tail' => $fail['log_tail']));
        }
        $repo->update_status($job_id, VS_Job_Status::FAILED, array('error_message' => $reason_text . $exit_code_text . ($node_error ? ' — ' . $node_error : '')));
        $repo->release_job_lock($job_id);
        delete_transient('mcqvs_render_pid_' . $job_id);
        delete_transient('mcqvs_render_started_' . $job_id);
        delete_transient('mcqvs_render_exit_' . $job_id);
        delete_transient('mcqvs_render_timeout_' . $job_id);
    }

    public static function kill_orphan_render($pid, $job_id = '')
    {
        $pid = (int) $pid;
        if ($pid <= 0) {
            return;
        }
        $start_ts = (int) get_transient('mcqvs_render_started_' . $job_id);
        if ($start_ts > 0) {
            $dur_ms = (int) round((microtime(true) - $start_ts) * 1000);
        } else {
            $dur_ms = -1;
        }
        if (self::is_pid_running($pid)) {
            if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
                @shell_exec('taskkill /F /PID ' . $pid . ' 2>NUL');
            } else {
                if (function_exists('posix_kill')) {
                    @posix_kill($pid, 9);
                } else {
                    @shell_exec('kill -9 ' . $pid . ' 2>/dev/null');
                }
            }
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log_pipeline(
                    'render.killed',
                    'failed',
                    $job_id,
                    "Render orphan killed: pid={$pid} after {$dur_ms}ms",
                    'warning',
                    array('job_id' => $job_id, 'pid' => $pid, 'duration_ms' => $dur_ms, 'reason' => 'orphan_killed')
                );
            }
        } else {
            // @FIX (cross-file audit 2026-07-07): The render.js worker self-terminates
            //              cleanly at its own `--timeout` (`process.exitCode = 3` on poll
            //              timeout, `process.exitCode = 1` on fatal browser error, `0` on
            //              success). If we observe NO surviving PID here, then the worker
            //              already exited on its own — it is NOT an orphan that we killed.
            //              Without this branch, every AS orphan-cleanup pass would log a
            //              false "Render killed (orphan/timeout)" and flip the row to
            //              FAILED with `render_timeout_or_orphan`, masking the real cause
            //              (timeout, fatal error, OOM) and silently breaking normal
            //              lifecycle when the worker simply took longer than the orphan
            //              grace window.
            //
            //              Strategy: leave the DB row alone if the worker exited on its
            //              own; trust `recover_completed_render()` and the upcoming
            //              `update_status()` from a successful upload to make the
            //              canonical transition. If the row is STILL `rendering` after
            //              the recover sweep, fall through to the timeout-fail path so
            //              truly-orphaned rows are still reaped.
            $existing_pre = class_exists('VS_Job_Repository') ? VS_Job_Repository::init()->get_job($job_id) : null;
            if (!$existing_pre || $existing_pre['status'] !== VS_Job_Status::RENDERING) {
                // Job already finished (completed/failed/cancelled) — drop the transients
                // and exit without re-failing or re-logging.
                if (!empty($job_id)) {
                    delete_transient('mcqvs_render_pid_' . $job_id);
                    delete_transient('mcqvs_render_started_' . $job_id);
                }
                return;
            }
            // Row is still `rendering` but the PID is gone. That means the worker exited
            // uncleanly without a PHP writeback. Try the log-recovery sweep first; if it
            // does not surface a completion marker, only THEN do we mark failed with the
            // *actual* last-known reason captured below instead of the misleading
            // "render_timeout_or_orphan" string.
            if (class_exists('VS_Automation_Engine') && method_exists('VS_Automation_Engine', 'recover_completed_render_public')) {
                $recovery = VS_Automation_Engine::recover_completed_render_public($job_id);
                if (is_array($recovery) && ($recovery['action'] ?? '') === 'completed') {
                    $extra_completed = !empty($recovery['video_url']) ? array('video_url' => $recovery['video_url']) : array();
                    VS_Job_Repository::init()->update_status($job_id, VS_Job_Status::COMPLETED, $extra_completed);
                    VS_Job_Repository::init()->release_job_lock($job_id);
                    delete_transient('mcqvs_render_pid_' . $job_id);
                    delete_transient('mcqvs_render_started_' . $job_id);
                    if (class_exists('VS_Error_Logger')) {
                        VS_Error_Logger::get_instance()->log_pipeline(
                            'render.completed',
                            'completed',
                            $job_id,
                            "Render completed (worker exited, log scan recovered) for {$job_id} after {$dur_ms}ms",
                            'info',
                            array('job_id' => $job_id, 'duration_ms' => $dur_ms, 'recovered_via' => 'kill_orphan_render_log_scan', 'video_url' => $recovery['video_url'] ?? '')
                        );
                    }
                    return;
                }
            }

            // @FIX (cross-file audit 2026-07-07): PID is CONFIRMED DEAD (we are in the
            //      `else` branch because is_pid_running() returned false) and the recovery
            //      sweep found NO completion marker. The render process is gone and can
            //      never recover, so leaving the row at `rendering` would wedge it forever
            //      with ZERO log output (this is exactly why job vs_6a4d039d49b3e_1596
            //      hung for hours with nothing in the log). Flip to FAILED with a real
            //      reason and log it. We deliberately do NOT honor the per-job render
            //      budget here — that budget only protects a SLOW-BUT-ALIVE render, which
            //      this is not.
            // @NEW 2026-07-18: Stop discarding the node's real failure. The orphan
            //      death means either the node hit its own hard timeout (exit=3,
            //      error=render_timeout) or hung until killed. Capture the exit
            //      stamp, the status-JSON error, and the tail of the node render
            //      log so the WP log shows the ACTUAL cause instead of a blind
            //      "no completion marker".
            $fail = self::collect_render_failure($job_id);
            $error_message = self::format_render_failure_message($pid, $fail['exit_hint'], $fail['node_error']);
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log_pipeline(
                    'render.killed',
                    'failed',
                    $job_id,
                    "Render process died without completion marker for {$job_id} after {$dur_ms}ms -> marked failed",
                    'warning',
                    array(
                        'job_id' => $job_id,
                        'pid' => $pid,
                        'duration_ms' => $dur_ms,
                        'reason' => 'render_process_died_no_marker',
                        'exit_hint' => $fail['exit_hint'],
                        'node_error' => $fail['node_error'],
                        'node_log_tail' => $fail['log_tail'],
                    )
                );
            }
            if (class_exists('VS_Job_Repository')) {
                $repo = VS_Job_Repository::init();
                $repo->update_status($job_id, VS_Job_Status::FAILED, array('error_message' => $error_message));
                $repo->release_job_lock($job_id);
            }
            delete_transient('mcqvs_render_pid_' . $job_id);
            delete_transient('mcqvs_render_started_' . $job_id);
            return;
        }
        if (!empty($job_id)) {
            delete_transient('mcqvs_render_pid_' . $job_id);
            delete_transient('mcqvs_render_started_' . $job_id);

            // @FIX (cross-file audit): Always mark the job FAILED with a deterministic reason
            //              when its render process is hard-killed (timeout/orphan path).
            //              Without this, the job can stay at `rendering` forever in
            //              `wp_vs_jobs` and confuse the next claim cycle.
            if (class_exists('VS_Job_Repository')) {
                $repo = VS_Job_Repository::init();
                $existing = $repo->get_job($job_id);
                if ($existing && $existing['status'] === VS_Job_Status::RENDERING) {
                    // @FIX (cross-file audit 2026-07-07): Honor the per-job "render time + 1 minute"
                    //              budget before flipping the row to FAILED. The previous logic
                    //              unconditionally reaped any still-rendering job when the
                    //              `mcqvs_kill_orphan_render` single-action fired, which meant
                    //              a normal-but-slow render could be killed just because its
                    //              queue-arrival slipped past the hardcoded timeout.
                    //
                    //              Per your rule: respect the job's OWN render timer. If the
                    //              job has not yet exceeded (render_timeout + 60s) past its
                    //              spawned-at timestamp, leave the recovery path alone — the
                    //              headless queue can re-evaluate via the render log.
                    $budget_exceeded = method_exists($repo, 'is_job_exceeded_own_render_time')
                        ? $repo->is_job_exceeded_own_render_time($job_id)
                        : true;
                    if (!$budget_exceeded) {
                        // @NEW 2026-07-18: Job is still within its OWN render budget and
                        //      the process is alive — a slow-but-valid render, not an orphan.
                        //      Log a heartbeat with the node's live progress so operators can
                        //      see it is genuinely advancing instead of appearing "stuck".
                        if (class_exists('VS_Error_Logger')) {
                            $prog = self::read_render_progress($job_id);
                            $msg = 'Render still within own budget (alive, not orphaned)';
                            if ($prog) { $msg .= ', node_status=' . $prog['status'] . ', progress=' . $prog['progress'] . '%'; }
                            VS_Error_Logger::get_instance()->log_pipeline('render.within_budget', 'info', $job_id, $msg, 'info', array('job_id' => $job_id, 'pid' => $pid, 'progress' => $prog ? $prog['progress'] : null));
                        }
                        return;
                    }
                    $reason = sprintf('render_timeout_or_orphan (killed_pid=%d)', $pid);
                    $extra = array('error_message' => $reason);
                    if ($dur_ms > 0) {
                        $extra['error_message'] .= sprintf(' duration_ms=%d', $dur_ms);
                    }
                    if (class_exists('VS_Error_Logger')) {
                        VS_Error_Logger::get_instance()->log_pipeline(
                            'render.killed',
                            'failed',
                            $job_id,
                            "Render killed (orphan/timeout) pid={$pid} after {$dur_ms}ms",
                            'warning',
                            array('job_id' => $job_id, 'pid' => $pid, 'duration_ms' => $dur_ms, 'reason' => 'render_timeout_or_orphan')
                        );
                    }
                    $repo->update_status($job_id, VS_Job_Status::FAILED, $extra);
                    $repo->release_job_lock($job_id);
                }
            }
        }
    }

    /**
     * @FIX 2026-07-21: Cron-based orphan kill fallback.
     *              Scans for rendering jobs that have exceeded their timeout + 120s
     *              grace and kills any orphan processes. BEFORE killing, checks that
     *              the render is NOT actively making progress — a render with a live
     *              PID and a recently-updated progress file (status=rendering, progress
     *              advancing) is skipped so that slow-but-valid renders are not murdered
     *              minutes before completion. This is a safety net when the AS orphan-kill
     *              action doesn't run due to queue processing delays. Runs every 5
     *              minutes via wp_cron as a backup to the AS action.
     */
    public static function cron_orphan_kill($job_id = '')
    {
        if (!class_exists('VS_Job_Repository')) {
            return;
        }
        $repo = VS_Job_Repository::init();
        $render_timeout_default = absint(get_option('mcqvs_render_timeout', 900));
        if ($render_timeout_default < 600) {
            $render_timeout_default = 900;
        }

        $rendering_jobs = $repo->get_jobs_by_status(VS_Job_Status::RENDERING, 50);
        foreach ($rendering_jobs as $job) {
            $jid = $job['job_id'];
            $pid = get_transient('mcqvs_render_pid_' . $jid);
            if (empty($pid)) {
                continue;
            }
            $started_ts = get_transient('mcqvs_render_started_' . $jid);
            if (is_numeric($started_ts) && (float) $started_ts > 0) {
                $elapsed = (int) (microtime(true) - (float) $started_ts);
            } else {
                $started_at = $job['started_at'] ?? '';
                $started_ts = strtotime($started_at . ' UTC');
                $elapsed = time() - ($started_ts ?: time());
            }
            $per_job_timeout = (int) get_transient('mcqvs_render_timeout_' . $jid);
            if ($per_job_timeout <= 0) {
                $per_job_timeout = $render_timeout_default;
            }
            // @FIX 2026-07-21: Use timeout+120 to match the AS orphan-kill schedule
            //       (scheduled at spawn as time()+timeout+120). Previously timeout+60
            //       was used, which was stricter than the AS path and killed renders
            //       that the AS action would have spared.
            $budget_seconds = $per_job_timeout + 120;
            if ($elapsed > $budget_seconds && self::is_pid_running(absint($pid))) {
                // @FIX 2026-07-21: Before killing, check if the render is actively
                //       making progress. If the progress file exists with status=rendering
                //       and was updated recently, skip the kill — the render is slow but
                //       not stuck.
                $prog = self::read_render_progress($jid);
                if (is_array($prog) && ($prog['status'] ?? '') === 'rendering' && ($prog['progress'] ?? -1) >= 0) {
                    $status_file = get_transient('mcqvs_render_status_' . $jid);
                    if (!empty($status_file) && @is_file($status_file)) {
                        $file_mtime = @filemtime($status_file);
                        if ($file_mtime > 0 && (time() - $file_mtime) < 300) {
                            if (class_exists('VS_Error_Logger')) {
                                VS_Error_Logger::get_instance()->log_pipeline(
                                    'render.orphan_cron_progress',
                                    'info',
                                    $jid,
                                    "Cron orphan kill SKIPPED for {$jid}: pid={$pid} alive, progress={$prog['progress']}%, status file updated <300s ago (elapsed={$elapsed}s, budget={$budget_seconds}s)",
                                    'info',
                                    array('job_id' => $jid, 'pid' => $pid, 'elapsed_sec' => $elapsed, 'budget_sec' => $budget_seconds, 'progress' => $prog['progress'])
                                );
                            }
                            continue;
                        }
                    }
                }
                self::kill_pid($pid);
                if (class_exists('VS_Error_Logger')) {
                    VS_Error_Logger::get_instance()->log_pipeline(
                        'render.orphan_cron',
                        'failed',
                        $jid,
                        "Cron orphan kill: pid={$pid} exceeded {$budget_seconds}s budget",
                        'warning',
                        array('job_id' => $jid, 'pid' => $pid, 'elapsed_sec' => $elapsed, 'budget_sec' => $budget_seconds)
                    );
                }
                $repo->update_status($jid, VS_Job_Status::FAILED, array('error_message' => 'render_timeout_or_orphan (cron killed)'));
                $repo->release_job_lock($jid);
                delete_transient('mcqvs_render_pid_' . $jid);
                delete_transient('mcqvs_render_started_' . $jid);
                delete_transient('mcqvs_render_timeout_' . $jid);
            }
        }
    }
}
