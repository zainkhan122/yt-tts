<?php
/**
 * AI Social Collage - End-to-End Pipeline Integration Test
 *
 * Run via WP-CLI:
 *   wp eval-file tests/test-pipeline-integration.php
 *
 * Tests:
 *   1. Buffer stats caching (new wp_options-based system)
 *   2. API error parsing (all error types)
 *   3. Quota state management
 *   4. Provider cooldown
 *   5. Job retry / smart delay computation
 *   6. Buffer stats scheduler anchor calculation
 *   7. Dashboard rendering reads from cache
 *   8. Buffer daily limit tracking
 */

if ( ! defined( 'ABSPATH' ) ) {
    echo "ERROR: Must be run via wp eval-file\n";
    exit( 1 );
}

use AiSocialCollage\Config;
use AiSocialCollage\Services\APIErrorParser;
use AiSocialCollage\Services\APIErrorInfo;
use AiSocialCollage\Services\QuotaStateManager;
use AiSocialCollage\Services\ProviderCooldown;
use AiSocialCollage\Services\BufferIntegration;
use AiSocialCollage\Database\JobManager;

// ═══════════════════════════════════════════════════════════════════════════
//  TEST HARNESS
// ═══════════════════════════════════════════════════════════════════════════

$passed  = 0;
$failed  = 0;
$errors  = [];

function test_assert( string $name, bool $condition, string $detail = '' ) {
    global $passed, $failed, $errors;
    if ( $condition ) {
        $passed++;
        echo "  PASS  {$name}\n";
    } else {
        $failed++;
        $msg = "  FAIL  {$name}";
        if ( $detail ) {
            $msg .= " — {$detail}";
        }
        $errors[] = $msg;
        echo "{$msg}\n";
    }
}

function section( string $title ) {
    echo "\n══════════════════════════════════════════════════════════════\n";
    echo "  {$title}\n";
    echo "══════════════════════════════════════════════════════════════\n";
}

// ═══════════════════════════════════════════════════════════════════════════
//  1. BUFFER STATS CACHING
// ═══════════════════════════════════════════════════════════════════════════

section( '1. BUFFER STATS CACHING (wp_options)' );

// Test: OPTION_BUFFER_STATS_CACHE constant exists
test_assert(
    'OPTION_BUFFER_STATS_CACHE constant defined',
    defined( 'AiSocialCollage\Config::OPTION_BUFFER_STATS_CACHE' ),
    'Constant not found'
);

// Test: ACTION_REFRESH_BUFFER_STATS constant exists
test_assert(
    'ACTION_REFRESH_BUFFER_STATS constant defined',
    defined( 'AiSocialCollage\Config::ACTION_REFRESH_BUFFER_STATS' ),
    'Constant not found'
);

// Test: Cache option defaults to empty array
$cache = get_option( Config::OPTION_BUFFER_STATS_CACHE, [] );
test_assert(
    'Cache option is array by default',
    is_array( $cache ),
    'Got: ' . gettype( $cache )
);

// Test: Write cache, read back
$test_data = [
    'draft_count'     => 42,
    'daily_limit'     => 10,
    'draft_retention' => 7,
    'fetched_at'      => time(),
];
update_option( Config::OPTION_BUFFER_STATS_CACHE, $test_data, false );
$read_back = get_option( Config::OPTION_BUFFER_STATS_CACHE, [] );
test_assert(
    'Cache write/read roundtrip (draft_count)',
    ( $read_back['draft_count'] ?? 0 ) === 42,
    'Expected 42, got ' . ( $read_back['draft_count'] ?? 'null' )
);
test_assert(
    'Cache write/read roundtrip (fetched_at)',
    isset( $read_back['fetched_at'] ) && $read_back['fetched_at'] > 0,
    'fetched_at missing or zero'
);

// Test: Cache with missing keys falls back to defaults
delete_option( Config::OPTION_BUFFER_STATS_CACHE );
$empty_cache = get_option( Config::OPTION_BUFFER_STATS_CACHE, [] );
test_assert(
    'Empty cache falls back to defaults (draft_count=0)',
    (int) ( $empty_cache['draft_count'] ?? 0 ) === 0
);
test_assert(
    'Empty cache falls back to defaults (daily_limit=5)',
    (int) ( $empty_cache['daily_limit'] ?? 5 ) === 5
);
test_assert(
    'Empty cache falls back to defaults (retention=DEFAULT_BUFFER_DRAFT_RETENTION_DAYS)',
    (int) ( $empty_cache['draft_retention'] ?? Config::DEFAULT_BUFFER_DRAFT_RETENTION_DAYS ) === Config::DEFAULT_BUFFER_DRAFT_RETENTION_DAYS
);

// Test: Verify Dashboard::get_buffer_stats() reads from cache (not API)
// Simulate what the dashboard does
update_option( Config::OPTION_BUFFER_STATS_CACHE, [
    'draft_count'     => 99,
    'daily_limit'     => 8,
    'draft_retention' => 5,
    'fetched_at'      => time(),
], false );
update_option( Config::OPTION_BUFFER_ENABLED, true );
update_option( Config::OPTION_BUFFER_ACCESS_TOKEN, 'test-token-xxx' );

// Call get_buffer_stats via reflection (it's private)
$dashboard = new \AiSocialCollage\View\Dashboard();
$ref = new ReflectionMethod( $dashboard, 'get_buffer_stats' );
$ref->setAccessible( true );
$stats = $ref->invoke( $dashboard );

test_assert(
    'Dashboard reads draft_count from cache (99)',
    ( $stats['draft_count'] ?? 0 ) === 99,
    'Got: ' . ( $stats['draft_count'] ?? 'null' )
);
test_assert(
    'Dashboard reads daily_limit from cache (8)',
    ( $stats['daily_limit'] ?? 0 ) === 8,
    'Got: ' . ( $stats['daily_limit'] ?? 'null' )
);
test_assert(
    'Dashboard reads draft_retention from cache (5)',
    ( $stats['draft_retention'] ?? 0 ) === 5,
    'Got: ' . ( $stats['draft_retention'] ?? 'null' )
);
test_assert(
    'Dashboard enabled=true from WP option',
    ( $stats['enabled'] ?? false ) === true
);
test_assert(
    'Dashboard has_token=true from WP option',
    ( $stats['has_token'] ?? false ) === true
);

// Cleanup
delete_option( Config::OPTION_BUFFER_STATS_CACHE );
delete_option( Config::OPTION_BUFFER_ENABLED );
delete_option( Config::OPTION_BUFFER_ACCESS_TOKEN );

// ═══════════════════════════════════════════════════════════════════════════
//  2. API ERROR PARSING — ALL ERROR TYPES
// ═══════════════════════════════════════════════════════════════════════════

section( '2. API ERROR PARSING' );

// 2a. Gemini 429 with RPD quota violation
$gemini_rpd_body = json_encode( [
    'error' => [
        'status' => 'RESOURCE_EXHAUSTED',
        'message' => 'Quota exceeded for quota metric',
        'details' => [
            [
                '@type' => 'type.googleapis.com/google.rpc.QuotaFailure',
                'violations' => [
                    [
                        'subject' => 'projects/123/locations/global',
                        'description' => 'Quota exceeded',
                        'quotaId' => 'RequestsPerDayPerProject',
                        'quotaMetric' => 'generativelanguage.googleapis.com/requests_per_day',
                    ],
                ],
            ],
            [
                '@type' => 'type.googleapis.com/google.rpc.RetryInfo',
                'retryDelay' => '3600s',
            ],
        ],
    ],
] );

$err = APIErrorParser::parse( Config::PROVIDER_GEMINI, 429, $gemini_rpd_body );
test_assert(
    'Gemini 429 RPD → TYPE_QUOTA_RPD',
    $err->error_type === APIErrorInfo::TYPE_QUOTA_RPD,
    'Got: ' . $err->error_type
);
test_assert(
    'Gemini 429 RPD → is_retryable=true',
    $err->is_retryable === true
);
test_assert(
    'Gemini 429 RPD → retry_after parsed from RetryInfo',
    $err->retry_after >= 3600,
    'Got: ' . $err->retry_after
);
test_assert(
    'Gemini 429 RPD → reset_at set (tomorrow PT)',
    $err->reset_at > time(),
    'Got: ' . $err->reset_at
);

// 2b. Gemini 429 with RPM quota violation
$gemini_rpm_body = json_encode( [
    'error' => [
        'status' => 'RESOURCE_EXHAUSTED',
        'message' => 'RPM limit exceeded',
        'details' => [
            [
                '@type' => 'type.googleapis.com/google.rpc.QuotaFailure',
                'violations' => [
                    [
                        'quotaId' => 'RequestsPerMinutePerProject',
                        'quotaMetric' => 'generativelanguage.googleapis.com/requests_per_minute',
                    ],
                ],
            ],
        ],
    ],
] );

$err = APIErrorParser::parse( Config::PROVIDER_GEMINI, 429, $gemini_rpm_body );
test_assert(
    'Gemini 429 RPM → TYPE_QUOTA_RPM',
    $err->error_type === APIErrorInfo::TYPE_QUOTA_RPM,
    'Got: ' . $err->error_type
);

// 2c. Gemini 500 → SERVER_OVERLOADED
$err = APIErrorParser::parse( Config::PROVIDER_GEMINI, 500, '{"error":{"status":"INTERNAL","message":"Server error"}}' );
test_assert(
    'Gemini 500 → TYPE_SERVER_OVERLOADED',
    $err->error_type === APIErrorInfo::TYPE_SERVER_OVERLOADED,
    'Got: ' . $err->error_type
);
test_assert(
    'Gemini 500 → is_retryable=true',
    $err->is_retryable === true
);

// 2d. Gemini 401 → AUTH_FAILURE
$err = APIErrorParser::parse( Config::PROVIDER_GEMINI, 401, '{"error":{"status":"UNAUTHENTICATED","message":"Bad key"}}' );
test_assert(
    'Gemini 401 → TYPE_AUTH_FAILURE',
    $err->error_type === APIErrorInfo::TYPE_AUTH_FAILURE,
    'Got: ' . $err->error_type
);
test_assert(
    'Gemini 401 → is_retryable=false',
    $err->is_retryable === false
);
test_assert(
    'Gemini 401 → is_deterministic=true',
    $err->is_deterministic === true
);

// 2e. Gemini 404 → MODEL_NOT_FOUND
$err = APIErrorParser::parse( Config::PROVIDER_GEMINI, 404, '{"error":{"status":"NOT_FOUND"}}' );
test_assert(
    'Gemini 404 → TYPE_MODEL_NOT_FOUND',
    $err->error_type === APIErrorInfo::TYPE_MODEL_NOT_FOUND,
    'Got: ' . $err->error_type
);

// 2f. Gemini 400 → REQUEST_SHAPE
$err = APIErrorParser::parse( Config::PROVIDER_GEMINI, 400, '{"error":{"status":"INVALID_ARGUMENT"}}' );
test_assert(
    'Gemini 400 → TYPE_REQUEST_SHAPE',
    $err->error_type === APIErrorInfo::TYPE_REQUEST_SHAPE,
    'Got: ' . $err->error_type
);
test_assert(
    'Gemini 400 → is_deterministic=true',
    $err->is_deterministic === true
);

// 2g. Gemini 408 → TRANSIENT
$err = APIErrorParser::parse( Config::PROVIDER_GEMINI, 408, '' );
test_assert(
    'Gemini 408 → TYPE_TRANSIENT',
    $err->error_type === APIErrorInfo::TYPE_TRANSIENT,
    'Got: ' . $err->error_type
);
test_assert(
    'Gemini 408 → is_retryable=true',
    $err->is_retryable === true
);

// 2h. Generic provider 429 with "per day" message
$err = APIErrorParser::parse( 'groq', 429, '{"error":{"message":"Rate limit: requests per day exceeded"}}' );
test_assert(
    'Groq 429 "per day" → TYPE_QUOTA_RPD',
    $err->error_type === APIErrorInfo::TYPE_QUOTA_RPD,
    'Got: ' . $err->error_type
);

// 2i. Generic provider 429 with "per minute" message
$err = APIErrorParser::parse( 'groq', 429, '{"error":{"message":"Rate limit: requests per minute exceeded"}}' );
test_assert(
    'Groq 429 "per minute" → TYPE_QUOTA_RPM',
    $err->error_type === APIErrorInfo::TYPE_QUOTA_RPM,
    'Got: ' . $err->error_type
);

// 2j. Generic provider 429 with "token" message
$err = APIErrorParser::parse( 'groq', 429, '{"error":{"message":"Token limit exceeded"}}' );
test_assert(
    'Groq 429 "token" → TYPE_QUOTA_TPM',
    $err->error_type === APIErrorInfo::TYPE_QUOTA_TPM,
    'Got: ' . $err->error_type
);

// 2k. Generic provider 502 → SERVER_OVERLOADED
$err = APIErrorParser::parse( 'groq', 502, 'Bad Gateway' );
test_assert(
    'Groq 502 → TYPE_SERVER_OVERLOADED',
    $err->error_type === APIErrorInfo::TYPE_SERVER_OVERLOADED,
    'Got: ' . $err->error_type
);

// 2l. WP_Error: cURL timeout
$wp_err = new \WP_Error( 'http_request', 'cURL error 28: Connection timed out' );
$err = APIErrorParser::parse_wp_error( 'gemini', $wp_err );
test_assert(
    'WP_Error cURL timeout → TYPE_TRANSIENT',
    $err->error_type === APIErrorInfo::TYPE_TRANSIENT,
    'Got: ' . $err->error_type
);

// 2m. WP_Error: connection refused
$wp_err = new \WP_Error( 'http_request', 'Connection refused' );
$err = APIErrorParser::parse_wp_error( 'gemini', $wp_err );
test_assert(
    'WP_Error connection refused → TYPE_SERVER_OVERLOADED',
    $err->error_type === APIErrorInfo::TYPE_SERVER_OVERLOADED,
    'Got: ' . $err->error_type
);

// 2n. WP_Error: DNS resolution
$wp_err = new \WP_Error( 'http_request', 'Could not resolve host' );
$err = APIErrorParser::parse_wp_error( 'gemini', $wp_err );
test_assert(
    'WP_Error DNS failure → TYPE_TRANSIENT',
    $err->error_type === APIErrorInfo::TYPE_TRANSIENT,
    'Got: ' . $err->error_type
);

// ═══════════════════════════════════════════════════════════════════════════
//  3. QUOTA STATE MANAGEMENT
// ═══════════════════════════════════════════════════════════════════════════

section( '3. QUOTA STATE MANAGEMENT' );

// Reset first
QuotaStateManager::reset_quota( 'gemini' );

// Test: Fresh state allows requests
test_assert(
    'Fresh state → can_make_request=true',
    QuotaStateManager::can_make_request( 'gemini' ) === true
);

// Test: Record success increments counters
QuotaStateManager::record_success( 'gemini' );
$status = QuotaStateManager::get_quota_status( 'gemini' );
test_assert(
    'After 1 success → rpm_used=1',
    $status['rpm_used'] === 1,
    'Got: ' . $status['rpm_used']
);
test_assert(
    'After 1 success → rpd_used=1',
    $status['rpd_used'] === 1,
    'Got: ' . $status['rpd_used']
);

// Test: Record multiple successes
for ( $i = 0; $i < 5; $i++ ) {
    QuotaStateManager::record_success( 'gemini' );
}
$status = QuotaStateManager::get_quota_status( 'gemini' );
test_assert(
    'After 6 successes → rpm_used=6',
    $status['rpm_used'] === 6,
    'Got: ' . $status['rpm_used']
);
test_assert(
    'After 6 successes → rpd_used=6',
    $status['rpd_used'] === 6,
    'Got: ' . $status['rpd_used']
);

// Test: Record RPD failure sets rpd_used to limit
$rpd_error = new APIErrorInfo( APIErrorInfo::TYPE_QUOTA_RPD, 'Daily limit hit', 'gemini' );
$rpd_error->reset_at = time() + 3600;
QuotaStateManager::record_failure( 'gemini', $rpd_error );
$status = QuotaStateManager::get_quota_status( 'gemini' );
test_assert(
    'After RPD failure → rpd_used=rpd_limit (1500)',
    $status['rpd_used'] === $status['rpd_limit'],
    'Got: ' . $status['rpd_used'] . ' vs limit ' . $status['rpd_limit']
);
test_assert(
    'After RPD failure → can_make_request=false',
    QuotaStateManager::can_make_request( 'gemini' ) === false
);

// Test: Reset clears state
QuotaStateManager::reset_quota( 'gemini' );
$status = QuotaStateManager::get_quota_status( 'gemini' );
test_assert(
    'After reset → rpd_used=0',
    $status['rpd_used'] === 0,
    'Got: ' . $status['rpd_used']
);
test_assert(
    'After reset → can_make_request=true',
    QuotaStateManager::can_make_request( 'gemini' ) === true
);

// Test: RPM failure fills RPM quota
$rpm_error = new APIErrorInfo( APIErrorInfo::TYPE_QUOTA_RPM, 'RPM limit', 'gemini' );
QuotaStateManager::record_failure( 'gemini', $rpm_error );
$status = QuotaStateManager::get_quota_status( 'gemini' );
test_assert(
    'After RPM failure → rpm_used=rpm_limit',
    $status['rpm_used'] === $status['rpm_limit'],
    'Got: ' . $status['rpm_used'] . ' vs limit ' . $status['rpm_limit']
);
test_assert(
    'After RPM failure → should_slow_down=true',
    QuotaStateManager::should_slow_down( 'gemini' ) === true
);

// Test: Auth failure fills both RPM and RPD
QuotaStateManager::reset_quota( 'gemini' );
$auth_error = new APIErrorInfo( APIErrorInfo::TYPE_AUTH_FAILURE, 'Bad API key', 'gemini' );
QuotaStateManager::record_failure( 'gemini', $auth_error );
$status = QuotaStateManager::get_quota_status( 'gemini' );
test_assert(
    'After AUTH_FAILURE → rpm_used=rpm_limit',
    $status['rpm_used'] === $status['rpm_limit'],
    'Got: ' . $status['rpm_used']
);
test_assert(
    'After AUTH_FAILURE → rpd_used=rpd_limit',
    $status['rpd_used'] === $status['rpd_limit'],
    'Got: ' . $status['rpd_used']
);

// Test: next_safe_slot_ts returns future timestamp after quota exhaustion
$slot_ts = QuotaStateManager::next_safe_slot_ts( 'gemini' );
test_assert(
    'next_safe_slot_ts after quota exhaustion → >= now',
    $slot_ts >= time(),
    'Got: ' . $slot_ts . ' vs now: ' . time()
);

// Test: get_recommended_interval scales with usage
QuotaStateManager::reset_quota( 'gemini' );
$base_interval = QuotaStateManager::get_recommended_interval( 'gemini' );
test_assert(
    'Recommended interval for fresh state → base (6s for Gemini)',
    $base_interval === 6,
    'Got: ' . $base_interval
);

// Cleanup
QuotaStateManager::reset_quota( 'gemini' );

// ═══════════════════════════════════════════════════════════════════════════
//  4. PROVIDER COOLDOWN
// ═══════════════════════════════════════════════════════════════════════════

section( '4. PROVIDER COOLDOWN' );

// Reset first
ProviderCooldown::reset_provider( 'gemini' );

test_assert(
    'Fresh state → not in cooldown',
    ProviderCooldown::is_in_cooldown( 'gemini' ) === false
);

// Set cooldown
ProviderCooldown::set_cooldown( 'gemini', 120 );
test_assert(
    'After set_cooldown(120) → is_in_cooldown=true',
    ProviderCooldown::is_in_cooldown( 'gemini' ) === true
);

$remaining = ProviderCooldown::get_cooldown_remaining( 'gemini' );
test_assert(
    'Cooldown remaining > 0',
    $remaining > 0,
    'Got: ' . $remaining
);
test_assert(
    'Cooldown remaining <= 120',
    $remaining <= 120,
    'Got: ' . $remaining
);

// Mark misconfigured
ProviderCooldown::mark_misconfigured( 'gemini' );
test_assert(
    'After mark_misconfigured → is_misconfigured=true',
    ProviderCooldown::is_misconfigured( 'gemini' ) === true
);

// Reset
ProviderCooldown::reset_provider( 'gemini' );
test_assert(
    'After reset → not in cooldown',
    ProviderCooldown::is_in_cooldown( 'gemini' ) === false
);
test_assert(
    'After reset → not misconfigured',
    ProviderCooldown::is_misconfigured( 'gemini' ) === false
);

// ═══════════════════════════════════════════════════════════════════════════
//  5. JOB RETRY / SMART DELAY
// ═══════════════════════════════════════════════════════════════════════════

section( '5. JOB RETRY & SMART DELAY' );

// Test: APIErrorInfo classification
$quota_rpd = new APIErrorInfo( APIErrorInfo::TYPE_QUOTA_RPD, 'test', 'gemini' );
test_assert(
    'TYPE_QUOTA_RPD → is_retryable=true, is_deterministic=false',
    $quota_rpd->is_retryable === true && $quota_rpd->is_deterministic === false
);

$auth = new APIErrorInfo( APIErrorInfo::TYPE_AUTH_FAILURE, 'test', 'gemini' );
test_assert(
    'TYPE_AUTH_FAILURE → is_retryable=false, is_deterministic=true',
    $auth->is_retryable === false && $auth->is_deterministic === true
);

$server = new APIErrorInfo( APIErrorInfo::TYPE_SERVER_OVERLOADED, 'test', 'gemini' );
test_assert(
    'TYPE_SERVER_OVERLOADED → is_retryable=true, is_deterministic=false',
    $server->is_retryable === true && $server->is_deterministic === false
);

$transient = new APIErrorInfo( APIErrorInfo::TYPE_TRANSIENT, 'test', 'gemini' );
test_assert(
    'TYPE_TRANSIENT → is_retryable=true, is_deterministic=false',
    $transient->is_retryable === true && $transient->is_deterministic === false
);

$request_shape = new APIErrorInfo( APIErrorInfo::TYPE_REQUEST_SHAPE, 'test', 'gemini' );
test_assert(
    'TYPE_REQUEST_SHAPE → is_retryable=false, is_deterministic=true',
    $request_shape->is_retryable === false && $request_shape->is_deterministic === true
);

// Test: is_quota_error() for various types
test_assert(
    'TYPE_QUOTA_RPD → is_quota_error()=true',
    $quota_rpd->is_quota_error() === true
);
test_assert(
    'TYPE_QUOTA_RPM → is_quota_error()=true',
    ( new APIErrorInfo( APIErrorInfo::TYPE_QUOTA_RPM, '', 'g' ) )->is_quota_error() === true
);
test_assert(
    'TYPE_QUOTA_TPM → is_quota_error()=true',
    ( new APIErrorInfo( APIErrorInfo::TYPE_QUOTA_TPM, '', 'g' ) )->is_quota_error() === true
);
test_assert(
    'TYPE_TRANSIENT → is_quota_error()=false',
    $transient->is_quota_error() === false
);
test_assert(
    'TYPE_AUTH_FAILURE → is_quota_error()=false',
    $auth->is_quota_error() === false
);

// Test: is_daily_quota()
test_assert(
    'TYPE_QUOTA_RPD → is_daily_quota()=true',
    $quota_rpd->is_daily_quota() === true
);
test_assert(
    'TYPE_QUOTA_RPM → is_daily_quota()=false',
    ( new APIErrorInfo( APIErrorInfo::TYPE_QUOTA_RPM, '', 'g' ) )->is_daily_quota() === false
);

// ═══════════════════════════════════════════════════════════════════════════
//  6. BUFFER STATS SCHEDULER ANCHOR CALCULATION
// ═══════════════════════════════════════════════════════════════════════════

section( '6. BUFFER STATS SCHEDULER ANCHOR' );

// Test: Verify the anchor logic produces correct UTC times
// We test the mathematical logic directly since we can't call the private method

function test_anchor_calculation( int $now, string $label ) {
    $hour   = (int) gmdate( 'G', $now );
    $minute = (int) gmdate( 'i', $now );
    $seconds_past_hour = $minute * 60;

    if ( $hour < 8 ) {
        $anchor = $now + ( ( 8 - $hour ) * 3600 - $seconds_past_hour );
    } elseif ( $hour < 16 ) {
        $anchor = $now + ( ( 16 - $hour ) * 3600 - $seconds_past_hour );
    } else {
        $anchor = $now + ( ( 24 - $hour + 8 ) * 3600 - $seconds_past_hour );
    }

    $anchor_hour = (int) gmdate( 'G', $anchor );
    $anchor_min  = (int) gmdate( 'i', $anchor );
    return [ 'anchor' => $anchor, 'hour' => $anchor_hour, 'minute' => $anchor_min, 'label' => $label ];
}

// Test: At 03:00 UTC → anchor should be 08:00 UTC
$t = strtotime( '2026-06-24 03:00:00 UTC' );
$r = test_anchor_calculation( $t, '03:00 UTC → 08:00 UTC' );
test_assert( $r['label'], $r['hour'] === 8 && $r['minute'] === 0, 'Got: ' . gmdate( 'H:i', $r['anchor'] ) );

// Test: At 10:00 UTC → anchor should be 16:00 UTC
$t = strtotime( '2026-06-24 10:00:00 UTC' );
$r = test_anchor_calculation( $t, '10:00 UTC → 16:00 UTC' );
test_assert( $r['label'], $r['hour'] === 16 && $r['minute'] === 0, 'Got: ' . gmdate( 'H:i', $r['anchor'] ) );

// Test: At 18:00 UTC → anchor should be 08:00 UTC next day
$t = strtotime( '2026-06-24 18:00:00 UTC' );
$r = test_anchor_calculation( $t, '18:00 UTC → 08:00 UTC+1d' );
test_assert( $r['label'], $r['hour'] === 8 && $r['minute'] === 0, 'Got: ' . gmdate( 'H:i', $r['anchor'] ) );

// Test: At 07:59 UTC → anchor should be 08:00 UTC (same day, 1 min later)
$t = strtotime( '2026-06-24 07:59:00 UTC' );
$r = test_anchor_calculation( $t, '07:59 UTC → 08:00 UTC (same day)' );
test_assert( $r['label'], $r['hour'] === 8 && $r['minute'] === 0, 'Got: ' . gmdate( 'H:i', $r['anchor'] ) );

// Test: At 15:59 UTC → anchor should be 16:00 UTC (same day)
$t = strtotime( '2026-06-24 15:59:00 UTC' );
$r = test_anchor_calculation( $t, '15:59 UTC → 16:00 UTC (same day)' );
test_assert( $r['label'], $r['hour'] === 16 && $r['minute'] === 0, 'Got: ' . gmdate( 'H:i', $r['anchor'] ) );

// Test: At 23:59 UTC → anchor should be 08:00 UTC next day
$t = strtotime( '2026-06-24 23:59:00 UTC' );
$r = test_anchor_calculation( $t, '23:59 UTC → 08:00 UTC+1d' );
test_assert( $r['label'], $r['hour'] === 8 && $r['minute'] === 0, 'Got: ' . gmdate( 'H:i', $r['anchor'] ) );

// Test: At 00:00 UTC → anchor should be 08:00 UTC
$t = strtotime( '2026-06-24 00:00:00 UTC' );
$r = test_anchor_calculation( $t, '00:00 UTC → 08:00 UTC' );
test_assert( $r['label'], $r['hour'] === 8 && $r['minute'] === 0, 'Got: ' . gmdate( 'H:i', $r['anchor'] ) );

// Test: At 16:00 UTC → anchor should be 08:00 UTC next day (edge: exactly on boundary)
$t = strtotime( '2026-06-24 16:00:00 UTC' );
$r = test_anchor_calculation( $t, '16:00 UTC → 08:00 UTC+1d' );
test_assert( $r['label'], $r['hour'] === 8 && $r['minute'] === 0, 'Got: ' . gmdate( 'H:i', $r['anchor'] ) );

// Test: Interval is 12 hours
test_assert(
    '12h interval = 43200 seconds',
    12 * HOUR_IN_SECONDS === 43200
);

// Test: PKT conversion (UTC+5)
// 1300 PKT = 0800 UTC ✓
// 2100 PKT = 1600 UTC ✓
$pkt_1300 = strtotime( '2026-06-24 13:00:00 Asia/Karachi' );
$utc_equivalent = gmdate( 'H:i', $pkt_1300 );
test_assert(
    '1300 PKT = 0800 UTC',
    $utc_equivalent === '08:00',
    'Got: ' . $utc_equivalent
);

$pkt_2100 = strtotime( '2026-06-24 21:00:00 Asia/Karachi' );
$utc_equivalent = gmdate( 'H:i', $pkt_2100 );
test_assert(
    '2100 PKT = 16:00 UTC',
    $utc_equivalent === '16:00',
    'Got: ' . $utc_equivalent
);

// ═══════════════════════════════════════════════════════════════════════════
//  7. BUFFER DAILY LIMIT TRACKING
// ═══════════════════════════════════════════════════════════════════════════

section( '7. BUFFER DAILY LIMIT TRACKING' );

// Test: Config helper methods exist
test_assert(
    'Config::get_buffer_tracker() callable',
    is_callable( [ Config::class, 'get_buffer_tracker' ] )
);
test_assert(
    'Config::buffer_daily_limit_reached() callable',
    is_callable( [ Config::class, 'buffer_daily_limit_reached' ] )
);
test_assert(
    'Config::increment_buffer_tracker() callable',
    is_callable( [ Config::class, 'increment_buffer_tracker' ] )
);

// Test: Fresh tracker has no limit reached
update_option( Config::OPTION_BUFFER_TRACKER, [ 'date' => '', 'ids' => [] ] );
update_option( Config::OPTION_BUFFER_DAILY_LIMIT, 5 );
test_assert(
    'Fresh tracker → daily_limit_reached=false',
    Config::buffer_daily_limit_reached() === false
);

// Test: Increment up to limit
for ( $i = 0; $i < 5; $i++ ) {
    Config::increment_buffer_tracker( 1000 + $i );
}
test_assert(
    'After 5 increments (limit=5) → daily_limit_reached=true',
    Config::buffer_daily_limit_reached() === true
);

// Test: Tracker data structure
$tracker = Config::get_buffer_tracker();
test_assert(
    'Tracker has date key',
    ! empty( $tracker['date'] ),
    'Got: ' . wp_json_encode( $tracker )
);
test_assert(
    'Tracker has 5 ids',
    count( $tracker['ids'] ?? [] ) === 5,
    'Got: ' . count( $tracker['ids'] ?? [] )
);

// Cleanup
delete_option( Config::OPTION_BUFFER_TRACKER );
delete_option( Config::OPTION_BUFFER_DAILY_LIMIT );

// ═══════════════════════════════════════════════════════════════════════════
//  8. JOB LOCK MECHANISM
// ═══════════════════════════════════════════════════════════════════════════

section( '8. JOB LOCK (transient-based)' );

// Test: Lock can be set and read
$lock_key = 'ai_collage_job_lock_99999';
set_transient( $lock_key, time(), 600 );
test_assert(
    'Lock set → get_transient returns value',
    false !== get_transient( $lock_key ),
    'Expected non-false'
);
test_assert(
    'Lock set → is locked (concurrent check)',
    false !== get_transient( $lock_key )
);

// Test: Lock can be deleted
delete_transient( $lock_key );
test_assert(
    'After delete → lock released',
    false === get_transient( $lock_key ),
    'Expected false, got: ' . var_export( get_transient( $lock_key ), true )
);

// ═══════════════════════════════════════════════════════════════════════════
//  9. API CALL TRACKING
// ═══════════════════════════════════════════════════════════════════════════

section( '9. API CALL TRACKING' );

test_assert(
    'ApiCallManager::create_call() callable',
    is_callable( [ \AiSocialCollage\Database\ApiCallManager::class, 'create_call' ] )
);
test_assert(
    'ApiCallManager::get_summary_stats() callable',
    is_callable( [ \AiSocialCollage\Database\ApiCallManager::class, 'get_summary_stats' ] )
);
test_assert(
    'ApiCallManager::hash_request() callable',
    is_callable( [ \AiSocialCollage\Database\ApiCallManager::class, 'hash_request' ] )
);

// Test: Hash is deterministic
$hash1 = \AiSocialCollage\Database\ApiCallManager::hash_request( 'gemini', [ 'model' => 'flash' ] );
$hash2 = \AiSocialCollage\Database\ApiCallManager::hash_request( 'gemini', [ 'model' => 'flash' ] );
test_assert(
    'Hash is deterministic (same input = same output)',
    $hash1 === $hash2,
    "Got: {$hash1} vs {$hash2}"
);

// Test: Different inputs produce different hashes
$hash3 = \AiSocialCollage\Database\ApiCallManager::hash_request( 'groq', [ 'model' => 'flash' ] );
test_assert(
    'Different provider → different hash',
    $hash1 !== $hash3
);

// ═══════════════════════════════════════════════════════════════════════════
//  10. CONFIG BUFFER HELPERS
// ═══════════════════════════════════════════════════════════════════════════

section( '10. CONFIG BUFFER HELPERS' );

test_assert(
    'Config::is_buffer_enabled() callable',
    is_callable( [ Config::class, 'is_buffer_enabled' ] )
);
test_assert(
    'Config::get_buffer_access_token() callable',
    is_callable( [ Config::class, 'get_buffer_access_token' ] )
);
test_assert(
    'Config::get_buffer_channels() callable',
    is_callable( [ Config::class, 'get_buffer_channels' ] )
);
test_assert(
    'Config::get_buffer_share_mode() callable',
    is_callable( [ Config::class, 'get_buffer_share_mode' ] )
);
test_assert(
    'Config::get_buffer_daily_limit() callable',
    is_callable( [ Config::class, 'get_buffer_daily_limit' ] )
);

// Test: Default share mode is 'draft'
$mode = Config::get_buffer_share_mode();
test_assert(
    'Default share mode = draft',
    $mode === 'draft',
    'Got: ' . $mode
);

// Test: Default daily limit is 5
update_option( Config::OPTION_BUFFER_DAILY_LIMIT, '' );
$limit = Config::get_buffer_daily_limit();
test_assert(
    'Default daily limit = 5',
    $limit === 5,
    'Got: ' . $limit
);

// ═══════════════════════════════════════════════════════════════════════════
//  11. ACTION SCHEDULER HOOK REGISTRATION
// ═══════════════════════════════════════════════════════════════════════════

section( '11. ACTION SCHEDULER HOOKS' );

test_assert(
    'ACTION_REFRESH_BUFFER_STATS value is correct',
    Config::ACTION_REFRESH_BUFFER_STATS === 'ai_social_collage_refresh_buffer_stats'
);

test_assert(
    'ACTION_POLL_CAMPAIGNS value is correct',
    Config::ACTION_POLL_CAMPAIGNS === 'ai_social_collage_poll_campaigns'
);

test_assert(
    'ACTION_POLL_FEEDS value is correct',
    Config::ACTION_POLL_FEEDS === 'ai_social_collage_poll_feeds'
);

test_assert(
    'ACTION_DAILY_CLEANUP value is correct',
    Config::ACTION_DAILY_CLEANUP === 'ai_social_collage_daily_cleanup'
);

// ═══════════════════════════════════════════════════════════════════════════
//  12. BUFFER INTEGRATION CONSTANTS
// ═══════════════════════════════════════════════════════════════════════════

section( '12. BUFFER INTEGRATION CONSTANTS' );

test_assert(
    'BufferIntegration::API_BASE = https://api.buffer.com',
    BufferIntegration::API_BASE === 'https://api.buffer.com'
);
test_assert(
    'BufferIntegration::MAX_RETRY_ATTEMPTS = 3',
    BufferIntegration::MAX_RETRY_ATTEMPTS === 3
);
test_assert(
    'BufferIntegration::INTER_REQUEST_DELAY_US = 1500000',
    BufferIntegration::INTER_REQUEST_DELAY_US === 1500000
);

// ═══════════════════════════════════════════════════════════════════════════
//  13. END-TO-END: CACHE FLOW SIMULATION
// ═══════════════════════════════════════════════════════════════════════════

section( '13. END-TO-END: CACHE FLOW SIMULATION' );

// Simulate: Scheduler runs and populates cache
update_option( Config::OPTION_BUFFER_ENABLED, true );
update_option( Config::OPTION_BUFFER_ACCESS_TOKEN, 'real-token' );
update_option( Config::OPTION_BUFFER_DAILY_LIMIT, 10 );
update_option( Config::OPTION_BUFFER_DRAFT_RETENTION_DAYS, 3 );

// Simulate refresh_buffer_stats storing data
$refresh_data = [
    'draft_count'     => 25,
    'daily_limit'     => 10,
    'draft_retention' => 3,
    'fetched_at'      => time(),
];
update_option( Config::OPTION_BUFFER_STATS_CACHE, $refresh_data, false );

// Simulate: Dashboard loads 5 times — should read from cache, not API
$api_call_count = 0;
for ( $i = 0; $i < 5; $i++ ) {
    $dashboard = new \AiSocialCollage\View\Dashboard();
    $ref = new ReflectionMethod( $dashboard, 'get_buffer_stats' );
    $ref->setAccessible( true );
    $stats = $ref->invoke( $dashboard );

    test_assert(
        "Dashboard load #{$i}: draft_count=25 from cache",
        $stats['draft_count'] === 25,
        'Got: ' . $stats['draft_count']
    );
    test_assert(
        "Dashboard load #{$i}: daily_limit=10 from cache",
        $stats['daily_limit'] === 10,
        'Got: ' . $stats['daily_limit']
    );
    test_assert(
        "Dashboard load #{$i}: enabled=true",
        $stats['enabled'] === true
    );
}

// Verify no Buffer API was called (api_call_count still 0)
test_assert(
    'Zero Buffer API calls during 5 dashboard loads',
    $api_call_count === 0,
    'API calls made: ' . $api_call_count
);

// Simulate: Scheduler runs again 12 hours later, updates cache
$update_data = [
    'draft_count'     => 30,
    'daily_limit'     => 10,
    'draft_retention' => 3,
    'fetched_at'      => time(),
];
update_option( Config::OPTION_BUFFER_STATS_CACHE, $update_data, false );

$dashboard = new \AiSocialCollage\View\Dashboard();
$ref = new ReflectionMethod( $dashboard, 'get_buffer_stats' );
$ref->setAccessible( true );
$stats = $ref->invoke( $dashboard );
test_assert(
    'After scheduler update: draft_count=30',
    $stats['draft_count'] === 30,
    'Got: ' . $stats['draft_count']
);

// Cleanup
delete_option( Config::OPTION_BUFFER_STATS_CACHE );
delete_option( Config::OPTION_BUFFER_ENABLED );
delete_option( Config::OPTION_BUFFER_ACCESS_TOKEN );
delete_option( Config::OPTION_BUFFER_DAILY_LIMIT );
delete_option( Config::OPTION_BUFFER_DRAFT_RETENTION_DAYS );

// ═══════════════════════════════════════════════════════════════════════════
//  SUMMARY
// ═══════════════════════════════════════════════════════════════════════════

echo "\n══════════════════════════════════════════════════════════════\n";
echo "  RESULTS: {$passed} passed, {$failed} failed\n";
echo "══════════════════════════════════════════════════════════════\n";

if ( $failed > 0 ) {
    echo "\n  FAILED TESTS:\n";
    foreach ( $errors as $e ) {
        echo "  {$e}\n";
    }
    echo "\n";
    exit( 1 );
}

echo "\n  ALL TESTS PASSED\n\n";
exit( 0 );
