/**
 * NM SEO Generator
 * AI-powered metadata generation for viral videos
 *
 * @package WP_News_MCQ_Generator
 * @version 1.0.0
 */

(function (window) {
  "use strict";

  const MCQVS_SEOGenerator = {
    config: {
      ajaxUrl: "",
      nonce: "",
    },

    init(config) {
      this.config = config || {};
    },

    /**
     * Generate viral high-performer metadata
     * @param {string} topic - Video topic
     * @param {array} questions - List of questions in the video
     * @param {Object} options - { platform: 'tiktok'|'shorts'|'reels', keywords: '' }
     */
    generate: async function (topic, questions, options = {}) {
      const platform = options.platform || "tiktok";
      const keywords = options.keywords || "";

      console.log(
        `[NM SEO] Generating high-performer metadata for ${platform} on topic: ${topic}`
      );

      // @FIX 1.6.0 (prompt SSOT): the prompt is now built SERVER-SIDE by
      // VS_AJAX_AI_Tools_Handler::build_seo_prompt() — identical for this Studio
      // button and the automatic Video Scheduler jobs. The browser only sends
      // structured arguments (topic, questions, platform, keywords).
      return await this._callGemini({
        topic: topic,
        questions: (questions || []).slice(0, 5),
        platform: platform,
        keywords: keywords,
      });
    },

    _callGemini: async function (args) {
      // @MODIFIED 2025-12-18: Use dedicated SEO endpoint
      // @MODIFIED 1.6.0: structured args instead of a browser-built prompt.
      const formData = new FormData();
      formData.append("action", "mcqvs_generate_seo");
      formData.append("nonce", this.config.nonce);
      formData.append("topic", args.topic || "");
      formData.append("platform", args.platform || "shorts");
      formData.append("keywords", args.keywords || "");
      formData.append("questions", JSON.stringify(args.questions || []));

      try {
        const response = await fetch(this.config.ajaxUrl, {
          method: "POST",
          body: formData,
        });
        const data = await response.json();

        if (data.success && data.data) {
          return data.data;
        } else {
          console.error("[NM SEO] API Error:", data);
          // Fallback to defaults
          return this._getDefaults();
        }
      } catch (e) {
        console.error("[NM SEO] Fetch Error:", e);
        return this._getDefaults();
      }
    },

    _getDefaults: function () {
      return {
        title: "Only 1% Can Pass This! 🧠",
        description:
          "Think you know your trivia? Test your knowledge with these impossible questions! Don't forget to comment your score!",
        tags: [
          "#quiz",
          "#trivia",
          "#knowledge",
          "#challenge",
          "#fyp",
          "#viral",
        ],
      };
    },
  };

  window.MCQVS_SEOGenerator = MCQVS_SEOGenerator;
})(window);
