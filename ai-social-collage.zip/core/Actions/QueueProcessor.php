<?php
namespace AiSocialCollage\Actions;

use AiSocialCollage\Config;
use AiSocialCollage\Database\JobManager;
use AiSocialCollage\Logger;
use AiSocialCollage\Services\AIProviderRegistry;
use AiSocialCollage\Services\APIErrorParser;
use AiSocialCollage\Services\APIErrorInfo;
use AiSocialCollage\Services\ContentRewriter;
use AiSocialCollage\Services\ContentCleaner;
use AiSocialCollage\Services\ImageRenderer;
use AiSocialCollage\Services\ImageGenerator;
use AiSocialCollage\Services\ImagePreprocessor;
use AiSocialCollage\Services\ImageAcquisitionService;
use AiSocialCollage\Services\ImageVerificationService;
use AiSocialCollage\Services\SocialBridge;
use AiSocialCollage\Services\WhatsAppBroadcaster;
use AiSocialCollage\Services\ProviderCooldown;
use AiSocialCollage\Services\QuotaStateManager;
use AiSocialCollage\Services\VideoRenderer;
use AiSocialCollage\Services\VideoProcessor;
use ActionScheduler;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class QueueProcessor {

	/**
	 * AUDIT FIX F2: hard cap on processing attempts for a single job.
	 *
	 * A job whose content reliably kills the PHP process (memory exhaustion,
	 * max_execution_time, segfault — none of which are \Throwable and none of
	 * which can be caught) would otherwise be retried forever. Because the
	 * health monitor always picks the OLDEST pending job, one such job blocks
	 * the entire queue permanently.
	 */
	const MAX_ATTEMPTS = 4;

	public function __construct() {
		add_action( Config::ACTION_PROCESS_JOB, [ $this, 'process_job' ] );
	}

	public function process_job( $job_id ) {
		$pipeline_paused = (bool) get_option( Config::OPTION_PIPELINE_PAUSED, false );
		if ( $pipeline_paused ) {
			if ( function_exists( 'as_schedule_single_action' ) ) {
				as_schedule_single_action( time() + 60, Config::ACTION_PROCESS_JOB, [ 'job_id' => (int) $job_id ], Config::AS_GROUP );
			}
			Logger::info( 'job_deferred_pipeline_paused', $job_id, [ 'retry_in' => 60 ], '200' );
			return;
		}

		$lock_key = 'ai_collage_job_lock_' . (int) $job_id;

		// AUDIT FIX F11: atomic, race-safe job lock. See acquire_job_lock() below.
		$lock = $this->acquire_job_lock( $lock_key );

		if ( ! $lock['acquired'] ) {
			Logger::warning( 'job_skipped_concurrent', $job_id, [
				'reason'           => 'Another process is already handling this job',
				'lock_age_seconds' => $lock['age'] ?? null,
				'lock_outcome'     => $lock['reason'],
			], '429' );
			return;
		}

		if ( 'recovered_stale' === $lock['reason'] ) {
			Logger::warning( 'job_stale_lock_deleted_and_reacquired', $job_id, [
				'lock_age_seconds' => $lock['age'] ?? null,
			], '200' );
		}

		// Double-check job status after acquiring lock — another process may have completed it.
		$job = JobManager::get_job( $job_id );
		if ( $job && in_array( $job->status, [ Config::STATUS_COMPLETED, Config::STATUS_FAILED, Config::STATUS_DISCARDED ], true ) ) {
			$this->release_job_lock( $lock_key );
			Logger::info( 'job_already_terminal_after_lock', $job_id, [ 'status' => $job->status ], '200' );
			return;
		}

		// ── AUDIT FIX: self-protection ────────────────────────────────────────
		// process_job() is invoked from three different contexts
		// (Action Scheduler, QueueHealthMonitor::process_pending_jobs_directly(),
		// CronScheduler::maybe_trigger_queue_run()). Only two of those set a time
		// limit, and none of them guarantee it. Enforce it here so the worker
		// cannot inherit a hostile limit (or none at all) from its caller.
		if ( function_exists( 'ignore_user_abort' ) ) {
			@\ignore_user_abort( true );
		}
		if ( function_exists( 'set_time_limit' ) ) {
			@\set_time_limit( 180 );
		}

		// ── AUDIT FIX F2: durable attempt counter + poison quarantine ─────────
		// Written to the DB *before* any work, so it survives a hard crash that
		// bypasses both catch(\Throwable) and finally{}.
		$attempts = JobManager::increment_retry_count( $job_id );

		if ( $attempts > self::MAX_ATTEMPTS ) {
			$post_id = $job && isset( $job->post_id ) ? (int) $job->post_id : 0;

			JobManager::update_status( $job_id, Config::STATUS_FAILED );
			$this->release_job_lock( $lock_key );
			\delete_transient( 'ai_collage_job_perm_fail_' . (int) $job_id );

			if ( $post_id ) {
				\delete_post_meta( $post_id, '_ai_collage_job_created' );
				\delete_transient( 'ai_collage_queued_recent_' . $post_id );
			}

			Logger::error( 'job_poison_quarantined', $job_id, [
				'attempts'   => $attempts,
				'max'        => self::MAX_ATTEMPTS,
				'post_id'    => $post_id,
				'last_error' => (string) \get_transient( 'ai_collage_last_fatal_' . (int) $job_id ),
			], '500', 'Job exceeded the maximum processing attempts and was quarantined as FAILED so it stops blocking the queue.' );

			return;
		}

		// ── AUDIT FIX F1: capture non-Throwable fatals ───────────────────────
		// OOM / max_execution_time / segfault terminate the request without ever
		// reaching catch(\Throwable) and without running finally{}. That is why
		// the logs showed direct_processing_starting_sync with no completion and
		// no error at all. A shutdown handler runs in all of those cases.
		if ( function_exists( 'register_shutdown_function' ) ) {
			$sd_lock_key = $lock_key;
			$sd_job_id   = (int) $job_id;

			@\register_shutdown_function( static function () use ( $sd_lock_key, $sd_job_id ) {
				$err = function_exists( 'error_get_last' ) ? \error_get_last() : null;

				if ( is_array( $err ) && isset( $err['type'] ) ) {
					$fatal_types = [ \E_ERROR, \E_PARSE, \E_CORE_ERROR, \E_COMPILE_ERROR, \E_USER_ERROR ];
					if ( in_array( (int) $err['type'], $fatal_types, true ) ) {
						$message = (string) ( $err['message'] ?? '' );

						Logger::error( 'job_fatal_error', $sd_job_id, [
							'php_error_type'    => (int) $err['type'],
							'message'           => $message,
							'file'              => (string) ( $err['file'] ?? '' ),
							'line'              => (int) ( $err['line'] ?? 0 ),
							'memory_peak_mb'    => round( memory_get_peak_usage( true ) / 1048576, 1 ),
							'memory_limit'      => (string) ini_get( 'memory_limit' ),
							'max_execution_time'=> (string) ini_get( 'max_execution_time' ),
							'note'              => 'Non-Throwable abort (OOM / timeout / fatal). Not catchable by try/catch.',
						], '500', 'FATAL aborted job processing: ' . $message );

						// Stash a short form so the quarantine log can name the cause.
						if ( function_exists( 'set_transient' ) ) {
							\set_transient( 'ai_collage_last_fatal_' . $sd_job_id, $message, \DAY_IN_SECONDS );
						}
					}
				}

				// The finally{} below does not run on a fatal — release the lock here
				// so the job is not additionally blocked by a 900s phantom lock.
				if ( function_exists( 'delete_transient' ) ) {
					\delete_transient( $sd_lock_key );
				}
			} );
		}

		try {
			$this->do_process_job( $job_id );

			// AUDIT FIX F2: a job that advanced past rewrite no longer needs its
			// attempt budget spent — clear it so retries are meaningful.
			$after = JobManager::get_job( $job_id );
			if ( $after && in_array(
				$after->status,
				[ Config::STATUS_RENDERING, Config::STATUS_SCHEDULED, Config::STATUS_READY_FOR_REVIEW, Config::STATUS_COMPLETED ],
				true
			) ) {
				JobManager::reset_retry_count( $job_id );
			}
		} finally {
			$this->release_job_lock( $lock_key );
		}
	}

	public function has_pending_action_for_job( $job_id ) {
		return self::check_pending_action_for_job( $job_id );
	}

	/**
	 * Check if a job has a pending/running AS action.
	 *
	 * @param int $job_id        The job ID to check.
	 * @param int $max_age_secs  If >0, only consider actions scheduled within
	 *                           this many seconds as "live". Older actions are
	 *                           treated as stale (the AS runner is not processing
	 *                           them). Default 0 = no age filter (backward compat).
	 */
	public static function check_pending_action_for_job( $job_id, int $max_age_secs = 0 ): bool {
		if ( $max_age_secs > 0 ) {
			// Direct DB query: faster and allows age filtering that the AS API
			// does not expose. Matches the args- LIKE patterns used elsewhere.
			global $wpdb;
			$as_table = $wpdb->prefix . 'actionscheduler_actions';
			if ( $wpdb->get_var( "SHOW TABLES LIKE '$as_table'" ) !== $as_table ) {
				return false;
			}
			$live_action = $wpdb->get_var( $wpdb->prepare(
				"SELECT action_id FROM `$as_table`
				 WHERE hook = %s
				   AND status IN ('pending', 'in-progress')
				   AND scheduled_date_gmt > DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d SECOND)
				   AND args LIKE %s
				 LIMIT 1",
				Config::ACTION_PROCESS_JOB,
				$max_age_secs,
				'%"job_id":' . (int) $job_id . '}'
			) );
			return ! empty( $live_action );
		}

		if ( ! function_exists( 'as_get_scheduled_actions' ) ) {
			return false;
		}
		try {
			$pending_actions = as_get_scheduled_actions(
				[
					'hook' => Config::ACTION_PROCESS_JOB,
					'args' => [ 'job_id' => (int) $job_id ],
					'status' => [ \ActionScheduler_Store::STATUS_PENDING, \ActionScheduler_Store::STATUS_RUNNING ],
				],
				'ids',
				Config::AS_GROUP
			);
			return count( $pending_actions ) > 0;
		} catch ( \Throwable $e ) {
			Logger::warning( 'action_check_failed', $job_id, [ 'error' => $e->getMessage() ], '500' );
			return false;
		}
	}

	private function do_process_job( $job_id ) {
		$job = JobManager::get_job( $job_id );

		if ( ! $job ) {
			Logger::error( 'job_failed', $job_id, '', 'Job not found in database.' );
			return;
		}

		if ( JobManager::has_completed_job_for_post( (int) $job->post_id ) ) {
			JobManager::update_status( $job_id, Config::STATUS_DISCARDED );
			// AUDIT FIX 1.1: $lock_key is only defined in process_job(); the
			// undefined variable here threw inside the catch(\Throwable) below
			// and flipped a duplicate-guard discard into FAILED + retry.
			// Derive the key instead of relying on the caller's scope.
			$this->release_job_lock( 'ai_collage_job_lock_' . (int) $job_id );
			Logger::info( 'job_skipped_post_already_completed', $job_id, [
				'post_id' => (int) $job->post_id,
			], '200', 'A completed job already exists for this post; not re-processing.' );
			return;
		}

		if ( $job->status === Config::STATUS_REWRITING || $job->status === Config::STATUS_RENDERING ) {
			$stale_seconds = time() - strtotime( $job->updated_at . ' UTC' );
			if ( $stale_seconds > 300 ) {
				$suffix = ( $job->status === Config::STATUS_REWRITING ) ? 'rewrite' : 'render';
				JobManager::update_status( $job_id, Config::STATUS_FAILED );
				// Release lock immediately so the next poll_campaigns() can re-queue this post
				// without waiting for the lock TTL (900s) or daily cleanup.
				\delete_transient( 'ai_collage_job_lock_' . (int) $job_id );
				Logger::error( $suffix . '_stale_timeout', $job_id, [
					'stale_seconds' => $stale_seconds,
				], '500', ucfirst( $suffix ) . ' job timed out after 300s, marked as failed' );
				return;
			}
		}

		$campaign = get_post_meta( $job->post_id, Config::META_CAMPAIGN_DATA, true );
		if ( ! is_array( $campaign ) ) {
			$campaign = [];
		} else if ( ! empty( $campaign['id'] ) ) {
			// Fetch the freshest campaign settings from the database to prevent stale config
			// if the user updated campaign settings while this job was sitting in the queue.
			$fresh_campaigns = Config::get_option_array( Config::OPTION_CAMPAIGNS, [] );
			foreach ( $fresh_campaigns as $fresh_c ) {
				if ( ( $fresh_c['id'] ?? '' ) === $campaign['id'] ) {
					$campaign = array_merge( $campaign, $fresh_c );
					// Update the snapshot so subsequent steps (like render) see the freshest data too
					update_post_meta( $job->post_id, Config::META_CAMPAIGN_DATA, $campaign );
					break;
				}
			}
		}

		AIProviderRegistry::set_context( [
			'job_id' => $job_id,
			'post_id' => $job->post_id,
			'caller' => 'QueueProcessor::process_job',
		] );

		try {
			switch ( $job->status ) {

				case Config::STATUS_PENDING:
					$this->step_rewrite( $job, $campaign );
					$job = JobManager::get_job( $job_id );
					if ( ! $job ) {
						throw new \Exception( 'Job record disappeared after rewrite step.' );
					}
					$this->step_render( $job, $campaign );
					break;

				case Config::STATUS_REWRITING:
					$job = JobManager::get_job( $job_id );
					if ( ! $job ) {
						throw new \Exception( 'Job record disappeared on rewriting resume.' );
					}
					$this->step_render( $job, $campaign );
					break;

case Config::STATUS_RENDERING:
			$job = JobManager::get_job( $job_id );
			if ( ! $job ) {
				throw new \Exception( 'Job record disappeared on rendering resume.' );
			}
			$this->step_render( $job, $campaign );
			break;

		case Config::STATUS_COMPLETED:
			Logger::info( 'job_already_completed_skip', $job_id, [], '200' );
			return;

		case Config::STATUS_FAILED:
			Logger::info( 'job_already_failed_skip', $job_id, [], '200' );
			return;

		case Config::STATUS_DISCARDED:
			Logger::info( 'job_already_discarded_skip', $job_id, [], '200' );
			return;

			case Config::STATUS_SCHEDULED:
 					$job = JobManager::get_job( $job_id );
 					if ( ! $job ) {
 						throw new \Exception( 'Job record disappeared on scheduled resume.' );
 					}
 					$this->step_render( $job, $campaign );
 					break;

 				case Config::STATUS_READY_FOR_REVIEW:
 					Logger::info( 'job_already_in_review_skip', $job_id, [], '200' );
 					return;

 				default:
 					Logger::error( 'job_unknown_status', $job_id, [ 'status' => $job->status ], '500', "Unknown job status: {$job->status}" );
 					return;
 		}
		} catch ( \Throwable $e ) {
			$error_msg = $e->getMessage();
			$retry_count = ( $job && isset( $job->retry_count ) ) ? (int) $job->retry_count : 0;
			$max_retries = 3;

// Chain exhaustion: all providers/models tried, all failed.
 			// The chain already tried each provider and model once.
 			// Retrying at job level won't help — mark as FAILED immediately.
 			if ( strpos( $error_msg, 'All providers failed' ) !== false ) {
 				JobManager::update_status( $job_id, Config::STATUS_FAILED );
 				\delete_transient( 'ai_collage_job_lock_' . (int) $job_id );

				// CRITICAL FIX: Clear the job_created meta so FeedIngester doesn't
				// create a duplicate job for the same post. The job has permanently
				// failed — the post should be available for re-processing if needed.
				if ( $job && isset( $job->post_id ) ) {
					delete_post_meta( (int) $job->post_id, '_ai_collage_job_created' );
					\delete_transient( 'ai_collage_queued_recent_' . (int) $job->post_id );
				}

 				Logger::error( 'job_chain_exhausted', $job_id, [
 					'error' => $error_msg,
 					'class' => get_class( $e ),
 					'file' => $e->getFile() . ':' . $e->getLine(),
 				], '500', $error_msg );
 				return;
 			}

			$http_code = 0;
			if ( preg_match( '/HTTP (\d{3})/', $error_msg, $m ) ) {
				$http_code = (int) $m[1];
			}

			$provider_name = '';
			if ( $job ) {
				$campaign = get_post_meta( $job->post_id, Config::META_CAMPAIGN_DATA, true );
				if ( is_array( $campaign ) ) {
					$ai_strategy = Config::get_campaign_value( $campaign, 'ai_strategy', Config::DEFAULT_STRATEGY );
					$provider_name = Config::strategy_to_provider( $ai_strategy );
				}
			}

			$error_info = APIErrorParser::parse( $provider_name, (int) $http_code, '', $error_msg );

 			if ( $error_info->is_retryable && $retry_count < $max_retries ) {
 				$delay = self::compute_smart_delay( $error_info, $retry_count );

 				if ( $error_info->error_type === APIErrorInfo::TYPE_QUOTA_RPD ) {
 					$delay = 30;
 				}

 				$delay = min( $delay, 600 );

 				if ( $error_info->error_type === APIErrorInfo::TYPE_TRANSIENT
 					|| $error_info->error_type === APIErrorInfo::TYPE_SERVER_OVERLOADED ) {
 					$delay = min( $delay, 120 );
 				}

				// AUDIT FIX F2: process_job() already incremented the attempt
				// counter for THIS attempt before any work started. Do not
				// increment again here, or a job would burn through its budget
				// twice as fast and be quarantined after 2 real attempts.
				$new_retry_count = $retry_count;
				JobManager::update_status( $job_id, Config::STATUS_PENDING );

				if ( function_exists( 'as_schedule_single_action' ) ) {
					as_schedule_single_action(
						time() + $delay,
						Config::ACTION_PROCESS_JOB,
						[ 'job_id' => $job_id ],
						Config::AS_GROUP
					);
				}

				QuotaStateManager::record_failure( $provider_name, $error_info );

				Logger::warning( 'job_retry_scheduled', $job_id, [
					'error' => $error_msg,
					'error_type' => $error_info->error_type,
					'retry_after_from_api' => $error_info->get_retry_after(),
					'computed_delay' => $delay,
					'retry_attempt' => $new_retry_count,
					'provider' => $provider_name,
				], '500' );
			} else {
				JobManager::update_status( $job_id, Config::STATUS_FAILED );
				\delete_transient( 'ai_collage_job_lock_' . (int) $job_id );

				// Clear job_created meta on permanent failure to allow re-processing.
				if ( $job && isset( $job->post_id ) ) {
					delete_post_meta( (int) $job->post_id, '_ai_collage_job_created' );
					\delete_transient( 'ai_collage_queued_recent_' . (int) $job->post_id );
				}

				Logger::error( 'job_exception', $job_id, [
					'error' => $error_msg,
					'error_type' => $error_info->error_type,
					'class' => get_class( $e ),
					'file' => $e->getFile() . ':' . $e->getLine(),
				], '500', $error_msg );
			}
		}
	}

    private function step_rewrite( $job, array $campaign ) {
        JobManager::update_status( $job->id, Config::STATUS_REWRITING );

		$raw_content = get_post_meta( $job->post_id, Config::META_RSS_CONTENT, true );
		if ( empty( $raw_content ) ) {
			$raw_content = get_post_field( 'post_content', $job->post_id );
		}
		$clean_content = ContentCleaner::clean( $raw_content );

 		if ( empty( trim( wp_strip_all_tags( $clean_content ) ) ) ) {
			JobManager::update_status( $job->id, Config::STATUS_FAILED );
			// @MODIFIED: Hard delete the post instead of trashing.
			// Trashed posts bypass the `before_delete_post` hook, which leaves 
			// orphaned media attachments and job database records in the system.
			wp_delete_post( $job->post_id, true );
			Logger::error( 'empty_post_content', $job->id, [ 'post_id' => $job->post_id ], '400', 'Post content is empty; cannot proceed with AI rewrite.' );
			throw new \Exception( 'Post content is empty; cannot proceed with AI rewrite.' );
		}

		$viability_enabled = (bool) get_option( Config::OPTION_VIABILITY_SCORING_ENABLED, false );
		$log_only_mode = (bool) get_option( Config::OPTION_VIABILITY_LOG_ONLY_MODE, true );
		$threshold = (int) get_option( Config::OPTION_VIABILITY_SCORE_THRESHOLD, 7 );

		if ( $viability_enabled ) {
			$viability_strategy = Config::get_campaign_value( $campaign, 'ai_strategy', Config::DEFAULT_STRATEGY );
			$viability_provider_name = Config::strategy_to_provider( $viability_strategy );
			$viability_provider = null;

			try {
				$viability_provider = AIProviderRegistry::get_provider_instance( $viability_provider_name );
			} catch ( \Throwable $e ) {
				$viability_provider = null;
			}

			if ( $viability_provider !== null ) {
				$viability = ContentRewriter::evaluate_news_viability( $viability_provider, $clean_content, [
					'job_id' => $job->id,
					'post_id' => $job->post_id,
					'caller' => 'QueueProcessor::step_rewrite::viability',
				] );

				$score = $viability['score'] ?? 5;
				$reason = $viability['reason'] ?? '';

				JobManager::update_viability_score( $job->id, $score, $reason );

				Logger::info( Config::LOG_ACTION_VIABILITY_SCORED, $job->id, [
					'score' => $score,
					'reason' => $reason,
					'threshold' => $threshold,
					'log_only' => $log_only_mode,
				], '200' );

				if ( ! $log_only_mode && $score < $threshold ) {
					JobManager::update_status( $job->id, Config::STATUS_DISCARDED );
					\delete_transient( 'ai_collage_job_perm_fail_' . (int) $job->id );
					Logger::info( Config::LOG_ACTION_VIABILITY_DISCARDED, $job->id, [
						'score' => $score,
						'threshold' => $threshold,
						'reason' => $reason,
					], '200' );
					return;
				}
			}
		}

        $ai_strategy = Config::get_campaign_value( $campaign, 'ai_strategy', Config::DEFAULT_STRATEGY );
        $template = Config::get_campaign_value( $campaign, 'template', Config::DEFAULT_TEMPLATE );

        $template_category = 'news';
        $vmap = Config::get_vertical_category_map();

        // ALWAYS respect target_vertical first, regardless of template setting.
        // Vertical is the user's explicit intent. Template is a layout choice.
        if ( ! empty( $campaign['target_vertical'] ) && isset( $vmap[ $campaign['target_vertical'] ] ) ) {
            $template_category = $vmap[ $campaign['target_vertical'] ];
        } elseif ( $template !== Config::TEMPLATE_AUTO ) {
            // Only fall back to template-based detection if no vertical is set
            $categories = Config::get_template_categories();
            foreach ( $categories as $cat => $templates ) {
                if ( in_array( $template, $templates, true ) ) {
                    $template_category = $cat;
                    break;
                }
            }
        }

		$rewrite_context = [
			'job_id' => $job->id,
			'post_id' => $job->post_id,
			'caller' => 'QueueProcessor::step_rewrite',
			'strategy' => $ai_strategy,
		];

		$provider_name = Config::strategy_to_provider( $ai_strategy );

		try {
			$ai_provider = AIProviderRegistry::get_provider_instance( $provider_name );
		} catch ( \Throwable $e ) {
			throw new \Exception( "Failed to create AI provider '{$provider_name}': " . $e->getMessage() );
		}

		if ( ! $ai_provider instanceof \AiSocialCollage\Contracts\AIProviderInterface ) {
			throw new \Exception( "AI provider '{$provider_name}' resolved to an invalid instance." );
		}

		$rewriter = new ContentRewriter( $ai_provider, $rewrite_context, $template_category, $campaign['output_language'] ?? 'auto' );
		$ai_data = $rewriter->rewrite_with_fallback( $clean_content, $provider_name );

		if ( ! $ai_data || empty( $ai_data['headline'] ) ) {
			throw new \Exception( 'AI content generation failed or returned empty headline.' );
		}

 		if ( self::is_error_sentinel( $ai_data['headline'], $ai_data['hook'] ?? '' ) ) {
 			throw new \Exception( 'AI returned an error message instead of real content: ' . $ai_data['headline'] );
 		}
 
 		if ( ! mb_check_encoding( $ai_data['headline'], 'UTF-8' ) || ! mb_check_encoding( $ai_data['hook'], 'UTF-8' ) ) {
 			throw new \Exception( 'AI response contains invalid UTF-8 encoding in headline or hook.' );
 		}
 		if ( self::is_mojibake( $ai_data['headline'] ) || self::is_mojibake( $ai_data['hook'] ?? '' ) ) {
 			throw new \Exception( 'AI response contains mojibake (encoding corruption) in headline or hook.' );
 		}
 
 if ( ! empty( $ai_data['_headline_verified'] ) ) {
JobManager::update_headline_verified( $job->id, true );
}
unset( $ai_data['_headline_verified'] );

JobManager::update_job_data( $job->id, $ai_data['headline'], $ai_data['hook'] );

if ( ! empty( $ai_data['detailed_description'] ) ) {
JobManager::update_detailed_description( $job->id, $ai_data['detailed_description'] );
}

// NEW: Store eyebrow and key_terms
if ( ! empty( $ai_data['eyebrow'] ) ) {
JobManager::update_eyebrow_key_terms( $job->id, $ai_data['eyebrow'], $ai_data['key_terms'] ?? [] );
}

// Store emphasis_word for headline highlighting
if ( ! empty( $ai_data['emphasis_word'] ) ) {
JobManager::update_emphasis_word( $job->id, $ai_data['emphasis_word'] );
}

$resolved_lang = $campaign['output_language'] ?? 'auto';
if ( $resolved_lang === 'auto' ) {
	$resolved_lang = $ai_data['language'] ?? '';
	if ( empty( $resolved_lang ) || ! in_array( $resolved_lang, [ 'en', 'ur' ], true ) ) {
		$source_lang = Config::detect_language( $clean_content );
		$resolved_lang = ( $source_lang === 'ur' ) ? 'ur' : ( in_array( $template_category, [ 'celebrity-urdu', 'controversy-urdu', 'emotional-urdu', 'breaking-urdu', 'inspirational-urdu' ], true ) ? 'ur' : 'en' );
	}
}

$ai_meta = [
	'suggested_template' => $ai_data['suggested_template'] ?? Config::DEFAULT_TEMPLATE,
	'suggested_category' => $ai_data['suggested_category'] ?? 'news',
	'ai_language' => $resolved_lang,
	'ai_hashtags' => $ai_data['hashtags'] ?? [],
	'ai_headline' => $ai_data['headline'] ?? '',
	'ai_hook' => $ai_data['hook'] ?? '',
	'ai_detailed_description' => $ai_data['detailed_description'] ?? '',
	'ai_x_hashtags' => $ai_data['x_hashtags'] ?? [],
	'ai_x_description' => $ai_data['x_description'] ?? '',
	'ai_mentions' => $ai_data['mentions'] ?? [],
	'ai_yt_title' => $ai_data['yt_title'] ?? '',
	'ai_yt_description' => $ai_data['yt_description'] ?? '',
];

if ( ! empty( $ai_data['x_description'] ) ) {
	$x_hashtags = $ai_data['x_hashtags'] ?? $ai_data['hashtags'] ?? [];
	$x_text = trim( $ai_data['x_description'] );
	if ( ! empty( $x_hashtags ) ) {
		$x_text .= "\n" . implode( ' ', array_slice( $x_hashtags, 0, 5 ) );
	}
	$ai_meta['x_content'] = $x_text;
}

update_post_meta( $job->post_id, Config::META_AUTO_META, $ai_meta );
		update_post_meta( $job->post_id, Config::META_GENERATED_AT, current_time( 'mysql' ) );

		$tag_names = [];
		if ( ! empty( $ai_data['hashtags'] ) && is_array( $ai_data['hashtags'] ) ) {
			$tag_names = array_map( function( $tag ) { return ltrim( $tag, '#' ); }, $ai_data['hashtags'] );
			$tag_names = array_slice( array_unique( $tag_names ), 0, 10 );
			wp_set_post_tags( $job->post_id, $tag_names, true );
		}

// Generate WhatsApp broadcast message
try {
	$whatsapp_data = WhatsAppBroadcaster::generate_broadcast_message( $job->post_id );
	if ( ! empty( $whatsapp_data['success'] ) && ! empty( $whatsapp_data['message'] ) ) {
		update_post_meta( $job->post_id, '_ai_collage_whatsapp_message', $whatsapp_data['message'] );
	} else {
		Logger::warning( 'whatsapp_broadcast_skipped', $job->id, [
			'post_id' => $job->post_id,
			'reason' => $whatsapp_data['error'] ?? 'No message generated',
		], '200' );
	}
} catch ( \Throwable $e ) {
	Logger::warning( 'whatsapp_broadcast_failed', $job->id, [
		'post_id' => $job->post_id,
		'error' => $e->getMessage(),
	], '500' );
}

Logger::info( Config::LOG_ACTION_AI_REWRITTEN, $job->id, [ 'strategy' => $ai_strategy, 'category' => $template_category, 'suggested_template' => $ai_meta['suggested_template'], 'suggested_category' => $ai_meta['suggested_category'], 'ai_language' => $ai_meta['ai_language'] ], '200' );
	}

    private function step_render( $job, array $campaign ) {
		JobManager::update_status( $job->id, Config::STATUS_RENDERING );

		$video_enabled = (bool) get_option( Config::OPTION_VIDEO_ENABLED, false );
		if ( $video_enabled && $this->is_video_job( $job, $campaign ) ) {
			Logger::info( 'video_render_branch', $job->id, [
				'reason' => 'Job contains video content, routing to VideoRenderer',
			], '200' );
			return $this->step_render_video( $job, $campaign );
		}

		$validation_result = $this->validate_job_data( $job );
		if ( ! $validation_result['valid'] ) {
			JobManager::update_status( $job->id, Config::STATUS_FAILED );
			Logger::error( 'render_validation_failed', $job->id, [
				'missing_fields' => $validation_result['missing_fields'],
				'invalid_fields' => $validation_result['invalid_fields'],
			], '400', 'Job data validation failed before rendering' );
			throw new \Exception( 'Job data validation failed: ' . implode( ', ', $validation_result['missing_fields'] ) );
		}

		$renderer = new ImageRenderer();

        $template = Config::get_campaign_value( $campaign, 'template', Config::DEFAULT_TEMPLATE );

	$auto_meta = get_post_meta( $job->post_id, Config::META_AUTO_META, true );
	if ( ! is_array( $auto_meta ) ) {
		$auto_meta = [];
	}

	if ( $template === Config::TEMPLATE_AUTO ) {
		$ai_template = $auto_meta['suggested_template'] ?? Config::DEFAULT_TEMPLATE;
		$ai_category = $auto_meta['suggested_category'] ?? 'news';
		$ai_language = $auto_meta['ai_language'] ?? '';

		if ( Config::template_exists( $ai_template ) && $ai_template !== Config::TEMPLATE_AUTO ) {
			$template = $ai_template;
		} else {
			$template = Config::DEFAULT_TEMPLATE;
		}

		Logger::info( Config::LOG_ACTION_AUTO_TEMPLATE_SELECTED, $job->id, [
			'original' => 'auto',
			'selected_template' => $template,
			'selected_category' => $ai_category,
			'ai_language' => $ai_language,
		], '200' );
	}

		if ( ! Config::template_exists( $template ) ) {
			$template = Config::DEFAULT_TEMPLATE;
		}

	$lang_content = get_post_meta( $job->post_id, Config::META_RSS_CONTENT, true );
	if ( empty( $lang_content ) ) {
		$lang_content = get_post_field( 'post_content', $job->post_id );
	}
	$language = Config::resolve_collage_language(
		$job->ai_headline,
		$job->ai_hook,
		$lang_content,
		$auto_meta,
		$campaign
	);
	$template_lang = Config::get_template_language( $template );
	if ( $language !== $template_lang ) {
		if ( $language === 'ur' && $template_lang !== 'ur' ) {
			$ai_suggested = $auto_meta['suggested_template'] ?? '';
			if ( ! empty( $ai_suggested ) && Config::template_exists( $ai_suggested ) && Config::get_template_language( $ai_suggested ) === 'ur' ) {
				$template = $ai_suggested;
			} else {
				$template = Config::TEMPLATE_NEWS_CARD;
			}
		}
		Logger::warning( 'template_language_adjusted', $job->id, [
			'detected' => $language,
			'template_lang' => $template_lang,
			'final_template' => $template,
		] );
	}

		$category = $auto_meta['suggested_category'] ?? '';
		if ( empty( $category ) || ! array_key_exists( $category, Config::get_template_categories() ) ) {
			$category = 'news';
			$categories = Config::get_template_categories();
			foreach ( $categories as $cat => $templates ) {
				if ( in_array( $template, $templates, true ) ) {
					$category = $cat;
					break;
				}
			}
		}

		$image_urls = $this->resolve_additional_images( $job->post_id, $template );

		$brand = is_array( $campaign ) ? Config::get_campaign_brand_settings( $campaign ) : Config::get_brand_settings();

		$original_image_path = '';
		$source_image_present = false;
		$image_url = get_the_post_thumbnail_url( $job->post_id, 'full' ) ?: '';
		
		if ( ! empty( $image_url ) ) {
			$source_image_present = true;
			$original_image_path = $this->resolve_image_path( $image_url );
		} else {
			$image_url = ImageGenerator::generate_for_job( $job );
			$job = JobManager::get_job( $job->id );
			if ( ! $job ) {
				throw new \Exception( 'Job record disappeared after image generation.' );
			}
		}

		if ( empty( $image_url ) && ! empty( $job->ai_generated_image_url ) ) {
			$image_url = $job->ai_generated_image_url;
		}

		// @MODIFIED: Resolution gate — check ORIGINAL source image BEFORE preprocessing.
		// This prevents wasting API calls and CPU cycles on images that cannot produce valid output.
		// The check must happen on the original source, not the potentially cropped result.
		$original_w = 0;
		$original_h = 0;
		if ( ! empty( $original_image_path ) && file_exists( $original_image_path ) ) {
			$original_size = @getimagesize( $original_image_path );
			if ( $original_size ) {
				$original_w = (int) $original_size[0];
				$original_h = (int) $original_size[1];
			}
		}
		// Only enforce size check on source images (not AI-generated images)
		if ( $source_image_present && ( $original_w < 600 || $original_h < 600 ) ) {
			Logger::error( 'render_source_too_small', $job->id, [
				'image_url' => $original_image_path,
				'width' => $original_w,
				'height' => $original_h,
				'minimum' => 600,
			], '400' );
			JobManager::update_status( $job->id, Config::STATUS_FAILED );
			throw new \Exception( sprintf(
				'Render source image too small (%dx%d). Minimum 600×600 required. Job abandoned.',
				$original_w, $original_h
			) );
		}

		if ( ! empty( $original_image_path ) ) {
			JobManager::update_original_image( $job->id, $original_image_path );
		}

		// No image available — fail the job with clear logging.
		if ( empty( $image_url ) ) {
			$provider = get_option( Config::OPTION_IMAGE_PROVIDER, Config::DEFAULT_IMAGE_PROVIDER );
			Logger::error( 'render_failed_no_image_available', $job->id, [
				'provider' => $provider,
				'reason' => 'No image in post content and image provider is set to "' . $provider . '". collage generation cannot proceed without an image.',
			], '400' );
			JobManager::update_status( $job->id, Config::STATUS_FAILED );
			return;
		}

		// STAGES 1, 2, 3 — Sequential Image Pipeline (Acquire clean -> Detect zones -> Crop)
		// Fixes Finding 3: AI-3 and AI-4 now receive the original uncropped source image.
		// We pass $source_image_present so the pipeline can skip Lens/Crop for AI-generated images.
		$image_url = $this->prepare_clean_image( $image_url, $campaign, $job->post_id, $source_image_present );

		// Resolution gate — reject PREPROCESSED images too small for quality rendering.
		// This catches cases where Cloudinary/AI cropping produced an undersized output.
		$source_w = 0;
		$source_h = 0;
		if ( ! empty( $image_url ) && file_exists( $image_url ) ) {
			$render_size = @getimagesize( $image_url );
			if ( $render_size ) {
				$render_w = (int) $render_size[0];
				$render_h = (int) $render_size[1];
				if ( $render_w < 600 || $render_h < 600 ) {
					Logger::error( 'render_source_too_small', $job->id, [
						'image_url' => $image_url,
						'width' => $render_w,
						'height' => $render_h,
						'minimum' => 600,
					], '400' );
					JobManager::update_status( $job->id, Config::STATUS_FAILED );
					throw new \Exception( sprintf(
						'Render source image too small (%dx%d). Minimum 600×600 required. Job abandoned.',
						$render_w, $render_h
					) );
				}
				$source_w = $render_w;
				$source_h = $render_h;
			}
		}

		$job_data = [
			'job_id'        => $job->id,
			'post_id'       => $job->post_id,
			'headline'      => trim( $job->ai_headline ),
			'hook'          => trim( ! empty( $job->ai_detailed_description ) ? $job->ai_detailed_description : $job->ai_hook ),
			'image_url'     => $image_url,
			'image_url_2'   => $image_urls[2] ?? '',
			'image_url_3'   => $image_urls[3] ?? '',
			'image_url_4'   => $image_urls[4] ?? '',
			'template'      => $template,
			'language'      => $language,
			'brand'         => $brand,
			'eyebrow'       => $job->ai_eyebrow ?? '',
			'key_terms'     => ! empty( $job->ai_key_terms ) ? json_decode( $job->ai_key_terms, true ) : [],
			'emphasis_word' => $job->ai_emphasis_word ?? '',
			'category'      => $category,
			'image_zone'    => $campaign['image_zone'] ?? null,
			'text_zone'     => $campaign['text_zone'] ?? null,
			'logo_zone'     => $campaign['logo_zone'] ?? null,
			'source_width'  => $source_w,
			'source_height' => $source_h,
		];

		JobManager::update_template_data( $job->id, $template, $category, $language );

    $attachment_id = 0;
    $render_succeeded = false;

    $watchdog_timeout = Config::RENDER_WATCHDOG_TIMEOUT;
    $prev_time_limit = 0;
    if ( function_exists( 'set_time_limit' ) && (int) @ini_get( 'max_execution_time' ) > 0 ) {
        $prev_time_limit = (int) @ini_get( 'max_execution_time' );
        @set_time_limit( $watchdog_timeout );
    }

    try {
        $attachment_id = $renderer->generate( $job_data );
        $render_succeeded = true;
    } catch ( \Throwable $e ) {
        $error_msg = $e->getMessage();
        Logger::error( 'render_failed', $job->id, [ 'error' => $error_msg, 'class' => get_class( $e ), 'file' => $e->getFile() . ':' . $e->getLine() ], '500' );
        if ( ! empty( $image_url ) && function_exists( 'attachment_url_to_postid' ) ) {
            $fallback_id = attachment_url_to_postid( $image_url );
            if ( $fallback_id > 0 ) {
                $attachment_id = $fallback_id;
                Logger::warning( 'render_fallback_to_ai_image', $job->id, [
                    'attachment_id' => $attachment_id,
                    'original_error' => $error_msg,
                ], '200' );
            }
        }
    } finally {
        if ( $prev_time_limit > 0 && function_exists( 'set_time_limit' ) ) {
            @set_time_limit( $prev_time_limit );
        }
    }

		// Render failure gate: prevent publish/social-dispatch when renderer produced no usable image.
		if ( $attachment_id === 0 ) {
			JobManager::update_status( $job->id, Config::STATUS_FAILED );
			Logger::error( 'render_failed_no_image', $job->id, '', '500', 'Render produced no image; job marked as failed.' );
			return;
		}

		if ( ! $render_succeeded ) {
			JobManager::update_status( $job->id, Config::STATUS_FAILED );
			Logger::error( 'render_failed_no_image', $job->id, '', '500', 'Render failed and fell back to original image; job marked as failed.' );
			return;
		}

		try {
			PostObserver::$suppress = true;
			
			// Check publish mode: campaign-level setting takes priority over global setting
			$campaign_publish_status = Config::get_campaign_value( $campaign, 'publish_status', '' );
			$global_publish_mode = ! empty( $campaign_publish_status ) ? $campaign_publish_status : get_option( Config::OPTION_PUBLISH_MODE, 'draft' );
			$prime_time_enabled = (bool) get_option( Config::OPTION_PRIME_TIME_ENABLED, false );
			
			// Determine post status based on workflow settings
			if ( $global_publish_mode === 'publish' ) {
				if ( $prime_time_enabled ) {
					// Check if current time is within prime time slot
					if ( $this->is_current_time_prime_slot() ) {
						$publish_status = 'publish';
					} else {
						// Schedule for next prime time
						$next_slot = $this->get_next_prime_time_slot();
						if ( $next_slot ) {
							$this->schedule_for_prime_time( $job->id, $next_slot );
							$publish_status = 'future';
						} else {
							$publish_status = 'draft';
						}
					}
				} else {
					$publish_status = 'publish';
				}
			} else {
				$publish_status = 'draft';
			}
			
			// Build Gutenberg blocks for easy editing
			$blocks = [];

			// 1) Featured image block (if attachment exists)
			if ( $attachment_id > 0 ) {
				$blocks[] = '<!-- wp:image {"id":' . $attachment_id . ',"sizeSlug":"full","linkDestination":"none"} -->' .
							'<figure class="wp-block-image size-full"><img src="' . esc_url( wp_get_attachment_url( $attachment_id ) ) . '" alt="" /></figure>' .
							'<!-- /wp:image -->';
			}

			// 2) Headline as H2 heading block
			// Gutenberg heading block save adds class="wp-block-heading" — must match for validation
			$blocks[] = '<!-- wp:heading {"level":2} -->' .
						'<h2 class="wp-block-heading">' . esc_html( $job->ai_headline ) . '</h2>' .
						'<!-- /wp:heading -->';

			// 3) Description as paragraph block
			$desc = ! empty( $job->ai_detailed_description ) ? $job->ai_detailed_description : $job->ai_hook;
			// Strip any existing HTML tags (AI may return <p> tags) to avoid double-wrapping in Gutenberg block
			$desc = wp_strip_all_tags( $desc );
			$desc = wp_kses_post( $desc );
			$blocks[] = '<!-- wp:paragraph -->' .
						'<p>' . $desc . '</p>' .
						'<!-- /wp:paragraph -->';

			$auto_meta = get_post_meta( $job->post_id, Config::META_AUTO_META, true );
			$auto_meta = is_array( $auto_meta ) ? $auto_meta : [];

			// 4) Hashtags paragraph block (if enabled)
			if ( (bool) get_option( Config::OPTION_APPEND_TAGS_TO_POST, false ) ) {
				$ai_hashtags = $auto_meta['ai_hashtags'] ?? [];
				if ( is_array( $ai_hashtags ) && ! empty( $ai_hashtags ) ) {
					$tag_strings = array_map( function( $tag ) {
						return '#' . preg_replace( '/[^\p{L}\p{N}]/u', '', ltrim( $tag, '#' ) );
					}, array_slice( $ai_hashtags, 0, 10 ) );
					$blocks[] = '<!-- wp:paragraph --><p>' . implode( ' ', $tag_strings ) . '</p><!-- /wp:paragraph -->';
				}
			}

			// 5) X content paragraph block
			if ( ! empty( $auto_meta['x_content'] ) ) {
				$blocks[] = '<!-- wp:paragraph --><p>' . esc_html( $auto_meta['x_content'] ) . '</p><!-- /wp:paragraph -->';
			}

			// 6) Mentions paragraph block
			$ai_mentions = $auto_meta['ai_mentions'] ?? [];
			if ( is_array( $ai_mentions ) && ! empty( $ai_mentions ) ) {
				$blocks[] = '<!-- wp:paragraph --><p>' . implode( ' ', array_slice( $ai_mentions, 0, 10 ) ) . '</p><!-- /wp:paragraph -->';
			}

			$post_content = implode( "\n\n", $blocks );

			$post_update = [
				'ID' => $job->post_id,
				'post_status' => $publish_status,
				'post_title' => $job->ai_headline,
				'post_content' => $post_content,
			];

			if ( ! empty( $campaign['destination_category'] ) ) {
				$post_update['post_category'] = [ (int) $campaign['destination_category'] ];
			}

			wp_update_post( $post_update );

			if ( $attachment_id > 0 ) {
				$thumb_set = set_post_thumbnail( $job->post_id, $attachment_id );
				if ( ! $thumb_set ) {
					Logger::warning( 'thumbnail_set_failed', $job->id, [ 'attachment_id' => $attachment_id, 'post_id' => $job->post_id ], '500' );
				}

				$metadata = [
					'attachment_id' => $attachment_id,
					'generated_at' => current_time( 'mysql' ),
					'template' => $job_data['template'],
					'template_category' => $category,
					'language' => $language,
					'post_id' => $job->post_id,
				];
				JobManager::update_image_metadata( $job->id, wp_json_encode( $metadata ) );

				SocialBridge::dispatch( $job->post_id, $attachment_id, $job->id, $job->ai_detailed_description ?? '', $job->ai_headline );
			}

    $status_result = JobManager::update_status( $job->id, Config::STATUS_COMPLETED );
			if ( false === $status_result ) {
				Logger::error( 'render_status_update_failed', $job->id, [], '500', 'Status could not be updated; reverting thumbnail.' );
				if ( $attachment_id > 0 ) {
					delete_post_thumbnail( $job->post_id );
					wp_delete_attachment( $attachment_id, true );
				}
				throw new \Exception( 'Job status could not be updated after render.' );
			}

			// Clear permanent failure tracking on success.
			\delete_transient( 'ai_collage_job_perm_fail_' . (int) $job->id );
		} finally {
			PostObserver::$suppress = false;
		}
		Logger::info( Config::LOG_ACTION_RENDER_AND_PUBLISH, $job->id, [ 'attachment_id' => $attachment_id ], '200' );

	do_action( Config::ACTION_COMPLETED, $job->post_id, $attachment_id, $job->id );

		$this->run_image_verification( $job, $attachment_id, $original_image_path );
	}

	// ── Video Pipeline ──────────────────────────────────────────────────────

	/**
	 * Detect if a job contains video content that should use the video pipeline.
	 *
	 * @param object $job      Job record.
	 * @param array  $campaign Campaign settings.
	 * @return bool True if job is a video job.
	 */
	private function is_video_job( $job, array $campaign ): bool {
		$content_type = Config::get_campaign_value( $campaign, 'content_type', Config::CONTENT_TYPE_AUTO );
		if ( $content_type === Config::CONTENT_TYPE_IMAGE ) {
			return false;
		}
		if ( $content_type === Config::CONTENT_TYPE_VIDEO ) {
			Logger::info( 'video_forced_by_campaign', $job->id ?? 0, [
				'content_type' => $content_type,
			], '200' );
			return true;
		}

		$post_id = $job->post_id ?? 0;
		if ( $post_id > 0 ) {
			$video_attachments = get_posts( [
				'post_type' => 'attachment',
				'post_parent' => $post_id,
				'post_mime_type' => 'video',
				'posts_per_page' => 1,
			] );
			if ( ! empty( $video_attachments ) ) {
				return true;
			}

			// Check for video embedded in post content (HTML blocks, wp:html, etc.)
			$post = get_post( $post_id );
			if ( $post && ! empty( $post->post_content ) ) {
				$post_content = $post->post_content;
				// Match <video src="..."> with video extension
				if ( preg_match( '/<video[^>]+src\s*=\s*["\']([^"\']+\.(?:mp4|mov|webm|avi|mkv|flv))["\']/i', $post_content, $matches ) ) {
					$video_url = esc_url_raw( trim( $matches[1] ) );
					if ( ! empty( $video_url ) ) {
						// Store in campaign for step_render_video to use
						$campaign['video_source_url'] = $video_url;
						return true;
					}
				}
				// Match <video><source src="..."></video> pattern
				if ( preg_match( '/<video[^>]*>.*?<source[^>]+src\s*=\s*["\']([^"\']+\.(?:mp4|mov|webm|avi|mkv|flv))["\']/is', $post_content, $matches ) ) {
					$video_url = esc_url_raw( trim( $matches[1] ) );
					if ( ! empty( $video_url ) ) {
						$campaign['video_source_url'] = $video_url;
						return true;
					}
				}
			}
		}

		if ( ! empty( $job->ai_generated_image_url ) ) {
			$ext = strtolower( pathinfo( $job->ai_generated_image_url, PATHINFO_EXTENSION ) );
			if ( VideoProcessor::is_video_extension( $ext ) ) {
				return true;
			}
		}

		if ( ! empty( $campaign['video_source_url'] ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Render a video job through the video pipeline.
	 *
	 * @param object $job      Job record.
	 * @param array  $campaign Campaign settings.
	 */
	private function step_render_video( $job, array $campaign ) {
		$brand = is_array( $campaign ) ? Config::get_campaign_brand_settings( $campaign ) : Config::get_brand_settings();

		$auto_meta = get_post_meta( $job->post_id, Config::META_AUTO_META, true );
		if ( ! is_array( $auto_meta ) ) {
			$auto_meta = [];
		}

		$lang_content = get_post_meta( $job->post_id, Config::META_RSS_CONTENT, true );
		if ( empty( $lang_content ) ) {
			$lang_content = get_post_field( 'post_content', $job->post_id );
		}
		$language = Config::resolve_collage_language(
			$job->ai_headline,
			$job->ai_hook,
			$lang_content,
			$auto_meta,
			$campaign
		);

		$video_path = '';
		$post_id = $job->post_id ?? 0;

		// Re-extract <video> URL from post content directly here.
		// is_video_job() detects the URL but cannot propagate it back by-value
		// (PHP arrays are pass-by-value), so $campaign['video_source_url'] is
		// empty when we arrive. We resolve it ourselves to avoid the
		// dead-mutation bug in is_video_job():927-942 and to keep this method
		// robust against any future caller that forgets to forward the URL.
		if ( empty( $campaign['video_source_url'] ) && $post_id > 0 ) {
			$post_obj = get_post( $post_id );
			if ( $post_obj && ! empty( $post_obj->post_content ) ) {
				$pc = $post_obj->post_content;
				$exts = '(?:mp4|mov|webm|avi|mkv|flv)(?:\?[^\s"\'<>]*)?';
				$found = '';
				if ( preg_match( '/<video[^>]+src\s*=\s*["\']([^"\']+' . $exts . ')["\']/i', $pc, $m ) ) {
					$found = $m[1];
				} elseif ( preg_match( '/<video[^>]*>.*?<source[^>]+src\s*=\s*["\']([^"\']+' . $exts . ')["\']/is', $pc, $m ) ) {
					$found = $m[1];
				} elseif ( preg_match( '/<video[^>]+src\s*=\s*["\']([^"\']+)["\']/i', $pc, $m ) ) {
					// Permissive fallback: any <video src="..."> tag without strict extension.
					// Useful when media library URLs have no extension or use uncommon formats.
					$found = $m[1];
				}
				if ( $found !== '' ) {
					$campaign['video_source_url'] = esc_url_raw( trim( $found ) );
					Logger::info( 'video_url_reextracted', $job->id, [
						'source'    => 'step_render_video',
						'video_url' => $campaign['video_source_url'],
					], '200' );
				}
			}
		}
		if ( empty( $campaign['video_source_url'] ) ) {
			Logger::warning( 'video_url_not_resolved', $job->id, [
				'note' => 'Job routed to video pipeline but no video URL resolvable from post content, attachments, or ai_generated_image_url.',
			], '500' );
		}

		// Priority 1: Check for HTML-embedded video URL (from is_video_job detection)
		if ( ! empty( $campaign['video_source_url'] ) ) {
			$video_url = $campaign['video_source_url'];
			// Check if it's a local WordPress upload URL
			$upload_dir = wp_upload_dir();
			if ( strpos( $video_url, $upload_dir['baseurl'] ) === 0 ) {
				$relative = str_replace( $upload_dir['baseurl'], '', $video_url );
				$local_path = $upload_dir['basedir'] . $relative;
				if ( file_exists( $local_path ) ) {
					$video_path = $local_path;
					Logger::info( 'html_video_local_found', $job->id, [ 'url' => $video_url, 'path' => $local_path ], '200' );
				}
			} else {
				// Remote URL - download to temp
				$temp_dir = AI_SOCIAL_COLLAGE_PATH . 'assets/temp';
				if ( ! is_dir( $temp_dir ) ) {
					wp_mkdir_p( $temp_dir );
				}
				$video_ext = pathinfo( $video_url, PATHINFO_EXTENSION );
				if ( empty( $video_ext ) || ! in_array( $video_ext, [ 'mp4', 'mov', 'webm', 'avi', 'mkv', 'flv' ], true ) ) {
					$video_ext = 'mp4';
				}
				$local_path = $temp_dir . '/html_video_' . $post_id . '_' . uniqid() . '.' . $video_ext;
				$downloaded = download_url( $video_url, 120 );
				if ( ! is_wp_error( $downloaded ) && file_exists( $downloaded ) ) {
					if ( @copy( $downloaded, $local_path ) ) {
						@unlink( $downloaded );
						if ( file_exists( $local_path ) ) {
							$video_path = $local_path;
							Logger::info( 'html_video_downloaded', $job->id, [ 'url' => $video_url, 'path' => $local_path ], '200' );
						}
					} else {
						@unlink( $downloaded );
					}
				}
				if ( empty( $video_path ) ) {
					Logger::warning( 'html_video_download_failed', $job->id, [ 'url' => $video_url, 'error' => is_wp_error( $downloaded ) ? $downloaded->get_error_message() : 'file not found' ] );
				}
			}
		}

		// Priority 2: Check WordPress video attachment
		if ( empty( $video_path ) && $post_id > 0 ) {
			$video_attachments = get_posts( [
				'post_type' => 'attachment',
				'post_parent' => $post_id,
				'post_mime_type' => 'video',
				'posts_per_page' => 1,
				'orderby' => 'menu_order',
				'order' => 'ASC',
			] );
			if ( ! empty( $video_attachments ) ) {
				$video_path = get_attached_file( $video_attachments[0]->ID );
			}
		}

		$job_data = [
			'job_id'        => $job->id,
			'post_id'       => $job->post_id,
			'headline'      => trim( $job->ai_headline ),
			'hook'          => trim( ! empty( $job->ai_detailed_description ) ? $job->ai_detailed_description : $job->ai_hook ),
			'video_path'    => $video_path,
			'language'      => $language,
			'brand'         => $brand,
			'category'      => $auto_meta['suggested_category'] ?? 'news',
			'campaign'      => $campaign,
		];

		$attachment_id = 0;
		$render_succeeded = false;

		$watchdog_timeout = Config::RENDER_WATCHDOG_TIMEOUT;
		$prev_time_limit = 0;
		if ( function_exists( 'set_time_limit' ) && (int) @ini_get( 'max_execution_time' ) > 0 ) {
			$prev_time_limit = (int) @ini_get( 'max_execution_time' );
			@set_time_limit( $watchdog_timeout );
		}

		try {
			$renderer = new VideoRenderer();
			$render_result = $renderer->generate( $job_data );
			$attachment_id = $render_result['attachment_id'] ?? 0;
			$r2_url        = $render_result['r2_url'] ?? false;
			$render_succeeded = true;

			// R2 upload completed during render. Persist video_url to job table
			// BEFORE marking the job complete — single source of truth.
			if ( $r2_url && is_string( $r2_url ) ) {
				\AiSocialCollage\Database\JobManager::update_job_fields( $job->id, [
					'video_url' => $r2_url,
				] );

				// Compute publish_at for cron scheduler (Buffer cron will pick up at publish_at).
				$campaign_for_schedule = get_post_meta( $job->post_id, Config::META_CAMPAIGN_DATA, true );
				if ( is_array( $campaign_for_schedule ) ) {
					$publish_time = Config::get_campaign_value( $campaign_for_schedule, 'publish_time', '09:00' );
					$frequency    = Config::get_campaign_value( $campaign_for_schedule, 'frequency', Config::FREQUENCY_1_DAY );
					$publish_at   = self::compute_publish_at( $publish_time, $frequency );
					\AiSocialCollage\Database\JobManager::update_job_fields( $job->id, [
						'publish_at' => $publish_at,
					] );
				}
			}
		} catch ( \Throwable $e ) {
			$error_msg = $e->getMessage();
			Logger::error( 'video_render_failed', $job->id, [
				'error' => $error_msg,
				'class' => get_class( $e ),
				'file' => $e->getFile() . ':' . $e->getLine(),
			], '500' );
		} finally {
			if ( $prev_time_limit > 0 && function_exists( 'set_time_limit' ) ) {
				@set_time_limit( $prev_time_limit );
			}
		}

		if ( $attachment_id === 0 ) {
			JobManager::update_status( $job->id, Config::STATUS_FAILED );
			if ( $render_succeeded ) {
				Logger::error( 'video_render_failed_no_output', $job->id, '', '500', 'Video render produced no output; job marked as failed.' );
			}
			return;
		}

		if ( ! $render_succeeded ) {
			JobManager::update_status( $job->id, Config::STATUS_FAILED );
			return;
		}

		// If R2+Buffer auto is enabled and the publish_mode is 'publish' (immediate),
		// upload to R2 NOW and push to Buffer in the same request. The R2 upload
		// is normally deferred to PostObserver::on_publish_transition, but that
		// hook is suppressed below when this pipeline publishes the post — so
		// we MUST upload here to avoid the "Buffer shares local URL" fallback.
		$campaign_publish_status = Config::get_campaign_value( $campaign, 'publish_status', '' );
		$global_publish_mode     = ! empty( $campaign_publish_status ) ? $campaign_publish_status : get_option( Config::OPTION_PUBLISH_MODE, 'draft' );

		// Upload to R2 when publishing immediately (if not already uploaded)
		if ( $attachment_id > 0 && empty( $r2_url ) && $global_publish_mode === 'publish' && Config::is_r2_configured() && Config::is_video_r2_buffer_auto_enabled() ) {
			$file_path = get_attached_file( $attachment_id );
			if ( $file_path && file_exists( $file_path ) ) {
				$upload_renderer = new VideoRenderer();
				$uploaded_r2_url = $upload_renderer->maybe_upload_to_r2( $file_path, $job->id, $attachment_id );
				if ( is_string( $uploaded_r2_url ) && $uploaded_r2_url !== '' ) {
					$r2_url = $uploaded_r2_url;
					Logger::info( 'r2_upload_synchronously', $job->id, [
						'post_id' => $job->post_id,
						'r2_url' => $r2_url,
					], '200' );
				} else {
					Logger::error( 'r2_upload_synchronously_failed', $job->id, [
						'post_id' => $job->post_id,
					], '500', 'R2 upload failed during render; Buffer sharing will be skipped.' );
				}
			}
		}

		if ( $r2_url && is_string( $r2_url ) && $global_publish_mode === 'publish' && Config::is_buffer_enabled() && Config::is_video_r2_buffer_auto_enabled() ) {
			try {
				$buffer_result = \AiSocialCollage\Services\BufferIntegration::share( $job->post_id, $attachment_id );
				if ( $buffer_result ) {
					Logger::info( 'buffer_pushed_synchronously', $job->id, [
						'post_id'   => $job->post_id,
						'video_url' => $r2_url,
					], '200' );
				} else {
					Logger::warning( 'buffer_push_returned_false_synchronously', $job->id, [
						'post_id' => $job->post_id,
					], '500' );
				}
			} catch ( \Throwable $e ) {
				Logger::warning( 'buffer_push_exception_synchronously', $job->id, [
					'post_id' => $job->post_id,
					'error'   => $e->getMessage(),
				], '500' );
			}
		}

		try {
			PostObserver::$suppress = true;

			$campaign_publish_status = Config::get_campaign_value( $campaign, 'publish_status', '' );
			$global_publish_mode = ! empty( $campaign_publish_status ) ? $campaign_publish_status : get_option( Config::OPTION_PUBLISH_MODE, 'draft' );
			$prime_time_enabled = (bool) get_option( Config::OPTION_PRIME_TIME_ENABLED, false );

			if ( $global_publish_mode === 'publish' ) {
				if ( $prime_time_enabled ) {
					if ( $this->is_current_time_prime_slot() ) {
						$publish_status = 'publish';
					} else {
						$next_slot = $this->get_next_prime_time_slot();
						if ( $next_slot ) {
							$this->schedule_for_prime_time( $job->id, $next_slot );
							$publish_status = 'future';
						} else {
							$publish_status = 'draft';
						}
					}
				} else {
					$publish_status = 'publish';
				}
			} else {
				$publish_status = 'draft';
			}

			// Build Gutenberg blocks for easy editing
			$blocks = [];

			// 1) Featured video block (if attachment exists)
			if ( $attachment_id > 0 ) {
				$vid_url = wp_get_attachment_url( $attachment_id );
				if ( $vid_url ) {
					$blocks[] = '<!-- wp:video {"src":"' . esc_url( $vid_url ) . '"} -->' .
								'<figure class="wp-block-video"><video controls src="' . esc_url( $vid_url ) . '"></video></figure>' .
								'<!-- /wp:video -->';
				}
			}

			// 2) Headline as H2 heading block
			// Gutenberg heading block save adds class="wp-block-heading" — must match for validation
			$blocks[] = '<!-- wp:heading {"level":2} -->' .
						'<h2 class="wp-block-heading">' . esc_html( $job->ai_headline ) . '</h2>' .
						'<!-- /wp:heading -->';

			// 3) Description as paragraph block
			$desc = ! empty( $job->ai_detailed_description ) ? $job->ai_detailed_description : $job->ai_hook;
			// Strip any existing HTML tags (AI may return <p> tags) to avoid double-wrapping in Gutenberg block
			$desc = wp_strip_all_tags( $desc );
			$desc = wp_kses_post( $desc );
			$blocks[] = '<!-- wp:paragraph -->' .
						'<p>' . $desc . '</p>' .
						'<!-- /wp:paragraph -->';

			$auto_meta = get_post_meta( $job->post_id, Config::META_AUTO_META, true );
			$auto_meta = is_array( $auto_meta ) ? $auto_meta : [];

			// 4) Hashtags paragraph block (if enabled)
			if ( (bool) get_option( Config::OPTION_APPEND_TAGS_TO_POST, false ) ) {
				$ai_hashtags = $auto_meta['ai_hashtags'] ?? [];
				if ( is_array( $ai_hashtags ) && ! empty( $ai_hashtags ) ) {
					$tag_strings = array_map( function( $tag ) {
						return '#' . preg_replace( '/[^\p{L}\p{N}]/u', '', ltrim( $tag, '#' ) );
					}, array_slice( $ai_hashtags, 0, 10 ) );
					$blocks[] = '<!-- wp:paragraph --><p>' . implode( ' ', $tag_strings ) . '</p><!-- /wp:paragraph -->';
				}
			}

			// 5) X content paragraph block
			if ( ! empty( $auto_meta['x_content'] ) ) {
				$blocks[] = '<!-- wp:paragraph --><p>' . esc_html( $auto_meta['x_content'] ) . '</p><!-- /wp:paragraph -->';
			}

			// 5b) YouTube Shorts title + description paragraph blocks (stored in post meta for social dispatch)
			if ( ! empty( $auto_meta['ai_yt_title'] ) ) {
				$blocks[] = '<!-- wp:paragraph --><p><strong>YouTube Title:</strong> ' . esc_html( $auto_meta['ai_yt_title'] ) . '</p><!-- /wp:paragraph -->';
			}
			if ( ! empty( $auto_meta['ai_yt_description'] ) ) {
				$blocks[] = '<!-- wp:paragraph --><p><strong>YouTube Description:</strong> ' . esc_html( $auto_meta['ai_yt_description'] ) . '</p><!-- /wp:paragraph -->';
			}

			// 6) Mentions paragraph block
			$ai_mentions = $auto_meta['ai_mentions'] ?? [];
			if ( is_array( $ai_mentions ) && ! empty( $ai_mentions ) ) {
				$blocks[] = '<!-- wp:paragraph --><p>' . implode( ' ', array_slice( $ai_mentions, 0, 10 ) ) . '</p><!-- /wp:paragraph -->';
			}

			$post_content = implode( "\n\n", $blocks );

			$post_update = [
				'ID' => $job->post_id,
				'post_status' => $publish_status,
				'post_title' => $job->ai_headline,
				'post_content' => $post_content,
			];

			if ( ! empty( $campaign['destination_category'] ) ) {
				$post_update['post_category'] = [ (int) $campaign['destination_category'] ];
			}

			wp_update_post( $post_update );

			if ( $attachment_id > 0 ) {
				set_post_thumbnail( $job->post_id, $attachment_id );

				$metadata = [
					'attachment_id' => $attachment_id,
					'generated_at' => current_time( 'mysql' ),
					'type' => 'video-reel',
					'language' => $language,
					'post_id' => $job->post_id,
				];
				if ( $r2_url ) {
					$metadata['r2_url'] = $r2_url;
				}
				JobManager::update_image_metadata( $job->id, wp_json_encode( $metadata ) );

				SocialBridge::dispatch( $job->post_id, $attachment_id, $job->id, $job->ai_detailed_description ?? '', $job->ai_headline );
			}

		// R2 upload + publish_at deferred to publish time (see PostObserver::on_publish_transition)
		$status_result = JobManager::update_status( $job->id, Config::STATUS_COMPLETED );
		if ( false === $status_result ) {
			Logger::error( 'video_render_status_update_failed', $job->id, [], '500', 'Status could not be updated after video render; reverting thumbnail.' );
			if ( $attachment_id > 0 ) {
				delete_post_thumbnail( $job->post_id );
				wp_delete_attachment( $attachment_id, true );
			}
			throw new \Exception( 'Job status could not be updated after video render.' );
		}

		// Clear permanent failure tracking on success.
		\delete_transient( 'ai_collage_job_perm_fail_' . (int) $job->id );
	} finally {
		PostObserver::$suppress = false;
	}

		Logger::info( Config::LOG_ACTION_RENDER_AND_PUBLISH, $job->id, [
			'attachment_id' => $attachment_id,
			'type' => 'video-reel',
		], '200' );

		do_action( Config::ACTION_COMPLETED, $job->post_id, $attachment_id, $job->id );
	}

	private function resolve_image_path( string $image_url ): string {
		if ( strpos( $image_url, ABSPATH ) === 0 ) {
			return $image_url;
		}
		$attachment_id = attachment_url_to_postid( $image_url );
		if ( $attachment_id > 0 ) {
			return get_attached_file( $attachment_id );
		}
		return '';
	}

	private function run_image_verification( $job, int $attachment_id, string $original_image_path ): void {
		if ( ! (bool) get_option( Config::OPTION_VERIFICATION_ENABLED, false ) || $attachment_id <= 0 ) {
			return;
		}
		if ( empty( $original_image_path ) || ! file_exists( $original_image_path ) ) {
			return;
		}

		$verification_service = ImageVerificationService::instance();
		$generated_image_path = get_attached_file( $attachment_id );

		if ( empty( $generated_image_path ) || ! file_exists( $generated_image_path ) ) {
			return;
		}

		$result = $verification_service->batch_verify( $generated_image_path, $original_image_path, $job->id );

		if ( ! $result['clean'] && ! empty( $result['issues'] ) ) {
			Logger::warning( Config::LOG_ACTION_IMAGE_VERIFICATION, $job->id, [
				'issues' => $result['issues'],
				'confidence' => $result['confidence'],
				'audit_log' => $result['audit_log'] ?? [],
			], '200' );
		}
	}

    private function validate_job_data( $job ) {
		$missing_fields = [];
		$invalid_fields = [];
		$truncations    = [];

		$max_headline_chars = 180;
		$max_hook_chars     = 300;

		if ( empty( $job->ai_headline ) ) {
			$missing_fields[] = 'ai_headline';
		} else {
			if ( ! mb_check_encoding( $job->ai_headline, 'UTF-8' ) ) {
				$invalid_fields[] = 'ai_headline (invalid UTF-8 encoding)';
				Logger::error( 'encoding_validation_failed', $job->id, [ 'field' => 'ai_headline', 'reason' => 'invalid UTF-8' ], '500' );
			} elseif ( self::is_mojibake( $job->ai_headline ) ) {
				$invalid_fields[] = 'ai_headline (mojibake detected)';
				Logger::error( 'encoding_validation_failed', $job->id, [ 'field' => 'ai_headline', 'reason' => 'mojibake pattern detected' ], '500' );
			} else {
				$headline_len = mb_strlen( trim( $job->ai_headline ), 'UTF-8' );
				if ( $headline_len < 3 ) {
					$invalid_fields[] = 'ai_headline (too short)';
				} elseif ( $headline_len > $max_headline_chars ) {
					$truncations['ai_headline'] = mb_substr( trim( $job->ai_headline ), 0, $max_headline_chars - 3, 'UTF-8' ) . '...';
					Logger::warning( 'headline_truncated', $job->id, [
						'original_length' => $headline_len,
						'max_allowed'     => $max_headline_chars,
					], '200' );
				}
			}
		}

		if ( empty( $job->ai_hook ) ) {
			$missing_fields[] = 'ai_hook';
		} else {
			if ( ! mb_check_encoding( $job->ai_hook, 'UTF-8' ) ) {
				$invalid_fields[] = 'ai_hook (invalid UTF-8 encoding)';
				Logger::error( 'encoding_validation_failed', $job->id, [ 'field' => 'ai_hook', 'reason' => 'invalid UTF-8' ], '500' );
			} elseif ( self::is_mojibake( $job->ai_hook ) ) {
				$invalid_fields[] = 'ai_hook (mojibake detected)';
				Logger::error( 'encoding_validation_failed', $job->id, [ 'field' => 'ai_hook', 'reason' => 'mojibake pattern detected' ], '500' );
			} else {
				$hook_len = mb_strlen( trim( $job->ai_hook ), 'UTF-8' );
				if ( $hook_len > $max_hook_chars ) {
					$truncations['ai_hook'] = mb_substr( trim( $job->ai_hook ), 0, $max_hook_chars - 3, 'UTF-8' ) . '...';
					Logger::warning( 'hook_truncated', $job->id, [
						'original_length' => $hook_len,
						'max_allowed'     => $max_hook_chars,
					], '200' );
				}
			}
		}

		if ( ! empty( $truncations ) ) {
			foreach ( $truncations as $field => $truncated_value ) {
				$job->{ $field } = $truncated_value;
			}
		}

		if ( empty( $job->post_id ) ) {
			$missing_fields[] = 'post_id';
		}

		if ( ! empty( $job->ai_detailed_description ) && strlen( trim( $job->ai_detailed_description ) ) < 10 ) {
			$invalid_fields[] = 'ai_detailed_description (too short)';
		}

		return [
			'valid' => empty( $missing_fields ) && empty( $invalid_fields ),
			'missing_fields' => $missing_fields,
			'invalid_fields' => $invalid_fields,
		];
	}

 	private static function is_mojibake( string $text ): bool {
 		if ( $text === '' ) {
 			return false;
 		}
 		if ( preg_match( '/\xC3[\x80-\xBF]\xC2[\x80-\xBF]/', $text ) ) {
 			return true;
 		}
 		if ( preg_match( '/\xC2[\x80-\xBF]{2,}/', $text ) ) {
 			return true;
 		}
 		if ( preg_match( '/[\xC0-\xC1][\x80-\xBF]/', $text ) ) {
 			return true;
 		}
 		if ( preg_match( '/\xE0[\x80-\x9F][\x80-\xBF]/', $text ) ) {
 			return true;
 		}
 		if ( preg_match( '/\xED[\xA0-\xBF][\x80-\xBF]/', $text ) ) {
 			return true;
 		}
 		if ( preg_match( '/\xF0[\x80-\x8F][\x80-\xBF]{2}/', $text ) ) {
 			return true;
 		}
 		if ( preg_match( '/\xF4[\x90-\xBF][\x80-\xBF]{2}/', $text ) ) {
 			return true;
 		}
 		if ( preg_match( '/[\xF5-\xFF]/', $text ) ) {
 			return true;
 		}
 		if ( preg_match( '/[\x80-\xBF](?<![\xC0-\xFD])/', $text ) && ! preg_match( '/[\xC0-\xFD]/', $text ) ) {
 			return true;
 		}
 		$latin1_orphans = preg_match_all( '/[\xC0-\xFF](?![\x80-\xBF])/', $text );
 		if ( $latin1_orphans > 3 ) {
 			return true;
 		}
 		$suspicious = preg_match_all( '/[ØÙÚÛÜÝÞßàáâãäåæçèéêëìíîïðñòóôõö÷øùúûüýþÿ]{3,}/', $text );
 		if ( $suspicious >= 2 ) {
 			return true;
 		}
 		return false;
 	}

 	private static function is_error_sentinel( string $headline, string $hook ): bool {
		$combined = mb_strtolower( $headline . ' ' . $hook, 'UTF-8' );
		$sentinel_patterns = [
			'source content missing',
			'cannot generate',
			'without factual data',
			'no source provided',
			'please provide the source',
			'no content available',
			'unable to generate',
			'insufficient information',
			'no information available',
			'content not available',
			'article not found',
			'no article content',
			'empty source',
			'no data provided',
			'no news content',
			'factual data',
			'provide the source article',
			'specific details from the news story are essential',
		];
		foreach ( $sentinel_patterns as $pattern ) {
			if ( mb_strpos( $combined, $pattern, 0, 'UTF-8' ) !== false ) {
				return true;
			}
		}
		return false;
	}

	private function resolve_additional_images( $post_id, $template ) {
		$slots = Config::get_template_image_slots( $template );
		$urls = [];

		if ( $slots <= 1 ) {
			return $urls;
		}

		$attachments = get_posts( [
			'post_type' => 'attachment',
			'post_parent' => $post_id,
			'post_mime_type' => 'image',
			'posts_per_page' => $slots - 1,
			'orderby' => 'menu_order',
			'order' => 'ASC',
			'exclude' => [ get_post_thumbnail_id( $post_id ) ],
		] );

		$idx = 2;
foreach ( $attachments as $att ) {
$url = wp_get_attachment_url( $att->ID );
$urls[ $idx ] = $url ? $url : '';
$idx++;
			if ( $idx > $slots ) {
				break;
			}
		}

		for ( $i = 2; $i <= $slots; $i++ ) {
			if ( ! isset( $urls[ $i ] ) ) {
				$urls[ $i ] = '';
			}
		}

		return $urls;
	}

	// ── NEW ORCHESTRATOR: Stage 1 to 3 ───────────────────────────────────
	
	private function prepare_clean_image( string $raw_image_url, array $campaign, int $post_id, bool $is_source_image ): string {
		if ( empty( $raw_image_url ) ) {
			return $raw_image_url;
		}

		// If this is an AI-generated image (not a source image), skip Lens and Crop.
		// AI-generated images are already clean and have no text bands.
		if ( ! $is_source_image ) {
			Logger::info( 'pipeline_skipped_ai_image', $post_id, [ 'reason' => 'Image is AI-generated, skipping Lens and Crop.' ] );
			return $raw_image_url;
		}

		$preprocessor = ImagePreprocessor::instance();

		// PASS 1: Prioritize the original source image for clean cropping.
		// This guarantees factual accuracy (preventing Lens from fetching a visually similar but incorrect event).
		try {
			$processed_source = $preprocessor->process( $raw_image_url, $campaign, $post_id );
			if ( $processed_source && file_exists( $processed_source ) ) {
				update_post_meta( $post_id, Config::META_PREPROCESSED_IMAGE, $processed_source );
				Logger::info( 'pipeline_source_cropped_success', $post_id, [ 'clean_path' => basename( $processed_source ) ] );
				return $processed_source;
			}
		} catch ( \Throwable $e ) {
			Logger::warning( 'pipeline_source_crop_failed', $post_id, [ 'error' => $e->getMessage() ] );
		}

		// PASS 2: If the source image couldn't be cropped (too small, corrupted, or preprocessor failed), fall back to SerpApi (Google Lens).
		Logger::info( 'pipeline_fallback_to_lens', $post_id, [ 'reason' => 'Source image crop failed or yielded no result. Falling back to Google Lens.' ] );
		
		$lens_path = $raw_image_url;
		try {
			$lens_path = ImageAcquisitionService::acquire_clean_image( $post_id, $raw_image_url );
		} catch ( \Throwable $e ) {
			Logger::warning( 'pipeline_lens_failed', $post_id, [ 'error' => $e->getMessage() ] );
		}
		
		if ( $lens_path === $raw_image_url ) {
			// Lens failed to find a better image.
			return $raw_image_url;
		}

		// PASS 3: Crop the newly acquired Lens image.
		try {
			$processed_lens = $preprocessor->process( $lens_path, $campaign, $post_id );
			if ( $processed_lens && file_exists( $processed_lens ) ) {
				update_post_meta( $post_id, Config::META_PREPROCESSED_IMAGE, $processed_lens );
				Logger::info( 'pipeline_lens_cropped_success', $post_id, [ 'clean_path' => basename( $processed_lens ) ] );
				return $processed_lens;
			}
		} catch ( \Throwable $e ) {
			Logger::warning( 'pipeline_lens_crop_failed', $post_id, [ 'error' => $e->getMessage() ] );
		}

		return $lens_path;
	}
	
	// ── Prime Time Scheduling Helpers ─────────────────────────────────
	
	/**
	 * Check if current time is within a prime time slot (within 15 min)
	 */
	private function is_current_time_prime_slot(): bool {
		$slots = $this->get_prime_time_slots();
		if ( empty( $slots ) ) {
			return false;
		}

		$now_local    = current_time( 'timestamp' );
		$today_date   = date( 'Y-m-d', $now_local );
		$local_offset = (int) ( $now_local - time() );

		foreach ( $slots as $slot ) {
			$slot_utc = strtotime( $today_date . ' ' . $slot );
			if ( false === $slot_utc ) {
				continue;
			}
			$slot_local = $slot_utc - $local_offset;
			if ( abs( $now_local - $slot_local ) < 900 ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Get next prime time slot string
	 */
	private function get_next_prime_time_slot(): ?string {
		$slots = $this->get_prime_time_slots();
		if ( empty( $slots ) ) {
			return null;
		}

		$now_local    = current_time( 'timestamp' );
		$today_date   = date( 'Y-m-d', $now_local );
		$local_offset = (int) ( $now_local - time() );

		foreach ( $slots as $slot ) {
			$slot_utc = strtotime( $today_date . ' ' . $slot );
			if ( false === $slot_utc ) {
				continue;
			}
			$slot_local = $slot_utc - $local_offset;
			if ( $slot_local > $now_local ) {
				return $slot;
			}
		}

		// If no more slots today, return first slot tomorrow
		return $slots[0];
	}

	/**
	 * Get configured prime time slots
	 */
	private function get_prime_time_slots(): array {
		$default_slots = [ '08:00', '13:00', '20:00' ];
		$slots = get_option( Config::OPTION_PRIME_TIME_SLOTS, $default_slots );
		return is_array( $slots ) ? $slots : $default_slots;
	}

	/**
	 * Schedule job for prime time publishing via Action Scheduler
	 */
	private function schedule_for_prime_time( int $job_id, string $time_slot ): void {
		if ( (bool) get_option( Config::OPTION_PIPELINE_PAUSED, false ) ) {
			Logger::info( 'prime_time_schedule_skipped_paused', $job_id, [ 'slot' => $time_slot ], '200' );
			return;
		}
		$now_local    = current_time( 'timestamp' );
		$today_date   = date( 'Y-m-d', $now_local );
		$local_offset = (int) ( $now_local - time() );

		$next_utc = strtotime( $today_date . ' ' . $time_slot );
		if ( false === $next_utc ) {
			$next_utc = time();
		}
		if ( $next_utc < time() + 60 ) {
			$next_utc = strtotime( $today_date . ' ' . $time_slot . ' +1 day' );
		}

		if ( function_exists( 'as_schedule_single_action' ) ) {
			as_schedule_single_action(
				$next_utc,
				Config::ACTION_PROCESS_JOB,
				[ 'job_id' => $job_id ],
				Config::AS_GROUP
			);
		}

 		JobManager::update_status( $job_id, Config::STATUS_SCHEDULED );

		Logger::info( 'job_scheduled_prime_time', $job_id, [
			'scheduled_time' => $time_slot,
			'timestamp' => $next_utc,
		], '200' );
	}

	private static function compute_smart_delay( APIErrorInfo $error_info, int $retry_count ): int {
		$retry_after = $error_info->get_retry_after();

		switch ( $error_info->error_type ) {
			case APIErrorInfo::TYPE_QUOTA_RPM:
				if ( $retry_after > 0 ) {
					return $retry_after + 5;
				}
				return 65;

			case APIErrorInfo::TYPE_QUOTA_TPM:
				if ( $retry_after > 0 ) {
					return $retry_after + 10;
				}
				return 120;

 			case APIErrorInfo::TYPE_QUOTA_RPD:
 				return 30;

 			case APIErrorInfo::TYPE_QUOTA_UNKNOWN:
 				if ( $retry_after > 0 ) {
 					return min( $retry_after + 10, 300 );
 				}
 				return min( pow( 2, $retry_count ) * 60, 240 );

 			case APIErrorInfo::TYPE_SERVER_OVERLOADED:
 			case APIErrorInfo::TYPE_TRANSIENT:
 				if ( $retry_after > 0 ) {
 					return min( $retry_after + 5, 120 );
 				}
 				return min( pow( 2, $retry_count ) * 20, 90 );

default:
				return min( pow( 2, $retry_count ) * 30, 90 );
  		}
 	}

	/**
	 * Compute the next publish time for a video job based on campaign settings.
	 * This mirrors the reference plugin's scheduling logic.
	 */
	public static function compute_publish_at( string $publish_time, string $frequency ): string {
		$tz = wp_timezone();
		$now = new \DateTime( 'now', $tz );
		$target_time = \DateTime::createFromFormat( 'H:i', $publish_time, $tz );
		if ( ! $target_time ) {
			$target_time = \DateTime::createFromFormat( 'H:i', '09:00', $tz );
		}
		$target_time->setDate( $now->format( 'Y' ), $now->format( 'm' ), $now->format( 'd' ) );

		// Map actual Config frequency values to interval offsets.
		// Config::get_frequencies() uses labels like '1 Day', 'Twice Daily', etc.
		$frequency_intervals = [
			Config::FREQUENCY_5_MINS      => '+5 minutes',
			Config::FREQUENCY_15_MINS     => '+15 minutes',
			Config::FREQUENCY_30_MINS     => '+30 minutes',
			Config::FREQUENCY_1_HOUR      => '+1 hours',
			Config::FREQUENCY_2_HOURS     => '+2 hours',
			Config::FREQUENCY_4_HOURS     => '+4 hours',
			Config::FREQUENCY_6_HOURS     => '+6 hours',
			Config::FREQUENCY_8_HOURS     => '+8 hours',
			Config::FREQUENCY_10_HOURS    => '+10 hours',
			Config::FREQUENCY_12_HOURS    => '+12 hours',
			Config::FREQUENCY_1_DAY       => '+1 days',
			Config::FREQUENCY_TWICE_DAILY => '+12 hours',
			Config::FREQUENCY_2_DAYS      => '+2 days',
		];

		$interval = $frequency_intervals[ $frequency ] ?? '+1 days';

		// If the target time today has passed, move to next interval
		if ( $target_time <= $now ) {
			$target_time->modify( $interval );
		}

		return $target_time->format( 'Y-m-d H:i:s' );
	}

	/**
	 * AUDIT FIX F11: acquire a per-job lock.
	 *
	 * WHY THIS EXISTS
	 * ---------------
	 * The original code called \add_transient(). That function does not exist in
	 * WordPress — the Transients API is get_transient() / set_transient() /
	 * delete_transient() and nothing else. So the first executable statement of
	 * process_job() threw:
	 *
	 *     Uncaught Error: Call to undefined function add_transient()
	 *
	 * ...from OUTSIDE any try/catch: before the job row was read, before the
	 * status ever moved off `pending`, and before anything was logged. Every
	 * direct run aborted the whole request right there. That is why the log shows
	 * `direct_processing_starting_sync` 190x and `direct_processing_completed_sync`
	 * exactly 0 times, and why no job_exception / job_failed row was ever written.
	 *
	 * DESIGN
	 * ------
	 * The Transients API has no atomic "add", so this uses compare-and-set with a
	 * unique token: write our token, read the value back, and only claim the lock
	 * if our token is the one still there. Losing the race means "skip this cycle
	 * and retry later" — the safe direction. Processing one job twice (duplicate
	 * AI spend, duplicate posts) is far worse than a delayed job.
	 *
	 * Locks are also age-broken: a process that dies holding a lock would
	 * otherwise block that job forever, so after $stale_after seconds the lock is
	 * treated as abandoned and re-taken.
	 *
	 * @param string $lock_key    Transient key for this job.
	 * @param int    $ttl         Lock lifetime in seconds (crash backstop).
	 * @param int    $stale_after Seconds after which an existing lock may be broken.
	 * @return array { acquired: bool, reason: string, age: int|null }
	 */
	private function acquire_job_lock( string $lock_key, int $ttl = 900, int $stale_after = 300 ): array {

		// Fail OPEN rather than fatal: a missing Transients API must never be able
		// to kill the queue the way \add_transient() did.
		if ( ! function_exists( 'set_transient' ) || ! function_exists( 'get_transient' ) ) {
			return [ 'acquired' => true, 'reason' => 'transient_api_unavailable_fail_open', 'age' => null ];
		}

		$now   = time();
		$token = function_exists( 'wp_generate_uuid4' ) ? wp_generate_uuid4() : uniqid( 'lock', true );

		// Fast path: a healthy lock already exists — don't even try to write.
		$existing      = get_transient( $lock_key );
		$existing_time = null;

		if ( is_array( $existing ) ) {
			$existing_time = isset( $existing['t'] ) ? (int) $existing['t'] : null;
		} elseif ( false !== $existing && is_scalar( $existing ) ) {
			$existing_time = (int) $existing; // legacy scalar lock from an older build
		}

		$breaking_stale = false;

		if ( null !== $existing_time ) {
			$age = $now - $existing_time;

			if ( $age < $stale_after ) {
				return [ 'acquired' => false, 'reason' => 'held', 'age' => $age ];
			}

			// Stale — the owning process almost certainly died. Break it below.
			$breaking_stale = true;
		}

		set_transient( $lock_key, [ 't' => $now, 'tok' => $token ], $ttl );
		$check = get_transient( $lock_key );

		if ( ! is_array( $check ) || ! isset( $check['tok'] ) || $check['tok'] !== $token ) {
			$winner_age = ( is_array( $check ) && isset( $check['t'] ) ) ? $now - (int) $check['t'] : null;

			return [ 'acquired' => false, 'reason' => 'lost_race', 'age' => $winner_age ];
		}

		return [
			'acquired' => true,
			'reason'   => $breaking_stale ? 'recovered_stale' : 'acquired',
			'age'      => $breaking_stale ? ( $now - $existing_time ) : 0,
		];
	}

	/**
	 * AUDIT FIX F11: release a per-job lock.
	 *
	 * @param string $lock_key Transient key for this job.
	 * @return void
	 */
	private function release_job_lock( string $lock_key ): void {
		if ( function_exists( 'delete_transient' ) ) {
			delete_transient( $lock_key );
		}
	}

}
