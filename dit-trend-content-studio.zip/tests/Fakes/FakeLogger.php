<?php

declare(strict_types=1);

namespace DIT\TrendStudio\Tests\Fakes;

use DIT\TrendStudio\Infrastructure\Logger;

final class FakeLogger extends Logger
{
    public array $entries = [];

    public function __construct() {} // Prevent parent constructor call if it does things we don't want

    public function info($message, $context = [])
    {
        $this->entries[] = ['level' => 'info', 'message' => (string)$message, 'context' => (array)$context];
    }

    public function warning($message, $context = [])
    {
        $this->entries[] = ['level' => 'warning', 'message' => (string)$message, 'context' => (array)$context];
    }

    public function error($message, $context = [])
    {
        $this->entries[] = ['level' => 'error', 'message' => (string)$message, 'context' => (array)$context];
    }

    public function hasEntry(string $level, string $needle): bool
    {
        foreach ($this->entries as $entry) {
            if ($entry['level'] === $level && str_contains($entry['message'], $needle)) {
                return true;
            }
        }
        return false;
    }

    public function findFirst(string $level, string $needle): ?array
    {
        foreach ($this->entries as $entry) {
            if ($entry['level'] === $level && str_contains($entry['message'], $needle)) {
                return $entry;
            }
        }
        return null;
    }
}
