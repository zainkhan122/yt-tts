/**
 * MCQ Video Studio - Diagnostics (Phase 4)
 * Collects render metadata for support/debug without scraping console logs.
 */
(function (global) {
  "use strict";

  const MCQVS_Diagnostics = {
    version: "1.0.0",

    collect(studio) {
      try {
        const jm = studio && studio.state && studio.state.jobManager ? studio.state.jobManager : null;
        const cache = studio && studio.state && studio.state.assetCache ? studio.state.assetCache : null;

        // @MODIFIED 2026-02-06: Fix logger reference and API call
        const logs = (window.MCQVSLogger && typeof window.MCQVSLogger.export === 'function')
          ? (window.MCQVSLogger.export().logs || [])
          : [];

        return {
          collectedAt: new Date().toISOString(),
          job: jm ? { state: jm.state, lastError: jm.lastError || null } : null,
          renderPlan: studio && studio.state ? (studio.state.renderPlan || null) : null,
          lastPreflight: studio && studio.state ? (studio.state.lastPreflightReport || null) : null,
          cache: cache && typeof cache.getStats === "function" ? cache.getStats() : null,
          templateId: studio && studio.state ? (studio.state.templateId || null) : null,
          fps: studio && studio.state ? (studio.state.fps || 30) : 30,
          dimensions: studio && studio.state ? (studio.state.dimensions || null) : null,
          logs: {
            count: Array.isArray(logs) ? logs.length : 0,
            tail: Array.isArray(logs) ? logs.slice(-80) : []
          }
        };
      } catch (e) {
        return { error: (e && e.message) ? e.message : String(e) };
      }
    },

    async fetchServerLogs() {
      try {
        const response = await fetch(window.mcqvsSettings && window.mcqvsSettings.ajaxUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: 'action=mcqvs_get_diagnostics_logs&nonce=' + (window.mcqvsSettings && window.mcqvsSettings.nonce)
        });
        const result = await response.json();
        return result.success ? result.data : [];
      } catch (e) {
        return [];
      }
    }
  };

  global.MCQVS_Diagnostics = MCQVS_Diagnostics;
})(typeof window !== "undefined" ? window : self);
