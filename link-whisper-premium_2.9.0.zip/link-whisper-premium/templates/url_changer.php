<div class="wrap wpil-report-page wpil_styles">
    <?=Wpil_Base::showVersion()?>
    <h1 class="wp-heading-inline"><?php esc_html_e('URL Changer','wpil'); ?></h1>
    <hr class="wp-header-end">
    <div id="poststuff">
        <div id="post-body" class="metabox-holder">
            <div id="post-body-content" style="position: relative;">
                <input id="wpil-object-cache-flush-nonce" type="hidden" value="<?php echo wp_create_nonce('wpil-flush-object-cache'); ?>" />
                <div id="wpil_url_changer_table">
                    <?php if(!empty($new_url_rule)){ ?>
                        <div class="progress" style="display:block">
                            <h4 class="progress_panel_msg"><?php esc_html_e('Updating URLs...','wpil'); ?></h4>
                            <div class="progress_panel loader">
                                <div class="progress_count"><?php esc_html_e('Changing URLs', 'wpil'); ?></div>
                            </div>
                        </div>
                    <?php }else{ ?>
                        <form>
                            <input type="hidden" name="page" value="link_whisper_url_changer" />
                            <?php $table->search_box('Search', 'search'); ?>
                        </form>
                        <form method="post" id="add_url_change_form">
                            <div method="post" style="float:left;">
                                <input type="text" name="old" placeholder="Old URL">
                                <input type="text" name="new" placeholder="New URL">
                                <input type="submit" value="Add URL" class="button-primary">
                            </div>
                        </form>
                        <div style="clear: both"></div>
                        <a href="javascript:void(0)" class="button-primary" id="wpil_url_changer_reset_button"><?php esc_html_e('Refresh Changed URL Report', 'wpil'); ?></a>
                        <?php if (!$reset) : ?>
                            <div class="table">
                                <?php $table->display(); ?>
                            </div>
                        <?php endif; ?>
                        <div class="progress" <?=$reset?'style="display:block"':''?>>
                            <h4 class="progress_panel_msg"><?php esc_html_e('Synchronizing your data..','wpil'); ?></h4>
                            <div class="progress_panel loader">
                                <div class="progress_count"></div>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    var wpil_url_changer_nonce = '<?=wp_create_nonce($user->ID . 'wpil_url_changer')?>';
    var is_wpil_url_changer_reset = <?=$reset?'true':'false'?>;
    var created_rule_id = <?php echo !empty($new_url_rule) ? $new_url_rule->id: 0;?>;
</script>