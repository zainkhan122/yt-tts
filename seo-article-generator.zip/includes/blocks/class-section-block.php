<?php
/**
 * Section Block
 * 
 * @package SEO_Article_Generator
 */

namespace SEO_Article_Generator\Blocks;

// Prevent direct access
if (! defined('ABSPATH')) {
    exit;
}

/**
 * Register and render section block for surgical patching
 */
class Section_Block
{
    /**
     * Initialize block registration
     *
     * @return void
     */
    public static function init()
    {
        add_action('init', array(__CLASS__, 'register_block'));
    }

    /**
     * Register the section block
     *
     * @return void
     */
    public static function register_block()
    {
        // Enqueue editor script
        add_action('enqueue_block_editor_assets', array(__CLASS__, 'enqueue_block_editor_assets'));

        // Register block type (server-side rendering only)
        \register_block_type('seo-gen/section', array(
            'api_version'     => 3,
            'attributes'      => array(
                'zone' => array(
                    'type'    => 'string',
                    'default' => '',
                ),
            ),
            'supports'        => array(
                'html' => false,
            ),
            'render_callback' => array(__CLASS__, 'render_block'),
        ));
    }

    /**
     * Enqueue block editor assets.
     */
    public static function enqueue_block_editor_assets()
    {
        $js_file = SEO_GEN_PLUGIN_DIR . 'assets/js/blocks/section-block.js';
        if (file_exists($js_file)) {
            wp_enqueue_script(
                'seo-gen-section-block-js',
                SEO_GEN_PLUGIN_URL . 'assets/js/blocks/section-block.js',
                array('wp-blocks', 'wp-element', 'wp-block-editor'),
                filemtime($js_file),
                true
            );
        }
    }

    /**
     * Render section block
     *
     * @param array  $attributes Block attributes
     * @param string $content Block content (inner blocks)
     * @return string Rendered HTML
     */
    public static function render_block($attributes = array(), $content = '')
    {
        $zone = ! empty($attributes['zone']) ? $attributes['zone'] : 'unknown';
        
        // The content is already wrapped in a div by the generator if needed,
        // but we ensure it remains consistent for front-end styling.
        return sprintf(
            '<div class="wp-block-seo-gen-section" data-seo-gen-zone="%s">%s</div>',
            esc_attr($zone),
            $content
        );
    }
}
