<?php
/**
 * Provider preference persistence — step 1/7 of approved FIX plan.
 * Uses WP transients (not options) for 4-hour TTL; endpoint-scoped.
 * Safe: only promotes existing chain members; never injects new providers.
 */
if (!defined('ABSPATH')) exit;

class SEO_Article_Generator_AI_Provider_Preference {
    private static $ttl_hours = 4;

    public static function get_preferred($endpoint_url = null) {
        $hash = $endpoint_url ? md5(parse_url($endpoint_url, PHP_URL_HOST) ?: 'default') : 'default';
        $cached = get_transient("seo_gen_last_success_{$hash}");
        return is_array($cached) && !empty($cached['provider_id']) && !empty($cached['model']) ? $cached : null;
    }

    public static function set_preferred($provider_id, $model, $endpoint_url = null) {
        $hash = $endpoint_url ? md5(parse_url($endpoint_url, PHP_URL_HOST) ?: 'default') : 'default';
        set_transient("seo_gen_last_success_{$hash}", array(
            'provider_id' => (string) $provider_id,
            'model' => (string) $model,
            'time' => time(),
        ), self::$ttl_hours * HOUR_IN_SECONDS);
    }
}
