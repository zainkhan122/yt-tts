<?php

namespace SEO_Article_Generator\AI;

if (!defined('ABSPATH')) {
    exit;
}

class Provider_Registry {

    private static ?self $instance = null;
    private array $builtin = [];
    private array $custom = [];

    public static function get_instance(): self {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->builtin = [
            'gemini' => [
                'class'                => Providers\Gemini_Provider::class,
                'key_option'           => 'seo_gen_gemini_api_key',
                'model_option'         => 'seo_gen_gemini_model',
                'default_model'        => 'gemini-2.0-flash',
                'models'               => [
                    'gemini-3.5-flash' => 'Gemini 3.5 Flash',
                    'gemini-2.0-flash' => 'Gemini 2.0 Flash',
                    'gemini-2.0-flash-001' => 'Gemini 2.0 Flash 001',
                    'gemini-2.5-flash' => 'Gemini 2.5 Flash',
                    'gemini-2.5-pro'   => 'Gemini 2.5 Pro',
                ],
                'endpoint'             => 'https://generativelanguage.googleapis.com/v1beta',
                'auth_type'            => 'query_key',
                'supports_web_search'  => true,
                'web_search_type'      => 'google_search',
                'supports_json_schema' => false,
                'fallback_option'      => 'seo_gen_gemini_fallback',
                'min_interval'         => 5,
                'max_attempts'         => 3,
            ],
        ];

$saved = get_option('seo_gen_custom_providers', '[]');
        
        if (is_string($saved)) {
            $saved = json_decode($saved, true);
        }
        $this->custom = is_array($saved) ? $saved : [];

        // Debug: Log what we're loading
        foreach ($this->custom as $provider) {
        }

        $this->custom = apply_filters('seo_gen_register_custom_providers', $this->custom);
    }

    public function get_all_ids(): array {
        $custom_ids = array_map(function($profile) {
            return $profile['id'];
        }, $this->custom);
        return array_merge(array_keys($this->builtin), $custom_ids);
    }

    public function is_custom(string $id): bool {
        return !isset($this->builtin[$id]);
    }

    public function get_provider_class(string $id): string {
        if ($this->is_custom($id)) {
            return Providers\Custom_Provider::class;
        }
        return $this->builtin[$id]['class'];
    }

    public function get_api_key_option(string $id): string {
        return $this->builtin[$id]['key_option'] ?? '';
    }

    public function get_model_option(string $id): string {
        return $this->builtin[$id]['model_option'] ?? '';
    }

    public function get_default_model(string $id): string {
        if ($this->is_custom($id)) {
            $profile = $this->get_custom_profile($id);
            $models = $profile['models'] ?? [];
            if (!empty($models) && is_array($models)) {
                return $models[0]['model_id'] ?? '';
            }
            return '';
        }
        return $this->builtin[$id]['default_model'] ?? '';
    }

    public function get_supported_models(string $id): array {
        if ($this->is_custom($id)) {
            $profile = $this->get_custom_profile($id);
            $models = [];
            foreach ((array)($profile['models'] ?? []) as $m) {
                if (!empty($m['model_id'])) {
                    $models[$m['model_id']] = $m['display_name'] ?? $m['model_id'];
                }
            }
            return $models;
        }
        return $this->builtin[$id]['models'] ?? [];
    }

    public function get_endpoint(string $id): string {
        if ($this->is_custom($id)) {
            $profile = $this->get_custom_profile($id);
            return rtrim($profile['api_url'] ?? '', '/');
        }
        return $this->builtin[$id]['endpoint'] ?? '';
    }

    public function get_auth_type(string $id): string {
        return $this->builtin[$id]['auth_type'] ?? 'bearer';
    }

    public function get_min_interval(string $id): int {
        if ($this->is_custom($id)) {
            return 2;
        }
        return $this->builtin[$id]['min_interval'] ?? 2;
    }

    public function get_max_attempts(string $id): int {
        if ($this->is_custom($id)) {
            return 3;
        }
        return $this->builtin[$id]['max_attempts'] ?? 3;
    }

    public function supports_web_search(string $id): bool {
        if ($this->is_custom($id)) {
            $profile = $this->get_custom_profile($id);
            return !empty($profile['enable_web_search']) && ($profile['web_search_config']['type'] ?? 'none') !== 'none';
        }
        return $this->builtin[$id]['supports_web_search'] ?? false;
    }

    public function get_web_search_type(string $id): string {
        if ($this->is_custom($id)) {
            $profile = $this->get_custom_profile($id);
            return $profile['web_search_config']['type'] ?? 'none';
        }
        return $this->builtin[$id]['web_search_type'] ?? 'none';
    }

    public function get_fallback_option(string $id): ?string {
        return $this->builtin[$id]['fallback_option'] ?? null;
    }

    public function get_custom_profile(string $id): array {
        foreach ($this->custom as $profile) {
            if (($profile['id'] ?? '') === $id) {
                return $profile;
            }
        }
        return [];
    }

    public function get_custom_providers(): array {
        return $this->custom;
    }

    /**
     * Check if an API URL is OpenRouter-compatible (uses OpenRouter's API endpoint)
     *
     * @param string $api_url The API URL to check
     * @return bool True if URL is OpenRouter-compatible
     */
    public function is_openrouter_compatible(string $api_url): bool {
        if (empty($api_url)) {
            return false;
        }
        return strpos($api_url, 'openrouter.ai') !== false
            || strpos($api_url, 'openrouterapi.ai') !== false;
    }

    /**
     * Check whether an API URL points to OpenCode Zen (opencode.ai host).
     * Sibling of is_openrouter_compatible(); used by the Zen free model sync
     * UI gate and by OpenCode_Zen_Model_Sync::find_zen_index().
     *
     * Stricter than a bare strpos() of 'opencode.ai' — matches the exact
     * host or any subdomain, so 'opencodeai.example.com' does not false-match.
     *
     * @param string $api_url The API URL to check.
     * @return bool True if URL host is opencode.ai or *.opencode.ai.
     */
    public function is_zen_url(string $api_url): bool {
        if (empty($api_url)) {
            return false;
        }
        if (strpos($api_url, 'opencode.ai') !== false) {
            return true;
        }
        $host = wp_parse_url($api_url, PHP_URL_HOST);
        if (! is_string($host) || $host === '') {
            return false;
        }
        return $host === 'opencode.ai'
            || substr($host, -strlen('.opencode.ai')) === '.opencode.ai';
    }

    public function save_custom_providers(array $providers): void {
        $sanitized = [];
        foreach ($providers as $profile) {
            $sanitized[] = $this->validate_custom_profile($profile);
        }
        update_option('seo_gen_custom_providers', wp_json_encode($sanitized));
        $this->custom = $sanitized;
    }

    /**
     * Set a runtime-only field on a custom provider's in-memory profile.
     *
     * Unlike save_custom_providers(), this does NOT persist to the database
     * and does NOT run through validate_custom_profile().  The field exists
     * only for the current request lifetime — perfect for transient hints
     * like _fallback_model (LKGM).
     *
     * @param string $id    Provider ID (e.g. 'prov_1779643665_n0pte').
     * @param string $field Field name.
     * @param mixed  $value Field value.
     * @since 2.34.20
     */
    public function set_custom_profile_runtime_field(string $id, string $field, $value): void {
        foreach ($this->custom as $i => $p) {
            if (($p['id'] ?? '') === $id) {
                $this->custom[$i][$field] = $value;
                return;
            }
        }
    }

    public function validate_custom_profile(array $profile): array {
        $sanitized = [];
        $sanitized['id'] = sanitize_key($profile['id'] ?? 'prov_' . time() . '_' . wp_generate_password(5, false));
        $sanitized['name'] = sanitize_text_field($profile['name'] ?? 'Unnamed Provider');
        $sanitized['api_url'] = esc_url_raw($profile['api_url'] ?? '');
        $sanitized['api_key'] = sanitize_text_field($profile['api_key'] ?? '');
        $sanitized['enable_web_search'] = !empty($profile['enable_web_search']);
        $sanitized['fallback_enabled'] = !empty($profile['fallback_enabled']);

        $sanitized['web_search_config'] = [
            'type'          => sanitize_text_field($profile['web_search_config']['type'] ?? 'none'),
            'search_engine' => sanitize_text_field($profile['web_search_config']['search_engine'] ?? 'search_pro'),
            'search_count'  => min(20, max(1, (int)($profile['web_search_config']['search_count'] ?? 10))),
        ];

        $sanitized['supports_json_schema'] = !empty($profile['supports_json_schema']);

        // Auto-detect OpenRouter native search: default to true for OpenRouter URLs
        $is_openrouter_url = $this->is_openrouter_compatible($profile['api_url'] ?? '');
        $sanitized['use_openrouter_native_search'] = isset($profile['use_openrouter_native_search'])
            ? !empty($profile['use_openrouter_native_search'])
            : $is_openrouter_url;

        $models = [];
        foreach ((array)($profile['models'] ?? []) as $m) {
            if (!empty($m['model_id'])) {
                $models[] = [
                    'model_id'     => sanitize_text_field($m['model_id']),
                    'display_name' => sanitize_text_field($m['display_name'] ?? $m['model_id']),
                    'expiration_date' => sanitize_text_field($m['expiration_date'] ?? ''),
                ];
            }
        }
        $sanitized['models'] = $models;

        return $sanitized;
    }

    public function register_temporary_provider(array $profile): void {
        $sanitized = $this->validate_custom_profile($profile);
        foreach ($this->custom as $key => $existing) {
            if (($existing['id'] ?? '') === $sanitized['id']) {
                $this->custom[$key] = $sanitized;
                return;
            }
        }
        $this->custom[] = $sanitized;
    }
}

