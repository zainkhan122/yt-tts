/**
 * MCQ Video Studio — Server-Side Render Entry Point (browser-free)
 *
 * Driven by PHP (VS_Headless_Renderer::render_job) which writes a job payload
 * JSON and spawns: node render-node.js --payload=/path/to/job.json
 *
 * Pipeline:
 *   1. Load reused browser rendering modules (shimmed into Node).
 *   2. Build deterministic RenderPlan + draw state.
 *   3. Prepare media: fonts, bg image/video frames, logo, music, SFX.
 *   4. Generate TTS voiceover WAVs (edge-tts) for voiceover cues.
 *   5. Mix audio (music + ducking + voice + SFX) via FFmpeg.
 *   6. Draw frames -> pipe RGBA to FFmpeg, mux with the audio -> MP4.
 *   7. Write status JSON + MP4; PHP finalizes (upload + status transition).
 *
 * No WordPress, no admin-ajax, no nonce, no browser. Exit codes mirror legacy:
 *   0 success | 2 ffmpeg/missing dep | 3 render timeout | 4 internal | 5 bad payload
 *
 * @package MCQ_Video_Studio
 * @subpackage render-service
 */

'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');
const CORE = path.join(__dirname, 'render-core');
const SR = require(path.join(CORE, 'server-renderer'));

if (typeof SR.loadRenderingModules !== 'function') {
    console.error('[FATAL] server-renderer.js missing loadRenderingModules export. Check server file integrity.');
    console.error('SR exports:', Object.keys(SR));
    process.exit(1);
}

const MEM_LIMIT_MB = 1500;
const memMB = process.memoryUsage().heapTotal / 1024 / 1024;
if (memMB > MEM_LIMIT_MB) {
    console.error('[WARN] Memory usage high: ' + memMB.toFixed(0) + 'MB, possible leak. Consider reducing frame count.');
}

const LOG_FILE = process.env.MCQVS_LOG_FILE || '';
const STATUS_PATH = process.env.MCQVS_STATUS_FILE || '';
const EXIT_FILE = process.env.MCQVS_EXIT_FILE || '';
let logBuffer = [];
function log(msg, level) {
    level = level || 'info';
    const line = '[' + (level === 'error' ? 'E' : level === 'warn' ? 'W' : 'I') + '] ' + msg;
    console.log(line);
    logBuffer.push({ t: Date.now(), level, msg: String(msg) });
}
// Expose log globally so media-prep.js, server-renderer.js, and template
// managers can write to the plugin's render log instead of console.log.
if (typeof global !== 'undefined') global.__MCQVS_RENDER_LOG = log;
function writeStatus(obj) {
    if (!STATUS_PATH) return;
    try { fs.writeFileSync(STATUS_PATH, JSON.stringify(Object.assign({ ts: Date.now() }, obj), null, 2)); } catch (_) {}
}
function writeExitFile(code) {
    if (!EXIT_FILE) return;
    try { fs.writeFileSync(EXIT_FILE, String(code)); } catch (_) {}
}
function fail(code, message) {
    log(message, 'error');
    writeStatus({ status: 'failed', error: message, error_code: code, logs: logBuffer.slice(-50) });
    writeExitFile(code);
    process.exit(code);
}

function detectFfmpeg(forced) {
    if (forced && fs.existsSync(forced)) return forced;
    for (const c of ['/usr/bin/ffmpeg', '/usr/local/bin/ffmpeg', '/opt/homebrew/bin/ffmpeg', 'C:\\ffmpeg\\bin\\ffmpeg.exe']) {
        if (fs.existsSync(c)) return c;
    }
    try { const w = require('child_process').execSync('which ffmpeg 2>/dev/null').toString().trim(); if (w) return w; } catch (_) {}
    return null;
}

async function main() {
    const args = (() => { const a = {}; process.argv.slice(2).forEach((x) => { const m = x.match(/^--([^=]+)(?:=(.*))?$/); if (m) a[m[1]] = m[2] === undefined ? true : m[2]; }); return a; })();
    const payloadPath = args.payload;
    if (!payloadPath || !fs.existsSync(payloadPath)) fail(5, 'Job payload missing: ' + payloadPath);

    let payload;
    try { payload = JSON.parse(fs.readFileSync(payloadPath, 'utf8')); }
    catch (e) { fail(5, 'Invalid payload JSON: ' + e.message); }

    const jobId = payload.job_id || 'unknown';
    const assetsJsDir = payload.assets_js_dir;
    if (!assetsJsDir || !fs.existsSync(assetsJsDir)) fail(2, 'assets/js dir not found: ' + assetsJsDir);

    const ffmpegBin = detectFfmpeg(payload.ffmpeg_bin);
    if (!ffmpegBin) fail(2, 'ffmpeg not found. Install ffmpeg or set mcqvs_ffmpeg_path.');

    const outPath = payload.out_path || path.join(os.tmpdir(), 'mcqvs_' + jobId + '.mp4');
    writeStatus({ status: 'rendering', job_id: jobId, progress: 0 });

    let win;
    try {
        win = SR.loadRenderingModules(assetsJsDir, { width: payload.width, height: payload.height, assetsUrl: payload.assets_url, origin: payload.origin });
        SR._setWindow(win);
    } catch (e) { fail(4, 'Load modules failed: ' + e.message); }
    log('Rendering modules loaded from ' + assetsJsDir + '.');

    const built = SR.buildPlanAndState(payload);
    if (!built.totalMs) fail(5, 'Render plan zero duration for ' + jobId);
    log(`Plan: ${built.width}x${built.height} @${built.fps}fps, ${built.totalMs}ms, ${payload.questions ? payload.questions.length : 0} Q`);

    // 1) Prepare media (fonts, bg image/video, logo, music, sfx).
    const settings = payload.settings || {};
    log('[render-node:DIAG] settings.templateFonts=' + JSON.stringify(settings.templateFonts) + ' settings.templateFontWeights=' + JSON.stringify(settings.templateFontWeights) + ' settings.fontOverride="' + (settings.fontOverride || '') + '" settings.template="' + (settings.template || '') + '"');
    let media;
    try {
        media = SR.prepareMedia({
            ffmpegBin, assetsJsDir, assetsUrl: payload.assets_url,
            width: built.width, height: built.height, settings, plan: built.plan,
            totalMs: built.totalMs,
        });
    } catch (e) { log('Media prep warning: ' + e.message, 'warn'); media = { bgImage: null, bgVideoFrames: null, bgVideoFrameDur: 33.33, logoImage: null, musicPath: null, voiceovers: [], sfx: [], duckWindows: [] }; }
    log('Media prepared: bg=' + (media.bgImage ? 'image' : (media.bgVideoFrames ? 'video-frames' : 'none')) + ', music=' + (media.musicPath ? 'yes' : 'no') + ', sfx=' + (media.sfx ? media.sfx.length : 0) + '.');

    // 2) Voiceover: generate TTS, measure durations, adapt question timing.
    const voiceWavs = [];
    const edgeHelper = path.join(__dirname, 'edge-tts-helper.js');
    try {
        const vo = settings.voiceover || {};
        if (vo.enabled && vo.voice) {
            // Phase 1: Generate all TTS and measure actual durations
            const ttsMeasured = SR.generateAndMeasureTts(built, settings, ffmpegBin, edgeHelper);
            log('TTS measured: ' + ttsMeasured.length + ' segments');

            // Phase 2: Adapt question durations to fit TTS
            if (ttsMeasured.length) {
                const fmt = String(settings.videoFormat || payload.videoFormat || 'shorts') === 'youtube' ? 'youtube' : 'shorts';
                const baseTiming = settings.timing || (fmt === 'youtube'
                    ? { hookIntro: 2000, questionTotal: 12000, questionPhases: { intro: 1000, reading: 9000, reveal: 3000 }, outroDuration: 5000 }
                    : { hookIntro: 1200, questionTotal: 7700, questionPhases: { intro: 600, reading: 5100, reveal: 2000 }, outroDuration: 3200 });
                const perScene = SR.computeAdaptiveTiming(built, ttsMeasured, baseTiming, { format: fmt });
                // Capture initial totalMs before rebuild for bg video frame re-extraction check
                const initialTotalMs = built.totalMs;
                // @FIX 2026-07-31: Always rebuild when TTS data exists (removed the
                //                  `adjusted > 0` gate). Parity with studio.export.js
                //                  and with the documented intent of
                //                  rebuildPlanWithAdaptiveTiming (2026-07-30):
                //                  _revealStartRel is anchored to reading TTS end + 300ms
                //                  for EVERY question, so the pill countdown and the
                //                  reveal moment track the actual TTS length. Without
                //                  the rebuild, jobs whose TTS fit the base duration
                //                  kept the pre-adaptive reveal (durMs - revealMs) while
                //                  the browser export of the same quiz used the
                //                  TTS-anchored reveal — cross-path parity divergence.
                SR.rebuildPlanWithAdaptiveTiming(built, perScene, ttsMeasured);
                log('Adaptive timing applied; new total duration: ' + built.totalMs + 'ms');

                // @FIX 2026-07-31: prepareMedia ran BEFORE the rebuild — media.sfx and
                //                  media.duckWindows are time-locked to PRE-adaptive
                //                  event times. Re-derive both from the realigned plan
                //                  so tick beeps, reveal/correct chimes, and music
                //                  ducking land at the NEW cue times (the audio mix
                //                  would otherwise play them off the visual reveal).
                media.sfx = SR.buildSfxEvents ? SR.buildSfxEvents(built.plan, { assetsJsDir }) : media.sfx;
                media.duckWindows = (built.plan.duckWindows || []).map((w) => ({
                    startSec: Math.max(0, Number(w.startMs || 0) / 1000),
                    endSec: Math.max(0, Number(w.endMs || 0) / 1000),
                    volume: Number(w.volume != null ? w.volume : 0.14),
                }));

                // @FIX 2026-08-17: Re-extract background video frames if total duration changed
                //                  significantly after adaptive timing. prepareMedia extracts
                //                  frames for initial totalMs, but rebuildPlanWithAdaptiveTiming
                //                  can extend duration (e.g. 2s -> 40s). Without re-extraction,
                //                  the 60-frame fallback loops every ~2s for the full render.
                if (media.bgVideoFrames && media.bgVideoFrames.length) {
                    const currentFrameCoverage = media.bgVideoFrames.length * (media.bgVideoFrameDur || 33.33);
                    if (built.totalMs > currentFrameCoverage * 1.5) { // Significant extension
                        try {
                            const bgVideoUrl = settings.bgVideoUrl || settings.bg_video || '';
                            if (bgVideoUrl) {
                                const newFrames = SR.extractBgVideoFrames(ffmpegBin, bgVideoUrl, built.width, built.height, media.bgVideoFrameDur || 33.33, built.totalMs);
                                if (newFrames.length > media.bgVideoFrames.length) {
                                    media.bgVideoFrames = newFrames;
                                    log('Re-extracted bg video frames for extended duration: ' + newFrames.length + ' frames (was ' + media.bgVideoFrames.length + ')');
                                }
                            }
                        } catch (reExtractErr) {
                            log('Background video frame re-extraction failed (non-fatal): ' + reExtractErr.message, 'warn');
                        }
                    }
                }
            }

            // Phase 3: Place TTS WAVs at ADAPTED scene positions.
            // @FIX 2026-07-25: `buildVoiceoverCues` ran BEFORE `rebuildPlanWithAdaptiveTiming`,
            //       so every `t.atMs` was computed from the ORIGINAL scene startMs/endMs.
            //       After adaptive timing extends earlier questions, all later scenes shift
            //       right, but only `reveal` cues were being remapped — `q_read`/`hook`/`cta`
            //       cues stayed at obsolete positions, placing TTS inside the PREVIOUS
            //       question's duration. Recalculate every scene-bound cue from the rebuilt
            //       plan's startMs/endMs.
            for (const t of ttsMeasured) {
                let adjustedAtMs = t.atMs;
                // @FIX 1.4.9.52 (TTS OVERLAP): trimSec = how much of this WAV may play
                // before it must stop (so it never runs into the next cue / scene).
                // null = play the whole clip.
                let trimSec = null;
                const scene = (built.plan.scenes || []).find(s => s.id === t.sceneId);
                if (scene) {
                    const sStart = Number(scene.startMs || 0);
                    const sEnd = Number(scene.endMs || (sStart + Number(scene.durMs || 0)));
                    const durMs = Number(t.durationMs) || 0;
                    if (t.kind === 'q_read') {
                        adjustedAtMs = Math.max(0, sStart + 80);
                        // Trim the read so it ends ~50ms before the reveal cue starts
                        // (or at the scene end when reveal measurement is missing).
                        const revealStartRel = Number(scene.timing?._revealStartRel || 0);
                        const revealAt = Math.max(adjustedAtMs + 250, sStart + revealStartRel + 20);
                        const readEndCap = Math.min(sEnd, revealAt);
                        trimSec = Math.max(0.05, (readEndCap - adjustedAtMs - 50) / 1000);
                    } else if (t.kind === 'reveal') {
                        // @FIX 2026-07-30: Fire answer TTS at the same moment as visual
                        //                   reveal (20ms offset for audio start). The reveal
                        //                   is anchored to reading TTS end + 300ms gap.
                        const revealStartRel = Number(scene.timing?._revealStartRel || 0);
                        // @FIX 1.4.9.52: clamp the reveal INSIDE the scene — if the
                        //                 anchor ever lands past the scene end (cap
                        //                 edge cases), pull it back so the answer audio
                        //                 never plays over the next question.
                        const revealDurMs = Number(scene.timing?._revealTtsMs || durMs);
                        const revealAnchor = sStart + revealStartRel + 20;
                        const latestStart = sEnd - revealDurMs - 60;
                        adjustedAtMs = Math.max(sStart + 250, Math.min(revealAnchor, latestStart));
                        trimSec = Math.max(0.05, (sEnd - adjustedAtMs - 50) / 1000);
                    } else if (t.kind === 'hook') {
                        // @FIX 2026-08-11: re-anchor hook TTS to the (possibly extended)
                        //       hook scene start so it never spills into Q1.
                        adjustedAtMs = Math.max(0, sStart + 50);
                        trimSec = Math.max(0.05, (sEnd - adjustedAtMs - 50) / 1000);
                    } else if (t.kind === 'cta') {
                        adjustedAtMs = Math.max(0, sStart + 200);
                        trimSec = Math.max(0.05, (sEnd - adjustedAtMs - 50) / 1000);
                    }
                }
                const atSec = Math.max(0, adjustedAtMs / 1000);
                voiceWavs.push({ path: t.path, atSec, durSec: (Number(t.durationMs) || 0) / 1000, trimSec });
                media.duckWindows.push({ startSec: Math.max(0, atSec - 0.05), endSec: atSec + t.durationMs / 1000 + 0.5, volume: 0.14 });
            }
            log('Voiceover segments: ' + voiceWavs.length);
        }
    } catch (e) { log('Voiceover warning: ' + e.message, 'warn'); }

    // 3) Mix audio.
    let audioWav = null;
    const durationSec = built.totalMs / 1000;
    if (media.musicPath || voiceWavs.length || media.sfx.length) {
        audioWav = path.join(os.tmpdir(), 'mcqvs_audio_' + jobId + '.wav');
        const ok = SR.mixAudio({
            ffmpegBin, sampleRate: 44100, durationSec,
            music: media.musicPath ? { path: media.musicPath, volume: 0.30 } : null,
            voiceovers: voiceWavs,
            sfx: media.sfx,
            duckWindows: media.duckWindows,
            outPath: audioWav,
        });
        if (!ok) { log('Audio mix failed; rendering video only.', 'warn'); audioWav = null; }
    }

    // 4) Render + mux.
    const hardTimeoutMs = (Number(payload.timeout) || 600) * 1000 + 120000;
    const watchdog = setTimeout(() => { log('HARD WATCHDOG tripped.', 'error'); writeStatus({ status: 'failed', error: 'render_timeout', error_code: 3, progress: -1, logs: logBuffer.slice(-50) }); writeExitFile(3); process.exit(3); }, hardTimeoutMs);
    log('Rendering ' + Math.ceil((built.totalMs / 1000) * built.fps) + ' frames (' + Math.round(built.totalMs / 1000) + 's @' + built.fps + 'fps); muxing ' + (audioWav ? 'with audio' : 'video-only') + '.');

    try {
        const result = await SR.renderToMp4(built, { bin: ffmpegBin }, media, audioWav, outPath, log, (pct) => {
            if (!main._last || pct - main._last >= 5) { main._last = pct; writeStatus({ status: 'rendering', job_id: jobId, progress: pct }); }
        });
        if (!fs.existsSync(outPath) || fs.statSync(outPath).size === 0) fail(4, 'FFmpeg produced no output: ' + outPath);
        const size = fs.statSync(outPath).size;
        log(`Render complete: ${(size / 1048576).toFixed(2)} MB, ${result.frames} frames`);

        // @NEW 2026-07-30: Extract a cover image (PNG) for social media thumbnails.
        // @FIX 2026-08-11: cover_config.mode selects WHERE the cover frame comes from:
        //   - 'scene' (default): frame 0 (the branded cover scene, logo + brand + hook/quiz name)
        //   - 'first_q_mid': frame at 50% of the FIRST question's duration (all 4 options +
        //     half timer — the quiz content itself becomes the poster).
        //   Works for Content Planner / headless renders; the Studio cover card previews the
        //   same frame (vs-cover-editor.js).
        let coverPath = '';
        try {
            coverPath = outPath.replace(/\.mp4$/, '-cover.png');
            const cc = (settings.cover_config && typeof settings.cover_config === 'object') ? settings.cover_config : {};
            let coverTimeMs = 0;
            if (cc.mode === 'first_q_mid') {
                const scenes = (built && built.plan && Array.isArray(built.plan.scenes)) ? built.plan.scenes : [];
                const q1 = scenes.find((s) => s && s.type === 'question');
                if (q1) coverTimeMs = Math.max(0, Number(q1.startMs || 0) + Number(q1.durMs || 0) / 2);
            }
            const { spawnSync } = require('child_process');
            const ffArgs = ['-i', outPath];
            if (coverTimeMs > 0) ffArgs.push('-ss', (coverTimeMs / 1000).toFixed(3));
            ffArgs.push('-vframes', '1', '-y', coverPath);
            const probe = spawnSync(ffmpegBin, ffArgs, { timeout: 15000, stdio: ['ignore', 'pipe', 'pipe'] });
            if (probe.status === 0 && fs.existsSync(coverPath) && fs.statSync(coverPath).size > 0) {
                log('Cover image extracted: ' + coverPath + ' (' + (fs.statSync(coverPath).size / 1024).toFixed(1) + ' KB)');
            } else {
                log('Cover extraction failed (non-fatal): ' + (probe.stderr ? probe.stderr.toString().slice(0, 200) : 'unknown'), 'warn');
                coverPath = '';
            }
        } catch (coverErr) {
            log('Cover extraction error (non-fatal): ' + coverErr.message, 'warn');
            coverPath = '';
        }

        writeStatus({ status: 'completed', job_id: jobId, video_path: outPath, video_size: size, cover_path: coverPath || '', duration_ms: result.durationMs, progress: 100, logs: logBuffer.slice(-50) });
        writeExitFile(0);
        process.exit(0);
    } catch (e) { clearTimeout(watchdog); fail(4, 'Render failed: ' + e.message); }
}

main();
