<?php

/**
 * SEO Metadata Generator
 *
 * Generates SEO-friendly titles, descriptions and slugs from the generated article.
 *
 * @package DIT_TrendStudio\SEO
 */

namespace DIT\TrendStudio\SEO;

use DIT\TrendStudio\DTO\GenerationResultDTO;

// Block direct access
defined('ABSPATH') || exit;

/**
 * Class MetadataGenerator
 * Compose metadata based on an article's headline and body.
 */
class MetadataGenerator
{
    /**
     * Generate SEO title, description and slug from article data.
     *
     * Accepts either a GenerationResultDTO or an associative array with
     * 'headline' and 'sections' keys.
     *
     * @param array|GenerationResultDTO $article
     * @return array{
     *   title: string,
     *   description: string,
     *   slug: string
     * }
     */
    public static function generate($article): array
    {
        // Extract fields
        if ($article instanceof GenerationResultDTO) {
            $title   = $article->headline;
            $sections = $article->sections;
            $meta_description = $article->meta_description ?? '';
        } elseif (is_array($article)) {
            $title   = $article['headline'] ?? '';
            $sections = $article['sections'] ?? [];
            $meta_description = $article['meta_description'] ?? '';
        } else {
            return [
                'title' => '',
                'description' => '',
                'slug' => '',
            ];
        }

        // Generate slug from title
        $raw_slug = sanitize_title($title);
        $slug = apply_filters('tcs_metadata_generator_slug', $raw_slug, $title);

        // Do NOT truncate titles by default.
        // If strict SERP-length titles are desired, use the filter below.
        $meta_title = trim($title);
        $meta_title = apply_filters('tcs_metadata_generator_title', $meta_title, $title);

        // PRIORITY: Use AI-generated meta_description if available
        if (!empty($meta_description)) {
            $description = wp_strip_all_tags(trim($meta_description));
        } else {
            // Fallback: Generate from first section body
            $body_text = '';
            foreach ($sections as $sec) {
                if (!empty($sec['body'])) {
                    $body_text = wp_strip_all_tags($sec['body']);
                    break;
                } elseif (!empty($sec['body_html'])) {
                    $body_text = wp_strip_all_tags($sec['body_html']);
                    break;
                }
            }
            $description = self::truncate_description($body_text);
        }
        $description = apply_filters('tcs_metadata_generator_description', $description, $meta_description ?: $body_text);

        return [
            'title' => $meta_title,
            'description' => $description,
            'slug' => $slug,
        ];
    }

    /**
     * Truncate text to ~155 characters for meta descriptions.
     *
     * @param string $text
     * @return string
     */
    private static function truncate_description(string $text): string
    {
        $text = trim(preg_replace('/\s+/', ' ', $text));
        if (mb_strlen($text) <= 160) {
            return $text;
        }
        $snippet = mb_substr($text, 0, 160);
        $last_space = mb_strrpos($snippet, ' ');
        if ($last_space !== false) {
            $snippet = mb_substr($snippet, 0, $last_space);
        }
        return $snippet . '…';
    }
}
