<?php

/**
 * Question Usage Tracker
 *
 * Tracks question usage for strict non-repetition in video generation.
 * Provides atomic reservation to prevent double-booking of questions.
 *
 * @package    WP_News_MCQ_Generator
 * @subpackage Includes
 * @since      9.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class NM_Question_Usage_Tracker
 *
 * Handles question reservation and usage tracking for Video Studio.
 *
 * @since 9.0.0
 */
class NM_Question_Usage_Tracker {


	/**
	 * Table name (without prefix).
	 *
	 * @var string
	 */
	const TABLE_NAME = 'nm_question_usage';

	/**
	 * Singleton instance.
	 *
	 * @var NM_Question_Usage_Tracker|null
	 */
	private static $instance = null;

	/**
	 * Get singleton instance.
	 *
	 * @since 9.0.0
	 * @return NM_Question_Usage_Tracker
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Get the full table name with prefix.
	 *
	 * @since 9.0.0
	 * @return string
	 */
	public static function get_table_name() {
		global $wpdb;
		return $wpdb->prefix . self::TABLE_NAME;
	}

	/**
	 * Create the usage tracking table.
	 *
	 * @since 9.0.0
	 * @return bool True on success.
	 */
	public static function create_table() {
		global $wpdb;

		$table_name      = self::get_table_name();
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE IF NOT EXISTS {$table_name} (
			id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
			question_id BIGINT UNSIGNED NOT NULL,
			topic_id BIGINT UNSIGNED NOT NULL,
			exam_id BIGINT UNSIGNED DEFAULT NULL,
			job_id VARCHAR(64) NOT NULL,
			status ENUM('reserved', 'used', 'released') DEFAULT 'reserved',
			reserved_at DATETIME NOT NULL,
			used_at DATETIME DEFAULT NULL,
			video_url VARCHAR(500) DEFAULT NULL,
			INDEX idx_question (question_id),
			INDEX idx_status_topic (status, topic_id),
			INDEX idx_job (job_id)
		) {$charset_collate};";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );

		return true;
	}

	/**
	 * Get eligible (unused) questions for a topic/exam.
	 *
	 * @since 9.0.0
	 * @param int      $topic_id Topic term ID.
	 * @param int|null $exam_id  Optional exam term ID.
	 * @param int      $limit    Maximum questions to return.
	 * @return array Array of question IDs.
	 */
	public function get_eligible_questions( $topic_id, $exam_id = null, $limit = 100 ) {
		global $wpdb;

		$table_name = self::get_table_name();
		$topic_id   = absint( $topic_id );
		$limit      = absint( $limit );

		// Get all questions for this topic/exam.
		$tax_query = array(
			array(
				'taxonomy' => 'topic',
				'field'    => 'term_id',
				'terms'    => $topic_id,
			),
		);

		if ( $exam_id ) {
			$tax_query['relation'] = 'AND';
			$tax_query[]           = array(
				'taxonomy' => 'nm_exam',
				'field'    => 'term_id',
				'terms'    => absint( $exam_id ),
			);
		}

		$query = new WP_Query(
			array(
				'post_type'      => 'mcq',
				'post_status'    => 'publish',
				'posts_per_page' => 500, // Get a large pool.
				'fields'         => 'ids',
				'tax_query'      => $tax_query, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
			)
		);

		$all_question_ids = $query->posts;

		if ( empty( $all_question_ids ) ) {
			return array();
		}

		// Get already used question IDs for this topic.
		$placeholders = implode( ',', array_fill( 0, count( $all_question_ids ), '%d' ) );

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$used_ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT DISTINCT question_id FROM {$table_name} 
				WHERE question_id IN ({$placeholders}) 
				AND status IN ('reserved', 'used')",
				...$all_question_ids
			)
		);

		// Filter out used questions.
		$eligible = array_diff( $all_question_ids, $used_ids );

		// Return limited results.
		return array_slice( array_values( $eligible ), 0, $limit );
	}

	/**
	 * Atomically reserve questions for a job.
	 *
	 * Uses database transaction to prevent race conditions.
	 *
	 * @since 9.0.0
	 * @param int      $topic_id Topic term ID.
	 * @param int|null $exam_id  Optional exam term ID.
	 * @param int      $count    Number of questions to reserve (3-7).
	 * @param string   $job_id   Unique job identifier.
	 * @return array|WP_Error Array of reserved question IDs or error.
	 */
	public function reserve_questions( $topic_id, $exam_id, $count, $job_id ) {
		global $wpdb;

		$table_name = self::get_table_name();
		$topic_id   = absint( $topic_id );
		$count      = max( 3, min( 10, absint( $count ) ) ); // Clamp 3-10.
		$job_id     = sanitize_text_field( $job_id );

		// Get eligible questions.
		$eligible = $this->get_eligible_questions( $topic_id, $exam_id, $count * 2 );

		if ( count( $eligible ) < $count ) {
			return new WP_Error(
				'insufficient_questions',
				sprintf(
					/* translators: %1$d: requested count, %2$d: available count */
					__( 'Not enough eligible questions. Requested: %1$d, Available: %2$d', 'wp-news-mcq-generator' ),
					$count,
					count( $eligible )
				)
			);
		}

		// Shuffle and take requested count.
		shuffle( $eligible );
		$to_reserve = array_slice( $eligible, 0, $count );

		// Start transaction.
		$wpdb->query( 'START TRANSACTION' );

		$reserved    = array();
		$now         = current_time( 'mysql' );
		$exam_id_val = $exam_id ? absint( $exam_id ) : null;

		foreach ( $to_reserve as $question_id ) {
			// Double-check not already reserved (race condition protection).
			$existing = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT id FROM {$table_name} 
					WHERE question_id = %d 
					AND status IN ('reserved', 'used') 
					FOR UPDATE",
					$question_id
				)
			);

			if ( $existing ) {
				continue; // Skip if already reserved.
			}

			// Insert reservation.
			$inserted = $wpdb->insert(
				$table_name,
				array(
					'question_id' => $question_id,
					'topic_id'    => $topic_id,
					'exam_id'     => $exam_id_val,
					'job_id'      => $job_id,
					'status'      => 'reserved',
					'reserved_at' => $now,
				),
				array( '%d', '%d', '%d', '%s', '%s', '%s' )
			);

			if ( $inserted ) {
				$reserved[] = $question_id;
			}

			if ( count( $reserved ) >= $count ) {
				break;
			}
		}

		if ( count( $reserved ) < $count ) {
			$wpdb->query( 'ROLLBACK' );
			return new WP_Error(
				'reservation_failed',
				__( 'Could not reserve enough questions due to concurrent access.', 'wp-news-mcq-generator' )
			);
		}

		$wpdb->query( 'COMMIT' );

		return $reserved;
	}

	/**
	 * Mark reserved questions as used.
	 *
	 * @since 9.0.0
	 * @param array  $question_ids Array of question IDs.
	 * @param string $job_id       Job identifier.
	 * @param string $video_url    Optional video URL.
	 * @return int Number of rows updated.
	 */
	public function mark_used( $question_ids, $job_id, $video_url = '' ) {
		global $wpdb;

		$table_name = self::get_table_name();
		$job_id     = sanitize_text_field( $job_id );
		$video_url  = esc_url_raw( $video_url );
		$now        = current_time( 'mysql' );

		$updated = 0;

		foreach ( $question_ids as $qid ) {
			$result = $wpdb->update(
				$table_name,
				array(
					'status'    => 'used',
					'used_at'   => $now,
					'video_url' => $video_url,
				),
				array(
					'question_id' => absint( $qid ),
					'job_id'      => $job_id,
					'status'      => 'reserved',
				),
				array( '%s', '%s', '%s' ),
				array( '%d', '%s', '%s' )
			);

			if ( $result ) {
				++$updated;
			}
		}

		return $updated;
	}

	/**
	 * Release reserved but unused questions.
	 *
	 * @since 9.0.0
	 * @param string $job_id Job identifier.
	 * @return int Number of rows released.
	 */
	public function release_reserved( $job_id ) {
		global $wpdb;

		$table_name = self::get_table_name();
		$job_id     = sanitize_text_field( $job_id );

		return $wpdb->update(
			$table_name,
			array( 'status' => 'released' ),
			array(
				'job_id' => $job_id,
				'status' => 'reserved',
			),
			array( '%s' ),
			array( '%s', '%s' )
		);
	}

	/**
	 * Get usage statistics for a topic.
	 *
	 * @since 9.0.0
	 * @param int $topic_id Topic term ID.
	 * @return array Statistics array.
	 */
	public function get_topic_stats( $topic_id ) {
		global $wpdb;

		$table_name = self::get_table_name();
		$topic_id   = absint( $topic_id );

		$stats = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT 
					COUNT(CASE WHEN status = 'reserved' THEN 1 END) as reserved,
					COUNT(CASE WHEN status = 'used' THEN 1 END) as used,
					COUNT(CASE WHEN status = 'released' THEN 1 END) as released
				FROM {$table_name}
				WHERE topic_id = %d",
				$topic_id
			),
			ARRAY_A
		);

		return $stats ? $stats : array(
			'reserved' => 0,
			'used'     => 0,
			'released' => 0,
		);
	}

	/**
	 * Clean up expired reservations (older than 24 hours).
	 *
	 * @since 9.0.0
	 * @return int Number of rows released.
	 */
	public function cleanup_expired_reservations() {
		global $wpdb;

		$table_name = self::get_table_name();
		$cutoff     = gmdate( 'Y-m-d H:i:s', strtotime( '-24 hours' ) );

		return $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table_name} 
				SET status = 'released' 
				WHERE status = 'reserved' 
				AND reserved_at < %s",
				$cutoff
			)
		);
	}
}
