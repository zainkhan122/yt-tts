<?php

/**
 * Changelog verifier (official release notes gate)
 *
 * Accepts:
 * - Same-root-domain changelog URLs as homepage (covers official sites + official subdomains/CDNs)
 * - GitHub/GitLab URLs only when they look release-related AND are plausibly official
 *
 * @package SEO_Article_Generator
 */

namespace SEO_Article_Generator\Validation;

if (!defined('ABSPATH')) {
    exit;
}

class ChangelogVerifier
{
    private const ALLOWED_CODE_HOSTS = [
        'github.com',
        'gitlab.com',
    ];

    /**
     * Verify that an article's changelog is verifiable.
     *
     * Two verification modes:
     * 1. CONTEXT MODE: whats_new generated from provided article_context (changelog HTML).
     *    - Accepts if article has non-empty article_context with version-specific content.
     *    - No external URL required.
     * 2. URL MODE: whats_new generated from web search (no provided context).
     *    - Requires valid changelogurl in tech_specs matching homepage domain or GitHub/GitLab releases.
     *
     * Expected input fields:
     * - $article['tech_specs']['changelogurl'] (string|null)
     * - $article['tech_specs']['homepage'] (string|null)
     * - $article['article_context'] (string|null) - provided changelog HTML
     * - $article['whats_new'] (array) - generated changelog items
     * - $article['whats_new_source'] (string) - 'context' or 'search' (optional)
     *
     * Return:
     * - ['ok' => bool, 'url' => string, 'reason' => string, 'mode' => string]
     */
    public static function verify(array $article): array
    {
        $ts = [];
        if (isset($article['tech_specs']) && is_array($article['tech_specs'])) {
            $ts = $article['tech_specs'];
        } elseif (isset($article['techspecs']) && is_array($article['techspecs'])) {
            $ts = $article['techspecs'];
        }

        $homepage       = self::as_string($ts['homepage'] ?? '');
        $changelogUrl   = self::as_string($ts['changelogurl'] ?? '');
        $articleContext = self::as_string($article['article_context'] ?? '');
        $whatsNew       = isset($article['whats_new']) && is_array($article['whats_new']) ? $article['whats_new'] : [];
        $whatsNewSource = self::as_string($article['whats_new_source'] ?? '');

        // No whats_new to verify - nothing to do
        if (empty($whatsNew)) {
            return ['ok' => true, 'url' => '', 'reason' => 'No whats_new to verify', 'mode' => 'none'];
        }

        // MODE 1: CONTEXT MODE - whats_new from provided article_context (changelog HTML)
        // This is the primary mode for Discovery pipeline where source post provides changelog.
        // [SSOT-FIX Finding 16] Stricter gate: the canonical version MUST appear verbatim
        // in the context. Previously, a length-only fallback (len > 500) let hallucinated
        // whats_new through whenever AI submitted a long context without the version —
        // producing fabricated changelogs that bypassed the URL-mode fallthrough.
        if (($whatsNewSource === 'context' || $whatsNewSource === '') && $articleContext !== '') {
            $canonicalVersion = self::as_string($ts['version'] ?? '');
            if ($canonicalVersion !== '' && self::context_contains_version($articleContext, $canonicalVersion)) {
                return ['ok' => true, 'url' => '', 'reason' => 'Verified against provided article_context (changelog HTML)', 'mode' => 'context'];
            }
            // No version match → reject (was: "Accepted: substantial article_context")
            return ['ok' => false, 'url' => '', 'reason' => 'Context provided but does not contain canonical version', 'mode' => 'context'];
        }

        // MODE 2: URL MODE - whats_new from web search (no provided context or context insufficient)
        // Requires valid external changelogurl
        if ($changelogUrl === '') {
            return ['ok' => false, 'url' => '', 'reason' => 'Missing tech_specs.changelogurl and no verified article_context', 'mode' => 'url'];
        }

        if (!filter_var($changelogUrl, FILTER_VALIDATE_URL)) {
            return ['ok' => false, 'url' => '', 'reason' => 'Invalid changelog URL', 'mode' => 'url'];
        }

        $scheme = self::get_url_part($changelogUrl, 'scheme');
        if (strtolower($scheme) !== 'https') {
            return ['ok' => false, 'url' => '', 'reason' => 'Changelog URL must be https', 'mode' => 'url'];
        }

        $chHost = self::normalize_host(self::get_url_part($changelogUrl, 'host'));
        if ($chHost === '') {
            return ['ok' => false, 'url' => '', 'reason' => 'Changelog URL host missing', 'mode' => 'url'];
        }

        // Rule 1: If homepage exists and root domain matches, accept immediately.
        $hpHost = self::normalize_host(self::get_url_part($homepage, 'host'));
        if ($hpHost !== '') {
            $chRoot = self::extract_root_domain($chHost);
            $hpRoot = self::extract_root_domain($hpHost);

            if ($chRoot !== '' && $hpRoot !== '' && $chRoot === $hpRoot) {
                return ['ok' => true, 'url' => $changelogUrl, 'reason' => 'Root domain matches homepage', 'mode' => 'url'];
            }
        }

        // Rule 2: Only allow GitHub/GitLab when plausibly official.
        if (!in_array($chHost, self::ALLOWED_CODE_HOSTS, true)) {
            return ['ok' => false, 'url' => '', 'reason' => 'Changelog host not allowed', 'mode' => 'url'];
        }

        $path = self::as_string(self::get_url_part($changelogUrl, 'path'));
        $path = ($path === '') ? '/' : $path;

        if ($chHost === 'github.com') {
            return self::verify_github($changelogUrl, $path, $homepage, $ts['developer'] ?? '', $ts['software_name'] ?? '');
        }

        if ($chHost === 'gitlab.com') {
            return self::verify_gitlab($changelogUrl, $path, $homepage, $ts['developer'] ?? '', $ts['software_name'] ?? '');
        }

        return ['ok' => false, 'url' => '', 'reason' => 'Unsupported changelog host', 'mode' => 'url'];
    }

    /**
     * Check if article context (changelog HTML) contains version-specific content.
     */
    private static function context_contains_version(string $context, string $version): bool
    {
        if ($version === '' || $context === '') {
            return false;
        }
        // Look for version in headings or version-specific sections
        $verEscaped = preg_quote($version, '/');
        $patterns = [
            '/<h[2-4][^>]*>.*?' . $verEscaped . '.*?<\/h[2-4]>/i',
            '/(?:Version|Release|v)' . $verEscaped . '/i',
            '/\b' . $verEscaped . '\b/i',
        ];
        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $context)) {
                return true;
            }
        }
        return false;
    }

    private static function verify_github(
        string $url,
        string $path,
        string $homepage,
        string $developer,
        string $softwarename
    ): array {
        $parts = self::path_segments($path);

        // Need at least /owner/repo
        if (count($parts) < 2) {
            return ['ok' => false, 'url' => '', 'reason' => 'GitHub URL missing owner/repo'];
        }

        [$owner, $repo] = [$parts[0], $parts[1]];

        $isReleaseLike =
            (strpos($path, '/releases') !== false) ||
            (strpos($path, '/tags') !== false) ||
            (self::is_changelog_file_on_github($path));

        if (!$isReleaseLike) {
            return ['ok' => false, 'url' => '', 'reason' => 'GitHub URL not release/tags/changelog-file related'];
        }

        if (!self::passes_plausibility($homepage, $developer, $softwarename, $owner, $repo, 'github')) {
            return ['ok' => false, 'url' => '', 'reason' => 'GitHub URL not plausibly official for project'];
        }

        return ['ok' => true, 'url' => $url, 'reason' => 'Plausible official GitHub changelog', 'mode' => 'url'];
    }

    private static function verify_gitlab(
        string $url,
        string $path,
        string $homepage,
        string $developer,
        string $softwarename
    ): array {
        $parts = self::path_segments($path);

        // GitLab can be nested groups; we still want at least group/project
        if (count($parts) < 2) {
            return ['ok' => false, 'url' => '', 'reason' => 'GitLab URL missing group/project'];
        }

        // Heuristic: take first two segments as group/project for plausibility.
        [$group, $project] = [$parts[0], $parts[1]];

        $isReleaseLike =
            (strpos($path, '/-/releases') !== false) ||
            (self::is_changelog_file_on_gitlab($path));

        if (!$isReleaseLike) {
            return ['ok' => false, 'url' => '', 'reason' => 'GitLab URL not releases/changelog-file related'];
        }

        if (!self::passes_plausibility($homepage, $developer, $softwarename, $group, $project, 'gitlab')) {
            return ['ok' => false, 'url' => '', 'reason' => 'GitLab URL not plausibly official for project'];
        }

        return ['ok' => true, 'url' => $url, 'reason' => 'Plausible official GitLab changelog', 'mode' => 'url'];
    }

    private static function passes_plausibility(
        string $homepage,
        string $developer,
        string $softwarename,
        string $ownerOrGroup,
        string $repoOrProject,
        string $hostType
    ): bool {
        $ownerToken = self::normalize_token($ownerOrGroup);
        $repoToken  = self::normalize_token($repoOrProject);

        $devToken   = self::normalize_token($developer, true);
        $nameToken  = self::normalize_token($softwarename);

        // 1) Developer name matches owner/group (strongest)
        if ($devToken !== '' && $ownerToken !== '' && $devToken === $ownerToken) {
            return true;
        }

        // 2) Software name matches repo/project (strong, usually correct)
        if ($nameToken !== '' && $repoToken !== '' && $nameToken === $repoToken) {
            return true;
        }

        // 3) Homepage explicitly contains the expected repo path (best evidence)
        $hp = strtolower(trim($homepage));
        if ($hp !== '') {
            $needle = '';
            if ($hostType === 'github') {
                $needle = 'github.com/' . strtolower($ownerOrGroup) . '/' . strtolower($repoOrProject);
            } elseif ($hostType === 'gitlab') {
                $needle = 'gitlab.com/' . strtolower($ownerOrGroup) . '/' . strtolower($repoOrProject);
            }
            if ($needle !== '' && strpos($hp, $needle) !== false) {
                return true;
            }
        }

        return false;
    }

    private static function is_changelog_file_on_github(string $path): bool
    {
        // Accept /blob/<branch>/CHANGELOG(.md|.txt) and similar.
        if (strpos($path, '/blob/') === false) {
            return false;
        }

        $lower = strtolower($path);

        $candidates = [
            '/changelog',
            '/changelog.md',
            '/changelog.txt',
            '/releases',
            '/release-notes',
            '/release-notes.md',
            '/news',
            '/news.md',
        ];

        foreach ($candidates as $c) {
            if (str_ends_with($lower, $c)) {
                return true;
            }
        }

        return false;
    }

    private static function is_changelog_file_on_gitlab(string $path): bool
    {
        // GitLab file views often look like /-/blob/<branch>/CHANGELOG.md
        if (strpos($path, '/-/blob/') === false) {
            return false;
        }

        $lower = strtolower($path);

        $candidates = [
            '/changelog',
            '/changelog.md',
            '/changelog.txt',
            '/release-notes',
            '/release-notes.md',
            '/news',
            '/news.md',
        ];

        foreach ($candidates as $c) {
            if (str_ends_with($lower, $c)) {
                return true;
            }
        }

        return false;
    }

    private static function path_segments(string $path): array
    {
        $trimmed = trim($path);
        if ($trimmed === '') {
            return [];
        }

        $trimmed = trim($trimmed, '/');
        if ($trimmed === '') {
            return [];
        }

        $parts = explode('/', $trimmed);
        $parts = array_values(array_filter($parts, static function ($p) {
            return $p !== '';
        }));

        return $parts;
    }

    private static function get_url_part(string $url, string $part): string
    {
        if ($url === '') {
            return '';
        }

        // Prefer WP helper when available (more forgiving in WP contexts)
        if (function_exists('\wp_parse_url')) {
            $parsed = \wp_parse_url($url);
        } else {
            $parsed = parse_url($url);
        }

        if (!is_array($parsed) || empty($parsed[$part])) {
            return '';
        }

        return (string)$parsed[$part];
    }

    private static function normalize_host(string $host): string
    {
        $host = strtolower(trim($host));
        $host = preg_replace('~^www\.~i', '', $host);
        return (string)$host;
    }

    /**
     * Root-domain extraction copied from Validator (make shared to avoid drift).
     * Handles common country-code second-level domains (co.uk, com.au, etc.).
     */
    public static function extract_root_domain(string $host): string
    {
        $host = self::normalize_host($host);
        if ($host === '') {
            return '';
        }

        $parts = explode('.', $host);
        $count = count($parts);

        if ($count <= 2) {
            return $host;
        }

        $countrySlds = [
            'co.uk',
            'org.uk',
            'me.uk',
            'ac.uk',
            'co.nz',
            'org.nz',
            'ac.nz',
            'com.au',
            'org.au',
            'net.au',
            'co.jp',
            'ne.jp',
            'or.jp',
            'co.in',
            'org.in',
            'net.in',
            'com.br',
            'org.br',
            'net.br',
            'co.za',
            'org.za',
        ];

        $lastTwo = $parts[$count - 2] . '.' . $parts[$count - 1];

        if (in_array($lastTwo, $countrySlds, true)) {
            return implode('.', array_slice($parts, -3));
        }

        return implode('.', array_slice($parts, -2));
    }

    /**
     * Normalize strings for fuzzy-but-safe matching.
     * If $isOrgName is true, strip common legal/organization suffix noise.
     */
    private static function normalize_token(string $value, bool $isOrgName = false): string
    {
        $value = strtolower(trim($value));
        if ($value === '') {
            return '';
        }

        // Strip common org/legal suffixes (optional but helps dev->owner matching).
        if ($isOrgName) {
            $value = preg_replace('~\b(inc|llc|ltd|gmbh|srl|sa|s\.a\.|s\.l\.|bv|ag|kg|plc|limited|company|co|corporation|corp|foundation|org|organization|team|software)\b~i', ' ', $value);
        }

        $value = preg_replace('~[^a-z0-9]+~', '-', $value);
        $value = preg_replace('~-+~', '-', $value);
        $value = trim($value, '-');

        return (string)$value;
    }

    private static function as_string($value): string
    {
        if (is_string($value)) {
            return trim($value);
        }
        return '';
    }
}
