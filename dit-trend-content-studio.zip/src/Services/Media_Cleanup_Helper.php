<?php

/**
 * Media Cleanup Helper
 *
 * Shared helper for safe media deletion/detach logic used by cleanup routines.
 *
 * @package DIT_TrendStudio
 * @since 2.15.12
 * @MODIFIED 2026-02-25 - Extracted reusable attachment detection + usage guard for global trash purge.
 */

namespace DIT\TrendStudio\Services;

if (!defined('ABSPATH')) {
    exit;
}

class Media_Cleanup_Helper
{
    /**
     * Collect candidate attachment IDs that are likely owned/used by the given post.
     *
     * Strategy:
     * - Attachments with post_parent = $post_id
     * - Featured image (thumbnail)
     * - Any wp-image-{id} references in post content
     * - Any block JSON `"id":123` references in post content
     *
     * @param int $post_id
     * @return int[]
     */
    public static function get_candidate_attachment_ids_for_post(int $post_id): array
    {
        $ids = array();

        $children = get_children(array(
            'post_parent' => $post_id,
            'post_type'   => 'attachment',
            'fields'      => 'ids',
        ));
        if (!empty($children) && is_array($children)) {
            $ids = array_merge($ids, array_map('intval', $children));
        }

        $thumb_id = (int) get_post_thumbnail_id($post_id);
        if ($thumb_id > 0) {
            $ids[] = $thumb_id;
        }

        $content = (string) get_post_field('post_content', $post_id);
        if ($content !== '') {
            if (preg_match_all('/wp-image-(\d+)/', $content, $m) && !empty($m[1])) {
                foreach ($m[1] as $id) {
                    $ids[] = (int) $id;
                }
            }

            if (preg_match_all('/\"id\"\s*:\s*(\d+)/', $content, $m2) && !empty($m2[1])) {
                foreach ($m2[1] as $id) {
                    $ids[] = (int) $id;
                }
            }

		// @MODIFIED 2026-02-25 - Resolve attachment IDs from <img src> URLs (covers cases without wp-image-* classes).
		// @MODIFIED 2026-05-08 - Pass $post_id as owner_post_id so guid/post_parent fallbacks activate.
		if (class_exists('DIT\\TrendStudio\\Services\\Media_Inventory')) {
			$inv = new Media_Inventory(null);
			foreach ($inv->extract_image_urls($content) as $raw_url) {
				$abs = $inv->normalize_to_absolute_url((string) $raw_url);
				$att_id = (int) $inv->resolve_attachment_id_from_url($abs, $post_id);
				if ($att_id > 0) {
					$ids[] = $att_id;
				}
			}
		}
        }

        $ids = array_values(array_unique(array_filter(array_map('intval', $ids))));
        return $ids;
    }


    /**
     * Get post IDs that reference an attachment (outside excluded post IDs).
     *
     * This expands usage detection beyond wp-image-ID by also checking direct URL references.
     *
     * @since 2.15.15
     * @MODIFIED 2026-02-25 - Return multi-post usage list for reliable cleanup logging.
     *
     * @param int   $attachment_id
     * @param int[] $exclude_post_ids
     * @param int   $limit
     * @return int[]
     */
    public static function get_attachment_usage_post_ids(int $attachment_id, array $exclude_post_ids = array(), int $limit = 10): array
    {
        global $wpdb;

        $attachment_id = (int) $attachment_id;
        if ($attachment_id <= 0) {
            return array();
        }

        $limit = max(1, min(50, (int) $limit));
        $exclude_post_ids = array_values(array_filter(array_map('intval', $exclude_post_ids)));

        $found = array();

        // 1) Featured image usage
        $sql = "SELECT pm.post_id
                FROM {$wpdb->postmeta} pm
                INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
                WHERE pm.meta_key = '_thumbnail_id'
                  AND pm.meta_value = %d
                  AND p.post_status <> 'trash'
                  AND p.post_type NOT IN ('revision','attachment','nav_menu_item')";

        $params = array($attachment_id);

        if (!empty($exclude_post_ids)) {
            $placeholders = implode(',', array_fill(0, count($exclude_post_ids), '%d'));
            $sql .= " AND pm.post_id NOT IN ({$placeholders})";
            $params = array_merge($params, $exclude_post_ids);
        }

        $sql .= " ORDER BY pm.post_id ASC LIMIT %d";
        $params[] = $limit;

        $rows = $wpdb->get_col($wpdb->prepare($sql, $params));
        if (!empty($rows)) {
            foreach ($rows as $r) {
                $rid = (int) $r;
                if ($rid > 0) {
                    $found[$rid] = true;
                    if (count($found) >= $limit) {
                        return array_keys($found);
                    }
                }
            }
        }

        // 2) Content references (wp-image-ID, block id, and direct URL references)
        $like = array(
            '%' . $wpdb->esc_like('wp-image-' . $attachment_id) . '%',
            '%' . $wpdb->esc_like('"id":' . $attachment_id) . '%',
        );

        $url = (string) wp_get_attachment_url($attachment_id);
        if ($url !== '') {
            $like[] = '%' . $wpdb->esc_like($url) . '%';

            // @MODIFIED 2026-02-25 - Add http/https variants to avoid false "exclusive" detection.
            $alt = self::swap_url_scheme($url);
            if ($alt !== '' && $alt !== $url) {
                $like[] = '%' . $wpdb->esc_like($alt) . '%';
            }

            if (function_exists('wp_make_link_relative')) {
                $rel = (string) wp_make_link_relative($url);
                if ($rel !== '' && $rel !== $url) {
                    $like[] = '%' . $wpdb->esc_like($rel) . '%';
                }
            }
        }

        $like_where = implode(' OR ', array_fill(0, count($like), 'post_content LIKE %s'));

        $sql2 = "SELECT ID FROM {$wpdb->posts}
                 WHERE post_status <> 'trash'
                   AND post_type NOT IN ('revision','attachment','nav_menu_item')
                   AND ({$like_where})";

        $params2 = $like;

        if (!empty($exclude_post_ids)) {
            $placeholders = implode(',', array_fill(0, count($exclude_post_ids), '%d'));
            $sql2 .= " AND ID NOT IN ({$placeholders})";
            $params2 = array_merge($params2, $exclude_post_ids);
        }

        $sql2 .= " ORDER BY ID ASC LIMIT %d";
        $params2[] = $limit;

        $rows2 = $wpdb->get_col($wpdb->prepare($sql2, $params2));
        if (!empty($rows2)) {
            foreach ($rows2 as $r) {
                $rid = (int) $r;
                if ($rid > 0) {
                    $found[$rid] = true;
                    if (count($found) >= $limit) {
                        break;
                    }
                }
            }
        }

        return array_keys($found);
    }

    /**
     * Swap URL scheme between http and https.
     *
     * @since 2.15.17
     * @MODIFIED 2026-02-25 - Used by attachment usage detection.
     */
    private static function swap_url_scheme(string $url): string
    {
        $url = trim($url);
        if ($url === '') {
            return '';
        }

        if (strpos($url, 'https://') === 0) {
            return 'http://' . substr($url, 8);
        }

        if (strpos($url, 'http://') === 0) {
            return 'https://' . substr($url, 7);
        }

        return '';
    }

    /**
     * Determine if an attachment is referenced elsewhere (outside excluded post IDs).
     *
     * Safety guard to avoid deleting shared media.
     *
     * @param int $attachment_id
     * @param int[] $exclude_post_ids
     * @return int The ID of the post using the attachment, or 0 if not used.
     */
    public static function is_attachment_used_elsewhere(int $attachment_id, array $exclude_post_ids = array()): int
    {
        $ids = self::get_attachment_usage_post_ids((int) $attachment_id, $exclude_post_ids, 1);
        return !empty($ids) ? (int) $ids[0] : 0;
    }

    /**
     * Detach an attachment from its parent post.
     *
     * @param int $attachment_id
     * @return void
     */
    public static function detach_attachment(int $attachment_id): void
    {
        global $wpdb;

        $wpdb->update(
            $wpdb->posts,
            array('post_parent' => 0),
            array('ID' => $attachment_id),
            array('%d'),
            array('%d')
        );
    }

    /**
     * Restore a trashed attachment (untrash) and detach it from parent.
     *
     * Used when an attachment is in Trash but appears referenced elsewhere, and force delete is disabled.
     *
     * @param int $attachment_id
     * @return void
     */
    public static function restore_attachment_from_trash(int $attachment_id): void
    {
        // This changes status from 'trash' back to 'inherit' for attachments.
        wp_untrash_post($attachment_id);
        self::detach_attachment($attachment_id);
    }
}
