<?php

/**
 * RSS Source Provider
 *
 * @package DIT_TrendStudio
 * @since 1.5.1
 */

namespace DIT\TrendStudio\Integrations\Trends;

use DIT\TrendStudio\Infrastructure\Logger;
use DIT\TrendStudio\Source_Exception;
use DIT\TrendStudio\Contracts\TrendSourceInterface;
use DIT\TrendStudio\Sources\Source_Provider;
use DIT\TrendStudio\Sources\Idea_DTO;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * RSS Feed Provider
 */
class RSSProvider implements Source_Provider, TrendSourceInterface
{
    /**
     * Logger instance
     *
     * @var Logger
     */
    private Logger $logger;

    /**
     * Constructor
     *
     * @param Logger $logger Logger instance
     */
    public function __construct(Logger $logger)
    {
        $this->logger = $logger;
    }

    /**
     * Get provider name
     *
     * @return string
     */
    public function get_name(): string
    {
        return 'RSS Feeds';
    }

    /**
     * Get provider type identifier
     *
     * @return string
     */
    public function get_type(): string
    {
        return 'rss';
    }

    /**
     * Check if provider is available/configured
     *
     * @return bool
     */
    public function is_available(): bool
    {
        $feeds = get_option('dit_ts_rss_feeds', '');
        return !empty($feeds);
    }

    /**
     * Fetch ideas from configured RSS feeds
     *
     * @param array $params Provider-specific parameters (not used for RSS)
     * @return Idea_DTO[] Array of idea DTOs
     * @throws Source_Exception On fetch failure
     */
    public function fetch_ideas(array $params = array()): array
    {
        $feeds_str = get_option('dit_ts_rss_feeds', '');
        if (empty($feeds_str)) {
            return array();
        }

        $feeds = array_map('trim', explode("\n", $feeds_str));
        $feeds = array_filter($feeds);

        $ideas = array();

        foreach ($feeds as $feed_url) {
            if (!filter_var($feed_url, FILTER_VALIDATE_URL)) {
                $this->logger->warning("RSS Provider: Invalid feed URL skipped: {$feed_url}");
                continue;
            }

            $this->logger->info("RSS Provider: Fetching feed: {$feed_url}");

            // fetch_feed returns a SimplePie object
            $rss = fetch_feed($feed_url);

            if (is_wp_error($rss)) {
                $this->logger->error("RSS Provider: Failed to fetch feed {$feed_url}: " . $rss->get_error_message());
                continue;
            }

            // Get items (limiting to 20 per feed for now)
            $items = $rss->get_items(0, 20);

            foreach ($items as $item) {
                // Extract image from enclosure or media:content if available
                $image_url = $this->get_item_image($item);

                $ideas[] = Idea_DTO::from_array(array(
                    'title'         => $item->get_title(),
                    'source_url'    => $item->get_permalink(),
                    'source_type'   => 'rss',
                    'provider_name' => $rss->get_title(),
                    'excerpt'       => wp_trim_words($item->get_description(), 50),
                    'image_url'     => $image_url,
                    'published_at'  => $item->get_date('c'),
                    'raw_data'      => array(
                        'feed_url' => $feed_url,
                        'author'   => $item->get_author() ? $item->get_author()->get_name() : '',
                    ),
                ));
            }
        }

        return $ideas;
    }

    /**
     * Implementation of TrendSourceInterface::fetchIdeas().
     *
     * This method proxies to fetch_ideas() for backward compatibility.
     *
     * @param array $params
     * @return array
     */
    public function fetchIdeas(array $params = array()): array
    {
        return $this->fetch_ideas($params);
    }

    /**
     * Extract image URL from feed item
     *
     * @param \SimplePie_Item $item
     * @return string
     */
    private function get_item_image($item): string
    {
        // 1. Try enclosures
        $enclosure = $item->get_enclosure();
        if ($enclosure && $enclosure->get_link()) {
            return $enclosure->get_link();
        }

        // 2. Try media:content
        $content = $item->get_item_tags('http://search.yahoo.com/mrss/', 'content');
        if ($content && isset($content[0]['attribs']['']['url'])) {
            return $content[0]['attribs']['']['url'];
        }

        // 3. Try thumbnail
        $thumb = $item->get_item_tags('http://search.yahoo.com/mrss/', 'thumbnail');
        if ($thumb && isset($thumb[0]['attribs']['']['url'])) {
            return $thumb[0]['attribs']['']['url'];
        }

        return '';
    }
}
