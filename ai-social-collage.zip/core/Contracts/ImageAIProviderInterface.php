<?php
namespace AiSocialCollage\Contracts;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

interface ImageAIProviderInterface {

	public function generate_image( $prompt, $width = 1080, $height = 1350 );

	public function get_provider_name();

	public function get_model_name();
}
