<?php

/**
 * Plugin Name: News MCQ Generator
 * Plugin URI: https://applehowtotips.com
 * Description: Generates MCQs from current news, topics, and custom articles with extensive features
 * Version:           9.5.6
 * Author:            MCP Developers
 * Author URI: https://applehowtotips.com
 * License:           GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       wp-news-mcq-generator
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP:      7.4
 *
 * @package wp-news-mcq-generator
 * @version 9.5.6
 *
 * @changelog
 * 9.5.1 - Monthly PDF: PDF cover now embeds the site LOGO (base64 data URI) + shows the domain link (thequizwire.com); page/SEO titles signal PDF download ("Download [Topic] MCQs with Answers/Explanations (PDF)").
 * 9.5.0 - Monthly PDF Archive: downloadable, professionally formatted monthly PDFs of all MCQs per selected topic (cover page with logo, page numbers, questions never cut), with ONE evergreen page per topic (/topic-mcqs-with-answers/ → clean slug). New 📥 Monthly PDF settings tab; Rank Math SEO title/meta updated monthly; accordion of past months' PDFs. Bundles Dompdf v3.1.6.
 * 9.4.5 - FIXED Daily Roundup never generating: the cron timezone bug (mktime used server UTC instead of site TZ) made it fire at 23:30 UTC = 04:30 next-day Karachi, so it looked at the wrong day and found "no MCQs published". Now scheduled at 23:30 site time via wp_timezone().
 * 9.4.3 - Daily roundup is now exam-practice oriented (title/prompt/UI reframed as "Daily Practice Roundup", not a news article). Added a "Run Daily Roundup Now" button on the News tab to trigger today's roundup immediately.
 * 9.4.2 - Updated News tab descriptions to match the new DAILY roundup (Enable Daily Roundup → one post per day covering all MCQs).
 * 9.4.1 - Daily Current Affairs Roundup: replaced per-batch tiny articles with ONE end-of-day roundup post covering ALL MCQs published that day (grouped by topic). Fixed garbled related-MCQ links (clean /mcq/slug/ permalinks, markdown+URL stripping) and changed the topic hub link text to just the topic name.
 * 9.4.0 - Added "Assign Random Authors to All MCQs" tool (E-E-A-T backfill: sets post_author + byline meta on every existing MCQ from the Named Authors list). Added Topic Pillar Articles: evergreen SEO/AIO/LLMO 800-1500 word pillars per selected topic/exam (new 🧭 Pillars settings tab), standalone post type, draft-first + Scheduler publishing, random author, FAQ + Rank Math SEO, featured image.
 * 9.0.1 - Migrated Quiz Generation from admin-ajax.php to public REST API endpoint to fix 403 Forbidden errors for guests.
 * 8.9.9 - Added Randomized daily MCQ publication limit (Min/Max range).
 * 8.9.8 - Added Topic Disambiguation by appending Parent Name to sub-topics in search results (e.g., "History - Pakistan").
 * 8.9.7 - Switched Quiz Topic Search to a public REST endpoint to bypass 403 Forbidden errors in some server environments.
 * 8.9.6 - Enhanced Quiz Topic search with detailed error reporting and visibility checks for guests.
 * 8.0.0 - Video Studio: Deterministic Rendering Engine, Template Manager, SEO Generator
 * 7.7.0 - Video Studio Priority 3: Workflow Efficiency (Batch logging, Brand Kits)
 * 7.5.0 - Video Studio Phase 1: Animation engine, TTS manager, 17 templates, audio manager
 * 7.3.15 - Restored rich HTML email digest, added universal notification bell for all users, fixed nonce compatibility, improved HTML detection
 * 7.3.14 - Branded Social Images: Added dynamic image generation with "TheQuizWire" branding (Vibrant Gradient + Footer CTA), fixed WhatsApp share text formatting, unified MCQ card rendering across Homepage/Topic pages, and enhanced Flexible Taxonomy Widget styling
 * 7.3.13 - Added social media image support for Topics/Exams with intelligent fallback hierarchy, fixed Twitter Card meta tags
 * 7.3.12 - UI Overhaul: Quiz/exam modal responsive (vh-based), Homepage EETA styling sync, Topic page button addition
 * 7.3.11 - Fixed multiple production bugs: PWA config, duplicate scan progress, quiz UI overlap, dark mode share button, E-A-T formatting, MCQ sync
 * 7.3.10 - Enhanced server-side MCQ validation (160char questions, 60char options),fixed quiz/mock exam dark mode, improved visual consistency
 * 7.3.9 - Fixed quiz modal viewport, E-A-T display, dark mode for exam tags/social shares/mock exam, mobile menu
 * 7.3.8 - Added E-A-T backfill admin tool, quiz modal mobile scrolling, Mock Exam shortcode
 * 7.3.7 - E-A-T implementation across site (author, fact-checked, difficulty)
 * 7.3.1 - Fixed email subscription text accuracy and quiz modal responsiveness
 * 7.3.0 - Added Blueprint vs Actual analytics and enhanced System Health monitoring
 * 7.2.0 - Improved social sharing and Current Affairs features
 */

if (! defined('ABSPATH')) {
	exit;
}

// ==================================================================================
// PLUGIN CONSTANTS
// ==================================================================================
define('NM_PLUGIN_VERSION', '9.5.6');
define('NM_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('NM_PLUGIN_URL', plugin_dir_url(__FILE__));
define('NM_MCQ_GENERATOR_VERSION', '9.5.6');
define('NM_MCQ_GENERATOR_URL', plugin_dir_url(__FILE__));
define('NM_VERSION', '9.5.6');
define('NM_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('NM_PLUGIN_FILE', __FILE__);

// ==================================================================================
// AUTOLOADER
// ==================================================================================
require_once NM_PLUGIN_PATH . 'includes/autoload.php';
// Explicitly load the Database Optimizer class to avoid autoload timing issues
require_once NM_PLUGIN_PATH . 'includes/class-nm-database-optimizer.php';
// ==================================================================================
// ✅ PHASE 3: Load Code Quality Classes
// These must be loaded BEFORE other classes that depend on them
// ==================================================================================
if (file_exists(NM_PLUGIN_PATH . 'includes/class-nm-response-handler.php')) {
	require_once NM_PLUGIN_PATH . 'includes/class-nm-response-handler.php';
}
if (file_exists(NM_PLUGIN_PATH . 'includes/class-nm-validator.php')) {
	require_once NM_PLUGIN_PATH . 'includes/class-nm-validator.php';
}

// ==================================================================================
// ✅ PHASE 3: Load NEW Refactored AJAX Classes
// These must be loaded BEFORE the AJAX Manager
// ==================================================================================
if (file_exists(NM_PLUGIN_PATH . 'includes/class-nm-ajax-frontend.php')) {
	require_once NM_PLUGIN_PATH . 'includes/class-nm-ajax-frontend.php';
}
if (file_exists(NM_PLUGIN_PATH . 'includes/class-nm-ajax-dashboard.php')) {
	require_once NM_PLUGIN_PATH . 'includes/class-nm-ajax-dashboard.php';
}
if (file_exists(NM_PLUGIN_PATH . 'includes/class-nm-ajax-admin.php')) {
	require_once NM_PLUGIN_PATH . 'includes/class-nm-ajax-admin.php';
}

// ✅ PHASE 4: Load Video Studio Integration Classes
if (file_exists(NM_PLUGIN_PATH . 'includes/class-nm-question-usage-tracker.php')) {
	require_once NM_PLUGIN_PATH . 'includes/class-nm-question-usage-tracker.php';
}
if (file_exists(NM_PLUGIN_PATH . 'includes/class-nm-rest-api.php')) {
	require_once NM_PLUGIN_PATH . 'includes/class-nm-rest-api.php';
}

// ✅ v7.3.8: Mock Exam Feature
if (file_exists(NM_PLUGIN_PATH . 'includes/class-nm-mock-exam.php')) {
	require_once NM_PLUGIN_PATH . 'includes/class-nm-mock-exam.php';
}

// ✅ NEW v9.0.3: 3rd Party Integrations (Jetpack & Rank Math & Buffer)
if (file_exists(NM_PLUGIN_PATH . 'includes/class-nm-jetpack-integration.php')) {
    require_once NM_PLUGIN_PATH . 'includes/class-nm-jetpack-integration.php';
}
if (file_exists(NM_PLUGIN_PATH . 'includes/class-nm-rank-math-integration.php')) {
    require_once NM_PLUGIN_PATH . 'includes/class-nm-rank-math-integration.php';
}
if (file_exists(NM_PLUGIN_PATH . 'includes/class-nm-buffer-integration.php')) {
    require_once NM_PLUGIN_PATH . 'includes/class-nm-buffer-integration.php';
}
// ==================================================================================
// INITIALIZE MANAGERS
// ==================================================================================
add_action(
	'plugins_loaded',
	function () {

		// ✅ Verify Phase 3 classes are loaded
		if (! class_exists('NM_Response_Handler')) {
		}
		if (! class_exists('NM_Validator')) {
		}

		// Core Infrastructure
		NM_Post_Type_Manager::init();
		NM_Cron_Manager::init();
		NM_AJAX_Manager::init(); // Now uses Response Handler & Validator
		NM_Cache_Manager::init();
		NM_Security_Manager::init();
		NM_Database_Migration::init();

        // Initialize Database Optimizer (guarded to prevent fatals if class not loaded)
        if (class_exists('NM_Database_Optimizer')) {
            NM_Database_Optimizer::init();
        } else {
        }

        // Initialize Social Image Generator (must be after post type registration)
        if (class_exists('NM_Social_Image_Generator')) {
            NM_Social_Image_Generator::init();
        }

        NM_Generation_Logger::init();

		// Admin Features
		NM_Admin_Menu::init();
		NM_Admin_Dashboard::init();

		if (file_exists(NM_PLUGIN_PATH . 'includes/class-nm-admin-settings.php')) {
			require_once NM_PLUGIN_PATH . 'includes/class-nm-admin-settings.php';
		}
		NM_Admin_Settings::init();
		NM_Meta_Boxes::init();
		NM_Importer::init();
		NM_Duplicate_Tool::init();
		NM_Reported_MCQs::init();
		// MCQ Exporter
		if (file_exists(NM_PLUGIN_DIR . 'includes/class-nm-mcq-exporter.php')) {
			require_once NM_PLUGIN_DIR . 'includes/class-nm-mcq-exporter.php';
			NM_MCQ_Exporter::init();
		}

		// Generation & Content (Service classes are just loaded)
		NM_Embedding_Database::init();
		NM_Advanced_News_Sources::init();
		NM_Current_Affairs_Generator::init();

		// @NEW 9.2.0: News roundup article generator (SEO/AIO/LLMO).
		if (file_exists(NM_PLUGIN_PATH . 'includes/class-nm-news-article-generator.php')) {
			require_once NM_PLUGIN_PATH . 'includes/class-nm-news-article-generator.php';
		}
		if (class_exists('NM_News_Article_Generator')) {
			NM_News_Article_Generator::init();
		}

		// @NEW 9.4.0: Topic Pillar generator (evergreen SEO/AIO/LLMO pillars).
		if (file_exists(NM_PLUGIN_PATH . 'includes/class-nm-topic-pillar-generator.php')) {
			require_once NM_PLUGIN_PATH . 'includes/class-nm-topic-pillar-generator.php';
		}
		if (class_exists('NM_Topic_Pillar_Generator')) {
			NM_Topic_Pillar_Generator::init();
		}

		// @NEW 9.5.0: Monthly PDF Archive (downloadable monthly MCQ PDFs per topic).
		if (file_exists(NM_PLUGIN_PATH . 'includes/class-nm-monthly-pdf-archive.php')) {
			require_once NM_PLUGIN_PATH . 'includes/class-nm-monthly-pdf-archive.php';
		}
		if (class_exists('NM_Monthly_PDF_Archive')) {
			NM_Monthly_PDF_Archive::init();
		}

		// Frontend & User Features
		NM_Widget_Manager::init();
		NM_Shortcode_Manager::init();
		NM_Frontend_Manager::init();
		NM_Template_Loader::init();
		NM_User_Authentication::init();
		NM_Email_Verification::init();
		NM_User_Dashboard::init();
		NM_Gamification::init();
		NM_Leaderboard::init();
		NM_Notifications::init();
		NM_PWA_Support::init();
		NM_Email_Digest::init();

		// ✅ v7.3.8: Mock Exam Feature
		NM_Mock_Exam::init();

        // ✅ NEW v9.0.3: 3rd Party Integrations
        if (class_exists('NM_Jetpack_Integration')) {
            NM_Jetpack_Integration::init();
        }
        if (class_exists('NM_Rank_Math_Integration')) {
            NM_Rank_Math_Integration::init();
        }
        if (class_exists('NM_Buffer_Integration')) {
            NM_Buffer_Integration::init();
        }

		// ✅ v9.0.0: REST API
		if (class_exists('NM_Rest_API')) {
			NM_Rest_API::init();
		}

		// ✅ v9.0.0: Signal that MCQ Plugin is ready for companion plugins
		do_action('nm_mcq_plugin_loaded');

		// ✅ v9.0.0: Video Studio Module (New Independent Structure)
		// Located in mcq-video-studio/ folder, will be moved outside plugin later
		$video_studio_bootstrap = NM_PLUGIN_DIR . 'mcq-video-studio/mcq-video-studio.php';
		if (file_exists($video_studio_bootstrap)) {
			require_once $video_studio_bootstrap;
		}
	},
	10
); // Priority 10 ensures WordPress core is fully loaded

// ==================================================================================
// CLOUDFLARE SUPER PAGE CACHE INTEGRATION (Robust purge on MCQ changes)
// ==================================================================================
require_once plugin_dir_path(__FILE__) . 'includes/class-nm-cloudflare-cache-integration.php';

add_action(
	'plugins_loaded',
	function () {
		if (class_exists('NM_Cloudflare_Cache_Integration')) {
			NM_Cloudflare_Cache_Integration::init();
		}
	},
	20
);

// ==================================================================================
// ACTIVATION & DEACTIVATION HOOKS
// ==================================================================================

/**
 * Plugin Activation Hook
 * Handles all setup tasks when plugin is activated
 *
 * @version 2.0 - Added database indexes for performance
 */
function nm_plugin_activate()
{

	// 0. ✅ Log Activation Start
	if (class_exists('NM_Generation_Logger')) {
		NM_Generation_Logger::nm_log_activity('🗑️  [ACTIVATION] Plugin activation started.', 'success');
	}

	// 1. ✅ Register Post Types (Required before flush_rewrite_rules)
	if (class_exists('NM_Post_Type_Manager')) {
		NM_Post_Type_Manager::register_post_types();
		if (class_exists('NM_Generation_Logger')) {
			NM_Generation_Logger::nm_log_activity('✅ [ACTIVATION] Post types registered.', 'info');
		}
	} else {
		error_log('NM Plugin Activation Error: NM_Post_Type_Manager class missing');
	}

	// 2. ✅ Database setup (Create tables, set options)
	if (class_exists('NM_Database_Manager')) {
		// ✅ FIX: Initialize Cron Manager to register schedules before activation
		if (class_exists('NM_Cron_Manager')) {
			// Ensure singleton is initialized so filters are added
			NM_Cron_Manager::init();

			// @MODIFIED: Force schedule registration immediately for this request
			// because wp_schedule_event checks wp_get_schedules() which relies on the 'cron_schedules' filter
			// which might not have fired yet if we are in the middle of a plugin activation.
			add_filter('cron_schedules', array('NM_Cron_Manager', 'register_cron_intervals'));
		}
		NM_Database_Manager::on_activation();

		if (class_exists('NM_Generation_Logger')) {
			NM_Generation_Logger::nm_log_activity('✅ [ACTIVATION] Database tables and options verified.', 'info');
		}
	} else {
		error_log('NM Plugin Activation Error: NM_Database_Manager class missing');
	}

	// 3. ✅ Install PWA files (Service worker, manifest)
	if (class_exists('NM_PWA_Support')) {
		NM_PWA_Support::install_pwa_files();
		if (class_exists('NM_Generation_Logger')) {
			NM_Generation_Logger::nm_log_activity('✅ [ACTIVATION] PWA files installed.', 'info');
		}
	}

	// 4. ✅ Flush rewrite rules (Enable pretty URLs)
	flush_rewrite_rules();
	if (class_exists('NM_Generation_Logger')) {
		NM_Generation_Logger::nm_log_activity('✅ [ACTIVATION] Rewrite rules flushed.', 'info');
	}

	// 5. ✅ NEW: Create performance indexes
	$indexes_file = plugin_dir_path(__FILE__) . 'includes/class-nm-database-indexes.php';

	if (file_exists($indexes_file)) {
		require_once $indexes_file;

		if (class_exists('NM_Database_Indexes')) {
			// Only create indexes if they don't exist
			if (! (new NM_Database_Indexes())->indexes_exist()) {
				$result = NM_Database_Indexes::create_indexes();

				if ($result) {
					if (class_exists('NM_Generation_Logger')) {
						NM_Generation_Logger::nm_log_activity('✅ [ACTIVATION] Database indexes created.', 'info');
					}
				} elseif (class_exists('NM_Generation_Logger')) {
					NM_Generation_Logger::nm_log_activity('⚠️  [ACTIVATION] Index creation returned false (may exist).', 'warning');
				}
			} else {
				// Indexes already exist
			}
		} else {
			error_log('NM Plugin Activation Error: NM_Database_Indexes class missing');
		}
	} else {
		error_log('NM Plugin Activation Error: Indexes file missing');
	}

	// 2b. ✅ Ensure embeddings table (schema + upgrades)
	if (class_exists('NM_Embedding_Database')) {
		$embedding_db = new NM_Embedding_Database();
		$embedding_db->create_table();
	} else {
		error_log('NM Plugin Activation Error: NM_Embedding_Database class missing');
	}

	// ✅ NEW v7.3.4: Create notifications table
	NM_Notifications::create_tables();

	// ✅ NEW v7.3.4: Schedule daily digest at 8 AM
	if (! wp_next_scheduled('nm_send_daily_digest')) {
		$tomorrow_8am = strtotime('tomorrow 8:00 AM');
		wp_schedule_event($tomorrow_8am, 'daily', 'nm_send_daily_digest');
		if (class_exists('NM_Generation_Logger')) {
			NM_Generation_Logger::nm_log_activity('✅ [ACTIVATION] Daily digest scheduled.', 'info');
		}
	}

	// ✅ NEW v9.0.0: Question Usage Tracker & REST API
	if (class_exists('NM_Question_Usage_Tracker')) {
		NM_Question_Usage_Tracker::create_table();
	}

	// Store activation timestamp
	update_option('nm_activation_time', current_time('mysql'));
	update_option('nm_plugin_version', NM_VERSION);

	if (class_exists('NM_Generation_Logger')) {
		NM_Generation_Logger::nm_log_activity('🎉 [ACTIVATION] Activation sequence complete!', 'success');
	}
}
register_activation_hook(__FILE__, 'nm_plugin_activate');

/**
 * Plugin Deactivation Hook
 * Runs on plugin deactivation
 */
function nm_plugin_deactivate()
{

	// 1. Database cleanup (handled by Database Manager)
	if (class_exists('NM_Database_Manager')) {
		NM_Database_Manager::on_deactivation();
	}

	// 2. ✅ Uninstall PWA files
	if (class_exists('NM_PWA_Support')) {
		NM_PWA_Support::uninstall_pwa_files();
	}

	// 3. Flush rewrite rules
	flush_rewrite_rules();

	// ✅ NEW v7.3.4: Clear scheduled digest
	wp_clear_scheduled_hook('nm_send_daily_digest');
}
register_deactivation_hook(__FILE__, 'nm_plugin_deactivate');
