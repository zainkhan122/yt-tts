package com.snsaver.app.domain.model

enum class Platform(val displayName: String, val shortName: String, val color: Long) {
    INSTAGRAM("Instagram","IG",0xFFE1306C), TIKTOK("TikTok","TT",0xFF00F2EA), TWITTER("X / Twitter","X",0xFF1DA1F2), FACEBOOK("Facebook","FB",0xFF1877F2), YOUTUBE("YouTube","YT",0xFFFF0000), REDDIT("Reddit","RD",0xFFFF4500), PINTEREST("Pinterest","PI",0xFFBD081C), SNAPCHAT("Snapchat","SC",0xFFFFFC00), UNKNOWN("Unknown","?",0xFF888888)
}
enum class DownloadStatus { PENDING, EXTRACTING, DOWNLOADING, COMPLETED, FAILED, CANCELLED }
enum class MediaType { IMAGE, VIDEO, CAROUSEL, UNKNOWN }
data class DownloadItem(
    val id: Long = 0, val sourceUrl: String, val platform: Platform,
    val status: DownloadStatus = DownloadStatus.PENDING, val mediaType: MediaType = MediaType.UNKNOWN,
    val filePath: String? = null, val thumbnailPath: String? = null, val caption: String? = null,
    val hashtags: List<String> = emptyList(), val profileUrl: String? = null, val profileName: String? = null,
    val mediaUrls: List<String> = emptyList(), val downloadedFiles: List<String> = emptyList(),
    val progress: Int = 0, val errorMessage: String? = null, val fileSize: Long = 0,
    val timestamp: Long = System.currentTimeMillis(), val title: String? = null, val workerId: String? = null
)
