<?php

/**
 * File 10: Feed Importer Class
 * Version: 2.3 - Fixed logging calls
 *
 * @MODIFIED: Now uses NM_Advanced_Duplicate_Detector class.
 * @MODIFIED: Now calls NM_Post_Type_Manager::save_mcq_post_unified()
 * @MODIFIED: Replaced call to nm_get_gemini_api_key() with NM_API_Client::get_gemini_api_key()
 * @MODIFIED: Replaced all procedural logging calls with static NM_Generation_Logger calls.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class NM_Feed_Importer {


	public static function init() {
		// This class is a service class; its methods are
		// called directly by the Cron Manager and AJAX Manager.
		// No init() hooks are needed here.
	}

	/**
	 * Main function to run the import process.
	 * Can be called from Cron or manually.
	 */
	public static function run_import( $override_status = null ) {
		$log            = array();
		$imported_count = 0;
		$skipped_count  = 0;

		$feed_url = get_option( 'nm_mcq_feed_url', '' );
		if ( empty( $feed_url ) ) {
			$log[] = '❌ Feed import failed: No feed URL configured.';
			if ( class_exists( 'NM_Generation_Logger' ) ) {
				NM_Generation_Logger::nm_log_activity( 'Feed Import Failed: No URL', 'error' );
			}
			return array( 0, $log );
		}

		$max_items = get_option( 'nm_feed_importer_max_items', 10 );
		$feed      = fetch_feed( $feed_url );

		if ( is_wp_error( $feed ) ) {
			$log[] = '❌ Feed import failed: ' . $feed->get_error_message();
			if ( class_exists( 'NM_Generation_Logger' ) ) {
				NM_Generation_Logger::nm_log_activity( 'Feed Import Failed: ' . $feed->get_error_message(), 'error' );
			}
			return array( 0, $log );
		}

		$items = $feed->get_items( 0, $max_items );
		if ( empty( $items ) ) {
			$log[] = 'ℹ️ Feed import: No new items found in feed.';
			if ( class_exists( 'NM_Generation_Logger' ) ) {
				NM_Generation_Logger::nm_log_activity( 'Feed Import: No new items', 'info' );
			}
			return array( 0, $log );
		}

		$log[] = 'ℹ️ Found ' . count( $items ) . " items in feed. Processing up to {$max_items}.";

		$gemini_api_key       = NM_API_Client::get_gemini_api_key();
		$skip_semantic_check  = get_option( 'nm_skip_import_duplicate_check', 0 );
		$similarity_threshold = floatval( get_option( 'nm_similarity_threshold', 0.70 ) );
		$detector             = new NM_Advanced_Duplicate_Detector( $gemini_api_key, $similarity_threshold );

		foreach ( $items as $item ) {
			$mcq_data = self::parse_mcq_from_feed_item( $item );

			if ( ! $mcq_data ) {
				$log[] = '⚠️ Skipped item: Invalid format. (' . $item->get_title() . ')';
				continue;
			}

			// --- Duplicate Check ---
			$is_duplicate    = false;
			$duplicate_check = array( 'is_duplicate' => false );

			if ( ! $skip_semantic_check ) {
				if ( ! empty( $gemini_api_key ) ) {
					$duplicate_check = $detector->check_duplicate( $mcq_data['question'] );
					$is_duplicate    = $duplicate_check['is_duplicate'];
				}
			} else {
				// Fallback to basic title check
				$is_duplicate = ( get_page_by_title( $mcq_data['question'], OBJECT, 'mcq' ) !== null );
				if ( $is_duplicate ) {
					$duplicate_check['method'] = 'title';
				}
			}

			if ( $is_duplicate ) {
				++$skipped_count;
				$method = $duplicate_check['method'] ?? 'unknown';
				$log[]  = "⏭️ Skipped duplicate ({$method}): " . $mcq_data['question'];
				if ( class_exists( 'NM_Generation_Logger' ) ) {
					NM_Generation_Logger::nm_log_activity(
						"Duplicate (feed, {$method})",
						'duplicate',
						array(
							'source_type' => 'feed',
							'question'    => $mcq_data['question'],
						)
					);
				}
				continue;
			}

			// --- Save the Post ---
			$save_args = array(
				'topic'    => $mcq_data['topic'],
				'subtopic' => $mcq_data['subtopic'] ?? '',
				'api_key'  => $gemini_api_key, // Pass API key for embedding
			);

			if ( $override_status ) {
				$save_args['post_status'] = $override_status;
			}

			$post_id = NM_Post_Type_Manager::save_mcq_post_unified( $mcq_data, $save_args );

			if ( $post_id ) {
				++$imported_count;
				$log[] = '✅ Imported MCQ: ' . $mcq_data['question'];
				update_post_meta( $post_id, '_nm_imported_from_feed', $feed_url );
				update_post_meta( $post_id, '_nm_feed_item_guid', $item->get_id() );
			} else {
				$log[] = '❌ Failed to save post: ' . $mcq_data['question'];
			}
		}

		$log[] = "✅ Feed import complete. Imported: {$imported_count}, Skipped: {$skipped_count}.";
		if ( class_exists( 'NM_Generation_Logger' ) ) {
			NM_Generation_Logger::nm_log_activity( "Feed Import Complete: {$imported_count} imported, {$skipped_count} skipped", 'success' );
		}

		return array( $imported_count, $log );
	}

	/**
	 * Parses the <content:encoded> block for structured MCQ data.
	 */
	private static function parse_mcq_from_feed_item( $item ) {
		$question = $item->get_title();
		$content  = $item->get_content();

		if ( preg_match( '/\{.*\}/s', $content, $matches ) ) {
			$json_data = json_decode( $matches[0], true );
			if ( json_last_error() === JSON_ERROR_NONE && isset( $json_data['options'] ) && isset( $json_data['answer'] ) ) {
				return array(
					'question'    => $question,
					'options'     => $json_data['options'],
					'answer'      => $json_data['answer'],
					'explanation' => $json_data['explanation'] ?? '',
					'topic'       => $json_data['topic'] ?? 'Uncategorized',
					'subtopic'    => $json_data['subtopic'] ?? '',
				);
			}
		}

		$description = $item->get_description();
		if ( preg_match( '/\{.*\}/s', $description, $matches ) ) {
			$json_data = json_decode( $matches[0], true );
			if ( json_last_error() === JSON_ERROR_NONE && isset( $json_data['options'] ) && isset( $json_data['answer'] ) ) {
				return array(
					'question'    => $question,
					'options'     => $json_data['options'],
					'answer'      => $json_data['answer'],
					'explanation' => $json_data['explanation'] ?? '',
					'topic'       => $json_data['topic'] ?? 'Uncategorized',
					'subtopic'    => $json_data['subtopic'] ?? '',
				);
			}
		}

		return false;
	}
}
