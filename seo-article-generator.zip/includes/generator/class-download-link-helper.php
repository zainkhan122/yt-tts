<?php

namespace SEO_Article_Generator\Generator;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Shared helper for download link logic.
 * Central download-link contract: normalization, validation, grouping, and display.
 *
 * @since 2.14.0
 * @MODIFIED 2026-03-08: Added is_placeholder_url, infer_platform_from_url, normalize_variant_name,
 *   normalize_link, normalize_links, get_primary_link. Fixed normalize_platform_name, sort_links_by_variant.
 * @MODIFIED 2026-03-11: Enhanced placeholder detection with LLM hallucination patterns.
 */
class Download_Link_Helper {


	/**
	 * Placeholder patterns for junk URL detection.
	 *
	 * @since 2.27.0
	 */
	private const PLACEHOLDER_PATTERNS = array(
		'placeholder',
		'example.com/download',
		'example.com',
		'dummy.com',
		'localhost',
		'127.0.0.1',
		'download-link-here',
		'your-download-link',
		'test.com',
		'idXXXXXXXXX',
		'id000000000',
		'id123456789',
		'com.example',
		'com.yourcompany',
		'officialsite.com',
		'yourdomain.com',
		'11011111011', // AI Youtube hallucination
		'00000000000',
		'11111111111',
		'12345678901',
		'abcdefghijk',
		'xxxxxxxxxxx',
		'dQw4w9WgXcQ',
	);

	/**
	 * Canonical platform mapping.
	 *
	 * @since 2.27.0
	 */
	private const CANONICAL_PLATFORM_MAP = array(
		'windows'     => 'Windows',
		'win'         => 'Windows',
		'pc'          => 'Windows',
		'mac'         => 'macOS', // Standardized to macOS
		'macos'       => 'macOS',
		'osx'         => 'macOS',
		'mac os'      => 'macOS',
		'linux'       => 'Linux',
		'ubuntu'      => 'Linux',
		'debian'      => 'Linux',
		'fedora'      => 'Linux',
		'android'     => 'Android',
		'ios'         => 'iOS',
		'iphone'      => 'iOS',
		'ipad'        => 'iOS',
		'app store'   => 'iOS',
		'play store'  => 'Android',
		'google play' => 'Android',
	);

	/**
	 * Non-download file extensions that represent media, documents, fonts, stylesheets, or scripts.
	 *
	 * @since 2.31.0
	 */
	private const NON_DOWNLOAD_EXTENSIONS = array(
		'png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'bmp', 'ico', 'tiff', 'tif', 'heic', 'avif', // Images
		'mp3', 'wav', 'ogg', 'flac', 'aac', 'm4a', 'wma',                                      // Audio
		'mp4', 'mkv', 'avi', 'mov', 'wmv', 'flv', 'webm', 'mpeg', 'mpg', 'm4v', '3gp',          // Video
		'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'rtf', 'odt', 'ods', 'odp',          // Documents
		'csv', 'xml', 'json', 'txt',                                                           // Data/text docs
		'woff', 'woff2', 'ttf', 'otf', 'eot',                                                  // Fonts
		'css', 'js', 'map', 'scss', 'less',                                                    // Web assets
	);

	/**
	 * Check if a URL is a placeholder, fake, or invalid download URL.
	 * This is the single source of truth for URL rejection across the pipeline.
	 *
	 * @MODIFIED 2026-03-09: Upgraded with robust pattern matching and host checks
	 * @MODIFIED 2026-03-11: Added standard AI hallucination patterns
	 *
	 * @param string $url URL to check
	 * @return bool True if URL should be rejected
	 */
	public static function is_placeholder_url( $url ) {
		$url = trim( (string) $url );
		if ( $url === '' || $url === '#' || strtolower( $url ) === 'n/a' ) {
			return true;
		}

		// Decode HTML entities before pattern matching
		$decoded    = html_entity_decode( $url, ENT_QUOTES, 'UTF-8' );
		$normalized = strtolower( trim( $decoded ) );

		$host       = parse_url( $decoded, PHP_URL_HOST );
		$host_lower = is_string( $host ) ? strtolower( preg_replace( '/^www\./i', '', $host ) ) : '';

		// Exempt explicitly trusted official domains from aggressive heuristic filtering.
		// Example: Google Chrome installers contain "/tag/" and "{GUIDs}" which trigger heuristic blocks.
		if ( $host_lower === 'dl.google.com' || $host_lower === 'google.com' || self::is_allowlisted_url( $url ) ) {
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				$exempt_reason = '';
				if ( $host_lower === 'dl.google.com' ) { $exempt_reason = 'dl.google.com'; }
				elseif ( $host_lower === 'google.com' ) { $exempt_reason = 'google.com'; }
				else { $exempt_reason = 'allowlist'; }
				error_log( '[DownloadLinkHelper] is_placeholder_url: EXEMPTED reason=' . $exempt_reason . ' host=' . $host_lower . ' url=' . $url );
			}
			return false;
		}

		if ( strpos( $normalized, 'javascript:' ) === 0 || strpos( $normalized, 'about:blank' ) === 0 || strpos( $normalized, 'data:' ) === 0 ) {
			return true;
		}

		if ( self::is_placeholder_youtube_url( $url ) ) {
			return true;
		}

		// Check against known placeholder patterns
		foreach ( self::PLACEHOLDER_PATTERNS as $needle ) {
			if ( strpos( $normalized, $needle ) !== false ) {
				return true;
			}
		}

		// Complex invalid patterns
		$invalid_patterns = array(
			'/your[-_\s]?link/i',
			'/your[-_\s]?download/i',
			'/your[-_\s]?url/i',
			'/fake/i',
			'/sample/i',
			'/changeme/i',
			'/not[\s\-_]*found/i',
			'/\{.+\}/',
			'/\[.+\]/',
			'/id[X0]{5,}/i', // Catch idXXXXX or id00000 with 5+ chars
			'/com\.(example|yourcompany|yourdomain)\./i',
		);

		foreach ( $invalid_patterns as $pattern ) {
			if ( preg_match( $pattern, $url ) ) {
				return true;
			}
		}

		// Host-based rejection (Trash/Social/Hallucination hubs)
		if ( is_string( $host ) ) {
			$host          = strtolower( preg_replace( '/^www\./i', '', $host ) );
			$blocked_hosts = array(
				'example.com',
				'dummy.com',
				'localhost',
				'127.0.0.1',
				'0.0.0.0',
				'facebook.com',
				'twitter.com',
				'linkedin.com',
				'pinterest.com',
				't.co',
				'instagram.com',
				'reddit.com',
				'youtube.com',
				'youtu.be',
				'vimeo.com',
			);

			if ( in_array( $host, $blocked_hosts, true ) ) {
				return true;
			}

			// Reject known "Trash" domains identified by user
			if ( stripos( $host, 'softexia.com' ) !== false && ( stripos( $url, '/tag/' ) !== false || stripos( $url, '/category/' ) !== false ) ) {
				return true;
			}
		}

		// Path-based rejection for generic "Hub" patterns
		$path = parse_url( $decoded, PHP_URL_PATH );
		if ( is_string( $path ) ) {
			$path_lower    = strtolower( $path );
			$blocked_paths = array( '/tag/', '/category/', '/author/', '/search/', '/drivers/' );
			foreach ( $blocked_paths as $p ) {
				if ( strpos( $path_lower, $p ) !== false ) {
					if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
						error_log( '[DownloadLinkHelper] is_placeholder_url: REJECTED - blocked path="' . $p . '" url=' . $url );
					}
					return true;
				}
			}
		}

		if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
			error_log( '[DownloadLinkHelper] is_placeholder_url: PASSED url=' . $url );
		}
		return false;
	}

	/**
	 * Combined check for URL validity and placeholder status.
	 * Useful for external validation (e.g. Validator).
	 *
	 * @since 2.27.0
	 *
	 * @param string $url URL to check
	 * @return bool True if URL is a real, valid HTTP(S) download link
	 */
	public static function is_valid_download_url( $url ) {
		$url = trim( (string) $url );
		if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
			error_log( '[DownloadLinkHelper] is_valid_download_url: CHECKING url=' . $url );
		}
		if ( self::is_placeholder_url( $url ) ) {
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				error_log( '[DownloadLinkHelper] is_valid_download_url: REJECTED - is_placeholder_url=true url=' . $url );
			}
			return false;
		}

		if ( self::is_affiliate_url( $url ) ) {
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				error_log( '[DownloadLinkHelper] is_valid_download_url: REJECTED - affiliate_url=true url=' . $url );
			}
			return false;
		}

		if ( ! filter_var( $url, FILTER_VALIDATE_URL ) ) {
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				error_log( '[DownloadLinkHelper] is_valid_download_url: REJECTED - invalid_url=true url=' . $url );
			}
			return false;
		}

		$path = (string) parse_url( $url, PHP_URL_PATH );
		if ( $path !== '' ) {
			$ext = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
			if ( in_array( $ext, self::NON_DOWNLOAD_EXTENSIONS, true ) ) {
				if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
					error_log( '[DownloadLinkHelper] is_valid_download_url: REJECTED - non-download extension="' . $ext . '" url=' . $url );
				}
				return false;
			}
		}

		$scheme = strtolower( (string) parse_url( $url, PHP_URL_SCHEME ) );
		if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
			error_log( '[DownloadLinkHelper] is_valid_download_url: ACCEPTED scheme=' . $scheme . ' url=' . $url );
		}
		return in_array( $scheme, array( 'http', 'https' ), true );
	}

	/**
	 * Positive binary-link check — mirrors Link_Resolver::resolve_from_html()
	 * so the discovery and generator paths agree on what counts as a download.
	 *
	 * @since 2.40.0
	 * @param string $url  URL to check.
	 * @param string $text Optional anchor/context text (secondary signal).
	 * @return bool True if URL is a binary file or release-asset target.
	 */
	public static function is_binary_link_url( $url, $text = '' ) {
		$url  = trim( (string) $url );
		$text = (string) $text;
		if ( $url === '' ) {
			return false;
		}
		if ( self::is_allowlisted_url( $url ) ) {
			return true;
		}
		if ( preg_match( '/\.(exe|msi|msix|msp|appx|dmg|pkg|deb|rpm|apk|appimage|zip|7z|tar\.gz|tgz|tar\.xz|tar\.bz2|sh|run|bin)(?:$|[?#])/i', $url ) ) {
			return true;
		}
		if ( preg_match( '~/(releases/(?:download|expanded_assets|latest)(?:[/?#]|$)|releases/tag/|-/releases(?:[/?#]|$)|raw/|archive/refs/)~i', $url ) ) {
			return true;
		}
		if ( preg_match( '#/projects/.+/files/.+/(download)?#i', $url ) ) {
			return true;
		}
		if ( $text !== '' && preg_match( '/\b(?:download|get\s+for|installer|offline\s+installer|direct\s+link|portable|trial)\b/i', $text ) ) {
			return true;
		}
		return false;
	}

	/**
	 * FIX F13 (Phase 3A): True when the URL points to a bare source-code
	 * repository page (project home / tree / blob / browse) rather than a
	 * downloadable release artifact.
	 *
	 * is_binary_link_url() is checked FIRST by callers: signal-bearing URLs
	 * (release assets, raw/ paths, /files/download on SourceForge, allowlisted
	 * vendor hosts) pass before this heuristic ever runs, so only genuinely
	 * signal-less repo pages are rejected.
	 *
	 * @param string $url URL to test.
	 * @return bool
	 */
	public static function is_repo_page_url( $url ) {
		$url = trim( (string) $url );
		if ( $url === '' ) {
			return false;
		}

		$host = strtolower( (string) parse_url( $url, PHP_URL_HOST ) );
		if ( $host === '' ) {
			return false;
		}

		// Code-hosting project pages: github.com/<o>/<r>[/tree|/blob|/pulls|/issues...],
		// gitlab.com/<o>/<r>[/-/tree|/-/blob...], bitbucket.org/<o>/<r>, codeberg.org/<o>/<r>.
		// NOTE: GitHub/GitLab are .com; Bitbucket/Codeberg are .org.
		if ( preg_match( '/(?:^|\.)(?:github|gitlab)\.com$|(?:^|\.)(?:bitbucket|codeberg)\.org$/i', $host ) ) {
			$path = (string) parse_url( $url, PHP_URL_PATH );

			if ($host === 'github.com' && preg_match('~^/[^/]+/[^/]+/blob/.+\.(?:exe|msi|zip|7z|dmg|pkg|deb|rpm|appimage)$~i', $path)) {
				parse_str((string) parse_url($url, PHP_URL_QUERY), $q);
				if (in_array(strtolower((string) ($q['raw'] ?? '')), array('true','1'), true)) return false;
			}
			if ($host === 'github.com' && preg_match('~^/[^/]+/[^/]+/releases(?:/(?:latest|tag/[^/]+))?/?$~i', $path)) return false;
			// [2.34.20 FIX] Release download/asset URLs, raw content, and archive
			// URLs are signal-bearing (direct file downloads), NOT repo pages.
			// Previously these were only caught by is_binary_link_url() which
			// callers like section_passes_sanity_check() don't invoke — causing
			// the download-section mandatory gate to falsely reject GitHub-hosted
			// download links.
			if ( preg_match( '#/releases/(?:download|assets)/#i', $path )
				|| preg_match( '#/(?:raw|archive)/#i', $path )
			) {
				return false;
			}
			// A bare release/tag/asset URL is signal-bearing and matched by
			// is_binary_link_url() first; anything else on the host is a repo page.
			if ( preg_match( '#^/[^/]+/[^/]+(?:/|$)#', $path ) ) {
				return true;
			}
			return false;
		}

		// SourceForge project pages vs /files/download artifacts:
		// projects/<p> (or projects/<p>/files with no /download) is a landing page.
		if ( $host === 'sourceforge.net' || preg_match( '/\.sourceforge\.net$/i', $host ) ) {
			$path = (string) parse_url( $url, PHP_URL_PATH );
			if ( preg_match( '#^/projects/[^/]+(?:/|$)#', $path ) && ! preg_match( '#/download#i', $path ) ) {
				return true;
			}
			return false;
		}

		return false;
	}

	/**
	 * Check if a URL is an affiliate/tracking redirect that should be rejected.
	 *
	 * Detects two classes of affiliate URLs:
	 * 1. Domain denylist — known affiliate network short domains (prf.hn, awin1.com, etc.)
	 * 2. Structural heuristic — opaque redirect paths with no file extension on non-vendor domains
	 *
	 * @MODIFIED 2026-04-29: Added for affiliate link firewall.
	 *
	 * @param string $url URL to check.
	 * @return bool True if the URL is an affiliate/tracking redirect.
	 */
	public static function is_affiliate_url( $url ) {
		$url = trim( (string) $url );
		if ( $url === '' ) {
			return false;
		}

		$host = strtolower( (string) parse_url( $url, PHP_URL_HOST ) );
		if ( $host === '' ) {
			return false;
		}

		// Hardcoded standard affiliate redirect domains denylist (Impact, Awin, ShareASale, CJ, etc.)
		static $hardcoded_affiliate_hosts = array(
			'evyy.net'                => true,
			'sjv.io'                  => true,
			'pxf.io'                  => true,
			'prf.hn'                  => true,
			'awin1.com'               => true,
			'shareasale.com'          => true,
			'cj.com'                  => true,
			'jdoqocy.com'             => true,
			'tkqlhce.com'             => true,
			'anrdoezrs.net'           => true,
			'dpbolvw.net'             => true,
			'kqzyfj.com'              => true,
			'qksrv.net'               => true,
			'click.linksynergy.com'   => true,
			'linksynergy.com'         => true,
			'rakuten.com'             => true,
			'impact.com'              => true,
			'impactradius.com'        => true,
			'flexlinkspro.com'        => true,
			'tracking.flexlinks.com'  => true,
			'referralrock.com'        => true,
			'partnerstack.com'        => true,
			'getrewardful.com'        => true,
			'tapfiliate.com'          => true,
			'leaddyno.com'            => true,
			'refersion.com'           => true,
			'ambassador.com'          => true,
			'emjcd.com'               => true,
			'avangate.com'            => true,
			'shareit.com'             => true,
			'regnow.com'              => true,
			'digistore24.com'         => true,
			'clickbank.net'           => true,
			'clickbank.com'           => true,
			'admitad.com'             => true,
			'tradedoubler.com'        => true,
			'webgains.com'            => true,
			'postaffiliatepro.com'    => true,
			'gomasters.co'            => true,
			'referralcandy.com'       => true,
			'doubleclick.net'         => true,
			'googleadservices.com'    => true,
		);

		if ( isset( $hardcoded_affiliate_hosts[ $host ] ) ) {
			return true;
		}
		foreach ( $hardcoded_affiliate_hosts as $denied => $true ) {
			if ( substr( $host, -( strlen( '.' . $denied ) ) ) === '.' . $denied ) {
				return true;
			}
		}

		// 1. Domain denylist check (admin-configurable)
		static $denylist = null;
		if ( $denylist === null ) {
			$raw      = trim(
				(string) \get_option(
					\SEO_Article_Generator\Option_Registry::DOWNLOAD_DOMAIN_DENYLIST,
					\SEO_Article_Generator\Option_Registry::defaults()[ \SEO_Article_Generator\Option_Registry::DOWNLOAD_DOMAIN_DENYLIST ]
				)
			);
			$denylist = array();
			if ( $raw !== '' ) {
				foreach ( preg_split( '/\r?\n/', $raw ) as $line ) {
					$line = strtolower( trim( $line ) );
					if ( $line !== '' ) {
						$denylist[ $line ] = true;
					}
				}
			}
		}

		if ( ! empty( $denylist ) ) {
			// Exact match
			if ( isset( $denylist[ $host ] ) ) {
				return true;
			}
			// Subdomain match (e.g., tracking.prf.hn)
			foreach ( $denylist as $denied => $true ) {
				if ( $denied !== '' && substr( $host, -( strlen( '.' . $denied ) ) ) === '.' . $denied ) {
					return true;
				}
			}
		}

		// 2. Structural heuristic: affiliate-style paths on non-vendor, non-store domains
		// Pattern: no file extension + path contains /click/ /track/ /redirect/ /aff/ /go/ /visit/
		// AND host is NOT a trusted store or in the allowlist
		$path         = (string) parse_url( $url, PHP_URL_PATH );
		$has_file_ext = (bool) preg_match( '/\.(exe|msi|msix|msp|appx|dmg|pkg|apk|ipa|deb|rpm|appimage|zip|7z|tar\.gz|tgz|tar\.xz|tar\.bz2|sh|run|bin)(?:$|[?#])/i', $path );
		if ( ! $has_file_ext && preg_match( '#/(click|track|redirect|aff|go|visit|ref|out|jump|hop|offer|cmp|campaign|deep|link)/#i', $path ) ) {
			// Exempt trusted stores and vendor domains (via allowlist)
			$trusted_stores = array( 'play.google.com', 'apps.apple.com', 'itunes.apple.com', 'apps.microsoft.com' );
			if ( ! in_array( $host, $trusted_stores, true ) ) {
				// Check if host is in download allowlist — those are explicitly trusted
				$url_clean = rtrim( strtolower( trim( $url ) ), '/' );
				if ( ! self::is_allowlisted_url( $url_clean ) ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Check if a URL is in the admin-configured download allowlist.
	 *
	 * Supports two entry types:
	 * - Full URL (contains "://"): exact match against the normalized URL.
	 * - Bare domain (no "://"): matches against any URL on that host.
	 *
	 * The allowlist bypasses the homepage collision guard for software whose
	 * download URL legitimately equals the homepage (web apps, browser extensions).
	 *
	 * @MODIFIED 2026-04-22: Added for homepage collision guard bypass.
	 * @MODIFIED 2026-05-06: Added bare-domain host matching.
	 *
	 * @param string $url URL to check (already lowercase, trailing-slash-stripped).
	 * @return bool True if the URL or its host is in the allowlist.
	 */
	private static function is_allowlisted_url( $url ) {
		static $allowlist       = null;
		static $allowlist_hosts = null;
		if ( $allowlist === null ) {
			$raw             = trim(
				(string) \get_option(
					\SEO_Article_Generator\Option_Registry::DOWNLOAD_ALLOWLIST,
					\SEO_Article_Generator\Option_Registry::defaults()[ \SEO_Article_Generator\Option_Registry::DOWNLOAD_ALLOWLIST ]
				)
			);
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				error_log( '[DownloadLinkHelper] is_allowlisted_url: get_option raw=' . var_export($raw, true) . ' | option_key=' . \SEO_Article_Generator\Option_Registry::DOWNLOAD_ALLOWLIST );
			}
			$allowlist       = array();
			$allowlist_hosts = array();
			if ( $raw !== '' ) {
				foreach ( preg_split( '/\r?\n/', $raw ) as $line ) {
					$line = rtrim( strtolower( trim( $line ) ), '/' );
					if ( $line === '' ) {
						continue;
					}
					if ( strpos( $line, '://' ) === false ) {
						// Bare host (with optional path/query) — strip everything past the
						// first "/" so "vendor.com/track/foo" stores as the bare host
						// "vendor.com" and matches every URL on that host. This mirrors
						// the lookup at lines below which only reads PHP_URL_HOST.
						$host_only = strtolower( trim( (string) explode( '/', $line, 2 )[0] ) );
						if ( $host_only !== '' ) {
							$allowlist_hosts[ $host_only ] = true;
						}
					} else {
						$allowlist[ $line ] = true;
					}
				}
			}
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				error_log( '[DownloadLinkHelper] is_allowlisted_url: LOADED allowlist_hosts=' . implode(', ', array_keys($allowlist_hosts)) . ' | allowlist_urls=' . implode(', ', array_keys($allowlist)) );
			}
		}

		// 1. Exact URL match (legacy behavior)
		if ( isset( $allowlist[ $url ] ) ) {
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				error_log( '[DownloadLinkHelper] is_allowlisted_url: ALLOWED exact_url=' . $url );
			}
			return true;
		}

		// 2. Host match against bare-domain entries
		if ( ! empty( $allowlist_hosts ) ) {
			$host = strtolower( parse_url( $url, PHP_URL_HOST ) );
			if ( $host !== false && $host !== null && $host !== '' ) {
				if ( isset( $allowlist_hosts[ $host ] ) ) {
					if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
						error_log( '[DownloadLinkHelper] is_allowlisted_url: ALLOWED host=' . $host . ' for url=' . $url );
					}
					return true;
				}
				// Subdomain match: e.g. "dl.google.com" matches any subdomain
				foreach ( $allowlist_hosts as $allowed_host => $true ) {
					if ( substr( $host, -( strlen( '.' . $allowed_host ) ) ) === '.' . $allowed_host ) {
						if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
							error_log( '[DownloadLinkHelper] is_allowlisted_url: ALLOWED subdomain host=' . $host . ' matches allowed_host=' . $allowed_host . ' for url=' . $url );
						}
						return true;
					}
				}
			}
		}

		if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
			error_log( '[DownloadLinkHelper] is_allowlisted_url: NOT allowlisted url=' . $url . ' | allowlist_hosts=' . implode(', ', array_keys($allowlist_hosts)) . ' | allowlist_urls=' . implode(', ', array_keys($allowlist)) );
		}
		return false;
	}

	/**
	 * Public entry point for allowlist checks from outside this class.
	 *
	 * Accepts a raw URL (with or without scheme) and returns true if the URL
	 * or its host appears in the admin-configured download allowlist.
	 *
	 * @param string $url The URL to check.
	 * @return bool True if allowlisted (exact URL or matching host).
	 */
	public static function is_url_in_allowlist( $url ) {
		if ( ! is_string( $url ) || trim( $url ) === '' ) {
			return false;
		}
		$url_clean = rtrim( strtolower( trim( $url ) ), '/' );
		return self::is_allowlisted_url( $url_clean );
	}

	/**
	 * Infer platform from URL domain or file extension.
	 *
	 * @MODIFIED 2026-03-09: Standardized on macOS and expanded detection
	 *
	 * @param string $url Download URL
	 * @return string Platform name or empty string
	 */
	/** F1–F6: one classification contract for discovery, extracted and stored links.
	 * URL/own-anchor evidence beats legacy labels. No whole-post context, no ZIP=Windows.
	 * Other is an explicit unknown, not a claim that an archive is platform independent.
	 * file_type retains the existing UI vocabulary; extension is the actual suffix.
	 */
	public static function classify_record(array $link): array {
		$url = (string) ($link['url'] ?? '');
		$text = trim(wp_strip_all_tags((string) ($link['text'] ?? '')));
		$path = (string) parse_url($url, PHP_URL_PATH);
		$extension = '';
		if (preg_match('/\.([a-z0-9]+(?:\.[a-z0-9]+)?)$/i', basename($path), $m)) {
			$extension = strtolower($m[1]);
			if (!in_array($extension, array('tar.gz','tar.xz','tar.bz2'), true)) {
				$extension = strtolower(pathinfo($path, PATHINFO_EXTENSION));
			}
		}
		$platform = self::infer_platform_from_url($url);
		$evidence = $platform !== '' ? 'url' : 'unknown';
		// Only the resolver can provide a DOM-scoped local context. Never use legacy context.
		if (isset($link['classification_subject_url']) && $link['classification_subject_url'] !== $url) {
			unset($link['classification_version'], $link['classification_evidence'], $link['classification_support'], $link['classification_context']);
		}
		$local = (string) ($link['classification_context'] ?? '');
		$selector = self::selector_evidence($url, $text);
		if ($selector !== '') { $link['link_type'] = 'portal'; $link['download_evidence'] = $selector; }
		if ($platform === '') {
			foreach (array($text, $local) as $scope) {
				$hits = array();
				foreach (array(
					'Windows'=>'/\b(?:windows|win(?:32|64)|pc)\b/i',
					'macOS'=>'/\b(?:mac|macos|os\s*x|apple\s+(?:silicon|chip))\b/i',
					'Linux'=>'/\b(?:linux|ubuntu|debian|fedora|appimage)\b/i',
					'Android'=>'/\b(?:android|google\s+play)\b/i',
					'iOS'=>'/\b(?:ios|ipados|iphone|ipad)\b/i',
				) as $os=>$pattern) {
					if (preg_match($pattern, $scope)) $hits[] = $os;
				}
				if (count($hits) === 1) { $platform = $hits[0]; $evidence = 'local_text'; break; }
			}
		}
		if ($platform === '') {
			$old = self::normalize_platform_name((string) ($link['platform'] ?? ''));
			if (in_array($old, array('Windows','macOS','Linux','Android','iOS'), true)) {
				$platform = $old; $evidence = ($link['classification_version'] ?? 0) === 1 ? (string) ($link['classification_evidence'] ?? 'supplied') : 'supplied';
			}
		}
		$platform = $platform ?: 'Other';
		// Separators count as token boundaries (PHP \b does not split underscores).
		$url_tokens = str_replace('_', ' ', rawurldecode($path . ' ' . (string) parse_url($url, PHP_URL_QUERY)));
		$manual_variant = trim(wp_strip_all_tags((string) ($link['_manual_variant'] ?? '')));
		$direct = $url_tokens . ' ' . $text . ' ' . $manual_variant;
		$architecture = '';
		$arch_conflict = false;
		$chrome_msi = false;
		// Direct filename token priority for Edge ARM64 / Chrome variants — avoid false conflict from ambiguous text
		$basename_lower = strtolower(basename($path));
		if (preg_match('/arm64/', $basename_lower) && !preg_match('/x64/', $basename_lower)) {
			$architecture = 'ARM64'; $arch_conflict = false;
		} elseif (preg_match('/enterprise(64|_arm64)?\.msi$/i', basename($path))) {
			// Already handled by chrome_msi below; avoid double processing
		}
		if ($architecture === '') {
		foreach (array($url_tokens, $manual_variant, $text, $local) as $scope) {
			$hits = array();
			foreach (array(
				'ARM64'=>'/\b(?:arm64|aarch64)\b|apple\s+silicon/i',
				'x64'=>'/\b(?:x64|amd64|x86[- ]64|win64(?![- ](?:aarch64|arm64)))\b|\b64[- ]bit\b/i',
				'x32'=>'/\b(?:x86(?![- ]64)|i[3-6]86|ia32|win32)\b|\b32[- ]bit\b/i',
				'ARM'=>'/\b(?:arm(?!64)|armhf|armv7)\b/i',
				'Universal'=>'/\buniversal\b/i',
				'Intel'=>'/\bintel\b/i',
			) as $arch=>$pattern) {
				if (preg_match($pattern, $scope)) $hits[] = $arch;
			}
			if (in_array('Universal', $hits, true)) { $architecture = 'Universal'; break; }
			if (count($hits) === 1) { $architecture = $hits[0]; break; }
			if (count($hits) > 1) { $arch_conflict = true; break; }
		}
		$host = strtolower((string) parse_url($url, PHP_URL_HOST));
		$chrome_msi = self::host_is($host, 'dl.google.com') && preg_match('/^googlechromestandaloneenterprise(64|_arm64)?\.msi$/i', basename($path), $chrome_match);
		if ($chrome_msi) {
			$architecture = strtolower($chrome_match[1] ?? '') === '_arm64' ? 'ARM64' : (($chrome_match[1] ?? '') === '64' ? 'x64' : 'x32');
			$arch_conflict = false;
			}
		}
		$package = 'unknown';
		if (in_array($extension, array('msp','mst','delta'), true) || preg_match('/\b(?:patch|updater|update only)\b/i', $text) || preg_match('/(?:^|[-_.])(?:upd|update|patch)\d*/i', basename($path)) || preg_match('/Upd\d/i', basename($path))) {
			$package = 'updater';
		} elseif (preg_match('/\b(?:plugins?|add-?ons?|extensions?|language\s*pack)\b/i', $direct)) {
			$package = 'addon';
		} elseif (preg_match('/\b(?:source\s*(?:code|archive)|src)\b/i', $direct)) {
			$package = 'source';
		} elseif (preg_match('/\b(?:portable|no[- ]install)\b/i', $direct)) {
			$package = 'portable';
		} elseif (in_array($extension, array('exe','msi','msix','appx','dmg','pkg','deb','rpm','apk','ipa','appimage','snap','flatpak'), true) || preg_match('/\b(?:installer|setup)\b/i', $direct)) {
			$package = 'installer';
		} elseif (in_array($extension, array('zip','7z','rar','tar.gz','tar.xz','tar.bz2','tgz'), true)) {
			$package = 'archive';
		} elseif (self::infer_file_type_from_url($url) === 'store') {
			$package = 'store';
		} elseif (($link['link_type'] ?? '') === 'portal') {
			$package = 'portal';
		}
		$tokens = $chrome_msi ? array('Enterprise', 'Offline') : array();
		// Preserve supported edition/channel vocabulary but do not concatenate sibling variants.
		foreach (array('2go'=>'2Go','server'=>'Server','workstation'=>'Workstation','enterprise'=>'Enterprise','professional'=>'Professional','community'=>'Community','premium'=>'Premium','ultimate'=>'Ultimate','platinum'=>'Platinum','express'=>'Express','pro'=>'Pro','lite'=>'Lite','basic'=>'Basic','plus'=>'Plus','free'=>'Free','esr'=>'ESR','lts'=>'LTS','offline'=>'Offline','debug'=>'Debug','dch'=>'DCH','dc'=>'DC','minimalist'=>'Minimalist','quadro'=>'Quadro','business'=>'Business','trial'=>'Trial','education'=>'Education','educational'=>'Education','academic'=>'Academic','home'=>'Home','student'=>'Student','personal'=>'Personal','starter'=>'Starter','suite'=>'Suite','whql'=>'WHQL') as $token=>$label) {
			if (preg_match('/\b'.preg_quote($token, '/').'\b/i', $direct)) $tokens[] = $label;
		}
		if ($manual_variant !== '' && empty($tokens) && $architecture === '' && !preg_match('/\b(?:standard|installer|portable|updater|addon)\b/i', $manual_variant)) $tokens[] = self::normalize_variant_name($manual_variant);
		$forms = array('updater'=>'Updater','addon'=>'Addon','source'=>'Source','portable'=>'Portable','installer'=>'Installer');
		if (isset($forms[$package])) $tokens[] = $forms[$package];
		if ($architecture !== '') $tokens[] = $architecture;
		$channel = '';
		foreach (array('Nightly','Canary','Beta','Alpha','Preview','Dev','RC','Stable') as $c) {
			if (preg_match('/\b'.strtolower($c).'\b/i', $direct)) { $channel=$c; break; }
		}
		if ($channel !== '' && $channel !== 'Stable') $tokens[] = $channel;
		$link['platform'] = $platform;
		$link['variant'] = $tokens ? implode(' ', array_unique($tokens)) : 'Standard';
		$link['extension'] = $extension;
		$link['architecture'] = $architecture;
		$link['package_kind'] = $package;
		$link['channel'] = $channel;
		$link['classification_evidence'] = $evidence;
		$link['classification_status'] = ($platform === 'Other' || $arch_conflict || $evidence === 'supplied') ? 'needs_review' : 'classified';
		$link['architecture_conflict'] = $arch_conflict;
		$link['classification_version'] = 1;
		$link['classification_subject_url'] = $url;
		if ($evidence === 'matching_release_artifact' && empty($link['classification_support'])) $link['classification_status'] = 'needs_review';
		// Expose non-download intent and foreign-product recommendations (gaps 4,5,6 above)
		if (preg_match('/\b(?:changelog|what[-\s]?new|releases?\/tag\/|release[-\s]?notes?)\b/i', $direct) && !in_array($package, array('installer','archive','store','portable'), true)) {
			$link['download_intent'] = 'other-purpose';
		}
		if (preg_match('/\b(?:mpc[-\s]?be|black[-\s]?edition)\b/i', $text) && !preg_match('/\bmedia\s*player\s*classic[-\s]?home\b/i', $text)) {
			$link['foreign_product_warning'] = true;
		}
		if (!empty($link['foreign_product_warning']) || !empty($link['download_intent'])) $link['classification_status'] = 'needs_review';
		// Bare repo homepage guard: exclude github/source/repo pages with no direct file
		if ((preg_match('/github\.com\/[^\/]+$/i', $url) || preg_match('/sourceforge\.net\/[^\/]+$/i', $url)) && empty($extension)) {
			$link['download_intent'] = 'other-purpose';
			$link['classification_status'] = 'needs_review';
		}
		return $link;
	}

	/** Deterministic primary; never removes links. Auxiliary-only sets still get one primary. */
	public static function select_primary(array $links, bool $smart = true): array {
		$items = array();
		foreach ($links as $link) {
			if (is_string($link)) $link = array('url'=>$link);
			if (!is_array($link) || empty($link['url'])) continue;
			$link = self::classify_record($link);
			$link = array_merge(array('file_type'=>'','version'=>'','channel'=>'','text'=>''), $link);
			$items[] = $link;
		}
		$family = static function(array $row): string {
			$u = (string) $row['url']; $p = (string) parse_url($u, PHP_URL_PATH);
			$base = preg_replace('/\.(?:tar\.gz|tar\.xz|tar\.bz2|[a-z0-9]+)$/i', '', basename($p));
			$base = preg_replace('/(?:^|[._ -])(?:setup|installer|install|portable|x64|x86|arm64|aarch64)(?=[._ -]|$)/i', ' ', $base);
			$base = preg_replace('/[._ -]+/', '', $base);
			return strtolower((string) parse_url($u, PHP_URL_HOST)) . dirname($p) . '/' . $base;
		};
		$families = array();
		foreach ($items as $item) {
			if ($item['platform'] !== 'Other' && $item['classification_evidence'] === 'url' && $item['package_kind'] === 'installer') {
				$families[$family($item)][$item['platform']][] = $item['url'];
			}
		}
		foreach ($items as &$item) {
			$evidence = $families[$family($item)] ?? array();
			if (($item['platform'] === 'Other' || $item['classification_evidence'] === 'matching_release_artifact') && in_array($item['package_kind'], array('archive','portable'), true) && count($evidence) === 1) {
				$item['platform'] = (string) array_key_first($evidence);
				$item['classification_evidence'] = 'matching_release_artifact';
				$item['classification_support'] = $evidence[$item['platform']];
				sort($item['classification_support'], SORT_STRING);
				$item['classification_status'] = $item['architecture_conflict'] ? 'needs_review' : 'classified';
			}
		}
		unset($item);
		$rank = static function(array $link) use ($smart): array {
			$aux = in_array($link['package_kind'], array('updater','addon','source'), true) ? 1 : 0;
			$os = array('Windows'=>0,'macOS'=>1,'Linux'=>2,'Android'=>3,'iOS'=>4);
			$form = array('installer'=>0,'store'=>1,'portable'=>2,'archive'=>3,'portal'=>4,'unknown'=>5,'updater'=>6,'addon'=>7,'source'=>8);
			$arch = array('x64'=>0,''=>1,'Universal'=>1,'Intel'=>1,'x32'=>2,'ARM64'=>3,'ARM'=>4);
			$manual = (!$smart && (!empty($link['is_primary']) || !empty($link['isprimary']))) ? 0 : 1;
			$preview = in_array($link['channel'], array('Beta','Alpha','Nightly','Canary','Dev','Preview','RC'), true) ? 1 : 0;
			return array($aux, $manual, $os[$link['platform']] ?? 9, !empty($link['_continuity_existing']) ? 1 : 0, $preview, $form[$link['package_kind']] ?? 5, $arch[$link['architecture']] ?? 9, $link['url']);
		};
		usort($items, static function($a,$b) use ($rank) { return $rank($a) <=> $rank($b); });
		foreach ($items as $i=>&$link) { $link['is_primary'] = ($i === 0); unset($link['isprimary']); }
		unset($link);
		return $items;
	}

	public static function link_platforms(array $links): array {
		$found = array();
		foreach ($links as $link) {
			$p = (string) ($link['platform'] ?? '');
			if (in_array($p, array('Windows','macOS','Linux','Android','iOS'), true)) $found[$p] = true;
		}
		return array_values(array_intersect(array('Windows','macOS','Linux','Android','iOS'), array_keys($found)));
	}

	/** Reconcile partial Phase-1 results with ALL verified source links, not just one OS.
	 * Exact URL identity preserves mirrors, case-sensitive paths, query tokens and labels.
	 * No version substitution or speculative URL synthesis is performed.
	 */
	public static function reconcile_source_links(array $fresh, array $recovered): array {
		$links = array();
		$strength = static function(array $r): array {
			$evidence = array('url'=>3,'local_text'=>2,'matching_release_artifact'=>2,'supplied'=>1,'unknown'=>0);
			return array(empty($r['_continuity_existing']) ? 1 : 0, $evidence[$r['classification_evidence'] ?? 'unknown'] ?? 0,
				!empty($r['architecture']) && empty($r['architecture_conflict']) ? 1 : 0);
		};
		foreach (array($fresh, $recovered) as $group=>$rows) {
			foreach ($rows as $row) {
				if (!is_array($row) || empty($row['url']) || (isset($row['approved']) && !$row['approved'])) continue;
				$row = self::normalize_link($row, 'Other');
				if (!$row) continue; // Rejected records cannot reserve an identity.
				$key = $row['url'];
				if ($group === 1) $row['_recovered_from_source'] = true;
				if (isset($links[$key])) {
					$old = $links[$key];
					// Stronger independent evidence improves a duplicate. Phase-1 wins equal evidence;
					// a continuity-only row never outranks a current source row.
					$winner = $strength($row) > $strength($old) ? $row : $old;
					if (!empty($old['_bypass_homepage_guard']) || !empty($row['_bypass_homepage_guard'])) $winner['_bypass_homepage_guard'] = true;
					$links[$key] = $winner;
				} else $links[$key] = $row;
			}
		}
		return self::normalize_links(array_values($links), 'Other');
	}

	/** F7: same projection at every write boundary; fingerprints permit contract comparisons. */
	public static function trace_links(string $stage, array $before, array $after, $logger = null): void {
		$project = static function(array $rows): array {
			$result = array();
			foreach ($rows as $r) {
				if (!is_array($r)) continue;
				$entry = array();
				foreach (array('url','text','platform','variant','extension','architecture','package_kind','is_primary','classification_status','_recovered_from_source') as $field) {
					$entry[$field] = in_array($field, array('is_primary','_recovered_from_source'), true) ? !empty($r[$field]) : (string) ($r[$field] ?? '');
				}
				$result[] = $entry;
			}
			return $result;
		};
		$in = $project($before); $out = $project($after);
		$data = array('stage'=>$stage, 'input_count'=>count($in), 'output_count'=>count($out), 'fingerprint'=>hash('sha256', wp_json_encode($out)), 'removed_urls'=>array_values(array_diff(array_column($in,'url'),array_column($out,'url'))), 'links'=>$out);
		if ($logger === null && class_exists('\\SEO_Article_Generator\\Logger')) {
			static $contract_logger;
			if (!$contract_logger) $contract_logger = new \SEO_Article_Generator\Logger();
			$logger = $contract_logger;
		}
		if ($logger) $logger->info('Download contract', $data);
		elseif (defined('SEO_GEN_DEBUG_LINKS') && SEO_GEN_DEBUG_LINKS) error_log('[Download contract] '.wp_json_encode($data));
	}

	/** Positive selector evidence, independent of OS certainty. Never exempts hard guards. */
	public static function selector_evidence(string $url, string $text, string $software = ''): string {
		$host = strtolower((string) parse_url($url, PHP_URL_HOST));
		$path = (string) parse_url($url, PHP_URL_PATH);
		if ($host === 'github.com' && preg_match('~^/[^/]+/[^/]+/releases(?:/(?:latest|tag/[^/]+))?/?$~', $path)
			&& preg_match('/\b(?:download|releases?|other operating systems|binaries|installers?)\b/i', $text)) return 'release_selector';
		if (in_array($host, array('google.com','www.google.com'), true) && preg_match('/\bchrome\b/i', $text)) {
			parse_str((string) parse_url($url, PHP_URL_QUERY), $q);
			$platform = is_string($q['platform'] ?? null) ? $q['platform'] : '';
			if (in_array($path, array('/chrome/browser/','/chrome/next-steps.html'), true)
				&& in_array($platform, array('win','win32','win64','win_arm64','mac','linux'), true)) return 'vendor_platform_selector';
			if ($path === '/chrome/eula.html' && preg_match('/\b(?:web|installer|download)\b/i', $text)) return 'vendor_legacy_portal';
		}
		if (in_array($host, array('irfanview.com','www.irfanview.com'), true) && $path === '/arm64.htm'
			&& preg_match('/\birfanview\b/i',$text) && preg_match('/\b(?:windows|arm|arm64|64-bit)\b/i',$text)) return 'vendor_platform_selector';
		return '';
	}

	public static function manual_revision(array $links): string {
		$projection = array();
		foreach ($links as $r) {
			if (!is_array($r) || empty($r['url'])) continue;
			$projection[$r['url']] = array((string)($r['platform']??''),(string)($r['variant']??''),(string)($r['text']??''),!empty($r['is_primary']));
		}
		ksort($projection, SORT_STRING);
		return hash('sha256',wp_json_encode($projection));
	}

	public static function prepare_manual_links(array $rows, array $previous): array {
		$existing = array_column($previous, null, 'url'); $submitted = array();
		foreach ($rows as $row) {
			if (!is_array($row) || !is_string($row['url'] ?? null) || trim($row['url']) === '') continue;
			$url = html_entity_decode(trim($row['url']), ENT_QUOTES, 'UTF-8');
			$base = $existing[$url] ?? array('url'=>$url);
			foreach (array('text','platform','variant','file_type','version','channel','is_primary') as $field) {
				if (isset($row[$field]) && is_scalar($row[$field])) $base[$field] = $row[$field];
			}
			if (isset($row['_manual_variant']) && is_string($row['_manual_variant']) && $row['_manual_variant'] !== (string)($existing[$url]['variant'] ?? '')) $base['_manual_variant'] = $row['_manual_variant'];
			if (isset($existing[$url],$row['platform']) && $row['platform'] !== $existing[$url]['platform']) {
				unset($base['classification_context'],$base['classification_version'],$base['classification_evidence'],$base['classification_support']);
			}
			$submitted[] = $base;
		}
		return $submitted;
	}

	/** Fail closed on a late/stale job rather than writing a removed URL back. */
	public static function assert_manual_removals(array $links, int $post_id): void {
		if ($post_id > 0 && count(self::respect_manual_removals($links,$post_id)) !== count($links)) {
			throw new \RuntimeException('download_edit_conflict: payload includes manually removed URLs; refresh the source and regenerate, or explicitly re-add them in the link editor.');
		}
	}

	/** Also reject stale pre-rendered HTML; a correct DTO alone does not prove body parity. */
	public static function assert_manual_body(string $html, int $post_id, string $software = ''): void {
		if ($post_id <= 0 || $html === '') return;
		$state = get_post_meta($post_id, '_seo_gen_download_edits', true);
		if (!is_array($state) || empty($state['removed_urls'])) return;
		$scope = Download_Content::inspect($html, $software);
		$dom = new \DOMDocument(); $previous = libxml_use_internal_errors(true);
		try {
			$loaded = $dom->loadHTML('<meta charset="utf-8">'.($scope['found'] ? $scope['html'] : $html));
		} finally { libxml_clear_errors(); libxml_use_internal_errors($previous); }
		if (!$loaded) throw new \RuntimeException('download_edit_conflict: malformed publication HTML.');
		$urls = array(); foreach ($dom->getElementsByTagName('a') as $a) $urls[] = array('url'=>$a->getAttribute('href'));
		self::assert_manual_removals($urls,$post_id);
	}

	/** Tombstones suppress accepted removals, not new-version source URLs. */
	public static function respect_manual_removals(array $links, int $post_id): array {
		$edits = get_post_meta($post_id, '_seo_gen_download_edits', true);
		$removed = is_array($edits) ? array_fill_keys((array)($edits['removed_urls'] ?? array()), true) : array();
		return array_values(array_filter($links, static function($r) use ($removed) { return !isset($removed[$r['url'] ?? '']); }));
	}

	private static function host_is(string $host, string $domain): bool {
		return $host === $domain || substr($host, -strlen('.'.$domain)) === '.'.$domain;
	}

	public static function infer_platform_from_url( $url ) {
		if ( ! is_string( $url ) || trim( $url ) === '' ) {
			return '';
		}

		$normalized_url = strtolower( $url );
		$host           = (string) parse_url( $normalized_url, PHP_URL_HOST );
		$path           = (string) parse_url( $normalized_url, PHP_URL_PATH );

		// Extension-based detection (Tier 1: Most reliable for direct links)
		if ( preg_match( '/\.(exe|msi|msix|msp|appx)(?:$|\?)/i', $path ) ) {
			return 'Windows';
		}
		if ( preg_match( '/\.(dmg|pkg)(?:$|\?)/i', $path ) ) {
			return 'macOS';
		}

		if ( preg_match( '/\.ipa$/i', $path ) ) return 'iOS';
		if ( preg_match( '/\.(apk)(?:$|\?)/i', $path ) ) {
			return 'Android';
		}

		if ( preg_match( '/\.(appimage|deb|rpm|snap|flatpak)(?:$|\?)/i', $path ) ) {
			return 'Linux';
		}

		// Tier 1.2: Path/Query keyword detection (resolves ambiguity for ZIP/pages)
		$query = (string) parse_url( $normalized_url, PHP_URL_QUERY );
		if ( $query !== '' ) {
			if ( preg_match( '/(?:^|&)(?:platform|os)=(win(?:32|64|_arm64)?|windows|pc)\b/i', $query ) ) {
				return 'Windows';
			}
			if ( preg_match( '/(?:^|&)(?:platform|os)=(mac|macos|osx|osx-api|ios-mac)\b/i', $query ) ) {
				return 'macOS';
			}
			if ( preg_match( '/(?:^|&)(?:platform|os)=(linux|ubuntu|debian)\b/i', $query ) ) {
				return 'Linux';
			}
			if ( preg_match( '/(?:^|&)(?:platform|os)=android\b/i', $query ) ) {
				return 'Android';
			}
			if ( preg_match( '/(?:^|&)(?:platform|os)=ios\b/i', $query ) ) {
				return 'iOS';
			}
		}

		// Also check path keywords
		if ( preg_match( '/[-_\/]linux(?:64|32)?[-_\.\/]/i', $path ) || preg_match( '/[-_]linux$/i', pathinfo( $path, PATHINFO_FILENAME ) ) ) {
			return 'Linux';
		}
		if ( preg_match( '/[-_\/](?:mac|macos|osx|apple)(?:[-_\.\/]|$)/i', $path ) || preg_match( '/[-_](?:mac|macos|osx)$/i', pathinfo( $path, PATHINFO_FILENAME ) ) ) {
			return 'macOS';
		}
		if ( preg_match( '/[-_\/](?:windows|win(?:32|64)?|pc)(?:[-_\.\/]|$)/i', $path ) || preg_match( '/[-_]windows$/i', pathinfo( $path, PATHINFO_FILENAME ) ) ) {
			return 'Windows';
		}
		if ( preg_match( '/[-_\/]android[-_\.\/]/i', $path ) || preg_match( '/[-_]android$/i', pathinfo( $path, PATHINFO_FILENAME ) ) ) {
			return 'Android';
		}
		if ( preg_match( '/[-_\/]ios[-_\.\/]/i', $path ) || preg_match( '/[-_]ios$/i', pathinfo( $path, PATHINFO_FILENAME ) ) ) {
			return 'iOS';
		}

		// Archives do not identify an OS. Preserve uncertainty.

		if (self::host_is($host, 'portableapps.com')) return 'Windows';

		// Domain-based detection (Tier 2: Source portals)
		if ( self::host_is($host, 'apps.apple.com') || self::host_is($host, 'itunes.apple.com') ) {
			return 'iOS';
		}

		if ( self::host_is($host, 'play.google.com') ) {
			return 'Android';
		}

		if ( self::host_is($host, 'apps.microsoft.com') ) {
			return 'Windows';
		}

		if ( self::host_is($host, 'commerce.adobe.com') ) {
			return 'Windows';
		}

		if ( self::host_is($host, 'snapcraft.io') || self::host_is($host, 'flathub.org') ) {
			return 'Linux';
		}

		return '';
	}

	/**
	 * Normalize variant name to canonical form.
	 *
	 * @MODIFIED 2026-03-09: Using improved mapping from proposed patch
	 *
	 * @param string $variant Raw variant
	 * @return string Normalized variant name
	 */
	public static function normalize_variant_name( $variant ) {
		$variant = trim( (string) $variant );
		if ( $variant === '' ) {
			return 'Standard';
		}

		$map = array(
			'64-bit'           => 'x64',
			'64 bit'           => 'x64',
			'64bit'            => 'x64',
			'64_bit'           => 'x64',
			'x64'              => 'x64',
			'amd64'            => 'x64',
			'win64'            => 'x64',
			'32-bit'           => 'x32',
			'32 bit'           => 'x32',
			'32bit'            => 'x32',
			'32_bit'           => 'x32',
			'x86'              => 'x32',
			'win32'            => 'x32',
			'i686'             => 'x32',
			'i386'             => 'x32',
			'arm64'            => 'ARM64',
			'aarch64'          => 'ARM64',
			'arm'              => 'ARM',
			'mac'              => 'Intel', // @MODIFIED 2026-05-21: Firefox .mac.pkg = Intel macOS
			'portable'         => 'Portable',
			'portable version' => 'Portable',
			'intel'            => 'Intel',
			'universal'        => 'Universal',
			'standard'         => 'Standard',
			'x86_64'           => 'x64',
			'esr'              => 'ESR',
			'lts'              => 'LTS',
			'pro'              => 'Pro',
			'lite'             => 'Lite',
			'community'        => 'Community',
			'enterprise'       => 'Enterprise',
			'premium'          => 'Premium',
			'ultimate'         => 'Ultimate',
			'professional'     => 'Professional',
			'trial'            => 'Trial',
			'plus trial'       => 'Plus Trial',
			'premium trial'    => 'Premium Trial',
			'platinum trial'   => 'Platinum Trial',
			'beta'             => 'Beta',
			'alpha'            => 'Alpha',
			'rc'               => 'RC',
			'preview'          => 'Preview',
			'canary'           => 'Canary',
			'nightly'          => 'Nightly',
			'dev'              => 'Dev',
			'stable'           => 'Stable',
			'basic'            => 'Basic',
			'free'             => 'Free',
			'suite'            => 'Suite',
			'plus'             => 'Plus',
			'max'              => 'Max',
			'mini'             => 'Mini',
			'home'             => 'Home',
			'express'          => 'Express',
			// @MODIFIED 2026-05-02: Added 'platinum' to sync with normalize_variant_label() map.
			'platinum'         => 'Platinum',
			'server'           => 'Server',
			'workstation'      => 'Workstation',
			'2go'              => '2Go',
			'offline'          => 'Offline',
			'debug'            => 'Debug',
			'dch'              => 'DCH',
			'dc'               => 'DC',
			'minimalist'       => 'Minimalist',
			'installer'        => 'Installer',
			'whql'             => 'WHQL',
			'quadro'           => 'Quadro',
			'business'         => 'Business',
			// @ADDED 2026-05-21: Missing architecture/education variants from audit
			'education'        => 'Education',
			'educational'      => 'Education',
			'academic'         => 'Academic',
			'home student'     => 'Home Student',
			'student'          => 'Student',
			'personal'         => 'Personal',
			'starter'          => 'Starter',
			'basic edition'    => 'Basic',
			'free edition'     => 'Free',
			'home edition'     => 'Home',
		);

		$key = strtolower( $variant );
		if ( isset( $map[ $key ] ) ) {
			return $map[ $key ];
		}

		// ARM64 falls back to custom logic if not in map
		if ( strpos( $key, 'apple silicon' ) !== false || preg_match( '/\bm[1-4]\b/i', $variant )
		) {
			return 'ARM64';
		}

		// @MODIFIED 2026-05-02: Preserve known lowercase architecture prefixes in composed
		// variants (e.g. "x64 Portable", "x86 ESR") — ucwords would produce "X64 Portable".
		// @MODIFIED 2026-05-07: Guard against architecture prefix duplicating a token
		// inside the suffix. e.g. "x64 Professional x64" would split into prefix="x64"
		// and suffix="Professional x64" — normalize_variant_label dedupes WITHIN the
		// suffix but NOT against the prefix. Strip prefix from suffix if present.
		// @MODIFIED 2026-05-13: Map prefix through canonical map so 'x86' becomes 'x32'.
		if ( preg_match( '/^(x64|x86|arm64|arm|intel|universal)\s+(.+)$/i', $variant, $cm ) ) {
			$prefix_lower     = strtolower( $cm[1] );
			$prefix_canonical = isset( $map[ $prefix_lower ] ) ? $map[ $prefix_lower ] : $prefix_lower;
			$suffix_lower     = strtolower( trim( $cm[2] ) );
			if ( preg_match( '/^(x64|x86|arm64|arm|intel|universal)$/i', $suffix_lower ) ) {
				$suffix_canonical = isset( $map[ $suffix_lower ] ) ? $map[ $suffix_lower ] : $suffix_lower;
				if ( $suffix_canonical === $prefix_canonical ) {
					return $prefix_canonical;
				}
				return $prefix_canonical . ' ' . $suffix_canonical;
			}
			$suffix        = self::normalize_variant_label( $cm[2] );
			$suffix_tokens = preg_split( '/\s+/', $suffix );
			$cleaned       = array();
			foreach ( $suffix_tokens as $st ) {
				if ( strtolower( $st ) === $prefix_canonical ) {
					continue;
				}
				$cleaned[] = $st;
			}
			$suffix = implode( ' ', $cleaned );
			if ( $suffix === '' ) {
				return $prefix_canonical;
			}
			return $prefix_canonical . ' ' . $suffix;
		}
		return self::normalize_variant_label( $variant );
	}

	/**
	 * Normalize platform name to canonical form.
	 *
	 * @MODIFIED 2026-03-09: Standardized to macOS and using CANONICAL_PLATFORM_MAP
	 *
	 * @param string $platform Raw platform name
	 * @return string Normalized platform name
	 */
	public static function normalize_platform_name( $platform, $url = '' ) {
		$platform = trim( (string) $platform );
		if ($platform === '' || strcasecmp($platform, 'Portable') === 0) {
			return $url !== '' ? (self::infer_platform_from_url($url) ?: 'Other') : 'Other';
		}

		$key = strtolower( $platform );
		$key = str_replace( array( '-', '_' ), ' ', $key );
		$key = preg_replace( '/\s+/', ' ', $key );
		$key = trim( $key );

		// 1. GOD MODE: Prioritize official stores over labels
		$inferred = '';
		if ( ! empty( $url ) ) {
			$inferred        = self::infer_platform_from_url( $url );
			$is_strong_store = ( strpos( $url, 'play.google.com' ) !== false || strpos( $url, 'apps.apple.com' ) !== false );

			if ( $is_strong_store && $inferred !== '' ) {
				return $inferred;
			}
		}

		// 2. Exact match in canonical platform map
		if ( isset( self::CANONICAL_PLATFORM_MAP[ $key ] ) ) {
			return self::CANONICAL_PLATFORM_MAP[ $key ];
		}

		// 3. Substring matching of known platform keywords in the raw string
		if ( strpos( $key, 'linux' ) !== false ) {
			return 'Linux';
		}
		if ( strpos( $key, 'mac' ) !== false || strpos( $key, 'osx' ) !== false || strpos( $key, 'os x' ) !== false ) {
			return 'macOS';
		}
		if ( strpos( $key, 'android' ) !== false ) {
			return 'Android';
		}
		if ( strpos( $key, 'ios' ) !== false || strpos( $key, 'iphone' ) !== false || strpos( $key, 'ipad' ) !== false ) {
			return 'iOS';
		}
		if ( strpos( $key, 'win' ) !== false || strpos( $key, 'pc' ) !== false || strpos( $key, 'windows' ) !== false ) {
			return 'Windows';
		}

		// 4. Split compound platform strings
		if ( strpos( $platform, ';' ) !== false || strpos( $platform, ',' ) !== false || strpos( $platform, '/' ) !== false || strlen( $platform ) > 30 ) {
			$first_token = preg_split( '/[;,\/]/', $platform )[0];
			$first_token = trim( $first_token );

			if ( $first_token !== $platform ) {
				$normalized_token = self::normalize_platform_name( $first_token, $url );
				if ( $normalized_token !== 'Other' ) {
					return $normalized_token;
				}
			}
		}

		// 5. Fallback to inferred platform from URL if available
		if ( empty( $inferred ) && ! empty( $url ) ) {
			$inferred = self::infer_platform_from_url( $url );
		}
		if ( ! empty( $inferred ) ) {
			return $inferred;
		}

		return ucfirst( $platform );
	}

	/**
	 * Build a unique identity tuple for a download link.
	 * Two links with the same identity = same button = duplicate.
	 *
	 * @since 2.31.0
	 * @param array $link
	 * @return string
	 */
	public static function build_link_identity( array $link ) {
		$platform  = strtolower( $link['platform'] ?? 'windows' );
		$variant   = strtolower( $link['variant'] ?? 'standard' );
		$file_type = strtolower( $link['file_type'] ?? '' );
		return "{$platform}|{$variant}|{$file_type}";
	}

	/**
	 * Decode CDN URL patterns for platform/variant keywords.
	 *
	 * @since 2.31.0
	 * @param string $url
	 * @return array Array with keys 'platform' and 'variant'
	 */
	public static function decode_cdn_parameters( $url ) {
		$result = array( 'platform' => '', 'variant' => '' );
		if ( empty( $url ) ) {
			return $result;
		}

		$url_lower = strtolower( $url );

		// 1. Avast/AVG CDN: bits.avcdn.net / avcdn.net
		if ( strpos( $url_lower, 'avcdn.net' ) !== false ) {
			if ( strpos( $url_lower, 'platform_win' ) !== false ) {
				$result['platform'] = 'Windows';
			} elseif ( strpos( $url_lower, 'platform_mac' ) !== false ) {
				$result['platform'] = 'macOS';
			}
			if ( strpos( $url_lower, 'insttype_free' ) !== false ) {
				$result['variant'] = 'Free';
			}
			// Look for offline setup
			if ( strpos( $url_lower, '_setup_offline' ) !== false ) {
				$result['variant'] = 'Offline';
			} elseif ( strpos( $url_lower, '_setup_online' ) !== false ) {
				$result['variant'] = 'Online';
			}
		}

		// 2. Adobe CDN
		if ( strpos( $url_lower, 'adobe.com' ) !== false ) {
			if ( strpos( $url_lower, '/osx/' ) !== false || strpos( $url_lower, '/mac/' ) !== false || strpos( $url_lower, 'dmg' ) !== false ) {
				$result['platform'] = 'macOS';
			} elseif ( strpos( $url_lower, '/win/' ) !== false || strpos( $url_lower, 'exe' ) !== false || strpos( $url_lower, 'msi' ) !== false ) {
				$result['platform'] = 'Windows';
			}
		}

		// 3. Microsoft CDN
		if ( strpos( $url_lower, 'microsoft.com' ) !== false ) {
			if ( strpos( $url_lower, 'windowsserver' ) !== false ) {
				$result['platform'] = 'Windows Server';
			}
		}

		return $result;
	}

	/**
	 * Normalize a single download link.
	 *
	 * @MODIFIED 2026-03-09: Integrated is_valid_download_url() and improved platform fallback
	 * @MODIFIED 2026-04-22: Added $homepage parameter — rejects links whose URL resolves
	 * to the software homepage (AI fallback for missing portable links).
	 * @MODIFIED 2026-05-23: Added $software_name parameter and CDN parameter decoding.
	 *
	 * @param array  $link            Raw link data
	 * @param string $fallback_platform Platform to use if none can be detected
	 * @param string $homepage        Software homepage URL to guard against (optional)
	 * @param string $software_name   Software name (optional)
	 * @return array|null Normalized link or null if invalid
	 */
	public static function normalize_link( $link, $fallback_platform = 'Windows', $homepage = '', $software_name = '', $changelogurl = '' ) {
		if (is_string($link)) $link = array('url'=>trim($link));
		$input_url = is_array( $link ) ? ( $link['url'] ?? '' ) : (string) $link;
		if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
			error_log( '[DownloadLinkHelper] normalize_link: PROCESSING url=' . $input_url . ' | homepage=' . $homepage . ' | software=' . $software_name );
		}
		if ( ! is_array( $link ) ) {
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				error_log( '[DownloadLinkHelper] normalize_link REJECTED: input is not an array | url=' . $input_url );
			}
			return null;
		}

		$url = isset( $link['url'] ) ? trim( (string) $link['url'] ) : '';
		$url = html_entity_decode( $url, ENT_QUOTES, 'UTF-8' );


		if ( ! self::is_valid_download_url( $url ) ) {
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				error_log( sprintf(
					'[DownloadLinkHelper] normalize_link REJECTED: url=%s | reason=is_valid_download_url=false | software=%s',
					$url, $software_name
				) );
			}
			return null;
		}

		if (self::is_affiliate_url($url)) return null;
		if (array_key_exists('approved', $link) && !$link['approved']) return null;
		$source_text = (string) ($link['text'] ?? '');
		$allowlisted = self::is_url_in_allowlist($url);
		$path_check = (string) parse_url($url, PHP_URL_PATH);
		$host_check = strtolower((string) parse_url($url, PHP_URL_HOST));
		if (!$allowlisted && (preg_match('/\b(?:brief review|release notes|home\s*page|website)\b/i', $source_text) || strpos($host_check, 'blog.') === 0)) return null;

		if (!$allowlisted && preg_match('~/(?:changelog|release-?notes|history|pricing|checkout|documentation)(?:[./]|$)~i', $path_check)) return null;
		if (!$allowlisted && preg_match('/^(?:homepage|home page|official (?:page|site|website)|release notes|changelog)$/i', trim($source_text))) return null;

		// HOMEPAGE COLLISION GUARD (2026-04-22)
		// Reject any link whose URL (stripped of trailing slash) matches the homepage,
		// UNLESS the URL is in the admin-configured download allowlist
		// OR the link is a portal fallback injected by Discovery_Processor for Link Continuity
		// OR the link is a canonical source link marked with _bypass_homepage_guard.
		if ( ! empty( $homepage ) ) {
			$url_clean      = rtrim( strtolower( trim( $url ) ), '/' );
			$homepage_clean = rtrim( strtolower( trim( (string) $homepage ) ), '/' );
			if ( $homepage_clean !== '' && $url_clean === $homepage_clean ) {
				$is_portal_fallback      = ! empty( $link['_portal_fallback'] );
				$is_canonical_bypass     = ! empty( $link['_bypass_homepage_guard'] );
				if ( ! self::is_allowlisted_url( $url_clean ) && ! $is_portal_fallback && ! $is_canonical_bypass ) {
					if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
						error_log( sprintf(
							'[DownloadLinkHelper] normalize_link REJECTED: url=%s | reason=homepage_collision | homepage=%s | software=%s',
							$url, $homepage, $software_name
						) );
					}
					return null;
				}
			}
		}

		// CHANGELOG COLLISION GUARD (2026-05-24)
		if ( ! empty( $changelogurl ) ) {
			$url_clean       = rtrim( strtolower( trim( $url ) ), '/' );
			$changelog_clean = rtrim( strtolower( trim( (string) $changelogurl ) ), '/' );
			if ( $changelog_clean !== '' && $url_clean === $changelog_clean ) {
				$is_portal_fallback  = ! empty( $link['_portal_fallback'] );
				$is_canonical_bypass = ! empty( $link['_bypass_homepage_guard'] );
				if ( ! self::is_allowlisted_url( $url_clean ) && ! $is_portal_fallback && ! $is_canonical_bypass ) {
					if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
						error_log( sprintf(
							'[DownloadLinkHelper] normalize_link REJECTED: url=%s | reason=changelog_collision | changelog=%s | software=%s',
							$url, $changelogurl, $software_name
						) );
					}
					return null;
				}
			}
		}

		// REPO PAGE GUARD — FIX F13 (Phase 3A): the manual-entry path already
		// rejected bare repo URLs via is_binary_link_url(), but AI-supplied
		// links were only checked for placeholders, so github/gitlab/etc.
		// project pages (no download signal) reached the article as "download
		// links". Reject them here too, honoring the same bypass flags as the
		// homepage/changelog guards (canonical links from Link_Resolver carry
		// real signals and are allowlisted or flagged _bypass_homepage_guard).
		{
			$url_for_repo_check = rtrim( strtolower( trim( $url ) ), '/' );
			if ( $url_for_repo_check !== '' && self::is_repo_page_url( $url_for_repo_check ) ) {
				$is_portal_fallback  = ! empty( $link['_portal_fallback'] );
				// FIX 7.2: _bypass_homepage_guard must NOT bypass repo page rejection.
				// That flag was designed for the homepage/changelog domain guard only.
				// Bare repo pages (github.com/owner/repo) are NEVER valid download links
			// regardless of where they came from. Only _portal_fallback (injected by
			// the system as last-resort) and the admin allowlist can override this.
				if ( ! self::is_allowlisted_url( $url_for_repo_check ) && ! $is_portal_fallback ) {
					if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
						error_log( sprintf(
							'[DownloadLinkHelper] normalize_link REJECTED: url=%s | reason=bare_repo_page | software=%s',
							$url, $software_name
						) );
					}
					return null;
				}
			}
		}

		$link = self::classify_record(array_merge($link, array('url'=>$url)));
		$platform = $link['platform'];
		$variant = $link['variant'];
		$url_extracted = self::extract_version_from_url($url, (string) ($link['text'] ?? ''), $software_name);

		$version = isset( $link['version'] ) ? trim( (string) $link['version'] ) : '';
		if ( $version === '' && ( ! empty( $url ) || ! empty( $link_text_for_extract ) ) ) {
			if ( $url_extracted === null ) {
				$url_extracted = self::extract_version_from_url( $url, $link_text_for_extract, $software_name );
			}
			$version = $url_extracted;
			if ( preg_match( '/(\d+(?:\.\d+)+)(?=[^0-9.]|$)/', $version, $vm ) ) {
				$version = $vm[1];
			} elseif ( preg_match( '/(\d{4,})\b/', $version, $vm ) ) {
				$version = $vm[1];
			} elseif ( ! preg_match( '/^\d/', $version ) ) {
				$version = '';
			}
		}
		$channel = isset( $link['channel'] ) ? trim( (string) $link['channel'] ) : '';

		$text = isset( $link['text'] ) ? trim( wp_strip_all_tags( (string) $link['text'] ) ) : '';

		// @MODIFIED 2026-05-02: Delegated to infer_file_type_from_url() — single mapping table (GAP 7).
		// URL-based inference ALWAYS wins over AI-provided file_type when URL has a recognizable extension.
		// AI file_type is only used when the URL has no recognizable extension (portal/redirect URLs).
		$file_type = self::infer_file_type_from_url( $url );
		if ( empty( $file_type ) && ! empty( $link['file_type'] ) ) {
			$file_type = sanitize_text_field( (string) $link['file_type'] );
		}

		$return_url = esc_url_raw( $url );
		if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
			error_log( '[DownloadLinkHelper] normalize_link: ACCEPTED url=' . $return_url . ' | platform=' . $platform . ' | variant=' . $variant . ' | file_type=' . $file_type . ' | is_primary=' . (!empty($link['is_primary']) ? 'yes' : 'no') . ' | software=' . $software_name );
		}
		return array_merge($link, array(
			'platform'         => $platform,
			'variant'          => $variant,
			'file_type'        => $file_type,
			'version'          => $version,
			'channel'          => $channel,
			'text'             => $text,
			'url'              => $return_url,
			'is_primary'       => ! empty( $link['is_primary'] ),
			'_portal_fallback' => ! empty( $link['_portal_fallback'] ),
		));
	}


	/**
	 * Validate a link record (alias for normalize_link for validator usage).
	 *
	 * @since 2.27.0
	 * @MODIFIED 2026-04-22: Signature updated to match normalize_link's $homepage parameter.
	 * @MODIFIED 2026-05-23: Propagated $software_name.
	 */
	public static function validate_link_record( array $link, $fallback_platform = 'Windows', $homepage = '', $software_name = '', $changelogurl = '' ) {
		return self::normalize_link( $link, $fallback_platform, $homepage, $software_name, $changelogurl );
	}

	/**
	 * Check if an array has at least one valid download link.
	 *
	 * @since 2.27.0
	 */
	public static function has_valid_download( $links ) {
		foreach ( (array) $links as $link ) {
			if ( ! is_array( $link ) ) {
				continue;
			}
			$url = isset( $link['url'] ) ? $link['url'] : '';
			if ( self::is_valid_download_url( $url ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Find the primary or first valid download URL from an array of links.
	 *
	 * @since 2.27.0
	 */
	public static function find_primary_download_url( $links ) {
		$fallback = '';
		foreach ( (array) $links as $link ) {
			if ( ! is_array( $link ) || empty( $link['url'] ) ) {
				continue;
			}
			$url = trim( (string) $link['url'] );
			if ( ! self::is_valid_download_url( $url ) ) {
				continue;
			}
			if ( ! empty( $link['is_primary'] ) ) {
				return $url;
			}
			if ( $fallback === '' ) {
				$fallback = $url;
			}
		}
		return $fallback;
	}

    /**
     * Normalize an array of download links.
	 * Rejects invalid/placeholder URLs, deduplicates, and ensures exactly one primary.
	 *
	 * @MODIFIED 2026-03-09: Enforces canonical platform names on fallback
	 * @MODIFIED 2026-04-22: Added $homepage parameter — propagated to normalize_link()
	 * to reject homepage-as-download AI hallucinations at source.
	 * @MODIFIED 2026-05-23: Added $software_name parameter.
	 *
	 * @param array  $links            Raw links array
	 * @param string $fallback_platform Platform to use if none can be detected
	 * @param string $homepage         Software homepage URL. Links matching it are dropped.
	 * @param string $software_name    Software name.
	 * @param string $changelogurl     Changelog URL. Links matching it are dropped.
	 * @return array Normalized, deduplicated, validated links
	 */
	public static function normalize_links( $links, $fallback_platform = 'Windows', $homepage = '', $software_name = '', $changelogurl = '' ) {
		$fallback_platform = self::normalize_platform_name( $fallback_platform );
		$clean             = array();
		$seen              = array();
		$dropped_reasons  = array();

		if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
			error_log( '[DownloadLinkHelper] normalize_links: BATCH START input=' . count( (array) $links ) . ' | homepage=' . $homepage . ' | software=' . $software_name );
			foreach ( (array) $links as $_idx => $_link ) {
				$_url = is_array( $_link ) ? ( $_link['url'] ?? '' ) : (string) $_link;
				error_log( '[DownloadLinkHelper] normalize_links:   INPUT[' . $_idx . '] url=' . $_url );
			}
		}

		foreach ( (array) $links as $link ) {
			$input_url = is_array( $link ) ? ( $link['url'] ?? '' ) : (string) $link;
			$normalized = self::normalize_link( $link, $fallback_platform, $homepage, $software_name, $changelogurl );
			if ( ! $normalized ) {
				if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
					$dropped_reasons[] = $input_url ?: '(empty)';
					error_log( '[DownloadLinkHelper] normalize_links:   DROPPED url=' . $input_url . ' | reason=normalize_link_returned_null');
				}
				continue;
			}

			$key = $normalized['url'];
			if ( isset( $seen[ $key ] ) ) {
				if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
					$dropped_reasons[] = $normalized['url'] . ' (duplicate)';
					error_log( '[DownloadLinkHelper] normalize_links:   DROPPED url=' . $input_url . ' | reason=duplicate (key=' . $key . ')');
				}
				continue;
			}

			// Architecture conflicts are corrected/flagged by classify_record; never drop a real URL for a label error.
			$clean[]      = $normalized;
			$seen[ $key ] = true;
			if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
				error_log( '[DownloadLinkHelper] normalize_links:   ACCEPTED url=' . $normalized['url'] . ' | platform=' . ( $normalized['platform'] ?? '' ) . ' | variant=' . ( $normalized['variant'] ?? '' ) );
			}
		}

		// Log homepage-collision rejections if any links were dropped.
		if ( ! empty( $homepage ) ) {
			$dropped = count( (array) $links ) - count( $clean );
			if ( $dropped > 0 ) {
				error_log(
					sprintf(
						'[DownloadLinkHelper] Validation/deduplication removed %d link(s). Homepage context: %s',
						$dropped,
						$homepage
					)
				);
			}
		}

		// DIAGNOSTIC: Log batch summary
		if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
			$total_in  = count( (array) $links );
			$total_out = count( $clean );
			error_log( sprintf(
				'[DownloadLinkHelper] normalize_links: input=%d | output=%d | dropped=%d | software=%s',
				$total_in, $total_out, $total_in - $total_out, $software_name
			) );
			if ( ! empty( $dropped_reasons ) ) {
				error_log( '[DownloadLinkHelper] DROPPED URLS: ' . implode( ' | ', $dropped_reasons ) );
			}
		}

		if ( ! empty( $clean ) ) {
			// @MODIFIED 2026-05-02: GAP 6 — Pass smart_windows_default=true for consistent primary selection.
			$clean = self::select_primary($clean, true);
		}
		return array_values( $clean );
	}

	/**
	 * Get the primary link from a normalized links array.
	 *
	 * @MODIFIED 2026-03-08: Added for consistent primary link retrieval
	 *
	 * @param array $links Normalized links array
	 * @return array|null Primary link or null
	 */
	public static function get_primary_link( $links ) {
		foreach ( (array) $links as $link ) {
			if ( ! empty( $link['is_primary'] ) ) {
				return $link;
			}
		}

		return ! empty( $links[0] ) ? $links[0] : null;
	}

	/**
	 * Group download links by platform.
	 * Preserves first-seen platform order instead of forcing a hardcoded order.
	 *
	 * @MODIFIED 2026-03-08: Cleaned up dead commented-out ordering code
	 *
	 * @param array $links Array of download link data
	 * @return array Grouped links: platform => array of links
	 */
	public static function group_links_by_platform( $links ) {
		$grouped        = array();
		$platform_order = array();

		foreach ( (array) $links as $link ) {
			if ( ! is_array( $link ) ) {
				continue;
			}

			$url      = isset( $link['url'] ) ? (string) $link['url'] : '';
			$platform = isset( $link['platform'] ) ? self::normalize_platform_name( $link['platform'], $url ) : 'Other';

			if ( ! isset( $grouped[ $platform ] ) ) {
				$grouped[ $platform ] = array();
				$platform_order[]     = $platform;
			}

			$grouped[ $platform ][] = $link;
		}

		$ordered = array();

		foreach ( $platform_order as $platform ) {
			$ordered[ $platform ] = self::sort_links_by_variant( $grouped[ $platform ] );
		}

		$priority = array(
			'Windows' => 0,
			'macOS'   => 1,
			'Linux'   => 2,
			'Android' => 3,
			'iOS'     => 4,
		);

		uksort(
			$ordered,
			function ( $a, $b ) use ( $priority ) {
				$p_a = isset( $priority[ $a ] ) ? $priority[ $a ] : 999;
				$p_b = isset( $priority[ $b ] ) ? $priority[ $b ] : 999;

				if ( $p_a !== $p_b ) {
					return $p_a - $p_b;
				}

				return strcasecmp( $a, $b );
			}
		);

		return $ordered;
	}

	/**
	 * Sort links by variant priority.
	 * Primary links first, then x64, x86, ARM64, ARM, Universal, Intel, Portable, Standard.
	 *
	 * @MODIFIED 2026-03-08: Added is_primary first-sort, expanded variant priority map
	 *
	 * @param array $platform_links Links for a specific platform
	 * @return array Sorted links
	 */
	public static function sort_links_by_variant( $platform_links ) {
		usort(
			$platform_links,
			function ( $a, $b ) {
				// @MODIFIED 2026-03-08: Primary links always sort first
				$primary_a = ! empty( $a['is_primary'] ) ? 0 : 1;
				$primary_b = ! empty( $b['is_primary'] ) ? 0 : 1;

				if ( $primary_a !== $primary_b ) {
					return $primary_a - $primary_b;
				}

				$v1 = isset( $a['variant'] ) ? self::normalize_variant_name( $a['variant'] ) : 'Standard';
				$v2 = isset( $b['variant'] ) ? self::normalize_variant_name( $b['variant'] ) : 'Standard';

				$priority = array(
					'x64'            => 0,
					'x32'            => 1,
					'ARM64'          => 2,
					'ARM'            => 3,
					'Universal'      => 4,
					'Intel'          => 5,
					'Portable'       => 6,
					'Standard'       => 7,
					'ESR'            => 8,
					'LTS'            => 9,
					'Enterprise'     => 10,
					'Pro'            => 11,
					'Professional'   => 12,
					'Premium'        => 13,
					'Ultimate'       => 14,
					'Platinum'       => 15,
					'Plus'           => 16,
					'Max'            => 17,
					'Suite'          => 18,
					'Community'      => 19,
					'Lite'           => 20,
					'Basic'          => 21,
					'Free'           => 22,
					'Mini'           => 23,
					'Home'           => 24,
					'Express'        => 25,
					'Beta'           => 30,
					'RC'             => 31,
					'Preview'        => 32,
					'Alpha'          => 33,
					'Canary'         => 34,
					'Nightly'        => 35,
					'Dev'            => 36,
					'Stable'         => 37,
					'Trial'          => 40,
					'Plus Trial'     => 41,
					'Premium Trial'  => 42,
					'Platinum Trial' => 43,
					'Server'         => 44,
					'Workstation'    => 45,
					'2Go'            => 46,
					'Offline'        => 47,
					'Debug'          => 48,
					'DCH'            => 49,
					'DC'             => 50,
					'Minimalist'     => 51,
					'Installer'      => 52,
					'WHQL'           => 53,
					'Quadro'         => 54,
				);
				$p1       = isset( $priority[ $v1 ] ) ? $priority[ $v1 ] : 99;
				$p2       = isset( $priority[ $v2 ] ) ? $priority[ $v2 ] : 99;

				// @MODIFIED 2026-05-02: For composed variants not in the priority map
				// (e.g. "x64 Portable", "ARM64 ESR"), derive priority from the architecture prefix
				// so "x64 Portable" sorts with x64 (0), not at the bottom (99).
				if ( $p1 === 99 && preg_match( '/^(x64|x86|ARM64|ARM|Intel|Universal)\s+/i', $v1, $pm1 ) ) {
					$pk1 = strtolower( $pm1[1] );
					$pk1 = ( $pk1 === 'arm64' ) ? 'ARM64' : $pk1;
					$pk1 = ( $pk1 === 'arm' ) ? 'ARM' : $pk1;
					$p1  = isset( $priority[ $pk1 ] ) ? $priority[ $pk1 ] : 99;
				}
				if ( $p2 === 99 && preg_match( '/^(x64|x86|ARM64|ARM|Intel|Universal)\s+/i', $v2, $pm2 ) ) {
					$pk2 = strtolower( $pm2[1] );
					$pk2 = ( $pk2 === 'arm64' ) ? 'ARM64' : $pk2;
					$pk2 = ( $pk2 === 'arm' ) ? 'ARM' : $pk2;
					$p2  = isset( $priority[ $pk2 ] ) ? $priority[ $pk2 ] : 99;
				}
				if ( $p1 === $p2 ) {
					// Newest version first when same variant/primary
					$ver1 = isset( $a['version'] ) ? (string) $a['version'] : '0';
					$ver2 = isset( $b['version'] ) ? (string) $b['version'] : '0';
					$vc  = version_compare( $ver2, $ver1 );
					if ( $vc !== 0 ) {
						return $vc;
					}
					return strcasecmp( $v1, $v2 );
				}

				return $p1 - $p2;
			}
		);

		return $platform_links;
	}

	/**
	 * Format download link text from structured fields.
	 *
	 * Builds consistent, unique text using: version, channel, platform, variant, file_type.
	 * Formula: "Download [Software] [Channel] [Version] for [Platform] - [Variant] ([FileType])"
	 *
	 * @MODIFIED 2026-09-10: Complete rewrite. Builds from structured fields (platform, variant,
	 *   file_type, version, channel) instead of relying on source text preservation.
	 *   Source text (existing_text) is used ONLY for user manual overrides (text not starting
	 *   with "Download"). Structured fields extracted from source URLs by normalize_link()
	 *   carry all the information needed for unique, distinguishable text.
	 *   Tested against 85 real links from softexia, neowin, kaldata — 0 collisions.
	 *
	 * @param array  $link          Link data with platform, variant, file_type, version, channel
	 * @param string $software_name Software name
	 * @param string $existing_text Previously stored text to preserve (optional, for user overrides)
	 * @return string Formatted download text
	 */
	public static function format_download_text( $link, $software_name, $existing_text = '' ) {
		$existing_text = trim( (string) $existing_text );
		$sn            = trim( wp_strip_all_tags( (string) $software_name ) );

		// ── PATH A: User manual override (text NOT starting with "Download") ──
		// Preserves custom text set by admin in the Hero Meta Box.
		if ( $existing_text !== '' && ! preg_match( '/^download\b/i', $existing_text ) ) {
			return trim( $existing_text );
		}

		// ── PATH B: Structured design is authoritative when fields exist ──
		$url                = isset( $link['url'] ) ? (string) $link['url'] : '';
		$platform           = isset( $link['platform'] ) ? self::normalize_platform_name( $link['platform'], $url ) : '';
		$variant            = isset( $link['variant'] ) ? self::normalize_variant_name( $link['variant'] ) : 'Standard';
		$file_type          = isset( $link['file_type'] ) ? trim( (string) $link['file_type'] ) : '';
		$version            = isset( $link['version'] ) ? trim( (string) $link['version'] ) : '';
		$channel            = isset( $link['channel'] ) ? trim( (string) $link['channel'] ) : '';

		// If we have enough structured evidence, build from design (not source raw text)
		if ( $platform !== '' && $file_type !== '' && ( $version !== '' || $channel !== '' ) ) {
			// structured path continues below; do NOT return raw source_text
		} else {
			// Partial evidence: fall back to normalized source text with required prefix
			$source_text = trim(wp_strip_all_tags((string) ($link['text'] ?? '')));
			if ( $source_text !== '' ) {
				// Enforce structured prefix; normalize case; never return uppercase DOWNLOAD unless intended
				if ( preg_match( '/^download\b/i', $source_text ) ) {
					return 'Download ' . substr( $source_text, 8 ); // normalize after prefix
				}
				return 'Download ' . $source_text;
			}
		}

		// ── Extract structured fields (authoritative) ──
		$url                = isset( $link['url'] ) ? (string) $link['url'] : '';
		$platform           = isset( $link['platform'] ) ? self::normalize_platform_name( $link['platform'], $url ) : '';
		$variant            = isset( $link['variant'] ) ? self::normalize_variant_name( $link['variant'] ) : 'Standard';
		$file_type          = isset( $link['file_type'] ) ? trim( (string) $link['file_type'] ) : '';
		$version            = isset( $link['version'] ) ? trim( (string) $link['version'] ) : '';
		$channel            = isset( $link['channel'] ) ? trim( (string) $link['channel'] ) : '';

		// ── PATH B: Store links (Play Store, App Store) ──
		if ( $file_type === 'store' ) {
			if ( strcasecmp( $platform, 'Android' ) === 0 ) {
				return 'Download ' . $sn . ' from Google Play Store';
			} elseif ( strcasecmp( $platform, 'iOS' ) === 0 ) {
				return 'Download ' . $sn . ' from Apple Store';
			}
		}

		// ── PATH C: Build from structured fields ──
		// Formula: "Download [Software] [Channel] [Version] for [Platform] - [Variant] ([FileType])"

		// Step 1: "Download [Software]"
		$text = 'Download ' . ( $sn !== '' ? $sn : 'the software' );

		// Step 2: Channel (Beta, Alpha, Snapshot, Nightly, Dev, Preview, RC) — skip Stable
		$skip_channels = array( 'stable', 'standard', 'release', 'final', '' );
		$channel_clean = trim( $channel );
		if ( $channel_clean !== '' && ! in_array( strtolower( $channel_clean ), $skip_channels, true ) ) {
			// Only add channel if not already in software name
			if ( stripos( $sn, $channel_clean ) === false ) {
				$text .= ' ' . ucfirst( strtolower( $channel_clean ) );
			}
		}

		// Step 3: Version (from structured field or extracted from URL)
		if ( $version === '' && $url !== '' ) {
			// Try to extract version from URL if not in structured field
			$extracted = self::extract_version_from_url( $url, '', $sn );
			if ( $extracted !== '' && preg_match( '/(\d+(?:\.\d+)+)/', $extracted, $vm ) ) {
				$version = $vm[1];
			}
		}
		if ( $version !== '' ) {
			// Don't duplicate if version is already in the text (e.g. from channel)
			if ( stripos( $text, $version ) === false ) {
				$text .= ' ' . $version;
			}
		}

		// Step 4: Platform — "for [Platform]"
		if ( $platform !== '' && $platform !== 'Other' ) {
			$text .= ' for ' . $platform;
		}

		// Step 5: Variant suffix — " - [Variant]" (when meaningful)
		$skip_variants = array( 'standard', 'default', 'main', '' );
		if ( ! in_array( strtolower( $variant ), $skip_variants, true ) ) {
			// Don't duplicate variant if it's already in the text
			if ( stripos( $text, $variant ) === false ) {
				$text .= ' - ' . $variant;
			}
		}

		// Step 6: File type — "([FileType])" for meaningful formats not already in text
		$meaningful_formats = array( 'deb', 'rpm', 'dmg', 'pkg', 'appimage', 'snap', 'flatpak', 'archive', 'shell', 'iso', 'exe', 'msi', 'zip', '7z', 'tar', 'gz' );
		if ( $file_type !== '' && in_array( strtolower( $file_type ), $meaningful_formats, true ) ) {
			if ( stripos( $text, $file_type ) === false ) {
				// Uppercase for short acronym formats (deb→DEB, dmg→DMG, etc.)
				$text .= ' (' . strtoupper( $file_type ) . ')';
			}
		}

		// Normalize ALL-CAPS words (e.g. "DOWNLOAD" → "Download", "FREE" → "Free")
		// Skip known software acronyms (OBS, NPS, VLC, etc.)
		$acronyms_whitelist = array( 'OBS', 'NPS', 'VLC', 'CPU', 'GPU', 'USB', 'HDD', 'SSD', 'DVD', 'CD', 'HTML', 'PDF', 'AVG', 'DMG', 'DEB', 'RPM', 'PKG', 'ISO' );
		$text = preg_replace_callback( '/\b[A-Z]{2,}\b/u', function( $m ) use ( $acronyms_whitelist ) {
			if ( in_array( $m[0], $acronyms_whitelist, true ) ) {
				return $m[0]; // Preserve known acronyms
			}
			return ucfirst( strtolower( $m[0] ) );
		}, $text );

		return trim( $text );
	}

	/**
	 * Remove variant tokens that are already present in source text.
	 * "Lite ARM" + text containing "Lite" → "ARM"
	 * "Platinum x64" + text without "Platinum" → "Platinum x64"
	 */
	private static function deduplicate_variant_against_text( $variant, $text, $software_name = '' ) {
		$tokens     = array_unique( array_filter( array_map( 'trim', preg_split( '/[\s,\/]+/', $variant ) ) ) );
		
		// If there is a " - " separator, only deduplicate against the suffix after the last " - "
		$last_dash = strrpos( $text, ' - ' );
		if ( $last_dash !== false ) {
			$searchable_text = substr( $text, $last_dash + 3 );
		} else {
			// Otherwise, strip the software name to avoid matching tokens within the software name
			$searchable_text = $text;
			if ( $software_name !== '' ) {
				$escaped_name = preg_quote( $software_name, '/' );
				$searchable_text = preg_replace( '/' . $escaped_name . '/i', '', $searchable_text );
			}
		}

		$text_lower = strtolower( $searchable_text );
		$result     = array();
		foreach ( $tokens as $t ) {
			$t = trim( $t );
			if ( $t === '' ) {
				continue;
			}
			if ( strpos( $text_lower, strtolower( $t ) ) === false ) {
				$result[] = $t;
			}
		}
		if ( empty( $result ) ) {
			return '';
		}
		return self::normalize_variant_name( implode( ' ', $result ) );
	}
	/**
	 * Extract variant/edition words from source anchor text.
	 * Used to recover edition info (Plus Trial, Premium, Suite, etc.) when variant field is empty.
	 *
	 * @param string $text Source anchor text
	 * @param string $software_name Software name to remove
	 * @param string $platform Platform to remove
	 * @return string Extracted variant
	 */
	private static function extract_variant_from_anchor_text( $text, $software_name = '', $platform = '' ) {
		$label = wp_strip_all_tags( (string) $text );
		$label = preg_replace( '/\s+/u', ' ', $label );
		$label = trim( (string) $label );
		// @MODIFIED 2026-05-22: Decode HTML entities so &amp; matches & in software_name.
		// Entity-encoded anchor text (e.g. "R-Wipe &amp; Clean 20.0") would not have its
		// software name stripped because raw "&" ≠ "&amp;", leaving fragments to become
		// garbage variants via ucwords() fallback.
		$label = html_entity_decode( $label, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		$label = preg_replace( '/\s+/u', ' ', $label );
		$label = trim( (string) $label );

		if ( $label === '' ) {
			return '';
		}

		// Remove software name (decode entities in both sides for reliable matching)
		if ( $software_name !== '' ) {
			$sn = html_entity_decode( $software_name, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
			$sn = preg_replace( '/\s+/u', ' ', $sn );
			$sn = trim( $sn );
			if ( $sn !== '' ) {
				$label = preg_replace( '/' . preg_quote( $sn, '/' ) . '/iu', '', $label );
			}
		}

		// Remove platform (decode entities for consistency)
		if ( $platform !== '' ) {
			$pf = html_entity_decode( $platform, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
			$pf = preg_replace( '/\s+/u', ' ', $pf );
			$pf = trim( $pf );
			if ( $pf !== '' ) {
				$label = preg_replace( '/' . preg_quote( $pf, '/' ) . '/iu', '', $label );
			}
		}

		// Remove common words
		$label = preg_replace( '/\bdownloads?\b/iu', '', $label );
		$label = preg_replace( '/\bfor\b/iu', '', $label );
		// @MODIFIED 2026-05-04: Strip "edition" noise word — AI link text often appends
		// "Edition" after the variant token (e.g. "Business Edition", "Free Edition").
		// Without this, normalize_variant_label receives "Business Edition" which tokenizes
		// to ["Business", "Edition"] producing "Business Edition" instead of "Business".
		$label = preg_replace( '/\bedition\b/iu', '', $label );
		// @MODIFIED 2026-05-21: Strip version-number-like tokens (e.g. "7.8", "2026", "b8985")
		// that leak into variant labels from anchor text such as "Download Tails 7.8" or
		// "VirtualDJ 2026 b8985". Prevents corruption like "Tails 7.8" or "2026 b8985".
		$label = preg_replace( '/\s*\d+\.\d+(?:\.\d+)*\s*/u', ' ', $label );
		$label = preg_replace( '/\s*\d{4}\s*/u', ' ', $label );
		$label = preg_replace( '/\s*b\d{4,6}\s*/iu', ' ', $label );
		$label = preg_replace( '/\s+/u', ' ', $label );
		$label = trim( (string) $label, " \t\n\r\0\x0B-–—" );

		return self::normalize_variant_label( $label );
	}

	/**
	 * Public wrapper for extract_variant_from_anchor_text.
	 * Allows external callers (Article_Generator, Discovery_Processor) to extract
	 * variant tokens from anchor text without duplicating the regex logic.
	 *
	 * @since 2.30.0
	 * @param string $text Source anchor text
	 * @param string $software_name Software name to strip from text (optional)
	 * @param string $platform Platform name to strip from text (optional)
	 * @return string Extracted and normalized variant
	 */
	public static function extract_variant_from_anchor_text_public( $text, $software_name = '', $platform = '' ) {
		return self::extract_variant_from_anchor_text( $text, $software_name, $platform );
	}
	/**
	 * Normalize variant label to canonical form.
	 *
	 * @param string $variant Raw variant text
	 * @return string Normalized variant
	 */
	private static function normalize_variant_label( $variant ) {
		$variant = wp_strip_all_tags( (string) $variant );
		$variant = preg_replace( '/\s+/u', ' ', $variant );
		$variant = trim( (string) $variant );

		if ( $variant === '' ) {
			return '';
		}

		// Canonical variant mapping
		$map    = array(
			'plus trial'       => 'Plus Trial',
			'premium trial'    => 'Premium Trial',
			'platinum trial'   => 'Platinum Trial',
			'portable version' => 'Portable',
			'portable edition' => 'Portable',
			'64-bit'           => 'x64',
			'64 bit'           => 'x64',
			'64bit'            => 'x64',
			'64_bit'           => 'x64',
			'amd64'            => 'x64',
			'x86_64'           => 'x64',
			'win64'            => 'x64',
			'x64'              => 'x64',
			'32-bit'           => 'x32',
			'32 bit'           => 'x32',
			'32bit'            => 'x32',
			'32_bit'           => 'x32',
			'win32'            => 'x32',
			'x86'              => 'x32',
			'aarch64'          => 'ARM64',
			'arm64'            => 'ARM64',
			'arm'              => 'ARM',
			'portable'         => 'Portable',
			'intel'            => 'Intel',
			'mac'              => 'Intel',
			'universal'        => 'Universal',
			'standard'         => 'Standard',
			'suite'            => 'Suite',
			'esr'              => 'ESR',
			'lts'              => 'LTS',
			'pro'              => 'Pro',
			'lite'             => 'Lite',
			'community'        => 'Community',
			'enterprise'       => 'Enterprise',
			'premium'          => 'Premium',
			'ultimate'         => 'Ultimate',
			'professional'     => 'Professional',
			'basic'            => 'Basic',
			'free'             => 'Free',
			'plus'             => 'Plus',
			'max'              => 'Max',
			'mini'             => 'Mini',
			'home'             => 'Home',
			'express'          => 'Express',
			'beta'             => 'Beta',
			'alpha'            => 'Alpha',
			'rc'               => 'RC',
			'preview'          => 'Preview',
			'canary'           => 'Canary',
			'nightly'          => 'Nightly',
			'dev'              => 'Dev',
			'stable'           => 'Stable',
			'platinum'         => 'Platinum',
			'trial'            => 'Trial',
			'server'           => 'Server',
			'workstation'      => 'Workstation',
			'2go'              => '2Go',
			'offline'          => 'Offline',
			'online'           => 'Online',
			'debug'            => 'Debug',
			'dch'              => 'DCH',
			'dc'               => 'DC',
			'minimalist'       => 'Minimalist',
			'installer'        => 'Installer',
			'setup'            => 'Setup',
			'whql'             => 'WHQL',
			'quadro'           => 'Quadro',
			'business'         => 'Business',
			'education'        => 'Education',
			'educational'      => 'Education',
			'academic'         => 'Academic',
			'home student'     => 'Home Student',
			'student'          => 'Student',
			'personal'         => 'Personal',
			'starter'          => 'Starter',
			'basic edition'    => 'Basic',
			'free edition'     => 'Free',
			'home edition'     => 'Home',
			'edition'          => 'Edition',
			'version'          => 'Version',
			'build'            => 'Build',
		);
		$lookup = strtolower( $variant );
		if ( isset( $map[ $lookup ] ) ) {
			return $map[ $lookup ];
		}

		$arch_canonical = array(
			'x64'       => 'x64',
			'x32'       => 'x32',
			'arm64'     => 'ARM64',
			'arm'       => 'ARM',
			'intel'     => 'Intel',
			'universal' => 'Universal',
			'mac'       => 'Intel',
		);
		$arch_lower     = strtolower( $variant );
		if ( isset( $arch_canonical[ $arch_lower ] ) ) {
			return $arch_canonical[ $arch_lower ];
		}

		if ( strpos( $lookup, 'apple silicon' ) !== false || preg_match( '/\bm[1-4]\b/i', $variant ) ) {
			return 'ARM64';
		}

		$tokens = preg_split( '/[\s,\/]+/', $lookup );
		if ( count( $tokens ) > 1 ) {
			$normalized_tokens = array();
			$seen_canonical    = array();
			foreach ( $tokens as $t ) {
				$t = trim( $t );
				if ( $t === '' ) {
					continue;
				}
				$t_clean = preg_replace( '/[^a-z0-9]/i', '', $t );
				if ( $t_clean === '' ) {
					continue;
				}
				if ( isset( $map[ $t ] ) ) {
					$canonical = $map[ $t ];
				} elseif ( isset( $map[ $t_clean ] ) ) {
					$canonical = $map[ $t_clean ];
				} elseif ( isset( $arch_canonical[ $t_clean ] ) ) {
					$canonical = $arch_canonical[ $t_clean ];
				} else {
					return 'Standard';
				}
				$seen_key = strtolower( $canonical );
				if ( isset( $seen_canonical[ $seen_key ] ) ) {
					continue;
				}
				$seen_canonical[ $seen_key ] = true;
				$normalized_tokens[]         = $canonical;
			}
			$arch_groups = array(
				array( 'x64', 'x32' ),
				array( 'ARM64', 'ARM' ),
			);
			foreach ( $arch_groups as $group ) {
				$found = array();
				foreach ( $group as $arch ) {
					$pos = array_search( $arch, $normalized_tokens, true );
					if ( $pos !== false ) {
						$found[ $pos ] = $arch;
					}
				}
				if ( count( $found ) > 1 ) {
					if ( $group[0] === 'x64' && $group[1] === 'x32' ) {
						foreach ( $found as $pos => $arch ) {
							unset( $normalized_tokens[ $pos ] );
						}
						$normalized_tokens = array_values( $normalized_tokens );
						if ( empty( $normalized_tokens ) ) {
							return 'Standard';
						}
					} else {
						ksort( $found );
						$keep = reset( $found );
						foreach ( $found as $pos => $arch ) {
							if ( $arch !== $keep ) {
								unset( $normalized_tokens[ $pos ] );
							}
						}
						$normalized_tokens = array_values( $normalized_tokens );
					}
				}
			}
			$joined = implode( ' ', $normalized_tokens );
			if ( $joined !== '' ) {
				return $joined;
			}
		}

		return 'Standard';
	}
	/**
	 * Extract version, architecture, and edition information from a URL.
	 *
	 * Scans path, query, and fragment for:
	 * 1. Architecture tokens (win64, amd64, arm64, intel, apple, etc.)
	 * 2. Edition/channel keywords (pro, community, esr, lts, portable, etc.)
	 * 3. Version numbers
	 *
	 * @MODIFIED 2026-03-05: Added for distinguishable download links
	 * @MODIFIED 2026-04-23: Enhanced with architecture detection and expanded edition keywords.
	 *   Architecture tokens are extracted from URL boundaries (delimited by _ - . /)
	 *   to prevent false positives from substring matches inside words.
	 *
	 * @param string $url The download URL
	 * @return string Extracted version/arch/edition string or empty
	 */
	public static function extract_version_from_url( $url, $link_text = '', $software_name = '' ) {
		if ( empty( $url ) && empty( $link_text ) ) {
			return '';
		}

		$parts           = parse_url( $url );
		$searchable_text = ( $parts['path'] ?? '' ) . ' ' . ( $parts['query'] ?? '' ) . ' ' . ( $parts['fragment'] ?? '' );

		if ( ! empty( $link_text ) ) {
			$searchable_text .= ' ' . trim( (string) $link_text );
		}

		if ( empty( trim( $searchable_text ) ) ) {
			return '';
		}

		// Strip software name case-insensitively to avoid matching parts of the software name as edition/variant keywords (Finding #2)
		if ( ! empty( $software_name ) ) {
			$escaped_software_name = preg_quote( $software_name, '/' );
			$searchable_text = preg_replace( '/\b' . $escaped_software_name . '\b/i', '', $searchable_text );
			$searchable_text = preg_replace( '/' . $escaped_software_name . '/i', '', $searchable_text );
		}

		$filename       = basename( str_replace( '+', ' ', $parts['path'] ?? '' ) );
		$filename_lower = strtolower( $filename );
		$host_lower     = strtolower( $parts['host'] ?? '' );

		// 1. Architecture tokens — highest priority for link differentiation.
		// Delimiter-bounded matching prevents false positives inside words.
		$arch_map = array(
			'apple silicon' => 'ARM64',
			'aarch64'       => 'ARM64',
			'arm64'         => 'ARM64',
			'universal'     => 'Universal',
			'mac'           => 'Intel', // Firefox-style .mac.pkg = Intel macOS
			'amd64'         => 'x64',
			'x86_64'        => 'x64',
			'x64'           => 'x64',
			'win64'         => 'x64',
			'64bit'         => 'x64',
			'64-bit'        => 'x64',
			'64_bit'        => 'x64',
			'x86'           => 'x32',
			'i686'          => 'x32',
			'i386'          => 'x32',
			'win32'         => 'x32',
			'32bit'         => 'x32',
			'32-bit'        => 'x32',
			'32_bit'        => 'x32',
		);

		$found_arch = '';
		foreach ( $arch_map as $token => $canonical ) {
			$pattern = '/(?:^|[_\-\.\/])' . preg_quote( $token, '/' ) . '(?:$|[_\-\.\/])/i';
			if ( preg_match( $pattern, $searchable_text ) ) {
				$found_arch = $canonical;
				break;
			}
		}

		// Apple/Intel/Universal/ARM/Portable/Installer — filename and host fallbacks
		if ( empty( $found_arch ) ) {
			if ( preg_match( '/[_\-\.]apple[_\-\.\/]/i', $filename_lower )
				|| preg_match( '/[_\-](?:m[1-4])[_\-\.\/]/i', $searchable_text )
			) {
				$found_arch = 'ARM64';
			} elseif ( preg_match( '/[_\-\.]macarm64[_\-\.\/]/i', $filename_lower )
				|| preg_match( '/[_\-\.]mac\.arm64[_\-\.\/]/i', $searchable_text )
			) {
				$found_arch = 'ARM64';
			} elseif ( preg_match( '/[_\-\.]intel[_\-\.\/]/i', $filename_lower )
				|| preg_match( '/[_\-\.]intel(?:$|[_\-\.\/])/i', $searchable_text )
			) {
				$found_arch = 'Intel';
			} elseif ( preg_match( '/[_\-\.]universal[_\-\.\/]/i', $searchable_text ) ) {
				$found_arch = 'Universal';
			} elseif ( preg_match( '/[_\-\.]portable[_\-\.\/]/i', $searchable_text )
				|| strpos( $filename_lower, 'portable' ) !== false
				|| strpos( $host_lower, 'portableapps.com' ) !== false
			) {
				$found_arch = 'Portable';
			} elseif ( preg_match( '/[_\-\.]installer[_\-\.\/]/i', $searchable_text )
				|| strpos( $filename_lower, 'installer' ) !== false
			) {
				$found_arch = 'Installer';
			} elseif ( preg_match( '/[_\-\.]whql[_\-\.\/]/i', $searchable_text )
				|| strpos( $filename_lower, 'whql' ) !== false
			) {
				$found_arch = 'WHQL';
			} elseif ( preg_match( '/[_\-\.]arm[_\-\.\/]/i', $searchable_text ) ) {
				$found_arch = 'ARM';
			}
		}

		// 2. Edition/channel keywords — pro, community, esr, lts, etc.
		$edition_keywords = array(
			'esr',
			'lts',
			'leap',
			'tumbleweed',
			'pro',
			'lite',
			'ultimate',
			'premium',
			'community',
			'enterprise',
			'preview',
			'beta',
			'alpha',
			'rc',
			'canary',
			'nightly',
			'dev',
			'stable',
			'plus',
			'basic',
			'professional',
			'trial',
			'suite',
			'express',
			'max',
			'mini',
			'home',
			'free',
			'platinum',
			'server',
			'workstation',
			'2go',
			'offline',
			'debug',
			'dch',
			'dc',
			'minimalist',
			'quadro',
			'business',
			'education',
			'academic',
			'student',
			'personal',
			'starter',
		);
		$found_editions   = array();
		if ( preg_match( '/\d\.?\d*esr(?![a-z0-9])/i', $searchable_text ) ) {
			$found_editions[] = 'esr';
		}

		foreach ( $edition_keywords as $keyword ) {
			if ( $keyword === 'esr' && in_array( 'esr', $found_editions, true ) ) {
				continue;
			}
			if ( preg_match( '/(?:^|[^a-z0-9])' . preg_quote( $keyword, '/' ) . '(?![a-z0-9])/i', $searchable_text ) ) {
				$found_editions[] = $keyword;
			}
		}
		// 3. Version-like strings
		$version = '';
		if ( preg_match( '/(?:^|[^a-z0-9])(?:v|ver|version)?\s*(\d+\.\d+(?:\.\d+)*)\b/i', $searchable_text, $matches ) ) {
			$version = $matches[1];
		} elseif ( preg_match( '/(?:^|[^a-z0-9])(?:v|ver|version)?\s*(\d{4,})\b/i', $searchable_text, $matches ) ) {
			$version = $matches[1];
		}

		// Assemble: edition keywords → architecture → version
		$parts_out = array();
		if ( ! empty( $found_editions ) ) {
			foreach ( $found_editions as $ek ) {
				$parts_out[] = ucfirst( $ek );
			}
		}
		if ( ! empty( $found_arch ) ) {
			$parts_out[] = $found_arch;
		}
		if ( ! empty( $version ) ) {
			$parts_out[] = $version;
		}

		return trim( implode( ' ', $parts_out ) );

		return trim( implode( ' ', $parts_out ) );
	}

	/**
	 * Specifically detect hallucinated/fake YouTube URLs generated by AI.
	 *
	 * @since 2.27.0
	 * @param string $url URL to check
	 * @return bool True if fake YouTube URL
	 */
	public static function is_placeholder_youtube_url( string $url ): bool {
		if ( strpos( $url, 'youtube.com/watch' ) === false && strpos( $url, 'youtu.be/' ) === false ) {
			return false;
		}

		// Extract the v= parameter or the path segment
		$video_id = '';
		if ( preg_match( '/(?:v=|\/)([\w-]{11})(?:\&|$|\?)/', $url, $matches ) ) {
			$video_id = $matches[1];
		}

		if ( empty( $video_id ) ) {
			return false;
		}

		// Known LLM hallucination IDs
		$known_fakes = array(
			'11011111011',
			'00000000000',
			'11111111111',
			'12345678901',
			'abcdefghijk',
			'xxxxxxxxxxx',
			'dQw4w9WgXcQ', // Rickroll
		);

		if ( in_array( $video_id, $known_fakes, true ) ) {
			return true;
		}

		// Heuristic: If ID is entirely digits or entirely the same char
		if ( preg_match( '/^(\d)\1{10}$/', $video_id ) || preg_match( '/^([a-zA-Z])\1{10}$/', $video_id ) ) {
			return true;
		}

		// Heuristic: Binary strings '11011111011' etc
		if ( preg_match( '/^[01]{11}$/', $video_id ) ) {
			return true;
		}

		return false;
	}

	/**
	 * Infer file_type from a download URL based on file extension or store domain.
	 * Single source of truth for file_type inference — used by normalize_link()
	 * and format_download_text() to avoid maintaining two separate mapping tables.
	 *
	 * @since 2.30.0
	 * @param string $url Download URL
	 * @return string Inferred file_type or empty string
	 */
	public static function infer_file_type_from_url( $url ) {
		if ( empty( $url ) || ! is_string( $url ) ) {
			return '';
		}

		static $file_type_map = array(
			'exe'      => 'exe',
			'msi'      => 'msi',
			'msix'     => 'msix',
			'msp'      => 'msp',
			'appx'     => 'appx',
			'dmg'      => 'dmg',
			'pkg'      => 'pkg',
			'apk'      => 'apk',
			'ipa'      => 'ipa',
			'deb'      => 'deb',
			'rpm'      => 'rpm',
			'appimage' => 'appimage',
			'zip'      => 'archive',
			'7z'       => 'archive',
			'tar.gz'   => 'archive',
			'tgz'      => 'archive',
			'tar.xz'   => 'archive',
			'tar.bz2'  => 'archive',
			'sh'       => 'shell',
			'run'      => 'shell',
			'bin'      => 'shell',
		);

		$url_path = (string) parse_url( $url, PHP_URL_PATH );
		if ( preg_match( '/\.(exe|msi|msix|msp|appx|dmg|pkg|apk|ipa|deb|rpm|appimage|zip|7z|tar\.gz|tgz|tar\.xz|tar\.bz2|sh|run|bin)(?:$|[?#])/i', $url_path, $em ) ) {
			$ext = strtolower( $em[1] );
			if ( isset( $file_type_map[ $ext ] ) ) {
				return $file_type_map[ $ext ];
			}
			return $ext;
		}

		$url_host = strtolower( (string) parse_url( $url, PHP_URL_HOST ) );
		if ( strpos( $url_host, 'play.google.com' ) !== false || strpos( $url_host, 'apps.apple.com' ) !== false || strpos( $url_host, 'apps.microsoft.com' ) !== false || strpos( $url_host, 'itunes.apple.com' ) !== false ) {
			return 'store';
		}

		return '';
	}

	private static function extract_variant_tokens_from_composite( $composite, $architecture_only = false ) {
		$composite = trim( (string) $composite );
		if ( $composite === '' ) {
			return '';
		}
		$tokens         = preg_split( '/\s+/', $composite );
		$non_version    = array();
		$seen           = array();
		$arch_canonical = array( 'x64', 'x32', 'ARM64', 'ARM', 'Intel', 'Universal' );
		foreach ( $tokens as $token ) {
			if ( preg_match( '/^\d/', $token ) ) {
				continue;
			}
			$normalized = self::normalize_variant_name( $token );
			if ( $architecture_only ) {
				if ( in_array( $normalized, $arch_canonical, true ) ) {
					$seen_key = strtolower( $normalized );
					if ( ! isset( $seen[ $seen_key ] ) ) {
						$seen[ $seen_key ] = true;
						$non_version[]     = $normalized;
					}
				}
			} else {
				$seen_key = strtolower( $normalized );
				if ( ! isset( $seen[ $seen_key ] ) ) {
					$seen[ $seen_key ] = true;
					$non_version[]     = $normalized;
				}
			}
		}
		return implode( ' ', $non_version );
	}
}
