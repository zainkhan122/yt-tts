<?php

namespace DIT\TrendStudio\Content;

use DIT\TrendStudio\AI\AI_Style_Guard;

/**
 * Blueprint provider for TrendStudio prompts.
 *
 * This class encapsulates the logic for selecting a structure blueprint
 * based on the search intent and content vertical. Moving this logic into
 * its own class makes the pipeline more testable and allows future
 * extension through filters or alternate providers. The structure
 * definitions mirror those previously embedded within ContentPipeline.
 */
class PromptBlueprint
{
    /**
     * Return a blueprint describing the structure and voice of the article.
     *
     * The blueprint contains keys: type, role, formatting_directives,
     * required_sections, and voice_guidelines. If a vertical-specific
     * blueprint exists (e.g. showbiz), it will override intent-based
     * definitions.
     *
     * @param string $intent   Search intent (commercial, informational, news, mixed)
     * @param string $vertical Content vertical (e.g. general, showbiz)
     * @return array
     */
    public static function getBlueprint(string $intent, string $vertical = 'general'): array
    {
        // Common restrictions for all prompts based on vertical
        $global_restrictions = AI_Style_Guard::get_prompt_instruction($vertical);

        $blueprints = array(
            'commercial' => array(
                'type' => 'review',
                'role' => 'You are a professional product reviewer. You provide unbiased, detailed, and critical analysis of products and services.',
                'formatting_directives' => 'Use a HTML <table> for specs comparison. Use "Pros/Cons" lists.',
                'required_sections' => array(
                    'verdict_box' => 'The "Too Long; Didn\'t Read" verdict in a callout box.',
                    'critical_analysis' => 'What the marketing materials WON\'T tell you (downsides).',
                    'comparison_table' => 'Feature-by-feature comparison table',
                    'buying_guide' => 'Decision criteria and recommendations',
                ),
                'voice_guidelines' => $global_restrictions . " Start with the 'Problem'. (e.g., 'Most winter coats make you look like a marshmallow.'). Connect with the reader's pain point immediately. Be opinionated. If a product is bad, say it. Use 'I' and 'We'.",
            ),
            'informational' => array(
                'type' => 'explainer',
                'role' => 'You are an educational expert. You simplify complex topics and provide clear, accurate, and helpful information.',
                'formatting_directives' => 'Use analogies. Use "Key Takeaways" bullet points at the top.',
                'required_sections' => array(
                    'quick_answer' => 'Direct, bold answer to the core question (Targeting Google Featured Snippet).',
                    'deep_dive' => 'The nuance and context.',
                    'myth_busting' => 'Common misconceptions corrected.',
                    'related_topics' => 'Connected concepts to explore',
                ),
                'voice_guidelines' => $global_restrictions . " Focus on accuracy and clarity over style. Use data to back up claims.",
            ),
            'news' => array(
                'type' => 'inverted_pyramid',
                'role' => 'You are a neutral news reporter. You provide objective, timely, and factual accounts of events.',
                // NOTE: If the system schema requests sections[].blocks, you MUST output blocks and MUST NOT output [VISUAL_N] tokens.
                'formatting_directives' => 'Use bold text for names and dates. Use blockquotes for reactions.
                NOTE: If the system schema requests sections[].blocks, you MUST output blocks and MUST NOT output [VISUAL_N] tokens.
                - Use semantic HTML5 (<article>, <section>, <p>, <ul>, <li>, <strong>, <em>, <blockquote>).',
                'required_sections' => array(
                    'lead' => 'Who, What, When, Where, Why in first paragraph',
                    'key_developments' => 'Most important facts in order of importance',
                    'context' => 'Background for readers unfamiliar with story',
                    'reactions' => 'Quotes and responses from stakeholders',
                ),
                'voice_guidelines' => $global_restrictions . " DO NOT start with a summary. Start with the 'News Hook' - the specific event that just happened. (e.g., 'Apple just killed the headphone jack.'). Use short paragraphs. Objective, timely, factual. No editorializing.",
            ),
            'mixed' => array(
                'type' => 'feature',
                'role' => 'You are a lifestyle feature writer. You tell engaging stories that provide depth and perspective on varied topics.',
                'formatting_directives' => 'Use pullquotes. Use rich descriptive language.',
                'required_sections' => array(
                    'hook' => 'Compelling opening with user experience',
                    'overview' => 'Topic summary and significance',
                    'deep_dive' => 'Detailed exploration with multiple angles',
                    'takeaways' => 'Key insights and actionable advice',
                ),
                'voice_guidelines' => $global_restrictions . " Engaging, balanced, insightful. Use anecdotes.",
            ),
        );

        // @MODIFIED 2026-02-24 - Persona registry for vertical-specific overrides (scalable).
        $override = PersonaRegistry::get_blueprint_override($vertical, $global_restrictions);
        if (!empty($override)) {
            return apply_filters('dit_ts_prompt_blueprint', $override, $intent, $vertical);
        }

        $blueprint = $blueprints[$intent] ?? $blueprints['mixed'];

        /**
         * Filter resolved prompt blueprint.
         *
         * @param array  $blueprint Resolved blueprint.
         * @param string $intent    Intent key.
         * @param string $vertical  Vertical key.
         */
        return apply_filters('dit_ts_prompt_blueprint', $blueprint, $intent, $vertical);
    }
}
