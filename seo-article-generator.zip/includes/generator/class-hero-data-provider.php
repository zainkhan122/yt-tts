<?php

/**
 * Hero Data Provider
 *
 * Derives hero section data from Article_Schema with optional presentation overrides.
 * Enforces Single Source of Truth pattern.
 *
 * @MODIFIED 2025-12-11 v1.8.0: New class for data synchronization architecture
 * @MODIFIED 2026-05-21: CRITICAL FIX - Added input validation and error handling
 * @package SEO_Article_Generator
 */

namespace SEO_Article_Generator\Generator;

use SEO_Article_Generator\Traits\Type_Safety;

// Prevent direct access.
if (! defined('ABSPATH')) {
	exit;
}

use SEO_Article_Generator\Schema\Safety_Data;

/**
 * Hero Data Provider Class
 * 
 * Provides hero section data with validation and error handling.
 */
class Hero_Data_Provider {
    use Type_Safety;

    /**
     * Fields that can be manually overridden via the Hero Meta Box.
     * These override schema-derived values when explicitly set by the user.
     */
    const ALLOWED_OVERRIDES = array(
        'software_name',
        'version',
        'license',
        'license_details',
        'file_size',
        'rating',
        'security_badge',
        'logo_url',
        'publisher',
        'category',
        'author_name',
        'last_updated',
        'last_verified_date',
        // @MODIFIED 2026-05-23: Allow download_links to be overridden from manual edits.
        // Schema_Sync_Service promotes accepted manual link edits to the canonical snapshot.
        'download_links',
    );

    /**
     * Generate hero section data from Article_Schema.
     *
     * @param Article_Schema $schema
     * @param array|null $overrides Manual overrides from admin UI.
     * @param int $post_id
     * @return array Hero section data.
     */
    public static function from_schema(Article_Schema $schema, ?array $overrides = null, int $post_id = 0): array
	{
		// CRITICAL FIX: Validate input schema before processing
		if (!$schema instanceof Article_Schema) {
			throw new \InvalidArgumentException('Schema must be an instance of Article_Schema');
		}
		
		$tech   = $schema->tech_specs;
		$safety = $schema->safety;
		$overrides = is_array($overrides) ? $overrides : [];
		
		// CRITICAL FIX: Validate required fields exist
		if (empty($tech->software_name) && empty($schema->title)) {
			throw new \RuntimeException('Hero section requires either tech_specs.software_name or title');
		}

		$rating_data = [
			'sum'     => 0,
			'count'   => 0,
			'average' => 0,
		];
		if ($post_id > 0 && \class_exists('SEO_Article_Generator\\Frontend\\Rating_System')) {
			$rating_data = \SEO_Article_Generator\Frontend\Rating_System::get_rating_data($post_id);
		}

		$hero_data = [
			'software_name'        => $tech->software_name ?: $schema->title,
			'version'              => $schema->get_canonical_version(),
			'license'              => $tech->license ?: 'Free',
			'license_details'      => self::normalize_license_details($tech->license ?: ''),
			'file_size'            => $tech->file_size,
		'rating' => $schema->editor_rating > 0 ? $schema->editor_rating : ($rating_data['average'] > 0 ? $rating_data['average'] : 0),
			'rating_count'         => $rating_data['count'],
			'security_badge'       => self::default_security_badge($safety),
			'download_links'       => [],
			'min_os'               => self::derive_min_os($schema),
			'architecture'         => self::derive_architecture($tech),
			// [SSOT-FIX Finding 6] Use WP-timezone dates so Hero Meta Box matches what
			// the user sees on the front-end (WP Settings → General → Timezone).
			// Version_SSOT::enforce() still uses \date() server-local for tech_specs.last_updated
			// but hero_data is consumed via renderers that read WP-timezone — so both must
			// converge. We use wp_date() here for user-facing display consistency.
			'last_updated'         => function_exists( '\wp_date' ) ? \wp_date( 'F j, Y' ) : gmdate( 'F j, Y' ),
			'logo_url'             => '',
			'publisher'            => self::derive_publisher($tech),
		'category' => self::extract_first_category($schema->category ?: ($tech->application_category ?: self::fallback_category_from_post($post_id))),
		'application_category' => self::normalize_application_category_value(
			($schema->category ?: ($tech->application_category ?: self::fallback_category_from_post($post_id)))
		),
		'all_categories' => $schema->category ?: ($tech->application_category ?: self::fallback_category_from_post($post_id)),
			'author_name'          => self::derive_author_name($post_id),
			'last_verified_date'   => gmdate( 'Y-m-d' ),
			'description'          => '',
		];

		// Download section is the canonical surface; no independent hero link source.
		if (! empty($schema->download_section['links']) && is_array($schema->download_section['links'])) {
			// @MODIFIED 2026-06-30: Use normalize_links() for consistent normalization
			// with the Download Zone. Previously used a lightweight loop that allowed
			// invalid/placeholder links through, causing hero meta box to show more
			// links than the Download Zone rendered.
			$homepage = trim((string) ($schema->tech_specs->homepage ?? ''));
			$sw_name = trim((string) ($schema->tech_specs->software_name ?? $schema->title ?? ''));
			$changelog = trim((string) ($schema->tech_specs->changelogurl ?? ''));
			$normalized = \SEO_Article_Generator\Generator\Download_Link_Helper::normalize_links(
				$schema->download_section['links'],
				'Windows',
				$homepage,
				$sw_name,
				$changelog
			);
			// [SSOT-FIX Finding 7] Defer primary-link assignment to enforce_single_primary()
			// so Hero_Meta_Box UI, Download Zone, and Rank_Math_Schema all use the same
			// selection rule (smart_windows_default=true: prefer Windows x64, fallback
			// to first link). Previously, Hero_Data_Provider used a hand-rolled primary
			// loop that produced a different "primary" than the Download Zone on
			// variants where the canonical link lacked an is_primary flag.
			$normalized = \SEO_Article_Generator\Publishing\Publish_Payload_Builder::enforce_single_primary( $normalized, true );

			$hero_data['download_links'] = $normalized;
		}

		if (! empty($overrides)) {
			foreach (self::ALLOWED_OVERRIDES as $field) {
				if (isset($overrides[$field]) && $overrides[$field] !== '' && $overrides[$field] !== null && $overrides[$field] !== []) {
					$hero_data[$field] = $overrides[$field];
				}
			}
		}

		return self::normalize_for_storage($hero_data, $post_id);
	}

	/**
	 * Normalization layer to ensure the data is "schema-ready".
	 */
	private static function normalize_for_storage(array $hero_data, int $post_id = 0): array
	{
		$hero_data['software_name'] = self::as_string($hero_data['software_name'] ?? '');
		$hero_data['name']          = $hero_data['software_name'];

		$hero_data['description'] = self::derive_description_internal($hero_data, $post_id);

		$hero_data['version']          = self::as_string($hero_data['version'] ?? '');
		$hero_data['software_version'] = $hero_data['version'];

		$hero_data['publisher'] = self::as_string($hero_data['publisher'] ?? '');
		$hero_data['developer'] = $hero_data['publisher'];

	$hero_data['category'] = self::as_string($hero_data['category'] ?? '');
	$hero_data['application_category'] = self::normalize_application_category_value(
		($hero_data['application_category'] ?: $hero_data['category']) ?: ''
	);
	$enum_to_display = array(
		'GameApplication' => 'Games',
		'UtilitiesApplication' => 'Utilities',
		'BusinessApplication' => 'Business',
		'DesignApplication' => 'Design',
		'SecurityApplication' => 'Security',
		'MultimediaApplication' => 'Multimedia',
		'BrowserApplication' => 'Browser',
		'SocialNetworkingApplication' => 'Communication',
		'DeveloperApplication' => 'Developer Tools',
		'EducationalApplication' => 'Education',
	);
	$ac = $hero_data['application_category'];
	if (isset($enum_to_display[$ac]) && ($hero_data['category'] === '' || $hero_data['category'] === $ac)) {
		$hero_data['category'] = $enum_to_display[$ac];
	}

		$hero_data['min_os']           = self::as_string($hero_data['min_os'] ?? '');
		$hero_data['download_links'] = self::normalize_links_internal((array) ($hero_data['download_links'] ?? []));
		$hero_data['operating_system'] = self::normalize_operating_system_value(
			(string) ($hero_data['operating_system'] ?? $hero_data['min_os'] ?? ''),
			(array) ($hero_data['download_links'] ?? []),
			(string) ($hero_data['os_support'] ?? '')
		);
		$hero_data['os_support']       = $hero_data['operating_system'];

		$primary_url                 = self::extract_primary_url($hero_data['download_links']);
		
		$hero_data['download_url'] = $primary_url;
		$hero_data['downloadUrl']  = $hero_data['download_url'];

		$hero_data['rating']       = (float)($hero_data['rating'] ?? 0);
		$hero_data['rating_count'] = (int)($hero_data['rating_count'] ?? 0);
		$hero_data['review_count'] = $hero_data['rating_count'];

		$hero_data['file_size']   = self::as_string($hero_data['file_size'] ?? '');
		$hero_data['fileSize']    = $hero_data['file_size'];
		
		$logo = self::resolve_logo_url_internal($hero_data, $post_id);
		$hero_data['logo_url']      = $logo;
		$hero_data['software_logo'] = $logo;
		$hero_data['image']         = $logo;

		$hero_data['tech_specs'] = array_filter([
			'operating_system'     => $hero_data['operating_system'],
			'os_support'           => $hero_data['os_support'],
			'version'              => $hero_data['version'],
			'software_version'     => $hero_data['software_version'],
			'application_category' => $hero_data['application_category'],
			'download_url'         => $hero_data['download_url'],
			'downloadUrl'          => $hero_data['downloadUrl'],
			'file_size'            => $hero_data['file_size'],
			'fileSize'             => $hero_data['fileSize'],
			'software_logo'        => $hero_data['logo_url'],
		]);

		return array_filter($hero_data, function($val) {
			return $val !== null;
		});
	}

	private static function derive_description_internal(array $hero_data, int $post_id): string
	{
		$desc = '';
		if (! empty($hero_data['description'])) {
			$desc = self::as_string($hero_data['description']);
		} elseif ($post_id > 0) {
			$post = \get_post($post_id);
			if ($post && ! empty($post->post_excerpt)) {
				$desc = trim(\wp_strip_all_tags((string)$post->post_excerpt));
			} elseif ($post && ! empty($post->post_content)) {
				$desc = trim(\wp_strip_all_tags(\wp_trim_words((string)$post->post_content, 30, '...')));
			}
		}

		// [HERO-NO-VERSION / HERO-NO-SIZE] The visible hero/schema description
		// must NEVER carry the software version or file size (SERP/SSOT churn),
		// exactly like meta_description. Previously the raw AI/excerpt text was
		// returned un-stripped, so updated posts kept "...11.8 Beta... (41.8 MB)"
		// in the visible tagline and Rank Math SoftwareApplication.description.
		if ($desc !== '') {
			$desc = self::strip_version_and_size($desc);
		}

		return $desc;
	}

	/**
	 * Remove software version tokens and file-size phrases from a user-facing
	 * description string (meta_description AND the visible hero/schema tagline).
	 *
	 * Handles the real formats seen in production:
	 *   - version after a name:  "Wine 11.8 Beta", "GoodSync 12.9.29",
	 *     "Start11 2.7.1.0", "v1.2", "version 1.2.3", "1.2.3-rc1"
	 *   - trailing OS-build versions stripped by the shared version regex
	 *   - sizes: "(41.8 MB)", "is 76.6 MB,", "sized 54.9 MB", "90MB", "1.5 GB"
	 * Cleans up the residue left behind (orphaned parentheses, dangling size
	 * verbs like "is/sized MB", leftover "+"/commas) so the sentence stays readable.
	 *
	 * @param string $text
	 * @return string
	 */
	public static function strip_version_and_size(string $text): string
	{
		$text = trim((string) $text);
		if ($text === '') {
			return '';
		}

		// --- File sizes --------------------------------------------------
		// Parenthesised size block, e.g. "(41.8 MB)" / "(90 MB)" -> whole group.
		$text = preg_replace('/\(\s*\d+(?:[.,]\d+)?\s*(?:MB|GB|KB|kB|TB)\s*\)/i', ' ', $text);
		// Size phrase with a leading verb/adj and optional comma, e.g.
		// "is 76.6 MB," / "sized 54.9 MB" / "of 26 MB" / "a 1.5 GB file".
		$text = preg_replace('/\b(?:is|are|sized?|of|at|a|an|~|approximately)\s+\d+(?:[.,]\d+)?\s*(?:MB|GB|KB|kB|TB)\b[,.]?/i', ' ', $text);
		// Bare number+unit anywhere, e.g. "76.6 MB," / "90MB" / "1.5GB".
		$text = preg_replace('/\b\d+(?:[.,]\d+)?\s*(?:MB|GB|KB|kB|TB)\b[,.]?/i', ' ', $text);

		// --- Versions ----------------------------------------------------
		// Protect values that LOOK like dotted versions but are not software
		// versions: OS-version ranges ("macOS 10.13+", "Windows 10/11"), rating
		// decimals ("4.5 stars", "rated 4.8"), and thousands ("12,000"). Mask
		// them, strip software versions, then restore.
		$guards = array();
		$guard  = static function (array $m) use (&$guards) {
			$key = "\x00G" . count($guards) . "\x00";
			// Keep match verbatim incl. trailing space so restore keeps word gaps.
			$guards[$key] = $m[0];
			return $key;
		};
		// OS name + version/range (e.g. "macOS 10.13+", "Windows 10/11",
		// "Windows 7, 8, 10 and 11"). Restrict to version tokens (digits,
		// separators / . , and the word "and") so trailing PROSE or a following
		// software build ("Start menu...Start11 2.7.1.0") is not swallowed.
		$os_num   = '[0-9]{1,3}(?:[.][0-9]{1,3})?';
		$os_sep   = '(?:\s*[/+,\s]|\s+and\s*)';
		$text = preg_replace_callback(
			'~\b(?:Windows|Win|macOS|Mac\s*OS|OS\s*X|Android|iOS|Ubuntu|Debian|Linux|Fedora)\s+'
			. $os_num . '(?:' . $os_sep . '\+?' . $os_num . '){0,4}\+?~iu',
			$guard,
			$text
		);
		// Rating/measurement decimals and integers: "4.5 stars", "rated 4.8",
		// "4.5/5", "12,000 users", "98 percent".
		$text = preg_replace_callback(
			'~\b\d+(?:[.,]\d+)+\s*(?:stars?|out of|reviews?|rating|rated|percent|%|/|MB|GB|KB|TB)?\b~i',
			static function (array $m) use ($guard) {
				// Only guard when it reads as a rating/measurement (followed by a
				// rating word or a unit) OR contains thousands separators; a bare
				// software version "12.9.29" stays un-guarded for stripping below.
				if (preg_match('/^\d{1,3}(?:,\d{3})+(?:\.\d+)?$/', trim($m[0]))) {
					return $guard($m);
				}
				return $m[0];
			},
			$text
		);
		$text = preg_replace_callback(
			'~\b\d+(?:\.\d+)?\s*(?:stars?|out of|reviews?|percent|%|/5|users?)\b~i',
			$guard,
			$text
		);
		// Prefixed: "v1.2", "version 1.2.3", "ver 2.7.1.0" (optionally -suffix).
		$text = preg_replace('/\b(?:version|ver|v)\s*\d+(?:\.\d+){1,3}(?:\s*-\s*[a-z0-9]+)?\b/i', ' ', $text);
		// Bare software build: "12.9.29" / "2.7.1.0" (3+ segments) — safe, never a rating.
		$text = preg_replace('/\b\d+(?:\.\d+){2,3}(?:\s*-\s*[a-z0-9]+)?\b/i', ' ', $text);
		// 2-segment version only when it carries a release channel ("11.8 Beta",
		// "1.2 Alpha") — a plain "4.5 stars" is guarded above and a stray decimal
		// in prose is left alone. Also handle release word first: "11.8 Beta".
		$text = preg_replace('/\b\d+\.\d+\s*(?:beta|alpha|rc\d?|build\s*\d+|stable|release)\b/i', ' ', $text);
		// Orphaned release-channel word left after its number was removed.
		$text = preg_replace('/\b(?:beta|alpha|rc|stable|release|build|patch|rev)\s*\d*\b/i', ' ', $text);
		// Restore all guarded values.
		foreach ($guards as $key => $val) {
			$text = str_replace($key, $val, $text);
		}

		// --- Residue cleanup ---------------------------------------------
		// Empty parentheses left by removed content.
		$text = preg_replace('/\(\s*\)/', ' ', $text);
		// Orphaned standalone "version"/"build" word whose number was removed
		// (e.g. "This trial version, restores" -> "This trial restores"). Remove
		// the word AND the comma it left dangling after a preceding noun.
		$text = preg_replace('/\s+(?:version|build|release)\s*,/i', ' ', $text);
		$text = preg_replace('/\b(?:version|build|release)\s*([,.;:!?])/i', '$1', $text);
		$text = preg_replace('/\b(?:version|build|release)\b/i', ' ', $text);
		// A size clause deletion can leave "a free trial, and supports X".
		// Collapse ONLY when the noun immediately before the comma is one of the
		// size/licence phrases the stripper acts on (trial/free/licence), never a
		// list of operating systems.
		$text = preg_replace(
			'/\b(free trial|trial|free|open-?source|licen[cs]e|freeware)\s*,\s*(?:and|or)\s+(supports|runs|offers|works|includes|allows|lets|helps|provides|requires|features|restores|adds|gives|delivers)\b/i',
			'$1 that $2',
			$text
		);
		// Dangling comma directly between a noun and a verb where the size/version
		// clause vanished ("This trial, restores") — only noun ", " verb, no list.
		$text = preg_replace('/\b(trial)\s*,\s*(restores|supports|offers|runs|provides)\b/i', '$1 $2', $text);
		// Remove orphaned size-verb words left in front of punctuation.
		$text = preg_replace('/\b(?:is|are|sized?|of|at)\s*(?=[,.;:!?]|$)/i', '', $text);
		// Dangling conjunction before punctuation/clause end after a removed
		// clause ("offers a free trial, and." -> "offers a free trial"). Leave a
		// legitimate mid-sentence list "Linux, macOS, and BSD" untouched.
		$text = preg_replace('/\s*,\s*(?:and|or)\s*(?=[,.!?]|$)/i', '', $text);
		$text = preg_replace('/\b(?:and|or)\s*,/i', ', ', $text);
		// Collapse repeated commas (only multiple commas, never a single one —
		// preserving thousands separators like "12,000").
		$text = preg_replace('/,,+/u', ', ', $text);
		$text = preg_replace('/,\s*\./u', '.', $text);
		// Collapse whitespace and fix stray spacing before punctuation.
		$text = preg_replace('/\s+/u', ' ', $text);
		$text = preg_replace('/\s+([,.;:!?])/u', '$1', $text);
		$text = preg_replace('/\s{2,}/u', ' ', $text);
		$text = trim($text, ' ,.;:');

		return $text === '' ? '' : $text;
	}

	private static function normalize_links_internal(array $links): array
	{
		return \SEO_Article_Generator\Generator\Download_Link_Helper::normalize_links($links, 'Other');
	}

	private static function extract_primary_url(array $links): string
	{
		foreach ($links as $link) if (! empty($link['is_primary'])) return (string)$link['url'];
		if (! empty($links)) return (string)$links[0]['url'];
		return '';
	}

	private static function resolve_logo_url_internal(array $hero_data, int $post_id): string
	{
if ($post_id > 0 && \has_post_thumbnail($post_id)) return (string)\get_the_post_thumbnail_url($post_id, 'full');
    if (! empty($hero_data['logo_url'])) return (string)$hero_data['logo_url'];
		return '';
	}

	private static function normalize_operating_system_value(string $value, array $links, string $os_support = ''): string
	{
		$platforms = \SEO_Article_Generator\Generator\Download_Link_Helper::link_platforms($links);
		if ($platforms) return implode(', ', $platforms);
		// Unknown links must not invent a Windows or Portable operating system.
		return ''; // Canonical empty/unknown downloads must not reintroduce stale OS metadata.
	}

	/**
	 * Build a deterministic, SSOT-driven meta description.
	 *
	 * Uses the canonical tech_specs values (software_name, license, os_support)
	 * so the snippet always matches the Hero and post body. Version and file_size
	 * are EXCLUDED (SERP churn / build-tag noise). Returns '' when the SSOT lacks
	 * the software_name (caller keeps AI text).
	 *
	 * @param array $article Article_Schema to_array() payload.
	 * @return string
	 */
	public static function build_ssot_meta_description( array $article ): string {
		$ts      = isset( $article['tech_specs'] ) && is_array( $article['tech_specs'] ) ? $article['tech_specs'] : array();
		$name    = trim( (string) ( $ts['software_name'] ?? ( $article['title'] ?? '' ) ) );
		$version = trim( (string) ( $ts['version'] ?? '' ) );
		$size    = trim( (string) ( $ts['file_size'] ?? '' ) );
		$license = trim( (string) ( $ts['license'] ?? '' ) );

		// [META-NO-VERSION] Version no longer belongs in meta_description (SERP churn,
		// build-tag noise, length bloat).
		// [META-NO-SIZE] File size no longer belongs in meta_description (SERP churn / noise).
		// Require name as the sole determinant.
		if ( $name === '' ) {
			return '';
		}

		$os_list = self::derive_short_os_list( (string) ( $ts['os_support'] ?? '' ) );

		$head = 'Download ' . $name;
		$head .= ($os_list !== '' ? ' for ' . $os_list : '') . '.';

		$parts = array( $head );
		if ( $license !== '' ) {
			$parts[] = ucfirst( $license ) . '.';
		}
		// [META-NO-SIZE] File size excluded from meta_description (SERP churn / noise).
		$parts[] = 'Verified ' . ( function_exists( '\\wp_date' ) ? \wp_date( 'M Y' ) : date( 'M Y' ) ) . '.';

		$meta = implode( ' ', $parts );

		if ( mb_strlen( $meta ) > 158 ) {
			$_cut = mb_substr( $meta, 0, 158 );
			$_sp  = mb_strrpos( $_cut, ' ' );
			$meta = ( $_sp !== false && $_sp > 40 ) ? mb_substr( $meta, 0, $_sp ) : $_cut;
			$meta = rtrim( $meta, ' .' ) . '.';
		}

		return $meta;
	}

	/**
	 * Keep the AI-authored meta wording (natural), but force the file size to
	 * match the canonical tech_specs (source of truth). Version is NEVER injected
	 * into meta_description (SERP churn / build-tag noise). Falls back to the
	 * rigid template (build_ssot_meta_description) only when the AI meta is empty.
	 */
	public static function repair_meta_to_spec( string $meta, array $article ): string {
		$ts      = isset( $article['tech_specs'] ) && is_array( $article['tech_specs'] ) ? $article['tech_specs'] : array();
		$name    = trim( (string) ( $ts['software_name'] ?? ( $article['title'] ?? '' ) ) );
		$version = trim( (string) ( $ts['version'] ?? '' ) );
		$size    = trim( (string) ( $ts['file_size'] ?? '' ) );

		$meta = trim( $meta );
		if ( $meta === '' ) {
			return self::strip_meta_boilerplate( self::build_ssot_meta_description( $article ) );
		}

		// [META-NO-VERSION / META-NO-SIZE] Route meta_description through the SAME
		// robust version+size cleaner the visible hero/schema description uses,
		// so both surfaces are consistent. strip_version_and_size() preserves
		// OS-version ranges, ratings ("4.5 stars") and thousands ("12,000") and
		// cleans the residue (orphaned parentheses, dangling size verbs) that the
		// older per-regex approach left ("( MB)", "is MB,", "Start11 .").
		$meta = self::strip_version_and_size( $meta );

		// [META-NO-VERSION] Do not re-inject canonical version into meta_description.
		// [META-NO-SIZE] Do not re-inject file size into meta_description.
		// Version + Size SSOT remain enforced on tech_specs / hero_badge / download_section
		// by Publish_Payload_Builder::enforce_version_ssot() and Hero_Data_Provider::build().

		// Strip robotic boilerplate tails (e.g. "Official download, features, and FAQ").
		$meta = self::strip_meta_boilerplate( $meta );

		// Cap at 160 chars, trimming at a word boundary (version/size are preserved).
		$max = 160;
		if ( mb_strlen( $meta ) > $max ) {
			$meta = mb_substr( $meta, 0, $max - 1 );
			$meta = preg_replace( '/\s+\S*$/u', '', $meta );
			$meta = rtrim( $meta, ' ,;:. ' ) . '…';
		}

		return $meta;
	}

	/**
	 * Remove robotic boilerplate tails the AI (or the template fallback) may append,
	 * e.g. "Official download, features, and FAQ." / "Safe download, features,
	 * requirements and FAQ." / "Official installer, features, system requirements, and FAQ."
	 */
	private static function strip_meta_boilerplate( string $meta ): string {
		$meta = preg_replace(
			'/\s*,?\s*(?:(?:official|safe)\s+(?:download|installer)[^.]*?|features,?\s*(?:requirements,\s*)?(?:and\s*)?)faq\.?\s*$/ix',
			'',
			$meta
		);

		return rtrim( $meta );
	}

	/**
	 * Derive a short, comma-separated OS label list from a free-text os_support string.
	 *
	 * @param string $os_support e.g. "Windows 11, 10; macOS 12+; Linux".
	 * @return string e.g. "Windows, macOS, Linux" or ''.
	 */
	private static function derive_short_os_list( string $os_support ): string {
		if ( $os_support === '' ) {
			return '';
		}
		$map = array(
			'windows' => 'Windows',
			'mac'     => 'macOS',
			'apple'   => 'macOS',
			'osx'     => 'macOS',
			'linux'   => 'Linux',
			'android' => 'Android',
			'ios'     => 'iOS',
		);
		$found = array();
		$low   = strtolower( $os_support );
		foreach ( $map as $k => $label ) {
			if ( strpos( $low, $k ) !== false && ! in_array( $label, $found, true ) ) {
				$found[] = $label;
			}
		}
		return implode( ', ', $found );
	}

	public static function normalize_application_category_value(string $value): string
	{
		if ($value === '') return '';
		
		$parts = explode(',', $value);
		$platforms = ['windows', 'macos', 'android', 'ios', 'linux', 'mac'];
		$first_valid = '';
		
		foreach ($parts as $part) {
			$clean = trim($part);
			if ($clean === '' || in_array(strtolower($clean), $platforms)) continue;
			$first_valid = $clean;
			break;
		}
		
		if ($first_valid === '') {
			return 'UtilitiesApplication'; // Fallback
		}

		$map = [
			// Existing curated keywords
			'game'          => 'GameApplication',
			'utility'       => 'UtilitiesApplication',
			'utilities'     => 'UtilitiesApplication',
			'business'      => 'BusinessApplication',
			'design'        => 'DesignApplication',
			'security'      => 'SecurityApplication',
			'multimedia'    => 'MultimediaApplication',
			'video'         => 'MultimediaApplication',
			'audio'         => 'MultimediaApplication',
			'browser'       => 'BrowserApplication',
			'communication' => 'CommunicationApplication',
			'developer'     => 'DeveloperApplication',
			'education'     => 'EducationalApplication',
			'download'      => 'DownloadApplication',
			'ftp'           => 'DownloadApplication',
			'file'          => 'DownloadApplication',
			'productivity'  => 'ProductivityApplication',
			'shopping'      => 'ShoppingApplication',
			'health'        => 'HealthApplication',
			'finance'       => 'FinanceApplication',
			'entertainment' => 'EntertainmentApplication',
			'travel'        => 'TravelApplication',
			'lifestyle'     => 'LifestyleApplication',

			// Extended coverage for the site's actual software category vocabulary
			// (derived from the plugin's $category_map + get_categories() taxonomy)
			'tool'          => 'UtilitiesApplication',
			'tools'         => 'UtilitiesApplication',
			'graphic'       => 'DesignApplication',
			'cad'           => 'DesignApplication',
			'privacy'       => 'SecurityApplication',
			'vpn'           => 'SecurityApplication',
			'ids'           => 'SecurityApplication',
			'media'         => 'MultimediaApplication',
			'recorder'      => 'MultimediaApplication',
			'screen'        => 'MultimediaApplication',
			'code'          => 'DeveloperApplication',
			'editor'        => 'DeveloperApplication',
			'cms'           => 'DeveloperApplication',
			'office'        => 'ProductivityApplication',
			'cloud'         => 'BusinessApplication',
			'sync'          => 'BusinessApplication',
			'pdf'           => 'BusinessApplication',
			'backup'        => 'UtilitiesApplication',
			'recovery'      => 'UtilitiesApplication',
			'driver'        => 'UtilitiesApplication',
			'custom'        => 'UtilitiesApplication',
			'optim'         => 'UtilitiesApplication',
			'internet'      => 'UtilitiesApplication',
			'remote'        => 'UtilitiesApplication',
			'uninstall'     => 'UtilitiesApplication',
			'usb'           => 'UtilitiesApplication',
			'archive'       => 'UtilitiesApplication',
			'cd'            => 'UtilitiesApplication',
			'dvd'           => 'UtilitiesApplication',
			'simul'         => 'EntertainmentApplication',
		];

		$lower = strtolower($first_valid);
		foreach ($map as $key => $target) {
			if (strpos($lower, $key) !== false) return $target;
		}

		// @MODIFIED: Force a valid Google enum instead of free-text ucfirst().
		return 'UtilitiesApplication';
	}

	private static function default_security_badge(Safety_Data $safety): string
	{
		return '✓ Verified Download Links';
	}

	private static function derive_min_os(Article_Schema $schema): string
	{
		return $schema->system_requirements->minimum['os'] ?? '';
	}

	private static function derive_architecture($tech): string
	{
		$file_name = strtolower($tech->file_name ?? '');
		
		// ARM64/Apple Silicon detection
		if (strpos($file_name, 'arm64') !== false || 
			strpos($file_name, 'aarch64') !== false ||
			strpos($file_name, 'apple silicon') !== false ||
			strpos($file_name, 'm1') !== false ||
			strpos($file_name, 'm2') !== false ||
			strpos($file_name, 'm3') !== false ||
			strpos($file_name, 'silicon') !== false) {
			return 'ARM64';
		}
		
		// ARM detection
		if (strpos($file_name, 'arm') !== false && strpos($file_name, '64') === false) {
			return 'ARM';
		}
		
		// 64-bit detection (enhanced)
		if (strpos($file_name, '64') !== false || 
			strpos($file_name, 'amd64') !== false ||
			strpos($file_name, 'x86_64') !== false) {
			return '64';
		}
		
		return '32';
	}

	private static function derive_publisher($tech): string
	{
		return $tech->developer ?: ($tech->publisher ?: '');
	}

	private static function derive_rating_count(Article_Schema $schema): string
	{
		// Deprecated in favor of direct Rating_System sync in from_schema()
		return $schema->rating_count > 0 ? "({$schema->rating_count} ratings)" : '';
	}

	private static function extract_first_category(string $categories): string
	{
		$parts = explode(',', $categories);
		$platforms = ['windows', 'macos', 'android', 'ios', 'linux', 'mac'];
		
		foreach ($parts as $part) {
			$clean = trim($part);
			if ($clean === '') continue;
			
			if (! in_array(strtolower($clean), $platforms)) {
				return $clean;
			}
		}

		return trim($parts[0] ?? '');
	}

	private static function normalize_license_details(string $raw): string
	{
		if (preg_match('/free|open.?source/i', $raw)) return 'Free';
		if (preg_match('/trial|demo/i', $raw)) return 'Trial';
		return 'Paid';
	}

	private static function derive_author_name(int $post_id): string
	{
		if ($post_id <= 0) return '';
		$reviewer_id = (int) \get_post_meta($post_id, '_seo_reviewed_by', true);
		$uid = $reviewer_id ?: \get_post_field('post_author', $post_id);
		if ($uid) {
			$user = \get_user_by('id', $uid);
			return $user ? $user->display_name : '';
		}
		return '';
	}

	/**
	 * Fallback: extract first non-OS category from post's assigned WordPress categories.
	 * Used when schema and tech_specs both lack a category (AI omission).
	 *
	 * @param int $post_id
	 * @return string Category slug or empty string.
	 */
	private static function fallback_category_from_post(int $post_id): string
	{
		if ($post_id <= 0) {
			return '';
		}
		$categories = \get_the_category($post_id);
		if (empty($categories) || \is_wp_error($categories)) {
			return '';
		}
		$os_slugs = array('windows', 'macos', 'mac', 'linux', 'android', 'ios', 'featured', 'offline', 'portable');
		foreach ($categories as $cat) {
			if (!in_array($cat->slug, $os_slugs, true)) {
				return $cat->slug;
			}
		}
		return '';
	}
}
