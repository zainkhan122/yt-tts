<?php
if (! defined('ABSPATH')) {
	exit;
}

/**
 * NMPublicationScheduler
 *
 * Handles human-like MCQ publishing:
 * - Publishes 1 MCQ at a time from a "ready" queue.
 * - Only during a daily window.
 * - Random gap between publishes.
 */
class NMPublicationScheduler
{




	const OPTION_KEY = 'nm_publication_schedule';
	const CRON_HOOK  = 'nm_publish_next_mcq';

	public static function init()
	{
		add_action(self::CRON_HOOK, array(self::class, 'publish_next_and_reschedule'));
		add_action('admin_post_nm_spike_publish', array(self::class, 'handle_spike_request'));
		self::maybe_schedule_first_event();
	}

	public static function get_today_target_info()
	{
		$settings = self::get_settings();
		$target   = self::get_daily_target($settings);

		return array(
			'date'      => current_time('Y-m-d'),
			'target'    => (int) $target,
			'published' => (int) self::get_daily_count(),
			'min'       => (int) $settings['min_per_day'],
			'max'       => (int) $settings['max_per_day'],
		);
	}

	public static function maybe_schedule_first_event()
	{
		if (! (int) get_option('nm_scheduler_enabled', 0)) {
			return;
		}
		if (wp_next_scheduled(self::CRON_HOOK)) {
			return;
		}

		$settings = self::get_settings();

		// @MODIFIED: v9.0.3 - check daily cap before scheduling first event
		if (self::reached_daily_cap($settings)) {
			self::schedule_next_day_wakeup($settings);
			return;
		}

		$ts_local = self::compute_next_run_timestamp($settings);

		if ($ts_local) {
			$run_local = wp_date('Y-m-d H:i:s', $ts_local);
			$ts_utc    = (int) get_gmt_from_date($run_local, 'U');
			wp_schedule_single_event($ts_utc, self::CRON_HOOK);
		}
	}

	public static function publish_next_and_reschedule()
	{
		if (! (int) get_option('nm_scheduler_enabled', 0)) {
			return;
		}

		$settings = self::get_settings();

		// @MODIFIED: v9.0.3 - Defensive check: stop if daily cap already reached
		if (self::reached_daily_cap($settings)) {
			self::schedule_next_day_wakeup($settings);
			return;
		}

		if (get_transient('nm_publish_lock')) {
			return;
		}
		set_transient('nm_publish_lock', 1, 60);

		$published = self::publish_one_from_queue($settings);

		delete_transient('nm_publish_lock');

		if ($published && ! self::reached_daily_cap($settings)) {
			$ts_local = self::compute_next_run_timestamp($settings);
			if ($ts_local) {
				$run_local = wp_date('Y-m-d H:i:s', $ts_local);
				$ts_utc    = (int) get_gmt_from_date($run_local, 'U');
				wp_schedule_single_event($ts_utc, self::CRON_HOOK);
			}
		}
	}

	private static function publish_one_from_queue($settings)
	{
		$candidate_ids = self::get_ready_queue_candidates();

		if (empty($candidate_ids)) {
			return false;
		}

		$chosen_id = self::pick_weighted_mcq($candidate_ids, $settings);
		if (! $chosen_id) {
			return false;
		}

		// @FIX 9.5.2: PRESERVE the author assigned at creation time (random named-author
		// rotation). The old code overwrote post_author with the current user / first
		// admin on EVERY scheduled publish, which stamped one admin onto all MCQs and
		// made wp-admin disagree with the frontend byline. Only repair author 0.
		$publish_args = array(
			'ID'          => $chosen_id,
			'post_status' => 'publish',
			'post_date'   => current_time('mysql'),
		);

		$existing_author = (int) get_post_field('post_author', $chosen_id);
		if (0 === $existing_author) {
			// Orphaned post (User 0 cannot publish): repair with the first admin.
			$admins = get_users(
				array(
					'role'   => 'administrator',
					'number' => 1,
					'fields' => 'ID',
				)
			);
			if (! empty($admins)) {
				$publish_args['post_author'] = (int) $admins[0];
			}
		}

		// Publish
		wp_update_post($publish_args);

		self::increment_daily_counter();

		// ✅ FIX: Clean up BOTH potential keys to prevent re-queueing issues
		delete_post_meta($chosen_id, '_nm_ready_for_publish'); // Standard
		delete_post_meta($chosen_id, 'nmreadyforpublish');     // Legacy

		return true;
	}

	/**
	 * ✅ FIX: Robust Query looking for EITHER key
	 */
	private static function get_ready_queue_candidates()
	{
		// @FIX 9.3.6: Include BOTH MCQs AND generated roundup articles so the Scheduler
		// Tab workflow also governs article publication (not just MCQs). Articles are
		// queued by the article generator with _nm_ready_for_publish=yes when the scheduler
		// is enabled.
		$args = array(
			'post_type'      => array( 'mcq', 'post' ),
			'post_status'    => 'draft',
			'posts_per_page' => 25,
			'fields'         => 'ids',
			'meta_query'     => array(
				'relation' => 'OR',
				array(
					'key'   => '_nm_ready_for_publish', // Correct Hidden Key
					'value' => 'yes',
				),
				array(
					'key'   => 'nmreadyforpublish',     // Legacy/User-entered Key
					'value' => 'yes',
				),
			),
		);

		$q = new WP_Query($args);
		return $q->posts;
	}

	private static function pick_weighted_mcq(array $ids, array $settings)
	{
		$weights = array();
		$total   = 0;

		foreach ($ids as $id) {
			$w = 1;
			// Hot Topics
			$topics = wp_get_post_terms($id, 'topic', array('fields' => 'ids'));
			if (! is_wp_error($topics) && is_array($topics)) {
				foreach ($topics as $tid) {
					if (isset($settings['hot_topics'][$tid])) {
						$w += (int) $settings['hot_topics'][$tid];
					}
				}
			}
			// Hot Exams
			$exams = wp_get_post_terms($id, 'nm_exam', array('fields' => 'ids')); // Fixed taxonomy name
			if (! is_wp_error($exams) && is_array($exams)) {
				foreach ($exams as $eid) {
					if (isset($settings['hot_exams'][$eid])) {
						$w += (int) $settings['hot_exams'][$eid];
					}
				}
			}
			$weights[$id] = max(1, $w);
			$total         += $weights[$id];
		}

		if ($total <= 0) {
			return $ids[array_rand($ids)];
		}

		$rand = (int) wp_rand(1, $total);
		foreach ($weights as $id => $w) {
			if ($rand <= $w) {
				return $id;
			}
			$rand -= $w;
		}
		return $ids[0];
	}

	private static function compute_next_run_timestamp(array $settings)
	{
		$tz     = wp_timezone();
		$now    = new DateTimeImmutable('now', $tz);
		$startH = (int) $settings['window_start_hour'];
		$endH   = (int) $settings['window_end_hour'];

		$today_start = $now->setTime($startH, 0, 0);
		$today_end   = $now->setTime($endH, 0, 0);

		if ($now < $today_start) {
			$base = $today_start;
		} elseif ($now > $today_end) {
			$base = $now->modify('+1 day')->setTime($startH, 0, 0);
		} else {
			$base = $now;
		}

		$weekday  = (int) $base->format('N');
		$gaps     = $settings['gaps'];
		$gap_conf = isset($gaps[$weekday]) ? $gaps[$weekday] : $gaps[1];

		$min_gap = max(60, (int) $gap_conf['min'] * 60);
		$max_gap = max($min_gap, (int) $gap_conf['max'] * 60);

		$gap_seconds = (int) wp_rand($min_gap, $max_gap);
		$run         = $base->modify('+' . $gap_seconds . ' seconds');

		$base_day_end = $base->setTime($endH, 0, 0);
		if ($run > $base_day_end) {
			$run    = $run->modify('+1 day')->setTime($startH, 0, 0);
			$jitter = (int) wp_rand(0, 30 * 60);
			$run    = $run->modify('+' . $jitter . ' seconds');
		}

		return $run->getTimestamp();
	}

	private static function schedule_next_day_wakeup(array $settings)
	{
		if (! (int) get_option('nm_scheduler_enabled', 0)) {
			return;
		}
		// If something is already scheduled, don't add another.
		if (wp_next_scheduled(self::CRON_HOOK)) {
			return;
		}

		$tz     = wp_timezone();
		$startH = (int) $settings['window_start_hour'];

		$tomorrow_start = (new DateTimeImmutable('now', $tz))->modify('+1 day')->setTime($startH, 0, 0);
		$jitter         = (int) wp_rand(0, 30 * 60);
		$run            = $tomorrow_start->modify('+' . $jitter . ' seconds');

		$run_local = wp_date('Y-m-d H:i:s', $run->getTimestamp());
		$ts_utc    = (int) get_gmt_from_date($run_local, 'U');
		wp_schedule_single_event($ts_utc, self::CRON_HOOK);
	}


	private static function reached_daily_cap($settings)
	{
		// @MODIFIED: Use randomized target instead of fixed max
		$target = self::get_daily_target($settings);
		return ($target > 0) && (self::get_daily_count() >= $target);
	}

	/**
	 * @MODIFIED: Picks a randomized target for the day between min and max settings.
	 * Returns the stored target for today or generates a new one.
	 */
	private static function get_daily_target($settings)
	{
		$today   = current_time('Y-m-d');
		$targets = get_option('nm_scheduler_daily_targets', array());

		if (isset($targets[$today])) {
			return (int) $targets[$today];
		}

		$min = (int) $settings['min_per_day'];
		$max = (int) $settings['max_per_day'];

		if ($max <= 0) {
			return 0;
		}
		if ($min <= 0) {
			$min = $max;
		}
		if ($min > $max) {
			$min = $max;
		}

		// Don't repeat yesterday if range allows
		$tz        = wp_timezone();
		$yesterday = (new DateTimeImmutable('now', $tz))->modify('-1 day')->format('Y-m-d');
		$prev      = isset($targets[$yesterday]) ? (int) $targets[$yesterday] : null;

		$new_target = (int) wp_rand($min, $max);

		if (null !== $prev && $max > $min && $new_target === $prev) {
			for ($i = 0; $i < 5 && $new_target === $prev; $i++) {
				$new_target = (int) wp_rand($min, $max);
			}
			if ($new_target === $prev) {
				$new_target = ($prev < $max) ? ($prev + 1) : $min;
			}
		}

		$targets[$today] = $new_target;

		// Cleanup old data (last 7 days kept)
		foreach ($targets as $date => $val) {
			if (strtotime($date) < strtotime('-7 days')) {
				unset($targets[$date]);
			}
		}

		update_option('nm_scheduler_daily_targets', $targets, false);
		return $new_target;
	}

	private static function get_daily_count()
	{
		$today = current_time('Y-m-d');
		$stats = get_option('nm_scheduler_stats', array());
		return isset($stats[$today]) ? (int) $stats[$today] : 0;
	}

	private static function increment_daily_counter()
	{
		$today = current_time('Y-m-d');
		$stats = get_option('nm_scheduler_stats', array());

		// Cleanup old data
		foreach ($stats as $date => $count) {
			if (strtotime($date) < strtotime('-7 days')) {
				unset($stats[$date]);
			}
		}

		if (! isset($stats[$today])) {
			$stats[$today] = 0;
		}
		++$stats[$today];
		update_option('nm_scheduler_stats', $stats, false);
	}

	public static function publish_spike_batch($count = 5)
	{
		$settings = self::get_settings();
		$i        = 0;
		while ($i < $count) {
			if (self::reached_daily_cap($settings)) {
				break;
			}
			if (! self::publish_one_from_queue($settings)) {
				break;
			}
			++$i;
		}
	}

	public static function handle_spike_request()
	{
		if (! current_user_can('manage_options')) {
			wp_die('Not allowed');
		}
		check_admin_referer('nm_spike_publish');
		$count = min(max(1, (int) $_POST['nm_spike_count']), 50);
		self::publish_spike_batch($count);

		// Re-arm scheduling (and if today's cap is hit, schedule tomorrow wakeup)
		self::maybe_schedule_first_event();

		wp_safe_redirect(wp_get_referer());
		exit;
	}

	private static function get_settings()
	{
		return array(
			'window_start_hour' => (int) get_option('nm_scheduler_window_start', 9),
			'window_end_hour'   => (int) get_option('nm_scheduler_window_end', 21),
			'max_per_day'       => (int) get_option('nm_scheduler_max_per_day', 50),
			'min_per_day'       => (int) get_option('nm_scheduler_min_per_day', 10), // @MODIFIED: Added min_per_day
			'hot_topics'        => self::get_expanded_hot_topics(), // @MODIFIED: Expand parents to children & map to weights
			'hot_exams'         => (array) get_option('nm_scheduler_hot_exams', array()),
			'gaps'              => array(
				1 => array(
					'min' => (int) get_option('nm_scheduler_min_gap', 15),
					'max' => (int) get_option('nm_scheduler_max_gap', 60),
				),
				2 => array(
					'min' => (int) get_option('nm_scheduler_min_gap', 15),
					'max' => (int) get_option('nm_scheduler_max_gap', 60),
				),
				3 => array(
					'min' => (int) get_option('nm_scheduler_min_gap', 15),
					'max' => (int) get_option('nm_scheduler_max_gap', 60),
				),
				4 => array(
					'min' => (int) get_option('nm_scheduler_min_gap', 15),
					'max' => (int) get_option('nm_scheduler_max_gap', 60),
				),
				5 => array(
					'min' => (int) get_option('nm_scheduler_min_gap', 15),
					'max' => (int) get_option('nm_scheduler_max_gap', 60),
				),
				6 => array(
					'min' => (int) get_option('nm_scheduler_min_gap', 20),
					'max' => (int) get_option('nm_scheduler_max_gap', 90),
				),
				7 => array(
					'min' => (int) get_option('nm_scheduler_min_gap', 20),
					'max' => (int) get_option('nm_scheduler_max_gap', 90),
				),
			),
		);
	}

	/**
	 * @MODIFIED: Helper to expand parent topics to children and assign weights.
	 * Returns [ term_id => weight ].
	 */
	private static function get_expanded_hot_topics()
	{
		$saved  = (array) get_option('nm_scheduler_hot_topics', array());
		$map    = array();
		$weight = 10; // Weight for hot topics

		foreach ($saved as $parent_id) {
			$parent_id = (int) $parent_id;
			if (! $parent_id) {
				continue;
			}

			// Add parent
			$map[$parent_id] = $weight;

			// Add children
			$children = get_term_children($parent_id, 'topic');
			if (! is_wp_error($children) && ! empty($children)) {
				foreach ($children as $child_id) {
					$map[$child_id] = $weight;
				}
			}
		}

		return $map;
	}
}

