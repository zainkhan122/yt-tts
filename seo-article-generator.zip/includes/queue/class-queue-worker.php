<?php

/**
 * Queue Worker — processes reserved jobs within a runtime budget
 *
 * @package SEO_Article_Generator
 * @MODIFIED 2026-03-02 v2.19.0: Industrial Queue Architecture
 */

namespace SEO_Article_Generator\Queue;

// Prevent direct access
if (! defined('ABSPATH')) {
    exit;
}

/**
 * The Worker picks up jobs from the queue, executes them,
 * and marks them completed or failed. Respects a maximum runtime
 * limit to avoid PHP timeout kills.
 */
class Queue_Worker
{
    /**
     * @var Job_Repository
     */
    private $repository;

    /**
     * @var mixed
     */
    private $logger;

    public function __construct(Job_Repository $repository, $logger = null)
    {
        $this->repository = $repository;
        $this->logger     = $logger;
    }

    public function run($max_runtime = 20, array $allowed_types = array())
    {
        $start    = microtime(true);
        $reserved = 0;
        $completed = 0;
        $failed   = 0;

        while ((microtime(true) - $start) < (int) $max_runtime) {
            $job = $this->repository->reserve(3600, $allowed_types);

            if (! $job) {
                break;
            }

            ++$reserved;
            $handler = null;

            try {
                $handler = $this->resolve_handler($job);

                $result = $handler->handle();

                // If handler returns 'reconciled', it means it already updated terminal state (e.g. Generate_Article_Job)
                if ($result === \SEO_Article_Generator\Queue\Job_Interface::STATUS_RECONCILED) {
                    ++$completed;
                    continue;
                }

                if ($result !== true) {
                    throw new \RuntimeException('Job handler returned false');
                }

                $ok = $this->repository->mark_completed(
                    (int) $job->id,
                    (string) $job->reservation_token
                );

                if (! $ok) {
                    throw new \RuntimeException(
                        'Queue completion CAS failed for queue job ' . (int) $job->id
                    );
                }
                ++$completed;
            } catch (\Throwable $e) {
                ++$failed;
                $attempts = ((int) $job->attempts) + 1;

                $failed_ok = $this->repository->mark_failed(
                    (int) $job->id,
                    $attempts,
                    (string) $job->reservation_token
                );

                if (! $failed_ok && $this->logger) {
                    $this->logger->error(
                        'Queue job failure CAS failed.',
                        array(
                            'queue_job_id'      => (int) $job->id,
                            'reservation_token' => (string) $job->reservation_token,
                            'job_type'          => (string) $job->type,
                            'error'             => $e->getMessage(),
                        )
                    );
                }

                if ($handler && method_exists($handler, 'failed')) {
                    $handler->failed($e);
                }
            }
        }

        return array(
            'reserved'  => $reserved,
            'completed' => $completed,
            'failed'    => $failed,
        );
    }

    private function resolve_handler($job)
    {
        $payload = json_decode(isset($job->payload) ? $job->payload : '{}', true);
        if (! is_array($payload)) {
            $payload = array();
        }

        $ref_id = (int) $job->reference_id;
        $q_id   = (int) $job->id;
        $token  = (string) $job->reservation_token;

        switch ($job->type) {
            case Job_Types::PROCESS_DRAFT:
                return new Jobs\Process_Draft_Job($ref_id, $payload, $q_id, $token);

            case Job_Types::CLEANUP_DISCOVERY:
                return new Jobs\Cleanup_Discovery_Job($ref_id, $payload, $q_id, $token);

            case Job_Types::CLEANUP_RETENTION:
                return new Jobs\Cleanup_Retention_Job($ref_id, $payload, $q_id, $token);

            case Job_Types::GENERATE_ARTICLE:
                return new Jobs\Generate_Article_Job($ref_id, $payload, $q_id, $token);

            default:
                throw new \RuntimeException('Unknown job type: ' . $job->type);
        }
    }
}
