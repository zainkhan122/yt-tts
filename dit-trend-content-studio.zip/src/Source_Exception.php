<?php

/**
 * Source Exception
 *
 * @package DIT_TrendStudio
 * @MODIFIED 2025-12-13 - Extracted from class-error-handler.php for autoloader compatibility
 */

namespace DIT\TrendStudio;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Custom exception for source provider errors
 */
class Source_Exception extends \Exception {}
