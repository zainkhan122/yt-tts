<?php

namespace SEO_Article_Generator\Validation;

use SEO_Article_Generator\Tools\Sentinel_Fallback_Utility;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Post_Content_Integrity_Guard
 *
 * Hard gate that runs before wp_update_post() / wp_insert_post() in auto_finalize().
 * Calls Sentinel_Fallback_Utility::audit() (structural check) and optionally
 * Surgical_Patcher::preflight() (zone check for plugin_generated posts).
 *
 * Only duplicate sentinels and duplicate IDs are fatal.
 * TOC stale anchors and cross-post links are warnings (logged, not blocking).
 *
 * @since 2.33.0
 */
final class Post_Content_Integrity_Guard {

    /**
     * Validate HTML before publishing.
     *
     * @param string $html   The final post_content to validate.
     * @param array  $args {
     *   @type string   $mode              'new' | 'update' | 'plugin_generated'
     *   @type string[] $required_sections Zone keys to check patchability (plugin_generated only)
     * }
     * @return array{ok:bool, fatal_reasons:array, audit:array, warnings:array}
     */
    public static function validate_for_publish( string $html, array $args = [] ): array {
        $args = wp_parse_args( $args, [
            'mode'              => 'update',
            'required_sections' => [],
        ] );

        $audit  = Sentinel_Fallback_Utility::audit( $html );
        $fatal  = (array) ( $audit['fatal_reasons'] ?? [] );

        // @MODIFIED 2026-03-22: Removed Surgical_Patcher::preflight check as it belongs to the legacy heuristic path.
        // The new block-based Patcher handles its own structure validation via parse_blocks().

        // cross_post_links are intentionally NOT promoted to fatal here.
        // Sentinel_Fallback_Utility::audit() classifies same-site internal links as warnings only
        // (line 174-180). These are legitimate SEO cross-linking, not structural corruption.
        // Only duplicate_sentinels and duplicate_ids remain fatal.

        $fatal = array_values( array_unique( array_filter( array_map( 'strval', $fatal ) ) ) );

        return [
            'ok'            => empty( $fatal ),
            'fatal_reasons' => $fatal,
            'audit'         => $audit,
            'warnings'      => (array) ( $audit['warnings'] ?? [] ),
        ];
    }
}
