<?php

/**
 * Draft Cleanup Service
 *
 * @package DIT_TrendStudio
 * @since 2.8.2
 */

namespace DIT\TrendStudio\Services;

use DIT\TrendStudio\Infrastructure\Logger;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Service to automatically clean up old draft posts
 */
class Draft_Cleanup_Service
{
    /**
     * Logger instance
     *
     * @var Logger
     */
    private Logger $logger;

    /**
     * Constructor
     *
     * @param Logger $logger Logger instance
     */
    public function __construct(Logger $logger)
    {
        $this->logger = $logger;
    }


    /**
     * Purge trashed source drafts immediately (manual button helper).
     *
     * This ignores the age threshold and only deletes posts that were marked by this plugin
     * as safe cleanup candidates (i.e., processed sources that already produced an article).
     *
     * @MODIFIED 2026-02-24 - Manual purge for admin verification without waiting for threshold days.
     *
     * @param int $batch_size Max posts per batch.
     * @param int $max_batches Safety cap to avoid long admin requests.
     * @return array Summary of purge results.
     */
    public function purge_trashed_cleanup_candidates_now(int $batch_size = 50, int $max_batches = 10): array
    {
        $enabled = (bool) get_option('dit_ts_enable_draft_cleanup', false);
        if (!$enabled) {
            return ['deleted_posts' => 0, 'deleted_media' => 0, 'remaining' => 0, 'status' => 'disabled'];
        }

        // @MODIFIED 2026-02-25 - Respect admin setting to delete associated media (safe-by-default with usage checks)
        $delete_media = (bool) get_option('dit_ts_draft_cleanup_delete_media', false);

        $meta_query = array(
            'relation' => 'AND',
            array(
                'key'     => '_dit_ts_cleanup_candidate',
                'value'   => '1',
                'compare' => '=',
            ),
            array(
                'key'     => '_dit_ts_article_id',
                'compare' => 'EXISTS',
            ),
            array(
                'key'     => '_dit_ts_processed_at_gmt',
                'compare' => 'EXISTS',
            ),
        );

        $deleted_posts = 0;
        $deleted_media = 0;

        $this->logger->info(sprintf(
            'Draft Cleanup (Manual): Starting trash purge now. Batch size: %d, Max batches: %d, Delete Media: %s',
            $batch_size,
            $max_batches,
            $delete_media ? 'YES' : 'NO'
        ));

        $batches = 0;
        do {
            $args = array(
                'post_type'      => 'post',
                'post_status'    => 'trash',
                'posts_per_page' => $batch_size,
                'meta_query'     => $meta_query,
                'fields'         => 'ids',
            );

            $ids = get_posts($args);
            if (empty($ids)) {
                break;
            }

            foreach ($ids as $post_id) {
                $post_deleted_media = 0;

                if ($delete_media) {
                    $attachment_ids = Media_Cleanup_Helper::get_candidate_attachment_ids_for_post((int) $post_id);

                    foreach ($attachment_ids as $attachment_id) {
                        // @MODIFIED 2026-02-25 - Report ALL using posts (up to 5) for skipped attachments.
                        $using_ids = Media_Cleanup_Helper::get_attachment_usage_post_ids((int) $attachment_id, array((int) $post_id), 5);
                        if (!empty($using_ids)) {
                            $refs = array();
                            foreach ($using_ids as $uid) {
                                $uid = (int) $uid;
                                $refs[] = sprintf(
                                    '%d (%s) %s',
                                    $uid,
                                    get_the_title($uid),
                                    html_entity_decode((string) get_edit_post_link($uid))
                                );
                            }

                            $this->logger->info(sprintf(
                                'Draft Cleanup (Manual): SKIPPED attachment %d (in-use elsewhere by: %s) for Post ID %d',
                                (int) $attachment_id,
                                implode(', ', $refs),
                                (int) $post_id
                            ));
                            continue;
                        }

                        if (wp_delete_attachment((int) $attachment_id, true)) {
                            $deleted_media++;
                            $post_deleted_media++;
                        }
                    }
                }

                if (wp_delete_post($post_id, true)) {
                    $deleted_posts++;
                    $this->logger->info(sprintf(
                        'Draft Cleanup (Manual): DELETED Post ID %d (attachments: %d)',
                        $post_id,
                        $post_deleted_media
                    ));
                }
            }

            $batches++;
        } while ($batches < $max_batches);

        // Calculate remaining eligible items
        $q = new \WP_Query(array(
            'post_type'      => 'post',
            'post_status'    => 'trash',
            'posts_per_page' => 1,
            'fields'         => 'ids',
            'meta_query'     => $meta_query,
            'no_found_rows'  => false,
        ));

        $remaining = (int) ($q->found_posts ?? 0);

        $this->logger->info(sprintf(
            'Draft Cleanup (Manual): Completed. Deleted %d posts (%d media). Remaining eligible in Trash: %d.',
            $deleted_posts,
            $deleted_media,
            $remaining
        ));

        return array(
            'deleted_posts' => $deleted_posts,
            'deleted_media' => $deleted_media,
            'remaining'     => $remaining,
            'status'        => 'success',
        );
    }

    /**
     * Perform cleanup of old drafts based on settings
     *
     * @return array Summary of cleanup results
     */
    public function cleanup_old_drafts(): array
    {
        $enabled = (bool) get_option('dit_ts_enable_draft_cleanup', false);
        if (!$enabled) {
            return ['deleted_posts' => 0, 'deleted_media' => 0, 'status' => 'disabled'];
        }

        $age_days = (int) get_option('dit_ts_draft_cleanup_age_days', 7);
        // @MODIFIED 2026-02-25 - Respect admin setting to delete associated media (safe-by-default with usage checks)
        $delete_media = (bool) get_option('dit_ts_draft_cleanup_delete_media', false);

        // Calculate threshold date (GMT)
        $threshold_timestamp = time() - ($age_days * DAY_IN_SECONDS);
        $threshold_date = gmdate('Y-m-d H:i:s', $threshold_timestamp);

        $this->logger->info(sprintf(
            "Draft Cleanup: Starting. Threshold: %d days (%s). Delete Media: %s",
            $age_days,
            $threshold_date,
            $delete_media ? 'YES' : 'NO'
        ));

        // Find trashed processed sources older than threshold
        $args = array(
            'post_type'      => 'post',
            'post_status'    => 'trash', // @MODIFIED 2026-02-24 - Only purge trashed sources
            'posts_per_page' => 100,
            'meta_query'     => array(
                'relation' => 'AND',
                array(
                    'key'     => '_dit_ts_cleanup_candidate',
                    'value'   => '1',
                    'compare' => '=',
                ),
                array(
                    'key'     => '_dit_ts_article_id',
                    'compare' => 'EXISTS',
                ),
                array(
                    'key'     => '_dit_ts_processed_at_gmt',
                    'value'   => (string) $threshold_timestamp,
                    'type'    => 'NUMERIC',
                    'compare' => '<=',
                ),
            ),
            'fields'         => 'ids',
        );

        $draft_ids = get_posts($args);
        $deleted_posts = 0;
        $deleted_media = 0;

        if (empty($draft_ids)) {
            $this->logger->info("Draft Cleanup: No matching drafts found.");
            return ['deleted_posts' => 0, 'deleted_media' => 0, 'status' => 'success'];
        }

        foreach ($draft_ids as $post_id) {
            $post_deleted_media = 0; // @MODIFIED 2026-02-22 - Track media deleted per post for logging

            // Check for associated media if enabled
            if ($delete_media) {
                $attachment_ids = Media_Cleanup_Helper::get_candidate_attachment_ids_for_post((int) $post_id);
                foreach ($attachment_ids as $attachment_id) {
                    // @MODIFIED 2026-02-25 - Report ALL using posts (up to 5) for skipped attachments.
                    $using_ids = Media_Cleanup_Helper::get_attachment_usage_post_ids((int) $attachment_id, array((int) $post_id), 5);
                    if (!empty($using_ids)) {
                        $refs = array();
                        foreach ($using_ids as $uid) {
                            $uid = (int) $uid;
                            $refs[] = sprintf(
                                '%d (%s) %s',
                                $uid,
                                get_the_title($uid),
                                html_entity_decode((string) get_edit_post_link($uid))
                            );
                        }

                        $this->logger->info(sprintf(
                            'Draft Cleanup: SKIPPED attachment %d (in-use elsewhere by: %s) for Post ID %d',
                            (int) $attachment_id,
                            implode(', ', $refs),
                            (int) $post_id
                        ));
                        continue;
                    }

                    if (wp_delete_attachment((int) $attachment_id, true)) {
                        $deleted_media++;
                        $post_deleted_media++;
                    }
                }
            }

            // Permanently delete the post
            if (wp_delete_post($post_id, true)) {
                // @MODIFIED 2026-02-22 - Log attachment deletion count per post
                $this->logger->info(sprintf(
                    "Draft Cleanup: DELETED Post ID %d ('%s') with %d attachments",
                    $post_id,
                    get_the_title($post_id),
                    $post_deleted_media
                ));
                $deleted_posts++;
            }
        }

        $this->logger->info(sprintf(
            "Draft Cleanup: Completed. Deleted %d posts and %d media attachments.",
            $deleted_posts,
            $deleted_media
        ));

        return [
            'deleted_posts' => $deleted_posts,
            'deleted_media' => $deleted_media,
            'status'        => 'success'
        ];
    }

    /**
     * Purge orphaned attachments where the parent post no longer exists.
     *
     * This is a remediation routine for cases where a source post was permanently deleted
     * but its child attachments remained, leaving files on disk.
     *
     * Safety: attachment is only deleted if it is not referenced anywhere else.
     * If referenced elsewhere, it is DETACHED (post_parent set to 0) rather than deleted.
     *
     * @MODIFIED 2026-02-25 - Add orphan attachment cleaner.
     *
     * @param int $batch_size Max attachments per batch.
     * @param int $max_batches Safety cap to avoid long admin requests.
     * @return array Summary
     */
    public function purge_orphaned_attachments_now(int $batch_size = 100, int $max_batches = 10): array
    {
        $enabled = (bool) get_option('dit_ts_enable_draft_cleanup', false);
        if (!$enabled) {
            return ['deleted_media' => 0, 'detached_media' => 0, 'remaining' => 0, 'status' => 'disabled'];
        }

        $delete_media = (bool) get_option('dit_ts_draft_cleanup_delete_media', false);
        if (!$delete_media) {
            return ['deleted_media' => 0, 'detached_media' => 0, 'remaining' => 0, 'status' => 'media_delete_disabled'];
        }

        global $wpdb;

        $deleted_media = 0;
        $detached_media = 0;

        $this->logger->info(sprintf(
            'Draft Cleanup (Manual): Starting orphan attachment purge. Batch size: %d, Max batches: %d',
            $batch_size,
            $max_batches
        ));

        $batches = 0;
        do {
            // Attachments with non-zero parent where parent no longer exists.
            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT a.ID, a.post_parent
                 FROM {$wpdb->posts} a
                 LEFT JOIN {$wpdb->posts} p ON p.ID = a.post_parent
                 WHERE a.post_type = 'attachment'
                   AND a.post_status = 'inherit'
                   AND a.post_parent <> 0
                   AND p.ID IS NULL
                 ORDER BY a.ID ASC
                 LIMIT %d",
                $batch_size
            ));

            if (empty($rows)) {
                break;
            }

            foreach ($rows as $row) {
                $attachment_id = (int) $row->ID;

                // If used elsewhere, detach rather than delete.
                $using_ids = Media_Cleanup_Helper::get_attachment_usage_post_ids($attachment_id, array(), 5);
                if (!empty($using_ids)) {
                    $wpdb->update(
                        $wpdb->posts,
                        array('post_parent' => 0),
                        array('ID' => $attachment_id),
                        array('%d'),
                        array('%d')
                    );
                    $detached_media++;
                    $this->logger->info(sprintf(
                        'Draft Cleanup (Manual): DETACHED orphan attachment %d (in-use elsewhere by post %d - %s)',
                        $attachment_id,
                        (int) $using_ids[0],
                        html_entity_decode((string) get_edit_post_link((int) $using_ids[0]))
                    ));
                    continue;
                }

                if (wp_delete_attachment($attachment_id, true)) {
                    $deleted_media++;
                    $this->logger->info(sprintf(
                        'Draft Cleanup (Manual): DELETED orphan attachment %d',
                        $attachment_id
                    ));
                }
            }

            $batches++;
        } while ($batches < $max_batches);

        // Remaining count
        $remaining = (int) $wpdb->get_var(
            "SELECT COUNT(1)
             FROM {$wpdb->posts} a
             LEFT JOIN {$wpdb->posts} p ON p.ID = a.post_parent
             WHERE a.post_type = 'attachment'
               AND a.post_status = 'inherit'
               AND a.post_parent <> 0
               AND p.ID IS NULL"
        );

        $this->logger->info(sprintf(
            'Draft Cleanup (Manual): Orphan purge complete. Deleted %d attachments, detached %d. Remaining orphan attachments: %d.',
            $deleted_media,
            $detached_media,
            $remaining
        ));

        return array(
            'deleted_media'  => $deleted_media,
            'detached_media' => $detached_media,
            'remaining'      => $remaining,
            'status'         => 'success',
        );
    }
}
