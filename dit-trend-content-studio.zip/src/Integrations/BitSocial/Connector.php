<?php

namespace DIT\TrendStudio\Integrations\BitSocial;

use DIT\TrendStudio\Services\Social_Queue_Manager;
use DIT\TrendStudio\Core\Social_Bootstrap;

class Connector
{
    private Social_Queue_Manager $queue;

    public function __construct(Social_Queue_Manager $queue)
    {
        $this->queue = $queue;
    }

    public function init(): void
    {
        add_filter('bit_social_post_data', [$this, 'inject_drip_image'], 10, 2);
        add_filter('bit_social_post_image', [$this, 'override_bit_social_image'], 20, 2);
        add_filter('bit_social_post_message', [$this, 'override_bit_social_message'], 20, 2);
        add_filter('bit_social_post_images', [$this, 'override_bit_social_images'], 20, 2);
        add_filter('get_post_metadata', [$this, 'intercept_thumbnail_meta'], 99, 4);
        add_action('bit_social_all_platforms_post_publish', [$this, 'on_share_complete'], 10, 1);
    }

    public function override_bit_social_image($image, $post_id): string
    {
        $job = get_transient(Social_Queue_Manager::ACTIVE_JOB_TRANSIENT . (int) $post_id);
        if (!$job || empty($job['image_url'])) {
            return $image;
        }
        return (string) $job['image_url'];
    }

    public function override_bit_social_images($images, $post_id): array
    {
        $job = get_transient(Social_Queue_Manager::ACTIVE_JOB_TRANSIENT . (int) $post_id);
        if (!$job || empty($job['images'])) {
            return $images;
        }
        $count  = max(1, (int) ($job['image_count'] ?? 1));
        $result = array_values(array_slice((array) $job['images'], 0, $count));
        return !empty($result) ? $result : $images;
    }

    public function override_bit_social_message($message, $post_id): string
    {
        $job = get_transient(Social_Queue_Manager::ACTIVE_JOB_TRANSIENT . (int) $post_id);
        if (!$job || empty($job['message'])) {
            return $message;
        }
        return (string) $job['message'];
    }

    public function intercept_thumbnail_meta($value, $post_id, $meta_key, $single)
    {
        // @MODIFIED 2026-04-21 - Only intercept for BitSocial sharing context, NOT for general post display
        // This prevents social collage from becoming the post's featured image
        $intercept_keys = ['_yoast_wpseo_opengraph-image', 'rank_math_facebook_image'];

        // @MODIFIED 2026-04-21 - NEVER intercept _thumbnail_id - social collage is NOT the featured image
        if (!in_array($meta_key, $intercept_keys, true)) {
            return $value;
        }

        $job = get_transient(Social_Queue_Manager::ACTIVE_JOB_TRANSIENT . (int) $post_id);
        if (!$job || empty($job['images'])) {
            return $value;
        }

        // @MODIFIED 2026-04-21 - Removed _thumbnail_id interception completely
        // Social collage should NEVER be the post's featured image

        return $value;
    }

    public function inject_drip_image(array $post_data, int $post_id): array
    {
        $job = get_transient(Social_Queue_Manager::ACTIVE_JOB_TRANSIENT . $post_id);
        if ($job) {
            set_transient(
                Social_Queue_Manager::ACTIVE_JOB_TRANSIENT . $post_id,
                $job,
                30 * MINUTE_IN_SECONDS
            );

            if (!empty($job['image_url'])) {
                $post_data['image'] = $job['image_url'];
                $post_data['images'] = [$job['image_url']];
            }
            if (!empty($job['message'])) {
                $post_data['message'] = $job['message'];
                $post_data['content'] = $job['message'];
            }
            if (!empty($job['networks']) && !empty($post_data['accounts'])) {
                $post_data['accounts'] = array_filter(
                    $post_data['accounts'],
                    fn($a) => in_array(
                        strtolower($a['provider'] ?? $a['platform'] ?? ''),
                        $job['networks'],
                        true
                    )
                );
            }
            return $post_data;
        }

        $collage_id = (int) get_post_meta(
            $post_id,
            Social_Bootstrap::SOCIAL_IMAGE_META_KEY,
            true
        );
        if ($collage_id && ($url = wp_get_attachment_url($collage_id))) {
            $post_data['image'] = $url;
            $post_data['images'] = [$url];
        } else {
            $thumb_id = (int) get_post_thumbnail_id($post_id);
            if ($thumb_id && ($thumb_url = wp_get_attachment_url($thumb_id))) {
                $post_data['image'] = $thumb_url;
                $post_data['images'] = [$thumb_url];
            }
        }
        return $post_data;
    }

	public function on_share_complete(array $all_platform_data): void
	{
		$post_id = (int)($all_platform_data[0]['post_id']
			?? $all_platform_data['post_id']
			?? 0);

		if ($post_id === 0) {
			error_log('DIT TrendStudio: on_share_complete received invalid payload. Keys: ' . implode(', ', array_keys($all_platform_data)));
			return;
		}

		if ($post_id) {
			delete_transient(Social_Queue_Manager::ACTIVE_JOB_TRANSIENT . $post_id);
		}
	}
}
