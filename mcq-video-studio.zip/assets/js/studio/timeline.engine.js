(function (window) {
  'use strict';

  /**
   * MCQVS_TimelineEngine
   * Deterministic clock and scene selection.
   */
  class MCQVS_TimelineEngine {
    constructor() {
      this._frameMs = 33.333333333333336;
      this._totalMs = 0;

      this._running = false;
      this._basePerfMs = 0;
      this._baseTimelineMs = 0;
      this._timelineMs = 0;

      this._sceneCursor = 0;
    }

    configure(cfg) {
      if (!cfg) return;
      if (Number.isFinite(cfg.frameMs) && cfg.frameMs > 0) this._frameMs = cfg.frameMs;
      if (Number.isFinite(cfg.totalMs) && cfg.totalMs >= 0) this._totalMs = cfg.totalMs;
      this._sceneCursor = 0;
    }

    reset(ms) {
      this._timelineMs = this._clamp(ms || 0);
      this._baseTimelineMs = this._timelineMs;
      this._running = false;
    }

    start(perfNowMs) {
      this._running = true;
      this._basePerfMs = (typeof perfNowMs === 'number') ? perfNowMs : window.performance.now();
      this._baseTimelineMs = this._timelineMs;
    }

    stop() {
      if (this._running) {
        this._timelineMs = this.now(window.performance.now());
      }
      this._running = false;
    }

    seek(ms) {
      this._timelineMs = this._clamp(ms);
      this._baseTimelineMs = this._timelineMs;
      if (this._running) {
        this._basePerfMs = window.performance.now();
      }
    }

    now(perfNowMs) {
      const f = (typeof perfNowMs === 'number') ? perfNowMs : window.performance.now();
      if (!this._running) return this._quantize(this._timelineMs);

      const raw = this._baseTimelineMs + (f - this._basePerfMs);
      this._timelineMs = this._clamp(raw);
      return this._quantize(this._timelineMs);
    }

    frameMs() {
      return this._frameMs;
    }

    totalMs() {
      return this._totalMs;
    }

    getActiveScene(planScenes, timelineMs) {
      if (!Array.isArray(planScenes) || planScenes.length === 0) return null;

      const t = timelineMs;
      let i = this._sceneCursor;
      if (i >= planScenes.length) i = planScenes.length - 1;

      // Walk forward while we're past the end
      while (i < planScenes.length - 1 && t >= (planScenes[i].endMs - 0.0001)) i++;
      // Walk backward if we overshot
      while (i > 0 && t < planScenes[i].startMs) i--;

      this._sceneCursor = i;
      const s = planScenes[i];
      if (t >= s.startMs && t < (s.endMs - 0.0001)) return { scene: s, index: i };

      return null;
    }

    _quantize(ms) {
      const frame = this._frameMs;
      return Math.round(ms / frame) * frame;
    }

    _clamp(ms) {
      if (!Number.isFinite(ms)) return 0;
      if (ms < 0) return 0;
      if (this._totalMs > 0 && ms > this._totalMs) return this._totalMs;
      return ms;
    }
  }

  window.MCQVS_TimelineEngine = MCQVS_TimelineEngine;
})(window);
