<?php

/**
 * NewsAPI Provider
 *
 * Fetches trending articles from 150,000+ news sources via NewsAPI.org
 * Free tier: 100 requests/day
 *
 * @package DIT_TrendStudio\Sources
 * @since 1.5.0
 */

namespace DIT\TrendStudio\Sources;

use DIT\TrendStudio\Infrastructure\Logger;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * NewsAPI.org provider implementation
 *
 * @since 1.5.0
 */
class NewsAPI_Provider implements Source_Provider
{
    /**
     * Logger instance
     *
     * @var Logger
     * @since 1.5.0
     */
    private Logger $logger;

    /**
     * API key
     *
     * @var string
     * @since 1.5.0
     */
    private string $api_key;

    /**
     * Default keywords to search
     *
     * @var array
     * @since 1.5.0
     */
    private array $keywords = [
        'celebrity fashion',
        'beauty trends',
        'entertainment news',
    ];

    /**
     * Constructor
     *
     * @param Logger $logger Logger instance
     * @since 1.5.0
     */
    public function __construct(Logger $logger)
    {
        $this->logger = $logger;
        $this->api_key = get_option('dit_ts_newsapi_key', '');
    }

    /**
     * Get provider name
     *
     * @return string
     * @since 1.5.0
     */
    public function get_name(): string
    {
        return 'NewsAPI';
    }

    /**
     * Get provider type
     *
     * @return string
     * @since 1.5.0
     */
    public function get_type(): string
    {
        return 'newsapi';
    }

    /**
     * Check if provider is configured
     *
     * @return bool
     * @since 1.5.0
     */
    public function is_available(): bool
    {
        return !empty($this->api_key);
    }

    /**
     * Fetch trending articles from NewsAPI
     *
     * @param array $params Optional parameters (keywords can be overridden)
     * @return Idea_DTO[]
     * @throws \DIT\TrendStudio\Source_Exception On API error
     * @since 1.5.0
     */
    public function fetch_ideas(array $params = array()): array
    {
        if (!$this->is_available()) {
            $this->logger->warning('NewsAPI: API key not configured');
            return array();
        }

        $keywords = $params['keywords'] ?? $this->keywords;
        $ideas = array();

        foreach ($keywords as $keyword) {
            try {
                $articles = $this->fetch_articles_for_keyword($keyword);
                $ideas = array_merge($ideas, $articles);
            } catch (\Exception $e) {
                $this->logger->error(sprintf('NewsAPI: Error fetching articles for "%s": %s', $keyword, $e->getMessage()));
                // Continue with other keywords on error
                continue;
            }
        }

        $this->logger->info(sprintf('NewsAPI: Fetched %d articles', count($ideas)));
        return $ideas;
    }

    /**
     * Fetch articles for a specific keyword
     *
     * @param string $keyword Search keyword
     * @return Idea_DTO[]
     * @throws \Exception On API error
     * @since 1.5.0
     */
    private function fetch_articles_for_keyword(string $keyword): array
    {
        $url = sprintf(
            'https://newsapi.org/v2/everything?q=%s&sortBy=publishedAt&pageSize=5&language=en&apiKey=%s',
            urlencode($keyword),
            $this->api_key
        );

        $response = wp_remote_get($url, array(
            'timeout' => 15,
            'headers' => array(
                'User-Agent' => 'DIT-TrendStudio/1.5.0',
            ),
        ));

        if (is_wp_error($response)) {
            throw new \Exception('API request failed: ' . $response->get_error_message());
        }

        $status_code = wp_remote_retrieve_response_code($response);
        if ($status_code !== 200) {
            $body = wp_remote_retrieve_body($response);
            throw new \Exception(sprintf('API returned HTTP %d: %s', $status_code, $body));
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new \Exception('Invalid JSON response: ' . json_last_error_msg());
        }

        if (!isset($data['status']) || $data['status'] !== 'ok') {
            $error = $data['message'] ?? 'Unknown error';
            throw new \Exception('API error: ' . $error);
        }

        if (empty($data['articles'])) {
            return array();
        }

        return $this->convert_articles_to_ideas($data['articles'], $keyword);
    }

    /**
     * Convert NewsAPI articles to Idea DTOs
     *
     * @param array  $articles Raw articles from API
     * @param string $keyword  Search keyword used
     * @return Idea_DTO[]
     * @since 1.5.0
     */
    private function convert_articles_to_ideas(array $articles, string $keyword): array
    {
        $ideas = array();

        foreach ($articles as $article) {
            // Skip articles without required fields
            if (empty($article['title']) || empty($article['url'])) {
                continue;
            }

            $ideas[] = Idea_DTO::from_array(array(
                'title'         => sanitize_text_field($article['title']),
                'excerpt'       => sanitize_textarea_field($article['description'] ?? ''),
                'source_url'    => esc_url_raw($article['url']),
                'source_type'   => 'newsapi',
                'provider_name' => 'NewsAPI',
                'image_url'     => !empty($article['urlToImage']) ? esc_url_raw($article['urlToImage']) : '',
                'published_at'  => $article['publishedAt'] ?? gmdate('c'),
                'raw_data'      => array(
                    'author'       => $article['author'] ?? '',
                    'source_name'  => $article['source']['name'] ?? '',
                    'keyword'      => $keyword,
                ),
            ));
        }

        return $ideas;
    }
}
