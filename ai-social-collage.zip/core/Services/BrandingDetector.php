<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class BrandingDetector {
    const OPTION_BRAND_PATTERNS = 'ai_collage_brand_patterns';
    
    public function detect_branding( $image_path ) {
        $branding_elements = [];
        
        // Use AI to detect logos and watermarks
        $ai_result = $this->ai_detect_branding( $image_path );
        if ( ! empty( $ai_result['logos'] ) ) {
            $branding_elements['logos'] = $ai_result['logos'];
        }
        
        // Use pattern matching for common branding
        $pattern_matches = $this->pattern_detect_branding( $image_path );
        if ( ! empty( $pattern_matches ) ) {
            $branding_elements['patterns'] = $pattern_matches;
        }
        
        return $branding_elements;
    }
    
    private function ai_detect_branding( $image_path ) {
        $genAI = new GeminiProvider();
        $prompt = "
        Analyze this image and identify all branding elements including:
        - Logos and brand marks
        - Watermarks
        - Website URLs
        - Social media handles
        - Copyright notices
        - Brand colors and typography
        
        Return JSON with:
        {
            'logos': [
                {'position': 'top-left', 'confidence': 0.95, 'description': 'Instagram logo'},
                ...
            ],
            'text_elements': [
                {'text': '@username', 'position': 'bottom-right', 'type': 'handle'},
                ...
            ]
        }
        ";
        
        try {
            $result = AIProviderRegistry::execute( $genAI, '', $prompt, [
                'image_path' => $image_path,
                'caller' => 'BrandingDetector::ai_detect_branding',
            ] );
            Logger::info( Config::LOG_ACTION_AI_BRANDING_DETECTED, null, [
                'image_path' => $image_path,
                'elements_found' => count( $result['logos'] ?? [] ) + count( $result['text_elements'] ?? [] ),
            ], '200' );
            return $result;
        } catch ( \Exception $e ) {
            Logger::warning( 'ai_branding_detection_failed', null, [
                'image_path' => $image_path,
                'error' => $e->getMessage(),
            ], '500' );
            return [ 'logos' => [], 'text_elements' => [] ];
        }
    }
    
    private function pattern_detect_branding( $image_path ) {
        $branding_patterns = [
            '/instagram\.com/i' => 'Instagram URL',
            '/facebook\.com/i' => 'Facebook URL',
            '/twitter\.com/i' => 'Twitter URL',
            '@[a-zA-Z0-9_]{1,15}' => 'Social media handle',
            '©\s*\d{4}' => 'Copyright notice',
            '©\s*[A-Za-z0-9\s]+' => 'Copyright symbol',
            '/\d{4}\s*©/' => 'Year copyright',
        ];
        
        $results = [];
        $image_text = $this->extract_text_for_patterns( $image_path );
        
        foreach ( $branding_patterns as $pattern => $description ) {
            if ( preg_match_all( $pattern, $image_text, $matches ) ) {
                foreach ( $matches[0] as $match ) {
                    $results[] = [
                        'text' => $match,
                        'type' => $description,
                        'confidence' => 0.8,
                    ];
                }
            }
        }
        
        return $results;
    }
    
    private function extract_text_for_patterns( $image_path ) {
        // Simple text extraction for pattern matching
        // In production, this would use OCR or more sophisticated text detection
        $image_text = '';
        
        // Try to read image metadata for embedded text
        $exif_data = @exif_read_data( $image_path );
        if ( ! empty( $exif_data['ImageDescription'] ) ) {
            $image_text .= $exif_data['ImageDescription'] . ' ';
        }
        
        // Add filename as potential text
        $image_text .= basename( $image_path );
        
        return $image_text;
    }
}