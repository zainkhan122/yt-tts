<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) exit;

class VideoRenderer {

	private $processor;

	public function __construct() {
		$this->processor = new VideoProcessor();
	}

	/**
	 * Generate a video reel from a source video.
	 *
	 * @param array $job_data Job data array (same structure as ImageRenderer expects).
	 * @return array [ 'attachment_id' => int, 'r2_url' => string|false ]
	 */
	public function generate( array $job_data ): array {
		$start_time = microtime( true );

		$video_path = $this->resolve_video_path( $job_data );
		if ( empty( $video_path ) || ! file_exists( $video_path ) ) {
			throw new \Exception( 'Video file not found for job.' );
		}

		Logger::info( 'video_render_start', $job_data['job_id'] ?? 0, [
			'video' => basename( $video_path ),
		], '200' );

		$max_duration = (float) get_option( Config::OPTION_VIDEO_MAX_DURATION, Config::DEFAULT_VIDEO_MAX_DURATION );
		$reel_width = (int) get_option( Config::OPTION_VIDEO_REEL_WIDTH, Config::DEFAULT_VIDEO_REEL_WIDTH );
		$reel_height = (int) get_option( Config::OPTION_VIDEO_REEL_HEIGHT, Config::DEFAULT_VIDEO_REEL_HEIGHT );

		$temp_dir = AI_SOCIAL_COLLAGE_PATH . 'assets/temp';
		if ( ! is_dir( $temp_dir ) ) {
			wp_mkdir_p( $temp_dir );
		}
		$job_id = $job_data['job_id'] ?? 0;
		$prefix = 'video_reel_' . $job_id . '_' . uniqid();

		try {
			$working_video = $video_path;

			// Probe source orientation up-front so all downstream stages
			// (crop, scale, compose) can adapt. A wide (landscape) clip needs
			// different handling than a tall (portrait) IG reel.
			$source_dims    = $this->processor->get_video_dimensions( $working_video );
			$source_w       = $source_dims['width']  ?? 0;
			$source_h       = $source_dims['height'] ?? 0;
			$source_ar      = ( $source_w > 0 && $source_h > 0 ) ? ( $source_w / $source_h ) : 0.0;
			$is_landscape  = ( $source_ar > 1.0 );
			$is_portrait   = ( $source_ar > 0.0 && $source_ar < 1.0 );
			$is_squareish  = ( $source_ar > 0.0 && abs( $source_ar - 1.0 ) < 0.05 );

			Logger::info( 'video_source_probed', $job_id, [
				'source'       => $source_w . 'x' . $source_h,
				'aspect_ratio' => round( $source_ar, 3 ),
				'orientation'  => $is_landscape ? 'landscape' : ( $is_portrait ? 'portrait' : ( $is_squareish ? 'square' : 'unknown' ) ),
			], '200' );

			$duration = $this->processor->get_video_duration( $working_video );
			if ( $duration > $max_duration ) {
				$trimmed = $temp_dir . '/' . $prefix . '_trimmed.mp4';
				if ( $this->processor->trim_video( $working_video, $max_duration, $trimmed ) ) {
					$working_video = $trimmed;
					Logger::info( 'video_trimmed', $job_id, [
						'original_duration' => $duration,
						'max_duration' => $max_duration,
					], '200' );
				}
			}

			$campaign = $job_data['campaign'] ?? [];
			$logo_removal_enabled = ! empty( $campaign['video_logo_removal_enabled'] );
			$logo_zone = $campaign['video_logo_zone'] ?? null;
			if ( $logo_removal_enabled && is_array( $logo_zone )
				&& isset( $logo_zone['x'], $logo_zone['y'], $logo_zone['w'], $logo_zone['h'] )
				&& (float) $logo_zone['w'] > 0 && (float) $logo_zone['h'] > 0 ) {
				$logo_removed = $temp_dir . '/' . $prefix . '_logo_removed.mp4';
				if ( $this->processor->remove_logo_with_removelogo( $working_video, $logo_removed, $logo_zone ) ) {
					$working_video = $logo_removed;
					Logger::info( 'video_source_logo_removed', $job_id, [
						'zone' => $logo_zone,
					], '200' );
				} else {
					Logger::warning( 'video_source_logo_removal_skipped', $job_id, [
						'zone'     => $logo_zone,
						'fallback' => 'original_unchanged',
					], '500' );
				}
			} elseif ( $logo_removal_enabled ) {
				Logger::warning( 'video_source_logo_zone_missing', $job_id, [
					'fallback' => 'skip_removal',
				], '400' );
			}

			$video_zone_mode = $campaign['video_zone_mode'] ?? Config::VIDEO_ZONE_MODE_AUTO;
			$region = [ 'x' => 0.0, 'y' => 0.0, 'w' => 1.0, 'h' => 1.0 ];


			// Step 2: Determine content region
			//
			// Intelligence:
			//  - Portrait (tall) source + MANUAL zone: obey the user's crop region
			//    (the canvas expects this region to be cut from the source).
			//  - Landscape (wide) source + any mode: NEVER slice a portrait region
			//    out of it; we only digitize the content row. Once prerecord gets
			//    the letterbox path later, it would otherwise shrink the height
			//    into failure or distort the clip. Force the compose stage to do
			//    the (correct) letterbox fit. We still detect a sensible auto
			//    region for portrait clips.
			$skip_content_crop = false;
			if ( $video_zone_mode === Config::VIDEO_ZONE_MODE_MANUAL ) {
				$region = $campaign['video_content_zone'] ?? [ 'x' => 0.0, 'y' => 0.0, 'w' => 1.0, 'h' => 1.0 ];
				// Manual zones are always respected — the user explicitly
				// configured crop coordinates for this exact source. The crop
				// filter works on any orientation (portrait, landscape, square).
				Logger::info( 'video_manual_zone_applied', $job_id, [
					'region'     => $region,
					'orientation' => $is_landscape ? 'landscape' : ( $is_portrait ? 'portrait' : 'square' ),
					'source'     => $source_w . 'x' . $source_h,
				], '200' );
			} else {
				if ( $is_landscape || $is_squareish || $source_ar === 0.0 ) {
					// Skip auto-region detection on wide/unknown sources:
					// FrameAnalyzer is tuned for portrait content; on landscape
					// footage it frequently returns a strip that can't fill the
					// portrait reel region. Letterbox fit at compose time.
					$skip_content_crop = true;
					Logger::info( 'video_content_crop_skipped_orientation', $job_id, [
						'reason'      => 'Auto-region detection skipped for non-portrait source.',
						'orientation' => $is_landscape ? 'landscape' : ( $is_squareish ? 'square' : 'unknown' ),
					], '200' );
				} else {
					// Auto: AI detection only on portrait sources.
					$frames = $this->processor->extract_frames( $working_video, 3 );
					$region = FrameAnalyzer::analyze_frames( $frames );
					$this->cleanup_files( $frames );
				}
			}

			Logger::info( 'video_region_determined', $job_id, [
				'mode' => $video_zone_mode,
				'region' => $region,
				'skip_crop' => $skip_content_crop,
			], '200' );

			// Step 3: Crop video to content region (intelligently skipped above)
			$is_cropped = ( ! $skip_content_crop && ( $region['x'] !== 0.0 || $region['y'] !== 0.0 || $region['w'] !== 1.0 || $region['h'] !== 1.0 ) );
			if ( $is_cropped ) {
				$crop_px = [
					'x' => (int) round( $source_w * $region['x'] ),
					'y' => (int) round( $source_h * $region['y'] ),
					'w' => (int) round( $source_w * $region['w'] ),
					'h' => (int) round( $source_h * $region['h'] ),
				];
				Logger::info( 'video_crop_executing', $job_id, [
					'region'   => $region,
					'crop_px'  => $crop_px,
					'source'   => $source_w . 'x' . $source_h,
					'mode'     => $video_zone_mode,
				], '200' );
				$cropped = $temp_dir . '/' . $prefix . '_cropped.mp4';
				if ( $this->processor->crop_video( $working_video, $region, $cropped ) ) {
					$working_video = $cropped;
					Logger::info( 'video_content_cropped', $job_id, [
						'region' => $region,
						'crop_px' => $crop_px,
						'mode' => $video_zone_mode,
					], '200' );
				} else {
					Logger::warning( 'video_content_crop_failed', $job_id, [
						'region' => $region,
						'crop_px' => $crop_px,
						'mode' => $video_zone_mode,
						'error' => $this->processor->last_error,
					], '500' );
				}
			}

		// Square sources must NOT be width-scaled: a 1080x1080 square scaled
		// to width=1080 stays 1080x1080, and the compose stage's
		// force_original_aspect_ratio=increase,crop filter then distorts it
		// to fill the tall video_area_h, producing a vertically-stretched,
		// unwatchable reel. Pass the (possibly cropped) square through
		// unmodified; compose_reel uses the contain (letterbox) strategy
		// for square sources, preserving aspect ratio.
		$skip_scale = $is_squareish;
		if ( ! $skip_scale ) {
			$scaled = $temp_dir . '/' . $prefix . '_scaled.mp4';
			if ( ! $this->processor->scale_video( $working_video, $reel_width, $scaled ) ) {
				throw new \Exception( 'Video scale to ' . $reel_width . 'px failed: ' . $this->processor->last_error );
			}
			$working_video = $scaled;
		} else {
			Logger::info( 'video_scale_skipped_square', $job_id, [
				'reason'      => 'Square source left unscaled to preserve aspect ratio in compose stage.',
				'source'      => $source_w . 'x' . $source_h,
				'orientation' => 'square',
			], '200' );
		}

			$brand = $job_data['brand'] ?? Config::get_brand_settings();
			$language = $job_data['language'] ?? 'ur';
			$headline = $job_data['headline'] ?? '';

		$heading_path = '';
		if ( ! empty( $headline ) ) {
			$heading_font = $brand['font_headline'] ?? Config::DEFAULT_BRAND_FONT_HEADLINE;
			// Heading text color: use heading_text_color from brand settings,
			// falling back to secondary_color (white). The collage pipeline
			// uses the same cascade: heading_text_color → text_color → #ffffff.
			$heading_color = ! empty( $brand['heading_text_color'] )
				? $brand['heading_text_color']
				: ( ! empty( $brand['secondary_color'] ) ? $brand['secondary_color'] : '#ffffff' );
			// Heading background color: heading_bg_color → text_backing_color → transparent.
			$heading_bg_color = ! empty( $brand['heading_bg_color'] )
				? $brand['heading_bg_color']
				: ( ! empty( $brand['text_backing_color'] ) ? $brand['text_backing_color'] : '' );
			// Use the SAME adaptive font-size base as the Collage/Image pipeline,
			// then apply the same scale_factor (canvas / 1080) so the heading
			// proportions match the collage output exactly.
			$headline_len = mb_strlen( $headline, 'UTF-8' );
			$is_urdu_heading = ( $language === 'ur' );
			$base_heading_size = HtmlTemplateRenderer::compute_adaptive_font_size( $headline_len, $is_urdu_heading, 'headline' );
			$scale_factor = $reel_width / 1080.0;
			// Video heading uses Pango bold which renders visually larger than
			// the collage GD/Chromium path at the same nominal size. Apply a
			// correction factor so the heading occupies the same proportion of
			// the canvas as it does in image cards.
			// Increased from 0.65 to 0.80 for larger Urdu text (was 35% reduction, now 20%).
			$video_heading_mult = 0.80;
			// Heading font size is decoupled from the image collage pipeline:
			// 1. video_heading_font_size (video-only brand setting, if set)
			// 2. heading_font_size (legacy brand setting, backward compatible)
			// 3. adaptive base (same algorithm as collage, corrected for Pango)
			$user_heading_size = $brand['video_heading_font_size'] ?? '';
			if ( ! is_numeric( $user_heading_size ) || $user_heading_size === '' ) {
				$user_heading_size = $brand['heading_font_size'] ?? '';
			}
			if ( ! empty( $user_heading_size ) && is_numeric( $user_heading_size ) ) {
				$heading_size = (int) round( (float) $user_heading_size * $scale_factor );
			} else {
				$heading_size = (int) round( $base_heading_size * $scale_factor * $video_heading_mult );
			}

			// Heading max-width: canvas width minus horizontal padding.
			// Video-specific padding (video_heading_padding) takes precedence
			// over the shared heading_padding so collage tweaks never move the
			// video heading.
			$heading_padding_css = $brand['video_heading_padding'] ?? '';
			if ( $heading_padding_css === '' ) {
				$heading_padding_css = $brand['heading_padding'] ?? Config::DEFAULT_HEADING_PADDING;
			}
			$h_padding = $this->processor->parse_padding_h( $heading_padding_css, $reel_width, $reel_height );
			$heading_max_width = $reel_width - $h_padding['left'] - $h_padding['right'];

			// Heading bar height: video-only proportion takes precedence over
			// the shared heading_height_proportion (backward compatible).
			$heading_height_pct = floatval( $brand['video_heading_height_proportion'] ?? '' );
			if ( $heading_height_pct <= 0 ) {
				$heading_height_pct = floatval( $brand['heading_height_proportion'] ?? '25.0' );
			}
			$heading_bar_height = ( $heading_height_pct > 0 )
				? (int) round( $reel_height * $heading_height_pct / 100.0 )
				: 0;

			// Upward growth budget: on letterboxed (landscape/square) sources
			// the heading may grow into the black bars above the video content,
			// all the way to the canvas top minus vertical padding. Mirror
			// compose_reel's letterbox math so the fit is exact:
			//   pad_top(h) = (reel_h - h - brand_h - fitted_h) / 2
			// The cap is the h where pad_top reaches the required padding.
			// Portrait sources fill the video area (no black bars), so they
			// keep the bar-based cap (budget = 0).
			$heading_height_budget = 0;
			if ( ( $is_landscape || $is_squareish || $source_ar === 0.0 ) && $source_w > 0 && $source_h > 0 ) {
				$brand_bar_pct = floatval( $brand['brand_bar_height_pct'] ?? Config::DEFAULT_BRAND_BAR_HEIGHT_PCT );
				$brand_bar_h   = (int) round( $reel_height * $brand_bar_pct / 100.0 );
				$fitted_h      = (int) round( $source_h * ( $reel_width / $source_w ) );
				$v_padding     = $h_padding['top'] + $h_padding['bottom'];
				$heading_height_budget = max( 0, (int) round( $reel_height - $brand_bar_h - $fitted_h - ( 2 * $v_padding ) ) );
				Logger::info( 'video_heading_growth_budget', $job_id, [
					'brand_bar_h'  => $brand_bar_h,
					'fitted_h'     => $fitted_h,
					'v_padding'    => $v_padding,
					'budget'       => $heading_height_budget,
					'orientation'  => $is_landscape ? 'landscape' : ( $is_squareish ? 'square' : 'unknown' ),
				], '200' );
			}

			$heading_result = $this->fit_heading_to_area(
				$headline,
				$heading_font,
				$heading_size,
				$heading_color,
				$heading_max_width,
				$heading_bar_height,
				$language,
				$heading_bg_color,
				$reel_width,
				$is_urdu_heading,
				$job_id,
				$heading_height_budget
			);

			$heading_path = $heading_result['path'] ?? '';
			$heading_y_offset = $heading_result['y_offset'] ?? 0;

			if ( $heading_path ) {
				Logger::info( 'video_heading_rendered', $job_id, [
					'text'         => mb_substr( $headline, 0, 50 ),
					'font'         => $heading_font,
					'base_size'    => $base_heading_size,
					'scale_factor' => round( $scale_factor, 3 ),
					'video_mult'   => $video_heading_mult,
					'font_size'    => $heading_size,
				], '200' );
			} else {
				Logger::warning( 'video_heading_render_failed', $job_id, [
					'text' => mb_substr( $headline, 0, 50 ),
					'font' => $heading_font,
				], '500' );
			}
		}

			$brand_bar_path = $this->processor->render_brand_bar_to_png( $brand, $reel_width, $reel_height );

			// Top-corner logo overlay — mirrors the collage pipeline's draw_top_logo().
			$top_logo_path = '';
			$logo_position = $brand['logo_position'] ?? Config::DEFAULT_BRAND_LOGO_POSITION;
			if ( in_array( $logo_position, [ 'top-left', 'top-right' ], true ) && ! empty( $brand['logo_url'] ) ) {
				$top_logo_path = $this->processor->render_top_logo_png( $brand, $reel_width, $reel_height );
				if ( $top_logo_path ) {
					Logger::info( 'video_top_logo_rendered', $job_id, [
						'logo_position' => $logo_position,
						'output'        => basename( $top_logo_path ),
					], '200' );
				}
			}

		// Detect audio content type. Mute ONLY confidently-music source audio.
		// 'voice' (speech) and 'ambiguous' (grey-zone / mixed / undetectable)
		// are preserved as-is to avoid destroying real speech or producing a
		// silent video from a borderline classification.
		$audio_type = $this->processor->detect_audio_type( $video_path );
		$mute_audio = ( $audio_type === 'music' );
		Logger::info( 'video_audio_decision', $job_id, [
			'source'       => basename( $video_path ),
			'audio_type'   => $audio_type,
			'mute_audio'   => $mute_audio,
		], '200' );

		// When muting, always resolve a replacement track (falls back to the
		// bundled default so the reel is never left silent). Pass allow_fallback
		// so a missing configured file does not short-circuit to '' here.
		$replacement_music_path = Config::get_replacement_music_path( true );

		$output_path = $temp_dir . '/' . $prefix . '_reel.mp4';
		$composed = $this->processor->compose_reel(
			$working_video,
			$heading_path,
			$brand_bar_path,
			$reel_width,
			$reel_height,
			$output_path,
			$top_logo_path,
			$brand,
			$heading_y_offset,
			$mute_audio,
			$replacement_music_path,
			$logo_zone
		);

		if ( ! $composed || ! file_exists( $output_path ) ) {
			$detail = $this->processor->last_error;
			if ( $detail === '' ) {
				$detail = $composed
					? 'compose_reel returned success but output file is missing on disk.'
					: 'compose_reel returned false, no output produced.';
			}
			throw new \Exception( 'Video reel composition failed: ' . $detail );
		}

			$this->cleanup_files( array_filter( [ $heading_path, $brand_bar_path, $top_logo_path ] ) );

			$execution_time = microtime( true ) - $start_time;

			Logger::info( Config::LOG_ACTION_VIDEO_REEL_GENERATED, $job_id, [
				'output' => basename( $output_path ),
				'size' => filesize( $output_path ),
				'duration' => $this->processor->get_video_duration( $output_path ),
				'execution_time' => round( $execution_time, 2 ),
			], '200' );

$attachment_id = $this->sideload_video_to_media_library( $output_path, $job_data['post_id'] ?? 0 );

        // Note: R2 upload is now handled exclusively in PostObserver::on_publish_transition
        // to ensure it only happens when the post is actually published, not during rendering.
        // This prevents wasting R2 storage and bandwidth on videos for posts that remain draft.

		@unlink( $output_path );
		if ( $working_video !== $video_path && file_exists( $working_video ) ) {
			@unlink( $working_video );
		}

		return [
			'attachment_id' => $attachment_id,
			'r2_url'        => false,
		];

		} catch ( \Throwable $e ) {
			Logger::error( 'video_render_failed', $job_id, [
				'error' => $e->getMessage(),
				'file' => $e->getFile() . ':' . $e->getLine(),
			], '500' );

			$this->cleanup_files( [
				$temp_dir . '/' . $prefix . '_trimmed.mp4',
				$temp_dir . '/' . $prefix . '_logo_removed.mp4',
				$temp_dir . '/' . $prefix . '_cropped.mp4',
				$temp_dir . '/' . $prefix . '_scaled.mp4',
				$temp_dir . '/' . $prefix . '_reel.mp4',
			] );

			throw $e;
		}
	}

	/**
	 * Upload rendered video to R2 and update job with video_url.
	 */
	public function maybe_upload_to_r2( string $video_path, int $job_id, int $attachment_id ): false|string {
		if ( ! class_exists( 'AiSocialCollage\Services\R2Storage' ) ) {
			Logger::warning( 'r2_upload_skipped_class_missing', $job_id, [], '500' );
			return false;
		}

		$r2 = new \AiSocialCollage\Services\R2Storage();
		$extension = pathinfo( $video_path, PATHINFO_EXTENSION );
		$key       = 'videos/' . $job_id . '/' . $attachment_id . '_' . time() . '.' . $extension;
		$mime_type = 'application/octet-stream'; // Default MIME type
		if ( function_exists( 'mime_content_type' ) ) {
			$mime_type = mime_content_type( $video_path );
		}

		// Shutdown handler: detect worker death (PHP max_execution_time, AS timeout, OOM)
		// so a silent abort writes a log row instead of leaving the job stuck.
		$abort_marker = 'r2_upload_in_progress_' . $job_id;
		set_transient( $abort_marker, time(), 600 );
		register_shutdown_function( function () use ( $abort_marker, $job_id, $key ) {
			if ( false !== get_transient( $abort_marker ) ) {
				Logger::error( 'r2_upload_aborted', $job_id, [
					'key'      => $key,
					'evidence' => 'shutdown_function fired while r2_upload_in_progress transient still set — worker died mid-upload',
				], '500' );
				delete_transient( $abort_marker );
			}
		} );

		Logger::info( 'r2_upload_start', $job_id, [
			'video_path' => $video_path,
			'key'        => $key,
			'mime_type'  => $mime_type,
		], '200' );

		$prev_time_limit = 0;
		if ( function_exists( 'set_time_limit' ) && (int) @ini_get( 'max_execution_time' ) > 0 ) {
			$prev_time_limit = (int) @ini_get( 'max_execution_time' );
			@set_time_limit( 180 );
		}

		try {
			$result = $r2->upload_file( $video_path, $key, $mime_type );
		} catch ( \Throwable $e ) {
			delete_transient( $abort_marker );
			Logger::error( 'r2_upload_exception', $job_id, [
				'error' => $e->getMessage(),
				'class' => get_class( $e ),
				'file'  => $e->getFile() . ':' . $e->getLine(),
			], '500' );
			if ( $prev_time_limit > 0 && function_exists( 'set_time_limit' ) ) {
				@set_time_limit( $prev_time_limit );
			}
			return false;
		} finally {
			if ( $prev_time_limit > 0 && function_exists( 'set_time_limit' ) ) {
				@set_time_limit( $prev_time_limit );
			}
		}

		if ( is_wp_error( $result ) ) {
			delete_transient( $abort_marker );
			Logger::error( 'r2_upload_failed', $job_id, [
				'error' => $result->get_error_message(),
				'key' => $key,
			], '500' );
			return false;
		}

		if ( ! is_string( $result ) || $result === '' ) {
			delete_transient( $abort_marker );
			Logger::error( 'r2_upload_empty_result', $job_id, [
				'key'    => $key,
				'result' => var_export( $result, true ),
			], '500' );
			return false;
		}

		delete_transient( $abort_marker );

		// Update job with R2 URL
		if ( class_exists( 'AiSocialCollage\Database\JobManager' ) ) {
			\AiSocialCollage\Database\JobManager::update_job_fields( $job_id, [
				'video_url' => $result,
			] );
		}

		// Also store in attachment meta for reference
		update_post_meta( $attachment_id, '_ai_collage_r2_url', $result );

		Logger::info( Config::LOG_ACTION_R2_UPLOAD, $job_id, [
			'url' => $result,
			'key' => $key,
			'attachment_id' => $attachment_id,
		], '200' );

		return $result;
	}

	/**
	 * Resolve the video file path from job data.
	 */
	private function resolve_video_path( array $job_data ): string {
		if ( ! empty( $job_data['video_path'] ) && file_exists( $job_data['video_path'] ) ) {
			return $job_data['video_path'];
		}

		$post_id = $job_data['post_id'] ?? 0;
		if ( $post_id > 0 ) {
			$attachments = get_posts( [
				'post_type' => 'attachment',
				'post_parent' => $post_id,
				'post_mime_type' => 'video',
				'posts_per_page' => 1,
				'orderby' => 'menu_order',
				'order' => 'ASC',
			] );

			if ( ! empty( $attachments ) ) {
				$path = get_attached_file( $attachments[0]->ID );
				if ( $path && file_exists( $path ) ) {
					return $path;
				}
			}
		}

		if ( ! empty( $job_data['image_url'] ) && VideoProcessor::is_video_file( $job_data['image_url'] ) ) {
			$path = $job_data['image_url'];
			if ( file_exists( $path ) ) {
				return $path;
			}
		}

		return '';
	}

	/**
	 * Sideload video to WordPress media library.
	 */
	private function sideload_video_to_media_library( string $file_path, int $post_id ): int {
		if ( ! function_exists( 'media_handle_sideload' ) ) {
			require_once( ABSPATH . 'wp-admin/includes/media.php' );
			require_once( ABSPATH . 'wp-admin/includes/file.php' );
			require_once( ABSPATH . 'wp-admin/includes/image.php' );
		}

		$file_array = [
			'name' => basename( $file_path ),
			'tmp_name' => $file_path,
		];

		$attachment_id = media_handle_sideload( $file_array, $post_id );

		if ( is_wp_error( $attachment_id ) ) {
			throw new \Exception( 'Failed to attach video to Media Library: ' . $attachment_id->get_error_message() );
		}

		update_post_meta( $attachment_id, Config::META_IS_AI_COLLAGE, '1' );
		update_post_meta( $attachment_id, Config::META_CONTENT_TYPE, Config::CONTENT_TYPE_VIDEO );

		return $attachment_id;
	}

	/**
	 * Clean up temporary files.
	 */
	private function cleanup_files( array $files ): void {
		foreach ( $files as $f ) {
			if ( ! empty( $f ) && file_exists( $f ) ) {
				@unlink( $f );
			}
		}
	}

	/**
	 * Intelligently render a heading that fits within the heading area.
	 *
	 * Iteratively reduces font size until the rendered text fits within
	 * `max_width` AND `bar_height`. Long Urdu text (which often wraps to
	 * multiple lines) is the primary driver — without this loop, long
	 * headlines get clipped at the top/bottom or extend past the bar.
	 *
	 * Returns array with 'path' and 'y_offset' (pixels to shift heading UP
	 * from default position to center it vertically in the allocated bar height).
	 *
	 * @param string $text       Headline text.
	 * @param string $font       Font family.
	 * @param int    $start_size Starting font size in pixels.
	 * @param string $color      Text color.
	 * @param int    $max_width  Maximum text width in pixels.
	 * @param int    $bar_height Maximum bar height in pixels (allocated space).
	 * @param string $language   'en' or 'ur'.
	 * @param string $bg_color   Optional background color.
	 * @param int    $canvas_w   Canvas width for bg bar.
	 * @param bool   $is_urdu    True for Urdu/RTL text.
	 * @param int    $job_id     Job ID for logging.
	 * @param int    $height_budget Max heading height in pixels from the
	 *                              letterbox geometry (0 = fall back to the
	 *                              bar-height cap for portrait/no-bars sources).
	 * @return array|false ['path' => string, 'y_offset' => int] or false.
	 */
	private function fit_heading_to_area(
		string $text,
		string $font,
		int $start_size,
		string $color,
		int $max_width,
		int $bar_height,
		string $language,
		string $bg_color,
		int $canvas_w,
		bool $is_urdu,
		int $job_id,
		int $height_budget = 0
	) {
		// Minimum font size — never go below this. Pango/Urdu becomes
		// illegible below ~24px on a 1080-wide canvas.
		$min_size     = max( 18, (int) round( $start_size * 0.5 ) );
		$current_size = $start_size;
		$attempt      = 0;
		$max_attempts = 8;
		$best_path    = false;
		$best_rendered_h = 0;

		while ( $attempt < $max_attempts && $current_size >= $min_size ) {
			$path = $this->processor->render_text_to_png(
				$text,
				$font,
				$current_size,
				$color,
				$max_width,
				$language,
				$bg_color,
				$bar_height,
				$canvas_w
			);

			if ( ! $path ) {
				return false;
			}

		// Measure rendered output against constraints.
		$info = @getimagesize( $path );
		if ( ! $info ) {
			$this->cleanup_files( [ $path ] );
			return false;
		}
		$rendered_w = (int) $info[0];
		$rendered_h = (int) $info[1];

		// Fit policy:
		//  - Width is HARD (overflow clips text horizontally).
		//  - Height: when height_budget > 0 (letterboxed landscape/square
		//    sources) the heading may grow into the black bars up to the
		//    canvas top minus padding — the budget IS the physical limit.
		//  - When height_budget = 0 (portrait video, no black bars) the bar
		//    cap is SOFT (bar can grow up to 25% over height_proportion
		//    to preserve readability; the bar is composited into a fixed
		//    background by heading_composite_on_background() which uses
		//    max(override, text_h), so a slight overflow expands the bar
		//    rather than clipping the text). Without this slack the loop
		//    shrinks to ~50% of intended size, producing illegible Urdu
		//    Nastaliq that the user sees as "font too small".
		$effective_max_width = ! empty( $bg_color ) ? $canvas_w : $max_width;
		$width_ok     = ( $rendered_w <= ( $effective_max_width + 4 ) );
		if ( $height_budget > 0 ) {
			$height_ok = ( $rendered_h <= $height_budget );
		} else {
			$height_ok = ( $bar_height <= 0 ) || ( $rendered_h <= (int) round( $bar_height * 1.25 ) );
		}

		if ( $width_ok && $height_ok ) {
			Logger::info( 'video_heading_fit_success', $job_id, [
				'font_size'    => $current_size,
				'attempts'     => $attempt + 1,
				'rendered'     => $rendered_w . 'x' . $rendered_h,
				'constraints'  => $max_width . 'x' . ( $height_budget > 0 ? $height_budget : $bar_height ),
				'lang'         => $language,
				'fit_mode'     => $height_budget > 0 ? 'geometry' : 'bar',
			], '200' );
			// Geometry mode: heading sits flush above the video content and
			// grows upward into the black bars; no bar-based centering.
			// Bar mode: center heading vertically in allocated bar_height.
			$y_offset = ( $height_budget > 0 )
				? 0
				: ( ( $bar_height > 0 && $rendered_h < $bar_height )
					? (int) round( ( $bar_height - $rendered_h ) / 2 )
					: 0 );
			return [ 'path' => $path, 'y_offset' => $y_offset ];
		}

		// Keep track of best attempt for fallback.
		if ( $width_ok && ( ! $best_path || $rendered_h < $best_rendered_h ) ) {
			$best_path = $path;
			$best_rendered_h = $rendered_h;
		} else {
			$this->cleanup_files( [ $path ] );
		}

		// Reduce size and retry. Urdu is reduced more aggressively
		// since Nastaliq ligatures grow tall quickly.
		$reduction = $is_urdu ? 0.85 : 0.90;
		$current_size = (int) round( $current_size * $reduction );
		$current_size = max( $current_size, $min_size - 1 );
		$attempt++;
	}

		// Exhausted retries — return best attempt so caller at least has
		// something rather than a blank heading.
		Logger::warning( 'video_heading_fit_exhausted', $job_id, [
			'start_size' => $start_size,
			'final_size' => $current_size,
			'attempts'   => $attempt,
			'lang'       => $language,
		], '500' );

		$fallback_path = $this->processor->render_text_to_png(
			$text,
			$font,
			max( $current_size, $min_size ),
			$color,
			$max_width,
			$language,
			$bg_color,
			$bar_height,
			$canvas_w
		);

		if ( $fallback_path ) {
			$info = @getimagesize( $fallback_path );
			$rendered_h = $info ? (int) $info[1] : 0;
			$y_offset = ( $height_budget > 0 )
				? 0
				: ( ( $bar_height > 0 && $rendered_h < $bar_height )
					? (int) round( ( $bar_height - $rendered_h ) / 2 )
					: 0 );
			return [ 'path' => $fallback_path, 'y_offset' => $y_offset ];
		}

		return false;
	}
}
