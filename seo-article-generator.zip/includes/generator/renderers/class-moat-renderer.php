<?php

namespace SEO_Article_Generator\Generator\Renderers;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Handles rendering of Moat content (user value section)
 */
class Moat_Renderer
{
    use \SEO_Article_Generator\Traits\Markdown_Processor;

    /**
     * Render the Moat content
     *
     * @param array $moat_data Moat data from AI
     * @return string HTML
     */
    public function render($moat_data)
    {
        return serialize_blocks($this->render_blocks($moat_data));
    }

    /**
     * Render the Moat content as block array.
     *
     * @param array $moat_data Moat data from AI
     * @return array Block array
     */
    public function render_blocks($moat_data)
    {
        if (empty($moat_data) || empty($moat_data['content'])) {
            return array();
        }

        $inner_blocks = array();

        // Use a generic heading if not provided
        $main_heading = !empty($moat_data['heading']) ? $moat_data['heading'] : 'Quick Start & Pro Tips';

        $inner_blocks[] = array(
            'blockName'    => 'core/heading',
            'attrs'        => array('level' => 2, 'anchor' => 'moat-content'),
            'innerBlocks'  => array(),
            'innerHTML'    => '<h2 class="wp-block-heading" id="moat-content">' . \wp_kses_post(self::process_markdown($main_heading)) . '</h2>',
            'innerContent' => array('<h2 class="wp-block-heading" id="moat-content">' . \wp_kses_post(self::process_markdown($main_heading)) . '</h2>'),
        );

        $content = $moat_data['content'];

        if (is_array($content)) {
            $why_prefixes = array('How This Would Help', 'Reason To Do This', 'Explanation', 'Why');
            $why_prefix = $why_prefixes[array_rand($why_prefixes)];

            // Cap at 3 items to enforce 1-3 target max
            $content = array_slice($content, 0, 3, true);

            foreach ($content as $item) {
                // Handle object structure (heading, recipe, why)
                if (is_array($item) && (isset($item['heading']) || isset($item['recipe']))) {
                    $item_heading = isset($item['heading']) ? $item['heading'] : '';
                    $recipe = isset($item['recipe']) ? $item['recipe'] : '';
                    $why = isset($item['why']) ? $item['why'] : '';

                    if ($item_heading === '') {
                        $item_heading = 'Pro Tip';
                    }

                    if ($item_heading) {
                        $inner_blocks[] = array(
                            'blockName'    => 'core/heading',
                            'attrs'        => array('level' => 3),
                            'innerBlocks'  => array(),
                            'innerHTML'    => '<h3 class="wp-block-heading">' . \wp_kses_post(self::process_markdown($item_heading)) . '</h3>',
                            'innerContent' => array('<h3 class="wp-block-heading">' . \wp_kses_post(self::process_markdown($item_heading)) . '</h3>'),
                        );
                    }

                    if ($recipe) {
                        // Convert newlines to list items if it looks like a list
                        if (strpos($recipe, "\n") !== false || preg_match('/^\d+\./', $recipe)) {
                            $lines = explode("\n", $recipe);
                            $list_items = array();
                            foreach ($lines as $line) {
                                $clean_line = trim(preg_replace('/^\d+\.\s*/', '', $line));
                                if ($clean_line) {
                                    $html_item = '<li>' . \wp_kses_post(self::process_markdown($clean_line)) . '</li>';
                                    $list_items[] = array(
                                        'blockName'    => 'core/list-item',
                                        'attrs'        => array(),
                                        'innerBlocks'  => array(),
                                        'innerHTML'    => $html_item,
                                        'innerContent' => array($html_item),
                                    );
                                }
                            }

                            if (!empty($list_items)) {
                                $inner_html = serialize_blocks($list_items);
                                $inner_blocks[] = array(
                                    'blockName'    => 'core/list',
                                    'attrs'        => array('ordered' => true),
                                    'innerBlocks'  => $list_items,
                                    'innerHTML'    => '<ol>' . $inner_html . '</ol>',
                                    'innerContent' => array('<ol>' . $inner_html . '</ol>'),
                                );
                            }
                        } else {
                            $html = '<p>' . \wp_kses_post(self::process_markdown($recipe)) . '</p>';
                            $inner_blocks[] = array(
                                'blockName'    => 'core/paragraph',
                                'attrs'        => array(),
                                'innerBlocks'  => array(),
                                'innerHTML'    => $html,
                                'innerContent' => array($html),
                            );
                        }
                    }

                    if ($why) {
                        $html = '<p style="font-style:italic"><strong>' . \esc_html($why_prefix) . ':</strong> ' . \wp_kses_post(self::process_markdown($why)) . '</p>';
                        $inner_blocks[] = array(
                            'blockName'    => 'core/paragraph',
                            'attrs'        => array('style' => array('typography' => array('fontStyle' => 'italic'))),
                            'innerBlocks'  => array(),
                            'innerHTML'    => $html,
                            'innerContent' => array($html),
                        );
                    }
                }
                // Handle simple string content (fallback)
                elseif (is_string($item)) {
                    $html = '<p>' . \wp_kses_post(self::process_markdown($item)) . '</p>';
                    $inner_blocks[] = array(
                        'blockName'    => 'core/paragraph',
                        'attrs'        => array(),
                        'innerBlocks'  => array(),
                        'innerHTML'    => $html,
                        'innerContent' => array($html),
                    );
                }
            }
        } elseif (is_string($content)) {
            // Very rare case, treat as raw HTML / blocks if possible
            $parsed = parse_blocks($content);
            if (!empty($parsed) && $parsed[0]['blockName'] !== null) {
                $inner_blocks = array_merge($inner_blocks, $parsed);
            } else {
                $html = '<p>' . \wp_kses_post($content) . '</p>';
                $inner_blocks[] = array(
                    'blockName'    => 'core/paragraph',
                    'attrs'        => array(),
                    'innerBlocks'  => array(),
                    'innerHTML'    => $html,
                    'innerContent' => array($html),
                );
            }
        }

        $inner_html = serialize_blocks($inner_blocks);

        return array(
            array(
                'blockName'    => 'core/group',
                'attrs'        => array(
                    'className' => 'seo-gen-moat-content',
                    'metadata'  => array('name' => 'Moat Content'),
                    'layout'    => array('type' => 'constrained'),
                ),
                'innerBlocks'  => $inner_blocks,
                'innerHTML'    => '<div class="wp-block-group seo-gen-moat-content">' . $inner_html . '</div>',
                'innerContent' => array('<div class="wp-block-group seo-gen-moat-content">' . $inner_html . '</div>'),
            )
        );
    }
}
