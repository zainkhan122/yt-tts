<?php
/**
 * Plugin Name: DIT Fashion Posts Generator
 * Description: Secure, self-contained generator — one draft post per designer collection line (Shopify stores, auto brand discovery) or per WooCommerce category. Settings screen, run-lock, time-budgeted runs, HTML sanitizer, srcset control, cleanup tools. No custom tables.
 * Version: 3.5.8
 * Author: (you)
 * License: GPL-2.0-or-later
 * Requires at least: 5.8
 * Requires PHP: 7.4
 *
 * ------------------------------------------------------------------
 * INSTALL (live site)
 * ------------------------------------------------------------------
 * 1. Copy this file to:  wp-content/plugins/collection-post-generator/
 *   collection-post-generator.php   (a folder with just this file)
 * 2. Plugins → activate "DIT Fashion Posts Generator".
 * 3. Settings → DIT Fashion PG → configure → "Run now".
 *
 * It runs itself every 6 hours via WP-Cron while active.
 * DEACTIVATE = full pause (cron unscheduled; state kept).
 *
 * Sources (which stores to track) are defined in cpg_default_sources()
 * below — the only thing you ever edit in this file. Everything else
 * is controlled from Settings → DIT Fashion PG.
 * ------------------------------------------------------------------
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* =====================================================================
 * INTERNAL CONSTANTS (do not change unless you know why)
 * =================================================================== */

define( 'CPG_CRON', 'cpg_cron_event' );
define( 'CPG_VERSION', '3.5.8' );
define( 'CPG_INTERVAL', 6 * HOUR_IN_SECONDS );
define( 'CPG_TIME_BUDGET', 150 );     // v3.5.6: was 45 — 2s pacing between feeds needs headroom
if ( ! defined( 'CPG_FETCH_GAP' ) ) {
	define( 'CPG_FETCH_GAP', 2 );       // v3.5.6: min seconds between HTTP requests (bursts look bot-like)
}
if ( ! defined( 'CPG_FETCH_RETRY' ) ) {
	define( 'CPG_FETCH_RETRY', 5 );     // v3.5.6: wait before the single retry of a failed fetch (0 = retry immediately)
}
define( 'CPG_LOCK_SECONDS', 600 );    // concurrent-run lock
define( 'CPG_IDS_MEMORIZED', 120 );   // max product IDs memorized per line
/* v3.5.6: browser-like UA. Diagnosed 2026-10-01: the live host's requests to
 * Sanaulla were fast-rejected ~90% of the time (2 of 21 got through) while the same
 * feeds answered every request from elsewhere — Cloudflare bot scoring at the host
 * IP. A non-browser UA hands it a free bot signal. */
define( 'CPG_UA', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36' );

/* =====================================================================
 * DEFAULT SETTINGS (overridable from the admin screen)
 * =================================================================== */

function cpg_defaults() {
	return array(
		'paused'          => 0,          // 1 = cron does nothing
		'post_status'     => 'draft',    // draft | pending | publish
		'category'        => 'for-fashion',
		'max_dresses'     => 15,
		'img_per_dress'   => 1,
		'min_dresses'     => 5,          // lines with fewer dresses are skipped
		'age_days'        => 0,          // 0 = no age filter
		'brands_per_run'  => 10,
		'img_width'       => 600,
		'max_posts_run'   => 1,          // max NEW posts per run (0 = unlimited)
		'max_posts_day'   => 2,          // max NEW posts per day (0 = unlimited)
		'sideload_all'    => 1,          // 1 = download ALL images locally (default)
		'link_collection' => 0,          // 1 = small source link at END of post
		'strip_srcset'    => 1,          // 1 = no srcset/sizes on our images (front-end)
		'respect_deletion'=> 1,          // deleted draft = rejected line
		'prune_days'      => 90,
		'desc_chars'      => 400,
		'brand_footer'    => 1,          // 1 = append brand site/Instagram line
		'brand_links'     => '',         // custom map (pipe format); empty = built-in map
		'proxy_provider'  => '',         // v3.5.8: primary proxy provider id ('' = off) — fallback only, after direct+retry fail
		'proxy_key'       => '',         // v3.5.8: primary provider API key
		'proxy_premium'   => 0,          // v3.5.7: 1 = ZenRows premium_proxy (10 credits/fetch); 0 = standard (1 credit)
		'proxy_provider2' => '',         // v3.5.8: backup provider — tried when the primary fails
		'proxy_key2'      => '',         // v3.5.8: backup provider API key
		'proxy_custom'    => '',         // v3.5.8: custom relay template containing {URL} (e.g. own Cloudflare Worker)
	);
}


/* =====================================================================
 * BRAND LINK MAP (v3.4) — appends the brand's own Website + Instagram
 * to generated posts. NEVER links sanaullastore.com.
 * =================================================================== */

function cpg_default_brand_links() {
	// handle | Display Name | Website | Instagram   (verified 2026-08-31)
	return <<<MAP
abaan-zohan | Abaan Zohan |  | https://www.instagram.com/abaanzohan/
abyaan | Abyaan | https://aabyaan.com/ | https://www.instagram.com/aabyaanofficial/
afrozeh | Afrozeh | https://www.afrozeh.com | https://www.instagram.com/afrozehofficial/
aik | Aik | https://aik.store | https://www.instagram.com/aikatelier/
aisha-fatema | Aisha Fatema |  | https://www.instagram.com/aishafatemaofficial/
ajr-couture-abbas-jamil-rajpoot | AJR Couture | https://ajrcouture.com | https://www.instagram.com/ajrcouture/
al-siyaab | Al Siyaab | https://alsiyaab.com | https://www.instagram.com/alsiyaab09/
al-zohaib | Al Zohaib | https://alzohaibstore.com | https://www.instagram.com/alzohaibtextile/
alee-malic | Alee Malic | https://aleemalic.com | https://www.instagram.com/aleemalicatelier/
alizeh-fashion | Alizeh | https://www.alizeh.pk | https://www.instagram.com/alizehfashionofficial/
amal | Amal | https://amal.com | https://www.instagram.com/amal.comofficial/
anayra-amal | Anayra Amal | https://www.anayraamal.com | https://www.instagram.com/anayraamal/
annus-abrar | Annus Abrar | https://www.annusabrar.net | https://www.instagram.com/annusabrar/
asifa-nabeel | Asifa & Nabeel | https://asifaandnabeel.pk | https://www.instagram.com/asifanabeel/
asim-jofa | Asim Jofa | https://asimjofa.com | https://www.instagram.com/asimjofa/
atiya-irfan-studio | Atiya Irfan Studio | https://atiyairfan.com | https://www.instagram.com/atiyairfanstudio/
avyana | Avyana |  | https://www.instagram.com/avyanapk/
ayesha-closet | Ayesha Closet |  | https://www.instagram.com/ayeshascloset.pk/
ayla-studio | Ayla Studio | https://www.aylastudio.com | https://www.instagram.com/aylastudio_official/
aylin-1 | Aylin |  | https://www.instagram.com/aylinfashions.official/
ayzel-by-afrozeh | Ayzel | https://ayzel.pk | https://www.instagram.com/ayzelonline/
azure | Azure | https://www.azureofficial.pk | https://www.instagram.com/azureofficial.pk/
azzal-by-ayesha-usman | Ayesha & Usman | https://ayeshaandusman.com | https://www.instagram.com/ayeshaandusman/
baby-nest | Baby Nest |  | https://www.instagram.com/babynest.pk/
banafsheh | Banafsheh |  | https://www.instagram.com/wearbanafsheh/
bareeq | Bareeq |  | https://www.instagram.com/bareeqofficial/
baroque | Baroque | https://baroque.pk | https://www.instagram.com/baroque_official/
beechtree | Beechtree | https://beechtree.pk | https://www.instagram.com/beechtree_pk/
bibayas | Bibayas |  | https://www.instagram.com/bibayaas/
bin-ilyas | Bin Ilyas | https://binilyas.com | https://www.instagram.com/binilyasofficial/
bin-saeed | Bin Saeed | http://binsaeedfabric.com | https://www.instagram.com/binsaeedfabrics/
brumano | Brumano | https://shopbrumano.com | https://www.instagram.com/shopbrumano/
buraq | Buraq Fabrics | https://buraqfabrics.com | https://www.instagram.com/buraqfabrics.official/
chandan-nagri | Chandan Nagri | https://chandan.pk | https://www.instagram.com/chandannagriofficial/
charizma | Charizma | https://houseofcharizma.com | https://www.instagram.com/charizma_official/
coco-by-zara-shahjahan | Coco by Zara Shahjahan | https://www.cocobyzarashahjahan.com | https://www.instagram.com/cocobyzarashahjahan/
crimson | Crimson | https://www.crimson.com.pk | https://www.instagram.com/crimsonpakistan/
cross-stitch | Cross Stitch | https://crossstitch.pk | https://www.instagram.com/crossstitch_official/
cyanic | Cyanic |  | https://www.instagram.com/cyanicofficial.pk/
daak-co | Daak & Co |  | https://www.instagram.com/daakandco/
damask-clothing-studio | Damask Clothing Studio |  | https://www.instagram.com/damaskclothingstudio/
daria-clothing | Daria Clothing | https://dariaclothing.com | https://www.instagram.com/dariaclothing.pk_/
deck-up | Deck Up | https://deckupclothing.com | https://www.instagram.com/deckupclothing/
dhaga | Dhaga | https://dhaga.com.pk | https://www.instagram.com/dhagaofficialstore/
dhanak | Dhanak | https://www.dhanak.com.pk | https://www.instagram.com/dhanak.official/
diara-couture | Diara Couture | https://diaracouture.com | https://www.instagram.com/diaracouture/
divinely-crafted | Divinely Crafted | https://divinelycrafted.org | https://www.instagram.com/_divinely.crafted/
edge-republic | Edge Republic | https://edge.pk | https://www.instagram.com/edgerepublicofficial/
edowlark | Edowlark | https://edowlark.com | https://www.instagram.com/edowlark/
eileen | Eileen | https://eileen.pk | https://www.instagram.com/eileenofficialstudio/
elaf | Elaf |  | https://www.instagram.com/elafofficialpk/
elan | Elan | https://elan.pk | https://www.instagram.com/elanofficial/
eleshia | Eleshia | https://eleshia.pk | https://www.instagram.com/eleshia.official/
emaan-adeel | Emaan Adeel | https://emaanadeel.com | https://www.instagram.com/emaanadeelfashion/
erum-khan | Erum Khan | https://erumkhanstores.com | https://www.instagram.com/erumkhancouture/
esmel | Esmel | https://esmelofficial.com | https://www.instagram.com/esmelofficial/
esra-fashion | Esra |  | https://www.instagram.com/esrafashion.pk/
fabiha-fatima | Fabiha Fatima | https://www.fabihafatima.pk | https://www.instagram.com/fabihafatima.official/
fabrich | Fabrich |  | https://www.instagram.com/fabrichofficialstore/
faiza-faisal | Faiza Faisal | https://faizafaisal.com | https://www.instagram.com/faizafaisalofficial/
faiza-saqlain | Faiza Saqlain | https://faizasaqlain.pk | https://www.instagram.com/faizasaqlain/
farah-talib | Farah Talib Aziz | https://www.farahtalibaziz.com.pk | https://www.instagram.com/farahtalibaziz/
feathers | Feathers | https://feathers.pk | https://www.instagram.com/feathers.com.pk/
florent | Florent | https://florentpakistan.com | https://www.instagram.com/florentpk/
fozia-khalid | Fozia Khalid | https://foziakhalid.com | https://www.instagram.com/foziakhalid_official/
freesia-premium | Freesia Premium | https://www.freesiapremium.com | https://www.instagram.com/freesiapremium/
fresh-birds | Fresh Birds |  | https://www.instagram.com/freshbirds/
garnet-clothing-pret | Garnet Clothing | https://garnetclothing.com | https://www.instagram.com/shop_garnet/
gem-garments | Gem Garments | https://www.gemgarments.com | https://www.instagram.com/gemgarments/
gul-ahmed | Gul Ahmed | https://www.gulahmedshop.com | https://www.instagram.com/gulahmedfashion/
gulaal | Gulaal | https://gulaal.pk | https://www.instagram.com/gulaalofficial/
gulmina | Gulmina | https://gulmina.pk | https://www.instagram.com/gulminaofficial/
hanim | Hanim | https://hanimofficial.com | https://www.instagram.com/hanim__official/
hareem-fatima | Hareem Fatima | https://hareemfatima.pk | https://www.instagram.com/hareemfatimaonline/
huma-gul | Huma Gul | https://humagul.pk | https://www.instagram.com/humagulofficial/
humdum | Humdum | https://humdum.pk | https://www.instagram.com/humdumcollection/
hussain-rehar | Hussain Rehar | https://hussainrehar.com | https://www.instagram.com/hussainrehar.official/
hz | HZ Textiles | https://hztextiles.pk | https://www.instagram.com/hz_textiles/
imran-ramzan | Imran Ramzan | https://imranramzan.com | https://www.instagram.com/imranramzan.official/
imrozia-premium | Imrozia | https://imroziaserene.com | https://www.instagram.com/imrozia_sereneoffical/
inara | Inara | https://shopinara.com | https://www.instagram.com/shop_inaraofficial/
inayat | Inayat Premium | https://inayatpremium.com | https://www.instagram.com/inayatpremium/
insiya-clothing | Insiya Clothing | https://insiyaclothing.com | https://www.instagram.com/insiyaclothing/
izel | Izel | https://izelapparel.com | https://www.instagram.com/izelapparel/
iznik | Iznik | https://iznikfashions.com | https://www.instagram.com/iznikfashion/
jahaan | Jahaan | https://jahaan.com.pk | https://www.instagram.com/jahaanofficialpk/
jazmin | Jazmin | https://jazmin.pk | https://www.instagram.com/jazminonline/
jild | Jild | https://www.jild.pk | https://www.instagram.com/jildleatherpk/
kahf-premium | Kahf Premium | https://kahfpremium.com | https://www.instagram.com/kahfpremium/
kanwal-malik | Kanwal Malik | https://www.kanwalmalik.com | https://www.instagram.com/kanwalmalik.official/
khuwab-by-kazma | Khuwab by Kazma |  | https://www.instagram.com/khuwab_by_kazma/
la-elise | La Elise | https://laeliseonline.com | https://www.instagram.com/laeliseonline/
la-khilaba | La Khilaba | https://la-khilaba-modest-wear.myshopify.com | https://www.instagram.com/lakhilabaofficial/
laaleh | Laaleh | https://laaleh.com | https://www.instagram.com/laaleh.store/
lakhany | LSM Lakhany | https://lakhanyonline.com | https://www.instagram.com/lakhanyofficial/
maherposh | Maherposh | https://maherposh.pk/ | https://www.instagram.com/maherposhpk/
mahnur | Mahnur | https://mahnur.pk | https://www.instagram.com/mahnurpk/
manahil-lakhani | Manahil Lakhani | https://manahillakhani.com | https://www.instagram.com/manahillakhani_official/
manahils | Manahils |  | https://www.instagram.com/manahils_pk/
manara | Manara | https://manara.pk | https://www.instagram.com/manarabymaria/
mannat-clothing | Mannat Clothing | https://mannatclothing.com | https://www.instagram.com/mannat_clothing/
maria-b | Maria.B | https://mariab.pk | https://www.instagram.com/mariabofficial/
maria-osama-khan | Maria Osama Khan | https://mariaosamakhan.com | https://www.instagram.com/mariaosamaofficial/
maryam-hussain | Maryam Hussain | https://maryamhussain.pk/ | https://www.instagram.com/maryamhussain_official/
mataish | Mataish | https://mataish.com | https://www.instagram.com/shopmataish/
mazham | Mazham | https://mazham.com | https://www.instagram.com/mazhamofficial/
meerak | Meerak | https://www.meerak.pk | https://www.instagram.com/meerak_official/
meeral | Meeral |  | https://www.instagram.com/meeralofficial/
mina-hasan | Mina Hasan | https://minahasan.com | https://www.instagram.com/minahasanofficial/
misaal-by-ayesha-somaya | Misaal | https://misaalbyas.com | https://www.instagram.com/misaalbyayeshasomaya/
motifz | Motifz | https://motifz.com.pk | https://www.instagram.com/motifzclothing/
musferah-saad | Musferah Saad | https://musferahsaad.com | https://www.instagram.com/musferahsaadofficial/
mushq | Mushq | https://mushq.com | https://www.instagram.com/mushqpk/
naayas | Naayas | https://naayas.com | https://www.instagram.com/naayas_official/
naaz-couture | Naaz Couture | https://naazcouturepk.com | https://www.instagram.com/naazcouture.official/
nairah | Nairah |  | https://www.instagram.com/nairahpk/
narmin-by-narkin-s | Narmin by Narkins | https://narmin.pk | https://www.instagram.com/narminbynarkins/
neeshay | Neeshay | https://www.neeshay.com | https://www.instagram.com/neeshay_official/
nomi-nisar | Nomi Ansari | https://www.nomiansari.com.pk/ | https://www.instagram.com/nomiansari/
noor-saadia-asad | Noor by Saadia Asad |  | https://www.instagram.com/noorbysaadiaasad/
noorma-kaamal | Noorma Kaamal |  | https://www.instagram.com/n.kaamal/
nourah | Nourah | https://nourah.pk | https://www.instagram.com/nourahpk/
nureh | Nureh | https://nureh.pk | https://www.instagram.com/nurehofficial/
ochre | Ochre | https://wearochre.com | https://www.instagram.com/ochreclothing/
ombrella-official | Ombrella | https://ombrellaofficial.com | https://www.instagram.com/ombrellaofficial/
panache-apparel | Panache |  | https://www.instagram.com/panachepakistan/
parishay | Parishay | https://parishay.pk | https://www.instagram.com/parishay.pk/
pashmire | Pashmire | https://pashmire.com | https://www.instagram.com/pashmireofficial/
qalamkar | Qalamkar | https://www.qalamkar.com.pk | https://www.instagram.com/qalamkar_/
qurratulain-saqib | Qurratulain Saqib | https://qurratulainsaqib.com | https://www.instagram.com/qurratulainsaqibofficial/
rabias-textiles | Rabia Textiles |  | https://www.instagram.com/rabiastextiles/
rajbari | Rajbari | https://www.rajbari.pk | https://www.instagram.com/rajbari.official/
rang-rasiya | Rang Rasiya | https://rangrasiya.com.pk | https://www.instagram.com/rangrasiya.official/
rashid-textiles | Rashid Tex | https://rashidtex.com | https://www.instagram.com/rashidtextile.official/
raum-by-sarb | Raum By Sarb | https://raumbysarb.com | https://www.instagram.com/raumbysarb/
regalia-textiles | Regalia Textiles | https://www.regaliatextiles.com/ | https://www.instagram.com/regaliatextiles/
rehan-n-muzammil | Rehan N Muzammil |  | https://www.instagram.com/rehannmuzammil/
republic-womenswear | Republic Womenswear |  | https://www.instagram.com/republicwomenswear/
riaz-arts | Riaz Arts | https://riazarts.com | https://www.instagram.com/riazarts/
ricamo | Ricamo |  | https://www.instagram.com/ricamobyhumera/
riley | Riley | https://riley.pk | https://www.instagram.com/rileyclothing.store/
ripret | Ripret | https://ripret.com | https://www.instagram.com/ripret.official/
roheenaz | Roheenaz | https://roheenaz.com | https://www.instagram.com/roheenaz.pk/
ruby-suleiman | Ruby Suleiman | https://rubysuleiman.com | https://www.instagram.com/rubysuleimanx/
saba-sumaiya | Saba Sumaiya | https://sabasumaiya.com | https://www.instagram.com/sabasumaiya.official/
sable-vogue | Sable Vogue | https://sablev.net | https://www.instagram.com/sablevogueofficial/
sahane | Sahane | https://www.thesahane.com | https://www.instagram.com/sahanepk/
sahar | Sahar | https://saharonline.pk | https://www.instagram.com/sahar.pakistan/
saira-rizwan | Saira Rizwan | https://sairarizwan.pk | https://www.instagram.com/sairarizwan_official/
saira-shakira | Saira Shakira |  | https://www.instagram.com/sairashakira/
salitex | Salitex | https://salitex.com | https://www.instagram.com/salitexclothing/
saphron | Saphron | https://saphrononline.com/ | https://www.instagram.com/saphronpakistan/
sara-jahan | Sara Jahan | https://sarajahanonline.com | https://www.instagram.com/sarajahanonline/
scherezade | Scherezade | https://www.scherezade.pk | https://www.instagram.com/scherezadeofficial/
seran | Seran | https://www.seran.com.pk | https://www.instagram.com/seranofficial/
shahjahan | Shahjahan | https://shahjahanofficial.com/ | https://www.instagram.com/shahjahanofficialpk/
shamooz | Shamooz | https://shamooz.com | https://www.instagram.com/shamooz.official/
shazme | Shazme | https://shazme.pk | https://www.instagram.com/shazmeofficial/
shurooq | Shurooq | https://shurooq.pk | https://www.instagram.com/shurooqpakistan/
sobia-nazir | Sobia Nazir | https://sobianazir.net | https://www.instagram.com/SobiaNazirOfficial/
stitch-vibes | Stitch Vibes | https://stitchvibes.com | https://www.instagram.com/stitch.vibes_/
stitching-cotton | Stitching Cotton | https://www.stitchingcotton.com | https://www.instagram.com/stitchingcotton/
suffuse-by-sana-yasir | Suffuse By Sana Yasir | https://suffuse.pk | https://www.instagram.com/suffusebysanayasir/
sundas-ahad | Sundas Ahad |  | https://www.instagram.com/sundasahadofficial/
suntex-fabrics | Suntex Fabrics | https://suntexfabrics.com | https://www.instagram.com/suntexfabric/
syah | Syah |  | https://www.instagram.com/syahofficialstore/
tana-bana | Tana Bana | https://www.tanabana.com.pk/ | https://www.instagram.com/tanabanashop/
tessa | Tessa | https://www.tessa.com | https://www.instagram.com/tessalynevents/
textilelime | Textilelime | https://textilelime.com | https://www.instagram.com/textilelime/
the-great-master-tgm | The Great Masters |  | https://www.instagram.com/tgmstore.pk/
threads-motifs | Threads & Motifs | https://www.threadsandmotifs.com | https://www.instagram.com/threadsandmotifsofficial/
uniluxe | Uniluxe | https://uniluxeonline.com | https://www.instagram.com/uniluxeonline/
urban-cut | Urban Cut |  | https://www.instagram.com/urbancut.pk/
vs-textiles | VS Textile Mills | https://www.vs.com.pk | https://www.instagram.com/vstextilemills/
waresha | Waresha |  | https://www.instagram.com/waresha.clothes/
xenia-formals | Xenia Formals | https://www.xeniaformals.com | https://www.instagram.com/xeniaformals/
yards | Yards | https://yards.pk | https://www.instagram.com/yards_official/
yashfa | Yashfa Studio | https://yashfastudio.com/ | https://www.instagram.com/yashfa.studio/
zaha-by-khadijah-shah | Zaha By Khadijah Shah | https://www.zaha.pk | https://www.instagram.com/zahaonline/
zara-shahjahan | Zara Shahjahan | https://zarashahjahan.com | https://www.instagram.com/zarashahjahanofficial/
zarif | Zarif | https://www.zarif.pk | https://www.instagram.com/zarifpakistan/
zariya | Zariya | https://zariyaclothing.com | https://www.instagram.com/zariyaclothing.pk/
zauk | Zauk | https://zaukstore.com | https://www.instagram.com/zaukofficial/
zeen | Zeen | https://zeenwoman.com | https://www.instagram.com/thezeenwoman/
zellbury | Zellbury | https://zellbury.com | https://www.instagram.com/zellbury/
zouj | Zouj | https://zouj.store/ | https://www.instagram.com/zouj.official/
MAP;
}

/**
 * Built-in map parsed, then the admin's custom lines merged ON TOP:
 * a custom line WINS for its handle (edit/override), new handles are ADDED.
 * A custom line with  "- | -"  disables that brand (blocks the built-in entry).
 */
function cpg_brand_map( $s ) {
	$map    = cpg_parse_brand_map( cpg_default_brand_links() );
	$custom = trim( (string) ( isset( $s['brand_links'] ) ? $s['brand_links'] : '' ) );
	if ( '' !== $custom ) {
		foreach ( cpg_parse_brand_map( $custom ) as $h => $entry ) {
			$map[ $h ] = $entry; // null = disabled on purpose
		}
	}
	return $map;
}

/** Parse pipe-format lines into handle => [name, site, instagram] (null = disabled). */
function cpg_parse_brand_map( $raw ) {
	$map = array();
	foreach ( preg_split( '/\r?\n/', (string) $raw ) as $line ) {
		$line = trim( $line );
		if ( '' === $line || '#' === $line[0] ) {
			continue;
		}
		$p = array_map( 'trim', explode( '|', $line ) );
		if ( count( $p ) < 2 || '' === $p[0] ) {
			continue;
		}
		$h    = strtolower( sanitize_key( $p[0] ) );
		$site = isset( $p[2] ) ? trim( $p[2] ) : '';
		$ig   = isset( $p[3] ) ? trim( $p[3] ) : '';
		$isDash = function ( $v ) { return '' === $v || '-' === $v || 'none' === strtolower( $v ); };
		if ( $isDash( $site ) && $isDash( $ig ) && ( '-' === $site || '-' === $ig ) ) {
			$map[ $h ] = null; // explicit disable
			continue;
		}
		$site = esc_url( $site );
		$ig   = esc_url( $ig );
		if ( '' === $site && '' === $ig ) {
			continue;
		}
		if ( false !== strpos( $site . $ig, 'sanaullastore.com' ) ) {
			continue; // never link the store itself
		}
		$map[ $h ] = array( $p[1], $site, $ig );
	}
	return $map;
}

/** Resolve the brand handle for a source (explicit key, else /collections/ slug). */
function cpg_source_brand_handle( $source ) {
	if ( ! empty( $source['brand_handle'] ) ) {
		return strtolower( sanitize_key( $source['brand_handle'] ) );
	}
	$url = isset( $source['url'] ) ? $source['url'] : ( isset( $source['collection_link'] ) ? $source['collection_link'] : '' );
	if ( $url && preg_match( '~/collections/([a-z0-9-]+)~i', $url, $m ) ) {
		return strtolower( $m[1] );
	}
	return '';
}

/** The footer line. Variants: both / site-only / instagram-only. */
function cpg_build_brand_footer( $source, $s ) {
	if ( empty( $s['brand_footer'] ) ) {
		return '';
	}
	$handle = cpg_source_brand_handle( $source );
	if ( '' === $handle ) {
		return '';
	}
	$map = cpg_brand_map( $s );
	if ( ! isset( $map[ $handle ] ) || ! is_array( $map[ $handle ] ) ) {
		return '';
	}
	list( $name, $site, $ig ) = $map[ $handle ];
	$site_a = '<a href="' . $site . '" target="_blank" rel="nofollow noopener">' . esc_html( $name ) . ' Website</a>';
	$ig_a   = '<a href="' . $ig . '" target="_blank" rel="nofollow noopener">Instagram page</a>';
	if ( $site && $ig ) {
		$html = '<p>Get your favorite dress from ' . $site_a . ' and more details on their ' . $ig_a . '.</p>';
	} elseif ( $site ) {
		$html = '<p>Get your favorite dress from ' . $site_a . '.</p>';
	} else {
		$html = '<p>Find more of ' . esc_html( $name ) . ' on their ' . $ig_a . '.</p>';
	}
	return $html . "\n";
}

function cpg_settings() {
	$s = get_option( 'cpg_settings', array() );
	if ( ! is_array( $s ) ) {
		$s = array();
	}
	/* v3.5.6 (decision 2026-10-01): the live site ran age_days=5, which permanently
	 * age-blocks every line that crossed 5 days while feeds were failing. One-time
	 * migration 5 -> 14. Any other stored value is left exactly as configured. */
	if ( ! get_option( 'cpg_v356_age14' ) ) {
		if ( isset( $s['age_days'] ) && 5 === (int) $s['age_days'] ) {
			$s['age_days'] = 14;
			update_option( 'cpg_settings', $s, false );
		}
		update_option( 'cpg_v356_age14', 1, false );
	}
	return wp_parse_args( $s, cpg_defaults() );
}

/**
 * SOURCES — the only editable part of this file.
 *
 * type=shopify_auto_brands : auto-discovers every brand of a Shopify store
 *                            from its brand-directory page (regex on links).
 * type=shopify_collection  : one brand feed, split into line-posts.
 * type=woo_category        : one WooCommerce Store API category = one post.
 */
function cpg_default_sources() {
	return array(

		array(
			'type'          => 'shopify_auto_brands',
			'name'          => 'Sanaulla (auto brands)',
			'store'         => 'https://sanaullastore.com',
			'directory'     => 'https://sanaullastore.com/pages/brands',
			'link_pattern'  => '#<a[^>]*href="https?://[^/]+/collections/([a-z0-9-]+)"[^>]*class="bp-tile"#i',
			'tags'          => array( 'Sanaulla', 'Pakistani Suits' ),
		),

		array(
			'type'            => 'shopify_collection',
			'name'            => 'Mushq @ Sanaulla Store',
			'store'           => 'https://sanaullastore.com',
			'url'             => 'https://sanaullastore.com/collections/mushq/products.json?limit=250',
			'collection_link' => 'https://sanaullastore.com/collections/mushq',
			'group_by'        => 'line',
			'tags'            => array( 'Mushq', 'Sanaulla', 'Pakistani Suits' ),
		),

		array(
			'type'            => 'woo_category',
			'name'            => 'Bloom Lawn 2026 by Saira Shakira',
			'url'             => 'https://www.thefashionstation.in/wp-json/wc/store/v1/products?per_page=100&category=bloom-lawn-2026-by-saira-shakira',
			'collection_link' => 'https://www.thefashionstation.in/product-category/bloom-lawn-2026-by-saira-shakira/',
			'tags'            => array( 'Saira Shakira', 'Lawn 2026' ),
		),
	);
}

/* =====================================================================
 * ACTIVATION / DEACTIVATION
 * =================================================================== */

register_activation_hook( __FILE__, 'cpg_activate' );
function cpg_activate() {
	cpg_ensure_cron();
}

register_deactivation_hook( __FILE__, 'cpg_deactivate' );
function cpg_deactivate() {
	wp_clear_scheduled_hook( CPG_CRON );
	delete_transient( 'cpg_lock' );
}

/* -----------------------------------------------------------------
 * SELF-HEALING SCHEDULER (v3.3.2)
 * register_activation_hook NEVER fires when the plugin file is simply
 * updated in place (FTP / Plugins editor) — so a file-updated install
 * had NO cron event at all: "Next scheduled run: —" and zero runs.
 * `init` fires on every WordPress request (front-end, admin, wp-cron).
 * The check is one wp_next_scheduled() against the loaded cron option,
 * and it NEVER touches an existing event (no drift). Pause is handled
 * inside cpg_run(), so an event sitting there while paused is by design.
 * ----------------------------------------------------------------- */
add_action( 'init', 'cpg_ensure_cron' );
function cpg_ensure_cron() {
	if ( false === wp_next_scheduled( CPG_CRON ) ) {
		wp_schedule_event( time() + 120, 'cpg_interval', CPG_CRON );
	}
}

add_filter( 'cron_schedules', 'cpg_cron_schedules' );
function cpg_cron_schedules( $schedules ) {
	$schedules['cpg_interval'] = array(
		'interval' => CPG_INTERVAL,
		'display'  => 'Every 6 hours (DIT Fashion Posts Generator)',
	);
	return $schedules;
}

add_action( CPG_CRON, 'cpg_cron_tick' );
function cpg_cron_tick() {
	$summary = cpg_run(); // silent on cron; result stored as last-run log
	return $summary;
}

/* =====================================================================
 * SECURITY: run lock (no concurrent runs, no cron overlap)
 * =================================================================== */

function cpg_acquire_lock() {
	if ( get_transient( 'cpg_lock' ) ) {
		return false;
	}
	set_transient( 'cpg_lock', time(), CPG_LOCK_SECONDS );
	return true;
}
function cpg_release_lock() {
	delete_transient( 'cpg_lock' );
}

/* =====================================================================
 * HTTP helper (single place, bounded, identified)
 * =================================================================== */

/* =====================================================================
 * v3.5.8: PROXY FALLBACK — provider registry. Endpoints verified against
 * each provider's docs (2026-10-01). A plain feed fetch = 1 credit on all.
 * Free tiers checked the same day: ScrapingAnt 10,000 credits/mo (failed
 * requests cost 0), ZenRows 5,000/mo (404s ARE billed — hence the 404 guard
 * in cpg_fetch), ScraperAPI 1,000/mo, ScrapingBee 1,000, Crawlbase
 * "up to 5,000" per their site (older docs said 1,000).
 * =================================================================== */

function cpg_proxy_provider_id( $p ) {
	return in_array( $p, array( 'scrapingant', 'zenrows', 'scraperapi', 'scrapingbee', 'crawlbase', 'custom' ), true ) ? $p : '';
}

function cpg_proxy_url( $provider, $key, $url, $premium, $template = '' ) {
	$key = trim( (string) $key );
	$u   = rawurlencode( $url );
	switch ( $provider ) {
		case 'scrapingant': // docs.scrapingant.com — datacenter request = 1 credit
			return 'https://api.scrapingant.com/v2/general?x-api-key=' . rawurlencode( $key ) . '&url=' . $u;
		case 'zenrows': // docs.zenrows.com — standard = 1 credit, premium = 10
			return 'https://api.zenrows.com/v1/?apikey=' . rawurlencode( $key ) . '&url=' . $u . ( $premium ? '&premium_proxy=true' : '' );
		case 'scraperapi': // docs.scraperapi.com — standard = 1 credit
			return 'https://api.scraperapi.com/?api_key=' . rawurlencode( $key ) . '&url=' . $u;
		case 'scrapingbee': // app.scrapingbee.com — standard = 1 credit
			return 'https://app.scrapingbee.com/api/v1/?api_key=' . rawurlencode( $key ) . '&url=' . $u;
		case 'crawlbase': // crawlbase.com — 1 request per credit
			return 'https://api.crawlbase.com/?token=' . rawurlencode( $key ) . '&url=' . $u;
		case 'custom': // YOUR OWN relay (e.g. a Cloudflare Worker, 100k req/day free) — template must contain {URL}
			return ( false !== strpos( (string) $template, '{URL}' ) )
				? str_replace( '{URL}', $u, (string) $template )
				: null;
	}
	return null;
}

/* v3.5.6: last fetch failure reason ('' after a success) — the log now says WHY a
 * feed failed (HTTP 403 / cURL error 28 / not JSON), not just "unreachable". */
function cpg_fetch_error( $msg = null ) {
	if ( null !== $msg ) {
		$GLOBALS['cpg_fetch_error'] = $msg;
	}
	return isset( $GLOBALS['cpg_fetch_error'] ) ? $GLOBALS['cpg_fetch_error'] : '';
}

function cpg_fetch( $url ) {
	$url = esc_url_raw( $url );
	if ( '' === $url ) {
		cpg_fetch_error( 'invalid URL' );
		return null;
	}
	static $last_request = 0.0;
	$gap = CPG_FETCH_GAP - ( microtime( true ) - $last_request );
	if ( $gap > 0 ) {
		sleep( (int) ceil( $gap ) ); // v3.5.6: pacing — never hammer; also gives rate limits time to cool
	}
	$attempt = function () use ( $url ) {
		$res = wp_remote_get( $url, array(
			'timeout'     => 20,
			'user-agent'  => CPG_UA,
			'redirection' => 3,
		) );
		if ( is_wp_error( $res ) ) {
			cpg_fetch_error( $res->get_error_message() ); // e.g. "cURL error 28: Operation timed out"
			return null;
		}
		$code = (int) wp_remote_retrieve_response_code( $res );
		if ( 200 !== $code ) {
			cpg_fetch_error( 'HTTP ' . $code ); // e.g. 403 = Cloudflare challenge, 429 = rate limit
			return null;
		}
		return wp_remote_retrieve_body( $res );
	};
	$last_request = microtime( true );
	$body         = $attempt();
	if ( null === $body ) { // v3.5.6: one retry — on 2026-10-01 2 of 21 requests got through, so a second try has real odds
		if ( CPG_FETCH_RETRY > 0 ) {
			sleep( CPG_FETCH_RETRY );
			$last_request = microtime( true );
		}
		$body = $attempt();
	}
	if ( null === $body ) { // v3.5.8: last resort — proxy chain (primary, then backup).
		// Response is JSON-validated downstream, so a wrapped/tampered proxy reply can
		// never build a garbage post. Credit guards:
		// (1) 404/410 = the collection is definitively dead — a proxy cannot help, and
		//     some providers BILL for 404s (ZenRows does). Never proxy those.
		// (2) 3 straight proxy failures this run = store or provider is down -> stop
		//     burning credits; the next run retries fresh.
		$err  = cpg_fetch_error();
		$dead = ( 0 === strpos( $err, 'HTTP 404' ) || 0 === strpos( $err, 'HTTP 410' ) );
		if ( ! $dead && empty( $GLOBALS['cpg_proxy_abandoned'] ) ) {
			$ps    = cpg_settings();
			$slots = array(
				array( $ps['proxy_provider'], $ps['proxy_key'] ),
				array( $ps['proxy_provider2'], $ps['proxy_key2'] ),
			);
			foreach ( $slots as $slot ) {
				list( $prov, $pkey ) = $slot;
				if ( '' === $prov || ( '' === trim( (string) $pkey ) && 'custom' !== $prov ) ) {
					continue; // not configured (custom relays need no key — the template carries access)
				}
				$purl = cpg_proxy_url( $prov, $pkey, $url, ! empty( $ps['proxy_premium'] ), isset( $ps['proxy_custom'] ) ? $ps['proxy_custom'] : '' );
				if ( null === $purl ) {
					cpg_fetch_error( 'proxy(' . $prov . ') — misconfigured (custom template needs {URL})' );
					continue;
				}
				$last_request = microtime( true );
				$res = wp_remote_get( $purl, array(
					'timeout'     => 45, // proxies are slower than direct
					'user-agent'  => CPG_UA,
					'redirection' => 3,
				) );
				if ( is_wp_error( $res ) ) {
					cpg_fetch_error( 'proxy(' . $prov . ') — ' . $res->get_error_message() );
				} elseif ( 200 !== (int) wp_remote_retrieve_response_code( $res ) ) {
					cpg_fetch_error( 'proxy(' . $prov . ') — HTTP ' . (int) wp_remote_retrieve_response_code( $res ) );
				} else {
					$body = wp_remote_retrieve_body( $res );
					cpg_fetch_error( '' );
					$GLOBALS['cpg_proxy_streak'] = 0;
					$GLOBALS['cpg_proxy_rescues'][ $prov ] = ( isset( $GLOBALS['cpg_proxy_rescues'][ $prov ] ) ? $GLOBALS['cpg_proxy_rescues'][ $prov ] : 0 ) + 1;
					break;
				}
				$GLOBALS['cpg_proxy_streak'] = ( isset( $GLOBALS['cpg_proxy_streak'] ) ? $GLOBALS['cpg_proxy_streak'] : 0 ) + 1;
				if ( $GLOBALS['cpg_proxy_streak'] >= 3 ) {
					$GLOBALS['cpg_proxy_abandoned'] = true; // stop spending this run
					cpg_fetch_error( 'proxy(' . $prov . ') — 3 straight proxy failures, giving up until next run' );
					break;
				}
			}
		}
	}
	if ( null !== $body ) {
		cpg_fetch_error( '' );
	}
	return $body;
}

function cpg_fetch_json( $url ) {
	$body = cpg_fetch( $url );
	if ( null === $body ) {
		return null;
	}
	$data = json_decode( $body, true );
	if ( ! is_array( $data ) ) {
		cpg_fetch_error( 'HTTP 200 but response is not JSON' ); // e.g. a challenge/interstitial HTML page
		return null;
	}
	return $data;
}

/* =====================================================================
 * SANITIZER — the only untrusted HTML we touch is product body_html.
 * Posts are BUILT from clean data, so scraper junk (scripts, pay-widget
 * divs, quick-view buttons, hidden spans) never exists in our output.
 * This function guarantees the description can't smuggle any in.
 * =================================================================== */

function cpg_clean_html( $html, $max_chars ) {
	if ( empty( $html ) || ! is_string( $html ) ) {
		return '';
	}
	// drop dangerous / junk blocks entirely
	$html = preg_replace( '#<(script|style|iframe|object|embed|noscript|form|svg|template)[^>]*>.*?</\1>#is', '', $html );
	$html = preg_replace( '#<(link|meta|input|button)[^>]*>#i', '', $html );
	$html = preg_replace( '#<!--.*?-->#s', '', $html );

	if ( null === $html ) {
		$html = '';
	}

	// text only
	$text = wp_strip_all_tags( $html );
	$text = html_entity_decode( $text, ENT_QUOTES, 'UTF-8' );
	$text = trim( preg_replace( '/[ \t]+/', ' ', $text ) );
	$text = preg_replace( '/\n{3,}/', "\n\n", $text );

	// crop whole words
	if ( function_exists( 'mb_strlen' ) && mb_strlen( $text ) > $max_chars ) {
		$text = mb_substr( $text, 0, $max_chars );
		$text = preg_replace( '/\s+\S*$/u', '', $text ) . '…';
	} elseif ( ! function_exists( 'mb_strlen' ) && strlen( $text ) > $max_chars ) {
		$text = substr( $text, 0, $max_chars );
		$text = preg_replace( '/\s+\S*$/', '', $text ) . '…';
	}
	return $text;
}

/* =====================================================================
 * RUN ENGINE
 * =================================================================== */

function cpg_run( $manual = false ) {
	$s = cpg_settings();

	if ( $s['paused'] ) {
		cpg_log_last_run( "Paused — nothing done." );
		return "Paused — nothing done.";
	}
	if ( ! cpg_acquire_lock() ) {
		cpg_log_last_run( "Blocked — another run is still in progress (run lock, expires within 10 min). Nothing was lost; try again shortly." );
		return "Another run is already in progress (lock active). Try again in a few minutes.";
	}

	$start  = microtime( true );
	$GLOBALS['cpg_proxy_rescues']   = array(); // v3.5.8: provider => rescue count
	$GLOBALS['cpg_proxy_streak']    = 0;
	$GLOBALS['cpg_proxy_abandoned'] = false;
	$report = array( 'DIT Fashion Posts Generator — run ' . date_i18n( 'Y-m-d H:i' ) );
	$GLOBALS['cpg_media'] = array( 'dl' => 0, 'reuse' => 0, 'fail' => 0, 'err' => '' );

	/* v3.2.1 FIX: reset the per-run counter at the START of every run.
	 * Before, it only reset at midnight, so "1 post per run" behaved as
	 * "1 post per day" and every later run the same day was THROTTLED. */
	$cc = cpg_counter();
	$cc['run'] = 0;
	update_option( 'cpg_counter', $cc, false );

	/* manual runs get a bigger time budget: real image downloads take seconds */
	$GLOBALS['cpg_budget'] = $manual ? 240 : CPG_TIME_BUDGET;
	if ( $manual && function_exists( 'set_time_limit' ) ) {
		@set_time_limit( 300 );
	}
	$count  = array( 'created' => 0, 'updated' => 0, 'skipped' => 0, 'ok' => 0 );
	$throttled = false; // once caps are hit: no more brand discovery, but updates still run

	foreach ( cpg_default_sources() as $source ) {

		if ( ( microtime( true ) - $start ) > ( isset( $GLOBALS['cpg_budget'] ) ? $GLOBALS['cpg_budget'] : CPG_TIME_BUDGET ) ) {
			$report[] = '[TIME] budget reached — remaining sources resume next run';
			break;
		}

		if ( 'shopify_auto_brands' === $source['type'] ) {
			if ( $throttled ) {
				continue; // creation budget spent — don't fetch more brand feeds this run
			}
			$held = cpg_process_auto_brands( $source, $s, $report, $count, $start );
			if ( 'throttled' === $held ) {
				$throttled = true;
				$report[] = '[HOLD] post cap reached — brand rotation resumes at the same spot next run';
			}
		} elseif ( 'shopify_collection' === $source['type'] ) {
			$body = cpg_fetch_json( $source['url'] );
			$items = ( isset( $body['products'] ) && is_array( $body['products'] ) ) ? $body['products'] : ( is_array( $body ) ? $body : array() );
			if ( empty( $items ) ) {
				$err = cpg_fetch_error();
				$report[] = '[SKIP] ' . $source['name'] . ' — feed empty/unreachable' . ( '' !== $err ? ' — ' . $err : '' ); // v3.5.6: reason
				continue;
			}
			$dresses = cpg_parse_shopify( $items, $source, $s );
			if ( ! empty( $source['group_by'] ) && 'line' === $source['group_by'] ) {
				$held = cpg_process_lines( $source, $dresses, $source['url'], $s, $report, $count );
				if ( 'throttled' === $held ) {
					$throttled = true;
					$report[] = '[HOLD] post cap reached — new collections resume next run (existing posts are final)';
				}
			} else {
				$res = cpg_store_collection_post( md5( $source['url'] ), $source, $dresses, $s );
				cpg_tally( $res, $count );
				$report[] = '[' . $res['action'] . '] ' . $source['name'] . ' — ' . $res['detail'];
			}
		} elseif ( 'woo_category' === $source['type'] ) {
			$body = cpg_fetch_json( $source['url'] );
			if ( ! is_array( $body ) ) {
				$err = cpg_fetch_error();
				$report[] = '[SKIP] ' . $source['name'] . ' — feed empty/unreachable' . ( '' !== $err ? ' — ' . $err : '' ); // v3.5.6: reason
				continue;
			}
			$dresses = cpg_parse_woo( $body, $s );
			if ( empty( $dresses ) ) {
				continue;
			}
			$res = cpg_store_collection_post( md5( $source['url'] ), $source, $dresses, $s );
			cpg_tally( $res, $count );
			$report[] = '[' . $res['action'] . '] ' . $source['name'] . ' — ' . $res['detail'];
		}
	}

	$m = $GLOBALS['cpg_media'];
	if ( ( $m['dl'] + $m['reuse'] + $m['fail'] ) > 0 ) {
		$report[] = sprintf( '[MEDIA] images: %d downloaded, %d reused, %d failed%s', $m['dl'], $m['reuse'], $m['fail'], ( '' !== $m['err'] ? ' — first error: ' . $m['err'] : '' ) );
	}
	if ( ! empty( $GLOBALS['cpg_proxy_rescues'] ) ) { // v3.5.8
		$bits = array();
		foreach ( $GLOBALS['cpg_proxy_rescues'] as $prov => $n ) {
			$bits[] = $prov . ' ' . (int) $n;
		}
		$net = '[NET] proxy rescues: ' . implode( ', ', $bits );
		if ( ! empty( $GLOBALS['cpg_proxy_abandoned'] ) ) {
			$net .= ' — proxy abandoned after 3 straight failures, resumes next run';
		}
		$report[] = $net;
	} elseif ( ! empty( $GLOBALS['cpg_proxy_abandoned'] ) ) {
		$report[] = '[NET] proxy abandoned after 3 straight failures — resumes next run';
	}
	foreach ( cpg_today_report_lines( $s ) as $cpg_tl ) {
		$report[] = $cpg_tl;
	}
	$report[] = sprintf( 'Done in %.1fs — created %d, updated %d, skipped %d, unchanged %d.',
		( microtime( true ) - $start ), $count['created'], $count['updated'], $count['skipped'], $count['ok'] );

	cpg_release_lock();
	cpg_log_last_run( implode( "\n", $report ) );
	return implode( "\n", $report );
}

function cpg_tally( $res, &$count ) {
	if ( isset( $count[ strtolower( $res['action'] ) ] ) ) {
		$count[ strtolower( $res['action'] ) ]++;
	}
}

function cpg_log_last_run( $text ) {
	update_option( 'cpg_last_run', array( 'time' => time(), 'log' => $text ), false );
}

/* =====================================================================
 * AUTO BRAND DISCOVERY (round-robin, time-budgeted)
 * =================================================================== */

function cpg_process_auto_brands( $source, $s, &$report, &$count, $start ) {

	$brands = cpg_get_brands( $source );
	if ( empty( $brands ) ) {
		$report[] = '[SKIP] ' . $source['name'] . ' — no brands found in directory';
		return;
	}

	$total  = count( $brands );
	$meta   = get_option( 'cpg_meta', array() );
	if ( ! is_array( $meta ) ) {
		$meta = array(); // F9: corrupt-option guard
	}
	$key    = md5( $source['name'] );
	$cursor = isset( $meta[ $key ] ) ? (int) $meta[ $key ] : 0;
	if ( $cursor >= $total ) {
		$cursor = 0;
	}

	$per_run = max( 1, (int) $s['brands_per_run'] );
	$report[] = '[INFO] ' . $source['name'] . ': ' . $total . ' brands, up to ' . $per_run . ' this run (cursor ' . $cursor . ')';

	$done = 0; // brands fully attempted this run
	for ( $i = 0; $i < $per_run; $i++ ) {
		$idx    = ( $cursor + $i ) % $total;
		$handle = $brands[ $idx ];

		if ( ( microtime( true ) - $start ) > ( isset( $GLOBALS['cpg_budget'] ) ? $GLOBALS['cpg_budget'] : CPG_TIME_BUDGET ) ) {
			$report[] = '[TIME] budget reached mid-rotation — resumes next run';
			break;
		}

		$feed  = $source['store'] . '/collections/' . $handle . '/products.json?limit=250';
		$body  = cpg_fetch_json( $feed );
		$items = ( isset( $body['products'] ) && is_array( $body['products'] ) ) ? $body['products'] : array();
		if ( empty( $items ) ) {
			$err = cpg_fetch_error();
			if ( '' !== $err ) { // v3.5.6: say WHY — HTTP status or connection error, no more guessing
				$report[] = '[INFO] ' . $handle . ': feed unreachable — ' . $err;
			} else {
				$report[] = '[INFO] ' . $handle . ': collection empty (feed reachable)';
			}
			$done++; // dead/empty feed counts as attempted
			continue;
		}

		$dresses = cpg_parse_shopify( $items, $source, $s );
		$held = cpg_process_lines( $source, $dresses, $feed, $s, $report, $count, $handle );
		if ( 'throttled' === $held ) {
			/* v3.3 F1: STAY on this brand. Its already-created lines are instantly
			 * skipped next run (state memory) and the pending ones resume exactly
			 * here. Before, the cursor jumped past the whole batch and pending
			 * lines waited for a full 221-brand wrap. */
			$meta[ $key ] = $idx;
			update_option( 'cpg_meta', $meta, false );
			return 'throttled';
		}
		$done++;
	}

	$meta[ $key ] = ( $cursor + $done ) % $total;
	update_option( 'cpg_meta', $meta, false );
	return '';
}

function cpg_process_lines( $source, $dresses, $feed_url, $s, &$report, &$count, $handle = '' ) {
	$groups = cpg_line_merge_same_collection( cpg_group_lines( $dresses ) );
	$label  = '' !== $handle ? $handle : $source['name'];
	$small  = 0; // lines below min_dresses
	$stale  = 0; // lines killed by the age filter
	$acted  = 0; // lines actually stored/checked

	foreach ( $groups as $code => $group ) {
		if ( count( $group['dresses'] ) < max( 1, (int) $s['min_dresses'] ) ) {
			$small++;
			continue;
		}
		if ( ! cpg_line_is_fresh( $group['dresses'], $s ) ) {
			$stale++;
			continue;
		}

		$season = $group['season']; // v3.5.1: merged at group level

		$sub   = $source;
		$sub['name'] = $group['title'];
		// v3.5 immutable-post policy: year-less codes get the season in the title so an
		// annual relaunch is visibly a new post ("... 2027").
		if ( '' !== $season && ! cpg_code_has_year( $code ) ) {
			$sub['name'] = $group['title'] . ' ' . $season;
		}
		$sub['cpg_season'] = $season;
		$sub['brand_handle'] = ( '' !== $handle ) ? $handle : cpg_source_brand_handle( $source );
		$sub['tags'] = array_merge( (array) $source['tags'], array( $code ) );
		$sub['collection_link'] = ( '' !== $handle )
			? $source['store'] . '/collections/' . $handle . ( 'OTHER' === $code ? '' : '/' . $code )
			: ( isset( $source['collection_link'] ) ? $source['collection_link'] : $feed_url );

		/* v3.5.1: the line key is COLLECTION NAME + SEASON — stable even if the store
		 * re-tags batches or the bigger batch flips. Next year's relaunch (new season)
		 * is a new line. Legacy pre-3.5/3.5 keys (per-code) migrate on first sight. */
		$norm = strtolower( preg_replace( '~[^a-z0-9]+~', '', $group['name'] ) );
		$key  = md5( $feed_url . '|' . $norm . '|' . $season );
		$state = get_option( 'cpg_state', array() );
		if ( ! is_array( $state ) ) {
			$state = array();
		}
		if ( ! isset( $state[ $key ] ) ) {
			foreach ( array_merge( array( $code ), (array) $group['codes'] ) as $lc ) {
				foreach ( array( md5( $feed_url . '|' . $lc ), md5( $feed_url . '|' . $lc . '|' . $season ) ) as $lk ) {
					if ( isset( $state[ $lk ] ) ) {
						$state[ $key ] = $state[ $lk ];
						unset( $state[ $lk ] );
						update_option( 'cpg_state', $state, false );
						break 2;
					}
				}
			}
		}
		$res = cpg_store_collection_post( $key, $sub, $group['dresses'], $s );
		$acted++;
		cpg_tally( $res, $count );
		$report[] = '[' . $res['action'] . '] ' . $label . ' / ' . $group['title'] . ' — ' . $res['detail'];
		if ( 'THROTTLED' === $res['action'] ) {
			$report[] = "[HOLD] post cap reached — this brand's remaining lines resume next run";
			return 'throttled';
		}
	}
	if ( 0 === $acted && ( $small + $stale ) > 0 ) {
		$report[] = '[INFO] ' . $label . ': ' . count( $groups ) . ' line(s) found — ' . $small . ' below min ' . (int) $s['min_dresses'] . ', ' . $stale . ' filtered by age — nothing to post';
	}
	return '';
}

function cpg_get_brands( $source ) {
	$cache = get_option( 'cpg_brands', array() );
	if ( ! is_array( $cache ) ) {
		$cache = array(); // F9: corrupt-option guard
	}
	$key   = md5( $source['directory'] );
	if ( isset( $cache[ $key ] ) && ( time() - (int) $cache[ $key ]['time'] ) < 7 * DAY_IN_SECONDS && ! empty( $cache[ $key ]['brands'] ) ) {
		return array_map( 'sanitize_key', (array) $cache[ $key ]['brands'] );
	}

	$html = cpg_fetch( $source['directory'] );
	if ( null === $html ) {
		return isset( $cache[ $key ]['brands'] ) ? array_map( 'sanitize_key', (array) $cache[ $key ]['brands'] ) : array();
	}

	$handles = array();
	if ( @preg_match_all( $source['link_pattern'], $html, $m ) && ! empty( $m[1] ) ) {
		$handles = array_values( array_unique( array_map( 'sanitize_key', $m[1] ) ) );
	}

	if ( ! empty( $handles ) ) {
		$cache[ $key ] = array( 'time' => time(), 'brands' => $handles );
		update_option( 'cpg_brands', $cache, false );
	}
	return $handles;
}

/* =====================================================================
 * PARSERS
 * =================================================================== */

function cpg_parse_shopify( $items, $source, $s ) {
	$dresses = array();
	$store   = rtrim( isset( $source['store'] ) ? $source['store'] : '', '/' );
	$per     = max( 1, (int) $s['img_per_dress'] );

	foreach ( (array) $items as $product ) {
		if ( empty( $product['title'] ) ) {
			continue;
		}
		$title = sanitize_text_field( $product['title'] );

		// line code: tag first, then title
		$code = '';
		$tags = isset( $product['tags'] ) ? $product['tags'] : array();
		if ( is_string( $tags ) ) {
			$tags = array_map( 'trim', explode( ',', $tags ) ); // products.json sends "tag1, tag2"
		}
		if ( ! empty( $tags ) && is_array( $tags ) ) {
			foreach ( $tags as $tag ) {
				if ( is_string( $tag ) && preg_match( '/^[A-Z]{1,4}\d{2}[A-Z]{1,5}$/', $tag ) ) {
					$code = $tag;
					break;
				}
			}
		}
		if ( '' === $code && preg_match( '/\b([A-Z]{1,4}\d{2}[A-Z]{1,5})\b/', $title, $m ) ) {
			$code = $m[1];
		}

		$line_name = $title;
		if ( '' !== $code ) {
			$parts     = explode( $code, $title, 2 );
			$line_name = trim( preg_replace( '/[\s\-–]+$/u', '', $parts[0] ) );
		}

		$images = array();
		foreach ( (array) ( isset( $product['images'] ) ? $product['images'] : array() ) as $img ) {
			if ( ! empty( $img['src'] ) && esc_url( $img['src'] ) ) {
				$images[] = esc_url_raw( $img['src'] );
			}
		}

		$price = '';
		if ( isset( $product['variants'][0]['price'] ) ) {
			$price = 'PKR ' . number_format( (float) $product['variants'][0]['price'] );
		}

		$dresses[] = array(
			'id'     => isset( $product['id'] ) ? (string) absint( $product['id'] ) : md5( $title ),
			'title'  => $title,
			'price'  => $price,
			'url'    => esc_url_raw( $store . '/products/' . ( isset( $product['handle'] ) ? sanitize_title( $product['handle'] ) : '' ) ),
			'imgs'   => array_slice( array_unique( $images ), 0, $per ),
			'code'   => $code,
			'line'   => $line_name,
			'desc'   => cpg_clean_html( isset( $product['body_html'] ) ? $product['body_html'] : '', (int) $s['desc_chars'] ),
			'date'   => ! empty( $product['published_at'] ) ? (int) strtotime( $product['published_at'] ) : 0,
		);
	}
	return $dresses;
}

function cpg_parse_woo( $body, $s ) {
	$dresses = array();
	$per     = max( 1, (int) $s['img_per_dress'] );
	foreach ( (array) $body as $product ) {
		if ( empty( $product['name'] ) ) {
			continue;
		}
		$images = array();
		foreach ( (array) ( isset( $product['images'] ) ? $product['images'] : array() ) as $img ) {
			if ( ! empty( $img['src'] ) ) {
				$images[] = esc_url_raw( $img['src'] );
			}
		}
		$price = '';
		if ( isset( $product['prices']['price'] ) ) {
			$minor  = isset( $product['prices']['currency_minor_unit'] ) ? (int) $product['prices']['currency_minor_unit'] : 2;
			$prefix = isset( $product['prices']['currency_prefix'] ) ? $product['prices']['currency_prefix'] : '';
			$price  = $prefix . number_format( (float) $product['prices']['price'] / pow( 10, $minor ), $minor );
		}
		$dresses[] = array(
			'id'     => isset( $product['id'] ) ? (string) absint( $product['id'] ) : md5( sanitize_text_field( $product['name'] ) ),
			'title'  => sanitize_text_field( $product['name'] ),
			'price'  => $price,
			'url'    => isset( $product['permalink'] ) ? esc_url_raw( $product['permalink'] ) : '',
			'imgs'   => array_slice( array_unique( $images ), 0, $per ),
			'code'   => '',
			'line'   => '',
			'desc'   => '',
			'date'   => 0,
		);
	}
	return $dresses;
}

/** v3.5: season of a line — "20YY" from a 2-digit year inside the code (MU26UNR -> 2026),
 * else the newest dress's year, else ''. Same-name collections relaunched next year get
 * a different season => a NEW post; same season => the existing post, locked. */
function cpg_line_season( $code, $dresses ) {
	if ( preg_match( '~(?<!\d)(2[0-9])(?!\d)~', $code, $m ) ) {
		return '20' . $m[1];
	}
	$max = 0;
	foreach ( $dresses as $d ) {
		if ( isset( $d['date'] ) && $d['date'] > $max ) {
			$max = $d['date'];
		}
	}
	return $max > 0 ? gmdate( 'Y', $max ) : '';
}

function cpg_code_has_year( $code ) {
	return 1 === preg_match( '~(?<!\d)2[0-9](?!\d)~', (string) $code );
}

function cpg_group_lines( $dresses ) {
	$groups = array();
	foreach ( $dresses as $d ) {
		$code = '' !== $d['code'] ? $d['code'] : 'OTHER';
		if ( ! isset( $groups[ $code ] ) ) {
			$groups[ $code ] = array( 'title' => '', 'dresses' => array() );
		}
		if ( '' === $groups[ $code ]['title'] && '' !== $d['line'] ) {
			$groups[ $code ]['title'] = $d['line'];
		}
		$groups[ $code ]['dresses'][] = $d;
	}
	foreach ( $groups as $code => &$g ) {
		$name     = ( '' !== $g['title'] ) ? $g['title'] : 'Collection';
		$g['title'] = ( 'OTHER' === $code ) ? $name . ' (Assorted)' : $name . ' (' . $code . ')';
	}
	return $groups;
}

/** v3.5.1: one COLLECTION = one post. The store sometimes splits a single collection
 * across two codes with the identical name (real cases from the live feed: "The Secret
 * Garden by Mushq" MU26USG + MU26ULSG; "Lakhany ... Printed Lawn" LSM26UP + LSM26ULP)
 * or leaves a few dresses untagged (OTHER). Merge groups that share the normalized
 * line name AND the season; primary code = the one carrying the most dresses. */
function cpg_line_merge_same_collection( $groups ) {
	$merged = array();
	foreach ( $groups as $code => $g ) {
		$raw = trim( preg_replace( '~\s*\([^)]*\)$~', '', $g['title'] ) ); // drop "(CODE)" / "(Assorted)"
		$norm   = strtolower( preg_replace( '~[^a-z0-9]+~', '', $raw ) );
		$season = cpg_line_season( $code, $g['dresses'] );
		$mk     = $norm . '|' . $season;
		if ( ! isset( $merged[ $mk ] ) ) {
			$merged[ $mk ] = array( 'name' => $raw, 'season' => $season, 'codes' => array(), 'dresses' => array() );
		}
		$merged[ $mk ]['dresses'] = array_merge( $merged[ $mk ]['dresses'], $g['dresses'] );
		if ( 'OTHER' !== $code ) {
			$merged[ $mk ]['codes'][ $code ] = count( $g['dresses'] );
		}
	}
	$out = array();
	foreach ( $merged as $m ) {
		arsort( $m['codes'] );
		$primary = ! empty( $m['codes'] ) ? array_key_first( $m['codes'] ) : 'OTHER';
		$title   = ( 'OTHER' === $primary )
			? $m['name'] . ' (Assorted)'
			: $m['name'] . ' (' . $primary . ')';
		$slot    = $primary;
		$i       = 2;
		while ( isset( $out[ $slot ] ) ) { $slot = $primary . '-' . ( $i++ ); } // paranoia guard
		$out[ $slot ] = array(
			'title'   => $title,
			'name'    => $m['name'],
			'season'  => $m['season'],
			'codes'   => array_keys( $m['codes'] ),
			'dresses' => $m['dresses'],
		);
	}
	return $out;
}

function cpg_line_is_fresh( $dresses, $s ) {
	$days = (int) $s['age_days'];
	if ( $days <= 0 ) {
		return true;
	}
	$newest = 0;
	foreach ( $dresses as $d ) {
		if ( $d['date'] > $newest ) {
			$newest = $d['date'];
		}
	}
	if ( 0 === $newest ) {
		return true;
	}
	return ( time() - $newest ) <= ( $days * DAY_IN_SECONDS );
}

/* =====================================================================
 * THROTTLE: N new posts per run / per day (updates never count)
 * ===================================================================== */

/** v3.5.3: "Today" section — lists what CPG created TODAY across ALL runs, from the
 * counter memory itself (the same store behind "daily cap X/Y used"), so the two can
 * never disagree. v3.5.4: posts later trashed/deleted stay listed from memory, tagged
 * "(now in Trash)" / "(later deleted)". DB query only as fallback when the cap says
 * posts exist but memory is empty (created before v3.5.3). */
function cpg_today_report_lines( $s ) {
	$c      = cpg_counter();
	$cap    = (int) $s['max_posts_day'] > 0 ? ' — daily cap ' . (int) $c['day'] . '/' . (int) $s['max_posts_day'] . ' used' : '';
	$entry  = is_array( $c['today_posts'] ) ? $c['today_posts'] : array();

	if ( empty( $entry ) && (int) $c['day'] > 0 ) {
		// created earlier today under a pre-3.5.3 build — best-effort DB fallback
		$ids = get_posts( array(
			'post_type'      => 'post',
			'post_status'    => array( 'publish', 'draft', 'pending', 'future', 'private' ),
			'posts_per_page' => 31,
			'fields'         => 'ids',
			'meta_key'       => '_cpg_post',
			'meta_value'     => '1',
			'date_query'     => array( array( 'after' => current_time( 'Y-m-d' ) . ' 00:00:00' ) ),
		) );
		foreach ( (array) $ids as $fb_id ) {
			$fb_p = get_post( (int) $fb_id );
			if ( $fb_p ) {
				$entry[ (int) $fb_id ] = array( 'time' => substr( (string) $fb_p->post_date, 11, 5 ), 'title' => $fb_p->post_title );
			}
		}
	}

	$created = max( count( $entry ), 0 );
	$lines   = array();
	$shown   = 0;
	$gone    = 0;
	foreach ( $entry as $tp_id => $e ) {
		$p     = get_post( (int) $tp_id );
		$title = isset( $e['title'] ) ? trim( (string) $e['title'] ) : '';
		$time  = isset( $e['time'] ) ? $e['time'] : '';
		if ( $p && 'post' === $p->post_type && 'trash' === $p->post_status ) {
			$gone++; // v3.5.4: still listed from memory — restorable from Trash
			if ( $shown < 30 ) {
				$lines[] = '  — #' . (int) $tp_id . ' ' . $title . ' (' . $time . ', now in Trash)';
			}
			$shown++;
			continue;
		}
		if ( ! $p || 'post' !== $p->post_type || ! in_array( $p->post_status, array( 'publish', 'draft', 'pending', 'future', 'private' ), true ) ) {
			$gone++; // v3.5.4: still listed with its memorized title — the log answers
			// "what was created today" even if the post no longer exists
			if ( $shown < 30 ) {
				$lines[] = '  — #' . (int) $tp_id . ' ' . $title . ' (' . $time . ', later deleted)';
			}
			$shown++;
			continue;
		}
		if ( $shown < 30 ) {
			$lines[] = '  — #' . (int) $tp_id . ' ' . $p->post_title . ' (' . $time . ')';
		}
		$shown++;
	}

	if ( 0 === $created && 0 === (int) $c['day'] ) {
		return array( '[TODAY] 0 CPG posts created so far today' . $cap );
	}
	if ( 0 === $created && (int) $c['day'] > 0 ) {
		return array( '[TODAY] ' . (int) $c['day'] . ' CPG post(s) created so far today (per counter; list unavailable — created before v3.5.3)' . $cap );
	}
	$header = '[TODAY] ' . $created . ' CPG post(s) created so far today' . $cap;
	if ( $gone > 0 ) {
		$header .= ' — ' . $gone . ' later deleted/trashed';
	}
	array_unshift( $lines, $header );
	if ( $shown > 30 ) {
		$lines[] = '  — … more';
	}
	return $lines;
}

function cpg_counter() {
	$c = get_option( 'cpg_counter', array() );
	if ( ! is_array( $c ) ) {
		$c = array(); // F9: corrupt-option guard
	}
	$today = current_time( 'Y-m-d' ); // F8: site timezone — caps reset at LOCAL midnight
	if ( ! isset( $c['date'] ) || $c['date'] !== $today ) {
		$c = array( 'date' => $today, 'day' => 0, 'run' => 0, 'today_posts' => array() );
	}
	if ( ! isset( $c['today_posts'] ) || ! is_array( $c['today_posts'] ) ) {
		$c['today_posts'] = array(); // v3.5.3 normalize older counters
	}
	return $c;
}

function cpg_throttle_hit( $s ) {
	$c = cpg_counter();
	if ( (int) $s['max_posts_run'] > 0 && (int) $c['run'] >= (int) $s['max_posts_run'] ) {
		return 'per-run cap reached';
	}
	if ( (int) $s['max_posts_day'] > 0 && (int) $c['day'] >= (int) $s['max_posts_day'] ) {
		return 'daily cap reached';
	}
	return '';
}

function cpg_counter_bump( $post_id = 0, $title = '' ) {
	$c = cpg_counter();
	$c['run']++;
	$c['day']++;
	if ( $post_id ) { // v3.5.3: remember WHAT was created today — same store as the cap,
		// so the [TODAY] log line can never disagree with "daily cap X/Y used".
		$c['today_posts'][ (int) $post_id ] = array(
			'time'  => current_time( 'H:i' ),
			'title' => $title,
		);
		if ( count( $c['today_posts'] ) > 60 ) {
			$c['today_posts'] = array_slice( $c['today_posts'], -60, null, true );
		}
	}
	update_option( 'cpg_counter', $c, false );
}

/* =====================================================================
 * POST CREATION / UPDATE (duplicates & deletion policy)
 * =================================================================== */

function cpg_store_collection_post( $key, $source, $dresses, $s ) {
	$state = get_option( 'cpg_state', array() );
	if ( ! is_array( $state ) ) {
		$state = array(); // F9: corrupt-option guard
	}
	$prev  = isset( $state[ $key ] ) ? $state[ $key ] : array( 'post_id' => 0, 'ids' => array() );
	if ( ! is_array( $prev ) ) {
		$prev = array( 'post_id' => 0, 'ids' => array() );
	}

	// rejected line: user deleted its draft once -> never again
	if ( ! empty( $prev['rejected'] ) ) {
		return array( 'action' => 'SKIPPED', 'detail' => 'line rejected earlier (draft deleted)' );
	}

	$max = (int) $s['max_dresses'];
	if ( $max > 0 ) {
		$dresses = array_slice( $dresses, 0, $max );
	}

	$all_ids = wp_list_pluck( $dresses, 'id' );
	$new_ids = array_diff( $all_ids, (array) $prev['ids'] );

	$post_id  = 0;
	$adopted  = false;
	if ( ! empty( $prev['post_id'] ) ) {
		$existing = get_post( (int) $prev['post_id'] );
		if ( $existing && 'trash' !== $existing->post_status ) {
			$post_id = (int) $prev['post_id'];
		} elseif ( ! empty( $s['respect_deletion'] ) ) {
			$state[ $key ] = array(
				'post_id'  => 0,
				'ids'      => array_slice( array_unique( array_merge( (array) $prev['ids'], $all_ids ) ), 0, CPG_IDS_MEMORIZED ),
				'rejected' => 1,
				'updated'  => time(),
			);
			update_option( 'cpg_state', $state, false );
			return array( 'action' => 'SKIPPED', 'detail' => 'draft deleted by user — line marked rejected' );
		}
	}

	/* v3.5 adopt-or-create: state lost/reset but a live post for this line exists ->
	 * re-bind instead of duplicating. Season must match (annual relaunch = new post). */
	if ( 0 === $post_id ) {
		$want_title = sanitize_text_field( $source['name'] );
		$want_season = isset( $source['cpg_season'] ) ? (string) $source['cpg_season'] : '';
		$cands = get_posts( array(
			'post_type'      => 'post',
			'post_status'    => array( 'publish', 'draft', 'pending', 'future', 'private' ),
			'title'          => $want_title,
			'posts_per_page' => 5,
			'fields'         => 'ids',
		) );
		if ( empty( $cands ) && preg_match( '~^(.*) \d{4}$~', $want_title, $bt ) ) {
			// year-less legacy post ("... (LG-RL-0463)") vs new titled "... (LG-RL-0463) 2026"
			$cands = get_posts( array(
				'post_type'      => 'post',
				'post_status'    => array( 'publish', 'draft', 'pending', 'future', 'private' ),
				'title'          => $bt[1],
				'posts_per_page' => 5,
				'fields'         => 'ids',
			) );
		}
		foreach ( (array) $cands as $cand ) {
			$cand_season = (string) get_post_meta( (int) $cand, '_cpg_season', true );
			if ( '' === $cand_season || $cand_season === $want_season ) {
				$post_id = (int) $cand;
				$adopted = true;
				$prev['ids'] = array_slice( array_unique( array_merge( (array) $prev['ids'], $all_ids ) ), 0, CPG_IDS_MEMORIZED );
				$new_ids     = array();
				update_post_meta( $post_id, '_cpg_post', 1 );
				update_post_meta( $post_id, '_cpg_key', $key );
				if ( '' !== $want_season ) {
					update_post_meta( $post_id, '_cpg_season', $want_season );
				}
				break;
			}
		}
	}

	if ( 0 === $post_id ) {
		$cap = cpg_throttle_hit( $s );
		if ( '' !== $cap ) {
			return array( 'action' => 'THROTTLED', 'detail' => $cap );
		}
		$post_id = wp_insert_post( array(
			'post_title'     => sanitize_text_field( $source['name'] ),
			'post_status'    => sanitize_key( $s['post_status'] ),
			'post_type'      => 'post',
			'post_category'  => cpg_category_ids( $source, $s ),
			'post_content'   => '', // placeholder — real content is built below, once the ID exists
		), true );
		if ( is_wp_error( $post_id ) ) {
			return array( 'action' => 'ERROR', 'detail' => $post_id->get_error_message() );
		}

		update_post_meta( $post_id, '_cpg_post', 1 );          // marker: ours
		update_post_meta( $post_id, '_cpg_key', $key );        // marker: which line
		if ( ! empty( $source['cpg_season'] ) ) {
			update_post_meta( $post_id, '_cpg_season', sanitize_key( $source['cpg_season'] ) ); // v3.5: which year
		}

		if ( ! empty( $source['tags'] ) ) {
			wp_set_post_tags( $post_id, array_map( 'sanitize_text_field', (array) $source['tags'] ), true );
		}

		/* v3.2 fix: build the content NOW, with the real post ID — this is what makes
		 * cpg_img_tag() sideload every image into the Media Library attached to this
		 * post. (Before, content was built with ID 0, sideload never ran, and images
		 * stayed on the store CDN.) */
		wp_update_post( array(
			'ID'           => $post_id,
			'post_content' => cpg_build_dress_blocks( $dresses, $post_id, $s ) . cpg_build_outro( $source, $s ) . cpg_build_brand_footer( $source, $s ),
		) );

		cpg_set_featured( $post_id, $dresses, $s ); // reuses the already-imported image via _cpg_src
		cpg_counter_bump( $post_id, sanitize_text_field( $source['name'] ) );
		$action = 'CREATED';
		$detail = count( $dresses ) . ' designs — post #' . $post_id;
	} else {
		$action = 'OK';
		$detail = $adopted
			? 'adopted existing post #' . $post_id . ' (state had been reset — no duplicate created, post locked)'
			: 'post #' . $post_id . ' already announced (' . count( $dresses ) . ' designs) — locked, no updates by design';
	}

	$state[ $key ] = array(
		'post_id' => $post_id ? $post_id : ( isset( $prev['post_id'] ) ? $prev['post_id'] : 0 ),
		'ids'     => array_slice( array_unique( array_merge( (array) $prev['ids'], $all_ids ) ), 0, CPG_IDS_MEMORIZED ),
		'updated' => time(),
	);
	update_option( 'cpg_state', $state, false );

	return array( 'action' => $action, 'detail' => $detail );
}

function cpg_category_ids( $source, $s ) {
	$slug = isset( $source['category'] ) ? sanitize_title( $source['category'] ) : sanitize_title( $s['category'] );
	if ( '' === $slug ) {
		return array();
	}
	$term = get_term_by( 'slug', $slug, 'category' );
	if ( $term ) {
		return array( (int) $term->term_id );
	}
	$created = wp_insert_term( $slug, 'category', array( 'slug' => $slug ) );
	if ( is_wp_error( $created ) ) {
		return array();
	}
	return array( (int) $created['term_id'] );
}

/* =====================================================================
 * OUTPUT BUILDERS (clean by construction; images without srcset)
 * =================================================================== */

function cpg_build_outro( $source, $s ) {
	if ( empty( $s['link_collection'] ) ) {
		return '';
	}
	$link = isset( $source['collection_link'] ) ? $source['collection_link'] : '';
	if ( '' === $link ) {
		return '';
	}
	return '<p><em><a href="' . esc_url( $link ) . '" target="_blank" rel="nofollow noopener">View this collection at the store</a></em></p>' . "\n";
}

function cpg_build_dress_blocks( $dresses, $post_id, $s ) {
	$html = '';
	$i    = 0;
	foreach ( $dresses as $d ) {
		$i++;
		$html .= '<h3>' . esc_html( $d['title'] ) . '</h3>' . "\n";
		if ( '' !== $d['price'] ) {
			$html .= '<p><strong>' . esc_html( $d['price'] ) . '</strong></p>' . "\n";
		}
		foreach ( $d['imgs'] as $src ) {
			$html .= cpg_img_tag( $src, $d['title'], $post_id, $s ) . "\n";
		}
		if ( '' !== $d['desc'] ) {
			$html .= '<p>' . esc_html( $d['desc'] ) . '</p>' . "\n";
		}
	}
	return $html;
}

function cpg_img_tag( $src, $alt, $post_id, $s ) {
	$width = ( (int) $s['img_width'] > 0 ) ? ' width="' . (int) $s['img_width'] . '"' : '';

	if ( ! empty( $s['sideload_all'] ) && $post_id ) {
		$id = cpg_sideload( $src, $post_id, $alt );
		if ( $id ) {
			$url = wp_get_attachment_url( $id );
			if ( $url ) {
				return '<img src="' . esc_url( $url ) . '" alt="' . esc_attr( $alt ) . '" loading="lazy"' . $width . ' />';
			}
		}
	}
	// fallback: CDN-hotlinked, plain tag (no srcset/sizes)
	return '<img src="' . esc_url( $src ) . '" alt="' . esc_attr( $alt ) . '" loading="lazy"' . $width . ' />';
}

/**
 * Download an image ONCE: if this exact source URL was already imported
 * (for any post), reuse that attachment instead of storing duplicates.
 */
function cpg_sideload( $src, $post_id, $alt ) {
	$src = esc_url_raw( $src );
	if ( '' === $src ) {
		return 0;
	}

	$existing = get_posts( array(
		'post_type'      => 'attachment',
		'post_status'    => 'inherit',
		'posts_per_page' => 1,
		'fields'         => 'ids',
		'meta_key'       => '_cpg_src',
		'meta_value'     => $src,
	) );
	if ( ! empty( $existing ) ) {
		cpg_media_tally( 'reuse' );
		return (int) $existing[0];
	}

	cpg_load_media_admin();
	$id = media_sideload_image( $src, $post_id, sanitize_text_field( $alt ), 'id' );
	if ( is_wp_error( $id ) ) {
		cpg_media_tally( 'fail', $id->get_error_message() );
		return 0;
	}
	update_post_meta( (int) $id, '_cpg_src', $src );
	cpg_media_tally( 'dl' );
	return (int) $id;
}

function cpg_media_tally( $kind, $err = '' ) {
	if ( ! isset( $GLOBALS['cpg_media'] ) ) {
		$GLOBALS['cpg_media'] = array( 'dl' => 0, 'reuse' => 0, 'fail' => 0, 'err' => '' );
	}
	if ( isset( $GLOBALS['cpg_media'][ $kind ] ) ) {
		$GLOBALS['cpg_media'][ $kind ]++;
	}
	if ( '' !== $err && '' === $GLOBALS['cpg_media']['err'] ) {
		$GLOBALS['cpg_media']['err'] = $err;
	}
}

function cpg_load_media_admin() {
	if ( ! function_exists( 'download_url' ) ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
	}
	if ( ! function_exists( 'media_handle_sideload' ) ) {
		require_once ABSPATH . 'wp-admin/includes/media.php';
	}
	if ( ! function_exists( 'wp_read_image_metadata' ) ) {
		require_once ABSPATH . 'wp-admin/includes/image.php';
	}
}

function cpg_set_featured( $post_id, $dresses, $s ) {
	if ( empty( $dresses[0]['imgs'] ) ) {
		return;
	}
	/* v3.3: try every image of every dress until one imports —
	 * a dead CDN asset on dress #1 no longer leaves the post thumbnail-less. */
	foreach ( (array) $dresses as $d ) {
		if ( empty( $d['imgs'] ) ) {
			continue;
		}
		foreach ( $d['imgs'] as $src ) {
			$id = cpg_sideload( $src, $post_id, $d['title'] );
			if ( $id ) {
				set_post_thumbnail( $post_id, $id );
				return;
			}
		}
	}
}

/* =====================================================================
 * FRONT-END: optional srcset/sizes removal on OUR posts only
 * (mirrors WPA's "remove srcset" behavior, scoped to CPG posts)
 * =================================================================== */

add_filter( 'the_content', 'cpg_maybe_strip_srcset', 999 );
function cpg_maybe_strip_srcset( $content ) {
	$s = cpg_settings();
	if ( empty( $s['strip_srcset'] ) || ! is_singular() || ! in_the_loop() ) {
		return $content;
	}
	if ( 1 !== (int) get_post_meta( get_the_ID(), '_cpg_post', true ) ) {
		return $content;
	}
	$content = preg_replace( '/\s+(srcset|sizes|decoding|fetchpriority)="[^"]*"/i', '', $content );
	return $content;
}

/* =====================================================================
 * MAINTENANCE: state cleanup, trash-ours, full reset
 * =================================================================== */

function cpg_cleanup() {
	$s     = cpg_settings();
	$state = get_option( 'cpg_state', array() );
	if ( ! is_array( $state ) ) {
		$state = array(); // F9: corrupt-option guard
	}
	$before = count( $state );
	$pruned = 0;
	$days   = max( 0, (int) $s['prune_days'] );

	foreach ( $state as $key => $entry ) {
		$pid   = ! empty( $entry['post_id'] ) ? (int) $entry['post_id'] : 0;
		$post  = $pid ? get_post( $pid ) : null;
		$alive = $post && 'trash' !== $post->post_status;

		if ( $alive && empty( $entry['rejected'] ) ) {
			continue; // active lines are never pruned
		}
		if ( $days > 0 && ( time() - (int) $entry['updated'] ) > $days * DAY_IN_SECONDS ) {
			unset( $state[ $key ] );
			$pruned++;
		}
	}
	update_option( 'cpg_state', $state, false );

	$lines   = array(
		'DIT Fashion Posts Generator — cleanup ' . date_i18n( 'Y-m-d H:i' ),
		'cpg_state: ' . $before . ' -> ' . count( $state ) . ' entries (pruned ' . $pruned . ')',
		'cpg_meta cursors: ' . count( (array) get_option( 'cpg_meta', array() ) ),
		'cpg_brands caches: ' . count( (array) get_option( 'cpg_brands', array() ) ),
		'Active lines are never pruned (pruning them would duplicate posts).',
	);
	return implode( "\n", $lines );
}

function cpg_trash_ours() {
	$n = 0;
	for ( $batch = 0; $batch < 30; $batch++ ) { // v3.3: handle more than 500 generated posts
		$q = new WP_Query( array(
			'post_type'      => 'post',
			'post_status'    => array( 'draft', 'pending', 'publish', 'future' ),
			'posts_per_page' => 500,
			'fields'         => 'ids',
			'meta_query'     => array(
				array( 'key' => '_cpg_post', 'value' => '1' ),
			),
		) );
		if ( empty( $q->posts ) ) {
			break;
		}
		foreach ( $q->posts as $pid ) {
			if ( wp_trash_post( $pid ) ) {
				$n++;
			}
		}
		if ( count( $q->posts ) < 500 ) {
			break;
		}
	}
	/* trashing posts flips their state entries to "rejected" on next run;
	   if you want a clean re-generation instead, use Reset (below) */
	return 'Trashed ' . $n . ' generated posts (find them in Trash).';
}

function cpg_reset_all() {
	delete_option( 'cpg_state' );
	delete_option( 'cpg_meta' );
	delete_option( 'cpg_brands' );
	delete_option( 'cpg_counter' ); // v3.3: caps start fresh too — regenerating is never blocked
	delete_transient( 'cpg_lock' );
	return 'Plugin state reset. Next run behaves like day one: caps start fresh, lines may be generated again. Existing posts are NOT touched.';
}

/* =====================================================================
 * ADMIN SCREEN: Settings → DIT Fashion PG
 * =================================================================== */

add_action( 'admin_menu', 'cpg_admin_menu' );
function cpg_admin_menu() {
	add_options_page( 'DIT Fashion Posts Generator', 'DIT Fashion PG', 'manage_options', 'cpg-settings', 'cpg_settings_page' );
}

add_action( 'admin_post_cpg_save_settings', 'cpg_handle_save_settings' );
function cpg_handle_save_settings() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Not allowed' );
	}
	check_admin_referer( 'cpg_admin', '_cpg_nonce' );

	$in = isset( $_POST['cpg'] ) && is_array( $_POST['cpg'] ) ? wp_unslash( $_POST['cpg'] ) : array();

	$clean = array(
		'paused'           => empty( $in['paused'] ) ? 0 : 1,
		'post_status'      => in_array( isset( $in['post_status'] ) ? $in['post_status'] : '', array( 'draft', 'pending', 'publish' ), true ) ? $in['post_status'] : 'draft',
		'category'         => sanitize_title( isset( $in['category'] ) ? $in['category'] : '' ),
		'max_dresses'      => min( 60, max( 1, (int) ( isset( $in['max_dresses'] ) ? $in['max_dresses'] : 15 ) ) ),
		'img_per_dress'    => min( 6, max( 1, (int) ( isset( $in['img_per_dress'] ) ? $in['img_per_dress'] : 1 ) ) ),
		'min_dresses'      => min( 50, max( 1, (int) ( isset( $in['min_dresses'] ) ? $in['min_dresses'] : 5 ) ) ),
		'age_days'         => min( 3650, max( 0, (int) ( isset( $in['age_days'] ) ? $in['age_days'] : 0 ) ) ),
		'proxy_provider'   => cpg_proxy_provider_id( isset( $in['proxy_provider'] ) ? $in['proxy_provider'] : '' ),
		'proxy_key'        => isset( $in['proxy_key'] ) ? trim( sanitize_text_field( $in['proxy_key'] ) ) : '',
		'proxy_premium'    => empty( $in['proxy_premium'] ) ? 0 : 1,
		'proxy_provider2'  => cpg_proxy_provider_id( isset( $in['proxy_provider2'] ) ? $in['proxy_provider2'] : '' ),
		'proxy_key2'       => isset( $in['proxy_key2'] ) ? trim( sanitize_text_field( $in['proxy_key2'] ) ) : '',
		'proxy_custom'     => isset( $in['proxy_custom'] ) ? trim( sanitize_text_field( $in['proxy_custom'] ) ) : '',
		'brands_per_run'   => min( 50, max( 1, (int) ( isset( $in['brands_per_run'] ) ? $in['brands_per_run'] : 10 ) ) ),
		'img_width'        => min( 2000, max( 0, (int) ( isset( $in['img_width'] ) ? $in['img_width'] : 600 ) ) ),
		'max_posts_run'    => min( 50, max( 0, (int) ( isset( $in['max_posts_run'] ) ? $in['max_posts_run'] : 1 ) ) ),
		'max_posts_day'    => min( 100, max( 0, (int) ( isset( $in['max_posts_day'] ) ? $in['max_posts_day'] : 2 ) ) ),
		'sideload_all'     => empty( $in['sideload_all'] ) ? 0 : 1,
		'link_collection'  => empty( $in['link_collection'] ) ? 0 : 1,
		'strip_srcset'     => empty( $in['strip_srcset'] ) ? 0 : 1,
		'respect_deletion' => empty( $in['respect_deletion'] ) ? 0 : 1,
		'prune_days'       => min( 3650, max( 0, (int) ( isset( $in['prune_days'] ) ? $in['prune_days'] : 90 ) ) ),
		'desc_chars'       => min( 2000, max( 0, (int) ( isset( $in['desc_chars'] ) ? $in['desc_chars'] : 400 ) ) ),
	);

	update_option( 'cpg_settings', $clean, false );
	wp_safe_redirect( add_query_arg( array( 'page' => 'cpg-settings', 'msg' => 'saved' ), admin_url( 'options-general.php' ) ) );
	exit;
}

function cpg_handle_action( $action ) {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Not allowed' );
	}
	check_admin_referer( 'cpg_admin_action_' . $action );

	switch ( $action ) {
		case 'run':
			$out = cpg_run( true ); // manual run: bigger time budget
			break;
		case 'cleanup':
			$out = cpg_cleanup();
			break;
		case 'trash':
			$out = cpg_trash_ours();
			break;
		case 'reset':
			$out = cpg_reset_all();
			break;
		default:
			$out = 'Unknown action';
	}
	return $out;
}

function cpg_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Not allowed' );
	}

	$msg = '';
	if ( isset( $_GET['cpg_action'] ) ) {
		$msg = cpg_handle_action( sanitize_key( $_GET['cpg_action'] ) );
	} elseif ( isset( $_GET['msg'] ) && 'saved' === $_GET['msg'] ) {
		$msg = 'Settings saved.';
	}

	$s      = cpg_settings();
	$state  = (array) get_option( 'cpg_state', array() );
	$last   = get_option( 'cpg_last_run', array() );
	$drafts = 0;
	$count_q = new WP_Query( array(
		'post_type'      => 'post',
		'post_status'    => array( 'draft', 'pending', 'publish', 'future', 'trash' ),
		'posts_per_page' => 1,
		'fields'         => 'ids',
		'meta_query'     => array( array( 'key' => '_cpg_post', 'value' => '1' ) ),
	) );
	$drafts = (int) $count_q->found_posts;

	$nonce_field = wp_nonce_field( 'cpg_admin', '_cpg_nonce', true, false );
	?>
	<div class="wrap">
		<h1>DIT Fashion Posts Generator <code>v3.5.8</code></h1>

		<?php if ( $msg ) : ?>
			<div class="notice notice-success"><pre style="white-space:pre-wrap;margin:8px 0"><?php echo esc_html( $msg ); ?></pre></div>
		<?php endif; ?>

		<?php if ( $s['paused'] ) : ?>
			<div class="notice notice-warning"><p><strong>Paused</strong> — the 6-hour cron is doing nothing until you untick “Pause”.</p></div>
		<?php endif; ?>

		<h2>Status</h2>
		<table class="widefat striped" style="max-width:640px">
			<tr><td>Generated posts (all statuses)</td><td><strong><?php echo esc_html( number_format_i18n( $drafts ) ); ?></strong></td></tr>
			<tr><td>Lines memorized (state entries)</td><td><strong><?php echo esc_html( number_format_i18n( count( $state ) ) ); ?></strong></td></tr>
			<?php
			$next       = wp_next_scheduled( CPG_CRON );
			$scheds     = wp_get_schedules();
			$engine     = ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON )
				? 'DISABLE_WP_CRON is set — a SERVER cron must call wp-cron.php, WP will never trigger itself'
				: 'WP-Cron (fires on page visits — no visitors = runs wait)';
			$interval_ok = isset( $scheds['cpg_interval'] );
			?>
			<tr><td>Cron engine</td><td><?php echo esc_html( $engine ); ?></td></tr>
			<tr><td>Next scheduled run</td><td><?php
				if ( $next ) {
					$pretty = esc_html( get_date_from_gmt( gmdate( 'Y-m-d H:i:s', $next ), 'Y-m-d H:i' ) );
					$diff   = $next - time();
					if ( $diff > 0 ) {
						echo $pretty . esc_html( sprintf( ' (in %d min)', max( 1, (int) round( $diff / 60 ) ) ) );
					} else {
						echo '<span style="color:#b32d2e;font-weight:600">' . $pretty . esc_html( sprintf( ' — OVERDUE by %d min. Fires on the next page visit (or server cron hit).', (int) round( - $diff / 60 ) ) ) . '</span>';
					}
				} else {
					echo '<span style="color:#b32d2e;font-weight:600">NOT SCHEDULED</span> — v3.3.2 auto-heals this on any WP page load; reload this page.';
				}
			?></td></tr>
			<tr><td>cpg_interval (6 h) registered</td><td><?php
				echo $interval_ok
					? 'yes'
					: '<span style="color:#b32d2e;font-weight:600">NO — another plugin/plugin-update broke the cron_schedules filter</span>';
			?></td></tr>
			<tr><td>Last run</td><td><?php echo esc_html( ! empty( $last['time'] ) ? get_date_from_gmt( gmdate( 'Y-m-d H:i:s', $last['time'] ), 'Y-m-d H:i' ) : 'never' ); ?></td></tr>
			<tr><td>Posts created today</td><td><strong><?php echo esc_html( (int) cpg_counter()['day'] ); ?></strong> / <?php echo esc_html( 0 === (int) $s['max_posts_day'] ? 'unlimited' : (string) (int) $s['max_posts_day'] ); ?></td></tr>
		</table>

		<?php if ( ! empty( $last['log'] ) ) : ?>
			<h3>Last run log</h3>
			<pre style="background:#fff;border:1px solid #ccd0d4;padding:10px;max-width:860px;white-space:pre-wrap"><?php echo esc_html( $last['log'] ); ?></pre>
		<?php endif; ?>

		<h2>Maintenance</h2>
		<p>
			<a class="button button-primary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'options-general.php?page=cpg-settings&cpg_action=run' ), 'cpg_admin_action_run' ) ); ?>">Run now</a>
			<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'options-general.php?page=cpg-settings&cpg_action=cleanup' ), 'cpg_admin_action_cleanup' ) ); ?>">Cleanup state</a>
			<a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'options-general.php?page=cpg-settings&cpg_action=trash' ), 'cpg_admin_action_trash' ) ); ?>" onclick="return confirm('Move ALL generated posts to Trash?');">Trash all generated posts</a>
			<a class="button button-link-delete" href="<?php echo esc_url( wp_nonce_url( admin_url( 'options-general.php?page=cpg-settings&cpg_action=reset' ), 'cpg_admin_action_reset' ) ); ?>" onclick="return confirm('Reset memorized lines? Posts stay, but lines may be generated again.');">Reset memory</a>
		</p>

		<h2>Settings</h2>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="cpg_save_settings" />
			<?php echo $nonce_field; // phpcs:ignore ?>
			<table class="form-table">
				<tr><th>Pause</th><td><label><input type="checkbox" name="cpg[paused]" value="1" <?php checked( $s['paused'], 1 ); ?> /> Pause automatic runs (cron does nothing)</label></td></tr>
				<tr><th>Post status</th><td>
					<select name="cpg[post_status]">
						<option value="draft" <?php selected( $s['post_status'], 'draft' ); ?>>Draft</option>
						<option value="pending" <?php selected( $s['post_status'], 'pending' ); ?>>Pending review</option>
						<option value="publish" <?php selected( $s['post_status'], 'publish' ); ?>>Published</option>
					</select></td></tr>
				<tr><th>Category slug</th><td><input type="text" name="cpg[category]" value="<?php echo esc_attr( $s['category'] ); ?>" class="regular-text" /><p class="description">Created automatically if missing (default: for-fashion).</p></td></tr>
				<tr><th>Max dresses per post</th><td><input type="number" name="cpg[max_dresses]" value="<?php echo esc_attr( $s['max_dresses'] ); ?>" min="1" max="60" /></td></tr>
				<tr><th>Images per dress</th><td><input type="number" name="cpg[img_per_dress]" value="<?php echo esc_attr( $s['img_per_dress'] ); ?>" min="1" max="6" /></td></tr>
				<tr><th>Min dresses per line</th><td><input type="number" name="cpg[min_dresses]" value="<?php echo esc_attr( $s['min_dresses'] ); ?>" min="1" max="50" /><p class="description">Lines with fewer designs are skipped (default 5).</p></td></tr>
				<tr><th>Age filter (days)</th><td><input type="number" name="cpg[age_days]" value="<?php echo esc_attr( $s['age_days'] ); ?>" min="0" max="3650" /><p class="description">0 = post every line. E.g. 45 = only lines whose newest dress is &lt; 45 days old.</p></td></tr>
				<tr><th>Proxy fallback</th><td>
				<?php $prov_opts = array( '' => 'Off', 'scrapingant' => 'ScrapingAnt (10k credits free/mo)', 'zenrows' => 'ZenRows (5k free/mo)', 'scraperapi' => 'ScraperAPI (1k free/mo)', 'scrapingbee' => 'ScrapingBee (1k free)', 'crawlbase' => 'Crawlbase (1k–5k free)', 'custom' => 'Custom relay / own Worker' ); ?>
				Primary: <select name="cpg[proxy_provider]"><?php foreach ( $prov_opts as $pv => $pl ) : ?><option value="<?php echo esc_attr( $pv ); ?>" <?php selected( $s['proxy_provider'], $pv ); ?>><?php echo esc_html( $pl ); ?></option><?php endforeach; ?></select>
				key <input type="password" name="cpg[proxy_key]" value="<?php echo esc_attr( $s['proxy_key'] ); ?>" size="24" autocomplete="off" /><br/>
				Backup: <select name="cpg[proxy_provider2]"><?php foreach ( $prov_opts as $pv => $pl ) : ?><option value="<?php echo esc_attr( $pv ); ?>" <?php selected( $s['proxy_provider2'], $pv ); ?>><?php echo esc_html( $pl ); ?></option><?php endforeach; ?></select>
				key <input type="password" name="cpg[proxy_key2]" value="<?php echo esc_attr( $s['proxy_key2'] ); ?>" size="24" autocomplete="off" /><br/>
				<label><input type="checkbox" name="cpg[proxy_premium]" value="1" <?php checked( $s['proxy_premium'], 1 ); ?> /> ZenRows premium proxies (10 credits/fetch — only for hard blocks)</label><br/>
				Custom relay template: <input type="text" name="cpg[proxy_custom]" value="<?php echo esc_attr( $s['proxy_custom'] ); ?>" size="52" /> <span class="description">must contain {URL}, e.g. https://your-worker.workers.dev/relay/SECRET/?url={URL}</span>
				<p class="description">Fires ONLY when a direct fetch fails twice. 404 feeds are never proxied; max 3 proxy failures per run. A plain feed fetch costs 1 credit on every provider. Empty keys = off.</p></td></tr>
			<tr><th>Brands per run (auto mode)</th><td><input type="number" name="cpg[brands_per_run]" value="<?php echo esc_attr( $s['brands_per_run'] ); ?>" min="1" max="50" /></td></tr>
				<tr><th>New posts per run</th><td><input type="number" name="cpg[max_posts_run]" value="<?php echo esc_attr( $s['max_posts_run'] ); ?>" min="0" max="50" /><p class="description">Cron runs every 6h — 1 per run = up to 4/day. 0 = unlimited.</p></td></tr>
				<tr><th>New posts per day</th><td><input type="number" name="cpg[max_posts_day]" value="<?php echo esc_attr( $s['max_posts_day'] ); ?>" min="0" max="100" /><p class="description">Hard daily ceiling across all runs. 0 = unlimited. Appended updates never count.</p></td></tr>
				<tr><th>Image width attr (px)</th><td><input type="number" name="cpg[img_width]" value="<?php echo esc_attr( $s['img_width'] ); ?>" min="0" max="2000" /></td></tr>
				<tr><th>Description length (chars)</th><td><input type="number" name="cpg[desc_chars]" value="<?php echo esc_attr( $s['desc_chars'] ); ?>" min="0" max="2000" /></td></tr>
				<tr><th>Download images</th><td><label><input type="checkbox" name="cpg[sideload_all]" value="1" <?php checked( $s['sideload_all'], 1 ); ?> /> Import every image into the Media Library — nothing stays hotlinked from the store CDN (default ON)</label></td></tr>
			<tr><th>Collection link</th><td><label><input type="checkbox" name="cpg[link_collection]" value="1" <?php checked( $s['link_collection'], 1 ); ?> /> Add a small “View this collection” link at the end of each post (default OFF)</label></td></tr>
				<tr><th>Remove srcset/sizes</th><td><label><input type="checkbox" name="cpg[strip_srcset]" value="1" <?php checked( $s['strip_srcset'], 1 ); ?> /> Strip srcset/sizes attributes on generated posts (front-end), like WPA</label></td></tr>
				<tr><th>Brand footer</th><td><label><input type="checkbox" name="cpg[brand_footer]" value="1" <?php checked( $s['brand_footer'], 1 ); ?> /> Append “Get your favorite dress from [Brand] Website…” line with the brand’s own links (never Sanaulla)</label></td></tr>
			<tr><th>Brand links map</th><td><textarea name="cpg[brand_links]" rows="4" class="large-text code" placeholder="Leave empty to use the built-in verified map (186 brands)."><?php echo esc_textarea( $s['brand_links'] ); ?></textarea><p class="description">Merged ON TOP of the built-in map: your line <strong>overrides</strong> that brand, a new handle is <strong>added</strong>. One per line: <code>handle | Name | https://site | https://instagram</code> (handle = Sanaulla collection slug, e.g. <code>mushq</code>; leave a field empty for single-link). <code>handle | Name | - | -</code> disables that brand.</p></td></tr>
			<tr><th>Respect deletion</th><td><label><input type="checkbox" name="cpg[respect_deletion]" value="1" <?php checked( $s['respect_deletion'], 1 ); ?> /> Deleting a draft = that line is rejected forever (never recreated)</label></td></tr>
				<tr><th>State prune (days)</th><td><input type="number" name="cpg[prune_days]" value="<?php echo esc_attr( $s['prune_days'] ); ?>" min="0" max="3650" /></td></tr>
			</table>
			<?php submit_button( 'Save settings' ); ?>
		</form>

		<h2>Sources</h2>
		<p>Stores to track are defined in <code>cpg_default_sources()</code> inside the plugin file — see the header comment there. Everything above is stored safely in the DB (autoload off).</p>
	</div>
	<?php
}
