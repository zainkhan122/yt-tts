<?php

/**
 * DB Post Finder
 *
 * @package SEO_Article_Generator
 */

namespace SEO_Article_Generator\Links;

use SEO_Article_Generator\Logger;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Find relevant internal links from WordPress database
 * 
 * @MODIFIED 2025-12-01 - Added DB post search capability for hybrid link discovery
 */
class DB_Post_Finder
{
    /**
     * Logger instance
     *
     * @var Logger
     */
    private $logger;

    /**
     * Constructor
     *
     * @param Logger $logger Logger instance
     */
    public function __construct($logger)
    {
        $this->logger = $logger;
    }

    /**
     * Find related posts from database
     *
     * @param string $software_name Software name
     * @param string $category Category
     * @param int    $count Number of posts to find
     * @return array Array of related posts
     */
    public function find_related($software_name, $category, $count = 3)
    {
        $this->logger->debug('DB Post Finder: Searching posts', array(
            'software' => $software_name,
            'category' => $category,
            'count' => $count,
        ));

        $posts = array();

        // Strategy 1: Search by category/taxonomy (highest priority)
        if (!empty($category)) {
            $category_posts = $this->search_by_category($category, $count);
            $posts = array_merge($posts, $category_posts);
        }

        // Strategy 2: Search by keywords in title/content
        if (count($posts) < $count) {
            $keywords = $this->extract_keywords($software_name);
            $keyword_posts = $this->search_by_keywords($keywords, $count - count($posts));
            $posts = array_merge($posts, $keyword_posts);
        }



        // Remove duplicates
        $posts = $this->remove_duplicates($posts);

        // Limit to requested count
        $posts = array_slice($posts, 0, $count);

        $this->logger->debug('DB Post Finder: Found posts', array('count' => count($posts)));

        return $posts;
    }

    /**
     * Search posts by category
     *
     * @param string $category Category name or slug
     * @param int    $limit Result limit
     * @return array Posts
     */
    public function search_by_category($category, $limit)
    {
        // @MODIFIED 2026-01-08: Ensure category is always a string (AI may return array)
        if (is_array($category)) {
            $category = implode(', ', array_filter($category));
        }
        $category = is_string($category) ? $category : '';

        $this->logger->debug('Searching by category', array('category' => $category));

        $args = array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'posts_per_page' => $limit,
            'orderby' => 'date',
            'order' => 'DESC',
            'category_name' => sanitize_title($category),
            'no_found_rows' => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => true,
        );

        $query = new \WP_Query($args);
        $posts = $this->format_posts($query->posts);
        wp_reset_postdata();

        return $posts;
    }

    /**
     * Search posts by keywords in title and content
     *
     * @param array $keywords Keywords to search
     * @param int   $limit Result limit
     * @return array Posts
     */
    public function search_by_keywords($keywords, $limit)
    {
        if (empty($keywords)) {
            return array();
        }

        $this->logger->debug('Searching by keywords', array('keywords' => $keywords));

        // Build search query from keywords
        $search_query = implode(' ', array_slice($keywords, 0, 3)); // Use top 3 keywords

        $args = array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'posts_per_page' => $limit,
            's' => $search_query,
            'orderby' => 'relevance',
            'order' => 'DESC',
            'no_found_rows' => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
        );

        $query = new \WP_Query($args);
        $posts = $this->format_posts($query->posts);
        wp_reset_postdata();

        return $posts;
    }

    /**
     * Search posts by taxonomy terms
     *
     * @param string $taxonomy Taxonomy name
     * @param array  $terms Term slugs
     * @param int    $limit Result limit
     * @return array Posts
     */
    public function search_by_taxonomy($taxonomy, $terms, $limit)
    {
        if (empty($terms)) {
            return array();
        }

        $this->logger->debug('Searching by taxonomy', array(
            'taxonomy' => $taxonomy,
            'terms' => $terms,
        ));

        $args = array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'posts_per_page' => $limit,
            'orderby' => 'date',
            'order' => 'DESC',
            'tax_query' => array(
                array(
                    'taxonomy' => $taxonomy,
                    'field' => 'slug',
                    'terms' => $terms,
                ),
            ),
            'no_found_rows' => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => true,
        );

        $query = new \WP_Query($args);
        $posts = $this->format_posts($query->posts);
        wp_reset_postdata();

        return $posts;
    }

    /**
     * Get recent posts
     *
     * @param int    $limit Result limit
     * @param string $category Optional category filter
     * @return array Posts
     */
    public function get_recent_posts($limit, $category = '')
    {
        $this->logger->debug('Getting recent posts', array('limit' => $limit));

        $args = array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'posts_per_page' => $limit,
            'orderby' => 'date',
            'order' => 'DESC',
            'no_found_rows' => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
        );

        // Add category filter if provided
        if (!empty($category)) {
            $args['category_name'] = sanitize_title($category);
        }

        $query = new \WP_Query($args);
        $posts = $this->format_posts($query->posts);
        wp_reset_postdata();

        return $posts;
    }

    /**
     * Format WP_Post objects to array format
     *
     * @param array $posts Array of WP_Post objects
     * @return array Formatted posts
     */
    private function format_posts($posts)
    {
        $formatted = array();

        foreach ($posts as $post) {
            // Get primary category
            $categories = get_the_category($post->ID);
            $category = !empty($categories) ? $categories[0]->name : '';

            $formatted[] = array(
                'title' => $post->post_title,
                'url' => get_permalink($post->ID),
                'category' => $category,
                'source' => 'db', // @MODIFIED Track source for debugging
            );
        }

        return $formatted;
    }

    /**
     * Extract keywords from software name
     *
     * @param string $software_name Software name
     * @return array Keywords
     */
    private function extract_keywords($software_name)
    {
        // Remove version numbers
        $name = preg_replace('/\d+(\.\d+)*/', '', $software_name);

        // Remove common words
        $stop_words = array('the', 'a', 'an', 'and', 'or', 'but', 'for', 'download', 'free', 'pro', 'plus', 'edition');

        // Split into words
        $words = preg_split('/[\s\-_]+/', strtolower($name));

        // Filter stop words
        $keywords = array_filter($words, function ($word) use ($stop_words) {
            return strlen($word) > 2 && !in_array($word, $stop_words);
        });

        return array_values($keywords);
    }

    /**
     * Remove duplicate posts by URL
     *
     * @param array $posts Posts array
     * @return array Unique posts
     */
    private function remove_duplicates($posts)
    {
        $unique = array();
        $urls = array();

        foreach ($posts as $post) {
            if (!in_array($post['url'], $urls)) {
                $unique[] = $post;
                $urls[] = $post['url'];
            }
        }

        return $unique;
    }

	/**
	 * Get significant tokens from a software name for token-based slug matching.
	 * Filters out short tokens (<=2 chars), pure digits, and common stop words.
	 *
	 * @param string $name The cleaned software name.
	 * @return array Significant tokens.
	 */
	private static function get_significant_tokens(string $name): array
	{
		$stop_words = array('the','a','an','and','or','but','for','download','free','pro','plus','edition','lite','full','new','latest','setup','online','offline','mac','win','pc','os','x64','x86','bit');
		$raw = preg_split('/[\s\-_\/]+/', strtolower(trim($name)));
		$tokens = array();
		foreach ($raw as $t) {
			$t = trim($t);
			if (strlen($t) <= 2) continue;
			if (preg_match('/^\d+$/', $t)) continue;
			if (in_array($t, $stop_words, true)) continue;
			$tokens[] = $t;
		}
		return array_slice($tokens, 0, 4);
	}

	/**
	 * Check if database has any published posts
	 *
	 * @return bool True if posts exist
	 */
	public function has_posts()
    {
        $count = wp_count_posts('post');
        return isset($count->publish) && $count->publish > 0;
    }

    /**
     * Get total published post count
     *
     * @return int Post count
     */
/**
     * EXACT MATCH LOOKUP: Pipeline Deduplication Guard.
     * Resolves the "WhatsApp" and "paint.NET" duplicate generation issue.
     *
     * @param string $software_name The raw software name from discovery.
     * @return int|false Post ID if found, false if genuinely new.
     */
    public function find_exact_match($software_name)
    {
        global $wpdb;

        $this->logger->debug('DB Post Finder: Performing strict identity check', array('software' => $software_name));

        // STRATEGY 1: 100% Deterministic Meta Lookup (Fastest & Most Accurate)
        $post_id = $wpdb->get_var($wpdb->prepare(
            "SELECT p.ID FROM {$wpdb->posts} p
            INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
            WHERE pm.meta_key = '_seo_gen_software_name'
            AND pm.meta_value = %s
            AND p.post_status NOT IN ('trash', 'auto-draft')
            LIMIT 1",
            $software_name
        ));

        if ($post_id) {
            return (int) $post_id;
        }

        // STRATEGY 2: Exact Slug Match
        $normalized_slug = sanitize_title($software_name);
        $post_id = $wpdb->get_var($wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts}
            WHERE post_name = %s
            AND post_type = 'post'
            AND post_status NOT IN ('trash', 'auto-draft')
            LIMIT 1",
            $normalized_slug
        ));

        if ($post_id) {
            return (int) $post_id;
        }

        // STRATEGY 3: Exact Title Match (Case-Insensitive Database Collation)
        $post_id = $wpdb->get_var($wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts}
            WHERE post_title = %s
            AND post_type = 'post'
            AND post_status NOT IN ('trash', 'auto-draft')
            LIMIT 1",
            $software_name
        ));

        if ($post_id) {
            return (int) $post_id;
        }

        // STRATEGY 4: Normalized prefix meta match — catches "Adobe Premiere Pro" vs stored "Adobe Premiere Pro 2026"
        // Only use prefix match for names with sufficient length to avoid false positives (e.g., "Arc" matching "Archiver")
        // Use version-agnostic matching: strip version numbers before comparing
        $software_name_base = self::strip_version_number($software_name);
        $norm_prefix = sanitize_text_field(strtolower($software_name_base));
        if (strlen($norm_prefix) >= 5) {
            $post_id = $wpdb->get_var($wpdb->prepare(
                "SELECT p.ID FROM {$wpdb->posts} p
                INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
                WHERE pm.meta_key = '_seo_gen_software_name'
                AND LOWER(pm.meta_value) LIKE %s
                AND p.post_status NOT IN ('trash', 'auto-draft')
                ORDER BY LENGTH(pm.meta_value) ASC
                LIMIT 1",
                $wpdb->esc_like($norm_prefix) . '%'
            ));

            if ($post_id) {
                $this->logger->debug('DB Post Finder: Strategy 4 (prefix meta) matched', array('software' => $software_name, 'post_id' => (int) $post_id));
                return (int) $post_id;
            }
        }

        // STRATEGY 5: Slug prefix match — catches "adobe-premiere-pro" as prefix of "adobe-premiere-pro-2026-26-0"
        // Same minimum length gate to prevent short-name false positives
        // Use version-agnostic matching: strip version numbers before comparing
        $software_name_base = self::strip_version_number($software_name);
        $normalized_slug = sanitize_title($software_name_base);
        if (strlen($normalized_slug) >= 5) {
            $post_id = $wpdb->get_var($wpdb->prepare(
                "SELECT ID FROM {$wpdb->posts}
                WHERE post_name LIKE %s
                AND post_type = 'post'
                AND post_status NOT IN ('trash', 'auto-draft')
                ORDER BY LENGTH(post_name) ASC
                LIMIT 1",
                $wpdb->esc_like($normalized_slug) . '%'
            ));

            if ($post_id) {
                $this->logger->debug('DB Post Finder: Strategy 5 (prefix slug) matched', array('software' => $software_name, 'post_id' => (int) $post_id));
                return (int) $post_id;
            }
        }

        // STRATEGY 6: Token-based slug match — catches "Bitdefender Premium Security" where slug is "bitdefender-total-security"
        // Split name into tokens, find posts whose slug contains ALL significant tokens (bypassing prefix mismatch)
        $software_name_base = self::strip_version_number($software_name);
        $tokens = self::get_significant_tokens($software_name_base);
		if (count($tokens) >= 1) {
			$like_clauses = array();
			$like_args = array();
			foreach ($tokens as $token) {
				// Normalize token for slug matching: strip non-alphanumeric chars for broader matching
				// e.g. "monkey's" → "monkeys", "dr.fone" → "drfone", "o&o" → "oo"
				$bare_token = preg_replace('/[^a-z0-9]/', '', sanitize_title($token));
				if (strlen($bare_token) < 2) continue;
				$like_clauses[] = "REPLACE(REPLACE(REPLACE(LOWER(post_name), '-', ''), '.', ''), '_', '') LIKE %s";
				$like_args[] = '%' . $wpdb->esc_like($bare_token) . '%';
			}
			$where = implode(' AND ', $like_clauses);
			$post_id = $wpdb->get_var($wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts}
				WHERE ($where)
				AND post_type = 'post'
				AND post_status NOT IN ('trash', 'auto-draft')
				ORDER BY LENGTH(post_name) DESC
				LIMIT 1",
				$like_args
			));

			if ($post_id) {
				$this->logger->debug('DB Post Finder: Strategy 6 (token slug) matched', array('software' => $software_name, 'post_id' => (int) $post_id, 'tokens' => $tokens));
				return (int) $post_id;
			}
		}

		return false;
	}

	/**
	 * Strip version numbers from software name for version-agnostic matching.
	 * Handles patterns like "FanControl V267", "Adobe Photoshop 2026", "7-Zip 23.01",
	 * "SIW (System Info) 2026", "Wipe 2605 by PrivacyRoot", "Zoom Player STREAM 22.5 Beta 2", etc.
	 *
	 * @param string $software_name The software name with potential version
	 * @return string Software name with version numbers removed
	 */
	private static function strip_version_number(string $software_name): string
	{
		$name = $software_name;

		// Remove leading "V" or "v" followed by ANY version number (dotted or not, e.g., "V267", "v1.2.3")
		$name = preg_replace('/^[vV]\d+(?:\.\d+)*\s*/', '', $name);

		// Remove trailing "by <Vendor>" suffix (e.g., "Wipe 2605 by PrivacyRoot" -> "Wipe")
		$name = preg_replace('/\s+by\s+.+$/i', '', $name);

		// Remove trailing version labels + number: "Build 16.06.0513", "Beta 2", "RC 1", "SP2" etc.
		$name = preg_replace('/\s+(?:Build|Revision|Rev|RC|SP|HF|CU|Beta|Alpha|Preview|Canary|Nightly|Dev|Patch|Hotfix|Update)\s*\d*(?:\.\d+)*\s*$/i', '', $name);

		// Remove trailing version numbers with optional prefix (e.g., "23.01", "1.2.3")
		$name = preg_replace('/[\s\-]*(?:ver(?:sion)?\.?\s*)?(\d+(?:\.\d+)+)\s*$/i', '', $name);

		// Remove trailing standalone version numbers (e.g., "V267", "2605", "5.141" no-dot for 4-digit)
		// This handles "FanControl V267" -> "FanControl", "Giada 1.4.1" -> "Giada"
		$name = preg_replace('/\s+v?\d+(?:\.\d+)*\s*$/i', '', $name);

		// Remove trailing year patterns (4 digits at the end, e.g., "2026", "2025")
		// FIX: Use '' not '$1' to truly remove the year, not re-insert it
		$name = preg_replace('/[\s\-]?\d{4}$/', '', $name);

		// Remove common version suffixes like "x64", "x86" (but keep them if they're part of the name)
		$name = preg_replace('/[\s\-](x64|x86|amd64|arm64|aarch64)(?:\s|$)/i', ' ', $name);

		// Clean up multiple spaces/hyphens
		$name = preg_replace('/\s+/', ' ', $name);
		$name = preg_replace('/-+/', '-', $name);
		$name = trim($name, ' -');

return $name ?: $software_name;
    }
}
