/**
 * NM Template Manager
 * Centralized engine for 17 unique video rendering styles
 *
 * @package WP_News_MCQ_Generator
 * @version 8.7.0
 * @author MCP Developers
 */

(function (window) {
  "use strict";

  // ==========================================
  // Deterministic RNG for preview/export parity
  // ==========================================
  function mcqvs_u32(x) { return (x >>> 0); }

  function mcqvs_hash32(x) {
    x = mcqvs_u32(x);
    x ^= x >>> 16;
    x = Math.imul(x, 0x7feb352d);
    x ^= x >>> 15;
    x = Math.imul(x, 0x846ca68b);
    x ^= x >>> 16;
    return mcqvs_u32(x);
  }

  function mcqvs_hashStr(str) {
    let h = 2166136261;
    for (let i = 0; i < str.length; i++) {
      h = Math.imul(h ^ str.charCodeAt(i), 16777619);
    }
    return mcqvs_u32(h);
  }

  function mcqvs_seedFromState(state, salt) {
    let s = 0;
    if (state && state.seed != null) s = mcqvs_hashStr(String(state.seed));
    s ^= mcqvs_hashStr(String(salt || ''));
    return mcqvs_u32(s);
  }

  function mcqvs_rand01(state, salt, n) {
    const seed = mcqvs_seedFromState(state, salt) ^ mcqvs_hash32(n | 0);
    return mcqvs_hash32(seed) / 4294967296;
  }

  // ==========================================
  // HELPERS
  // ==========================================
  function mcqvs_normalizeLogoPosition(pos) {
    const p = String(pos || '').toLowerCase().trim();
    if (p === 'corner' || p === 'top-right' || p === 'top-left' || p === 'topleft' || p === 'topright') return 'corner';
    if (p === 'outro') return 'outro';
    if (p === 'intro' || p === 'intro_outro' || p === 'intro+outro') return 'intro_outro';
    if (p === 'all' || p === '') return 'all';
    return 'all';
  }

  function mcqvs_cornerAnchor(pos) {
    const p = String(pos || '').toLowerCase().trim();
    if (p === 'top-left' || p === 'topleft') return 'top-left';
    return 'top-right';
  }

  function wrapTextToLines(ctx, text, maxWidth) {
    const words = String(text || '').split(" ");
    const lines = [];
    let currentLine = words[0] || "";

    for (let i = 1; i < words.length; i++) {
      const word = words[i];
      const width = ctx.measureText(currentLine + " " + word).width;
      if (width < maxWidth) currentLine += " " + word;
      else { lines.push(currentLine); currentLine = word; }
    }
    lines.push(currentLine);
    return lines;
  }

  // Unified Text Fitting Logic
  function fitText(ctx, text, fontFace, maxWidth, maxHeight, initialFontSize = 80) {
    let fontSize = initialFontSize;
    const minFontSize = 20;

    const countLines = (c, t, w) => {
      const words = String(t || '').split(" ");
      let line = words[0] || "";
      let lines = 1;
      for (let i = 1; i < words.length; i++) {
        const width = c.measureText(line + " " + words[i]).width;
        if (width < w) line += " " + words[i];
        else { lines++; line = words[i]; }
      }
      return lines;
    };

    while (fontSize > minFontSize) {
      ctx.font = `bold ${fontSize}px ${fontFace}`;

      const widestWord = String(text || '').split(" ")
        .reduce((max, word) => Math.max(max, ctx.measureText(word).width), 0);

      if (widestWord > maxWidth) { fontSize -= 2; continue; }

      const lines = countLines(ctx, text, maxWidth);
      const totalHeight = lines * (fontSize * 1.5);

      if (totalHeight <= maxHeight) return fontSize;
      fontSize -= 2;
    }
    return minFontSize;
  }

  // ==========================================
  // BASE TEMPLATE CLASS
  // ==========================================
class VideoTemplate {
	constructor(id, config) {
		this.id = id;
		this.config = config || {};
	}

	// @NEW 2026-04-24: Format-aware layout resolver
	getLayout(cw, ch) {
		const isLandscape = cw > ch;
		const cx = cw / 2;
		const cy = ch / 2;

if (isLandscape) {
return {
isLandscape: true,
cx, cy,
CARD_X: Math.round(cw * 0.04),
CARD_TOP: Math.round(ch * 0.14),
CARD_WIDTH: Math.round(cw * 0.43),
TEXT_WIDTH: Math.round(cw * 0.37),
TEXT_MAX_HEIGHT: Math.round(ch * 0.50),
OPT_X: Math.round(cw * 0.53),
OPT_WIDTH: Math.round(cw * 0.43),
OPT_TEXT_WIDTH: Math.round(cw * 0.37),
TIMER_W: Math.round(cw * 0.07),
TIMER_H: Math.round(ch * 0.055),
TIMER_Y: Math.round(ch * 0.87),
TIMER_X: Math.round(cw * 0.89),
BAR_W: Math.round(cw * 0.78),
BAR_X: Math.round(cw * 0.04),
BAR_Y: Math.round(ch * 0.94),
BAR_Y_OFFSET: 0,
BRAND_Y: Math.round(ch * 0.04),
BRAND_LOGO_SIZE: Math.round(ch * 0.045),
LOGO_SIZE: Math.round(Math.min(cw, ch) * 0.05),
LOGO_PADDING: Math.round(Math.min(cw, ch) * 0.02),
COVER_LOGO_SIZE: Math.round(Math.min(cw, ch) * 0.12),
COVER_LOGO_Y: Math.round(ch * 0.22),
COVER_BRAND_Y: Math.round(ch * 0.40),
COVER_QUIZ_Y: Math.round(ch * 0.50),
HOOK_X: cx,
HOOK_Y: cy,
HOOK_MAX_WIDTH: Math.round(cw * 0.85),
HOOK_FONT_SIZE: Math.round(Math.min(cw, ch) * 0.055),
QUESTION_FONT_INITIAL: Math.round(Math.min(cw, ch) * 0.04),
OPTION_FONT: Math.round(Math.min(cw, ch) * 0.028),
OPTION_LINE_HEIGHT: Math.round(ch * 0.06),
OPTION_BOX_HEIGHT: Math.round(ch * 0.08),
OPTION_GAP: Math.round(ch * 0.018),
QUESTION_TOP_PADDING: Math.round(ch * 0.08),
QUESTION_BOTTOM_GAP: Math.round(ch * 0.04),
OUTRO_BRAND_Y: Math.round(ch * 0.30),
OUTRO_CTA_Y_OFFSET: Math.round(ch * 0.13),
OUTRO_RANK_Y_OFFSET: Math.round(ch * 0.24),
OUTRO_URL_Y_OFFSET: Math.round(ch * 0.33),
OUTRO_LOGO_Y: Math.round(ch * 0.22),
OUTRO_LOGO_MAX: Math.round(Math.min(cw, ch) * 0.15),
OUTRO_BRAND_FONT: Math.round(Math.min(cw, ch) * 0.065),
OUTRO_CTA_FONT: Math.round(Math.min(cw, ch) * 0.058),
OUTRO_RANK_FONT: Math.round(Math.min(cw, ch) * 0.03),
OUTRO_URL_FONT: Math.round(Math.min(cw, ch) * 0.022),
};
}

return {
isLandscape: false,
cx, cy,
CARD_X: Math.round(cw * 0.074),
CARD_TOP: Math.round(ch * 0.208),
CARD_WIDTH: Math.round(cw * 0.852),
TEXT_WIDTH: Math.round(cw * 0.778),
TEXT_MAX_HEIGHT: Math.round(ch * 0.234),
OPT_X: Math.round(cw * 0.111),
OPT_WIDTH: Math.round(cw * 0.778),
OPT_TEXT_WIDTH: Math.round(cw * 0.694),
TIMER_W: Math.round(cw * 0.389),
TIMER_H: Math.round(ch * 0.068),
TIMER_Y: Math.round(ch * 0.833),
TIMER_X: cx - Math.round(cw * 0.389) / 2,
BAR_W: Math.round(cw * 0.778),
BAR_X: Math.round(cw * 0.111),
BAR_Y_OFFSET: -45,
BRAND_Y: Math.round(ch * 0.052),
	BRAND_LOGO_SIZE: Math.round(cw * 0.111),
	LOGO_SIZE: Math.round(cw * 0.093),
	LOGO_PADDING: Math.round(cw * 0.037),
	COVER_LOGO_SIZE: Math.round(cw * 0.167),
	COVER_LOGO_Y: Math.round(ch * 0.25),
	COVER_BRAND_Y: Math.round(ch * 0.46),
	COVER_QUIZ_Y: Math.round(ch * 0.56),
	HOOK_X: cx,
	HOOK_Y: cy,
	HOOK_MAX_WIDTH: Math.round(cw * 0.833),
	HOOK_FONT_SIZE: Math.round(cw * 0.083),
	QUESTION_FONT_INITIAL: Math.round(cw * 0.069),
OPTION_FONT: Math.round(cw * 0.044),
OPTION_LINE_HEIGHT: 60,
OPTION_BOX_HEIGHT: 95,
OPTION_GAP: 20,
QUESTION_TOP_PADDING: 120,
QUESTION_BOTTOM_GAP: 50,
OUTRO_BRAND_Y: Math.round(ch * 0.38),
OUTRO_CTA_Y_OFFSET: Math.round(ch * 0.10),
OUTRO_RANK_Y_OFFSET: Math.round(ch * 0.17),
OUTRO_URL_Y_OFFSET: Math.round(ch * 0.23),
OUTRO_LOGO_Y: Math.round(ch * 0.24),
OUTRO_LOGO_MAX: Math.round(cw * 0.222),
OUTRO_BRAND_FONT: Math.round(cw * 0.11),
OUTRO_CTA_FONT: Math.round(cw * 0.10),
OUTRO_RANK_FONT: Math.round(cw * 0.05),
OUTRO_URL_FONT: Math.round(cw * 0.038),
};
}

    _scaleTextStyle(style, currentSize) {
      if (!style || typeof style !== 'object') return style;
      const baseSize = style.fontSize || 50;
      const scale = currentSize / baseSize;
      if (Math.abs(scale - 1) < 0.1) return style;

      const newStyle = JSON.parse(JSON.stringify(style));

      if (newStyle.stroke && typeof newStyle.stroke === 'object') {
        newStyle.stroke.width = Math.max(1, (newStyle.stroke.width || 0) * scale);
      }

      if (newStyle.shadow && typeof newStyle.shadow === 'object') {
        newStyle.shadow.blur *= scale;
        newStyle.shadow.offsetX *= scale;
        newStyle.shadow.offsetY *= scale;
      }

      if (newStyle.shadows && Array.isArray(newStyle.shadows)) {
        newStyle.shadows.forEach(s => {
          if (typeof s === 'object') {
            s.blur *= scale;
            s.offsetX *= scale;
            s.offsetY *= scale;
          }
        });
      }

      if (newStyle.glow && typeof newStyle.glow === 'object') {
        newStyle.glow.blur *= scale;
      }

      return newStyle;
    }

    render(ctx, state, assets) {
      state = state || {};
      const animationPhase = state.animationPhase;
      const _logoPosRaw = state.logoPosition;

      state.logoPosition = mcqvs_normalizeLogoPosition(_logoPosRaw);
      state._cornerAnchor = mcqvs_cornerAnchor(_logoPosRaw);

      if (state.brandName != null) state.brandName = String(state.brandName);
      if (state.quizName != null) state.quizName = String(state.quizName);

      const isReveal = (animationPhase === 'reveal');

      // 1) Background
      this.drawBackground(ctx, state);

      // 2) Branding (skip on outro and cover; outro/cover handle their own)
      if (state.currentSceneId !== 'outro' && state.currentSceneId !== 'cover') {
        this.renderComponent(ctx, "branding", state, assets);
      }

      // 3) Scene routing
      const currentScene = state.activeScene;

      if (currentScene && currentScene.type === "cover") {
        this.renderComponent(ctx, "cover", state, assets);
      } else if (currentScene && currentScene.type === "question") {
        this.renderComponent(ctx, "scene", state, assets, currentScene);
      } else if (currentScene && currentScene.type === "hook") {
        this.renderComponent(ctx, "hook", state, assets);
      } else if (state.currentSceneId === "outro" || (currentScene && currentScene.type === "outro")) {
        this.renderComponent(ctx, "outro", state, assets);
      } else {
        if (animationPhase === "hook") this.renderComponent(ctx, "hook", state, assets);
      }

      // 4) Corner logo (preview/export parity)
      // @FIX: Fall back to state.brandLogoImage when assets.logoImage is missing
      //       (server-renderer puts logo in state.brandLogoImage, not assets).
      //       Must check _isDrawable — Image objects from failed/empty downloads
      //       have width=0/height=0 and throw "Image given has not completed loading".
      const _isDrawable = (img) => !!(img && typeof img === 'object' && Number(img.width) > 0 && Number(img.height) > 0);
      const _cornerLogo = _isDrawable(assets && assets.logoImage) ? assets.logoImage
        : (_isDrawable(state && state.brandLogoImage) ? state.brandLogoImage : null);
      if (
        _cornerLogo &&
        state.currentSceneId !== 'outro' &&
        (state.logoPosition === 'corner' || state.logoPosition === 'all' || state.logoPosition === 'intro_outro')
      ) {
        this.drawCornerLogo(ctx, _cornerLogo, state._cornerAnchor || 'top-right');
      }

      // 5) Post FX
      this.applyPostProcessing(ctx, state);

      // Keep lint happy for unused local (isReveal used in drawQuestion path)
      void isReveal;
    }

    renderComponent(ctx, component, state, assets, scene = null) {
      switch (component) {
        case "cover": {
          this.drawCover(ctx, state, assets);
          break;
        }
        case "branding": {
          const lp = mcqvs_normalizeLogoPosition(state.logoPosition);
          // @FIX: For intro_outro, only show center logo on hook (intro) scene — outro draws its own logo
          const showCenterLogo = (lp === 'all') || (lp === 'intro_outro' && state.currentSceneId === 'hook');
          // @FIX: Fall back to state.brandLogoImage when assets.logoImage is missing
          //       Must check _isDrawable to avoid "Image given has not completed loading"
          const _isDrawableBr = (img) => !!(img && typeof img === 'object' && Number(img.width) > 0 && Number(img.height) > 0);
          const _brandLogo = _isDrawableBr(assets && assets.logoImage) ? assets.logoImage
            : (_isDrawableBr(state && state.brandLogoImage) ? state.brandLogoImage : null);
          this.drawBranding(
            ctx,
            state.brandName || "Quiz Master",
            state.quizName || "",
            showCenterLogo ? _brandLogo : null,
            state
          );
          break;
        }
        case "hook":
          this.drawHook(ctx, state.hookText, state.elapsed, state);
          break;

        case "scene":
          if (!scene) break;
          if (scene.type === "question") {
            this.drawQuestion(
              ctx,
              scene.content,
              state.animationPhase === "reveal",
              state.elapsed,
              state
            );
          } else if (scene.type === "story") {
            this.drawStory(ctx, scene.content, state.elapsed, state);
          } else if (scene.type === "hook") {
            const text = (scene.content && scene.content.hookText) || state.hookText;
            this.drawHook(ctx, text, state.elapsed, state);
          } else if (scene.type === "outro") {
            const outroState = Object.assign({}, state, scene.content || {});
            this.drawOutro(ctx, outroState, assets);
          }
          break;

        case "outro":
          this.drawOutro(ctx, state, assets);
          break;
      }
    }

drawStory(ctx, content, elapsed, state) {
const cw = (ctx.canvas && ctx.canvas.width) || 1080;
const ch = (ctx.canvas && ctx.canvas.height) || 1920;
const L = this.getLayout(cw, ch);
const colors = (state && state.templateColors) || this.config.colors || {};
const font = (state && state.fontOverride) || (state && state.templateFonts && state.templateFonts.primary) || (this.config.fonts && this.config.fonts.primary) || "Inter";
ctx.fillStyle = colors.text || "#ffffff";
ctx.font = `bold ${L.HOOK_FONT_SIZE}px ${font}, Inter, sans-serif`;
ctx.textAlign = "center";
ctx.textBaseline = "middle";
this.wrapText(ctx, (content && content.text) || "", L.cx, L.cy, Math.round(cw * 0.8), Math.round(L.HOOK_FONT_SIZE * 1.4));
void elapsed;
}

    // ✅ CLEAN SINGLE IMPLEMENTATION (no duplicates)
  drawBackground(ctx, state) {
    const elapsed = Number(state && state.elapsed) || 0;
    const cw = (ctx.canvas && ctx.canvas.width) || 1080;
    const ch = (ctx.canvas && ctx.canvas.height) || 1920;
    // @PATCH 2026-02-06: Persist BG video element across frames (prevents leaked videos + enables pause/stop)
    const host = (state && state.__bgHost && typeof state.__bgHost === 'object') ? state.__bgHost : state;

      const resolveUrl = (src) => {
        const s = String(src || '').trim();
        if (!s) return '';
        if (/^(https?:)?\/\//i.test(s) || s.startsWith('data:') || s.startsWith('blob:')) return s;
        if (s.startsWith('/')) return (window.location.origin || '') + s;

        const base = (window.MCQVSConfig && window.MCQVSConfig.assetsUrl)
          ? String(window.MCQVSConfig.assetsUrl)
          : '';

        if (base) return base.replace(/\/+$/, '') + '/' + s.replace(/^\/+/, '');
        return s;
      };

      const looksLikeVideoFile = (s) => /\.(mp4|webm|m4v|mov)(\?|#|$)/i.test(String(s || ''));

      const pickVideoSrc = (bg) => {
        if (!bg) return '';
        if (typeof bg === 'string') return looksLikeVideoFile(bg) ? bg : '';
        if (typeof bg === 'object') {
          if (bg.video && typeof bg.video === 'object') {
            return (bg.video.url || bg.video.src || bg.video.mp4 || bg.video.webm || '');
          }
          if (Array.isArray(bg.videos) && bg.videos.length) {
            const v0 = bg.videos[0];
            if (typeof v0 === 'string') return v0;
            if (v0 && typeof v0 === 'object') return (v0.url || v0.src || v0.mp4 || v0.webm || '');
          }
          return (bg.videoUrl || bg.videoSrc || bg.mp4 || bg.webm || bg.video || bg.src || bg.url || '');
        }
        return '';
      };

      // 1) Worker frames
      if (state.bgVideoFrames && state.bgVideoFrames.length > 0) {
        // @MODIFIED 2026-02-08: Use correct frame duration (default to 33.33ms if missing)
        const frameDur = Number(state.bgVideoFrameDur) || 33.33;
        const frameIdx = Math.floor(elapsed / frameDur) % state.bgVideoFrames.length;
        const frame = state.bgVideoFrames[frameIdx];
        if (frame) {
      ctx.drawImage(frame, 0, 0, cw, ch);
      ctx.fillStyle = "rgba(0,0,0,0.6)";
      ctx.fillRect(0, 0, cw, ch);
          return;
        }
      }

      // 2) Preview video element
      try {
        const bgCfg = this.config.background || null;
        const templateVideo = pickVideoSrc(bgCfg);

        const desiredVideoSrc = resolveUrl(
          state.bgVideoData ||
          state.bgVideoUrl ||
          templateVideo
        );

        const canInitVideo =
          !!desiredVideoSrc &&
          typeof document !== 'undefined' &&
          typeof HTMLVideoElement !== 'undefined';

        if (canInitVideo) {
          const cur = host.bgVideo;
          const curSrc = host._bgVideoSrc || '';


          if (!(cur instanceof HTMLVideoElement) || curSrc !== desiredVideoSrc) {
            if (cur instanceof HTMLVideoElement) {
              try { cur.pause(); } catch (_) { }
              try { cur.removeAttribute('src'); cur.load(); } catch (_) { }
              try { if (window.__MCQVS_BG_VIDEOS && window.__MCQVS_BG_VIDEOS.delete) window.__MCQVS_BG_VIDEOS.delete(cur); } catch (_) { }
            }
            const v = document.createElement('video');
            try { window.__MCQVS_BG_VIDEOS = window.__MCQVS_BG_VIDEOS || new Set(); window.__MCQVS_BG_VIDEOS.add(v); } catch (_) { }
            v.muted = true;

            v.loop = true;
            v.autoplay = true;
            v.playsInline = true;
            v.preload = 'auto';

            try {
              const u = new URL(desiredVideoSrc, window.location.href);
              if (u.origin !== window.location.origin) v.crossOrigin = 'anonymous';
            } catch (_) { }

            host._bgVideoReady = false;
            v.addEventListener('loadeddata', () => { host._bgVideoReady = true; }, { once: true });
            v.addEventListener('error', () => {
              host._bgVideoReady = false;

              console.warn('[MCQVS] BG video error:', desiredVideoSrc, v.error);
            });

            v.src = desiredVideoSrc;
            v.load();

            const p = v.play();
            if (p && typeof p.catch === 'function') p.catch(() => { });

            host.bgVideo = v;
            host._bgVideoSrc = desiredVideoSrc;
            host.bgVideoData = desiredVideoSrc;

          }

          if (host.bgVideo && host.bgVideo instanceof HTMLVideoElement) {
            if (host._bgVideoReady === true || host.bgVideo.readyState >= 2) {
              try {
        ctx.drawImage(host.bgVideo, 0, 0, cw, ch);

        ctx.fillStyle = "rgba(0,0,0,0.6)";
        ctx.fillRect(0, 0, cw, ch);
                return;
              } catch (e) { /* fall through */ }
            }
          }
        }
      } catch (e) { /* never hard-fail */ }

      // 3) Image background
      if (state.bgImage) {
    ctx.drawImage(state.bgImage, 0, 0, cw, ch);
    ctx.fillStyle = "rgba(0,0,0,0.6)";
    ctx.fillRect(0, 0, cw, ch);
        return;
      }

      // 4) Template fallback (gradient/solid)
      const bgConfig = this.config.background || {};
      const colors = bgConfig.colors || ["#000", "#333"];

      // @FIX 2026-08-11 (PERF): static-background cache. For templates whose background is
      //       NOT animated and there is no bg video/image, the background is pixel-identical
      //       every frame — but we were re-running the gradient/solid draw (and constructing
      //       a new gradient object) per frame at 24-30fps across the whole render loop.
      //       Now we draw it ONCE to an offscreen canvas (keyed by template+size+colors) and
      //       blit it with a single drawImage per frame. Animated gradients, bg videos and
      //       bg images are NEVER cached (they change per frame). The cache lives on the
      //       template instance so it persists across frames AND across jobs in one process.
      const _isStaticBg = !bgConfig.animated &&
        !(state.bgVideoFrames && state.bgVideoFrames.length) &&
        !state.bgImage;
      if (_isStaticBg) {
        const _cacheKey = String(this.id || '') + '|' + cw + 'x' + ch + '|' + colors.join(',');
        let _cached = this._bgCache && this._bgCache.key === _cacheKey ? this._bgCache.canvas : null;
        if (!_cached) {
          try {
            let _c;
            if (typeof OffscreenCanvas !== 'undefined') {
              _c = new OffscreenCanvas(cw, ch);
            } else if (typeof document !== 'undefined' && typeof document.createElement === 'function') {
              _c = document.createElement('canvas');
              _c.width = cw; _c.height = ch;
            }
            if (_c) {
              const _cctx = _c.getContext('2d');
              if (bgConfig.type === "gradient") {
                const g2 = _cctx.createLinearGradient(0, 0, 0, ch);
                colors.forEach((cc, i) => g2.addColorStop(i / (colors.length - 1), cc));
                _cctx.fillStyle = g2;
                _cctx.fillRect(0, 0, cw, ch);
              } else {
                _cctx.fillStyle = colors[0];
                _cctx.fillRect(0, 0, cw, ch);
              }
              this._bgCache = { key: _cacheKey, canvas: _c };
              _cached = _c;
            }
          } catch (_e) { _cached = null; }
        }
        if (_cached) {
          try { ctx.drawImage(_cached, 0, 0, cw, ch); } catch (_e) { /* fall through */ }
          return;
        }
      }

      if (window.MCQVS_AnimationEngine && bgConfig.type === "gradient" && bgConfig.animated) {
      window.MCQVS_AnimationEngine.backgrounds.meshGradient(ctx, cw, ch, colors, elapsed);
    } else if (bgConfig.type === "gradient") {
      const grad = ctx.createLinearGradient(0, 0, 0, ch);
      colors.forEach((c, i) => grad.addColorStop(i / (colors.length - 1), c));
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, cw, ch);
    } else {
      ctx.fillStyle = colors[0];
      ctx.fillRect(0, 0, cw, ch);
      }
    }

	drawCornerLogo(ctx, logoImage, anchor = 'top-right') {
		if (!logoImage) return;

		const cw = (ctx.canvas && ctx.canvas.width) || 1080;
		const ch = (ctx.canvas && ctx.canvas.height) || 1920;
		const L = this.getLayout(cw, ch);
		const size = L.LOGO_SIZE;
		const padding = L.LOGO_PADDING;
		const x = (anchor === 'top-left') ? padding : (cw - size - padding);
		const y = padding;

		ctx.save();
		ctx.globalAlpha = 0.8;
		ctx.shadowColor = "rgba(0,0,0,0.5)";
		ctx.shadowBlur = 10;
		try { ctx.drawImage(logoImage, x, y, size, size); } catch (e) { }
		ctx.restore();
	}

	// @MODIFIED 2026-02-07: Added state parameter to fix ReferenceError
	// @MODIFIED 2026-04-24: Layout-aware positioning
	drawBranding(ctx, name, quizName, logo, state = {}) {
		const cw = (ctx.canvas && ctx.canvas.width) || 1080;
		const ch = (ctx.canvas && ctx.canvas.height) || 1920;
		const L = this.getLayout(cw, ch);
		const colors = state.templateColors || this.config.colors || {};
		const brandFont = (state.fontOverride || (state.templateFonts && state.templateFonts.primary) || (this.config.fonts && this.config.fonts.primary) || "Inter");
		const quizFont = ((state.fontOverride) || (state.templateFonts && state.templateFonts.secondary) || (this.config.fonts && this.config.fonts.secondary) || "Inter");

		if (L.isLandscape) {
			const barY = L.BRAND_Y;
			const barH = Math.round(ch * 0.055);
			const padX = Math.round(cw * 0.04);

			const _isDrawableBr = (img) => !!(img && typeof img === 'object' && Number(img.width) > 0 && Number(img.height) > 0);
			const _brandLogo = _isDrawableBr(logo) ? logo : (_isDrawableBr(state && state.brandLogoImage) ? state.brandLogoImage : null);

			let brandFontSize = Math.round(ch * 0.038);
			const maxBrandWidth = cw * 0.35;
			ctx.font = `bold ${brandFontSize}px ${brandFont}, Inter, sans-serif`;
			let measured = ctx.measureText(name || "").width;
			while (measured > maxBrandWidth && brandFontSize > 14) {
				brandFontSize -= 1;
				ctx.font = `bold ${brandFontSize}px ${brandFont}, Inter, sans-serif`;
				measured = ctx.measureText(name || "").width;
			}

			const logoSize = _brandLogo ? Math.round(barH * 0.7) : 0;
			const brandX = padX + (logoSize ? logoSize + Math.round(cw * 0.01) : 0);
			const brandY = barY + barH / 2;

			if (_brandLogo) {
				try {
					ctx.drawImage(_brandLogo, padX, brandY - logoSize / 2, logoSize, logoSize);
				} catch (e) { }
			}

			ctx.fillStyle = colors.accent || "#00f0ff";
			ctx.font = `bold ${brandFontSize}px ${brandFont}, Inter, sans-serif`;
			ctx.textAlign = "left";
			ctx.textBaseline = "middle";
			ctx.shadowBlur = 8;
			ctx.shadowColor = "rgba(0,0,0,0.7)";
			ctx.fillText(name || "", brandX, brandY);

			if (quizName) {
				// @FIX 1.4.9.58: wrap the topic name to up to 2 lines and use a larger
				// base font — previously it was forced to ONE tiny line (27px base,
				// shrinking until it fit), which was barely readable for long topics
				// even though the header had room below.
				let quizFontSize = Math.round(ch * 0.036);
				const maxQuizWidth = cw * 0.36;
				ctx.font = `bold ${quizFontSize}px ${quizFont}, Inter, sans-serif`;
				let quizLines = wrapTextToLines(ctx, String(quizName), maxQuizWidth);
				// Keep at most 2 lines; shrink until 2 lines fit comfortably.
				while (quizLines.length > 2 && quizFontSize > 12) {
					quizFontSize -= 1;
					ctx.font = `bold ${quizFontSize}px ${quizFont}, Inter, sans-serif`;
					quizLines = wrapTextToLines(ctx, String(quizName), maxQuizWidth);
				}
				const qLineH = Math.round(quizFontSize * 1.22);
				const padding = Math.round(quizFontSize * 0.6);
				let boxW = maxQuizWidth + padding * 2;
				for (const ln of quizLines) {
					boxW = Math.max(boxW, Math.min(maxQuizWidth + padding * 2, ctx.measureText(ln).width + padding * 3));
				}
				const boxH = quizLines.length * qLineH + padding;
				// @FIX 2026-08-11 (Option-3 landscape): quiz name badge was top-RIGHT —
				//       the new layout reserves top-right for the "Q n/total" counter pill,
				//       so the topic is now CENTERED between branding (left) and the pill.
				const badgeX = Math.round(L.cx - boxW / 2);
				const badgeY = barY + (barH - boxH) / 2;

				ctx.shadowBlur = 10;
				ctx.shadowColor = "rgba(0,0,0,0.5)";

				const badgeGrad = ctx.createLinearGradient(badgeX, badgeY, badgeX + boxW, badgeY + boxH);
				badgeGrad.addColorStop(0, "rgba(40, 40, 60, 0.95)");
				badgeGrad.addColorStop(1, "rgba(20, 20, 30, 0.95)");

				ctx.fillStyle = badgeGrad;
				ctx.strokeStyle = "#FFD700";
				ctx.lineWidth = 1.5;
				this.drawRoundedRect(ctx, badgeX, badgeY, boxW, boxH, Math.round(boxH * 0.35));
				ctx.fill();
				ctx.stroke();

				ctx.shadowBlur = 0;
				ctx.fillStyle = "#FFD700";
				ctx.font = `bold ${quizFontSize}px ${quizFont}, Inter, sans-serif`;
				ctx.textAlign = "center";
				ctx.textBaseline = "middle";
				const quizTop = badgeY + (boxH - (quizLines.length * qLineH)) / 2 + qLineH / 2;
				quizLines.forEach((ln, li) => ctx.fillText(ln, badgeX + boxW / 2, quizTop + li * qLineH + 1));
			}

			ctx.shadowBlur = 0;
			return;
		}

		let brandFontSize = Math.round(cw * 0.042);

		const maxBrandWidth = cw * 0.9;
		ctx.font = `bold ${brandFontSize}px ${brandFont}, Inter, sans-serif`;
		let measured2 = ctx.measureText(name || "").width;
		while (measured2 > maxBrandWidth && brandFontSize > 16) {
			brandFontSize -= 2;
			ctx.font = `bold ${brandFontSize}px ${brandFont}, Inter, sans-serif`;
			measured2 = ctx.measureText(name || "").width;
		}

		if (logo) {
			const size = L.BRAND_LOGO_SIZE;
			ctx.drawImage(logo, L.cx - size / 2, L.BRAND_Y, size, size);
		}

		ctx.fillStyle = colors.accent || "#00f0ff";
		ctx.font = `bold ${brandFontSize}px ${brandFont}, Inter, sans-serif`;
		ctx.textAlign = "center";
		ctx.shadowBlur = 15;
		ctx.shadowColor = "rgba(0,0,0,0.9)";
		const nameY = logo ? L.BRAND_Y + L.BRAND_LOGO_SIZE + Math.round(L.BRAND_LOGO_SIZE * 0.6) : L.BRAND_Y + Math.round(L.BRAND_LOGO_SIZE * 0.4);
		ctx.fillText(name, L.cx, nameY);

		if (quizName) {
			ctx.save();

			// @FIX 1.4.9.58: wrap the topic name to up to 2 lines and use a larger
			// base font (previously a single shrinking line — tiny for long topics).
			const maxQuizWidth = cw * 0.86;
			const padding = 20;
			const startY = logo ? nameY + Math.round(L.BRAND_LOGO_SIZE * 0.18) : nameY + Math.round(L.BRAND_LOGO_SIZE * 0.25);
			const badgeY = startY;

			// @FIX 2026-08-13 (SHORTS TOPIC CLIP): the 2-line topic badge was sized
			//       purely off its own content, so when the topic wrapped to 2 lines —
			//       or a header logo pushed the badge down — its bottom edge fell below
			//       the question card top (L.CARD_TOP). Because branding is drawn BEFORE
			//       the question card, the card then covered the badge: the topic was
			//       "out of its box" and rendered BEHIND the Q card. Cap the badge's
			//       available height to the space above the card and shrink the font
			//       (down to a readable floor) so the topic always stays fully visible.
			const topicCapBottom = L.CARD_TOP - Math.round(ch * 0.012);
			// True available height: from the badge's start up to the cap above the
			// card. When a header logo pushes the badge down, this shrinks to fit — the
			// badge then drops to fewer/smaller lines rather than overlapping the card.
			const topicMaxH = Math.max(1, topicCapBottom - badgeY);

			let fontSize = Math.round(L.BRAND_LOGO_SIZE * 0.58);
			ctx.font = `bold ${fontSize}px ${quizFont}`;
			let quizLines2 = wrapTextToLines(ctx, String(quizName), maxQuizWidth);
			// Shrink while the badge would either exceed 2 lines OR overflow the space
			// above the question card. Keeps 2-line topics when there is room (no
			// regression for the common case) and prevents any overlap with the card.
			while (fontSize > 14) {
				const qLineH2check = Math.round(fontSize * 1.24);
				const boxHcheck = quizLines2.length * qLineH2check + padding;
				if (quizLines2.length <= 2 && boxHcheck <= topicMaxH) break;
				fontSize -= 1;
				ctx.font = `bold ${fontSize}px ${quizFont}`;
				quizLines2 = wrapTextToLines(ctx, String(quizName), maxQuizWidth);
			}

			ctx.font = `bold ${fontSize}px ${quizFont}`;
			const qLineH2 = Math.round(fontSize * 1.24);
			let boxWidth = maxQuizWidth + padding * 2;
			for (const ln of quizLines2) {
				boxWidth = Math.max(boxWidth, Math.min(maxQuizWidth + padding * 2, ctx.measureText(ln).width + padding * 3));
			}
			const boxHeight = quizLines2.length * qLineH2 + padding;
			const badgeX = L.cx - (boxWidth / 2);

			ctx.shadowBlur = 15;
			ctx.shadowColor = "rgba(0,0,0,0.5)";

			const badgeGrad2 = ctx.createLinearGradient(badgeX, badgeY, badgeX + boxWidth, badgeY + boxHeight);
			badgeGrad2.addColorStop(0, "rgba(40, 40, 60, 0.95)");
			badgeGrad2.addColorStop(1, "rgba(20, 20, 30, 0.95)");

			ctx.fillStyle = badgeGrad2;
			ctx.strokeStyle = "#FFD700";
			ctx.lineWidth = 2;

			this.drawRoundedRect(ctx, badgeX, badgeY, boxWidth, boxHeight, 15);
			ctx.fill();
			ctx.stroke();

			ctx.shadowBlur = 0;
			ctx.fillStyle = "#FFD700";
			ctx.textAlign = "center";
			ctx.textBaseline = "middle";
			const qTop = badgeY + (boxHeight - (quizLines2.length * qLineH2)) / 2 + qLineH2 / 2;
			quizLines2.forEach((ln, li) => ctx.fillText(ln, L.cx, qTop + li * qLineH2 + 2));

			ctx.restore();
		}

		ctx.shadowBlur = 0;
	}

	drawCover(ctx, state = {}, assets = {}) {
		const cw = (ctx.canvas && ctx.canvas.width) || 1080;
		const ch = (ctx.canvas && ctx.canvas.height) || 1920;
		const L = this.getLayout(cw, ch);
		const colors = state.templateColors || this.config.colors || {};
		const brandFont = state.fontOverride || (state.templateFonts && state.templateFonts.primary) || (this.config.fonts && this.config.fonts.primary) || "Inter";
		const quizFont = (state.fontOverride) || (state.templateFonts && state.templateFonts.secondary) || (this.config.fonts && this.config.fonts.secondary) || "Inter";

		const cc = state.coverConfig || {};
		const showLogo = cc.show_logo !== false;
		const brandSize = cc.brand_size || 'large';
		const badgeStyle = cc.badge_style || 'gold';
		const bgColor = cc.bg_color || '';

		const _isDrawable = (img) => !!(img && typeof img === 'object' && Number(img.width) > 0 && Number(img.height) > 0);

		ctx.save();

		if (bgColor) {
			const grad = ctx.createLinearGradient(0, 0, cw, ch);
			grad.addColorStop(0, bgColor);
			grad.addColorStop(1, bgColor);
			ctx.fillStyle = grad;
			ctx.fillRect(0, 0, cw, ch);
		}

		const scale = brandSize === 'large' ? 1.0 : brandSize === 'medium' ? 0.75 : 0.55;

		const logo = (showLogo && _isDrawable(state && state.brandLogoImage)) ? state.brandLogoImage
			: (showLogo && _isDrawable(assets && assets.logoImage) ? assets.logoImage : null);

		const brandName = state.brandName || "Quiz Master";
		const quizName = state.quizName || "";

		// @NEW 2026-08-11: Hook-first cover. If a visible hook text exists, frame-0 shows the
		//       HOOK as the hero (curiosity scroll-stopper) with a small brand footer — NOT the
		//       quiz name. This is the frame IG/FB/TikTok capture as the poster and what YT
		//       samples as a thumbnail candidate, so it must stop the scroll, not announce a topic.
		//       Falls through to the classic logo+brand+quizName layout when there is no hook
		//       (e.g. hook hidden or long-form without a hook) — zero regression for those paths.
		const hookRaw = String(state.hookText || '').trim();
		const hookVisible = state.hookVisible !== false;
		if (hookRaw && hookVisible) {
			const heroFontSize = Math.round(cw * 0.085);
			const minHeroFont = Math.round(cw * 0.058);
			const maxHookWidth = cw * 0.84;
			const wrappedHook = this._wrapQuizText(ctx, hookRaw, maxHookWidth, brandFont, heroFontSize, minHeroFont);
			const hookLines = (wrappedHook && wrappedHook.lines && wrappedHook.lines.length) ? wrappedHook.lines : [hookRaw];
			const hookFontSize = (wrappedHook && wrappedHook.fontSize) ? wrappedHook.fontSize : heroFontSize;
			const hookLineH = Math.round(hookFontSize * 1.22);
			const blockH = hookLines.length * hookLineH;

			// Logo (small, top-center) if enabled
			if (logo) {
				const lSize = Math.round(cw * 0.085);
				ctx.shadowBlur = 16;
				ctx.shadowColor = "rgba(0,0,0,0.45)";
				try { ctx.drawImage(logo, L.cx - lSize / 2, Math.round(ch * 0.07), lSize, lSize); } catch (e) { }
			}

			// Semi-transparent band behind the hook for legibility on any background
			const bandW = Math.min(cw * 0.9, (wrappedHook && wrappedHook.maxLineWidth ? wrappedHook.maxLineWidth : maxHookWidth) + Math.round(cw * 0.09));
			const bandH = blockH + Math.round(hookLineH * 0.9);
			const bandX = L.cx - bandW / 2;
			const bandY = Math.round(ch * 0.40) - Math.round(bandH / 2);
			const bandGrad = ctx.createLinearGradient(bandX, bandY, bandX, bandY + bandH);
			bandGrad.addColorStop(0, "rgba(12,12,22,0.80)");
			bandGrad.addColorStop(1, "rgba(12,12,22,0.58)");
			ctx.fillStyle = bandGrad;
			this.drawRoundedRect(ctx, bandX, bandY, bandW, bandH, Math.round(Math.min(bandW, bandH) * 0.16));
			ctx.fill();
			ctx.strokeStyle = (colors && colors.accent) ? colors.accent : "#FFD700";
			ctx.lineWidth = 2;
			ctx.globalAlpha = 0.9;
			this.drawRoundedRect(ctx, bandX, bandY, bandW, bandH, Math.round(Math.min(bandW, bandH) * 0.16));
			ctx.stroke();
			ctx.globalAlpha = 1;

			// Hook text — white, bold, centered
			ctx.shadowBlur = 18;
			ctx.shadowColor = "rgba(0,0,0,0.85)";
			ctx.fillStyle = "#FFFFFF";
			ctx.font = `bold ${hookFontSize}px ${brandFont}, Inter, sans-serif`;
			ctx.textAlign = "center";
			ctx.textBaseline = "middle";
			const textTop = bandY + Math.round((bandH - blockH) / 2) + Math.round(hookLineH / 2);
			hookLines.forEach((ln, i) => {
				ctx.fillText(ln, L.cx, textTop + i * hookLineH);
			});

			// Brand footer (small, accent)
			const brandFootSize = Math.round(cw * 0.038);
			ctx.shadowBlur = 10;
			ctx.shadowColor = "rgba(0,0,0,0.7)";
			ctx.fillStyle = (colors && colors.accent) ? colors.accent : "#00f0ff";
			ctx.font = `bold ${brandFootSize}px ${brandFont}, Inter, sans-serif`;
			ctx.fillText(brandName, L.cx, Math.round(ch * 0.9));

			ctx.restore();
			return;
		}

		if (L.isLandscape) {
			const logoSize = logo ? Math.round(ch * 0.18 * scale) : 0;
			const logoY = Math.round(ch * 0.22);

			if (logo) {
				ctx.shadowBlur = 20;
				ctx.shadowColor = "rgba(0,0,0,0.5)";
				try { ctx.drawImage(logo, L.cx - logoSize / 2, logoY, logoSize, logoSize); } catch (e) { }
			}

			let brandFontSize = Math.round(ch * 0.07 * scale);
			const maxBrandWidth = cw * 0.6;
			ctx.font = `bold ${brandFontSize}px ${brandFont}, Inter, sans-serif`;
			let measured = ctx.measureText(brandName).width;
			while (measured > maxBrandWidth && brandFontSize > 20) {
				brandFontSize -= 2;
				ctx.font = `bold ${brandFontSize}px ${brandFont}, Inter, sans-serif`;
				measured = ctx.measureText(brandName).width;
			}

			const brandY = logo ? logoY + logoSize + Math.round(ch * 0.04) : Math.round(ch * 0.35);
			ctx.shadowBlur = 15;
			ctx.shadowColor = "rgba(0,0,0,0.7)";
			ctx.fillStyle = (colors && colors.accent) ? colors.accent : "#00f0ff";
			ctx.textAlign = "center";
			ctx.textBaseline = "middle";
			ctx.fillText(brandName, L.cx, brandY);

			if (quizName) {
				const maxQuizWidth = cw * 0.55;
				const padding = Math.round(ch * 0.012);
				const lineGap = Math.round(ch * 0.004);
				const quizMinFontSize = Math.round(brandFontSize * 0.45);

				const wrapped = this._wrapQuizText(ctx, quizName, maxQuizWidth - padding * 2, quizFont, brandFontSize * 0.8, quizMinFontSize);
				const lines = wrapped.lines;
				const quizFontSize = wrapped.fontSize;

				const textWidth = wrapped.maxLineWidth;
				const boxWidth = Math.min(maxQuizWidth, textWidth + padding * 3);
				const lineHeight = quizFontSize + lineGap;
				const boxHeight = (lines.length * lineHeight) - lineGap + padding;
				const badgeY = brandY + Math.round(ch * 0.06);
				const badgeX = L.cx - boxWidth / 2;

				ctx.shadowBlur = 20;
				ctx.shadowColor = "rgba(0,0,0,0.5)";

				let badgeBorder = "#FFD700";
				let badgeBg1 = "rgba(40, 40, 60, 0.95)";
				let badgeBg2 = "rgba(20, 20, 30, 0.95)";
				let badgeText = "#FFD700";
				if (badgeStyle === 'accent' && colors.accent) {
					badgeBorder = colors.accent;
					badgeText = colors.accent;
				} else if (badgeStyle === 'minimal') {
					badgeBorder = 'rgba(255,255,255,0.2)';
					badgeBg1 = 'rgba(255,255,255,0.08)';
					badgeBg2 = 'rgba(255,255,255,0.04)';
					badgeText = '#FFFFFF';
				}

				const badgeGrad = ctx.createLinearGradient(badgeX, badgeY, badgeX + boxWidth, badgeY + boxHeight);
				badgeGrad.addColorStop(0, badgeBg1);
				badgeGrad.addColorStop(1, badgeBg2);

				ctx.fillStyle = badgeGrad;
				ctx.strokeStyle = badgeBorder;
				ctx.lineWidth = badgeStyle === 'minimal' ? 1 : 2;

				const radius = Math.round(Math.min(boxWidth, boxHeight) * 0.25);
				this.drawRoundedRect(ctx, badgeX, badgeY, boxWidth, boxHeight, radius);
				ctx.fill();
				ctx.stroke();

				ctx.shadowBlur = 0;
				ctx.fillStyle = badgeText;
				ctx.font = `bold ${quizFontSize}px ${quizFont}`;
				ctx.textAlign = "center";
				ctx.textBaseline = "middle";
				const startY = badgeY + padding / 2 + quizFontSize / 2;
				lines.forEach((ln, i) => {
					ctx.fillText(ln, L.cx, startY + i * lineHeight);
				});
			}

			ctx.restore();
			return;
		}

		if (logo) {
			const size = Math.round(56 * scale * (cw / 270));
			const y = Math.round(ch * 0.28);
			ctx.shadowBlur = 16;
			ctx.shadowColor = "rgba(0,0,0,0.4)";
			ctx.drawImage(logo, L.cx - size / 2, y, size, size);
		}

		let brandFontSize = Math.round(22 * scale * (cw / 270));
		const maxBrandWidth = cw * 0.85;
		ctx.font = `bold ${brandFontSize}px ${brandFont}, Inter, sans-serif`;
		let measured2 = ctx.measureText(brandName).width;
		while (measured2 > maxBrandWidth && brandFontSize > 18) {
			brandFontSize -= 2;
			ctx.font = `bold ${brandFontSize}px ${brandFont}, Inter, sans-serif`;
			measured2 = ctx.measureText(brandName).width;
		}
		ctx.shadowBlur = 12;
		ctx.shadowColor = "rgba(0,0,0,0.6)";
		ctx.fillStyle = (colors && colors.accent) ? colors.accent : "#00f0ff";
		ctx.textAlign = "center";
		ctx.textBaseline = "middle";
		const brandY2 = logo ? Math.round(ch * 0.42) : Math.round(ch * 0.36);
		ctx.fillText(brandName, L.cx, brandY2);

		if (quizName) {
			const maxQuizWidth = cw * 0.8;
			const padding = 14 * (cw / 270);
			const lineGap = 4 * (cw / 270);
			const quizMinFontSize = Math.round(brandFontSize * 0.5);

			const wrapped2 = this._wrapQuizText(ctx, quizName, maxQuizWidth - padding * 2, quizFont, brandFontSize, quizMinFontSize);
			const lines2 = wrapped2.lines;
			const quizFontSize2 = wrapped2.fontSize;

			const textWidth2 = wrapped2.maxLineWidth;
			const boxWidth2 = Math.min(maxQuizWidth, textWidth2 + padding * 3);
			const lineHeight2 = quizFontSize2 + lineGap;
			const boxHeight2 = (lines2.length * lineHeight2) - lineGap + padding;
			const badgeY2 = logo ? Math.round(ch * 0.54) : Math.round(ch * 0.48);
			const badgeX2 = L.cx - boxWidth2 / 2;

			ctx.shadowBlur = 20;
			ctx.shadowColor = "rgba(0,0,0,0.5)";

			let badgeBorder2 = "#FFD700";
			let badgeBg1_2 = "rgba(40, 40, 60, 0.95)";
			let badgeBg2_2 = "rgba(20, 20, 30, 0.95)";
			let badgeText2 = "#FFD700";
			if (badgeStyle === 'accent' && colors.accent) {
				badgeBorder2 = colors.accent;
				badgeText2 = colors.accent;
			} else if (badgeStyle === 'minimal') {
				badgeBorder2 = 'rgba(255,255,255,0.2)';
				badgeBg1_2 = 'rgba(255,255,255,0.08)';
				badgeBg2_2 = 'rgba(255,255,255,0.04)';
				badgeText2 = '#FFFFFF';
			}

			const badgeGrad2 = ctx.createLinearGradient(badgeX2, badgeY2, badgeX2 + boxWidth2, badgeY2 + boxHeight2);
			badgeGrad2.addColorStop(0, badgeBg1_2);
			badgeGrad2.addColorStop(1, badgeBg2_2);

			ctx.fillStyle = badgeGrad2;
			ctx.strokeStyle = badgeBorder2;
			ctx.lineWidth = badgeStyle === 'minimal' ? 1 : 2;

			const radius2 = Math.round(Math.min(boxWidth2, boxHeight2) * 0.25);
			this.drawRoundedRect(ctx, badgeX2, badgeY2, boxWidth2, boxHeight2, radius2);
			ctx.fill();
			ctx.stroke();

			ctx.shadowBlur = 0;
			ctx.fillStyle = badgeText2;
			ctx.font = `bold ${quizFontSize2}px ${quizFont}`;
			ctx.textAlign = "center";
			ctx.textBaseline = "middle";
			const startY2 = badgeY2 + padding / 2 + quizFontSize2 / 2;
			lines2.forEach((ln, i) => {
				ctx.fillText(ln, L.cx, startY2 + i * lineHeight2);
			});
		}

		ctx.restore();
	}

	drawHook(ctx, text, elapsed, state = {}) {
		if (state && state.hookVisible === false) {
			return;
		}

		const cw = (ctx.canvas && ctx.canvas.width) || 1080;
		const ch = (ctx.canvas && ctx.canvas.height) || 1920;
		const L = this.getLayout(cw, ch);
		const colors = this.config.colors || {};
		const font = (state.fontOverride || (state.templateFonts && state.templateFonts.primary) || (this.config.fonts && this.config.fonts.primary) || "Inter");
		const hookFontSize = L.HOOK_FONT_SIZE;

		ctx.save();

		if (window.MCQVS_AnimationEngine && window.MCQVS_AnimationEngine.kineticText) {
			window.MCQVS_AnimationEngine.kineticText.wordByWord(ctx, text, L.HOOK_X, L.HOOK_Y, {
				elapsed: elapsed,
				duration: 2000,
				fontSize: hookFontSize,
				lineHeight: Math.round(hookFontSize * 1.4),
				color: colors.text || "#ffffff",
				font: font,
				effect: "popIn",
			});
		} else if (state.textEffects && state.textEffects.enabled && window.MCQVS_TextEffects) {
			const styleId = state.textEffects.currentStyle || 'classicBold';
			const preset = window.MCQVS_TextEffects.presets[styleId] || window.MCQVS_TextEffects.presets.classicBold;
			const style = preset.hook;

			window.MCQVS_TextEffects.drawStyledText(ctx, text, L.HOOK_X, L.HOOK_Y, {
				...(style || {}),
				maxWidth: L.HOOK_MAX_WIDTH,
				lineHeight: 1.3,
				align: 'center'
			});
		} else {
			ctx.fillStyle = colors.text || "#fff";
			ctx.font = `bold ${hookFontSize}px ${font}`;
			ctx.textAlign = "center";
			this.wrapText(ctx, text, L.HOOK_X, L.HOOK_Y, L.HOOK_MAX_WIDTH, Math.round(hookFontSize * 1.22));
		}

		ctx.restore();
	}

	drawQuestion(ctx, q, isReveal, elapsed, state = {}) {
		if (!q || !q.options) {
			const cw = (ctx.canvas && ctx.canvas.width) || 1080;
			const ch = (ctx.canvas && ctx.canvas.height) || 1920;
			ctx.save();
			ctx.fillStyle = 'rgba(0,0,0,0.75)';
			ctx.fillRect(0, 0, cw, ch);
			ctx.fillStyle = '#fff';
			ctx.font = 'bold 48px Inter, sans-serif';
			ctx.textAlign = 'center';
			ctx.textBaseline = 'middle';
			ctx.fillText('Render Error: invalid question data', cw / 2, ch / 2);
			ctx.restore();
			return;
		}

		const cw = (ctx.canvas && ctx.canvas.width) || 1080;
		const ch = (ctx.canvas && ctx.canvas.height) || 1920;
		const L = this.getLayout(cw, ch);

		const colors = state.templateColors || this.config.colors || {};
		const fontPrimary = ((state.fontOverride) || (state.templateFonts && state.templateFonts.primary) || (this.config.fonts && this.config.fonts.primary) || "Inter")
			+ ", sans-serif";
		const fontSecondary = ((state.fontOverride) || (state.templateFonts && state.templateFonts.secondary) || (this.config.fonts && this.config.fonts.secondary) || "Inter")
			+ ", sans-serif";

		const canvasCfg = this.config.canvas || {};
		const cardStyle = (canvasCfg.card && canvasCfg.card.style) || "glass";

		if (L.isLandscape) {
			this._drawQuestionLandscape(ctx, q, isReveal, elapsed, state, L, colors, fontPrimary, fontSecondary, canvasCfg, cardStyle, cw, ch);
		} else {
			this._drawQuestionPortrait(ctx, q, isReveal, elapsed, state, L, colors, fontPrimary, fontSecondary, canvasCfg, cardStyle, cw, ch);
		}

		void elapsed;
	}

	_drawQuestionPortrait(ctx, q, isReveal, elapsed, state, L, colors, fontPrimary, fontSecondary, canvasCfg, cardStyle, cw, ch) {
		const cardY = L.CARD_TOP;
		const cardWidth = L.CARD_WIDTH;
		const cardX = L.CARD_X;
		const textAreaW = L.TEXT_WIDTH;
		const textAreaH = L.TEXT_MAX_HEIGHT;
		const questionFontSize = fitText(ctx, q.question, fontPrimary, textAreaW, textAreaH, L.QUESTION_FONT_INITIAL);

		ctx.save();
		ctx.font = `bold ${questionFontSize}px ${fontPrimary}`;
		const qLines = wrapTextToLines(ctx, q.question, textAreaW);
		ctx.restore();

		const questionLineHeight = questionFontSize * 1.35;
		const questionTotalHeight = qLines.length * questionLineHeight;

		const questionTopY = cardY + L.QUESTION_TOP_PADDING;
		const questionBottomY = questionTopY + questionTotalHeight;

		let currentOptY = questionBottomY + L.QUESTION_BOTTOM_GAP;
		const optionConfigs = [];

		const qOptions = ["A", "B", "C", "D"];
		qOptions.forEach((opt, i) => {
			const rawText = q.options[opt] || (q.options[i] ? q.options[i] : "");
			const textToDraw = String(rawText || "")
				.replace(new RegExp("^(Option\\s+)?[A-D][.:\\u0029]\\s*", "i"), "")
				.trim();

			let optFontSize = L.OPTION_FONT;
			if (state.textEffects && state.textEffects.enabled && window.MCQVS_TextEffects) {
				const styleId = state.textEffects.currentStyle || 'classicBold';
				const preset = window.MCQVS_TextEffects.presets[styleId] || window.MCQVS_TextEffects.presets.classicBold;
				// @FIX 1.4.9.56: minimalist template removed — always use the standard option font.
				const style = preset.option || {};
				optFontSize = Math.max(style.fontSize || L.OPTION_FONT, 36);
			}

			ctx.save();
			ctx.font = `bold ${optFontSize}px ${fontSecondary}`;
			const lines = wrapTextToLines(ctx, textToDraw, L.OPT_TEXT_WIDTH);
			ctx.restore();

			let boxHeight = L.OPTION_BOX_HEIGHT;
			if (lines.length > 1) boxHeight += (lines.length - 1) * L.OPTION_LINE_HEIGHT;

			optionConfigs.push({
				text: textToDraw,
				y: currentOptY,
				height: boxHeight,
				lines: lines,
				fontSize: optFontSize,
				isCorrect: isReveal && (typeof q.correct === 'number' ? q.correct === i : q.answer === opt),
			});

			currentOptY += boxHeight + L.OPTION_GAP;
		});

		const totalContentBottom = currentOptY + 60;
		const cardH = Math.max(Math.round(ch * 0.604), totalContentBottom - cardY);

		if (cardStyle === "neon") {
			this._drawNeonCard(ctx, cardX, cardY, cardWidth, cardH, canvasCfg.card);
		} else if (cardStyle === "brutalist") {
			this._drawBrutalistCard(ctx, cardX, cardY, cardWidth, cardH, canvasCfg.card);
		} else if (cardStyle === "solid") {
			this._drawSolidCard(ctx, cardX, cardY, cardWidth, cardH, canvasCfg.card);
		} else {
			this._drawGlassCard(ctx, cardX, cardY, cardWidth, cardH, canvasCfg.card);
		}

		this._drawTimerBar(ctx, state, cardY, cardH, L);
		this._drawTimerPill(ctx, state, L);

		this._drawQuestionText(ctx, qLines, questionTopY, questionLineHeight, questionFontSize, colors, fontPrimary, state, L);
		this._drawOptionCards(ctx, optionConfigs, canvasCfg, cardStyle, colors, fontSecondary, state, L, false);

		// @NEW 2026-08-11: Difficulty badge + post-reveal explanation (uses the AI/CSV
		//       difficulty & explanation fields now preserved on every question).
		this._drawDifficultyBadge(ctx, q, L, colors, cw, ch);
		this._drawExplanationBar(ctx, q, isReveal, state, L, colors, cw, ch);
	}

	_drawQuestionLandscape(ctx, q, isReveal, elapsed, state, L, colors, fontPrimary, fontSecondary, canvasCfg, cardStyle, cw, ch) {
		// @REWRITE 2026-08-11 (Option 3 — "Question band + 2x2 grid"):
		//   Header (drawn by drawBranding): [logo][Brand]  [Quiz name centered]  [Q n/total pill]
		//   Question band (full width, wrapped, difficulty badge)
		//   2x2 option grid (letter tiles, wrapped, correct highlight on reveal)
		//   Timer bar (bottom) + countdown pill (bottom-right) + explanation bar
		//   NO per-question CTA — the score challenge lives in the outro only.
		const headerBarH = Math.round(ch * 0.055);
		const headerTop = L.BRAND_Y;
		const headerMid = headerTop + headerBarH / 2;
		const bandPad = Math.round(cw * 0.045);
		const bandTop = headerTop + headerBarH + Math.round(ch * 0.022);
		const bandH = Math.round(ch * 0.19);
		const bandX = bandPad;
		const bandW = cw - bandPad * 2;
		const bandY = bandTop;

		// --- Q n/total counter pill (top-right of header) ---
		const seqIdx = (typeof q.sequenceIndex === 'number' ? q.sequenceIndex : (typeof q.questionIndex === 'number' ? q.questionIndex : 0)) + 1;
		const totalQs = (typeof q.totalQuestions === 'number' ? q.totalQuestions : 0);
		const pillLabel = totalQs > 0 ? 'Q ' + seqIdx + '/' + totalQs : 'Q ' + seqIdx;
		// Reserve space for the corner logo when a corner logo will be drawn by render().
		const lpRaw = String((state && state.logoPosition) || 'all').toLowerCase();
		const cornerActive = (lpRaw === 'corner' || lpRaw === 'all' || lpRaw === 'intro_outro') && !!(state && state.brandLogoImage);
		const rightReserve = cornerActive ? (L.LOGO_SIZE + L.LOGO_PADDING * 2 + Math.round(cw * 0.012)) : Math.round(cw * 0.025);

		ctx.save();
		const pillFs = Math.round(ch * 0.024);
		ctx.font = 'bold ' + pillFs + 'px ' + fontPrimary + ', Inter, sans-serif';
		const pillTextW = ctx.measureText(pillLabel).width;
		const pillPadX = Math.round(pillFs * 0.9);
		const pillW = pillTextW + pillPadX * 2;
		const pillH = Math.round(pillFs * 1.9);
		const pillX = cw - rightReserve - pillW;
		const pillY = headerMid - pillH / 2;
		const pillGrad = ctx.createLinearGradient(pillX, pillY, pillX, pillY + pillH);
		pillGrad.addColorStop(0, 'rgba(18,18,32,0.94)');
		pillGrad.addColorStop(1, 'rgba(10,10,22,0.94)');
		ctx.fillStyle = pillGrad;
		ctx.strokeStyle = (colors && colors.accent) ? colors.accent : '#FFD700';
		ctx.lineWidth = 2;
		this.drawRoundedRect(ctx, pillX, pillY, pillW, pillH, pillH / 2);
		ctx.fill();
		ctx.stroke();
		ctx.fillStyle = '#FFFFFF';
		ctx.font = 'bold ' + pillFs + 'px ' + fontPrimary + ', Inter, sans-serif';
		ctx.textAlign = 'center';
		ctx.textBaseline = 'middle';
		ctx.fillText(pillLabel, pillX + pillW / 2, pillY + pillH / 2 + 1);
		ctx.restore();

		// --- Question band ---
		const drawPanel = (x, y, w, h, cfg, isCell) => {
			const c = Object.assign({}, cfg, isCell ? { opacity: 0.6 } : {});
			if (cardStyle === 'neon') this._drawNeonCard(ctx, x, y, w, h, c);
			else if (cardStyle === 'brutalist') this._drawBrutalistCard(ctx, x, y, w, h, c);
			else if (cardStyle === 'solid') this._drawSolidCard(ctx, x, y, w, h, c);
			else this._drawGlassCard(ctx, x, y, w, h, c);
		};
		const panelCfg = (canvasCfg && canvasCfg.card) || {};
		drawPanel(bandX, bandY, bandW, bandH, panelCfg, false);

		const innerPadX = Math.round(cw * 0.02);
		const innerPadY = Math.round(ch * 0.012);
		const qInnerW = bandW - innerPadX * 2;
		const qInnerH = bandH - innerPadY * 2;

		// Difficulty badge — small pill at the band's left, vertically centered.
		// @FIX 1.4.9.58: sized FIRST so the question text wraps within the space
		//       AFTER the badge. Previously fitText/wrap used the FULL band width
		//       while the text was drawn right of the badge — long lines ran under
		//       the pill and got clipped/overlapped ("MEDUMI", mangled words in
		//       landscape renders).
		let diffX = 0, diffW = 0;
		const diffText = String((q && q.difficulty) || '').trim().toUpperCase();
		if (['EASY', 'MEDIUM', 'HARD'].includes(diffText)) {
			const dFs = Math.round(ch * 0.02);
			ctx.save();
			ctx.font = 'bold ' + dFs + 'px ' + fontSecondary + ', Inter, sans-serif';
			const dTextW = ctx.measureText(diffText).width;
			const dPad = Math.round(dFs * 0.8);
			diffW = dTextW + dPad * 2;
			const diffH = Math.round(dFs * 1.7);
			diffX = bandX + innerPadX;
			const diffY = bandY + (bandH - diffH) / 2;
			const dFill = diffText === 'EASY' ? '#27AE60' : diffText === 'MEDIUM' ? '#F5A623' : '#E53935';
			ctx.fillStyle = dFill;
			this.drawRoundedRect(ctx, diffX, diffY, diffW, diffH, diffH / 2);
			ctx.fill();
			ctx.fillStyle = '#FFFFFF';
			ctx.textAlign = 'center';
			ctx.textBaseline = 'middle';
			ctx.fillText(diffText, diffX + diffW / 2, diffY + diffH / 2 + 1);
			ctx.restore();
		}
		const badgeGapX = diffW ? Math.round(cw * 0.012) : 0;
		// The width actually available for question text (after the badge).
		const textAvailW = Math.max(120, qInnerW - diffW - badgeGapX);

		// Question text — auto-fit then wrap (professional multi-line), within the
		// space right of the difficulty pill.
		const qFont = fitText(ctx, q.question, fontPrimary, textAvailW, qInnerH, Math.round(ch * 0.048));
		ctx.save();
		ctx.font = 'bold ' + qFont + 'px ' + fontPrimary + ', Inter, sans-serif';
		const qLines = wrapTextToLines(ctx, q.question, textAvailW);
		ctx.restore();
		const qLineH = Math.round(qFont * 1.3);
		const qBlockH = qLines.length * qLineH;

		// Question text — centered in the remaining band space (right of difficulty pill)
		const textLeft = bandX + innerPadX + diffW + badgeGapX;
		const textX = textLeft + (bandW - innerPadX * 2 - diffW - badgeGapX) / 2;
		ctx.save();
		ctx.fillStyle = (colors && colors.text) ? colors.text : '#FFFFFF';
		ctx.font = 'bold ' + qFont + 'px ' + fontPrimary + ', Inter, sans-serif';
		ctx.textAlign = 'center';
		ctx.textBaseline = 'middle';
		ctx.shadowBlur = 10;
		ctx.shadowColor = 'rgba(0,0,0,0.55)';
		const textTop = bandY + (bandH - qBlockH) / 2 + qLineH / 2;
		qLines.forEach((ln, i) => ctx.fillText(ln, textX, textTop + i * qLineH));
		ctx.restore();

		// --- 2x2 option grid ---
		const gridTop = bandY + bandH + Math.round(ch * 0.022);
		const gridBottom = Math.round(ch * 0.845);
		const gap = Math.round(cw * 0.018);
		const cellW = (bandW - gap) / 2;
		const cellH = (gridBottom - gridTop - gap) / 2;
		const cellCfg = (canvasCfg && canvasCfg.options) || {};
		const letters = ['A', 'B', 'C', 'D'];
		const optList = [];
		for (let i = 0; i < 4; i++) {
			const raw = q.options ? (q.options[letters[i]] || q.options[i]) : '';
			optList.push(String(raw || '').replace(/^(Option\s+)?[A-D][.:\)]\s*/i, '').trim());
		}
		for (let i = 0; i < 4; i++) {
			const row = Math.floor(i / 2), col = i % 2;
			const cx0 = bandX + col * (cellW + gap);
			const cy0 = gridTop + row * (cellH + gap);
			const isCorrect = isReveal && (typeof q.correct === 'number' ? q.correct === i : q.answer === optList[i]);
			drawPanel(cx0, cy0, cellW, cellH, cellCfg, true);

			// @FIX 2026-08-13 (YT LETTER TILE): the letter TILE was sized off the CELL
			//       (min(cellH*0.5, cellW*0.16) ≈ 129px on a 1920x1080 canvas), so even
			//       after the glyph was reduced, a giant accent square dwarfed each option
			//       cell and the A/B/C/D still read as "big". Size the tile from the
			//       option text instead (compact ~45px) so the letter block is a small,
			//       proportional badge in the corner of the option.
			const oFontStart = Math.round(ch * 0.028);
			const tileSize = Math.max(30, Math.round(oFontStart * 1.5));
			const tileX = cx0 + Math.round(cellW * 0.035);
			const tileY = cy0 + (cellH - tileSize) / 2;

			// option text — wrapped, vertically centered. Computed BEFORE the letter so
			// the letter glyph can scale to the option text (fixes the oversized
			// A/B/C/D on YouTube/long-form, where the glyph was ~2x the option text).
			let oFont = oFontStart;
			let oLines = [optList[i]];
			const oAvailW = cellW - tileSize - Math.round(cellW * 0.05) - Math.round(cellW * 0.035);
			while (oFont > Math.round(ch * 0.016)) {
				ctx.save();
				ctx.font = 'bold ' + oFont + 'px ' + fontSecondary + ', Inter, sans-serif';
				oLines = wrapTextToLines(ctx, optList[i] || '', oAvailW);
				ctx.restore();
				if (oLines.length * oFont * 1.25 <= cellH * 0.8) break;
				oFont -= 2;
			}

			ctx.save();
			ctx.fillStyle = isCorrect ? ((colors && colors.correct) || '#27AE60') : ((colors && colors.accent) || '#FFD700');
			this.drawRoundedRect(ctx, tileX, tileY, tileSize, tileSize, Math.round(tileSize * 0.22));
			ctx.fill();
			ctx.fillStyle = '#FFFFFF';
			// @FIX 2026-08-13 (YT LETTER SIZE): the glyph was sized off the tile
			//       (tileSize*0.52 ≈ 68px on a 261px-tall cell), dwarfing the ~30px
			//       option text. Scale it to the option font instead (a touch larger
			//       than the text, never exceeding the old tile-based size) so A/B/C/D
			//       read as compact labels. The tile itself is now compact too.
			const letterFont = Math.min(Math.round(tileSize * 0.52), Math.max(Math.round(oFont * 1.15), Math.round(ch * 0.02)));
			ctx.font = 'bold ' + letterFont + 'px ' + fontSecondary + ', Inter, sans-serif';
			ctx.textAlign = 'center';
			ctx.textBaseline = 'middle';
			ctx.fillText(letters[i], tileX + tileSize / 2, tileY + tileSize / 2 + 1);
			ctx.restore();

			const oLineH = Math.round(oFont * 1.25);
			const oBlockH = oLines.length * oLineH;
			const oTextX = tileX + tileSize + Math.round(cellW * 0.03);
			const oTextY = cy0 + (cellH - oBlockH) / 2 + oLineH / 2;
			ctx.save();
			ctx.fillStyle = isCorrect ? ((colors && colors.correct) || '#27AE60') : ((colors && colors.text) ? colors.text : '#FFFFFF');
			ctx.font = 'bold ' + oFont + 'px ' + fontSecondary + ', Inter, sans-serif';
			ctx.textAlign = 'left';
			ctx.textBaseline = 'middle';
			ctx.shadowBlur = 6;
			ctx.shadowColor = 'rgba(0,0,0,0.45)';
			oLines.forEach((ln, li) => ctx.fillText(ln, oTextX, oTextY + li * oLineH));
			ctx.restore();

			// correct reveal — green border overlay
			if (isCorrect) {
				ctx.save();
				ctx.strokeStyle = (colors && colors.correct) || '#27AE60';
				ctx.lineWidth = 3;
				this.drawRoundedRect(ctx, cx0, cy0, cellW, cellH, Math.round(Math.min(cellW, cellH) * 0.12));
				ctx.stroke();
				ctx.restore();
			}
		}

		// Timer bar + countdown pill (existing landscape positions: bottom bar, bottom-right pill)
		this._drawTimerBar(ctx, state, 0, gridBottom, L);
		this._drawTimerPill(ctx, state, L);

		// Post-reveal explanation bar (existing, bottom area)
		this._drawExplanationBar(ctx, q, isReveal, state, L, colors, cw, ch);
	}


	// @NEW 2026-08-11: EASY / MEDIUM / HARD pill on the question card. Uses the
	//       difficulty field (AI prompts now return it; CSV importer already stores it).
	//       Color-coded: Easy=green, Medium=amber, Hard=red. No-op when absent.
	_drawDifficultyBadge(ctx, q, L, colors, cw, ch) {
		if (!q || !q.difficulty) return;
		const diff = String(q.difficulty).trim().toLowerCase();
		if (!["easy", "medium", "hard"].includes(diff)) return;

		const diffColor = diff === "easy" ? "#27AE60" : diff === "medium" ? "#F5A623" : "#E53935";
		const label = diff.toUpperCase();
		const fontPx = Math.max(18, Math.round(cw * 0.024));
		const padX = Math.round(fontPx * 0.9);
		const pillH = Math.round(fontPx * 1.7);

		ctx.save();
		ctx.font = `bold ${fontPx}px ${(this.config.fonts && this.config.fonts.primary) || "Inter"}, Inter, sans-serif`;
		const textW = ctx.measureText(label).width;
		const pillW = textW + padX * 2;
		const radius = pillH / 2;
		const x = L.isLandscape ? Math.round(L.CARD_X + L.CARD_WIDTH - pillW - Math.round(cw * 0.01)) : Math.round(L.cx - pillW / 2);
		const y = Math.round(L.CARD_TOP + (L.isLandscape ? 6 : Math.round(ch * 0.008)));

		// Pill background + border
		ctx.fillStyle = diffColor;
		ctx.globalAlpha = 0.92;
		this.drawRoundedRect(ctx, x, y, pillW, pillH, radius);
		ctx.fill();
		ctx.globalAlpha = 1;
		ctx.strokeStyle = "rgba(255,255,255,0.55)";
		ctx.lineWidth = 2;
		this.drawRoundedRect(ctx, x, y, pillW, pillH, radius);
		ctx.stroke();

		// Label
		ctx.fillStyle = "#FFFFFF";
		ctx.font = `bold ${fontPx}px ${(this.config.fonts && this.config.fonts.primary) || "Inter"}, Inter, sans-serif`;
		ctx.textAlign = "center";
		ctx.textBaseline = "middle";
		ctx.fillText(label, x + pillW / 2, y + pillH / 2 + 1);
		ctx.restore();
	}

	// @NEW 2026-08-11: One-line learning bar shown after the reveal (answer visible) —
	//       uses the AI `explanation` field. Appears ~0.65s into the reveal window and
	//       stays for the remainder of the question scene. No-op when absent.
	// @FIX 2026-08-11: Gated by state.showExplanation (Settings > Defaults & Scheduling).
	//       Default OFF — only renders when the job/Studio explicitly enables it.
	_drawExplanationBar(ctx, q, isReveal, state, L, colors, cw, ch) {
		if (!state || state.showExplanation !== true) return;
		if (!q || !q.explanation || !isReveal) return;
		const expl = String(q.explanation).trim();
		if (!expl) return;

		// Only show once the reveal has started + ~650ms (let the correct answer flash first).
		const rsKnown = state && state.timing && state.timing._revealStartRel != null && Number(state.timing._revealStartRel) > 0;
		const elIn = Number(state && state.elapsedInScene) || 0;
		if (rsKnown) {
			if (elIn < Number(state.timing._revealStartRel) + 650) return;
		} else if (!state || state.elapsedInScene === undefined) {
			// No per-scene timing available (some preview paths) — show on reveal only.
		} else if (elIn < 650) {
			return;
		}

		const fontPx = Math.max(22, Math.round(cw * 0.03));
		const padX = Math.round(cw * 0.04);
		const padY = Math.round(fontPx * 0.55);
		const maxW = Math.round(cw * 0.92);
		const barY = Math.round(ch * (L.isLandscape ? 0.86 : 0.88));

		ctx.save();
		ctx.font = `bold ${fontPx}px ${(this.config.fonts && this.config.fonts.secondary) || "Inter"}, Inter, sans-serif`;

		// Wrap to 1-2 lines
		const lines = [];
		let cur = "";
		const words = expl.split(/\s+/).filter(Boolean);
		for (const w of words) {
			const cand = cur ? cur + " " + w : w;
			if (ctx.measureText(cand).width <= maxW) cur = cand;
			else { if (cur) lines.push(cur); cur = w; }
		}
		if (cur) lines.push(cur);
		if (lines.length > 2) lines.length = 2;

		const lineH = Math.round(fontPx * 1.35);
		const barH = Math.round(padY * 2 + lines.length * lineH);

		// Semi-transparent bar + accent edge
		const grad = ctx.createLinearGradient(0, barY, 0, barY + barH);
		grad.addColorStop(0, "rgba(12,12,22,0.88)");
		grad.addColorStop(1, "rgba(12,12,22,0.78)");
		ctx.fillStyle = grad;
		this.drawRoundedRect(ctx, Math.round(cw * 0.04), barY, Math.round(cw * 0.92), barH, Math.round(barH * 0.22));
		ctx.fill();
		ctx.fillStyle = (colors && colors.accent) ? colors.accent : "#FFD700";
		ctx.fillRect(Math.round(cw * 0.04), barY, 6, barH);

		// Text: "💡 " prefix + explanation
		ctx.fillStyle = "#FFFFFF";
		ctx.textAlign = "left";
		ctx.textBaseline = "middle";
		const textX = Math.round(cw * 0.04) + padX;
		const textY = barY + padY + Math.round(lineH / 2);
		lines.forEach((ln, i) => {
			ctx.fillText((i === 0 ? "💡 " : "") + ln, textX, textY + i * lineH);
		});
		ctx.restore();
	}

_drawTimerBar(ctx, state, cardY, cardH, L) {
if (!state.timing || state.elapsedInScene === undefined) return;

	const revealStart = (state.timing._revealStartRel !== undefined)
		? state.timing._revealStartRel
		: (state.timing.questionTotal || 12000) - ((state.timing.questionPhases && state.timing.questionPhases.reveal) || 3000);

	const readingEndRel = state.timing._readingEndRel;
	const elapsedInScene = state.elapsedInScene;
	const effectiveElapsed = (readingEndRel !== undefined && readingEndRel !== null && elapsedInScene < readingEndRel)
		? 0
		: Math.max(0, elapsedInScene - (readingEndRel || 0));

	ctx.save();

	const barH = 6;
	const barW = L.BAR_W;
	const barX = L.BAR_X;
	const barY = L.isLandscape ? L.BAR_Y : (cardY + cardH + L.BAR_Y_OFFSET);
	const barRadius = 3;

	ctx.fillStyle = "rgba(0, 0, 0, 0.8)";
	this.drawRoundedRect(ctx, barX, barY, barW, barH, barRadius);
	ctx.fill();

	ctx.strokeStyle = "#FF00FF";
	ctx.lineWidth = 1;
	ctx.stroke();

	if (elapsedInScene >= 0 && elapsedInScene < revealStart) {
		const remainingRatio = revealStart > 0
			? Math.max(0, Math.min(1, (revealStart - elapsedInScene) / revealStart))
			: 0;
		if (remainingRatio > 0) {
			const fillW = barW * remainingRatio;
			const grad = ctx.createLinearGradient(barX, barY, barX + fillW, barY);
			grad.addColorStop(0, "#FF00FF");
			grad.addColorStop(0.5, "#FFFF00");
			grad.addColorStop(1, "#00FFFF");

			ctx.shadowBlur = 6;
			ctx.shadowColor = "#FF00FF";

			ctx.fillStyle = grad;
			this.drawRoundedRect(ctx, barX, barY, fillW, barH, barRadius);
			ctx.fill();
		}
	}

	ctx.restore();
}

	_drawTimerPill(ctx, state, L) {
		if (!state.timing || state.elapsedInScene === undefined) return;

		const revealStart = (state.timing._revealStartRel !== undefined)
			? state.timing._revealStartRel
			: (state.timing.questionTotal || 12000) - ((state.timing.questionPhases && state.timing.questionPhases.reveal) || 3000);

		const elapsedInScene = state.elapsedInScene;
		if (elapsedInScene >= revealStart) return;

		const remainingMs = revealStart - elapsedInScene;
		const remainingSec = Math.ceil(remainingMs / 1000);

		ctx.save();
		ctx.globalAlpha = 0.95;

		const w = L.TIMER_W, h = L.TIMER_H;
		const r = Math.round(Math.min(w, h) * 0.38);
		const x = L.TIMER_X;
		const y = L.TIMER_Y;

		const grad = ctx.createLinearGradient(x, y, x, y + h);
		grad.addColorStop(0, "rgba(20,20,40,0.95)");
		grad.addColorStop(1, "rgba(10,10,30,0.95)");
		ctx.fillStyle = grad;

		ctx.strokeStyle = "#00f0ff";
		ctx.lineWidth = 5;
		ctx.shadowBlur = 20;
		ctx.shadowColor = "#00f0ff";

		if (remainingMs <= 5000) {
			const blinkPhase = Math.sin((5000 - remainingMs) / 5000 * Math.PI * 4);
			const pulseIntensity = 0.6 + 0.4 * Math.abs(blinkPhase);
			ctx.shadowBlur = 20 + Math.round(25 * pulseIntensity);
			ctx.shadowColor = blinkPhase > 0 ? "#ff3366" : "#00f0ff";
			ctx.strokeStyle = blinkPhase > 0 ? "#ff3366" : "#00f0ff";
			ctx.lineWidth = 5 + Math.round(3 * pulseIntensity);
		}

		this.drawRoundedRect(ctx, x, y, w, h, r);
		ctx.fill();
		ctx.stroke();

		ctx.shadowBlur = 0;
		ctx.fillStyle = "#fff";
		const timerFont = Math.round(h * 0.65);
		ctx.font = `800 ${timerFont}px Inter, sans-serif`;
		ctx.textAlign = "center";
		ctx.textBaseline = "middle";
		ctx.fillText(String(remainingSec), x + w / 2, y + h / 2);

		ctx.restore();
	}

_drawQuestionText(ctx, qLines, questionTopY, questionLineHeight, questionFontSize, colors, fontPrimary, state, L) {
const questionCenterX = L.isLandscape
? L.CARD_X + L.CARD_WIDTH / 2
: L.cx;

ctx.save();
if (state.textEffects && state.textEffects.enabled && window.MCQVS_TextEffects) {
const styleId = state.textEffects.currentStyle || 'classicBold';
const preset = window.MCQVS_TextEffects.presets[styleId] || window.MCQVS_TextEffects.presets.classicBold;

if (preset && preset.question) {
const scaledStyle = this._scaleTextStyle(preset.question, questionFontSize);

qLines.forEach((line, i) => {
const y = questionTopY + (i * questionLineHeight) + (questionLineHeight / 2);

ctx.save();
ctx.textAlign = 'center';
ctx.textBaseline = 'middle';

window.MCQVS_TextEffects.drawStyledText(ctx, line, questionCenterX, y, Object.assign({}, scaledStyle, {
fontSize: questionFontSize,
fontFamily: fontPrimary,
fontWeight: scaledStyle.fontWeight || 'bold',
maxWidth: 5000,
lineHeight: 1,
wrap: false,
align: 'center',
baseline: 'middle'
}));

					ctx.restore();
				});
} else {
this._drawStandardQuestionText(ctx, qLines, questionTopY, questionLineHeight, questionFontSize, colors, fontPrimary, L);
}
} else {
this._drawStandardQuestionText(ctx, qLines, questionTopY, questionLineHeight, questionFontSize, colors, fontPrimary, L);
}
		ctx.restore();
	}

_drawOptionCards(ctx, optionConfigs, canvasCfg, cardStyle, colors, fontSecondary, state, L, isLandscape) {
const optX = L.OPT_X;
const optW = L.OPT_WIDTH;
const textXPad = Math.round(optW * 0.06);
const textStartX = optX + textXPad;

		optionConfigs.forEach(opt => {
			const isCorrect = !!opt.isCorrect;
			const optY = opt.y;
			const boxHeight = opt.height;

			const optStyle = (canvasCfg.options && canvasCfg.options.style) || cardStyle;
			const optRadius = (canvasCfg.options && canvasCfg.options.borderRadius) || 25;

			if (optStyle === "neon" || optStyle === "neon-pill") {
				this._drawNeonCard(ctx, optX, optY, optW, boxHeight, Object.assign({}, canvasCfg.options, {
					borderRadius: optStyle === "neon-pill" ? boxHeight / 2 : optRadius,
					glowBlur: isCorrect ? 30 : 10,
					glowColor: isCorrect ? (colors.correct || "#00ff00") : "rgba(255,255,255,0.2)"
				}));
			} else if (optStyle === "brutalist") {
				this._drawBrutalistCard(ctx, optX, optY, optW, boxHeight, Object.assign({}, canvasCfg.options, {
					shadowColor: isCorrect ? (colors.correct || "#00ff00") : "#000000"
				}));
			} else if (optStyle === "solid") {
				this._drawSolidCard(ctx, optX, optY, optW, boxHeight, Object.assign({}, canvasCfg.options, {
					opacity: isCorrect ? 1 : 0.9,
					borderColor: isCorrect ? (colors.correct || "#00ff00") : "rgba(0,0,0,0.1)"
				}));
			} else {
				this._drawGlassCard(ctx, optX, optY, optW, boxHeight, Object.assign({}, canvasCfg.options, {
					opacity: isCorrect ? 0.95 : (canvasCfg.options && canvasCfg.options.activeOpacity) || 0.1,
					borderColor: isCorrect ? (colors.correct || "#ffffff") : "rgba(255,255,255,0.1)"
				}));
			}

			if (state.textEffects && state.textEffects.enabled && window.MCQVS_TextEffects) {
				const styleId = state.textEffects.currentStyle || 'classicBold';
				const preset = window.MCQVS_TextEffects.presets[styleId] || window.MCQVS_TextEffects.presets.classicBold;

				let style = preset.option || {};
				if (isCorrect && preset.correct) style = Object.assign({}, preset.correct, { fill: colors.text || "#FFFFFF", stroke: "none" });

				const totalTextH = opt.lines.length * (opt.fontSize * 1.2);
				const startTextY = optY + (boxHeight - totalTextH) / 2 + ((opt.fontSize * 1.2) / 2);

				const scaledOptStyle = this._scaleTextStyle(style, opt.fontSize);

				opt.lines.forEach((line, i) => {
					const y = startTextY + (i * opt.fontSize * 1.2);

					ctx.save();
					ctx.textAlign = 'left';
					ctx.textBaseline = 'middle';

					window.MCQVS_TextEffects.drawStyledText(ctx, line, textStartX, y, Object.assign({}, scaledOptStyle, {
						fontSize: opt.fontSize,
						fontFamily: fontSecondary,
						fontWeight: scaledOptStyle.fontWeight || 'bold',
						maxWidth: 5000,
						lineHeight: 1,
						wrap: false,
						align: 'left',
						baseline: 'middle',
						fill: (isCorrect && !preset.correct) ? "#000000" : style.fill
					}));

					ctx.restore();
				});
			} else {
				ctx.fillStyle = isCorrect ? "#000000" : (colors.text || "#FFFFFF");
				ctx.font = `bold ${opt.fontSize}px ${fontSecondary}`;
				ctx.textAlign = "left";
				ctx.textBaseline = "middle";

				const totalTextH = opt.lines.length * (opt.fontSize * 1.2);
				const startTextY = optY + (boxHeight - totalTextH) / 2 + ((opt.fontSize * 1.2) / 2);

				opt.lines.forEach((line, i) => {
					ctx.fillText(line, textStartX, startTextY + (i * opt.fontSize * 1.2));
				});
			}

			ctx.restore();
		});
	}

_drawStandardQuestionText(ctx, lines, startY, lineHeight, fontSize, colors, font, L) {
ctx.fillStyle = (colors && colors.text) || "#FFFFFF";
ctx.font = `bold ${fontSize}px ${font}`;
ctx.textAlign = "center";
ctx.textBaseline = "middle";
ctx.shadowBlur = 10;
ctx.shadowColor = "rgba(0,0,0,0.5)";

const textCenterX = L.isLandscape
? L.CARD_X + L.CARD_WIDTH / 2
: L.cx;

lines.forEach((line, i) => {
ctx.fillText(line, textCenterX, startY + (i * lineHeight) + (lineHeight / 2));
});
}

    // ==========================================
    // @NEW 2026-02-23: Modular Drawing Helpers
    // ==========================================

    _drawGlassCard(ctx, x, y, w, h, cfg = {}) {
      const radius = Math.max(0, Number(cfg.borderRadius) || 40);
      const opacity = Math.min(1, Math.max(0, Number(cfg.opacity) || 0.85));
      const blur = Math.max(0, Number(cfg.blur) || 25);
      const borderWeight = Math.max(0, Number(cfg.borderWeight) || 2);
      const borderColor = cfg.borderColor || "rgba(255, 255, 255, 0.15)";

      ctx.save();
      ctx.shadowBlur = 30;
      ctx.shadowColor = "rgba(0,0,0,0.5)";

      const glassGrad = ctx.createLinearGradient(x, y, x + w, y + h);
      glassGrad.addColorStop(0, `rgba(20, 20, 30, ${opacity})`);
      glassGrad.addColorStop(1, `rgba(10, 10, 20, ${opacity + 0.05})`);

      ctx.fillStyle = glassGrad;
      ctx.strokeStyle = borderColor;
      ctx.lineWidth = borderWeight;

      this.drawRoundedRect(ctx, x, y, w, h, radius);
      ctx.fill();
      ctx.stroke();

      // Inner subtle border for "glass" depth
      ctx.strokeStyle = "rgba(255, 255, 255, 0.05)";
      ctx.lineWidth = 1;
      this.drawRoundedRect(ctx, x + 5, y + 5, w - 10, h - 10, radius - 5);
      ctx.stroke();
      ctx.restore();
    }

    _drawNeonCard(ctx, x, y, w, h, cfg = {}) {
      const radius = Math.max(0, Number(cfg.borderRadius) || 50);
      const glowColor = cfg.glowColor || "#00f0ff";
      const glowBlur = Math.max(0, Number(cfg.glowBlur) || 20);
      const borderWeight = Math.max(0, Number(cfg.borderWeight) || 4);

      ctx.save();
      // Multi-layered glow for "Neon" effect
      ctx.shadowBlur = glowBlur;
      ctx.shadowColor = glowColor;
      ctx.strokeStyle = glowColor;
      ctx.lineWidth = borderWeight;

      // Dark semi-transparent core
      ctx.fillStyle = "rgba(10, 10, 20, 0.9)";
      this.drawRoundedRect(ctx, x, y, w, h, radius);
      ctx.fill();
      ctx.stroke();

      // Secondary inner glow
      ctx.shadowBlur = glowBlur / 2;
      ctx.strokeStyle = "#ffffff";
      ctx.lineWidth = 1;
      this.drawRoundedRect(ctx, x + 2, y + 2, w - 4, h - 4, radius - 2);
      ctx.stroke();
      ctx.restore();
    }

    _drawBrutalistCard(ctx, x, y, w, h, cfg = {}) {
      const offset = Number(cfg.offset) || 15;
      const shadowColor = cfg.shadowColor || "#000000";
      const borderWeight = Math.max(0, Number(cfg.borderWeight) || 4);
      const radius = Math.max(0, Number(cfg.borderRadius) || 0);
      // @FIX 2026-08-11: Brutalist cards were hardcoded WHITE. Templates with neon text
      //       (retro80s magenta/cyan) were unreadable on white. fillColor is now
      //       configurable (default white for back-compat); retro80s passes a dark
      //       fill so its neon text pops.
      const fillColor = cfg.fillColor || "#ffffff";

      ctx.save();
      // Drop shadow (Solid)
      ctx.fillStyle = shadowColor;
      this.drawRoundedRect(ctx, x + offset, y + offset, w, h, radius);
      ctx.fill();

      // Main card
      ctx.fillStyle = fillColor;
      ctx.strokeStyle = shadowColor;
      ctx.lineWidth = borderWeight;
      this.drawRoundedRect(ctx, x, y, w, h, radius);
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }

    _drawSolidCard(ctx, x, y, w, h, cfg = {}) {
      const radius = Math.max(0, Number(cfg.borderRadius) || 20);
      const opacity = Math.min(1, Math.max(0, Number(cfg.opacity) || 0.95));
      const borderWeight = Math.max(0, Number(cfg.borderWeight) || 1);
      const borderColor = cfg.borderColor || "rgba(0,0,0,0.1)";

      ctx.save();
      ctx.fillStyle = `rgba(255, 255, 255, ${opacity})`;
      ctx.strokeStyle = borderColor;
      ctx.lineWidth = borderWeight;
      this.drawRoundedRect(ctx, x, y, w, h, radius);
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }

    drawRoundedRect(ctx, x, y, width, height, radius) {
      const r = Math.max(0, Number(radius) || 0);
      const rr = Math.min(r, width / 2, height / 2);

      ctx.beginPath();
      ctx.moveTo(x + rr, y);
      ctx.lineTo(x + width - rr, y);
      ctx.quadraticCurveTo(x + width, y, x + width, y + rr);
      ctx.lineTo(x + width, y + height - rr);
      ctx.quadraticCurveTo(x + width, y + height, x + width - rr, y + height);
      ctx.lineTo(x + rr, y + height);
      ctx.quadraticCurveTo(x, y + height, x, y + height - rr);
      ctx.lineTo(x, y + rr);
      ctx.quadraticCurveTo(x, y, x + rr, y);
      ctx.closePath();
    }

	drawOutro(ctx, state, assets = {}) {
		const cw = (ctx.canvas && ctx.canvas.width) || 1080;
		const ch = (ctx.canvas && ctx.canvas.height) || 1920;
		const L = this.getLayout(cw, ch);
		ctx.save();

		const overlay = ctx.createLinearGradient(0, 0, 0, ch);
		overlay.addColorStop(0, "rgba(15, 23, 42, 0.4)");
		overlay.addColorStop(0.4, "rgba(15, 23, 42, 0.95)");
		overlay.addColorStop(1, "rgba(15, 23, 42, 1.0)");
		ctx.fillStyle = overlay;
		ctx.fillRect(0, 0, cw, ch);

		const lp = mcqvs_normalizeLogoPosition(state.logoPosition);

		// @FIX 2026-06-27 OUTRO_LOGO: Resolve a drawable logo by checking assets first
		// then state.brandLogoImage, since preview/export parity must hold and
		// image width/height may be 0 when the asset is still mid-decode.
		const _isDrawable = (img) => !!(img && typeof img === 'object' && Number(img.width) > 0 && Number(img.height) > 0);
		const logo = _isDrawable(assets && assets.logoImage)
			? assets.logoImage
			: (_isDrawable(state && state.brandLogoImage) ? state.brandLogoImage : null);

		let brandY = L.OUTRO_BRAND_Y;

		if (logo && (lp === "outro" || lp === "all" || lp === "intro_outro" || lp === "corner")) {
			const maxSize = L.OUTRO_LOGO_MAX;
			const scale = Math.min(maxSize / logo.width, maxSize / logo.height);
			const w = logo.width * scale;
			const h = logo.height * scale;
			const x = (cw - w) / 2;
			const y = L.OUTRO_LOGO_Y;

			try {
				ctx.drawImage(logo, x, y, w, h);
				brandY = L.OUTRO_LOGO_Y + maxSize + Math.round(maxSize * 0.33);
			} catch (e) {
				console.warn("drawOutro: Logo draw failed", e);
			}
		}

		// @FIX 2026-05-02: Use template-aware primary font in outro + clamp brand name width
		const outroBrandFont = ((state.fontOverride) || (state.templateFonts && state.templateFonts.primary) || (this.config.fonts && this.config.fonts.primary) || "Inter");
			// @FIX: Use layout-aware OUTRO_BRAND_FONT (90px portrait / 59px landscape)
		//       instead of hardcoded 0.045 (~49px) which was unreadable on mobile.
		let outroBrandFontSize = L.OUTRO_BRAND_FONT;
		const maxOutroBrandWidth = cw * 0.9;
		// @FIX 2026-08-04: Use `bold` keyword + simple fallback chain (matches drawBranding
		//       which works on Linux node-canvas). The previous `700 ... system-ui, -apple-system,
		//       sans-serif` string was silently rejected by Pango's CSS font parser on Linux,
		//       leaving ctx.font at the default "10px sans-serif" — making brand/CTA unreadable.
		const _outroFontStr = `bold ${outroBrandFontSize}px ${outroBrandFont}, Inter, sans-serif`;
		ctx.font = _outroFontStr;
		const _rlog = (typeof globalThis !== 'undefined' && globalThis.__MCQVS_RENDER_LOG) || (typeof global !== 'undefined' && global.__MCQVS_RENDER_LOG) || null;
		if (_rlog) _rlog('[drawOutro:DIAG] post-set-font ctxFont="' + ctx.font + '" fontStr="' + _outroFontStr + '"');
		let outroMeasured = ctx.measureText(state.brandName || "").width;

		// DIAGNOSTIC: Log exact values for outro text sizing
		if (_rlog) {
			_rlog('[drawOutro:DIAG] cw=' + cw + ' ch=' + ch + ' isLandscape=' + L.isLandscape + ' outroBrandFont=' + outroBrandFont + ' initialFontSize=' + outroBrandFontSize + ' brandName="' + (state.brandName || '') + '" measuredWidth=' + outroMeasured + ' maxBrandWidth=' + maxOutroBrandWidth + ' fontOverride="' + (state.fontOverride || '') + '" templateFonts=' + JSON.stringify(state.templateFonts));
			_rlog('[drawOutro:DIAG] layout OUTRO_BRAND_FONT=' + L.OUTRO_BRAND_FONT + ' OUTRO_CTA_FONT=' + L.OUTRO_CTA_FONT + ' OUTRO_LOGO_MAX=' + L.OUTRO_LOGO_MAX + ' OUTRO_LOGO_Y=' + L.OUTRO_LOGO_Y + ' OUTRO_BRAND_Y=' + L.OUTRO_BRAND_Y);
		}

		while (outroMeasured > maxOutroBrandWidth && outroBrandFontSize > 28) {
			outroBrandFontSize -= 2;
			ctx.font = `bold ${outroBrandFontSize}px ${outroBrandFont}, Inter, sans-serif`;
			outroMeasured = ctx.measureText(state.brandName || "").width;
		}
		if (_rlog) _rlog('[drawOutro:DIAG] finalBrandFontSize=' + outroBrandFontSize + ' clampFired=' + (outroBrandFontSize < L.OUTRO_BRAND_FONT));

		ctx.font = `bold ${outroBrandFontSize}px ${outroBrandFont}, Inter, sans-serif`;
		ctx.fillStyle = "#FFFFFF";
		ctx.textAlign = "center";
		ctx.textBaseline = "middle";
		ctx.shadowColor = "rgba(0,0,0,0.6)";
		ctx.shadowBlur = 25;
		ctx.shadowOffsetY = 10;
		ctx.fillText(state.brandName || "Quiz Master", cw / 2, brandY);

		const colors = state.templateColors || this.config.colors || {};
		const ctaColor = colors.accent || colors.primary || "#fbbf24";

		const ctaText = state.computedCtaText || state.ctaText || "Subscribe for More!";
		const outroCtaFont = outroBrandFont;
		let outroCtaFontSize = L.OUTRO_CTA_FONT;
		const maxCtaWidth = cw * 0.85;
		ctx.font = `bold ${outroCtaFontSize}px ${outroCtaFont}, Inter, sans-serif`;
		let ctaMeasured = ctx.measureText(ctaText).width;
		if (_rlog) _rlog('[drawOutro:DIAG] ctaText="' + ctaText + '" initialCtaFontSize=' + outroCtaFontSize + ' measuredWidth=' + ctaMeasured + ' maxCtaWidth=' + maxCtaWidth);
		while (ctaMeasured > maxCtaWidth && outroCtaFontSize > 22) {
			outroCtaFontSize -= 2;
			ctx.font = `bold ${outroCtaFontSize}px ${outroCtaFont}, Inter, sans-serif`;
			ctaMeasured = ctx.measureText(ctaText).width;
		}
		if (_rlog) _rlog('[drawOutro:DIAG] finalCtaFontSize=' + outroCtaFontSize + ' clampFired=' + (outroCtaFontSize < L.OUTRO_CTA_FONT));

		ctx.font = `bold ${outroCtaFontSize}px ${outroCtaFont}, Inter, sans-serif`;
		ctx.fillStyle = ctaColor;
		ctx.shadowColor = "rgba(0,0,0,0.9)";
		ctx.shadowBlur = 25;
		ctx.shadowOffsetY = 6;
		ctx.fillText(ctaText, cw / 2, brandY + L.OUTRO_CTA_Y_OFFSET);

		// @FIX 2026-08-13 (DOUBLE CTA): the 'score' preset already puts the ask in the
		//       main CTA ("Comment your score 👇 5/5?"). The old logic ALSO forced a
		//       second rank line ("👇 Drop your score in the comments!") whenever the CTA
		//       text mentioned "comment your score", stacking two near-identical CTA
		//       asks on the outro (reported as "double CTA"). The supporting rank line is
		//       now shown ONLY when the rank system is explicitly enabled AND the main
		//       CTA is not already a score/comment prompt — so a normal score CTA renders
		//       a single, clean ask.
		const ctaAsksScore = /comment your score|drop your score|your score|comment/i.test(ctaText);
		if (state.useRankSystemCTA === true && !ctaAsksScore) {
			ctx.font = `bold ${L.OUTRO_RANK_FONT}px ${outroBrandFont}, Inter, sans-serif`;
			ctx.fillStyle = ctaColor;
			ctx.shadowBlur = 0;
			const rankLine = 'Comment your score below! 👇';
			ctx.fillText(rankLine, cw / 2, brandY + L.OUTRO_RANK_Y_OFFSET);
		}

		if (state.websiteUrl) {
			ctx.font = `${L.OUTRO_URL_FONT}px ${outroBrandFont}, Inter, sans-serif`;
			ctx.fillStyle = "rgba(255,255,255,0.7)";
			ctx.shadowBlur = 0;
			ctx.fillText(state.websiteUrl, cw / 2, brandY + L.OUTRO_URL_Y_OFFSET);
		}

		if (state.ctaPreset && state.ctaPreset !== 'custom') {
			this.drawVectorIcon(ctx, isScoreCta ? 'trophy' : state.ctaPreset, cw / 2, brandY + L.OUTRO_CTA_Y_OFFSET - 100, 80);
		}

		ctx.restore();
	}

    drawVectorIcon(ctx, type, x, y, size) {
      ctx.save();
      ctx.fillStyle = "#FFD700";
      ctx.shadowColor = "#FFD700";
      ctx.shadowBlur = 15;
      ctx.translate(x, y);

      const s = size / 100;
      ctx.scale(s, s);

      if (type === 'bell' || type === 'subscribe') {
        ctx.beginPath();
        ctx.moveTo(0, -40);
        ctx.bezierCurveTo(20, -40, 35, -20, 35, 10);
        ctx.lineTo(45, 30);
        ctx.lineTo(-45, 30);
        ctx.lineTo(-35, 10);
        ctx.bezierCurveTo(-35, -20, -20, -40, 0, -40);
        ctx.fill();

        ctx.beginPath();
        ctx.arc(0, 30, 10, 0, Math.PI);
        ctx.fill();
      } else if (type === 'like' || type === 'thumb') {
        ctx.font = "80px sans-serif";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText("\u{1F44D}", 0, 0);
      } else if (type === 'share') {
        ctx.font = "80px sans-serif";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText("\u{1F4E4}", 0, 0);
      } else if (type === 'comment') {
        ctx.font = "80px sans-serif";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText("\u{1F4AC}", 0, 0);
      } else if (type === 'trophy') {
        ctx.font = "80px sans-serif";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText("\u{1F3C6}", 0, 0);
      } else if (type === 'follow') {
        ctx.font = "80px sans-serif";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText("\u{2795}", 0, 0);
      } else if (type === 'link') {
        ctx.font = "80px sans-serif";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText("\u{1F517}", 0, 0);
      }

      ctx.restore();
    }

    wrapText(ctx, text, x, y, maxWidth, lineHeight) {
      const words = String(text || '').split(" ");
      let line = "";
      let dy = 0;
      for (let n = 0; n < words.length; n++) {
        const testLine = line + words[n] + " ";
        if (ctx.measureText(testLine).width > maxWidth && n > 0) {
          ctx.fillText(line, x, y + dy);
          line = words[n] + " ";
          dy += lineHeight;
        } else {
          line = testLine;
        }
      }
      ctx.fillText(line, x, y + dy);
    }

applyPostProcessing(ctx, state) {
if (!window.MCQVS_AnimationEngine) return;
const pp = window.MCQVS_AnimationEngine.postProcessing;
const cw = (ctx.canvas && ctx.canvas.width) || 1080;
const ch = (ctx.canvas && ctx.canvas.height) || 1920;

try { pp.vignette(ctx, cw, ch, 0.35); } catch(e) { /* vignette failed, continue */ }

if (state.enableFilmGrain !== false) {
try { pp.filmGrain(ctx, cw, ch, 0.04); } catch(e) { /* filmGrain failed, continue */ }
}
}

_wrapQuizText(ctx, text, maxTextWidth, font, startFontSize, minFontSize) {
		let fontSize = startFontSize || minFontSize;
		const tryWrap = (size) => {
			ctx.font = `bold ${size}px ${font}`;
			const words = String(text).split(/\s+/).filter(Boolean);
			const lines = [];
			let current = '';
			let widest = 0;
			for (let i = 0; i < words.length; i++) {
				const word = words[i];
				const candidate = current ? (current + ' ' + word) : word;
				const w = ctx.measureText(candidate).width;
				if (w <= maxTextWidth) {
					current = candidate;
					widest = Math.max(widest, ctx.measureText(current).width);
				} else if (!current) {
					let chunk = '';
					for (const ch of word) {
						const t = chunk + ch;
						if (chunk && ctx.measureText(t).width > maxTextWidth) {
							lines.push(chunk);
							widest = Math.max(widest, ctx.measureText(chunk).width);
							chunk = ch;
						} else {
							chunk = t;
						}
					}
					current = chunk;
					if (current) widest = Math.max(widest, ctx.measureText(current).width);
				} else {
					lines.push(current);
					widest = Math.max(widest, ctx.measureText(current).width);
					current = word;
				}
			}
			if (current) {
				lines.push(current);
				widest = Math.max(widest, ctx.measureText(current).width);
			}
			return { lines, widest };
		};
		let result = tryWrap(fontSize);
		while (result.lines.some((l) => ctx.measureText(l).width > maxTextWidth) && fontSize > minFontSize) {
			fontSize -= 1;
			result = tryWrap(fontSize);
		}
		return { lines: result.lines, fontSize: fontSize, maxLineWidth: result.widest };
	}

  }

  // ==========================================
  // SUB TEMPLATES
  // ==========================================
class NeonTemplate extends VideoTemplate {
  drawBackground(ctx, state) {
    super.drawBackground(ctx, state);

    const cw = (ctx.canvas && ctx.canvas.width) || 1080;
    const ch = (ctx.canvas && ctx.canvas.height) || 1920;
    const elapsed = state.elapsed || 0;
    ctx.save();
    ctx.strokeStyle = (this.config.colors && this.config.colors.secondary) || "#00f0ff";
    ctx.shadowBlur = 10;
    ctx.shadowColor = (this.config.colors && this.config.colors.secondary) || "#00f0ff";
    ctx.globalAlpha = 0.2 + Math.sin(elapsed / 500) * 0.1;
    ctx.lineWidth = 2;

    const offset = (elapsed / 20) % 100;
    for (let y = 0; y < ch; y += 100) {
      ctx.beginPath();
      ctx.moveTo(0, y + offset);
      ctx.lineTo(cw, y + offset);
      ctx.stroke();
    }
    for (let x = 0; x < cw; x += 100) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, ch);
      ctx.stroke();
    }
    ctx.restore();
  }

    renderComponent(ctx, component, state, assets, scene = null) {
      ctx.save();
      ctx.shadowBlur = 15;
      ctx.shadowColor = (this.config.colors && this.config.colors.primary) || "#00f0ff";
      const res = super.renderComponent(ctx, component, state, assets, scene);
      ctx.restore();
      return res;
    }
  }

class SpaceTemplate extends VideoTemplate {
  constructor(id, config) {
    super(id, config);
    this.stars = null;
  }

  drawBackground(ctx, state) {
    super.drawBackground(ctx, state);
    const cw = (ctx.canvas && ctx.canvas.width) || 1080;
    const ch = (ctx.canvas && ctx.canvas.height) || 1920;
    const elapsed = state.elapsed || 0;

    if (!this.stars) {
      const salt = 'space_stars:' + String(this.id || this.templateId || 'space');
      this.stars = Array.from({ length: 100 }, (_, i) => ({
        x: mcqvs_rand01(state, salt, i * 4 + 0) * cw,
        y: mcqvs_rand01(state, salt, i * 4 + 1) * ch,
        s: mcqvs_rand01(state, salt, i * 4 + 2) * 3 + 1,
        o: mcqvs_rand01(state, salt, i * 4 + 3) * Math.PI * 2,
      }));
    }

    ctx.save();
    this.stars.forEach((s) => {
      ctx.fillStyle = "#fff";
      ctx.globalAlpha = 0.3 + Math.sin(s.o + elapsed / 1000) * 0.5;
      ctx.beginPath();
      ctx.arc(s.x, (s.y + (elapsed / 20) * s.s) % ch, s.s, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.restore();
  }
}

  class LuxuryTemplate extends VideoTemplate {
    // @MODIFIED 2026-02-07: Added state parameter to match parent signature
drawBranding(ctx, name, quizName, logo, state = {}) {
ctx.save();
const cw = (ctx.canvas && ctx.canvas.width) || 1080;
const grad = ctx.createLinearGradient(Math.round(cw * 0.2), 0, Math.round(cw * 0.8), 0);
      grad.addColorStop(0, "#D4AF37");
      grad.addColorStop(0.5, "#FFF7A0");
      grad.addColorStop(1, "#D4AF37");
      ctx.fillStyle = grad;
      ctx.shadowBlur = 20;
      ctx.shadowColor = "rgba(212, 175, 55, 0.5)";
      super.drawBranding(ctx, name, quizName, logo, state);
      ctx.restore();
    }
  }

class RetroTemplate extends VideoTemplate {
  applyPostProcessing(ctx, state) {
    const cw = (ctx.canvas && ctx.canvas.width) || 1080;
    const ch = (ctx.canvas && ctx.canvas.height) || 1920;
    ctx.fillStyle = "rgba(0,0,0,0.1)";
    for (let y = 0; y < ch; y += 8) ctx.fillRect(0, y, cw, 4);

    ctx.globalAlpha = 0.03;
    const fi = (state && typeof state.frameIndex === 'number')
      ? state.frameIndex
      : Math.floor((state.elapsed || 0) / 33.33);

    for (let i = 0; i < 1000; i++) {
      const r0 = mcqvs_rand01(state, 'retro_noise', fi * 3000 + i * 3 + 0);
      const r1 = mcqvs_rand01(state, 'retro_noise', fi * 3000 + i * 3 + 1);
      const r2 = mcqvs_rand01(state, 'retro_noise', fi * 3000 + i * 3 + 2);
      ctx.fillStyle = (r0 > 0.5) ? "#fff" : "#000";
      ctx.fillRect(r1 * cw, r2 * ch, 4, 4);
    }
    ctx.globalAlpha = 1.0;
  }
}

  class HorrorTemplate extends VideoTemplate {
    render(ctx, state, assets) {
      ctx.save();
      const fi = (state && typeof state.frameIndex === 'number')
        ? state.frameIndex
        : Math.floor((state.elapsed || 0) / 33.33);

      const r0 = mcqvs_rand01(state, 'horror_jitter', fi * 3 + 0);
      if (r0 > 0.95) {
        const r1 = mcqvs_rand01(state, 'horror_jitter', fi * 3 + 1);
        const r2 = mcqvs_rand01(state, 'horror_jitter', fi * 3 + 2);
        ctx.translate((r1 - 0.5) * 10, (r2 - 0.5) * 10);
      }
      super.render(ctx, state, assets);
      ctx.restore();
    }

  applyPostProcessing(ctx, state) {
    const cw = (ctx.canvas && ctx.canvas.width) || 1080;
    const ch = (ctx.canvas && ctx.canvas.height) || 1920;
    const cx = cw / 2;
    const cy = ch / 2;
    const grad = ctx.createRadialGradient(cx, cy, Math.round(Math.min(cw, ch) * 0.19), cx, cy, Math.round(Math.max(cw, ch) * 0.63));
    grad.addColorStop(0, "rgba(0,0,0,0)");
    grad.addColorStop(1, "rgba(0,0,0,0.8)");
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, cw, ch);
      void state;
    }
  }

  // ==========================================
  // TEMPLATE MANAGER
  // ==========================================
  const MCQVS_TemplateManager = {
    instances: {},

    getTemplate(id) {
      if (this.instances[id]) return this.instances[id];

      const config = (window.MCQVS_VideoTemplates && typeof window.MCQVS_VideoTemplates.get === 'function')
        ? window.MCQVS_VideoTemplates.get(id)
        : null;

      if (!config) return new VideoTemplate("default", {});

      if (config && config.schema && window.MCQVS_SchemaValidate) {
        const res = window.MCQVS_SchemaValidate.validate(config.schema, config, "template");
        if (!res.ok) {
          console.error("[MCQVS] Template schema invalid for", id, res.issues);
          throw new Error("Template schema invalid for " + id);
        }
      }

      let instance;
      switch (config.category) {
        case "energetic":
          instance = new NeonTemplate(id, config);
          break;

        case "themed":
          if (id === "retro80s") instance = new RetroTemplate(id, config);
          else if (id === "horror") instance = new HorrorTemplate(id, config);
          else if (id === "space") instance = new SpaceTemplate(id, config);
          else instance = new VideoTemplate(id, config);
          break;

        case "professional":
          if (id === "elegant") instance = new LuxuryTemplate(id, config);
          else instance = new VideoTemplate(id, config);
          break;

        default:
          instance = new VideoTemplate(id, config);
      }

      this.instances[id] = instance;
      return instance;
    },

    renderFromSchema: function (ctx, schema, data, state) {
      if (!schema || !schema.layers) {
        console.warn("[TemplateManager] Invalid schema - no layers defined");
        return;
      }

    const canvasW = (ctx.canvas && ctx.canvas.width) || 1080;
    const canvasH = (ctx.canvas && ctx.canvas.height) || 1920;

      schema.layers.forEach(layer => {
        if (layer.visible === false) return;

        ctx.save();

        const x = this._resolvePosition(layer.x, canvasW);
        const y = this._resolvePosition(layer.y, canvasH);

        switch (layer.type) {
          case 'rect': this._renderRect(ctx, layer, x, y, canvasW, canvasH, state); break;
          case 'text': this._renderText(ctx, layer, x, y, data, state); break;
          case 'image': this._renderImage(ctx, layer, x, y, data, state); break;
          case 'gradient': this._renderGradient(ctx, layer, canvasW, canvasH, state); break;
        }

        ctx.restore();
      });
    },

    _resolvePosition: function (value, dimension) {
      if (typeof value === 'string' && value.endsWith('%')) {
        return (parseFloat(value) / 100) * dimension;
      }
      return parseFloat(value) || 0;
    },

    _pathRoundedRect: function (ctx, x, y, w, h, r) {
      const rr = Math.max(0, Number(r) || 0);
      const radius = Math.min(rr, w / 2, h / 2);
      ctx.beginPath();
      ctx.moveTo(x + radius, y);
      ctx.lineTo(x + w - radius, y);
      ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
      ctx.lineTo(x + w, y + h - radius);
      ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h);
      ctx.lineTo(x + radius, y + h);
      ctx.quadraticCurveTo(x, y + h, x, y + h - radius);
      ctx.lineTo(x, y + radius);
      ctx.quadraticCurveTo(x, y, x + radius, y);
      ctx.closePath();
    },

    _renderRect: function (ctx, layer, x, y, canvasW, canvasH, state) {
      const w = this._resolvePosition(layer.width, canvasW);
      const h = this._resolvePosition(layer.height, canvasH);
      const radius = layer.radius || 0;

      ctx.fillStyle = layer.fill || 'rgba(0,0,0,0.5)';
      if (layer.shadow) {
        ctx.shadowBlur = layer.shadow.blur || 10;
        ctx.shadowColor = layer.shadow.color || 'rgba(0,0,0,0.5)';
      }

      if (typeof ctx.roundRect === 'function') {
        ctx.beginPath();
        ctx.roundRect(x, y, w, h, radius);
        ctx.fill();
      } else {
        this._pathRoundedRect(ctx, x, y, w, h, radius);
        ctx.fill();
      }

      if (layer.stroke) {
        ctx.strokeStyle = layer.stroke.color || '#fff';
        ctx.lineWidth = layer.stroke.width || 2;
        ctx.stroke();
      }

      void state;
    },

    _renderText: function (ctx, layer, x, y, data, state) {
      let text = layer.text;
      if (layer.dataKey && data && data[layer.dataKey]) text = data[layer.dataKey];
      if (!text) return;

      const fontSize = layer.fontSize || 48;
      const fontWeight = layer.fontWeight || 'bold';
      const fontFamily = layer.fontFamily || 'Inter, sans-serif';

      ctx.font = `${fontWeight} ${fontSize}px ${fontFamily}`;
      ctx.fillStyle = layer.fill || '#ffffff';
      ctx.textAlign = layer.align || 'center';
      ctx.textBaseline = layer.baseline || 'middle';

      if (layer.shadow) {
        ctx.shadowBlur = layer.shadow.blur || 10;
        ctx.shadowColor = layer.shadow.color || 'rgba(0,0,0,0.5)';
      }

      if (layer.maxWidth) {
        const lines = wrapTextToLines(ctx, text, layer.maxWidth);
        const lineHeight = fontSize * (layer.lineHeight || 1.2);
        lines.forEach((line, i) => ctx.fillText(line, x, y + (i * lineHeight)));
      } else {
        ctx.fillText(text, x, y);
      }

      void state;
    },

    _renderImage: function (ctx, layer, x, y, data, state) {
      const img = (layer.dataKey && data) ? data[layer.dataKey] : null;
      if (!img) return;

      const w = layer.width || img.width || 100;
      const h = layer.height || img.height || 100;

      ctx.drawImage(img, x - w / 2, y - h / 2, w, h);

      void state;
    },

    _renderGradient: function (ctx, layer, canvasW, canvasH, state) {
      const colors = layer.colors || ['#000', '#333'];
      const grad = ctx.createLinearGradient(0, 0, 0, canvasH);
      colors.forEach((c, i) => grad.addColorStop(i / (colors.length - 1), c));
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, canvasW, canvasH);
      void state;
    },

    schemas: {
      trivia: {
        id: 'trivia',
        name: 'General Trivia (JSON)',
        layers: [
          { type: 'gradient', colors: ['#1a0a3e', '#2d1b69', '#4a2c8d'] },
          { type: 'rect', x: '7.4%', y: '20.8%', width: '85.2%', height: '60.4%', fill: 'rgba(20, 20, 30, 0.85)', radius: 40, shadow: { blur: 30, color: 'rgba(0,0,0,0.5)' } },
          { type: 'text', x: '50%', y: '12%', dataKey: 'brandName', fontSize: 64, fill: '#00f0ff', align: 'center' },
          { type: 'text', x: '50%', y: '28%', dataKey: 'question', fontSize: 52, fill: '#ffffff', align: 'center', maxWidth: 840, lineHeight: 1.2 }
        ]
      }
    }
  };

  window.MCQVS_TemplateManager = MCQVS_TemplateManager;

})(window);
