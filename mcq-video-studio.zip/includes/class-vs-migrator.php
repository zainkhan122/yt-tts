<?php

/**
 * Migration Tool: Legacy Posts to Custom Tables
 *
 * Handles the migration of 'mcq' post types and 'topic'/'nm_exam' taxonomies
 * into the new 'wp_vs_mcq_bank' and 'wp_vs_topics' custom tables.
 *
 * @package MCQ_Video_Studio
 * @since 1.1.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class VS_Migrator
{

    private static $instance = null;
    private $batch_size = 50;

    public static function init()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        add_action('wp_ajax_mcqvs_run_migration', array($this, 'ajax_run_migration'));
        add_action('wp_ajax_mcqvs_get_migration_status', array($this, 'ajax_get_migration_status'));
    }

    /**
     * AJAX: Run Migration Batch
     */
    public function ajax_run_migration()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        $offset = isset($_POST['offset']) ? absint($_POST['offset']) : 0;
        $stats = $this->migrate_batch($offset);

        wp_send_json_success($stats);
    }

    /**
     * AJAX: Get Migration Stats (Total count)
     */
    public function ajax_get_migration_status()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');

        // @FIX: Missing capability gate — any logged-in user could enumerate legacy MCQ posts.
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Forbidden');
        }

        $count = $this->get_legacy_count();
        wp_send_json_success(array('total' => $count));
    }

    /**
     * Get count of unmigrated posts
     */
    private function get_legacy_count()
    {
        $args = array(
            'post_type'      => 'mcq',
            'post_status'    => 'any',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'meta_query'     => array(
                array(
                    'key'     => '_mcqvs_migrated',
                    'compare' => 'NOT EXISTS'
                )
            )
        );
        $query = new WP_Query($args);
        return $query->found_posts;
    }

    /**
     * Process a batch of posts
     */
    private function migrate_batch($offset = 0)
    {
        global $wpdb;
        $repo = new VS_MCQ_Repository();

        $args = array(
            'post_type'      => 'mcq',
            'post_status'    => 'any',
            'posts_per_page' => $this->batch_size,
            'meta_query'     => array(
                array(
                    'key'     => '_mcqvs_migrated',
                    'compare' => 'NOT EXISTS'
                )
            )
        );

        $query = new WP_Query($args);

        // @FIX: Hard cap iterations within a single AJAX call so a runaway WP_Query can't
        //       exhaust PHP memory or block the request indefinitely. Anything beyond this
        //       limit is queued for the next AJAX batch.
        $max_iterations_per_call = 200;
        $iterations = 0;
        $migrated = 0;
        $errors = 0;
        $processed_ids = array();

        if (!$query->have_posts()) {
            return array(
                'migrated' => 0,
                'errors'   => 0,
                'done'     => true,
                'message'  => 'No more posts to migrate.'
            );
        }

        foreach ($query->posts as $post) {
            if ($iterations >= $max_iterations_per_call) {
                break;
            }
            $iterations++;
            try {
                // 1. Extract Data
                $question_text = $post->post_title;
                $options_raw   = get_post_meta($post->ID, 'mcq_options', true);
                $correct_raw   = get_post_meta($post->ID, 'mcq_answer', true);

                // 2. Handle Taxonomy (Topic)
                $terms = get_the_terms($post->ID, 'topic'); // Prioritize 'topic'
                if (!$terms || is_wp_error($terms)) {
                    $terms = get_the_terms($post->ID, 'nm_exam'); // Fallback 'nm_exam'
                }

                $topic_id = 0;
                if ($terms && !is_wp_error($terms) && !empty($terms)) {
                    $term = reset($terms); // Take first term
                    // Sync Term to Custom Table
                    $topic_id = $repo->create_topic($term->name, 'subject');
                    // @FIX: `is_wp_error()` on an int is always false. Branch is dead.
                    //       Run actual check using the actual result type, then log.
                    if (is_wp_error($topic_id)) {
                        error_log("VS Migrator: Failed to sync topic for Post {$post->ID}: " . $topic_id->get_error_message());
                        $topic_id = 0;
                    } elseif (!is_numeric($topic_id) || (int) $topic_id <= 0) {
                        error_log("VS Migrator: create_topic returned non-numeric ID for Post {$post->ID}: " . var_export($topic_id, true));
                        $topic_id = 0;
                    } else {
                        $topic_id = (int) $topic_id;
                    }
                }

                // 3. Normalize Options/Answer (Reuse logic from Handler?)
                // Just save raw for now, Repository checks basic validity.
                // We need `correct_index`. Legacy stored text.
                // We must find the index.

                $flat_options = array();
                if (is_array($options_raw)) {
                    foreach ($options_raw as $opt) {
                        $flat_options[] = trim(preg_replace('/^(Option\s+|[A-D0-9][\.\)\:\-\s]+|\([A-D0-9]\)\s*)/i', '', (string)$opt));
                    }
                }

                $correct_index = -1;
                $clean_correct = trim(strtolower((string) $correct_raw));
                // 1. Exact text match.
                $found = array_search($clean_correct, array_map('strtolower', $flat_options), true);
                if ($found !== false && $found >= 0 && $found <= 3) {
                    $correct_index = (int) $found;
                } else {
                    // 2. Letter-prefix match (A/B/C/D), useful for legacy raw "A" or "B." etc.
                    if (preg_match('/^\s*\(?\s*([A-Da-d])\s*\)?[\.\)\:\-]?/', (string) $correct_raw, $m)) {
                        $letter_index = ord(strtoupper($m[1])) - ord('A');
                        if ($letter_index >= 0 && $letter_index < count($flat_options)) {
                            $correct_index = $letter_index;
                        }
                    }
                }
                // 3. @FIX: Last-resort default to 0 keeps inserts non-fatal but logs a warning.
                if ($correct_index < 0) {
                    error_log("VS Migrator: Could not derive correct_index for Post {$post->ID}; defaulting to 0. Raw correct value: " . (string) $correct_raw);
                    $correct_index = 0;
                }

                // 4. Insert into Bank
                $result = $repo->insert_mcq(array(
                    'question_text' => $question_text,
                    'options'       => $flat_options,
                    'correct_index' => $correct_index,
                    'topic_id'      => $topic_id,
                    'status'        => 'approved',
                    'source_ref'    => 'post_' . $post->ID
                ));

                if (is_wp_error($result) && $result->get_error_code() !== 'duplicate_mcq') {
                    throw new Exception($result->get_error_message());
                }

                // 5. Mark as Migrated
                update_post_meta($post->ID, '_mcqvs_migrated', 1);
                $migrated++;
                $processed_ids[] = $post->ID;
            } catch (Exception $e) {
                $errors++;
                error_log("VS Migrator Error Post {$post->ID}: " . $e->getMessage());
                // Mark processed even if error to prevent infinite loop? 
                // Better to mark as '_mcqvs_migration_failed'
                update_post_meta($post->ID, '_mcqvs_migrated', 'failed');
            }
        }

        return array(
            'migrated' => $migrated,
            'errors'   => $errors,
            // @FIX: Done when fewer items than page-size came back, OR when we hit the cap
            //       (so future polls can continue from the meta-marker we wrote).
            'done'     => count($query->posts) < $this->batch_size || $iterations >= $max_iterations_per_call && count($query->posts) < $max_iterations_per_call,
            'remaining' => $this->get_legacy_count()
        );
    }
}
