<?php
$type = (!empty($term_id)?'term':'post');
$wpil_post = new Wpil_Model_Post($post_id, $type);
$max_links_per_post = get_option('wpil_max_links_per_post', 0);
$post_at_max_links = false;

if(get_option('wpil_disable_outbound_suggestions')){ ?>
    <div class="wpil_styles" style="min-height: 200px">
        <p style="display: inline-block;"><?php esc_html_e('Outbound Link Suggestions Disabled', 'wpil') ?></p>
        <a style="float: right; margin: 15px 0px;" href="<?=esc_url(admin_url("admin.php?{$wpil_post->type}_id={$wpil_post->id}&page=link_whisper&type=inbound_suggestions_page&ret_url=" . base64_encode($wpil_post->getLinks()->edit)))?>" class="button-primary">Add Inbound links</a>
        <br />
        <a href="<?=esc_url($wpil_post->getLinks()->export)?>" target="_blank"><?php esc_html_e('Export post data for support', 'wpil') ?></a>
    </div>
    <?php
    return;
}elseif(!empty($max_links_per_post)){
    // check if the current post is at the link limit
    if(Wpil_link::at_max_outbound_links($wpil_post)){
        $post_at_max_links = true;
    }
}

$force_manual_suggestions = $manually_trigger_suggestions || $post_at_max_links;
$manual_button_text = $post_at_max_links ? __('Generate More Suggestions Anyway', 'wpil') : __('Get Suggestions', 'wpil');
$suggestion_url = admin_url('admin.php?post_id=' . $post_id . '&page=link_whisper&type=outbound_suggestions_ajax'.(!empty($term_id)?'&term_id='.$term_id:'').(!empty($user->ID) ? '&nonce='.wp_create_nonce($user->ID .'wpil_suggestion_nonce') : '')) . Wpil_Settings::get_suggestion_filter_string() . ($post_at_max_links ? '&ignore_max_link_limit=1' : '');
?>
<?php if($force_manual_suggestions){ ?>
    <div class="wpil_styles wpil-get-manual-suggestions-container" style="min-height: 200px">
        <?php if($post_at_max_links){ ?>
            <p style="display: inline-block;"><?php esc_html_e('Post has reached the max link limit. If you still want more ideas for this post, click the button below and Link Whisper will generate more suggestions anyway.', 'wpil') ?></p>
            <br />
        <?php } ?>
        <a href="#" id="wpil-get-manual-suggestions" style="margin: 15px 0px;" class="button-primary"><?php echo esc_html($manual_button_text); ?></a>
        <a style="float: right; margin: 15px 0px;" href="<?=esc_url(admin_url("admin.php?{$wpil_post->type}_id={$wpil_post->id}&page=link_whisper&type=inbound_suggestions_page&ret_url=" . base64_encode($wpil_post->getLinks()->edit)))?>" class="button-primary">Add Inbound links</a>
        <br />
        <a href="<?=esc_url($wpil_post->getLinks()->export)?>" target="_blank"><?php esc_html_e('Export post data for support', 'wpil') ?></a>
    </div>
<?php } ?>
<div data-wpil-ajax-container="" data-wpil-ajax-container-url="<?=esc_url($suggestion_url)?>" class="wpil_keywords_list wpil_styles" data-wpil-manual-suggestions="<?php echo ($force_manual_suggestions) ? 1: 0;?>" <?php echo ($force_manual_suggestions) ? 'style="display:none"': ''; ?> data-wpil-suggestion-nonce="<?php echo wp_create_nonce($user->ID .'wpil_suggestion_nonce'); ?>">
    <div class="progress_panel loader">
        <div class="progress_count" style="width: 100%"><?php esc_html_e('Processing Link Suggestions', 'wpil');?></div>
    </div>
    <div class="wpil-process-loading-error-message">
        <p><?php esc_html_e('The suggestions are taking longer than normal, so there might have been an error.', 'wpil'); ?></p>
        <p><?php esc_html_e('If you don\'t see any progress in the next 2 minutes, please try reloading the page and re-starting the process.', 'wpil'); ?></p>
    </div>
</div>
