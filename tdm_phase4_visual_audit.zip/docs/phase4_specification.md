# Phase 4 — Cinematic visual planning

**Status:** implemented (planner + diversity gate). **Does not render films.** Custom `index.html` remains the production path; `hf_compose.py` is fallback only. `pipeline.py` untouched.

## Quality bar (why this phase is heavy)

Highest-quality TDM visuals are **not** sharper Ken Burns or another caption bar. They are:

1. **One grammar per film.** Pick a *mode* (character / environment / object / mechanism / symbol) and stay inside it. Mixing phone-UI + ECG + door-slabs is a kit, not a film.
2. **Meaning is the motion.** If the sentence is overcrowding, the picture must *spatially* overcrowd. If the sentence is ambiguous loss, the picture must split presence/absence. Zoom+pan on a moody still is the **fallback when motion is not the meaning** (R27).
3. **Type is a system, not a stamp.** One family, one size, one tracking *inside* a Short. Gold is for 1–3 punches, not every word. Do not mix HF caption styles.
4. **Modesty (R1.7).** No nudes, cleavage, bare chest, body close-ups. People fully clothed; prefer silhouette, hands, rooms, objects.
5. **Do not inherit the last Short.** s01 living-death (phone/ECG/LIVING–DEATH split) and s02 door-slabs+maze are **retired grammars** for any *new* family. Same navy/gold brand is allowed; same GSAP ids and motifs are not.
6. **Feasibility honesty.** This pipeline has stills + GSAP/HyperFrames 2D. Never promise 3D, After Effects, or live-action we cannot shoot.
7. **No 2026 listicle chassis.** No quiz, countdown, or ranked-list wrapper.

## CLI

```
python3 tools/plan_visual.py DIR     # write DIR/visual_plan.json (additive)
python3 tools/check_visual.py DIR    # diversity + type lock + feasibility
```

Exit: **0** pass/warn · **1** usage · **3** visual fail. **Never 2.**

## `visual_plan.json` (canonical)

See `docs/schemas/visual_plan.md`. Modes, motif, palette, type lock, per-beat `visual_intent` vs `hf` implementation id.

## Banned fingerprints

Computed from real HTML:

- s01 `videos/short_s01_hf/living-death/index.html` (phone, ecg, wLive/wDeath, motes…)
- s02 `videos/short_s02/index.html` (`d1`–`d6`, `maze`, `deck`…)

`check_visual` Jaccard of element `id`s vs those sets: **≥ 0.35 and ≥ 4 shared** → FAIL for a directory whose topic id is **not** s01/s02. Owners may match themselves.

Generic `hf_compose` scene names used as the *only* grammar on a new family → **WARN** (fallback), not an identity.

## Five identities (contracts, not five renders)

`tools/visual_identities.json`

| id | Mode | Not allowed to copy |
|---|---|---|
| `id.jung_symbol` | symbol | s01 split words / ECG |
| `id.relationship_character` | character | phone-bubble chat UI as the whole film |
| `id.cognitive_mechanism` | mechanism | **s02 door slabs** |
| `id.existential_environment` | environment | s01 ghost motes as default fog |
| `id.long_object_diagram` | object | applying Short kinetic bars to 16:9 |

Acceptance later: five **shot** films, one each. Phase 4 only stores the contracts and refuses collisions.

## Additive `beat_needs`

`plan_visual.py --patch-needs` may add `visual_intent`, `motif`, `palette`, `transition`, `camera` **without** deleting `hf`/`kind`/`start`.
