<?php

/**
 * Canonical Slug Service
 *
 * Single source of truth for generating clean, evergreen slugs from software names.
 * Handles migration from versioned slugs to clean slugs with Rank Math 301 redirects.
 *
 * @package SEO_Article_Generator\Utils
 * @since   2026-08-04
 */

namespace SEO_Article_Generator\Utils;

if (! defined('ABSPATH')) {
    exit;
}

/**
 * Canonical Slug Service
 *
 * Generates clean, evergreen slugs from software names and handles
 * migration from versioned slugs with Rank Math 301 redirects.
 */
final class Canonical_Slug_Service
{
    /**
     * Option key for migration state tracking.
     */
    private const OPTION_MIGRATION_STATE = 'seo_gen_slug_migration_state';

    /**
     * Option key for rollback data.
     */
    private const OPTION_ROLLBACK_DATA = 'seo_gen_slug_rollback_data';

    /**
     * Regex pattern to detect versioned slugs for PHP preg_match.
     * Matches patterns like:
     *   software-1.0.0
     *   software-1.0.0-final
     *   software-2.0.0-beta
     *   software-2026-build-23-0
     *   software-1-0-0 (dashed dotted notation)
     *   software-20260531
     *   software-with-prose-suffix-after-version (e.g. upx-5-2-0-ultimate-packer-for-executables)
     */
    private const VERSIONED_SLUG_PATTERN_PHP = '/-\d+(?:[._-]\d+)*(?:-(?:final|beta|alpha|rc|update|build|release|preview|dev|nightly|stable|lts|esr|\d{8}))?(?:-[a-z][\w-]*)?$/i';

    /**
     * Regex pattern to detect versioned slugs for MySQL REGEXP.
     * Loose pattern to catch candidates; precise filtering is done in PHP via
     * VERSIONED_SLUG_PATTERN_PHP.
     */
    private const VERSIONED_SLUG_PATTERN_DB = '-[0-9]';

/**
     * Generate clean, evergreen slug from a versioned slug.
     * Extracts the core software name by removing version suffixes.
     *
     * @param string $versioned_slug e.g., "mame-0236", "potplayer-1721555", "kmplayer-42256-final-2021082612"
     * @return string Clean slug e.g., "mame", "potplayer", "kmplayer"
     */
    public static function generate_clean_slug_from_versioned(string $versioned_slug): string
    {
        $clean = $versioned_slug;

        // Remove version patterns from the end - handle both single and multiple digit groups
        // Pattern: -digits (with optional additional .digit or -digit groups) + optional suffixes
        $clean = preg_replace('/-\d+(?:[._-]\d+)*(?:-(?:final|beta|alpha|rc|update|build|release|preview|dev|nightly|stable|lts|esr|\d{8}))?(?:-[a-z][a-zA-Z0-9_-]*)?$/i', '', $clean);
        $clean = preg_replace('/-(?:final|beta|alpha|rc|update|build|release|preview|dev|nightly|stable|lts|esr)$/i', '', $clean);
        $clean = preg_replace('/-\d{8}$/', '', $clean); // Remove date suffixes like 20260531
        $clean = preg_replace('/-by-.+$/', '', $clean); // Remove "by-treecardgames" etc.
        $clean = preg_replace('/-\d+(?:[._-]\d+)+.*$/', '', $clean);

        return $clean;
    }

    /**
     * Generate clean, evergreen slug from software name.
     * Strips version-like suffixes that might have slipped through.
     *
     * @param string $software_name e.g., "MediaCoder"
     * @param string $category_slug optional category for hierarchical URLs (not used per requirements)
     * @return string Clean slug e.g., "mediacoder"
     */
    public static function generate_clean_slug(string $software_name, string $category_slug = ''): string
    {
        // Sanitize the software name
        $clean = sanitize_title($software_name);

        // Remove common version-like suffixes that might have slipped through
        $clean = preg_replace('/-\d+(?:[._-]\d+)+(?:-.*)?$/', '', $clean);
        $clean = preg_replace('/-(final|beta|alpha|rc|update|build|release|preview|dev|nightly|stable|lts|esr)$/i', '', $clean);
        $clean = preg_replace('/-\d{8}$/', '', $clean); // Remove date suffixes like 20260531
        $clean = preg_replace('/-by-.+$/', '', $clean); // Remove "by-treecardgames" etc.
        // [REGEX-FIX] Strip any trailing prose that follows a versioned suffix,
        // e.g. "upx-5-2-0-ultimate-packer-for-executables" → "upx".
        $clean = preg_replace('/-\d+(?:[._-]\d+)+.*$/', '', $clean);

        // Per requirements: NO category in URL (flat structure)
        // $category_slug is ignored

        return $clean;
    }

/**
      * Check if a slug contains a version pattern.
      *
      * @param string $slug
      * @return bool
      */
     public static function is_versioned_slug(string $slug): bool
     {
         return (bool) preg_match(self::VERSIONED_SLUG_PATTERN_PHP, $slug);
     }

    /**
     * Check if Rank Math Redirections module is active and available.
     *
     * @return bool
     */
    public static function is_rankmath_redirections_active(): bool
    {
        // Check for Pro version first
        if (class_exists('\RankMathPro\Redirections\Redirections')) {
            return true;
        }

        // Check for free version
        if (class_exists('\RankMath\Redirections\DB')) {
            return true;
        }

        return false;
    }

    /**
     * Flag to skip redirect creation for current migration run.
     * Set by AJAX handler before calling run_migration().
     *
     * @var bool
     */
    private static $skip_redirect_creation = false;

    /**
     * Check if plugin-managed Rank Math redirects are disabled for current run.
     *
     * @return bool
     */
    public static function should_skip_redirect_creation(): bool
    {
        if (self::$skip_redirect_creation) {
            return true;
        }
        return (bool) get_option(\SEO_Article_Generator\Option_Registry::DISABLE_RM_REDIRECTS, false);
    }

    /**
     * Set the skip redirect flag for the current migration run.
     *
     * @param bool $skip
     * @return void
     */
    public static function set_skip_redirect_creation(bool $skip): void
    {
        self::$skip_redirect_creation = $skip;
    }

    /**
     * Get the Rank Math Redirections DB class (works for both free and Pro).
     *
     * @return string|null Class name or null if not available
     */
    public static function get_rm_db_class(): ?string
    {
        if (class_exists('\RankMathPro\Redirections\DB')) {
            return '\RankMathPro\Redirections\DB';
        }
        if (class_exists('\RankMath\Redirections\DB')) {
            return '\RankMath\Redirections\DB';
        }
        return null;
    }

    /**
     * Create a 301 redirect via Rank Math Redirections API.
     * Works for both free and Pro versions.
     *
     * @param string $from_slug Source slug (without leading/trailing slash)
     * @param string $to_slug   Target slug (without leading/trailing slash)
     * @return bool True on success
     */
    public static function create_rankmath_redirect(string $from_slug, string $to_slug): bool
    {
        if (!self::is_rankmath_redirections_active()) {
            error_log('[CanonicalSlug] Rank Math Redirections module not active');
            return false;
        }

        $db_class = self::get_rm_db_class();
        if (!$db_class) {
            error_log('[CanonicalSlug] No Rank Math DB class found');
            return false;
        }

        try {
            global $wpdb;
            $table = $wpdb->prefix . 'rank_math_redirections';
            $target = trailingslashit('/' . $to_slug);
            $pattern = '/' . $from_slug;

            // Raw array for Rank Math API (add/update) — API handles serialization
            $sources_raw = [
                [
                    'pattern'    => $pattern,
                    'comparison' => 'contains',
                ],
            ];

            // Serialized for direct DB LIKE query and fallback insert
            $sources_serialized = maybe_serialize($sources_raw);

            // Direct DB check: find existing redirect with exact pattern in sources
            $existing = $wpdb->get_row($wpdb->prepare(
                "SELECT id FROM $table WHERE sources LIKE %s AND status = 'active' LIMIT 1",
                '%"pattern";s:' . strlen($pattern) . ':"' . $wpdb->esc_like($pattern) . '"%'
            ));

            if ($existing && $existing->id) {
                $update_args = [
                    'id'          => $existing->id,
                    'url_to'      => $target,
                    'sources'     => $sources_raw,
                    'header_code' => 301,
                    'status'      => 'active',
                ];
                $result = $db_class::update($update_args);
                if (is_wp_error($result)) {
                    error_log('[CanonicalSlug] Failed to update redirect #' . $existing->id . ': ' . $result->get_error_message());
                    return false;
                }
                return true;
            }

            // Insert new redirect via Rank Math API (pass raw array, not serialized)
            $args = [
                'sources'     => $sources_raw,
                'url_to'      => $target,
                'header_code' => 301,
                'hits'        => 0,
                'status'      => 'active',
            ];

            $result = $db_class::add($args);
            if (is_wp_error($result) || !$result) {
                error_log('[CanonicalSlug] RM API add failed for ' . $from_slug . ' → ' . $to_slug . ', trying direct DB insert');
                return self::insert_redirect_direct($sources_serialized, $target);
            }

            return true;
        } catch (\Throwable $e) {
            error_log('[CanonicalSlug] Redirect creation exception: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Direct DB insert for a Rank Math redirect.
     *
     * @param string $sources Serialized sources data
     * @param string $target  Target URL with trailing slash
     * @return bool
     */
    private static function insert_redirect_direct(string $sources, string $target): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . 'rank_math_redirections';

        $inserted = $wpdb->insert(
            $table,
            [
                'sources'     => $sources,
                'url_to'      => $target,
                'header_code' => 301,
                'type'        => 'plain',
                'hits'        => 0,
                'status'      => 'active',
                'name'        => '',
                'created'     => current_time('mysql'),
                'updated'     => current_time('mysql'),
            ],
            ['%s', '%s', '%d', '%s', '%d', '%s', '%s', '%s', '%s']
        );

        if ($inserted === false) {
            error_log('[CanonicalSlug] Direct DB insert failed: ' . $wpdb->last_error);
            return false;
        }

        return true;
    }

    /**
     * Delete a redirect by source slug.
     *
     * @param string $from_slug Source slug
     * @return bool
     */
    public static function delete_rankmath_redirect(string $from_slug): bool
    {
        if (!self::is_rankmath_redirections_active()) {
            return false;
        }

        try {
            global $wpdb;
            $table = $wpdb->prefix . 'rank_math_redirections';
            $pattern = '/' . $from_slug;

            // Direct DB delete: match exact pattern in serialized sources
            $deleted = $wpdb->query($wpdb->prepare(
                "DELETE FROM $table WHERE sources LIKE %s",
                '%"pattern";s:' . strlen($pattern) . ':"' . $wpdb->esc_like($pattern) . '"%'
            ));

            return $deleted !== false;
        } catch (\Throwable $e) {
            error_log('[CanonicalSlug] Redirect deletion exception: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Verify a redirect actually exists in the database with valid sources.
     * The Rank Math API sometimes returns success but the redirect row has
     * empty sources, making it invisible and non-functional. This method
     * does a direct DB check to confirm the redirect is real.
     *
     * @param string $from_slug Source slug
     * @param string $to_slug   Target slug
     * @return bool True if redirect exists with valid sources
     */
    public static function verify_redirect_exists(string $from_slug, string $to_slug): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . 'rank_math_redirections';
        $target = trailingslashit('/' . $to_slug);
        $source_pattern = '%' . $wpdb->esc_like('/' . $from_slug) . '%';

        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT id, sources FROM $table WHERE url_to = %s AND sources LIKE %s AND status = 'active' LIMIT 1",
            $target,
            $source_pattern
        ));

        if (!$row) {
            return false;
        }

        // Ensure sources is not empty and contains valid data
        $sources = maybe_unserialize($row->sources);
        if (empty($sources) || !is_array($sources) || empty($sources[0]['pattern'])) {
            return false;
        }

        return true;
    }

    /**
     * Get the primary category slug for a post (first non-OS category).
     *
     * @param int $post_id
     * @return string
     */
    public static function get_primary_category_slug(int $post_id): string
    {
        // First check Rank Math Primary Category meta
        $primary_cat_id = (int) get_post_meta($post_id, 'rank_math_primary_category', true);
        if ($primary_cat_id > 0) {
            $term = get_term($primary_cat_id, 'category');
            if ($term && !is_wp_error($term)) {
                return $term->slug;
            }
        }

        // Fallback: first non-OS category
        $terms = get_the_terms($post_id, 'category');
        if ($terms && !is_wp_error($terms)) {
            $os_slugs = ['windows', 'mac', 'macos', 'linux', 'android', 'ios', 'featured', 'offline', 'portable'];
            foreach ($terms as $t) {
                if (!in_array($t->slug, $os_slugs, true)) {
                    return $t->slug;
                }
            }
        }

        return '';
    }

    /**
     * Migrate a single post from versioned slug to clean slug with 301 redirect.
     * This is the core migration function.
     *
     * @param int $post_id Post ID to migrate
     * @return array Result array with keys: success, old_slug, new_slug, redirect_created, error
     */
    public static function migrate_slug(int $post_id): array
    {
        $result = [
            'success'         => false,
            'old_slug'        => '',
            'new_slug'        => '',
            'redirect_created' => false,
            'error'           => '',
            'rollback_entries' => [], // Secondary rollback entries (older posts renamed during collision)
        ];

        $post = get_post($post_id);
        if (!$post || $post->post_type !== 'post') {
            $result['error'] = 'Post not found or not a post type';
            return $result;
        }

        $old_slug = $post->post_name;
        $result['old_slug'] = $old_slug;
        $result['post_id'] = $post_id; // Add post_id to result for frontend logging

        // Skip if already clean
        if (!self::is_versioned_slug($old_slug)) {
            $result['error'] = 'Slug is already clean (no version pattern)';
            return $result;
        }

        // Get software name from hero data (for collision resolution only)
        $hero_data = \SEO_Article_Generator\Plugin::get_instance()->get_hero_data($post_id);
        $software_name = $hero_data['software_name'] ?? $post->post_title;

        // Generate clean slug from the versioned slug itself (more reliable than hero_data)
        $new_slug = self::generate_clean_slug_from_versioned($old_slug);
        $result['new_slug'] = $new_slug;

        // [COLLISION-FIX] Resolve collision with deterministic dual-canonical strategy:
        //   Case A: existing canonical is NON-plugin-owned (editor-created)
        //           → editor wins; current versioned post redirects to editor post.
        //   Case B: existing canonical IS plugin-owned
        //           → latest-modified wins (gets clean slug); older gets 301 to latest.
        //   Case C: no existing canonical
        //           → current post becomes canonical with clean slug.
        $collision = self::resolve_clean_slug_collision($post_id, $new_slug);
        if ($collision['action'] === 'redirect_to_editor') {
            $redirect_created = self::create_rankmath_redirect($old_slug, $collision['canonical_slug']);
            $result['redirect_created'] = $redirect_created;
            $result['new_slug'] = $collision['canonical_slug'];
            if (!$redirect_created) {
                $result['error'] = 'Failed to create Rank Math 301 redirect to editor canonical';
                return $result;
            }
            $result['success'] = true;
            $result['note'] = $collision['note'] ?? 'Editor canonical exists; versioned post redirected to it.';
            // [LOG] Record permalink change in plugin logs
            $logger = \SEO_Article_Generator\Plugin::get_instance()->get_logger();
            if ($logger) {
                $logger->info('slug_redirect_to_editor', [
                    'post_id'       => $post_id,
                    'old_slug'      => $old_slug,
                    'editor_slug'   => $collision['canonical_slug'],
                    'redirect_code' => 301,
                ]);
            }
            $result['note'] = $collision['note'] ?? 'Editor canonical exists; versioned post redirected to it.';
            return $result;
        }
        if ($collision['action'] === 'redirect_older_plugin') {
            $new_slug = $collision['canonical_slug'];
            $result['new_slug'] = $new_slug;
            $older_post_id = $collision['older_post_id'];
            $older_old_slug = $collision['older_old_slug'];
            $older_redirect = self::create_rankmath_redirect($older_old_slug, $new_slug);
            if (!$older_redirect) {
                $result['error'] = 'Failed to create 301 from older plugin-owned canonical';
                return $result;
            }
            $older_update = wp_update_post([
                'ID'        => $older_post_id,
                'post_name' => $older_old_slug . '-' . $older_post_id,
            ], true);
            if (is_wp_error($older_update)) {
                self::delete_rankmath_redirect($older_old_slug);
                $result['error'] = 'Failed to rename older plugin-owned post: ' . $older_update->get_error_message();
                return $result;
            }
            self::invalidate_post_path_cache($older_post_id, $older_old_slug);
            // Track secondary rollback entry for the renamed older post
            $result['rollback_entries'][] = [
                'post_id'  => $older_post_id,
                'old_slug' => $older_old_slug,
                'new_slug' => $older_old_slug . '-' . $older_post_id,
                'redirect' => true,
            ];
            // [LOG] Older plugin post renamed
            $logger = \SEO_Article_Generator\Plugin::get_instance()->get_logger();
            if ($logger) {
                $logger->info('slug_older_plugin_renamed', [
                    'older_post_id'  => $older_post_id,
                    'old_slug'       => $older_old_slug,
                    'new_slug'       => $older_old_slug . '-' . $older_post_id,
                    'winner_post_id' => $post_id,
                ]);
            }
            $result['note'] = 'Newer plugin post wins; older post ' . $older_post_id . ' redirected';
        }
        if ($collision['action'] === 'redirect_older_editor') {
            $new_slug = $collision['canonical_slug'];
            $result['new_slug'] = $new_slug;
            $older_post_id = $collision['older_post_id'];
            $older_old_slug = $collision['older_old_slug'];
            $older_redirect = self::create_rankmath_redirect($older_old_slug, $new_slug);
            if (!$older_redirect) {
                $result['error'] = 'Failed to create 301 from older editor-owned canonical';
                return $result;
            }
            $older_update = wp_update_post([
                'ID'        => $older_post_id,
                'post_name' => $older_old_slug . '-' . $older_post_id,
            ], true);
            if (is_wp_error($older_update)) {
                self::delete_rankmath_redirect($older_old_slug);
                $result['error'] = 'Failed to rename older editor-owned post: ' . $older_update->get_error_message();
                return $result;
            }
            self::invalidate_post_path_cache($older_post_id, $older_old_slug);
            // Track secondary rollback entry for the renamed older post
            $result['rollback_entries'][] = [
                'post_id'  => $older_post_id,
                'old_slug' => $older_old_slug,
                'new_slug' => $older_old_slug . '-' . $older_post_id,
                'redirect' => true,
            ];
            // [LOG] Older editor post renamed
            $logger = \SEO_Article_Generator\Plugin::get_instance()->get_logger();
            if ($logger) {
                $logger->info('slug_older_editor_renamed', [
                    'older_post_id'  => $older_post_id,
                    'old_slug'       => $older_old_slug,
                    'new_slug'       => $older_old_slug . '-' . $older_post_id,
                    'winner_post_id' => $post_id,
                ]);
            }
            $result['note'] = 'Newer plugin post wins; older editor post ' . $older_post_id . ' redirected';
        }

        // Create 301 redirect via Rank Math (or skip if Rank Math auto-redirect is handling it)
        if (self::should_skip_redirect_creation()) {
            $redirect_created = true;
            $result['redirect_created'] = false;
            $result['note'] = (isset($result['note']) ? $result['note'] . ' ' : '') . '(Plugin redirects disabled — Rank Math will auto-redirect).';
        } else {
            $redirect_created = self::create_rankmath_redirect($old_slug, $new_slug);
            $result['redirect_created'] = $redirect_created;

            if (!$redirect_created) {
                $result['error'] = 'Failed to create Rank Math 301 redirect';
                return $result;
            }

            // [VERIFY-FIX] Verify redirect actually exists with valid sources in DB.
            // The Rank Math API sometimes returns success but creates a row with empty
            // sources, which makes the redirect invisible and non-functional.
            if (!self::verify_redirect_exists($old_slug, $new_slug)) {
                $result['error'] = 'Redirect created but verification failed (missing sources). Direct DB insert required.';
                error_log('[CanonicalSlug] Redirect verification failed for ' . $old_slug . ' -> ' . $new_slug);
                // Attempt direct DB insert as last resort
                $sources = maybe_serialize([
                    [
                        'pattern'    => '/' . $old_slug,
                        'comparison' => 'contains',
                    ],
                ]);
                self::insert_redirect_direct($sources, trailingslashit('/' . $new_slug));
            }
        }

        // Update post slug
        $update_result = wp_update_post([
            'ID'        => $post_id,
            'post_name' => $new_slug,
        ], true);

        if (is_wp_error($update_result)) {
            $result['error'] = 'Failed to update post slug: ' . $update_result->get_error_message();
            // Try to rollback redirect
            self::delete_rankmath_redirect($old_slug);
            return $result;
        }

        // Invalidate permalink cache
        if (class_exists('\SEO_Article_Generator\Services\Schema_Sync_Service')) {
            \SEO_Article_Generator\Services\Schema_Sync_Service::invalidate_permalink_cache($post_id);
        }
        // [CACHE-FIX] Also clear WP's post-path cache so subsequent items in
        // the same batch see the renamed slug instead of the cached old one.
        self::invalidate_post_path_cache($post_id, $old_slug);

        $result['success'] = true;
        // [LOG] Permalink migrated
        $logger = \SEO_Article_Generator\Plugin::get_instance()->get_logger();
        if ($logger) {
            $logger->info('slug_migrated', [
                'post_id'  => $post_id,
                'old_slug' => $old_slug,
                'new_slug' => $new_slug,
                'redirect' => true,
            ]);
        }
        return $result;
    }

/**
     * Get ALL posts that have versioned slugs (plugin-owned AND editor-owned).
     * Winner is determined by latest post_modified_gmt in collision resolution,
     * not by ownership.
     *
     * @param int $limit
     * @param int $offset
     * @return array Array of post IDs
     */
    public static function get_versioned_posts(int $limit = 100, int $offset = 0): array
    {
        global $wpdb;

        $table = $wpdb->posts;

        // Query ALL versioned posts (no SQL LIMIT — $wpdb->prepare() drops LIMIT
        // when %s and %d placeholders are mixed in some MySQL configurations).
        $query = $wpdb->prepare(
            "SELECT ID, post_name FROM {$table}
              WHERE post_type = 'post'
                AND post_status IN ('publish', 'draft', 'future')
                AND post_name REGEXP %s
              ORDER BY ID ASC",
            self::VERSIONED_SLUG_PATTERN_DB
        );

        $results = $wpdb->get_results($query, ARRAY_A);

        $all_ids = [];
        if (!empty($results)) {
            foreach ($results as $row) {
                $all_ids[] = (int) $row['ID'];
            }
        }

        // Apply offset and limit in PHP
        return array_slice($all_ids, $offset, $limit);
    }

/**
     * Count ALL posts with versioned slugs (plugin-owned AND editor-owned).
     *
     * @return int
     */
    public static function count_versioned_posts(): int
    {
        global $wpdb;

        $table = $wpdb->posts;

        $query = $wpdb->prepare(
            "SELECT COUNT(*) FROM {$table}
              WHERE post_type = 'post'
                AND post_status IN ('publish', 'draft', 'future')
                AND post_name REGEXP %s",
            self::VERSIONED_SLUG_PATTERN_DB
        );

        $count = $wpdb->get_var($query);

        // Filter to plugin-owned (rough estimate - we'll refine in migration)
        return (int) ($count ?: 0);
    }

    /**
     * Run a dry-run migration to preview changes.
     *
     * @param int $limit Number of posts to preview
     * @return array Preview data
     */
    public static function dry_run_migration(int $limit = 100): array
    {
        $posts = self::get_versioned_posts($limit);
        $preview = [];

        foreach ($posts as $post_id) {
            $post = get_post($post_id);
            if (!$post) {
                continue;
            }

            // Generate clean slug from the versioned slug itself
            $old_slug = $post->post_name;
            $new_slug = self::generate_clean_slug_from_versioned($old_slug);

            // [DRY-RUN-FIX] Use same collision resolution as real migration
            $collision = self::resolve_clean_slug_collision($post_id, $new_slug);
            $action = $collision['action'];
            $final_slug = $collision['canonical_slug'] ?? $new_slug;
            $note = '';

            if ($action === 'redirect_to_editor') {
                $note = 'Editor canonical exists; will redirect to ' . $final_slug;
            } elseif ($action === 'redirect_older_plugin') {
                $note = 'Newer plugin post wins; older post ' . $collision['older_post_id'] . ' will be redirected';
            } elseif ($action === 'redirect_older_editor') {
                $note = 'Newer plugin post wins; older editor post ' . $collision['older_post_id'] . ' will be redirected';
            } elseif ($action === 'become_canonical') {
                $note = 'Will become canonical clean slug';
            }

            $preview[] = [
                'post_id'      => $post_id,
                'title'        => $post->post_title,
                'old_slug'     => $post->post_name,
                'new_slug'     => $final_slug,
                'will_migrate' => true,
                'action'       => $action,
                'note'         => $note,
            ];
        }

        return [
            'total_versioned' => self::count_versioned_posts(),
            'preview'        => $preview,
        ];
    }

    /**
     * Run full migration with progress tracking and rollback support.
     * Processes ONE post per call. Call repeatedly until has_more=false.
     *
     * Architecture: stores the full list of post IDs at initialization so that
     * offset-based pagination remains correct even as migrated posts' slugs change
     * (causing them to disappear from the REGEXP query).
     *
     * @param int $batch_size Posts per call (default 1 to avoid gateway timeouts)
     * @return array Migration results with 'has_more' flag
     */
    public static function run_migration(int $batch_size = 1): array
    {
        // Load existing state or initialize
        $state = get_option(self::OPTION_MIGRATION_STATE, false);
        if (!$state || !isset($state['total']) || !isset($state['remaining_ids'])) {
            // First call - initialize with full ID list snapshot
            $all_ids = self::get_all_versioned_post_ids();
            $state = [
                'started_at'    => current_time('mysql'),
                'total'         => count($all_ids),
                'processed'     => 0,
                'succeeded'     => 0,
                'failed'        => 0,
                'errors'        => [],
                'rollback_data' => [],
                'remaining_ids' => $all_ids,
            ];
        }

        // [LOG] Migration started (only log on first call)
        if ($state['processed'] === 0) {
            $logger = \SEO_Article_Generator\Plugin::get_instance()->get_logger();
            if ($logger) {
                $logger->info('slug_migration_started', [
                    'total_posts'  => $state['total'],
                ]);
            }
        }

        // Take the next batch_size posts from the remaining IDs list
        $post_ids = array_slice($state['remaining_ids'], 0, $batch_size);
        $batch_details = [];

        if (!empty($post_ids)) {
            foreach ($post_ids as $post_id) {
                $result = self::migrate_slug($post_id);

                $state['processed']++;
                // Remove this ID from remaining regardless of success/failure
                array_shift($state['remaining_ids']);

                if ($result['success']) {
                    $state['succeeded']++;
                    // Store rollback data for primary post
                    $state['rollback_data'][] = [
                        'post_id'    => $post_id,
                        'old_slug'   => $result['old_slug'],
                        'new_slug'   => $result['new_slug'],
                        'redirect'   => $result['redirect_created'],
                    ];
                    // Store secondary rollback entries (older posts renamed during collision)
                    if (!empty($result['rollback_entries'])) {
                        foreach ($result['rollback_entries'] as $entry) {
                            $state['rollback_data'][] = $entry;
                        }
                    }
                } else {
                    $state['failed']++;
                    $state['errors'][] = [
                        'post_id' => $post_id,
                        'error'   => $result['error'],
                    ];
                }

                // Collect detail for response
                $batch_details[] = $result;
            }
        }

        // Determine if there are more posts to process
        $has_more = !empty($state['remaining_ids']);
        $state['has_more'] = $has_more;

        // If complete, finalize
        if (!$has_more) {
            $state['completed_at'] = current_time('mysql');

            // [LOG] Migration completed
            $logger = \SEO_Article_Generator\Plugin::get_instance()->get_logger();
            if ($logger) {
                $method = $state['failed'] > 0 ? 'warning' : 'info';
                $logger->$method('slug_migration_completed', [
                    'total_processed' => $state['processed'],
                    'succeeded'       => $state['succeeded'],
                    'failed'          => $state['failed'],
                    'duration_sec'    => strtotime($state['completed_at']) - strtotime($state['started_at']),
                ]);
            }
        }

        // Save rollback data after every batch (not just on completion)
        // so rollback works even if migration is stopped early.
        if (!empty($state['rollback_data'])) {
            $rollback = [
                'created_at' => current_time('mysql'),
                'data'       => $state['rollback_data'],
            ];
            update_option(self::OPTION_ROLLBACK_DATA, $rollback, false);
        }

        // Strip batch_details from state before persisting (prevent wp_options bloat)
        unset($state['batch_details']);
        update_option(self::OPTION_MIGRATION_STATE, $state, false);

        // Re-attach for the response only
        $state['batch_details'] = $batch_details;

        return $state;
    }

    /**
     * Get ALL versioned post IDs as a snapshot.
     * Used once at migration init so pagination stays correct as slugs change.
     *
     * @return array Array of post IDs
     */
    private static function get_all_versioned_post_ids(): array
    {
        global $wpdb;
        $table = $wpdb->posts;

        $query = $wpdb->prepare(
            "SELECT ID FROM {$table}
              WHERE post_type = 'post'
                AND post_status IN ('publish', 'draft', 'future')
                AND post_name REGEXP %s
              ORDER BY ID ASC",
            self::VERSIONED_SLUG_PATTERN_DB
        );

        $results = $wpdb->get_results($query, ARRAY_A);

        $ids = [];
        if (!empty($results)) {
            foreach ($results as $row) {
                $ids[] = (int) $row['ID'];
            }
        }

        return $ids;
    }

    /**
     * Rollback migration using stored rollback data.
     *
     * @return array Rollback results
     */
    public static function rollback_migration(): array
    {
        $rollback = get_option(self::OPTION_ROLLBACK_DATA, false);
        if (!$rollback || empty($rollback['data'])) {
            return ['success' => false, 'error' => 'No rollback data available'];
        }

        $results = [
            'success'    => true,
            'restored'   => 0,
            'failed'     => 0,
            'errors'     => [],
            'details'    => [],
        ];

        foreach ($rollback['data'] as $item) {
            $post_id = $item['post_id'];
            $old_slug = $item['old_slug'];
            $new_slug = $item['new_slug'];

            // Restore old slug
            $update = wp_update_post([
                'ID'        => $post_id,
                'post_name' => $old_slug,
            ], true);

            if (is_wp_error($update)) {
                $results['failed']++;
                $results['errors'][] = [
                    'post_id' => $post_id,
                    'error'   => $update->get_error_message(),
                ];
                $results['details'][] = [
                    'post_id' => $post_id,
                    'old_slug' => $old_slug,
                    'new_slug' => $new_slug,
                    'success'  => false,
                    'error'    => $update->get_error_message(),
                ];
                continue;
            }

            // Delete the redirect we created (source = old_slug, target = new_slug)
            self::delete_rankmath_redirect($old_slug);

            // Invalidate caches after slug restore
            self::invalidate_post_path_cache($post_id, $old_slug);

            $results['restored']++;
            $results['details'][] = [
                'post_id' => $post_id,
                'old_slug' => $old_slug,
                'new_slug' => $new_slug,
                'success'  => true,
            ];
        }

        // Clear migration state and rollback data
        delete_option(self::OPTION_MIGRATION_STATE);
        delete_option(self::OPTION_ROLLBACK_DATA);

        return $results;
    }

    /**
     * Get current migration state.
     *
     * Recomputes fresh stats from the database on every call so the
     * "Refresh Stats" button always returns current counts rather than
     * stale cached state from the last migration run.
     *
     * @return array
     */
    public static function get_migration_state(): array
    {
        // Fresh count of posts that still have versioned slugs.
        $total = self::count_versioned_posts();

        // Check rollback data for migrated/failed counts.
        $rollback = get_option(self::OPTION_ROLLBACK_DATA, false);
        $migrated = 0;
        $rollback_ready = false;
        if (is_array($rollback) && !empty($rollback['data'])) {
            $migrated = count($rollback['data']);
            $rollback_ready = true;
        }

        // Failed count comes from the migration state option.
        $state = get_option(self::OPTION_MIGRATION_STATE, false);
        $failed = 0;
        if (is_array($state) && isset($state['failed'])) {
            $failed = (int) $state['failed'];
        }

        // Link update state
        $link_state = self::get_link_update_state();

        return [
            'active'         => true,
            'total'          => $total,
            'processed'      => $migrated + $failed,
            'succeeded'      => $migrated,
            'failed'         => $failed,
            'link_update'    => $link_state,
            'rollback_ready' => $rollback_ready,
        ];
    }

    /**
     * Ensure new posts get clean slugs (no version).
     * Collision handling is delegated to the SELF HEAL/migration path.
     * Called during post creation.
     *
     * @param string $software_name
     * @return string Clean slug
     */
    public static function ensure_clean_slug_for_new_post(string $software_name): string
    {
        return self::generate_clean_slug($software_name);
    }

    /**
     * [COLLISION-FIX] Resolve a clean-slug collision against any existing post
     * occupying the target slug. Returns a deterministic action plan so the
     * caller can perform the right Rank Math 301 + wp_update_post sequence.
     *
     * Action matrix:
     *   'become_canonical'       — no conflict; current post takes the clean slug.
     *   'redirect_to_editor'     — existing post is non-plugin-owned (editor
     *                              canonical) AND newer than current. Current
     *                              versioned post must 301 to editor's slug.
     *   'redirect_older_plugin'  — existing post IS plugin-owned. Whichever of
     *                              the two has the LATER post_modified_gmt wins
     *                              the clean slug. The loser must be renamed
     *                              out of the way and 301'd to the winner.
     *   'redirect_older_editor'  — existing post is editor-owned but OLDER than
     *                              current plugin post. Editor post gets
     *                              renamed with -<post_id> suffix and 301'd to
     *                              current plugin post's clean slug.
     *
     * @param int    $post_id   Post being migrated.
     * @param string $new_slug  Target clean slug for the migrating post.
     * @return array{
     *   action: string,
     *   canonical_slug?: string,
     *   older_post_id?: int,
     *   older_old_slug?: string
     * }
     */
    public static function resolve_clean_slug_collision(int $post_id, string $new_slug): array
    {
        $existing = get_page_by_path($new_slug, OBJECT, 'post');
        if (!$existing || (int) $existing->ID === $post_id) {
            return ['action' => 'become_canonical'];
        }

        $existing_type = '';
        if (class_exists('\SEO_Article_Generator\Discovery\Post_Type_Classifier')) {
            $existing_type = \SEO_Article_Generator\Discovery\Post_Type_Classifier::classify((int) $existing->ID);
        }
        $existing_is_plugin = class_exists('\SEO_Article_Generator\Discovery\Post_Type_Classifier')
            && \SEO_Article_Generator\Discovery\Post_Type_Classifier::is_plugin_owned($existing_type);

        $current_modified = get_post_modified_time('U', true, $post_id);
        $existing_modified = get_post_modified_time('U', true, (int) $existing->ID);

        // NEW STRATEGY: Latest modified_gmt wins, regardless of ownership
        // Only exception: if timestamps are equal, prefer editor (legacy behavior)
        if ($current_modified >= $existing_modified) {
            // Current post is newer or equal - current wins
            if ($existing_is_plugin) {
                return [
                    'action'          => 'redirect_older_plugin',
                    'canonical_slug'  => $new_slug,
                    'older_post_id'   => (int) $existing->ID,
                    'older_old_slug'  => $existing->post_name,
                ];
            } else {
                // Existing is editor-owned but older - rename editor post
                return [
                    'action'          => 'redirect_older_editor',
                    'canonical_slug'  => $new_slug,
                    'older_post_id'   => (int) $existing->ID,
                    'older_old_slug'  => $existing->post_name,
                ];
            }
        } else {
            // Existing post is newer - existing wins
            if ($existing_is_plugin) {
                return [
                    'action'         => 'redirect_to_editor',
                    'canonical_slug' => $existing->post_name,
                    'note'           => 'Existing plugin post is newer; current redirects to it',
                ];
            } else {
                return [
                    'action'         => 'redirect_to_editor',
                    'canonical_slug' => $existing->post_name,
                    'note'           => 'Existing editor post is newer; current redirects to it',
                ];
            }
        }
    }

    /**
     * [CACHE-FIX] Invalidate every WP cache layer that keys off post slug so
     * the next get_page_by_path() in the same batch sees the renamed slug.
     * Without this, batch migrations suffix-rename slugs that aren't actually
     * colliding (stale cache) AND miss real collisions that just happened
     * earlier in the same batch.
     *
     * @param int    $post_id
     * @param string $old_slug
     * @return void
     */
    public static function invalidate_post_path_cache(int $post_id, string $old_slug): void
    {
        clean_post_cache($post_id);
        wp_cache_delete($old_slug, 'posts');
        wp_cache_delete('get_page_by_path_' . md5($old_slug), 'posts');
    }

    // ========================================================================
    // Internal Link Updater
    // ========================================================================

    /**
     * Option key for link update state tracking.
     */
    private const OPTION_LINK_UPDATE_STATE = 'seo_gen_link_update_state';

    /**
     * Option key for link update rollback data.
     */
    private const OPTION_LINK_UPDATE_ROLLBACK = 'seo_gen_link_update_rollback';

    /**
     * Build slug-to-slug mapping from rollback data.
     *
     * @return array<string,string> Map of old_slug => new_slug
     */
    public static function get_slug_mapping(): array
    {
        $mapping = [];

        $rollback = get_option(self::OPTION_ROLLBACK_DATA, false);
        if (!is_array($rollback) || empty($rollback['data'])) {
            return $mapping;
        }

        foreach ($rollback['data'] as $item) {
            if (empty($item['old_slug']) || empty($item['new_slug'])) {
                continue;
            }

            $old_slug = (string) $item['old_slug'];
            $new_slug = (string) $item['new_slug'];

            // Skip if slugs are identical (no change needed)
            if ($old_slug === $new_slug) {
                continue;
            }

            // Use the final target slug as key (handles collision cases)
            $mapping[$old_slug] = $new_slug;
        }

        // Sort by key length descending to prevent substring replacement issues
        // e.g. replace "whatsapp-2-22-5-72-for-android-2-2206-9-0-for-desktop" before "whatsapp"
        uksort($mapping, function ($a, $b) {
            return strlen($b) - strlen($a);
        });

        return $mapping;
    }

    /**
     * Get all posts that contain internal links to old versioned slugs.
     *
     * @param array $mapping Slug mapping (old => new)
     * @return array Array of post IDs that contain old slugs
     */
    public static function get_posts_with_old_links(array $mapping): array
    {
        global $wpdb;

        if (empty($mapping)) {
            return [];
        }

        $old_slugs = array_keys($mapping);
        if (empty($old_slugs)) {
            return [];
        }

        // Build WHERE clause for each slug
        $where_clauses = [];
        foreach ($old_slugs as $slug) {
            $where_clauses[] = $wpdb->prepare(
                "(post_content LIKE %s OR post_excerpt LIKE %s)",
                '%' . $wpdb->esc_like($slug) . '%',
                '%' . $wpdb->esc_like($slug) . '%'
            );
        }

        $where_sql = implode(' OR ', $where_clauses);

        $query = $wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts}
              WHERE post_type = 'post'
                AND post_status IN ('publish', 'draft', 'future')
                AND ({$where_sql})
              ORDER BY ID ASC"
        );

        // $where_sql is already prepared, so we need to restructure
        // Actually, let's use a different approach for safety
        return self::get_posts_with_old_links_safe($mapping);
    }

    /**
     * Safe implementation using multiple LIKE conditions.
     *
     * @param array $mapping
     * @return array
     */
    private static function get_posts_with_old_links_safe(array $mapping): array
    {
        global $wpdb;

        $all_ids = [];
        $old_slugs = array_keys($mapping);

        // Process in chunks to avoid overly long SQL
        $chunks = array_chunk($old_slugs, 50, true);

        foreach ($chunks as $chunk) {
            $like_clauses = [];
            $prepare_values = [];

            foreach ($chunk as $slug) {
                $like_clauses[] = "(post_content LIKE %s OR post_excerpt LIKE %s)";
                $like_values[] = '%' . $wpdb->esc_like($slug) . '%';
                $like_values[] = '%' . $wpdb->esc_like($slug) . '%';
            }

            $sql = "SELECT ID FROM {$wpdb->posts}
                    WHERE post_type = 'post'
                      AND post_status IN ('publish', 'draft', 'future')
                      AND (" . implode(' OR ', $like_clauses) . ")
                    ORDER BY ID ASC";

            $results = $wpdb->get_results($wpdb->prepare($sql, ...$like_values), ARRAY_A);

            if (!empty($results)) {
                foreach ($results as $row) {
                    $all_ids[(int) $row['ID']] = (int) $row['ID'];
                }
            }
        }

        return array_values($all_ids);
    }

    /**
     * Update internal links in a single post.
     *
     * @param int    $post_id  Post ID
     * @param array  $mapping  Slug mapping (old => new)
     * @return array Result with 'updated' boolean and 'count' of replacements
     */
    public static function update_post_internal_links(int $post_id, array $mapping): array
    {
        $result = [
            'post_id' => $post_id,
            'updated' => false,
            'count'   => 0,
        ];

        $post = get_post($post_id);
        if (!$post || $post->post_type !== 'post') {
            return $result;
        }

        $content = $post->post_content;
        $excerpt = $post->post_excerpt;

        $new_content = self::replace_slugs_in_text($content, $mapping);
        $new_excerpt = self::replace_slugs_in_text($excerpt, $mapping);

        $content_changed = ($new_content !== $content);
        $excerpt_changed = ($new_excerpt !== $excerpt);

        if (!$content_changed && !$excerpt_changed) {
            return $result;
        }

        // Store original content for rollback
        self::store_link_update_backup($post_id, $content, $excerpt);

        $update_data = [
            'ID' => $post_id,
        ];

        if ($content_changed) {
            $update_data['post_content'] = $new_content;
        }

        if ($excerpt_changed) {
            $update_data['post_excerpt'] = $new_excerpt;
        }

        $update_result = wp_update_post($update_data, true);

        if (is_wp_error($update_result)) {
            return $result;
        }

        $result['updated'] = true;
        $result['count'] = self::count_replacements($content, $new_content) + self::count_replacements($excerpt, $new_excerpt);

        // Clear caches
        clean_post_cache($post_id);

        return $result;
    }

    /**
     * Replace old slugs with new slugs in text content.
     *
     * Uses word boundaries to prevent partial slug matches.
     *
     * @param string $text    Original text
     * @param array  $mapping Slug mapping (old => new)
     * @return string Modified text
     */
    public static function replace_slugs_in_text(string $text, array $mapping): string
    {
        if (empty($mapping) || empty($text)) {
            return $text;
        }

        foreach ($mapping as $old_slug => $new_slug) {
            if ($old_slug === $new_slug) {
                continue;
            }

            // Escape old slug for regex
            $escaped_old = preg_quote($old_slug, '/');

            // Build regex with lookbehind/lookahead for word boundaries
            // Matches slug when preceded by: start of string, /, space, ", ', =, (, comma
            // Matches slug when followed by: end of string, /, space, ", ', ), !, ., ,, ;, :, ?, &, #, =
            $pattern = '/(?<=[\s"\'=(),]|^)' . $escaped_old . '(?=[\s"\'\)!.,;:?&#=]|$)/i';

            $new_text = preg_replace($pattern, $new_slug, $text, -1, $count);

            if ($new_text !== null && $count > 0) {
                $text = $new_text;
            }
        }

        return $text;
    }

    /**
     * Count replacements made between old and new text.
     *
     * @param string $old_text
     * @param string $new_text
     * @return int
     */
    private static function count_replacements(string $old_text, string $new_text): int
    {
        return abs(strlen($old_text) - strlen($new_text));
    }

    /**
     * Store original content for rollback.
     *
     * @param int    $post_id
     * @param string $content
     * @param string $excerpt
     * @return void
     */
    private static function store_link_update_backup(int $post_id, string $content, string $excerpt): void
    {
        $backups = get_option(self::OPTION_LINK_UPDATE_ROLLBACK, []);

        // Only store first backup (original content)
        if (!isset($backups[$post_id])) {
            $backups[$post_id] = [
                'content' => $content,
                'excerpt' => $excerpt,
                'time'    => current_time('mysql'),
            ];
            update_option(self::OPTION_LINK_UPDATE_ROLLBACK, $backups, false);
        }
    }

    /**
     * Run internal links update — processes one post per call.
     *
     * @return array Result with 'has_more', 'processed', 'updated', 'total'
     */
    public static function run_link_update(): array
    {
        $state = get_option(self::OPTION_LINK_UPDATE_STATE, false);

        if (!$state || !isset($state['remaining_ids'])) {
            // Initialize
            $mapping = self::get_slug_mapping();
            if (empty($mapping)) {
                return [
                    'active'    => false,
                    'total'     => 0,
                    'processed' => 0,
                    'updated'   => 0,
                    'has_more'  => false,
                    'message'   => 'No slug mapping found. Run migration first.',
                ];
            }

            $post_ids = self::get_posts_with_old_links_safe($mapping);

            $state = [
                'started_at'     => current_time('mysql'),
                'total'          => count($post_ids),
                'processed'      => 0,
                'updated'        => 0,
                'remaining_ids'  => $post_ids,
                'mapping'        => $mapping,
            ];
        }

        $mapping = $state['mapping'];

        // Process one post
        $post_id = array_shift($state['remaining_ids']);

        $update_result = [
            'post_id' => $post_id,
            'updated' => false,
            'count'   => 0,
        ];

        if ($post_id) {
            $update_result = self::update_post_internal_links($post_id, $mapping);
            $state['processed']++;

            if ($update_result['updated']) {
                $state['updated']++;
            }
        }

        $has_more = !empty($state['remaining_ids']);
        $state['has_more'] = $has_more;

        if (!$has_more) {
            $state['completed_at'] = current_time('mysql');
        }

        // Strip mapping from state before persisting (prevent bloat)
        unset($state['mapping']);
        update_option(self::OPTION_LINK_UPDATE_STATE, $state, false);

        // Re-attach for response
        $state['mapping'] = $mapping;
        $state['active'] = true;
        $state['last_result'] = $update_result;

        return $state;
    }

    /**
     * Rollback link updates to original content.
     *
     * @return array Rollback results
     */
    public static function rollback_link_updates(): array
    {
        $backups = get_option(self::OPTION_LINK_UPDATE_ROLLBACK, false);

        if (!is_array($backups) || empty($backups)) {
            return ['success' => false, 'message' => 'No backup data available'];
        }

        $results = [
            'success'  => true,
            'restored' => 0,
            'failed'   => 0,
        ];

        foreach ($backups as $post_id => $backup) {
            $update_data = [
                'ID'           => $post_id,
                'post_content' => $backup['content'],
                'post_excerpt' => $backup['excerpt'],
            ];

            $update_result = wp_update_post($update_data, true);

            if (is_wp_error($update_result)) {
                $results['failed']++;
            } else {
                $results['restored']++;
                clean_post_cache($post_id);
            }
        }

        // Clear state and backups
        delete_option(self::OPTION_LINK_UPDATE_STATE);
        delete_option(self::OPTION_LINK_UPDATE_ROLLBACK);

        return $results;
    }

    /**
     * Get link update state for refresh stats.
     *
     * @return array
     */
    public static function get_link_update_state(): array
    {
        $state = get_option(self::OPTION_LINK_UPDATE_STATE, false);

        if (!$state) {
            // Check if there's mapping available
            $mapping = self::get_slug_mapping();
            return [
                'active'      => false,
                'total'       => 0,
                'processed'   => 0,
                'updated'     => 0,
                'has_mapping' => !empty($mapping),
            ];
        }

        return [
            'active'    => true,
            'total'     => $state['total'] ?? 0,
            'processed' => $state['processed'] ?? 0,
            'updated'   => $state['updated'] ?? 0,
            'has_more'  => $state['has_more'] ?? false,
        ];
    }
}