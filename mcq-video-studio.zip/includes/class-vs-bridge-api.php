<?php

/**
 * REST Bridge API
 *
 * Exposes the VS MCQ Bank to the Video Studio JS frontend.
 * Secure, fast, and read-optimized.
 *
 * @package MCQ_Video_Studio
 */

if (! defined('ABSPATH')) {
 exit;
}

class VS_Bridge_API
{

 private static $instance = null;
 private static $namespace = 'mcq-video-studio/v1';

 public static function init()
 {
 if (null === self::$instance) {
 self::$instance = new self();
 }
 return self::$instance;
 }

 private function __construct()
 {
 add_action('rest_api_init', array($this, 'register_routes'));
 }

 public function register_routes()
 {
 register_rest_route(
 self::$namespace,
 '/bank/questions',
 array(
 'methods' => 'GET',
 'callback' => array($this, 'get_questions'),
 'permission_callback' => array($this, 'check_permission'),
 'args' => array(
 'topic_id' => array(
 'validate_callback' => function ($param) {
 return is_numeric($param);
 }
 ),
 'limit' => array(
 'default' => 20,
 'validate_callback' => function ($param) {
 return is_numeric($param);
 }
 )
 )
 )
 );

 register_rest_route(
 self::$namespace,
 '/bank/generate',
 array(
 'methods' => 'POST',
 'callback' => array($this, 'trigger_generation'),
 'permission_callback' => array($this, 'check_permission'),
 )
 );
 }

 public function check_permission()
 {
 return current_user_can('edit_posts');
 }

 public function get_questions($request)
 {
 if (! class_exists('VS_MCQ_Repository')) {
 return new WP_Error('system_error', 'Repository class missing');
 }

 $repo = new VS_MCQ_Repository();
 $args = array(
 'topic_id' => $request->get_param('topic_id'),
 'limit' => $request->get_param('limit'),
 'status' => 'approved'
 );

 $results = $repo->find($args);
 return rest_ensure_response($results);
 }

 public function trigger_generation($request)
 {
 if (! function_exists('as_schedule_single_action')) {
 return new WP_Error('missing_dependency', 'Action Scheduler not active.');
 }

 $topic_id = $request->get_param('topic_id');
 $count = $request->get_param('count') ?: 5;

 if (empty($topic_id)) {
 return new WP_Error('missing_param', 'Topic ID required');
 }

 $batch_id = uniqid('vs_gen_');

 as_schedule_single_action(
 time(),
 'vs_generate_mcq_batch',
 array($topic_id, $count, $batch_id),
 'mcq-video-studio'
 );

 return rest_ensure_response(array(
 'success' => true,
 'message' => 'Generation scheduled',
 'batch_id' => $batch_id
 ));
 }
}

// @BACKWARD-COMPAT: Alias for legacy class name used in init sequence
if (!class_exists('VS_Video_Studio_Bridge')) {
 class VS_Video_Studio_Bridge extends VS_Bridge_API {}
}
