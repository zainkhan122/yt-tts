<?php
/**
 * Template Preview Generator - GD Version
 * Generates accurate PNG previews matching each template's layout
 * Uses placeholder images, brand bar, category badge, and sample text
 * Works on any platform with PHP GD extension
 */

define('ABSPATH', true);
define('AI_SOCIAL_COLLAGE_PATH', dirname(__DIR__) . '/');

require_once AI_SOCIAL_COLLAGE_PATH . 'core/Config.php';

use AiSocialCollage\Config;

class GdPreviewGenerator {

    private $preview_dir;
    private $width = 540;
    private $height = 675;

    // Brand defaults (mirrors Config defaults for standalone CLI use)
    private $brand_name  = 'NewsBrand';
    private $brand_url   = 'www.newsbrand.com';
    private $accent_hex  = '#FF1744';
    private $text_hex    = '#FFFFFF';
    private $secondary_hex = '#CCCCCC';
    private $backing_hex = '#000000';

    public function __construct() {
        $this->preview_dir = AI_SOCIAL_COLLAGE_PATH . 'assets/img/previews/';
        if (!is_dir($this->preview_dir)) {
            mkdir($this->preview_dir, 0755, true);
        }
    }

    // ── Color helpers ──────────────────────────────────────────────────────

    private function color($img, $r, $g, $b, $alpha = 0) {
        $alpha = min(127, max(0, intval($alpha)));
        return imagecolorallocatealpha($img, $r, $g, $b, $alpha);
    }

    private function hex_to_rgb($hex) {
        $hex = ltrim($hex, '#');
        if (strlen($hex) === 3) {
            $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
        return [
            hexdec(substr($hex, 0, 2)),
            hexdec(substr($hex, 2, 2)),
            hexdec(substr($hex, 4, 2)),
        ];
        }
        return [
            hexdec(substr($hex, 0, 2)),
            hexdec(substr($hex, 2, 2)),
            hexdec(substr($hex, 4, 2)),
        ];
    }

    private function hex_color($img, $hex, $alpha = 0) {
        $rgb = $this->hex_to_rgb($hex);
        return $this->color($img, $rgb[0], $rgb[1], $rgb[2], $alpha);
    }

    // ── Font helper ────────────────────────────────────────────────────────

    private function get_font_path() {
        $font_paths = [
            AI_SOCIAL_COLLAGE_PATH . 'assets/fonts/NotoNastaliqUrdu-Regular.ttf',
            AI_SOCIAL_COLLAGE_PATH . 'assets/fonts/NotoSansArabic-Regular.ttf',
            'C:\Windows\Fonts\arial.ttf',
            'C:\Windows\Fonts\verdana.ttf',
        ];
        foreach ($font_paths as $path) {
            if (file_exists($path)) {
                return $path;
            }
        }
        $system_fonts = glob('C:\Windows\Fonts\*.ttf');
        if (!empty($system_fonts)) {
            return $system_fonts[0];
        }
        return null;
    }

    // ── Drawing helpers ────────────────────────────────────────────────────

    private function draw_gradient_rect($img, $x, $y, $w, $h, $color1, $color2) {
        for ($i = 0; $i < $h; $i++) {
            $ratio = ($h > 1) ? ($i / ($h - 1)) : 0;
            $r = intval($color1[0] + ($color2[0] - $color1[0]) * $ratio);
            $g = intval($color1[1] + ($color2[1] - $color1[1]) * $ratio);
            $b = intval($color1[2] + ($color2[2] - $color1[2]) * $ratio);
            $color = $this->color($img, $r, $g, $b);
            imageline($img, $x, $y + $i, $x + $w - 1, $y + $i, $color);
        }
    }

    /**
     * Draw a placeholder "photo" — a gradient rectangle with a simple
     * landscape silhouette so it looks like a real image, not a black box.
     */
    private function draw_placeholder_photo($img, $x, $y, $w, $h, $hue_shift = 0) {
        // Base gradient (sky-like)
        $top_r = 60 + $hue_shift;  $top_g = 80 + $hue_shift;  $top_b = 140 + $hue_shift;
        $bot_r = 30 + $hue_shift;  $bot_g = 40 + $hue_shift;   $bot_b = 70 + $hue_shift;
        $this->draw_gradient_rect($img, $x, $y, $w, $h, [$top_r, $top_g, $top_b], [$bot_r, $bot_g, $bot_b]);

        // Simple "mountain" silhouette
        $sil_color = $this->color($img, 20, 25, 40);
        $mid_y = $y + intval($h * 0.65);
        $peak1_x = $x + intval($w * 0.3);
        $peak1_y = $y + intval($h * 0.35);
        $peak2_x = $x + intval($w * 0.7);
        $peak2_y = $y + intval($h * 0.45);
        $base_y  = $y + $h;

        // Left mountain
        for ($py = $peak1_y; $py < $base_y; $py++) {
            $progress = ($py - $peak1_y) / ($base_y - $peak1_y);
            $left_x  = $x + intval($w * 0.05 * (1 - $progress));
            $right_x = $peak1_x + intval(($w * 0.15) * $progress);
            imageline($img, max($x, $left_x), $py, min($x + $w, $right_x), $py, $sil_color);
        }
        // Right mountain
        for ($py = $peak2_y; $py < $base_y; $py++) {
            $progress = ($py - $peak2_y) / ($base_y - $peak2_y);
            $left_x  = $peak2_x - intval(($w * 0.15) * $progress);
            $right_x = $x + $w - intval($w * 0.05 * (1 - $progress));
            imageline($img, max($x, $left_x), $py, min($x + $w, $right_x), $py, $sil_color);
        }

        // Subtle "sun" circle
        $sun_x = $x + intval($w * 0.75);
        $sun_y = $y + intval($h * 0.25);
        $sun_r = intval(min($w, $h) * 0.08);
        $sun_color = $this->color($img, 255, 200, 100, 60);
        imagefilledellipse($img, $sun_x, $sun_y, $sun_r * 2, $sun_r * 2, $sun_color);
    }

    /**
     * Draw the brand bar at the bottom of the card.
     */
    private function draw_brand_bar($img, $y_start) {
        $w = $this->width;
        $h = $this->height;
        $bar_h = 44;
        $bar_y = $y_start;

        // Bar background
        imagefilledrectangle($img, 0, $bar_y, $w, $bar_y + $bar_h, $this->hex_color($img, $this->backing_hex));
        // Subtle top border
        $border_color = $this->hex_color($img, $this->accent_hex, 80);
        imageline($img, 0, $bar_y, $w, $bar_y, $border_color);

        $font = $this->get_font_path();
        $accent = $this->hex_color($img, $this->accent_hex);
        $text_c = $this->hex_color($img, $this->text_hex);

        // Logo placeholder (small rounded rect)
        $logo_x = 16;
        $logo_y = $bar_y + 10;
        $logo_w = 40;
        $logo_h = 24;
        $logo_bg = $this->color($img, 255, 255, 255, 40);
        imagefilledrectangle($img, $logo_x, $logo_y, $logo_x + $logo_w, $logo_y + $logo_h, $logo_bg);
        // Small "N" inside logo box
        if ($font) {
            imagettftext($img, 12, 0, $logo_x + 10, $logo_y + 18, $accent, $font, 'N');
        }

        // Brand name
        if ($font) {
            imagettftext($img, 11, 0, $logo_x + $logo_w + 10, $bar_y + 26, $text_c, $font, $this->brand_name);
        }

        // Brand URL (right-aligned)
        if ($font) {
            $bbox = imagettftext($img, 9, 0, 0, 0, $accent, $font, $this->brand_url);
            $text_w = $bbox[2] - $bbox[0];
            imagettftext($img, 9, 0, $w - $text_w - 16, $bar_y + 26, $accent, $font, $this->brand_url);
        }
    }

    /**
     * Draw a category badge.
     */
    private function draw_category_badge($img, $x, $y, $label) {
        $font = $this->get_font_path();
        if (!$font) return;

        $accent = $this->hex_color($img, $this->accent_hex);
        $text_c = $this->hex_color($img, '#FFFFFF');

        $bbox = imagettftext($img, 10, 0, 0, 0, $text_c, $font, $label);
        $text_w = $bbox[2] - $bbox[0];
        $text_h = $bbox[1] - $bbox[7];

        $pad_x = 12;
        $pad_y = 6;
        $badge_w = $text_w + $pad_x * 2;
        $badge_h = $text_h + $pad_y * 2;

        // Rounded-ish badge (just a filled rect)
        imagefilledrectangle($img, $x, $y, $x + $badge_w, $y + $badge_h, $accent);

        imagettftext($img, 10, 0, $x + $pad_x, $y + $pad_y + $text_h, $text_c, $font, $label);
    }

    // ── Template: news-card ────────────────────────────────────────────────

    private function draw_news_card($img) {
        $w = $this->width;
        $h = $this->height;
        $font = $this->get_font_path();

        $accent    = $this->hex_color($img, $this->accent_hex);
        $text_c    = $this->hex_color($img, $this->text_hex);
        $secondary = $this->hex_color($img, $this->secondary_hex, 200);
        $backing   = $this->hex_color($img, $this->backing_hex);

        // Photo area (top 58%)
        $photo_h = intval($h * 0.58);
        $this->draw_placeholder_photo($img, 0, 0, $w, $photo_h, 0);

        // Gradient overlay from photo to content
        $overlay_top = intval($h * 0.43);
        for ($y = $overlay_top; $y < $photo_h; $y++) {
            $progress = ($y - $overlay_top) / ($photo_h - $overlay_top);
            $alpha = intval($progress * 180);
            $c = $this->color($img, 0, 0, 0, $alpha);
            imageline($img, 0, $y, $w, $y, $c);
        }

        // Content block (bottom 42%)
        $content_y = $photo_h;
        imagefilledrectangle($img, 0, $content_y, $w, $h, $backing);

        // Category badge
        $badge_y = $content_y + 18;
        $this->draw_category_badge($img, 24, $badge_y, 'BREAKING');

        // Headline
        $headline_y = $badge_y + 36;
        if ($font) {
            imagettftext($img, 26, 0, 24, $headline_y, $text_c, $font, 'BIG NEWS HEADLINE');
            imagettftext($img, 14, 0, 24, $headline_y + 32, $secondary, $font, 'Sample hook description goes here');
        }

        // Brand bar at bottom
        $this->draw_brand_bar($img, $h - 44);
    }

    // ── Template: dual-photo ───────────────────────────────────────────────

    private function draw_dual_photo($img) {
        $w = $this->width;
        $h = $this->height;
        $font = $this->get_font_path();

        $accent    = $this->hex_color($img, $this->accent_hex);
        $text_c    = $this->hex_color($img, $this->text_hex);
        $secondary = $this->hex_color($img, $this->secondary_hex, 200);
        $backing   = $this->hex_color($img, $this->backing_hex);

        $photo_h = intval($h * 0.52);
        $half_w  = intval($w / 2);
        $gap     = 3;

        // Left photo
        $this->draw_placeholder_photo($img, 0, 0, $half_w - $gap, $photo_h, -20);
        // Right photo
        $this->draw_placeholder_photo($img, $half_w + $gap, 0, $half_w - $gap, $photo_h, 30);

        // Divider line
        imagefilledrectangle($img, $half_w - 1, 0, $half_w + 1, $photo_h, $this->color($img, 0, 0, 0));

        // Photo labels
        if ($font) {
            // Label backgrounds
            $label_bg = $this->color($img, 0, 0, 0, 40);
            // Left label
            imagefilledrectangle($img, $half_w - $gap - 80, $photo_h - 30, $half_w - $gap - 4, $photo_h - 8, $label_bg);
            imagettftext($img, 10, 0, $half_w - $gap - 76, $photo_h - 12, $text_c, $font, 'PHOTO 1');
            // Right label
            imagefilledrectangle($img, $half_w + $gap + 4, $photo_h - 30, $half_w + $gap + 80, $photo_h - 8, $label_bg);
            imagettftext($img, 10, 0, $half_w + $gap + 8, $photo_h - 12, $text_c, $font, 'PHOTO 2');
        }

        // Gradient overlay
        $overlay_top = intval($h * 0.42);
        for ($y = $overlay_top; $y < $photo_h; $y++) {
            $progress = ($y - $overlay_top) / ($photo_h - $overlay_top);
            $alpha = intval($progress * 180);
            $c = $this->color($img, 0, 0, 0, $alpha);
            imageline($img, 0, $y, $w, $y, $c);
        }

        // Content block
        imagefilledrectangle($img, 0, $photo_h, $w, $h, $backing);

        // Category badge
        $badge_y = $photo_h + 18;
        $this->draw_category_badge($img, 24, $badge_y, 'COMPARISON');

        // Headline
        if ($font) {
            imagettftext($img, 24, 0, 24, $badge_y + 36, $text_c, $font, 'BIG NEWS HEADLINE');
            imagettftext($img, 13, 0, 24, $badge_y + 66, $secondary, $font, 'Sample hook description');
        }

        // Brand bar
        $this->draw_brand_bar($img, $h - 44);
    }

    // ── Template: text-heavy ────────────────────────────────────────────────

    private function draw_text_heavy($img) {
        $w = $this->width;
        $h = $this->height;
        $font = $this->get_font_path();

        $accent    = $this->hex_color($img, $this->accent_hex);
        $text_c    = $this->hex_color($img, $this->text_hex);
        $backing   = $this->hex_color($img, $this->backing_hex);

        // Small photo strip (top 30%)
        $photo_h = intval($h * 0.30);
        $this->draw_placeholder_photo($img, 0, 0, $w, $photo_h, 50);

        // Gradient overlay
        $overlay_top = intval($h * 0.20);
        for ($y = $overlay_top; $y < $photo_h; $y++) {
            $progress = ($y - $overlay_top) / ($photo_h - $overlay_top);
            $alpha = intval($progress * 200);
            $c = $this->color($img, 0, 0, 0, $alpha);
            imageline($img, 0, $y, $w, $y, $c);
        }

        // Content block (bottom 70%)
        imagefilledrectangle($img, 0, $photo_h, $w, $h, $backing);

        // Quote mark
        if ($font) {
            $quote_color = $this->hex_color($img, $this->accent_hex, 70);
            imagettftext($img, 48, 0, intval($w / 2) - 10, $photo_h + 55, $quote_color, $font, '"');
        }

        // Headline / quote text
        $text_y = $photo_h + 85;
        if ($font) {
            imagettftext($img, 24, 0, 30, $text_y, $text_c, $font, 'QUOTE OR STATEMENT');
            imagettftext($img, 24, 0, 30, $text_y + 36, $text_c, $font, 'GOES HERE IN BOLD');
        }

        // Attribution
        $attr_y = $text_y + 72;
        if ($font) {
            imagettftext($img, 14, 0, 30, $attr_y, $accent, $font, '— Attribution Source');
        }

        // Brand bar
        $this->draw_brand_bar($img, $h - 44);
    }

    // ── Main generator ─────────────────────────────────────────────────────

    public function generate_preview($template_key) {
        $img = imagecreatetruecolor($this->width, $this->height);
        imagealphablending($img, true);
        imagesavealpha($img, true);

        // Transparent background (will be filled by draw methods)
        $transparent = $this->color($img, 0, 0, 0, 127);
        imagefill($img, 0, 0, $transparent);

        switch ($template_key) {
            case 'news-card':
                $this->draw_news_card($img);
                break;
            case 'dual-photo':
                $this->draw_dual_photo($img);
                break;
            case 'text-heavy':
                $this->draw_text_heavy($img);
                break;
        }

        $output_path = $this->preview_dir . $template_key . '.png';
        if (imagepng($img, $output_path)) {
            imagedestroy($img);
            echo "Generated: $template_key.png\n";
            return true;
        }

        imagedestroy($img);
        echo "Failed: $template_key\n";
        return false;
    }

    public function generate_all() {
        if (!extension_loaded('gd')) {
            echo "GD extension is not loaded. Please enable it in php.ini\n";
            return false;
        }

        $templates = Config::get_templates();
        $success = 0;
        $failed = 0;

        foreach ($templates as $template_key => $template_label) {
            if ($template_key === 'auto') continue;

            if ($this->generate_preview($template_key)) {
                $success++;
            } else {
                $failed++;
            }
        }

        echo "\n=== Preview Generation Complete ===\n";
        echo "Success: $success\n";
        echo "Failed: $failed\n";

        return $failed === 0;
    }
}

$generator = new GdPreviewGenerator();
$generator->generate_all();
