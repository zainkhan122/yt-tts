/**
 * Hero Meta Box JavaScript
 * @MODIFIED 2025-12-04 v1.4.0: Repeater field for download links
 * @MODIFIED 2025-12-14 v2.1.0: WordPress media picker for logo upload
 *
 * @package SEO_Article_Generator
 */

(function ($) {
  "use strict";

  var HeroMetaBox = {
    linkIndex: 0,
    mediaFrame: null,

    init: function () {
      this.bindEvents();
      this.setInitialIndex();
      // @MODIFIED 2026-01-07: Initialize Sortable
      this.initSortable();
    },

    bindEvents: function () {
      // Add new link row
      $(document).on(
        "click",
        "#seo-gen-add-hero-link",
        this.addLinkRow.bind(this)
      );

      // Remove link row
      $(document).on(
        "click",
        ".seo-gen-remove-hero-link",
        this.removeLinkRow.bind(this)
      );

      // Ensure only one primary checkbox
      $(document).on(
        "change",
        '.seo-gen-primary-checkbox',
        this.handlePrimaryChange.bind(this)
      );

      // @MODIFIED 2025-12-14 v2.1.0: Logo picker events
      $(document).on(
        "click",
        "#seo-gen-select-logo",
        this.openMediaPicker.bind(this)
      );
      $(document).on(
        "click",
        "#seo-gen-remove-logo",
        this.removeLogo.bind(this)
      );

      // @MODIFIED 2025-12-24 v2.6.1: Direct URL input for images not in media library
      $(document).on(
        "click",
        "#seo-gen-apply-logo-url",
        this.applyLogoUrl.bind(this)
      );
      $(document).on(
        "keypress",
        "#hero_logo_url_direct",
        this.handleUrlKeypress.bind(this)
      );
    },

    // @MODIFIED 2026-01-07: Initialize jQuery UI Sortable
    initSortable: function () {
      var self = this;
      var container = $("#seo-gen-hero-links-container");
      if (container.length && $.fn.sortable) {
        container.sortable({
          handle: ".seo-gen-drag-handle",
          placeholder: "seo-gen-sortable-placeholder",
          axis: "y",
          opacity: 0.7,
          update: function (event, ui) {
            // @MODIFIED 2026-01-07: Renumber indices after sorting
            self.updateIndices();
          }
        });
      }
    },

    updateIndices: function () {
      // Iterate over each row and update input names to be sequential (0, 1, 2...)
      $("#seo-gen-hero-links-container .seo-gen-hero-link-row").each(function (divIndex, element) {
        var row = $(element);
        var newIndex = divIndex; // 0-based index

        row.attr("data-index", newIndex);

        // Update name attributes for inputs
        row.find("input, select, textarea").each(function () {
          var input = $(this);
          var name = input.attr("name");
          if (name) {
            // Regex to replace the index inside hero_links[ OLD_INDEX ][ field ]
            // Handles both hero_links[0][field] and hero_links[][field]
            var newName = name.replace(/hero_links\[.*?\]\[/, "hero_links[" + newIndex + "][");
            input.attr("name", newName);
          }
        });
      });
    },

    setInitialIndex: function () {
      var existingRows = $(".seo-gen-hero-link-row");
      if (existingRows.length > 0) {
        var lastIndex = existingRows.last().data("index");
        this.linkIndex = parseInt(lastIndex) + 1;
      }
    },

    addLinkRow: function (e) {
      e.preventDefault();

      var template = $("#seo-gen-hero-link-template").html();

      // Use a placeholder index initially, then re-index immediately
      var newRow = template.replace(/\{\{INDEX\}\}/g, "9999");

      $("#seo-gen-hero-links-container").append(newRow);

      // @MODIFIED 2026-01-07: Refresh sortable
      $("#seo-gen-hero-links-container").sortable("refresh");

      this.updateIndices();
    },

    removeLinkRow: function (e) {
      e.preventDefault();
      var self = this;
      var row = $(e.currentTarget).closest(".seo-gen-hero-link-row");
      row.fadeOut(300, function () {
        $(this).remove();
        self.updateIndices();
      });
    },

    handlePrimaryChange: function (e) {
      var checkbox = $(e.currentTarget);
      var isChecked = checkbox.is(":checked");

      // Sync to hidden input
      checkbox.siblings('.seo-gen-primary-hidden').val(isChecked ? '1' : '0');

      if (isChecked) {
        // Uncheck all other primary checkboxes
        // @MODIFIED 2026-01-07: Updated selector class
        $('.seo-gen-primary-checkbox')
          .not(checkbox)
          .prop("checked", false)
          .siblings('.seo-gen-primary-hidden')
          .val('0');
      }
    },

    /**
     * Open WordPress media picker for logo selection
     * @MODIFIED 2025-12-14 v2.1.0: New method for App Store style logo
     */
    openMediaPicker: function (e) {
      e.preventDefault();

      var self = this;

      // Create media frame if it doesn't exist
      if (!this.mediaFrame) {
        this.mediaFrame = wp.media({
          title: "Select Software Logo",
          button: {
            text: "Use as Logo",
          },
          multiple: false,
          library: {
            type: "image",
          },
        });

        // When an image is selected
        this.mediaFrame.on("select", function () {
          var attachment = self.mediaFrame
            .state()
            .get("selection")
            .first()
            .toJSON();

          // Get thumbnail URL (prefer medium size if available)
          var imageUrl =
            attachment.sizes && attachment.sizes.thumbnail
              ? attachment.sizes.thumbnail.url
              : attachment.url;

          // Update hidden input with full URL
          $("#hero_logo_url").val(attachment.url);

          // @MODIFIED 2025-12-24 v2.6.1: Sync direct URL input
          $("#hero_logo_url_direct").val(attachment.url);

          // Update preview
          $("#hero_logo_preview").html(
            '<img src="' + imageUrl + '" alt="Logo">'
          );

          // Show remove button
          $("#seo-gen-remove-logo").show();
        });
      }

      // Open the media picker
      this.mediaFrame.open();
    },

    /**
     * Remove the currently selected logo
     * @MODIFIED 2025-12-14 v2.1.0: New method
     */
    removeLogo: function (e) {
      e.preventDefault();

      // Clear hidden input
      $("#hero_logo_url").val("");

      // Clear direct URL input
      $("#hero_logo_url_direct").val("");

      // Reset preview
      $("#hero_logo_preview").html(
        '<span class="seo-gen-logo-placeholder">No Logo</span>'
      );

      // Hide remove button
      $("#seo-gen-remove-logo").hide();
    },

    /**
     * Apply logo from directly pasted URL
     * @MODIFIED 2025-12-24 v2.6.1: Support images in uploads folder not in media library
     */
    applyLogoUrl: function (e) {
      e.preventDefault();

      var url = $("#hero_logo_url_direct").val().trim();

      if (!url) {
        alert("Please enter a valid image URL");
        return;
      }

      // Basic URL validation
      if (
        !url.match(/^https?:\/\/.+\.(jpg|jpeg|png|gif|webp|svg|ico)(\?.*)?$/i)
      ) {
        if (!confirm("The URL doesn't appear to be an image. Apply anyway?")) {
          return;
        }
      }

      // Update hidden input
      $("#hero_logo_url").val(url);

      // Update preview with loading state first
      $("#hero_logo_preview").html(
        '<span class="seo-gen-logo-placeholder">Loading...</span>'
      );

      // Create image to test if it loads
      var testImg = new Image();
      testImg.onload = function () {
        $("#hero_logo_preview").html('<img src="' + url + '" alt="Logo">');
        $("#seo-gen-remove-logo").show();
      };
      testImg.onerror = function () {
        $("#hero_logo_preview").html(
          '<img src="' + url + '" alt="Logo" style="opacity:0.5">'
        );
        $("#seo-gen-remove-logo").show();
        // Still apply - maybe it will work on page load
      };
      testImg.src = url;
    },

    /**
     * Handle Enter key in URL input
     * @MODIFIED 2025-12-24 v2.6.1: Convenience for applying URL with Enter
     */
    handleUrlKeypress: function (e) {
      if (e.which === 13) {
        e.preventDefault();
        this.applyLogoUrl(e);
      }
    },
  };

  $(document).ready(function () {
    HeroMetaBox.init();
  });
})(jQuery);
