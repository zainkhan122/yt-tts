<?php

namespace DIT\TrendStudio\Content;

use DIT\TrendStudio\DTO\GenerationRequestDTO;

/**
 * Build a structured prompt array from a GenerationRequestDTO.
 *
 * The prompt builder centralises the logic for mapping request
 * parameters and the selected blueprint into the array expected by
 * PromptEngine. By using a DTO as input, it becomes simpler to
 * validate and manipulate the request before construction. This
 * class can be extended in future to support dynamic filtering or
 * external template overrides.
 */
class PromptBuilder
{
    /**
     * Build the structured prompt data from a GenerationRequestDTO.
     *
     * @param GenerationRequestDTO $request Input request DTO containing all user-provided fields
     * @return array Structured array ready to be passed to PromptEngine
     */
    public static function buildPrompt(GenerationRequestDTO $request): array
    {
        // Determine search intent with fallback
        $search_intent = $request->searchIntent ?: 'mixed';

        // Determine vertical: use provided value or fallback to plugin option
        $vertical = $request->vertical;
        if (empty($vertical)) {
            // Use WordPress get_option only if defined; fallback to default showbiz
            if (function_exists('get_option')) {
                $vertical = get_option('dit_ts_content_vertical', 'showbiz');
            } else {
                $vertical = 'showbiz';
            }
        }

        // Retrieve the blueprint for this intent and vertical
        $blueprint = PromptBlueprint::getBlueprint($search_intent, $vertical);

        // compose the visual assets list if map is provided
        $visual_assets = '';
        if (!empty($request->sourceVisualMap)) {
            $lines = [];
            foreach ($request->sourceVisualMap as $token => $data) {
                // @MODIFIED 2026-02-15 - Extract ID from [VISUAL_N] or legacy [SOURCE_VISUAL_N]
                $visual_id = str_replace(['[SOURCE_VISUAL_', '[VISUAL_', ']'], '', $token);
                $url = (string) ($data['url'] ?? '');
                $path = $url !== '' ? (string) (parse_url($url, PHP_URL_PATH) ?: '') : '';
                $filename = $path !== '' ? basename($path) : '';
                $alt = trim((string) ($data['alt'] ?? ''));
                $type = (string) ($data['type'] ?? 'visual');

                $desc = $alt !== '' ? $alt : ($filename !== '' ? $filename : ('Visual ' . $visual_id));
                if ($filename !== '' && stripos($desc, $filename) === false) {
                    $desc .= " (file: {$filename})";
                }

                $heading     = trim((string) ($data['heading'] ?? ''));
                $context     = trim((string) ($data['context'] ?? ''));
                $preceding_p = trim((string) ($data['preceding_p'] ?? ''));

                // Keep prompt lean: short excerpts only
                // @MODIFIED 2026-05-06 - Include preceding_p (the paragraph immediately before the image)
                // which most precisely describes the dress in Pakistani fashion sale posts.
                $detail = '';
                if ($preceding_p !== '') {
                    $preceding_p = preg_replace('/\s+/', ' ', wp_strip_all_tags($preceding_p));
                    if (strlen($preceding_p) > 130) {
                        $preceding_p = substr($preceding_p, 0, 130);
                    }
                    $detail = $preceding_p;
                } elseif ($context !== '') {
                    $context = preg_replace('/\s+/', ' ', wp_strip_all_tags($context));
                    if (strlen($context) > 130) {
                        $context = substr($context, 0, 130);
                    }
                    $detail = $context;
                }

                if ($heading !== '') {
                    $heading = preg_replace('/\s+/', ' ', wp_strip_all_tags($heading));
                    if (strlen($heading) > 80) {
                        $heading = substr($heading, 0, 80);
                    }
                    $desc .= " | near: \"{$heading}\"";
                }

                if ($detail !== '') {
                    $desc .= " | describes: \"{$detail}\"";
                }

                $lines[] = "[VISUAL_{$visual_id}] ({$type}): {$desc}";
            }
            $visual_assets = "VISUAL ASSETS AVAILABLE (Use [VISUAL_N] tokens to place these):\n" . implode("\n", $lines);

            // @MODIFIED 2026-02-16 - Anti-Repetition Instruction
            $count = count($lines);
            if ($count > 3) {
                $visual_assets .= "\n\nCRITICAL VISUAL RULE: You have {$count} unique images available. You MUST use valid tokens from [VISUAL_0] to [VISUAL_" . ($count - 1) . "].\n- NEVER repeat the same token.\n- Distribute valid tokens throughout the article.\n- DO NOT hallucinate tokens beyond [VISUAL_" . ($count - 1) . "].";
            }
        }

        // Compose the prompt data array
        return array(
            'idea_title'         => $request->ideaTitle,
            'idea_text'          => $request->ideaText,
            'vertical'           => $vertical,
            'category'           => $request->category,
            'source_urls'        => $request->sourceUrls,
            'primary_keyword'    => $request->primaryKeyword,
            'search_intent'      => $search_intent,
            'secondary_keywords' => $request->secondaryKeywords,
            'editorial_angle'    => $request->editorialAngle ?: 'neutral',
            'structure_blueprint' => $blueprint,
            'visual_assets'      => $visual_assets,
            // Provide explicit persona, style guide and formatting rules for the AI
            'role_definition'    => $blueprint['role'],
            'style_guide'        => $blueprint['voice_guidelines'],
            'formatting_rules'   => $blueprint['formatting_directives'],
        );
    }
}
