<?php

/**
 * Schema Sync Service
 * 
 * Centralized service for Article_Schema persistence and derived view regeneration.
 * Enforces Single Source of Truth pattern.
 *
 * @MODIFIED 2025-12-11 v1.8.0: New class for data synchronization architecture
 * @package SEO_Article_Generator
 */

namespace SEO_Article_Generator\Services;

// Prevent direct access.
if (!defined('ABSPATH')) {
    exit;
}

use SEO_Article_Generator\Generator\Article_Schema;
use SEO_Article_Generator\Generator\Hero_Data_Provider;

/**
 * Centralized schema load/save with derived view regeneration.
 * 
 * This service explicitly treats the post meta snapshot (_seo_gen_article_snapshot)
 * as the absolute canonical source of truth.
 * Derived views (such as _seo_gen_hero_data) are materialized caches explicitly
 * built from the canonical snapshot and overrides.
 */
class Schema_Sync_Service
{
    /**
     * Re-entry guard: prevents apply_hero_overrides() → save_schema() →
     * write_software_schema() → (hook fires) → save_schema() cascade.
     * Static because a single PHP request has one execution context.
     */
    private static bool $is_saving = false;

    /**
     * Per-request permalink cache.
     * get_permalink() is expensive in XAMPP (rewrites resolved via DB).
     * Keyed by post_id so multiple posts in one request are still correct.
     *
     * @var array<int, string>
     */
    private static array $permalink_cache = [];

    /**
     * Meta key for article snapshot (canonical data).
     */
    private const META_SNAPSHOT = '_seo_gen_article_snapshot';

    /**
     * Meta key for hero overrides (presentation layer).
     */
    private const META_HERO_OVERRIDES = '_seo_gen_hero_overrides';

    /**
     * Meta key for derived hero data (cache).
     */
    private const META_HERO_DATA = '_seo_gen_hero_data';

    /**
     * Meta key for schema modification timestamp.
     */
    private const META_SCHEMA_MODIFIED = '_seo_gen_schema_modified';

    /**
     * Load Article_Schema from post meta snapshot.
     *
     * @MODIFIED 2025-12-11 v1.8.0: Initial implementation
     *
     * @param int $post_id WordPress post ID.
     * @return Article_Schema|null Schema instance or null if no snapshot exists.
     */
    public static function load_schema(int $post_id): ?Article_Schema
    {
        $snapshot = get_post_meta($post_id, self::META_SNAPSHOT, true);

        if (empty($snapshot) || !is_array($snapshot)) {
            return null;
        }

        return Article_Schema::from_array($snapshot);
    }

    /**
     * Save schema to snapshot and regenerate all derived views.
     *
     * Derived views updated:
     * - _seo_gen_hero_data (via Hero_Data_Provider)
     * - _seo_gen_schema_modified (timestamp)
     *
     * @since 1.8.0
     *
     * @param int            $post_id        WordPress post ID.
     * @param Article_Schema $schema         The schema to persist.
     * @param array|null     $hero_overrides Optional hero overrides to apply.
     * @return void
     */
    public static function save_schema(int $post_id, Article_Schema $schema, ?array $hero_overrides = null): void
    {
        // Re-entry guard: apply_hero_overrides() calls save_schema() which calls
        // write_software_schema() which may fire hooks that re-trigger save_schema().
        if (self::$is_saving) {
            return;
        }
        self::$is_saving = true;

        try {
            $new_snapshot = $schema->to_array();

            // 1. Persist canonical snapshot only when content actually changed.
            //    Avoids a MySQL write + serialization on every WP save when nothing changed.
            $existing_raw  = \get_post_meta($post_id, self::META_SNAPSHOT, true);
            $existing_hash = is_array($existing_raw) ? md5(serialize($existing_raw)) : '';
            $new_hash      = md5(serialize($new_snapshot));
            $snapshot_changed = ($existing_hash !== $new_hash);

            if ($snapshot_changed) {
                \update_post_meta($post_id, self::META_SNAPSHOT, $new_snapshot);
            }

            // 2. Update modification timestamp only when snapshot changed.
            if ($snapshot_changed) {
                \update_post_meta($post_id, self::META_SCHEMA_MODIFIED, \SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts());
            }

        // 3. Regenerate derived hero data ONLY when overrides actually changed.
        // Previously this ran on every save - extremely expensive in XAMPP.
        $overrides = $hero_overrides;
        if ($overrides === null) {
            $overrides = \get_post_meta($post_id, self::META_HERO_OVERRIDES, true);
            if (!is_array($overrides)) {
                $overrides = [];
            }
            // [SSOT-FIX] Auto path (no explicit manual overrides passed): strip the
            // fields that MUST be re-derived on every update — version + both dates.
            // _seo_gen_hero_overrides may hold STALE values from a prior manual Hero
            // meta-box save (or a prior buggy run). Hero_Data_Provider::from_schema()
            // honors ALLOWED_OVERRIDES ('version','last_updated','last_verified_date'),
            // so leaving them in would clobber the freshly-derived canonical version
            // and dates on EVERY automated update — producing hero meta that lags the
            // title/tech_specs. Manual edits arrive via $hero_overrides (non-null) and
            // are intentionally honored below.
            foreach ( array( 'version', 'last_updated', 'last_verified_date' ) as $_ssot_field ) {
                unset( $overrides[ $_ssot_field ] );
            }
        }

        // @MODIFIED 2026-05-23: Merge persisted download_links into overrides for hero regeneration.
        // This ensures manual link edits are reflected in the derived hero data.
        // Uses is_array() to distinguish "no meta" (false) from "explicitly empty" ([]).
        // An empty array correctly overrides schema links when user cleared all links.
        // @MODIFIED 2026-06-18: Normalize persisted links through the same pipeline as
        // the Download Zone to ensure hero meta box and download zone show identical links.
        $persisted_links = \get_post_meta($post_id, '_seo_gen_hero_download_links', true);
        if (is_array($persisted_links)) {
            $homepage = trim((string) ($schema->tech_specs->homepage ?? ''));
            $sw_name = trim((string) ($schema->tech_specs->software_name ?? $schema->title ?? ''));
            $changelog = trim((string) ($schema->tech_specs->changelogurl ?? ''));
            $overrides['download_links'] = \SEO_Article_Generator\Generator\Download_Link_Helper::normalize_links(
                $persisted_links,
                'Windows',
                $homepage,
                $sw_name,
                $changelog
            );
        }

            // Compute overrides hash to detect actual changes
            $overrides_hash = md5(serialize($overrides));
            $existing_overrides_hash = \get_post_meta($post_id, '_seogen_overrides_hash', true) ?: '';

            // Skip hero regeneration if nothing changed
            if ($overrides_hash === $existing_overrides_hash && !$snapshot_changed) {
                // Still sync flat meta for legacy compatibility ONLY if hero_data exists.
                // Only write when values actually differ to avoid 4x unnecessary DB writes.
                $existing_hero = \get_post_meta($post_id, self::META_HERO_DATA, true);
                if (!empty($existing_hero)) {
                    $flat_syncs = [
                        '_seo_gen_download_url' => $existing_hero['download_url'] ?? '',
                        '_seo_gen_file_size'    => $existing_hero['file_size'] ?? '',
                        '_seo_gen_license'      => $existing_hero['license'] ?? '',
                        '_seo_gen_developer'    => $existing_hero['developer'] ?? '',
                    ];
                    foreach ($flat_syncs as $fk => $fv) {
                        if ((string) (\get_post_meta($post_id, $fk, true) ?? '') !== (string) $fv) {
                            \update_post_meta($post_id, $fk, $fv);
                        }
                    }
                }

                // @FIX 2026-07-25: Force hero data regeneration on the fast path.
                // Even when overrides hash and snapshot hash are unchanged, seogenherodata
                // can drift from the schema due to pre-SSOT runs or partial regens.
                // Hero_Data_Provider::from_schema() is deterministic and read-only on the
                // schema object; the cost is negligible and correctness is critical.
                $hero_data = Hero_Data_Provider::from_schema($schema, $overrides, $post_id);
                \update_post_meta($post_id, self::META_HERO_DATA, $hero_data);
                \update_post_meta($post_id, 'seogenherodata', $hero_data);

                // Sync flat meta keys for legacy compatibility from the fresh hero data.
                if (!empty($hero_data)) {
                    \update_post_meta($post_id, '_seo_gen_download_url', $hero_data['download_url'] ?? '');
                    \update_post_meta($post_id, '_seo_gen_file_size',    $hero_data['file_size'] ?? '');
                    \update_post_meta($post_id, '_seo_gen_license',      $hero_data['license'] ?? '');
                    \update_post_meta($post_id, '_seo_gen_developer',    $hero_data['developer'] ?? '');
                }

                // @FIX 2026-07-25: Sync _seo_gen_version from schema's tech_specs.version
                // as the authoritative SSOT. Per architectural decision (Finding 8),
                // Title_Analyzer-extracted version from the LIVE post title is NOT
                // allowed to overwrite _seo_gen_version — the live title IS the
                // AI-generated title and cannot be a "newer" authority than the schema.
                // Title-parsed version comparison belongs in the staging gate
                // (Discovery_Processor) against the SOURCE post title only.
                $schema_version = trim((string) ($schema->tech_specs->version ?? ''));
                if (!empty($schema_version) && strcasecmp($schema_version, 'unknown') !== 0) {
                    $current_ver = trim((string) \get_post_meta($post_id, '_seo_gen_version', true));
                    if ($current_ver === '' || strcasecmp($current_ver, 'unknown') === 0
                        || \SEO_Article_Generator\Discovery\Title_Analyzer::is_newer_version($schema_version, $current_ver)) {
                        \update_post_meta($post_id, '_seo_gen_version', $schema_version);
                    }
                }

                // Skip rest of hero processing
                goto after_hero_data;
            }

            // Store new overrides hash
            \update_post_meta($post_id, '_seogen_overrides_hash', $overrides_hash);

		$hero_data = Hero_Data_Provider::from_schema($schema, $overrides, $post_id);
		\update_post_meta($post_id, self::META_HERO_DATA, $hero_data);
		// @MODIFIED 2026-04-28: SSOT sync — write to seogenherodata as well so all readers
		// (Download_Renderer, Plugin::get_hero_data(), Discovery_Processor) see consistent data.
		\update_post_meta($post_id, 'seogenherodata', $hero_data);
		// @ADDED 2026-06-06: SSOT sync — keep _seo_gen_version in lockstep with the
		// hero data write. _seo_gen_version is read as a canonical version source
		// by Discovery_Engine, Discovery_Bootstrap, Discovery_Processor and
		// Post_Type_Classifier. Without this write, the next staging-time
		// is_newer_version() check had to fall through to seogenherodata or the
		// post title to see the new version.
		if ( ! empty( $hero_data['version'] ) ) {
			\update_post_meta( $post_id, '_seo_gen_version', (string) $hero_data['version'] );
		}

		// [SSOT-FIX Finding 8] Title-parsed version override REMOVED. The live post title
		// is the AI-generated title from the latest finalization — using it to overwrite
		// _seo_gen_version creates a circular dependency where the title becomes the
		// source of truth for the schema's version. Title_Analyzer-based staging
		// comparisons belong in Discovery_Processor's is_newer_version() gate, which
		// compares the SOURCE (staging draft) title vs the EXISTING (live) title —
		// never the AI-generated title we just wrote.

		// @FIX: Set Cloudflare bypass transient so the first visitor after save
		// sees fresh content. write_hero_data() sets this but save_schema() writes
		// hero data directly, bypassing write_hero_data(). Without this, the
		// maybe_bypass_cache_for_hero_posts() filter has no flag to consume.
		if (\function_exists('\get_post_status') && \get_post_status($post_id) === 'publish') {
			\set_transient('seo_gen_hero_dirty_' . $post_id, 1, 60);
		}

            // [PLATFORM PARITY] Sync flat meta keys for legacy/UI compatibility.
            if (!empty($hero_data)) {
                \update_post_meta($post_id, '_seo_gen_download_url', $hero_data['download_url'] ?? '');
                \update_post_meta($post_id, '_seo_gen_file_size',    $hero_data['file_size'] ?? '');
                \update_post_meta($post_id, '_seo_gen_license',      $hero_data['license'] ?? '');
                \update_post_meta($post_id, '_seo_gen_developer',    $hero_data['developer'] ?? '');
            }

            // 4. Seed ratings only when snapshot is new — not on every save.
            if ($snapshot_changed && \class_exists('SEO_Article_Generator\\Frontend\\Rating_System')) {
                \SEO_Article_Generator\Frontend\Rating_System::maybe_seed_ratings($post_id);
            }

            // 5. Sync to Rank Math native schema meta only when snapshot changed.
            //    write_software_schema() calls get_permalink() which is slow in XAMPP.
            if ($snapshot_changed && \class_exists('SEO_Article_Generator\\Integration\\Rank_Math_Schema_Handler')) {
                \SEO_Article_Generator\Integration\Rank_Math_Schema_Handler::write_software_schema($post_id);
            }

            after_hero_data:

        } finally {
            self::$is_saving = false;
        }
    }

    /**
     * Apply hero overrides and regenerate hero view.
     *
     * @MODIFIED 2025-12-30 v2.8.5: Also syncs factual data back to Article_Schema snapshot.
     * @MODIFIED 2026-05-23: Preserve download_links in persistent storage for manual edits.
     *
     * @param int $post_id WordPress post ID.
     * @param array $overrides Hero presentation and factual overrides.
     * @return bool True on success, false if no schema exists.
     */
    public static function apply_hero_overrides(int $post_id, array $overrides): bool
    {
        // Extract download_links BEFORE unsetting — they persist separately for manual edits.
        $has_download_links = array_key_exists('download_links', $overrides);
        $download_links = $overrides['download_links'] ?? array();

        // @MODIFIED 2026-05-03: Enforce SSOT — download_links are not applied to schema.
        // They must flow from _canonical_download_links → download_section → schema only.
        unset($overrides['download_links']);

        // Load existing schema
        $schema = self::load_schema($post_id);

        if ($schema === null) {
            // No schema exists - cannot regenerate hero
            return false;
        }

        // @MODIFIED 2026-06-18: SSOT SYNC — When hero download links are manually edited,
        // normalize them and sync back to download_section['links'] in the schema snapshot.
        // This ensures the Download Zone (which reads from download_section) and the Hero Meta Box
        // (which reads from seogenherodata) always show the same links.
        // Without this sync, manual hero edits are invisible to the Download Zone.
        // Uses array_key_exists to distinguish "not provided" from "explicitly empty" (user cleared all).
        if ($has_download_links && is_array($download_links)) {
            $homepage = trim((string) ($schema->tech_specs->homepage ?? ''));
            $software_name = trim((string) ($schema->tech_specs->software_name ?? $schema->title ?? ''));
            $changelogurl = trim((string) ($schema->tech_specs->changelogurl ?? ''));
            $normalized_links = \SEO_Article_Generator\Generator\Download_Link_Helper::normalize_links(
                $download_links,
                'Windows',
                $homepage,
                $software_name,
                $changelogurl
            );
            // Sync normalized links to schema — empty array is valid (user cleared all links)
            $schema->download_section['links'] = $normalized_links;
        }

        // @MODIFIED 2025-12-30 v2.8.5: Sync factual data back to the canonical snapshot
        // This ensures Hero edits propagate to JSON-LD and RankMath.
        $schema->apply_hero_overrides($overrides);

        // [SSOT-FIX 2026-07-25] Strip version/dates from persisted hero overrides so that
        // the next auto-finalize / meta-box view cannot leak stale version/last_updated/
        // last_verified_date into Hero meta. These three fields are source-of-truth from
        // schema + today(), and must never ride through _seo_gen_hero_overrides.
        // Mirrors the SSOT strip already applied on the auto path in save_schema() (lines ~147-149).
        foreach ( array( 'version', 'last_updated', 'last_verified_date' ) as $_ssot_field ) {
            unset( $overrides[ $_ssot_field ] );
        }

        // @MODIFIED 2026-01-02: Explicitly persist overrides so they aren't lost on reload
        update_post_meta($post_id, self::META_HERO_OVERRIDES, $overrides);

        // @MODIFIED 2026-05-23: Persist download_links separately for manual hero edits.
        // This ensures manual link edits survive schema sync without breaking SSOT for AI-generated content.
        // Uses array_key_exists to distinguish "explicitly set to empty" from "not provided at all".
        if ($has_download_links) {
            update_post_meta($post_id, '_seo_gen_hero_download_links', $download_links);
        }

        // Save updated snapshot (this triggers RankMath sync via save_post hook eventually)
        // We pass overrides to ensure derived hero data is also regenerated.
        self::save_schema($post_id, $schema, $overrides);

        return true;
    }

    /**
     * Check if a post has a valid schema snapshot.
     *
     * @param int $post_id WordPress post ID.
     * @return bool True if schema exists.
     */
    public static function has_schema(int $post_id): bool
    {
        $snapshot = get_post_meta($post_id, self::META_SNAPSHOT, true);
        return !empty($snapshot) && is_array($snapshot);
    }

    /**
     * Get schema modification timestamp.
     *
     * @param int $post_id WordPress post ID.
     * @return int|null Unix timestamp or null if not set.
     */
    public static function get_schema_modified(int $post_id): ?int
    {
        $timestamp = get_post_meta($post_id, self::META_SCHEMA_MODIFIED, true);
        return $timestamp ? (int) $timestamp : null;
    }

    /**
     * Cache get_permalink() per post_id for the lifetime of the request.
     * Eliminates repeated rewrite-rule resolution in XAMPP.
     */
    public static function get_cached_permalink(int $post_id): string
    {
        if (!isset(self::$permalink_cache[$post_id])) {
            $p = \get_permalink($post_id);
            self::$permalink_cache[$post_id] = $p ?: '';
        }
        return self::$permalink_cache[$post_id];
    }

    /**
     * Invalidate the permalink cache for a post.
     * Clears WP's internal rewrite cache and our local cache.
     *
     * @param int $post_id
     * @return void
     */
    public static function invalidate_permalink_cache(int $post_id): void
    {
        unset(self::$permalink_cache[$post_id]);
        // Force WP to refresh the post's permalink
        \clean_post_cache($post_id);
    }
}
