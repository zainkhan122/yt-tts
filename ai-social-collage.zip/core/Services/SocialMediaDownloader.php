<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SocialMediaDownloader {
    const OPTION_YTDLP_PATH = 'ai_collage_ytdlp_path';
    const OPTION_GALLERY_DL_PATH = 'ai_collage_gallery_dl_path';
    const OPTION_BRANDING_REMOVAL_ENABLED = 'ai_collage_branding_removal_enabled';
    const OPTION_OCR_ENABLED = 'ai_collage_ocr_enabled';
    
    public function __construct() {
        $this->ytdlp_path = get_option( self::OPTION_YTDLP_PATH, '/usr/local/bin/yt-dlp' );
        $this->gallery_dl_path = get_option( self::OPTION_GALLERY_DL_PATH, '/usr/local/bin/gallery-dl' );
        $this->branding_enabled = (bool) get_option( self::OPTION_BRANDING_REMOVAL_ENABLED, false );
        $this->ocr_enabled = (bool) get_option( self::OPTION_OCR_ENABLED, false );
    }

    /**
     * Verify the configured yt-dlp / gallery-dl binaries exist and respond
     * to --version. Caches the probe so each binary is checked at most
     * once per request lifecycle.
     *
     * @return array{yt_dlp_ok:bool,yt_dlp_version:string,yt_dlp_path:string,gallery_dl_ok:bool,gallery_dl_version:string,gallery_dl_path:string,exec_available:bool}
     */
    public function check_binary_health() {
        static $cache = null;
        if ( $cache !== null ) {
            return $cache;
        }

        $exec_available = function_exists( 'exec' )
            && ! in_array( 'exec', array_map( 'trim', explode( ',', (string) ini_get( 'disable_functions' ) ) ), true );

        $cache = [
            'exec_available'     => $exec_available,
            'yt_dlp_path'        => $this->ytdlp_path,
            'yt_dlp_ok'          => false,
            'yt_dlp_version'     => '',
            'gallery_dl_path'    => $this->gallery_dl_path,
            'gallery_dl_ok'      => false,
            'gallery_dl_version' => '',
        ];

        if ( ! $exec_available ) {
            return $cache;
        }

        if ( is_file( $this->ytdlp_path ) && is_executable( $this->ytdlp_path ) ) {
            @exec( escapeshellcmd( $this->ytdlp_path ) . ' --version 2>&1', $yt_out, $yt_rc );
            if ( $yt_rc === 0 && ! empty( $yt_out ) ) {
                $cache['yt_dlp_ok']      = true;
                $cache['yt_dlp_version'] = trim( $yt_out[0] );
            }
        }

        if ( is_file( $this->gallery_dl_path ) && is_executable( $this->gallery_dl_path ) ) {
            @exec( escapeshellcmd( $this->gallery_dl_path ) . ' --version 2>&1', $gd_out, $gd_rc );
            if ( $gd_rc === 0 && ! empty( $gd_out ) ) {
                $cache['gallery_dl_ok']      = true;
                $cache['gallery_dl_version'] = trim( $gd_out[0] );
            }
        }

        return $cache;
    }

    public function download_media( $url, $platform_type ) {
        $temp_dir = wp_upload_dir()['path'] . '/social_media_temp/';
        if ( ! file_exists( $temp_dir ) ) {
            wp_mkdir_p( $temp_dir );
        }

        $output_path = $temp_dir . uniqid() . '.tmp';

        try {
            // Try yt-dlp first
            if ( $this->execute_ytdlp( $url, $output_path ) ) {
                return $this->process_downloaded_media( $output_path, $platform_type );
            }

            // Fallback to gallery-dl for image galleries
            if ( $this->execute_gallery_dl( $url, $output_path ) ) {
                return $this->process_downloaded_media( $output_path, $platform_type );
            }

            throw new \RuntimeException( 'Failed to download media from URL' );
        } catch ( \Throwable $e ) {
            if ( file_exists( $output_path ) ) {
                @unlink( $output_path );
            }
            throw $e;
        }
    }

    private function execute_ytdlp( $url, $output_path ) {
        if ( ! file_exists( $this->ytdlp_path ) ) {
            Logger::warning( 'ytdlp_missing', null, [
                'path'  => $this->ytdlp_path,
                'error' => 'binary_not_found',
            ], '404' );
            return false;
        }

        // Probe version once per request; warn if binary is stale or broken.
        $health = $this->check_binary_health();
        if ( ! $health['exec_available'] ) {
            Logger::warning( 'ytdlp_exec_disabled', null, [
                'path' => $this->ytdlp_path,
            ], '403' );
            return false;
        }
        if ( ! $health['yt_dlp_ok'] ) {
            Logger::warning( 'ytdlp_version_probe_failed', null, [
                'path'    => $this->ytdlp_path,
                'hint'    => 'binary present but did not respond to --version — may be outdated, missing ffmpeg/deno, or corrupt',
            ], '500' );
        }
        
        $command = escapeshellcmd( $this->ytdlp_path ) . 
                   ' --no-check-certificate ' .
                   ' --no-playlist ' .
                   ' --output "' . $output_path . '" ' .
                   ' "' . escapeshellarg( $url ) . '" 2>&1';
        
        exec( $command, $output, $return_code );
        
        if ( $return_code === 0 && file_exists( $output_path ) ) {
            Logger::info( Config::LOG_ACTION_SOCIAL_MEDIA_DOWNLOADED, null, [
                'url' => $url,
                'output_path' => $output_path,
                'file_size' => filesize( $output_path ),
            ], '200' );
            return true;
        }
        
        Logger::warning( 'ytdlp_download_failed', null, [
            'url' => $url,
            'return_code' => $return_code,
            'output' => implode( "\n", array_slice( $output, 0, 5 ) ),
        ], '500' );
        
        return false;
    }
    
    private function execute_gallery_dl( $url, $output_path ) {
        if ( ! file_exists( $this->gallery_dl_path ) ) {
            Logger::warning( 'gallery_dl_missing', null, [
                'path'  => $this->gallery_dl_path,
                'error' => 'binary_not_found',
            ], '404' );
            return false;
        }

        $health = $this->check_binary_health();
        if ( ! $health['exec_available'] ) {
            Logger::warning( 'gallery_dl_exec_disabled', null, [
                'path' => $this->gallery_dl_path,
            ], '403' );
            return false;
        }
        if ( ! $health['gallery_dl_ok'] ) {
            Logger::warning( 'gallery_dl_version_probe_failed', null, [
                'path' => $this->gallery_dl_path,
            ], '500' );
        }
        
        $command = escapeshellcmd( $this->gallery_dl_path ) . 
                   ' --directory "' . dirname( $output_path ) . '" ' .
                   ' --filename "' . basename( $output_path, '.tmp' ) . '" ' .
                   ' "' . escapeshellarg( $url ) . '" 2>&1';
        
        exec( $command, $output, $return_code );
        
        // gallery-dl saves with different extension, find the file
        if ( $return_code === 0 ) {
            $files = glob( dirname( $output_path ) . '/*' );
            if ( ! empty( $files ) ) {
                $output_path = $files[0];
                Logger::info( Config::LOG_ACTION_SOCIAL_MEDIA_DOWNLOADED, null, [
                    'url' => $url,
                    'output_path' => $output_path,
                    'file_size' => filesize( $output_path ),
                ], '200' );
                return true;
            }
        }
        
        Logger::warning( 'gallery_dl_download_failed', null, [
            'url' => $url,
            'return_code' => $return_code,
            'output' => implode( "\n", array_slice( $output, 0, 5 ) ),
        ], '500' );
        
        return false;
    }
    
    private function process_downloaded_media( $file_path, $platform_type ) {
        // Validate the downloaded file is actually a media payload.
        // yt-dlp/gallery-dl on 403 / rate-limit can save the HTML error page
        // to disk and still return exit code 0, which would otherwise propagate
        // a corrupt attachment into the collage pipeline.
        if ( ! $this->is_valid_media_file( $file_path ) ) {
            $size = file_exists( $file_path ) ? filesize( $file_path ) : 0;
            Logger::warning( 'social_media_invalid_payload', null, [
                'file_path' => $file_path,
                'size'      => $size,
                'platform'  => $platform_type,
            ], '500' );
            throw new \RuntimeException( 'Downloaded file is not a valid media payload (size=' . $size . ')' );
        }

        $result = [
            'file_path' => $file_path,
            'file_size' => filesize( $file_path ),
            'file_type' => $this->detect_file_type( $file_path ),
            'platform' => $platform_type,
            'branding_removed' => 0,
            'ocr_text' => '',
        ];

        // Extract metadata based on platform
        $metadata = $this->extract_platform_metadata( $file_path, $platform_type );
        $result['metadata'] = $metadata;

        // Apply branding removal if enabled
        if ( $this->branding_enabled ) {
            $result = $this->remove_branding( $result );
        }

        // Apply OCR if enabled
        if ( $this->ocr_enabled ) {
            $result['ocr_text'] = $this->extract_text_from_media( $file_path );
        }

        return $result;
    }

    /**
     * Cheap media-payload check: extension allow-list plus minimum size plus
     * a magic-byte sniff so we reject HTML error pages saved by the downloader.
     */
    private function is_valid_media_file( $file_path ) {
        if ( ! file_exists( $file_path ) ) {
            return false;
        }
        $size = filesize( $file_path );
        // 1 KB minimum; a real social media asset is always above this.
        if ( $size < 1024 ) {
            return false;
        }
        $ext = strtolower( pathinfo( $file_path, PATHINFO_EXTENSION ) );
        $allowed = [ 'jpg', 'jpeg', 'png', 'gif', 'webp', 'mp4', 'mov', 'avi', 'webm', 'mkv', 'flv', 'wmv' ];
        if ( ! in_array( $ext, $allowed, true ) ) {
            return false;
        }
        $handle = @fopen( $file_path, 'rb' );
        if ( ! $handle ) {
            return false;
        }
        $head = fread( $handle, 16 );
        fclose( $handle );
        if ( ! is_string( $head ) || strlen( $head ) < 4 ) {
            return false;
        }
        // Reject HTML / XML error pages saved by the binary.
        if ( stripos( $head, '<!doctype html' ) === 0
            || stripos( $head, '<html' ) === 0
            || stripos( $head, '<?xml' ) === 0
            || stripos( $head, '{"' ) === 0 ) {
            return false;
        }
        return true;
    }

    private function remove_branding( $media_data ) {
        if ( ! class_exists( '\\AiSocialCollage\\Services\\BrandingDetector' ) ) {
            Logger::warning( 'branding_detector_missing', null, [
                'file_path' => $media_data['file_path'],
            ], '500' );
            return $media_data;
        }

        $branding_detector = new BrandingDetector();
        $branding_elements = $branding_detector->detect_branding( $media_data['file_path'] );

        if ( ! empty( $branding_elements ) ) {
            if ( ! class_exists( '\\AiSocialCollage\\Services\\BrandingRemover' ) ) {
                Logger::warning( 'branding_remover_missing', null, [
                    'file_path'              => $media_data['file_path'],
                    'branding_elements_count' => is_array( $branding_elements ) ? count( $branding_elements ) : 0,
                ], '500' );
                return $media_data;
            }

            $branding_remover = new BrandingRemover();
            $original_path = $media_data['file_path'];
            $cleaned_path = $branding_remover->remove_branding( $original_path, $branding_elements );

            if ( $cleaned_path && file_exists( $cleaned_path ) ) {
                $media_data['file_path'] = $cleaned_path;
                $media_data['branding_removed'] = 1;
                Logger::info( Config::LOG_ACTION_BRANDING_REMOVED, null, [
                    'original_path' => $original_path,
                    'cleaned_path' => $cleaned_path,
                    'elements_processed' => count( $branding_elements ),
                ], '200' );
            }
        }

        return $media_data;
    }
    
    private function extract_platform_metadata( $file_path, $platform_type ) {
        $metadata = [
            'platform' => $platform_type,
            'author' => '',
            'caption' => '',
            'hashtags' => [],
        ];
        
        // Platform-specific metadata extraction
        switch ( $platform_type ) {
            case Config::SOURCE_TYPE_INSTAGRAM:
                $metadata = $this->extract_instagram_metadata( $file_path );
                break;
            case Config::SOURCE_TYPE_TWITTER:
                $metadata = $this->extract_twitter_metadata( $file_path );
                break;
            case Config::SOURCE_TYPE_TIKTOK:
                $metadata = $this->extract_tiktok_metadata( $file_path );
                break;
            default:
                // Generic metadata extraction
                $metadata['caption'] = basename( $file_path );
        }
        
        return $metadata;
    }
    
    private function extract_text_from_media( $image_path ) {
        if ( ! class_exists( '\\AiSocialCollage\\Services\\OCRService' ) ) {
            Logger::warning( 'ocr_service_missing', null, [
                'image_path' => $image_path,
            ], '500' );
            return '';
        }
        $ocr_service = new OCRService();
        return $ocr_service->extract_text_from_media( $image_path );
    }
    
    private function detect_file_type( $file_path ) {
        $extension = strtolower( pathinfo( $file_path, PATHINFO_EXTENSION ) );
        $allowed_types = [ 'jpg', 'jpeg', 'png', 'gif', 'webp', 'mp4', 'mov', 'avi', 'webm', 'mkv', 'flv', 'wmv' ];
        return in_array( $extension, $allowed_types ) ? $extension : 'unknown';
    }

    /**
     * Check if a file is a video based on extension or MIME type.
     *
     * @param string $file_path Path to file.
     * @return bool True if file is a video.
     */
    public static function is_video_file( $file_path ) {
        $ext = strtolower( pathinfo( $file_path, PATHINFO_EXTENSION ) );
        if ( in_array( $ext, Config::VIDEO_EXTENSIONS, true ) ) {
            return true;
        }
        if ( function_exists( 'mime_content_type' ) ) {
            $mime = @mime_content_type( $file_path );
            return is_string( $mime ) && strpos( $mime, 'video/' ) === 0;
        }
        return false;
    }
    
    // Platform-specific metadata extraction methods
    private function extract_instagram_metadata( $file_path ) {
        return [
            'platform' => Config::SOURCE_TYPE_INSTAGRAM,
            'author' => '',
            'caption' => '',
            'hashtags' => [],
            'format' => 'instagram',
        ];
    }
    
    private function extract_twitter_metadata( $file_path ) {
        return [
            'platform' => Config::SOURCE_TYPE_TWITTER,
            'author' => '',
            'caption' => '',
            'hashtags' => [],
            'format' => 'twitter',
        ];
    }
    
    private function extract_tiktok_metadata( $file_path ) {
        return [
            'platform' => Config::SOURCE_TYPE_TIKTOK,
            'author' => '',
            'caption' => '',
            'hashtags' => [],
            'format' => 'tiktok',
        ];
    }
}