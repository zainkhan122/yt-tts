<?php

/**
 * Security Manager for MCQ Plugin
 * Provides input sanitization, rate limiting, and security logging
 */

if (! defined('ABSPATH')) {
	exit;
}

if (! class_exists('NM_Security_Manager')) {

	class NM_Security_Manager
	{

		/**
		 * CRITICAL: Basic sanitization methods (used by AJAX handlers)
		 */
		public static function sanitize_integer($value)
		{
			return absint($value);
		}

		public static function sanitize_text($value)
		{
			return sanitize_text_field($value);
		}

		public static function sanitize_textarea($value)
		{
			return sanitize_textarea_field($value);
		}

		public static function sanitize_email($value)
		{
			return sanitize_email($value);
		}

		public static function sanitize_url($value)
		{
			return esc_url_raw($value);
		}

		/**
		 * Initialize security features
		 */
		public static function init()
		{
			// ✅ NEW: Strict Access Control Hooks
			add_action('admin_init', array(__CLASS__, 'enforce_dashboard_access'));
			add_filter('show_admin_bar', array(__CLASS__, 'hide_admin_bar'));
			add_action('login_init', array(__CLASS__, 'restrict_wp_login'));

			// ✅ NEW: Enterprise Hardening Hooks
			add_filter('rest_endpoints', array(__CLASS__, 'disable_rest_user_endpoints'));
			add_action('template_redirect', array(__CLASS__, 'disable_author_archives'));
			add_filter('the_generator', array(__CLASS__, 'remove_wp_version'));

			try {
				global $wpdb;

				if (! $wpdb || ! $wpdb->ready) {
					return false;
				}

				// Set default security options
				$security_options = get_option('nm_security_settings', array());
				$defaults         = array(
					'rate_limit_enabled'      => true,
					'max_requests_per_minute' => 60,
					'max_requests_per_hour'   => 1000,
					'block_suspicious_ips'    => true,
					'log_all_requests'        => false,
					'csrf_protection'         => true,
				);
				$security_options = array_merge($defaults, $security_options);
				update_option('nm_security_settings', $security_options, false);

				return true;
			} catch (Exception $e) {
				return false;
			}
		}

		/**
		 * Rate limiting with safe checks
		 */
		public static function check_rate_limit($action, $limit = 60, $window = 60)
		{
			try {
				$ip      = self::get_client_ip();
				$user_id = get_current_user_id() ?: $ip;
				$key     = "nm_rate_limit_{$action}_{$user_id}";

				$current_count = get_transient($key);
				if ($current_count === false) {
					$current_count = 0;
				}

				if ($current_count >= $limit) {
					self::log_security_event(
						'rate_limit_exceeded',
						array(
							'action'   => $action,
							'attempts' => $current_count,
							'limit'    => $limit,
						),
						'medium'
					);
					return false;
				}

				set_transient($key, $current_count + 1, $window);
				return true;
			} catch (Exception $e) {
				return true; // Allow request if check fails
			}
		}

		/**
		 * Enhanced CSRF protection
		 */
		public static function verify_enhanced_nonce($action, $nonce_key = 'nonce')
		{
			try {
				if (! isset($_POST[$nonce_key])) {
					return false;
				}

				$nonce = sanitize_text_field($_POST[$nonce_key]);

				// Check WordPress nonce
				if (wp_verify_nonce($nonce, $action)) {
					return true;
				}

				// Check if it's the legacy nonce format
				if (wp_verify_nonce($nonce, 'nm_mcq_nonce')) {
					return true;
				}

				return false;
			} catch (Exception $e) {
				return false;
			}
		}

		/**
		 * Safe input validation
		 */
		public static function validate_mcq_data($data)
		{
			try {
				$errors = array();

				// Validate question
				if (empty($data['question'])) {
					$errors[] = 'Question is required';
				} elseif (strlen($data['question']) > 180) {
					$errors[] = 'Question must be under 180 characters';
				}

				// Validate options
				if (! isset($data['options']) || ! is_array($data['options'])) {
					$errors[] = 'Options are required';
				} else {
					foreach (array('A', 'B', 'C', 'D') as $option) {
						if (empty($data['options'][$option])) {
							$errors[] = "Option {$option} is required";
						} elseif (strlen($data['options'][$option]) > 70) {
							$errors[] = "Option {$option} must be under 70 characters";
						}
					}
				}

				// Validate answer
				if (empty($data['answer']) || ! in_array($data['answer'], array('A', 'B', 'C', 'D'))) {
					$errors[] = 'Valid answer is required (A, B, C, or D)';
				}

				// Validate explanation
				if (! empty($data['explanation']) && strlen($data['explanation']) > 1000) {
					$errors[] = 'Explanation must be under 1000 characters';
				}

				return empty($errors) ? true : $errors;
			} catch (Exception $e) {
				return array('Validation failed due to error');
			}
		}

		/**
		 * Generate security tokens
		 */
		public static function generate_frontend_token()
		{
			try {
				$user_id   = get_current_user_id();
				$timestamp = time();
				$data      = $user_id . '|' . $timestamp . '|frontend';
				return hash_hmac('sha256', $data, wp_salt('secure_auth') . 'nm_frontend');
			} catch (Exception $e) {
				return wp_create_nonce('nm_frontend_fallback');
			}
		}

		public static function generate_admin_token()
		{
			try {
				$user_id   = get_current_user_id();
				$timestamp = time();
				$data      = $user_id . '|' . $timestamp . '|admin';
				return hash_hmac('sha256', $data, wp_salt('secure_auth') . 'nm_admin');
			} catch (Exception $e) {
				return wp_create_nonce('nm_admin_fallback');
			}
		}

		/**
		 * Get client IP safely
		 */
		public static function get_client_ip()
		{
			$ip_keys = array('HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR');

			foreach ($ip_keys as $key) {
				if (! empty($_SERVER[$key])) {
					$ip = trim($_SERVER[$key]);

					if (strpos($ip, ',') !== false) {
						$ip = trim(explode(',', $ip)[0]);
					}

					if (filter_var($ip, FILTER_VALIDATE_IP)) {
						return $ip;
					}
				}
			}

			return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
		}

		/**
		 * Safe early security check
		 */
		public static function early_security_check()
		{
			try {
				$ip = self::get_client_ip();

				// Basic checks only - don't break functionality
				if (self::is_ip_blocked($ip)) {
					wp_die('Access temporarily blocked', 'Security', array('response' => 403));
				}
			} catch (Exception $e) {
				// Don't block on error
			}
		}

		/**
		 * Helper methods with safe defaults
		 */
		private static function is_ip_blocked($ip)
		{
			try {
				$blocked_ips = get_option('nm_blocked_ips', array());
				return isset($blocked_ips[$ip]) && $blocked_ips[$ip] > time();
			} catch (Exception $e) {
				return false;
			}
		}

		public static function log_security_event($event_type, $event_data = array(), $severity = 'medium')
		{
			try {
				// Basic logging - just to error log for now
				if ($severity === 'critical' || $severity === 'high') {
				}
			} catch (Exception $e) {
				// Silent fail on logging errors
			}
		}

		public static function log_failed_login($username)
		{
			self::log_security_event('login_failed', array('username' => $username), 'medium');
		}

		public static function log_successful_login($user_login, $user)
		{
			self::log_security_event('login_success', array('username' => $user_login), 'low');
		}

		public static function cleanup_old_logs($days = 30)
		{
			global $wpdb;
			$table = $wpdb->prefix . 'nm_security_log';
			$days  = max(1, (int) $days);

			try {
				$wpdb->query(
					$wpdb->prepare(
						"DELETE FROM {$table} WHERE timestamp < DATE_SUB(NOW(), INTERVAL %d DAY)",
						$days
					)
				);
			} catch (Exception $e) {
				error_log('NM Security: cleanup_old_logs error: ' . $e->getMessage());
			}
		}

		/**
		 * ✅ NEW: Enforce Dashboard Access Control
		 * Redirects 'quiz_taker' users away from wp-admin to their custom dashboard
		 *
		 * @since 2.6 Security Hardening
		 */
		public static function enforce_dashboard_access()
		{
			// Allow AJAX requests
			if (defined('DOING_AJAX') && DOING_AJAX) {
				return;
			}

			$user = wp_get_current_user();

			// Check if user has 'quiz_taker' role and NO other admin capabilities
			if (in_array('quiz_taker', (array) $user->roles) && ! current_user_can('manage_options')) {
				wp_safe_redirect(home_url('/mcq-dashboard/'));
				exit;
			}
		}

		/**
		 * ✅ NEW: Hide Admin Bar for Quiz Takers
		 *
		 * @since 2.6 Security Hardening
		 */
		public static function hide_admin_bar($show)
		{
			$user = wp_get_current_user();
			if (in_array('quiz_taker', (array) $user->roles) && ! current_user_can('manage_options')) {
				return false;
			}
			return $show;
		}

		/**
		 * ✅ NEW: Restrict Access to wp-login.php
		 * Redirects strict traffic to custom login page
		 *
		 * @since 2.6 Security Hardening
		 */
		public static function restrict_wp_login()
		{
			// ✅ FIXED: Allow custom login URLs (like /login-text/) to bypass redirection
			if (isset($_SERVER['REQUEST_URI']) && stripos($_SERVER['REQUEST_URI'], 'wp-login.php') === false) {
				return;
			}

			$action = isset($_REQUEST['action']) ? sanitize_text_field($_REQUEST['action']) : 'login';

			// Allowed actions on wp-login.php
			$allowed_actions = array('logout', 'postpass', 'rp', 'resetpass', 'validate_2fa');

			if (! in_array($action, $allowed_actions)) {
				wp_safe_redirect(home_url('/mcq-login/'));
				exit;
			}
		}

		/**
		 * ✅ NEW: Disable REST API User Enumeration
		 * Prevents /wp/v2/users from leaking usernames
		 */
		public static function disable_rest_user_endpoints($endpoints)
		{
			if (! is_user_logged_in() || ! current_user_can('manage_options')) {
				if (isset($endpoints['/wp/v2/users'])) {
					unset($endpoints['/wp/v2/users']);
				}
				if (isset($endpoints['/wp/v2/users/(?P<id>[\d]+)'])) {
					unset($endpoints['/wp/v2/users/(?P<id>[\d]+)']);
				}
			}
			return $endpoints;
		}

		/**
		 * ✅ NEW: Disable Author Archives
		 * Prevents username harvesting via /?author=1
		 */
		public static function disable_author_archives()
		{
			if (is_author()) {
				wp_safe_redirect(home_url());
				exit;
			}
		}

		/**
		 * ✅ NEW: Remove WordPress Version
		 * Obfuscates the specific WP version in source code
		 */
		public static function remove_wp_version()
		{
			return '';
		}
	} // End NM_Security_Manager class

} // End class_exists check

