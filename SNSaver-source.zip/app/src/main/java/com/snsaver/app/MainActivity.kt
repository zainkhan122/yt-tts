package com.snsaver.app
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.*
import com.snsaver.app.data.preferences.AppPreferences
import com.snsaver.app.ui.navigation.*
import com.snsaver.app.ui.theme.SNSaverTheme
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
@AndroidEntryPoint class MainActivity:ComponentActivity(){@Inject lateinit var preferences:AppPreferences;override fun onCreate(state:Bundle?){super.onCreate(state);enableEdgeToEdge();setContent{val selected by preferences.theme.collectAsStateWithLifecycle("system");val system=isSystemInDarkTheme();SNSaverTheme(selected=="dark"||(selected=="system"&&system)){SNSaverRoot()}}}}
data class NavItem(val label:String,val route:String,val selected:androidx.compose.ui.graphics.vector.ImageVector,val plain:androidx.compose.ui.graphics.vector.ImageVector)
@Composable fun SNSaverRoot(){val nav=rememberNavController();val entry by nav.currentBackStackEntryAsState();val route=entry?.destination?.route;val items=listOf(NavItem("Inbox",Routes.INBOX,Icons.Filled.Download,Icons.Outlined.Download),NavItem("Gallery",Routes.GALLERY,Icons.Filled.PhotoLibrary,Icons.Outlined.PhotoLibrary),NavItem("Settings",Routes.SETTINGS,Icons.Filled.Settings,Icons.Outlined.Settings));Scaffold(bottomBar={if(route in items.map{it.route})NavigationBar{items.forEach{i->val active=route==i.route;NavigationBarItem(active,{nav.navigate(i.route){popUpTo(Routes.INBOX){saveState=true};launchSingleTop=true;restoreState=true}},{Icon(if(active)i.selected else i.plain,i.label)},label={Text(i.label)})}}}){pad->AppNavigation(nav,Modifier.padding(pad))}}
