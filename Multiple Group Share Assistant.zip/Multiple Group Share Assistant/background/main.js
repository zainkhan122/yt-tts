import { InstallationIdManager } from './installation_id.js';
import { startAutoShareScheduler, stopAutoShareScheduler } from './scheduler.js';

/**
 * Injects content scripts into existing Facebook tabs upon installation
 * This allows the extension to work immediately without requiring a refresh
 */
async function injectContentScriptsIntoFacebookTabs() {
  console.log('Attempting to inject content scripts into open Facebook tabs...');
  try {
    const tabs = await chrome.tabs.query({ url: ['*://*.facebook.com/*', '*://facebook.com/*'] });
    
    if (tabs.length === 0) {
      console.log('No open Facebook tabs found to inject scripts into.');
      return;
    }

    const scripts = [
      "expired_overlay.js",
      "content_core.js",
      "content_ui_progress.js",
      "content_ui_modals.js",
      "content_ui_elements.js",
      "content_main.js"
    ];

    console.log(`Found ${tabs.length} Facebook tabs. Injecting scripts:`, scripts);

    for (const tab of tabs) {
      // Skip if the tab is restricted (e.g. chrome:// URLs)
      if (!tab.url || tab.url.startsWith('chrome://') || tab.url.startsWith('edge://')) continue;

      try {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: scripts
        });
        console.log(`Successfully injected scripts into tab ${tab.id}`);
      } catch (err) {
        // Ignore errors for tabs where we can't inject (e.g. restricted domains that matched wildcard somehow, or closed tabs)
        console.warn(`Failed to inject scripts into tab ${tab.id}:`, err.message);
      }
    }
  } catch (error) {
    console.error('Error querying or injecting into tabs:', error);
  }
}

// Initialize unique installation ID on extension install/startup
chrome.runtime.onInstalled.addListener((details) => {
  console.log('Extension installed/updated - ensuring unique installation ID exists');
  InstallationIdManager.getUniqueInstallationId().then(id => {
    console.log('Unique installation ID initialized:', id);
  });

  // Start auto-share scheduler
  startAutoShareScheduler();

  // Inject scripts into open tabs if this is a fresh install or update
  // We do this for both install and update to ensure the latest scripts are running
  injectContentScriptsIntoFacebookTabs();
});

// Also initialize on startup
chrome.runtime.onStartup.addListener(() => {
  console.log('Extension startup - ensuring unique installation ID exists');
  InstallationIdManager.getUniqueInstallationId().then(id => {
    console.log('Unique installation ID confirmed:', id);
  });
  
  // Start auto-share scheduler on browser restart
  startAutoShareScheduler();
});

// Listen for messages from popup to start/stop scheduler
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Background script received message:', request.type);

  if (request.type === 'get_installation_id') {
    // Get installation ID for signup purposes
    InstallationIdManager.getUniqueInstallationId().then(uniqueId => {
      sendResponse({ installationId: uniqueId });
    });
    return true; // Indicates asynchronous response
  }

  if (request.type === 'start_auto_share') {
    startAutoShareScheduler().then(() => sendResponse({ success: true }));
    return true;
  }

  if (request.type === 'stop_auto_share') {
    stopAutoShareScheduler().then(() => sendResponse({ success: true }));
    return true;
  }

  if (request.type === 'get_auto_share_status') {
    chrome.storage.local.get(['autoShareConfig'], (result) => {
      sendResponse({ config: result.autoShareConfig || {} });
    });
    return true;
  }
  
  // All other form-filling message types have been removed.
});
