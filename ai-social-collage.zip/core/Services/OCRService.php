<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Logger;
use AiSocialCollage\Services\GeminiProvider;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class OCRService {
    const OPTION_OCR_PROVIDER = 'ai_collage_ocr_provider';
    const OCR_PROVIDER_GEMINI = 'gemini';
    const OCR_PROVIDER_SPACE = 'ocr_space';
    
    public function extract_text_from_media( $media_path, $media_type = 'image' ) {
        $provider = get_option( self::OPTION_OCR_PROVIDER, self::OCR_PROVIDER_GEMINI );
        
        switch ( $provider ) {
            case self::OCR_PROVIDER_GEMINI:
                return $this->gemini_ocr( $media_path, $media_type );
                
            case self::OCR_PROVIDER_SPACE:
                return $this->ocr_space_ocr( $media_path );
                
            default:
                throw new \Exception( 'Unsupported OCR provider: ' . $provider );
        }
    }
    
    private function gemini_ocr( $image_path, $media_type ) {
        $genAI = new GeminiProvider();
        $prompt = "
        Extract all visible text from this {$media_type}. Include:
        - Headings and titles
        - Body text and descriptions
        - Hashtags and mentions
        - URLs and website links
        - Any visible text on the {$media_type}
        
        Return structured JSON:
        {
            'headings': ['text1', 'text2'],
            'body_text': 'main content extracted',
            'hashtags': ['#tag1', '#tag2'],
            'mentions': ['@user1'],
            'urls': ['https://example.com'],
            'raw_text': 'all text found in order'
        }
        ";
        
        try {
            $result = AIProviderRegistry::execute( $genAI, '', $prompt, [
                'image_path' => $image_path,
                'caller' => 'OCRService::gemini_ocr',
            ] );
            Logger::info( Config::LOG_ACTION_OCR_EXTRACTED, null, [
                'image_path' => $image_path,
                'media_type' => $media_type,
                'text_extracted' => ! empty( $result['raw_text'] ),
            ], '200' );
            return $result;
        } catch ( \Exception $e ) {
            Logger::warning( 'gemini_ocr_failed', null, [
                'image_path' => $image_path,
                'error' => $e->getMessage(),
            ], '500' );
            return [
                'headings' => [],
                'body_text' => '',
                'hashtags' => [],
                'mentions' => [],
                'urls' => [],
                'raw_text' => '',
            ];
        }
    }
    
    private function ocr_space_ocr( $image_path ) {
        // OCR Space API implementation would go here
        // This is a placeholder for the actual implementation
        return [
            'headings' => [],
            'body_text' => '',
            'hashtags' => [],
            'mentions' => [],
            'urls' => [],
            'raw_text' => '',
        ];
    }
}