<?php

/**
 * Validation Warning UI - Admin Interface
 *
 * Displays validation issues with actionable options
 *
 * @package SEO_Article_Generator
 * @since   2.1.2
 */

namespace SEO_Article_Generator\Admin;

class Validation_Warning_UI
{

    /**
     * Render validation modal with issues
     *
     * @param array $validation_result Result from Truth_Validator::validate_truthfulness()
     * @param array $ai_output The generated content
     * @return void (outputs HTML)
     */
    public function render_validation_modal($validation_result, $ai_output)
    {
        $action = $validation_result['action'];
        $issues = $validation_result['issues'];

?>
        <div id="validation-warning-modal" class="validation-modal" data-action="<?php echo esc_attr($action); ?>">
            <div class="validation-modal-content">

                <!-- Header -->
                <div class="validation-modal-header <?php echo esc_attr($this->get_header_class($action)); ?>">
                    <span class="validation-icon"><?php echo $this->get_icon($action); ?></span>
                    <h2><?php echo esc_html($this->get_title($action)); ?></h2>
                </div>

                <!-- Issues List -->
                <div class="validation-modal-body">
                    <?php $this->render_grounding_context($validation_result['grounding'] ?? []); ?>

                    <p class="validation-description">
                        <?php echo esc_html($this->get_description($action, count($issues))); ?>
                    </p>

                    <div class="validation-issues-list">
                        <?php foreach ($issues as $index => $issue) : ?>
                            <?php $this->render_issue_card($issue, $index, $ai_output); ?>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Action Buttons -->
                <div class="validation-modal-footer">
                    <?php $this->render_action_buttons($action, $issues); ?>
                </div>

            </div>
        </div>

        <style>
            .validation-modal {
                position: fixed;
                z-index: 999999;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0, 0, 0, 0.7);
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .validation-modal-content {
                background-color: #fff;
                border-radius: 8px;
                width: 90%;
                max-width: 800px;
                max-height: 90vh;
                display: flex;
                flex-direction: column;
                box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
            }

            .validation-modal-header {
                padding: 20px;
                border-radius: 8px 8px 0 0;
                display: flex;
                align-items: center;
                gap: 12px;
            }

            .validation-modal-header.critical {
                background-color: #dc3232;
                color: #fff;
            }

            .validation-modal-header.error {
                background-color: #f56e28;
                color: #fff;
            }

            .validation-modal-header.warning {
                background-color: #ffb900;
                color: #000;
            }

            .validation-icon {
                font-size: 28px;
            }

            .validation-modal-header h2 {
                margin: 0;
                font-size: 20px;
            }

            .validation-modal-body {
                padding: 20px;
                overflow-y: auto;
                flex: 1;
            }

            .validation-description {
                margin-bottom: 20px;
                font-size: 14px;
                line-height: 1.6;
            }

            .validation-issues-list {
                display: flex;
                flex-direction: column;
                gap: 16px;
            }

            .validation-issue-card {
                border: 1px solid #ddd;
                border-radius: 6px;
                padding: 16px;
                background-color: #f9f9f9;
            }

            .validation-issue-card.critical {
                border-left: 4px solid #dc3232;
                background-color: #fff5f5;
            }

            .validation-issue-card.error {
                border-left: 4px solid #f56e28;
                background-color: #fff8f3;
            }

            .validation-issue-card.warning {
                border-left: 4px solid #ffb900;
                background-color: #fffef5;
            }

            .issue-header {
                display: flex;
                justify-content: space-between;
                align-items: start;
                margin-bottom: 12px;
            }

            .issue-field {
                font-weight: 600;
                font-size: 14px;
                color: #333;
            }

            .issue-severity-badge {
                padding: 4px 12px;
                border-radius: 12px;
                font-size: 11px;
                font-weight: 600;
                text-transform: uppercase;
            }

            .issue-severity-badge.critical {
                background-color: #dc3232;
                color: #fff;
            }

            .issue-severity-badge.error {
                background-color: #f56e28;
                color: #fff;
            }

            .issue-severity-badge.warning {
                background-color: #ffb900;
                color: #000;
            }

            .issue-message {
                margin-bottom: 12px;
                font-size: 14px;
                color: #555;
            }

            .issue-details {
                background-color: #fff;
                border: 1px solid #ddd;
                border-radius: 4px;
                padding: 12px;
                margin-bottom: 12px;
                font-family: 'Courier New', monospace;
                font-size: 12px;
            }

            .issue-details-row {
                margin-bottom: 8px;
            }

            .issue-details-row:last-child {
                margin-bottom: 0;
            }

            .issue-details-label {
                font-weight: 600;
                color: #666;
            }

            .issue-actions {
                display: flex;
                gap: 8px;
                flex-wrap: wrap;
            }

            .issue-action-btn {
                padding: 6px 14px;
                border: 1px solid #ddd;
                border-radius: 4px;
                background-color: #fff;
                cursor: pointer;
                font-size: 12px;
                transition: all 0.2s;
            }

            .issue-action-btn.primary {
                background-color: #2271b1;
                color: #fff;
                border-color: #2271b1;
            }

            .issue-action-btn:hover {
                opacity: 0.8;
            }

            .validation-modal-footer {
                padding: 20px;
                border-top: 1px solid #ddd;
                display: flex;
                gap: 12px;
                justify-content: flex-end;
            }

            .validation-footer-btn {
                padding: 10px 24px;
                border: none;
                border-radius: 4px;
                cursor: pointer;
                font-size: 14px;
                font-weight: 500;
                transition: all 0.2s;
            }

            .validation-footer-btn.cancel {
                background-color: #f0f0f0;
                color: #333;
            }

            .validation-footer-btn.edit {
                background-color: #2271b1;
                color: #fff;
            }

            .validation-footer-btn.proceed {
                background-color: #00a32a;
                color: #fff;
            }

            .validation-footer-btn.force-proceed {
                background-color: #f56e28;
                color: #fff;
            }

            .validation-footer-btn:hover {
                opacity: 0.85;
            }

            .validation-footer-btn:disabled {
                opacity: 0.5;
                cursor: not-allowed;
            }

            /* Grounding Context Styling */
            .validation-grounding-context {
                background: #f0f7ff;
                border: 1px solid #bae6fd;
                border-radius: 6px;
                padding: 12px 16px;
                margin-bottom: 20px;
                display: flex;
                flex-direction: column;
                gap: 8px;
            }

            .grounding-title {
                font-size: 11px;
                font-weight: 600;
                text-transform: uppercase;
                letter-spacing: 0.5px;
                color: #0369a1;
                display: flex;
                align-items: center;
                gap: 6px;
            }

            .grounding-links {
                display: flex;
                gap: 16px;
                flex-wrap: wrap;
            }

            .grounding-link {
                font-size: 13px;
                color: #2271b1;
                text-decoration: none;
                display: flex;
                align-items: center;
                gap: 4px;
            }

            .grounding-link:hover {
                text-decoration: underline;
            }
        </style>

        <script>
            jQuery(document).ready(function($) {
                // Auto-apply fixes
                $('.issue-action-btn[data-action="auto-fix"]').on('click', function() {
                    const issueIndex = $(this).data('issue-index');
                    const autoFix = $(this).data('auto-fix');

                    // Apply fix to hidden form fields or AI output object
                    console.log('Applying auto-fix:', autoFix);

                    // Update the AI output data
                    window.validationAutoFixes = window.validationAutoFixes || {};
                    window.validationAutoFixes[issueIndex] = autoFix;

                    // Mark as fixed
                    $(this).closest('.validation-issue-card')
                        .css('opacity', '0.6')
                        .prepend('<div class="auto-fix-applied">✓ Auto-fix applied</div>');

                    $(this).prop('disabled', true).text('Applied');
                });

                // Manual edit
                $('#validation-manual-edit-btn').on('click', function() {
                    // Close modal and populate form with current values
                    $('#validation-warning-modal').fadeOut();

                    // Scroll to first issue field in the editor
                    // (Implementation depends on your editor structure)
                    alert('Scroll to editor to manually fix issues');
                });

                // Cancel generation
                $('#validation-cancel-btn').on('click', function() {
                    if (confirm('Are you sure you want to discard this generated content?')) {
                        $('#validation-warning-modal').fadeOut();
                        // Reset form or navigate away
                        window.location.reload();
                    }
                });

                // Proceed with warnings
                $('#validation-proceed-btn').on('click', function() {
                    const action = $('#validation-warning-modal').data('action');

                    if (action === 'BLOCK_PUBLISHING') {
                        alert('Critical issues must be fixed before publishing.');
                        return;
                    }

                    // Apply all auto-fixes
                    if (window.validationAutoFixes) {
                        // Merge fixes into AI output
                        console.log('Applying fixes:', window.validationAutoFixes);
                    }

                    // Proceed with publishing
                    $('#validation-warning-modal').fadeOut();

                    // Trigger actual content save
                    $('#publish-article-btn').click();
                });

                // Force proceed (override)
                $('#validation-force-proceed-btn').on('click', function() {
                    const confirmation = confirm(
                        'WARNING: You are about to publish content with critical issues. ' +
                        'This may violate Google\'s guidelines and result in penalties. ' +
                        '\n\nAre you absolutely sure?'
                    );

                    if (confirmation) {
                        const doubleConfirmation = prompt(
                            'Type "I UNDERSTAND THE RISKS" to proceed:'
                        );

                        if (doubleConfirmation === 'I UNDERSTAND THE RISKS') {
                            $('#validation-warning-modal').fadeOut();
                            $('#seo-gen-publish').click();
                        }
                    }
                });
            });
        </script>
    <?php
    }

    /**
     * Render individual issue card
     */
    private function render_issue_card($issue, $index, $ai_output)
    {
        $severity = $issue['severity'];
    ?>
        <div class="validation-issue-card <?php echo esc_attr($severity); ?>" data-issue-index="<?php echo esc_attr($index); ?>">

            <div class="issue-header">
                <div class="issue-field">
                    📍 <?php echo esc_html(ucwords(str_replace('_', ' ', $issue['field']))); ?>
                </div>
                <span class="issue-severity-badge <?php echo esc_attr($severity); ?>">
                    <?php echo esc_html($severity); ?>
                </span>
            </div>

            <div class="issue-message">
                <?php echo esc_html($issue['message']); ?>
            </div>

            <?php if (! empty($issue['details'])) : ?>
                <div class="issue-details">
                    <?php $this->render_issue_details($issue['details']); ?>
                </div>
            <?php endif; ?>

            <?php if (! empty($issue['suggested_fix'])) : ?>
                <div class="issue-suggested-fix">
                    <strong>💡 Suggested Fix:</strong> <?php echo esc_html($issue['suggested_fix']); ?>
                </div>
            <?php endif; ?>

            <div class="issue-actions">
                <?php if (! empty($issue['auto_fix'])) : ?>
                    <button
                        class="issue-action-btn primary"
                        data-action="auto-fix"
                        data-issue-index="<?php echo esc_attr($index); ?>"
                        data-auto-fix="<?php echo esc_attr(json_encode($issue['auto_fix'])); ?>">
                        ⚡ Apply Auto-Fix
                    </button>
                <?php endif; ?>
            </div>

        </div>
    <?php
    }

    /**
     * Render issue details (expected vs. got, etc.)
     */
    private function render_issue_details($details)
    {
        foreach ($details as $key => $value) {
            if (is_array($value)) {
                echo '<div class="issue-details-row">';
                echo '<span class="issue-details-label">' . esc_html(ucwords(str_replace('_', ' ', $key))) . ':</span><br>';
                foreach ($value as $sub_key => $sub_value) {
                    echo '&nbsp;&nbsp;• ' . esc_html($sub_key) . ': ' . esc_html($sub_value) . '<br>';
                }
                echo '</div>';
            } else {
                echo '<div class="issue-details-row">';
                echo '<span class="issue-details-label">' . esc_html(ucwords(str_replace('_', ' ', $key))) . ':</span> ';
                echo esc_html($value);
                echo '</div>';
            }
        }
    }

    /**
     * Render action buttons based on validation result
     */
    private function render_action_buttons($action, $issues)
    {
    ?>
        <button id="validation-cancel-btn" class="validation-footer-btn cancel">
            ✕ Discard Content
        </button>

        <button id="validation-manual-edit-btn" class="validation-footer-btn edit">
            ✎ Edit Manually
        </button>

        <?php if ($action !== 'BLOCK_PUBLISHING') : ?>
            <button id="validation-proceed-btn" class="validation-footer-btn proceed">
                ✓ Apply Fixes & Proceed
            </button>
        <?php endif; ?>

        <?php if ($action === 'BLOCK_PUBLISHING') : ?>
            <button id="validation-force-proceed-btn" class="validation-footer-btn force-proceed">
                ⚠️ Override & Publish Anyway
            </button>
        <?php endif; ?>
    <?php
    }

    /**
     * Get header CSS class based on action
     */
    private function get_header_class($action)
    {
        switch ($action) {
            case 'BLOCK_PUBLISHING':
                return 'critical';
            case 'REQUIRE_MANUAL_REVIEW':
                return 'error';
            case 'WARN_BEFORE_PUBLISHING':
                return 'warning';
            default:
                return '';
        }
    }

    /**
     * Get icon based on action
     */
    private function get_icon($action)
    {
        switch ($action) {
            case 'BLOCK_PUBLISHING':
                return '🛑';
            case 'REQUIRE_MANUAL_REVIEW':
                return '⚠️';
            case 'WARN_BEFORE_PUBLISHING':
                return '⚡';
            default:
                return 'ℹ️';
        }
    }

    /**
     * Get title based on action
     */
    private function get_title($action)
    {
        switch ($action) {
            case 'BLOCK_PUBLISHING':
                return 'Critical Issues Detected – Publishing Blocked';
            case 'REQUIRE_MANUAL_REVIEW':
                return 'Content Requires Manual Review';
            case 'WARN_BEFORE_PUBLISHING':
                return 'Content Generated with Warnings';
            default:
                return 'Validation Results';
        }
    }

    /**
     * Get description based on action
     */
    private function get_description($action, $issue_count)
    {
        switch ($action) {
            case 'BLOCK_PUBLISHING':
                return sprintf(
                    'AI generated content with %d critical issue(s) that must be resolved before publishing. ' .
                        'These violations could result in Google penalties.',
                    $issue_count
                );
            case 'REQUIRE_MANUAL_REVIEW':
                return sprintf(
                    '%d issue(s) detected that require your review. You can apply auto-fixes, edit manually, or proceed with warnings.',
                    $issue_count
                );
            case 'WARN_BEFORE_PUBLISHING':
                return sprintf(
                    '%d warning(s) detected. Review the issues below and decide whether to proceed or make corrections.',
                    $issue_count
                );
            default:
                return 'Review the validation results below.';
        }
    }

    /**
     * Render Source of Truth / Grounding Links
     *
     * @param array $grounding
     * @return void
     */
    private function render_grounding_context($grounding)
    {
        if (empty($grounding['changelog_url']) && empty($grounding['homepage_url'])) {
            return;
        }
    ?>
        <div class="validation-grounding-context">
            <div class="grounding-title">
                <span class="dashicons dashicons-admin-links" style="font-size:16px;width:16px;height:16px;"></span>
                Grounding Truth: Sources Used for Validation
            </div>
            <div class="grounding-links">
                <?php if (! empty($grounding['changelog_url'])) : ?>
                    <a href="<?php echo \esc_url($grounding['changelog_url']); ?>" target="_blank" class="grounding-link">
                        🔍 View Changelog Source ↗
                    </a>
                <?php endif; ?>

                <?php if (! empty($grounding['homepage_url'])) : ?>
                    <a href="<?php echo \esc_url($grounding['homepage_url']); ?>" target="_blank" class="grounding-link">
                        🏠 Official Homepage ↗
                    </a>
                <?php endif; ?>
            </div>
        </div>
<?php
    }
}
