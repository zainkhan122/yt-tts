<?php

namespace DIT\TrendStudio\Content\Media;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * MediaSelector
 *
 * Phase 2: Selects a high-signal subset of images (default 15) and builds
 * a context-rich visual map used by PromptBuilder and token swap-back.
 *
 * @package DIT_TrendStudio
 * @since 2.10.0
 */
class MediaSelector
{
    /**
     * Tokenize <img> tags into [VISUAL_N] while selecting only the best $limit.
     *
     * @param string $html
     * @param int    $limit
     * @param string $vertical
     * @return array { html:string, visual_map:array, stats:array }
     */
    public static function tokenize_images(string $html, int $limit = 15, string $vertical = ''): array
    {
        $html = (string) $html;
        if (trim($html) === '') {
            return [
                'html'       => $html,
                'visual_map' => [],
                'stats'      => ['candidates' => 0, 'selected' => 0],
            ];
        }

        // @MODIFIED 2026-02-17 - Support [embed], <iframe>, and social <blockquote> tokenization
        // This ensures they are treated as "must-have" visuals and not lost.
        $pattern = '/(<img[^>]+?\b(?:src|data-src|data-lazy-src)=\\\\?["\'](.*?)\\\\?["\'][^>]*>|\[embed\](.*?)\[\/embed\]|<iframe[^>]+src=\\\\?["\'](.*?)\\\\?["\'][^>]*>.*?<\/iframe>|<iframe[^>]+src=\\\\?["\'](.*?)\\\\?["\'][^>]*\/>|<blockquote class=\\\\?["\'][^"\'\\\\]*instagram-media[^"\'\\\\]*\\\\?["\'][^>]*>.*?<\/blockquote>|<blockquote class=\\\\?["\'][^"\'\\\\]*twitter-tweet[^"\'\\\\]*\\\\?["\'][^>]*>.*?<\/blockquote>|<blockquote class=\\\\?["\'][^"\'\\\\]*tiktok-embed[^"\'\\\\]*\\\\?["\'][^>]*>.*?<\/blockquote>)/is';

        if (!preg_match_all($pattern, $html, $m, PREG_OFFSET_CAPTURE)) {
            return [
                'html'       => $html,
                'visual_map' => [],
                'stats'      => ['candidates' => 0, 'selected' => 0],
            ];
        }

        $candidates = [];
        $seen = [];

        for ($i = 0; $i < count($m[0]); $i++) {
            $tag   = self::decode_ai_string($m[1][$i][0] ?? '');

            // @MODIFIED 2026-02-17 - Embeds might not have a simple src group in the same position
            // We iterate through possible capture groups for the URL/Content
            $url = '';
            foreach ([2, 3, 4, 5] as $g) {
                if (!empty($m[$g][$i][0])) {
                    $url = self::decode_ai_string($m[$g][$i][0]);
                    break;
                }
            }

            // If it's a blockquote or embed without extracted URL, use the tag as the identifier
            if ($url === '' && (stripos($tag, '<blockquote') !== false || stripos($tag, '[embed]') !== false)) {
                $url = 'embed:' . md5($tag); // distinct fake URL for dedupe
            }

            $pos   = (int) ($m[0][$i][1] ?? 0);
            $len   = strlen((string) ($m[0][$i][0] ?? ''));

            if ($tag === '') {
                continue;
            }

            // @MODIFIED 2026-02-22 - Explicitly track type for scoring/rendering
            $type = 'image';
            if (stripos($tag, '<blockquote') !== false || stripos($tag, '[embed]') !== false || stripos($tag, '<iframe') !== false) {
                $type = 'embed';
            }

            // Filter obvious junk early
            if (self::is_junk_image($url)) {
                continue;
            }

            $att_id = 0;
            if (function_exists('attachment_url_to_postid')) {
                $att_id = (int) attachment_url_to_postid($url);
            }

            $path = $url !== '' ? (string) (parse_url($url, PHP_URL_PATH) ?: '') : '';
            $file = $path !== '' ? basename($path) : '';

            $dedupe_key = $att_id > 0 ? ('att:' . $att_id) : ($file !== '' ? ('file:' . strtolower($file)) : ('url:' . md5(strtolower($url))));
            if (isset($seen[$dedupe_key])) {
                continue;
            }
            $seen[$dedupe_key] = true;

    $alt = '';
    if (preg_match('/alt=["\']([^"\'\\\\]*)["\']/i', $tag, $am)) {
        $alt = (string) $am[1];
    }

    // @MODIFIED 2026-05-12 - Hero-First: Extract dimensions from HTML
    $width = 0;
    $height = 0;
    if (preg_match('/\bwidth=["\'](\d+)["\']/i', $tag, $wm)) {
        $width = (int) $wm[1];
    }
    if (preg_match('/\bheight=["\'](\d+)["\']/i', $tag, $hm)) {
        $height = (int) $hm[1];
    }

    // @MODIFIED 2026-05-12 - Hero-First: Enrich with WP metadata if available
    if ($att_id > 0) {
        $metadata = wp_get_attachment_metadata($att_id);
        if (is_array($metadata)) {
            if (!empty($metadata['width'])) {
                $width = (int) $metadata['width'];
            }
            if (!empty($metadata['height'])) {
                $height = (int) $metadata['height'];
            }
        }
    }

    $para_index = self::count_before($html, '<p', $pos) + 1;

    $heading_info = self::last_heading_before($html, $pos);
    $heading_text = (string) ($heading_info['text'] ?? '');
    $heading_lvl = (int) ($heading_info['level'] ?? 0);

    $ctx = self::context_window($html, $pos, 300);

    $score = self::score_candidate([
        'url' => $url,
        'file' => $file,
        'alt' => $alt,
        'heading' => $heading_text,
        'heading_lvl' => $heading_lvl,
        'context' => $ctx,
        'para_index' => $para_index,
        'vertical' => $vertical,
        'att_id' => $att_id,
        'type' => $type, // @MODIFIED 2026-02-22 - Pass type for scoring
        'width' => $width, // @MODIFIED 2026-05-12 - Hero-First
        'height' => $height, // @MODIFIED 2026-05-12 - Hero-First
    ]);

    $candidates[] = [
        'i' => $i,
        'pos' => $pos,
        'len' => $len,
        'url' => $url,
        'tag' => $tag,
        'alt' => $alt,
        'file' => $file,
        'att_id' => $att_id,
        'para_index' => $para_index,
        'heading' => $heading_text,
        'heading_lvl' => $heading_lvl,
        'context' => $ctx,
        'score' => $score,
        'type' => $type, // @MODIFIED 2026-02-22 - Store type
        'width' => $width, // @MODIFIED 2026-05-12 - Hero-First
        'height' => $height, // @MODIFIED 2026-05-12 - Hero-First
    ];
        }

        if (empty($candidates)) {
            return [
                'html'       => $html,
                'visual_map' => [],
                'stats'      => ['candidates' => 0, 'selected' => 0],
            ];
        }

        $selected = self::select($candidates, $limit, $vertical);

        // Build index lookup for fast replacement
        $sel_by_match_index = [];
        foreach ($selected as $k => $cand) {
            $sel_by_match_index[(int) $cand['i']] = (int) $k; // token index
        }

        // Replace from end to start for safe offsets
        usort($candidates, static function ($a, $b) {
            return (int) $b['pos'] <=> (int) $a['pos'];
        });

        $visual_map = [];
        foreach ($candidates as $cand) {
            $match_i = (int) $cand['i'];
            $start   = (int) $cand['pos'];
            $length  = (int) $cand['len'];

            if (isset($sel_by_match_index[$match_i])) {
                $tidx  = (int) $sel_by_match_index[$match_i];
                $token = '[VISUAL_' . $tidx . ']';

                $visual_map[$token] = [
                    'url'          => (string) $cand['url'],
                    'tag'          => (string) $cand['tag'],
                    'alt'          => (string) $cand['alt'],
                    'file'         => (string) $cand['file'],
                    'attachment_id' => (int) $cand['att_id'],
                    'para_index'   => (int) $cand['para_index'],
                    'heading'      => (string) $cand['heading'],
                    'context'      => (string) $cand['context'],
                    'score'        => (float) $cand['score'],
                    'type'         => (string) $cand['type'], // @MODIFIED 2026-02-22 - Use explicit type
                ];

                $html = substr_replace($html, $token, $start, $length);
            } else {
                // Cull non-selected images completely (keeps AI input lean)
                $html = substr_replace($html, '', $start, $length);
            }
        }

        return [
            'html'       => $html,
            'visual_map' => $visual_map,
            'stats'      => ['candidates' => count($candidates), 'selected' => count($visual_map)],
        ];
    }

    private static function select(array $candidates, int $limit, string $vertical): array
    {
        $limit = max(1, min(30, (int) $limit));

        // Sort by score desc as baseline
        $sorted = $candidates;
        usort($sorted, static function ($a, $b) {
            $sa = (float) ($a['score'] ?? 0);
            $sb = (float) ($b['score'] ?? 0);
            if ($sa === $sb) {
                // Prefer earlier in document if tied
                return (int) ($a['pos'] ?? 0) <=> (int) ($b['pos'] ?? 0);
            }
            return ($sb <=> $sa);
        });

        $picked = [];
        $used_i = [];

        $pick_best = static function (callable $filter) use (&$sorted, &$picked, &$used_i) {
            foreach ($sorted as $cand) {
                $i = (int) $cand['i'];
                if (isset($used_i[$i])) {
                    continue;
                }
                if ($filter($cand)) {
                    $picked[] = $cand;
                    $used_i[$i] = true;
                    return true;
                }
            }
            return false;
        };

        // Reserve first two tokens to be “early narrative” for both fashion/showbiz
        $pick_best(static function ($c) {
            return (int) ($c['para_index'] ?? 999) === 1;
        });
        $pick_best(static function ($c) {
            return (int) ($c['para_index'] ?? 999) === 2;
        });

        // Fashion: prefer one-per-H3 section (dress showcase) in document order
        if (strpos((string) $vertical, 'fashion') !== false) {
            $h3_keys = [];
            usort($candidates, static function ($a, $b) {
                return (int) $a['pos'] <=> (int) $b['pos'];
            });
            foreach ($candidates as $cand) {
                if ((int) ($cand['heading_lvl'] ?? 0) !== 3) {
                    continue;
                }
                $hk = strtolower(trim((string) ($cand['heading'] ?? '')));
                if ($hk === '' || isset($h3_keys[$hk])) {
                    continue;
                }
                $h3_keys[$hk] = true;

                $pick_best(static function ($c) use ($hk) {
                    return strtolower(trim((string) ($c['heading'] ?? ''))) === $hk;
                });

                if (count($picked) >= $limit) {
                    break;
                }
            }
        }

        // Fill remaining by score
        foreach ($sorted as $cand) {
            $i = (int) $cand['i'];
            if (isset($used_i[$i])) {
                continue;
            }
            $picked[] = $cand;
            $used_i[$i] = true;
            if (count($picked) >= $limit) {
                break;
            }
        }

        // Final order defines token indices: ensure stable narrative order by position
        usort($picked, static function ($a, $b) {
            return (int) ($a['pos'] ?? 0) <=> (int) ($b['pos'] ?? 0);
        });

        // Re-index tokens after ordering
        return array_values($picked);
    }

    private static function score_candidate(array $c): float
    {
        $score = 0.0;

    $file = strtolower((string) ($c['file'] ?? ''));
    $alt = trim((string) ($c['alt'] ?? ''));
    $hd = trim((string) ($c['heading'] ?? ''));
    $ctx = trim((string) ($c['context'] ?? ''));
    $pi = (int) ($c['para_index'] ?? 999);
    $vl = (string) ($c['vertical'] ?? '');

    // @MODIFIED 2026-05-12 - Hero-First: Extract dimensions
    $width = (int) ($c['width'] ?? 0);
    $height = (int) ($c['height'] ?? 0);
    $is_portrait = ($height > 0 && $width > 0 && $height > $width);
    
    // @MODIFIED 2026-05-12/13 - Persona-Based Thresholds (AUDIT-BACKED FIX)
    // Based on real image analysis: Fashion=97% portrait, Showbiz=28% portrait
    $vertical_lower = strtolower((string) ($c['vertical'] ?? ''));
    $is_fashion = (strpos($vertical_lower, 'fashion') !== false);
    $is_showbiz = (strpos($vertical_lower, 'showbiz') !== false);
    
    // Universal junk filter (reject tiny images for all personas)
    $is_tiny = ($height > 0 && $height < 200) || ($width > 0 && $width < 300);
    if ($is_tiny) {
        $is_embed = (($c['type'] ?? '') === 'embed' || strpos((string) ($c['url'] ?? ''), 'embed:') === 0);
        if (!$is_embed) {
            return -1000.0; // Hard cull for tiny non-embeds
        }
    }
    
    // Fashion PK: Strict portrait requirement (H>W, H>=700px)
    // Audit result: 97% of fashion images are portrait, avg 723x999px
    if ($is_fashion) {
        $is_hero_portrait = ($is_portrait && $height >= 700);
        if (!$is_hero_portrait) {
            $is_embed = (($c['type'] ?? '') === 'embed' || strpos((string) ($c['url'] ?? ''), 'embed:') === 0);
            if (!$is_embed) {
                return -1000.0; // Reject non-portrait fashion images
            }
        }
        if ($is_hero_portrait) {
            $score += 50.0; // Portrait bonus
        }
    } 
    // Showbiz PK: Lenient thresholds (H>=400px OR W>=600px)
    // Audit result: Only 28% portrait, 72% landscape. Avg 985x718px
    elseif ($is_showbiz) {
        $is_acceptable = ($height >= 400 || $width >= 600);
        if (!$is_acceptable) {
            $is_embed = (($c['type'] ?? '') === 'embed' || strpos((string) ($c['url'] ?? ''), 'embed:') === 0);
            if (!$is_embed) {
                return -1000.0; // Reject tiny showbiz images
            }
        }
        // Bonus for larger, portrait images
        if ($is_portrait && $height >= 700) {
            $score += 50.0; // Premium showbiz content
        } elseif ($is_portrait) {
            $score += 25.0; // Standard portrait
        } elseif ($width >= 800) {
            $score += 15.0; // Good landscape
        }
    }
    // Default (other personas): Moderate threshold
    else {
        $is_hero_portrait = ($is_portrait && $height >= 700);
        if ($is_hero_portrait) {
            $score += 50.0;
        }
    }

    if ($pi <= 3) {
        $score += 3.0; // earlier narrative weight
    }

    if ($alt !== '') {
        $score += min(6.0, (float) (strlen($alt) / 18));
    }

    if ($hd !== '') {
        $score += 2.0;
    }

    if ($ctx !== '') {
        $score += min(4.0, (float) (strlen($ctx) / 120));
    }

    if ($file !== '' && !self::is_junk_filename($file)) {
        $score += 1.5;
    }

    // Fashion: reward H3 adjacency (dress showcase)
    if (strpos($vl, 'fashion') !== false && (int) ($c['heading_lvl'] ?? 0) === 3) {
        $score += 3.0;
    }

    // Penalize obvious junk patterns
    if (self::is_junk_filename($file)) {
        $score -= 8.0;
    }

    // @MODIFIED 2026-02-22 - Embeds are "Must Have" content (Instagram/YouTube/IFRAME)
    // Check both prefix (legacy) and explicit type (preferred)
    if (($c['type'] ?? '') === 'embed' || strpos((string) ($c['url'] ?? ''), 'embed:') === 0) {
        $score += 50.0;
    }

    return $score;
    }

    private static function is_junk_image(string $url): bool
    {
        $u = strtolower($url);
        if ($u === '') {
            return true;
        }
        if (preg_match('/\.(svg|gif)$/i', $u)) {
            return true;
        }
        foreach (['logo', 'icon', 'sprite', 'pixel', 'tracker', 'avatar', 'emoji', 'spacer', 'blank', '1x1'] as $k) {
            if (strpos($u, $k) !== false) {
                return true;
            }
        }
        return false;
    }

    private static function is_junk_filename(string $file): bool
    {
        $f = strtolower($file);
        if ($f === '') {
            return true;
        }
        foreach (['logo', 'icon', 'sprite', 'pixel', 'tracker', 'avatar', 'emoji', 'spacer', 'blank', '1x1'] as $k) {
            if (strpos($f, $k) !== false) {
                return true;
            }
        }
        return false;
    }

    private static function last_heading_before(string $html, int $pos): array
    {
        $before = substr($html, 0, max(0, $pos));
        if ($before === '') {
            return ['level' => 0, 'text' => ''];
        }

        if (!preg_match_all('/<h([1-6])[^>]*>(.*?)<\/h\\1>/is', $before, $hm)) {
            return ['level' => 0, 'text' => ''];
        }

        $idx  = count($hm[0]) - 1;
        $lvl  = (int) ($hm[1][$idx] ?? 0);
        $text = (string) ($hm[2][$idx] ?? '');
        $text = self::strip_text($text);

        return ['level' => $lvl, 'text' => $text];
    }

    private static function context_window(string $html, int $pos, int $radius = 240): string
    {
        $start = max(0, $pos - $radius);
        $end   = min(strlen($html), $pos + $radius);

        $chunk = substr($html, $start, $end - $start);
        $chunk = self::strip_text($chunk);

        // Keep it short and useful
        if (strlen($chunk) > 260) {
            $chunk = substr($chunk, 0, 260);
        }
        return $chunk;
    }

    private static function count_before(string $haystack, string $needle, int $pos): int
    {
        if ($pos <= 0) {
            return 0;
        }
        return substr_count(substr($haystack, 0, $pos), $needle);
    }

    private static function strip_text(string $html): string
    {
        $txt = function_exists('wp_strip_all_tags') ? wp_strip_all_tags($html) : strip_tags($html);
        $txt = preg_replace('/\s+/', ' ', (string) $txt);
        return trim((string) $txt);
    }

    private static function decode_ai_string(string $s): string
    {
        if (class_exists('\DIT\TrendStudio\Security\Sanitizer')) {
            return (string) \DIT\TrendStudio\Security\Sanitizer::decode_ai_string($s);
        }
        return stripslashes($s);
    }
}
