/**
 * PWA Service Worker - Static Bootstrapper
 * @version 2.0
 *
 * This file is COPIED to the website root as 'sw.js'.
 * It dynamically imports its configuration to stay up-to-date.
 *
 * @MODIFIED: Now imports from a physical /pwa-config.js file.
 */

// Dynamically import the configuration.
try {
    // ✅ FIX: Import from a physical JS file, not a PHP virtual file
    importScripts('/pwa-config.js');
} catch (e) {
    console.error('NM PWA: Failed to import config. Offline capabilities may be limited.', e);
    // Define fallbacks in case import fails
    var staticCacheName = 'nm-static-fallback';
    var dynamicCacheName = 'nm-dynamic-fallback';
    var staticAssets = ['/'];
}

// Now, 'staticCacheName', 'dynamicCacheName', and 'staticAssets'
// are available globally in this worker from the importScripts() call.

self.addEventListener('install', event => {
    console.log('NM PWA: Service Worker installing...');
    event.waitUntil(
        caches.open(staticCacheName).then(cache => {
            console.log('NM PWA: Precaching static assets.');
            return cache.addAll(staticAssets);
        }).catch(err => {
            console.error('NM PWA: Static cache addAll failed', err);
        })
    );
    self.skipWaiting();
});

self.addEventListener('activate', event => {
    console.log('NM PWA: Service Worker activating...');
    event.waitUntil(
        caches.keys().then(keys => {
            return Promise.all(
                keys.filter(key => key !== staticCacheName && key !== dynamicCacheName)
                    .map(key => {
                        console.log('NM PWA: Deleting old cache:', key);
                        return caches.delete(key);
                    })
            );
        })
    );
    return self.clients.claim();
});

self.addEventListener('fetch', event => {
    // Only handle GET requests
    if (event.request.method !== 'GET') {
        return;
    }

    // Don't cache admin, ajax, or post requests
    if (event.request.url.indexOf('/wp-admin/') > -1 ||
        event.request.url.indexOf('/wp-login.php') > -1 ||
        event.request.url.indexOf('admin-ajax.php') > -1) {
        return;
    }

    // ✅ MODIFIED: Network-First strategy for HTML navigation (fixes stale nonces)
    if (event.request.mode === 'navigate') {
        event.respondWith(
            fetch(event.request).then(fetchRes => {
                return caches.open(dynamicCacheName).then(cache => {
                    if (fetchRes.status === 200) {
                        cache.put(event.request.url, fetchRes.clone());
                    }
                    return fetchRes;
                });
            }).catch(() => {
                // If offline, fall back to cache
                return caches.match(event.request);
            })
        );
        return;
    }

    // Default: Cache-First strategy for static assets (images, css, js)
    event.respondWith(
        caches.match(event.request).then(cacheRes => {
            // 1. Return from cache if found
            if (cacheRes) {
                return cacheRes;
            }

            // 2. Not in cache, fetch from network
            return fetch(event.request).then(fetchRes => {
                // 3. Store valid responses in the dynamic cache
                return caches.open(dynamicCacheName).then(cache => {
                    // Check for valid response (e.g., no 500 errors)
                    if (fetchRes.status === 200) {
                        cache.put(event.request.url, fetchRes.clone());
                    }
                    return fetchRes;
                });
            });
        }).catch(() => {
            // 4. Offline fallback (optional)
        })
    );
});