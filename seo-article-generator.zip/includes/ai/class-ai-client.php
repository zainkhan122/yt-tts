<?php

/**
 * AI Client (Facade)
 *
 * @package SEO_Article_Generator
 */

namespace SEO_Article_Generator\AI;

use SEO_Article_Generator\AI_Exception;
use SEO_Article_Generator\AI\AI_Rate_Limit_Exception;
use SEO_Article_Generator\AI\API_Error_Parser;
use SEO_Article_Generator\AI\API_Error_Info;
use SEO_Article_Generator\AI\Quota_State_Manager;
use SEO_Article_Generator\Logger;
use SEO_Article_Generator\Validation\Truth_Validator;
use SEO_Article_Generator\AI\Providers\Gemini_Provider;
use SEO_Article_Generator\AI\Providers\Perplexity_Provider;
use SEO_Article_Generator\AI\Providers\OpenAI_Provider;
use SEO_Article_Generator\AI\Providers\Groq_Provider;
use SEO_Article_Generator\AI\Providers\OpenRouter_Provider;
use SEO_Article_Generator\AI\Providers\Custom_Provider;
use SEO_Article_Generator\AI\Providers\Provider_Interface;
use SEO_Article_Generator\AI\Provider_Registry;
use SEO_Article_Generator\Utils\Plugin_Time;

// Prevent direct access
if (! defined('ABSPATH')) {
	exit;
}

/**
 * AI API client for Gemini and Perplexity integration
 *
 * Refactored in 2.13.5 to use Provider pattern.
 */
class AI_Client
{

	/**
	 * @var string
	 */
	private $provider_name;

	/**
	 * @var string
	 */
	private $api_key;

	/**
	 * @var Logger
	 */
	private $logger;

	/**
	 * @var Provider_Interface
	 */
	private $provider;

	/**
	 * Request execution context forwarded to providers (used to derive a stable
	 * OpenCode Zen session id for a generation job). Carries at least 'job_id'.
	 *
	 * @var array
	 * @since 2.34.4
	 */
	private $request_context = array();

/**
 * @var array Compact HTTP trace from last request
 */
 private $last_http_trace = array();

 /**
 * @var bool Signals execute_safe_request() that this is a scout (non-generation) call.
 */
 private $_is_scout_call = false;

	/**
	 * Available Perplexity Sonar models
	 */
	public const PERPLEXITY_MODELS = array(
		'sonar'               => 'Sonar (Lightweight)',
		'sonar-pro'           => 'Sonar Pro (Advanced)',
		'sonar-reasoning-pro' => 'Sonar Reasoning Pro (CoT)',
		'sonar-deep-research' => 'Sonar Deep Research (Expert)',
	);

private const MODEL_REGISTRY = array(
	'gemini' => array(
		// Stable models (routed via v1beta endpoint)
		'gemini-3.5-flash' => true,
		'gemini-2.0-flash' => true,
		'gemini-2.0-flash-001' => true,
		'gemini-2.5-flash' => true,
		'gemini-2.5-pro' => true,
	),
		'openai' => array(
			'gpt-4o-mini' => true,
			'gpt-4o' => true,
			'gpt-4-turbo' => true,
			'gpt-3.5-turbo' => true,
		),
	'groq' => array(
		'openai/gpt-oss-120b' => true,
		'openai/gpt-oss-20b' => true,
		'llama-3.3-70b-versatile' => true,
		'qwen/qwen3-32b' => true,
		'meta-llama/llama-4-scout-17b-16e-instruct' => true,
		'llama-3.1-8b-instant' => true,
	),
	'perplexity' => array(
		'sonar' => true,
		'sonar-pro' => true,
		'sonar-reasoning-pro' => true,
		'sonar-deep-research' => true,
	),
	'openrouter' => array(
		'nvidia/nemotron-3-super-120b-a12b:free' => true,
		'inclusionai/ling-2.6-1t:free' => true,
		'qwen/qwen3-next-80b-a3b-instruct:free' => true,
		'google/gemma-4-31b-it:free' => true,
		'google/gemma-4-26b-a4b-it:free' => true,
		'meta-llama/llama-3.3-70b-instruct:free' => true,
	),
);

	/**
	 * Gemini model TPM limits (April 2026 registry - verified stable models only)
	 */
	private const GEMINI_MODEL_LIMITS = array(
		'gemini-3.5-flash' => 1000000,
		'gemini-2.0-flash' => 1000000,
		'gemini-2.0-flash-001' => 1000000,
		'gemini-2.5-flash' => 1000000,
		'gemini-2.5-pro' => 1000000,
	);

/**
 * Gemini endpoint version mapping (v1beta for full feature set)
 */
private const GEMINI_ENDPOINT_VERSION = array(
    'gemini-3.5-flash' => 'v1beta',
    'gemini-2.0-flash' => 'v1beta',
    'gemini-2.0-flash-001' => 'v1beta',
    'gemini-2.5-flash' => 'v1beta',
    'gemini-2.5-pro' => 'v1beta',
);

	private const GROQ_MODEL_LIMITS = array(
		'openai/gpt-oss-120b' => 30000,
		'openai/gpt-oss-20b' => 30000,
		'llama-3.3-70b-versatile' => 12000,
		'qwen/qwen3-32b' => 12000,
		'meta-llama/llama-4-scout-17b-16e-instruct' => 500000,
		'llama-3.1-8b-instant' => 30000,
	);

	private const OPENROUTER_MODEL_LIMITS = array(
		'nvidia/nemotron-3-super-120b-a12b:free' => 32768,
		'inclusionai/ling-2.6-1t:free' => 32768,
		'qwen/qwen3-next-80b-a3b-instruct:free' => 32768,
		'google/gemma-4-31b-it:free' => 32768,
		'google/gemma-4-26b-a4b-it:free' => 32768,
		'meta-llama/llama-3.3-70b-instruct:free' => 32768,
	);

	/**
	 * Phase 3F (2.34.0): transport-timeout (cURL 28) model parking thresholds.
	 * TIMEOUT_STRIKE_LIMIT timeouts within TIMEOUT_STRIKE_WINDOW seconds park the
	 * model for TIMEOUT_COOLDOWN_SECONDS via the cooldown SSOT.
	 */
	public const TIMEOUT_STRIKE_LIMIT   = 3;
	public const TIMEOUT_STRIKE_WINDOW  = 900;   // 15 min rolling window
	public const TIMEOUT_COOLDOWN_SECONDS = 900; // park for 15 min

	/**
	 * Phase 3Q (2.34.13): Provider Circuit Breaker thresholds.
	 *
	 * Inspired by OmniRoute's 3-layer resilience model (Provider Circuit Breaker,
	 * Connection Cooldown, Model Lockout).  Our plugin has a single key per
	 * provider and background jobs (not real-time streaming), so we implement
	 * the circuit breaker layer only — the other two are handled by our existing
	 * per-model cooldown/misconfigured system.
	 *
	 * States: CLOSED (normal) → OPEN (provider skipped) with exponential backoff.
	 * Lazy recovery: after cooldown expires, next request is a half-open probe.
	 * Success-decay: each success halves the failure count (OmniRoute pattern).
	 *
	 * Only trips on PROVIDER-LEVEL failures (5xx, transport timeouts).
	 * Model-level failures (429, 401, 403, 404) use the existing per-model
	 * cooldown/misconfigured system and do NOT trip the circuit breaker.
	 */
	public const CB_OPEN_THRESHOLD        = 3;   // failures before opening
	public const CB_WINDOW_SECONDS        = 3600; // 1 hour failure window (must exceed max cooldown)
	public const CB_BASE_COOLDOWN         = 300;  // 5 min first open
	public const CB_MAX_COOLDOWN          = 3600; // 1 hour cap
	public const CB_BACKOFF_MULTIPLIER    = 2;    // exponential escalation

    public static function get_supported_models(string $provider): array
    {
        return array_keys(self::MODEL_REGISTRY[$provider] ?? array());
    }

    public static function is_supported_model(string $provider, string $model): bool
    {
        return isset(self::MODEL_REGISTRY[$provider][trim($model)]);
    }

public static function get_default_model_for_provider(string $provider): string
    {
        switch ($provider) {
            case 'openai':
                return 'gpt-4o-mini';
		case 'groq':
			return 'openai/gpt-oss-120b';
		case 'perplexity':
			return 'sonar-pro';
		case 'openrouter':
			return 'nvidia/nemotron-3-super-120b-a12b:free';
		case 'gemini':
		default:
			return 'gemini-2.0-flash';
        }
    }

	public static function resolve_provider_model(string $provider, string $model = ''): array
	{
		$provider = strtolower(trim($provider));
		$model = trim($model);

		if (!in_array($provider, self::get_all_providers(), true)) {
			return array('ok' => false, 'provider' => $provider, 'model' => $model, 'reason' => 'unknown_provider');
		}

		if ($model === '') {
			$model = self::get_default_model_for_provider($provider);
		}

		// Gemini: strict validation unless mode is explicitly 'custom'
		if ($provider === 'gemini') {
			$gemini_mode = self::get_gemini_model_mode();
			if ($gemini_mode !== 'custom') {
				// Not in custom mode: must be a verified model
				if (!self::is_supported_model('gemini', $model)) {
					return array(
						'ok' => false,
						'provider' => $provider,
						'model' => $model,
						'reason' => 'unsupported_model',
					);
				}
				return array('ok' => true, 'provider' => $provider, 'model' => $model);
			}
			// Custom mode: allow any non-empty model
			if ($model === '') {
				return array(
					'ok' => false,
					'provider' => $provider,
					'model' => $model,
					'reason' => 'empty_custom_model',
				);
			}
			return array('ok' => true, 'provider' => $provider, 'model' => $model);
		}

		// Non-Gemini providers: allow custom models with warning
		if (!self::is_supported_model($provider, $model)) {
			error_log(
				sprintf(
					'[SEO Gen] Custom model "%s" for provider "%s" is not in registry. Proceeding with user-specified value.',
					$model,
					$provider
				)
			);
		}

		return array('ok' => true, 'provider' => $provider, 'model' => $model);
	}

	public static function get_fallback_candidates(): array
    {
        if (self::is_provider_only_mode_enabled()) {
            return array();
        }

        $candidates = array();

        foreach (self::get_active_providers() as $provider) {
            $data = self::get_provider_details($provider);

            // Custom providers rotate through ALL their configured models internally
            // (see Custom_Provider::chat_completion_retry_loop). Emit a single candidate
            // keyed to the first currently-ready model to avoid re-walking the same
            // provider once per model in the outer loop.
            if (!empty($data['available']) && !empty($data['model_valid'])) {
                $candidates[] = array(
                    'provider' => $provider,
                    'model'    => $data['model'],
                );
            }
        }

        return $candidates;
    }

    public static function get_generation_snapshot(): array
    {
        $providers       = array();
        $routable        = array();
        $temporary_block = array();
        $hard_block      = array();
        $min_retry_after = 0;

        foreach (self::get_active_providers() as $provider) {
            $data   = self::get_provider_details($provider);
            $reason = 'ready';

            if (empty($data['enabled'])) {
                $reason = 'disabled';
            } elseif (empty($data['key_present'])) {
                $reason = 'missing_key';
            } elseif (empty($data['model_valid'])) {
                $reason = 'invalid_model';
            } elseif (($data['state'] ?? '') === 'misconfigured') {
                $reason = 'misconfigured';
            } elseif (($data['state'] ?? '') === 'cooldown') {
                $reason = 'cooldown';
            } elseif (empty($data['available'])) {
                $reason = 'unavailable';
            }

            $row = array(
                'provider'    => (string) $provider,
                'model'       => (string) ($data['model'] ?? ''),
                'enabled'     => !empty($data['enabled']),
                'available'   => !empty($data['available']),
                'reason'      => $reason,
                'retry_after' => (int) ($data['retry_after'] ?? 0),
            );

            $providers[] = $row;

            if ($row['available']) {
                $routable[] = $row;
                continue;
            }

            if ($reason === 'cooldown') {
                $temporary_block[] = $row;
                if ($row['retry_after'] > 0 && ($min_retry_after === 0 || $row['retry_after'] < $min_retry_after)) {
                    $min_retry_after = $row['retry_after'];
                }
                continue;
            }

            if ($reason !== 'disabled') {
                $hard_block[] = $row;
            }
        }

        return array(
            'providers'           => $providers,
            'routable'            => $routable,
            'bootstrap_provider'  => (string) ($routable[0]['provider'] ?? ''),
            'temporary_blocked'   => $temporary_block,
            'hard_blocked'        => $hard_block,
            'min_retry_after'     => max(0, (int) $min_retry_after),
        );
    }

    /**
     * Get provider status summary for Job_Handler preflight checks.
     *
     * PHASE 5: Single source for provider/availability state.
     * Returns canonical DTO with all fields consumers need - no recomputation required.
     *
     * @return array{
     *   paused: int,
     *   reason: string,
     *   until: int,
     *   resume_diff: string,
     *   providers_detail: array,
     *   enabled_count: int,
     *   routable: array,
     *   temporary_blocked: array,
     *   hard_blocked: array,
     *   min_retry_after: int,
     *   bootstrap_provider: string,
     * }
     */
    public static function get_provider_status(): array {
        $snapshot = self::get_generation_snapshot();
        $providers_detail = array();
        foreach ($snapshot['providers'] ?? array() as $row) {
            $providers_detail[] = array(
                'provider'    => $row['provider'] ?? '',
                'model'       => $row['model'] ?? '',
                'enabled'     => !empty($row['enabled']),
                'available'   => !empty($row['available']),
                'reason'      => $row['reason'] ?? '',
                'retry_after' => max(0, (int)($row['retry_after'] ?? 0)),
            );
        }
        $enabled_count = count(array_filter($providers_detail, function($p) {
            return !empty($p['enabled']) && !empty($p['available']);
        }));
        
        $now = Plugin_Time::now_utc_ts();
        
        // PHASE 5 FIX: Derive canonical top-level reason and until from blocking providers
        // ONLY if there are no routable providers available.
        $until = 0;
        $reason = '';
        $temp_blocked = $snapshot['temporary_blocked'] ?? array();
        
        if (empty($snapshot['routable'])) {
            // Find the blocking provider with the SHORTEST retry horizon
            foreach ($temp_blocked as $blocked) {
                $retry_after = max(0, (int) ($blocked['retry_after'] ?? 0));
                $blocked_until = $now + $retry_after;
                if ($until === 0 || $blocked_until < $until) {
                    $until = $blocked_until;
                    $reason = (string) ($blocked['reason'] ?? 'cooldown');
                }
            }
            
            // If no temporary blocks but hard blocks exist, report that
            if ($until === 0 && !empty($snapshot['hard_blocked'])) {
                $reason = (string) ($snapshot['hard_blocked'][0]['reason'] ?? 'unavailable');
            }
        }
        
        $resume_diff = '';
        if ($until > $now) {
            $local_now = $now;
            $local_until = $until;
            // Use anonymous function for human_time_diff context
            $resume_diff = human_time_diff($local_now, $local_until);
        }
        
        // PHASE 5: Include all fields needed by consumers - no recomputation required
        return array(
            'paused'              => empty($snapshot['routable']) ? 1 : 0,
            'reason'              => $reason,
            'until'               => $until,
            'resume_diff'         => $resume_diff,
            'providers_detail'    => $providers_detail,
            'enabled_count'       => $enabled_count,
            'routable'            => $snapshot['routable'] ?? array(),
            'temporary_blocked'   => $temp_blocked,
            'hard_blocked'        => $snapshot['hard_blocked'] ?? array(),
            'min_retry_after'     => $snapshot['min_retry_after'] ?? 0,
            'bootstrap_provider'  => $snapshot['bootstrap_provider'] ?? '',
        );
    }

    /**
     * Get daily quota status.
     *
     * PHASE 5: Single source for quota state.
     *
     * @return array{
     *   enabled: int,
     *   limit: int,
     *   used: int,
     *   remaining: int,
     *   day: string,
     *   reset_utc_ts: int,
     * }
     */
    public static function get_daily_quota_status(): array {
        $defaults = \SEO_Article_Generator\Option_Registry::defaults();
        $provider = \get_option(
            \SEO_Article_Generator\Option_Registry::API_PROVIDER,
            $defaults[\SEO_Article_Generator\Option_Registry::API_PROVIDER]
        );
        $reset_ts = (int)\get_transient(self::daily_quota_transient_key($provider));
        $now_utc = \SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts();
        if ($reset_ts === 0 || $reset_ts > $now_utc) {
            $reset_ts = $reset_ts ?: $now_utc;
        }
        $daily_quota = max(0, (int)\get_option(
            \SEO_Article_Generator\Option_Registry::DAILY_QUOTA,
            $defaults[\SEO_Article_Generator\Option_Registry::DAILY_QUOTA]
        ));
        $quota_key = 'seogen_ai_checks_' . \SEO_Article_Generator\Utils\Plugin_Time::site_today_ymd();
        $quota_used = max(0, (int)\get_transient($quota_key));
        return array(
            'enabled'     => $daily_quota > 0 ? 1 : 0,
            'limit'      => $daily_quota,
            'used'       => $quota_used,
            'remaining' => $daily_quota > 0 ? max(0, $daily_quota - $quota_used) : 0,
            'day'        => \SEO_Article_Generator\Utils\Plugin_Time::site_today_ymd(),
            'reset_utc_ts' => $reset_ts,
        );
    }

    /**
     * Transient key for daily quota reset.
     *
     * @param string $provider
     * @return string
     */
    private static function daily_quota_transient_key(string $provider): string {
        return 'seogen_daily_quota_reset_' . \sanitize_key($provider);
    }

    /**
     * Set daily quota block.
     *
     * PHASE 5: Single source for quota blocking.
     *
     * @param string $reason
     * @param int $api_reset_ts
     */
    public static function set_daily_quota_block(string $reason = '', int $api_reset_ts = 0): void {
        $defaults = \SEO_Article_Generator\Option_Registry::defaults();
        $provider = \get_option(
            \SEO_Article_Generator\Option_Registry::API_PROVIDER,
            $defaults[\SEO_Article_Generator\Option_Registry::API_PROVIDER]
        );
        $key = self::daily_quota_transient_key($provider);
        $now_utc = \SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts();

        if ($api_reset_ts >= $now_utc + 60) {
            $reset_ts = $api_reset_ts;
        } else {
            $reset_ts = ('gemini' === $provider)
                ? Quota_Reset_Calculator::gemini_next_rpd_reset_ts($now_utc)
                : Quota_Reset_Calculator::generic_next_reset_ts($now_utc);
        }

        $existing = (int) \get_transient($key);
        if ($existing > $reset_ts) {
            return;
        }

        $duration = max(3600, $reset_ts - $now_utc - 300);
        \set_transient($key, $reset_ts, $duration);
    }

    /**
     * Determine whether an error reason indicates daily quota exhaustion.
     *
     * PHASE 5: Single source for quota classification.
     *
     * @param string $reason
     * @return bool
     */
    public static function is_daily_quota_error(string $reason): bool
    {
        $decoded = @json_decode($reason, true);
        if (is_array($decoded) && !empty($decoded['error'])) {
            $body_str = is_string($reason) ? $reason : wp_json_encode($decoded);
            $info = API_Error_Parser::parse('gemini', 429, $body_str);
            if ($info->is_daily_quota()) {
                return true;
            }
        }

        if (stripos($reason, 'Daily Quota Exhausted') !== false) {
            return true;
        }

        return false;
    }

	/**
	 * Get Gemini API key
	 *
	 * @return string
	 */
	public static function get_gemini_key()
	{
		return trim(\get_option('seo_gen_gemini_api_key', ''));
	}

	/**
	 * Get Gemini Model Name with optional intra-Gemini fallback chain
	 *
	 * @MODIFIED 2026-04-21 - Added fallback chain support matching Groq implementation
	 * @param bool $forceFallback Force fallback chain within Gemini models
	 * @param string|null $currentModel The currently failing model to base fallback on
	 * @return string
	 */
	public static function get_gemini_model($forceFallback = false, $currentModel = null)
	{
		$mode = self::get_gemini_model_mode();
		$primaryModel = $mode === 'custom' ? self::get_gemini_custom_model() : $mode;
		$primaryModel = trim((string) \apply_filters('seo_gen_use_model', $primaryModel));

		if ($primaryModel === '') {
			$primaryModel = self::get_default_model_for_provider('gemini');
		}

		$fallbackEnabled = (bool) \get_option(
			\SEO_Article_Generator\Option_Registry::GEMINI_FALLBACK,
			\SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::GEMINI_FALLBACK]
		);

		$resolved = self::resolve_provider_model('gemini', $primaryModel);
		$normalized = !empty($resolved['ok'])
			? (string) $resolved['model']
			: self::get_default_model_for_provider('gemini');

		// Self-heal: ensure seo_gen_gemini_model matches normalized value
		$storedEffective = trim((string) \get_option(
			\SEO_Article_Generator\Option_Registry::GEMINI_MODEL,
			\SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::GEMINI_MODEL]
		));
		if ($storedEffective !== $normalized) {
			\update_option(\SEO_Article_Generator\Option_Registry::GEMINI_MODEL, $normalized, false);
		}

		// Intra-Gemini fallback chain — verified stable, non-Pro models only.
		// Pro models are intentionally excluded: they have stricter rate limits
		// and higher cost, so they are valid as a user-selected primary but
		// should never be silently injected as a fallback during 429/5xx.
		if ($fallbackEnabled && $forceFallback) {
			$chainBase = $currentModel ?? $normalized;

			$chain = array(
				'gemini-3.5-flash'   => 'gemini-2.5-flash',
				'gemini-2.5-flash'   => 'gemini-2.0-flash',
				'gemini-2.0-flash'   => 'gemini-2.0-flash-001',
				'gemini-2.0-flash-001' => null,
			);

			if (array_key_exists($chainBase, $chain)) {
				if ($chain[$chainBase] !== null) {
					return $chain[$chainBase];
				}
				return $chainBase;
			}

			return $normalized;
		}

		return $normalized;
	}

	/**
	 * Get Gemini model mode (verified ID or 'custom')
	 *
	 * @return string
	 */
	public static function get_gemini_model_mode(): string
	{
		$defaults = \SEO_Article_Generator\Option_Registry::defaults();
		$mode = trim((string) \get_option(
			\SEO_Article_Generator\Option_Registry::GEMINI_MODEL_MODE,
			$defaults[\SEO_Article_Generator\Option_Registry::GEMINI_MODEL_MODE]
		));

		if ($mode === 'custom') {
			return 'custom';
		}

		// Validate: must be a supported model or revert to default
		return self::is_supported_model('gemini', $mode) ? $mode : self::get_default_model_for_provider('gemini');
	}

	/**
	 * Get Gemini custom model value (only used when mode is 'custom')
	 *
	 * @return string
	 */
	public static function get_gemini_custom_model(): string
	{
		$defaults = \SEO_Article_Generator\Option_Registry::defaults();
		return trim((string) \get_option(
			\SEO_Article_Generator\Option_Registry::GEMINI_CUSTOM_MODEL,
			$defaults[\SEO_Article_Generator\Option_Registry::GEMINI_CUSTOM_MODEL]
		));
	}

	/**
	 * Get Gemini API endpoint URL with version routing
	 *
	 * @param string $model Model identifier
	 * @return string Full API endpoint URL
	 */
	public static function get_gemini_endpoint(string $model): string
	{
		$version = self::GEMINI_ENDPOINT_VERSION[$model] ?? 'v1beta';
		return "https://generativelanguage.googleapis.com/{$version}/models/{$model}:generateContent";
	}

/**
 * Available Gemini models (April 2026 registry - verified stable models only)
 *
 * @return array
 */
public static function get_gemini_models()
{
return array(
'gemini-3.5-flash' => 'Gemini 3.5 Flash (Stable model, routed via v1beta)',
'gemini-2.0-flash' => 'Gemini 2.0 Flash (Stable model, routed via v1beta)',
'gemini-2.0-flash-001' => 'Gemini 2.0 Flash 001 (Stable model, routed via v1beta)',
'gemini-2.5-flash' => 'Gemini 2.5 Flash (Stable model, routed via v1beta)',
'gemini-2.5-pro' => 'Gemini 2.5 Pro (Stable model, routed via v1beta)',
);
}

	/**
	 * Get Perplexity API key
	 *
	 * @return string
	 */
	public static function get_perplexity_key()
	{
		return trim(\get_option('seo_gen_perplexity_api_key', ''));
	}

	/**
	 * Get selected Perplexity model
	 *
	 * @return string
	 */
	public static function get_perplexity_model()
	{
		$model = trim((string) \apply_filters(
			'seo_gen_use_model',
			\get_option('seo_gen_perplexity_model', 'sonar-pro')
		));

		$resolved = self::resolve_provider_model('perplexity', $model);
		if (!empty($resolved['ok'])) {
			return (string) $resolved['model'];
		}

		return self::get_default_model_for_provider('perplexity');
	}

	/**
	 * Get OpenAI API key
	 *
	 * @return string
	 */
	public static function get_openai_key()
	{
		return trim(\get_option('seo_gen_openai_api_key', ''));
	}

	/**
	 * Get OpenAI model
	 *
	 * @return string
	 */
	public static function get_openai_model()
	{
		$model = trim((string) \apply_filters(
			'seo_gen_use_model',
			\get_option('seo_gen_openai_model', 'gpt-4o-mini')
		));

		$resolved = self::resolve_provider_model('openai', $model);
		if (!empty($resolved['ok'])) {
			return (string) $resolved['model'];
		}

		return self::get_default_model_for_provider('openai');
	}

	/**
	 * Available OpenAI models
	 *
	 * @return array
	 */
	public static function get_openai_models()
	{
		return array(
			'gpt-4o-mini' => 'GPT-4o Mini',
			'gpt-4o'      => 'GPT-4o',
		);
	}

	/**
	 * Get Groq API key
	 *
	 * @return string
	 */
	public static function get_groq_key()
	{
		return trim(\get_option('seo_gen_groq_api_key', ''));
	}

	/**
	 * Get Groq preferred model
	 *
	 * @param bool $forceFallback Force fallback chain within Groq models
	 * @param string|null $currentModel The currently failing model to base fallback on
	 * @return string
	 */
	public static function get_groq_model($forceFallback = false, $currentModel = null)
	{
	$primaryModel = (string) \get_option('seo_gen_groq_model', 'openai/gpt-oss-120b');
	$primaryModel = trim((string) \apply_filters('seo_gen_use_model', $primaryModel));

	$fallbackEnabled = (bool) \get_option('seo_gen_groq_fallback', 0);

	$resolved = self::resolve_provider_model('groq', $primaryModel);
	$normalized = !empty($resolved['ok'])
		? (string) $resolved['model']
		: self::get_default_model_for_provider('groq');

	if ($normalized !== $primaryModel) {
		\update_option('seo_gen_groq_model', $normalized, false);
	}

	if ($fallbackEnabled && $forceFallback) {
		$chainBase = $currentModel ?? $normalized;

		$chain = array(
			'openai/gpt-oss-120b' => 'openai/gpt-oss-20b',
			'openai/gpt-oss-20b' => 'llama-3.3-70b-versatile',
			'llama-3.3-70b-versatile' => 'qwen/qwen3-32b',
			'qwen/qwen3-32b' => 'meta-llama/llama-4-scout-17b-16e-instruct',
			'meta-llama/llama-4-scout-17b-16e-instruct' => 'llama-3.1-8b-instant',
			'llama-3.1-8b-instant' => null,
		);

		if (isset($chain[$chainBase]) && $chain[$chainBase] !== null) {
			return $chain[$chainBase];
		}

		return $normalized;
	}

	return $normalized;
	}

	public static function get_groq_models()
	{
		return array(
			'openai/gpt-oss-120b' => 'GPT-OSS 120B (Primary Writing, json_schema)',
			'openai/gpt-oss-20b' => 'GPT-OSS 20B (Fast Drafting, json_schema)',
			'llama-3.3-70b-versatile' => 'Llama 3.3 70B (Versatile Fallback)',
			'qwen/qwen3-32b' => 'Qwen3 32B (Creative Alternative)',
			'meta-llama/llama-4-scout-17b-16e-instruct' => 'Llama 4 Scout 17B (High TPM)',
			'llama-3.1-8b-instant' => 'Llama 3.1 8B (Ultra-Fast Draft)',
		);
	}

	public static function get_openrouter_key(): string
	{
		return (string) \get_option('seo_gen_openrouter_api_key', '');
	}

	public static function get_openrouter_model($forceFallback = false, $currentModel = null)
	{
		$primaryModel = (string) \get_option('seo_gen_openrouter_model', 'nvidia/nemotron-3-super-120b-a12b:free');
		$primaryModel = trim((string) \apply_filters('seo_gen_use_model', $primaryModel));

		$fallbackEnabled = (bool) \get_option('seo_gen_openrouter_fallback', 0);

		$resolved = self::resolve_provider_model('openrouter', $primaryModel);
		$normalized = !empty($resolved['ok'])
			? (string) $resolved['model']
			: self::get_default_model_for_provider('openrouter');

		if ($normalized !== $primaryModel) {
			\update_option('seo_gen_openrouter_model', $normalized, false);
		}

		if ($fallbackEnabled && $forceFallback) {
			$chainBase = $currentModel ?? $normalized;

			$chain = array(
				'nvidia/nemotron-3-super-120b-a12b:free' => 'inclusionai/ling-2.6-1t:free',
				'inclusionai/ling-2.6-1t:free' => 'qwen/qwen3-next-80b-a3b-instruct:free',
				'qwen/qwen3-next-80b-a3b-instruct:free' => 'google/gemma-4-31b-it:free',
				'google/gemma-4-31b-it:free' => 'meta-llama/llama-3.3-70b-instruct:free',
				'meta-llama/llama-3.3-70b-instruct:free' => null,
			);

			if (isset($chain[$chainBase]) && $chain[$chainBase] !== null) {
				return $chain[$chainBase];
			}

			return $normalized;
		}

		return $normalized;
	}

	public static function get_openrouter_models()
	{
		return array(
			'nvidia/nemotron-3-super-120b-a12b:free' => 'Nemotron 3 Super 120B (Free, 262K ctx)',
			'inclusionai/ling-2.6-1t:free' => 'Ling 2.6 1T (Free, Long Context)',
			'qwen/qwen3-next-80b-a3b-instruct:free' => 'Qwen3 Next 80B (Free, Research)',
			'google/gemma-4-31b-it:free' => 'Gemma 4 31B (Free, Balanced)',
			'google/gemma-4-26b-a4b-it:free' => 'Gemma 4 26B (Free, Fast)',
	'meta-llama/llama-3.3-70b-instruct:free' => 'Llama 3.3 70B (Free, Fallback)',
	);
}

	/**
	* Shared Provider Registry Contract
	 * Returns all provider IDs known to the software architecture.
	 */
	public static function get_all_providers(): array
	{
		$registry = Provider_Registry::get_instance();
		return $registry->get_all_ids();
	}

	/**
	 * Whether provider-only mode is enabled (no fallback chain).
	 *
	 * @return bool
	 */
	public static function is_provider_only_mode_enabled(): bool
	{
		return (bool) \get_option('seo_gen_provider_only_mode', false);
	}

	/**
	 * Get the locked provider ID when provider-only mode is active.
	 *
	 * @return string
	 */
	public static function get_locked_provider_id(): string
	{
		$provider = \strtolower(\trim((string) \get_option('seo_gen_api_provider', 'gemini')));

		return \in_array($provider, self::get_all_providers(), true) ? $provider : 'gemini';
	}

	/**
	 * Canonical Provider Resolution DTO
	 * Returns a standardized array shape for any provider's architectural state.
	 */
	public static function get_provider_details(string $provider_id): array
	{
		$allowed = self::get_all_providers();
		if (!\in_array($provider_id, $allowed, true)) {
			return array('id' => $provider_id, 'enabled' => false, 'ok' => false);
		}

		$registry = Provider_Registry::get_instance();

		if ($registry->is_custom($provider_id)) {
			return self::get_custom_provider_details($provider_id, $registry);
		}

		$model = '';
		$key   = '';
		switch ($provider_id) {
			case 'gemini':
				$model = self::get_gemini_model();
				$key   = self::get_gemini_key();
				break;
			case 'openai':
				$model = self::get_openai_model();
				$key   = self::get_openai_key();
				break;
		case 'groq':
			$model = self::get_groq_model();
			$key = self::get_groq_key();
			break;
		case 'perplexity':
			$model = self::get_perplexity_model();
			$key = self::get_perplexity_key();
			break;
		case 'openrouter':
			$model = self::get_openrouter_model();
			$key = self::get_openrouter_key();
			break;
	}

		$enabled = '1' === (string)\get_option('seo_gen_enable_' . $provider_id, '1');
		$misconfigured = self::is_provider_misconfigured($provider_id, $model);

	$cooldown_ts_model = (int)\get_transient(self::get_provider_cooldown_key($provider_id, $model));
	$cooldown_ts_provider = (int)\get_transient(self::get_provider_cooldown_key($provider_id));
	$cooldown = max($cooldown_ts_model, $cooldown_ts_provider);

	$now = Plugin_Time::now_utc_ts();
	$state = 'ready';

	// @MODIFIED 2026-04-07: Hard Reset Override (Bypass Object Cache lag)
	$last_reset = (int) \get_option('seo_gen_last_manual_reset', 0);
	if ($last_reset > 0 && ($now - $last_reset) < 45) {
		$cooldown = 0;
		$misconfigured = false;
	}


	$resolved = self::resolve_provider_model($provider_id, $model);

	// Daily quota check: if the provider's daily quota transient is set,
	// mark it as cooldown so it is excluded from fallback candidates.
	$daily_quota_key     = self::daily_quota_transient_key( $provider_id );
	$daily_quota_reset   = (int) \get_transient( $daily_quota_key );
	$daily_quota_blocked = $daily_quota_reset > $now;

	// Hard Reset Override: also clear daily quota block within 45s of manual reset
	if ($last_reset > 0 && ($now - $last_reset) < 45) {
		$daily_quota_blocked = false;
	}

	// [2.34.13] Phase 3Q: Check circuit breaker state.
	// If the breaker is OPEN, the provider is effectively in cooldown.
	$cb_state = self::cb_can_execute( $provider_id );
	if ( ! $cb_state['allowed'] ) {
		$cb_retry = (int) $cb_state['retry_after'];
		if ( $cb_retry > 0 ) {
			$cooldown = max( $cooldown, $now + $cb_retry );
		}
	}

	if (!$resolved['ok']) {
		$state = 'invalid_model';
	} elseif ($misconfigured) {
		$state = 'misconfigured';
	} elseif ($daily_quota_blocked) {
		$state    = 'cooldown';
		$cooldown = max( $cooldown, $daily_quota_reset );
	} elseif ($cooldown > $now) {
		$state = 'cooldown';
	}

		return array(
			'id'          => $provider_id,
			'model'       => $resolved['ok'] ? $resolved['model'] : $model,
			'model_valid' => $resolved['ok'],
			'enabled'     => $enabled,
			'key_present' => !empty($key),
			'available'   => ($state === 'ready' && $enabled && !empty($key)),
			'state'       => $state,
			'retry_after' => ($state === 'cooldown') ? max(1, $cooldown - $now) : 0,
		);
	}

	private static function get_custom_provider_details(string $provider_id, Provider_Registry $registry): array {
		$profile = $registry->get_custom_profile($provider_id);
		$models = array_values(array_filter((array)($profile['models'] ?? []), function ($m) {
			return !empty($m['model_id']);
		}));
		$key = $profile['api_key'] ?? '';

		$enabled = !empty($profile['id']);

		$now = Plugin_Time::now_utc_ts();

		$last_reset = (int) \get_option('seo_gen_last_manual_reset', 0);
		$hard_reset = ($last_reset > 0 && ($now - $last_reset) < 45);

		// Evaluate every model so newly added models (saved in seo_gen_custom_providers)
		// are picked up automatically on the next snapshot read.
		$available_models = array();
		$any_misconfigured = true;
		$any_cooldown = 0;

		foreach ($models as $m) {
			$mid = (string) ($m['model_id'] ?? '');

			$misconfigured = $hard_reset ? false : self::is_provider_misconfigured($provider_id, $mid);

			$cooldown_ts_model = (int)\get_transient(self::get_provider_cooldown_key($provider_id, $mid));
			$cooldown_ts_provider = (int)\get_transient(self::get_provider_cooldown_key($provider_id));
			$cooldown = max($cooldown_ts_model, $cooldown_ts_provider);
			if ($hard_reset) {
				$cooldown = 0;
			}

			$model_state = 'ready';
			if ($misconfigured) {
				$model_state = 'misconfigured';
			} elseif ($cooldown > $now) {
				$model_state = 'cooldown';
				$any_cooldown = max($any_cooldown, $cooldown - $now);
			} else {
				$any_misconfigured = false;
			}

			$available_models[] = array(
				'model_id'    => $mid,
				'state'       => $model_state,
				'available'   => ($model_state === 'ready'),
				'retry_after' => ($model_state === 'cooldown') ? max(1, $cooldown - $now) : 0,
			);
		}

		// Provider is blocked ONLY when every model is individually misconfigured.
		$misconfigured = $any_misconfigured && !empty($models);

		// Choose the first ready model as the canonical model (used for the snapshot
		// and for single-model consumers). If none ready but some in cooldown, report
		// the soonest-clearing model so the snapshot still reflects a routable target
		// once cooldown lifts.
		$model = '';
		$state = 'ready';
		$cooldown = 0;
		if (!empty($models)) {
			$ready = null;
			$soonest = null;
			foreach ($available_models as $am) {
				if ($am['available'] && $ready === null) {
					$ready = $am;
				}
				if ($am['state'] === 'cooldown' && ($soonest === null || $am['retry_after'] < $soonest['retry_after'])) {
					$soonest = $am;
				}
			}
			if ($ready !== null) {
				$model = $ready['model_id'];
				$state = 'ready';
			} elseif ($soonest !== null) {
				$model = $soonest['model_id'];
				$state = 'cooldown';
				$cooldown = $soonest['retry_after'];
			} else {
				// All models misconfigured.
				$model = (string) ($models[0]['model_id'] ?? '');
				$state = 'misconfigured';
			}
		}

		return array(
			'id'              => $provider_id,
			'model'           => $model,
			'model_valid'     => !empty($model),
			'enabled'         => $enabled,
			'key_present'     => !empty($key),
			'available'       => ($state === 'ready' && $enabled && !empty($key) && !empty($model)),
			'state'           => $state,
			'retry_after'     => ($state === 'cooldown') ? max(1, $cooldown) : 0,
			'available_models' => $available_models,
		);
	}

	/**
	 * Shared Provider Registry Contract
	 * Returns only providers that are enabled and ordered by user preference.
	 */
	public static function get_active_providers(): array
	{
		if (self::is_provider_only_mode_enabled()) {
			$primary = self::get_locked_provider_id();
			$data    = self::get_provider_details($primary);

			return !empty($data['enabled']) ? array($primary) : array();
		}

		$raw_order = \get_option('seo_gen_provider_fallback_order', self::get_all_providers());
		if (\is_string($raw_order)) {
			$raw_order = \array_map('trim', \explode(',', $raw_order));
		}

		$allowed = self::get_all_providers();
		$clean = array();

		$primary = \get_option('seo_gen_api_provider', 'gemini');
		$p_data  = self::get_provider_details($primary);
		if ($p_data['enabled']) {
			$clean[] = $primary;
		}

		foreach ((array)$raw_order as $provider) {
			$provider = \strtolower(\trim($provider));
			if (\in_array($provider, $allowed, true) && !\in_array($provider, $clean, true)) {
				$data = self::get_provider_details($provider);
				if ($data['enabled']) {
					$clean[] = $provider;
				}
			}
		}

		$registry = Provider_Registry::get_instance();
		foreach ($registry->get_custom_providers() as $profile) {
			$custom_id = $profile['id'] ?? '';
			if ($custom_id !== '' && !\in_array($custom_id, $clean, true)) {
				$data = self::get_provider_details($custom_id);
				if ($data['enabled']) {
					$clean[] = $custom_id;
				}
			}
		}

		// Guaranteed Gemini backstop: when the primary is a custom/OpenRouter
		// provider and its free-tier models exhaust, the built-in Gemini provider
		// must still be reachable as a cross-provider fallback. It is only appended
		// when it is enabled AND has a resolvable API key, so a keyless install is
		// never offered a dead candidate. (Skipped entirely in provider-only mode,
		// which returns above.)
		if (!\in_array('gemini', $clean, true)) {
			$gemini_data = self::get_provider_details('gemini');
			if (!empty($gemini_data['enabled']) && !empty($gemini_data['key_present'])) {
				$clean[] = 'gemini';
			}
		}

		return $clean;
	}

	/**
	 * Shared Provider Registry Contract
	 * Returns only providers that are enabled AND have valid keys AND are not in cooldown.
	 */
	public static function get_routable_providers(): array
	{
		$providers = self::get_active_providers();

		return array_values(array_filter($providers, static function (string $provider): bool {
			$data = self::get_provider_details($provider);
			return ! empty($data['available']);
		}));
	}

	/**
	 * Get the fallback chain 
	 */
	public static function get_fallback_chain()
	{
		return self::get_fallback_candidates();
	}

	/**
	 * API Metrics: Get the option key for storing metrics.
	 */
	private static function get_api_metrics_option_key(): string
	{
		return 'seo_gen_api_metrics_v1';
	}

	/**
	 * API Metrics: Load and normalize metrics from the option store.
	 */
	private static function load_api_metrics(): array
	{
		$raw = get_option(self::get_api_metrics_option_key(), array());

		if (!is_array($raw)) {
			$raw = array();
		}

		$today = Plugin_Time::site_today_ymd();
		$all_providers = self::get_all_providers();

		if (($raw['day'] ?? '') !== $today) {
			$raw['day'] = $today;
			$raw['providers'] = $raw['providers'] ?? array();

			foreach ($all_providers as $provider) {
				$row = $raw['providers'][$provider] ?? array();
				$row['attempts_today'] = 0;
				$row['success_today']  = 0;
				$row['failures_today'] = 0;
				$row['last_status']    = (int) ($row['last_status'] ?? 0);
				$row['last_error_at']  = (int) ($row['last_error_at'] ?? 0);
				$raw['providers'][$provider] = $row;
			}
		}

		foreach ($all_providers as $provider) {
			if (!isset($raw['providers'][$provider]) || !is_array($raw['providers'][$provider])) {
				$raw['providers'][$provider] = array();
			}

			$raw['providers'][$provider] = array_merge(
				array(
					'attempts_today' => 0,
					'attempts_total' => 0,
					'success_today'  => 0,
					'success_total'  => 0,
					'failures_today' => 0,
					'failures_total' => 0,
					'last_status'    => 0,
					'last_error_at'  => 0,
				),
				$raw['providers'][$provider]
			);
		}

		return $raw;
	}

	/**
	 * API Metrics: Persist metrics to the option store.
	 */
	private static function save_api_metrics(array $metrics): void
	{
		\update_option(self::get_api_metrics_option_key(), $metrics, false);
	}

	/**
	 * Metric buffer for reducing DB writes during retry loops
	 * @var array
	 */
	private static $metric_buffer = [];

	/**
	 * Buffer a metric for batched write
	 */
	private static function buffer_metric(string $provider, string $field): void
	{
		$provider = \sanitize_key($provider);
		if (!isset(self::$metric_buffer[$provider])) {
			self::$metric_buffer[$provider] = [];
		}
		if (!isset(self::$metric_buffer[$provider][$field])) {
			self::$metric_buffer[$provider][$field] = 0;
		}
		self::$metric_buffer[$provider][$field]++;
	}

	/**
	 * Flush buffered metrics to DB - called once per request lifecycle
	 */
	private static function flush_metric_buffer(): void
	{
		if (empty(self::$metric_buffer)) {
			return;
		}

		$metrics = self::load_api_metrics();

		foreach (self::$metric_buffer as $provider => $fields) {
			if (!isset($metrics['providers'][$provider])) {
				continue;
			}
			foreach ($fields as $field => $count) {
				if (isset($metrics['providers'][$provider][$field])) {
					$metrics['providers'][$provider][$field] += $count;
				}
			}
		}

		self::save_api_metrics($metrics);
		self::$metric_buffer = [];
	}

	/**
	 * API Metrics: Record an API attempt before the request fires.
	 */
	private static function record_api_attempt(string $provider): void
	{
		self::buffer_metric($provider, 'attempts_today');
		self::buffer_metric($provider, 'attempts_total');
	}

	/**
	 * API Metrics: Record a successful API response (HTTP 200).
	 */
	private static function record_api_success(string $provider, int $status_code = 200): void
	{
		self::buffer_metric($provider, 'success_today');
		self::buffer_metric($provider, 'success_total');
	}

	/**
	 * API Metrics: Record a failed API response (401, 429, 503, etc.).
	 */
	private static function record_api_failure(string $provider, int $status_code = 0): void
	{
		self::buffer_metric($provider, 'failures_today');
		self::buffer_metric($provider, 'failures_total');
	}

	/**
	 * Phase 3F (2.34.0): park a model that hangs at the transport layer.
	 *
	 * A cURL error 28 (or http_request_failed timeout) burns the FULL request
	 * window — 180s on free-tier custom providers — before the fallback hop.
	 * The 09-06 log showed the primary model (nemotron-3.5-lightning:free)
	 * timing out on ~150 requests, i.e. every generation paid a wasted 180s
	 * wait AND a second HTTP call to the fallback. HTTP 408/504 already set a
	 * short cooldown, but a transport-level WP_Error never reached that path.
	 *
	 * This records the timeout against the (provider, model) pair; after
	 * TIMEOUT_STRIKE_LIMIT strikes inside the strike window it parks the model
	 * for TIMEOUT_COOLDOWN_SECONDS via the SAME cooldown SSOT the candidate
	 * resolver already honours, so subsequent jobs skip straight to a healthy
	 * fallback instead of waiting 180s each. A success clears the strike count.
	 *
	 * @param string $provider
	 * @param string $model
	 * @param string $error_message  Raw WP_Error message (used to detect timeout).
	 * @return void
	 */
	public static function note_transport_timeout(string $provider, string $model, string $error_message = ''): void
	{
		$is_timeout = (stripos($error_message, 'cURL error 28') !== false)
			|| (stripos($error_message, 'timed out') !== false)
			|| (stripos($error_message, 'http_request_failed') !== false)
			|| (stripos($error_message, 'timeout') !== false);
		if (! $is_timeout) {
			return;
		}

		$strike_key = 'seo_gen_timeout_strikes_' . \sanitize_key($provider) . '_' . md5((string) $model);
		$strikes    = (int) \get_transient($strike_key) + 1;
		\set_transient($strike_key, $strikes, self::TIMEOUT_STRIKE_WINDOW);

		if ($strikes >= self::TIMEOUT_STRIKE_LIMIT) {
			$cooldown_until = Plugin_Time::now_utc_ts() + self::TIMEOUT_COOLDOWN_SECONDS;
			\set_transient(self::get_provider_cooldown_key($provider, $model), $cooldown_until, self::TIMEOUT_COOLDOWN_SECONDS + 60);
			\delete_transient($strike_key);
			// AI_Client is a mostly-static service with no injected logger; route
			// the parking event through WP's error log so it is never silent.
			\error_log(
				"SEO-AG: {$provider}/{$model} timed out {$strikes}x recently; parking model for "
				. (int) (self::TIMEOUT_COOLDOWN_SECONDS / 60) . " min and routing to fallback."
			);
		}
	}

	/**
	 * Clear transport-timeout strike count for a healthy (provider, model) pair.
	 * Called on a successful 200 so a recovered model re-enters rotation.
	 */
	public static function clear_transport_timeout_strikes(string $provider, string $model = ''): void
	{
		\delete_transient('seo_gen_timeout_strikes_' . \sanitize_key($provider) . '_' . md5((string) $model));
	}

	// ─── Phase 3Q (2.34.13): Provider Circuit Breaker ────────────────────────

	/**
	 * Circuit breaker transient key for failure tracking.
	 * Separate from the per-model error count used by existing cooldown logic.
	 */
	private static function cb_key( string $provider, string $suffix = '' ): string {
		$key = 'seo_gen_cb_' . \sanitize_key( $provider );
		if ( $suffix !== '' ) {
			$key .= '_' . $suffix;
		}
		return $key;
	}

	/**
	 * Read the current circuit breaker failure count for a provider.
	 * Returns an array [count, window_start].
	 */
	private static function cb_get_failures( string $provider ): array {
		$raw = \get_transient( self::cb_key( $provider, 'failures' ) );
		if ( is_array( $raw ) && isset( $raw['count'], $raw['window'] ) ) {
			return $raw;
		}
		return array( 'count' => 0, 'window' => 0 );
	}

	/**
	 * Can we send a request to this provider right now?
	 *
	 * @return array{allowed: bool, state: string, retry_after: int, failure_count: int}
	 */
	public static function cb_can_execute( string $provider ): array {
		$now     = Plugin_Time::now_utc_ts();
		$failures = self::cb_get_failures( $provider );
		$count    = (int) $failures['count'];
		$window   = (int) $failures['window'];

		// Window expired: reset to CLOSED
		if ( $count > 0 && ( $now - $window ) > self::CB_WINDOW_SECONDS ) {
			\delete_transient( self::cb_key( $provider, 'failures' ) );
			return array( 'allowed' => true, 'state' => 'closed', 'retry_after' => 0, 'failure_count' => 0 );
		}

		// Below threshold: CLOSED
		if ( $count < self::CB_OPEN_THRESHOLD ) {
			return array( 'allowed' => true, 'state' => 'closed', 'retry_after' => 0, 'failure_count' => $count );
		}

		// At/above threshold: check if cooldown expired (HALF_OPEN)
		$open_until = (int) \get_transient( self::cb_key( $provider, 'open_until' ) );
		if ( $open_until > $now ) {
			// OPEN: provider blocked
			return array(
				'allowed'      => false,
				'state'        => 'open',
				'retry_after'  => $open_until - $now,
				'failure_count'=> $count,
			);
		}

		// Cooldown expired: HALF_OPEN (allow one probe)
		return array( 'allowed' => true, 'state' => 'half_open', 'retry_after' => 0, 'failure_count' => $count );
	}

	/**
	 * Record a provider-level failure (5xx, transport timeout).
	 * Increments the failure counter and opens the breaker when threshold is reached.
	 *
	 * @return array{opened: bool, state: string, cooldown_seconds: int}
	 */
	public static function cb_record_failure( string $provider ): array {
		$now = Plugin_Time::now_utc_ts();
		$failures = self::cb_get_failures( $provider );
		$count    = (int) $failures['count'];
		$window   = (int) $failures['window'];

		// Window expired: start fresh
		if ( $count > 0 && ( $now - $window ) > self::CB_WINDOW_SECONDS ) {
			$count  = 0;
			$window = $now;
		}

		if ( $window <= 0 ) {
			$window = $now;
		}

		$count++;
		\set_transient( self::cb_key( $provider, 'failures' ), array( 'count' => $count, 'window' => $window ), self::CB_WINDOW_SECONDS + 60 );

		if ( $count >= self::CB_OPEN_THRESHOLD ) {
			// Escalating cooldown: base * multiplier^(times_opened - 1), capped
			$times_opened = max( 1, (int) \get_transient( self::cb_key( $provider, 'open_count' ) ) + 1 );
			\set_transient( self::cb_key( $provider, 'open_count' ), $times_opened, self::CB_MAX_COOLDOWN + 60 );

			$cooldown = min( self::CB_MAX_COOLDOWN, (int) ( self::CB_BASE_COOLDOWN * pow( self::CB_BACKOFF_MULTIPLIER, $times_opened - 1 ) ) );
			$open_until = $now + $cooldown;
			\set_transient( self::cb_key( $provider, 'open_until' ), $open_until, $cooldown + 60 );

			\error_log( "SEO-AG Circuit Breaker: {$provider} OPEN after {$count} failures (cooldown {$cooldown}s, open #{$times_opened})" );

			return array( 'opened' => true, 'state' => 'open', 'cooldown_seconds' => $cooldown );
		}

		return array( 'opened' => false, 'state' => 'closed', 'cooldown_seconds' => 0 );
	}

	/**
	 * Record a success.  Implements OmniRoute's success-decay pattern:
	 * halve the failure count so a recovered provider re-enters rotation
	 * before its full window expires.
	 */
	public static function cb_record_success( string $provider ): void {
		$failures = self::cb_get_failures( $provider );
		$count = (int) $failures['count'];
		if ( $count <= 0 ) {
			return; // Already clean
		}

		// Success-decay: halve the failure count (OmniRoute pattern)
		$new_count = (int) floor( $count / 2 );
		if ( $new_count <= 0 ) {
			// Fully recovered: clear all circuit breaker state
			\delete_transient( self::cb_key( $provider, 'failures' ) );
			\delete_transient( self::cb_key( $provider, 'open_until' ) );
			\delete_transient( self::cb_key( $provider, 'open_count' ) );
			\error_log( "SEO-AG Circuit Breaker: {$provider} recovered (failure count {$count} → 0). All state cleared." );
		} else {
			\set_transient( self::cb_key( $provider, 'failures' ), array( 'count' => $new_count, 'window' => $failures['window'] ?? Plugin_Time::now_utc_ts() ), self::CB_WINDOW_SECONDS + 60 );
			// Also clear the open_until so the provider can re-enter HALF_OPEN
			\delete_transient( self::cb_key( $provider, 'open_until' ) );
		}
	}

	/**
	 * Get the current circuit breaker state for a provider (for snapshot/logging).
	 */
	public static function cb_get_state( string $provider ): array {
		return self::cb_can_execute( $provider );
	}

	/**
	 * Reset the circuit breaker for a provider (manual override / hard reset).
	 */
	public static function cb_reset( string $provider ): void {
		\delete_transient( self::cb_key( $provider, 'failures' ) );
		\delete_transient( self::cb_key( $provider, 'open_until' ) );
		\delete_transient( self::cb_key( $provider, 'open_count' ) );
	}

	/**
	 * API Metrics: Get aggregated dashboard metrics for all providers.
	 */
	public static function get_dashboard_metrics(): array
	{
		$metrics = self::load_api_metrics();

		$out = array(
			'attempts_today' => 0,
			'attempts_total' => 0,
			'success_today'  => 0,
			'success_total'  => 0,
			'failures_today' => 0,
			'failures_total' => 0,
			'providers'      => array(),
		);

		$all_providers = self::get_all_providers();

		foreach ($all_providers as $provider) {
			$row = $metrics['providers'][$provider] ?? array();

			$out['providers'][$provider] = array(
				'attempts_today' => (int) ($row['attempts_today'] ?? 0),
				'attempts_total' => (int) ($row['attempts_total'] ?? 0),
				'success_today'  => (int) ($row['success_today'] ?? 0),
				'success_total'  => (int) ($row['success_total'] ?? 0),
				'failures_today' => (int) ($row['failures_today'] ?? 0),
				'failures_total' => (int) ($row['failures_total'] ?? 0),
				'last_status'    => (int) ($row['last_status'] ?? 0),
				'last_error_at'  => (int) ($row['last_error_at'] ?? 0),
			);

			$out['attempts_today'] += $out['providers'][$provider]['attempts_today'];
			$out['attempts_total'] += $out['providers'][$provider]['attempts_total'];
			$out['success_today']  += $out['providers'][$provider]['success_today'];
			$out['success_total']  += $out['providers'][$provider]['success_total'];
			$out['failures_today'] += $out['providers'][$provider]['failures_today'];
			$out['failures_total'] += $out['providers'][$provider]['failures_total'];
		}

		return $out;
	}

	/**
	 * Constructor
	 *
	 * @param string $provider
	 * @param string $api_key
	 * @param Logger $logger
	 */
	public function __construct($provider, $api_key, $logger)
	{
		$this->provider_name = $provider;
		$this->api_key       = $api_key;
		$this->logger        = $logger;

		$this->initialize_provider();
	}

	/**
	 * Set the execution context for the current logical request (generation job).
	 *
	 * Used by providers that need a stable conversation/session identity across
	 * PHP workers, Action Scheduler retries and provider/model fallback — notably
	 * OpenCode Zen's `x-opencode-session` header. Passed through to the active
	 * provider and RE-applied after every provider/model switch so the same
	 * job_id survives fallback hops.
	 *
	 * @param array $context e.g. ['job_id' => 123].
	 * @return void
	 * @since 2.34.4
	 */
	public function set_request_context(array $context): void
	{
		$this->request_context = $context;
		if ($this->provider !== null && method_exists($this->provider, 'set_execution_context')) {
			$this->provider->set_execution_context($context);
		}
	}

	/**
	 * @return array
	 * @since 2.34.4
	 */
	public function get_request_context(): array
	{
		return is_array($this->request_context) ? $this->request_context : array();
	}

	/**
	 * Get compact HTTP trace from last API request.
	 *
	 * @return array
	 */
	public function get_last_http_trace(): array
	{
		return is_array($this->last_http_trace) ? $this->last_http_trace : array();
	}

	/**
	 * Initialize the correct provider
	 */
	private function initialize_provider()
	{
		$registry = Provider_Registry::get_instance();
		$provider_class = $registry->get_provider_class($this->provider_name);

		if ($provider_class === Custom_Provider::class) {
			$profile = $registry->get_custom_profile($this->provider_name);
			$this->provider = new Custom_Provider(
				$this->api_key,
				$this->logger,
				$this,
				$this->provider_name,
				$profile
			);
			$this->apply_context_to_provider();
			return;
		}

		switch ($this->provider_name) {
			case 'perplexity':
				$this->provider = new Perplexity_Provider($this->api_key, $this->logger, $this);
				break;

			case 'openai':
				$this->provider = new OpenAI_Provider($this->api_key, $this->logger, $this);
				break;

		case 'groq':
			$this->provider = new Groq_Provider($this->api_key, $this->logger, $this);
			break;

		case 'openrouter':
			$this->provider = new OpenRouter_Provider($this->api_key, $this->logger, $this);
			break;

		case 'gemini':
			default:
				$this->provider = new Gemini_Provider($this->api_key, $this->logger, $this);
				break;
		}

		$this->apply_context_to_provider();
	}

	/**
	 * Push the current request context (e.g. job_id) onto the freshly-built
	 * provider so the same conversation identity survives model/provider
	 * fallback (initialize_provider() runs on every switch_to_provider_model()).
	 *
	 * @return void
	 * @since 2.34.4
	 */
	private function apply_context_to_provider(): void
	{
		if ($this->provider !== null
			&& method_exists($this->provider, 'set_execution_context')
			&& ! empty($this->request_context)) {
			$this->provider->set_execution_context($this->request_context);
		}
	}


	private function switch_to_provider_model(string $provider, string $model): void
	{
		$registry = Provider_Registry::get_instance();

		if ($registry->is_custom($provider)) {
			$profile = $registry->get_custom_profile($provider);
			$this->provider_name = $provider;
			$this->api_key = $profile['api_key'] ?? '';
			if ($model !== '') {
				$profile['_fallback_model'] = $model;
			}
			$this->initialize_provider();
			$this->logger->info("Switched AI provider to custom {$this->provider_name} for model {$model}");
			return;
		}

		$resolved = self::resolve_provider_model($provider, $model);
		if (!$resolved['ok']) {
			throw new AI_Exception('Invalid fallback provider/model: ' . $provider . '/' . $model);
		}

		$this->provider_name = $resolved['provider'];

		switch ($this->provider_name) {
			case 'perplexity':
				$this->api_key = self::get_perplexity_key();
				break;
			case 'openai':
				$this->api_key = self::get_openai_key();
				break;
		case 'groq':
			$this->api_key = self::get_groq_key();
			break;
		case 'openrouter':
			$this->api_key = self::get_openrouter_key();
			break;
		case 'gemini':
			default:
				$this->api_key = self::get_gemini_key();
				break;
		}

		$this->initialize_provider();
		$this->logger->info("Switched AI provider to {$this->provider_name} for model {$resolved['model']}");
	}

    private function restore_provider_state(string $provider, string $api_key): void
    {
        $this->provider_name = $provider;
        $this->api_key       = $api_key;
        $this->initialize_provider();
    }

    private function normalize_generation_exception(\Throwable $e): \Throwable
    {
        if ($e instanceof AI_Rate_Limit_Exception) {
            return $e;
        }

        if ($e instanceof AI_Exception) {
            $previous = $e->getPrevious();
            if ($previous instanceof AI_Rate_Limit_Exception) {
                return $previous;
            }
            return $e;
        }

        return new AI_Exception($e->getMessage(), 0, $e);
    }

	/**
	 * Generate article using AI
	 *
	 * @param array $prompt_data Structured prompt data
	 * @return array AI response data
	 * @throws AI_Exception If API call fails
	 */
	public function generate_article($prompt_data)
	{
		$this->logger->info('Starting AI article generation', array('provider' => $this->provider_name));

		$original_provider = $this->provider_name;
		$original_key      = $this->api_key;
		$original_details  = self::get_provider_details($original_provider);
		$original_model    = (string) ($original_details['model'] ?? '');

		if ($this->provider instanceof \SEO_Article_Generator\AI\Providers\Gemini_Provider) {
			$this->provider->reset_model_override();
		}

		try {
			return $this->execute_with_validation($prompt_data);
		} catch (\Throwable $e) {
			$primary_error    = $this->normalize_generation_exception($e);

			if (self::is_provider_only_mode_enabled()) {
				$this->logger->warning(
					'Provider-only mode active; fallback chain disabled.',
					array(
						'provider' => $original_provider,
						'error'    => $primary_error->getMessage(),
					)
				);

				throw $primary_error;
			}

			// [2.34.12] Deterministic PHP errors (TypeError, Error, LogicException)
			// are NEVER fixed by switching models.  Walking the fallback chain
			// wastes identical HTTP calls on each candidate. Fail immediately.
			if ($primary_error instanceof \TypeError
				|| $primary_error instanceof \Error
				|| $primary_error instanceof \LogicException
			) {
				$this->logger->error(
					'Deterministic PHP error — skipping fallback chain.',
					array('class' => get_class($primary_error), 'message' => $primary_error->getMessage())
				);
				throw $primary_error;
			}

			$rate_limit_seen  = ($primary_error instanceof AI_Rate_Limit_Exception);
			$hard_failure_seen = !$rate_limit_seen;
			$last_fallback_error = null;

			$this->logger->warning(
				'Primary AI generation failed, checking fallback chain...',
				array('error' => $primary_error->getMessage())
			);

			if (strpos($primary_error->getMessage(), 'Prompt too short') !== false) {
				throw $primary_error;
			}

			foreach (self::get_fallback_candidates() as $candidate) {
				if ($candidate['provider'] === $original_provider && $candidate['model'] === $original_model) {
					continue;
				}

				$model_override = static function ($current) use ($candidate) {
					return $candidate['model'];
				};

try {
 $this->logger->info(sprintf('Fallback attempt: trying %s/%s.', $candidate['provider'], $candidate['model']));

 $this->switch_to_provider_model($candidate['provider'], $candidate['model']);

$prompt_data['_resolved_provider'] = $candidate['provider'];
  $prompt_data['_resolved_model'] = $candidate['model'];

  // NOTE: _resolved_model is honoured by Gemini_Provider::resolve_model().
  // Custom_Provider targets models via _fallback_model in the profile config
  // (written by switch_to_provider_model above), NOT via _resolved_model.
  // Both mechanisms achieve the same end; keep this comment to prevent future
  // refactors from assuming _resolved_model is universally honoured.

 if ($candidate['provider'] === 'perplexity' && empty($prompt_data['homepage'])) {
 $prompt_data['homepage'] = $prompt_data['sourceurl'] ?? $prompt_data['homepage'] ?? '';
 }

 \add_filter('seo_gen_use_model', $model_override, 20, 1);
 try {
 $result = $this->execute_with_validation($prompt_data);
 } finally {
 \remove_filter('seo_gen_use_model', $model_override, 20);
 }

 $this->logger->info(sprintf('Fallback succeeded: %s/%s delivered generation.', $candidate['provider'], $candidate['model']));

 $this->restore_provider_state($original_provider, $original_key);
 return $result;
 } catch (\Throwable $fe) {
 $normalized = $this->normalize_generation_exception($fe);
 $last_fallback_error = $normalized;

 if ($normalized instanceof AI_Rate_Limit_Exception) {
 $rate_limit_seen = true;
 } else {
 $hard_failure_seen = true;
 }

 $this->logger->error(
 "Fallback {$candidate['provider']}/{$candidate['model']} failed: " . $normalized->getMessage()
 );
					continue;
				}
			}

			$this->restore_provider_state($original_provider, $original_key);

			if ($last_fallback_error instanceof \Throwable && $hard_failure_seen) {
				throw $last_fallback_error;
			}

			if ($rate_limit_seen && !$hard_failure_seen) {
				if ($last_fallback_error instanceof AI_Rate_Limit_Exception) {
					throw $last_fallback_error;
				}
				throw $primary_error instanceof AI_Rate_Limit_Exception
					? $primary_error
					: new AI_Rate_Limit_Exception('All routable AI providers are temporarily rate-limited.');
			}

			throw $primary_error;
		}
	}

	/**
	 * Helper for generation + validation
	 */
private function execute_with_validation($prompt_data)
 {
 $this->_is_scout_call = ! empty($prompt_data['_scout_call']);
 try {
 $ai_output = $this->provider->generate_article($prompt_data);

			// Run Truth Validation (Centralized)
			// @MODIFIED 2026-03-20: Safety Guard - Removed Truth_Validator bypass
			// Truth checks must always run to ensure factual accuracy, even if structural 
			// validation is relaxed for updates.
			$validator  = new Truth_Validator();
			$input_data = array(
				'software_name'   => $prompt_data['software_name'] ?? '',
				'tech_specs'      => array(
					'version' => $prompt_data['version'] ?? null,
				),
				'download'        => array(
					'url'       => $prompt_data['download_link'] ?? null,
					'file_size' => $prompt_data['file_size'] ?? null,
				),
				'scraped_version' => $prompt_data['scraped_version'] ?? null,
				'homepage'        => $prompt_data['homepage'] ?? null,
				'changelogurl'    => $prompt_data['changelogurl'] ?? null,
			);

			// Validate and append results
			$validation_result = $validator->validate_truthfulness($input_data, $ai_output);

			// Append validation result to output
			$ai_output['_validation'] = $validation_result;

			// @MODIFIED 2026-04-03: ENHANCEMENT - Attach critical truth validation issues to returned payload
			// so ArticleGenerator can act on them before scoring
			if (!empty($validation_result['issues'])) {
				$critical_issues = array();
				foreach ($validation_result['issues'] as $issue) {
					$severity = $issue['severity'] ?? '';
					if ($severity === 'critical') {
						$critical_issues[] = $issue;
					}
				}
				if (!empty($critical_issues)) {
					$ai_output['_truth_validation_critical'] = $critical_issues;
				}
			}

			// Log validation failure but return data
			if (! $validation_result['can_publish']) {
				$this->logger->warning('Truth validation failed', array('issues' => $validation_result['issues']));
			}

			// Append debug data
			$ai_output['_debug'] = array(
				'provider'     => $this->provider_name,
				'http_trace'   => $this->get_last_http_trace(),
				'raw_prompt'   => $this->provider->get_last_raw_prompt(),
				'raw_response' => $this->provider->get_last_raw_response(),
			);

			return $ai_output;
} catch (\Throwable $e) {
 $normalized = $this->normalize_generation_exception($e);

 $this->logger->error('AI generation failed: ' . $normalized->getMessage(), array(
 'provider' => $this->provider_name,
 'type' => get_class($normalized),
 ));

 \error_log(
 '[SEO GEN AI ERROR] Provider: ' . $this->provider_name .
 ' | Type: ' . get_class($normalized) .
 ' | Message: ' . $normalized->getMessage()
 );

 throw $normalized;
} finally {
 $this->_is_scout_call = false;
 }
 }

 /**
 * Test API connection
	 *
	 * @return array Test results
	 * @throws AI_Exception If test fails
	 */
public function test_connection()
 {
 return $this->provider->test_connection();
 }

	/**
	 * Centralized AI Gateway: Executes all API requests with throttling and tracking.
	 *
	 * @since 2.15.0
	 *
	 * @param string $endpoint The API endpoint URL.
	 * @param array  $args     The wp_remote_post arguments.
	 * @param string $provider The provider name (gemini/perplexity).
	 * @return array|\WP_Error The API response or WP_Error.
	 */
    /**
     * Summarize HTTP payload for compact logging.
     *
     * @param mixed $request_body
     * @param mixed $response_body
     * @return array
     */
    private function summarize_http_payload($request_body, $response_body = null): array
    {
        $request_string = is_string($request_body) ? $request_body : wp_json_encode($request_body);
        $response_string = is_string($response_body) ? $response_body : wp_json_encode($response_body);
        $request_string = is_string($request_string) ? $request_string : '';
        $response_string = is_string($response_string) ? $response_string : '';

        return array(
            'request_bytes' => strlen($request_string),
            'request_sha1' => $request_string !== '' ? sha1($request_string) : '',
            'response_bytes' => strlen($response_string),
            'response_preview' => $response_string !== '' ? substr(trim($response_string), 0, 300) : '',
        );
    }

    public function execute_safe_request($endpoint, $args, $provider, string $model = '')
    {
        if ($model === '') {
            $details = self::get_provider_details($provider);
            $model = (string) ($details['model'] ?? '');
        }

        $cooldown_key = self::get_provider_cooldown_key($provider, $model);
        $error_count_key = self::get_provider_error_count_key($provider, $model);
        $pause_reason_key = self::get_provider_pause_reason_key($provider, $model);

		$now               = Plugin_Time::now_utc_ts();
		$cooldown_model    = (int)\get_transient($cooldown_key);
		$cooldown_provider = (int)\get_transient(self::get_provider_cooldown_key($provider));
		$cooldown_until    = max($cooldown_model, $cooldown_provider);

		if ($cooldown_until > $now) {
			$wait = $cooldown_until - $now;
			return $this->error_with_data(
				'provider_cooldown',
				"API Gateway: {$provider}/{$model} cooldown active. Retry in {$wait}s.",
				$provider,
				$wait
			);
		}

		// [2.34.13] Phase 3Q: Provider Circuit Breaker check.
		// Prevents wasting requests on a provider that is repeatedly failing at
		// the service level (5xx, transport timeouts).  Runs AFTER per-model
		// cooldown but BEFORE lock acquisition so we don't even contend for
		// the mutex on a tripped breaker.
		$cb = self::cb_can_execute( $provider );
		if ( ! $cb['allowed'] ) {
			$cb_wait = (int) $cb['retry_after'];
			return $this->error_with_data(
				'provider_cooldown',
				"Circuit Breaker: {$provider} OPEN after {$cb['failure_count']} failures. Retry in {$cb_wait}s.",
				$provider,
				$cb_wait
			);
		}

		if (! $this->acquire_lock($provider)) {
			return $this->error_with_data(
				'provider_locked',
				"AI Inflight Lock: {$provider} already processing another request. Retry in 15s.",
				$provider,
				15
			);
		}

        try {
            $min_interval = $this->get_min_interval_seconds($provider);
            if (Quota_State_Manager::should_slow_down($provider, $model)) {
                $recommended = Quota_State_Manager::get_recommended_interval($provider, $model);
                $min_interval = max($min_interval, (float) $recommended);
            }
            $last_call_key = 'seogenapilastcall_' . \sanitize_key($provider);
 $last_call_ts = (float) \get_option($last_call_key, 0);
 $now_float = (float) \microtime(true);
 $diff = $now_float - $last_call_ts;
 if ($last_call_ts > 0 && $diff < $min_interval) {
 $wait_us = (int) (($min_interval - $diff) * 1000000);
 if ($wait_us > 0) {
 \usleep($wait_us);
 }
 }
 \update_option($last_call_key, (float) \microtime(true), false);

			// @DEBUG 2026-03-13 - Log key prefix to verify correct key is sent
			$key_prefix = substr(\is_string($this->api_key) ? $this->api_key : '', 0, 6);
			$key_len    = strlen(\is_string($this->api_key) ? $this->api_key : '');

			// Sensitive URL masking for logs
			$log_endpoint = preg_replace('/key=[^&]+/', 'key=***', (string) $endpoint);

			$this->logger->info("API Gateway Request: {$provider}", array(
				'key_prefix' => $key_prefix . '...',
				'key_len'    => $key_len,
				'endpoint'   => $log_endpoint
			));

			$attempt = 0;
			$max_attempts = $this->get_max_attempts($provider);

do {
$attempt++;

self::record_api_attempt($provider);

// Flush attempt metric immediately — survive PHP death mid-request
if ($attempt === 1) {
self::flush_metric_buffer();
}

            if ($this->logger) {
                // FIX: Prevent double-encoding if provider already serialized the payload
                $body_log = is_string($args['body'] ?? '') ? $args['body'] : wp_json_encode($args['body'] ?? array());
                $this->logger->info("API Gateway RAW Request [" . $provider . "]: " . substr((string) $body_log, 0, 150000));
            }

$response = \wp_remote_post($endpoint, $args);
 if (\is_wp_error($response)) {
					self::record_api_failure($provider, 0);

					// [2.34.13] Phase 3Q: Transport failures are provider-level — record in CB.
					$_err_msg = $response->get_error_message();
					$_is_transport = (stripos($_err_msg, 'cURL error 28') !== false)
						|| (stripos($_err_msg, 'timed out') !== false)
						|| (stripos($_err_msg, 'could not resolve host') !== false)
						|| (stripos($_err_msg, 'connection refused') !== false);
					if ( $_is_transport ) {
						self::cb_record_failure( $provider );
					}

					$this->logger->warning("API Gateway: WP_Error from {$provider} on attempt {$attempt}.", array(
						'error' => $response->get_error_message(),
					));

					if ($attempt < $max_attempts && $this->is_retryable_wp_error($response)) {
						$this->sleep_with_jitter($this->get_backoff_seconds($attempt, $provider));
						continue;
					}

					return $response;
				}

				$status_code = (int) \wp_remote_retrieve_response_code($response);
				$response_body = \wp_remote_retrieve_body($response);
				$request_body = $args['body'] ?? '';

				$this->last_http_trace = array(
					'provider'       => $provider,
					'endpoint'       => preg_replace('/key=[^&]+/', 'key=***', (string) $endpoint),
					'status_code'    => $status_code,
					'request_bytes'  => is_string($request_body) ? strlen($request_body) : 0,
					'response_bytes' => is_string($response_body) ? strlen($response_body) : 0,
					'response_head'  => is_string($response_body) ? substr(trim($response_body), 0, 500) : '',
				);

        if (200 === $status_code) {
            self::record_api_success($provider, 200);
            // Phase 3F: a clean 200 means this model is healthy again — clear its
            // transport-timeout strikes so it can re-enter rotation.
            self::clear_transport_timeout_strikes($provider, (string) $model);
            // [2.34.13] Phase 3Q: Success-decay for circuit breaker.
            // Halves the failure count so a recovered provider re-enters rotation
            // before its full window expires (OmniRoute pattern).
            self::cb_record_success( $provider );
            \SEO_Article_Generator\Usage_Tracker::increment($provider);
            // Any success clears the error-count for the whole provider (all models),
            // so a clean call resets the escalating cooldown budget instead of letting
            // a stale counter from an earlier model snowball across jobs.
            $all_models = \SEO_Article_Generator\AI\Provider_Registry::get_instance()->get_supported_models($provider);
            \delete_transient($error_count_key);
            \delete_transient(self::get_provider_error_count_key($provider));
            foreach ($all_models as $m_id => $m_label) {
                \delete_transient(self::get_provider_error_count_key($provider, (string) $m_id));
            }
            self::set_provider_pause_reason($provider, $model, '');

            $usage_data = array();
            $decoded_body = @json_decode($response_body, true);
            if (is_array($decoded_body)) {
                if (isset($decoded_body['usageMetadata'])) {
                    $usage_data['total_tokens'] = (int) ($decoded_body['usageMetadata']['totalTokenCount'] ?? 0);
                } elseif (isset($decoded_body['usage'])) {
                    $usage_data['total_tokens'] = (int) ($decoded_body['usage']['total_tokens'] ?? 0);
                }
            }
            Quota_State_Manager::record_success($provider, $model, $usage_data);

            $is_scout_call = $this->_is_scout_call;
            if (! $is_scout_call) {
                global $wpdb;
                // FIX: Use aliased Plugin_Time class (already imported from Utils namespace)
                $quota_key = 'seogenaichecks_' . Plugin_Time::site_today_ymd();
                $wpdb->query($wpdb->prepare(
                    "INSERT INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, 1, 'no') ON DUPLICATE KEY UPDATE option_value = option_value + 1",
                    $quota_key
                ));
 if ($this->logger) {
 $today_used = (int) $wpdb->get_var($wpdb->prepare("SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", $quota_key));
 $this->logger->info(sprintf('API Gateway quota incremented for %s. Today: %d.', $provider, $today_used));
 }
 } else {
 if ($this->logger) {
 $this->logger->info(sprintf('API Gateway scout call on %s — quota counter NOT incremented.', $provider));
 }
 }

 if ($this->logger) {
 $this->logger->info("API Gateway RAW Response [" . $provider . "]: " . substr(trim((string)$response_body), 0, 150000));
 }

 return $response;
 }

		if (self::is_provider_auth_failure($provider, $status_code, (string) $response_body)) {
			self::record_api_failure($provider, $status_code);

			$this->logger->error("API Gateway: Authentication/configuration failure for {$provider}.", array(
				'status_code' => $status_code,
				'response' => \substr(\trim((string) $response_body), 0, 500),
			));

			self::mark_provider_misconfigured($provider, 'Authentication or permission failure', 86400);

			return $this->error_with_data(
				'auth_failed',
				"Authentication failed for {$provider}.",
				$provider,
				86400
			);
		}

		if (self::is_model_not_found_response($provider, $status_code, (string) $response_body)) {
			self::record_api_failure($provider, $status_code);

			$this->logger->error("API Gateway: Invalid model configured for {$provider}/{$model}.", array(
				'status_code' => $status_code,
				'model' => $model,
				'response' => \substr(\trim((string) $response_body), 0, 500),
			));

			// Model-scoped only: a 404 on one model must not poison sibling models
			// of the same provider (Critical #1).
			// [2.34.12] Extended to 7 days: "unavailable for free" is a permanent
			// OpenRouter gate state. 24h TTL caused dead models to re-enter rotation
			// daily, wasting 1 HTTP call per job. 7 days outlives the 3-day sync
			// cadence so the model is pruned by sync before the flag expires.
			self::mark_provider_misconfigured($provider, 'Invalid model configured', 7 * DAY_IN_SECONDS, $model);

			return $this->error_with_data(
				'misconfigured',
				"Invalid model configured for {$provider}/{$model}.",
				$provider,
				86400
			);
		}

		if (self::is_request_shape_invalid_response($provider, $status_code, (string) $response_body)) {
			self::record_api_failure($provider, $status_code);

			$http_summary = $this->summarize_http_payload($request_body, $response_body);
			$this->logger->error("API Gateway: request-shape failure from {$provider}/{$model}. Provider state NOT poisoned.", array(
				'status_code' => $status_code,
				'provider' => $provider,
				'model' => $model,
				'request_bytes' => $http_summary['request_bytes'],
				'request_sha1' => $http_summary['request_sha1'],
				'response_bytes' => $http_summary['response_bytes'],
				'response' => $http_summary['response_preview'],
			));

			// Do not set misconfigured state.
			// Do not set cooldown.
			// Return raw response so provider-level code can raise a normal AI_Exception for this job only.
			return $response;
		}

            if (429 === $status_code || 503 === $status_code) {
                $response_headers = wp_remote_retrieve_headers($response);
                $headers_array = is_array($response_headers) ? $response_headers : array();
                if ($response_headers instanceof \Requests_Utility_CaseInsensitiveDictionary) {
                    $headers_array = $response_headers->getAll();
                } elseif (!is_array($headers_array)) {
                    $headers_array = array();
                }

                $error_info = API_Error_Parser::parse($provider, $status_code, (string) $response_body, $headers_array);
                Quota_State_Manager::calibrate_from_error($provider, $model, $error_info);

                $retry_after = $error_info->get_retry_delay_seconds();
                $quota_type = $error_info->is_daily_quota() ? 'day' : 'minute';
                $reset_at = $error_info->get_reset_at_ts();

                if ($attempt < $max_attempts && $retry_after > 0 && $retry_after <= 10) {
                    $this->logger->warning("API Gateway: {$provider} temporary {$status_code}; retrying.", array(
                        'attempt' => $attempt,
                        'retry_after' => $retry_after,
                    ));
                    $this->sleep_with_jitter($retry_after);
                    continue;
                }

                self::record_api_failure($provider, $status_code);

                $error_count = (int) \get_transient($error_count_key) + 1;
                \set_transient($error_count_key, $error_count, 3600);

                if ($error_info->get_error_type() === API_Error_Info::TYPE_SERVER_OVERLOADED) {
                    $base_backoff = min(300, 60 * (int) pow(2, $error_count - 1));
                    $retry_after = max($base_backoff, $retry_after);
                    $reset_at = Plugin_Time::now_utc_ts() + $retry_after;
                    $reason = 'Provider Overloaded';
                } elseif ($error_info->is_daily_quota()) {
                    if ($reset_at <= Plugin_Time::now_utc_ts()) {
                        $reset_at = ('gemini' === $provider)
                            ? Quota_Reset_Calculator::gemini_next_rpd_reset_ts()
                            : Quota_Reset_Calculator::generic_next_reset_ts();
                    }
                    $retry_after = max(60, $reset_at - Plugin_Time::now_utc_ts());
                    $reason = 'Daily Quota Exhausted';
                    // F1: also set the PROVIDER-scoped cooldown key. get_provider_details()
                    // only reads the primary-model key for the built-in path, so a daily
                    // hit on a non-primary rotated model would otherwise leave the provider
                    // appearing "ready" and re-loop. Mirrors the model-scoped set below.
                    \set_transient(self::get_provider_cooldown_key($provider), $reset_at, max(60, $retry_after + 60));
                } elseif ($error_info->is_quota_error()) {
                    if (1 === $error_count) {
                        $retry_after = max($retry_after, 30);
                        $reset_at = Plugin_Time::now_utc_ts() + $retry_after;
                    } elseif (2 === $error_count) {
                        $retry_after = max($retry_after, 300);
                        $reset_at = Plugin_Time::now_utc_ts() + $retry_after;
                    } else {
                        $reset_at = Plugin_Time::now_utc_ts() + max($retry_after, 900);
                        $retry_after = max(60, $reset_at - Plugin_Time::now_utc_ts());
                    }
                    $reason = 'Rate Limit Strike';
                } else {
                    if (1 === $error_count) {
                        $retry_after = max($retry_after, 60);
                        $reset_at = Plugin_Time::now_utc_ts() + $retry_after;
                    } elseif (2 === $error_count) {
                        $retry_after = max($retry_after, 300);
                        $reset_at = Plugin_Time::now_utc_ts() + $retry_after;
                    } else {
                        $reset_at = Plugin_Time::now_utc_ts() + max($retry_after, 900);
                        $retry_after = max(60, $reset_at - Plugin_Time::now_utc_ts());
                    }
                    $reason = 'Rate Limit Strike';
                }

                \set_transient($cooldown_key, $reset_at, max(60, $retry_after + 60));
                self::set_provider_pause_reason($provider, $model, $reason);

                $http_summary = $this->summarize_http_payload($request_body, $response_body);
                $this->logger->error("API Gateway: {$provider}/{$model} received {$status_code}. Cooldown engaged.", array(
                    'provider' => $provider,
                    'model' => $model,
                    'status_code' => $status_code,
                    'retry_after' => $retry_after,
                    'quota_type' => $quota_type,
                    'reset_at' => $reset_at,
                    'error_type' => $error_info->get_error_type(),
                    'recommended_action' => $error_info->recommended_action(),
                    'quota_metric' => $error_info->get_quota_metric(),
                    'error_count' => $error_count,
                    'request_bytes' => $http_summary['request_bytes'],
                    'request_sha1' => $http_summary['request_sha1'],
                    'response_bytes' => $http_summary['response_bytes'],
                    'response' => $http_summary['response_preview'],
                ));

                return $this->error_with_data(
                    'rate_limit',
                    "API rate limit exceeded ({$status_code}) for {$provider}/{$model}. {$reason}.",
                    $provider,
                    $retry_after,
                    $quota_type,
                    $reset_at,
                $error_info
            );
            }

            if ($attempt < $max_attempts && $this->is_retryable_status_code($status_code)) {
				$delay = $this->get_backoff_seconds($attempt, $provider);

            $http_summary = $this->summarize_http_payload($request_body, $response_body);
            $this->logger->warning("API Gateway: retryable {$status_code} from {$provider}; retrying.", array(
                'attempt' => $attempt,
                'delay' => $delay,
                'request_bytes' => $http_summary['request_bytes'],
                'request_sha1' => $http_summary['request_sha1'],
                'response_bytes' => $http_summary['response_bytes'],
                'response' => $http_summary['response_preview'],
            ));

				$this->sleep_with_jitter($delay);
				continue;
			}

			if (500 === $status_code || 502 === $status_code) {
				// [2.34.13] Phase 3Q: Record provider-level failure in circuit breaker.
				// 5xx indicates the provider itself is having issues (not model-specific).
				$cb_result = self::cb_record_failure( $provider );
				if ( $cb_result['opened'] ) {
					$this->logger->warning(
						"Circuit Breaker: {$provider} OPENED after repeated 5xx failures.",
						array( 'status_code' => $status_code, 'cb_state' => $cb_result )
					);
				}

				// [2.34.13] Phase 3Q: Escalating backoff for 5xx errors.
				// Previously: fixed 300s cooldown. Now: 1st=60s, 2nd=300s, 3rd+=900s.
				$cb_failures = self::cb_get_failures( $provider );
				$cb_count = (int) $cb_failures['count'];
				$cooldown_seconds = $cb_count <= 1 ? 60 : ( $cb_count === 2 ? 300 : 900 );
				$reset_at = Plugin_Time::now_utc_ts() + $cooldown_seconds;
				\set_transient($cooldown_key, $reset_at, max(360, $cooldown_seconds + 60));
				self::set_provider_pause_reason($provider, $model, 'Server Error');
				$this->logger->warning("API Gateway: {$provider}/{$model} 5xx retry budget exhausted. Cooldown {$cooldown_seconds}s.", array(
					'status_code' => $status_code,
					'model'       => $model,
					'cb_failures' => $cb_count,
				));
			} elseif (408 === $status_code || 504 === $status_code) {
				// [2.34.13] Phase 3Q: Record timeout as provider-level failure too.
				self::cb_record_failure( $provider );

				$reset_at = Plugin_Time::now_utc_ts() + 30;
				\set_transient($cooldown_key, $reset_at, 90);
				self::set_provider_pause_reason($provider, $model, 'Timeout');
				$this->logger->warning("API Gateway: {$provider}/{$model} timeout retry budget exhausted. Cooldown 30s.", array(
					'status_code' => $status_code,
					'model'       => $model,
				));
			}

        $http_summary = $this->summarize_http_payload($request_body, $response_body);
        $this->logger->error("API Gateway: unexpected {$status_code} from {$provider}.", array(
            'request_bytes' => $http_summary['request_bytes'],
            'request_sha1' => $http_summary['request_sha1'],
            'response_bytes' => $http_summary['response_bytes'],
            'response' => $http_summary['response_preview'],
        ));

			self::record_api_failure($provider, $status_code);

			return $response;

			} while ($attempt < $max_attempts);

			self::record_api_failure($provider, 0);

			return new \WP_Error('ai_error', 'API request failed after retries.');
		} catch (\Throwable $e) {
			self::record_api_failure($provider, 0);

			return new \WP_Error('ai_error', $e->getMessage());
		} finally {
			$this->release_lock($provider);
			self::flush_metric_buffer();
		}
	}

	private static function get_provider_cooldown_key(string $provider, string $model = ''): string
	{
		$key = 'seo_gen_api_cooldown_' . \sanitize_key($provider);
		if ($model !== '') {
			// md5 so special characters in model ids (e.g. "google/gemma-4:free")
			// never collide or get mangled by sanitize_key.
			$key .= '_' . md5($model);
		}
		return $key;
	}

	private static function get_provider_error_count_key(string $provider, string $model = ''): string
	{
		$key = 'seo_gen_api_error_count_' . \sanitize_key($provider);
		if ($model !== '') {
			$key .= '_' . md5($model);
		}
		return $key;
	}

	private static function get_provider_pause_reason_key(string $provider, string $model = ''): string
	{
		$key = 'seo_gen_api_pause_reason_' . \sanitize_key($provider);
		if ($model !== '') {
			$key .= '_' . md5($model);
		}
		return $key;
	}

	private static function set_provider_pause_reason(string $provider, string $model, string $reason): void
	{
		$model_key    = self::get_provider_pause_reason_key($provider, $model);
		$provider_key = self::get_provider_pause_reason_key($provider);

		if ($reason === '') {
			\delete_option($model_key);
			\delete_option($provider_key);
		} else {
			\update_option($model_key, $reason, false);
			\update_option($provider_key, $reason, false);
		}
	}

	private function get_min_interval_seconds($provider)
	{
		$registry = Provider_Registry::get_instance();
		if ($registry->is_custom($provider)) {
			return (float) $registry->get_min_interval($provider);
		}
		switch ($provider) {
		case 'openai':
		case 'groq':
		case 'openrouter':
			return 1.0;
		case 'perplexity':
				return 2.0;
			case 'gemini':
			default:
				return 5.0;
		}
	}

	private function get_max_attempts($provider)
	{
		$registry = Provider_Registry::get_instance();
		if ($registry->is_custom($provider)) {
			return (int) $registry->get_max_attempts($provider);
		}
		switch ($provider) {
		case 'openai':
		case 'groq':
		case 'gemini':
		case 'openrouter':
			return 3;
			case 'perplexity':
			default:
				return 2;
		}
	}

	private function is_retryable_wp_error($error)
	{
		$msg = strtolower($error->get_error_message());

		// cURL error 28 = operation timed out — the model is simply slow.
		// Do NOT retry: every retry burns the full timeout window again.
		// The caller model-fallback loop switches to a faster model instead.
		if (false !== strpos($msg, 'curl error 28') || false !== strpos($msg, 'operation timed out')) {
			return false;
		}

		$markers = array(
			'timed out',
			'timeout',
			'could not resolve host',
			'connection reset',
			'connection refused',
			'ssl',
			'http request failed',
		);

		foreach ($markers as $marker) {
			if (false !== strpos($msg, $marker)) {
				return true;
			}
		}

		return false;
	}

	private function is_retryable_status_code($status_code)
	{
		return in_array((int) $status_code, array(408, 409, 425, 500, 502, 504), true);
	}

	private function get_backoff_seconds($attempt, $provider)
	{
		$base = ('openai' === $provider || 'groq' === $provider) ? 2 : 4;
		return min(20, $base * max(1, $attempt));
	}

	private function sleep_with_jitter($seconds)
	{
		$seconds = max(1, (int) $seconds);
		$jitter = mt_rand(100, 900) * 1000;
		\usleep(($seconds * 1000000) + $jitter);
	}

	/**
 * Detect if this is a daily quota exhaustion.
 * Delegates to is_daily_quota_error() as the single source of truth.
 * This ensures classify_quota_type() and is_daily_quota_error() never diverge.
 */
private function detect_quota_type($response, string $provider): string
 {
 	$body = (string) \wp_remote_retrieve_body($response);
 	$status_code = (int) \wp_remote_retrieve_response_code($response);
 	$headers = array();
 	$info = API_Error_Parser::parse($provider, $status_code, $body, $headers);

 	if ($info->is_daily_quota()) {
 		return 'day';
 	}

  return 'minute';
 }

	/**
	 * Return WP_Error with structured data.
	 */
    private function error_with_data($code, $message, $provider, $retry_after, $quota_type = 'minute', $reset_at = 0, ?API_Error_Info $error_info = null)
    {
        if ($reset_at <= 0) {
            $reset_at = ('day' === $quota_type)
                ? ('gemini' === $provider ? Quota_Reset_Calculator::gemini_next_rpd_reset_ts() : Quota_Reset_Calculator::generic_next_reset_ts())
                : Plugin_Time::now_utc_ts() + $retry_after;
        }

        $data = array(
            'provider' => $provider,
            'retry_after' => $retry_after,
            'reset_at' => $reset_at,
            'reset_at_local' => Quota_Reset_Calculator::format_in_wp_tz($reset_at),
            'quota_type' => $quota_type,
        );

        if ($error_info !== null) {
            $data['error_info'] = $error_info;
        }

        return new \WP_Error($code, $message, $data);
    }

    /**
	 * Lightweight "Scout" method for Auto-Discovery.
	 */
	public function check_for_updates($software_name, $current_version)
	{
		$resolved = self::resolve_bootstrap_provider();
		if (empty($resolved['ok'])) {
			return false;
		}

	$scout_model_map = [
		'gemini' => 'gemini-2.0-flash',
		'openai' => 'gpt-4o-mini',
		'groq' => 'llama-3.1-8b-instant',
		'perplexity' => 'sonar',
		'openrouter' => 'google/gemma-4-26b-a4b-it:free',
	];
$provider = $resolved['provider'];
 $scout_model = $scout_model_map[$provider] ?? self::get_default_model_for_provider($provider);

 $original_provider = $this->provider_name;
 $original_key = $this->api_key;

 $prompt_data = [
			'system' => 'You are a strict JSON content generator. Search the web for the latest stable release. Return ONLY one valid JSON object with keys latestversion, changelogurl, hasupdate.',
			'user'   => sprintf(
				'Search the web for the latest stable release of %s. The current known version is %s. Return ONLY a valid JSON object {"latest_version":"x.x.x","changelog_url":"url-or-empty-string","has_update":true-or-false}.',
				$software_name,
				$current_version
			),
		];

try {
 $this->switch_to_provider_model($provider, $scout_model);
 } catch ( \Exception $e ) {
 $this->logger->error('Scout model switch failed: ' . $e->getMessage());
 $this->restore_provider_state($original_provider, $original_key);
 return false;
 }

 $prompt_data['_resolved_provider'] = $provider;
 $prompt_data['_resolved_model'] = $scout_model;
 $prompt_data['_scout_call'] = true;

 try {
 $result = $this->execute_with_validation($prompt_data);
 } catch ( \Exception $e ) {
 $this->logger->error('Update probe failed: ' . $e->getMessage());
 $this->restore_provider_state($original_provider, $original_key);
 return false;
 }

 $this->restore_provider_state($original_provider, $original_key);

		if (empty($result) || !is_array($result)) {
			return false;
		}

		return [
			'latest_version' => $result['latest_version'] ?? $result['latestversion'] ?? '',
			'changelog_url'  => $result['changelog_url']  ?? $result['changelogurl']  ?? '',
			'has_update'     => $result['has_update']     ?? $result['hasupdate']     ?? false,
		];
	}



	/**
	 * Acquire a named per-provider mutex using the options table.
	 * Stale locks (> 90 s) are evicted atomically before the attempt.
	 */
	private function acquire_lock( string $provider ): bool {
		global $wpdb;

		$lock_key = 'seo_gen_api_lock_' . \sanitize_key( $provider );
		$now      = (string) \time();
		$table    = $wpdb->options;

		// Atomically evict any lock older than 90 seconds.
		$wpdb->query( $wpdb->prepare(
			"DELETE FROM {$table}
			  WHERE option_name = %s
			    AND CAST(option_value AS UNSIGNED) < %d",
			$lock_key,
			\time() - 90
		) );

		// Attempt atomic claim; fails silently on duplicate-key.
		$wpdb->suppress_errors( true );
		$claimed = (bool) $wpdb->query( $wpdb->prepare(
			"INSERT INTO {$table} (option_name, option_value, autoload)
			 VALUES (%s, %s, 'no')",
			$lock_key,
			$now
		) );
		$wpdb->suppress_errors( false );

		return $claimed;
	}

	/**
	 * Release the per-provider mutex.
	 */
	private function release_lock( string $provider ): void {
		\delete_option( 'seo_gen_api_lock_' . \sanitize_key( $provider ) );
	}

	private static function mark_provider_misconfigured(string $provider, string $reason, int $ttl = 86400, string $model = ''): void
	{
		$key = 'seo_gen_api_misconfigured_' . $provider;
		if ($model !== '') {
			$key .= '_' . md5($model);
		}
		\set_transient($key, 1, $ttl);
		\update_option('seo_gen_api_pause_reason_' . $provider, $reason, false);
		if ($model !== '') {
			\update_option('seo_gen_api_pause_reason_' . $provider . '_' . md5($model), $reason, false);
		}
	}

	public static function is_provider_misconfigured(string $provider, string $model = ''): bool
	{
		if ($model !== '') {
			$model_key = 'seo_gen_api_misconfigured_' . $provider . '_' . md5($model);
			if ((bool) \get_transient($model_key)) {
				return true;
			}
		}
		return (bool) \get_transient('seo_gen_api_misconfigured_' . $provider);
	}

    private static function is_model_not_found_response(string $provider, int $status_code, string $response_body): bool
    {
        if ($status_code !== 404 && $status_code !== 400) {
            return false;
        }

        $info = API_Error_Parser::parse($provider, $status_code, $response_body);
        return $info->get_error_type() === API_Error_Info::TYPE_MODEL_NOT_FOUND;
    }

	/**
	 * Determine if response indicates authentication/permission failure
	 *
	 * @param string $provider
	 * @param int $status_code
	 * @param string $response_body
	 * @return bool
	 */
    private static function is_provider_auth_failure(string $provider, int $status_code, string $response_body): bool
    {
        if ($status_code !== 401 && $status_code !== 403) {
            return false;
        }

        $info = API_Error_Parser::parse($provider, $status_code, $response_body);
        return $info->get_error_type() === API_Error_Info::TYPE_AUTH_FAILURE;
    }

	/**
	 * Determine if response indicates request-shape error (400 INVALID_ARGUMENT)
	 * These should fail the request but NOT poison provider state
	 *
	 * @param string $provider
	 * @param int $status_code
	 * @param string $response_body
	 * @return bool
	 */
    private static function is_request_shape_invalid_response(string $provider, int $status_code, string $response_body): bool
    {
        if ($status_code !== 400) {
            return false;
        }

        $info = API_Error_Parser::parse($provider, $status_code, $response_body);
        return $info->get_error_type() === API_Error_Info::TYPE_REQUEST_SHAPE;
    }

	public static function get_api_key_for_provider(string $provider): string
    {
		$registry = Provider_Registry::get_instance();
		if ($registry->is_custom($provider)) {
			$profile = $registry->get_custom_profile($provider);
			return (string) ($profile['api_key'] ?? '');
		}
        switch (strtolower(trim($provider))) {
            case 'openai':
                return (string) self::get_openai_key();

            case 'perplexity':
                return (string) self::get_perplexity_key();

		case 'groq':
			return (string) self::get_groq_key();

		case 'openrouter':
			return (string) self::get_openrouter_key();

		case 'gemini':
            default:
                return (string) self::get_gemini_key();
        }
    }

    public static function resolve_bootstrap_provider(): array
    {
        $status = self::get_provider_status();

        if (!empty($status['routable'][0]['provider'])) {
            $provider = (string) $status['routable'][0]['provider'];
            $model    = (string) ($status['routable'][0]['model'] ?? '');

            return array(
                'ok'        => true,
                'provider'  => $provider,
                'api_key'   => self::get_api_key_for_provider($provider),
                'model'     => $model,   // snapshot-chosen ready model (2.34.12)
                'status'    => $status,
            );
        }

        if (self::is_provider_only_mode_enabled()) {
            $locked = self::get_locked_provider_id();
            $data   = self::get_provider_details($locked);

            return array(
                'ok'          => false,
                'temporary'   => (($data['state'] ?? '') === 'cooldown'),
                'retry_after' => max(60, (int) ($data['retry_after'] ?? 60)),
                'reason'      => \sprintf(
                    'Provider-only mode is enabled. Selected provider "%s" is not available (%s).',
                    $locked,
                    (string) ($data['state'] ?? 'unknown')
                ),
                'status'      => $status,
            );
        }

        $providers = array();
        foreach ((array) ($status['providers_detail'] ?? array()) as $row) {
            $providers[] = \sprintf(
                '%s:%s',
                (string) ($row['provider'] ?? 'unknown'),
                (string) ($row['reason'] ?? 'unknown')
            );
        }

        return array(
            'ok'          => false,
            'temporary'   => !empty($status['temporary_blocked']),
            'retry_after' => max(60, (int) ($status['min_retry_after'] ?? 60)),
            'reason'      => 'No active AI providers available' . (!empty($providers) ? ' (' . \implode(', ', $providers) . ')' : ''),
            'status'      => $status,
        );
    }

	/**
	 * @MODIFIED 2026-04-07: Centralized Exhaustive Reset
	 * Performs a deep purge of all API states across all providers and models.
	 */
	public static function reset_all_cooldowns(): void
	{
		global $wpdb;

		// 1. Wildcard SQL Wipe (DB Fallback)
		$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_seo_gen_api_cooldown_%'");
		$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_seo_gen_api_cooldown_%'");
		$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_seo_gen_api_error_count_%'");
		$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_seo_gen_api_error_count_%'");
		$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE 'seo_gen_api_pause_reason_%'");
		// Model-scoped misconfigured flags also carry an md5(model) suffix.
		$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_seo_gen_api_misconfigured_%'");
		// Daily quota block transients (seogen_daily_quota_reset_{provider}).
		$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_seogen_daily_quota_reset_%'");
		$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_seogen_daily_quota_reset_%'");
		// [2.34.13] Phase 3Q: Circuit breaker state.
		$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_seo_gen_cb_%'");
		$wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_timeout_seo_gen_cb_%'");

		// 2. Explicit API Purge (Object Cache safe)
	 $registry = Provider_Registry::get_instance();
	 foreach (self::get_all_providers() as $p) {
	 \delete_transient('seo_gen_api_cooldown_' . $p);
	 \delete_transient('seo_gen_api_error_count_' . $p);
	 \delete_option('seo_gen_api_pause_reason_' . $p);
	 \delete_option('seogenapilastcall_' . \sanitize_key($p));
	 \delete_transient('seo_gen_api_misconfigured_' . $p);
	 \delete_transient('seogen_daily_quota_reset_' . $p);
	 // [2.34.13] Phase 3Q: Reset circuit breaker for each provider.
	 self::cb_reset( $p );

		if ($registry->is_custom($p)) {
				$profile = $registry->get_custom_profile($p);
				$models = $profile['models'] ?? [];
				foreach ((array)$models as $m) {
					$ms = (string) ($m['model_id'] ?? '');
					if ($ms !== '') {
						\delete_transient('seo_gen_api_cooldown_' . $p . '_' . md5($ms));
						\delete_transient('seo_gen_api_error_count_' . $p . '_' . md5($ms));
						\delete_transient('seo_gen_api_misconfigured_' . $p . '_' . md5($ms));
					}
				}
			} else {
				$models = self::get_supported_models($p);
				foreach ($models as $m) {
					$ms = (string) $m;
					\delete_transient('seo_gen_api_cooldown_' . $p . '_' . md5($ms));
					\delete_transient('seo_gen_api_error_count_' . $p . '_' . md5($ms));
					\delete_transient('seo_gen_api_misconfigured_' . $p . '_' . md5($ms));
				}

				$current = \get_option('seo_gen_' . $p . '_model');
				if ($current) {
					\delete_transient('seo_gen_api_cooldown_' . $p . '_' . md5($current));
				}
			}
		}

		// 3. Clear base keys
		\delete_transient('seo_gen_api_cooldown');
		\delete_transient('seo_gen_api_error_count');
		\delete_option('seo_gen_api_pause_reason');

		// 4. Set reset timestamp for the 45s "Hard Override"
		\update_option('seo_gen_last_manual_reset', Plugin_Time::now_utc_ts(), false);

		if (\function_exists('wp_cache_flush')) {
			\wp_cache_flush();
		}
	}
}
