<?php

namespace DIT\TrendStudio\Integrations\Buffer;

if (!defined('ABSPATH')) {
    exit;
}

class Account_Manager
{
    const STORAGE_KEY = 'dit_ts_buffer_accounts';

    private static $cache = null;

    public static function get_accounts(): array
    {
        if (self::$cache !== null) {
            return self::$cache;
        }

        $raw = get_option(self::STORAGE_KEY, []);
        if (is_string($raw)) {
            $raw = json_decode($raw, true);
        }
        if (!is_array($raw)) {
            $raw = [];
        }

        // Backward-compat: migrate legacy single-account options
        if (empty($raw)) {
            $legacy_token = get_option('nm_buffer_access_token', '');
            if (!empty($legacy_token)) {
                $legacy = self::build_legacy_profile();
                if ($legacy !== null) {
                    $raw = [$legacy['id'] => $legacy];
                }
            }
        }

        $indexed = [];
        foreach ($raw as $profile) {
            if (!empty($profile['id'])) {
                $id = (string) $profile['id'];
                $profile['channels'] = $profile['channels'] ?? [];
                $indexed[$id] = $profile;
            }
        }
        self::$cache = $indexed;
        return self::$cache;
    }

    public static function get_account(string $id): ?array
    {
        $accounts = self::get_accounts();
        return $accounts[$id] ?? null;
    }

    public static function get_enabled_accounts(): array
    {
        $all = self::get_accounts();
        return array_filter($all, function ($a) {
            return !empty($a['enabled']);
        });
    }

    public static function save_accounts(array $accounts): void
    {
        $validated = [];
        foreach ($accounts as $profile) {
            if (empty($profile['id'])) {
                continue;
            }
            $id = sanitize_key($profile['id']);
            $validated[$id] = [
                'id' => $id,
                'name' => sanitize_text_field($profile['name'] ?? $id),
                'api_key' => sanitize_text_field($profile['api_key'] ?? ''),
                'enabled' => !empty($profile['enabled']),
                'daily_limit' => max(0, min(50, (int) ($profile['daily_limit'] ?? 5))),
                'channels' => self::sanitize_channels($profile['channels'] ?? []),
            ];
        }
        update_option(self::STORAGE_KEY, $validated);
        self::clear_cache();
    }

    public static function clear_cache(): void
    {
        self::$cache = null;
    }

    public static function get_tracker_key(string $account_id): string
    {
        return 'nm_buffer_pub_tracker_' . $account_id;
    }

    private static function sanitize_channels(array $channels): array
    {
        $clean = [];
        foreach ($channels as $ch_id => $config) {
            $ch_id = sanitize_text_field((string) $ch_id);
            if (empty($ch_id)) {
                continue;
            }
            $clean[$ch_id] = [
                'enabled' => !empty($config['enabled']),
                'post_type' => in_array($config['post_type'] ?? 'post', ['post', 'story', 'reel', 'video'], true)
                    ? $config['post_type'] : 'post',
                'template' => isset($config['template'])
                    ? sanitize_textarea_field(wp_unslash($config['template']))
                    : '',
                'is_link_post' => !empty($config['is_link_post']),
                'pinterest_board_id' => sanitize_text_field($config['pinterest_board_id'] ?? ''),
                'pinterest_title' => sanitize_text_field($config['pinterest_title'] ?? ''),
                'youtube_title' => sanitize_text_field($config['youtube_title'] ?? ''),
                'youtube_category_id' => sanitize_text_field($config['youtube_category_id'] ?? ''),
                'youtube_privacy' => sanitize_text_field($config['youtube_privacy'] ?? ''),
                'youtube_embeddable' => !empty($config['youtube_embeddable']),
                'youtube_license' => sanitize_text_field($config['youtube_license'] ?? ''),
                'youtube_made_for_kids' => !empty($config['youtube_made_for_kids']),
                'youtube_notify_subscribers' => !empty($config['youtube_notify_subscribers']),
                'youtube_is_ai_generated' => !empty($config['youtube_is_ai_generated']),
                'share_as_story' => !empty($config['share_as_story']),
            ];
        }
        return $clean;
    }

    private static function build_legacy_profile(): ?array
    {
        $token = get_option('nm_buffer_access_token', '');
        if (empty($token)) {
            return null;
        }
        $channels_raw = get_option('nm_buffer_enabled_channels', []);
        if (!is_array($channels_raw)) {
            $channels_raw = [];
        }
        $enabled_channels = array_map('sanitize_text_field', $channels_raw);

        $channel_types = get_option('nm_buffer_channel_types', []);
        $channel_templates = get_option('nm_buffer_channel_templates', []);
        $channel_link_posts = get_option('nm_buffer_channel_link_posts', []);
        $channel_pinterest_boards = get_option('nm_buffer_channel_pinterest_boards', []);
        $channel_pinterest_titles = get_option('nm_buffer_channel_pinterest_titles', []);

        $channels = [];
        foreach ($enabled_channels as $ch_id) {
            $channels[$ch_id] = [
                'enabled' => true,
                'post_type' => $channel_types[$ch_id] ?? 'post',
                'template' => $channel_templates[$ch_id] ?? '',
                'is_link_post' => !empty($channel_link_posts[$ch_id]),
                'pinterest_board_id' => $channel_pinterest_boards[$ch_id] ?? '',
                'pinterest_title' => $channel_pinterest_titles[$ch_id] ?? '',
            ];
        }

        return [
            'id' => 'legacy',
            'name' => 'Default Account',
            'api_key' => $token,
            'enabled' => (bool) get_option('nm_buffer_enabled', false),
            'daily_limit' => (int) get_option('nm_buffer_daily_limit', 5),
            'channels' => $channels,
        ];
    }
}
