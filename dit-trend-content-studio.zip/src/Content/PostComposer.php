<?php

/**
 * Content Formatter
 *
 * @package DIT_TrendStudio
 * @MODIFIED 2025-12-13 - New magazine-style formatter, no download/software sections
 * @MODIFIED 2025-12-13 - Added scoped wrapper and URL validation for sources
 * @MODIFIED 2025-12-13 - P0: Added image attribution and editor-only verification badges
 * @MODIFIED 2025-12-14 - Added to_block_markup() for Gutenberg-native output
 */

namespace DIT\TrendStudio\Content;

use DIT\TrendStudio\Content\Media\MediaMatcher; // @MODIFIED 2026-02-16 - Phase 2 Fashion Matcher
use DIT\TrendStudio\Schema\Content_Schema; // @MODIFIED 2026-02-17 - Fix Class Not Found
use DIT\TrendStudio\Services\Media_Inventory; // @MODIFIED 2026-02-24 - Robust attachment resolution

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Formats content into strict HTML blocks
 */
class PostComposer
{
    /**
     * Current article title (used for consistent image alt text, etc.)
     * @since 2.2.0
     */
    private string $current_post_title = '';
    /**
     * Allowed CSS classes (allowlist enforcement)
     * @MODIFIED 2025-12-14 - Prevent class-spam
     * @MODIFIED 2025-12-27 - Added content block classes
     */
    private const ALLOWED_CLASSES = [
        'dit-ts-article',
        'dit-ts-dek',
        'dit-ts-pullquote-accent',
        'dit-ts-sources',
        'dit-ts-source-item',
        'dit-ts-byline',
        'dit-ts-callout',
        'dit-ts-callout-title',
        'dit-ts-content-block',
        'dit-ts-trend_summary',
        'dit-ts-what_to_buy',
        'dit-ts-how_to_wear',
        'dit-ts-fit_guidance',
        'dit-ts-care_notes',
        'dit-ts-product_picks',
        'dit-ts-application_tips',
        'dit-ts-skin_type_guidance',
        'dit-ts-ingredient_notes',
        'dit-ts-key_facts',
        'dit-ts-timeline',
        'dit-ts-expert_context',
        'dit-ts-verdict-box',
    ];

    /**
     * Transform inline citation markers [n] to anchor links.
     *
     * Converts audit-friendly `[1]`, `[2]` markers to clickable links
     * pointing to the Sources section (Option A) or external URLs (Option B).
     *
     * @since 1.8.0 Phase 4: Hybrid render-time transformation
     * @param string $content       HTML content with [n] markers
     * @param array  $sources_index Numbered source index [{id, label, url}, ...]
     * @param string $link_style    'anchor' (link to #sources-n) or 'external' (direct URL)
     * @return string Content with [n] replaced by links
     */
    public function transform_citation_markers(string $content, array $sources_index, string $link_style = 'anchor'): string
    {
        if (empty($sources_index)) {
            return $content;
        }

        // Build lookup map: id => source data
        $source_map = [];
        foreach ($sources_index as $source) {
            $source_map[$source['id']] = $source;
        }

        // Replace [n] with appropriate links
        $content = preg_replace_callback(
            '/\[(\d+)\]/',
            function ($matches) use ($source_map, $link_style) {
                $id = (int) $matches[1];

                if (!isset($source_map[$id])) {
                    // Invalid citation ID - keep original marker
                    return $matches[0];
                }

                $source = $source_map[$id];
                $label = esc_html($source['label'] ?? $source['url']);

                if ($link_style === 'external') {
                    // Option B: Direct external link
                    $url = esc_url($source['url']);
                    return sprintf(
                        '<sup class="dit-ts-citation"><a href="%s" target="_blank" rel="noopener noreferrer" title="%s">[%d]</a></sup>',
                        $url,
                        $label,
                        $id
                    );
                } else {
                    // Option A: Plain text marker (since Sources section is hidden from frontend)
                    return sprintf(
                        '<sup class="dit-ts-citation" title="%s">[%d]</sup>',
                        $label,
                        $id
                    );
                }
            },
            $content
        );

        return $content;
    }

    /**
     * Convert article data to Gutenberg block markup
     * @MODIFIED 2025-12-14 - Primary output method for editor-friendly content
     * @MODIFIED 2025-12-14 - Removed outer wrapper group for portal-native output
     *
     * @param array $article Article data array
     * @param bool  $wrap_in_group Optional: wrap in group block for CSS scoping (default false)
     * @return string Block-serialized content
     */
    public function to_block_markup(array $article, bool $wrap_in_group = false): string
    {
        $schema = Content_Schema::from_array($article);

        // Use headline as canonical title for alt text and other render decisions.
        $this->current_post_title = trim((string) ($schema->headline ?: ($article['headline'] ?? '')));

        $blocks = [];

        // Dek as paragraph block
        if (!empty($schema->dek)) {
            // @MODIFIED 2026-02-18 - Use wp_kses_post to support AI-generated formatting/entities
            $blocks[] = $this->serialize_block(
                'core/paragraph',
                [], // no className
                '<p>' . wp_kses_post($schema->dek) . '</p>'
            );
        }

        // Process rankable content blocks (What to Buy, etc.)
        if (!empty($schema->content_blocks)) {
            $blocks = array_merge($blocks, $this->format_content_blocks($schema->content_blocks, $schema->vertical));
        }

        // Main content sections
        $first_section = true;
        foreach ($schema->sections as $section) {
            if (!empty($section['blocks']) && is_array($section['blocks'])) {
                $section_blocks = $this->section_structured_blocks_to_blocks($section, $first_section, $schema, $article);
            } else {
                $section_blocks = $this->section_to_blocks($section, $first_section, $schema);
            }
            $blocks = array_merge($blocks, $section_blocks);
            $first_section = false;
        }

        // Join blocks as flat sequence (no outer wrapper by default)
        $inner_content = implode("\n\n", $blocks);

        // @MODIFIED 2026-01-12 - Enhance UI elements (Verdict Boxes only) via Regex Post-Processing
        $inner_content = $this->enhance_ui_elements($inner_content);

        // @MODIFIED 2026-01-26 - Parse Markdown (Bold/Italic) fix for AI output
        $inner_content = $this->parse_markdown_global($inner_content);

        // @REMOVED 2026-02-06 - Bolding moved to preprocess step (before block serialization) to prevent fragmentation

        // @MODIFIED 2026-01-14 - Remove top-level group wrapper by default for native block output
        if ($wrap_in_group) {
            // @FIX 2026-01-16 - Wrap inner content in div to prevent "Block Recovery" error
            $wrapped_inner = '<div class="wp-block-group dit-ts-article">' . $inner_content . '</div>';
            return $this->serialize_block('core/group', [
                'className' => 'dit-ts-article',
                'layout' => ['type' => 'constrained'] // @MODIFIED 2026-01-19 - Added layout constraint
            ], $wrapped_inner);
        }

        return $inner_content;
    }

    /**
     * Preprocess section HTML before block parsing
     * 
     * @MODIFIED 2026-02-17 - Added html_entity_decode to fix double-encoded AI output
     * @MODIFIED 2026-02-11 - Removed manual bolding/quote processing (AI handles this now)
     * 
     * @param string $html Raw section body HTML
     * @param object|null $schema Article schema (for vertical detection)
     * @return string Preprocessed HTML
     */
    private function preprocess_section_html(string $html, $schema = null): string
    {
        // Decode HTML entities to ensure AI-generated encoded tags (e.g. &lt;strong&gt;) are treated as markup.
        // This is safe because we sanitize/whitelist tags later in parse_body_to_elements.
        // We use ENT_QUOTES | ENT_HTML5 to catch all entities including single quotes and HTML5 named entities.
        $html = html_entity_decode($html, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        // Manual bolding logic removed: AI is now natively instructed to handle bolding 
        // for entities, fabrics, and quotes within the PromptBlueprint/Client schemas.
        return $html;
    }


    /**
     * Detects and formats special UI patterns (Tables, Pros/Cons, Verdicts)
     * @MODIFIED 2026-01-12 - NEW: Post-processing for rich UI elements
     * 
     * @param string $html_content Raw block content
     * @return string Content with enhanced block markup
     */
    private function enhance_ui_elements(string $html_content): string
    {
        // 1. (Removed) Table conversion is now handled natively in section_to_blocks

        // 2. Format "Verdict" or "Quick Answer" boxes
        // If we see a section labeled "Verdict" or "Quick Take", wrap it in a colored group
        return $html_content;
    }

    /**
     * Convert section to block array
     * @MODIFIED 2025-12-14 - Fixed contract: wraps paragraphs in <p> here (not in parse_body)
     * @MODIFIED 2025-12-14 - Added list block support for <ul>/<ol>
     * @MODIFIED 2025-12-14 - Added core/image block for selected images
     * @MODIFIED 2026-01-12 - Added support for Tables, Blockquotes, and Headings
     * @MODIFIED 2026-02-06 - Added $schema parameter for preprocessing
     *
     * @param array $section Section data
     * @param bool  $is_first Whether this is the first section
     * @param object|null $schema Article schema (for preprocessing)
     * @return array Block strings
     */
    private function section_to_blocks(array $section, bool $is_first, $schema = null): array
    {
        $blocks = [];
        $heading = $section['heading'] ?? '';
        $body = $section['body_html'] ?? '';

        if (empty($body)) {
            return [];
        }
        $selected_image = $section['selected_image'] ?? null;

        // Heading (skip for introduction)
        // @MODIFIED 2026-01-16 - Suppress Internal Keys strings from becoming Headings
        $internal_keys = ['verdict_box', 'comparison_table', 'buying_guide', 'sources', 'quick_answer', 'deep_dive', 'myth_busting', 'related_topics'];
        $is_internal_key_only = in_array(strtolower($heading), $internal_keys);

        // Strip prefixes like "quick_answer:" or "myth_busting:" from the visual heading
        $clean_heading = preg_replace('/^(?:' . implode('|', $internal_keys) . '):\s*/i', '', $heading);

        if (!empty($clean_heading) && strtolower($clean_heading) !== 'introduction' && !$is_internal_key_only) {
            // @MODIFIED 2026-02-18 - Use wp_kses_post to support AI-generated formatting/entities
            $blocks[] = $this->serialize_block('core/heading', [
                'level' => 2,
                'className' => 'wp-block-heading', // @MODIFIED 2026-01-19 - Gutenberg compliance
            ], '<h2 class="wp-block-heading">' . wp_kses_post($clean_heading) . '</h2>');
        }

        // Insert selected image after heading (if any)
        if (!empty($selected_image) && !empty($selected_image['full'])) {
            $blocks[] = $this->format_image_block($selected_image, $heading);
        }

        // @MODIFIED 2026-02-06 - Preprocess HTML before parsing (apply bolding to raw HTML, not serialized blocks)
        $body = $this->preprocess_section_html($body, $schema);

        // Parse body into block elements (paragraphs and lists)
        $elements = $this->parse_body_to_elements($body);

        // Enforce deterministic visual placement for fashion_pk.
        if ($schema && (($schema->vertical ?? '') === 'fashion_pk')) {
            $elements = $this->enforce_fashion_pk_visual_layout($elements, $is_first);
        }
        $first_para = true;

        foreach ($elements as $element) {
            if ($element['type'] === 'list') {
                $html = $element['html'] ?? '';
                $html = preg_replace('/^<(ul|ol)\b/i', '<$1 class="wp-block-list"', $html);

                $blocks[] = $this->serialize_block('core/list', [
                    'ordered' => ($element['list_type'] === 'ol'),
                ], $html);
            } elseif ($element['type'] === 'table') {
                // Emit core/table block
                $blocks[] = $this->serialize_block('core/table', [
                    'className' => 'is-style-stripes',
                ], $element['html']);
            } elseif ($element['type'] === 'blockquote') {
                // Emit core/quote block. Gutenberg requires <blockquote><p> content for core/quote recovery.
                $quote_html = '<blockquote class="wp-block-quote"><p>' . trim($element['content']) . '</p></blockquote>';
                $blocks[] = $this->serialize_block('core/quote', [], $quote_html);
            } elseif ($element['type'] === 'embed') {
                $blocks[] = $this->format_embed_block($element['url'] ?? '', $element['provider'] ?? 'embed');
            } elseif ($element['type'] === 'image') {
                // Emit core/image block from inline content
                $image_data = [
                    'full' => $element['src'],
                    'alt'  => $element['alt'],
                    'attribution' => $element['attribution'] ?? '',
                ];
                $blocks[] = $this->format_image_block($image_data, $image_data['alt']);
            } elseif ($element['type'] === 'heading') {
                // Emit core/heading block
                $blocks[] = $this->serialize_block('core/heading', [
                    'level' => $element['level'] ?? 3,
                    'className' => 'wp-block-heading', // @MODIFIED 2026-01-19
                ], '<h' . ($element['level'] ?? 3) . ' class="wp-block-heading">' . $element['text'] . '</h' . ($element['level'] ?? 3) . '>');
            } else {
                // Paragraph
                $attrs = [];

                // Drop cap on first paragraph of first section
                if ($is_first && $first_para) {
                    // @MODIFIED 2026-01-27 - Drop Cap disabled per user request
                    $clean_content = preg_replace('/^<p[^>]*>(.*)<\/p>$/is', '$1', trim($element['content']));
                    $element['content'] = '<p>' . $clean_content . '</p>';
                } else {
                    $clean_content = preg_replace('/^<p[^>]*>(.*)<\/p>$/is', '$1', trim($element['content']));
                    $element['content'] = '<p>' . $clean_content . '</p>';
                }

                // Wrap inline content in <p> exactly once
                $blocks[] = $this->serialize_block('core/paragraph', $attrs, $element['content']);
                $first_para = false;
            }
        }

        // Insert editorial callout after section content (if any)
        if (!empty($section['editorial_callout'])) {
            $blocks[] = $this->format_callout_block($section['editorial_callout']);
        }

        return $blocks;
    }

    /**
     * Format editorial callout as Gutenberg group block
     * @MODIFIED 2026-03-09 - Properly wrap in core/group block for styling stability.
     *
     * @param array $callout Callout data ['title' => string, 'content' => string]
     * @return string Serialized block
     */
    private function format_callout_block(array $callout): string
    {
        $allowed_tags = [
            'em'     => [],
            'strong' => [],
            'a'      => ['href' => [], 'title' => [], 'target' => []],
            'ul'     => [],
            'ol'     => [],
            'li'     => [],
        ];
        $title = wp_kses_post($callout['title'] ?: 'EDITOR\'S INSIGHT');
        $content = wp_kses($callout['content'] ?? '', $allowed_tags);

        $inner_blocks = [];
        $inner_blocks[] = $this->serialize_block('core/paragraph', [
            'className' => 'dit-ts-callout-title',
        ], '<p class="dit-ts-callout-title"><strong>' . $title . '</strong></p>');

        $paras = preg_split('/\n\s*\n/', $content);
        foreach ($paras as $para) {
            $cleaned = trim($para);
            if (!empty($cleaned)) {
                $inner_blocks[] = $this->serialize_block('core/paragraph', [], '<p>' . $cleaned . '</p>');
            }
        }

        $inner_html = implode("\n", $inner_blocks);
        $wrapped_html = '<div class="wp-block-group dit-ts-callout">' . $inner_html . '</div>';

        return $this->serialize_block('core/group', [
            'className' => 'dit-ts-callout',
            'layout' => ['type' => 'constrained']
        ], $wrapped_html);
    }

    /**
     * Format content blocks for rankability (what_to_buy, how_to_wear, etc.)
     * @since 1.8.1
     *
     * @param array  $content_blocks Content blocks from AI
     * @param string $vertical       Content vertical
     * @return array Serialized block strings
     */
    private function format_content_blocks(array $content_blocks, string $vertical): array
    {
        $blocks = [];

        // @MODIFIED 2026-01-28 - Showbiz Override: Do not render content blocks (4-para layout violation)
        if ($vertical === 'showbiz') {
            return [];
        }

        // @MODIFIED 2026-01-28 - Filter allowlist to prevent hallucinations (e.g. 'the_scoop')
        // Using namespace alias might be tricky if not imported, so using fully qualified name or helper
        // Assuming DIT\TrendStudio\Schema\Content_Blocks exists
        if (class_exists('DIT\TrendStudio\Schema\Content_Blocks')) {
            $allowed = array_keys(\DIT\TrendStudio\Schema\Content_Blocks::get_required_blocks($vertical));
            // Also allow common fallbacks if schema is strict? No, strict is better.
            $content_blocks = array_intersect_key($content_blocks, array_flip($allowed));
        }

        // Block type to human-readable heading map
        $block_labels = [
            'trend_summary' => 'Key Trends',
            'what_to_buy' => 'What to Buy',
            'how_to_wear' => 'How to Wear It',
            'fit_guidance' => 'Fit & Sizing Guide',
            'care_notes' => 'Care & Maintenance',
            'product_picks' => 'Product Picks',
            'application_tips' => 'Application Tips',
            'skin_type_guidance' => 'Skin Type Guide',
            'ingredient_notes' => 'Ingredient Notes',
            'key_facts' => 'Key Facts',
            'timeline' => 'Timeline',
            'expert_context' => 'Expert Context',
        ];

        foreach ($content_blocks as $block_type => $items) {
            if (empty($items) || !is_array($items)) {
                continue;
            }

            $label = $block_labels[$block_type] ?? ucwords(str_replace('_', ' ', $block_type));

            // Create heading for block
            $block_group = [];
            $block_group[] = $this->serialize_block('core/heading', [
                'level' => 3,
                'className' => 'wp-block-heading', // @MODIFIED 2026-01-19
            ], '<h3 class="wp-block-heading">' . wp_kses_post($label) . '</h3>');

            // Render items as list
            $list_items = '';
            foreach ($items as $item) {
                if (is_array($item)) {
                    // Complex item (e.g., what_to_buy with type/why/suits)
                    $item_text = '';
                    if (!empty($item['type'])) {
                        $item_text .= '<strong>' . wp_kses_post($item['type']) . '</strong>';
                        if (!empty($item['why'])) {
                            $item_text .= ' – ' . wp_kses_post($item['why']);
                        }
                        if (!empty($item['suits'])) {
                            $item_text .= ' <em>(Suits: ' . wp_kses_post($item['suits']) . ')</em>';
                        }
                    } elseif (!empty($item['text'])) {
                        $item_text = wp_kses_post($item['text']);
                    } else {
                        // Fallback: stringify first available value
                        $item_text = wp_kses_post(reset($item) ?: '');
                    }
                    if (!empty($item_text)) {
                        $list_items .= '<li>' . $item_text . '</li>';
                    }
                } else {
                    // Simple string item
                    $list_items .= '<li>' . wp_kses_post($item) . '</li>';
                }
            }

            if (!empty($list_items)) {
                $block_group[] = $this->serialize_block('core/list', [
                    'ordered' => false,
                    'className' => 'wp-block-list', // @MODIFIED 2026-01-19
                ], '<ul class="wp-block-list">' . $list_items . '</ul>');
            }

            // Add blocks directly to the main array (No Group Wrapper)
            if (!empty($block_group)) {
                foreach ($block_group as $bg_block) {
                    $blocks[] = $bg_block;
                }
            }
        }

        return $blocks;
    }

    /**
     * Format image as Gutenberg image block with deterministic metadata.
     * @MODIFIED 2026-03-09 - Added data-dit-visual and data-dit-hint injection (Issue #PrecisionMedia)
     *
     * @param array  $image   Image data
     * @param string $alt     Alt text fallback
     * @return string Serialized block
     */
    private function format_image_block(array $image, string $alt = ''): string
    {
        $url = $image['full'] ?? $image['regular'] ?? '';

        // Resolve attachment ID for local images
        $attachment_id = !empty($image['id']) ? (int)$image['id'] : attachment_url_to_postid($url);

        if (!$attachment_id && class_exists('DIT\TrendStudio\Services\Media_Inventory')) {
            $inventory = new \DIT\TrendStudio\Services\Media_Inventory();
            $attachment_id = $inventory->resolve_attachment_id_from_url($url);
        }

        $esc_url = esc_url($url);
        $raw_alt = trim((string)($image['alt'] ?? $alt));
        if ($raw_alt === '' && $this->current_post_title !== '') {
            $raw_alt = $this->current_post_title;
        }

        $clean_text = esc_attr(wp_specialchars_decode(strip_tags((string)$raw_alt), ENT_QUOTES));

        // METADATA INJECTION: visual_idx and hint for deterministic recovery
        $metadata_attrs = '';
        if (isset($image['visual_idx'])) {
            $metadata_attrs .= sprintf(' data-dit-visual="%d"', (int)$image['visual_idx']);
        }
        if (!empty($image['hint'])) {
            $metadata_attrs .= sprintf(' data-dit-hint="%s"', esc_attr($image['hint']));
        }

        $html = '<figure class="wp-block-image size-large">';
        $img_attr = sprintf('src="%s" alt="%s" title="%s"%s', $esc_url, $clean_text, $clean_text, $metadata_attrs);
        if ($attachment_id) {
            $img_attr .= sprintf(' class="wp-image-%d"', $attachment_id);
        }

        $html .= sprintf('<img %s/>', $img_attr);
        $html .= '</figure>';

        $block_attrs = [
            'sizeSlug' => 'large',
            'linkDestination' => 'none',
        ];
        if ($attachment_id) {
            $block_attrs['id'] = $attachment_id;
        }

        return $this->serialize_block('core/image', $block_attrs, $html);
    }

    /**
     * Format embed as Gutenberg embed block
     * @MODIFIED 2026-02-21 - Centralized fix for YouTube "Invalid Content"
     *
     * @param string $url      Embed URL
     * @param string $provider Provider slug
     * @return string Serialized block
     */
    private function format_embed_block(string $url, string $provider = 'embed'): string
    {
        $url = trim($url);
        if ($url === '') {
            return '';
        }

        // @MODIFIED 2026-02-22 - Normalize provider for all known social/video platforms (was youtube/vimeo only)
        if ($provider === 'embed') {
            if (stripos($url, 'youtube.com') !== false || stripos($url, 'youtu.be') !== false) {
                $provider = 'youtube';
            } elseif (stripos($url, 'vimeo.com') !== false) {
                $provider = 'vimeo';
            } elseif (stripos($url, 'instagram.com') !== false) {
                $provider = 'instagram';
            } elseif (stripos($url, 'tiktok.com') !== false) {
                $provider = 'tiktok';
            } elseif (stripos($url, 'twitter.com') !== false || stripos($url, 'x.com') !== false) {
                $provider = 'twitter';
            } elseif (stripos($url, 'facebook.com') !== false || stripos($url, 'fb.watch') !== false) {
                $provider = 'facebook';
            }
        }

        $is_youtube = ($provider === 'youtube');
        $is_vimeo   = ($provider === 'vimeo');
        $is_video   = ($is_youtube || $is_vimeo);
        $is_rich    = in_array($provider, ['twitter', 'instagram', 'tiktok', 'facebook', 'pinterest', 'youtube', 'vimeo', 'embed'], true);

        // Standard WordPress Type
        $block_type = ($is_video) ? 'video' : ($is_rich ? 'rich' : 'video');

        // Build Figure Class (MUST match block_type to avoid "Invalid Content")
        $figure_class  = 'wp-block-embed';
        $figure_class .= ' is-type-' . $block_type;
        $figure_class .= ' is-provider-' . $provider;
        $figure_class .= ' wp-block-embed-' . $provider;

        $extra_className = '';
        if ($is_video) {
            $extra_className = 'wp-embed-aspect-16-9 wp-has-aspect-ratio';
            $figure_class .= ' ' . $extra_className;
        }

// @MODIFIED 2026-02-22 - Strip UTM tracking params that corrupt embed URLs (causes u0026 in JSON)
        $url = preg_replace('/[?&](utm_source|utm_campaign|utm_medium)=[^&]*/i', '', $url);
        $url = rtrim($url, '?&');

// @MODIFIED 2026-05-13 - Stripped all wp_oembed_get() pre-fetch. Use bare URL for ALL
// platforms. Pre-fetched oEmbed HTML with <script> tags causes block validation mismatch
// ("Block contains unexpected or invalid content") on TikTok and risks the same on other
// trusted providers (Twitter/X, Pinterest). WordPress resolves oEmbed at render time via
// render_block filters — no need to duplicate it in innerHTML.
        $embed_html = '<figure class="' . esc_attr($figure_class) . '"><div class="wp-block-embed__wrapper">' . "\n" .
                esc_url($url) . "\n" .
                '</div></figure>';

        // Attributes
        $attrs = [
            'url'       => $url,
            'type'      => $block_type,
        ];

        if ($extra_className !== '') {
            $attrs['className'] = $extra_className;
        }

        if ($is_video) {
            $attrs['responsive'] = true;
        }

        if ($is_rich && $provider !== 'embed') {
            $attrs['providerNameSlug'] = $provider;
        }

        return $this->serialize_block('core/embed', $attrs, $embed_html);
    }

    private function cap_image_elements(array $elements, int $max_images): array
    {
        $count = 0;
        $out = [];
        foreach ($elements as $el) {
            if (($el['type'] ?? '') === 'image') {
                $count++;
                if ($count > $max_images) {
                    continue;
                }
            }
            $out[] = $el;
        }
        return $out;
    }

    private function ensure_image_after_first_paragraphs(array $elements, int $paragraphs_needed): array
    {
        $para_indexes = [];
        foreach ($elements as $i => $el) {
            if (($el['type'] ?? '') === 'paragraph') {
                $para_indexes[] = $i;
                if (count($para_indexes) >= $paragraphs_needed) {
                    break;
                }
            }
        }

        foreach ($para_indexes as $pi) {
            if (isset($elements[$pi + 1]) && ($elements[$pi + 1]['type'] ?? '') === 'image') {
                continue;
            }
            $j = $this->find_next_image_index($elements, $pi + 1);
            if ($j === null) break;

            $img = $elements[$j];
            array_splice($elements, $j, 1);
            array_splice($elements, $pi + 1, 0, [$img]);
        }

        return $elements;
    }

    private function ensure_image_after_h3_paragraphs(array $elements): array
    {
        for ($i = 0; $i < count($elements); $i++) {
            $el = $elements[$i] ?? [];
            if (($el['type'] ?? '') !== 'heading' || (int)($el['level'] ?? 0) !== 3) continue;

            $p = null;
            for ($k = $i + 1; $k < count($elements); $k++) {
                if (($elements[$k]['type'] ?? '') === 'paragraph') {
                    $p = $k;
                    break;
                }
                if (($elements[$k]['type'] ?? '') === 'heading') break;
            }
            if ($p === null) continue;

            if (isset($elements[$p + 1]) && ($elements[$p + 1]['type'] ?? '') === 'image') continue;

            $j = $this->find_next_image_index($elements, $p + 1);
            if ($j === null) continue;

            $img = $elements[$j];
            array_splice($elements, $j, 1);
            array_splice($elements, $p + 1, 0, [$img]);
        }
        return $elements;
    }

    private function find_next_image_index(array $elements, int $start): ?int
    {
        for ($i = $start; $i < count($elements); $i++) {
            if (($elements[$i]['type'] ?? '') === 'image') return $i;
        }
        return null;
    }


    /**
     * Detect OEmbed URLs focusing on social platforms
     * @MODIFIED 2026-03-09 - Consolidated precision logic + Asset Rejection (Issue #SocialFix)
     *
     * @param string $text
     * @return array|null
     */
    private function detect_oembed_url(string $text): ?array
    {
        $url = trim(wp_strip_all_tags($text));

        // Must be a single URL token
        if (!preg_match('~^https?://\S+$~i', $url)) {
            return null;
        }

        // Clean trailing punctuation from URL
        $url = rtrim($url, " \t\n\r\0\x0B.,);!?]\"'");

        if ($url === '' || $url === '#' || strpos($url, '#') === 0) {
            return null;
        }

        // REJECT direct asset files from embed queue (Issue #GuardAssetEmbed)
        $asset_exts = ['.jpg', '.jpeg', '.png', '.gif', '.mp4', '.webp', '.pdf'];
        foreach ($asset_exts as $ext) {
            if (stripos($url, $ext) !== false) {
                return null;
            }
        }

        $host = strtolower(parse_url($url, PHP_URL_HOST) ?? '');

        // @MODIFIED 2026-05-06 - Added vm.tiktok.com (TikTok short-link / mobile redirect domain).
        // Added vt.tiktok.com (video redirect variant). Added m.youtube.com (mobile YouTube).
        // instagram.com covers /p/ posts and /reel/ reels via subdomain wildcard check below.
        $map = [
            'youtube'   => ['youtube.com', 'youtu.be', 'm.youtube.com'],
            'vimeo'     => ['vimeo.com', 'player.vimeo.com'],
            'instagram' => ['instagram.com'],
            'tiktok'    => ['tiktok.com', 'vm.tiktok.com', 'vt.tiktok.com'],
            'twitter'   => ['twitter.com', 'x.com', 't.co'],
            'facebook'  => ['facebook.com', 'fb.watch', 'fb.me'],
            'pinterest' => ['pinterest.com', 'pin.it'],
        ];

        foreach ($map as $provider => $hosts) {
            foreach ($hosts as $h) {
                if ($host === $h || (strlen($host) > strlen($h) && substr($host, - (strlen($h) + 1)) === '.' . $h)) {
                    return ['provider' => $provider, 'url' => $url];
                }
            }
        }

        // Unknown provider, still embeddable sometimes
        return ['provider' => 'embed', 'url' => $url];
    }

    /**
     * Enforce Fashion PK visual layout rules based on token index.
     * Rules:
     * - [VISUAL_0] -> After Paragraph 1
     * - [VISUAL_1] -> After Paragraph 2
     * - [VISUAL_2] -> After Paragraph 2 (Optional)
     * - [VISUAL_3+] -> Interleaved with H3 dress blocks
     * - Leftovers -> Dump at end
     */
    private function enforce_fashion_pk_visual_layout(array $elements, bool $is_first_section): array
    {
        $max_images = 15;

        // @MODIFIED 2026-02-19 - Preserve token-anchored image positions for rewrite pipelines.
        // If images are already interleaved with text and carry visual indices, do not reshuffle.
        $img_positions = [];
        $tokenized = 0;
        foreach ($elements as $i => $el) {
            if (($el['type'] ?? '') === 'image') {
                $img_positions[] = (int) $i;
                if (isset($el['visual_idx']) && $el['visual_idx'] !== null) {
                    $tokenized++;
                }
            }
        }
        $interleaved = false;
        for ($j = 0; $j < (count($img_positions) - 1); $j++) {
            if (($img_positions[$j + 1] - $img_positions[$j]) > 1) {
                $interleaved = true;
                break;
            }
        }
        if ($tokenized >= 2 && $interleaved) {
            return $elements;
        }

        // Extract images and keep original order index for stable sorting
        $images = [];
        $stream = [];
        $order = 0;

        foreach ($elements as $el) {
            if (($el['type'] ?? '') === 'image') {
                $el['_order'] = $order++;
                $images[] = $el;
            } else {
                $stream[] = $el;
            }
        }

        if (empty($images)) return $stream;

        if (count($images) > $max_images) {
            $images = array_slice($images, 0, $max_images);
        }

        // Stable sort by visual_idx if present, else by original order
        // This ensures semantic matching (visual_0 -> para 1) if indices are present.
        usort($images, function ($a, $b) {
            $ai = $a['visual_idx'] ?? null;
            $bi = $b['visual_idx'] ?? null;

            if ($ai === null && $bi === null) return ($a['_order'] <=> $b['_order']);
            if ($ai === null) return 1;
            if ($bi === null) return -1;
            if ((int)$ai === (int)$bi) return ($a['_order'] <=> $b['_order']);
            return ((int)$ai <=> (int)$bi);
        });

        // Partition:
        // - intro pool: visual_idx 0..2
        // - dress pool: visual_idx >= 3
        // - unknown pool: visual_idx missing (fallback)
        $intro = [];
        $dress = [];
        $unknown = [];

        foreach ($images as $img) {
            $vidx = $img['visual_idx'] ?? null;
            $unset_img = $img;
            unset($unset_img['_order']); // Clean up temp key

            if ($vidx === null) {
                $unknown[] = $unset_img;
            } elseif ((int)$vidx <= 2) {
                $intro[] = $unset_img;
            } else {
                $dress[] = $unset_img;
            }
        }

        // Count H3 slots (each H3 expects 1 image after its first paragraph)
        $h3_count = 0;
        foreach ($stream as $el) {
            if (($el['type'] ?? '') === 'heading' && (int)($el['level'] ?? 0) === 3) {
                $h3_count++;
            }
        }

        // Para1: exactly 1 image after first paragraph (first section only)
        // Para2: 1–2 images after second paragraph (first section only),
        // BUT do not steal from dress pool (>=3). Only use intro/unknown.
        $p1_imgs = [];
        $p2_imgs = [];

        if ($is_first_section) {
            // Prefer intro[0] for para1, else unknown
            if (!empty($intro)) {
                $p1_imgs[] = array_shift($intro);
            } elseif (!empty($unknown)) {
                $p1_imgs[] = array_shift($unknown);
            }

            // Para2: up to 2 from remaining intro first, then unknown
            // Also ensure we don't starve H3: keep at least 1 per H3 from (dress + unknown) if possible
            $available_for_h3 = count($dress) + count($unknown);
            $h3_safe = min($h3_count, $available_for_h3);

            // We allow para2 images only if we can still satisfy H3s reasonably.
            // Para2 images come from intro/unknown ONLY, so this primarily prevents draining unknown pool.
            $room_for_para2 = max(0, (count($dress) + count($unknown) - $h3_safe));

            // Always try to place at least 1 after para2 if possible from intro; otherwise use unknown only if room exists.
            if (!empty($intro)) {
                $p2_imgs[] = array_shift($intro);
                if (!empty($intro)) {
                    $p2_imgs[] = array_shift($intro);
                } elseif ($room_for_para2 > 0 && !empty($unknown)) {
                    $p2_imgs[] = array_shift($unknown);
                }
            } elseif ($room_for_para2 > 0 && !empty($unknown)) {
                $p2_imgs[] = array_shift($unknown);
                if ($room_for_para2 > 1 && !empty($unknown)) {
                    $p2_imgs[] = array_shift($unknown);
                }
            }
        }

        // Dress images for H3 blocks: prefer dress pool, fallback unknown.
        $dress_queue = array_values(array_merge($dress, $unknown));

        // @MODIFIED 2026-02-16 - Phase 2: reorder dress queue by matching H3 blocks to best images.
        if (count($dress_queue) > 1) {
            $dress_queue = MediaMatcher::reorder_fashion_dress_queue($stream, $dress_queue);
        }

        // Find first and second paragraph indexes in stream
        $first_para_idx = null;
        $second_para_idx = null;
        for ($i = 0; $i < count($stream); $i++) {
            if (($stream[$i]['type'] ?? '') === 'paragraph') {
                if ($first_para_idx === null) $first_para_idx = $i;
                elseif ($second_para_idx === null) {
                    $second_para_idx = $i;
                    break;
                }
            }
        }

        // Rebuild with injections
        $out = [];
        $await_h3_para = false;
        $dq = 0;

        for ($i = 0; $i < count($stream); $i++) {
            $el = $stream[$i];

            if (($el['type'] ?? '') === 'heading') {
                $await_h3_para = ((int)($el['level'] ?? 0) === 3);
            }

            $out[] = $el;

            if ($is_first_section && $first_para_idx !== null && $i === $first_para_idx) {
                foreach ($p1_imgs as $img) $out[] = $img;
            }

            if ($is_first_section && $second_para_idx !== null && $i === $second_para_idx) {
                foreach ($p2_imgs as $img) $out[] = $img;
            }

            if ($await_h3_para && (($el['type'] ?? '') === 'paragraph')) {
                if (isset($dress_queue[$dq])) {
                    $out[] = $dress_queue[$dq];
                    $dq++;
                }
                $await_h3_para = false;
            }
        }

        // Dump leftovers at end (your requirement)
        for ($k = $dq; $k < count($dress_queue); $k++) {
            $out[] = $dress_queue[$k];
        }

        foreach ($elements as $el) {
            if (($el['type'] ?? '') === 'image' && isset($el['_order'])) {
                // Should not happen, but ensure cleanup if logic above fails
                unset($el['_order']);
            }
        }

        return $out;
    }

    private function parse_body_to_elements(string $body_html): array
    {
        if (empty($body_html)) {
            return [];
        }

        // @MODIFIED 2026-02-13 - Robust block detection to prevent Gutenberg block recovery.
        // Expanded to include strong|em|a to ensure mixed tags trigger HTML element parsing.
        $has_block_tags = (bool) preg_match('/<(p|ul|ol|table|blockquote|img|iframe|h[1-6]|figure|figcaption|strong|em|a)\b/i', $body_html);

        if (!$has_block_tags) {
            // Normalize <br><br> into paragraph breaks for plain-text style output.
            $normalized = preg_replace('/<br\s*\/?>\s*<br\s*\/?>/i', "\n\n", $body_html);
            $normalized = preg_replace('/<br\s*\/?>/i', "\n", $normalized);

            $paras = preg_split("/\n\s*\n/", $normalized);
            $elements = [];
            foreach ($paras as $para) {
                $trimmed = trim($para);
                if ($trimmed !== '') {
                    $elements[] = [
                        'type'    => 'paragraph',
                        'content' => $trimmed,
                    ];
                }
            }
            if (!empty($elements)) {
                return $elements;
            }
        }

        $elements = [];

        // Use DOMDocument for robust HTML parsing
        $dom = new \DOMDocument('1.0', 'UTF-8');

        // Suppress warnings for malformed HTML
        \libxml_use_internal_errors(true);

        // Polyfill constants to prevent runtime errors in some envs
        if (!defined('LIBXML_HTML_NOIMPLIED')) define('LIBXML_HTML_NOIMPLIED', 8192);
        if (!defined('LIBXML_HTML_NODEFDTD')) define('LIBXML_HTML_NODEFDTD', 4);

        // Wrap in container and load
        $wrapped = '<div id="dit-ts-root">' . $body_html . '</div>';
        $dom->loadHTML(
            '<?xml encoding="UTF-8">' . $wrapped,
            \LIBXML_HTML_NOIMPLIED | \LIBXML_HTML_NODEFDTD
        );

        \libxml_clear_errors();

        // Find root container
        $root = $dom->getElementById('dit-ts-root');
        if (!$root) {
            // Fallback to legacy regex method
            return $this->normalize_elements($this->parse_body_to_elements_legacy($body_html));
        }

        // @MODIFIED 2026-02-07 - Implemented text node buffering to prevent sentence fragmentation
        $buffer = '';
        $flush_buffer = function () use (&$elements, &$buffer) {
            $content = trim($buffer);
            if ($content !== '') {
                $elements[] = ['type' => 'paragraph', 'content' => $content];
            }
            $buffer = '';
        };

        // Block-level tags that force a paragraph break (flush buffer)
        $block_tags = ['p', 'div', 'ul', 'ol', 'table', 'blockquote', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'figure', 'iframe', 'hr', 'pre', 'address', 'img'];

        // Iterate child nodes
        foreach ($root->childNodes as $node) {
            if ($node->nodeType !== XML_ELEMENT_NODE) {
                // Buffer text nodes (escaped)
                if ($node->nodeType === XML_TEXT_NODE) {
                    $text = $node->textContent;

                    // Special case: If buffer is empty and text is a standalone URL -> block embed
                    if (trim($buffer) === '') {
                        $embed = $this->detect_oembed_url(trim($text));
                        if ($embed) {
                            $elements[] = [
                                'type'     => 'embed',
                                'provider' => $embed['provider'],
                                'url'      => $embed['url'],
                                'html'     => $embed['url'], // URL-only wrapper preferred
                            ];
                            continue;
                        }
                    }

                    // Buffer escaped text content
                    $buffer .= esc_html($text);
                }
                continue;
            }

            $tag = strtolower($node->nodeName);

            // Flush buffer if we hit a block element
            if (in_array($tag, $block_tags, true)) {
                $flush_buffer();
            }

            if ($tag === 'ul' || $tag === 'ol') {
                // List element
                $elements[] = [
                    'type'      => 'list',
                    'list_type' => $tag,
                    'html'      => $this->get_outer_html($node, $dom),
                ];
            } elseif ($tag === 'img') {
                // Image element
                $src = $node->getAttribute('src');
                $alt = $node->getAttribute('alt');
                $attribution = $node->getAttribute('title');
                $vidx = $node->getAttribute('data-dit-visual');

                if (!empty($src)) {
                    $elements[] = [
                        'type'        => 'image',
                        'src'         => $src,
                        'alt'         => $alt,
                        'attribution' => $attribution,
                        'visual_idx'  => ($vidx !== '' && is_numeric($vidx)) ? (int) $vidx : null,
                    ];
                }
            } elseif ($tag === 'p') {
                // Paragraph element
                $inner = $this->get_inner_html($node, $dom);
                $inner = $this->sanitize_paragraph_content($inner);

                // @FIXED 2026-02-06: If a paragraph contains ONLY an <img>, render as a native core/image block.
                // This happens frequently when media passthrough or legacy HTML wraps images in <p> tags.
                if (preg_match('~^\s*(?:<a[^>]*>\s*)?<img[^>]*src=["\']([^"\']+)["\'][^>]*>(?:\s*</a>)?\s*$~i', trim($inner), $im)) {
                    $src = $im[1];
                    $alt_attr = '';
                    $visual_idx = null;
                    if (preg_match('~alt=["\']([^"\']*)["\']]~i', $inner, $am)) {
                        $alt_attr = html_entity_decode($am[1], ENT_QUOTES | ENT_HTML5, 'UTF-8');
                    }
                    if (preg_match('~data-dit-visual=["\'](\d+)["\']~i', $inner, $vm)) {
                        $visual_idx = (int) $vm[1];
                    }
                    $elements[] = [
                        'type' => 'image',
                        'src'  => $src,
                        'alt'  => $alt_attr,
                        'visual_idx' => $visual_idx,
                    ];
                    continue;
                }

                if (!empty($inner)) {
                    // @MODIFIED 2026-02-13 - Split by images first (higher priority than embeds)
                    // This ensures images injected by Media_Passthrough are elevated to native blocks.
                    $image_segments = $this->split_content_by_images($inner);

                    if (count($image_segments) > 1 || (count($image_segments) === 1 && $image_segments[0]['type'] === 'image')) {
                        foreach ($image_segments as $seg) {
                            if ($seg['type'] === 'image') {
                                $elements[] = [
                                    'type' => 'image',
                                    'src'  => $seg['src'] ?? '',
                                    'alt'  => $seg['alt'] ?? '',
                                ];
                            } elseif ($seg['type'] === 'text') {
                                $text_content = trim($seg['content'] ?? '');
                                if ($text_content !== '') {
                                    // Check if text contains embeds
                                    $embed_segments = $this->split_content_by_embeds($text_content);
                                    if (!empty($embed_segments)) {
                                        foreach ($embed_segments as $embed_seg) {
                                            if ($embed_seg['type'] === 'embed') {
                                                $elements[] = [
                                                    'type'     => 'embed',
                                                    'provider' => $embed_seg['provider'] ?? 'embed',
                                                    'url'      => $embed_seg['url'] ?? '',
                                                    'html'     => $embed_seg['url'] ?? '',
                                                ];
                                            } elseif ($embed_seg['type'] === 'text') {
                                                $final_text = trim($embed_seg['content'] ?? '');
                                                if ($final_text !== '') {
                                                    $elements[] = [
                                                        'type'    => 'paragraph',
                                                        'content' => $final_text,
                                                    ];
                                                }
                                            }
                                        }
                                    } else {
                                        $elements[] = [
                                            'type'    => 'paragraph',
                                            'content' => $text_content,
                                        ];
                                    }
                                }
                            }
                        }
                        continue;
                    }

                    // @MODIFIED 2026-02-06 - Convert [embed]URL[/embed] shortcodes preserving inline positions.
                    $segments = $this->split_content_by_embeds($inner);

                    if (!empty($segments)) {
                        foreach ($segments as $seg) {
                            if ($seg['type'] === 'embed') {
                                $elements[] = [
                                    'type'     => 'embed',
                                    'provider' => $seg['provider'] ?? 'embed',
                                    'url'      => $seg['url'] ?? '',
                                    'html'     => $seg['url'] ?? '',
                                ];
                            } elseif ($seg['type'] === 'text') {
                                $text_content = trim($seg['content'] ?? '');
                                if ($text_content !== '') {
                                    // Check if text is actually an embed URL without shortcode
                                    $embed = $this->detect_oembed_url($text_content);
                                    if ($embed) {
                                        $elements[] = [
                                            'type'     => 'embed',
                                            'provider' => $embed['provider'],
                                            'url'      => $embed['url'],
                                            'html'     => $embed['url'],
                                        ];
                                    } else {
                                        $elements[] = [
                                            'type'    => 'paragraph',
                                            'content' => $text_content,
                                        ];
                                    }
                                }
                            }
                        }
                        continue;
                    }

                    $embed = $this->detect_oembed_url($inner);
                    if ($embed) {
                        $elements[] = [
                            'type'     => 'embed',
                            'provider' => $embed['provider'],
                            'url'      => $embed['url'],
                            'html'     => $embed['url'],
                        ];
                        continue;
                    }
                    // @FIX 2026-01-27 - Check for block elements (table) inside paragraph
                    if (strpos($inner, '<table') !== false) {
                        $elements[] = [
                            'type' => 'table',
                            'html' => $inner,
                        ];
                    } else {
                        $elements[] = [
                            'type'    => 'paragraph',
                            'content' => $inner,
                        ];
                    }
                }
            } elseif ($tag === 'iframe') {
                // Iframe (YouTube etc)
                $src = $node->getAttribute('src');
                if (!empty($src)) {
                    $det = $this->detect_oembed_url($src);
                    $elements[] = [
                        'type'     => 'embed',
                        'provider' => $det['provider'] ?? 'embed',
                        'url'      => $det['url'] ?? $src,
                        'html'     => $det['url'] ?? $src, // keep URL-only for oEmbed
                    ];
                }
            } elseif ($tag === 'blockquote' && strpos($node->getAttribute('class'), 'tiktok-embed') !== false) {
                // TikTok Embed - prefer URL for WP oEmbed
                $cite = $node->getAttribute('cite');
                $url = $cite;

                if (empty($url)) {
                    $links = $node->getElementsByTagName('a');
                    if ($links->length > 0) {
                        $url = $links->item($links->length - 1)->getAttribute('href');
                    }
                }

                $elements[] = [
                    'type' => 'embed',
                    'provider' => 'tiktok',
                    'url' => $url,
                    'html' => $this->get_outer_html($node, $dom),
                ];
            } elseif ($tag === 'blockquote' && (strpos($node->getAttribute('class'), 'fb-video') !== false || strpos($node->getAttribute('class'), 'fb-post') !== false)) {
                // Facebook Embed - preserve URL for WP oEmbed
                $url = '';

                // Facebook uses data-href often
                $data_href = $node->getAttribute('data-href');
                if (!empty($data_href)) {
                    $url = $data_href;
                }

                if (empty($url)) {
                    $cite = $node->getAttribute('cite');
                    if (!empty($cite)) $url = $cite;
                }

                if (empty($url)) {
                    $links = $node->getElementsByTagName('a');
                    if ($links->length > 0) {
                        $url = $links->item($links->length - 1)->getAttribute('href');
                    }
                }

                $elements[] = [
                    'type' => 'embed',
                    'provider' => 'facebook',
                    'url' => $url,
                    'html' => $this->get_outer_html($node, $dom),
                ];
            } elseif ($tag === 'blockquote' && strpos($node->getAttribute('class'), 'twitter-tweet') !== false) {
                // Twitter Embed
                // Extract link from inner 'a' tag if possible, or just use outer HTML
                $links = $node->getElementsByTagName('a');
                $url = '';
                if ($links->length > 0) {
                    $url = $links->item($links->length - 1)->getAttribute('href'); // Usually last link is date permalink
                }

                $elements[] = [
                    'type' => 'embed',
                    'provider' => 'twitter',
                    'url' => $url,
                    'html' => $this->get_outer_html($node, $dom),
                ];
            } elseif ($tag === 'blockquote' && strpos($node->getAttribute('class'), 'instagram-media') !== false) {
                // Instagram Embed
                $perm = $node->getAttribute('data-instgrm-permalink');
                // @MODIFIED 2026-02-22 - Strip UTM tracking that corrupts embed URLs
                $perm = preg_replace('/[?&](utm_source|utm_campaign|utm_medium)=[^&]*/i', '', $perm);
                $perm = rtrim($perm, '?&');
                $elements[] = [
                    'type' => 'embed',
                    'provider' => 'instagram',
                    'url' => $perm,
                    'html' => $this->get_outer_html($node, $dom),
                ];
            } elseif ($tag === 'blockquote') {
                // Blockquote - wrap as paragraph with styling
                $inner = $this->get_inner_html($node, $dom);
                if (!empty(trim($inner))) {
                    $elements[] = [
                        'type'    => 'blockquote',
                        'content' => $inner,
                    ];
                }
            } elseif ($tag === 'table') {
                // Table element
                $elements[] = [
                    'type' => 'table',
                    'html' => $this->get_outer_html($node, $dom),
                ];
            } elseif (in_array($tag, ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'])) {
                // Subheading within section
                $elements[] = [
                    'type'  => 'heading',
                    'level' => (int) substr($tag, 1),
                    'text'  => trim($node->textContent),
                ];

            } elseif (
                $tag === 'div' && (
                    strpos($node->getAttribute('class'), 'fb-video') !== false ||
                    strpos($node->getAttribute('class'), 'fb-post') !== false
                )
            ) {
                // @MODIFIED 2026-05-06 - Facebook SDK <div class="fb-video" data-href="URL"> embed.
                // Facebook uses <div> (not <blockquote>) for its JavaScript SDK embeds.
                // Extract URL from data-href, then rebuild as a proper wp:embed block.
                $url = $node->getAttribute('data-href') ?: '';
                if (empty($url)) {
                    $links = $node->getElementsByTagName('a');
                    if ($links->length > 0) {
                        $url = $links->item($links->length - 1)->getAttribute('href');
                    }
                }
                // Strip UTM tracking (same guard as blockquote Facebook handler above).
                $url = preg_replace('/[?&](utm_source|utm_campaign|utm_medium)=[^&]*/i', '', (string) $url);
                $url = rtrim($url, '?&');
                if (!empty($url)) {
                    $elements[] = [
                        'type'     => 'embed',
                        'provider' => 'facebook',
                        'url'      => $url,
                        'html'     => $this->get_outer_html($node, $dom),
                    ];
                }

            } elseif (
                $tag === 'figure' &&
                strpos($node->getAttribute('class'), 'wp-block-embed') !== false
            ) {
                // @MODIFIED 2026-05-06 - Source post already contains a Gutenberg wp:embed block
                // (e.g. the idea draft was itself a Gutenberg post). Re-extract the URL from the
                // inner wp-block-embed__wrapper div and rebuild as a fresh embed element so that
                // provider detection and all block attrs are generated correctly for the destination post.
                $embed_url = '';
                $divs = $node->getElementsByTagName('div');
                for ($di = 0; $di < $divs->length; $di++) {
                    $div_item = $divs->item($di);
                    if (strpos($div_item->getAttribute('class'), 'wp-block-embed__wrapper') !== false) {
                        $embed_url = trim($div_item->textContent);
                        break;
                    }
                }
                // Only convert if the wrapper contains a plain URL (not pre-fetched oEmbed HTML).
                if ($embed_url !== '' && filter_var($embed_url, FILTER_VALIDATE_URL)) {
                    $det = $this->detect_oembed_url($embed_url);
                    $elements[] = [
                        'type'     => 'embed',
                        'provider' => $det['provider'] ?? 'embed',
                        'url'      => $det['url'] ?? $embed_url,
                        'html'     => $det['url'] ?? $embed_url,
                    ];
                }
                // If the wrapper holds pre-fetched oEmbed HTML (not a plain URL), fall through
                // to the buffer so the raw figure HTML is preserved as-is.

            } else {
                // Inline elements (strong, em, br, span, unknown) -> Buffer outer HTML
                // This prevents fragmentation of sentences containing HTML tags
                $buffer .= $this->get_outer_html($node, $dom);
            }
        }
        $flush_buffer();

        // @FIXED 2026-02-06 - Normalize paragraph fragmentation from AI output.
        // Goals:
        // - Merge punctuation-only paragraphs into the previous paragraph.
        // - Merge “list item” single-line paragraphs into the previous paragraph when they are clearly
        //   continuations (common in showbiz name/title runs).
        // - Avoid producing dozens of one-liner <p> blocks that degrade readability.
        return $this->normalize_elements($elements);
    }
    /**
     * Normalize parsed elements to reduce paragraph fragmentation.
     *
     * This runs AFTER DOM parsing, before block serialization.
     *
     * @param array $elements
     * @return array
     */
    private function normalize_elements(array $elements): array
    {
        if (empty($elements)) {
            return $elements;
        }

        $out = [];
        $n = count($elements);

        for ($i = 0; $i < $n; $i++) {
            $el = $elements[$i];

            if (($el['type'] ?? '') !== 'paragraph') {
                $out[] = $el;
                continue;
            }

            $html = trim((string) ($el['content'] ?? ''));
            if ($html === '') {
                continue;
            }

            $text = trim($this->strip_inline_tags($html));

            // 1) Punctuation-only paragraphs: append to previous paragraph.
            if ($this->is_punctuation_only($text) && !empty($out)) {
                $last_idx = count($out) - 1;
                if (($out[$last_idx]['type'] ?? '') === 'paragraph') {
                    $out[$last_idx]['content'] = rtrim((string) $out[$last_idx]['content']) . $text;
                    continue;
                }
            }

            // 2) Paragraph begins with punctuation and previous is a paragraph: glue it.
            if (!empty($out) && ($out[count($out) - 1]['type'] ?? '') === 'paragraph') {
                $lead = mb_substr($text, 0, 1);
                if (in_array($lead, ['.', ',', ':', ';', '!', '?', '”', '"', ')'], true)) {
                    $last_idx = count($out) - 1;
                    $out[$last_idx]['content'] = rtrim((string) $out[$last_idx]['content']) . ' ' . ltrim($html);
                    continue;
                }
            }

            // 3) “like / including / such as” runs: merge subsequent short item-paragraphs into one.
            if (!empty($out) && ($out[count($out) - 1]['type'] ?? '') === 'paragraph') {
                $prev_idx = count($out) - 1;
                $prev_html = (string) ($out[$prev_idx]['content'] ?? '');
                $prev_text = trim($this->strip_inline_tags($prev_html));

                if ($this->ends_with_list_intro($prev_text)) {
                    $items = [];
                    $j = $i;

                    while ($j < $n) {
                        $cand = $elements[$j];
                        if (($cand['type'] ?? '') !== 'paragraph') {
                            break;
                        }
                        $cand_html = trim((string) ($cand['content'] ?? ''));
                        if ($cand_html === '') {
                            $j++;
                            continue;
                        }

                        $cand_text = trim($this->strip_inline_tags($cand_html));

                        if ($this->is_punctuation_only($cand_text)) {
                            $j++;
                            continue;
                        }

                        if (!$this->is_short_list_item_paragraph($cand_html, $cand_text)) {
                            break;
                        }

                        $items[] = $cand_html;
                        $j++;

                        if (count($items) >= 8) {
                            break;
                        }
                    }

                    if (count($items) >= 2) {
                        $joined = implode(', ', $items);
                        $out[$prev_idx]['content'] = rtrim($prev_html) . ' ' . $joined;
                        $i = $j - 1;
                        continue;
                    }
                }
            }

            $out[] = $el;
        }

        return $out;
    }

    /**
     * Strip inline tags but keep their text for heuristics.
     */
    private function strip_inline_tags(string $html): string
    {
        return trim((string) wp_strip_all_tags($html));
    }

    private function is_punctuation_only(string $text): bool
    {
        return (bool) preg_match('/^[\s\"“”\'\.,:;!?\-–—\(\)\[\]]+$/u', $text);
    }

    private function ends_with_list_intro(string $text): bool
    {
        // Covers: "like", "including", "such as" (with optional punctuation)
        return (bool) preg_match('/\b(like|including|such as)\s*[:\-—]?\s*$/i', $text);
    }

    private function is_short_list_item_paragraph(string $html, string $text): bool
    {
        if (stripos($html, '<a ') !== false) {
            return false;
        }

        $len = mb_strlen($text);
        if ($len < 1 || $len > 60) {
            return false;
        }

        if (preg_match('/[\.!\?]$/u', $text)) {
            return false;
        }

        if (preg_match('/\b(and|but|because|while|however)\b/i', $text)) {
            return false;
        }

        return true;
    }

    /**
     * Split content by <img> tags, preserving inline positioning.
     * Ensures images nested within paragraphs are elevated to standalone core/image blocks.
     * @MODIFIED 2026-02-13 - New method to handle Media_Passthrough tag injection
     *
     * @param string $html Inner HTML potentially containing <img> tags
     * @return array Array of segments: [{type: 'text'|'image', content?: string, src?: string, alt?: string}, ...]
     */
    private function split_content_by_images(string $html): array
    {
        // Quick exit if no images present
        if (stripos($html, '<img') === false) {
            $trimmed = trim($html);
            return $trimmed === '' ? [] : [['type' => 'text', 'content' => $html]];
        }

        $segments = [];
        $working = (string) $html;

        // Pattern: <img ...src="..." ... />
        // Handles both self-closing and non-self-closing variants
        $pattern = '/<img[^>]+src=["\']([^"\']+)["\'][^>]*\/?>/i';

        $last_pos = 0;

        while (preg_match($pattern, $working, $match, PREG_OFFSET_CAPTURE, $last_pos)) {
            $full_match = $match[0][0];    // Full <img> tag
            $match_pos = $match[0][1];     // Position in string
            $src = $match[1][0] ?? '';     // Captured src URL

            // Text BEFORE this image
            if ($match_pos > $last_pos) {
                $text_before = substr($working, $last_pos, $match_pos - $last_pos);
                $text_before = trim($text_before);
                // Skip whitespace-only segments
                if ($text_before !== '' && !preg_match('/^[\s\r\n]+$/', $text_before)) {
                    $segments[] = ['type' => 'text', 'content' => $text_before];
                }
            }

            // Extract alt attribute if present
            $alt = '';
            if (preg_match('/alt=["\']([^"\']*)["\']/', $full_match, $alt_match)) {
                $alt = html_entity_decode($alt_match[1], ENT_QUOTES | ENT_HTML5, 'UTF-8');
            }

            $vidx = null;
            if (preg_match('/data-dit-visual=["\'](\d+)["\']/', $full_match, $vm)) {
                $vidx = (int) $vm[1];
            }

            $hint = '';
            if (preg_match('/data-dit-hint=["\']([^"\']*)["\']/', $full_match, $hm)) {
                $hint = html_entity_decode($hm[1], ENT_QUOTES | ENT_HTML5, 'UTF-8');
            }

            if ($src !== '') {
                $segments[] = [
                    'type'       => 'image',
                    'src'        => $src,
                    'alt'        => $alt,
                    'visual_idx' => $vidx,
                    'hint'       => $hint, // @MODIFIED 2026-02-16 - Phase 2 hint
                ];
            }

            // Move past this match
            $last_pos = $match_pos + strlen($full_match);
        }

        // Text AFTER all images
        if ($last_pos < strlen($working)) {
            $text_after = substr($working, $last_pos);
            $text_after_trimmed = trim($text_after);

            // Only include if it's substantial
            if ($text_after_trimmed !== '' && !preg_match('/^[\s\r\n\.,\!\?]+$/', $text_after_trimmed)) {
                $segments[] = ['type' => 'text', 'content' => $text_after_trimmed];
            }
        }

        return $segments;
    }

    /**
     * Split content by embed shortcodes, preserving inline positioning.
     * Handles 50+ edge cases including: multiple embeds, text before/after, malformed shortcodes,
     * URL encoding, whitespace variations, mixed [embed] and [video], etc.
     *
     * @MODIFIED 2026-02-06 - Rewritten to preserve embed positioning in content flow
     *
     * @param string $html Inner HTML potentially containing [embed] or [video] shortcodes
     * @return array Array of segments: [{type: 'text'|'embed', content?: string, url?: string, provider?: string}, ...]
     */
    private function split_content_by_embeds(string $html): array
    {
        // Quick exit if no shortcodes present
        if (stripos($html, '[embed]') === false && stripos($html, '[video]') === false) {
            $trimmed = trim($html);
            return $trimmed === '' ? [] : [['type' => 'text', 'content' => $html]];
        }

        $segments = [];
        $working = (string) $html;

        // Pattern: [embed]URL[/embed] or [video]URL[/video]
        // Handles:
        // - Optional whitespace around URL
        // - URL with query params, fragments, encoded chars
        // - Case-insensitive tags
        // - Mismatched closing tags (embed/video)
        $pattern = '/\[(embed|video)\]\s*(https?:\/\/[^\s\[\]]+?)\s*\[\/(?:embed|video)\]/i';

        $last_pos = 0;

        while (preg_match($pattern, $working, $match, PREG_OFFSET_CAPTURE, $last_pos)) {
            $full_match = $match[0][0];    // Full shortcode string
            $match_pos = $match[0][1];     // Position in string
            $url_raw = $match[2][0] ?? ''; // Captured URL

            // Text BEFORE this embed
            if ($match_pos > $last_pos) {
                $text_before = substr($working, $last_pos, $match_pos - $last_pos);
                $text_before = trim($text_before);
                // Skip whitespace-only or newline-only segments
                if ($text_before !== '' && !preg_match('/^[\s\r\n]+$/', $text_before)) {
                    $segments[] = ['type' => 'text', 'content' => $text_before];
                }
            }

            // Clean and decode the URL
            // Handles:
            // - HTML entities (&amp; -> &)
            // - JSON escape sequences (\u0026 -> &) as LITERAL strings (not PHP escapes)
            // - Trailing punctuation
            // - URL fragments and query params
            $url = \DIT\TrendStudio\Security\Sanitizer::decode_ai_string($url_raw); // Remove backslashes from JSON escaping and handle entities/\u

            if ($url !== '') {
                $det = $this->detect_oembed_url($url);
                $segments[] = [
                    'type' => 'embed',
                    'provider' => $det['provider'] ?? 'embed',
                    'url' => $det['url'] ?? $url,
                ];
            }

            // Move past this match
            $last_pos = $match_pos + strlen($full_match);
        }

        // Text AFTER all embeds (excluding trailing whitespace-only text like ".")
        if ($last_pos < strlen($working)) {
            $text_after = substr($working, $last_pos);
            $text_after_trimmed = trim($text_after);

            // Only include if it's substantial (not just punctuation or whitespace)
            if ($text_after_trimmed !== '' && !preg_match('/^[\s\r\n\.\,\!\?]+$/', $text_after_trimmed)) {
                $segments[] = ['type' => 'text', 'content' => $text_after_trimmed];
            }
        }

        return $segments;
    }

    /**
     * Get outer HTML of a DOM node
     *
     * @param \DOMNode     $node Node
     * @param \DOMDocument $dom  Document
     * @return string Outer HTML
     */
    private function get_outer_html(\DOMNode $node, \DOMDocument $dom): string
    {
        return $dom->saveHTML($node) ?: '';
    }

    /**
     * Get inner HTML of a DOM node
     *
     * @param \DOMNode     $node Node
     * @param \DOMDocument $dom  Document
     * @return string Inner HTML
     */
    private function get_inner_html(\DOMNode $node, \DOMDocument $dom): string
    {
        $inner = '';
        foreach ($node->childNodes as $child) {
            $inner .= $dom->saveHTML($child);
        }
        return $inner;
    }

    /**
     * Legacy regex-based parser (fallback)
     *
     * @param string $body_html HTML body content
     * @return array Array of elements
     */
    private function parse_body_to_elements_legacy(string $body_html): array
    {
        $elements = [];

        // @MODIFIED 2026-01-27 - Added table support to regex
        $pattern = '/(<p[^>]*>.*?<\/p>|<ul[^>]*>.*?<\/ul>|<ol[^>]*>.*?<\/ol>|<table[^>]*>.*?<\/table>)/is';

        if (preg_match_all($pattern, $body_html, $matches)) {
            foreach ($matches[1] as $block) {
                if (preg_match('/^<(ul|ol)[^>]*>(.*)<\/\1>$/is', $block, $list_match)) {
                    $elements[] = [
                        'type'      => 'list',
                        'list_type' => $list_match[1],
                        'html'      => $block,
                    ];
                } elseif (preg_match('/^<table[^>]*>(.*)<\/table>$/is', $block, $table_match)) {
                    $elements[] = [
                        'type' => 'table',
                        'html' => $block,
                    ];
                } elseif (preg_match('/^<p[^>]*>(.*)<\/p>$/is', $block, $p_match)) {
                    $inner = $this->sanitize_paragraph_content($p_match[1]);
                    // Check if table inside p (legacy edge case)
                    if (strpos($inner, '<table') !== false) {
                        $elements[] = [
                            'type' => 'table',
                            'html' => $inner,
                        ];
                    } elseif (!empty($inner)) {
                        $elements[] = [
                            'type'    => 'paragraph',
                            'content' => $inner,
                        ];
                    }
                }
            }
        }

        if (empty($elements)) {
            // @MODIFIED 2026-02-16: Defensive fallback for raw text (AI sometimes skips tags)
            // Split by double newlines to treat as paragraphs
            $chunks = preg_split('/(\r\n|\n|\r){2,}/', trim($body_html));

            foreach ($chunks as $chunk) {
                $inner = $this->sanitize_paragraph_content($chunk);
                if (!empty($inner)) {
                    $elements[] = [
                        'type'    => 'paragraph',
                        'content' => $inner,
                    ];
                }
            }
        }

        return $this->normalize_elements($elements);
    }

    /**
     * Auto-inject user images into article based on alt-text/context matching
     * @MODIFIED 2025-12-18 - Phase 4: Auto media injection
     *
     * @param array $article   Article data with sections
     * @param array $media_ids Array of WP attachment IDs
     * @return array Article with injected images
     */
    public function auto_inject_images(array $article, array $media_ids): array
    {
        if (empty($media_ids) || empty($article['sections'])) {
            return $article;
        }

        // Build media context map
        $media_items = [];
        foreach ($media_ids as $media_id) {
            $alt = get_post_meta($media_id, '_wp_attachment_image_alt', true);
            $title = get_the_title($media_id);
            $description = get_post($media_id)->post_content ?? '';
            $url = wp_get_attachment_url($media_id);

            if (!$url) {
                continue;
            }

            $media_items[] = [
                'id'          => $media_id,
                'url'         => $url,
                'alt'         => $alt ?: $title,
                'title'       => $title,
                'description' => $description,
                'keywords'    => $this->extract_keywords_from_text($alt . ' ' . $title . ' ' . $description),
                'used'        => false,
            ];
        }

        // Match media to sections based on content similarity
        foreach ($article['sections'] as $index => &$section) {
            if (!empty($section['selected_image'])) {
                continue; // Already has image
            }

            $section_text = ($section['heading'] ?? '') . ' ' . strip_tags($section['body_html'] ?? '');
            $section_keywords = $this->extract_keywords_from_text($section_text);

            $best_match = null;
            $best_score = 0;

            foreach ($media_items as $key => $media) {
                if ($media['used']) {
                    continue;
                }

                $score = $this->calculate_keyword_overlap($section_keywords, $media['keywords']);

                if ($score > $best_score && $score >= 0.15) { // 15% keyword overlap threshold
                    $best_score = $score;
                    $best_match = $key;
                }
            }

            if ($best_match !== null) {
                $media = $media_items[$best_match];
                $section['selected_image'] = [
                    'id'          => $media['id'],
                    'full'        => $media['url'],
                    'alt'         => $media['alt'],
                    'attribution' => 'User uploaded',
                ];
                $media_items[$best_match]['used'] = true;
            }
        }

        return $article;
    }

    /**
     * Extract keywords from text for matching
     *
     * @param string $text Text to extract from
     * @return array Keywords
     */
    private function extract_keywords_from_text(string $text): array
    {
        $text = strtolower($text);
        preg_match_all('/\b[a-z]{4,}\b/', $text, $matches);
        $words = $matches[0] ?? [];

        // Remove common stop words
        $stop_words = ['this', 'that', 'with', 'from', 'they', 'have', 'been', 'were', 'will', 'would', 'could', 'should', 'about', 'which', 'their', 'there', 'when', 'what', 'where', 'some', 'more', 'also', 'only', 'into', 'than', 'then', 'being', 'after', 'before', 'just', 'over', 'such', 'make', 'made', 'like', 'very', 'each', 'most', 'other'];

        $keywords = array_filter($words, fn($w) => !in_array($w, $stop_words));

        return array_unique($keywords);
    }

    /**
     * Calculate keyword overlap between two sets
     *
     * @param array $keywords1 First set
     * @param array $keywords2 Second set
     * @return float Overlap ratio (0-1)
     */
    private function calculate_keyword_overlap(array $keywords1, array $keywords2): float
    {
        if (empty($keywords1) || empty($keywords2)) {
            return 0.0;
        }

        $intersection = count(array_intersect($keywords1, $keywords2));
        $smaller_set = min(count($keywords1), count($keywords2));

        return $smaller_set > 0 ? $intersection / $smaller_set : 0.0;
    }


    /**
     * Sanitize paragraph inner content
     * Removes has-drop-cap class (handled by block attr) and stray <p> wrappers
     * @MODIFIED 2025-12-14 - Belt-and-suspenders cleanup for AI output
     *
     * @param string $content Raw content
     * @return string Cleaned content
     */
    private function sanitize_paragraph_content(string $content): string
    {
        $content = trim($content);

        // Strip any has-drop-cap class (block attribute handles this)
        $content = preg_replace('/\s*class=["\']has-drop-cap["\']/', '', $content);
        $content = preg_replace('/\bhas-drop-cap\b/', '', $content);

        // Strip outer <p> tags if AI mistakenly nested them
        $content = preg_replace('/^<p[^>]*>(.*)<\/p>$/is', '$1', $content);

        return trim($content);
    }

    /**
     * Render structured blocks (Phase 3) to Gutenberg blocks.
     *
     * @MODIFIED 2026-02-16 - Phase 3 structured blocks support
     */
    private function section_structured_blocks_to_blocks(array $section, bool $is_first, $schema, array $article): array
    {
        $blocks_out = [];

        $heading = (string) ($section['heading'] ?? '');
        $internal_keys = ['verdict_box', 'comparison_table', 'buying_guide', 'sources', 'quick_answer', 'deep_dive', 'myth_busting', 'related_topics'];
        $is_internal_key_only = in_array(strtolower($heading), $internal_keys, true);
        $clean_heading = preg_replace('/^(?:' . implode('|', $internal_keys) . '):\s*/i', '', $heading);

        // Optional section heading
        if (!$is_first && !$is_internal_key_only && trim($clean_heading) !== '' && stripos($clean_heading, 'introduction') === false) {
            // @MODIFIED 2026-02-18 - Use wp_kses_post to support AI-generated formatting/entities
            $blocks_out[] = $this->serialize_block(
                'core/heading',
                ['level' => 2],
                '<h2>' . wp_kses_post($clean_heading) . '</h2>'
            );
        }

        $vmap = [];
        if (!empty($article['_source_visual_map']) && is_array($article['_source_visual_map'])) {
            $vmap = $article['_source_visual_map'];
        } elseif (!empty($article['source_visual_map']) && is_array($article['source_visual_map'])) {
            $vmap = $article['source_visual_map'];
        }

        foreach ((array) ($section['blocks'] ?? []) as $b) {
            if (!is_array($b)) {
                continue;
            }
            $type = (string) ($b['type'] ?? '');
            if ($type === '') {
                continue;
            }

            if ($type === 'p') {
                $html = (string) ($b['html'] ?? '');
                if (trim($html) === '') {
                    continue;
                }
                // assume html already contains <p>...</p> or raw text
                if (stripos($html, '<p') === false) {
                    $html = '<p>' . wp_kses_post($html) . '</p>';
                }
                $blocks_out[] = $this->serialize_block('core/paragraph', [], $html);
                continue;
            }

            if ($type === 'h') {
                $lvl = (int) ($b['level'] ?? 3);
                $lvl = max(2, min(4, $lvl));
                $text = (string) ($b['text'] ?? '');
                if (trim($text) === '') {
                    continue;
                }
                $blocks_out[] = $this->serialize_block(
                    'core/heading',
                    ['level' => $lvl],
                    '<h' . $lvl . '>' . wp_kses_post($text) . '</h' . $lvl . '>'
                );
                continue;
            }

            if ($type === 'embed_ref') {
                $url = (string) ($b['url'] ?? '');
                if ($url === '') {
                    continue;
                }

                // @MODIFIED 2026-02-21 - Use centralized formatter to prevent "Invalid Content"
                $blocks_out[] = $this->format_embed_block($url);
                continue;
            }

            if ($type === 'visual_ref') {
                $id = isset($b['id']) ? (int) $b['id'] : -1;
                if ($id < 0) {
                    continue;
                }
                $token = '[VISUAL_' . $id . ']';
                $meta = $vmap[$token] ?? null;
                if (!is_array($meta) || empty($meta['url'])) {
                    // If unresolved, skip safely (validator will catch in QualityGate)
                    continue;
                }
                $blocks_out[] = $this->render_visual_ref_block($meta, $id);
                continue;
            }

            if ($type === 'html') {
                $html = (string) ($b['html'] ?? '');
                if (trim($html) === '') {
                    continue;
                }
                $blocks_out[] = $this->serialize_block('core/html', [], $html);
                continue;
            }

            // Unknown block type: ignore (or treat as html if present)
            if (!empty($b['html'])) {
                $blocks_out[] = $this->serialize_block('core/html', [], (string) $b['html']);
            }
        }

        return $blocks_out;
    }

    /**
     * Render a visual_ref into a wp:image block.
     *
     * @MODIFIED 2026-02-16 - Phase 3 structured blocks support
     */
    private function render_visual_ref_block(array $meta, int $visual_id): string
    {
        $url = (string) ($meta['url'] ?? '');
        if ($url === '') {
            return '';
        }

        // Handle embeds differently than images
        // @MODIFIED 2026-02-22 - Robust type detection fallback for known video/social providers
        $is_embed = (($meta['type'] ?? '') === 'embed' || strpos($url, 'embed:') === 0);

        if (!$is_embed) {
            $video_patterns = ['youtube.com', 'youtu.be', 'vimeo.com', 'instagram.com', 'tiktok.com', 'twitter.com', 'x.com', 'facebook.com'];
            foreach ($video_patterns as $vp) {
                if (stripos($url, $vp) !== false) {
                    $is_embed = true;
                    break;
                }
            }
        }

        if ($is_embed) {
            // Un-prefix fake dedupe URLs if present
            if (strpos($url, 'embed:') === 0) {
                // If it's a fake URL for a literal embed tag without a source, we might just want to return the raw tag
                $tag = (string) ($meta['tag'] ?? '');
                if ($tag !== '') {
                    return $this->serialize_block('core/html', [], $tag);
                }
                return '';
            }

            // Try to guestimate provider for better formatting if it's a real URL
            $provider = 'embed';
            if (stripos($url, 'instagram.com') !== false) {
                $provider = 'instagram';
            } elseif (stripos($url, 'tiktok.com') !== false) {
                $provider = 'tiktok';
            } elseif (stripos($url, 'twitter.com') !== false || stripos($url, 'x.com') !== false) {
                $provider = 'twitter';
            } elseif (stripos($url, 'youtube.com') !== false || stripos($url, 'youtu.be') !== false) {
                $provider = 'youtube';
            }

            return $this->format_embed_block($url, $provider);
        }

        $alt = (string) ($meta['alt'] ?? '');
        if ($alt === '' && $this->current_post_title !== '') {
            $alt = $this->current_post_title;
        }
        $att_id = (int) ($meta['attachment_id'] ?? 0);

        // @MODIFIED 2026-02-26 - Resolve attachment_id from URL to avoid wp:image id=0 and improve cleanup/SEO.
        if ($att_id <= 0) {
            $att_id = (int) attachment_url_to_postid($url);
            if ($att_id <= 0) {
                $inv = new Media_Inventory();
                $att_id = (int) $inv->resolve_attachment_id_from_url($url);
            }
        }

        $class  = $att_id > 0 ? 'wp-image-' . $att_id : '';
        $size   = 'large';

        $img = '<img src="' . esc_url($url) . '" alt="' . esc_attr($alt) . '"';
        if ($class !== '') {
            $img .= ' class="' . esc_attr($class) . '"';
        }
        $img .= ' />';
        $fig = '<figure class="wp-block-image size-' . esc_attr($size) . '">' . $img . '</figure>';
        $attrs = [
            'sizeSlug' => $size,
            'linkDestination' => 'none',
        ];

        if ($att_id > 0) {
            $attrs['id'] = $att_id;
        }

        return $this->serialize_block('core/image', $attrs, $fig);
    }

    /**
     * Convert sources to Group block
     *
     * @param array $sources Sources array
     * @return string Block markup or empty
     */
    private function sources_to_block(array $sources): string
    {
        // Filter valid URLs
        $valid_sources = array_filter($sources, function ($source) {
            $url = $source['url'] ?? '';
            return !empty($url) && filter_var($url, FILTER_VALIDATE_URL);
        });

        if (empty($valid_sources)) {
            return '';
        }

        $inner = [];

        // Heading
        $inner[] = $this->serialize_block('core/heading', [
            'level' => 3,
            'className' => 'wp-block-heading', // @MODIFIED 2026-01-19 - Added for Gutenberg compliance
        ], '<h3 class="wp-block-heading">' . esc_html__('Sources', 'dit-trend-content-studio') . '</h3>');

        // Source items
        foreach ($valid_sources as $source) {
            $url = esc_url($source['url']);
            $label = esc_html($source['label'] ?? $source['url']);

            $inner[] = $this->serialize_block('core/paragraph', [
                'className' => 'dit-ts-source-item',
            ], sprintf(
                '<p><a href="%s" target="_blank" rel="noopener noreferrer">%s</a></p>',
                $url,
                $label
            ));
        }

        return $this->serialize_block('core/group', [
            'className' => 'dit-ts-sources',
        ], implode("\n", $inner));
    }

    /**
     * Serialize a Gutenberg block
     *
     * @param string $name  Block name (e.g., 'core/paragraph')
     * @param array  $attrs Block attributes
     * @param string $inner Inner HTML content
     * @return string Serialized block markup
     */
    private function serialize_block(string $name, array $attrs, string $inner): string
    {
        // Use WP core serializer when available (most robust; prevents block recovery).
        if (function_exists('serialize_block')) {
            return serialize_block([
                'blockName'    => $name,
                'attrs'        => $attrs,
                'innerBlocks'  => [],
                'innerHTML'    => $inner,
                'innerContent' => [$inner],
            ]);
        }

        // Fallback: emulate core escaping for comment-delimited JSON attributes
        $attr_string = '';
        if (!empty($attrs)) {
            if (function_exists('serialize_block_attributes')) {
                $attr_string = ' ' . serialize_block_attributes($attrs);
            } else {
                $json = wp_json_encode($attrs, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

                // Critical: prevent invalid HTML comments by escaping `--` and `<` like core does.
                $json = str_replace('--', '\\u002d\\u002d', $json);
                $json = str_replace('<', '\\u003c', $json);

                $attr_string = ' ' . $json;
            }
        }

        // Self-closing block if no inner content
        if (trim((string) $inner) === '') {
            return "<!-- wp:{$name}{$attr_string} /-->";
        }

        return "<!-- wp:{$name}{$attr_string} -->\n{$inner}\n<!-- /wp:{$name} -->";
    }


    /**
     * Convert article data to HTML (legacy, for admin preview)
     *
     * @param array $article Article data array
     * @return string Formatted HTML
     */
    public function to_html(array $article): string
    {
        $schema = Content_Schema::from_array($article);

        // Scoped wrapper for CSS isolation
        $html = '<div class="dit-ts-article">';

        // Dek/subhead
        if (!empty($schema->dek)) {
            $html .= $this->format_dek($schema->dek);
        }

        // Sections
        $first_section = true;
        $blocks = []; // Initialize blocks array for this context
        foreach ($schema->sections as $index => $section) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log(sprintf('TrendStudio: Processing section %d: %s', $index, $section['heading'] ?? 'Unnamed'));
            }
            // Assuming section_to_blocks is a method that returns an array of block strings
            // For to_html, we'll use format_section and convert its output to a block-like structure for debug consistency
            // This is a placeholder as section_to_blocks is not defined in the provided context.
            // If section_to_blocks is meant to return actual block objects/arrays, this would need adjustment.
            $section_html = $this->format_section($section);
            $section_blocks = [$section_html]; // Wrap HTML in an array to simulate block output
            if (defined('WP_DEBUG') && WP_DEBUG) {
                error_log(sprintf('TrendStudio: Section %d returned %d blocks.', $index, count($section_blocks)));
            }
            $blocks = array_merge($blocks, $section_blocks);
            $first_section = false;
        }
        // In to_html, we concatenate the HTML directly, so we'll join the 'blocks' here.
        $html .= implode("\n", $blocks);

        // Sources attribution
        if (!empty($schema->sources)) {
            $html .= $this->format_sources($schema->sources);
        }

        $html .= '</div>';
        return $html;
    }

    /**
     * Wrap a string in <p> tags exactly once.
     * @MODIFIED 2026-03-09
     *
     * @param string $content
     * @return string
     */
    private function wrap_paragraph_once(string $content): string
    {
        $content = trim($content);
        if ($content === '') return '';
        if (strpos($content, '<p') === 0) return $content;
        return "<p>{$content}</p>";
    }

    /**
     * Format dek/subhead
     *
     * @param string $dek Dek text
     * @return string HTML
     */
    private function format_dek(string $dek): string
    {
        return sprintf(
            '<p class="dit-ts-dek"><em>%s</em></p>',
            esc_html($dek)
        );
    }

    /**
     * Format content section
     *
     * @param array $section Section data
     * @return string HTML
     */
    private function format_section(array $section): string
    {
        $heading = $section['heading'] ?? '';
        $body = $section['body_html'] ?? '';

        $html = '';

        // Skip heading for intro section or if empty
        if (!empty($heading) && strtolower($heading) !== 'introduction') {
            $html .= sprintf('<h2>%s</h2>', esc_html($heading));
        }

        // Body content (already HTML)
        $html .= wp_kses_post($body);

        return $html;
    }

    /**
     * Format sources attribution
     *
     * @param array $sources Sources array
     * @return string HTML
     */
    private function format_sources(array $sources): string
    {
        // Validate URLs to filter AI-fabricated sources
        $valid_sources = array_filter($sources, function ($source) {
            $url = $source['url'] ?? '';
            return !empty($url) && filter_var($url, FILTER_VALIDATE_URL);
        });

        if (empty($valid_sources)) {
            return '';
        }

        $html = '<div class="dit-ts-sources">';
        $html .= '<h3>' . esc_html__('Sources', 'dit-trend-content-studio') . '</h3>';
        $html .= '<ul>';

        foreach ($valid_sources as $source) {
            $url = $source['url'];
            $label = $source['label'] ?? $url;

            $html .= sprintf(
                '<li><a href="%s" target="_blank" rel="noopener noreferrer">%s</a></li>',
                esc_url($url),
                esc_html($label)
            );
        }

        $html .= '</ul></div>';

        return $html;
    }

    /**
     * Format image attribution line
     * @MODIFIED 2025-12-13 - P0: Image attribution rendering
     *
     * @param array $attribution Attribution data
     * @return string HTML
     */
    private function format_image_attribution(array $attribution): string
    {
        $credit = $attribution['credit'] ?? '';
        if (empty($credit)) {
            return '';
        }

        $parts = array(esc_html($credit));
        $license = $attribution['license'] ?? '';
        if (!empty($license) && $license !== 'Unknown') {
            $parts[] = esc_html($license);
        }

        return sprintf(
            '<figcaption class="dit-ts-image-credit">%s</figcaption>',
            implode(' / ', $parts)
        );
    }

    /**
     * Format content section for preview (with verification badges)
     * @MODIFIED 2025-12-13 - P0: Editor-only verification badges
     * @MODIFIED 2025-12-14 - Added inline image picker for section images
     *
     * @param array $section Section data
     * @param int   $index   Section index for form handling
     * @return string HTML with verification badge
     */
    private function format_section_preview(array $section, int $index = 0): string
    {
        $heading = $section['heading'] ?? '';
        $body = $section['body_html'] ?? '';
        $status = $section['verification_status'] ?? '';
        $image_suggestions = $section['image_suggestions'] ?? [];
        $selected_image = $section['selected_image'] ?? null;

        $html = '';

        // Verification badge (editor-only)
        $badge = '';
        if ($status === 'UNVERIFIED') {
            $badge = '<span class="dit-ts-unverified-badge">[UNVERIFIED]</span> ';
        } elseif ($status === 'REPORT_CLAIMS') {
            $badge = '<span class="dit-ts-report-claims-badge">[REPORT CLAIMS]</span> ';
        }

        // Skip heading for intro section or if empty
        if (!empty($heading) && strtolower($heading) !== 'introduction') {
            $html .= sprintf('<h2>%s%s</h2>', $badge, esc_html($heading));
        } elseif (!empty($badge)) {
            // No heading but has badge - prepend to body
            $body = $badge . $body;
        }

        // Inline image picker (if suggestions available)
        if (!empty($image_suggestions)) {
            $html .= $this->render_image_picker($image_suggestions, $selected_image, $index);
        }

        // Body content (already HTML)
        $html .= wp_kses_post($body);

        return $html;
    }

    /**
     * Render inline image picker for a section
     * @MODIFIED 2025-12-14 - Image suggestion UI
     *
     * @param array       $suggestions Image suggestions array
     * @param array|null  $selected    Currently selected image
     * @param int         $index       Section index
     * @return string HTML
     */
    private function render_image_picker(array $suggestions, ?array $selected, int $index): string
    {
        $html = '<div class="dit-ts-image-picker" data-section="' . $index . '">';
        $html .= '<div class="dit-ts-image-picker__label">Select section image:</div>';
        $html .= '<div class="dit-ts-image-picker__options">';

        foreach ($suggestions as $i => $image) {
            $is_selected = ($selected && isset($selected['id']) && $selected['id'] === $image['id']);
            $selected_class = $is_selected ? ' dit-ts-image-picker__option--selected' : '';

            $html .= sprintf(
                '<label class="dit-ts-image-picker__option%s">
                    <input type="radio" name="dit_ts_section_%d_image" value="%s" data-image=\'%s\' %s>
                    <img src="%s" alt="%s" class="dit-ts-image-picker__thumb">
                    <span class="dit-ts-image-picker__credit">%s</span>
                </label>',
                $selected_class,
                $index,
                esc_attr($image['id']),
                esc_attr(wp_json_encode($image)),
                $is_selected ? 'checked' : '',
                esc_url($image['thumb']),
                esc_attr($image['alt'] ?? $image['attribution'] ?? ''),
                esc_html($image['attribution'] ?? 'Unknown')
            );
        }

        // None option
        $none_selected = empty($selected);
        $html .= sprintf(
            '<label class="dit-ts-image-picker__option dit-ts-image-picker__option--none%s">
                <input type="radio" name="dit_ts_section_%d_image" value="" %s>
                <span class="dit-ts-image-picker__none-label">None</span>
            </label>',
            $none_selected ? ' dit-ts-image-picker__option--selected' : '',
            $index,
            $none_selected ? 'checked' : ''
        );

        $html .= '</div></div>';

        return $html;
    }

    /**
     * Format article for preview (includes wrapper)
     *
     * @param array $article Article data
     * @return string HTML with preview wrapper
     */
    /**
     * Convert article data to preview-friendly HTML
     * @MODIFIED 2025-12-18 - Added validation results for scoring dashboard
     *
     * @param array $article    Article data
     * @param array $validation Optional validation results from Scoring Engine
     * @return string HTML
     */
    public function to_preview_html(array $article, array $validation = []): string
    {
        $schema = Content_Schema::from_array($article);

        $html = '<div class="dit-ts-preview">';

        // Preview header
        $html .= '<div class="dit-ts-preview-header">';
        $html .= sprintf('<h1>%s</h1>', esc_html($schema->headline));
        if (!empty($schema->dek)) {
            $html .= sprintf('<p class="dit-ts-preview-dek">%s</p>', esc_html($schema->dek));
        }
        $html .= '</div>';

        // @MODIFIED 2025-12-13 - P0: Image attribution in preview
        if (!empty($schema->image_attribution)) {
            $html .= $this->format_image_attribution($schema->image_attribution);
        }

        // Content (with verification badges for preview)
        $html .= '<div class="dit-ts-preview-content">';
        $html .= '<div class="dit-ts-article">';

        // Dek/subhead
        if (!empty($schema->dek)) {
            $html .= $this->format_dek($schema->dek);
        }

        // @MODIFIED 2025-12-13 - P0: Use preview formatter with verification badges
        // @MODIFIED 2025-12-14 - Pass index for image picker
        foreach ($schema->sections as $i => $section) {
            $html .= $this->format_section_preview($section, $i);
        }

        // Sources attribution
        if (!empty($schema->sources)) {
            $html .= $this->format_sources($schema->sources);
        }

        $html .= '</div>';
        $html .= '</div>';

        // @MODIFIED 2025-12-18 - Elite Quality Dashboard
        if (!empty($validation)) {
            $html .= $this->render_quality_dashboard($validation);
        } else {
            $html .= $this->render_issues_panel($article);
        }

        $html .= '</div>';

        return $html;
    }

    /**
     * Render Elite Quality Dashboard for preview
     * @MODIFIED 2025-12-18 - New 100-point scoring dashboard
     *
     * @param array $validation Validation results with breakdown
     * @return string HTML
     */
    private function render_quality_dashboard(array $validation): string
    {
        $score = $validation['score'] ?? 0;
        $threshold = $validation['threshold'] ?? 75;
        $breakdown = $validation['breakdown'] ?? [];
        $passed = $validation['passed'] ?? false;

        $meter_color = $passed ? '#00a32a' : ($score > 50 ? '#dba617' : '#d63638');
        $status_label = $passed ? 'ELITE READY' : ($score > 50 ? 'DRAFT QUALITY' : 'NEEDS REWRITE');

        $html = '<div class="dit-ts-quality-dashboard">';
        $html .= '<div class="dit-ts-quality-header" style="border-left: 5px solid ' . $meter_color . '">';
        $html .= '<div class="dit-ts-quality-main">';
        $html .= sprintf('<span class="dit-ts-quality-score" style="color: %s">%d</span>', $meter_color, $score);
        $html .= sprintf('<span class="dit-ts-quality-status">%s</span>', $status_label);
        $html .= '</div>';
        $html .= sprintf('<div class="dit-ts-quality-threshold">Target: %d+ | Mode: %s</div>', $threshold, $passed ? 'Elite' : 'Standard');
        $html .= '</div>';

        $html .= '<div class="dit-ts-quality-breakdown">';
        foreach ($breakdown as $cat => $data) {
            $is_penalty = (isset($data['max']) && $data['max'] === 0);
            $cat_label = ($cat === 'sourcing') ? 'Grounding' : (($cat === 'readability') ? 'Editorial Style' : ucfirst($cat));

            if ($is_penalty) {
                $cat_pct = 0;
                $cat_color = '#d63638';
                $score_text = sprintf('%d pts', $data['raw']);
            } else {
                $cat_pct = ($data['max'] > 0) ? ($data['raw'] / $data['max']) ? ($data['raw'] / $data['max'] * 100) : 0 : 0;
                $cat_color = ($cat_pct >= 80) ? '#00a32a' : (($cat_pct >= 50) ? '#dba617' : '#d63638');
                $score_text = sprintf('%d/%d', $data['raw'], $data['max']);
            }

            $html .= '<div class="dit-ts-quality-cat" style="margin-bottom: 12px; padding: 8px; background: rgba(0,0,0,0.02); border-radius: 4px;">';
            $html .= sprintf('<div style="display:flex; justify-content:between; align-items:center; margin-bottom:4px;"><strong>%s</strong> <span style="margin-left:auto; font-family:monospace;">%s</span></div>', $cat_label, $score_text);

            if (!$is_penalty) {
                $html .= '<div class="dit-ts-quality-bar-bg" style="height:6px; background:#eee; border-radius:3px; overflow:hidden;">';
                $html .= '<div class="dit-ts-quality-bar" style="height:100%; width: ' . $cat_pct . '%; background: ' . $cat_color . '; transition: width 0.5s ease;"></div>';
                $html .= '</div>';
            }

            if (!empty($data['issues'])) {
                $html .= '<ul class="dit-ts-quality-issues" style="margin-top: 8px; font-size: 12px; color: #666; padding-left: 20px;">';
                foreach ($data['issues'] as $issue) {
                    $html .= '<li>' . esc_html($issue) . '</li>';
                }
                $html .= '</ul>';
            }
            $html .= '</div>';
        }
        $html .= '</div>';

        return $html;
    }

    /**
     * Render Editorial Issues Panel for preview (Legacy fallback)
     * @MODIFIED 2025-12-14 - Heuristic-based issues detection
     *
     * @param array $article Article data
     * @return string HTML for issues panel
     */
    private function render_issues_panel(array $article): string
    {
        $issues = \DIT\TrendStudio\Admin\Editorial_Issues::analyze($article);

        if (empty($issues)) {
            return '<div class="dit-ts-issues-panel dit-ts-issues-clean">
                <span class="dit-ts-issues-icon">✓</span> No editorial issues detected
            </div>';
        }

        $total = \DIT\TrendStudio\Admin\Editorial_Issues::count_issues($issues);
        $is_ready = \DIT\TrendStudio\Admin\Editorial_Issues::is_ready($issues);

        $panel_class = $is_ready ? 'dit-ts-issues-info' : 'dit-ts-issues-warning';

        $html = '<div class="dit-ts-issues-panel ' . $panel_class . '">';
        $html .= '<h3 class="dit-ts-issues-heading">';
        $html .= '<span class="dit-ts-issues-icon">' . ($is_ready ? 'ℹ' : '⚠') . '</span> ';
        $html .= 'Editorial Issues (' . $total . ')';
        if (!$is_ready) {
            $html .= ' <span class="dit-ts-issues-gate">— Review required before publishing</span>';
        }
        $html .= '</h3>';

        foreach ($issues as $section_issues) {
            $html .= '<div class="dit-ts-issue-section">';
            $html .= '<strong>' . esc_html($section_issues['heading']) . '</strong>';
            $html .= '<ul class="dit-ts-issue-list">';

            foreach ($section_issues['issues'] as $issue) {
                $severity_class = 'dit-ts-issue-' . ($issue['severity'] ?? 'info');
                $html .= sprintf(
                    '<li class="dit-ts-issue-item %s"><span class="dit-ts-issue-text">%s</span> — <em class="dit-ts-issue-action">%s</em></li>',
                    esc_attr($severity_class),
                    esc_html($issue['text']),
                    esc_html($issue['action'])
                );
            }

            $html .= '</ul></div>';
        }

        $html .= '</div>';

        return $html;
    }
    /**
     * Parse global markdown (Bold/Italic) in final HTML
     * @since 1.9.0
     * @param string $content
     * @return string
     */
    private function parse_markdown_global(string $content): string
    {
        // Bold: **text**
        $content = preg_replace('/\*\*(.*?)\*\*/s', '<strong>$1</strong>', $content);

        // Italic: *text* (avoiding double ** match)
        $content = preg_replace('/(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)/s', '<em>$1</em>', $content);

        return $content;
    }
}
