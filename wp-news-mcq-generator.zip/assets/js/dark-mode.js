/**
 * Site-Wide Dark Mode Manager
 * @version 3.0
 *
 * This script handles the 2-state (Light/Dark) theme toggle.
 * It works with the 'inject_dark_mode_fouc_fix' script to manage
 * the 'dark-mode' class on the <html> element.
 *
 * It respects the OS setting on first load and then allows the user
 * to toggle between 'light' and 'dark' modes, saving their
 * preference in localStorage.
 */
jQuery(document).ready(function ($) {
    'use strict';

    const themeToggle = {
        // --- 1. CONFIGURATION ---
        storageKey: 'nm-theme',
        cssClass: 'dark-mode',
        buttonId: '#nm-theme-toggle-btn',

        // --- 2. INITIALIZATION ---
        init: function () {
            // Check if the toggle button exists
            if ($(this.buttonId).length === 0) {
                return;
            }
            
            this.bindEvents();
            this.updateUI();
            
            // Listen for OS theme changes *only if* the user is in 'auto' mode.
            window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
                const currentSetting = this.getThemeSetting();
                if (currentSetting === 'auto') {
                    this.applyTheme(e.matches);
                    this.updateUI();
                }
            });
        },

        /**
         * Bind click events to the toggle button.
         */
        bindEvents: function () {
            $(document).on('click', this.buttonId, (e) => {
                e.preventDefault();
                this.toggleTheme();
            });
        },

        // --- 3. THEME LOGIC ---

        /**
         * Gets the user's saved theme from localStorage ('light', 'dark', or 'auto').
         * @returns {string} 'light', 'dark', or 'auto'
         */
        getThemeSetting: function () {
            try {
                return localStorage.getItem(this.storageKey) || 'auto';
            } catch (e) {
                return 'auto'; // Default to 'auto' if localStorage fails
            }
        },
        
        /**
         * Checks if the theme *should currently be* dark.
         * @returns {boolean}
         */
        shouldBeDark: function() {
            const theme = this.getThemeSetting();
            if (theme === 'dark') {
                return true;
            }
            if (theme === 'auto' && window.matchMedia('(prefers-color-scheme: dark)').matches) {
                return true;
            }
            return false;
        },

        /**
         * Saves the user's *explicit* theme choice to localStorage.
         * @param {string} theme - 'light' or 'dark'
         */
        saveThemeSetting: function (theme) {
            try {
                localStorage.setItem(this.storageKey, theme);
            } catch (e) {
                console.error("Failed to save theme to localStorage", e);
            }
        },
        
        /**
         * Toggles the theme when the button is clicked.
         * This will override the 'auto' setting.
         */
        toggleTheme: function() {
            // Is the site dark *right now*?
            const isCurrentlyDark = document.documentElement.classList.contains(this.cssClass);
            
            // If it's dark, set to light. If it's light, set to dark.
            const newTheme = isCurrentlyDark ? 'light' : 'dark';
            
            this.saveThemeSetting(newTheme);
            this.applyTheme(!isCurrentlyDark); // Apply the opposite of current state
            this.updateUI();
        },

        /**
         * Applies the 'dark-mode' class to the <html> tag.
         * @param {boolean} isDark - Whether to add or remove the class.
         */
        applyTheme: function (isDark) {
            if (isDark) {
                document.documentElement.classList.add(this.cssClass);
            } else {
                document.documentElement.classList.remove(this.cssClass);
            }
        },

        // --- 4. UI MANAGEMENT ---
        
        /**
         * Updates the toggle button icon to show the correct state.
         */
        updateUI: function () {
            // This function runs on page load and after every toggle.
            // It checks the *actual* state of the page (which could be from 'auto' or 'manual')
            // and sets the button icon accordingly.
            const isDark = document.documentElement.classList.contains(this.cssClass);
            
            if (isDark) {
                // Show Sun icon
                $(this.buttonId).find('.nm-theme-icon-light').show();
                $(this.buttonId).find('.nm-theme-icon-dark').hide();
                $(this.buttonId).attr('title', 'Switch to Light Mode');
            } else {
                // Show Moon icon
                $(this.buttonId).find('.nm-theme-icon-light').hide();
                $(this.buttonId).find('.nm-theme-icon-dark').show();
                $(this.buttonId).attr('title', 'Switch to Dark Mode');
            }
        }
    };

    // Run the theme manager
    themeToggle.init();
});