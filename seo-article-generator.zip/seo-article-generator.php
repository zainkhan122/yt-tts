<?php

/**
 * SEO Article Generator
 *
 * @package     SEO_Article_Generator
 * @author      Your Name
 * @copyright   2025
 * @license     GPL-2.0-or-later
 *
 * @wordpress-plugin
 * Plugin Name: SEO Article Generator
 * Plugin URI:  https://softwareswave.com
 * Description: SEO article for software download pages
 * Version: 2.34.23
 * Author:            TrendStudio
 * Author URI:  https://softwareswave.com
 * Text Domain:       seo-article-generator
 * Domain Path:       /languages
 */

// v2.34.9 - 2026-09-07: [DISCOVERY PROMPT FATAL — use-before-def] After staging was fixed (2.34.8) generation was reached and immediately fatalled: "Prompt_Builder::get_discovery_instructions(): Argument #1 ($scope_sections) must be of type array, null given, called in class-prompt-builder.php on line 77". Root cause (introduced by the PHASE 3E scoped-payload work, 2.33.0): in build_full_instruction_set() the call self::get_discovery_instructions($_scope_sections) on line 77 used $_scope_sections one line BEFORE it was defined (defined on the next line 78: "$_scope_sections = (array)($prompt_data['regen_sections'] ?? array('all'));"). The variable was therefore undefined and passed as null; the method's parameter was typed `array` (default never applies when an argument is explicitly passed), so PHP 8.4 threw a TypeError on EVERY discovery generation. Fix: (1) moved the "$_scope_sections = (array)(...)" resolution ABOVE the get_discovery_instructions()/get_json_schema() calls that consume it (so it is always a concrete array — ['all'] when regen_sections is absent/null, explicit sections otherwise); (2) hardened get_discovery_instructions() to accept `$scope_sections = array('all')` with an internal is_array guard that coerces null/non-array/empty to ['all'], so no caller can ever trip the array type-hint again. Behaviour for correctly-scoped jobs is unchanged; discovery generation now builds its persona instructions instead of fataling. Verified the resolution yields ["all"] for absent and explicit-null regen_sections and the concrete section list when provided; 151/151 PHP files lint clean.
// v2.34.8 - 2026-09-07: [WP AUTO STAGE — REAL ROOT CAUSE: errno 1064 EMBEDDED COMMENT] HONEST CORRECTION. The 2.34.7 by-ref diagnostic finally captured the true error: "mysql_errno=1064 You have an error in your SQL syntax ... near '// FIX F3 (Phase 3B): rescans run periodically while items are'". Root cause: the F3 heartbeat edit in Phase 3B (v2.32.26) inserted a multi-line PHP "//" COMMENT INSIDE the double-quoted $sql = "..." string of stage_wp_auto_item()'s discovery upsert. Inside a PHP double-quoted string "//" is literal text, not a comment, and MySQL rejects "//" as syntax (SQL comments are "--" or /* */) — so EVERY WP-Automatic staging INSERT failed with 1064 and created no row. The changelog payload was tiny (3,157 bytes), so the "Data too long" theory in 2.34.6/7 was NOT the cause (the cap_text_column caps are kept as harmless defensive hardening, a no-op for normal values). Why it looked like it worked: after the INSERT errored, the fallback "SELECT id ... WHERE dedupe_key = md5(post_id)" matched an OLD pre-existing discovery row for the same post and returned that id, so the code logged "Staged discovery #..." pointing at the old row — which stayed status=done and never re-opened (hence the recurring "INSERT kept existing status=done" warnings); genuinely NEW software with no prior row fell through and got re-polled forever. Fix: removed the PHP // comment lines from inside the SQL literal and placed the explanatory note OUTSIDE the string (above the prepare), leaving the heartbeat_at IF(...) as valid SQL. Added a repo-wide scanner asserting no // comment lines fall inside any $sql="..." string (scans includes/ + admin/ clean). Verified in a real MariaDB: built the actual wpzp_seo_gen_discovery schema and replayed the real upsert (a) fresh insert, (b) re-stage newer version over an existing done row via ON DUPLICATE KEY, and (c) brand-new software — all succeed after the fix, whereas the prior SQL threw 1064. The by-ref $diag diagnostic and dashboard seo_gen_error_log surfacing from 2.34.7 are retained (they are what exposed this) and the safety-net system_error marking from 2.34.5 is retained. 151/151 PHP files lint clean.
// v2.34.7 - 2026-09-07: [WP AUTO STAGE — ROOT CAUSE PROVEN + REAL ERROR REACHES DASHBOARD] HONEST DEEP-TRACE: compared the current repo working tree (plugin/) against the earliest surviving pre-release snapshot (Phase 3A/2.32.25) for the ENTIRE WP-Automatic post cycle. The control flow — run_wp_auto_draft_poll, get_unprocessed_drafts (meta_query seo_gen_processed NOT EXISTS), and every branch of process_single_draft (name/version parse, truncated/challenge gate, is_newer_version compare, LAYER1/LAYER2 cooldown dedupe, download-link gate, stage call) — is BYTE-IDENTICAL to the pre-change snapshot; the ONLY changes to that path are (a) the wrong-key fix seogen_error_log -> seo_gen_error_log (the key the dashboard column actually reads) and (b) the added safety-net. The upsert COLUMNS and ON DUPLICATE logic are unchanged. The functions that feed the changelog field (extract_version_changelog_slice, build_source_facts_from_draft) are also byte-identical — not touched by any of my work — so this is NOT a regression I introduced. ROOT CAUSE REPRODUCED IN REAL MySQL/MariaDB: building the actual wpzp_seo_gen_discovery schema and replaying the real INSERT shows an oversized changelog (extract_version_changelog_slice returns the FULL scraped draft HTML when it cannot locate the version heading, and the column is TEXT = 65,535 bytes) aborts the ENTIRE statement with MySQL errno 1406 "Data too long for column 'changelog'" — wpdb::query() returns FALSE, insert_id=0, and no fallback row matches, exactly the production signature (query_ok=false, no row). Normal-length changelogs insert fine; the ON DUPLICATE update path for an existing done post also works. FIX VERIFIED EMPIRICALLY: the same oversized content, run through cap_text_column() (changelog <=60 KB on a UTF-8-safe boundary with an mbstring-free fallback; name/version/url fields bounded to their column widths AFTER wp_kses_post escaping), INSERTs successfully (stored 60,003 bytes). The caps are a no-op for every normal short value and never touch identity/version fields. Applied the same defensive caps to the sibling RSS discovery path (stage_item) which writes the same TEXT changelog column. Error visibility: stage_wp_auto_item() now hands a by-ref $diag built AT the failure point (before later SELECTs reset $wpdb state) containing prepare_ok/query_ok/mysql errno/driver error and per-column payload byte sizes, which the caller writes to seo_gen_error_log so the dashboard Error Log column shows the exact cause (e.g. errno 1406 + offending column size) instead of the old blank "no $wpdb error reported". NOTE the prior "no error" was itself because the failure branch re-read $wpdb->last_error AFTER the fallback row-lookup SELECTs had already reset it — now read at the moment of failure. Net: the recurring drafts (ZHPCleaner 33059, SIW 33081, Attribute Changer 33101, Phiola, draw.io, Hydra) now stage; any genuine future failure is surfaced verbatim. Verified 17 prepare placeholders = 17 args (no placeholder mismatch); 151/151 PHP lint clean; cap unit cases pass for ASCII and 2/3/4-byte UTF-8 on both the mbstring and fallback paths; MySQL replay (insert, oversized-abort, capped-success, done-collision update) all confirmed.
// v2.34.6 - 2026-09-07: [WP AUTO STAGE ROOT CAUSE + ERROR VISIBILITY] 2.34.5 bounded the stuck poll loop and exposed that staging produced NO row, but the dashboard Error Log column stayed empty ("—") and the SQL error was blank. Two real defects found and fixed. (1) ERROR MASKED: stage_wp_auto_item() captured $wpdb->last_error only AFTER running two fallback SELECTs (dedupe_key, draft_post_id); every $wpdb->query() resets last_error/last_query at entry, so the fallback SELECTs wiped the genuine INSERT error and left it empty / pointing at the wrong query. Now the INSERT result is captured and the real MySQL error/errno/failing-query are snapshotted IMMEDIATELY after the upsert, before any fallback query; prepare() failure is detected separately. (2) WRONG META KEY: the engine wrote the failure reason to post meta 'seogen_error_log' (5 sites) while the admin "Processed Drafts → Error Log" column and the FATAL catch read 'seo_gen_error_log' — so reasons never displayed. Normalised all writes to 'seo_gen_error_log'. (3) ROOT CAUSE — silent TEXT-column overflow: extract_version_changelog_slice() returns the FULL draft HTML whenever it cannot locate the target version heading, and the discovery table stores changelog as TEXT (~65 KB) plus several TEXT url fields; a long WP-Automatic draft page overflowed the column and MySQL aborted the ENTIRE INSERT (query returned false, zero row) for the recurring drafts (ZHPCleaner, SIW, Attribute Changer, Phiola, draw.io, Hydra) regardless of new/legacy/plugin type. Added cap_text_column() to bound every inserted column (changelog <=60 KB on a UTF-8-safe boundary, software_name/version/url fields to their column budgets) AFTER wp_kses_post escaping so entity expansion cannot re-overflow; includes a mbstring-free UTF-8 boundary fallback. Identity/version fields are never cut. Net effect: the previously-failing drafts now stage (body capped) instead of erroring, and any genuinely-failing upsert records the exact mysql errno + query AND shows it in the dashboard Error Log column. Verified: truncation unit cases pass for ASCII and 2/3/4-byte UTF-8 (valid UTF-8, no split sequences) on both the mbstring and fallback paths; 151/151 PHP files lint clean.
// v2.34.5 - 2026-09-07: [WP AUTO DRAFT POLL STUCK-LOOP FIX] User reported "Waiting: N" drafts never being processed (6 SW drafts). Log diagnosis: the same ~6 drafts (SIW/System Info -> post 757, ZHPCleaner -> 328, draw.io Desktop -> 17558, Attribute Changer -> 18606, Phiola -> 21595, Hydra Download Manager) were re-fetched and re-processed on EVERY poll (386 batches in the log, each matching a core legacy UPDATE post) but never reached ANY terminal log line - no "Staged discovery", no "Skipped & scheduled deletion", no "Skipped staging" cooldown, no download-gate ignore, no FATAL. Root cause: process_single_draft() had NO else-branch after stage_wp_auto_item(); every early-return path (empty name/version, truncated/challenge content, not-newer, LAYER1/LAYER2 cooldown duplicate, no-download-link) marks seo_gen_processed and the success path marks it 'staged', but when stage_wp_auto_item() returned 0 (staging upsert produced no row) the method just ENDED without setting seo_gen_processed and without logging. get_unprocessed_drafts() selects drafts WHERE seo_gen_processed NOT EXISTS, so those drafts were picked up again forever - the "Waiting: 6" that never drains (and re-running 386x wasted cycles). Fix: (1) added a safety-net else-branch: when staging returns <=0 the draft is now marked seo_gen_processed_status='system_error' with the reason (incl. any $wpdb->last_error), logged at ERROR, and NOT deleted (so a genuine transient DB failure can be retried via "Poll Drafts Now" rather than destroying the source draft); (2) hardened stage_wp_auto_item() row-id resolution - after the INSERT..ON DUPLICATE KEY UPDATE it now resolves insert_id then falls back to dedupe_key lookup then to a draft_post_id lookup (covers legacy rows whose dedupe_key predates the post_id-key migration), and logs a detailed ERROR (query result, last_error, last_query) when genuinely no row is produced instead of silently returning 0. The "running late" poll indicator is explained by the recurring AS action drifting to now+15min while the external-cron heartbeat also fires the poll every ~2min (both by design); the loop is now bounded because every terminal and failure path marks the draft. Full tree 151 PHP files lint clean.
// v2.34.4 - 2026-09-07: [OPENCODE ZEN SESSION HEADER] OpenCode Go/Zen requires clients to "send a stable session ID in the x-opencode-session header for each conversation" (https://opencode.ai/docs/go/#where-can-i-use-it) so Zen can optimize routing and prompt caching; the plugin never sent it. Added includes/ai/class-opencode-session.php (AI\Opencode_Session): is_zen_endpoint() detects the Zen host by endpoint hostname (opencode.ai and *.opencode.ai only - lookalike hosts excluded), session_id()/deterministic_id() derive the id, apply_header() injects it with case-insensitive dedupe. The header is sent on Zen CHAT-COMPLETION requests only - text generation, vision requests, the connection test, model/provider fallback hops, and response-format/web-search self-correction retries - and is NOT sent on the non-chat /zen/v1/models sync (OpenCode_Zen_Model_Sync) nor on OpenRouter/Gemini/Groq/other custom providers. For a generation job the id is DETERMINISTIC: a UUID v5 namespaced under a fixed plugin namespace from site_url + job_id, so it is identical across PHP workers, Action Scheduler retries and model/provider fallback (verified stable across two independent php-cli processes, and distinct per site so staging/prod never collide). For a no-job logical request (connection test, scout) a fresh random UUID v4 is minted once per logical request and reused across that request's internal retries/fallback. No persisted/static configuration field is created. Wiring: AI_Client carries a request_context (set_request_context/get_request_context) and re-applies it to the active provider on every initialize_provider() (the hop used by switch_to_provider_model and restore_provider_state), so the same job identity survives fallback; Custom_Provider stores it via set_execution_context() and adds the header in both its chat retry loop and test_connection() (the only two header-construction sites); Job_Handler sets ['job_id'=>id] right after constructing the AI client. Custom_Provider reached through the AJAX connection test (class-plugin.php) has no job and correctly gets an ephemeral id. The class is autoloader-mappable (includes/ai/class-opencode-session.php), no hard-require needed. Verified: 35 php-cli assertions pass (host detection incl. lookalike rejection, v4/v5 format + version/variant nibbles, deterministic-vs-ephemeral, cross-process stability, per-site isolation, header present on Zen + absent on OpenRouter, dedupe of a preset header, ephemeral reuse across retries + uniqueness across requests, and context survival across a provider re-initialization/fallback hop). All 151 PHP files lint clean.
// v2.34.3 - 2026-09-06: [VERSION/SIZE LEAK FIX] User reported the visible description/snippet on New AND Updated posts still carried the software version and file size (e.g. "Download Wine 11.8 Beta ... (41.8 MB)", "GoodSync 12.9.29 ... is 76.6 MB", "Start11 2.7.1.0 ... sized 54.9 MB"). Root cause: the old stripping only ran on meta_description via per-field regexes that (a) LEFT residue ("( MB)", "is MB,", "Start11 .", "macOS +") and (b) never touched the VISIBLE hero/schema tagline - derive_description_internal() returned raw AI/excerpt text, and Rank Math SoftwareApplication.description used that raw value. Fix: new shared Hero_Data_Provider::strip_version_and_size() used by (1) hero derive_description_internal() [visible tagline], (2) repair_meta_to_spec() [meta_description], (3) Version_SSOT::enforce() meta path, and (4) Rank Math schema buildSoftwareApplication.description. The cleaner strips software versions (prefixed v/ver/version, 3-4 segment builds like 2.7.1.0, and name+version+channel like "11.8 Beta") and file sizes ("(41.8 MB)", "is 76.6 MB,", "90MB") while PRESERVING OS-version ranges ("Windows 10/11", "macOS 10.13+"), rating decimals ("4.5 stars"), and thousands ("12,000") via a mask/restore guard, then cleans residue (empty parentheses, dangling size verbs, broken conjunctions). Also made the meta fallback template version-free ("Download {software_name}" not "Download {name} {version}"). Verified with real php-cli: the three reported strings now render version/size-free and grammatical; ratings/OS versions/lists are untouched. All 150 files lint clean.
// v2.34.2 - 2026-09-06: [FULL CLASS-LOAD AUDIT] Audited all 165 files / 150 PHP files with php-cli 8.4 (every file passes php -l, 0 syntax errors) and verified every production class resolves via the spl_autoloader OR is hard-required in bootstrap. Found and fixed a second latent class-not-found landmine: the four exception classes (AI_Exception, Validation_Exception, Database_Exception, File_Upload_Exception) are all defined inside includes/class-error-handler.php - a filename the autoloader cannot map to their FQCNs (it looks for class-ai-exception.php) - so they were only available after Error_Handler itself happened to autoload, and could fatal in early/background contexts. class-error-handler.php is now hard-required in the class-plugin.php bootstrap block (file_exists guarded), alongside the 2.34.1 version-resolver/title-analyzer hard-require. Verified: all bootstrap-critical classes (exceptions, Error_Handler, SeoGen_Version_Resolver, Title_Analyzer, Version_SSOT, Option_Registry) load with NO autoloader registered. Note: includes/generator/class-post-type-classifier-generator.php is documented zero-caller dead code (its own docblock: "Zero files across the repo use or call PostTypeClassifier") and is never autoloaded/referenced; left in place, harmless. Package verified to contain all 165 files with 150/150 PHP files lint-clean.
// v2.34.1 - 2026-09-06: [CLASS LOAD FATAL FIX] Overdue Recovery / process_item_background fatalled with "Class SEO_Article_Generator\Utils\SeoGen_Version_Resolver not found". The file exists (includes/utils/class-seo-gen-version-resolver.php) and the spl_autoloader CAN resolve it (verified), but it - along with its dependency Discovery\Title_Analyzer - was only ever loaded via the autoloader, never hard-required in bootstrap. Every other critical class is explicitly require_once'd at the top of includes/class-plugin.php; when the autoloader was not effective for the file in production (partial/older deploy state), the discovery died. Hard-require both files in the class-plugin.php bootstrap block (file_exists guarded), so they load on every request regardless of autoloader state. Behaviour unchanged; verified they load without the autoloader registered.
// v2.34.0 - 2026-09-06: [SYNTAX FIX] Resolved a fatal parse error in class-article-generator.php: the 2.32.28 thin-output guard closure was declared `static function () use (..., $this)`, which is illegal PHP ($this cannot appear in a use() list; a bound closure already receives $this). php -l reported "Cannot use $this as lexical variable" on every PHP >= 5.4, so the whole class file failed to compile. Changed to a non-static closure with $this removed from the use() list (behaviour identical - $this auto-binds). Verified with php-cli: all 150 PHP files pass php -l with zero syntax errors. [DUPLICATE AI-CALL GUARD] Stops the 09-06 waste loop where ~1,298 AI HTTP calls in 10h produced only ~19 real updates. Five fixes: (P1) Claim-time post-level duplicate suppression in Job_Handler::process_job() - new is_job_latest_for_post() retires an OLDER backlog ticket (job + queue, via Job_Repository::mark_superseded()) WITHOUT an AI call when a newer non-terminal job already covers the same post (existing_post_id / existingpostid JSON match) or the owning discovery references a newer job; signature 'superseded_duplicate_no_ai_burn' resolves to 'abort' in Discovery_Processor::get_recovery_strategy() so rescans never resurrect it. (P2) Time/heartbeat-aware liveness: get_job_lifecycle_status() now reads heartbeat_at/status_started_at/created_at and lifecycle_state_is_stale_dead() marks a non-terminal job 'stale_dead' (active > ZOMBIE_ACTIVE_STALE_SECONDS=40min with no heartbeat; passive queued/pending > ZOMBIE_PASSIVE_STALE_SECONDS=12h) instead of treating any non-terminal state as 'live' forever; the orphan-completion guard in handle_job_finished() now ADOPTS a newer real completion when the prior owner is a zombie rather than dropping it (fixes 193 orphan-drops). (P3) Force-wake throttle: Discovery_Processor force-wokes at most once per FORCE_WAKE_THROTTLE=120s per discovery (cuts 1,334/day busy-wakes). (P4) Transport-timeout model parking: Custom_Provider reports cURL-28/timeouts to AI_Client::note_transport_timeout(); 3 strikes in 15min parks that model for 15min via the existing cooldown SSOT (success clears strikes), so jobs skip straight to fallback instead of paying a wasted 180s wait each. (P5) Thin-output hardening: array_has_meaningful_content/intro/default sanity branches reject template-stub values (new is_placeholder_content(): 'Step 1: ...', TODO/N-A/lorem/your-text-here, ellipsis-only) so the 59-byte quick_start-stub response (post 31804) trips the thin guard / mandatory gates instead of being accepted and normalizer-backfilled.
// v2.33.1 - 2026-09-06: [NOTICE FIX] Removed a ~123-line orphaned duplicate of the TYPE_PLUGIN surgical-patch branch that was stranded AFTER the Publish_Payload_Builder class closing brace in class-publish-payload-builder.php. It referenced $post_type/$this at file scope (undefined), so every include evaluated a condition on an undefined variable, flooding the WP debug log with 'Undefined variable $post_type ... line 1429'. The block was unreachable dead code - the identical logic lives correctly inside build() (where $post_type is defined and the integrity guard is wired) - so deletion is behaviour-preserving. Version_SSOT class below it untouched.
// v2.33.0 - 2026-09-06: [SCOPED AI PAYLOAD] The AI is now asked ONLY for the sections the user selected in Discovery/Update settings. Prompt JSON schema already pruned per section; this release closes the leaks that still caused full-payload responses: (1) new/upgrade posts now force an always-on structural skeleton (title/slug/meta_description/focus_keyword/long_tail+lsi+keyword_variations/category/tags/tech_specs identity DTO/software_type) so hero badge/version SSOT/Rank Math meta always have data regardless of toggles; (2) discovery persona instructions (FAQ mandate, 'moat_data MANDATORY', hybrid-mode moat search) are emitted only when faqs/moat are in scope, plus an explicit SECTION SCOPE strict directive; (3) internal-link tokens are contracted only into zones that are actually generated (kills the 0/N dropped_unused warnings when intro/features/moat are deselected); (4) Discovery settings UI gains Hero Meta + Related Software toggles (parity with Update sections). Content_Formatter already enforces regen_sections on new posts (2026-09-01 change); updates/self-heal keep render-all non-empty so preserve-merge never drops zones. Full Article ('all') path unchanged.
// v2.32.28 - 2026-09-06: [THIN-OUTPUT GUARD] Full-render self-heal/forced-rewrite updates no longer ship 3-zone pages when the AI (200 OK) omits prose sections. Article_Generator wraps the AI->normalize->schema build in a thin-output retry: full-render updates only (partial surgical updates unaffected); after the first response the expected DISCOVERY prose zones are checked via the existing section_passes_sanity_check SSOT predicate (SIMPLE_UTILITY faqs/moat exempt); when prose is missing the AI call is retried ONCE with a different provider/model chosen from AI_Client::get_fallback_candidates() (skips the resolved model; errors on the retry rethrow into the normal API-error chain). If the retry is still thin the job fails with DeterministicFailureException 'full_render_ai_omitted_sections' (job handler classifies the signature terminal; discovery recovery registry classifies it 'abort' => parked in Failed tab, post untouched, manual Run-now resets). Defense-in-depth: sentinel-absent self-heal re-verifies the MERGED article for prose zones (empty payload or intro<=20 chars / features|faqs<2) immediately before Content_Formatter render and parks via mark_discovery_failure with the same signature instead of writing.
// v2.32.27 - 2026-09-06: [DRY-RUN HARDENING] reconcile_after_queue_reset SELECT now includes scheduled_at (deferred branch respected future publish window instead of always re-arming immediately); F6 Tier-2 dedup SQL de-duplicated in PHP (removed non-deterministic GROUP BY that referenced non-grouped meta_value under ONLY_FULL_GROUP_BY). Verified against 18 real logged discoveries (New/Update/Self-Heal) — F4/F13 producer-consumer chain closes (download-gate throw -> mark_discovery_failure -> breaker parks after 3).
// v2.32.26 - 2026-09-06: [PHASE 3B/3C ROBUSTNESS + HYGIENE] F3 mid-flight heartbeat refresh on alive-job polls (+rescan no longer NULLs in-flight heartbeat), F5 edition-qualifier synonyms (pro=professional etc.) before conflict compare, F6 dedup Tier 2 reads legacy meta key + Tier 1->2 gate runs when Tier 1 only hit the excluded self, F7 inherit-branch replaced-thumb capture, F8 single content-contract reader in classifier (all 3 keys) consumed by engine, F9 submit zone gate uses sentinel SSOT (space-form zone comments), F11 dead WATCHDOG_STALE_HEARTBEAT_SECONDS option removed, F12 dead deterministic-link production documented (not wired), F14 stale comments corrected, F15 single Article_Schema::is_simple_utility() consumed by generator + PPB gates.
// v2.32.25 - 2026-09-06: [PHASE 3A DISCOVERY HARDENING] F4 per-item failure circuit breaker (consecutive_failures/last_failure_at; rescan skips tripped items; approve refuses; Failed-tab PARKED badge; Retry/Run-Now/Dismiss override), F0 all raw failure writes route through mark_discovery_failure SSOT, F1 version SSOT re-enforced on DATA-PRESERVE merge path, F2 regen-scope freeze restored (submit reads approved snapshot; approve always freezes; gate write-if-missing), F13 bare repo pages rejected on AI link path + both presence gates. DB schema 2.20.1.
// v2.32.24 - 2026-09-06: [DEATH-LOOP ROOT FIX] A2 pre-claim gate, E overdue liveness+grace, B2 orphan adoption, F2 worker orphan refusal, D2 transient lifecycle + passive-wait exemption, C2 SSOT failure, G terminal logging + idempotency. Version SSOT aligned (was 2.28.1).
// v2.29.0 - 2026-06-01: [PUBLISH WATCHDOG] Added seo_gen_publish_watchdog recurring AS action (default 120s, option-tunable) that force-publishes plugin-owned posts stuck in 'future'. Complements WP-Cron for hosts that disable it. SSOT ownership gate via Post_Type_Classifier; per-blog MySQL lock prevents overlap.
// v2.28.1 - 2026-07-31: [BUFFER OBFUSCATION FIX] Changed link obfuscation to wrap the last hostname dot (domain.TLD boundary) instead of the first, producing www.site(.)com/post-link instead of www(.)site.com/post-link.
// v2.28.0 - 2026-04-23: [THREE-LAYER INTELLIGENCE] Complete API error system overhaul. Added API_Error_Info (typed value object), API_Error_Parser (provider-aware structured parser), and Quota_State_Manager (live quota tracking with predictive throttling). Adaptive backoff replaces static delays with API's exact retryDelay and auto-adjusts min_interval based on quota utilization. All error classification now routes through SSOT.
// v2.26.6 - 2026-03-09: [POLLER FIX] Resolved WP Auto Draft Poller stall by adding missing database columns (draft_post_id, featured_image_id, source_type) and implementing robust try-catch error handling in the polling loop.
// v2.26.5 - 2026-03-09: [TIME ZONE] Fixed critical recurring time zone bug. All scheduling and dashboard counts now strictly follow Website Local Time. Fixed 0-count bug in Completed tab and hardened settings persistence.


// Prevent direct access
if (! defined('ABSPATH')) {
	exit;
}

// Define plugin constants
define('SEO_GEN_VERSION', '2.34.23');
define('SEO_GEN_PLUGIN_FILE', __FILE__);
define('SEO_GEN_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('SEO_GEN_PLUGIN_URL', plugin_dir_url(__FILE__));
define('SEO_GEN_PLUGIN_BASENAME', plugin_basename(__FILE__));

// DIAGNOSTIC: Enable download link debugging (set to false or remove in production)
if ( ! defined( 'SEO_GEN_DEBUG_LINKS' ) ) {
	define( 'SEO_GEN_DEBUG_LINKS', true );
}

// v2.26.7: Secure Action Scheduler inclusion to prevent fatal redeclaration errors.
if (! class_exists('ActionScheduler')) {
	$as_path = __DIR__ . '/vendor/action-scheduler/action-scheduler.php';
	if (file_exists($as_path)) {
		require_once $as_path;
	}
}

if (class_exists('ActionScheduler')) {
	add_filter('action_scheduler_run_queue_on_admin_init', '__return_false', 10, 0);

	// FIX AS RECURRING ACTION KILLER: AS 3.9.3 kills recurring actions after
	// 5 consecutive failures. Our heartbeat handlers routinely exceed PHP
	// max_execution_time on slow AI generations (cURL 180s timeout + retry path
	// = 250s+ heartbeat). This marked queue_worker/sync_finalizer/etc as
	// STATUS_FAILED repeatedly until AS stopped rescheduling them entirely,
	// producing the persistent "Re-created missing recurring action" loop seen
	// in production logs. Set threshold so high that the killer never engages
	// for these handlers — the meta-watchdog in Discovery_Bootstrap already
	// recreates missing recurring actions every page load.
	add_filter('action_scheduler_recurring_action_failure_threshold', function ( $threshold ) {
		return 999999;
	}, 10, 1 );
}

/**
 * Autoloader for plugin classes
 */
spl_autoload_register(
	function ($class) {
		$prefix = 'SEO_Article_Generator\\';
		$len = strlen($prefix);

		if (strncmp($prefix, $class, $len) !== 0) {
			return;
		}

		$relative_class = (string) substr($class, $len);

		if (strpos($relative_class, 'Admin\\') === 0) {
			$base_dir = SEO_GEN_PLUGIN_DIR . 'admin/';
			$relative_class = substr($relative_class, 6);
		} else {
			$base_dir = SEO_GEN_PLUGIN_DIR . 'includes/';
		}

		$parts = explode('\\', $relative_class);
		$class_name = array_pop($parts);
		$dir_path = empty($parts) ? '' : strtolower(implode('/', $parts)) . '/';

		$is_trait = (strpos($relative_class, 'Traits\\') !== false);
		$prefix_type = $is_trait ? 'trait-' : 'class-';
		
		// Convert Class_Name to class-class-name.php AND RankMath to rank-math
		$clean_class = preg_replace('/([a-z])([A-Z])/', '$1-$2', $class_name);
		$file_name = $prefix_type . strtolower(str_replace('_', '-', $clean_class)) . '.php';
		$file = $base_dir . $dir_path . $file_name;

		if (file_exists($file)) {
			require $file;
		}
	}
);

/**
 * Initialize the plugin internals only after schema is confirmed current.
 */
if (! function_exists('seo_gen_init')) {
	function seo_gen_init()
	{
		try {
			if (! class_exists('SEO_Article_Generator\\Plugin')) {
				throw new \RuntimeException('Plugin class not found. Core files may be missing.');
			}

			$plugin = \SEO_Article_Generator\Plugin::get_instance();
			$plugin->init();

			if (class_exists('SEO_Article_Generator\\Discovery\\Discovery_Bootstrap')) {
				$discovery = \SEO_Article_Generator\Discovery\Discovery_Bootstrap::get_instance();
				$discovery->init();
			}

			if (class_exists('SEO_Article_Generator\\Tools\\Sentinel_Injector')) {
				\SEO_Article_Generator\Tools\Sentinel_Injector::register();
			}
		} catch (\Throwable $e) {
			error_log('SEO Article Generator initialization failed: ' . $e->getMessage());

			add_action(
				'admin_notices',
				function () use ($e) {
					if (current_user_can('manage_options')) {
						printf(
							'<div class="notice notice-error"><p><strong>SEO Article Generator Error:</strong> %s</p></div>',
							esc_html($e->getMessage())
						);
					}
				}
			);
		}
	}
}

/**
 * Installer loader helper.
 */
if (! function_exists('seo_gen_require_installer')) {
	function seo_gen_require_installer()
	{
		require_once SEO_GEN_PLUGIN_DIR . 'includes/class-installer.php';
	}
}

/**
 * Upgrade lock key.
 */
if (! function_exists('seo_gen_upgrade_lock_key')) {
	function seo_gen_upgrade_lock_key()
	{
		return 'seo_gen_upgrade_lock';
	}
}

if (! function_exists('seo_gen_upgrade_lock_ttl')) {
	function seo_gen_upgrade_lock_ttl()
	{
		return 15 * MINUTE_IN_SECONDS;
	}
}

/**
 * Check whether an upgrade is currently running.
 */
if (! function_exists('seo_gen_is_upgrade_locked')) {
	function seo_gen_is_upgrade_locked()
	{
		$locked_at = (int) get_option(seo_gen_upgrade_lock_key(), 0);

		if ($locked_at <= 0) {
			return false;
		}

		if ((time() - $locked_at) > seo_gen_upgrade_lock_ttl()) {
			delete_option(seo_gen_upgrade_lock_key());
			return false;
		}

		return true;
	}
}

/**
 * Acquire a short-lived upgrade mutex.
 */
if (! function_exists('seo_gen_acquire_upgrade_lock')) {
	function seo_gen_acquire_upgrade_lock()
	{
		$locked_at = (int) get_option(seo_gen_upgrade_lock_key(), 0);

		if ($locked_at > 0 && (time() - $locked_at) > seo_gen_upgrade_lock_ttl()) {
			delete_option(seo_gen_upgrade_lock_key());
		}

		return add_option(seo_gen_upgrade_lock_key(), time(), '', 'no');
	}
}

/**
 * Release upgrade mutex.
 */
if (! function_exists('seo_gen_release_upgrade_lock')) {
	function seo_gen_release_upgrade_lock()
	{
		delete_option(seo_gen_upgrade_lock_key());
	}
}

/**
 * Return whether schema is current.
 */
if (! function_exists('seo_gen_schema_is_current')) {
	function seo_gen_schema_is_current()
	{
		seo_gen_require_installer();
		return \SEO_Article_Generator\Installer::is_schema_healthy();
	}
}

/**
 * Run DB upgrade only in safe contexts.
 * Admin-only by default; also allow WP-CLI.
 */
if (! function_exists('seo_gen_maybe_upgrade')) {
	function seo_gen_maybe_upgrade()
	{
		if (! is_admin() && ! (defined('WP_CLI') && WP_CLI)) {
			return;
		}

		seo_gen_require_installer();

		if (! \SEO_Article_Generator\Installer::needs_upgrade() && \SEO_Article_Generator\Installer::is_schema_healthy()) {
			return;
		}

		if (! seo_gen_acquire_upgrade_lock()) {
			return;
		}

		try {
			update_option(\SEO_Article_Generator\Installer::OPTION_INSTALL_STATE, 'installing', false);
			delete_option(\SEO_Article_Generator\Installer::OPTION_INSTALL_ERR);

			\SEO_Article_Generator\Installer::upgrade();
		} catch (\Throwable $e) {
			error_log('SEO Article Generator upgrade failed: ' . $e->getMessage());
			update_option(\SEO_Article_Generator\Installer::OPTION_INSTALL_ERR, $e->getMessage(), false);
			update_option(\SEO_Article_Generator\Installer::OPTION_INSTALL_STATE, 'failed', false);
		} finally {
			seo_gen_release_upgrade_lock();
		}
	}
}
add_action('plugins_loaded', 'seo_gen_maybe_upgrade', 5);

/**
 * Safe boot gate.
 * Never boot plugin services against an outdated schema.
 */
if (! function_exists('seo_gen_boot')) {
	function seo_gen_boot()
	{
		seo_gen_require_installer();

		$install_state = get_option(\SEO_Article_Generator\Installer::OPTION_INSTALL_STATE, 'installed');

		if ($install_state === 'installing' || $install_state === 'failed') {
			return;
		}

		if (seo_gen_is_upgrade_locked()) {
			return;
		}

		if (! seo_gen_schema_is_current()) {
			return;
		}

		seo_gen_init();
	}
}
add_action('plugins_loaded', 'seo_gen_boot', 20);

/**
 * Optional admin notice so upgrades are not invisible.
 */
if (! function_exists('seo_gen_upgrade_admin_notice')) {
	function seo_gen_upgrade_admin_notice()
	{
		if (! current_user_can('manage_options')) {
			return;
		}

		if (seo_gen_is_upgrade_locked()) {
			echo '<div class="notice notice-warning"><p><strong>SEO Article Generator:</strong> Database upgrade is currently running.</p></div>';
			return;
		}

		if (! seo_gen_schema_is_current()) {
			$error = get_option(\SEO_Article_Generator\Installer::OPTION_INSTALL_ERR);
			if ($error) {
				echo '<div class="notice notice-error"><p><strong>SEO Article Generator:</strong> Database upgrade failed: ' . esc_html($error) . '</p><p>Check your error logs or try deactivating and reactivating the plugin.</p></div>';
			} else {
				echo '<div class="notice notice-warning"><p><strong>SEO Article Generator:</strong> Database upgrade is pending. Visit this admin page again in a moment.</p></div>';
			}
		}
	}
}
add_action('admin_notices', 'seo_gen_upgrade_admin_notice');

/**
 * Activation hook
 */
function seo_gen_activate()
{
	try {
		$installer_file = SEO_GEN_PLUGIN_DIR . 'includes/class-installer.php';

		if (! file_exists($installer_file)) {
			throw new \RuntimeException('Installer class file not found');
		}

		require_once $installer_file;

		if (! class_exists('SEO_Article_Generator\\Installer')) {
			throw new \RuntimeException('Installer class not found');
		}

		\SEO_Article_Generator\Installer::activate();
	} catch (\Throwable $e) {
		seo_gen_release_upgrade_lock();

		wp_die(
			'Plugin activation failed: ' . esc_html($e->getMessage()),
			'SEO Article Generator Activation Error',
			array('back_link' => true)
		);
	}
}
register_activation_hook(__FILE__, 'seo_gen_activate');

/**
 * Deactivation hook
 */
function seo_gen_deactivate()
{
	try {
		require_once SEO_GEN_PLUGIN_DIR . 'includes/class-installer.php';
		seo_gen_release_upgrade_lock();
		\SEO_Article_Generator\Installer::deactivate();
	} catch (\Throwable $e) {
		seo_gen_release_upgrade_lock();
		error_log('SEO Article Generator deactivation error: ' . $e->getMessage());
	}
}
register_deactivation_hook(__FILE__, 'seo_gen_deactivate');
