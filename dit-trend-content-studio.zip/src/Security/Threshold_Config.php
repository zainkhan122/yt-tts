<?php

/**
 * Threshold Configuration
 *
 * Single source of truth for all validation thresholds and scoring point distributions.
 *
 * @package DIT_TrendStudio\Security
 * @since   1.3.0
 */

namespace DIT\TrendStudio\Security;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Configuration class for Scoring Engine and Validator.
 */
class Threshold_Config
{
    /**
     * Get the full configuration for a given mode.
     *
     * @param string $mode 'editorial' or 'social'
     * @return array
     */
    public static function get(string $mode = 'editorial'): array
    {
        $defaults = [
            'sourcing' => [
                'pts_full'      => 40,
                'min_citations' => 3,
                'penalty_unnamed' => 5, // Pts removed per unnamed source claim
            ],
            'readability' => [
                'pts_full'       => 25,
                'optimal_sentence_length' => 20,
                'max_sentence_length'     => 45,
                'optimal_breathability'   => 0.7, // 70% variance in sentence lengths
            ],
            'seo' => [
                'pts_full'      => 20,
                'min_title'     => 40,
                'max_title'     => 70,
                'min_meta'      => 120,
                'max_meta'      => 160,
            ],
            'media' => [
                'pts_full'      => 15,
                'require_credit' => true,
                'min_search_terms' => 3,
            ],
            'threshold' => 75,
        ];

        if ($mode === 'social') {
            $defaults['threshold'] = 60;
            $defaults['sourcing']['min_citations'] = 1;
            $defaults['readability']['max_sentence_length'] = 60;
        }

        return $defaults;
    }

    /**
     * Get the pass/fail threshold for a mode.
     *
     * @param string $mode
     * @return int
     */
    public static function get_mode_threshold(string $mode = 'editorial'): int
    {
        return self::get($mode)['threshold'];
    }
}
