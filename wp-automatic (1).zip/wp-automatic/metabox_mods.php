<?php

// Globals
global $post;
global $wpdb;
global $camp_general;
global $post_id;
global $camp_options;
global $post_types;

global $camp_replace_link;

?>

<div class="TTWForm-container" dir="ltr">
	<div class="TTWForm">
		<div class="panes">
		
		
					 <div id="field1zz-container" class="field f_100">
		 <div class="option clearfix">
                    
                    <input name="camp_options[]" data-controls="replace_regex"   value="OPT_RGX_REPLACE" type="checkbox">
                    <span class="option-title">
							Search and replace (REGEX enabled) ( pattern1|pattern2) 
                    </span>
                    <br>
                    
		            <div id="replace_regex" class="field f_100">
		               <label for="field6">
		                    Search|Replace one per line
		               </label>
		               <textarea name="cg_regex_replace" ><?php   echo wp_automatic_htmlentities($camp_general['cg_regex_replace'],ENT_COMPAT, 'UTF-8' )  ?></textarea>
		            
		            	
		            	<br>
		            	<div class="field f_100">
			            	<input name="camp_options[]"    value="OPT_RGX_REPLACE_PROTECT" type="checkbox">
		                    <span class="option-title">
								Protect html tags  before replacing? 
		                    </span>
		                </div>
		                
		                 <div class="field f_100">    
		                    <input name="camp_options[]"    value="OPT_RGX_REPLACE_WORD" type="checkbox">
		                    <span class="option-title">
								Words replace? (in case above box contining words or sentences) 
		                    </span>
		                    
		                    
	                    </div>
	                    <br>
		                
		                <div class="field f_100">    
		                    <input name="camp_options[]"    value="OPT_RGX_REPLACE_TTL" type="checkbox">
		                    <span class="option-title">
								Apply to titles also? 
		                    </span>
		                   
		                    
	                    </div>
	                    
	                    <div class="field f_100">    
		                    <input name="camp_options[]"    value="OPT_RGX_REPLACE_SEP" type="checkbox">
		                    <span class="option-title">
								Use # as the seprator between search and replace
		                    </span>
		                    <div class="description"><i>search#replace instead of search|replace</i></div>
		                    
	                    </div>
	                    
	                    <br>
	                    
	                     <div class="description"><i>*add "|titleonly" without quotes at the end of the rule if you want to apply it to only titles<br><br>*add "|contentonly" without quotes at the end of the rule if you want to apply it to only the content<br><br>example1: nice|awesome replaces the the word nice with awesome<br>example2: nice| replaces the word nice with empty <br>example3: nice|awesome|titleonly replaces the word nice with awesome in titles only</i></div>
		            
		            </div>
		            
		            
		            
		            
               </div>
          </div>
		           
         <div id="replace_links" class="field f_100">
               <div class="option clearfix">
                    
                    <input name="camp_options[]" data-controls="replace_linkc" value="OPT_REPLACE" type="checkbox">
                    <span class="option-title">
							Replace specified keywords in the fetched article with a link (Kewyords in the keywords box)
                    </span>
                    <br>
                    
		            <div id="replace_linkc" class="field f_100">
		               <label for="field6">
		                    Link to replace keywords with
		               </label>
		               <input value="<?php   echo $camp_replace_link   ?>" name="camp_replace_link" id="field6"   type="text">
		             <div class="description">The plugin will search for the keywords from the keywords box and hyperlink with this link<br>For example if you are getting videos from Youtube about SEO keyword, add the desired hyperlink</div>
		            </div>
		            
               </div>
		 </div>
		 
		 <div  class="field f_100">
               <div class="option clearfix">
                    
                    <input name="camp_options[]" data-controls="replace_linkc_keywords" value="OPT_REPLACE_KEYWORD" type="checkbox">
                    <span class="option-title">
							Hyperlink specific keywords with a specific link
                    </span>
                    <br>
                    
		            <div id="replace_linkc_keywords" class="field f_100">
		               <label >
		                    keyword|link (one per line)
		               </label>
		                
		                <textarea name="cg_keywords_replace" ><?php   echo  @$camp_general['cg_keywords_replace']  ?></textarea>
		             
						<input name="camp_options[]"  value="OPT_REPLACE_KEYWORD_ONCE" type="checkbox">
						<span class="option-title">
								Replace only once per post (by default it will replace all occurences)
						</span>
						
						<div class="description">The plugin will search for the keyword  and hyperlink with this link<br>example 1: seo|https://moz.com<br>example 2: seo,link building|https://moz.com</div>
		            </div>
		            
               </div>
		 </div>

		 

          <div id="limit_content" class="field f_100">
               <div class="option clearfix">
                    
                    <input name="camp_options[]"  data-controls="limit_content_c" id="limit_content_opt" value="OPT_LIMIT" type="checkbox">
                    <span class="option-title">
							Truncate content to a specific number of chars
                    </span>
                    <br>
                    
		            <div id="limit_content_c" class="field f_100">
		               <label for="field6">
		                    Number of characters ?
		               </label>
		               
		                <input value="<?php   echo @$camp_general['cg_content_limit']   ?>" max="20000" min="0" name="cg_content_limit" id="fieldlimit" required="required" class="ttw-range range"
               type="range">
               
               			<div class="field f_100">TIP: if you want to get the content before truncation, use the tag [cont] in the post template or the custom fields section</div> 
		               
		            </div>
		            
               </div>
		 </div>      


		<div id="limit_title" class="field f_100">
               <div class="option clearfix">
                    
                    <input name="camp_options[]"  data-controls="limit_title_c" id="limit_title_opt" value="OPT_LIMIT_TITLE" type="checkbox">
                    <span class="option-title">
							Truncate title to a specific number of chars
                    </span>
                    <br>
                    
		            <div id="limit_title_c" >
		              
		              <div class="field f_100" >
			               <label>
			                    Number of characters ?
			               </label>
			               
			                <input value="<?php   echo @$camp_general['cg_title_limit']   ?>" max="20000" min="0" name="cg_title_limit" id="fieldlimit2" required="required" class="ttw-range range" type="range">
			               
		               </div>
		               
		               <div class="field f_100" >
		               <input name="camp_options[]"    value="OPT_LIMIT_NO_DOT" type="checkbox">
		                    <span class="option-title">
								Do not add "..." to the end of the truncated title? 
		                    </span>
		            	
		            		</div>
		            		
		            		 <div class="field f_100" >
		               		<input name="camp_options[]"    value="OPT_LIMIT_NO_TRUN" type="checkbox">
		                    <span class="option-title">
								Remove the last truncated word (not-complete) from the truncated title?
		                    </span>
		            	
		             	</div>
		            
		            </div>
		            
               </div>
		 </div>      
		 
        <div class="field f_100" >
		               <input name="camp_options[]"    value="OPT_REMOVE_EMOJI" type="checkbox">
		                    <span class="option-title">
							 	Delete emojis from the post content (if your wp_posts table is not utf8mp4 encoded, emojis cause post insertion failure) 
		                    </span>
		            	
		</div>

		<div class="field f_100" >
		               <input name="camp_options[]"    value="OPT_REMOVE_IMAGES" type="checkbox">
		                    <span class="option-title">
							 	Remove all images from the post content 
		                    </span>
		            	
		</div>

		<!-- remove consequent <br> tags option -->
		<div class="field f_100" >
		               <input name="camp_options[]"    value="OPT_REMOVE_CONSEQ_BR" type="checkbox">
		                    <span class="option-title">
							 	Remove consequent br tags from the post content 
		                    </span>
		</div>

		<!-- Remove empty <p>...</p> tags -->
		<div class="field f_100" >
		               <input name="camp_options[]"    value="OPT_REMOVE_EMPTY_P" type="checkbox">
		                    <span class="option-title">
							 	Remove empty p tags from the post content 
		                    </span>
		</div>
		
		<div class="clear"></div>
	</div>
</div>
</div>
