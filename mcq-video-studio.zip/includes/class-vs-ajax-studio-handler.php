<?php

/**
 * AJAX Handler for Studio Sources and Data
 *
 * @package MCQ_Video_Studio
 */

if (! defined('ABSPATH')) {
	exit;
}

class VS_AJAX_Studio_Handler
{


	private static $instance = null;

	public static function get_instance()
	{
		if (self::$instance === null) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * AJAX: Fetch List of Topics/Exams (Sources)
	 */
	public function ajax_get_studio_sources()
	{
		check_ajax_referer('mcqvs_studio_nonce', 'nonce');

		if (! current_user_can('manage_options')) {
			wp_send_json_error(__('Access denied', 'mcq-video-studio'));
		}

		$type = isset($_POST['type']) ? sanitize_text_field(wp_unslash($_POST['type'])) : 'topic';

		// @Refactored 2026-02-09: Pure Custom Table Logic
		// We ignore $type (legacy distinction) and serve from wp_vs_topics
		// but we might want to filter if we add 'exam' type later.

		global $wpdb;
		$table_topics = $wpdb->prefix . 'vs_topics';
		$table_bank   = $wpdb->prefix . 'vs_mcq_bank';

		// Get all topics with question counts
		// Includes 'subject' and 'bulk_generated'
		$topics = $wpdb->get_results("
            SELECT t.id, t.name, COUNT(q.id) as count 
            FROM $table_topics t 
            LEFT JOIN $table_bank q ON t.id = q.topic_id 
            GROUP BY t.id
            HAVING count > 0
            ORDER BY t.name ASC
        ");

		$data = array();
		foreach ($topics as $t) {
			$data[] = array(
				'id'    => $t->id,
				'title' => $t->name . ' (' . $t->count . ')',
				'count' => $t->count,
				// Force frontend to treat as bank_topic
				'type'  => 'bank_topic'
			);
		}

		wp_send_json_success($data);
	}

	/**
	 * AJAX: Fetch Questions for a specific Topic/Exam
	 */
	public function ajax_get_studio_data()
	{
		error_log('MCQVS: ajax_get_studio_data triggered');
		check_ajax_referer('mcqvs_studio_nonce', 'nonce');

		if (! current_user_can('manage_options')) {
			wp_send_json_error(__('Access denied', 'mcq-video-studio'));
		}

		$id   = isset($_POST['id']) ? absint($_POST['id']) : 0;
		$type = isset($_POST['type']) ? sanitize_text_field(wp_unslash($_POST['type'])) : '';

		if (empty($id)) {
			wp_send_json_error(__('Missing source ID', 'mcq-video-studio'));
		}

		// @Refactored 2026-02-09: Repository Only
		if (! class_exists('VS_MCQ_Repository')) {
			wp_send_json_error('Repository missing');
		}

		$repo = new VS_MCQ_Repository();

		$limit  = isset($_POST['limit']) ? absint($_POST['limit']) : 10;
		$offset = isset($_POST['offset']) ? absint($_POST['offset']) : 0;

		// Fetch questions
		$results = $repo->find(array(
			'topic_id' => $id,
			'limit'    => $limit,
			'offset'   => $offset
		));

		// Transform to Studio Format
		$questions = array();
		foreach ($results as $row) {
			$questions[] = array(
				'id'       => $row['id'],
				'question' => $row['question_text'],
				// Decode JSON options
				'options'  => json_decode($row['options']),
				'correct'  => intval($row['correct_index']),
				'answer'   => '', // Legacy compat
				'background' => 'gradient'
			);
		}

		// Fetch Topic Name for Title
		$topic_row = $repo->get_topic($id);
		$title = $topic_row ? $topic_row['name'] : 'Bank Quiz';

		wp_send_json_success(array(
			'questions' => $questions,
			'title'     => $title
		));
	}
}
