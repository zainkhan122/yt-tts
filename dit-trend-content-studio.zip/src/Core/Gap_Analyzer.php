<?php

/**
 * Gap Analyzer & Win Strategy Generator
 *
 * Scrapes content and uses AI to generate a winning content strategy
 * that directly maps to the Briefing Room's input fields.
 *
 * @package DIT_TrendStudio\Core
 * @since 1.8.0
 */

namespace DIT\TrendStudio\Core;

use DIT\TrendStudio\Contracts\AIProviderInterface;
use DIT\TrendStudio\Infrastructure\Logger;

if (!defined('ABSPATH')) {
    exit;
}

class Gap_Analyzer
{
    /** @var AIProviderInterface */
    private $ai_client;

    /** @var Logger */
    private $logger;

    public function __construct(AIProviderInterface $ai_client, Logger $logger)
    {
        $this->ai_client = $ai_client;
        $this->logger = $logger;
    }

    /**
     * Analyze content (URL or Text) and return a Win Strategy.
     *
     * @param string $input       The content or URL to analyze.
     * @param string $source_type 'url' or 'text'.
     * @param string $mode        'competitor' (Beat them) or 'brand' (Enhance them).
     * @return array JSON-compatible array with strategy fields.
     * @throws \Exception On failure.
     */
    public function analyze(string $input, string $source_type = 'url', string $mode = 'competitor'): array
    {
        $this->logger->info("Starting Analysis", ['type' => $source_type, 'mode' => $mode]);

        $content = $input;

        // 1. Fetch content if URL
        if ($source_type === 'url') {
            $content = $this->fetch_url_content($input);
            if (empty($content)) {
                throw new \Exception(__('Could not retrieve content from URL. Please check the link or paste the text manually.', 'dit-trend-content-studio'));
            }
        }

        // 2. Truncate for efficiency (Gemini 2.5 Flash context is large, but let's stay sane)
        // Keep first 50,000 characters (approx 10-12k words)
        if (strlen($content) > 50000) {
            $content = substr($content, 0, 50000) . '... [TRUNCATED]';
        }

        // 3. Build Analysis Prompt based on Mode
        if ($mode === 'brand') {
            $prompt = $this->build_brand_enhancement_prompt($content);
        } else {
            $prompt = $this->build_competitor_gap_prompt($content);
        }

        // 4. Call AI
        try {
            $response = $this->ai_client->generateCustomJson($prompt);

            // @MODIFIED 2026-01-14 - Handle new response structure with debug data
            $strategy_data = $response['data'] ?? $response; // Fallback if old structure
            $validated = $this->validate_strategy($strategy_data);

            // Merge debug info if present
            if (isset($response['raw_request'])) {
                $validated['raw_request'] = $response['raw_request'];
            }
            if (isset($response['raw_response'])) {
                $validated['raw_response'] = $response['raw_response'];
            }

            return $validated;
        } catch (\Exception $e) {
            $this->logger->error("Gap Analysis failed: " . $e->getMessage());
            throw new \Exception(__('Analysis failed: ', 'dit-trend-content-studio') . $e->getMessage());
        }
    }

    /**
     * Fetch and clean content from a URL server-side.
     *
     * @param string $url
     * @return string Raw text content
     */
    private function fetch_url_content(string $url): string
    {
        // Basic validation
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            return '';
        }

        $response = wp_remote_get($url, [
            'timeout' => 60, // Increased timeout
            'sslverify' => apply_filters('tcs_fetch_url_ssl_verify', true),
            'user-agent' => 'Mozilla/5.0 (compatible; TrendStudioBot/1.0; +https://example.com)',
        ]);

        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
            return '';
        }

        $html = wp_remote_retrieve_body($response);

        // Basic clean-up: remove script/style tags before stripping tags
        $html = preg_replace('/<script\b[^>]*>(.*?)<\/script>/is', '', $html);
        $html = preg_replace('/<style\b[^>]*>(.*?)<\/style>/is', '', $html);

        // Strip tags to get raw text
        $text = wp_strip_all_tags($html);

        // Collapse whitespace
        $text = preg_replace('/\s+/', ' ', $text);

        return trim($text);
    }

    /**
     * Validate and sanitize the strategy response.
     * Ensures keys match what the frontend expects.
     *
     * @param array $data
     * @return array
     */
    private function validate_strategy(array $data): array
    {
        return [
            'topic'             => sanitize_text_field($data['topic'] ?? ''),
            'unique_angle'      => sanitize_textarea_field($data['unique_angle'] ?? ''),
            'focus_keyword'     => sanitize_text_field($data['focus_keyword'] ?? ''),
            // Ensure these match the <select> values in Briefing Room
            'editorial_angle'   => $this->match_allowed_value($data['editorial_angle'] ?? '', ['neutral', 'skeptical', 'enthusiastic', 'contrarian', 'data_driven'], 'neutral'),
            'search_intent'     => $this->match_allowed_value($data['search_intent'] ?? '', ['mixed', 'informational', 'commercial', 'news'], 'mixed'),
            'article_structure' => $this->match_allowed_value($data['article_structure'] ?? '', ['deep_dive', 'listicle', 'news_brief', 'comparison'], 'deep_dive'),
            // Notes field combines the strategic rationale
            'notes'             => sanitize_textarea_field($data['notes'] ?? ''),
        ];
    }

    /**
     * Helper to enforce enum-like values for dropdowns.
     */
    private function match_allowed_value($value, $allowed, $default)
    {
        return in_array($value, $allowed) ? $value : $default;
    }

    /**
     * Construct the Prompt for 'Competitor Audit' Mode (Skyscraper)
     */
    private function build_competitor_gap_prompt(string $content): string
    {
        return $this->build_analysis_prompt($content); // Reuse existing logic
    }

    /**
     * [LEGACY Wrapper] Kept for compatibility.
     */
    private function build_analysis_prompt(string $content): string
    {
        return <<<PROMPT
# Role
You are an Expert Content Strategist and SEO Auditor. Your job is to analyze the competitor content below and devise a "Win Strategy" to create a superior piece of content (The Skyscraper Technique).

# Input Content
"""
{$content}
"""

# Analysis Task
1. Identify the core topic and primary intent.
2. Find gaps in E-E-A-T (Expertise, Experience, Authoritativeness, Trustworthiness).
3. Identify missed angles, lack of data, or boring narratives.
4. Formulate a "Unique Angle" that makes our version significantly better.

# Output Requirements
Return a JSON object that maps directly to our CMS configuration. Use these EXACT keys and values:

```json
{
  "topic": "A refined, engaging topic title based on the input",
  "focus_keyword": "The likely primary SEO keyword",
  "unique_angle": "2-3 sentences explaining EXACTLY how our version will be different. (e.g., 'Instead of just listing X, we will analyze Y using data from Z...')",
  
  "editorial_angle": "Choose ONE: ['neutral', 'skeptical', 'enthusiastic', 'contrarian', 'data_driven']",
  "search_intent": "Choose ONE: ['mixed', 'informational', 'commercial', 'news']",
  "article_structure": "Choose ONE: ['deep_dive', 'listicle', 'news_brief', 'comparison']",

  "notes": "A bulleted summary of: \\n- Weaknesses in original content\\n- Opportunities for us\\n- specific data/sources we should look for.\\n\\n## ASSETS TO REUSE:\\n[List any <img>, <video>, <iframe>, or <a href> tags found in the input, EXACTLY as they appear. Do not change attributes.]"
}
```

# Selection Logic
* **editorial_angle**:
  * Use 'contrarian' if the input is generic/cliché.
  * Use 'data_driven' if the input lacks evidence.
  * Use 'skeptical' if the input makes bold, unverified claims.

* **article_structure**:
  * If input is a list, suggest 'deep_dive' to add depth, or 'comparison' to add value.
PROMPT;
    }

    /**
     * [NEW] The "Brand Enhancement" Prompt.
     * Focuses on polishing, adding depth, and preserving specific entities.
     */
    private function build_brand_enhancement_prompt(string $content): string
    {
        return <<<PROMPT
# Role
You are a Senior Luxury Brand Editor. The user has provided a draft or press release for a specific brand/collection. 
Your goal is NOT to change the facts, but to elevate the narrative, add industry authority, and "editorial gloss" while keeping the brand as the hero.

# Input Content (Source of Truth)
"""
{$content}
"""

# Task: Brand Enhancement Strategy
1. **Fact Extraction**: Identify specific product names, materials (e.g., "Mother of Pearl"), and claims. These MUST be preserved.
2. **Thematic Elevation**: Identify the core theme (e.g., "Quiet Luxury", "Handloom Heritage").
3. **Add Depth**: How can we validate this brand's approach using broader industry trends? (e.g., If they mention handloom, explain *why* handloom is premium in the current global market).

# Output Requirements
Return a JSON object for our content brief system:

```json
{
  "topic": "A refined, editorial headline based on the input (e.g., 'Why [Brand] is Redefining Winter...')",
  "focus_keyword": "The primary brand or collection keyword",
  "unique_angle": "The specific narrative hook that connects the Brand to broader culture/trends. (Do not invent facts, just context).",
  
  "editorial_angle": "enthusiastic",
  "search_intent": "commercial",
  "article_structure": "deep_dive",

  "notes": "Instructions for the writer:\\n- KEY BRAND FACTS: [List specific details to keep]\\n- CONTEXT TO ADD: [Suggest data/trends that validate the brand]\\n- TONE: Sophisticated, authoritative.\\n\\n## ASSETS TO REUSE:\\n[List any <img>, <video>, <iframe>, or <a href> tags found in the input, EXACTLY as they appear. Do not change attributes.]"
}
```

# Selection Logic
* **editorial_angle**: Usually 'enthusiastic' or 'neutral'.
* **search_intent**: Usually 'commercial' or 'news'.
PROMPT;
    }
}
