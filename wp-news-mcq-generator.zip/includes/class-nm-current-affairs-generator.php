<?php

/**
 * Class NM_Current_Affairs_Generator
 *
 * Manages the generation of MCQs from current affairs news feeds.
 *
 * @package News_MCQ_Generator
 * @version 2.2 (FIXED) - Re-implemented Feeder/Worker pattern
 *
 * @MODIFIED: Restored V23's Feeder/Worker architecture to fix rate limiting.
 * @MODIFIED: run_generation_cron() is now the FEFDER (queues articles).
 * @MODIFIED: Added run_worker_cron() as the WORKER (processes 1 article).
 * @MODIFIED: Removed sleep(7) from process_sources() as worker interval is now the rate limit.
 */

if (! defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

class NM_Current_Affairs_Generator
{


	/**
	 * Option key for storing generation status.
	 *
	 * @var string
	 */
	private static $status_option_key = 'nm_ca_generation_status';

	/**
	 * Option key for storing the last check timestamp.
	 *
	 * @var string
	 */
	private static $last_check_option_key = 'nm_ca_last_check_timestamp';

	/**
	 * Transient key for the article processing queue.
	 *
	 * @var string
	 */
	private static $queue_transient_key = 'nm_ca_generation_queue';

	/**
	 * Transient key for caching processed article fingerprints.
	 *
	 * @var string
	 */
	private static $processed_transient_key = 'nm_ca_processed_articles';

	/**
	 * Transient key for locking the queue worker process.
	 *
	 * @var string
	 */
	private static $worker_lock_key = 'nm_ca_queue_lock';
	/**
	 * Hard safety cap for the queue size. If exceeded, the worker will reset the queue.
	 * You can override this via the 'nm_ca_max_queue_size' filter.
	 *
	 * @var int
	 */
	private static $max_queue_size = 10;


	/**
	 * Initializes the hooks for the current affairs generator.
	 */
	public static function init()
	{
		// Hooks are now registered in NM_Cron_Manager
		// add_action('nm_generate_current_affairs_mcq_cron', [__CLASS__, 'run_generation_cron']); // This is the Feeder
		// add_action('nm_ca_queue_worker_cron', [__CLASS__, 'run_worker_cron']); // This is the Worker
	}

	/**
	 * CRON JOB 1: THE FEEDER
	 * Executes the generation process via WP-Cron.
	 * This function now ONLY queues articles. It does not call the API.
	 */
	public static function run_generation_cron()
	{
		if (self::is_generation_in_progress()) {
			return;
		}

		self::set_generation_status('running');
		$start_time = time();

		$generation_queue = get_transient(self::$queue_transient_key) ?: array();
		$queued_count     = 0;
		$skipped_cached   = 0;

		try {
			$pak_enabled = get_option('nm_current_affairs_enabled', 0);
			$int_enabled = get_option('nm_current_affairs_enabled', 0);
			$pak_limit   = (int) (get_option('nm_current_affairs_pakistan_count', 1));
			$int_limit   = (int) (get_option('nm_current_affairs_intl_count', 1));

			// 1. Process Pakistan Sources
			if ($pak_enabled && $pak_limit > 0) {
				$pak_sources = self::get_sources('pakistan');
				if (! empty($pak_sources)) {
					$articles  = self::fetch_and_filter_articles($pak_sources, $pak_limit * 5);
					$added_pak = 0;
					foreach ($articles as $article) {
						if ($added_pak >= $pak_limit) {
							break;
						}
						$fingerprint = self::get_article_fingerprint($article);
						if (! self::is_article_processed($fingerprint) && ! isset($generation_queue[$fingerprint])) {
							$article['intended_topic']        = 'Pakistan Current Affairs';
							$generation_queue[$fingerprint] = $article;
							++$queued_count;
							++$added_pak;
						} else {
							++$skipped_cached;
						}
					}
				}
			}

			// 2. Process International Sources
			if ($int_enabled && $int_limit > 0) {
				$int_sources = self::get_sources('international');
				if (! empty($int_sources)) {
					$articles   = self::fetch_and_filter_articles($int_sources, $int_limit * 5);
					$added_intl = 0;
					foreach ($articles as $article) {
						if ($added_intl >= $int_limit) {
							break;
						}
						$fingerprint = self::get_article_fingerprint($article);
						if (! self::is_article_processed($fingerprint) && ! isset($generation_queue[$fingerprint])) {
							$article['intended_topic']        = 'International Current Affairs';
							$generation_queue[$fingerprint] = $article;
							++$queued_count;
							++$added_intl;
						} else {
							++$skipped_cached;
						}
					}
				}
			}
			// 3. Enforce max queue size before saving
			$configured_max = (int) get_option('nm_current_affairs_max_queue', self::$max_queue_size);
			if ($configured_max <= 0) {
				$configured_max = self::$max_queue_size;
			}
			$max_queue_size = apply_filters('nm_ca_max_queue_size', $configured_max);

			if (count($generation_queue) > $max_queue_size) {
				$original         = count($generation_queue);
				$generation_queue = array_slice($generation_queue, 0, $max_queue_size, true);
				error_log(
					"⚠️ [CA Feeder] Trimmed queue from {$original} to {$max_queue_size} items to respect max queue size."
				);
			}

			// 4. Save the (possibly trimmed) queue
			set_transient(self::$queue_transient_key, $generation_queue, 2 * HOUR_IN_SECONDS);
			$elapsed = time() - $start_time;
			error_log(
				"News MCQ Feeder: Queuing finished in {$elapsed}s. Added {$queued_count} new articles. " .
					'Total in queue: ' . count($generation_queue) . ". Skipped {$skipped_cached} processed articles."
			);
		} catch (Exception $e) {
		}

		self::set_generation_status('idle');
		update_option(self::$last_check_option_key, time());
	}

	/**
	 * CRON JOB 2: THE WORKER
	 * Processes one item from the generation queue.
	 */
	public static function run_worker_cron()
	{
		$released = false;

		// Register a shutdown function to release the lock in case of fatal errors
		register_shutdown_function(
			function () use (&$released) {
				if (! $released) {
					delete_transient(self::$worker_lock_key);
				}
			}
		);

		try {
			// Check for lock
			$lock_time = get_transient(self::$worker_lock_key);
			if ($lock_time) {
				$lock_age = time() - intval($lock_time);
				if ($lock_age > 120) { // 2 minute failsafe
					delete_transient(self::$worker_lock_key);
				} else {
					$released = true; // Mark as "clean" exit
					return;
				}
			}

			// Set lock
			set_transient(self::$worker_lock_key, time(), 120); // 2 minute lock

			// Load queue and normalize to an array
			$generation_queue = get_transient(self::$queue_transient_key);
			if (! is_array($generation_queue)) {
				$generation_queue = array();
			}

			// If queue is empty, bail out cleanly
			if (empty($generation_queue)) {
				delete_transient(self::$worker_lock_key);
				$released = true;
				return;
			}

			// Enforce hard safety cap on queue size using setting + filter
			$configured_max = (int) get_option('nm_current_affairs_max_queue', self::$max_queue_size);
			if ($configured_max <= 0) {
				$configured_max = self::$max_queue_size;
			}

			$max_queue_size = apply_filters('nm_ca_max_queue_size', $configured_max);

			if (count($generation_queue) > $max_queue_size) {
				error_log(
					'⚠️ [CA Worker] Queue size ' . count($generation_queue) .
						' exceeds max ' . $max_queue_size . '. Trimming queue to max and continuing.'
				);

				// Keep only the first $max_queue_size items (FIFO behaviour preserved)
				$generation_queue = array_slice($generation_queue, 0, $max_queue_size, true);

				// Save the trimmed queue back for transparency
				set_transient(self::$queue_transient_key, $generation_queue, 2 * HOUR_IN_SECONDS);
			}

			// At this point, we have a non-empty queue within the cap.
			// Read batch size from settings and clamp to a safe range (1–5)
			$raw_batch  = (int) get_option('nm_current_affairs_worker_batch', 1);
			$batch_size = min(5, max(1, $raw_batch));
			error_log(
				'🔄 [CA Worker] Starting queue processing... '
					. count($generation_queue)
					. ' items remaining. Batch size: '
					. $batch_size
			);
			$batch_size = min(5, max(1, $raw_batch));

			error_log(
				'🔄 [CA Worker] Starting queue processing... '
					. count($generation_queue)
					. ' items remaining. Batch size: '
					. $batch_size
			);

			// Set up detector ONCE per worker run, reuse for the whole batch
			$gemini_api_key       = NM_API_Client::get_gemini_api_key();
			$similarity_threshold = floatval(get_option('nm_similarity_threshold', 0.70));
			$detector             = class_exists('NM_Advanced_Duplicate_Detector')
				? new NM_Advanced_Duplicate_Detector($gemini_api_key, $similarity_threshold)
				: null;

			$processed_this_run = 0;
			// @FIX 9.3.3: Collect this run's created MCQs + their source articles so we can
			// generate ONE roundup article per worker run (capped daily) — the article
			// generator was previously wired only into the News-Based pipeline, which is NOT
			// the active one, so no articles were ever created.
			$batch_articles = array();
			$batch_mcqs     = array();

			// Process up to $batch_size items (FIFO)
			for ($i = 0; $i < $batch_size; $i++) {
				if (empty($generation_queue)) {
					break;
				}

				// Get one item
				$fingerprint = array_key_first($generation_queue);
				$article     = $generation_queue[$fingerprint];
				unset($generation_queue[$fingerprint]);

				// Process this article
				$result = self::generate_mcq_from_article(
					$article,
					$article['intended_topic'] ?? 'Current Affairs',
					$detector
				);

				if (isset($result['success']) && $result['success']) {
					error_log(
						"✅ [CA Worker] Successfully generated MCQ {$result['mcq_id']} for topic '{$result['topic']}'."
					);
					self::mark_article_processed($fingerprint, 'created', $result['mcq_id']);

					// @FIX 9.3.3: Buffer this source article + created MCQ for the roundup
					// article (generated once after the batch, capped daily).
					$batch_articles[] = array(
						'title'       => $article['title'] ?? '',
						'description' => $article['description'] ?? '',
						'url'         => $article['link'] ?? '',
						'source_name' => $article['source'] ?? '',
						'category'    => $article['intended_topic'] ?? 'Current Affairs',
					);
					if (isset($result['mcq_id'])) {
						$batch_mcqs[] = array(
							'post_id'   => $result['mcq_id'],
							'question'  => get_the_title( $result['mcq_id'] ),
							'topic'     => $result['topic'] ?? ( $article['intended_topic'] ?? 'Current Affairs' ),
							'subtopic'  => '',
							'permalink' => get_permalink( $result['mcq_id'] ),
						);
					}
				} elseif (isset($result['duplicate']) && $result['duplicate']) {
					$method = $result['method'] ?? 'unknown';
					$title  = $article['title'] ?? '(no title)';
					error_log(
						"⏭️ [CA Worker] Skipped duplicate article (Method: {$method}): {$title}"
					);
					self::mark_article_processed($fingerprint, 'duplicate');
				} else {
					$error = $result['error'] ?? 'Unknown error';
					$title = $article['title'] ?? '(no title)';
					error_log(
						"❌ [CA Worker] Failed to generate MCQ (Error: {$error}): {$title}"
					);
					self::mark_article_processed($fingerprint, 'rejected');
				}

				++$processed_this_run;
			}

			// Save the modified (smaller) queue
			set_transient(self::$queue_transient_key, $generation_queue, 2 * HOUR_IN_SECONDS);

			error_log(
				'ℹ️ [CA Worker] Processed '
					. $processed_this_run
					. ' item(s) this run. Remaining in queue: '
					. count($generation_queue)
					. '.'
			);

			// @FIX 9.4.1: Per-batch article generation is DISABLED. The old approach created
			// one tiny article per worker batch (1–2 MCQs), not a real roundup. Roundups are
			// now generated ONCE per day by the nm_daily_roundup_cron (end of day), covering
			// ALL MCQs published that day. The $batch_* data is still collected above for
			// future/manual use but is no longer turned into per-batch posts.
		} catch (Exception $e) {
		}

		// Release lock
		delete_transient(self::$worker_lock_key);
		$released = true;
	}

	/**
	 * Processes a list of news sources to generate MCQs.
	 * (This function is no longer called by the cron, but by the worker)
	 */
	private static function process_sources($sources, $topic, $limit, $detector)
	{
		// This function is now effectively deprecated by the Feeder/Worker model,
		// but we'll keep its logic inside run_worker_cron()
		return 0;
	}

	/**
	 * Fetches and filters articles from a list of source keys.
	 */
	private static function fetch_and_filter_articles($sources, $limit)
	{
		if (! class_exists('NM_Advanced_News_Sources')) {
			return array();
		}

		$all_articles = array();
		$seen_links   = array();

		foreach ($sources as $source_key) {
			$articles = NM_Advanced_News_Sources::fetch_articles($source_key, $limit); // Fetch more per source

			foreach ($articles as $article) {
				if (isset($article['link']) && ! isset($seen_links[$article['link']])) {
					if (self::is_article_relevant($article)) {
						$all_articles[]                 = $article;
						$seen_links[$article['link']] = true;
					}
				}
			}
		}

		usort(
			$all_articles,
			function ($a, $b) {
				$a_date = isset($a['date']) ? strtotime($a['date']) : 0;
				$b_date = isset($b['date']) ? strtotime($b['date']) : 0;
				return $b_date <=> $a_date;
			}
		);

		return $all_articles;
	}

	/**
	 * Checks if an article is relevant based on keyword filtering.
	 */
	private static function is_article_relevant($article)
	{
		$settings        = get_option('nm_admin_settings', array());
		$reject_keywords = $settings['reject_keywords'] ?? '';
		$prefer_keywords = $settings['prefer_keywords'] ?? '';

		$text_to_check = (isset($article['title']) ? $article['title'] : '') . ' ' . (isset($article['description']) ? $article['description'] : '');
		$text_to_check = strtolower($text_to_check);

		if (! empty($reject_keywords)) {
			$reject_list = array_map('trim', explode(',', $reject_keywords));
			foreach ($reject_list as $keyword) {
				if (! empty($keyword) && strpos($text_to_check, strtolower($keyword)) !== false) {
					return false;
				}
			}
		}

		if (! empty($prefer_keywords)) {
			$prefer_list     = array_map('trim', explode(',', $prefer_keywords));
			$found_preferred = false;
			foreach ($prefer_list as $keyword) {
				if (! empty($keyword) && strpos($text_to_check, strtolower($keyword)) !== false) {
					$found_preferred = true;
					break;
				}
			}
			if (! $found_preferred) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Generates a single MCQ from a given article.
	 */
	private static function generate_mcq_from_article($article, $intended_topic, $detector)
	{
		$gemini_api_key = NM_API_Client::get_gemini_api_key();
		if (empty($gemini_api_key)) {
			return array(
				'success'   => false,
				'duplicate' => false,
				'error'     => 'Gemini API key missing',
			);
		}

		// ✅ START MODIFICATION: Scrape Full Article Text

		$article_url  = $article['link'] ?? '';
		$article_text = '';

		if (! empty($article_url)) {
			// Call our new helper function
			$article_text = self::scrape_and_parse_article($article_url);
		}

		// Fallback to title/description if scraping fails or URL is empty
		if (empty($article_text)) {
			$title        = isset($article['title']) ? (string) $article['title'] : '';
			$description  = isset($article['description']) ? (string) $article['description'] : '';
			$article_text = $title . ".\n\n" . $description;

			if (empty(trim($article_text))) {
				return array(
					'success'   => false,
					'duplicate' => false,
					'error'     => 'Article title/description empty and scraping failed.',
				);
			}
		}
		// ✅ END MODIFICATION

		if (! class_exists('NM_API_Client')) {
			return array(
				'success'   => false,
				'duplicate' => false,
				'error'     => 'Core function not found',
			);
		}
		// ✅ GET THE NEW SETTING
		$num_questions = (int) get_option('nm_ca_questions_per_article', 3);

		// ✅ PASS THE SETTING TO THE API CLIENT
		$api_response = NM_API_Client::get_instance()->generate_mcq_with_categorization($article_text, $num_questions);

		// ✅ START MODIFICATION: Handle the new array-based response

		// Check for API failure or an empty 'questions' array
		if (! $api_response['success'] || ! isset($api_response['data']['questions']) || empty($api_response['data']['questions'])) {
			return array(
				'success'   => false,
				'duplicate' => false,
				'error'     => $api_response['error'] ?? 'AI rejected or returned empty array',
			);
		}

		$questions_from_api = $api_response['data']['questions'];
		$ai_decided_topic   = $api_response['data']['topic'] ?? $intended_topic; // Get the single topic for the whole batch

		$generated_count = 0;
		$duplicate_count = 0;
		$last_method     = 'unknown';
		$post_id         = 0; // Keep track of the last post ID for the log

		// Loop through each question returned by the AI
		foreach ($questions_from_api as $mcq_data) {

			if (empty($mcq_data['question'])) {
				continue; // Skip if a question in the batch is empty
			}

			$new_question_text = $mcq_data['question'];

			// We run the duplicate check for *each* question in the batch
			if ($detector) {
				$duplicate_check = $detector->check_duplicate($new_question_text, $ai_decided_topic);
				if (isset($duplicate_check['is_duplicate']) && $duplicate_check['is_duplicate']) {
					++$duplicate_count;
					$last_method = $duplicate_check['method'] ?? 'text_match';
					continue; // Skip this question and move to the next in the batch
				}
			}

			// If not a duplicate, save it
			if (! class_exists('NM_Post_Type_Manager') || ! method_exists('NM_Post_Type_Manager', 'save_mcq_post_unified')) {
				return array(
					'success'   => false,
					'duplicate' => false,
					'error'     => 'NM_Post_Type_Manager::save_mcq_post_unified not found',
				);
			}

			$save_params = array(
				'topic'   => $ai_decided_topic,
				'api_key' => $gemini_api_key,
			);

			// Check Global Smart Schedule Setting
			$smart_schedule_global = get_option('nm_scheduler_enabled', 0);
			if ($smart_schedule_global) {
				$save_params['post_status'] = 'smart_schedule';
			}

			$post_id = NM_Post_Type_Manager::save_mcq_post_unified($mcq_data, $save_params);

			if ($post_id && ! is_wp_error($post_id)) {
				++$generated_count;
				update_post_meta($post_id, 'mcq_source', $article['source'] ?? 'Unknown');
				update_post_meta($post_id, 'mcq_source_url', $article['link'] ?? '');

				$topic_assignment_result = self::assign_mcq_to_topic_taxonomy($post_id, $ai_decided_topic);
				if (! $topic_assignment_result['success']) {
				}

				// Embedding is now handled by save_mcq_post_unified, no need to do it here.

				if (class_exists('NM_Generation_Logger')) {
					NM_Generation_Logger::nm_log_activity(
						"Created MCQ from {$article['source']}",
						'success',
						array(
							'source_type' => 'news',
							'source_ref'  => $ai_decided_topic,
							'mcq_id'      => $post_id,
							'question'    => $new_question_text,
						)
					);
				}
			}
		} // End foreach loop

		// --- Return a summary of the batch ---
		if ($generated_count > 0) {
			// At least one question was generated
			return array(
				'success'   => true,
				'duplicate' => ($duplicate_count > 0),
				'mcq_id'    => $post_id,
				'topic'     => $ai_decided_topic,
				'generated' => $generated_count,
			);
		} elseif ($duplicate_count > 0) {
			// All questions in the batch were duplicates
			return array(
				'success'   => false,
				'duplicate' => true,
				'method'    => $last_method,
			);
		} else {
			// No questions generated, no duplicates found (e.g., all were empty)
			return array(
				'success'   => false,
				'duplicate' => false,
				'error'     => 'AI returned a batch, but all questions were invalid.',
			);
		}
		// ✅ END MODIFICATION
	}

	/**
	 * Assigns a post to a 'topic' taxonomy term, creating the term if it doesn't exist.
	 */
	private static function assign_mcq_to_topic_taxonomy($post_id, $topic_name)
	{
		if (empty($topic_name)) {
			return array(
				'success' => false,
				'error'   => 'Topic name was empty',
			);
		}
		$taxonomy = 'topic';
		$term     = get_term_by('name', $topic_name, $taxonomy);
		if ($term === false) {
			$new_term = wp_insert_term($topic_name, $taxonomy);
			if (is_wp_error($new_term)) {
				return array(
					'success' => false,
					'error'   => $new_term->get_error_message(),
				);
			}
			$term_id = (int) $new_term['term_id'];
		} else {
			$term_id = (int) $term->term_id;
		}
		$result = wp_set_post_terms($post_id, array($term_id), $taxonomy);
		if (is_wp_error($result)) {
			return array(
				'success' => false,
				'error'   => $result->get_error_message(),
			);
		}
		return array(
			'success' => true,
			'term_id' => $term_id,
		);
	}

	/**
	 * Gets the list of RSS feed sources for a specific group.
	 */
	private static function get_sources($group)
	{
		if (! class_exists('NM_Advanced_News_Sources')) {
			return array();
		}
		$all_sources         = NM_Advanced_News_Sources::get_sources();
		$enabled_source_keys = get_option('nm_enabled_news_sources', array_keys($all_sources));
		$group_sources       = array();

		foreach ($enabled_source_keys as $source_key) {
			if (isset($all_sources[$source_key])) {
				$source          = $all_sources[$source_key];
				$source_category = $source['category'] ?? 'general'; // Default to 'general' if not set

				// ✅ START FIX: Make 'international' a "catch-all"
				if ($group === 'pakistan') {
					// Pakistan group only matches 'pakistan'
					if ($source_category === 'pakistan') {
						$group_sources[] = $source_key;
					}
				} elseif ($group === 'international') {
					// International group matches EVERYTHING EXCEPT 'pakistan'
					if ($source_category !== 'pakistan') {
						$group_sources[] = $source_key;
					}
				}
				// ✅ END FIX
			}
		}
		return $group_sources;
	}

	/**
	 * Checks if the generation process is already running.
	 */
	private static function is_generation_in_progress()
	{
		$status = get_option(self::$status_option_key, 'idle');
		if ($status === 'running') {
			$last_check = (int) get_option(self::$last_check_option_key, 0);
			if ((time() - $last_check) > 900) {
				self::set_generation_status('idle');
				return false;
			}
			return true;
		}
		return false;
	}

	/**
	 * Sets the generation status.
	 */
	private static function set_generation_status($status)
	{
		update_option(self::$status_option_key, $status);
		if ($status === 'running') {
			update_option(self::$last_check_option_key, time());
		}
	}

	// ===================================================================
	// HELPER FUNCTIONS FOR FEEDER/WORKER
	// ===================================================================

	private static function get_article_fingerprint($article)
	{
		$title       = isset($article['title']) ? (string) $article['title'] : '';
		$description = isset($article['description']) ? (string) $article['description'] : '';
		if (empty($title) && empty($description)) {
			return md5(uniqid());
		}
		$text = strtolower(trim($title) . ' ' . strtolower(substr(trim($description), 0, 150)));
		$text = preg_replace('/\s+/', ' ', $text);
		$text = preg_replace('/[^a-z0-9 ]/', '', $text);
		return md5($text);
	}

	private static function is_article_processed($fingerprint)
	{
		$cache = get_transient(self::$processed_transient_key);
		if (! $cache || ! is_array($cache)) {
			return false;
		}
		if (isset($cache[$fingerprint])) {
			$entry = $cache[$fingerprint];
			// Check if entry is still valid (e.g., expires after 25 hours)
			if (isset($entry['expires']) && $entry['expires'] > current_time('timestamp')) {
				return array(
					'processed' => true,
					'reason'    => $entry['reason'],
					'mcq_id'    => $entry['mcq_id'] ?? null,
					'age'       => human_time_diff($entry['timestamp'], current_time('timestamp')),
				);
			}
		}
		return false;
	}

	private static function mark_article_processed($fingerprint, $reason = 'created', $mcq_id = null)
	{
		$cache = get_transient(self::$processed_transient_key);
		if (! $cache || ! is_array($cache)) {
			$cache = array();
		}
		$cache[$fingerprint] = array(
			'timestamp' => current_time('timestamp'),
			'reason'    => $reason,
			'mcq_id'    => $mcq_id,
			'expires'   => current_time('timestamp') + (25 * HOUR_IN_SECONDS), // Cache for 25 hours
		);

		// Clean up expired entries from cache
		$now = current_time('timestamp');
		foreach ($cache as $fp => $data) {
			if (isset($data['expires']) && $data['expires'] < $now) {
				unset($cache[$fp]);
			}
		}

		set_transient(self::$processed_transient_key, $cache, 25 * HOUR_IN_SECONDS);
	}

	// ===================================================================
	// ✅ START NEW: ScraperAPI + Readability Logic
	// ===================================================================

	/**
	 * Scrapes a URL using ScraperAPI and then parses the HTML to extract clean article text.
	 * This mimics the "Readability" algorithm used by `wp-automatic`.
	 *
	 * @param string $url The article URL to scrape.
	 * @return string|false Clean article text on success, false on failure.
	 */
	private static function scrape_and_parse_article($url)
	{
		$api_client = NM_API_Client::get_instance();

		// 1. Scrape the raw HTML using the API client
		$raw_html = $api_client->scrape_article_text($url);

		if (empty($raw_html)) {
			return false;
		}

		// 2. Parse the HTML to find the main content
		$doc = new DOMDocument();
		// Suppress warnings for malformed HTML (common on news sites)
		@$doc->loadHTML('<?xml encoding="utf-8" ?>' . $raw_html);

		if (! $doc) {
			return false;
		}

		$xpath = new DOMXPath($doc);

		// Remove common clutter elements before scoring
		$clutter_selectors = array(
			'//script',
			'//style',
			'//nav',
			'//footer',
			'//header',
			'//*[contains(@class, "comment")]',
			'//*[contains(@id, "comment")]',
			'//*[contains(@class, "sidebar")]',
			'//*[contains(@id, "sidebar")]',
			'//*[contains(@class, "footer")]',
			'//*[contains(@id, "footer")]',
			'//*[contains(@class, "header")]',
			'//*[contains(@id, "header")]',
			'//*[contains(@class, "menu")]',
			'//*[contains(@id, "menu")]',
			'//*[contains(@class, "ad")]',
			'//*[contains(@id, "ad")]',
			'//*[contains(@class, "share")]',
		);

		foreach ($clutter_selectors as $selector) {
			$nodes = $xpath->query($selector);
			if ($nodes) {
				foreach ($nodes as $node) {
					if ($node->parentNode) {
						$node->parentNode->removeChild($node);
					}
				}
			}
		}

		// Find the element with the most <p> tags (simplified Readability)
		$body = $doc->getElementsByTagName('body')->item(0);
		if (! $body) {
			return false;
		}

		$best_element = null;
		$max_score    = -100;

		$candidates = array();
		foreach (array('article', 'main', 'section', 'div') as $tag) {
			$elements = $body->getElementsByTagName($tag);
			foreach ($elements as $el) {
				$candidates[] = $el;
			}
		}

		foreach ($candidates as $node) {
			$score  = 0;
			$p_tags = $node->getElementsByTagName('p');
			$score += $p_tags->length * 2; // High score for paragraphs

			$text_length = strlen(trim($node->nodeValue));
			if ($text_length > 100) {
				$score += $text_length / 100; // Bonus for text length
			}

			// Penalize common clutter classes/IDs
			$class = $node->getAttribute('class');
			$id    = $node->getAttribute('id');
			if (preg_match('/(nav|menu|sidebar|footer|header|ad|comment|share|related|popup)/i', $class . ' ' . $id)) {
				$score -= 50;
			}

			if ($score > $max_score) {
				$max_score    = $score;
				$best_element = $node;
			}
		}

		if ($best_element) {
			// We found a winner, extract its text content
			$text = trim($best_element->nodeValue);
			// Clean up extra whitespace
			$text = preg_replace('/\s\s+/', "\n\n", $text); // Replace multiple spaces/newlines with double newline

			// ✅ START MODIFICATION: Enforce 7,000 character limit (as you suggested)
			$max_chars = 7000;
			if (mb_strlen($text) > $max_chars) {
				// Use mb_substr to safely handle multi-byte characters
				$text = mb_substr($text, 0, $max_chars) . '... [Content truncated]';
			}
			// ✅ END MODIFICATION

			// FREE MEMORY (PHP GC has trouble with cyclic DOM objects)
			$doc = null;
			$xpath = null;
			unset($doc, $xpath, $candidates, $best_element, $body);

			return $text;
		}

		$doc = null;
		$xpath = null;
		unset($doc, $xpath, $candidates, $best_element, $body);

		return false;
	}
	// ===================================================================
	// ✅ END NEW: ScraperAPI + Readability Logic
	// ===================================================================
}
