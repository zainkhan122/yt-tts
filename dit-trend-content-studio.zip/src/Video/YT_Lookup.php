<?php
/**
 * DIT Video Module — YT_Lookup
 *
 * Discovers the YouTube URL of a shared Short by searching the channel for the
 * generated title. This is robust because Buffer's publish response does NOT
 * reliably return the final YouTube URL for uploads. We search our own channel
 * (channel ID from settings) via the YouTube Data API for a video whose title
 * matches the one we generated, then return its watch URL / embed URL.
 *
 * Requires: a YouTube Data API key + the channel ID (both configurable).
 *
 * @package DIT\TrendStudio\Video
 */

namespace DIT\TrendStudio\Video;

use DIT\TrendStudio\Infrastructure\Logger;

if (!defined('ABSPATH')) {
    exit;
}

class YT_Lookup
{
    /** @var Settings */
    protected $settings;

    /** @var Logger */
    protected $logger;

    public function __construct(Settings $settings, Logger $logger)
    {
        $this->settings = $settings;
        $this->logger   = $logger;
    }

    public function api_key(): string
    {
        $k = (string) $this->settings->get('yt_api_key', '');
        return $k !== '' ? $k : (string) get_option('dit_ts_google_search_api_key', '');
    }

    public function channel_id(): string
    {
        return (string) $this->settings->get('yt_channel_id', '');
    }

    /**
     * Search the channel for a video by (fuzzy) title. Returns watch URL or ''.
     *
     * @param string $title The title we generated for the Short.
     */
    public function find_video_by_title(string $title): string
    {
        $key  = $this->api_key();
        $chan = $this->channel_id();
        if ($key === '' || $chan === '' || $title === '') {
            return '';
        }
        // Exact-ish match first, then broad.
        foreach (array($title, $this->slugify($title)) as $q) {
            $url = $this->search($key, $chan, $q);
            if ($url !== '') {
                return $url;
            }
        }
        return '';
    }

    /**
     * youtube.search.list?part=id&channelId=&q=&type=video&maxResults=5&key=
     */
    protected function search(string $key, string $chan, string $q): string
    {
        $url = add_query_arg(array(
            'part'        => 'snippet,id',
            'channelId'   => $chan,
            'q'           => $q,
            'type'        => 'video',
            'maxResults'  => 10,
            'key'         => $key,
            'order'       => 'date',
        ), 'https://www.googleapis.com/youtube/v3/search');

        $resp = wp_remote_get($url, array('timeout' => 30));
        if (is_wp_error($resp)) {
            $this->logger->warning('YT_Lookup search error: ' . $resp->get_error_message());
            return '';
        }
        $body = json_decode(wp_remote_retrieve_body($resp), true);
        if (empty($body['items'])) {
            return '';
        }

        $target = $this->slugify($q);
        foreach ($body['items'] as $item) {
            $id   = $item['id']['videoId'] ?? '';
            $t    = $this->slugify($item['snippet']['title'] ?? '');
            // Best match: title token overlap.
            if ($t === $target || $this->similar($t, $target) > 0.6) {
                return 'https://www.youtube.com/watch?v=' . $id;
            }
        }
        // Fallback: newest result from our channel.
        $id = $body['items'][0]['id']['videoId'] ?? '';
        return $id ? 'https://www.youtube.com/watch?v=' . $id : '';
    }

    /**
     * Build a native YouTube embed URL (for Gutenberg core/embed block).
     */
    public function embed_url(string $watch_url): string
    {
        $id = $this->video_id($watch_url);
        return $id ? 'https://www.youtube.com/embed/' . $id : '';
    }

    public function video_id(string $watch_url): string
    {
        parse_str((string) wp_parse_url($watch_url, PHP_URL_QUERY), $q);
        if (!empty($q['v'])) {
            return (string) $q['v'];
        }
        // youtu.be/<id>
        $path = trim((string) wp_parse_url($watch_url, PHP_URL_PATH), '/');
        return preg_match('/^[A-Za-z0-9_-]{6,20}$/', $path) ? $path : '';
    }

    protected function slugify(string $s): string
    {
        $s = strtolower(trim($s));
        $s = preg_replace('/[^a-z0-9]+/', ' ', $s);
        return trim($s);
    }

    protected function similar(string $a, string $b): float
    {
        similar_text($a, $b, $pct);
        return $pct / 100;
    }
}
