<?php

namespace DIT\TrendStudio\DTO;

/**
 * Data Transfer Object representing the request to generate content.
 *
 * All properties are public for ease of assignment and consumption.
 */
class GenerationRequestDTO
{
    public string $ideaTitle = '';
    public string $ideaText = '';
    public string $vertical = '';
    public string $category = '';
    public string $sourceUrls = '';
    public string $primaryKeyword = '';
    public string $searchIntent = '';
    public string $secondaryKeywords = '';
    public string $editorialAngle = '';
    public array $structureBlueprint = [];
    public string $roleDefinition = '';
    public string $styleGuide = '';
    public string $formattingRules = '';
    public array $sourceVisualMap = [];

    /**
     * Construct from associative array of prompt data. Any missing keys
     * will retain their default values.
     *
     * @param array $data
     */
    public function __construct(array $data = [])
    {
        foreach ($data as $key => $value) {
            $prop = self::snakeToCamel($key);
            if (property_exists($this, $prop)) {
                $this->{$prop} = $value;
            }
        }
    }

    /**
     * Convert snake_case keys to camelCase properties.
     *
     * @param string $snake
     * @return string
     */
    private static function snakeToCamel(string $snake): string
    {
        $result = lcfirst(str_replace(' ', '', ucwords(str_replace('_', ' ', $snake))));
        return $result;
    }

    /**
     * Serialize DTO back to array with snake_case keys.
     *
     * @return array
     */
    public function toArray(): array
    {
        return [
            'idea_title'         => $this->ideaTitle,
            'idea_text'          => $this->ideaText,
            'vertical'           => $this->vertical,
            'category'           => $this->category,
            'source_urls'        => $this->sourceUrls,
            'primary_keyword'    => $this->primaryKeyword,
            'search_intent'      => $this->searchIntent,
            'secondary_keywords' => $this->secondaryKeywords,
            'editorial_angle'    => $this->editorialAngle,
            'structure_blueprint' => $this->structureBlueprint,
            'role_definition'    => $this->roleDefinition,
            'style_guide'        => $this->styleGuide,
            'formatting_rules'   => $this->formattingRules,
            'source_visual_map'  => $this->sourceVisualMap,
        ];
    }
}
