<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class OpenCodeZenModelSync {

	const API_URL = 'https://opencode.ai/zen/v1/models';

	/**
	 * Known free model IDs from OpenCode Zen pricing table.
	 * Identified by: '-free' suffix in ID, or entry in pricing table marked "Free".
	 */
	private static $FREE_MODEL_IDS = [
		'big-pickle',
		'deepseek-v4-flash-free',
		'mimo-v2.5-free',
		'north-mini-code-free',
		'nemotron-3-ultra-free',
		'hy3-free',
	];

	/**
	 * Detect an OpenCode Zen custom provider by its API URL.
	 * Matches any host ending in "opencode.ai" (e.g. opencode.ai, zen.opencode.ai)
	 * or the documented Zen base path "/zen".
	 */
	public static function is_zen_url( string $url ): bool {
		$url = trim( $url );
		if ( $url === '' ) {
			return false;
		}
		if ( strpos( $url, 'opencode.ai' ) !== false ) {
			return true;
		}
		$host = wp_parse_url( $url, PHP_URL_HOST );
		if ( is_string( $host ) && ( $host === 'opencode.ai' || substr( $host, -strlen( '.opencode.ai' ) ) === '.opencode.ai' ) ) {
			return true;
		}
		return false;
	}

	public static function sync(): array {
		$providers = Config::get_custom_providers();
		if ( empty( $providers ) ) {
			return [ 'success' => false, 'message' => 'No custom providers configured.' ];
		}

		$zen_index = -1;
		foreach ( $providers as $i => $p ) {
			$url = $p['api_url'] ?? '';
			if ( self::is_zen_url( $url ) ) {
				$zen_index = $i;
				break;
			}
		}

		if ( $zen_index === -1 ) {
			return [ 'success' => false, 'message' => 'No OpenCode Zen custom provider found (URL must contain opencode.ai).' ];
		}

		$free_models = self::fetch_free_models();
		if ( $free_models === null ) {
			return [ 'success' => false, 'message' => 'Failed to fetch models from OpenCode Zen API.' ];
		}

		if ( empty( $free_models ) ) {
			return [ 'success' => false, 'message' => 'No free models returned from OpenCode Zen API.' ];
		}

		$providers[ $zen_index ]['models'] = $free_models;

		$clean = [];
		foreach ( $providers as $profile ) {
			$validated = Config::validate_custom_profile( $profile );
			if ( $validated !== null ) {
				$clean[] = $validated;
			}
		}
		update_option( Config::OPTION_CUSTOM_PROVIDERS, wp_json_encode( $clean ) );

		update_option( Config::OPTION_ZEN_LAST_SYNC, time(), false );

		$ids = array_column( $free_models, 'model_id' );
		Logger::info( Config::LOG_ACTION_ZEN_SYNC, null, [
			'model_ids' => $ids,
			'total' => count( $free_models ),
		], '200' );

		return [
			'success' => true,
			'message' => sprintf( 'Sync complete: %d free Zen models loaded.', count( $free_models ) ),
			'total' => count( $free_models ),
			'model_ids' => $ids,
		];
	}

	/**
	 * Fetch all models from Zen API, filter to only free models.
	 */
	private static function fetch_free_models(): ?array {
		$response = wp_remote_get( self::API_URL, [
			'timeout' => 30,
			'headers' => [
				'Accept' => 'application/json',
			],
		] );

		if ( is_wp_error( $response ) ) {
			Logger::warning( Config::LOG_ACTION_ZEN_SYNC, null, [
				'error' => $response->get_error_message(),
				'phase' => 'fetch',
			], '500' );
			return null;
		}

		$code = wp_remote_retrieve_response_code( $response );
		$raw = wp_remote_retrieve_body( $response );

		if ( $code !== 200 ) {
			Logger::warning( Config::LOG_ACTION_ZEN_SYNC, null, [
				'http_code' => $code,
				'phase' => 'fetch',
			], (string) $code );
			return null;
		}

		$data = json_decode( $raw, true );
		if ( ! is_array( $data ) || empty( $data['data'] ) || ! is_array( $data['data'] ) ) {
			Logger::warning( Config::LOG_ACTION_ZEN_SYNC, null, [
				'error' => 'Invalid JSON or empty data array',
				'phase' => 'parse',
			], '500' );
			return null;
		}

		$free = [];
		foreach ( $data['data'] as $model ) {
			$id = $model['id'] ?? '';
			if ( $id === '' ) {
				continue;
			}

			if ( ! in_array( $id, self::$FREE_MODEL_IDS, true ) ) {
				continue;
			}

			$name = self::model_id_to_display( $id );

			$free[] = [
				'display_name' => $name,
				'model_id' => $id,
			];
		}

		return ! empty( $free ) ? $free : null;
	}

	private static function model_id_to_display( string $id ): string {
		$clean = str_replace( [ '-', '_' ], ' ', $id );
		$clean = str_replace( ' free', ' (Free)', $clean );
		return ucwords( $clean );
	}

	public static function get_last_sync_time(): int {
		return (int) get_option( Config::OPTION_ZEN_LAST_SYNC, 0 );
	}

	public static function has_zen_provider(): bool {
		$providers = Config::get_custom_providers();
		foreach ( $providers as $p ) {
			if ( self::is_zen_url( $p['api_url'] ?? '' ) ) {
				return true;
			}
		}
		return false;
	}
}