<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class NM_Cloudflare_Cache_Integration {


	private static $purged_this_request            = false;
	private static $busted_home_cache_this_request = false;

	public static function init() {

		// Covers draft/future -> publish, etc.
		add_action( 'transition_post_status', array( __CLASS__, 'on_transition_post_status' ), 10, 3 );

		// Covers edits to already published MCQs (content/meta changes).
		add_action( 'post_updated', array( __CLASS__, 'on_post_updated' ), 10, 3 );

		// Covers changes to Topic/Exam after publish (common in admin/editor workflows).
		add_action( 'set_object_terms', array( __CLASS__, 'on_set_object_terms' ), 10, 6 );

		// Best integration point with Super Page Cache related-URL purge mechanism.
		add_filter( 'swcfpc_post_related_url_init', array( __CLASS__, 'filter_swcfpc_related_urls' ), 10, 2 );
	}

	public static function on_transition_post_status( $new_status, $old_status, $post ) {

		if ( ! ( $post instanceof WP_Post ) ) {
			return;
		}

		if ( $post->post_type !== 'mcq' ) {
			return;
		}

		if ( $new_status === 'publish' && $old_status !== 'publish' ) {

			// ✅ Minimal internal bust: only on first publish.
			// (Edits/term changes are already handled by NM_Cache_Manager hooks.)
			if ( class_exists( 'NM_Cache_Manager' ) ) {
				NM_Cache_Manager::bust_topic_cache();
			}

			// ✅ Always purge edge HTML listing pages (homepage/topic/exam/archive).
			self::purge_listing_pages( $post->ID );
		}
	}

	public static function on_post_updated( $post_id, $post_after, $post_before ) {

		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}

		if ( ! ( $post_after instanceof WP_Post ) ) {
			return;
		}

		if ( $post_after->post_type !== 'mcq' ) {
			return;
		}

		if ( $post_after->post_status !== 'publish' ) {
			return;
		}

		self::purge_listing_pages( $post_id );
	}

	public static function on_set_object_terms( $object_id, $terms, $tt_ids, $taxonomy, $append, $old_tt_ids ) {

		if ( ! in_array( $taxonomy, array( 'topic', 'nm_exam' ), true ) ) {
			return;
		}

		$post = get_post( $object_id );
		if ( ! ( $post instanceof WP_Post ) ) {
			return;
		}

		if ( $post->post_type !== 'mcq' ) {
			return;
		}

		if ( $post->post_status !== 'publish' ) {
			return;
		}

		self::purge_listing_pages( $object_id );
	}

	public static function filter_swcfpc_related_urls( $list_of_urls, $post_id ) {

		$post = get_post( $post_id );
		if ( ! ( $post instanceof WP_Post ) || $post->post_type !== 'mcq' ) {
			return $list_of_urls;
		}

		$urls = array_merge( (array) $list_of_urls, self::build_listing_urls( $post_id ) );
		$urls = array_values( array_unique( array_filter( $urls ) ) );

		return $urls;
	}

	private static function purge_listing_pages( $post_id ) {

		// Super Page Cache supports programmatic purge via this action (expects full URLs).
		if ( ! has_action( 'swcfpc_purge_cache' ) ) {
			return;
		}

		// Prevent multiple purges in the same request (publish can trigger multiple hooks).
		if ( self::$purged_this_request ) {
			return;
		}

		// IMPORTANT: Bust homepage MCQ transient cache so origin HTML is fresh
		self::bust_homepage_mcq_transients();

		$urls_to_purge = self::build_listing_urls( $post_id );

		if ( empty( $urls_to_purge ) ) {
			return;
		}

		self::$purged_this_request = true;

		NM_Cache_Manager::purge_cloudflare_urls( $urls_to_purge );
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
		}
	}

	private static function build_listing_urls( $post_id ) {

		$urls = array();

		// 1) Homepage (shortcode listing lives here)
		$urls[] = trailingslashit( home_url( '/' ) );

		// 2) If front page is a static page, include its permalink too (safety).
		$page_on_front = (int) get_option( 'page_on_front' );
		if ( $page_on_front > 0 ) {
			$front_link = get_permalink( $page_on_front );
			if ( ! empty( $front_link ) ) {
				$urls[] = $front_link;
			}
		}

		// 3) MCQ archive
		$archive_link = get_post_type_archive_link( 'mcq' );
		if ( ! empty( $archive_link ) ) {
			$urls[] = $archive_link;
		}

		// 4) Topic taxonomy archives + parent topics
		$topics = get_the_terms( $post_id, 'topic' );
		if ( $topics && ! is_wp_error( $topics ) ) {
			foreach ( $topics as $term ) {
				$term_link = get_term_link( $term );
				if ( ! is_wp_error( $term_link ) ) {
					$urls[] = $term_link;
				}

				if ( ! empty( $term->parent ) ) {
					$parent = get_term( (int) $term->parent, 'topic' );
					if ( $parent && ! is_wp_error( $parent ) ) {
						$parent_link = get_term_link( $parent );
						if ( ! is_wp_error( $parent_link ) ) {
							$urls[] = $parent_link;
						}
					}
				}
			}
		}

		// 5) Exam taxonomy archives
		$exams = get_the_terms( $post_id, 'nm_exam' );
		if ( $exams && ! is_wp_error( $exams ) ) {
			foreach ( $exams as $term ) {
				$term_link = get_term_link( $term );
				if ( ! is_wp_error( $term_link ) ) {
					$urls[] = $term_link;
				}
			}
		}

		// Normalize URLs and remove empties/duplicates.
		$urls = array_map(
			function ( $u ) {
				return is_string( $u ) ? trailingslashit( $u ) : '';
			},
			$urls
		);

		return array_values( array_unique( array_filter( $urls ) ) );
	}
	/**
	 * Bust homepage MCQ transient caches used by optimized homepage loads.
	 *
	 * This clears transients like:
	 * - _transient_nm_mcqs_opt_*
	 * - _transient_timeout_nm_mcqs_opt_*
	 *
	 * This is required because these keys are not namespaced through NM_Cache_Manager,
	 * so NM_Cache_Manager::bust_topic_cache() won't remove them automatically.
	 */
	private static function bust_homepage_mcq_transients() {
		if ( self::$busted_home_cache_this_request ) {
			return;
		}

		global $wpdb;

		// Transients are stored as options:
		// _transient_{key} and _transient_timeout_{key}
		$prefix = 'nm_mcqs_opt_';

		$like_transient = $wpdb->esc_like( '_transient_' . $prefix ) . '%';
		$like_timeout   = $wpdb->esc_like( '_transient_timeout_' . $prefix ) . '%';

		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
				$like_transient,
				$like_timeout
			)
		);

		self::$busted_home_cache_this_request = true;
	}
}
