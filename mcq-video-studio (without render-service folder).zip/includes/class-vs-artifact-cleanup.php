<?php
/**
 * Central Cleanup Service for MCQ Video Studio artifacts (v1.7.0 rewrite).
 *
 * WHY THIS REWRITE (production incident 2026-09-18, ~70 GB /tmp, fs 100%,
 * MariaDB errcode 28): the previous implementation was architecturally
 * disabled by default — `option()` returned DISABLED (-1) for every retention
 * category the admin had not explicitly configured, and the prune loop skips
 * categories with `$days <= 0`. On any install where nobody typed retention
 * values, the daily cron ran and deleted NOTHING. There was also no
 * immediate cleanup on terminal job transitions for /tmp artifacts, no
 * heartbeat/orphan model for the flat /tmp namespace, no disk-space gate and
 * no emergency path.
 *
 * DESIGN (single authority — this class owns ALL filesystem cleanup):
 *  - Job-scoped temp home: {get_temp_dir()}mcqvs/{job_id}/ with frames/,
 *    audio/, tts/, assets/, render/, output/, status.json, render.log,
 *    heartbeat. Legacy flat /tmp/mcqvs_* artifacts remain cleanable forever
 *    (backward compatibility) and are guarded by the same active-job logic.
 *  - Layer 1 (immediate): VS_Job_Repository::update_status() and
 *    clear_stuck_jobs() call on_job_terminal() on EVERY terminal transition
 *    (completed/failed/cancelled) from every producer (renderer, automation,
 *    AJAX, bulk). Bulky subtrees are removed immediately; small diagnostics
 *    (status.json/render.log) are kept per retention then swept.
 *  - Layer 2 (scheduled orphan sweep): this class' existing daily cron
 *    (CRON_HOOK unchanged) + admin_init self-heal. Classifies every job dir
 *    by DB status + heartbeat freshness; NEVER touches active jobs; removes
 *    orphans/terminal-expired/legacy flat artifacts; tolerates per-file
 *    failures; idempotent; lock-guarded against concurrent sweeps.
 *  - Disk gate: disk_health() (healthy/warning/critical) + emergency orphan
 *    sweep on critical pressure before renders are deferred (never deletes
 *    active jobs, never deletes published output).
 *
 * SECURITY: every deletion path is validated (job-id pattern), canonicalized
 * and containment-checked against the plugin temp base; symlinks are unlinked
 * never followed; nothing outside the base is ever removed.
 *
 * @package MCQ_Video_Studio
 */

if (! defined('ABSPATH')) {
    exit;
}

class VS_Artifact_Cleanup
{
    /** Cron hook (unchanged from pre-1.7.0 so existing schedules keep working). */
    public const CRON_HOOK = 'mcqvs_daily_artifact_prune';

    /** Sentinel meaning "feature disabled" (explicit admin choice only). */
    public const DISABLED = -1;

    /** Sub-trees we own inside uploads/mcq-video-studio/. */
    private const UPLOAD_SUBDIRS = array('tts', 'covers', 'generated', 'exports');

    /** Sanitize range for retention (days). 0 disables, -1 = use safe default. */
    public const RETENTION_MIN_DAYS = 0;
    public const RETENTION_MAX_DAYS = 365;

    /**
     * SAFE DEFAULTS (days) — the fix for the incident: an unset retention no
     * longer means "never clean". Explicit 0 in Settings still disables a
     * category deliberately. Values chosen from observed render footprints:
     * temp render artifacts are useless after the job ends; uploads caches
     * (tts/covers) are reusable for a week; generated/export MP4s are kept
     * 2 days for manual download/retry.
     */
    public const DEFAULT_RETENTION_DAYS = array(
        'tts'         => 7,
        'covers'      => 7,
        'generated'   => 2,
        'exports'     => 2,
        'batch'       => 2,
        'render_temp' => 1,
        'temp'        => 1,
    );

    /** Job-scoped temp root name under get_temp_dir(). */
    public const JOB_ROOT = 'mcqvs';

    /** Bulky subdirs inside a job dir — removed immediately on terminal. */
    public const BULK_SUBDIRS = array('frames', 'audio', 'tts', 'assets', 'render', 'output');

    /** Terminal job statuses per VS_Schema::get_job_statuses(). */
    private const TERMINAL_STATUSES = array('completed', 'failed', 'cancelled');

    /** Statuses that mean "a render may legitimately be in flight". */
    private const ACTIVE_STATUSES = array('pending', 'ready_for_render', 'rendering', 'uploading');

    /** Legacy flat prefixes (PHP side / Node side) — disjoint, as before. */
    private const LEGACY_RENDER_TEMP = array('mcqvs_payload_*', 'mcqvs_status_*', 'mcqvs_renderlog_*', 'mcqvs_exit_*', 'mcqvs_vs_*.mp4');
    // mcqvs_tts_* (superset of tts_err) and mcqvs_logo_* cover residue from
    // older plugin versions; the seen-map dedupes overlap with tts_err.
    private const LEGACY_NODE_TEMP   = array('mcqvs_audio_*', 'mcqvs_bgframes_*', 'mcqvs_sfx_*', 'mcqvs_video_*', 'mcqvs_r2_*', 'mcqvs_tts_*', 'mcqvs_logo_*', 'mcqvs_asset_*');

    private static $instance = null;

    /** @var array<string,bool>|null */
    private $terminal_cache = null;

    public static function init()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        add_action(self::CRON_HOOK, array($this, 'run_daily_artifact_prune'));
        add_action('wp_ajax_mcqvs_run_artifact_cleanup', array($this, 'ajax_run_cleanup_now'));
        // Self-heal: admin pages are the cheapest reliable heartbeat for
        // "is cron alive". Never schedules more than once (wp_next_scheduled).
        add_action('admin_init', array($this, 'ensure_schedule'));
        // @NEW 1.9.8 (root-cause fix, live evidence 2026-10-05): this VPS runs the
        // video pipeline on Action Scheduler while WP-Cron never ticks, so a
        // WP-Cron-only prune starved and /tmp grew ~10 GB/day. Catch-up runs the
        // prune from ANY request (admin/ajax/front) when the last real run is
        // older than 26 h — throttled to one check per hour, lock-guarded.
        add_action('init', array($this, 'maybe_catch_up'));
        $this->ensure_schedule();
        self::migrate_blank_retention();
    }

    /**
     * Missed-run catch-up (v1.9.8). WP-Cron can be disabled/broken on a host
     * while Action Scheduler keeps the render pipeline alive — cleanup must not
     * depend on which scheduler happens to work. Throttled by a 1 h transient;
     * the prune itself is lock-guarded and idempotent, so overlapping triggers
     * (WP-Cron + AS + catch-up) are safe.
     *
     * @NEW 1.9.8
     */
    public function maybe_catch_up()
    {
        if (get_transient('mcqvs_cleanup_catchup_check')) {
            return;
        }
        set_transient('mcqvs_cleanup_catchup_check', 1, 3600);
        $last = (int) get_option('mcqvs_cleanup_last_run', 0);
        if ($last > 0 && (time() - $last) < (26 * 3600)) {
            return;
        }
        if (class_exists('VS_Error_Logger')) {
            VS_Error_Logger::get_instance()->log('MCQVS cleanup.catch_up triggered (last run ' . ($last ? gmdate('Y-m-d H:i:s', $last) : 'never') . ')', 'info', array('_type' => 'artifact_cleanup', 'event' => 'catch_up'));
        }
        $this->run_daily_artifact_prune();
    }

    /**
     * @FIX 1.9.7 (owner report: retention fields / dead button): a form save
     * with the retention inputs left BLANK used to store 0 (= explicitly off)
     * for every category — the exact state that let /tmp grow to 70 GB. The
     * all-zero signature is almost certainly accidental, so migrate it once to
     * the UNSET sentinel (-1 → safe defaults). Any other combination (e.g. a
     * deliberate 0 on one category) is respected untouched. Flag-guarded.
     */
    public static function migrate_blank_retention()
    {
        if (get_option('mcqvs_retention_blank_migrated', 0)) {
            return;
        }
        $cats = array('tts', 'covers', 'generated', 'exports', 'batch', 'render_temp', 'temp');
        $all_zero = true;
        $any_stored = false;
        foreach ($cats as $c) {
            $raw = get_option('mcqvs_artifact_retention_' . $c, null);
            if ($raw === null) {
                continue;
            }
            $any_stored = true;
            if ((int) $raw !== 0) {
                $all_zero = false;
            }
        }
        if ($any_stored && $all_zero) {
            foreach ($cats as $c) {
                update_option('mcqvs_artifact_retention_' . $c, -1);
            }
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log('MCQVS cleanup.retention_blank_migrated: all-zero stored retentions reset to safe defaults', 'warning', array('_type' => 'artifact_cleanup', 'event' => 'retention_blank_migrated'));
            }
        }
        update_option('mcqvs_retention_blank_migrated', 1);
    }

    // ------------------------------------------------------------------
    //  SCHEDULING (self-healing, duplicate-proof)
    // ------------------------------------------------------------------

    /**
     * Guarantees exactly one recurring prune event exists. Safe to call on
     * every request (single wp_next_scheduled read, no writes when present).
     */
    public function ensure_schedule()
    {
        if (! wp_next_scheduled(self::CRON_HOOK)) {
            wp_schedule_event(time() + 3600, 'daily', self::CRON_HOOK);
        }
        // @NEW 1.9.8: when Action Scheduler is part of the stack (it is — the
        // render/publish pipelines use it), also register the prune there so
        // hosts with dead WP-Cron still get a daily scheduled run, not only
        // catch-up. as_has_scheduled_action keeps this duplicate-proof.
        if (function_exists('as_schedule_recurring_action') && function_exists('as_has_scheduled_action')
            && ! as_has_scheduled_action(self::CRON_HOOK, array(), 'mcq-video-studio')) {
            as_schedule_recurring_action(time() + 3600, DAY_IN_SECONDS, self::CRON_HOOK, array(), 'mcq-video-studio');
        }
    }

    // ------------------------------------------------------------------
    //  PATHS + SECURITY
    // ------------------------------------------------------------------

    /**
     * Validate a job id against the repository's own format
     * (class-vs-job-repository.php: 'vs_' . uniqid() . '_' . wp_rand()).
     */
    public static function is_valid_job_id($job_id)
    {
        return (bool) preg_match('/^vs_[0-9a-f]{6,14}_\d{1,10}$/', (string) $job_id);
    }

    /** Plugin temp base: {get_temp_dir()}mcqvs/ (created on demand elsewhere). */
    public static function job_root_dir()
    {
        return get_temp_dir() . self::JOB_ROOT;
    }

    /**
     * ALL filesystem bases that may hold plugin temp artifacts.
     *
     * WHY (production evidence 2026-09-18): PHP's get_temp_dir() and Node's
     * os.tmpdir() can DISAGREE on a VPS (TMPDIR/service env), which produced
     * mcqvs_* files in /tmp AND mcqvs_bgframes_* in /home/<user>/tmp. A sweep
     * that only knows one base silently leaks the other. Bases are:
     *   1. get_temp_dir()            (WP/PHP writers, job-scoped root)
     *   2. sys_get_temp_dir()        (PHP tempnam producers)
     *   3. /tmp and /var/tmp         (unix defaults, node fallback)
     *   4. home-dir tmp folders      (node os.tmpdir() under TMPDIR/service env)
     *   5. admin-listed extras       (mcqvs_extra_temp_dirs option)
     *   6. filter mcqvs_temp_bases   (hosts with exotic layouts)
     * Every sweep stays strictly inside plugin-owned prefixes within these
     * bases — unrelated files are never touched.
     *
     * @NEW 1.7.1
     * @return array Normalized dir paths with trailing slash, de-duplicated.
     */
    public static function temp_bases()
    {
        $bases = array();
        $add = function ($dir) use (&$bases) {
            if (! is_string($dir) || $dir === '') {
                return;
            }
            $dir = trailingslashit(wp_normalize_path($dir));
            if (! is_dir($dir)) {
                return;
            }
            $real = @realpath($dir);
            $key  = trailingslashit($real !== false ? wp_normalize_path($real) : $dir);
            if (! in_array($key, $bases, true)) {
                $bases[] = $key;
            }
        };

        $add(get_temp_dir());
        if (function_exists('sys_get_temp_dir')) {
            $add(sys_get_temp_dir());
        }
        if (DIRECTORY_SEPARATOR === '/') {
            $add('/tmp');
            $add('/var/tmp');
            foreach ((array) @glob('/home/*/tmp', GLOB_ONLYDIR) as $home_tmp) {
                $add($home_tmp);
            }
        }
        $extra = (string) get_option('mcqvs_extra_temp_dirs', '');
        foreach (preg_split('/[\s,;]+/', $extra, -1, PREG_SPLIT_NO_EMPTY) as $e) {
            $e = trim($e);
            // Security: absolute paths only; containment is enforced per-file
            // by the prefix globs, never by trusting this list blindly.
            if ($e !== '' && strpos($e, '/') === 0) {
                $add($e);
            }
        }

        $filtered = apply_filters('mcqvs_temp_bases', $bases);
        if (is_array($filtered) && ! empty($filtered)) {
            // Re-normalize filter output (trailing slash + existence) so every
            // consumer can concatenate safely.
            $norm = array();
            foreach ($filtered as $f) {
                $add($f);
            }
            // $add dedupes into $bases already; keep order stable:
            return $bases;
        }
        return $bases;
    }

    /**
     * Containment check for recursive deletion: path must live inside ONE of
     * the known temp bases (any of them — multi-base VPS layouts) or inside
     * the plugin's uploads subtree. Never follows or deletes outside.
     *
     * @NEW 1.7.1
     */
    private function is_within_any_base($path)
    {
        $p = wp_normalize_path($path);
        foreach (self::temp_bases() as $base_dir) {
            if (strpos($p, $base_dir) === 0) {
                return true;
            }
        }
        $up = $this->uploads_base();
        if ($up !== '' && strpos($p, wp_normalize_path($up)) === 0) {
            return true;
        }
        return false;
    }

    /**
     * Job-scoped temp dir. Canonicalized + containment-checked.
     * @return string '' when the job id is not trustworthy.
     */
    public static function job_temp_dir($job_id)
    {
        if (! self::is_valid_job_id($job_id)) {
            return '';
        }
        $base = wp_normalize_path(self::job_root_dir());
        $dir  = wp_normalize_path($base . '/' . $job_id);
        // Defence-in-depth: canonical containment (no ../, no external absolutes).
        if (strpos($dir, $base . '/') !== 0) {
            return '';
        }
        return $dir;
    }

    /**
     * True when $path is strictly inside the plugin temp bases
     * ({get_temp_dir()}mcqvs/ OR get_temp_dir() for legacy flat files).
     */
    private function is_within_temp_base($path)
    {
        $p    = wp_normalize_path($path);
        $base = wp_normalize_path(self::job_root_dir());
        $temp = wp_normalize_path(get_temp_dir());
        return (strpos($p, $base . '/') === 0) || (strpos($p, $temp) === 0 && strpos(basename($p), 'mcqvs_') === 0);
    }

    // ------------------------------------------------------------------
    //  CONFIG
    // ------------------------------------------------------------------

    /** Active-job stale threshold (seconds). Configurable, default 2 h. */
    public static function active_stale_seconds()
    {
        $h = (int) get_option('mcqvs_cleanup_active_stale_hours', 2);
        if ($h < 1) {
            $h = 1;
        }
        if ($h > 72) {
            $h = 72;
        }
        return $h * 3600;
    }

    /** Completed-job diagnostics retention (seconds). Default 1 h. */
    public static function completed_retention_seconds()
    {
        $h = (int) get_option('mcqvs_cleanup_completed_retention_hours', 1);
        return max(0, min(168, $h)) * 3600;
    }

    /** Failed-job diagnostics retention (seconds). Default 24 h. */
    public static function failed_retention_seconds()
    {
        $h = (int) get_option('mcqvs_cleanup_failed_retention_hours', 24);
        return max(0, min(336, $h)) * 3600;
    }

    /** Minimum free bytes on the temp filesystem before renders are allowed. */
    public static function min_free_disk_bytes()
    {
        $gb = (float) get_option('mcqvs_min_free_disk_gb', 10);
        if ($gb < 1) {
            $gb = 1;
        }
        return (int) round($gb * 1024 * 1024 * 1024);
    }

    /**
     * Retention days for a category: explicit admin value wins; UNSET now
     * falls back to SAFE DEFAULTS (the incident fix); explicit 0 = disabled.
     */
    private function option($key)
    {
        if ($key === 'dry_run') {
            return (int) get_option('mcqvs_artifact_retention_dry_run', 0);
        }
        $raw = get_option('mcqvs_artifact_retention_' . $key, null);
        if ($raw === null || $raw === '' || $raw === false) {
            $days = self::DEFAULT_RETENTION_DAYS[$key] ?? 1;
        } else {
            $days = (int) $raw;
            if ($days < 0) {
                $days = self::DEFAULT_RETENTION_DAYS[$key] ?? 1;
            }
        }
        if ($days > self::RETENTION_MAX_DAYS) {
            $days = self::RETENTION_MAX_DAYS;
        }
        return $days;
    }

    // ------------------------------------------------------------------
    //  DISK HEALTH + EMERGENCY
    // ------------------------------------------------------------------

    /**
     * healthy | warning | critical for the temp filesystem.
     * Testable: filter mcqvs_disk_free_bytes overrides the probe.
     *
     * @return array{state:string,free:int,min:int}
     */
    public static function disk_health()
    {
        $path = get_temp_dir();
        $free = apply_filters('mcqvs_disk_free_bytes', null, $path);
        if (! is_numeric($free)) {
            $free = @disk_free_space($path);
        }
        $free = is_numeric($free) ? (int) $free : PHP_INT_MAX;
        $min  = self::min_free_disk_bytes();
        $state = 'healthy';
        if ($free < $min) {
            $state = 'critical';
        } elseif ($free < $min * 2) {
            $state = 'warning';
        }
        return array('state' => $state, 'free' => $free, 'min' => $min);
    }

    /**
     * Emergency pressure valve: on critical disk, sweep ORPHANS only (never
     * active jobs, never terminal-within-retention diagnostics), then recheck.
     * Called by the renderer gate before deferring a render.
     *
     * @return array{state:string,free:int,min:int,swept:array}
     */
    public static function emergency_cleanup_if_critical()
    {
        $health = self::disk_health();
        $swept  = array();
        if ($health['state'] === 'critical') {
            $self = self::init();
            $swept = $self->sweep_orphans_only();
            $health = self::disk_health();
        }
        $health['swept'] = $swept;
        return $health;
    }

    // ------------------------------------------------------------------
    //  LAYER 1 — IMMEDIATE JOB CLEANUP (terminal transitions)
    // ------------------------------------------------------------------

    /**
     * Called by VS_Job_Repository on EVERY terminal status transition and by
     * clear_stuck_jobs(). Removes bulky subtrees at once; keeps status.json +
     * render.log until their retention expires (Layer 2 removes the shell).
     * Idempotent + never throws.
     *
     * @param string $job_id
     * @param string $status Terminal status reached.
     * @return array Stats.
     */
    public function on_job_terminal($job_id, $status)
    {
        $stats = array('job_id' => $job_id, 'status' => $status, 'bytes' => 0, 'removed' => 0, 'kept_logs' => false);
        $dir = self::job_temp_dir($job_id);
        if ($dir === '' || ! is_dir($dir)) {
            // Legacy flat artifacts for this job: remove bulky ones now too.
            $stats['bytes'] += $this->remove_legacy_job_files($job_id, true);
            return $stats;
        }
        foreach (self::BULK_SUBDIRS as $sub) {
            $sub_dir = $dir . '/' . $sub;
            if (is_dir($sub_dir)) {
                $bytes = $this->dir_size($sub_dir);
                $this->rrmdir($sub_dir);
                $stats['bytes'] += $bytes;
                $stats['removed']++;
            }
        }
        // Legacy out mp4 inside job dir (output/ already covered) + root strays.
        foreach (array('out.mp4', 'video.mp4') as $f) {
            if (is_file($dir . '/' . $f)) {
                $stats['bytes'] += (int) @filesize($dir . '/' . $f);
                @unlink($dir . '/' . $f);
                $stats['removed']++;
            }
        }
        $stats['bytes'] += $this->remove_legacy_job_files($job_id, true);
        $stats['kept_logs'] = true; // status.json/render.log swept by Layer 2
        $this->log('cleanup.job_terminal', array_merge($stats, array('reason' => 'terminal:' . $status)));
        return $stats;
    }

    /**
     * Manual/forced full removal of one job's temp home (AJAX-safe, validated).
     * Used by tests + the "purge job temps" escape hatch.
     */
    public function cleanup_job_full($job_id)
    {
        $dir = self::job_temp_dir($job_id);
        if ($dir === '' || ! is_dir($dir)) {
            return array('job_id' => $job_id, 'removed' => 0, 'bytes' => 0);
        }
        $bytes = $this->dir_size($dir);
        $this->rrmdir($dir);
        $legacy = $this->remove_legacy_job_files($job_id, true);
        return array('job_id' => $job_id, 'removed' => 1, 'bytes' => $bytes + $legacy);
    }

    /**
     * Delete legacy flat /tmp artifacts belonging to one job id.
     * @param bool $include_bulk Always true today; param kept for clarity.
     * @return int bytes reclaimed.
     */
    private function remove_legacy_job_files($job_id, $include_bulk)
    {
        if (! self::is_valid_job_id($job_id)) {
            return 0;
        }
        $bytes = 0;
        $patterns = array(
            'mcqvs_payload_' . $job_id . '.json',
            'mcqvs_status_' . $job_id . '.json',
            'mcqvs_renderlog_' . $job_id . '.log',
            'mcqvs_exit_' . $job_id,
            'mcqvs_' . $job_id . '.mp4',
            'mcqvs_audio_' . $job_id . '.wav',
        );
        // @FIX 1.7.1: PHP and Node temp bases can differ (TMPDIR/service env) —
        // per-job legacy files are removed from EVERY known base.
        foreach (self::temp_bases() as $temp) {
            foreach ($patterns as $p) {
                $f = $temp . $p;
                if (is_file($f)) {
                    $bytes += (int) @filesize($f);
                    @unlink($f);
                }
            }
            if ($include_bulk) {
                foreach ((array) @glob($temp . 'mcqvs_bgframes_*' . $job_id . '*') as $d) {
                    if (is_dir($d)) {
                        $bytes += $this->dir_size($d);
                        $this->rrmdir($d);
                    }
                }
            }
        }
        return $bytes;
    }

    // ------------------------------------------------------------------
    //  HEARTBEAT + CLASSIFICATION
    // ------------------------------------------------------------------

    /**
     * Last heartbeat epoch for a job: heartbeat file (node, every ~10 s) →
     * status.json mtime → job dir mtime. Never null for existing dirs.
     */
    public function heartbeat_time($job_id)
    {
        $dir = self::job_temp_dir($job_id);
        if ($dir !== '') {
            foreach (array('/heartbeat', '/status.json', '') as $suffix) {
                $f = $dir . $suffix;
                if ($suffix === '' ? is_dir($f) : is_file($f)) {
                    $m = @filemtime($f);
                    if ($m !== false) {
                        return (int) $m;
                    }
                }
            }
        }
        // Legacy flat namespace (jobs spawned by pre-1.7.0 renders): the node
        // side rewrote mcqvs_status_<job>.json at every milestone — that mtime
        // is the best available heartbeat for those jobs. Check EVERY base
        // (PHP and Node temp dirs can differ — @FIX 1.7.1).
        foreach (self::temp_bases() as $temp) {
            $legacy = $temp . 'mcqvs_status_' . $job_id . '.json';
            if (is_file($legacy)) {
                $m = @filemtime($legacy);
                if ($m !== false) {
                    return (int) $m;
                }
            }
        }
        return 0;
    }

    /**
     * Classify a job dir for the sweep. DB status is authoritative; heartbeat
     * detects crashes (status says rendering but nothing moved for hours).
     *
     * @return array{class:string,reason:string} class: active|terminal|orphan|unknown
     */
    public function classify_job($job_id)
    {
        $status = $this->job_status($job_id);
        $hb     = $this->heartbeat_time($job_id);
        $stale  = self::active_stale_seconds();
        $now    = time();

        if ($status !== '' && in_array($status, self::TERMINAL_STATUSES, true)) {
            return array('class' => 'terminal', 'reason' => 'db:' . $status);
        }
        if ($status !== '' && in_array($status, self::ACTIVE_STATUSES, true)) {
            if ($hb > 0 && ($now - $hb) > $stale) {
                return array('class' => 'orphan', 'reason' => 'stale-heartbeat:' . ($now - $hb) . 's> ' . $stale . 's');
            }
            return array('class' => 'active', 'reason' => 'db:' . $status);
        }
        // Unknown job (row gone) or exotic status: orphan if dir is old enough,
        // otherwise leave for the next pass (protects just-created jobs whose
        // DB row insert and dir creation are not atomic).
        if (($now - $hb) > $stale) {
            return array('class' => 'orphan', 'reason' => 'unknown-or-stale');
        }
        return array('class' => 'unknown', 'reason' => 'within-grace');
    }

    private function job_status($job_id)
    {
        if (! class_exists('VS_Job_Repository')) {
            return '';
        }
        try {
            global $wpdb;
            $table = VS_Job_Repository::get_table_name();
            return (string) $wpdb->get_var($wpdb->prepare(
                "SELECT status FROM {$table} WHERE job_id = %s LIMIT 1",
                $job_id
            ));
        } catch (\Throwable $e) {
            return '';
        }
    }

    // ------------------------------------------------------------------
    //  LAYER 2 — SCHEDULED SWEEP
    // ------------------------------------------------------------------

    /**
     * Daily (self-healed) sweep. Lock-guarded, per-candidate failure tolerant,
     * idempotent, active-job safe, legacy-flat aware, structured logging.
     *
     * @return array Stats.
     */
    public function run_daily_artifact_prune()
    {
        $lock = 'mcqvs_cleanup_lock';
        if (get_transient($lock)) {
            $this->log('cleanup.skip_locked', array());
            return array('skipped' => 'locked');
        }
        set_transient($lock, 1, 600);

        try {
            $stats = $this->prune_all(false);
        } catch (\Throwable $e) {
            $this->log('cleanup.error', array('error' => $e->getMessage()));
            $stats = array('error' => $e->getMessage());
        }

        delete_transient($lock);
        return $stats;
    }

    /**
     * Emergency variant: orphans + expired terminal + legacy stale ONLY.
     * (Never deletes active jobs; identical code path with a flag.)
     */
    private function sweep_orphans_only()
    {
        return $this->prune_all(true);
    }

    /**
     * The whole sweep, parameterised so emergency and daily share one code
     * path (no duplicated cleanup logic).
     *
     * @param bool $orphans_only Skip uploads-cache categories (emergency mode).
     * @return array Stats.
     */
    private function prune_all($orphans_only)
    {
        $started = microtime(true);
        $dry_run = (bool) $this->option('dry_run');

        $stats = array(
            'candidates'     => 0,
            'deleted'        => 0,
            'failed'         => 0,
            'skipped_active' => 0,
            'orphans'        => 0,
            'bytes'          => 0,
            'tts' => 0, 'covers' => 0, 'generated' => 0, 'exports' => 0,
            'batch' => 0, 'render_temp' => 0, 'temp' => 0,
            'dry_run'        => $dry_run,
        );

        // --- uploads caches (skipped in emergency mode) ---
        if (! $orphans_only) {
            $base = $this->uploads_base();
            if ($base !== '') {
                foreach (self::UPLOAD_SUBDIRS as $sub) {
                    $days = $this->option($sub);
                    if ($days <= 0) {
                        continue;
                    }
                    $n = $this->prune_flat_dir($base . '/' . $sub, $days, $dry_run, $stats);
                    $stats[$sub] = $n;
                    $stats['candidates'] += $n;
                    $stats['deleted'] += $n;
                }
                $batch_days = $this->option('batch');
                if ($batch_days > 0) {
                    $n = $this->prune_batch_subdirs($base . '/batch', $batch_days, $dry_run, $stats);
                    $stats['batch'] = $n;
                    $stats['candidates'] += $n;
                    $stats['deleted'] += $n;
                }
            }
        }

        // --- job-scoped temp dirs: {base}mcqvs/{job_id}/ on EVERY base ---
        // (PHP creates them under get_temp_dir(), but a mis-set WP_TEMP_DIR or
        // a future writer must never leave a root unswept on another base.)
        $bases = self::temp_bases();
        $stats['bases'] = count($bases);
        foreach ($bases as $base_dir) {
            $root = $base_dir . self::JOB_ROOT;
            if (! is_dir($root)) {
                continue;
            }
            $job_dirs = (array) @glob($root . '/*', GLOB_ONLYDIR);
            foreach ($job_dirs as $job_dir) {
                $job_id = basename($job_dir);
                if (! self::is_valid_job_id($job_id)) {
                    // Not ours by naming convention: leave untouched forever.
                    continue;
                }
                $stats['candidates']++;
                $cls = $this->classify_job($job_id);
                if ($cls['class'] === 'active') {
                    $stats['skipped_active']++;
                    continue;
                }
                if ($cls['class'] === 'unknown') {
                    $stats['skipped_active']++; // within grace window
                    continue;
                }
                $age_ok = true;
                if ($cls['class'] === 'terminal') {
                    $status   = $this->job_status($job_id);
                    $retention = ($status === 'completed') ? self::completed_retention_seconds() : self::failed_retention_seconds();
                    $dir_mtime = (int) @filemtime($job_dir);
                    $age_ok = (time() - $dir_mtime) >= $retention || $this->dir_holds_only_logs($job_dir);
                }
                if (! $age_ok) {
                    $stats['skipped_active']++; // diagnostics still in retention
                    continue;
                }
                if ($cls['class'] === 'orphan') {
                    $stats['orphans']++;
                }
                $bytes = $dry_run ? 0 : $this->dir_size($job_dir);
                if (! $dry_run) {
                    $this->rrmdir($job_dir);
                    if (is_dir($job_dir)) {
                        $stats['failed']++; // e.g. permission — continue anyway
                        $this->log('cleanup.delete_failed', array('path' => $job_id));
                        continue;
                    }
                }
                $stats['bytes'] += $bytes;
                $stats['deleted']++;
            }
            // Remove the root when empty (never leave orphan dirs).
            if (! $dry_run) {
                @rmdir($root);
            }
        }

        // --- legacy flat mcqvs_* on EVERY base with active-job guard ---
        // (the 2026-09-18 VPS had bgframes in /home/<user>/tmp while PHP files
        // lived in /tmp — both bases are swept, prefixes stay plugin-owned.)
        $rt_days = $this->option('render_temp');
        $nd_days = $this->option('temp');
        foreach ($bases as $base_dir) {
            if ($rt_days > 0) {
                $n = $this->prune_legacy_glob($base_dir, self::LEGACY_RENDER_TEMP, $rt_days, $dry_run, $stats);
                $stats['render_temp'] += $n;
            }
            if ($nd_days > 0) {
                $n = $this->prune_legacy_glob($base_dir, self::LEGACY_NODE_TEMP, $nd_days, $dry_run, $stats);
                $stats['temp'] += $n;
            }
        }

        $stats['duration_ms'] = (int) round((microtime(true) - $started) * 1000);
        // @NEW 1.9.8: last-run record powers the missed-run catch-up.
        update_option('mcqvs_cleanup_last_run', time());
        $this->log('cleanup.completed', $stats);
        return $stats;
    }

    /** True when a terminal job dir holds only the kept diagnostics. */
    private function dir_holds_only_logs($dir)
    {
        $entries = (array) @scandir($dir);
        $entries = array_values(array_diff($entries, array('.', '..')));
        foreach ($entries as $e) {
            if (! in_array($e, array('status.json', 'render.log', 'heartbeat'), true)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Legacy flat sweeper WITH active-job protection: any candidate whose
     * name embeds a valid job id belonging to a fresh active job is skipped.
     */
    private function prune_legacy_glob($dir, array $prefixes, $days, $dry_run, array &$stats)
    {
        $cutoff = time() - ((int) $days * DAY_IN_SECONDS);
        $seen   = array();
        $count  = 0;
        foreach ($prefixes as $prefix) {
            foreach ((array) @glob(trailingslashit($dir) . $prefix) as $f) {
                $key = wp_normalize_path($f);
                if (isset($seen[$key])) {
                    continue;
                }
                $seen[$key] = true;
                $stats['candidates']++;

                // Active-job guard (job id embedded in legacy names).
                if (preg_match('/mcqvs_[a-z_]+_(vs_[0-9a-f]{6,14}_\d{1,10})/', basename($f), $m)) {
                    $cls = $this->classify_job($m[1]);
                    if ($cls['class'] === 'active') {
                        $stats['skipped_active']++;
                        continue;
                    }
                }

                try {
                    $mtime = (int) @filemtime($f);
                } catch (\Throwable $e) {
                    $stats['failed']++;
                    continue;
                }
                if ($mtime === 0 || $mtime >= $cutoff) {
                    continue;
                }
                if (is_dir($f)) {
                    $bytes = $dry_run ? 0 : $this->dir_size($f);
                    if (! $dry_run) {
                        $this->rrmdir($f);
                        if (is_dir($f)) {
                            $stats['failed']++;
                            $this->log('cleanup.delete_failed', array('path' => basename($f)));
                            continue;
                        }
                    }
                    $stats['bytes'] += $bytes;
                    $count++;
                    continue;
                }
                $size = (int) @filesize($f);
                if (! $dry_run) {
                    if (! @unlink($f) && is_file($f)) {
                        $stats['failed']++;
                        $this->log('cleanup.delete_failed', array('path' => basename($f)));
                        continue;
                    }
                }
                $stats['bytes'] += $size;
                $count++;
            }
        }
        $stats['deleted'] += $count;
        return $count;
    }

    /** AJAX "Run cleanup now" (unchanged verb/nonce). */
    public function ajax_run_cleanup_now()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }
        $stats = $this->run_daily_artifact_prune();
        wp_send_json_success($stats);
    }

    // ------------------------------------------------------------------
    //  WALKERS / HELPERS (kept from pre-1.7.0, hardened)
    // ------------------------------------------------------------------

    private function prune_flat_dir($dir, $days, $dry_run, array &$stats)
    {
        if (! is_dir($dir)) {
            return 0;
        }
        $dir_norm = wp_normalize_path($dir);
        $cutoff   = time() - ((int) $days * DAY_IN_SECONDS);
        $count    = 0;
        try {
            $iter = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS),
                RecursiveIteratorIterator::CHILD_FIRST
            );
        } catch (\Throwable $e) {
            $stats['failed'] = ($stats['failed'] ?? 0) + 1;
            return 0;
        }
        try {
          foreach ($iter as $entry) {
            $path = $entry->getPathname();
            if (strpos(wp_normalize_path($path), $dir_norm) !== 0) {
                continue;
            }
            try {
                $mtime = $entry->getMTime();
            } catch (\Throwable $e) {
                continue;
            }
            if ($mtime >= $cutoff) {
                continue;
            }
            if ($entry->isDir()) {
                if (! $dry_run) {
                    @rmdir($path);
                }
                continue;
            }
            $size = (int) @filesize($path);
            if (! $dry_run) {
                if (! @unlink($path) && is_file($path)) {
                    $stats['failed'] = ($stats['failed'] ?? 0) + 1;
                    continue;
                }
            }
            $stats['bytes'] += $size;
            $count++;
          }
        } catch (\Throwable $e) {
            $stats['failed'] = ($stats['failed'] ?? 0) + 1;
        }
        return $count;
    }

    private function prune_batch_subdirs($base, $days, $dry_run, array &$stats)
    {
        if (! is_dir($base)) {
            return 0;
        }
        $cutoff = time() - ((int) $days * DAY_IN_SECONDS);
        $count  = 0;
        $job_dirs = (array) @glob($base . '/*', GLOB_ONLYDIR);
        $terminal_ids = $this->terminal_job_ids();
        foreach ($job_dirs as $job_dir) {
            $job_id = basename($job_dir);
            $mtime  = @filemtime($job_dir);
            if ($mtime === false || $mtime >= $cutoff) {
                continue;
            }
            $is_terminal = isset($terminal_ids[$job_id]);
            $is_unknown  = ! $this->job_exists($job_id);
            if (! $is_terminal && ! $is_unknown) {
                $stats['skipped_active'] = ($stats['skipped_active'] ?? 0) + 1;
                continue;
            }
            $subtree_bytes = $dry_run ? 0 : $this->dir_size($job_dir);
            if (! $dry_run) {
                $this->rrmdir($job_dir);
                if (is_dir($job_dir)) {
                    $stats['failed'] = ($stats['failed'] ?? 0) + 1;
                    continue;
                }
            }
            $stats['bytes'] += $subtree_bytes;
            $count++;
        }
        return $count;
    }

    private function uploads_base()
    {
        $u = wp_upload_dir();
        if (! empty($u['error']) || empty($u['basedir'])) {
            return '';
        }
        $base = trailingslashit($u['basedir']) . 'mcq-video-studio';
        if (! is_dir($base)) {
            return '';
        }
        return $base;
    }

    private function terminal_job_ids()
    {
        if ($this->terminal_cache !== null) {
            return $this->terminal_cache;
        }
        $this->terminal_cache = array();
        if (! class_exists('VS_Job_Repository')) {
            return $this->terminal_cache;
        }
        try {
            global $wpdb;
            $table = VS_Job_Repository::get_table_name();
            $placeholders = implode(',', array_fill(0, count(self::TERMINAL_STATUSES), '%s'));
            $sql = "SELECT job_id FROM {$table} WHERE status IN ({$placeholders})";
            $prepared = call_user_func_array(array($wpdb, 'prepare'), array_merge(array($sql), self::TERMINAL_STATUSES));
            foreach ((array) $wpdb->get_results($prepared, 'ARRAY_A') as $r) {
                if (! empty($r['job_id'])) {
                    $this->terminal_cache[(string) $r['job_id']] = true;
                }
            }
        } catch (\Throwable $e) {
            // empty cache — age-based fallback still applies
        }
        return $this->terminal_cache;
    }

    private function job_exists($job_id)
    {
        if ($job_id === '' || ! class_exists('VS_Job_Repository')) {
            return false;
        }
        try {
            global $wpdb;
            $table = VS_Job_Repository::get_table_name();
            return ! empty($wpdb->get_var($wpdb->prepare(
                "SELECT 1 FROM {$table} WHERE job_id = %s LIMIT 1",
                $job_id
            )));
        } catch (\Throwable $e) {
            return false;
        }
    }

    private function rrmdir($dir)
    {
        if (! is_dir($dir)) {
            return;
        }
        if (! $this->is_within_any_base($dir)) {
            // Only our own trees (any known base + uploads) are ever recursed.
            return;
        }
        try {
            $iter = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS),
                RecursiveIteratorIterator::CHILD_FIRST
            );
        } catch (\Throwable $e) {
            return;
        }
        try {
            foreach ($iter as $entry) {
                $path = $entry->getPathname();
                try {
                    $is_link = $entry->isLink();
                } catch (\Throwable $e) {
                    $is_link = false;
                }
                if ($is_link) {
                    @unlink($path);
                    continue;
                }
                if ($entry->isDir()) {
                    @rmdir($path);
                    continue;
                }
                @unlink($path);
            }
        } catch (\Throwable $e) {
            // permission-denied subtree: stop THIS dir, caller counts a failure
        }
        @rmdir($dir);
    }

    private function dir_size($dir)
    {
        $bytes = 0;
        try {
            $iter = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS),
                RecursiveIteratorIterator::LEAVES_ONLY
            );
        } catch (\Throwable $e) {
            return 0;
        }
        try {
            foreach ($iter as $entry) {
                try {
                    if ($entry->isLink()) {
                        continue;
                    }
                    $bytes += (int) $entry->getSize();
                } catch (\Throwable $e) {
                    // per-entry tolerance: one unreadable entry must not abort
                }
            }
        } catch (\Throwable $e) {
            // unreadable subdir (permissions) — return what we measured so far
        }
        return $bytes;
    }

    /** Structured log through the plugin's existing logger. */
    private function log($event, array $data)
    {
        if (class_exists('VS_Error_Logger')) {
            $msg = 'MCQVS ' . $event;
            if (! empty($data)) {
                $parts = array();
                foreach ($data as $k => $v) {
                    if (is_scalar($v)) {
                        $parts[] = $k . '=' . $v;
                    }
                }
                if ($parts) {
                    $msg .= ' ' . implode(' ', $parts);
                }
            }
            VS_Error_Logger::get_instance()->log($msg, 'info', array('_type' => 'artifact_cleanup', 'event' => $event, 'data' => $data));
        }
    }
}
