<?php
/**
 * Jetpack Social Integration & Stats
 *
 * @package SEO_Article_Generator
 */

namespace SEO_Article_Generator\Integration;

use SEO_Article_Generator\Logger;
use SEO_Article_Generator\Option_Registry;

if (!defined('ABSPATH')) {
    exit;
}

class Jetpack_Integration
{
    private $logger;

    public static $pending_tags = array();

    const SOCIAL_IMAGE_META_KEY  = '_seo_gen_social_collage_id';
    const JETPACK_META_KEY       = '_wpas_mess';
    const JETPACK_IMAGE_META     = '_wpas_media_src';
    const JETPACK_SOCIAL_OPTIONS = '_wpas_options';

    public function __construct(Logger $logger)
    {
        $this->logger = $logger;
    }

    public function register_hooks()
    {
        add_action('transition_post_status', array($this, 'handle_status_transition'), 5, 3);

        add_filter('jetpack_images_get_images', array($this, 'force_jetpack_collage_image'), 0, 3);

        add_filter('wpas_submit_post?', array($this, 'filter_jetpack_network'), 10, 4);
    }

    private function is_ai_post($post_id)
    {
        if (get_post_meta($post_id, '_seo_gen_regen_sections', true) || get_post_meta($post_id, 'seogenherodata', true)) {
            return true;
        }

        if (version_compare(PHP_VERSION, '5.3.6', '>=')) {
            $trace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 15);
        } else {
            $trace = debug_backtrace(false);
        }

        foreach ($trace as $frame) {
            if (isset($frame['class'], $frame['function']) &&
                $frame['class'] === 'SEO_Article_Generator\\Jobs\\Job_Handler' &&
                $frame['function'] === 'finalize_generated_post') {
                return true;
            }
        }

        return false;
    }

    public function handle_status_transition($new_status, $old_status, $post)
    {
        if ($new_status !== 'publish') {
            return;
        }

        if ($new_status === $old_status) {
            return;
        }

        if (!$this->is_ai_post($post->ID)) {
            return;
        }

        $enabled = get_option(Option_Registry::JETPACK_ENABLED, false);
        if (!$enabled) {
            return;
        }

        $this->sync_to_jetpack($post->ID);
    }

    public function sync_to_jetpack($post_id)
    {
        $global_template = get_option(Option_Registry::JETPACK_TEMPLATE, "{title}\n\n{excerpt}\n\n{tags}\n\n{link}");
        $network_templates = get_option(Option_Registry::JETPACK_NETWORK_TEMPLATES, array());
        $selected_networks = get_option(Option_Registry::JETPACK_NETWORKS, array());

        $post = get_post($post_id);
        if (!$post) {
            $this->logger->error("Jetpack Integration: Post {$post_id} not found for sync.");
            return false;
        }

        $title = $post->post_title;
        $excerpt = wp_strip_all_tags($post->post_excerpt ?: wp_trim_words($post->post_content, 40));
        // [FIX] Social hashtags must be ONLY AI-generated, SEO-optimized tags and must
        // NOT include source post tags, slugs or categories. Source priority:
        //   1) in-memory AI tags set during finalize (self::$pending_tags)
        //   2) persisted AI tags from post meta (survives watchdog publishes)
        //   3) global DEFAULT_TAGS option fallback
        $tags_array = array();
        if (!empty(self::$pending_tags)) {
            $tags_array = self::$pending_tags;
        } elseif ($ai_tags = get_post_meta($post_id, '_seo_gen_ai_tags', true)) {
            $tags_array = is_array($ai_tags) ? $ai_tags : array();
        } else {
            $default_tags = get_option(Option_Registry::DEFAULT_TAGS, array());
            if (is_string($default_tags)) {
                $default_tags = array_filter(array_map('trim', explode(',', $default_tags)), static function ($t) {
                    return $t !== '';
                });
            }
            $tags_array = is_array($default_tags) ? $default_tags : array();
        }
        // [FIX] Enforce STRICT single-token hashtags. Strip any leading '#', remove
        // spaces and all non-hashtag characters so a value like "media player" becomes
        // "mediaplayer" (never "#media player"). Guarantees no multi-word hashtags even
        // if the AI or DEFAULT_TAGS supplies them.
        $tags_array = array_filter(array_map(static function ($t) {
            $t = trim((string) $t);
            $t = ltrim($t, '#');
            $t = preg_replace('/[^A-Za-z0-9_]/', '', $t);
            return $t;
        }, $tags_array), static function ($t) {
            return $t !== '';
        });
        $tags = !empty($tags_array) ? '#' . implode(' #', $tags_array) : '';
        $link = get_permalink($post_id);

        $message_data = array(
            '{title}'   => $title,
            '{excerpt}' => $excerpt,
            '{tags}'    => $tags,
            '{link}'    => $link,
        );

        $message = str_replace(array_keys($message_data), array_values($message_data), $global_template);
        $message = preg_replace("/\n{3,}/", "\n\n", trim($message));
        update_post_meta($post_id, self::JETPACK_META_KEY, $message);

        $valid_types = array(
            'facebook'  => array('post', 'story', 'reel'),
            'instagram' => array('post', 'story', 'reel'),
            'twitter'   => array('post'),
            'linkedin'  => array('post'),
            'tumblr'    => array('post'),
            'mastodon'  => array('post'),
            'threads'   => array('post', 'story'),
            'bluesky'   => array('post'),
        );

        if (class_exists('\Jetpack\Publicize') && method_exists('\Jetpack\Publicize', 'get_connections')) {
            try {
                $publicize = new \Jetpack\Publicize();
                $connections = $publicize->get_connections('post', $post_id);
                foreach ($connections as $conn) {
                    $conn_id = isset($conn['id']) ? $conn['id'] : (isset($conn['connection_id']) ? $conn['connection_id'] : '');
                    $service_name = isset($conn['service_name']) ? strtolower($conn['service_name']) : '';
                    if (empty($conn_id) || empty($service_name)) {
                        continue;
                    }

                    $conn_post_type = 'post';
                    if (isset($selected_networks[$service_name . '_type'])) {
                        $requested_type = $selected_networks[$service_name . '_type'];
                        $allowed = isset($valid_types[$service_name]) ? $valid_types[$service_name] : array('post');
                        if (in_array($requested_type, $allowed, true)) {
                            $conn_post_type = $requested_type;
                        }
                    }

                    $custom_template = isset($network_templates[$service_name]) ? $network_templates[$service_name] : '';
                    if (!empty($custom_template) && trim($custom_template) !== trim($global_template)) {
                        $custom_message = str_replace(array_keys($message_data), array_values($message_data), $custom_template);
                        $custom_message = preg_replace("/\n{3,}/", "\n\n", trim($custom_message));
                        update_post_meta($post_id, self::JETPACK_META_KEY . '_' . $conn_id, $custom_message);
                    } else {
                        delete_post_meta($post_id, self::JETPACK_META_KEY . '_' . $conn_id);
                    }
                }
            } catch (\Throwable $e) {
                $this->logger->warning("Jetpack Integration: Could not fetch connections — " . $e->getMessage());
            }
        }

        $share_url = $this->resolve_collage_url($post_id);

        if (!empty($share_url)) {
            $collage_id = (int) get_post_meta($post_id, self::SOCIAL_IMAGE_META_KEY, true);
            update_post_meta($post_id, self::JETPACK_IMAGE_META, $share_url);
            $this->update_jetpack_social_options($post_id, $collage_id, $share_url);
        } else {
            $thumb_id = (int) get_post_thumbnail_id($post_id);
            if ($thumb_id) {
                $thumb_url = wp_get_attachment_url($thumb_id);
                update_post_meta($post_id, self::JETPACK_IMAGE_META, $thumb_url);
                $this->update_jetpack_social_options($post_id, $thumb_id, $thumb_url, 'featured-image');
            } else {
                delete_post_meta($post_id, self::JETPACK_IMAGE_META);
                delete_post_meta($post_id, self::JETPACK_SOCIAL_OPTIONS);
            }
        }

        $this->logger->info("Jetpack Integration: Synced post {$post_id} for social sharing.");
        return true;
    }

    public function force_jetpack_collage_image($images, $post_id, $args)
    {
        if (!get_option(Option_Registry::JETPACK_ENABLED, false)) {
            return $images;
        }

        $context = isset($args['context']) ? $args['context'] : '';
        if (!in_array($context, array('publicize', 'opengraph', 'twitter', ''), true)) {
            return $images;
        }

        $collage_url = $this->resolve_collage_url($post_id);
        if (empty($collage_url)) {
            $thumb_id = (int) get_post_thumbnail_id($post_id);
            if ($thumb_id) {
                $collage_url = wp_get_attachment_url($thumb_id);
            }
            if (empty($collage_url)) {
                return $images;
            }
        }

        if (!is_array($images)) {
            $images = array();
        }

        array_unshift($images, array(
            'type' => 'image',
            'from' => 'custom',
            'src'  => $collage_url,
            'href' => $collage_url,
        ));

        $current_media_src = get_post_meta($post_id, self::JETPACK_IMAGE_META, true);
        if ($current_media_src !== $collage_url) {
            update_post_meta($post_id, self::JETPACK_IMAGE_META, $collage_url);
        }
        $collage_id = (int) get_post_meta($post_id, self::SOCIAL_IMAGE_META_KEY, true);
        if ($collage_id) {
            $existing_options = (array) get_post_meta($post_id, self::JETPACK_SOCIAL_OPTIONS, true);
            $existing_media = isset($existing_options['attached_media'][0]['url']) ? $existing_options['attached_media'][0]['url'] : '';
            if ($existing_media !== $collage_url) {
                $this->update_jetpack_social_options($post_id, $collage_id, $collage_url);
            }
        }

        return $images;
    }

    public function filter_jetpack_network($should_share, $post_id, $service_name, $connection)
    {
        if (!get_option(Option_Registry::JETPACK_ENABLED, false)) {
            return $should_share;
        }

        $networks = (array) get_option(Option_Registry::JETPACK_NETWORKS, array());
        $initialized = (bool) get_option(Option_Registry::JETPACK_NETWORKS_INITIALIZED, false);

        if (!$initialized && empty($networks)) {
            $known = array('facebook', 'instagram', 'threads', 'linkedin', 'tumblr', 'mastodon', 'nextdoor', 'bluesky');
            foreach ($known as $svc) {
                $networks[$svc] = true;
            }
            update_option(Option_Registry::JETPACK_NETWORKS, $networks);
            update_option(Option_Registry::JETPACK_NETWORKS_INITIALIZED, true);
        } elseif ($initialized && empty($networks)) {
            return false;
        }

        $service_name = strtolower($service_name);

        if (!isset($networks[$service_name])) {
            return $should_share;
        }

        return !empty($networks[$service_name]);
    }

    public static function update_jetpack_social_options($post_id, $media_id, $media_url, $source = 'media-library')
    {
        $options = (array) get_post_meta($post_id, self::JETPACK_SOCIAL_OPTIONS, true);
        $options['attached_media'] = array(
            array('id' => $media_id, 'url' => $media_url, 'type' => 'image'),
        );
        $options['media_source'] = $source;
        update_post_meta($post_id, self::JETPACK_SOCIAL_OPTIONS, $options);
    }

    public function resolve_collage_url($post_id)
    {
        $collage_id = (int) get_post_meta($post_id, self::SOCIAL_IMAGE_META_KEY, true);
        if (!$collage_id) {
            return '';
        }

        $attachment = get_post($collage_id);
        if (!$attachment || $attachment->post_type !== 'attachment') {
            return '';
        }

        $url = wp_get_attachment_url($collage_id);
        if (is_string($url) && !empty($url)) {
            return $url;
        }

        $parent = (int) $attachment->post_parent;
        if ($parent > 0 && $parent !== $post_id) {
            wp_update_post(array('ID' => $collage_id, 'post_parent' => $post_id));
            $url = wp_get_attachment_url($collage_id);
            return is_string($url) ? $url : '';
        }

        return '';
    }

    /**
     * Get Jetpack Stats (traffic/visitors) for the site
     *
     * @param string $period 'day', 'week', 'month', 'year'
     * @return array
     */
    public function get_site_stats($period = 'day')
    {
        $stats = array(
            'views'           => 0,
            'visitors'        => 0,
            'period'          => $period,
            'top_posts'       => array(),
            'referrers'       => array(),
            'search_terms'    => array(),
            'clicks'          => 0,
            'error'           => '',
        );

        // Check if Jetpack Stats module is active
        if (!class_exists('Jetpack_Stats')) {
            $stats['error'] = 'Jetpack Stats module not active';
            return $stats;
        }

        try {
            // Get views and visitors for the period
            $end_date = date('Y-m-d');
            $start_date = $this->get_period_start_date($period);

            // Use Jetpack Stats API
            $views = $this->get_views($start_date, $end_date);
            $visitors = $this->get_visitors($start_date, $end_date);
            $top_posts = $this->get_top_posts($start_date, $end_date, 10);
            $referrers = $this->get_referrers($start_date, $end_date, 10);
            $search_terms = $this->get_search_terms($start_date, $end_date, 10);

            $stats['views'] = (int) $views;
            $stats['visitors'] = (int) $visitors;
            $stats['top_posts'] = $top_posts;
            $stats['referrers'] = $referrers;
            $stats['search_terms'] = $search_terms;
        } catch (\Throwable $e) {
            $this->logger->error('Jetpack Stats error: ' . $e->getMessage());
            $stats['error'] = $e->getMessage();
        }

        return $stats;
    }

    /**
     * Get start date for period
     */
    private function get_period_start_date($period)
    {
        switch ($period) {
            case 'day':
                return date('Y-m-d');
            case 'week':
                return date('Y-m-d', strtotime('-7 days'));
            case 'month':
                return date('Y-m-d', strtotime('-30 days'));
            case 'year':
                return date('Y-m-d', strtotime('-365 days'));
            default:
                return date('Y-m-d');
        }
    }

    /**
     * Get total views for date range
     */
    private function get_views($start_date, $end_date)
    {
        if (function_exists('stats_get_csv')) {
            $result = stats_get_csv('postviews', array(
                'period' => 'custom',
                'start_date' => $start_date,
                'end_date' => $end_date,
                'summarize' => true,
            ));
            if (is_array($result) && !empty($result[0]['views'])) {
                return $result[0]['views'];
            }
        }
        return 0;
    }

    /**
     * Get total visitors for date range
     */
    private function get_visitors($start_date, $end_date)
    {
        if (function_exists('stats_get_csv')) {
            $result = stats_get_csv('postviews', array(
                'period' => 'custom',
                'start_date' => $start_date,
                'end_date' => $end_date,
                'summarize' => true,
            ));
            if (is_array($result) && !empty($result[0]['visitors'])) {
                return $result[0]['visitors'];
            }
        }
        return 0;
    }

    /**
     * Get top posts for date range
     */
    private function get_top_posts($start_date, $end_date, $limit = 10)
    {
        if (!function_exists('stats_get_csv')) {
            return array();
        }

        $result = stats_get_csv('postviews', array(
            'period' => 'custom',
            'start_date' => $start_date,
            'end_date' => $end_date,
            'limit' => $limit,
        ));

        $posts = array();
        if (is_array($result)) {
            foreach ($result as $row) {
                $post_id = isset($row['post_id']) ? (int) $row['post_id'] : 0;
                $title = $post_id > 0 ? get_the_title($post_id) : (isset($row['title']) ? $row['title'] : 'Unknown');
                $posts[] = array(
                    'post_id' => $post_id,
                    'title'   => $title,
                    'url'     => $post_id > 0 ? get_permalink($post_id) : (isset($row['permalink']) ? $row['permalink'] : ''),
                    'views'   => isset($row['views']) ? (int) $row['views'] : 0,
                );
            }
        }
        return $posts;
    }

    /**
     * Get referrers for date range
     */
    private function get_referrers($start_date, $end_date, $limit = 10)
    {
        if (!function_exists('stats_get_csv')) {
            return array();
        }

        $result = stats_get_csv('referrers', array(
            'period' => 'custom',
            'start_date' => $start_date,
            'end_date' => $end_date,
            'limit' => $limit,
        ));

        $referrers = array();
        if (is_array($result)) {
            foreach ($result as $row) {
                $referrers[] = array(
                    'referrer' => isset($row['referrer']) ? $row['referrer'] : 'Direct',
                    'views'    => isset($row['views']) ? (int) $row['views'] : 0,
                );
            }
        }
        return $referrers;
    }

    /**
     * Get search terms for date range
     */
    private function get_search_terms($start_date, $end_date, $limit = 10)
    {
        if (!function_exists('stats_get_csv')) {
            return array();
        }

        $result = stats_get_csv('searchterms', array(
            'period' => 'custom',
            'start_date' => $start_date,
            'end_date' => $end_date,
            'limit' => $limit,
        ));

        $terms = array();
        if (is_array($result)) {
            foreach ($result as $row) {
                $terms[] = array(
                    'term'  => isset($row['term']) ? $row['term'] : '',
                    'views' => isset($row['views']) ? (int) $row['views'] : 0,
                );
            }
        }
        return $terms;
    }

    /**
     * Check if Jetpack Stats is available
     */
    public static function is_stats_available()
    {
        return class_exists('Jetpack_Stats') || function_exists('stats_get_csv');
    }
}
