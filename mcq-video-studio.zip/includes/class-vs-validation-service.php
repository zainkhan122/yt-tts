<?php

/**
 * Validation Service
 *
 * Ensures data integrity before hitting the storage layer.
 *
 * @package MCQ_Video_Studio
 */

if (! defined('ABSPATH')) {
    exit;
}

class VS_Validation_Service
{

    /**
     * Validate MCQ structure and content limits.
     *
     * @param array $data Raw MCQ data from AI
     * @return true|WP_Error
     */
    public static function validate_mcq_structure($data)
    {

        // 1. Basic Fields
        if (empty($data['question_text'])) {
            return new WP_Error('invalid_content', 'Question text is missing.');
        }

        // 2. Options Check
        if (! isset($data['options']) || ! is_array($data['options'])) {
            return new WP_Error('invalid_options', 'Options must be an array.');
        }

        if (count($data['options']) !== 4) {
            // Strict requirement for Video Studio templates
            return new WP_Error('invalid_option_count', 'MCQ must have exactly 4 options.');
        }

        // 3. Conciseness Limits (Visual Safety)
        if (strlen($data['question_text']) > 180) {
            return new WP_Error('text_too_long', 'Question exceeds 180 characters. Video templates may break.');
        }

        foreach ($data['options'] as $opt) {
            if (strlen($opt) > 80) {
                return new WP_Error('option_too_long', 'Option exceeds 80 characters: ' . substr($opt, 0, 20) . '...');
            }
        }

        // 4. Correct Answer Index
        if (! isset($data['correct_index']) || ! is_numeric($data['correct_index'])) {
            return new WP_Error('invalid_index', 'Correct index is missing.');
        }

        $idx = intval($data['correct_index']);
        if ($idx < 0 || $idx > 3) {
            return new WP_Error('index_out_of_bounds', "Correct index ($idx) must be between 0 and 3.");
        }

        return true;
    }
}
