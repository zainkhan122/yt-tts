/**
 * NM Animation Engine
 * Professional animation system for Quiz Shorts Studio
 *
 * Provides easing functions, kinetic typography, transitions, and camera effects
 *
 * @package WP_News_MCQ_Generator
 * @version 1.0.0
 */

(function (window) {
  "use strict";

    const MCQVS_AnimationEngine = {

    // @NEW 2026-04-22: Deterministic seeded RNG for preview/renderer parity
    _seed: 12345,
    setSeed(s) { this._seed = s; },
    seededRandom() {
        this._seed = (this._seed * 1664525 + 1013904223) & 0xFFFFFFFF;
        return (this._seed >>> 0) / 0xFFFFFFFF;
    },

    // ==========================================
    // EASING FUNCTIONS
    // Standard easing curves for smooth animations
    // ==========================================
    easing: {
      // Linear
      linear: (t) => t,

      // Quad
      easeInQuad: (t) => t * t,
      easeOutQuad: (t) => t * (2 - t),
      easeInOutQuad: (t) => (t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t),

      // Cubic
      easeInCubic: (t) => t * t * t,
      easeOutCubic: (t) => --t * t * t + 1,
      easeInOutCubic: (t) =>
        t < 0.5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1,

      // Quart
      easeInQuart: (t) => t * t * t * t,
      easeOutQuart: (t) => 1 - --t * t * t * t,
      easeInOutQuart: (t) =>
        t < 0.5 ? 8 * t * t * t * t : 1 - 8 * --t * t * t * t,

      // Expo
      easeInExpo: (t) => (t === 0 ? 0 : Math.pow(2, 10 * (t - 1))),
      easeOutExpo: (t) => (t === 1 ? 1 : 1 - Math.pow(2, -10 * t)),
      easeInOutExpo: (t) => {
        if (t === 0 || t === 1) return t;
        if (t < 0.5) return Math.pow(2, 20 * t - 10) / 2;
        return (2 - Math.pow(2, -20 * t + 10)) / 2;
      },

      // Back (overshoots)
      easeInBack: (t) => t * t * (2.70158 * t - 1.70158),
      easeOutBack: (t) => 1 + --t * t * (2.70158 * t + 1.70158),
      easeInOutBack: (t) => {
        const c = 1.70158 * 1.525;
        return t < 0.5
          ? (Math.pow(2 * t, 2) * ((c + 1) * 2 * t - c)) / 2
          : (Math.pow(2 * t - 2, 2) * ((c + 1) * (t * 2 - 2) + c) + 2) / 2;
      },

      // Bounce
      easeOutBounce: (t) => {
        const n1 = 7.5625,
          d1 = 2.75;
        if (t < 1 / d1) return n1 * t * t;
        if (t < 2 / d1) return n1 * (t -= 1.5 / d1) * t + 0.75;
        if (t < 2.5 / d1) return n1 * (t -= 2.25 / d1) * t + 0.9375;
        return n1 * (t -= 2.625 / d1) * t + 0.984375;
      },
      easeInBounce: (t) => 1 - MCQVS_AnimationEngine.easing.easeOutBounce(1 - t),

      // Elastic
      easeOutElastic: (t) => {
        if (t === 0 || t === 1) return t;
        return (
          Math.pow(2, -10 * t) *
          Math.sin(((t * 10 - 0.75) * (2 * Math.PI)) / 3) +
          1
        );
      },
      easeInElastic: (t) => {
        if (t === 0 || t === 1) return t;
        return (
          -Math.pow(2, 10 * t - 10) *
          Math.sin(((t * 10 - 10.75) * (2 * Math.PI)) / 3)
        );
      },

      // @NEW 2025-12-18: Advanced Professional Easings
      smoothStep: (t) => t * t * (3 - 2 * t),
      backOut: (t) => {
        const s = 1.70158;
        return --t * t * ((s + 1) * t + s) + 1;
      },
      anticipate: (t) => {
        const s = 1.70158;
        if (t < 0.5) return 0.5 * (t *= 2) * t * ((s + 1) * t - s);
        return 0.5 * ((t = t * 2 - 2) * t * ((s + 1) * t + s) + 2);
      },
    },

    // ==========================================
    // UTILITIES
    // Helper functions for visual processing
    // ==========================================
    utils: {
      /**
       * Apply motion blur by accumulating multiple offset renders
       * @param {CanvasRenderingContext2D} ctx
       * @param {Function} drawFn - The drawing function to blur
       * @param {number} velocityX
       * @param {number} velocityY
       * @param {number} samples - Number of blur samples (8-12 recommended)
       */
      motionBlur: function (ctx, drawFn, velocityX, velocityY, samples = 8) {
        if (velocityX === 0 && velocityY === 0) {
          drawFn(ctx);
          return;
        }

        const alpha = 1 / samples;
        ctx.save();
        ctx.globalAlpha = alpha;

        for (let i = 0; i < samples; i++) {
          const t = i / (samples - 1);
          const offX = velocityX * (t - 0.5);
          const offY = velocityY * (t - 0.5);

          ctx.save();
          ctx.translate(offX, offY);
          drawFn(ctx);
          ctx.restore();
        }

        ctx.restore();
      },
    },

    // ==========================================
    // KINETIC TYPOGRAPHY
    // Word-by-word and character-level text animations
    // ==========================================
    kineticText: {
      /**
       * @NEW 2025-12-18: Render text with professional effects
       */
      drawStyled: function (ctx, text, x, y, options = {}) {
        if (window.MCQVS_TextEffects) {
          return window.MCQVS_TextEffects.drawStyledText(ctx, text, x, y, options);
        }
        // Fallback to simple fill
        ctx.fillText(text, x, y);
      },

      /**
       * Render text word-by-word with animation
       * @param {CanvasRenderingContext2D} ctx
       * @param {string} text
       * @param {number} x - Center X position
       * @param {number} y - Base Y position
       * @param {object} options
       */
      wordByWord: function (ctx, text, x, y, options = {}) {
        const defaults = {
          elapsed: 0,
          duration: 2000,
          delayPerWord: 100,
          maxWidth: 900,
          lineHeight: 60,
          fontSize: 48,
          fontWeight: "bold",
          fontFamily: "Outfit, sans-serif",
          fill: "#FFFFFF",
          stroke: "#000000",
          strokeWidth: 3,
          align: "center",
          effect: "popIn",
          shadow: true,
        };
        const opts = { ...defaults, ...options };

        if (!text || typeof text !== "string") return y;

        // @NEW 2026-01-08: Kinetic Layout Cache to fix FPS drops
        if (!this._cache) this._cache = {};
        const cacheKey = `${text}:${opts.maxWidth}:${opts.fontSize}:${opts.fontWeight}:${opts.fontFamily}:${opts.align}`;
        let cache = this._cache[cacheKey];

        const words = text.split(/\s+/);
        const wordCount = words.length;
        const wordDuration = opts.duration / wordCount;

        ctx.save();
        ctx.font = `${opts.fontWeight} ${opts.fontSize}px ${opts.fontFamily}`;
        ctx.textAlign = opts.align;
        ctx.textBaseline = "middle";

        if (!cache) {
          // Calculate line breaks and word positions ONCE
          const lines = [];
          let currentLine = [];
          let currentWidth = 0;

          words.forEach((word) => {
            const wordWidth = ctx.measureText(word + " ").width;
            if (
              currentWidth + wordWidth > opts.maxWidth &&
              currentLine.length > 0
            ) {
              lines.push(currentLine);
              currentLine = [word];
              currentWidth = wordWidth;
            } else {
              currentLine.push(word);
              currentWidth += wordWidth;
            }
          });
          if (currentLine.length > 0) lines.push(currentLine);

          // Calculate absolute word positions within lines
          const processedLines = lines.map((line) => {
            const lineText = line.join(" ");
            const lineWidth = ctx.measureText(lineText).width;
            let currentX = x - lineWidth / 2;

            return line.map((word) => {
              const wordWidth = ctx.measureText(word).width;
              const spaceWidth = ctx.measureText(" ").width;
              const wX = currentX + wordWidth / 2;
              const res = { word, x: wX, width: wordWidth, space: spaceWidth };
              currentX += wordWidth + spaceWidth;
              return res;
            });
          });

          cache = { lines: processedLines };
          this._cache[cacheKey] = cache;
        }

        const lines = cache.lines;

        // Render each word with animation
        let wordIndex = 0;
        lines.forEach((line, lineIdx) => {
          const lineY = y + lineIdx * opts.lineHeight;

          line.forEach((wordObj) => {
            const { word, x: wordX, width: wordWidth, space: spaceWidth } = wordObj;
            const wordStartTime = wordIndex * opts.delayPerWord;
            const wordProgress = Math.max(
              0,
              Math.min(1, (opts.elapsed - wordStartTime) / wordDuration)
            );

            if (wordProgress > 0) {
              // Apply effect
              ctx.save();
              let alpha = 1;
              let scale = 1;
              let offsetY = 0;

              switch (opts.effect) {
                case "popIn":
                  const popEase =
                    MCQVS_AnimationEngine.easing.easeOutBack(wordProgress);
                  scale = popEase;
                  alpha = Math.min(1, wordProgress * 2);
                  break;
                case "slideUp":
                  const slideEase =
                    MCQVS_AnimationEngine.easing.easeOutCubic(wordProgress);
                  offsetY = (1 - slideEase) * 50;
                  alpha = slideEase;
                  break;
                case "fadeIn":
                  alpha = MCQVS_AnimationEngine.easing.easeOutQuad(wordProgress);
                  break;
                case "bounce":
                  const bounceEase =
                    MCQVS_AnimationEngine.easing.easeOutBounce(wordProgress);
                  scale = bounceEase;
                  offsetY = (1 - bounceEase) * -30;
                  alpha = Math.min(1, wordProgress * 3);
                  break;
              }

              ctx.globalAlpha = alpha;
              ctx.translate(wordX, lineY + offsetY);
              ctx.scale(scale, scale);

              // Shadow
              if (opts.shadow) {
                ctx.shadowColor = "rgba(0, 0, 0, 0.7)";
                ctx.shadowBlur = 10;
                ctx.shadowOffsetX = 3;
                ctx.shadowOffsetY = 3;
              }

              // Stroke
              if (opts.stroke && opts.strokeWidth > 0) {
                ctx.strokeStyle = opts.stroke;
                ctx.lineWidth = opts.strokeWidth;
                ctx.strokeText(word, 0, 0);
              }

              // Fill
              ctx.fillStyle = opts.fill;
              ctx.fillText(word, 0, 0);

              ctx.restore();
            }

            wordIndex++;
          });
        });

        ctx.restore();
        return y + lines.length * opts.lineHeight;
      },

      /**
       * Typewriter effect - character by character
       */
      typewriter: function (ctx, text, x, y, options = {}) {
        const defaults = {
          elapsed: 0,
          duration: 1500,
          fontSize: 48,
          fontWeight: "bold",
          fontFamily: "Outfit, sans-serif",
          fill: "#FFFFFF",
          stroke: "#000000",
          strokeWidth: 2,
          cursorBlink: true,
        };
        const opts = { ...defaults, ...options };

        if (!text) return;

        const progress = Math.min(1, opts.elapsed / opts.duration);
        const charsToShow = Math.floor(progress * text.length);
        const visibleText = text.substring(0, charsToShow);

        ctx.save();
        ctx.font = `${opts.fontWeight} ${opts.fontSize}px ${opts.fontFamily}`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";

        // Stroke
        if (opts.strokeWidth > 0) {
          ctx.strokeStyle = opts.stroke;
          ctx.lineWidth = opts.strokeWidth;
          ctx.strokeText(visibleText, x, y);
        }

        // Fill
        ctx.fillStyle = opts.fill;
        ctx.fillText(visibleText, x, y);

        // Cursor
        if (opts.cursorBlink && charsToShow < text.length) {
          const cursorVisible = Math.floor(opts.elapsed / 300) % 2 === 0;
          if (cursorVisible) {
            const textWidth = ctx.measureText(visibleText).width;
            ctx.fillRect(
              x + textWidth / 2 + 5,
              y - opts.fontSize / 2,
              3,
              opts.fontSize
            );
          }
        }

        ctx.restore();
      },

      /**
       * @NEW 2025-12-18: Non-Linear Dynamic Captions
       * Prevents drift by weighing word duration by character length
       */
      dynamicCaptions: function (ctx, text, x, y, options = {}) {
        const defaults = {
          elapsed: 0,
          totalDuration: 2000,
          highlightColor: "#FFFF00",
          fontSize: 64,
          fontWeight: "900",
          fontFamily: "Outfit, sans-serif",
          maxWidth: 900,
          align: "center",
          strokeWidth: 5,
        };
        const opts = { ...defaults, ...options };

        if (!text) return;

        const words = text.split(/\s+/);

        // --- NON-LINEAR TIMING MODEL ---
        // 1. Calculate weights (character length + transition buffer)
        const weights = words.map((w) => Math.max(2, w.length));
        const totalWeight = weights.reduce((a, b) => a + b, 0);

        // 2. Map word to time intervals
        let cumulativeTime = 0;
        const intervals = words.map((w, i) => {
          const duration = (weights[i] / totalWeight) * opts.totalDuration;
          const start = cumulativeTime;
          cumulativeTime += duration;
          return { start, end: cumulativeTime };
        });

        // 3. Find current word
        const currentWordIdx = intervals.findIndex(
          (interval) =>
            opts.elapsed >= interval.start && opts.elapsed < interval.end
        );

        ctx.save();
        ctx.font = `${opts.fontWeight} ${opts.fontSize}px ${opts.fontFamily}`;
        ctx.textAlign = opts.align;
        ctx.textBaseline = "middle";

        const lineWidth = ctx.measureText(text).width;
        let currentX = x - lineWidth / 2;

        words.forEach((word, idx) => {
          const wordWidth = ctx.measureText(word).width;
          const wordX = currentX + wordWidth / 2;

          ctx.save();
          if (idx === currentWordIdx) {
            // Apply "Hormozi" Pop effect
            ctx.fillStyle = opts.highlightColor;
            ctx.shadowColor = opts.highlightColor;
            ctx.shadowBlur = 20;

            // Bounce/Scale animation for active word
            const interval = intervals[idx];
            const wordElapsed = opts.elapsed - interval.start;
            const wordDuration = interval.end - interval.start;
            const wordProgress = wordElapsed / wordDuration;
            const scale = 1.15 + Math.sin(wordProgress * Math.PI) * 0.1;

            ctx.scale(scale, scale);
            ctx.strokeText(word, wordX / scale, y / scale);
            ctx.fillText(word, wordX / scale, y / scale);
          } else {
            ctx.fillStyle = "#FFFFFF";
            ctx.strokeStyle = "#000000";
            ctx.lineWidth = opts.strokeWidth;
            ctx.strokeText(word, wordX, y);
            ctx.fillText(word, wordX, y);
          }
          ctx.restore();
          currentX += wordWidth + ctx.measureText(" ").width;
        });

        ctx.restore();
      },
    },

    // ==========================================
    // TRANSITIONS
    // Visual transitions between scenes/questions
    // ==========================================
    transitions: {
      // Current transition state
      _active: null,
      _startTime: 0,
      _duration: 400,
      _buffer: null, // Offscreen canvas for buffering

      /**
       * Start a transition
       * @param {string} type - Transition type
       * @param {number} duration - Duration in ms
       * @param {HTMLCanvasElement} currentCanvas - Current canvas to buffer
       */
      start: function (type, duration = 400, currentCanvas = null, manualStartTime = null) {
        this._active = type;
        this._manualTimeline = manualStartTime !== null;
        this._startTime = manualStartTime !== null ? manualStartTime : Date.now();
        this._duration = duration;

        if (currentCanvas) {
          if (!this._buffer) {
            this._buffer = document.createElement("canvas");
            this._buffer.width = currentCanvas.width;
            this._buffer.height = currentCanvas.height;
          }
          const bCtx = this._buffer.getContext("2d");
          bCtx.clearRect(0, 0, this._buffer.width, this._buffer.height);
          bCtx.drawImage(currentCanvas, 0, 0);
        }
      },

      /**
       * Check if transition is active
       */
      isActive: function (manualElapsed = null) {
        if (!this._active) return false;

        // Normalize timebase
        let elapsed;
        if (this._manualTimeline && manualElapsed !== null) {
          elapsed = manualElapsed - this._startTime;
        } else {
          elapsed = Date.now() - this._startTime;
        }

        if (elapsed >= this._duration) {
          this._active = null;
          return false;
        }
        return true;
      },

      /**
       * Get transition progress (0-1)
       */
      getProgress: function (manualElapsed = null) {
        if (!this._active) return 1;

        let elapsed;
        if (this._manualTimeline && manualElapsed !== null) {
          elapsed = manualElapsed - this._startTime;
        } else {
          // Fallback for live mode or missing manual time
          const time = manualElapsed !== null ? manualElapsed : Date.now() - this._startTime;
          // If manualElapsed is passed in live mode (e.g. from drawFrame with timestamp), it might be handled like this.
          // But let's stick to the cleanest interpretation of the request:
          // "compute manualElapsed - _startTime when manual mode"
          if (this._manualTimeline && manualElapsed === null) {
            // Edge case: manual mode but no time provided
            elapsed = 0;
          } else {
            // Live mode or legacy handling
            elapsed = (manualElapsed !== null && !this._manualTimeline) ? manualElapsed : Date.now() - this._startTime;
          }
        }

        return Math.min(1, elapsed / this._duration);
      },

      /**
       * Apply current transition effect to canvas
       */
      apply: function (ctx, width, height, manualElapsed = null) {
        if (!this._active) return;

        const progress = this.getProgress(manualElapsed);
        // @FIX 2026-01-28: Self-clearing mechanism to prevent infinite transition overlays
        if (progress >= 1) {
          this._active = null;
          return;
        }

        const eased = MCQVS_AnimationEngine.easing.easeInOutQuad(progress);

        // Motion blur calculation: simple velocity based on progress change
        // In deterministic mode, we can calculate actual pixels/frame
        const velocityScale = 150; // Adjust for intensity
        const velocity = (1 - progress) * velocityScale;

        switch (this._active) {
          case "fadeZoom":
            this._fadeZoom(ctx, width, height, eased);
            break;
          case "slideLeft":
            this._slideWithBlur(ctx, width, height, eased, "left", velocity);
            break;
          case "slideRight":
            this._slideWithBlur(ctx, width, height, eased, "right", velocity);
            break;
          case "swipeUp":
            this._swipeUp(ctx, width, height, eased);
            break;
          case "flashWhite":
            this._flashWhite(ctx, width, height, eased);
            break;
          case "zoomBlur":
            this._zoomBlur(ctx, width, height, eased);
            break;
          case "pixelate":
            this._pixelate(ctx, width, height, eased);
            break;
          case "glitch":
            this._glitch(ctx, width, height, eased);
            break;
        }
      },

      /**
       * New Slide transition with integrated motion blur
       */
      _slideWithBlur: function (ctx, w, h, progress, dir, velocity) {
        const offset = (1 - progress) * w * (dir === "left" ? 1 : -1);

        const drawFn = (c) => {
          if (this._buffer) {
            c.drawImage(this._buffer, offset, 0);
          } else {
            // Fallback - rectangle representing content
            c.fillStyle = "rgba(0,0,0,0.5)";
            c.fillRect(offset, 0, w, h);
          }
        };

        MCQVS_AnimationEngine.utils.motionBlur(
          ctx,
          drawFn,
          dir === "left" ? -velocity : velocity,
          0,
          8
        );
      },

      // Transition implementations
      _fadeZoom: function (ctx, w, h, progress) {
        if (progress < 0.5) {
          // Fade out + zoom in
          const p = progress * 2;
          ctx.save();
          ctx.globalAlpha = 1 - p;
          ctx.translate(w / 2, h / 2);
          ctx.scale(1 + p * 0.2, 1 + p * 0.2);
          ctx.translate(-w / 2, -h / 2);
          ctx.restore();
        }
      },

      _slideLeft: function (ctx, w, h, progress) {
        const offset = (1 - progress) * w;
        ctx.save();
        ctx.beginPath();
        ctx.rect(offset, 0, w, h);
        ctx.clip();
        ctx.fillStyle = "#000000";
        ctx.fillRect(0, 0, offset, h);
        ctx.restore();
      },

      _slideRight: function (ctx, w, h, progress) {
        const offset = progress * w;
        ctx.save();
        ctx.beginPath();
        ctx.rect(0, 0, offset, h);
        ctx.clip();
        ctx.restore();
      },

      _swipeUp: function (ctx, w, h, progress) {
        const offset = (1 - progress) * h;
        ctx.save();
        ctx.fillStyle = "#000000";
        ctx.fillRect(0, 0, w, offset);
        ctx.restore();
      },

      _flashWhite: function (ctx, w, h, progress) {
        // Peak white at 0.5, fade out after
        let alpha = progress < 0.5 ? progress * 2 : 2 - progress * 2;
        ctx.save();
        ctx.globalAlpha = alpha * 0.8;
        ctx.fillStyle = "#FFFFFF";
        ctx.fillRect(0, 0, w, h);
        ctx.restore();
      },

      _zoomBlur: function (ctx, w, h, progress) {
        // Simulated radial blur via overlays
        if (progress < 0.5) {
          const p = progress * 2;
          for (let i = 0; i < 5; i++) {
            ctx.save();
            ctx.globalAlpha = 0.1 * (1 - p);
            const scale = 1 + i * 0.02 * p;
            ctx.translate(w / 2, h / 2);
            ctx.scale(scale, scale);
            ctx.translate(-w / 2, -h / 2);
            ctx.restore();
          }
        }
      },

      _pixelate: function (ctx, w, h, progress) {
        // This requires reading image data - simplified version
        if (progress < 0.5) {
          const blockSize = Math.max(1, Math.floor((1 - progress * 2) * 30));
          ctx.save();
          ctx.imageSmoothingEnabled = false;
          // Would need to draw to temp canvas and scale - simplified overlay
          ctx.globalAlpha = 0.3 * (1 - progress * 2);
          ctx.fillStyle = "#000000";
          for (let x = 0; x < w; x += blockSize * 2) {
            for (let y = 0; y < h; y += blockSize * 2) {
              ctx.fillRect(x, y, blockSize, blockSize);
            }
          }
          ctx.restore();
        }
      },

      _glitch: function (ctx, w, h, progress) {
        if (progress < 0.7) {
          const intensity = (1 - progress / 0.7) * 20;
          ctx.save();

          // Random horizontal slices
          for (let i = 0; i < 5; i++) {
		const sliceY = MCQVS_AnimationEngine.seededRandom() * h;
			const sliceH = 10 + MCQVS_AnimationEngine.seededRandom() * 30;
			const offsetX = (MCQVS_AnimationEngine.seededRandom() - 0.5) * intensity * 2;

            ctx.drawImage(
              ctx.canvas,
              0,
              sliceY,
              w,
              sliceH,
              offsetX,
              sliceY,
              w,
              sliceH
            );
          }

          // RGB split
          ctx.globalCompositeOperation = "screen";
          ctx.globalAlpha = 0.3 * (1 - progress);
          ctx.fillStyle = "#FF0000";
          ctx.fillRect(-intensity / 2, 0, w, h);
          ctx.fillStyle = "#00FFFF";
          ctx.fillRect(intensity / 2, 0, w, h);

          ctx.restore();
        }
      },
    },

    // ==========================================
    // CAMERA EFFECTS
    // Shake, zoom, and pan effects
    // ==========================================
    camera: {
      _state: {
        shake: { active: false, intensity: 0, startTime: 0, duration: 0 },
        zoom: {
          active: false,
          scale: 1,
          startTime: 0,
          duration: 0,
          targetScale: 1,
        },
        pan: {
          active: false,
          x: 0,
          y: 0,
          startTime: 0,
          duration: 0,
          targetX: 0,
          targetY: 0,
        },
      },

      /**
       * Start screen shake effect
       * @param {number} intensity - Shake intensity (1-20)
       * @param {number} duration - Duration in ms
       */
      shake: function (intensity = 10, duration = 300, manualStartTime = null) {
        this._state.shake = {
          active: true,
          intensity: intensity,
          startTime: manualStartTime !== null ? manualStartTime : Date.now(),
          duration: duration,
		noiseX: Array.from({ length: 10 }, () => MCQVS_AnimationEngine.seededRandom() - 0.5),
		noiseY: Array.from({ length: 10 }, () => MCQVS_AnimationEngine.seededRandom() - 0.5),
        };
      },

      /**
       * Start zoom effect
       */
      zoom: function (targetScale = 1.1, duration = 500) {
        this._state.zoom = {
          active: true,
          scale: 1,
          targetScale: targetScale,
          startTime: Date.now(),
          duration: duration,
        };
      },

      /**
       * Start pan effect
       */
      pan: function (targetX = 0, targetY = 0, duration = 500) {
        this._state.pan = {
          active: true,
          x: 0,
          y: 0,
          targetX: targetX,
          targetY: targetY,
          startTime: Date.now(),
          duration: duration,
        };
      },

      /**
       * Apply all active camera effects
       * Call before rendering frame content
       */
      applyTransform: function (ctx, centerX, centerY, manualElapsed = null) {
        const now = manualElapsed !== null ? manualElapsed : Date.now();

        // @NEW 2025-12-18: Ken Burns Effect (Virtual Camera Scale/Pan)
        // This makes backgrounds feel alive with subtle movement (Planning Phase 6)
        if (this._kenBurns) {
          const kb = this._kenBurns;
          const p = ((now - kb.startTime) % kb.duration) / kb.duration;
          const eased = MCQVS_AnimationEngine.easing.easeInOutQuad(p);

          const scale = kb.startScale + (kb.endScale - kb.startScale) * eased;
          const offX = kb.startOffX + (kb.endOffX - kb.startOffX) * eased;
          const offY = kb.startOffY + (kb.endOffY - kb.startOffY) * eased;

          ctx.translate(centerX + offX, centerY + offY);
          ctx.scale(scale, scale);
          ctx.translate(-centerX, -centerY);
        }

        // Shake
        if (this._state.shake.active) {
          // Normalize mixed timebases (epoch ms vs timeline ms)
          if (manualElapsed !== null && this._state.shake.startTime > 1e12) {
            this._state.shake.startTime = now;
          }
          const elapsed = now - this._state.shake.startTime;
          if (elapsed < this._state.shake.duration) {
            const progress = Math.max(0, Math.min(1, elapsed / this._state.shake.duration));
            const decay = Math.pow(1 - progress, 2); // Faster decay for "impact" feel
            const intensity = this._state.shake.intensity * decay;

            // Use time-based noise for smoother shake than pure random
        const freq = 0.05;
		const offsetX =
			Math.sin(now * freq) * intensity +
			(MCQVS_AnimationEngine.seededRandom() - 0.5) * intensity * 0.5;
		const offsetY =
			Math.cos(now * freq * 1.1) * intensity +
			(MCQVS_AnimationEngine.seededRandom() - 0.5) * intensity * 0.5;

            ctx.translate(offsetX, offsetY);
          } else {
            this._state.shake.active = false;
          }
        }

        // Zoom (Legacy)
        if (this._state.zoom.active) {
          const elapsed = now - this._state.zoom.startTime;
          if (elapsed < this._state.zoom.duration) {
            const progress = elapsed / this._state.zoom.duration;
            const eased = MCQVS_AnimationEngine.easing.easeOutQuad(progress);
            const scale = 1 + (this._state.zoom.targetScale - 1) * eased;
            ctx.translate(centerX, centerY);
            ctx.scale(scale, scale);
            ctx.translate(-centerX, -centerY);
          } else {
            this._state.zoom.active = false;
          }
        }

        // Pan (Legacy)
        if (this._state.pan.active) {
          const elapsed = now - this._state.pan.startTime;
          if (elapsed < this._state.pan.duration) {
            const progress = elapsed / this._state.pan.duration;
            const eased = MCQVS_AnimationEngine.easing.easeInOutQuad(progress);
            const x = this._state.pan.targetX * eased;
            const y = this._state.pan.targetY * eased;
            ctx.translate(x, y);
          } else {
            this._state.pan.active = false;
          }
        }
      },

      /**
       * Start the Ken Burns effect for professional background motion
       */
      startKenBurns: function (duration = 10000) {
        this._kenBurns = {
          startTime: Date.now(),
          duration: duration,
          startScale: 1.0,
          endScale: 1.15,
          startOffX: -10,
          endOffX: 10,
          startOffY: -5,
          endOffY: 5,
        };
      },

      /**
       * Check if any camera effect is active
       */
      isActive: function () {
        return (
          this._state.shake.active ||
          this._state.zoom.active ||
          this._state.pan.active ||
          !!this._kenBurns
        );
      },

      /**
       * Reset all camera effects
       */
      reset: function () {
        this._state.shake.active = false;
        this._state.zoom.active = false;
        this._state.pan.active = false;
        this._kenBurns = null;
      },
    },

    // ==========================================
    // OVERLAYS (NEW v8.2.0)
    // Kinetic emojis, stickers, and floating elements
    // ==========================================
    overlays: {
      _active: [],
      _keywords: {
        money: ["💰", "💵", "🤑", "💸"],
        time: ["⏰", "⌛", "⏳", "⏱️"],
        world: ["🌍", "🌎", "🌏", "🗺️"],
        love: ["❤️", "💖", "😍", "✨"],
        idea: ["💡", "🧠", "✨"],
        win: ["🏆", "🥇", "⭐", "🎉"],
      },

      /**
       * Spawn a kinetic emoji
       * @param {string} emoji - The emoji to display
       * @param {number} x, y - Position
       * @param {Object} options - Custom motion options
       */
      spawnEmoji: function (emoji, x, y, options = {}) {
        const defaults = {
          duration: 1500,
		vx: (MCQVS_AnimationEngine.seededRandom() - 0.5) * 4,
		vy: -5 - MCQVS_AnimationEngine.seededRandom() * 5,
		gravity: 0.2,
		rotationSpeed: (MCQVS_AnimationEngine.seededRandom() - 0.5) * 0.2,
          scale: 1.0,
        };
        const opts = { ...defaults, ...options };

        this._active.push({
          text: emoji,
          x: x,
          y: y,
          vx: opts.vx,
          vy: opts.vy,
          gravity: opts.gravity,
          rotation: 0,
          rotationSpeed: opts.rotationSpeed,
          scale: opts.scale,
          startTime: Date.now(),
          duration: opts.duration,
          opacity: 1,
        });
      },

      /**
       * Get emojis by keyword
       */
      getEmojis: function (keyword) {
        return this._keywords[keyword.toLowerCase()] || [];
      },

      /**
       * Update and draw all active overlays
       */
      updateAndDraw: function (ctx, width, height, manualElapsed = null) {
        const now = manualElapsed !== null ? manualElapsed : Date.now();
        this._active = this._active.filter((o) => {
          const elapsed = manualElapsed !== null ? now : now - o.startTime;
          const progress = Math.min(1, elapsed / o.duration);

          if (progress >= 1) return false;

          // Physics update
          o.x += o.vx;
          o.y += o.vy;
          o.vy += o.gravity;
          o.rotation += o.rotationSpeed;
          o.opacity = 1 - MCQVS_AnimationEngine.easing.easeInQuad(progress);

          // Draw
          ctx.save();
          ctx.globalAlpha = o.opacity;
          ctx.translate(o.x, o.y);
          ctx.rotate(o.rotation);
          ctx.scale(o.scale, o.scale);
          ctx.font = "80px Arial";
          ctx.textAlign = "center";
          ctx.textBaseline = "middle";
          ctx.fillText(o.text, 0, 0);
          ctx.restore();

          return true;
        });
      },
    },

    // ==========================================
    // PARTICLE SYSTEM
    // Enhanced particle effects
    // ==========================================
    particles: {
      _particles: [],
      _currentTime: 0,
      setCurrentTime(t) { this._currentTime = Number(t) || 0; },
      _types: {
        confetti: {
          colors: [
            "#FF6B6B",
            "#4ECDC4",
            "#45B7D1",
            "#96CEB4",
            "#FFEAA7",
            "#DDA0DD",
            "#98D8C8",
          ],
          size: { min: 8, max: 15 },
          gravity: 0.3,
          wind: 0.05,
          rotation: true,
          lifetime: 2000,
        },
        sparks: {
          colors: ["#FFD700", "#FFA500", "#FF4500", "#FFFFFF"],
          size: { min: 2, max: 6 },
          gravity: 0.1,
          wind: 0,
          rotation: false,
          lifetime: 800,
        },
        stars: {
          colors: ["#FFFFFF", "#FFD700", "#87CEEB"],
          size: { min: 10, max: 20 },
          gravity: -0.05, // Float up
          wind: 0.02,
          rotation: true,
          lifetime: 1500,
        },
        bokeh: {
          colors: [
            "rgba(255,255,255,0.3)",
            "rgba(173,216,230,0.2)",
            "rgba(255,182,193,0.2)",
          ],
          size: { min: 20, max: 80 },
          gravity: -0.02,
          wind: 0.01,
          rotation: false,
          lifetime: 5000,
        },
      },

      /**
       * Create burst of particles
       */
      burst: function (x, y, type = "confetti", count = 30) {
        const config = this._types[type] || this._types.confetti;

        for (let i = 0; i < count; i++) {
		const angle = ((Math.PI * 2) / count) * i + MCQVS_AnimationEngine.seededRandom() * 0.5;
			// @MODIFIED 2026-02-07: Increased speed for whole-screen coverage
			const speed = 8 + MCQVS_AnimationEngine.seededRandom() * 22;
			const size =
				config.size.min +
				MCQVS_AnimationEngine.seededRandom() * (config.size.max - config.size.min);

			this._particles.push({
				x: x,
				y: y,
				vx: Math.cos(angle) * speed,
				vy: Math.sin(angle) * speed - 5,
				size: size,
				color:
				config.colors[Math.floor(MCQVS_AnimationEngine.seededRandom() * config.colors.length)],
				rotation: MCQVS_AnimationEngine.seededRandom() * Math.PI * 2,
				rotationSpeed: (MCQVS_AnimationEngine.seededRandom() - 0.5) * 0.2,
            gravity: config.gravity,
            wind: config.wind,
            lifetime: config.lifetime,
            born: this._currentTime || 0,
            type: type,
          });
        }
      },

      /**
       * Update all particles
       */
      update: function () {
        const now = this._currentTime || 0;
        this._particles = this._particles.filter((p) => {
          const age = now - p.born;
          if (age > p.lifetime) return false;

          p.x += p.vx;
          p.y += p.vy;
          p.vy += p.gravity;
		p.vx += (MCQVS_AnimationEngine.seededRandom() - 0.5) * p.wind;
          p.rotation += p.rotationSpeed;

          return true;
        });
      },

      /**
       * Draw all particles
       */
      draw: function (ctx) {
        const now = this._currentTime || 0;

        this._particles.forEach((p) => {
          const age = now - p.born;
          const lifeProgress = age / p.lifetime;
          const alpha = 1 - lifeProgress;

          ctx.save();
          ctx.globalAlpha = alpha;
          ctx.translate(p.x, p.y);
          ctx.rotate(p.rotation);

          ctx.fillStyle = p.color;

          if (p.type === "stars") {
            // Draw star shape
            this._drawStar(ctx, 0, 0, 5, p.size, p.size / 2);
          } else if (p.type === "sparks") {
            // Draw circle
            ctx.beginPath();
            ctx.arc(0, 0, p.size, 0, Math.PI * 2);
            ctx.fill();
          } else if (p.type === "bokeh") {
            // Draw blurred circle (bokeh)
            const grad = ctx.createRadialGradient(0, 0, 0, 0, 0, p.size);
            grad.addColorStop(0, p.color);
            grad.addColorStop(1, "transparent");
            ctx.fillStyle = grad;
            ctx.beginPath();
            ctx.arc(0, 0, p.size, 0, Math.PI * 2);
            ctx.fill();
          } else {
            // Confetti rectangle
            ctx.fillRect(-p.size / 2, -p.size / 4, p.size, p.size / 2);
          }

          ctx.restore();
        });
      },

      _drawStar: function (ctx, cx, cy, spikes, outerRadius, innerRadius) {
        let rot = (Math.PI / 2) * 3;
        let x = cx,
          y = cy;
        const step = Math.PI / spikes;

        ctx.beginPath();
        ctx.moveTo(cx, cy - outerRadius);

        for (let i = 0; i < spikes; i++) {
          x = cx + Math.cos(rot) * outerRadius;
          y = cy + Math.sin(rot) * outerRadius;
          ctx.lineTo(x, y);
          rot += step;

          x = cx + Math.cos(rot) * innerRadius;
          y = cy + Math.sin(rot) * innerRadius;
          ctx.lineTo(x, y);
          rot += step;
        }

        ctx.lineTo(cx, cy - outerRadius);
        ctx.closePath();
        ctx.fill();
      },

      /**
       * Clear all particles
       */
      clear: function () {
        this._particles = [];
      },
    },

    // ==========================================
    // POST-PROCESSING (NEW v8.7.0)
    // Cinematic filters and overlays
    // ==========================================
    postProcessing: {
      /**
       * Apply cinematic vignette
       */
      vignette: function (ctx, w, h, intensity = 0.4) {
        ctx.save();
        const grad = ctx.createRadialGradient(
          w / 2,
          h / 2,
          0,
          w / 2,
          h / 2,
          Math.sqrt(w * w + h * h) / 2
        );
        grad.addColorStop(0, "rgba(0,0,0,0)");
        grad.addColorStop(1, `rgba(0,0,0,${intensity})`);
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, w, h);
        ctx.restore();
      },

      /**
       * Apply film grain overlay
       * Note: Uses small pre-rendered patterns for performance
       */
      filmGrain: function (ctx, w, h, intensity = 0.05) {
        if (!this._grainPattern) {
          const pCanvas = document.createElement("canvas");
          pCanvas.width = 128;
          pCanvas.height = 128;
          const pCtx = pCanvas.getContext("2d");
          const imgData = pCtx.createImageData(128, 128);
          for (let i = 0; i < imgData.data.length; i += 4) {
			const val = MCQVS_AnimationEngine.seededRandom() * 255;
            imgData.data[i] = val;
            imgData.data[i + 1] = val;
            imgData.data[i + 2] = val;
            imgData.data[i + 3] = 255;
          }
          pCtx.putImageData(imgData, 0, 0);
          this._grainPattern = ctx.createPattern(pCanvas, "repeat");
        }

        ctx.save();
        ctx.globalAlpha = intensity;
        ctx.globalCompositeOperation = "overlay";
        ctx.fillStyle = this._grainPattern;
        ctx.translate(MCQVS_AnimationEngine.seededRandom() * 128, MCQVS_AnimationEngine.seededRandom() * 128);
        ctx.fillRect(-128, -128, w + 128, h + 128);
        ctx.restore();
      },
    },

    // ==========================================
    // BACKGROUNDS (NEW v8.7.0)
    // Dynamic animated backgrounds
    // ==========================================
    backgrounds: {
      /**
       * Render animated mesh-style gradient
       */
      meshGradient: function (ctx, w, h, colors, manualElapsed = null) {
        const now = manualElapsed !== null ? manualElapsed : Date.now();
        const t = now * 0.001;

        ctx.save();

        // @FIX 2026-01-18: Set base color before drawing (fixes flickering)
        ctx.fillStyle = colors[0] || '#000000';
        ctx.fillRect(0, 0, w, h); // Base color

        colors.forEach((color, i) => {
          const x = w / 2 + (Math.sin(t * (0.5 + i * 0.1)) * w) / 3;
          const y = h / 2 + (Math.cos(t * (0.3 + i * 0.12)) * h) / 3;
          const radius = w * (0.8 + Math.sin(t * 0.2 + i) * 0.2);

          const grad = ctx.createRadialGradient(x, y, 0, x, y, radius);
          grad.addColorStop(0, color);
          grad.addColorStop(1, "transparent");

          ctx.globalCompositeOperation = "screen";
          ctx.fillStyle = grad;
          ctx.fillRect(0, 0, w, h);
        });

        // @FIX 2026-01-18: Reset composite operation to prevent bleeding
        ctx.globalCompositeOperation = "source-over";
        ctx.restore();
      },
    },
  };

  // Export to window
  window.MCQVS_AnimationEngine = MCQVS_AnimationEngine;
})(window);
