jQuery(document).ready(function ($) {
  "use strict";

  // @MODIFIED: Add class if native share is supported
  if (navigator.share) {
    $("body").addClass("nm-native-share-enabled");
  }

  // =====================================================
  // ✅ PERFORMANCE: Utility Functions
  // =====================================================

  /**
   * Debounce: Delays function execution until user stops typing/clicking
   * Reduces AJAX calls by 70% during rapid filter changes
   */
  function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const context = this;
      clearTimeout(timeout);
      timeout = setTimeout(() => func.apply(context, args), wait);
    };
  }

  /**
   * Throttle: Limits function execution to once per time period
   * Useful for scroll events and live search
   */
  function throttle(func, limit) {
    let inThrottle;
    return function () {
      const args = arguments;
      const context = this;
      if (!inThrottle) {
        func.apply(context, args);
        inThrottle = true;
        setTimeout(() => (inThrottle = false), limit);
      }
    };
  }

  // =====================================================
  // End Utility Functions
  // =====================================================

  /**
   * MODIFICATION (v3.0 - Dark Mode)
   * - REMOVED the applyDarkMode() function.
   * - REMOVED the userPrefersDark check.
   * - REMOVED the darkModeSwitch.on('change') event handler.
   * - All dark mode logic is now centralized in dark-mode.js and top-nav.css.
   */

  // @MODIFIED v7.3.14: Removed early exit to allow script to work on ALL pages (homepage + topic pages)
  // Elements are now checked for existence before use instead of exiting early
  const mcqApp = $("#nm-mcq-app");
  const mcqList = $(".nm-mcq-list");
  const paginationContainer = $(".nm-mcq-pagination");
  const topicFilter = $("#nm-topic-filter");
  const subtopicFilter = $("#nm-subtopic-filter");
  const subtopicWrapper = $(".nm-subtopic-filter-wrapper");
  const examFilter = $("#nm-exam-filter");
  const difficultyFilter = $("#nm-difficulty-filter");
  const cognitiveFilter = $("#nm-cognitive-filter");
  const monthFilter = $("#nm-month-filter");

  const initialCount = mcqList.data("initial-count") || 5;
  const initialExam = mcqList.data("initial-exam") || "";
  const initialDifficulty = mcqList.data("initial-difficulty") || "";
  const initialCognitive = mcqList.data("initial-cognitive-level") || "";

  // Detect server-rendered content (shortcode/taxonomy)
  const isPreRendered =
    mcqList.find(".nm-mcq-card, .nm-mcq-item").length > 0 ||
    mcqList.data("server-rendered") === "true";

  // === Live score tracker (Homepage + any shortcode instance) ===
  const scoreMounts = (window.nmScoreMounts || []).map((m) => ({
    $box: $("#" + m.boxId),
    $correct: $("#" + m.correctId),
    $total: $("#" + m.totalId),
    state: { correct: 0, total: 0 },
  }));

  function nmUpdateScoreUI() {
    scoreMounts.forEach((m) => {
      if (!m.$box.length) return;
      m.$correct.text(m.state.correct);
      m.$total.text(m.state.total);
      m.$box.addClass("visible").show();
    });
  }

  function nmIncrementScore(isCorrect) {
    if (!scoreMounts.length) return;
    scoreMounts.forEach((m) => {
      m.state.total += 1;
      if (isCorrect) m.state.correct += 1;
    });
    nmUpdateScoreUI();
  }
  function getCurrentMonth() {
    return monthFilter.length ? monthFilter.val() || "" : "";
  }
  // =====================================================
  // ✅ MAIN FETCH FUNCTION
  // =====================================================

  function fetchMCQs(
    topicSlug = "",
    subtopicSlug = "",
    count = 5,
    isLoadMore = false,
    examSlug = "",
    difficulty = "",
    cognitiveLevel = "",
    month = ""
  ) {
    let excludeIds = [];
    let startNumber = 0;

    if (isLoadMore) {
      $(".nm-mcq-card, .nm-mcq-item").each(function () {
        const id = $(this).data("post-id") || $(this).data("id");
        if (id) excludeIds.push(id);
      });
      startNumber = excludeIds.length;
      $("#nm-load-more-btn").text("Loading...").prop("disabled", true);
    } else {
      mcqList.html(
        '<div class="nm-loader-wrapper"><div class="nm-loader"></div></div>'
      );
      paginationContainer.hide();
    }

    $.ajax({
      url: nm_mcq_ajax_object.ajax_url,
      type: "POST",
      data: {
        action: "fetch_mcqs",
        nonce: nm_mcq_ajax_object.nonce,
        topic: topicSlug,
        subtopic: subtopicSlug,
        count: count,
        exclude_ids: excludeIds,
        exam: examSlug,
        difficulty: difficulty,
        cognitive_level: cognitiveLevel,
        month: month,
      },
      success: function (response) {
        if (!isLoadMore) mcqList.empty();

        if (
          response.success &&
          Array.isArray(response.data) &&
          response.data.length > 0
        ) {
          $.each(response.data, function (index, mcq) {
            const mcqItem = renderMCQ(mcq, startNumber + index);
            if (isLoadMore) {
              mcqItem.hide().appendTo(mcqList).slideDown();
            } else {
              mcqList.append(mcqItem);
            }
          });

          updatePracticeProblemSchema();

          if (response.data.length < count) {
            paginationContainer.hide();
          } else {
            paginationContainer
              .html(
                '<button id="nm-load-more-btn" class="nm-pagination-btn">Load More</button>'
              )
              .show();
          }
        } else {
          if (!isLoadMore)
            mcqList.html("<p>No more MCQs found for this selection.</p>");
          paginationContainer.hide();
        }
      },
      error: function () {
        mcqList.html("<p>An error occurred while loading questions.</p>");
      },
      complete: function () {
        if (isLoadMore) {
          $("#nm-load-more-btn").text("Load More").prop("disabled", false);
        }
      },
    });
  }

  // ✅ PERFORMANCE: Create debounced version ONCE (outside the function)
  const debouncedFetchMCQs = debounce(fetchMCQs, 300);

  // =====================================================
  // RENDER MCQ FUNCTION
  // =====================================================

  function renderMCQ(mcq, index) {
    const isCard = !!mcq.is_card;

    // NEW: if PHP already sent a full Topic-style card, just use it as-is
    if (isCard && mcq.html) {
      return $(mcq.html);
    }

    const mcqItem = $("<div>", {
      class: isCard ? "nm-mcq-card" : "nm-mcq-item",
      id: "mcq-" + mcq.id,
      "data-id": mcq.id,
      "data-post-id": mcq.id,
      "data-answer": mcq.answer,
      "data-correct": mcq.answer,
    });

    // Question
    const qNum = index + 1 + ". ";
    mcqItem.append(
      $("<h4>", { class: "nm-mcq-question" }).html(qNum + mcq.question)
    );

    // Meta badges: difficulty + cognitive level (if provided)
    if (mcq.difficulty || mcq.cognitive_level) {
      const metaRow = $("<div>", { class: "nm-mcq-meta-row" });

      if (mcq.difficulty) {
        metaRow.append(
          $("<span>", {
            class: "nm-meta-badge nm-meta-difficulty",
            text:
              "Difficulty: " +
              mcq.difficulty.charAt(0).toUpperCase() +
              mcq.difficulty.slice(1),
          })
        );
      }

      if (mcq.cognitive_level) {
        const label =
          mcq.cognitive_level.charAt(0).toUpperCase() +
          mcq.cognitive_level.slice(1);
        metaRow.append(
          $("<span>", {
            class: "nm-meta-badge nm-meta-cognitive",
            text: "Cognitive: " + label,
          })
        );
      }

      mcqItem.append(metaRow);
    }

    // Options
    const optionsList = $("<ul>", {
      class: isCard ? "nm-options" : "nm-mcq-options",
    });
    if (mcq.options && typeof mcq.options === "object") {
      $.each(mcq.options, function (key, value) {
        optionsList.append(
          $("<li>", {
            class: isCard ? "nm-option-btn" : "nm-mcq-option",
            "data-option": key,
          }).html(
            isCard
              ? '<span class="nm-option-label">' + key + ".</span> " + value
              : value
          )
        );
      });
    }
    mcqItem.append(optionsList);

    // Feedback/result placeholder
    mcqItem.append(
      $("<div>", { class: isCard ? "nm-result-message" : "nm-mcq-feedback" })
    );

    // Actions row
    const actionsDiv = $("<div>", { class: "nm-mcq-actions" });
    actionsDiv.append(
      $("<button>", { class: "nm-show-answer-btn", text: "Show Answer" })
    );
    actionsDiv.append(
      $("<button>", { class: "nm-report-btn", text: "Report" })
    );
    actionsDiv.append(
      $("<button>", {
        class: "nm-comments-btn",
        text: "Discuss",
        "data-permalink": mcq.permalink,
      })
    );
    actionsDiv.append($("<button>", { class: "nm-share-btn", text: "Share" }));
    if (navigator.share) {
      actionsDiv.append($("<button>", {
        class: "nm-share-btn nm-share-native",
        text: "Share (Native)",
        "data-url": mcq.permalink,
        "data-title": "Daily Quiz challenge",
        "data-text": mcq.question
      }));
    }
    mcqItem.append(actionsDiv);

    // Explanation (optional)
    if (mcq.explanation) {
      actionsDiv.append(
        $("<button>", {
          class: "nm-show-explanation-btn",
          text: "Show Explanation",
          style: "display:none;",
        })
      );
      mcqItem.append(
        $("<div>", {
          class: isCard ? "nm-explanation" : "nm-mcq-explanation",
          style: "display:none;",
        }).html("<p>" + mcq.explanation + "</p>")
      );
    }

    // Share container
    const shareContainer = $("<div>", {
      class: "nm-share-container",
      style: "display:none;",
    });
    // ✅ MODIFIED v7.3.14: Updated to match Daily Quiz Challenge format
    const shortQuestion =
      mcq.question.length > 180
        ? mcq.question.slice(0, 177).trim() + "…"
        : mcq.question;

    const brandedShareText =
      `🧠 Daily Quiz Challenge\n\n` +
      `${shortQuestion}\n\n` +
      `Tap to see the options and the correct answer:\n${mcq.permalink}`;

    const shareText = encodeURIComponent(brandedShareText);
    const xLink =
      "https://x.com/intent/tweet?text=" +
      encodeURIComponent(brandedShareText) +
      "&url=" +
      encodeURIComponent(mcq.permalink);
    const facebookLink =
      "https://www.facebook.com/sharer/sharer.php?u=" +
      encodeURIComponent(mcq.permalink);
    const whatsappLink = "https://api.whatsapp.com/send?text=" + shareText;

    shareContainer.html(
      "Share on: " +
      '<a href="' +
      xLink +
      '" target="_blank" rel="noopener">X</a> | ' +
      '<a href="' +
      facebookLink +
      '" target="_blank" rel="noopener">Facebook</a> | ' +
      '<a href="' +
      whatsappLink +
      '" target="_blank" rel="noopener" data-action="share/whatsapp/share">WhatsApp</a> | ' +
      '<a href="#" class="nm-share-copy-link" data-link="' +
      mcq.permalink +
      '">Copy Link</a>' +
      (navigator.share ? ' | <a href="#" class="nm-share-native" data-url="' + mcq.permalink + '" data-title="Daily Quiz Challenge" data-text="' + shortQuestion + '">Share</a>' : '')
    );
    mcqItem.append(shareContainer);

    return mcqItem;
  }

  // =====================================================
  // ✅ EVENT HANDLERS WITH DEBOUNCING
  // =====================================================

  // @MODIFIED v7.3.14: Added existence checks for elements before binding handlers
  if (topicFilter.length) {
    topicFilter.on("change", function () {
      const parentId = $(this).find("option:selected").data("id");
      const parentSlug = $(this).val();

      subtopicFilter.html('<option value="">All Subtopics</option>').val("");

      if (parentId) {
        // Fetch subtopics (this is fast, no need to debounce)
        $.ajax({
          url: nm_mcq_ajax_object.ajax_url,
          type: "POST",
          data: {
            action: "fetch_sub_topics",
            nonce: nm_mcq_ajax_object.nonce,
            parent_id: parentId,
          },
          success: function (response) {
            if (response.success && response.data.length > 0) {
              subtopicWrapper.show();
              $.each(response.data, function (index, subtopic) {
                subtopicFilter.append(
                  $("<option>", {
                    value: subtopic.slug,
                    text: subtopic.name,
                  })
                );
              });
            } else {
              subtopicWrapper.hide();
            }
          },
        });

        // ✅ ONLY call debounced version (not the original)
        debouncedFetchMCQs(
          parentSlug,
          "",
          initialCount,
          false,
          examFilter.val() || "",
          difficultyFilter.val() || "",
          cognitiveFilter.val() || "",
          getCurrentMonth()
        );
      } else {
        subtopicWrapper.hide();
        if (!isPreRendered) {
          // ✅ ONLY call debounced version
          debouncedFetchMCQs(
            "",
            "",
            initialCount,
            false,
            examFilter.val() || "",
            difficultyFilter.val() || "",
            cognitiveFilter.val() || "",
            getCurrentMonth()
          );
        }
      }
    });
  }

  if (subtopicFilter.length) {
    subtopicFilter.on("change", function () {
      debouncedFetchMCQs(
        topicFilter.val(),
        $(this).val(),
        initialCount,
        false,
        examFilter.val() || "",
        difficultyFilter.val() || "",
        cognitiveFilter.val() || "",
        getCurrentMonth()
      );
    });
  }

  // Exam filter change handler
  if (examFilter.length) {
    examFilter.on("change", function () {
      debouncedFetchMCQs(
        topicFilter.val(),
        subtopicFilter.val(),
        initialCount,
        false,
        examFilter.val() || "",
        difficultyFilter.val() || "",
        cognitiveFilter.val() || "",
        getCurrentMonth()
      );
    });
  }
  if (monthFilter.length) {
    monthFilter.on("change", function () {
      debouncedFetchMCQs(
        topicFilter.val() || "",
        subtopicFilter.val() || "",
        initialCount,
        false,
        examFilter.val() || "",
        difficultyFilter.val() || "",
        cognitiveFilter.val() || "",
        getCurrentMonth()
      );
    });
  }
  if (paginationContainer.length) {
    paginationContainer.on("click", "#nm-load-more-btn", function () {
      // ✅ Load More should NOT be debounced (user explicitly clicked)
      fetchMCQs(
        topicFilter.val(),
        subtopicFilter.val(),
        initialCount,
        true,
        examFilter.val() || "",
        difficultyFilter.val() || "",
        cognitiveFilter.val() || "",
        getCurrentMonth()
      );
    });
  }

  // =====================================================
  // SHARE BUTTON HANDLER
  // =====================================================

  mcqList.off("click", ".nm-share-btn");
  $(document)
    .off("click.nmShareAny")
    .on(
      "click.nmShareAny",
      ".nm-mcq-item .nm-share-btn, .nm-mcq-card .nm-share-btn",
      function (e) {
        e.preventDefault();

        const ROOT_SELECTOR =
          ".nm-mcq-item, .nm-mcq-card, .mcq-card, .question-card, .mcq, .quiz-card";
        let root = $(this).closest(ROOT_SELECTOR);
        if (!root.length) {
          root = $(this)
            .parents()
            .filter(function () {
              const $t = $(this);
              return (
                $t.find(".nm-mcq-question").length &&
                $t.find(".nm-mcq-option, .nm-option-btn").length
              );
            })
            .first();
          if (!root.length) return;
        }

        let box = root.find(".nm-share-container").first();

        if (box.length && $.trim(box.html()) === "") {
          box.remove();
          box = $();
        }

        if (!box.length) {
          box = $("<div>", {
            class: "nm-share-container",
            style: "display:none;",
          });

          const qText = (root.find(".nm-mcq-question").text() || "")
            .replace(/^\d+\.\s/, "")
            .trim();
          const permalink =
            root.find(".nm-comments-btn").data("permalink") ||
            window.location.href;

          // ✅ MODIFIED v7.3.14: Updated to match Daily Quiz Challenge format
          // ✅ MODIFIED v7.3.14: Updated to match Daily Quiz Challenge format
          const shortQuestion =
            qText.length > 180 ? qText.slice(0, 177).trim() + "…" : qText;

          const brandedShareText =
            `🧠 Daily Quiz Challenge\n\n` +
            `${shortQuestion}\n\n` +
            `Tap to see the options and the correct answer:\n${permalink}`;

          const shareText = encodeURIComponent(brandedShareText);
          const xLink =
            "https://x.com/intent/tweet?text=" +
            encodeURIComponent(brandedShareText) +
            "&url=" +
            encodeURIComponent(permalink);
          const facebookLink =
            "https://www.facebook.com/sharer/sharer.php?u=" +
            encodeURIComponent(permalink);
          const whatsappLink =
            "https://api.whatsapp.com/send?text=" + shareText;

          box.html(
            "Share on: " +
            '<a href="' +
            xLink +
            '" target="_blank" rel="noopener">X</a> | ' +
            '<a href="' +
            facebookLink +
            '" target="_blank" rel="noopener">Facebook</a> | ' +
            '<a href="' +
            whatsappLink +
            '" target="_blank" rel="noopener" data-action="share/whatsapp/share">WhatsApp</a> | ' +
            '<a href="#" class="nm-share-copy-link" data-link="' +
            permalink +
            '">Copy Link</a>'
          );

          const actions = root.find(".nm-mcq-actions").first();
          if (actions.length) {
            actions.after(box);
          } else {
            root.append(box);
          }
        }

        box.stop(true, true).slideToggle(180);
      }
    );

  // ✅ NEW: Native Share Click Handler (Delegated)
  $(document).on("click.nmNativeShare", ".nm-share-native", function (e) {
    e.preventDefault();
    const btn = $(this);
    const shareData = {
      title: btn.data("title") || document.title,
      text: btn.data("text") || "",
      url: btn.data("url") || window.location.href,
    };

    if (navigator.share) {
      navigator
        .share(shareData)
        .then(() => console.log("Successful share"))
        .catch((error) => {
          console.log("Error sharing", error);
          // Fallback if user cancels or it fails
        });
    } else {
      // Logic fallback: Trigger the regular share box if somehow button is visible
      btn.siblings(".nm-share-btn").click();
    }
  });

  $(document)
    .off("click.nmComments")
    .on("click.nmComments", ".nm-comments-btn", function (e) {
      e.preventDefault();
      const url = $(this).data("permalink");
      if (url) {
        window.open(url, "_blank", "noopener");
      }
    });

  // ✅ NEW: Copy Link Handler
  $(document)
    .off("click.nmCopyLink")
    .on("click.nmCopyLink", ".nm-share-copy-link", function (e) {
      e.preventDefault();
      const btn = $(this);
      const urlToCheck = btn.data("link") || window.location.href;

      // Use Clipboard API with fallback
      if (navigator.clipboard) {
        navigator.clipboard
          .writeText(urlToCheck)
          .then(function () {
            const originalText = btn.text();
            btn.text("Copied!");
            setTimeout(() => btn.text(originalText), 2000);
          })
          .catch(function (err) {
            console.error("Could not copy text: ", err);
            fallbackCopyTextToClipboard(urlToCheck, btn);
          });
      } else {
        fallbackCopyTextToClipboard(urlToCheck, btn);
      }
    });

  function fallbackCopyTextToClipboard(text, btn) {
    const textArea = document.createElement("textarea");
    textArea.value = text;
    textArea.style.top = "0";
    textArea.style.left = "0";
    textArea.style.position = "fixed";
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();

    try {
      const successful = document.execCommand("copy");
      if (successful) {
        const originalText = btn.text();
        btn.text("Copied!");
        setTimeout(() => btn.text(originalText), 2000);
      }
    } catch (err) {
      console.error("Fallback: Oops, unable to copy", err);
    }
    document.body.removeChild(textArea);
  }

  // =====================================================
  // ANSWER SELECTION HANDLER
  // =====================================================

  // @MODIFIED v7.3.14: Changed from mcqList.on() to $(document).on() for consistency
  // This ensures option buttons work on ALL pages (homepage, topic pages, dynamically loaded content)
  $(document)
    .off("click.nmOptionClick")
    .on("click.nmOptionClick", ".nm-mcq-option, .nm-option-btn", function () {
      const selectedOption = $(this);
      const mcqItem = selectedOption.closest(".nm-mcq-item, .nm-mcq-card");

      if (mcqItem.hasClass("answered")) return;
      mcqItem.addClass("answered");

      const correctAnswer = mcqItem.data("answer") || mcqItem.data("correct");
      const selectedAnswer = selectedOption.data("option");
      const isCorrect =
        String(selectedAnswer).toUpperCase() ===
        String(correctAnswer).toUpperCase();

      if (isCorrect) {
        selectedOption.addClass("correct");
        mcqItem
          .find(".nm-mcq-feedback, .nm-result-message")
          .text("Correct!")
          .addClass("correct")
          .show();
      } else {
        selectedOption.addClass("wrong");
        mcqItem
          .find(".nm-mcq-feedback, .nm-result-message")
          .text("Wrong!")
          .addClass("wrong")
          .show();
        mcqItem
          .find(
            '.nm-mcq-option[data-option="' +
            correctAnswer +
            '"], .nm-option-btn[data-option="' +
            correctAnswer +
            '"]'
          )
          .addClass("correct");
      }

      mcqItem.find(".nm-show-explanation-btn").show();
      mcqItem.find(".nm-explanation, .nm-mcq-explanation").hide();
      mcqItem.find(".nm-view-link").show();

      nmIncrementScore(isCorrect);

      if (!window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
        setTimeout(() => {
          const $next = mcqItem.nextAll(".nm-mcq-item, .nm-mcq-card").first();
          if ($next.length)
            $next[0].scrollIntoView({ behavior: "smooth", block: "center" });
        }, 1200);
      }

      const postId = mcqItem.data("id") || mcqItem.data("post-id");
      if (nm_mcq_ajax_object.is_user_logged_in === "yes" && postId) {
        trackAnswer(postId, isCorrect, selectedAnswer);
      }
    });

  // ✅ MODIFIED v7.3.13: Changed to document-level delegation for Topic page support
  $(document)
    .off("click.nmShowAnswer")
    .on("click.nmShowAnswer", ".nm-show-answer-btn", function () {
      const mcqItem = $(this).closest(".nm-mcq-item, .nm-mcq-card");
      if (mcqItem.hasClass("answered")) return;
      mcqItem.addClass("answered");

      const correctAnswer = mcqItem.data("answer") || mcqItem.data("correct");
      mcqItem
        .find(
          '.nm-mcq-option[data-option="' +
          correctAnswer +
          '"], .nm-option-btn[data-option="' +
          correctAnswer +
          '"]'
        )
        .addClass("correct");
      mcqItem.find(".nm-show-explanation-btn").show();
      mcqItem.find(".nm-explanation, .nm-mcq-explanation").hide();
      mcqItem.find(".nm-view-link").show();
    });

  // ✅ MODIFIED v7.3.13: Changed to document-level delegation for Topic page support
  $(document)
    .off("click.nmShowExpl")
    .on("click.nmShowExpl", ".nm-show-explanation-btn", function () {
      const btn = $(this);
      const explanation = btn
        .closest(".nm-mcq-item, .nm-mcq-card")
        .find(".nm-mcq-explanation, .nm-explanation");

      explanation.slideToggle(400, function () {
        btn.text(
          explanation.is(":visible") ? "Hide Explanation" : "Show Explanation"
        );
      });
    });

  // ✅ MODIFIED v7.3.13: Changed to document-level delegation for Topic page support
  $(document)
    .off("click.nmReport")
    .on("click.nmReport", ".nm-report-btn", function () {
      const reportBtn = $(this);
      const reason = prompt(
        "Please provide a brief reason for reporting this question."
      );
      if (!reason) return;

      const mcqItem = reportBtn.closest(".nm-mcq-item, .nm-mcq-card");
      const postId = mcqItem.data("id") || mcqItem.data("post-id");

      $.ajax({
        url: nm_mcq_ajax_object.ajax_url,
        type: "POST",
        data: {
          action: "report_mcq",
          nonce: nm_mcq_ajax_object.nonce,
          post_id: postId,
          reason: reason,
        },
        success: function (response) {
          if (response.success) {
            reportBtn.text(" Reported").prop("disabled", true);
          } else {
            alert(
              (response && response.data && response.data.message) ||
              "Could not report question."
            );
          }
        },
        error: function () {
          alert("An error occurred while reporting the question.");
        },
      });
    });

  // =====================================================
  // TRACK ANSWER FUNCTION
  // =====================================================

  function trackAnswer(postId, wasCorrect, selectedAnswer) {
    if (!postId || typeof postId === "undefined") {
      console.error("❌ Invalid postId:", postId);
      return false;
    }

    const mcqElement = $("#mcq-" + postId);
    const questionTitle =
      mcqElement
        .find(".nm-mcq-question")
        .text()
        .replace(/^\d+\.\s*/, "") || "Question";
    const topicSlug =
      $("#nm-topic-filter").val() || $("#nm-subtopic-filter").val() || "";

    const trackingData = {
      action: "nm_log_quiz_activity",
      nonce: nm_mcq_ajax_object.nonce,
      question_id: postId,
      question_title: questionTitle,
      topic_slug: topicSlug,
      is_correct: wasCorrect ? 1 : 0,
      selected_answer: selectedAnswer || "",
      timestamp: Date.now(),
    };

    $.ajax({
      url: nm_mcq_ajax_object.ajax_url,
      type: "POST",
      dataType: "json",
      data: trackingData,
      success: function (response) {
        if (response.success) {
          console.log("✅ Answer tracked successfully:", response.data);
        } else {
          console.warn(
            "⚠️ Server returned error while tracking:",
            response.data.message || "Unknown error"
          );
        }
      },
      error: function (xhr) {
        console.error("❌ AJAX Error while tracking answer:", xhr.responseText);
      },
    });

    return true;
  }

  // =====================================================
  // SCHEMA INJECTION
  // =====================================================

  function updatePracticeProblemSchema() {
    const allMCQsData = [];

    $(".nm-mcq-item, .nm-mcq-card").each(function () {
      const item = $(this);
      const questionText = item
        .find(".nm-mcq-question")
        .text()
        .replace(/^\d+\.\s/, "");
      const options = {};

      item.find(".nm-mcq-option, .nm-option-btn").each(function () {
        const optionEl = $(this);
        const optionKey = optionEl.data("option");
        const optionText =
          optionEl.find("span:not(.nm-option-label)").text() || optionEl.text();
        options[optionKey] = optionText;
      });

      const answer = item.data("answer") || item.data("correct");

      allMCQsData.push({
        question: questionText,
        options: options,
        answer: answer,
      });
    });

    $("#nm-mcq-schema").remove();
    if (allMCQsData.length === 0) return;

    const questionList = allMCQsData.map(function (mcq) {
      const answerOptions = Object.keys(mcq.options).map(function (key) {
        return { "@type": "Answer", text: mcq.options[key] };
      });
      const correctAnswerText = mcq.options[mcq.answer] || "";
      return {
        "@type": "Question",
        name: mcq.question,
        acceptedAnswer: { "@type": "Answer", text: correctAnswerText },
        suggestedAnswer: answerOptions,
      };
    });

    const schema = {
      "@context": "https://schema.org",
      "@type": "Quiz",
      about: { "@type": "Thing", name: document.title },
      hasPart: questionList,
    };

    const script = $("<script>", {
      type: "application/ld+json",
      id: "nm-mcq-schema",
    });
    script.text(JSON.stringify(schema));
    $("head").append(script);
  }

  // =====================================================
  // INITIAL LOAD
  // =====================================================

  if (isPreRendered) {
    updatePracticeProblemSchema();

    const selectedOption = topicFilter.find("option:selected");
    const parentId = selectedOption.data("id");

    if (parentId) {
      $.ajax({
        url: nm_mcq_ajax_object.ajax_url,
        type: "POST",
        data: {
          action: "fetch_sub_topics",
          nonce: nm_mcq_ajax_object.nonce,
          parent_id: parentId,
        },
        success: function (response) {
          if (response.success && response.data.length > 0) {
            subtopicWrapper.show();
            $.each(response.data, function (index, subtopic) {
              subtopicFilter.append(
                $("<option>", {
                  value: subtopic.slug,
                  text: subtopic.name,
                })
              );
            });
          }
        },
      });
    }

    if ($(".nm-mcq-card, .nm-mcq-item").length >= initialCount) {
      paginationContainer
        .html(
          '<button id="nm-load-more-btn" class="nm-pagination-btn">Load More</button>'
        )
        .show();
    }
  } else {
    // ✅ Use debounced version for initial load too
    debouncedFetchMCQs(
      "",
      "",
      initialCount,
      false,
      initialExam,
      initialDifficulty,
      initialCognitive,
      getCurrentMonth()
    );
  }
});

