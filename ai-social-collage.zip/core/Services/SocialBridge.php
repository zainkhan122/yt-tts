<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SocialBridge {

	public static function dispatch( $post_id, $attachment_id, $job_id, $ai_detailed_description = '', $ai_headline = '' ) {
		$post = get_post( $post_id );
		if ( ! $post ) {
			return;
		}

		$campaign = get_post_meta( $post_id, Config::META_CAMPAIGN_DATA, true );
		$headline = $ai_headline ?: ( get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ) ?: $post->post_title );

		$payload = self::build_payload( $post, $attachment_id, $headline, $campaign, $ai_detailed_description );

		do_action( Config::SOCIAL_HOOK_ALL, $payload );

		$platforms = Config::get_social_platforms();
		foreach ( $platforms as $platform_key => $platform_label ) {
			do_action( Config::SOCIAL_HOOK_PREFIX . $platform_key, $payload );
		}

		// Jetpack Social integration
		if ( Config::is_jetpack_enabled() ) {
			try {
				JetpackSocial::sync( $post_id, $attachment_id );
			} catch ( \Throwable $e ) {
				Logger::warning( 'jetpack_sync_exception', $job_id, [
					'post_id' => $post_id,
					'error' => $e->getMessage(),
				] );
			}
		}

 		// Buffer API integration
 		if ( Config::is_buffer_enabled() ) {
 			try {
 				$buffer_result = BufferIntegration::share( $post_id, $attachment_id );
 				if ( ! $buffer_result ) {
 					Logger::warning( 'buffer_share_returned_false', $job_id, [
 						'post_id' => $post_id,
 					] );
 				}
 			} catch ( \Throwable $e ) {
 				Logger::warning( 'buffer_share_exception', $job_id, [
 					'post_id' => $post_id,
 					'error' => $e->getMessage(),
 				] );
 			}
 		}

		Logger::info( Config::LOG_ACTION_SOCIAL_POST, $job_id, [ 'post_id' => $post_id ], '200', 'Dispatched to ' . count( $platforms ) . ' platform hooks' );
	}

private static function build_payload( $post, $attachment_id, $headline, $campaign, $ai_detailed_description = '' ) {
		$url = wp_get_attachment_url( $attachment_id );
		$path = get_attached_file( $attachment_id );
		$image_url = $url ? $url : '';
		$image_path = $path ? $path : '';
		$brand = Config::get_brand_settings();

	$hashtags = self::generate_hashtags( $post, $campaign );

		if ( empty( $ai_detailed_description ) ) {
			$ai_detailed_description = wp_trim_words( wp_strip_all_tags( $post->post_content ), 30 );
		}

		$auto_meta = get_post_meta( $post->ID, Config::META_AUTO_META, true );
		$auto_meta = is_array( $auto_meta ) ? $auto_meta : [];
		$x_content = $auto_meta['x_content'] ?? '';
		$x_hashtags = '';
		if ( ! empty( $auto_meta['ai_x_hashtags'] ) && is_array( $auto_meta['ai_x_hashtags'] ) ) {
			$x_hashtags = implode( ' ', array_slice( $auto_meta['ai_x_hashtags'], 0, 5 ) );
		}
		$x_description = $auto_meta['ai_x_description'] ?? '';

		$twitter_desc = ! empty( $x_content ) ? $x_content : $ai_detailed_description;

		$content_type = 'image';
		if ( $attachment_id > 0 ) {
			$ct_meta = get_post_meta( $attachment_id, Config::META_CONTENT_TYPE, true );
			if ( $ct_meta === Config::CONTENT_TYPE_VIDEO ) {
				$content_type = 'video';
			} else {
				$mime = get_post_mime_type( $attachment_id );
				if ( ! empty( $mime ) && strpos( $mime, 'video/' ) === 0 ) {
					$content_type = 'video';
				}
			}
		}

		return [
			'post_id' => $post->ID,
			'post_title' => $post->post_title,
			'post_url' => get_permalink( $post->ID ),
			'post_excerpt' => wp_trim_words( wp_strip_all_tags( $post->post_content ), 30 ),
			'detailed_description' => $ai_detailed_description,
			'attachment_id' => $attachment_id,
			'image_url' => $image_url,
			'image_path' => $image_path,
			'headline' => $headline,
			'hashtags' => $hashtags,
			'x_hashtags' => $x_hashtags,
			'x_description' => $x_description,
			'campaign' => is_array( $campaign ) ? $campaign : [],
			'platform_size' => Config::get_campaign_value( $campaign, 'platform_size', Config::DEFAULT_SIZE ),
			'brand_name' => $brand['brand_name'] ?: get_bloginfo( 'name' ),
			'brand_logo_url' => $brand['logo_url'] ?: '',
			'content_type' => $content_type,
			'platform_texts' => [
				'twitter' => self::build_platform_text( $headline, $twitter_desc, $hashtags, 'twitter', $post, $x_hashtags, $x_description ),
				'instagram' => self::build_platform_text( $headline, $ai_detailed_description, $hashtags, 'instagram', $post ),
				'facebook' => self::build_platform_text( $headline, $ai_detailed_description, $hashtags, 'facebook', $post ),
				'linkedin' => self::build_platform_text( $headline, $ai_detailed_description, $hashtags, 'linkedin', $post ),
				'whatsapp' => self::build_platform_text( $headline, $ai_detailed_description, $hashtags, 'whatsapp', $post ),
				'pinterest' => self::build_platform_text( $headline, $ai_detailed_description, $hashtags, 'pinterest', $post ),
			],
			'metadata' => [
				'generated_by' => 'ai-social-collage-pro',
				'version' => Config::VERSION,
				'timestamp' => current_time( 'mysql' ),
			],
		];
	}

	public static function build_platform_text( $headline, $detailed_description, $hashtags, $platform, $post = null, $x_hashtags = '', $x_description = '' ) {
		$post_url = $post ? get_permalink( $post->ID ) : '';
		$desc = $detailed_description ?: '';

		switch ( $platform ) {
			case 'twitter':
				$text = $headline . "\n\n" . $desc;
				if ( mb_strlen( $text ) > 280 ) {
					$text = mb_substr( $text, 0, 277 ) . '…';
				}
				$twitter_hashtags = $x_hashtags ?: $hashtags;
				if ( $twitter_hashtags && mb_strlen( $text . "\n\n" . $twitter_hashtags ) <= 280 ) {
					$text .= "\n\n" . $twitter_hashtags;
				}
				return $text;

			case 'instagram':
				return $headline . "\n\n" . $desc . "\n\n" . $hashtags;

			case 'facebook':
				return $headline . "\n\n" . $desc . "\n\n" . ( $post_url ? 'Read more: ' . $post_url : '' ) . "\n" . $hashtags;

			case 'linkedin':
				$text = $headline . "\n\n" . $desc . "\n\n" . $hashtags;
				if ( mb_strlen( $text ) > 3000 ) {
					$text = mb_substr( $text, 0, 2997 ) . '…';
				}
				return $text;

			case 'whatsapp':
				return $headline . "\n\n" . $desc;

			case 'pinterest':
				$text = $headline . ' — ' . $desc;
				if ( mb_strlen( $text ) > 500 ) {
					$text = mb_substr( $text, 0, 497 ) . '…';
				}
				return $text;

			default:
				return $headline . "\n\n" . $desc . "\n\n" . $hashtags;
		}
	}

    private static function generate_hashtags( $post, $campaign ) {
        $auto_meta = get_post_meta( $post->ID, Config::META_AUTO_META, true );
        if ( is_array( $auto_meta ) && ! empty( $auto_meta['ai_hashtags'] ) ) {
            $clean = [];
            foreach ( $auto_meta['ai_hashtags'] as $tag ) {
                $tag = trim( $tag );
                $tag = ltrim( $tag, '#' );
                $tag = preg_replace( '/[^\p{L}\p{N}_]/u', '', $tag );
                if ( ! empty( $tag ) && mb_strlen( $tag, 'UTF-8' ) >= 2 ) {
                    $clean[] = '#' . $tag;
                }
            }
            if ( ! empty( $clean ) ) {
                return implode( ' ', array_slice( array_unique( $clean ), 0, 5 ) );
            }
        }

        return '';
    }

	public static function get_fs_poster_format( $payload ) {
		$platform_text = $payload['platform_texts']['facebook'] ?? ( $payload['post_excerpt'] . "\n\n" . $payload['hashtags'] );
		return [
			'post_id' => $payload['post_id'],
			'post_title' => $payload['headline'] ?: $payload['post_title'],
			'post_content' => $platform_text,
			'post_link' => $payload['post_url'],
			'image_path' => $payload['image_path'],
			'image_url' => $payload['image_url'],
			'media_id' => $payload['attachment_id'],
		];
	}

	public static function get_bit_social_format( $payload ) {
		$platform_text = $payload['platform_texts']['instagram'] ?? ( $payload['post_excerpt'] . "\n\n" . $payload['hashtags'] );
		$content_type = $payload['content_type'] ?? 'image';
		return [
			'source_post_id' => $payload['post_id'],
			'title' => $payload['headline'] ?: $payload['post_title'],
			'message' => $platform_text,
			'link' => $payload['post_url'],
			'media' => [
				'type' => $content_type,
				'url' => $payload['image_url'],
				'path' => $payload['image_path'],
				'id' => $payload['attachment_id'],
			],
			'tags' => $payload['hashtags'],
		];
	}

    public static function get_generic_format( $payload ) {
        return $payload;
    }
}
