<?php

/**
 * Error Handler
 *
 * @package DIT_TrendStudio
 * @MODIFIED 2025-12-13 - Forked from SEO Article Generator
 * @MODIFIED 2025-12-13 - Extracted exception classes to separate files for autoloader compatibility
 * @MODIFIED 2025-12-13 - Removed global error handlers to avoid interfering with other plugins
 */

namespace DIT\TrendStudio;

use DIT\TrendStudio\Infrastructure\Logger;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Centralized error handling utilities
 * 
 * Note: This class no longer hijacks global PHP error handling.
 * Use try-catch blocks in specific locations instead.
 */
class Error_Handler
{
    /**
     * Logger instance
     *
     * @var Logger
     */
    private $logger;

    /**
     * Initialize error handler (no-op, kept for backwards compatibility)
     *
     * @return void
     */
    public function init()
    {
        // No longer sets global handlers - use try-catch in plugin code instead
    }

    /**
     * Handle PHP errors
     *
     * @param int    $errno Error number
     * @param string $errstr Error message
     * @param string $errfile Error file
     * @param int    $errline Error line
     * @return bool
     */
    public function handle_error($errno, $errstr, $errfile, $errline)
    {
        // Don't handle suppressed errors
        if (!(error_reporting() & $errno)) {
            return false;
        }

        $error_types = array(
            E_ERROR => 'ERROR',
            E_WARNING => 'WARNING',
            E_PARSE => 'PARSE',
            E_NOTICE => 'NOTICE',
            E_CORE_ERROR => 'CORE_ERROR',
            E_CORE_WARNING => 'CORE_WARNING',
            E_COMPILE_ERROR => 'COMPILE_ERROR',
            E_COMPILE_WARNING => 'COMPILE_WARNING',
            E_USER_ERROR => 'USER_ERROR',
            E_USER_WARNING => 'USER_WARNING',
            E_USER_NOTICE => 'USER_NOTICE',
            E_STRICT => 'STRICT',
            E_RECOVERABLE_ERROR => 'RECOVERABLE_ERROR',
            E_DEPRECATED => 'DEPRECATED',
            E_USER_DEPRECATED => 'USER_DEPRECATED',
        );

        $type = isset($error_types[$errno]) ? $error_types[$errno] : 'UNKNOWN';

        // Log the error
        if ($this->logger) {
            $this->logger->error("[{$type}] {$errstr} in {$errfile}:{$errline}");
        }

        // Also send to PHP error_log for visibility during development
        error_log("[DIT TS PHP ERROR] [{$type}] {$errstr} in {$errfile}:{$errline}");

        // During development, let WordPress/PHP also handle it so it appears in debug.log
        if (defined('WP_DEBUG') && WP_DEBUG) {
            return false; // allow default PHP handler in dev
        }

        // In production, keep it internal
        return true;
    }

    /**
     * Handle uncaught exceptions
     *
     * @param \Throwable $exception Exception object
     * @return void
     */
    public function handle_exception($exception)
    {
        $message = sprintf(
            'Uncaught exception: %s in %s:%d',
            $exception->getMessage(),
            $exception->getFile(),
            $exception->getLine()
        );

        if ($this->logger) {
            $this->logger->error($message);
            $this->logger->error('Stack trace: ' . $exception->getTraceAsString());
        }

        // Also log to PHP error_log so nothing is truly silent
        error_log('[DIT TS EXCEPTION] ' . $message);
        error_log('[DIT TS EXCEPTION TRACE] ' . $exception->getTraceAsString());

        // Display user-friendly error for AJAX
        if (defined('DOING_AJAX') && DOING_AJAX) {
            wp_send_json_error(array(
                'message' => $this->get_user_friendly_message($exception),
            ));
        }
    }

    /**
     * Handle fatal errors on shutdown
     *
     * @return void
     */
    public function handle_shutdown()
    {
        $error = error_get_last();

        if ($error && in_array($error['type'], array(E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR))) {
            if ($this->logger) {
                $this->logger->error(
                    sprintf(
                        'Fatal error: %s in %s:%d',
                        $error['message'],
                        $error['file'],
                        $error['line']
                    )
                );
            }

            // Always mirror fatals to PHP error_log
            error_log(sprintf(
                '[DIT TS FATAL] %s in %s:%d',
                $error['message'],
                $error['file'],
                $error['line']
            ));
        }
    }

    /**
     * Get user-friendly error message
     *
     * @param \Throwable $exception Exception object
     * @return string
     */
    private function get_user_friendly_message($exception)
    {
        // Start by checking simple class names if they are in the same namespace
        // Or check full class path if migrated

        $class = get_class($exception);

        if (strpos($class, 'AI_Exception') !== false) {
            return 'Failed to connect to AI service. Please check your API key and try again.';
        }

        if (strpos($class, 'Validation_Exception') !== false) {
            return $exception->getMessage();
        }

        if (strpos($class, 'Database_Exception') !== false) {
            return 'A database error occurred. Please try again or contact support.';
        }

        if (strpos($class, 'Source_Exception') !== false) {
            return 'Failed to fetch from source: ' . $exception->getMessage();
        }

        return 'An unexpected error occurred. Please try again.';
    }

    /**
     * Set logger instance
     *
     * @param Logger $logger Logger instance
     * @return void
     */
    public function set_logger($logger)
    {
        $this->logger = $logger;
    }
}
