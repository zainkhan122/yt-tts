<?php

/**
 * AI_Network_Trait
 *
 * Centralizes network operations for AI providers (Gemini, OpenRouter, Groq, Custom).
 * Handles retries, exponential backoff, circuit breaking, and cURL hardening.
 *
 * @package DIT_TrendStudio
 */

namespace DIT\TrendStudio\Infrastructure;

use DIT\TrendStudio\AI_Exception;

if (!defined('ABSPATH')) {
    exit;
}

trait AI_Network_Trait
{
    /**
	 * Provider slug for transient keys (gemini, openrouter, groq, custom)
     * @var string
     */
    protected $provider_slug = 'unknown';

    /**
     * Cross-site mutex handle (VPS-wide). When present, calls are serialized across
     * multiple WordPress installs on the same server.
     *
     * @var resource|null
     */
    protected $dit_ts_lock_handle = null;

    /**
     * Redact secrets from URLs before logging (e.g. Gemini ?key=...).
     *
     * @MODIFIED 2026-02-24 - Prevent API keys/tokens from being written to logs.
     *
     * @param string $url
     * @return string
     */
    protected function redact_url_for_logs(string $url): string
    {
        if ($url === '') {
            return $url;
        }

        // Redact common credential query params.
        $pattern = '/([?&](?:key|api_key|apikey|access_token|token)=)[^&]+/i';
        $redacted = preg_replace($pattern, '$1REDACTED', $url);

        return is_string($redacted) ? $redacted : $url;
    }

    /**
     * Call API with retry logic for transient errors.
     *
     * @param string $url  API URL
     * @param array  $args Request arguments
     * @param int    $max_retries Max retry attempts
     * @return array|\WP_Error API response
     */
    protected function call_api_with_retry(string $url, array $args, int $max_retries = 2)
    {
        $this->check_circuit_breaker();

        $retry_count = 0;
        $wait_time = 2; // Initial wait in seconds

        // Standard Hardening
        $args['timeout'] = 120;
        @ini_set('max_execution_time', 300);
        @ini_set('output_buffering', 'Off');

        $args['stream']   = false;
        $args['blocking'] = true;
        $args['httpversion'] = '1.1';

        $force_timeout_handle = function ($handle) {
            curl_setopt($handle, CURLOPT_CONNECTTIMEOUT, 30);
            curl_setopt($handle, CURLOPT_TIMEOUT, 120);
            curl_setopt($handle, CURLOPT_BUFFERSIZE, 524288); // 512KB buffer
            curl_setopt($handle, CURLOPT_TCP_NODELAY, true);
            curl_setopt($handle, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
            curl_setopt($handle, CURLOPT_FORBID_REUSE, true);
        };

        $retry_start_time = time();

        while ($retry_count <= $max_retries) {
            if (time() - $retry_start_time > 240) {
                if ($this->logger) {
                    $this->logger->warning("{$this->provider_slug} retry loop exceeded 240s wall time; aborting retries.", [
                        'retry_count' => $retry_count,
                        'max_retries' => $max_retries,
                    ]);
                }
                break;
            }

            // @MODIFIED 2026-02-18 - Global Request Lock: Serialize calls across all threads to avoid 429 bursts
            $lock_acquired = $this->acquire_request_lock();

            // @MODIFIED 2026-02-18 - RPM Throttle: Enforce 4s gap for Gemini (Free Tier compliance)
            $this->enforce_rpm_throttle();

            add_action('http_api_curl', $force_timeout_handle);

            if ($this->logger) {
                // @MODIFIED 2026-02-24 - Redact secrets (API keys/tokens) from URLs before logging.
                $log_url = $this->redact_url_for_logs($url);

                $this->logger->info("{$this->provider_slug} API Request", [
                    'url'  => $log_url,
                    'body' => json_decode($args['body'] ?? '{}', true) ?: 'Raw: ' . substr($args['body'] ?? 'None', 0, 500),
                ]);
            }

            $response = wp_remote_post($url, $args);
            remove_action('http_api_curl', $force_timeout_handle);

            // @MODIFIED 2026-02-25 - Persist last request time (VPS-wide when file lock is active)
            // and then release the lock.
            $this->store_last_request_time();
            $this->release_request_lock();

            if (is_wp_error($response)) {
                $error_msg  = $response->get_error_message();
                if ($this->logger) {
                    // @MODIFIED 2026-02-24 - Redact secrets (API keys/tokens) from URLs before logging.
                    $this->logger->error("{$this->provider_slug} API Error: {$error_msg}", [
                        'code' => $response->get_error_code(),
                        'url'  => $this->redact_url_for_logs($url),
                    ]);
                }

                if ($retry_count < $max_retries) {
                    $retry_count++;
                    sleep($wait_time);
                    $wait_time *= 2;
                    continue;
                }

                $this->record_circuit_failure();
                return $response;
            }

            $code     = wp_remote_retrieve_response_code($response);
            $raw_body = wp_remote_retrieve_body($response);

            if ($this->logger) {
                $this->logger->info("{$this->provider_slug} API Response Metrics", [
                    'code'   => $code,
                    'length' => strlen($raw_body),
                    'body'   => $raw_body
                ]);
            }

        // @MODIFIED 2026-04-23 - Three-Layer Intelligence: ALL 429/413 errors
        // now go through API_Error_Parser → Quota_State_Manager → Backoff_Strategy
        // instead of legacy string-matching + inline backoff.
        // @MODIFIED 2026-05-06 - 5xx (503 etc.) are NOT retried in-process.
        // Each retry burns an API call against daily quota (free tier: 20/day).
        // The scheduler's handle_job_error reschedules with proper three-layer backoff.
        if (($code === 429 || $code === 413) && $retry_count < $max_retries) {
            if ($code === 429 || $code === 413) {
                $has_layers = class_exists('DIT\\TrendStudio\\Infrastructure\\API_Error_Parser')
                    && class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_State_Manager')
                    && class_exists('DIT\\TrendStudio\\Infrastructure\\Backoff_Strategy');

                if ($has_layers) {
                    $headers = wp_remote_retrieve_headers($response);
                    $error_info = \DIT\TrendStudio\Infrastructure\API_Error_Parser::parse(
                        $this->provider_slug, $code, $raw_body, (array) $headers
                    );
                    \DIT\TrendStudio\Infrastructure\Quota_State_Manager::calibrate_from_error($this->provider_slug, $error_info);

                    if (!empty($error_info['is_quota_zero'])) {
                        $this->record_circuit_failure();
                        return $response;
                    }

                    // @MODIFIED 2026-07-14 - Check for RPD daily quota limit. If exhausted, do not retry in-process. Pause immediately and fail so fallback chain triggers instantly.
                    $is_rpd = ($error_info['quota_bucket'] === 'rpd' || $error_info['error_type'] === 'daily_quota');
                    if ($is_rpd) {
                        $reason = \DIT\TrendStudio\Infrastructure\Backoff_Strategy::get_reason($error_info);
                        if (class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Pause_Manager')) {
                            \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::pause($this->provider_slug, $reason, 3600, 86400);
                        }
                        $this->record_circuit_failure();
                        if ($this->logger) {
                            $this->logger->warning("{$this->provider_slug} DAILY QUOTA (RPD) EXHAUSTED. Pausing provider immediately and aborting in-process retries.");
                        }
                        return $response;
                    }

                    $quota_health = \DIT\TrendStudio\Infrastructure\Quota_State_Manager::get_health($this->provider_slug);
                    $consecutive = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::get_consecutive_daily_quota_429s($this->provider_slug);
                $wait_time = \DIT\TrendStudio\Infrastructure\Backoff_Strategy::calculate($error_info, $quota_health, $consecutive + 1);

                if (\DIT\TrendStudio\Infrastructure\Backoff_Strategy::should_pause($error_info, $consecutive)) {
                    $reason = \DIT\TrendStudio\Infrastructure\Backoff_Strategy::get_reason($error_info);
                    \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::pause($this->provider_slug, $reason, 3600, 86400);
                    $this->record_circuit_failure();
                    return $response;
                }

                // @FIXED 2026-04-24 - Cap in-process sleep to 120s max.
                // Delays beyond 120s indicate daily_quota or sustained rate limits
                // that should be handled by job rescheduling, not by blocking this PHP process.
                $wait_time = min($wait_time, 120);
            } else {
                // Legacy fallback: parse Retry-After header + scan body for retryDelay
                $retry_after = wp_remote_retrieve_header($response, 'retry-after');
                if (is_numeric($retry_after)) {
                    $wait_time = max((int)$retry_after, $wait_time);
                } else {
                    $body_json = json_decode($raw_body, true);
                    if (isset($body_json['error']['details'])) {
                        foreach ($body_json['error']['details'] as $detail) {
                            if (isset($detail['retryDelay'])) {
                                $extracted_delay = (int)$detail['retryDelay'];
                                if ($extracted_delay > 0) {
                                    $wait_time = max($extracted_delay, $wait_time);
                                }
                            }
                        }
                    }
                    if ($wait_time < 90) {
                        $wait_time = max($wait_time, 90);
                    }
                }
                // @FIXED 2026-04-24 - Cap legacy sleep to 120s max to prevent
                // multi-hour process blocking (e.g. 23491s from daily_quota retryDelay)
                $wait_time = min($wait_time, 120);
            }
            }

            $retry_count++;
            if ($this->logger) {
                $this->logger->warning("{$this->provider_slug} API returned {$code}. Retrying in {$wait_time}s ({$retry_count}/{$max_retries})");
            }
            sleep($wait_time);
            $wait_time *= 2;
            continue;
        }

        // Terminal codes
        if ($code < 400 || $code === 401 || $code === 403 || $code === 404) {
            if ($code === 200) {
                $this->record_circuit_success();
                // @MODIFIED 2026-04-22 - Reset ALL consecutive error counters on success
                if (class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Pause_Manager')) {
                    \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::reset_consecutive_on_success($this->provider_slug);
                    // @MODIFIED 2026-05-05 - Clear stale provider pause since quota has clearly recovered
                    if (\DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::is_paused($this->provider_slug)) {
                        \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::clear($this->provider_slug);
                        if ($this->logger) {
                            $this->logger->info("{$this->provider_slug} API success: Cleared stale quota pause.");
                        }
                    }
                }
            } else {
                    $this->record_circuit_failure();
                }
                return $response;
            }

            $this->record_circuit_failure();
            return $response;
        }

        $this->record_circuit_failure();
        return $response;
    }

    /**
     * Check circuit breaker state
     * @throws AI_Exception if circuit is open
     */
    protected function check_circuit_breaker(): void
    {
        if (!\get_option('dit_ts_circuit_breaker_enabled', true)) {
            return;
        }

        $failures           = (int) \get_transient("dit_ts_{$this->provider_slug}_circuit_failures");
        $circuit_open_until = (int) \get_transient("dit_ts_{$this->provider_slug}_circuit_open_until");

        if ($circuit_open_until && \time() < $circuit_open_until) {
            $wait = $circuit_open_until - \time();
            throw new AI_Exception(
                "Circuit breaker is OPEN for {$this->provider_slug}. API paused for {$wait}s due to repeated failures."
            );
        }

        if ($failures >= 3) {
            $open_duration = 120; // 2 minutes
            \set_transient("dit_ts_{$this->provider_slug}_circuit_open_until", \time() + $open_duration, $open_duration);
            throw new AI_Exception("Circuit breaker OPENED for {$this->provider_slug} after 3 consecutive failures.");
        }
    }

    /**
     * Record success (reset circuit)
     */
    protected function record_circuit_success(): void
    {
        \delete_transient("dit_ts_{$this->provider_slug}_circuit_failures");
        \delete_transient("dit_ts_{$this->provider_slug}_circuit_open_until");
    }

    /**
     * Record failure (increment counter)
     */
    protected function record_circuit_failure(): void
    {
        $failures = (int) \get_transient("dit_ts_{$this->provider_slug}_circuit_failures");
        $failures++;
        \set_transient("dit_ts_{$this->provider_slug}_circuit_failures", $failures, 600); // 10 min window
    }

    /**
     * Acquire a global lock to serialize AI requests across all processes.
     * @MODIFIED 2026-02-18 - Fix: Activate and utilize the semaphore system
     */
    protected function acquire_request_lock()
    {
        // @MODIFIED 2026-02-25 - Prefer VPS-wide file lock (works across multiple WP installs)
        // to prevent multi-site bursts when the same API key is shared.
        $lock_path = $this->get_global_lock_path();
        if ($lock_path !== '') {
            $fh = @fopen($lock_path, 'c');
            if (is_resource($fh)) {
                $max_wait = 15;
                $waited = 0.0;
                while ($waited < $max_wait) {
                    if (@flock($fh, LOCK_EX | LOCK_NB)) {
                        $this->dit_ts_lock_handle = $fh;
                        return true;
                    }
                    usleep(500000);
                    $waited += 0.5;
                }
                @fclose($fh);
            }
        }

        $lock_key = 'dit_ts_ai_request_mutex';
        $max_wait = 15; // 15 seconds max wait
        $waited   = 0;

        while ($waited < $max_wait) {
            // Atomic add_option as mutex
            if (add_option($lock_key, time(), '', 'no')) {
                return true;
            }

            // Check if lock is stale (> 30s)
            $lock_time = (int) get_option($lock_key);
            if ($lock_time && (time() - $lock_time > 30)) {
                delete_option($lock_key);
                if (add_option($lock_key, time(), '', 'no')) {
                    return true;
                }
            }

            usleep(500000); // Wait 0.5s
            $waited += 0.5;
        }

        if ($this->logger) {
            $this->logger->warning("{$this->provider_slug} Request lock timeout after {$max_wait}s. Proceeding anyway.");
        }
        return false;
    }

    /**
     * Release the global request lock.
     */
    protected function release_request_lock()
    {
        if (is_resource($this->dit_ts_lock_handle)) {
            @flock($this->dit_ts_lock_handle, LOCK_UN);
            @fclose($this->dit_ts_lock_handle);
            $this->dit_ts_lock_handle = null;
            return;
        }
        delete_option('dit_ts_ai_request_mutex');
    }

    /**
     * Enforce a cool-down period between requests for Free Tier compliance.
     * @MODIFIED 2026-02-18 - Universalized for all providers
     */
    protected function enforce_rpm_throttle()
    {
        // @MODIFIED 2026-04-23 - Three-Layer Intelligence: use Quota_State_Manager
        // for predictive throttling instead of hardcoded min_gap
        $recommended = 0;
        if (class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_State_Manager')) {
            $recommended = Quota_State_Manager::get_recommended_interval($this->provider_slug);
            Quota_State_Manager::wait_for_safe_slot($this->provider_slug);
            // Use recommended interval, but don't exceed hard safety limit
            $min_gap = min($recommended, 30);
        } else {
            // Fallback: legacy hardcoded gaps
            $min_gap = ($this->provider_slug === 'gemini') ? 4 : 1;
        }

        $last_request = 0;
        if (is_resource($this->dit_ts_lock_handle)) {
            $last_request = (int) $this->read_global_last_request_time();
        } else {
            $last_request = (int) get_transient("dit_ts_{$this->provider_slug}_last_request_time");
        }

        $now = time();

        if ($last_request && ($now - $last_request) < $min_gap) {
            $wait = (int) ($min_gap - ($now - $last_request));
            if ($this->logger) {
                $this->logger->info("{$this->provider_slug} RPM Throttle: Sleeping {$wait}s (recommended: {$recommended}s).");
            }
            sleep($wait);
        }
    }

    /**
     * Persist last request time.
     *
     * @MODIFIED 2026-02-25 - Writes to VPS-wide file when global lock is active.
     */
    protected function store_last_request_time(): void
    {
        $now = time();

        if (is_resource($this->dit_ts_lock_handle)) {
            $path = $this->get_global_last_request_path();
            if ($path !== '') {
                @file_put_contents($path, (string) $now, LOCK_EX);
            }
        }

        set_transient("dit_ts_{$this->provider_slug}_last_request_time", $now, 60);
    }

    /**
     * VPS-wide lock file.
     */
    protected function get_global_lock_path(): string
    {
        $dir = (string) @sys_get_temp_dir();
        if ($dir === '' || !is_dir($dir) || !is_writable($dir)) {
            return '';
        }
        $slug = sanitize_key($this->provider_slug);
        return rtrim($dir, '/\\') . DIRECTORY_SEPARATOR . 'dit_ts_ai_mutex_' . $slug . '.lock';
    }

    /**
     * VPS-wide last request tracking file.
     */
    protected function get_global_last_request_path(): string
    {
        $dir = (string) @sys_get_temp_dir();
        if ($dir === '' || !is_dir($dir) || !is_writable($dir)) {
            return '';
        }
        $slug = sanitize_key($this->provider_slug);
        return rtrim($dir, '/\\') . DIRECTORY_SEPARATOR . 'dit_ts_ai_last_' . $slug . '.txt';
    }

    /**
     * Read VPS-wide last request time.
     */
    protected function read_global_last_request_time(): int
    {
        $path = $this->get_global_last_request_path();
        if ($path === '' || !file_exists($path)) {
            return 0;
        }
        $raw = (string) @file_get_contents($path);
        return (int) trim($raw);
    }

    /**
     * Signal that this provider's daily quota is exhausted.
     * Called only after handle_429() confirms the error warrants a full pause.
     */
 protected function signal_daily_quota_exhausted()
 {
 if (class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Pause_Manager')) {
 \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::pause($this->provider_slug, 'daily_quota_exhausted', 3600, 86400);
 if ($this->logger) {
 $this->logger->warning("{$this->provider_slug} DAILY QUOTA EXHAUSTED — confirmed by adaptive classifier. Full pause activated.");
 }
 }

 delete_transient("dit_ts_{$this->provider_slug}_daily_quota_exhausted");
 if ($this->provider_slug === 'gemini') {
 delete_transient('dit_ts_gemini_quota_pause');
 }
 }
}
