<?php

/**
 * E-E-A-T Author Profile Manager
 * 
 * Extends WordPress users with SEO-relevant credentials for Google E-E-A-T compliance.
 * Registers user meta fields, renders profile UI, and provides data access methods.
 *
 * @package SEO_Article_Generator
 * @since   2.2.0
 */

namespace SEO_Article_Generator\EEAT;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Author Profile System
 * 
 * Extends WordPress users with E-E-A-T credentials:
 * - Professional title (jobTitle in schema)
 * - Bio (description in schema)
 * - Credentials (hasCredential in schema)
 * - Social profiles (sameAs in schema)
 * - Admin verification status
 */
class Author_Profile_Manager
{

    /**
     * Register custom user meta fields for E-E-A-T
     * @MODIFIED 2025-12-16 v2.2.0: Created for E-E-A-T compliance
     */
    public function register_user_meta()
    {
        register_meta('user', 'seo_author_title', [
            'type'              => 'string',
            'description'       => 'Professional title (e.g., Software Reviewer, Tech Analyst)',
            'single'            => true,
            'sanitize_callback' => 'sanitize_text_field',
            'show_in_rest'      => true,
        ]);

        register_meta('user', 'seo_author_bio', [
            'type'              => 'string',
            'description'       => 'Short professional bio (2-3 sentences)',
            'single'            => true,
            'sanitize_callback' => 'sanitize_textarea_field',
            'show_in_rest'      => true,
        ]);

        register_meta('user', 'seo_author_credentials', [
            'type'              => 'string',
            'description'       => 'Years of experience or certifications',
            'single'            => true,
            'sanitize_callback' => 'sanitize_text_field',
            'show_in_rest'      => true,
        ]);

        register_meta('user', 'seo_author_social_links', [
            'type'              => 'string',
            'description'       => 'JSON array of social profiles',
            'single'            => true,
            'sanitize_callback' => [$this, 'sanitize_social_links'],
            'show_in_rest'      => true,
        ]);

        register_meta('user', 'seo_author_verified', [
            'type'              => 'boolean',
            'description'       => 'Admin-verified author status',
            'single'            => true,
            'default'           => false,
            'show_in_rest'      => true,
        ]);
    }

    /**
     * Sanitize social links JSON
     */
    public function sanitize_social_links($value)
    {
        $decoded = json_decode($value, true);

        if (! is_array($decoded)) {
            return wp_json_encode([]);
        }

        $sanitized = [];
        $allowed_platforms = ['twitter', 'linkedin', 'github', 'website'];

        foreach ($decoded as $platform => $url) {
            if (in_array($platform, $allowed_platforms, true)) {
                $sanitized[$platform] = esc_url_raw($url);
            }
        }

        return wp_json_encode($sanitized);
    }

    /**
     * Get author profile data
     * 
     * @param int $user_id WordPress user ID
     * @return array|null Complete author profile or null if user not found
     */
    public function get_author_profile($user_id)
    {
        $user = get_userdata($user_id);

        if (! $user) {
            return null;
        }

        $social_links = get_user_meta($user_id, 'seo_author_social_links', true);
        $social_links = $social_links ? json_decode($social_links, true) : [];

        return [
            'id'            => $user_id,
            'name'          => $user->display_name,
            'email'         => $user->user_email,
            'title'         => get_user_meta($user_id, 'seo_author_title', true),
            'bio'           => get_user_meta($user_id, 'seo_author_bio', true),
            'credentials'   => get_user_meta($user_id, 'seo_author_credentials', true),
            'social_links'  => $social_links,
            'verified'      => (bool) get_user_meta($user_id, 'seo_author_verified', true),
            'avatar_url'    => get_avatar_url($user_id, ['size' => 200]),
            'posts_url'     => get_author_posts_url($user_id),
            'total_posts'   => count_user_posts($user_id, 'post'),
        ];
    }

    /**
     * Add custom fields to user profile page
     * 
     * @param WP_User $user User object
     */
    public function render_profile_fields($user)
    {
        $profile = $this->get_author_profile($user->ID);
?>
        <h2>SEO Author Profile (E-E-A-T Signals)</h2>
        <p class="description">
            These fields help Google understand your expertise and build trust in your content.
            <strong>Tip:</strong> Complete profiles significantly improve E-E-A-T scores.
        </p>

        <table class="form-table">
            <tr>
                <th><label for="seo_author_title">Professional Title *</label></th>
                <td>
                    <input
                        type="text"
                        name="seo_author_title"
                        id="seo_author_title"
                        value="<?php echo esc_attr($profile['title']); ?>"
                        class="regular-text"
                        placeholder="e.g., Senior Software Reviewer" />
                    <p class="description">
                        Your job title or role. Examples: "Tech Analyst", "Software Engineer", "IT Consultant"
                    </p>
                </td>
            </tr>

            <tr>
                <th><label for="seo_author_credentials">Credentials</label></th>
                <td>
                    <input
                        type="text"
                        name="seo_author_credentials"
                        id="seo_author_credentials"
                        value="<?php echo esc_attr($profile['credentials']); ?>"
                        class="regular-text"
                        placeholder="e.g., 10+ years in software testing" />
                    <p class="description">
                        Years of experience, certifications, or relevant qualifications
                    </p>
                </td>
            </tr>

            <tr>
                <th><label for="seo_author_bio">Professional Bio *</label></th>
                <td>
                    <textarea
                        name="seo_author_bio"
                        id="seo_author_bio"
                        rows="4"
                        class="large-text"
                        placeholder="Write 2-3 sentences about your background and expertise..."><?php echo esc_textarea($profile['bio']); ?></textarea>
                    <p class="description">
                        <strong>Max 200 words.</strong> Focus on relevant experience, not generic claims.
                        Bad: "I love technology!" | Good: "I've tested 500+ Windows applications since 2015."
                    </p>
                </td>
            </tr>

            <tr>
                <th><label>Social Profiles</label></th>
                <td>
                    <?php
                    $platforms = ['twitter', 'linkedin', 'github', 'website'];
                    foreach ($platforms as $platform) :
                        $url = $profile['social_links'][$platform] ?? '';
                    ?>
                        <label style="display: block; margin-bottom: 10px;">
                            <span style="display: inline-block; width: 80px; font-weight: 600;">
                                <?php echo esc_html(ucfirst($platform)); ?>:
                            </span>
                            <input
                                type="url"
                                name="seo_social_<?php echo esc_attr($platform); ?>"
                                value="<?php echo esc_url($url); ?>"
                                class="regular-text"
                                placeholder="https://<?php echo esc_attr($platform); ?>.com/yourprofile" />
                        </label>
                    <?php endforeach; ?>
                    <p class="description">
                        Add at least one social profile to strengthen your authorship identity.
                    </p>
                </td>
            </tr>

            <?php if (current_user_can('manage_options')) : ?>
                <tr>
                    <th><label for="seo_author_verified">Verified Author</label></th>
                    <td>
                        <label>
                            <input
                                type="checkbox"
                                name="seo_author_verified"
                                id="seo_author_verified"
                                value="1"
                                <?php checked($profile['verified'], true); ?> />
                            Mark this author as verified
                        </label>
                        <p class="description">
                            <strong>Admin only.</strong> Shows "Verified" badge on author byline.
                            Use for staff writers with proven expertise.
                        </p>
                    </td>
                </tr>
            <?php endif; ?>
        </table>

        <style>
            .eeat-profile-preview {
                background: #f9f9f9;
                border: 1px solid #ddd;
                border-radius: 6px;
                padding: 15px;
                margin-top: 20px;
            }

            .eeat-profile-preview h4 {
                margin-top: 0;
            }

            .eeat-profile-preview .author-avatar {
                width: 60px;
                height: 60px;
                border-radius: 50%;
                float: left;
                margin-right: 15px;
            }
        </style>

        <div class="eeat-profile-preview">
            <h4>Preview: How This Appears in Articles</h4>
            <img src="<?php echo esc_url($profile['avatar_url']); ?>" class="author-avatar" alt="">
            <div>
                <strong><?php echo esc_html($profile['name']); ?></strong>
                <?php if ($profile['verified']) : ?>
                    <span style="color: #00a32a;">✓ Verified</span>
                <?php endif; ?>
                <br>
                <em><?php echo esc_html($profile['title'] ?: 'No title set'); ?></em>
                <?php if ($profile['credentials']) : ?>
                    <br><small><?php echo esc_html($profile['credentials']); ?></small>
                <?php endif; ?>
            </div>
        </div>
<?php
    }

    /**
     * Save custom profile fields
     * 
     * @param int $user_id User ID being edited
     */
    public function save_profile_fields($user_id)
    {
        if (! current_user_can('edit_user', $user_id)) {
            return;
        }

        // Save simple text fields
        $text_fields = ['seo_author_title', 'seo_author_bio', 'seo_author_credentials'];
        foreach ($text_fields as $field) {
            if (isset($_POST[$field])) {
                update_user_meta($user_id, $field, sanitize_text_field($_POST[$field]));
            }
        }

        // Save social links
        $social_links = [];
        $platforms = ['twitter', 'linkedin', 'github', 'website'];
        foreach ($platforms as $platform) {
            if (! empty($_POST["seo_social_{$platform}"])) {
                $social_links[$platform] = esc_url_raw($_POST["seo_social_{$platform}"]);
            }
        }
        update_user_meta($user_id, 'seo_author_social_links', wp_json_encode($social_links));

        // Save verified status (admin only)
        if (current_user_can('manage_options')) {
            $verified = isset($_POST['seo_author_verified']) ? 1 : 0;
            update_user_meta($user_id, 'seo_author_verified', $verified);
        }
    }
}
