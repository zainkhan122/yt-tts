/**
 * MCQ Video Studio — Server Media Preparation
 *
 * Resolves every asset the preview uses so the server render is pixel/audio
 * faithful: fonts (registered into node-canvas), background image, background
 * video frames (extracted with FFmpeg), logo image, SFX files, and TTS
 * voiceover WAVs (generated via the bundled edge-tts-helper.js).
 *
 * All failures are non-fatal: missing fonts fall back to system, missing bg
 * video falls back to gradient, missing SFX/TTS are skipped — exactly like the
 * browser preview's graceful degradation.
 *
 * @package MCQ_Video_Studio
 * @subpackage render-service/render-core
 */

'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');
const http = require('http');
const https = require('https');
const { spawnSync } = require('child_process');
const { createCanvas, Image, registerFont } = require('canvas');

function httpGet(url) {
    return new Promise((resolve, reject) => {
        const lib = url.startsWith('https') ? https : http;
        const req = lib.get(url, { timeout: 30000 }, (res) => {
            if (res.statusCode < 200 || res.statusCode >= 300) {
                reject(new Error('HTTP ' + res.statusCode + ' for ' + url));
                res.resume();
                return;
            }
            const chunks = [];
            res.on('data', (c) => chunks.push(c));
            res.on('end', () => resolve(Buffer.concat(chunks)));
        });
        req.on('timeout', () => { req.destroy(new Error('timeout' + url)); });
        req.on('error', reject);
    });
}

function ffmpegProbeHasVideo(ffmpegBin, file) {
    const r = spawnSync(ffmpegBin, ['-i', file], { stdio: ['ignore', 'pipe', 'pipe'] });
    return /Stream.*Video/.test(r.stderr.toString());
}

function tmpFile(prefix, ext) {
    return path.join(os.tmpdir(), prefix + '_' + process.pid + '_' + Math.random().toString(36).slice(2) + (ext || ''));
}

/**
 * Register TTF/OTF fonts used by the template into node-canvas.
 * Mirrors studio.export.js prepareFonts (same font family -> file map).
 */
function prepareFonts(assetsJsDir, templateFonts, fontOverride, templateFontWeights) {
    const candidates = [
        path.join(assetsJsDir, 'fonts'),
        path.join(assetsJsDir, '..', 'fonts'),
    ];
    const fontsDir = candidates.find((d) => fs.existsSync(d));
    if (!fontsDir) return;

    const fontMap = {
        'Inter': 'Inter-Bold.ttf',
        'Outfit': 'Outfit-Bold.ttf',
        'Roboto': 'Roboto-Black.ttf',
        'Bangers': 'Bangers-Regular.ttf',
        'Permanent Marker': 'PermanentMarker-Regular.ttf',
        'Orbitron': 'Orbitron-Bold.ttf',
        'Press Start 2P': 'PressStart2P-Regular.ttf',
        'Creepster': 'Creepster-Regular.ttf',
        'Cinzel': 'Cinzel-Bold.ttf',
        'Audiowide': 'Audiowide-Regular.ttf',
        'Open Sans': 'OpenSans-Bold.ttf',
        'Lato': 'Lato-Bold.ttf',
        'Playfair Display': 'PlayfairDisplay-Bold.ttf',
        'Quicksand': 'Quicksand-Bold.ttf',
        'Rajdhani': 'Rajdhani-Bold.ttf',
        'Electrolize': 'Electrolize-Regular.ttf',
        'Exo 2': 'Exo2-Regular.ttf',
        'Nosifer': 'Nosifer-Regular.ttf',
        'Roboto Mono': 'RobotoMono-Bold.ttf',
        'VT323': 'VT323-Regular.ttf',
        'Share Tech Mono': 'ShareTechMono-Regular.ttf',
        'Patrick Hand': 'PatrickHand-Regular.ttf',
        'EB Garamond': 'EBGaramond-Bold.ttf',
        'Fira Code': 'FiraCode-Bold.ttf',
        'JetBrains Mono': 'JetBrainsMono-Bold.ttf',
        'Bebas Neue': 'BebasNeue-Regular.ttf',
        'Oswald': 'Oswald-Bold.ttf',
    };

    const weightFileMap = {
        'Inter': { '700': 'Inter-Bold.ttf' },
        'Roboto': { '700': 'Roboto-Bold.ttf', '900': 'Roboto-Black.ttf' },
        'Outfit': { '700': 'Outfit-Bold.ttf' },
    };

    // @FIX 2026-08-11: Normalize any requested weight to the 400/700/900 buckets we
    //       actually register. All bundled font files are single-weight, so we register
    //       the same file for 400/700/900 (and 500/600 map to their nearest bucket).
    //       Previously weights like 500/600 from template configs were requested but never
    //       registered on the server — node-canvas then fell back to a tiny default font
    //       (the "unreadable text" bug). The browser has the same single-file @font-face
    //       with all weights mapped to the same file, so this matches.
    const normalizeWeight = (w) => {
        const n = parseInt(String(w || '').replace(/\D/g, ''), 10) || 400;
        if (n >= 800) return '900';
        if (n >= 600) return '700';
        return '400';
    };

    const families = new Set();
    if (fontOverride) families.add(fontOverride.split(',')[0].trim().replace(/['"]/g, ''));
    if (templateFonts && typeof templateFonts === 'object' && !Array.isArray(templateFonts)) {
        if (templateFonts.primary) families.add(templateFonts.primary.split(',')[0].trim().replace(/['"]/g, ''));
        if (templateFonts.secondary) families.add(templateFonts.secondary.split(',')[0].trim().replace(/['"]/g, ''));
    } else if (Array.isArray(templateFonts)) {
        templateFonts.forEach((f) => families.add(f.split(',')[0].trim().replace(/['"]/g, '')));
    }
    families.add('Inter');

    // Register each font family with ALL weights the template needs
    families.forEach((name) => {
        const file = fontMap[name];
        if (!file) return;

        // Collect the weights this font family needs (normalized to 400/700/900).
        // @FIX 2026-08-11 (CRITICAL): always register the full 400/700/900 set. Every
        //       bundled font file is single-weight, and templates/text-presets request
        //       weights across the range (e.g. classicBold question = 900). If a weight
        //       is missing, node-canvas falls back to a broken tiny default font, which
        //       misrenders text ("unreadable" bug). Registering all three buckets with
        //       the same file is harmless and makes any template/text-preset work.
        const neededWeights = new Set(['400', '700', '900']);

        if (templateFontWeights && typeof templateFontWeights === 'object') {
            Object.values(templateFontWeights).forEach((w) => {
                if (w) neededWeights.add(normalizeWeight(w));
            });
        }

        const wm = weightFileMap[name];
        if (wm) Object.keys(wm).forEach((w) => neededWeights.add(w));

        const regResults = [];
        neededWeights.forEach((w) => {
            // Try weight-specific file first, fallback to the base font file
            const wFile = wm && wm[w] ? wm[w] : file;
            const wfp = path.join(fontsDir, wFile);
            const exists = fs.existsSync(wfp);
            try {
                if (exists) registerFont(wfp, { family: name, weight: w });
                regResults.push(w + ':' + wFile + ':' + (exists ? 'OK' : 'MISSING'));
            } catch (e) { regResults.push(w + ':' + wFile + ':ERR:' + e.message); }
        });
        const _log = (typeof global !== 'undefined' && global.__MCQVS_RENDER_LOG) || console.log;
        _log('[prepareFonts] family=' + name + ' weights=' + Array.from(neededWeights).join(',') + ' results=[' + regResults.join(' ') + '] fontsDir=' + fontsDir);
    });
}

function loadImageFile(file) {
    if (!file || !fs.existsSync(file)) return null;
    try {
        const img = new Image();
        const buf = fs.readFileSync(file);
        img.src = buf;
        return img;
    } catch (_) {
        return null;
    }
}

/**
 * Extract background video frames with FFmpeg, matching the browser's
 * `bgVideoFrameDur` cadence. Returns array of node-canvas Images.
 * @param {number} [totalMs] - Total render duration in ms. If provided, extracts
 *   enough frames to cover the full duration (capped at 18000 frames ~10 min @30fps).
 */
function extractBgVideoFrames(ffmpegBin, videoUrl, width, height, frameDur, totalMs) {
    try {
        // @FIX: Sanitize URL — WordPress sanitize_text_field preserves literal spaces
        //       (e.g. "Abstract Art (5).mp4"), but new URL() and http.get() throw on
        //       un-encoded spaces. Encode them to %20 so the URL is valid.
        const safeUrl = videoUrl.replace(/ /g, '%20');
        // @FIX: Local filesystem paths (e.g. "C:\...\bg-videos\file.mp4" or
        //       "/var/www/.../bg-videos/file.mp4") are not valid URLs; new URL()
        //       throws on Windows drive letters, which would abort frame extraction
        //       before the fs.existsSync(local path) branch below can run. Derive the
        //       extension with path.extname for non-HTTP inputs.
        let ext;
        if (/^https?:\/\//i.test(safeUrl)) {
            ext = path.extname(new URL(safeUrl, 'http://x').pathname) || '.mp4';
        } else {
            ext = path.extname(safeUrl) || '.mp4';
        }
        // Download remote URL to temp first.
        let localVideo = safeUrl;
        if (/^https?:\/\//i.test(safeUrl)) {
            const tmpVid = tmpFile('mcqvs_bgvid', ext);
            fs.writeFileSync(tmpVid, syncHttp(safeUrl));
            localVideo = tmpVid;
        } else if (fs.existsSync(videoUrl)) {
            localVideo = videoUrl;
        } else {
            return [];
        }
        if (!ffmpegProbeHasVideo(ffmpegBin, localVideo)) return [];

        const outDir = fs.mkdtempSync(path.join(os.tmpdir(), 'mcqvs_bgframes_'));
        const fps = (1000 / frameDur).toFixed(4);
        // Calculate required frames: cover full render duration, cap at 18000 (10 min @ 30fps)
        const requiredFrames = totalMs ? Math.min(18000, Math.ceil(totalMs / frameDur)) : 60;
        const r = spawnSync(ffmpegBin, [
            '-i', localVideo,
            '-vf', `fps=${fps},scale=${width}:${height}:force_original_aspect_ratio=decrease,pad=${width}:${height}:(ow-iw)/2:(oh-ih)/2`,
            '-frames:v', String(requiredFrames),
            path.join(outDir, 'frame_%04d.png'),
        ], { stdio: 'pipe' });
        if (r.status !== 0) return [];

        const frames = fs.readdirSync(outDir)
            .filter((f) => f.endsWith('.png'))
            .sort()
            .map((f) => loadImageFile(path.join(outDir, f)))
            .filter(Boolean);
        return frames;
    } catch (e) {
        console.warn('[media-prep] extractBgVideoFrames failed:', e.message);
        return [];
    }
}

function syncHttp(url) {
    // Synchronous HTTP GET for small assets with redirect following (max 5 hops).
    // @FIX: writeFileSync(1, ...) writes to fd 1 (stdout), not fd 0 (stdin).
    //       The old code wrote to fd 0 which returned empty buffers, silently
    //       breaking all remote asset downloads (bg-video, logo, music).
    //       Added redirect handling: 301/302/307/308 with Location header.
    const data = spawnSync(process.execPath, ['-e',
        `const u=process.argv[1];const MAX_REDIRECTS=5;` +
        `(function f(url,n){if(n>MAX_REDIRECTS)throw Error('redirect_loop');` +
        `const l=url.startsWith('https')?require('https'):require('http');` +
        `l.get(url,{timeout:60000},r=>{` +
        `if(r.statusCode>=300&&r.statusCode<400&&r.headers.location){` +
        `const loc=new URL(r.headers.location,url).href;f(loc,n+1);return;` +
        `}` +
        `const c=[];r.on('data',d=>c.push(d));r.on('end',()=>{` +
        `const b=Buffer.concat(c);require('fs').writeFileSync(1,b);` +
        `});}).on('error',e=>{require('fs').writeSync(2,e.message);process.exit(1)});` +
        `})(u,0);`,
        url], { encoding: 'buffer', stdio: ['pipe', 'pipe', 'pipe'] });
    if (data.status !== 0) return Buffer.alloc(0);
    return data.stdout;
}

/**
 * Generate a voiceover WAV from text using the bundled edge-tts-helper.js.
 * Returns the WAV path (converted from the helper's MP3) or null.
 */
// @FIX 1.4.9.49 (TTS SSOT): Only canonical Edge voice IDs reach the helper.
// Browser Web Speech names (e.g. "Microsoft David - English (United States)")
// leak from the Studio preview and are rejected by Edge (~0.3s empty response).
const EDGE_VOICE_RE = /^[a-z]{2}-[A-Z]{2}-[A-Za-z]+Neural$/;
function normalizeEdgeVoice(voice) {
    const v = String(voice || '').trim();
    if (!v || v === '__webspeech__' || !EDGE_VOICE_RE.test(v)) return 'en-US-AriaNeural';
    return v;
}

function generateTts(ffmpegBin, edgeTtsHelper, voice, text, rate, pitch) {
    try {
        const mp3 = tmpFile('mcqvs_tts', '.mp3');
        const r = spawnSync(process.execPath, [
            edgeTtsHelper,
            '--text=' + text,
            '--voice=' + normalizeEdgeVoice(voice),
            '--rate=' + (rate || '+0%'),
            '--pitch=' + (pitch || '+0Hz'),
            '--output=' + mp3,
        ], { stdio: 'pipe', timeout: 90000 });
        if (r.status !== 0 || !fs.existsSync(mp3)) return null;
        const wav = tmpFile('mcqvs_tts', '.wav');
        const c = spawnSync(ffmpegBin, ['-y', '-i', mp3, '-ar', '44100', '-ac', '2', '-c:a', 'pcm_s16le', wav], { stdio: 'pipe' });
        if (c.status !== 0 || !fs.existsSync(wav)) return null;
        return wav;
    } catch (_) {
        return null;
    }
}

/**
 * @NEW 2026-08-11: Batch TTS — synthesize MANY segments in ONE edge-tts-helper node
 *       process, then convert all MP3s to WAV with ONE multi-input ffmpeg invocation.
 *       Replaces the per-segment 2-spawn (node + ffmpeg) with ~2 spawns per whole
 *       video. A 5-question short (~12-20 TTS segments) went from 24-40 process
 *       spawns to 2 — the single biggest render wall-time win for TTS-heavy jobs.
 *
 * @param {string} ffmpegBin
 * @param {string} edgeTtsHelper
 * @param {string} voice
 * @param {string[]} texts        Array of cue texts (in order).
 * @param {string} rate           e.g. '+20%'
 * @param {string} pitch          e.g. '+0Hz'
 * @returns {Promise<(string|null)[]>} WAV path per text (null on per-segment failure).
 */
function generateTtsBatch(ffmpegBin, edgeTtsHelper, voice, texts, rate, pitch) {
    const arr = Array.isArray(texts) ? texts : [];
    if (!arr.length) return [];

    // @FIX 2026-08-11 (SYNC + ORDINAL MAP): this must be SYNCHRONOUS (spawnSync is sync)
    //       so generateAndMeasureTts can consume it directly — a Promise here broke the
    //       caller (no await) and silently fell back to the slow per-segment path.
    //       Also: ffmpeg's -map index is the INPUT ORDINAL (position in `existing`),
    //       NOT the original segment index — if segment 0 fails and segment 1 succeeds,
    //       mp3_1 becomes input 0, so it must be `-map 0:a`. Using the segment index
    //       here made ffmpeg fail on the NEXT segment and DROPPED its TTS from the mix
    //       (the lag/overlap symptom). Both are fixed.
    const mp3s = arr.map(() => tmpFile('mcqvs_tts', '.mp3'));
    const wavs = arr.map(() => tmpFile('mcqvs_tts', '.wav'));

    const r = spawnSync(process.execPath, [
        edgeTtsHelper,
        '--texts=' + JSON.stringify(arr),
        '--outputs=' + JSON.stringify(mp3s),
        '--voice=' + normalizeEdgeVoice(voice),
        '--rate=' + (rate || '+0%'),
        '--pitch=' + (pitch || '+0Hz'),
    ], { stdio: 'pipe', timeout: Math.max(120000, arr.length * 45000) });

    if (r.status !== 0) {
        return arr.map(() => null);
    }

    // Parse batch result to find which mp3s actually got written.
    let wrote = new Set();
    try {
        const out = JSON.parse(r.stdout.toString().trim().split('\n').pop() || '{}');
        if (out && Array.isArray(out.batch)) {
            out.batch.forEach((b) => { if (b && b.success) wrote.add(b.index); });
        }
    } catch (_) { /* fall through — convert any file that exists */ }

    // One ffmpeg invocation: -i mp3_a -i mp3_b ... -map 0:a wav_a -map 1:a wav_b ...
    const ffArgs = ['-y'];
    const existing = []; // original segment indices whose mp3 exist, in input order
    mp3s.forEach((m, i) => {
        if (wrote.has(i) || fs.existsSync(m)) {
            ffArgs.push('-i', m);
            existing.push(i);
        }
    });
    if (!existing.length) return arr.map(() => null);
    // CRITICAL: input ordinal = position in `existing`, not the segment index.
    existing.forEach((segIdx, inputIdx) => {
        ffArgs.push('-map', inputIdx + ':a', '-ar', '44100', '-ac', '2', '-c:a', 'pcm_s16le', wavs[segIdx]);
    });
    const c = spawnSync(ffmpegBin, ffArgs, { stdio: 'pipe', timeout: 120000 });

    return arr.map((_, i) => (fs.existsSync(wavs[i]) ? wavs[i] : null));
}

/**
 * @param {object} opts
 *   ffmpegBin, edgeTtsHelper, assetsJsDir, assetsUrl, width, height,
 *   settings, plan (with scenes, duckWindows, sfxEvents), voiceover config
 * @returns {object} prepared media references for the renderer
 */
function prepareMedia(opts) {
    const out = {
        bgImage: null,
        bgVideoFrames: null,
        bgVideoFrameDur: 33.33,
        logoImage: null,
        musicPath: null,
        voiceovers: [],   // { path, atSec }
        sfx: [],          // { path, atSec, gain }
        duckWindows: [],  // { startSec, endSec, volume }
    };

    const settings = opts.settings || {};
    const plan = opts.plan || { scenes: [], duckWindows: [], sfxEvents: [] };
    // @FIX: Extract ffmpegBin from opts — was referencing bare undefined variable,
    //       causing "ffmpegBin is not defined" when bg_video URL was set.
    const ffmpegBin = opts.ffmpegBin || '';

    // Fonts (register into node-canvas globally).
    prepareFonts(opts.assetsJsDir, settings.templateFonts, settings.fontOverride, settings.templateFontWeights);

    // Background image.
    if (settings.bgImagePath && fs.existsSync(settings.bgImagePath)) {
        out.bgImage = loadImageFile(settings.bgImagePath);
    }

    // Background video frames (bgVideoUrl can be URL or local path).
    // @FIX 2026-07-31: Accept the planner's native `bg_video` key too (some older job
    //       payloads persist it without the normalized bgVideoUrl mapping) and surface a
    //       clear warning instead of silently degrading to the template gradient when the
    //       video could not be downloaded/decoded — the #1 cause of "bg video missing in
    //       rendered video" reports.
    // @FIX: Prefer the PHP-resolved local filesystem path (bgVideoPath) over the
    //       remote URL (bgVideoUrl). bgVideoUrl is ALWAYS populated by
    //       VS_Headless_Renderer::render_job (headless-renderer.php:434) whenever
    //       bg_video is set, so the original `bgVideoUrl || bgVideoPath` order made
    //       bgVideoPath dead code and forced every headless render down the syncHttp
    //       HTTPS download. That download runs outside the browser — no WordPress
    //       auth cookie and Node's default rejectUnauthorized:true — so it silently
    //       failed on self-signed certs, auth-gated, or localhost-bound asset URLs.
    //       Result: the Studio Editor (in-browser <video>) played the background
    //       fine, but the headless Content Pipeline produced a plain gradient.
    //       Reading from disk honours the local-path optimization at
    //       headless-renderer.php:440-450.
    const bgVideoPath = (settings.bgVideoPath && fs.existsSync(settings.bgVideoPath)) ? settings.bgVideoPath : '';
    const bgVideo = bgVideoPath || settings.bgVideoUrl || settings.bg_video || '';
    if (bgVideo && !out.bgImage) {
        // Use totalMs from opts (initial) or plan.totalMs (after rebuild) to extract full-duration frames
        const totalMsForFrames = opts.totalMs || (opts.plan && opts.plan.totalMs);
        const frames = extractBgVideoFrames(ffmpegBin, bgVideo, opts.width, opts.height, out.bgVideoFrameDur, totalMsForFrames);
        if (frames.length) {
            out.bgVideoFrames = frames;
        } else {
            console.warn('[media-prep] bg_video set (' + String(bgVideo).substring(0, 120) + ') but no frames extracted — check ffmpeg, network reachability, and CORS/HTTPS cert. Falling back to gradient.');
        }
    }

    // Logo (supports both local file path and remote URL — same pattern as music).
    const logoSource = settings.logoPath || settings.logoUrl || '';
    if (logoSource) {
        if (/^https?:\/\//i.test(logoSource)) {
            try {
                const tmp = tmpFile('mcqvs_logo', '.png');
                const buf = syncHttp(logoSource);
                if (buf && buf.length) {
                    fs.writeFileSync(tmp, buf);
                    out.logoImage = loadImageFile(tmp);
                    const log = (typeof global !== 'undefined' && global.__MCQVS_RENDER_LOG) || console.log;
                    log('[media-prep] Logo downloaded: ' + logoSource + ' -> ' + tmp + ' (' + (out.logoImage ? out.logoImage.width + 'x' + out.logoImage.height : 'failed') + ')');
                } else {
                    const log = (typeof global !== 'undefined' && global.__MCQVS_RENDER_LOG) || console.warn;
                    log('[media-prep] Logo download failed (empty response): ' + logoSource);
                }
            } catch (e) {
                const log = (typeof global !== 'undefined' && global.__MCQVS_RENDER_LOG) || console.warn;
                log('[media-prep] Logo download error: ' + logoSource + ' — ' + e.message);
            }
        } else if (fs.existsSync(logoSource)) {
            out.logoImage = loadImageFile(logoSource);
            const log = (typeof global !== 'undefined' && global.__MCQVS_RENDER_LOG) || console.log;
            log('[media-prep] Logo loaded from local: ' + logoSource + ' (' + (out.logoImage ? out.logoImage.width + 'x' + out.logoImage.height : 'failed') + ')');
        } else {
            const log = (typeof global !== 'undefined' && global.__MCQVS_RENDER_LOG) || console.warn;
            log('[media-prep] Logo source not found: ' + logoSource);
        }
    }

    // Music (bgMusicUrl can be URL or local path; bgMusicPath is local-only alias).
    // @FIX: Prefer the PHP-resolved local bgMusicPath over bgMusicUrl, mirroring the
    //       bg_video fix. bgMusicUrl is always populated by VS_Headless_Renderer, so
    //       the original order made bgMusicPath dead code and forced syncHttp downloads
    //       that fail on self-signed certs / auth-gated / localhost URLs — silently
    //       dropping background music from headless renders while the browser played it.
    const musicPath = (settings.bgMusicPath && fs.existsSync(settings.bgMusicPath)) ? settings.bgMusicPath : '';
    const musicUrl = musicPath || settings.bgMusicUrl || '';
    if (musicUrl) {
        if (/^https?:\/\//i.test(musicUrl)) {
            const ext = path.extname(new URL(musicUrl, 'http://x').pathname) || '.mp3';
            const tmp = tmpFile('mcqvs_music', ext);
            try { fs.writeFileSync(tmp, syncHttp(musicUrl)); out.musicPath = tmp; } catch (_) {}
        } else if (fs.existsSync(musicUrl)) {
            out.musicPath = musicUrl;
        }
    }

    // Duck windows (from plan, in seconds).
    (plan.duckWindows || []).forEach((w) => {
        out.duckWindows.push({
            startSec: Math.max(0, Number(w.startMs || 0) / 1000),
            endSec: Math.max(0, Number(w.endMs || 0) / 1000),
            volume: Number(w.volume != null ? w.volume : 0.14),
        });
    });

    // SFX (time-locked to plan.sfxEvents).
    out.sfx = buildSfxEvents(plan, opts);

    return out;
}

/**
 * Resolve plan.sfxEvents to concrete audio files (local path, remote URL, or
 * assetsJsDir/audio/sfx/<name>.mp3), time-locked to each event's atMs.
 * Exported so render-node.js can re-derive media.sfx AFTER
 * rebuildPlanWithAdaptiveTiming realigns plan.sfxEvents to the new
 * TTS-anchored cue times (prepareMedia runs BEFORE the rebuild, so the
 * original media.sfx entries are locked to pre-adaptive absolute times).
 */
function buildSfxEvents(plan, opts) {
    const out = [];
    const sfxDir = path.join(opts.assetsJsDir, 'audio', 'sfx');
    (plan.sfxEvents || []).forEach((ev) => {
        const atMs = Number(ev.atMs || 0);
        const gain = Number(ev.gain != null ? ev.gain : 1);
        let file = null;
        if (ev.path && fs.existsSync(ev.path)) file = ev.path;
        else if (/^https?:\/\//i.test(ev.name || '')) file = ev.name;
        else if (ev.name) {
            const cand = path.join(sfxDir, String(ev.name).replace(/\.mp3$/i, '') + '.mp3');
            file = fs.existsSync(cand) ? cand : null;
        }
        if (!file && /^https?:\/\//i.test(ev.name || '')) {
            try { const t = tmpFile('mcqvs_sfx', '.mp3'); fs.writeFileSync(t, syncHttp(ev.name)); file = t; } catch (_) {}
        }
        if (file) out.push({ path: file, atSec: Math.max(0, atMs / 1000), gain });
    });
    return out;
}

module.exports = { prepareMedia, buildSfxEvents, generateTts, generateTtsBatch, extractBgVideoFrames, prepareFonts };
