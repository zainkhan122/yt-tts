<?php

namespace SEO_Article_Generator\AI;

use SEO_Article_Generator\Logger;
use SEO_Article_Generator\Option_Registry;

if (! defined('ABSPATH')) {
	exit;
}

/**
 * OpenCode Zen Free Model Auto-Sync
 *
 * Sibling of OpenRouter_Model_Sync. Targets the OpenCode Zen custom provider
 * (api_url host = opencode.ai) and replaces its `models` array entirely with
 * the hard-coded FREE_MODEL_IDS whitelist — the strategy mandated by the
 * OpenRouter+Zen universal sync plan.
 *
 * Strategy differences vs OpenRouter_Model_Sync:
 *  - Whitelist filter (not pricing/modality filter) — Zen publishes non-free
 *    models alongside free ones; we strictly allow-list the six known-free IDs.
 *  - Full REPLACE of the matching provider's `models` array (no diff, no
 *    order preservation). Manually-added Zen models are wiped on sync, per
 *    the documented Zen behavior.
 *  - No expiration check (Zen API does not publish an expiration_date slot).
 *
 * Failure safety (parity with OpenRouter sync):
 *  - Any HTTP / parse / empty-result failure aborts WITHOUT touching the
 *    stored model list (no silent wipe).
 *  - Blank provider protection: if the whitelist yields zero entries, abort.
 *
 * Wires into the same infrastructure used by OpenRouter_Model_Sync:
 *  - Option_Registry::ZEN_LAST_SYNC for last-sync stamp
 *  - Option_Registry::LOG_ACTION_ZEN_SYNC for log context
 *  - AS_Registry::HOOK_SYNC_ZEN for the recurring scheduler hook
 *  - Provider_Registry::is_zen_url() for provider detection
 *  - Provider_Registry::save_custom_providers() for direct order-preserving
 *    storage (validate_custom_profile runs on all profiles).
 *
 * @since 2.30.x
 */
class OpenCode_Zen_Model_Sync {

	const API_URL = 'https://opencode.ai/zen/v1/models';

	/**
	 * Hard-coded whitelist of known free Zen model IDs.
	 * Synchronized with the marketing pricing-table "Free" mark; these IDs
	 * are the only ones passed through from the Zen /v1/models catalog.
	 *
	 * If opencode.ai publishes new free models, they will NOT appear until
	 * this whitelist is updated — see plan §6 "OpenCode Zen whitelist stale".
	 *
	 * @var string[]
	 */
	private static $FREE_MODEL_IDS = array(
		'big-pickle',
		'deepseek-v4-flash-free',
		'mimo-v2.5-free',
		'north-mini-code-free',
		'nemotron-3-ultra-free',
		'hy3-free',
	);

	/**
	 * Run the Zen model sync.
	 *
	 * Full-replace strategy: the matching Zen provider's `models` array is
	 * rebuilt from the whitelist, then saved via the standard
	 * Provider_Registry::save_custom_providers() pipeline.
	 *
	 * @return array{ success: bool, message: string, added: int, removed: int, total: int }
	 */
	public static function sync(): array {
		$registry = Provider_Registry::get_instance();
		$providers = $registry->get_custom_providers();

		$zen_index = self::find_zen_index($providers);
		if ($zen_index < 0) {
			return self::result(false, 'No OpenCode Zen custom provider found (URL must contain opencode.ai).');
		}

		$free_models = self::fetch_free_models();
		if (null === $free_models) {
			return self::result(false, 'OpenCode Zen API request failed; existing models left unchanged.');
		}
		if (empty($free_models)) {
			return self::result(false, 'OpenCode Zen API returned no whitelisted models; existing models left unchanged.');
		}

		// Step 4: REPLACE the matching provider's models array (full-replace
		// strategy). Manually-added Zen models are wiped here by design.
		$providers[$zen_index]['models'] = $free_models;

		if (empty($providers[$zen_index]['models'])) {
			return self::result(false, 'Sync would remove all models; aborting to preserve existing provider.');
		}

		// Step 5+6: validate ALL providers and save directly.
		$registry->save_custom_providers($providers);

		self::update_last_sync();

		$logger = self::logger();
		if ($logger) {
			$logger->info(
				sprintf(
					'[OpenCode Zen Sync] Replaced model list: %d models.',
					count($free_models)
				),
				array(
					'action'    => Option_Registry::LOG_ACTION_ZEN_SYNC,
					'model_ids' => wp_list_pluck($free_models, 'model_id'),
				)
			);
		}

		$message = sprintf(
			'Sync complete: %d Zen model(s) installed.',
			count($free_models)
		);

		// added/removed counts are reported as 0 / total because the strategy
		// is full-replace, not additive — matches the OpenRouter result shape
		// for UI/AJAX consistency (front-end only reads $result['message']).
		return self::result(true, $message, 0, 0, count($free_models));
	}

	/**
	 * Fetch the whitelist-filtered Zen model list.
	 *
	 * @return array<int,array{model_id:string,display_name:string}>|null
	 *         Null on transport/parse failure.
	 */
	private static function fetch_free_models(): ?array {
		$response = wp_remote_get(
			self::API_URL,
			array(
				'timeout'    => 30,
				'headers'    => array('Accept' => 'application/json'),
				'user-agent' => 'SEO-Article-Generator/' . (defined('SEO_GEN_VERSION') ? SEO_GEN_VERSION : '1.0'),
			)
		);

		if (is_wp_error($response)) {
			$logger = self::logger();
			if ($logger) {
				$logger->warning('OpenCode Zen sync fetch failed: ' . $response->get_error_message());
			}
			return null;
		}

		$code = (int) wp_remote_retrieve_response_code($response);
		if ($code < 200 || $code >= 300) {
			$logger = self::logger();
			if ($logger) {
				$logger->warning('OpenCode Zen sync fetch HTTP error: ' . $code);
			}
			return null;
		}

		$body = wp_remote_retrieve_body($response);
		$data = json_decode($body, true);
		if (! is_array($data) || ! isset($data['data']) || ! is_array($data['data']) || empty($data['data'])) {
			$logger = self::logger();
			if ($logger) {
				$logger->warning('OpenCode Zen sync: malformed or empty API response.');
			}
			return null;
		}

		$filtered = array();
		foreach ($data['data'] as $model) {
			if (! is_array($model)) {
				continue;
			}
			$id = isset($model['id']) ? (string) $model['id'] : '';
			if ('' === $id) {
				continue;
			}
			// Strict whitelist filter — skip anything not in $FREE_MODEL_IDS.
			if (! in_array($id, self::$FREE_MODEL_IDS, true)) {
				continue;
			}
			$filtered[] = array(
				'model_id'     => $id,
				'display_name' => self::model_id_to_display($id),
			);
		}

		return $filtered;
	}

	/**
	 * Derive a human-readable display name from a Zen model id.
	 *
	 * Examples:
	 *   deepseek-v4-flash-free -> Deepseek V4 Flash (Free)
	 *   big-pickle             -> Big Pickle
	 *   hy3-free               -> Hy3 (Free)
	 *
	 * @param string $id Raw model id from the Zen API.
	 * @return string Display name.
	 */
	private static function model_id_to_display(string $id): string {
		$display = $id;
		// Strip the trailing '-free' suffix when present; it will be re-added as ' (Free)'.
		$is_free_suffix = substr($id, -strlen('-free')) === '-free';
		if ('' !== $is_free_suffix && strlen($id) > strlen('-free')) {
			$display = substr($id, 0, -strlen('-free'));
		}
		// Replace hyphens / underscores with spaces, capitalize words.
		$display = str_replace(array('-', '_'), ' ', $display);
		$display = ucwords($display);
		if ($is_free_suffix) {
			$display .= ' (Free)';
		}
		return $display;
	}

	/**
	 * Locate the first Zen-compatible custom provider index.
	 *
	 * @param array $providers
	 * @return int Negative when none found.
	 */
	private static function find_zen_index(array $providers): int {
		$registry = Provider_Registry::get_instance();
		foreach ($providers as $i => $profile) {
			$url = (string) ($profile['api_url'] ?? '');
			if ($registry->is_zen_url($url)) {
				return (int) $i;
			}
		}
		return -1;
	}

	/**
	 * Whether an OpenCode Zen custom provider exists.
	 *
	 * @return bool
	 */
	public static function has_zen_provider(): bool {
		return self::find_zen_index(Provider_Registry::get_instance()->get_custom_providers()) >= 0;
	}

	/**
	 * Get the last successful sync timestamp.
	 *
	 * @return int Unix timestamp (0 = never).
	 */
	public static function get_last_sync_time(): int {
		return (int) get_option(Option_Registry::ZEN_LAST_SYNC, 0);
	}

	/**
	 * Update the last-sync timestamp.
	 */
	private static function update_last_sync(): void {
		update_option(Option_Registry::ZEN_LAST_SYNC, time(), false);
	}

	/**
	 * Build a standardized result array (mirrors OpenRouter_Model_Sync::result).
	 *
	 * @param bool   $success
	 * @param string $message
	 * @param int    $added
	 * @param int    $removed
	 * @param int    $total
	 * @return array{success:bool,message:string,added:int,removed:int,total:int}
	 */
	private static function result(bool $success, string $message, int $added = 0, int $removed = 0, int $total = 0): array {
		return array(
			'success' => $success,
			'message' => $message,
			'added'   => $added,
			'removed' => $removed,
			'total'   => $total,
		);
	}

	/**
	 * Best-effort logger resolution (mirrors OpenRouter_Model_Sync::logger).
	 *
	 * @return Logger|null
	 */
	private static function logger(): ?Logger {
		if (class_exists('\SEO_Article_Generator\Logger')) {
			return new Logger();
		}
		return null;
	}
}
