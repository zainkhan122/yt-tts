<?php

/**
 * Hero Data Provider
 *
 * Derives hero section data from Article_Schema with optional presentation overrides.
 * Enforces Single Source of Truth pattern.
 *
 * @MODIFIED 2025-12-11 v1.8.0: New class for data synchronization architecture
 * @MODIFIED 2026-05-21: CRITICAL FIX - Added input validation and error handling
 * @package SEO_Article_Generator
 */

namespace SEO_Article_Generator\Generator;

use SEO_Article_Generator\Traits\Type_Safety;

// Prevent direct access.
if (! defined('ABSPATH')) {
	exit;
}

use SEO_Article_Generator\Schema\Safety_Data;

/**
 * Hero Data Provider Class
 * 
 * Provides hero section data with validation and error handling.
 */
class Hero_Data_Provider {
    use Type_Safety;

    /**
     * Fields that can be manually overridden via the Hero Meta Box.
     * These override schema-derived values when explicitly set by the user.
     */
    const ALLOWED_OVERRIDES = array(
        'software_name',
        'version',
        'license',
        'license_details',
        'file_size',
        'rating',
        'security_badge',
        'logo_url',
        'publisher',
        'category',
        'author_name',
        'last_updated',
        'last_verified_date',
        // @MODIFIED 2026-05-23: Allow download_links to be overridden from manual edits.
        // These are persisted separately in _seo_gen_hero_download_links and merged
        // into overrides by save_schema() before calling from_schema().
        'download_links',
    );

    /**
     * Generate hero section data from Article_Schema.
     *
     * @param Article_Schema $schema
     * @param array|null $overrides Manual overrides from admin UI.
     * @param int $post_id
     * @return array Hero section data.
     */
    public static function from_schema(Article_Schema $schema, ?array $overrides = null, int $post_id = 0): array
	{
		// CRITICAL FIX: Validate input schema before processing
		if (!$schema instanceof Article_Schema) {
			throw new \InvalidArgumentException('Schema must be an instance of Article_Schema');
		}
		
		$tech   = $schema->tech_specs;
		$safety = $schema->safety;
		$overrides = is_array($overrides) ? $overrides : [];
		
		// CRITICAL FIX: Validate required fields exist
		if (empty($tech->software_name) && empty($schema->title)) {
			throw new \RuntimeException('Hero section requires either tech_specs.software_name or title');
		}

		$rating_data = [
			'sum'     => 0,
			'count'   => 0,
			'average' => 0,
		];
		if ($post_id > 0 && \class_exists('SEO_Article_Generator\\Frontend\\Rating_System')) {
			$rating_data = \SEO_Article_Generator\Frontend\Rating_System::get_rating_data($post_id);
		}

		$hero_data = [
			'software_name'        => $tech->software_name ?: $schema->title,
			'version'              => $schema->get_canonical_version(),
			'license'              => $tech->license ?: 'Free',
			'license_details'      => self::normalize_license_details($tech->license ?: ''),
			'file_size'            => $tech->file_size,
		'rating' => $schema->editor_rating > 0 ? $schema->editor_rating : ($rating_data['average'] > 0 ? $rating_data['average'] : 0),
			'rating_count'         => $rating_data['count'],
			'security_badge'       => self::default_security_badge($safety),
			'download_links'       => [],
			'min_os'               => self::derive_min_os($schema),
			'architecture'         => self::derive_architecture($tech),
			// [SSOT-FIX Finding 6] Use WP-timezone dates so Hero Meta Box matches what
			// the user sees on the front-end (WP Settings → General → Timezone).
			// Version_SSOT::enforce() still uses \date() server-local for tech_specs.last_updated
			// but hero_data is consumed via renderers that read WP-timezone — so both must
			// converge. We use wp_date() here for user-facing display consistency.
			'last_updated'         => function_exists( '\wp_date' ) ? \wp_date( 'F j, Y' ) : gmdate( 'F j, Y' ),
			'logo_url'             => '',
			'publisher'            => self::derive_publisher($tech),
		'category' => self::extract_first_category($schema->category ?: ($tech->application_category ?: self::fallback_category_from_post($post_id))),
		'application_category' => self::normalize_application_category_value(
			($schema->category ?: ($tech->application_category ?: self::fallback_category_from_post($post_id)))
		),
		'all_categories' => $schema->category ?: ($tech->application_category ?: self::fallback_category_from_post($post_id)),
			'author_name'          => self::derive_author_name($post_id),
			'last_verified_date'   => gmdate( 'Y-m-d' ),
			'description'          => '',
		];

		if (! empty($schema->download_section['links']) && is_array($schema->download_section['links'])) {
			// @MODIFIED 2026-06-30: Use normalize_links() for consistent normalization
			// with the Download Zone. Previously used a lightweight loop that allowed
			// invalid/placeholder links through, causing hero meta box to show more
			// links than the Download Zone rendered.
			$homepage = trim((string) ($schema->tech_specs->homepage ?? ''));
			$sw_name = trim((string) ($schema->tech_specs->software_name ?? $schema->title ?? ''));
			$changelog = trim((string) ($schema->tech_specs->changelogurl ?? ''));
			$normalized = \SEO_Article_Generator\Generator\Download_Link_Helper::normalize_links(
				$schema->download_section['links'],
				'Windows',
				$homepage,
				$sw_name,
				$changelog
			);
			// [SSOT-FIX Finding 7] Defer primary-link assignment to enforce_single_primary()
			// so Hero_Meta_Box UI, Download Zone, and Rank_Math_Schema all use the same
			// selection rule (smart_windows_default=true: prefer Windows x64, fallback
			// to first link). Previously, Hero_Data_Provider used a hand-rolled primary
			// loop that produced a different "primary" than the Download Zone on
			// variants where the canonical link lacked an is_primary flag.
			$normalized = \SEO_Article_Generator\Publishing\Publish_Payload_Builder::enforce_single_primary( $normalized, true );

			foreach ($normalized as $index => $link) {
				// @MODIFIED 2026-06-30: Ensure platform is never empty before the filter
				// This prevents valid links from being dropped when platform inference fails
				if (empty($link['platform'])) {
					$inferred = \SEO_Article_Generator\Generator\Download_Link_Helper::infer_platform_from_url($link['url'] ?? '');
					if (!empty($inferred)) {
						$link['platform'] = $inferred;
					} else {
						$link['platform'] = 'Windows';
					}
				}
				if (empty($link['url'])) continue;

			$hero_data['download_links'][] = [
				'platform' => (string) $link['platform'],
				'url' => (string) $link['url'],
				'variant' => \SEO_Article_Generator\Generator\Download_Link_Helper::normalize_variant_name(
					isset($link['variant']) ? (string) $link['variant'] : ''
				),
				'file_type' => isset($link['file_type']) ? (string) $link['file_type'] : '',
				'version' => isset($link['version']) ? (string) $link['version'] : '',
				'channel' => isset($link['channel']) ? (string) $link['channel'] : '',
				'text' => isset($link['text']) ? (string) $link['text'] : '',
				'is_primary' => ! empty( $link['is_primary'] ),
			];
			}
		}

		if (! empty($overrides)) {
			foreach (self::ALLOWED_OVERRIDES as $field) {
				if (isset($overrides[$field]) && $overrides[$field] !== '' && $overrides[$field] !== null && $overrides[$field] !== []) {
					$hero_data[$field] = $overrides[$field];
				}
			}
		}

		return self::normalize_for_storage($hero_data, $post_id);
	}

	/**
	 * Normalization layer to ensure the data is "schema-ready".
	 */
	private static function normalize_for_storage(array $hero_data, int $post_id = 0): array
	{
		$hero_data['software_name'] = self::as_string($hero_data['software_name'] ?? '');
		$hero_data['name']          = $hero_data['software_name'];

		$hero_data['description'] = self::derive_description_internal($hero_data, $post_id);

		$hero_data['version']          = self::as_string($hero_data['version'] ?? '');
		$hero_data['software_version'] = $hero_data['version'];

		$hero_data['publisher'] = self::as_string($hero_data['publisher'] ?? '');
		$hero_data['developer'] = $hero_data['publisher'];

	$hero_data['category'] = self::as_string($hero_data['category'] ?? '');
	$hero_data['application_category'] = self::normalize_application_category_value(
		($hero_data['application_category'] ?: $hero_data['category']) ?: ''
	);
	$enum_to_display = array(
		'GameApplication' => 'Games',
		'UtilitiesApplication' => 'Utilities',
		'BusinessApplication' => 'Business',
		'DesignApplication' => 'Design',
		'SecurityApplication' => 'Security',
		'MultimediaApplication' => 'Multimedia',
		'BrowserApplication' => 'Browser',
		'SocialNetworkingApplication' => 'Communication',
		'DeveloperApplication' => 'Developer Tools',
		'EducationalApplication' => 'Education',
	);
	$ac = $hero_data['application_category'];
	if (isset($enum_to_display[$ac]) && ($hero_data['category'] === '' || $hero_data['category'] === $ac)) {
		$hero_data['category'] = $enum_to_display[$ac];
	}

		$hero_data['min_os']           = self::as_string($hero_data['min_os'] ?? '');
		$hero_data['operating_system'] = self::normalize_operating_system_value(
			(string) ($hero_data['operating_system'] ?? $hero_data['min_os'] ?? ''),
			(array) ($hero_data['download_links'] ?? []),
			(string) ($tech->os_support ?? '')
		);
		$hero_data['os_support']       = $hero_data['operating_system'];

		$hero_data['download_links'] = self::normalize_links_internal((array) ($hero_data['download_links'] ?? []));
		$primary_url                 = self::extract_primary_url($hero_data['download_links']);
		
		$hero_data['download_url'] = (string)($hero_data['download_url'] ?? $primary_url);
		$hero_data['downloadUrl']  = $hero_data['download_url'];

		$hero_data['rating']       = (float)($hero_data['rating'] ?? 0);
		$hero_data['rating_count'] = (int)($hero_data['rating_count'] ?? 0);
		$hero_data['review_count'] = $hero_data['rating_count'];

		$hero_data['file_size']   = self::as_string($hero_data['file_size'] ?? '');
		$hero_data['fileSize']    = $hero_data['file_size'];
		
		$logo = self::resolve_logo_url_internal($hero_data, $post_id);
		$hero_data['logo_url']      = $logo;
		$hero_data['software_logo'] = $logo;
		$hero_data['image']         = $logo;

		$hero_data['tech_specs'] = array_filter([
			'operating_system'     => $hero_data['operating_system'],
			'os_support'           => $hero_data['os_support'],
			'version'              => $hero_data['version'],
			'software_version'     => $hero_data['software_version'],
			'application_category' => $hero_data['application_category'],
			'download_url'         => $hero_data['download_url'],
			'downloadUrl'          => $hero_data['downloadUrl'],
			'file_size'            => $hero_data['file_size'],
			'fileSize'             => $hero_data['fileSize'],
			'software_logo'        => $hero_data['logo_url'],
		]);

		return array_filter($hero_data, function($val) {
			return $val !== null;
		});
	}

	private static function derive_description_internal(array $hero_data, int $post_id): string
	{
		if (! empty($hero_data['description'])) return self::as_string($hero_data['description']);
		if ($post_id > 0) {
			$post = \get_post($post_id);
			if ($post && ! empty($post->post_excerpt)) return trim(\wp_strip_all_tags((string)$post->post_excerpt));
			if ($post && ! empty($post->post_content)) return trim(\wp_strip_all_tags(\wp_trim_words((string)$post->post_content, 30, '...')));
		}
		return '';
	}

	private static function normalize_links_internal(array $links): array
	{
		$out = [];
		foreach ($links as $link) {
			if (empty($link['url'])) continue;
			$out[] = [
				'platform' => self::as_string($link['platform'] ?? ''),
				'url' => (string)$link['url'],
				'variant' => self::as_string($link['variant'] ?? ''),
				'file_type' => self::as_string($link['file_type'] ?? ''),
				'version' => self::as_string($link['version'] ?? ''),
				'channel' => self::as_string($link['channel'] ?? ''),
				'text' => self::as_string($link['text'] ?? ''),
				'is_primary' => ! empty($link['is_primary']),
			];
		}
		return $out;
	}

	private static function extract_primary_url(array $links): string
	{
		foreach ($links as $link) if (! empty($link['is_primary'])) return (string)$link['url'];
		if (! empty($links)) return (string)$links[0]['url'];
		return '';
	}

	private static function resolve_logo_url_internal(array $hero_data, int $post_id): string
	{
if ($post_id > 0 && \has_post_thumbnail($post_id)) return (string)\get_the_post_thumbnail_url($post_id, 'full');
    if (! empty($hero_data['logo_url'])) return (string)$hero_data['logo_url'];
		return '';
	}

	private static function normalize_operating_system_value(string $value, array $links, string $os_support = ''): string
	{
		if ($value !== '') return $value;
		$platforms = [];
		foreach ($links as $link) {
			$p = strtolower($link['platform']);
			if (strpos($p, 'win') !== false) $platforms['Windows'] = 'Windows';
			if (strpos($p, 'mac') !== false) $platforms['macOS'] = 'macOS';
			if (strpos($p, 'android') !== false) $platforms['Android'] = 'Android';
			if (strpos($p, 'ios') !== false) $platforms['iOS'] = 'iOS';
		}
		if (!empty($platforms)) return implode(', ', $platforms);
		// @MODIFIED: Derive from tech_specs.os_support text when no links/platforms exist.
		return self::derive_short_os_list($os_support);
	}

	/**
	 * Build a deterministic, SSOT-driven meta description.
	 *
	 * Uses the canonical tech_specs values (software_name, license, os_support)
	 * so the snippet always matches the Hero and post body. Version and file_size
	 * are EXCLUDED (SERP churn / build-tag noise). Returns '' when the SSOT lacks
	 * the software_name (caller keeps AI text).
	 *
	 * @param array $article Article_Schema to_array() payload.
	 * @return string
	 */
	public static function build_ssot_meta_description( array $article ): string {
		$ts      = isset( $article['tech_specs'] ) && is_array( $article['tech_specs'] ) ? $article['tech_specs'] : array();
		$name    = trim( (string) ( $ts['software_name'] ?? ( $article['title'] ?? '' ) ) );
		$version = trim( (string) ( $ts['version'] ?? '' ) );
		$size    = trim( (string) ( $ts['file_size'] ?? '' ) );
		$license = trim( (string) ( $ts['license'] ?? '' ) );

		// [META-NO-VERSION] Version no longer belongs in meta_description (SERP churn,
		// build-tag noise, length bloat).
		// [META-NO-SIZE] File size no longer belongs in meta_description (SERP churn / noise).
		// Require name as the sole determinant.
		if ( $name === '' ) {
			return '';
		}

		$os_list = self::derive_short_os_list( (string) ( $ts['os_support'] ?? '' ) );

		$head = 'Download ' . $name;
		$head .= ' for ' . ( $os_list !== '' ? $os_list : 'Windows' ) . '.';

		$parts = array( $head );
		if ( $license !== '' ) {
			$parts[] = ucfirst( $license ) . '.';
		}
		// [META-NO-SIZE] File size excluded from meta_description (SERP churn / noise).
		$parts[] = 'Verified ' . ( function_exists( '\\wp_date' ) ? \wp_date( 'M Y' ) : date( 'M Y' ) ) . '.';

		$meta = implode( ' ', $parts );

		if ( mb_strlen( $meta ) > 158 ) {
			$_cut = mb_substr( $meta, 0, 158 );
			$_sp  = mb_strrpos( $_cut, ' ' );
			$meta = ( $_sp !== false && $_sp > 40 ) ? mb_substr( $meta, 0, $_sp ) : $_cut;
			$meta = rtrim( $meta, ' .' ) . '.';
		}

		return $meta;
	}

	/**
	 * Keep the AI-authored meta wording (natural), but force the file size to
	 * match the canonical tech_specs (source of truth). Version is NEVER injected
	 * into meta_description (SERP churn / build-tag noise). Falls back to the
	 * rigid template (build_ssot_meta_description) only when the AI meta is empty.
	 */
	public static function repair_meta_to_spec( string $meta, array $article ): string {
		$ts      = isset( $article['tech_specs'] ) && is_array( $article['tech_specs'] ) ? $article['tech_specs'] : array();
		$name    = trim( (string) ( $ts['software_name'] ?? ( $article['title'] ?? '' ) ) );
		$version = trim( (string) ( $ts['version'] ?? '' ) );
		$size    = trim( (string) ( $ts['file_size'] ?? '' ) );

		$meta = trim( $meta );
		if ( $meta === '' ) {
			return self::strip_meta_boilerplate( self::build_ssot_meta_description( $article ) );
		}

		// [META-NO-VERSION] Strip ALL version formats from meta_description entirely
		// (SERP churn / build-tag noise). Matches 2+ dotted segments so 2-segment
		// versions like "v26.1", "26.1", "15.2" are caught (previously missed by
		// the 3+ segment regex). Strip is unconditional so the intro-derived fallback
		// in Discovery_Processor::auto_finalize() is safe even when tech_specs.version
		// is empty.
		$vt = '/\b\d+\.\d+(?:\.\d+)?(?:\.\d+)?(?:\s*Build\s*\d+)?\b/i';
		$meta = preg_replace( $vt, '', $meta );
		// Also strip prefixed versions like "v1.2", "v1.2.3", "version 1.2.3", "ver 1.2.3"
		$meta = preg_replace( '/\b(?:v|version|ver)\s*\d+\.\d+(?:\.\d+)?(?:\.\d+)?\b/i', '', $meta );
		// Strip versions with dashes/suffixes (e.g. "1.2.3-beta", "1.2.3-rc1", "1.2.3-alpha")
		$meta = preg_replace( '/\b\d+\.\d+(?:\.\d+)?(?:-[a-z0-9]+)?\b/i', '', $meta );
		// Strip prefixed versions with dashes (e.g. "v1.2.3-beta", "version 1.2.3-rc1")
		$meta = preg_replace( '/\b(?:v|version|ver)\s*\d+\.\d+(?:\.\d+)?(?:-[a-z0-9]+)?\b/i', '', $meta );

		// [META-NO-SIZE] Strip file sizes from meta_description (e.g. "46.6 MB", "26 MB").
		// User explicitly does not want version OR file size in meta_description.
		$meta = preg_replace( '/\b\d+(?:\.\d+)?\s*(?:MB|GB|KB|kB|TB|bytes?)\b/i', '', $meta );
		// Also strip sizes without space (e.g. "90MB", "1.5GB")
		$meta = preg_replace( '/\b\d+(?:\.\d+)?(?:MB|GB|KB|kB|TB)\b/i', '', $meta );

		$meta = preg_replace( '/\s+/', ' ', $meta );
		$meta = trim( $meta, ' ,.;:' );

		// [META-NO-VERSION] Do not re-inject canonical version into meta_description.
		// [META-NO-SIZE] Do not re-inject file size into meta_description.
		// Version + Size SSOT remain enforced on tech_specs / hero_badge / download_section
		// by Publish_Payload_Builder::enforce_version_ssot() and Hero_Data_Provider::build().

		// Strip robotic boilerplate tails (e.g. "Official download, features, and FAQ").
		$meta = self::strip_meta_boilerplate( $meta );

		// Cap at 160 chars, trimming at a word boundary (version/size are preserved).
		$max = 160;
		if ( mb_strlen( $meta ) > $max ) {
			$meta = mb_substr( $meta, 0, $max - 1 );
			$meta = preg_replace( '/\s+\S*$/u', '', $meta );
			$meta = rtrim( $meta, ' ,;:. ' ) . '…';
		}

		return $meta;
	}

	/**
	 * Remove robotic boilerplate tails the AI (or the template fallback) may append,
	 * e.g. "Official download, features, and FAQ." / "Safe download, features,
	 * requirements and FAQ." / "Official installer, features, system requirements, and FAQ."
	 */
	private static function strip_meta_boilerplate( string $meta ): string {
		$meta = preg_replace(
			'/\s*,?\s*(?:(?:official|safe)\s+(?:download|installer)[^.]*?|features,?\s*(?:requirements,\s*)?(?:and\s*)?)faq\.?\s*$/ix',
			'',
			$meta
		);

		return rtrim( $meta );
	}

	/**
	 * Derive a short, comma-separated OS label list from a free-text os_support string.
	 *
	 * @param string $os_support e.g. "Windows 11, 10; macOS 12+; Linux".
	 * @return string e.g. "Windows, macOS, Linux" or ''.
	 */
	private static function derive_short_os_list( string $os_support ): string {
		if ( $os_support === '' ) {
			return '';
		}
		$map = array(
			'windows' => 'Windows',
			'mac'     => 'macOS',
			'apple'   => 'macOS',
			'osx'     => 'macOS',
			'linux'   => 'Linux',
			'android' => 'Android',
			'ios'     => 'iOS',
		);
		$found = array();
		$low   = strtolower( $os_support );
		foreach ( $map as $k => $label ) {
			if ( strpos( $low, $k ) !== false && ! in_array( $label, $found, true ) ) {
				$found[] = $label;
			}
		}
		return implode( ', ', $found );
	}

	public static function normalize_application_category_value(string $value): string
	{
		if ($value === '') return '';
		
		$parts = explode(',', $value);
		$platforms = ['windows', 'macos', 'android', 'ios', 'linux', 'mac'];
		$first_valid = '';
		
		foreach ($parts as $part) {
			$clean = trim($part);
			if ($clean === '' || in_array(strtolower($clean), $platforms)) continue;
			$first_valid = $clean;
			break;
		}
		
		if ($first_valid === '') {
			return 'UtilitiesApplication'; // Fallback
		}

		$map = [
			// Existing curated keywords
			'game'          => 'GameApplication',
			'utility'       => 'UtilitiesApplication',
			'utilities'     => 'UtilitiesApplication',
			'business'      => 'BusinessApplication',
			'design'        => 'DesignApplication',
			'security'      => 'SecurityApplication',
			'multimedia'    => 'MultimediaApplication',
			'video'         => 'MultimediaApplication',
			'audio'         => 'MultimediaApplication',
			'browser'       => 'BrowserApplication',
			'communication' => 'CommunicationApplication',
			'developer'     => 'DeveloperApplication',
			'education'     => 'EducationalApplication',
			'download'      => 'DownloadApplication',
			'ftp'           => 'DownloadApplication',
			'file'          => 'DownloadApplication',
			'productivity'  => 'ProductivityApplication',
			'shopping'      => 'ShoppingApplication',
			'health'        => 'HealthApplication',
			'finance'       => 'FinanceApplication',
			'entertainment' => 'EntertainmentApplication',
			'travel'        => 'TravelApplication',
			'lifestyle'     => 'LifestyleApplication',

			// Extended coverage for the site's actual software category vocabulary
			// (derived from the plugin's $category_map + get_categories() taxonomy)
			'tool'          => 'UtilitiesApplication',
			'tools'         => 'UtilitiesApplication',
			'graphic'       => 'DesignApplication',
			'cad'           => 'DesignApplication',
			'privacy'       => 'SecurityApplication',
			'vpn'           => 'SecurityApplication',
			'ids'           => 'SecurityApplication',
			'media'         => 'MultimediaApplication',
			'recorder'      => 'MultimediaApplication',
			'screen'        => 'MultimediaApplication',
			'code'          => 'DeveloperApplication',
			'editor'        => 'DeveloperApplication',
			'cms'           => 'DeveloperApplication',
			'office'        => 'ProductivityApplication',
			'cloud'         => 'BusinessApplication',
			'sync'          => 'BusinessApplication',
			'pdf'           => 'BusinessApplication',
			'backup'        => 'UtilitiesApplication',
			'recovery'      => 'UtilitiesApplication',
			'driver'        => 'UtilitiesApplication',
			'custom'        => 'UtilitiesApplication',
			'optim'         => 'UtilitiesApplication',
			'internet'      => 'UtilitiesApplication',
			'remote'        => 'UtilitiesApplication',
			'uninstall'     => 'UtilitiesApplication',
			'usb'           => 'UtilitiesApplication',
			'archive'       => 'UtilitiesApplication',
			'cd'            => 'UtilitiesApplication',
			'dvd'           => 'UtilitiesApplication',
			'simul'         => 'EntertainmentApplication',
		];

		$lower = strtolower($first_valid);
		foreach ($map as $key => $target) {
			if (strpos($lower, $key) !== false) return $target;
		}

		// @MODIFIED: Force a valid Google enum instead of free-text ucfirst().
		return 'UtilitiesApplication';
	}

	private static function default_security_badge(Safety_Data $safety): string
	{
		return '✓ Verified Download Links';
	}

	private static function derive_min_os(Article_Schema $schema): string
	{
		return $schema->system_requirements->minimum['os'] ?? '';
	}

	private static function derive_architecture($tech): string
	{
		$file_name = strtolower($tech->file_name ?? '');
		
		// ARM64/Apple Silicon detection
		if (strpos($file_name, 'arm64') !== false || 
			strpos($file_name, 'aarch64') !== false ||
			strpos($file_name, 'apple silicon') !== false ||
			strpos($file_name, 'm1') !== false ||
			strpos($file_name, 'm2') !== false ||
			strpos($file_name, 'm3') !== false ||
			strpos($file_name, 'silicon') !== false) {
			return 'ARM64';
		}
		
		// ARM detection
		if (strpos($file_name, 'arm') !== false && strpos($file_name, '64') === false) {
			return 'ARM';
		}
		
		// 64-bit detection (enhanced)
		if (strpos($file_name, '64') !== false || 
			strpos($file_name, 'amd64') !== false ||
			strpos($file_name, 'x86_64') !== false) {
			return '64';
		}
		
		return '32';
	}

	private static function derive_publisher($tech): string
	{
		return $tech->developer ?: ($tech->publisher ?: '');
	}

	private static function derive_rating_count(Article_Schema $schema): string
	{
		// Deprecated in favor of direct Rating_System sync in from_schema()
		return $schema->rating_count > 0 ? "({$schema->rating_count} ratings)" : '';
	}

	private static function extract_first_category(string $categories): string
	{
		$parts = explode(',', $categories);
		$platforms = ['windows', 'macos', 'android', 'ios', 'linux', 'mac'];
		
		foreach ($parts as $part) {
			$clean = trim($part);
			if ($clean === '') continue;
			
			if (! in_array(strtolower($clean), $platforms)) {
				return $clean;
			}
		}

		return trim($parts[0] ?? '');
	}

	private static function normalize_license_details(string $raw): string
	{
		if (preg_match('/free|open.?source/i', $raw)) return 'Free';
		if (preg_match('/trial|demo/i', $raw)) return 'Trial';
		return 'Paid';
	}

	private static function derive_author_name(int $post_id): string
	{
		if ($post_id <= 0) return '';
		$reviewer_id = (int) \get_post_meta($post_id, '_seo_reviewed_by', true);
		$uid = $reviewer_id ?: \get_post_field('post_author', $post_id);
		if ($uid) {
			$user = \get_user_by('id', $uid);
			return $user ? $user->display_name : '';
		}
		return '';
	}

	/**
	 * Fallback: extract first non-OS category from post's assigned WordPress categories.
	 * Used when schema and tech_specs both lack a category (AI omission).
	 *
	 * @param int $post_id
	 * @return string Category slug or empty string.
	 */
	private static function fallback_category_from_post(int $post_id): string
	{
		if ($post_id <= 0) {
			return '';
		}
		$categories = \get_the_category($post_id);
		if (empty($categories) || \is_wp_error($categories)) {
			return '';
		}
		$os_slugs = array('windows', 'macos', 'mac', 'linux', 'android', 'ios', 'featured', 'offline', 'portable');
		foreach ($categories as $cat) {
			if (!in_array($cat->slug, $os_slugs, true)) {
				return $cat->slug;
			}
		}
		return '';
	}
}
