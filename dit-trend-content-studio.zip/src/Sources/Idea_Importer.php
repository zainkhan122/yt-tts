<?php

/**
 * Idea Importer Service
 *
 * @package DIT_TrendStudio
 * @MODIFIED 2025-12-13 - New file for sourcing layer
 * @MODIFIED 2025-12-20 - Pinterest removed (API complexity). NewsAPI + Social Searcher added as free-tier providers.
 */

namespace DIT\TrendStudio\Sources;

use DIT\TrendStudio\Infrastructure\Logger;
use DIT\TrendStudio\Services\Content_Cleaner;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Orchestrates idea import from multiple source providers
 */
class Idea_Importer
{
    /**
     * Logger instance
     *
     * @var Logger
     */
    private Logger $logger;

    /**
     * Registered source providers
     *
     * @var Source_Provider[]
     */
    private array $providers = array();

    /**
     * Constructor
     *
     * @param Logger $logger Logger instance
     */
    public function __construct(Logger $logger)
    {
        $this->logger = $logger;
    }

    /**
     * Register a source provider
     *
     * @param Source_Provider $provider Provider instance
     * @return void
     */
    public function register_provider(Source_Provider $provider): void
    {
        $this->providers[$provider->get_type()] = $provider;
    }

    /**
     * Get all registered providers
     *
     * @return Source_Provider[]
     */
    public function get_providers(): array
    {
        return $this->providers;
    }

    /**
     * Get available (configured) providers
     *
     * @return Source_Provider[]
     */
    public function get_available_providers(): array
    {
        return array_filter($this->providers, function ($provider) {
            return $provider->is_available();
        });
    }

    /**
     * Import ideas from all available providers
     *
     * @param array $params Optional params passed to providers
     * @return array Import results: ['imported' => int, 'skipped' => int, 'errors' => string[]]
     */
    public function import_all(array $params = array()): array
    {
        $results = array(
            'imported' => 0,
            'skipped' => 0,
            'errors' => array(),
        );

        $available = $this->get_available_providers();
        if (empty($available)) {
            $this->logger->warning('Idea Importer: No available providers configured');
            return array(
                'imported' => 0,
                'skipped' => 0,
                'errors' => array(),
            );
        }

        foreach ($available as $provider) {
            try {
                $ideas = $provider->fetch_ideas($params);
                $provider_results = $this->save_ideas($ideas);
                $results['imported'] += $provider_results['imported'];
                $results['skipped'] += $provider_results['skipped'];
            } catch (\Exception $e) {
                $error = sprintf('[%s] %s', $provider->get_name(), $e->getMessage());
                $results['errors'][] = $error;
                $this->logger->error('Idea Importer: ' . $error);
            }
        }

        $this->logger->info(sprintf(
            'Idea Importer: Completed. Imported: %d, Skipped: %d, Errors: %d',
            $results['imported'],
            $results['skipped'],
            count($results['errors'])
        ));

        return $results;
    }

    /**
     * Import ideas from a specific provider type
     *
     * @param string $type   Provider type (rss, pinterest)
     * @param array  $params Optional params
     * @return array Import results
     */
    public function import_from(string $type, array $params = array()): array
    {
        if (!isset($this->providers[$type])) {
            return array(
                'imported' => 0,
                'skipped' => 0,
                'errors' => array("Provider '{$type}' not registered"),
            );
        }

        $provider = $this->providers[$type];
        if (!$provider->is_available()) {
            return array(
                'imported' => 0,
                'skipped' => 0,
                'errors' => array("Provider '{$type}' is not configured"),
            );
        }

        try {
            $ideas = $provider->fetch_ideas($params);
            return $this->save_ideas($ideas);
        } catch (\Exception $e) {
            return array(
                'imported' => 0,
                'skipped' => 0,
                'errors' => array($e->getMessage()),
            );
        }
    }

    /**
     * Save ideas as dit_idea CPT posts
     *
     * @param Idea_DTO[] $ideas Array of idea DTOs
     * @return array ['imported' => int, 'skipped' => int]
     */
    private function save_ideas(array $ideas): array
    {
        $imported = 0;
        $skipped = 0;

        foreach ($ideas as $idea) {
            // Check for duplicate by content hash
            $existing = $this->find_by_hash($idea->content_hash);
            if ($existing) {
                $skipped++;
                continue;
            }

            // Create new dit_idea post
            $post_id = wp_insert_post(array(
                'post_type' => 'dit_idea',
                'post_title' => $idea->title,
                // @MODIFIED 2026-01-26 - Clean HTML to remove garbage but keep visuals/text
                'post_content' => !empty($idea->content) ? $this->clean_html_content($idea->content) : $idea->excerpt,
                'post_status' => 'draft',  // Admin-only, awaiting review
                'meta_input' => array(
                    '_dit_search_intent' => 'news', // @MODIFIED 2026-01-24 - Force 'news' intent for showbiz
                    '_dit_ts_source_url' => $idea->source_url,
                    '_dit_ts_source_type' => $idea->source_type,
                    '_dit_ts_provider_name' => $idea->provider_name,
                    '_dit_ts_image_url' => $idea->image_url,
                    '_dit_ts_published_at' => $idea->published_at,
                    '_dit_ts_fetched_at' => $idea->fetched_at,
                    '_dit_ts_content_hash' => $idea->content_hash,
                    '_dit_ts_raw_data' => wp_json_encode($idea->raw_data),
                ),
            ));

            if (is_wp_error($post_id)) {
                $this->logger->warning('Idea Importer: Failed to save idea: ' . $post_id->get_error_message());
                continue;
            }

            // Maybe sideload featured image
            if (!empty($idea->image_url)) {
                $this->maybe_sideload_image($post_id, $idea->image_url);
            }

            $imported++;
        }

        return array(
            'imported' => $imported,
            'skipped' => $skipped,
        );
    }

    /**
     * Find existing idea by content hash
     *
     * @param string $hash Content hash
     * @return int|null Post ID if found, null otherwise
     */
    private function find_by_hash(string $hash): ?int
    {
        global $wpdb;

        $post_id = $wpdb->get_var($wpdb->prepare(
            "SELECT post_id FROM {$wpdb->postmeta} 
             WHERE meta_key = '_dit_ts_content_hash' AND meta_value = %s 
             LIMIT 1",
            $hash
        ));

        return $post_id ? (int) $post_id : null;
    }

    /**
     * Optionally sideload featured image with smart renaming
     * @MODIFIED 2026-02-09 - Added filename sanitization to prevent .webp.webp and rename to title
     *
     * @param int    $post_id   Post ID
     * @param string $image_url Image URL
     * @return void
     */
    private function maybe_sideload_image(int $post_id, string $image_url): void
    {
        // Skip if already has thumbnail
        if (has_post_thumbnail($post_id)) {
            return;
        }

        // Require media functions
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        // Prepare filename filter
        $post_title = get_the_title($post_id);
        $rename_filter = function ($file) use ($post_title) {
            $info = pathinfo($file['name']);
            $ext = empty($info['extension']) ? '' : '.' . $info['extension'];

            // Fix double extension (.webp.webp)
            if (preg_match('/\.webp\.webp$/i', $file['name'])) {
                $ext = '.webp';
            } elseif (preg_match('/\.jpg\.jpg$/i', $file['name'])) {
                $ext = '.jpg';
            }

            // Create SEO-friendly filename from post title
            $new_name = sanitize_title($post_title);

            // Limit length
            $new_name = mb_substr($new_name, 0, 80);

            if (!empty($new_name)) {
                $file['name'] = $new_name . $ext;
            }

            return $file;
        };

        // Add filter
        add_filter('wp_handle_sideload_prefilter', $rename_filter);

        // Perform sideload
        $attachment_id = media_sideload_image($image_url, $post_id, '', 'id');

        // Remove filter
        remove_filter('wp_handle_sideload_prefilter', $rename_filter);

        if (!is_wp_error($attachment_id)) {
            set_post_thumbnail($post_id, $attachment_id);

            // @MODIFIED 2026-02-14 - Robustness: Ensure metadata is generated.
            // This prevents "Could not retrieve featured image data" in Gutenberg.
            $attach_file = get_attached_file($attachment_id);
            if ($attach_file && file_exists($attach_file)) {
                $metadata = wp_generate_attachment_metadata($attachment_id, $attach_file);
                wp_update_attachment_metadata($attachment_id, $metadata);
            }

            // @MODIFIED 2026-02-09 - Log rename success
            $this->logger->info("Sideloaded image for Post $post_id", ['original' => $image_url, 'attachment_id' => $attachment_id]);
        } else {
            $this->logger->warning("Failed to sideload image: " . $attachment_id->get_error_message());
        }
    }

    /**
     * Get pending ideas (not yet generated)
     *
     * @param int $limit Max ideas to return
     * @param string|null $category_filter Optional category slug to override global setting
     * @return \WP_Post[]
     */
    public function get_pending_ideas(int $limit = 20, ?string $category_filter = null): array
    {
        // @MODIFIED 2026-02-08 - Use provided filter if set, otherwise fall back to global setting
        if ($category_filter !== null) {
            $category_slug = $category_filter;
        } else {
            $category_slug = get_option('dit_ts_import_draft_category', '');
        }

        // @MODIFIED 2026-01-30 - Fallback to vertical if specific category not set, to prevent "Apple" leaks
        if (empty($category_slug)) {
            $category_slug = get_option('dit_ts_content_vertical', '');
        }

        // @MODIFIED 2026-01-30 - Support comma-separated categories (trim spaces)
        if (!empty($category_slug)) {
            $parts = explode(',', $category_slug);
            $parts = array_map('trim', $parts);
            $category_slug = implode(',', array_filter($parts));
        }

        // If no category filter is set, use original unified query
        if (empty($category_slug)) {
            return get_posts(array(
                'post_type' => array('dit_idea', 'post'), // @MODIFIED 2026-01-25 - Support standard drafts as source
                'post_status' => array('draft', 'pending', 'failed'),
                'posts_per_page' => $limit,
                'orderby' => 'date',
                'order' => 'DESC',
                'meta_query' => array(
                    'relation' => 'OR',
                    array(
                        'key' => '_dit_ts_generated',
                        'compare' => 'NOT EXISTS',
                    ),
                    array(
                        'key' => '_dit_ts_generated',
                        'value' => 'failed',
                        'compare' => '=',
                    ),
                ),
            ));
        }

        // If category filter is set, split queries to avoid filtering out dit_idea (which usually don't have cats)
        // 1. Get dit_idea (unfiltered)
        $ideas = get_posts(array(
            'post_type' => 'dit_idea',
            'post_status' => array('draft', 'pending', 'failed'),
            'posts_per_page' => $limit,
            'orderby' => 'date',
            'order' => 'DESC',
            'meta_query' => array(
                'relation' => 'OR',
                array(
                    'key' => '_dit_ts_generated',
                    'compare' => 'NOT EXISTS',
                ),
                array(
                    'key' => '_dit_ts_generated',
                    'value' => 'failed',
                    'compare' => '=',
                ),
            ),
        ));

        // 2. Get standard posts (filtered by category)
        $args = array(
            'post_type' => 'post',
            'post_status' => array('draft', 'pending', 'failed'),
            'posts_per_page' => $limit,
            'orderby' => 'date',
            'order' => 'DESC',
            'meta_query' => array(
                'relation' => 'OR',
                array(
                    'key' => '_dit_ts_generated',
                    'compare' => 'NOT EXISTS',
                ),
                array(
                    'key' => '_dit_ts_generated',
                    'value' => 'failed',
                    'compare' => '=',
                ),
            ),
        );

        // @MODIFIED 2026-02-09 - Fix "No Pending Ideas" bug: Support both ID and Slug
        // If numeric (e.g. "5" or "5,6"), use 'category' (ID). Else use 'category_name' (Slug).
        // Remove commas for numeric check
        $clean_cat = str_replace(',', '', $category_slug);

        $this->logger->info("Idea Importer: Querying pending drafts...", [
            'raw_slug' => $category_slug,
            'is_numeric' => is_numeric($clean_cat),
            'clean_cat' => $clean_cat
        ]);

        if (is_numeric($clean_cat)) {
            // "category" argument expects comma-separated ID string or array.
            // If we have "5, 6", simply "5, 6" works for 'category' arg in get_posts (mapped to 'cat')?
            // get_posts() takes 'category' => int ID. For multiple, it's tricky.
            // WP_Query takes 'cat' => "5,6". 
            // So we explicitly use 'cat' or 'category__in'.
            // If comma present, explode to array and use category__in
            if (strpos($category_slug, ',') !== false) {
                $cats = array_map('intval', explode(',', $category_slug));
                $args['category__in'] = $cats;
            } else {
                $args['category'] = intval($category_slug);
            }
        } else {
            $args['category_name'] = $category_slug;
        }

        $this->logger->info("Idea Importer: WP Query Args", ['args' => json_encode($args)]);

        $posts = get_posts($args);

        // @MODIFIED 2026-04-26 - Debug: Log found post IDs to diagnose zero-count issues
        $post_ids = wp_list_pluck($posts, 'ID');
        $this->logger->info("Idea Importer: Found drafts", [
            'count' => count($posts),
            'post_ids' => array_values($post_ids),
            'category_query' => $args['category_name'] ?? 'none'
        ]);

        // Merge, sort by date, and limit
        $combined = array_merge($ideas, $posts);

        usort($combined, function ($a, $b) {
            return strtotime($b->post_date) - strtotime($a->post_date);
        });

        $result = array_slice($combined, 0, $limit);

        // @MODIFIED 2026-06-21 - Log import visibility for diagnostics
        if ($this->logger) {
            $first = !empty($result) ? $result[0]->post_title : 'none';
            $last = !empty($result) ? $result[count($result) - 1]->post_title : 'none';
            $this->logger->info("Idea_Importer: get_pending_ideas() returning {$limit} items.", [
                'total_fetched' => count($combined),
                'returning' => count($result),
                'first_title' => $first,
                'last_title' => $last,
            ]);
        }

        return $result;
    }

    /**
     * Mark idea as generated
     *
     * @param int $idea_id   Idea post ID
     * @param int $article_id Generated article post ID
     * @return void
     */
    public function mark_as_generated(int $idea_id, int $article_id): void
    {
        update_post_meta($idea_id, '_dit_ts_generated', '1');
        update_post_meta($idea_id, '_dit_ts_flag_set_at', time());
        update_post_meta($idea_id, '_dit_ts_article_id', $article_id);

        // @MODIFIED 2026-02-24 - Mark processed time + cleanup eligibility for safe source deletion.
        update_post_meta($idea_id, '_dit_ts_processed_at_gmt', (int) current_time('timestamp', true));
        update_post_meta($idea_id, '_dit_ts_cleanup_candidate', 1);

        // @MODIFIED 2026-01-31 - Keep original drafts completely unchanged
        // Only dit_idea posts get published (archived)
        $source_post = get_post($idea_id);
        if ($source_post && $source_post->post_type === 'post') {
            // Original draft post remains untouched
            // Meta fields (_dit_ts_generated, _dit_ts_article_id) are already set above
        } else {
            wp_update_post(array(
                'ID' => $idea_id,
                'post_status' => 'publish',  // Move from draft to published (still admin-only for CPT)
            ));
        }
    }
    /**
     * Clean HTML content to keep only relevant text and visuals
     * @param string $html Raw HTML
     * @return string Cleaned HTML
     */
    private function clean_html_content(string $html): string
    {
        // 1. Aggressively strip scripts and styles (including content)
        $html = preg_replace(array(
            '@<script[^>]*?>.*?</script>@si', // Strip out javascript
            '@<style[^>]*?>.*?</style>@si',   // Strip out styles
            '@<noscript[^>]*?>.*?</noscript>@si', // Strip out noscript
            '@<!--.*?-->@s',                  // Strip comments
        ), '', $html);

        // Define allowed tags and attributes for "Source Extraction"
        $allowed = array(
            'p' => array(),
            'br' => array(),
            'strong' => array(),
            'b' => array(),
            'em' => array(),
            'i' => array(),
            'h1' => array(),
            'h2' => array(),
            'h3' => array(),
            'h4' => array(),
            'ul' => array(),
            'ol' => array(),
            'li' => array(),
            'blockquote' => array(
                'class' => true,
                'data-dnt' => true,
                'cite' => true
            ),
            'iframe' => array(
                'src' => true,
                'width' => true,
                'height' => true,
                'frameborder' => true,
                'allow' => true,
                'allowfullscreen' => true,
                'title' => true
            ),
            'img' => array(
                'src' => true,
                'alt' => true,
                'width' => true,
                'height' => true
            ),
            'a' => array(
                'href' => true,
                'title' => true,
                'target' => true
            )
        );

        // 2. Filter via kses
        return wp_kses($html, $allowed);
    }
}
