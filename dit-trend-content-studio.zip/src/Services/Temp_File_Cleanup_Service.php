<?php

namespace DIT\TrendStudio\Services;

if (!defined('ABSPATH')) {
    exit;
}

class Temp_File_Cleanup_Service
{
    private const TTL = DAY_IN_SECONDS;
    private const PREFIX = 'dit-ts-';

    private $logger;

    public function __construct($logger = null)
    {
        $this->logger = $logger;
    }

    public function init(): void
    {
        add_action('dit_ts_daily_cleanup', [$this, 'cleanup_orphaned_temp_files']);
    }

    public function cleanup_orphaned_temp_files(): void
    {
        $dirs = $this->get_temp_directories();
        $cutoff = time() - self::TTL;
        $total_deleted = 0;

        foreach ($dirs as $dir) {
            $total_deleted += $this->sweep_directory($dir, $cutoff);
        }

        if ($total_deleted > 0 && $this->logger) {
            $this->logger->info(sprintf(
                'Temp_File_Cleanup: Deleted %d orphaned temp file(s) older than 24 hours.',
                $total_deleted
            ));
        }
    }

    private function get_temp_directories(): array
    {
        $dirs = [];

        if (function_exists('sys_get_temp_dir')) {
            $sys_tmp = rtrim(sys_get_temp_dir(), '\\/');
            if (is_dir($sys_tmp)) {
                $dirs[] = $sys_tmp;
            }
        }

        if (function_exists('get_temp_dir')) {
            $wp_tmp = rtrim(get_temp_dir(), '\\/');
            if (is_dir($wp_tmp) && !in_array($wp_tmp, $dirs, true)) {
                $dirs[] = $wp_tmp;
            }
        }

        if (defined('WP_CONTENT_DIR')) {
            $content_dir = rtrim(WP_CONTENT_DIR, '\\/');
            if (is_dir($content_dir) && !in_array($content_dir, $dirs, true)) {
                $dirs[] = $content_dir;
            }
        }

        return $dirs;
    }

    private function sweep_directory(string $dir, int $cutoff): int
    {
        $count = 0;

        try {
            $iterator = new \DirectoryIterator($dir);
        } catch (\Exception $e) {
            return 0;
        }

        foreach ($iterator as $fileinfo) {
            if ($fileinfo->isDot() || !$fileinfo->isFile()) {
                continue;
            }

            $name = $fileinfo->getFilename();

            if (strpos($name, self::PREFIX) !== 0) {
                continue;
            }

            if ($fileinfo->getMTime() < $cutoff) {
                $path = $fileinfo->getPathname();
                if (@unlink($path)) {
                    $count++;
                }
            }
        }

        return $count;
    }
}
