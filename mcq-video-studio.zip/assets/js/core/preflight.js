/**
 * MCQVS Preflight
 * Verifies critical assets exist and can be decoded BEFORE render.
 *
 * @package MCQ_Video_Studio
 * @since 9.0.0
 */
(function (window) {
  "use strict";

  const MCQVS_Preflight = {
    /**
     * @param {Object} plan RenderPlan
     * @param {Object} deps {assetCache, audioContext, timeoutMs}
     * @returns {Promise<{ok:boolean, issues:Array}>}
     */
    async run(plan, deps = {}) {
      const issues = [];
      const timeoutMs = Number(deps.timeoutMs || 12000);
      const cache = deps.assetCache || null;
      const audioCtx = deps.audioContext || null;

      const checkUrl = async (url, kind) => {
        if (!url) return;
        try {
          // Prefer cache fetch to validate availability (includes timeout)
          if (cache) await cache.fetchArrayBuffer(url, { timeoutMs });
          else {
            const ctrl = new AbortController();
            const t = setTimeout(() => ctrl.abort(), timeoutMs);
            try {
              const res = await fetch(url, { method: "GET", signal: ctrl.signal });
              if (!res.ok) throw new Error(`HTTP ${res.status}`);
              await res.arrayBuffer();
            } finally {
              clearTimeout(t);
            }
          }

          // Decode audio if possible (catches corrupted/mp3 mime edge cases)
          if (kind === "audio" && audioCtx) {
            if (cache) await cache.decodeAudio(audioCtx, url, { timeoutMs });
            else {
              const res = await fetch(url);
              const buf = await res.arrayBuffer();
              await audioCtx.decodeAudioData(buf.slice(0));
            }
          }
        } catch (e) {
          issues.push({ level: "error", kind, url, message: String(e && e.message ? e.message : e) });
        }
      };

      const audios = plan?.assets?.audio || [];
      const images = plan?.assets?.images || [];

      for (const u of audios) await checkUrl(u, "audio");
      for (const u of images) await checkUrl(u, "image");


const fonts = plan?.assets?.fonts || [];
if (fonts.length && typeof document !== "undefined" && document.fonts && document.fonts.load) {
  for (const f of fonts) {
    if (!f) continue;
    try {
      // Attempt to load a representative font face
      await Promise.race([
        document.fonts.load(`16px "${f}"`),
        new Promise((_, rej) => setTimeout(() => rej(new Error("font load timeout")), timeoutMs)),
      ]);
    } catch (e) {
      issues.push({ level: "warn", kind: "font", font: f, message: String(e && e.message ? e.message : e) });
    }
  }
}

      return { ok: issues.length === 0, issues };
    },
  };

  window.MCQVS_Preflight = MCQVS_Preflight;
})(window);
