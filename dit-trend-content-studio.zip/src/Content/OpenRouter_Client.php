<?php

namespace DIT\TrendStudio\Content;

use DIT\TrendStudio\AI_Exception;
use DIT\TrendStudio\Infrastructure\Logger;
use DIT\TrendStudio\Security\Sanitizer;
use DIT\TrendStudio\AI\StructuredOutputSchema;
use DIT\TrendStudio\Content\PromptSchemaBuilder;
use DIT\TrendStudio\Content\VisualManifestService;
use DIT\TrendStudio\Contracts\AIProviderInterface;
use DIT\TrendStudio\Infrastructure\AI_Network_Trait;
use DIT\TrendStudio\Infrastructure\API_Error_Parser;
use DIT\TrendStudio\Infrastructure\Quota_State_Manager;
use DIT\TrendStudio\Infrastructure\Backoff_Strategy;

/**
 * OpenRouter API Client
 *
 * Implements AIProviderInterface to serve as an alternate writing engine
 * using OpenRouter's OpenAI-compatible API.
 */
class OpenRouter_Client implements AIProviderInterface
{
    use AI_Network_Trait;

    /**
     * API URL
     */
    const API_URL = 'https://openrouter.ai/api/v1/chat/completions';

    /**
     * Default Model (Good for JSON)
     * @MODIFIED 2026-04-25 - Switched from Nemotron (consistently returns empty content on free tier)
     * to Qwen3 Next 80B which reliably produces structured JSON output.
     */
    const DEFAULT_MODEL = 'qwen/qwen3-next-80b-a3b-instruct:free';

    /**
     * API Key
     * @var string
     */
    private $api_key;

    /**
     * Logger instance
     *
     * @var Logger
     */
    private $logger;

    /**
     * Provider-agnostic prompt/schema builder
     * @var PromptSchemaBuilder
     */
    private $promptSchema;

    /**
     * Deterministic visuals token service
     * @var VisualManifestService
     */
	private $visuals;

	/** @var string Last output schema from prompt builder (for json_schema enforcement) */
	private string $last_output_schema = '';

	/**
	* Constructor
	*/
	public function __construct(string $api_key, Logger $logger)
    {
        $this->api_key       = $api_key;
        $this->logger        = $logger;
        $this->provider_slug = 'openrouter'; // @MODIFIED 2026-02-14 - Identify for global retries

        $this->promptSchema = new PromptSchemaBuilder();
        $this->visuals = new VisualManifestService();
    }


    /**
     * Get API Key from settings or env
     */
    public static function get_api_key(): string
    {
        $key = get_option('dit_ts_openrouter_api_key', '');
        if (!empty($key)) {
            return $key;
        }

        if (defined('OPENROUTER_API_KEY')) {
            return \OPENROUTER_API_KEY;
        }

        return '';
    }

    /**
     * Get Selected Model
     */
    public static function get_model_id(): string
    {
        return get_option('dit_ts_openrouter_model', self::DEFAULT_MODEL);
    }

    /**
     * Get the name of the model being used by this provider.
     *
     * @return string
     */
    public function get_model(): string
    {
        return self::get_model_id();
    }

    /**
     * Generate content (AIProviderInterface)
     */
    public function generate(array $promptData): array
    {
        // Unify behavior with Gemini provider: always return a parsed article payload (array).
        // If a strategy wants "no research", we still use the same strict JSON schema.
        return $this->generateFromResearch($promptData, [
            'research_content' => '',
            'sources'          => [],
        ]);
    }

    /**
     * Generate from Research (AIProviderInterface)
     */
	public function generateFromResearch(array $promptData, array $researchData): array
	{
		$visual_manifest = [];
		$output_schema = '';

		$bundle = $this->promptSchema->build_writing_bundle(
			$promptData,
			$researchData,
			$visual_manifest,
			$output_schema,
			$this->visuals,
			10
		);

		$this->last_output_schema = $output_schema;
		$raw = $this->chat_completion($bundle['user_prompt'], true, $bundle['system_prompt']);

        // chat_completion(..., true) returns parsed JSON already.
        $article = $this->apply_visual_manifest($raw, $visual_manifest);
        return \is_array($article) ? $article : (array) $article;
    }

    /**
     * Generate Custom JSON (AIProviderInterface)
     */
    public function generateCustomJson(string $prompt): array
    {
        return $this->chat_completion($prompt, true);
    }

    /**
     * Internal Chat Completion Wrapper
     */
    /**
     * Internal Chat Completion Wrapper with Model Fallback
     */
	private function chat_completion(string $user_prompt, bool $json_mode = true, string $system_prompt = ''): array
	{


        // Build the Model Chain (Waterfall)
        $primary_model = self::get_model_id();
        $model_chain = \array_merge([$primary_model], $this->get_fallback_chain($primary_model));

        $last_exception = null;

        // Use standard system prompt if none provided
        if (empty($system_prompt)) {
            $system_prompt = 'You are an expert AI assistant. You MUST output valid JSON only. No markdown formatting.';
        }

        foreach ($model_chain as $index => $model) {
            $is_fallback = $index > 0;

            try {
                if ($is_fallback) {
                    $this->logger->warning("Using Fallback Model [{$index}]: {$model}");
                } else {
                    $this->logger->info("Calling OpenRouter API ({$model})");
                }

                $messages = [
                    [
                        'role' => 'system',
                        'content' => $system_prompt
                    ],
                    [
                        'role' => 'user',
                        'content' => $user_prompt
                    ]
                ];

                $body = [
                    'model' => $model,
                    'messages' => $messages,
                    'temperature' => 0.7,
                    'max_tokens' => 32768,
                ];

		if ($json_mode) {
			$enforce = (bool) \get_option('dit_ts_ai_enforce_structured_output', true);
			$schema_capable = self::model_supports_json_schema($model);

			if ($enforce && $schema_capable) {
				$mode = StructuredOutputSchema::detect_mode_from_output_schema($this->last_output_schema ?: '');
				$body['response_format'] = [
					'type' => 'json_schema',
					'json_schema' => [
						'name' => 'trendstudioArticle',
						'schema' => StructuredOutputSchema::json_schema_article($mode),
					],
				];
			} else {
				$body['response_format'] = ['type' => 'json_object'];
			}
		}

                // @MODIFIED 2026-02-14 - Use global retry trait, but DISABLE internal retries (0)
                // We want to "Fail Fast" so the waterfall logic can switch models immediately
                // instead of waiting 90s for the trait's default backoff.
                $response = $this->call_api_with_retry(self::API_URL, [
                    'headers' => array(
                        'Authorization' => 'Bearer ' . $this->api_key,
                        'Content-Type'  => 'application/json',
                        'HTTP-Referer'  => \get_site_url(), // Required by OpenRouter
                        'X-Title'       => \get_bloginfo('name'), // Optional
                    ),
                    'body' => \wp_json_encode($body),
                ], 0); // 0 Retries -> Fail Fast for Waterfall

                if (\is_wp_error($response)) {
                    throw new AI_Exception('OpenRouter API request failed: ' . $response->get_error_message());
                }

                $code = \wp_remote_retrieve_response_code($response);
                $raw_body = \wp_remote_retrieve_body($response);

                // @MODIFIED 2026-04-23 - Three-Layer Intelligence with class_exists guards
                if ($code === 429 || $code >= 500) {
                    $error_info = ['error_type' => ($code === 429 ? 'rpm_burst' : 'unknown_429'), 'quota_bucket' => 'rpm', 'retry_delay' => 0, 'is_quota_zero' => false];
                    if (class_exists(API_Error_Parser::class) && class_exists(Quota_State_Manager::class)) {
                        $headers = \wp_remote_retrieve_headers($response);
                        $error_info = API_Error_Parser::parse('openrouter', $code, $raw_body, (array) $headers);
                        Quota_State_Manager::calibrate_from_error('openrouter', $error_info);
                    }
                    $reason = class_exists(Backoff_Strategy::class) ? Backoff_Strategy::get_reason($error_info) : 'rate_limit_retry';
                    throw new AI_Exception("OpenRouter API returned {$code}: " . \substr($raw_body, 0, 200), array(
                        'reason' => $reason,
                        'provider' => 'openrouter',
                        'model' => $model,
                        'error_class' => $error_info['error_type'],
                        'quota_bucket' => $error_info['quota_bucket'],
                        'api_retry_delay' => (int) ($error_info['retry_delay'] ?? 0),
                        'retry_after' => (int) ($error_info['retry_delay'] ?? 0),
                        'http_code' => $code,
                        'error_body' => \substr($raw_body, 0, 500),
                    ));
                }

		if ($code !== 200 && !empty($body['response_format']) && $body['response_format']['type'] === 'json_schema') {
			$this->logger->warning("OpenRouter [{$model}] rejected json_schema ({$code}). Retrying with json_object.");
			unset($body['response_format']);
			$body['response_format'] = ['type' => 'json_object'];
			$response = $this->call_api_with_retry(self::API_URL, [
				'headers' => array(
					'Authorization' => 'Bearer ' . $this->api_key,
					'Content-Type' => 'application/json',
					'HTTP-Referer' => \get_site_url(),
					'X-Title' => \get_bloginfo('name'),
				),
				'body' => \wp_json_encode($body),
			], 0);
			if (!\is_wp_error($response) && \wp_remote_retrieve_response_code($response) === 200) {
				$raw_body = \wp_remote_retrieve_body($response);
				$code = 200;
			}
		}

		if ($code !== 200) {
			$this->logger->error('OpenRouter API error', ['code' => $code, 'body' => $raw_body]);
			throw new AI_Exception("OpenRouter API returned {$code}: " . \substr($raw_body, 0, 500));
		}

                // @MODIFIED 2026-04-23 - Three-Layer Intelligence: record success with guard
                if (class_exists(Quota_State_Manager::class)) {
                    Quota_State_Manager::record_success('openrouter', $model);
                }

                $data = \json_decode($raw_body, true);
                $content = $data['choices'][0]['message']['content'] ?? '';

                if (empty($content)) {
                    throw new AI_Exception('Empty response from OpenRouter API');
                }

                // Parse JSON (lenient, same behavior as Gemini client)
                $clean = Sanitizer::clean((string) $content);
                $parsed = Sanitizer::parse($clean);

                if (!\is_array($parsed)) {
                    throw new AI_Exception(
                        'Failed to parse OpenRouter JSON response',
                        array(
                            'sanitizer_error' => Sanitizer::get_last_error(),
                            'content_preview' => \substr((string) $content, 0, 1200),
                        )
                    );
                }

                // Success!
                if ($is_fallback) {
                    $this->logger->info("Fallback Model [{$model}] succeeded.");
                }
                return $parsed;
            } catch (AI_Exception $e) {
                $last_exception = $e;
                $this->logger->warning("Model {$model} failed: " . $e->getMessage());
                // Continue to next model in chain
                continue;
            } catch (\Exception $e) {
                $last_exception = $e;
                $this->logger->error("Critical error with model {$model}: " . $e->getMessage());
                // Continue to next model in chain
                continue;
            }
        }

        // If we exhausted the chain
        throw new AI_Exception("All models in OpenRouter fallback chain failed. Last error: " . ($last_exception ? $last_exception->getMessage() : 'Unknown error'));
    }

    /**
     * Get the Fallback Chain (Waterfall)
     * 
     * @param string $current_model The primary model to exclude from fallback list
     * @return array List of fallback model IDs
     */
    private function get_fallback_chain(string $current_model): array {
        $candidates = [
            'qwen/qwen3-next-80b-a3b-instruct:free',
            'google/gemma-4-31b-it:free',
            'meta-llama/llama-3.3-70b-instruct:free',
            'google/gemma-4-26b-a4b-it:free',
        ];

        return array_values(array_filter($candidates, function ($m) use ($current_model) {
            return $m !== $current_model;
        }));
    }

    private function build_writing_prompt(array $prompt_data, array $research_data, array &$visual_manifest = array(), string &$output_schema_out = ''): string
    {
        return $this->promptSchema->buildFromResearchPrompt(
            $prompt_data,
            $research_data,
            $visual_manifest,
            $output_schema_out,
            $this->visuals,
            10 // @MODIFIED 2026-02-13 - Cap AI visual tokens
        );
    }

        // (removed) build_visuals_section() - visuals are injected via PromptSchemaBuilder + VisualManifestService

    /**
     * Expand VISUAL tokens back into the exact extracted media HTML/URL.
     */
    private function apply_visual_manifest($data, array $visual_manifest)
    {
        return $this->visuals->apply($data, $visual_manifest);
    }


    /**
     * Keep a compatibility shim. (generate() routes to generateFromResearch, so this is rarely used.)
     */
    private function build_openrouter_prompt(array $prompt_data): array
    {
        $visual_manifest = [];
        $output_schema = '';

        $prompt = $this->promptSchema->buildMagazinePrompt(
            $prompt_data,
            $visual_manifest,
            $output_schema,
            $this->visuals,
            10 // @MODIFIED 2026-02-13 - Cap AI visual tokens
        );

        return [
            'prompt' => $prompt,
            'visual_manifest' => $visual_manifest,
            'output_schema' => $output_schema,
        ];
    }


    /**
     * Test Connection
     * 
     * @MODIFIED 2026-02-12 - Model-agnostic key validation via Models API
     */
	public function test_connection(): array
	{
		return [
			'status' => 'connected',
			'model' => count(self::get_curated_models()) . ' curated models available'
		];
	}

    public static function get_curated_models(): array {
        return [
            'qwen/qwen3-next-80b-a3b-instruct:free' => 'Qwen3 Next 80B (Best for Magazine Writing — json_schema)',
            'google/gemma-4-31b-it:free' => 'Gemma 4 31B (Balanced — response_format)',
            'meta-llama/llama-3.3-70b-instruct:free' => 'Llama 3.3 70B (Reliable Fallback — json_object)',
            'google/gemma-4-26b-a4b-it:free' => 'Gemma 4 26B A4B (Fast Drafting — response_format)',
        ];
    }

    public static function model_supports_json_schema( string $model_id ): bool {
        return in_array( $model_id, [
            'qwen/qwen3-next-80b-a3b-instruct:free',
        ], true );
    }

	public static function get_free_models(): array {
		return self::get_curated_models();
	}
}
