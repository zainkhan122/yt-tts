<?php

/**
 * Schema Sync Service
 * 
 * Centralized service for Article_Schema persistence and derived view regeneration.
 * Enforces Single Source of Truth pattern.
 *
 * @MODIFIED 2025-12-11 v1.8.0: New class for data synchronization architecture
 * @package SEO_Article_Generator
 */

namespace SEO_Article_Generator\Services;

// Prevent direct access.
if (!defined('ABSPATH')) {
    exit;
}

use SEO_Article_Generator\Generator\Article_Schema;
use SEO_Article_Generator\Generator\Hero_Data_Provider;

/**
 * Centralized schema load/save with derived view regeneration.
 * 
 * This service explicitly treats the post meta snapshot (_seo_gen_article_snapshot)
 * as the absolute canonical source of truth.
 * Derived views (such as _seo_gen_hero_data) are materialized caches explicitly
 * built from the canonical snapshot and overrides.
 */
class Schema_Sync_Service
{
    /**
     * Re-entry guard: prevents apply_hero_overrides() → save_schema() →
     * write_software_schema() → (hook fires) → save_schema() cascade.
     * Static because a single PHP request has one execution context.
     */
    private static bool $is_saving = false;

    /** WordPress unslashes metadata values; preserve literal source labels/JSON. */
    private static function write_meta(int $post_id, string $key, $value): void {
        \update_post_meta($post_id, $key, \wp_slash($value));
    }


    /**
     * Per-request permalink cache.
     * get_permalink() is expensive in XAMPP (rewrites resolved via DB).
     * Keyed by post_id so multiple posts in one request are still correct.
     *
     * @var array<int, string>
     */
    private static array $permalink_cache = [];

    /**
     * Meta key for article snapshot (canonical data).
     */
    private const META_SNAPSHOT = '_seo_gen_article_snapshot';

    /**
     * Meta key for hero overrides (presentation layer).
     */
    private const META_HERO_OVERRIDES = '_seo_gen_hero_overrides';

    /**
     * Meta key for derived hero data (cache).
     */
    private const META_HERO_DATA = '_seo_gen_hero_data';

    /**
     * Meta key for schema modification timestamp.
     */
    private const META_SCHEMA_MODIFIED = '_seo_gen_schema_modified';

    /**
     * Load Article_Schema from post meta snapshot.
     *
     * @MODIFIED 2025-12-11 v1.8.0: Initial implementation
     *
     * @param int $post_id WordPress post ID.
     * @return Article_Schema|null Schema instance or null if no snapshot exists.
     */
    public static function load_schema(int $post_id): ?Article_Schema
    {
        $snapshot = get_post_meta($post_id, self::META_SNAPSHOT, true);

        if (empty($snapshot) || !is_array($snapshot)) {
            return null;
        }

        return Article_Schema::from_array($snapshot);
    }

    /**
     * Save schema to snapshot and regenerate all derived views.
     *
     * Derived views updated:
     * - _seo_gen_hero_data (via Hero_Data_Provider)
     * - _seo_gen_schema_modified (timestamp)
     *
     * @since 1.8.0
     *
     * @param int            $post_id        WordPress post ID.
     * @param Article_Schema $schema         The schema to persist.
     * @param array|null     $hero_overrides Optional hero overrides to apply.
     * @return void
     */
    public static function save_schema(int $post_id, Article_Schema $schema, ?array $hero_overrides = null): void
    {
        // Re-entry guard: apply_hero_overrides() calls save_schema() which calls
        // write_software_schema() which may fire hooks that re-trigger save_schema().
        if (self::$is_saving) {
            return;
        }
        self::$is_saving = true;

        try {
            if ($hero_overrides !== null && array_key_exists('download_links', $hero_overrides)) {
                $schema->download_section['links'] = (array) $hero_overrides['download_links'];
            }
            $before_links = (array) ($schema->download_section['links'] ?? array());
            $schema->download_section['links'] = \SEO_Article_Generator\Generator\Download_Link_Helper::normalize_links(
                $before_links, 'Other', (string) ($schema->tech_specs->homepage ?? ''),
                (string) ($schema->tech_specs->software_name ?? ''), (string) ($schema->tech_specs->changelogurl ?? '')
            );
            \SEO_Article_Generator\Generator\Download_Link_Helper::assert_manual_removals($schema->download_section['links'], $post_id);
            $schema->extra['_canonical_download_links'] = $schema->download_section['links'];
            \SEO_Article_Generator\Generator\Download_Link_Helper::trace_links('schema_save:' . $post_id, $before_links, $schema->download_section['links']);
            $new_snapshot = $schema->to_array();

            // 1. Persist canonical snapshot only when content actually changed.
            //    Avoids a MySQL write + serialization on every WP save when nothing changed.
            $existing_raw  = \get_post_meta($post_id, self::META_SNAPSHOT, true);
            $existing_hash = is_array($existing_raw) ? md5(serialize($existing_raw)) : '';
            $new_hash      = md5(serialize($new_snapshot));
            $snapshot_changed = ($existing_hash !== $new_hash);

            if ($snapshot_changed) {
                self::write_meta($post_id, self::META_SNAPSHOT, $new_snapshot);
            }

            // 2. Update modification timestamp only when snapshot changed.
            if ($snapshot_changed) {
                self::write_meta($post_id, self::META_SCHEMA_MODIFIED, \SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts());
            }

        // 3. Regenerate derived hero data ONLY when overrides actually changed.
        // Previously this ran on every save - extremely expensive in XAMPP.
        $overrides = $hero_overrides;
        if ($overrides === null) {
            $overrides = \get_post_meta($post_id, self::META_HERO_OVERRIDES, true);
            if (!is_array($overrides)) {
                $overrides = [];
            }
            // [SSOT-FIX] Auto path (no explicit manual overrides passed): strip the
            // fields that MUST be re-derived on every update — version + both dates.
            // _seo_gen_hero_overrides may hold STALE values from a prior manual Hero
            // meta-box save (or a prior buggy run). Hero_Data_Provider::from_schema()
            // honors ALLOWED_OVERRIDES ('version','last_updated','last_verified_date'),
            // so leaving them in would clobber the freshly-derived canonical version
            // and dates on EVERY automated update — producing hero meta that lags the
            // title/tech_specs. Manual edits arrive via $hero_overrides (non-null) and
            // are intentionally honored below.
            foreach ( array( 'version', 'last_updated', 'last_verified_date', 'download_links', 'download_url', 'operating_system', 'os_support' ) as $_ssot_field ) {
                unset( $overrides[ $_ssot_field ] );
            }
        }

        // Links have already been promoted to canonical schema (including explicit empty arrays).
        unset($overrides['download_links']);

            // Compute overrides hash to detect actual changes
            $overrides_hash = md5(serialize($overrides));
            $existing_overrides_hash = \get_post_meta($post_id, '_seogen_overrides_hash', true) ?: '';

            // Skip hero regeneration if nothing changed
            if ($overrides_hash === $existing_overrides_hash && !$snapshot_changed) {
                // Still sync flat meta for legacy compatibility ONLY if hero_data exists.
                // Only write when values actually differ to avoid 4x unnecessary DB writes.
                $existing_hero = \get_post_meta($post_id, self::META_HERO_DATA, true);
                if (!empty($existing_hero)) {
                    $flat_syncs = [
                        '_seo_gen_download_url' => $existing_hero['download_url'] ?? '',
                        '_seo_gen_file_size'    => $existing_hero['file_size'] ?? '',
                        '_seo_gen_license'      => $existing_hero['license'] ?? '',
                        '_seo_gen_developer'    => $existing_hero['developer'] ?? '',
                    ];
                    foreach ($flat_syncs as $fk => $fv) {
                        if ((string) (\get_post_meta($post_id, $fk, true) ?? '') !== (string) $fv) {
                            self::write_meta($post_id, $fk, $fv);
                        }
                    }
                }

                // @FIX 2026-07-25: Force hero data regeneration on the fast path.
                // Even when overrides hash and snapshot hash are unchanged, seogenherodata
                // can drift from the schema due to pre-SSOT runs or partial regens.
                // Hero_Data_Provider::from_schema() is deterministic and read-only on the
                // schema object; the cost is negligible and correctness is critical.
                $hero_data = Hero_Data_Provider::from_schema($schema, $overrides, $post_id);
                self::write_meta($post_id, self::META_HERO_DATA, $hero_data);
                self::write_meta($post_id, 'seogenherodata', $hero_data);

                // Sync flat meta keys for legacy compatibility from the fresh hero data.
                if (!empty($hero_data)) {
                    self::write_meta($post_id, '_seo_gen_download_url', $hero_data['download_url'] ?? '');
                    self::write_meta($post_id, '_seo_gen_file_size',    $hero_data['file_size'] ?? '');
                    self::write_meta($post_id, '_seo_gen_license',      $hero_data['license'] ?? '');
                    self::write_meta($post_id, '_seo_gen_developer',    $hero_data['developer'] ?? '');
                }

                // @FIX 2026-07-25: Sync _seo_gen_version from schema's tech_specs.version
                // as the authoritative SSOT. Per architectural decision (Finding 8),
                // Title_Analyzer-extracted version from the LIVE post title is NOT
                // allowed to overwrite _seo_gen_version — the live title IS the
                // AI-generated title and cannot be a "newer" authority than the schema.
                // Title-parsed version comparison belongs in the staging gate
                // (Discovery_Processor) against the SOURCE post title only.
                $schema_version = trim((string) ($schema->tech_specs->version ?? ''));
                if (!empty($schema_version) && strcasecmp($schema_version, 'unknown') !== 0) {
                    $current_ver = trim((string) \get_post_meta($post_id, '_seo_gen_version', true));
                    if ($current_ver === '' || strcasecmp($current_ver, 'unknown') === 0
                        || \SEO_Article_Generator\Discovery\Title_Analyzer::is_newer_version($schema_version, $current_ver)) {
                        self::write_meta($post_id, '_seo_gen_version', $schema_version);
                    }
                }

                // Skip rest of hero processing
                goto after_hero_data;
            }

            // Store new overrides hash
            self::write_meta($post_id, '_seogen_overrides_hash', $overrides_hash);

		$hero_data = Hero_Data_Provider::from_schema($schema, $overrides, $post_id);
		self::write_meta($post_id, self::META_HERO_DATA, $hero_data);
		// @MODIFIED 2026-04-28: SSOT sync — write to seogenherodata as well so all readers
		// (Download_Renderer, Plugin::get_hero_data(), Discovery_Processor) see consistent data.
		self::write_meta($post_id, 'seogenherodata', $hero_data);
		// @ADDED 2026-06-06: SSOT sync — keep _seo_gen_version in lockstep with the
		// hero data write. _seo_gen_version is read as a canonical version source
		// by Discovery_Engine, Discovery_Bootstrap, Discovery_Processor and
		// Post_Type_Classifier. Without this write, the next staging-time
		// is_newer_version() check had to fall through to seogenherodata or the
		// post title to see the new version.
		if ( ! empty( $hero_data['version'] ) ) {
			self::write_meta( $post_id, '_seo_gen_version', (string) $hero_data['version'] );
		}

		// [SSOT-FIX Finding 8] Title-parsed version override REMOVED. The live post title
		// is the AI-generated title from the latest finalization — using it to overwrite
		// _seo_gen_version creates a circular dependency where the title becomes the
		// source of truth for the schema's version. Title_Analyzer-based staging
		// comparisons belong in Discovery_Processor's is_newer_version() gate, which
		// compares the SOURCE (staging draft) title vs the EXISTING (live) title —
		// never the AI-generated title we just wrote.

		// @FIX: Set Cloudflare bypass transient so the first visitor after save
		// sees fresh content. write_hero_data() sets this but save_schema() writes
		// hero data directly, bypassing write_hero_data(). Without this, the
		// maybe_bypass_cache_for_hero_posts() filter has no flag to consume.
		if (\function_exists('\get_post_status') && \get_post_status($post_id) === 'publish') {
			\set_transient('seo_gen_hero_dirty_' . $post_id, 1, 60);
		}

            // [PLATFORM PARITY] Sync flat meta keys for legacy/UI compatibility.
            if (!empty($hero_data)) {
                self::write_meta($post_id, '_seo_gen_download_url', $hero_data['download_url'] ?? '');
                self::write_meta($post_id, '_seo_gen_file_size',    $hero_data['file_size'] ?? '');
                self::write_meta($post_id, '_seo_gen_license',      $hero_data['license'] ?? '');
                self::write_meta($post_id, '_seo_gen_developer',    $hero_data['developer'] ?? '');
            }

            // 4. Seed ratings only when snapshot is new — not on every save.
            if ($snapshot_changed && \class_exists('SEO_Article_Generator\\Frontend\\Rating_System')) {
                \SEO_Article_Generator\Frontend\Rating_System::maybe_seed_ratings($post_id);
            }

            // 5. Sync to Rank Math native schema meta only when snapshot changed.
            //    write_software_schema() calls get_permalink() which is slow in XAMPP.
            after_hero_data:
            \SEO_Article_Generator\Generator\Download_Link_Helper::trace_links('hero_save:' . $post_id, $schema->download_section['links'], (array) ($hero_data['download_links'] ?? array()));
            if (class_exists('\\SEO_Article_Generator\\Plugin')) {
                \SEO_Article_Generator\Plugin::get_instance()->invalidate_hero_data_cache($post_id);
            }
            // Rebuild even on unchanged snapshot: the hero may just have been repaired.
            if (class_exists('\\SEO_Article_Generator\\Integration\\Rank_Math_Schema_Handler')) {
                \SEO_Article_Generator\Integration\Rank_Math_Schema_Handler::write_software_schema($post_id);
            }

        } finally {
            self::$is_saving = false;
        }
    }

    /**
     * Apply hero overrides and regenerate hero view.
     *
     * @MODIFIED 2025-12-30 v2.8.5: Also syncs factual data back to Article_Schema snapshot.
     * @MODIFIED 2026-05-23: Preserve download_links in persistent storage for manual edits.
     *
     * @param int $post_id WordPress post ID.
     * @param array $overrides Hero presentation and factual overrides.
     * @return bool True on success, false if no schema exists.
     */
    /** Per-post guard includes wp_update_post/save_post re-entry, not just metadata saves. */
    private static array $manual_saves = array();

    public static function apply_hero_overrides(int $post_id, array $overrides): bool
    {
        if (isset(self::$manual_saves[$post_id])) return true;
        self::$manual_saves[$post_id] = true;
        try {
            return self::apply_accepted_hero_edit($post_id, $overrides);
        } finally {
            unset(self::$manual_saves[$post_id]);
        }
    }

    private static function apply_accepted_hero_edit(int $post_id, array $overrides): bool
    {
        $schema = self::load_schema($post_id);
        if ($schema === null) return false;
        $has_links = array_key_exists('download_links', $overrides);
        if ($has_links && !is_array($overrides['download_links'])) return false;
        if ($has_links) {
            foreach ($overrides['download_links'] as $row) {
                if (!is_array($row) || !is_string($row['url'] ?? null)) return false;
                foreach (array('text','platform','variant','file_type','version','channel','is_primary','_manual_variant') as $field) {
                    if (isset($row[$field]) && !is_scalar($row[$field])) return false;
                }
            }
        }
        $previous = (array)($schema->download_section['links'] ?? array());
        if (isset($overrides['_download_revision']) && !hash_equals(\SEO_Article_Generator\Generator\Download_Link_Helper::manual_revision($previous), (string)$overrides['_download_revision'])) return false;
        unset($overrides['_download_revision']);
        $rows = $overrides['download_links'] ?? array();
        unset($overrides['download_links']);
        $helper = \SEO_Article_Generator\Generator\Download_Link_Helper::class;
        $changed = false;
        if ($has_links) {
            $submitted = $helper::prepare_manual_links($rows,$previous);
            $normalized = $helper::normalize_links($submitted, 'Other', (string)$schema->tech_specs->homepage,
                (string)$schema->tech_specs->software_name, (string)$schema->tech_specs->changelogurl);
            // Invalid nonblank submitted rows are not accepted as implicit deletions.
            $wanted = array_unique(array_column($submitted,'url'));
            if (array_diff($wanted, array_column($normalized,'url'))) return false;
            $changed = $normalized !== $previous;
            $schema->download_section['links'] = $normalized;
        }
        $schema->apply_hero_overrides($overrides);
        if ($changed) {
            $schema->sync_platforms();
            $old_content = (string)\get_post_field('post_content', $post_id, 'raw');
            $patch = \SEO_Article_Generator\Generator\Download_Content::replace($old_content, $schema);
            // Fail closed before changing canonical/derived metadata. Never rewrite arbitrary body HTML.
            if (!$patch['ok']) return false;
            if ($patch['content'] !== $old_content) {
                $written = \wp_update_post(\wp_slash(array('ID'=>$post_id, 'post_content'=>$patch['content'])), true);
                if (\is_wp_error($written) || !$written) return false;
                if ((string)\get_post_field('post_content',$post_id,'raw') !== $patch['content']) {
                    // A save filter changed the payload. Do not commit mismatched hero/schema state.
                    // Restore best-effort through WP, keeping the same re-entry guard active.
                    \wp_update_post(\wp_slash(array('ID'=>$post_id,'post_content'=>$old_content)), true);
                    if ((string)\get_post_field('post_content',$post_id,'raw') !== $old_content) {
                        error_log('Download edit rollback requires inspection for post ' . $post_id);
                    }
                    return false;
                }
            }
            $schema->html_content = $patch['content'];
            $state = \get_post_meta($post_id, '_seo_gen_download_edits', true);
            $removed = is_array($state) ? (array)($state['removed_urls'] ?? array()) : array();
            $now = array_column($schema->download_section['links'],'url');
            $removed = array_values(array_diff(array_unique(array_merge($removed,
                array_diff(array_column($previous,'url'),$now))),$now));
            self::write_meta($post_id, '_seo_gen_download_edits', array('removed_urls'=>$removed, 'explicit_empty'=>!$now));
            self::write_meta($post_id, '_seo_gen_hero_download_links', $schema->download_section['links']);
        }
        foreach (array('version','last_updated','last_verified_date') as $field) unset($overrides[$field]);
        self::write_meta($post_id, self::META_HERO_OVERRIDES, $overrides);
        self::save_schema($post_id, $schema, $overrides);
        return true;
    }

    /**
     * Check if a post has a valid schema snapshot.
     *
     * @param int $post_id WordPress post ID.
     * @return bool True if schema exists.
     */
    public static function has_schema(int $post_id): bool
    {
        $snapshot = get_post_meta($post_id, self::META_SNAPSHOT, true);
        return !empty($snapshot) && is_array($snapshot);
    }

    /**
     * Get schema modification timestamp.
     *
     * @param int $post_id WordPress post ID.
     * @return int|null Unix timestamp or null if not set.
     */
    public static function get_schema_modified(int $post_id): ?int
    {
        $timestamp = get_post_meta($post_id, self::META_SCHEMA_MODIFIED, true);
        return $timestamp ? (int) $timestamp : null;
    }

    /**
     * Cache get_permalink() per post_id for the lifetime of the request.
     * Eliminates repeated rewrite-rule resolution in XAMPP.
     */
    public static function get_cached_permalink(int $post_id): string
    {
        if (!isset(self::$permalink_cache[$post_id])) {
            $p = \get_permalink($post_id);
            self::$permalink_cache[$post_id] = $p ?: '';
        }
        return self::$permalink_cache[$post_id];
    }

    /**
     * Invalidate the permalink cache for a post.
     * Clears WP's internal rewrite cache and our local cache.
     *
     * @param int $post_id
     * @return void
     */
    public static function invalidate_permalink_cache(int $post_id): void
    {
        unset(self::$permalink_cache[$post_id]);
        // Force WP to refresh the post's permalink
        \clean_post_cache($post_id);
    }
}
