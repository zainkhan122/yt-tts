<?php

/**
 * Safety Data DTO
 *
 * @package SEO_Article_Generator
 */

namespace SEO_Article_Generator\Schema;

use SEO_Article_Generator\Traits\Type_Safety;

// Prevent direct access.
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Value Object for Safety & Trust Signals.
 */
class Safety_Data
{
    use Type_Safety;

    /** @var bool */
    public $verified_download = false;

    /** @var string */
    public $file_hash = '';

    /** @var array */
    public $scanned_by = array();

    /**
     * Create from array with defaults.
     *
     * @param array $data Input array.
     * @return self
     */
    public static function from_array($data = array())
    {
        $instance = new self();
        $data = (array) $data;

        // Handle various true/false inputs
        $instance->verified_download = !empty($data['verified_download']);

        $instance->file_hash = isset($data['file_hash']) ? self::as_string($data['file_hash']) : '';

        if (isset($data['scanned_by'])) {
            if (is_array($data['scanned_by'])) {
                $instance->scanned_by = $data['scanned_by'];
            } elseif (is_string($data['scanned_by']) && !empty($data['scanned_by'])) {
                $instance->scanned_by = array($data['scanned_by']);
            }
        }

        return $instance;
    }

    /**
     * Convert to array.
     *
     * @return array
     */
    public function to_array()
    {
        return get_object_vars($this);
    }
}
