#!/usr/bin/env python3
"""HTML composition fingerprints for visual diversity."""
from __future__ import annotations
import re
from pathlib import Path

S01 = Path("/home/user/videos/short_s01_hf/living-death/index.html")
S02 = Path("/home/user/videos/short_s02/index.html")
GENERIC = {
    "phone_bubble", "thread_reply", "calendar_stamp", "ghost_motes",
    "split_words", "plates", "door_soul", "ecg_stamp", "heart_pulse", "still_label",
}


def ids_from_html(text: str) -> set[str]:
    return {m for m in re.findall(r'\bid=["\']([^"\']+)["\']', text) if m not in {"root", "main", "vo"}}


def fingerprint(path: Path) -> set[str]:
    if not path.exists():
        return set()
    return ids_from_html(path.read_text(encoding="utf-8", errors="ignore"))


def fonts_from_html(text: str) -> set[str]:
    fams = set()
    for m in re.findall(r"font-family:\s*([^;]+)", text, re.I):
        parts = re.split(r",", m)
        if parts:
            fams.add(re.sub(r"[\"']", "", parts[0]).strip().lower())
    return {f for f in fams if f and f not in {"sans-serif", "serif", "monospace", "system-ui"}}


def jaccard(a: set[str], b: set[str]) -> float:
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def banned_sets() -> dict[str, set[str]]:
    return {"s01": fingerprint(S01), "s02": fingerprint(S02)}
