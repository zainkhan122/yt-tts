<?php

/**
 * Source Provider Interface
 *
 * @package DIT_TrendStudio
 * @MODIFIED 2025-12-13 - New file for sourcing layer
 */

namespace DIT\TrendStudio\Sources;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Interface for content source providers (RSS, Pinterest, etc.)
 */
interface Source_Provider
{
    /**
     * Get provider name
     *
     * @return string
     */
    public function get_name(): string;

    /**
     * Get provider type identifier
     *
     * @return string
     */
    public function get_type(): string;

    /**
     * Check if provider is available/configured
     *
     * @return bool
     */
    public function is_available(): bool;

    /**
     * Fetch ideas from this provider
     *
     * @param array $params Provider-specific parameters
     * @return Idea_DTO[] Array of idea DTOs
     * @throws \DIT\TrendStudio\Source_Exception On fetch failure
     */
    public function fetch_ideas(array $params = array()): array;
}
