<?php
// FILE: includes/content/class-deterministic-section-renderer.php

namespace SEO_Article_Generator\Content;

defined('ABSPATH') || exit;

final class Deterministic_Section_Renderer
{
    public static function render(string $section, array $data): string
    {
        switch ($section) {
            case 'tech_specs':
                return self::render_tech_specs((array) ($data['tech_specs'] ?? array()));
            case 'download':
                return self::render_download((array) ($data['download_section'] ?? array()));
            default:
                return '';
        }
    }

    public static function render_tech_specs(array $specs): string
    {
        if (empty($specs)) {
            return '';
        }

        $label_map = array(
            'software_name' => 'Software',
            'version' => 'Version',
            'developer' => 'Developer',
            'license' => 'License',
            'file_size' => 'File Size',
            'homepage' => 'Homepage',
            'last_updated' => 'Last Updated',
            'os_support' => 'OS Support',
        );

        $rows = '';
        foreach ($label_map as $key => $label) {
            $value = $specs[$key] ?? '';
            if ($value === '' || $value === null) {
                continue;
            }

            if ($key === 'homepage' && filter_var((string) $value, FILTER_VALIDATE_URL)) {
                $value_html = '<a href="' . esc_url((string) $value) . '" rel="nofollow noopener" target="_blank">' . esc_html((string) $value) . '</a>';
            } else {
                $value_html = esc_html((string) $value);
            }

            $rows .= '<tr><th>' . esc_html($label) . '</th><td>' . $value_html . '</td></tr>';
        }

        if ($rows === '') {
            return '';
        }

        return implode("\n", array(
            '<!-- seo-gen-zone:tech_specs -->',
            '<!-- wp:group {"layout":{"type":"constrained"}} -->',
            '<div class="wp-block-group" data-seo-gen-zone="tech_specs">',
            '<h2 id="technical-specifications">Technical Specifications</h2>',
            '<div class="seo-gen-specs-table">',
            '<table><tbody>',
            $rows,
            '</tbody></table>',
            '</div>',
            '</div>',
            '<!-- /wp:group -->',
        ));
    }

    public static function render_download(array $download): string
    {
        $links = (array) ($download['links'] ?? array());
        if (empty($links)) {
            return '';
        }

        $items = '';
        foreach ($links as $link) {
            $url = (string) ($link['url'] ?? '');
            if ($url === '') {
                continue;
            }

            $heading = trim((string) ($download['heading'] ?? ''));
            $sw_name = preg_replace( '/^Download\s+/i', '', $heading );
            if ( class_exists( '\\SEO_Article_Generator\\Generator\\Download_Link_Helper' ) ) {
                $label = \SEO_Article_Generator\Generator\Download_Link_Helper::format_download_text( $link, $sw_name, (string) ( $link['text'] ?? '' ) );
            } else {
                $label = (string) ( $link['text'] ?? 'Download' );
            }
            if ( $label === '' ) {
                $label = 'Download';
            }
            $platform = trim((string) ($link['platform'] ?? ''));
            $variant = trim((string) ($link['variant'] ?? ''));

            $meta = array_filter(array($platform, $variant), static function ($v) {
                return $v !== '';
            });

            $meta_html = '';
            if (! empty($meta)) {
                $meta_html = '<span class="seo-gen-download-meta">' . esc_html(implode(' · ', $meta)) . '</span>';
            }

            $items .= '<li class="seo-gen-download-item">';
            $items .= '<a class="seo-gen-download-button" href="' . esc_url($url) . '" rel="nofollow noopener" target="_blank">' . esc_html($label) . '</a>';
            $items .= $meta_html;
            $items .= '</li>';
        }

        if ($items === '') {
            return '';
        }

        $os_support = trim((string) ($download['os_support'] ?? ''));

        return implode("\n", array(
            '<!-- seo-gen-zone:download -->',
            '<!-- wp:group {"layout":{"type":"constrained"}} -->',
            '<div class="wp-block-group seo-gen-download-portal" data-seo-gen-zone="download">',
            '<h2>Download</h2>',
            $os_support !== '' ? '<p class="seo-gen-download-os">Supported platforms: ' . esc_html($os_support) . '</p>' : '',
            '<ul class="seo-gen-download-list">',
            $items,
            '</ul>',
            '</div>',
            '<!-- /wp:group -->',
        ));
    }
}
