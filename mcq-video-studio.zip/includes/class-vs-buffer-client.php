<?php

/**
 * Buffer API Client
 *
 * Handles publishing videos to Social Media via Buffer.
 * Uses Buffer GraphQL API exclusively (v2).
 *
 * @package MCQ_Video_Studio
 * @subpackage Includes
 * @since 1.0.0
 */

if (! defined('ABSPATH')) {
    exit;
}

/**
 * Class VS_Buffer_Client
 *
 * Buffer GraphQL API integration.
 *
 * @since 1.0.0
 */
class VS_Buffer_Client
{

    private $access_token;
    private $api_url = 'https://api.buffer.com';
    private $account_id = '';

    public function __construct($access_token = '', $account_id = '')
    {
        $this->account_id = is_string($account_id) ? sanitize_key($account_id) : '';
        if ($this->account_id !== '') {
            $token = VS_Buffer_Account_Registry::get_token($this->account_id);
            $this->access_token = $token !== '' ? $token : ($access_token ? $access_token : get_option('mcqvs_buffer_access_token', ''));
        } else {
            $this->access_token = $access_token ? $access_token : get_option('mcqvs_buffer_access_token', '');
        }
    }

    public function get_account_id()
    {
        return $this->account_id;
    }

    private function org_id_option_key()
    {
        return $this->account_id !== '' ? 'mcqvs_buffer_account_' . $this->account_id . '_org_id' : 'mcqvs_buffer_org_id';
    }

    private function channels_data_option_key()
    {
        return $this->account_id !== '' ? 'mcqvs_buffer_account_' . $this->account_id . '_channels_data' : 'mcqvs_buffer_channels_data';
    }

    private function channel_ids_option_key()
    {
        return $this->account_id !== '' ? 'mcqvs_buffer_account_' . $this->account_id . '_channel_ids' : 'mcqvs_buffer_channels';
    }

    /**
     * Escape a PHP scalar for safe interpolation as a GraphQL string literal.
     *
     * @param mixed $value Scalar (will be cast to string).
     * @return string Quoted, escaped scalar ready to be placed in `text: "...", etc.`
     */
    public static function escape_graphql_string($value)
    {
        if ($value === null || $value === false) {
            return '""';
        }
        $s = (string) $value;
        $escaped = str_replace(
            array('\\',    '"',     "\n",    "\r",    "\t",    "\f",    "\b"),
            array('\\\\', '\\"',  '\\n',  '\\r',  '\\t',  '\\f',  '\\b'),
            $s
        );
        $escaped = preg_replace_callback(
            '/[\x00-\x1F]/u',
            static function ($m) {
                return '\\u' . str_pad(strtoupper(dechex(ord($m[0]))), 4, '0', STR_PAD_LEFT);
            },
            $escaped
        );
        return '"' . $escaped . '"';
    }

    /**
     * Execute a raw GraphQL query against the Buffer API.
     *
     * @param string $query GraphQL document.
     * @param array  $variables Optional variables.
     * @param int    $timeout   HTTP timeout in seconds.
     * @return array|WP_Error Decoded response body or WP_Error.
     */
    private function graphql($query, $variables = array(), $timeout = 15)
    {
        $payload = array('query' => $query);
        if (! empty($variables)) {
            $payload['variables'] = $variables;
        }

        $start_time = microtime(true);
        $response = wp_remote_post(
            $this->api_url,
            array(
                'headers' => array(
                    'Content-Type'  => 'application/json',
                    'Authorization' => 'Bearer ' . $this->access_token,
                ),
                'body'    => wp_json_encode($payload),
                'timeout' => $timeout,
            )
        );
        $duration = microtime(true) - $start_time;

        VS_Error_Logger::get_instance()->log_api($this->api_url, 'POST', array('query' => substr($query, 0, 200)), $response, $duration, 'buffer');

        if (is_wp_error($response)) {
            VS_Error_Logger::get_instance()->log('Buffer GraphQL HTTP Error', 'error', array('error' => $response->get_error_message()));
            return $response;
        }

        $raw = wp_remote_retrieve_body($response);
        $body = json_decode($raw, true);

        if (! is_array($body)) {
            VS_Error_Logger::get_instance()->log('Buffer GraphQL: Malformed JSON response', 'error', array('raw' => $raw));
            return new WP_Error('buffer_malformed_response', 'Buffer API returned an invalid response.');
        }

        return $body;
    }

    /**
     * Get the first organization ID for the authenticated account.
     *
     * @return string|WP_Error Organization ID string or WP_Error.
     */
    private function get_first_organization_id()
    {
        // @FIX 2026-07-31: Persist the org id in an option — the org is stable per
        //       account and never needs re-resolving on every push. Only
        //       clear_channels_cache() (manual refresh / token change) resets it.
        // @FIX 2026-08-01 (multi-account): Cache key is scoped per Buffer account so
        //       two accounts never clobber each other's org id.
        $cache_key = $this->org_id_option_key();
        $cached_org = get_option($cache_key, '');
        if (!empty($cached_org)) {
            return $cached_org;
        }

        $query = 'query GetOrganizations {
  account {
    organizations {
      id
      name
    }
  }
}';

        $body = $this->graphql($query);

        if (is_wp_error($body)) {
            return $body;
        }

        if (isset($body['errors'])) {
            $msgs = wp_list_pluck($body['errors'], 'message');
            return new WP_Error('buffer_org_errors', implode('; ', $msgs));
        }

        $orgs = $body['data']['account']['organizations'] ?? null;
        if (empty($orgs) || ! is_array($orgs)) {
            return new WP_Error('buffer_no_orgs', 'No organizations found for this Buffer account.');
        }

        update_option($cache_key, $orgs[0]['id'], false);

        return $orgs[0]['id'];
    }

    /**
     * Get all organization IDs for the current account (cached per account).
     *
     * Used as a fallback when the first organization has no channels, because a
     * Buffer account can hold multiple organizations with channels split between them.
     *
     * @return array|WP_Error List of org ID strings or WP_Error.
     */
    private function get_all_organization_ids()
    {
        $cache_key = $this->org_id_option_key() . '_all';
        $cached = get_option($cache_key, '');
        $ids = is_string($cached) ? json_decode($cached, true) : $cached;
        if (is_array($ids) && !empty($ids)) {
            return $ids;
        }

        $query = 'query GetOrganizations {
  account {
    organizations {
      id
      name
    }
  }
}';

        $body = $this->graphql($query);

        if (is_wp_error($body)) {
            return $body;
        }

        if (isset($body['errors'])) {
            $msgs = wp_list_pluck($body['errors'], 'message');
            return new WP_Error('buffer_org_errors', implode('; ', $msgs));
        }

        $orgs = $body['data']['account']['organizations'] ?? null;
        if (empty($orgs) || ! is_array($orgs)) {
            return array();
        }

        $ids = array();
        foreach ($orgs as $org) {
            if (!empty($org['id'])) {
                $ids[] = $org['id'];
            }
        }

        update_option($cache_key, wp_json_encode($ids), false);

        return $ids;
    }

    /**
     * Get connected channels via GraphQL.
     *
     * @param string $organization_id Optional. Uses first org if omitted.
     * @return array|WP_Error Array of channel objects or WP_Error.
     */
    public function get_channels($organization_id = '')
    {
        if (empty($this->access_token)) {
            VS_Error_Logger::get_instance()->log('Buffer Client: Missing Token', 'error');
            return new WP_Error('missing_token', 'Buffer Access Token is missing.');
        }

        if (empty($organization_id)) {
            $organization_id = $this->get_first_organization_id();
            if (is_wp_error($organization_id)) {
                return $organization_id;
            }
        }

        $channels = $this->query_channels_for_org($organization_id);
        if (is_wp_error($channels)) {
            return $channels;
        }

        // @FIX 2026-08-08: A multi-organization Buffer account may keep its channels
        // under a non-first org. Before declaring "0 channels", probe the other orgs.
        if (empty($channels)) {
            $all_orgs = $this->get_all_organization_ids();
            if (is_array($all_orgs)) {
                foreach ($all_orgs as $oid) {
                    if ($oid === $organization_id) {
                        continue;
                    }
                    $alt = $this->query_channels_for_org($oid);
                    if (is_array($alt) && !empty($alt)) {
                        return $alt;
                    }
                }
            }
        }

        return $channels;
    }

    /**
     * Run the GetChannels GraphQL query for a single organization.
     *
     * @param string $organization_id
     * @return array|WP_Error
     */
    private function query_channels_for_org($organization_id)
    {
        $org_id_escaped = self::escape_graphql_string($organization_id);

        $query = 'query GetChannels {
  channels(input: { organizationId: ' . $org_id_escaped . ' }) {
    id
    name
    displayName
    service
    avatar
    isQueuePaused
  }
}';

        $body = $this->graphql($query);

        if (is_wp_error($body)) {
            return $body;
        }

        if (isset($body['errors'])) {
            $msgs = wp_list_pluck($body['errors'], 'message');
            return new WP_Error('buffer_channel_errors', implode('; ', $msgs));
        }

        $channels = $body['data']['channels'] ?? null;
        if (! is_array($channels)) {
            return new WP_Error('buffer_no_channels', 'No channels found for this organization.');
        }

        return $channels;
    }

    /**
     * Get channels with persistent caching (option-backed).
     *
     * @FIX 2026-07-31: Was a 1-hour transient, so a low-volume publisher re-fetched
     *       GetOrganizations + GetChannels on every push. Channels change rarely;
     *       the option is only re-fetched when missing or after an explicit
     *       clear_channels_cache() (manual "Refresh channels" / token change).
     *
     * @return array|WP_Error
     */
    public function get_channels_cached()
    {
        // @FIX 2026-08-01 (multi-account): Cache is scoped per Buffer account.
        $data_key = $this->channels_data_option_key();
        $ids_key  = $this->channel_ids_option_key();

        $cached = get_option($data_key, '');
        $channels = is_string($cached) ? json_decode($cached, true) : $cached;
        if (is_array($channels) && !empty($channels)) {
            return $channels;
        }

        $channels = $this->get_channels();
        if (! is_wp_error($channels)) {
            update_option($data_key, wp_json_encode($channels), false);
            $ids = array();
            foreach ($channels as $ch) {
                if (!empty($ch['id'])) {
                    $ids[] = $ch['id'];
                }
            }
            update_option($ids_key, wp_json_encode($ids), false);
        }

        return $channels;
    }

    /**
     * Clear the persistent channel/org cache.
     *
     * Keeps mcqvs_buffer_channels (the user's saved default channel selection)
     * intact — the refresh action rewrites it on success.
     *
     * @FIX 2026-08-01 (multi-account): Accepts an optional $account_id. With no arg,
     *       clears legacy default-account cache plus every registered account's
     *       cache. With an account id, only that account's cache is purged.
     *
     * @param string $account_id Optional Buffer account id ('' = clear all).
     * @return void
     */
    public static function clear_channels_cache($account_id = '')
    {
        if ($account_id !== '') {
            $aid = sanitize_key($account_id);
            delete_transient('mcqvs_buffer_channels');
            delete_option('mcqvs_buffer_account_' . $aid . '_org_id');
            delete_option('mcqvs_buffer_account_' . $aid . '_org_id_all');
            delete_option('mcqvs_buffer_account_' . $aid . '_channels_data');
            return;
        }

        delete_transient('mcqvs_buffer_channels');
        delete_option('mcqvs_buffer_org_id');
        delete_option('mcqvs_buffer_org_id_all');
        delete_option('mcqvs_buffer_channels_data');

        // Multi-account: purge every registered account's per-account cache so a
        // global "Refresh all" / token rotation truly clears every account.
        $accounts = VS_Buffer_Account_Registry::get_accounts();
        if (is_array($accounts)) {
            foreach (array_keys($accounts) as $aid) {
                delete_option('mcqvs_buffer_account_' . $aid . '_org_id');
                delete_option('mcqvs_buffer_account_' . $aid . '_org_id_all');
                delete_option('mcqvs_buffer_account_' . $aid . '_channels_data');
            }
        }
    }

    /**
     * Get connected profiles (backward-compatible public method).
     *
     * @return array|WP_Error
     */
    public function get_profiles()
    {
        return $this->get_channels();
    }

    /**
     * Get valid post types per service.
     *
     * @FIX 2026-08-10: Threads does NOT support stories on Buffer — only
     * regular posts. The previous `array('post', 'story')` let the settings
     * UI offer a "story" post type that Buffer would reject. Threads is now
     * correctly limited to `post`. Stories remain Facebook + Instagram only.
     *
     * @return array
     */
    public static function get_valid_post_types()
    {
        return array(
            'facebook'  => array('post', 'story', 'reel'),
            'instagram' => array('post', 'story', 'reel'),
            'twitter'   => array('post'),
            'linkedin'  => array('post'),
            'pinterest' => array('post'),
            'youtube'   => array('post', 'video'),
            'threads'   => array('post'),
            'tiktok'    => array('post', 'video'),
            'mastodon'  => array('post'),
            'bluesky'   => array('post'),
            'google'    => array('post'),
        );
    }

    /**
     * @NEW 2026-08-10: Character limit per Buffer service for the post text field.
     *
     * Source: Buffer's published platform limits (publish.buffer.com profile
     * settings). YouTube's text limit applies to the description — the title
     * is bounded separately (see get_youtube_title_limit()).
     *
     * Values are conservative Buffer-side caps, not the absolute platform max.
     * Setting cap = 0 means "no effective limit".
     *
     * @return array<string,int>
     */
    public static function get_service_char_limits()
    {
        return array(
            'twitter'   => 280,    // X / Twitter hard limit
            'threads'   => 500,
            'bluesky'   => 300,
            'mastodon'  => 500,
            'pinterest' => 500,
            'linkedin'  => 3000,
            'instagram' => 2200,
            'facebook'  => 63206,
            'tiktok'    => 2200,
            'youtube'   => 5000,   // description
            'google'    => 1500,
        );
    }

    /**
     * @NEW 2026-08-10: Return the character cap for a single service.
     *
     * @param string $service Buffer service key (facebook, twitter, etc).
     * @return int 0 = no effective limit.
     */
    public static function get_service_char_limit($service)
    {
        $limits = self::get_service_char_limits();
        return isset($limits[$service]) ? (int) $limits[$service] : 0;
    }

    /**
     * @NEW 2026-08-11: Substitute caption/title placeholders.
     * Keys: {topic} {score} {total} {hook} {hashtags} {firstquestion} {link} {part} {part_total}.
     * Unknown placeholders are left untouched (so future templates don't break).
     *
     * @param string $template
     * @param array  $data Associative map of available values (missing = '').
     * @return string
     */
    public static function substitute_placeholders($template, $data = array())
    {
        if (!is_string($template) || $template === '') {
            return is_string($template) ? $template : '';
        }
        $data = is_array($data) ? $data : array();
        $get = function ($k) use ($data) {
            return isset($data[$k]) && $data[$k] !== '' ? (string) $data[$k] : '';
        };

        $keys = array('{topic}', '{score}', '{total}', '{hook}', '{hashtags}', '{firstquestion}', '{link}', '{part}', '{part_total}');
        $vals = array(
            $get('topic'), $get('score'), $get('total'), $get('hook'), $get('hashtags'),
            $get('firstquestion'), $get('link'), $get('part'), $get('part_total'),
        );

        $out = str_replace($keys, $vals, $template);
        $out = preg_replace('/\n{3,}/', "\n\n", $out);
        return trim($out);
    }

    /**
     * @NEW 2026-08-10: YouTube title character limit (separate from description).
     *
     * @return int
     */
    public static function get_youtube_title_limit()
    {
        return 100;
    }

    /**
     * @NEW 2026-08-10: Truncate a caption to fit a service's character limit.
     *
     * Truncation is whitespace-aware: we cut on the nearest word boundary and
     * append an ellipsis so the result reads naturally. If the caption already
     * fits (or there is no limit for this service), the original string is
     * returned untouched.
     *
     * Special sentinels:
     *  - '__youtube_title__' uses the YouTube title cap (100 chars).
     *
     * @param string $caption
     * @param string $service
     * @return string
     */
    public static function truncate_caption_for_service($caption, $service)
    {
        if (!is_string($caption)) {
            return '';
        }
        if ($service === '__youtube_title__') {
            $limit = self::get_youtube_title_limit();
        } else {
            $limit = self::get_service_char_limit($service);
        }
        if ($limit <= 0) {
            return $caption;
        }
        // Operate on the visible char count, not bytes — Buffer counts chars.
        if (function_exists('mb_strlen') && function_exists('mb_substr')) {
            if (mb_strlen($caption, 'UTF-8') <= $limit) {
                return $caption;
            }
            // Reserve 1 char for the ellipsis so the final string fits.
            $cut = mb_substr($caption, 0, max(1, $limit - 1), 'UTF-8');
            // Snap to the last whitespace inside the cut so we don't slice mid-word.
            $last_space = mb_strrpos($cut, ' ', 0, 'UTF-8');
            if ($last_space !== false && $last_space > max(1, $limit / 2)) {
                $cut = mb_substr($cut, 0, $last_space, 'UTF-8');
            }
            return rtrim($cut) . '…';
        }
        if (strlen($caption) <= $limit) {
            return $caption;
        }
        $cut = substr($caption, 0, max(1, $limit - 1));
        $last_space = strrpos($cut, ' ');
        if ($last_space !== false && $last_space > max(1, $limit / 2)) {
            $cut = substr($cut, 0, $last_space);
        }
        return rtrim($cut) . '...';
    }

    /**
     * Create social posts via a single aliased GraphQL mutation.
     *
     * Buffer's API limits are per HTTP request (e.g. Free: 100/15min, 250/24h, 3,000/30d)
     * and the schema allows up to 30 aliases per query, so all channels are pushed in
     * ONE request instead of one request per channel.
     *
     * @param array  $channel_ids Array of Buffer channel IDs.
     * @param string $text        Post caption.
     * @param string $video_url   Public URL of the video.
     * @param string $scheduled_at ISO8601 datetime for scheduled posting (empty = addToQueue).
     * @param array  $options     Optional: scheduling_mode, channel_types, link_posts.
     * @return array|WP_Error
     */
    public function create_update($channel_ids, $text, $video_url, $scheduled_at = '', $options = array())
    {
        if (empty($this->access_token)) {
            VS_Error_Logger::get_instance()->log('Buffer Client: Missing Token for Update', 'error');
            return new WP_Error('missing_token', 'Buffer Access Token is missing.');
        }

        if (empty($channel_ids) || !is_array($channel_ids)) {
            return new WP_Error('missing_channels', 'No channel IDs provided.');
        }

        $scheduling_mode = $options['scheduling_mode'] ?? 'addToQueue';
        $channel_types   = $options['channel_types'] ?? array();
        $link_posts      = $options['link_posts'] ?? array();
        $channel_data    = $options['channel_data'] ?? array();
        // @FIX 2026-08-08 (YouTube): Buffer requires title + categoryId on create for
        // YouTube posts. These are per-account (or job) config, applied to every
        // youtube channel in this batch.
        $youtube_title    = $options['youtube_title'] ?? '';
        $youtube_category = $options['youtube_category'] ?? '27';
        // @NEW 2026-08-10: Per-channel caption + post-to-story overrides.
        // `$channel_captions` is keyed by channel_id; `$channel_post_to_story`
        // is keyed by channel_id => bool. Missing keys fall back to the global
        // caption / post_type dropdown.
        $channel_captions       = isset($options['channel_captions']) && is_array($options['channel_captions']) ? $options['channel_captions'] : array();
        $channel_post_to_story  = isset($options['channel_post_to_story']) && is_array($options['channel_post_to_story']) ? $options['channel_post_to_story'] : array();

        $channels = array();
        $rejected  = array();
        foreach ($channel_ids as $channel_id) {
            $channel_id = sanitize_text_field(trim($channel_id));
            if (empty($channel_id)) {
                continue;
            }
            if (!self::is_valid_channel_id($channel_id)) {
                $rejected[] = $channel_id;
                continue;
            }
            $service = $channel_data[$channel_id]['service'] ?? '';
            // @NEW 2026-08-10: Resolve the caption for THIS channel. Per-channel
            // template takes priority; fall back to the global caption, then
            // truncate to the service's character limit so Buffer never rejects
            // a Twitter/X post with "cannot exceed 280 characters" again.
            $channel_text = $text;
            if (!empty($channel_captions[$channel_id]) && is_string($channel_captions[$channel_id])) {
                $channel_text = $channel_captions[$channel_id];
            }
            $channel_text = self::truncate_caption_for_service($channel_text, $service);

            // @NEW 2026-08-10: Resolve the post type. An explicit "post to stories"
            // tick on a story-capable service forces post_type=story; otherwise
            // the existing channel_types dropdown decides.
            //
            // @FIX 2026-08-10: Threads does NOT support stories on Buffer. Only
            // Facebook and Instagram can carry a "Story" post type. Forcing
            // post_type=story on a Threads channel would fail at the API with
            // an unknown-type rejection.
            //
            // @FIX 2026-08-13: If user explicitly turns OFF the story tick for a
            // channel but the dropdown is set to 'story', fall back to 'reel'
            // instead of posting as story. This prevents "Video must be no longer
            // than 1 minute" errors on Stories channels when user wants Reels.
            $post_type = $channel_types[$channel_id] ?? 'post';
            $story_services = array('facebook', 'instagram');

            // User explicitly turned OFF stories tick for this channel
            $stories_explicitly_off = isset($channel_post_to_story[$channel_id]) && !$channel_post_to_story[$channel_id];
            if ($stories_explicitly_off && in_array($service, $story_services, true) && $post_type === 'story') {
                $post_type = 'reel';
            }

            // User explicitly turned ON stories tick -> force Story
            if ($service !== '' && in_array($service, $story_services, true) && !empty($channel_post_to_story[$channel_id])) {
                $post_type = 'story';
            }

            // @NEW 2026-08-10: Per-channel YouTube overrides. Per-buffer-account
            // a YouTube channel is unique, so title + category stay at the
            // account level (passed in as $youtube_title / $youtube_category).
            // Apply the YouTube title cap (100 chars) before it reaches Buffer.
            $ch_yt_title = $youtube_title;
            $ch_yt_category = $youtube_category;
            if ($service === 'youtube') {
                $ch_yt_title = self::truncate_caption_for_service($ch_yt_title, '__youtube_title__');
            }

            $channels[] = array(
                'id'              => $channel_id,
                'service'         => $service,
                'post_type'       => $post_type,
                'link_post'       => !empty($link_posts[$channel_id]),
                'scheduling_mode' => $scheduling_mode,
                'youtube_title'   => $ch_yt_title,
                'youtube_category'=> $ch_yt_category,
                // Carried forward so batch + per-channel fallback build uses the
                // resolved text instead of the global $text.
                'text'            => $channel_text,
            );
        }

        if (empty($channels)) {
            $detail = !empty($rejected) ? ' Invalid channel IDs: ' . implode(', ', array_slice($rejected, 0, 5)) : '';
            return new WP_Error('invalid_channels', 'No valid Buffer channel IDs provided.' . $detail);
        }

        if (!empty($rejected)) {
            VS_Error_Logger::get_instance()->log(
                'buffer.invalid_channel_ids_skipped',
                'warning',
                array('rejected' => $rejected, 'accepted' => count($channels))
            );
        }

        $batch = $this->create_post_batch_graphql($channels, $text, $video_url, $scheduled_at);

        if (is_wp_error($batch)) {
            // @FIX 2026-07-31: Fall back to per-channel mutations if Buffer's gateway
            //       rejects the aliased multi-mutation document or the request fails
            //       at transport level. Keeps the pre-batch behavior as a safety net.
            $errors  = array();
            $results = array();
            foreach ($channels as $ch) {
                // @NEW 2026-08-10: Honor the per-channel resolved text in the
                // fallback path too so a transport-level retry doesn't re-use the
                // global (potentially over-limit) caption.
                $ch_text = isset($ch['text']) && is_string($ch['text']) ? $ch['text'] : $text;
                $result = $this->create_post_graphql($ch['id'], $ch_text, $video_url, $scheduled_at, $ch);
                if (is_wp_error($result)) {
                    $errors[] = $result->get_error_message();
                } else {
                    $result['channel'] = $ch['id'];
                    $results[] = $result;
                }
            }
            if (!empty($errors) && empty($results)) {
                return new WP_Error('buffer_all_failed', 'All channel posts failed: ' . implode('; ', $errors));
            }
            return array(
                'success' => count($results),
                'failed'  => count($errors),
                'errors'  => $errors,
                'results' => $results,
            );
        }

        if (!empty($batch['errors']) && empty($batch['results'])) {
            return new WP_Error('buffer_all_failed', 'All channel posts failed: ' . implode('; ', $batch['errors']));
        }

        return $batch;
    }

    /**
     * Validate a Buffer channel ID.
     *
     * Buffer's `createPost` mutation expects `channelId: ChannelId`, which the
     * official docs define as "the MongoDB ObjectId of a Buffer Channel" — i.e.
     * a 24-character hexadecimal string. Placeholder strings such as
     * `buffer_channel_1` (which must never be persisted) fail this check and are
     * rejected by the API with "Invalid ChannelId format."
     *
     * @FIX 2026-08-06: Guard every path that sends a channel ID so garbage never
     *       reaches Buffer and we can fall back to the real configured channels.
     *
     * @param mixed $channel_id The candidate channel ID.
     * @return bool True if it looks like a valid Buffer ObjectId.
     */
    public static function is_valid_channel_id($channel_id)
    {
        if (!is_string($channel_id)) {
            return false;
        }
        $id = trim($channel_id);
        return (bool) preg_match('/^[0-9a-fA-F]{24}$/', $id);
    }

    /**
     * Return the currently saved/default channel IDs that pass the ObjectId check.
     *
     * Reads `mcqvs_buffer_enabled_channels` first, then falls back to the cached
     * full list in `mcqvs_buffer_channels`. Used by callers that need a real
     * default channel list instead of placeholder strings.
     *
     * @FIX 2026-08-06: Filters out legacy placeholder IDs that Buffer rejects.
     *
     * @return array Valid Buffer channel IDs.
     */
    public static function get_valid_saved_channel_ids()
    {
        $raw = get_option('mcqvs_buffer_enabled_channels', '');
        $candidates = is_string($raw) ? json_decode($raw, true) : $raw;
        if (!is_array($candidates) || empty($candidates)) {
            $raw = get_option('mcqvs_buffer_channels', '[]');
            $candidates = is_string($raw) ? json_decode($raw, true) : $raw;
        }
        if (!is_array($candidates)) {
            return array();
        }
        return array_values(array_filter($candidates, array('VS_Buffer_Client', 'is_valid_channel_id')));
    }

    /**
     * GraphQL: Create a single post for one channel (fallback path).
     *
     * @param string $channel_id   Buffer channel ID.
     * @param string $text         Post caption.
     * @param string $video_url    Public URL of the video.
     * @param string $scheduled_at ISO8601 datetime (empty = addToQueue).
     * @param array  $options      id, scheduling_mode, post_type, service, link_post.
     * @return array|WP_Error
     */
    private function create_post_graphql($channel_id, $text, $video_url, $scheduled_at = '', $options = array())
    {
        $query = 'mutation CreatePost {
  ' . $this->build_create_post_input($channel_id, $text, $video_url, $scheduled_at, $options) . '
}';

        $body = $this->graphql($query);

        if (is_wp_error($body)) {
            return $body;
        }

        if (isset($body['data']['createPost']['post'])) {
            return $body['data']['createPost'];
        }

        if (isset($body['data']['createPost']['message'])) {
            $err_msg = $body['data']['createPost']['message'];
            VS_Error_Logger::get_instance()->log('Buffer GraphQL MutationError', 'error', array('message' => $err_msg, 'channel' => $channel_id));
            return new WP_Error('buffer_graphql_error', $err_msg);
        }

        if (isset($body['errors'])) {
            $err_msgs = wp_list_pluck($body['errors'], 'message');
            VS_Error_Logger::get_instance()->log('Buffer GraphQL Errors', 'error', array('errors' => $err_msgs, 'channel' => $channel_id));
            return new WP_Error('buffer_graphql_errors', implode('; ', $err_msgs));
        }

        return new WP_Error('buffer_unknown', 'Unexpected response from Buffer API.');
    }

    /**
     * Build the GraphQL `createPost` call body (input + selection set) for one channel.
     *
     * @param string $channel_id   Buffer channel ID.
     * @param string $text         Post caption.
     * @param string $video_url    Public URL of the video.
     * @param string $scheduled_at ISO8601 datetime (empty = addToQueue).
     * @param array  $options      id, scheduling_mode, post_type, service, link_post.
     * @return string
     */
    private function build_create_post_input($channel_id, $text, $video_url, $scheduled_at = '', $options = array())
    {
        $scheduling_mode = $options['scheduling_mode'] ?? 'addToQueue';
        $post_type       = $options['post_type'] ?? 'post';
        $service         = $options['service'] ?? '';
        $link_post       = $options['link_post'] ?? false;

        $text_escaped       = self::escape_graphql_string($text);
        $video_url_escaped  = self::escape_graphql_string(esc_url($video_url));
        $channel_id_escaped = self::escape_graphql_string($channel_id);

        $mode = $scheduling_mode;
        $due_at_arg = '';

        if ($scheduling_mode === 'customScheduled') {
            if (!empty($scheduled_at)) {
                $due_at_arg = ', dueAt: ' . self::escape_graphql_string($scheduled_at);
            } else {
                $due_at = gmdate('Y-m-d\TH:i:s', time() + 300) . '.000Z';
                $due_at_arg = ', dueAt: ' . self::escape_graphql_string($due_at);
            }
        }

        $metadata_parts = array();

        if ($service === 'facebook' || $service === 'linkedin') {
            $meta_fields = array();
            // @FIX 2026-08-01: Buffer rejects Facebook posts whose `type` is not
            //       declared, even plain `post`. The old guard only emitted the type
            //       when it was NOT 'post', so selecting "Post" stripped the required
            //       field and produced "Facebook posts require a type (post, story, or reel)."
            //       Always declare the type for facebook; linkedin keeps prior behavior.
            if ($service === 'facebook' || $post_type !== 'post') {
                $meta_fields[] = 'type: ' . $post_type;
            }
            if ($link_post && !empty($video_url)) {
                $meta_fields[] = 'linkAttachment: { url: ' . self::escape_graphql_string(esc_url($video_url)) . ' }';
            }
            if (!empty($meta_fields)) {
                $metadata_parts[] = $service . ': { ' . implode(', ', $meta_fields) . ' }';
            }
        } elseif ($service === 'instagram') {
            $meta_fields = array('shouldShareToFeed: true');
            if ($post_type !== 'post') {
                $meta_fields[] = 'type: ' . $post_type;
            }
            $metadata_parts[] = 'instagram: { ' . implode(', ', $meta_fields) . ' }';
        } elseif ($service === 'threads') {
            if ($post_type !== 'post') {
                $metadata_parts[] = 'threads: { type: ' . $post_type . ' }';
            }
        } elseif ($service === 'youtube') {
            // @FIX 2026-08-08 (YouTube): Buffer requires title + categoryId on create
            // (YoutubePostMetadataInput). Without them Buffer rejects the post with
            // "YouTube posts require a title., YouTube posts require a category."
            $yt_title = $options['youtube_title'] ?? '';
            if ($yt_title === '') {
                $yt_title = 'Quiz Video';
            } else {
                // @NEW 2026-08-11: Actually substitute {topic}/{hook}/{hashtags}/… in the
                //       YouTube title (the Settings help text already advertised these).
                //       Prefer the shared placeholder data from the push pipeline.
                $yt_data = (isset($options['placeholder_data']) && is_array($options['placeholder_data']))
                    ? $options['placeholder_data']
                    : array(
                        'topic' => isset($options['topic_name']) ? $options['topic_name'] : 'Quiz Video',
                        'score' => '5', 'total' => '5',
                        'hook' => '', 'hashtags' => '', 'firstquestion' => '',
                        'link' => esc_url_raw(home_url('/')), 'part' => '', 'part_total' => '',
                    );
                $yt_title = self::substitute_placeholders($yt_title, $yt_data);
                if ($yt_title === '') {
                    $yt_title = 'Quiz Video';
                }
            }
            $yt_category = $options['youtube_category'] ?? '27';
            if (!preg_match('/^\d{1,2}$/', $yt_category)) {
                $yt_category = '27'; // Education
            }
            $metadata_parts[] = 'youtube: { title: ' . self::escape_graphql_string($yt_title) . ', categoryId: ' . self::escape_graphql_string($yt_category) . ' }';
        }

        $metadata_arg = '';
        if (!empty($metadata_parts)) {
            $metadata_arg = ', metadata: { ' . implode(', ', $metadata_parts) . ' }';
        }

        return 'createPost(input: {
    text: ' . $text_escaped . ',
    channelId: ' . $channel_id_escaped . ',
    schedulingType: automatic,
    mode: ' . $mode . $due_at_arg . ',
    assets: [{ video: { url: ' . $video_url_escaped . ' } }]' . $metadata_arg . '
  }) {
    ... on PostActionSuccess {
      post { id text dueAt }
    }
    ... on MutationError {
      message
    }
  }';
    }

    /**
     * GraphQL: Create posts for multiple channels in one aliased mutation.
     *
     * Buffer caps queries at 30 aliases, so channel lists are chunked at 30.
     * Each alias returns the same union as the single-post call, so results keep
     * the exact shape consumed by push_job_to_buffer() / mark_published().
     *
     * @param array  $channels Each entry: id, service, post_type, link_post, scheduling_mode.
     * @param string $text         Post caption.
     * @param string $video_url    Public URL of the video.
     * @param string $scheduled_at ISO8601 datetime (empty = addToQueue).
     * @return array|WP_Error
     */
    private function create_post_batch_graphql($channels, $text, $video_url, $scheduled_at = '')
    {
        $results = array();
        $errors  = array();

        foreach (array_chunk($channels, 30) as $chunk) {
            $alias_parts = array();
            foreach ($chunk as $i => $channel) {
                // @NEW 2026-08-10: Use the per-channel resolved text (already
                // truncated to the service's character limit by create_update()).
                // Fall back to the global $text when a channel entry is malformed.
                $ch_text = isset($channel['text']) && is_string($channel['text']) ? $channel['text'] : $text;
                $alias_parts[] = 'p' . $i . ': ' . $this->build_create_post_input($channel['id'], $ch_text, $video_url, $scheduled_at, $channel);
            }

            $query = 'mutation CreatePosts {
  ' . implode('
  ', $alias_parts) . '
}';

            // Aliased mutations execute serially server-side, so allow more time than
            // a single-post request (measured single posts: ~0.3-1.3s each).
            $body = $this->graphql($query, array(), 60);

            if (is_wp_error($body)) {
                return $body;
            }

            if (!isset($body['data']) || !is_array($body['data'])) {
                $err_msgs = isset($body['errors']) ? wp_list_pluck($body['errors'], 'message') : array('Unexpected response from Buffer API.');
                VS_Error_Logger::get_instance()->log('Buffer GraphQL Errors', 'error', array('errors' => $err_msgs, 'channels' => count($chunk)));
                return new WP_Error('buffer_graphql_errors', implode('; ', $err_msgs));
            }

            // Map top-level errors (path[0] = alias) for aliases that failed without a MutationError body.
            $alias_error_msgs = array();
            if (isset($body['errors']) && is_array($body['errors'])) {
                foreach ($body['errors'] as $te) {
                    $path = isset($te['path']) && is_array($te['path']) ? $te['path'] : array();
                    $alias = isset($path[0]) ? (string) $path[0] : '';
                    if ($alias !== '') {
                        $alias_error_msgs[$alias] = isset($te['message']) ? $te['message'] : 'GraphQL error';
                    }
                }
            }

            foreach ($chunk as $i => $channel) {
                $node = isset($body['data']['p' . $i]) ? $body['data']['p' . $i] : null;
                if (is_array($node) && isset($node['post'])) {
                    $results[] = array(
                        'post'    => $node['post'],
                        'channel' => $channel['id'],
                    );
                } elseif (is_array($node) && isset($node['message'])) {
                    $err_msg = $node['message'];
                    VS_Error_Logger::get_instance()->log('Buffer GraphQL MutationError', 'error', array('message' => $err_msg, 'channel' => $channel['id']));
                    $errors[] = $err_msg;
                } elseif (isset($alias_error_msgs['p' . $i])) {
                    $errors[] = $alias_error_msgs['p' . $i];
                } else {
                    $errors[] = 'Unexpected response for channel ' . $channel['id'];
                }
            }
        }

        return array(
            'success' => count($results),
            'failed'  => count($errors),
            'errors'  => $errors,
            'results' => $results,
        );
    }

    /**
     * Push a completed job to Buffer (shared cron + AJAX entry point).
     *
     * @FIX 2026-08-01 (multi-account): Fans out to all active Buffer accounts.
     *       Each account gets its own lock, token, channel list, daily limit,
     *       and per-account cache. Results are aggregated. If only the legacy
     *       default account exists, behavior is identical to the pre-multi code.
     *
     * @param string $job_id
     * @param string $video_url Public URL of the video.
     * @param array  $job       Full job row from VS_Job_Repository::get_job().
     * @return array|WP_Error
     */
    public static function push_job_to_buffer($job_id, $video_url, $job)
    {
        // @FIX 1.4.9.53 (global STOP): no new Buffer posts while stopped.
        // (Posts already sent to Buffer.com cannot be recalled — this only
        // prevents NEW scheduling/pushing.)
        if (function_exists('mcqvs_is_global_stopped') && mcqvs_is_global_stopped()) {
            return new WP_Error('global_stop', 'Buffer push skipped: global STOP is active. Resume from the dashboard to publish again.');
        }
        $accounts = VS_Buffer_Account_Registry::get_active_accounts();
        if (empty($accounts)) {
            // Legacy fallback: single default account path.
            return self::push_job_to_buffer_single($job_id, $video_url, $job, '', array());
        }

        // Per-job setting can restrict to a specific account.
        $settings = is_string($job['settings'] ?? '') ? json_decode($job['settings'], true) : ($job['settings'] ?? array());
        if (is_array($settings) && !empty($settings['buffer_account_id'])) {
            $target_id = $settings['buffer_account_id'];
            if (isset($accounts[$target_id])) {
                $accounts = array($target_id => $accounts[$target_id]);
            } else {
                return new WP_Error('no_such_account', "Buffer account '{$target_id}' not found or not active.");
            }
        }

        $aggregate_results = array(
            'success' => 0,
            'failed'  => 0,
            'errors'  => array(),
            'results' => array(),
            'skipped' => false,
            'reason'  => '',
            // @FIX 2026-08-08 (multi-account): Accumulate every account's published
            // channels + Buffer post ids so the job record reflects the UNION of all
            // enabled accounts, not just the last account that was pushed.
            'published_channels' => array(),
            'matched_post_ids'   => array(),
        );

        $first_account = true;
        foreach ($accounts as $account_id => $account) {
            // Each account gets its own lock to prevent double-push on same account.
            if (class_exists('VS_Job_Repository')) {
                $job_repo = VS_Job_Repository::init();
                $lock_key = 'mcqvs_job_lock_' . $job_id . '_' . $account_id;
                $locked = get_transient($lock_key);
                if ($locked) {
                    VS_Error_Logger::get_instance()->log("Buffer push: Job {$job_id} account {$account_id} is locked, skipping.", 'info', array('job_id' => $job_id, 'account_id' => $account_id));
                    $aggregate_results['errors'][] = "Account {$account_id}: locked";
                    $aggregate_results['failed']++;
                    continue;
                }
                set_transient($lock_key, 1, 60);
            }

            $result = self::push_job_to_buffer_single($job_id, $video_url, $job, $account_id, $account);

            // Release per-account lock.
            if (class_exists('VS_Job_Repository')) {
                $lock_key = 'mcqvs_job_lock_' . $job_id . '_' . $account_id;
                delete_transient($lock_key);
            }

            if (is_wp_error($result)) {
                $aggregate_results['errors'][] = "Account {$account_id}: " . $result->get_error_message();
                $aggregate_results['failed']++;
            } else {
                $aggregate_results['success'] += (int) ($result['success'] ?? 0);
                $aggregate_results['failed']  += (int) ($result['failed'] ?? 0);
                $aggregate_results['errors']  = array_merge($aggregate_results['errors'], $result['errors'] ?? array());
                if (!empty($result['results'])) {
                    $aggregate_results['results'] = array_merge($aggregate_results['results'], $result['results']);
                }
                if (!empty($result['published_channels'])) {
                    $aggregate_results['published_channels'] = array_merge($aggregate_results['published_channels'], $result['published_channels']);
                }
                if (!empty($result['matched_post_ids'])) {
                    $aggregate_results['matched_post_ids'] = array_merge($aggregate_results['matched_post_ids'], $result['matched_post_ids']);
                }
                if (!empty($result['skipped']) && $result['skipped'] === true) {
                    // Preserve skip reason from first account.
                    if ($first_account) {
                        $aggregate_results['skipped'] = true;
                        $aggregate_results['reason'] = $result['reason'] ?? 'skipped';
                    }
                }
            }
            $first_account = false;
        }

        // @FIX 2026-08-08 (multi-account): Mark the job published with the UNION of
        // channels/post ids across every account pushed. Each single-account call
        // marks its own snapshot; this final call records the full fan-out.
        if (class_exists('VS_Job_Repository') && !empty($aggregate_results['published_channels'])) {
            $job_repo = VS_Job_Repository::init();
            $job_repo->mark_published(
                $job_id,
                array_values(array_unique($aggregate_results['published_channels'])),
                array_values(array_unique($aggregate_results['matched_post_ids']))
            );
        }

        return $aggregate_results;
    }

    /**
     * @NEW 2026-08-07: Compute the next available publish_at slot AFTER the last
     * scheduled video in the same parent_batch_id. Used when a Buffer push has failed
     * the maximum number of automatic retries and the job needs to be re-queued to a
     * later date in the same calendar. Returns 'Y-m-d H:i:s' UTC string or empty string
     * when no parent_batch_id / no anchor slot exists.
     *
     * Slot math mirrors compute_publish_at(): parses publish_frequency into per-day
     * count, divides day into equal slots, and stacks successive re-queues on different
     * days so two failures don't collide on the same publish_at.
     */
    private static function compute_post_calendar_publish_at($job_id, $settings)
    {
        if (!class_exists('VS_Job_Repository')) {
            return '';
        }
        $job_repo = VS_Job_Repository::init();
        $job = $job_repo->get_job($job_id);
        if (!$job || empty($job['parent_batch_id'])) {
            return '';
        }
        $batch_id = (string) $job['parent_batch_id'];

        $anchor_utc = $job_repo->get_max_publish_at_for_batch($batch_id, $job_id);
        $requeued_anchor_utc = $job_repo->get_max_buffer_requeued_to_for_batch($batch_id);

        $candidates = array();
        if (!empty($anchor_utc) && $anchor_utc !== '0000-00-00 00:00:00') {
            $candidates[] = $anchor_utc;
        }
        if (!empty($requeued_anchor_utc) && $requeued_anchor_utc !== '0000-00-00 00:00:00') {
            $candidates[] = $requeued_anchor_utc;
        }
        if (empty($candidates)) {
            return '';
        }
        sort($candidates, SORT_STRING);
        $latest_utc = end($candidates);

        $frequency = $settings['publish_frequency'] ?? get_option('mcqvs_publish_frequency', 'daily');
        $per_day = 1;
        if (preg_match('/^(\d+)x[_\s]?daily$/i', $frequency, $m)) {
            $per_day = max(1, (int) $m[1]);
        } elseif ($frequency === 'twice_daily') {
            $per_day = 2;
        }

        // Slot the re-queue at the next day after the latest anchor, slot 0 (anchor time).
        try {
            $tz = function_exists('wp_timezone') ? wp_timezone() : new DateTimeZone('UTC');
        } catch (Exception $e) {
            $tz = new DateTimeZone('UTC');
        }
        try {
            $latest_local = new DateTime($latest_utc, new DateTimeZone('UTC'));
            $latest_local->setTimezone($tz);
        } catch (Exception $e) {
            return '';
        }
        $latest_local->modify('+1 day');
        return $latest_local->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
    }

    /**
     * Single-account Buffer push (extracted from the original push_job_to_buffer).
     *
     * @param string $job_id
     * @param string $video_url
     * @param array  $job
     * @param string $account_id Empty string = legacy default account.
     * @param array  $account  Account data (token, channels, daily_limit, etc.) if $account_id set.
     * @return array|WP_Error
     */
    private static function push_job_to_buffer_single($job_id, $video_url, $job, $account_id, $account)
    {
        $is_default = ($account_id === '');
        $token = $is_default ? get_option('mcqvs_buffer_access_token', '') : ($account['token'] ?? '');
        if (empty($token)) {
            return new WP_Error('no_token', 'Buffer access token not configured');
        }

        // @FIX 2026-07-06: Acquire job-level lock to prevent duplicate pushes on concurrent cron runs
        // For default account, use the legacy lock key for backward compat with get_jobs_ready_for_publish().
        if (class_exists('VS_Job_Repository')) {
            $job_repo = VS_Job_Repository::init();
            if ($is_default) {
                if (!$job_repo->acquire_job_lock($job_id, 60)) {
                    VS_Error_Logger::get_instance()->log("Buffer push: Job {$job_id} is locked, skipping to prevent duplicate.", 'info', array('job_id' => $job_id));
                    return array('success' => 0, 'failed' => 0, 'errors' => array('locked'), 'results' => array(), 'skipped' => true, 'reason' => 'locked');
                }
            }
        }

        $settings = is_string($job['settings'] ?? '') ? json_decode($job['settings'], true) : ($job['settings'] ?? array());
        if (!is_array($settings)) {
            $settings = array();
        }

        // If this job has exhausted its automatic Buffer attempts, skip it (manual push only).
        if (!empty($settings['buffer_manual_pending'])) {
            if (class_exists('VS_Job_Repository')) {
                $job_repo = VS_Job_Repository::init();
                if ($is_default) {
                    $job_repo->release_job_lock($job_id);
                }
            }
            return array('success' => 0, 'failed' => 0, 'errors' => array(), 'results' => array(), 'skipped' => true, 'reason' => 'manual_push_required');
        }

        $topic_name = $settings['topic_name'] ?? 'Quiz Video';
        $question_count = absint($job['question_count'] ?? 5);

        // @NEW 2026-08-11: Extra caption data for richer placeholders.
        //  - {firstquestion}: teaser from the actual quiz (quiz_data may be JSON string or array).
        //  - {link}: site URL (falls back to the WP home URL — thequizwire.com).
        //  - {part} / {part_total}: series numbering from content-planner part settings.
        $first_question = '';
        $quiz_data = isset($job['quiz_data']) ? $job['quiz_data'] : array();
        if (is_string($quiz_data)) {
            $decoded = json_decode($quiz_data, true);
            if (is_array($decoded)) $quiz_data = $decoded;
        }
        if (is_array($quiz_data) && !empty($quiz_data)) {
            foreach ($quiz_data as $qitem) {
                if (is_array($qitem)) {
                    $qtext = trim((string) ($qitem['question'] ?? ''));
                } else {
                    $qtext = trim((string) $qitem);
                }
                if ($qtext !== '') {
                    $first_question = (function_exists('mb_substr') ? mb_substr($qtext, 0, 90) : substr($qtext, 0, 90));
                    if (function_exists('mb_strlen') ? mb_strlen($first_question) >= 90 : strlen($first_question) >= 90) {
                        $first_question = rtrim($first_question) . '…';
                    }
                    break;
                }
            }
        }
        $site_url = !empty($settings['websiteUrl']) ? esc_url_raw($settings['websiteUrl']) : esc_url_raw(home_url('/'));
        $part_index = isset($settings['part_index']) ? absint($settings['part_index']) : 0;
        $part_total = isset($settings['part_total']) ? absint($settings['part_total']) : 0;
        $part_label = ($part_total > 1 && $part_index > 0) ? ('Part ' . $part_index . '/' . $part_total) : '';

        if (!empty($job['published_channels'])) {
            if (class_exists('VS_Job_Repository')) {
                $job_repo = VS_Job_Repository::init();
                if ($is_default) {
                    $job_repo->release_job_lock($job_id);
                }
            }
            return array('success' => 0, 'failed' => 0, 'errors' => array(), 'results' => array(), 'skipped' => true);
        }

        // Channel selection: per-account channels > job-specific > global enabled > cached all.
        $enabled_channels = $is_default
            ? json_decode(get_option('mcqvs_buffer_enabled_channels', '[]'), true)
            : ($account['channels'] ?? array());
        $channel_ids = !empty($enabled_channels) ? $enabled_channels
            : ($is_default
                ? json_decode(get_option('mcqvs_buffer_channels', '[]'), true)
                : json_decode(get_option('mcqvs_buffer_account_' . $account_id . '_channel_ids', '[]'), true));

        // @FIX 2026-08-08 (multi-account): Job-level buffer_channels is a legacy
        // single-account concept (content planner). It must NOT override a named
        // account's OWN channel selection — each enabled account pushes to its own
        // channels. Only the legacy default path (no registry accounts) honors it.
        $job_channels = $is_default ? ($settings['buffer_channels'] ?? null) : null;
        if (is_array($job_channels) && !empty($job_channels)) {
            // @FIX 2026-08-06: Job-saved channels could contain placeholder IDs
            //       (e.g. the old `buffer_channel_1` defaults) that Buffer rejects
            //       with "Invalid ChannelId format." Only accept valid ObjectId
            //       channel IDs; if none are valid, keep the real configured list
            //       that was already resolved above instead of pushing garbage.
            $valid_job_channels = array_values(array_filter($job_channels, array('VS_Buffer_Client', 'is_valid_channel_id')));
            if (!empty($valid_job_channels)) {
                $channel_ids = $valid_job_channels;
            }
        }

        if (empty($channel_ids) || !is_array($channel_ids)) {
            if (class_exists('VS_Job_Repository') && $is_default) {
                $job_repo = VS_Job_Repository::init();
                $job_repo->release_job_lock($job_id);
            }
            return new WP_Error('no_channels', 'No Buffer channels configured.');
        }

        $daily_limit = $is_default
            ? absint(get_option('mcqvs_buffer_daily_limit', 0))
            : max(0, (int) ($account['daily_limit'] ?? 0));

        // Per-account daily tracker.
        $tracker_option = $is_default ? 'mcqvs_buffer_pub_tracker' : 'mcqvs_buffer_pub_tracker_' . $account_id;
        if ($daily_limit > 0) {
            $tracker = get_option($tracker_option, array('date' => '', 'ids' => array()));
            if (!is_array($tracker)) {
                $tracker = array('date' => '', 'ids' => array());
            }
            $today = current_time('Y-m-d');
            if ($tracker['date'] !== $today) {
                $tracker = array('date' => $today, 'ids' => array());
            }
            if (count($tracker['ids']) >= $daily_limit) {
                VS_Error_Logger::get_instance()->log('Buffer: Daily limit (' . $daily_limit . ') reached for account ' . ($is_default ? 'default' : $account_id), 'warning');
                if (class_exists('VS_Job_Repository') && $is_default) {
                    $job_repo = VS_Job_Repository::init();
                    $job_repo->release_job_lock($job_id);
                }
                return new WP_Error('daily_limit', 'Buffer daily share limit reached.');
            }
        }

        $scheduled_at = '';
        if (!empty($job['publish_at']) && $job['publish_at'] !== '0000-00-00 00:00:00') {
            try {
                $dt = new DateTime($job['publish_at'], new DateTimeZone('UTC'));
                $scheduled_at = $dt->format('Y-m-d\TH:i:s') . '.000Z';
            } catch (Exception $e) {
                $scheduled_at = '';
            }
        }

        // @NEW 2026-08-11: Placeholder set upgraded. Supported:
        //   {hook} {topic} {score} {total} {hashtags}            (original)
        //   {firstquestion}  — first question teaser from quiz_data
        //   {link}           — site URL (home_url() by default = thequizwire.com)
        //   {part} {part_total} — series numbering (Content Planner part settings)
        // Default template upgraded to include the question teaser + site link (drives
        // traffic to thequizwire.com — the channel's #1 goal). Existing installs keep
        // their saved template; only a saved template that still equals the OLD default
        // is auto-migrated to the new default below.
        $default_template = "{hook}\n\n{topic}\nCan you score {score}/{total}? Comment below 👇\n\n❓ Q1: {firstquestion}\n\n📚 More daily MCQs: {link}\n\n{hashtags}";
        if ($is_default) {
            $saved_tpl = get_option('mcqvs_buffer_caption_template', '');
            if ($saved_tpl === '') {
                $template = $default_template;
            } elseif ($saved_tpl === "{hook}\n\n{topic}\nCan you score {score}/{total}?\n\n{hashtags}") {
                // Legacy default still in place → migrate to the richer template.
                update_option('mcqvs_buffer_caption_template', $default_template);
                $template = $default_template;
            } else {
                $template = $saved_tpl;
            }
        } else {
            $template = !empty($account['caption_template']) ? $account['caption_template'] : $default_template;
        }

        // Shared placeholder data (also reused by the per-channel templates + YT title).
        $replace_vals = array(
            'topic'         => $topic_name,
            'score'         => (string) $question_count,
            'total'         => (string) $question_count,
            'hook'          => isset($settings['hook']) ? $settings['hook'] : '',
            'hashtags'      => isset($settings['hashtags']) ? $settings['hashtags'] : '',
            'firstquestion' => $first_question,
            'link'          => $site_url,
            'part'          => $part_label,
            'part_total'    => $part_total > 1 ? (string) $part_total : '',
        );

        $caption = self::substitute_placeholders($template, $replace_vals);

        // @NEW 2026-08-10: Per-channel caption overrides. Each channel can carry
        // its own template (same placeholders as the global one). An empty or
        // missing channel entry falls back to the global $caption.
        $channel_captions_raw = $is_default
            ? (json_decode(get_option('mcqvs_buffer_channel_captions', '{}'), true) ?: array())
            : ($account['channel_captions'] ?? array());
        $channel_captions_resolved = array();
        if (is_array($channel_captions_raw)) {
            foreach ($channel_captions_raw as $cid => $tpl) {
                $cid = (string) $cid;
                if ($cid === '' || !is_string($tpl) || trim($tpl) === '') {
                    continue;
                }
                $resolved = self::substitute_placeholders($tpl, $replace_vals);
                if ($resolved !== '') {
                    $channel_captions_resolved[$cid] = $resolved;
                }
            }
        }

        // @NEW 2026-08-10: Per-channel "post to story" overrides. An explicit
        // true forces post_type=story for FB/IG/Threads regardless of the
        // channel_types dropdown.
        $channel_post_to_story = $is_default
            ? (json_decode(get_option('mcqvs_buffer_channel_post_to_story', '{}'), true) ?: array())
            : ($account['channel_post_to_story'] ?? array());
        if (!is_array($channel_post_to_story)) {
            $channel_post_to_story = array();
        }
        $channel_post_to_story = array_map(function ($v) { return !empty($v); }, $channel_post_to_story);

        // Scheduling mode & channel settings: per-account > global.
        $scheduling_mode = $is_default
            ? get_option('mcqvs_buffer_scheduling_mode', 'addToQueue')
            : ($account['scheduling_mode'] ?? get_option('mcqvs_buffer_scheduling_mode', 'addToQueue'));
        $channel_types = $is_default
            ? json_decode(get_option('mcqvs_buffer_channel_types', '{}'), true)
            : ($account['channel_types'] ?? array());
        $link_posts = $is_default
            ? json_decode(get_option('mcqvs_buffer_channel_link_posts', '{}'), true)
            : ($account['channel_link_posts'] ?? array());

        $client = new self($token, $account_id);

        // @FIX 2026-08-08 (YouTube): Per-account YouTube title template + category.
        // Title falls back to "{topic} - Quiz" (or "Quiz Video") so a push never
        // reaches Buffer without the required title/categoryId fields.
        $youtube_title = $is_default
            ? get_option('mcqvs_buffer_youtube_title', '')
            : ($account['youtube_title'] ?? '');
        if ($youtube_title === '') {
            $youtube_title = '{topic} - Quiz';
        }
        $youtube_title = str_replace(
            array('{topic}', '{score}', '{total}', '{hook}', '{hashtags}'),
            array($topic_name, $question_count, $question_count, $settings['hook'] ?? '', $settings['hashtags'] ?? ''),
            $youtube_title
        );
        $youtube_title = trim($youtube_title);
        if ($youtube_title === '') {
            $youtube_title = 'Quiz Video';
        }

        $youtube_category = $is_default
            ? get_option('mcqvs_buffer_youtube_category', '27')
            : ($account['youtube_category'] ?? '27');
        if (!preg_match('/^\d{1,2}$/', (string) $youtube_category)) {
            $youtube_category = '27'; // Education
        }


        $channels_raw = $client->get_channels_cached();
        $channel_data = array();
        if (is_array($channels_raw)) {
            foreach ($channels_raw as $ch) {
                $channel_data[$ch['id']] = $ch;
            }
        }

        // Detailed pipeline logging for dashboard visibility
        if (class_exists('VS_Error_Logger')) {
            VS_Error_Logger::get_instance()->log_pipeline(
                'buffer.push',
                'started',
                $job_id,
                "Buffer push starting for job {$job_id} to " . count($channel_ids) . " channel(s)" . ($is_default ? '' : " (account: {$account_id})"),
                'info',
                array(
                    'job_id' => $job_id,
                    'video_url' => $video_url,
                    'channel_ids' => $channel_ids,
                    'scheduled_at' => $scheduled_at,
                    'scheduling_mode' => $scheduling_mode,
                    'account_id' => $account_id,
                )
            );
        }

        $result = $client->create_update($channel_ids, $caption, $video_url, $scheduled_at, array(
            'scheduling_mode' => $scheduling_mode,
            'channel_types'   => $channel_types,
            'link_posts'      => $link_posts,
            'channel_data'    => $channel_data,
            'youtube_title'   => $youtube_title,
            'youtube_category'=> $youtube_category,
            // @NEW 2026-08-10: Per-channel overrides flow through here. The
            // client resolves per-channel text (truncated to service limit) and
            // forces post_type=story when the tick is set on FB/IG.
            'channel_captions'      => $channel_captions_resolved,
            'channel_post_to_story' => $channel_post_to_story,
            // @NEW 2026-08-11: Shared placeholder data so the YouTube title can
            // substitute {topic}/{hook}/{hashtags}/{part}/… at post creation.
            'placeholder_data'      => $replace_vals,
        ));

        if (is_wp_error($result)) {
            $err_msg = $result->get_error_message();
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log_pipeline(
                    'buffer.push',
                    'failed',
                    $job_id,
                    "Buffer push failed for job {$job_id}" . ($is_default ? '' : " (account: {$account_id})") . ": " . $err_msg,
                    'error',
                    array('job_id' => $job_id, 'video_url' => $video_url, 'error' => $err_msg, 'account_id' => $account_id)
                );
            }
            // @FIX 2026-08-07: Exponential backoff (120s, 240s, 480s, 960s, capped at 1h) +
            // automatic re-queue to the next calendar slot in the SAME parent_batch_id
            // after the 4th failure (3 retries + initial). Prior behaviour set a flat
            // 300s cooldown and permanently parked the job via buffer_manual_pending.
            $buffer_attempts = (int) ($settings['buffer_attempts'] ?? 0);
            $buffer_attempts++;
            $settings['buffer_attempts'] = $buffer_attempts;
            $settings['buffer_last_error'] = $err_msg;
            $settings['buffer_last_error_time'] = gmdate('Y-m-d H:i:s');

            if ($buffer_attempts >= 4) {
                // Final failure for this calendar slot — re-queue to end of same batch.
                $requeued_publish_at = self::compute_post_calendar_publish_at($job_id, $settings);
                if (!empty($requeued_publish_at)) {
                    $settings['buffer_attempts'] = 0;
                    $settings['buffer_requeued_at'] = gmdate('Y-m-d H:i:s');
                    $settings['buffer_requeued_to'] = $requeued_publish_at;
                    delete_transient('mcqvs_buffer_retry_' . $job_id);

                    if (class_exists('VS_Job_Repository')) {
                        $j_repo = VS_Job_Repository::init();
                        $render_buffer = absint(get_option('mcqvs_render_buffer_minutes', 60));
                        if ($render_buffer < 5) {
                            $render_buffer = 60;
                        }
                        $new_scheduled_at = gmdate('Y-m-d H:i:s', strtotime($requeued_publish_at . ' UTC') - ($render_buffer * 60));
                        $j_repo->update_job_fields($job_id, array(
                            'settings'           => wp_json_encode($settings),
                            'publish_at'         => $requeued_publish_at,
                            'scheduled_at'       => $new_scheduled_at,
                            'buffer_requeued_to' => $requeued_publish_at,
                        ));
                    }

                    if (class_exists('VS_Error_Logger')) {
                        VS_Error_Logger::get_instance()->log(
                            'buffer.requeued_post_calendar',
                            'warning',
                            array(
                                'job_id'        => $job_id,
                                'attempts'      => $buffer_attempts,
                                'last_error'    => $err_msg,
                                'new_publish_at'=> $requeued_publish_at,
                                'message'       => "Buffer push failed {$buffer_attempts} times; re-queued to {$requeued_publish_at} (same calendar batch)."
                            )
                        );
                    }
                } else {
                    // No parent_batch_id or no other jobs in batch to anchor against —
                    // fall back to the legacy manual-pending park so a human can intervene.
                    $settings['buffer_manual_pending'] = true;
                    delete_transient('mcqvs_buffer_retry_' . $job_id);
                    if (class_exists('VS_Error_Logger')) {
                        VS_Error_Logger::get_instance()->log(
                            'buffer.max_attempts_reached',
                            'warning',
                            array(
                                'job_id'    => $job_id,
                                'attempts'  => $buffer_attempts,
                                'last_error'=> $err_msg,
                                'message'   => "Buffer push failed after {$buffer_attempts} attempts and no batch anchor found; marked for manual push."
                            )
                        );
                    }
                }
            } else {
                $delay = min(3600, 60 * (2 ** $buffer_attempts));
                set_transient('mcqvs_buffer_retry_' . $job_id, 1, $delay);
                if (class_exists('VS_Error_Logger')) {
                    VS_Error_Logger::get_instance()->log(
                        'buffer.retry_scheduled',
                        'info',
                        array('job_id' => $job_id, 'attempt' => $buffer_attempts, 'next_retry_in' => $delay . 's')
                    );
                }
            }
            // Persist updated attempt tracking to the job row.
            if (class_exists('VS_Job_Repository')) {
                $j_repo = VS_Job_Repository::init();
                $j_repo->update_job_fields($job_id, array('settings' => wp_json_encode($settings)));
            }
            if (class_exists('VS_Job_Repository') && $is_default) {
                $job_repo = VS_Job_Repository::init();
                $job_repo->release_job_lock($job_id);
            }
            return $result;
        }

        // @FIX 2026-07-31: Pair each Buffer post id with the channel it actually
        //       succeeded on (per-channel result carries the channel id). The old
        //       count-based array_slice() mis-aligned published_channels when a
        //       middle channel failed (marked the failed channel as published).
        $published_channels = array();
        $matched_post_ids   = array();
        if (is_array($result) && !empty($result['results'])) {
            foreach ($result['results'] as $r) {
                if (!is_array($r) || !isset($r['post']['id'])) {
                    continue;
                }
                $matched_post_ids[] = $r['post']['id'];
                $channel = isset($r['channel']) ? $r['channel'] : '';
                if ($channel !== '' && in_array($channel, $channel_ids, true)) {
                    $published_channels[] = $channel;
                }
            }
        }

        if (empty($published_channels)) {
            // Legacy fallback: align by success count when results lack channel ids.
            $succeeded = is_array($result) ? (int) ($result['success'] ?? count($matched_post_ids)) : 0;
            $published_channels = array_slice($channel_ids, 0, max(0, $succeeded));
            $matched_post_ids   = array_slice($matched_post_ids, 0, count($published_channels));
        }
        $succeeded = count($matched_post_ids);

        if (class_exists('VS_Job_Repository')) {
            $job_repo = VS_Job_Repository::init();
            $job_repo->mark_published($job_id, $published_channels, $matched_post_ids);
        }

        if ($daily_limit > 0) {
            $tracker = get_option($tracker_option, array('date' => '', 'ids' => array()));
            if (!is_array($tracker)) {
                $tracker = array('date' => '', 'ids' => array());
            }
            $today = current_time('Y-m-d');
            if ($tracker['date'] !== $today) {
                $tracker = array('date' => $today, 'ids' => array());
            }
            foreach ($matched_post_ids as $pid) {
                $tracker['ids'][] = $pid;
            }
            update_option($tracker_option, $tracker, false);
        }

        // @FIX 2026-07-06: Release job lock after successful publish or early exit
        if (class_exists('VS_Job_Repository') && $is_default) {
            $job_repo = VS_Job_Repository::init();
            $job_repo->release_job_lock($job_id);
        }

        // Detailed success logging
        if (class_exists('VS_Error_Logger')) {
            VS_Error_Logger::get_instance()->log_pipeline(
                'buffer.push',
                'completed',
                $job_id,
                "Buffer push completed for job {$job_id}" . ($is_default ? '' : " (account: {$account_id})") . ": {$succeeded}/" . count($channel_ids) . " succeeded",
                'info',
                array(
                    'job_id' => $job_id,
                    'video_url' => $video_url,
                    'requested_channels' => $channel_ids,
                    'published_channels' => $published_channels,
                    'buffer_post_ids' => $matched_post_ids,
                    'success_count' => $succeeded,
                    'failed_count' => (int) ($result['failed'] ?? 0),
                    'errors' => $result['errors'] ?? array(),
                    'account_id' => $account_id,
                )
            );
        }

        return $result + array(
            'published_channels' => $published_channels,
            'matched_post_ids'   => $matched_post_ids,
        );
    }
}

/**
 * Buffer Account Registry — multi-account support for MCQ Video Studio.
 *
 * Mirrors the account-management pattern from the AI News plugin (Config::get_active_buffer_accounts).
 * Stores all accounts in a single option `mcqvs_buffer_accounts` (JSON array keyed by account id).
 * Falls back to the legacy single-token options so existing single-account installs work unchanged.
 *
 * @since 1.4.9.14
 */
class VS_Buffer_Account_Registry
{
    const OPTION_ACCOUNTS = 'mcqvs_buffer_accounts';

    /**
     * Get all accounts (raw stored data).
     *
     * @return array
     */
    public static function get_accounts()
    {
        $stored = get_option(self::OPTION_ACCOUNTS, '');
        $accounts = is_string($stored) ? json_decode($stored, true) : (is_array($stored) ? $stored : array());
        if (!is_array($accounts)) {
            $accounts = array();
        }

        // Re-key numerically-indexed arrays by account id (defensive).
        if (!empty($accounts) && is_int(array_key_first($accounts))) {
            $keyed = array();
            foreach ($accounts as $acct) {
                $acct_id = $acct['id'] ?? '';
                if ($acct_id !== '') {
                    $keyed[$acct_id] = $acct;
                }
            }
            $accounts = $keyed;
        }

        // @FIX 2026-08-08: Normalize account keys to lowercase. Every lookup path
        // runs sanitize_key(), which lowercases, so a mixed-case key (created by
        // wp_generate_password() before the lowercase fix) could never be matched
        // again. Lowercasing here heals legacy data in place.
        $normalized = array();
        foreach ($accounts as $aid => $acct) {
            $lkey = strtolower($aid);
            if (is_array($acct) && isset($acct['id'])) {
                $acct['id'] = strtolower((string) $acct['id']);
            }
            $normalized[$lkey] = $acct;
        }
        $accounts = $normalized;

        return $accounts;
    }

    /**
     * Get only active accounts (enabled + has token).
     *
     * @return array
     */
    public static function get_active_accounts()
    {
        $accounts = self::get_accounts();
        $active = array();
        foreach ($accounts as $acct) {
            if (!empty($acct['enabled']) && !empty($acct['token'])) {
                $active[$acct['id']] = $acct;
            }
        }
        return $active;
    }

    /**
     * Get a single account by id.
     *
     * @param string $id
     * @return array|null
     */
    public static function get_account($id)
    {
        $accounts = self::get_accounts();
        return $accounts[$id] ?? null;
    }

    /**
     * Get the token for an account.
     *
     * @param string $id
     * @return string
     */
    public static function get_token($id)
    {
        $acct = self::get_account($id);
        if (is_array($acct) && !empty($acct['token'])) {
            return (string) $acct['token'];
        }
        // Fallback to legacy single token for 'default' account.
        if ($id === 'default') {
            return (string) get_option('mcqvs_buffer_access_token', '');
        }
        return '';
    }

    /**
     * Get per-account daily limit.
     *
     * @param string $id
     * @return int
     */
    public static function get_daily_limit($id)
    {
        $acct = self::get_account($id);
        if (is_array($acct)) {
            return max(0, (int) ($acct['daily_limit'] ?? 0));
        }
        return 0;
    }

    /**
     * Get per-account enabled channel IDs.
     *
     * @param string $id
     * @return array
     */
    public static function get_channels($id)
    {
        $acct = self::get_account($id);
        if (is_array($acct) && isset($acct['channels']) && is_array($acct['channels'])) {
            return $acct['channels'];
        }
        return array();
    }

    /**
     * Get per-account channel types.
     *
     * @param string $id
     * @return array
     */
    public static function get_channel_types($id)
    {
        $acct = self::get_account($id);
        if (is_array($acct) && isset($acct['channel_types']) && is_array($acct['channel_types'])) {
            return $acct['channel_types'];
        }
        return array();
    }

    /**
     * Get per-account link posts map.
     *
     * @param string $id
     * @return array
     */
    public static function get_link_posts($id)
    {
        $acct = self::get_account($id);
        if (is_array($acct) && isset($acct['channel_link_posts']) && is_array($acct['channel_link_posts'])) {
            return $acct['channel_link_posts'];
        }
        return array();
    }

    /**
     * Get per-account caption template.
     *
     * @param string $id
     * @return string
     */
    public static function get_caption_template($id)
    {
        $acct = self::get_account($id);
        if (is_array($acct) && isset($acct['caption_template']) && is_string($acct['caption_template'])) {
            return $acct['caption_template'];
        }
        return '';
    }

    /**
     * @NEW 2026-08-10: Per-channel caption template overrides.
     *
     * Returns a map of channel_id => caption template. A channel not present in the
     * map (or with an empty template) falls back to the account-level caption template.
     *
     * @param string $id Account id.
     * @return array<string,string>
     */
    public static function get_channel_captions($id)
    {
        $acct = self::get_account($id);
        if (is_array($acct) && isset($acct['channel_captions']) && is_array($acct['channel_captions'])) {
            $clean = array();
            foreach ($acct['channel_captions'] as $cid => $tpl) {
                $cid = (string) $cid;
                if ($cid !== '' && is_string($tpl)) {
                    $clean[$cid] = $tpl;
                }
            }
            return $clean;
        }
        return array();
    }

    /**
     * @NEW 2026-08-10: Per-channel "post to stories" override.
     *
     * Returns a map of channel_id => bool. A channel not present falls back to the
     * channel-type dropdown (post_type === 'story').
     *
     * @param string $id Account id.
     * @return array<string,bool>
     */
    public static function get_channel_post_to_story($id)
    {
        $acct = self::get_account($id);
        if (is_array($acct) && isset($acct['channel_post_to_story']) && is_array($acct['channel_post_to_story'])) {
            $clean = array();
            foreach ($acct['channel_post_to_story'] as $cid => $flag) {
                $cid = (string) $cid;
                if ($cid !== '') {
                    $clean[$cid] = !empty($flag);
                }
            }
            return $clean;
        }
        return array();
    }

    /**
     * Get per-account scheduling mode.
     *
     * @param string $id
     * @return string
     */
    public static function get_scheduling_mode($id)
    {
        $acct = self::get_account($id);
        if (is_array($acct) && isset($acct['scheduling_mode']) && is_string($acct['scheduling_mode'])) {
            return $acct['scheduling_mode'];
        }
        return 'addToQueue';
    }

    /**
     * Lazy migration: if accounts option is empty but legacy token exists,
     * synthesize a 'default' account so the rest of the code can treat
     * single-account installs uniformly as multi-account with one account.
     *
     * @return void
     */
    public static function ensure_legacy_migrated()
    {
        $accounts = self::get_accounts();
        if (!empty($accounts)) {
            return; // Already migrated.
        }

        $legacy_token = get_option('mcqvs_buffer_access_token', '');
        if (empty($legacy_token)) {
            return; // No legacy config to migrate.
        }

        $enabled_channels = json_decode(get_option('mcqvs_buffer_enabled_channels', '[]'), true);
        $channel_types    = json_decode(get_option('mcqvs_buffer_channel_types', '{}'), true);
        $link_posts       = json_decode(get_option('mcqvs_buffer_channel_link_posts', '{}'), true);
        $daily_limit      = absint(get_option('mcqvs_buffer_daily_limit', 0));
        $caption_template = get_option('mcqvs_buffer_caption_template', "{hook}\n\n{topic}\nCan you score {score}/{total}?\n\n{hashtags}");
        $scheduling_mode  = get_option('mcqvs_buffer_scheduling_mode', 'addToQueue');

        $synthetic = array(
            'id'               => 'default',
            'label'            => 'Default Account',
            'token'            => $legacy_token,
            'enabled'          => true,
            'channels'         => is_array($enabled_channels) ? $enabled_channels : array(),
            'channel_types'    => is_array($channel_types) ? $channel_types : array(),
            'channel_link_posts' => is_array($link_posts) ? $link_posts : array(),
            'daily_limit'      => $daily_limit,
            'caption_template' => $caption_template,
            'scheduling_mode'  => $scheduling_mode,
            'is_default'       => true,
            // @NEW 2026-08-10: Per-channel caption / story maps. Empty by default —
            // the UI populates these lazily when a user opens a per-channel editor.
            // Per-channel YouTube overrides intentionally omitted: a Buffer account
            // owns exactly one YouTube channel, so title/category live at the
            // account level (youtube_title / youtube_category).
            'channel_captions'      => array(),
            'channel_post_to_story' => array(),
        );

        update_option(self::OPTION_ACCOUNTS, wp_json_encode(array('default' => $synthetic)), false);
    }

    /**
     * Add or update an account.
     *
     * @param array $data Account data: id (optional, auto-generated if empty), label, token, enabled, daily_limit, etc.
     * @return string|WP_Error Account id on success, WP_Error on failure.
     */
    public static function add_account($data)
    {
        if (empty($data['label']) || empty($data['token'])) {
            return new WP_Error('invalid_account', 'Label and token are required.');
        }

        $accounts = self::get_accounts();

        $id = isset($data['id']) && $data['id'] !== '' ? sanitize_key($data['id']) : '';
        if ($id === '') {
            // @FIX 2026-08-08: Force lowercase. wp_generate_password() emits mixed
            // case, and every AJAX boundary lowercases the id via sanitize_key(),
            // so a mixed-case key could never be looked up again ("Account not found").
            $id = 'acct_' . strtolower(wp_generate_password(8, false));
        }

        // Ensure uniqueness.
        $original_id = $id;
        $suffix = 2;
        while (isset($accounts[$id])) {
            $id = $original_id . '_' . $suffix;
            $suffix++;
        }

        // If this is the first account and no default exists, mark it as default.
        $has_default = false;
        foreach ($accounts as $acct) {
            if (!empty($acct['is_default'])) {
                $has_default = true;
                break;
            }
        }

        $account = array(
            'id'                 => $id,
            'label'              => sanitize_text_field($data['label']),
            'token'              => sanitize_text_field($data['token']),
            'enabled'            => !empty($data['enabled']),
            'channels'           => isset($data['channels']) && is_array($data['channels']) ? $data['channels'] : array(),
            'channel_types'      => isset($data['channel_types']) && is_array($data['channel_types']) ? $data['channel_types'] : array(),
            'channel_link_posts' => isset($data['channel_link_posts']) && is_array($data['channel_link_posts']) ? $data['channel_link_posts'] : array(),
            'daily_limit'        => max(0, (int) ($data['daily_limit'] ?? 0)),
            'caption_template'   => isset($data['caption_template']) ? sanitize_textarea_field($data['caption_template']) : '',
            'scheduling_mode'    => isset($data['scheduling_mode']) && in_array($data['scheduling_mode'], array('addToQueue', 'customScheduled', 'shareNow'), true) ? $data['scheduling_mode'] : 'addToQueue',
            'youtube_title'      => sanitize_text_field($data['youtube_title'] ?? ''),
            'youtube_category'   => sanitize_text_field($data['youtube_category'] ?? '27'),
            'is_default'         => !$has_default,
            // @NEW 2026-08-10: Per-channel caption / story maps. Sanitized by
            // the dedicated helpers below; new accounts start with empty maps
            // so the JSON schema is uniform across legacy + fresh installs.
            // Per-channel YouTube overrides intentionally omitted — a Buffer
            // account has exactly one YouTube channel, so its title/category
            // live at the account level (youtube_title / youtube_category).
            'channel_captions'      => self::sanitize_channel_captions_map($data['channel_captions'] ?? null),
            'channel_post_to_story' => self::sanitize_channel_story_map($data['channel_post_to_story'] ?? null),
        );

        $accounts[$id] = $account;
        update_option(self::OPTION_ACCOUNTS, wp_json_encode($accounts), false);

        // Clear this account's cache so next push uses fresh data.
        VS_Buffer_Client::clear_channels_cache($id);

        return $id;
    }

    /**
     * Update an existing account.
     *
     * @param string $id
     * @param array $data
     * @return bool|WP_Error
     */
    public static function update_account($id, $data)
    {
        $accounts = self::get_accounts();
        if (!isset($accounts[$id])) {
            return new WP_Error('account_not_found', 'Account not found.');
        }

        $account = $accounts[$id];
        $old_token = $account['token'] ?? '';

        if (isset($data['label'])) {
            $account['label'] = sanitize_text_field($data['label']);
        }
        if (isset($data['token'])) {
            $account['token'] = sanitize_text_field($data['token']);
        }
        if (isset($data['enabled'])) {
            $account['enabled'] = (bool) $data['enabled'];
        }
        if (isset($data['channels']) && is_array($data['channels'])) {
            $account['channels'] = $data['channels'];
        }
        if (isset($data['channel_types']) && is_array($data['channel_types'])) {
            $account['channel_types'] = $data['channel_types'];
        }
        if (isset($data['channel_link_posts']) && is_array($data['channel_link_posts'])) {
            $account['channel_link_posts'] = $data['channel_link_posts'];
        }
        if (isset($data['daily_limit'])) {
            $account['daily_limit'] = max(0, (int) $data['daily_limit']);
        }
        if (isset($data['caption_template'])) {
            $account['caption_template'] = sanitize_textarea_field($data['caption_template']);
        }
        if (isset($data['scheduling_mode']) && in_array($data['scheduling_mode'], array('addToQueue', 'customScheduled', 'shareNow'), true)) {
            $account['scheduling_mode'] = $data['scheduling_mode'];
        }
        if (isset($data['youtube_title'])) {
            $account['youtube_title'] = sanitize_text_field($data['youtube_title']);
        }
        if (isset($data['youtube_category'])) {
            $account['youtube_category'] = sanitize_text_field($data['youtube_category']);
        }
        // @NEW 2026-08-10: Per-channel overrides. Only overwrite when the caller
        // sends the field; absence means "no change" so a partial save (e.g. just
        // toggling enabled) doesn't blank the maps.
        if (isset($data['channel_captions'])) {
            $account['channel_captions'] = self::sanitize_channel_captions_map($data['channel_captions']);
        }
        if (isset($data['channel_post_to_story'])) {
            $clean_story_map = self::sanitize_channel_story_map($data['channel_post_to_story']);
            $account['channel_post_to_story'] = $clean_story_map;
            // @FIX 2026-08-13: For default account, also sync legacy global option
            // so push pipeline (which reads mcqvs_buffer_channel_post_to_story) stays
            // in sync with registry. Without this, tick appears to "come back" on refresh
            // because UI reads registry but push reads stale global option.
            if ($id === 'default' || !empty($account['is_default'])) {
                update_option('mcqvs_buffer_channel_post_to_story', wp_json_encode($clean_story_map), false);
            }
        }

        $accounts[$id] = $account;
        update_option(self::OPTION_ACCOUNTS, wp_json_encode($accounts), false);

        // @FIX 2026-08-08: Only purge the cached org/channel list when the token
        // actually changed. Clearing on every save wiped the cached channel list
        // (mcqvs_buffer_account_{id}_channels_data + _org_id) that the settings card
        // renders — so a non-default account appeared to "lose" its channels after a
        // routine save + refresh. The cache now persists until the user explicitly
        // clicks "Refresh Channels" (or changes the token).
        if (($account['token'] ?? '') !== $old_token) {
            VS_Buffer_Client::clear_channels_cache($id);
        }

        return true;
    }

    /**
     * Delete an account.
     *
     * @param string $id
     * @return bool|WP_Error
     */
    public static function delete_account($id)
    {
        $accounts = self::get_accounts();
        if (!isset($accounts[$id])) {
            return new WP_Error('account_not_found', 'Account not found.');
        }

        // Prevent deleting the last enabled account.
        $enabled_count = 0;
        foreach ($accounts as $acct) {
            if (!empty($acct['enabled'])) {
                $enabled_count++;
            }
        }
        if ($enabled_count <= 1 && !empty($accounts[$id]['enabled'])) {
            return new WP_Error('last_account', 'Cannot delete the last enabled Buffer account.');
        }

        unset($accounts[$id]);
        update_option(self::OPTION_ACCOUNTS, wp_json_encode($accounts), false);

        // Clean up per-account caches.
        delete_option('mcqvs_buffer_account_' . $id . '_org_id');
        delete_option('mcqvs_buffer_account_' . $id . '_org_id_all');
        delete_option('mcqvs_buffer_account_' . $id . '_channels_data');
        delete_option('mcqvs_buffer_account_' . $id . '_channel_ids');
        delete_option('mcqvs_buffer_pub_tracker_' . $id);

        return true;
    }

    /**
     * @NEW 2026-08-10: Sanitize a per-channel caption map.
     *
     * Accepts either an array (raw form), a JSON string, or null. Returns a
     * canonical channel_id => caption template map. Empty strings are kept
     * (so the UI can signal "explicitly blanked") but other falsy values are
     * dropped. Non-string keys are coerced to strings.
     *
     * @param mixed $raw
     * @return array<string,string>
     */
    private static function sanitize_channel_captions_map($raw)
    {
        if ($raw === null) {
            return array();
        }
        if (is_string($raw)) {
            $decoded = json_decode($raw, true);
            $raw = is_array($decoded) ? $decoded : array();
        }
        if (!is_array($raw)) {
            return array();
        }
        $clean = array();
        foreach ($raw as $cid => $tpl) {
            $cid = (string) $cid;
            if ($cid === '' || !is_string($tpl)) {
                continue;
            }
            // Keep empty strings; drop anything else non-stringifiable.
            $clean[$cid] = sanitize_textarea_field($tpl);
        }
        return $clean;
    }

    /**
     * @NEW 2026-08-10: Sanitize a per-channel "post to story" map.
     *
     * @param mixed $raw
     * @return array<string,bool>
     */
    private static function sanitize_channel_story_map($raw)
    {
        if ($raw === null) {
            return array();
        }
        if (is_string($raw)) {
            $decoded = json_decode($raw, true);
            $raw = is_array($decoded) ? $decoded : array();
        }
        if (!is_array($raw)) {
            return array();
        }
        $clean = array();
        foreach ($raw as $cid => $flag) {
            $cid = (string) $cid;
            if ($cid === '') {
                continue;
            }
            $clean[$cid] = !empty($flag);
        }
        return $clean;
    }
}
