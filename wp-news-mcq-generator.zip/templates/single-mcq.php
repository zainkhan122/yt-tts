<?php

/**
 * Single MCQ Template
 * @version 1.3 - Hardened with XSS Prevention
 * * @MODIFIED: Added esc_html(), esc_url(), and esc_attr() to all dynamic output.
 * @MODIFIED: Used wp_kses_post() for explanation output.
 */

get_header();
$is_astra = function_exists('astra_page_layout');
$post_id = get_the_ID();
?>

<?php if ($is_astra): ?>
    <div id="primary" <?php astra_primary_class(); ?>>
        <?php astra_primary_content_top(); ?>
    <?php endif; ?>

    <?php
    $topics = wp_get_post_terms($post_id, 'topic', ['number' => 1]);
    ?>

    <div class="nm-custom-breadcrumb">
        <a href="<?php echo esc_url(home_url()); ?>">🏠 Home</a>
        <span class="separator">›</span>
        <a href="<?php echo esc_url(get_post_type_archive_link('mcq')); ?>">MCQs</a>

        <?php if (!empty($topics) && !is_wp_error($topics)) : ?>
            <span class="separator">›</span>
            <a href="<?php echo esc_url(get_term_link($topics[0])); ?>"><?php echo esc_html($topics[0]->name); ?></a>
        <?php endif; ?>

        <span class="separator">›</span>
        <span class="current">Question</span>
    </div>

    <div class="mcq-single-container">
        <?php
        while (have_posts()) : the_post();
            $post_id = get_the_ID();
            $original_options = get_post_meta($post_id, 'mcq_options', true);
            $original_correct_answer = get_post_meta($post_id, 'mcq_answer', true);
            $explanation = get_post_meta($post_id, 'mcq_explanation', true);
            $difficulty = get_post_meta($post_id, 'mcq_difficulty', true);

            if (!is_array($original_options) || empty($original_correct_answer) || !isset($original_options[$original_correct_answer])) {
                echo '<p>Question data unavailable.</p>';
                continue;
            }

            // @MODIFIED: Canonical page must be deterministic for SEO/schema/cache stability
            // Disabled randomization to ensure HTML order matches RankMath JSON-LD schema.
            $options = $original_options;
            $correct_answer_key = $original_correct_answer;
        ?>

            <article id="post-<?php the_ID(); ?>" <?php post_class('mcq-single-post'); ?>>

                <header class="mcq-header">
                    <h1 class="mcq-question"><?php the_title(); ?></h1>
                </header>

                <?php
                // ✅ NEW v7.3.7: Display E-A-T Attribution Box
                if (class_exists('NM_Frontend_Manager') && method_exists('NM_Frontend_Manager', 'nm_display_mcq_attribution')) {
                    NM_Frontend_Manager::nm_display_mcq_attribution($post_id);
                }
                ?>

                <div class="mcq-options-container">
                    <?php foreach ($options as $key => $value): ?>
                        <div class="mcq-option" data-option="<?php echo esc_attr($key); ?>">
                            <input type="radio"
                                name="mcq_answer"
                                id="option_<?php echo esc_attr($key); ?>"
                                value="<?php echo esc_attr($key); ?>"
                                aria-label="Option <?php echo esc_attr($key); ?>: <?php echo esc_attr($value); ?>">

                            <label for="option_<?php echo esc_attr($key); ?>">
                                <span class="option-letter"><?php echo esc_html($key); ?>.</span>
                                <span class="option-text"><?php echo esc_html($value); ?></span>
                            </label>
                        </div>
                    <?php endforeach; ?>
                </div>

                <button class="mcq-submit-btn"
                    type="button"
                    role="button"
                    aria-label="Submit your answer"
                    data-post-id="<?php echo (int) $post_id; ?>"
                    data-correct="<?php echo esc_attr($correct_answer_key); ?>">
                    Check Answer
                </button>

                <div class="mcq-result" style="display:none;"></div>

                <?php if ($explanation): ?>
                    <div class="mcq-explanation" style="display:none;">
                        <h3>💡 Explanation:</h3>
                        <p><?php echo wp_kses_post($explanation); ?></p>
                    </div>
                <?php endif; ?>

                <?php
                $topics = get_the_terms($post_id, 'topic');
                if ($topics && !is_wp_error($topics)):
                ?>
                    <div class="mcq-topics">
                        <span class="topics-label">📚 Topics:</span>
                        <?php foreach ($topics as $topic): ?>
                            <a href="<?php echo esc_url(get_term_link($topic)); ?>" class="topic-tag">
                                <?php echo esc_html($topic->name); ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <?php
                // ✅ NEW v7.3.7: Display Exam Tags (Internal Linking Strategy)
                $exam_tags = get_the_terms($post_id, 'nm_exam');
                if ($exam_tags && !is_wp_error($exam_tags)):
                ?>
                    <div class="mcq-exams">
                        <span class="exams-label">🎯 Exams:</span>
                        <?php foreach ($exam_tags as $exam): ?>
                            <a href="<?php echo esc_url(get_term_link($exam)); ?>" class="exam-tag">
                                <?php echo esc_html($exam->name); ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

                <?php
                // ✅ NEW: Display AI Tags (Ordering: Topics -> Exams -> Tags)
                $ai_tags = get_the_terms($post_id, 'mcq_tag');
                if ($ai_tags && !is_wp_error($ai_tags)):
                ?>
                    <div class="mcq-tags">
                        <span class="tags-label">🏷️ Tags:</span>
                        <?php foreach ($ai_tags as $tag): ?>
                            <a href="<?php echo esc_url(get_term_link($tag)); ?>" class="mcq-tag-pill">
                                <?php echo esc_html($tag->name); ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

            </article>

            <?php
            // Renders related posts and share buttons (which are now inside nm-frontend-manager.php)
            the_content();
            ?>

            <?php
            if (comments_open() || get_comments_number()) :
                comments_template();
            endif;
            ?>

        <?php endwhile; ?>
    </div>

    <script>
        jQuery(document).ready(function($) {
            'use strict';

            const submitBtn = $('.mcq-submit-btn');
            const resultDiv = $('.mcq-result');
            const explanationDiv = $('.mcq-explanation');
            let isSubmitting = false;

            const ajaxUrl = '<?php echo esc_js(admin_url('admin-ajax.php')); ?>';
            const mcqNonce = '<?php echo esc_js(wp_create_nonce('nm_mcq_nonce')); ?>';
            const isLoggedIn = <?php echo is_user_logged_in() ? 'true' : 'false'; ?>;

            submitBtn.on('click', function() {
                if (isSubmitting) return;

                const btn = $(this);
                const postId = btn.data('post-id');
                const correctAnswer = btn.data('correct');
                const selectedOption = $('input[name="mcq_answer"]:checked');

                if (selectedOption.length === 0) {
                    resultDiv.removeClass('correct incorrect')
                        .addClass('incorrect')
                        .html('⚠️ Please select an answer before submitting.')
                        .slideDown();

                    $('html, body').animate({
                        scrollTop: resultDiv.offset().top - 100
                    }, 500);
                    return;
                }

                isSubmitting = true;

                const selectedValue = selectedOption.val();
                const isCorrect = (selectedValue === correctAnswer);

                $('.mcq-option').each(function() {
                    const optionKey = $(this).data('option');
                    if (optionKey === correctAnswer) {
                        $(this).addClass('correct');
                    } else if (optionKey === selectedValue && !isCorrect) {
                        $(this).addClass('incorrect');
                    }
                });

                resultDiv.removeClass('correct incorrect');

                if (isCorrect) {
                    resultDiv.addClass('correct')
                        .html('✅ <strong>Correct!</strong> Well done! You got it right.');
                } else {
                    const correctText = $('.mcq-option[data-option="' + correctAnswer + '"] .option-text').text();
                    resultDiv.addClass('incorrect')
                        .html('❌ <strong>Incorrect.</strong> The correct answer is: <strong>' + correctAnswer + '</strong> - ' + correctText);
                }

                resultDiv.slideDown();
                explanationDiv.slideDown();

                btn.prop('disabled', true).text('✓ Answer Submitted');
                $('input[name="mcq_answer"]').prop('disabled', true);

                if (isLoggedIn) {
                    $.ajax({
                        url: ajaxUrl,
                        type: 'POST',
                        data: {
                            action: 'track_answer',
                            nonce: mcqNonce,
                            post_id: postId,
                            was_correct: isCorrect ? 1 : 0,
                            selected_answer: selectedValue
                        },
                        success: function(response) {
                            if (response.success) {
                                console.log('✅ Answer tracked (ID: ' + postId + ')');
                            } else {
                                console.warn('⚠️ Failed to track:', response.data?.message);
                            }
                        },
                        error: function(xhr) {
                            console.error('❌ AJAX Error:', xhr.responseText);
                        }
                    });
                }

                $('html, body').animate({
                    scrollTop: resultDiv.offset().top - 100
                }, 500);
            });

            $(document).on('keypress', function(e) {
                if (e.which === 13 && !isSubmitting) {
                    submitBtn.not(':disabled').click();
                }
            });
        });
    </script>

    <?php if ($is_astra): ?>
        <?php astra_primary_content_bottom(); ?>
    </div>
    <?php if (astra_page_layout() == 'right-sidebar'): ?>
        <?php get_sidebar(); ?>
    <?php endif; ?>
<?php endif; ?>

<?php get_footer(); ?>