<?php

/**
 * Discovery Processor — Approval Pipeline & Background Worker
 *
 * @package SEO_Article_Generator\Discovery
 * @version 2026-03-22 (Clean Restoration v4)
 */

namespace SEO_Article_Generator\Discovery;

use SEO_Article_Generator\Utils\Plugin_Time;
use SEO_Article_Generator\Utils\SeoGen_Version_Resolver;
use SEO_Article_Generator\Jobs\Job_Handler;
use SEO_Article_Generator\Queue\AS_Registry;
use SEO_Article_Generator\Installer;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( Discovery_Engine::class, false ) ) {
	require_once __DIR__ . '/class-discovery-engine.php';
}

class Discovery_Processor {

	/** Pure link-stage boundary apart from the explicit existing-post read. No jobs/API/writes. */
	public static function reconcile_download_sources(array $phase1, string $html, int $existing_post_id = 0, string $software_name = '', string $source_url = '', $logger = null, int $discovery_id = 0, bool $update_mode = false): array {
		$args = array('source_url'=>$source_url, 'software_name'=>$software_name);
		$fresh = Data_Extractor::extract($html, $args);
		$recovery = $fresh['all_links'];
		if ($existing_post_id > 0 && !$update_mode) {
			$existing = array('links' => \SEO_Article_Generator\Integration\Link_Resolver::recover_existing_post_links($existing_post_id, $software_name));
			foreach ($existing['links'] as &$old_link) $old_link['_continuity_existing'] = true;
			unset($old_link);
			$recovery = array_merge($recovery, $existing['links']);
		}
		$links = \SEO_Article_Generator\Generator\Download_Link_Helper::reconcile_source_links($phase1, $recovery);
		if ($existing_post_id > 0 && !$update_mode) $links = \SEO_Article_Generator\Generator\Download_Link_Helper::normalize_links(\SEO_Article_Generator\Generator\Download_Link_Helper::respect_manual_removals($links, $existing_post_id), 'Other');
		\SEO_Article_Generator\Generator\Download_Link_Helper::trace_links('discovery_reconcile:' . $discovery_id, $phase1, $links, $logger);
		return $links;
	}

	/** @var \SEO_Article_Generator\Jobs\Job_Handler */
	private $job_handler;

	/** @var \SEO_Article_Generator\Logger */
	private $logger;

	/** Seconds between completion polls (last-resort safety net) */
	const POLL_INTERVAL = 30;

	/** Seconds before first poll after job submission — give AI time to complete */
	const FIRST_POLL_DELAY = 45;

	/** Maximum poll attempts before hard fail (prevents infinite loops) */
	const MAX_POLL_ATTEMPTS = 10;

	/**
	 * FIX F4 (Phase 3A): per-item failure circuit breaker. After this many
	 * CONSECUTIVE failures (counted in mark_discovery_failure, reset on done or
	 * manual Retry/Run-now), the item is parked: rescan will not re-pend it and
	 * approve/auto-gen will not pick it up until a human overrides.
	 */
	public const MAX_CONSECUTIVE_FAILURES = 3;

	/**
	 * FIX D2b (2026-09-06): starvation backstop for passive waits (seconds).
	 * A job stuck 'pending' (worker never picks it up) longer than this trips a
	 * timeout via the failure SSOT. Passive waits below the cap do NOT consume
	 * poll budget, so backlog/deferral waves no longer mass-time-out healthy rows.
	 */
	const MAX_PASSIVE_WAIT_SECONDS = 43200;

	/**
	 * Phase 3F (2.34.0): minimum seconds between per-discovery queue force-wake
	 * kicks while a job sits pending behind the backlog. Cuts the 1,334/day
	 * busy-wake spam to at most one per ~2 min per starved discovery without
	 * slowing drain (the recurring worker keeps pulling regardless).
	 */
	const FORCE_WAKE_THROTTLE = 120;
	// Canonical discovery table column map.
	public const COL_STATUS           = 'status';
	public const COL_ERROR_MESSAGE    = 'error_message';
	public const COL_HEARTBEAT_AT     = 'heartbeat_at';
	public const COL_SCHEDULED_AT     = 'scheduled_at';
	public const COL_EXISTING_POST_ID = 'existing_post_id';
	public const COL_DRAFT_POST_ID    = 'draft_post_id';
	public const COL_SOURCE_TYPE      = 'source_type';
	public const COL_COMPLETED_AT     = 'completed_at';
	public const COL_QUEUE_JOB_ID     = 'queue_job_id';
	public const COL_JOB_ID           = 'job_id';
	public const COL_POLL_COUNT       = 'poll_count';
	public const COL_CONSECUTIVE_FAILURES = 'consecutive_failures';
	public const COL_LAST_FAILURE_AT     = 'last_failure_at';

	/** @var bool Guard against duplicate hook registration */
	private $hooks_registered = false;

	public function __construct( $job_handler = null, $logger = null ) {
		$this->job_handler = $job_handler ?: new Job_Handler();
		$this->logger      = $logger ?: \SEO_Article_Generator\Plugin::get_instance()->get_logger();
	}

	private function has_recoverable_snapshot( int $job_id ): bool {
		$preview = $this->job_handler->get_preview( $job_id );

		return ! empty( $preview['article'] ) && is_array( $preview['article'] );
	}

	private function recover_from_reconcile_failed_snapshot( int $discovery_id, int $job_id, int $user_id, string $context = '' ): bool {
		if ( ! $this->has_recoverable_snapshot( $job_id ) ) {
			return false;
		}

		$item = $this->claim_item_for_finalization( $discovery_id, $job_id, true );
		if ( ! $item ) {
			$this->logger->error(
				'Discovery ' . (int) $discovery_id . ' ' . $context .
				': snapshot recovery claim failed for reconcile_failed job ' . (int) $job_id . '.'
			);
			return false;
		}

		$this->logger->warning(
			'Discovery ' . (int) $discovery_id . ' ' . $context .
			': recovering reconcile_failed job ' . (int) $job_id .
			' using persisted post-generation snapshot.'
		);

		$this->auto_finalize( $item, $job_id, $user_id > 0 ? $user_id : 1 );
		return true;
	}

	private function get_default_new_post_sections(): array {
		return array(
			'introduction',
			'features',
			'download',
			'tech_specs',
			'installation',
			'safety',
			'faqs',
			'moat',
			'pros_cons',
		);
	}

	private function get_new_post_sections(): array {
		$defaults = \SEO_Article_Generator\Option_Registry::defaults();
		$fallback = $defaults[ \SEO_Article_Generator\Option_Registry::DISCOVERY_SECTIONS ];

		$sections = \get_option(
			\SEO_Article_Generator\Option_Registry::DISCOVERY_SECTIONS,
			$fallback
		);

		if ( ! is_array( $sections ) || empty( $sections ) ) {
			$sections = $fallback;
		}

		$sections = \SEO_Article_Generator\Generator\Article_Schema::normalize_sections(
			$sections,
			array_merge( $fallback, array( 'toc', 'all' ) )
		);

		return array_values(
			array_unique(
				array_filter(
					$sections,
					static function ( $value ) {
						return is_string( $value ) && trim( $value ) !== '';
					}
				)
			)
		);
	}

	private function get_update_sections(): array {
		$defaults = \SEO_Article_Generator\Option_Registry::defaults();
		$fallback = $defaults[ \SEO_Article_Generator\Option_Registry::UPDATE_SECTIONS ];

		$sections = \get_option(
			\SEO_Article_Generator\Option_Registry::UPDATE_SECTIONS,
			false
		);

		if ( $sections === false ) {
			return $fallback;
		}

		if ( ! is_array( $sections ) ) {
			$sections = $fallback;
		}

		$sections = \SEO_Article_Generator\Generator\Article_Schema::normalize_sections( $sections, $fallback );

		if ( empty( $sections ) ) {
			$this->logger->warning( 'UPDATE_SECTIONS option resolved to an empty canonical set. Falling back to default update sections.' );
			return $fallback;
		}

		return array_values(
			array_unique(
				array_filter(
					$sections,
					static function ( $value ) {
						return is_string( $value ) && trim( $value ) !== '';
					}
				)
			)
		);
	}

	/**
	 * Register non-AS hooks explicitly. Must be called once after construction.
	 * AS-scoped hooks (process_item_background, check_and_finalize_job, sideload_featured_image)
	 * are registered via AS_Registry::register() only.
	 */
	public function register_hooks(): void {
		if ( $this->hooks_registered ) {
			return;
		}

		\add_action( 'seo_gen_job_finished', array( $this, 'handle_job_finished' ), 10, 3 );
		\add_action( 'seo_gen_process_draft_job', array( $this, 'handle_draft_processing' ), 10, 2 );
		\add_action( AS_Registry::HOOK_AUTO_GEN_CRON, array( $this, 'run_auto_generation' ) );

		$this->hooks_registered = true;
	}

	private function is_pipeline_paused(): bool {
		return \SEO_Article_Generator\Discovery\Discovery_Bootstrap::get_instance()->is_discovery_paused();
	}

	public function get_generation_gate(): array {
		return (array) $this->job_handler->get_generation_preflight();
	}

	/**
	 * Acquire a per-blog MySQL named lock for run_auto_generation().
	 * GET_LOCK(name, 0) is atomic — no TOCTOU. Returns true when lock is acquired.
	 */
	private function acquire_autogen_lock(): bool {
		global $wpdb;
		return 1 === (int) $wpdb->get_var(
			$wpdb->prepare( 'SELECT GET_LOCK(%s, 0)', 'seogen_autogen_' . get_current_blog_id() )
		);
	}

	/**
	 * Release the autogen MySQL named lock acquired by acquire_autogen_lock().
	 */
	private function release_autogen_lock(): void {
		global $wpdb;
		$wpdb->get_var(
			$wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', 'seogen_autogen_' . get_current_blog_id() )
		);
	}

	private function has_existing_pending_action( int $discovery_id ): bool {
		if ( ! function_exists( 'as_get_scheduled_actions' ) ) {
			return false;
		}
		foreach ( array( \ActionScheduler_Store::STATUS_PENDING, \ActionScheduler_Store::STATUS_RUNNING ) as $as_status ) {
			$existing = as_get_scheduled_actions(
				array(
					'hook'   => AS_Registry::HOOK_PROCESS_ITEM,
					'args'   => array( $discovery_id ),
					'status' => $as_status,
				),
				'ids'
			);
			if ( ! empty( $existing ) ) {
					return true;
			}
		}
		return false;
	}

	private function write_scheduled_at( int $discovery_id, ?int $utc_ts ): void {
		global $wpdb;

		$wpdb->update(
			Installer::table_discovery(),
			array(
				'scheduled_at' => $utc_ts ? Plugin_Time::utc_mysql_from_utc_ts( $utc_ts ) : null,
			),
			array( 'id' => $discovery_id ),
			array( '%s' ),
			array( '%d' )
		);
	}

	private function defer_discovery_without_job( int $discovery_id, int $user_id, int $delay_seconds, string $reason ): bool {
		global $wpdb;

		$table = Installer::table_discovery();

		if (
			class_exists( '\\SEO_Article_Generator\\AI\\AI_Client' ) &&
			method_exists( '\\SEO_Article_Generator\\AI\\AI_Client', 'is_daily_quota_error' ) &&
			\SEO_Article_Generator\AI\AI_Client::is_daily_quota_error( $reason )
		) {
			$gate         = $this->get_generation_gate();
			$api_reset_ts = ! empty( $gate['retry_after'] )
				? ( Plugin_Time::now_utc_ts() + max( 60, (int) $gate['retry_after'] ) )
				: 0;

			\SEO_Article_Generator\AI\AI_Client::set_daily_quota_block( $reason, $api_reset_ts );
		}

		AS_Registry::cancel_item_actions( $discovery_id );

		$updated = $wpdb->update(
			$table,
			array(
				'status'        => 'queued',
				'error_message' => null,
				'heartbeat_at'  => null,
				'scheduled_at'  => null,
				'completed_at'  => null,
			),
			array( 'id' => $discovery_id ),
			array( '%s', '%s', '%s', '%s', '%s' ),
			array( '%d' )
		);

		if ( $updated === false ) {
			$this->logger->error( 'Discovery ' . (int) $discovery_id . ' defer failed: Could not update status to queued' );
			return false;
		}

		if ( ! AS_Registry::schedule_process_item( $discovery_id, $user_id, max( 60, $delay_seconds ) ) ) {
			$this->restore_item_schedule_failure( $discovery_id, 'queued', $reason, null );
			return false;
		}

		$this->sync_scheduled_at_from_registry( $discovery_id, Plugin_Time::now_utc_ts() + max( 60, $delay_seconds ) );
		return true;
	}

	private function fail_discovery_configuration_block( int $discovery_id, string $reason ): void {
		$this->mark_discovery_failure( $discovery_id, 'failed', $reason );
	}

	private function discovery_enabled(): bool {
		return ! \SEO_Article_Generator\Discovery\Discovery_Bootstrap::get_instance()->is_discovery_paused();
	}

	private function get_pipeline_delay_seconds( bool $is_update, int $minimum_seconds ): int {
		$defaults = \SEO_Article_Generator\Option_Registry::defaults();
		if ( $is_update ) {
			$min_minutes = max(
				1,
				(int) \get_option(
					\SEO_Article_Generator\Option_Registry::UPDATE_DELAY_MIN,
					$defaults[ \SEO_Article_Generator\Option_Registry::UPDATE_DELAY_MIN ]
				)
			);
			$max_minutes = max(
				$min_minutes,
				(int) \get_option(
					\SEO_Article_Generator\Option_Registry::UPDATE_DELAY_MAX,
					$defaults[ \SEO_Article_Generator\Option_Registry::UPDATE_DELAY_MAX ]
				)
			);
		} else {
			$min_minutes = max(
				1,
				(int) \get_option(
					\SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MIN,
					$defaults[ \SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MIN ]
				)
			);
			$max_minutes = max(
				$min_minutes,
				(int) \get_option(
					\SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MAX,
					$defaults[ \SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MAX ]
				)
			);
		}

		return max(
			$minimum_seconds,
			\wp_rand( $min_minutes * MINUTE_IN_SECONDS, $max_minutes * MINUTE_IN_SECONDS )
		);
	}

	public function suspend_pipeline(): int {
		global $wpdb;

		$table = Installer::table_discovery();
		$rows  = $wpdb->get_results(
			"SELECT id
			 FROM {$table}
			 WHERE status IN ('queued','processing','generating','finalizing','deferred')"
		);

		$affected = 0;

		foreach ( (array) $rows as $row ) {
			AS_Registry::cancel_item_actions( (int) $row->id );
			++$affected;
		}

		// Reset 'processing' (no job yet) back to 'queued' so cleanup won't kill them.
		// Keep 'generating'/'finalizing' (live job) as-is so resume() can recover them.
		$wpdb->query(
			"UPDATE {$table}
			 SET status = 'queued',
				 error_message = NULL,
				 scheduled_at = NULL,
				 heartbeat_at = NULL
			 WHERE status = 'processing'"
		);
		$wpdb->query(
			"UPDATE {$table}
			 SET error_message = NULL,
				 scheduled_at = NULL,
				 heartbeat_at = NULL
			 WHERE status IN ('queued','generating','finalizing','deferred')"
		);

		return $affected;
	}

	public function resume_pipeline(): int {
		global $wpdb;

		$table = Installer::table_discovery();
		// [FINDING-1 UPDATE] Include timeout in resume query
				$rows = $wpdb->get_results(
					"SELECT id, status, job_id, queue_job_id, type, existing_post_id, scheduled_at
            FROM {$table}
            WHERE status IN ('queued','processing','generating','finalizing','failed','timeout','deferred')"
				);

		$user_id            = \get_current_user_id() ? (int) \get_current_user_id() : 1;
		$rearmed            = 0;
		$next_process_delay = 5;

		// Get clumping protection settings from Options
		$defaults    = \SEO_Article_Generator\Option_Registry::defaults();
		$min_minutes = max( 1, (int) \get_option( \SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MIN, $defaults[ \SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MIN ] ) );
		$max_minutes = max( $min_minutes, (int) \get_option( \SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MAX, $defaults[ \SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MAX ] ) );
		// Convert to seconds and use as base stagger range
		$resume_stagger_sec   = max( 60, (int) ( $min_minutes * 60 ) );
		$resume_stagger_range = max( $resume_stagger_sec, (int) ( $max_minutes * 60 ) );

		$poll_stagger_idx = 0;

		// Gate check: defer all rearming if provider is temporarily blocked
		$gate                         = $this->get_generation_gate();
		$pipeline_temporarily_blocked = empty( $gate['ok'] ) && ! empty( $gate['temporary'] );
		$pipeline_retry_after         = max( 60, (int) ( $gate['retry_after'] ?? 60 ) );

		foreach ( (array) $rows as $row ) {
			// Guard: Skip if no valid discovery item
			if ( empty( $row->id ) ) {
				continue;
			}

			$discovery_id = 0;
			try {
				$discovery_id = (int) $row->id;
			} catch ( \Throwable $e ) {
				continue;
			}

			if ( $discovery_id <= 0 ) {
				continue;
			}

			// Skip deferred items whose publish window hasn't arrived yet.
			// They are waiting for their scheduled_at — not stuck.
			if ( (string) $row->status === 'deferred' ) {
				$scheduled_at = (string) ( $row->scheduled_at ?? '' );
				if ( $scheduled_at !== '' && strtotime( $scheduled_at ) > time() ) {
					continue; // Still waiting for publish window
				}
				// If scheduled_at is in the past or empty, the check job was lost — fall through to re-arm
			}

			$status = (string) $row->status;
			$job_id = (int) ( $row->job_id ?? 0 );

			// [FINDING-1 UPDATE] Include timeout in status check
			if ( $job_id > 0 && in_array( $status, array( 'generating', 'finalizing', 'failed', 'timeout', 'deferred' ), true ) ) {
				$life = $this->job_handler->get_job_lifecycle_status( (int) $job_id );

				if ( ! empty( $life['should_fail'] ) ) {
					if (
						( $life['combined_status'] ?? '' ) === 'reconcile_failed' &&
						$this->recover_from_reconcile_failed_snapshot(
							$discovery_id,
							$job_id,
							(int) ( $life['user_id'] ?? $user_id ),
							'resume_pipeline'
						)
					) {
						++$rearmed;
						continue;
					}

					$this->mark_discovery_failure(
						$discovery_id,
						(string) ( $life['failure_status'] ?? 'failed' ),
						(string) ( $life['failure_reason'] ?? 'Resume found terminal job state.' )
					);
					++$rearmed;
					continue;
				}

				// [FINDING-1 UPDATE] Allow failed/timeout recovery when finalizing
				if ( ! empty( $life['should_finalize'] ) ) {
					$allow_failed_recovery = in_array( (string) $status, array( 'failed', 'timeout' ), true );

					$claimed = $this->claim_item_for_finalization(
						$discovery_id,
						(int) $job_id,
						$allow_failed_recovery
					);

					if ( $claimed ) {
						$this->auto_finalize( $claimed, (int) $job_id, (int) ( $life['user_id'] ?? $user_id ), false );
					}

					++$rearmed;
					continue;
				}
			}

			if ( ! empty( $life['should_continue'] ) ) {
				$gate = (array) $this->job_handler->get_generation_preflight();

				if ( ( $life['combined_status'] ?? '' ) === 'deferred' && empty( $gate['temporary'] ) ) {
					// Contract repair before deferred promotion
					$deferred_contract = Discovery_Engine::canonicalize_discovery_contract(
						(string) ( $row->type ?? '' ),
						(int) ( $row->existing_post_id ?? 0 )
					);

					if (
					(string) ( $row->type ?? '' ) !== $deferred_contract['type'] ||
					(int) ( $row->existing_post_id ?? 0 ) !== (int) $deferred_contract['existing_post_id']
					) {
						$wpdb->update(
							$table,
							array(
								'type'                     => $deferred_contract['type'],
								self::COL_EXISTING_POST_ID => (int) $deferred_contract['existing_post_id'],
							),
							array( 'id' => $discovery_id ),
							array( '%s', '%d' ),
							array( '%d' )
						);
									$this->logger->warning(
										'resume_pipeline deferred-promotion repaired contract.',
										array(
											'discovery_id' => $discovery_id,
											'resolved_type' => $deferred_contract['type'],
											'resolved_post' => (int) $deferred_contract['existing_post_id'],
										)
									);
					}

					AS_Registry::cancel_item_actions( $discovery_id );

					$wpdb->update(
						$table,
						array(
							'status'        => 'queued',
							'error_message' => null,
							'heartbeat_at'  => null,
							'scheduled_at'  => null,
							'job_id'        => null,
							'queue_job_id'  => null,
							'poll_count'    => 0,
						),
						array( 'id' => $discovery_id, 'status' => 'deferred' ),
						array( '%s', '%s', '%s', '%s', '%d', '%d', '%d' ),
						array( '%d', '%s' )
					);

					if ( $this->has_existing_pending_action( $discovery_id ) ) {
									$this->logger->info( 'Discovery ' . $discovery_id . ': resume_pipeline skipped — AS action already pending.' );
									$this->sync_scheduled_at_from_registry( $discovery_id, Plugin_Time::now_utc_ts() + $next_process_delay );
									++$rearmed;
									continue;
					}

					if ( AS_Registry::schedule_process_item( $discovery_id, $user_id, $next_process_delay ) ) {
								$this->sync_scheduled_at_from_registry( $discovery_id, Plugin_Time::now_utc_ts() + $next_process_delay );
								// Add random jitter within min/max range to prevent clumping
								$jitter              = rand( $resume_stagger_sec, $resume_stagger_range );
								$next_process_delay += $jitter;
								++$rearmed;
								continue;
					}

					$this->mark_discovery_failure( $discovery_id, 'failed', 'Resume could not re-arm previously deferred discovery item.' );
					++$rearmed;
					continue;
				}

				/*
				* Deferred jobs: schedule from available_at + clumping protection interval.
				* Use min/max interval settings from Options to prevent API rush when resuming.
				* Add deterministic bounded jitter so a batch of jobs sharing the same available_at
				* does not herd onto the same second.
				*/
				if ( ( $life['combined_status'] ?? '' ) === 'deferred' ) {
					$deferred_until = (int) ( $life['deferred_until'] ?? 0 );
					$now_ts         = Plugin_Time::now_utc_ts();
					// Use clumping protection settings instead of fixed POLL_INTERVAL
					$gap_seconds = rand( $min_minutes * 60, $max_minutes * 60 );
					// Add deterministic jitter based on discovery/job ID to prevent exact collisions
					$deferred_jitter = ( $discovery_id + max( 0, (int) $job_id ) ) % 60;

					$delay = ( $deferred_until > $now_ts )
					? max( $gap_seconds, ( $deferred_until - $now_ts ) + 5 + $deferred_jitter )
					: $gap_seconds + $deferred_jitter;
				} else {
					// Non-deferred jobs: use staggered timing with random jitter
					$jitter = rand( 0, 30 );
					$delay  = 5 + ( $poll_stagger_idx * $resume_stagger_sec ) + $jitter;
					++$poll_stagger_idx;
				}
				// If there's already a pending job with future available_at
				// (set by revive_cooldown_jobs), honour it to prevent premature processing.
				// FIX: Stale available_at (in the past or <30s away) from pause-time deferral
				// must be re-staggered to prevent API rush on resume.
				if ( ! empty( $life['job_id'] ) && $life['job_id'] > 0 ) {
					$job_row = $wpdb->get_row(
						$wpdb->prepare(
							"SELECT available_at FROM {$wpdb->prefix}seo_gen_jobs WHERE id = %d AND status IN ('pending','deferred') LIMIT 1",
							(int) $life['job_id']
						),
						ARRAY_A
					);

					if ( ! empty( $job_row['available_at'] ) ) {
						$existing_ts = Plugin_Time::utc_ts_from_utc_mysql( $job_row['available_at'] );
						$now_ts      = Plugin_Time::now_utc_ts();

						if ( $existing_ts > $now_ts + 30 ) {
							// Respect the stagger - align delay to the job's available_at
							$delay = max( $delay, $existing_ts - $now_ts + rand( 1, 10 ) );
						} else {
							// Stale available_at from pause-time deferral — restagger to prevent API rush
							$staggered_ts    = $now_ts + $delay;
							$staggered_mysql = Plugin_Time::utc_mysql_from_utc_ts( $staggered_ts );
							$wpdb->update(
								$wpdb->prefix . 'seo_gen_jobs',
								array( 'available_at' => $staggered_mysql ),
								array( 'id' => (int) $life['job_id'] ),
								array( '%s' ),
								array( '%d' )
							);
							if ( ! empty( $row->queue_job_id ) && (int) $row->queue_job_id > 0 ) {
								$wpdb->update(
									Installer::table_queue(),
									array( 'available_at' => $staggered_mysql ),
									array( 'id' => (int) $row->queue_job_id ),
									array( '%s' ),
									array( '%d' )
								);
							}
						}
					}
				}
				$wpdb->update(
					$table,
					array(
						'error_message' => null,
						'heartbeat_at'  => null,
						'scheduled_at'  => null,
						'poll_count'    => 0,
					),
					array( 'id' => $discovery_id ),
					array( '%s', '%s', '%s', '%d' ),
					array( '%d' )
				);

				if ( AS_Registry::schedule_check_job( $discovery_id, (int) $job_id, $user_id, 1, $delay ) ) {
					$this->write_scheduled_at( $discovery_id, Plugin_Time::now_utc_ts() + $delay );
					++$rearmed;
				} else {
					$this->mark_discovery_failure(
						$discovery_id,
						'failed',
						'Resume failed: lifecycle poll could not be re-armed.'
					);
					++$rearmed;
				}
				continue;
			}

			// Queued / processing (no job): reset contract, wipe identity, re-arm.
			$resume_type    = (string) ( $row->type ?? '' );
			$resume_post_id = (int) ( $row->existing_post_id ?? 0 );

			if ( $resume_type !== '' || $resume_post_id > 0 ) {
				$resume_contract = Discovery_Engine::canonicalize_discovery_contract(
					$resume_type,
					$resume_post_id
				);

				if (
					$resume_type !== $resume_contract['type'] ||
					$resume_post_id !== (int) $resume_contract['existing_post_id']
				) {
					$wpdb->update(
						$table,
						array(
							'type'                     => $resume_contract['type'],
							self::COL_EXISTING_POST_ID => (int) $resume_contract['existing_post_id'],
						),
						array( 'id' => $discovery_id ),
						array( '%s', '%d' ),
						array( '%d' )
					);
					$this->logger->warning(
						'resume_pipeline repaired discovery contract.',
						array(
							'discovery_id'  => $discovery_id,
							'resolved_type' => $resume_contract['type'],
							'resolved_post' => (int) $resume_contract['existing_post_id'],
						)
					);
					$resume_post_id = (int) $resume_contract['existing_post_id'];
				}
			}

			$wpdb->update(
				$table,
				array(
					'status'        => 'queued',
					'error_message' => null,
					'heartbeat_at'  => null,
					'scheduled_at'  => null,
					'poll_count'    => 0,
				),
				array( 'id' => $discovery_id ),
				array( '%s', '%s', '%s', '%s', '%d' ),
				array( '%d' )
			);

			$is_update = $resume_post_id > 0;
			$delay     = $this->get_pipeline_delay_seconds( $is_update, $is_update ? 60 : 30 );

			if ( $pipeline_temporarily_blocked ) {
				$delay = max( $delay, $pipeline_retry_after );
			}

			if ( $this->has_existing_pending_action( $discovery_id ) ) {
				$this->logger->info( 'Discovery ' . $discovery_id . ': resume_pipeline queued-path skipped — AS action already pending.' );
				$this->sync_scheduled_at_from_registry( $discovery_id, Plugin_Time::now_utc_ts() + $delay );
				++$rearmed;
				continue;
			}

			if ( AS_Registry::schedule_process_item( $discovery_id, $user_id, $delay ) ) {
				$this->sync_scheduled_at_from_registry( $discovery_id, Plugin_Time::now_utc_ts() + $delay );
				++$rearmed;
			} else {
				$this->mark_discovery_failure( $discovery_id, 'failed', 'Resume could not re-arm queued/processing discovery item.' );
				++$rearmed;
			}
		}

		return $rearmed;
	}

	public function approve_item( $discovery_id, $user_id, $delay_seconds = 30 ) {
		global $wpdb;

		$table         = Installer::table_discovery();
		$delay_seconds = max( 30, (int) $delay_seconds );

		// Pre-enqueue sentinel gate: for existing posts, check sentinels BEFORE
		// the item waits its staggered delay. If no sentinels, set the legacy rewrite
		// flag now so process_item_background skips the expensive on-the-fly migration.
		// Uses Post_Type_Classifier::has_sentinel_structure() as single SSOT.
		$item_pre = $this->get_item( (int) $discovery_id, array( 'id', 'status', 'existing_post_id', 'type', 'consecutive_failures' ) );
		if ( $item_pre && ! empty( $item_pre->existing_post_id ) && (int) $item_pre->existing_post_id > 0 ) {
			$existing_content = \get_post_field( 'post_content', (int) $item_pre->existing_post_id, 'raw' );
			if ( is_string( $existing_content ) && ! empty( trim( $existing_content ) ) ) {
				$has_any_sentinels = Post_Type_Classifier::has_sentinel_structure( $existing_content );
				if ( ! $has_any_sentinels ) {
					\update_post_meta( (int) $item_pre->existing_post_id, '_seo_gen_force_legacy_rewrite', '1' );
					$this->logger->info(
						sprintf(
							'approve_item: Post %d has no sentinels. Pre-set _seo_gen_force_legacy_rewrite to bypass sentinel check at generation time.',
							(int) $item_pre->existing_post_id
						)
					);
				}
			}
		}

		// FIX F4 (Phase 3A): refuse tripped (parked) items — manual Retry/Run-now resets the breaker.
		if ( $item_pre && (int) ( $item_pre->consecutive_failures ?? 0 ) >= self::MAX_CONSECUTIVE_FAILURES ) {
			$park_message = sprintf(
				'Parked after %d consecutive failures — use Retry or Run Now to run it again.',
				(int) $item_pre->consecutive_failures
			);
			$wpdb->update(
				$table,
				array( 'error_message' => $park_message ),
				array( 'id' => (int) $discovery_id ),
				array( '%s' ),
				array( '%d' )
			);
			$this->logger->warning( 'Discovery ' . (int) $discovery_id . ' approval refused: ' . $park_message );
			return false;
		}

		$claimed = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table}
            SET status = 'queued', error_message = NULL, completed_at = NULL, poll_count = 0
            WHERE id = %d AND status = 'pending'",
				$discovery_id
			)
		);
		if ( ! $claimed ) {
			$current_status = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT status FROM {$table} WHERE id = %d",
					$discovery_id
				)
			);

			$error_message = 'Item is no longer in pending status';
			if ( $current_status ) {
				$error_message = sprintf( 'Item is already %s', $current_status );
			}

			$wpdb->update(
				$table,
				array( 'error_message' => $error_message ),
				array( 'id' => $discovery_id ),
				array( '%s' ),
				array( '%d' )
			);

			$this->logger->warning(
				'Discovery ' . (int) $discovery_id . ' approval failed: ' . $error_message,
				array( 'current_status' => $current_status )
			);

			return false;
		}

		$item = $this->get_item( (int) $discovery_id, array( 'id', 'type', 'existing_post_id' ) );

		if ( ! $item ) {
			$this->restore_item_schedule_failure( (int) $discovery_id, 'pending', 'Item not found after status update', null );
			$this->logger->error( 'Discovery ' . (int) $discovery_id . ' approval failed: Item not found after status update' );
			return false;
		}

		// Canonicalize type/post contract before queueing
		$current_post_id = ! empty( $item->existing_post_id ) ? (int) $item->existing_post_id : 0;

		$contract = Discovery_Engine::canonicalize_discovery_contract(
			(string) ( $item->type ?? 'legacy' ),
			$current_post_id
		);

		if (
			(string) ( $item->type ?? '' ) !== $contract['type'] ||
			(int) ( $item->existing_post_id ?? 0 ) !== (int) $contract['existing_post_id']
		) {
			$wpdb->update(
				$table,
				array(
					'type'                     => $contract['type'],
					self::COL_EXISTING_POST_ID => (int) $contract['existing_post_id'],
				),
				array( 'id' => (int) $discovery_id ),
				array( '%s', '%d' ),
				array( '%d' )
			);

			$this->logger->warning(
				'approve_item repaired discovery contract before queueing.',
				array(
					'discovery_id'              => (int) $discovery_id,
					'resolved_type'             => $contract['type'],
					'resolved_existing_post_id' => (int) $contract['existing_post_id'],
				)
			);

			$item->type             = $contract['type'];
			$item->existing_post_id = (int) $contract['existing_post_id'];
		}

		// Plugin filter gate: reject plugin-generated items when filter is active
		if (
			(int) \get_option( Discovery_Engine::PLUGIN_FILTER_OPTION, 0 ) === 1
			&& Post_Type_Classifier::is_plugin_owned( $contract['type'] ?? '' )
		) {
			// FIX F0 (Phase 3A): route through the failure SSOT (cancels actions itself).
			$this->mark_discovery_failure( (int) $discovery_id, 'failed', Discovery_Engine::PLUGIN_FILTER_ERROR );

			$this->logger->warning(
				'Discovery ' . (int) $discovery_id . ' approval blocked by plugin-generated filter.'
			);

			return false;
		}

		if ( ! empty( $item->existing_post_id ) ) {
			$this->persist_regen_sections_snapshot( (int) $item->existing_post_id );
		}

		$_dq_quota    = class_exists( '\\SEO_Article_Generator\\AI\\AI_Client' ) && method_exists( '\\SEO_Article_Generator\\AI\\AI_Client', 'get_daily_quota_status' )
			? \SEO_Article_Generator\AI\AI_Client::get_daily_quota_status()
			: array( 'reset_utc_ts' => 0 );
		$_dq_reset_ts = max( 0, (int) ( $_dq_quota['reset_utc_ts'] ?? 0 ) );
		if ( $_dq_reset_ts > 0 && Plugin_Time::now_utc_ts() < $_dq_reset_ts ) {
			$_dq_remaining = $_dq_reset_ts - Plugin_Time::now_utc_ts();
			$_dq_reason    = sprintf(
				'Daily API quota exhausted. Quota resets at %s UTC.',
				Plugin_Time::utc_mysql_from_utc_ts( $_dq_reset_ts )
			);
			if ( ! $this->defer_discovery_without_job(
				(int) $discovery_id,
				(int) $user_id,
				max( 300, $_dq_remaining + 300 ),
				$_dq_reason
			) ) {
				$this->restore_item_schedule_failure( (int) $discovery_id, 'pending', 'Failed to defer discovery due to daily quota', null );
				$this->logger->error(
					'Discovery ' . (int) $discovery_id . ' DQ-defer failed — restored to pending to prevent orphaned queued state.'
				);
				return false;
			}
			$this->logger->warning( 'Discovery ' . (int) $discovery_id . ' approval deferred — ' . $_dq_reason );
			return true;
		}

		$gate = $this->get_generation_gate();
		if ( empty( $gate['ok'] ) ) {
			if ( ! empty( $gate['temporary'] ) ) {
				$delay = max( 60, (int) ( $gate['retry_after'] ?? 300 ) );

				if ( ! $this->defer_discovery_without_job( (int) $discovery_id, (int) $user_id, $delay, (string) $gate['reason'] ) ) {
					$this->restore_item_schedule_failure( (int) $discovery_id, 'pending', 'Failed to defer discovery due to temporary gate: ' . (string) $gate['reason'], null );
					return false;
				}

				$this->logger->warning(
					'Discovery ' . (int) $discovery_id . ' queued but delayed before job creation: ' . (string) $gate['reason']
				);

				return true;
			}

			$this->fail_discovery_configuration_block( (int) $discovery_id, (string) $gate['reason'] );
			$this->logger->error(
				'Discovery ' . (int) $discovery_id . ' rejected before job creation: ' . (string) $gate['reason']
			);
			return false;
		}

		$is_update = ! empty( $item->existing_post_id );

		$effective_delay = max(
			(int) $delay_seconds,
			$this->get_pipeline_delay_seconds( $is_update, $is_update ? 60 : 30 )
		);

		AS_Registry::cancel_item_actions( (int) $discovery_id );

		if ( $this->has_existing_pending_action( (int) $discovery_id ) ) {
			$this->logger->info( 'Discovery ' . (int) $discovery_id . ': AS action already pending, skipping duplicate schedule.' );
			$this->sync_scheduled_at_from_registry( (int) $discovery_id, Plugin_Time::now_utc_ts() + $effective_delay );
			return true;
		}

		if ( ! AS_Registry::schedule_process_item( (int) $discovery_id, (int) $user_id, $effective_delay ) ) {
			$this->restore_item_schedule_failure( (int) $discovery_id, 'pending', 'Action Scheduler refused process-item schedule', null );
			$this->logger->error( 'Discovery ' . (int) $discovery_id . ' approval failed: Action Scheduler refused process-item schedule.' );
			return false;
		}

		$verify_ts   = 0;
		$max_retries = 3;
		for ( $retry = 0; $retry < $max_retries; $retry++ ) {
			if ( $retry > 0 ) {
				usleep( 500000 );
			}
			$this->sync_scheduled_at_from_registry( (int) $discovery_id, Plugin_Time::now_utc_ts() + $effective_delay );
			$verify_item = $this->get_item( (int) $discovery_id, array( 'scheduled_at' ) );
			$verify_ts   = 0;
			if ( $verify_item && ! empty( $verify_item->scheduled_at ) ) {
				$verify_ts = (int) strtotime( $verify_item->scheduled_at . ' UTC' );
			}
			if ( $verify_ts > 0 ) {
				break;
			}
		}

		// MODIFIED: Keep item queued with fallback instead of restoring to pending
		if ( $verify_ts <= 0 ) {
			$fallback_utc = Plugin_Time::now_utc_ts() + $effective_delay;
			$this->write_scheduled_at( (int) $discovery_id, $fallback_utc );
			$this->invalidate_dashboard_caches();
			$this->logger->warning(
				'Discovery ' . (int) $discovery_id . ' scheduled_at could not be confirmed from Action Scheduler immediately; keeping queued with fallback timestamp.'
			);
			return true;
		}

		// N1 FIX: Flush snapshot cache so AJAX returns fresh pending count
		$this->invalidate_dashboard_caches();

		$scheduled_utc = AS_Registry::get_next_item_run( (int) $discovery_id );

		$this->logger->info(
			'Discovery ' . (int) $discovery_id . ' approved. Scheduled for ' .
			Plugin_Time::utc_mysql_from_utc_ts( $scheduled_utc ) . ' UTC'
		);

		return true;
	}

	public function handle_draft_processing( int $item_id, int $user_id ) {
		$this->logger->info( "Draft Ingestion: Triggering background worker for Discovery #{$item_id}" );
		return $this->process_item_background( $item_id, $user_id );
	}

	public function process_item_background( $discovery_id, $user_id = 0 ) {
		global $wpdb;

		$table = Installer::table_discovery();

		if ( $user_id <= 0 ) {
			$user_id = \get_current_user_id() ? (int) \get_current_user_id() : 1;
		}

		if ( $this->is_pipeline_paused() ) {
			AS_Registry::cancel_item_actions( (int) $discovery_id );
			$this->restore_item_schedule_failure( (int) $discovery_id, 'queued', null, null );
			$this->logger->info( "Discovery #{$discovery_id} frozen: Engine is Paused." );
			return;
		}

		// FIX A2 (2026-09-06): lifecycle-aware pre-claim gate. Replaces dead Fix A
		// (which tested status AFTER the claim had already flipped it to
		// 'processing', so it could never fire). Overdue Recovery — and any other
		// caller — can invoke this method for a row that is back in 'queued' while
		// its AI job is still alive. Spawning here wipes job_id (Step A zeroes it)
		// and orphans the live job's completion: the 09-05 death loop (2752
		// duplicate jobs, 433 dropped completions). Mirrors run_item_now()
		// semantics: finalize when ready, re-arm the check-job when the job is
		// alive, spawn only when the previous job is dead or missing.
		$preclaim = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT id, status, job_id, queue_job_id FROM {$table} WHERE id = %d",
				$discovery_id
			),
			ARRAY_A
		);
		if ( $preclaim && (string) ( $preclaim['status'] ?? '' ) === 'queued' && (int) ( $preclaim['job_id'] ?? 0 ) > 0 ) {
			$preclaim_job_id = (int) $preclaim['job_id'];
			$preclaim_life   = $this->job_handler->get_job_lifecycle_status( $preclaim_job_id );

			if ( ! empty( $preclaim_life['should_finalize'] ) ) {
				$preclaim_claimed = $this->claim_item_for_finalization( (int) $discovery_id, $preclaim_job_id, true );
				if ( $preclaim_claimed ) {
					$this->auto_finalize( $preclaim_claimed, $preclaim_job_id, (int) ( $preclaim_life['user_id'] ?? $user_id ), true );
					return;
				}
				$this->logger->warning( "Discovery {$discovery_id} pre-claim: job {$preclaim_job_id} complete but claim failed; falling through to normal processing." );
			} elseif ( ! empty( $preclaim_life['should_continue'] ) ) {
				// Job alive — restore 'generating', re-arm its check-job, spawn nothing.
				$preclaim_combined = (string) ( $preclaim_life['combined_status'] ?? '' );
				$preclaim_delay    = self::POLL_INTERVAL;
				if ( $preclaim_combined === 'deferred' ) {
					$preclaim_deferred_until = (int) ( $preclaim_life['deferred_until'] ?? 0 );
					$preclaim_now_ts         = Plugin_Time::now_utc_ts();
					$preclaim_jitter         = max( 1, (int) $discovery_id % self::POLL_INTERVAL );
					$preclaim_delay          = $preclaim_deferred_until > $preclaim_now_ts
						? max( self::POLL_INTERVAL, ( $preclaim_deferred_until - $preclaim_now_ts ) + 5 + $preclaim_jitter )
						: max( self::POLL_INTERVAL, 5 + $preclaim_jitter );
				}
				$preclaim_restored = $wpdb->query(
					$wpdb->prepare(
						"UPDATE {$table}
						 SET status = 'generating', heartbeat_at = %s, poll_count = 0, error_message = NULL
						 WHERE id = %d AND status = 'queued'",
						Plugin_Time::utc_mysql_now(),
						$discovery_id
					)
				);
				if ( (int) $preclaim_restored === 1 ) {
					$this->clear_effective_poll_count( (int) $discovery_id );
					if ( AS_Registry::schedule_check_job( (int) $discovery_id, $preclaim_job_id, (int) $user_id, 1, $preclaim_delay ) ) {
						$this->sync_scheduled_at_from_registry( (int) $discovery_id, Plugin_Time::now_utc_ts() + $preclaim_delay );
					} else {
						$this->logger->error( "Discovery {$discovery_id} pre-claim: live job {$preclaim_job_id} restored to generating but check-job re-arm failed." );
					}
					$this->logger->info( "Discovery {$discovery_id} pre-claim: job {$preclaim_job_id} alive ({$preclaim_combined}) — re-armed check-job, no duplicate spawn." );
				}
				return;
			}
			// should_fail / missing / unrecognized → fall through to claim + spawn fresh.
		}

		$claimed = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table}
				 SET status = 'processing', heartbeat_at = %s
				 WHERE id = %d AND status = 'queued'",
				Plugin_Time::utc_mysql_now(),
				$discovery_id
			)
		);

		if ( ! $claimed ) {
			return;
		}

		@ignore_user_abort( true );
		@set_time_limit( 300 );

		$item = $this->get_item( (int) $discovery_id );

		if ( ! $item ) {
			$this->logger->error( 'Discovery ' . (int) $discovery_id . ' could not be reloaded after claim; marking failed to avoid a stuck row.' );
			$this->mark_discovery_failure(
				(int) $discovery_id,
				'failed',
				'Discovery row could not be reloaded after claim.'
			);
			return;
		}

		// GUARD A: re-verify the live post version is still older than what was
		// staged. The discovery's discovered_version is the new version; the
		// discovery's current_version is a snapshot frozen at staging time (see
		// Discovery_Engine::stage_wp_auto_item). A sibling discovery may have
		// finalized and updated the same post in the meantime. Reading the live
		// post version is the only way to know. Skipping here saves the AI call
		// AND prevents a duplicate re-write of identical content.
		if ( ! empty( $item->existing_post_id ) ) {
			$live_post_id   = (int) $item->existing_post_id;
			$staged_version = trim( (string) ( $item->discovered_version ?? '' ) );

			if ( $staged_version !== '' && \get_post( $live_post_id ) ) {
				$live_version = SeoGen_Version_Resolver::current_version( $live_post_id );

				if ( $live_version !== ''
					&& strcasecmp( $live_version, 'unknown' ) !== 0
					&& ! Title_Analyzer::is_newer_version( $staged_version, $live_version, $this->logger )
				) {
					AS_Registry::cancel_item_actions( (int) $discovery_id );

					$wpdb->update(
						$table,
						array(
							self::COL_STATUS        => Discovery_Engine::STATUS_SKIPPED_NOT_NEWER,
							self::COL_ERROR_MESSAGE => sprintf(
								'Skipped at process entry: post %d is already at version %s (staged: %s). Sibling discovery finalized the same update while this row was queued.',
								$live_post_id,
								$live_version,
								$staged_version
							),
							self::COL_HEARTBEAT_AT  => null,
							self::COL_SCHEDULED_AT  => null,
							self::COL_COMPLETED_AT  => Plugin_Time::utc_mysql_now(),
							self::COL_JOB_ID        => null,
							self::COL_QUEUE_JOB_ID  => null,
						),
						array( 'id' => (int) $discovery_id ),
						array( '%s', '%s', '%s', '%s', '%s', '%d', '%d' ),
						array( '%d' )
					);

					$this->invalidate_dashboard_caches();
					$this->logger->info(
						sprintf(
							'Discovery %d: skipped_not_newer at process entry. Post %d live version=%s, staged=%s. No API call, no job, no re-update.',
							(int) $discovery_id,
							$live_post_id,
							$live_version,
							$staged_version
						)
					);
					return;
				}
			}
		}

		// Plugin filter gate: block plugin-generated items when filter is active
		// [FINDING-3 FIX] Moved BEFORE draft deferral to avoid unnecessary unschedule calls
		$contract = Discovery_Engine::canonicalize_discovery_contract(
			(string) ( $item->type ?? '' ),
			(int) ( $item->existing_post_id ?? 0 )
		);

		if (
			(int) \get_option( Discovery_Engine::PLUGIN_FILTER_OPTION, 0 ) === 1
			&& Post_Type_Classifier::is_plugin_owned( $contract['type'] ?? '' )
		) {
			// FIX F0 (Phase 3A): route through the failure SSOT. A live job from a
			// previous cycle is orphaned here and F2 refuses it pre-lease, so no AI
			// burns on a blocked item.
			$this->mark_discovery_failure( (int) $discovery_id, 'failed', Discovery_Engine::PLUGIN_FILTER_ERROR );

			$this->logger->warning(
				'Discovery ' . (int) $discovery_id . ' processing blocked by plugin-generated filter.'
			);
			return;
		}

		// FINDING-8 FIX: If this is a WP-Auto item with a pending draft deletion,
		// cancel the deletion now. The draft will be re-scheduled for deletion after
		// finalization (done/failed) to ensure the generation run has full access to the content.
		// [FINDING-3 FIX] Moved AFTER plugin filter gate - only defer for items that actually proceed
		if (
			! empty( $item->source_type ) && $item->source_type === 'wp_automatic'
			&& (int) ( $item->draft_post_id ?? 0 ) > 0
		) {
			AS_Registry::unschedule_all( AS_Registry::HOOK_DELETE_DRAFT, array( (int) $item->draft_post_id ) );
			$this->logger->info(
				sprintf(
					'Discovery %d: deferred WP-Auto draft deletion for draft %d until finalization.',
					$discovery_id,
					(int) $item->draft_post_id
				)
			);
		}

		try {
			$_dq_quota    = class_exists( '\\SEO_Article_Generator\\AI\\AI_Client' ) && method_exists( '\\SEO_Article_Generator\\AI\\AI_Client', 'get_daily_quota_status' )
				? \SEO_Article_Generator\AI\AI_Client::get_daily_quota_status()
				: array( 'reset_utc_ts' => 0 );
			$_dq_reset_ts = max( 0, (int) ( $_dq_quota['reset_utc_ts'] ?? 0 ) );
			if ( $_dq_reset_ts > 0 && Plugin_Time::now_utc_ts() < $_dq_reset_ts ) {
				$_dq_remaining = $_dq_reset_ts - Plugin_Time::now_utc_ts();
				$_dq_reason    = sprintf(
					'Daily API quota exhausted. Deferred until %s UTC.',
					Plugin_Time::utc_mysql_from_utc_ts( $_dq_reset_ts )
				);
				if ( ! $this->defer_discovery_without_job(
					(int) $discovery_id,
					(int) $user_id,
					max( 300, $_dq_remaining + 300 ),
					$_dq_reason
				) ) {
					throw new \Exception( 'Failed to defer item during daily quota block.' );
				}
				$this->logger->warning( 'Discovery ' . (int) $discovery_id . ' deferred — ' . $_dq_reason );
				return;
			}

			$raw_html  = $item->changelog ?? '';
			$link_html = $raw_html;

			if ( $item->source_type === 'wp_automatic' && $item->draft_post_id ) {
				$draft = \get_post( $item->draft_post_id );
				if ( $draft ) {
					$link_html = $draft->post_content . "\n" . $link_html;
				}
			}

			// R1 FIX: Read Phase-1 transient FIRST, prefer it over fresh extraction.
			// Always delete the transient to prevent orphaned wp_options rows.
			$phase1_facts = \get_transient( 'seo_gen_source_facts_' . (int) $item->id );
			\delete_transient( 'seo_gen_source_facts_' . (int) $item->id );   // always purge
			\delete_transient( 'seo_gen_classification_' . (int) $item->id ); // always purge

			// C1 FIX: Capture phase-1 extras in LOCAL variables so they survive $input_data construction.
			$p1_approved_links   = array();
			$p1_target_platforms = array();
			$p1_os_support       = '';
			$use_phase1_links    = false;

			if ( is_array( $phase1_facts ) && ! empty( $phase1_facts['resolved_links'] ) ) {
				$p1_approved_links   = $phase1_facts['resolved_links'];
				$p1_target_platforms = $phase1_facts['target_platforms'] ?? array();
				$p1_os_support       = (string) ( $phase1_facts['os_support'] ?? '' );
				$use_phase1_links    = true;
				$this->logger->info( 'Discovery ' . (int) $item->id . ' using Phase-1 resolved links (' . count( $p1_approved_links ) . ') from source facts transient.' );
			}

			// Fresh extraction fallback (used when Phase-1 transient expired/missing).
			$extracted      = array();
			$approved_links = array();

			if ( ! $use_phase1_links ) {
				$extracted      = \SEO_Article_Generator\Discovery\Data_Extractor::extract(
					(string) $link_html,
					array(
						'source_url'    => (string) ( $item->source_url ?? '' ),
						'software_name' => (string) ( $item->software_name ?? '' ),
					)
				);
				$approved_links = $extracted['all_links'] ?? array();
			} else {
				$approved_links = $p1_approved_links;
			}

			$is_update = !empty($item->existing_post_id);
			$approved_links = self::reconcile_download_sources($approved_links, (string) $link_html,
				(int) ($item->existing_post_id ?? 0), (string) ($item->software_name ?? ''),
				(string) ($item->source_url ?? ''), $this->logger, (int) $item->id,
				$is_update);
			$p1_target_platforms = \SEO_Article_Generator\Generator\Download_Link_Helper::link_platforms($approved_links);
			$p1_os_support = implode(', ', $p1_target_platforms);

			// --- PRE-FLIGHT LINK GATE ---
			// @MODIFIED 2026-04-03: A new post with zero download links cannot produce a valid article.
			// Fail immediately — no job row, no queue ticket, no API call.
			// @MODIFIED 2026-05-04: UPDATE path now validates Link Continuity viability BEFORE
			// allowing the job through. If neither fresh links nor existing post links exist,
			// the API call is guaranteed to fail at the completeness gate — abort early.
			// @MODIFIED 2026-06-06: When the source URL itself is in the admin-configured
			// download allowlist, inject it as a portal fallback so SPA / PWA / web-app
			// software (where the product page IS the download) bypasses the gate. Mirrors
			// the shape used by the update-path portal fallback below.
			$is_new_post = empty( $item->existing_post_id );

			if ( empty( $approved_links ) ) {
				$_source_url = (string) ( $item->source_url ?? '' );
				if ( $_source_url !== ''
					&& class_exists( '\\SEO_Article_Generator\\Generator\\Download_Link_Helper' )
					&& \SEO_Article_Generator\Generator\Download_Link_Helper::is_url_in_allowlist( $_source_url )
					&& \SEO_Article_Generator\Generator\Download_Link_Helper::respect_manual_removals(array(array('url'=>$_source_url)), (int)($item->existing_post_id ?? 0))
				) {
					$approved_links[] = array(
						'url'              => $_source_url,
						'text'             => 'Official Download',
						'platform'         => 'Other',
						'variant'          => 'Standard',
						'link_type'        => 'portal',
						'confidence'       => 1.0,
						'approved'         => true,
						'is_primary'       => true,
						'_portal_fallback' => true,
					);
					$this->logger->info( sprintf(
						'Discovery %d: source URL is in the download allowlist; injected as portal fallback to bypass pre-flight gate.',
						$discovery_id
					) );
				}
			}

			if ( empty( $approved_links ) ) {
				if ( $is_new_post ) {
					$this->logger->warning(
						sprintf(
							'Discovery %d aborted pre-flight: no downloadable links found for new post. '
							. 'API call prevented. Dismissing and cleaning up source.',
							$discovery_id
						)
					);
					$this->mark_discovery_failure(
						$discovery_id,
						'failed',
						'No downloadable links found. Article generation requires at least one real download '
						. 'link for a new post. API call was not made. Re-run discovery or add links manually.'
					);
					$this->dismiss_and_cleanup_source( $discovery_id );
					return;
				}

				// UPDATE path: validate Link Continuity viability before proceeding.
				// If the existing post has no recoverable download links either, the AI call
				// is guaranteed to fail at the completeness gate — abort now, save the API call.
				$_lc_recovered = array('links' => \SEO_Article_Generator\Integration\Link_Resolver::recover_existing_post_links((int)$item->existing_post_id, (string)($item->software_name ?? '')));
				$_lc_has_real_links  = ! empty( $_lc_recovered['links'] ) && is_array( $_lc_recovered['links'] );

				if ( ! $_lc_has_real_links ) {
					$this->logger->warning(
						sprintf(
							'Discovery %d aborted pre-flight: no downloadable links in source AND no recoverable links in existing post %d. '
							. 'API call prevented. Dismissing and cleaning up source.',
							$discovery_id,
							(int) $item->existing_post_id
						)
					);
					$this->mark_discovery_failure(
						$discovery_id,
						'failed',
						'No downloadable links found in source or existing post content. '
						. 'Article generation requires at least one real download link. '
						. 'API call was not made. Add download links to the source or existing post and re-run discovery.'
					);
					$this->dismiss_and_cleanup_source( $discovery_id );
					return;
				}

				// @MODIFIED 2026-07-04: Promote ALL verifiable recoverable links into
				// canonical, not just one portal-fallback link. Previously (FACT
				// integrity regression for posts 1215, 865, 382, 262, 255, 157
				// across logs 2026-07-02 / 2026-07-03) this block added a single
				// portal-fallback URL and logged N=verified. The N recoverable
				// URLs were silently discarded. Now they are promoted into
				// approved_links, with portal-fallback kept only as last-resort.
				$_recovered_count        = 0;
				if ( ! empty( $_lc_recovered['links'] ) && is_array( $_lc_recovered['links'] ) ) {
					foreach ( $_lc_recovered['links'] as $rl ) {
						if ( ! is_array( $rl ) || empty( $rl['url'] ) ) {
							continue;
						}
						$approved_links[] = array_merge(
							$rl,
							array(
								'approved'         => true,
								'_portal_fallback' => false,
							)
						);
						$_recovered_count++;
					}
				}

				// Last-resort portal fallback only when no real recovered URLs existed.
				if ( 0 === $_recovered_count ) {
					$approved_links[] = array(
						'url'              => (string) ( $item->source_url ?? '' ),
						'text'             => 'Official Website',
						'platform'         => 'Other',
						'variant'          => 'Standard',
						'link_type'        => 'portal',
						'confidence'       => 1.0,
						'approved'         => true,
						'is_primary'       => true,
						'_portal_fallback' => true,
					);
					$this->logger->info(
						sprintf(
							'Discovery %d (update, post %d): no fresh links found, no valid recoverable links. Portal fallback injected as last resort.',
							$discovery_id,
							(int) $item->existing_post_id
						)
					);
				} else {
					$this->logger->info(
						sprintf(
							'Discovery %d (update, post %d): no fresh links found. Promoted %d recoverable link(s) from existing post content into approved_links.',
							$discovery_id,
							(int) $item->existing_post_id,
							$_recovered_count
						)
					);
				}
			}
			// --- END PRE-FLIGHT LINK GATE ---

			// C1 FIX: Build $input_data ONCE, using local variables to preserve Phase-1 data.
			// FINDING-2 FIX: Authoritative version reconciliation
			$approved_links = \SEO_Article_Generator\Generator\Download_Link_Helper::normalize_links($approved_links, 'Other');
			$p1_target_platforms = \SEO_Article_Generator\Generator\Download_Link_Helper::link_platforms($approved_links);
			$p1_os_support = implode(', ', $p1_target_platforms);

			$stored_discovered_version = is_string( $item->discovered_version ?? null ) ? trim( (string) $item->discovered_version ) : '';
			$runtime_version           = $stored_discovered_version;
			if ( $runtime_version === '' && ! empty( $extracted['version'] ) && is_string( $extracted['version'] ) ) {
				$runtime_version = trim( (string) $extracted['version'] );
			}
			if ( $runtime_version !== '' && $runtime_version !== $stored_discovered_version ) {
				$wpdb->update(
					$table,
					array( 'discovered_version' => $runtime_version ),
					array( 'id' => (int) $discovery_id ),
					array( '%s' ),
					array( '%d' )
				);
				$item->discovered_version = $runtime_version;
			}
			if ( $runtime_version === '' ) {
				$this->logger->warning(
					sprintf(
						'Discovery %d aborted pre-flight: discovered_version is empty and no extractor version was recovered. Refusing to schedule AI job with blank runtime version.',
						(int) $discovery_id
					)
				);
				$this->mark_discovery_failure(
					(int) $discovery_id,
					'failed',
					'Discovery version is empty. Refusing to schedule AI job with blank runtime version.'
				);
				return;
			}

			// ── INTERNAL LINKS: Fetch from Link_Finder and build token map ──
			$seogen_links     = array();
			$seogen_token_map = array();
			$il_defaults      = \SEO_Article_Generator\Option_Registry::defaults();
			$il_count         = max(
				0,
				(int) \get_option(
					\SEO_Article_Generator\Option_Registry::INTERNAL_LINK_COUNT,
					$il_defaults[ \SEO_Article_Generator\Option_Registry::INTERNAL_LINK_COUNT ] ?? 3
				)
			);
			// [2.34.11] Internal linking is now DETERMINISTIC: Internal_Link_Injector
			// adds contextual links to the FINAL rendered HTML (intro/MOAT/Features)
			// after generation — no AI tokens. The legacy AI-token contract below is
			// intentionally disabled so the AI is no longer asked to emit
			// [SEOGEN_LINK_n] placeholders (it routinely omitted/misplaced them).
			// Kept in place for reference but never populates seogen_links.
			$seogen_links     = array();
			$seogen_token_map = array();
			if ( false && $il_count > 0 ) {
				$il_finder   = new \SEO_Article_Generator\Links\Link_Finder(
					$this->logger,
					new \SEO_Article_Generator\Links\DB_Post_Finder( $this->logger )
				);
				$il_category = trim( (string) ( $item->software_name ?? '' ) );
				$il_raw      = $il_finder->find_related(
					trim( (string) ( $item->software_name ?? '' ) ),
					$il_category,
					$il_count
				);
				$il_zones    = array( 'introduction', 'moatdata', 'features' );
				$il_slot     = 0;
				foreach ( $il_raw as $il_link ) {
					if ( ! is_array( $il_link ) || empty( $il_link['url'] ) || empty( $il_link['title'] ) ) {
						continue;
					}
					++$il_slot;
					$il_token                      = 'SEOGEN_LINK_' . $il_slot;
					$il_zone                       = $il_zones[ ( $il_slot - 1 ) % 3 ];
					$seogen_links[]                = array(
						'token' => $il_token,
						'title' => sanitize_text_field( (string) $il_link['title'] ),
						'url'   => esc_url_raw( (string) $il_link['url'] ),
						'zone'  => $il_zone,
					);
					$seogen_token_map[ $il_token ] = array(
						'url'   => esc_url_raw( (string) $il_link['url'] ),
						'zone'  => $il_zone,
						'title' => sanitize_text_field( (string) $il_link['title'] ),
					);
					if ( $il_slot >= $il_count ) {
						break;
					}
				}
				if ( ! empty( $seogen_links ) ) {
					$this->logger->info(
						sprintf(
							'Internal links: %d links fetched from Link_Finder for Discovery %d.',
							count( $seogen_links ),
							(int) $discovery_id
						)
					);
				}
			}

			$input_data             = array(
				'generation_mode'          => 'auto',
				'software_name'            => $item->software_name,
				'version'                  => $runtime_version,
				'source_url'               => $item->source_url,
				'homepage_url'             => (string) ( $phase1_facts['homepage_url'] ?? ( $extracted['homepage_url'] ?? '' ) ),
				'changelog_url'            => (string) ( $phase1_facts['changelog_url'] ?? ( $extracted['changelog_url'] ?? '' ) ),
				'focus_keyword'            => $item->software_name,
				// Prefer Phase-1 platform data; fall back to fresh extraction.
				'target_platforms'         => $p1_target_platforms,
				'os_support'               => $p1_os_support,
				'existing_post_id'         => ! empty( $item->existing_post_id ) ? (int) $item->existing_post_id : 0,
				'canonical_download_links' => $approved_links,
				'detected_metadata'        => \wp_json_encode(
					array(
						'resolved_links'  => $approved_links,
						'rejected_links'  => $extracted['rejected_links'] ?? array(),
						'grounding_hints' => $extracted['grounding_hints'] ?? array(),
						'file_size'       => $extracted['file_size'] ?? '',
						'license'         => $extracted['license'] ?? '',
						'developer'       => $extracted['developer'] ?? '',
						'version'         => $runtime_version,
						'homepage_url'    => (string) ( $phase1_facts['homepage_url'] ?? ( $extracted['homepage_url'] ?? '' ) ),
						'changelog_url'   => (string) ( $phase1_facts['changelog_url'] ?? ( $extracted['changelog_url'] ?? '' ) ),
					)
				),
				'article_context'          => "Source Context:\n" . \wp_strip_all_tags( $raw_html ),
				'input_type'               => 'discovery',
				// FIX F2/B2 (2026-09-06): stamp owner identity so the worker can
				// refuse orphaned jobs pre-AI and completions can re-attach.
				'discovery_id'             => (int) $discovery_id,
				'is_update'                => ! empty( $item->existing_post_id ),
				'is_legacy_upgrade'        => ! empty( $item->existing_post_id )
				&& \get_post_meta( (int) $item->existing_post_id, '_seo_gen_force_legacy_rewrite', true ) === '1',
				'existing_article_html'    => ( ! empty( $item->existing_post_id ) ) ? (string) \get_post_field( 'post_content', (int) $item->existing_post_id, 'raw' ) : '',
				'user_id'                  => $user_id,
				'seogen_links'             => $seogen_links,
				'seogen_token_map'         => $seogen_token_map,
			);
			$is_legacy_rewrite_type = ! empty( $item->existing_post_id )
			&& in_array( (string) ( $item->type ?? '' ), array( Post_Type_Classifier::TYPE_LEGACY, 'legacy' ), true );
			$force_legacy           = ! empty( $item->existing_post_id )
			&& \get_post_meta( (int) $item->existing_post_id, '_seo_gen_force_legacy_rewrite', true ) === '1';

			// STALE TYPE GUARD: If DB row says 'legacy' but the live post no longer qualifies
			// (classify() cleared the stale flag above), re-classify from live content and fix the DB.
			if ( $is_legacy_rewrite_type && ! $force_legacy && ! empty( $item->existing_post_id ) ) {
				$live_type = Post_Type_Classifier::classify( (int) $item->existing_post_id );
				if ( $live_type !== Post_Type_Classifier::TYPE_LEGACY ) {
					$is_legacy_rewrite_type = false;
					global $wpdb;
					$wpdb->update(
						Installer::table_discovery(),
						array( 'type' => $live_type ),
						array( 'id' => (int) $item->id ),
						array( '%s' ),
						array( '%d' )
					);
				}
			}

			if ( ! empty( $item->existing_post_id ) && ! $is_legacy_rewrite_type && ! $force_legacy ) {
				// FIX F2 (Phase 3A): use the scope frozen at approve-time so a settings
				// change mid-flight cannot alter scope. Falls back to the live global
				// when no snapshot exists (pre-freeze rows).
				$regen = $this->get_regen_sections_snapshot( (int) $item->existing_post_id );
				if ( empty( $regen ) ) {
					$regen = $this->get_update_sections();
				}
				$regen = \SEO_Article_Generator\Generator\Article_Schema::normalize_sections( $regen, array() );

				if ( empty( $regen ) ) {
					throw new \RuntimeException(
						'Discovery configuration invalid for updates: AI Update Sections resolved to an empty canonical set.'
					);
				}

				$input_data['regen_sections'] = $regen;
			} else {
				$regen = $this->get_new_post_sections();
				$regen = \SEO_Article_Generator\Generator\Article_Schema::normalize_sections( $regen, array( 'all', 'toc' ) );

				if ( empty( $regen ) ) {
					throw new \RuntimeException(
						'Discovery configuration invalid for new posts: Discovery Generation Sections resolved to an empty canonical set.'
					);
				}

				if ( ! in_array( 'toc', $regen, true ) ) {
					$regen[] = 'toc';
				}
				$input_data['regen_sections'] = array_values( array_unique( $regen ) );
			}
			$regen_sections = array_values( array_unique( $input_data['regen_sections'] ) );

			// --- ZONE COVERAGE GATE (UNIFIED) ---
			// Handles both no-sentinel posts (full rebuild) and partial-sentinel posts (zone coverage < 50%).
			// Must run AFTER $input_data['regen_sections'] is set by the existing_post_id branch above.
			// RESPECT the force-legacy-rewrite flag: if approve_item or a prior gate pass already
			// decided this post needs a full rewrite, skip the expensive sentinel check + migration.
			// The generation path at the _seo_gen_force_legacy_rewrite check below already handles this.
			if ( ! empty( $item->existing_post_id ) && \get_post_meta( (int) $item->existing_post_id, '_seo_gen_force_legacy_rewrite', true ) !== '1' ) {
				$existing_content = \get_post_field( 'post_content', (int) $item->existing_post_id, 'raw' );

				if ( is_string( $existing_content ) && ! empty( trim( $existing_content ) ) ) {

					// FIX F9 (Phase 3B, 2.32.26): single sentinel SSOT — approve_item
					// and the submit gate must route space-form zone comments
					// (<!-- seo-gen-zone introduction -->) identically. The helper
					// covers all three formats with a space-tolerant zone regex.
					$has_any_sentinels = Post_Type_Classifier::has_sentinel_structure( $existing_content );

					// Case A: No sentinel structure in any format.
					// MODIFIED: Attempt on-the-fly sentinel migration BEFORE deciding on full rewrite.
					if ( ! $has_any_sentinels ) {
						$this->logger->warning(
							sprintf(
								'Discovery %d: Post %d has no sentinel structure in any format. Attempting in-memory sentinel migration before deciding on full rewrite.',
								$discovery_id,
								(int) $item->existing_post_id
							)
						);

						$repair = \SEO_Article_Generator\Tools\Sentinel_Fallback_Utility::repair_and_audit(
							$existing_content,
							array(),
							array( 'is_update' => false )
						);

						if ( ! empty( $repair['migration_attempted'] ) && ! empty( $repair['changed'] ) && empty( $repair['audit']['fatal_reasons'] ) ) {
							$existing_content = (string) $repair['content'];

							// FIX F9 (Phase 3B): sentinel SSOT (space-tolerant).
							$has_any_sentinels = Post_Type_Classifier::has_sentinel_structure( $existing_content );

							if ( $has_any_sentinels ) {
								$this->logger->info(
									sprintf(
										'Discovery %d: Post %d on-the-fly sentinel migration succeeded. Persisting before generation.',
										$discovery_id,
										(int) $item->existing_post_id
									)
								);

								\wp_update_post(
									array(
										'ID'           => (int) $item->existing_post_id,
										'post_content' => \wp_slash( $existing_content ),
									)
								);

								\delete_post_meta( (int) $item->existing_post_id, '_seo_gen_content_contract' );
							} else {
								$this->logger->warning(
									sprintf(
										'Discovery %d: Post %d migration returned content without usable sentinels. Forcing full rewrite.',
										$discovery_id,
										(int) $item->existing_post_id
									)
								);
							}
						} elseif ( ! empty( $repair['migration_attempted'] ) ) {
							$fatal = implode( ', ', (array) ( $repair['audit']['fatal_reasons'] ?? array() ) );
							$this->logger->warning(
								sprintf(
									'Discovery %d: Post %d on-the-fly migration failed: %s. Forcing full rewrite.',
									$discovery_id,
									(int) $item->existing_post_id,
									$fatal !== '' ? $fatal : 'unknown'
								)
							);
						} else {
							$has_any_sentinels = true;
							$this->logger->info(
								sprintf(
									'Discovery %d: Post %d stale sentinel read; post was already migrated. Proceeding normally.',
									$discovery_id,
									(int) $item->existing_post_id
								)
							);
						}

						if ( ! $has_any_sentinels ) {
									$this->logger->warning(
										sprintf(
											'Discovery %d: Post %d all migration attempts exhausted. Pre-generation sentinel check failed — routing to TYPE_LEGACY full rewrite.',
											$discovery_id,
											(int) $item->existing_post_id
										)
									);

									// Set legacy flag for TYPE_LEGACY full rewrite path
									\update_post_meta( (int) $item->existing_post_id, '_seo_gen_force_legacy_rewrite', '1' );

									// FIX: Route to queued AND immediately trigger next stage (no waiting)
									$wpdb->update(
										$table,
										array(
											self::COL_STATUS        => 'queued',
											self::COL_ERROR_MESSAGE => 'pre-gen sentinel fail: routing to TYPE_LEGACY rewrite',
											self::COL_HEARTBEAT_AT  => null,
											self::COL_JOB_ID        => null,
											self::COL_QUEUE_JOB_ID  => null,
										),
										array( 'id' => $discovery_id ),
										array( '%s', '%s', '%s', '%d', '%d' ),
										array( '%d' )
									);

									// Cancel any scheduled actions
									AS_Registry::cancel_item_actions( $discovery_id );

									// Trigger IMMEDIATE processing (no waiting in queue)
									AS_Registry::schedule_process_item( $discovery_id, (int) ( $user_id ?? 1 ), 1 );

									// FIX: Sync timestamp so UI does not show "overdue" immediately
									$this->sync_scheduled_at_from_registry( $discovery_id, Plugin_Time::now_utc_ts() + 1 );

									$this->logger->info(
										sprintf(
											'Discovery %d: Post %d routed to TYPE_LEGACY rewrite with immediate processing.',
											$discovery_id,
											(int) $item->existing_post_id
										)
									);
									return;
						}
					}

// Case B: Self-Healing Zone Gate (Coverage & Critical Missing)
				if ( $has_any_sentinels ) {
					$configured_sections = $this->get_update_sections();
					$present_zones       = 0;

					// Critical zones: only sections the user actually enabled in update settings.
					// SSOT is the settings toggle — never force-check a zone the user disabled.
					$critical_zones    = array_values(
						array_intersect(
							array( 'download', 'tech_specs', 'moat' ),
							$configured_sections
						)
					);
					$missing_critical  = false;
					$missing_zone_name = '';

					foreach ( $configured_sections as $section ) {
						if ( \SEO_Article_Generator\Generator\Surgical_Patcher::find_zone( $existing_content, $section ) !== false ) {
							++$present_zones;
						} elseif ( in_array( $section, $critical_zones, true ) ) {
							$missing_critical  = true;
							$missing_zone_name = $section;
						}
					}

					$total_sections = count( $configured_sections );

					// If it's missing a critical zone OR coverage is under 50%, force full rewrite
					if ( $missing_critical || ( $total_sections > 0 && ( $present_zones / $total_sections ) < 0.5 ) ) {

							$reason = $missing_critical
								? "Missing critical requested zone '{$missing_zone_name}'"
								: "Low sentinel coverage ({$present_zones}/{$total_sections})";

							// [OBSERVABILITY 2026-08-26] Log the scope change so escalations are visible.
							$new_scope = $this->get_new_post_sections();
							$this->logger->warning(
								sprintf(
									'Discovery %d: Post %d trigger self-healing full rewrite. Reason: %s. Old scope: [%s]. New scope: [%s].',
									$discovery_id,
									(int) $item->existing_post_id,
									$reason,
									implode( ', ', $configured_sections ),
									implode( ', ', $new_scope )
								)
							);

							$input_data['regen_sections']    = $new_scope;
							$regen_sections                  = (array) $input_data['regen_sections'];
							$input_data['is_legacy_upgrade'] = true;

							// SET POINT S2: Sentinels exist but critical zone missing or coverage < 50%.
							// is_update remains true — the PPB bypass (post_id=0) handles routing around SurgicalPatcher.
							\update_post_meta( (int) $item->existing_post_id, '_seo_gen_force_legacy_rewrite', '1' );
						}
					}
				}
			}
			// --- END ZONE COVERAGE GATE ---

			$gate = $this->get_generation_gate();

			if ( empty( $gate['ok'] ) ) {
				if ( ! empty( $gate['temporary'] ) ) {
					$delay = max( 60, (int) ( $gate['retry_after'] ?? 300 ) );
					if ( ! $this->defer_discovery_without_job( (int) $discovery_id, (int) $user_id, $delay, (string) $gate['reason'] ) ) {
						throw new \RuntimeException( 'Failed to defer discovery item during temporary provider block.' );
					}
					return;
				}

				$this->fail_discovery_configuration_block( (int) $discovery_id, (string) $gate['reason'] );
				return;
			}

			if ( $this->is_pipeline_paused() ) {
				AS_Registry::cancel_item_actions( (int) $discovery_id );
				$this->restore_item_schedule_failure( (int) $discovery_id, 'processing', null, null );
				$this->logger->info( "Discovery #{$discovery_id} frozen before job creation: Engine is Paused." );
				return;
			}

			$poll_at = Plugin_Time::now_utc_ts() + self::FIRST_POLL_DELAY;

			// Step A: Pre-claim as generating with job_id=0 sentinel — closes the race
			// window where the job completes before job_id is persisted to the discovery row.
			// Guard on status = 'processing' to prevent stale AS actions from corrupting done/failed rows.
			// FIX: Wrap Step A in FOR UPDATE lock to prevent race between concurrent process_item_background calls.

			$wpdb->query( 'START TRANSACTION' );
			try {
				$fresh_row = $wpdb->get_row(
					$wpdb->prepare(
						"SELECT id, status FROM {$table} WHERE id = %d FOR UPDATE",
						$discovery_id
					),
					ARRAY_A
				);

				if ( ! $fresh_row ) {
					$wpdb->query( 'ROLLBACK' );
					$this->logger->warning( "Discovery {$discovery_id} Step A aborted: row not found." );
					return;
				}

				if ( $fresh_row['status'] !== 'processing' ) {
					$wpdb->query( 'ROLLBACK' );
					$this->logger->warning( "Discovery {$discovery_id} Step A aborted: expected 'processing', found '" . ( $fresh_row['status'] ?? 'NULL' ) . "'. Skipping to avoid state corruption." );
					return;
				}

				$pre_claimed = $wpdb->query(
					$wpdb->prepare(
						"UPDATE {$table}
						 SET status        = 'generating',
						     job_id        = 0,
						     queue_job_id  = 0,
						     error_message = NULL,
						     heartbeat_at  = NULL,
						     scheduled_at  = %s
						 WHERE id = %d
						   AND status = 'processing'",
						Plugin_Time::utc_mysql_from_utc_ts( $poll_at ),
						$discovery_id
					)
				);

				if ( $pre_claimed === false ) {
					$wpdb->query( 'ROLLBACK' );
					throw new \RuntimeException( 'Step A DB error: ' . $wpdb->last_error );
				}

				if ( (int) $pre_claimed === 0 ) {
					$wpdb->query( 'ROLLBACK' );
					$this->logger->warning(
						'Discovery ' . (int) $discovery_id . ' Step A no-op: row not in processing status. Aborting to avoid state corruption.'
					);
					return;
				}
				// FIX: Immediately release the lock. Do NOT hold row locks while generating or validating external jobs.
				$wpdb->query( 'COMMIT' );
			} catch ( \Exception $e ) {
				$wpdb->query( 'ROLLBACK' );
				throw $e;
			}

			// Step B: Now submit the job — row is already marked generating, lock held
			$res = $this->job_handler->schedule_generation( $input_data, $user_id );
			if ( ! $res || empty( $res['job_id'] ) ) {
				// Rollback: restore to processing so cleanup can recover it
				$wpdb->update(
					$table,
					array(
						'status' => 'processing',
						'job_id' => null,
					),
					array( 'id' => $discovery_id )
				);
				throw new \RuntimeException( 'AI Job scheduling failed.' );
			}

			$job_id       = (int) $res['job_id'];
			$queue_job_id = (int) ( $res['queue_job_id'] ?? 0 );

			if ( $job_id <= 0 || $queue_job_id <= 0 ) {
				$wpdb->update(
					$table,
					array(
						'status'       => 'processing',
						'job_id'       => null,
						'queue_job_id' => null,
						'scheduled_at' => null,
						'heartbeat_at' => null,
					),
					array( 'id' => $discovery_id ),
					array( '%s', '%d', '%d', '%s', '%s' ),
					array( '%d' )
				);

				$job_handler_file = ( new \ReflectionClass( \SEO_Article_Generator\Jobs\Job_Handler::class ) )->getFileName();

				$this->logger->error(
					'Discovery ' . (int) $discovery_id . ' schedule_generation returned an invalid identity pair.',
					array(
						'job_id'                 => $job_id,
						'queue_job_id'           => $queue_job_id,
						'processor_file'         => __FILE__,
						'processor_mtime'        => @filemtime( __FILE__ ),
						'job_handler_file'       => $job_handler_file,
						'job_handler_file_mtime' => @filemtime( $job_handler_file ),
					)
				);

				throw new \RuntimeException(
					'Generation scheduling returned an invalid identity pair (job_id/queue_job_id).'
				);
			}

			// Force-wake the queue worker immediately. Routed through the unique
			// scheduler so a pending recurring/single tick short-circuits instead of
			// stacking another orphan row that would survive unschedule_all($hook, []).
			if ( \SEO_Article_Generator\Queue\AS_Registry::is_ready_public() ) {
				\SEO_Article_Generator\Queue\AS_Registry::schedule_unique_single_action(
					Plugin_Time::now_utc_ts() + 2,
					\SEO_Article_Generator\Queue\AS_Registry::HOOK_QUEUE_WORKER,
					array()
				);
			}

			// Step B.5 — Write real queue_job_id immediately.
			// Closes the fallback lookup gap: if the job fails before Step C executes,
			// handle_job_finished() can now locate the row via queue_job_id.
			$wpdb->update(
				$table,
				array( 'queue_job_id' => $queue_job_id ),
				array( 'id' => $discovery_id ),
				array( '%d' ),
				array( '%d' )
			);

			// Step C: Write real job_id back — row lock released, updating state
			$updated = $wpdb->update(
				$table,
				array(
					'job_id'       => $job_id,
					'queue_job_id' => $queue_job_id,
				),
				array( 'id' => $discovery_id ),
				array( '%d', '%d' ),
				array( '%d' )
			);
			// FIX: Removed orphaned COMMIT. Transaction was safely closed in Step A.

			$this->logger->info(
				"Discovery {$discovery_id} Step C: job_id={$job_id}, queue_job_id={$queue_job_id}, updated=" . (int) $updated,
				array(
					'job_id'          => (int) $job_id,
					'queue_job_id'    => (int) $queue_job_id,
					'processor_file'  => __FILE__,
					'processor_mtime' => @filemtime( __FILE__ ),
				)
			);

			// STEP C.1: Lock & Persist if Race Detected
			if ( $updated === false || (int) $updated === 0 ) {
				$wpdb->query( 'START TRANSACTION' );
				try {
					$fresh = $wpdb->get_row(
						$wpdb->prepare(
							'SELECT id, status FROM ' . Installer::table_discovery() . " 
						 WHERE id = %d AND status IN ('processing', 'generating') FOR UPDATE",
							$discovery_id
						)
					);

					if ( ! $fresh || $fresh->status !== 'generating' ) {
						$this->logger->warning( "Discovery {$discovery_id} Step C race lost: status=" . ( $fresh->status ?? 'missing' ) . '.' );
						$wpdb->query( 'ROLLBACK' );
					} else {
						$real_updated = $wpdb->update(
							$table,
							array(
								'job_id'       => $job_id,
								'queue_job_id' => $queue_job_id,
							),
							array( 'id' => $discovery_id ),
							array( '%d', '%d' ),
							array( '%d' )
						);

						$wpdb->query( 'COMMIT' );
						$this->logger->info(
							"Discovery {$discovery_id} Step C lock-won: updated=" . (int) $real_updated,
							array(
								'job_id'          => (int) $job_id,
								'queue_job_id'    => (int) $queue_job_id,
								'processor_file'  => __FILE__,
								'processor_mtime' => @filemtime( __FILE__ ),
							)
						);
					}
				} catch ( \Exception $e ) {
					$wpdb->query( 'ROLLBACK' );
					$this->logger->error( "Discovery {$discovery_id} Step C lock failed: " . $e->getMessage() );
				}
			}

			$schedule_ok = AS_Registry::schedule_check_job( (int) $discovery_id, (int) $job_id, (int) $user_id, 1, self::FIRST_POLL_DELAY );
			if ( ! $schedule_ok ) {
				$this->logger->error( "Discovery {$discovery_id} CRITICAL: Job {$job_id} created but check_poll could not be scheduled. Manual intervention may be required." );

				if ( ! AS_Registry::schedule_check_job( (int) $discovery_id, (int) $job_id, (int) $user_id, 1, 10 ) ) {
					$this->write_scheduled_at( (int) $discovery_id, null );
					$this->logger->error( 'Discovery ' . (int) $discovery_id . ' First poll schedule failed after retry.' );
				}
			}

			if ( $schedule_ok || AS_Registry::get_next_item_run( (int) $discovery_id ) > 0 ) {
				$wpdb->update(
					Installer::table_discovery(),
					array( 'poll_count' => 1 ),
					array( 'id' => (int) $discovery_id ),
					array( '%d' ),
					array( '%d' )
				);
			}

			// FIX D2 (2026-09-06): a fresh job starts a fresh budget cycle. Clears
			// any stale effective-poll / wait-since residue from a previous cycle
			// on this row (retry/resume/spawn roads all funnel through here).
			$this->clear_effective_poll_count( (int) $discovery_id );

			// R4 FIX: Persist regen sections to transient keyed by discovery ID for fallback when job row is purged
			$actual_regen_sections = $input_data['regen_sections'] ?? array();
			if ( ! empty( $actual_regen_sections ) ) {
				\set_transient(
					'seo_gen_regen_for_discovery_' . (int) $discovery_id,
					$actual_regen_sections,
					6 * \HOUR_IN_SECONDS
				);
			}
		} catch ( \Throwable $e ) {
			$this->mark_discovery_failure( (int) $discovery_id, 'failed', $e->getMessage() );
		}
	}

	public function check_and_finalize_job( $discovery_id, $job_id, $user_id, $attempt ) {
		global $wpdb;

		if ( $this->is_pipeline_paused() ) {
			return;
		}

		$poll_count = (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT poll_count FROM ' . Installer::table_discovery() . ' WHERE id = %d',
				$discovery_id
			)
		);

		$life = $this->job_handler->get_job_lifecycle_status( (int) $job_id );

		// FIX: Skip if discovery already finalized (prevents duplicate finalization
		// race with Overdue Recovery or manual Run Now). Mirrors auto_finalize guard.
		$current_status = (string) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT status FROM ' . Installer::table_discovery() . ' WHERE id = %d',
				$discovery_id
			)
		);
		if ( $current_status === 'done' ) {
			AS_Registry::cancel_item_actions( $discovery_id );
			$this->logger->info(
				"check_and_finalize_job: Discovery #{$discovery_id} already done, cancelling actions."
			);
			return;
		}

		if ( ! empty( $life['should_finalize'] ) ) {
			$item = $this->claim_item_for_finalization( (int) $discovery_id, (int) $job_id );
			if ( $item ) {
				$this->auto_finalize( $item, (int) $job_id, (int) ( $life['user_id'] ?? ( $user_id ?: 1 ) ), false );
			} else {
				$this->logger->warning(
					"Discovery {$discovery_id} poll: claim_item_for_finalization returned null for job {$job_id}. "
					. 'Job is complete but item may already be finalized or in wrong status.'
				);
			}
			return;
		}

		if ( $poll_count >= self::MAX_POLL_ATTEMPTS ) {
			$this->mark_discovery_failure(
				(int) $discovery_id,
				'timeout',
				sprintf(
					'Discovery %d exceeded max poll attempts (%d).',
					(int) $discovery_id,
					self::MAX_POLL_ATTEMPTS
				)
			);
			return;
		}

		if ( ! empty( $life['should_fail'] ) ) {
			$effective_user_id = (int) ( $life['user_id'] ?? ( $user_id > 0 ? $user_id : 1 ) );

			if (
				( $life['combined_status'] ?? '' ) === 'reconcile_failed' &&
				$this->recover_from_reconcile_failed_snapshot(
					(int) $discovery_id,
					(int) $job_id,
					$effective_user_id,
					'check_and_finalize_job'
				)
			) {
				return;
			}

			$this->mark_discovery_failure(
				(int) $discovery_id,
				(string) ( $life['failure_status'] ?? 'failed' ),
				(string) ( $life['failure_reason'] ?? 'AI job failed.' )
			);
			return;
		}

		if ( ! empty( $life['should_continue'] ) ) {
			$current_poll = $poll_count;

			// FIX F3 (Phase 3B, 2.32.26): mid-flight heartbeat refresh. Each poll
			// that sees the job alive refreshes heartbeat_at so Overdue Recovery's
			// stale-heartbeat sweep (300s/option window) never matches a slow-but-
			// healthy job. Previously heartbeat_at was NULL for the whole
			// generating phase, offering zero grace — a check-job even seconds late
			// let recovery re-process the row (Fix E's liveness read only catches
			// cases recovery reaches; this keeps those rows out of the candidate
			// set entirely). Terminal finalize/fail paths overwrite/clear it.
			$wpdb->update(
				Installer::table_discovery(),
				array( self::COL_HEARTBEAT_AT => Plugin_Time::utc_mysql_now() ),
				array( 'id' => (int) $discovery_id ),
				array( '%s' ),
				array( '%d' )
			);

			// FIX D2b (2026-09-06): passive waits must not consume timeout budget.
			// A job that is legitimately 'pending' behind the worker, or 'deferred'
			// to a future slot/reset, is healthy-but-waiting: tripping MAX_POLLS on
			// it mass-times-out rows whose jobs would have run fine (09-05 R5).
			// Only ACTIVE work (processing/generating/validating/reserved) and
			// unknown states increment. Pending starvation is backstopped by the
			// 12h cap below instead of the poll counter.
			$budget_combined_status = (string) ( $life['combined_status'] ?? '' );
			$budget_is_future_deferred = $budget_combined_status === 'deferred'
				&& (int) ( $life['deferred_until'] ?? 0 ) > Plugin_Time::now_utc_ts();
			$is_passive_wait = $budget_combined_status === 'pending' || $budget_is_future_deferred;

			// FIX D (2026-09-06): Track effective poll count in transient so Overdue Recovery
			// resetting DB poll_count doesn't hide the real number of poll cycles. This prevents
			// the timeout from being indefinitely deferred while Overdue Recovery keeps
			// respawning jobs.
			if ( ! $is_passive_wait ) {
				$effective_poll_key = 'seo_gen_effective_poll_' . (int) $discovery_id;
				$effective_poll_count = (int) \get_transient( $effective_poll_key );
				if ( $effective_poll_count <= 0 ) {
					$effective_poll_count = $current_poll;
				}
				$effective_poll_count++;
				\set_transient( $effective_poll_key, $effective_poll_count, 86400 );

				// Use effective count for timeout decision (not DB poll_count which Overdue Recovery resets)
				if ( $effective_poll_count >= self::MAX_POLL_ATTEMPTS ) {
					$this->mark_discovery_failure(
						(int) $discovery_id,
						'timeout',
						sprintf(
							'Discovery %d exceeded max effective poll attempts (%d). Effective polls: %d, DB polls: %d.',
							(int) $discovery_id,
							self::MAX_POLL_ATTEMPTS,
							$effective_poll_count,
							$current_poll
						)
					);
					\delete_transient( $effective_poll_key );
					return;
				}


			} elseif ( $budget_combined_status === 'pending' ) {
				// Starvation backstop: pending far beyond any plausible backlog
				// means the worker/queue is broken. Trip via the failure SSOT.
				$passive_wait_key   = 'seo_gen_passive_wait_since_' . (int) $discovery_id;
				$passive_wait_since = (int) \get_transient( $passive_wait_key );
				if ( $passive_wait_since <= 0 ) {
					$passive_wait_since = Plugin_Time::now_utc_ts();
					\set_transient( $passive_wait_key, $passive_wait_since, 2 * 86400 );
				} elseif ( ( Plugin_Time::now_utc_ts() - $passive_wait_since ) > self::MAX_PASSIVE_WAIT_SECONDS ) {
					\delete_transient( $passive_wait_key );
					$this->mark_discovery_failure(
						(int) $discovery_id,
						'timeout',
						sprintf(
							'Discovery %d AI job pending without execution for over %d hours (worker starvation).',
							(int) $discovery_id,
							(int) ( self::MAX_PASSIVE_WAIT_SECONDS / 3600 )
						)
					);
					return;
				}
			}

			// Passive waits hold the DB counter steady (same exemption).
			$budget_poll_count = $is_passive_wait ? $current_poll : $current_poll + 1;

			// Handle deferred jobs
			if ( ( $life['combined_status'] ?? '' ) === 'deferred' ) {
				$deferred_until  = (int) ( $life['deferred_until'] ?? 0 );
				$now_ts          = Plugin_Time::now_utc_ts();
				$deferred_jitter = ( $discovery_id + max( 0, (int) $job_id ) ) % self::POLL_INTERVAL;

				// FIX: When the check-job fires and the discovery's scheduled_at has passed,
				// the publish slot has arrived — finalize immediately instead of rescheduling.
				// This closes the gap where rearm_finalization() scheduled a check-job for
				// slot_time, the check-job fires on time, but the old code just kept
				// rescheduling in an infinite loop, leaving the item deferred forever
				// until run_overdue_recovery() happened to pick it up.
				$discovery_scheduled_at = (string) $wpdb->get_var(
					$wpdb->prepare(
						'SELECT scheduled_at FROM ' . Installer::table_discovery() . ' WHERE id = %d',
						(int) $discovery_id
					)
				);
				$slot_ts = $discovery_scheduled_at !== '' ? Plugin_Time::utc_ts_from_utc_mysql( $discovery_scheduled_at ) : 0;

				if ( $slot_ts > 0 && $slot_ts <= $now_ts ) {
					$this->logger->info(
						"check_and_finalize_job: Deferred discovery {$discovery_id} slot arrived (scheduled_at={$discovery_scheduled_at}, now={$now_ts}). Finalizing."
					);
					$claimed = $this->claim_item_for_finalization( (int) $discovery_id, (int) $job_id );
					if ( $claimed ) {
						$this->auto_finalize( $claimed, (int) $job_id, (int) ( $life['user_id'] ?? ( $user_id ?: 1 ) ), false );
					}
					return;
				}

				// Slot not yet arrived — reschedule for slot time
				$backoff_seconds = ( $deferred_until > $now_ts )
				? max( self::POLL_INTERVAL, ( $deferred_until - $now_ts ) + 5 + $deferred_jitter )
				: ( self::POLL_INTERVAL * 2 ) + $deferred_jitter;

				if ( ! AS_Registry::schedule_check_job( (int) $discovery_id, (int) $job_id, (int) $user_id, $current_poll + 1, $backoff_seconds ) ) {
					$this->mark_discovery_failure( (int) $discovery_id, 'failed', 'Failed to reschedule deferred discovery poll.' );
					return;
				}
				$wpdb->update(
					Installer::table_discovery(),
					array( 'poll_count' => $budget_poll_count ),
					array( 'id' => (int) $discovery_id ),
					array( '%d' ),
					array( '%d' )
				);
				$this->sync_scheduled_at_from_registry( (int) $discovery_id, Plugin_Time::now_utc_ts() + $backoff_seconds );
				return;
			}

			// Handle non-deferred continuation

			if ( ! AS_Registry::schedule_check_job(
				(int) $discovery_id,
				(int) $job_id,
				(int) $user_id,
				(int) $current_poll + 1,
				self::POLL_INTERVAL
			) ) {
				$this->mark_discovery_failure( (int) $discovery_id, 'failed', 'Failed to reschedule discovery poll.' );
				return;
			}

			$wpdb->update(
				Installer::table_discovery(),
				array( 'poll_count' => $budget_poll_count ),
				array( 'id' => (int) $discovery_id ),
				array( '%d' ),
				array( '%d' )
			);

			$this->sync_scheduled_at_from_registry( (int) $discovery_id, Plugin_Time::now_utc_ts() + self::POLL_INTERVAL );

			// MODIFIED: Only force-wake if job is pending AND no temporary provider block
			$gate = $this->get_generation_gate();
			if (
				\in_array( (string) ( $life['job_status'] ?? '' ), array( 'pending' ), true )
				&& \in_array( (string) ( $life['queue_status'] ?? '' ), array( 'queued' ), true )
				&& empty( $gate['temporary'] )
			) {
				// PHASE 3F (2.34.0): throttle force-wakes. The 09-06 log showed
				// 1,334 force-wokes from 11 starved discoveries firing on every
				// poll — the unique scheduler coalesces the AS action but each
				// poll still re-armed + logged + kicked the worker, adding churn
				// that cannot speed a single worker draining a ~2,480 backlog.
				// Rate-limit the kick to at most once every FORCE_WAKE_THROTTLE
				// seconds per discovery; the recurring worker + watchdog still
				// drain the queue, so a missed kick only costs the throttle window.
				$wake_key   = 'seo_gen_force_wake_' . (int) $discovery_id;
				$last_wake  = (int) \get_transient( $wake_key );
				$now_wake   = Plugin_Time::now_utc_ts();
				if ( AS_Registry::is_ready_public() && ( $last_wake <= 0 || ( $now_wake - $last_wake ) >= self::FORCE_WAKE_THROTTLE ) ) {
					\set_transient( $wake_key, $now_wake, self::FORCE_WAKE_THROTTLE * 2 );
					\SEO_Article_Generator\Queue\AS_Registry::schedule_unique_single_action(
						$now_wake + 2,
						AS_Registry::HOOK_QUEUE_WORKER,
						array()
					);
					$this->logger->info( "Discovery {$discovery_id}: job {$job_id} still pending — force-woke queue worker (throttled)." );
				}
			}
			return;
		}

		$this->mark_discovery_failure(
			(int) $discovery_id,
			'failed',
			'Lifecycle contract violation: processor received no actionable decision.'
		);
		$wpdb->update(
			Installer::table_discovery(),
			array( 'poll_count' => 0 ),
			array( 'id' => (int) $discovery_id ),
			array( '%d' ),
			array( '%d' )
		);
	}

	/**
	 * Hoisted publishing-window gate for UPDATE finalization.
	 *
	 * Returns true when the discovery was deferred (caller must return without
	 * writing). Returns false when within the active window and no deferral is
	 * required; the MySQL finalize lock is then held in $update_publish_lock and
	 * must be released by the caller (post-persistence or the catch block).
	 *
	 * This runs BEFORE Publish_Payload_Builder::build() so sentinel-absent
	 * posts cannot bypass the window via the immediate self-heal catch path.
	 */
	private function maybe_defer_update_to_window( $item, $job_id, $user_id, &$update_publish_lock ): bool {
		global $wpdb;
		$table = Installer::table_discovery();

		$defaults = \SEO_Article_Generator\Option_Registry::defaults();
		$scheduling_enabled = (bool) \get_option( \SEO_Article_Generator\Option_Registry::ENABLE_SCHEDULING, $defaults[ \SEO_Article_Generator\Option_Registry::ENABLE_SCHEDULING ] );
		if ( ! $scheduling_enabled ) {
			return false;
		}

		$normalize_hhmm = static function ( $raw, string $fallback ): string {
			$raw = trim( (string) $raw );
			if ( $raw === '' ) {
				return $fallback;
			}

			if ( preg_match( '/^\d{1,2}:\d{2}$/', $raw ) ) {
				list($hour, $minute) = array_map( 'intval', explode( ':', $raw, 2 ) );
			} else {
				$digits = preg_replace( '/\D+/', '', $raw );

				if ( strlen( $digits ) === 3 ) {
					$hour   = (int) substr( $digits, 0, 1 );
					$minute = (int) substr( $digits, 1, 2 );
				} elseif ( strlen( $digits ) === 4 ) {
					$hour   = (int) substr( $digits, 0, 2 );
					$minute = (int) substr( $digits, 2, 2 );
				} else {
					return $fallback;
				}
			}

			if ( $hour < 0 || $hour > 23 || $minute < 0 || $minute > 59 ) {
				return $fallback;
			}

			return sprintf( '%02d:%02d', $hour, $minute );
		};

		$rearm_finalization = function ( int $delay_seconds, string $reason ) use ( $wpdb, $table, $item, $job_id, $user_id, &$update_publish_lock ) {
			// GUARD: If the discovery has transitioned to 'done' since
			// auto_finalize() started, do NOT revert it to 'generating'.
			$pre_check_status = (string) $wpdb->get_var(
				$wpdb->prepare( "SELECT status FROM {$table} WHERE id = %d", (int) $item->id )
			);
			if ( $pre_check_status === 'done' ) {
				AS_Registry::cancel_item_actions( (int) $item->id );
				$this->logger->info(
					"rearm_finalization: Discovery #{$item->id} already 'done'. Aborting deferral."
				);
				if ( ! empty( $update_publish_lock ) ) {
					$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $update_publish_lock ) );
					$update_publish_lock = null;
				}
				throw new \RuntimeException( 'Update deferral aborted: discovery #' . (int) $item->id . ' already marked done.' );
			}

			$delay_seconds = max( 60, $delay_seconds );
			$run_at_utc    = Plugin_Time::now_utc_ts() + $delay_seconds;

			$updated = $wpdb->update(
				$table,
				array(
					self::COL_STATUS        => \SEO_Article_Generator\Discovery\Discovery_Engine::STATUS_DEFERRED,
					self::COL_ERROR_MESSAGE => null,
					self::COL_HEARTBEAT_AT  => null,
					self::COL_SCHEDULED_AT  => Plugin_Time::utc_mysql_from_utc_ts( $run_at_utc ),
					self::COL_POLL_COUNT    => 0,
				),
				array(
					'id'     => (int) $item->id,
					'status' => 'finalizing',
				),
				array( '%s', '%s', '%s', '%s', '%d' ),
				array( '%d', '%s' )
			);

			// FIX: If row was not in 'finalizing' (e.g. race with handle_job_finished
			// left it in 'generating'), retry once with broader status match so the
			// deferral does not silently drop. Without this, items stuck in
			// 'generating' never reach 'deferred' and the sync_finalizer never sees
			// them at their scheduled slot.
			if ( (int) $updated === 0 ) {
				$updated = $wpdb->update(
					$table,
					array(
						self::COL_STATUS        => \SEO_Article_Generator\Discovery\Discovery_Engine::STATUS_DEFERRED,
						self::COL_ERROR_MESSAGE => null,
						self::COL_HEARTBEAT_AT  => null,
						self::COL_SCHEDULED_AT  => Plugin_Time::utc_mysql_from_utc_ts( $run_at_utc ),
						self::COL_POLL_COUNT    => 0,
					),
					array(
						'id'     => (int) $item->id,
						'status' => 'generating',
					),
					array( '%s', '%s', '%s', '%s', '%d' ),
					array( '%d', '%s' )
				);
			}

			if ( $updated === false ) {
				throw new \RuntimeException( 'Failed to defer update finalization. DB error: ' . $wpdb->last_error );
			}

			if ( ! AS_Registry::schedule_check_job( (int) $item->id, (int) $job_id, (int) $user_id, 1, $delay_seconds ) ) {
				throw new \RuntimeException( 'Failed to defer update finalization. Action Scheduler refused check-job schedule.' );
			}

			// FIX: Re-schedule draft deletion so it survives the deferral period.
			// The deletion was cancelled in process_item_background() and must be
			// reinstated even during deferred finalization to prevent draft pile-up.
			if (
				! empty( $item->source_type ) && $item->source_type === 'wp_automatic'
				&& (int) ( $item->draft_post_id ?? 0 ) > 0
				&& \get_post( (int) $item->draft_post_id )
			) {
				\SEO_Article_Generator\Discovery\Discovery_Engine::schedule_draft_deletion( (int) $item->draft_post_id );
			}

			if ( ! empty( $update_publish_lock ) ) {
				$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $update_publish_lock ) );
				$update_publish_lock = null;
			}

			$this->logger->info( $reason );

			return true;
		};

		$active_days = \get_option( \SEO_Article_Generator\Option_Registry::ACTIVE_DAYS, $defaults[ \SEO_Article_Generator\Option_Registry::ACTIVE_DAYS ] );
		if ( ! \is_array( $active_days ) || empty( $active_days ) ) {
			$active_days = $defaults[ \SEO_Article_Generator\Option_Registry::ACTIVE_DAYS ];
		}

		$publish_start = $normalize_hhmm( (string) \get_option( \SEO_Article_Generator\Option_Registry::PUBLISH_START, $defaults[ \SEO_Article_Generator\Option_Registry::PUBLISH_START ] ), $defaults[ \SEO_Article_Generator\Option_Registry::PUBLISH_START ] );
		$publish_end   = $normalize_hhmm( (string) \get_option( \SEO_Article_Generator\Option_Registry::PUBLISH_END, $defaults[ \SEO_Article_Generator\Option_Registry::PUBLISH_END ] ), $defaults[ \SEO_Article_Generator\Option_Registry::PUBLISH_END ] );
		if ( $publish_start >= $publish_end ) {
			$publish_end = $defaults[ \SEO_Article_Generator\Option_Registry::PUBLISH_END ];
		}

		$update_publish_lock = 'seo_gen_update_finalize_' . $wpdb->blogid;
		$lock_acquired       = 1 === (int) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 5)', $update_publish_lock ) );

		if ( ! $lock_acquired ) {
			if ( $rearm_finalization( \rand( 30, 90 ), 'Update finalization deferred: finalize lock busy.' ) ) {
				return true;
			}
		}

		$now_ts  = Plugin_Time::now_utc_ts();
		$day_str = Plugin_Time::site_day_of_week( $now_ts );

		$find_next_active_window_start = static function ( int $from_ts ) use ( $active_days, $publish_start ): int {
			$cursor = Plugin_Time::next_site_midnight_utc_ts( $from_ts );
			for ( $i = 0; $i < 14; $i++ ) {
				$candidate_day = Plugin_Time::site_day_of_week( $cursor );
				if ( \in_array( $candidate_day, $active_days, true ) ) {
					$ymd_local = Plugin_Time::site_date_str( $cursor );
					return Plugin_Time::site_hhmm_to_utc_ts( $ymd_local, $publish_start );
				}
				$cursor = Plugin_Time::next_site_midnight_utc_ts( $cursor );
			}
			return 0;
		};

		if ( ! \in_array( $day_str, $active_days, true ) ) {
			$inactive_slot = $this->get_next_update_slot_ts( (int) $item->id );
			if ( $inactive_slot > $now_ts + 5 ) {
				$delay = $inactive_slot - $now_ts;
				\set_transient( 'seo_gen_update_stagger_done_' . (int) $item->id, 1, $delay + HOUR_IN_SECONDS );
				if ( $rearm_finalization( $delay, sprintf( 'Update deferred: staggered inactive day at %s (%d seconds).', Plugin_Time::site_datetime( $inactive_slot ), $delay ) ) ) {
					return true;
				}
			}
			$resume_at = $find_next_active_window_start( $now_ts );
			if ( $resume_at > 0 && $rearm_finalization( max( 60, $resume_at - $now_ts ), 'Update deferred: inactive publishing day.' ) ) {
				return true;
			}
			if ( ! empty( $update_publish_lock ) ) {
				$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $update_publish_lock ) );
				$update_publish_lock = null;
			}
			throw new \RuntimeException( 'Update deferral failed: no active publishing day found within 14 days.' );
		}

		$today_ymd    = Plugin_Time::site_date_str( $now_ts );
		$window_start = Plugin_Time::site_hhmm_to_utc_ts( $today_ymd, $publish_start );
		$window_end   = Plugin_Time::site_hhmm_to_utc_ts( $today_ymd, $publish_end );

		if ( $now_ts < $window_start ) {
			$pre_window_slot = $this->get_next_update_slot_ts( (int) $item->id );
			if ( $pre_window_slot > $now_ts + 5 && $pre_window_slot <= $window_end ) {
				$delay = $pre_window_slot - $now_ts;
				\set_transient( 'seo_gen_update_stagger_done_' . (int) $item->id, 1, $delay + HOUR_IN_SECONDS );
				if ( $rearm_finalization( $delay, sprintf( 'Update deferred: staggered before window at %s (%d seconds).', Plugin_Time::site_datetime( $pre_window_slot ), $delay ) ) ) {
					return true;
				}
			}
			if ( $rearm_finalization( max( 60, $window_start - $now_ts ), 'Update deferred: before publish window.' ) ) {
				return true;
			}
		}

		if ( $now_ts >= $window_end ) {
			$next_day_slot = $this->get_next_update_slot_ts( (int) $item->id );
			if ( $next_day_slot > $now_ts + 5 ) {
				$delay = $next_day_slot - $now_ts;
				\set_transient( 'seo_gen_update_stagger_done_' . (int) $item->id, 1, $delay + HOUR_IN_SECONDS );
				if ( $rearm_finalization( $delay, sprintf( 'Update deferred: staggered past window at %s (%d seconds).', Plugin_Time::site_datetime( $next_day_slot ), $delay ) ) ) {
					return true;
				}
			}
			$resume_at = $find_next_active_window_start( $now_ts );
			if ( $resume_at > 0 && $rearm_finalization( max( 60, $resume_at - $now_ts ), 'Update deferred: publish window closed.' ) ) {
				return true;
			}
			if ( ! empty( $update_publish_lock ) ) {
				$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $update_publish_lock ) );
				$update_publish_lock = null;
			}
			throw new \RuntimeException( 'Update deferral failed: no next publish window found within 14 days.' );
		}

		$stagger_once_key = 'seo_gen_update_stagger_done_' . (int) $item->id;
		$stagger_done     = (int) \get_transient( $stagger_once_key ) === 1;

		if ( ! $stagger_done ) {
			$next_slot_ts = $this->get_next_update_slot_ts( (int) $item->id );
			$now_ts       = Plugin_Time::now_utc_ts();

			if ( $next_slot_ts > $now_ts + 5 ) {
				$delay = $next_slot_ts - $now_ts;
				\set_transient( $stagger_once_key, 1, $delay + HOUR_IN_SECONDS );
				if ( $rearm_finalization( $delay, sprintf( 'Update deferred: next slot at %s (%d seconds).', Plugin_Time::site_datetime( $next_slot_ts ), $delay ) ) ) {
					return true;
				}
			}
		} else {
			\delete_transient( $stagger_once_key );
		}

		// Within the active publishing window: no deferral. Lock remains held
		// so the caller can serialize the actual write and release it after.
		return false;
	}

	public function auto_finalize( $item, $job_id, $user_id, bool $force = false ) {
		global $wpdb;
		$table = Installer::table_discovery();
		$update_publish_lock = null;

		$this->logger->info(
			"auto_finalize: Starting for Discovery #{$item->id} (job_id: {$job_id}, existing_post_id: " . ( $item->existing_post_id ?? 0 ) . ')'
		);

		// GUARD: If this discovery is already 'done', bail immediately.
		// rearm_finalization() closures from a prior invocation can schedule
		// check-jobs that fire after the item was already published.
		// Without this guard the stagger logic re-defers a completed item.
		$current_status = (string) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT status FROM {$table} WHERE id = %d",
				(int) $item->id
			)
		);
		if ( $current_status === 'done' ) {
			AS_Registry::cancel_item_actions( (int) $item->id );
			$this->logger->info(
				"auto_finalize: Discovery #{$item->id} is already 'done'. Skipping re-finalization."
			);
			return;
		}

		if ( $this->is_pipeline_paused() ) {
			AS_Registry::cancel_item_actions( (int) $item->id );

			// Preserve each item's staggered publish window while the engine is
			// paused. claim_item_for_finalization() nulls scheduled_at on
			// promotion, so a blind "now + 15min" re-stamp here collapses every
			// waiting item to the same imminent time (dashboard renders it as
			// "Queued") and drifts the schedule forward on every paused poll.
			// Re-derive the item's real publish slot with the same helper the
			// normal defer path uses; only fall back to a short recheck when
			// scheduling is disabled or the publish window is already closed.
			$now_ts  = Plugin_Time::now_utc_ts();
			$slot_ts = $this->get_next_update_slot_ts( (int) $item->id );

			if ( $slot_ts > $now_ts + 5 ) {
				$recheck_delay = $slot_ts - $now_ts;
				$recheck_at    = $slot_ts;
			} else {
				$recheck_delay = 900;
				$recheck_at    = $now_ts + $recheck_delay;
			}

			$wpdb->update(
				$table,
				array(
					self::COL_STATUS        => 'generating',
					self::COL_ERROR_MESSAGE => null,
					self::COL_HEARTBEAT_AT  => null,
					self::COL_SCHEDULED_AT  => Plugin_Time::utc_mysql_from_utc_ts( $recheck_at ),
				),
				array( 'id' => (int) $item->id ),
				array( '%s', '%s', '%s', '%s' ),
				array( '%d' )
			);
			if ( ! AS_Registry::schedule_check_job( (int) $item->id, (int) $job_id, (int) $user_id, 1, $recheck_delay ) ) {
				$this->logger->warning( "Discovery #{$item->id}: paused-pipeline freeze failed to schedule check_job retry." );
			}
			$this->logger->info( "Discovery #{$item->id} frozen before finalization: Engine is Paused. Publish slot preserved (" . Plugin_Time::utc_mysql_from_utc_ts( $recheck_at ) . " UTC)." );
			return;
		}

		// GUARD B: re-verify the live post version is still older than what
		// the staged discovery recorded. auto_finalize() can be invoked more
		// than once for the same discovery_id via check_and_finalize_job
		// retries, manual "Run Now" on a finalizing row, or pause/resume
		// cycles. If a previous invocation of THIS discovery already wrote
		// the new version, a second invocation would silently re-write
		// identical content. Same SSOT as Guard A: read the live post, not
		// the discovery table.
		if ( ! empty( $item->existing_post_id ) ) {
			$live_post_id   = (int) $item->existing_post_id;
			$staged_version = trim( (string) ( $item->discovered_version ?? '' ) );

			if ( $staged_version !== '' && \get_post( $live_post_id ) ) {
				$live_version = SeoGen_Version_Resolver::current_version( $live_post_id );

				if ( $live_version !== ''
					&& strcasecmp( $live_version, 'unknown' ) !== 0
					&& ! Title_Analyzer::is_newer_version( $staged_version, $live_version, $this->logger )
				) {
					AS_Registry::cancel_item_actions( (int) $item->id );

					$wpdb->update(
						$table,
						array(
							self::COL_STATUS        => Discovery_Engine::STATUS_SKIPPED_NOT_NEWER,
							self::COL_ERROR_MESSAGE => sprintf(
								'auto_finalize: post %d is already at version %s (staged: %s). Duplicate finalization suppressed.',
								$live_post_id,
								$live_version,
								$staged_version
							),
							self::COL_HEARTBEAT_AT  => null,
							self::COL_SCHEDULED_AT  => null,
							self::COL_COMPLETED_AT  => Plugin_Time::utc_mysql_now(),
							self::COL_JOB_ID        => null,
							self::COL_QUEUE_JOB_ID  => null,
						),
						array( 'id' => (int) $item->id ),
						array( '%s', '%s', '%s', '%s', '%s', '%d', '%d' ),
						array( '%d' )
					);

					$this->invalidate_dashboard_caches();
					$this->logger->info(
						sprintf(
							'Discovery %d: auto_finalize skipped_not_newer. Post %d live version=%s, staged=%s. Duplicate finalization suppressed — no content rewrite.',
							(int) $item->id,
							$live_post_id,
							$live_version,
							$staged_version
						)
					);
					return;
				}
			}
		}

		$created_new_post  = false;
		$updated_post      = false;
		$original_snapshot = array();
		$final_id          = 0;
		$replaced_thumb_id = 0;
		$draft_post_id     = 0;

		try {
			// WINDOW GATE (hoisted above PPB/build so the sentinel-absent
			// self-heal path cannot bypass the publishing window). For updates,
			// defer finalization outside the configured window instead of
			// writing immediately via the catch block.
			// $force = true SKIPS this gate — used ONLY by overdue recovery for
			// items whose scheduled slot already passed (publish immediately,
			// never re-defer). This prevents the re-deferral loop where recovery
			// re-entered maybe_defer_update_to_window() and burned a new slot.
			if ( ! $force && (int) ( $item->existing_post_id ?? 0 ) > 0 ) {
				if ( $this->maybe_defer_update_to_window( $item, $job_id, $user_id, $update_publish_lock ) ) {
					if ( ! empty( $item->draft_post_id ) && (int) $item->draft_post_id > 0 && \get_post( (int) $item->draft_post_id ) ) {
						\update_post_meta( (int) $item->draft_post_id, 'seo_gen_processed_status', 'finalizing' );
					}
					return;
				}
			}

			// Mark the source draft as 'finalizing' so the dashboard reflects actual
			// pipeline state instead of stale 'staged' while PPB builds and publishes.
			if ( ! empty( $item->draft_post_id ) && (int) $item->draft_post_id > 0 && \get_post( (int) $item->draft_post_id ) ) {
				\update_post_meta( (int) $item->draft_post_id, 'seo_gen_processed_status', 'finalizing' );
			}

			$preview = $this->job_handler->get_preview( $job_id );

			$this->logger->info( "auto_finalize: Retrieved preview for job {$job_id}, article keys: " . ( is_array( $preview['article'] ?? null ) ? implode( ', ', array_keys( $preview['article'] ) ) : 'null' ) );

			// Audit Fix: Pre-validate schema consistency BEFORE mutating WordPress content
			if ( empty( $preview['article'] ) ) {
				throw new \Exception( "Article preview is empty for Job #{$job_id}" );
			}
			\SEO_Article_Generator\Generator\Article_Schema::from_array( $preview['article'] );

			$post_id = $item->existing_post_id ? (int) $item->existing_post_id : 0;

			// ── REGEN SECTIONS SYNC GATE ───────────────────────────────────────────────────────
			// For update posts ($post_id > 0), Publish_Payload_Builder::build() reads
			// _seo_gen_regen_sections from post meta to determine the merged_clone scope
			// for surgical patching. If we write the current job's regen sections AFTER PPB
			// (as the old order did), PPB uses the PREVIOUS job's scope while write_post_meta()
			// saves the CURRENT scope — producing a permanent schema-content mismatch.
			//
			// Fix: read and persist regen sections from the current job BEFORE calling PPB::build().
			// The finalization block below still runs its own write, which is idempotent (same value).
			// The transient is NOT deleted here — the finalization block handles cleanup as before.
			// ───────────────────────────────────────────────────────────────────────────────────-
			if ( $post_id > 0 ) {
				$regen_pre_ppb = $this->job_handler->get_regen_sections( $job_id );

				if ( empty( $regen_pre_ppb ) ) {
					$regen_pre_ppb = \get_transient( 'seo_gen_regen_for_discovery_' . (int) $item->id );
				}

				if ( empty( $regen_pre_ppb ) ) {
					$snapshot_raw = \get_post_meta( $post_id, '_seo_gen_regen_sections', true );
					if ( $snapshot_raw === '' || $snapshot_raw === null ) {
						$snapshot_raw = \get_post_meta( $post_id, 'seogenregensections', true );
					}

					if ( \is_array( $snapshot_raw ) ) {
						$regen_pre_ppb = $snapshot_raw;
					} elseif ( \is_string( $snapshot_raw ) && $snapshot_raw !== '' ) {
						$decoded       = \json_decode( $snapshot_raw, true );
						$regen_pre_ppb = \is_array( $decoded ) ? $decoded : array();
					}
				}

				if ( empty( $regen_pre_ppb ) ) {
					$this->logger->error(
						sprintf(
							'Discovery %d: regen sections unavailable — job %d purged, transient expired, post meta missing. ' .
							'Refusing finalization to prevent scope drift. Manual re-approval required.',
							(int) $item->id,
							(int) $job_id
						)
					);
					throw new \RuntimeException(
						sprintf(
							'regen_sections_unresolvable: Discovery %d job %d — all three resolution paths exhausted. ' .
							'Refusing to finalize to prevent surgical patch scope drift.',
							(int) $item->id,
							(int) $job_id
						)
					);
				}

				if ( ! empty( $regen_pre_ppb ) ) {
					$normalized_regen = \SEO_Article_Generator\Generator\Article_Schema::normalize_sections(
						$regen_pre_ppb,
						$this->get_update_sections()
					);

					$normalized_regen = array_values(
						array_unique(
							array_filter(
								$normalized_regen,
								static function ( $value ) {
									return \is_string( $value ) && \trim( $value ) !== '';
								}
							)
						)
					);

					// FIX F2 (Phase 3A): the snapshot is frozen at approve-time — only
					// seed it when missing. A forced rewrite must NOT freeze its
					// new-post scope as the post's update scope: persist the global
					// update scope instead so the NEXT update uses update sections.
					if ( empty( $this->get_regen_sections_snapshot( $post_id ) ) ) {
						if ( \get_post_meta( $post_id, '_seo_gen_force_legacy_rewrite', true ) === '1' ) {
							$this->persist_regen_sections_snapshot( $post_id );
						} else {
							$regen_json = \wp_json_encode( $normalized_regen );
							\update_post_meta( $post_id, '_seo_gen_regen_sections', $regen_json );
							\update_post_meta( $post_id, 'seogenregensections', $regen_json );
						}
					}
				}
			}
			// ── END REGEN SECTIONS SYNC GATE ─────────────────────────────────────────────────

			// If the pre-generation gate forced a full rewrite on an existing post,
			// pass post_id=0 to PPB so SurgicalPatcher is bypassed entirely.
			// Sole source of truth: _seo_gen_force_legacy_rewrite meta key.
				$was_forced_full_rewrite = ( $post_id > 0 )
			&& \get_post_meta( $post_id, '_seo_gen_force_legacy_rewrite', true ) === '1';
				$ppb_post_id             = $was_forced_full_rewrite ? 0 : $post_id;

			if ( $was_forced_full_rewrite && $post_id > 0 && ! empty( $preview['article'] ) && is_array( $preview['article'] ) ) {
				$_fk = trim( (string) ( $preview['article']['focus_keyword'] ?? $preview['article']['focuskeyword'] ?? '' ) );
				$_md = trim( (string) ( $preview['article']['meta_description'] ?? $preview['article']['metadescription'] ?? '' ) );
				if ( $_fk === '' ) {
					$existing_fk = trim( (string) \get_post_meta( $post_id, 'rank_math_focus_keyword', true ) );
					if ( $existing_fk !== '' ) {
						$preview['article']['focus_keyword'] = $existing_fk;
					}
				}
				if ( $_md === '' ) {
					$existing_md = trim( (string) \get_post_meta( $post_id, 'rank_math_description', true ) );
					if ( $existing_md !== '' ) {
						$preview['article']['meta_description'] = $existing_md;
					} else {
						$_intro_parts = is_array( $preview['article']['introduction'] ?? null )
							? $preview['article']['introduction']
							: array();
						$_intro_text  = trim( implode( ' ', array_filter( array_map( 'wp_strip_all_tags', $_intro_parts ) ) ) );
						if ( $_intro_text !== '' ) {
							$_derived    = mb_substr( $_intro_text, 0, 158 );
							$_last_space = mb_strrpos( $_derived, ' ' );
							if ( $_last_space !== false && $_last_space > 80 ) {
								$_derived = mb_substr( $_derived, 0, $_last_space );
							}
							$preview['article']['meta_description'] = trim( $_derived );
						} elseif ( ! empty( $preview['article']['title'] ) || ! empty( $preview['article']['tech_specs']['software_name'] ) ) {
							$sw  = $preview['article']['tech_specs']['software_name'] ?? $preview['article']['software_name'] ?? '';
							$preview['article']['meta_description'] = trim( sprintf( 'Download %s', $sw ) );
						}
					}
				}
			}

			// [DATA-PRESERVE 2026-08-26] Forced full rewrite must not destroy sections the
			// scoped update never regenerated. When the pre-generation gates escalate an
			// update to a full rewrite (zone coverage < 50%, missing critical zone, or
			// sentinel-absent routing), the AI was still run under a SECTION-SCOPED prompt
			// contract. SIMPLE_UTILITY classification (prompt rules force faqs=[] /
			// moat_data={}) and soft-fail omissions then produce html_content WITHOUT those
			// zones; publishing that verbatim deletes live FAQ / MOAT ("Why It Stands Out")
			// content. Reuse the canonical merge primitive (Article_Schema::merged_clone,
			// same authority PPB uses on the surgical path) to inherit every section the
			// AI did not deliver from the live schema snapshot, then re-render the FULL
			// article through Content_Formatter with the persisted heading map so carried
			// sections keep their exact headings (e.g. "Why It Stands Out").
			if ( $was_forced_full_rewrite && $post_id > 0
				&& \SEO_Article_Generator\Services\Schema_Sync_Service::has_schema( $post_id ) ) {
				try {
					$_dp_base_schema    = \SEO_Article_Generator\Services\Schema_Sync_Service::load_schema( $post_id );
					$_dp_ai_schema      = \SEO_Article_Generator\Generator\Article_Schema::from_array( $preview['article'] );
					$_dp_override_scope = array();

					foreach ( \SEO_Article_Generator\Generator\Article_Schema::get_ordered_section_keys() as $_dp_key ) {
						if ( ! empty( $_dp_ai_schema->get_section_payload( $_dp_key ) ) ) {
							$_dp_override_scope[] = $_dp_key;
						}
					}

					// Always let the fresh run own hero + download: hero is rebuilt from
					// canonical DTOs at generation time and download links are SSOT-driven.
					foreach ( array( 'hero', 'download' ) as $_dp_forced ) {
						if ( ! in_array( $_dp_forced, $_dp_override_scope, true ) ) {
							$_dp_override_scope[] = $_dp_forced;
						}
					}

					$_dp_merged = \SEO_Article_Generator\Generator\Article_Schema::merged_clone(
						$_dp_base_schema,
						$_dp_ai_schema,
						$_dp_override_scope
					);

					// Preserve the current job's regen scope for downstream consumers
					// (Download_Renderer link-continuity reads regen_sections).
					if ( ! empty( $regen_sections ) ) {
						$_dp_arr              = $_dp_merged->to_array();
						$_dp_arr['regen_sections'] = array_values( array_map( 'strval', $regen_sections ) );
						$_dp_merged = \SEO_Article_Generator\Generator\Article_Schema::from_array( $_dp_arr );
					}

					$preview['article'] = $_dp_merged->to_array();

					// FIX F1 (Phase 3A): the forced-rewrite path bypasses PPB's
					// enforce_version_ssot(), so preserved (non-AI-delivered) sections
					// kept previous version strings/dates. Re-enforce here, sourced
					// from the AI schema (already canonical via the generate-time SSOT),
					// BEFORE Content_Formatter re-renders html_content below.
					$_dp_ai_arr = $_dp_ai_schema->to_array();
					$_dp_canon  = isset( $_dp_ai_arr['tech_specs']['version'] ) ? (string) $_dp_ai_arr['tech_specs']['version'] : '';
					\SEO_Article_Generator\Publishing\Publish_Payload_Builder::enforce_version_ssot( $preview['article'], $_dp_canon );
					unset( $_dp_ai_arr, $_dp_canon );

					$_dp_heading_map = array();
					$_dp_persisted   = \get_post_meta( $post_id, '_seo_gen_heading_map', true );
					if ( empty( $_dp_persisted ) || ! is_array( $_dp_persisted ) ) {
						$_dp_persisted = \get_post_meta( $post_id, 'seogenheadingmap', true );
					}
					if ( is_array( $_dp_persisted ) ) {
						$_dp_heading_map = $_dp_persisted;
					}

					if ( class_exists( '\\SEO_Article_Generator\\Generator\\Content_Formatter' ) ) {
						$_dp_formatter        = new \SEO_Article_Generator\Generator\Content_Formatter( $_dp_heading_map, true );
						// [THIN-RENDER FIX 2026-09-08] Same fix as sentinel-absent self-heal:
						// strip regen_sections before Content_Formatter so the render filter
						// does not discard preserved sections from the merge.
						$_dp_render_article   = $preview['article'];
						unset( $_dp_render_article['regen_sections'] );
						$_dp_rendered         = (string) $_dp_formatter->to_html( $_dp_render_article, $post_id );
						if ( trim( $_dp_rendered ) !== '' ) {
							$preview['article']['html_content'] = $_dp_rendered;
							$this->logger->info(
								sprintf(
									'Discovery %d: forced-rewrite preserve merge applied for post %d — override scope: %s.',
									(int) $item->id,
									$post_id,
									implode( ', ', $_dp_override_scope )
								)
							);
						}
					}

					unset( $_dp_base_schema, $_dp_ai_schema, $_dp_override_scope, $_dp_merged, $_dp_heading_map, $_dp_persisted, $_dp_formatter, $_dp_rendered, $_dp_key, $_dp_forced, $_dp_arr );
				} catch ( \Throwable $_dp_merge_error ) {
					$this->logger->warning(
						sprintf(
							'Discovery %d: forced-rewrite preserve merge failed for post %d — falling back to plain rewrite. Error: %s',
							(int) $item->id,
							$post_id,
							$_dp_merge_error->getMessage()
						)
					);
				}
			}

			try {
				$payload_data = \SEO_Article_Generator\Publishing\Publish_Payload_Builder::build( $preview, $ppb_post_id );
			} catch ( \Throwable $e ) {
				throw new \RuntimeException(
					'Publish payload build failed: ' . $e->getMessage(),
					0,
					$e
				);
			}

			$post_content = $payload_data['content'];
			$post_title   = ! empty( $payload_data['title'] ) ? $payload_data['title'] : $item->software_name;
			$preview      = $payload_data['preview'];
			$meta_input   = $payload_data['meta_input'] ?? array();

			// Deterministic internal links are injected on the FINAL content just
			// before persistence for both paths (see seo_gen_apply_internal_links
			// below at the update/new-post array builds, and the self-heal write),
			// so the sentinel-absent self-heal render (which reassigns $post_content
			// later in auto_finalize) is also covered.
			// Standard path: $post_content is final here (self-heal reassigns it
			// later and applies the injector at its own persistence point).
			// empty() is used because $sentinel_self_heal_ok is declared further
			// down (self-heal block) and not yet defined on the standard path.
			if ( empty( $sentinel_self_heal_ok ) ) {
				$post_content = $this->seo_gen_apply_internal_links( $post_content, $item, (int) $post_id );
			}

			// When PPB ran as new-post (post_id=0 bypass), preserve existing title
			// and hero data that the new-post branch cannot access.
			if ( $was_forced_full_rewrite && $post_id > 0 ) {
				$existing_post_for_rewrite = \get_post( $post_id );
				if ( $existing_post_for_rewrite && ! empty( $existing_post_for_rewrite->post_title ) ) {
					$new_version = trim( (string) ( $preview['article']['tech_specs']['version'] ?? '' ) );
					if ( class_exists( '\SEO_Article_Generator\Discovery\Title_Analyzer' ) && $new_version !== '' ) {
						$analyzer  = new \SEO_Article_Generator\Discovery\Title_Analyzer();
						$extracted = $analyzer->extract( $existing_post_for_rewrite->post_title );
						if ( ! empty( $extracted['version'] ) ) {
							$title_vr_pattern = '/\b' . preg_quote( (string) $extracted['version'], '/' ) . '\b/i';
							$post_title       = preg_replace( $title_vr_pattern, $new_version, $existing_post_for_rewrite->post_title );
						} else {
							$post_title = $existing_post_for_rewrite->post_title;
						}
					} else {
						$post_title = $existing_post_for_rewrite->post_title;
					}
				}

				$existing_hero = \get_post_meta( $post_id, 'seogenherodata', true );
				if ( is_array( $existing_hero ) && ! empty( $meta_input['seogenherodata'] ) && is_array( $meta_input['seogenherodata'] ) ) {
					foreach ( array( 'logo_url', 'rating', 'rating_count', 'last_verified_date' ) as $_hero_key ) {
						if ( empty( $meta_input['seogenherodata'][ $_hero_key ] ) && ! empty( $existing_hero[ $_hero_key ] ) ) {
							$meta_input['seogenherodata'][ $_hero_key ] = $existing_hero[ $_hero_key ];
						}
					}
				}
			}

			if ( $post_id ) {
				$this->logger->info( "Restoring Pipeline: Finalizing Update for Discovery #{$item->id} (Post #{$post_id})" );



				// ── POST PERSISTENCE: Update Path ──────────────────────────────────────
				$existing_post = \get_post( $post_id );
				if ( $existing_post ) {
					$updated_post      = true;
					$original_snapshot = array(
						'post_content' => $existing_post->post_content,
						'post_title'   => $existing_post->post_title,
						'categories'   => \wp_get_post_categories( $post_id, array( 'fields' => 'ids' ) ),
						'tags'         => \wp_get_post_tags( $post_id, array( 'fields' => 'ids' ) ),
						'thumbnail_id' => (int) \get_post_thumbnail_id( $post_id ),
						'meta'         => array(),
						'schema'       => \SEO_Article_Generator\Services\Schema_Sync_Service::has_schema( $post_id )
							? \SEO_Article_Generator\Services\Schema_Sync_Service::load_schema( $post_id )
							: null,
					);
					$all_meta_keys     = \get_post_custom_keys( $post_id );
					if ( is_array( $all_meta_keys ) ) {
						foreach ( $all_meta_keys as $mk ) {
							if ( 0 === strpos( $mk, '_seo_gen_' ) || 0 === strpos( $mk, 'seogen' ) || 0 === strpos( $mk, 'rank_math_' ) ) {
								$original_snapshot['meta'][ $mk ] = \get_post_meta( $post_id, $mk, true );
							}
						}
					}
				}

				// Derive post_excerpt from meta_description — BUT honor [META-PRESERVE]:
				// when this is a plugin-owned update that already carries a
				// rank_math_description, keep the existing meta so post_excerpt, hero
				// description, and social shares never diverge from the SEO meta.
				$_meta_description = '';
				if ( $post_id > 0 && \SEO_Article_Generator\Discovery\Post_Type_Classifier::is_plugin_owned(
					\SEO_Article_Generator\Discovery\Post_Type_Classifier::classify( $post_id )
				) ) {
					$_preserved_md = trim( (string) \get_post_meta( $post_id, 'rank_math_description', true ) );
					if ( $_preserved_md !== '' ) {
						$_meta_description = $_preserved_md;
					}
				}
				if ( $_meta_description === '' ) {
					$_meta_description = trim( (string) ( $preview['article']['meta_description'] ?? '' ) );
					if ( $_meta_description === '' && ! empty( $preview['article']['introduction'] ) ) {
						$_intro_parts = is_array( $preview['article']['introduction'] ) ? $preview['article']['introduction'] : array( $preview['article']['introduction'] );
						$_intro_text  = trim( implode( ' ', array_filter( array_map( 'wp_strip_all_tags', $_intro_parts ) ) ) );
						if ( $_intro_text !== '' ) {
							$_derived    = mb_substr( $_intro_text, 0, 158 );
							$_last_space = mb_strrpos( $_derived, ' ' );
							if ( $_last_space !== false && $_last_space > 80 ) {
										$_derived = mb_substr( $_derived, 0, $_last_space );
							}
							// [SSOT-FIX Finding 11] Strip version from intro-derived excerpt so
							// post_excerpt never carries software version. Uses the same
							// repair_meta_to_spec() the normal path runs in write_post_meta().
							if ( class_exists( '\SEO_Article_Generator\Generator\Hero_Data_Provider' ) ) {
								$_derived = \SEO_Article_Generator\Generator\Hero_Data_Provider::repair_meta_to_spec( $_derived, $preview['article'] );
							}
							$_meta_description = trim( $_derived );
						}
					}
				}

				// [SSOT-FIX] REMOVED duplicate "Derive post_excerpt" block. The second
				// copy (formerly lines 2848-2861) was dead-code duplication: it re-read
				// $preview['article']['meta_description'] and overwrote the result of
				// the first block with the same value, producing zero functional
				// change but doubling the version-strip call cost. Determinism required
				// a single derivation path; the duplicate has been removed.

			$post_arr = array(
					'ID'           => $post_id,
					'post_content' => $post_content,
					'post_title'   => $post_title,
					'post_excerpt' => $_meta_description,
				);
				if ( $existing_post && ! empty( $existing_post->post_name ) ) {
					$post_arr['post_name'] = $existing_post->post_name;
				}
			if ( ! empty( $meta_input[ \SEO_Article_Generator\EEAT\Article_Attribution_Metabox::META_PRIMARY_AUTHOR ] ) ) {
				$post_arr['post_author'] = (int) $meta_input[ \SEO_Article_Generator\EEAT\Article_Attribution_Metabox::META_PRIMARY_AUTHOR ] ;
			}

			// Legacy update: DO NOT set post_date/edit_date — the stagger delay
				// already controls timing of content replacement. Changing post_date
				// to a future value would either cause WordPress to flip status to
				// 'future' (404) or show "published in the future" — both wrong.
				// Keep the original publish date; only post_modified changes.

				$final_id = $this->job_handler->finalize_generated_post( $post_id, $post_arr );

				$this->logger->info( "Finalize post result for Discovery #{$item->id}: final_id={$final_id}, post_id={$post_id}, is_update=true" );

				if ( ! empty( $update_publish_lock ) ) {
					$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $update_publish_lock ) );
					$update_publish_lock = null;
				}
				// ── END POST PERSISTENCE: Update Path ──────────────────────────────────
			} else {
					// ── POST PERSISTENCE: New Post Path ─────────────────────────────────
					$created_new_post = true;

					$publish_mode = (string) \get_option( \SEO_Article_Generator\Option_Registry::DISCOVERY_PUBLISH_STATUS, \SEO_Article_Generator\Option_Registry::defaults()[ \SEO_Article_Generator\Option_Registry::DISCOVERY_PUBLISH_STATUS ] );
					$publish_mode = ( $publish_mode === 'draft' ) ? 'draft' : 'publish';

					$publish_ts = $this->calculate_scheduled_publish_date();
					$is_future  = ( $publish_ts > Plugin_Time::now_utc_ts() + 60 );

				if ( $publish_mode === 'draft' ) {
					$status = 'draft';
				} else {
					$status = $is_future ? 'future' : 'publish';
				}

				$this->logger->info(
					sprintf(
						'Auto-Finalize: Scheduling New Post for Discovery %d. Mode=%s. Status=%s. Date=%s',
						$item->id,
						$publish_mode,
						$status,
						Plugin_Time::site_datetime( $publish_ts )
					)
				);

				$ai_slug           = (string) ( $preview['article']['slug'] ?? '' );
				$software_name_raw = (string) ( $item->software_name ?? '' );
				// [ISSUE-6 FIX] Use Canonical_Slug_Service for evergreen clean slugs (no version)
				$clean_slug        = \SEO_Article_Generator\Utils\Canonical_Slug_Service::ensure_clean_slug_for_new_post($software_name_raw);

			// Derive post_excerpt from meta_description
			$_meta_description = trim( (string) ( $preview['article']['meta_description'] ?? '' ) );
			// [SSOT-FIX 2.34.20] Run repair_meta_to_spec on AI-returned meta_description
			// so post_excerpt matches what write_post_meta() will write to rank_math_description.
			if ( $_meta_description !== '' && class_exists( '\\SEO_Article_Generator\\Generator\\Hero_Data_Provider' ) ) {
				$_meta_description = \SEO_Article_Generator\Generator\Hero_Data_Provider::repair_meta_to_spec( $_meta_description, $preview['article'] );
			}
			if ( $_meta_description === '' && ! empty( $preview['article']['introduction'] ) ) {
					$_intro_parts = is_array( $preview['article']['introduction'] ) ? $preview['article']['introduction'] : array( $preview['article']['introduction'] );
					$_intro_text  = trim( implode( ' ', array_filter( array_map( 'wp_strip_all_tags', $_intro_parts ) ) ) );
					if ( $_intro_text !== '' ) {
								$_derived    = mb_substr( $_intro_text, 0, 158 );
								$_last_space = mb_strrpos( $_derived, ' ' );
						if ( $_last_space !== false && $_last_space > 80 ) {
							$_derived = mb_substr( $_derived, 0, $_last_space );
						}
						// [SSOT-FIX Finding 11] Strip version from intro-derived excerpt for new posts too.
						if ( class_exists( '\SEO_Article_Generator\Generator\Hero_Data_Provider' ) ) {
							$_derived = \SEO_Article_Generator\Generator\Hero_Data_Provider::repair_meta_to_spec( $_derived, $preview['article'] );
						}
									$_meta_description = trim( $_derived );
					}
				}

			$post_data = array(
					'post_title'   => $post_title,
					'post_content' => $post_content,
					'post_status'  => $status,
					'post_author'  => (int) $user_id,
					'post_name'    => $clean_slug,
					'post_type'    => 'post',
					'edit_date'    => true,
					'post_excerpt' => $_meta_description,
				);
				if ( $status !== 'draft' ) {
					$post_data['post_date']     = Plugin_Time::site_mysql_from_utc_ts( $publish_ts );
					$post_data['post_date_gmt'] = Plugin_Time::utc_mysql_from_utc_ts( $publish_ts );
				}

				if ( ! empty( $meta_input[ \SEO_Article_Generator\EEAT\Article_Attribution_Metabox::META_PRIMARY_AUTHOR ] ) ) {
					$post_data['post_author'] = (int) $meta_input[ \SEO_Article_Generator\EEAT\Article_Attribution_Metabox::META_PRIMARY_AUTHOR ];
				}

					$this->logger->info( "Restoring Pipeline: Finalizing New Post for Discovery #{$item->id}" );
					$final_id = $this->job_handler->finalize_generated_post( 0, $post_data );

				$this->logger->info( "Finalize post result for Discovery #{$item->id}: final_id={$final_id}, post_id=0, is_update=false" );

				// ── INTERNAL LINKS for new posts ────────────────────────────────
				// seo_gen_apply_internal_links() ran above (line ~3093) with
				// post_id=0 which SKIPS the Link Whisper bridge. Now that the
				// post exists ($final_id > 0), re-run injection so LW can place
				// contextual links. The deterministic injector also benefits
				// from a real post_id for self-link exclusion.
				if ( $final_id > 0 ) {
					$post_content = $this->seo_gen_apply_internal_links(
						$post_content, $item, (int) $final_id
					);
					\wp_update_post( array(
						'ID'           => (int) $final_id,
						'post_content' => $post_content,
					) );
				}
				// ── END POST PERSISTENCE: New Post Path ─────────────────────────────
			}

			// ── SHARED FINALIZATION: runs for both update and new-post paths ──────
			if ( $final_id > 0 ) {
				// CRITICAL: Capture the legacy rewrite flag state BEFORE write_post_meta()
				// clears it at line ~3110. The done_type override at line ~2545 needs this
				// value to correctly report the actual processing path in the Completed Tab.
				$had_force_legacy_rewrite = ! empty( $item->existing_post_id )
					&& \get_post_meta( (int) $item->existing_post_id, '_seo_gen_force_legacy_rewrite', true ) === '1';

				$this->write_post_meta( $final_id, $item, $job_id, $preview, $user_id, $meta_input );

				// FEATURED IMAGE RESOLUTION
				$thumbnail_set        = false;
				$draft_post_id        = ! empty( $item->draft_post_id ) ? (int) $item->draft_post_id : 0;
				$pre_replace_thumb_id = (int) \get_post_thumbnail_id( $final_id );
				if ( $draft_post_id > 0 ) {
					$draft_thumb_id = (int) \get_post_thumbnail_id( $draft_post_id );
					if ( $draft_thumb_id > 0 && \get_post( $draft_thumb_id ) ) {
						\set_post_thumbnail( $final_id, $draft_thumb_id );
						$thumbnail_set     = true;
						$replaced_thumb_id = $pre_replace_thumb_id;
						\wp_update_post(
							array(
								'ID'          => $draft_thumb_id,
								'post_parent' => $final_id,
							)
						);
						$this->logger->info( "Featured image: reused local attachment {$draft_thumb_id} from WP-Auto draft (reparented to post {$final_id})." );
						\SEO_Article_Generator\Discovery\Discovery_Engine::rename_attachment_to_software( $draft_thumb_id, (string) ( $item->software_name ?? '' ), $this->logger );
						\delete_post_thumbnail( $draft_post_id );
						$thumb_url = \wp_get_attachment_image_url( $draft_thumb_id, 'full' );
						if ( $thumb_url ) {
							$herodata = \get_post_meta( $final_id, 'seogenherodata', true );
							if ( is_array( $herodata ) && empty( $herodata['logo_url'] ) ) {
								$herodata['logo_url']           = $thumb_url;
								// [FIX 2026-07-25] Use canonical date formats matching Hero_Data_Provider::from_schema()
								// so Plugin::normalize_hero_data() does not produce a different ISO representation
								// when it round-trips last_updated through strtotime()/wp_date(). last_updated was
								// previously written as 'Y-m-d' while every other writer uses 'F j, Y' — causing
								// the hero meta box to render a different Last Updated label than the frontend
								// after each image-reparent.
								$herodata['last_updated']       = date( 'F j, Y' );
								$herodata['last_verified_date'] = gmdate( 'Y-m-d' );
								\SEO_Article_Generator\Plugin::get_instance()->write_hero_data( $final_id, $herodata );
							}
						}
					}
				}
				if ( ! $thumbnail_set ) {
					$source_post_id = ! empty( $item->existing_post_id ) ? (int) $item->existing_post_id : 0;
					if ( $source_post_id > 0 ) {
						$existing_thumb_id = (int) \get_post_thumbnail_id( $source_post_id );
						if ( $existing_thumb_id > 0 && \get_post( $existing_thumb_id ) ) {
							\set_post_thumbnail( $final_id, $existing_thumb_id );
							$thumbnail_set = true;
							// FIX F7 (Phase 3B, 2.32.26): capture the replaced thumb like the
							// draft branch does, so the post-finalization cleanup can delete a
							// newly-orphaned NEW-from-existing thumbnail (the refcount guard at
							// the tail still preserves attachments shared by other posts).
							// Typical update finalizes final_id === source_post_id (no-op set,
							// pre==existing) leaving $replaced_thumb_id = 0 as before.
							$replaced_thumb_id = $pre_replace_thumb_id;
							$this->logger->info( "Featured image: inherited attachment {$existing_thumb_id} from source post." );
							$thumb_url = \wp_get_attachment_image_url( $existing_thumb_id, 'full' );
							if ( $thumb_url ) {
								$herodata = \get_post_meta( $final_id, 'seogenherodata', true );
								if ( is_array( $herodata ) && empty( $herodata['logo_url'] ) ) {
									$herodata['logo_url']           = $thumb_url;
									// [FIX 2026-07-25] Use canonical date formats matching Hero_Data_Provider::from_schema()
									// so Plugin::normalize_hero_data() does not produce a different ISO representation
									// when it round-trips last_updated through strtotime()/wp_date(). last_updated was
									// previously written as 'Y-m-d' while every other writer uses 'F j, Y' — causing
									// the hero meta box to render a different Last Updated label than the frontend
									// after each image-reparent.
									$herodata['last_updated']       = date( 'F j, Y' );
									$herodata['last_verified_date'] = gmdate( 'Y-m-d' );
									\SEO_Article_Generator\Plugin::get_instance()->write_hero_data( $final_id, $herodata );
								}
							}
						}
					}
				}
				if ( ! $thumbnail_set ) {
					$this->schedule_featured_image_sideload(
						$final_id,
						(string) ( $item->source_image_url ?? '' ),
						(string) ( $item->source_thumbnail_url ?? '' ),
						(int) $item->id,
						(int) $user_id
					);
				}
			}

			// Resolve canonical type for the done row.
			// Preserve the original discovery type ("new" / "legacy" / "plugingenerated")
			// that was set at pipeline entry.  Re-canonicalizing against the published
			// post ($final_id) would overwrite "new" to "plugingenerated" because the
			// freshly-created post carries plugin meta signals — breaking the dashboard
			// Generation Activities card where "New Posts" would always read 0.
			$done_type = $item->type ?? Post_Type_Classifier::TYPE_NEW;

			// CRITICAL FIX: When _seo_gen_force_legacy_rewrite was active, the post was
			// processed through the TYPE_LEGACY full-rewrite path (new post sections with TOC).
			// The discovery row type may still show the pre-flag classification (e.g.
			// "plugingeneratedlegacy"), but the actual processing was a legacy rewrite.
			// Override done_type to "legacy" so the Completed Tab shows the correct path.
			// On the NEXT update, the flag will be cleared (write_post_meta) and the post
			// will be properly classified as TYPE_PLUGIN.
			// NOTE: $had_force_legacy_rewrite was captured BEFORE write_post_meta() cleared
			// the flag, because reading from DB here would always return false.
			if ( ! empty( $had_force_legacy_rewrite ) ) {
				$done_type = Post_Type_Classifier::TYPE_LEGACY;
			}

			// Resolve discovered_version for the done row. The AI preview is the
			// freshest source (it just generated it), so it wins. The post state
			// (seogenherodata / _seo_gen_hero_data / _seo_gen_version / post
			// title) is the fallback. SeoGen_Version_Resolver is the single
			// source of truth for the post-state ladder — same priority order
			// the staging-time is_newer_version() gate and the duplicate-update
			// guards use.
			$resolved_version = '';
			if ( ! empty( $preview['article'] ) && is_array( $preview['article'] ) ) {
				$resolved_version = trim(
					(string) (
					$preview['article']['hero_section']['version'] ??
					$preview['article']['tech_specs']['version'] ?? ''
					)
				);
			}
			if ( $resolved_version === '' && $final_id > 0 ) {
				$resolved_version = SeoGen_Version_Resolver::current_version( $final_id );
			}

			$done_update  = array(
				self::COL_STATUS           => 'done',
				self::COL_EXISTING_POST_ID => $final_id,
				'type'                     => $done_type,
				self::COL_COMPLETED_AT     => Plugin_Time::utc_mysql_now(),
				// FIX F4: success resets the breaker.
				self::COL_CONSECUTIVE_FAILURES => 0,
				self::COL_LAST_FAILURE_AT     => null,
			);
			$done_formats = array( '%s', '%d', '%s', '%s', '%d', '%s' );
			// CRITICAL FIX: Do NOT overwrite current_version with the new version.
			// current_version holds the OLD (pre-update) version from discovery time.
			// The dashboard displays discovered_version as "new" and current_version as "was X".
			// Overwriting current_version here caused both columns to show the same new version.
			// Instead, update discovered_version with the AI-resolved version for consistency.
			if ( $resolved_version !== '' ) {
				$done_update['discovered_version'] = $resolved_version;
				$done_formats[]                    = '%s';
			}

			$wpdb->update(
				$table,
				$done_update,
				array( 'id' => (int) $item->id ),
				$done_formats,
				array( '%d' )
			);

			// FIX: Verify the status update actually affected a row.
			// If 0 rows affected, the discovery row was already moved (race condition)
			// or the ID is stale. Throw to prevent silent 'finalizing' state persistence.
			$updated_rows = $wpdb->rows_affected;
			if ( (int) $updated_rows === 0 ) {
				$this->logger->error(
					'auto_finalize: Failed to update discovery #' . (int) $item->id . ' to done — 0 rows affected'
				);
				throw new \RuntimeException(
					'Discovery status update failed: 0 rows affected for ID ' . (int) $item->id
				);
			}

			// Delete the consumed job — output_data is no longer needed once
			// the post has been written. Prevents stale reuse, keeps jobs table lean.
			$this->job_handler->delete_job( $job_id );

			$this->invalidate_dashboard_caches();

				// CLOUDFLARE CACHE FIX: Fire an immediate (non-queued) purge for the
				// finalized post URL and homepage. The Cloudflare plugin's edit_post hook
				// writes to a file queue drained by WP-Cron — if cron is delayed or
				// disabled the queue never processes and the homepage stays stale.
				// do_action('swcfpc_purge_cache', $urls) calls Cache_Controller::purge_urls()
				// with queue_mode=false, bypassing the queue entirely.
				if ( (int) $final_id > 0 ) {
					$_cf_purge_urls = array();
					$_cf_perm       = \get_permalink( (int) $final_id );
					if ( $_cf_perm ) {
						$_cf_purge_urls[] = $_cf_perm;
					}
					$_cf_home = \home_url( '/' );
					if ( $_cf_home && ! \in_array( $_cf_home, $_cf_purge_urls, true ) ) {
						$_cf_purge_urls[] = $_cf_home;
					}
					if ( \get_option( 'show_on_front' ) === 'page' ) {
						$_cf_ppid = (int) \get_option( 'page_for_posts' );
						if ( $_cf_ppid > 0 ) {
							$_cf_plink = \get_permalink( $_cf_ppid );
							if ( $_cf_plink && ! \in_array( $_cf_plink, $_cf_purge_urls, true ) ) {
								$_cf_purge_urls[] = $_cf_plink;
							}
						}
					}
					if ( ! empty( $_cf_purge_urls ) ) {
						\do_action( 'swcfpc_purge_cache', $_cf_purge_urls );
						$this->logger->info( 'Cloudflare page-cache purged (post + homepage): ' . implode( ', ', array_slice( $_cf_purge_urls, 0, 5 ) ) );
					}
				}

				$this->logger->info( 'Discovery ' . (int) $item->id . ': finalized and dashboard cache invalidated.' );

			// Deferred replaced-featured-image cleanup.
			// Only delete the old attachment after finalization is confirmed done.
			// If finalization fails and rolls back, the old image must still exist for restore.
		if ( $replaced_thumb_id > 0 ) {
			// Guard: if $replaced_thumb_id is still the active thumbnail of the
			// published post, this is a self-replacement (draft reused the same
			// attachment).  Do NOT delete — the image is still live.
			$current_active_thumb = (int) \get_post_thumbnail_id( $final_id );
			if ( $replaced_thumb_id !== $current_active_thumb ) {
				$still_used = (int) $wpdb->get_var(
					$wpdb->prepare(
						"SELECT COUNT(*) FROM {$wpdb->postmeta}
					 WHERE meta_key = '_thumbnail_id' AND meta_value = %d",
						$replaced_thumb_id
					)
				);
				if ( $still_used <= 0 ) {
						\wp_delete_attachment( $replaced_thumb_id, true );
						$this->logger->info( "Featured image cleanup: deleted replaced attachment {$replaced_thumb_id} after successful finalization." );
				} else {
					$this->logger->info( "Featured image cleanup: skipped deletion of replaced attachment {$replaced_thumb_id}, still referenced by {$still_used} post(s)." );
				}
			}
		}

				// Re-schedule WP-Auto draft deletion after successful finalization.
				// The deletion was cancelled in process_item_background() to protect the
				// draft during generation. Now that finalization succeeded, re-schedule
				// using the single source of truth for delay computation.
			if (
			! empty( $item->source_type ) && $item->source_type === 'wp_automatic'
			&& (int) ( $item->draft_post_id ?? 0 ) > 0
			&& \get_post( (int) $item->draft_post_id )
			) {
				\SEO_Article_Generator\Discovery\Discovery_Engine::schedule_draft_deletion( (int) $item->draft_post_id );
			}

			// Update seo_gen_processed_status on the source draft so the WP admin
			// shows the actual lifecycle state instead of stale 'staged'.
			if ( ! empty( $item->draft_post_id ) && (int) $item->draft_post_id > 0 && \get_post( (int) $item->draft_post_id ) ) {
				\update_post_meta( (int) $item->draft_post_id, 'seo_gen_processed_status', 'completed' );
			}

			// ── END SHARED FINALIZATION ───────────────────────────────────────────

		} catch ( \Throwable $e ) {
			// Release the update publish lock before rollback so lock leakage cannot stall later finalizations.
			if ( ! empty( $update_publish_lock ) ) {
				$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $update_publish_lock ) );
				$update_publish_lock = null;
			}

			// DEFENSE-IN-DEPTH: re-check the publishing window before the immediate
			// self-heal write. Sentinel-absent posts passed the hoisted gate before
			// PPB::build(), so this is normally a no-op; if scheduling is enabled and we
			// are somehow outside the window, defer instead of writing now.
			// FIX: respect $force — when caller passed force=true (handle_job_finished,
			// check_and_finalize_job, overdue_recovery), the intent is "publish NOW".
			// Unconditionally re-entering maybe_defer_update_to_window() caused an
			// infinite re-deferral loop where forced finalizations were deferred again
			// on failure, then re-finalized when the deferred slot arrived, failed
			// again, and so on forever.
			if ( ! $force && (int) ( $item->existing_post_id ?? 0 ) > 0 ) {
				try {
					if ( $this->maybe_defer_update_to_window( $item, $job_id, $user_id, $update_publish_lock ) ) {
						return;
					}
					if ( ! empty( $update_publish_lock ) ) {
						$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $update_publish_lock ) );
						$update_publish_lock = null;
					}
				} catch ( \Throwable $ge ) {
					$this->logger->warning( 'Self-heal window re-check failed: ' . $ge->getMessage() );
					if ( ! empty( $update_publish_lock ) ) {
						$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $update_publish_lock ) );
						$update_publish_lock = null;
					}
				}
			}

			// SENTINEL ABSENT RECOVERY: If SurgicalPatcher reported no sentinel structure,
			// this post was classified as TYPE_PLUGIN but has no zone delimiters.
			// Re-queue with isupdate=false to force a full TYPE_LEGACY rewrite on retry.
			$message = (string) $e->getMessage();

			if (
				strpos( $message, 'migration_failed_missing_block_delimiters' ) !== false
				|| strpos( $message, 'TYPE_PLUGIN_LEGACY sentinel migration failed' ) !== false
			) {
				// SENTINEL-ABSENT RECOVERY: the live plugin post has no block delimiters,
				// so Publish_Payload_Builder (PPB) cannot patch it. The generator sets
				// html_content = '' for TYPE_PLUGIN / TYPE_PLUGIN_LEGACY posts by design
				// (class-article-generator.php ~1942/1958), and the generator routes on
				// Post_Type_Classifier::classify($existing_post_id) which still reports
				// TYPE_PLUGIN for these posts — so a plain PPB re-run would write EMPTY
				// content and wipe the published post. The ONLY renderer that works for
				// sentinel-absent plugin posts is Content_Formatter::to_html(), which the
				// standard TYPE_LEGACY full-rewrite path also uses internally.
				//
				// The fix below RENDERS via Content_Formatter (correct renderer) but feeds
				// the output into the SAME shared finalization tail as every other update:
				// featured-image reparent, Cloudflare purge, replaced-attachment cleanup and
				// draft deletion all run from the shared tail at ~2836, NOT duplicated here.
				$sentinel_self_heal_ok = false;
				if (
					! empty( $item->existing_post_id )
					&& ! empty( $preview )
					&& ! empty( $preview['article'] )
					&& is_array( $preview['article'] )
				) {
					$_sh_post_id = (int) $item->existing_post_id;
					$_sh_existing = \get_post( $_sh_post_id );
					$_sh_article = $preview['article'];

					// [SSOT-FIX] Re-enforce version SSOT + today's date across every
					// version-bearing surface of the article BEFORE the downstream
					// consumers (Hero_Data_Provider::repair_meta_to_spec, Content_Formatter::to_html,
					// Publish_Payload_Builder::buildHeroMetaInput) read it. The self-heal
					// path historically bypassed Publish_Payload_Builder::build() (which is
					// the normal path SSOT entry point, class-publish-payload-builder.php:284),
					// so hero_section.version, hero_section.last_updated, tech_specs.last_updated
					// and meta_description substring rewrites never ran — leaving the Hero
					// meta version badge and "Last Updated" date lagging the canonical title /
					// tech_specs table. Log evidence 2026-07-23: self-heal finalizations
					// for posts 1056/8975/9090/13987 carried AI hallusinated versions
					// (e.g. 9.0.44.51 vs canonical 9.0.45.63) and AI-returned stagger dates
					// (e.g. "January 2025") into the published hero meta.
					if ( class_exists( '\\SEO_Article_Generator\\Publishing\\Publish_Payload_Builder' ) ) {
						\SEO_Article_Generator\Publishing\Publish_Payload_Builder::enforce_version_ssot( $_sh_article );
						$preview['article'] = $_sh_article;
					}

					// [SSOT-FIX] Repair meta_description version BEFORE Content_Formatter
					// and buildHeroMetaInput consume the article. The self-heal path bypasses
					// PPB's re-enforcement (class-publish-payload-builder.php:284-350), so the
					// stale meta_description from merged_clone's base_schema leaks through.
					$_sh_meta_desc = trim( (string) ( $_sh_article['meta_description'] ?? '' ) );
					if ( $_sh_meta_desc !== '' && class_exists( '\\SEO_Article_Generator\\Generator\\Hero_Data_Provider' ) ) {
						$_sh_repaired = \SEO_Article_Generator\Generator\Hero_Data_Provider::repair_meta_to_spec( $_sh_meta_desc, $_sh_article );
						if ( $_sh_repaired !== '' && $_sh_repaired !== $_sh_meta_desc ) {
							$_sh_article['meta_description'] = $_sh_repaired;
							$preview['article']['meta_description'] = $_sh_repaired;
						}
					}
					unset( $_sh_meta_desc, $_sh_repaired );

					if ( $_sh_existing ) {
						$_sh_heading_map = array();
						if ( ! empty( $_sh_article['_seo_gen_heading_map'] ) && is_array( $_sh_article['_seo_gen_heading_map'] ) ) {
							$_sh_heading_map = $_sh_article['_seo_gen_heading_map'];
						} elseif ( ! empty( $_sh_article['seogenheadingmap'] ) && is_array( $_sh_article['seogenheadingmap'] ) ) {
							$_sh_heading_map = $_sh_article['seogenheadingmap'];
						}

						// Full new-pipeline section set (DISCOVERY_SECTIONS) — matches the
						// TYPE_LEGACY full-rewrite path used by the standard pipeline.
						$_sh_selected = $this->get_new_post_sections();
						$_sh_selected = \SEO_Article_Generator\Generator\Article_Schema::normalize_sections( $_sh_selected, array() );
						$_sh_selected = array_values( array_unique( array_filter( $_sh_selected, static function ( $z ) {
							return is_string( $z ) && $z !== '' && $z !== 'all' && $z !== 'toc';
						} ) ) );

						// [DATA-PRESERVE 2026-08-26] Sentinel-absent self-heal must not drop sections the
						// live post still owns. The AI was run under a scoped contract; its output lacks
						// moat/FAQ/etc. Merge the live schema snapshot (if any) so the full re-render
						// inherits all unregenerated zones with their exact headings.
						if ( \SEO_Article_Generator\Services\Schema_Sync_Service::has_schema( $_sh_post_id ) ) {
							try {
								$_sh_base_schema    = \SEO_Article_Generator\Services\Schema_Sync_Service::load_schema( $_sh_post_id );
								$_sh_ai_schema      = \SEO_Article_Generator\Generator\Article_Schema::from_array( $_sh_article );
								$_sh_override_scope = array();

								foreach ( \SEO_Article_Generator\Generator\Article_Schema::get_ordered_section_keys() as $_sh_key ) {
									if ( ! empty( $_sh_ai_schema->get_section_payload( $_sh_key ) ) ) {
										$_sh_override_scope[] = $_sh_key;
									}
								}

								foreach ( array( 'hero', 'download' ) as $_sh_forced ) {
									if ( ! in_array( $_sh_forced, $_sh_override_scope, true ) ) {
										$_sh_override_scope[] = $_sh_forced;
									}
								}

								$_sh_merged = \SEO_Article_Generator\Generator\Article_Schema::merged_clone(
									$_sh_base_schema,
									$_sh_ai_schema,
									$_sh_override_scope
								);

								$_sh_arr = $_sh_merged->to_array();
								$_sh_ai_arr = $_sh_ai_schema->to_array();

								foreach ( array( 'title', 'meta_description', 'slug', 'focus_keyword', 'tags', 'category', 'long_tail_keywords', 'keyword_variations' ) as $_sh_top ) {
									if ( ! empty( $_sh_ai_arr[ $_sh_top ] ) ) {
										$_sh_arr[ $_sh_top ] = $_sh_ai_arr[ $_sh_top ];
									}
								}

								$_sh_canonical_version = '';
								if ( ! empty( $_sh_ai_arr['tech_specs']['version'] ) ) {
									$_sh_canonical_version = (string) $_sh_ai_arr['tech_specs']['version'];
								}
								if ( class_exists( '\\SEO_Article_Generator\\Publishing\\Publish_Payload_Builder' ) ) {
									\SEO_Article_Generator\Publishing\Publish_Payload_Builder::enforce_version_ssot( $_sh_arr, $_sh_canonical_version );
								}

								$_sh_article = $_sh_arr;
								$preview['article'] = $_sh_arr;

								$this->logger->info(
									sprintf(
										'Discovery %d: self-heal preserve merge applied for post %d — override scope: %s.',
										(int) $item->id,
										$_sh_post_id,
										implode( ', ', $_sh_override_scope )
									)
								);
							} catch ( \Throwable $_sh_merge_error ) {
								$this->logger->warning(
									sprintf(
										'Discovery %d: self-heal preserve merge failed for post %d — falling back to plain rewrite. Error: %s',
										(int) $item->id,
										$_sh_post_id,
										$_sh_merge_error->getMessage()
									)
								);
							}
						}

						// [PHASE 3D, 2.32.28] DEFENSE-IN-DEPTH thin-output guard.
						// The generator-level guard retries a thin full-render AI response once
						// with a different model and throws when both attempts omit prose.
						// Re-verify HERE, after the preserve merge with the live schema snapshot:
						// if the article that would be rendered+published is STILL missing
						// expected prose zones (AI omitted them AND the live post holds no
						// recoverable copy), do NOT write a 3-zone page. Park the discovery with
						// a clear 'AI omitted sections' message; the live post is left exactly
						// as-is (this check runs before any wp_update_post). Manual Retry/Run-now
						// resets the breaker and re-arms.
						$_sh_tg_expected = $this->get_new_post_sections();
						$_sh_tg_expected = \SEO_Article_Generator\Generator\Article_Schema::normalize_sections( $_sh_tg_expected, array() );
						$_sh_tg_expected = array_values( array_filter( $_sh_tg_expected, static function ( $z ) {
							return is_string( $z ) && $z !== '' && $z !== 'all' && $z !== 'toc';
						} ) );
						if ( \SEO_Article_Generator\Generator\Article_Schema::is_simple_utility( $_sh_article['software_type'] ?? null ) ) {
							$_sh_tg_expected = array_values( array_diff( $_sh_tg_expected, array( 'faqs', 'moat' ) ) );
						}

						// video is non-critical; hero/download are rebuilt deterministically.
						// The thin-output policy concerns PROSE zones.
						$_sh_tg_prose   = array_values( array_diff( $_sh_tg_expected, array( 'hero', 'download', 'video', 'whats_new' ) ) );
						$_sh_tg_schema  = \SEO_Article_Generator\Generator\Article_Schema::from_array( $_sh_article );
						$_sh_tg_missing = array();
						foreach ( $_sh_tg_prose as $_sh_tg_zone ) {
							$_sh_tg_payload = $_sh_tg_schema->get_section_payload( $_sh_tg_zone );
							if ( empty( $_sh_tg_payload ) ) {
								$_sh_tg_missing[] = $_sh_tg_zone;
								continue;
							}
							// Non-empty-but-thin heuristic mirrors the generator sanity predicate
							// for key prose zones so a heading-only stub cannot pass the re-check.
							if ( $_sh_tg_zone === 'introduction' ) {
								$_sh_tg_intro = is_array( $_sh_tg_payload ) ? $_sh_tg_payload : array( $_sh_tg_payload );
								if ( strlen( trim( implode( ' ', array_filter( $_sh_tg_intro ) ) ) ) <= 20 ) {
									$_sh_tg_missing[] = $_sh_tg_zone;
								}
							} elseif ( $_sh_tg_zone === 'features' || $_sh_tg_zone === 'faqs' ) {
								if ( ! is_array( $_sh_tg_payload ) || count( $_sh_tg_payload ) < 2 ) {
									$_sh_tg_missing[] = $_sh_tg_zone;
								}
							}
						}

						if ( ! empty( $_sh_tg_missing ) ) {
							// POST LEFT UNTOUCHED: the render/write block below never runs.
							$_sh_tg_msg = 'full_render_ai_omitted_sections: AI omitted required prose sections ('
								. implode( ', ', array_values( array_unique( $_sh_tg_missing ) ) )
								. ') on sentinel-absent self-heal for post ' . $_sh_post_id
								. '; live post content could not supply them either. Post left unchanged; parked for manual review.';

							$this->logger->error(
								sprintf(
									'[AUDIT] Discovery %d Post %d: %s',
									(int) $item->id,
									$_sh_post_id,
									$_sh_tg_msg
								)
							);

							// Keep the full-rewrite routing flag for the next manual run (the post
							// still needs a full rebuild); do NOT alter content.
							\update_post_meta( $_sh_post_id, '_seo_gen_force_legacy_rewrite', '1' );

							// SSOT failure: status=failed; the 'full_render_ai_omitted_sections'
							// signature resolves to 'abort' in get_recovery_strategy() so no
							// auto-recovery resurrects it (parked in Failed tab; manual Run-now resets).
							$this->mark_discovery_failure( (int) $item->id, 'failed', $_sh_tg_msg );

							unset( $_sh_tg_expected, $_sh_tg_prose, $_sh_tg_schema, $_sh_tg_missing,
								$_sh_tg_zone, $_sh_tg_payload, $_sh_tg_intro, $_sh_tg_msg );
							return; // do NOT render, do NOT write — post content preserved
						}

						unset( $_sh_tg_expected, $_sh_tg_prose, $_sh_tg_schema, $_sh_tg_missing,
							$_sh_tg_zone, $_sh_tg_payload, $_sh_tg_intro );

						$_sh_rendered = '';
						if ( class_exists( '\\SEO_Article_Generator\\Generator\\Content_Formatter' ) ) {
							$_sh_formatter  = new \SEO_Article_Generator\Generator\Content_Formatter( $_sh_heading_map, true );
							// [THIN-RENDER FIX 2026-09-08] The preserve-merge above
							// restored ALL sections from the live schema snapshot into
							// $_sh_article.  Content_Formatter::to_html() applies a
							// regen_sections filter (added 2026-09-01) that restricts
							// rendering to only the zones in regen_sections — which for
							// partial updates is a small subset (e.g. tech_specs, download).
							// In this self-heal path we are doing a FULL re-render through
							// Content_Formatter, so ALL preserved sections must be emitted.
							// Strip regen_sections so the filter sees an empty array and
							// renders the complete section set from the merged article.
							$_sh_render_article = $_sh_article;
							unset( $_sh_render_article['regen_sections'] );
							$_sh_rendered   = (string) $_sh_formatter->to_html( $_sh_render_article, $_sh_post_id );
						}

						if ( $_sh_rendered !== '' && strpos( $_sh_rendered, '<!-- wp:seo-gen/section ' ) !== false ) {
							// Hand the rendered content to the SHARED update tail instead of
							// writing it here. Set the same variables the standard path uses so
							// the tail (finalize_generated_post -> shared finalization) runs unchanged.
							$post_content = $_sh_rendered;
							$post_id      = $_sh_post_id;
							$post_title   = ! empty( $_sh_article['title'] ) ? (string) $_sh_article['title'] : $item->software_name;

							// Deterministic internal links on the self-healed render
							// (this branch reassigns $post_content after the standard-path
							// injection, so apply them here too before the shared write).
							$post_content = $this->seo_gen_apply_internal_links( $post_content, $item, (int) $_sh_post_id );

							// Build hero meta (seogenherodata) the same way PPB would, so the
							// shared write_post_meta tail is fully satisfied.
							$meta_input = array();
							if ( class_exists( '\\SEO_Article_Generator\\Publishing\\Publish_Payload_Builder' ) ) {
								// [ISSUE-1 FIX] Enforce Version SSOT on self-heal article before building meta.
								// Self-heal bypasses PPB::build() where enforce_version_ssot() normally runs.
								\SEO_Article_Generator\Publishing\Version_SSOT::enforce( $_sh_article );
								$meta_input = \SEO_Article_Generator\Publishing\Publish_Payload_Builder::buildHeroMetaInput( $_sh_article, $_sh_post_id );
							}

							// Flag the post as full-rewrite so the done row + routing are correct.
							\update_post_meta( $_sh_post_id, '_seo_gen_content_contract', 'blocks-v1' );
							\delete_post_meta( $_sh_post_id, '_seo_gen_force_legacy_rewrite' );

							$this->logger->info(
								sprintf(
									'[AUDIT] Discovery %d Post %d: sentinel-absent self-heal rendered via Content_Formatter '
									. '(%d bytes); routing through standard finalization tail for image/purge/cleanup.',
									(int) $item->id,
									$_sh_post_id,
									strlen( $_sh_rendered )
								)
							);

							$sentinel_self_heal_ok = true;
						} else {
							$this->logger->warning(
								sprintf(
									'[AUDIT] Discovery %d Post %d: self-heal Content_Formatter::to_html() returned empty or no block sentinels. Falling back to re-queue loop.',
									(int) $item->id,
									$_sh_post_id
								)
							);
						}
						unset( $_sh_rendered, $_sh_article, $_sh_selected );
					}
				}

				if ( $sentinel_self_heal_ok ) {
					// SELF-HEAL USES THE SAME FINALIZATION TAIL AS THE STANDARD UPDATE PATH.
					// PPB cannot render plugin posts (html_content is empty by design), so we
					// rendered via Content_Formatter above. Now we run the IDENTICAL shared
					// tail the standard update path uses (~2844-3038): write_post_meta,
					// featured-image reparent, Cloudflare purge, replaced-attachment cleanup,
					// draft deletion, done row, cache invalidation. No stripped-down duplicate.

					// SCHEDULING CONTRACT: The sentinel-absent self-heal rewrites an
					// ALREADY-PUBLISHED plugin-owned post. It must honor the same update
					// stagger as the normal update path (get_next_update_slot_ts), otherwise
					// every sentinel-absent post is published the instant generation finishes
					// — bypassing seo_gen_update_delay_*, publish start/end window,
					// updates-per-day cap and active-days. When scheduling is disabled
					// get_next_update_slot_ts() returns 0, meaning "publish now".
					//
					// FIX: When $force=true (overdue recovery or check-job slot arrived),
					// skip slot calculation entirely. The caller already determined this
					// item's scheduled slot has passed — publish NOW, never re-defer.
					// Without this, get_next_update_slot_ts() returns a NEW future slot,
					// creating an infinite deferral loop where the post never publishes.
					$_slot_ts  = $force ? 0 : $this->get_next_update_slot_ts( (int) $item->id );
					$_now_ts   = Plugin_Time::now_utc_ts();
					$_deferred = ( $_slot_ts > 0 && $_slot_ts > $_now_ts + 5 );

					if ( $_deferred ) {
						$this->write_scheduled_at( (int) $item->id, $_slot_ts );
						$wpdb->update(
							$table,
							array(
								self::COL_STATUS        => 'generating',
								self::COL_ERROR_MESSAGE => null,
								self::COL_HEARTBEAT_AT  => null,
							),
							array( 'id' => (int) $item->id ),
							array( '%s', '%s', '%s' ),
							array( '%d' )
						);
						if ( ! AS_Registry::schedule_check_job( (int) $item->id, (int) $job_id, (int) $user_id, 1, $_slot_ts - $_now_ts ) ) {
							$this->logger->warning(
								sprintf(
									'[AUDIT] Discovery %d Post %d: self-heal deferred write failed to schedule check_job; falling back to immediate write.',
									(int) $item->id,
									$_sh_post_id
								)
							);
							$_deferred = false;
						} else {
							$this->invalidate_dashboard_caches();
							$this->logger->info(
								sprintf(
									'[AUDIT] Discovery %d Post %d: sentinel-absent self-heal DEFERRED to staggered slot %s UTC. Skipping immediate publish to honor update scheduling.',
									(int) $item->id,
									$_sh_post_id,
									Plugin_Time::utc_mysql_from_utc_ts( $_slot_ts )
								)
							);
							unset( $_sh_post_id, $_sh_existing, $_sh_article, $_sh_selected, $_sh_rendered, $_sh_heading_map, $_sh_formatter, $post_content, $post_id, $post_title, $meta_input, $thumbnail_set, $replaced_thumb_id, $draft_post_id, $pre_replace_thumb_id, $thumb_url, $herodata, $source_post_id, $existing_thumb_id, $resolved_version, $_cf_purge_urls, $_cf_perm, $_cf_home, $_cf_ppid, $_cf_plink, $_slot_ts, $_now_ts, $_deferred );
							return;
						}
					}

				if ( ! $_deferred ) {
				$final_id = (int) $_sh_post_id;

				// [SSOT-FIX 2.34.20] Derive post_excerpt from the same repaired meta_description
				// used for rank_math_description, so both surfaces match after write_post_meta().
				$_sh_excerpt = trim( (string) ( $_sh_article['meta_description'] ?? '' ) );
				if ( $_sh_excerpt === '' ) {
					$_sh_excerpt = trim( (string) ( $preview['article']['meta_description'] ?? '' ) );
				}
				if ( $_sh_excerpt === '' && ! empty( $meta_input ) && is_array( $meta_input ) ) {
					$_sh_excerpt = trim( (string) ( $meta_input['rank_math_description'] ?? '' ) );
				}

				\wp_update_post(
					array(
						'ID'           => $final_id,
						'post_content' => \wp_slash( $post_content ),
						'post_title'   => $post_title,
						'post_excerpt' => $_sh_excerpt,
					)
				);

					$this->write_post_meta( $final_id, $item, $job_id, $preview, $user_id, $meta_input );

					// FEATURED IMAGE RESOLUTION — mirror shared tail 2850-2875.
					$thumbnail_set        = false;
					$replaced_thumb_id    = 0;
					$draft_post_id        = ! empty( $item->draft_post_id ) ? (int) $item->draft_post_id : 0;
					$pre_replace_thumb_id = (int) \get_post_thumbnail_id( $final_id );
					if ( $draft_post_id > 0 ) {
						$draft_thumb_id = (int) \get_post_thumbnail_id( $draft_post_id );
						if ( $draft_thumb_id > 0 && \get_post( $draft_thumb_id ) ) {
							\set_post_thumbnail( $final_id, $draft_thumb_id );
							$thumbnail_set     = true;
							$replaced_thumb_id = $pre_replace_thumb_id;
							\wp_update_post(
								array(
									'ID'          => $draft_thumb_id,
									'post_parent' => $final_id,
								)
							);
							$this->logger->info( "Featured image: reused local attachment {$draft_thumb_id} from WP-Auto draft (reparented to post {$final_id})." );
							\SEO_Article_Generator\Discovery\Discovery_Engine::rename_attachment_to_software( $draft_thumb_id, (string) ( $item->software_name ?? '' ), $this->logger );
							\delete_post_thumbnail( $draft_post_id );
							$thumb_url = \wp_get_attachment_image_url( $draft_thumb_id, 'full' );
							if ( $thumb_url ) {
								$herodata = \get_post_meta( $final_id, 'seogenherodata', true );
								if ( is_array( $herodata ) && empty( $herodata['logo_url'] ) ) {
									$herodata['logo_url']           = $thumb_url;
									// [FIX 2026-07-25] Use canonical date formats matching Hero_Data_Provider::from_schema()
									// so Plugin::normalize_hero_data() does not produce a different ISO representation
									// when it round-trips last_updated through strtotime()/wp_date(). last_updated was
									// previously written as 'Y-m-d' while every other writer uses 'F j, Y' — causing
									// the hero meta box to render a different Last Updated label than the frontend
									// after each image-reparent.
									$herodata['last_updated']       = date( 'F j, Y' );
									$herodata['last_verified_date'] = gmdate( 'Y-m-d' );
									\SEO_Article_Generator\Plugin::get_instance()->write_hero_data( $final_id, $herodata );
								}
							}
						}
					}
					if ( ! $thumbnail_set ) {
						$source_post_id = (int) $final_id;
						$existing_thumb_id = (int) \get_post_thumbnail_id( $source_post_id );
						if ( $existing_thumb_id > 0 && \get_post( $existing_thumb_id ) ) {
							\set_post_thumbnail( $final_id, $existing_thumb_id );
							$thumbnail_set = true;
							$this->logger->info( "Featured image: inherited attachment {$existing_thumb_id} from source post." );
						}
					}

					// Resolve discovered_version for the done row (mirror 2929-2964).
					$resolved_version = '';
					if ( ! empty( $preview['article'] ) && is_array( $preview['article'] ) ) {
						$resolved_version = trim(
							(string) (
							$preview['article']['hero_section']['version'] ??
							$preview['article']['tech_specs']['version'] ?? ''
							)
						);
					}
					if ( $resolved_version === '' && $final_id > 0 ) {
						$resolved_version = SeoGen_Version_Resolver::current_version( $final_id );
					}

					$done_update = array(
						self::COL_STATUS           => 'done',
						self::COL_EXISTING_POST_ID => $final_id,
						'type'                     => Post_Type_Classifier::TYPE_LEGACY,
						self::COL_COMPLETED_AT     => Plugin_Time::utc_mysql_now(),
						// FIX F4: success resets the breaker.
						self::COL_CONSECUTIVE_FAILURES => 0,
						self::COL_LAST_FAILURE_AT     => null,
					);
					$done_formats = array( '%s', '%d', '%s', '%s', '%d', '%s' );
					if ( $resolved_version !== '' ) {
						$done_update['discovered_version'] = $resolved_version;
						$done_formats[]                    = '%s';
					}

					$wpdb->update(
						$table,
						$done_update,
						array( 'id' => (int) $item->id ),
						$done_formats,
						array( '%d' )
					);
					$this->invalidate_dashboard_caches();

					// CLOUDFLARE PURGE — mirror shared tail 2981-3003.
					if ( (int) $final_id > 0 ) {
						$_cf_purge_urls = array();
						$_cf_perm       = \get_permalink( (int) $final_id );
						if ( $_cf_perm ) {
							$_cf_purge_urls[] = $_cf_perm;
						}
						$_cf_home = \home_url( '/' );
						if ( $_cf_home && ! \in_array( $_cf_home, $_cf_purge_urls, true ) ) {
							$_cf_purge_urls[] = $_cf_home;
						}
						if ( \get_option( 'show_on_front' ) === 'page' ) {
							$_cf_ppid = (int) \get_option( 'page_for_posts' );
							if ( $_cf_ppid > 0 ) {
								$_cf_plink = \get_permalink( $_cf_ppid );
								if ( $_cf_plink && ! \in_array( $_cf_plink, $_cf_purge_urls, true ) ) {
									$_cf_purge_urls[] = $_cf_plink;
								}
							}
						}
						if ( ! empty( $_cf_purge_urls ) ) {
							\do_action( 'swcfpc_purge_cache', $_cf_purge_urls );
							$this->logger->info( 'Cloudflare page-cache purged (post + homepage): ' . implode( ', ', array_slice( $_cf_purge_urls, 0, 5 ) ) );
						}
					}

					$this->logger->info( 'Discovery ' . (int) $item->id . ': finalized and dashboard cache invalidated.' );

				// Replaced featured-image cleanup — mirror shared tail.
				// Guard: skip if $replaced_thumb_id is still the active thumbnail
				// (self-replacement scenario — the image is still live on the post).
				if ( $replaced_thumb_id > 0 ) {
					$current_active_thumb = (int) \get_post_thumbnail_id( $final_id );
					if ( $replaced_thumb_id !== $current_active_thumb ) {
						$still_used = (int) $wpdb->get_var(
							$wpdb->prepare(
								"SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = '_thumbnail_id' AND meta_value = %d",
								$replaced_thumb_id
							)
						);
						if ( $still_used <= 0 ) {
							\wp_delete_attachment( $replaced_thumb_id, true );
							$this->logger->info( "Featured image cleanup: deleted replaced attachment {$replaced_thumb_id} after successful finalization." );
						} else {
							$this->logger->info( "Featured image cleanup: skipped deletion of replaced attachment {$replaced_thumb_id}, still referenced by {$still_used} post(s)." );
						}
					}
				}

					// Re-schedule WP-Auto draft deletion after successful self-heal finalization.
					// Mirror shared tail 3031-3037.
					if (
						! empty( $item->source_type ) && $item->source_type === 'wp_automatic'
						&& (int) ( $item->draft_post_id ?? 0 ) > 0
						&& \get_post( (int) $item->draft_post_id )
					) {
						\SEO_Article_Generator\Discovery\Discovery_Engine::schedule_draft_deletion( (int) $item->draft_post_id );
					}

					AS_Registry::cancel_item_actions( (int) $item->id );
					\delete_transient( 'seo_gen_sentinel_retry_' . (int) $item->id );
					do_action( 'seo_gen_post_finalized', $final_id, $preview );
					return;
					}
				}

				// Clear the blocks-v1 content contract so the next run does not assume a patchable
				// block contract. Discovery's pre-generation zone gate will then decide whether
				// this post can be migrated or must be forced through the full-rewrite path.
				if ( ! empty( $item->existing_post_id ) ) {
					\delete_post_meta( (int) $item->existing_post_id, '_seo_gen_content_contract' );
					\update_post_meta( (int) $item->existing_post_id, '_seo_gen_force_legacy_rewrite', '1' );
				}
				// FIX F0 (Phase 3A): the "guard" referenced above does not exist —
				// mark_discovery_failure explicitly ALLOWS finalizing→failed. Route
				// through the SSOT so draft re-schedule, transient clear, breaker
				// count and logging all run on this path.
				$this->mark_discovery_failure(
					(int) $item->id,
					'failed',
					'no_sentinel_structure_requires_regen. Content contract cleared. Retry will be routed through discovery full-rewrite gating.'
				);
				return; // do NOT rollback — post content was not touched
			}

			// Audit Fix: Rollback new post draft if critical persistence fails
			if ( $created_new_post ) {
				if ( $final_id > 0 ) {
					$this->logger->warning( "Rolling back orphaned post #{$final_id} due to finalization error." );
					// Reparent the draft's featured image back to the draft before deleting the new post.
					// Without this, cleanup_orphaned_featured_image (before_delete_post hook) would
					// delete the attachment that rightfully belongs to the draft.
					if ( $draft_post_id > 0 ) {
						$rollback_thumb_id = (int) \get_post_thumbnail_id( $final_id );
						if ( $rollback_thumb_id > 0 ) {
							$rollback_att = \get_post( $rollback_thumb_id );
							if ( $rollback_att && (int) $rollback_att->post_parent === (int) $final_id ) {
								\wp_update_post(
									array(
										'ID'          => $rollback_thumb_id,
										'post_parent' => $draft_post_id,
									)
								);
								\set_post_thumbnail( $draft_post_id, $rollback_thumb_id );
								$this->logger->info( "Rollback: reparented attachment {$rollback_thumb_id} back to draft {$draft_post_id} before new-post deletion." );
							}
						}
					}
					\wp_delete_post( $final_id, true );
				}
				$wpdb->update(
					$table,
					array( self::COL_EXISTING_POST_ID => 0 ),
					array( 'id' => (int) $item->id ),
					array( '%d' ),
					array( '%d' )
				);
						$final_id = 0;
				if (
					! empty( $item->source_type ) && $item->source_type === 'wp_automatic'
					&& (int) ( $item->draft_post_id ?? 0 ) > 0
					&& \get_post( (int) $item->draft_post_id )
				) {
					\SEO_Article_Generator\Discovery\Discovery_Engine::schedule_draft_deletion( (int) $item->draft_post_id );
				}
			}

			// Audit Fix: Rollback existing post content if critical persistence fails
			if ( $updated_post && $final_id > 0 && ! empty( $original_snapshot ) ) {
				$this->logger->warning( "Rolling back post #{$final_id} content due to finalization failure." );
				\wp_update_post(
					array(
						'ID'           => $final_id,
						'post_content' => \wp_slash( $original_snapshot['post_content'] ),
						'post_title'   => \wp_slash( $original_snapshot['post_title'] ),
					)
				);
				\wp_set_post_categories( $final_id, $original_snapshot['categories'] );
				\wp_set_post_tags( $final_id, $original_snapshot['tags'], false );
				foreach ( $original_snapshot['meta'] as $k => $v ) {
					if ( $v === '' ) {
						\delete_post_meta( $final_id, $k );
					} else {
						\update_post_meta( $final_id, $k, $v );
					}
				}
				if ( ! empty( $original_snapshot['schema'] ) ) {
					try {
						\SEO_Article_Generator\Services\Schema_Sync_Service::save_schema( $final_id, $original_snapshot['schema'] );
					} catch ( \Throwable $schema_rollback_error ) {
						$this->logger->error(
							"Schema rollback failed for Post {$final_id}: " . $schema_rollback_error->getMessage()
						);
					}
				}
				// Restore the original featured image that was replaced by the draft's image.
				// The draft's attachment was reparented to $final_id during featured image resolution;
				// reparent it back to the draft and restore the draft's _thumbnail_id.
				$original_thumb_id = ! empty( $original_snapshot['thumbnail_id'] ) ? (int) $original_snapshot['thumbnail_id'] : 0;
				if ( $draft_post_id > 0 ) {
					$current_thumb_id = (int) \get_post_thumbnail_id( $final_id );
					if ( $current_thumb_id > 0 ) {
						$current_att = \get_post( $current_thumb_id );
						if ( $current_att && (int) $current_att->post_parent === (int) $final_id ) {
							\wp_update_post(
								array(
									'ID'          => $current_thumb_id,
									'post_parent' => $draft_post_id,
								)
							);
							\set_post_thumbnail( $draft_post_id, $current_thumb_id );
							$this->logger->info( "Rollback: reparented draft attachment {$current_thumb_id} back to draft {$draft_post_id}." );
						}
					}
				}
				if ( $original_thumb_id > 0 ) {
					\set_post_thumbnail( $final_id, $original_thumb_id );
					$this->logger->info( "Rollback: restored original featured image {$original_thumb_id} on post {$final_id}." );
				} else {
					\delete_post_thumbnail( $final_id );
					$this->logger->info( "Rollback: removed featured image from post {$final_id} (original had none)." );
				}
			}

			// CRITICAL FIX: Re-schedule draft deletion after finalization failure on
			// ANY path (not just $created_new_post). Without this, WP-Auto drafts whose
			// deletion was cancelled in process_item_background() at line 1056 are never
			// re-scheduled if the update path fails before hitting the success block at
			// line 2580. The draft pile-up grows unbounded.
			if (
				! empty( $item->source_type ) && $item->source_type === 'wp_automatic'
				&& (int) ( $item->draft_post_id ?? 0 ) > 0
				&& \get_post( (int) $item->draft_post_id )
			) {
				try {
					\SEO_Article_Generator\Discovery\Discovery_Engine::schedule_draft_deletion( (int) $item->draft_post_id );
					$this->logger->info(
						sprintf(
							'Discovery %d: emergency draft deletion re-scheduled for draft %d after finalization failure.',
							(int) $item->id,
							(int) $item->draft_post_id
						)
					);
				} catch ( \Exception $e ) {
					$this->logger->error(
						sprintf(
							'Discovery %d: FAILED to re-schedule draft deletion for draft %d after finalization failure: %s',
							(int) $item->id,
							(int) $item->draft_post_id,
							$e->getMessage()
						)
					);
				}
			}

			// Update seo_gen_processed_status on the source draft so the WP admin
			// shows the actual lifecycle state instead of stale 'staged'.
			if ( ! empty( $item->draft_post_id ) && (int) $item->draft_post_id > 0 && \get_post( (int) $item->draft_post_id ) ) {
				\update_post_meta( (int) $item->draft_post_id, 'seo_gen_processed_status', 'failed' );
			}

			$this->logger->error(
				"Finalization FAILED for Discovery #{$item->id}: " . $e->getMessage(),
				array(
					'job_id'  => $job_id,
					'post_id' => $post_id ?? 0,
					'trace'   => $e->getTraceAsString(),
				)
			);
			$this->mark_discovery_failure( $item->id, 'failed', $e->getMessage() );
		}
	}
	/**
	 * FIX B2 (2026-09-06): locate the discovery owner of an orphaned completed job.
	 *
	 * Primary: jobs.input_data['discovery_id'] stamped at spawn (precise).
	 * Secondary (legacy backlog jobs without the stamp): existing_post_id + staged
	 * version match, so a sibling discovery tracking a different version is never
	 * adopted onto.
	 *
	 * Safety: never adopts onto a row owned by a live job (the orphan is then
	 * redundant — the live job will deliver). Callers must only pass completions.
	 *
	 * @return object|null Discovery row with backfilled job identity, or null.
	 */
	private function adopt_orphan_completion( $job_id ) {
		global $wpdb;

		$job_id = (int) $job_id;
		if ( $job_id <= 0 ) {
			return null;
		}

		$jobs_table = Installer::table_jobs();
		$job_row    = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT input_data, queue_job_id FROM {$jobs_table} WHERE id = %d",
				$job_id
			),
			ARRAY_A
		);
		if ( ! $job_row || empty( $job_row['input_data'] ) ) {
			return null;
		}

		$input = json_decode( (string) $job_row['input_data'], true );
		if ( ! is_array( $input ) ) {
			return null;
		}

		$table     = Installer::table_discovery();
		$candidate = null;

		$owner_id = (int) ( $input['discovery_id'] ?? 0 );
		if ( $owner_id > 0 ) {
			$candidate = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT id, status, job_id, queue_job_id, error_message, source_type, draft_post_id
					 FROM {$table}
					 WHERE id = %d
					   AND status IN ( 'queued', 'processing', 'generating', 'finalizing', 'deferred' )
					 LIMIT 1",
					$owner_id
				)
			);
		}

		if ( ! $candidate ) {
			$legacy_post = (int) ( $input['existing_post_id'] ?? ( $input['existingpostid'] ?? 0 ) );
			$legacy_ver  = trim( (string) ( $input['version'] ?? '' ) );
			if ( $legacy_post > 0 && $legacy_ver !== '' ) {
				$candidate = $wpdb->get_row(
					$wpdb->prepare(
						"SELECT id, status, job_id, queue_job_id, error_message, source_type, draft_post_id
						 FROM {$table}
						 WHERE existing_post_id = %d
						   AND discovered_version = %s
						   AND status IN ( 'queued', 'processing', 'generating', 'finalizing', 'deferred' )
						 ORDER BY id DESC LIMIT 1",
						$legacy_post,
						$legacy_ver
					)
				);
			}
		}

		if ( ! $candidate ) {
			return null;
		}

		$current_job_id = (int) ( $candidate->job_id ?? 0 );
		if ( $current_job_id > 0 && $current_job_id !== $job_id ) {
			$current_life = $this->job_handler->get_job_lifecycle_status( $current_job_id );
			// PHASE 3F (2.34.0): a genuinely LIVE owner (running or healthy-queued
			// per the time-aware liveness check) still wins and this late
			// completion is dropped. But a ZOMBIE owner (stale_dead — stuck non-
			// terminal with no heartbeat past the threshold, the 09-06 job-7260
			// case) must NOT swallow a real, newer completion. Previously the
			// age-less should_continue read "live" forever, so ~193 finished
			// duplicate jobs were dropped while their AI spend was already burnt.
			// Now: only drop when the owner is truly live; otherwise fall through
			// and ADOPT this completion (the salvage path below).
			$owner_truly_live = ! empty( $current_life['should_continue'] );
			if ( $owner_truly_live ) {
				$this->logger->info(
					'handle_job_finished: orphan completion for job ' . $job_id .
					' dropped — discovery ' . (int) $candidate->id . ' owns live job ' . $current_job_id . '.'
				);
				return null;
			}
			$this->logger->warning(
				'handle_job_finished: owner job ' . $current_job_id .
				' is not live (state=' . (string) ( $current_life['combined_status'] ?? 'unknown' ) .
				'); adopting newer completion job ' . $job_id .
				' for discovery ' . (int) $candidate->id . ' instead of dropping it.'
			);
		}

		$wpdb->update(
			$table,
			array(
				'job_id'        => $job_id,
				'queue_job_id'  => (int) ( $job_row['queue_job_id'] ?? 0 ),
				'error_message' => null,
			),
			array( 'id' => (int) $candidate->id ),
			array( '%d', '%d', '%s' ),
			array( '%d' )
		);

		$this->logger->info(
			'handle_job_finished: adopted orphan completion job ' . $job_id .
			' onto discovery ' . (int) $candidate->id . ' (previous job ' . $current_job_id . ').'
		);

		return $this->get_item( (int) $candidate->id );
	}

	public function handle_job_finished( int $job_id, string $status, int $user_id = 0 ) {
		if ( $this->is_pipeline_paused() ) {
			return;
		}

		global $wpdb;

		$item = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT id, status, job_id, queue_job_id, error_message, source_type, draft_post_id
				 FROM ' . Installer::table_discovery() . '
				 WHERE job_id = %d
				 LIMIT 1',
				$job_id
			)
		);

		if ( ! $item ) {
			$queue_job_id = (int) $wpdb->get_var(
				$wpdb->prepare(
					'SELECT queue_job_id FROM ' . Installer::table_jobs() . ' WHERE id = %d',
					$job_id
				)
			);

			$this->logger->info(
				'handle_job_finished: job_id=' . $job_id . ', fallback queue_job_id from jobs table: ' . $queue_job_id
			);

			if ( $queue_job_id > 0 ) {
				$item = $wpdb->get_row(
					$wpdb->prepare(
						'SELECT id, status, job_id, queue_job_id, error_message, source_type, draft_post_id
						 FROM ' . Installer::table_discovery() . '
						 WHERE queue_job_id = %d
						 LIMIT 1',
						$queue_job_id
					)
				);

				$this->logger->info(
					'handle_job_finished: Fallback query found item: ' . ( $item ? ( 'id=' . $item->id . ', status=' . $item->status ) : 'none' )
				);

				if ( $item && in_array( (string) $item->status, array( 'generating', 'deferred' ), true ) ) {
					$wpdb->update(
						Installer::table_discovery(),
						array(
							'job_id'        => $job_id,
							'status'        => 'generating',
							'error_message' => null,
						),
						array( 'id' => (int) $item->id ),
						array( '%d', '%s', '%s' ),
						array( '%d' )
					);

					$item = $this->get_item( (int) $item->id );
					$this->logger->info(
						'handle_job_finished: Backfilled job_id=' . $job_id . ' for discovery ' . (int) $item->id . ' via queue_job_id fallback.'
					);
				}
			}
		}

		// FIX B2 (2026-09-06): orphan-completion adoption. Replaces dead Fix B
		// (which re-queried the discovery table with the same failed predicate).
		// Adopts COMPLETED jobs only, and only onto rows with no live job —
		// a stale failure must never kill a row whose current job is healthy.
		if ( ! $item && $status === 'completed' ) {
			$item = $this->adopt_orphan_completion( (int) $job_id );
		}

		if ( ! $item ) {
			$this->logger->warning(
				'handle_job_finished: No identity-matched item found.',
				array(
					'job_id' => (int) $job_id,
					'status' => (string) $status,
				)
			);
			return;
		}

		// HARD-STOP: Ignore completions for manually killed rows so async callbacks cannot resurrect them.
		if ( $item && ! empty( $item->error_message ) && $item->error_message === 'Killed manually by user.' ) {
			$this->logger->warning(
				'handle_job_finished ignored for manually killed discovery ' . (int) $item->id . ' job ' . (int) $job_id . '.'
			);
			return;
		}

		$allow_failed_recovery = in_array( (string) $item->status, array( 'failed', 'timeout' ), true );
		$claimed               = $this->claim_item_for_finalization( (int) $item->id, (int) $job_id, $allow_failed_recovery );

		if ( ! $claimed ) {
			$current_status = (string) $wpdb->get_var(
				$wpdb->prepare(
					'SELECT status FROM ' . Installer::table_discovery() . ' WHERE id = %d',
					(int) $item->id
				)
			);
			$this->logger->error(
				'Discovery ' . (int) $item->id . ' claim FAILED in handle_job_finished for job ' . (int) $job_id . '. Current status=' . $current_status . '.'
			);
			return;
		}

		$this->logger->info(
			'handle_job_finished: Processing job ' . (int) $job_id . ' with status ' . $status .
			' for discovery ' . (int) $claimed->id . ' current status ' . $claimed->status
		);

		if ( $status === 'completed' ) {
			$this->auto_finalize( $claimed, $job_id, $user_id, false );

			$post_status = (string) $wpdb->get_var(
				$wpdb->prepare(
					'SELECT status FROM ' . Installer::table_discovery() . ' WHERE id = %d',
					(int) $claimed->id
				)
			);
			if ( $post_status === 'failed' ) {
				$failure_reason = (string) $wpdb->get_var(
					$wpdb->prepare(
						'SELECT error_message FROM ' . Installer::table_discovery() . ' WHERE id = %d',
						(int) $claimed->id
					)
				);
				$recovery_strategy = self::get_recovery_strategy( $failure_reason );
				if ( $recovery_strategy === 'immediate_dismiss' ) {
					$this->logger->info( sprintf(
						'[AUDIT] Discovery %d auto_finalize resulted in immediate dismiss. Reason: %s',
						(int) $claimed->id,
						$failure_reason
					) );
					$this->dismiss_and_cleanup_source( (int) $claimed->id );
				} elseif ( $recovery_strategy === 'discovery' ) {
					$_sentinel_retry_key  = 'seo_gen_sentinel_retry_' . (int) $claimed->id;
					$_is_sentinel_failure = strpos( strtolower( $failure_reason ), 'no_sentinel_structure' ) !== false;

					if ( $_is_sentinel_failure ) {
						$_sentinel_retry_count = (int) \get_transient( $_sentinel_retry_key );
						if ( $_sentinel_retry_count >= 2 ) {
							$this->logger->warning( sprintf(
								'[AUDIT] Discovery %d sentinel retry exhausted (%d/2). Dismissing + deleting. Reason: %s',
								(int) $claimed->id,
								$_sentinel_retry_count,
								$failure_reason
							) );
							\delete_transient( $_sentinel_retry_key );
							$this->dismiss_and_cleanup_source( (int) $claimed->id );
							return;
						}
						\set_transient( $_sentinel_retry_key, $_sentinel_retry_count + 1, 86400 );
					}

					$this->logger->info( sprintf(
						'Discovery %d auto_finalize resulted in failure (strategy: %s). Triggering recovery. Reason: %s',
						(int) $claimed->id,
						$recovery_strategy,
						$failure_reason
					) );
					$this->smart_recover_item( (int) $claimed->id, $user_id, 30 );
				} else {
					$this->logger->warning( sprintf(
						'Discovery %d auto_finalize failed — leaving in Failed tab. Reason: %s',
						(int) $claimed->id,
						$failure_reason
					) );
				}
			} else {
				\delete_transient( 'seo_gen_sentinel_retry_' . (int) $claimed->id );
			}
			return;
		}

		// ── DETERMINISTIC FAILURES (failed_validation): exactly 1 retry, then dismiss + delete.
		// These are terminal at job level (class-job-handler.php sets STATUS_FAILED_VALIDATION)
		// and should NOT enter the normal 3-retry auto-recovery loop.
		if ( $status === \SEO_Article_Generator\Jobs\Job_Handler::STATUS_FAILED_VALIDATION ) {
			$life           = $this->job_handler->get_job_lifecycle_status( (int) $job_id );
			$failure_reason = (string) ( $life['failure_reason'] ?? ( 'Deterministic generation failure: ' . $status ) );

			$this->mark_discovery_failure(
				(int) $claimed->id,
				'failed',
				$failure_reason
			);

			$recovery_strategy = self::get_recovery_strategy( $failure_reason );

			if ( $recovery_strategy === 'immediate_dismiss' ) {
				$this->logger->info( sprintf(
					'[AUDIT] Discovery %d immediate dismiss (deterministic): %s',
					(int) $claimed->id,
					$failure_reason
				) );
				$this->dismiss_and_cleanup_source( (int) $claimed->id );
				return;
			}

			// Deterministic: exactly 1 retry, then dismiss + delete.
			$det_transient_key = 'seo_gen_det_retry_' . $claimed->id;
			$det_retry_count   = (int) \get_transient( $det_transient_key );
			if ( $det_retry_count < 1 ) {
				\set_transient( $det_transient_key, $det_retry_count + 1, 86400 );
				$this->logger->info( sprintf(
					'[AUDIT] Discovery %d deterministic retry (%d/1): %s',
					(int) $claimed->id,
					$det_retry_count + 1,
					$failure_reason
				) );
				$this->smart_recover_item( (int) $claimed->id, $user_id, 30 );
			} else {
				$this->logger->warning( sprintf(
					'[AUDIT] Discovery %d deterministic retry exhausted. Dismissing + deleting. Reason: %s',
					(int) $claimed->id,
					$failure_reason
				) );
				$this->dismiss_and_cleanup_source( (int) $claimed->id );
			}
			return;
		}

		if ( in_array( $status, array( 'failed', 'timed_out', 'reconcile_failed' ), true ) ) {
			if ( $status === 'reconcile_failed' ) {
				$this->recover_from_reconcile_failed_snapshot( (int) $claimed->id, (int) $job_id, $user_id ?: 1, 'handle_job_finished' );
				return;
			}

			$life           = $this->job_handler->get_job_lifecycle_status( (int) $job_id );
			$failure_reason = (string) ( $life['failure_reason'] ?? ( 'AI job finished with status ' . $status ) );

			if (
			class_exists( '\\SEO_Article_Generator\\AI\\AI_Client' ) &&
			method_exists( '\\SEO_Article_Generator\\AI\\AI_Client', 'is_daily_quota_error' ) &&
			\SEO_Article_Generator\AI\AI_Client::is_daily_quota_error( $failure_reason )
			) {
				$gate         = $this->get_generation_gate();
				$retry_after  = (int) ( $gate['retry_after'] ?? 0 );
				$api_reset_ts = ( $retry_after > 60 ) ? ( Plugin_Time::now_utc_ts() + $retry_after ) : 0;
				\SEO_Article_Generator\AI\AI_Client::set_daily_quota_block( $failure_reason, $api_reset_ts );
			}

			$this->mark_discovery_failure(
				(int) $claimed->id,
				in_array( $status, array( 'timed_out', 'timeout' ), true ) ? 'timeout' : 'failed',
				$failure_reason
			);

			// SSOT Auto-Recovery
			$recovery_strategy = self::get_recovery_strategy( $failure_reason );

			if ( $recovery_strategy === 'immediate_dismiss' ) {
				$this->logger->info( sprintf(
					'[AUDIT] Discovery %d immediate dismiss: %s',
					(int) $claimed->id,
					$failure_reason
				) );
				$this->dismiss_and_cleanup_source( (int) $claimed->id );
				return;
			}

			if ( $recovery_strategy === 'deterministic' ) {
				$det_transient_key = 'seo_gen_det_retry_' . $claimed->id;
				$det_retry_count   = (int) \get_transient( $det_transient_key );
				if ( $det_retry_count < 1 ) {
					\set_transient( $det_transient_key, $det_retry_count + 1, 86400 );
					$this->logger->info( sprintf(
						'[AUDIT] Discovery %d deterministic retry (%d/1): %s',
						(int) $claimed->id,
						$det_retry_count + 1,
						$failure_reason
					) );
					$this->smart_recover_item( (int) $claimed->id, $user_id, 30 );
				} else {
					$this->logger->warning( sprintf(
						'[AUDIT] Discovery %d deterministic retry exhausted. Dismissing + deleting. Reason: %s',
						(int) $claimed->id,
						$failure_reason
					) );
					$this->dismiss_and_cleanup_source( (int) $claimed->id );
				}
				return;
			}

			if ( $recovery_strategy !== 'abort' ) {
				$transient_key = 'seo_gen_recovery_count_' . $claimed->id;
				$recovery_count = (int) \get_transient( $transient_key );
				if ( $recovery_count < 3 ) {
					\set_transient( $transient_key, $recovery_count + 1, 86400 );
					$this->logger->info( 'Discovery ' . $claimed->id . ' auto-recovery triggered (' . ($recovery_count + 1) . '/3) for strategy: ' . $recovery_strategy );
					$this->smart_recover_item( (int) $claimed->id, $user_id, 30 );
				} else {
					$this->logger->warning( 'Discovery ' . $claimed->id . ' reached max auto-recovery limit (3). Abandoning in Failed tab.' );
				}
			}
		}
	}

	public function write_post_meta( $post_id, $item, $job_id, $preview, $user_id = 0, array $meta_input = array() ) {
		$this->assign_taxonomies( $post_id, $preview, $item );

		$is_update = ! empty( $item->existing_post_id )
			&& (int) $post_id === (int) $item->existing_post_id;

		// ── RANK MATH SEO META (runs for both new and update posts) ──
		$article = ( ! empty( $preview['article'] ) && is_array( $preview['article'] ) )
			? $preview['article']
			: array();

		$focus_keyword    = trim( (string) ( $article['focus_keyword'] ?? $article['focuskeyword'] ?? '' ) );
		$meta_description = trim( (string) ( $article['meta_description'] ?? $article['metadescription'] ?? '' ) );

		// Fallback to meta_input only when article contract is empty — never override it.
		if ( $focus_keyword === '' && ! empty( $meta_input ) && is_array( $meta_input ) ) {
			$focus_keyword = trim( (string) ( $meta_input['rank_math_focus_keyword'] ?? '' ) );
		}
		if ( $meta_description === '' && ! empty( $meta_input ) && is_array( $meta_input ) ) {
			$meta_description = trim( (string) ( $meta_input['rank_math_description'] ?? '' ) );
		}

		// ── SSOT META DESCRIPTION ──
		// F14 (Phase 3C, 2.32.26): clarified a garbled legacy comment. Keep the
		// AI's natural wording; force the version + size to match the canonical
		// tech_specs (hero/body source of truth). Falls back to the rigid
		// template only when the AI meta is empty.
		$_repaired = \SEO_Article_Generator\Generator\Hero_Data_Provider::repair_meta_to_spec( $meta_description, $article );
		if ( $_repaired !== '' ) {
			$meta_description            = $_repaired;
			$article['meta_description'] = $_repaired;
			// [SSOT-FIX] Propagate repaired meta_description into $preview so that
			// Schema_Sync_Service::save_schema() persists the corrected value to the
			// DB snapshot instead of the stale one from merged_clone. (F14: line
			// number reference removed — it drifted across releases.)
			$preview['article']['meta_description'] = $_repaired;
		}

		// ── WHAT'S NEW cumulative history (mod: whats_new accordion) ──
		// AI returns only the newest version's bullets (flat). Persist a
		// version-stamped history so updates accumulate: newest stays the
		// visible "What's New" block; older entries render in an accordion (max 5).
		if ( ! empty( $article['whats_new'] ) && is_array( $article['whats_new'] ) ) {
			$_wn = array_values( array_filter( array_map( 'strval', $article['whats_new'] ) ) );
			if ( ! empty( $_wn ) ) {
				$_ver  = isset( $article['tech_specs']['version'] ) ? trim( (string) $article['tech_specs']['version'] ) : '';
				$_date = function_exists( '\\wp_date' ) ? \wp_date( 'Y-m-d' ) : date( 'Y-m-d' );
				$_hist = $post_id > 0
					? (array) \get_post_meta( $post_id, '_seo_gen_whats_new_history', true )
					: array();
				if ( ! is_array( $_hist ) ) {
					$_hist = array();
				}

				// [ROBUST FIX] Normalize legacy/accumulated history entries into the
				// canonical {version,date,bullets} shape on read. Older or malformed
				// meta (flat string lists, 'whats_new'/'items' aliases, missing
				// 'bullets') would otherwise render a blank accordion. This migrates
				// stored meta in place on the next write below.
				foreach ( $_hist as &$_h ) {
					if ( is_string( $_h ) && $_h !== '' ) {
						$_h = array( 'version' => '', 'date' => '', 'bullets' => array( $_h ) );
						continue;
					}
					if ( ! is_array( $_h ) ) {
						$_h = array( 'version' => '', 'date' => '', 'bullets' => array() );
						continue;
					}
					$_hv = isset( $_h['version'] ) ? trim( (string) $_h['version'] ) : '';
					$_hd = isset( $_h['date'] ) ? trim( (string) $_h['date'] ) : '';
					$_hb = null;
					foreach ( array( 'bullets', 'whats_new', 'items' ) as $_hk ) {
						if ( isset( $_h[ $_hk ] ) && is_array( $_h[ $_hk ] ) ) {
							$_hb = $_h[ $_hk ];
							break;
						}
					}
					$_hstruct = isset( $_h['version'] ) || isset( $_h['date'] )
						|| isset( $_h['bullets'] ) || isset( $_h['whats_new'] ) || isset( $_h['items'] );
					if ( null === $_hb && ! $_hstruct ) {
						$_hb = $_h; // flat list of bullet strings
					}
					$_hbb = array();
					if ( is_array( $_hb ) ) {
						foreach ( $_hb as $_x ) {
							$_x = is_scalar( $_x ) ? trim( (string) $_x ) : '';
							if ( $_x !== '' ) {
								$_hbb[] = $_x;
							}
						}
					}
					$_h = array( 'version' => $_hv, 'date' => $_hd, 'bullets' => $_hbb );
				}
				unset( $_h );

				if ( ! empty( $_hist ) && isset( $_hist[0]['version'] ) && (string) $_hist[0]['version'] === $_ver && $_ver !== '' ) {
					$_hist[0]['bullets'] = $_wn;
					$_hist[0]['date']    = $_date;
				} else {
					array_unshift( $_hist, array(
						'version' => $_ver,
						'date'    => $_date,
						'bullets' => $_wn,
					) );
				}
				if ( count( $_hist ) > 6 ) {
					$_hist = array_slice( $_hist, 0, 6 );
				}
				$article['whats_new_history'] = $_hist;
				if ( $post_id > 0 ) {
					\update_post_meta( $post_id, '_seo_gen_whats_new_history', $_hist );
				}
			}
		}

		if ( $post_id > 0 ) {
			if ( class_exists( '\\SEO_Article_Generator\\Generator\\Response_Normalizer' ) ) {
				$focus_keyword    = \SEO_Article_Generator\Generator\Response_Normalizer::strip_markdown( $focus_keyword );
				$meta_description = \SEO_Article_Generator\Generator\Response_Normalizer::strip_markdown( $meta_description );
			}

			if ( $focus_keyword !== '' ) {
				\update_post_meta( $post_id, 'rank_math_focus_keyword', \sanitize_text_field( $focus_keyword ) );
			} elseif ( ! $is_update ) {
				\delete_post_meta( $post_id, 'rank_math_focus_keyword' );
			}

			// [META-PRESERVE] Plugin-owned posts that already carry a meta
			// description must NOT have rank_math_description overwritten by
			// regeneration / self-heal paths. Only backfill when empty.
			$existing_md          = trim( (string) \get_post_meta( $post_id, 'rank_math_description', true ) );
			$is_plugin_owned_post = \SEO_Article_Generator\Discovery\Post_Type_Classifier::is_plugin_owned(
				\SEO_Article_Generator\Discovery\Post_Type_Classifier::classify( $post_id )
			);
			$preserve_existing_md = $is_update && $is_plugin_owned_post && $existing_md !== '';

			if ( $preserve_existing_md ) {
				$_sanitized_existing = \SEO_Article_Generator\Generator\Hero_Data_Provider::repair_meta_to_spec( $existing_md, $article );
				if ( $_sanitized_existing !== $existing_md && $_sanitized_existing !== '' ) {
					\update_post_meta( $post_id, 'rank_math_description', \sanitize_textarea_field( $_sanitized_existing ) );
					$meta_description = $_sanitized_existing;
					$preserve_existing_md = false;
				}
			}

			if ( $meta_description !== '' && ! $preserve_existing_md ) {
				\update_post_meta( $post_id, 'rank_math_description', \sanitize_textarea_field( $meta_description ) );
			} elseif ( $meta_description === '' && ! $is_update ) {
				\delete_post_meta( $post_id, 'rank_math_description' );
			}

			$this->logger->info(
				'Rank Math SEO meta written in write_post_meta.',
				array(
					'post_id'                  => (int) $post_id,
					'job_id'                   => (int) $job_id,
					'focus_keyword_present'       => ( $focus_keyword !== '' ),
					'meta_description_present'    => ( $meta_description !== '' ),
					'meta_description_preserved'  => ( $preserve_existing_md ),
					'focus_keyword_source'        => ( $focus_keyword !== '' )
						? ( trim( (string) ( $article['focus_keyword'] ?? $article['focuskeyword'] ?? '' ) ) !== ''
							? 'articlecontract'
							: 'metainput_fallback' )
						: 'none_will_delete_stale',
					'meta_description_source'     => ( $meta_description !== '' )
						? ( $preserve_existing_md
							? 'preserved_existing'
							: ( trim( (string) ( $article['meta_description'] ?? $article['metadescription'] ?? '' ) ) !== ''
								? 'articlecontract'
								: 'metainput_fallback' ) )
					: 'none_will_delete_stale',
			)
		);
	}

	// ── POST_EXCERPT RECONCILIATION (SSOT-FIX 2.34.20) ──
	// rank_math_description is the canonical SSOT for the visible description.
	// post_excerpt (used by themes via the_excerpt()) must match it exactly.
	// This reconciles ALL divergence vectors: intro-slice fallback, self-heal path,
	// new-post raw AI value, and any future derivation path that writes post_excerpt
	// before write_post_meta() runs.
	if ( $post_id > 0 && $meta_description !== '' ) {
		$current_excerpt = trim( (string) \get_post_field( 'post_excerpt', $post_id, 'raw' ) );
		if ( $current_excerpt !== $meta_description ) {
			\wp_update_post( array(
				'ID'           => $post_id,
				'post_excerpt' => $meta_description,
			) );
			$this->logger->info(
				'Post excerpt reconciled to rank_math_description.',
				array(
					'post_id'     => (int) $post_id,
					'old_excerpt' => mb_substr( $current_excerpt, 0, 120 ),
					'new_excerpt' => mb_substr( $meta_description, 0, 120 ),
				)
			);
		}
	}
	// ── END POST_EXCERPT RECONCILIATION ──

	// ── END RANK MATH META ──

	// [ARCHITECTURAL-FIX] Finding 2B: Force-save meta_input from publish payload
		// @MODIFIED 2026-04-03: Guard against array-typed JSON meta (PHP 8 compatibility)
		// [SSOT-FIX Finding 14] Skip seogenherodata here — Schema_Sync_Service::save_schema()
		// is the canonical owner of seogenherodata and rebuilds it from the schema in
		// finalize_generated_post(). Writing here first would be overwritten by save_schema's
		// Hero_Data_Provider::from_schema() pass anyway, producing a redundant DB write.
		if ( ! empty( $meta_input ) ) {
			static $json_typed_meta_keys = array(
				'_seo_gen_regen_sections',
				'_seo_gen_article_snapshot',
			);

			foreach ( $meta_input as $meta_key => $meta_value ) {
				if ( $meta_key === 'post_author' ) {
					continue; // Native field, not meta
				}

				// [SSOT-FIX Finding 14] Schema_Sync_Service owns seogenherodata; skip here.
				if ( $meta_key === 'seogenherodata' ) {
					continue;
				}

				if ( in_array( $meta_key, $json_typed_meta_keys, true ) && is_array( $meta_value ) ) {
					$meta_value = \wp_json_encode( $meta_value );
				}

				update_post_meta( $post_id, $meta_key, $meta_value );
			}
		}

		$heading_map = array();
		if ( ! empty( $preview['article'] ) && is_array( $preview['article'] ) ) {
			$raw_heading_map = array();

			if ( ! empty( $preview['article']['_seo_gen_heading_map'] ) && is_array( $preview['article']['_seo_gen_heading_map'] ) ) {
				$raw_heading_map = $preview['article']['_seo_gen_heading_map'];
			} elseif ( ! empty( $preview['article']['seogenheadingmap'] ) && is_array( $preview['article']['seogenheadingmap'] ) ) {
				$raw_heading_map = $preview['article']['seogenheadingmap'];
			}

			foreach ( $raw_heading_map as $map_key => $map_value ) {
				if ( ! is_string( $map_key ) || ! is_string( $map_value ) ) {
					continue;
				}

				$map_key   = trim( $map_key );
				$map_value = trim( $map_value );

				if ( $map_key === '' || $map_value === '' ) {
					continue;
				}

				$canonical_key = \SEO_Article_Generator\Generator\Article_Schema::get_canonical_key( $map_key );
				if ( ! $canonical_key ) {
					continue;
				}

				$heading_map[ $canonical_key ] = $map_value;
			}
		}

		if ( ! empty( $heading_map ) ) {
			update_post_meta( $post_id, 'seogenheadingmap', $heading_map );
		}

		// @MODIFIED 2026-03-24: Use Schema_Sync_Service for canonical persistence with merge safety
		if ( ! empty( $preview['article'] ) && is_array( $preview['article'] ) ) {
			try {
				$schema = \SEO_Article_Generator\Generator\Article_Schema::from_array( $preview['article'] );

				/*
				 * Do NOT re-merge here.
				 * Publish_Payload_Builder::build() has already produced the canonical effective article
				 * for both new and update flows, including partial-regeneration merge logic.
				 * Re-merging here creates a second authority and can desync top-level fields.
				 */
				\SEO_Article_Generator\Services\Schema_Sync_Service::save_schema( $post_id, $schema );
			} catch ( \Throwable $e ) {
				throw new \RuntimeException( 'Critical Schema Failure for Post ' . $post_id . ': ' . $e->getMessage(), 0, $e );
			}
		}

		// Audit Fix #Critical-2: Robust Metadata Persistence
		// Failing to save the job ID means the link to the AI record is lost.
		// We treat this as a BLOCKING error to prevent "orphaned" posts.
		$ok = \update_post_meta( $post_id, '_seo_gen_job_id', $job_id );

		// If update_post_meta returns false, it could be because the value is the same.
		// We check if it actually exists.
		if ( $ok === false && (int) \get_post_meta( $post_id, '_seo_gen_job_id', true ) !== $job_id ) {
			throw new \RuntimeException( "Critical Metadata Failure: Failed to persist _seo_gen_job_id for Post {$post_id}" );
		}

		$saved_content = \get_post_field( 'post_content', $post_id, 'raw' );
		$has_sentinels = is_string( $saved_content )
		&& strpos( $saved_content, '<!-- wp:seo-gen/section' ) !== false;

		if ( $has_sentinels ) {
			$contract_ok = \update_post_meta( $post_id, '_seo_gen_content_contract', 'blocks-v1' );

			if ( $contract_ok === false && 'blocks-v1' !== (string) \get_post_meta( $post_id, '_seo_gen_content_contract', true ) ) {
				throw new \RuntimeException( "Critical Metadata Failure: Failed to persist _seo_gen_content_contract for Post {$post_id}" );
			}
		} else {
			\delete_post_meta( $post_id, '_seo_gen_content_contract' );
			// FIX: Add leading backslash to force global namespace lookup for SEO_GEN_DEBUG constant
			if ( defined( '\SEO_GEN_DEBUG' ) && \SEO_GEN_DEBUG ) {
				\error_log(
					sprintf(
						'SEO GEN [write_post_meta] Post %d saved without zone sentinels — contract NOT written.',
						$post_id
					)
				);
			}
		}

		// CRITICAL FIX: Always clear the legacy rewrite flag after successful finalization,
		// regardless of whether sentinels were written. The flag is a one-time migration
		// directive — once the post has been processed through the full-rewrite path,
		// it must be classified as TYPE_PLUGIN on the next update scan.
		// Without this, posts get stuck in an infinite zero-content loop:
		// flag set → TYPE_LEGACY → empty html_content → no sentinels → flag NOT cleared → repeat.
		\delete_post_meta( $post_id, '_seo_gen_force_legacy_rewrite' );

		\update_post_meta( $post_id, '_seo_gen_last_checked', Plugin_Time::utc_mysql_now() );

		\do_action( 'seo_gen_post_finalized', $post_id, $preview );
	}

	public function assign_taxonomies( $post_id, $preview, $item = null ) {
		if ( empty( $preview['article'] ) || ! is_array( $preview['article'] ) ) {
			return;
		}

		$article = $preview['article'];

		$is_update = false;
		if ( ! empty( $item ) && is_object( $item ) && ! empty( $item->existing_post_id ) ) {
			$is_update = ( (int) $item->existing_post_id ) > 0;
		} elseif ( ! empty( $item ) && is_array( $item ) && ! empty( $item['existing_post_id'] ) ) {
			$is_update = ( (int) $item['existing_post_id'] ) > 0;
		}

		$tech_specs    = is_array( $article['tech_specs'] ?? null ) ? $article['tech_specs'] : array();
		$software_name = trim( (string) ( $tech_specs['software_name'] ?? '' ) );
		$ossupport     = trim( (string) ( $tech_specs['os_support'] ?? '' ) );
		$license       = trim( (string) ( $tech_specs['license'] ?? '' ) );

		// --- CATEGORIES (Deterministic OS + Type Mapping) ---
		// @MODIFIED 2026-04-24: Replaced AI-dependent category assignment with deterministic
		// OS detection from tech_specs + keyword-to-category mapping table. AI category is
		// used only as a HINT that is validated against actual WP categories.

		$cat_ids = array();

		// STEP 1: Deterministic OS category assignment from tech_specs.os_support.
		// No AI needed — the OS platforms are structural facts.
		// [ISSUE-8 FIX] OS categories moved to TAGS only (not assigned as categories)
		// to fix breadcrumb/entity confusion. Rank Math Primary Category will be the type category.
		$os_category_map = array(
			'windows' => 'windows',
			'mac'     => 'mac',
			'macos'   => 'mac',
			'apple'   => 'mac',
			'linux'   => 'linux',
			'android' => 'android',
			'ios'     => 'ios',
			'iphone'  => 'ios',
			'ipad'    => 'ios',
		);
		$os_lower        = strtolower( $ossupport );
		$os_slugs_for_tags = array();
		foreach ( $os_category_map as $keyword => $slug ) {
			if ( strpos( $os_lower, $keyword ) !== false ) {
				$term = \get_term_by( 'slug', $slug, 'category' );
				if ( $term && ! \is_wp_error( $term ) ) {
					$os_slugs_for_tags[] = $slug; // Collect for TAGS, not categories
				}
			}
		}
		$os_slugs_for_tags = array_values( array_unique( $os_slugs_for_tags ) );

		// STEP 2: Software Type → Category mapping using keyword table.
		// Merge custom user overrides (from settings) with default keyword table.
		$keyword_map = self::get_category_keyword_map();

		// STEP 3: Try AI category hint — validate against actual WP categories.
		$ai_category      = trim( (string) ( $article['category'] ?? '' ) );
		$ai_hero_category = '';
		if ( ! empty( $article['hero_section'] ) && is_array( $article['hero_section'] ) && ! empty( $article['hero_section']['category'] ) ) {
			$ai_hero_category = trim( (string) $article['hero_section']['category'] );
		}
		$ai_candidates = array_filter( array_map( 'trim', explode( ',', $ai_category . ',' . $ai_hero_category ) ) );
		$type_cat_id   = 0;
		foreach ( $ai_candidates as $candidate ) {
			if ( ! is_string( $candidate ) || trim( $candidate ) === '' ) {
				continue;
			}
			$term = \get_term_by( 'slug', \sanitize_title( $candidate ), 'category' );
			if ( ! $term ) {
				$term = \get_term_by( 'name', $candidate, 'category' );
			}
			if ( $term && ! \is_wp_error( $term ) ) {
				$slug = $term->slug;
				// Skip OS categories — already assigned in Step 1
				$os_slugs = array( 'windows', 'mac', 'macos', 'linux', 'android', 'ios', 'featured', 'offline', 'portable' );
				if ( ! in_array( strtolower( $slug ), $os_slugs, true ) ) {
					$type_cat_id = (int) $term->term_id;
					break;
				}
			}
		}

		// STEP 4: If AI didn't resolve a type category, scan software_name + ai_category against keyword map.
		if ( $type_cat_id === 0 && ! empty( $keyword_map ) ) {
			$scan_text = strtolower( $software_name . ' ' . $ai_category . ' ' . ( $article['software_type'] ?? '' ) );
			foreach ( $keyword_map as $keyword => $slug ) {
				if ( $keyword !== '' && strpos( $scan_text, $keyword ) !== false ) {
					$term = \get_term_by( 'slug', $slug, 'category' );
					if ( $term && ! \is_wp_error( $term ) ) {
						$type_cat_id = (int) $term->term_id;
						break;
					}
				}
			}
		}

		// STEP 5: Fallback — use existing post categories (for updates) or 'misc'.
		if ( $type_cat_id === 0 ) {
			if ( $is_update && $post_id > 0 ) {
				$existing_terms = \get_the_terms( $post_id, 'category' );
				if ( ! empty( $existing_terms ) && ! \is_wp_error( $existing_terms ) ) {
					$os_slugs = array( 'windows', 'macos', 'linux', 'android', 'ios', 'featured', 'offline', 'portable' );
					$sw_terms = array_filter(
						$existing_terms,
						static function ( $t ) use ( $os_slugs ) {
							return ! in_array( $t->slug, $os_slugs, true );
						}
					);
					if ( ! empty( $sw_terms ) ) {
						$type_cat_id = (int) reset( $sw_terms )->term_id;
					}
				}
			}
			if ( $type_cat_id === 0 ) {
				$default_cat_id = (int) \get_option(
					\SEO_Article_Generator\Option_Registry::DEFAULT_CATEGORY,
					0
				);
				if ( $default_cat_id > 0 && \get_term( $default_cat_id, 'category' ) ) {
					$type_cat_id = $default_cat_id;
				} else {
					// Try common fallback slugs in order
					$fallback_slugs = array( 'misc', 'uncategorized', 'general', 'tools', 'utilities' );
					foreach ( $fallback_slugs as $fslug ) {
						$term = \get_term_by( 'slug', $fslug, 'category' );
						if ( $term && ! \is_wp_error( $term ) ) {
							$type_cat_id = (int) $term->term_id;
							break;
						}
					}
					// Last resort: auto-create 'misc' category if nothing exists
					if ( $type_cat_id === 0 ) {
						$new_term = \wp_insert_term( 'Miscellaneous', 'category', array( 'slug' => 'misc' ) );
						if ( ! \is_wp_error( $new_term ) && isset( $new_term['term_id'] ) ) {
							$type_cat_id = (int) $new_term['term_id'];
						}
					}
				}
			}
		}
		if ( $type_cat_id > 0 && ! in_array( $type_cat_id, $cat_ids, true ) ) {
			$cat_ids[] = $type_cat_id;
		}

		if ( ! empty( $cat_ids ) ) {
			$cat_ids = array_values( array_unique( array_filter( $cat_ids ) ) );

			if ( $is_update ) {
				$existing = \wp_get_post_categories( $post_id, array( 'fields' => 'ids' ) );
				$existing = is_array( $existing ) ? $existing : array();
				$merged   = array_values( array_unique( array_merge( $existing, $cat_ids ) ) );
				\wp_set_post_categories( $post_id, $merged );
			} else {
				\wp_set_post_categories( $post_id, $cat_ids );
			}
		}

		// [ISSUE-8 FIX] Set Rank Math Primary Category to the resolved type category.
		// This ensures breadcrumbs, schema applicationCategory, and SERP entity path
		// all point to the software TYPE (e.g., "Downloaders") not OS (e.g., "Windows").
		if ( $type_cat_id > 0 ) {
			\update_post_meta( $post_id, 'rank_math_primary_category', $type_cat_id );
		}

		// --- TAGS (Deterministic: categories-as-tags + metadata) ---
		// @MODIFIED 2026-04-24: Replaced AI-dependent tags with deterministic pipeline.
		// Categories become tags, plus software name, license type. AI tags discarded.
		$tags = array();

		// TAG SOURCE 1: All assigned categories → tags (user preference: categories as tags).
		if ( ! empty( $cat_ids ) ) {
			foreach ( $cat_ids as $cid ) {
				$term = \get_term_by( 'id', $cid, 'category' );
				if ( $term && ! \is_wp_error( $term ) ) {
					$tags[] = \sanitize_text_field( $term->name );
				}
			}
		}

		// [ISSUE-8 FIX] TAG SOURCE 1b: OS platforms as tags (not categories).
		// Fixes breadcrumb volatility and duplicate archive pages.
		if ( ! empty( $os_slugs_for_tags ) ) {
			foreach ( $os_slugs_for_tags as $slug ) {
				$term = \get_term_by( 'slug', $slug, 'category' );
				if ( $term && ! \is_wp_error( $term ) ) {
					$tags[] = \sanitize_text_field( $term->name );
				}
			}
		}

		// TAG SOURCE 2: Software name (always).
		if ( $software_name !== '' ) {
			$tags[] = \sanitize_text_field( $software_name );
		}

		// TAG SOURCE 3: License type — map to canonical tag forms.
		if ( $license !== '' ) {
			$license_tag_map = array(
				'freeware'     => 'freeware',
				'free'         => 'freeware',
				'open source'  => 'freeware',
				'trial'        => 'shareware',
				'shareware'    => 'shareware',
				'commercial'   => 'shareware',
				'paid'         => 'shareware',
				'subscription' => 'shareware',
			);
			$lic_lower       = strtolower( $license );
			foreach ( $license_tag_map as $needle => $tag_val ) {
				if ( strpos( $lic_lower, $needle ) !== false ) {
					$tags[] = \sanitize_text_field( $tag_val );
					break;
				}
			}
		}

		// TAG SOURCE 4: Type category name as tag (if distinct from OS categories).
		if ( $type_cat_id > 0 ) {
			$type_term = \get_term_by( 'id', $type_cat_id, 'category' );
			if ( $type_term && ! \is_wp_error( $type_term ) ) {
				$type_tag = \sanitize_text_field( $type_term->name );
				if ( ! in_array( strtolower( $type_tag ), array_map( 'strtolower', $tags ), true ) ) {
					$tags[] = $type_tag;
				}
			}
		}

		$tags = array_values( array_unique( array_filter( $tags ) ) );
		$tags = $this->enforce_tag_limit( $tags, $article, 8 );
		if ( ! empty( $tags ) ) {
			\wp_set_post_tags( $post_id, $tags, true );
		}
	}

	/**
	 * Get the merged category keyword→slug map.
	 * Custom user overrides (from settings) take priority over defaults.
	 *
	 * @MODIFIED 2026-04-24: New method for deterministic category mapping.
	 * @return array<string,string> keyword => category-slug
	 */
	private static function get_category_keyword_map(): array {
		static $cached = null;
		if ( $cached !== null ) {
			return $cached;
		}

		$default_map = array(
			'3d cad'                  => '3d-cad-aec',
			'autocad'                 => '3d-cad-aec',
			'revit'                   => '3d-cad-aec',
			'solidworks'              => '3d-cad-aec',
			'sketchup'                => '3d-cad-aec',
			'bim'                     => '3d-cad-aec',
			'cad'                     => '3d-cad-aec',
			'adobe'                   => 'adobe',
			'photoshop'               => 'adobe',
			'illustrator'             => 'adobe',
			'premiere'                => 'adobe',
			'after effects'           => 'adobe',
			'acrobat'                 => 'adobe',
			'indesign'                => 'adobe',
			'lightroom'               => 'adobe',
			'creative cloud'          => 'adobe',
			'camera raw'              => 'adobe',
			'dng converter'           => 'adobe',
			'adobe camera'            => 'adobe',
			'ai tool'                 => 'ai-tools',
			'artificial intelligence' => 'ai-tools',
			'machine learning'        => 'ai-tools',
			'chatbot'                 => 'ai-tools',
			'image generator'         => 'ai-tools',
			'ai writing'              => 'ai-tools',
			'language model'          => 'ai-tools',
			'ai assistant'            => 'ai-tools',
			'lm studio'               => 'ai-tools',
			'local llm'               => 'ai-tools',
			'app'                     => 'tools',
			'application'             => 'tools',
			'archive'                 => 'archives',
			'zip'                     => 'archives',
			'rar'                     => 'archives',
			'7zip'                    => 'archives',
			'extract'                 => 'archives',
			'compress'                => 'archives',
			'tar'                     => 'archives',
			'unzip'                   => 'archives',
			'decompress'              => 'archives',
			'peazip'                  => 'archives',
			'audio'                   => 'audio',
			'music player'            => 'audio',
			'audio editor'            => 'audio',
			'sound'                   => 'audio',
			'podcast'                 => 'audio',
			'audio recorder'          => 'audio',
			'monkeys audio'           => 'audio',
			'monkey\'s audio'         => 'audio',
			'lossless'                => 'audio',
			'ape'                     => 'audio',
			'audio compressor'        => 'audio',
			'aimp'                    => 'audio',
			'mediamonkey'             => 'audio',
			'n-track'                 => 'audio',
			'ntrack'                  => 'audio',
			'track studio'            => 'audio',
			'tuniac'                  => 'audio',
			'virtualdj'               => 'audio',
			'reaper'                  => 'audio',
			'audials'                 => 'audio',
			'balabolka'               => 'tools',
			'audio converter'         => 'audio-converters',
			'mp3 converter'           => 'audio-converters',
			'audio format'            => 'audio-converters',
			'music converter'         => 'audio-converters',
			'backup'                  => 'backup-recovery',
			'recovery'                => 'backup-recovery',
			'disk image'              => 'backup-recovery',
			'clone'                   => 'backup-recovery',
			'system restore'          => 'backup-recovery',
			'file recovery'           => 'backup-recovery',
			'data recovery'           => 'backup-recovery',
			'rescue'                  => 'backup-recovery',
			'wipe'                    => 'backup-recovery',
			'cleaner'                 => 'backup-recovery',
			'disk copy'               => 'backup-recovery',
			'r-studio'                => 'backup-recovery',
			'privacy'                 => 'security-privacy',
			'disk cleaner'            => 'security-privacy',
			'browser'                 => 'browsers',
			'web browser'             => 'browsers',
			'internet browser'        => 'browsers',
			'firefox'                 => 'browsers',
			'mozilla'                 => 'browsers',
			'chrome'                  => 'browsers',
			'chromium'                => 'browsers',
			'librewolf'               => 'browsers',
			'waterfox'                => 'browsers',
			'pale moon'               => 'browsers',
			'palemoon'                => 'browsers',
			'yandex'                  => 'browsers',
			'edge'                    => 'browsers',
			'microsoft edge'          => 'browsers',
			'opera'                   => 'browsers',
			'slimjet'                 => 'browsers',
			'srware'                  => 'browsers',
			'iron'                    => 'browsers',
			'zen'                     => 'browsers',
			'perplexity'              => 'browsers',
			'comet'                   => 'browsers',
			'arc browser'             => 'browsers',
			'helium'                  => 'browsers',
			'floorp'                  => 'browsers',
			'dvd'                     => 'cd-dvd-tools',
			'cd burner'               => 'cd-dvd-tools',
			'disc burner'             => 'cd-dvd-tools',
			'iso burner'              => 'cd-dvd-tools',
			'optical disc'            => 'cd-dvd-tools',
			'blu-ray'                 => 'cd-dvd-tools',
			'dvdfab'                  => 'cd-dvd-tools',
			'dvd fab'                 => 'cd-dvd-tools',
			'daemon tools'            => 'cd-dvd-tools',
			'virtual drive'           => 'cd-dvd-tools',
			'nero'                    => 'cd-dvd-tools',
			'ashampoo burning'        => 'cd-dvd-tools',
			'cloud'                   => 'cloud-synchronization',
			'sync'                    => 'cloud-synchronization',
			'drive'                   => 'cloud-synchronization',
			'cloud storage'           => 'cloud-synchronization',
			'dropbox'                 => 'cloud-synchronization',
			'onedrive'                => 'cloud-synchronization',
			'goodsync'                => 'cloud-synchronization',
			'sync software'           => 'cloud-synchronization',
			'cms'                     => 'cms',
			'content management'      => 'cms',
			'wordpress'               => 'cms',
			'code editor'             => 'code-editors',
			'ide'                     => 'code-editors',
			'text editor'             => 'code-editors',
			'programming'             => 'code-editors',
			'developer tool'          => 'code-editors',
			'.net'                    => 'code-editors',
			'dotnet'                  => 'code-editors',
			'microsoft .net'          => 'code-editors',
			'visual studio'           => 'code-editors',
			'java'                    => 'code-editors',
			'jdk'                     => 'code-editors',
			'jre'                     => 'code-editors',
			'web builder'             => 'code-editors',
			'wysiwyg'                 => 'code-editors',
			'emeditor'                => 'code-editors',
			'phpmaker'                => 'code-editors',
			'pilotedit'               => 'code-editors',
			'rocketcake'              => 'code-editors',
			'css html'                => 'code-editors',
			'html validator'          => 'code-editors',
			'communication'           => 'communication',
			'messaging'               => 'communication',
			'video call'              => 'communication',
			'voip'                    => 'communication',
			'telegram'                => 'communication',
			'signal'                  => 'communication',
			'whatsapp'                => 'communication',
			'paltalk'                 => 'communication',
			'teams'                   => 'communication',
			'microsoft teams'         => 'communication',
			'google meet'             => 'communication',
			'meet'                    => 'communication',
			'mdaemon'                 => 'communication',
			'thunderbird'             => 'communication',
			'customization'           => 'customization',
			'theme'                   => 'customization',
			'wallpaper'               => 'customization',
			'desktop'                 => 'customization',
			'icon pack'               => 'customization',
			'skin'                    => 'customization',
			'downloader'              => 'downlaoder',
			'download manager'        => 'downlaoder',
			'download accelerator'    => 'downlaoder',
			'video downloader'        => 'downlaoder',
			'youtube downloader'      => 'downlaoder',
			'driver updater'          => 'driver-updater',
			'driver'                  => 'drivers',
			'graphics driver'         => 'drivers',
			'gpu driver'              => 'drivers',
			'nvidia'                  => 'drivers',
			'rtx'                     => 'drivers',
			'ftp'                     => 'ftp',
			'file transfer'           => 'ftp',
			'sftp'                    => 'ftp',
			'graphic'                 => 'graphics',
			'image editor'            => 'graphics',
			'photo editor'            => 'graphics',
			'screenshot'              => 'graphics',
			'design'                  => 'graphics',
			'drawing'                 => 'graphics',
			'paint.net'               => 'graphics',
			'paintnet'                => 'graphics',
			'faststone'               => 'graphics',
			'imageglass'              => 'graphics',
			'xnview'                  => 'graphics',
			'xnviewmp'                => 'graphics',
			'vuescan'                 => 'graphics',
			'reaconverter'            => 'graphics',
			'topaz'                   => 'graphics',
			'gigapixel'               => 'graphics',
			'leafview'                => 'graphics',
			'image viewer'            => 'graphics',
			'ashampoo photo'          => 'graphics',
			'imagine'                 => 'graphics',
			'internet'                => 'internet',
			'network'                 => 'internet',
			'wifi'                    => 'internet',
			'ip scanner'              => 'internet',
			'wireshark'               => 'internet',
			'media converter'         => 'media-converters',
			'video converter'         => 'video-converters',
			'format converter'        => 'media-converters',
			'media player'            => 'media-players',
			'video player'            => 'media-players',
			'vlc'                     => 'media-players',
			'music player'            => 'media-players',
			'potplayer'               => 'media-players',
			'gom player'              => 'media-players',
			'zoom player'             => 'media-players',
			'allplayer'               => 'media-players',
			'jriver'                  => 'media-players',
			'kmplayer'                => 'media-players',
			'office'                  => 'office',
			'spreadsheet'             => 'office',
			'word processor'          => 'office',
			'presentation'            => 'office',
			'document'                => 'office',
			'evernote'                => 'office',
			'joplin'                  => 'office',
			'filecenter'              => 'office',
			'lucion'                  => 'office',
			'optimization'            => 'optimization',
			'optimizer'               => 'optimization',
			'speed'                   => 'optimization',
			'tuneup'                  => 'optimization',
			'system optimizer'        => 'optimization',
			'pc optimizer'            => 'optimization',
			'advanced systemcare'     => 'optimization',
			'glary'                   => 'optimization',
			'system mechanic'         => 'optimization',
			'tweaknow'                => 'optimization',
			'wise care'               => 'optimization',
			'wincontig'               => 'optimization',
			'windows manager'         => 'optimization',
			'defrag'                  => 'optimization',
			'scene shift'             => 'optimization',
			'sceneshift'              => 'optimization',
			'os'                      => 'os',
			'operating system'        => 'os',
			'pdf'                     => 'pdf',
			'pdf reader'              => 'pdf',
			'pdf editor'              => 'pdf',
			'pdf converter'           => 'pdf',
			'portable'                => 'portable',
			'portable app'            => 'portable',
			'remote desktop'          => 'remote-desktop',
			'remote access'           => 'remote-desktop',
			'anydesk'                 => 'remote-desktop',
			'hoptodesk'               => 'remote-desktop',
			'teamviewer'              => 'remote-desktop',
			'screen recorder'         => 'screen-recorder',
			'screencast'              => 'screen-recorder',
			'screen capture'          => 'screen-recorder',
			'snagit'                  => 'screen-recorder',
			'camtasia'                => 'screen-recorder',
			'techsmith'               => 'screen-recorder',
			'security'                => 'security-privacy',
			'antivirus'               => 'security-privacy',
			'malware'                 => 'security-privacy',
			'firewall'                => 'security-privacy',
			'spyware'                 => 'security-privacy',
			'ransomware'              => 'security-privacy',
			'bitdefender'             => 'security-privacy',
			'total security'          => 'security-privacy',
			'internet security'       => 'security-privacy',
			'endpoint'                => 'security-privacy',
			'kaspersky'               => 'security-privacy',
			'gridinsoft'              => 'security-privacy',
			'norton'                  => 'security-privacy',
			'privazer'                => 'security-privacy',
			'privacy eraser'          => 'security-privacy',
			'sandboxie'               => 'security-privacy',
			'hitman'                  => 'security-privacy',
			'loaris'                  => 'security-privacy',
			'unhackme'                => 'security-privacy',
			'vpn'                     => 'vpn',
			'proxy'                   => 'vpn',
			'tunnel'                  => 'vpn',
			'virtual private'         => 'vpn',
			'windscribe'              => 'vpn',
			'simulator'               => 'simulator',
			'emulator'                => 'simulator',
			'games'                   => 'games',
			'game'                    => 'games',
			'minecraft'               => 'games',
			'xemu'                    => 'simulator',
			'mame'                    => 'simulator',
			'tools'                   => 'tools',
			'toolkit'                 => 'tools',
			'utility'                 => 'tools',
			'system utility'          => 'tools',
			'diagnostic'              => 'tools',
			'burnin'                  => 'tools',
			'burnintest'              => 'tools',
			'passmark'                => 'tools',
			'benchmark'               => 'tools',
			'stress test'             => 'tools',
			'hardware test'           => 'tools',
			'system test'             => 'tools',
			'argus monitor'           => 'tools',
			'argusmonitor'            => 'tools',
			'performancetest'         => 'tools',
			'performance test'        => 'tools',
			'eventsentry'             => 'tools',
			'glow'                    => 'tools',
			'ntlite'                  => 'tools',
			'mediainfo'               => 'tools',
			'xyplorer'                => 'tools',
			'qbittorrent'             => 'tools',
			'torrent'                 => 'tools',
			'apache'                  => 'tools',
			'http server'             => 'tools',
			'server'                  => 'tools',
			'file server'             => 'tools',
			'hfs'                     => 'tools',
			'pc manager'              => 'tools',
			'wingate'                 => 'tools',
			'bluecon'                 => 'tools',
			'o&o'                     => 'tools',
			'aida64'                  => 'tools',
			'aida'                    => 'tools',
			'gpu-z'                   => 'tools',
			'gpuz'                    => 'tools',
			'memtest'                 => 'tools',
			'memtest86'               => 'tools',
			'msi center'              => 'tools',
			'onyx'                    => 'tools',
			'wine'                    => 'tools',
			'xplorer'                 => 'tools',
			'file manager'            => 'tools',
			'explorer'                => 'tools',
			'roboform'                => 'tools',
			'hide folders'            => 'tools',
			'wise folder'             => 'tools',
			'dr.fone'                 => 'tools',
			'drfone'                  => 'tools',
			'google earth'            => 'tools',
			'google antigravity'      => 'tools',
			'flyoobe'                 => 'tools',
			'inno'                    => 'tools',
			'inno setup'              => 'tools',
			'awesome miner'           => 'tools',
			'miner'                   => 'tools',
			'bluestacks'              => 'tools',
			'ldplayer'                => 'tools',
			'memu'                    => 'tools',
			'vmware'                  => 'tools',
			'workstation'             => 'tools',
			'unifab'                  => 'video-editor',
			'varia'                   => 'downlaoder',
			'draw.io'                 => 'graphics',
			'drawio'                  => 'graphics',
			'streamfab'               => 'cd-dvd-tools',
			'uninstaller'             => 'uninstallers',
			'remove'                  => 'uninstallers',
			'revo'                    => 'uninstallers',
			'revo uninstaller'        => 'uninstallers',
			'usb'                     => 'usb',
			'flash drive'             => 'usb',
			'pendrive'                => 'usb',
			'wintousb'                => 'usb',
			'usb boot'                => 'usb',
			'bootable'                => 'usb',
			'andromouse'              => 'tools',
			'android mouse'           => 'tools',
			'rufus'                   => 'usb',
			'video converter'         => 'video-converters',
			'video encoder'           => 'video-converters',
			'transcoder'              => 'video-converters',
			'video editor'            => 'video-editor',
			'video editing'           => 'video-editor',
			'movie maker'             => 'video-editor',
			'filmora'                 => 'video-editor',
			'movavi'                  => 'video-editor',
			'video editor plus'       => 'video-editor',
			'videopad'                => 'video-editor',
			'winxvideo'               => 'video-editor',
			'winx video'              => 'video-editor',
			'activepresenter'         => 'video-editor',
			'capcut'                  => 'video-editor',
			'davinci resolve'         => 'video-editor',
			'davinci'                 => 'video-editor',
			'hitpaw'                  => 'video-editor',
			'shotcut'                 => 'video-editor',
			'cyberlink promeo'        => 'video-editor',
			'promeo'                  => 'video-editor',
			'shutter encoder'         => 'video-converters',
		);

		// Custom overrides from settings (format: "keyword1, keyword2 => slug" per line)
		$custom_raw = trim( (string) \get_option( \SEO_Article_Generator\Option_Registry::CATEGORY_KEYWORD_MAP, '' ) );
		if ( $custom_raw !== '' ) {
			foreach ( preg_split( '/\r?\n/', $custom_raw ) as $line ) {
				$line = trim( $line );
				if ( $line === '' || strpos( $line, '=>' ) === false ) {
					continue;
				}
				$parts = array_map( 'trim', explode( '=>', $line, 2 ) );
				if ( count( $parts ) === 2 && $parts[0] !== '' && $parts[1] !== '' ) {
					foreach ( array_map( 'trim', explode( ',', $parts[0] ) ) as $kw ) {
						if ( $kw !== '' ) {
							$default_map[ strtolower( $kw ) ] = $parts[1];
						}
					}
				}
			}
		}

		$cached = $default_map;
		return $cached;
	}

	private function enforce_tag_limit( array $tags, array $article, int $max = 8 ): array {
		$software_name = strtolower( trim( (string) ( $article['tech_specs']['software_name'] ?? $article['softwarename'] ?? $article['software_name'] ?? '' ) ) );
		$os_support    = strtolower( trim( (string) ( $article['tech_specs']['os_support'] ?? $article['ossupport'] ?? '' ) ) );
		$license       = strtolower( trim( (string) ( $article['tech_specs']['license'] ?? $article['license'] ?? '' ) ) );

		// @MODIFIED 2026-04-24: Load configurable blocklist from option, fallback to hardcoded defaults.
		$blocklist_raw     = trim( (string) \get_option( \SEO_Article_Generator\Option_Registry::TAG_BLOCKLIST, '' ) );
		$generic_blocklist = array();
		if ( $blocklist_raw !== '' ) {
			foreach ( array_map( 'trim', preg_split( '/[,\\n]+/', $blocklist_raw ) ) as $item ) {
				if ( $item !== '' ) {
					$generic_blocklist[] = strtolower( $item );
				}
			}
		}
		if ( empty( $generic_blocklist ) ) {
			$generic_blocklist = array(
				'software',
				'download',
				'free download',
				'windows software',
				'pc software',
				'best software',
				'top software',
				'utility',
				'utilities',
				'computer software',
				'latest version',
				'new version',
				'software download',
				'free software',
				'app',
				'application',
			);
		}

		// @MODIFIED 2026-04-24: Removed developer from anchors (user preference).
		$anchors  = array_filter( array( $software_name, $os_support, $license ) );
		$filtered = array();
		foreach ( $tags as $tag ) {
			$tag_lower = strtolower( trim( (string) $tag ) );
			if ( $tag_lower === '' ) {
				continue;
			}
			if ( in_array( $tag_lower, $generic_blocklist, true ) ) {
				continue;
			}
			$is_relevant = false;
			foreach ( $anchors as $anchor ) {
				if ( $anchor !== '' && ( strpos( $tag_lower, $anchor ) !== false || strpos( $anchor, $tag_lower ) !== false ) ) {
					$is_relevant = true;
					break;
				}
			}
			if ( ! $is_relevant ) {
				$is_relevant = str_word_count( $tag_lower ) >= 2;
			}
			if ( $is_relevant ) {
				$filtered[] = $tag;
			}
		}

		// @MODIFIED 2026-04-24: Use configurable max from option.
		$configured_max = (int) \get_option( \SEO_Article_Generator\Option_Registry::TAG_MAX_COUNT, $max );
		if ( $configured_max < 3 ) {
			$configured_max = 3;
		}

		return array_slice( $filtered, 0, $configured_max );
	}
	public function reconcile_after_queue_reset(): int {
		global $wpdb;
		$table = Installer::table_discovery();

		$now   = Plugin_Time::utc_mysql_now();
		$fixed = 0;

		$rows = $wpdb->get_results(
			// FIX (2.32.27): include scheduled_at — the deferred branch below
			// reads $row['scheduled_at'] to respect the future publish window;
			// without it, every deferred item looked like a missed slot and was
			// re-armed immediately instead of waiting for its scheduled time.
			"SELECT id, status, job_id, queue_job_id, error_message, scheduled_at
			 FROM {$table}
			 WHERE status IN ('pending','queued','processing','generating','finalizing','failed','timeout','deferred')",
			ARRAY_A
		);

		foreach ( (array) $rows as $row ) {
			$id     = (int) $row['id'];
			$status = (string) $row['status'];
			$jobid  = (int) $row['job_id'];
			$errmsg = trim( (string) ( $row['error_message'] ?? '' ) );

			if ( $status === 'pending' ) {
				$updated = $wpdb->query(
					$wpdb->prepare(
						"UPDATE {$table}
					 SET job_id = NULL, queue_job_id = NULL, scheduled_at = NULL, heartbeat_at = NULL
					 WHERE id = %d AND (job_id IS NOT NULL OR queue_job_id IS NOT NULL OR scheduled_at IS NOT NULL OR heartbeat_at IS NOT NULL)",
						$id
					)
				);
				if ( $updated ) {
					++$fixed;
				}
				continue;
			}

			if ( $status === 'queued' ) {
				// Narrow queued -> pending demotion so it happens only when no process-item schedule,
				// no recoverable job lifecycle, and no finalizable job remain.
				$nextprocess = AS_Registry::get_next_item_run( $id );
				if ( $nextprocess > 0 ) {
					$this->write_scheduled_at( $id, (int) $nextprocess );
					++$fixed;
					continue;
				}

				if ( $jobid > 0 ) {
					$life = $this->job_handler->get_job_lifecycle_status( (int) $jobid );

					if ( ! empty( $life['should_continue'] ) ) {
						$poll_delay = self::POLL_INTERVAL;
						$wpdb->update(
							$table,
							array( 'poll_count' => 0 ),
							array( 'id' => $id ),
							array( '%d' ),
							array( '%d' )
						);
						if ( ! AS_Registry::schedule_check_job( $id, (int) $jobid, 1, 1, $poll_delay ) ) {
							$this->mark_discovery_failure( $id, 'failed', 'Queue reset found active job but failed to re-arm polling.' );
						} else {
							$this->write_scheduled_at( $id, Plugin_Time::now_utc_ts() + $poll_delay );
						}
						++$fixed;
						continue;
					}

					if ( ! empty( $life['should_finalize'] ) ) {
						$claimed = $this->claim_item_for_finalization( $id, (int) $jobid, true );
if ( $claimed ) {
						$this->auto_finalize( $claimed, (int) $jobid, (int) ( $life['user_id'] ?? 1 ), false );
					}
						++$fixed;
						continue;
					}
				}

				// Only demote to pending when no stronger truth exists
				$wpdb->update(
					$table,
					array(
						'status'        => 'pending',
						'error_message' => 'Queue reset: re-queued for re-approval.',
						'scheduled_at'  => null,
						'heartbeat_at'  => null,
						'job_id'        => null,
						'queue_job_id'  => null,
					),
					array( 'id' => $id ),
					array( '%s', '%s', '%s', '%s', '%d', '%d' ),
					array( '%d' )
				);
				++$fixed;
				continue;
			}

			if ( $jobid > 0 && in_array( $status, array( 'generating', 'processing', 'finalizing' ), true ) ) {
				$life = $this->job_handler->get_job_lifecycle_status( $jobid );

				if ( ! empty( $life['should_finalize'] ) ) {
					$claimed = $this->claim_item_for_finalization( $id, $jobid );
					if ( $claimed ) {
						$this->auto_finalize( $claimed, $jobid, (int) ( $life['user_id'] ?? 1 ) );
						++$fixed;
						continue;
					}
				}

				if ( ! empty( $life['should_continue'] ) ) {
					$wpdb->update(
						$table,
						array(
							'error_message' => null,
							'scheduled_at'  => null,
							'heartbeat_at'  => null,
							'poll_count'    => 0,
						),
						array( 'id' => $id ),
						array( '%s', '%s', '%s', '%d' ),
						array( '%d' )
					);
					AS_Registry::schedule_check_job( $id, $jobid, 1, 1, 30 );
					++$fixed;
					continue;
				}
			}

			// Deferred items: respect scheduled_at — only re-arm if the check job was lost.
			if ( $status === 'deferred' ) {
				$scheduled_at_str = (string) ( $row['scheduled_at'] ?? '' );
				$has_check_job    = AS_Registry::get_next_item_run( $id ) > 0;

				if ( $scheduled_at_str !== '' && strtotime( $scheduled_at_str ) > time() && $has_check_job ) {
					// Still waiting for publish window and check job is alive — leave alone
					continue;
				}

				if ( $scheduled_at_str !== '' && strtotime( $scheduled_at_str ) > time() && ! $has_check_job ) {
					// Waiting for publish window but check job was lost — reschedule it
					$delay = max( 60, strtotime( $scheduled_at_str ) - time() );
					AS_Registry::schedule_check_job( $id, $jobid, 1, 1, $delay );
					$this->write_scheduled_at( $id, time() + $delay );
					++$fixed;
					continue;
				}

				// scheduled_at in the past or empty — treat as missed, re-arm for immediate processing
				$wpdb->update(
					$table,
					array(
						'status'       => 'queued',
						'scheduled_at' => null,
						'heartbeat_at' => null,
						'job_id'       => null,
						'queue_job_id' => null,
					),
					array( 'id' => $id ),
					array( '%s', '%s', '%s', '%d', '%d' ),
					array( '%d' )
				);
				if ( AS_Registry::schedule_process_item( $id, 1, 30 ) ) {
					$this->write_scheduled_at( $id, Plugin_Time::now_utc_ts() + 30 );
				}
				++$fixed;
				continue;
			}

			$message = $errmsg ?: 'Queue reset reconciled orphaned discovery item after Action Scheduler reset.';
			// FIX F0 (Phase 3A): route through the SSOT (also nulls stale job refs).
			$this->mark_discovery_failure( $id, 'failed', $message );
			\SEO_Article_Generator\Core\Admission_Gate::get_instance()->reset_stale_counters();
			++$fixed;
		}

		$this->invalidate_dashboard_caches();
		return $fixed;
	}

	public function run_auto_generation(): string {
		if ( $this->is_pipeline_paused() ) {
			return 'skipped_paused';
		}

		if ( ! \get_option( \SEO_Article_Generator\Option_Registry::ENABLE_AUTO_GENERATION, \SEO_Article_Generator\Option_Registry::defaults()[ \SEO_Article_Generator\Option_Registry::ENABLE_AUTO_GENERATION ] ) ) {
			return 'skipped_disabled';
		}

		// Cross-request atomic mutex. GET_LOCK returns 0 when already held — no TOCTOU.
		if ( ! $this->acquire_autogen_lock() ) {
			$this->logger->info( 'Auto-Gen: skipped — concurrent run already in progress (lock busy).' );
			return 'skipped_lock';
		}

		try {
			$now_utc        = Plugin_Time::now_utc_ts();
			$quota          = class_exists( '\\SEO_Article_Generator\\AI\\AI_Client' ) && method_exists( '\\SEO_Article_Generator\\AI\\AI_Client', 'get_daily_quota_status' )
			? \SEO_Article_Generator\AI\AI_Client::get_daily_quota_status()
			: array( 'reset_utc_ts' => 0 );
			$quota_reset_ts = max( 0, (int) ( $quota['reset_utc_ts'] ?? 0 ) );
			if ( $quota_reset_ts > $now_utc ) {
				$fallback_routable = false;
				if ( class_exists( '\\SEO_Article_Generator\\AI\\AI_Client' ) && method_exists( '\\SEO_Article_Generator\\AI\\AI_Client', 'get_provider_status' ) ) {
					$_prov_status = \SEO_Article_Generator\AI\AI_Client::get_provider_status();
					$fallback_routable = ! empty( $_prov_status['routable'] );
				}
				if ( ! $fallback_routable ) {
					$this->logger->warning(
						'Auto-Gen: Approval cycle skipped — ALL providers blocked (primary quota until ' .
						Plugin_Time::utc_mysql_from_utc_ts( $quota_reset_ts ) . ' UTC, no routable fallbacks).'
					);
					return 'skipped_providers';
				}
				$this->logger->info(
					'Auto-Gen: Primary provider quota blocked but routable fallback providers available — proceeding with fallback chain.'
				);
			}
			if ( ! empty( $quota['enabled'] ) && ( $quota['remaining'] ?? 0 ) <= 0 ) {
				$this->logger->info(
					\sprintf(
						'Auto-Gen skipped: daily API quota exhausted. Used: %d / %d. Resets: %s UTC.',
						(int) ( $quota['used'] ?? 0 ),
						(int) ( $quota['limit'] ?? 0 ),
						\SEO_Article_Generator\Plugin_Time::utc_mysql_from_utc_ts( (int) $quota_reset_ts )
					)
				);
				return 'skipped_quota';
			}

			$gate = $this->get_generation_gate();
			if ( empty( $gate['ok'] ) ) {
				$reason = (string) ( $gate['reason'] ?? 'No active AI providers available' );
				if ( ! empty( $gate['temporary'] ) ) {
					$this->logger->warning( 'Auto-Gen: Approval cycle skipped — temporary generation block. ' . $reason );
					return 'skipped_gate';
				}
				$this->logger->error( 'Auto-Gen: Approval cycle skipped — hard generation block. ' . $reason );
				return 'skipped_gate';
			}

			$defaults = \SEO_Article_Generator\Option_Registry::defaults();
			$limit = max( 1, (int) \get_option( \SEO_Article_Generator\Option_Registry::AUTO_GENERATION_BATCH, $defaults[ \SEO_Article_Generator\Option_Registry::AUTO_GENERATION_BATCH ] ) );

			global $wpdb;
			$table   = Installer::table_discovery();
			$pending = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT id, software_name FROM $table WHERE status = 'pending' ORDER BY discovered_at ASC LIMIT %d",
					$limit
				)
			);

		if ( empty( $pending ) ) {
			$_total_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM $table");
			$_status_dist = $wpdb->get_col("SELECT status FROM $table GROUP BY status ORDER BY COUNT(*) DESC", 0);
			$this->logger->info(
				'Auto-Gen: no pending items. Table totals: ' . $_total_count . '. Status distribution: ' . implode( ', ', $_status_dist ) . '.'
			);
			return 'skipped_no_pending';
		}

					$admin_ids = \get_users(
						array(
							'role'    => 'administrator',
							'number'  => 1,
							'fields'  => 'ids',
							'orderby' => 'ID',
							'order'   => 'ASC',
						)
					);
					$admin_id  = ! empty( $admin_ids ) ? (int) $admin_ids[0] : 1;

				$raw_interval = \get_option( \SEO_Article_Generator\Option_Registry::AUTO_GENERATION_INTERVAL, $defaults[ \SEO_Article_Generator\Option_Registry::AUTO_GENERATION_INTERVAL ] );

		$interval_seconds = \SEO_Article_Generator\Option_Registry::interval_to_seconds( $raw_interval );

					$count    = count( $pending );
					$slot_gap = $count > 1 ? (int) floor( $interval_seconds / $count ) : 0;
					$slot_gap = max( 60, $slot_gap );

					$base_offset = 30;

			foreach ( array_values( $pending ) as $slot => $item ) {
				$item_obj   = (object) $item;
				$slot_delay = $base_offset + ( $slot * $slot_gap );
				$this->approve_item( (int) $item_obj->id, $admin_id, $slot_delay );
			}

			return 'ran';
		} finally {
			$this->release_autogen_lock();
		}
	}

	public function reconcile_item_status( int $id ): void {
		global $wpdb;
		$table = Installer::table_discovery();

		$item = $this->get_item( $id, array( 'id', 'status', 'job_id', 'type', 'existing_post_id' ) );

		if ( ! $item ) {
			return;
		}
		$item_obj = (object) $item;

		// Contract repair: ensure type/existing_post_id are canonical
		$reconcile_contract = Discovery_Engine::canonicalize_discovery_contract(
			(string) ( $item_obj->type ?? '' ),
			(int) ( $item_obj->existing_post_id ?? 0 )
		);

		if (
		(string) ( $item_obj->type ?? '' ) !== $reconcile_contract['type'] ||
		(int) ( $item_obj->existing_post_id ?? 0 ) !== (int) $reconcile_contract['existing_post_id']
		) {
			$wpdb->update(
				$table,
				array(
					'type'                     => $reconcile_contract['type'],
					self::COL_EXISTING_POST_ID => (int) $reconcile_contract['existing_post_id'],
				),
				array( 'id' => $id ),
				array( '%s', '%d' ),
				array( '%d' )
			);
			$this->logger->warning(
				'reconcile_item_status repaired discovery contract.',
				array(
					'discovery_id'  => $id,
					'resolved_type' => $reconcile_contract['type'],
					'resolved_post' => (int) $reconcile_contract['existing_post_id'],
				)
			);
			$item_obj->type             = $reconcile_contract['type'];
			$item_obj->existing_post_id = (int) $reconcile_contract['existing_post_id'];
		}

		// [FINDING-1 FIX] Allow failed/timeout rows to be recovered by completed jobs
		if ( ! in_array( $item_obj->status, array( 'queued', 'generating', 'processing', 'finalizing', 'failed', 'timeout', 'deferred' ), true ) ) {
			return;
		}

		if ( (int) $item_obj->job_id <= 0 && $item_obj->status === 'queued' ) {
			return;
		}

		$job_status = $this->job_handler->get_job_lifecycle_status( (int) $item_obj->job_id );
		$s          = $job_status['combined_status'] ?? '';

		if ( $s === 'completed' ) {
			// [FINDING-1 FIX] Allow recovery of failed/timeout status when job completed
			$allow_failed_recovery = in_array( (string) $item_obj->status, array( 'failed', 'timeout' ), true );

			$claimed = $this->claim_item_for_finalization(
				(int) $id,
				(int) $item_obj->job_id,
				$allow_failed_recovery
			);
			if ( $claimed ) {
				$this->auto_finalize( $claimed, (int) $item_obj->job_id, (int) ( $job_status['user_id'] ?? 1 ) );
			}
			return;
		}

		if ( $s === 'reconcile_failed' ) {
			if (
				$this->recover_from_reconcile_failed_snapshot(
					(int) $id,
					(int) $item_obj->job_id,
					(int) ( $job_status['user_id'] ?? 1 ),
					'reconcile_item_status'
				)
			) {
				return;
			}
		}

		if ( in_array(
			$s,
			array(
				'failed',
				'error',
				'timeout',
				'timed_out',
				Job_Handler::STATUS_FAILED_VALIDATION,
				'reconcile_failed',
			),
			true
		) ) {
			$this->mark_discovery_failure(
				(int) $id,
				in_array( $s, array( 'timeout', 'timed_out' ), true ) ? 'timeout' : 'failed',
				(string) ( $job_status['failure_reason'] ?? $job_status['error_message'] ?? $s )
			);
			return;
		}
	}
	public function run_queue_now(): int {
		if ( $this->is_pipeline_paused() ) {
			return 0;
		}

		global $wpdb;

		$items = $wpdb->get_results(
			'SELECT id, existing_post_id
			 FROM ' . Installer::table_discovery() . "
			 WHERE status IN ('queued','processing','generating','finalizing','failed','timeout','deferred')
			 ORDER BY discovered_at ASC"
		);

		$count               = 0;
		$uid                 = \get_current_user_id() ? (int) \get_current_user_id() : 1;
		$next_delay          = 1;
		$process_stagger_sec = 10;

		foreach ( (array) $items as $item ) {
			// Refetch each row before dispatch so bulk manual run does not act on stale batch state
			$fresh = $this->get_item( (int) $item->id, array( 'id', 'status', 'job_id', 'existing_post_id' ) );
			if ( empty( $fresh ) ) {
				continue;
			}

			$fresh_obj = (object) $fresh;
			if ( ! in_array( (string) $fresh_obj->status, array( 'queued', 'processing', 'generating', 'finalizing', 'failed', 'timeout', 'deferred' ), true ) ) {
				continue;
			}

			if ( $this->run_item_now( (int) $fresh_obj->id, $uid, $next_delay ) ) {
				++$count;
			}

			$next_delay += $process_stagger_sec;
		}

		return $count;
	}


	public function run_item_now( int $id, int $uid = 0, int $delay_seconds = 1 ): bool {
		if ( $this->is_pipeline_paused() ) {
			return false;
		}

		global $wpdb;

		$table = Installer::table_discovery();

		if ( $uid <= 0 ) {
			$uid = \get_current_user_id() ? (int) \get_current_user_id() : 1;
		}

		$delay_seconds = max( 1, (int) $delay_seconds );

		$item = $this->get_item(
			$id,
			array(
				'id',
				'status',
				'job_id',
				'error_message',
				'heartbeat_at',
				'type',
				'existing_post_id',
			)
		);

		if ( ! $item ) {
			return false;
		}

		$status = (string) $item->status;
		$job_id = (int) $item->job_id;

		// Add lifecycle-preserving gate used by retry_item() before any identity reset
		if ( $job_id > 0 && \in_array( $status, array( 'queued', 'processing', 'generating', 'finalizing', 'deferred' ), true ) ) {
			$life = $this->job_handler->get_job_lifecycle_status( $job_id );

			if ( ! empty( $life['should_finalize'] ) ) {
				$claimed = $this->claim_item_for_finalization( $id, $job_id, true );
				if ( $claimed ) {
					$this->auto_finalize( $claimed, $job_id, (int) ( $life['user_id'] ?? $uid ), true );
					return true;
				}
				return false;
			}

			if ( ! empty( $life['should_continue'] ) ) {
				$poll_delay = max( 1, (int) $delay_seconds );
				if ( ( $life['combined_status'] ?? '' ) === 'deferred' ) {
					$deferred_until  = (int) ( $life['deferred_until'] ?? 0 );
					$now_ts          = Plugin_Time::now_utc_ts();
					$deferred_jitter = max( 1, $id % self::POLL_INTERVAL );
					$poll_delay      = $deferred_until > $now_ts
						? max( self::POLL_INTERVAL, ( $deferred_until - $now_ts ) + 5 + $deferred_jitter )
						: max( self::POLL_INTERVAL, 5 + $deferred_jitter );
				}

				$wpdb->update(
					$table,
					array( 'poll_count' => 0 ),
					array( 'id' => $id ),
					array( '%d' ),
					array( '%d' )
				);

				// FIX D2 (2026-09-06): re-arm starts a fresh budget cycle.
				$this->clear_effective_poll_count( (int) $id );

				if ( ! AS_Registry::schedule_check_job( $id, $job_id, (int) $uid, 1, $poll_delay ) ) {
					$this->restore_item_schedule_failure(
						$id,
						$status,
						isset( $item['error_message'] ) ? (string) $item['error_message'] : null,
						isset( $item['heartbeat_at'] ) ? (string) $item['heartbeat_at'] : null
					);
					$this->logger->error( 'Discovery ' . $id . ' manual poll failed; Action Scheduler refused check-job schedule.' );
					return false;
				}

				$this->sync_scheduled_at_from_registry( $id, Plugin_Time::now_utc_ts() + $poll_delay );
				$this->logger->info( 'Discovery ' . $id . ' manual poll re-armed in-flight job poll at ' . $poll_delay . 's.' );
				return true;
			}
		}

			// Non-in-flight path - preserve update snapshot before reset/re-arm
		if ( ! empty( $item->existing_post_id ) ) {
			$this->persist_regen_sections_snapshot( (int) $item->existing_post_id );
		}

		if ( ! \in_array( $status, array( 'queued', 'failed', 'timeout', 'deferred' ), true ) ) {
			return false;
		}

		$contract = Discovery_Engine::canonicalize_discovery_contract(
			(string) ( $item->type ?? '' ),
			(int) ( $item->existing_post_id ?? 0 )
		);

		// Contract repair: write canonical type/existing_post_id before re-queuing
		if (
		(string) ( $item->type ?? '' ) !== $contract['type'] ||
		(int) ( $item->existing_post_id ?? 0 ) !== (int) $contract['existing_post_id']
		) {
			$wpdb->update(
				$table,
				array(
					'type'                     => $contract['type'],
					self::COL_EXISTING_POST_ID => (int) $contract['existing_post_id'],
				),
				array( 'id' => $id ),
				array( '%s', '%d' ),
				array( '%d' )
			);
			$this->logger->warning(
				'run_item_now repaired discovery contract before re-queuing.',
				array(
					'discovery_id'  => (int) $id,
					'resolved_type' => $contract['type'],
					'resolved_post' => (int) $contract['existing_post_id'],
				)
			);
			$item->type             = $contract['type'];
			$item->existing_post_id = (int) $contract['existing_post_id'];
		}

		if (
		(int) \get_option( Discovery_Engine::PLUGIN_FILTER_OPTION, 0 ) === 1
		&& Post_Type_Classifier::is_plugin_owned( $contract['type'] ?? '' )
		) {
			// FIX F0 (Phase 3A): route through the failure SSOT (cancels actions
			// and invalidates caches itself).
			$marked = $this->mark_discovery_failure( $id, 'failed', Discovery_Engine::PLUGIN_FILTER_ERROR );

			if ( ! $marked ) {
				return false;
			}

			$this->logger->warning(
				'Discovery ' . (int) $id . ' run-now blocked by plugin-generated filter.'
			);

			return false;
		}

		AS_Registry::cancel_item_actions( $id );

		$updated = $wpdb->update(
			$table,
			array(
				'status'        => 'queued',
				'error_message' => null,
				'heartbeat_at'  => Plugin_Time::utc_mysql_now(),
				'scheduled_at'  => null,
				'job_id'        => null,
				'queue_job_id'  => null,
				'poll_count'    => 0,
				// FIX F4: manual run resets the breaker (explicit human override).
				'consecutive_failures' => 0,
				'last_failure_at'      => null,
			),
			array( 'id' => $id ),
			array( '%s', '%s', '%s', '%s', '%d', '%d', '%d', '%d', '%s' ),
			array( '%d' )
		);

		if ( $updated === false ) {
			return false;
		}

		if ( ! AS_Registry::schedule_process_item( $id, (int) $uid, $delay_seconds ) ) {
			$this->restore_item_schedule_failure(
				$id,
				$status,
				isset( $item->error_message ) ? (string) $item->error_message : null,
				isset( $item->heartbeat_at ) ? (string) $item->heartbeat_at : null
			);
			$this->logger->error( 'Discovery ' . $id . ' manual run failed: Action Scheduler refused process-item schedule.' );
			return false;
		}

		$this->sync_scheduled_at_from_registry( $id, Plugin_Time::now_utc_ts() + $delay_seconds );
		$this->logger->info( 'Discovery ' . $id . ' manual run triggered at +' . $delay_seconds . 's.' );

		return true;
	}

	/**
	 * SSOT Error Classification Registry
	 * Returns the recovery strategy based on error signatures.
	 *
	 * @param string $error_message
	 * @return string 'discovery', 'generation', or 'abort'
	 */
	public static function get_recovery_strategy( string $error_message ): string {
		$error_message = strtolower( trim( $error_message ) );

		if ( empty( $error_message ) ) {
			return 'generation';
		}

		// Discovery-level data gaps: retry via discovery path (re-queues item).
		// no_sentinel_structure_requires_regen: post has no zone delimiters —
		// _seo_gen_force_legacy_rewrite flag is already set; retry_item re-queues
		// and process_item_background routes through full-rewrite gating.
		$discovery_signatures = array(
			'no_sentinel_structure_requires_regen',
			'surgical_patch_requested_zones_missing',
			// A requested section missing from the AI schema is almost always
			// recoverable: the regeneration is re-prompted with the same
			// regen_sections, so the AI gets a second (capped) chance to emit it.
			// Classifying this as 'deterministic' abandoned the update (and the
			// source) the moment the AI omitted a section the admin just enabled,
			// so a newly-toggled section could silently never propagate. Route it
			// through full-regeneration retries instead — capped at 3 by the caller.
			'ai_schema_missing_requested_sections',
		);
		foreach ( $discovery_signatures as $sig ) {
			if ( strpos( $error_message, $sig ) !== false ) {
				return 'discovery';
			}
		}

		// Deterministic failures: exactly 1 retry allowed, then dismiss + delete.
		// These errors are data-driven — the same input will always produce the
		// same gap. After the first retry fails, the source draft and media must
		// be cleaned up to stop burning API quota.
		$deterministic_signatures = array(
			'missing required populated sections',
			'final sanity check',
			'all partial regeneration sections failed sanity check',
			'software name mismatch',
			'publish preflight failed at schema',
		);
		foreach ( $deterministic_signatures as $sig ) {
			if ( strpos( $error_message, $sig ) !== false ) {
				return 'deterministic';
			}
		}

		// Immediate dismiss: source has no usable data — zero retry, delete
		// draft + media immediately. Retry is pointless when the source itself
		// provides nothing to build from.
		$immediate_dismiss_signatures = array(
			'no downloadable links found',
		);
		foreach ( $immediate_dismiss_signatures as $sig ) {
			if ( strpos( $error_message, $sig ) !== false ) {
				return 'immediate_dismiss';
			}
		}

		// Unrecoverable errors: bad request, invalid payload, manually killed
		$abort_signatures = array(
			'http 400',
			// [PHASE 3D, 2.32.28] Thin-output guard parked this item: the full-render
			// AI output omitted prose sections even after the alternate-model retry.
			// Leave it in the Failed tab (parked); manual Retry/Run-now resets the
			// breaker and re-arms. The post content is untouched by this failure.
			'full_render_ai_omitted_sections',
			// [PHASE 3F, 2.34.0] Duplicate-suppression retired this backlog job
			// WITHOUT an AI call because a newer job already covers the same post.
			// Never resurrect it via rescan/auto-gen (it is a duplicate, not a
			// content failure); the newer owning job produces the real result.
			'superseded_duplicate_no_ai_burn',
			'status code 400',
			'error 400',
			'invalid_argument',
			'invalidargument',
			'bad request',
			'killed manually by user',
		);
		foreach ( $abort_signatures as $sig ) {
			if ( strpos( $error_message, $sig ) !== false ) {
				return 'abort';
			}
		}

		// Default fallback for flaky AI errors, timeouts, rate limits
		return 'generation';
	}

	/**
	 * Smart recovery based on SSOT Error Classification.
	 *
	 * @param int $id Discovery ID
	 * @param int $uid User ID
	 * @param int $delay_seconds Schedule delay
	 * @return bool
	 */
	public function smart_recover_item( int $id, int $uid = 0, int $delay_seconds = 1 ): bool {
		global $wpdb;

		$item = $this->get_item( $id, array( 'id', 'status', 'error_message', 'existing_post_id' ) );
		if ( ! $item ) {
			return false;
		}

		$strategy = self::get_recovery_strategy( (string) ( $item->error_message ?? '' ) );

		if ( $strategy === 'abort' ) {
			$this->logger->warning( 'Discovery ' . $id . ' smart recovery aborted due to permanent error signature: ' . (string) $item->error_message );
			return false; // Leave it in terminal state
		}

		if ( $strategy === 'immediate_dismiss' ) {
			$this->logger->info( sprintf(
				'[AUDIT] Discovery %d smart recovery: immediate dismiss + cleanup. Reason: %s',
				$id,
				(string) $item->error_message
			) );
			return $this->dismiss_and_cleanup_source( $id );
		}

		if ( $strategy === 'discovery' ) {
			// Do NOT clear existing_post_id. The existing system uses _seo_gen_force_legacy_rewrite 
			// post meta to route the post to full-rewrite gating while retaining its ID/featured image.
			if ( strpos( strtolower( (string) ( $item->error_message ?? '' ) ), 'no_sentinel_structure' ) !== false ) {
				$this->logger->info( 'Discovery ' . $id . ' smart recovery routing to DISCOVERY (Full Rewrite Gating).' );
			} else {
				$this->logger->info( 'Discovery ' . $id . ' smart recovery routing to DISCOVERY.' );
			}
		} elseif ( $strategy === 'deterministic' ) {
			$this->logger->info( sprintf(
				'Discovery %d smart recovery routing to DETERMINISTIC retry (1-shot).',
				$id
			) );
		} else {
			$this->logger->info( 'Discovery ' . $id . ' smart recovery routing to GENERATION retry.' );
		}

		return $this->retry_item( $id, $uid, $delay_seconds );
	}

	public function retry_item( int $id, int $uid = 0, int $delay_seconds = 1 ): bool {
		if ( $this->is_pipeline_paused() ) {
			return false;
		}

		global $wpdb;

		$table = Installer::table_discovery();

		if ( $uid <= 0 ) {
			$uid = \get_current_user_id() ? (int) \get_current_user_id() : 1;
		}

		$delay_seconds = max( 1, (int) $delay_seconds );

		$item = $this->get_item(
			$id,
			array(
				'id',
				'status',
				'job_id',
				'queue_job_id',
				'last_job_id',
				'error_message',
				'heartbeat_at',
				'type',
				'existing_post_id',
			)
		);

		if ( ! $item ) {
			return false;
		}
		$item_obj = (object) $item;

		if ( ! \in_array( (string) $item_obj->status, array( 'failed', 'timeout' ), true ) ) {
			return false;
		}

		$contract = Discovery_Engine::canonicalize_discovery_contract(
			(string) ( $item_obj->type ?? '' ),
			(int) ( $item_obj->existing_post_id ?? 0 )
		);

		// [FIX 1] Contract repair: write canonical values back before re-queueing
		if (
			(string) ( $item_obj->type ?? '' ) !== $contract['type'] ||
			(int) ( $item_obj->existing_post_id ?? 0 ) !== (int) $contract['existing_post_id']
		) {
			$wpdb->update(
				$table,
				array(
					'type'                     => $contract['type'],
					self::COL_EXISTING_POST_ID => (int) $contract['existing_post_id'],
				),
				array( 'id' => $id ),
				array( '%s', '%d' ),
				array( '%d' )
			);
			$this->logger->warning(
				'retry_item repaired discovery contract before re-queuing.',
				array(
					'discovery_id'  => (int) $id,
					'resolved_type' => $contract['type'],
					'resolved_post' => (int) $contract['existing_post_id'],
				)
			);
			$item_obj->type             = $contract['type'];
			$item_obj->existing_post_id = (int) $contract['existing_post_id'];
		}

		if (
			(int) \get_option( Discovery_Engine::PLUGIN_FILTER_OPTION, 0 ) === 1
			&& Post_Type_Classifier::is_plugin_owned( $contract['type'] ?? '' )
		) {
			// FIX F0 (Phase 3A): route through the failure SSOT (cancels actions itself).
			// NOTE: on an already-failed row G2 keeps the FIRST failure message; the
			// filter refusal is still recorded in the log line below.
			$this->mark_discovery_failure( $id, 'failed', Discovery_Engine::PLUGIN_FILTER_ERROR );

			$this->logger->warning( 'Discovery ' . $id . ' retry blocked by plugin-generated filter.' );
			return false;
		}

		// Compute recovery strategy to determine if full re-queue is needed.
		// Discovery-routed errors require full regeneration; re-finalizing the
		// same completed job would hit the same error.
		$error_msg        = strtolower( trim( (string) ( $item_obj->error_message ?? '' ) ) );
		$is_discovery_routed = ( self::get_recovery_strategy( $error_msg ) === 'discovery' );

		// MODIFIED: Check if existing job is still alive before allowing retry
		// Fall back to last_job_id when job_id was nulled by mark_discovery_failure
		$current_job_id = (int) ( $item_obj->job_id ?? 0 );
		if ( $current_job_id === 0 && (int) ( $item_obj->last_job_id ?? 0 ) > 0 ) {
			$current_job_id = (int) $item_obj->last_job_id;
		}
		// Restore job_id/queue_job_id for claim_item_for_finalization WHERE clause.
		// mark_discovery_failure() nulls these columns but preserves last_job_id.
		if ( $current_job_id > 0 && empty( $item_obj->job_id ) ) {
			$wpdb->update(
				$table,
				array(
					'job_id'       => $current_job_id,
					'queue_job_id' => $current_job_id,
				),
				array( 'id' => $id ),
				array( '%d', '%d' ),
				array( '%d' )
			);
		}

		if ( $current_job_id > 0 && ! $is_discovery_routed ) {
			$life     = $this->job_handler->get_job_lifecycle_status( $current_job_id );
			$combined = (string) ( $life['combined_status'] ?? '' );

			// If job should finalize, try to claim and finalize instead of retrying
			if ( ! empty( $life['should_finalize'] ) ) {
				$claimed = $this->claim_item_for_finalization( $id, $current_job_id, true );
				if ( $claimed ) {
					$this->auto_finalize( $claimed, $current_job_id, (int) ( $life['user_id'] ?? $uid ) );
					return true;
				}

				$this->logger->warning(
					'Discovery ' . (int) $id . ' retry blocked: job ' . (int) $current_job_id .
					' is terminal-complete but finalization claim failed. Identity preserved.'
				);
				return false;
			}

			// If job is still active (pending, deferred, processing, generating, validating), block retry
			if (
				! empty( $life['should_continue'] )
				|| \in_array( $combined, array( 'pending', 'deferred', 'processing', 'generating', 'validating' ), true )
			) {
				$poll_delay = max( 1, $delay_seconds );
				if ( $combined === 'deferred' ) {
					$deferred_until  = (int) ( $life['deferred_until'] ?? 0 );
					$now_ts          = Plugin_Time::now_utc_ts();
					$deferred_jitter = (int) $id % max( 1, self::POLL_INTERVAL );

					if ( $deferred_until > $now_ts ) {
						$poll_delay = max( self::POLL_INTERVAL, ( $deferred_until - $now_ts ) + 5 + $deferred_jitter );
					} else {
						$poll_delay = max( self::POLL_INTERVAL, 5 + $deferred_jitter );
					}
				}

				AS_Registry::cancel_item_actions( $id );

				$wpdb->update(
					$table,
					array( 'poll_count' => 0 ),
					array( 'id' => $id ),
					array( '%d' ),
					array( '%d' )
				);

				// FIX D2 (2026-09-06): re-arm starts a fresh budget cycle.
				$this->clear_effective_poll_count( (int) $id );

				if ( ! AS_Registry::schedule_check_job( $id, $current_job_id, (int) $uid, 1, $poll_delay ) ) {
					$this->logger->error(
						'Discovery ' . (int) $id . ' retry blocked: existing job ' . (int) $current_job_id .
						' is still active (' . $combined . ') but poll re-arm failed. Identity preserved.'
					);
					return false;
				}

				$this->sync_scheduled_at_from_registry( $id, Plugin_Time::now_utc_ts() + $poll_delay );

				$this->logger->warning(
					'Discovery ' . (int) $id . ' retry blocked: existing job ' . (int) $current_job_id .
					' is still active (' . $combined . '). Poll re-armed instead of resetting identity.'
				);
				return true;
			}

			if ( ! empty( $life['should_fail'] ) ) {
				$this->logger->info(
					'Discovery ' . (int) $id . ' retry proceeding only after terminal lifecycle state for job ' .
					(int) $current_job_id . ': ' . $combined
				);
			} else {
				$this->logger->warning(
					'Discovery ' . (int) $id . ' retry refused: unresolved lifecycle state for job ' .
					(int) $current_job_id . '. Identity preserved to avoid orphaning.'
				);
				return false;
			}
		}

		AS_Registry::cancel_item_actions( $id );

		$updated = $wpdb->update(
			$table,
			array(
				'status'        => 'queued',
				'error_message' => null,
				'heartbeat_at'  => null,
				'scheduled_at'  => null,
				'job_id'        => null,
				'queue_job_id'  => null,
				'poll_count'    => 0,
				// FIX F4: manual retry resets the breaker (explicit human override).
				'consecutive_failures' => 0,
				'last_failure_at'      => null,
			),
			array( 'id' => $id ),
			array( '%s', '%s', '%s', '%s', '%d', '%d', '%d', '%d', '%s' ),
			array( '%d' )
		);

		if ( $updated === false ) {
			return false;
		}

		if ( ! AS_Registry::schedule_process_item( $id, (int) $uid, $delay_seconds ) ) {
			$this->restore_item_schedule_failure(
				$id,
				(string) $item_obj->status,
				isset( $item_obj->error_message ) ? (string) $item_obj->error_message : null,
				isset( $item_obj->heartbeat_at ) ? (string) $item_obj->heartbeat_at : null
			);
			$this->logger->error( 'Discovery ' . $id . ' retry failed: Action Scheduler refused process-item schedule.' );
			return false;
		}

		$this->sync_scheduled_at_from_registry( $id, Plugin_Time::now_utc_ts() + $delay_seconds );
		$this->logger->info( 'Manual retry triggered for Discovery ' . $id );

		return true;
	}

	public function kill_pipeline_item( int $id, int $user_id = 0 ): bool {
		global $wpdb;

		if ( $this->is_pipeline_paused() ) {
			return false;
		}

		$table = Installer::table_discovery();
		$item  = $this->get_item( $id, array( 'id', 'status', 'job_id' ) );

		if ( ! $item ) {
			return false;
		}

		$status = (string) ( $item->status ?? '' );
		if ( ! in_array( $status, array( 'queued', 'processing', 'generating', 'finalizing', 'deferred' ), true ) ) {
			return false;
		}

		AS_Registry::cancel_item_actions( $id );

		$job_id = (int) ( $item->job_id ?? 0 );
		if ( $job_id > 0 && $this->job_handler ) {
			$this->job_handler->force_cancel_job( $job_id, 'Killed manually from discovery dashboard.' );
		}

		// FIX F0 (Phase 3A): route through the failure SSOT (draft re-schedule,
		// transient clear, logging). Kill is a manual action, not a failure —
		// do not count the breaker here (parked explicitly below instead).
		$marked = $this->mark_discovery_failure( $id, 'failed', 'Killed manually by user.', false );

		if ( ! $marked ) {
			return false;
		}

		// FIX F4: park killed items at the trip threshold so rescan + auto-gen do
		// not resurrect them. Manual Retry / Run Now resets the breaker and re-runs.
		$wpdb->update(
			$table,
			array(
				self::COL_CONSECUTIVE_FAILURES => self::MAX_CONSECUTIVE_FAILURES,
				self::COL_LAST_FAILURE_AT     => Plugin_Time::utc_mysql_now(),
			),
			array( 'id' => $id ),
			array( '%d', '%s' ),
			array( '%d' )
		);

		$this->invalidate_dashboard_caches();
		return true;
	}

	public function fail_plugin_filtered_pending_items(): int {
		global $wpdb;

		$table = Installer::table_discovery();

		if ( ! class_exists( 'SEO_Article_Generator\Discovery\Post_Type_Classifier' ) || ! class_exists( 'SEO_Article_Generator\Discovery\Discovery_Engine' ) ) {
			return 0;
		}

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id
				 FROM {$table}
				 WHERE status = %s
				   AND type IN (%s, %s)",
				'pending',
				\SEO_Article_Generator\Discovery\Post_Type_Classifier::TYPE_PLUGIN,
				\SEO_Article_Generator\Discovery\Post_Type_Classifier::TYPE_PLUGIN_LEGACY
			)
		);

		$count = 0;

		foreach ( (array) $rows as $row ) {
			$id = (int) $row->id;
			// FIX F0 (Phase 3A): route through the failure SSOT (cancels actions itself).
			if ( $this->mark_discovery_failure( $id, 'failed', \SEO_Article_Generator\Discovery\Discovery_Engine::PLUGIN_FILTER_ERROR ) ) {
				++$count;
			}
		}

		$this->invalidate_dashboard_caches();
		return $count;
	}

	public function after_history_mutation_reconcile(): void {
		global $wpdb;

		$table = Installer::table_discovery();

		$rows = $wpdb->get_results(
			"SELECT id
			 FROM {$table}
			 WHERE status IN ('queued','processing','generating','finalizing','failed','timeout','deferred')",
			ARRAY_A
		);

		foreach ( (array) $rows as $row ) {
			$id = (int) ( $row['id'] ?? 0 );
			if ( $id > 0 ) {
				$this->reconcile_item_status( $id );
			}
		}

		$this->invalidate_dashboard_caches();
	}

	private function sync_scheduled_at_from_registry( int $discovery_id, ?int $fallback_utc_ts = null ): void {
		global $wpdb;

		$next = 0;

		// 1) Existing process-item schedule lookup.
		$process_ts = AS_Registry::get_next_item_run( $discovery_id );
		if ( $process_ts > 0 ) {
			$next = $process_ts;
		}

		// 2) Also inspect pending check-job polls for this discovery item.
		if ( function_exists( 'as_get_scheduled_actions' ) && class_exists( '\ActionScheduler' ) ) {
			$action_ids = as_get_scheduled_actions(
				array(
					'hook'     => AS_Registry::HOOK_CHECK_JOB,
					'status'   => \ActionScheduler_Store::STATUS_PENDING,
					'group'    => AS_Registry::GROUP,
					'per_page' => 50,
				),
				'ids'
			);

			if ( ! empty( $action_ids ) ) {
				$store = \ActionScheduler::store();

				foreach ( (array) $action_ids as $action_id ) {
					$action = $store->fetch_action( $action_id );
					if ( ! $action || $action instanceof \ActionScheduler_NullAction ) {
						continue;
					}

					$args = $action->get_args();
					if ( ! isset( $args[0] ) || (int) $args[0] !== $discovery_id ) {
						continue;
					}

					$schedule = $action->get_schedule();
					if ( ! $schedule ) {
						continue;
					}

					// FIX: Use getTimestamp() which is standard in ActionScheduler_Schedule interface
					// Fallback to get_date() for backward compatibility if needed
					$ts = 0;
					if ( method_exists( $schedule, 'getTimestamp' ) ) {
						$ts = (int) $schedule->getTimestamp();
					} elseif ( method_exists( $schedule, 'get_date' ) ) {
						// Fallback for older AS versions
						$date = $schedule->get_date();
						$ts   = $date ? (int) $date->getTimestamp() : 0;
					}

					if ( $ts <= 0 ) {
						continue;
					}
					if ( $ts > 0 && ( $next === 0 || $ts < $next ) ) {
						$next = $ts;
					}
				}
			}
		}

		$ts = $next > 0
			? $next
			: ( Plugin_Time::now_utc_ts() < (int) $fallback_utc_ts ? (int) $fallback_utc_ts : null );

		$wpdb->update(
			Installer::table_discovery(),
			array( 'scheduled_at' => $ts ? Plugin_Time::utc_mysql_from_utc_ts( $ts ) : null ),
			array( 'id' => $discovery_id ),
			array( '%s' ),
			array( '%d' )
		);
	}

	private function restore_item_schedule_failure(
		int $discovery_id,
		string $status,
		?string $error_message = null,
		?string $heartbeat_at = null
	): void {
		global $wpdb;

		$table = Installer::table_discovery();

		$wpdb->update(
			$table,
			array(
				self::COL_STATUS        => $status,
				self::COL_ERROR_MESSAGE => $error_message,
				self::COL_HEARTBEAT_AT  => $heartbeat_at,
				self::COL_SCHEDULED_AT  => null,
			),
			array( 'id' => $discovery_id ),
			array( '%s', '%s', '%s', '%s' ),
			array( '%d' )
		);

		$this->invalidate_dashboard_caches();
	}

	private function schedule_featured_image_sideload( int $pid, string $iurl, string $lurl, int $did, int $uid, int $retry_attempt = 0 ): void {
		// @MODIFIED 2026-04-03: Filter out localhost and same-site URLs that wp_remote_get() will block.
		$site_host = \wp_parse_url( \get_site_url(), PHP_URL_HOST );

		$filter_local_url = static function ( string $url ) use ( $site_host ): string {
			if ( empty( $url ) ) {
				return '';
			}
			$host = \wp_parse_url( $url, PHP_URL_HOST );
			if ( ! $host ) {
				return '';
			}
			// Block localhost, 127.x, 192.168.x, 10.x, and same-site URLs
			if (
				$host === 'localhost'
				|| $host === $site_host
				|| preg_match( '/^127\.\d+\.\d+\.\d+$/', $host )
				|| preg_match( '/^192\.168\./', $host )
				|| preg_match( '/^10\./', $host )
			) {
				return '';
			}
			return $url;
		};

		$iurl = $filter_local_url( $iurl );
		$lurl = $filter_local_url( $lurl );

		// M2 FIX: When both candidate URLs are absent there is nothing to schedule,
		// but record the failure so operators can identify affected posts.
		if ( empty( $iurl ) && empty( $lurl ) ) {
			$this->logger->warning(
				sprintf(
					'schedule_featured_image_sideload: Post %d Discovery %d — both image URLs are empty/local. No featured image will be set.',
					$pid,
					$did
				)
			);
			// Mark post so the operator can identify and manually fix affected posts.
			\update_post_meta( $pid, '_seo_gen_image_sideload_failed', time() );
			return;
		}

		$delay_seconds = $retry_attempt > 0 ? 30 * 60 : 2;

		$scheduled = AS_Registry::schedule_sideload( $pid, $iurl, $lurl, $did, $uid, $delay_seconds );
		if ( ! $scheduled ) {
			$this->logger->error(
				sprintf(
					'schedule_featured_image_sideload: Action Scheduler refused sideload schedule for Post %d (Discovery %d). Featured image will be missing.',
					$pid,
					$did
				)
			);
			// Mark so the operator can identify and manually fix affected posts.
			\update_post_meta( $pid, '_seo_gen_image_sideload_failed', time() );
		}
	}

	/**
	 * Calculate the next available publish slot based on user settings.
	 * respects: active days, publish window, and posts per day cap.
	 *
	 * @return int UTC Unix Timestamp
	 */

	/**
	 * Apply deterministic internal links to FINAL rendered block HTML.
	 *
	 * Single choke point used by every persistence branch in auto_finalize():
	 * the standard update $post_arr, the new-post $post_data, and the
	 * sentinel-absent self-heal wp_update_post() write. Adds 1–3 contextual
	 * internal links only inside the intro / MOAT / Features zones, never
	 * beyond the configured cap, and never mutates content when no safe
	 * contextual anchor exists. Failures are swallowed so linking can never
	 * break publishing.
	 *
	 * @since 2.34.11
	 *
	 * @param string $content       Final post_content HTML.
	 * @param object $item          Discovery row (software_name, existing_post_id).
	 * @param int    $fallback_post Post id to exclude when existing_post_id unset.
	 * @return string Content, possibly with internal links added.
	 */
	private function seo_gen_apply_internal_links( string $content, $item, int $fallback_post = 0 ): string {
		if ( trim( $content ) === '' ) {
			return $content;
		}

		$post_id = (int) ( ! empty( $item->existing_post_id ) ? $item->existing_post_id : $fallback_post );

		// [2.34.14] Try Link Whisper bridge first — contextual NLP matching.
		if ( $post_id > 0
			&& class_exists( '\\SEO_Article_Generator\\Links\\Link_Whisper_Bridge' )
			&& \SEO_Article_Generator\Links\Link_Whisper_Bridge::is_available()
		) {
			try {
				$bridge = new \SEO_Article_Generator\Links\Link_Whisper_Bridge( $this->logger );
				$linked = $bridge->inject( $content, $post_id );
				if ( $linked !== $content ) {
					return $linked; // Link Whisper placed links — use them.
				}
			} catch ( \Throwable $e ) {
				$this->logger->warning( 'Link Whisper Bridge skipped: ' . $e->getMessage() );
			}
		}

		// Fallback: deterministic brand-name injector.
		if ( ! class_exists( '\\SEO_Article_Generator\\Links\\Internal_Link_Injector' ) ) {
			return $content;
		}
		try {
			$injector = new \SEO_Article_Generator\Links\Internal_Link_Injector( $this->logger );
			$name     = trim( (string) ( $item->software_name ?? '' ) );
			return $injector->inject( $content, $name, $post_id );
		} catch ( \Throwable $e ) {
			$this->logger->warning( 'Internal link injector skipped: ' . $e->getMessage() );
			return $content;
		}
	}

	private function calculate_scheduled_publish_date(): int {
		global $wpdb;

		$lock_name = 'seogen_publish_slot_' . $wpdb->blogid;
		$timeouts  = array( 5, 5, 5, 15 );
		$acquired  = false;

		foreach ( $timeouts as $index => $timeout ) {
			$raw = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, %d)', $lock_name, $timeout ) );
			if ( $raw === 1 ) {
				$acquired = true;
				break;
			}

			if ( $index < ( count( $timeouts ) - 1 ) ) {
				\usleep( \rand( 200000, 600000 ) );
			}
		}

		if ( ! $acquired ) {
			$this->logger->warning( 'calculate_scheduled_publish_date: GET_LOCK failed after 4 tries. Running unprotected.' );
			return $this->_calculate_scheduled_publish_date_inner();
		}

		try {
			return $this->_calculate_scheduled_publish_date_inner();
		} finally {
			$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock_name ) );
		}
	}

	private function _calculate_scheduled_publish_date_inner(): int {
		global $wpdb;

		$now_ts  = Plugin_Time::now_utc_ts();
		$defaults = \SEO_Article_Generator\Option_Registry::defaults();
		$enabled = (bool) \get_option( \SEO_Article_Generator\Option_Registry::ENABLE_SCHEDULING, $defaults[ \SEO_Article_Generator\Option_Registry::ENABLE_SCHEDULING ] );

		if ( ! $enabled ) {
			return $now_ts;
		}

		$normalize_hhmm = static function ( $raw, string $fallback ): string {
			$raw = trim( (string) $raw );
			if ( $raw === '' ) {
				return $fallback;
			}

			if ( preg_match( '/^\d{1,2}:\d{2}$/', $raw ) ) {
				list($hour, $minute) = array_map( 'intval', explode( ':', $raw, 2 ) );
			} else {
				$digits = preg_replace( '/\D+/', '', $raw );

				if ( strlen( $digits ) === 3 ) {
					$hour   = (int) substr( $digits, 0, 1 );
					$minute = (int) substr( $digits, 1, 2 );
				} elseif ( strlen( $digits ) === 4 ) {
					$hour   = (int) substr( $digits, 0, 2 );
					$minute = (int) substr( $digits, 2, 2 );
				} else {
					return $fallback;
				}
			}

			if ( $hour < 0 || $hour > 23 || $minute < 0 || $minute > 59 ) {
				return $fallback;
			}

			return sprintf( '%02d:%02d', $hour, $minute );
		};

		$start_hhmm = $normalize_hhmm( (string) \get_option( \SEO_Article_Generator\Option_Registry::PUBLISH_START, $defaults[ \SEO_Article_Generator\Option_Registry::PUBLISH_START ] ), $defaults[ \SEO_Article_Generator\Option_Registry::PUBLISH_START ] );
		$end_hhmm   = $normalize_hhmm( (string) \get_option( \SEO_Article_Generator\Option_Registry::PUBLISH_END, $defaults[ \SEO_Article_Generator\Option_Registry::PUBLISH_END ] ), $defaults[ \SEO_Article_Generator\Option_Registry::PUBLISH_END ] );

		if ( $start_hhmm === $end_hhmm ) {
			$end_hhmm = $defaults[ \SEO_Article_Generator\Option_Registry::PUBLISH_END ];
		}
		$max_daily   = (int) \get_option( \SEO_Article_Generator\Option_Registry::POSTS_PER_DAY, $defaults[ \SEO_Article_Generator\Option_Registry::POSTS_PER_DAY ] );
		$active_days = \get_option( \SEO_Article_Generator\Option_Registry::ACTIVE_DAYS, $defaults[ \SEO_Article_Generator\Option_Registry::ACTIVE_DAYS ] );
		if ( empty( $active_days ) || ! \is_array( $active_days ) ) {
			$active_days = $defaults[ \SEO_Article_Generator\Option_Registry::ACTIVE_DAYS ];
		}

		$iter_limit   = 30; // Don't look further than 30 days ahead
		$candidate_ts = $now_ts;

		for ( $i = 0; $i < $iter_limit; $i++ ) {
			$day_str   = Plugin_Time::site_day_of_week( $candidate_ts );
			$ymd_local = Plugin_Time::site_date_str( $candidate_ts );

			// 1. Is it an active day?
			if ( ! \in_array( $day_str, $active_days, true ) ) {
				$candidate_ts = Plugin_Time::next_site_midnight_utc_ts( $candidate_ts );
				continue;
			}

			// 2. Window Bounds for this day
			$start_ts = Plugin_Time::site_hhmm_to_utc_ts( $ymd_local, $start_hhmm );
			$end_ts   = Plugin_Time::site_hhmm_to_utc_ts( $ymd_local, $end_hhmm );

			// If "now" is past today's window, move to next day
			if ( $candidate_ts > $end_ts ) {
				$candidate_ts = Plugin_Time::next_site_midnight_utc_ts( $candidate_ts );
				continue;
			}

			// Adjust start to "now" if we are already inside the window
			$effective_start = \max( $start_ts, $candidate_ts );

			// 3. Quota / Collision Check — moved inside lock for atomicity with transient reservations
			$slot_key      = 'seo_gen_publish_cascade_' . $ymd_local;
			$slot_count_key = 'seo_gen_publish_cascade_count_' . $ymd_local;
			$lock_key       = 'seo_gen_publish_cascade_lock_' . $ymd_local;
			$lock_acquired  = 1 === (int) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 5)', $lock_key ) );

			if ( ! $lock_acquired ) {
				// Another process is calculating; read the reserved slot from transient.
				$last_ts = (int) \get_transient( $slot_key );
				if ( $last_ts < 1 ) {
					$last_ts = $this->get_last_scheduled_timestamp_for_day( $ymd_local );
				}

				// Non-lock path: check if adding this post would exceed daily limit
				// using reservation count transient for accuracy
				$db_count = $this->get_scheduled_new_post_count_for_day( $ymd_local );
				$reserved_count = (int) \get_transient( $slot_count_key );
				if ( ( $db_count + $reserved_count ) >= $max_daily ) {
					$candidate_ts = Plugin_Time::next_site_midnight_utc_ts( $candidate_ts );
					continue;
				}
			} else {
				// Inside lock: count committed posts + in-flight reservations
				$db_count = $this->get_scheduled_new_post_count_for_day( $ymd_local );
				$reserved_count = (int) \get_transient( $slot_count_key );
				if ( ( $db_count + $reserved_count ) >= $max_daily ) {
					$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock_key ) );
					$candidate_ts = Plugin_Time::next_site_midnight_utc_ts( $candidate_ts );
					continue;
				}

				$transient_ts = (int) \get_transient( $slot_key );
				$last_ts = $this->get_last_scheduled_timestamp_for_day( $ymd_local );
				if ( $last_ts < 1 ) {
					$last_ts = $transient_ts;
				}
			}

			// Gap logic — for NEW posts, use publish interval settings
			$gap_min        = \max( 1, (int) \get_option( \SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MIN, $defaults[ \SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MIN ] ) );
			$gap_max        = \max( $gap_min, (int) \get_option( \SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MAX, $defaults[ \SEO_Article_Generator\Option_Registry::PUBLISH_INTERVAL_MAX ] ) );
			$random_gap_sec = \rand( $gap_min * 60, $gap_max * 60 );

			$final_ts = \max( $effective_start + $random_gap_sec, $last_ts + $random_gap_sec );

			// [PUBLISHING HARDENING] Add 1-5 second sub-jitter to prevent clumping in high-speed batches
			$final_ts += \rand( 1, 5 );

			// Persist for next caller — prevents race when batch finalization runs before
			// preceding items' wp_update_post has committed.
			if ( $lock_acquired ) {
				\set_transient( $slot_key, $final_ts, DAY_IN_SECONDS );
				// Increment reservation count for limit enforcement
				$new_count = (int) \get_transient( $slot_count_key ) + 1;
				\set_transient( $slot_count_key, $new_count, DAY_IN_SECONDS );
				$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock_key ) );
			}

			// Safety check: Don't push beyond the end of the window
			if ( $final_ts > $end_ts ) {
				\delete_transient( $slot_key );
				// Decrement reservation count since we're not using this slot
				if ( $lock_acquired ) {
					$new_count = max( 0, (int) \get_transient( $slot_count_key ) - 1 );
					\set_transient( $slot_count_key, $new_count, DAY_IN_SECONDS );
				}
				$candidate_ts = Plugin_Time::next_site_midnight_utc_ts( $candidate_ts );
				continue;
			}

			return $final_ts;
		}

		return $now_ts; // Fallback to now if we somehow loop too much
	}

	/**
	 * Count NEW posts scheduled (status=future) or published today in site timezone.
	 * Only counts posts that are NOT updates (i.e., discovery.existing_post_id = 0 or NULL).
	 */
	private function get_scheduled_new_post_count_for_day( string $ymd_local ): int {
		global $wpdb;
		$disc_table = Installer::table_discovery();

		// FIX: post_date is stored in site-local time, but we need to query using site-local date.
		// The LIKE query works because post_date is stored as 'Y-m-d H:i:s' in site time.
		// Only count NEW posts: join with discovery table and filter where existing_post_id = 0 or NULL
		$count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT p.ID)
				 FROM {$wpdb->posts} p
				 INNER JOIN {$wpdb->postmeta} pm
					 ON pm.post_id = p.ID
					AND pm.meta_key = 'seogenjobid'
				 LEFT JOIN {$disc_table} d
					 ON d.existing_post_id = p.ID
				 WHERE p.post_type = 'post'
				   AND p.post_status IN ('publish','future')
				   AND p.post_date >= %s
				   AND p.post_date < %s
				   AND (d.existing_post_id IS NULL OR d.existing_post_id = 0)",
				$ymd_local . ' 00:00:00',
				$ymd_local . ' 23:59:59'
			)
		);

		return (int) $count;
	}

	/**
	 * Count posts scheduled (status=future) or published today in site timezone.
	 * DEPRECATED: Use get_scheduled_new_post_count_for_day() for new posts.
	 * Kept for backward compatibility with get_last_scheduled_timestamp_for_day().
	 */
	private function get_scheduled_post_count_for_day( string $ymd_local ): int {
		return $this->get_scheduled_new_post_count_for_day( $ymd_local );
	}

	/**
	 * Get the timestamp of the last scheduled/published NEW post for a specific local day.
	 * Only counts posts that are NOT updates (i.e., discovery.existing_post_id = 0 or NULL).
	 */
	private function get_last_scheduled_timestamp_for_day( string $ymd ): int {
		global $wpdb;
		$disc_table = Installer::table_discovery();

		$last_date = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT MAX(p.post_date)
				 FROM {$wpdb->posts} p
				 INNER JOIN {$wpdb->postmeta} pm
					 ON pm.post_id = p.ID
					AND pm.meta_key = 'seogenjobid'
				 LEFT JOIN {$disc_table} d
					 ON d.existing_post_id = p.ID
				 WHERE p.post_type = 'post'
				   AND p.post_status IN ('publish', 'future')
				   AND p.post_date LIKE %s
				   AND (d.existing_post_id IS NULL OR d.existing_post_id = 0)",
				$ymd . '%'
			)
		);

		if ( ! $last_date ) {
			return 0;
		}

		return Plugin_Time::utc_ts_from_site_mysql( $last_date );
	}

	/**
	 * Get the latest update-slot timestamp reserved in the discovery table for a given local day.
	 *
	 * Unlike get_last_scheduled_timestamp_for_day() which queries wp_posts (used for NEW posts
	 * whose post_date is set), UPDATE posts keep their original post_date. This method queries
	 * the discovery table's scheduled_at column where deferred updates store their future slot.
	 *
	 * @param string $ymd_local  Site-local date string (YYYY-MM-DD).
	 * @return int                UTC timestamp of the latest reserved slot, or 0 if none.
	 */
	private function get_last_update_slot_ts_for_day( string $ymd_local ): int {
		global $wpdb;
		$table = Installer::table_discovery();

		// FIX: scheduled_at is stored in UTC, but we receive a site-local date.
		// Convert the site-local date range to UTC for proper comparison.
		$site_tz = \wp_timezone();
		$start_dt = new \DateTimeImmutable( $ymd_local . ' 00:00:00', $site_tz );
		$end_dt   = new \DateTimeImmutable( $ymd_local . ' 23:59:59', $site_tz );
		$start_utc = $start_dt->setTimezone( new \DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );
		$end_utc   = $end_dt->setTimezone( new \DateTimeZone( 'UTC' ) )->format( 'Y-m-d H:i:s' );

		$last_date = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT MAX(scheduled_at)
				 FROM {$table}
					 WHERE existing_post_id > 0
					   AND status IN ('generating', 'finalizing', 'deferred')
					   AND scheduled_at BETWEEN %s AND %s",
				$start_utc,
				$end_utc
			)
		);

		if ( ! $last_date ) {
			return 0;
		}

		return Plugin_Time::utc_ts_from_utc_mysql( $last_date );
	}

	/**
	 * Find the next available update slot for today, coordinating across all pending updates.
	 *
	 * Mirrors _calculate_scheduled_publish_date_inner() for NEW posts but adapted for the
	 * UPDATE path: queries the discovery table (not wp_posts), uses update-delay settings for
	 * the gap, and enforces seo_gen_updates_per_day.
	 *
	 * @param int $current_item_id  The discovery row ID of the item being finalized (excluded from queries).
	 * @return int                  UTC timestamp of the next available slot, or 0 if none today.
	 */
	private function get_next_update_slot_ts( int $current_item_id ): int {
		global $wpdb;
		$table = Installer::table_discovery();

		$now_ts = Plugin_Time::now_utc_ts();

		$defaults = \SEO_Article_Generator\Option_Registry::defaults();
		$enabled = (bool) \get_option( \SEO_Article_Generator\Option_Registry::ENABLE_SCHEDULING, $defaults[ \SEO_Article_Generator\Option_Registry::ENABLE_SCHEDULING ] );
		if ( ! $enabled ) {
			return 0;
		}

		$delay_min = max( 1, (int) \get_option( \SEO_Article_Generator\Option_Registry::UPDATE_DELAY_MIN, $defaults[ \SEO_Article_Generator\Option_Registry::UPDATE_DELAY_MIN ] ) );
		$delay_max = max( $delay_min, (int) \get_option( \SEO_Article_Generator\Option_Registry::UPDATE_DELAY_MAX, $defaults[ \SEO_Article_Generator\Option_Registry::UPDATE_DELAY_MAX ] ) );

		$start_hhmm = trim( (string) \get_option( \SEO_Article_Generator\Option_Registry::PUBLISH_START, $defaults[ \SEO_Article_Generator\Option_Registry::PUBLISH_START ] ) );
		$end_hhmm   = trim( (string) \get_option( \SEO_Article_Generator\Option_Registry::PUBLISH_END, $defaults[ \SEO_Article_Generator\Option_Registry::PUBLISH_END ] ) );
		if ( $start_hhmm === '' ) {
			$start_hhmm = $defaults[ \SEO_Article_Generator\Option_Registry::PUBLISH_START ];
		}
		if ( $end_hhmm === '' ) {
			$end_hhmm = $defaults[ \SEO_Article_Generator\Option_Registry::PUBLISH_END ];
		}

		$active_days = \get_option( \SEO_Article_Generator\Option_Registry::ACTIVE_DAYS, $defaults[ \SEO_Article_Generator\Option_Registry::ACTIVE_DAYS ] );
		if ( empty( $active_days ) || ! \is_array( $active_days ) ) {
			$active_days = $defaults[ \SEO_Article_Generator\Option_Registry::ACTIVE_DAYS ];
		}

		$max_updates = (int) \get_option( \SEO_Article_Generator\Option_Registry::UPDATES_PER_DAY, $defaults[ \SEO_Article_Generator\Option_Registry::UPDATES_PER_DAY ] );

		$ymd_local = Plugin_Time::site_date_str( $now_ts );
		$day_str   = Plugin_Time::site_day_of_week( $now_ts );

		if ( ! \in_array( $day_str, $active_days, true ) ) {
			return 0;
		}

		$start_ts = Plugin_Time::site_hhmm_to_utc_ts( $ymd_local, $start_hhmm );
		$end_ts   = Plugin_Time::site_hhmm_to_utc_ts( $ymd_local, $end_hhmm );

		if ( $now_ts > $end_ts ) {
			return 0;
		}

		$effective_start = \max( $start_ts, $now_ts );

		// FIX: Use atomic lock for slot reservation to prevent race conditions.
		// Multiple concurrent jobs must serialize slot calculation.
		$slot_key       = 'seo_gen_update_slot_' . $ymd_local;
		$slot_count_key = 'seo_gen_update_slot_count_' . $ymd_local;
		$lock_key       = 'seo_gen_update_slot_lock_' . $ymd_local;
		$lock_acquired  = 1 === (int) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 10)', $lock_key ) );

		if ( ! $lock_acquired ) {
			// Another process holds the slot lock. Read the latest reserved slot
			// from transient (or DB fallback) and apply the gap to avoid clumping.
			$reserved_ts = (int) \get_transient( $slot_key );
			if ( $reserved_ts < 1 ) {
				$reserved_ts = $this->get_last_update_slot_ts_for_day( $ymd_local );
			}

			// Non-lock path: check if adding this update would exceed daily limit
			$update_count = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(DISTINCT id)
					 FROM {$table}
					 WHERE id != %d
					   AND existing_post_id > 0
					   AND status IN ('generating', 'finalizing', 'deferred')
					   AND scheduled_at >= %s",
					$current_item_id,
					Plugin_Time::utc_mysql_from_utc_ts( $effective_start )
				)
			);
			$reserved_count = (int) \get_transient( $slot_count_key );
			if ( ( $update_count + $reserved_count ) >= $max_updates ) {
				return 0;
			}

			$random_gap_sec = \rand( $delay_min * 60, $delay_max * 60 );
			$base_ts = ( $reserved_ts > $now_ts ) ? $reserved_ts : $effective_start;
			$next_ts = \max( $base_ts + $random_gap_sec, $effective_start + $random_gap_sec );
			$next_ts += \rand( 1, 5 );
			if ( $next_ts <= $end_ts ) {
				return $next_ts;
			}
			return 0;
		}

		// CRITICAL FIX: Enforce updates-per-day cap (count pending + deferred updates for today).
		if ( $max_updates > 0 ) {
			$update_count = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(DISTINCT id)
					 FROM {$table}
					 WHERE id != %d
					   AND existing_post_id > 0
					   AND status IN ('generating', 'finalizing', 'deferred')
					   AND scheduled_at >= %s",
					$current_item_id,
					Plugin_Time::utc_mysql_from_utc_ts( $effective_start )
				)
			);
			$reserved_count = (int) \get_transient( $slot_count_key );
			if ( ( $update_count + $reserved_count ) >= $max_updates ) {
				$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock_key ) );
				return 0;
			}
		}

		// Find the latest reserved slot: first from DB, then from transient for in-flight items.
		$last_slot_ts = $this->get_last_update_slot_ts_for_day( $ymd_local );

		$slot_key     = 'seo_gen_update_slot_' . $ymd_local;
		$transient_ts = (int) \get_transient( $slot_key );
		if ( $transient_ts > $last_slot_ts ) {
			$last_slot_ts = $transient_ts;
		}

		// Apply gap using update-delay settings.
		$random_gap_sec = \rand( $delay_min * 60, $delay_max * 60 );

		$final_ts = \max( $effective_start + $random_gap_sec, $last_slot_ts + $random_gap_sec );

		// Sub-jitter to prevent clumping in high-speed batches.
		$final_ts += \rand( 1, 5 );

		if ( $final_ts > $end_ts ) {
			// Decrement reservation count since we're not using this slot
			$new_count = max( 0, (int) \get_transient( $slot_count_key ) - 1 );
			\set_transient( $slot_count_key, $new_count, DAY_IN_SECONDS );
			$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock_key ) );
			return 0;
		}

		// ATOMIC RESERVATION: Reserve this slot so the next concurrent caller sees it.
		\set_transient( $slot_key, $final_ts, DAY_IN_SECONDS );
		// Increment reservation count for limit enforcement
		$new_count = (int) \get_transient( $slot_count_key ) + 1;
		\set_transient( $slot_count_key, $new_count, DAY_IN_SECONDS );
		$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock_key ) );

		return $final_ts;
	}

	public function sideload_featured_image( int $pid, string $iurl, string $lurl, int $did, int $uid ): void {
		// FINDING-5 FIX: Guard against duplicate media entries on recovery re-runs.
		if ( \has_post_thumbnail( $pid ) ) {
			$this->logger->info(
				sprintf(
					'Sideload skipped for Post %d (Discovery %d): post already has a featured image.',
					$pid,
					$did
				)
			);
			return;
		}

		$prior_fail_time = (int) \get_post_meta( $pid, '_seo_gen_image_sideload_failed', true );
		$is_retry_run    = $prior_fail_time > 0;

		$candidates = array_filter( array( $iurl, $lurl ) );
		foreach ( $candidates as $url ) {
			try {
				$iid = \SEO_Article_Generator\Integration\WP_Automatic_Bridge::sideload_image( $url, $pid );
				if ( $iid && ! \is_wp_error( $iid ) ) {
					\set_post_thumbnail( $pid, $iid );
					$thumb_url_sideload = \wp_get_attachment_image_url( $iid, 'full' );
					if ( $thumb_url_sideload ) {
						$herodata_sideload = \get_post_meta( $pid, 'seogenherodata', true );
						if ( is_array( $herodata_sideload ) && empty( $herodata_sideload['logo_url'] ) ) {
							$herodata_sideload['logo_url'] = $thumb_url_sideload;
							\SEO_Article_Generator\Plugin::get_instance()->write_hero_data( $pid, $herodata_sideload );
						}
					}
					\delete_post_meta( $pid, '_seo_gen_image_sideload_failed' );
					$this->logger->info( sprintf( 'Sideload SUCCESS for Post %d from %s', $pid, $url ) );
					return;
				}
				$this->logger->warning( sprintf( 'Sideload attempt failed for Post %d URL %s — trying fallback.', $pid, $url ) );
			} catch ( \Throwable $e ) {
				$this->logger->error( sprintf( 'Sideload exception for Post %d URL %s: %s', $pid, $url, $e->getMessage() ) );
			}
		}
		$this->logger->error( sprintf( 'Sideload FAILED for Post %d (Discovery %d): all candidate URLs exhausted.', $pid, $did ) );
		\update_post_meta( $pid, '_seo_gen_image_sideload_failed', time() );

		if ( ! $is_retry_run ) {
			$this->schedule_featured_image_sideload( $pid, $iurl, $lurl, $did, $uid, 1 );
		} else {
			$this->logger->warning(
				sprintf(
					'Sideload permanently skipped Post %d Discovery %d — retry also failed. Manual intervention required.',
					$pid,
					$did
				)
			);
		}
	}

	public function get_item( int $id, array $f = array() ) {
		global $wpdb;
		$s = empty( $f ) ? '*' : implode( ', ', array_map( 'sanitize_key', $f ) );
		return $wpdb->get_row( $wpdb->prepare( "SELECT {$s} FROM " . Installer::table_discovery() . ' WHERE id = %d', $id ) );
	}

	/**
	 * FIX D2 (2026-09-06): SSOT for the effective-poll transient lifecycle.
	 * Must be cleared on every terminal write and every fresh budget cycle, or
	 * manual Retry instantly re-times-out for 24h (retry poisoning).
	 */
	private function clear_effective_poll_count( int $discovery_id ): void {
		\delete_transient( 'seo_gen_effective_poll_' . (int) $discovery_id );
		\delete_transient( 'seo_gen_passive_wait_since_' . (int) $discovery_id );
	}

	/**
	 * FIX C2 (2026-09-06): narrow public wrapper so Overdue Recovery routes
	 * failures through the mark_discovery_failure SSOT (AS cancel, last_job_id,
	 * draft re-schedule, cache invalidate, transient clear).
	 */
	public function fail_item_from_recovery( int $discovery_id, string $reason ): bool {
		return $this->mark_discovery_failure( $discovery_id, 'failed', $reason );
	}

	private function mark_discovery_failure( int $id, string $status, string $message, bool $count_breaker = true ): bool {
		global $wpdb;

		// Cancel AS actions before writing so no new polls fire for this row.
		AS_Registry::cancel_item_actions( $id );

		// Guard: never demote a 'done' row to failed — finalization wins.
		// Allow 'finalizing' to be demoted — otherwise exception-during-finalize leaves rows stuck forever.
		$current_status = (string) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT status FROM ' . Installer::table_discovery() . ' WHERE id = %d',
				$id
			)
		);

		// FIX D2 (2026-09-06): every terminal write clears the budget transients.
		$this->clear_effective_poll_count( (int) $id );

		// FIX G2 (2026-09-06): idempotent terminal writes — a row already in the
		// same terminal state keeps its FIRST failure (original cause). Stops the
		// 09-05 churn (1129 repeated timeout re-marks) and repeated draft
		// re-schedules from stale poll chains.
		if ( $current_status === $status && \in_array( $status, array( 'failed', 'timeout' ), true ) ) {
			return true;
		}

		if ( $current_status === 'done' ) {
			$this->logger->warning(
				sprintf(
					'mark_discovery_failure suppressed for Discovery %d — current status is "%s". Failure reason: %s',
					$id,
					$current_status,
					$message
				)
			);
				return false;
		}

		// Preserve job_id as last_job_id before nulling, so retry_item can
		// trace the identity chain and check liveness of the previous job.
		$current_job_id = (int) $wpdb->get_var(
			$wpdb->prepare(
				'SELECT job_id FROM ' . Installer::table_discovery() . ' WHERE id = %d',
				$id
			)
		);

		// CRITICAL FIX: Before marking failure, capture the draft_post_id and source_type
		// for WP-Auto draft deletion re-scheduling. The deletion was cancelled earlier in
		// process_item_background() and must be re-scheduled on ANY failure path.
		$draft_meta    = $wpdb->get_row(
			$wpdb->prepare(
				'SELECT draft_post_id, source_type, consecutive_failures FROM ' . Installer::table_discovery() . ' WHERE id = %d',
				$id
			)
		);
		$draft_post_id = ! empty( $draft_meta ) ? (int) $draft_meta->draft_post_id : 0;
		$source_type   = ! empty( $draft_meta ) ? (string) $draft_meta->source_type : '';
		// FIX F4: consecutive-failure count for the circuit breaker (capped; reset on done/manual retry).
		$prev_failures = ! empty( $draft_meta ) ? (int) ( $draft_meta->consecutive_failures ?? 0 ) : 0;
		$new_failures  = $count_breaker ? min( $prev_failures + 1, 99 ) : $prev_failures;

		$update_data   = array(
			self::COL_STATUS        => $status,
			self::COL_ERROR_MESSAGE => $message,
			self::COL_SCHEDULED_AT  => null,
			self::COL_HEARTBEAT_AT  => null,
			self::COL_COMPLETED_AT  => Plugin_Time::utc_mysql_now(),
			self::COL_JOB_ID        => null,
			self::COL_QUEUE_JOB_ID  => null,
		);
		$update_format = array( '%s', '%s', '%s', '%s', '%s', '%d', '%d' );

		if ( $count_breaker ) {
			$update_data[ self::COL_CONSECUTIVE_FAILURES ] = $new_failures;
			$update_data[ self::COL_LAST_FAILURE_AT ]      = Plugin_Time::utc_mysql_now();
			$update_format[] = '%d';
			$update_format[] = '%s';
		}

		if ( $current_job_id > 0 ) {
			$update_data['last_job_id'] = $current_job_id;
			$update_format[]            = '%d';
		}

		$result = (bool) $wpdb->update(
			Installer::table_discovery(),
			$update_data,
			array( 'id' => $id ),
			$update_format,
			array( '%d' )
		);

		$this->invalidate_dashboard_caches();

		// FIX G (2026-09-06): terminal failures were invisible in logs (09-05 had
		// zero timeout lines for 1129 timeout writes) — log every terminal write.
		$this->logger->warning(
			sprintf(
				'Discovery %d marked %s: %s (previous job %d, failures=%d, persisted=%s).',
				(int) $id,
				(string) $status,
				(string) $message,
				(int) $current_job_id,
				(int) $new_failures,
				$result ? 'yes' : 'no'
			)
		);

		// Re-schedule draft deletion for WP-Auto items. The deletion was cancelled
		// in process_item_background() and must be re-instated now that the item has
		// reached a terminal failed state.
		if ( $draft_post_id > 0 && $source_type === 'wp_automatic' && \get_post( $draft_post_id ) ) {
			\SEO_Article_Generator\Discovery\Discovery_Engine::schedule_draft_deletion( $draft_post_id );
			$this->logger->info(
				sprintf(
					'Discovery %d: draft deletion re-scheduled for draft %d after failure (%s).',
					$id,
					$draft_post_id,
					$status
				)
			);
		}

		return $result;
	}

	/**
	 * Dismiss a discovery item and immediately delete its draft post + media.
	 *
	 * Used for:
	 * - "No downloadable links" pre-flight abort (zero retry)
	 * - Deterministic failures after retry exhaustion (1 retry then dismiss)
	 *
	 * Follows the existing delete_draft_post() pattern for attachment reparenting
	 * and orphan cleanup. Sets status to 'ignored' so the item does not appear
	 * in the Failed tab.
	 *
	 * @param int $id Discovery ID.
	 * @return bool True on success.
	 */
	public function dismiss_and_cleanup_source( int $id ): bool {
		global $wpdb;

		$table = Installer::table_discovery();

		$item = $this->get_item( $id, array( 'id', 'status', 'draft_post_id', 'source_type', 'error_message' ) );
		if ( ! $item ) {
			return false;
		}

		// Guard: never overwrite a 'done' row.
		$current_status = (string) $wpdb->get_var(
			$wpdb->prepare( 'SELECT status FROM ' . $table . ' WHERE id = %d', $id )
		);
		if ( $current_status === 'done' || $current_status === 'ignored' ) {
			$this->logger->warning(
				sprintf( 'dismiss_and_cleanup_source suppressed for Discovery %d — status is "%s".', $id, $current_status )
			);
			return false;
		}

		$draft_post_id = (int) ( $item->draft_post_id ?? 0 );
		$source_type   = (string) ( $item->source_type ?? '' );
		$error_message = (string) ( $item->error_message ?? '' );

		\delete_transient( 'seo_gen_sentinel_retry_' . $id );

		// FIX D2 (2026-09-06): terminal dismiss clears the budget transients.
		$this->clear_effective_poll_count( (int) $id );

		// 1. Cancel any pending AS actions.
		AS_Registry::cancel_item_actions( $id );

		// 2. Mark discovery as 'ignored' (removed from Failed tab).
		$wpdb->update(
			$table,
			array(
				self::COL_STATUS        => 'ignored',
				self::COL_COMPLETED_AT  => Plugin_Time::utc_mysql_now(),
				self::COL_SCHEDULED_AT  => null,
				self::COL_HEARTBEAT_AT  => null,
				self::COL_JOB_ID        => null,
				self::COL_QUEUE_JOB_ID  => null,
			),
			array( 'id' => $id ),
			array( '%s', '%s', '%s', '%s', '%d', '%d' ),
			array( '%d' )
		);

		// 3. Delete the draft post + its attachments immediately WITH PROPER REPARENTING.
		// Uses Discovery_Engine::delete_draft_post_static() which reparents featured images
		// used by published posts instead of deleting them (bug fix for data loss).
		if ( $draft_post_id > 0 && \get_post( $draft_post_id ) ) {
			\SEO_Article_Generator\Discovery\Discovery_Engine::delete_draft_post_static( $draft_post_id );
			$this->logger->info( sprintf(
				'[AUDIT] Discovery %d: draft %d deleted immediately via dismiss_and_cleanup_source (with reparenting).',
				$id,
				$draft_post_id
			) );
		}

		$this->invalidate_dashboard_caches();

		$this->logger->info( sprintf(
			'[AUDIT] Discovery %d dismissed and source cleaned up. Draft=%d, source_type=%s, reason=%s',
			$id,
			$draft_post_id,
			$source_type,
			$error_message
		) );

		return true;
	}

	public function claim_item_for_finalization( int $discovery_id, int $job_id, bool $allow_failed_recovery = false ): ?object {
		global $wpdb;

		$table      = Installer::table_discovery();
		$jobs_table = Installer::table_jobs();

		$expected_queue_job_id = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT queue_job_id FROM {$jobs_table} WHERE id = %d",
				$job_id
			)
		);

		$claimable_statuses = $allow_failed_recovery
			? array( 'queued', 'processing', 'generating', 'failed', 'timeout', 'finalizing', 'deferred' )
			: array( 'queued', 'processing', 'generating', 'finalizing', 'deferred' );

		$status_sql = "'" . implode( "','", array_map( 'esc_sql', $claimable_statuses ) ) . "'";

		/*
		 * Primary strict claim path.
		 * Prefer exact discovery id + job id match.
		 * Only use queuejobid as a fallback identity when it is a real non-zero value.
		 */
		if ( $expected_queue_job_id > 0 ) {
			$claimed = $wpdb->query(
				$wpdb->prepare(
					"UPDATE {$table}
					 SET status = 'finalizing',
					     heartbeat_at = %s,
					     scheduled_at = NULL,
					     error_message = NULL
					 WHERE id = %d
					   AND status IN ({$status_sql})
					   AND (
					        job_id = %d
					        OR (job_id = 0 AND queue_job_id = %d)
					   )",
					Plugin_Time::utc_mysql_now(),
					$discovery_id,
					$job_id,
					$expected_queue_job_id
				)
			);
		} else {
			$claimed = $wpdb->query(
				$wpdb->prepare(
					"UPDATE {$table}
					 SET status = 'finalizing',
					     heartbeat_at = %s,
					     scheduled_at = NULL,
					     error_message = NULL
					 WHERE id = %d
					   AND status IN ({$status_sql})
					   AND job_id = %d",
					Plugin_Time::utc_mysql_now(),
					$discovery_id,
					$job_id
				)
			);
		}

		if ( (int) $claimed === 1 ) {
			AS_Registry::cancel_item_actions( $discovery_id );
			return $this->get_item( $discovery_id );
		}

		/*
		 * Recovery path:
		 * if the row is still generating/processing and already belongs to this job,
		 * queuejob drift must not block finalization.
		 * Lock the row, verify ownership from DB, then promote to finalizing.
		 */
		$wpdb->query( 'START TRANSACTION' );
		try {
			$fresh = $wpdb->get_row(
				$wpdb->prepare(
					'SELECT id, status, job_id, queue_job_id, type, existing_post_id
					 FROM ' . $table . '
					 WHERE id = %d FOR UPDATE',
					$discovery_id
				),
				ARRAY_A
			);

			if ( ! $fresh ) {
				$wpdb->query( 'ROLLBACK' );
				$this->logger->error(
					'Discovery ' . (int) $discovery_id . ': finalization claim failed — row missing.',
					array(
						'job_id'                => (int) $job_id,
						'expected_queue_job_id' => (int) $expected_queue_job_id,
					)
				);
				return null;
			}

			$fresh_status        = (string) ( $fresh['status'] ?? '' );
			$fresh_job_id        = (int) ( $fresh['job_id'] ?? 0 );
			$fresh_queue_job_id  = (int) ( $fresh['queue_job_id'] ?? 0 );
			$fresh_type          = (string) ( $fresh['type'] ?? '' );
			$fresh_existing_post = (int) ( $fresh['existing_post_id'] ?? 0 );

			// === CONTRACT REPAIR inside the lock — before any finalizing write ===
			$claim_contract = Discovery_Engine::canonicalize_discovery_contract(
				$fresh_type,
				$fresh_existing_post
			);

			$contract_dirty = (
				$fresh_type !== $claim_contract['type'] ||
				$fresh_existing_post !== (int) $claim_contract['existing_post_id']
			);

			if ( $contract_dirty ) {
				$wpdb->update(
					$table,
					array(
						'type'                     => $claim_contract['type'],
						self::COL_EXISTING_POST_ID => (int) $claim_contract['existing_post_id'],
					),
					array( 'id' => $discovery_id ),
					array( '%s', '%d' ),
					array( '%d' )
				);
				$this->logger->warning(
					'claim_item_for_finalization repaired discovery contract under lock.',
					array(
						'discovery_id'  => (int) $discovery_id,
						'resolved_type' => $claim_contract['type'],
						'resolved_post' => (int) $claim_contract['existing_post_id'],
						'prior_type'    => $fresh_type,
						'prior_post'    => $fresh_existing_post,
					)
				);
				$fresh_type          = $claim_contract['type'];
				$fresh_existing_post = (int) $claim_contract['existing_post_id'];
			}
			// === END CONTRACT REPAIR ===

			$status_allowed         = in_array( $fresh_status, $claimable_statuses, true );
			$job_matches            = ( $fresh_job_id === (int) $job_id );
			$queue_fallback_matches = (
				$fresh_job_id === 0
				&& $expected_queue_job_id > 0
				&& $fresh_queue_job_id === $expected_queue_job_id
			);

			if ( $status_allowed && ( $job_matches || $queue_fallback_matches ) ) {
				$updated = $wpdb->update(
					$table,
					array(
						'status'        => 'finalizing',
						'heartbeat_at'  => Plugin_Time::utc_mysql_now(),
						'scheduled_at'  => null,
						'error_message' => null,
						'job_id'        => $job_matches ? $fresh_job_id : $job_id,
						'queue_job_id'  => $expected_queue_job_id > 0
													? $expected_queue_job_id
													: $fresh_queue_job_id,
					),
					array( 'id' => $discovery_id ),
					array( '%s', '%s', '%s', '%s', '%d', '%d' ),
					array( '%d' )
				);

				if ( $updated !== false ) {
					$wpdb->query( 'COMMIT' );
					AS_Registry::cancel_item_actions( $discovery_id );
					$this->logger->warning(
						'Discovery ' . (int) $discovery_id . ': finalization claim recovered via locked re-read.',
						array(
							'job_id'                => (int) $job_id,
							'expected_queue_job_id' => (int) $expected_queue_job_id,
							'fresh_status'          => $fresh_status,
							'fresh_job_id'          => $fresh_job_id,
							'fresh_queue_job_id'    => $fresh_queue_job_id,
						)
					);
					return $this->get_item( $discovery_id );
				}
			}

			$wpdb->query( 'ROLLBACK' );

			if ( $allow_failed_recovery && $fresh_status === 'failed' ) {
				$claimed_failed = $wpdb->query(
					$wpdb->prepare(
						'UPDATE ' . $table . '
						 SET status = \'finalizing\', heartbeat_at = %s, scheduled_at = NULL, error_message = NULL
						 WHERE id = %d AND job_id = %d AND status = \'failed\'',
						Plugin_Time::utc_mysql_now(),
						$discovery_id,
						$job_id
					)
				);
				if ( (int) $claimed_failed === 1 ) {
					AS_Registry::cancel_item_actions( $discovery_id );
					return $this->get_item( $discovery_id );
				}
			}

			if ( in_array( $fresh_status, array( 'finalizing', 'done' ), true ) ) {
				$this->logger->info(
					'Discovery ' . (int) $discovery_id . ': finalization claim skipped — already ' . $fresh_status . '.',
					array(
						'job_id'                => (int) $job_id,
						'expected_queue_job_id' => (int) $expected_queue_job_id,
					)
				);
			} else {
				$this->logger->error(
					'Discovery ' . (int) $discovery_id . ': finalization claim failed unexpectedly — current status: ' . $fresh_status . '.',
					array(
						'job_id'                => (int) $job_id,
						'expected_queue_job_id' => (int) $expected_queue_job_id,
						'fresh_job_id'          => $fresh_job_id,
						'fresh_queue_job_id'    => $fresh_queue_job_id,
					)
				);
			}
			return null;

		} catch ( \Exception $e ) {
			$wpdb->query( 'ROLLBACK' );
			$this->logger->error(
				'Discovery ' . (int) $discovery_id . ': finalization claim lock path failed — ' . $e->getMessage(),
				array(
					'job_id'                => (int) $job_id,
					'expected_queue_job_id' => (int) $expected_queue_job_id,
				)
			);
			return null;
		}
	}

	private function get_regen_sections_snapshot( int $pid ): array {
		$raw = \get_post_meta( $pid, '_seo_gen_regen_sections', true );

		if ( $raw === '' || $raw === null ) {
			$raw = \get_post_meta( $pid, 'seogenregensections', true );
		}

		if ( \is_array( $raw ) ) {
			return array_values( $raw );
		}

		if ( \is_string( $raw ) && $raw !== '' ) {
			$decoded = json_decode( $raw, true );
			if ( \is_array( $decoded ) ) {
				return array_values( $decoded );
			}
		}

		return array();
	}

	private function persist_regen_sections_snapshot( int $pid ): void {
		// FIX F2 (Phase 3A): freeze the CURRENT global scope at run start.
		// No producer of per-post custom scopes exists, so any stored value is a
		// stale global — always re-freeze. Called from approve/run-now (run start);
		// retry deliberately does NOT re-persist (it resumes the frozen scope).
		$global_sections = $this->get_update_sections();
		$json            = \wp_json_encode( $global_sections );

		\update_post_meta( $pid, '_seo_gen_regen_sections', $json );
		\update_post_meta( $pid, 'seogenregensections', $json );

		$this->logger->info(
			sprintf(
				'persist_regen_sections_snapshot: Post %d scope frozen to current global (%d sections).',
				$pid,
				count( (array) $global_sections )
			)
		);
	}

	public function invalidate_dashboard_caches(): void {
		\delete_transient( 'seo_gen_dashboard_stats' );
		\delete_transient( 'seo_gen_as_queue_count' );
		// FINDING-12 FIX (existing)
		\delete_transient( 'seo_gen_dashboard_snapshot_' . \get_current_blog_id() );
		// NEW: flush scanner controls cache so discovery toggle/provider block changes
		// are immediately visible without waiting 30 seconds for TTL expiry.
		\delete_transient( 'seo_gen_scanner_snap_' . \get_current_blog_id() );
	}

	/**
	 * Get terminal retention days from config or filter.
	 *
	 * @return int
	 */
	private function get_terminal_retention_days(): int {
		$days = (int) \apply_filters( 'seo_gen_discovery_terminal_retention_days', 60 );
		return \max( 1, $days );
	}

	/**
	 * Purge old discovery records (terminal states > days)
	 *
	 * @param int $days Retention period in days (0 = use config)
	 * @return int Number of rows deleted
	 */
	public function purge_old_items( $days = 0 ) {
		$days = $days > 0 ? (int) $days : $this->get_terminal_retention_days();

		global $wpdb;
		$table  = Installer::table_discovery();
		$cutoff = Plugin_Time::utc_mysql_from_utc_ts(
			Plugin_Time::now_utc_ts() - ( $days * DAY_IN_SECONDS )
		);

		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT id
				 FROM {$table}
			 WHERE status IN ('failed', 'timeout', 'skippednotnewer', 'skippedduplicate', 'ignored')
			   AND (
			        completed_at <= %s
			        OR (completed_at IS NULL AND discovered_at <= %s)
			   )",
			$cutoff,
			$cutoff
		)
	);

	if ( empty( $ids ) ) {
		return 0;
	}

	foreach ( $ids as $id ) {
			\SEO_Article_Generator\Queue\AS_Registry::cancel_item_actions( (int) $id );
	}

	$id_list = implode( ',', array_map( 'intval', $ids ) );
	return (int) $wpdb->query( "DELETE FROM {$table} WHERE id IN ($id_list)" );
	}

		/**
	* REMOVED: Post-publish internal link injection path.
	* Internal links are now injected exclusively by ArticleGenerator::inject_internal_links()
	* during the AI generation pass.
	*/

}