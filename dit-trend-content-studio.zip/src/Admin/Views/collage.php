<?php

/**
 * Collage Maker Admin View
 *
 * @package DIT_TrendStudio
 * @version 3.1.0
 */
defined('ABSPATH') || exit;
?>
<div class="wrap">
    <h1><?php esc_html_e('Collage Maker', 'dit-trend-studio'); ?></h1>

    <div class="dit-ts-collage-container">

        <!-- ═══════════════════ LEFT: CONTROLS ═══════════════════ -->
        <div class="dit-ts-collage-sidebar">

            <!-- Template -->
            <div class="dit-ts-card">
                <h3><?php esc_html_e('Template', 'dit-trend-studio'); ?></h3>
                <div class="dit-ts-form-group">
                    <label for="dit-ts-template"><?php esc_html_e('Layout Mode', 'dit-trend-studio'); ?></label>
                    <select id="dit-ts-template" class="widefat">
                        <option value="split_card"><?php esc_html_e('Split Card (Canvas – Live Preview)', 'dit-trend-studio'); ?></option>
                        <option value="grid"><?php esc_html_e('Grid Collage (Server-side)', 'dit-trend-studio'); ?></option>
                    </select>
                </div>
            </div>

            <!-- Images — zoom + swap added per-item by JS -->
            <div class="dit-ts-card">
                <h3><?php esc_html_e('Images', 'dit-trend-studio'); ?></h3>
                <div id="dit-ts-image-list" class="dit-ts-image-list">
                    <p class="dit-ts-empty-state"><?php esc_html_e('No images added yet.', 'dit-trend-studio'); ?></p>
                </div>
                <button type="button" id="dit-ts-add-images" class="button button-secondary">
                    <span class="dashicons dashicons-plus-alt2"></span>
                    <?php esc_html_e('Add Images', 'dit-trend-studio'); ?>
                </button>
                <p class="description dit-ts-split-only"><?php esc_html_e('Split Card: 2–3 images. Drag to reorder. Use zoom slider per image.', 'dit-trend-studio'); ?></p>
                <p class="description dit-ts-grid-only"><?php esc_html_e('Grid: up to 6 images. Drag to reorder. Zoom and swap per image.', 'dit-trend-studio'); ?></p>
            </div>

            <!-- ═══ GRID ONLY ═══ -->

            <!-- Grid: Layout -->
            <div class="dit-ts-card dit-ts-grid-only">
                <h3><?php esc_html_e('Grid Layout', 'dit-trend-studio'); ?></h3>
                <div class="dit-ts-form-row">
                    <div class="dit-ts-form-group">
                        <label for="dit-ts-grid-image-count"><?php esc_html_e('Image Count', 'dit-trend-studio'); ?></label>
                        <select id="dit-ts-grid-image-count" class="widefat">
                            <option value="1"><?php esc_html_e('1 Image', 'dit-trend-studio'); ?></option>
                            <option value="2"><?php esc_html_e('2 Images', 'dit-trend-studio'); ?></option>
                            <option value="3"><?php esc_html_e('3 Images', 'dit-trend-studio'); ?></option>
                            <option value="4"><?php esc_html_e('4 Images', 'dit-trend-studio'); ?></option>
                            <option value="5"><?php esc_html_e('5 Images', 'dit-trend-studio'); ?></option>
                            <option value="6" selected><?php esc_html_e('6 Images', 'dit-trend-studio'); ?></option>
                        </select>
                    </div>
                    <div class="dit-ts-form-group">
                        <label for="dit-ts-grid-layout"><?php esc_html_e('Layout Style', 'dit-trend-studio'); ?></label>
                        <select id="dit-ts-grid-layout" class="widefat"></select>
                    </div>
                </div>
                <div class="dit-ts-form-row">
                    <div class="dit-ts-form-group">
                        <label for="dit-ts-aspect-ratio"><?php esc_html_e('Aspect Ratio', 'dit-trend-studio'); ?></label>
                        <select id="dit-ts-aspect-ratio" class="widefat">
                            <option value="1:1" selected><?php esc_html_e('1:1 Square', 'dit-trend-studio'); ?></option>
                            <option value="16:9"><?php esc_html_e('16:9 Landscape', 'dit-trend-studio'); ?></option>
                            <option value="9:16"><?php esc_html_e('9:16 Portrait', 'dit-trend-studio'); ?></option>
                            <option value="4:3"><?php esc_html_e('4:3', 'dit-trend-studio'); ?></option>
                            <option value="legacy"><?php esc_html_e('Legacy (700×412)', 'dit-trend-studio'); ?></option>
                            <option value="custom"><?php esc_html_e('Custom…', 'dit-trend-studio'); ?></option>
                        </select>
                    </div>
                    <div class="dit-ts-form-group">
                        <label for="dit-ts-corner-radius"><?php esc_html_e('Corner Radius', 'dit-trend-studio'); ?></label>
                        <div class="dit-ts-control">
                            <div class="dit-ts-inline">
                                <input type="range" id="dit-ts-corner-radius" min="0" max="60" value="0" step="2">
                                <span id="dit-ts-corner-radius-val">0</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="dit-ts-custom-dims" class="dit-ts-form-row hidden">
                    <div class="dit-ts-form-group">
                        <label for="dit-ts-custom-width"><?php esc_html_e('Width (px)', 'dit-trend-studio'); ?></label>
                        <input type="number" id="dit-ts-custom-width" class="widefat" value="1080" min="400" max="4000" step="10">
                    </div>
                    <div class="dit-ts-form-group">
                        <label for="dit-ts-custom-height"><?php esc_html_e('Height (px)', 'dit-trend-studio'); ?></label>
                        <input type="number" id="dit-ts-custom-height" class="widefat" value="1080" min="400" max="4000" step="10">
                    </div>
                </div>
            </div>

            <!-- Grid: Typography -->
            <div class="dit-ts-card dit-ts-grid-only">
                <h3><?php esc_html_e('Typography', 'dit-trend-studio'); ?></h3>
                <div class="dit-ts-form-group">
                    <label for="dit-ts-grid-font"><?php esc_html_e('Font (server-side TTF)', 'dit-trend-studio'); ?></label>
                    <select id="dit-ts-grid-font" class="widefat">
                        <option value=""><?php esc_html_e('— System Default —', 'dit-trend-studio'); ?></option>
                    </select>
                    <!-- Live font preview -->
                    <div id="dit-ts-font-preview-grid" class="dit-ts-font-preview-box">
                        <span class="dit-ts-fp-latin">Aa Bb Cc 123</span>
                        <span class="dit-ts-fp-urdu" dir="rtl">اب پ تھ ایک دو</span>
                    </div>
                </div>
                <div class="dit-ts-form-row">
                    <div class="dit-ts-form-group">
                        <label for="dit-ts-grid-font-size"><?php esc_html_e('Font Size (px)', 'dit-trend-studio'); ?></label>
                        <div class="dit-ts-control">
                            <div class="dit-ts-inline">
                                <input type="range" id="dit-ts-grid-font-size" min="14" max="72" value="24" step="1">
                                <span id="dit-ts-grid-font-size-val">24</span>
                            </div>
                        </div>
                    </div>
                    <div class="dit-ts-form-group">
                        <label for="dit-ts-letter-spacing"><?php esc_html_e('Letter Spacing', 'dit-trend-studio'); ?></label>
                        <div class="dit-ts-control">
                            <div class="dit-ts-inline">
                                <input type="range" id="dit-ts-letter-spacing" min="0" max="30" value="10" step="1">
                                <span id="dit-ts-letter-spacing-val">10</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="dit-ts-form-row">
                    <div class="dit-ts-form-group">
                        <label for="dit-ts-text-align"><?php esc_html_e('Alignment', 'dit-trend-studio'); ?></label>
                        <select id="dit-ts-text-align" class="widefat">
                            <option value="center" selected><?php esc_html_e('Center', 'dit-trend-studio'); ?></option>
                            <option value="left"><?php esc_html_e('Left', 'dit-trend-studio'); ?></option>
                            <option value="right"><?php esc_html_e('Right', 'dit-trend-studio'); ?></option>
                        </select>
                    </div>
                    <div class="dit-ts-form-group">
                        <label for="dit-ts-grid-line-height"><?php esc_html_e('Line Height', 'dit-trend-studio'); ?></label>
                        <div class="dit-ts-control">
                            <div class="dit-ts-inline">
                                <input type="range" id="dit-ts-grid-line-height" min="1.0" max="2.5" value="1.2" step="0.1">
                                <span id="dit-ts-grid-line-height-val">1.2</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Grid: Style -->
            <div class="dit-ts-card dit-ts-grid-only">
                <h3><?php esc_html_e('Style', 'dit-trend-studio'); ?></h3>
                <div class="dit-ts-form-row">
                    <div class="dit-ts-form-group">
                        <label for="dit-ts-border-color"><?php esc_html_e('Border / Gap Color', 'dit-trend-studio'); ?></label>
                        <input type="color" id="dit-ts-border-color" class="dit-ts-color-picker" value="#000000">
                    </div>
                    <div class="dit-ts-form-group">
                        <label for="dit-ts-blur-intensity"><?php esc_html_e('Blur Intensity', 'dit-trend-studio'); ?></label>
                        <div class="dit-ts-control">
                            <div class="dit-ts-inline">
                                <input type="range" id="dit-ts-blur-intensity" min="0" max="20" value="0" step="1">
                                <span id="dit-ts-blur-intensity-val">0</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="dit-ts-form-group">
                    <label>
                        <input type="checkbox" id="dit-ts-is-retina" value="1">
                        <?php esc_html_e('Retina / 2× Output', 'dit-trend-studio'); ?>
                    </label>
                </div>
            </div>

            <!-- Grid: Bottom Text -->
            <div class="dit-ts-card dit-ts-grid-only">
                <h3><?php esc_html_e('Bottom Text', 'dit-trend-studio'); ?></h3>
                <div class="dit-ts-form-group">
                    <label for="dit-ts-grid-bottom-text"><?php esc_html_e('Brand / Caption', 'dit-trend-studio'); ?></label>
                    <input type="text" id="dit-ts-grid-bottom-text" class="widefat"
                        value="<?php echo esc_attr(get_option('dit_ts_collage_bottom_text', get_bloginfo('name'))); ?>">
                </div>
            </div>

            <!-- ═══ SPLIT CARD ONLY ═══ -->

            <!-- Split: Text Content -->
            <div class="dit-ts-card dit-ts-split-only">
                <h3><?php esc_html_e('Text Content', 'dit-trend-studio'); ?></h3>
                <div class="dit-ts-form-group">
                    <label for="dit-ts-main-font"><?php esc_html_e('Font', 'dit-trend-studio'); ?></label>
                    <select id="dit-ts-main-font" class="widefat"></select>
                    <!-- Live font preview -->
                    <div id="dit-ts-font-preview-split" class="dit-ts-font-preview-box">
                        <span class="dit-ts-fp-latin">Aa Bb Cc — The Quick Brown Fox</span>
                        <span class="dit-ts-fp-urdu" dir="rtl">اب پ تھ — یہ اردو ہے</span>
                    </div>
                </div>
                <div class="dit-ts-form-group">
                    <label for="dit-ts-split-heading"><?php esc_html_e('Heading', 'dit-trend-studio'); ?></label>
                    <textarea id="dit-ts-split-heading" class="widefat" rows="3" dir="auto"
                        placeholder="<?php esc_attr_e('Enter heading…', 'dit-trend-studio'); ?>"></textarea>
                </div>
                <div class="dit-ts-form-row">
                    <div class="dit-ts-form-group">
                        <label for="dit-ts-heading-size"><?php esc_html_e('Heading Size', 'dit-trend-studio'); ?></label>
                        <div class="dit-ts-control">
                            <div class="dit-ts-inline">
                                <input type="range" id="dit-ts-heading-size" min="20" max="96" value="48" step="1">
                                <span id="dit-ts-heading-size-val">48</span>
                            </div>
                        </div>
                    </div>
                    <div class="dit-ts-form-group">
                        <label for="dit-ts-heading-line-height"><?php esc_html_e('Line Height', 'dit-trend-studio'); ?></label>
                        <div class="dit-ts-control">
                            <div class="dit-ts-inline">
                                <input type="range" id="dit-ts-heading-line-height" min="1.0" max="3.0" value="1.5" step="0.1">
                                <span id="dit-ts-heading-line-height-val">1.5</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="dit-ts-form-group">
                    <label for="dit-ts-split-body"><?php esc_html_e('Body Text', 'dit-trend-studio'); ?></label>
                    <textarea id="dit-ts-split-body" class="widefat" rows="4" dir="auto"
                        placeholder="<?php esc_attr_e('Enter body text…', 'dit-trend-studio'); ?>"></textarea>
                </div>
                <div class="dit-ts-form-row">
                    <div class="dit-ts-form-group">
                        <label for="dit-ts-body-size"><?php esc_html_e('Body Size', 'dit-trend-studio'); ?></label>
                        <div class="dit-ts-control">
                            <div class="dit-ts-inline">
                                <input type="range" id="dit-ts-body-size" min="14" max="60" value="26" step="1">
                                <span id="dit-ts-body-size-val">26</span>
                            </div>
                        </div>
                    </div>
                    <div class="dit-ts-form-group">
                        <label for="dit-ts-body-line-height"><?php esc_html_e('Line Height', 'dit-trend-studio'); ?></label>
                        <div class="dit-ts-control">
                            <div class="dit-ts-inline">
                                <input type="range" id="dit-ts-body-line-height" min="1.0" max="3.0" value="1.5" step="0.1">
                                <span id="dit-ts-body-line-height-val">1.5</span>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- @MODIFIED 2026-03-01 - Added separate Heading BG color -->
                <div class="dit-ts-form-row">
                    <div class="dit-ts-form-group">
                        <label for="dit-ts-heading-bg-color"><?php esc_html_e('Heading BG Color', 'dit-trend-studio'); ?></label>
                        <input type="color" id="dit-ts-heading-bg-color" class="dit-ts-color-picker" value="#f0f0f0">
                    </div>
                    <div class="dit-ts-form-group">
                        <label for="dit-ts-body-bg-color-split"><?php esc_html_e('Body Text BG', 'dit-trend-studio'); ?></label>
                        <input type="color" id="dit-ts-body-bg-color-split" class="dit-ts-color-picker" value="#ffffff">
                    </div>
                </div>
            </div>

            <!-- Split: Brand Bar -->
            <div class="dit-ts-card dit-ts-split-only">
                <h3><?php esc_html_e('Brand Bar', 'dit-trend-studio'); ?></h3>
                <div class="dit-ts-form-group">
                    <label for="dit-ts-brand-text"><?php esc_html_e('Brand Name', 'dit-trend-studio'); ?></label>
                    <input type="text" id="dit-ts-brand-text" class="widefat"
                        value="<?php echo esc_attr(get_option('dit_ts_collage_bottom_text', get_bloginfo('name'))); ?>">
                </div>
                <div class="dit-ts-form-row">
                    <div class="dit-ts-form-group">
                        <label for="dit-ts-brand-bar-height"><?php esc_html_e('Bar Height (%)', 'dit-trend-studio'); ?></label>
                        <div class="dit-ts-control">
                            <div class="dit-ts-inline">
                                <input type="range" id="dit-ts-brand-bar-height" min="3" max="12" value="8" step="1">
                                <span id="dit-ts-brand-bar-height-val">8</span>
                            </div>
                        </div>
                    </div>
                    <div class="dit-ts-form-group">
                        <label for="dit-ts-logo-size"><?php esc_html_e('Logo Size (%)', 'dit-trend-studio'); ?></label>
                        <div class="dit-ts-control">
                            <div class="dit-ts-inline">
                                <input type="range" id="dit-ts-logo-size" min="30" max="80" value="60" step="5">
                                <span id="dit-ts-logo-size-val">60</span>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- @MODIFIED 2026-03-01 - Added brand letter spacing -->
                <div class="dit-ts-form-row">
                    <div class="dit-ts-form-group">
                        <label for="dit-ts-brand-letter-spacing"><?php esc_html_e('Letter Spacing', 'dit-trend-studio'); ?></label>
                        <div class="dit-ts-control">
                            <div class="dit-ts-inline">
                                <input type="range" id="dit-ts-brand-letter-spacing" min="0" max="30" value="0" step="1">
                                <span id="dit-ts-brand-letter-spacing-val">0</span>
                            </div>
                        </div>
                    </div>
                    <div class="dit-ts-form-group">
                        <label for="dit-ts-watermark-opacity"><?php esc_html_e('Watermark Opacity (%)', 'dit-trend-studio'); ?></label>
                        <div class="dit-ts-control">
                            <div class="dit-ts-inline">
                                <input type="range" id="dit-ts-watermark-opacity" min="0" max="100" value="0" step="5">
                                <span id="dit-ts-watermark-opacity-val">0</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="dit-ts-form-row">
                    <div class="dit-ts-form-group">
                        <label for="dit-ts-brand-bg-color"><?php esc_html_e('Bar Background', 'dit-trend-studio'); ?></label>
                        <input type="color" id="dit-ts-brand-bg-color" class="dit-ts-color-picker" value="#111111">
                    </div>
                    <div class="dit-ts-form-group">
                        <label for="dit-ts-body-bg-color"><?php esc_html_e('Text Area BG', 'dit-trend-studio'); ?></label>
                        <input type="color" id="dit-ts-body-bg-color" class="dit-ts-color-picker" value="#ffffff">
                    </div>
                </div>
                <!-- @MODIFIED 2026-03-01 - Added brand bar font size + text align -->
                <div class="dit-ts-form-row">
                    <div class="dit-ts-form-group">
                        <label for="dit-ts-brand-font-size"><?php esc_html_e('Bar Font Size (%)', 'dit-trend-studio'); ?></label>
                        <div class="dit-ts-control">
                            <div class="dit-ts-inline">
                                <input type="range" id="dit-ts-brand-font-size" min="20" max="90" value="45" step="5">
                                <span id="dit-ts-brand-font-size-val">45</span>
                            </div>
                        </div>
                    </div>
                    <div class="dit-ts-form-group">
                        <label for="dit-ts-brand-text-align"><?php esc_html_e('Bar Text Align', 'dit-trend-studio'); ?></label>
                        <select id="dit-ts-brand-text-align" class="widefat">
                            <option value="left" selected><?php esc_html_e('Left', 'dit-trend-studio'); ?></option>
                            <option value="center"><?php esc_html_e('Center', 'dit-trend-studio'); ?></option>
                            <option value="right"><?php esc_html_e('Right', 'dit-trend-studio'); ?></option>
                        </select>
                    </div>
                </div>
                <div class="dit-ts-form-group">
                    <label><?php esc_html_e('Logo', 'dit-trend-studio'); ?></label>
                    <div class="dit-ts-logo-row">
                        <div id="dit-ts-logo-preview" class="dit-ts-logo-preview"></div>
                        <div class="dit-ts-logo-actions">
                            <button type="button" id="dit-ts-select-logo" class="button button-secondary"><?php esc_html_e('Select Logo', 'dit-trend-studio'); ?></button>
                            <button type="button" id="dit-ts-clear-logo" class="button button-link-delete"><?php esc_html_e('Remove', 'dit-trend-studio'); ?></button>
                        </div>
                        <input type="hidden" id="dit-ts-logo-id" value="">
                    </div>
                </div>
            </div>

            <!-- ═══ SHARED: Export ═══ -->
            <div class="dit-ts-card">
                <h3><?php esc_html_e('Export', 'dit-trend-studio'); ?></h3>
                <div class="dit-ts-form-group dit-ts-split-only">
                    <label for="dit-ts-export-scale"><?php esc_html_e('Resolution', 'dit-trend-studio'); ?></label>
                    <select id="dit-ts-export-scale" class="widefat">
                        <option value="1"><?php esc_html_e('1× – 1080 px', 'dit-trend-studio'); ?></option>
                        <option value="2" selected><?php esc_html_e('2× – 2160 px (Default)', 'dit-trend-studio'); ?></option>
                        <option value="3"><?php esc_html_e('3× – 3240 px', 'dit-trend-studio'); ?></option>
                    </select>
                </div>
                <div class="dit-ts-form-row">
                    <div class="dit-ts-form-group">
                        <label for="dit-ts-output-format"><?php esc_html_e('Format', 'dit-trend-studio'); ?></label>
                        <select id="dit-ts-output-format" class="widefat">
                            <option value="webp" selected>WebP</option>
                            <option value="jpg">JPEG</option>
                            <option value="png">PNG</option>
                        </select>
                    </div>
                    <div class="dit-ts-form-group">
                        <label for="dit-ts-collage-title"><?php esc_html_e('Media Library Title', 'dit-trend-studio'); ?></label>
                        <input type="text" id="dit-ts-collage-title" class="widefat"
                            placeholder="<?php esc_attr_e('Auto-generated if blank', 'dit-trend-studio'); ?>">
                    </div>
                </div>
            </div>

            <button type="button" id="dit-ts-generate-btn" class="button button-primary button-hero" disabled>
                <?php esc_html_e('Generate / Save', 'dit-trend-studio'); ?>
            </button>

            <div id="dit-ts-result-actions" class="dit-ts-result-actions hidden" role="status">
                <span class="dit-ts-success-msg"><?php esc_html_e('✓ Saved to Media Library', 'dit-trend-studio'); ?></span>
                <a id="dit-ts-view-link" href="#" target="_blank" rel="noopener noreferrer" class="button button-secondary">
                    <?php esc_html_e('View Image', 'dit-trend-studio'); ?>
                </a>
            </div>

        </div><!-- /.dit-ts-collage-sidebar -->

        <!-- ═══════════════════ RIGHT: PREVIEW ═══════════════════ -->
        <div class="dit-ts-collage-preview">
            <div class="dit-ts-preview-card">
                <h3><?php esc_html_e('Live Preview', 'dit-trend-studio'); ?></h3>
                <p class="dit-ts-preview-help">
                    <span class="dit-ts-split-only"><?php esc_html_e('Updates live as you type. Zoom sliders pan/zoom each image.', 'dit-trend-studio'); ?></span>
                    <span class="dit-ts-grid-only"><?php esc_html_e('Canvas preview matches export layout. Click Generate for HD server output.', 'dit-trend-studio'); ?></span>
                </p>
                <div id="dit-ts-preview-box" class="dit-ts-preview-box">
                    <div class="dit-ts-placeholder">
                        <span class="dashicons dashicons-format-image"></span>
                        <p class="dit-ts-split-only"><?php esc_html_e('Add at least 2 images to preview.', 'dit-trend-studio'); ?></p>
                        <p class="dit-ts-grid-only"><?php esc_html_e('Add images to preview.', 'dit-trend-studio'); ?></p>
                    </div>
                    <canvas id="dit-ts-split-canvas" class="dit-ts-split-canvas" style="display:none;"></canvas>
                    <img id="dit-ts-grid-result-img" class="dit-ts-split-canvas" src="" alt="" style="display:none;">
                </div>
            </div>
        </div>

    </div><!-- /.dit-ts-collage-container -->
</div>