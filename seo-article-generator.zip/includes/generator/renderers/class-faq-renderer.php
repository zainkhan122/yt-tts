<?php
/**
 * FAQ (FREQUENTLY ASKED QUESTIONS) RENDERER
 *
 * @MODIFIED 2026-06-14 — Gutenberg block recovery fix (class-faq-renderer.php):
 *
 * WHY: The question title text could contain HTML entities (e.g., &amp; from
 * wp_kses_post or markdown processing). When stored in the block attrs 'title'
 * field, these entities remained encoded. Gutenberg's JS save() uses
 * RichText.Content which compares the decoded text, causing a mismatch and
 * triggering block recovery.
 *
 * WHAT CHANGED:
 * 1. Added html_entity_decode() on question title text (line 61) to ensure
 *    the 'title' attr in the block comment contains plain text matching what
 *    the JS RichText.Content component expects.
 * 2. The innerHTML already uses serialize_blocks() which handles correct
 *    JSON encoding of block comment attributes via WordPress core.
 *
 * FILES: class-faq-renderer.php (this file)
 */

namespace SEO_Article_Generator\Generator\Renderers;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Handles rendering of FAQ blocks
 */
class FAQ_Renderer
{
    use \SEO_Article_Generator\Traits\Markdown_Processor;

    /**
     * Render FAQs as a Rank Math FAQ block
     *
     * @param array  $faqs      FAQ items from AI
     * @param int    $post_id   Post ID for unique IDs
     * @param string $heading   Section heading
     * @param string $anchor_id Section anchor ID
     * @return string HTML
     */
    public function render($faqs, $post_id = 0, $heading = 'Frequently Asked Questions', $anchor_id = 'faq')
    {
        $blocks = $this->render_blocks($faqs, $post_id, $heading, $anchor_id);
        if (empty($blocks)) {
            return '';
        }

        // Manually serialize to avoid serialize_blocks() applying JSON_HEX_TAG
        // which encodes < > in block attrs (\u003c / \u003e), breaking Gutenberg's
        // block validation for rank-math/faq-block content fields that contain HTML.
        $output = '';
        foreach ($blocks as $block) {
            $output .= self::serialize_single_block($block);
        }
        return $output;
    }

    /**
     * Serialize a single block without JSON_HEX_TAG encoding.
     *
     * WordPress core's serialize_blocks() → serialize_block_attrs() uses
     * json_encode(JSON_HEX_TAG) which turns <p> into \u003cp\u003e in block
     * comment JSON. Gutenberg's parser decodes this fine, but the Rank Math
     * FAQ block's JS save() compares decoded content against innerHTML, and
     * any whitespace/encoding mismatch triggers block recovery.
     *
     * By using json_encode() WITHOUT JSON_HEX_TAG, <p> stays as <p> in the
     * JSON string, matching what Gutenberg's own serializer produces.
     */
    private static function serialize_single_block(array $block): string
    {
        $block_name = $block['blockName'] ?? '';
        if ($block_name === '') {
            // Freeform HTML — just output innerHTML
            return implode('', $block['innerContent'] ?? array());
        }

        // Serialize attrs WITHOUT JSON_HEX_TAG
        $attrs_json = '';
        if (!empty($block['attrs'])) {
            $attrs_json = wp_json_encode(
                $block['attrs'],
                JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
            );
        }

        // Build the block comment
        $output = '<!-- wp:' . $block_name . ($attrs_json !== '' ? ' ' . $attrs_json : '') . ' -->';

        // Inner content (with nested blocks serialized recursively)
        if (!empty($block['innerBlocks']) && !empty($block['innerContent'])) {
            $inner_block_index = 0;
            foreach ($block['innerContent'] as $chunk) {
                if ($chunk === null) {
                    // Null placeholder = slot for a nested inner block
                    if (isset($block['innerBlocks'][$inner_block_index])) {
                        $output .= self::serialize_single_block($block['innerBlocks'][$inner_block_index]);
                        $inner_block_index++;
                    }
                } else {
                    $output .= $chunk;
                }
            }
        } elseif (!empty($block['innerContent'])) {
            $output .= implode('', $block['innerContent']);
        }

        $output .= '<!-- /wp:' . $block_name . ' -->';

        return $output;
    }

    /**
     * Render FAQs as block array.
     *
     * @param array  $faqs      FAQ items from AI
     * @param int    $post_id   Post ID
     * @param string $heading   Section heading
     * @param string $anchor_id Section anchor ID
     * @return array Block array
     */
    public function render_blocks($faqs, $post_id = 0, $heading = 'Frequently Asked Questions', $anchor_id = 'faq')
    {
        if (empty($faqs) || !is_array($faqs)) {
            return array();
        }

        $blocks = array();

        // Heading block
        $blocks[] = array(
            'blockName'    => 'core/heading',
            'attrs'        => array('level' => 2, 'anchor' => $anchor_id),
            'innerBlocks'  => array(),
            'innerHTML'    => '<h2 class="wp-block-heading" id="' . \esc_attr($anchor_id) . '">' . \esc_html($heading) . '</h2>',
            'innerContent' => array('<h2 class="wp-block-heading" id="' . \esc_attr($anchor_id) . '">' . \esc_html($heading) . '</h2>'),
        );

        $questions_json = array();
        $inner_html     = '';
        $index          = 0;

        foreach ($faqs as $faq) {
            $question = isset($faq['question']) ? \html_entity_decode(\wp_strip_all_tags(self::process_markdown($faq['question'])), ENT_QUOTES, 'UTF-8') : '';
            $answer   = isset($faq['answer']) ? self::process_markdown($faq['answer']) : '';

            if ($question === '' || $answer === '') {
                continue;
            }

            $clean_answer = \wp_strip_all_tags($answer, '<strong><em><a>');
            $final_answer = trim(\wpautop($clean_answer));

            ++$index;
		$faq_id = 'faq-question-' . ($post_id > 0 ? $post_id . '-' : '') . $index;

		$questions_json[] = array(
			'id' => $faq_id,
			'title' => $question,
			'content' => $final_answer,
			'visible' => true,
		);

		$inner_html .= '<div class="rank-math-faq-item">';
		$inner_html .= '<h3 class="rank-math-question">' . \esc_html($question) . '</h3>';
		$inner_html .= '<div class="rank-math-answer">' . $final_answer . '</div>';
		$inner_html .= '</div>';
        }

        if (empty($questions_json)) {
            return array();
        }

	$block_attrs = \wp_json_encode(
		array(
			'questions' => $questions_json,
			'className' => 'rank-math-block',
		),
		JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
	);

        $blocks[] = array(
            'blockName'    => 'rank-math/faq-block',
            'attrs'        => json_decode($block_attrs, true),
            'innerBlocks'  => array(),
            'innerHTML'    => '<div class="wp-block-rank-math-faq-block rank-math-block">' . $inner_html . '</div>',
            'innerContent' => array('<div class="wp-block-rank-math-faq-block rank-math-block">' . $inner_html . '</div>'),
        );

        return $blocks;
    }
}
