<?php

/**
 * E-E-A-T Frontend Styles
 * 
 * CSS for author bylines and verification badges.
 *
 * @package SEO_Article_Generator
 * @since   2.2.0
 */

namespace SEO_Article_Generator\Frontend;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Frontend Styles
 * @MODIFIED 2025-12-16 v2.2.0: Created for E-E-A-T CSS
 */
class EEAT_Frontend_Styles
{

    /**
     * Generate inline CSS
     */
    public static function get_inline_css()
    {
        return <<<CSS
/* Author Byline - @MODIFIED 2025-12-17 v2.4.3: Dark mode support */
.seo-author-byline {
    display: flex;
    gap: 15px;
    padding: 20px;
    background: var(--seo-gen-bg-card, #f9f9f9);
    border-left: 4px solid var(--seo-gen-primary, #2271b1);
    border-radius: var(--seo-gen-radius, 8px);
    margin: 20px 0;
}

.seo-author-avatar img {
    border-radius: 50%;
    display: block;
}

.seo-author-info {
    flex: 1;
}

.seo-author-name {
    font-size: 18px;
    font-weight: 600;
    margin-bottom: 5px;
    color: var(--seo-gen-text-dark, #1f2937);
}

.seo-author-name a {
    color: var(--seo-gen-primary, #2271b1);
    text-decoration: none;
}

.seo-author-name a:hover {
    text-decoration: underline;
}

.seo-verified-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 2px 8px;
    background: #e6f7ec;
    color: #00a32a;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 600;
    margin-left: 8px;
}

.seo-author-title {
    color: var(--seo-gen-text-light, #666);
    font-size: 14px;
    font-style: italic;
    margin-bottom: 8px;
}

.seo-author-credentials {
    color: var(--seo-gen-text-light, #555);
    font-size: 13px;
    margin-bottom: 8px;
}

.seo-author-bio {
    color: var(--seo-gen-text-dark, #333);
    font-size: 14px;
    line-height: 1.6;
    margin-bottom: 12px;
}

.seo-author-social {
    display: flex;
    gap: 10px;
}

.seo-social-link {
    color: var(--seo-gen-text-light, #666);
    transition: color 0.2s;
}

.seo-social-link:hover {
    color: var(--seo-gen-primary, #2271b1);
}

/* Article Meta */
.seo-article-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 15px;
    font-size: 14px;
    color: var(--seo-gen-text-light, #666);
    margin-bottom: 20px;
}

.seo-meta-item {
    display: inline-flex;
    align-items: center;
    gap: 5px;
}

.seo-verified-icon {
    color: #00a32a;
    font-weight: 600;
}

/* Verification Badge */
.seo-verification-badge {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 15px;
    background: #e6f7ec;
    border: 1px solid #00a32a;
    border-radius: 6px;
    margin: 20px 0;
}

.seo-verification-icon svg {
    display: block;
}

.seo-verification-text {
    font-size: 14px;
    line-height: 1.6;
    color: var(--seo-gen-text-dark, #333);
}

.seo-verification-text strong {
    color: #00a32a;
}

.seo-verified-compact {
    display: inline-flex;
    align-items: center;
    padding: 4px 10px;
    background: #e6f7ec;
    color: #00a32a;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 600;
}

/* Responsive */
@media (max-width: 768px) {
    .seo-author-byline {
        flex-direction: column;
        text-align: center;
    }

    .seo-author-avatar {
        margin: 0 auto;
    }

    .seo-article-meta {
        flex-direction: column;
        gap: 8px;
    }
}

/* Dark Mode Support for Neve Theme */
[data-neve-theme='dark'] .seo-author-byline,
.neve-dark .seo-author-byline,
html.nv-dark .seo-author-byline,
body.nv-dark .seo-author-byline {
    background: var(--seo-gen-bg-card-alt, #1e293b);
}

[data-neve-theme='dark'] .seo-author-name,
.neve-dark .seo-author-name,
html.nv-dark .seo-author-name,
body.nv-dark .seo-author-name {
    color: var(--seo-gen-text-primary, #f1f5f9);
}

[data-neve-theme='dark'] .seo-author-title,
[data-neve-theme='dark'] .seo-author-credentials,
[data-neve-theme='dark'] .seo-social-link,
[data-neve-theme='dark'] .seo-article-meta,
.neve-dark .seo-author-title,
.neve-dark .seo-author-credentials,
.neve-dark .seo-social-link,
.neve-dark .seo-article-meta,
html.nv-dark .seo-author-title,
html.nv-dark .seo-author-credentials,
html.nv-dark .seo-social-link,
html.nv-dark .seo-article-meta,
body.nv-dark .seo-author-title,
body.nv-dark .seo-author-credentials,
body.nv-dark .seo-social-link,
body.nv-dark .seo-article-meta {
    color: var(--seo-gen-text-secondary, #94a3b8);
}

[data-neve-theme='dark'] .seo-author-bio,
[data-neve-theme='dark'] .seo-verification-text,
.neve-dark .seo-author-bio,
.neve-dark .seo-verification-text,
html.nv-dark .seo-author-bio,
html.nv-dark .seo-verification-text,
body.nv-dark .seo-author-bio,
body.nv-dark .seo-verification-text {
    color: var(--seo-gen-text-primary, #e2e8f0);
}
CSS;
    }
}
