# visual_plan.json

| Field | Meaning |
|---|---|
| `mode` | `character` \| `environment` \| `object` \| `mechanism` \| `symbol` |
| `identity_id` | key in `tools/visual_identities.json` |
| `motif` | one concrete image (maze is s02; new cognitive films need another) |
| `palette` | `{ bg, ink, punch }` hex |
| `type` | `{ family, size_px, tracking_em, case }` — **one** set per Short |
| `feasibility` | `stills_gsap` \| `stills_kenburns` — never `cgi3d` unless true |
| `beats[]` | `{ i, visual_intent, camera, transition, hf? }` |

`visual_intent` is what the eye must understand. `hf` is an implementation id (generic kit or custom). Intent wins.
