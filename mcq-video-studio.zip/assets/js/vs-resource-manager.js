/**
 * MCQVS Resource Manager
 * Centralized manager for Blob URLs to prevent memory leaks
 *
 * @package WP_News_MCQ_Generator
 * @version 8.8.0
 * @author MCP Developers
 * @since 2026-01-17
 *
 * Problem: URL.createObjectURL() creates Blob URLs that persist in
 * browser memory until explicitly revoked. GC does NOT clean these up.
 *
 * Solution: Track all allocated URLs and provide cleanup methods.
 */

(function (window) {
  "use strict";

  const MCQVS_ResourceManager = {
    /**
     * Active resource URLs - Set for O(1) lookup
     * @private
     */
    _activeResources: new Set(),

    /**
     * Resource metadata for debugging
     * @private
     */
    _metadata: new Map(),

    /**
     * Allocate a new Blob URL and track it
     * @param {Blob|File} blob - The blob to create URL for
     * @param {string} [label] - Optional label for debugging
     * @returns {string} The created object URL
     */
    allocate: function (blob, label = "unknown") {
      const url = URL.createObjectURL(blob);
      this._activeResources.add(url);
      this._metadata.set(url, {
        label: label,
        size: blob.size || 0,
        type: blob.type || "unknown",
        createdAt: Date.now(),
      });

      if (window.MCQVS_Studio?.config?.debug) {
        console.log(
          `[ResourceManager] Allocated: ${label} (${this._activeResources.size} active)`
        );
      }

      return url;
    },

    /**
     * Release a single Blob URL
     * @param {string} url - The URL to release
     * @returns {boolean} True if URL was found and released
     */
    release: function (url) {
      if (!url) return false;

      if (this._activeResources.has(url)) {
        URL.revokeObjectURL(url);
        this._activeResources.delete(url);

        const meta = this._metadata.get(url);
        this._metadata.delete(url);

        if (window.MCQVS_Studio?.config?.debug) {
          console.log(
            `[ResourceManager] Released: ${meta?.label || "unknown"} (${this._activeResources.size} remaining)`
          );
        }

        return true;
      }

      return false;
    },

    /**
     * Emergency cleanup - purge ALL tracked resources
     * Call after batch exports or on cancellation
     */
    purgeAll: function () {
      const count = this._activeResources.size;

      for (const url of this._activeResources) {
        try {
          URL.revokeObjectURL(url);
        } catch (e) {
          // Ignore errors on already-revoked URLs
        }
      }

      this._activeResources.clear();
      this._metadata.clear();

      console.log(`[ResourceManager] Purged ${count} resources`);
    },

    /**
     * Get count of active resources (for monitoring)
     * @returns {number}
     */
    getActiveCount: function () {
      return this._activeResources.size;
    },

    /**
     * Get memory stats for debugging
     * @returns {Object}
     */
    getStats: function () {
      let totalSize = 0;
      const breakdown = {};

      for (const [url, meta] of this._metadata) {
        totalSize += meta.size;
        breakdown[meta.label] = (breakdown[meta.label] || 0) + 1;
      }

      return {
        count: this._activeResources.size,
        totalSizeBytes: totalSize,
        totalSizeMB: (totalSize / (1024 * 1024)).toFixed(2),
        breakdown: breakdown,
      };
    },
  };

  // Export to window
  window.MCQVS_ResourceManager = MCQVS_ResourceManager;
})(window);
