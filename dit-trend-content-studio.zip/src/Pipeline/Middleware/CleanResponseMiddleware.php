<?php

namespace DIT\TrendStudio\Pipeline\Middleware;

use DIT\TrendStudio\Contracts\MiddlewareInterface;
use DIT\TrendStudio\Services\Content_Cleaner;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * CleanResponseMiddleware
 *
 * Runs the Content_Cleaner on all string fields in the AI response.
 */
class CleanResponseMiddleware implements MiddlewareInterface
{
    public function handle(array $data, array $context, callable $next): array
    {
        $cleaner = new Content_Cleaner();

        array_walk_recursive($data, function (&$value) use ($cleaner) {
            if (is_string($value) && !empty($value)) {
                $value = $cleaner->clean_generated_content($value);
            }
        });

        return $next($data);
    }
}
