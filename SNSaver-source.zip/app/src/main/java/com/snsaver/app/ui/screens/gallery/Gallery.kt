package com.snsaver.app.ui.screens.gallery
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.snsaver.app.domain.model.*
import com.snsaver.app.domain.repository.DownloadRepository
import com.snsaver.app.ui.components.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import javax.inject.Inject
@HiltViewModel class GalleryViewModel @Inject constructor(repo:DownloadRepository):ViewModel(){val filter=MutableStateFlow<Platform?>(null);val items=combine(repo.observeCompleted(),filter){list,p->if(p==null)list else list.filter{it.platform==p}}.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())}
@OptIn(ExperimentalMaterial3Api::class) @Composable fun GalleryScreen(onItem:(Long)->Unit,vm:GalleryViewModel=hiltViewModel()){val items by vm.items.collectAsStateWithLifecycle();val filter by vm.filter.collectAsStateWithLifecycle();Scaffold(topBar={Column{TopAppBar(title={Text("Gallery",style=MaterialTheme.typography.headlineMedium)});Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal=12.dp),horizontalArrangement=Arrangement.spacedBy(7.dp)){FilterChip(filter==null,{vm.filter.value=null},{Text("All")});Platform.entries.filter{it!=Platform.UNKNOWN}.forEach{p->FilterChip(filter==p,{vm.filter.value=p},{Text(p.shortName)})}}}}){pad->if(items.isEmpty())EmptyState("Gallery is empty","Completed downloads appear here") else LazyVerticalGrid(GridCells.Adaptive(150.dp),Modifier.fillMaxSize().padding(pad).padding(horizontal=12.dp),horizontalArrangement=Arrangement.spacedBy(9.dp),verticalArrangement=Arrangement.spacedBy(9.dp),contentPadding=PaddingValues(vertical=10.dp)){items(items,key={it.id}){GalleryTile(it){onItem(it.id)}}}}}
