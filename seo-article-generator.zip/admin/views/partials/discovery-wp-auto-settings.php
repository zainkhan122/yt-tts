<?php

/**
 * admin/views/partials/discovery-wp-auto-settings.php
 *
 * NEW FILE — WP Automatic Integration Settings Tab
 *
 * @MODIFIED 2026-03-02 - New WP Auto draft polling settings panel
 */

if (! defined('ABSPATH')) exit;

$current_category_id = (int) \get_option(\SEO_Article_Generator\Option_Registry::WP_AUTO_CATEGORY_ID, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::WP_AUTO_CATEGORY_ID]);
$current_retention   = (int) \get_option(\SEO_Article_Generator\Option_Registry::DRAFT_RETENTION_DAYS, \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::DRAFT_RETENTION_DAYS]);

// ── External Heartbeat Cron state ───────────────────────────────────────
// Lazily initialize the secret on first UI render so the operator never
// sees an empty field — the heartbeat endpoint would generate it on first
// ping anyway, but bootstrapping here lets the operator copy the command
// immediately without first pinging the endpoint.
$heartbeat_secret = (string) \get_option(\SEO_Article_Generator\Option_Registry::EXTERNAL_CRON_SECRET, '');
if ('' === $heartbeat_secret) {
    $heartbeat_secret = \wp_generate_password(32, false);
    \update_option(\SEO_Article_Generator\Option_Registry::EXTERNAL_CRON_SECRET, $heartbeat_secret, false);
}
$heartbeat_last_fire   = (int) \get_option(\SEO_Article_Generator\Option_Registry::EXTERNAL_CRON_LAST_FIRE, 0);
$heartbeat_last_report = (string) \get_option(\SEO_Article_Generator\Option_Registry::EXTERNAL_CRON_LAST_REPORT, '');
$heartbeat_url         = \trailingslashit(\home_url('/')) . '?seo_gen_heartbeat=1&secret=' . $heartbeat_secret;
$heartbeat_curl        = 'curl -s "' . $heartbeat_url . '"';
$heartbeat_cron_line   = '* * * * * ' . $heartbeat_curl . ' >/dev/null 2>&1';

// Render last-fire status text (relative).
$heartbeat_status_text = 'Never fired';
$heartbeat_status_class = 'color:#b26a00;';
$now_utc = \time();
if ($heartbeat_last_fire > 0) {
    $ago = $now_utc - $heartbeat_last_fire;
    if ($ago < 60) {
        $heartbeat_status_text = $ago . 's ago';
        $heartbeat_status_class = 'color:#2e7d32;';
    } elseif ($ago < 300) {
        $heartbeat_status_text = \intval($ago / 60) . 'm ' . ($ago % 60) . 's ago';
        $heartbeat_status_class = 'color:#2e7d32;';
    } elseif ($ago < 900) {
        $heartbeat_status_text = \intval($ago / 60) . 'm ago';
        $heartbeat_status_class = 'color:#b26a00;';
    } else {
        $heartbeat_status_text = \gmdate('Y-m-d H:i:s', $heartbeat_last_fire) . ' UTC (' . \intval($ago / 60) . 'm ago)';
        $heartbeat_status_class = 'color:#c62828;';
    }
}

$bootstrap_wp = isset($bootstrap) && $bootstrap instanceof \SEO_Article_Generator\Discovery\Discovery_Bootstrap
    ? $bootstrap
    : \SEO_Article_Generator\Discovery\Discovery_Bootstrap::get_instance();

$wp_auto_snapshot = ($bootstrap_wp && method_exists($bootstrap_wp, 'get_dashboard_wp_auto_snapshot'))
    ? (array) $bootstrap_wp->get_dashboard_wp_auto_snapshot()
    : array(
        'state'          => 'inactive',
        'label'          => 'Not Configured',
        'category_id'    => 0,
        'configured'     => 0,
        'scheduled'      => 0,
        'next_poll'      => 0,
        'next_poll_text' => 'Not scheduled',
        'pending_drafts' => 0,
    );

// All available categories for the dropdown
$all_categories = \get_categories(['hide_empty' => false, 'orderby' => 'name']);

// @MODIFIED 2026-03-07 - Fetch unprocessed draft counts per category for better UX in dropdown
// @MODIFIED 2026-08-16: Fixed counter to also exclude drafts with seo_gen_processed_status
// (throttled drafts have status but no seo_gen_processed meta by design, since 2026-07-26 fix)
global $wpdb;
$draft_counts = $wpdb->get_results("
    SELECT tt.term_id, COUNT(p.ID) as count
    FROM {$wpdb->posts} p
    JOIN {$wpdb->term_relationships} tr ON p.ID = tr.object_id
    JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id
    WHERE p.post_type = 'post'
      AND p.post_status = 'draft'
      AND tt.taxonomy = 'category'
      AND NOT EXISTS (
          SELECT 1 FROM {$wpdb->postmeta} pm
          WHERE pm.post_id = p.ID
            AND pm.meta_key = 'seo_gen_processed'
      )
      AND NOT EXISTS (
          SELECT 1 FROM {$wpdb->postmeta} pm
          WHERE pm.post_id = p.ID
            AND pm.meta_key = 'seo_gen_processed_status'
      )
    GROUP BY tt.term_id
", OBJECT_K);
?>

<div style="max-width:680px; margin-top:20px;">

    <h2>WP Automatic Integration Settings</h2>

    <div style="background:#f6f7f7;border:1px solid #c3c4c7;padding:16px 20px;border-radius:4px;margin-bottom:20px;">
        <strong>How This Works:</strong>
        <ol style="margin:8px 0 0 20px;">
            <li>Create campaigns in <strong>WP Automatic</strong> with <em>New Post Status = Draft</em></li>
            <li>Assign a dedicated category to those campaigns (e.g. "WP Auto Staging")</li>
            <li>Configure that category below</li>
            <li>SEO-Gen polls every <strong>15 minutes</strong>, processes up to <strong>10 unprocessed drafts per run</strong>, compares versions, and stages only genuine updates or new items for AI generation.</li>
        </ol>
    </div>

    <div id="sgd-wpauto-status-box"
         style="background:<?php echo ! empty($wp_auto_snapshot['configured']) ? '#edf7ed' : '#fff3e0'; ?>; border:1px solid <?php echo ! empty($wp_auto_snapshot['scheduled']) ? '#5cb85c' : '#ff9800'; ?>; padding:12px 16px; border-radius:4px; margin-bottom:16px; display:flex; justify-content:space-between; align-items:center;">
        <div>
            <strong>Status:</strong>
            <span id="sgd-wpauto-state"
                  style="color:<?php echo ! empty($wp_auto_snapshot['scheduled']) ? '#2e7d32' : '#b26a00'; ?>; font-weight:600;">
                <?php echo esc_html($wp_auto_snapshot['label']); ?>
            </span>
            &nbsp;&nbsp;
            Next poll:
            <code id="sgd-wpauto-next-poll"><?php echo esc_html($wp_auto_snapshot['next_poll_text']); ?></code>
            &nbsp;&nbsp;
            Waiting:
            <strong id="sgd-wpauto-pending"><?php echo (int) $wp_auto_snapshot['pending_drafts']; ?></strong>
        </div>

        <div style="display:flex; gap:8px;">
            <button type="button" class="button button-small" id="seo-gen-wp-auto-poll-now">Poll Drafts Now</button>
            <button type="button" class="button button-small" id="seo-gen-wp-auto-clear-log" style="color:#d63638; border-color:#d63638;">Clear History</button>
        </div>
    </div>

    <form id="seo-gen-wp-auto-settings-form">

        <table class="form-table" style="margin:0;">
            <tr>
                <th scope="row" style="width:220px;">
                    <label for="wp_auto_category_id">WP Auto Staging Category</label>
                </th>
                <td>
                    <select name="wp_auto_category_id" id="wp_auto_category_id" style="min-width:280px;">
                        <option value="0">— Select a category —</option>
                        <?php foreach ($all_categories as $cat):
                            $unprocessed = isset($draft_counts[$cat->term_id]) ? (int) $draft_counts[$cat->term_id]->count : 0;
                        ?>
                            <option value="<?php echo (int) $cat->term_id; ?>"
                                <?php \selected($current_category_id, $cat->term_id); ?>>
                                <?php echo \esc_html($cat->name); ?>
                                <?php if ($unprocessed > 0): ?>
                                    (<?php echo $unprocessed; ?> unprocessed drafts)
                                <?php else: ?>
                                    (<?php echo (int) $cat->count; ?> posts)
                                <?php endif; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <p class="description">
                        Assign this category to your WP Automatic campaigns.
                    </p>
                </td>
            </tr>

        </table>

        <p style="margin-top:16px;">
            <button type="submit" class="button button-primary" id="seo-gen-save-wp-auto">
                Save Settings
            </button>
            <span id="seo-gen-wp-auto-status" style="margin-left:12px;display:none;"></span>
        </p>
    </form>

    <hr style="margin:24px 0;">

    <h3>Processed Drafts (Last 10)</h3>
    <?php
    // Show recently processed WP Auto drafts for audit (Scoped to configured category only)
    $cat_ids   = \SEO_Article_Generator\Discovery\Discovery_Bootstrap::get_instance()->get_wp_auto_category_ids();
    $processed = \get_posts([
        'post_type'      => 'post',
        'post_status'    => 'draft',
        'meta_key'       => 'seo_gen_processed',
        'orderby'        => 'meta_value_num',
        'order'          => 'DESC',
        'posts_per_page' => 10,
        'category__in'   => ! empty($cat_ids) ? $cat_ids : [0], // Force 0 if no category to show empty
    ]);

    if (empty($processed)):
    ?>
        <p style="color:#666;">No processed drafts yet.</p>
    <?php else: ?>
        <table class="widefat striped" style="margin-top:8px;">
            <thead>
                <tr>
                    <th>Draft Title</th>
                    <th>Status</th>
                    <th>Processed At</th>
                    <th>Scheduled Delete</th>
                    <th>Error Log</th>
                </tr>
            </thead>
            <tbody>
<?php foreach ($processed as $p):
			$proc_time = (int) \get_post_meta($p->ID, 'seo_gen_processed', true);
			$proc_status = \get_post_meta($p->ID, 'seo_gen_processed_status', true);
			$err_log = \get_post_meta($p->ID, 'seo_gen_error_log', true);

			$del_action = \SEO_Article_Generator\Queue\AS_Registry::get_next_run(
				\SEO_Article_Generator\Queue\AS_Registry::HOOK_DELETE_DRAFT,
				[(int) $p->ID]
			);

			if ($del_action > 0) {
				$del_label = \SEO_Article_Generator\Utils\Plugin_Time::site_datetime($del_action);
				$del_style = '';
			} else {
				// No pending AS deletion action. This means the draft is either:
				// (a) currently being generated — deletion deferred until finalization, OR
				// (b) its AS action was lost (deactivation, failure path). The daily
				//     safety-net job (Cleanup_Retention_Job) will re-schedule it.
				$del_label = 'Pending';
				$del_style = 'color:#b26a00;';
			}

			$status_colors = [
				'staged' => '#2e7d32',
				'skipped_not_newer' => '#e65100',
				'parse_failed' => '#c62828',
				'staging' => '#1565c0',
			];
			$color = $status_colors[$proc_status] ?? '#555';
			?>
			<tr>
				<td><?php echo \esc_html($p->post_title); ?> <span style="color:#aaa; font-size:10px;">(#<?php echo $p->ID; ?>)</span></td>
				<td>
					<span style="color:<?php echo $color; ?>; font-weight:600;"><?php echo \esc_html(\strtoupper($proc_status)); ?></span>
				</td>
				<td><?php echo $proc_time ? \SEO_Article_Generator\Utils\Plugin_Time::site_datetime($proc_time) : '—'; ?></td>
				<td><span style="<?php echo $del_style; ?>"><?php echo \esc_html($del_label); ?></span></td>
				<td>
					<?php if ($err_log): ?>
					<button type="button" class="button button-small" onclick="alert(this.nextElementSibling.textContent)">View Log</button>
					<span style="display:none;"><?php echo \esc_html($err_log); ?></span>
					<?php else: ?>
					—
					<?php endif; ?>
				</td>
			</tr>
			<?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>

    <!-- ══════════════════════════════════════════════════════════════════════ -->
    <!-- External Heartbeat Cron — Deterministic, Traffic-Independent Watchdog   -->
    <!-- ══════════════════════════════════════════════════════════════════════ -->

    <h2 style="margin-top:32px;">External Heartbeat Cron
        <span id="sgd-heartbeat-status-pill"
              style="font-size:11px; padding:3px 10px; border-radius:10px; vertical-align:middle; margin-left:8px; background:#e2e4e7; color:#555; font-weight:400;">
            <?php echo \esc_html($heartbeat_status_text); ?>
        </span>
    </h2>

    <div style="background:#f6f7f7;border:1px solid #c3c4c7;padding:16px 20px;border-radius:4px;margin-bottom:16px;">
        <strong>Why this is critical:</strong>
        <p style="margin:8px 0 0 0; color:#3c434a;">
            Action Scheduler's queue runner depends on WP-Cron. When WP-Cron is disabled
            (<code>DISABLE_WP_CRON=true</code>) or silently broken on your host, all
            AS recurring actions (queue worker, sync finalizer, publish watchdog, overdue
            recovery, WP Auto poll, auto-gen) stop firing — items sit "overdue" in the
            pipeline indefinitely. The <strong>External Heartbeat Cron</strong> is a single
            HTTP endpoint that fires ALL watchdogs deterministically, independent of
            page-load traffic. Setup takes 30 seconds on your VPS crontab.
        </p>
    </div>

    <div id="sgd-heartbeat-status-box"
         style="background:<?php echo $heartbeat_last_fire > 0 && (\time() - $heartbeat_last_fire) < 120 ? '#edf7ed' : '#fff3e0'; ?>; border:1px solid <?php echo $heartbeat_last_fire > 0 && (\time() - $heartbeat_last_fire) < 120 ? '#5cb85c' : '#ff9800'; ?>; padding:12px 16px; border-radius:4px; margin-bottom:16px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
        <div>
            <strong>Last fired:</strong>
            <span id="sgd-heartbeat-last" style="<?php echo \esc_attr($heartbeat_status_class); ?> font-weight:600;">
                <?php echo \esc_html($heartbeat_status_text); ?>
            </span>
            &nbsp;&nbsp;
            <strong>Endpoint:</strong>
            <code><?php echo $heartbeat_last_fire > 0 ? 'OK' : 'Awaiting first ping'; ?></code>
        </div>
        <div style="display:flex; gap:8px;">
            <button type="button" class="button button-small" id="seo-gen-heartbeat-test">Test Now</button>
            <button type="button" class="button button-small" id="seo-gen-heartbeat-regen" style="color:#d63638; border-color:#d63638;">Regenerate Secret</button>
        </div>
    </div>

    <table class="form-table" style="margin:0;">
        <tr>
            <th scope="row" style="width:220px;">
                <label for="seo-gen-heartbeat-url">Heartbeat URL</label>
            </th>
            <td>
                <input type="text" id="seo-gen-heartbeat-url" readonly
                       value="<?php echo \esc_attr($heartbeat_url); ?>"
                       style="width:100%; max-width:560px; font-family:monospace; background:#f6f7f7;" />
                <button type="button" class="button button-small" data-clipboard-target="#seo-gen-heartbeat-url" style="margin-left:6px;">Copy</button>
                <p class="description" style="margin-top:6px;">
                    Ping this URL every 60 seconds. Returns <code>heartbeat: ok in 35ms — {&hellip;}</code> on success.
                </p>
            </td>
        </tr>
        <tr>
            <th scope="row" style="width:220px;">
                <label for="seo-gen-heartbeat-curl">System Cron Command</label>
            </th>
            <td>
                <input type="text" id="seo-gen-heartbeat-curl" readonly
                       value="<?php echo \esc_attr($heartbeat_curl); ?>"
                       style="width:100%; max-width:560px; font-family:monospace; background:#f6f7f7;" />
                <button type="button" class="button button-small" data-clipboard-target="#seo-gen-heartbeat-curl" style="margin-left:6px;">Copy</button>
                <p class="description" style="margin-top:6px;">
                    One-shot curl command. Test from your VPS shell first.
                </p>
            </td>
        </tr>
        <tr>
            <th scope="row" style="width:220px;">
                <label for="seo-gen-heartbeat-crontab">Crontab Entry</label>
            </th>
            <td>
                <input type="text" id="seo-gen-heartbeat-crontab" readonly
                       value="<?php echo \esc_attr($heartbeat_cron_line); ?>"
                       style="width:100%; max-width:560px; font-family:monospace; background:#f6f7f7;" />
                <button type="button" class="button button-small" data-clipboard-target="#seo-gen-heartbeat-crontab" style="margin-left:6px;">Copy</button>
                <p class="description" style="margin-top:6px;">
                    Add to <code>crontab -e</code> on your VPS — fires every minute. If you use
                    <a href="https://cron.org" target="_blank">cron.org</a> /
                    <a href="https://www.easycron.com" target="_blank">EasyCron</a>, paste the
                    Heartbeat URL above with a 1-minute schedule.
                </p>
            </td>
        </tr>
        <tr>
            <th scope="row" style="width:220px;">
                <label>Secret Token</label>
            </th>
            <td>
                <code id="seo-gen-heartbeat-secret" style="background:#f6f7f7; padding:4px 8px; border-radius:3px;">
                    <?php echo \esc_html($heartbeat_secret); ?>
                </code>
                <p class="description" style="margin-top:6px; color:#d63638;">
                    Treat this token like a password. Regenerating it invalidates the old URL.
                </p>
            </td>
        </tr>
        <tr>
            <th scope="row" style="width:220px;">
                <label for="seo-gen-heartbeat-report">Last Run Report</label>
            </th>
            <td>
                <pre id="seo-gen-heartbeat-report"
                     style="background:#f6f7f7; padding:8px 10px; border-radius:3px; font-size:11px; max-height:140px; overflow:auto; margin:0; white-space:pre-wrap; word-break:break-all;"><?php
                    echo $heartbeat_last_report !== '' ? \esc_html($heartbeat_last_report) : '(no heartbeat has fired yet)';
                ?></pre>
            </td>
        </tr>
    </table>

    <div style="background:#fff8e5;border-left:4px solid #ffb900;padding:10px 14px;margin:14px 0;border-radius:2px;">
        <strong>Cloudflare Note:</strong> The URL has query parameters
        (<code>?seo_gen_heartbeat=1&secret=...</code>), which bypass Cloudflare's static
        cache by default. If you have an aggressive page rule that strips query strings,
        add a Cloudflare Page Rule to bypass cache for the path
        <code>*softwareswave.com/*seo_gen_heartbeat*</code> — mirroring your
        <strong>WP Automatic cron URL</strong> exclusion.
    </div>

    <div style="background:#e9f5ff;border-left:4px solid #007cba;padding:10px 14px;margin:14px 0;border-radius:2px;">
        <strong>What the heartbeat covers (every 60 seconds):</strong>
        <ul style="margin:6px 0 0 18px; padding:0;">
            <li>Triggers <strong>Action Scheduler's internal runner</strong> — drains any pending AS actions (process_item, check_job, sideload_image, force_finalize, delete_draft, daily_cleanup, discovery, openrouter/zen sync) that were waiting on WP-Cron.</li>
            <li>Runs <strong>queue_worker</strong> (picks up ready jobs) — atomic lock, no overlap.</li>
            <li>Runs <strong>sync_finalizer</strong> (DB-driven deferred dispatch) — atomic lock.</li>
            <li>Runs <strong>publish_watchdog</strong> (force-publishes overdue <code>future</code> posts).</li>
            <li>Runs <strong>overdue_recovery</strong> (every 15 min internally) — recovers stuck <code>generating/finalizing/processing/deferred</code> items.</li>
            <li>Re-arms items with <strong>lost HOOK_PROCESS_ITEM</strong> AS actions (pipeline stuck-forever root cause).</li>
            <li>Fires <strong>wp_auto_draft_poll</strong> (WPA integration — same job your <code>?wp_automatic=cron</code> triggers).</li>
            <li>Fires <strong>auto_generation</strong> when ENABLE_AUTO_GENERATION=1.</li>
        </ul>
    </div>

</div>

<script>
    // ── Heartbeat controls ─────────────────────────────────────────────
    document.addEventListener('DOMContentLoaded', function() {
        // Copy-to-clipboard for any element with data-clipboard-target
        document.querySelectorAll('[data-clipboard-target]').forEach(function(btn) {
            btn.addEventListener('click', function() {
                var sel = btn.getAttribute('data-clipboard-target');
                var input = document.querySelector(sel);
                if (!input) return;
                input.select();
                input.setSelectionRange(0, 99999);
                try {
                    document.execCommand('copy');
                    var original = btn.textContent;
                    btn.textContent = '✓ Copied';
                    setTimeout(function(){ btn.textContent = original; }, 1400);
                } catch (e) {}
            });
        });

        // Test heartbeat
        var testBtn = document.getElementById('seo-gen-heartbeat-test');
        if (testBtn) {
            testBtn.addEventListener('click', function() {
                var btn = this;
                var original = btn.textContent;
                btn.disabled = true;
                btn.textContent = 'Testing…';
                var data = new FormData();
                data.append('action', 'seo_gen_test_heartbeat');
                data.append('nonce', '<?php echo \wp_create_nonce('seo_gen_nonce'); ?>');
                fetch(ajaxurl, { method: 'POST', body: data })
                    .then(function(r) { return r.json(); })
                    .then(function(res) {
                        if (res.success) {
                            var pre = document.getElementById('seo-gen-heartbeat-report');
                            if (pre) { pre.textContent = res.data.body || ''; }

                            // Update the status box live so the operator
                            // sees "0s ago" / "OK" without a page reload.
                            if (res.data.timestamp && res.data.timestamp > 0) {
                                var lastEl = document.getElementById('sgd-heartbeat-last');
                                if (lastEl) {
                                    lastEl.textContent = '0s ago';
                                    lastEl.style.color = '#2e7d32';
                                    lastEl.style.fontWeight = '600';
                                }
                                var box = document.getElementById('sgd-heartbeat-status-box');
                                if (box) {
                                    box.style.background = '#edf7ed';
                                    box.style.borderColor = '#5cb85c';
                                }
                                // Update the Endpoint: OK code tag
                                var codeTags = box ? box.querySelectorAll('code') : [];
                                for (var i = 0; i < codeTags.length; i++) {
                                    if (codeTags[i].textContent === 'Awaiting first ping') {
                                        codeTags[i].textContent = 'OK';
                                    }
                                }
                            }

                            alert(res.data.message || 'Heartbeat test complete.');
                        } else {
                            alert('Heartbeat test failed: ' + (res.data.message || 'Unknown error.'));
                        }
                    })
                    .catch(function() { alert('Network error during heartbeat test.'); })
                    .finally(function() {
                        btn.disabled = false;
                        btn.textContent = original;
                    });
            });
        }

        // Regenerate secret
        var regenBtn = document.getElementById('seo-gen-heartbeat-regen');
        if (regenBtn) {
            regenBtn.addEventListener('click', function() {
                if (!confirm('Regenerate heartbeat secret? Your existing crontab URL will stop working until you update it.')) return;
                var btn = this;
                var original = btn.textContent;
                btn.disabled = true;
                btn.textContent = 'Regenerating…';
                var data = new FormData();
                data.append('action', 'seo_gen_regenerate_heartbeat_secret');
                data.append('nonce', '<?php echo \wp_create_nonce('seo_gen_nonce'); ?>');
                fetch(ajaxurl, { method: 'POST', body: data })
                    .then(function(r) { return r.json(); })
                    .then(function(res) {
                        if (res.success) {
                            if (res.data.url) {
                                var urlInput = document.getElementById('seo-gen-heartbeat-url');
                                if (urlInput) urlInput.value = res.data.url;
                                var curlInput = document.getElementById('seo-gen-heartbeat-curl');
                                if (curlInput && res.data.command) curlInput.value = res.data.command;
                                var cronInput = document.getElementById('seo-gen-heartbeat-crontab');
                                if (cronInput && res.data.command) cronInput.value = '* * * * * ' + res.data.command + ' >/dev/null 2>&1';
                            }
                            if (res.data.secret) {
                                var secretEl = document.getElementById('seo-gen-heartbeat-secret');
                                if (secretEl) secretEl.textContent = res.data.secret;
                            }
                            alert(res.data.message || 'Secret regenerated. Update your crontab with the new URL.');
                        } else {
                            alert('Regeneration failed: ' + (res.data.message || 'Unknown error.'));
                        }
                    })
                    .catch(function() { alert('Network error during regeneration.'); })
                    .finally(function() {
                        btn.disabled = false;
                        btn.textContent = original;
                    });
            });
        }
    });
</script>

<script>
    function renderWpAutoSnapshot(snapshot) {
        if (!snapshot || typeof snapshot !== 'object') {
            return;
        }

        var stateEl = document.getElementById('sgd-wpauto-state');
        var nextEl = document.getElementById('sgd-wpauto-next-poll');
        var pendingEl = document.getElementById('sgd-wpauto-pending');
        var boxEl = document.getElementById('sgd-wpauto-status-box');

        if (stateEl) {
            stateEl.textContent = snapshot.label || 'Unknown';
            stateEl.style.color = snapshot.scheduled ? '#2e7d32' : '#b26a00';
        }

        if (nextEl) {
            if (snapshot.next_poll_overdue) {
                nextEl.textContent = (snapshot.next_poll_text || 'Now') + ' (running late)';
                nextEl.style.color = '#b26a00';
            } else {
                nextEl.textContent = snapshot.next_poll_text || 'Not scheduled';
                nextEl.style.color = '';
            }
        }

        if (pendingEl) {
            pendingEl.textContent = parseInt(snapshot.pending_drafts || 0, 10);
        }

        if (boxEl) {
            boxEl.style.background = snapshot.configured ? '#edf7ed' : '#fff3e0';
            boxEl.style.borderColor = snapshot.scheduled ? '#5cb85c' : '#ff9800';
        }
    }

    function pollWpAutoSnapshot() {
        var data = new FormData();
        data.append('action', 'seogen_wp_auto_snapshot');
        data.append('nonce', '<?php echo \wp_create_nonce('seo_gen_nonce'); ?>');

        fetch(ajaxurl, { method: 'POST', body: data })
            .then(function(r){ return r.json(); })
            .then(function(res){
                if (res.success && res.data && res.data.snapshot) {
                    renderWpAutoSnapshot(res.data.snapshot);
                }
            });
    }

    document.getElementById('seo-gen-wp-auto-settings-form').addEventListener('submit', function(e) {
        e.preventDefault();
        var form = this;
        var status = document.getElementById('seo-gen-wp-auto-status');
        var btn = document.getElementById('seo-gen-save-wp-auto');
        btn.disabled = true;
        btn.textContent = 'Saving…';

        var data = new FormData(form);
        data.append('action', 'seo_gen_save_wp_auto_settings');
        data.append('nonce', '<?php echo \wp_create_nonce('seo_gen_nonce'); ?>');

        fetch(ajaxurl, {
                method: 'POST',
                body: data
            })
            .then(r => r.json())
            .then(function(res) {
                status.style.display = 'inline';
                if (res.success) {
                    status.style.color = '#2e7d32';
                    status.textContent = res.data.message || 'Saved.';
                    if (res.data.snapshot) {
                        renderWpAutoSnapshot(res.data.snapshot);
                    }
                } else {
                    status.style.color = '#c62828';
                    status.textContent = res.data.message || 'Save failed.';
                }
            })
            .catch(function() {
                status.style.display = 'inline';
                status.style.color = '#c62828';
                status.textContent = '✗ Network error.';
            })
            .finally(function() {
                btn.disabled = false;
                btn.textContent = 'Save Settings';
            });
    });

    // WP Auto Poll Now
    var pollBtn = document.getElementById('seo-gen-wp-auto-poll-now');
    if (pollBtn) {
        pollBtn.addEventListener('click', function() {
            var btn = this;
            var originalText = btn.textContent;
            btn.disabled = true;
            btn.textContent = 'Polling…';

            var data = new FormData();
            data.append('action', 'seo_gen_trigger_wp_auto_poll');
            data.append('nonce', '<?php echo \wp_create_nonce('seo_gen_nonce'); ?>');

            fetch(ajaxurl, { method: 'POST', body: data })
                .then(r => r.json())
                .then(function(res) {
                    if (res.success) {
                        if (res.data.snapshot) {
                            renderWpAutoSnapshot(res.data.snapshot);
                        }
                        alert(res.data.message || 'Poll completed.');
                    } else {
                        var errMsg = res.data.message || 'Unknown error.';
                        if (res.data.diagnostics) {
                            var diag = res.data.diagnostics;
                            var details = [];
                            if (diag.hint) details.push('Hint: ' + diag.hint);
                            if (diag.bootstrap_block && diag.bootstrap_block.retry_after_utc) {
                                details.push('Block expires (UTC): ' + diag.bootstrap_block.retry_after_utc);
                            }
                            if (diag.last_reason) details.push('Reason: ' + diag.last_reason);
                            if (details.length) {
                                errMsg += '\n\nDiagnostics:\n' + details.join('\n');
                            }
                        }
                        alert('Poll failed: ' + errMsg);
                    }
                })
                .catch(() => alert('Network error during poll.'))
                .finally(() => {
                    btn.disabled = false;
                    btn.textContent = originalText;
                });
        });
    }

    // WP Auto Clear Log
    var clearBtn = document.getElementById('seo-gen-wp-auto-clear-log');
    if (clearBtn) {
        clearBtn.addEventListener('click', function() {
            if (!confirm('Clear processed history? Active drafts might be re-processed.')) return;
            
            var btn = this;
            var originalText = btn.textContent;
            btn.disabled = true;
            btn.textContent = 'Clearing…';

            var data = new FormData();
            data.append('action', 'seo_gen_clear_wp_auto_log');
            data.append('nonce', '<?php echo \wp_create_nonce('seo_gen_nonce'); ?>');

            fetch(ajaxurl, { method: 'POST', body: data })
                .then(r => r.json())
                .then(function(res) {
                    if (res.success) {
                        if (res.data.snapshot) {
                            renderWpAutoSnapshot(res.data.snapshot);
                        }
                        alert(res.data.message || 'History cleared.');
                    } else {
                        alert('Failed to clear log: ' + (res.data.message || 'Unknown error.'));
                    }
                })
                .catch(() => alert('Network error.'))
                .finally(() => {
                    btn.disabled = false;
                    btn.textContent = originalText;
                });
        });
    }

    // Start lightweight polling when the tab is present
    setInterval(pollWpAutoSnapshot, 15000);
</script>
