package com.snsaver.app.ui.screens.settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.snsaver.app.data.preferences.AppPreferences
import com.snsaver.app.domain.repository.DownloadRepository
import com.snsaver.app.util.FileHelper
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject
data class SettingsState(val endpoint:String="",val key:String="",val gallery:Boolean=true,val theme:String="system",val bytes:Long=0)
@HiltViewModel class SettingsViewModel @Inject constructor(private val p:AppPreferences,private val files:FileHelper,private val repo:DownloadRepository):ViewModel(){val state=combine(p.apiEndpoint,p.apiKey,p.saveToGallery,p.theme){a,b,c,d->SettingsState(a,b,c,d,files.size())}.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),SettingsState());fun endpoint(v:String)=viewModelScope.launch{p.endpoint(v)};fun key(v:String)=viewModelScope.launch{p.apiKey(v)};fun gallery(v:Boolean)=viewModelScope.launch{p.gallery(v)};fun theme(v:String)=viewModelScope.launch{p.theme(v)};fun clear()=viewModelScope.launch{repo.observeAll().first().flatMap{it.downloadedFiles}.forEach(files::delete);repo.deleteAll()}}
@OptIn(ExperimentalMaterial3Api::class) @Composable fun SettingsScreen(onBack:()->Unit,vm:SettingsViewModel=hiltViewModel()){val s by vm.state.collectAsStateWithLifecycle();var confirm by remember{mutableStateOf(false)};if(confirm)AlertDialog({confirm=false},title={Text("Clear downloads?")},text={Text("App copies and metadata will be deleted. Gallery copies remain.")},confirmButton={TextButton({confirm=false;vm.clear()}){Text("Clear")}},dismissButton={TextButton({confirm=false}){Text("Cancel")}});Scaffold(topBar={TopAppBar({Text("Settings",style=MaterialTheme.typography.headlineMedium)},navigationIcon={IconButton(onBack){Icon(Icons.AutoMirrored.Filled.ArrowBack,null)}})}){pad->Column(Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Header("Extractor");OutlinedTextField(s.endpoint,vm::endpoint,Modifier.fillMaxWidth(),label={Text("Cobalt endpoint")},singleLine=true);OutlinedTextField(s.key,vm::key,Modifier.fillMaxWidth(),label={Text("API key (optional)")},visualTransformation=PasswordVisualTransformation(),singleLine=true);Header("Downloads");SettingSwitch("Save to Gallery","Keep a second copy in Pictures or Movies",s.gallery,vm::gallery);Header("Appearance");Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf("system","dark","light").forEach{FilterChip(s.theme==it,{vm.theme(it)},{Text(it.replaceFirstChar(Char::uppercase))})}};Header("Storage");Text("App storage: ${format(s.bytes)}");OutlinedButton({confirm=true},Modifier.fillMaxWidth()){Text("Clear all downloads")};Header("About");Card{Column(Modifier.padding(16.dp)){Text("SNSaver",style=MaterialTheme.typography.titleLarge);Text("Version 1.0.0");Spacer(Modifier.height(8.dp));Text("Download only media you have permission to save. Platform terms and creators’ rights still apply.",color=MaterialTheme.colorScheme.onSurfaceVariant)}}}}}
@Composable private fun Header(v:String)=Text(v,color=MaterialTheme.colorScheme.primary,style=MaterialTheme.typography.titleSmall)
@Composable private fun SettingSwitch(t:String,d:String,v:Boolean,f:(Boolean)->Unit)=Card{Row(Modifier.fillMaxWidth().padding(14.dp)){Column(Modifier.weight(1f)){Text(t);Text(d,style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)};Switch(v,f)}}
private fun format(v:Long)=if(v<1048576)"%.1f KB".format(v/1024.0) else "%.1f MB".format(v/1048576.0)
