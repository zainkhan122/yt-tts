<?php

namespace SEO_Article_Generator\Tools;


if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sentinel_Fallback_Utility
 *
 * Shared audit engine for post HTML integrity. Used by:
 * - Sentinel_Injector (backfill gate)
 * - Post_Content_Integrity_Guard (pre-publish gate)
 * - Surgical_Patcher (optional debugging)
 *
 * FATAL checks (will block save): duplicate sentinels, duplicate HTML IDs.
 * WARNING checks (logged only, do NOT block): stale TOC anchors, FAQ structure, cross-post links.
 *
 * @since 2.33.0
 */
final class Sentinel_Fallback_Utility {

	public static function normalize_zone_key( string $key ): string {
		if ( class_exists( '\SEO_Article_Generator\Generator\Article_Schema' ) ) {
			$canonical = \SEO_Article_Generator\Generator\Article_Schema::get_canonical_key( $key );
			if ( is_string( $canonical ) && $canonical !== '' ) {
				return $canonical;
			}
		}

		return strtolower( trim( $key ) );
	}

	/**
	 * Normalize → retrofit sentinels → audit. Returns full result for injectors.
	 *
	 * @param string $html Raw post_content.
	 * @param string[] $required_sections Optional zone keys to pass to Content_Normalizer.
	 * @param array $context Optional audit context, e.g. [ 'is_update' => true ].
	 * @return array{changed:bool, content:string, repairs:array, injected:array, already_present:array, not_found:array, audit:array}
	 */
	public static function repair_and_audit( string $html, array $required_sections = [], array $context = array() ): array {
		$original = $html;
		$repairs = [];

		// FIX: Detect and strip corrupted/empty/self-closing SECTION blocks before normalization.
		// Self-closing or immediately closed section blocks indicate a failed previous migration
		// (clustering at top of document). Strip all section sentinels to force a clean rebuild from structural IDs.
		// SCOPED: Only match self-closing wp:seo-gen/section blocks, NOT other self-closing blocks
		// like <!-- wp:seo-gen/hero /--> which is valid and should not trigger the strip logic.
		$has_self_closing = preg_match( '/<!--\s*wp:seo-gen\/section\s+\{[^}]*"zone"\s*:\s*"[a-z0-9_-]+"[^}]*\}\s*\/-->/im', $html );
		$has_empty_blocks = preg_match( '/<!--\s*wp:seo-gen\/section\s+\{[^}]*"zone"\s*:\s*"[a-z0-9_-]+"[^}]*\}\s*-->\s*<!--\s*\/wp:seo-gen\/section\s*-->/is', $html );

		if ( $has_self_closing || $has_empty_blocks ) {
			$html = preg_replace( '/<!--\s*wp:seo-gen\/section\s+\{[^}]*"zone"\s*:\s*"[a-z0-9_-]+"[^}]*\}\s*-->/is', '', $html );
			$html = preg_replace( '/<!--\s*\/wp:seo-gen\/section\s*-->/i', '', $html );
		}

		if ( class_exists( '\SEO_Article_Generator\Content\Content_Normalizer' ) ) {
			if ( class_exists( '\SEO_Article_Generator\Generator\Article_Schema' ) ) {
				$zone_keys = ! empty( $required_sections )
					? \SEO_Article_Generator\Generator\Article_Schema::normalize_sections( $required_sections )
					: \SEO_Article_Generator\Generator\Article_Schema::get_ordered_section_keys();
			} else {
				$zone_keys = ! empty( $required_sections ) ? $required_sections : [];
			}

			$normalized = \SEO_Article_Generator\Content\Content_Normalizer::normalize( $html, $zone_keys );
			$html = (string) ( $normalized['normalized_html'] ?? $html );
			$repairs = (array) ( $normalized['repairs'] ?? [] );
		}

		// Determine whether upgrade was actually needed before running it.
		$already_has_blocks = strpos( $html, '<!-- wp:seo-gen/section ' ) !== false;

		[ , $html ] = Sentinel_Injector::upgrade_legacy_html_to_blocks( $html );

		if ( strpos( $html, '<!-- wp:seo-gen/section ' ) === false ) {
			return [
				'changed' => false,
				'migration_attempted' => ! $already_has_blocks,
				'content' => $html,
				'repairs' => $repairs,
				'injected' => [],
				'already_present' => [],
				'not_found' => [],
				'audit' => [
					'duplicate_sentinels' => [],
					'duplicate_ids' => [],
					'stale_toc_anchors' => [],
					'faq_issues' => [],
					'cross_post_links' => [],
					'is_clean' => false,
					'fatal_reasons' => $already_has_blocks ? [] : [ 'upgrade_produced_no_block_delimiters' ],
					'warnings' => [],
				],
			];
		}

		// CRITICAL FIX: Validate zone coverage after repair.
		// Even if upgrade succeeded, we need to ensure the zones we need are actually present.
		// This catches the case where empty sentinels were at top and real content elsewhere.
		if ( class_exists( '\SEO_Article_Generator\Generator\Article_Schema' ) ) {
			$all_zones = \SEO_Article_Generator\Generator\Article_Schema::get_ordered_section_keys();

			// Check which zones are actually in the upgraded content (have real content)
			$zones_present = array_values( array_filter( $all_zones, static function ( $z ) use ( $html ) {
				return \SEO_Article_Generator\Generator\Surgical_Patcher::find_zone( $html, $z ) !== false;
			} ) );

			$missing_zones = array_values( array_diff( $all_zones, $zones_present ) );

			// If required_sections were passed, check those specifically
			if ( ! empty( $required_sections ) ) {
				$missing_required = array_values( array_diff( $required_sections, $zones_present ) );
				if ( ! empty( $missing_required ) ) {
					// Add warning but don't fail - the content may still be patchable
					$repairs['missing_required_zones'] = $missing_required;
				}
			}
		}

		$audit = self::audit( $html, $context );

		// Since retrofit logic is now migration-only, we don't track 'injected' vs 'already_present' separately
		return [
			'changed' => $html !== $original,
			'migration_attempted' => ! $already_has_blocks,
			'content' => $html,
			'repairs' => $repairs,
			'injected' => [],
			'already_present' => [],
			'not_found' => [],
			'audit' => $audit,
		];
	}

	/**
	 * Audit post HTML and return categorised results.
	 *
	 * Fatal reasons (array): conditions that must block publishing.
	 * is_clean (bool): true only when fatal array is empty.
	 *
	 * @return array{duplicate_sentinels:array, duplicate_ids:array, stale_toc_anchors:array, faq_issues:array, cross_post_links:array, is_clean:bool, fatal_reasons:array, warnings:array}
	 */
	public static function audit( string $html, array $context = array() ): array {
		$is_update = ! empty( $context['is_update'] );
		$duplicate_sentinels = self::find_duplicate_sentinels( $html );
		$duplicate_ids = self::find_duplicate_ids( $html );
		$stale_toc_anchors = self::find_stale_toc_anchors( $html );
		$faq_issues = self::find_faq_issues( $html );
		$cross_post_links = self::find_cross_post_links( $html );

		// Only structural corruption is fatal — TOC/link issues are warnings
		$fatal = [];
		$warnings = [];

		if ( ! empty( $duplicate_sentinels ) ) {
			$fatal[] = 'duplicate_sentinels';
		}
		if ( ! empty( $duplicate_ids ) ) {
			$fatal[] = 'duplicate_ids';
		}
		// Stale anchors: warning only — IDs may exist in shortcodes/hero outside post_content
		if ( ! empty( $stale_toc_anchors ) ) {
			$warnings[] = 'stale_toc_anchors';
		}
		// FAQ issues: warning only — structural but recoverable
		if ( ! empty( $faq_issues ) ) {
			$warnings[] = 'faq_structure';
		}
		// Cross-post links are ALWAYS warnings.
		// Same-site deep links found in content are not treated as structural corruption here.
		// Current generation no longer injects internal links, but legacy content or other plugins
		// may still contain same-site links, so they remain warning-only.
		if ( ! empty( $cross_post_links ) ) {
			$warnings[] = 'cross_post_links';
		}

		return [
			'duplicate_sentinels' => $duplicate_sentinels,
			'duplicate_ids' => $duplicate_ids,
			'stale_toc_anchors' => $stale_toc_anchors,
			'faq_issues' => $faq_issues,
			'cross_post_links' => $cross_post_links,
			'is_clean' => empty( $fatal ),
			'fatal_reasons' => $fatal,
			'warnings' => $warnings,
		];
	}

	/**
	 * Quick publishability check (audit-only, no repair).
	 */
	public static function is_publishable( string $html, array $context = array() ): array {
		$audit = self::audit( $html, $context );
		return [
			'ok' => ! empty( $audit['is_clean'] ),
			'audit' => $audit,
			'fatal_reasons' => (array) ( $audit['fatal_reasons'] ?? [] ),
		];
	}

	// ─── Private audit methods ─────────────────────────────────────────────────

	private static function find_duplicate_sentinels( string $html ): array {
		$counts = [];

		// Format 1: wp:seo-gen/section block sentinels — both normal and self-closing.
		// Normal:  <!-- wp:seo-gen/section {"zone":"zonename"} -->
		// Self-closing: <!-- wp:seo-gen/section {"zone":"zonename"} /-->
		// Single unified regex: the (\/?) captures optional slash before -->.
		// Each sentinel is counted exactly once — no double-counting.
		preg_match_all(
			'/<!--\s*wp:seo-gen\/section\s+\{[^}]*"zone"\s*:\s*"([a-z0-9_-]+)"[^}]*\}\s*(\/?)->/i',
			$html,
			$m1
		);
		foreach ( $m1[1] ?? [] as $zone ) {
			$key = self::normalize_zone_key( (string) $zone );
			if ( '' === $key ) {
				continue;
			}
			$counts[ $key ] = ( $counts[ $key ] ?? 0 ) + 1;
		}

		// Format 2: Legacy HTML comment sentinel — <!-- seo-gen-zone:name -->
		preg_match_all(
			'/<!--\s*seo-gen-zone:([a-z0-9_-]+)\s*-->/i',
			$html,
			$m2
		);
		foreach ( $m2[1] ?? [] as $zone ) {
			$key = self::normalize_zone_key( (string) $zone );
			if ( '' === $key ) {
				continue;
			}
			$counts[ $key ] = ( $counts[ $key ] ?? 0 ) + 1;
		}

		return array_keys( array_filter( $counts, static fn( int $c ): bool => $c > 1 ) );
	}

	private static function find_duplicate_ids( string $html ): array {
		preg_match_all( '/\sid=(["\'])([^"\']+)\1/i', $html, $m );
		$counts = [];
		foreach ( (array) ( $m[2] ?? [] ) as $id ) {
			$key = strtolower( trim( (string) $id ) );
			if ( $key === '' ) {
				continue;
			}
			$counts[ $key ] = ( $counts[ $key ] ?? 0 ) + 1;
		}
		return array_keys( array_filter( $counts, static fn( $c ) => $c > 1 ) );
	}

	private static function find_stale_toc_anchors( string $html ): array {
		preg_match_all( '/href=(["\'])[^"\']*#([^"\']+)\1/i', $html, $hrefs );
		preg_match_all( '/\sid=(["\'])([^"\']+)\1/i', $html, $ids );

		$id_map = [];
		foreach ( (array) ( $ids[2] ?? [] ) as $id ) {
			$id_map[ strtolower( trim( (string) $id ) ) ] = true;
		}

		$stale = [];
		foreach ( (array) ( $hrefs[2] ?? [] ) as $anchor ) {
			$key = strtolower( trim( (string) $anchor ) );
			if ( $key !== '' && empty( $id_map[ $key ] ) ) {
				$stale[] = $key;
			}
		}
		return array_values( array_unique( $stale ) );
	}

	private static function find_faq_issues( string $html ): array {
		$issues = [];
		$faq_block_count = (int) preg_match_all( '/wp-block-rank-math-faq-block/i', $html );
		$question_count = (int) preg_match_all( '/rank-math-question/i', $html );
		$answer_count = (int) preg_match_all( '/rank-math-answer/i', $html );

		if ( $faq_block_count > 0 && $question_count === 0 ) {
			$issues[] = 'faq_block_without_questions';
		}
		if ( $question_count !== $answer_count ) {
			$issues[] = 'faq_question_answer_mismatch';
		}
		return $issues;
	}

	private static function find_cross_post_links( string $html ): array {
		$site_url = function_exists( 'home_url' ) ? home_url() : '';
		if ( '' === $site_url ) {
			return [];
		}
		$site_host = (string) wp_parse_url( $site_url, PHP_URL_HOST );
		if ( '' === $site_host ) {
			return [];
		}
		preg_match_all( '/href=(["\'])(https?:\/\/[^"\']+)\1/i', $html, $m );
		$cross = [];
		foreach ( (array) ( $m[2] ?? [] ) as $url ) {
			$host = (string) wp_parse_url( (string) $url, PHP_URL_HOST );
			if ( $host === $site_host && ! in_array( $url, $cross, true ) ) {
				$cross[] = (string) $url;
			}
		}
		return $cross;
	}
}
