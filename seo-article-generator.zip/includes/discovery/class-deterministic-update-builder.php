<?php
namespace SEO_Article_Generator\Discovery;

defined('ABSPATH') || exit;

final class Deterministic_Update_Builder
{
    /** @var mixed */
    private $logger;

    public function __construct($logger = null)
    {
        $this->logger = $logger;
    }

    public function build_from_source($item, \WP_Post $existing_post = null, array $link_resolution = array(), array $source_facts = array()): array
    {
        $approved_links = $link_resolution['links'] ?? array();

        if (class_exists('\SEO_Article_Generator\Integration\Link_Resolver')) {
            $bundle = \SEO_Article_Generator\Integration\Link_Resolver::build_canonical_bundle(
                $approved_links,
                array(
                    'source_url'     => (string) ($item->source_url ?? ''),
                    'software_name'  => (string) ($item->software_name ?? ''),
                )
            );
        } else {
            $bundle = array(
                'primary_download_url' => '',
                'download_count'       => count($approved_links),
                'all_links'            => $approved_links,
                'platform_matrix'      => array(),
                'portable_links'       => array(),
                'store_links'          => array(),
                'direct_links'         => array(),
                'os_support'           => '',
            );
        }

	$existing_hero = $existing_post ? \SEO_Article_Generator\Plugin::get_instance()->get_hero_data($existing_post->ID) : array();
        if (! is_array($existing_hero)) {
            $existing_hero = array();
        }

        $software_name = (string) ($item->software_name ?? ($existing_hero['software_name'] ?? ''));
        $version       = (string) ($item->discovered_version ?? ($existing_hero['version'] ?? ''));
        $source_url    = (string) ($item->source_url ?? '');
		$homepage = (string) ($source_facts['homepage_url'] ?? $source_url);
		$changelog_url = (string) ($source_facts['changelog_url'] ?? '');
		$file_size = (string) ($source_facts['file_size'] ?? ($existing_hero['file_size'] ?? ''));
        $developer     = (string) ($source_facts['developer'] ?? ($existing_hero['developer'] ?? ''));
        $license       = (string) ($source_facts['license'] ?? ($existing_hero['license'] ?? ''));
        $last_updated  = (string) ($source_facts['last_updated'] ?? \wp_date('F j, Y'));
        $os_support    = (string) ($bundle['os_support'] ?? ($source_facts['os_support'] ?? ''));

	$download_links = array();
	foreach (($bundle['all_links'] ?? array()) as $row) {
		$download_links[] = array(
			'platform' => (string) ($row['platform'] ?? ''),
			'url' => (string) ($row['url'] ?? ''),
			'variant' => (string) ($row['variant'] ?? ''),
			'file_type' => (string) ($row['file_type'] ?? ''),
			'version' => (string) ($row['version'] ?? ''),
			'channel' => (string) ($row['channel'] ?? ''),
			'text' => (string) ($row['text'] ?? ''),
			'is_primary' => ! empty($row['is_primary']),
		);
	}

	$tech_specs = array(
		'software_name' => $software_name,
		'version' => $version,
		'homepage' => $homepage,
		'changelogurl' => $changelog_url,
		'file_size' => $file_size,
            'developer'     => $developer,
            'license'       => $license,
            'last_updated'  => $last_updated,
            'os_support'    => $os_support,
        );

        $download_section = array(
            'title'      => 'Download',
            'os_support' => $os_support,
            'links'      => $download_links,
        );

        $hero_data = array_merge($existing_hero, array(
            'software_name'   => $software_name,
            'version'         => $version,
            'file_size'       => $file_size,
            'developer'       => $developer,
            'license'         => $license,
            'download_url'    => (string) ($bundle['primary_download_url'] ?? ''),
            'download_links'  => $download_links,
            'homepage_url'    => $homepage,
            'os_support'      => $os_support,
            'last_updated'    => $last_updated,
            'last_verified_date' => \wp_date('Y-m-d'),
        ));

        return array(
            'tech_specs'        => $tech_specs,
            'download_section'  => $download_section,
            'hero_data'         => $hero_data,
            'required_zones'    => array('download', 'tech_specs'),
            'patch_sections'    => array('download', 'tech_specs'),
            'ai_owned_sections' => array('whats_new', 'features', 'moat'),
            'post_title'        => $this->build_post_title($existing_post ? $existing_post->post_title : '', $software_name, $version),
            'source_facts'      => $source_facts,
            'bundle'            => $bundle,
        );
    }

    private function build_post_title(string $existing_title, string $software_name, string $version): string
    {
        $clean_name = trim($software_name);
        $clean_ver  = trim($version);

        if ($clean_name === '' || $clean_ver === '') {
            return $existing_title;
        }

        if ($existing_title !== '' && preg_match('/\b\d+(?:\.\d+)+(?:\.\d+)?\b/', $existing_title)) {
            return preg_replace('/\b\d+(?:\.\d+)+(?:\.\d+)?\b/', $clean_ver, $existing_title, 1);
        }

        return $clean_name . ' ' . $clean_ver;
    }
}
