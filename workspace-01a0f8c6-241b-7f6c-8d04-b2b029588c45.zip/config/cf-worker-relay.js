/**
 * DIT Fashion Posts Generator — Sanaulla feed relay (Cloudflare Worker)
 * --------------------------------------------------------------------
 * WHY: the live host's IP gets bot-scored by Sanaulla's Cloudflare sometimes.
 * This Worker fetches the feeds from Cloudflare's own edge — the most
 * block-resistant free route that exists — and you OWN it (no third party,
 * no credits, no terms that can change).
 *
 * FREE PLAN LIMITS: 100,000 requests/day (we need ~85/day). No card needed.
 *
 * DEPLOY (10 minutes, one time):
 *   1. workers.cloudflare.com -> Create application -> Create Worker (name: dit-relay)
 *   2. Edit code -> paste this ENTIRE file -> change SECRET below -> Deploy
 *   3. Test in a browser:
 *      https://dit-relay.<your-subdomain>.workers.dev/relay/SECRET/?url=https://sanaullastore.com/collections/mushq/products.json?limit=250
 *      (must show raw JSON)
 *   4. WordPress -> Settings -> DIT Fashion PG -> Proxy fallback:
 *      Primary = "Custom relay / own Worker"
 *      Template = https://dit-relay.<your-subdomain>.workers.dev/relay/SECRET/?url={URL}
 *      (leave the key field empty — the SECRET in the URL is the credential)
 */

const SECRET = 'CHANGE-THIS-to-a-long-random-string'; // anyone holding it can use your worker

const ALLOWED_HOSTS = new Set([
  'sanaullastore.com', // the ONLY host this relay will ever fetch — never an open proxy
]);

export default {
  async fetch(request) {
    const url = new URL(request.url);

    // gate 1: secret path
    if (url.pathname !== '/relay/' + SECRET + '/') {
      return new Response('not found', { status: 404 });
    }

    // gate 2: required target
    const target = url.searchParams.get('url');
    if (!target) {
      return new Response('missing url parameter', { status: 400 });
    }
    let t;
    try {
      t = new URL(target);
    } catch (e) {
      return new Response('bad url', { status: 400 });
    }

    // gate 3: host allowlist
    if (!ALLOWED_HOSTS.has(t.hostname)) {
      return new Response('host not allowed', { status: 403 });
    }

    // fetch like a browser
    const r = await fetch(t.toString(), {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36',
        'Accept': 'application/json,text/plain,*/*',
      },
    });

    return new Response(r.body, {
      status: r.status,
      headers: {
        'Content-Type': 'application/json',
        'Cache-Control': 'public, max-age=300', // identical requests within 5 min are free
      },
    });
  },
};
