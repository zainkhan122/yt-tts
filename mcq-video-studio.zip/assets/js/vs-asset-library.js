/**
 * NM Asset Library Manager
 * Handles reusable assets (backgrounds, fonts, brand presets)
 *
 * @package WP_News_MCQ_Generator
 * @version 1.0.0
 */

(function (window) {
  "use strict";

  const MCQVS_AssetLibrary = {
    _storageKey: "mcqvs_asset_library",
    assets: {
      backgrounds: [], // { id, name, url, type: 'image'|'video' }
      fonts: [], // { id, name, family }
    },

    /**
     * Initialize the library from storage (prefers server, falls back to local)
     */
    init: async function () {
      // 1. Try local cache first for speed
      const saved = localStorage.getItem(this._storageKey);
      if (saved) {
        try {
          this.assets = JSON.parse(saved);
        } catch (e) { }
      }

      // 2. Fetch fresh data from server (mcqvsStudioConfig is new name, fallback is handled if missing)
      const config = window.MCQVSConfig || window.mcqvsStudioConfig;
      if (!config) {
        console.warn('MCQVS: Studio Config missing. Asset library may fail to load default assets.');
      }
      if (config) {
        try {
          const response = await jQuery.post(config.ajaxurl, {
            action: "mcqvs_get_studio_assets",
            nonce: config.nonce,
          });

          if (response.success && response.data.assets) {
            this.assets = JSON.parse(response.data.assets);
            localStorage.setItem(this._storageKey, response.data.assets);
            console.log("[NM AssetLibrary] Synced with server");
          }
        } catch (e) {
          console.error("[NM AssetLibrary] Server sync failed", e);
        }
      }
    },

    /**
     * Add an asset to the library
     */
    add: function (category, asset) {
      if (!this.assets[category]) {
        this.assets[category] = [];
      }

      if (this.assets[category].some((a) => a.url === asset.url)) {
        return false;
      }

      this.assets[category].push(asset);
      this.persist();
      return true;
    },

    /**
     * Remove an asset from the library
     */
    remove: function (category, id) {
      if (this.assets[category]) {
        this.assets[category] = this.assets[category].filter(
          (a) => a.id !== id
        );
        this.persist();
      }
    },

    /**
     * Get all assets in a category
     */
    getAll: function (category) {
      return this.assets[category] || [];
    },

    /**
     * Persist assets to localStorage AND server
     */
    persist: function () {
      const data = JSON.stringify(this.assets);
      localStorage.setItem(this._storageKey, data);

      const config = window.MCQVSConfig || window.mcqvsStudioConfig;
      if (config) {
        jQuery.post(config.ajaxurl, {
          action: "mcqvs_save_studio_assets",
          nonce: config.nonce,
          assets: data,
        });
      }
    },
  };

  // Initialize immediately
  // @MODIFIED 2026-02-04: Removed auto-init to prevent race condition with Config.
  // Explicitly called by studio.controller.js
  // MCQVS_AssetLibrary.init();
  window.MCQVS_AssetLibrary = MCQVS_AssetLibrary;
})(window);
