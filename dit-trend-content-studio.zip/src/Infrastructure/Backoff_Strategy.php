<?php

/**
 * Adaptive Backoff Strategy
 *
 * Context-aware delay calculation replacing 4 scattered backoff formulas.
 * Takes parsed error info + quota state as inputs to produce optimal delays.
 *
 * @package DIT_TrendStudio
 * @since 2026-04-22
 */

namespace DIT\TrendStudio\Infrastructure;

if (!defined('ABSPATH')) {
    exit;
}

class Backoff_Strategy
{
    /**
     * Calculate the optimal delay for a rate-limited retry.
     *
     * @param array $error_info  Parsed error from API_Error_Parser
     * @param array $quota_health Health data from Quota_State_Manager::get_health()
     * @param int   $attempt     Current retry attempt number (1-based)
     * @return int  Delay in seconds
     */
    public static function calculate(array $error_info, array $quota_health = [], int $attempt = 1): int
    {
        $error_type = $error_info['error_type'] ?? 'unknown_429';
        $api_delay = (int) ($error_info['retry_delay'] ?? 0);
        $reset_at = (int) ($error_info['reset_at'] ?? 0);
        $bucket = $error_info['quota_bucket'] ?? API_Error_Parser::UNKNOWN;
        $is_quota_zero = !empty($error_info['is_quota_zero']);

        if ($is_quota_zero) {
            return 0;
        }

        switch ($error_type) {
            case 'daily_quota':
                return self::for_daily_quota($reset_at, $attempt);

            case 'rpm_burst':
                return self::for_rpm_burst($api_delay, $attempt, $quota_health);

            case 'tpm_exceeded':
                return self::for_tpm($api_delay, $attempt);

            case 'rpm_sustained':
                return self::for_rpm_sustained($api_delay, $attempt, $quota_health);

            // @MODIFIED 2026-04-29 - Handle 503 Service Unavailable (high demand)
            case 'service_unavailable':
                return self::for_service_unavailable($api_delay, $attempt);

            default:
                return self::for_unknown($api_delay, $attempt);
        }
    }

    /**
     * Get the AI_Exception reason string for a given error type.
     * Maps API_Error_Parser error_type → Scheduler's expected reason values.
     */
    public static function get_reason(array $error_info): string
    {
        $error_type = $error_info['error_type'] ?? 'unknown_429';

        $map = [
            'daily_quota' => 'daily_quota_exhausted',
            'rpm_burst' => 'rate_limit_retry',
            'rpm_sustained' => 'rate_limit_retry',
            'tpm_exceeded' => 'rate_limit_retry',
            'quota_zero' => 'model_quota_zero',
            'unknown_429' => 'rate_limit_retry',
            // @MODIFIED 2026-04-29 - Handle 503 Service Unavailable (high demand)
            'service_unavailable' => 'rate_limit_retry',
        ];

        return $map[$error_type] ?? 'rate_limit_retry';
    }

    /**
     * Should this error trigger a full provider pause (vs just a retry)?
     */
    public static function should_pause(array $error_info, int $consecutive_count): bool
    {
        $error_type = $error_info['error_type'] ?? 'unknown_429';
        $api_delay = (int) ($error_info['retry_delay'] ?? 0);

        if ($error_type === 'daily_quota') {
            return ($api_delay >= 300) ? ($consecutive_count >= 2) : ($consecutive_count >= 3);
        }
        if ($error_type === 'rpm_sustained') {
            return $consecutive_count >= 3;
        }

        return false;
    }

    private static function for_daily_quota(int $reset_at, int $attempt): int
    {
        if ($reset_at > time()) {
            return max(300, $reset_at - time() + 120);
        }
        $base = 3600;
        return (int) min(86400, $base * (2 ** min(4, $attempt - 1)));
    }

    private static function for_rpm_burst(int $api_delay, int $attempt, array $quota_health): int
    {
        $rpm_status = $quota_health['rpm']['status'] ?? Quota_State_Manager::GREEN;
        $base = match ($rpm_status) {
            Quota_State_Manager::RED => 90,
            Quota_State_Manager::YELLOW => 45,
            default => 15,
        };

        if ($api_delay > 0) {
            return max($api_delay, $base);
        }

        return (int) min(600, $base * $attempt);
    }

    private static function for_rpm_sustained(int $api_delay, int $attempt, array $quota_health): int
    {
        $rpm_status = $quota_health['rpm']['status'] ?? Quota_State_Manager::YELLOW;
        $base = match ($rpm_status) {
            Quota_State_Manager::RED => 180,
            Quota_State_Manager::YELLOW => 90,
            default => 45,
        };

        if ($api_delay > 0) {
            return max($api_delay, $base);
        }

        return (int) min(900, $base * $attempt);
    }

    private static function for_tpm(int $api_delay, int $attempt): int
    {
        if ($api_delay > 0) {
            return max($api_delay, 60);
        }
        return (int) min(600, 60 * $attempt);
    }

    // @MODIFIED 2026-04-29 - Handle 503 Service Unavailable (high demand)
    private static function for_service_unavailable(int $api_delay, int $attempt): int
    {
        if ($api_delay > 0) {
            return max($api_delay, 10);
        }
        // 503 = Google server overload, not our quota. Use a long backoff to avoid
        // burning free-tier quota on retries that will also fail.
        return (int) min(300, 60 * $attempt);
    }

    private static function for_unknown(int $api_delay, int $attempt): int
    {
        if ($api_delay > 0) {
            return max($api_delay, 30);
        }
        return (int) min(300, 30 * $attempt);
    }
}
