<?php

/**
 * Job Repository
 *
 * Manages video generation jobs in the database.
 *
 * @package    MCQ_Video_Studio
 * @subpackage Includes
 * @since      1.0.0
 */

if (! defined('ABSPATH')) {
    exit;
}

/**
 * Class VS_Job_Repository
 *
 * CRUD operations for video jobs.
 *
 * @since 1.0.0
 */
class VS_Job_Repository
{

    const TABLE_NAME = 'vs_jobs';

    private static $instance = null;

    public static function init()
    {
        if (null === self::$instance) {
            self::$instance = new self();

            self::ensure_table_exists();
            // @FIX: Run all schema migrations as a single ordered block. Every ALTER directive
            //       is funneled through VS_Error_Logger instead of silently $wpdb->suppress_errors
            //       so admins see what went wrong if a site strays from the canonical schema.
            self::run_schema_migrations();
        }
        return self::$instance;
    }

    /**
     * Ordered, idempotent schema migration block.
     *
     * @since 1.4.9.0
     */
    private static function run_schema_migrations()
    {
        if (get_option('mcqvs_db_enum_fix_136') !== 'done') {
            $ok = self::fix_status_enum();
            if ($ok) {
                update_option('mcqvs_db_enum_fix_136', 'done');
            } elseif (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log('Schema migration failed: fix_status_enum', 'error', array('db_error' => self::last_wpdb_error()));
            }
        }

        if (get_option('mcqvs_db_varchar_migration') !== 'done') {
            $ok = self::migrate_enum_to_varchar();
            if ($ok) {
                update_option('mcqvs_db_varchar_migration', 'done');
            } elseif (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log('Schema migration failed: migrate_enum_to_varchar', 'error', array('db_error' => self::last_wpdb_error()));
            }
        }

        if (get_option('mcqvs_publish_columns_migration') !== 'done') {
            // Independent of the enum migration — calling the publish-columns
            // table-alter on its own keeps fresh installs safe even when an admin
            // manually toggles flags.
            self::add_publish_columns();
            update_option('mcqvs_publish_columns_migration', 'done');
        }

        if (get_option('mcqvs_model_provider_column_migration') !== 'done') {
            $ok = self::add_model_provider_columns();
            if ($ok) {
                update_option('mcqvs_model_provider_column_migration', 'done');
            } elseif (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log('Schema migration failed: add_model_provider_columns', 'error', array('db_error' => self::last_wpdb_error()));
            }
        }

        if (get_option('mcqvs_buffer_requeue_column_migration') !== 'done') {
            $ok = self::add_buffer_requeue_column();
            if ($ok) {
                update_option('mcqvs_buffer_requeue_column_migration', 'done');
            } elseif (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log('Schema migration failed: add_buffer_requeue_column', 'error', array('db_error' => self::last_wpdb_error()));
            }
        }
    }

    private static function add_model_provider_columns()
    {
        global $wpdb;
        $table = self::get_table_name();

        $exists = $wpdb->get_results("SHOW COLUMNS FROM `{$table}` LIKE 'model_provider'");
        if (empty($exists)) {
            $suppress = $wpdb->suppress_errors();
            $r1 = $wpdb->query("ALTER TABLE `{$table}` ADD `model_provider` VARCHAR(128) DEFAULT NULL COMMENT 'Provider slug used for this job'");
            $r2 = $wpdb->query("ALTER TABLE `{$table}` ADD `model_id` VARCHAR(128) DEFAULT NULL COMMENT 'Model ID used for this job'");
            $wpdb->suppress_errors($suppress);
            if ($r1 === false || $r2 === false) {
                return false;
            }
        }

        $indexes = $wpdb->get_col("SHOW INDEX FROM `{$table}`", 2);
        if (!in_array('idx_model_provider', $indexes, true)) {
            $wpdb->query("ALTER TABLE `{$table}` ADD INDEX `idx_model_provider` (`model_provider`)");
        }

        return true;
    }

    /**
     * @NEW 2026-08-07: Track the most recent publish_at reassignment performed by the
     * exponential-backoff Buffer retry re-queue (Patch 4). Allows successive re-queues
     * to stack (i.e. two failed jobs in the same batch land on different next-day slots)
     * without colliding on the same publish_at. Idempotent — re-runs are no-ops.
     */
    private static function add_buffer_requeue_column()
    {
        global $wpdb;
        $table = self::get_table_name();

        $exists = $wpdb->get_results("SHOW COLUMNS FROM `{$table}` LIKE 'buffer_requeued_to'");
        if (empty($exists)) {
            $suppress = $wpdb->suppress_errors();
            $r = $wpdb->query("ALTER TABLE `{$table}` ADD `buffer_requeued_to` DATETIME DEFAULT NULL COMMENT 'Last publish_at reassigned by exponential-backoff Buffer retry re-queue'");
            $wpdb->suppress_errors($suppress);
            if ($r === false) {
                return false;
            }
        }

        $indexes = $wpdb->get_col("SHOW INDEX FROM `{$table}`", 2);
        if (!in_array('idx_buffer_requeued_to', $indexes, true)) {
            $wpdb->query("ALTER TABLE `{$table}` ADD INDEX `idx_buffer_requeued_to` (`buffer_requeued_to`)");
        }

        return true;
    }

    /**
     * Capture $wpdb->last_error safely (it can be unset in some test environments).
     */
    private static function last_wpdb_error()
    {
        global $wpdb;
        return isset($wpdb) && isset($wpdb->last_error) ? $wpdb->last_error : '';
    }

    /**
     * Forcefully alters the status ENUM to include 'ready_for_render'
     * because WP's dbDelta notoriously ignores ENUM changes.
     */
    private static function fix_status_enum()
    {
        global $wpdb;
        $table = self::get_table_name();

        $suppress = $wpdb->suppress_errors();
        $r1 = $wpdb->query("ALTER TABLE {$table} MODIFY COLUMN status ENUM('pending', 'rendering', 'uploading', 'completed', 'failed', 'cancelled', 'ready_for_render') DEFAULT 'pending'");
        $r2 = $wpdb->query("UPDATE {$table} SET status = 'ready_for_render' WHERE status = '' OR status IS NULL");
        $wpdb->suppress_errors($suppress);
        return ($r1 !== false && $r2 !== false);
    }

    private static function ensure_table_exists()
    {
        global $wpdb;
        $table = self::get_table_name();

        if ($wpdb->get_var("SHOW TABLES LIKE '{$table}'") !== $table) {
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
            $tables = VS_Schema::get_tables_to_create();
            if (isset($tables['vs_jobs'])) {
                dbDelta($tables['vs_jobs']);
            }
        }
    }

    private static function migrate_enum_to_varchar()
    {
        global $wpdb;
        $table = self::get_table_name();

        $suppress = $wpdb->suppress_errors();
        $r1 = $wpdb->query("ALTER TABLE {$table} MODIFY COLUMN status VARCHAR(30) DEFAULT 'pending'");
        $r2 = $wpdb->query("ALTER TABLE {$table} MODIFY COLUMN platform VARCHAR(20) DEFAULT 'all'");
        $r3 = $wpdb->query("UPDATE {$table} SET status = 'ready_for_render' WHERE status = '' OR status IS NULL");
        $wpdb->suppress_errors($suppress);

        // Sub-tables: each is gated by row existence so legacy sites that pre-date them are safe.
        $projects_table = $wpdb->prefix . 'vs_projects';
        $r4 = null;
        if ($wpdb->get_var("SHOW TABLES LIKE '{$projects_table}'") === $projects_table) {
            $r4 = $wpdb->query("ALTER TABLE {$projects_table} MODIFY COLUMN status VARCHAR(30) DEFAULT 'draft'");
        }

        $mcq_table = $wpdb->prefix . 'vs_mcq_bank';
        $r5 = $r6 = null;
        if ($wpdb->get_var("SHOW TABLES LIKE '{$mcq_table}'") === $mcq_table) {
            $r5 = $wpdb->query("ALTER TABLE {$mcq_table} MODIFY COLUMN difficulty VARCHAR(10) DEFAULT 'medium'");
            $r6 = $wpdb->query("ALTER TABLE {$mcq_table} MODIFY COLUMN status VARCHAR(20) DEFAULT 'draft'");
        }

        $topics_table = $wpdb->prefix . 'vs_topics';
        $r7 = null;
        if ($wpdb->get_var("SHOW TABLES LIKE '{$topics_table}'") === $topics_table) {
            $r7 = $wpdb->query("ALTER TABLE {$topics_table} MODIFY COLUMN type VARCHAR(20) NOT NULL DEFAULT 'exam'");
        }

        // @FIX: Publish columns are now handled by `add_publish_columns()` as a separate,
        //       observable idempotent ALTER (see `run_schema_migrations`). Removed the
        //       nested call here to avoid double-execution.

        // Treat the migration as successful if at least the core status/platform
        // ALTER succeeded; sub-table adjustments are best-effort upgrades.
        return ($r1 !== false && $r2 !== false && $r3 !== false);
    }

    private static function add_publish_columns()
    {
        global $wpdb;
        $table = self::get_table_name();

        $suppress = $wpdb->suppress_errors();

        $check = $wpdb->get_results("SHOW COLUMNS FROM `{$table}` LIKE 'publish_at'");
        if (empty($check)) {
            $wpdb->query("ALTER TABLE `{$table}` ADD `publish_at` DATETIME DEFAULT NULL COMMENT 'When the video should be published to social media'");
        }

        $check = $wpdb->get_results("SHOW COLUMNS FROM `{$table}` LIKE 'published_channels'");
        if (empty($check)) {
            // @FIX: VARCHAR(500) silently truncates when more than ~10 long channel IDs are stored.
            //       Buffer GraphQL posts return UUID-shaped IDs, so use TEXT to be safe.
            $wpdb->query("ALTER TABLE `{$table}` ADD `published_channels` TEXT DEFAULT NULL COMMENT 'JSON: Array of Buffer channel IDs that received this video'");
        } else {
            // @FIX 2026-07-22: Convert existing VARCHAR to TEXT to prevent silent truncation
            $wpdb->query("ALTER TABLE `{$table}` MODIFY `published_channels` TEXT DEFAULT NULL");
        }

        $check = $wpdb->get_results("SHOW COLUMNS FROM `{$table}` LIKE 'buffer_post_ids'");
        if (empty($check)) {
            $wpdb->query("ALTER TABLE `{$table}` ADD `buffer_post_ids` TEXT DEFAULT NULL COMMENT 'JSON: Array of Buffer post IDs from successful pushes'");
        } else {
            // @FIX 2026-07-22: Convert existing VARCHAR to TEXT to prevent silent truncation
            $wpdb->query("ALTER TABLE `{$table}` MODIFY `buffer_post_ids` TEXT DEFAULT NULL");
        }
        $existing_indexes = $wpdb->get_col("SHOW INDEX FROM `{$table}`", 2);
        if (!in_array('idx_publish_at', $existing_indexes, true)) {
            $wpdb->query("ALTER TABLE `{$table}` ADD INDEX `idx_publish_at` (`publish_at`)");
        }
        if (!in_array('idx_status_publish', $existing_indexes, true)) {
            $wpdb->query("ALTER TABLE `{$table}` ADD INDEX `idx_status_publish` (`status`, `publish_at`)");
        }
        // @FIX: `get_jobs_by_status` ordered BY `created_at` but indexed only on `status`.
        //       Also `get_jobs_by_batch` ORDER BY created_at with only single-column index.
        if (!in_array('idx_status_created_at', $existing_indexes, true)) {
            $wpdb->query("ALTER TABLE `{$table}` ADD INDEX `idx_status_created_at` (`status`, `created_at`)");
        }
        // @FIX: Schema declared `retry_count` but an index/column-level guarantee
        //       never existed. Add TINYINT UNSIGNED DEFAULT 0 to legacy sites so the
        //       auto-clear counter doesn't accidentally set NULL.
        $check = $wpdb->get_results("SHOW COLUMNS FROM `{$table}` LIKE 'retry_count'");
        if (empty($check)) {
            $wpdb->query("ALTER TABLE `{$table}` ADD `retry_count` TINYINT UNSIGNED NOT NULL DEFAULT 0");
        } else {
            // Coerce NULL → 0 to support the COALESCE(retry_count,0) updates above.
            $wpdb->query("UPDATE `{$table}` SET retry_count = 0 WHERE retry_count IS NULL");
        }

        $wpdb->suppress_errors($suppress);
    }

    public static function get_table_name()
    {
        global $wpdb;
        return $wpdb->prefix . self::TABLE_NAME;
    }

    /**
     * Normalize quiz_data to always be an array of question objects.
     * Handles legacy {"ids": [...]} format by resolving to full questions.
     *
     * @param mixed $quiz_data Raw quiz_data from DB
     * @param object $mcq_repo MCQ repository for resolving IDs
     * @return array Array of question objects
     */
    public static function normalize_quiz_data($quiz_data, $mcq_repo = null)
    {
        if (empty($quiz_data)) {
            return array();
        }

        $decoded = is_string($quiz_data) ? json_decode($quiz_data, true) : $quiz_data;

        if (!is_array($decoded)) {
            return array();
        }

        if (isset($decoded['ids']) && is_array($decoded['ids'])) {
            if ($mcq_repo && !empty($decoded['ids'])) {
                $questions = array();
                foreach ($decoded['ids'] as $id) {
                    $mcq = $mcq_repo->find(array('id' => $id));
                    if (!empty($mcq)) {
                        $questions[] = $mcq[0];
                    }
                }
                return $questions;
            }
            return array();
        }

        if (isset($decoded[0]) && is_array($decoded[0])) {
            return $decoded;
        }

        return array();
    }

    public static function create_table()
    {
        $tables = VS_Schema::get_tables_to_create();
        if (isset($tables['vs_jobs'])) {
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
            dbDelta($tables['vs_jobs']);
        }
    }

    /**
     * Create a new job.
     *
     * @param array $args Job arguments.
     * @return string|WP_Error Job ID on success.
     */
    public function create_job($args)
    {
        global $wpdb;

        $defaults = array(
            'topic_id'        => 0,
            'exam_id'         => null,
            'project_id'      => null,
            'question_count'  => 5,
            'status'          => VS_Job_Status::PENDING,
            'quiz_data'       => null,
            'settings'        => null,
            'platform'        => 'all',
            'scheduled_at'    => gmdate('Y-m-d H:i:s'),
            'model_provider'  => null,
            'model_id'        => null,
            'parent_batch_id' => null,
        );

        $data = wp_parse_args($args, $defaults);

        if (!is_numeric($data['topic_id'])) {
            return new WP_Error('invalid_data', 'Topic ID is required.');
        }

        if ($data['status'] && !VS_Job_Status::is_valid($data['status'])) {
            $data['status'] = VS_Job_Status::PENDING;
        }

        if ($data['platform'] && !VS_Schema::is_valid_platform($data['platform'])) {
            $data['platform'] = 'all';
        }

        $quiz_data = $data['quiz_data'];
        if (is_array($data['quiz_data'])) {
            $quiz_data = wp_json_encode($data['quiz_data']);
        }

        $settings = $data['settings'];
        if (is_array($data['settings'])) {
            $settings = wp_json_encode($data['settings']);
        }

        $job_id = 'vs_' . uniqid() . '_' . wp_rand(1000, 9999);

        // @FIX (cross-file audit): Persist `parent_batch_id` so the headless render queue
        //       can filter by the active batch (prevents picking up leftover `READY_FOR_RENDER`
        //       rows from previous cycles). The schema column + idx_parent_batch already exist.
        //       Sanitized + null-coalesced so legacy callers behave exactly as before.
        $parent_batch_id = (isset($data['parent_batch_id']) && is_string($data['parent_batch_id']) && $data['parent_batch_id'] !== '')
            ? sanitize_text_field($data['parent_batch_id'])
            : null;

        $inserted = $wpdb->insert(
            self::get_table_name(),
            array(
                'job_id'          => $job_id,
                'topic_id'        => absint($data['topic_id']),
                'exam_id'         => $data['exam_id'] ? absint($data['exam_id']) : null,
                'project_id'      => $data['project_id'] ? absint($data['project_id']) : null,
                'question_count'  => absint($data['question_count']),
                'status'          => $data['status'],
                'quiz_data'       => $quiz_data,
                'settings'        => $settings,
                'platform'        => $data['platform'],
                'scheduled_at'    => $data['scheduled_at'],
                'model_provider'  => $data['model_provider'],
                'model_id'        => $data['model_id'],
                'parent_batch_id' => $parent_batch_id,
                'created_at'      => gmdate('Y-m-d H:i:s'),
            ),
            array('%s', '%d', '%d', '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')
        );

        if (!$inserted) {
            $this->maybe_add_missing_columns();

            $inserted = $wpdb->insert(
                self::get_table_name(),
                array(
                    'job_id'          => $job_id,
                    'topic_id'        => absint($data['topic_id']),
                    'exam_id'         => $data['exam_id'] ? absint($data['exam_id']) : null,
                    'project_id'      => $data['project_id'] ? absint($data['project_id']) : null,
                    'question_count'  => absint($data['question_count']),
                    'status'          => $data['status'],
                    'quiz_data'       => $quiz_data,
                    'settings'        => $settings,
                    'platform'        => $data['platform'],
                    'scheduled_at'    => $data['scheduled_at'],
                    'parent_batch_id' => $parent_batch_id,
                    'created_at'      => gmdate('Y-m-d H:i:s'),
                ),
                array('%s', '%d', '%d', '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s')
            );

            if (!$inserted) {
                $error_msg = 'Could not insert job even after schema check. DB Error: ' . $wpdb->last_error;
                if (class_exists('VS_Error_Logger')) {
                    VS_Error_Logger::get_instance()->log($error_msg, 'error', array(
                        'data' => $data,
                        'job_id' => $job_id
                    ));
                }
                return new WP_Error('db_insert_error', $error_msg);
            }
        }

        $verify_status = $wpdb->get_var($wpdb->prepare(
            "SELECT status FROM " . self::get_table_name() . " WHERE job_id = %s", $job_id
        ));
        if ($verify_status !== $data['status']) {
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log("DB integrity: status mismatch after insert. Expected={$data['status']}, Got={$verify_status}", 'error', array('job_id' => $job_id));
            }
            $wpdb->update(self::get_table_name(), array('status' => $data['status']), array('job_id' => $job_id));
        }

        if (class_exists('VS_Error_Logger')) {
            VS_Error_Logger::get_instance()->log_pipeline(
                'job.created',
                'completed',
                $job_id,
                "Job {$job_id} created (status: {$data['status']}, topic: {$data['topic_id']})",
                'info',
                array(
                    'job_id' => $job_id,
                    'topic_id' => $data['topic_id'],
                    'status' => $data['status'],
                    'question_count' => $data['question_count'],
                )
            );
        }

        return $job_id;
    }

    /**
     * Self-Healing DB Schema
     * Checks if modernization columns exist and adds them via ALTER if missing.
     */
    public function maybe_add_missing_columns()
    {
        global $wpdb;
        $table = self::get_table_name();

        $columns_to_check = array(
            'quiz_data' => 'LONGTEXT DEFAULT NULL COMMENT "JSON: Question IDs or cached quiz content"',
            'settings' => 'LONGTEXT DEFAULT NULL COMMENT "JSON: Template, background, music config"',
            'parent_batch_id' => 'VARCHAR(64) DEFAULT NULL COMMENT "Groups jobs from same bulk schedule"',
            'project_id' => 'BIGINT UNSIGNED DEFAULT NULL COMMENT "Links job to originating project"',
            'publish_at' => 'DATETIME DEFAULT NULL COMMENT "When the video should be published to social media"',
            'published_channels' => 'VARCHAR(500) DEFAULT NULL COMMENT "JSON: Array of Buffer channel IDs that received this video"',
            'buffer_post_ids' => 'VARCHAR(500) DEFAULT NULL COMMENT "JSON: Array of Buffer post IDs from successful pushes"',
        );

        foreach ($columns_to_check as $col => $definition) {
            $check = $wpdb->get_results("SHOW COLUMNS FROM `{$table}` LIKE '{$col}'");
            if (empty($check)) {
                $wpdb->query("ALTER TABLE `{$table}` ADD `{$col}` {$definition}");
            }
        }
    }

    /**
     * Get pending jobs due for execution.
     *
     * @param int $limit Limit.
     * @return array Job rows.
     */
    public function get_pending_jobs($limit = 5)
    {
        global $wpdb;
        $table = self::get_table_name();
        $now = gmdate('Y-m-d H:i:s');

        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table}
                WHERE status = %s
                AND scheduled_at <= %s
                ORDER BY scheduled_at ASC
                LIMIT %d",
                VS_Job_Status::PENDING,
                $now,
                $limit
            ),
            ARRAY_A
        );
    }

    public function get_jobs_by_status($status, $limit = 5)
    {
        global $wpdb;
        $table = self::get_table_name();

        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table}
                WHERE status = %s
                ORDER BY created_at ASC
                LIMIT %d",
                $status,
                $limit
            ),
            ARRAY_A
        );
    }

    /**
     * @FIX (cross-file audit): Claim-aware variant of `get_jobs_by_status`.
     *
     *       When `mcqvs_content_plan_pending_batches` is set, the headless-render queue
     *       MUST filter by `parent_batch_id` to avoid spawning renders for jobs left over
     *       from previous retries (the source of "scheduled A, rendered B" mismatches).
     *       HOWEVER: automation-created and AS-worker-created jobs have parent_batch_id=NULL
     *       and MUST also be visible to the queue. The query now fetches the active batch
     *       PLUS any NULL-parent_batch_id rows to prevent silent orphaning.
     *       Backed by the existing `idx_parent_batch` index — no schema change.
     *
     * @param string $status
     * @param int    $limit
     * @param string|null $parent_batch_id  When non-null/non-empty, restrict to that batch + NULL rows.
     * @return array
     */
    public function get_jobs_by_status_for_batch($status, $limit = 5, $parent_batch_id = null)
    {
        global $wpdb;
        $table = self::get_table_name();

        $parent_batch_id = (is_string($parent_batch_id) && $parent_batch_id !== '')
            ? sanitize_text_field($parent_batch_id)
            : null;

        if ($parent_batch_id !== null) {
            // @FIX: Include both the active planner batch AND orphaned jobs
            //       (parent_batch_id IS NULL). Without this, automation-created
            //       jobs from run_daily_scheduler() and AS worker are invisible
            //       whenever a content planner batch is active.
            return $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT * FROM {$table}
                    WHERE status = %s
                      AND (parent_batch_id = %s OR parent_batch_id IS NULL)
                    ORDER BY created_at ASC
                    LIMIT %d",
                    $status,
                    $parent_batch_id,
                    $limit
                ),
                ARRAY_A
            );
        }

        return $this->get_jobs_by_status($status, $limit);
    }

    /**
     * Update job status with transition validation.
     *
     * @param string $job_id Job ID.
     * @param string $status New status.
     * @param array  $extras Extra fields to update.
     * @return int|false
     */
    public function update_status($job_id, $status, $extras = array())
    {
        global $wpdb;

        if (!VS_Job_Status::is_valid($status)) {
            return false;
        }

        $job = $this->get_job($job_id);
        $from_status = $job ? $job['status'] : 'unknown';

        if ($job && !VS_Job_Status::can_transition($from_status, $status)) {
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log(
                    "Invalid status transition blocked: {$from_status} -> {$status} for job {$job_id}",
                    'error',
                    array('job_id' => $job_id, 'from' => $from_status, 'to' => $status)
                );
            }
            return false;
        }

        $data = array_merge(array('status' => $status), $extras);

        // @FIX: Use UTC consistently for all datetime columns to match publish_at storage
        if (VS_Job_Status::RENDERING === $status) {
            $data['started_at'] = gmdate('Y-m-d H:i:s');
        }
        if (in_array($status, array(VS_Job_Status::COMPLETED, VS_Job_Status::FAILED, VS_Job_Status::CANCELLED), true)) {
            $data['completed_at'] = gmdate('Y-m-d H:i:s');
        }

        $result = $wpdb->update(
            self::get_table_name(),
            $data,
            array('job_id' => $job_id)
        );

        if (class_exists('VS_Error_Logger') && $result !== false) {
            $extra_ctx = array('job_id' => $job_id, 'from' => $from_status, 'to' => $status);
            if (!empty($extras['error_message'])) {
                $extra_ctx['error_message'] = $extras['error_message'];
            }
            VS_Error_Logger::get_instance()->log_pipeline(
                'job.transition',
                $status === 'failed' ? 'failed' : 'completed',
                $job_id,
                "Job {$job_id}: {$from_status} -> {$status}",
                $status === 'failed' ? 'error' : 'info',
                $extra_ctx
            );
        }

        return $result;
    }

    /**
     * Update video URL after render completes.
     *
     * @param string $job_id Job ID
     * @param string $video_url URL of the rendered video
     * @param string $video_path Optional local path
     * @return int|false
     */
    public function update_video_url($job_id, $video_url, $video_path = null)
    {
        global $wpdb;

        $data = array('video_url' => $video_url);
        if ($video_path) {
            $data['video_path'] = $video_path;
        }

        return $wpdb->update(
            self::get_table_name(),
            $data,
            array('job_id' => $job_id)
        );
    }

    /**
     * Get job by ID.
     *
     * @param string $job_id
     * @return array|null
     */
    public function get_job($job_id)
    {
        global $wpdb;
        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM " . self::get_table_name() . " WHERE job_id = %s", $job_id),
            ARRAY_A
        );
    }

    /**
     * Get job by project ID.
     *
     * @param int $project_id
     * @return array|null
     */
    public function get_job_by_project($project_id)
    {
        global $wpdb;
        return $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM " . self::get_table_name() . " WHERE project_id = %d ORDER BY created_at DESC LIMIT 1", $project_id),
            ARRAY_A
        );
    }

    /**
     * Get job stats for dashboard.
     *
     * @return array
     */
    public function get_stats()
    {
        global $wpdb;
        $table = self::get_table_name();

        $completed_total = (int) $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE status = 'completed'");
        // @FIX: completed_at is stored in UTC; use UTC_DATE() so "today" matches job completion in UTC
        $completed_today = (int) $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE status = 'completed' AND DATE(completed_at) = UTC_DATE()");

        $pending = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM $table WHERE status IN (%s, %s)",
                VS_Job_Status::PENDING,
                VS_Job_Status::READY_FOR_RENDER
            )
        );

        return array(
            'completed_total' => $completed_total,
            'completed_today' => $completed_today,
            'pending'         => $pending,
        );
    }

    /**
     * Get recent completed jobs with topic name and delivery details.
     *
     * @param int $limit Number of jobs to return.
     * @return array
     */
    public function get_recent_completed_jobs($limit = 5)
    {
        global $wpdb;
        $table = self::get_table_name();
        $topics_table = $wpdb->prefix . 'vs_topics';

        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT j.job_id, j.topic_id, j.status, j.video_path, j.video_url,
                        j.completed_at, j.created_at, j.settings,
                        j.published_channels, j.buffer_post_ids, j.publish_at, j.scheduled_at,
                        COALESCE(t.name, CONCAT('Topic #', j.topic_id)) AS topic_name
                 FROM {$table} j
                 LEFT JOIN {$topics_table} t ON j.topic_id = t.id
                 WHERE j.status = %s
                 ORDER BY j.completed_at DESC
                 LIMIT %d",
                VS_Job_Status::COMPLETED,
                $limit
            ),
            ARRAY_A
        );
    }

    /**
     * Get recent active (non-completed, non-failed) pipeline jobs for dashboard visibility.
     * Includes pending, ready_for_render, rendering, uploading.
     * Ordering prioritizes:
     *   1. Active jobs (rendering, uploading, ready_for_render) - currently processing
     *   2. Pending jobs scheduled for TODAY (date-wise) - "Active" / today's videos
     *   3. Pending jobs overdue (scheduled_at < today) - "Overdue"
     *   4. Pending jobs scheduled for future days - "Upcoming"
     *   5. Pending jobs without scheduled_at (legacy/unscheduled)
     *   COMPLETED jobs are EXCLUDED - they have their own "Recent Videos" card.
     *
     * @param int $limit Max jobs to return.
     * @return array
     */
    public function get_recent_pipeline_jobs($limit = 25)
    {
        global $wpdb;
        $table = self::get_table_name();
        $topics_table = $wpdb->prefix . 'vs_topics';

        $statuses = array(
            VS_Job_Status::PENDING,
            VS_Job_Status::READY_FOR_RENDER,
            VS_Job_Status::RENDERING,
            VS_Job_Status::UPLOADING,
            // COMPLETED excluded - has dedicated "Recent Videos" card
        );

        $placeholders = implode(',', array_fill(0, count($statuses), '%s'));
        $today_gmt = gmdate('Y-m-d');
        $now_gmt = gmdate('Y-m-d H:i:s');

        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT j.job_id, j.topic_id, j.status, j.video_path, j.video_url,
                        j.completed_at, j.created_at, j.scheduled_at, j.publish_at, j.settings,
                        j.question_count, j.retry_count, j.error_message, j.started_at,
                        j.parent_batch_id,
                        COALESCE(t.name, CONCAT('Topic #', j.topic_id)) AS topic_name
                 FROM {$table} j
                 LEFT JOIN {$topics_table} t ON j.topic_id = t.id
                 WHERE j.status IN ({$placeholders})
                 ORDER BY
                     -- Priority 1: Active rendering/uploading/ready_for_render jobs first
                     CASE
                         WHEN j.status IN ('rendering', 'uploading', 'ready_for_render') THEN 0
                         -- Priority 2: Pending jobs scheduled for TODAY (date-wise) - Today videos
                         WHEN j.status = 'pending' AND j.scheduled_at IS NOT NULL AND j.scheduled_at != '0000-00-00 00:00:00' AND DATE(j.scheduled_at) = %s THEN 1
                         -- Priority 3: Pending jobs overdue (scheduled before today)
                         WHEN j.status = 'pending' AND j.scheduled_at IS NOT NULL AND j.scheduled_at != '0000-00-00 00:00:00' AND DATE(j.scheduled_at) < %s THEN 2
                         -- Priority 4: Pending jobs scheduled for future days
                         WHEN j.status = 'pending' AND j.scheduled_at IS NOT NULL AND j.scheduled_at != '0000-00-00 00:00:00' THEN 3
                         -- Priority 5: Pending jobs without scheduled_at (legacy/unscheduled)
                         WHEN j.status = 'pending' THEN 4
                     END ASC,
                     -- Within priority 2 (today): order by scheduled_at ASC (earliest today first)
                     CASE
                         WHEN j.status = 'pending' AND j.scheduled_at IS NOT NULL AND j.scheduled_at != '0000-00-00 00:00:00' AND DATE(j.scheduled_at) = %s THEN j.scheduled_at
                     END ASC,
                     -- Within priority 3 (overdue): order by scheduled_at ASC (most overdue first)
                     CASE
                         WHEN j.status = 'pending' AND j.scheduled_at IS NOT NULL AND j.scheduled_at != '0000-00-00 00:00:00' AND DATE(j.scheduled_at) < %s THEN j.scheduled_at
                     END ASC,
                     -- Within priority 4 (future): order by scheduled_at ASC (soonest first)
                     CASE
                         WHEN j.status = 'pending' AND j.scheduled_at IS NOT NULL AND j.scheduled_at != '0000-00-00 00:00:00' AND DATE(j.scheduled_at) > %s THEN j.scheduled_at
                     END ASC,
                     -- Within priority 1 (active): order by started_at DESC (most recent active first)
                     CASE
                         WHEN j.status IN ('rendering', 'uploading', 'ready_for_render') THEN j.started_at
                     END DESC,
                     -- Fallback: created_at DESC
                     j.created_at DESC
                 LIMIT %d",
                array_merge($statuses, array($today_gmt, $today_gmt, $today_gmt, $today_gmt, $today_gmt, (int) $limit))
            ),
            ARRAY_A
        );
    }

    /**
     * Get job count per status for dashboard pipeline view.
     *
     * @return array Associative array keyed by status constant.
     */
    public function get_status_breakdown()
    {
        global $wpdb;
        $table = self::get_table_name();

        $statuses = array(
            VS_Job_Status::PENDING,
            VS_Job_Status::READY_FOR_RENDER,
            VS_Job_Status::RENDERING,
            VS_Job_Status::UPLOADING,
            VS_Job_Status::COMPLETED,
            VS_Job_Status::FAILED,
            VS_Job_Status::CANCELLED,
        );

        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT status, COUNT(*) as cnt FROM {$table} WHERE status IN (" . implode(',', array_fill(0, count($statuses), '%s')) . ") GROUP BY status",
                ...$statuses
            ),
            OBJECT_K
        );

        $breakdown = array();
        foreach ($statuses as $s) {
            $breakdown[$s] = isset($results[$s]) ? (int) $results[$s]->cnt : 0;
        }
        return $breakdown;
    }

    /**
     * Get next job ready for rendering.
     *
     * @return array|null
     */
    public function get_next_ready_job()
    {
        global $wpdb;
        $table = self::get_table_name();

        return $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE status = %s ORDER BY created_at ASC LIMIT 1",
                VS_Job_Status::READY_FOR_RENDER
            ),
            ARRAY_A
        );
    }

    /**
     * Get all jobs for a batch.
     *
     * @param string $parent_batch_id
     * @return array
     */
    public function get_jobs_by_batch($parent_batch_id)
    {
        global $wpdb;
        $table = self::get_table_name();

        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE parent_batch_id = %s ORDER BY created_at ASC",
                $parent_batch_id
            ),
            ARRAY_A
        );
    }

    /**
     * @FIX 1.4.9.50: Find jobs belonging to a topic that are still schedulable
     * (not yet rendered/completed/failed). Used by the calendar drag-save so
     * moving a topic to a new date re-stamps the EXISTING jobs' publish_at /
     * scheduled_at — the Pipeline Jobs card reads vs_jobs, not the plan option.
     *
     * @param int|string $topic_id vs_topics.id (0 = match by nothing).
     * @return array[]
     */
    public function get_schedulable_jobs_by_topic($topic_id)
    {
        global $wpdb;
        $table = self::get_table_name();
        $topic_id = absint($topic_id);
        if ($topic_id <= 0) {
            return array();
        }
        // Only jobs that haven't been rendered/published yet can be re-stamped.
        $statuses = array(
            VS_Job_Status::PENDING,
            VS_Job_Status::READY_FOR_RENDER,
        );
        $placeholders = implode(',', array_fill(0, count($statuses), '%s'));

        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT job_id, topic_id, status, publish_at, scheduled_at, settings
                 FROM {$table}
                 WHERE topic_id = %d AND status IN ({$placeholders})
                 ORDER BY created_at ASC",
                array_merge(array($topic_id), $statuses)
            ),
            ARRAY_A
        );
    }

    /**
     * Delete job by ID.
     *
     * @param string $job_id
     * @return int|false
     */
    public function delete_job($job_id)
    {
        global $wpdb;
        return $wpdb->delete(
            self::get_table_name(),
            array('job_id' => $job_id),
            array('%s')
        );
    }

    /**
     * Clear stuck jobs (pending for too long).
     *
     * @FIX: Increment `retry_count` and append a short timestamp marker to `error_message`
     *       so admins can see how many times the auto-cleaner tripped the same row.
     * @param int $threshold_minutes      Threshold for RENDERING/UPLOADING (active jobs).
     * @param int|null $pending_threshold  Separate (longer) threshold for PENDING jobs.
     *                                     Defaults to max($threshold_minutes * 4, 120) so
     *                                     legitimately queued jobs are not swept prematurely.
     * @return int Number updated
     */
    public function clear_stuck_jobs($threshold_minutes = 30, $pending_threshold = null)
    {
        global $wpdb;
        $table = self::get_table_name();
        if ($pending_threshold === null) {
            $pending_threshold = max($threshold_minutes * 4, 120);
        }

        $now = gmdate('Y-m-d H:i:s');
        $marker = sprintf(' [stuck-fail@%s]', $now);
        $total = 0;
        $all_job_ids = array();
        $grace_seconds = 120; // MATCH AS orphan-kill schedule (timeout+120)
        $render_timeout = absint(get_option('mcqvs_render_timeout', 900));
        if ($render_timeout < 600) {
            $render_timeout = 900;
        }
        $render_timeout = max(60, $render_timeout);

        // 1) PENDING — SELECT IDs first, then UPDATE by IDs so logging captures them.
        // @FIX 2026-08-07: Measure staleness against the job's processing due time
        // (scheduled_at), NOT import time (created_at). Calendar-scheduled CSV jobs
        // are created days in advance with scheduled_at = publish_at - render_buffer;
        // they MUST wait until their scheduled slot. Automation jobs (scheduled_at =
        // creation time) behave exactly as before.
        $pending_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT job_id FROM {$table}
             WHERE status = %s
               AND scheduled_at IS NOT NULL
               AND scheduled_at < DATE_SUB(%s, INTERVAL %d MINUTE)",
            VS_Job_Status::PENDING, $now, $pending_threshold
        ));
        if (!empty($pending_ids)) {
            $placeholders = implode(',', array_fill(0, count($pending_ids), '%s'));
            $total += (int) $wpdb->query(
                $wpdb->prepare(
                    "UPDATE {$table} SET status = %s, error_message = CONCAT(IFNULL(error_message,''), %s), retry_count = COALESCE(retry_count,0) + 1 WHERE job_id IN ({$placeholders})",
                    array_merge(array(VS_Job_Status::FAILED, $marker), $pending_ids)
                )
            );
            $all_job_ids = array_merge($all_job_ids, $pending_ids);
        }

        // 2) RENDERING — SELECT candidates, then check PID liveness + per-job budget
        //    before marking anything as failed. A render with a live PID that is still
        //    within its OWN scaled timeout is NOT stuck — it is making progress.
        $rendering_candidates = $wpdb->get_results($wpdb->prepare(
            "SELECT job_id, started_at FROM {$table} WHERE status = %s AND started_at IS NOT NULL AND started_at < DATE_SUB(%s, INTERVAL %d MINUTE)",
            VS_Job_Status::RENDERING, $now, $threshold_minutes
        ));
        $rendering_to_kill = array();
        foreach ($rendering_candidates as $rc) {
            $pid = (int) get_transient('mcqvs_render_pid_' . $rc->job_id);
            $per_job_timeout = (int) get_transient('mcqvs_render_timeout_' . $rc->job_id);
            if ($per_job_timeout <= 0) {
                $per_job_timeout = $render_timeout;
            }
            $budget_seconds = $per_job_timeout + $grace_seconds; // 120s grace to match AS orphan-kill
            $started_ts = (float) get_transient('mcqvs_render_started_' . $rc->job_id);
            if ($started_ts > 0) {
                $elapsed = (int) (microtime(true) - $started_ts);
            } else {
                $started_at_ts = strtotime($rc->started_at . ' UTC');
                $elapsed = time() - ($started_at_ts ?: time());
            }
            $alive = ($pid > 0 && class_exists('VS_Headless_Renderer') && VS_Headless_Renderer::is_pid_running($pid));
            if ($alive && $elapsed <= $budget_seconds) {
                continue;
            }
            $rendering_to_kill[] = $rc->job_id;
        }
        if (!empty($rendering_to_kill)) {
            $placeholders = implode(',', array_fill(0, count($rendering_to_kill), '%s'));
            $total += (int) $wpdb->query(
                $wpdb->prepare(
                    "UPDATE {$table} SET status = %s, error_message = CONCAT(IFNULL(error_message,''), %s), retry_count = COALESCE(retry_count,0) + 1 WHERE job_id IN ({$placeholders})",
                    array_merge(array(VS_Job_Status::FAILED, $marker), $rendering_to_kill)
                )
            );
            $all_job_ids = array_merge($all_job_ids, $rendering_to_kill);
            foreach ($rendering_to_kill as $jid) {
                delete_transient('mcqvs_job_lock_' . $jid);
                delete_transient('mcqvs_render_pid_' . $jid);
            }
        }

        // 3) UPLOADING — SELECT IDs then UPDATE by IDs for proper logging.
        //    No PID/budget check needed; uploading is PHP-synchronous and
        //    $threshold_minutes is a generous safety net.
        $uploading_ids = $wpdb->get_col($wpdb->prepare(
            "SELECT job_id FROM {$table} WHERE status = %s AND started_at IS NOT NULL AND started_at < DATE_SUB(%s, INTERVAL %d MINUTE)",
            VS_Job_Status::UPLOADING, $now, $threshold_minutes
        ));
        if (!empty($uploading_ids)) {
            $placeholders = implode(',', array_fill(0, count($uploading_ids), '%s'));
            $total += (int) $wpdb->query(
                $wpdb->prepare(
                    "UPDATE {$table} SET status = %s, error_message = CONCAT(IFNULL(error_message,''), %s), retry_count = COALESCE(retry_count,0) + 1 WHERE job_id IN ({$placeholders})",
                    array_merge(array(VS_Job_Status::FAILED, $marker), $uploading_ids)
                )
            );
            $all_job_ids = array_merge($all_job_ids, $uploading_ids);
        }

        // 4) READY_FOR_RENDER — SELECT candidates, filter out cooldown rows, UPDATE by IDs
        $rrf_candidates = $wpdb->get_col($wpdb->prepare(
            "SELECT job_id FROM {$table} WHERE status = %s AND started_at IS NOT NULL AND started_at < DATE_SUB(%s, INTERVAL %d SECOND)",
            VS_Job_Status::READY_FOR_RENDER,
            $now,
            ($render_timeout + $grace_seconds)
        ));
        if (is_array($rrf_candidates) && !empty($rrf_candidates)) {
            $rrf_filtered = array();
            foreach ($rrf_candidates as $cid) {
                $cooldown_until = (int) get_transient('mcqvs_reset_cooldown_' . $cid);
                if ($cooldown_until > time()) {
                    continue;
                }
                $rrf_filtered[] = $cid;
            }
            if (!empty($rrf_filtered)) {
                $placeholders_rrf = implode(',', array_fill(0, count($rrf_filtered), '%s'));
                $total += (int) $wpdb->query(
                    $wpdb->prepare(
                        "UPDATE {$table} SET status = %s, error_message = CONCAT(IFNULL(error_message,''), %s), retry_count = COALESCE(retry_count,0) + 1 WHERE job_id IN ({$placeholders_rrf})",
                        array_merge(array(VS_Job_Status::FAILED, $marker), $rrf_filtered)
                    )
                );
                $all_job_ids = array_merge($all_job_ids, $rrf_filtered);
            }
        }

        // Audit log — uses the captured $all_job_ids which are collected BEFORE the UPDATEs
        if ($total > 0 && class_exists('VS_Error_Logger')) {
            VS_Error_Logger::get_instance()->log_pipeline(
                'stuck.cleared',
                'failed',
                'auto-cleaner',
                "Auto-cleaner marked {$total} stuck job(s) as failed (threshold: {$threshold_minutes} min).",
                'error',
                array(
                    'affected' => $total,
                    'threshold_minutes' => $threshold_minutes,
                    'job_ids' => $all_job_ids,
                    'stuck_timestamp' => $now,
                )
            );
        }

        return $total;
    }

    /**
     * @NEW 2026-08-07: Heal jobs the auto-cleaner killed while they were waiting.
     *
     * Touches ONLY rows whose error_message carries the auto-cleaner marker
     * `[stuck-fail@`, so genuinely failed renders/buffer pushes are left alone.
     * Without $force, the heal budget is bounded by retry_count <= 2 so a
     * permanently broken job cannot spin forever. Restores the correct state:
     * - calendar job (settings `_calendar_render_scheduled`) with future
     *   scheduled_at -> PENDING (waits for its scheduled render time)
     * - quiz_data present -> READY_FOR_RENDER (re-claimable by render queue)
     * - otherwise -> PENDING (re-runs question reservation via vs_process_job_event)
     *
     * @param bool $force Reset regardless of retry budget (manual button).
     * @return array list of array { job_id, status, scheduled_at }
     */
    public function recover_failed_jobs($force = false)
    {
        global $wpdb;
        $table = self::get_table_name();

        $sql = "SELECT * FROM {$table}
                WHERE status = 'failed'
                  AND error_message LIKE '%[stuck-fail@%'";
        if (!$force) {
            $sql .= " AND retry_count <= 2";
        }
        $rows = $wpdb->get_results($sql, ARRAY_A);

        $recovered = array();
        foreach ($rows as $job) {
            $settings = is_string($job['settings'] ?? '') ? json_decode($job['settings'], true) : ($job['settings'] ?? array());
            if (!is_array($settings)) {
                $settings = array();
            }
            $is_calendar  = !empty($settings['_calendar_render_scheduled']);
            $scheduled_at = (string) ($job['scheduled_at'] ?? '');
            $has_quiz     = !empty($job['quiz_data']);

            // Strip the auto-cleaner marker so a later genuine failure is not re-healed.
            $error_message = trim((string) $job['error_message']);
            $marker_pos = strpos($error_message, ' [stuck-fail@');
            if ($marker_pos !== false) {
                $error_message = trim(substr($error_message, 0, $marker_pos));
            }

            if ($is_calendar && $scheduled_at !== '' && $scheduled_at > gmdate('Y-m-d H:i:s')) {
                $new_status = VS_Job_Status::PENDING;
            } elseif ($has_quiz) {
                $new_status = VS_Job_Status::READY_FOR_RENDER;
            } else {
                $new_status = VS_Job_Status::PENDING;
            }

            $settings['buffer_attempts'] = 0;
            unset($settings['buffer_manual_pending']);

            $wpdb->query(
                $wpdb->prepare(
                    "UPDATE {$table}
                     SET status = %s,
                         error_message = %s,
                         settings = %s,
                         retry_count = %d,
                         completed_at = NULL
                     WHERE job_id = %s",
                    $new_status,
                    ($error_message !== '' ? $error_message : ''),
                    wp_json_encode($settings),
                    (int) $job['retry_count'] + 1,
                    $job['job_id']
                )
            );

            $recovered[] = array(
                'job_id'       => $job['job_id'],
                'status'       => $new_status,
                'scheduled_at' => $scheduled_at,
            );
        }

        if (!empty($recovered) && class_exists('VS_Error_Logger')) {
            VS_Error_Logger::get_instance()->log_pipeline(
                'job.recovered',
                'completed',
                'auto-recovery',
                sprintf('Recovered %d auto-cleaned failed job(s) to pending/ready_for_render.', count($recovered)),
                'info',
                array('job_ids' => array_column($recovered, 'job_id'), 'force' => $force)
            );
        }

        return $recovered;
    }

    /**
     * CROSS-FILE AUDIT (2026-07-07): Per-job stuck check.
     *
     * Per your rule: a job is "stuck" iff `(its owned render time + 60s grace)`
     * has elapsed since its spawn. The spawn baseline is the monotonic PHP
     * transient `mcqvs_render_started_<job_id>` (stamped by
     * `VS_Headless_Renderer::render_job()`). It is preferred over the
     * `started_at` DATETIME column because the column can drift across server
     * timezone writes, whereas `microtime(true)` is monotonic.
     *
     * Returns false if the render has not actually started (`started_at` empty),
     * so this helper is safe to call from both the kill-orphan path AND the
     * auto-cleaner without false-positives on freshly-claimed rows.
     *
     * @param string $job_id
     * @return bool True when the job exceeded its own render time + 1 minute.
     */
    public function is_job_exceeded_own_render_time($job_id)
    {
        if (!is_string($job_id) || $job_id === '') {
            return false;
        }
        $job = $this->get_job($job_id);
        if (!$job || empty($job['started_at']) || $job['started_at'] === '0000-00-00 00:00:00') {
            return false;
        }
        $started_at_ts = is_numeric($job['started_at'])
            ? (int) $job['started_at']
            : (int) strtotime($job['started_at'] . ' UTC');
        if ($started_at_ts <= 0) {
            return false;
        }
        // @FIX 2026-07-20: Use the per-job scaled timeout stored at spawn time
        //       (mcqvs_render_timeout_<job_id> transient), which accounts for frame
        //       count scaling in render_job(). Fall back to the global option only
        //       when the per-job transient is missing.
        // @FIX 2026-07-21: Align grace period to 120s to match the AS orphan-kill
        //       schedule (scheduled at timeout+120). Previously 60s caused the AS
        //       path to always kill on arrival because the schedule fires 120s past
        //       timeout but the budget check only granted 60s of grace.
        $per_job_timeout = (int) get_transient('mcqvs_render_timeout_' . $job_id);
        if ($per_job_timeout <= 0) {
            $per_job_timeout = absint(get_option('mcqvs_render_timeout', 900));
            if ($per_job_timeout < 600) {
                $per_job_timeout = 900;
            }
        }
        $per_job_timeout = max(60, $per_job_timeout);
        $budget_seconds = $per_job_timeout + 120;

        // Prefer the PHP-side monotonic spawn transient over the DB column.
        $spawn_monotonic = get_transient('mcqvs_render_started_' . $job_id);
        if (is_numeric($spawn_monotonic) && (float) $spawn_monotonic > 0) {
            $elapsed = (int) (microtime(true) - (float) $spawn_monotonic);
        } else {
            $elapsed = time() - $started_at_ts;
        }

        return $elapsed > $budget_seconds;
    }

    public function get_jobs_ready_for_publish($limit = 10)
    {
        global $wpdb;
        $table = self::get_table_name();

        $now_gmt = gmdate('Y-m-d H:i:s');

        // @FIX (cross-file audit 2026-07-19): Also recover completed `r2_buffer` jobs that
        //       have NO publish_at. Previously the query required publish_at IS NOT NULL, so
        //       server-rendered r2_buffer jobs (finalize_server_render never set publish_at)
        //       were invisible to the cron and stayed stuck forever. We now include NULL
        //       publish_at rows and gate them in PHP to buffer-intended jobs only.
        $jobs = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE status = %s AND video_url IS NOT NULL AND video_url != '' AND (publish_at IS NULL OR publish_at <= %s) AND (published_channels IS NULL OR published_channels = '') ORDER BY COALESCE(publish_at, '9999-12-31 23:59:59') ASC LIMIT %d",
                VS_Job_Status::COMPLETED,
                $now_gmt,
                $limit
            ),
            ARRAY_A
        );

        // @VERIFICATION 2026-07-06: Validate job integrity before returning
        $validated_jobs = array();
        foreach ($jobs as $job) {
            $has_issues = false;
            $issues = array();

            // Check settings integrity first to determine delivery mode and retry state.
            $settings = is_string($job['settings'] ?? '') ? json_decode($job['settings'], true) : ($job['settings'] ?? array());
            $save_mode = is_array($settings) ? ($settings['save_mode'] ?? null) : null;

            // Skip jobs in Buffer retry backoff or awaiting manual push.
            if (false !== get_transient('mcqvs_buffer_retry_' . $job['job_id'])) {
                continue;
            }
            if (is_array($settings) && !empty($settings['buffer_manual_pending'])) {
                continue;
            }

            if ($save_mode === null) {
                $save_mode = get_option('mcqvs_delivery_mode', 'local');
            }

            // Check video_url is a valid URL
            if (!filter_var($job['video_url'], FILTER_VALIDATE_URL)) {
                $issues[] = 'invalid_video_url';
                $has_issues = true;
            }

            // A completed job is only a Buffer candidate when its delivery mode is r2_buffer.
            // Plain r2/local jobs were never meant for Buffer, regardless of publish_at.
            if ($save_mode !== 'r2_buffer') {
                continue;
            }
            // r2_buffer with null publish_at is expected — do NOT flag as invalid_publish_at.
            if (empty($job['publish_at']) || $job['publish_at'] === '0000-00-00 00:00:00') {
                // expected for r2_buffer
            } else {
                // publish_at is set; verify it is a valid datetime string.
                $dt_check = DateTime::createFromFormat('Y-m-d H:i:s', $job['publish_at']);
                if (!$dt_check) {
                    $issues[] = 'invalid_publish_at';
                    $has_issues = true;
                }
            }

            if (is_array($settings) && !empty($settings['_publish_computed_at'])) {
                // Verify intent fields exist
                if (empty($settings['_publish_start_date']) && empty($settings['_publish_offset'])) {
                    $issues[] = 'missing_publish_intent';
                    // Don't block - just log
                }
            }

            if ($has_issues) {
                // Log integrity issue but don't block - let the publish step handle it
                if (class_exists('VS_Error_Logger')) {
                    VS_Error_Logger::get_instance()->log_pipeline(
                        'job.integrity',
                        'warning',
                        $job['job_id'],
                        "Job {$job['job_id']} has integrity issues: " . implode(', ', $issues),
                        'warning',
                        array('job_id' => $job['job_id'], 'issues' => $issues, 'video_url' => $job['video_url'], 'publish_at' => $job['publish_at'])
                    );
                }
                // Still include the job - the publish step will handle the error
            }

            $validated_jobs[] = $job;
        }

        return $validated_jobs;
    }

    /**
     * @NEW 2026-08-07: Maximum publish_at among jobs sharing the same parent_batch_id
     * (excluding the supplied job_id). Used by the Buffer retry re-queue to find the
     * end of the calendar for a given CSV import batch. Returns 'Y-m-d H:i:s' UTC string
     * or null when no other jobs in the batch carry a valid publish_at.
     */
    public function get_max_publish_at_for_batch($batch_id, $exclude_job_id = '')
    {
        global $wpdb;
        $table = self::get_table_name();

        if (empty($batch_id)) {
            return null;
        }

        $sql = "SELECT MAX(publish_at) FROM {$table}
                WHERE parent_batch_id = %s
                  AND publish_at IS NOT NULL
                  AND publish_at != '0000-00-00 00:00:00'";
        $params = array($batch_id);

        if ($exclude_job_id !== '') {
            $sql .= " AND job_id != %s";
            $params[] = $exclude_job_id;
        }

        $max = $wpdb->get_var($wpdb->prepare($sql, $params));
        if (empty($max) || $max === '0000-00-00 00:00:00') {
            return null;
        }
        return (string) $max;
    }

    /**
     * @NEW 2026-08-07: Maximum buffer_requeued_to across all jobs in the same
     * parent_batch_id. Lets successive failed-Buffer re-queues stack on different
     * next-day slots instead of colliding on the same publish_at. Returns 'Y-m-d H:i:s'
     * UTC string or null when nothing has been re-queued yet.
     */
    public function get_max_buffer_requeued_to_for_batch($batch_id)
    {
        global $wpdb;
        $table = self::get_table_name();

        if (empty($batch_id)) {
            return null;
        }

        $max = $wpdb->get_var($wpdb->prepare(
            "SELECT MAX(buffer_requeued_to) FROM {$table}
             WHERE parent_batch_id = %s
               AND buffer_requeued_to IS NOT NULL
               AND buffer_requeued_to != '0000-00-00 00:00:00'",
            $batch_id
        ));

        if (empty($max) || $max === '0000-00-00 00:00:00') {
            return null;
        }
        return (string) $max;
    }

    public function mark_published($job_id, $channel_ids, $buffer_post_ids)
    {
        global $wpdb;

        return $wpdb->update(
            self::get_table_name(),
            array(
                'published_channels' => wp_json_encode($channel_ids),
                'buffer_post_ids' => wp_json_encode($buffer_post_ids),
            ),
            array('job_id' => $job_id)
        );
    }

    public function update_publish_at($job_id, $publish_at)
    {
        global $wpdb;

        return $wpdb->update(
            self::get_table_name(),
            array('publish_at' => $publish_at),
            array('job_id' => $job_id)
        );
    }

    /**
     * Atomically claim a READY_FOR_RENDER job for rendering.
     * Uses a single UPDATE with WHERE clause to prevent race conditions.
     *
     * @param string $job_id
     * @return bool True if claim succeeded, false if job was already claimed or not in correct status
     */
    public function claim_job_for_render($job_id)
    {
        global $wpdb;
        $table = self::get_table_name();
        $now = gmdate('Y-m-d H:i:s');
        $updated = $wpdb->query($wpdb->prepare(
            "UPDATE {$table} 
             SET status = %s, started_at = %s 
             WHERE job_id = %s AND status = %s",
            VS_Job_Status::RENDERING, $now, $job_id, VS_Job_Status::READY_FOR_RENDER
        ));
        return (bool) $updated;
    }

    /**
     * Persist arbitrary column update(s) on a job without a status transition.
     * @NEW 2026-07-10: Used by Content Planner to persist bank_question_ids metadata.
     *
     * @param string $job_id
     * @param array  $data column => value pairs (e.g. ['settings' => '{}']).
     * @return int|false
     */
    public function update_job_fields($job_id, $data)
    {
        global $wpdb;

        if (empty($job_id) || !is_array($data) || empty($data)) {
            return false;
        }

        return $wpdb->update(
            self::get_table_name(),
            $data,
            array('job_id' => $job_id)
        );
    }

    /**
     * @NEW 2026-07-19: Get completed r2_buffer jobs that need manual Buffer push.
     * These jobs failed 3 automatic attempts and have buffer_manual_pending in settings.
     */
    public function get_jobs_need_manual_buffer_push($limit = 50)
    {
        global $wpdb;
        $table = self::get_table_name();

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE status = %s AND video_url IS NOT NULL AND video_url != '' AND (published_channels IS NULL OR published_channels = '') ORDER BY updated_at DESC LIMIT %d",
                VS_Job_Status::COMPLETED,
                $limit
            ),
            ARRAY_A
        );

        $manual = array();
        foreach ($rows as $job) {
            $settings = is_string($job['settings'] ?? '') ? json_decode($job['settings'], true) : ($job['settings'] ?? array());
            if (is_array($settings) && !empty($settings['buffer_manual_pending'])) {
                $manual[] = $job;
            }
        }
        return $manual;
    }

    public function acquire_job_lock($job_id, $timeout_seconds = 300)
    {
        $lock_key = 'mcqvs_job_lock_' . $job_id;
        $locked = get_transient($lock_key);

        if ($locked) {
            return false;
        }

        set_transient($lock_key, 1, $timeout_seconds);
        return true;
    }

    public function release_job_lock($job_id)
    {
        delete_transient('mcqvs_job_lock_' . $job_id);
    }
}