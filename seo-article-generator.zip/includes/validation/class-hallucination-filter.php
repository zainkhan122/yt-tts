<?php

/**
 * Hallucination Filter
 *
 * Detects likely AI hallucinations in generated content and warns (not blocks).
 * Part of Google compliance overhaul to reduce fabricated content.
 *
 * @package SEO_Article_Generator
 * @since   2.2.0
 */

namespace SEO_Article_Generator\Validation;

// Prevent direct access.
if (!defined('ABSPATH')) {
    exit;
}

use SEO_Article_Generator\Traits\Type_Safety;

/**
 * Detects hallucinated content in AI-generated articles.
 *
 * This filter runs AFTER AI returns data but BEFORE validation.
 * It flags suspicious patterns but does NOT block generation.
 * Issues are logged for human review.
 */
class Hallucination_Filter
{
    use Type_Safety;
    /**
     * URL patterns that suggest fabrication.
     * These domains either don't exist or are commonly hallucinated.
     *
     * @var array
     */
    /**
     * URL patterns that suggest fabrication.
     * These domains either don't exist or are commonly hallucinated.
     *
     * @var array
     */
    public const FAKE_URL_PATTERNS = [
        '/example\.com/i',
        '/placeholder/i',
        '/download\.software/i',
        '/officialsite\.com/i',
        '/get-.*-now\.com/i',
        '/software-download\.com/i',
        '/free-download-.*\.com/i',
        '/official-.*-download/i',
        '/update-software\.com/i',
        '/downloadcenter\.com/i',
    ];

    /**
     * Generic marketing phrases in "What's New" that suggest no real changelog.
     *
     * @var array
     */
    private const GENERIC_CHANGELOG_PHRASES = [
        'improved performance',
        'enhanced user experience',
        'bug fixes and improvements',
        'stability improvements',
        'new features added',
        'updated user interface',
        'various improvements',
        'minor fixes',
        'performance enhancements',
        'optimized for speed',
    ];

    /**
     * Check for hallucinated content.
     *
     * @param array $ai_data    AI-generated article data.
     * @param array $input_data Original user input (for comparison).
     * @return array ['valid' => bool, 'issues' => string[], 'suggestions' => string[]]
     */
    public static function check(array $ai_data, array $input_data): array
    {
        $issues = [];
        $suggestions = [];

        // Check 1: Fake download URLs
        $url_issues = self::check_download_urls($ai_data);
        $issues = array_merge($issues, $url_issues);
        if (!empty($url_issues)) {
            $suggestions[] = 'Provide manual download links or verify URL sources.';
        }

        // Check 2: Suspiciously round file sizes (when user didn't provide one)
        $size_issues = self::check_file_size($ai_data, $input_data);
        $issues = array_merge($issues, $size_issues);
        if (!empty($size_issues)) {
            $suggestions[] = 'Verify file size from official source or leave blank.';
        }

        // Check 3: Generic "What's New" content
        $whats_new_issues = self::check_whats_new($ai_data);
        $issues = array_merge($issues, $whats_new_issues);
        if (!empty($whats_new_issues)) {
            $suggestions[] = 'Remove "What\'s New" section if no official changelog exists.';
        }

        // Check 4: Version number mismatch (if user provided one)
        $version_issues = self::check_version_mismatch($ai_data, $input_data);
        $issues = array_merge($issues, $version_issues);
        if (!empty($version_issues)) {
            $suggestions[] = 'AI returned different version than input. Verify against official source.';
        }

        // Check 5: System requirements look templated
        $sysreq_issues = self::check_system_requirements($ai_data);
        $issues = array_merge($issues, $sysreq_issues);
        if (!empty($sysreq_issues)) {
            $suggestions[] = 'System requirements may be guessed. Clear if not verified.';
        }

        // @MODIFIED 2025-12-15 v2.2.0: Check 6: Comparison field count and quality
        $comparison_issues = self::check_comparison_fields($ai_data);
        $issues = array_merge($issues, $comparison_issues);
        if (!empty($comparison_issues)) {
            $suggestions[] = 'Review competitor comparison table for relevance and accuracy.';
        }

        return [
            'valid' => empty($issues),
            'issues' => $issues,
            'suggestions' => array_unique($suggestions),
        ];
    }

    /**
     * Clean content by removing hallucinated/generic sections.
     *
     * @param array $ai_data AI-generated article data.
     * @return array Cleaned article data.
     */
    public static function clean_content(array $ai_data): array
    {
        // 1. Check What's New
        $whats_new_issues = self::check_whats_new($ai_data);
        if (!empty($whats_new_issues)) {
            // Remove generic What's New section
            $ai_data['whats_new'] = [];

            // Log for debugging
            error_log('[SEO-Gen] Auto-removed generic "What\'s New" section.');
        }

        return $ai_data;
    }

    /**
     * Check download URLs for fake patterns.
     *
     * @param array $ai_data AI data.
     * @return array Issues found.
     */
    private static function check_download_urls(array $ai_data): array
    {
        $issues = [];

        if (empty($ai_data['download_section']['links'])) {
            return $issues;
        }

        foreach ($ai_data['download_section']['links'] as $link) {
            $url = self::as_string($link['url'] ?? '');

            foreach (self::FAKE_URL_PATTERNS as $pattern) {
                if (preg_match($pattern, $url)) {
                    $issues[] = "Suspicious download URL detected: {$url}";
                    break;
                }
            }

            // Check for extremely long URLs (often hallucinated paths)
            if (strlen($url) > 300) {
                $issues[] = "Download URL suspiciously long (" . strlen($url) . " chars)";
            }
        }

        return $issues;
    }

    /**
     * Check file size for suspiciously round numbers.
     *
     * @param array $ai_data    AI data.
     * @param array $input_data User input.
     * @return array Issues found.
     */
    private static function check_file_size(array $ai_data, array $input_data): array
    {
        $issues = [];

        $file_size = $ai_data['tech_specs']['file_size'] ?? '';

        // Only flag if user didn't provide file size
        if (!empty($input_data['file_size'])) {
            return $issues;
        }

        if (empty($file_size)) {
            return $issues;
        }

        // Suspiciously round numbers without decimal
        $round_patterns = [
            '/^(10|20|25|50|100|150|200|250|500)\s*(MB|GB)$/i',
            '/^(1|2|5)\s*GB$/i',
        ];

        foreach ($round_patterns as $pattern) {
            if (preg_match($pattern, self::as_string($file_size))) {
                $issues[] = "File size '{$file_size}' looks fabricated (suspiciously round without source)";
                break;
            }
        }

        return $issues;
    }

    /**
     * Check "What's New" for generic marketing speak.
     *
     * @param array $ai_data AI data.
     * @return array Issues found.
     */
    private static function check_whats_new(array $ai_data): array
    {
        $issues = [];

        $whats_new = $ai_data['whats_new'] ?? [];

        if (empty($whats_new) || !is_array($whats_new)) {
            return $issues;
        }

        $generic_count = 0;
        $total_items = count($whats_new);

        foreach ($whats_new as $item) {
            $item_lower = strtolower(is_string($item) ? $item : '');

            foreach (self::GENERIC_CHANGELOG_PHRASES as $phrase) {
                if (strpos($item_lower, $phrase) !== false) {
                    $generic_count++;
                    break;
                }
            }
        }

        // If more than 50% of items are generic, flag it
        if ($total_items > 0 && ($generic_count / $total_items) > 0.5) {
            $issues[] = "What's New section appears to be generic marketing speak ({$generic_count}/{$total_items} items)";
        }

        return $issues;
    }

    /**
     * Check for version number mismatch with input.
     *
     * @param array $ai_data    AI data.
     * @param array $input_data User input.
     * @return array Issues found.
     */
    private static function check_version_mismatch(array $ai_data, array $input_data): array
    {
        $issues = [];

        $input_version = self::as_string($input_data['version'] ?? '');
        $ai_version = self::as_string($ai_data['tech_specs']['version'] ?? '');

        if (empty($input_version) || empty($ai_version)) {
            return $issues;
        }

        // Normalize versions for comparison (remove "v" prefix, etc.)
	$input_normalized = preg_replace('/^v/i', '', strtolower((string)$input_version));
	$ai_normalized = preg_replace('/^v/i', '', strtolower((string)$ai_version));

        if ($input_normalized !== $ai_normalized) {
            $issues[] = "Version mismatch: Input='{$input_version}' but AI returned='{$ai_version}'";
        }

        return $issues;
    }

    /**
     * Check system requirements for templated/fabricated patterns.
     *
     * @param array $ai_data AI data.
     * @return array Issues found.
     */
    private static function check_system_requirements(array $ai_data): array
    {
        $issues = [];

        $sys_reqs = $ai_data['system_requirements'] ?? [];

        if (empty($sys_reqs['minimum'])) {
            return $issues;
        }

        $min = $sys_reqs['minimum'];

        // Common templated patterns that are often guessed
        $templated_patterns = [
            'ram' => '/^(4|8)\s*GB(\s+RAM)?$/i',     // Exact 4GB or 8GB = likely guessed
            'storage' => '/^(100|500)\s*MB$/i',     // Exact 100MB or 500MB = likely guessed
        ];

        $suspicious_fields = 0;

        if (!empty($min['ram']) && preg_match($templated_patterns['ram'], self::as_string($min['ram']))) {
            $suspicious_fields++;
        }

        if (!empty($min['storage']) && preg_match($templated_patterns['storage'], self::as_string($min['storage']))) {
            $suspicious_fields++;
        }

        if ($suspicious_fields >= 2) {
            $issues[] = "System requirements look templated (multiple exact round numbers)";
        }

        return $issues;
    }

    /**
     * Check comparison fields for quality issues.
     * @MODIFIED 2025-12-15 v2.2.0: Added for dynamic competitor table validation
     *
     * @param array $ai_data AI data.
     * @return array Issues found.
     */
    private static function check_comparison_fields(array $ai_data): array
    {
        $issues = [];

        $competitors = $ai_data['competitors'] ?? [];

        if (empty($competitors)) {
            return $issues;
        }

        // Check 1: New format field count (if using comparison_fields)
        if (isset($competitors[0]['comparison_fields']) && is_array($competitors[0]['comparison_fields'])) {
            $field_count = count($competitors[0]['comparison_fields']);

            if ($field_count < 4) {
                $issues[] = "Comparison table has too few fields ({$field_count}). Recommend 6-10 for meaningful comparison.";
            }

            if ($field_count > 12) {
                $issues[] = "Comparison table has too many fields ({$field_count}). Consider trimming to 8-10 for readability.";
            }

            // Check 2: Detect if ALL competitors have identical values for a field (likely hallucinated)
            $field_values = [];
            foreach ($competitors as $competitor) {
                foreach ($competitor['comparison_fields'] as $field_data) {
                    $field_name = $field_data['field'] ?? 'unknown';
                    $field_values[$field_name][] = strtolower(self::as_string($field_data['value'] ?? ''));
                }
            }

            foreach ($field_values as $field_name => $values) {
                $unique_values = array_unique($values);
                // If all competitors have the exact same value (and not "Yes" or "No" which are expected)
                if (count($unique_values) === 1 && count($values) > 1) {
                    $single_value = $unique_values[0];
                    if (!in_array($single_value, ['yes', 'no', 'n/a', 'unknown'])) {
                        $issues[] = "Suspicious: All competitors have identical value for '{$field_name}' ('{$single_value}')";
                    }
                }
            }
        } else {
            // Legacy format: Check for number of competitors
            if (count($competitors) > 5) {
                $issues[] = "Too many competitors (" . count($competitors) . "). Recommend max 3-4 for focused comparison.";
            }
        }

        return $issues;
    }
}
