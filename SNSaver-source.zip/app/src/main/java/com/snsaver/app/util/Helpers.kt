package com.snsaver.app.util
import android.content.*
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.os.Build
import android.provider.MediaStore
import com.snsaver.app.domain.model.MediaType
import dagger.hilt.android.qualifiers.ApplicationContext
import okhttp3.*
import java.io.File
import javax.inject.Inject

class ClipboardHelper @Inject constructor(@ApplicationContext private val context:Context){
 fun read()=(context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).primaryClip?.getItemAt(0)?.coerceToText(context)?.toString()
 fun copy(value:String)=(context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("SNSaver",value))
}
class FileHelper @Inject constructor(@ApplicationContext private val context:Context,private val client:OkHttpClient){
 private val dir get()=File(context.filesDir,"downloads").apply{mkdirs()}
 suspend fun download(url:String,name:String,progress:(Long,Long)->Unit)=kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO){
  val target=File(dir,name);client.newCall(Request.Builder().url(url).build()).execute().use{r->if(!r.isSuccessful)error("Download returned HTTP ${r.code}");val body=r.body?:error("Empty download");body.byteStream().use{i->target.outputStream().use{o->val b=ByteArray(64*1024);var n:Int;var done=0L;while(i.read(b).also{n=it}>=0){o.write(b,0,n);done+=n;progress(done,body.contentLength())}}}};target}
 fun thumbnail(path:String):File{val out=File(context.cacheDir,"thumbnails/thumb_${System.currentTimeMillis()}.jpg").apply{parentFile?.mkdirs()};val r=MediaMetadataRetriever();try{r.setDataSource(path);val bmp=r.getFrameAtTime(0)?:error("No video frame");out.outputStream().use{bmp.compress(Bitmap.CompressFormat.JPEG,82,it)}}finally{r.release()};return out}
 fun delete(path:String)=runCatching{File(path).delete()}.getOrDefault(false)
 fun size()=dir.walkTopDown().filter{it.isFile}.sumOf{it.length()}
}
class MediaStoreHelper @Inject constructor(@ApplicationContext private val context:Context){
 fun save(file:File,type:MediaType):String{val image=type==MediaType.IMAGE;val values=ContentValues().apply{put(MediaStore.MediaColumns.DISPLAY_NAME,file.name);put(MediaStore.MediaColumns.MIME_TYPE,if(image)"image/jpeg" else "video/mp4");if(Build.VERSION.SDK_INT>=29){put(MediaStore.MediaColumns.RELATIVE_PATH,(if(image)"Pictures" else "Movies")+"/SNSaver");put(MediaStore.MediaColumns.IS_PENDING,1)}};val collection=if(image)MediaStore.Images.Media.EXTERNAL_CONTENT_URI else MediaStore.Video.Media.EXTERNAL_CONTENT_URI;val uri=context.contentResolver.insert(collection,values)?:error("Unable to create gallery entry");try{context.contentResolver.openOutputStream(uri)?.use{o->file.inputStream().use{it.copyTo(o)}}?:error("Unable to open gallery entry");if(Build.VERSION.SDK_INT>=29){values.clear();values.put(MediaStore.MediaColumns.IS_PENDING,0);context.contentResolver.update(uri,values,null,null)};return uri.toString()}catch(e:Exception){context.contentResolver.delete(uri,null,null);throw e}}
}
