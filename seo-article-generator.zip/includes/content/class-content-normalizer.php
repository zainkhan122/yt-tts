<?php
// FILE: includes/content/class-content-normalizer.php

namespace SEO_Article_Generator\Content;

defined('ABSPATH') || exit;

final class Content_Normalizer
{
    public static function normalize(string $html, array $required_sections = array()): array
    {
        $original = $html;
        $repairs = array();

        $html = self::normalize_newlines($html);

        [$html, $count] = self::normalize_gutenberg_comments($html);
        if ($count > 0) {
            $repairs['gutenberg_comments_normalized'] = $count;
        }

        [$html, $count] = self::repair_broken_zone_sentinels($html);
        if ($count > 0) {
            $repairs['sentinels_repaired'] = $count;
        }

        [$html, $count] = self::inject_missing_zone_sentinels($html);
        if ($count > 0) {
            $repairs['sentinels_injected'] = $count;
        }

        [$html, $count] = self::dedupe_duplicate_zone_sentinels($html);
        if ($count > 0) {
            $repairs['duplicate_sentinels_removed'] = $count;
        }

        [$html, $count] = self::close_orphaned_gutenberg_blocks($html);
        if ($count > 0) {
            $repairs['orphaned_gutenberg_blocks_closed'] = $count;
        }

        [$html, $count] = self::close_orphaned_html_wrappers($html);
        if ($count > 0) {
            $repairs['orphaned_html_wrappers_closed'] = $count;
        }

        [$html, $count] = self::strip_fragment_garbage($html);
        if ($count > 0) {
            $repairs['fragment_garbage_removed'] = $count;
        }

        $zone_report = self::build_zone_report($html, $required_sections);

        return array(
            'original_html'   => $original,
            'normalized_html' => $html,
            'changed'         => $html !== $original,
            'repairs'         => $repairs,
            'zone_report'     => $zone_report,
        );
    }

    private static function normalize_newlines(string $html): string
    {
        $html = str_replace(array("\r\n", "\r"), "\n", $html);
        $html = preg_replace("/\n{3,}/", "\n\n", $html);
        return (string) $html;
    }

    private static function normalize_gutenberg_comments(string $html): array
    {
        $count = 0;

        $patterns = array(
            '/<\!--\s*wp:/i'     => '<!-- wp:',
            '/<\!--\s*\/\s*wp:/i' => '<!-- /wp:',
            '/<\!\-\-\s*wp:/i'    => '<!-- wp:',
            '/<\!\-\-\s*\/\s*wp:/i' => '<!-- /wp:',
        );

        foreach ($patterns as $pattern => $replacement) {
            $html = preg_replace($pattern, $replacement, $html, -1, $hits);
            $count += (int) $hits;
        }

        $html = preg_replace('/<!--\s*(\/?wp:[a-z0-9\/\-_]+)([^>]*)--\s*>/i', '<!-- $1$2 -->', $html, -1, $hits);
        $count += (int) $hits;

        $html = preg_replace('/<!--\s*(\/?wp:[a-z0-9\/\-_]+)([^>\n]*?)(?=\n|<)/i', '<!-- $1$2 -->', $html, -1, $hits);
        $count += (int) $hits;

        return array($html, $count);
    }

	private static function repair_broken_zone_sentinels(string $html): array
	{
		$count = 0;
		$map   = self::zone_alias_map();

		$html = preg_replace_callback(
			'/<!--\s*seo[\s\-_]*gen[\s\-_]*zone\s*[:=]?\s*([a-z0-9\-_]+)\s*(?:-->)?/i',
			static function (array $m) use (&$count, $map): string {
				$raw = strtolower(trim((string) ($m[1] ?? '')));
				$key = str_replace(array('_', ' '), '-', $raw);

				if (isset($map[$key])) {
					$normalized = '<!-- seo-gen-zone:' . $map[$key] . ' -->';
					if ($m[0] !== $normalized) {
						$count++;
					}
					return $normalized;
				}

				$canonical = \SEO_Article_Generator\Generator\Article_Schema::get_canonical_key($key);
				if (is_string($canonical) && $canonical !== '') {
					$normalized = '<!-- seo-gen-zone:' . $canonical . ' -->';
					if ($m[0] !== $normalized) {
						$count++;
						return $normalized;
					}
				}

				return $m[0];
			},
			$html
		);

		return array($html, $count);
	}

    private static function inject_missing_zone_sentinels(string $html): array
    {
        $count   = 0;
        $present = self::extract_present_zones($html);
        $specs   = self::zone_marker_specs($html);

        foreach (\SEO_Article_Generator\Generator\Article_Schema::get_ordered_section_keys() as $zone) {
            if (isset($present[$zone])) {
                continue;
            }

            if (empty($specs[$zone]) || !is_array($specs[$zone])) {
                continue;
            }

            $offset = self::locate_zone_opening_tag($html, $specs[$zone]);

            if ($offset === false) {
                continue;
            }

            $html = substr_replace($html, '<!-- seo-gen-zone:' . $zone . ' -->' . "\n", $offset, 0);
            $present[$zone] = true;
            $count++;
        }

        return array($html, $count);
    }

    private static function extract_present_zones(string $html): array
    {
        $present = array();

        preg_match_all(
            '/<!--\s*wp:seo-gen\/section\s+\{[^}]*"zone"\s*:\s*"([a-z0-9_-]+)"[^}]*\}\s*-->/i',
            $html,
            $block_matches
        );

        foreach ((array) ($block_matches[1] ?? array()) as $zone) {
            $canonical = \SEO_Article_Generator\Generator\Article_Schema::get_canonical_key((string) $zone);
            if (is_string($canonical) && $canonical !== '') {
                $present[$canonical] = true;
            }
        }

        preg_match_all('/<!--\s*seo-gen-zone:([a-z0-9_-]+)\s*-->/i', $html, $comment_matches);

        foreach ((array) ($comment_matches[1] ?? array()) as $zone) {
            $canonical = \SEO_Article_Generator\Generator\Article_Schema::get_canonical_key((string) $zone);
            if (is_string($canonical) && $canonical !== '') {
                $present[$canonical] = true;
            }
        }

        return $present;
    }

	private static function locate_zone_opening_tag(string $html, array $spec): int|false
	{
		$patterns = array();

		if (!empty($spec['data_attr'])) {
			$patterns[] = '/<[a-z0-9:-]+\b[^>]*\bdata-seo-gen-zone\s*=\s*([\'"])' . preg_quote((string) $spec['data_attr'], '/') . '\1[^>]*>/i';
		}

		foreach (array('block_class', 'legacy_class') as $class_key) {
			if (!empty($spec[$class_key])) {
				$patterns[] = '/<[a-z0-9:-]+\b[^>]*\bclass\s*=\s*([\'"])[^\'"]*\b' . preg_quote((string) $spec[$class_key], '/') . '\b[^\'"]*\1[^>]*>/i';
			}
		}

		if (!empty($spec['anchor_id'])) {
			$patterns[] = '/<[a-z0-9:-]+\b[^>]*\bid\s*=\s*([\'"])' . preg_quote((string) $spec['anchor_id'], '/') . '\1[^>]*>/i';
		}

		foreach ((array) ($spec['anchor_id_patterns'] ?? array()) as $pattern) {
			if (is_string($pattern) && $pattern !== '') {
				$patterns[] = $pattern;
			}
		}

		foreach ($patterns as $pattern) {
			if (!preg_match($pattern, $html, $m, PREG_OFFSET_CAPTURE)) {
				continue;
			}

			$offset    = (int) $m[0][1];
			$tag_start = strrpos(substr($html, 0, $offset + 1), '<');

			if ($tag_start === false) {
				return $offset;
			}

			$before_tag = substr($html, 0, $tag_start);

			// FIX: Prevent catastrophic backtracking that consumes all preceding blocks.
			// Use (?:(?!-->).)* to strictly isolate only the immediately preceding block comment, 
			// ensuring sentinels aren't incorrectly injected at offset 0 (top of the document).
			if (preg_match('/(?:(?!-->).)*-->\s*$/is', $before_tag, $block_match, PREG_OFFSET_CAPTURE)) {
				$raw_block   = (string) $block_match[0][0];
				$block_start = (int) $block_match[0][1];

				if (!preg_match('/\/\s*-->$/', $raw_block)) {
					$block_end = $block_start + strlen($raw_block);
					$between   = substr($html, $block_end, $tag_start - $block_end);

					if (trim($between) === '') {
						return $block_start;
					}
				}
			}

			return (int) $tag_start;
		}

		return false;
	}

    private static function dedupe_duplicate_zone_sentinels(string $html): array
    {
        $count = 0;

        foreach (array_keys(self::zone_marker_specs()) as $zone) {
            $sentinel = preg_quote('<!-- seo-gen-zone:' . $zone . ' -->', '/');
            $html = preg_replace('/(?:' . $sentinel . '\s*){2,}/', '<!-- seo-gen-zone:' . $zone . ' -->' . "\n", $html, -1, $hits);
            $count += (int) $hits;
        }

        return array($html, $count);
    }

    private static function close_orphaned_gutenberg_blocks(string $html): array
    {
        $count = 0;
        $tokens = array();

        if (! preg_match_all('/<!--\s*(\/?)wp:([a-z0-9\/\-_]+)(.*?)-->/is', $html, $matches, PREG_OFFSET_CAPTURE)) {
            return array($html, 0);
        }

        foreach ($matches[0] as $i => $full) {
            $raw = (string) $full[0];
            $offset = (int) $full[1];
            $closing = trim((string) $matches[1][$i][0]) === '/';
            $slug = strtolower(trim((string) $matches[2][$i][0]));
            $self_closing = (bool) preg_match('/\/\s*-->$/', $raw);

            $tokens[] = array(
                'raw' => $raw,
                'offset' => $offset,
                'closing' => $closing,
                'slug' => $slug,
                'self_closing' => $self_closing,
            );
        }

        $stack = array();
        $remove = array();

        foreach ($tokens as $idx => $token) {
            if ($token['self_closing']) {
                continue;
            }

            if (! $token['closing']) {
                $stack[] = $token['slug'];
                continue;
            }

            $last = end($stack);
            if ($last === $token['slug']) {
                array_pop($stack);
                continue;
            }

            if (in_array($token['slug'], $stack, true)) {
                while (! empty($stack) && end($stack) !== $token['slug']) {
                    $missing = array_pop($stack);
                    $html .= "\n<!-- /wp:" . $missing . " -->";
                    $count++;
                }
                if (! empty($stack) && end($stack) === $token['slug']) {
                    array_pop($stack);
                }
            } else {
                $remove[] = $idx;
            }
        }

        if (! empty($remove)) {
            rsort($remove);
            foreach ($remove as $idx) {
                $tok = $tokens[$idx];
                $html = substr_replace($html, '', $tok['offset'], strlen($tok['raw']));
                $count++;
            }
        }

        while (! empty($stack)) {
            $missing = array_pop($stack);
            $html .= "\n<!-- /wp:" . $missing . " -->";
            $count++;
        }

        return array($html, $count);
    }

    private static function close_orphaned_html_wrappers(string $html): array
    {
        $count = 0;
        $tag_pattern = '/<\/?([a-z][a-z0-9]*)\b[^>]*>/i';
        $void = array('br','img','hr','meta','link','input','source','area','base','col','embed','track','wbr');
        $stack = array();

        if (! preg_match_all($tag_pattern, $html, $matches, PREG_OFFSET_CAPTURE)) {
            return array($html, 0);
        }

        foreach ($matches[0] as $i => $full) {
            $tag = strtolower((string) $matches[1][$i][0]);
            $raw = (string) $full[0];

            if (in_array($tag, $void, true)) {
                continue;
            }

            if (preg_match('/^<\//', $raw)) {
                $last = end($stack);
                if ($last === $tag) {
                    array_pop($stack);
                }
                continue;
            }

            if (preg_match('/\/>$/', $raw)) {
                continue;
            }

            if (in_array($tag, array('div','section','article','table','tbody','thead','tr','td','th','ul','ol','li','p','details','summary'), true)) {
                $stack[] = $tag;
            }
        }

        while (! empty($stack)) {
            $tag = array_pop($stack);
            $html .= '</' . $tag . '>';
            $count++;
        }

        return array($html, $count);
    }

    private static function strip_fragment_garbage(string $html): array
    {
        $count = 0;

        $html = preg_replace('/^\s*(<\/(?:td|tr|tbody|thead|table|li|ul|ol|p|div|section)>[\s\n]*)+/i', '', $html, -1, $hits);
        $count += (int) $hits;

        $html = preg_replace('/(?:<!--\s*\/?wp:[a-z0-9\/\-_]+\s*-->\s*){3,}$/i', '', $html, -1, $hits);
        $count += (int) $hits;

        $html = preg_replace('/\n{3,}/', "\n\n", $html, -1, $hits);
        $count += (int) $hits;

        return array($html, $count);
    }

    private static function build_zone_report(string $html, array $required_sections = array()): array
    {
        $report = array();
        $zones  = self::zone_marker_specs($html);

        foreach ($zones as $zone => $spec) {
            $sentinel       = '<!-- seo-gen-zone:' . $zone . ' -->';
            $sentinel_count = substr_count($html, $sentinel);

            $marker_count = 0;
            if (! empty($spec['data_attr'])) {
                $marker_count += substr_count($html, 'data-seo-gen-zone="' . $spec['data_attr'] . '"');
            }
            if (! empty($spec['block_class'])) {
                $marker_count += substr_count($html, $spec['block_class']);
            }
            if (! empty($spec['legacy_class'])) {
                $marker_count += substr_count($html, $spec['legacy_class']);
            }
            if (! empty($spec['anchor_id'])) {
                $marker_count += substr_count($html, 'id="' . $spec['anchor_id'] . '"');
            }
            // Count fuzzy anchor pattern matches for the report.
            if (! empty($spec['anchor_id_patterns'])) {
                foreach ((array) $spec['anchor_id_patterns'] as $pattern) {
                    $marker_count += (int) preg_match_all($pattern, $html);
                }
            }

            $report[$zone] = array(
                'sentinel_count' => $sentinel_count,
                'marker_count'   => $marker_count,
                'required'       => in_array($zone, $required_sections, true),
            );
        }

        return $report;
    }

	private static function zone_alias_map(): array
	{
		return \SEO_Article_Generator\Generator\Article_Schema::get_alias_map();
	}

	public static function zone_marker_specs(string $html = ''): array
	{
		$defaults = class_exists('\SEO_Article_Generator\Generator\Article_Schema')
			? \SEO_Article_Generator\Generator\Article_Schema::get_marker_specs()
			: array();

		if (function_exists('apply_filters')) {
			$filtered = apply_filters('seo_gen_zone_marker_specs', $defaults, $html);
			return is_array($filtered) ? $filtered : $defaults;
		}

		return $defaults;
	}
}
