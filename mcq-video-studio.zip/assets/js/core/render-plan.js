/**
 * MCQVS Render Plan
 * Single source of truth for timeline timing + cue points shared by Preview and Export.
 *
 * @package MCQ_Video_Studio
 * @since 9.0.0
 */
(function (window) {
  "use strict";

  const MCQVS_RenderPlan = {
    /**
     * Build a deterministic render plan from an already-built playlist.
     *
     * @param {Array} playlist - [{id,type,duration,content,timing}]
     * @param {Object} opts - {fps,width,height,templateId}
     * @returns {Object} plan
     */
    buildFromPlaylist(playlist, opts = {}) {
      const fps = Number(opts.fps || 30);
      const frameMs = 1000 / fps;

      const snap = (ms) => {
        const frames = Math.max(0, Math.round(Number(ms || 0) / frameMs));
        return frames * frameMs;
      };

      const plan = {
        version: 1,
        fps,
        frameMs,
        width: Number(opts.width || 1080),
        height: Number(opts.height || 1920),
        templateId: opts.templateId || null,
        createdAt: new Date().toISOString(),
        scenes: [],
        cues: [],
        assets: {
          images: [],
          audio: [],
          fonts: [],
        },
        totalMs: 0,
      };

      let cursor = 0;
      let firstSceneStart = null;
      let lastSceneEnd = null;
      (playlist || []).forEach((scene) => {
        const dur = snap(scene.duration || 0);
        const startMs = snap(cursor);
        if (firstSceneStart === null) firstSceneStart = startMs;

        const sceneEntry = {
          id: String(scene.id || ""),
          type: String(scene.type || "unknown"),
          startMs,
          durMs: dur,
          endMs: startMs + dur,
          content: scene.content || {},
          timing: scene.timing ? Object.assign({}, scene.timing, { questionTotal: dur }) : null,
        };
        plan.scenes.push(sceneEntry);

        // Global cue points for intro/outro boundaries
        if (sceneEntry.type === "hook" || sceneEntry.type === "intro") {
          plan.cues.push({ type: "intro_start", sceneId: sceneEntry.id, atMs: sceneEntry.startMs });
          plan.cues.push({ type: "intro_end", sceneId: sceneEntry.id, atMs: sceneEntry.endMs });
        }
        if (sceneEntry.type === "outro") {
          plan.cues.push({ type: "outro_start", sceneId: sceneEntry.id, atMs: sceneEntry.startMs });
        }

        // Cue points for question reveal (used by sparkles, SFX, etc.)
        if (sceneEntry.type === "question") {
          const revealMs = Number(sceneEntry.timing?.questionPhases?.reveal || 3000);
          const introMs = Number(sceneEntry.timing?.questionPhases?.intro || 0);
          const revealStart = snap(Math.max(0, sceneEntry.endMs - revealMs));
          sceneEntry.timing._revealStartRel = revealStart - sceneEntry.startMs;
          const readingDur = Math.max(0, revealStart - sceneEntry.startMs - introMs);
          // @FIX 2026-07-28: Ticks start 5 seconds BEFORE the visual reveal point (timer=0).
          //                   This ensures the timer glow/blinking fires in the last 5 seconds
          //                   of the countdown, matching user requirement.
          const tickStart = snap(Math.max(sceneEntry.startMs, revealStart - 5000));
          plan.cues.push({
            type: "question_start",
            sceneId: sceneEntry.id,
            atMs: sceneEntry.startMs,
          });
          plan.cues.push({
            type: "reveal_start",
            sceneId: sceneEntry.id,
            atMs: revealStart,
          });

          // Correct answer is displayed at reveal start (used for sparkles + result SFX)
          plan.cues.push({
            type: "reveal_correct",
            sceneId: sceneEntry.id,
            atMs: revealStart,
          });

          // Countdown begins (5 seconds before reveal)
          plan.cues.push({
            type: "countdown_start",
            sceneId: sceneEntry.id,
            atMs: tickStart,
          });

          // Countdown ticks in the last 5 seconds before reveal
          for (let i = 0; i < 5; i++) {
            const at = tickStart + i * 1000;
            if (at >= sceneEntry.startMs && at < revealStart) {
              plan.cues.push({
                type: "tick",
                sceneId: sceneEntry.id,
                atMs: snap(at),
              });
            }
          }

          // Useful for audio ducking and FX scheduling
          plan.cues.push({
            type: "reading_end",
            sceneId: sceneEntry.id,
            atMs: revealStart,
            meta: { readingMs: snap(readingDur), revealMs: snap(revealMs) },
          });
        }

        cursor = sceneEntry.endMs;
        lastSceneEnd = sceneEntry.endMs;
      });

      plan.totalMs = snap(cursor);

      if (firstSceneStart !== null) {
        plan.cues.push({ type: "timeline_start", sceneId: "_", atMs: snap(firstSceneStart) });
      }
      if (lastSceneEnd !== null) {
        plan.cues.push({ type: "timeline_end", sceneId: "_", atMs: snap(lastSceneEnd) });
      }

      return plan;
    },

    /**
     * Collect assets referenced by config (best-effort).
     * This does NOT attempt deep template introspection (templates remain independent).
     */
    collectAssetsFromConfig(plan, config = {}) {
      const add = (arr, v) => {
        if (!v) return;
        if (Array.isArray(v)) v.forEach((x) => add(arr, x));
        else if (!arr.includes(v)) arr.push(v);
      };

      // Audio
      add(plan.assets.audio, config.musicUrl);
      add(plan.assets.audio, config.voiceUrl);
      if (config.sfx) Object.values(config.sfx).forEach((u) => add(plan.assets.audio, u));

      // Images
      add(plan.assets.images, config.logoUrl);
      add(plan.assets.images, config.backgroundImageUrl);

      // Fonts (worker-safe font list)
      add(plan.assets.fonts, config.fontFamily);

      return plan;
    },
  };

  window.MCQVS_RenderPlan = MCQVS_RenderPlan;
  // @FIX: Some legacy callers (`studio.export.js` line ~223) reference `MCQVSRenderPlan`
  //       without the underscore; alias both forms to the same object so neither fails.
  window.MCQVSRenderPlan  = MCQVS_RenderPlan;
  if (window.MCQVS_PlanBuilder && window.MCQVS_PlanBuilder.buildFromPlaylist) {
      window.MCQVSPlanBuilder = window.MCQVS_PlanBuilder;
  }
})(window);
