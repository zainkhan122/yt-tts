<?php

namespace DIT\TrendStudio\DTO;

/**
 * Data Transfer Object representing a single trend or idea.
 */
class TrendDTO
{
    /**
     * The topic or seed phrase for the trend.
     *
     * @var string
     */
    public string $topic;

    /**
     * Top-level category for the trend.
     *
     * @var string
     */
    public string $category;

    /**
     * Growth velocity of the trend (e.g. "fast", "steady").
     *
     * @var string
     */
    public string $velocity;

    /**
     * Freshness indicator (e.g. "new", "established").
     *
     * @var string
     */
    public string $freshness;

    /**
     * @param string $topic
     * @param string $category
     * @param string $velocity
     * @param string $freshness
     */
    public function __construct(string $topic, string $category, string $velocity, string $freshness)
    {
        $this->topic     = $topic;
        $this->category  = $category;
        $this->velocity  = $velocity;
        $this->freshness = $freshness;
    }
}
