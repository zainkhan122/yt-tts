<?php
/**
 * CPG v3.3 audit harness — emulates enough of WordPress to EXECUTE the real
 * plugin file through full multi-run scenarios. Any PHP notice/warning is
 * promoted to an exception and fails the suite.
 */
error_reporting(E_ALL);
set_error_handler(function ($no, $str, $file, $line) { throw new Exception("PHP $no: $str @ $file:$line"); });

define('ABSPATH', '/tmp/');
define('MINUTE_IN_SECONDS', 60); define('HOUR_IN_SECONDS', 3600); define('DAY_IN_SECONDS', 86400);

$GLOBALS['TOptions'] = array(); $GLOBALS['TPosts'] = array(); $GLOBALS['TMeta'] = array();
$GLOBALS['TTrans'] = array(); $GLOBALS['TFeeds'] = array(); $GLOBALS['TNextId'] = 50;

/* ---------- WP stubs ---------- */
function add_action(...$a) {} function add_filter(...$a) {}
function register_activation_hook(...$a) {} function register_deactivation_hook(...$a) {}
function wp_next_scheduled($h) { return isset($GLOBALS['TSched'][$h]) ? $GLOBALS['TSched'][$h] : false; }
function wp_schedule_event($t, $i, $h) { $GLOBALS['TSched'][$h] = $t; return true; }
function wp_clear_scheduled_hook($h) { unset($GLOBALS['TSched'][$h]); }
function get_transient($k) { return isset($GLOBALS['TTrans'][$k]) ? $GLOBALS['TTrans'][$k] : false; }
function set_transient($k, $v, $e = 0) { $GLOBALS['TTrans'][$k] = $v; return true; }
function delete_transient($k) { unset($GLOBALS['TTrans'][$k]); return true; }
class TErr { private $m; public function __construct($m) { $this->m = $m; } public function get_error_message() { return $this->m; } }
function is_wp_error($x) { return $x instanceof TErr; }
function wp_remote_get($url) {
	// v3.5.8: anything that is not one of our feed/directory hosts = a proxy/relay call.
	// Must compare the actual HOST — proxy URLs embed the encoded target URL, which
	// contains "sanaullastore.com" inside the ?url= parameter.
	$t_host = parse_url($url, PHP_URL_HOST);
	if (!in_array($t_host, array('sanaullastore.com', 'www.thefashionstation.in'), true)) {
		$GLOBALS['TProxyCalls'] = isset($GLOBALS['TProxyCalls']) ? $GLOBALS['TProxyCalls'] : array();
		$GLOBALS['TProxyCalls'][] = $url;
		if (!empty($GLOBALS['TProxyFail']) && in_array($t_host, (array)$GLOBALS['TProxyFail'], true)) return array('response' => array('code' => 500), 'body' => ''); // fail only listed proxy hosts
		return array('response' => array('code' => 200), 'body' => isset($GLOBALS['TProxyBody']) ? $GLOBALS['TProxyBody'] : '');
	}
	$GLOBALS['TFetchCount'][$url] = (isset($GLOBALS['TFetchCount'][$url]) ? $GLOBALS['TFetchCount'][$url] : 0) + 1;
	if (!empty($GLOBALS['TFailOnce'][$url]) && 1 === $GLOBALS['TFetchCount'][$url]) {
		return array('response' => array('code' => 403), 'body' => ''); // first call blocked, retry gets through
	}
	if (!empty($GLOBALS['TForceCode'][$url])) {
		return array('response' => array('code' => (int)$GLOBALS['TForceCode'][$url]), 'body' => ''); // persistent block (403) or death (404)
	}
	if (isset($GLOBALS['TFeeds'][$url])) return array('response' => array('code' => 200), 'body' => $GLOBALS['TFeeds'][$url]);
	return array('response' => array('code' => 404), 'body' => '');
}
function wp_remote_retrieve_response_code($r) { return isset($r['response']['code']) ? $r['response']['code'] : 0; }
function wp_remote_retrieve_body($r) { return isset($r['body']) ? $r['body'] : ''; }
function esc_html($t) { return htmlspecialchars((string)$t, ENT_QUOTES); }
function esc_attr($t) { return htmlspecialchars((string)$t, ENT_QUOTES); }
function esc_url($u) { return $u; } function esc_url_raw($u) { return $u; }
function wp_strip_all_tags($s) { return trim(strip_tags((string)$s)); }
function sanitize_text_field($t) { return trim(strip_tags((string)$t)); }
function sanitize_key($t) { return strtolower(preg_replace('/[^a-z0-9_\-]/i', '', (string)$t)); }
function sanitize_title($t) { return trim(preg_replace('/[^a-z0-9]+/i', '-', strtolower((string)$t)), '-'); }
function number_format_i18n($n) { return number_format($n); }
function date_i18n($f) { return date($f); }
function current_time($f) { return date($f); }
function get_date_from_gmt($s, $f) { return $s; }
function get_option($k, $d = false) { return array_key_exists($k, $GLOBALS['TOptions']) ? $GLOBALS['TOptions'][$k] : $d; }
function update_option($k, $v, $a = null) { $GLOBALS['TOptions'][$k] = $v; return true; }
function delete_option($k) { unset($GLOBALS['TOptions'][$k]); return true; }
function wp_parse_args($a, $d) { return array_merge($d, (array)$a); }
function absint($n) { return abs((int)$n); }
function wp_list_pluck($arr, $field) { $o = array(); foreach ($arr as $x) { $o[] = $x[$field]; } return $o; }

function wp_insert_post($arr) {
	$id = isset($arr['ID']) ? (int)$arr['ID'] : 0;
	if (!$id) { $id = ++$GLOBALS['TNextId']; }
	$defaults = array('post_type' => 'post', 'post_status' => 'draft', 'post_title' => '', 'post_content' => '', 'post_parent' => 0, 'post_date' => current_time('Y-m-d H:i:s'), 'post_date_gmt' => gmdate('Y-m-d H:i:s'));
	$merged = array_merge($defaults, $arr);
	$merged['ID'] = $id;
	$GLOBALS['TPosts'][$id] = (object)$merged;
	return $id;
}
function wp_update_post($arr) { // real WP merges with the existing post — stub must too
	$id = isset($arr['ID']) ? (int)$arr['ID'] : 0;
	$cur = ($id && isset($GLOBALS['TPosts'][$id])) ? (array)$GLOBALS['TPosts'][$id] : array();
	$merged = array_merge(array('post_type' => 'post', 'post_status' => 'draft', 'post_title' => '', 'post_content' => '', 'post_parent' => 0, 'post_date' => current_time('Y-m-d H:i:s'), 'post_date_gmt' => gmdate('Y-m-d H:i:s')), $cur, $arr);
	if (!$id) { $id = ++$GLOBALS['TNextId']; }
	$merged['ID'] = $id;
	$GLOBALS['TPosts'][$id] = (object)$merged;
	return $id;
}
function get_post($id) { return isset($GLOBALS['TPosts'][(int)$id]) ? $GLOBALS['TPosts'][(int)$id] : null; }
function get_post_field($f, $id) { $p = get_post($id); return $p ? $p->$f : ''; }
function update_post_meta($id, $k, $v) { $GLOBALS['TMeta'][(int)$id][$k] = $v; return true; }
function get_post_meta($id, $k, $single = false) {
	$v = isset($GLOBALS['TMeta'][(int)$id][$k]) ? $GLOBALS['TMeta'][(int)$id][$k] : '';
	return $single ? $v : array($v);
}
function wp_set_post_tags($id, $tags, $append) {
	$old = isset($GLOBALS['TMeta'][(int)$id]['_tags']) ? $GLOBALS['TMeta'][(int)$id]['_tags'] : array();
	$GLOBALS['TMeta'][(int)$id]['_tags'] = $append ? array_merge($old, (array)$tags) : (array)$tags;
}
function set_post_thumbnail($id, $thumb) { $GLOBALS['TMeta'][(int)$id]['_thumbnail_id'] = $thumb; }
function media_sideload_image($src, $post_id, $desc = null, $return = 'html') {
	if (strpos($src, 'bad') !== false) { return new TErr('Fake download failure'); }
	$id = wp_insert_post(array('post_type' => 'attachment', 'post_status' => 'inherit', 'post_parent' => $post_id, 'post_title' => $desc));
	return $id;
}
function wp_get_attachment_url($id) { return 'https://blog.test/wp-content/uploads/cpg-' . $id . '.jpg'; }
function get_term_by($f, $v, $tax) { return false; }
function wp_insert_term($name, $tax, $args = array()) { return array('term_id' => 7); }
function wp_trash_post($id) { if (isset($GLOBALS['TPosts'][(int)$id])) { $GLOBALS['TPosts'][(int)$id]->post_status = 'trash'; return true; } return false; }
function is_singular() { return !empty($GLOBALS['TSingular']); }
function in_the_loop() { return true; }
function get_the_ID() { return $GLOBALS['TTheID']; }
function download_url($url, $timeout = 300) { return '/tmp/fake.zip'; }
function media_handle_sideload($file, $post_id, $desc = null, $args = array()) { return 1; }
function wp_read_image_metadata($file) { return array(); }

function t_query($args) {
	$ids = array();
	foreach ($GLOBALS['TPosts'] as $id => $p) {
		if (isset($args['post_type']) && $p->post_type !== $args['post_type']) continue;
		if (isset($args['post_status'])) {
			if ('any' === $args['post_status']) { if ('trash' === $p->post_status) continue; }
			else {
				$st = is_array($args['post_status']) ? $args['post_status'] : array($args['post_status']);
				if (!in_array($p->post_status, $st, true)) continue;
			}
		}
		if (isset($args['title']) && $p->post_title !== $args['title']) continue;
		if (!empty($args['date_query'])) {
			$after = strtotime($args['date_query'][0]['after']);
			$pd = isset($p->post_date) ? $p->post_date : date('Y-m-d H:i:s');
			if ($after && strtotime($pd) <= $after) continue;
		}
		if (isset($args['meta_key'])) {
			$mv = isset($GLOBALS['TMeta'][$id][$args['meta_key']]) ? $GLOBALS['TMeta'][$id][$args['meta_key']] : null;
			if ($mv === null || (isset($args['meta_value']) && (string)$mv !== (string)$args['meta_value'])) continue;
		}
		if (!empty($args['meta_query'])) {
			$ok = true;
			foreach ($args['meta_query'] as $mq) {
				$mv = isset($GLOBALS['TMeta'][$id][$mq['key']]) ? $GLOBALS['TMeta'][$id][$mq['key']] : null;
				if ($mv === null || (string)$mv !== (string)$mq['value']) { $ok = false; break; }
			}
			if (!$ok) continue;
		}
		$ids[] = $id;
	}
	$pp = isset($args['posts_per_page']) ? (int)$args['posts_per_page'] : 10;
	if ($pp > 0) { $ids = array_slice($ids, 0, $pp); }
	return $ids;
}
function get_posts($args) { $args = array_merge(array('suppress_filters' => true), $args); return t_query($args); }
class WP_Query {
	public $posts; public $found_posts;
	public function __construct($args = array()) {
		$all = t_query(array_merge($args, array('posts_per_page' => -1)));
		$this->found_posts = count($all);
		$pp = isset($args['posts_per_page']) ? (int)$args['posts_per_page'] : 10;
		$this->posts = $pp > 0 ? array_slice($all, 0, $pp) : $all;
	}
}

/* ---------- v3.5.6: fetch pacing/retry waits off in the test harness ---------- */
define('CPG_FETCH_GAP', 0);
define('CPG_FETCH_RETRY', 0);

/* ---------- include the REAL plugin ---------- */
require '/home/user/php/collection-post-generator.php';

/* ---------- test data builders ---------- */
function t_prod($id, $title, $code, $img, $price = '25500', $tags = null, $published = '2026-08-01T00:00:00Z') {
	if (null === $tags) { $tags = 'new-arrival, ' . $code; } // products.json reality: STRING
	if (is_array($tags)) { $tags = implode(', ', $tags); }
	return array(
		'id' => $id, 'title' => $title, 'handle' => sanitize_title($title), 'tags' => $tags,
		'published_at' => $published,
		'body_html' => "<p>Embroidered front</p><script>alert('x')</script><p>Dyed trouser</p>",
		'variants' => array(array('price' => $price)),
		'images' => array(array('src' => $img)),
	);
}
function t_feed($prods) { return json_encode(array('products' => $prods)); }
function t_base_feeds() {
	$f = array();
	$dir = '';
	foreach (range('a', 'f') as $l) { $h = 'brand-' . $l; $dir .= '<a href="https://sanaullastore.com/collections/' . $h . '" class="bp-tile">' . strtoupper($l) . '</a>'; }
	$f['https://sanaullastore.com/pages/brands'] = $dir;
	$f['https://sanaullastore.com/collections/brand-a/products.json?limit=250'] = t_feed(array_merge(
		array_map(function ($i) { return t_prod(100 + $i, "Astoria by A Unstitched AA26UAA NL-$i", 'AA26UAA', "https://cdn.test/ok/a$i.jpg"); }, range(1, 5)),
		array_map(function ($i) { return t_prod(200 + $i, "Bloom by A Unstitched AA26UBB NL-$i", 'AA26UBB', "https://cdn.test/ok/b$i.jpg", '27000'); }, range(1, 6))
	));
	$f['https://sanaullastore.com/collections/brand-b/products.json?limit=250'] = t_feed(
		array_map(function ($i) { return t_prod(300 + $i, "Chic by B Unstitched BB26UCC NL-$i", 'BB26UCC', "https://cdn.test/ok/c$i.jpg"); }, range(1, 5)));
	$f['https://sanaullastore.com/collections/brand-c/products.json?limit=250'] = t_feed(
		array_map(function ($i) { return t_prod(400 + $i, "Mini by C Unstitched CC26UDD NL-$i", 'CC26UDD', "https://cdn.test/ok/d$i.jpg"); }, range(1, 3))); // 3 < min 5
	$d1 = array('id' => 501, 'title' => 'Dora by D Unstitched DD26UEE NL-1', 'handle' => 'dora-1', 'tags' => 'DD26UEE', 'published_at' => '2026-08-01T00:00:00Z', 'body_html' => '<p>x</p>', 'variants' => array(array('price' => '25500')), 'images' => array(array('src' => 'https://cdn.test/bad/d1.jpg'), array('src' => 'https://cdn.test/ok/e1.jpg')));
	$dd = array_merge(array($d1), array_map(function ($i) { return t_prod(500 + $i, "Dora by D Unstitched DD26UEE NL-$i", 'DD26UEE', "https://cdn.test/ok/e$i.jpg"); }, range(2, 5)));
	$f['https://sanaullastore.com/collections/brand-d/products.json?limit=250'] = t_feed($dd);
	$f['https://sanaullastore.com/collections/brand-e/products.json?limit=250'] = t_feed(
		array_map(function ($i) { return t_prod(600 + $i, "Eva by E Unstitched EE26UFF NL-$i", 'EE26UFF', "https://cdn.test/ok/f$i.jpg"); }, range(1, 5)));
	$f['https://sanaullastore.com/collections/brand-f/products.json?limit=250'] = t_feed(
		array_map(function ($i) { return t_prod(700 + $i, "Fana by F Unstitched FF26UGG NL-$i", 'FF26UGG', "https://cdn.test/ok/g$i.jpg"); }, range(1, 5)));
	$f['https://sanaullastore.com/collections/mushq/products.json?limit=250'] = t_feed(
		array_map(function ($i) { return t_prod(800 + $i, "Nirvana by Mushq Printed MU26UNR NL-$i", 'MU26UNR', "https://cdn.test/ok/m$i.jpg", '25500', array('MU26UNR', 'mushq')); }, range(1, 5))); // ARRAY tags
	$f['https://www.thefashionstation.in/wp-json/wc/store/v1/products?per_page=100&category=bloom-lawn-2026-by-saira-shakira'] = json_encode(
		array_map(function ($i) { return array('id' => 900 + $i, 'name' => "Bloom Lawn Saira Shakira Design $i", 'permalink' => "https://www.thefashionstation.in/product/design-$i/", 'images' => array(array('src' => "https://cdn.test/ok/w$i.jpg")), 'prices' => array('price' => '329000', 'currency_minor_unit' => 2, 'currency_prefix' => 'Rs. ')); }, range(1, 3)));
	return $f;
}
function t_fresh($settings = array()) {
	$GLOBALS['TOptions'] = array(); $GLOBALS['TPosts'] = array(); $GLOBALS['TMeta'] = array();
	$GLOBALS['TTrans'] = array(); $GLOBALS['TFeeds'] = t_base_feeds(); $GLOBALS['TNextId'] = 50;
	if ($settings) { $GLOBALS['TOptions']['cpg_settings'] = $settings; }
}
function t_log() { $l = get_option('cpg_last_run', array()); return isset($l['log']) ? $l['log'] : ''; }
function t_cpg_posts() {
	$r = array();
	foreach ($GLOBALS['TPosts'] as $id => $p) { if ($p->post_type === 'post' && !empty($GLOBALS['TMeta'][$id]['_cpg_post'])) { $r[$id] = $p; } }
	return $r;
}
function t_cursor() { $m = get_option('cpg_meta', array()); return isset($m[md5('Sanaulla (auto brands)')]) ? $m[md5('Sanaulla (auto brands)')] : null; }
$GLOBALS['PASS'] = 0; $GLOBALS['FAIL'] = 0;
function ok($cond, $label) {
	if ($cond) { $GLOBALS['PASS']++; echo "  PASS  $label\n"; }
	else { $GLOBALS['FAIL']++; echo "  FAIL  $label\n"; }
}

/* ================= SCENARIO T1-T4: caps, throttle, cursor, day rollover ================= */
echo "== S1: cap sequence (run cap 1, day cap 2) ==\n";
t_fresh();
$s1 = cpg_run(); // run 1
ok(strpos($s1, 'created 1') !== false, 'run1 creates exactly 1 post (per-run cap)');
ok(strpos($s1, 'AA26UAA') !== false && strpos($s1, 'CREATED') !== false, 'run1 creates AA26UAA line');
ok(strpos($s1, 'THROTTLED') !== false, 'run1 logs THROTTLED for the next line');
ok(t_cursor() === 0, 'F1: cursor stays at 0 (throttled brand not skipped)');
$posts = t_cpg_posts();
ok(count($posts) === 1, 'exactly 1 post exists');
$p = reset($posts);
ok(strpos($p->post_content, '<a ') === false, 'content has zero anchors');
ok(strpos($p->post_content, 'cdn.test') === false, 'content has zero CDN urls (all local)');
ok(substr_count($p->post_content, '<h3>') === 5, '5 dress blocks');
ok(strpos($p->post_content, 'PKR 25,500') !== false, 'price present');
ok(strpos($p->post_content, 'alert') === false, 'script smuggle stripped from desc');
ok(strpos($s1, '[MEDIA] images: 5 downloaded, 1 reused, 0 failed') !== false, 'media tally exact (5 dl + featured reuse)');
$c = get_option('cpg_counter');
ok($c['run'] === 1 && $c['day'] === 1, 'counter run=1 day=1');

$s2 = cpg_run(); // run 2, same day
ok(strpos($s2, 'created 1') !== false && strpos($s2, 'AA26UBB') !== false, 'run2 creates AA26UBB (run counter reset — v3.2.1 fix)');
ok(t_cursor() === 1, 'cursor moves to 1 only after brand-a fully done, throttle on brand-b');
$c = get_option('cpg_counter');
ok($c['day'] === 2, 'day counter now 2');

$s3 = cpg_run(); // run 3, same day — day cap 2 hit
ok(strpos($s3, 'created 0') !== false, 'run3 creates nothing (day cap)');
ok(strpos($s3, 'daily cap reached') !== false, 'run3 says daily cap');
ok(t_cursor() === 1, 'cursor still parked at brand-b');
// mushq/woo were still visited (their first creations throttled, no crash)
ok(strpos($s3, 'Mushq') !== false || strpos($s3, 'Bloom') !== false, 'other sources still scanned after throttle');

// day rollover: pretend yesterday
$c = get_option('cpg_counter'); $c['date'] = '2000-01-01'; update_option('cpg_counter', $c);
$s4 = cpg_run();
ok(strpos($s4, 'created 1') !== false && strpos($s4, 'BB26UCC') !== false, 'rollover: BB26UCC created');
ok(strpos($s4, 'created 1,') !== false, 'only 1 created (run cap) even after rollover');
ok(t_cursor() === 3, 'cursor = 3 (brand-b done, brand-c 3-dress line skipped, throttled on brand-d)');
ok(strpos($s4, 'brand-c: 1 line(s) found') !== false && strpos($s4, 'below min 5') !== false, 'v3.3.1: barren brand explains itself in log');

/* ================= S2: append (no cap consumed) + reuse ================= */
echo "== S2: append new dress to an existing line ==\n";
$fe =& $GLOBALS['TFeeds'];
$a_feed = json_decode($fe['https://sanaullastore.com/collections/brand-a/products.json?limit=250'], true);
$a_feed['products'][] = t_prod(106, 'Astoria by A Unstitched AA26UAA NL-6', 'AA26UAA', 'https://cdn.test/ok/a6.jpg');
$fe['https://sanaullastore.com/collections/brand-a/products.json?limit=250'] = json_encode($a_feed);
update_option('cpg_meta', array(md5('Sanaulla (auto brands)') => 0)); // rotate back to brand-a
$before = count(t_cpg_posts());
$s5 = cpg_run();
ok(strpos($s5, 'UPDATED') === false, 'v3.5: no UPDATED action exists anymore');
ok(strpos($s5, 'AA26UAA') !== false && strpos($s5, 'already announced') !== false, 'AA26UAA reported as already announced (locked)');
ok(count(t_cpg_posts()) >= $before, 'no posts removed');
$aa = null; $aacnt = 0;
foreach (t_cpg_posts() as $p) { if (strpos($p->post_title, 'AA26UAA') !== false) { $aa = $p; $aacnt++; } }
ok($aacnt === 1, 'exactly one AA26UAA post (no duplicate)');
ok($aa && substr_count($aa->post_content, '<h3>') === 5, 'v3.5: post STILL has the original 5 dress blocks (new dress NOT appended)');
ok($aa && strpos($aa->post_content, 'New designs added') === false, 'no append section added');

/* ================= S3: min_dresses never posted ================= */
echo "== S3: min dresses ==\n";
$state = get_option('cpg_state', array());
$has_c = false;
foreach ($state as $k => $v) { }
$mini = 0;
foreach (t_cpg_posts() as $p) { if (strpos($p->post_title, 'CC26UDD') !== false) { $mini++; } }
ok($mini === 0, '3-dress line CC26UDD never posted (min 5)');

/* ================= S4: trash => rejected; reset => regenerate despite caps ================= */
echo "== S4: trash/reject + reset clears counter ==\n";
$aa_id = $aa->ID;
wp_trash_post($aa_id);
update_option('cpg_meta', array(md5('Sanaulla (auto brands)') => 0));
$s6 = cpg_run();
ok(strpos($s6, 'rejected') !== false, 'trashed line marked rejected (SKIPPED)');
$msg = cpg_reset_all();
ok(get_option('cpg_counter', 'GONE') === 'GONE', 'F3: reset deletes cpg_counter');
$s7 = cpg_run();
ok(strpos($s7, 'created 1') !== false, 'after reset a post is created immediately even though caps were hit earlier today');

/* ================= S5: lock behavior ================= */
echo "== S5: run lock ==\n";
set_transient('cpg_lock', time(), 600);
$s8 = cpg_run();
ok(strpos($s8, 'Another run') !== false, 'locked run refuses politely');
ok(strpos(t_log(), 'Blocked') !== false, 'F5: lock refusal is visible in Last-run log');
delete_transient('cpg_lock');

/* ================= S6: updates flow while day cap blocks creations ================= */
echo "== S6: woo append under day cap ==\n";
t_fresh(array('max_posts_run' => 1, 'max_posts_day' => 1));
$woo_url = 'https://www.thefashionstation.in/wp-json/wc/store/v1/products?per_page=100&category=bloom-lawn-2026-by-saira-shakira';
// pre-seed: woo post already exists from "yesterday"
$pid = wp_insert_post(array('post_title' => 'Bloom Lawn 2026 by Saira Shakira', 'post_status' => 'draft', 'post_type' => 'post', 'post_content' => 'old'));
update_post_meta($pid, '_cpg_post', 1);
update_option('cpg_state', array(md5($woo_url) => array('post_id' => $pid, 'ids' => array('901', '902', '903'), 'updated' => time())));
update_option('cpg_counter', array('date' => current_time('Y-m-d'), 'day' => 1, 'run' => 0)); // day cap ALREADY spent
$woo = json_decode($GLOBALS['TFeeds'][$woo_url], true);
$woo[] = array('id' => 904, 'name' => 'Bloom Lawn Saira Shakira Design 4', 'permalink' => 'https://www.thefashionstation.in/product/design-4/', 'images' => array(array('src' => 'https://cdn.test/ok/w4.jpg')), 'prices' => array('price' => '349000', 'currency_minor_unit' => 2, 'currency_prefix' => 'Rs. '));
$GLOBALS['TFeeds'][$woo_url] = json_encode($woo);
$s9 = cpg_run();
ok(strpos($s9, 'created 0') !== false, 'day cap: no creations');
ok(strpos($s9, 'UPDATED') === false, 'v3.5: woo line NOT updated (posts immutable)');
ok(strpos($s9, 'already announced') !== false, 'woo line reported locked while capped');
$woo_post = get_post($pid);
ok(strpos($woo_post->post_content, 'Design 4') === false, 'new product 904 NOT appended (locked)');

/* ================= S7: bad image => fallback + failed count ================= */
echo "== S7: image failure fallback ==\n";
t_fresh();
$GLOBALS['cpg_media'] = array('dl'=>0,'reuse'=>0,'fail'=>0,'err'=>''); // direct call: reset run-scoped tally
$body = json_decode($GLOBALS['TFeeds']['https://sanaullastore.com/collections/brand-d/products.json?limit=250'], true);
$dresses = cpg_parse_shopify($body['products'], array('store' => 'https://sanaullastore.com'), cpg_settings());
$res = cpg_store_collection_post('testkey-dd', array('name' => 'Dora (DD26UEE)', 'tags' => array('t')), $dresses, cpg_settings());
ok($res['action'] === 'CREATED', 'DD26UEE created');
$p = null;
foreach (t_cpg_posts() as $pp) { if (strpos($pp->post_title, 'Dora') !== false) { $p = $pp; } }
ok($p && strpos($p->post_content, 'https://cdn.test/bad/d1.jpg') !== false, 'failed image falls back to CDN url');
ok($p && substr_count($p->post_content, 'blog.test/wp-content/uploads') === 4, 'other 4 images are local (dress 1 lead img is the dead one)');
$m = $GLOBALS['cpg_media'];

ok(!empty($GLOBALS['TMeta'][$p->ID]['_thumbnail_id']), 'featured thumbnail set from the WORKING image');

ok($p && strpos($p->post_content, 'loading="lazy"') !== false, 'local imgs carry loading=lazy');

/* ================= S8: max_dresses slice ================= */
echo "== S8: max dresses slice ==\n";
t_fresh(array('max_dresses' => 4));
$body = json_decode($GLOBALS['TFeeds']['https://sanaullastore.com/collections/brand-a/products.json?limit=250'], true);
$dresses = cpg_parse_shopify($body['products'], array('store' => 'https://sanaullastore.com'), cpg_settings());
$grp = cpg_group_lines($dresses);
ok(isset($grp['AA26UAA']) && isset($grp['AA26UBB']), 'F4: tags STRING still grouped by code');
$res = cpg_store_collection_post('k-slice', array('name' => 'Slice'), $grp['AA26UBB']['dresses'], cpg_settings());
ok($res['action'] === 'CREATED', 'slice post created');
$p = null;
foreach (t_cpg_posts() as $pp) { if ($pp->post_title === 'Slice') { $p = $pp; } }
ok($p && substr_count($p->post_content, '<h3>') === 4, 'max_dresses=4 => 4 blocks (from 6)');

/* ================= S9: paused + manual + no-lock-leak ================= */
echo "== S9: paused / manual / lock released ==\n";
t_fresh(array('paused' => 1));
$s10 = cpg_run();
ok($s10 === 'Paused — nothing done.', 'paused run does nothing');
ok(get_transient('cpg_lock') === false, 'no lock leak after paused return');
t_fresh();
$s11 = cpg_run(true); // manual
ok(strpos($s11, 'Done in') !== false, 'manual run executes');
ok(get_transient('cpg_lock') === false, 'lock released after normal run');

/* ================= S10: srcset stripper scoped ================= */
echo "== S10: srcset filter ==\n";
t_fresh();
$pid = wp_insert_post(array('post_type' => 'post', 'post_status' => 'draft', 'post_content' => '<img src="x.jpg" srcset="a 1x" sizes="100vw" />'));
update_post_meta($pid, '_cpg_post', 1);
$GLOBALS['TTheID'] = $pid; $GLOBALS['TSingular'] = true;
$out = cpg_maybe_strip_srcset(get_post_field('post_content', $pid));
ok(strpos($out, 'srcset') === false && strpos($out, 'sizes') === false, 'srcset/sizes stripped on CPG post');
$pid2 = wp_insert_post(array('post_type' => 'post', 'post_status' => 'draft', 'post_content' => '<img src="y.jpg" srcset="b 1x" />'));
$GLOBALS['TTheID'] = $pid2;
$out2 = cpg_maybe_strip_srcset(get_post_field('post_content', $pid2));
ok(strpos($out2, 'srcset') !== false, 'normal posts untouched');

/* ================= S11: trash-ours >500 ================= */
echo "== S11: trash batches ==\n";
t_fresh();
for ($i = 0; $i < 1200; $i++) {
	$id = wp_insert_post(array('post_type' => 'post', 'post_status' => 'draft', 'post_content' => 'x'));
	update_post_meta($id, '_cpg_post', 1);
}
$msg = cpg_trash_ours();
ok(strpos($msg, 'Trashed 1200') !== false, 'F6: all 1200 generated posts trashed in one click');
$left = t_query(array('post_type' => 'post', 'post_status' => array('draft'), 'meta_key' => '_cpg_post', 'meta_value' => '1', 'posts_per_page' => -1));
ok(count($left) === 0, 'none left behind');

/* ================= S12: dead feeds / empty directory ================= */
echo "== S12: dead sources ==\n";
t_fresh();
$GLOBALS['TFeeds'] = array(); // everything 404
$s12 = cpg_run();
ok(strpos($s12, 'created 0') !== false, 'all-dead feeds: run completes with 0 created');
ok(strpos($s12, 'no brands found') !== false, 'directory dead reported');
ok(get_transient('cpg_lock') === false, 'lock released even after dead sources');
$GLOBALS['TFeeds']['https://sanaullastore.com/pages/brands'] = '<a href="https://sanaullastore.com/collections/brand-a" class="bp-tile">A</a>';
update_option('cpg_settings', array('brands_per_run' => 1)); // one slot: brand-a visited exactly once
$GLOBALS['TFetchCount'] = array();
$s12b = cpg_run();
ok(strpos($s12b, 'brand-a: feed unreachable — HTTP 404') !== false, 'v3.5.6: unreachable brand feed logs the REASON (HTTP 404)');
ok((isset($GLOBALS['TFetchCount']['https://sanaullastore.com/collections/brand-a/products.json?limit=250']) ? $GLOBALS['TFetchCount']['https://sanaullastore.com/collections/brand-a/products.json?limit=250'] : 0) === 2, 'v3.5.6: failed brand fetch retried exactly once');
$GLOBALS['TFeeds']['https://sanaullastore.com/collections/brand-a/products.json?limit=250'] = '{"products":[]}';
$s12c = cpg_run();
ok(strpos($s12c, 'brand-a: collection empty (feed reachable)') !== false, 'v3.5.6: reachable-but-empty collection distinguished from unreachable');
t_fresh();
$GLOBALS['TFeeds'] = t_base_feeds();
update_option('cpg_settings', array('max_posts_run' => 99, 'max_posts_day' => 99, 'brands_per_run' => 6)); // no throttle, exactly one visit per brand
$b12 = 'https://sanaullastore.com/collections/brand-b/products.json?limit=250';
$GLOBALS['TFailOnce'][$b12] = 1; // first attempt blocked (403), retry must rescue it
$s12d = cpg_run();
ok(strpos($s12d, 'brand-b: feed unreachable') === false && (isset($GLOBALS['TFetchCount'][$b12]) ? $GLOBALS['TFetchCount'][$b12] : 0) === 2, 'v3.5.6: one-shot 403 rescued by the retry — brand-b processed normally');
unset($GLOBALS['TFailOnce'][$b12]);

/* ================= S13: cron self-heal + no drift (v3.3.2) ================= */
echo "== S13: cron scheduling ==\n";
t_fresh();
$GLOBALS['TSched'] = array(); // file-updated install: activation hook never fired
ok(wp_next_scheduled('cpg_cron_event') === false, 'F7: file-update install state = nothing scheduled (the v3.3.1 bug)');
cpg_ensure_cron();
$t = wp_next_scheduled('cpg_cron_event');
ok($t !== false && $t > time() && $t <= time() + 150, 'F7: ensure_cron schedules the event (now +2min window)');
cpg_ensure_cron();
cpg_ensure_cron();
ok(wp_next_scheduled('cpg_cron_event') === $t, 'F7: repeated ensure_cron on every init NEVER drifts the schedule');
$GLOBALS['TSched']['cpg_cron_event'] = time() - 3600; // overdue event
cpg_ensure_cron();
ok(wp_next_scheduled('cpg_cron_event') === time() - 3600, 'F7: overdue event untouched (wp-cron owns re-anchor on fire)');
cpg_deactivate();
ok(wp_next_scheduled('cpg_cron_event') === false, 'F7: deactivate still clears the event completely');




/* ================= S14: brand footer (v3.4) ================= */
echo "\n== S14: brand link footer ==\n";
t_fresh();
$map = cpg_brand_map(cpg_settings());
ok(count($map) === 186, 'F10: built-in map loads with 186 brands (' . count($map) . ')');
ok(isset($map['mushq']) && $map['mushq'][1] === 'https://mushq.com' && $map['mushq'][2] === 'https://www.instagram.com/mushqpk/', 'F10: mushq entry = mushq.com + mushqpk');
ok(!isset($map['sanaulla']), 'F10: no sanaulla key in map');

// exact user-requested rendering, end-to-end through the store (shopify URL slug resolution)
$GLOBALS['TFeeds'] = t_base_feeds();
$GLOBALS['TFeeds']['https://sanaullastore.com/collections/mushq/products.json?limit=250'] = $GLOBALS['TFeeds']['https://sanaullastore.com/collections/brand-a/products.json?limit=250'];
$mushqSrc = array('type'=>'shopify_collection','name'=>'Mushq @ Sanaulla Store','store'=>'https://sanaullastore.com','url'=>'https://sanaullastore.com/collections/mushq/products.json?limit=250','collection_link'=>'https://sanaullastore.com/collections/mushq','tags'=>array('Mushq'));
$dresses = cpg_parse_shopify(json_decode($GLOBALS['TFeeds']['https://sanaullastore.com/collections/mushq/products.json?limit=250'], true)['products'], $mushqSrc, cpg_settings());
if (count($dresses) < 5) { $dresses = array_merge($dresses, $dresses, $dresses, $dresses, $dresses); $dresses = array_slice($dresses, 0, 8); }
$res = cpg_store_collection_post('s14-mushq', $mushqSrc, $dresses, cpg_settings());
preg_match('~#(\d+)~', $res['detail'], $mId); $c = get_post_field('post_content', (int)($mId[1] ?? 0));
$want = 'Get your favorite dress from <a href="https://mushq.com" target="_blank" rel="nofollow noopener">Mushq Website</a> and more details on their <a href="https://www.instagram.com/mushqpk/" target="_blank" rel="nofollow noopener">Instagram page</a>.';
ok(strpos($c, $want) !== false, 'F10: exact Mushq footer rendered through store flow');
ok(substr_count($c, 'Get your favorite dress') === 1, 'F10: footer appears exactly once');

// unknown brand -> no footer
t_fresh(); $GLOBALS['TFeeds'] = t_base_feeds();
$unknownSrc = array('type'=>'shopify_collection','name'=>'Unknown Label','store'=>'https://sanaullastore.com','url'=>'https://sanaullastore.com/collections/zzz-unknown-label/products.json?limit=250','tags'=>array());
$GLOBALS['TFeeds']['https://sanaullastore.com/collections/zzz-unknown-label/products.json?limit=250'] = $GLOBALS['TFeeds']['https://sanaullastore.com/collections/brand-b/products.json?limit=250'];
$d2 = cpg_parse_shopify(json_decode($GLOBALS['TFeeds']['https://sanaullastore.com/collections/zzz-unknown-label/products.json?limit=250'], true)['products'], $unknownSrc, cpg_settings());
$res2 = cpg_store_collection_post('s14-unknown', $unknownSrc, $d2, cpg_settings());
preg_match('~#(\d+)~', $res2['detail'], $mId2); $c2 = get_post_field('post_content', (int)($mId2[1] ?? 0));
ok(strpos($c2, 'Get your favorite dress') === false, 'F10: unmapped brand gets NO footer');

// variants via custom map
t_fresh();
$sCustom = cpg_settings();
$sCustom['brand_links'] = "brandx | Brand X | https://brandx.example | \nbrandy | Brand Y | | https://www.instagram.com/brandy/\nmushq | Mushq | https://mushq.com | https://www.instagram.com/mushqpk/\n# comment line\nbadline-no-pipes\n";
$mCustom = cpg_brand_map($sCustom);
ok(count($mCustom) === 188, 'F10: custom map MERGED over built-in (186 + brandx + brandy)');
$fX = cpg_build_brand_footer(array('brand_handle'=>'brandx'), $sCustom);
$fY = cpg_build_brand_footer(array('brand_handle'=>'brandy'), $sCustom);
ok($fX === '<p>Get your favorite dress from <a href="https://brandx.example" target="_blank" rel="nofollow noopener">Brand X Website</a>.</p>' . "\n", 'F10: site-only variant');
ok($fY === '<p>Find more of Brand Y on their <a href="https://www.instagram.com/brandy/" target="_blank" rel="nofollow noopener">Instagram page</a>.</p>' . "\n", 'F10: instagram-only variant');

// disabled toggle
$sOff = cpg_settings(); $sOff['brand_footer'] = 0;
ok(cpg_build_brand_footer(array('brand_handle'=>'mushq'), $sOff) === '', 'F10: toggle off = no footer');

// sanaulla link injected into custom map -> filtered
$sEvil = cpg_settings();
$sEvil['brand_links'] = "mushq | Mushq | https://sanaullastore.com/collections/mushq | https://www.instagram.com/mushqpk/\n";
$fEvil = cpg_build_brand_footer(array('brand_handle'=>'mushq'), $sEvil);
ok(strpos($fEvil, 'sanaullastore') === false && strpos($fEvil, 'https://mushq.com') !== false, 'F10: sanaulla line rejected — built-in entry survives');
$sBlock = cpg_settings(); $sBlock['brand_links'] = "mushq | Mushq | - | -\n";
ok(cpg_build_brand_footer(array('brand_handle'=>'mushq'), $sBlock) === '', 'F10: \"- | -\" line disables a built-in brand');
$sOver = cpg_settings(); $sOver['brand_links'] = "mushq | Mushq | https://only-site.example | \n";
$fOver = cpg_build_brand_footer(array('brand_handle'=>'mushq'), $sOver);
ok(strpos($fOver, 'https://only-site.example') !== false && strpos($fOver, 'instagram.com') === false, 'F10: custom override wins over built-in (site swapped, IG gone)');

// update path must not duplicate the footer
t_fresh(); $GLOBALS['TFeeds'] = t_base_feeds();
$GLOBALS['TFeeds']['https://sanaullastore.com/collections/mushq/products.json?limit=250'] = $GLOBALS['TFeeds']['https://sanaullastore.com/collections/brand-a/products.json?limit=250'];
$d3 = cpg_parse_shopify(json_decode($GLOBALS['TFeeds']['https://sanaullastore.com/collections/mushq/products.json?limit=250'], true)['products'], $mushqSrc, cpg_settings());
$d3 = array_slice(array_merge($d3,$d3,$d3,$d3,$d3), 0, 8);
cpg_store_collection_post('s14-dup', $mushqSrc, $d3, cpg_settings());
// same line, one NEW dress id
$d4 = $d3; $first = $d4[0]; $first['id'] = 'new-id-999'; $first['title'] = 'New Design'; $d4[] = $first;
$resUpd = cpg_store_collection_post('s14-dup', $mushqSrc, $d4, cpg_settings());
preg_match('~#(\d+)~', $resUpd['detail'], $mId3); $cUpd = get_post_field('post_content', (int)($mId3[1] ?? 0));
ok($resUpd['action'] === 'OK' && substr_count($cUpd, 'Get your favorite dress') === 1 && strpos($cUpd, 'New designs added') === false, 'F10: locked post keeps exactly one footer, no append');

// ig-only built-in entry renders
$fSS = cpg_build_brand_footer(array('brand_handle'=>'saira-shakira'), cpg_settings());
ok(strpos($fSS, 'https://www.instagram.com/sairashakira/') !== false && strpos($fSS, 'Find more of Saira Shakira') !== false, 'F10: built-in IG-only brand (saira-shakira) renders variant');


/* ================= S15: adopt-or-create + rich log (v3.4.5) ================= */
echo "\n== S15: adopt-or-create after state reset ==\n";
t_fresh(); $GLOBALS['TFeeds'] = t_base_feeds();
$GLOBALS['TFeeds']['https://sanaullastore.com/collections/mushq/products.json?limit=250'] = $GLOBALS['TFeeds']['https://sanaullastore.com/collections/brand-a/products.json?limit=250'];
$mushqSrc15 = array('type'=>'shopify_collection','name'=>'Mushq @ Sanaulla Store','store'=>'https://sanaullastore.com','url'=>'https://sanaullastore.com/collections/mushq/products.json?limit=250','collection_link'=>'https://sanaullastore.com/collections/mushq','tags'=>array('Mushq'));
$dd15 = cpg_parse_shopify(json_decode($GLOBALS['TFeeds']['https://sanaullastore.com/collections/mushq/products.json?limit=250'], true)['products'], $mushqSrc15, cpg_settings());
$sCap = cpg_settings(); $sCap['max_posts_run'] = 1; $sCap['max_posts_day'] = 1;
$r1 = cpg_store_collection_post('s15-mushq', $mushqSrc15, $dd15, $sCap);
preg_match('~#(\d+)~', $r1['detail'], $m15a); $origId15 = (int)$m15a[1];
ok($r1['action'] === 'CREATED', 'first run CREATED (post #' . $origId15 . ')');
$postsBefore15 = count($GLOBALS['TPosts']);
// simulate plugin state reset (option lost) with posts still on the site
update_option('cpg_state', array(), false);
$r2 = cpg_store_collection_post('s15-mushq', $mushqSrc15, $dd15, $sCap);
preg_match('~#(\d+)~', $r2['detail'], $m15b);
ok($r2['action'] === 'OK' && (int)$m15b[1] === $origId15, 'state reset + caps FULL -> adopted existing post #' . $m15b[1] . ', not throttled, no duplicate');
ok(count($GLOBALS['TPosts']) === $postsBefore15, 'post count unchanged after adoption');
ok(strpos($r2['detail'], 'adopted existing post') !== false, 'log states the adoption explicitly');
// genuinely new dress while caps still full -> post is LOCKED (v3.5: no appends ever)
$dn15 = $dd15; $one15 = $dd15[0]; $one15['id'] = 'new-9001'; $one15['title'] = 'Brand New Mushq Design XYZ'; $dn15[] = $one15;
$r3 = cpg_store_collection_post('s15-mushq', $mushqSrc15, $dn15, $sCap);
preg_match('~#(\d+)~', $r3['detail'], $m15c);
ok($r3['action'] === 'OK' && (int)$m15c[1] === $origId15, 'new dress at full cap -> post LOCKED (OK), not updated');
$c15 = get_post_field('post_content', $origId15);
ok(strpos($c15, 'Brand New Mushq Design XYZ') === false && strpos($c15, 'New designs added') === false, 'nothing appended, content untouched');
$cnt15 = 0; foreach ($GLOBALS['TPosts'] as $tp15) { if ($tp15->post_type === 'post' && $tp15->post_title === get_post_field('post_title', $origId15)) $cnt15++; }
ok($cnt15 === 1, 'exactly ONE post with this title exists');


/* ================= S16: annual relaunch = new post; season keys (v3.5) ================= */
echo "\n== S16: year-aware lines ==\n";
t_fresh(); $GLOBALS['TFeeds'] = t_base_feeds();
$s16s = cpg_settings(); $s16s['max_posts_run'] = 0; $s16s['max_posts_day'] = 0; $s16s['min_dresses'] = 2;
$s16src = array('type'=>'shopify_collection','name'=>'Test Brand','store'=>'https://sanaullastore.com','url'=>'https://sanaullastore.com/collections/s16brand/products.json?limit=250','collection_link'=>'','group_by'=>'line','tags'=>array());
$s16feed = t_feed(array(
 t_prod(601, 'Aura S16 Unstitched TA26UAM NL-1', 'TA26UAM', 'https://cdn.test/ok/s1.jpg'),
 t_prod(602, 'Aura S16 Unstitched TA26UAM NL-2', 'TA26UAM', 'https://cdn.test/ok/s2.jpg'),
));
$GLOBALS['TFeeds']['https://sanaullastore.com/collections/s16brand/products.json?limit=250'] = $s16feed;
$rep16 = array(); $cnt16 = array();
$r16a = cpg_process_lines($s16src, cpg_parse_shopify(json_decode($s16feed, true)['products'], $s16src, $s16s), $s16src['url'], $s16s, $rep16, $cnt16);
$aura26 = 0; foreach (t_cpg_posts() as $p16) { if (strpos($p16->post_title, 'TA26UAM') !== false) $aura26++; }
ok($aura26 === 1, 'year-coded line TA26UAM: one post created');
// next year: TA27UAM = different code => new line => NEW post
$s16feed27 = t_feed(array(
 t_prod(701, 'Aura S17 Unstitched TA27UAM NL-1', 'TA27UAM', 'https://cdn.test/ok/s3.jpg', '25500', null, '2027-03-01T00:00:00Z'),
 t_prod(702, 'Aura S17 Unstitched TA27UAM NL-2', 'TA27UAM', 'https://cdn.test/ok/s4.jpg', '25500', null, '2027-03-01T00:00:00Z'),
));
$GLOBALS['TFeeds']['https://sanaullastore.com/collections/s16brand/products.json?limit=250'] = $s16feed27;
$rep16b = array(); $cnt16b = array();
$r16b = cpg_process_lines($s16src, cpg_parse_shopify(json_decode($s16feed27, true)['products'], $s16src, $s16s), $s16src['url'], $s16s, $rep16b, $cnt16b);
$aura27 = 0; foreach (t_cpg_posts() as $p16) { if (strpos($p16->post_title, 'TA27UAM') !== false) $aura27++; }
ok($aura27 === 1, 'annual relaunch TA27UAM: a NEW post is created');
// year-less code: season comes from dress dates; title gains the year
$s16feedL = t_feed(array(
 t_prod(801, 'Mono Lakh LX-0001 A', 'LX-0001', 'https://cdn.test/ok/l1.jpg', '25500', null, '2026-04-01T00:00:00Z'),
 t_prod(802, 'Mono Lakh LX-0001 B', 'LX-0001', 'https://cdn.test/ok/l2.jpg', '25500', null, '2026-04-01T00:00:00Z'),
));
$GLOBALS['TFeeds']['https://sanaullastore.com/collections/s16brand/products.json?limit=250'] = $s16feedL;
$rep16c = array(); $cnt16c = array();
cpg_process_lines($s16src, cpg_parse_shopify(json_decode($s16feedL, true)['products'], $s16src, $s16s), $s16src['url'], $s16s, $rep16c, $cnt16c);
$lx26 = null; foreach (t_cpg_posts() as $p16) { if (strpos($p16->post_title, 'LX-0001') !== false) $lx26 = $p16; }
ok($lx26 && strpos($lx26->post_title, '2026') !== false, 'year-less code: title carries the season (… 2026)');
// same line again after a state wipe -> ADOPTED (no duplicate), legacy-style state key migrates
$st16 = get_option('cpg_state', array());
foreach ($st16 as $k16 => $v16) { if (!empty($v16['post_id']) && (int)$v16['post_id'] === (int)$lx26->ID) { unset($st16[$k16]); $st16[md5($s16src['url'] . '|LX-0001')] = $v16; } } // pretend it was stored pre-3.5
update_option('cpg_state', $st16, false);
$rep16d = array(); $cnt16d = array();
cpg_process_lines($s16src, cpg_parse_shopify(json_decode($s16feedL, true)['products'], $s16src, $s16s), $s16src['url'], $s16s, $rep16d, $cnt16d);
$lxcount = 0; foreach (t_cpg_posts() as $p16) { if (strpos($p16->post_title, 'LX-0001') !== false) $lxcount++; }
ok($lxcount === 1, 'legacy pre-3.5 state key migrated: still exactly one LX post (re-bound, not duplicated)');
// next year, same year-less code -> season 2027 -> NEW post
$s16feedL27 = t_feed(array(
 t_prod(901, 'Mono Lakh LX-0001 A2', 'LX-0001', 'https://cdn.test/ok/l3.jpg', '25500', null, '2027-04-01T00:00:00Z'),
 t_prod(902, 'Mono Lakh LX-0001 B2', 'LX-0001', 'https://cdn.test/ok/l4.jpg', '25500', null, '2027-04-01T00:00:00Z'),
));
$GLOBALS['TFeeds']['https://sanaullastore.com/collections/s16brand/products.json?limit=250'] = $s16feedL27;
$rep16e = array(); $cnt16e = array();
cpg_process_lines($s16src, cpg_parse_shopify(json_decode($s16feedL27, true)['products'], $s16src, $s16s), $s16src['url'], $s16s, $rep16e, $cnt16e);
$lx27 = 0; foreach (t_cpg_posts() as $p16) { if (strpos($p16->post_title, 'LX-0001') !== false && strpos($p16->post_title, '2027') !== false) $lx27++; }
ok($lx27 === 1, 'year-less annual relaunch: NEW post "... LX-0001) 2027" created');


/* ===== S17: split codes / untagged dresses = ONE collection post (v3.5.1) ===== */
echo "\n== S17: same name+season merge ==\n";
t_fresh(); $GLOBALS['TFeeds'] = t_base_feeds();
$s17s = cpg_settings(); $s17s['max_posts_run'] = 0; $s17s['max_posts_day'] = 0; $s17s['min_dresses'] = 2;
$s17src = array('type'=>'shopify_collection','name'=>'TSG','store'=>'https://sanaullastore.com','url'=>'https://sanaullastore.com/collections/s17brand/products.json?limit=250','collection_link'=>'','group_by'=>'line','tags'=>array());
// real pattern: identical collection name split over two codes + one untagged dress
$s17feed = t_feed(array(
 t_prod(711, 'Secret Garden Test Unstitched SG26UGG A', 'SG26UGG', 'https://cdn.test/ok/g1.jpg'),
 t_prod(712, 'Secret Garden Test Unstitched SG26UGG B', 'SG26UGG', 'https://cdn.test/ok/g2.jpg'),
 t_prod(721, 'Secret Garden Test Unstitched SG26ULGG C', 'SG26ULGG', 'https://cdn.test/ok/g3.jpg'),
 t_prod(731, 'Secret Garden Test Unstitched', '', 'https://cdn.test/ok/g4.jpg'),
));
$GLOBALS['TFeeds']['https://sanaullastore.com/collections/s17brand/products.json?limit=250'] = $s17feed;
$rep17 = array(); $cnt17 = array();
cpg_process_lines($s17src, cpg_parse_shopify(json_decode($s17feed, true)['products'], $s17src, $s17s), $s17src['url'], $s17s, $rep17, $cnt17);
$sgPosts = array();
foreach (t_cpg_posts() as $p17) { if (strpos($p17->post_title, 'Secret Garden Test') !== false) $sgPosts[] = $p17; }
ok(count($sgPosts) === 1, 'split codes + untagged => exactly ONE collection post (got ' . count($sgPosts) . ')');
$blocks = $sgPosts ? substr_count($sgPosts[0]->post_content, '<h3>') : 0;
ok($blocks === 4, 'merged post shows all 4 dresses (got ' . $blocks . ')');
ok($sgPosts && strpos($sgPosts[0]->post_title, 'SG26UGG') !== false, 'primary (largest) code in title');
// same name next year => NEW post
$s17feed27 = t_feed(array(
 t_prod(811, 'Secret Garden Test Unstitched SG27UGG A', 'SG27UGG', 'https://cdn.test/ok/g5.jpg', '25500', null, '2027-05-01T00:00:00Z'),
 t_prod(812, 'Secret Garden Test Unstitched SG27UGG B', 'SG27UGG', 'https://cdn.test/ok/g6.jpg', '25500', null, '2027-05-01T00:00:00Z'),
));
$GLOBALS['TFeeds']['https://sanaullastore.com/collections/s17brand/products.json?limit=250'] = $s17feed27;
$rep17b = array(); $cnt17b = array();
cpg_process_lines($s17src, cpg_parse_shopify(json_decode($s17feed27, true)['products'], $s17src, $s17s), $s17src['url'], $s17s, $rep17b, $cnt17b);
$sgTotal = 0;
foreach (t_cpg_posts() as $p17) { if (strpos($p17->post_title, 'Secret Garden Test') !== false) $sgTotal++; }
ok($sgTotal === 2, 'next year same name => NEW post (total ' . $sgTotal . ')');


/* ===== S18: [TODAY] section lists posts created today across runs (v3.5.2) ===== */
echo "\n== S18: today section ==\n";
t_fresh(); $GLOBALS['TFeeds'] = t_base_feeds();
$s18s = cpg_settings(); $s18s['max_posts_run'] = 2; $s18s['max_posts_day'] = 5;
$log18 = cpg_run();
$c18 = 0; foreach (t_cpg_posts() as $p18) { if (strpos($p18->post_title, 'AA26UAA') !== false) { $c18++; $idAA = $p18->ID; } }
ok($c18 === 1 && isset($idAA), 'setup: AA26UAA post created');
ok(strpos($log18, '[TODAY]') !== false, 'log contains [TODAY] section');
ok(strpos($log18, '#' . $idAA . ' ') !== false && strpos($log18, 'AA26UAA') !== false, 'TODAY lists the created post with id+title');
// decoys: non-CPG post today, CPG post yesterday, trashed CPG post today -> all excluded
$np18 = wp_insert_post(array('post_title' => 'DECOY-NONCPG-TODAY'));
$yp18 = wp_insert_post(array('post_title' => 'DECOY-CPG-YESTERDAY'));
update_post_meta($yp18, '_cpg_post', 1);
$GLOBALS['TPosts'][$yp18]->post_date = date('Y-m-d H:i:s', time() - 86400 * 2);
$tp18 = wp_insert_post(array('post_title' => 'DECOY-CPG-TRASHED'));
update_post_meta($tp18, '_cpg_post', 1);
$GLOBALS['TPosts'][$tp18]->post_status = 'trash';
$log18b = cpg_run();
$today18 = substr($log18b, strpos($log18b, '[TODAY]'));
// v3.5.3: persistence across runs comes from the COUNTER memory (not a DB query)
$log18c = cpg_run();
ok(strpos($log18c, '[TODAY]') !== false && strpos($log18c, 'AA26UAA') !== false, 'TODAY lists posts from EARLIER runs via counter memory');
$GLOBALS['TPosts'][$idAA]->post_status = 'trash';
$log18d = cpg_run();
$today18d = substr($log18d, strpos($log18d, '[TODAY]'));
// v3.5.4: trashed posts stay listed from memory, tagged (now in Trash)
ok(strpos($today18d, 'AA26UAA') !== false && strpos($today18d, ', now in Trash)') !== false && strpos($today18d, 'later deleted/trashed') !== false, 'trashed post still listed from memory + tagged (now in Trash)');
unset($GLOBALS['TPosts'][$idAA]); // hard delete: post gone entirely, not just trashed
$log18e = cpg_run();
$today18e = substr($log18e, strpos($log18e, '[TODAY]'));
ok(strpos($today18e, 'AA26UAA') !== false && strpos($today18e, ', later deleted)') !== false, 'hard-deleted post still listed with memorized title (later deleted)');
ok(strpos($today18, 'DECOY-NONCPG-TODAY') === false, 'non-CPG post excluded');
ok(strpos($today18, 'DECOY-CPG-YESTERDAY') === false, 'yesterday CPG post excluded');
ok(strpos($today18, 'DECOY-CPG-TRASHED') === false, 'trashed CPG post excluded');
ok(strpos($log18b, 'daily cap') !== false, 'cap usage shown');

/* ================= S19: v3.5.6 one-time age_days 5 -> 14 migration ================= */
echo "\n== S19: age migration ==\n";
t_fresh();
update_option('cpg_settings', array('age_days' => 5));
ok((int)cpg_settings()['age_days'] === 14, 'v3.5.6: age_days 5 migrated to 14');
ok((int)get_option('cpg_settings')['age_days'] === 14, 'v3.5.6: migrated value persisted to storage');
update_option('cpg_settings', array('age_days' => 6)); // marker set — no second migration
ok((int)cpg_settings()['age_days'] === 6, 'v3.5.6: migration runs exactly once — later custom value untouched');
t_fresh();
update_option('cpg_settings', array('age_days' => 45));
ok((int)cpg_settings()['age_days'] === 45, 'v3.5.6: non-5 values never migrated');

/* ================= S20: v3.5.7 proxy fallback (ZenRows) ================= */
echo "\n== S20: proxy fallback ==\n";
$missing20 = 'https://sanaullastore.com/collections/brand-b/products.json?limit=250';
// 1) no key configured: failing feed = 2 direct attempts, ZERO proxy calls
t_fresh();
$GLOBALS['TFeeds'] = t_base_feeds();
$GLOBALS['TFetchCount'] = array(); // S18's runs polluted the counter — start clean
unset($GLOBALS['TFeeds'][$missing20]);
update_option('cpg_settings', array('max_posts_run' => 99, 'max_posts_day' => 99, 'brands_per_run' => 6));
$s20a = cpg_run();
ok(empty($GLOBALS['TProxyCalls']), 'proxy OFF by default — no key, no proxy calls');
ok((isset($GLOBALS['TFetchCount'][$missing20]) ? $GLOBALS['TFetchCount'][$missing20] : 0) === 2, 'without key: exactly direct attempt + retry');
// 2) key set: both direct attempts fail, proxy returns the feed -> rescued + logged
t_fresh();
$GLOBALS['TFeeds'] = t_base_feeds();
$GLOBALS['TFetchCount'] = array();
unset($GLOBALS['TFeeds'][$missing20]);
$GLOBALS['TForceCode'][$missing20] = 403; // blocked (not 404-dead) so the proxy may fire
$GLOBALS['TProxyBody'] = t_feed(array_map(function ($i) { return t_prod(300 + $i, "Chic by B Unstitched BB26UCC NL-$i", 'BB26UCC', "https://cdn.test/ok/c$i.jpg"); }, range(1, 5)));
update_option('cpg_settings', array('max_posts_run' => 99, 'max_posts_day' => 99, 'brands_per_run' => 6, 'proxy_provider' => 'zenrows', 'proxy_key' => 'TESTKEY'));
$GLOBALS['TProxyCalls'] = array();
$s20b = cpg_run();
ok(count($GLOBALS['TProxyCalls']) === 1, 'exactly ONE proxy call for the failing feed (credit discipline)');
ok(strpos($GLOBALS['TProxyCalls'][0], 'apikey=TESTKEY') !== false && strpos($GLOBALS['TProxyCalls'][0], rawurlencode($missing20)) !== false, 'proxy URL carries key + target');
ok(strpos($GLOBALS['TProxyCalls'][0], 'premium_proxy') === false, 'standard mode by default (1 credit, not 10)');
ok(strpos($s20b, '[NET] proxy rescues: zenrows 1') !== false, 'run log reports the rescue');
ok((isset($GLOBALS['TFetchCount'][$missing20]) ? $GLOBALS['TFetchCount'][$missing20] : 0) === 2, 'direct tried twice BEFORE the proxy fired');
// 3) premium checkbox -> premium_proxy=true
update_option('cpg_settings', array('max_posts_run' => 99, 'max_posts_day' => 99, 'brands_per_run' => 6, 'proxy_provider' => 'zenrows', 'proxy_key' => 'TESTKEY', 'proxy_premium' => 1));
$GLOBALS['TProxyCalls'] = array();
cpg_run();
ok(isset($GLOBALS['TProxyCalls'][0]) && strpos($GLOBALS['TProxyCalls'][0], 'premium_proxy=true') !== false, 'premium checkbox adds premium_proxy=true');
// 4) proxy fails too -> honest reason in log, no crash, no garbage post
$GLOBALS['TProxyFail'] = array('api.zenrows.com');
$GLOBALS['TProxyCalls'] = array();
$s20d = cpg_run();
ok(strpos($s20d, 'proxy(zenrows) — HTTP 500') !== false, 'proxy failure surfaces the reason');
unset($GLOBALS['TProxyFail'], $GLOBALS['TProxyBody'], $GLOBALS['TForceCode']);

/* ================= S21: v3.5.8 provider chain + credit guards ================= */
echo "\n== S21: proxy providers ==\n";
$u21 = 'https://sanaullastore.com/collections/mushq/products.json?limit=250';
ok(cpg_proxy_url('scrapingant', 'SK1', $u21, false, '') === 'https://api.scrapingant.com/v2/general?x-api-key=SK1&url=' . rawurlencode($u21), 'ScrapingAnt URL built (x-api-key form, docs-verified)');
ok(cpg_proxy_url('zenrows', 'ZK1', $u21, false, '') === 'https://api.zenrows.com/v1/?apikey=ZK1&url=' . rawurlencode($u21), 'ZenRows URL built (standard, no premium)');
ok(strpos(cpg_proxy_url('zenrows', 'ZK1', $u21, true, ''), '&premium_proxy=true') !== false, 'ZenRows premium adds premium_proxy=true');
ok(cpg_proxy_url('scraperapi', 'AK1', $u21, false, '') === 'https://api.scraperapi.com/?api_key=AK1&url=' . rawurlencode($u21), 'ScraperAPI URL built');
ok(cpg_proxy_url('scrapingbee', 'BK1', $u21, false, '') === 'https://app.scrapingbee.com/api/v1/?api_key=BK1&url=' . rawurlencode($u21), 'ScrapingBee URL built');
ok(cpg_proxy_url('crawlbase', 'CK1', $u21, false, '') === 'https://api.crawlbase.com/?token=CK1&url=' . rawurlencode($u21), 'Crawlbase URL built');
ok(cpg_proxy_url('custom', '', $u21, false, 'https://relay.test/w/?u={URL}') === 'https://relay.test/w/?u=' . rawurlencode($u21), 'custom template substitutes {URL}');
ok(cpg_proxy_url('custom', '', $u21, false, 'https://relay.test/w/') === null, 'custom template without {URL} rejected');
ok(cpg_proxy_url('bogus', 'x', $u21, false, '') === null && cpg_proxy_provider_id('nope') === '' && cpg_proxy_provider_id('scrapingant') === 'scrapingant', 'unknown providers rejected by whitelist');
// 404 dead feed + keys set -> NEVER proxied (credit guard: some providers bill 404s)
t_fresh();
$GLOBALS['TFeeds'] = t_base_feeds();
$GLOBALS['TFetchCount'] = array();
$GLOBALS['TProxyCalls'] = array();
$miss21 = 'https://sanaullastore.com/collections/brand-c/products.json?limit=250';
unset($GLOBALS['TFeeds'][$miss21]); // missing feed = stub 404 = definitively dead
update_option('cpg_settings', array('max_posts_run' => 99, 'max_posts_day' => 99, 'brands_per_run' => 6, 'proxy_provider' => 'scrapingant', 'proxy_key' => 'SK'));
cpg_run();
ok(empty($GLOBALS['TProxyCalls']), '404 dead feed NEVER proxied even with keys set (credit guard)');
// backup chain: primary provider down (500), backup rescues
t_fresh();
$GLOBALS['TFeeds'] = t_base_feeds();
$GLOBALS['TFetchCount'] = array();
$GLOBALS['TProxyCalls'] = array();
$GLOBALS['TForceCode'][$miss21] = 403;
$GLOBALS['TProxyFail'] = array('api.scrapingant.com'); // primary down; backup must rescue
$GLOBALS['TProxyBody'] = t_feed(array_map(function ($i) { return t_prod(400 + $i, "Mini by C Unstitched CC26UDD NL-$i", 'CC26UDD', "https://cdn.test/ok/d$i.jpg"); }, range(1, 5)));
update_option('cpg_settings', array('max_posts_run' => 99, 'max_posts_day' => 99, 'brands_per_run' => 6, 'proxy_provider' => 'scrapingant', 'proxy_key' => 'SK', 'proxy_provider2' => 'scraperapi', 'proxy_key2' => 'AK'));
$s21c = cpg_run();
ok(count($GLOBALS['TProxyCalls']) === 2, 'primary tried then backup (2 proxy calls for one feed)');
ok(strpos($GLOBALS['TProxyCalls'][0], 'api.scrapingant.com') !== false && strpos($GLOBALS['TProxyCalls'][1], 'api.scraperapi.com') !== false && strpos($GLOBALS['TProxyCalls'][1], 'api_key=AK') !== false, 'both provider URLs built correctly');
ok(strpos($s21c, '[NET] proxy rescues: scraperapi 1') !== false, 'rescue attributed to the BACKUP provider');
// circuit breaker: 4 block-failing feeds + failing proxy -> exactly 3 attempts then abandoned
t_fresh();
$GLOBALS['TFeeds'] = t_base_feeds();
$GLOBALS['TFetchCount'] = array();
$GLOBALS['TProxyCalls'] = array();
foreach (array('brand-b', 'brand-c', 'brand-d', 'brand-e') as $bb) { $GLOBALS['TForceCode']['https://sanaullastore.com/collections/' . $bb . '/products.json?limit=250'] = 403; }
$GLOBALS['TProxyFail'] = array('api.zenrows.com');
update_option('cpg_settings', array('max_posts_run' => 99, 'max_posts_day' => 99, 'brands_per_run' => 6, 'proxy_provider' => 'zenrows', 'proxy_key' => 'ZK'));
$s21d = cpg_run();
ok(count($GLOBALS['TProxyCalls']) === 3, 'circuit breaker: exactly 3 proxy attempts, then spending stops');
ok(strpos($s21d, 'abandoned after 3 straight failures') !== false, 'log reports proxy abandoned');
ok(strpos($s21d, 'proxy(zenrows) — HTTP 500') !== false, 'failure reason names the provider');
// custom relay as primary provider (no key needed — template carries access)
t_fresh();
$GLOBALS['TFeeds'] = t_base_feeds();
$GLOBALS['TFetchCount'] = array();
$GLOBALS['TProxyCalls'] = array();
unset($GLOBALS['TProxyFail']);
$GLOBALS['TForceCode'] = array('https://sanaullastore.com/collections/brand-b/products.json?limit=250' => 403);
$GLOBALS['TProxyBody'] = t_feed(array_map(function ($i) { return t_prod(300 + $i, "Chic by B Unstitched BB26UCC NL-$i", 'BB26UCC', "https://cdn.test/ok/c$i.jpg"); }, range(1, 5)));
update_option('cpg_settings', array('max_posts_run' => 99, 'max_posts_day' => 99, 'brands_per_run' => 6, 'proxy_provider' => 'custom', 'proxy_key' => '', 'proxy_custom' => 'https://relay.test/w/?u={URL}'));
$s21e = cpg_run();
ok(count($GLOBALS['TProxyCalls']) === 1 && strpos($GLOBALS['TProxyCalls'][0], 'https://relay.test/w/?u=' . rawurlencode('https://sanaullastore.com/collections/brand-b/products.json?limit=250')) === 0, 'custom relay URL built from template');
ok(strpos($s21e, '[NET] proxy rescues: custom 1') !== false, 'custom relay rescue counted');
unset($GLOBALS['TForceCode'], $GLOBALS['TProxyBody'], $GLOBALS['TProxyCalls']);

echo "\n==== RESULT: {$GLOBALS['PASS']} passed, {$GLOBALS['FAIL']} failed ====\n";
