<?php

namespace SEO_Article_Generator\AI\Providers;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Interface for AI Providers
 * 
 * @since 2.13.5
 */
interface Provider_Interface
{
    /**
     * Generate article content from prompt data
     * 
     * @param array $prompt_data Structured prompt data
     * @return array The raw AI response (article data)
     * @throws \Exception
     */
    public function generate_article(array $prompt_data): array;

    /**
     * Get last raw prompt
     * @return string|null
     */
    public function get_last_raw_prompt();

    /**
     * Get last raw response
     * @return string|null
     */
    public function get_last_raw_response();

    /**
     * Test the API connection parameters
     *
     * @return array test results
     * @throws \Exception
     */
    public function test_connection();
}
