package com.snsaver.app.ui.screens.inbox
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.work.WorkManager
import com.snsaver.app.data.network.PlatformDetector
import com.snsaver.app.domain.model.*
import com.snsaver.app.domain.repository.DownloadRepository
import com.snsaver.app.ui.components.*
import com.snsaver.app.util.ClipboardHelper
import com.snsaver.app.worker.DownloadWorker
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class InboxState(val items:List<DownloadItem> = emptyList(),val message:String?=null)
@HiltViewModel class InboxViewModel @Inject constructor(private val repo:DownloadRepository,private val detector:PlatformDetector,private val clipboard:ClipboardHelper,private val work:WorkManager):ViewModel(){
 private val message=MutableStateFlow<String?>(null);val state=combine(repo.observeAll(),message){items,msg->InboxState(items,msg)}.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),InboxState())
 fun paste(){val url=clipboard.read()?.let(detector::extract);if(url==null){message.value="No valid URL on clipboard";return};add(url)}
 private fun add(url:String)=viewModelScope.launch{val id=repo.add(DownloadItem(sourceUrl=url,platform=detector.detect(url)));enqueue(id);message.value="Download added"}
 fun retry(id:Long)=viewModelScope.launch{repo.get(id)?.let{repo.update(it.copy(status=DownloadStatus.PENDING,progress=0,errorMessage=null));enqueue(id)}}
 private suspend fun enqueue(id:Long){val request=DownloadWorker.request(id);work.enqueue(request);repo.get(id)?.let{repo.update(it.copy(workerId=request.id.toString()))}}
 fun consumed(){message.value=null}
}
@OptIn(ExperimentalMaterial3Api::class) @Composable fun InboxScreen(onItem:(Long)->Unit,vm:InboxViewModel=hiltViewModel()){
 val state by vm.state.collectAsStateWithLifecycle();val snack=remember{SnackbarHostState()};LaunchedEffect(state.message){state.message?.let{snack.showSnackbar(it);vm.consumed()}}
 Scaffold(topBar={TopAppBar(title={Text("Inbox",style=MaterialTheme.typography.headlineMedium)})},snackbarHost={SnackbarHost(snack)},floatingActionButton={ExtendedFloatingActionButton(onClick=vm::paste,icon={Icon(Icons.Default.ContentPaste,null)},text={Text("Paste link")})}){p->if(state.items.isEmpty())EmptyState("No downloads yet","Share a social link to SNSaver or paste one here") else LazyColumn(Modifier.fillMaxSize().padding(p).padding(horizontal=16.dp),contentPadding=PaddingValues(vertical=10.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){items(state.items,key={it.id}){item->DownloadCard(item,{if(item.status==DownloadStatus.COMPLETED)onItem(item.id)},{vm.retry(item.id)})}}}
}
