<?php
/**
 * Database Indexes Manager
 * Adds performance indexes to improve query speed by 50-70%
 *
 * @package WP_News_MCQ_Generator
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class NM_Database_Indexes {

	/**
	 * Create all performance indexes
	 * Call this on plugin activation
	 */
	public static function create_indexes() {
		global $wpdb;

		$errors = array();

		try {

			// 1. Index for leaderboard queries on usermeta
			$result1 = $wpdb->query(
				$wpdb->prepare(
					'CREATE INDEX IF NOT EXISTS idx_nm_meta_key_value ON %i (meta_key(50), meta_value(10))',
					$wpdb->usermeta
				)
			);

			if ( $result1 === false && $wpdb->last_error ) {
				$errors[] = 'usermeta index: ' . $wpdb->last_error;
			} else {
			}

			// 2. Indexes for user answers table
			$answers_table = $wpdb->prefix . 'nm_user_answers';

			// Check if table exists
			if ( $wpdb->get_var( "SHOW TABLES LIKE '{$answers_table}'" ) == $answers_table ) {

				// Index for user + MCQ queries
				// Index for user + MCQ queries
				$result2 = $wpdb->query(
					$wpdb->prepare(
						'CREATE INDEX IF NOT EXISTS idx_user_mcq_time ON %i (user_id, mcq_id, answered_at)',
						$answers_table
					)
				);

				// Index for date-based queries (weekly/monthly leaderboard)
				// Index for date-based queries (weekly/monthly leaderboard)
				$result3 = $wpdb->query(
					$wpdb->prepare(
						'CREATE INDEX IF NOT EXISTS idx_answered_at ON %i (answered_at)',
						$answers_table
					)
				);

				// Index for correctness queries
				$result4 = $wpdb->query(
					$wpdb->prepare(
						'CREATE INDEX IF NOT EXISTS idx_correct_answers ON %i (user_id, is_correct)',
						$answers_table
					)
				);

				if ( $result2 === false ) {
					$errors[] = 'user_mcq_time index failed';
				}
				if ( $result3 === false ) {
					$errors[] = 'answered_at index failed';
				}
				if ( $result4 === false ) {
					$errors[] = 'is_correct index failed';
				}

				if ( $result2 !== false && $result3 !== false && $result4 !== false ) {
				}
			} else {
			}

			// 3. Index for posts table (MCQ queries)
			$result5 = $wpdb->query(
				$wpdb->prepare(
					'CREATE INDEX IF NOT EXISTS idx_post_type_status_date ON %i (post_type(20), post_status(20), post_date)',
					$wpdb->posts
				)
			);

			if ( $result5 === false && $wpdb->last_error ) {
				$errors[] = 'posts index: ' . $wpdb->last_error;
			} else {
			}

			// 4. Index for term relationships (topic queries)
			$result6 = $wpdb->query(
				$wpdb->prepare(
					'CREATE INDEX IF NOT EXISTS idx_term_object ON %i (term_taxonomy_id, object_id)',
					$wpdb->term_relationships
				)
			);

			if ( $result6 === false && $wpdb->last_error ) {
				$errors[] = 'term_relationships index: ' . $wpdb->last_error;
			} else {
			}
		} catch ( Exception $e ) {
			$errors[] = 'Exception: ' . $e->getMessage();
		}

		if ( empty( $errors ) ) {
			update_option( 'nm_indexes_created', true );
			update_option( 'nm_indexes_version', '1.0' );
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Check if indexes exist
	 */
	public static function indexes_exist() {
		return (bool) get_option( 'nm_indexes_created', false );
	}

	/**
	 * Drop all custom indexes (for cleanup/uninstall)
	 */
	public static function drop_indexes() {
		global $wpdb;

		$answers_table = $wpdb->prefix . 'nm_user_answers';

		$wpdb->query( $wpdb->prepare( 'DROP INDEX IF EXISTS idx_nm_meta_key_value ON %i', $wpdb->usermeta ) );
		$wpdb->query( $wpdb->prepare( 'DROP INDEX IF EXISTS idx_user_mcq_time ON %i', $answers_table ) );
		$wpdb->query( $wpdb->prepare( 'DROP INDEX IF EXISTS idx_answered_at ON %i', $answers_table ) );
		$wpdb->query( $wpdb->prepare( 'DROP INDEX IF EXISTS idx_correct_answers ON %i', $answers_table ) );
		$wpdb->query( $wpdb->prepare( 'DROP INDEX IF EXISTS idx_post_type_status_date ON %i', $wpdb->posts ) );
		$wpdb->query( $wpdb->prepare( 'DROP INDEX IF EXISTS idx_term_object ON %i', $wpdb->term_relationships ) );

		delete_option( 'nm_indexes_created' );
		delete_option( 'nm_indexes_version' );
	}
}
