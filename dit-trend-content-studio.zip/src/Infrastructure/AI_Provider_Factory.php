<?php

namespace DIT\TrendStudio\Infrastructure;

use DIT\TrendStudio\Contracts\AIProviderInterface;
use DIT\TrendStudio\Integrations\Gemini\Client as Gemini_Client;
use DIT\TrendStudio\Content\Custom_Client;

if (!defined('ABSPATH')) {
	exit;
}

class AI_Provider_Factory
{
	const STRATEGY_GEMINI     = 'gemini';
	const STRATEGY_CUSTOM     = 'custom';

	private static $valid_strategies = [
		self::STRATEGY_GEMINI,
		self::STRATEGY_CUSTOM,
	];

	private static $legacy_map = [
		'composite' => self::STRATEGY_GEMINI,
		'gemini_only' => self::STRATEGY_GEMINI,
		'composite_openrouter' => self::STRATEGY_GEMINI,
		'openrouter_only' => self::STRATEGY_GEMINI,
		'openrouter_primary' => self::STRATEGY_GEMINI,
		'openrouter' => self::STRATEGY_GEMINI,
		'composite_groq' => self::STRATEGY_GEMINI,
		'groq_only' => self::STRATEGY_GEMINI,
		'groq' => self::STRATEGY_GEMINI,
		'composite_deepseek' => self::STRATEGY_CUSTOM,
		'deepseek_only' => self::STRATEGY_CUSTOM,
		'deepseek' => self::STRATEGY_CUSTOM,
		'perplexity_only' => self::STRATEGY_GEMINI,
	];

	private static $custom_providers_cache = null;

	public static function create(string $strategy, Logger $logger, array $input_data = []): AIProviderInterface
	{
		$strategy = self::normalize_strategy($strategy);

		switch ($strategy) {
		case self::STRATEGY_CUSTOM:
			$provider_id = (string) ($input_data['custom_provider_id'] ?? '');
			$providers = self::get_custom_providers();
			$profile = null;

			if ($provider_id !== '' && isset($providers[$provider_id])) {
				$profile = $providers[$provider_id];
			} elseif (!empty($providers)) {
				$default_id = (string) \get_option('dit_ts_custom_default_provider', '');
				if ($default_id !== '' && isset($providers[$default_id])) {
					$profile = $providers[$default_id];
				} else {
					$profile = reset($providers);
				}
			}

			if ($profile !== null) {
				$key = (string) ($profile['api_key'] ?? '');
				$url = (string) ($profile['api_url'] ?? '');
				$slug = (string) ($profile['id'] ?? 'custom');
				if (empty($key)) {
					throw new \Exception('Custom Provider API Key not configured for "' . ($profile['name'] ?? $slug) . '"');
				}
				if (empty($url)) {
					throw new \Exception('Custom Provider API URL not configured for "' . ($profile['name'] ?? $slug) . '"');
				}
				$client = new Custom_Client($key, $logger, $url, $slug, $profile);
			} else {
				$key = Custom_Client::get_api_key();
				$url = Custom_Client::get_api_url();
				if (empty($key)) {
					throw new \Exception('Custom Provider API Key not configured');
				}
				if (empty($url)) {
					throw new \Exception('Custom Provider API URL not configured');
				}
				$client = new Custom_Client($key, $logger, $url, 'custom', []);
			}

			$model_override = (string) ($input_data['custom_model_id'] ?? '');
			if ($model_override !== '') {
				$client->set_model_override($model_override);
			}

			return $client;

		case self::STRATEGY_GEMINI:
		default:
			$key = get_option('dit_ts_gemini_api_key', '');
			if (empty($key)) {
				$key = Gemini_Client::get_gemini_key();
			}
			if (empty($key)) {
				throw new \Exception('Gemini API Key not configured');
			}
			return new Gemini_Client($key, $logger);
		}
	}

	public static function create_from_test(string $provider, string $api_key, Logger $logger, string $api_url = '', string $provider_slug = 'custom'): AIProviderInterface
	{
		switch ($provider) {
		case 'custom':
			return new Custom_Client($api_key, $logger, $api_url, $provider_slug);
		case 'gemini':
		default:
			return new Gemini_Client($api_key, $logger);
		}
	}

	public static function get_effective_strategy(array $input_data = []): string
	{
		$raw = (string)($input_data['strategy_override'] ?? $input_data['ai_strategy'] ?? get_option('dit_ts_ai_strategy', self::STRATEGY_GEMINI));
		return self::normalize_strategy($raw);
	}

	public static function normalize_strategy(string $strategy): string
	{
		$strategy = \sanitize_key($strategy);
		if (in_array($strategy, self::$valid_strategies, true)) {
			return $strategy;
		}
		return self::$legacy_map[$strategy] ?? self::STRATEGY_GEMINI;
	}

	public static function strategy_to_provider(string $strategy): string
	{
		return self::normalize_strategy($strategy);
	}

	public static function get_valid_strategies(): array
	{
		return self::$valid_strategies;
	}

	public static function get_custom_providers(): array
	{
		if (self::$custom_providers_cache !== null) {
			return self::$custom_providers_cache;
		}

		$raw = \get_option('dit_ts_custom_providers', []);
		if (is_string($raw)) {
			$raw = \json_decode($raw, true);
		}
		if (!\is_array($raw)) {
			self::$custom_providers_cache = [];
			return self::$custom_providers_cache;
		}

		$indexed = [];
		foreach ($raw as $profile) {
			if (!empty($profile['id'])) {
				$indexed[$profile['id']] = $profile;
			}
		}
		self::$custom_providers_cache = $indexed;
		return self::$custom_providers_cache;
	}

	public static function clear_custom_providers_cache(): void
	{
		self::$custom_providers_cache = null;
	}

	/**
	 * Build an ordered fallback provider chain (cross-provider + universal).
	 *
	 * @param string $primary_strategy  Strategy that already failed ('gemini'|'custom').
	 * @param string $primary_provider_id  Custom provider ID (empty for built-in).
	 * @param array  $fallback_config   Optional. Fallback config array; loaded from option if empty.
	 * @param bool   $skip_gate         When true, bypass enable_cross_provider_fallback guard
	 *                                  (used when another mechanism already verified fallback eligibility).
	 * @return array<int, array{strategy: string, provider_id: string}>
	 */
	public static function build_fallback_chain(string $primary_strategy, string $primary_provider_id = '', array $fallback_config = [], bool $skip_gate = false): array
	{
		if (empty($fallback_config)) {
			$fallback_config = \get_option('dit_ts_custom_fallback_config', []);
			if (\is_string($fallback_config)) {
				$fallback_config = \json_decode($fallback_config, true) ?: [];
			}
		}

		$can_cross_fallback = !empty($fallback_config['enable_cross_provider_fallback']);
		$can_universal      = !empty($fallback_config['enable_universal_fallback']);

		if (!$skip_gate && !$can_cross_fallback && !$can_universal) {
			return [];
		}

		$chain = [];
		$providers = self::get_custom_providers();
		$cross_order = (array) ($fallback_config['cross_provider_order'] ?? []);

		// Custom (cross-provider) segment — runs when either the toggle is on or caller bypassed gate.
		if ($can_cross_fallback || $skip_gate) {
			foreach ($cross_order as $id) {
				$id = \sanitize_key((string) $id);
				if ($id === '' || $id === $primary_provider_id) {
					continue;
				}
				if (isset($providers[$id])) {
					$chain[] = ['strategy' => 'custom', 'provider_id' => $id];
				}
			}

			foreach ($providers as $id => $profile) {
				if ($id === $primary_provider_id) {
					continue;
				}
				if (!\in_array($id, $cross_order, true)) {
					$chain[] = ['strategy' => 'custom', 'provider_id' => $id];
				}
			}
		}

		// Built-in (universal Gemini) segment — only when explicitly enabled (skip_gate does NOT
		// auto-enable universal lest we silently append Gemini for cross-only configs).
		if ($can_universal && $primary_strategy !== 'gemini') {
			$gemini_key = \get_option('dit_ts_gemini_api_key', '');
			if (empty($gemini_key)) {
				$gemini_key = \DIT\TrendStudio\Integrations\Gemini\Client::get_gemini_key();
			}
			if (!empty($gemini_key)) {
				$chain[] = ['strategy' => 'gemini', 'provider_id' => ''];
			}
		}

		return $chain;
	}
}
