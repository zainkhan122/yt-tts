<?php
namespace AiSocialCollage\Services\ImageAI;

use AiSocialCollage\Config;
use AiSocialCollage\Contracts\ImageAIProviderInterface;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CloudflareWorkerProvider implements ImageAIProviderInterface {

	private $worker_url;
	private $api_key;

	public function __construct( $worker_url = '', $api_key = '' ) {
		$this->worker_url = rtrim( $worker_url, '/' );
		$this->api_key = $api_key;
	}

	public function generate_image( $prompt, $width = 1080, $height = 1350 ) {
		if ( empty( $this->worker_url ) ) {
			throw new \Exception( 'Cloudflare Worker AI requires a Worker URL.' );
		}

		$body = wp_json_encode( [
			'prompt' => $prompt,
			'width' => (int) $width,
			'height' => (int) $height,
		] );

		$headers = [ 'Content-Type' => 'application/json' ];
		if ( ! empty( $this->api_key ) ) {
			$headers['Authorization'] = 'Bearer ' . $this->api_key;
		}

		$response = wp_remote_post( $this->worker_url, [
			'timeout' => 120,
			'headers' => $headers,
			'body' => $body,
		] );

		if ( is_wp_error( $response ) ) {
			Logger::error( 'cloudflare_worker_image_error', null, [ 'error' => $response->get_error_message() ], '500' );
			throw new \Exception( 'Cloudflare Worker AI request failed: ' . $response->get_error_message() );
		}

		$code = wp_remote_retrieve_response_code( $response );
		$content_type = wp_remote_retrieve_header( $response, 'content-type' );

		if ( $code !== 200 ) {
			$body_text = wp_remote_retrieve_body( $response );
			$result = json_decode( $body_text, true );
			$err = $result['error'] ?? $result['message'] ?? mb_substr( $body_text, 0, 500 );
			Logger::error( 'cloudflare_worker_image_error', null, [ 'code' => $code, 'error' => $err ], '500' );
			throw new \Exception( "Cloudflare Worker AI error: {$err}" );
		}

		if ( strpos( $content_type, 'image/' ) !== false ) {
			$image_data = wp_remote_retrieve_body( $response );
		} else {
			$result = json_decode( wp_remote_retrieve_body( $response ), true );
			if ( ! empty( $result['image'] ) ) {
				$image_data = base64_decode( $result['image'] );
			} elseif ( ! empty( $result['image_base64'] ) ) {
				$image_data = base64_decode( $result['image_base64'] );
			} elseif ( ! empty( $result['url'] ) ) {
				return $this->download_from_url( $result['url'] );
			} else {
				throw new \Exception( 'Cloudflare Worker AI returned unexpected response format' );
			}
		}

		if ( empty( $image_data ) || strlen( $image_data ) < 1000 ) {
			throw new \Exception( 'Cloudflare Worker AI returned empty or invalid image data' );
		}

		return $this->save_temp_image( $image_data );
	}

	private function download_from_url( $url ) {
		$response = wp_remote_get( $url, [ 'timeout' => 60 ] );
		if ( is_wp_error( $response ) ) {
			throw new \Exception( 'Failed to download image from Worker URL: ' . $response->get_error_message() );
		}
		return $this->save_temp_image( wp_remote_retrieve_body( $response ) );
	}

	private function save_temp_image( $data ) {
		$temp_dir = AI_SOCIAL_COLLAGE_PATH . 'assets/temp';
		if ( ! is_dir( $temp_dir ) ) {
			wp_mkdir_p( $temp_dir );
		}

		$filename = 'ai_gen_' . uniqid() . '.png';
		$path = $temp_dir . '/' . $filename;
		file_put_contents( $path, $data );

		return $path;
	}

	public function get_provider_name() {
		return Config::PROVIDER_IMAGE_CLOUDFLARE_WORKER;
	}

	public function get_model_name() {
		return 'cloudflare-worker-ai';
	}
}
