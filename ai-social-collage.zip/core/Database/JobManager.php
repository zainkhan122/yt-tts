<?php
namespace AiSocialCollage\Database;

use AiSocialCollage\Config;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class JobManager {

	public static function create_job( $post_id ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) !== $table_name ) {
			Migration::ensure_tables();
		}

		// Race condition guard: use database-level atomic INSERT ... ON DUPLICATE KEY UPDATE
		// to prevent duplicate jobs when multiple cron cycles fire simultaneously.
		$result = $wpdb->query( $wpdb->prepare(
			"INSERT INTO $table_name (post_id, status, created_at, updated_at) 
			 VALUES (%d, %s, %s, %s)
			 ON DUPLICATE KEY UPDATE post_id = post_id",
			(int) $post_id,
			Config::STATUS_PENDING,
			gmdate( 'Y-m-d H:i:s' ),
			gmdate( 'Y-m-d H:i:s' )
		) );

		if ( $result === false ) {
			return false;
		}

		// If duplicate, job already exists - return 0
		if ( $result === 0 ) {
			return 0;
		}

		update_post_meta( $post_id, '_ai_collage_job_created', 1 );

		return $wpdb->insert_id;
	}

	public static function update_status( $job_id, $status ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		return $wpdb->update(
			$table_name,
			[
				'status' => sanitize_text_field( $status ),
				'updated_at' => gmdate( 'Y-m-d H:i:s' ),
			],
			[ 'id' => (int) $job_id ],
			[ '%s', '%s' ],
			[ '%d' ]
		);
	}

public static function update_job_data( $job_id, $headline, $hook ) {
        global $wpdb;
        $table_name = $wpdb->prefix . Config::TABLE_JOBS;
  
        // Guard against null values - sanitize_utf8_text handles null but be explicit
        $headline = $headline ?? '';
        $hook     = $hook ?? '';
  
        $wpdb->update(
            $table_name,
            [
                'ai_headline' => self::sanitize_utf8_text( $headline ),
                'ai_hook' => self::sanitize_utf8_text( $hook ),
                'updated_at' => gmdate( 'Y-m-d H:i:s' ),
            ],
            [ 'id' => (int) $job_id ],
            [ '%s', '%s', '%s' ],
            [ '%d' ]
        );
    }

	public static function update_detailed_description( $job_id, $description ) {
 global $wpdb;
 $table_name = $wpdb->prefix . Config::TABLE_JOBS;
 
 $wpdb->update(
 $table_name,
 [
 'ai_detailed_description' => self::sanitize_utf8_text( $description ),
 'updated_at' => gmdate( 'Y-m-d H:i:s' ),
 ],
 [ 'id' => (int) $job_id ],
 [ '%s', '%s' ],
 [ '%d' ]
);
}

	public static function update_eyebrow_key_terms( $job_id, $eyebrow, $key_terms ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		$wpdb->update(
			$table_name,
			[
				'ai_eyebrow' => sanitize_text_field( $eyebrow ),
				'ai_key_terms' => is_array( $key_terms ) ? wp_json_encode( $key_terms ) : '',
				'updated_at' => gmdate( 'Y-m-d H:i:s' ),
			],
			[ 'id' => (int) $job_id ],
			[ '%s', '%s', '%s' ],
			[ '%d' ]
		);
	}

	public static function update_emphasis_word( $job_id, $emphasis_word ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		$wpdb->update(
			$table_name,
			[
 			'ai_emphasis_word' => mb_substr( self::sanitize_utf8_text( $emphasis_word ), 0, 50, 'UTF-8' ),
				'updated_at' => gmdate( 'Y-m-d H:i:s' ),
			],
			[ 'id' => (int) $job_id ],
			[ '%s', '%s' ],
			[ '%d' ]
		);
	}

private static function sanitize_utf8_text( ?string $text ): string {
  		if ( $text === null || $text === '' ) {
  			return '';
  		}
  		$text = html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
  		$text = wp_strip_all_tags( $text );
  		$text = preg_replace( '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $text );
  		$text = trim( $text );
  		if ( ! mb_check_encoding( $text, 'UTF-8' ) ) {
  			$text = mb_convert_encoding( $text, 'UTF-8', 'UTF-8' );
  		}
  		return $text;
  	}

 	public static function update_image_metadata( $job_id, $metadata_json ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		$wpdb->update(
			$table_name,
			[
				'image_metadata' => $metadata_json,
				'updated_at' => gmdate( 'Y-m-d H:i:s' ),
			],
			[ 'id' => (int) $job_id ],
			[ '%s', '%s' ],
			[ '%d' ]
		);
	}

public static function job_exists_for_post( $post_id, $exclude_failed = false ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) !== $table_name ) {
			return false;
		}

		// Active/recoverable statuses that should block re-enqueueing.
		// FAILED and DISCARDED are terminal — they do NOT block.
		// SCHEDULED is included only when explicitly checking for active jobs (exclude_failed=false).
		// This matches CronScheduler's intent: don't queue if job is scheduled for prime time.
		if ( $exclude_failed ) {
			// FeedIngester path: only block on truly active jobs.
			// COMPLETED is included to prevent duplicate completed jobs.
			$blocking_statuses = [ Config::STATUS_PENDING, Config::STATUS_REWRITING, Config::STATUS_RENDERING, Config::STATUS_COMPLETED ];
		} else {
			// CronScheduler path: also block on SCHEDULED (prime-time wait).
			$blocking_statuses = [ Config::STATUS_PENDING, Config::STATUS_REWRITING, Config::STATUS_RENDERING, Config::STATUS_SCHEDULED, Config::STATUS_COMPLETED ];
		}

		$placeholders = implode( ',', array_fill( 0, count( $blocking_statuses ), '%s' ) );
		$sql = $wpdb->prepare(
			"SELECT COUNT(*) FROM $table_name WHERE post_id = %d AND status IN ($placeholders)",
			array_merge( [ (int) $post_id ], $blocking_statuses )
		);
		$count = $wpdb->get_var( $sql );

		return (int) $count > 0;
	}

	/**
	 * Check if a post has ANY job record (including failed/discarded).
	 * Used for auditing/debugging, not for enqueue blocking.
	 */
	public static function job_any_exists_for_post( $post_id ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) !== $table_name ) {
			return false;
		}

		$count = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM $table_name WHERE post_id = %d",
			(int) $post_id
		) );

		return $count > 0;
	}

	public static function get_job( $job_id ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM $table_name WHERE id = %d",
				(int) $job_id
			)
		);
	}

	public static function get_jobs_by_status( $status, $limit = 100, $offset = 0 ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM $table_name WHERE status = %s ORDER BY created_at DESC LIMIT %d OFFSET %d",
				sanitize_text_field( $status ),
				(int) $limit,
				(int) $offset
			)
		);
	}

	public static function get_status_counts() {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) !== $table_name ) {
			return [];
		}

		$results = $wpdb->get_results(
			"SELECT status, COUNT(*) as cnt FROM $table_name GROUP BY status"
		);

		$counts = [];
		foreach ( $results as $row ) {
			$counts[ $row->status ] = (int) $row->cnt;
		}

		return $counts;
	}

	public static function update_template_data( $job_id, $template, $category, $language ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		$wpdb->update(
			$table_name,
			[
				'template' => sanitize_text_field( $template ),
				'template_category' => sanitize_text_field( $category ),
				'language' => sanitize_text_field( $language ),
				'updated_at' => gmdate( 'Y-m-d H:i:s' ),
			],
			[ 'id' => (int) $job_id ],
			[ '%s', '%s', '%s', '%s' ],
			[ '%d' ]
		);
	}

	public static function update_brand_data( $job_id, $logo_position, $emphasis_color, $key_term_color, $breaking_color, $text_backing_color ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		$wpdb->update(
			$table_name,
			[
				'brand_logo_position' => sanitize_text_field( $logo_position ),
				'emphasis_color' => sanitize_hex_color( $emphasis_color ),
				'key_term_color' => sanitize_hex_color( $key_term_color ),
				'breaking_color' => sanitize_hex_color( $breaking_color ),
				'text_backing_color' => sanitize_hex_color( $text_backing_color ),
				'updated_at' => gmdate( 'Y-m-d H:i:s' ),
			],
			[ 'id' => (int) $job_id ],
			[ '%s', '%s', '%s', '%s', '%s', '%s' ],
			[ '%d' ]
		);
	}

	public static function update_additional_images( $job_id, array $image_urls ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		$data = [ 'updated_at' => gmdate( 'Y-m-d H:i:s' ) ];
		$format = [ '%s' ];

		for ( $i = 2; $i <= 4; $i++ ) {
			$key = 'image_url_' . $i;
			$data[ $key ] = isset( $image_urls[ $i ] ) ? esc_url_raw( $image_urls[ $i ] ) : null;
			$format[] = '%s';
		}

		$wpdb->update(
			$table_name,
			$data,
			[ 'id' => (int) $job_id ],
			$format,
			[ '%d' ]
		);
	}

	public static function update_headline_verified( $job_id, $verified = true ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		$wpdb->update(
			$table_name,
			[
				'headline_verified' => $verified ? 1 : 0,
				'updated_at' => gmdate( 'Y-m-d H:i:s' ),
			],
			[ 'id' => (int) $job_id ],
			[ '%d', '%s' ],
			[ '%d' ]
		);
	}

	public static function update_original_image( $job_id, string $image_path ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		$wpdb->update(
			$table_name,
			[
				'original_image_path' => $image_path,
				'updated_at' => gmdate( 'Y-m-d H:i:s' ),
			],
			[ 'id' => (int) $job_id ],
			[ '%s', '%s' ],
			[ '%d' ]
		);
	}

	public static function update_ai_generated_image_url( $job_id, $url ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		$wpdb->update(
			$table_name,
			[
				'ai_generated_image_url' => esc_url_raw( $url ),
				'updated_at' => gmdate( 'Y-m-d H:i:s' ),
			],
			[ 'id' => (int) $job_id ],
			[ '%s', '%s' ],
			[ '%d' ]
		);
	}

	public static function get_jobs_by_template( $template, $limit = 50, $offset = 0 ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM $table_name WHERE template = %s ORDER BY created_at DESC LIMIT %d OFFSET %d",
				sanitize_text_field( $template ),
				(int) $limit,
				(int) $offset
			)
		);
	}

	public static function get_jobs_by_language( $language, $limit = 50, $offset = 0 ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM $table_name WHERE language = %s ORDER BY created_at DESC LIMIT %d OFFSET %d",
				sanitize_text_field( $language ),
				(int) $limit,
				(int) $offset
			)
		);
	}

	public static function delete_job( $job_id ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		$wpdb->delete(
			$table_name,
			[ 'id' => (int) $job_id ],
			[ '%d' ]
		);
	}

    public static function purge_old_jobs( $days ) {
        global $wpdb;
        $table_name = $wpdb->prefix . Config::TABLE_JOBS;

        return (int) $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM $table_name WHERE created_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY) AND status IN (%s, %s)",
                (int) $days,
                Config::STATUS_COMPLETED,
                Config::STATUS_FAILED
            )
        );
    }

	/**
	 * Purge jobs stuck in non-terminal active statuses beyond the retention window.
	 *
	 * Covers `pending` jobs whose Action Scheduler action was lost and `scheduled`
	 * jobs whose prime-time action never fired (legitimate prime-time waits are < 24h).
	 * `ready_for_review` is intentionally excluded (human action pending);
	 * `rewriting`/`rendering` are transitioned to failed within minutes by
	 * mark_stuck_jobs_failed() and then purged by purge_old_jobs().
	 * Uses updated_at: every state transition refreshes it, so only truly
	 * stagnant rows are removed.
	 */
	public static function purge_stuck_jobs( $days ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		return (int) $wpdb->query(
			$wpdb->prepare(
				"DELETE FROM $table_name WHERE updated_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY) AND status IN (%s, %s)",
				(int) $days,
				Config::STATUS_PENDING,
				Config::STATUS_SCHEDULED
			)
		);
	}

	public static function count_stuck_jobs( $timeout_minutes = 30 ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;
		$stuck_statuses = [ Config::STATUS_PENDING, Config::STATUS_REWRITING, Config::STATUS_RENDERING, Config::STATUS_SCHEDULED ];
		$placeholders = implode( ',', array_fill( 0, count( $stuck_statuses ), '%s' ) );
		$sql = $wpdb->prepare(
			"SELECT COUNT(*) FROM `$table_name` WHERE status IN ($placeholders) AND updated_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d MINUTE)",
			array_merge( $stuck_statuses, [ (int) $timeout_minutes ] )
		);
		return (int) $wpdb->get_var( $sql );
	}

	public static function mark_stuck_jobs_failed( $timeout_minutes = 30 ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;
		$stuck_statuses = [ Config::STATUS_REWRITING, Config::STATUS_RENDERING ];
		$placeholders = implode( ',', array_fill( 0, count( $stuck_statuses ), '%s' ) );

		$stuck = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM `$table_name` WHERE status IN ($placeholders) AND updated_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d MINUTE)",
				array_merge( $stuck_statuses, [ (int) $timeout_minutes ] )
			)
		);

		$count = 0;
		foreach ( $stuck as $job ) {
			$wpdb->update(
				$table_name,
				[ 'status' => Config::STATUS_FAILED, 'updated_at' => gmdate( 'Y-m-d H:i:s' ) ],
				[ 'id' => (int) $job->id ],
				[ '%s', '%s' ],
				[ '%d' ]
			);

			// ENHANCEMENT: Clear individual job locks to prevent persistent staleness
			delete_transient( 'ai_collage_job_lock_' . (int) $job->id );
			delete_transient( 'ai_collage_queued_recent_' . (int) $job->post_id );

			delete_post_meta( (int) $job->post_id, '_ai_collage_job_created' );

			$count++;
		}

		// PENDING recovery: a pending job whose Action Scheduler action was lost
		// (failed enqueue, AS table truncation, etc.) can never transition and
		// would sit in the queue forever. Fail it so it surfaces on the Jobs page
		// for manual retry. A pending job that still owns a live AS action is
		// left untouched — this includes jobs deferred while the pipeline is
		// paused (QueueProcessor::process_job re-schedules them every 60s, so a
		// live action always exists for them). If a stale action fires after the
		// job was failed, do_process_job() safely no-ops on STATUS_FAILED.
		//
		// "Live action" semantics MUST match QueueHealthMonitor::fix_orphaned_db_jobs()
		// (single source of truth for action-existence): three argument formats
		// (compact JSON, JSON with space, PHP-serialized) AND a 5-minute
		// scheduled_date_gmt window. Without the window, a stale-but-pending
		// action (runner dead) would shield an orphaned job — defeating the fix
		// exactly when the monitor is also dead.
		$as_live_table = $wpdb->prefix . 'actionscheduler_actions';
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$as_live_table'" ) === $as_live_table ) {
			$orphaned_sql = 'SELECT j.id, j.post_id FROM `' . $table_name . '` j '
				. 'WHERE j.status = %s '
				. 'AND j.updated_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d MINUTE) '
				. 'AND NOT EXISTS ('
				. '  SELECT 1 FROM `' . $as_live_table . '` a '
				. '  WHERE a.hook = %s '
				. '    AND ( '
				. '      (a.status = \'in-progress\') '
				. '      OR (a.status = \'pending\' AND a.scheduled_date_gmt > DATE_SUB(UTC_TIMESTAMP(), INTERVAL 5 MINUTE)) '
				. '    ) '
				. '    AND ( a.args LIKE CONCAT(\'%%"job_id":\', j.id, \'}\') '
				. '       OR a.args LIKE CONCAT(\'%%"job_id": \', j.id, \'}\') '
				. '       OR a.args LIKE CONCAT(\'%%\\\'job_id\\\':\', j.id, \';%%\') )'
				. ')';
			$orphaned_pending = $wpdb->get_results( $wpdb->prepare(
				$orphaned_sql,
				Config::STATUS_PENDING,
				(int) $timeout_minutes,
				Config::ACTION_PROCESS_JOB
			) );

			foreach ( $orphaned_pending as $pjob ) {
				$wpdb->update(
					$table_name,
					[ 'status' => Config::STATUS_FAILED, 'updated_at' => gmdate( 'Y-m-d H:i:s' ) ],
					[ 'id' => (int) $pjob->id ],
					[ '%s', '%s' ],
					[ '%d' ]
				);

				delete_transient( 'ai_collage_job_lock_' . (int) $pjob->id );
				delete_transient( 'ai_collage_queued_recent_' . (int) $pjob->post_id );

				delete_post_meta( (int) $pjob->post_id, '_ai_collage_job_created' );

				$count++;
			}
		}

		// CRITICAL FIX: Properly unclaim stuck AS actions AND delete orphaned claim rows
		// This replaces the previous raw SQL that only zeroed claim_id without cleaning up
		// the claims table, which caused queue deadlocks.
		$as_table = $wpdb->prefix . 'actionscheduler_actions';
		$claims_table = $wpdb->prefix . 'actionscheduler_claims';
		
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$as_table'" ) === $as_table ) {
			// First, collect the claim IDs that will be orphaned so we can clean them up
			$claim_ids_to_delete = $wpdb->get_col( $wpdb->prepare(
				"SELECT DISTINCT claim_id FROM `$as_table` 
				 WHERE claim_id != 0 AND status = 'in-progress' AND hook = %s",
				Config::ACTION_PROCESS_JOB
			) );
			
			// Reset stuck actions to pending and unclaim them
			$wpdb->query( $wpdb->prepare(
				"UPDATE `$as_table` SET status = 'pending', claim_id = 0 
				 WHERE status = 'in-progress' AND hook = %s",
				Config::ACTION_PROCESS_JOB
			) );
			
			// Delete the orphaned claim rows to prevent claim count inflation
			if ( ! empty( $claim_ids_to_delete ) ) {
				$claim_placeholders = implode( ',', array_fill( 0, count( $claim_ids_to_delete ), '%d' ) );
				$wpdb->query( $wpdb->prepare(
					"DELETE FROM `$claims_table` WHERE claim_id IN ($claim_placeholders)",
					$claim_ids_to_delete
				) );
			}
		}

		return $count;
	}

	public static function update_viability_score( $job_id, $score, $reason = '' ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		$wpdb->update(
			$table_name,
			[
				'viability_score' => (int) $score,
				'viability_reason' => sanitize_text_field( mb_substr( $reason, 0, 500 ) ),
				'updated_at' => gmdate( 'Y-m-d H:i:s' ),
			],
			[ 'id' => (int) $job_id ],
			[ '%d', '%s', '%s' ],
			[ '%d' ]
		);
	}

	public static function purge_discarded_jobs( $days ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		return (int) $wpdb->query(
			$wpdb->prepare(
				"DELETE FROM $table_name WHERE created_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d DAY) AND status = %s",
				(int) $days,
				Config::STATUS_DISCARDED
			)
		);
	}

	public static function get_viability_stats() {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) !== $table_name ) {
			return [ 'total_scored' => 0, 'avg_score' => 0, 'discarded_count' => 0, 'passed_count' => 0, 'score_distribution' => [] ];
		}

		$total_scored = (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM $table_name WHERE viability_score IS NOT NULL"
		);

		$avg_score = (float) $wpdb->get_var(
			"SELECT AVG(viability_score) FROM $table_name WHERE viability_score IS NOT NULL"
		);

		$discarded_count = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM $table_name WHERE status = %s",
				Config::STATUS_DISCARDED
			)
		);

		$passed_count = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM $table_name WHERE viability_score IS NOT NULL AND status != %s",
				Config::STATUS_DISCARDED
			)
		);

		$distribution = [];
		$rows = $wpdb->get_results(
			"SELECT
				CASE
					WHEN viability_score BETWEEN 1 AND 3 THEN '1-3'
					WHEN viability_score BETWEEN 4 AND 6 THEN '4-6'
					WHEN viability_score BETWEEN 7 AND 8 THEN '7-8'
					WHEN viability_score BETWEEN 9 AND 10 THEN '9-10'
					ELSE 'unknown'
				END as bucket,
				COUNT(*) as cnt
			FROM $table_name
			WHERE viability_score IS NOT NULL
			GROUP BY bucket
			ORDER BY bucket"
		);
		foreach ( $rows as $row ) {
			$distribution[ $row->bucket ] = (int) $row->cnt;
		}

		return [
			'total_scored' => $total_scored,
			'avg_score' => round( $avg_score, 2 ),
			'discarded_count' => $discarded_count,
			'passed_count' => $passed_count,
			'score_distribution' => $distribution,
		];
	}

	public static function update_retry_count( $job_id, $retry_count ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		$wpdb->update(
			$table_name,
			[
				'retry_count' => (int) $retry_count,
				'updated_at' => gmdate( 'Y-m-d H:i:s' ),
			],
			[ 'id' => (int) $job_id ],
			[ '%d', '%s' ],
			[ '%d' ]
		);
	}

	/**
	 * Get video jobs ready for Buffer publishing via the publish scheduler cron.
	 * Returns jobs with a video_url, publish_at <= now, and not yet published to all channels.
	 *
	 * @param int $limit Max jobs to return.
	 * @return array Array of job objects.
	 */
	/**
	 * Get the latest completed job for a specific post.
	 */
	public static function get_completed_job_for_post( int $post_id ): ?object {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) !== $table_name ) {
			return null;
		}

		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM $table_name
				 WHERE post_id = %d
				   AND status = %s
				   AND (video_url IS NULL OR video_url = '')
				 ORDER BY id DESC
				 LIMIT 1",
				$post_id,
				Config::STATUS_COMPLETED
			)
		);
	}

	/**
	 * Get completed jobs that should already have a video_url but don't
	 * (render finished but R2 upload was skipped, failed, or aborted).
	 * Used by the stuck-R2 retry cron to find recoverable jobs.
	 *
	 * @param int $limit Max jobs to return.
	 * @return array Array of job objects.
	 */
	public static function get_stuck_r2_jobs( int $limit = 10 ): array {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) !== $table_name ) {
			return [];
		}
		// Only recover completed jobs whose WP post is PUBLISHED and that have an
		// AI-generated reel attachment. Draft/future posts defer R2 to publish
		// time (PostObserver::on_publish_transition) and image posts never have a
		// reel — neither belongs in the stuck-R2 recovery loop.
		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT j.* FROM $table_name j
				 INNER JOIN {$wpdb->posts} p ON p.ID = j.post_id
					AND p.post_type = 'post'
					AND p.post_status = 'publish'
				 INNER JOIN {$wpdb->posts} att ON att.post_parent = j.post_id
					AND att.post_type = 'attachment'
					AND att.post_mime_type LIKE 'video%'
				 INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = att.ID
					AND pm.meta_key = %s
					AND pm.meta_value = '1'
				 WHERE j.status = %s
				   AND (j.video_url IS NULL OR j.video_url = '')
				   AND j.updated_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL 10 MINUTE)
				   AND j.updated_at > DATE_SUB(UTC_TIMESTAMP(), INTERVAL 24 HOUR)
				 ORDER BY j.updated_at ASC
				 LIMIT %d",
				Config::META_IS_AI_COLLAGE,
				Config::STATUS_COMPLETED,
				$limit
			)
		);
	}

	public static function get_jobs_ready_for_publish( int $limit = 20 ): array {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM $table_name
				WHERE status = %s
				AND video_url IS NOT NULL AND video_url != ''
				AND publish_at IS NOT NULL AND publish_at != ''
				AND publish_at <= UTC_TIMESTAMP()
				ORDER BY publish_at ASC
				LIMIT %d",
				Config::STATUS_COMPLETED,
				$limit
			)
		);
	}

	public static function update_job_fields( $job_id, array $fields ) {
		global $wpdb;
		$table_name = $wpdb->prefix . Config::TABLE_JOBS;

		$allowed = [ 'video_url', 'publish_at', 'published_channels', 'buffer_post_ids' ];
		$data = [];
		$format = [];
		foreach ( $fields as $key => $value ) {
			if ( in_array( $key, $allowed, true ) ) {
				$data[ $key ] = $value;
				$format[] = '%s';
			}
		}
		if ( empty( $data ) ) {
			return;
		}
		$data['updated_at'] = gmdate( 'Y-m-d H:i:s' );
		$format[] = '%s';

		$wpdb->update(
			$table_name,
			$data,
			[ 'id' => (int) $job_id ],
			$format,
			[ '%d' ]
		);
	}
}
