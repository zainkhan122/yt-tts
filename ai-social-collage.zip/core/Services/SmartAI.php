<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SmartAI {

    public static function extract_dominant_colors( $image_url, $count = null ) {
        if ( ! $count ) {
            $count = Config::SMART_AI_COLOR_COUNT;
        }

        $start_time = microtime( true );

        $cache_key = 'ai_collage_colors_' . md5( $image_url );
        $cached = get_transient( $cache_key );
        if ( $cached !== false ) {
            return $cached;
        }

        $image_path = self::resolve_local_path( $image_url );
        if ( ! $image_path || ! file_exists( $image_path ) ) {
            return self::get_fallback_colors();
        }

        try {
            $image_info = getimagesize( $image_path );
            if ( ! $image_info ) {
                return self::get_fallback_colors();
            }

            $mime_type = $image_info['mime'];
            switch ( $mime_type ) {
                case 'image/jpeg':
                    $image = imagecreatefromjpeg( $image_path );
                    break;
                case 'image/png':
                    $image = imagecreatefrompng( $image_path );
                    break;
                case 'image/webp':
                    $image = imagecreatefromwebp( $image_path );
                    break;
                default:
                    return self::get_fallback_colors();
            }

            if ( ! $image ) {
                return self::get_fallback_colors();
            }

            $colors = self::quantize_colors( $image, $count );
            imagedestroy( $image );

		$result = [
			'primary' => $colors[0] ?? Config::DEFAULT_BRAND_PRIMARY_COLOR,
			'secondary' => $colors[1] ?? Config::DEFAULT_BRAND_SECONDARY_COLOR,
			'accent' => $colors[2] ?? Config::DEFAULT_BRAND_ACCENT_COLOR,
			'emphasis' => Config::DEFAULT_BRAND_EMPHASIS_COLOR,
			'key_term' => Config::DEFAULT_BRAND_KEY_TERM_COLOR,
			'breaking' => Config::DEFAULT_BRAND_BREAKING_COLOR,
			'text_backing' => Config::DEFAULT_BRAND_TEXT_BACKING_COLOR,
			'palette' => array_slice( $colors, 0, $count ),
			'dark_text' => self::should_use_dark_text( $colors[0] ?? '#000000' ),
			'overlay_opacity' => self::calculate_overlay_opacity( $colors ),
		];

        $result = self::snap_to_ds_palette( $result );

        // Force text_backing from brand settings. Sampling it from the image
        // often leads to unreadable contrast.
        $brand = Config::get_brand_settings();
        $result['palette']['text_backing'] = $brand['text_backing_color'] ?? Config::DEFAULT_BRAND_TEXT_BACKING_COLOR;

        set_transient( $cache_key, $result, HOUR_IN_SECONDS );

	$execution_time = microtime( true ) - $start_time;
		Logger::info( Config::LOG_ACTION_SMART_AI_COLORS, null, [ 'image' => $image_url ], '200', wp_json_encode( $result['palette'] ), $execution_time );

            return $result;
        } catch ( \Exception $e ) {
            return self::get_fallback_colors();
        }
    }

    public static function detect_focal_point( $image_url ) {
        $start_time = microtime( true );

        $cache_key = 'ai_collage_focal_' . md5( $image_url );
        $cached = get_transient( $cache_key );
        if ( $cached !== false ) {
            return $cached;
        }

        $image_path = self::resolve_local_path( $image_url );
        if ( ! $image_path || ! file_exists( $image_path ) ) {
            return self::get_default_focal_point();
        }

        try {
            $image_info = getimagesize( $image_path );
            if ( ! $image_info ) {
                return self::get_default_focal_point();
            }

            $mime_type = $image_info['mime'];
            switch ( $mime_type ) {
                case 'image/jpeg':
                    $image = imagecreatefromjpeg( $image_path );
                    break;
                case 'image/png':
                    $image = imagecreatefrompng( $image_path );
                    break;
                case 'image/webp':
                    $image = imagecreatefromwebp( $image_path );
                    break;
                default:
                    return self::get_default_focal_point();
            }

            if ( ! $image ) {
                return self::get_default_focal_point();
            }

            $width = imagesx( $image );
            $height = imagesy( $image );

            $focal = self::calculate_brightness_focal( $image, $width, $height );
            imagedestroy( $image );

            $result = [
                'x' => $focal['x'],
                'y' => $focal['y'],
                'x_percent' => round( $focal['x'] / $width, 4 ),
                'y_percent' => round( $focal['y'] / $height, 4 ),
                'css_position' => round( ( $focal['x'] / $width ) * 100 ) . '% ' . round( ( $focal['y'] / $height ) * 100 ) . '%',
            ];

            set_transient( $cache_key, $result, HOUR_IN_SECONDS );

	$execution_time = microtime( true ) - $start_time;
		Logger::info( Config::LOG_ACTION_SMART_AI_FOCAL, null, [ 'image' => $image_url ], '200', wp_json_encode( $result ), $execution_time );

            return $result;
        } catch ( \Exception $e ) {
            return self::get_default_focal_point();
        }
    }

	public static function enhance_job_data( array $job_data ) {
		$auto_color = (bool) get_option( Config::OPTION_AUTO_COLOR_ENABLED, true );
		$smart_crop = (bool) get_option( Config::OPTION_SMART_CROP_ENABLED, true );

		$image_url = $job_data['image_url'] ?? '';
		if ( empty( $image_url ) ) {
			$job_data['brand'] = $job_data['brand'] ?? Config::get_brand_settings();
			$job_data['focal_point'] = self::get_default_focal_point();
			$job_data['colors'] = self::get_fallback_colors( $job_data['brand'] );
			return $job_data;
		}

		if ( $auto_color ) {
			$job_data['colors'] = self::extract_dominant_colors( $image_url );
		} else {
			$job_data['colors'] = self::get_fallback_colors( $job_data['brand'] ?? [] );
		}

		if ( $smart_crop ) {
			$job_data['focal_point'] = self::detect_focal_point( $image_url );
		} else {
			$job_data['focal_point'] = self::get_default_focal_point();
		}

		if ( empty( $job_data['brand'] ) ) {
			$job_data['brand'] = Config::get_brand_settings();
		}

		return $job_data;
	}

    private static function quantize_colors( $image, $count ) {
        $width = imagesx( $image );
        $height = imagesy( $image );

        $sample_step = max( 1, (int) ( sqrt( $width * $height ) / 50 ) );
        $color_buckets = [];

        for ( $y = 0; $y < $height; $y += $sample_step ) {
            for ( $x = 0; $x < $width; $x += $sample_step ) {
                $rgb = imagecolorat( $image, $x, $y );
                $r = ( $rgb >> 16 ) & 0xFF;
                $g = ( $rgb >> 8 ) & 0xFF;
                $b = $rgb & 0xFF;

                $qr = (int) ( $r / 32 ) * 32;
                $qg = (int) ( $g / 32 ) * 32;
                $qb = (int) ( $b / 32 ) * 32;

                $key = sprintf( '%02x%02x%02x', $qr, $qg, $qb );
                if ( ! isset( $color_buckets[ $key ] ) ) {
                    $color_buckets[ $key ] = [ 'count' => 0, 'r' => 0, 'g' => 0, 'b' => 0 ];
                }
                $color_buckets[ $key ]['count']++;
                $color_buckets[ $key ]['r'] += $r;
                $color_buckets[ $key ]['g'] += $g;
                $color_buckets[ $key ]['b'] += $b;
            }
        }

        uasort( $color_buckets, function( $a, $b ) {
            return $b['count'] - $a['count'];
        });

        $results = [];
        $idx = 0;
        foreach ( $color_buckets as $key => $bucket ) {
            if ( $idx >= $count * 3 ) break;

            $avg_r = (int) ( $bucket['r'] / $bucket['count'] );
            $avg_g = (int) ( $bucket['g'] / $bucket['count'] );
            $avg_b = (int) ( $bucket['b'] / $bucket['count'] );

            $brightness = ( $avg_r * 299 + $avg_g * 587 + $avg_b * 114 ) / 1000;
            $saturation = max( $avg_r, $avg_g, $avg_b ) - min( $avg_r, $avg_g, $avg_b );

            if ( $saturation < 20 && $brightness > 230 ) continue;
            if ( $saturation < 10 && $brightness < 25 ) continue;

            $too_similar = false;
            foreach ( $results as $existing ) {
                $existing_rgb = sscanf( $existing, '#%02x%02x%02x' );
                $distance = sqrt(
                    pow( $avg_r - $existing_rgb[0], 2 ) +
                    pow( $avg_g - $existing_rgb[1], 2 ) +
                    pow( $avg_b - $existing_rgb[2], 2 )
                );
                if ( $distance < 60 ) {
                    $too_similar = true;
                    break;
                }
            }

            if ( ! $too_similar ) {
                $results[] = sprintf( '#%02x%02x%02x', $avg_r, $avg_g, $avg_b );
                if ( count( $results ) >= $count ) break;
            }
            $idx++;
        }

        $ds_palette = [ Config::DEFAULT_BRAND_EMPHASIS_COLOR, Config::DEFAULT_BRAND_SECONDARY_COLOR, Config::DEFAULT_BRAND_PRIMARY_COLOR, Config::DEFAULT_BRAND_ACCENT_COLOR, Config::DEFAULT_BRAND_TEXT_BACKING_COLOR ];
		while ( count( $results ) < $count ) {
			$results[] = $ds_palette[ rand( 0, count( $ds_palette ) - 1 ) ];
		}

        return $results;
    }

    private static function calculate_brightness_focal( $image, $width, $height ) {
        $grid_x = 10;
        $grid_y = 10;
        $cell_w = (int) ( $width / $grid_x );
        $cell_h = (int) ( $height / $grid_y );

        $max_brightness = 0;
        $focal_x = (int) ( $width / 2 );
        $focal_y = (int) ( $height / 3 );

        $weight_center = 1.5;

        for ( $gy = 0; $gy < $grid_y; $gy++ ) {
            for ( $gx = 0; $gx < $grid_x; $gx++ ) {
                $cell_brightness = 0;
                $sample_count = 0;

                $start_x = $gx * $cell_w;
                $start_y = $gy * $cell_h;
                $end_x = min( $start_x + $cell_w, $width );
                $end_y = min( $start_y + $cell_h, $height );

                $step = max( 1, (int) ( $cell_w / 4 ) );

                for ( $sy = $start_y; $sy < $end_y; $sy += $step ) {
                    for ( $sx = $start_x; $sx < $end_x; $sx += $step ) {
                        $rgb = imagecolorat( $image, $sx, $sy );
                        $r = ( $rgb >> 16 ) & 0xFF;
                        $g = ( $rgb >> 8 ) & 0xFF;
                        $b = $rgb & 0xFF;
                        $cell_brightness += ( $r * 299 + $g * 587 + $b * 114 ) / 1000;
                        $sample_count++;
                    }
                }

                if ( $sample_count > 0 ) {
                    $cell_brightness /= $sample_count;
                }

                $cx = abs( $gx - $grid_x / 2 + 0.5 ) / ( $grid_x / 2 );
                $cy = abs( $gy - $grid_y / 2 + 0.5 ) / ( $grid_y / 2 );
                $center_bonus = 1 + $weight_center * ( 1 - ( $cx + $cy ) / 2 );

                $top_bonus = 1 + ( 1 - $gy / $grid_y ) * 0.3;

                $weighted_brightness = $cell_brightness * $center_bonus * $top_bonus;

                if ( $weighted_brightness > $max_brightness ) {
                    $max_brightness = $weighted_brightness;
                    $focal_x = (int) ( $start_x + $cell_w / 2 );
                    $focal_y = (int) ( $start_y + $cell_h / 2 );
                }
            }
        }

        return [ 'x' => $focal_x, 'y' => $focal_y ];
    }

    private static function should_use_dark_text( $hex_color ) {
        $rgb = sscanf( $hex_color, '#%02x%02x%02x' );
        if ( ! $rgb ) return true;
        $brightness = ( $rgb[0] * 299 + $rgb[1] * 587 + $rgb[2] * 114 ) / 1000;
        return $brightness > 128;
    }

    private static function calculate_overlay_opacity( $colors ) {
        $primary_rgb = sscanf( $colors[0] ?? '#000000', '#%02x%02x%02x' );
        if ( ! $primary_rgb ) return 0.7;
        $brightness = ( $primary_rgb[0] * 299 + $primary_rgb[1] * 587 + $primary_rgb[2] * 114 ) / 1000;
        if ( $brightness < Config::SMART_AI_MIN_BRIGHTNESS * 255 ) {
            return 0.5;
        }
        return 0.7;
    }

    private static function resolve_local_path( $image_url ) {
        $upload_dir = wp_upload_dir();
        $base_url = $upload_dir['baseurl'];
        $base_dir = $upload_dir['basedir'];

        if ( strpos( $image_url, $base_url ) === 0 ) {
            return str_replace( $base_url, $base_dir, $image_url );
        }

        $attachment_id = attachment_url_to_postid( $image_url );
        if ( $attachment_id ) {
            $path = get_attached_file( $attachment_id );
            if ( $path && file_exists( $path ) ) {
                return $path;
            }
        }

        return null;
    }

    private static function snap_to_ds_palette( array $result ) {
        $ds = [
            Config::DEFAULT_BRAND_EMPHASIS_COLOR,
            Config::DEFAULT_BRAND_SECONDARY_COLOR,
            Config::DEFAULT_BRAND_PRIMARY_COLOR,
            Config::DEFAULT_BRAND_ACCENT_COLOR,
            Config::DEFAULT_BRAND_TEXT_BACKING_COLOR,
        ];
        foreach ( [ 'primary', 'secondary', 'accent' ] as $key ) {
            if ( empty( $result[ $key ] ) ) {
                continue;
            }
            $result[ $key ] = self::nearest_ds_color( $result[ $key ], $ds );
        }
        if ( ! empty( $result['palette'] ) && is_array( $result['palette'] ) ) {
            foreach ( $result['palette'] as $i => $color ) {
                $result['palette'][ $i ] = self::nearest_ds_color( $color, $ds );
            }
        }
        return $result;
    }

    private static function nearest_ds_color( $hex, array $palette ) {
        $hex = ltrim( $hex, '#' );
        if ( strlen( $hex ) !== 6 || ! ctype_xdigit( $hex ) ) {
            return '#' . $hex;
        }
        $r = hexdec( substr( $hex, 0, 2 ) );
        $g = hexdec( substr( $hex, 2, 2 ) );
        $b = hexdec( substr( $hex, 4, 2 ) );
        $best = '#' . $hex;
        $best_dist = PHP_INT_MAX;
        foreach ( $palette as $candidate ) {
            $ch = ltrim( $candidate, '#' );
            if ( strlen( $ch ) !== 6 ) {
                continue;
            }
            $cr = hexdec( substr( $ch, 0, 2 ) );
            $cg = hexdec( substr( $ch, 2, 2 ) );
            $cb = hexdec( substr( $ch, 4, 2 ) );
            $dist = sqrt( pow( $r - $cr, 2 ) + pow( $g - $cg, 2 ) + pow( $b - $cb, 2 ) );
            if ( $dist < $best_dist ) {
                $best_dist = $dist;
                $best = $candidate;
            }
        }
        return $best_dist <= 25 ? $best : '#' . $hex;
    }

	private static function get_fallback_colors( array $brand = [] ) {
		if ( empty( $brand ) ) {
			$brand = Config::get_brand_settings();
		}
		return [
			'primary' => $brand['primary_color'] ?? Config::DEFAULT_BRAND_PRIMARY_COLOR,
			'secondary' => $brand['secondary_color'] ?? Config::DEFAULT_BRAND_SECONDARY_COLOR,
			'accent' => $brand['accent_color'] ?? Config::DEFAULT_BRAND_ACCENT_COLOR,
			'emphasis' => $brand['emphasis_color'] ?? Config::DEFAULT_BRAND_EMPHASIS_COLOR,
			'key_term' => $brand['key_term_color'] ?? Config::DEFAULT_BRAND_KEY_TERM_COLOR,
			'breaking' => $brand['breaking_color'] ?? Config::DEFAULT_BRAND_BREAKING_COLOR,
			'text_backing' => $brand['text_backing_color'] ?? Config::DEFAULT_BRAND_TEXT_BACKING_COLOR,
			'palette' => [ $brand['primary_color'] ?? Config::DEFAULT_BRAND_PRIMARY_COLOR, $brand['secondary_color'] ?? Config::DEFAULT_BRAND_SECONDARY_COLOR, $brand['accent_color'] ?? Config::DEFAULT_BRAND_ACCENT_COLOR ],
			'dark_text' => false,
			'overlay_opacity' => 0.7,
		];
	}

    private static function get_default_focal_point() {
        return [
            'x' => 540,
            'y' => 450,
            'x_percent' => 0.5,
            'y_percent' => 0.3333,
            'css_position' => '50% 33%',
        ];
    }
}
