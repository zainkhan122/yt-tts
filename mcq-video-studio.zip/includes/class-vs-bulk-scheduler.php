<?php

/**
 * Bulk Scheduler
 *
 * Handles bulk quiz generation and job scheduling for the Content Calendar.
 *
 * @package MCQ_Video_Studio
 * @since 1.2.5
 */

if (! defined('ABSPATH')) {
    exit;
}

class VS_Bulk_Scheduler
{

    private static $instance = null;

    public static function init()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }

        // @NEW 2026-02-08: Register Action Scheduler hook for background processing
        add_action('vs_process_bulk_schedule', array(__CLASS__, 'process_bulk_schedule_background'));

        return self::$instance;
    }

    /**
     * Handle bulk quiz generation and job creation.
     * @MODIFIED 2026-02-08: Now schedules Action Scheduler task instead of running synchronously
     * 
     * @param string $topic Topic name
     * @param int $total_questions Total questions to generate
     * @param int $questions_per_video Questions per video
     * @param string $start_date Start date (Y-m-d H:i:s)
     * @param string $frequency Frequency (daily, every_3_days, weekly)
     * @param array $settings Template/music/background settings
     * @return array|WP_Error Array with batch_id or error
     */
    public function handle_bulk_request($topic, $total_questions, $questions_per_video, $start_date, $frequency, $settings = array())
    {
        // 1. Validate inputs
        if (empty($topic) || $total_questions < 1 || $questions_per_video < 1) {
            return new WP_Error('invalid_input', 'Topic, total questions, and questions per video are required.');
        }

        // 2. Create a unique batch ID
        $batch_id = 'batch_' . uniqid() . '_' . wp_rand(1000, 9999);

        // 3. Store batch metadata for tracking
        update_option('mcqvs_batch_' . $batch_id, array(
            'topic'                => $topic,
            'total_questions'      => $total_questions,
            'questions_per_video'  => $questions_per_video,
            'start_date'           => $start_date,
            'frequency'            => $frequency,
            'settings'             => $settings,
            'status'               => 'scheduled',
            'created_at'           => gmdate('Y-m-d H:i:s'),
        ));

        // 4. Schedule Action Scheduler task for background processing
        if (function_exists('as_schedule_single_action')) {
            as_schedule_single_action(
                time(), // Run immediately in background
                'vs_process_bulk_schedule',
                array(
                    'batch_id' => $batch_id,
                ),
                'mcq-video-studio'
            );

            return array(
                'batch_id'    => $batch_id,
                'status'      => 'scheduled',
                'message'     => 'Bulk generation scheduled. You will be notified when complete.',
            );
        } else {
            return new WP_Error('action_scheduler_missing', 'Action Scheduler not available.');
        }
    }

    /**
     * Process bulk schedule in background (called by Action Scheduler)
     * @NEW 2026-02-08: Background worker for bulk generation
     * 
     * @param string $batch_id Batch ID
     */
    public static function process_bulk_schedule_background($batch_id)
    {
        $batch_meta = get_option('mcqvs_batch_' . $batch_id);

        if (!$batch_meta) {
            error_log("VS Bulk Scheduler: Batch $batch_id not found.");
            return;
        }

        try {
            // Update status
            $batch_meta['status'] = 'processing';
            update_option('mcqvs_batch_' . $batch_id, $batch_meta);

            // Extract params
            $topic = $batch_meta['topic'];
            $total_questions = $batch_meta['total_questions'];
            $questions_per_video = $batch_meta['questions_per_video'];
            $start_date = $batch_meta['start_date'];
            $frequency = $batch_meta['frequency'];
            $settings = $batch_meta['settings'];

            error_log("VS Bulk Scheduler: Processing batch $batch_id for topic '$topic' ($total_questions Qs).");

            // 1. Generate all questions via AI (with model rotation)
            $ai_handler = VS_AJAX_AI_Quiz_Handler::get_instance();
            $context = 'bulk_' . $batch_id;
            $questions = $ai_handler->generate_topic_quiz_data($topic, $total_questions, $context);

            if (is_wp_error($questions)) {
                throw new Exception($questions->get_error_message());
            }

            // 2. Save questions to Dedicated Bank
            $repo = new VS_MCQ_Repository();
            $question_ids = array();

            // Create/get topic
            $topic_record = $repo->get_topic($topic);
            if (!$topic_record) {
                $topic_id = $repo->create_topic($topic, 'bulk_generated');
            } else {
                $topic_id = $topic_record['id'];
            }

            foreach ($questions as $q) {
                $result = $repo->insert_mcq(array(
                    'question_text' => $q['question'],
                    'options'       => wp_json_encode($q['options']),
                    'correct_index' => $q['correct'],
                    'topic_id'      => $topic_id,
                    'status'        => 'approved',
                ));

                if (!is_wp_error($result)) {
                    $question_ids[] = $result;
                }
            }

            if (empty($question_ids)) {
                throw new Exception('Failed to save questions to database.');
            }

            // 3. Split into jobs
            $job_repo = VS_Job_Repository::init();
            $batches = array_chunk($question_ids, $questions_per_video);
            $job_ids = array();

            $current_date = strtotime($start_date);
            $interval = self::get_interval_seconds($frequency);
            $parent_batch_id = $batch_id;

            $mcq_repo = VS_MCQ_Repository::get_instance();
            
            foreach ($batches as $index => $batch) {
                $job_id = $job_repo->create_job(array(
                    'topic_id'       => $topic_id,
                    'question_count' => count($batch),
                    'scheduled_at'   => gmdate('Y-m-d H:i:s'),
                    'platform'       => VS_Schema::is_valid_platform($settings['platform'] ?? 'all') ? $settings['platform'] : 'all',
                ));

                if (!is_wp_error($job_id)) {
                    $resolved_questions = array();
                    foreach ($batch as $qid) {
                        $mcqs = $mcq_repo->find(array('id' => $qid));
                        if (!empty($mcqs)) {
                            $row = $mcqs[0];
                            $resolved_questions[] = array(
                                'id'         => $row['id'],
                                'question'   => $row['question_text'],
                                'options'    => json_decode($row['options'], true),
                                'correct'    => (int) $row['correct_index'],
                                'background' => 'gradient',
                            );
                        }
                    }

                    $job_settings = wp_json_encode($settings);
                    $job_repo->update_status($job_id, VS_Job_Status::READY_FOR_RENDER, array(
                        'quiz_data'       => wp_json_encode($resolved_questions),
                        'settings'        => $job_settings,
                        'parent_batch_id' => $parent_batch_id,
                    ));

                    $job_ids[] = $job_id;
                }

                $current_date += $interval;
            }

            // 4. Update batch status
            $batch_meta['status'] = 'completed';
            $batch_meta['job_ids'] = $job_ids;
            $batch_meta['topic_id'] = $topic_id; // @NEW: Store topic ID for frontend linking
            $batch_meta['total_questions_saved'] = count($question_ids);
            $batch_meta['completed_at'] = gmdate('Y-m-d H:i:s');
            update_option('mcqvs_batch_' . $batch_id, $batch_meta);

            error_log("VS Bulk Scheduler: Batch $batch_id complete. Created " . count($job_ids) . " jobs.");
        } catch (Exception $e) {
            // Update batch status to failed
            $batch_meta['status'] = 'failed';
            $batch_meta['error'] = $e->getMessage();
            update_option('mcqvs_batch_' . $batch_id, $batch_meta);

            error_log("VS Bulk Scheduler Error: " . $e->getMessage());

            // Rethrow to let Action Scheduler handle retry
            throw $e;
        }
    }

    /**
     * Convert frequency string to seconds.
     */
    private static function get_interval_seconds($frequency)
    {
        switch ($frequency) {
            case 'daily':
                return DAY_IN_SECONDS;
            case 'every_3_days':
                return 3 * DAY_IN_SECONDS;
            case 'weekly':
                return WEEK_IN_SECONDS;
            default:
                return DAY_IN_SECONDS;
        }
    }
    /**
     * Get recent batches for Dashboard Timeline.
     * @NEW 2026-02-09
     *
     * @param int $limit
     * @return array
     */
    public static function get_recent_batches($limit = 5)
    {
        global $wpdb;

        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT option_name, option_value FROM $wpdb->options WHERE option_name LIKE %s ORDER BY option_id DESC LIMIT %d",
                'mcqvs_batch_%',
                $limit * 2 // Fetch extra to account for potential non-batch matches (unlikely but safe)
            )
        );

        $batches = array();
        foreach ($results as $row) {
            $data = maybe_unserialize($row->option_value);
            if (is_array($data) && isset($data['topic'])) {
                $data['batch_id'] = str_replace('mcqvs_batch_', '', $row->option_name);
                $batches[] = $data;
            }
        }

        usort($batches, function ($a, $b) {
            return strtotime($b['created_at'] . ' UTC') - strtotime($a['created_at'] . ' UTC');
        });

        $batches = array_slice($batches, 0, $limit);

        $stale_cutoff = strtotime('-7 days');
        if (count($results) > $limit * 2) {
            $all_batch_options = $wpdb->get_col($wpdb->prepare(
                "SELECT option_name FROM $wpdb->options WHERE option_name LIKE %s ORDER BY option_id ASC",
                'mcqvs_batch_%'
            ));
            foreach ($all_batch_options as $opt_name) {
                $opt_val = get_option($opt_name);
                if (is_array($opt_val) && isset($opt_val['created_at'])) {
                    if (strtotime($opt_val['created_at'] . ' UTC') < $stale_cutoff) {
                        delete_option($opt_name);
                    }
                }
            }
        }

        return $batches;
    }
}
