// content_ui_progress.js - Progress overlay and status display
(function() {
  'use strict';

  // Initialize Namespace
  window.ShareUnlimited = window.ShareUnlimited || {};
  window.ShareUnlimited.UI = window.ShareUnlimited.UI || {};
  
  const UI = window.ShareUnlimited.UI;
  const State = window.ShareUnlimited.State;

  /**
   * Creates and shows an animated progress overlay on the Facebook page
   */
  function createProgressOverlay() {
    // Remove any existing overlay
    const existing = document.getElementById('share-unlimited-progress-overlay');
    if (existing) existing.remove();
    
    const overlay = document.createElement('div');
    overlay.id = 'share-unlimited-progress-overlay';
    overlay.innerHTML = `
      <div class="su-overlay-content">
        <div class="su-overlay-header" id="su-drag-handle">
          <div class="su-brand">
            <div class="su-brand-icon">🚀</div>
            <span class="su-brand-text">Multiple Group Share Assistant</span>
            <span class="su-drag-hint">✋ Drag me</span>
          </div>
          <div class="su-header-buttons">
            <button class="su-minimize-btn" id="su-minimize-btn" title="Minimize">−</button>
            <button class="su-cancel-btn" id="su-cancel-share" title="Cancel">✕</button>
          </div>
        </div>
        
        <div class="su-progress-section">
          <!-- Hard requirement, not a nicety: Facebook stops rendering and stops
               responding to clicks in a hidden tab, so a backgrounded share silently
               posts to the wrong group (or the same group repeatedly). This row is
               always visible during a share and turns red the moment the tab is
               hidden — see setTabHiddenWarning(). -->
          <div class="su-tab-warning" id="su-tab-warning">
            <span class="su-tab-warning-icon">👁️</span>
            <span id="su-tab-warning-text">Keep this tab open and on screen until sharing finishes. Facebook stops responding in a background tab.</span>
          </div>

          <div class="su-current-group" id="su-current-group">
            Preparing to share...
          </div>
          
          <div class="su-progress-container">
            <div class="su-progress-bar" id="su-progress-bar">
              <div class="su-progress-fill"></div>
              <div class="su-progress-shimmer"></div>
            </div>
            <div class="su-progress-text" id="su-progress-text">0 / 0</div>
          </div>
          
          <div class="su-status-message" id="su-status-message">
            <span class="su-status-icon">⏳</span>
            <span>Starting share process...</span>
          </div>

          <div class="su-countdown-timer" id="su-countdown-timer" style="display: none;">
            <div class="su-countdown-content">
              <span>Next post in: <span class="su-countdown-time"></span>s</span>
              <button class="su-skip-btn" id="su-skip-countdown" title="Skip wait">Skip ⏭️</button>
            </div>
          </div>
        </div>
        
        <div class="su-groups-list" id="su-groups-list">
          <!-- Groups will be added here dynamically -->
        </div>
      </div>
    `;
    
    // Add styles including Select All animations
    const styles = document.createElement('style');
    styles.textContent = `
      @keyframes shimmer {
        0% {
          transform: translateX(-100%) translateY(-100%) rotate(45deg);
        }
        100% {
          transform: translateX(100%) translateY(100%) rotate(45deg);
        }
      }
      
      @keyframes selectAllPulse {
        0%, 100% {
          box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }
        50% {
          box-shadow: 0 6px 25px rgba(102, 126, 234, 0.7);
        }
      }
      
      #share-unlimited-progress-overlay {
        position: fixed;
        top: 60px;
        right: 20px;
        z-index: 999999;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
        animation: slideDown 0.4s ease-out;
      }
      
      @keyframes slideDown {
        from {
          opacity: 0;
          transform: translateX(20px) translateY(-20px);
        }
        to {
          opacity: 1;
          transform: translateX(0) translateY(0);
        }
      }
      
      .su-overlay-content {
        background: white;
        border-radius: 16px;
        box-shadow: 0 12px 40px rgba(0, 0, 0, 0.3), 0 0 0 1px rgba(0, 0, 0, 0.05);
        padding: 20px;
        min-width: 400px;
        max-width: 500px;
        backdrop-filter: blur(10px);
      }
      
      .su-overlay-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
      }
      
      .su-brand {
        display: flex;
        align-items: center;
        gap: 10px;
      }
      
      .su-brand-icon {
        font-size: 24px;
        animation: pulse 2s ease-in-out infinite;
      }
      
      @keyframes pulse {
        0%, 100% { transform: scale(1); }
        50% { transform: scale(1.1); }
      }
      
      .su-brand-text {
        font-size: 18px;
        font-weight: 700;
        color: #050505;
        text-shadow: none;
      }

      .su-drag-hint {
        font-size: 11px;
        color: #65676b;
        margin-left: 8px;
        font-weight: 400;
        opacity: 0;
        transition: opacity 0.3s;
      }
      
      #su-drag-handle {
        cursor: move;
        user-select: none;
      }
      
      #su-drag-handle:hover .su-drag-hint {
        opacity: 1;
      }
      
      .su-header-buttons {
        display: flex;
        gap: 8px;
      }
      
      .su-minimize-btn {
        background: #e4e6eb;
        border: 1px solid transparent;
        color: #050505;
        padding: 4px 12px;
        border-radius: 8px;
        font-size: 20px;
        font-weight: 400;
        cursor: pointer;
        transition: all 0.2s;
        line-height: 1;
      }
      
      .su-minimize-btn:hover {
        background: #d8dadf;
        transform: translateY(-1px);
      }

      .su-cancel-btn {
        padding: 4px 12px;
        font-size: 16px;
        line-height: 1;
        background: #e4e6eb;
        border: 1px solid transparent;
        color: #050505;
        padding: 8px 16px;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s;
      }
      
      .su-cancel-btn:hover {
        background: #d8dadf;
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
      }

      .su-progress-section {
        background: #f0f2f5;
        border-radius: 12px;
        padding: 16px;
        margin-bottom: 16px;
        backdrop-filter: blur(10px);
      }
      
      .su-current-group {
        color: #050505;
        font-size: 16px;
        font-weight: 600;
        margin-bottom: 12px;
        text-align: center;
        min-height: 24px;
        text-shadow: none;
      }
      
      .su-progress-container {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-bottom: 12px;
      }
      
      .su-progress-bar {
        flex: 1;
        height: 12px;
        background: #e4e6eb;
        border-radius: 6px;
        overflow: hidden;
        position: relative;
        box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
      }
      
      .su-progress-fill {
        height: 100%;
        background: linear-gradient(90deg, #4facfe 0%, #00f2fe 100%);
        border-radius: 6px;
        width: 0%;
        transition: width 0.5s ease-out;
        box-shadow: 0 2px 8px rgba(79, 172, 254, 0.5);
      }
      
      .su-progress-shimmer {
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.4), transparent);
        animation: shimmer 2s infinite;
      }
      
      @keyframes shimmer {
        0% { left: -100%; }
        100% { left: 100%; }
      }
      
      .su-progress-text {
        color: #050505;
        font-size: 14px;
        font-weight: 700;
        min-width: 60px;
        text-align: right;
        text-shadow: none;
      }

      .su-status-message {
        display: flex;
        align-items: center;
        gap: 8px;
        color: #65676b;
        font-size: 13px;
        justify-content: center;
      }

      .su-tab-warning {
        display: flex;
        align-items: flex-start;
        gap: 8px;
        background: #fff3cd;
        border: 1px solid #ffe08a;
        color: #7a5b00;
        border-radius: 8px;
        padding: 8px 10px;
        margin-bottom: 12px;
        font-size: 12px;
        line-height: 1.45;
        font-weight: 600;
      }

      .su-tab-warning-icon {
        font-size: 14px;
        line-height: 1.45;
        flex-shrink: 0;
      }

      /* Applied by setTabHiddenWarning() while document.visibilityState === 'hidden'.
         The user can't see it at that moment — it's there for the instant they return. */
      .su-tab-warning.su-tab-warning-active {
        background: #ffebe8;
        border-color: #e41e3f;
        color: #b3122c;
        animation: su-tab-warning-flash 1s ease-in-out infinite;
      }

      @keyframes su-tab-warning-flash {
        0%, 100% { box-shadow: 0 0 0 0 rgba(228, 30, 63, 0); }
        50%      { box-shadow: 0 0 0 4px rgba(228, 30, 63, 0.25); }
      }

      /* Applied while the run is PARKED between groups (v18.0). Deliberately calm —
         a slow breathe, not the red alarm: nothing went wrong and nothing needs
         checking, the run is simply waiting for the user to come back. */
      .su-tab-warning.su-tab-warning-paused {
        background: #fff8e1;
        border-color: #ffc107;
        color: #7a5b00;
        animation: su-tab-warning-breathe 2.4s ease-in-out infinite;
      }

      @keyframes su-tab-warning-breathe {
        0%, 100% { opacity: 1; }
        50%      { opacity: 0.72; }
      }
      
      .su-status-icon {
        font-size: 16px;
        animation: spin 2s linear infinite;
      }
  
      .su-countdown-timer {
        margin-top: 12px;
        padding: 8px;
        background: #e7f3ff;
        border-radius: 8px;
        text-align: center;
        color: #1877f2;
        font-size: 14px;
        font-weight: 500;
      }
  
      .su-countdown-content {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
      }
  
      .su-countdown-time {
        font-weight: 700;
        font-size: 16px;
      }
  
      .su-skip-btn {
        background: #1877f2;
        border: 1px solid transparent;
        color: white;
        padding: 6px 14px;
        border-radius: 6px;
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s;
        white-space: nowrap;
        flex-shrink: 0;
      }
  
      .su-skip-btn:hover {
        background: #166fe5;
        transform: translateY(-1px);
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
      }
  
      .su-skip-btn:active {
        transform: translateY(0);
      }
      
      @keyframes spin {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
      }
      
      .su-groups-list {
        background: #f0f2f5;
        border-radius: 12px;
        padding: 12px;
        max-height: 200px;
        overflow-y: auto;
        backdrop-filter: blur(10px);
      }
      
      .su-groups-list::-webkit-scrollbar {
        width: 6px;
      }
      
      .su-groups-list::-webkit-scrollbar-track {
        background: rgba(0, 0, 0, 0.05);
        border-radius: 3px;
      }

      .su-groups-list::-webkit-scrollbar-thumb {
        background: #bcc0c4;
        border-radius: 3px;
      }
      
      .su-group-item {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 8px 12px;
        margin-bottom: 6px;
        border-radius: 8px;
        transition: all 0.3s;
        color: #050505;
        font-size: 14px;
      }

      .su-group-item.pending {
        background: #ffffff;
        opacity: 0.6;
      }

      .su-group-item.active {
        background: #e7f3ff;
        border: 1px solid rgba(24, 119, 242, 0.5);
        animation: activeGlow 1.5s ease-in-out infinite;
      }
      
      @keyframes activeGlow {
        0%, 100% { box-shadow: 0 0 10px rgba(79, 172, 254, 0.3); }
        50% { box-shadow: 0 0 20px rgba(79, 172, 254, 0.6); }
      }
      
      .su-group-item.completed {
        background: rgba(66, 183, 42, 0.12);
        border: 1px solid rgba(66, 183, 42, 0.4);
      }
      
      .su-group-item.failed {
        background: rgba(228, 30, 63, 0.08);
        border: 1px solid rgba(228, 30, 63, 0.35);
      }
      
      .su-group-icon {
        font-size: 18px;
        min-width: 24px;
        text-align: center;
      }
      
      .su-group-body {
        flex: 1;
        min-width: 0;
        display: flex;
        flex-direction: column;
        gap: 5px;
      }

      .su-group-name {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .su-group-reason {
        font-size: 12px;
        color: #65676b;
        line-height: 1.4;
        white-space: normal;
      }

      .su-group-remove-btn {
        align-self: flex-start;
        background: rgba(228, 30, 63, 0.08);
        border: 1px solid rgba(228, 30, 63, 0.45);
        color: #e41e3f;
        padding: 5px 11px;
        border-radius: 6px;
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s;
        white-space: nowrap;
      }

      .su-group-remove-btn:hover:not(:disabled) {
        background: rgba(228, 30, 63, 0.16);
        transform: translateY(-1px);
      }

      .su-group-remove-btn:disabled {
        cursor: default;
      }

      .su-group-remove-btn.done {
        background: rgba(66, 183, 42, 0.12);
        border-color: rgba(66, 183, 42, 0.45);
        color: #36a420;
      }

      .su-completion-message {
        text-align: center;
        padding: 20px;
        color: #050505;
        font-size: 18px;
        font-weight: 600;
        animation: fadeIn 0.5s;
      }
      
      @keyframes fadeIn {
        from { opacity: 0; transform: scale(0.9); }
        to { opacity: 1; transform: scale(1); }
      }
      
      .su-completion-icon {
        font-size: 48px;
        margin-bottom: 12px;
        animation: bounce 0.6s;
      }
      
      @keyframes bounce {
        0%, 100% { transform: translateY(0); }
        50% { transform: translateY(-10px); }
      }
    `;
    
    document.head.appendChild(styles);
    document.body.appendChild(overlay);
    
    // Add cancel button handler
    document.getElementById('su-cancel-share').addEventListener('click', () => {
      if (confirm('Are you sure you want to cancel the sharing process?')) {
        State.shareProcessCancelled = true;
        updateProgressOverlay({
          status: '❌ Cancelled',
          message: 'Share process cancelled by user'
        });
        setTimeout(() => removeProgressOverlay(), 2000);
      }
    });
    
    // Add minimize button handler
    let isMinimized = false;
    const minimizeBtn = document.getElementById('su-minimize-btn');
    const progressSection = overlay.querySelector('.su-progress-section');
    const groupsList = overlay.querySelector('.su-groups-list');
    
    minimizeBtn.addEventListener('click', () => {
      isMinimized = !isMinimized;
      if (isMinimized) {
        progressSection.style.display = 'none';
        groupsList.style.display = 'none';
        minimizeBtn.textContent = '+';
        minimizeBtn.title = 'Restore';
      } else {
        progressSection.style.display = 'block';
        groupsList.style.display = 'block';
        minimizeBtn.textContent = '−';
        minimizeBtn.title = 'Minimize';
      }
    });
    
    // Add skip button handler
    document.addEventListener('click', (e) => {
      if (e.target && e.target.id === 'su-skip-countdown') {
        console.log('Skip button clicked');
        State.countdownSkipRequested = true;
      }
    });
    
    // Add drag functionality
    const dragHandle = document.getElementById('su-drag-handle');
    let isDragging = false;
    let currentX;
    let currentY;
    let initialX;
    let initialY;
    let xOffset = 0;
    let yOffset = 0;
    
    dragHandle.addEventListener('mousedown', dragStart);
    document.addEventListener('mousemove', drag);
    document.addEventListener('mouseup', dragEnd);
    
    function dragStart(e) {
      const transform = overlay.style.transform;
      if (transform && transform !== 'none') {
        const matrix = transform.match(/translate\((.+?)px,\s*(.+?)px\)/);
        if (matrix) {
          xOffset = parseFloat(matrix[1]);
          yOffset = parseFloat(matrix[2]);
        }
      }
      
      initialX = e.clientX - xOffset;
      initialY = e.clientY - yOffset;
      
      if (e.target === dragHandle || dragHandle.contains(e.target)) {
        if (e.target.tagName === 'BUTTON' || e.target.closest('button')) {
          return;
        }
        isDragging = true;
        dragHandle.style.cursor = 'grabbing';
      }
    }
    
    function drag(e) {
      if (isDragging) {
        e.preventDefault();
        currentX = e.clientX - initialX;
        currentY = e.clientY - initialY;
        xOffset = currentX;
        yOffset = currentY;
        
        overlay.style.transform = `translate(${currentX}px, ${currentY}px)`;
      }
    }
    
    function dragEnd() {
      if (isDragging) {
        initialX = currentX;
        initialY = currentY;
        isDragging = false;
        dragHandle.style.cursor = 'move';
      }
    }
    
    return overlay;
  }

  /**
   * Updates the progress overlay with current status
   */
  function updateProgressOverlay(data) {
    const overlay = document.getElementById('share-unlimited-progress-overlay');
    if (!overlay) return;
    
    if (data.current !== undefined && data.total !== undefined) {
      const percentage = (data.current / data.total) * 100;
      const progressFill = overlay.querySelector('.su-progress-fill');
      const progressText = overlay.querySelector('#su-progress-text');
      
      if (progressFill) progressFill.style.width = percentage + '%';
      if (progressText) progressText.textContent = `${data.current} / ${data.total}`;
    }
    
    if (data.groupName) {
      const currentGroup = overlay.querySelector('#su-current-group');
      if (currentGroup) currentGroup.textContent = `Sharing to: ${data.groupName}`;
    }
    
    if (data.status) {
      const statusMessage = overlay.querySelector('#su-status-message');
      if (statusMessage) {
        statusMessage.innerHTML = `<span class="su-status-icon">${data.status}</span><span>${data.message || ''}</span>`;
      }
    }
  }

  /**
   * Updates the countdown timer in the on-page overlay.
   */
  function updateCountdownOverlay(time) {
    const countdownTimer = document.getElementById('su-countdown-timer');
    if (!countdownTimer) return;

    if (time > 0) {
      const timeSpan = countdownTimer.querySelector('.su-countdown-time');
      countdownTimer.style.display = 'block';
      if (timeSpan) timeSpan.textContent = time;
    } else {
      countdownTimer.style.display = 'none';
    }
  }

  /**
   * Switches the always-on "keep this tab visible" row between its calm state and its
   * alarm state. Called by Core.VisibilityWatch on every visibilitychange during a share.
   * The alarm state is what the user sees the moment they come back to the tab.
   * @param {boolean} hidden - true while the tab is backgrounded.
   */
  // `mode` (v18.0) distinguishes the two very different reasons the tab can be hidden:
  //   'paused' — hidden BETWEEN groups. Nothing was in flight, the run parked itself
  //              and will resume on its own. Calm amber, no alarm.
  //   'danger' — hidden MID-GROUP. Facebook froze underneath an open composer, so the
  //              results genuinely cannot be trusted. Flashing red, as before.
  // Getting these the wrong way round would either cry wolf over a harmless pause or
  // downplay a run that needs checking, so the caller (Core.VisibilityWatch) decides —
  // this function never infers it.
  function setTabHiddenWarning(hidden, mode = 'danger') {
    const warning = document.getElementById('su-tab-warning');
    if (!warning) return;
    const text = document.getElementById('su-tab-warning-text');
    const icon = warning.querySelector('.su-tab-warning-icon');

    const paused = !!hidden && mode === 'paused';
    warning.classList.toggle('su-tab-warning-active', !!hidden && !paused);
    warning.classList.toggle('su-tab-warning-paused', paused);
    if (icon) icon.textContent = paused ? '⏸️' : (hidden ? '🛑' : '👁️');
    if (text) {
      if (paused) {
        text.textContent = 'Paused — you left this tab between groups, so nothing was ' +
          'lost. Sharing resumes by itself the moment you come back.';
      } else if (hidden) {
        text.textContent = 'You left this tab while a post was in progress. Facebook ' +
          'stopped responding, so posts may have gone to the wrong group — check your ' +
          'groups before sharing again.';
      } else {
        text.textContent = 'Keep this tab open and on screen until sharing finishes. ' +
          'Facebook stops responding in a background tab.';
      }
    }
  }

  /**
   * Initializes the groups list in the overlay
   */
  function initializeGroupsList(groupNames) {
    const groupsList = document.getElementById('su-groups-list');
    if (!groupsList) return;
    
    groupsList.innerHTML = groupNames.map((name, index) => `
      <div class="su-group-item pending" id="su-group-${index}">
        <span class="su-group-icon">⏳</span>
        <div class="su-group-body">
          <span class="su-group-name">${escapeHtml(name)}</span>
        </div>
      </div>
    `).join('');
  }

  /**
   * Updates a specific group's status in the overlay.
   * @param {number} index
   * @param {string} status - 'pending' | 'active' | 'completed' | 'failed'
   * @param {{reason?: string, removable?: boolean, groupId?: string|null,
   *          removeMode?: 'all'|'extras'}} [detail] - optional failure detail.
   *        `reason` renders as a sub-line under the group name; `removable` adds a
   *        "Remove from my saved lists" button (used for the group-not-found case).
   *        `groupId` lets that cleanup target THIS group rather than every group
   *        sharing its display name; `removeMode: 'extras'` trims redundant copies
   *        of a group instead of removing it outright (the duplicate-skip case).
   */
  function updateGroupStatus(index, status, detail = null) {
    const groupItem = document.getElementById(`su-group-${index}`);
    if (!groupItem) return;

    groupItem.className = 'su-group-item ' + status;

    if (status === 'active') {
      // Keep the in-progress group visible as the list grows past the container's
      // max-height — `block: 'nearest'` only scrolls the internal .su-groups-list
      // (the overlay itself is position:fixed, so it never touches the FB page scroll).
      groupItem.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    const icon = groupItem.querySelector('.su-group-icon');
    if (icon) {
      switch(status) {
        case 'active':
          icon.textContent = '🚀';
          break;
        case 'completed':
          icon.textContent = '✅';
          break;
        case 'failed':
          icon.textContent = '❌';
          break;
        default:
          icon.textContent = '⏳';
      }
    }

    const body = groupItem.querySelector('.su-group-body');
    if (!body) return;

    // Remove any previously-rendered failure detail (in case status changes)
    const oldExtra = body.querySelector('.su-group-extra');
    if (oldExtra) oldExtra.remove();

    if (status === 'failed' && detail && detail.reason) {
      const groupName = (groupItem.querySelector('.su-group-name')?.textContent || '').trim();
      const extra = document.createElement('div');
      extra.className = 'su-group-extra';
      extra.style.cssText = 'display:flex; flex-direction:column; gap:6px;';

      const reason = document.createElement('div');
      reason.className = 'su-group-reason';
      reason.textContent = detail.reason;
      extra.appendChild(reason);

      if (detail.removable && groupName) {
        // Tag the item so the completion screen can offer a one-click bulk cleanup even
        // after the live list is replaced. The ID rides along so the cleanup can tell
        // this group apart from another one that happens to share its display name.
        groupItem.dataset.removableGroup = groupName;
        if (detail.groupId) groupItem.dataset.removableGroupId = detail.groupId;
        const mode = detail.removeMode === 'extras' ? 'extras' : 'all';
        groupItem.dataset.removableGroupMode = mode;

        const ref = { name: groupName, id: detail.groupId || null };
        const removeBtn = document.createElement('button');
        removeBtn.className = 'su-group-remove-btn';
        removeBtn.textContent = mode === 'extras'
          ? '🗑️ Remove the duplicate from my saved lists'
          : '🗑️ Remove from my saved lists';
        removeBtn.title = mode === 'extras'
          ? `Drop the redundant copies of "${groupName}" from your presets, keeping one`
          : `Remove "${groupName}" from every preset that contains it`;
        removeBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          removeGroupsFromAllPresets(ref, removeBtn, mode);
        });
        extra.appendChild(removeBtn);
      }

      body.appendChild(extra);
    }
  }

  /**
   * Removes one or more groups from every saved preset that contains them, then
   * persists the result. Empty presets are left intact (non-destructive). Updates
   * the clicked button in place to reflect the outcome.
   *
   * Matching is by IDENTITY, not by display name (v18.2). Two groups can share a
   * name and a preset may legitimately list both, so removing "ABC" by name would
   * take the innocent twin with it. When both the target and the stored entry carry
   * a group ID, the IDs decide; name matching is the fallback for the case where
   * one side genuinely has no ID (a pre-v18.2 preset, or a group we never resolved).
   *
   * @param {string|{name:string,id?:string}|Array} groupRefs
   * @param {HTMLButtonElement} [btnEl]
   * @param {'all'|'extras'} [mode] - 'extras' keeps the first matching entry per
   *        group and drops only the redundant copies (the duplicate-skip case,
   *        where removing every copy would lose the group entirely).
   */
  function removeGroupsFromAllPresets(groupRefs, btnEl, mode = 'all') {
    // Never compare group names with bare === (v15.4 rule): FB renders apostrophes/nbsp
    // inconsistently, so match on the normalized form when the helper is available.
    const normalizeName = (window.ShareUnlimited && window.ShareUnlimited.Core && window.ShareUnlimited.Core.normalizeGroupNameForMatch)
      ? window.ShareUnlimited.Core.normalizeGroupNameForMatch
      : (s) => (s || '').trim();
    const toRef = (window.ShareUnlimited && window.ShareUnlimited.Core && window.ShareUnlimited.Core.presetGroupRef)
      ? window.ShareUnlimited.Core.presetGroupRef
      : (g) => {
          const name = (g && typeof g === 'object') ? String(g.name || '') : String(g || '');
          if (!name.trim()) return null;
          return { name: name.trim(), id: (g && typeof g === 'object' && g.id) ? String(g.id) : null };
        };

    const targets = (Array.isArray(groupRefs) ? groupRefs : [groupRefs])
      .map(toRef)
      .filter(Boolean);
    if (!targets.length) return;

    // Both identified → the IDs decide. Either side unidentified → the name is all
    // we have, so fall back to it rather than refusing to clean anything up.
    const isTarget = (entry) => {
      const ref = toRef(entry);
      if (!ref) return false;
      const n = normalizeName(ref.name);
      return targets.some(t =>
        (t.id && ref.id) ? t.id === ref.id : (!!n && n === normalizeName(t.name)));
    };
    const identity = (entry) => {
      const ref = toRef(entry);
      if (!ref) return '';
      return ref.id ? 'id:' + ref.id : 'nm:' + normalizeName(ref.name);
    };

    const idleLabel = btnEl ? btnEl.textContent : '';
    if (btnEl) {
      btnEl.disabled = true;
      btnEl.textContent = 'Removing…';
    }

    chrome.storage.local.get(['groupPresets'], (result) => {
      const presets = Array.isArray(result.groupPresets) ? result.groupPresets : [];
      let affected = 0;

      presets.forEach(preset => {
        if (!preset || !Array.isArray(preset.groups)) return;
        const before = preset.groups.length;
        const kept = new Set();
        preset.groups = preset.groups.filter(g => {
          if (!isTarget(g)) return true;
          if (mode !== 'extras') return false;
          const key = identity(g);
          if (kept.has(key)) return false;   // a redundant copy — this is the one to drop
          kept.add(key);
          return true;                       // keep the first copy
        });
        if (preset.groups.length !== before) affected++;
      });

      if (affected === 0) {
        if (btnEl) {
          btnEl.disabled = false;
          btnEl.textContent = 'ℹ️ Not in any saved list';
        }
        return;
      }

      chrome.storage.local.set({ groupPresets: presets }, () => {
        if (chrome.runtime.lastError) {
          if (btnEl) {
            btnEl.disabled = false;
            btnEl.textContent = idleLabel || '⚠️ Couldn’t save — try again';
          }
          return;
        }
        if (btnEl) {
          btnEl.disabled = true;
          btnEl.classList.add('done');
          btnEl.textContent = `✓ Removed from ${affected} saved list${affected === 1 ? '' : 's'}`;
        }
      });
    });
  }

  /** Minimal HTML escape for injecting user/group text into innerHTML strings. */
  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  /**
   * Shows completion message in the overlay
   */
  function showCompletionMessage(success, successCount, totalCount, tabWasHidden = false) {
    const overlay = document.getElementById('share-unlimited-progress-overlay');
    if (!overlay) return;

    const content = overlay.querySelector('.su-overlay-content');
    if (!content) return;

    const icon = success ? '🎉' : '⚠️';
    const message = success
      ? `Successfully shared to all ${totalCount} groups!`
      : `Shared to ${successCount} of ${totalCount} groups`;

    // Collect the groups that couldn't be found (tagged during the run) so we can offer a
    // one-click cleanup on the completion screen — the live list is about to be wiped.
    // Only the NOT-FOUND ones: a duplicate-skip is also removable, but it keeps its own
    // "drop the redundant copy" button and must never be swept up by a bulk action whose
    // copy says these groups couldn't be found.
    // Refs, not names — two different groups can share a display name, and this list is
    // what the cleanup matches on.
    const seenMissing = new Set();
    const missingGroups = Array.from(overlay.querySelectorAll('[data-removable-group]'))
      .filter(el => (el.dataset.removableGroupMode || 'all') === 'all')
      .map(el => ({ name: el.dataset.removableGroup, id: el.dataset.removableGroupId || null }))
      .filter(ref => {
        if (!ref.name) return false;
        const key = ref.id ? 'id:' + ref.id : 'nm:' + ref.name.trim().toLowerCase();
        if (seenMissing.has(key)) return false;
        seenMissing.add(key);
        return true;
      });

    const missingBlock = missingGroups.length ? `
        <div style="background: rgba(228,30,63,0.08); border:1px solid rgba(228,30,63,0.35); border-radius:10px; padding:12px 14px; margin:0 0 16px; text-align:left;">
          <div style="font-size:13px; font-weight:700; color:#e41e3f; margin-bottom:6px;">
            ⚠️ ${missingGroups.length} group${missingGroups.length === 1 ? '' : 's'} couldn’t be found
          </div>
          <div style="font-size:12px; color:#65676b; line-height:1.45; margin-bottom:10px;">
            They may have changed names, or you’re signed in to a profile that isn’t a member. Remove them so they stop clogging your saved lists.
          </div>
          <div style="max-height:90px; overflow-y:auto; margin-bottom:10px;">
            ${missingGroups.map(ref => `<div style="font-size:12px; color:#050505; padding:2px 0;">• ${escapeHtml(ref.name)}</div>`).join('')}
          </div>
          <button id="su-remove-missing-btn" class="su-group-remove-btn" style="width:100%; white-space:normal;">
            🗑️ Remove ${missingGroups.length === 1 ? 'it' : `all ${missingGroups.length}`} from my saved lists
          </button>
        </div>
    ` : '';

    // The tab went to the background at some point during this run. Facebook stops
    // rendering and stops responding to clicks while hidden, so the per-group results
    // above cannot be trusted — say so plainly instead of showing a clean green tick.
    const hiddenBlock = tabWasHidden ? `
        <div style="background: rgba(228,30,63,0.08); border:1px solid rgba(228,30,63,0.35); border-radius:10px; padding:12px 14px; margin:0 0 16px; text-align:left;">
          <div style="font-size:13px; font-weight:700; color:#e41e3f; margin-bottom:6px;">
            🛑 You switched away from this tab
          </div>
          <div style="font-size:12px; color:#65676b; line-height:1.45;">
            Facebook stops responding while its tab is hidden, so some posts may have gone to the wrong group or to the same group more than once. <strong>Check these groups on Facebook before sharing again</strong>, and keep this tab on screen for the whole run next time.
          </div>
        </div>
    ` : '';

    content.innerHTML = `
      <div class="su-completion-message">
        <div class="su-completion-icon">${tabWasHidden ? '🛑' : icon}</div>
        <div style="font-size:16px; font-weight:700; margin-bottom:10px;">${message}</div>
        <div style="font-size:13px; color:#65676b; margin-bottom:18px; line-height:1.5;">
          If you have more work,<br>please refresh the page to start your next sharing job.
        </div>
        ${hiddenBlock}
        ${missingBlock}
        <button id="su-refresh-btn" style="
          background: #1877f2;
          border: none;
          color: white;
          padding: 10px 28px;
          border-radius: 8px;
          font-size: 14px;
          font-weight: 700;
          cursor: pointer;
          margin-bottom: 8px;
          width: 100%;
          transition: background 0.2s;
        ">🔄 Refresh Page</button>
        <button id="su-close-btn" style="
          background: #e4e6eb;
          border: 1px solid transparent;
          color: #050505;
          padding: 7px 20px;
          border-radius: 8px;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          width: 100%;
          transition: background 0.2s;
        ">Close</button>
      </div>
    `;

    const refreshBtn = content.querySelector('#su-refresh-btn');
    const closeBtn = content.querySelector('#su-close-btn');
    const removeMissingBtn = content.querySelector('#su-remove-missing-btn');

    if (removeMissingBtn) {
      removeMissingBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        removeGroupsFromAllPresets(missingGroups, removeMissingBtn);
      });
    }

    refreshBtn.addEventListener('mouseenter', () => { refreshBtn.style.background = '#166fe5'; });
    refreshBtn.addEventListener('mouseleave', () => { refreshBtn.style.background = '#1877f2'; });
    refreshBtn.addEventListener('click', () => { location.reload(); });

    closeBtn.addEventListener('mouseenter', () => { closeBtn.style.background = '#d8dadf'; });
    closeBtn.addEventListener('mouseleave', () => { closeBtn.style.background = '#e4e6eb'; });
    closeBtn.addEventListener('click', () => removeProgressOverlay());
  }

  /**
   * Removes the progress overlay
   */
  function removeProgressOverlay() {
    const overlay = document.getElementById('share-unlimited-progress-overlay');
    if (overlay) {
      overlay.style.animation = 'slideDown 0.3s ease-out reverse';
      setTimeout(() => overlay.remove(), 300);
    }
  }

  // Export functions
  Object.assign(UI, {
    createProgressOverlay,
    updateProgressOverlay,
    updateCountdownOverlay,
    setTabHiddenWarning,
    initializeGroupsList,
    updateGroupStatus,
    showCompletionMessage,
    removeProgressOverlay
  });

})();
