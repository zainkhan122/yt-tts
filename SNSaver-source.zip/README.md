# SNSaver

A production-structured Android app for saving permitted social-media media through a configurable Cobalt-compatible extractor.

## Stack
Kotlin, Jetpack Compose, Material 3, Room, WorkManager, Hilt, DataStore, OkHttp, Jsoup, Coil, MediaStore.

## Open and run
1. Open this directory in Android Studio Ladybug or newer.
2. Use JDK 17 and install Android SDK 35.
3. Sync Gradle and run the `app` configuration on Android 8.0+.
4. In **Settings**, configure a Cobalt-compatible endpoint and API key if required by that instance.

The default public endpoint can change its authentication or availability policy. For a reliable release, use an endpoint you operate or are authorized to use.

## Main flow
Share a text link to SNSaver or copy it and tap **Paste link**. WorkManager extracts and downloads in the background, Room drives the reactive inbox/gallery, and MediaStore optionally creates a Gallery copy.

## Release checklist
- Replace the sample launcher artwork with final brand assets.
- Configure a private signing key outside source control.
- Add a privacy policy and store disclosures.
- Confirm extractor terms, platform terms, and local copyright requirements.
- Add analytics/crash reporting only with appropriate consent.
- Test real links from each claimed platform against your chosen Cobalt version.

## Build
```bash
./gradlew assembleDebug
./gradlew lint
./gradlew test
```
