/**
 * NM Timeline Controller
 * Manages video timeline, seeking, and scrubbing
 *
 * @package WP_News_MCQ_Generator
 * @version 1.0.0
 */

(function (window) {
  "use strict";

  class MCQVS_Timeline {
    /**
     * @param {Object} options
     * @param {number} options.fps - Video framerate (default 30)
     * @param {Function} options.onSeek - Callback when timeline position changes
     */
    constructor(options = {}) {
      this.fps = options.fps || 30;
      this.onSeek = options.onSeek || null;
      this.totalDuration = 0; // ms
      this.currentTime = 0; // ms
      this.isPlaying = false;
      this._timer = null;
    }

    /**
     * Set the total duration of the timeline
     * @param {number} durationMs
     */
    setDuration(durationMs) {
      this.totalDuration = durationMs;
    }

    /**
     * Seek to a specific time
     * @param {number} timeMs
     */
    seek(timeMs) {
      this.currentTime = Math.max(0, Math.min(timeMs, this.totalDuration));
      if (this.onSeek) {
        this.onSeek(this.currentTime);
      }
    }

    /**
     * Scrub via normalized position (0-1)
     * @param {number} ratio
     */
    scrub(ratio) {
      this.seek(this.totalDuration * ratio);
    }

    /**
     * Get human-readable time string (MM:SS)
     * @param {number} ms
     * @returns {string}
     */
    formatTime(ms) {
      const totalSeconds = Math.floor(ms / 1000);
      const minutes = Math.floor(totalSeconds / 60);
      const seconds = totalSeconds % 60;
      return `${minutes.toString().padStart(2, "0")}:${seconds
        .toString()
        .padStart(2, "0")}`;
    }

    /**
     * Get current progress (0-1)
     */
    getProgress() {
      if (this.totalDuration === 0) return 0;
      return this.currentTime / this.totalDuration;
    }

    /**
     * @NEW 2025-12-18: Render a reactive waveform on the timeline
     * @param {CanvasRenderingContext2D} ctx
     * @param {number} width, height
     */
    renderWaveform(ctx, width, height) {
      ctx.save();
      const barWidth = 4;
      const spacing = 2;
      const bars = Math.floor(width / (barWidth + spacing));

      // Use pre-calculated peaks or fallback to deterministic pseudo-random
      const peaks = this.peaks || [];

      for (let i = 0; i < bars; i++) {
        let h;
        if (peaks.length > 0) {
          const peakIdx = Math.floor((i / bars) * peaks.length);
          h = height * (peaks[peakIdx] || 0.1);
        } else {
          // Deterministic Pseudo-random fallback (sine-based)
          h =
            height * (0.3 + Math.sin(i * 0.2) * 0.2 + Math.cos(i * 0.5) * 0.1);
        }

        const isPlayed = i / bars < this.getProgress();
        ctx.fillStyle = isPlayed
          ? "rgba(40, 150, 255, 0.8)"
          : "rgba(40, 150, 255, 0.2)";
        ctx.fillRect(i * (barWidth + spacing), (height - h) / 2, barWidth, h);
      }
      ctx.restore();
    }

    /**
     * @NEW 2025-12-18: Generate peaks from an AudioBuffer for reactive visuals
     */
    async generatePeaks(audioBuffer, samples = 200) {
      const channelData = audioBuffer.getChannelData(0);
      const step = Math.floor(channelData.length / samples);
      const peaks = [];

      for (let i = 0; i < samples; i++) {
        let max = 0;
        for (let j = 0; j < step; j++) {
          const val = Math.abs(channelData[i * step + j]);
          if (val > max) max = val;
        }
        peaks.push(max);
      }
      this.peaks = peaks;
      console.log("[NM Timeline] Peaks generated:", samples);
    }

    /**
     * Get current frame number
     */
    getCurrentFrame() {
      return Math.floor((this.currentTime / 1000) * this.fps);
    }

    /**
     * @NEW 2025-12-18: Set markers for question boundaries
     * @param {Array} times - Array of marker times in ms
     */
    setMarkers(times) {
      this.markers = times;
    }
  }

  window.MCQVS_Timeline = MCQVS_Timeline;
})(window);
