<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Contracts\VerificationProviderInterface;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class GoogleVisionVerificationProvider implements VerificationProviderInterface {

    private $api_key;

    public function __construct( string $api_key = '' ) {
        $this->api_key = $api_key;
    }

    public function get_provider_name(): string {
        return Config::PROVIDER_VERIFICATION_GOOGLE;
    }

    public function get_model_name(): string {
        return 'google-vision-ocr';
    }

    public function is_available(): bool {
        return ! empty( $this->api_key );
    }

    public function get_cost_estimate( int $image_count = 1 ): float {
        $cost_per_image = 1.50;
        return $cost_per_image * $image_count;
    }

    public function analyze_image( string $image_path, string $prompt, array $options = [] ): array {
        if ( ! file_exists( $image_path ) ) {
            throw new \Exception( 'Image file not found: ' . $image_path );
        }

        $api_url = "https://vision.googleapis.com/v1/images:annotate?key=" . urlencode( $this->api_key );
        
        $image_data = file_get_contents( $image_path );
        if ( ! $image_data ) {
            throw new \Exception( 'Failed to read image: ' . $image_path );
        }

        $payload = [
            'requests' => [
                [
                    'image' => [
                        'content' => base64_encode( $image_data ),
                    ],
                    'features' => [
                        [ 'type' => 'TEXT_DETECTION', 'maxResults' => 100 ],
                        [ 'type' => 'OBJECT_LOCALIZATION', 'maxResults' => 20 ],
                    ],
                ],
            ],
        ];

        $response = wp_remote_post( $api_url, [
            'timeout' => 60,
            'headers' => [ 'Content-Type' => 'application/json' ],
            'body' => wp_json_encode( $payload ),
        ] );

        if ( is_wp_error( $response ) ) {
            throw new \Exception( 'Google Vision API error: ' . $response->get_error_message() );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );

        if ( $code !== 200 ) {
            throw new \Exception( "Google Vision API returned HTTP {$code}: " . mb_substr( $body, 0, 500 ) );
        }

        $result = json_decode( $body, true );
        return $this->parse_result( $result, $options );
    }

    private function parse_result( array $result, array $options ): array {
        $texts = [];
        $full_text = '';
        
        if ( isset( $result['responses'][0]['fullTextAnnotation']['text'] ) ) {
            $full_text = $result['responses'][0]['fullTextAnnotation']['text'];
        }

        $objects = [];
        if ( isset( $result['responses'][0]['localizedObjectAnnotations'] ) ) {
            $objects = $result['responses'][0]['localizedObjectAnnotations'];
        }

        return [
            'text' => $full_text,
            'objects' => $objects,
            'clean' => empty( $options['expected_text'] ) || ! $this->contains_text( $full_text, $options['expected_text'] ),
            'confidence' => 0.90,
            'provider' => $this->get_provider_name(),
            'model' => $this->get_model_name(),
        ];
    }

    private function contains_text( string $haystack, string $needle ): bool {
        similar_text( strtolower( $haystack ), strtolower( $needle ), $percent );
        return $percent > 70;
    }
}