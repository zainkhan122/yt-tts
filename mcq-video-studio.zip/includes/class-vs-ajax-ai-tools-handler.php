<?php

/**
 * AJAX Handler for AI Tools (Hooks, SEO, Backgrounds)
 *
 * @package MCQ_Video_Studio
 */

if (! defined('ABSPATH')) {
    exit;
}

class VS_AJAX_AI_Tools_Handler
{

    private static $instance = null;

    public static function get_instance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * @NEW 2026-02-18: Get Authoritative Working Model
     * @MODIFIED 2026-06-26: Route through the active AI provider.
     *                      Falls back to Gemini classic endpoint if no provider is selected.
     */
    private function get_working_model()
    {
        $active = get_option('mcqvs_api_provider', 'gemini');
        if (class_exists('VS_Provider_Registry') && !empty($active)) {
            try {
                return VS_Provider_Registry::get_instance()->get_working_model($active);
            } catch (\Exception $e) {
                // keep legacy Gemini fallback
            }
        }
        return get_option('mcqvs_gemini_model_id', 'gemini-3-flash-preview');
    }

    /**
     * @NEW 2026-02-18: Independent Key Logic (Local > Parent)
     */
    private function get_api_key()
    {
        $api_key = get_option('mcqvs_gemini_api_key', '');
        if (empty($api_key)) {
            $api_key = get_option('nm_gemini_api_key', '');
        }
        return $api_key;
    }

    /**
     * AJAX: Generate Viral Hooks
     */
    public function ajax_generate_hooks()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error(__('Access denied', 'mcq-video-studio'));
        }

        // @NEW 2026-02-25: Short transient lock to prevent duplicate background jobs
        $lock_key = 'mcqvs_ai_bg_lock_' . md5($_POST['prompt'] ?? '');
        if (get_transient($lock_key)) {
            wp_send_json_error(__('Background generation already in progress. Please wait.', 'mcq-video-studio'));
        }
        set_transient($lock_key, 1, 15);

        $topic          = sanitize_text_field($_POST['topic'] ?? '');
        $question_count = absint($_POST['question_count'] ?? 5);
        // @NEW 2026-08-11: Accept the actual quiz questions (JSON array of {question})
        //       so the hooks reference the most surprising fact instead of the topic name.
        $questions_raw  = isset($_POST['questions']) ? wp_unslash($_POST['questions']) : '';
        $questions_ctx  = '';
        if (is_string($questions_raw) && $questions_raw !== '') {
            $qarr = json_decode($questions_raw, true);
            if (is_array($qarr)) {
                $lines = array();
                foreach (array_slice($qarr, 0, 8) as $qi => $qq) {
                    $qtxt = is_array($qq) ? (string) ($qq['question'] ?? '') : (string) $qq;
                    if ($qtxt !== '') $lines[] = ($qi + 1) . '. ' . $qtxt;
                }
                if (!empty($lines)) $questions_ctx = implode("\n", $lines);
            }
        }

        $registry = class_exists('VS_Provider_Registry') ? VS_Provider_Registry::get_instance() : null;

        if ($registry) {
            $rotation = $registry->get_next_model('hooks');
            $active_provider = $rotation['provider'];
            $model = $rotation['model'];
            $api_key = $registry->get_rotation_api_key($active_provider);
        } else {
            $active_provider = 'gemini';
            $model = get_option('mcqvs_gemini_model_id', 'gemini-3-flash-preview');
            $api_key = $this->get_api_key();
        }

        if (empty($api_key)) {
            $defaults = array(
                "Can you score $question_count/$question_count?",
                'Only 1% get this right!',
                'Test your knowledge NOW!',
                'Are you a GENIUS?',
                'Most people FAIL this quiz!',
            );
            wp_send_json_success(array('hooks' => $defaults, 'source' => 'fallback'));
        }

        $prompt = "You are a viral-shorts copywriter. Generate 5 high-retention hook texts for a $question_count-question quiz about \"$topic\".\n";
        if ($questions_ctx !== '') {
            $prompt .= "The quiz questions are:\n{$questions_ctx}\n";
        }
        $prompt .= "Use modern social media psychology frameworks: Curiosity Gaps, Negative Constraints, Specific Stakes.\n"
            . "Each hook: max 8 words, ONE relevant emoji at the start, derived from the MOST surprising question or fact above (never generic, never spoiling the answer).\n"
            . "Return ONLY a JSON array of strings: [\"hook1\", \"hook2\", \"hook3\", \"hook4\", \"hook5\"]";

        $url = $registry ? $registry->build_rotation_url($active_provider, $model) : "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key=" . $api_key;
        if ($registry) {
            $request_body = $registry->build_request_body(
                $active_provider,
                array(array('role' => 'user', 'content' => $prompt)),
                $model,
                array('json_mode' => true)
            );
        } else {
            $request_body = array('contents' => array(array('parts' => array(array('text' => $prompt)))));
        }
        $post_args = array(
            'body'    => json_encode($request_body),
            'timeout' => 15,
        );
        if ($registry) {
            $post_args['headers'] = $registry->build_rotation_headers($active_provider, $url);
        } else {
            $post_args['headers'] = array('Content-Type' => 'application/json');
        }
        $start_time = microtime(true);
        $response = wp_remote_post($url, $post_args);
        $duration = microtime(true) - $start_time;

        // @NEW 2026-01-09: Central API Logging
        VS_Error_Logger::get_instance()->log_api($url, 'POST', array('prompt' => $prompt), $response, $duration);

        if (is_wp_error($response)) {
            wp_send_json_success(array('hooks' => array("Can you score $question_count/$question_count?", 'Only 1% get this right!'), 'source' => 'fallback'));
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        $raw_text = '';
        if (isset($body['candidates'][0]['content']['parts'][0]['text'])) {
            $raw_text = $body['candidates'][0]['content']['parts'][0]['text'];
        } elseif (isset($body['choices'][0]['message']['content'])) {
            $raw_text = $body['choices'][0]['message']['content'];
        }
        if (empty($raw_text) && $registry) {
            $raw_text = $registry->extract_content($active_provider, $body);
        }
        $json_text = preg_replace('/```(json)?/', '', $raw_text);
        $hooks = json_decode(trim($json_text), true);

        if (! $hooks || ! is_array($hooks)) {
            wp_send_json_success(array('hooks' => array('Are you a GENIUS?', 'Most people FAIL this quiz!'), 'source' => 'fallback'));
        }

        wp_send_json_success(array('hooks' => $hooks, 'source' => 'ai'));
    }

    /**
     * AJAX: Generate SEO Metadata
     */
    public function ajax_generate_seo()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error(__('Access denied', 'mcq-video-studio'));
        }

        $prompt  = isset($_POST['prompt']) ? sanitize_textarea_field(wp_unslash($_POST['prompt'])) : '';

        $registry = class_exists('VS_Provider_Registry') ? VS_Provider_Registry::get_instance() : null;

        if ($registry) {
            $rotation = $registry->get_next_model('seo');
            $active_provider = $rotation['provider'];
            $model = $rotation['model'];
            $api_key = $registry->get_rotation_api_key($active_provider);
        } else {
            $active_provider = 'gemini';
            $model = get_option('mcqvs_gemini_model_id', 'gemini-3-flash-preview');
            $api_key = $this->get_api_key();
        }

        if (strlen($prompt) > 30000) {
            wp_send_json_error(__('Prompt too large for AI processing.', 'mcq-video-studio'));
        }

        $seo_lock = 'mcqvs_seo_lock_' . md5($prompt);
        if (get_transient($seo_lock)) {
            wp_send_json_error(__('SEO generation already in progress. Please wait.', 'mcq-video-studio'));
        }
        set_transient($seo_lock, 1, 10);

        if (empty($api_key)) {
            delete_transient($seo_lock);
            wp_send_json_success(array(
                'title'       => 'Only 1% Can Pass This! 🧠',
                'description' => 'Test your knowledge with these impossible questions!',
                'tags'        => array('#quiz', '#trivia', '#viral'),
                'source'      => 'fallback',
            ));
        }

        $url = $registry ? $registry->build_rotation_url($active_provider, $model) : "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key=" . $api_key;
        if ($registry) {
            $request_body = $registry->build_request_body(
                $active_provider,
                array(array('role' => 'user', 'content' => $prompt)),
                $model,
                array('json_mode' => true)
            );
        } else {
            $request_body = array('contents' => array(array('parts' => array(array('text' => $prompt)))));
        }
        $post_args = array(
            'body'    => json_encode($request_body),
            'timeout' => 20,
        );
        if ($registry) {
            $post_args['headers'] = $registry->build_rotation_headers($active_provider, $url);
        } else {
            $post_args['headers'] = array('Content-Type' => 'application/json');
        }
        $start_time = microtime(true);
        $response = wp_remote_post($url, $post_args);
        $duration = microtime(true) - $start_time;

        // @NEW 2026-01-09: Central API Logging
        VS_Error_Logger::get_instance()->log_api($url, 'POST', array('prompt' => $prompt), $response, $duration);

        if (is_wp_error($response)) {
            delete_transient($seo_lock);
            wp_send_json_success(array('title' => 'Quiz Challenge! 🔥', 'tags' => array('#quiz'), 'source' => 'fallback'));
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        $raw_text = '';
        if (isset($body['candidates'][0]['content']['parts'][0]['text'])) {
            $raw_text = $body['candidates'][0]['content']['parts'][0]['text'];
        } elseif (isset($body['choices'][0]['message']['content'])) {
            $raw_text = $body['choices'][0]['message']['content'];
        }
        if (empty($raw_text) && $registry) {
            $raw_text = $registry->extract_content($active_provider, $body);
        }
        $json_text = preg_replace('/```(json)?/', '', $raw_text);
        $result = json_decode(trim($json_text), true);

        if (! $result || ! is_array($result)) {
            delete_transient($seo_lock);
            wp_send_json_success(array('title' => 'Quiz Time! 🎯', 'tags' => array('#trivia'), 'source' => 'fallback'));
        }

        delete_transient($seo_lock);
        wp_send_json_success(array_merge($result, array('source' => 'ai')));
    }

}
