<?php
/**
 * Comprehensive Title Matching System Test
 *
 * Tests the complete title-matching pipeline across:
 * - Title_Analyzer::extract() — name/version extraction
 * - Similarity_Helper::match_result() — fuzzy matching + year conflict
 * - DB_Post_Finder::find_exact_match() — SQL matching strategies
 * - Discovery_Engine::find_existing_software() — tiered matching
 *
 * Validates coherence, single-source-of-truth, and absence of contradictions
 * between the 4 modified files.
 *
 * @package SEO_Article_Generator\Tests
 */

namespace {
    if (!defined('ABSPATH')) {
        define('ABSPATH', dirname(__DIR__) . '/');
    }
    if (!defined('WP_DEBUG')) {
        define('WP_DEBUG', true);
    }

    // Minimal WordPress stubs for isolated testing
    if (!function_exists('sanitize_title')) {
        function sanitize_title($title) {
            $title = strtolower(trim($title));
            $title = preg_replace('/[^a-z0-9\-]/', '-', $title);
            $title = preg_replace('/-+/', '-', $title);
            return trim($title, '-');
        }
    }
    if (!function_exists('sanitize_text_field')) {
        function sanitize_text_field($str) { return trim(strip_tags($str)); }
    }
}

namespace SEO_Article_Generator\Tests {

    require_once dirname(__DIR__) . '/includes/discovery/class-title-analyzer.php';
    require_once dirname(__DIR__) . '/includes/discovery/class-similarity-helper.php';

    use SEO_Article_Generator\Discovery\Title_Analyzer;
    use SEO_Article_Generator\Discovery\Similarity_Helper;

    class TitleMatchingSystemTest
    {
        private Title_Analyzer $analyzer;
        private int $passed = 0;
        private int $failed = 0;
        private array $failures = [];

        public function __construct()
        {
            $this->analyzer = new Title_Analyzer();
        }

        // =====================================================================
        // TEST RUNNER
        // =====================================================================

        public function run(): void
        {
            echo "==========================================================\n";
            echo " TITLE MATCHING SYSTEM — COMPREHENSIVE TEST SUITE\n";
            echo "==========================================================\n\n";

            $this->test_xml_titles_extraction();
            $this->test_year_in_name_products();
            $this->test_year_plus_build();
            $this->test_dotted_product_names();
            $this->test_multi_version_slash_titles();
            $this->test_single_word_names();
            $this->test_complex_version_formats();
            $this->test_v_prefix_versions();
            $this->test_special_char_products();
            $this->test_number_is_name_products();
            $this->test_edition_qualifiers();
            $this->test_browser_style_versions();
            $this->test_date_based_versions();
            $this->test_trailing_noise_stripping();
            $this->test_similarity_helper_consistency();
            $this->test_year_conflict_detection();
            $this->test_cross_file_normalization_coherence();
            $this->test_aggressive_extract_fallback();
            $this->test_clean_name_year_stripping_rules();
            $this->test_version_comparison();

            echo "\n==========================================================\n";
            echo " RESULTS: {$this->passed} PASSED, {$this->failed} FAILED\n";
            echo "==========================================================\n";

            if (!empty($this->failures)) {
                echo "\nFAILURES:\n";
                echo str_repeat('-', 60) . "\n";
                foreach ($this->failures as $i => $f) {
                    echo sprintf("[%d] %s\n    Input: %s\n    Expected: %s\n    Got: %s\n\n",
                        $i + 1, $f['test'], $f['input'], $f['expected'], $f['actual']
                    );
                }
            }

            // Exit with appropriate code
            exit($this->failed > 0 ? 1 : 0);
        }

        // =====================================================================
        // ASSERTION HELPERS
        // =====================================================================

        private function assertExtract(string $title, string $expectedName, string $expectedVersion, string $context = ''): void
        {
            $result = $this->analyzer->extract($title);
            $actualName = $result ? $result['name'] : '(false)';
            $actualVer = $result ? $result['version'] : '(false)';

            $nameOk = (strtolower(trim($actualName)) === strtolower(trim($expectedName)));
            $verOk = (strtolower(trim($actualVer)) === strtolower(trim($expectedVersion)));

            if ($nameOk && $verOk) {
                $this->passed++;
            } else {
                $this->failed++;
                $this->failures[] = [
                    'test' => $context ?: 'extract()',
                    'input' => $title,
                    'expected' => "name=\"{$expectedName}\", version=\"{$expectedVersion}\"",
                    'actual' => "name=\"{$actualName}\", version=\"{$actualVer}\"",
                ];
            }
        }

        private function assertSimilaritySafe(string $a, string $b, bool $expectSafe, string $context = ''): void
        {
            $result = Similarity_Helper::match_result($a, $b);
            if ($result['safe'] === $expectSafe) {
                $this->passed++;
            } else {
                $this->failed++;
                $this->failures[] = [
                    'test' => $context ?: 'match_result()',
                    'input' => "\"{$a}\" vs \"{$b}\"",
                    'expected' => $expectSafe ? 'safe=true' : 'safe=false',
                    'actual' => sprintf('safe=%s (score=%.4f, label=%s)', $result['safe'] ? 'true' : 'false', $result['score'], $result['label']),
                ];
            }
        }

        private function assertVersionNewer(string $new, string $old, bool $expected, string $context = ''): void
        {
            $actual = Title_Analyzer::is_newer_version($new, $old);
            if ($actual === $expected) {
                $this->passed++;
            } else {
                $this->failed++;
                $this->failures[] = [
                    'test' => $context ?: 'is_newer_version()',
                    'input' => "new=\"{$new}\" vs old=\"{$old}\"",
                    'expected' => $expected ? 'true (is newer)' : 'false (not newer)',
                    'actual' => $actual ? 'true' : 'false',
                ];
            }
        }

        // =====================================================================
        // TEST: REAL XML TITLES FROM softwarewave.WordPress.2026-03-15.xml
        // =====================================================================

        private function test_xml_titles_extraction(): void
        {
            echo "--- Test: Real XML Titles Extraction ---\n";

            // Critical: Year + Build (Bug #1 scenario)
            $this->assertExtract(
                'VirtualDJ 2026 Build 8985 Stable – Free Download',
                'VirtualDJ 2026', 'Build 8985',
                'XML: VirtualDJ year+build'
            );

            // MemTest86 — number is build, not version pattern
            $this->assertExtract(
                'MemTest86 11.6 Build 1000 - Free Download UEFI Memory Diagnostic',
                'MemTest86', '11.6 Build 1000',
                'XML: MemTest86 dotted+build'
            );

            // IObit Smart Defrag — dotted version with "Final"
            $this->assertExtract(
                'IObit Smart Defrag 11.2.0.472 Final – Free Efficient Disc Defragmentation',
                'IObit Smart Defrag', '11.2.0.472',
                'XML: IObit dotted version'
            );

            // GOM Player+ — special char in name
            $this->assertExtract(
                'GOM Player+ 24.0.9.14769 - Powerful AI Multimedia Experience',
                'GOM Player+', '24.0.9.14769',
                'XML: GOM Player+ with special char'
            );

            // VideoProc Converter AI — product with "AI" in name
            $this->assertExtract(
                'VideoProc Converter AI 8.7 Download for Windows & macOS',
                'VideoProc Converter AI', '8.7',
                'XML: VideoProc Converter AI'
            );

            // BlueStacks X — year after name
            $this->assertExtract(
                'BlueStacks X 5.22 2026 - Free Android Emulator for PC',
                'BlueStacks X', '5.22',
                'XML: BlueStacks with trailing year'
            );

            // Adobe Premiere Pro 2026 — year is product identity
            $this->assertExtract(
                'Adobe Premiere Pro 2026 26.0 Download for Windows',
                'Adobe Premiere Pro 2026', '26.0',
                'XML: Adobe Premiere Pro 2026'
            );

            // draw.io Desktop — dotted name with version
            $this->assertExtract(
                'draw.io Desktop download - Latest Version 29.3.0 for Windows',
                'draw.io Desktop', '29.3.0',
                'XML: draw.io dotted name'
            );

            // R-Studio — hyphenated name with build
            $this->assertExtract(
                'R-Studio 9.5 Build 191683 - Complete Data Recovery',
                'R-Studio', '9.5 Build 191683',
                'XML: R-Studio with Build'
            );

            // Internet Download Manager — multi-word with Build
            $this->assertExtract(
                'Internet Download Manager (IDM) 6.42 Build 60 for Windows',
                'Internet Download Manager (IDM)', '6.42 Build 60',
                'XML: IDM with parenthetical and Build'
            );

            // Opera — high build number
            $this->assertExtract(
                'Opera 127.0 Build 5778.64 Free Browser with AI & VPN',
                'Opera', '127.0 Build 5778.64',
                'XML: Opera high build number'
            );

            // Google Chrome — browser-style version
            $this->assertExtract(
                'Google Chrome 145.0.7632.76 Free Download for Windows, Mac, Linux & Mobile',
                'Google Chrome', '145.0.7632.76',
                'XML: Chrome browser version'
            );

            // Mozilla Firefox — standard dotted
            $this->assertExtract(
                'Download Mozilla Firefox 147.0.3 - Fast, Private, and Open Source Web Browser',
                'Mozilla Firefox', '147.0.3',
                'XML: Firefox with leading "Download"'
            );

            // KMPlayer — date-based version
            $this->assertExtract(
                'KMPlayer 2026.1.26.43 Free Download for Windows, macOS, Android & iOS',
                'KMPlayer', '2026.1.26.43',
                'XML: KMPlayer date-based version'
            );

            // PotPlayer — date-based version
            $this->assertExtract(
                'PotPlayer 26.1.15 Download for Windows: Free Multimedia Player',
                'PotPlayer', '26.1.15',
                'XML: PotPlayer date-based'
            );

            // Nero Burning ROM — year + dotted
            $this->assertExtract(
                'Nero Burning ROM 2026 28.5.1050 Free Download for Windows',
                'Nero Burning ROM 2026', '28.5.1050',
                'XML: Nero year + version'
            );

            // Ashampoo Burning Studio 2026 — year IS the version
            $this->assertExtract(
                'Ashampoo Burning Studio 2026 for Windows – Free Disc Burning Suite',
                'Ashampoo Burning Studio 2026', 'Unknown',
                'XML: Ashampoo year-only product'
            );

            // Wine — multi-version slash
            $this->assertExtract(
                'Wine 11.0 - Free Download for Linux, macOS, and BSD - Compatibility Layer',
                'Wine', '11.0',
                'XML: Wine single version'
            );

            // Rufus — with Build
            $this->assertExtract(
                'Rufus 4.13 Build 2316 Free Download for Windows: Bootable USB Creator Utility',
                'Rufus', '4.13 Build 2316',
                'XML: Rufus with Build'
            );

            // Adobe InDesign — year + build keyword
            $this->assertExtract(
                'Adobe InDesign 2026 Build 21.2 Download for Windows: Desktop Publishing Software',
                'Adobe InDesign 2026', 'Build 21.2',
                'XML: Adobe InDesign year+build'
            );

            // Free Download Manager — number at end
            $this->assertExtract(
                'Free Download Manager 6.33.1 Build 6644 - Best IDM Alternative',
                'Free Download Manager', '6.33.1 Build 6644',
                'XML: FDM with Build'
            );

            // 3uTools — number starts name
            $this->assertExtract(
                '3uTools 9.02.025 Free Download for Windows and macOS',
                '3uTools', '9.02.025',
                'XML: 3uTools number-prefixed name'
            );

            // xplorer² — special char in name
            $this->assertExtract(
                'xplorer² 6.3.0.0 - Exceptional File and Information Manager',
                'xplorer²', '6.3.0.0',
                'XML: xplorer² special char'
            );

            // Hitman Pro — with Build and Final
            $this->assertExtract(
                'Hitman Pro 3.8.50 Build 346 Final Download for Windows',
                'Hitman Pro', '3.8.50 Build 346',
                'XML: Hitman Pro version+build'
            );

            // HopToDesk — v-prefix
            $this->assertExtract(
                'HopToDesk Download v1.45.5 for Windows (Free Remote Desktop)',
                'HopToDesk', '1.45.5',
                'XML: HopToDesk v-prefix'
            );

            // Wise Folder Hider — complex nested version
            $this->assertExtract(
                'Wise Folder Hider Pro 5.0.9.2.3.9 Download for Windows',
                'Wise Folder Hider Pro', '5.0.9.2.3.9',
                'XML: Wise Folder Hider deep dotted'
            );

            // PilotEdit — slash in name
            $this->assertExtract(
                'PilotEdit Lite/ Pro 20.6.0 Download for Windows - Free Text and Hex Editor',
                'PilotEdit Lite/ Pro', '20.6.0',
                'XML: PilotEdit with slash variant'
            );

            // LM Studio — "Download" before version
            $this->assertExtract(
                'LM Studio Download 0.4.0: Local LLM Runner',
                'LM Studio', '0.4.0',
                'XML: LM Studio version after Download'
            );

            // Maxthon Browser — v-prefix with long version
            $this->assertExtract(
                'Maxthon Browser Download v7.5.2.5400 for Windows, Android, and iOS',
                'Maxthon Browser', '7.5.2.5400',
                'XML: Maxthon with v-prefix'
            );

            // Wise Care 365 — "Download v" pattern
            $this->assertExtract(
                'Wise Care 365 Download v7.3.5 for Windows',
                'Wise Care 365', '7.3.5',
                'XML: Wise Care 365 Download v pattern'
            );

            // CSS HTML Validator — dotted version
            $this->assertExtract(
                'CSS HTML Validator 26.01 Download for Windows: HTML, CSS, and SEO Checker',
                'CSS HTML Validator', '26.01',
                'XML: CSS HTML Validator'
            );

            // Glow — v-prefix mid-title
            $this->assertExtract(
                'Glow v26.2 Download for Windows: Free System Analysis Software',
                'Glow', '26.2',
                'XML: Glow v-prefix'
            );

            // KLS Backup 2025 — year in name + version
            $this->assertExtract(
                'KLS Backup 2025 14.0.3.1 Download for Windows: Professional Data Synchronization and Archiving',
                'KLS Backup 2025', '14.0.3.1',
                'XML: KLS Backup year+version'
            );

            // AquaSoft Video Vision 2026 — year in name, no numeric version
            $this->assertExtract(
                'AquaSoft Video Vision 2026 Download for Windows (Trial/Paid)',
                'AquaSoft Video Vision 2026', 'Unknown',
                'XML: AquaSoft year-only'
            );

            // Download Adobe Character Animator — leading "Download"
            $this->assertExtract(
                'Download Adobe Character Animator 26.0 for Windows',
                'Adobe Character Animator', '26.0',
                'XML: Leading Download stripped'
            );

            // Norton Neo AI Browser — "Free Download" prefix
            $this->assertExtract(
                'Free Download Norton Neo AI Browser 143.0.1748.193 for Windows & Mac',
                'Norton Neo AI Browser', '143.0.1748.193',
                'XML: Free Download prefix stripped'
            );

            echo "   ... " . ($this->passed) . " XML title assertions completed\n";
        }

        // =====================================================================
        // TEST: YEAR-IN-NAME PRODUCTS
        // =====================================================================

        private function test_year_in_name_products(): void
        {
            echo "--- Test: Year-in-Name Products ---\n";

            // Year IS the product identity — should be preserved in name
            $this->assertExtract(
                'AutoCAD 2026 - Free Download for Windows',
                'AutoCAD 2026', 'Unknown',
                'Year-name: AutoCAD 2026 (year = identity)'
            );

            $this->assertExtract(
                'Microsoft Office 2024 Download - Full Version',
                'Microsoft Office 2024', 'Unknown',
                'Year-name: Office 2024'
            );

            $this->assertExtract(
                'CorelDRAW 2024 Free Download for Windows 10/11',
                'CorelDRAW 2024', 'Unknown',
                'Year-name: CorelDRAW 2024'
            );

            // Year + separate version — year stays in name
            $this->assertExtract(
                'Acronis True Image 2025 Build 40542 Download for Windows',
                'Acronis True Image 2025', 'Build 40542',
                'Year-name: Acronis 2025 + Build'
            );

            echo "   ... year-in-name assertions completed\n";
        }

        // =====================================================================
        // TEST: YEAR + BUILD (Bug #1 critical path)
        // =====================================================================

        private function test_year_plus_build(): void
        {
            echo "--- Test: Year + Build Products ---\n";

            $this->assertExtract(
                'VirtualDJ 2024 Build 8385 - Free Download for Windows',
                'VirtualDJ 2024', 'Build 8385',
                'Year+Build: VirtualDJ 2024'
            );

            $this->assertExtract(
                'ESET NOD32 Antivirus 2025 Build 18.1.10.0 - Free Download',
                'ESET NOD32 Antivirus 2025', 'Build 18.1.10.0',
                'Year+Build: ESET NOD32'
            );

            $this->assertExtract(
                'Bitdefender Total Security 2025 Build 27.0.30.137 - Download',
                'Bitdefender Total Security 2025', 'Build 27.0.30.137',
                'Year+Build: Bitdefender'
            );

            echo "   ... year+build assertions completed\n";
        }

        // =====================================================================
        // TEST: DOTTED PRODUCT NAMES
        // =====================================================================

        private function test_dotted_product_names(): void
        {
            echo "--- Test: Dotted Product Names ---\n";

            $this->assertExtract(
                'Paint.NET 5.1.1 - Free Download for Windows',
                'Paint.NET', '5.1.1',
                'Dotted: Paint.NET'
            );

            $this->assertExtract(
                'draw.io 26.0.9 Desktop - Download for Windows',
                'draw.io', '26.0.9',
                'Dotted: draw.io'
            );

            $this->assertExtract(
                'Node.js v22.15.0 LTS Download for Windows',
                'Node.js', '22.15.0',
                'Dotted: Node.js v-prefix'
            );

            echo "   ... dotted names assertions completed\n";
        }

        // =====================================================================
        // TEST: MULTI-VERSION SLASH TITLES
        // =====================================================================

        private function test_multi_version_slash_titles(): void
        {
            echo "--- Test: Multi-Version Slash Titles ---\n";

            $this->assertExtract(
                'VLC Media Player 3.0.21 / 4.0.0 Beta - Download for Windows',
                'VLC Media Player', '3.0.21',
                'Slash: VLC primary version'
            );

            $this->assertExtract(
                'HandBrake 1.9.2 / 1.9.3 Nightly - Free Download',
                'HandBrake', '1.9.2',
                'Slash: HandBrake primary'
            );

            $this->assertExtract(
                'Wine 10.0 RC4 / 9.0 Stable – Run Windows applications under Linux',
                'Wine', '10.0 RC4',
                'Slash: Wine RC vs Stable'
            );

            echo "   ... slash title assertions completed\n";
        }

        // =====================================================================
        // TEST: SINGLE-WORD NAMES
        // =====================================================================

        private function test_single_word_names(): void
        {
            echo "--- Test: Single-Word Name Products ---\n";

            $this->assertExtract(
                'Blender 4.4.0 - Free Download for Windows',
                'Blender', '4.4.0',
                'SingleWord: Blender'
            );

            $this->assertExtract(
                'GIMP 2.10.38 - Free Download for Windows',
                'GIMP', '2.10.38',
                'SingleWord: GIMP'
            );

            $this->assertExtract(
                'Inkscape 1.4.1 - Free Download',
                'Inkscape', '1.4.1',
                'SingleWord: Inkscape'
            );

            $this->assertExtract(
                'Krita 5.2.9 - Free Download for Windows',
                'Krita', '5.2.9',
                'SingleWord: Krita'
            );

            echo "   ... single-word name assertions completed\n";
        }

        // =====================================================================
        // TEST: COMPLEX VERSION FORMATS
        // =====================================================================

        private function test_complex_version_formats(): void
        {
            echo "--- Test: Complex Version Formats ---\n";

            $this->assertExtract(
                'Apache Tomcat 10.1.39 RC2 - Download',
                'Apache Tomcat', '10.1.39 RC2',
                'Complex: Tomcat RC'
            );

            // SP (Service Pack) format
            $this->assertExtract(
                'WinRAR 7.10 Final - Free Download for Windows',
                'WinRAR', '7.10',
                'Complex: WinRAR Final'
            );

            echo "   ... complex version assertions completed\n";
        }

        // =====================================================================
        // TEST: V-PREFIX VERSIONS
        // =====================================================================

        private function test_v_prefix_versions(): void
        {
            echo "--- Test: v-Prefix Versions ---\n";

            $this->assertExtract(
                'HopToDesk v1.45.5 - Free Download for Windows',
                'HopToDesk', '1.45.5',
                'vPrefix: HopToDesk'
            );

            $this->assertExtract(
                'Ventoy v1.1.05 - Free Download',
                'Ventoy', '1.1.05',
                'vPrefix: Ventoy'
            );

            $this->assertExtract(
                'yt-dlp v2025.04.30 - Download for Windows',
                'yt-dlp', '2025.04.30',
                'vPrefix: yt-dlp date-based'
            );

            $this->assertExtract(
                'Syncthing v1.29.3 - Free Download',
                'Syncthing', '1.29.3',
                'vPrefix: Syncthing'
            );

            echo "   ... v-prefix assertions completed\n";
        }

        // =====================================================================
        // TEST: SPECIAL CHARACTERS IN NAMES
        // =====================================================================

        private function test_special_char_products(): void
        {
            echo "--- Test: Special Characters in Names ---\n";

            $this->assertExtract(
                'Notepad++ 8.7.8 - Free Download for Windows',
                'Notepad++', '8.7.8',
                'SpecialChar: Notepad++'
            );

            $this->assertExtract(
                'GPU-Z 2.62.0 - Free Download for Windows',
                'GPU-Z', '2.62.0',
                'SpecialChar: GPU-Z hyphenated'
            );

            $this->assertExtract(
                'O&O DiskImage 22.2.1142 Premium Download for Windows',
                'O&O DiskImage', '22.2.1142',
                'SpecialChar: O&O ampersand'
            );

            echo "   ... special char assertions completed\n";
        }

        // =====================================================================
        // TEST: NUMBER-IS-NAME PRODUCTS
        // =====================================================================

        private function test_number_is_name_products(): void
        {
            echo "--- Test: Number-is-Name Products ---\n";

            $this->assertExtract(
                '7-Zip 24.09 - Free Download for Windows',
                '7-Zip', '24.09',
                'NumName: 7-Zip'
            );

            $this->assertExtract(
                '360 Total Security 11.0.0.1116 - Free Download',
                '360 Total Security', '11.0.0.1116',
                'NumName: 360 Total Security'
            );

            $this->assertExtract(
                '4K Video Downloader+ 1.10.2 - Free Download',
                '4K Video Downloader+', '1.10.2',
                'NumName: 4K Video Downloader+'
            );

            $this->assertExtract(
                '1Password 8.10.62 - Download for Windows',
                '1Password', '8.10.62',
                'NumName: 1Password'
            );

            echo "   ... number-is-name assertions completed\n";
        }

        // =====================================================================
        // TEST: EDITION QUALIFIERS
        // =====================================================================

        private function test_edition_qualifiers(): void
        {
            echo "--- Test: Edition Qualifiers ---\n";

            $this->assertExtract(
                'AIDA64 Extreme Edition 7.50.7100 - Download for Windows',
                'AIDA64 Extreme Edition', '7.50.7100',
                'Edition: AIDA64 Extreme'
            );

            $this->assertExtract(
                'VMware Workstation 17 Pro 17.6.3 - Free Download',
                'VMware Workstation 17 Pro', '17.6.3',
                'Edition: VMware Workstation Pro'
            );

            $this->assertExtract(
                'Sublime Text 4 Build 4189 - Download for Windows',
                'Sublime Text', '4 Build 4189',
                'Edition: Sublime Text 4 + Build'
            );

            echo "   ... edition qualifier assertions completed\n";
        }

        // =====================================================================
        // TEST: BROWSER-STYLE HIGH VERSIONS
        // =====================================================================

        private function test_browser_style_versions(): void
        {
            echo "--- Test: Browser-Style High Versions ---\n";

            $this->assertExtract(
                'Google Chrome 136.0.7103.93 - Free Download for Windows',
                'Google Chrome', '136.0.7103.93',
                'Browser: Chrome'
            );

            $this->assertExtract(
                'Mozilla Firefox 138.0.1 - Free Download for Windows',
                'Mozilla Firefox', '138.0.1',
                'Browser: Firefox'
            );

            $this->assertExtract(
                'Opera 118.0.5461.88 - Free Download for Windows',
                'Opera', '118.0.5461.88',
                'Browser: Opera'
            );

            $this->assertExtract(
                'Microsoft Edge 144.0.3719.128 Free Download for Windows, macOS, Linux & Mobile',
                'Microsoft Edge', '144.0.3719.128',
                'Browser: Edge'
            );

            echo "   ... browser-style version assertions completed\n";
        }

        // =====================================================================
        // TEST: DATE-BASED VERSIONS
        // =====================================================================

        private function test_date_based_versions(): void
        {
            echo "--- Test: Date-Based Versions ---\n";

            $this->assertExtract(
                'PotPlayer 250430 - Free Download for Windows',
                'PotPlayer', '250430',
                'DateVer: PotPlayer 6-digit date'
            );

            $this->assertExtract(
                'Shotcut 25.03.29 - Free Download for Windows',
                'Shotcut', '25.03.29',
                'DateVer: Shotcut'
            );

            echo "   ... date-based version assertions completed\n";
        }

        // =====================================================================
        // TEST: TRAILING NOISE STRIPPING
        // =====================================================================

        private function test_trailing_noise_stripping(): void
        {
            echo "--- Test: Trailing Noise Stripping ---\n";

            // "Download for Windows" pattern
            $this->assertExtract(
                'Blender 4.4.0 Download for Windows',
                'Blender', '4.4.0',
                'Noise: Download for Windows stripped'
            );

            // "Free Download" trailing
            $this->assertExtract(
                'GIMP 2.10.38 - Free Download',
                'GIMP', '2.10.38',
                'Noise: Free Download stripped'
            );

            // "for macOS" platform suffix
            $this->assertExtract(
                'OnyX 4.9.5 Download for macOS System Maintenance and Optimization',
                'OnyX', '4.9.5',
                'Noise: platform noise stripped'
            );

            // Leading "Free Download" prefix
            $this->assertExtract(
                'Free Download Norton Neo AI Browser 143.0.1748.193 for Windows & Mac',
                'Norton Neo AI Browser', '143.0.1748.193',
                'Noise: leading Free Download stripped'
            );

            // Leading "Download" prefix
            $this->assertExtract(
                'Download Adobe Character Animator 26.0 for Windows',
                'Adobe Character Animator', '26.0',
                'Noise: leading Download stripped'
            );

            echo "   ... noise stripping assertions completed\n";
        }

        // =====================================================================
        // TEST: SIMILARITY_HELPER CROSS-FILE COHERENCE
        // =====================================================================

        private function test_similarity_helper_consistency(): void
        {
            echo "--- Test: Similarity_Helper Coherence ---\n";

            // Same software, different versions — should match
            $this->assertSimilaritySafe('VirtualDJ', 'VirtualDJ', true,
                'Similarity: identical names');

            $this->assertSimilaritySafe('Adobe Premiere Pro', 'Adobe Premiere Pro', true,
                'Similarity: identical multi-word');

            // Different editions — should NOT match (qualifier conflict)
            $this->assertSimilaritySafe('AIDA64 Extreme', 'AIDA64 Business', false,
                'Similarity: edition conflict Extreme vs Business');

            $this->assertSimilaritySafe('VMware Workstation Pro', 'VMware Workstation Player', false,
                'Similarity: edition conflict Pro vs Player');

            // Partial name containment — should match if safe
            $this->assertSimilaritySafe('Adobe Photoshop', 'Adobe Photoshop 2026', true,
                'Similarity: name with year suffix');

            // Completely different software — should NOT match
            $this->assertSimilaritySafe('VLC Media Player', 'VirtualDJ', false,
                'Similarity: completely different software');

            $this->assertSimilaritySafe('Google Chrome', 'Mozilla Firefox', false,
                'Similarity: different browsers');

            echo "   ... similarity coherence assertions completed\n";
        }

        // =====================================================================
        // TEST: YEAR CONFLICT DETECTION (Bug #5 fix)
        // =====================================================================

        private function test_year_conflict_detection(): void
        {
            echo "--- Test: Year Conflict Detection ---\n";

            // Same year — should be safe
            $this->assertSimilaritySafe('Adobe Premiere Pro 2026', 'Adobe Premiere Pro 2026', true,
                'YearConflict: same year safe');

            // Different years — should NOT be safe (year conflict)
            $this->assertSimilaritySafe('Adobe Premiere Pro 2025', 'Adobe Premiere Pro 2026', false,
                'YearConflict: 2025 vs 2026 blocked');

            $this->assertSimilaritySafe('AutoCAD 2024', 'AutoCAD 2026', false,
                'YearConflict: AutoCAD 2024 vs 2026');

            $this->assertSimilaritySafe('CorelDRAW 2024', 'CorelDRAW 2025', false,
                'YearConflict: CorelDRAW different years');

            // One has year, other doesn't — should be safe (no conflict)
            $this->assertSimilaritySafe('Adobe Photoshop', 'Adobe Photoshop 2026', true,
                'YearConflict: no year vs year = safe');

            // IObit Smart Defrag — same name across versions (no year in name)
            $this->assertSimilaritySafe('IObit Smart Defrag', 'IObit Smart Defrag', true,
                'YearConflict: no-year products safe');

            echo "   ... year conflict detection assertions completed\n";
        }

        // =====================================================================
        // TEST: CROSS-FILE NORMALIZATION COHERENCE
        // Tests that Title_Analyzer normalize() and Similarity_Helper normalize()
        // produce compatible results for the SAME input.
        // =====================================================================

        private function test_cross_file_normalization_coherence(): void
        {
            echo "--- Test: Cross-File Normalization Coherence ---\n";

            // Key coherence rule: Title_Analyzer strips noise from the TITLE before extraction.
            // Similarity_Helper normalizes the EXTRACTED NAME for comparison.
            // They must not contradict each other.

            $titles = [
                'VirtualDJ 2026 Build 8985 Stable – Free Download',
                'Adobe Premiere Pro 2026 26.0 Download for Windows',
                'Google Chrome 145.0.7632.76 Free Download',
                'IObit Smart Defrag 11.2.0.472 Final – Free',
                'Free Download Manager 6.33.1 Build 6644',
            ];

            foreach ($titles as $title) {
                $extracted = $this->analyzer->extract($title);
                if (!$extracted) {
                    $this->failed++;
                    $this->failures[] = [
                        'test' => 'Cross-file coherence',
                        'input' => $title,
                        'expected' => 'extraction succeeds',
                        'actual' => 'extraction returned false',
                    ];
                    continue;
                }

                // The extracted name fed to Similarity_Helper::normalize() should
                // produce a non-empty, meaningful string
                $simNorm = Similarity_Helper::normalize($extracted['name']);
                if (strlen($simNorm) < 2) {
                    $this->failed++;
                    $this->failures[] = [
                        'test' => 'Cross-file coherence: Similarity normalize',
                        'input' => "name=\"{$extracted['name']}\" from \"{$title}\"",
                        'expected' => 'normalize() produces >= 2 chars',
                        'actual' => "got: \"{$simNorm}\"",
                    ];
                } else {
                    $this->passed++;
                }

                // Critical: Similarity_Helper::normalize() should NOT strip years
                // (Bug #5 fix) — years preserved as significant tokens
                if (preg_match('/\b(20\d{2})\b/', $extracted['name'], $ym)) {
                    $year = $ym[1];
                    if (strpos($simNorm, strtolower($year)) === false) {
                        $this->failed++;
                        $this->failures[] = [
                            'test' => 'Cross-file coherence: year preservation',
                            'input' => "name=\"{$extracted['name']}\"",
                            'expected' => "year {$year} preserved after normalize()",
                            'actual' => "normalized=\"{$simNorm}\" — year stripped!",
                        ];
                    } else {
                        $this->passed++;
                    }
                }
            }

            echo "   ... cross-file coherence assertions completed\n";
        }

        // =====================================================================
        // TEST: AGGRESSIVE_EXTRACT FALLBACK (Bug #2 fix)
        // =====================================================================

        private function test_aggressive_extract_fallback(): void
        {
            echo "--- Test: Aggressive Extract Fallback ---\n";

            // Titles where VERSION_PATTERN might miss but aggressive_extract catches
            $this->assertExtract(
                'SomeApp 26.0 Download',
                'SomeApp', '26.0',
                'AggressiveFallback: trailing noise after version'
            );

            // Should NOT return full title as name (Bug #2 original issue)
            $result = $this->analyzer->extract('Totally Unknown App');
            if ($result && $result['name'] === 'Totally Unknown App' && $result['version'] === 'Unknown') {
                $this->passed++;
            } elseif (!$result) {
                // Also acceptable: false for unparseable
                $this->passed++;
            } else {
                $this->failed++;
                $this->failures[] = [
                    'test' => 'AggressiveFallback: no-version title',
                    'input' => 'Totally Unknown App',
                    'expected' => 'name="Totally Unknown App", version="Unknown" or false',
                    'actual' => sprintf('name="%s", version="%s"', $result['name'] ?? '?', $result['version'] ?? '?'),
                ];
            }

            echo "   ... aggressive extract assertions completed\n";
        }

        // =====================================================================
        // TEST: CLEAN_NAME YEAR STRIPPING RULES (Bug #6 fix)
        // =====================================================================

        private function test_clean_name_year_stripping_rules(): void
        {
            echo "--- Test: clean_name Year Stripping Rules ---\n";

            // Multi-word name + trailing year → year STRIPPED from name
            // "Adobe Premiere Pro 2026" → strip year only if >= 2 words remain
            // This is tested indirectly: when version is detected separately,
            // the raw_name passed to clean_name may include a year.

            // Single-word + year → year PRESERVED (it's the product identity)
            $this->assertExtract(
                'AutoCAD 2026',
                'AutoCAD 2026', 'Unknown',
                'CleanName: single-word + year preserved'
            );

            // Two-word name + year + separate version → year may go either way
            // But the name must still be recognizable
            $result = $this->analyzer->extract('Adobe Photoshop 2026 27.4.0 for Windows');
            if ($result) {
                // Name should either be "Adobe Photoshop 2026" or "Adobe Photoshop"
                // Version should be "27.4.0"
                $nameOk = in_array(strtolower($result['name']), ['adobe photoshop 2026', 'adobe photoshop']);
                $verOk = ($result['version'] === '27.4.0');
                if ($nameOk && $verOk) {
                    $this->passed++;
                } else {
                    $this->failed++;
                    $this->failures[] = [
                        'test' => 'CleanName: Adobe Photoshop 2026 with version',
                        'input' => 'Adobe Photoshop 2026 27.4.0 for Windows',
                        'expected' => 'name contains "Adobe Photoshop", version="27.4.0"',
                        'actual' => sprintf('name="%s", ver="%s"', $result['name'], $result['version']),
                    ];
                }
            } else {
                $this->failed++;
                $this->failures[] = [
                    'test' => 'CleanName: Adobe Photoshop 2026',
                    'input' => 'Adobe Photoshop 2026 27.4.0 for Windows',
                    'expected' => 'extraction succeeds',
                    'actual' => 'returned false',
                ];
            }

            echo "   ... clean_name year stripping assertions completed\n";
        }

        // =====================================================================
        // TEST: VERSION COMPARISON (is_newer_version)
        // =====================================================================

        private function test_version_comparison(): void
        {
            echo "--- Test: Version Comparison ---\n";

            // Basic dotted version
            $this->assertVersionNewer('2.0.0', '1.0.0', true, 'VerCmp: 2.0 > 1.0');
            $this->assertVersionNewer('1.0.0', '2.0.0', false, 'VerCmp: 1.0 < 2.0');
            $this->assertVersionNewer('1.0.0', '1.0.0', false, 'VerCmp: equal');

            // Build numbers
            $this->assertVersionNewer('Build 8985', 'Build 8490', true, 'VerCmp: Build 8985 > 8490');
            $this->assertVersionNewer('6.42 Build 60', '6.42 Build 27', true, 'VerCmp: same base, higher build');
            $this->assertVersionNewer('6.42 Build 27', '6.42 Build 60', false, 'VerCmp: same base, lower build');

            // Pre-release tiers
            $this->assertVersionNewer('1.0.0', '1.0.0 Beta', true, 'VerCmp: stable > beta');
            $this->assertVersionNewer('1.0.0 RC1', '1.0.0 Beta', true, 'VerCmp: RC > Beta');
            $this->assertVersionNewer('1.0.0 Beta', '1.0.0 Alpha', true, 'VerCmp: Beta > Alpha');

            // Unknown handling
            $this->assertVersionNewer('1.0.0', 'Unknown', true, 'VerCmp: any > Unknown');
            $this->assertVersionNewer('Unknown', '1.0.0', false, 'VerCmp: Unknown < any');
            $this->assertVersionNewer('Unknown', 'Unknown', false, 'VerCmp: Unknown = Unknown');

            // Letter suffix
            $this->assertVersionNewer('1.2.3c', '1.2.3b', true, 'VerCmp: letter c > b');
            $this->assertVersionNewer('1.2.3a', '1.2.3b', false, 'VerCmp: letter a < b');

            // Browser-style high numbers
            $this->assertVersionNewer('145.0.7632.76', '144.0.3719.128', true, 'VerCmp: Chrome 145 > 144');
            $this->assertVersionNewer('147.0.3', '147.0.2', true, 'VerCmp: Firefox minor bump');

            // Year-based versions (treated as dotted)
            $this->assertVersionNewer('2026.1.26.43', '2025.12.23.15', true, 'VerCmp: KMPlayer 2026 > 2025');

            echo "   ... version comparison assertions completed\n";
        }
    }

    // =========================================================================
    // EXECUTE
    // =========================================================================
    $test = new TitleMatchingSystemTest();
    $test->run();
}
