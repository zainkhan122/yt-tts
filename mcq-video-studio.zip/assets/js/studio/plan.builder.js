/**
 * MCQVS Plan Builder
 * Thin adapter around MCQVS_RenderPlan with template cue-points + asset collection.
 *
 * Exports:
 *  - buildFromPlaylist(playlist, ctx)
 *  - buildFromState(state, ctx)
 *
 * @since 2026-02-05
 */
(function (window) {
  "use strict";

  const _num = (v, d) => {
    const n = Number(v);
    return Number.isFinite(n) ? n : d;
  };

  const _normalizeSelectedIndices = (state) => {
    const qs = Array.isArray(state && state.questions) ? state.questions : [];
    const sel = Array.isArray(state && state.selectedQuestions) ? state.selectedQuestions : [];
    if (!sel.length) return qs.map((_, i) => i);

    const out = [];
    const seen = new Set();
    for (const v of sel) {
      const i = Number(v);
      if (!Number.isInteger(i)) continue;
      if (i < 0 || i >= qs.length) continue;
      if (seen.has(i)) continue;
      seen.add(i);
      out.push(i);
    }
    return out.length ? out : qs.map((_, i) => i);
  };

  const _deriveTiming = (state) => {
    const t = (state && state.timing) ? state.timing : {};
    // @FIX 2026-08-11: Format-aware fallbacks. Shorts default to the 25-40s sweet-spot
    //                  pacing; long-form keeps the classic roomy timing. These only apply
    //                  when state.timing is missing entirely (controller always sets it).
    const isShort = !(state && state.videoFormat === 'youtube');
    const hookIntro = _num(t.hookIntro, isShort ? 1200 : 2000);
    const outroDuration = _num(t.outroDuration, isShort ? 3200 : 5000);

    const intro = _num(t.questionAppear, isShort ? 600 : 1000);
    const reveal = _num(t.revealAnswer, (t.questionPhases && t.questionPhases.reveal) ? t.questionPhases.reveal : (isShort ? 2000 : 3000));

    const questionTotal = _num(t.questionTotal, isShort ? 7700 : 12000);   // 600+500+4600+2000 — matches server fallback (SSOT)
    const reading = Math.max(0, questionTotal - intro - reveal);

    return {
      hookIntro,
      outroDuration,
      questionTotal,
      questionPhases: { intro, reading, reveal },
    };
  };

  const _buildPlaylistFromState = (state) => {
    const timing = _deriveTiming(state);
    const playlist = [];

    // @NEW 2026-07-30: Cover scene — first frame is always a beautiful cover (logo + brand + hook/quiz name).
    // @FIX 2026-08-11: Cover was 2 frames (~83ms) — too short for social platforms to capture as the
    //                  poster/thumbnail. Extended to ~1s (fps frames) so the hook-first card is a viable
    //                  auto thumbnail and scroll-stopper. Mirrors server-renderer.js.
    const coverCfg = state.coverConfig || {};
    if (coverCfg.enabled !== false) {
      playlist.push({
        id: "cover",
        type: "cover",
        duration: 1000,  // 1s cover — matches server-renderer (SSOT)
        content: {},
        timing,
      });
    }

    const hookText = String((state && state.hookText) || "").trim();
    // @FIX 2026-08-11: When the hook is hidden (hookVisible === false) do NOT add the
    //       hook scene at all — otherwise the video carried a blank 1.2s gap before the
    //       first question. Mirrored in server-renderer.js + studio.export.js (SSOT).
    if (hookText && (state && state.hookVisible !== false)) {
      playlist.push({
        id: "hook",
        type: "hook",
        duration: timing.hookIntro,
        content: { hookText, hookVisible: (state && state.hookVisible !== false) },
        timing,
      });
    }

    const indices = _normalizeSelectedIndices(state);
    const totalQuestions = indices.length;

    // If no questions exist, force a visible hook message (prevents "blank" preview when Hook text is hidden).
    if (!totalQuestions) {
      return [
        {
          id: 'hook',
          type: 'hook',
          duration: Math.max(2000, Number(timing.hookIntro) || 2000),
          content: {
            hookText: 'No questions loaded. Use Data Source → Load Questions.',
            hookVisible: true
          },
          timing,
        }
      ];
    }

    indices.forEach((qIndex, sequenceIndex) => {
      const q = state && state.questions ? state.questions[qIndex] : null;
      if (!q) return;

      playlist.push({
        id: `q${qIndex}`,
        type: "question",
        duration: timing.questionTotal,
        content: {
          ...q,
          questionIndex: qIndex,
          sequenceIndex,
          totalQuestions,
        },
        timing,
      });
    });

    const ctaText = String((state && (state.computedCtaText || state.ctaText)) || "Subscribe!").trim();
    playlist.push({
      id: "outro",
      type: "outro",
      duration: timing.outroDuration,
      content: { ctaText },
      timing,
    });

    return playlist;
  };

  function buildFromPlaylist(playlist, ctx) {
    if (!window.MCQVS_RenderPlan || typeof window.MCQVS_RenderPlan.buildFromPlaylist !== "function") {
      throw new Error("MCQVS_RenderPlan.buildFromPlaylist missing");
    }

    const normalized = (Array.isArray(playlist) ? playlist : []).map(s => {
      const dur =
        (s && s.duration != null) ? s.duration :
          (s && s.durationMs != null) ? s.durationMs :
            (s && s.durMs != null) ? s.durMs :
              0;
      return Object.assign({}, s, { duration: Number(dur) || 0 });
    });

    const plan = window.MCQVS_RenderPlan.buildFromPlaylist(normalized, {

      fps: _num(ctx && ctx.fps, 30),
      width: _num(ctx && ctx.width, 1080),
      height: _num(ctx && ctx.height, 1920),
      templateId: (ctx && ctx.templateId) ? String(ctx.templateId) : null,
    });

    if (plan && window.MCQVS_RenderPlan.collectAssetsFromConfig && ctx && ctx.assetConfig) {
      window.MCQVS_RenderPlan.collectAssetsFromConfig(plan, ctx.assetConfig);
    }

    const tm = window.MCQVS_TemplateManager;
    let _attachedCueEvents = false;
    if (tm && typeof tm.getTemplate === "function") {
      const tpl = tm.getTemplate((ctx && ctx.templateId) ? ctx.templateId : null) || tm.getTemplate("trivia");
      const templateCfg = tpl && tpl.config ? tpl.config : null;
      if (templateCfg && typeof templateCfg.getCuePoints === "function") {
        const cuePack = templateCfg.getCuePoints(plan) || {};
        plan.duckWindows = Array.isArray(cuePack.duckWindows) ? cuePack.duckWindows : [];
        plan.sfxEvents = Array.isArray(cuePack.sfxEvents) ? cuePack.sfxEvents : [];
        plan.fxEvents = Array.isArray(cuePack.fxEvents) ? cuePack.fxEvents : [];
        _attachedCueEvents = true;
      }
    }

    // @FIX 2026-08-11 (Reveal animation in preview): if the template had no
    // getCuePoints (e.g. a template added without a contract entry), the plan
    // carried NO fxEvents/sfxEvents — the unified renderer then never fired the
    // reveal particles/shake/glow, so preview showed no reveal animation while the
    // server render (which has its own fallback) did. Derive the cue events from
    // plan.cues as a fallback (mirrors server-renderer realignCueDerivedEvents).
    if (!_attachedCueEvents) {
      const cues = Array.isArray(plan.cues) ? plan.cues : [];
      const byType = (type) => cues.filter((c) => c && c.type === type);
      const duckWindows = [];
      const sfxEvents = [];
      const fxEvents = [];

      byType("reveal_start").forEach((c) => {
        duckWindows.push({ startMs: Math.max(0, Number(c.atMs || 0) - 250), endMs: Number(c.atMs || 0) + 1400, volume: 0.18 });
        sfxEvents.push({ name: "reveal", atMs: Number(c.atMs || 0), gain: 1.0 });
      });
      byType("tick").forEach((c) => sfxEvents.push({ name: "tick", atMs: Number(c.atMs || 0), gain: 0.55 }));
      byType("reveal_correct").forEach((c) => sfxEvents.push({ name: "correct", atMs: Number(c.atMs || 0), gain: 1.0 }));

      const particleCues = byType("reveal_correct");
      const revealCues = particleCues.length ? particleCues : byType("reveal_start");
      revealCues.forEach((c) => fxEvents.push({ type: "particles_burst", atMs: Number(c.atMs || 0), kind: "sparkles" }));
      byType("tick").forEach((c) => fxEvents.push({ type: "timer_glow", atMs: Number(c.atMs || 0), durationMs: 240, intensity: 0.75, color: "#00f0ff" }));
      byType("reveal_start").forEach((c) => fxEvents.push({ type: "screen_shake", atMs: Number(c.atMs || 0), durationMs: 360, magnitude: 10 }));

      plan.duckWindows = duckWindows;
      plan.sfxEvents = sfxEvents;
      plan.fxEvents = fxEvents;
    }



    // @NEW 2026-02-07: Font Override
    if (ctx && ctx.fontOverride) {
      plan.fontOverride = ctx.fontOverride;
    }

    if (!plan.requiredSfx) {
      const names = new Set();
      (plan.sfxEvents || []).forEach((e) => {
        if (e && e.name) names.add(String(e.name));
      });
      plan.requiredSfx = Array.from(names);
    }

    if (ctx && ctx.sfxMap && plan.requiredSfx && plan.requiredSfx.length) {
      plan.assets = plan.assets || {};
      plan.assets.audio = Array.isArray(plan.assets.audio) ? plan.assets.audio : [];
      plan.requiredSfx.forEach((name) => {
        const url = ctx.sfxMap[name];
        if (url && !plan.assets.audio.includes(url)) plan.assets.audio.push(url);
      });
    }

    if (plan && window.MCQVS_RenderPlanValidator && typeof window.MCQVS_RenderPlanValidator.assertValid === "function") {
      window.MCQVS_RenderPlanValidator.assertValid(plan);
    }

    return plan;
  }

  // @MODIFIED 2026-02-06: Removed duplicate buildFromState function (was lines 166-237)
  // The following buildFromState is the canonical implementation

  function buildFromState(state, ctx) {
    const st = state || {};
    const templateId = (ctx && ctx.templateId) ? String(ctx.templateId) : String(st.templateId || st.currentTemplate || "trivia");
    const playlist = _buildPlaylistFromState(st);

    const plan = buildFromPlaylist(playlist, {
      fps: _num(ctx && ctx.fps, 30),
      width: _num(ctx && ctx.width, 1080),
      height: _num(ctx && ctx.height, 1920),
      templateId,

      fontOverride: (ctx && ctx.fontOverride) ? ctx.fontOverride : (st.fontOverride || null), // @NEW 2026-02-07
      assetConfig: (ctx && ctx.assetConfig) ? ctx.assetConfig : null,
      sfxMap: (ctx && ctx.sfxMap) ? ctx.sfxMap : null,
    });

    plan.playlist = playlist;
    return plan;
  }

  window.MCQVS_PlanBuilder = { buildFromPlaylist, buildFromState };

})(window);
