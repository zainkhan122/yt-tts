/**
 * Download Tracker
 * 
 * Intercepts click events on download buttons and sends AJAX request to track downloads.
 * Non-blocking: download proceeds immediately while tracking request is sent in background.
 *
 * @package SEO_Article_Generator
 * @since 2.16.7
 * @MODIFIED 2026-01-09: New file for download click tracking
 */
(function () {
    'use strict';

    // Bail early if config not available
    if (typeof seoGenDownload === 'undefined') {
        return;
    }

    var config = seoGenDownload;
    var tracked = false; // Prevent duplicate tracking on same page

    /**
     * Track download via AJAX
     * Non-blocking: Uses sendBeacon or async XHR
     */
    function trackDownload() {
        if (tracked) {
            return; // Already tracked this session
        }
        tracked = true;

        var data = new FormData();
        data.append('action', 'seo_gen_track_download');
        data.append('nonce', config.nonce);
        data.append('post_id', config.post_id);

        // Use sendBeacon if available (non-blocking, survives page navigation)
        if (navigator.sendBeacon) {
            // sendBeacon needs URLSearchParams for proper form encoding
            var params = new URLSearchParams();
            params.append('action', 'seo_gen_track_download');
            params.append('nonce', config.nonce);
            params.append('post_id', config.post_id);
            navigator.sendBeacon(config.ajax_url, params);
            return;
        }

        // Fallback to async XHR
        var xhr = new XMLHttpRequest();
        xhr.open('POST', config.ajax_url, true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.send(
            'action=seo_gen_track_download' +
            '&nonce=' + encodeURIComponent(config.nonce) +
            '&post_id=' + encodeURIComponent(config.post_id)
        );
    }

    /**
     * Attach click handlers to download links
     */
    function init() {
        // Use event delegation on document for dynamically loaded content
        document.addEventListener('click', function (e) {
            var target = e.target;

            // Walk up to find matching link (handles clicks on icon/text inside button)
            while (target && target !== document) {
                if (target.matches && (
                    target.matches('.seo-gen-hero__btn') ||
                    target.matches('.seo-gen-heroalt-link') ||
                    target.matches('.seo-gen-download-btn') ||
                    target.matches('[data-seo-gen-download]')
                )) {
                    trackDownload();
                    return; // Don't prevent default - let download proceed
                }
                target = target.parentNode;
            }
        });
    }

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
