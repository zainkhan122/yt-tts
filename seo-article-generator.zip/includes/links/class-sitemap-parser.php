<?php

/**
 * Sitemap Parser
 *
 * @package SEO_Article_Generator
 */

namespace SEO_Article_Generator\Links;

use SEO_Article_Generator\File_Upload_Exception;
use SEO_Article_Generator\Logger;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Parse and cache sitemap CSV
 * @deprecated 1.6.0 - CSV sourcing is deprecated in favor of Unified Relevance Pool and future API fetch.
 */
class Sitemap_Parser
{
    /**
     * Logger instance
     *
     * @var Logger
     */
    private $logger;

    /**
     * Constructor
     *
     * @param Logger $logger Logger instance
     */
    public function __construct($logger)
    {
        $this->logger = $logger;
    }

    /**
     * Import CSV file to database
     *
     * @param string $file_path Path to CSV file
     * @return array Import results
     * @throws File_Upload_Exception If import fails
     */
    public function import_csv($file_path)
    {
        global $wpdb;

        $this->logger->info('Importing sitemap CSV', array('file' => basename($file_path)));

        if (!file_exists($file_path)) {
            throw new File_Upload_Exception('File not found');
        }

        // Parse CSV
        $entries = $this->parse_csv_file($file_path);

        if (empty($entries)) {
            throw new File_Upload_Exception('No valid entries found in CSV');
        }

        // Clear existing data
	$table = \SEO_Article_Generator\Installer::table_links();
	$wpdb->query("TRUNCATE TABLE {$table}");

        // Insert entries
        $imported = 0;
        $skipped = 0;

        foreach ($entries as $entry) {
            $result = $wpdb->insert(
                $table,
                array(
                    'title' => $entry['title'],
                    'url' => $entry['url'],
                    'category' => $entry['category'],
                    'keywords' => $entry['keywords'],
                    'software_type' => $entry['software_type'],
                ),
                array('%s', '%s', '%s', '%s', '%s')
            );

            if ($result) {
                $imported++;
            } else {
                $skipped++;
            }
        }

        $this->logger->info('Sitemap import completed', array(
            'imported' => $imported,
            'skipped' => $skipped,
        ));

        return array(
            'imported' => $imported,
            'skipped' => $skipped,
            'total' => count($entries),
        );
    }

    /**
     * Parse CSV file
     *
     * @param string $file_path CSV file path
     * @return array Parsed entries
     * @throws File_Upload_Exception If parsing fails
     */
    private function parse_csv_file($file_path)
    {
        $entries = array();

        $handle = fopen($file_path, 'r');
        if (!$handle) {
            throw new File_Upload_Exception('Failed to open CSV file');
        }

        // Read header
        $header = fgetcsv($handle);
        if (!$header || count($header) < 2) {
            fclose($handle);
            throw new File_Upload_Exception('Invalid CSV format - missing header');
        }

        // @MODIFIED 2025-12-02: Fix UTF-8 BOM and whitespace issues
        // Remove UTF-8 BOM from first column if present (common in Excel exports)
        if (!empty($header[0])) {
            $header[0] = preg_replace('/^\x{FEFF}/u', '', $header[0]);
        }

        // Normalize header - lowercase, trim, remove special chars
        $header = array_map(function ($col) {
            $col = strtolower(trim($col));
            // Remove common invisible characters
            $col = preg_replace('/[\x00-\x1F\x7F-\x9F]/u', '', $col);
            return $col;
        }, $header);

        // Find column indexes (case-insensitive)
        $title_index = array_search('title', $header);
        $url_index = array_search('url', $header);

        if (false === $title_index || false === $url_index) {
            fclose($handle);
            // @MODIFIED 2025-12-02: Better error message with header debug info
            $header_str = implode(', ', array_map(function ($col) {
                return '"' . $col . '"';
            }, $header));
            throw new File_Upload_Exception("CSV must have 'Title' and 'URL' columns. Found columns: {$header_str}");
        }

        // Read data rows
        $row_number = 1;
        while (($row = fgetcsv($handle)) !== false) {
            $row_number++;

            if (count($row) < 2) {
                continue; // Skip empty rows
            }

            $title = isset($row[$title_index]) ? trim($row[$title_index]) : '';
            $url = isset($row[$url_index]) ? trim($row[$url_index]) : '';

            if (empty($title) || empty($url)) {
                $this->logger->warning("Skipping row {$row_number}: missing title or URL");
                continue;
            }

            // Extract metadata from title
            $metadata = $this->extract_metadata($title);

            $entries[] = array(
                'title' => $title,
                'url' => $url,
                'category' => $metadata['category'],
                'keywords' => $metadata['keywords'],
                'software_type' => $metadata['software_type'],
            );
        }

        fclose($handle);

        return $entries;
    }

    /**
     * Extract metadata from title
     *
     * @param string $title Title string
     * @return array Extracted metadata
     */
    private function extract_metadata($title)
    {
        $metadata = array(
            'category' => '',
            'keywords' => '',
            'software_type' => '',
        );

        // Extract software type from common patterns
        $types = array(
            'browser' => 'Browser',
            'player' => 'Media Player',
            'editor' => 'Editor',
            'antivirus' => 'Security',
            'vpn' => 'Security',
            'downloader' => 'Download Manager',
            'converter' => 'Converter',
            'recorder' => 'Recorder',
            'cleaner' => 'System Utility',
            'optimizer' => 'System Utility',
            'backup' => 'Backup',
            'firewall' => 'Security',
            'pdf' => 'PDF Tool',
            'office' => 'Office Suite',
        );

        $title_lower = strtolower($title);

        foreach ($types as $pattern => $type) {
            if (strpos($title_lower, $pattern) !== false) {
                $metadata['software_type'] = $type;
                break;
            }
        }

        // Extract keywords (words longer than 3 chars, excluding common words)
        $stop_words = array('the', 'and', 'for', 'with', 'download', 'free', 'version', 'final', 'build');

        $words = preg_split('/[\s\-_\(\)\[\]]+/', $title_lower);
        $keywords = array_filter($words, function ($word) use ($stop_words) {
            return strlen($word) > 3 && !in_array($word, $stop_words) && !is_numeric($word);
        });

        $metadata['keywords'] = implode(' ', $keywords);

        // Try to determine category
        if (!empty($metadata['software_type'])) {
            $metadata['category'] = $metadata['software_type'];
        }

        return $metadata;
    }

    /**
     * Get sitemap statistics
     *
     * @return array Statistics
     */
    public function get_stats()
    {
        global $wpdb;

	$table = \SEO_Article_Generator\Installer::table_links();

	$total = $wpdb->get_var("SELECT COUNT(*) FROM {$table}");

        $categories = $wpdb->get_results(
            "SELECT software_type, COUNT(*) as count 
            FROM {$table} 
            WHERE software_type != '' 
            GROUP BY software_type 
            ORDER BY count DESC 
            LIMIT 10",
            ARRAY_A
        );

        return array(
            'total_links' => (int) $total,
            'categories' => $categories,
        );
    }
}
