<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ImagePreprocessor {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

 	public function process( string $image_url, array $campaign, int $post_id ): ?string {
 		if ( empty( $image_url ) ) {
 			return null;
 		}

 		$downloaded_path = null;
 		$local_path = $this->resolve_local_path( $image_url, $downloaded_path );
 		if ( ! $local_path || ! file_exists( $local_path ) ) {
 			$this->cleanup_downloaded_source( $downloaded_path );
 			return null;
 		}

 		$image_info = getimagesize( $local_path );
 		if ( ! $image_info ) {
 			$this->cleanup_downloaded_source( $downloaded_path );
 			return null;
 		}

 		$width = (int) $image_info[0];
 		$height = (int) $image_info[1];

 		if ( $width < 200 || $height < 200 ) {
 			$this->cleanup_downloaded_source( $downloaded_path );
 			return null;
 		}

 		$detection_mode = $campaign['detection_mode'] ?? 'hybrid';
 		$zones = $this->resolve_zones( $campaign, $width, $height, $detection_mode, $local_path, $post_id );

 		if ( ! $zones || empty( $zones['image'] ) ) {
 			Logger::debug( 'image_preprocess_no_zones', $post_id, [
 				'detection_mode' => $detection_mode,
 				'width' => $width,
 				'height' => $height,
 			] );
 			$this->cleanup_downloaded_source( $downloaded_path );
 			return null;
 		}

 		$temp_dir = $this->get_temp_dir();
 		if ( ! $temp_dir ) {
 			$this->cleanup_downloaded_source( $downloaded_path );
 			return null;
 		}

		// Cloudinary Auto-Crop Path
		$cloud_name = get_option( Config::OPTION_CLOUDINARY_CLOUD_NAME );
		$api_key = get_option( Config::OPTION_CLOUDINARY_API_KEY );
		$api_secret = get_option( Config::OPTION_CLOUDINARY_API_SECRET );

		if ( ! empty( $cloud_name ) && ! empty( $api_key ) && ! empty( $api_secret ) ) {
			$cloudinary_path = $this->process_with_cloudinary( $local_path, $zones, $cloud_name, $api_key, $api_secret, $post_id );
			if ( $cloudinary_path ) {
				// Apply logo removal after Cloudinary crop.
				// Cloudinary only uses zones['image'] for c_crop — it ignores zones['logo'].
				// We must remove the logo from the cropped result using ImageMagick.
				$logo_zone = $zones['logo'] ?? null;
				$image_zone = $zones['image'] ?? null;
				if ( $logo_zone && $image_zone && $this->logo_overlaps_image( $logo_zone, $image_zone ) ) {
					$rel_logo = $this->relative_zone( $logo_zone, $image_zone );
					$convert = $this->find_convert();
					if ( $convert ) {
						$this->crop_out_logo( $cloudinary_path, $rel_logo, $convert );
					}
				}

				$this->cleanup_downloaded_source( $downloaded_path );
				Logger::info( Config::LOG_ACTION_IMAGE_PREPROCESSED, $post_id, [
					'original' => $image_url,
					'cleaned_path' => $cloudinary_path,
					'provider' => 'cloudinary',
				], '200' );
				return $cloudinary_path;
			}
			Logger::warning( 'cloudinary_preprocess_failed', $post_id, [ 'fallback' => 'hybrid' ] );
		}

		// Cloudinary returned null — fall through to ImageMagick crop path.
		// resolve_zones() was already called at the top of process(). Do NOT call it
		// again here — duplicate call wastes a Gemini token and risks overwriting a
		// valid result if quota is exhausted on the second call (Finding 1 fix).

 		$output_path = $temp_dir . '/preprocessed_' . uniqid( 'img_', true ) . '_' . getmypid() . '.jpg';

		$image_zone = $zones['image'];
		$ix1 = (int) $image_zone['x1'];
		$iy1 = (int) $image_zone['y1'];
		$iw  = (int) $image_zone['w'];
		$ih  = (int) $image_zone['h'];

		if ( $iw <= 0 || $ih <= 0 ) {
			return null;
		}

		$convert = $this->find_convert();
		if ( ! $convert ) {
			Logger::warning( 'image_preprocess_no_imagemagick', $post_id );
			return null;
		}

		$cmd = sprintf(
			'%s %s -crop %dx%d+%d+%d +repage %s',
			escapeshellarg( $convert ),
			escapeshellarg( $local_path ),
			$iw, $ih, $ix1, $iy1,
			escapeshellarg( $output_path )
		);

		exec( $cmd, $crop_output, $crop_rc );

		if ( $crop_rc !== 0 || ! file_exists( $output_path ) ) {
			@unlink( $output_path );
			Logger::error( 'image_preprocess_crop_failed', $post_id, [
				'return_code' => $crop_rc,
				'cmd' => $cmd,
			] );
			return null;
		}

		$logo_zone = $zones['logo'] ?? null;
		if ( $logo_zone && $this->logo_overlaps_image( $logo_zone, $image_zone ) ) {
			$rel_logo = $this->relative_zone( $logo_zone, $image_zone );
			$this->crop_out_logo( $output_path, $rel_logo, $convert );
		}

		if ( ! $this->validate_output( $output_path ) ) {
			@unlink( $output_path );
			Logger::warning( 'image_preprocess_validation_failed', $post_id );
			return null;
		}

		$debug_mode = (bool) get_option( Config::OPTION_IMAGE_EXTRACTION_DEBUG, false );
		if ( $debug_mode ) {
			$debug_path = $temp_dir . '/debug_zones_' . uniqid( 'dbg_', true ) . '.jpg';
			$this->save_debug_overlay( $local_path, $zones, $debug_path, $convert );
		}

		Logger::info( Config::LOG_ACTION_IMAGE_PREPROCESSED, $post_id, [
			'original' => $image_url,
			'cleaned_path' => $output_path,
			'zones' => $zones,
			'provider' => 'imagemagick',
		], '200' );

		// @MODIFIED: Clean up the temp source image after successful preprocessing.
		// The source (e.g. ris_clean_ris_*.jpg from ImageAcquisitionService) sits in
		// assets/temp/ and was never deleted, causing disk accumulation. Only delete
		// if the source is inside the plugin temp directory — never delete original
		// WordPress uploads.
		$plugin_temp_dir = AI_SOCIAL_COLLAGE_PATH . 'assets/temp';
		if ( $local_path && file_exists( $local_path ) && strpos( $local_path, $plugin_temp_dir ) === 0 ) {
			@unlink( $local_path );
		}

		return $output_path;
	}

	private function process_with_cloudinary( string $local_path, array $zones, string $cloud_name, string $api_key, string $api_secret, int $post_id ): ?string {
		$url = "https://api.cloudinary.com/v1_1/{$cloud_name}/image/upload";
		
		$args = [
			'timeout' => 30,
			'headers' => [
				'Authorization' => 'Basic ' . base64_encode( "$api_key:$api_secret" ),
			],
			'body' => [
				'file' => curl_file_create( escapeshellarg( $local_path ) ), // Safe path
				'timestamp' => time(),
			],
		];
		
		// 1. Upload to Cloudinary
		$ch = curl_init( $url );
		curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
		curl_setopt( $ch, CURLOPT_POST, true );
		curl_setopt( $ch, CURLOPT_POSTFIELDS, [
			'file' => new \CURLFile( $local_path ),
			'timestamp' => time(),
		]);
		curl_setopt( $ch, CURLOPT_USERPWD, "$api_key:$api_secret" );
		
		$response_body = curl_exec( $ch );
		$http_code = curl_getinfo( $ch, CURLINFO_HTTP_CODE );
		curl_close( $ch );

		if ( $http_code !== 200 ) {
			Logger::error( 'cloudinary_upload_failed', $post_id, [ 'response' => $response_body, 'code' => $http_code ] );
			return null;
		}

		$data = json_decode( $response_body, true );
		$public_id = $data['public_id'] ?? null;

		if ( ! $public_id ) {
			return null;
		}

		// 2. Build the perfectly cropped URL
		// Crop to the exact zone coordinates detected by AI to remove top/bottom text bands.
		// Do NOT use c_fill here — it resizes the output and breaks logo coordinate mapping
		// for crop_out_logo which runs after this step. The template uses background-size:cover
		// so the preprocessed image dimensions don't need to match the canvas exactly.
		$image_zone = $zones['image'] ?? null;
		$crop_param = '';
		if ( $image_zone && ! empty( $image_zone['w'] ) && ! empty( $image_zone['h'] ) ) {
			$ix = (int) $image_zone['x1'];
			$iy = (int) $image_zone['y1'];
			$iw = (int) $image_zone['w'];
			$ih = (int) $image_zone['h'];
			$crop_param = "c_crop,x_{$ix},y_{$iy},w_{$iw},h_{$ih}/";
		}

		$transformed_url = "https://res.cloudinary.com/{$cloud_name}/image/upload/{$crop_param}f_auto,q_auto/{$public_id}.jpg";

		// 3. Download the transformed image
		$temp_dir = $this->get_temp_dir();
		$output_path = $temp_dir . '/preprocessed_cloudinary_' . uniqid( 'img_', true ) . '.jpg';
		
		$downloaded = download_url( $transformed_url, 30 );
		if ( ! is_wp_error( $downloaded ) ) {
			@copy( $downloaded, $output_path );
			@unlink( $downloaded );
		} else {
			Logger::error( 'cloudinary_download_failed', $post_id, [ 'error' => $downloaded->get_error_message() ] );
			$output_path = null;
		}

		// 4. Destroy the original from Cloudinary to save storage credits
		$destroy_url = "https://api.cloudinary.com/v1_1/{$cloud_name}/image/destroy";
		$ch2 = curl_init( $destroy_url );
		curl_setopt( $ch2, CURLOPT_RETURNTRANSFER, true );
		curl_setopt( $ch2, CURLOPT_POST, true );
		curl_setopt( $ch2, CURLOPT_POSTFIELDS, [
			'public_id' => $public_id,
			'timestamp' => time(),
		]);
		curl_setopt( $ch2, CURLOPT_USERPWD, "$api_key:$api_secret" );
		curl_exec( $ch2 );
		curl_close( $ch2 );

		if ( $output_path && $this->validate_output( $output_path ) ) {
			return $output_path;
		}

		return null;
	}

 	private function resolve_local_path( string $image_url, ?string &$downloaded_path = null ): ?string {
 		$downloaded_path = null;

 		if ( strpos( $image_url, ABSPATH ) === 0 ) {
 			return $image_url;
 		}

 		$upload_dir = wp_upload_dir();
 		$base_url = $upload_dir['baseurl'];

 		if ( strpos( $image_url, $base_url ) === 0 ) {
 			$relative = str_replace( $base_url, '', $image_url );
 			$local = $upload_dir['basedir'] . $relative;
 			if ( file_exists( $local ) ) {
 				return $local;
 			}
 		}

 		$attachment_id = attachment_url_to_postid( $image_url );
 		if ( $attachment_id > 0 ) {
 			$path = get_attached_file( $attachment_id );
 			if ( $path && file_exists( $path ) ) {
 				return $path;
 			}
 		}

 		$temp_dir = $this->get_temp_dir();
 		if ( ! $temp_dir ) {
 			return null;
 		}

 		$downloaded = download_url( $image_url, 30 );
 		if ( is_wp_error( $downloaded ) ) {
 			Logger::warning( 'image_preprocess_download_failed', null, [
 				'url' => $image_url,
 				'error' => $downloaded->get_error_message(),
 			] );
 			return null;
 		}

 		$local_copy = $temp_dir . '/source_' . uniqid( 'src_', true ) . '.' . pathinfo( $image_url, PATHINFO_EXTENSION );
 		if ( ! @copy( $downloaded, $local_copy ) ) {
 			@unlink( $downloaded );
 			return null;
 		}
 		@unlink( $downloaded );

 		$downloaded_path = $local_copy;
 		return $local_copy;
 	}

 	private function cleanup_downloaded_source( ?string $downloaded_path ): void {
 		if ( empty( $downloaded_path ) || ! file_exists( $downloaded_path ) ) {
 			return;
 		}
 		$plugin_temp_dir = AI_SOCIAL_COLLAGE_PATH . 'assets/temp';
 		if ( strpos( $downloaded_path, $plugin_temp_dir ) === 0 ) {
 			@unlink( $downloaded_path );
 		}
 	}

	private function resolve_zones( array $campaign, int $width, int $height, string $mode, string $image_path, int $post_id = 0 ): ?array {
		$manual_zones = $this->get_manual_zones( $campaign, $width, $height );

		if ( $mode === 'manual' ) {
			return $manual_zones;
		}

		// For hybrid mode: validate manual zones FIRST before wasting API calls
		if ( $mode === 'hybrid' ) {
			if ( isset( $manual_zones['image']['y2'] ) ) {
				$trim = (int) round( $height * 0.05 );
				$manual_zones['image']['y2'] = max( 0, $manual_zones['image']['y2'] - $trim );
				$manual_zones['image']['h']  = max( 0, $manual_zones['image']['y2'] - $manual_zones['image']['y1'] );
			}
			if ( $this->validate_zones( $manual_zones, $width, $height, false ) ) {
				return $manual_zones;
			}
		}

		if ( $mode === 'auto' || $mode === 'hybrid' ) {
			$auto_zones = $this->auto_detect_zones( $image_path, $width, $height, $campaign, $post_id );
			if ( $auto_zones && $this->validate_zones( $auto_zones, $width, $height, ! empty( $auto_zones['has_social_overlay'] ) ) ) {
				return $auto_zones;
			}
			Logger::warning( 'image_preprocess_ai_failed_using_manual_zones', $post_id, [
				'mode'  => $mode,
				'auto_zones' => $auto_zones ? [
					'image_h' => $auto_zones['image']['h'] ?? null,
					'image_y2' => $auto_zones['image']['y2'] ?? null,
					'has_social_overlay' => $auto_zones['has_social_overlay'] ?? null,
				] : null,
				'note'  => 'Manual fallback zones applied with 5% conservative bottom trim to reduce band bleed.',
			] );
		}

		// Apply 5% conservative bottom trim to manual zones to reduce band bleed risk.
		// Manual zones use campaign config defaults that cannot know where a specific
		// image's text band ends. Trimming 5% off y2 guarantees some margin.
		if ( isset( $manual_zones['image']['y2'] ) ) {
			$trim = (int) round( $height * 0.05 );
			$manual_zones['image']['y2'] = max( 0, $manual_zones['image']['y2'] - $trim );
			$manual_zones['image']['h']  = max( 0, $manual_zones['image']['y2'] - $manual_zones['image']['y1'] );
		}

		// Validate manual zones - if they fail, try script-based detection as final fallback
		if ( $this->validate_zones( $manual_zones, $width, $height, ! empty( $manual_zones['has_social_overlay'] ) ) ) {
			return $manual_zones;
		}

		Logger::debug( 'manual_zones_validation_failed', $post_id, [
			'reason' => 'Manual zones failed validation, attempting script-based detection',
			'width' => $width,
			'height' => $height,
		] );

		// Fallback to script-based detection when manual zones are invalid
		$convert = $this->find_convert();
		if ( $convert && file_exists( $image_path ) ) {
			$script_zones = $this->detect_crop_with_script( $image_path, $width, $height, $campaign, $convert );
			if ( $script_zones ) {
				Logger::info( 'script_based_zones_used', $post_id, [
					'source' => 'detect_crop_with_script',
				] );
				return [
					'logo' => $script_zones['logo_position'] ?? $manual_zones['logo'],
					'text' => $manual_zones['text'],
					'image' => [
						'x1' => $script_zones['x1'],
						'y1' => $script_zones['y1'],
						'x2' => $script_zones['x2'],
						'y2' => $script_zones['y2'],
						'w' => $script_zones['x2'] - $script_zones['x1'],
						'h' => $script_zones['y2'] - $script_zones['y1'],
					],
					'has_social_overlay' => false,
				];
			}
		}

		// Last resort: return manual zones even if they fail validation
		// This prevents complete pipeline failure
		Logger::warning( 'all_zones_failed', $post_id, [
			'returning_manual_zones_despite_validation_failure' => true,
		] );
		return $manual_zones;
	}

	private function get_manual_zones( array $campaign, int $width, int $height ): array {
		$defaults = Config::DEFAULT_SOCIAL_ZONES['facebook_generic'];

		$logo_cfg = $campaign['logo_zone'] ?? $defaults['logo_zone'];
		$text_cfg = $campaign['text_zone'] ?? $defaults['text_zone'];
		$image_cfg = $campaign['image_zone'] ?? $defaults['image_zone'];

		// Respect the configured image zone height to ensure text bands are cropped
		$image_h = $image_cfg['h']; 
		
		return [
			'logo' => [
				'x1' => (int) ( $logo_cfg['x'] * $width ),
				'y1' => (int) ( $logo_cfg['y'] * $height ),
				'x2' => (int) ( ( $logo_cfg['x'] + $logo_cfg['w'] ) * $width ),
				'y2' => (int) ( ( $logo_cfg['y'] + $logo_cfg['h'] ) * $height ),
				'w'  => (int) ( $logo_cfg['w'] * $width ),
				'h'  => (int) ( $logo_cfg['h'] * $height ),
			],
			'text' => [
				'x1' => (int) ( $text_cfg['x'] * $width ),
				'y1' => (int) ( $text_cfg['y'] * $height ),
				'x2' => (int) ( ( $text_cfg['x'] + $text_cfg['w'] ) * $width ),
				'y2' => (int) ( ( $text_cfg['y'] + $text_cfg['h'] ) * $height ),
				'w'  => (int) ( $text_cfg['w'] * $width ),
				'h'  => (int) ( $text_cfg['h'] * $height ),
			],
			'image' => [
				'x1' => (int) ( $image_cfg['x'] * $width ),
				'y1' => (int) ( $image_cfg['y'] * $height ),
				'x2' => (int) ( ( $image_cfg['x'] + $image_cfg['w'] ) * $width ),
				'y2' => (int) ( ( $image_cfg['y'] + $image_h ) * $height ),
				'w'  => (int) ( $image_cfg['w'] * $width ),
				'h'  => (int) ( $image_h * $height ),
			],
			'has_social_overlay' => false,
		];
	}

	private function auto_detect_zones( string $image_path, int $width, int $height, array $campaign, int $post_id = 0 ): ?array {
		$convert = $this->find_convert();
		if ( ! $convert ) {
			return null;
		}

		$ai_result = $this->detect_crop_with_ai( $image_path, $post_id );
		$detected_logo = null;
		$has_social_overlay = false;
		if ( null !== $ai_result ) {
			// New format: {photo: {x1_pct, y1_pct, x2_pct, y2_pct}, logo: {...}, text_band: {...}}
			$photo = $ai_result['photo'];
			$crop_box = [
				'x1' => (int) ( $photo['x1_pct'] * $width / 100 ),
				'y1' => (int) ( $photo['y1_pct'] * $height / 100 ),
				'x2' => (int) ( $photo['x2_pct'] * $width / 100 ),
				'y2' => (int) ( $photo['y2_pct'] * $height / 100 ),
			];

			// Safety clamp: if Gemini returned a text_band, ensure photo zone stays out of it.
			// This prevents the crop from bleeding into headline/brand bars at top OR bottom.
			// CRITICAL: When a social overlay exists, its boundary takes priority over
			// text-band clamping. The social overlay is part of the photo content and must
			// be retained in the crop. Text-band misdetection is common when the overlay
			// text and headline text have similar content.
			$has_social_overlay = ! empty( $ai_result['social_overlay'] ) && is_array( $ai_result['social_overlay'] )
				&& isset( $ai_result['social_overlay']['y2_pct'] ) && (float) $ai_result['social_overlay']['y2_pct'] > 0;

			if ( ! empty( $ai_result['text_band'] ) && is_array( $ai_result['text_band'] ) ) {
				$tb = $ai_result['text_band'];
				
				$is_top_band = isset($tb['y2_pct']) && $tb['y2_pct'] < 50;
				$is_bottom_band = isset($tb['y1_pct']) && $tb['y1_pct'] > 50;

				// Bottom text band: clamp photo y2 to text_band y1
				if ( isset( $tb['y1_pct'] ) && $is_bottom_band ) {
					$text_band_y1 = (int) ( (float) $tb['y1_pct'] * $height / 100 );
					
					// ENHANCEMENT: AI is approximate. Use ImageMagick script to snap to exact pixel boundary.
					$exact_y1 = $this->find_exact_bottom_band_y( $image_path, $width, $height, $convert );
					if ( $exact_y1 < $height && abs($exact_y1 - $text_band_y1) < ($height * 0.15) ) {
						// The script found a band boundary within 15% of the AI's estimate. Use the exact pixel edge.
						$text_band_y1 = $exact_y1;
					}

					if ( $text_band_y1 > 0 && $crop_box['y2'] > $text_band_y1 ) {
						if ( $has_social_overlay ) {
							// Social overlay exists — only clamp if text_band is clearly below it.
							// If text_band y1 is above social_overlay y2, the text_band detection
							// is likely wrong (misdetected social overlay text as headline bar).
							$so_y2 = (int) ( (float) $ai_result['social_overlay']['y2_pct'] * $height / 100 );
							if ( $text_band_y1 >= $so_y2 ) {
								// Text band is below social overlay — safe to clamp
								$crop_box['y2'] = $text_band_y1;
							}
							// else: text band overlaps social overlay — trust social overlay, skip clamp
						} else {
							// No social overlay — standard clamping
							$crop_box['y2'] = $text_band_y1;
						}
					}
				}
				// Top text band: clamp photo y1 to text_band y2 + 1% conservative margin
				if ( isset( $tb['y2_pct'] ) && $is_top_band ) {
					$text_band_y2 = (int) ( (float) $tb['y2_pct'] * $height / 100 );
					$safe_y1 = $text_band_y2 + (int) ( $height * 0.01 );
					if ( $safe_y1 > 0 && $crop_box['y1'] < $safe_y1 ) {
						$crop_box['y1'] = $safe_y1;
					}
				}
			}

			// OFFLINE SAFETY NET: When AI didn't detect a social overlay but there's a
			// significant gap between photo y2 and text_band y1, the gap likely contains
			// an undetected social overlay. Detect it via edge variance analysis.
			if ( ! $has_social_overlay && ! empty( $ai_result['text_band'] ) && is_array( $ai_result['text_band'] ) ) {
				$tb = $ai_result['text_band'];
				if ( isset( $tb['y1_pct'] ) ) {
					$text_band_y1_px = (int) ( (float) $tb['y1_pct'] * $height / 100 );
					$gap_top = $crop_box['y2'];
					$gap_height = $text_band_y1_px - $gap_top;
					$gap_pct = $gap_height / $height;

					// Gap of 4-25% of height may contain a social overlay or inset photo.
					// Lowered from 8% to 4% to catch inset photos that sit close to the text band.
					if ( $gap_pct > 0.04 && $gap_pct < 0.25 ) {
						// Check edge variance: a social overlay has diverse content (text, avatar)
						// while empty photo space or a text band has uniform appearance
						$strip_h = max( 1, (int) $gap_height );
						$cmd = sprintf(
							'%s %s -colorspace gray -crop %dx%d+0+%d! +repage -format "%%[fx:standard_deviation]" info:',
							escapeshellarg( $convert ), escapeshellarg( $image_path ),
							$width, $strip_h, $gap_top
						);
						$out = []; @exec( $cmd, $out, $rc );
						if ( $rc === 0 && ! empty( $out[0] ) ) {
							$gap_edge = (float) $out[0];
							// Social overlays have text + avatar → higher edge variance (>0.08)
							// Uniform dark/light bands have lower variance (<0.06)
							if ( $gap_edge > 0.08 ) {
								$crop_box['y2'] = $text_band_y1_px;
								$has_social_overlay = true;
								Logger::info( 'offline_social_overlay_detected', $post_id, [
									'gap_top' => $gap_top,
									'gap_bottom' => $text_band_y1_px,
									'gap_pct' => round( $gap_pct * 100, 1 ),
									'edge_variance' => round( $gap_edge, 4 ),
								] );
							}
						}
					}
				}
			}

			// Extract AI-detected logo position (absolute pixel coordinates)
			if ( ! empty( $ai_result['logo'] ) ) {
				$detected_logo = [
					'x' => (int) ( $ai_result['logo']['x_pct'] * $width / 100 ),
					'y' => (int) ( $ai_result['logo']['y_pct'] * $height / 100 ),
					'w' => (int) ( $ai_result['logo']['w_pct'] * $width / 100 ),
					'h' => (int) ( $ai_result['logo']['h_pct'] * $height / 100 ),
				];
			}
		} else {
			$crop_box = $this->detect_crop_with_script( $image_path, $width, $height, $campaign, $convert );
			if ( null === $crop_box ) {
				return null;
			}
			$detected_logo = $crop_box['logo_position'] ?? null;

			// When photo zone is large (>85% of height), detect social overlay via edge variance
			// in the gap below the photo. This handles the case when Gemini is unavailable
			// and the offline script detects a photo that includes an overlay.
			if ( $height > 0 ) {
				$script_image_h = max( 0, $crop_box['y2'] - $crop_box['y1'] );
				$script_image_pct = $script_image_h / $height;
				if ( $script_image_pct > 0.85 ) {
					$gap_top    = (int) $crop_box['y2'];
					$gap_height = max( 0, $height - $gap_top );
					if ( $gap_height > 10 && $width > 10 ) {
						$gap_im = @imagecreatefromjpeg( $image_path );
						if ( $gap_im ) {
							$gap_gd = imagecreatetruecolor( $width, $gap_height );
							imagecopy( $gap_gd, $gap_im, 0, 0, 0, $gap_top, $width, $gap_height );
							$edge_count = 0;
							$step = max( 1, (int) ( $gap_height * $width / 200000 ) );
							for ( $gy = 1; $gy < $gap_height; $gy += $step ) {
								for ( $gx = 1; $gx < $width; $gx += $step ) {
									$rgb_c = imagecolorat( $gap_gd, $gx, $gy );
									$rgb_l = imagecolorat( $gap_gd, $gx - 1, $gy );
									$rgb_u = imagecolorat( $gap_gd, $gx, $gy - 1 );
									$diff_c_l = abs( ( ( $rgb_c >> 16 ) & 0xFF ) - ( ( $rgb_l >> 16 ) & 0xFF ) )
											  + abs( ( ( $rgb_c >> 8 ) & 0xFF ) - ( ( $rgb_l >> 8 ) & 0xFF ) )
											  + abs( ( $rgb_c & 0xFF ) - ( $rgb_l & 0xFF ) );
									$diff_c_u = abs( ( ( $rgb_c >> 16 ) & 0xFF ) - ( ( $rgb_u >> 16 ) & 0xFF ) )
											  + abs( ( ( $rgb_c >> 8 ) & 0xFF ) - ( ( $rgb_u >> 8 ) & 0xFF ) )
											  + abs( ( $rgb_c & 0xFF ) - ( $rgb_u & 0xFF ) );
									if ( $diff_c_l > 160 || $diff_c_u > 160 ) {
										$edge_count++;
									}
								}
							}
							imagedestroy( $gap_gd );
							imagedestroy( $gap_im );
							$gap_total = max( 1, (int) ( ceil( $gap_height / $step ) * ceil( $width / $step ) ) );
							$edge_ratio = $edge_count / $gap_total;
							if ( $edge_ratio > 0.08 ) {
								$has_social_overlay = true;
								if ( $post_id > 0 ) {
									error_log( sprintf(
										'[AI Social Collage] script_overlay_detected post_id=%d edge_ratio=%.4f gap_height=%d image_pct=%.4f',
										$post_id,
										$edge_ratio,
										$gap_height,
										$script_image_pct
									) );
								}
							}
						}
					}
				}
			}
		}

		$image_h = max(1, $crop_box['y2'] - $crop_box['y1']);
		$image_w = max(1, $crop_box['x2'] - $crop_box['x1']);
		$text_y1 = $crop_box['y2'];

		$defaults = Config::DEFAULT_SOCIAL_ZONES['facebook_generic'];
		$logo_cfg = $campaign['logo_zone'] ?? $defaults['logo_zone'];

		$logo_x1 = (int) ( $logo_cfg['x'] * $width );
		$logo_y1 = (int) ( $logo_cfg['y'] * $height );
		$logo_w  = (int) ( $logo_cfg['w'] * $width );
		$logo_h  = (int) ( $logo_cfg['h'] * $height );

		// Use detected logo position if available, otherwise use config defaults
		if ( $detected_logo ) {
			$logo_x1 = (int) $detected_logo['x'];
			$logo_y1 = (int) $detected_logo['y'];
			$logo_w  = (int) $detected_logo['w'];
			$logo_h  = (int) $detected_logo['h'];
		}

		return [
			'logo' => [
				'x1' => $logo_x1,
				'y1' => $logo_y1,
				'x2' => $logo_x1 + $logo_w,
				'y2' => $logo_y1 + $logo_h,
				'w'  => $logo_w,
				'h'  => $logo_h,
			],
			'text' => [
				'x1' => 0,
				'y1' => $text_y1,
				'x2' => $width,
				'y2' => $height,
				'w'  => $width,
				'h'  => max(0, $height - $text_y1),
			],
			'image' => [
				'x1' => $crop_box['x1'],
				'y1' => $crop_box['y1'],
				'x2' => $crop_box['x2'],
				'y2' => $crop_box['y2'],
				'w'  => $image_w,
				'h'  => $image_h,
			],
			'has_social_overlay' => $has_social_overlay,
		];
	}
	private function detect_crop_with_ai( string $image_path, int $post_id ): ?array {
		$prompt = "You are analyzing a social media news collage image to find the clean photo area.

CRITICAL RULE: If you see ANY box/card with a profile picture, avatar, username, or social media post text overlaid on the photograph, you MUST include it in the PHOTO zone. These social overlays (Instagram posts, Twitter/X posts, Facebook comments, TikTok captions, etc.) are part of the content and must NOT be cropped out.

CRITICAL RULE 2: If you see an INSET PHOTO (a smaller rectangular photo embedded within the main image — showing a different angle, scene, or group of people), the ENTIRE inset photo MUST be included within the PHOTO zone. Inset photos are editorial collage content and must NOT be cropped out. The PHOTO zone y2 must extend at least to the BOTTOM of the inset photo.

STEP 1 — IDENTIFY these elements:
- PHOTO: The main photograph (person, place, thing). INCLUDES any inset photos / secondary photos / collage panels embedded within the main image.
- INSET_PHOTO: A smaller rectangular image embedded within the main photo area. It may show a different scene, group of people, or angle. It is NOT a social media overlay (no profile pic, no username). It IS editorial content and MUST be fully included in the PHOTO zone.
- SOCIAL_OVERLAY: Any overlaid box/card containing a profile pic, username, and text content. Examples: Instagram post screenshot, Twitter/X tweet box, Facebook comment card, TikTok caption overlay. These can have ANY background color (white, dark, transparent, colored). They sit ON TOP of the photo. DO NOT confuse these with headline bars.
- TEXT_BAND: The news headline bar, ticker, or brand name bar — typically at the very bottom with LARGE bold text, solid/gradient background, and a brand name. This is NOT a social media overlay.
- LOGO: Channel logo, watermark, or branding badge.

STEP 2 — RETURN bounding boxes as float percentages (0.0-100.0):

The PHOTO zone MUST extend to include:
1. ANY social overlay that sits on the photo
2. ANY inset photo / secondary photo / collage panel (the ENTIRE inset must be inside the photo zone)
- photo y2 = bottom of the lowest social overlay OR inset photo (whichever is lower), or bottom of photo if neither exists
- photo y1 = top of the photo (or below any top text band)
- EXCLUDE only the TEXT_BAND (headline bar) and LOGO from the photo zone

Return ONLY valid JSON with ALL fields (return a SINGLE JSON object, NOT an array):
{\"photo\":{\"x1_pct\":0.0,\"y1_pct\":0.0,\"x2_pct\":100.0,\"y2_pct\":80.0},\"social_overlay\":{\"x1_pct\":55.0,\"y1_pct\":50.0,\"x2_pct\":98.0,\"y2_pct\":79.0},\"logo\":null,\"text_band\":{\"x1_pct\":0.0,\"y1_pct\":82.0,\"x2_pct\":100.0,\"y2_pct\":95.0}}

IMPORTANT: social_overlay MUST be the bounding box of the overlay card itself (NOT null when an overlay exists). Only return null if there is absolutely no social media overlay on the photo.
IMPORTANT: When an inset photo exists, report it in the social_overlay field even if it has no social media chrome — the system uses this field to ensure the photo zone extends to include it."; 

		// Layer 1: Google Gemini (Primary AI)
		$crop = $this->try_ai_provider( \AiSocialCollage\Config::PROVIDER_GEMINI, $image_path, $prompt, $post_id );
		if ( $crop ) return $crop;

		// Layer 2: Custom Providers (OpenRouter, Groq, etc)
		$custom_providers = \AiSocialCollage\Config::get_custom_providers();
		foreach ( $custom_providers as $cp ) {
			if ( empty( $cp['id'] ) ) {
				continue;
			}
			$crop = $this->try_ai_provider( $cp['id'], $image_path, $prompt, $post_id );
			if ( $crop ) return $crop;
		}

		return null;
	}

	private function try_ai_provider( string $provider_name, string $image_path, string $prompt, int $post_id ): ?array {
		try {
			$provider = \AiSocialCollage\Services\AIProviderRegistry::get_provider_instance( $provider_name );
		} catch ( \Throwable $e ) {
			Logger::warning( "crop_failed_init_{$provider_name}", $post_id, [ 'error' => $e->getMessage() ] );
			return null;
		}

		$example_images = [];
		$examples_dir = AI_SOCIAL_COLLAGE_PATH . 'assets/crop-examples';
		if ( is_dir( $examples_dir ) ) {
			$files = glob( $examples_dir . '/image-*.jpg' );
			if ( $files ) {
				$example_images = array_slice( $files, 0, 3 );
			}
		}

		$context = [
			'caller' => "ImagePreprocessor::detect_crop_{$provider_name}",
			'image_path' => $image_path,
			'post_id' => $post_id,
			'example_images' => $example_images,
		];

		$max_retries = 3;
		$last_error = null;

		for ( $attempt = 1; $attempt <= $max_retries; $attempt++ ) {
			try {
				$result = \AiSocialCollage\Services\AIProviderRegistry::execute( $provider, '', $prompt, $context );
				if ( ! is_array( $result ) ) {
					$last_error = 'Invalid response: not an array';
					$error_info = new \AiSocialCollage\Services\APIErrorInfo(
						\AiSocialCollage\Services\APIErrorInfo::TYPE_UNKNOWN,
						$last_error,
						$provider_name
					);
					\AiSocialCollage\Services\QuotaStateManager::record_failure( $provider_name, $error_info );
					continue;
				}

			if ( isset( $result[0] ) && is_array( $result[0] ) && array_key_exists( 'photo', $result[0] ) ) {
				$result = end( $result );
			}

			$photo = $result['photo'] ?? $result['crop'] ?? null;
			if ( ! is_array( $photo ) || ! isset( $photo['x1_pct'] ) || ! isset( $photo['y1_pct'] ) || ! isset( $photo['x2_pct'] ) || ! isset( $photo['y2_pct'] ) ) {
				$last_error = 'Invalid photo JSON format';
				$error_info = new \AiSocialCollage\Services\APIErrorInfo(
					\AiSocialCollage\Services\APIErrorInfo::TYPE_UNKNOWN,
					$last_error,
					$provider_name
				);
				\AiSocialCollage\Services\QuotaStateManager::record_failure( $provider_name, $error_info );
				continue;
			}

			$normalized = [
				'photo' => [
					'x1_pct' => max( 0.0, min( 100.0, (float) $photo['x1_pct'] ) ),
					'y1_pct' => max( 0.0, min( 100.0, (float) $photo['y1_pct'] ) ),
					'x2_pct' => max( 0.0, min( 100.0, (float) $photo['x2_pct'] ) ),
					'y2_pct' => max( 0.0, min( 100.0, (float) $photo['y2_pct'] ) ),
				],
				'logo'           => null,
				'text_band'      => null,
				'social_overlay' => null,
			];

			if ( ! empty( $result['social_overlay'] ) && is_array( $result['social_overlay'] )
				&& isset( $result['social_overlay']['x1_pct'] ) && isset( $result['social_overlay']['y1_pct'] ) ) {
				$overlay_y2 = isset( $result['social_overlay']['y2_pct'] ) ? (float) $result['social_overlay']['y2_pct'] : 0.0;
				if ( $overlay_y2 > 0 ) {
					$normalized['social_overlay'] = [
						'x1_pct' => max( 0.0, min( 100.0, (float) $result['social_overlay']['x1_pct'] ) ),
						'y1_pct' => max( 0.0, min( 100.0, (float) $result['social_overlay']['y1_pct'] ) ),
						'x2_pct' => max( 0.0, min( 100.0, (float) ( $result['social_overlay']['x2_pct'] ?? 100.0 ) ) ),
						'y2_pct' => max( 0.0, min( 100.0, $overlay_y2 ) ),
					];

					if ( $overlay_y2 > $normalized['photo']['y2_pct'] ) {
						$normalized['photo']['y2_pct'] = $overlay_y2;
					}
				}
			}

			if ( $normalized['photo']['y2_pct'] <= $normalized['photo']['y1_pct'] || $normalized['photo']['x2_pct'] <= $normalized['photo']['x1_pct'] ) {
				$last_error = 'Invalid crop: degenerate dimensions';
				$error_info = new \AiSocialCollage\Services\APIErrorInfo(
					\AiSocialCollage\Services\APIErrorInfo::TYPE_REQUEST_SHAPE,
					$last_error,
					$provider_name
				);
				\AiSocialCollage\Services\QuotaStateManager::record_failure( $provider_name, $error_info );
				continue;
			}

			if ( ! empty( $result['logo'] ) && is_array( $result['logo'] ) ) {
				if ( isset( $result['logo']['x1_pct'] ) && isset( $result['logo']['y1_pct'] ) ) {
					$w_pct = max( 0.0, (float) ($result['logo']['x2_pct'] ?? 100.0) - (float) $result['logo']['x1_pct'] );
					$h_pct = max( 0.0, (float) ($result['logo']['y2_pct'] ?? 100.0) - (float) $result['logo']['y1_pct'] );
					$normalized['logo'] = [
						'x_pct' => max( 0.0, min( 100.0, (float) $result['logo']['x1_pct'] ) ),
						'y_pct' => max( 0.0, min( 100.0, (float) $result['logo']['y1_pct'] ) ),
						'w_pct' => max( 0.0, min( 50.0, $w_pct ) ),
						'h_pct' => max( 0.0, min( 30.0, $h_pct ) ),
					];
				} elseif ( isset( $result['logo']['x_pct'] ) && isset( $result['logo']['y_pct'] ) ) {
					$normalized['logo'] = [
						'x_pct' => max( 0.0, min( 100.0, (float) $result['logo']['x_pct'] ) ),
						'y_pct' => max( 0.0, min( 100.0, (float) $result['logo']['y_pct'] ) ),
						'w_pct' => max( 0.0, min( 50.0, (float) ( $result['logo']['w_pct'] ?? 10.0 ) ) ),
						'h_pct' => max( 0.0, min( 30.0, (float) ( $result['logo']['h_pct'] ?? 5.0 ) ) ),
					];
				}
			}

			if ( ! empty( $result['text_band'] ) && is_array( $result['text_band'] ) && isset( $result['text_band']['x1_pct'] ) && isset( $result['text_band']['y1_pct'] ) ) {
				$normalized['text_band'] = [
					'x1_pct' => max( 0.0, min( 100.0, (float) $result['text_band']['x1_pct'] ) ),
					'y1_pct' => max( 0.0, min( 100.0, (float) $result['text_band']['y1_pct'] ) ),
					'x2_pct' => max( 0.0, min( 100.0, (float) ( $result['text_band']['x2_pct'] ?? 100.0 ) ) ),
					'y2_pct' => max( 0.0, min( 100.0, (float) ( $result['text_band']['y2_pct'] ?? 100.0 ) ) ),
				];
			}

			Logger::info( "crop_success_{$provider_name}", $post_id, [ 'photo' => $normalized['photo'], 'social_overlay' => $normalized['social_overlay'], 'logo' => $normalized['logo'], 'attempt' => $attempt ] );

			\AiSocialCollage\Services\QuotaStateManager::record_success( $provider_name );
				return $normalized;
			} catch ( \Exception $e ) {
				$last_error = $e->getMessage();

				$http_code = 0;
				if ( preg_match( '/HTTP (\d{3})/', $last_error, $m ) ) {
					$http_code = (int) $m[1];
				}

				$error_info = \AiSocialCollage\Services\APIErrorParser::parse( $provider_name, $http_code, '', $last_error );

				\AiSocialCollage\Services\QuotaStateManager::record_failure( $provider_name, $error_info );

 				if ( ! $error_info->is_retryable ) {
 					if ( $error_info->is_deterministic ) {
 						\AiSocialCollage\Services\ProviderCooldown::set_cooldown( $provider_name, 120, $error_info->error_type );
 					}
 					break;
 				}

 				$retry_after = $error_info->get_retry_after();
 				if ( $error_info->is_daily_quota() ) {
 					$reset_at = $error_info->get_reset_at_ts();
 					if ( $reset_at <= 0 ) {
 						$reset_at = time() + 3600;
 					}
 					\AiSocialCollage\Services\ProviderCooldown::set_daily_quota( $provider_name, $reset_at );
 					break;
 				}
 				if ( $error_info->is_quota_error() ) {
 					\AiSocialCollage\Services\ProviderCooldown::set_cooldown( $provider_name, max( $retry_after, 120 ), $error_info->error_type );
 					break;
 				}

			if ( $attempt < $max_retries ) {
				$delay = $retry_after > 0 ? $retry_after : max( 1, pow( 2, $attempt ) );
				throw new \Exception( "HTTP 429 Rate limited by {$provider_name}, retry_after={$delay}s", 429 );
			}
				break;
			}
		}

		Logger::warning( "crop_exhausted_{$provider_name}", $post_id, [ 'error' => $last_error ] );
		return null;
	}

	private function detect_crop_with_script( string $image_path, int $width, int $height, array $campaign, string $convert ): ?array {
		$dark_thresh = (float) ( $campaign['dark_band_threshold'] ?? 0.25 );
		$strip_height = max( 1, (int) ( $height / 100 ) );
		$strip_width  = max( 1, (int) ( $width / 80 ) );

		// CRITICAL: Only scan the top 15% and bottom 20% of the image for text bands.
		// Previous scan ranges (top 60%, bottom 50%) caused social media overlays
		// at 50-80% height to be falsely detected as "bands" and cropped out.
		// Social overlays sit ON the photo and must be retained.
		// Text bands (headline bars, tickers) are always at the very top or very bottom.
		$scan_limit_top    = (int) ( $height * 0.15 );
		$scan_limit_bottom = (int) ( $height * 0.60 );

		// ── PASS 1: Per-row brightness + edge-density scan ─────────────────
		// Detects text bands by low edge variance and dark-text-uniform regions.
		$row_means = [];
		$row_edges = [];
		for ( $y = 0; $y < $height; $y += $strip_height ) {
			$cmd = sprintf(
				'%s %s -colorspace gray -crop %dx%d+0+%d! +repage -format "%%[fx:mean]" info:',
				escapeshellarg( $convert ), escapeshellarg( $image_path ), $width, $strip_height, $y
			);
			$out = []; @exec( $cmd, $out, $rc );
			if ( $rc === 0 && ! empty( $out[0] ) ) {
				$row_means[ $y ] = (float) $out[0];
			}
			$cmd2 = sprintf(
				'%s %s -colorspace gray -crop %dx%d+0+%d! +repage -format "%%[fx:standard_deviation]" info:',
				escapeshellarg( $convert ), escapeshellarg( $image_path ), $width, $strip_height, $y
			);
			$out2 = []; @exec( $cmd2, $out2, $rc2 );
			if ( $rc2 === 0 && ! empty( $out2[0] ) ) {
				$row_edges[ $y ] = (float) $out2[0];
			}
		}

		if ( empty( $row_means ) ) return null;

		// Combined band detector — catches all text-band types:
		// - Pure dark bands (black, near-black, very dark blue)
		// - Pure bright/white bands (white text bar backgrounds)
		// - Mixed bands: dark blue background + white text averages to ~0.35-0.50 mean
		//   with low edge variance. The (int) threshold of 0.25 misses these entirely.
		// - Colored bands: green/red/yellow background with Urdu/Arabic text.
		//   These have mean ~0.3-0.6 and edge ~0.06-0.12 due to text variance.
		// NOTE: Scan range is now limited to top 15% / bottom 20%, so we can be more
		// aggressive — social overlays at 50-80% are outside the scan range.
		$is_band = function( $mean, $edge ) use ( $dark_thresh ) {
			if ( $mean < $dark_thresh ) return true;         // Pure dark band
			if ( $mean > 0.80 ) return true;                 // Pure bright/white band
			if ( $edge < 0.06 ) return true;                 // Very uniform region (any brightness)
			if ( $edge < 0.12 && $mean < 0.55 ) return true; // Low-variance dark zone (dark blue+white text, colored bands)
			return false;
		};

		// Top-down: find first run of photo rows
		$top_band_end = 0;
		$image_top = 0;
		$consecutive = 0;
		foreach ( $row_means as $y => $mean ) {
			if ( $y > $scan_limit_top ) break;
			$edge = $row_edges[ $y ] ?? 0.5;
			if ( $is_band( $mean, $edge ) ) {
				$top_band_end = $y + $strip_height;
				$consecutive = 0;
			} else {
				$consecutive++;
				if ( $consecutive > 3 ) { // Require 4 consecutive non-band rows before committing
					$image_top = $top_band_end;
					break;
				}
			}
		}

		// Bottom-up
		$bottom_band_start = $height;
		$image_bottom = $height;
		$consecutive = 0;
		$y_keys = array_keys( $row_means );
		rsort( $y_keys );
		foreach ( $y_keys as $y ) {
			if ( $y < $scan_limit_bottom ) break;
			$edge = $row_edges[ $y ] ?? 0.5;
			if ( $is_band( $row_means[ $y ], $edge ) ) {
				$bottom_band_start = $y;
				$consecutive = 0;
			} else {
				$consecutive++;
				if ( $consecutive > 3 ) { // Require 4 consecutive non-band rows before committing
					$image_bottom = $bottom_band_start;
					break;
				}
			}
		}
		if ( $bottom_band_start < $height && $consecutive <= 3 ) {
			$image_bottom = $bottom_band_start;
		}

		// ── PASS 2: Corner-region logo scan ────────────────────────────────
		// Detects low-edge uniform extensions beyond the main photo top.
		$detected_logo_corner = null;
		$corner_w = (int) ( $width * 0.12 );
		$corner_h = (int) ( $height * 0.06 );
		$corners = [
			[ 'x' => 0,                'y' => 0 ],
			[ 'x' => $width - $corner_w, 'y' => 0 ],
		];
		foreach ( $corners as $c ) {
			if ( $c['y'] >= $image_bottom || $c['y'] + $corner_h <= $image_top ) continue;
			$cmd = sprintf(
				'%s %s -crop %dx%d+%d+%d! +repage -colorspace gray -format "%%[fx:standard_deviation]" info:',
				escapeshellarg( $convert ), escapeshellarg( $image_path ),
				$corner_w, $corner_h, $c['x'], $c['y']
			);
			$out = []; @exec( $cmd, $out, $rc );
			if ( $rc === 0 && ! empty( $out[0] ) ) {
				$corner_edge = (float) $out[0];
				if ( $corner_edge < 0.12 && $c['y'] + $corner_h > $image_top && $c['y'] < $image_top + $corner_h ) {
					$image_top = $c['y'] + $corner_h;
					$detected_logo_corner = [
						'x' => $c['x'],
						'y' => $c['y'],
						'w' => $corner_w,
						'h' => $corner_h,
						'edge' => $corner_edge,
					];
				}
			}
		}

		// ── PASS 3: Vertical edge scan for side collages ──────────────────
		$left_band_end  = 0;
		$right_band_start = $width;
		for ( $x = 0; $x < (int) ( $width * 0.25 ); $x += $strip_width ) {
			$cmd = sprintf(
				'%s %s -colorspace gray -crop %dx%d+%d+%d! +repage -format "%%[fx:standard_deviation]" info:',
				escapeshellarg( $convert ), escapeshellarg( $image_path ),
				$strip_width, $height, $x, $image_top
			);
			$out = []; @exec( $cmd, $out, $rc );
			$edge = ( $rc === 0 && ! empty( $out[0] ) ) ? (float) $out[0] : 0.5;
			if ( $edge < 0.03 ) {
				$left_band_end = $x + $strip_width;
			} else {
				break;
			}
		}
		for ( $x = $width - $strip_width; $x > (int) ( $width * 0.75 ); $x -= $strip_width ) {
			$cmd = sprintf(
				'%s %s -colorspace gray -crop %dx%d+%d+%d! +repage -format "%%[fx:standard_deviation]" info:',
				escapeshellarg( $convert ), escapeshellarg( $image_path ),
				$strip_width, $height, $x, $image_top
			);
			$out = []; @exec( $cmd, $out, $rc );
			$edge = ( $rc === 0 && ! empty( $out[0] ) ) ? (float) $out[0] : 0.5;
			if ( $edge < 0.03 ) {
				$right_band_start = $x;
			} else {
				break;
			}
		}

		// Validate minimum photo area
		$photo_w = $right_band_start - $left_band_end;
		$photo_h = $image_bottom - $image_top;
		if ( $photo_w < ( $width * 0.50 ) || $photo_h < ( $height * 0.20 ) ) {
			return null;
		}

		return [
			'x1' => $left_band_end,
			'y1' => $image_top,
			'x2' => $right_band_start,
			'y2' => $image_bottom,
			'logo_position' => $detected_logo_corner,
		];
	}

	private function find_exact_bottom_band_y( string $image_path, int $width, int $height, string $convert ): int {
		$strip_height = max( 1, (int) ( $height / 100 ) );
		$scan_limit_bottom = (int) ( $height * 0.60 ); // Scan bottom 40%

		$row_means = [];
		$row_edges = [];
		// Extract rows from bottom up
		for ( $y = $height - $strip_height; $y >= $scan_limit_bottom; $y -= $strip_height ) {
			$cmd = sprintf(
				'%s %s -colorspace gray -crop %dx%d+0+%d! +repage -format "%%[fx:mean],%%[fx:standard_deviation]" info:',
				escapeshellarg( $convert ), escapeshellarg( $image_path ), $width, $strip_height, $y
			);
			$out = []; @exec( $cmd, $out, $rc );
			if ( $rc === 0 && ! empty( $out[0] ) ) {
				$parts = explode(',', $out[0]);
				if (count($parts) == 2) {
					$row_means[ $y ] = (float) $parts[0];
					$row_edges[ $y ] = (float) $parts[1];
				}
			}
		}

		$is_band = function( $mean, $edge ) {
			if ( $mean < 0.25 ) return true;         // Pure dark band
			if ( $mean > 0.80 ) return true;         // Pure bright/white band
			if ( $edge < 0.06 ) return true;         // Very uniform region
			if ( $edge < 0.12 && $mean < 0.55 ) return true; // Low-variance dark zone
			return false;
		};

		$bottom_band_start = $height;
		$image_bottom = $height;
		$consecutive = 0;
		$y_keys = array_keys( $row_means );
		rsort( $y_keys );
		foreach ( $y_keys as $y ) {
			$edge = $row_edges[ $y ] ?? 0.5;
			if ( $is_band( $row_means[ $y ], $edge ) ) {
				$bottom_band_start = $y;
				$consecutive = 0;
			} else {
				$consecutive++;
				if ( $consecutive > 3 ) { // Require 4 consecutive non-band rows
					$image_bottom = $bottom_band_start;
					break;
				}
			}
		}
		if ( $bottom_band_start < $height && $consecutive <= 3 ) {
			$image_bottom = $bottom_band_start;
		}
		return $image_bottom;
	}

	private function validate_zones( array $zones, int $width, int $height, bool $has_social_overlay = false ): bool {
		$image_zone = $zones['image'] ?? [];
		$image_h    = $image_zone['h']  ?? 0;
		$image_y2   = $image_zone['y2'] ?? $height;

		if ( $image_h <= 0 ) {
			Logger::debug( 'validate_zones_reject', null, [ 'reason' => 'image_h <= 0', 'image_h' => $image_h, 'height' => $height ] );
			return false;
		}

		$image_pct = $image_h / $height;
		// Zone must cover at least 25% of height. Zones covering >92% almost certainly
		// include a text band — reject them so the manual fallback (with 5% trim) is used.
		// When social overlay is detected, raise cap to 96% because the overlay legitimately
		// extends the photo zone toward the bottom of the image.
		$max_pct = $has_social_overlay ? 0.96 : 0.92;
		if ( $image_pct < 0.25 || $image_pct > $max_pct ) {
			Logger::debug( 'validate_zones_reject', null, [ 'reason' => 'image_pct out of range', 'image_pct' => round( $image_pct, 4 ), 'max_pct' => $max_pct, 'has_social_overlay' => $has_social_overlay, 'image_h' => $image_h, 'height' => $height ] );
			return false;
		}

		// The zone bottom must leave clearance from the image bottom.
		// Standard: 6%. With social overlay: 2% — overlays can sit near the bottom edge.
		$min_clearance = $has_social_overlay ? 0.02 : 0.06;
		$bottom_clearance = ( $height - $image_y2 ) / $height;
		if ( $bottom_clearance < $min_clearance ) {
			Logger::debug( 'validate_zones_reject', null, [ 'reason' => 'bottom_clearance too small', 'bottom_clearance' => round( $bottom_clearance, 4 ), 'min_clearance' => $min_clearance, 'image_y2' => $image_y2, 'height' => $height ] );
			return false;
		}

		return true;
	}

	private function logo_overlaps_image( array $logo_zone, array $image_zone ): bool {
		return (
			$logo_zone['y2'] > $image_zone['y1'] &&
			$logo_zone['y1'] < $image_zone['y2'] &&
			$logo_zone['x2'] > $image_zone['x1'] &&
			$logo_zone['x1'] < $image_zone['x2']
		);
	}

	private function relative_zone( array $zone, array $parent_zone ): array {
		return [
			'x1' => max( 0, $zone['x1'] - $parent_zone['x1'] ),
			'y1' => max( 0, $zone['y1'] - $parent_zone['y1'] ),
			'x2' => min( $zone['x2'] - $parent_zone['x1'], $parent_zone['w'] ),
			'y2' => min( $zone['y2'] - $parent_zone['y1'], $parent_zone['h'] ),
		];
	}

	private function crop_out_logo( string $image_path, array $rel_logo, string $convert ): bool {
		$lx1 = (int) $rel_logo['x1'];
		$ly1 = (int) $rel_logo['y1'];
		$lx2 = (int) $rel_logo['x2'];
		$ly2 = (int) $rel_logo['y2'];

		$image_info = getimagesize( $image_path );
		if ( ! $image_info ) {
			return false;
		}
		$img_w = (int) $image_info[0];
		$img_h = (int) $image_info[1];

		$logo_w = $lx2 - $lx1;
		$logo_h = $ly2 - $ly1;

		if ( $logo_w <= 0 || $logo_h <= 0 ) {
			return false;
		}

		// Guard: if the logo zone exceeds 35% of the image in either dimension,
		// it is a default/fallback zone (e.g. full-width top strip), not an actual
		// detected logo. Filling it would destroy valid photo content.
		if ( $logo_w > ( $img_w * 0.35 ) || $logo_h > ( $img_h * 0.35 ) ) {
			return false;
		}

		// ── PER-PIXEL BILINEAR INPAINTING WITH NOISE (SAFE MODE) ─────────────────
		//
		// Why Clone Stamp failed: If the AI logo detection box is slightly too small, 
		// the "adjacent" patch actually contains the rest of the logo, causing it to 
		// duplicate the logo.
		//
		// Why original Bilinear failed: If the box is tight, sampling the immediate 
		// 1-px border samples the logo's glowing edge, smearing the logo color (e.g. pink) 
		// across the whole box. Also, a mathematically smooth box looks like a blurry smudge.
		//
		// Fix: 
		// 1. Sample pixels from a WIDE margin (e.g., 6 pixels OUTSIDE the bounding box) 
		//    to guarantee we don't sample the logo's anti-aliased edge.
		// 2. Add synthetic camera noise (grain) to the gradient to break the smoothness.
		// ─────────────────────────────────────────────────────────────────────────

		$mime = $image_info['mime'] ?? null;
		$im   = null;
		switch ( $mime ) {
			case 'image/jpeg': $im = @imagecreatefromjpeg( $image_path ); break;
			case 'image/png':  $im = @imagecreatefrompng( $image_path );  break;
			case 'image/webp':
				if ( function_exists( 'imagecreatefromwebp' ) ) {
					$im = @imagecreatefromwebp( $image_path );
				}
				break;
		}

		if ( ! $im ) {
			return $this->fill_logo_with_mean_color_imagemagick(
				$image_path, $lx1, $ly1, $logo_w, $logo_h, $img_w, $img_h, $convert
			);
		}

		// 1. Expand the user's manual zone to engulf any shadows/glows/anti-aliasing
		//    around the logo. A pad of 4 pixels ensures the boundaries we sample are
		//    100% clean background, and the interpolation covers the glow.
		$pad = 4;
		$ex1 = $lx1 - $pad;
		$ey1 = $ly1 - $pad;
		$ex2 = $lx2 + $pad;
		$ey2 = $ly2 + $pad;

		// 2. Define the exact boundary pixels we will sample from.
		$bx1 = $ex1 - 1;
		$by1 = $ey1 - 1;
		$bx2 = $ex2 + 1;
		$by2 = $ey2 + 1;

		$has_top = ( $by1 >= 0 );
		$has_bot = ( $by2 < $img_h );
		$has_lft = ( $bx1 >= 0 );
		$has_rgt = ( $bx2 < $img_w );

		$top_px = null; $bot_px = null; $lft_px = null; $rgt_px = null;

		// Sample the top boundary row
		if ( $has_top ) {
			$top_px = [];
			for ( $x = max( 0, $ex1 ); $x <= min( $img_w - 1, $ex2 ); $x++ ) {
				$p = imagecolorat( $im, $x, $by1 );
				$top_px[$x] = [ ( $p >> 16 ) & 0xFF, ( $p >> 8 ) & 0xFF, $p & 0xFF ];
			}
		}
		// Sample the bottom boundary row
		if ( $has_bot ) {
			$bot_px = [];
			for ( $x = max( 0, $ex1 ); $x <= min( $img_w - 1, $ex2 ); $x++ ) {
				$p = imagecolorat( $im, $x, $by2 );
				$bot_px[$x] = [ ( $p >> 16 ) & 0xFF, ( $p >> 8 ) & 0xFF, $p & 0xFF ];
			}
		}
		// Sample the left boundary column
		if ( $has_lft ) {
			$lft_px = [];
			for ( $y = max( 0, $ey1 ); $y <= min( $img_h - 1, $ey2 ); $y++ ) {
				$p = imagecolorat( $im, $bx1, $y );
				$lft_px[$y] = [ ( $p >> 16 ) & 0xFF, ( $p >> 8 ) & 0xFF, $p & 0xFF ];
			}
		}
		// Sample the right boundary column
		if ( $has_rgt ) {
			$rgt_px = [];
			for ( $y = max( 0, $ey1 ); $y <= min( $img_h - 1, $ey2 ); $y++ ) {
				$p = imagecolorat( $im, $bx2, $y );
				$rgt_px[$y] = [ ( $p >> 16 ) & 0xFF, ( $p >> 8 ) & 0xFF, $p & 0xFF ];
			}
		}

		// 3. Fallback mean color
		$all = [];
		foreach ( [ $top_px, $bot_px, $lft_px, $rgt_px ] as $b ) {
			if ( $b ) { foreach ( $b as $c ) { $all[] = $c; } }
		}
		
		$fb_r = 128; $fb_g = 128; $fb_b = 128;
		if ( count( $all ) > 0 ) {
			$r_sum = 0; $g_sum = 0; $b_sum = 0;
			foreach ( $all as $c ) { $r_sum += $c[0]; $g_sum += $c[1]; $b_sum += $c[2]; }
			$fb_r = (int)( $r_sum / count( $all ) );
			$fb_g = (int)( $g_sum / count( $all ) );
			$fb_b = (int)( $b_sum / count( $all ) );
		} elseif ( ! $has_top && ! $has_bot && ! $has_lft && ! $has_rgt ) {
			imagedestroy( $im );
			return $this->fill_logo_with_mean_color_imagemagick(
				$image_path, $lx1, $ly1, $logo_w, $logo_h, $img_w, $img_h, $convert
			);
		}

		// 4. Fill loop bounds (clamped safely to image dimensions)
		$fill_x1 = max( 0, $ex1 );
		$fill_y1 = max( 0, $ey1 );
		$fill_x2 = min( $img_w - 1, $ex2 );
		$fill_y2 = min( $img_h - 1, $ey2 );

		// The distance between the left boundary (bx1) and right boundary (bx2)
		$width_total  = (float) max( 1, $bx2 - $bx1 );
		// The distance between the top boundary (by1) and bottom boundary (by2)
		$height_total = (float) max( 1, $by2 - $by1 );

		for ( $y = $fill_y1; $y <= $fill_y2; $y++ ) {
			// Mathematical distance from the top boundary
			$ty = min( 1.0, max( 0.0, ( $y - $by1 ) / $height_total ) );

			for ( $x = $fill_x1; $x <= $fill_x2; $x++ ) {
				// Mathematical distance from the left boundary
				$tx = min( 1.0, max( 0.0, ( $x - $bx1 ) / $width_total ) );

				$h_r = $h_g = $h_b = -1;
				if ( $has_lft && $has_rgt ) {
					$l = $lft_px[$y]; $r = $rgt_px[$y];
					$h_r = $l[0] + ( $r[0] - $l[0] ) * $tx;
					$h_g = $l[1] + ( $r[1] - $l[1] ) * $tx;
					$h_b = $l[2] + ( $r[2] - $l[2] ) * $tx;
				} elseif ( $has_lft ) {
					$h_r = $lft_px[$y][0]; $h_g = $lft_px[$y][1]; $h_b = $lft_px[$y][2];
				} elseif ( $has_rgt ) {
					$h_r = $rgt_px[$y][0]; $h_g = $rgt_px[$y][1]; $h_b = $rgt_px[$y][2];
				}

				$v_r = $v_g = $v_b = -1;
				if ( $has_top && $has_bot ) {
					$t = $top_px[$x]; $b = $bot_px[$x];
					$v_r = $t[0] + ( $b[0] - $t[0] ) * $ty;
					$v_g = $t[1] + ( $b[1] - $t[1] ) * $ty;
					$v_b = $t[2] + ( $b[2] - $t[2] ) * $ty;
				} elseif ( $has_top ) {
					$v_r = $top_px[$x][0]; $v_g = $top_px[$x][1]; $v_b = $top_px[$x][2];
				} elseif ( $has_bot ) {
					$v_r = $bot_px[$x][0]; $v_g = $bot_px[$x][1]; $v_b = $bot_px[$x][2];
				}

				if ( $h_r >= 0 && $v_r >= 0 ) {
					$fr = ( $h_r + $v_r ) / 2;
					$fg = ( $h_g + $v_g ) / 2;
					$fb = ( $h_b + $v_b ) / 2;
				} elseif ( $h_r >= 0 ) {
					$fr = $h_r; $fg = $h_g; $fb = $h_b;
				} elseif ( $v_r >= 0 ) {
					$fr = $v_r; $fg = $v_g; $fb = $v_b;
				} else {
					$fr = $fb_r; $fg = $fb_g; $fb = $fb_b;
				}

				// 5. Synthetic grain to perfectly meld into the photograph.
				// A random noise (-7 to 7) destroys the math-smooth plastic look.
				$noise = rand( -7, 7 );
				$fr = min( 255, max( 0, (int)( $fr + $noise ) ) );
				$fg = min( 255, max( 0, (int)( $fg + $noise ) ) );
				$fb = min( 255, max( 0, (int)( $fb + $noise ) ) );

				imagesetpixel( $im, $x, $y, ( $fr << 16 ) | ( $fg << 8 ) | $fb );
			}
		}

		// ── Step 4: Save back to disk ─────────────────────────────────────────
		$temp_path = dirname( $image_path ) . '/logo_removed_' . uniqid( 'lr_', true ) . '.jpg';
		$saved     = imagejpeg( $im, $temp_path, 92 );
		imagedestroy( $im );

		if ( $saved && file_exists( $temp_path ) ) {
			@unlink( $image_path );
			@rename( $temp_path, $image_path );
			return true;
		}

		@unlink( $temp_path );
		return false;
	}

	/**
	 * ImageMagick fallback for when GD is unavailable.
	 * Uses interior adjacent patches to determine fill color (no boundary pixels),
	 * then draws a solid rectangle. Solid fill is a limitation of IM from PHP,
	 * but the color is correctly sampled from interior photo content.
	 */
	private function fill_logo_with_mean_color_imagemagick(
		string $image_path,
		int $lx1, int $ly1, int $logo_w, int $logo_h,
		int $img_w, int $img_h,
		string $convert
	): bool {
		$lx2      = $lx1 + $logo_w;
		$ly2      = $ly1 + $logo_h;
		$edge_min = 3;

		// Interior patches: same boundary logic as the GD path.
		$patches = [];
		if ( $lx1 - $logo_w >= $edge_min ) {
			$py1 = max( $edge_min, $ly1 ); $py2 = min( $img_h - $edge_min - 1, $ly2 );
			if ( $py2 > $py1 ) { $patches[] = [ $lx1 - $logo_w, $py1, $logo_w, $py2 - $py1 ]; }
		}
		if ( $lx2 + $logo_w <= $img_w - $edge_min ) {
			$py1 = max( $edge_min, $ly1 ); $py2 = min( $img_h - $edge_min - 1, $ly2 );
			if ( $py2 > $py1 ) { $patches[] = [ $lx2 + 1, $py1, $logo_w, $py2 - $py1 ]; }
		}
		if ( $ly2 + $logo_h <= $img_h - $edge_min ) {
			$px1 = max( $edge_min, $lx1 ); $px2 = min( $img_w - $edge_min - 1, $lx2 );
			if ( $px2 > $px1 ) { $patches[] = [ $px1, $ly2 + 1, $px2 - $px1, $logo_h ]; }
		}
		if ( $ly1 - $logo_h >= $edge_min ) {
			$px1 = max( $edge_min, $lx1 ); $px2 = min( $img_w - $edge_min - 1, $lx2 );
			if ( $px2 > $px1 ) { $patches[] = [ $px1, $ly1 - $logo_h, $px2 - $px1, $logo_h ]; }
		}

		$parse_color = static function ( string $raw ): ?array {
			if ( preg_match( '/srgb\s*\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i', $raw, $m ) ) {
				return [ (int) $m[1], (int) $m[2], (int) $m[3] ];
			}
			if ( preg_match( '/#([0-9a-fA-F]{6})/', $raw, $m ) ) {
				$h = $m[1];
				return [ hexdec( substr( $h, 0, 2 ) ), hexdec( substr( $h, 2, 2 ) ), hexdec( substr( $h, 4, 2 ) ) ];
			}
			return null;
		};

		$r_sum = 0; $g_sum = 0; $b_sum = 0; $n = 0;
		foreach ( $patches as [ $px, $py, $pw, $ph ] ) {
			if ( $pw <= 0 || $ph <= 0 ) { continue; }
			$cmd = sprintf(
				'%s %s -crop %dx%d+%d+%d +repage -scale 1x1! -format "%%[pixel:u.p{0,0}]" info:',
				escapeshellarg( $convert ), escapeshellarg( $image_path ),
				$pw, $ph, $px, $py
			);
			$out = []; @exec( $cmd, $out, $rc );
			if ( $rc === 0 && ! empty( $out[0] ) ) {
				$rgb = $parse_color( trim( $out[0] ) );
				if ( $rgb ) { $r_sum += $rgb[0]; $g_sum += $rgb[1]; $b_sum += $rgb[2]; $n++; }
			}
		}

		$fill_hex = '#808080';
		if ( $n > 0 ) {
			$fill_hex = sprintf( '#%02x%02x%02x',
				(int) round( $r_sum / $n ), (int) round( $g_sum / $n ), (int) round( $b_sum / $n )
			);
		}

		$fill_x1 = max( 0, $lx1 - 2 );
		$fill_y1 = max( 0, $ly1 - 2 );
		$fill_w  = min( $img_w - $fill_x1, $logo_w + 4 );
		$fill_h  = min( $img_h - $fill_y1, $logo_h + 4 );

		$temp_path = dirname( $image_path ) . '/logo_removed_' . uniqid( 'lr_', true ) . '.jpg';
		$cmd = sprintf(
			'%s %s -fill %s -draw "rectangle %d,%d %d,%d" %s',
			escapeshellarg( $convert ), escapeshellarg( $image_path ),
			escapeshellarg( $fill_hex ),
			$fill_x1, $fill_y1, $fill_x1 + $fill_w - 1, $fill_y1 + $fill_h - 1,
			escapeshellarg( $temp_path )
		);
		exec( $cmd, $output, $rc );

		if ( $rc === 0 && file_exists( $temp_path ) ) {
			@unlink( $image_path );
			@rename( $temp_path, $image_path );
			return true;
		}

		@unlink( $temp_path );
		return false;
	}


	private function validate_output( string $output_path ): bool {
		if ( ! file_exists( $output_path ) ) {
			return false;
		}

		$info = getimagesize( $output_path );
		if ( ! $info ) {
			return false;
		}

		$width = (int) $info[0];
		$height = (int) $info[1];

		if ( $width < 100 || $height < 100 ) {
			return false;
		}

		$file_size = filesize( $output_path );
		if ( $file_size < 1024 ) {
			return false;
		}

		return true;
	}

	private function save_debug_overlay( string $image_path, array $zones, string $output_path, string $convert ): void {
		$colors = [
			'image' => 'lime',
			'text'  => 'red',
			'logo'  => 'blue',
		];

		$draw_commands = [];
		foreach ( $zones as $name => $zone ) {
			$color = $colors[ $name ] ?? 'white';
			$draw_commands[] = sprintf(
				'-stroke %s -strokewidth 2 -fill none -draw "rectangle %d,%d %d,%d"',
				$color,
				(int) $zone['x1'],
				(int) $zone['y1'],
				(int) $zone['x2'],
				(int) $zone['y2']
			);
		}

		$cmd = sprintf(
			'%s %s %s %s',
			escapeshellarg( $convert ),
			escapeshellarg( $image_path ),
			implode( ' ', $draw_commands ),
			escapeshellarg( $output_path )
		);

		@exec( $cmd );
	}

	private function find_convert(): ?string {
		static $cached = null;
		if ( null !== $cached ) {
			return $cached;
		}

		$candidates = [
			Config::IM_CONVERT_PATH,
			'/usr/bin/convert',
			'/usr/local/bin/convert',
			'/opt/homebrew/bin/convert',
		];

		foreach ( $candidates as $path ) {
			if ( file_exists( $path ) && is_executable( $path ) ) {
				$cached = $path;
				return $cached;
			}
		}

		if ( function_exists( 'exec' ) ) {
			@exec( 'which convert 2>/dev/null', $out, $rc );
			if ( $rc === 0 && ! empty( $out[0] ) ) {
				$cached = $out[0];
				return $cached;
			}
		}

		$cached = null;
		return null;
	}

	private function get_temp_dir(): ?string {
		$temp_dir = AI_SOCIAL_COLLAGE_PATH . 'assets/temp';

		if ( ! is_dir( $temp_dir ) ) {
			if ( ! wp_mkdir_p( $temp_dir ) ) {
				return null;
			}
		}

		if ( ! is_writable( $temp_dir ) ) {
			return null;
		}

		return $temp_dir;
	}
}
