<?php
/**
 * Advanced Multi-Layer Duplicate Detection System
 * Version: 1.0.1 - FIXED FATAL ERROR
 *
 * @MODIFIED: Replaced call to removed function nm_get_embedding_db()
 * with a new instance of NM_Embedding_Database().
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class NM_Advanced_Duplicate_Detector {

	private $api_key;
	private $similarity_threshold;
	private $fuzzy_threshold;

	/**
	 * Constructor
	 * * @param string $api_key Gemini API key for semantic checks
	 *
	 * @param float $similarity_threshold Semantic similarity threshold (0.0-1.0)
	 * @param float $fuzzy_threshold Fuzzy text match threshold (0.0-1.0)
	 */
	public function __construct( $api_key, $similarity_threshold = 0.70, $fuzzy_threshold = 0.75 ) {
		$this->api_key              = $api_key;
		$this->similarity_threshold = $similarity_threshold;
		$this->fuzzy_threshold      = $fuzzy_threshold;
	}

	/**
	 * Main duplicate check function
	 * Returns detailed information about the match
	 * * @param string $question_text The question to check
	 *
	 * @param int $exclude_post_id Optional post ID to exclude from search
	 * @return array ['is_duplicate' => bool, 'method' => string, 'post_id' => int, 'similarity' => float]
	 */
	public function check_duplicate( $question_text, $topic_name = '', $exclude_post_id = 0 ) {
		// Layer 1: Exact Match (fastest - DB query)
		$exact_match = $this->check_exact_match( $question_text, $exclude_post_id );
		if ( $exact_match['is_duplicate'] ) {
			return array_merge(
				$exact_match,
				array(
					'method' => 'exact',
					'layer'  => 1,
				)
			);
		}
		// Layer 3: Semantic Similarity (slow - AI embeddings)
		$semantic_match = $this->check_semantic_match( $question_text, $topic_name, $exclude_post_id );
		if ( $semantic_match['is_duplicate'] ) {
			return array_merge(
				$semantic_match,
				array(
					'method' => 'semantic',
					'layer'  => 3,
				)
			);
		}

		return array( 'is_duplicate' => false );
	}

	/**
	 * Layer 1: Exact title match using direct SQL
	 * Checks if identical question exists in database
	 */
	private function check_exact_match( $question, $exclude_id = 0 ) {
		global $wpdb;

		$normalized = $this->normalize_text( $question );

		$query = $wpdb->prepare(
			"SELECT ID, post_title FROM {$wpdb->posts} 
             WHERE post_type = 'mcq' 
             AND post_status IN ('publish', 'draft')
             AND LOWER(TRIM(post_title)) = %s
             AND ID != %d
             LIMIT 1",
			strtolower( trim( $normalized ) ),
			$exclude_id
		);

		$result = $wpdb->get_row( $query );

		if ( $result ) {
			return array(
				'is_duplicate'      => true,
				'post_id'           => $result->ID,
				'existing_question' => $result->post_title,
				'similarity'        => 1.0,
			);
		}

		return array( 'is_duplicate' => false );
	}
	/**
	 * Layer 3: Semantic similarity using AI embeddings
	 * NOW OPTIMIZED to query by topic.
	 *
	 * @param string $question The question text.
	 * @param string $topic_name The name of the parent topic (e.g., "Pakistan", "Science").
	 * @param int    $exclude_id The post ID to exclude.
	 * @return array Duplicate check result.
	 */
	private function check_semantic_match( $question, $topic_name = '', $exclude_id = 0 ) {
		// 1. Get the term_id from the topic name
		$term_id = 0;
		if ( ! empty( $topic_name ) ) {
			$term = get_term_by( 'name', $topic_name, 'topic' );
			if ( $term && ! is_wp_error( $term ) ) {
				$term_id = $term->term_id;
			}
		}

		// If no topic is found, we must skip this check to ensure performance.
		// It's better to skip than to load 5000+ embeddings.
		if ( empty( $term_id ) ) {
			return array(
				'is_duplicate' => false,
				'error'        => 'No topic provided for semantic filter.',
			);
		}

		// 2. Generate embedding for new question
		$new_embedding = $this->get_embedding( $question );
		if ( ! $new_embedding ) {
			return array(
				'is_duplicate' => false,
				'error'        => 'Failed to generate embedding',
			);
		}

		// 3. Get embeddings *only for this topic*
		$embedding_db     = new NM_Embedding_Database();
		$topic_embeddings = $embedding_db->get_embeddings_for_topic( $term_id );

		if ( empty( $topic_embeddings ) ) {
			return array( 'is_duplicate' => false ); // No embeddings in this topic yet
		}

		// 4. Check against the small, filtered list (e.g., 1-vs-50 instead of 1-vs-5000)
		foreach ( $topic_embeddings as $post_id => $existing_embedding ) {
			// Skip the post we're checking against itself
			if ( $post_id === $exclude_id ) {
				continue;
			}

			if ( is_array( $existing_embedding ) && count( $existing_embedding ) > 0 ) {
				$similarity = $this->cosine_similarity( $new_embedding, $existing_embedding );

				if ( $similarity >= $this->similarity_threshold ) {
					$question_text = get_the_title( $post_id );

					return array(
						'is_duplicate'      => true,
						'post_id'           => $post_id,
						'existing_question' => $question_text,
						'similarity'        => round( $similarity, 4 ),
					);
				}
			}
		}

		return array( 'is_duplicate' => false );
	}

	/**
	 * Get embedding from Gemini API
	 */
	private function get_embedding( $text ) {
		// Use existing function if available
		if ( class_exists( 'NM_API_Client' ) ) {
			return NM_API_Client::get_instance()->get_embedding( $text, $this->api_key );
		}

				// Fallback implementation using the same model as NM_API_Client.
		$embedding_model = class_exists( 'NM_API_Client' )
			? NM_API_Client::get_embedding_model_name()
			: 'gemini-embedding-2';
		$api_url         = 'https://generativelanguage.googleapis.com/v1beta/models/' . $embedding_model . ':embedContent?key=' . $this->api_key;

		$response = wp_remote_post(
			$api_url,
			array(
				'headers' => array( 'Content-Type' => 'application/json' ),
				'body'    => json_encode(
					array(
						'model'                => 'models/' . $embedding_model,
						'outputDimensionality' => 768,
						'content'              => array(
							'parts' => array(
								array( 'text' => $text ),
							),
						),
					)
				),
				'timeout' => 30,
			)
		);

		if ( is_wp_error( $response ) ) {
			return null;
		}

		$data = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( isset( $data['embedding']['values'] ) ) {
			return $data['embedding']['values'];
		}

		return null;
	}

	/**
	 * Calculate cosine similarity between two vectors
	 */
	private function cosine_similarity( $vec1, $vec2 ) {
		$dot_product = 0.0;
		$magnitude1  = 0.0;
		$magnitude2  = 0.0;

		$length = count( $vec1 );
		if ( $length !== count( $vec2 ) ) {
			return 0.0;
		}

		for ( $i = 0; $i < $length; $i++ ) {
			$dot_product += $vec1[ $i ] * $vec2[ $i ];
			$magnitude1  += $vec1[ $i ] * $vec1[ $i ];
			$magnitude2  += $vec2[ $i ] * $vec2[ $i ];
		}

		$denominator = sqrt( $magnitude1 ) * sqrt( $magnitude2 );

		return $denominator === 0.0 ? 0.0 : $dot_product / $denominator;
	}

	/**
	 * Advanced text normalization with synonym replacement
	 */
	private function normalize_text( $text ) {
		$text = strtolower( $text );

		// Synonym replacements (before removing punctuation)
		$synonyms = array(
			'nation'                => 'country',
			'nations'               => 'countries',
			'over '                 => 'more than ',
			'above '                => 'more than ',
			'historic'              => 'historical',
			'deployed personnel'    => 'sent personnel',
			'geographical sectors'  => 'sectors',
			'border patrol sectors' => 'patrol sectors',
			'shared with'           => 'with',
			'mexican border'        => 'mexico border',
			'which country'         => 'which nation',
			'which nation'          => 'which country',
		);

		foreach ( $synonyms as $from => $to ) {
			$text = str_replace( $from, $to, $text );
		}

		// Normalize numbers
		$text = preg_replace( '/\s+/', ' ', $text ); // Multiple spaces → single
		$text = preg_replace( '/,(\d{3})/', '$1', $text ); // 200,000 → 200000

		// Remove punctuation
		$text = str_replace( array( '?', '!', '.', ',', ';', ':', '"', "'", '-' ), ' ', $text );

		// Remove common filler words
		$fillers = array( ' the ', ' a ', ' an ', ' of ', ' to ', ' in ', ' on ', ' at ', ' by ', ' for ' );
		foreach ( $fillers as $filler ) {
			$text = str_replace( $filler, ' ', $text );
		}

		$text = preg_replace( '/\s+/', ' ', $text );
		return trim( $text );
	}

	/**
	 * Get duplicate detection statistics
	 */
	public function get_statistics() {
		global $wpdb;

		$total_mcqs = $wpdb->get_var(
			"SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'mcq' AND post_status IN ('publish', 'draft')"
		);

		$mcqs_with_embeddings = $wpdb->get_var(
			"SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key = 'mcq_embedding'"
		);

		return array(
			'total_mcqs'           => (int) $total_mcqs,
			'mcqs_with_embeddings' => (int) $mcqs_with_embeddings,
			'embedding_coverage'   => $total_mcqs > 0 ? round( ( $mcqs_with_embeddings / $total_mcqs ) * 100, 2 ) : 0,
		);
	}

	/**
	 * Find similar MCQs (used by the admin tool)
	 */
	public function find_similar_mcqs( $question, $exclude_post_id ) {
		$new_embedding = $this->get_embedding( $question );
		if ( ! $new_embedding ) {
			return array();
		}

		$embedding_db   = new NM_Embedding_Database();
		$all_embeddings = $embedding_db->get_all_embeddings( 5000 ); // Limit scan
		$similarities   = array();

		foreach ( $all_embeddings as $post_id => $existing_embedding ) {
			if ( $post_id == $exclude_post_id ) {
				continue;
			}
			if ( is_array( $existing_embedding ) && count( $existing_embedding ) > 0 ) {
				$similarity = $this->cosine_similarity( $new_embedding, $existing_embedding );
				if ( $similarity >= $this->similarity_threshold ) {
					$similarities[] = array(
						'post_id'    => $post_id,
						'similarity' => $similarity,
					);
				}
			}
		}

		// Sort by similarity (highest first)
		usort(
			$similarities,
			function ( $a, $b ) {
				return $b['similarity'] <=> $a['similarity'];
			}
		);

		return $similarities;
	}
}
