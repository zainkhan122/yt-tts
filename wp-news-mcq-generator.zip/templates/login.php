<?php
/**
 * Login Page Template
 * @version 2.1 - Hardened with XSS Prevention
 *
 * @MODIFIED: Added esc_url() to home_url() calls.
 */

if (!defined('ABSPATH')) exit;

get_header();
?>

<div class="nm-auth-wrapper">
    <div class="nm-auth-container">
        <div class="nm-auth-box">

            <div class="nm-auth-promo">
                <div class="nm-promo-content">
                    <h2>Welcome Back!</h2>
                    <p>Login to resume your learning journey, track your progress, and climb the leaderboard.</p>
                    <ul class="nm-promo-benefits">
                        <li><span class="nm-icon">✅</span> Track your stats</li>
                        <li><span class="nm-icon">🏆</span> View your rank</li>
                        <li><span class="nm-icon">📚</span> Access your quiz history</li>
                    </ul>
                </div>
            </div>

            <div class="nm-auth-form-container">
                <div class="nm-auth-header">
                    <h1>Login</h1>
                    <p>Access your account</p>
                </div>

                <form id="nm-login-form" class="nm-auth-form">
                    <div class="nm-form-group">
                        <label for="username">Username or Email</label>
                        <input type="text" id="username" name="username" required autofocus>
                    </div>

                    <div class="nm-form-group">
                        <label for="password">Password</label>
                        <div class="nm-password-field">
                            <input type="password" id="password" name="password" required>
                            <span class="nm-toggle-password">
                                <i class="fa fa-eye"></i>
                            </span>
                        </div>
                    </div>

                    <div class="nm-form-row">
                        <label class="nm-checkbox-label">
                            <input type="checkbox" name="remember" value="1">
                            <span>Remember me</span>
                        </label>
                        <a href="<?php echo esc_url(home_url('/mcq-reset-password/')); ?>" class="nm-link">Forgot Password?</a>
                    </div>

                    <button type="submit" class="nm-btn nm-btn-primary nm-btn-block">Login</button>
                </form>

                <div class="nm-auth-divider">
                    <span>OR</span>
                </div>

                <div class="nm-social-login">
                    <?php if (get_option('nm_enable_google_oauth', 0)): ?>
                    <button class="nm-btn nm-btn-google">
                        <i class="fab fa-google"></i>
                        Continue with Google
                    </button>
                    <?php endif; ?>

                    <?php if (get_option('nm_enable_facebook_oauth', 0)): ?>
                    <button class="nm-btn nm-btn-facebook">
                        <i class="fab fa-facebook"></i>
                        Continue with Facebook
                    </button>
                    <?php endif; ?>
                </div>

                <div class="nm-auth-footer">
                    <p>Don't have an account? <a href="<?php echo esc_url(home_url('/mcq-register/')); ?>" class="nm-link-primary">Sign Up</a></p>
                </div>
            </div>
            
        </div>
    </div>
</div>

<?php get_footer(); ?>