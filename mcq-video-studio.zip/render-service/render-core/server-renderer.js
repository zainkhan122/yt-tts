/**
 * MCQ Video Studio — Server Render Core
 *
 * Reuses the EXACT browser drawing code (vs-unified-renderer, vs-template-manager,
 * vs-animation-engine, vs-text-effects, vs-video-templates) to produce frames,
 * draws backgrounds (image or extracted video frames), registers template fonts,
 * then pipes raw RGBA to FFmpeg for H.264/MP4 encoding — and muxes a fully mixed
 * audio track (TTS voiceover + background music with ducking + time-locked SFX).
 *
 * No browser, no WebCodecs, no Playwright, no WordPress nonce in the render path.
 *
 * @package MCQ_Video_Studio
 * @subpackage render-service/render-core
 */

'use strict';

const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawn } = require('child_process');
const { installDomShim } = require('./dom-shim');
const { mixAudio } = require('./audio-mixer');
const mediaPrep = require('./media-prep');

let _win = null;

/**
 * Load the browser-authored rendering modules into the shimmed global scope.
 */
function loadRenderingModules(assetsJsDir, opts) {
    const shim = installDomShim(opts);
    const windowShim = shim.window;

    const files = [
        'vs-animation-engine.js',
        'vs-text-effects.js',
        'vs-video-templates.js',
        'vs-template-manager.js',
        'vs-unified-renderer.js',
        'studio/plan.builder.js',
        'core/render-plan.js',
    ];

    for (const f of files) {
        const full = path.join(assetsJsDir, f);
        if (!fs.existsSync(full)) throw new Error('Missing rendering module: ' + full);
        const src = fs.readFileSync(full, 'utf8');
        const fn = new Function('window', 'document', 'OffscreenCanvas', 'self', 'globalThis', 'require', 'module', 'exports', src);
        fn(windowShim, shim.document, global.OffscreenCanvas, windowShim, windowShim, require, undefined, undefined);
    }
    return windowShim;
}

function windowPlanBuilder() { return (_win && _win.MCQVS_PlanBuilder) || { buildFromPlaylist: null, buildFromState: null }; }
function windowRenderPlan() { return (_win && _win.MCQVSRenderPlan) || { buildFromPlaylist: null }; }

function buildMinimalPlan(playlist, opts) {
    const fps = opts.fps, frameMs = 1000 / fps;
    const snap = (ms) => Math.round(ms / frameMs) * frameMs;
    let cursor = 0; let total = 0;
    const scenes = playlist.map((s) => {
        const dur = snap(s.duration || 0);
        const startMs = snap(cursor); cursor += dur; total = startMs + dur;
        return { id: String(s.id), type: String(s.type), startMs, durMs: dur, endMs: startMs + dur, content: s.content || {}, timing: s.timing || null };
    });
    return { version: 1, fps, frameMs, width: opts.width, height: opts.height, templateId: opts.templateId, scenes, cues: [], assets: { images: [], audio: [], fonts: [] }, totalMs: total, fxEvents: [], sfxEvents: [], duckWindows: [] };
}

/**
 * Build a deterministic RenderPlan + state from a job payload (mirrors browser
 * ExportManager.buildPlaylistForExport + PlanBuilder.buildFromState).
 */
function buildPlanAndState(payload) {
    const settings = payload.settings || {};
    const questions = Array.isArray(payload.questions) ? payload.questions : [];
    let templateId = settings.template || 'trivia';
    const isYoutube = (payload.videoFormat || settings.videoFormat || 'shorts') === 'youtube';
    const width = isYoutube ? 1920 : 1080;
    const height = isYoutube ? 1080 : 1920;

    // @FIX 2026-08-XX: Use apply() as the SSOT bridge so state.templateColors,
    //       state.templateEffects, AND state.templateFonts are all populated
    //       consistently — matching the browser path. Previously only templateFonts
    //       was manually extracted, leaving state.templateColors and state.templateEffects
    //       null on the server path (drawHook/drawOutro miss template effects).
    let templateFonts = null;
    let templateFontWeights = null;
    try {
        const vt = _win && _win.MCQVS_VideoTemplates;
        if (vt && typeof vt.apply === 'function') {
            const applied = vt.apply(templateId, settings);
            if (applied) {
                templateFonts = settings.templateFonts || null;
                templateFontWeights = settings.templateFontWeights || null;
                // @FIX 2026-08-11 (CRITICAL): persist templateFontWeights back into
                //       settings so render-node's prepareMedia → prepareFonts sees the
                //       template's real weights (500/700/900) and registers each font at
                //       400/700/900. Previously only templateFonts was set here, so
                //       prepareFonts registered ONLY weight 700 — templates that request
                //       weight 900 (science Exo 2, space Orbitron, corporate Inter-900…)
                //       made node-canvas fall back to a broken tiny default font, which
                //       misrendered question text and brand names (the "unreadable" bug).
                if (templateFontWeights) settings.templateFontWeights = templateFontWeights;
            }
        }
        // Fallback: manual extraction if apply() failed or returned false
        if (!templateFonts) {
            if (vt && typeof vt.get === 'function') {
                const tpl = vt.get(templateId);
                if (tpl && tpl.fonts) {
                    templateFonts = { primary: tpl.fonts.primary || null, secondary: tpl.fonts.secondary || null };
                    templateFontWeights = tpl.fonts.weights || null;
                    settings.templateFonts = templateFonts;
                    if (templateFontWeights) settings.templateFontWeights = templateFontWeights;
                }
            }
        }
        // @FIX 1.4.9.57 (regression): a job may reference a template that no longer
        // exists (removed minimalist/quizwire). Normalize the id used for state +
        // plan + the final getTemplate() render so old queued jobs re-render with a
        // real dark template instead of an empty default config.
        if (typeof vt.get === 'function' && !vt.get(templateId)) {
            templateId = (vt.get('trivia')) ? 'trivia' : 'corporate';
            settings.template = templateId; // persist so plan.builder + cues use it
        }
    } catch (_) {}
    if (settings.fontOverride) settings.fontOverride = String(settings.fontOverride);
    const _log = (typeof global !== 'undefined' && global.__MCQVS_RENDER_LOG) || console.log;
    _log('[buildPlanAndState:DIAG] templateId=' + templateId + ' templateFonts=' + JSON.stringify(templateFonts) + ' templateFontWeights=' + JSON.stringify(templateFontWeights) + ' fontOverride="' + (settings.fontOverride || '') + '"');

    const videoFormat = (payload.videoFormat || settings.videoFormat || 'shorts') === 'youtube' ? 'youtube' : 'shorts';
    const fps = videoFormat === 'youtube' ? 30 : 24;

    // @FIX 2026-08-11: Format-aware default timing. Shorts get the 25-40s sweet-spot
    //                  pacing (hook 1.2s + ~8s/question + 3.2s outro); long-form keeps
    //                  the classic roomy pacing. Only used as a fallback when the job
    //                  has no explicit timing — adaptive TTS timing still overrides
    //                  per-question durations via computeAdaptiveTiming().
    const timing = settings.timing || (videoFormat === 'youtube'
        ? { hookIntro: 2000, questionTotal: 12000, questionPhases: { intro: 1000, reading: 9000, reveal: 3000 }, outroDuration: 5000 }
        : { hookIntro: 1200, questionTotal: 7700, questionPhases: { intro: 600, reading: 5100, reveal: 2000 }, outroDuration: 3200 });

    const playlist = [];
    // @NEW 2026-07-30: Cover scene — first frame shows full branding (logo + brand + hook/quiz name).
    // @FIX 2026-08-11: Cover was 2 frames (~83ms) — too short for YouTube/IG/FB to ever capture
    //                  it as the poster/thumbnail. Extended to a full second (~1s @ fps) so the
    //                  hook-first card is a viable auto thumbnail and scroll-stopper.
    // @FIX 2026-08-11 (SSOT): Gate on cover_config.enabled (mirrors plan.builder +
    //                  studio.export buildPlaylistForExport) so "Disable Video Cover"
    //                  also removes the cover scene in SERVER renders, not just browser
    //                  preview/export.
    const coverCfgSrv = (settings.cover_config && typeof settings.cover_config === 'object') ? settings.cover_config : {};
    if (coverCfgSrv.enabled !== false) {
        playlist.push({ id: 'cover', type: 'cover', duration: 1000, content: {}, timing });   // 1s cover — frame-0 must be capturable as thumbnail
    }
    const hookText = String(settings.hookText || '').trim();
    // @FIX 2026-08-11: Skip the hook scene entirely when the hook is hidden
    //       (settings.hookVisible === false) — no dead 1.2s gap before Q1.
    //       Mirrors plan.builder.js + studio.export.js (SSOT).
    if (hookText && settings.hookVisible !== false) playlist.push({ id: 'hook', type: 'hook', duration: Number(timing.hookIntro || 2000), content: { hookText, hookVisible: settings.hookVisible !== false }, timing });
    questions.forEach((q, idx) => {
        playlist.push({ id: 'q' + idx, type: 'question', duration: Number(timing.questionTotal || 12000), content: Object.assign({}, q, { questionIndex: idx, sequenceIndex: idx, totalQuestions: questions.length }), timing });
    });
    // @FIX 2026-08-11 (SCORE CTA): server-side equivalent of the controller's
    //       updateComputedValues() — when ctaStyle is 'score', fill in the X/X total
    //       (number of questions) so the outro reads "Comment your score 👇 5/5?" even
    //       though the server has no JS controller. Falls back to ctaText/computedCtaText.
    let ctaText = String(settings.computedCtaText || settings.ctaText || 'Subscribe!').trim();
    const ctaStyleSrv = String(settings.ctaStyle || 'score').toLowerCase();
    if (ctaStyleSrv === 'score' && (!/score/i.test(ctaText) || ctaText === 'Comment your score 👇')) {
        const qCountSrv = Array.isArray(questions) ? questions.length : 0;
        ctaText = qCountSrv > 0 ? ('Comment your score 👇 ' + qCountSrv + '/' + qCountSrv + '?') : 'Comment your score 👇';
    }
    playlist.push({ id: 'outro', type: 'outro', duration: Number(timing.outroDuration || 5000), content: { ctaText }, timing });

    let plan = null;
    const pb = windowPlanBuilder();
    if (pb.buildFromState) {
        // @FIX 1.4.9.52 (CRITICAL): pass hookVisible + coverConfig into buildFromState.
        // buildFromState rebuilds its own playlist via _buildPlaylistFromState, which
        // gates the cover scene on state.coverConfig.enabled !== false and the hook
        // scene on state.hookVisible !== false. Previously neither field was passed,
        // so the final server plan ALWAYS contained cover + hook scenes regardless of
        // settings — "Disable Cover Page" and "Show Hook Text On Video = off" had NO
        // effect on server/headless renders (the video showed the hook despite the
        // Content Planner toggle being unchecked).
        plan = pb.buildFromState({
            questions, hookText, ctaText, currentTemplate: templateId,
            hookVisible: settings.hookVisible !== false,
            coverConfig: coverCfgSrv,
            voiceover: settings.voiceover || null, sfxEnabled: settings.sfxEnabled,
            bgMusicUrl: settings.bgMusicUrl || null,
        }, { fps, width, height, templateId, sfxMap: {}, assetConfig: { musicUrl: settings.bgMusicUrl || null, sfx: {} } });
    } else if (pb.buildFromPlaylist) {
        plan = pb.buildFromPlaylist(playlist, { fps, width, height, templateId });
    } else {
        plan = buildMinimalPlan(playlist, { fps, width, height, templateId });
    }
    if (!plan || !plan.totalMs) plan = buildMinimalPlan(playlist, { fps, width, height, templateId });

    const state = Object.assign({
        questions,
        currentTemplate: templateId,
        templateId,
        videoFormat: isYoutube ? 'youtube' : 'shorts',
        width, height, fps,
        brandName: settings.brandName || 'QuizWire',
        quizName: settings.quizName || '',
        brandLogoImage: null,
        logoPosition: settings.logoPosition || 'all',
        bgImage: null,
        bgVideoUrl: null,
        bgMusicUrl: null,
        musicEnabled: false,
        sfxEnabled: !!settings.sfxEnabled,
        // @NEW 2026-08-11: Explanation bar toggle — default OFF (ultra-minimal), only
        //       rendered when the job explicitly enables it.
        showExplanation: settings.showExplanation === true,
        // @FIX 1.4.9.52 (SSOT): set textEffects.currentStyle from the template so the
        //       server path uses the SAME text-effect preset as the browser preview /
        //       export (browser sets it via MCQVS_VideoTemplates.apply(state)). Without
        //       it, the server fell back to classicBold — white fill + heavy black
        //       stroke — which looked different from preview and was the wrong style
        //       for light templates.
        textEffects: (function () {
            const te = settings.textEffects || { enabled: true };
            if (typeof te === 'object' && !te.currentStyle && settings.templateEffects && settings.templateEffects.textEffect) {
                te.currentStyle = settings.templateEffects.textEffect;
            }
            return te;
        })(),
        templateConfig: settings.templateConfig || {},
        templateColors: settings.templateColors || null,
        templateFonts: settings.templateFonts || null,
        templateEffects: settings.templateEffects || null,
        brandColor: settings.brandColor || null,
        hookText, hookVisible: settings.hookVisible !== false,
        ctaText, ctaStyle: settings.ctaStyle || 'subscribe',
        useRankSystemCTA: !!settings.useRankSystemCTA,
        computedCtaText: settings.computedCtaText || ctaText,
        websiteUrl: settings.websiteUrl || '',
        subHookText: settings.subHookText || '',
        fontOverride: settings.fontOverride || null,
        timing,
        fxEvents: (plan && plan.fxEvents) || [],
    }, plan ? { renderPlan: plan } : {});

    return { plan, state, width, height, fps, totalMs: plan.totalMs, templateId };
}

/**
 * Port of studio.export.js _buildVoiceoverCues — pure JS, no DOM. Produces TTS
 * text cues (hook/question+options/reveal/cta) with their scheduled atMs.
 */
function buildVoiceoverCues(built, settings) {
    const vo = settings.voiceover || {};
    if (!vo.enabled) return [];
    const provider = String(vo.provider || '').trim();
    if (provider === 'webspeech' && !vo.webspeechCapturedAudio) return [];
    if (!vo.voice) return []; // nothing to generate

    const norm = (s) => String(s || '').replace(/<[^>]+>/g, ' ').replace(/[\r\n\t]+/g, ' ').replace(/\s{2,}/g, ' ').trim();
    const cues = [];

    const hookText = norm(settings.hookText);
    if (vo.speakHook !== false && hookText && settings.hookVisible !== false) {
        // @FIX 2026-07-30: Offset hook TTS cue by cover scene duration so audio
        //       stays in sync with the visual hook scene (which now starts AFTER
        //       the cover scene). Without this, TTS plays 33-83ms ahead of visual.
        const scenesArr = (built.plan && built.plan.scenes) || [];
        const coverScene = scenesArr.find((s) => s.type === 'cover');
        const coverDur = coverScene ? Number(coverScene.durMs || 0) : 0;
        const hookScene = scenesArr.find((s) => s.type === 'hook');
        // @FIX 2026-08-11: give the hook cue a sceneId so computeAdaptiveTiming can extend
        //       the hook scene to fit its TTS (prevents hook audio spilling into Q1).
        cues.push({ atMs: 50 + coverDur, text: hookText, kind: 'hook', sceneId: hookScene ? hookScene.id : '' });
    }

    const scenes = (built.plan && built.plan.scenes) || [];
    const qScenes = scenes.filter((s) => s.type === 'question');
    const outro = scenes.find((s) => s.type === 'outro');

    qScenes.forEach((scene, idx) => {
        const c = scene.content || {};
        const qText = norm(c.question || c.text);
        const opts = Array.isArray(c.options) ? c.options.map((o) => norm(o)) : [];
        const correct = Number.isInteger(c.correct) ? c.correct : (Number.isInteger(c.correctAnswer) ? c.correctAnswer : 0);

        let line = qText ? `Question ${idx + 1}. ${qText}.` : `Question ${idx + 1}.`;
        if (vo.speakOptions !== false && opts.length) {
            if (opts[0]) line += ` ${opts[0]}.`;
            if (opts[1]) line += ` ${opts[1]}.`;
            if (opts[2]) line += ` ${opts[2]}.`;
            if (opts[3]) line += ` ${opts[3]}.`;
        }
        line = norm(line);
        const startMs = Math.max(0, Number(scene.startMs || 0) + 80);
        if (line) cues.push({ atMs: startMs, text: line, kind: 'q_read', sceneId: scene.id });

        if (vo.speakAnswer !== false && opts.length) {
            const revealMs = Number(scene.timing && scene.timing.questionPhases ? scene.timing.questionPhases.reveal : 3000);
            const endMs = Number(scene.endMs || (Number(scene.startMs || 0) + Number(scene.durMs || 0)));
            const revealStart = Math.max(0, endMs - revealMs);
            const optText = opts[correct] || '';
            const answerPhrase = norm(vo.answerPhrase);
            const phraseTpl = answerPhrase || 'correct answer is';
            let ansText = `${phraseTpl} ${optText}.`;
            const revealCueTime = Math.min(Math.max(revealStart + 20, startMs + 250), Math.max(startMs + 250, endMs - 100));
            cues.push({ atMs: revealCueTime, text: norm(ansText), kind: 'reveal', sceneId: scene.id });
        }
    });

    if (vo.speakCta !== false && outro) {
        const cta = norm((outro.content && outro.content.ctaText) || settings.computedCtaText || settings.ctaText);
        if (cta) cues.push({ atMs: Math.max(0, Number(outro.startMs || 0) + 200), text: cta, kind: 'cta', sceneId: outro.id });
    }
    return cues;
}

/**
 * Phase 1: Generate all TTS WAVs and measure their actual durations.
 * Returns array of { path, atMs, durationMs, kind, sceneId, text }.
 */
function generateAndMeasureTts(built, settings, ffmpegBin, edgeHelper) {
    const vo = settings.voiceover || {};
    if (!vo.enabled || !vo.voice) return [];

    const cues = buildVoiceoverCues(built, settings);
    if (!cues.length) return [];

    const { spawnSync } = require('child_process');
    const ratePct = vo.rate ? Math.round((vo.rate - 1.0) * 100) : 0;
    const rateStr = (ratePct >= 0 ? '+' : '') + ratePct + '%';
    const pitchStr = vo.pitch ? (vo.pitch >= 0 ? '+' + vo.pitch + 'Hz' : vo.pitch + 'Hz') : '+0Hz';

    // @FIX 2026-08-11 (PERF): batch ALL segments through ONE edge-tts-helper node
    //       process + ONE multi-input ffmpeg convert, instead of 2 spawns per segment.
    //       Generates TTS in parallel-friendly chunks of 8 to bound per-invocation time,
    //       keeps per-segment retry semantics, and only falls back to the per-segment
    //       path if batching throws (never breaks rendering).
    const results = [];
    const CHUNK = 8;
    try {
        for (let i = 0; i < cues.length; i += CHUNK) {
            const chunk = cues.slice(i, i + CHUNK);
            const wavs = mediaPrep.generateTtsBatch(ffmpegBin, edgeHelper, vo.voice, chunk.map(c => c.text), rateStr, pitchStr);
            for (let k = 0; k < chunk.length; k++) {
                const cue = chunk[k];
                const wav = wavs && wavs[k];
                if (!wav) continue;
                let durationMs = 0;
                try {
                    const r = spawnSync(ffmpegBin, ['-i', wav, '-f', 'null', '-'], { stdio: ['ignore', 'pipe', 'pipe'], timeout: 10000 });
                    const match = r.stderr.toString().match(/Duration:\s*(\d+):(\d+):(\d+)\.(\d+)/);
                    if (match) {
                        durationMs = ((parseInt(match[1]) * 3600) + (parseInt(match[2]) * 60) + parseInt(match[3])) * 1000 + parseInt(match[4]) * 10;
                    }
                } catch (_) {}
                results.push({ path: wav, atMs: Number(cue.atMs || 0), durationMs, kind: cue.kind, sceneId: cue.sceneId, text: cue.text });
            }
        }
        if (results.length) return results;
    } catch (e) {
        // fall through to per-segment path below
    }

    // Fallback: per-segment (older helper without batch support / unexpected error).
    for (const cue of cues) {
        const wav = mediaPrep.generateTts(ffmpegBin, edgeHelper, vo.voice, cue.text, rateStr, pitchStr);
        if (!wav) continue;
        let durationMs = 0;
        try {
            const r = spawnSync(ffmpegBin, ['-i', wav, '-f', 'null', '-'], { stdio: ['ignore', 'pipe', 'pipe'], timeout: 10000 });
            const match = r.stderr.toString().match(/Duration:\s*(\d+):(\d+):(\d+)\.(\d+)/);
            if (match) {
                durationMs = ((parseInt(match[1]) * 3600) + (parseInt(match[2]) * 60) + parseInt(match[3])) * 1000 + parseInt(match[4]) * 10;
            }
        } catch (_) {}
        results.push({ path: wav, atMs: Number(cue.atMs || 0), durationMs, kind: cue.kind, sceneId: cue.sceneId, text: cue.text });
    }
    return results;
}

/**
 * Phase 2: Compute per-question durations from TTS measurements.
 * Ensures each question scene is long enough for its TTS to complete,
 * with a minimum buffer for visual phases (intro + reveal).
 *
 * Returns map of sceneId -> required durationMs.
 */
function computeAdaptiveTiming(built, ttsResults, baseTiming, opts) {
    const scenes = (built.plan && built.plan.scenes) || [];
    const o = (opts && typeof opts === 'object') ? opts : {};
    // @FIX 1.4.9.56 (TTS CORRECTNESS — user spec): each question's scene is sized to
    //       the ACTUAL TTS it must speak — full read (question + options per the
    //       checked speak settings) + a short gap + the full reveal (correct answer).
    //       No truncating per-question cap: a long read simply makes that scene
    //       longer, and Q2's audio never starts until Q1's read+reveal have finished.
    //       The old 12.5s cap + read-budget clamp (1.4.9.52) CUT the read mid-option
    //       when TTS was long (e.g. options spoken at rate 1.0) — the user heard
    //       "reaches the 3rd option then Q2 starts". The cap is replaced by a very
    //       generous safety ceiling (90s/question) that only guards against a
    //       pathological runaway, never truncates normal narration.
    const isYoutube = String(o.format || built.videoFormat || 'shorts') === 'youtube';
    const phaseReveal = Number(baseTiming.questionPhases?.reveal || 3000);
    const minQuestionMs = isYoutube ? 8000 : 5200;
    // Safety ceiling only — normal narration (even 20s of options) is never cut.
    const maxQuestionMs = isYoutube ? 120000 : 90000;
    const maxReadingMs  = isYoutube ? 110000 : 80000;
    const ttsBufferMs   = 300;

    const perScene = {};

    // @FIX 2026-08-11 (HOOK OVERLAP): the hook scene was fixed at hookIntro (1.2s) but the
    //       hook TTS can be longer (1.5-2s) — its audio spilled into the first question's
    //       reading. Extend the hook scene to fit its TTS (capped so it can't balloon).
    for (const scene of scenes) {
        if (scene.type !== 'hook') continue;
        if (!scene.id) continue;
        const hookCue = (ttsResults || []).find(t => t && t.sceneId === scene.id && t.kind === 'hook');
        const hookDur = hookCue ? Number(hookCue.durationMs) : 0;
        if (Number.isFinite(hookDur) && hookDur > 0) {
            const hookBase = Number(baseTiming.hookIntro || 1200);
            const hookNeed = Math.min(8000, Math.max(hookBase, hookDur + 200));
            if (hookNeed > Number(scene.durMs || 0)) perScene[scene.id] = hookNeed;
        }
    }

    for (const scene of scenes) {
        if (scene.type !== 'question') continue;
        if (!scene.id) continue; // defensive — every scene must have an id for cue mapping

        const sceneTts = ttsResults.filter(t => t && t.sceneId === scene.id);
        if (!sceneTts.length) continue;

        const qReadCue = sceneTts.find(t => t.kind === 'q_read');
        if (!qReadCue) continue;

        // @FIX 2026-07-25: If TTS generation failed (durationMs 0 / NaN) for this
        //                  scene, skip adaptive timing. The scene keeps its base
        //                  durMs from render-plan.js, whose cues are valid, and
        //                  the rest of the pipeline proceeds without spillover.
        const qReadRaw = Number(qReadCue.durationMs);
        if (!Number.isFinite(qReadRaw) || qReadRaw <= 0) continue;

        // @FIX 2026-07-25: Scene durMs = TTS reading length + reveal phase only.
        //                  No separate "thinking" budget — reveal fires IMMEDIATELY
        //                  after TTS finishes (per user spec 2026-07-25). Pill
        //                  countdown therefore reflects: scene durMs - elapsed,
        //                  which hits 0 exactly when reveal begins.
        //                  Include the 80ms TTS start offset (q_read cue atMs at
        //                  sceneStart + 80) so durMs actually encompasses TTS end.
        const qReadStartOffsetMs = 80;
        // @FIX 1.4.9.56: use the FULL measured read — never truncate it. The read
        //                 WAV is trimmed only at the reveal moment (render-node Phase
        //                 3 + mixer), which is AFTER the full read because the scene
        //                 is sized to read + gap + reveal below.
        const qReadDurMs = Math.max(0, Math.min(qReadRaw, maxReadingMs));

        const revealCue = sceneTts.find(t => t.kind === 'reveal');
        const revealTtsDur = revealCue ? (Number(revealCue.durationMs) || 0) : 0;
        // Reveal TTS must fit inside the reveal window; extend reveal phase if needed.
        const totalRevealWindow = Math.max(phaseReveal, revealTtsDur + 200);

        // Scene = 80ms start + FULL read + 300ms gap + full reveal window.
        // Ceiling is only a pathological-runaway guard (90s), not a truncator.
        const requiredMs = Math.min(
            maxQuestionMs,
            Math.max(
                qReadStartOffsetMs + qReadDurMs + ttsBufferMs + totalRevealWindow,
                minQuestionMs
            )
        );

        const currentDurMs = Number(scene.durMs || 0);
        if (requiredMs > currentDurMs) {
            perScene[scene.id] = requiredMs;
        }
    }

    return perScene;
}

/**
 * @NEW 2026-07-25: Re-derive sfxEvents / fxEvents / duckWindows from the rebuilt
 *                  plan.cues so every audio + visual cue fires at the NEW
 *                  reveal moment, in sync with TTS playback and the pill.
 * Mirrors the cue -> event mapping done by vs-video-templates.getCuePoints so
 * the rebuilt events have the same shapes and gains as the original.
 */
function realignCueDerivedEvents(plan) {
    if (!plan || !Array.isArray(plan.cues)) return plan;

    // @FIX 2026-07-31: Prefer the REAL template getCuePoints — the same one
    //                  MCQVS_PlanBuilder.buildFromPlaylist uses to derive the
    //                  original pre-adaptive events — so the realigned events are
    //                  IDENTICAL in shape: template-aware timer glow rect,
    //                  per-template intensities/colors, intro/outro flashes, and
    //                  scene-boundary transition SFX. The previous hand-ported
    //                  mapping pinned the glow rect to {24,180,72,72} (top-left
    //                  corner instead of the pill) and dropped flash/transition
    //                  events entirely.
    try {
        const tm = _win && _win.MCQVS_TemplateManager;
        if (tm && typeof tm.getTemplate === 'function') {
            const tpl = tm.getTemplate(plan.templateId) || tm.getTemplate('trivia');
            const cfg = tpl && tpl.config;
            if (cfg && typeof cfg.getCuePoints === 'function') {
                const pack = cfg.getCuePoints(plan) || {};
                plan.fxEvents = Array.isArray(pack.fxEvents) ? pack.fxEvents : [];
                plan.sfxEvents = Array.isArray(pack.sfxEvents) ? pack.sfxEvents : [];
                plan.duckWindows = Array.isArray(pack.duckWindows) ? pack.duckWindows : [];
                return plan;
            }
        }
    } catch (_) { /* fall through to the manual mapping below */ }

    const cues = plan.cues.slice();
    const byType = (type) => cues.filter((c) => c.type === type);

    const duckWindows = [];
    const baseMusicDuck = 0.18;
    byType('reveal_start').forEach((c) => {
        const at = Math.max(0, Number(c.atMs || 0));
        duckWindows.push({ startMs: Math.max(0, at - 250), endMs: at + 1400, volume: baseMusicDuck });
    });
    byType('intro_start').forEach((c) => {
        const at = Math.max(0, Number(c.atMs || 0));
        duckWindows.push({ startMs: at, endMs: at + 700, volume: baseMusicDuck });
    });
    byType('outro_start').forEach((c) => {
        const at = Math.max(0, Number(c.atMs || 0));
        duckWindows.push({ startMs: at, endMs: at + 700, volume: baseMusicDuck });
    });

    const sfxEvents = [];
    byType('tick').forEach((c) => sfxEvents.push({ name: 'tick', atMs: Number(c.atMs || 0), gain: 0.55 }));
    byType('reveal_start').forEach((c) => sfxEvents.push({ name: 'reveal', atMs: Number(c.atMs || 0), gain: 1.0 }));
    byType('reveal_correct').forEach((c) => sfxEvents.push({ name: 'correct', atMs: Number(c.atMs || 0), gain: 1.0 }));

    const fxEvents = [];
    // @FIX 2026-07-31: Use OR logic (reveal_correct OR reveal_start) to match
    //                  vs-video-templates.getCuePoints — the previous AND logic
    //                  fired both, doubling particle bursts.
    const particleCues = byType('reveal_correct');
    const revealCues = particleCues.length ? particleCues : byType('reveal_start');
    revealCues.forEach((c) => fxEvents.push({ type: 'particles_burst', atMs: Number(c.atMs || 0), kind: 'sparkles' }));
    // @FIX 2026-07-31: Use template-specific glow intensity and shake magnitude
    //                  instead of hardcoded values, matching vs-video-templates
    //                  getCuePoints fallback. Resolve template opts from _win.
    let glowIntensity = 0.75;
    let shakeMag = 10;
    try {
        const tm2 = _win && _win.MCQVS_TemplateManager;
        if (tm2 && typeof tm2.getTemplate === 'function') {
            const t2 = tm2.getTemplate(plan.templateId) || tm2.getTemplate('trivia');
            const o2 = t2 && t2.config && t2.config.opts;
            if (o2) {
                if (o2.timerGlowIntensity != null) glowIntensity = Number(o2.timerGlowIntensity);
                if (o2.shakeMag != null) shakeMag = Number(o2.shakeMag);
            }
        }
    } catch (_) { /* use defaults */ }
    byType('tick').forEach((c) => fxEvents.push({ type: 'timer_glow', atMs: Number(c.atMs || 0), durationMs: 240, intensity: glowIntensity, color: '#00f0ff' }));
    byType('reveal_start').forEach((c) => fxEvents.push({ type: 'screen_shake', atMs: Number(c.atMs || 0), durationMs: 360, magnitude: shakeMag }));

    plan.fxEvents = fxEvents;
    plan.sfxEvents = sfxEvents;
    plan.duckWindows = duckWindows;
    return plan;
}

/**
 * Phase 3: Rebuild the plan with adaptive per-question durations.
 * Mutates built.plan.scenes and built.totalMs in place.
 */
function rebuildPlanWithAdaptiveTiming(built, perSceneDurations, ttsResults) {
    const scenes = (built.plan && built.plan.scenes) || [];
    // @FIX 2026-07-30: Always rebuild when TTS data exists, even if no scene
    //                  needs duration extension. _revealStartRel is anchored to
    //                  reading TTS end + 300ms (not durMs - revealMs), and the
    //                  answer TTS fires at the same moment as the visual reveal
    //                  (in render-node.js Phase 3). Applies to EVERY question.
    const hasTtsData = Array.isArray(ttsResults) && ttsResults.length > 0;
    if (!hasTtsData && !Object.keys(perSceneDurations).length) return built;

    // @FIX: built.frameMs does not exist — frameMs lives on built.plan.frameMs.
    //       Compute from fps as fallback.
    const frameMs = (built.plan && built.plan.frameMs) ? built.plan.frameMs : (1000 / (built.fps || 30));

    let cursor = 0;
    const newScenes = [];
    for (const scene of scenes) {
        const startMs = Math.round(cursor / frameMs) * frameMs;
        const durMs = perSceneDurations[scene.id] != null
            ? Math.round(perSceneDurations[scene.id] / frameMs) * frameMs
            : scene.durMs;

        // Calculate TTS read duration for this scene (if TTS measurements exist)
        let ttsReadMs = null;
        let revealTtsMs = 0;
        if (ttsResults && scene.type === 'question') {
            const qRead = (ttsResults || []).find(t => t.sceneId === scene.id && t.kind === 'q_read');
            const revealCue = (ttsResults || []).find(t => t.sceneId === scene.id && t.kind === 'reveal');
            if (qRead) {
                revealTtsMs = revealCue ? (Number(revealCue.durationMs) || 0) : 0;
                // @FIX 1.4.9.56: use the FULL measured read. The scene duration was
                // sized to read + gap + reveal in computeAdaptiveTiming (no cap
                // truncation), so the reveal anchor below (80 + full read + 300) is
                // always INSIDE the scene — the read is fully spoken, then the
                // reveal, then the next question.
                ttsReadMs = Math.round(Math.max(0, Number(qRead.durationMs) || 0));
            }
        }

        const newTiming = scene.timing ? { ...scene.timing, questionTotal: durMs } : null;
        if (newTiming && ttsReadMs !== null) {
            newTiming._ttsReadMs = ttsReadMs;
            // @FIX 2026-07-25: _readingEndRel = q_read start offset (80ms) + actual
            //                 TTS duration. The previous formula used introMs, which
            //                 is the visual intro phase duration — unrelated to when
            //                 TTS playback actually begins. Misusing introMs pushed
            //                 _readingEndRel 1s beyond TTS end, so template-manager
            //                 held the pill full during a non-existent reading window.
            newTiming._readingEndRel = Math.round(80 + ttsReadMs);
            // @FIX 2026-07-25: Recompute _revealStartRel from the NEW durMs.
            //                 render-plan.js:78-79 set this from the ORIGINAL endMs,
            //                 so it stayed at 9000 (12s - 3s) even after durMs extended
            //                 to 16s+. template-manager _drawTimerPill (line 944-946)
            //                 prefers _revealStartRel when present, so the stale value
            //                 made the pill countdown hit 0 well before TTS finished.
            const revealMs = Number(scene.timing?.questionPhases?.reveal || 3000);
            // Preserve OLD reveal/scene-start so cue realignment below can derive
            // each tick's relative index (0..4) from its pre-adaptive position.
            newTiming._oldRevealStartRel = scene.timing?._revealStartRel;
            newTiming._oldSceneStartMs   = scene.startMs;
            // @FIX 2026-07-30: Anchor visual reveal to end of TTS reading + 300ms gap,
            //                   NOT to durMs - revealMs. The reading-gap formula ensures the
            //                   reveal fires after the question TTS finishes, and the answer
            //                   TTS fires at the same moment (render-node.js Phase 3).
            // @FIX 1.4.9.52: uses the budget-capped ttsReadMs (above) so the reveal
            //                 never lands beyond the scene's end when the cap binds.
            newTiming._revealStartRel = Math.max(0, 80 + ttsReadMs + 300);
            // @FIX 1.4.9.52: expose the reveal TTS length so Phase 3 can clamp the
            //                 reveal cue inside the scene (belt & braces).
            newTiming._revealTtsMs = Math.round(revealTtsMs);
        }

        newScenes.push({
            ...scene,
            startMs,
            durMs,
            endMs: startMs + durMs,
            timing: newTiming,
        });
        cursor = startMs + durMs;
    }

    built.plan.scenes = newScenes;
    built.plan.totalMs = Math.round(cursor / frameMs) * frameMs;
    built.totalMs = built.plan.totalMs;

    // @FIX 2026-07-25: Realign plan.cues to the rebuilt scene boundaries.
    //                 render-plan.js:82-117 emits reveal_start, countdown_start,
    //                 reveal_correct, and 5 tick cues with absolute atMs computed
    //                 from the ORIGINAL revealStart. After adaptive timing shifted
    //                 scene boundaries, these cues fired at stale positions —
    //                 meaning SFX sparkles, countdown beeps, and reveal animation
    //                 on the correct-answer card fired at the OLD reveal moment,
    //                 out of sync with TTS playback and the pill countdown.
    if (Array.isArray(built.plan.cues)) {
        const sceneById = {};
        for (const s of newScenes) sceneById[s.id] = s;
        const rebuilt = [];
        for (const cue of built.plan.cues) {
            const sc = cue.sceneId ? sceneById[cue.sceneId] : null;
            if (sc) {
                // @FIX 2026-07-31: Remap intro/outro boundary cues to REBUILT scene
                //                  times so intro/outro flash FX and duck windows follow
                //                  scene shifts (extending a question pushes the outro
                //                  right — the outro flash was firing at the old start).
                if (cue.type === 'intro_start') { rebuilt.push({ ...cue, atMs: sc.startMs }); continue; }
                if (cue.type === 'intro_end') { rebuilt.push({ ...cue, atMs: sc.endMs }); continue; }
                if (cue.type === 'outro_start') { rebuilt.push({ ...cue, atMs: sc.startMs }); continue; }
            }
            if (!sc || sc.type !== 'question') { rebuilt.push(cue); continue; }
            const revealMs = Number(sc.timing?.questionPhases?.reveal || 3000);
            // @FIX 2026-07-30: Use _revealStartRel (reading-anchored) instead of
            //                   endMs - revealMs - 1000, so the visual reveal is
            //                   always 300ms after reading ends regardless of durMs.
            const revealStartRel = (sc.timing && sc.timing._revealStartRel !== undefined)
                ? sc.timing._revealStartRel
                : Math.max(0, sc.durMs - revealMs);
            const visualRevealStart = Math.max(0, (sc.startMs || 0) + revealStartRel);
            if (cue.type === 'reveal_start' || cue.type === 'reveal_correct') {
                rebuilt.push({ ...cue, atMs: visualRevealStart });
            } else if (cue.type === 'countdown_start') {
                // @FIX 2026-07-28: Tick window begins 5s before visual reveal (timer=0).
                rebuilt.push({ ...cue, atMs: Math.max(sc.startMs, visualRevealStart - 5000) });
            } else if (cue.type === 'tick') {
                // Re-derive tick index (0..4) from old atMs vs old countdownStart,
                // then reposition to visualRevealStart - (5 - i) * 1000. We must use the
                // ORIGINAL scene startMs + original _revealStartRel because cues'
                // atMs were computed from pre-adaptive scene boundaries.
                const oldRevealStartRel = Number(sc.timing?._oldRevealStartRel || 0);
                const oldSceneStart     = Number(sc.timing?._oldSceneStartMs || 0);
                const oldRevealAbs      = oldSceneStart + oldRevealStartRel;
                const oldCountdownStart = Math.max(oldSceneStart, oldRevealAbs - 5000);
                const tickIdx = Math.round((Number(cue.atMs || 0) - oldCountdownStart) / 1000);
                if (tickIdx >= 0 && tickIdx < 5) {
                    // @FIX 2026-07-28: Ticks anchored to visual reveal start, not scene end.
                    const newCountdownStart = Math.max(sc.startMs, visualRevealStart - 5000);
                    rebuilt.push({ ...cue, atMs: newCountdownStart + tickIdx * 1000 });
                }
            } else {
                rebuilt.push(cue);
            }
        }
        built.plan.cues = rebuilt;

        // @FIX 2026-07-25: Re-derive plan.fxEvents, plan.sfxEvents, plan.duckWindows
        //                 from the rebuilt cues. vs-video-templates.getCuePoints
        //                 produced these from the PRE-adaptive cues inside
        //                 MCQVS_PlanBuilder.buildFromPlaylist (called from
        //                 buildPlanAndState before rebuildPlanWithAdaptiveTiming),
        //                 so count-down ticks, reveal SFX, sparkles and music
        //                 duck windows were firing at the OLD revealStart — out
        //                 of sync with TTS playback and the (now-correct) pill.
        realignCueDerivedEvents(built.plan);

        // @FIX 2026-07-25: Strip the in-flight _oldRevealStartRel / _oldSceneStartMs
        //                 fields from scene.timing once the cue realignment has
        //                 consumed them. Prevents these scratch fields from
        //                 leaking into the cached plan (state.renderPlan) and
        //                 surfacing through RenderPlanValidator / persistence.
        for (const s of newScenes) {
            if (s && s.timing && typeof s.timing === 'object') {
                delete s.timing._oldRevealStartRel;
                delete s.timing._oldSceneStartMs;
            }
        }
    }

    return built;
}

/**
 * Draw one frame using the reused template renderer.
 */
async function drawFrame(ctx, built, frameIndex, media, renderer) {
    const { plan, state, width, height, fps } = built;
    const tMs = Math.round((frameIndex * 1000) / fps);

    let activeScene = null; let elapsedInScene = 0; let phase = null;
    if (plan && Array.isArray(plan.scenes)) {
        for (const sc of plan.scenes) {
            if (tMs >= sc.startMs && tMs < sc.endMs) { activeScene = sc; elapsedInScene = tMs - sc.startMs; break; }
        }
        if (!activeScene && plan.scenes.length) { const last = plan.scenes[plan.scenes.length - 1]; activeScene = last; elapsedInScene = last.durMs; }
    }

    if (activeScene && activeScene.type === 'question' && activeScene.timing) {
        const qp = activeScene.timing.questionPhases || activeScene.timing;
        const intro = Number(qp.intro || 1000);
        const reveal = Number(qp.reveal || 3000);
        // @FIX 2026-07-28: Use _revealStartRel (which accounts for 1s-before-TTS offset)
        //                   instead of the hardcoded durMs - reveal fallback.
        const revealStart = (activeScene.timing._revealStartRel !== undefined)
            ? activeScene.timing._revealStartRel
            : Math.max(0, activeScene.durMs - reveal);
        if (elapsedInScene < intro) phase = 'question_intro';
        else if (elapsedInScene < revealStart) phase = 'question';
        else phase = 'reveal';
    } else if (activeScene && activeScene.type === 'hook') phase = 'hook';
    else if (activeScene && activeScene.type === 'outro') phase = 'outro';

    const frameState = Object.assign({}, state, {
        time: tMs, elapsed: tMs, elapsedInScene,
        // @FIX 2026-07-31: Set prevElapsed to the exact previous frame time.
        //                  unified-renderer falls back to `now - 34` when it is
        //                  missing, leaving a ~7ms dead zone per frame in which
        //                  one-shot FX (particles_burst / screen_shake at exact
        //                  frame multiples) are silently skipped — at 24fps that
        //                  is roughly 1 in 5 reveal sparkle bursts never fired.
        //                  Mirrors vs-render-worker.js:501 (prevElapsed: prevMs).
        prevElapsed: Math.max(0, tMs - Math.round(1000 / fps)),
        currentSceneId: activeScene ? activeScene.id : null,
        activeScene, animationPhase: phase,
        // @FIX 2026-07-31: Consume the REALIGNED plan.fxEvents instead of the
        //                  pre-adaptive snapshot taken by buildPlanAndState.
        //                  rebuildPlanWithAdaptiveTiming mutates plan.fxEvents
        //                  AFTER state was built, so state.fxEvents still held the
        //                  OLD absolute times: the timer glow pulsed at the stale
        //                  countdown (blink appeared at pill 7-8 instead of 5) and
        //                  the reveal sparkle burst fired at the stale reveal
        //                  moment (or was skipped entirely in the dead zone).
        //                  Mirrors vs-render-worker.js:504 (plan.fxEvents read live).
        fxEvents: (plan && Array.isArray(plan.fxEvents)) ? plan.fxEvents : (state.fxEvents || []),
        // Media (mirrors worker INIT payload):
        bgImage: media.bgImage,
        bgVideoFrames: media.bgVideoFrames,
        bgVideoFrameDur: media.bgVideoFrameDur,
        brandLogoImage: media.logoImage,
        // @FIX: Pass per-scene timing (with _revealStartRel, _ttsReadMs, _readingEndRel)
        //       so template-manager's _drawTimerBar/_drawTimerPill use the correct
        //       adaptive timing instead of the global default.
        timing: (activeScene && activeScene.timing) || state.timing || {},
    });

    if (typeof _win.MCQVS_AnimationEngine !== 'undefined' && _win.MCQVS_AnimationEngine.setSeed) {
        _win.MCQVS_AnimationEngine.setSeed((plan.createdAt || plan.seed || 0) + frameIndex * 7919);
    }

    if (!renderer) {
        throw new Error('MCQVS_UnifiedRenderer not loaded (module failed to attach to window shim)');
    }
    await renderer.render(ctx, frameState, {});
}

/**
 * Encode to MP4 (video frames + mixed audio) via FFmpeg.
 */
function renderToMp4(built, ffmpeg, media, audioWavPath, outPath, log, progressCb) {
    return new Promise((resolve, reject) => {
        const { width, height, fps, totalMs } = built;
        const totalFrames = Math.max(1, Math.ceil((totalMs / 1000) * fps));

        const canvas = global.window.createCanvas(width, height);
        const ctx = canvas.getContext('2d', { alpha: false });

        // @FIX 2026-07-18: MCQVS_UnifiedRenderer is a CLASS — its `render` is an
        //      instance method (async). The previous code called it statically
        //      (`MCQVS_UnifiedRenderer.render(...)`), which threw
        //      "_win.MCQVS_UnifiedRenderer.render is not a function" and failed the
        //      entire render. Instantiate once per job, then AWAIT the async render
        //      so each frame is fully drawn before we capture it (otherwise frames
        //      would be grabbed mid-draw).
        const renderer = (_win && _win.MCQVS_UnifiedRenderer) ? new _win.MCQVS_UnifiedRenderer() : null;
        log('UnifiedRenderer ready: ' + (renderer ? 'instance created' : 'MISSING'));

        // FFmpeg inputs: raw video (stdin) + optional audio WAV.
        const args = ['-y'];
        args.push('-f', 'rawvideo', '-pix_fmt', 'rgba', '-s', `${width}x${height}`, '-r', String(fps), '-i', '-');
        if (audioWavPath && fs.existsSync(audioWavPath)) {
            args.push('-i', audioWavPath);
        }
        args.push('-c:v', 'libx264', '-preset', 'ultrafast', '-pix_fmt', 'yuv420p', '-crf', '23', '-movflags', '+faststart');
        if (audioWavPath && fs.existsSync(audioWavPath)) {
            args.push('-c:a', 'aac', '-b:a', '128k', '-shortest');
        } else {
            args.push('-an');
        }
        args.push(outPath);

        log('Spawning ffmpeg (video' + (audioWavPath ? ' + audio' : '') + '): ' + ffmpeg.bin + ' ' + args.join(' '));
        const ff = spawn(ffmpeg.bin, args, { stdio: ['pipe', 'pipe', 'pipe'] });
        // @FIX: Each 1080x1920 RGBA frame is ~8MB. The default stdin highWaterMark
        //       is 16KB, so every single frame write triggers backpressure (drain wait).
        //       Raise it to 16MB so ~2 frames can queue, overlapping draw + encode.
        ff.stdin._writableState.highWaterMark = 16 * 1024 * 1024;
        let ffErr = '';
        ff.stderr.on('data', (d) => { ffErr += d.toString(); });
        ff.on('error', (e) => reject(new Error('ffmpeg spawn error: ' + e.message)));

        let frameIndex = 0;
        let lastFrameTs = Date.now();
        // @FIX 2026-07-18: The old watchdog only set a `stalled` flag that was
        //      never acted on, so a hung frame loop ran until the 17-min process
        //      hard-timeout. Now we actually ABORT with a clear reason if no frame
        //      advances for 180s (genuine backpressure from ffmpeg is far shorter).
        const watchdog = setInterval(() => {
            if (frameIndex < totalFrames && Date.now() - lastFrameTs > 180000) {
                clearInterval(watchdog);
                reject(new Error('Frame draw stalled: no progress for 180s (frame ' + frameIndex + '/' + totalFrames + ')'));
                try { ff.stdin.end(); } catch (_) {}
            }
        }, 60000);

        async function pump() {
            if (frameIndex >= totalFrames) { ff.stdin.end(); clearInterval(watchdog); return; }
            try { await drawFrame(ctx, built, frameIndex, media, renderer); }
            catch (e) { clearInterval(watchdog); reject(new Error('Frame draw failed @' + frameIndex + ': ' + e.message)); ff.stdin.end(); return; }
            const buf = ctx.getImageData(0, 0, width, height).data;
            const ok = ff.stdin.write(Buffer.from(buf.buffer, buf.byteOffset, buf.byteLength));
            frameIndex++;
            lastFrameTs = Date.now();
            if (frameIndex % fps === 0 && progressCb) {
                const pct = built.totalMs ? Math.min(100, Math.round((frameIndex / totalFrames) * 100)) : 0;
                progressCb(pct, frameIndex);
                if (frameIndex % (fps * 10) === 0) {
                    log('Render progress: ' + pct + '% (frame ' + frameIndex + '/' + totalFrames + ')');
                }
            }
            if (ok) setImmediate(pump);
            else ff.stdin.once('drain', pump);
        }

        ff.on('close', (code) => {
            clearInterval(watchdog);
            if (code === 0) resolve({ durationMs: totalMs, frames: totalFrames });
            else reject(new Error('ffmpeg exited ' + code + ' — ' + ffErr.slice(-2000)));
        });
        pump();
    });
}

module.exports = {
    loadRenderingModules,
    buildPlanAndState,
    buildVoiceoverCues,
    generateAndMeasureTts,
    computeAdaptiveTiming,
    rebuildPlanWithAdaptiveTiming,
    realignCueDerivedEvents,
    drawFrame,
    renderToMp4,
    prepareMedia: mediaPrep.prepareMedia,
    buildSfxEvents: mediaPrep.buildSfxEvents,
    generateTts: mediaPrep.generateTts,
    mixAudio,
    _setWindow(w) { _win = w; },
    buildMinimalPlan,
};
