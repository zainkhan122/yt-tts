<?php

/**
 * Research Orchestrator (Workflow)
 *
 * Handles external research (Perplexity / Google Search) and provides
 * intelligence for the content generation pipeline.
 *
 * @package DIT_TrendStudio\Core
 * @MODIFIED 2025-12-18 - Initial scaffold for Phase 2.
 * @MODIFIED 2025-12-18 - Complete implementation with Perplexity + Gemini integration.
 * @MODIFIED 2026-02-05 - Restored from backup to fix missing workflow methods.
 */

namespace DIT\TrendStudio\Core;

use DIT\TrendStudio\Contracts\AIProviderInterface;
use DIT\TrendStudio\Integrations\Gemini\Client as AI_Client;
use DIT\TrendStudio\Content\Perplexity_Client as Perplexity_Client;
use DIT\TrendStudio\Core\Content_Auditor;
use DIT\TrendStudio\Infrastructure\Logger;
use DIT\TrendStudio\Infrastructure\Usage_Tracker;
use DIT\TrendStudio\Infrastructure\API_Error_Parser;
use DIT\TrendStudio\Infrastructure\Quota_State_Manager;
use DIT\TrendStudio\Infrastructure\Backoff_Strategy;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Orchestrates the Phase 2 workflow: Research → Outline → Draft
 *
 * Primary flow: Perplexity (research) → Gemini (outline/draft)
 * Fallback flow: Gemini with Google Search grounding
 */
class Research_Orchestrator
{
    /** @var AIProviderInterface */
    private $ai_client;

    /** @var Logger */
    private $logger;

    /** @var Perplexity_Client|null */
    private $perplexity_client = null;

    /** @var bool */
    private $perplexity_available = false;

    /**
     * Constructor
     *
     * @param AIProviderInterface $ai_client AI provider client (Gemini, OpenRouter, Groq, etc.)
     * @param Logger $logger Logger instance
     */
    public function __construct(AIProviderInterface $ai_client, Logger $logger)
    {
        $this->ai_client = $ai_client;
        $this->logger    = $logger;

        // Initialize Perplexity if API key available
        // Note: Client location might vary, assuming standard integration path or static helper
        $perplexity_key = Perplexity_Client::get_api_key();
        if (!empty($perplexity_key)) {
            $this->perplexity_client = new Perplexity_Client($perplexity_key, $logger);
            $this->perplexity_available = true;
            $this->logger->info('Workflow_Orchestrator initialized with Perplexity');
        } else {
            $this->logger->info('Workflow_Orchestrator initialized without Perplexity (Gemini fallback)');
        }
    }

    /**
     * Get the AI client instance.
     * @since 1.7.0
     *
     * @return AI_Client
     */
    public function get_ai_client(): AIProviderInterface
    {
        return $this->ai_client;
    }

    /**
     * Gather intelligence for a brief.
     *
     * @MODIFIED 2025-12-18 - Full implementation with Perplexity + Gemini fallback.
     *
     * @param array $brief Associative array containing 'topic', 'user_notes', etc.
     * @return array ['facts' => [], 'sources' => [], 'raw_research' => '']
     */
    public function gather_intelligence(array $brief): array
    {
        $topic = $brief['topic'] ?? $brief['idea_title'] ?? '';
        $this->logger->info('Gathering intelligence for topic: ' . $topic);

        // Build prompt data for research
        $prompt_data = [
            'idea_title'  => $topic,
            'idea_text'   => $brief['user_notes'] ?? '',
            'vertical'    => $brief['vertical'] ?? 'general',
            'source_urls' => $brief['source_urls'] ?? '',
        ];

        // Try Perplexity first
        if ($this->perplexity_available) {
            try {
                $research = $this->perplexity_client->research($prompt_data);
                return $this->normalize_intelligence($research);
            } catch (\Exception $e) {
                $this->logger->warning('Perplexity research failed, falling back to Gemini', [
                    'error' => $e->getMessage(),
                ]);
            }
        }

        // Fallback: Use Gemini with grounding
        return $this->gather_with_gemini($prompt_data);
    }

    /**
     * Gather intelligence using Gemini with Google Search grounding.
     *
     * @param array $prompt_data Prompt data
     * @return array Normalized intelligence
     */
    private function gather_with_gemini(array $prompt_data): array
    {
        $this->logger->info('Using Gemini grounding for intelligence gathering');

        try {
            // Use existing generate_article which has grounding enabled
            $result = $this->ai_client->generate_article($prompt_data);

            // Extract facts and sources from grounded response
            $sources = [];
            if (!empty($result['sources'])) {
                foreach ($result['sources'] as $source) {
                    $sources[] = [
                        'url'   => $source['url'] ?? '',
                        'label' => $source['label'] ?? $source['title'] ?? '',
                    ];
                }
            }

            return [
                'facts'         => $this->extract_facts_from_article($result),
                'sources'       => $sources,
                'sources_index' => $this->build_sources_index($sources),
                'raw_research'  => $result['content'] ?? '',
                'provider'      => 'gemini_grounded',
            ];
        } catch (\Exception $e) {
            $this->logger->error('Gemini grounding failed: ' . $e->getMessage());
            return [
                'facts'         => [],
                'sources'       => [],
                'sources_index' => [],
                'raw_research'  => '',
                'provider'      => 'none',
                'error'         => $e->getMessage(),
            ];
        }
    }

    /**
     * Normalize Perplexity research response to standard format.
     *
     * @param array $research Raw Perplexity response
     * @return array Normalized intelligence
     */
    private function normalize_intelligence(array $research): array
    {
        $facts = [];

        // Parse research content into individual facts
        $content = $research['research_content'] ?? '';
        if (!empty($content)) {
            // Split by newlines and bullet points
            $lines = preg_split('/[\r\n]+/', $content);
            foreach ($lines as $line) {
                $line = trim($line, " \t\n\r\0\x0B-•*");
                if (strlen($line) > 20) { // Filter out short lines
                    $facts[] = $line;
                }
            }
        }

        $sources = $research['sources'] ?? [];

        return [
            'facts'         => $facts,
            'sources'       => $sources,
            'sources_index' => $this->build_sources_index($sources),
            'raw_research'  => $content,
            'provider'      => $research['provider'] ?? 'perplexity',
        ];
    }

    /**
     * Build numbered source index for inline citations.
     *
     * @since 1.8.0
     * @param array $sources Array of sources [{url, label}, ...]
     * @return array Numbered index [{id: 1, label, url}, ...]
     */
    private function build_sources_index(array $sources): array
    {
        $index = [];
        foreach ($sources as $i => $source) {
            $index[] = [
                'id'    => $i + 1,
                'label' => $source['label'] ?? '',
                'url'   => $source['url'] ?? '',
            ];
        }
        return $index;
    }

    /**
     * Extract key facts from generated article structure.
     *
     * @param array $article Article data
     * @return array List of fact strings
     */
    private function extract_facts_from_article(array $article): array
    {
        $facts = [];

        // Extract from sections
        if (!empty($article['sections'])) {
            foreach ($article['sections'] as $section) {
                if (!empty($section['content'])) {
                    // Get first paragraph as key fact
                    $stripped = wp_strip_all_tags($section['content']);
                    $sentences = preg_split('/(?<=[.!?])\s+/', $stripped, 3);
                    if (!empty($sentences[0])) {
                        $facts[] = $sentences[0];
                    }
                }
            }
        }

        return $facts;
    }

    /**
     * Generate a JSON outline based on intelligence and the brief.
     *
     * @MODIFIED 2025-12-18 - Full implementation with Gemini prompt.
     *
     * @param array $intelligence Result from gather_intelligence().
     * @param array $brief        Original brief data.
     * @return array JSON-serializable outline tree [{title, slug, summary}, ...]
     */
    public function generate_outline(array $intelligence, array $brief): array
    {
        $topic = $brief['topic'] ?? $brief['idea_title'] ?? '';
        $user_notes = $brief['user_notes'] ?? '';
        $facts = implode("\n- ", $intelligence['facts'] ?? []);
        $sources_text = '';
        foreach (($intelligence['sources'] ?? []) as $src) {
            $sources_text .= "- {$src['label']}: {$src['url']}\n";
        }

        $prompt = <<<PROMPT
You are an editorial content planner. Generate a detailed article outline for the following topic.

## Topic
{$topic}

## Editor Notes
{$user_notes}

## Research Facts
- {$facts}

## Available Sources
{$sources_text}

## Instructions
Create a professional article outline with 5-8 sections. Each section should have:
- A compelling title
- A URL-friendly slug
- A 1-2 sentence summary of what this section will cover

Output as valid JSON array:
[
  {"title": "Section Title", "slug": "section-slug", "summary": "What this section covers"},
  ...
]

Only output the JSON array, no other text.
PROMPT;

        $this->logger->info('Generating outline for topic: ' . $topic);

        try {
            $response = $this->call_gemini_json($prompt);
            $outline = json_decode($response, true);

            if (json_last_error() !== JSON_ERROR_NONE || !is_array($outline)) {
                $this->logger->warning('Failed to parse outline JSON, using fallback');
                return $this->get_fallback_outline($topic);
            }

            // Validate structure
            $valid_outline = [];
            foreach ($outline as $section) {
                if (!empty($section['title']) && !empty($section['slug'])) {
                    $valid_outline[] = [
                        'title'   => sanitize_text_field($section['title']),
                        'slug'    => sanitize_title($section['slug']),
                        'summary' => sanitize_text_field($section['summary'] ?? ''),
                    ];
                }
            }

            if (empty($valid_outline)) {
                return $this->get_fallback_outline($topic);
            }

            $this->logger->info('Outline generated', ['sections' => count($valid_outline)]);
            return $valid_outline;
        } catch (\Exception $e) {
            $this->logger->error('Outline generation failed: ' . $e->getMessage());
            return $this->get_fallback_outline($topic);
        }
    }

    /**
     * Get fallback outline when AI generation fails.
     *
     * @param string $topic Topic name
     * @return array Default outline structure
     */
    private function get_fallback_outline(string $topic): array
    {
        return [
            ['title' => 'Introduction', 'slug' => 'introduction', 'summary' => "Overview of {$topic}"],
            ['title' => 'Background', 'slug' => 'background', 'summary' => 'Context and history'],
            ['title' => 'Key Details', 'slug' => 'key-details', 'summary' => 'Main facts and information'],
            ['title' => 'Analysis', 'slug' => 'analysis', 'summary' => 'Expert insights and implications'],
            ['title' => 'Conclusion', 'slug' => 'conclusion', 'summary' => 'Summary and outlook'],
        ];
    }

    /**
     * Draft a single section using approved sources and user notes.
     *
     * @MODIFIED 2025-12-18 - Full implementation with section-specific prompts.
     *
     * @param string $section_slug Identifier of the section to draft.
     * @param array  $context      Includes 'brief', 'intelligence', 'outline', 'media_ids', 'user_notes'.
     * @return string Generated HTML content for the section.
     */
    public function draft_section(string $section_slug, array $context): string
    {
        $brief = $context['brief'] ?? [];
        $intelligence = $context['intelligence'] ?? [];
        $outline = $context['outline'] ?? [];
        $user_notes = $context['user_notes'] ?? '';
        $media_ids = $context['media_ids'] ?? [];

        // Find section in outline
        $section_info = null;
        $section_index = 0;
        foreach ($outline as $idx => $sec) {
            if ($sec['slug'] === $section_slug) {
                $section_info = $sec;
                $section_index = $idx;
                break;
            }
        }

        if (!$section_info) {
            $this->logger->warning("Section not found in outline: {$section_slug}");
            return "<p>Section content unavailable.</p>";
        }

        $topic = $brief['topic'] ?? $brief['idea_title'] ?? '';
        $section_title = $section_info['title'];
        $section_summary = $section_info['summary'] ?? '';
        $facts = implode("\n- ", $intelligence['facts'] ?? []);

        // Build numbered source index for inline citations (Phase 2: Strict Inline Sourcing)
        $sources_index = $intelligence['sources_index'] ?? [];
        $sources_text = '';
        if (!empty($sources_index)) {
            foreach ($sources_index as $source) {
                $sources_text .= "[{$source['id']}] {$source['label']} — {$source['url']}\n";
            }
        } else {
            // Fallback for legacy data without sources_index
            foreach (($intelligence['sources'] ?? []) as $i => $src) {
                $id = $i + 1;
                $sources_text .= "[{$id}] {$src['label']} — {$src['url']}\n";
            }
        }

        // Get media alt-texts if available
        $media_context = '';
        if (!empty($media_ids)) {
            foreach ($media_ids as $media_id) {
                $alt = get_post_meta($media_id, '_wp_attachment_image_alt', true);
                $title = \get_the_title($media_id);
                if ($alt || $title) {
                    $media_context .= "- Image: " . ($alt ?: $title) . "\n";
                }
            }
        }

        $is_intro = ($section_index === 0);
        $is_conclusion = ($section_index === count($outline) - 1);

        $prev_section_context = '';
        if (!empty($context['prev_section_content'])) {
            $prev_section_context = "\n## Context (Written in Previous Section)\n" . wp_trim_words($context['prev_section_content'], 150) . "\n";
        }

        $prompt = <<<PROMPT
# Role
You are an Elite Executive Editor. Write the "{$section_title}" section for a high-end editorial about "{$topic}".

# Task
Synthesize the research facts below into a cohesive, nuanced narrative section. Ensure it flows perfectly from the preceding thoughts.
{$prev_section_context}

## Section Details
- Title: {$section_title}
- Purpose: {$section_summary}
- Position: Section {$section_index} of article

## Research Facts to Incorporate
- {$facts}

## Source Index (MUST cite every factual claim)
{$sources_text}

## Citation Rule (MANDATORY)
Every factual claim MUST end with at least one citation tag like [1] or [1][3].
If you cannot cite a claim from the Source Index, REMOVE the claim entirely.
Citations are plain text [N], not HTML links.

## Editor Notes
{$user_notes}

## Writing Guidelines (CRITICAL)
1. **Inline Citations**: Every statistic, date, quote, or factual assertion must have a [N] citation immediately after it.
2. **Narrative Stitching**: Connect your first paragraph to the themes of the previous section. Use transitional hooks.
3. **Anti-Roboticism**: Strictly avoid AI cliches: "In the ever-evolving landscape", "tapestry of", "delves into", "a testament to", "crucial role", "in conclusion".
4. **Professionalism**: Write like a human expert. Use varied sentence lengths.
5. **Formatting**: Output clean HTML. Only use <p>, <h3>, <h4>, <ul>, <li>, <a>. 
6. **Word Count**: 200-400 words.
PROMPT;

        if ($is_intro) {
            $prompt .= "\n- This is the INTRODUCTION: Hook the reader, provide context, preview the article. Do NOT use the header 'Introduction'.";
        } elseif ($is_conclusion) {
            $prompt .= "\n- This is the CONCLUSION: Summarize key points, provide final insights or call-to-action. Do NOT use the header 'Conclusion'.";
        }

        $prompt .= "\n\nOutput ONLY the HTML content. No markdown blocks, no titles, no intro text.";

        $this->logger->info("Drafting section: {$section_slug}");

        try {
            $content = $this->call_gemini_text($prompt);

            // Clean up any markdown artifacts
            $content = preg_replace('/^```html?\s*/i', '', $content);
            $content = preg_replace('/\s*```$/', '', $content);

            // Ensure proper HTML structure
            if (strpos($content, '<') === false) {
                $content = '<p>' . nl2br(esc_html($content)) . '</p>';
            }

            // Phase 3: Repair pass for strict inline citations mode
            if (get_option('dit_ts_strict_inline_citations', false)) {
                $sources_index = $intelligence['sources_index'] ?? [];
                if (!empty($sources_index)) {
                    $auditor = new Content_Auditor($this->logger);
                    $citation_result = $auditor->validate_inline_citations($content, $sources_index);

                    if ($citation_result['missing_citation_count'] > 0 || $citation_result['invalid_citation_count'] > 0) {
                        $this->logger->info('Citation repair needed', [
                            'missing' => $citation_result['missing_citation_count'],
                            'invalid' => $citation_result['invalid_citation_count'],
                        ]);
                        $content = $this->repair_citations($content, $citation_result, $sources_index);
                    }
                }
            }

            return $content;
        } catch (\Exception $e) {
            $this->logger->error("Section draft failed: {$section_slug} - " . $e->getMessage());
            return "<p>Content generation failed for this section.</p>";
        }
    }

    /**
     * Draft the entire article in a single API call to prevent quota exhaustion.
     *
     * @since 1.9.0 - Phase 4: Consolidated Generation (Replaces chunked section drafting)
     * @param array $outline Outline structure
     * @param array $context Context containing brief, intelligence, user_notes
     * @return array Associative array of section slugs => generated HTML
     */
    public function draft_full_article(array $outline, array $context): array
    {
        $brief = $context['brief'] ?? [];
        $intelligence = $context['intelligence'] ?? [];
        $user_notes = $context['user_notes'] ?? '';

        $topic = $brief['topic'] ?? $brief['idea_title'] ?? '';
        $facts = implode("\n- ", $intelligence['facts'] ?? []);

        // Build numbered source index
        $sources_index = $intelligence['sources_index'] ?? [];
        $sources_text = '';
        if (!empty($sources_index)) {
            foreach ($sources_index as $source) {
                $sources_text .= "[{$source['id']}] {$source['label']} — {$source['url']}\n";
            }
        } else {
            foreach (($intelligence['sources'] ?? []) as $i => $src) {
                $id = $i + 1;
                $sources_text .= "[{$id}] {$src['label']} — {$src['url']}\n";
            }
        }

        $outline_text = "";
        foreach ($outline as $idx => $sec) {
            $outline_text .= "- Section " . ($idx + 1) . ": " . $sec['title'] . " (Slug: `" . $sec['slug'] . "`)\n  Purpose: " . ($sec['summary'] ?? '') . "\n";
        }

        $prompt = <<<PROMPT
# Role
You are an Elite Executive Editor. Write a complete, high-end editorial about "{$topic}".

# Task
Synthesize the research facts below into a cohesive, nuanced article following the exact outline provided.

## Article Outline (Required Structure)
{$outline_text}

## Research Facts to Incorporate
- {$facts}

## Source Index (MUST cite every factual claim)
{$sources_text}

## Citation Rule (MANDATORY)
Every factual claim MUST end with at least one citation tag like [1] or [1][3].
If you cannot cite a claim from the Source Index, REMOVE the claim entirely.
Citations are plain text [N], not HTML links.

## Editor Notes
{$user_notes}

## Writing Guidelines (CRITICAL)
1. **Professionalism**: Write like a human expert. Use varied sentence lengths. Connect sections with transitional hooks.
2. **Anti-Roboticism**: Strictly avoid AI cliches: "In the ever-evolving landscape", "tapestry of", "delves into", "a testament to".
3. **Introduction & Conclusion**: Hook the reader in section 1. Provide final insights in the last section. Do NOT use headers like "Introduction" or "Conclusion" in the text itself.
4. **Formatting**: ONLY use <p>, <h3>, <h4>, <ul>, <li>, <a>. No markdown blocks inside the HTML.
5. **JSON Mode Output**: 
Your response MUST be a valid JSON object where keys are the specific `Slug`s from the outline, and the values are the generated HTML string for that section.
Example:
{
  "introduction": "<p>Opening paragraph.</p>",
  "background": "<p>Background context.</p>"
}
PROMPT;

        $this->logger->info("Drafting full article (Consolidated Generation)");

        try {
            $response = $this->call_gemini_json($prompt);
            $sections_map = json_decode($response, true);

            if (json_last_error() !== JSON_ERROR_NONE || !is_array($sections_map)) {
                $this->logger->error("Full article draft failed JSON parse. Using fallback split.");
                return [];
            }

            return $sections_map;
        } catch (\Exception $e) {
            $this->logger->error("Full article draft failed: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Call Gemini API expecting JSON response.
     *
     * @param string $prompt Prompt text
     * @return string JSON string response
     * @throws \Exception On API failure
     */
    private function call_gemini_json(string $prompt): string
    {
        // @FIXED 2026-04-24 - Route through injected AIProviderInterface instead of
        // hardcoding Gemini HTTP calls. This respects the user's chosen strategy
        // (OpenRouter, Groq, etc.) and avoids bypassing quota management.
        try {
            $result = $this->ai_client->generateCustomJson($prompt);
            // Gemini returns ['data' => ..., 'raw_request' => ..., 'raw_response' => ...]
            // OpenRouter/Groq/DeepSeek return the flat parsed array directly
            $data = $result['data'] ?? $result;
            return is_array($data) ? (string) wp_json_encode($data) : '';
        } catch (\Throwable $e) {
            $this->logger->warning('Side-band JSON generation failed via provider, falling back to Gemini.', [
                'error' => $e->getMessage(),
            ]);
            // Fallback: only use Gemini direct if provider fails and Gemini key exists
            $gemini_key = AI_Client::get_gemini_key();
            if (empty($gemini_key)) {
                throw new \Exception('Side-band JSON generation failed and no Gemini fallback key: ' . $e->getMessage());
            }
            $model_id = AI_Client::get_model_id();
            $api_version = AI_Client::get_api_version();
            $url = "https://generativelanguage.googleapis.com/{$api_version}/models/{$model_id}:generateContent?key=" . rawurlencode($gemini_key);

            $body = [
                'contents' => [
                    ['parts' => [['text' => $prompt]]]
                ],
                'generationConfig' => [
                    'temperature' => 0.3,
                    'maxOutputTokens' => 32768,
                    'responseMimeType' => 'application/json',
                ],
            ];

            $response = wp_remote_post($url, [
                'headers' => ['Content-Type' => 'application/json'],
                'body' => wp_json_encode($body),
                'timeout' => 60,
            ]);

            if (is_wp_error($response)) {
                throw new \Exception('Gemini API error: ' . $response->get_error_message());
            }

            $code = wp_remote_retrieve_response_code($response);
            $raw_body = wp_remote_retrieve_body($response);

            if ($code === 429 || $code === 403) {
                $error_info = ['error_type' => 'rpm_burst', 'quota_bucket' => 'rpm', 'retry_delay' => 0, 'is_quota_zero' => false];
                if (class_exists(API_Error_Parser::class) && class_exists(Quota_State_Manager::class)) {
                    $headers = wp_remote_retrieve_headers($response);
                    $error_info = API_Error_Parser::parse('gemini', $code, $raw_body, (array) $headers);
                    Quota_State_Manager::calibrate_from_error('gemini', $error_info);
                }
                throw new \Exception("Gemini rate limit ({$error_info['error_type']}).", 0, new \Exception($raw_body));
            }

            if ($code !== 200) {
                throw new \Exception("Gemini API returned {$code}: " . substr($raw_body, 0, 500));
            }

            if (class_exists(Quota_State_Manager::class)) {
                Quota_State_Manager::record_success('gemini', $model_id, ['total_tokens' => 0]);
            }
            if (class_exists(Usage_Tracker::class)) {
                Usage_Tracker::increment('gemini');
            }

            $data = json_decode($raw_body, true);
        return $data['candidates'][0]['content']['parts'][0]['text'] ?? '';
        }
    }

    /**
     * Call Gemini API expecting text response.
     *
     * @param string $prompt Prompt text
     * @return string Text response
     * @throws \Exception On API failure
     */
    private function call_gemini_text(string $prompt): string
    {
        // @FIXED 2026-04-24 - Route through injected AIProviderInterface instead of
        // hardcoding Gemini HTTP calls. This respects the user's chosen strategy.
        try {
            $result = $this->ai_client->generateCustomJson($prompt);
            // Gemini returns ['data' => ..., 'raw_request' => ..., 'raw_response' => ...]
            // OpenRouter/Groq/DeepSeek return the flat parsed array directly
            $data = $result['data'] ?? $result;
            if (!empty($data) && is_array($data)) {
                $first = reset($data);
                if (is_string($first) && strlen($first) > 20) {
                    return $first;
                }
                return (string) wp_json_encode($data);
            }
            return '';
        } catch (\Throwable $e) {
            $this->logger->warning('Side-band text generation failed via provider, falling back to Gemini.', [
                'error' => $e->getMessage(),
            ]);
            $gemini_key = AI_Client::get_gemini_key();
            if (empty($gemini_key)) {
                throw new \Exception('Side-band text generation failed and no Gemini fallback key: ' . $e->getMessage());
            }
            $model_id = AI_Client::get_model_id();
            $api_version = AI_Client::get_api_version();
            $url = "https://generativelanguage.googleapis.com/{$api_version}/models/{$model_id}:generateContent?key=" . rawurlencode($gemini_key);

            $body = [
                'contents' => [
                    ['parts' => [['text' => $prompt]]]
                ],
                'generationConfig' => [
                    'temperature' => 0.7,
                    'maxOutputTokens' => 32768,
                ],
            ];

            $response = wp_remote_post($url, [
                'headers' => ['Content-Type' => 'application/json'],
                'body' => wp_json_encode($body),
                'timeout' => 90,
            ]);

            if (is_wp_error($response)) {
                throw new \Exception('Gemini API error: ' . $response->get_error_message());
            }

            $code = wp_remote_retrieve_response_code($response);
            $raw_body = wp_remote_retrieve_body($response);

            if ($code === 429 || $code === 403) {
                $error_info = ['error_type' => 'rpm_burst', 'quota_bucket' => 'rpm', 'retry_delay' => 0, 'is_quota_zero' => false];
                if (class_exists(API_Error_Parser::class) && class_exists(Quota_State_Manager::class)) {
                    $headers = wp_remote_retrieve_headers($response);
                    $error_info = API_Error_Parser::parse('gemini', $code, $raw_body, (array) $headers);
                    Quota_State_Manager::calibrate_from_error('gemini', $error_info);
                }
                throw new \Exception("Gemini rate limit ({$error_info['error_type']}).", 0, new \Exception($raw_body));
            }

            if ($code !== 200) {
                throw new \Exception("Gemini API returned {$code}: " . substr($raw_body, 0, 500));
            }

            if (class_exists(Quota_State_Manager::class)) {
                Quota_State_Manager::record_success('gemini', $model_id, ['total_tokens' => 0]);
            }
            if (class_exists(Usage_Tracker::class)) {
                Usage_Tracker::increment('gemini');
            }

            $data = json_decode($raw_body, true);
        return $data['candidates'][0]['content']['parts'][0]['text'] ?? '';
        }
    }

    /**
     * Batch repair citations across multiple failing sentences in a single API call.
     * 
     * @since 1.9.0 Phase 4: Consolidated Validation
     * @param array $failing_sentences Array of strings
     * @param array $sources_index Numbered source index
     * @return array Associative array of [original_sentence => fixed_sentence]
     */
    public function batch_repair_citations(array $failing_sentences, array $sources_index): array
    {
        if (empty($failing_sentences)) {
            return [];
        }

        $failing_text = implode("\n", array_map(fn($c) => "- " . $c, $failing_sentences));
        $sources_text = '';
        foreach ($sources_index as $src) {
            $sources_text .= "[{$src['id']}] {$src['label']} — {$src['url']}\n";
        }

        $prompt = <<<PROMPT
# Task
Rewrite ONLY the following sentences to add correct inline citations. Keep meaning intact.

## Failing Sentences
{$failing_text}

## Source Index
{$sources_text}

## Rules
1. Add [N] citation tags to each sentence where N matches a source from the index.
2. If a claim cannot be cited, soften it (e.g., add "reportedly" or "according to reports").
3. Return ONLY a valid JSON object mapping the original sentence exact string as the key to the corrected sentence as the value.
Example:
{
  "Apple sold millions of units.": "Apple sold millions of units [2]."
}
PROMPT;

        try {
            $response = $this->call_gemini_json($prompt);
            $map = json_decode($response, true);
            if (json_last_error() === JSON_ERROR_NONE && is_array($map)) {
                $this->logger->info('Batch citation repair completed', ['count' => count($map)]);
                return $map;
            }
        } catch (\Exception $e) {
            $this->logger->warning('Batch citation repair failed: ' . $e->getMessage());
        }

        return [];
    }

    /**
     * Repair citations in content by rewriting sentences with missing or invalid citations.
     *
     * @since 1.8.0 Phase 3: Strict Inline Sourcing
     * @param string $content       Original HTML content
     * @param array  $citation_audit Validation results from Content_Auditor
     * @param array  $sources_index  Numbered source index
     * @return string Repaired content
     */
    private function repair_citations(string $content, array $citation_audit, array $sources_index): string
    {
        // Build list of failing sentences
        $failing = array_filter(
            $citation_audit['claims'] ?? [],
            fn($c) =>
            !$c['has_inline_citation'] || !empty($c['invalid_citation_ids'])
        );

        if (empty($failing)) {
            return $content;
        }

        $failing_text = implode("\n", array_map(fn($c) => "- " . $c['sentence'], $failing));
        $sources_text = '';
        foreach ($sources_index as $src) {
            $sources_text .= "[{$src['id']}] {$src['label']} — {$src['url']}\n";
        }

        $prompt = <<<PROMPT
# Task
Rewrite ONLY the following sentences to add correct inline citations. Keep meaning intact.

## Failing Sentences
{$failing_text}

## Source Index
{$sources_text}

## Rules
1. Add [N] citation tags to each sentence where N matches a source from the index.
2. If a claim cannot be cited, soften it (e.g., add "reportedly" or "according to reports").
3. Return ONLY the corrected sentences as plain text, one per line, in the same order.
4. Do NOT add markdown formatting, bullet points, or any other decoration.
PROMPT;

        try {
            $fixed = $this->call_gemini_text($prompt);
            $fixed_lines = preg_split('/[\r\n]+/', trim($fixed));

            // Replace failing sentences with fixed versions
            $failing_array = array_values($failing);
            foreach ($failing_array as $i => $fail) {
                if (!empty($fixed_lines[$i])) {
                    $fixed_sentence = trim($fixed_lines[$i], "- \t\n\r");
                    $content = str_replace($fail['sentence'], $fixed_sentence, $content);
                }
            }

            $this->logger->info('Citation repair completed', [
                'repaired_count' => count($failing_array),
            ]);
        } catch (\Exception $e) {
            $this->logger->warning('Citation repair failed: ' . $e->getMessage());
        }

        return $content;
    }

    /**
     * Get Gemini API key.
     *
     * @return string API key
     */
    private function get_gemini_key(): string
    {
        return AI_Client::get_gemini_key();
    }

    /**
     * Check if Perplexity is available.
     *
     * @return bool
     */
    public function is_perplexity_available(): bool
    {
        return $this->perplexity_available;
    }
}
