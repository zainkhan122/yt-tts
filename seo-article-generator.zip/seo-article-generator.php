<?php

/**
 * SEO Article Generator
 *
 * @package     SEO_Article_Generator
 * @author      Your Name
 * @copyright   2025
 * @license     GPL-2.0-or-later
 *
 * @wordpress-plugin
 * Plugin Name: SEO Article Generator
 * Plugin URI:  https://softwareswave.com
 * Description: SEO article for software download pages
 * Version: 2.28.1
 * Author:            TrendStudio
 * Author URI:  https://softwareswave.com
 * Text Domain:       seo-article-generator
 * Domain Path:       /languages
 */

// v2.29.0 - 2026-06-01: [PUBLISH WATCHDOG] Added seo_gen_publish_watchdog recurring AS action (default 120s, option-tunable) that force-publishes plugin-owned posts stuck in 'future'. Complements WP-Cron for hosts that disable it. SSOT ownership gate via Post_Type_Classifier; per-blog MySQL lock prevents overlap.
// v2.28.1 - 2026-07-31: [BUFFER OBFUSCATION FIX] Changed link obfuscation to wrap the last hostname dot (domain.TLD boundary) instead of the first, producing www.site(.)com/post-link instead of www(.)site.com/post-link.
// v2.28.0 - 2026-04-23: [THREE-LAYER INTELLIGENCE] Complete API error system overhaul. Added API_Error_Info (typed value object), API_Error_Parser (provider-aware structured parser), and Quota_State_Manager (live quota tracking with predictive throttling). Adaptive backoff replaces static delays with API's exact retryDelay and auto-adjusts min_interval based on quota utilization. All error classification now routes through SSOT.
// v2.26.6 - 2026-03-09: [POLLER FIX] Resolved WP Auto Draft Poller stall by adding missing database columns (draft_post_id, featured_image_id, source_type) and implementing robust try-catch error handling in the polling loop.
// v2.26.5 - 2026-03-09: [TIME ZONE] Fixed critical recurring time zone bug. All scheduling and dashboard counts now strictly follow Website Local Time. Fixed 0-count bug in Completed tab and hardened settings persistence.


// Prevent direct access
if (! defined('ABSPATH')) {
	exit;
}

// Define plugin constants
define('SEO_GEN_VERSION', '2.28.1');
define('SEO_GEN_PLUGIN_FILE', __FILE__);
define('SEO_GEN_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('SEO_GEN_PLUGIN_URL', plugin_dir_url(__FILE__));
define('SEO_GEN_PLUGIN_BASENAME', plugin_basename(__FILE__));

// DIAGNOSTIC: Enable download link debugging (set to false or remove in production)
if ( ! defined( 'SEO_GEN_DEBUG_LINKS' ) ) {
	define( 'SEO_GEN_DEBUG_LINKS', true );
}

// v2.26.7: Secure Action Scheduler inclusion to prevent fatal redeclaration errors.
if (! class_exists('ActionScheduler')) {
	$as_path = __DIR__ . '/vendor/action-scheduler/action-scheduler.php';
	if (file_exists($as_path)) {
		require_once $as_path;
	}
}

if (class_exists('ActionScheduler')) {
	add_filter('action_scheduler_run_queue_on_admin_init', '__return_false', 10, 0);

	// FIX AS RECURRING ACTION KILLER: AS 3.9.3 kills recurring actions after
	// 5 consecutive failures. Our heartbeat handlers routinely exceed PHP
	// max_execution_time on slow AI generations (cURL 180s timeout + retry path
	// = 250s+ heartbeat). This marked queue_worker/sync_finalizer/etc as
	// STATUS_FAILED repeatedly until AS stopped rescheduling them entirely,
	// producing the persistent "Re-created missing recurring action" loop seen
	// in production logs. Set threshold so high that the killer never engages
	// for these handlers — the meta-watchdog in Discovery_Bootstrap already
	// recreates missing recurring actions every page load.
	add_filter('action_scheduler_recurring_action_failure_threshold', function ( $threshold ) {
		return 999999;
	}, 10, 1 );
}

/**
 * Autoloader for plugin classes
 */
spl_autoload_register(
	function ($class) {
		$prefix = 'SEO_Article_Generator\\';
		$len = strlen($prefix);

		if (strncmp($prefix, $class, $len) !== 0) {
			return;
		}

		$relative_class = (string) substr($class, $len);

		if (strpos($relative_class, 'Admin\\') === 0) {
			$base_dir = SEO_GEN_PLUGIN_DIR . 'admin/';
			$relative_class = substr($relative_class, 6);
		} else {
			$base_dir = SEO_GEN_PLUGIN_DIR . 'includes/';
		}

		$parts = explode('\\', $relative_class);
		$class_name = array_pop($parts);
		$dir_path = empty($parts) ? '' : strtolower(implode('/', $parts)) . '/';

		$is_trait = (strpos($relative_class, 'Traits\\') !== false);
		$prefix_type = $is_trait ? 'trait-' : 'class-';
		
		// Convert Class_Name to class-class-name.php AND RankMath to rank-math
		$clean_class = preg_replace('/([a-z])([A-Z])/', '$1-$2', $class_name);
		$file_name = $prefix_type . strtolower(str_replace('_', '-', $clean_class)) . '.php';
		$file = $base_dir . $dir_path . $file_name;

		if (file_exists($file)) {
			require $file;
		}
	}
);

/**
 * Initialize the plugin internals only after schema is confirmed current.
 */
if (! function_exists('seo_gen_init')) {
	function seo_gen_init()
	{
		try {
			if (! class_exists('SEO_Article_Generator\\Plugin')) {
				throw new \RuntimeException('Plugin class not found. Core files may be missing.');
			}

			$plugin = \SEO_Article_Generator\Plugin::get_instance();
			$plugin->init();

			if (class_exists('SEO_Article_Generator\\Discovery\\Discovery_Bootstrap')) {
				$discovery = \SEO_Article_Generator\Discovery\Discovery_Bootstrap::get_instance();
				$discovery->init();
			}

			if (class_exists('SEO_Article_Generator\\Tools\\Sentinel_Injector')) {
				\SEO_Article_Generator\Tools\Sentinel_Injector::register();
			}
		} catch (\Throwable $e) {
			error_log('SEO Article Generator initialization failed: ' . $e->getMessage());

			add_action(
				'admin_notices',
				function () use ($e) {
					if (current_user_can('manage_options')) {
						printf(
							'<div class="notice notice-error"><p><strong>SEO Article Generator Error:</strong> %s</p></div>',
							esc_html($e->getMessage())
						);
					}
				}
			);
		}
	}
}

/**
 * Installer loader helper.
 */
if (! function_exists('seo_gen_require_installer')) {
	function seo_gen_require_installer()
	{
		require_once SEO_GEN_PLUGIN_DIR . 'includes/class-installer.php';
	}
}

/**
 * Upgrade lock key.
 */
if (! function_exists('seo_gen_upgrade_lock_key')) {
	function seo_gen_upgrade_lock_key()
	{
		return 'seo_gen_upgrade_lock';
	}
}

if (! function_exists('seo_gen_upgrade_lock_ttl')) {
	function seo_gen_upgrade_lock_ttl()
	{
		return 15 * MINUTE_IN_SECONDS;
	}
}

/**
 * Check whether an upgrade is currently running.
 */
if (! function_exists('seo_gen_is_upgrade_locked')) {
	function seo_gen_is_upgrade_locked()
	{
		$locked_at = (int) get_option(seo_gen_upgrade_lock_key(), 0);

		if ($locked_at <= 0) {
			return false;
		}

		if ((time() - $locked_at) > seo_gen_upgrade_lock_ttl()) {
			delete_option(seo_gen_upgrade_lock_key());
			return false;
		}

		return true;
	}
}

/**
 * Acquire a short-lived upgrade mutex.
 */
if (! function_exists('seo_gen_acquire_upgrade_lock')) {
	function seo_gen_acquire_upgrade_lock()
	{
		$locked_at = (int) get_option(seo_gen_upgrade_lock_key(), 0);

		if ($locked_at > 0 && (time() - $locked_at) > seo_gen_upgrade_lock_ttl()) {
			delete_option(seo_gen_upgrade_lock_key());
		}

		return add_option(seo_gen_upgrade_lock_key(), time(), '', 'no');
	}
}

/**
 * Release upgrade mutex.
 */
if (! function_exists('seo_gen_release_upgrade_lock')) {
	function seo_gen_release_upgrade_lock()
	{
		delete_option(seo_gen_upgrade_lock_key());
	}
}

/**
 * Return whether schema is current.
 */
if (! function_exists('seo_gen_schema_is_current')) {
	function seo_gen_schema_is_current()
	{
		seo_gen_require_installer();
		return \SEO_Article_Generator\Installer::is_schema_healthy();
	}
}

/**
 * Run DB upgrade only in safe contexts.
 * Admin-only by default; also allow WP-CLI.
 */
if (! function_exists('seo_gen_maybe_upgrade')) {
	function seo_gen_maybe_upgrade()
	{
		if (! is_admin() && ! (defined('WP_CLI') && WP_CLI)) {
			return;
		}

		seo_gen_require_installer();

		if (! \SEO_Article_Generator\Installer::needs_upgrade() && \SEO_Article_Generator\Installer::is_schema_healthy()) {
			return;
		}

		if (! seo_gen_acquire_upgrade_lock()) {
			return;
		}

		try {
			update_option(\SEO_Article_Generator\Installer::OPTION_INSTALL_STATE, 'installing', false);
			delete_option(\SEO_Article_Generator\Installer::OPTION_INSTALL_ERR);

			\SEO_Article_Generator\Installer::upgrade();
		} catch (\Throwable $e) {
			error_log('SEO Article Generator upgrade failed: ' . $e->getMessage());
			update_option(\SEO_Article_Generator\Installer::OPTION_INSTALL_ERR, $e->getMessage(), false);
			update_option(\SEO_Article_Generator\Installer::OPTION_INSTALL_STATE, 'failed', false);
		} finally {
			seo_gen_release_upgrade_lock();
		}
	}
}
add_action('plugins_loaded', 'seo_gen_maybe_upgrade', 5);

/**
 * Safe boot gate.
 * Never boot plugin services against an outdated schema.
 */
if (! function_exists('seo_gen_boot')) {
	function seo_gen_boot()
	{
		seo_gen_require_installer();

		$install_state = get_option(\SEO_Article_Generator\Installer::OPTION_INSTALL_STATE, 'installed');

		if ($install_state === 'installing' || $install_state === 'failed') {
			return;
		}

		if (seo_gen_is_upgrade_locked()) {
			return;
		}

		if (! seo_gen_schema_is_current()) {
			return;
		}

		seo_gen_init();
	}
}
add_action('plugins_loaded', 'seo_gen_boot', 20);

/**
 * Optional admin notice so upgrades are not invisible.
 */
if (! function_exists('seo_gen_upgrade_admin_notice')) {
	function seo_gen_upgrade_admin_notice()
	{
		if (! current_user_can('manage_options')) {
			return;
		}

		if (seo_gen_is_upgrade_locked()) {
			echo '<div class="notice notice-warning"><p><strong>SEO Article Generator:</strong> Database upgrade is currently running.</p></div>';
			return;
		}

		if (! seo_gen_schema_is_current()) {
			$error = get_option(\SEO_Article_Generator\Installer::OPTION_INSTALL_ERR);
			if ($error) {
				echo '<div class="notice notice-error"><p><strong>SEO Article Generator:</strong> Database upgrade failed: ' . esc_html($error) . '</p><p>Check your error logs or try deactivating and reactivating the plugin.</p></div>';
			} else {
				echo '<div class="notice notice-warning"><p><strong>SEO Article Generator:</strong> Database upgrade is pending. Visit this admin page again in a moment.</p></div>';
			}
		}
	}
}
add_action('admin_notices', 'seo_gen_upgrade_admin_notice');

/**
 * Activation hook
 */
function seo_gen_activate()
{
	try {
		$installer_file = SEO_GEN_PLUGIN_DIR . 'includes/class-installer.php';

		if (! file_exists($installer_file)) {
			throw new \RuntimeException('Installer class file not found');
		}

		require_once $installer_file;

		if (! class_exists('SEO_Article_Generator\\Installer')) {
			throw new \RuntimeException('Installer class not found');
		}

		\SEO_Article_Generator\Installer::activate();
	} catch (\Throwable $e) {
		seo_gen_release_upgrade_lock();

		wp_die(
			'Plugin activation failed: ' . esc_html($e->getMessage()),
			'SEO Article Generator Activation Error',
			array('back_link' => true)
		);
	}
}
register_activation_hook(__FILE__, 'seo_gen_activate');

/**
 * Deactivation hook
 */
function seo_gen_deactivate()
{
	try {
		require_once SEO_GEN_PLUGIN_DIR . 'includes/class-installer.php';
		seo_gen_release_upgrade_lock();
		\SEO_Article_Generator\Installer::deactivate();
	} catch (\Throwable $e) {
		seo_gen_release_upgrade_lock();
		error_log('SEO Article Generator deactivation error: ' . $e->getMessage());
	}
}
register_deactivation_hook(__FILE__, 'seo_gen_deactivate');
