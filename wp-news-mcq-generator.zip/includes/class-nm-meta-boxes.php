<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Meta Boxes Manager
 * Handles all custom meta boxes for the MCQ post type.
 */
class NM_Meta_Boxes {

	public static function init() {
		add_action( 'add_meta_boxes', array( self::class, 'add_meta_boxes' ) );
		add_action( 'save_post_mcq', array( self::class, 'save_meta_box_data' ) );
		add_filter( 'manage_mcq_posts_columns', array( self::class, 'set_custom_columns' ) );
		add_action( 'manage_mcq_posts_custom_column', array( self::class, 'custom_column_content' ), 10, 2 );
		add_action( 'restrict_manage_posts', array( self::class, 'add_reported_filter' ) );
		add_filter( 'parse_query', array( self::class, 'filter_mcqs_by_reported_status' ) );
	}

	public static function add_meta_boxes() {
		add_meta_box( 'nm_mcq_details', 'MCQ Details', array( self::class, 'render_details_meta_box' ), 'mcq', 'normal', 'high' );
		add_meta_box( 'nm_eat_meta_box', 'Source Attribution (E-A-T)', array( self::class, 'render_eat_meta_box' ), 'mcq', 'normal', 'default' );
		add_meta_box( 'nm_related_questions_meta', '🔗 Related Questions', array( self::class, 'render_related_meta_box' ), 'mcq', 'side', 'default' );
	}

	public static function render_details_meta_box( $post ) {
		wp_nonce_field( 'nm_save_mcq_details', 'nm_mcq_details_nonce' );
		$options         = get_post_meta( $post->ID, 'mcq_options', true ) ?: array(
			'A' => '',
			'B' => '',
			'C' => '',
			'D' => '',
		);
		$answer          = get_post_meta( $post->ID, 'mcq_answer', true );
		$explanation     = get_post_meta( $post->ID, 'mcq_explanation', true );
		$is_reported     = get_post_meta( $post->ID, 'mcq_reported', true );
		$report_reason   = get_post_meta( $post->ID, 'mcq_report_reason', true );
		$difficulty      = get_post_meta( $post->ID, 'mcq_difficulty', true );
		$cognitive_level = get_post_meta( $post->ID, 'mcq_cognitive_level', true );

		?>
		<style>.nm-mb-row{margin-bottom:10px;}.nm-mb-label{font-weight:bold;display:block;margin-bottom:5px;}.nm-mb-input{width:100%;}</style>
		<div class="nm-meta-box">
			<?php foreach ( array( 'A', 'B', 'C', 'D' ) as $opt ) : ?>
			<div class="nm-mb-row">
				<label class="nm-mb-label">Option <?php echo $opt; ?>:</label>
				<input type="text" name="nm_mcq_options[<?php echo $opt; ?>]" value="<?php echo esc_attr( $options[ $opt ] ); ?>" class="nm-mb-input">
			</div>
			<?php endforeach; ?>
			<div class="nm-mb-row">
				<label class="nm-mb-label">Correct Answer:</label>
				<select name="nm_mcq_answer" class="nm-mb-input">
					<?php foreach ( array( 'A', 'B', 'C', 'D' ) as $opt ) : ?>
						<option value="<?php echo $opt; ?>" <?php selected( $answer, $opt ); ?>>Option <?php echo $opt; ?></option>
					<?php endforeach; ?>
				</select>
			</div>
			<div class="nm-mb-row">
				<label class="nm-mb-label">Difficulty:</label>
				<select name="nm_mcq_difficulty" class="nm-mb-input">
					<option value="">Select Difficulty</option>
					<option value="easy" <?php selected( $difficulty, 'easy' ); ?>>Easy</option>
					<option value="medium" <?php selected( $difficulty, 'medium' ); ?>>Medium</option>
					<option value="hard" <?php selected( $difficulty, 'hard' ); ?>>Hard</option>
				</select>
			</div>
			<div class="nm-mb-row">
				<label class="nm-mb-label">Cognitive Level (Bloom):</label>
				<select name="nm_mcq_cognitive_level" class="nm-mb-input">
					<option value="">Select Cognitive Level</option>
					<option value="remember"   <?php selected( $cognitive_level, 'remember' ); ?>>Remember</option>
					<option value="understand" <?php selected( $cognitive_level, 'understand' ); ?>>Understand</option>
					<option value="apply"      <?php selected( $cognitive_level, 'apply' ); ?>>Apply</option>
					<option value="analyze"    <?php selected( $cognitive_level, 'analyze' ); ?>>Analyze</option>
					<option value="evaluate"   <?php selected( $cognitive_level, 'evaluate' ); ?>>Evaluate</option>
				</select>
			</div>
			<div class="nm-mb-row">
				<label class="nm-mb-label">Explanation:</label>
				<textarea name="nm_mcq_explanation" rows="5" class="nm-mb-input"><?php echo esc_textarea( $explanation ); ?></textarea>
			</div>
			<?php if ( $is_reported === 'yes' ) : ?>
				<div style="background:#fff8e1;border-left:4px solid #ffc107;padding:10px;margin-top:15px;">
					<strong>⚠️ Reported:</strong> <?php echo esc_html( $report_reason ?: 'No reason provided.' ); ?>
					<br><label><input type="checkbox" name="nm_clear_report" value="yes"> Clear Report</label>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	public static function render_eat_meta_box( $post ) {
		wp_nonce_field( 'nm_save_eat_meta', 'nm_eat_meta_nonce' );
		$source_url   = get_post_meta( $post->ID, 'mcq_source_url', true );
		$source_name  = get_post_meta( $post->ID, 'mcq_source_name', true );
		$author_name  = get_post_meta( $post->ID, 'mcq_author_name', true );
		$fact_checked = get_post_meta( $post->ID, 'mcq_fact_checked', true );
		?>
		<p><label><strong>Source URL:</strong></label><br><input type="url" name="mcq_source_url" value="<?php echo esc_url( $source_url ); ?>" class="widefat"></p>
		<p><label><strong>Source Name:</strong></label><br><input type="text" name="mcq_source_name" value="<?php echo esc_attr( $source_name ); ?>" class="widefat"></p>
		<p><label><strong>Author:</strong></label><br><input type="text" name="mcq_author_name" value="<?php echo esc_attr( $author_name ); ?>" class="widefat"></p>
		<p><label><input type="checkbox" name="mcq_fact_checked" value="yes" <?php checked( $fact_checked, 'yes' ); ?>> Fact-Checked</label></p>
		<?php
	}

	public static function render_related_meta_box( $post ) {
		// We can't easily move nm_get_related_questions here without circular deps,
		// so we'll check if it exists in the global scope (from 21-related-questions.php)
		if ( function_exists( 'nm_get_related_questions' ) ) {
			$related = nm_get_related_questions( $post->ID, 5 );
			if ( empty( $related ) ) {
				echo '<p>No related questions found.</p>';
			} else {
				echo '<ul>';
				foreach ( $related as $item ) {
					$percent = round( $item['similarity'] * 100 );
					echo '<li><a href="' . get_edit_post_link( $item['id'] ) . '">' . esc_html( $item['title'] ) . '</a> <small>(' . $percent . '%)</small></li>';
				}
				echo '</ul>';
			}
		} else {
			echo '<p>Related questions module not loaded.</p>';
		}
	}

    public static function save_meta_box_data( $post_id ) {
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }
        if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
            return;
        }

        if ( ! isset( $_POST['nm_mcq_details_nonce'] ) ) {
            return;
        }
        if ( ! wp_verify_nonce( $_POST['nm_mcq_details_nonce'], 'nm_save_mcq_details' ) ) {
            return;
        }

        if ( isset( $_POST['nm_mcq_options'] ) ) {
				update_post_meta( $post_id, 'mcq_options', array_map( 'sanitize_text_field', $_POST['nm_mcq_options'] ) );
			}
			if ( isset( $_POST['nm_mcq_answer'] ) ) {
				update_post_meta( $post_id, 'mcq_answer', strtoupper( sanitize_key( $_POST['nm_mcq_answer'] ) ) );
			}
			if ( isset( $_POST['nm_mcq_explanation'] ) ) {
				update_post_meta( $post_id, 'mcq_explanation', wp_kses_post( $_POST['nm_mcq_explanation'] ) );
			}
			if ( isset( $_POST['nm_mcq_difficulty'] ) ) {
				update_post_meta( $post_id, 'mcq_difficulty', sanitize_key( $_POST['nm_mcq_difficulty'] ) );
			}
			if ( isset( $_POST['nm_mcq_cognitive_level'] ) ) {
				update_post_meta( $post_id, 'mcq_cognitive_level', sanitize_key( $_POST['nm_mcq_cognitive_level'] ) );
			}
	if ( isset( $_POST['nm_clear_report'] ) ) {
		delete_post_meta( $post_id, 'mcq_reported' );
		delete_post_meta( $post_id, 'mcq_report_reason' );
	}

	// E-A-T
	if ( isset( $_POST['nm_eat_meta_nonce'] ) && wp_verify_nonce( $_POST['nm_eat_meta_nonce'], 'nm_save_eat_meta' ) ) {
		update_post_meta( $post_id, 'mcq_source_url', esc_url_raw( $_POST['mcq_source_url'] ) );
		update_post_meta( $post_id, 'mcq_source_name', sanitize_text_field( $_POST['mcq_source_name'] ) );
		update_post_meta( $post_id, 'mcq_author_name', sanitize_text_field( $_POST['mcq_author_name'] ) );
		update_post_meta( $post_id, 'mcq_fact_checked', isset( $_POST['mcq_fact_checked'] ) ? 'yes' : 'no' );
	}
	}

	public static function set_custom_columns( $columns ) {
		unset( $columns['date'] );
		$columns['topic']    = 'Topic';
		$columns['reported'] = 'Reported';
		$columns['date']     = 'Date';
		return $columns;
	}

	public static function custom_column_content( $column, $post_id ) {
		switch ( $column ) {
			case 'topic':
				echo get_the_term_list( $post_id, 'topic', '', ', ', '' ) ?: '—';
				break;
			case 'reported':
				echo ( get_post_meta( $post_id, 'mcq_reported', true ) === 'yes' ) ? '<span style="color:red;font-weight:bold;">Yes</span>' : 'No';
				break;
		}
	}

	public static function add_reported_filter( $post_type ) {
		if ( 'mcq' === $post_type ) {
			$val = $_GET['reported_filter'] ?? '';
			echo '<select name="reported_filter"><option value="">All Statuses</option><option value="yes" ' . selected( $val, 'yes', false ) . '>Reported</option><option value="no" ' . selected( $val, 'no', false ) . '>Not Reported</option></select>';
		}
	}

	public static function filter_mcqs_by_reported_status( $query ) {
		global $pagenow;
		if ( is_admin() && $query->is_main_query() && $pagenow === 'edit.php' && ( $_GET['post_type'] ?? '' ) === 'mcq' && ! empty( $_GET['reported_filter'] ) ) {
			$query->set( 'meta_key', 'mcq_reported' );
			$query->set( 'meta_value', sanitize_text_field( $_GET['reported_filter'] ) );
		}
	}
}
?>
