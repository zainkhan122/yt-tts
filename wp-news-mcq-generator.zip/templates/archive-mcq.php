<?php

/**
 * Archive Template for MCQ Post Type
 * Version 3.2 - Hardened with XSS Prevention
 *
 * @MODIFIED: Added esc_html(), esc_url(), and esc_attr() to all dynamic output.
 */

if (!defined('ABSPATH')) exit;

get_header();
// Detect if we are on the Exam landing page (/exam/)
// This is a normal WordPress Page with slug "exam"
$is_exam_root = is_page() && get_post_field( 'post_name', get_queried_object_id() ) === 'exam';
$is_astra = function_exists('astra_page_layout');
?>
<?php if ($is_astra): ?>
    <div id="primary" <?php astra_primary_class(); ?>>
        <?php astra_primary_content_top(); ?>
    <?php endif; ?>

    <div class="nm-topic-wrap">

        <div class="nm-archive-hero">
    <h1>
        📚 <?php echo $is_exam_root ? 'Browse Exam MCQs' : 'Browse MCQs'; ?>
    </h1>
    <p>
        <?php
        if ( $is_exam_root ) {
            echo 'Select an exam below or scroll to see all exam-tagged questions';
        } else {
            echo 'Select a topic below or scroll to see all questions';
        }
        ?>
    </p>
        </div>
		<div class="nm-custom-breadcrumb">
    <a href="<?php echo esc_url( home_url() ); ?>">🏠 Home</a>
    <span class="separator">›</span>
    <span class="current">
        <?php echo $is_exam_root ? 'Exams' : 'MCQs'; ?>
    </span>
</div>
        <div class="nm-topic-tabs">
            <h2 class="nm-topic-tabs-title">
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                    <path d="M2 2H16M2 6H16M2 10H16M2 14H16" stroke="currentColor" stroke-width="2" stroke-linecap="round" />
                </svg>
               <?php echo $is_exam_root ? 'Browse by Exam' : 'Browse by Topic'; ?>
</h2>
            <div class="nm-tabs-grid">
    <?php
    if ( $is_exam_root ) {
        // On /exam/: list all Exams (nm_exam taxonomy)
        $exam_terms = get_terms( [
            'taxonomy'   => 'nm_exam',
            'hide_empty' => true,
            'orderby'    => 'count',
            'order'      => 'DESC',
        ] );

        if ( ! empty( $exam_terms ) && ! is_wp_error( $exam_terms ) ) :
            foreach ( $exam_terms as $exam ) : ?>
                <a href="<?php echo esc_url( get_term_link( $exam ) ); ?>" class="nm-topic-tab">
                   <span class="nm-topic-tab-name">
    <?php echo esc_html( str_replace( '_', ' ', $exam->name ) ); ?>
</span>
                    <span class="nm-topic-tab-count"><?php echo (int) $exam->count; ?> MCQs</span>
                </a>
            <?php endforeach;
        endif;
    } else {
        // Default: list parent Topics
        $parent_topics = get_terms( [
            'taxonomy'   => 'topic',
            'hide_empty' => true,
            'parent'     => 0,
            'orderby'    => 'count',
            'order'      => 'DESC',
        ] );

        if ( ! empty( $parent_topics ) && ! is_wp_error( $parent_topics ) ) :
            foreach ( $parent_topics as $topic ) : ?>
                <a href="<?php echo esc_url( get_term_link( $topic ) ); ?>" class="nm-topic-tab">
                    <span class="nm-topic-tab-name"><?php echo esc_html( $topic->name ); ?></span>
                    <span class="nm-topic-tab-count"><?php echo (int) $topic->count; ?> MCQs</span>
                </a>
            <?php endforeach;
        endif;
    }
    ?>
</div>
        </div>

        <?php
        $paged = get_query_var('paged') ? (int) get_query_var('paged') : 1;

$args = [
    'post_type'      => 'mcq',
    'posts_per_page' => 15,
    'paged'          => $paged,
    'orderby'        => 'date',
    'order'          => 'DESC',
];

// On /exam/: only show MCQs that are tagged with at least one Exam term (nm_exam)
if ( $is_exam_root ) {
    $exam_term_ids = get_terms( [
        'taxonomy'   => 'nm_exam',
        'hide_empty' => false,
        'fields'     => 'ids',
    ] );

    if ( ! is_wp_error( $exam_term_ids ) && ! empty( $exam_term_ids ) ) {
        $args['tax_query'] = [
            [
                'taxonomy' => 'nm_exam',
                'field'    => 'term_id',
                'terms'    => $exam_term_ids,
                'include_children' => false,
            ],
        ];
    }
}

$mcq_query = new WP_Query( $args );

        if ($mcq_query->have_posts()) :
        ?>
            <div class="nm-questions-section">
                <div class="nm-section-header">
                    <h2 class="nm-section-title">Latest Questions</h2>
                    <span class="nm-question-count"><?php echo (int) $mcq_query->found_posts; ?> Total</span>
                </div>

                <div class="nm-questions-list">
                    <?php while ($mcq_query->have_posts()) : $mcq_query->the_post();
                        $post_id = get_the_ID();
                        $difficulty = get_post_meta($post_id, 'mcq_difficulty', true);

// Decide which taxonomy to use for the badge
if ( $is_exam_root ) {
    // On /exam/: prefer the Exam tag
    $badge_terms = wp_get_post_terms( $post_id, 'nm_exam', [ 'number' => 1 ] );

    // Fallback to Topic if no exam tag found
    if ( empty( $badge_terms ) || is_wp_error( $badge_terms ) ) {
        $badge_terms = wp_get_post_terms( $post_id, 'topic', [ 'number' => 1 ] );
    }
} else {
    // Default archive: show Topic
    $badge_terms = wp_get_post_terms( $post_id, 'topic', [ 'number' => 1 ] );
}
?>
<article class="nm-question-card-clean">
    <div class="nm-card-top">
        <?php if ( ! empty( $badge_terms ) && ! is_wp_error( $badge_terms ) ) : ?>
            <span class="nm-card-topic-badge">
                <?php echo esc_html( str_replace( '_', ' ', $badge_terms[0]->name ) ); ?>
            </span>
        <?php endif; ?>
                                <span class="nm-card-date"><?php echo esc_html(get_the_date('M j, Y')); ?></span>
                            </div>

                            <h3 class="nm-card-question-title">
                                <a href="<?php the_permalink(); ?>" class="nm-card-question-link">
                                    <?php the_title(); ?>
                                </a>
                            </h3>

                            <div class="nm-card-meta-row">
                                <?php if ($difficulty) : ?>
                                    <span class="nm-difficulty-tag difficulty-<?php echo esc_attr(strtolower($difficulty)); ?>">
                                        <?php echo esc_html($difficulty); ?>
                                    </span>
                                <?php else : ?>
                                    <span></span>
                                <?php endif; ?>

                                <a href="<?php the_permalink(); ?>" class="nm-answer-btn">
                                    Answer Now
                                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                                        <path d="M5 11L9 7L5 3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </a>
                            </div>
                        </article>
                    <?php endwhile; ?>
                </div>

                <?php if ($mcq_query->max_num_pages > 1) : ?>
                    <div class="nm-pagination-wrapper">
                        <?php
                        // paginate_links() escapes HTML internally.
                        echo paginate_links([
                            'total' => $mcq_query->max_num_pages,
                            'current' => $paged,
                            'prev_text' => '←',
                            'next_text' => '→',
                            'type' => 'list',
                            'mid_size' => 2,
                            'end_size' => 1
                        ]);
                        ?>
                    </div>
                <?php endif; ?>
            </div>

        <?php else : ?>

            <div class="nm-no-results">
                <div class="nm-no-results-icon">😕</div>
                <h2>No Questions Found</h2>
                <p>Check back soon for new MCQs!</p>
            </div>

        <?php endif; ?>

        <?php wp_reset_postdata(); ?>

    </div>

    <?php if ($is_astra): ?>
        <?php astra_primary_content_bottom(); ?>
    </div><?php if (astra_page_layout() == 'right-sidebar'): ?>
        <?php get_sidebar(); ?>
    <?php endif; ?>
<?php endif; ?>

<?php get_footer(); ?>