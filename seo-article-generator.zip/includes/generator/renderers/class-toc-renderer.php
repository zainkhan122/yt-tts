<?php
/**
 * TOC (TABLE OF CONTENTS) RENDERER
 *
 * @MODIFIED 2026-06-14 — Gutenberg block recovery fix (class-toc-renderer.php):
 *
 * WHY: Gutenberg's JS block parser encodes block comment attributes using
 * WordPress core's serialize_block_attributes() pattern (e.g., & becomes
 * \u0026, < becomes \u003c). The previous manual block comment construction
 * used JSON_HEX_* flags which produce subtly different encoding (e.g.,
 * JSON_HEX_APOS encodes apostrophes which core never does). This caused
 * the stored block attrs to not round-trip correctly through parse → save.
 *
 * WHAT CHANGED:
 * 1. Replaced manual <!-- wp:rank-math/toc-block {...} --> string concatenation
 *    with a block array passed to serialize_blocks(). This lets WordPress core
 *    handle all JSON encoding of block comment attributes, ensuring the stored
 *    attrs exactly match what Gutenberg's parser expects.
 * 2. Added html_entity_decode() after wp_strip_all_tags() on heading text to
 *    prevent double-encoding of & → &amp;amp; in the TOC content attribute.
 *
 * FILES: class-toc-renderer.php (this file)
 */

namespace SEO_Article_Generator\Generator\Renderers;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Handles generating Rank Math TOC blocks via post-rendering extraction.
 */
class TOC_Renderer
{
    /**
     * Parses final HTML for H2 tags and generates a Rank Math TOC block.
     *
     * @param string $article_html The fully rendered article HTML.
     * @return string The Rank Math TOC block HTML.
     */
    public function generate_from_html(string $article_html): string
    {
        // Extract all H2 tags that have an ID attribute
        if (!preg_match_all('/<h2[^>]*id="([^"]+)"[^>]*>(.*?)<\/h2>/is', $article_html, $matches, PREG_SET_ORDER)) {
            return ''; // No headings found, no TOC.
        }

        $headings_json = array();

        foreach ($matches as $match) {
            $anchor_id = $match[1];
            $text      = \html_entity_decode(\wp_strip_all_tags(trim($match[2])), ENT_QUOTES, 'UTF-8');

            if (empty($anchor_id) || empty($text)) {
                continue;
            }

            // Normalize anchor link to fragment-only to avoid absolute path issues
            $href = self::normalize_toc_href($anchor_id);

            // Rank Math expects a unique key for each item
            $key = \wp_generate_uuid4();

            $headings_json[] = array(
                'key'             => $key,
                'content'         => $text,
                'level'           => 2,
                'link'            => $href,
                'disable'         => false,
                'isUpdated'       => false,
                'isGeneratedLink' => true,
            );
        }

        if (empty($headings_json)) {
            return '';
        }

        // Build innerHTML matching Rank Math's JS save() output exactly.
        // save() renders: <div useBlockProps id="rank-math-toc"><nav><ul><List /></ul></nav></div>
        // List component renders: <li className=""><a href={link}>{content}</a></li>
        $list_html = '';
        foreach ($headings_json as $h) {
            $list_html .= '<li class=""><a href="' . \esc_url($h['link']) . '">' . \esc_html($h['content']) . '</a></li>';
        }

        $inner_html = '<div class="wp-block-rank-math-toc-block" id="rank-math-toc"><nav><ul>' . $list_html . '</ul></nav></div>';

        // Build block struct and let serialize_blocks() handle the JSON encoding
        // of the block comment — this matches WordPress core's serialize_block_attributes().
        $block = array(
            array(
                'blockName'    => 'rank-math/toc-block',
                'attrs'        => array(
                    'headings'  => $headings_json,
                    'listStyle' => 'ul',
                ),
                'innerBlocks'  => array(),
                'innerHTML'    => $inner_html,
                'innerContent' => array($inner_html),
            ),
        );

        return \serialize_blocks($block);
    }

    /**
     * Force anchor links to relative fragment format to prevent navigation breakage.
     */
    private static function normalize_toc_href(string $href): string {
        $href = trim($href);
        if ($href === '') {
            return '#';
        }

        // If it's already a fragment, sanitize and return
        if ($href[0] === '#') {
            return '#' . \sanitize_title(substr($href, 1));
        }

        // If it's a full URL with fragment, extract fragment
        $parts = \wp_parse_url($href);
        if (! empty($parts['fragment'])) {
            return '#' . \sanitize_title($parts['fragment']);
        }

        // Otherwise assume the whole thing is intended as an anchor ID
        return '#' . \sanitize_title($href);
    }
}
