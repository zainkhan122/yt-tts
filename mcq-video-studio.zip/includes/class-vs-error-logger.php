<?php

/**
 * Central Error Logger
 *
 * Handles server-side errors AND remote client-side logs.
 * Now acts as the "Single Source of Truth" for the entire plugin.
 *
 * Storage: wp_vs_logs table (persistent, configurable retention 1-30 days).
 * Previously used WP transient with 1 hour expiry; that path is retired.
 *
 * @package MCQ_Video_Studio
 * @since 1.2.0
 * @modified 2026-07-06: Migrated from transient to wp_vs_logs DB table.
 */

if (!defined('ABSPATH')) {
    exit;
}

class VS_Error_Logger
{
    private static $instance = null;

    /** @var string Table name (set once per request) */
    private $table = '';

    /** @var int|null Cached retention days (lazy) */
    private static $retention_cache = null;

    public static function get_instance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /** Resolve table name once per request. */
    private function init_table()
    {
        if ($this->table !== '') return;
        global $wpdb;
        $this->table = $wpdb->prefix . 'vs_logs';
    }

    /** Check that wp_vs_logs exists (useful in Settings tab before DB is migrated). */
    public function table_exists()
    {
        $this->init_table();
        global $wpdb;
        $name = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $this->table));
        return $name === $this->table;
    }

    /** Number of retention days (from Settings → Logs tab). */
    public function retention_days()
    {
        if (self::$retention_cache !== null) return self::$retention_cache;
        self::$retention_cache = (int) get_option('mcqvs_log_retention_days', 7);
        if (self::$retention_cache < 1)  self::$retention_cache = 1;
        if (self::$retention_cache > 30) self::$retention_cache = 30;
        return self::$retention_cache;
    }

    /** Absolute row cap (from Settings → Logs tab). */
    public function max_total()
    {
        $v = (int) get_option('mcqvs_log_max_total', 5000);
        if ($v < 500)  $v = 500;
        if ($v > 50000) $v = 50000;
        return $v;
    }

    // ------------------------------------------------------------------
    //  HOOKS
    // ------------------------------------------------------------------

    /**
     * Initialize hooks for remote logging + daily prune.
     * Must be called from Core init.
     */
    public function init()
    {
        add_action('wp_ajax_mcqvs_remote_log', array($this, 'handle_remote_log'));
        add_action('wp_ajax_nopriv_mcqvs_remote_log', array($this, 'handle_remote_log'));

        // Prune old rows daily (table + daily counter options)
        add_action('mcqvs_daily_telemetry_prune', array($this, 'prune_daily_telemetry'));
        if (! wp_next_scheduled('mcqvs_daily_telemetry_prune')) {
            wp_schedule_event(time() + 3600, 'daily', 'mcqvs_daily_telemetry_prune');
        }
    }

    // ------------------------------------------------------------------
    //  PRUNE
    // ------------------------------------------------------------------

    /**
     * Drop daily-counter options older than 90 days + prune wp_vs_logs rows
     * older than the configured retention window.
     */
    public function prune_daily_telemetry()
    {
        global $wpdb;
        $this->init_table();

        // 1. Prune daily counter options (> 90 days old)
        $cutoff = gmdate('Y-m-d', time() - 90 * DAY_IN_SECONDS);
        $like1 = $wpdb->esc_like('mcqvs_api_count_') . '%';
        $like2 = $wpdb->esc_like('mcqvs_videos_created_') . '%';
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$wpdb->options} WHERE (option_name LIKE %s OR option_name LIKE %s) AND option_name < %s",
            $like1, $like2, 'mcqvs_api_count_' . $cutoff
        ));

        // 2. Prune wp_vs_logs rows older than retention window
        if ($this->table_exists()) {
            $days = $this->retention_days();
            $cutoff_ts = gmdate('Y-m-d H:i:s', time() - ($days * DAY_IN_SECONDS));
            $wpdb->query($wpdb->prepare(
                "DELETE FROM {$this->table} WHERE ts < %s",
                $cutoff_ts
            ));
        }

        // 3. Enforce absolute cap (delete oldest if over max_total)
        $this->enforce_cap();
    }

    /**
     * Trim wp_vs_logs to max_total rows (delete oldest first).
     */
    public function enforce_cap()
    {
        global $wpdb;
        $this->init_table();
        if (!$this->table_exists()) return;

        $max = $this->max_total();
        $current = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$this->table}");
        if ($current <= $max) return;

        $to_delete = $current - $max;
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$this->table} ORDER BY ts ASC LIMIT %d",
            $to_delete
        ));
    }

    // ------------------------------------------------------------------
    //  AJAX: Remote Log (JS → WP)
    // ------------------------------------------------------------------

    public function handle_remote_log()
    {
        $skip_auth = false;
        $log_source = 'CLIENT_SIDE';

        // Validate render log token (alternative auth for unauthenticated render service)
        if (isset($_POST['log_token'])) {
            $log_token = sanitize_text_field($_POST['log_token']);
            // Extract job_id from context to look up the expected token
            $raw_context = isset($_POST['context']) ? stripslashes($_POST['context']) : '';
            $decoded     = $raw_context ? json_decode($raw_context, true) : null;
            $job_id      = is_array($decoded) && isset($decoded['job_id']) ? sanitize_text_field($decoded['job_id']) : '';

            if (!empty($job_id) && !empty($log_token)) {
                $expected = get_transient('mcqvs_render_log_token_' . $job_id);
                if ($expected && hash_equals($expected, $log_token)) {
                    $skip_auth = true;
                    $log_source = 'RENDER_SERVICE';
                }
            }
        }

        if (!$skip_auth) {
            check_ajax_referer('mcqvs_studio_nonce', 'nonce');
            if (!current_user_can('edit_posts')) {
                wp_send_json_error('Forbidden');
            }
        }

        $level   = isset($_POST['level'])   ? sanitize_text_field($_POST['level'])   : 'info';
        $message = isset($_POST['message']) ? sanitize_text_field($_POST['message']) : 'Remote Log';

        $context = array();
        if (isset($_POST['context'])) {
            $raw_context = stripslashes($_POST['context']);
            $decoded     = json_decode($raw_context, true);
            $context     = is_array($decoded) ? $decoded : array('raw' => $raw_context);
        }

        $context['source'] = $log_source;

        $this->log($message, $level, $context);
        wp_send_json_success();
    }

    // ------------------------------------------------------------------
    //  PUBLIC: log() + log_api() + log_pipeline()
    // ------------------------------------------------------------------

    /**
     * Log a general error or message.
     *
     * @param string $message Main message
     * @param string $level   'error', 'warning', 'info'
     * @param array  $context Additional data (serialized to JSON column)
     */
    public function log($message, $level = 'error', $context = array())
    {
        $this->save_log_row($message, $level, $context);
    }

    /**
     * Log a structured pipeline audit event with correlation IDs.
     *
     * Every pipeline stage (topic generation → job creation → rendering →
     * upload → Buffer) emits one of these so the full lifecycle of any
     * entity is traceable in a single log-filter search.
     *
     * @param string $stage    Pipeline stage name (e.g. 'job.created', 'job.transition', 'upload.started', 'buffer.pushed')
     * @param string $status   'started' | 'completed' | 'failed'
     * @param string $entity_id  The primary entity (job_id, topic_id, batch_id)
     * @param string $message   Human-readable description
     * @param string $level    'error' | 'warning' | 'info'
     * @param array  $extra    Additional context (merged into the log row)
     */
    public function log_pipeline($stage, $status, $entity_id, $message, $level = 'info', $extra = array())
    {
        $context = array_merge(array(
            'pipeline_stage' => $stage,
            'pipeline_status' => $status,
            'entity_id' => $entity_id,
        ), $extra);
        $this->save_log_row($message, $level, $context, 'pipeline');
    }

    /**
     * Log detailed API calls (Request + Response).
     *
     * @param string $url           API URL
     * @param string $method        GET/POST
     * @param mixed  $request_body  sent data
     * @param mixed  $response_raw  received data (WP_Error or array)
     * @param float  $duration      seconds
     */
    public function log_api($url, $method, $request_body, $response_raw, $duration = 0, $source = '')
    {
        $status        = 'unknown';
        $response_body = '';
        $success_flag  = null;
        $is_shell      = false;

        if (is_wp_error($response_raw)) {
            $status        = 'error';
            $response_body = $response_raw->get_error_message();
        } elseif (is_array($response_raw) && array_key_exists('success', $response_raw)) {
            $is_shell      = true;
            $success_flag  = (bool) $response_raw['success'];
            $exit_code     = isset($response_raw['exit_code'])
                ? (int) $response_raw['exit_code']
                : (isset($response_raw['code']) ? (int) $response_raw['code'] : ($success_flag ? 0 : 1));
            $status        = $exit_code;
            $response_body = $response_raw['stdout']
                ?? $response_raw['body']
                ?? $response_raw['stderr']
                ?? '';
        } elseif (is_string($response_raw)) {
            $status        = 'shell';
            $response_body = $response_raw;
        } else {
            $status        = wp_remote_retrieve_response_code($response_raw);
            $response_body = wp_remote_retrieve_body($response_raw);
        }

        $decoded = json_decode((string) $response_body, true);
        if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
            $response_body = $decoded;
            if ($is_shell && $success_flag === null && array_key_exists('success', $decoded)) {
                $success_flag = (bool) $decoded['success'];
            }
        }

        $is_error = false;
        if (is_wp_error($response_raw)) {
            $is_error = true;
        } elseif (is_int($status) && $status >= 400) {
            $is_error = true;
        } elseif ($is_shell && $success_flag === false) {
            $is_error = true;
        } elseif ($is_shell && is_int($status) && $status !== 0) {
            $is_error = true;
        }

        $level = $is_error ? 'error' : 'info';
        $msg   = "API Call: $method $url (" . (is_int($status) ? (string) $status : (string) $status) . ")";
        $ctx   = array(
            'url'      => $url,
            'method'   => $method,
            'duration' => round($duration, 4) . 's',
            'request'  => $request_body,
            'response' => $response_body,
        );

        $this->save_log_row($msg, $level, $ctx, 'api');

        // Per-source daily counter (AI providers incl. customs + Buffer)
        $source = is_string($source) ? trim($source) : '';
        if ($source === '') {
            if (strpos($url, 'api.buffer.com') !== false) {
                $source = 'buffer';
            } elseif (class_exists('VS_Provider_Registry')) {
                $source = VS_Provider_Registry::get_instance()->identify_provider_from_url($url);
            }
            if ($source === '') {
                $source = 'other';
            }
        }
        $source_key = 'mcqvs_api_count_' . $source . '_' . current_time('Y-m-d');
        update_option($source_key, (int) get_option($source_key, 0) + 1, false);

        // Legacy aggregate counter kept for backward compat (also used as total fallback)
        $date_key = 'mcqvs_api_count_' . current_time('Y-m-d');
        update_option($date_key, (int) get_option($date_key, 0) + 1, false);
    }

    // ------------------------------------------------------------------
    //  PRIVATE: write to wp_vs_logs
    // ------------------------------------------------------------------

    /**
     * Insert one row into wp_vs_logs and enforce the cap.
     *
     * @param string $message
     * @param string $level
     * @param array  $context
     * @param string $type      'general' | 'api' — stored in context as 'type' key
     */
    private function save_log_row($message, $level = 'error', $context = array(), $type = 'general')
    {
        global $wpdb;
        $this->init_table();

        // Fall back to transient if table does not exist (pre-upgrade installs)
        if (!$this->table_exists()) {
            $this->save_log_fallback($message, $level, $context);
            return;
        }

        $context['_type'] = $type;
        $source = isset($context['source']) ? strtoupper($context['source']) : 'SERVER';

        $user_id    = get_current_user_id();
        $request_uri = isset($_SERVER['REQUEST_URI']) ? substr($_SERVER['REQUEST_URI'], 0, 255) : null;

        $wpdb->insert(
            $this->table,
            array(
                'ts'           => gmdate('Y-m-d H:i:s'),
                'level'        => $level,
                'source'       => $source,
                'message'      => $message,
                'context_json' => wp_json_encode($context, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                'user_id'      => $user_id > 0 ? $user_id : null,
                'request_uri'  => $request_uri,
            ),
            array('%s', '%s', '%s', '%s', '%s', '%d', '%s')
        );

        // Enforce cap (runs per-write is cheap when under cap; avoids a cron gap)
        $this->enforce_cap();
    }

    /**
     * Fallback: write to transient if the vs_logs table has not been created yet
     * (e.g. before first DB migration runs after plugin update).
     */
    private function save_log_fallback($message, $level, $context)
    {
        $log_key  = 'mcqvs_error_logs';
        $retention = 3600;
        $max_logs  = 100;

        $entry = array(
            'timestamp' => gmdate('Y-m-d H:i:s'),
            'type'      => isset($context['_type']) ? $context['_type'] : 'general',
            'level'     => $level,
            'message'   => $message,
            'context'   => $context,
        );

        $logs = get_transient($log_key);
        if (!is_array($logs)) $logs = array();
        array_unshift($logs, $entry);
        if (count($logs) > $max_logs) {
            $logs = array_slice($logs, 0, $max_logs);
        }
        set_transient($log_key, $logs, $retention);
    }

    // ------------------------------------------------------------------
    //  PUBLIC: read methods
    // ------------------------------------------------------------------

    /**
     * Retrieve logs with optional filters (used by AJAX + Log Viewer page).
     *
     * Falls back to the legacy transient when wp_vs_logs table does not exist
     * (pre-upgrade installs that have not yet triggered the DB migration).
     *
     * @param array $args {
     *     @type string $level     'error'|'warning'|'info'|'' (empty = all)
     *     @type string $source    'SERVER'|'CLIENT_SIDE'|'' (empty = all)
     *     @type string $search    free-text LIKE on message
     *     @type string $from      'YYYY-MM-DD HH:MM:SS' (optional)
     *     @type string $to        'YYYY-MM-DD HH:MM:SS' (optional)
     *     @type string $order     'DESC'|'ASC' (default DESC)
     *     @type int    $limit     max rows (default 100)
     *     @type int    $offset    offset (default 0)
     * }
     * @return array{ rows: array, total: int }
     */
    public function get_logs_filtered($args = array())
    {
        global $wpdb;
        $this->init_table();

        $defaults = array(
            'level'   => '',
            'source'  => '',
            'search'  => '',
            'from'    => '',
            'to'      => '',
            'order'   => 'DESC',
            'limit'   => 100,
            'offset'  => 0,
        );
        $args = wp_parse_args($args, $defaults);

        // --- TABLE PATH ---
        if ($this->table_exists()) {
            return $this->get_logs_from_table($args);
        }

        // --- TRANSIENT FALLBACK (pre-migration installs) ---
        return $this->get_logs_from_transient($args);
    }

    /**
     * Query wp_vs_logs directly.
     */
    private function get_logs_from_table($args)
    {
        global $wpdb;

        $where  = array();
        $params = array();

        if ($args['level'] !== '') {
            $where[]  = 'level = %s';
            $params[] = $args['level'];
        }
        if ($args['source'] !== '') {
            $where[]  = 'source = %s';
            $params[] = $args['source'];
        }
        if ($args['search'] !== '') {
            $where[]  = 'message LIKE %s';
            $params[] = '%' . $wpdb->esc_like($args['search']) . '%';
        }
        if ($args['from'] !== '') {
            $where[]  = 'ts >= %s';
            $params[] = $args['from'];
        }
        if ($args['to'] !== '') {
            $where[]  = 'ts <= %s';
            $params[] = $args['to'];
        }

        $where_sql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
        $order     = strtoupper($args['order']) === 'ASC' ? 'ASC' : 'DESC';

        // Total (without LIMIT)
        $count_params = $params;
        $total = (int) $wpdb->get_var(
            $wpdb->prepare("SELECT COUNT(*) FROM {$this->table} {$where_sql}", ...$count_params)
        );

        // Rows
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, ts, level, source, message, context_json, user_id, request_uri
                 FROM {$this->table} {$where_sql} ORDER BY ts {$order} LIMIT %d OFFSET %d",
                array_merge($params, array($args['limit'], $args['offset']))
            ),
            ARRAY_A
        );

        if (!is_array($rows)) $rows = array();

        return array('rows' => $rows, 'total' => $total);
    }

    /**
     * Read from the legacy transient and apply filters in-memory.
     * Used as a fallback when wp_vs_logs has not been created yet.
     */
    private function get_logs_from_transient($args)
    {
        $log_key  = 'mcqvs_error_logs';
        $raw_logs = get_transient($log_key);

        if (!is_array($raw_logs)) {
            return array('rows' => array(), 'total' => 0);
        }

        // Normalise legacy transient entries to the DB row format
        $normalised = array();
        foreach ($raw_logs as $i => $entry) {
            $ts     = isset($entry['timestamp']) ? $entry['timestamp'] : '';
            $level  = isset($entry['level'])     ? $entry['level']     : 'info';
            $msg    = isset($entry['message'])   ? $entry['message']   : '';
            $ctx    = isset($entry['context'])   ? $entry['context']   : array();
            $source = isset($ctx['source'])      ? strtoupper($ctx['source']) : 'SERVER';

            $normalised[] = array(
                'id'          => $i + 1, // fake ID
                'ts'          => $ts,
                'level'       => $level,
                'source'      => $source,
                'message'     => $msg,
                'context_json'=> wp_json_encode($ctx, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
                'user_id'     => null,
                'request_uri' => null,
            );
        }

        // In-memory filter
        $filtered = $normalised;

        if ($args['level'] !== '') {
            $filtered = array_filter($filtered, function ($r) use ($args) {
                return $r['level'] === $args['level'];
            });
        }
        if ($args['source'] !== '') {
            $needle = strtoupper($args['source']);
            $filtered = array_filter($filtered, function ($r) use ($needle) {
                return strtoupper($r['source']) === $needle;
            });
        }
        if ($args['search'] !== '') {
            $needle = strtolower($args['search']);
            $filtered = array_filter($filtered, function ($r) use ($needle) {
                return stripos($r['message'], $needle) !== false;
            });
        }
        if ($args['from'] !== '') {
            $filtered = array_filter($filtered, function ($r) use ($args) {
                return $r['ts'] >= $args['from'];
            });
        }
        if ($args['to'] !== '') {
            $filtered = array_filter($filtered, function ($r) use ($args) {
                return $r['ts'] <= $args['to'];
            });
        }

        // Re-index
        $filtered = array_values($filtered);
        $total    = count($filtered);

        // Sort
        $order = strtoupper($args['order']) === 'ASC' ? SORT_ASC : SORT_DESC;
        usort($filtered, function ($a, $b) use ($order) {
            $cmp = strcmp($a['ts'], $b['ts']);
            return $order === SORT_ASC ? $cmp : -$cmp;
        });

        // Slice
        $filtered = array_slice($filtered, $args['offset'], $args['limit']);

        return array('rows' => $filtered, 'total' => $total);
    }

    /**
     * Retrieve a single log row by ID.
     *
     * @param int $id
     * @return array|null  associative array or null
     */
    public function get_log($id)
    {
        global $wpdb;
        $this->init_table();
        if (!$this->table_exists()) return null;

        $row = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->table} WHERE id = %d", $id),
            ARRAY_A
        );

        return $row ?: null;
    }

    /**
     * Delete specific log rows.
     *
     * @param int[] $ids
     * @return int number of deleted rows
     */
    public function delete_logs($ids)
    {
        global $wpdb;
        $this->init_table();
        if (!$this->table_exists() || empty($ids)) return 0;

        $placeholders = implode(',', array_fill(0, count($ids), '%d'));
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$this->table} WHERE id IN ({$placeholders})",
            $ids
        ));
        return $wpdb->rows_affected;
    }

    /**
     * Clear all logs.
     */
    public function clear_logs()
    {
        global $wpdb;
        $this->init_table();

        // Clear DB table
        if ($this->table_exists()) {
            $wpdb->query("TRUNCATE TABLE {$this->table}");
        }

        // Clear legacy transient if present
        delete_transient('mcqvs_error_logs');
    }

    /**
     * Get aggregate stats for the Settings → Logs tab.
     *
     * @return array{ total: int, within_retention: int, errors: int, warnings: int, info: int }
     */
    public function get_stats()
    {
        global $wpdb;
        $this->init_table();

        if (!$this->table_exists()) {
            // Fallback: count from transient
            $raw = get_transient('mcqvs_error_logs');
            if (!is_array($raw)) {
                return array('total' => 0, 'within_retention' => 0, 'errors' => 0, 'warnings' => 0, 'info' => 0);
            }
            $errors = $warnings = $infos = 0;
            foreach ($raw as $e) {
                $lv = isset($e['level']) ? $e['level'] : 'info';
                if ($lv === 'error')   $errors++;
                elseif ($lv === 'warning') $warnings++;
                else $infos++;
            }
            return array(
                'total'            => count($raw),
                'within_retention' => count($raw),
                'errors'           => $errors,
                'warnings'         => $warnings,
                'info'             => $infos,
            );
        }

        $total   = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$this->table}");
        $errors  = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$this->table} WHERE level = %s", 'error'));
        $warns   = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$this->table} WHERE level = %s", 'warning'));
        $infos   = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$this->table} WHERE level = %s", 'info'));

        $days    = $this->retention_days();
        $cutoff  = gmdate('Y-m-d H:i:s', time() - ($days * DAY_IN_SECONDS));
        $within  = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$this->table} WHERE ts >= %s", $cutoff));

        return array(
            'total'            => $total,
            'within_retention' => $within,
            'errors'           => $errors,
            'warnings'         => $warns,
            'info'             => $infos,
        );
    }

    /**
     * Get recent error logs for dashboard card (last N errors only).
     *
     * @param int $limit
     * @return array  list of rows with decoded context_json
     */
    public function get_recent_errors($limit = 5)
    {
        $result = $this->get_logs_filtered(array(
            'level' => 'error',
            'limit' => $limit,
            'order' => 'DESC',
        ));

        $rows = array();
        foreach ($result['rows'] as $r) {
            $r['context'] = json_decode($r['context_json'], true);
            unset($r['context_json']);
            $rows[] = $r;
        }
        return $rows;
    }

    /**
     * Backward-compatible get_logs() for legacy callers.
     * Returns the last 100 rows (newest first) with decoded context_json.
     *
     * @return array
     */
    public function get_logs()
    {
        $result = $this->get_logs_filtered(array('limit' => 100, 'order' => 'DESC'));

        $rows = array();
        foreach ($result['rows'] as $r) {
            $r['context']   = json_decode($r['context_json'], true);
            unset($r['context_json']);
            $rows[]         = $r;
        }
        return $rows;
    }

    // ------------------------------------------------------------------
    //  Stats (unchanged)
    // ------------------------------------------------------------------

    public function get_daily_api_usage()
    {
        $by_source = $this->get_daily_api_usage_by_source();
        $total = array_sum($by_source);
        // Fallback to legacy aggregate if no source-tagged calls exist yet
        if ($total === 0) {
            $date_key = 'mcqvs_api_count_' . current_time('Y-m-d');
            $total = (int) get_option($date_key, 0);
        }
        return $total;
    }

    /**
     * Daily API call counts broken down by source.
     *
     * Returns an associative array keyed by source id ('gemini', custom provider
     * ids, 'buffer', 'other') with the integer call count for the current day.
     * Handles pre-migration untagged calls by attributing the difference between
     * the legacy aggregate and the sum of source counters to 'other'.
     *
     * @return array
     */
    public function get_daily_api_usage_by_source()
    {
        global $wpdb;
        $today = current_time('Y-m-d');
        $prefix_len = strlen('mcqvs_api_count_');

        // Fetch all mcqvs_api_count_*_YYYY-MM-DD options (source-tagged)
        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT option_name, option_value FROM {$wpdb->options} WHERE option_name LIKE %s",
                $wpdb->esc_like('mcqvs_api_count_') . '%_' . $today
            ),
            OBJECT_K
        );

        $by_source = array();
        foreach ((array) $results as $row) {
            $name   = $row->option_name;
            $suffix = substr($name, $prefix_len);                           // "<source>_YYYY-MM-DD"
            $source = substr($suffix, 0, - (strlen($today) + 1));          // strip "_YYYY-MM-DD"
            if ($source === '') {
                continue; // skip the old aggregate mcqvs_api_count_YYYY-MM-DD
            }
            $by_source[$source] = (int) ($by_source[$source] ?? 0) + (int) $row->option_value;
        }

        // Account for pre-migration untagged calls: the legacy aggregate may be
        // larger than the sum of source counters if calls were made before source
        // tagging was introduced. Attribute the excess to 'other'.
        $date_key   = 'mcqvs_api_count_' . $today;
        $legacy_tot = (int) get_option($date_key, 0);
        $tagged_sum = array_sum($by_source);
        if ($legacy_tot > $tagged_sum) {
            $by_source['other'] = (int) ($by_source['other'] ?? 0) + ($legacy_tot - $tagged_sum);
        }
        return $by_source;
    }

    public static function increment_video_count()
    {
        $total = (int) get_option('mcqvs_videos_created_total', 0);
        update_option('mcqvs_videos_created_total', $total + 1, false);

        $today_key = 'mcqvs_videos_created_' . current_time('Y-m-d');
        $today     = (int) get_option($today_key, 0);
        update_option($today_key, $today + 1, false);
    }

    public static function get_video_stats()
    {
        $today_key = 'mcqvs_videos_created_' . current_time('Y-m-d');
        return array(
            'total' => (int) get_option('mcqvs_videos_created_total', 0),
            'today' => (int) get_option($today_key, 0),
        );
    }

    /**
     * Videos Created stats derived from the jobs table (status = 'completed').
     *
     * The "Videos Created" KPI must match the "Completed" pipeline card, so it is
     * sourced from the same jobs table count rather than the append-only
     * mcqvs_videos_created_total option, which only the in-browser export path
     * increments and therefore desyncs for server/headless completions.
     *
     * @return array {total:int, today:int}
     */
    public static function get_completed_video_stats()
    {
        if (! class_exists('VS_Job_Repository')) {
            return self::get_video_stats();
        }
        $repo  = VS_Job_Repository::init();
        $stats = $repo->get_stats(); // ['completed_total','completed_today','pending']
        return array(
            'total' => (int) ($stats['completed_total'] ?? 0),
            'today' => (int) ($stats['completed_today'] ?? 0),
        );
    }
}
