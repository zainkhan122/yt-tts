<?php

/**
 * AJAX Handler for Stock Video Search (Pexels)
 *
 * @package MCQ_Video_Studio
 */

if (! defined('ABSPATH')) {
    exit;
}

class VS_AJAX_Stock_Handler
{

    private static $instance = null;

    public static function get_instance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * AJAX: Search Stock Videos (Pexels)
     */
    public function ajax_search_stock_videos()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        $query   = sanitize_text_field($_POST['query'] ?? '');
        // @FIX: Prefer canonical `mcqvs_pexels_api_key`, fall back to parent `nm_pexels_api_key`.
        $api_key = get_option('mcqvs_pexels_api_key', '');
        if (empty($api_key)) {
            $api_key = get_option('nm_pexels_api_key', '');
        }

        if (empty($api_key)) {
            wp_send_json_error(__('Pexels API Key not configured.', 'mcq-video-studio'));
        }

        $url = 'https://api.pexels.com/videos/search?query=' . urlencode($query) . '&per_page=15&orientation=portrait';
        $start_time = microtime(true);
        $response = wp_remote_get($url, array(
            'headers' => array('Authorization' => $api_key),
            'timeout' => 20,
        ));
        $duration = microtime(true) - $start_time;

        // @NEW 2026-01-09: Central API Logging
        VS_Error_Logger::get_instance()->log_api($url, 'GET', array(), $response, $duration);

        if (is_wp_error($response)) {
            VS_Error_Logger::get_instance()->log('Pexels API Error', 'error', array('msg' => $response->get_error_message()));
            wp_send_json_error($response->get_error_message());
        }

        wp_send_json_success(json_decode(wp_remote_retrieve_body($response), true));
    }
}
