<?php
/**
 * OpenRouter Free Model Auto-Sync
 *
 * Pulls the current free text-only model catalog from OpenRouter and reconciles
 * it against the matching custom provider stored in `dit_ts_custom_providers`.
 * Adds new free models after existing ones, removes models that are no longer
 * listed or that are expiring within the sync window, and never wipes a provider
 * when the upstream API call fails or returns an empty list.
 *
 * @package    DIT_TrendStudio
 * @subpackage Services
 * @since      2.28.0
 */

namespace DIT\TrendStudio\Services;

use DIT\TrendStudio\Infrastructure\AI_Provider_Factory;
use DIT\TrendStudio\Infrastructure\Logger;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class OpenRouterModelSync
 *
 * Static facade. State lives in `dit_ts_custom_providers` (sequential array of
 * provider profiles) and `dit_ts_openrouter_last_sync` (unix timestamp).
 */
class OpenRouterModelSync
{
    /** OpenRouter public catalog endpoint. */
    const API_URL = 'https://openrouter.ai/api/v1/models';

    /** Sync runs every 3 days; models expiring within this window are pruned. */
    const SYNC_WINDOW_DAYS = 3;

    /** wp_options key holding the last successful sync timestamp. */
    const OPTION_LAST_SYNC = 'dit_ts_openrouter_last_sync';

    /** wp_options key holding the sequential custom-provider list. */
    const OPTION_PROVIDERS = 'dit_ts_custom_providers';

    /** Action Scheduler hook fired by the recurring 3-day cron. */
    const ACTION_HOOK = 'dit_ts_sync_openrouter_models';

    /** Action Scheduler group for the recurring sync. */
    const AS_GROUP = 'dit_ts_openrouter_sync';

    /** Log message tag used in Logger::info() / warning() calls. */
    const LOG_TAG = 'OpenRouter model sync';

    /**
     * Model ID prefixes that are NOT text-content-creation models.
     * Filtered out before the comparison set is built.
     *
     * @var string[]
     */
    private static $BLOCKED_MODEL_PREFIXES = array(
        'google/lyria',     // Audio/music generation (priced as free for some tiers)
        'google/gemini-tts',// TTS
        'google/imagen',    // Image generation
        'openai/dall-e',    // Image generation
        'openai/sora',      // Video generation
        'tts',              // generic TTS prefix
        'stable-diffusion', // Image generation
        'midjourney',       // Image generation
        'suno/',            // Audio/music generation
        'elevenlabs/',      // Audio generation
        // Embedding-only models — not useful for content generation
        'cohere/embed',     // Cohere embeddings
        'voyage/',          // Voyage embeddings
        'nomic/',           // Nomic embeddings
        'openai/embedding', // OpenAI embeddings
    );

    /**
     * Run the sync.
     *
     * Algorithm (mirrors openrouter-model-sync-universal-plan.md §2b):
     *  1. Locate the OpenRouter custom provider (URL contains "openrouter.ai").
     *  2. Fetch the free text-only model catalog from the API.
     *  3. Abort without modifying state on API failure or empty result.
     *  4. Build removed/expiring/added Sets against the provider's current models.
     *  5. Rebuild the model list preserving original order, appending new ones.
     *  6. Abort if the rebuild would empty the provider.
     *  7. Save raw sequential array (NOT the indexed cache) to preserve order.
     *  8. Update last-sync timestamp and log the operation.
     *
     * @return array {
     *     @type bool   $success
     *     @type string $message
     *     @type int    $added
     *     @type int    $removed
     *     @type int    $expiring
     * }
     */
    public static function sync(): array
    {
        $logger = new Logger();

        // 1. Pull the raw sequential list (never the indexed cache — it is order-lossy on save).
        $providers = self::get_raw_providers();
        if (!is_array($providers) || empty($providers)) {
            $logger->warning(self::LOG_TAG . ': no custom providers configured.');
            return array(
                'success'  => false,
                'message'  => __('No custom providers configured.', 'dit-trend-content-studio'),
                'added'    => 0,
                'removed'  => 0,
                'expiring' => 0,
            );
        }

        $or_index = null;
        $or_profile = null;
        foreach ($providers as $i => $profile) {
            $url = (string) ($profile['api_url'] ?? '');
            if (stripos($url, 'openrouter.ai') !== false) {
                $or_index = $i;
                $or_profile = $profile;
                break;
            }
        }

        if ($or_index === null) {
            $logger->info(self::LOG_TAG . ': no OpenRouter custom provider found, skipping.');
            return array(
                'success'  => false,
                'message'  => __('No OpenRouter custom provider found.', 'dit-trend-content-studio'),
                'added'    => 0,
                'removed'  => 0,
                'expiring' => 0,
            );
            }

        // 3. Fetch + filter. Never mutate state when the API misbehaves.
        $api_models = self::fetch_free_models();
        if ($api_models === null) {
            return array(
                'success'  => false,
                'message'  => __('OpenRouter API request failed. Existing models left unchanged.', 'dit-trend-content-studio'),
                'added'    => 0,
                'removed'  => 0,
                'expiring' => 0,
            );
        }
        if (empty($api_models)) {
            return array(
                'success'  => false,
                'message'  => __('OpenRouter returned no free models. Existing models left unchanged.', 'dit-trend-content-studio'),
                'added'    => 0,
                'removed'  => 0,
                'expiring' => 0,
            );
        }

        // 4. Build comparison Sets keyed by model_id (OpenRouter IDs are unique strings).
        $current_models = isset($or_profile['models']) && is_array($or_profile['models']) ? $or_profile['models'] : array();
        $current_ids   = array();
        foreach ($current_models as $m) {
            $mid = (string) ($m['model_id'] ?? '');
            if ($mid !== '') {
                $current_ids[$mid] = true;
            }
        }

        $api_ids = array();
        $api_meta = array(); // model_id => [expiration_date => string|null]
        foreach ($api_models as $am) {
            $mid = (string) ($am['id'] ?? '');
            if ($mid === '') {
                continue;
            }
            $api_ids[$mid] = true;
            $api_meta[$mid] = array(
                'expiration_date'   => (string) ($am['expiration_date'] ?? ''),
                'context_length'    => isset($am['context_length']) ? (int) $am['context_length'] : 0,
                'display_name'      => (string) ($am['name'] ?? $mid),
            );
        }

        // 5. Removal detection — iterate current models in their stored order.
        $removed_ids  = array();
        $expiring_ids = array();
        $cutoff       = time() + (self::SYNC_WINDOW_DAYS * DAY_IN_SECONDS);
        foreach ($current_models as $m) {
            $mid = (string) ($m['model_id'] ?? '');
            if ($mid === '') {
                continue;
            }
            if (!isset($api_ids[$mid])) {
                // Model no longer exists in the API catalog.
                $removed_ids[$mid] = true;
                continue;
            }
            // Model exists — check whether it's expiring soon.
            if (isset($api_meta[$mid]['expiration_date']) && $api_meta[$mid]['expiration_date'] !== '') {
                $ts = strtotime($api_meta[$mid]['expiration_date']);
                if ($ts && $ts < $cutoff) {
                    $removed_ids[$mid]  = true;
                    $expiring_ids[$mid] = true;
                }
            }
        }

        // 6. Addition detection — iterate API result. New ones go AFTER existing.
        $added_ids = array();
        foreach ($api_models as $am) {
            $mid = (string) ($am['id'] ?? '');
            if ($mid === '' || isset($current_ids[$mid]) || isset($removed_ids[$mid])) {
                continue;
            }
            $added_ids[$mid] = true;
        }

        // 7. No-op short-circuit.
        if (empty($removed_ids) && empty($added_ids)) {
            update_option(self::OPTION_LAST_SYNC, time(), false);
            $logger->info(self::LOG_TAG . ': no changes.');
            return array(
                'success'  => true,
                'message'  => __('No changes — models are already in sync.', 'dit-trend-content-studio'),
                'added'    => 0,
                'removed'  => 0,
                'expiring' => 0,
            );
        }

        // 8. Rebuild, preserving original order, appending new models at the end.
        $new_models = array();
        foreach ($current_models as $m) {
            $mid = (string) ($m['model_id'] ?? '');
            if ($mid === '' || isset($removed_ids[$mid])) {
                continue;
            }
            $new_models[] = array(
                'display_name' => (string) ($m['display_name'] ?? $mid),
                'model_id'     => $mid,
            );
        }

        foreach (array_keys($added_ids) as $mid) {
            $meta = isset($api_meta[$mid]) ? $api_meta[$mid] : array();
            $name = (string) ($meta['display_name'] ?? $mid);
            $new_models[] = array(
                'display_name' => $name,
                'model_id'     => $mid,
            );
        }

        // 9. Refuse to leave the provider empty.
        if (empty($new_models)) {
            $logger->warning(self::LOG_TAG . ': sync would empty the provider, aborting.', array(
                'provider_id'   => (string) ($or_profile['id'] ?? ''),
                'removed_count' => count($removed_ids),
            ));
            return array(
                'success'  => false,
                'message'  => __('Sync would remove every model — aborted to protect the provider.', 'dit-trend-content-studio'),
                'added'    => 0,
                'removed'  => 0,
                'expiring' => 0,
            );
        }

        // 10. Save. We MUST operate on the raw sequential array (not the indexed cache)
        //     to preserve provider order across the save.
        $or_profile['models'] = $new_models;
        $providers[$or_index]  = $or_profile;

        // Validate every profile shape before persisting — prevents corrupted siblings
        // from being written when an earlier process mutated the option badly.
        $clean = array();
        foreach ($providers as $profile) {
            $pid = isset($profile['id']) ? sanitize_key((string) $profile['id']) : '';
            if ($pid === '') {
                continue;
            }
            $models_clean = array();
            if (isset($profile['models']) && is_array($profile['models'])) {
                foreach ($profile['models'] as $m) {
                    $mid = (string) ($m['model_id'] ?? '');
                    $mname = (string) ($m['display_name'] ?? $mid);
                    if ($mid !== '') {
                        $models_clean[] = array(
                            'display_name' => sanitize_text_field($mname),
                            'model_id'     => sanitize_text_field($mid),
                        );
                    }
                }
            }
            $profile['models'] = $models_clean;
            $clean[] = $profile;
        }

        update_option(self::OPTION_PROVIDERS, $clean);
        AI_Provider_Factory::clear_custom_providers_cache();
        update_option(self::OPTION_LAST_SYNC, time(), false);

        $summary = array(
            'success'  => true,
            'message'  => sprintf(
                /* translators: 1: added count, 2: removed count, 3: expiring count */
                __('Synced %1$d added, %2$d removed (%3$d expiring).', 'dit-trend-content-studio'),
                count($added_ids),
                count($removed_ids),
                count($expiring_ids)
            ),
            'added'    => count($added_ids),
            'removed'  => count($removed_ids),
            'expiring' => count($expiring_ids),
        );

        $logger->info(self::LOG_TAG . ': complete.', array(
            'provider_id'   => (string) ($or_profile['id'] ?? ''),
            'added'         => $summary['added'],
            'removed'       => $summary['removed'],
            'expiring'      => $summary['expiring'],
        ));

        return $summary;
    }

    /**
     * Fetch the OpenRouter catalog and return only free, text-only models.
     *
     * Returns null on ANY error so that `sync()` can abort without mutating state.
     *
     * @return array|null Filtered array of model rows (id, name, expiration_date, context_length),
     *                    or null if the request failed or the response could not be parsed.
     */
    private static function fetch_free_models(): ?array
    {
        $url = add_query_arg(
            array(
                'output_modalities' => 'text',
                'input_modalities'  => 'text',
                'max_price'         => '0',
            ),
            self::API_URL
        );

        $response = wp_remote_get($url, array(
            'timeout'    => 30,
            'user-agent' => 'DIT-TrendStudio/' . DIT_TS_VERSION . ' (WordPress ' . get_bloginfo('version') . ')',
        ));

        if (is_wp_error($response)) {
            (new Logger())->warning(self::LOG_TAG . ': wp_remote_get failed.', array(
                'error' => $response->get_error_message(),
            ));
            return null;
        }

        $code = (int) wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            (new Logger())->warning(self::LOG_TAG . ': non-200 response.', array(
                'http_code' => $code,
            ));
            return null;
        }

        $body = wp_remote_retrieve_body($response);
        $json = json_decode($body, true);
        if (!is_array($json) || !isset($json['data']) || !is_array($json['data'])) {
            (new Logger())->warning(self::LOG_TAG . ': malformed response, no data array.');
            return null;
        }

        $filtered = array();
        foreach ($json['data'] as $row) {
            if (!is_array($row) || empty($row['id'])) {
                continue;
            }

            // (a) Pricing filter — both prompt and completion must be zero (free).
            $prompt_price     = (string) ($row['pricing']['prompt'] ?? '');
            $completion_price = (string) ($row['pricing']['completion'] ?? '');
            if ($prompt_price !== '0' && $prompt_price !== '0.0' && $prompt_price !== '0.0000') {
                continue;
            }
            if ($completion_price !== '0' && $completion_price !== '0.0' && $completion_price !== '0.0000') {
                continue;
            }

            // (b) Output modality filter — must include text and must not include audio/image/video/embeddings.
            $arch = isset($row['architecture']) && is_array($row['architecture']) ? $row['architecture'] : array();
            $out_modalities = isset($arch['output_modalities']) && is_array($arch['output_modalities']) ? $arch['output_modalities'] : null;

            if ($out_modalities !== null) {
                $has_text = false;
                foreach ($out_modalities as $mod) {
                    $m = strtolower((string) $mod);
                    if (in_array($m, array('image', 'audio', 'video', 'embeddings', 'embedding'), true)) {
                        // Non-text output → not a content-creation model.
                        continue 2;
                    }
                    if ($m === 'text') {
                        $has_text = true;
                    }
                }
                if (!$has_text) {
                    continue;
                }
            }
            // Note: input_modalities are deliberately NOT filtered.
            // Models that accept image/video/audio on the input side but produce
            // text-only output (e.g. Gemma 4, Nemotron VL) are valid content-creation
            // tools for this plugin, which only consumes the text output.

            // (c) Modality string filter (older API shape):
            //     architecture.modality = "text->text", "text+image->text+image", etc.
            $modality_str = isset($arch['modality']) ? strtolower((string) $arch['modality']) : '';
            if ($modality_str !== '' && strpos($modality_str, 'text') === false) {
                continue;
            }

            // (d) Blocked-prefix filter — image/audio/video generation models.
            $id_lower = strtolower((string) $row['id']);
            $blocked = false;
            foreach (self::$BLOCKED_MODEL_PREFIXES as $prefix) {
                if (strpos($id_lower, $prefix) !== false) {
                    $blocked = true;
                    break;
                }
            }
            if ($blocked) {
                continue;
            }

            $filtered[] = array(
                'id'              => (string) $row['id'],
                'name'            => (string) ($row['name'] ?? $row['id']),
                'expiration_date' => isset($row['expiration_date']) ? (string) $row['expiration_date'] : '',
                'context_length'  => isset($row['context_length']) ? (int) $row['context_length'] : 0,
            );
        }

        return $filtered;
    }

    /**
     * Read the raw sequential providers array directly from the option.
     * Avoids the AI_Provider_Factory composite cache, which re-indexes by `id`
     * and would destroy order-saving semantics on save.
     *
     * @return array
     */
    private static function get_raw_providers(): array
    {
        $raw = get_option(self::OPTION_PROVIDERS, array());
        if (is_string($raw)) {
            $decoded = json_decode($raw, true);
            $raw = is_array($decoded) ? $decoded : array();
        }
        return is_array($raw) ? $raw : array();
    }

    /**
     * Unix timestamp of the last successful sync (0 when never run).
     *
     * @return int
     */
    public static function get_last_sync_time(): int
    {
        return (int) get_option(self::OPTION_LAST_SYNC, 0);
    }

    /**
     * Whether at least one configured custom provider points at OpenRouter.
     * Used by the scheduler to skip the recurring action when there's nothing to sync.
     *
     * @return bool
     */
    public static function has_openrouter_provider(): bool
    {
        return count(self::find_openrouter_profiles()) > 0;
    }

    /**
     * Locate every custom provider whose api_url contains "openrouter.ai".
     *
     * @return array Sequential list of profiles (each an array), order preserved.
     */
    private static function find_openrouter_profiles(): array
    {
        $matches = array();
        foreach (self::get_raw_providers() as $profile) {
            $url = (string) ($profile['api_url'] ?? '');
            if (stripos($url, 'openrouter.ai') !== false) {
                $matches[] = $profile;
            }
        }
        return $matches;
    }
}
