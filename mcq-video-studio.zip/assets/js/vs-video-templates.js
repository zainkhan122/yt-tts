/**
 * NM Video Templates
 * Professional template system for Quiz Shorts Studio
 *
 * 17 distinct visual templates with color palettes, fonts, and effects
 *
 * @package WP_News_MCQ_Generator
 * @version 1.0.0
 */

(function (window) {
  "use strict";

  const MCQVS_VideoTemplates = {
    // ==========================================
    // TEMPLATE DEFINITIONS
    // ==========================================
    templates: {
      // === PROFESSIONAL ===

      corporate: {
        name: "Corporate",
        category: "professional",
        description: "Clean, professional look for business content",
        colors: {
          primary: "#2C3E50",
          secondary: "#3498DB",
          accent: "#E74C3C",
          text: "#FFFFFF",
          textSecondary: "#BDC3C7",
          correct: "#27AE60",
          wrong: "#E74C3C",
        },
        background: {
          type: "gradient",
          colors: ["#1a1a2e", "#16213e", "#0f3460"],
          animated: true,
        },
        fonts: {
          primary: "Inter",
          secondary: "Roboto",
          weights: { normal: "500", bold: "700", heavy: "900" },
        },
        effects: {
          transition: "fadeZoom",
          particles: "sparks",
          textEffect: "classicBold",
        },
        // @NEW 2026-02-23: Professional Canvas Styling
        canvas: {
          card: { style: "glass", opacity: 0.85, blur: 25, borderRadius: 40, borderWeight: 2 },
          options: { style: "glass", borderRadius: 25, activeOpacity: 0.4 }
        },
      },

      elegant: {
        name: "Elegant",
        category: "professional",
        description: "Sophisticated design with gold accents",
        colors: {
          primary: "#1A1A1A",
          secondary: "#2D2D2D",
          accent: "#D4AF37",
          text: "#FFFFFF",
          textSecondary: "#C9C9C9",
          correct: "#D4AF37",
          wrong: "#8B0000",
        },
        background: {
          type: "gradient",
          colors: ["#0D0D0D", "#1A1A1A", "#2D2D2D"],
          animated: false,
        },
        fonts: {
          primary: "Playfair Display",
          secondary: "Lato",
          weights: { normal: "400", bold: "700", heavy: "900" },
        },
        effects: {
          transition: "fadeZoom",
          particles: "stars",
          textEffect: "goldLuxury",
        },
        // @NEW 2026-02-23: Elegant Canvas Styling
        canvas: {
          card: { style: "glass", opacity: 0.9, blur: 30, borderRadius: 15, borderWeight: 3, borderColor: "#D4AF37" },
          options: { style: "glass", borderRadius: 10, borderWeight: 2, borderColor: "rgba(212, 175, 55, 0.3)" }
        },
      },

      // === ENERGETIC ===

      neon: {
        name: "Neon Nights",
        category: "energetic",
        description: "Vibrant neon colors on dark background",
        colors: {
          primary: "#FF00FF",
          secondary: "#00FFFF",
          accent: "#FFFF00",
          text: "#FFFFFF",
          textSecondary: "#FF00FF",
          correct: "#00FF00",
          wrong: "#FF0040",
        },
        background: {
          type: "gradient",
          colors: ["#0D0221", "#150734", "#1A0A3E"],
          animated: true,
        },
        fonts: {
          primary: "Orbitron",
          secondary: "Rajdhani",
          weights: { normal: "500", bold: "700", heavy: "900" },
        },
        effects: {
          transition: "glitch",
          particles: "sparks",
          textEffect: "neonGlow",
        },
        // @NEW 2026-02-23: Neon Canvas Styling
        canvas: {
          card: { style: "neon", glowColor: "#FF00FF", glowBlur: 20, borderRadius: 50, borderWeight: 4 },
          options: { style: "neon-pill", borderRadius: 40, activeGlow: true }
        },
      },

      fire: {
        name: "Fire & Heat",
        category: "energetic",
        description: "Hot, fiery colors for intense quizzes",
        colors: {
          primary: "#FF4500",
          secondary: "#FF6B35",
          accent: "#FFD700",
          text: "#FFFFFF",
          textSecondary: "#FFCC00",
          correct: "#00FF00",
          wrong: "#FF0000",
        },
        background: {
          type: "gradient",
          colors: ["#1A0000", "#3D0000", "#5C0000"],
          animated: true,
        },
        fonts: {
          primary: "Bangers",
          secondary: "Roboto",
          weights: { normal: "400", bold: "400", heavy: "400" },
        },
        effects: {
          transition: "flashWhite",
          particles: "sparks",
          textEffect: "fireIce",
        },
      },

      electric: {
        name: "Electric Blue",
        category: "energetic",
        description: "High-energy electric blue theme",
        colors: {
          primary: "#00D4FF",
          secondary: "#0099FF",
          accent: "#FFFFFF",
          text: "#FFFFFF",
          textSecondary: "#00D4FF",
          correct: "#00FF88",
          wrong: "#FF3366",
        },
        background: {
          type: "gradient",
          colors: ["#000428", "#004e92", "#000428"],
          animated: true,
        },
        fonts: {
          primary: "Electrolize",
          secondary: "Roboto Mono",
          weights: { normal: "400", bold: "400", heavy: "400" },
        },
        effects: {
          transition: "zoomBlur",
          particles: "sparks",
          textEffect: "neonGlow",
        },
      },

      // === THEMED ===

      horror: {
        name: "Horror",
        category: "themed",
        description: "Spooky theme for horror trivia",
        colors: {
          primary: "#8B0000",
          secondary: "#4A0000",
          accent: "#FF0000",
          text: "#E8E8E8",
          textSecondary: "#990000",
          correct: "#00FF00",
          wrong: "#FF0000",
        },
        background: {
          type: "gradient",
          colors: ["#0A0A0A", "#1A0A0A", "#0A0A0A"],
          animated: false,
        },
        fonts: {
          primary: "Creepster",
          secondary: "Nosifer",
          weights: { normal: "400", bold: "400", heavy: "400" },
        },
        effects: {
          transition: "glitch",
          particles: null,
          textEffect: "classicBold",
        },
      },

      space: {
        name: "Space Odyssey",
        category: "themed",
        description: "Cosmic theme with stars and galaxies",
        colors: {
          primary: "#9B59B6",
          secondary: "#3498DB",
          accent: "#F39C12",
          text: "#FFFFFF",
          textSecondary: "#9B59B6",
          correct: "#2ECC71",
          wrong: "#E74C3C",
        },
        background: {
          type: "gradient",
          colors: ["#0F0C29", "#302B63", "#24243E"],
          animated: true,
        },
        fonts: {
          primary: "Orbitron",
          secondary: "Exo 2",
          weights: { normal: "500", bold: "700", heavy: "900" },
        },
        effects: {
          transition: "fadeZoom",
          particles: "stars",
          textEffect: "classicBold",
        },
      },

      nature: {
        name: "Nature",
        category: "themed",
        description: "Fresh, natural green theme",
        colors: {
          primary: "#27AE60",
          secondary: "#2ECC71",
          accent: "#F1C40F",
          text: "#FFFFFF",
          textSecondary: "#A9DFBF",
          correct: "#00FF00",
          wrong: "#E74C3C",
        },
        background: {
          type: "gradient",
          colors: ["#0F2917", "#1A4D2E", "#0F2917"],
          animated: true,
        },
        fonts: {
          primary: "Quicksand",
          secondary: "Open Sans",
          weights: { normal: "500", bold: "700", heavy: "700" },
        },
        effects: {
          transition: "slideLeft",
          particles: "confetti",
          textEffect: "classicBold",
        },
      },

      retro80s: {
        name: "Retro 80s",
        category: "themed",
        description: "Synthwave retro aesthetic",
        colors: {
          primary: "#FF6EC7",
          secondary: "#00FFFF",
          accent: "#FFE600",
          text: "#FFFFFF",
          textSecondary: "#FF6EC7",
          correct: "#00FF00",
          wrong: "#FF0066",
        },
        background: {
          type: "gradient",
          colors: ["#1A0533", "#2D1B4E", "#0D0221"],
          animated: true,
        },
        fonts: {
          // @FIX 2026-08-11: 'Press Start 2P' is a very wide display pixel font — long
          //       questions auto-shrunk to tiny unreadable sizes. 'Orbitron' keeps the
          //       retro-futuristic vibe but stays legible for questions/brand. VT323
          //       (terminal) kept for options. Both ship locally (Orbitron-Bold.ttf,
          //       VT323-Regular.ttf) and are registered in browser + server pipelines.
          primary: "Orbitron",
          secondary: "VT323",
          weights: { normal: "400", bold: "700", heavy: "900" },
        },
        effects: {
          transition: "pixelate",
          particles: "confetti",
          textEffect: "retroArcade",
        },
        // @NEW 2026-02-23: Retro Canvas Styling
        // @FIX 2026-08-11: Brutalist cards were white -> magenta/cyan retroArcade text was
        //       unreadable (poor contrast + glow washout). fillColor dark (#0D0221) so the
        //       neon text pops, matching the classic synthwave look.
        canvas: {
          card: { style: "brutalist", offset: 15, borderRadius: 0, shadowColor: "rgba(0,0,0,1)", borderWeight: 4, fillColor: "#0D0221" },
          options: { style: "brutalist", offset: 8, borderRadius: 0, borderWeight: 3, fillColor: "#0D0221" }
        },
      },

      cyberpunk: {
        name: "Cyberpunk",
        category: "themed",
        description: "Futuristic cyberpunk style",
        colors: {
          primary: "#00FFC8",
          secondary: "#FF0080",
          accent: "#FFFF00",
          text: "#FFFFFF",
          textSecondary: "#00FFC8",
          correct: "#00FF00",
          wrong: "#FF0040",
        },
        background: {
          type: "gradient",
          colors: ["#0D0D0D", "#1A1A2E", "#0D0D0D"],
          animated: true,
        },
        fonts: {
          primary: "Audiowide",
          secondary: "Share Tech Mono",
          weights: { normal: "400", bold: "400", heavy: "400" },
        },
        effects: {
          transition: "glitch",
          particles: "sparks",
          textEffect: "glitchEffect",
        },
        // @NEW 2026-02-23: Cyberpunk Canvas Styling
        canvas: {
          card: { style: "neon", glowColor: "#00FFC8", glowBlur: 15, borderRadius: 10, borderWeight: 3, angle: 5 },
          options: { style: "neon", borderRadius: 5, activeGlow: true }
        },
      },

      // === EDUCATIONAL ===

      classroom: {
        name: "Classroom",
        category: "educational",
        description: "Traditional educational look",
        colors: {
          primary: "#2E7D32",
          secondary: "#4CAF50",
          accent: "#FFC107",
          text: "#FFFFFF",
          textSecondary: "#C8E6C9",
          correct: "#00E676",
          wrong: "#FF5252",
        },
        background: {
          type: "gradient",
          colors: ["#1B3A1B", "#2E5A2E", "#1B3A1B"],
          animated: false,
        },
        fonts: {
          primary: "Permanent Marker",
          secondary: "Patrick Hand",
          weights: { normal: "400", bold: "400", heavy: "400" },
        },
        effects: {
          transition: "slideLeft",
          particles: "stars",
          textEffect: "classicBold",
        },
      },

      science: {
        name: "Science Lab",
        category: "educational",
        description: "Scientific theme with molecular feel",
        colors: {
          primary: "#00BCD4",
          secondary: "#0097A7",
          accent: "#FFEB3B",
          text: "#FFFFFF",
          textSecondary: "#80DEEA",
          correct: "#76FF03",
          wrong: "#FF1744",
        },
        background: {
          type: "gradient",
          colors: ["#001F3F", "#003366", "#001F3F"],
          animated: true,
        },
        fonts: {
          primary: "Exo 2",
          secondary: "Roboto Mono",
          weights: { normal: "500", bold: "700", heavy: "900" },
        },
        effects: {
          transition: "zoomBlur",
          particles: "sparks",
          textEffect: "classicBold",
        },
      },

      history: {
        name: "History",
        category: "educational",
        description: "Vintage, historical aesthetic",
        colors: {
          primary: "#8D6E63",
          secondary: "#6D4C41",
          accent: "#D4AF37",
          text: "#FFF8E1",
          textSecondary: "#BCAAA4",
          correct: "#81C784",
          wrong: "#E57373",
        },
        background: {
          type: "gradient",
          colors: ["#2C1810", "#3E2723", "#2C1810"],
          animated: false,
        },
        fonts: {
          primary: "Cinzel",
          secondary: "EB Garamond",
          weights: { normal: "400", bold: "700", heavy: "900" },
        },
        effects: {
          transition: "fadeZoom",
          particles: null,
          textEffect: "elegantSerif",
        },
      },

      // === EXISTING (UPGRADED) ===

      tech: {
        name: "Tech Mastery",
        category: "existing",
        description: "Technology and coding theme",
        colors: {
          primary: "#00D4FF",
          secondary: "#0099CC",
          accent: "#00FF88",
          text: "#FFFFFF",
          textSecondary: "#00D4FF",
          correct: "#00FF00",
          wrong: "#FF3366",
        },
        background: {
          type: "gradient",
          colors: ["#0a1628", "#132a4a", "#1e3d6a"],
          animated: true,
        },
        fonts: {
          primary: "Fira Code",
          secondary: "JetBrains Mono",
          weights: { normal: "400", bold: "600", heavy: "700" },
        },
        effects: {
          transition: "glitch",
          particles: "sparks",
          textEffect: "neonGlow",
        },
      },

      sports: {
        name: "Sports Arena",
        category: "existing",
        description: "Dynamic sports theme",
        colors: {
          primary: "#E53935",
          secondary: "#C62828",
          accent: "#FFEB3B",
          text: "#FFFFFF",
          textSecondary: "#FF8A80",
          correct: "#00E676",
          wrong: "#FF1744",
        },
        background: {
          type: "gradient",
          colors: ["#0d1a0d", "#1a3d1a", "#2d5a2d"],
          animated: true,
        },
        fonts: {
          primary: "Bebas Neue",
          secondary: "Oswald",
          weights: { normal: "400", bold: "400", heavy: "400" },
        },
        effects: {
          transition: "swipeUp",
          particles: "confetti",
          textEffect: "comicBold",
        },
      },

      trivia: {
        name: "General Trivia",
        category: "existing",
        description: "Classic quiz show style",
        colors: {
          primary: "#9C27B0",
          secondary: "#7B1FA2",
          accent: "#00F0FF",
          text: "#FFFFFF",
          textSecondary: "#E1BEE7",
          correct: "#00E676",
          wrong: "#FF5252",
        },
        background: {
          type: "gradient",
          colors: ["#1a0a3e", "#2d1b69", "#4a2c8d"],
          animated: true,
        },
        fonts: {
          primary: "Outfit",
          secondary: "Inter",
          weights: { normal: "500", bold: "700", heavy: "900" },
        },
        effects: {
          transition: "fadeZoom",
          particles: "confetti",
          textEffect: "classicBold",
        },
      },
    },

    // ==========================================
    // METHODS
    // ==========================================

    /**
     * Get all templates
     * @returns {object}
     */
    getAll: function () {
      return this.templates;
    },

    /**
     * Get template by ID
     * @param {string} id
     * @returns {object|null}
     */
    get: function (id) {
      return this.templates[id] || null;
    },

    /**
     * Get templates by category
     * @param {string} category
     * @returns {object}
     */
    getByCategory: function (category) {
      const filtered = {};
      Object.entries(this.templates).forEach(([id, template]) => {
        if (template.category === category) {
          filtered[id] = template;
        }
      });
      return filtered;
    },

    /**
     * Get all categories
     * @returns {array}
     */
    getCategories: function () {
      return [...new Set(Object.values(this.templates).map((t) => t.category))];
    },

    /**
     * Apply template to studio state
     * @param {string} templateId
     * @param {object} state - Studio state object to modify
     */
    apply: function (templateId, state) {
      let resolvedId = templateId;
      // @FIX 1.4.9.57 (regression): a job may still reference a template that no
      // longer exists (e.g. the removed minimalist/quizwire) — e.g. old jobs in
      // vs_jobs. Fall back to a safe built-in dark template instead of applying an
      // empty default config (which rendered black-bg + hardcoded-white text).
      if (!this.get(resolvedId)) {
        console.warn("[NM Templates] Template not found:", resolvedId, "— falling back to trivia");
        resolvedId = "trivia";
      }
      const template = this.get(resolvedId);
      if (!template) {
        console.warn("[NM Templates] Fallback template missing:", resolvedId);
        return false;
      }

      // Apply background
      if (state.backgrounds) {
        state.backgrounds[resolvedId] = template.background;
      }

      // Apply text effects
      if (state.textEffects) {
        state.textEffects.currentStyle = template.effects.textEffect;
      }

      // Store template reference
      state.currentTemplate = resolvedId;
      state.templateColors = template.colors;
      state.templateFonts = template.fonts;
      state.templateEffects = template.effects;

      console.log("[NM Templates] Applied template:", resolvedId);
      return true;
    },

    /**
     * Get random template
     * @param {string} category - Optional category filter
     * @returns {string} - Template ID
     */
    getRandom: function (category = null) {
      let pool = Object.keys(this.templates);

      if (category) {
        pool = pool.filter((id) => this.templates[id].category === category);
      }

      return pool[Math.floor(Math.random() * pool.length)];
    },

    /**
     * Generate preview gradient for template card
     * @param {string} templateId
     * @returns {string} - CSS gradient
     */
    getPreviewGradient: function (templateId) {
      const template = this.get(templateId);
      if (!template) return "linear-gradient(135deg, #333, #111)";

      const colors = template.background.colors;
      return `linear-gradient(135deg, ${colors.join(", ")})`;
    },
  };


  // ==========================================
  // PHASE 2: Schema + Declared Assets (for key templates)
  // ==========================================
  const _mcqvsAttachSchema = (id) => {
    const t = MCQVS_VideoTemplates.templates[id];
    if (!t) return;

    // Lightweight schema for runtime contract enforcement
    t.schema = t.schema || {
      name: { required: true, type: "string" },
      category: { required: true, type: "string" },
      colors: {
        required: true,
        type: "object",
        shape: {
          primary: { required: true, type: "string" },
          secondary: { required: true, type: "string" },
          accent: { required: true, type: "string" },
          text: { required: true, type: "string" },
          correct: { required: true, type: "string" },
          wrong: { required: true, type: "string" },
        },
      },
      background: {
        required: true,
        type: "object",
        shape: { type: { required: true, type: "string" } },
      },
      fonts: {
        required: true,
        type: "object",
        shape: {
          primary: { required: true, type: "string" },
          secondary: { required: true, type: "string" },
        },
      },
      effects: { required: true, type: "object" },
    };

    // Declared assets: fonts are critical (preview/export parity)
    t.assets = t.assets || { fonts: [], images: [], audio: [] };
    if (t.fonts) {
      if (t.fonts.primary && !t.assets.fonts.includes(t.fonts.primary)) t.assets.fonts.push(t.fonts.primary);
      if (t.fonts.secondary && !t.assets.fonts.includes(t.fonts.secondary)) t.assets.fonts.push(t.fonts.secondary);
    }
  };

  [
    "corporate",
    "elegant",
    "neon",
    "fire",
    "electric",
    "classroom",
    "science",
    "history",
  ].forEach(_mcqvsAttachSchema);


  // ==========================================
  // PHASE 3: Template Contracts (Declared Assets + CuePoints)
  // ==========================================
  // @PHASE 5.1 2026-01-30: Template-defined timer glow region (exact pill bounds per template)
const _mcqvsTimerRectFor = (tid, plan, opts = {}) => {
const w = (plan && plan.width) ? Number(plan.width) : 1080;
const h = (plan && plan.height) ? Number(plan.height) : 1920;
const isLandscape = w > h;

const group = (["corporate", "elegant"].includes(tid)) ? "professional"
: (["neon", "fire", "electric"].includes(tid)) ? "neon"
: (["classroom", "science", "history"].includes(tid)) ? "school"
: "default";

let pillW, pillH, pillY, pillR, pillX;

if (isLandscape) {
pillW = Math.round(w * 0.07);
pillH = Math.round(h * 0.055);
pillY = Math.round(h * 0.87);
pillX = Math.round(w * 0.89);
pillR = 14;
if (group === "professional") { pillW = Math.round(w * 0.07); pillH = Math.round(h * 0.055); pillR = 12; }
if (group === "neon") { pillW = Math.round(w * 0.075); pillH = Math.round(h * 0.06); pillR = 16; }
if (group === "school") { pillW = Math.round(w * 0.07); pillH = Math.round(h * 0.055); pillR = 14; }
} else {
pillW = Math.round(w * 0.389); pillH = Math.round(h * 0.068); pillY = Math.round(h * 0.833); pillR = 26;
pillX = Math.round((w - pillW) / 2);
if (group === "professional") { pillW = Math.round(w * 0.389); pillH = Math.round(h * 0.068); pillY = Math.round(h * 0.833); pillR = 24; }
if (group === "neon") { pillW = Math.round(w * 0.389); pillH = Math.round(h * 0.068); pillY = Math.round(h * 0.833); pillR = 30; }
if (group === "school") { pillW = Math.round(w * 0.389); pillH = Math.round(h * 0.068); pillY = Math.round(h * 0.833); pillR = 26; }
}

    if (opts && opts.timerRect && typeof opts.timerRect === "object") {
      const r = opts.timerRect;
      return {
        x: Number.isFinite(r.x) ? r.x : pillX,
        y: Number.isFinite(r.y) ? r.y : pillY,
        w: Number.isFinite(r.w) ? r.w : pillW,
        h: Number.isFinite(r.h) ? r.h : pillH,
        r: Number.isFinite(r.r) ? r.r : pillR,
      };
    }

    return { x: pillX, y: pillY, w: pillW, h: pillH, r: pillR };
  };

  const _mcqvsAttachContracts = (id, opts = {}) => {
    const t = MCQVS_VideoTemplates.templates[id];
    if (!t) return;

    // Uniform contract for tooling (preflight, audio, FX scheduling)
    t.getDeclaredAssets = t.getDeclaredAssets || function () {
      return {
        fonts: (this.assets && this.assets.fonts) ? [...this.assets.fonts] : [],
        images: (this.assets && this.assets.images) ? [...this.assets.images] : [],
        audio: (this.assets && this.assets.audio) ? [...this.assets.audio] : [],
      };
    };

    // Plan-derived cue points (template can add/override behavior)
    t.getCuePoints = t.getCuePoints || function (plan) {
      const cues = (plan && Array.isArray(plan.cues)) ? plan.cues : [];
      const byType = (type) => cues.filter((c) => c.type === type);

      // Template-defined timer region for glow effects (preview/export parity)
      const timerRect = _mcqvsTimerRectFor(id, plan, opts);


      const baseMusicDuck = Number(opts.duckVolume || 0.18);
      const duckWindows = [];

      // Duck music around reveals (prevents SFX masking on mobile)
      byType("reveal_start").forEach((c) => {
        duckWindows.push({ startMs: Math.max(0, c.atMs - 250), endMs: c.atMs + 1400, volume: baseMusicDuck });
      });

      // Optional duck around intro/outro transitions
      if (opts.duckIntro) {
        byType("intro_start").forEach((c) => {
          duckWindows.push({ startMs: Math.max(0, c.atMs), endMs: c.atMs + 700, volume: baseMusicDuck });
        });
      }
      if (opts.duckOutro) {
        byType("outro_start").forEach((c) => {
          duckWindows.push({ startMs: Math.max(0, c.atMs), endMs: c.atMs + 700, volume: baseMusicDuck });
        });
      }

      // SFX events from plan (generic)
      const sfxEvents = [];
      const sfxTransition = opts.transitionSfx || "transition";
      const sfxReveal = opts.revealSfx || "reveal";
      const sfxResult = opts.resultSfx || "correct";

      byType("tick").forEach((c) => sfxEvents.push({ name: "tick", atMs: c.atMs, gain: 0.55 }));

      // @FIX 2026-07-02: Removed countdown SFX (file deleted by user, causes 404).
      // Reveal SFX at reveal start.
      byType("reveal_start").forEach((c) => {
        sfxEvents.push({ name: sfxReveal, atMs: c.atMs, gain: 1.0 });
      });

      // Result SFX exactly when the correct answer is displayed (more noticeable and matches user expectation).
      const revealCorrectCues = byType("reveal_correct");
      revealCorrectCues.forEach((c) => {
        sfxEvents.push({ name: sfxResult, atMs: c.atMs, gain: 1.0 });
      });

      // Transition SFX at scene boundaries (light, non-intrusive)
      // @FIX 2026-07-01: Skip whoosh at final question->outro boundary to avoid sound collision with outro flash
      if (plan && Array.isArray(plan.scenes)) {
        for (let i = 0; i < plan.scenes.length - 1; i++) {
          const a = plan.scenes[i];
          const b = plan.scenes[i + 1];
          if (a && b && a.endMs != null && b.type !== 'outro') {
            sfxEvents.push({ name: sfxTransition, atMs: Math.max(0, a.endMs - 120), gain: 0.55 });
          }
        }
      }

      // Visual FX cue points (preview + export parity)
      // Force sparkles for correct reveal regardless of template (user requirement).
      const fxEvents = [];
      {
        const particleCues = byType("reveal_correct");
        const cues = particleCues.length ? particleCues : byType("reveal_start");
        cues.forEach((c) => fxEvents.push({ type: "particles_burst", atMs: c.atMs, kind: "sparkles" }));
      }

      // @PHASE 5 2026-01-30: Production FX (intro/outro flashes, timer glow, screen shake)
      const flashIntensity = Number(opts.flashIntensity != null ? opts.flashIntensity : 0.65);
      const shakeMag = Number(opts.shakeMag != null ? opts.shakeMag : 10);
      const glowIntensity = Number(opts.timerGlowIntensity != null ? opts.timerGlowIntensity : 0.75);

      byType("intro_start").forEach((c) => fxEvents.push({ type: "flash", atMs: c.atMs, durationMs: 320, intensity: flashIntensity }));
      byType("outro_start").forEach((c) => fxEvents.push({ type: "flash", atMs: c.atMs, durationMs: 320, intensity: flashIntensity }));

      // Timer glow: pulse on tick cues (last 5 seconds) for retention
      byType("tick").forEach((c) => fxEvents.push({ type: "timer_glow", atMs: c.atMs, durationMs: 240, intensity: glowIntensity, color: (this.colors && this.colors.accent) ? this.colors.accent : "#00f0ff", rect: timerRect }));

      // Reveal hit: subtle shake to emphasize the answer moment
      const shakeCues = byType("reveal_correct");
      (shakeCues.length ? shakeCues : byType("reveal_start")).forEach((c) =>
        fxEvents.push({ type: "screen_shake", atMs: c.atMs, durationMs: 360, magnitude: shakeMag })
      );

      return { duckWindows, sfxEvents, fxEvents };
    };
  };

  // Contracts tuned for your primary templates
    // @FIX 2026-01-31: Add all templates to ensure FX/SFX events work universally
    [
      ["corporate", { duckIntro: true, duckOutro: true, transitionSfx: "transition", duckVolume: 0.20 }],
    ["elegant", { duckIntro: true, duckOutro: true, transitionSfx: "transition", duckVolume: 0.20, flashIntensity: 0.55, shakeMag: 8, timerGlowIntensity: 0.65 }],

    ["neon", { duckIntro: true, duckOutro: true, transitionSfx: "whoosh", duckVolume: 0.14, flashIntensity: 0.75, shakeMag: 14, timerGlowIntensity: 0.90 }],
    ["fire", { duckIntro: true, duckOutro: true, transitionSfx: "whoosh", duckVolume: 0.14, flashIntensity: 0.80, shakeMag: 16, timerGlowIntensity: 0.95 }],
    ["electric", { duckIntro: true, duckOutro: true, transitionSfx: "whoosh", duckVolume: 0.14, flashIntensity: 0.80, shakeMag: 16, timerGlowIntensity: 0.95 }],

    ["classroom", { duckIntro: false, duckOutro: false, transitionSfx: "transition", duckVolume: 0.22, flashIntensity: 0.45, shakeMag: 6, timerGlowIntensity: 0.60 }],
    ["science", { duckIntro: false, duckOutro: false, transitionSfx: "transition", duckVolume: 0.22, flashIntensity: 0.45, shakeMag: 6, timerGlowIntensity: 0.60 }],
    ["history", { duckIntro: false, duckOutro: false, transitionSfx: "transition", duckVolume: 0.22, flashIntensity: 0.45, shakeMag: 6, timerGlowIntensity: 0.60 }],

    // @FIX 2026-01-31: Missing templates
    ["trivia", { duckIntro: true, duckOutro: true, transitionSfx: "transition", duckVolume: 0.18, flashIntensity: 0.65, shakeMag: 10, timerGlowIntensity: 0.75 }],
    ["tech", { duckIntro: true, duckOutro: true, transitionSfx: "whoosh", duckVolume: 0.14, flashIntensity: 0.80, shakeMag: 14, timerGlowIntensity: 0.90 }],
    ["sports", { duckIntro: true, duckOutro: true, transitionSfx: "whoosh", duckVolume: 0.16, flashIntensity: 0.70, shakeMag: 12, timerGlowIntensity: 0.80 }],
    ["horror", { duckIntro: false, duckOutro: false, transitionSfx: "transition", duckVolume: 0.12, flashIntensity: 0.40, shakeMag: 8, timerGlowIntensity: 0.50 }],
    ["space", { duckIntro: true, duckOutro: true, transitionSfx: "transition", duckVolume: 0.18, flashIntensity: 0.65, shakeMag: 10, timerGlowIntensity: 0.75 }],
    ["nature", { duckIntro: true, duckOutro: true, transitionSfx: "transition", duckVolume: 0.20, flashIntensity: 0.60, shakeMag: 8, timerGlowIntensity: 0.70 }],
    ["retro80s", { duckIntro: true, duckOutro: true, transitionSfx: "whoosh", duckVolume: 0.14, flashIntensity: 0.75, shakeMag: 14, timerGlowIntensity: 0.90 }],
    ["cyberpunk", { duckIntro: true, duckOutro: true, transitionSfx: "whoosh", duckVolume: 0.14, flashIntensity: 0.80, shakeMag: 16, timerGlowIntensity: 0.95 }],
  ].forEach(([id, opts]) => _mcqvsAttachContracts(id, opts));


  // ==========================================
  // Export to window (canonical + back-compat)
  // ==========================================
  // @FIX 2026-02-03: Canonical global is MCQVSVideoTemplates (used by Studio + TemplateManager).
  // Keep MCQVS_VideoTemplates as alias to avoid regressions in older code.
  (function exportGlobals(win, api) {
    // Canonical
    win.MCQVSVideoTemplates = api;

    // Back-compat alias (do not remove)
    win.MCQVS_VideoTemplates = api;
  })(window, MCQVS_VideoTemplates);
})(window);
