/**
 * NM TTS Manager
 * Multi-provider Text-to-Speech manager for Quiz Shorts Studio
 *
 * Supports:
 * - Edge TTS (Microsoft, free, unlimited — via server-side Node.js helper)
 * - Google Cloud TTS (free tier: 4M chars/month standard, 1M Wavenet)
 * - Azure Cognitive TTS (paid API key required)

 * - ElevenLabs TTS (paid API key required)
 * - Web Speech API (browser built-in, preview-only fallback)
 *
 * @package WP_News_MCQ_Generator
 * @version 2.0.0
 */

(function (window) {
  "use strict";

  const MCQVS_TTSManager = {
    // Configuration
    config: {
      provider: "edge", // 'edge', 'google', 'webspeech'
      voice: "en-US-AriaNeural", // Edge TTS voice
      googleVoice: "en-US-Neural2-F", // Google Cloud voice
      rate: 1.0,
      pitch: 1.0,
      ajaxUrl: "",
      nonce: "",
      googleApiKey: "", // Set from WordPress settings
      elevenlabsVoice: "pNInz6obpgmqS2C9vI62", // Default ElevenLabs voice (Adam)
    },

    // Voice mappings
    voices: {
      edge: [
        // US English
        { id: "en-US-AriaNeural", name: "Aria (Female, US)", gender: "female" },
        { id: "en-US-GuyNeural", name: "Guy (Male, US)", gender: "male" },
        { id: "en-US-JennyNeural", name: "Jenny (Female, US)", gender: "female" },
        { id: "en-US-TonyNeural", name: "Tony (Male, US)", gender: "male" },
        { id: "en-US-MichelleNeural", name: "Michelle (Female, US)", gender: "female" },
        { id: "en-US-AnaNeural", name: "Ana (Female, US, Child)", gender: "female" },
        // UK English — tested working
        { id: "en-GB-SoniaNeural", name: "Sonia (Female, UK)", gender: "female" },
        { id: "en-GB-RyanNeural", name: "Ryan (Male, UK)", gender: "male" },
        { id: "en-GB-LibbyNeural", name: "Libby (Female, UK)", gender: "female" },
        { id: "en-GB-MaisieNeural", name: "Maisie (Female, UK)", gender: "female" },
        { id: "en-GB-ThomasNeural", name: "Thomas (Male, UK)", gender: "male" },
        // Australian English — tested working
        { id: "en-AU-NatashaNeural", name: "Natasha (Female, AU)", gender: "female" },
        { id: "en-AU-WilliamNeural", name: "William (Male, AU)", gender: "male" },
        // Indian English — tested working
        { id: "en-IN-NeerjaNeural", name: "Neerja (Female, IN)", gender: "female" },
        { id: "en-IN-PrabhatNeural", name: "Prabhat (Male, IN)", gender: "male" },
        // Canadian English
        { id: "en-CA-ClaraNeural", name: "Clara (Female, CA)", gender: "female" },
        { id: "en-CA-LiamNeural", name: "Liam (Male, CA)", gender: "male" },
        // Irish English
        { id: "en-IE-ConnorNeural", name: "Connor (Male, IE)", gender: "male" },
        { id: "en-IE-EmilyNeural", name: "Emily (Female, IE)", gender: "female" },
      ],
      google: [
        {
          id: "en-US-Neural2-F",
          name: "Neural2 Female (US)",
          gender: "female",
        },
        { id: "en-US-Neural2-D", name: "Neural2 Male (US)", gender: "male" },
        {
          id: "en-US-Wavenet-F",
          name: "Wavenet Female (US)",
          gender: "female",
        },
        { id: "en-US-Wavenet-D", name: "Wavenet Male (US)", gender: "male" },
        {
          id: "en-GB-Neural2-A",
          name: "Neural2 Female (UK)",
          gender: "female",
        },
        { id: "en-GB-Neural2-B", name: "Neural2 Male (UK)", gender: "male" },
      ],
      elevenlabs: [
        { id: "pNInz6obpgmqS2C9vI62", name: "Adam (Male)", gender: "male" },
        {
          id: "21m00Tcm4lPqWqAnfXSt",
          name: "Rachel (Female)",
          gender: "female",
        },
      ],
    },

    // Cache for generated audio
    cache: {},

    // Current audio state
    _currentAudio: null,
	_speaking: false,
	_speakingSince: 0,

    /**
     * Initialize TTS Manager
     * @param {object} config
     */
    init: function (config = {}) {
      this.config = { ...this.config, ...config };

      // Load Web Speech API voices
      if ("speechSynthesis" in window) {
        speechSynthesis.onvoiceschanged = () => {
          this.voices.webspeech = speechSynthesis
            .getVoices()
            .filter((v) => v.lang.startsWith("en"))
            .map((v) => ({
              id: v.voiceURI,
              name: v.name,
              gender: "unknown",
              native: v,
            }));
        };
        speechSynthesis.getVoices();
      }

      console.log("[NM TTS] Initialized with provider:", this.config.provider);
    },

    /**
     * Set TTS provider
     * @param {string} provider - 'edge', 'google', 'webspeech'
     */
    setProvider: function (provider) {
      if (
        [
          "edge",
          "google",
          "webspeech",
          "azure",
          "elevenlabs",
        ].includes(provider)
      ) {
        this.config.provider = provider;
        console.log("[NM TTS] Provider set to:", provider);
      }
    },

    /**
     * Set voice for current provider
     * @param {string} voiceId
     */
    setVoice: function (voiceId) {
      if (this.config.provider === "edge") {
        this.config.voice = voiceId;
      } else if (this.config.provider === "google") {
        this.config.googleVoice = voiceId;
      } else if (this.config.provider === "elevenlabs") {
        this.config.elevenlabsVoice = voiceId;
      }
    },

    /**
     * Get available voices for current provider
     * @returns {array}
     */
    getVoices: function () {
      return this.voices[this.config.provider] || [];
    },

    /**
     * Speak text - main entry point
     * @param {string} text
     * @param {object} options
     * @returns {Promise<number>} - Duration in ms
     */
	speak: async function (text, options = {}) {
		if (!text || this._speaking) {
			if (this._speaking && this._speakingSince && (Date.now() - this._speakingSince > 60000)) {
				console.warn('[NM TTS] _speaking stuck for >60s, force-resetting');
				this._speaking = false;
				this._currentAudio = null;
				try { if (window.speechSynthesis) window.speechSynthesis.cancel(); } catch (_) {}
			} else {
				return 0;
			}
		}

		const opts = {
			rate: this.config.rate,
			pitch: this.config.pitch,
			...options,
		};

		this._speaking = true;
		this._speakingSince = Date.now();

      try {
        // If provider is webspeech, use browser API
        if (this.config.provider === "webspeech") {
          return await this._speakWebSpeech(text, opts);
        }

        // Use Server-side TTS for Edge, Google, Azure, ElevenLabs
        // @MODIFIED 2026-04-24: Edge is now a standalone free provider (no Azure key needed)
        return await this._speakServer(text, {
            provider: this.config.provider,
            voice:
            this.config.provider === "google"
              ? this.config.googleVoice
              : this.config.provider === "elevenlabs"
              ? this.config.elevenlabsVoice
              : this.config.voice,
          ...opts,
        });
      } catch (error) {
        console.error("[NM TTS] Error:", error);
        // Fallback to Web Speech API
        return await this._speakWebSpeech(text, opts);
      } finally {
        this._speaking = false;
      }
    },

    /**
     * Internal server-side TTS renderer
     */
_speakServer: async function (text, params) {
    if (this.cache[text]) {
      return await this._playAudio(this.cache[text]);
    }

    const formData = new FormData();
    formData.append("action", "mcqvs_generate_tts");
    formData.append("nonce", this.config.nonce);
    formData.append("text", text);
    formData.append("voice", params.voice);
    formData.append("provider", params.provider);

    const response = await fetch(this.config.ajaxUrl, {
      method: "POST",
      body: formData,
    });

    const contentType = response.headers.get("content-type");
    if (!contentType || !contentType.includes("application/json")) {
      const text = await response.text();
      console.error("[NM TTS] Non-JSON response:", text.substring(0, 200));
      throw new Error(
        "Server returned an invalid response (not JSON). Please check server logs."
      );
    }

    const data = await response.json();
    if (!data.success) {
      throw new Error(data.data || "TTS Generation Failed");
    }

    // Favor audio_url (server cached) over base64
    const audioUrl =
      data.data.audio_url ||
      (data.data.audio_base64
        ? "data:audio/mp3;base64," + data.data.audio_base64
        : null);

    if (!audioUrl) {
      throw new Error("No audio data returned from server");
    }

    // Use server-provided duration if available (NEW: TTS synchronization fix)
    // Fall back to measuring actual audio duration if not provided (backward compatibility)
    let durationMs = null;
    if (data.data && typeof data.data.duration === 'number') {
      // Server provided estimated duration - use it for perfect synchronization
      durationMs = data.data.duration * 1000; // Convert seconds to milliseconds
      console.log(
        "[NM TTS] Using server-provided duration:",
        durationMs / 1000,
        "seconds for:",
        text.substring(0, 20) + "..."
      );
    } else {
      // Server didn't provide duration - measure actual audio duration (legacy behavior)
      console.log(
        "[NM TTS] Server did not provide duration, will measure actual audio length"
      );
    }

    if (data.data.cached) {
      console.log(
        "[NM TTS] Using server-cached audio for:",
        text.substring(0, 20) + "..."
      );
    }

    this.cache[text] = audioUrl;

    // If we have server-provided duration, use it directly
    // Otherwise, play the audio and wait for it to end to get actual duration
    if (durationMs !== null) {
      // Return a promise that resolves after the server-provided duration
      return new Promise((resolve) => {
        setTimeout(() => {
          // Clear current audio reference since we're not actually playing it
          this._currentAudio = null;
          resolve(durationMs);
        }, durationMs);
      });
    } else {
      // Fall back to original behavior: play audio and measure actual duration
      return await this._playAudio(audioUrl);
    }
  },

    /**
     * Stop current speech
     */
    stop: function () {
      if (this._currentAudio) {
        this._currentAudio.pause();
        this._currentAudio = null;
      }
      if ("speechSynthesis" in window) {
        speechSynthesis.cancel();
      }
      this._speaking = false;
    },

    /**
     * Pre-generate TTS for multiple texts
     * @param {array} texts
     * @returns {Promise<object>} - Map of text -> audio data
     */
    pregenerate: async function (texts) {
      const results = {};

      for (const text of texts) {
        if (this.cache[text]) {
          results[text] = this.cache[text];
          continue;
        }

        try {
          if (this.config.provider === "edge") {
            const audioData = await this._generateEdge(text);
            this.cache[text] = audioData;
            results[text] = audioData;
          } else if (this.config.provider === "google") {
            const audioData = await this._generateGoogle(text);
            this.cache[text] = audioData;
            results[text] = audioData;
          }
        } catch (e) {
          console.error("[NM TTS] Pregenerate error for:", text, e);
        }
      }

      return results;
    },

    /**
     * Get estimated duration for text (without generating)
     * @param {string} text
     * @returns {number} - Estimated duration in ms
     */
    estimateDuration: function (text) {
      if (!text) return 0;
      // Punctuation-weighted estimate matching controller's auto-fit formula.
      // Accounts for sentence-boundary pauses and structured TTS (labels, options).
      const txt = String(text || '').trim();
      const wc = txt.split(/\s+/).filter(Boolean).length;
      if (!wc) return 0;
      const baseWpm = 150;
      const rate = Math.max(0.6, Math.min(1.4, Number(this.config.rate) || 1.0));
      const wps = Math.max(1.2, (baseWpm / 60) * rate);
      const punct = (txt.match(/[.!?]/g) || []).length;
      const sec = (wc / wps) + 0.35 + Math.min(1.5, punct * 0.16);
      return Math.max(800, Math.ceil(sec * 1000 * 1.15));
    },

    // ==========================================
    // EDGE TTS (via edge-tts-web API proxy)
    // ==========================================

    /**
     * Generate audio using Edge TTS
     * Uses the edge-tts library via server proxy or direct WebSocket
     */
    _generateEdge: async function (text) {
      // Edge TTS works via WebSocket to Microsoft's TTS service
      // For WordPress, we'll use the speak-tts npm package pattern
      // but implemented client-side using the Speech Synthesis Markup Language (SSML)

      // Since Edge TTS requires WebSocket connection to Microsoft servers,
      // we simulate it using the browser's native speech synthesis with
      // Microsoft voices if available, or queue for server generation

      // Check if we have Azure voices available in browser
      const voices = window.speechSynthesis?.getVoices() || [];
      const azureVoice = voices.find(
        (v) =>
          v.name.includes("Microsoft") &&
          v.name.includes(this.config.voice.split("-")[1])
      );

      if (azureVoice) {
        // Use native speech synthesis with Azure voice
        return new Promise((resolve, reject) => {
          const utterance = new SpeechSynthesisUtterance(text);
          utterance.voice = azureVoice;
          utterance.rate = this.config.rate;
          utterance.pitch = this.config.pitch;

          let audioData = null;
          utterance.onend = () => resolve(audioData);
          utterance.onerror = reject;

          speechSynthesis.speak(utterance);
        });
      }

      // Fallback: Use Web Speech API but return estimated duration
      return {
        type: "webspeech",
        text: text,
        duration: this.estimateDuration(text),
      };
    },

    _speakEdge: async function (text, opts) {
        // Check cache first
        if (this.cache[text] && this.cache[text].url) {
            return await this._playAudio(this.cache[text].url);
        }

        // @MODIFIED 2026-04-24: Edge TTS is now server-side (free, no API key needed).
        // Route through the same server pipeline as Google/Azure.
        return await this._speakServer(text, {
            provider: 'edge',
            voice: this.config.voice,
            ...opts,
        });
    },

    // ==========================================
    // GOOGLE CLOUD TTS
    // ==========================================

    _generateGoogle: async function (text) {
      if (!this.config.googleApiKey) {
        throw new Error("Google Cloud TTS API key not configured");
      }

      const response = await fetch(
        `https://texttospeech.googleapis.com/v1/text:synthesize?key=${this.config.googleApiKey}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            input: { text: text },
            voice: {
              languageCode: "en-US",
              name: this.config.googleVoice,
            },
            audioConfig: {
              audioEncoding: "MP3",
              speakingRate: this.config.rate,
              pitch: (this.config.pitch - 1) * 4, // Convert to semitones
            },
          }),
        }
      );

      if (!response.ok) {
        throw new Error(`Google TTS API error: ${response.status}`);
      }

      const data = await response.json();
      const audioContent = data.audioContent; // Base64 encoded MP3

      // Create audio URL from base64
      const audioBlob = this._base64ToBlob(audioContent, "audio/mp3");
      const audioUrl = URL.createObjectURL(audioBlob);

      return {
        type: "google",
        url: audioUrl,
        text: text,
        duration: await this._getAudioDuration(audioUrl),
      };
    },

    _speakGoogle: async function (text, opts) {
      try {
        let audioData = this.cache[text];

        if (!audioData) {
          audioData = await this._generateGoogle(text);
          this.cache[text] = audioData;
        }

        return await this._playAudio(audioData.url);
      } catch (error) {
        console.error("[NM TTS] Google TTS error:", error);
        // Fallback to Web Speech
        return await this._speakWebSpeech(text, opts);
      }
    },

    // ==========================================
    // WEB SPEECH API (Fallback)
    // ==========================================

    // @FIX 2026-07-31: speechSynthesis.getVoices() returns an EMPTY array until the
    //       browser fires 'voiceschanged' (async). The first TTS segment (the hook) used
    //       to run before voices loaded, so no voice was set and the browser's default
    //       (male) voice spoke the hook while later segments used the selected voice.
    //       Wait briefly for voices before selecting one.
    _waitForVoices: function (timeoutMs) {
        return new Promise((resolve) => {
            if (!("speechSynthesis" in window)) { resolve(); return; }
            const done = () => resolve();
            const voices = speechSynthesis.getVoices();
            if (voices && voices.length) { resolve(); return; }
            const timer = setTimeout(() => {
                cleanup();
                resolve();
            }, timeoutMs || 500);
            const handler = () => {
                if (speechSynthesis.getVoices().length) {
                    cleanup();
                    resolve();
                }
            };
            const cleanup = () => {
                clearTimeout(timer);
                speechSynthesis.removeEventListener('voiceschanged', handler);
            };
            speechSynthesis.addEventListener('voiceschanged', handler);
        });
    },

	_speakWebSpeech: async function (text, opts) {
		if (!("speechSynthesis" in window)) {
			throw new Error("Web Speech API not supported");
		}

		// Wait for voices to be available before choosing one.
		await this._waitForVoices();

		return new Promise((resolve, reject) => {
			speechSynthesis.cancel();

			const utterance = new SpeechSynthesisUtterance(text);
			utterance.rate = opts.rate || 1.0;
			utterance.pitch = opts.pitch || 1.0;

			const voices = speechSynthesis.getVoices();
			const englishVoices = voices.filter((v) => v.lang.toLowerCase().startsWith("en"));

			// @FIX 2026-07-31: Never let Web Speech silently pick the browser's default
			//       first English voice (frequently male, e.g. Microsoft David / Google US
			//       English). Preference order:
			//         1. A voice whose name/URI matches the configured default voice.
			//         2. A "female" English voice (common neural names) so previews match
			//            the Edge default voice personality when rotation is disabled.
			//         3. Any Google/Microsoft English voice (last resort).
			//         4. Any English voice.
			const configuredVoice = String(this.config && this.config.voice ? this.config.voice : '').trim().toLowerCase();
			const femaleHints = ["aria", "jenny", "michelle", "sonia", "libby", "maisie", "natasha", "neerja", "clara", "emily", "ana", "zira", "hazel", "heera", "amy", "jane", "zoe", "susan", "katherine", "google us english"];

			// Match on the voice SHORT-NAME only (e.g. "aria" from "en-US-AriaNeural"),
			// not the language/locale prefix ("en", "us", "gb") which matches every
			// English voice and would inadvertently re-select the browser's default male voice.
			const extractShortName = (id) => {
				const parts = String(id || '').split('-');
				let name = parts[parts.length - 1] || '';
				name = name.replace(/\d+$/i, '').replace(/neural$/i, '');
				return name.toLowerCase() || '';
			};
			const shortName = extractShortName(configuredVoice);

			const matchConfigured = shortName
				? englishVoices.find((v) => {
						const hay = (v.name + ' ' + (v.voiceURI || '')).toLowerCase();
						// "aria" should match "Aria", "ariaonline", "aria-online", "aria.zip"
						return hay.includes(shortName) ||
							new RegExp('\\b' + shortName + '\\b').test(hay.replace(/[^a-z0-9]/g, ' '));
					})
				: null;

			const matchFemale =
				englishVoices.find((v) => femaleHints.some((hint) => v.name.toLowerCase().includes(hint))) ||
				englishVoices.find((v) => /\(female\)/i.test(v.name) && /female|women|she/i.test(v.name));

			const englishVoice =
				matchConfigured ||
				matchFemale ||
				englishVoices.find(
					(v) => v.name.includes("Google") || v.name.includes("Microsoft")
				) ||
				englishVoices[0] ||
				null;

			if (englishVoice) {
				utterance.voice = englishVoice;
			}

			const startTime = Date.now();
			let resolved = false;
			let keepAliveTimer = null;

			const done = (duration) => {
				if (resolved) return;
				resolved = true;
				if (keepAliveTimer) clearInterval(keepAliveTimer);
				resolve(duration);
			};

			utterance.onend = () => {
				done(Date.now() - startTime);
			};

			utterance.onerror = (event) => {
				if (event.error !== "canceled") {
					done(0);
					reject(event);
				} else {
					done(0);
				}
			};

			speechSynthesis.speak(utterance);

			keepAliveTimer = setInterval(() => {
				if (speechSynthesis.paused) {
					speechSynthesis.resume();
				} else if (!speechSynthesis.speaking) {
					done(Date.now() - startTime);
				}
			}, 10000);
		});
	},

    // ==========================================
    // UTILITY FUNCTIONS
    // ==========================================

    _playAudio: function (url) {
      return new Promise((resolve, reject) => {
        const audio = new Audio(url);
        this._currentAudio = audio;

        audio.onended = () => {
          this._currentAudio = null;
          resolve(audio.duration * 1000);
        };

        audio.onerror = reject;
        audio.play().catch(reject);
      });
    },

    _getAudioDuration: function (url) {
      return new Promise((resolve) => {
        const audio = new Audio(url);
        audio.onloadedmetadata = () => {
          resolve(audio.duration * 1000);
        };
        audio.onerror = () => resolve(this.estimateDuration(""));
      });
    },

    _base64ToBlob: function (base64, contentType) {
      const byteCharacters = atob(base64);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      return new Blob([byteArray], { type: contentType });
    },

    /**
     * Clear TTS cache
     */
    clearCache: function () {
      // Revoke blob URLs to free memory
      Object.values(this.cache).forEach((data) => {
        if (data.url && data.url.startsWith("blob:")) {
          URL.revokeObjectURL(data.url);
        }
      });
      this.cache = {};
    },
  };

  // Export to window
  window.MCQVS_TTSManager = MCQVS_TTSManager;
})(window);
