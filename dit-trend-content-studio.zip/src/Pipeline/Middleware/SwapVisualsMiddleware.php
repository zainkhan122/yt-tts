<?php

namespace DIT\TrendStudio\Pipeline\Middleware;

use DIT\TrendStudio\Contracts\MiddlewareInterface;
use DIT\TrendStudio\Content\ContentPipeline;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * SwapVisualsMiddleware
 *
 * Restores [VISUAL_N] tokens using the pipeline's logic.
 */
class SwapVisualsMiddleware implements MiddlewareInterface
{
    protected ContentPipeline $pipeline;

    public function __construct(ContentPipeline $pipeline)
    {
        $this->pipeline = $pipeline;
    }

    public function handle(array $data, array $context, callable $next): array
    {
        $input_data = $context['input_data'] ?? [];

        // Use the pipeline's high-precision swap logic (which now injects hints/ids)
        $data = $this->pipeline->swap_visual_tokens_back($data, $input_data);

        return $next($data);
    }
}
