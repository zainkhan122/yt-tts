<?php

declare(strict_types=1);

namespace DIT\TrendStudio\Tests\Fakes;

use DIT\TrendStudio\Contracts\AIProviderInterface;

final class FakeAIProvider implements AIProviderInterface
{
    private array $plainResponse;
    private array $researchResponse;
    private string $model;

    public array $calls = [];

    public function __construct(array $plainResponse = [], array $researchResponse = [], string $model = 'gemini-test')
    {
        $this->plainResponse = $plainResponse;
        $this->researchResponse = $researchResponse ?: $plainResponse;
        $this->model = $model;
    }

    public function get_model(): string
    {
        return $this->model;
    }

    public function generate(array $promptData): array
    {
        $this->calls[] = [
            'method' => 'generate',
            'promptData' => $promptData,
        ];

        return $this->plainResponse;
    }

    public function generateFromResearch(array $promptData, array $researchData): array
    {
        $this->calls[] = [
            'method' => 'generateFromResearch',
            'promptData' => $promptData,
            'researchData' => $researchData,
        ];

        return $this->researchResponse;
    }

    public function generateCustomJson(string $prompt): array
    {
        $this->calls[] = [
            'method' => 'generateCustomJson',
            'prompt' => $prompt,
        ];
        return [];
    }
}
