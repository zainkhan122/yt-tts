<?php

/**
 * Abstract Job Base Class
 *
 * @package SEO_Article_Generator
 * @MODIFIED 2026-03-02 v2.19.0: Industrial Queue Architecture
 */

namespace SEO_Article_Generator\Queue;

use SEO_Article_Generator\Utils\Plugin_Time;

// Prevent direct access
if (! defined('ABSPATH')) {
    exit;
}

/**
 * Base class for all queue jobs. Provides common infrastructure.
 */
abstract class Abstract_Job implements Job_Interface
{
    /**
     * @var int Reference ID.
     */
    protected $reference_id;

    /**
     * @var array Payload.
     */
    protected $payload;

    /**
     * @var int|null The industrial queue ticket ID.
     */
    protected $queue_job_id;

    /**
     * @var string|null The ownership token for the current reservation.
     */
    protected $reservation_token;

    /**
     * @param int         $reference_id     Reference ID.
     * @param array       $payload          Optional payload data.
     * @param int|null    $queue_job_id     Queue ID.
     * @param string|null $reservation_token Token.
     */
    public function __construct($reference_id, $payload = array(), $queue_job_id = null, $reservation_token = null)
    {
        $this->reference_id      = (int) $reference_id;
        $this->payload           = $payload;
        $this->queue_job_id      = $queue_job_id ? (int) $queue_job_id : null;
        $this->reservation_token = $reservation_token;
    }

    /**
     * Default failure handler — logs the error.
     *
     * @param \Throwable $e The exception.
     * @return void
     */
    public function failed(\Throwable $e)
    {
        error_log('[SEO Gen Queue] Job failed: ' . $e->getMessage());
    }

    /**
     * Helper: current MySQL timestamp.
     *
     * @return string
     */
    protected function now()
    {
        return Plugin_Time::utc_mysql_now();
    }
}
