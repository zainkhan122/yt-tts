<?php
/**
 * Registration Page Template
 * @version 2.2 - Hardened with XSS Prevention
 *
 * @MODIFIED: Added esc_url() to home_url() calls.
 */

if (!defined('ABSPATH')) exit;

get_header();
?>

<div class="nm-auth-wrapper">
    <div class="nm-auth-container">
        <div class="nm-auth-box">
            
            <div class="nm-auth-promo">
                <div class="nm-promo-content">
                    <h2>Why Join?</h2>
                    <p>Get the most out of your practice. Signing up is free and gives you access to powerful features.</p>
                    <ul class="nm-promo-benefits">
                        <li>
                            <span class="nm-icon">📊</span>
                            <div>
                                <strong>Track Your Progress</strong>
                                <span class="nm-desc">View your accuracy, see your history, and identify weak topics.</span>
                            </div>
                        </li>
                        <li>
                            <span class="nm-icon">🏆</span>
                            <div>
                                <strong>Earn Points & Badges</strong>
                                <span class="nm-desc">Climb the leaderboard and earn achievements for your knowledge.</span>
                            </div>
                        </li>
                        <li>
                            <span class="nm-icon">👥</span>
                            <div>
                                <strong>Join the Community</strong>
                                <span class="nm-desc">See how you rank against other learners in Pakistan and worldwide.</span>
                            </div>
                        </li>
                        </ul>
                </div>
            </div>

            <div class="nm-auth-form-container">
                <div class="nm-auth-header">
                    <h1>Create Account</h1>
                    <p>Join our community and start learning!</p>
                </div>

                <form id="nm-register-form" class="nm-auth-form">
                    <div class="nm-form-group">
                        <label for="username">Username</label>
                        <input type="text" id="username" name="username" required autofocus>
                        <small class="nm-form-hint">Letters, numbers, and underscores only</small>
                    </div>

                    <div class="nm-form-group">
                        <label for="email">Email Address</label>
                        <input type="email" id="email" name="email" required>
                    </div>

                    <div class="nm-form-group">
                        <label for="display_name">Display Name</label>
                        <input type="text" id="display_name" name="display_name">
                        <small class="nm-form-hint">This is how others will see you</small>
                    </div>

                    <div class="nm-form-group">
                        <label for="password">Password</label>
                        <div class="nm-password-field">
                            <input type="password" id="password" name="password" required>
                            <span class="nm-toggle-password">
                                <i class="fa fa-eye"></i>
                            </span>
                        </div>
                        <div class="nm-password-strength"></div>
                        <small class="nm-form-hint">At least 8 characters with uppercase, lowercase, number, and special character</small>
                    </div>

                    <div class="nm-form-group">
                        <label for="confirm_password">Confirm Password</label>
                        <input type="password" id="confirm_password" name="confirm_password" required>
                    </div>

                    <div class="nm-form-group">
                        <label class="nm-checkbox-label">
                            <input type="checkbox" name="terms" required>
                            <span>I agree to the <a href="<?php echo esc_url(home_url('/terms/')); ?>" target="_blank">Terms of Service</a> and <a href="<?php echo esc_url(home_url('/privacy/')); ?>" target="_blank">Privacy Policy</a></span>
                        </label>
                    </div>

                    <button type="submit" class="nm-btn nm-btn-primary nm-btn-block">Create Account</button>
                </form>
                
                <div class="nm-auth-footer">
                    <p>Already have an account? <a href="<?php echo esc_url(home_url('/mcq-login/')); ?>" class="nm-link-primary">Login</a></p>
                </div>
            </div>

        </div>
    </div>
</div>

<?php get_footer(); ?>