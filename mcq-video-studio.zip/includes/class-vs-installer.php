<?php

/**
 * Video Studio Installer
 *
 * Handles database table creation and updates.
 * Now uses centralized VS_Schema for all table definitions.
 *
 * @package MCQ_Video_Studio
 */

if (! defined('ABSPATH')) {
    exit;
}

class VS_Installer
{

 private static $instance = null;

 public static function init()
 {
 if (null === self::$instance) {
 self::$instance = new self();
 }
 return self::$instance;
 }

 public static function get_instance()
 {
 return self::init();
 }

 private function __construct()
 {}

 /**
 * Install all plugin tables.
 * Uses centralized schema from VS_Schema.
 */
 public static function install()
    {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    $tables = VS_Schema::get_tables_to_create();
    foreach ($tables as $table_name => $sql) {
        $table_fqn = $wpdb->prefix . $table_name;
        $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table_fqn));
        if ($exists === $table_fqn) {
            continue;
        }
        dbDelta($sql);
    }

        update_option('mcqvs_db_version', VS_Schema::VERSION);
    }

    /**
     * Create all tables (alias for install).
     * Called by repositories on init if tables don't exist.
     */
    public static function create_all_tables()
    {
        self::install();
    }

    /**
     * Auto-install render-service npm dependencies (canvas, ws) if missing.
     *
     * Runs on activation and on every init. If node_modules/canvas is absent
     * (e.g. after a plugin zip deploy that overwrote the VPS's node_modules),
     * this executes `npm install --omit=dev` in the render-service directory
     * so the headless renderer can find canvas without manual intervention.
     *
     * Guarded by a 24-hour transient to avoid re-running on every page load.
     * Only fires on Linux (the production target) — skipped on Windows/macOS
     * dev machines where native compilation may not be available.
     *
     * @since 1.4.9.2
     */
    public static function maybe_install_render_deps()
    {
        if (defined('DOING_AJAX') && DOING_AJAX) {
            return;
        }

        $rs_dir = MCQVS_PLUGIN_DIR . 'render-service';
        if (!is_dir($rs_dir)) {
            return;
        }

        // Quick filesystem check — canvas is only "ready" when its native binding
        // exists, and ffmpeg is only ready when either the system provides it or
        // the npm-provisioned ffmpeg-static binary exists. `node_modules/canvas`
        // existing is NOT enough: npm >= 12 blocks install scripts (node-pre-gyp)
        // unless the package is covered by the package.json `allowScripts` field,
        // so the folder appears but the prebuilt binary was never downloaded.
        if (self::deps_ready($rs_dir)) {
            return;
        }

        // Only run on Linux (production target). Skip on Windows/macOS dev machines.
        if (strtoupper(substr(PHP_OS, 0, 3)) !== 'LIN') {
            return;
        }

        // Guard: don't re-run within 24 hours (transient TTL).
        $lock_key = 'mcqvs_render_deps_install_lock';
        if (get_transient($lock_key)) {
            return;
        }
        set_transient($lock_key, time(), 86400);

        self::run_npm_install($rs_dir, true);

        if (self::deps_ready($rs_dir)) {
            delete_transient($lock_key);
        }
    }

    /**
     * @FIX 1.4.9.43 (self-sufficient): Force (re)install of the render-service npm
     * deps — used by the Settings > Headless "Setup Server Environment" button so
     * the whole stack (canvas, ffmpeg-static, ws) is provisioned from the admin UI
     * with no SSH. Bypasses the 24h lock.
     *
     * @return array { ok: bool, log: string }
     */
    public static function force_install_render_deps()
    {
        $rs_dir = MCQVS_PLUGIN_DIR . 'render-service';
        if (!is_dir($rs_dir)) {
            return array('ok' => false, 'log' => 'render-service directory missing: ' . $rs_dir);
        }
        return self::run_npm_install($rs_dir, false);
    }

    /**
     * Shared npm install logic for render-service.
     *
     * @param string $rs_dir      Absolute path to render-service/.
     * @param bool   $fast_heal   When true, skip when a system ffmpeg already exists
     *                            (load-time path only provisions what's missing).
     * @return array { ok: bool, log: string }
     */
    private static function run_npm_install($rs_dir, $fast_heal)
    {
        $log = '';

        // @FIX 1.4.9.44 (CRITICAL): Resolve HOW to run npm. `which npm` often
        // returns nothing under PHP's shell (web user) even though npm works in
        // the admin's SSH shell — nvm/nodenv installs only load in the user's
        // profile. So we never hard-abort on "npm not on PATH": we fall back to
        // the node binary's bundled npm (npm-cli.js), then to a login shell.
        $runner = self::resolve_npm_runner();
        if (empty($runner)) {
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log(
                    'Auto-install render deps skipped: no usable npm found.',
                    'error',
                    array('rs_dir' => $rs_dir)
                );
            }
            return array('ok' => false, 'log' => 'npm not found (checked PATH, node\'s bundled npm-cli.js, and login shell). Click "Setup Server Environment" — it provisions a portable Node and retries automatically.');
        }

        // @FIX 1.4.9.42: A stale/broken canvas must not survive. npm may treat an
        // existing node_modules/canvas as up-to-date and never run its install
        // script — and a 2.x canvas has NO prebuilt binary for Node >= 22 (ABI
        // 127), which is why this whole file ended up missing on Node 22 VPSes.
        // The packaged dependency is now canvas ^3.2.3 (N-API v7 prebuilds work
        // on every modern Node, no compile, no system deps). Remove the stale
        // folder + any lockfile so `npm install` resolves fresh 3.x.
        if (!self::canvas_ready($rs_dir)) {
            @shell_exec('rm -rf ' . escapeshellarg($rs_dir . '/node_modules/canvas') . ' ' . escapeshellarg($rs_dir . '/package-lock.json') . ' 2>&1');
        }

        $cmd = str_replace('{RS_DIR}', escapeshellarg($rs_dir), $runner['install']);
        $output = @shell_exec($cmd);
        $log .= trim((string) $output) . "\n";

        // npm >= 12 blocks install scripts unless `allowScripts` covers the package
        // (it now does, in render-service/package.json) — but if the package was
        // already present and npm skipped it as up-to-date, force node-pre-gyp via
        // `npm rebuild canvas` so the native binary actually gets built/downloaded.
        if (!self::canvas_ready($rs_dir)) {
            $rcmd = str_replace('{RS_DIR}', escapeshellarg($rs_dir), $runner['rebuild']);
            $output = @shell_exec($rcmd);
            $log .= trim((string) $output) . "\n";
        }

        $ok = self::deps_ready($rs_dir);

        if (class_exists('VS_Error_Logger')) {
            VS_Error_Logger::get_instance()->log(
                $ok ? 'Auto-installed render-service npm deps (canvas+ffmpeg-static+ws).' : 'Auto-install render-service npm deps failed.',
                $ok ? 'info' : 'error',
                array('npm_output' => trim($log), 'rs_dir' => $rs_dir)
            );
        }

        return array('ok' => $ok, 'log' => $log);
    }

    /**
     * @FIX 1.4.9.44 (CRITICAL): Build the npm invocation command(s), tolerant of
     * nvm/nodenv/custom installs where `npm` is NOT on PHP's PATH.
     *
     * Returns command templates with a {RS_DIR} placeholder, or an empty array.
     * Order of attempts:
     *  1. Plain `npm` on PATH (the common case).
     *  2. The node binary's bundled npm — `node <npm-cli.js> install`. Works for
     *     official node dists, nvm symlinks (readlink -f resolves them), and
     *     distro packages (Debian keeps npm-cli.js in /usr/share/nodejs).
     *  3. A login shell (`bash -lc`) that sources the user profile (nvm).
     *
     * @return array{install:string,rebuild:string}|array Empty when nothing found.
     */
    private static function resolve_npm_runner()
    {
        // 1) Plain npm on PATH.
        $npm = trim((string) @shell_exec('which npm 2>/dev/null'));
        if (!empty($npm) && @is_executable($npm)) {
            $n = '/usr/bin/env ' . escapeshellarg($npm);
            return array(
                'install' => 'cd {RS_DIR} && ' . $n . ' install --omit=dev 2>&1',
                'rebuild' => 'cd {RS_DIR} && ' . $n . ' rebuild canvas 2>&1',
            );
        }

        // 2) Node's bundled npm (npm-cli.js).
        $node = trim((string) @shell_exec('which node 2>/dev/null'));
        if (empty($node) || !@is_executable($node)) {
            $opt = function_exists('get_option') ? (string) get_option('mcqvs_node_path', '') : '';
            if (!empty($opt) && @is_executable($opt)) {
                $node = $opt;
            }
        }
        if (empty($node) || !@is_executable($node)) {
            // Portable node the plugin itself provisioned into uploads.
            $uploads = function_exists('wp_upload_dir') ? wp_upload_dir() : false;
            if (is_array($uploads) && !empty($uploads['basedir'])) {
                $found = glob(trailingslashit($uploads['basedir']) . 'mcq-video-studio/runtime/node-*/bin/node');
                if (is_array($found)) {
                    foreach ($found as $g) {
                        if (@is_executable($g)) { $node = $g; break; }
                    }
                }
            }
        }
        if (!empty($node) && @is_executable($node)) {
            $real = trim((string) @shell_exec('readlink -f ' . escapeshellarg($node) . ' 2>/dev/null'));
            if (!empty($real)) {
                $node = $real;
            }
            $dir = dirname($node);
            $clis = array(
                $dir . '/node_modules/npm/bin/npm-cli.js',
                dirname($dir) . '/lib/node_modules/npm/bin/npm-cli.js',
                dirname($dir) . '/node_modules/npm/bin/npm-cli.js',
                '/usr/share/nodejs/npm/bin/npm-cli.js',
            );
            foreach ($clis as $cli) {
                if (@is_file($cli)) {
                    $run = escapeshellarg($node) . ' ' . escapeshellarg($cli);
                    return array(
                        'install' => 'cd {RS_DIR} && ' . $run . ' install --omit=dev 2>&1',
                        'rebuild' => 'cd {RS_DIR} && ' . $run . ' rebuild canvas 2>&1',
                    );
                }
            }
        }

        // 3) Login shell (last resort — sources the user profile where nvm lives).
        if (@is_file('/bin/bash')) {
            return array(
                'install' => 'bash -lc "cd {RS_DIR} && npm install --omit=dev 2>&1"',
                'rebuild' => 'bash -lc "cd {RS_DIR} && npm rebuild canvas 2>&1"',
            );
        }

        return array();
    }

    /**
     * True when canvas is loadable AND ffmpeg is available (system or npm).
     *
     * @param string $rs_dir Absolute path to render-service/.
     * @return bool
     */
    private static function deps_ready($rs_dir)
    {
        if (!self::canvas_ready($rs_dir)) {
            return false;
        }
        // ffmpeg: either the npm-provisioned binary or a system one.
        if (file_exists($rs_dir . '/node_modules/ffmpeg-static/ffmpeg') && @is_executable($rs_dir . '/node_modules/ffmpeg-static/ffmpeg')) {
            return true;
        }
        $opt = function_exists('get_option') ? get_option('mcqvs_ffmpeg_path', '') : '';
        if (!empty($opt) && @is_executable($opt)) {
            return true;
        }
        foreach (array('/usr/bin/ffmpeg', '/usr/local/bin/ffmpeg') as $p) {
            if (@is_executable($p)) {
                return true;
            }
        }
        $which = trim((string) @shell_exec('which ffmpeg 2>/dev/null'));
        if (!empty($which) && @is_executable($which)) {
            return true;
        }
        return false;
    }

    /**
     * True only when canvas is actually loadable — module folder present AND the
     * native binding (built/downloaded by node-pre-gyp) exists.
     *
     * @param string $rs_dir Absolute path to render-service/.
     * @return bool
     */
    private static function canvas_ready($rs_dir)
    {
        return is_dir($rs_dir . '/node_modules/canvas')
            && file_exists($rs_dir . '/node_modules/canvas/build/Release/canvas.node');
    }

    /**
     * Drop all plugin tables (for testing/reset).
     */
    public static function uninstall()
    {
        // @FIX 1.4.9.41 (data-loss): This is a full-destroy utility (drops ALL
        // tables including vs_mcq_bank + deletes Content Planner data). Guard it
        // behind the same opt-in as the uninstall hook so nothing can ever invoke
        // it accidentally:
        //   define('MCQVS_PURGE_DATA_ON_UNINSTALL', true); // wp-config.php
        //   OR Settings > Data > "Delete all plugin data on uninstall" (default: KEEP).
        if (!(defined('MCQVS_PURGE_DATA_ON_UNINSTALL') && MCQVS_PURGE_DATA_ON_UNINSTALL)) {
            if (!function_exists('get_option') || !(bool) get_option('mcqvs_purge_data_on_uninstall', false)) {
                return;
            }
        }

        global $wpdb;
        $prefix = $wpdb->prefix;

        $tables = array(
            'vs_logs',
            'vs_topics',
            'vs_mcq_bank',
            'vs_exam_calendar',
            'vs_jobs',
            'vs_projects',
            'vs_project_questions'
        );

        foreach ($tables as $table) {
            $wpdb->query("DROP TABLE IF EXISTS {$prefix}{$table}");
        }

        delete_option('mcqvs_db_version');
        delete_option('mcqvs_db_enum_fix_136');
        delete_option('mcqvs_db_varchar_migration');
        delete_option('mcqvs_publish_columns_migration');
        delete_option('mcqvs_batch_tracker');
        delete_option('mcqvs_content_plan');
        delete_option('mcqvs_content_plan_pending_batches');
    }
}