/**
 * MCQ Video Studio - Preview Module
 *
 * Handles canvas rendering, animation loops, and preview state.
 *
 * @requires MCQVSLogger (studio.logger.js) [optional]
 * @requires MCQVS_TemplateManager (vs-template-manager.js) [required]
 *
 * @version 8.8.2
 * @since 2026-02-04
 */

(function (window) {
    'use strict';

    const Logger = window.MCQVSLogger || null;

    class PreviewManager {
        constructor(state, config) {
            this.state = state || {};
            this.config = config || {};

            this.canvas = null;
            this.ctx = null;

            this.animationFrame = null;
            this.isPlaying = false;

            this.currentTime = 0;
            this.startTimestamp = null;

            this._hasLoggedError = false;
            this._bgDrawableCache = new Map();    // key -> CanvasImageSource
            this._bgUrlCache = new Map();         // key -> objectURL (for Blob/File)
            this._bgImgCache = new Map();         // key -> HTMLImageElement

            if (Logger && Logger.info) Logger.info('PREVIEW_INIT');
        }


        /**
         * Preview question source-of-truth
         * - If state.selectedQuestions has items => preview renders ONLY those (in that order)
         * - Else => preview renders all state.questions
         * Returns ORIGINAL indices into state.questions
         */
        _getActiveQuestionIndices() {
            const qs = Array.isArray(this.state.questions) ? this.state.questions : [];
            const sel = Array.isArray(this.state.selectedQuestions) ? this.state.selectedQuestions : [];

            if (!sel.length) {
                return qs.map((_, i) => i);
            }

            const out = [];
            const seen = new Set();

            for (const v of sel) {
                const i = Number(v);
                if (!Number.isInteger(i)) continue;
                if (i < 0 || i >= qs.length) continue;
                if (seen.has(i)) continue;
                seen.add(i);
                out.push(i);
            }

            return out.length ? out : qs.map((_, i) => i);
        }

        initialize() {
            this.canvas = document.getElementById('previewCanvas');
            if (!this.canvas) {
                if (Logger && Logger.warn) Logger.warn('PREVIEW_CANVAS_MISSING');
                return;
            }

            this.ctx = this.canvas.getContext('2d', { alpha: false, desynchronized: true });

        this.canvas.width = (window.StudioController?.RESOLUTION?.width) || 1080;
        this.canvas.height = (window.StudioController?.RESOLUTION?.height) || 1920;

            if (Logger && Logger.info) {
                Logger.info('PREVIEW_CANVAS_READY', { width: this.canvas.width, height: this.canvas.height });
            }
        }

        start() {
            if (this.isPlaying) return;
            if (!this.ctx) this.initialize();
            if (!this.ctx) return;

            this.isPlaying = true;
            this.startTimestamp = performance.now();
            this.currentTime = 0;

            // Ensure template-driven bg video is running
            this._setBgVideoPlaying(true);

            this.animationFrame = requestAnimationFrame((ts) => this.render(ts));

            if (Logger && Logger.info) Logger.info('PREVIEW_START');
        }

        stop() {
            if (!this.isPlaying && !this.animationFrame) return;

            this.isPlaying = false;

            // Pause bg video so it doesn't keep running when preview is paused
            this._setBgVideoPlaying(false);

            if (this.animationFrame) {
                cancelAnimationFrame(this.animationFrame);
                this.animationFrame = null;
            }

            // Hard-stop bg video element created by TemplateManager
            this._destroyBgVideo();

            if (Logger && Logger.info) Logger.info('PREVIEW_STOP', { time: this.currentTime });
        }

        pause() {
            if (!this.isPlaying) return;

            this.isPlaying = false;
            if (this.animationFrame) {
                cancelAnimationFrame(this.animationFrame);
                this.animationFrame = null;
            }

            // @PATCH 2026-02-06: Pause background video deterministically
            this._setBgVideoPlaying(false);

            if (Logger && Logger.debug) Logger.debug('PREVIEW_PAUSE', { time: this.currentTime });
        }

        _setBgVideoPlaying(shouldPlay) {
            const host = this.state || {};
            const key = host.__templateHostKey || 'mcqvs_preview';

            const v =
                host.bgVideo ||
                (window.__MCQVS_BG_VIDEOS && window.__MCQVS_BG_VIDEOS[key]) ||
                (window.__MCQVS_BG_VIDEOS && window.__MCQVS_BG_VIDEOS.default) ||
                null;

            if (!v || !(v instanceof HTMLVideoElement)) return;

            if (shouldPlay) {
                try {
                    v.muted = true;
                    const p = v.play();
                    if (p && typeof p.catch === 'function') p.catch(() => { });
                } catch (_) { }
                return;
            }

            try { v.pause(); } catch (_) { }
        }



        _destroyBgVideo() {
            const v = this.state && this.state.bgVideo;
            if (!v || !(v instanceof HTMLVideoElement)) return;

            try { v.pause(); } catch (_) { }
            try { v.currentTime = 0; } catch (_) { }
            try { v.removeAttribute('src'); v.load(); } catch (_) { }

            try { this.state.bgVideo = null; } catch (_) { }
            try { this.state._bgVideoReady = false; } catch (_) { }
            try { this.state._bgVideoSrc = null; } catch (_) { }
        }

        resume() {
            if (this.isPlaying) return;
            if (!this.ctx) this.initialize();
            if (!this.ctx) return;

            this.isPlaying = true;
            this.startTimestamp = performance.now() - this.currentTime;

            // Ensure template-driven bg video is running
            this._setBgVideoPlaying(true);

            this.animationFrame = requestAnimationFrame((ts) => this.render(ts));

            if (Logger && Logger.debug) Logger.debug('PREVIEW_RESUME', { time: this.currentTime });
        }

        render(timestamp) {
            if (!this.isPlaying) return;

            this.currentTime = timestamp - (this.startTimestamp || timestamp);

            // @PATCH 2026-02-06: Stop exactly at end-of-timeline (prevents bg/video/audio continuing)
            const total = Number(this.getTotalDurationMs && this.getTotalDurationMs()) || 0;
            if (total > 0 && this.currentTime >= total) {
                this.currentTime = total;
                this.renderFrame(total);

                this._dispatchTransportEvent('ended', { time: total, total });

                this.stop();
                return;
            }

            this.renderFrame(this.currentTime);
            this.animationFrame = requestAnimationFrame((ts) => this.render(ts));
        }


        // ------------------------------
        // Helpers (branding parity)
        // ------------------------------

        normalizeLogoPosition(pos) {
            const p = String(pos || '').toLowerCase().trim();
            // legacy UI values -> engine values
            if (p === 'top-right' || p === 'top-left' || p === 'corner') return 'corner';
            if (p === 'outro') return 'outro';
            if (p === 'all' || p === '' || p === 'intro') return 'all';
            return 'all';
        }
        // @PATCH 2026-02-06: timeline total for deterministic end-stop
        getTotalDurationMs() {
            const t = (this.state && this.state.timing) ? this.state.timing : {};
            // @FIX 2026-08-11: hidden hook contributes no time (question starts immediately).
            const hook = (this.state && this.state.hookVisible === false) ? 0 : (Number(t.hookIntro) || 0);
            const qTotal = Number(t.questionTotal) || 0;
            const outro = Number(t.outroDuration) || 0;
            const active = this._getActiveQuestionIndices();
            return hook + (active.length * qTotal) + outro;
        }

        _dispatchTransportEvent(type, detail = {}) {
            try {
                document.dispatchEvent(new CustomEvent('mcqvs:preview:' + String(type || ''), { detail }));
            } catch (_) { }
        }

        computeSeed(templateId, quizName) {
            const str = String(templateId || '') + '|' + String(quizName || '');
            let h = 5381;
            for (let i = 0; i < str.length; i++) h = ((h << 5) + h) + str.charCodeAt(i);
            return (h >>> 0);
        }
        _isImageDataLike(v) {
            return !!v
                && typeof v === 'object'
                && typeof v.width === 'number'
                && typeof v.height === 'number'
                && v.data
                && (v.data instanceof Uint8ClampedArray);
        }

        _isLoadedHtmlImage(img) {
            return !!img && img.complete && img.naturalWidth > 0 && img.naturalHeight > 0;
        }

        _toDrawable(source, cacheKey) {
            if (!source) return null;

            // Already drawable
            if (typeof source === 'object') {
                if (source instanceof HTMLCanvasElement) return source;
                if (typeof OffscreenCanvas !== 'undefined' && source instanceof OffscreenCanvas) return source;
                if (source instanceof HTMLVideoElement) return source;
                if (typeof ImageBitmap !== 'undefined' && source instanceof ImageBitmap) return source;
                if (source instanceof HTMLImageElement) return this._isLoadedHtmlImage(source) ? source : null;

                // ImageData -> cache a canvas per frame
                if (this._isImageDataLike(source) || source instanceof ImageData) {
                    const key = `imagedata:${cacheKey}`;
                    if (this._bgDrawableCache.has(key)) return this._bgDrawableCache.get(key);

                    const c = document.createElement('canvas');
                    c.width = source.width;
                    c.height = source.height;
                    const cctx = c.getContext('2d', { alpha: false, desynchronized: true });
                    cctx.putImageData(source, 0, 0);

                    this._bgDrawableCache.set(key, c);
                    return c;
                }

                // Blob/File -> objectURL -> HTMLImageElement
                if (source instanceof Blob) {
                    const key = `blob:${cacheKey}`;
                    if (!this._bgUrlCache.has(key)) this._bgUrlCache.set(key, URL.createObjectURL(source));

                    const url = this._bgUrlCache.get(key);
                    return this._toDrawable(url, key);
                }
            }

            // dataURL / url string -> HTMLImageElement (cached)
            if (typeof source === 'string') {
                const key = `str:${cacheKey}:${source}`;
                if (!this._bgImgCache.has(key)) {
                    const img = new Image();
                    img.decoding = 'async';
                    img.src = source;
                    this._bgImgCache.set(key, img);
                }
                const img = this._bgImgCache.get(key);
                return this._isLoadedHtmlImage(img) ? img : null;
            }

            return null;
        }


        // ------------------------------
        // Render frame
        // ------------------------------

        renderFrame(timeMs) {
            if (!this.ctx) return;

            const tm = window.MCQVS_TemplateManager;
            if (!tm || typeof tm.getTemplate !== 'function') {
                this.ctx.fillStyle = '#000';
                this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
                this.ctx.fillStyle = '#f00';
                this.ctx.font = '40px sans-serif';
                this.ctx.fillText('Missing TemplateManager', 50, 100);
                return;
            }

            const templateId = this.state.templateId || 'trivia';
            const template = tm.getTemplate(templateId) || tm.getTemplate('trivia');
            if (!template || typeof template.render !== 'function') {
                this.ctx.fillStyle = '#000';
                this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
                this.ctx.fillStyle = '#f00';
                this.ctx.font = '36px sans-serif';
                this.ctx.fillText('Template missing or invalid: ' + String(templateId), 50, 120);
                return;
            }


            const phase = this.calculatePhase(timeMs);
            const renderState = this.buildRenderState(phase, timeMs);
            const assets = this.buildRenderAssets(timeMs);
            // --- PATCH: bridge assets.bgImage into state.bgImage (TemplateManager reads state.bgImage) ---
            if (assets && assets.bgImage) {
                renderState.bgImage = assets.bgImage;
            }

            try {
                template.render(this.ctx, renderState, assets);
            } catch (e) {
                if (Logger && Logger.error && !this._hasLoggedError) {
                    Logger.error('PREVIEW_RENDER_FAIL', e);
                    this._hasLoggedError = true;
                }

                // visible failure instead of silent blank
                this.ctx.fillStyle = '#000';
                this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
                this.ctx.fillStyle = '#f00';
                this.ctx.font = '36px sans-serif';
                this.ctx.fillText('Preview render failed (see console).', 50, 120);
            }

        }

        buildRenderState(phase, timeMs) {
            const s = this.state || {};
            const timing = s.timing || {};

            const templateId = s.templateId || 'trivia';
            const quizName = s.quizName || '';

            const state = {
                // timeline info
                elapsed: timeMs,              // global time 
                // @PATCH 2026-02-06: BG video persistence host for templates
                __templateHost: this.state,
                __templateHostKey: 'mcqvs_preview',
                // (background / video should NOT reset per scene)
                elapsedInScene: phase.time,   // per-scene time (timers/animations)
                time: timeMs,
                fps: 30,

                // background (TemplateManager.drawBackground expects these on STATE)
                bgImage: this.state?.bgImage || null,
                bgVideoFrames: Array.isArray(this.state?.bgVideoFrames) ? this.state.bgVideoFrames : null,
                bgVideoDataUrl: this.state?.bgVideoDataUrl || null,
                // template/config
                templateId,
                logoPosition: this.normalizeLogoPosition(s.logoPosition),

                // determinism
                seed: (typeof s.seed === 'number') ? s.seed : this.computeSeed(templateId, quizName),
                frameIndex: Math.floor((Number(timeMs) || 0) / (1000 / 30)),

                // branding/meta
                brandName: s.brandName || 'Quiz Master',
                quizName,
                // @NEW 2026-02-07: Preview font override
                fontOverride: s.fontOverride || null,
                brandColor: s.brandColor || '#FFD700',
                ctaText: s.ctaText || 'Thanks for watching!',
                computedCtaText: (s.computedCtaText || s.ctaText || ''),
                ctaPreset: s.ctaStyle || 'subscribe',
                useRankSystemCTA: !!s.useRankCta,
                websiteUrl: s.websiteUrl || '',

                // hook
                hookText: s.hookText || 'Hook Text',
                subHookText: s.subHookText || '',
                hookVisible: (s.hookVisible !== false),

                // extra (templates may rely)
                timing: timing,
                textEffects: s.textEffects || {},

                // backgrounds (TemplateManager drawBackground reads from STATE, not assets)
                bgImage: s.bgImage || null,
                bgVideoFrames: Array.isArray(s.bgVideoFrames) ? s.bgVideoFrames : null,

                // scene
                currentSceneId: phase.type,
                animationPhase: 'question',


                activeScene: { type: phase.type }
            };

            if (phase.type === 'hook') {
                state.currentSceneId = 'hook';
                state.activeScene = {
                    type: 'hook',
                    id: 'hook',
                    content: {
                        hookText: state.hookText,
                        subHookText: state.subHookText
                    }
                };
                return state;
            }

            if (phase.type === 'question') {
                const qIndex = Number.isInteger(phase.index) ? phase.index : 0;                 // ORIGINAL index in state.questions
                const selIndex = Number.isInteger(phase.selectionIndex) ? phase.selectionIndex : 0; // ORDER in preview timeline

                // IMPORTANT: templates usually expect contiguous q_1..q_n
                state.currentSceneId = 'q_' + (selIndex + 1);

                const qRaw = (s.questions && s.questions[qIndex]) ? s.questions[qIndex] : {};

                const qText = String(qRaw.question ?? qRaw.text ?? '').trim() || 'Question';

                const optRaw = Array.isArray(qRaw.options) ? qRaw.options : [];
                const options = (optRaw.length >= 2)
                    ? optRaw.map(v => String(v ?? '').trim())
                    : ['Option A', 'Option B', 'Option C', 'Option D'];

                let correct =
                    (typeof qRaw.correct === 'number') ? qRaw.correct :
                        (typeof qRaw.correctAnswer === 'number') ? qRaw.correctAnswer : 0;

                correct = parseInt(correct, 10);
                if (Number.isNaN(correct) || correct < 0 || correct > 3) correct = 0;

                state.activeScene = {
                    type: 'question',
                    id: state.currentSceneId,
                    index: qIndex,
                    selectionIndex: selIndex,
                    content: {

                        question: qText,
                        options,
                        correct
                    }
                };

        const introEnd = Number(timing.questionPhases?.intro || 1000);
        const revealDur = Number(timing.questionPhases?.reveal || 3000);
        const revealStart = (timing._revealStartRel !== undefined)
            ? timing._revealStartRel
            : Math.max(0, (timing.questionTotal || 12000) - revealDur);
        if (phase.time < introEnd) {
            state.animationPhase = 'question_intro';
        } else if (phase.time < revealStart) {
            state.animationPhase = 'question';
        } else {
            state.animationPhase = 'reveal';
        }

                return state;
            }

            if (phase.type === 'outro') {
                state.currentSceneId = 'outro';
                state.activeScene = {
                    type: 'outro',
                    id: 'outro',
                    content: {
                        ctaText: state.ctaText,
                        websiteUrl: state.websiteUrl,
                        quizName: state.quizName,
                        brandName: state.brandName
                    }
                };
                return state;
            }

            return state;
        }

        buildRenderAssets(timeMs) {
            const frames = Array.isArray(this.state?.bgVideoFrames) ? this.state.bgVideoFrames : null;

            // Default background (may be string/Blob/HTMLImageElement/etc)
            const fallbackBg = this._toDrawable(this.state?.bgImage || null, 'bgImage');

            // If video frames exist, drive bgImage from frames (loop)
        if (frames && frames.length) {
            const frameDuration = Number(this.state?.bgVideoFrameDur) > 0 ? Number(this.state.bgVideoFrameDur) : (1000 / 30);
            const idx = Math.floor((Math.max(0, Number(timeMs) || 0)) / frameDuration) % frames.length;

                const raw = frames[idx];
                const frameBg = this._toDrawable(raw, `bgFrame:${idx}`);

                return {
                    bgImage: frameBg || fallbackBg,
                    logoImage: this._toDrawable(this.state?.brandLogoImage || null, 'brandLogoImage')
                };
            }

            return {
                bgImage: fallbackBg,
                logoImage: this._toDrawable(this.state?.brandLogoImage || null, 'brandLogoImage')
            };
        }



        calculatePhase(timeMs) {
            const timing = this.state.timing || {};
            const hookDuration = timing.hookIntro || 2000;
            const questionDuration = timing.questionTotal || 12000;
            const outroDuration = timing.outroDuration || 5000;

            const qs = Array.isArray(this.state.questions) ? this.state.questions : [];
            const activeIdx = this._getActiveQuestionIndices();
            const numQuestions = activeIdx.length;

            if (timeMs < hookDuration) {
                return { type: 'hook', progress: hookDuration ? (timeMs / hookDuration) : 1, time: timeMs };
            }

            if (numQuestions === 0) {
                const outroTime0 = Math.max(0, timeMs - hookDuration);
                return { type: 'outro', progress: Math.min(1, outroDuration ? (outroTime0 / outroDuration) : 1), time: outroTime0 };
            }

            const questionsTotal = numQuestions * questionDuration;

            if (timeMs < hookDuration + questionsTotal) {
                const questionTime = timeMs - hookDuration;
                const selectionIndex = Math.min(numQuestions - 1, Math.floor(questionTime / questionDuration));
                const questionIndex = (activeIdx[selectionIndex] != null) ? activeIdx[selectionIndex] : selectionIndex;
                const within = questionTime % questionDuration;
                return {
                    type: 'question',
                    index: questionIndex,
                    selectionIndex: selectionIndex,
                    progress: questionDuration ? (within / questionDuration) : 1,
                    time: within
                };
            }

            const outroTime = timeMs - hookDuration - questionsTotal;
            return {
                type: 'outro',
                progress: Math.min(1, outroDuration ? (outroTime / outroDuration) : 1),
                time: outroTime
            };
        }

        destroy() {
            this.stop();
            this.canvas = null;
            this.ctx = null;
            if (Logger && Logger.info) Logger.info('PREVIEW_DESTROY');
        }
    }

    window.MCQVS_PreviewManager = PreviewManager;

})(window);
