<?php

/**
 * Perplexity AI Client
 *
 * @package DIT_TrendStudio
 * @MODIFIED 2025-12-13 - NEW FILE: Perplexity API integration for research/fact-gathering
 * @MODIFIED 2026-02-12 - Unify writing prompt/schema via PromptSchemaBuilder + HARD GATE empty-body
 */

namespace DIT\TrendStudio\Content;

use DIT\TrendStudio\AI_Exception;
use DIT\TrendStudio\Infrastructure\Logger;
use DIT\TrendStudio\Infrastructure\AI_Network_Trait;
use DIT\TrendStudio\Infrastructure\API_Error_Parser;
use DIT\TrendStudio\Infrastructure\Quota_State_Manager;
use DIT\TrendStudio\Infrastructure\Backoff_Strategy;
use DIT\TrendStudio\Contracts\AIProviderInterface;
use DIT\TrendStudio\Security\Sanitizer;
use DIT\TrendStudio\Content\PromptSchemaBuilder;
use DIT\TrendStudio\Content\VisualManifestService;
use DIT\TrendStudio\AI\StructuredOutputSchema;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Perplexity API client for real-time web research + writing
 *
 * Uses the Sonar model which has built-in web search capabilities
 * and returns citations for factual grounding.
 * 
 * @MODIFIED 2026-02-13 - Implements AIProviderInterface for PromptEngine compatibility
 */
class Perplexity_Client implements AIProviderInterface
{
    use AI_Network_Trait;

    /**
     * Perplexity API URL (OpenAI-compatible format)
     */
    const API_URL = 'https://api.perplexity.ai/chat/completions';

    /**
     * Model to use - sonar has web search built-in
     */
    const MODEL = 'sonar';

    /**
     * Provider-agnostic prompt/schema builder
     * @var PromptSchemaBuilder
     */
    private $promptSchema;

    /**
     * Deterministic visuals token service
     * @var VisualManifestService
     */
    private $visuals;

    /**
     * Get Perplexity API key from multiple sources
     */
    public static function get_api_key(): string
    {
        $key = get_option('dit_ts_perplexity_api_key', '');
        if (!empty($key)) {
            return $key;
        }

        $env_key = getenv('PERPLEXITY_API_KEY');
        if (!empty($env_key)) {
            return $env_key;
        }

        if (defined('PERPLEXITY_API_KEY')) {
            return \PERPLEXITY_API_KEY;
        }

        return '';
    }

    /**
     * Constructor
     */
    public function __construct(string $api_key, Logger $logger)
    {
        $this->api_key       = $api_key;
        $this->logger        = $logger;
        $this->provider_slug = 'perplexity'; // @MODIFIED 2026-02-14 - Identify for global retries

        $this->promptSchema = new PromptSchemaBuilder($logger);
        $this->visuals      = new VisualManifestService();
    }

    /**
     * Get the name of the model being used by this provider.
     *
     * @return string
     */
    public function get_model(): string
    {
        return self::MODEL;
    }

    /**
     * Research a topic using Perplexity's web search capabilities
     *
     * @throws AI_Exception
     */
    public function research(array $prompt_data): array
    {
        \DIT\TrendStudio\Infrastructure\Usage_Tracker::increment('perplexity');
        $this->logger->info('Starting Perplexity research', [
            'topic' => $prompt_data['idea_title'] ?? 'Unknown',
        ]);

        // Defensive logging for empty topic detection
        $topic = (string)($prompt_data['idea_title'] ?? '');
        $this->logger->info('Perplexity research topic extraction', [
            'idea_title'        => $topic,
            'idea_title_length' => strlen($topic),
            'has_idea_text'     => !empty($prompt_data['idea_text']),
            'prompt_data_keys'  => array_keys($prompt_data),
        ]);

        if ($topic === '' || strlen($topic) < 10) {
            $this->logger->error('Topic is empty or too short. Cannot proceed with research.', [
                'idea_title'        => $topic,
                'idea_title_length' => strlen($topic),
                'prompt_data'       => $prompt_data,
            ]);
            throw new AI_Exception('Topic too short for research (minimum 10 characters required)');
        }

        $prompt = $this->build_research_prompt($prompt_data);

        $body = [
            'model' => self::MODEL,
            'messages' => [
                [
                    'role' => 'system',
                    'content' => 'You are an investigative journalist focused on finding hidden truths, user sentiment, and real-world experiences. Go beyond surface-level facts to uncover what real users are saying on forums like Reddit and Quora. Look for controversies, complaints, and authentic anecdotes. Report findings with attribution but anonymize individual users.',
                ],
                [
                    'role' => 'user',
                    'content' => $prompt,
                ],
            ],
            'max_tokens' => 32768,
            'temperature' => 0.2,
            'return_citations' => true,
            'return_related_questions' => false,
        ];

        $apiKey = trim($this->api_key);
        if ($apiKey === '') {
            throw new AI_Exception('Perplexity API key missing (perplexity_api_key).');
        }

        try {
            // @MODIFIED 2026-02-14 - Use global retry trait for stability
            $response = $this->call_api_with_retry(self::API_URL, [
                'headers' => [
                    'Authorization' => 'Bearer ' . $apiKey,
                    'Content-Type'  => 'application/json',
                    'Accept'        => 'application/json',
                    'User-Agent'    => 'Mozilla/5.0 (WordPress; DIT_TrendStudio) AppleWebKit/537.36 (KHTML, like Gecko)',
                ],
                'body'    => wp_json_encode($body),
            ]);

            if (is_wp_error($response)) {
                $err_msg = $response->get_error_message();
                throw new AI_Exception('Perplexity API request failed: ' . $err_msg);
            }

            $code     = wp_remote_retrieve_response_code($response);
            $body_raw = wp_remote_retrieve_body($response);

            // WAF/Auth Check: Perplexity should NEVER return HTML
            $bodyTrim = ltrim((string)$body_raw);
            if ($bodyTrim !== '' && $bodyTrim[0] === '<') {
                throw new AI_Exception('Perplexity returned HTML (likely auth/WAF blocked).');
            }

            if ($code === 429) {
                // @MODIFIED 2026-04-23 - Three-Layer Intelligence with class_exists guards
                $error_info = ['error_type' => 'rpm_burst', 'quota_bucket' => 'rpm', 'retry_delay' => 0, 'is_quota_zero' => false];
                if (class_exists(API_Error_Parser::class) && class_exists(Quota_State_Manager::class)) {
                    $headers = \wp_remote_retrieve_headers($response);
                    $error_info = API_Error_Parser::parse('perplexity', $code, $body_raw, (array) $headers);
                    Quota_State_Manager::calibrate_from_error('perplexity', $error_info);
                }
                $reason = class_exists(Backoff_Strategy::class) ? Backoff_Strategy::get_reason($error_info) : 'rate_limit_retry';
                throw new AI_Exception('Perplexity rate limit exceeded', array(
                    'reason' => $reason,
                    'provider' => 'perplexity',
                    'error_class' => $error_info['error_type'],
                    'quota_bucket' => $error_info['quota_bucket'],
                    'api_retry_delay' => (int) ($error_info['retry_delay'] ?? 0),
                    'retry_after' => (int) ($error_info['retry_delay'] ?? 0),
                    'http_code' => $code,
                    'error_body' => substr($body_raw, 0, 500),
                ));
            }

            if ($code !== 200) {
                $this->logger->error('Perplexity API error', ['code' => $code, 'body' => $body_raw]);
                throw new AI_Exception("Perplexity API returned {$code}: " . substr((string)$body_raw, 0, 500));
            }

            // @MODIFIED 2026-04-23 - Three-Layer Intelligence: record success with guard
            if (class_exists(Quota_State_Manager::class)) {
                Quota_State_Manager::record_success('perplexity', self::MODEL);
            }

            $data = json_decode($body_raw, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new AI_Exception('Failed to parse Perplexity response: ' . json_last_error_msg());
            }

            return $this->parse_research_response($data);
        } catch (\Throwable $e) {
            // Cooldown to stop hammering on repeated auth/WAF failures (10 mins)
            set_transient('trendsstudio_perplexity_down', time(), 10 * MINUTE_IN_SECONDS);
            throw $e;
        }
    }

    /**
     * Build research prompt for Perplexity
     */
    private function build_research_prompt(array $prompt_data): string
    {
        $idea_title  = (string)($prompt_data['idea_title'] ?? '');
        $idea_text   = (string)($prompt_data['idea_text'] ?? '');
        $source_urls = (string)($prompt_data['source_urls'] ?? '');
        // @MODIFIED 2026-02-13 - Add URL research for Pakistani verticals
        $vertical = (string)($prompt_data['vertical'] ?? 'general');
        $url_instruction = $this->get_url_research_instruction($vertical);

        return <<<PROMPT
Research the following topic with the mindset of an INVESTIGATIVE JOURNALIST.
Your goal is not just to find facts, but to finding the "Missing Information" that marketing glosses over.

## TOPIC
{$idea_title}
{$idea_text}

## REFERENCE URLs
{$source_urls}
{$url_instruction}

## CRITICAL RESEARCH DIRECTIVES
You must perform these distinct "mental searches" to gather a complete picture:

0.  **PRIORITY CHECK**:
    - The "TOPIC" content above is the SOURCE OF TRUTH.
    - If external search results conflict with the specific details in the TOPIC (e.g., a different person, date, or event), YOU MUST TRUST THE "TOPIC" DATA.
    - Do NOT drift to "related" or "viral" topics just because they share keywords. Stick to the specific story in the TOPIC.

1.  **THE "FACTS" SEARCH**:
    - Find the latest technical specs, verified dates, and core features.
    - Source: Official documentation, news outlets.
    - **Look for original images/videos**: Note if there are specific viral videos or images mentioned in the topic, and find their context.

2.  **THE "REDDIT/FORUM" SEARCH (site:reddit.com "complaints" OR "issues")**:
    - FIND NEGATIVES. This is critical. What are real users hating?
    - look for patterns like "It broke after a week" or "Customer service is ghosting me".
    - identifying specific subreddit discussions.

3.  **THE "EXPERT/ACADEMIC" SEARCH (site:.edu OR site:scholar.google.com)**:
    - What is the deep technical or sociological context?
    - Are there studies or whitepapers debunking common myths about this?

4.  **THE "COMPETITOR" SEARCH**:
    - Who is doing this better? Who is cheaper?

## REQUIRED OUTPUT FORMAT
You must rigorously structure your findings into these sections which will be parsed by our system:

**FACTS:**
[Bulleted list of verified hard content facts, dates, prices, and specs.]

**USER_SENTIMENT:**
[Summary of the "Reddit/Forum" findings. Be explicit about negatives. Use phrases like "Users frequently complain about..." or "Consensus is mixed regarding..."]

**CONTROVERSIES:**
[What are the active debates? e.g. "Experts disagree on whether X is healthy..."]

**ANECDOTES:**
[Find at least 3 specific user stories. e.g. "A Reddit user claimed that..."]

**QUOTES:**
[3+ direct, punchy quotes from users or experts. Anonymize if needed.]

**SOURCES:**
[List of citations]
PROMPT;
    }

    /**
     * Get URL research instruction for Pakistani verticals
     * 
     * @MODIFIED 2026-02-13 - NEW METHOD: Independent URL research per provider
     * @param string $vertical Content vertical
     * @return string URL research instruction or empty
     */
    private function get_url_research_instruction(string $vertical): string
    {
        if ($vertical === 'showbiz_pk') {
            return <<<'INSTRUCTION'

## OFFICIAL SOCIAL MEDIA VERIFICATION (SHOWBIZ)
Find the official Instagram account of the lead celebrity mentioned in the TOPIC.

VERIFICATION CRITERIA:
1. Must be verified (blue checkmark) OR have 100K+ followers
2. Must be active (posted within last 3 months)
3. Must match celebrity's actual identity

OUTPUT FORMAT: Add section **VERIFIED_URLS:**
- Instagram: https://instagram.com/[handle] (Verified: Yes/No, Followers: XXk)

If not found: 
- Instagram: NOT_FOUND (Reason: [explain])
INSTRUCTION;
        }

        if ($vertical === 'fashion_pk') {
            return <<<'INSTRUCTION'

## OFFICIAL BRAND LINKS VERIFICATION (FASHION)
Find the official website and Instagram of the fashion brand mentioned in the TOPIC.

VERIFICATION CRITERIA:
Website:
1. Must be brand's official e-commerce or landing page
2. Must be active and functional
3. Must match brand name in TOPIC

Instagram:
1. Must be verified OR have 10K+ followers
2. Must be active (posted within last month)
3. Must match brand's identity

OUTPUT FORMAT: Add section **VERIFIED_URLS:**
- Website: https://brandname.com
- Instagram: https://instagram.com/brandname (Verified: Yes/No)

If not found:
- Website: NOT_FOUND (Reason: [explain])
- Instagram: NOT_FOUND (Reason: [explain])

DO NOT HALLUCINATE. If unsure, mark NOT_FOUND.
INSTRUCTION;
        }

        return '';
    }

    /**
     * Parse Perplexity research response
     *
     * Returns both legacy `research_content` + segmented fields:
     * facts, user_sentiment, controversies, anecdotes, quotes.
     *
     * @throws AI_Exception
     */
    private function parse_research_response(array $data): array
    {
        $content   = (string)($data['choices'][0]['message']['content'] ?? '');
        $citations = $data['citations'] ?? [];

        if ($content === '') {
            throw new AI_Exception('Empty research response from Perplexity');
        }

        // Normalize citations
        $sources = [];
        foreach ($citations as $citation) {
            if (is_string($citation)) {
                $sources[] = [
                    'url'   => $citation,
                    'label' => $this->extract_domain($citation),
                ];
            } elseif (is_array($citation) && isset($citation['url'])) {
                $sources[] = [
                    'url'   => (string)$citation['url'],
                    'label' => (string)($citation['title'] ?? $this->extract_domain((string)$citation['url'])),
                ];
            }
        }

        $seg = $this->parse_segmented_research($content);
        // @MODIFIED 2026-02-13 - Extract verified URLs from research
        $verified_urls = $this->extract_verified_urls($content);

        $this->logger->info('Perplexity research completed', [
            'content_length' => strlen($content),
            'sources_count'  => count($sources),
        ]);

        return [
            'research_content' => $content,
            'facts'            => $seg['facts'],
            'user_sentiment'   => $seg['user_sentiment'],
            'controversies'    => $seg['controversies'],
            'anecdotes'        => $seg['anecdotes'],
            'quotes'           => $seg['quotes'],
            'verified_urls'    => $verified_urls, // @MODIFIED 2026-02-13
            'sources'          => $sources,
            'model'            => self::MODEL,
            'provider'         => 'perplexity',
        ];
    }

    /**
     * Parse the REQUIRED OUTPUT FORMAT sections from Perplexity research content.
     * Safe fallback: returns empty strings if sections not found.
     */
    private function parse_segmented_research(string $content): array
    {
        $out = [
            'facts'          => '',
            'user_sentiment' => '',
            'controversies'  => '',
            'anecdotes'      => '',
            'quotes'         => '',
        ];

        $map = [
            'facts'          => 'FACTS',
            'user_sentiment' => 'USER_SENTIMENT',
            'controversies'  => 'CONTROVERSIES',
            'anecdotes'      => 'ANECDOTES',
            'quotes'         => 'QUOTES',
        ];

        foreach ($map as $k => $label) {
            $out[$k] = $this->extract_section($content, $label);
        }

        return $out;
    }

    /**
     * Extract section body between **LABEL:** and next **XYZ:** block.
     */
    private function extract_section(string $content, string $label): string
    {
        $pattern = '/\*\*' . preg_quote($label, '/') . ':\*\*\s*(.*?)(?=\n\s*\*\*[A-Z_]+:\*\*|\z)/s';
        if (preg_match($pattern, $content, $m)) {
            return trim((string)$m[1]);
        }
        return '';
    }

    /**
     * Extract verified URLs from research content
     * 
     * @MODIFIED 2026-02-13 - NEW METHOD: Parse VERIFIED_URLS section
     * @param string $content Research response
     * @return array ['website' => string|null, 'instagram' => string|null]
     */
    private function extract_verified_urls(string $content): array
    {
        $urls = ['website' => null, 'instagram' => null];

        $verified_section = $this->extract_section($content, 'VERIFIED_URLS');
        if ($verified_section === '') {
            return $urls;
        }

        // Parse Website
        if (preg_match('/^-\s*Website:\s*(https?:\/\/[^\s]+)/m', $verified_section, $m)) {
            $url = trim($m[1]);
            if (stripos($url, 'NOT_FOUND') === false) {
                $urls['website'] = $url;
            }
        }

        // Parse Instagram
        if (preg_match('/^-\s*Instagram:\s*(https?:\/\/[^\s]+)/m', $verified_section, $m)) {
            $url = trim($m[1]);
            if (stripos($url, 'NOT_FOUND') === false) {
                $urls['instagram'] = $url;
            }
        }

        return $urls;
    }

    /**
     * Extract domain from URL for label
     */
    private function extract_domain(string $url): string
    {
        $parsed = wp_parse_url($url);
        $host   = $parsed['host'] ?? $url;
        return preg_replace('/^www\./', '', (string)$host);
    }

    /**
     * Test API connection
     *
     * @throws AI_Exception
     */
    public function test_connection(): array
    {
        $body = [
            'model' => self::MODEL,
            'messages' => [
                [
                    'role' => 'user',
                    'content' => 'Hello, respond with just "OK" to confirm connection.',
                ],
            ],
            'max_tokens' => 10,
        ];

        // @MODIFIED 2026-02-14 - Use global retry logic
        $response = $this->call_api_with_retry(self::API_URL, [
            'headers' => [
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type'  => 'application/json',
            ],
            'body'    => wp_json_encode($body),
        ]);

        if (is_wp_error($response)) {
            throw new AI_Exception('Connection failed: ' . $response->get_error_message());
        }

        $code = wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            throw new AI_Exception('API returned error code: ' . $code);
        }

        return [
            'status'   => 'connected',
            'provider' => 'perplexity',
            'model'    => self::MODEL,
        ];
    }

    /**
     * Generate a full article using Perplexity (writing)
     *
     * @throws AI_Exception
     */
    public function generate_article(array $prompt_data, array $research_data): array
    {
        \DIT\TrendStudio\Infrastructure\Usage_Tracker::increment('perplexity');
        $this->logger->info('Starting Perplexity article generation');

        // Build unified prompt/schema (same canonical JSON structure as Gemini/OpenRouter)
        $bundle = $this->build_writing_bundle($prompt_data, $research_data);

        $system_prompt = $bundle['system_prompt'];
        $user_prompt   = $bundle['user_prompt'];

        // IMPORTANT: we keep Perplexity payload simple; schema enforcement happens in prompt + hard gate.
        $body = [
            'model' => self::MODEL,
            'messages' => [
                ['role' => 'system', 'content' => $system_prompt],
                ['role' => 'user',   'content' => $user_prompt],
            ],
            'max_tokens'   => 32768,
            'temperature'  => 0.5,
            'top_p'        => 0.9,
        ];

        // @MODIFIED 2026-02-17 - Phase 4: Enforce structured output via json_schema if enabled
        $enforce = (bool) get_option('dit_ts_ai_enforce_structured_output', true);
        if ($enforce && !empty($bundle['output_schema'])) {
            $mode = StructuredOutputSchema::detect_mode_from_output_schema((string) $bundle['output_schema']);
            $body['response_format'] = array(
                'type'       => 'json_schema',
                'json_schema' => array(
                    'name'   => 'trendstudioArticle',
                    'schema' => StructuredOutputSchema::json_schema_article($mode),
                ),
            );
        }

        $apiKey = trim($this->api_key);
        if ($apiKey === '') {
            throw new AI_Exception('Perplexity API key missing (perplexity_api_key).');
        }

        // @MODIFIED 2026-02-14 - Use global retry trait
        $response = $this->call_api_with_retry(self::API_URL, [
            'headers' => [
                'Authorization' => 'Bearer ' . $apiKey,
                'Content-Type'  => 'application/json',
                'Accept'        => 'application/json',
            ],
            'body'    => wp_json_encode($body),
        ], 3); // Generation allows 3 retries (higher cost/wait acceptable)

        if (is_wp_error($response)) {
            $err_msg = $response->get_error_message();
            throw new AI_Exception('Perplexity generation failed: ' . $err_msg);
        }

        $code     = wp_remote_retrieve_response_code($response);
        $body_raw = wp_remote_retrieve_body($response);

        // WAF/Auth Check: Perplexity should NEVER return HTML
        $bodyTrim = ltrim((string)$body_raw);
        if ($bodyTrim !== '' && $bodyTrim[0] === '<') {
            throw new AI_Exception('Perplexity returned HTML (likely auth/WAF blocked).');
        }

if ($code === 429) {
            // @MODIFIED 2026-04-23 - Three-Layer Intelligence with class_exists guards
            $error_info = ['error_type' => 'rpm_burst', 'quota_bucket' => 'rpm', 'retry_delay' => 0, 'is_quota_zero' => false];
            if (class_exists(API_Error_Parser::class) && class_exists(Quota_State_Manager::class)) {
                $headers = \wp_remote_retrieve_headers($response);
                $error_info = API_Error_Parser::parse('perplexity', $code, $body_raw, (array) $headers);
                Quota_State_Manager::calibrate_from_error('perplexity', $error_info);
            }
            $reason = class_exists(Backoff_Strategy::class) ? Backoff_Strategy::get_reason($error_info) : 'rate_limit_retry';
            throw new AI_Exception('Perplexity rate limit exceeded', array(
                'reason' => $reason,
                'provider' => 'perplexity',
                'error_class' => $error_info['error_type'],
                'quota_bucket' => $error_info['quota_bucket'],
                'api_retry_delay' => (int) ($error_info['retry_delay'] ?? 0),
                'retry_after' => (int) ($error_info['retry_delay'] ?? 0),
                'http_code' => $code,
                'error_body' => substr($body_raw, 0, 500),
            ));
        }

        // @MODIFIED 2026-04-23 - Three-Layer Intelligence: record success with guard
        if (class_exists(Quota_State_Manager::class)) {
            Quota_State_Manager::record_success('perplexity', self::MODEL);
        }

        if ($code !== 200) {
            // @MODIFIED 2026-02-17 - Phase 4.1.1: Fallback if Perplexity rejects response_format/json_schema.
            if (!empty($body['response_format']) && $this->is_response_format_rejection($code, (string) $body_raw)) {
                $this->logger->warning('Perplexity rejected response_format; retrying without schema enforcement.', [
                    'code' => $code,
                    'preview' => substr((string) $body_raw, 0, 300),
                ]);

                unset($body['response_format']);

                $response = $this->call_api_with_retry(self::API_URL, [
                    'headers' => [
                        'Authorization' => 'Bearer ' . $apiKey,
                        'Content-Type'  => 'application/json',
                        'Accept'        => 'application/json',
                    ],
                    'body'    => wp_json_encode($body),
                ], 1);

                if (is_wp_error($response)) {
                    throw new AI_Exception('Perplexity fallback failed: ' . $response->get_error_message());
                }

                $code     = wp_remote_retrieve_response_code($response);
                $body_raw = wp_remote_retrieve_body($response);
            }

            if ($code !== 200) {
                throw new AI_Exception("Perplexity API returned {$code}: " . substr((string)$body_raw, 0, 800));
            }
        }

        $data    = json_decode($body_raw, true);
        $content = (string)($data['choices'][0]['message']['content'] ?? '');

        if ($content === '') {
            throw new AI_Exception('Perplexity returned empty writing content');
        }

        // @MODIFIED 2026-02-17 - Phase 4: Use specialized parser with auto-repair
        $content = preg_replace('/^```(?:json)?\s*|\s*```$/i', '', trim($content));

        $article_data = $this->parse_article_json(
            $content,
            (string) ($bundle['output_schema'] ?? ''),
            (int) get_option('dit_ts_ai_json_repair_attempts', 1),
            (string) $system_prompt
        );

        // Expand VISUAL tokens back into final HTML ONLY for legacy non-tokenized flows.
        if (empty($prompt_data['source_visual_map']) && !empty($bundle['visual_manifest'])) {
            $article_data = $this->visuals->apply($article_data, (array) $bundle['visual_manifest']);
        }

        // Normalize to canonical schema
        $article_data = $this->normalize_article_response($article_data, $research_data, $prompt_data);

        // HARD GATE: stop “images-only” publishes (fail job => no publish)
        // @MODIFIED 2026-02-12 - Use central PromptSchemaBuilder gate
        $this->promptSchema->assert_non_empty_article($article_data);

        return $article_data;
    }

    /**
     * Generate content (AIProviderInterface implementation)
     * 
     * Delegates to research + article generation flow.
     * 
     * @MODIFIED 2026-02-13 - NEW: Interface method for PromptEngine compatibility
     * @param array $promptData Structured prompt data
     * @return array Generated article data
     * @throws AI_Exception
     */
    public function generate(array $promptData): array
    {
        // For Perplexity, always do research first, then write
        $research = $this->research($promptData);
        return $this->generate_article($promptData, $research);
    }

    /**
     * Generate content from research data (AIProviderInterface implementation)
     * 
     * @MODIFIED 2026-02-13 - NEW: Interface method for PromptEngine compatibility
     * @param array $promptData Structured prompt data
     * @param array $researchData Research data to use
     * @return array Generated article data
     * @throws AI_Exception
     */
    public function generateFromResearch(array $promptData, array $researchData): array
    {
        // Directly use existing article generation with provided research
        return $this->generate_article($promptData, $researchData);
    }

    /**
     * Generate custom JSON (AIProviderInterface implementation)
     * 
     * @MODIFIED 2026-02-13 - NEW: Interface method for PromptEngine compatibility
     * @param string $prompt Custom prompt text
     * @return array Parsed JSON response
     * @throws AI_Exception
     */
    public function generateCustomJson(string $prompt): array
    {
        \DIT\TrendStudio\Infrastructure\Usage_Tracker::increment('perplexity');

        $body = [
            'model' => self::MODEL,
            'messages' => [
                [
                    'role' => 'system',
                    'content' => 'You are a helpful AI assistant. You MUST respond with valid JSON only.',
                ],
                [
                    'role' => 'user',
                    'content' => $prompt,
                ],
            ],
            'max_tokens' => 32768,
            'temperature' => 0.3,
        ];

        $apiKey = trim($this->api_key);
        if ($apiKey === '') {
            throw new AI_Exception('Perplexity API key missing (perplexity_api_key).');
        }

        // @MODIFIED 2026-02-14 - Use global retry trait
        $response = $this->call_api_with_retry(self::API_URL, [
            'headers' => [
                'Authorization' => 'Bearer ' . $apiKey,
                'Content-Type'  => 'application/json',
                'Accept'        => 'application/json',
            ],
            'body'    => wp_json_encode($body),
        ]);

        if (is_wp_error($response)) {
            throw new AI_Exception('Perplexity custom JSON failed: ' . $response->get_error_message());
        }

        $code = wp_remote_retrieve_response_code($response);
        $body_raw = wp_remote_retrieve_body($response);

        if ($code !== 200) {
            throw new AI_Exception("Perplexity API returned {$code}: " . substr((string)$body_raw, 0, 500));
        }

        $data = json_decode($body_raw, true);
        $content = (string)($data['choices'][0]['message']['content'] ?? '');

        if ($content === '') {
            throw new AI_Exception('Empty response from Perplexity custom JSON call');
        }

        // Strip code fences if present
        $content = preg_replace('/^```json\s*|\s*```$/', '', trim($content));

        $parsed = json_decode($content, true);
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($parsed)) {
            throw new AI_Exception('Failed to parse Perplexity custom JSON: ' . json_last_error_msg());
        }

        return $parsed;
    }

    /**
     * Unified writing prompt builder: delegates to PromptSchemaBuilder
     * 
     * @MODIFIED 2026-02-12 - Align with new PromptSchemaBuilder architecture
     */
    private function build_writing_bundle(array $prompt_data, array $research_data): array
    {
        $visual_manifest = [];
        $output_schema   = '';

        // @MODIFIED 2026-02-17 - Phase 4.1.1: Fix arg signature (6 params only).
        return $this->promptSchema->build_perplexity_writing_bundle(
            $prompt_data,
            $research_data,
            $visual_manifest,
            $output_schema,
            null, // Pipeline is authoritative; do not re-tokenize here.
            0
        );
    }

    /**
     * Check if Perplexity rejected the response format or schema.
     * 
     * @param int $code
     * @param string $body
     * @return bool
     */
    public function is_response_format_rejection(int $code, string $body): bool
    {
        if ($code !== 400 && $code !== 422) {
            return false;
        }

        $body = strtolower($body);
        return strpos($body, 'response_format') !== false ||
            strpos($body, 'json_schema') !== false ||
            strpos($body, 'schema') !== false;
    }

    /**
     * Normalize Perplexity output to canonical TrendStudio article schema expected by formatter/publisher.
     */
    private function normalize_article_response(array $article, array $research_data, array $prompt_data): array
    {
        // Back-compat mappings
        if (!isset($article['headline']) && isset($article['title'])) {
            $article['headline'] = (string)$article['title'];
        }

        $article['headline']          = (string)($article['headline'] ?? 'Untitled');
        $article['dek']               = (string)($article['dek'] ?? '');
        $article['category']          = (string)($article['category'] ?? (string)($prompt_data['category'] ?? ''));
        $article['vertical']          = (string)($article['vertical'] ?? (string)($prompt_data['vertical'] ?? ($research_data['vertical'] ?? '')));
        $article['meta_description']  = (string)($article['meta_description'] ?? '');
        $article['tags']              = (isset($article['tags']) && is_array($article['tags'])) ? $article['tags'] : [];
        $article['sources']           = (isset($article['sources']) && is_array($article['sources'])) ? $article['sources'] : [];
        $article['internal_links']    = (isset($article['internal_links']) && is_array($article['internal_links'])) ? $article['internal_links'] : [];
        $article['content_blocks']    = (isset($article['content_blocks']) && is_array($article['content_blocks'])) ? $article['content_blocks'] : [];
        $article['source_snippets']   = (isset($article['source_snippets']) && is_array($article['source_snippets'])) ? $article['source_snippets'] : [];

        // Merge sources from research if missing/empty
        if (empty($article['sources']) && !empty($research_data['sources']) && is_array($research_data['sources'])) {
            $article['sources'] = $research_data['sources'];
        }

        // Normalize sections
        if (!isset($article['sections']) || !is_array($article['sections'])) {
            $article['sections'] = [];
        } else {
            foreach ($article['sections'] as $i => $s) {
                if (!is_array($s)) {
                    continue;
                }
                if (!isset($article['sections'][$i]['bodyhtml'])) {
                    $article['sections'][$i]['bodyhtml'] =
                        (string)($s['body_html'] ?? $s['body'] ?? $s['content'] ?? '');
                }
                if (!isset($article['sections'][$i]['heading']) || trim((string)$article['sections'][$i]['heading']) === '') {
                    $article['sections'][$i]['heading'] = 'Story';
                }
                if (!isset($article['sections'][$i]['verification_status']) || trim((string)$article['sections'][$i]['verification_status']) === '') {
                    $article['sections'][$i]['verification_status'] = 'UNVERIFIED';
                }
            }
        }

        return $article;
    }

    /**
     * @MODIFIED 2026-02-17 - Phase 4: Use Sanitizer + optional AI repair pass; supports response_format json_schema.
     */
    private function parse_article_json(string $raw, string $output_schema, int $max_repairs, string $system_prompt): array
    {
        $parsed = Sanitizer::parse($raw);
        if (is_array($parsed)) {
            return $parsed;
        }

        $this->logger->warning('Perplexity JSON parse failed; attempting repair', array(
            'error'   => Sanitizer::get_last_error(),
            'preview' => substr($raw, 0, 1200),
        ));

        if ($max_repairs <= 0) {
            throw new AI_Exception('Failed to parse Perplexity JSON response: ' . Sanitizer::get_last_error());
        }

        $mode   = StructuredOutputSchema::detect_mode_from_output_schema($output_schema);
        $schema = StructuredOutputSchema::json_schema_article($mode);

        $repair_prompt = "You are a strict JSON repair bot. Return VALID JSON ONLY.\n\n"
            . "Original constraints (for structure/tone only; do not output):\n" . $system_prompt . "\n\n"
            . "You MUST match this JSON schema:\n" . wp_json_encode($schema) . "\n\n"
            . "Here is the invalid output:\n" . $raw . "\n\n"
            . "Return ONLY the corrected JSON object. No markdown fences. No commentary.";

        for ($i = 0; $i < $max_repairs; $i++) {
            try {
                $fixed = $this->generateCustomJsonWithSchema($repair_prompt, $schema);
            } catch (\Throwable $e) {
                $this->logger->warning('Perplexity JSON repair call failed', array(
                    'attempt' => $i + 1,
                    'error'   => $e->getMessage(),
                ));
                continue;
            }

            if (is_array($fixed) && !empty($fixed)) {
                return $fixed;
            }
        }

        throw new AI_Exception('Failed to parse/repair Perplexity JSON response after repair attempts.');
    }

    /**
     * Custom JSON generation with explicit response_format json_schema.
     *
     * @MODIFIED 2026-02-17 - Phase 4: hard schema enforcement for repair path.
     */
    private function generateCustomJsonWithSchema(string $prompt, array $schema): array
    {
        $apiKey = trim($this->api_key);
        if ($apiKey === '') {
            throw new AI_Exception('Perplexity API key missing (perplexity_api_key).');
        }

        $body = array(
            'model'    => self::MODEL,
            'messages' => array(
                array('role' => 'system', 'content' => 'Return VALID JSON ONLY. No markdown. No commentary.'),
                array('role' => 'user',   'content' => $prompt),
            ),
            'max_tokens'  => 32768,
            'temperature' => 0.2,
            'top_p'       => 0.9,
            'response_format' => array(
                'type'       => 'json_schema',
                'json_schema' => array(
                    'name'   => 'trendstudioArticle',
                    'schema' => $schema,
                ),
            ),
        );

        $response = $this->call_api_with_retry(self::API_URL, array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $apiKey,
                'Content-Type'  => 'application/json',
                'Accept'        => 'application/json',
            ),
            'body' => wp_json_encode($body),
        ), 2);

        if (is_wp_error($response)) {
            throw new AI_Exception('Perplexity JSON repair request failed: ' . $response->get_error_message());
        }

        $code = wp_remote_retrieve_response_code($response);
        $raw  = wp_remote_retrieve_body($response);

        if ($code !== 200) {
            throw new AI_Exception('Perplexity repair API returned ' . $code . ': ' . substr((string) $raw, 0, 800));
        }

        $data    = json_decode($raw, true);
        $content = (string) ($data['choices'][0]['message']['content'] ?? '');
        if ($content === '') {
            throw new AI_Exception('Perplexity repair returned empty content');
        }

        $parsed = Sanitizer::parse($content);
        if (!is_array($parsed)) {
            throw new AI_Exception('Perplexity repair output not parseable: ' . Sanitizer::get_last_error());
        }

        return $parsed;
    }
}
