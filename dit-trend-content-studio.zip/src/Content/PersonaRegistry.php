<?php

namespace DIT\TrendStudio\Content;

use DIT\TrendStudio\Content\Personas\FashionPkPersona;
use DIT\TrendStudio\Content\Personas\LifestylePkPersona;
use DIT\TrendStudio\Content\Personas\PersonaInterface;
use DIT\TrendStudio\Content\Personas\ShowbizPkPersona;

/**
 * Persona registry for vertical-specific prompt blueprint overrides.
 *
 * Replaces ad-hoc vertical conditionals with an extensible provider registry.
 * Third parties (or future internal modules) can register personas via the
 * `dit_ts_personas` filter.
 *
 * @package DIT_TrendStudio\Content
 * @since 2.15.4
 */
class PersonaRegistry
{
    /**
     * Return a vertical-specific blueprint override (if registered).
     *
     * @param string $vertical             Vertical key.
     * @param string $global_restrictions  Guardrails injected globally by AI_Style_Guard.
     * @return array|null
     */
    public static function get_blueprint_override(string $vertical, string $global_restrictions): ?array
    {
        $personas = array(
            new FashionPkPersona(),
            new ShowbizPkPersona(),
            new LifestylePkPersona(),
        );

        /**
         * Filter registered personas.
         *
         * @param array  $personas Array of PersonaInterface implementations.
         * @param string $vertical  Current vertical.
         */
        $personas = apply_filters('dit_ts_personas', $personas, $vertical);
        if (!is_array($personas)) {
            $personas = array();
        }

        foreach ($personas as $persona) {
            if (!($persona instanceof PersonaInterface)) {
                continue;
            }

            if ($persona->get_vertical() !== $vertical) {
                continue;
            }

            $blueprint = $persona->get_blueprint($global_restrictions);
            if (is_array($blueprint) && !empty($blueprint)) {
                return $blueprint;
            }
        }

        return null;
    }
}
