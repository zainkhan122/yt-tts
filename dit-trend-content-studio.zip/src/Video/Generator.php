<?php
/**
 * DIT Video Module — Generator
 *
 * Orchestrates one video production for a qualified post:
 *   1. gather images (featured + attached, best quality first)
 *   2. generate script + YouTube metadata (AI via DIT, or fallback)
 *   3. write narration + manifest to a work dir
 *   4. run the Node/Python renderer (TTS + overlays + ffmpeg) -> final.mp4
 *   5. attach the video to the post, set _dit_ts_video_id (so DIT's existing
 *      Buffer share uploads it to YouTube), and set YT SEO meta
 *   6. log every step via DIT's Logger
 *
 * Fully optional: every failure is caught and logged; never throws up the stack.
 *
 * @package DIT\TrendStudio\Video
 */

namespace DIT\TrendStudio\Video;

use DIT\TrendStudio\Infrastructure\Logger;

if (!defined('ABSPATH')) {
    exit;
}

class Generator
{
    /** @var Settings */
    protected $settings;

    /** @var Logger */
    protected $logger;

    public function __construct(Settings $settings, Logger $logger)
    {
        $this->settings = $settings;
        $this->logger   = $logger;
    }

    /**
     * Generate a video for a post. Returns array{ok, video_id, log}.
     */
    public function generate_for_post(int $post_id): array
    {
        $log = array();
        if (!$this->settings->is_active()) {
            return array('ok' => false, 'log' => array('Video module disabled or runner missing.'));
        }

        $post = get_post($post_id);
        if (!$post || 'post' !== $post->post_type) {
            return array('ok' => false, 'log' => array("Post {$post_id} not found or not a 'post'."));
        }

        try {
            // 1) Images
            $this->logger->info("DIT Video: gathering images for post {$post_id}");
            $images = $this->gather_images($post_id);
            $log[] = 'images: ' . count($images);
            if (count($images) < 1) {
                $this->logger->warning("DIT Video: post {$post_id} has no usable images; skipping.");
                return array('ok' => false, 'log' => array_merge($log, array('No usable images.')));
            }

            // 2) Post context + metadata
            $urdu_heading = trim(wp_strip_all_tags((string) get_post_meta($post_id, '_dit_ts_urdu_heading', true)));
            if ($urdu_heading === '') {
                $urdu_heading = trim(wp_strip_all_tags((string) get_post_meta($post_id, '_dit_ts_urdu_description', true)));
            }
            if ($urdu_heading === '') {
                $urdu_heading = $post->post_title;
            }

            $post_ctx = array(
                'id'           => $post_id,
                'title'        => $post->post_title,
                'content'      => $post->post_content,
                'urdu_heading' => $urdu_heading,
                'categories'   => $this->post_categories($post_id),
            );
            // Detect short-form video embeds (IG Reel / YT Short / TikTok) that are
            // already short clips — these can be dropped in as video scenes.
            $short_clips = $this->detect_short_clips($post_id);

            // Build ordered image manifest WITH per-image context parsed from the
            // structured post format: "Name of Dress / Dress description / image".
            $image_manifest = $this->image_manifest($images);
            $this->attach_image_context($image_manifest, $post->post_content);

            $this->logger->info("DIT Video: generating script for post {$post_id} (" . count($image_manifest) . ' images, ' . count($short_clips) . ' short clips)');
            $ai = new Script_AI($this->logger);
            $meta = $ai->generate($post_ctx, $image_manifest);
            $log[] = 'scenes: ' . count($meta['scene_scripts']);
            $log[] = 'yt_title: ' . mb_substr($meta['youtube_title'], 0, 60);

            // 3) Work dir + files
            $workdir = $this->workdir($post_id);
            // narration.txt = opening + all scene scripts joined (single flowing VO),
            // plus scene_scripts[] kept in the manifest for per-scene TTS.
            $narration = trim((string) ($meta['opening_line'] ?? '') . ' ' . implode(' ', (array) $meta['scene_scripts']));
            $this->writetext($workdir . '/narration.txt', $narration);
            $manifest = $this->build_manifest($post_id, $workdir, $image_manifest, $urdu_heading, $meta, $short_clips);
            $this->writetext($workdir . '/manifest.json', wp_json_encode($manifest, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
            $log[] = 'workdir: ' . $workdir;

            // 4) Run renderer
            $this->logger->info("DIT Video: rendering post {$post_id}");
            $render = $this->run_runner($workdir . '/manifest.json', $workdir);
            if (!$render['ok']) {
                $this->logger->error("DIT Video: render failed for post {$post_id}: " . $render['error']);
                return array('ok' => false, 'log' => array_merge($log, array('render_failed: ' . $render['error'])));
            }
            $video_path = $render['path'];
            $log[] = 'render: ' . basename($video_path) . ' (' . round(filesize($video_path) / 1048576, 1) . 'MB)';

            // 5) Attach + meta
            $video_id = $this->attach_video($post_id, $video_path, $meta);
            if (!$video_id) {
                return array('ok' => false, 'log' => array_merge($log, array('attach_video failed')));
            }
            update_post_meta($post_id, '_dit_ts_video_id', $video_id);
            update_post_meta($post_id, '_dit_ts_video_ready', '1');
            update_post_meta($post_id, '_dit_ts_video_generated_at', gmdate('c'));
            // YouTube SEO meta (used by DIT Buffer share for YouTube).
            update_post_meta($post_id, '_dit_ts_urdu_heading', $urdu_heading);
            update_post_meta($post_id, '_dit_ts_urdu_description', $meta['youtube_description']);
            update_post_meta($post_id, '_dit_ts_hashtags', $meta['hashtags']);
            update_post_meta($post_id, '_dit_ts_youtube_title', $meta['youtube_title']);

            $log[] = 'video_attached: #' . $video_id;
            $this->logger->info("DIT Video: completed post {$post_id}, video #{$video_id}");

            // Allow integrations (e.g. publish video post) to react.
            do_action('dit_ts_video_generated', $post_id, $video_id, $meta);

            return array('ok' => true, 'video_id' => $video_id, 'log' => $log);
        } catch (\Throwable $e) {
            $this->logger->error('DIT Video: generation failed for post ' . $post_id . ': ' . $e->getMessage());
            return array('ok' => false, 'log' => array_merge($log, array('exception: ' . $e->getMessage())));
        }
    }

    /**
     * Gather images: featured image first, then child image attachments.
     * Filters out broken/small images; keeps quality order.
     */
    protected function gather_images(int $post_id): array
    {
        $ids = array();

        $featured = (int) get_post_thumbnail_id($post_id);
        if ($featured) {
            $ids[] = $featured;
        }

        $children = get_children(array(
            'post_parent' => $post_id,
            'post_type'   => 'attachment',
            'post_mime_type' => 'image',
            'orderby'     => 'menu_order ID',
            'order'       => 'ASC',
            'fields'      => 'ids',
        ));
        foreach ((array) $children as $id) {
            $ids[] = (int) $id;
        }
        $ids = array_values(array_unique(array_filter($ids)));

        $images = array();
        foreach ($ids as $id) {
            $file = get_attached_file($id);
            if (!$file || !file_exists($file)) {
                continue;
            }
            $size = @filesize($file);
            if ($size && $size < 2000) {
                continue; // broken/tiny
            }
            $images[] = array('id' => $id, 'path' => $file);
        }

        // Sort by resolution descending (quality-first) — matches DIT's rating.
        usort($images, function ($a, $b) {
            $wa = $this->width($a['path']);
            $wb = $this->width($b['path']);
            return $wb <=> $wa;
        });

        return array_slice($images, 0, 12);
    }

    private function width(string $path): int
    {
        $s = @getimagesize($path);
        return $s ? (int) $s[0] : 0;
    }

    private function height(string $path): int
    {
        $s = @getimagesize($path);
        return $s ? (int) $s[1] : 0;
    }

    /**
     * Ordered image manifest with orientation, passed to both the AI and renderer.
     */
    protected function image_manifest(array $images): array
    {
        $out = array();
        foreach ($images as $img) {
            $w = $this->width($img['path']);
            $h = $this->height($img['path']);
            $out[] = array(
                'path'        => $img['path'],
                'id'          => $img['id'],
                'width'       => $w,
                'height'      => $h,
                'orientation' => ($w && $h) ? ($w >= $h ? 'landscape' : 'portrait') : 'unknown',
                'context'     => '',
            );
        }
        return $out;
    }

    private function post_categories(int $post_id): string
    {
        $cats = wp_get_post_categories($post_id, array('fields' => 'names'));
        return is_array($cats) ? implode(', ', $cats) : '';
    }

    /**
     * Attach per-image context to the manifest by parsing the structured post body.
     *
     * DIT posts are written as repeated blocks of:
     *   <h3>Name of Dress / Heading</h3>
     *   <p>description of the dress / item ...</p>
     *   <img ... image of the dress ...>
     *
     * We scan the HTML body for these [heading, paragraph, image] clusters in
     * order and assign the nearest preceding text as the image's context. Images
     * without a preceding cluster get an empty/fallback context. This gives the
     * AI real per-image descriptions without needing a vision model.
     *
     * @param array $manifest  reference to the ordered image manifest
     * @param string $content  raw post_content (HTML)
     */
    protected function attach_image_context(array &$manifest, string $content): void
    {
        if (empty($manifest)) {
            return;
        }

        // Regex to find each image element (any <img ...> or block <figure> with an img).
        // Captures everything between consecutive images so we can grab the nearest
        // heading + paragraph text preceding each image.
        $imgRe = '/<(?:img|figure)[^>]*?(?:wp-image-(\d+))?[^>]*>/i';

        // Split content by image boundaries.
        $parts = preg_split($imgRe, $content, -1, PREG_SPLIT_OFFSET_CAPTURE);

        // Collect image positions in original order.
        $positions = array();
        if (preg_match_all($imgRe, $content, $m, PREG_OFFSET_CAPTURE)) {
            foreach ($m[0] as $match) {
                $positions[] = $match[1];
            }
        }

        // For each image in the manifest (in order), find the text cluster that
        // appears immediately before it in the source and extract its text.
        $mIdx = 0;
        $manifest_count = count($manifest);
        for ($i = 0; $i < count($positions) && $mIdx < $manifest_count; $i++) {
            $imgStart = $positions[$i];
            $before = substr($content, 0, $imgStart);
            // The text right before this image = cluster context.
            $ctx = $this->text_before_image($before);
            if ($ctx === '') {
                continue; // skip empty context images, keep manifest order
            }
            // Assign to the next manifest image.
            $manifest[$mIdx]['context'] = $ctx;
            $mIdx++;
        }
    }

    /**
     * Extract readable text (headings + paragraphs) from the HTML immediately
     * preceding an image, stopping at a large gap.
     */
    protected function text_before_image(string $before): string
    {
        // Take only the tail (last ~2000 chars) to avoid unrelated earlier text.
        $tail = mb_substr($before, -2000);
        // Extract headings and paragraphs.
        $blocks = array();
        if (preg_match_all('/<(h[1-6]|p)[^>]*>(.*?)<\/\1>/is', $tail, $m)) {
            foreach ($m[2] as $block) {
                $text = trim(wp_strip_all_tags(html_entity_decode($block)));
                $text = preg_replace('/\s+/', ' ', $text);
                if ($text !== '') {
                    $blocks[] = $text;
                }
            }
        }
        // Reverse so the closest block to the image comes first, then take up to 2.
        $blocks = array_slice(array_reverse($blocks), 0, 2);
        return trim(implode(' — ', $blocks));
    }

    /**
     * Detect SHORT-FORM video embeds that can be dropped in as scenes:
     *   - Instagram Reels, YouTube Shorts, TikTok (already short clips).
     * Long-form YouTube videos are deliberately EXCLUDED (too long to crop
     * blindly; those are handled via the image/transcript path instead).
     */
    protected function detect_short_clips(int $post_id): array
    {
        $content = get_post_field('post_content', $post_id);
        $clips   = array();
        if (preg_match_all(
            '#https?://(?:www\.)?(?:instagram\.com/(?:reel|reels)/[A-Za-z0-9_-]+|youtube\.com/shorts/[A-Za-z0-9_-]+|tiktok\.com/\S*?/video/\d+)[^\s"\'<>]*#i',
            $content,
            $m
        )) {
            foreach (array_unique($m[0]) as $u) {
                $clips[] = array('url' => trim($u, " \t\n\r\0\x0B"), 'kind' => 'short');
            }
        }
        return $clips;
    }

    /**
     * Build the manifest.json the runner consumes.
     */
    protected function build_manifest(int $post_id, string $workdir, array $images, string $urdu_heading, array $meta, array $short_clips = array()): array
    {
        $brand = new Brand();
        return array(
            'job_id'   => $post_id,
            'workdir'  => $workdir,
            'images'   => array_map(function ($img) {
                return $img['path'];
            }, $images),
            // Per-image context (parsed from "Name/description/image" structure).
            'image_context' => array_map(function ($img) {
                return isset($img['context']) ? $img['context'] : '';
            }, $images),
            // Short-form video clips (IG Reel / YT Short / TikTok) to use as scenes.
            'short_clips' => array_values($short_clips),
            // Per-scene scripts aligned to images (index i -> image i).
            'scene_scripts' => isset($meta['scene_scripts']) ? array_values((array) $meta['scene_scripts']) : array(),
            'opening_line'  => (string) ($meta['opening_line'] ?? ''),
            'closing_line'  => (string) ($meta['closing_line'] ?? ''),
            'narration' => trim((string) ($meta['opening_line'] ?? '') . ' ' . implode(' ', (array) ($meta['scene_scripts'] ?? array()))),
            'heading'  => $urdu_heading,
            'brand'    => array(
                'name'       => $brand->brand_text(),
                'logo'       => $brand->logo_path(),
                'urdu_font'  => $brand->urdu_font_path(),
                'latin_font' => $brand->latin_font_path(),
            ),
            'heading_font_size' => $this->settings->get_int('heading_font_size', 64),
            'max_duration'      => $this->settings->get_int('max_duration', 60),
            'use_black_bars'    => (bool) $this->settings->get_bool('use_black_bars', true),
            'tts'     => array(
                'backend' => (string) $this->settings->get('tts_backend', 'edge'),
                'voice'   => (string) $this->settings->get('tts_voice', 'ur-PK-UzmaNeural'),
                'speed'   => (string) $this->settings->get('tts_speed', '1.15'),
                'lang'    => 'ur-PK',
            ),
            'video'   => array(
                'width'  => $this->settings->get_int('width', 1080),
                'height' => $this->settings->get_int('height', 1920),
                'fps'    => $this->settings->get_int('fps', 30),
            ),
            'env'     => array(
                'node'    => $this->bin('node'),
                'npm'     => $this->bin('npm'),
                'python'  => $this->bin('python3'),
                'ffmpeg'  => $this->bin('ffmpeg'),
                'ffprobe' => $this->bin('ffprobe'),
                'php'     => PHP_BINARY,
            ),
        );
    }

    private function bin(string $name): string
    {
        $out = array();
        // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec
        @exec('command -v ' . escapeshellarg($name) . ' 2>/dev/null', $out, $code);
        return (0 === $code && !empty($out)) ? trim($out[0]) : $name;
    }

    /**
     * Run `node render.mjs manifest.json` in the runner dir.
     */
    protected function run_runner(string $manifest_path, string $workdir): array
    {
        $runner = $this->settings->runner_dir();
        $script = $runner . '/render.mjs';
        if (!is_file($script)) {
            return array('ok' => false, 'error' => 'render.mjs not found in ' . $runner);
        }
        $node = $this->bin('node');

        $cmd = sprintf(
            'cd %s && %s %s %s > %s 2>&1',
            escapeshellarg($runner),
            escapeshellarg($node),
            escapeshellarg($script),
            escapeshellarg($manifest_path),
            escapeshellarg($workdir . '/render.log')
        );
        // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec
        @exec($cmd, $out, $code);

        $final = $workdir . '/final.mp4';
        if (0 !== $code || !is_file($final)) {
            $logtxt = is_readable($workdir . '/render.log') ? file_get_contents($workdir . '/render.log') : '';
            return array('ok' => false, 'error' => 'render exited ' . $code . ': ' . substr($logtxt, -400));
        }
        return array('ok' => true, 'path' => $final);
    }

    /**
     * Insert the final MP4 as a media attachment on the post.
     */
    protected function attach_video(int $post_id, string $video_path, array $meta): int
    {
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $file_type = wp_check_filetype($video_path, array('mp4' => 'video/mp4'));
        $attachment = array(
            'post_mime_type' => $file_type['type'] ? $file_type['type'] : 'video/mp4',
            'post_title'     => !empty($meta['youtube_title']) ? $meta['youtube_title'] : 'Video for post ' . $post_id,
            'post_content'   => '',
            'post_status'    => 'inherit',
            'post_parent'    => $post_id,
        );

        $attach_id = wp_insert_attachment($attachment, $video_path, $post_id);
        if (!$attach_id) {
            return 0;
        }
        update_post_meta($attach_id, '_dit_ts_video_owned', '1');
        $meta_data = wp_generate_attachment_metadata($attach_id, $video_path);
        if (is_array($meta_data)) {
            wp_update_attachment_metadata($attach_id, $meta_data);
        }
        return (int) $attach_id;
    }

    private function workdir(int $post_id): string
    {
        $base = WP_CONTENT_DIR . '/dit-video/' . $post_id;
        if (!is_dir($base)) {
            wp_mkdir_p($base);
        }
        return untrailingslashit($base);
    }

    private function writetext(string $path, string $content): void
    {
        // phpcs:ignore WordPress.WP.AlternativeFunctions
        @file_put_contents($path, $content);
    }
}
