<?php

/**
 * Truth Enforcement Layer - Hallucination Detection & Validation
 *
 * @package SEO_Article_Generator
 * @since   2.1.2
 */

namespace SEO_Article_Generator\Validation;

use SEO_Article_Generator\Traits\Type_Safety;

class Truth_Validator
{
    use Type_Safety;

    /**
     * Domain Policy is now the specific Single Source of Truth
     */

    /**
     * Allowed redirect status codes
     */
    private const VALID_REDIRECTS = [301, 302, 307, 308];

    /**
     * Validation severity levels
     */
    private const SEVERITY_PASS = 'pass';
    private const SEVERITY_WARNING = 'warning';
    private const SEVERITY_ERROR = 'error';
    private const SEVERITY_CRITICAL = 'critical';

    /**
     * Main validation entry point
     *
     * @param array $input_data  Original user/scraper input
     * @param array $ai_output   Generated content from AI
     * @return array Validation result with issues and suggested actions
     */
    public function validate_truthfulness($input_data, $ai_output)
    {
        $issues = [];
		$mode = 'blog';

        // 1. Version validation
        $version_check = $this->validate_version(
            $input_data['tech_specs']['version'] ?? null,
            $ai_output['tech_specs']['version'] ?? null,
            $input_data['scraped_version'] ?? null
        );
        if ($version_check['severity'] !== self::SEVERITY_PASS) {
            $issues[] = $version_check;
        }

        // 2. Download URL validation — @MODIFIED 2026-05-20: Skipped.
        // AI no longer generates download_section. System builds download_section from canonical links.
        // Download link validation happens at the source (discovery/resolver), not against AI output.

        // 3. File size sanity check
        if (isset($ai_output['download']['file_size'], $input_data['download']['file_size'])) {
            $size_check = $this->validate_file_size(
                $input_data['download']['file_size'],
                $ai_output['download']['file_size']
            );
            if ($size_check['severity'] !== self::SEVERITY_PASS) {
                $issues[] = $size_check;
            }
        }

        // 4. System requirements hallucination check
        $sysreq_check = $this->validate_system_requirements(
            $ai_output['system_requirements'] ?? []
        );
        if ($sysreq_check['severity'] !== self::SEVERITY_PASS) {
            $issues[] = $sysreq_check;
        }

        // 5. Safety badge honesty check
        $safety_check = $this->validate_safety_claims(
            $ai_output['safety'] ?? [],
            $input_data['safety'] ?? []
        );
        if ($safety_check['severity'] !== self::SEVERITY_PASS) {
            $issues[] = $safety_check;
        }

        return [
            'valid'       => empty(array_filter($issues, fn($i) => $i['severity'] === self::SEVERITY_CRITICAL)),
            'issues'      => $issues,
            'action'      => $this->determine_action($issues),
            'can_publish' => $this->can_auto_publish($issues),
			'grounding' => [
				'changelog_url' => $input_data['changelog_url'] ?? ($input_data['changelogurl'] ?? null),
				'homepage_url' => $input_data['homepage_url'] ?? ($ai_output['tech_specs']['homepage'] ?? null),
			],
        ];
    }

    /**
     * Version Validation
     *
     * Critical: User provided explicit version, AI returned different version
     * Warning: Scraped version differs from AI version
     * Pass: Versions match or no version provided
     */
    private function validate_version($user_version, $ai_version, $scraped_version)
    {
        $ai_version = self::as_string($ai_version);
        $user_version = self::as_string($user_version);
        $scraped_version = self::as_string($scraped_version);

        // No version to validate
        if (empty($ai_version)) {
            return [
                'field'       => 'version',
                'severity'    => self::SEVERITY_WARNING,
                'message'     => 'AI did not provide a version number.',
                'user_action' => 'MANUAL_ENTRY_REQUIRED',
                'suggested_fix' => 'Enter version manually or re-scrape from official source.',
            ];
        }

        // User provided explicit version - compare but only warn (AI might have found a newer one)
        if (! empty($user_version) && ! version_compare($ai_version, $user_version, '==')) {
            return [
                'field'       => 'version',
                'severity'    => self::SEVERITY_WARNING,
                'message'     => sprintf(
                    'Version mismatch (Potential update). Source: %s, AI returned: %s',
                    $user_version,
                    $ai_version
                ),
                'user_action' => 'REVIEW_REQUIRED',
                'suggested_fix' => sprintf('Verify if %s is indeed the latest version.', $ai_version),
            ];
        }

        // Scraped version exists and differs from AI
        if (! empty($scraped_version) && ! version_compare($ai_version, $scraped_version, '==')) {
            return [
                'field'       => 'version',
                'severity'    => self::SEVERITY_WARNING,
                'message'     => sprintf(
                    'Version mismatch. Scraped: %s, AI returned: %s',
                    $scraped_version,
                    $ai_version
                ),
                'user_action' => 'REVIEW_REQUIRED',
                'suggested_fix' => 'Verify which version is current on official website.',
            ];
        }

        return ['field' => 'version', 'severity' => self::SEVERITY_PASS];
    }

    /**
     * Download URL Validation
     *
     * Checks:
     * - URL accessibility (200-299 status)
     * - Domain matches homepage or safe portal
     * - Redirect chains lead to safe destination
     * - URL format validity
     */
    /**
     * File Size Validation
     *
     * Tiered tolerance:
     * - 0-10%: Pass silently
     * - 10-20%: Pass with warning
     * - >20%: Require manual approval
     */
    private function validate_file_size($input_size, $ai_size)
    {
        // Parse sizes to bytes for comparison
        $input_bytes = $this->parse_size_to_bytes($input_size);
        $ai_bytes    = $this->parse_size_to_bytes($ai_size);

        if ($input_bytes === 0) {
            return ['field' => 'file_size', 'severity' => self::SEVERITY_PASS];
        }

        $variance_percent = abs(($ai_bytes - $input_bytes) / $input_bytes) * 100;

        if ($variance_percent <= 10) {
            return ['field' => 'file_size', 'severity' => self::SEVERITY_PASS];
        }

        if ($variance_percent <= 20) {
            return [
                'field'       => 'file_size',
                'severity'    => self::SEVERITY_WARNING,
                'message'     => sprintf(
                    'File size differs by %.1f%% (Input: %s, AI: %s)',
                    $variance_percent,
                    $input_size,
                    $ai_size
                ),
                'user_action' => 'REVIEW_RECOMMENDED',
                'suggested_fix' => 'Verify file size on official download page.',
            ];
        }

        return [
            'field'       => 'file_size',
            'severity'    => self::SEVERITY_WARNING,
            'message'     => sprintf(
                'File size variance detected (%.1f%%). Source: %s, AI: %s',
                $variance_percent,
                $input_size,
                $ai_size
            ),
            'user_action' => 'REVIEW_RECOMMENDED',
            'suggested_fix' => 'Verify file size if consistency is critical.',
        ];
    }

    /**
     * System Requirements Hallucination Detection
     *
     * Flags common hallucinated values:
     * - "4 GB RAM" without source
     * - Generic processor requirements
     * - Assumed disk space values
     */
    private function validate_system_requirements($sys_reqs)
    {
        $suspicious_patterns = [
            'ram'       => ['4 GB', '8 GB', '2 GB', '512 MB'], // Common guesses
            'processor' => ['Intel Core i3', '2 GHz', '1 GHz processor'],
            'disk'      => ['500 MB', '1 GB', '100 MB'],
        ];

        $flags = [];

        foreach ($sys_reqs as $platform => $requirements) {
            foreach ($suspicious_patterns as $field => $patterns) {
                $value = self::as_string($requirements[$field] ?? '');

                if (empty($value)) {
                    continue;
                }

                foreach ($patterns as $pattern) {
                    if (stripos($value, $pattern) !== false) {
                        $flags[] = [
                            'platform' => $platform,
                            'field'    => $field,
                            'value'    => $value,
                            'reason'   => 'Matches common hallucination pattern',
                        ];
                    }
                }
            }
        }

        if (empty($flags)) {
            return ['field' => 'system_requirements', 'severity' => self::SEVERITY_PASS];
        }

        return [
            'field'       => 'system_requirements',
            'severity'    => self::SEVERITY_WARNING,
            'message'     => sprintf('%d system requirement(s) may be hallucinated.', count($flags)),
            'user_action' => 'REVIEW_REQUIRED',
            'details'     => $flags,
            'suggested_fix' => 'Verify requirements on official system requirements page.',
        ];
    }

    /**
     * Safety Claims Validation
     *
     * Ensures security badges are only shown when evidence exists
     */
    private function validate_safety_claims($ai_safety, $input_safety)
    {
        $has_virus_scan    = ! empty($ai_safety['virus_total_scan']) || ! empty($input_safety['virus_total_scan']);
        $has_verified_dl   = ! empty($ai_safety['verified_download']) || ! empty($input_safety['verified_download']);
        $has_file_hash     = ! empty($ai_safety['file_hash']) || ! empty($input_safety['file_hash']);

        $has_evidence = $has_virus_scan || $has_verified_dl || $has_file_hash;

        // Check if AI is making unsupported safety claims
        $safety_badge = self::as_string($ai_safety['security_badge'] ?? '');
        $ai_claims_safe = !empty($safety_badge) && stripos($safety_badge, 'safe') !== false;

        if ($ai_claims_safe && !$has_evidence) {
            return [
                'field'       => 'safety_badge',
                'severity'    => self::SEVERITY_CRITICAL,
                'message'     => 'AI generated security claim without evidence.',
                'user_action' => 'REMOVE_BADGE',
                'suggested_fix' => 'Remove "100% Secure" or similar claims until verified.',
                'auto_fix'    => ['safety.security_badge' => null],
            ];
        }

        return ['field' => 'safety_badge', 'severity' => self::SEVERITY_PASS];
    }

    /**
     * Parse file size string to bytes
     */
    private function parse_size_to_bytes($size_str)
    {
        $size_str = self::as_string($size_str);
        if (is_numeric($size_str)) {
            return (float) $size_str;
        }

        $units = ['B' => 1, 'KB' => 1024, 'MB' => 1048576, 'GB' => 1073741824];

        if (preg_match('/([0-9.]+)\s*([A-Z]+)/i', $size_str, $matches)) {
            $value = (float) $matches[1];
            $unit  = strtoupper($matches[2]);

            return $value * ($units[$unit] ?? 1);
        }

        return 0;
    }

    /**
     * Determine overall action based on all issues
     */
    private function determine_action($issues)
    {
        $has_critical = false;
        $has_error    = false;
        $has_warning  = false;

        foreach ($issues as $issue) {
            switch ($issue['severity']) {
                case self::SEVERITY_CRITICAL:
                    $has_critical = true;
                    break;
                case self::SEVERITY_ERROR:
                    $has_error = true;
                    break;
                case self::SEVERITY_WARNING:
                    $has_warning = true;
                    break;
            }
        }

        if ($has_critical) {
            return 'BLOCK_PUBLISHING'; // Cannot publish without fixes
        }

        if ($has_error) {
            return 'REQUIRE_MANUAL_REVIEW'; // Admin must review before publishing
        }

        if ($has_warning) {
            return 'WARN_BEFORE_PUBLISHING'; // Show warnings but allow publishing
        }

        return 'ALLOW_PUBLISHING'; // All checks passed
    }

    /**
     * Can content be auto-published without manual intervention?
     */
    private function can_auto_publish($issues)
    {
        foreach ($issues as $issue) {
            if (in_array($issue['severity'], [self::SEVERITY_CRITICAL, self::SEVERITY_ERROR], true)) {
                return false;
            }
        }
        return true;
    }

    /**
     * F12 (Phase 3C, 2.32.26): NOT WIRED — pairs with
     * Deterministic_Update_Builder, which has zero production callers.
     * Retained for the deferred deterministic-link backfill work.
     */
    public function validate_deterministic_update_payload(array $bundle, array $verified_links = []): array
    {
        $issues = [];

        $primary = self::as_string($bundle['primary_download_url'] ?? '');
        $tech_specs = isset($bundle['tech_specs']) && is_array($bundle['tech_specs']) ? $bundle['tech_specs'] : [];
        $links = isset($bundle['download_section']['links']) && is_array($bundle['download_section']['links'])
            ? $bundle['download_section']['links']
            : [];

        if ($primary === '') {
            $issues[] = [
                'field'        => 'primary_download_url',
                'severity'     => self::SEVERITY_CRITICAL,
                'message'      => 'Deterministic bundle is missing a primary download URL.',
                'user_action'   => 'BLOCK',
                'suggested_fix' => 'Do not publish update until at least one approved source link exists.',
            ];
        } elseif (!filter_var($primary, FILTER_VALIDATE_URL)) {
            $issues[] = [
                'field'        => 'primary_download_url',
                'severity'     => self::SEVERITY_CRITICAL,
                'message'      => 'Deterministic bundle contains an invalid primary download URL.',
                'user_action'   => 'BLOCK',
                'suggested_fix' => 'Rebuild canonical bundle from approved resolver links.',
            ];
        }

        if (!empty($verified_links)) {
            $verified_set = [];
            foreach ($verified_links as $row) {
                $url = self::as_string(is_array($row) ? ($row['url'] ?? '') : $row);
                if ($url !== '') {
                    $verified_set[$url] = true;
                }
            }

            if ($primary !== '' && !isset($verified_set[$primary])) {
                $issues[] = [
                    'field'        => 'primary_download_url',
                    'severity'     => self::SEVERITY_ERROR,
                    'message'      => 'Deterministic bundle attempted to replace a verified source URL with a non-verified URL.',
                    'user_action'   => 'REVIEWREQUIRED',
                    'suggested_fix' => 'Keep only approved resolver URLs for updates.',
                ];
            }

            foreach ($links as $idx => $link) {
                $url = self::as_string($link['url'] ?? '');
                if ($url === '') {
                    continue;
                }

                if (!isset($verified_set[$url])) {
                    $issues[] = [
                        'field'        => 'download_section.links[' . $idx . ']',
                        'severity'     => self::SEVERITY_ERROR,
                        'message'      => 'Download link is not part of the verified source bundle.',
                        'user_action'   => 'REVIEWREQUIRED',
                        'suggested_fix' => 'Drop non-source links from deterministic update bundle.',
                    ];
                }
            }
        }

        foreach (['software_name', 'version'] as $required_field) {
            if (self::as_string($tech_specs[$required_field] ?? '') === '') {
                $issues[] = [
                    'field'        => 'tech_specs.' . $required_field,
                    'severity'     => self::SEVERITY_WARNING,
                    'message'      => 'Deterministic bundle is missing ' . $required_field . '.',
                    'user_action'   => 'REVIEWRECOMMENDED',
                    'suggested_fix' => 'Backfill from source facts or existing verified meta.',
                ];
            }
        }

        if (empty($links) && $primary !== '') {
            $issues[] = [
                'field'        => 'download_section.links',
                'severity'     => self::SEVERITY_WARNING,
                'message'      => 'Primary download URL exists but rendered link list is empty.',
                'user_action'   => 'REVIEWRECOMMENDED',
                'suggested_fix' => 'Populate download_section.links from canonical bundle.',
            ];
        }

        return [
            'valid'      => empty(array_filter($issues, static function ($issue) {
                return in_array($issue['severity'], [self::SEVERITY_CRITICAL, self::SEVERITY_ERROR], true);
            })),
            'issues'     => $issues,
            'action'     => $this->determine_action($issues),
            'can_publish' => $this->can_auto_publish($issues),
        ];
    }
}
