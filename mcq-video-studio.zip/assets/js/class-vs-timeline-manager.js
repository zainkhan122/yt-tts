/**
 * MCQVS Timeline Manager
 * Handles scene logic, timing, and phase transitions.
 * 
 * @package WP_News_MCQ_Generator
 * @version 1.0.0
 */

(function (window) {
    "use strict";

    class MCQVS_TimelineManager {
        /**
         * @param {Object} config - Timing configuration
         * @param {Object} config.timing - { hookIntro, questionTotal, questionPhases: { intro, reading, reveal }, outroDuration }
         */
        constructor(config) {
            // @FIX 2026-08-11: Shorts-first fallback (SSOT with studio.controller/server).
            this.timing = config.timing || {
                hookIntro: 1200,
                questionTotal: 7700,
                questionPhases: {
                    intro: 600,
                    reading: 5100,
                    reveal: 2000
                },
                outroDuration: 3200
            };
        }

        /**
         * Get the scene description for a given timestamp
         * 
         * @param {number} elapsed - Total elapsed time in ms
         * @param {Array} questions - Array of questions
         * @returns {Object} { sceneId, phase, localTime, questionIndex, isTransitioning }
         */
        getSceneAtTime(elapsed, questions) {
            const t = this.timing;
            const qCount = questions.length;

            // 1. Hook Phase
            if (elapsed < t.hookIntro) {
                return {
                    sceneId: 'hook',
                    phase: 'hook',
                    localTime: elapsed,
                    questionIndex: -1,
                    progress: elapsed / t.hookIntro
                };
            }

            const activeTime = elapsed - t.hookIntro;
            const totalQuestionsTime = qCount * t.questionTotal;

            // 2. Question Phases
            if (activeTime < totalQuestionsTime) {
                const qIndex = Math.floor(activeTime / t.questionTotal);
                const localTime = activeTime % t.questionTotal;

                let phase = 'unknown';

                if (localTime < t.questionPhases.intro) {
                    phase = 'intro';
                } else if (localTime < ((t._revealStartRel !== undefined) ? t._revealStartRel : (t.questionTotal - t.questionPhases.reveal))) {
                    phase = 'reading';
                } else {
                    phase = 'reveal';
                }

                return {
                    sceneId: `q_${qIndex}`,
                    phase: phase,
                    localTime: localTime,
                    questionIndex: qIndex,
                    progress: localTime / t.questionTotal
                };
            }

            // 3. Outro Phase
            const outroElapsed = activeTime - totalQuestionsTime;

            // Cap at end
            if (outroElapsed > t.outroDuration + 1000) { // +1s buffer
                return {
                    sceneId: 'end',
                    phase: 'end',
                    localTime: t.outroDuration,
                    questionIndex: qCount,
                    progress: 1
                };
            }

            return {
                sceneId: 'outro',
                phase: 'outro',
                localTime: outroElapsed,
                questionIndex: qCount,
                progress: Math.min(1, outroElapsed / t.outroDuration)
            };
        }

        /**
         * Calculate total duration
         * @param {number} questionCount 
         */
        getTotalDuration(questionCount) {
            const t = this.timing;
            return t.hookIntro + (questionCount * t.questionTotal) + t.outroDuration;
        }
    }

    // Export
    window.MCQVS_TimelineManager = MCQVS_TimelineManager;

})(window);
