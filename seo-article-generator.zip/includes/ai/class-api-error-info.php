<?php

namespace SEO_Article_Generator\AI;

if (!defined('ABSPATH')) {
    exit;
}

class API_Error_Info
{
    const TYPE_QUOTA_RPD = 'quota_rpd';
    const TYPE_QUOTA_RPM = 'quota_rpm';
    const TYPE_QUOTA_TPM = 'quota_tpm';
    const TYPE_QUOTA_UNKNOWN = 'quota_unknown';
    const TYPE_AUTH_FAILURE = 'auth_failure';
    const TYPE_MODEL_NOT_FOUND = 'model_not_found';
    const TYPE_REQUEST_SHAPE = 'request_shape';
    const TYPE_SERVER_OVERLOADED = 'server_overloaded';
    const TYPE_SAFETY_BLOCK = 'safety_block';
    const TYPE_TRANSIENT = 'transient';
    const TYPE_UNKNOWN = 'unknown';

    const ACTION_SKIP_MODEL = 'skip_model';
    const ACTION_ROUTE_NEXT = 'route_next';
    const ACTION_BLOCK_DAILY = 'block_daily';
    const ACTION_HARD_FAIL = 'hard_fail';
    const ACTION_SAFETY_BLOCK = 'safety_block';

    private $provider = '';
    private $http_status = 0;
    private $error_status = '';
    private $error_code = 0;
    private $message = '';
    private $error_type = self::TYPE_UNKNOWN;
    private $retry_delay_seconds = 0;
    private $quota_metric = '';
    private $quota_limit = 0;
    private $is_retryable = false;
    private $is_deterministic = false;
    private $reset_at_ts = 0;
    private $details_raw = array();
    private $field_violations = array();
    private $response_headers = array();

    public static function from_array(array $d): self
    {
        $info = new self();
        $info->provider = (string) ($d['provider'] ?? '');
        $info->http_status = (int) ($d['http_status'] ?? 0);
        $info->error_status = (string) ($d['error_status'] ?? '');
        $info->error_code = (int) ($d['error_code'] ?? 0);
        $info->message = (string) ($d['message'] ?? '');
        $info->error_type = (string) ($d['error_type'] ?? self::TYPE_UNKNOWN);
        $info->retry_delay_seconds = (int) ($d['retry_delay_seconds'] ?? 0);
        $info->quota_metric = (string) ($d['quota_metric'] ?? '');
        $info->quota_limit = (int) ($d['quota_limit'] ?? 0);
        $info->is_retryable = !empty($d['is_retryable']);
        $info->is_deterministic = !empty($d['is_deterministic']);
        $info->reset_at_ts = (int) ($d['reset_at_ts'] ?? 0);
        $info->details_raw = (array) ($d['details_raw'] ?? array());
        $info->field_violations = (array) ($d['field_violations'] ?? array());
        $info->response_headers = (array) ($d['response_headers'] ?? array());
        return $info;
    }

    public function to_array(): array
    {
        return array(
            'provider' => $this->provider,
            'http_status' => $this->http_status,
            'error_status' => $this->error_status,
            'error_code' => $this->error_code,
            'message' => $this->message,
            'error_type' => $this->error_type,
            'retry_delay_seconds' => $this->retry_delay_seconds,
            'quota_metric' => $this->quota_metric,
            'quota_limit' => $this->quota_limit,
            'is_retryable' => $this->is_retryable,
            'is_deterministic' => $this->is_deterministic,
            'reset_at_ts' => $this->reset_at_ts,
            'details_raw' => $this->details_raw,
            'field_violations' => $this->field_violations,
            'response_headers' => $this->response_headers,
        );
    }

    public function get_provider(): string { return $this->provider; }
    public function get_http_status(): int { return $this->http_status; }
    public function get_error_status(): string { return $this->error_status; }
    public function get_error_code(): int { return $this->error_code; }
    public function get_message(): string { return $this->message; }
    public function get_error_type(): string { return $this->error_type; }
    public function get_retry_delay_seconds(): int { return $this->retry_delay_seconds; }
    public function get_quota_metric(): string { return $this->quota_metric; }
    public function get_quota_limit(): int { return $this->quota_limit; }
    public function is_retryable(): bool { return $this->is_retryable; }
    public function is_deterministic(): bool { return $this->is_deterministic; }
    public function get_reset_at_ts(): int { return $this->reset_at_ts; }
    public function get_details_raw(): array { return $this->details_raw; }
    public function get_field_violations(): array { return $this->field_violations; }
    public function get_response_headers(): array { return $this->response_headers; }

    public function is_quota_error(): bool
    {
        return in_array($this->error_type, array(
            self::TYPE_QUOTA_RPD, self::TYPE_QUOTA_RPM,
            self::TYPE_QUOTA_TPM, self::TYPE_QUOTA_UNKNOWN,
            self::TYPE_SERVER_OVERLOADED,
        ), true);
    }

    public function is_daily_quota(): bool
    {
        return $this->error_type === self::TYPE_QUOTA_RPD;
    }

    /**
     * Single source of truth for how the global fallback system should react to
     * this error. Every provider fallback chain and the AI_Client gateway must
     * consult this instead of re-deriving policy from error_type ad hoc.
     */
    public function recommended_action(): string
    {
        switch ($this->error_type) {
            case self::TYPE_MODEL_NOT_FOUND:
                return self::ACTION_SKIP_MODEL;
            case self::TYPE_QUOTA_RPM:
            case self::TYPE_QUOTA_TPM:
            case self::TYPE_QUOTA_UNKNOWN:
            case self::TYPE_SERVER_OVERLOADED:
            case self::TYPE_TRANSIENT:
                return self::ACTION_ROUTE_NEXT;
            case self::TYPE_QUOTA_RPD:
                return self::ACTION_BLOCK_DAILY;
            case self::TYPE_AUTH_FAILURE:
            case self::TYPE_REQUEST_SHAPE:
                return self::ACTION_HARD_FAIL;
            case self::TYPE_SAFETY_BLOCK:
                return self::ACTION_SAFETY_BLOCK;
            default:
                // Unknown errors must not be retried blindly; treat as hard failure.
                return self::ACTION_HARD_FAIL;
        }
    }

    public function is_route_next(): bool
    {
        return $this->recommended_action() === self::ACTION_ROUTE_NEXT;
    }

    public function is_daily_block(): bool
    {
        return $this->recommended_action() === self::ACTION_BLOCK_DAILY;
    }

    public function is_skip_model(): bool
    {
        return $this->recommended_action() === self::ACTION_SKIP_MODEL;
    }

    public function is_hard_fail(): bool
    {
        return $this->recommended_action() === self::ACTION_HARD_FAIL;
    }
}
