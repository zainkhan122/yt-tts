#!/usr/bin/env bash
#
# MCQ Video Studio — VPS dependency AUDIT ONLY (browser-free pipeline)
#
# This script does NOT install or modify anything. It only DETECTS what the
# new Chromium-free render pipeline needs, prints a PASS/FAIL table, and lists
# exactly what is MISSING so the operator can decide how to install it.
#
# Run on the VPS, from the plugin root:
#   bash render-service/setup-vps.sh
#
set -uo pipefail

PLUGIN_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RENDER_DIR="$PLUGIN_DIR/render-service"

echo "Plugin root : $PLUGIN_DIR"
echo "Render dir  : $RENDER_DIR"
echo

# ───────────────────────── 1. DETECT ─────────────────────────
HAS_NODE=0; HAS_NPM=0; HAS_FFMPEG=0; HAS_CANVAS=0
HAS_CAIRO=0; HAS_PANGO=0; HAS_JPEG=0; HAS_GIF=0; HAS_RSVG=0
HAS_BUILDTOOL=0

if command -v node >/dev/null 2>&1; then HAS_NODE=1; NODE_VER="$(node -v)"; fi
if command -v npm  >/dev/null 2>&1; then HAS_NPM=1;  NPM_VER="$(npm -v)"; fi
if command -v ffmpeg >/dev/null 2>&1; then HAS_FFMPEG=1; FFMPEG_VER="$(ffmpeg -version 2>/dev/null | head -1 | cut -d' ' -f1-3)"; fi

if [ "$HAS_NODE" = "1" ]; then
  if node -e "require('canvas'); process.exit(0)" >/dev/null 2>&1; then HAS_CANVAS=1; fi
fi

pkg_have(){ command -v pkg-config >/dev/null 2>&1 && pkg-config --exists "$1"; }
pkg_have cairo       && HAS_CAIRO=1
pkg_have pango       && HAS_PANGO=1
pkg_have libjpeg     && HAS_JPEG=1
pkg_have librsvg-2.0 && HAS_RSVG=1
# giflib: pkg-config name is inconsistent across distros, so also probe the header.
pkg_have giflib && HAS_GIF=1
[ -f /usr/include/gif_lib.h ] && HAS_GIF=1

# node-canvas's compile step invokes g++ directly, so ALL of gcc/g++/make must exist.
if command -v gcc >/dev/null 2>&1 && command -v g++ >/dev/null 2>&1 && command -v make >/dev/null 2>&1; then
  HAS_BUILDTOOL=1
fi

# ───────────────────────── 2. REPORT ─────────────────────────
echo "================ AVAILABILITY CHECK ================"
printf '%-14s %s\n' "node"          "$([ $HAS_NODE = 1 ] && echo "OK ($NODE_VER)" || echo MISSING)"
printf '%-14s %s\n' "npm"           "$([ $HAS_NPM = 1 ] && echo "OK ($NPM_VER)" || echo MISSING)"
printf '%-14s %s\n' "ffmpeg"        "$([ $HAS_FFMPEG = 1 ] && echo "OK ($FFMPEG_VER)" || echo MISSING)"
printf '%-14s %s\n' "node-canvas"   "$([ $HAS_CANVAS = 1 ] && echo "OK" || echo MISSING "(will build via npm)")"
echo "--- node-canvas native libs (need ALL for the build) ---"
printf '%-14s %s\n' "cairo"         "$([ $HAS_CAIRO = 1 ] && echo OK || echo MISSING)"
printf '%-14s %s\n' "pango"         "$([ $HAS_PANGO = 1 ] && echo OK || echo MISSING)"
printf '%-14s %s\n' "libjpeg"       "$([ $HAS_JPEG = 1 ] && echo OK || echo MISSING)"
printf '%-14s %s\n' "giflib"        "$([ $HAS_GIF = 1 ] && echo OK || echo MISSING)"
printf '%-14s %s\n' "librsvg"       "$([ $HAS_RSVG = 1 ] && echo OK || echo MISSING)"
printf '%-14s %s\n' "build-tools"   "$([ $HAS_BUILDTOOL = 1 ] && echo OK || echo MISSING)"
echo "====================================================="

# ───────────────────────── 3. MISSING SUMMARY ─────────────────────────
MISSING=()
[ "$HAS_NODE" = 0 ]      && MISSING+=("node (>=16)")
[ "$HAS_NPM" = 0 ]       && MISSING+=("npm")
[ "$HAS_FFMPEG" = 0 ]    && MISSING+=("ffmpeg")
[ "$HAS_CAIRO" = 0 ]     && MISSING+=("libcairo2-dev")
[ "$HAS_PANGO" = 0 ]     && MISSING+=("libpango1.0-dev")
[ "$HAS_JPEG" = 0 ]      && MISSING+=("libjpeg-dev")
[ "$HAS_GIF" = 0 ]       && MISSING+=("libgif-dev")
[ "$HAS_RSVG" = 0 ]      && MISSING+=("librsvg2-dev")
[ "$HAS_BUILDTOOL" = 0 ] && MISSING+=("build-essential python3 make g++ pkg-config")
[ "$HAS_CANVAS" = 0 ]    && MISSING+=("npm modules: canvas + ws (run: cd render-service && npm install)")

echo
if [ "${#MISSING[@]}" = "0" ]; then
  echo "✅ All requirements satisfied. Nothing to install."
else
  echo "❌ MISSING (${#MISSING[@]} item(s)):"
  for m in "${MISSING[@]}"; do
    echo "   - $m"
  done
  echo
  echo "Paste the list above back to the developer for the exact install commands."
fi
echo
echo "No changes were made to this system."
