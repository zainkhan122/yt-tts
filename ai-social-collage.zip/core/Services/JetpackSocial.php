<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class JetpackSocial {

    public function __construct() {
        add_filter( 'jetpack_images_get_images', [ $this, 'override_jetpack_image' ], 0, 3 );
        add_filter( 'wpas_submit_post?', [ $this, 'filter_jetpack_network' ], 10, 4 );
        add_filter( 'wpas_extra_data', [ $this, 'filter_jetpack_extra_data' ], 0, 2 );
        add_filter( 'wpas_message', [ $this, 'filter_jetpack_message' ], 0, 3 );
        add_filter( 'wpas_default_suffix', [ $this, 'filter_default_suffix' ], 0, 1 );
        add_filter( 'wpas_default_prefix', [ $this, 'filter_default_prefix' ], 0, 1 );
        add_filter( 'wpas_default_message', [ $this, 'filter_default_message' ], 0, 1 );
        add_filter( 'jetpack_publicize_options', [ $this, 'filter_jetpack_publicize_options' ], 10, 1 );
        add_filter( 'pre_option_jetpack_publicize_options', [ $this, 'pre_option_jetpack_publicize_options' ], 10, 1 );
        add_action( 'save_post', [ $this, 'on_save_post_inject_options' ], 5, 2 );
    }

    public static function sync( int $post_id, int $attachment_id = 0 ): bool {
        if ( ! Config::is_jetpack_enabled() ) {
            return false;
        }

        $publicize_class = self::get_publicize_class();
        if ( ! $publicize_class ) {
            Logger::debug( 'jetpack_class_missing', null, [ 'post_id' => $post_id ] );
            return false;
        }

        $auto_meta = get_post_meta( $post_id, Config::META_AUTO_META, true );
        $auto_meta = is_array( $auto_meta ) ? $auto_meta : [];

        $headline = $auto_meta['ai_headline'] ?? '';
        if ( empty( $headline ) ) {
            $headline = get_post_field( 'post_title', $post_id );
        }

        $description = $auto_meta['ai_detailed_description'] ?? $auto_meta['ai_hook'] ?? '';
        if ( empty( $description ) ) {
            $description = wp_trim_words( wp_strip_all_tags( get_post_field( 'post_content', $post_id ) ), 30 );
        }

$x_content = $auto_meta['x_content'] ?? '';
		$x_hashtags = '';
		if ( ! empty( $auto_meta['ai_x_hashtags'] ) && is_array( $auto_meta['ai_x_hashtags'] ) ) {
			$x_hashtags = implode( ' ', array_slice( $auto_meta['ai_x_hashtags'], 0, 5 ) );
		}
		$x_description = $auto_meta['ai_x_description'] ?? '';

		$default_hashtags = self::get_hashtags( $post_id );
		$link = Config::is_jetpack_link_disabled() ? '' : get_permalink( $post_id );

		if ( empty( $headline ) || empty( $description ) ) {
			Logger::warning( 'jetpack_sync_empty_content', null, [ 'post_id' => $post_id ] );
			return false;
		}

		$template = Config::get_jetpack_template();
		$message_data = [
			'{headline}'       => wp_strip_all_tags( html_entity_decode( trim( $headline ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) ),
			'{description}'    => wp_strip_all_tags( trim( $description ) ),
			'{hashtags}'       => $default_hashtags,
			'{link}'           => $link,
			'{x_hashtags}'     => $x_hashtags,
			'{x_description}'  => $x_description,
			'{X-CONTENT}'      => $x_description . ( $x_hashtags ? "\n" . $x_hashtags : '' ),
		];

        $global_message = str_replace( array_keys( $message_data ), array_values( $message_data ), $template );
        $global_message = preg_replace( "/\n{3,}/", "\n\n", trim( $global_message ) );
        update_post_meta( $post_id, Config::META_JETPACK_MESSAGE, $global_message );

        update_post_meta( $post_id, Config::META_JETPACK_OPTIONS, [
            'open_url' => ! Config::is_jetpack_link_disabled(),
        ] );

        // Suppress Jetpack's own link-appending when link sharing is disabled.
        if ( Config::is_jetpack_link_disabled() ) {
            update_post_meta( $post_id, '_wpas_link', 0 );
        } else {
            delete_post_meta( $post_id, '_wpas_link' );
        }

        self::write_per_network_messages( $post_id, $message_data, $default_hashtags, $x_content, $x_hashtags, $x_description );

        if ( $attachment_id > 0 ) {
            $image_url = wp_get_attachment_url( $attachment_id );
            if ( ! empty( $image_url ) ) {
                // For video content, _wpas_options.attached_media (set by update_jetpack_social_options)
                // is the sole source of truth for the wpcom Publicize upload. Avoid polluting the
                // image-only _wpas_media_src slot with a video URL, which Jetpack's `jetpack_images_get_images`
                // filter (used for OpenGraph / Related Posts only) would attempt to treat as an image.
                if ( ! self::is_video_attachment( $attachment_id ) ) {
                    update_post_meta( $post_id, Config::META_JETPACK_IMAGE, $image_url );
                }
                self::update_jetpack_social_options( $post_id, $attachment_id, $image_url );
            }
        } else {
            self::set_featured_image_fallback( $post_id );
        }

        Logger::info( Config::LOG_ACTION_JETPACK_SYNC, null, [
            'post_id' => $post_id,
            'attachment_id' => $attachment_id,
        ], '200', 'Jetpack sync completed for post ' . $post_id );

        return true;
    }

private static function write_per_network_messages( int $post_id, array $message_data, string $default_hashtags, string $x_content = '', string $x_hashtags = '', string $x_description = '' ): void {
		$network_templates = Config::get_jetpack_network_templates();
		$network_hashtags = Config::get_jetpack_network_hashtags();

		if ( empty( $network_templates ) && empty( $network_hashtags ) ) {
			return;
		}

		$publicize_class = self::get_publicize_class();
		if ( ! $publicize_class || ! method_exists( $publicize_class, 'get_connections' ) ) {
			Logger::debug( 'jetpack_publicize_unavailable', null, [ 'post_id' => $post_id ] );
			return;
		}

		try {
			$publicize = new $publicize_class();
			$connections = $publicize->get_connections( 'post', $post_id );

			foreach ( $connections as $conn ) {
				$conn_id = $conn['id'] ?? $conn['connection_id'] ?? '';
				$service_name = $conn['service_name'] ?? '';
				if ( empty( $conn_id ) || empty( $service_name ) ) {
					continue;
				}

				$custom_template = $network_templates[ $service_name ] ?? '';
				$custom_hashtags = $network_hashtags[ $service_name ] ?? '';

				if ( ! empty( $custom_template ) || ! empty( $custom_hashtags ) ) {
					$network_data = $message_data;

					if ( $service_name === 'twitter' && ! empty( $x_content ) ) {
						$network_data['{description}'] = wp_strip_all_tags( trim( $x_content ) );
						$network_data['{X-CONTENT}'] = wp_strip_all_tags( trim( $x_content ) );
					}

					if ( ! empty( $custom_hashtags ) ) {
						$network_data['{hashtags}'] = $custom_hashtags;
					}

					if ( ! empty( $custom_template ) ) {
						$custom_message = str_replace( array_keys( $network_data ), array_values( $network_data ), $custom_template );
					} else {
						$global_template = Config::get_jetpack_template();
						$custom_message = str_replace( array_keys( $network_data ), array_values( $network_data ), $global_template );
					}

					$custom_message = preg_replace( "/\n{3,}/", "\n\n", trim( $custom_message ) );
					update_post_meta( $post_id, Config::META_JETPACK_MESSAGE . '_' . $conn_id, $custom_message );
				} else {
					delete_post_meta( $post_id, Config::META_JETPACK_MESSAGE . '_' . $conn_id );
				}
			}
		} catch ( \Throwable $e ) {
			Logger::warning( 'jetpack_per_network_error', null, [
				'post_id' => $post_id,
				'error' => $e->getMessage(),
			] );
		}
	}

    public static function update_jetpack_social_options( int $post_id, int $media_id, string $media_url, string $source = 'media-library' ): void {
        $media_type = self::is_video_attachment( $media_id ) ? 'video' : 'image';

        $options = (array) get_post_meta( $post_id, Config::META_JETPACK_OPTIONS, true );
        $options['attached_media'] = [
            [ 'id' => $media_id, 'url' => $media_url, 'type' => $media_type ],
        ];
        $options['media_source'] = $source;
        $options['open_url'] = ! Config::is_jetpack_link_disabled();
        update_post_meta( $post_id, Config::META_JETPACK_OPTIONS, $options );
    }

    /**
     * Detect whether the attachment is video content.
     *
     * Checks META_CONTENT_TYPE first (set by VideoRenderer), then falls back to MIME type.
     */
    private static function is_video_attachment( int $attachment_id ): bool {
        if ( $attachment_id <= 0 ) {
            return false;
        }
        $content_type = get_post_meta( $attachment_id, Config::META_CONTENT_TYPE, true );
        if ( $content_type === Config::CONTENT_TYPE_VIDEO ) {
            return true;
        }
        $mime = get_post_mime_type( $attachment_id );
        return ! empty( $mime ) && strpos( $mime, 'video/' ) === 0;
    }

	private static function set_featured_image_fallback( int $post_id ): void {
		$thumb_id = (int) get_post_thumbnail_id( $post_id );
		if ( $thumb_id > 0 ) {
			$thumb_url = wp_get_attachment_url( $thumb_id );
			if ( ! empty( $thumb_url ) ) {
				update_post_meta( $post_id, Config::META_JETPACK_IMAGE, $thumb_url );
				self::update_jetpack_social_options( $post_id, $thumb_id, $thumb_url, 'featured-image' );
			}
		} else {
			delete_post_meta( $post_id, Config::META_JETPACK_IMAGE );
		}
	}

    private static function get_hashtags( int $post_id ): string {
        $generated = get_post_meta( $post_id, Config::META_GENERATED_HASHTAGS, true );
        if ( is_array( $generated ) && ! empty( $generated ) ) {
            $clean = [];
            foreach ( $generated as $tag ) {
                $tag = trim( $tag );
                $tag = ltrim( $tag, '#' );
                $tag = preg_replace( '/[^\p{L}\p{N}_]/u', '', $tag );
                if ( ! empty( $tag ) && mb_strlen( $tag, 'UTF-8' ) >= 2 ) {
                    $clean[] = '#' . $tag;
                }
            }
            if ( ! empty( $clean ) ) {
                return implode( ' ', array_slice( array_unique( $clean ), 0, 5 ) );
            }
        }

        $auto_meta = get_post_meta( $post_id, Config::META_AUTO_META, true );
        if ( is_array( $auto_meta ) && ! empty( $auto_meta['ai_hashtags'] ) ) {
            $clean = [];
            foreach ( $auto_meta['ai_hashtags'] as $tag ) {
                $tag = trim( $tag );
                $tag = ltrim( $tag, '#' );
                $tag = preg_replace( '/[^\p{L}\p{N}_]/u', '', $tag );
                if ( ! empty( $tag ) && mb_strlen( $tag, 'UTF-8' ) >= 2 ) {
                    $clean[] = '#' . $tag;
                }
            }
            if ( ! empty( $clean ) ) {
                return implode( ' ', array_slice( array_unique( $clean ), 0, 5 ) );
            }
        }

        return '';
    }

    public function override_jetpack_image( array $images, int $post_id, array $args ): array {
        if ( ! Config::is_jetpack_enabled() ) {
            return $images;
        }

        $collage_url = get_post_meta( $post_id, Config::META_JETPACK_IMAGE, true );
        if ( empty( $collage_url ) ) {
            return $images;
        }

        // Defensive: the `jetpack_images_get_images` filter is image-only by spec
        // (see Jetpack developer docs). Never inject a video URL into this filter —
        // video upload uses `_wpas_options.attached_media` instead.
        $extension = strtolower( (string) wp_parse_url( $collage_url, PHP_URL_PATH ) );
        if ( preg_match( '/\.(mp4|webm|mov|m4v|avi|mkv)$/i', $extension ) ) {
            return $images;
        }

        $context = $args['context'] ?? '';
        if ( ! in_array( $context, [ 'publicize', 'opengraph', 'twitter', '' ], true ) ) {
            return $images;
        }

        if ( ! is_array( $images ) ) {
            $images = [];
        }

		array_unshift( $images, [
			'type' => 'image',
			'from' => 'custom',
			'src' => $collage_url,
			'href' => $collage_url,
		] );

		return $images;
    }

    public function filter_jetpack_network( bool $should_share, int $post_id, string $service_name, array $connection ): bool {
        if ( ! Config::is_jetpack_enabled() ) {
            return $should_share;
        }

        $networks = Config::get_jetpack_networks();

        if ( ! isset( $networks[ $service_name ] ) ) {
            if ( $service_name === 'instagram' && isset( $networks['instagram-business'] ) ) {
                return ! empty( $networks['instagram-business'] );
            }
            if ( $service_name === 'instagram-business' && isset( $networks['instagram'] ) ) {
                return ! empty( $networks['instagram'] );
            }
            return $should_share;
        }

        return ! empty( $networks[ $service_name ] );
    }

    public function filter_jetpack_extra_data( array $extra_data, int $post_id ): array {
        if ( ! Config::is_jetpack_enabled() ) {
            return $extra_data;
        }

        if ( Config::is_jetpack_link_disabled() ) {
            unset( $extra_data['url'] );
        }

        return $extra_data;
    }

    public function filter_jetpack_message( string $message, int $post_id, string $service_name ): string {
        if ( ! Config::is_jetpack_enabled() ) {
            return $message;
        }

        if ( ! Config::is_jetpack_link_disabled() ) {
            return $message;
        }

        $permalink = get_permalink( $post_id );
        if ( $permalink ) {
            $message = str_replace( $permalink, '', $message );
            $message = str_replace( '%url%', '', $message );
            $message = preg_replace( '#https?://\S+#', '', $message );
        }

        $message = trim( preg_replace( '/\n{2,}/', "\n\n", $message ) );

        return $message;
    }

    public function filter_default_suffix( string $suffix ): string {
        if ( ! Config::is_jetpack_enabled() || ! Config::is_jetpack_link_disabled() ) {
            return $suffix;
        }
        return '';
    }

    public function filter_default_prefix( string $prefix ): string {
        if ( ! Config::is_jetpack_enabled() || ! Config::is_jetpack_link_disabled() ) {
            return $prefix;
        }
        return '';
    }

    public function filter_default_message( string $message ): string {
        if ( ! Config::is_jetpack_enabled() || ! Config::is_jetpack_link_disabled() ) {
            return $message;
        }
        return str_replace( '%url%', '', $message );
    }

    public function filter_jetpack_publicize_options( array $options ): array {
        if ( ! Config::is_jetpack_enabled() ) {
            return $options;
        }

        if ( Config::is_jetpack_link_disabled() ) {
            $options['open_url']      = false;
            $options['attach_media']  = ! empty( $options['attach_media'] );
            $options['disable_link']  = true;
        }

        return $options;
    }

    public function pre_option_jetpack_publicize_options( $pre ): array {
        if ( ! Config::is_jetpack_enabled() || ! Config::is_jetpack_link_disabled() ) {
            return (array) $pre;
        }
        $options              = is_array( $pre ) ? $pre : [];
        $options['open_url']  = false;
        $options['disable_link'] = true;
        return $options;
    }

    public function on_save_post_inject_options( int $post_id, $post ) {
        if ( ! Config::is_jetpack_enabled() || ! Config::is_jetpack_link_disabled() ) {
            return;
        }

        if ( ! $post instanceof \WP_Post ) {
            return;
        }

        if ( $post->post_type !== 'post' ) {
            return;
        }

        update_post_meta( $post_id, Config::META_JETPACK_OPTIONS, [
            'open_url'     => false,
            'disable_link' => true,
        ] );

        update_post_meta( $post_id, '_wpas_link', 0 );

        $existing = (array) get_option( Config::OPTION_JETPACK_OPTIONS_OVERRIDE, [] );
        $existing[ $post_id ] = [
            'open_url'     => false,
            'disable_link' => true,
        ];
        update_option( Config::OPTION_JETPACK_OPTIONS_OVERRIDE, $existing, false );
    }

    private static function get_publicize_class(): ?string {
        // New namespace (Jetpack 14.x+)
        if ( class_exists( '\\Automattic\\Jetpack\\Publicize\\Publicize' ) ) {
            return '\\Automattic\\Jetpack\\Publicize\\Publicize';
        }
        // Legacy namespace (Jetpack < 14.x)
        if ( class_exists( '\\Jetpack\\Publicize' ) ) {
            return '\\Jetpack\\Publicize';
        }
        return null;
    }
}
