<?php

/**
 * Admin Settings Manager
 * Version: 1.5 - Restored Manual Generation Controls
 *
 * @MODIFIED: Ported all detailed descriptions and UI elements from V23 settings files.
 * @MODIFIED: Re-added missing 'related_similarity_threshold' and 'related_position' settings.
 * @MODIFIED: Re-added Manual Generation buttons and log, placing them under their respective tabs.
 * @MODIFIED: Added JavaScript from V23's 2-admin-settings.php to power the manual controls.
 */

if (! defined('ABSPATH')) {
	exit;
}

class NM_Admin_Settings
{


	public static function init()
	{
		add_action('admin_init', array(self::class, 'register_all_settings'));
		// Settings submenu is registered by NM_Admin_Menu::register_settings_submenu()
		// at priority 99 so it always renders last in the MCQ sidebar.
	}

	/**
	 * Registers the "Settings" submenu page.
	 */
	public static function register_submenu()
	{
		add_submenu_page(
			'nm_mcq_generator',
			'MCQ Settings',
			'⚙️ Settings',
			'manage_options',
			'news-mcq-generator',
			array(self::class, 'render_options_page')
		);
	}

	/**
	 * Register ALL settings groups
	 */
	public static function register_all_settings()
	{
		// 1. API Keys
		register_setting('nm_api_keys_group', 'nm_gemini_api_key', array('sanitize_callback' => 'sanitize_text_field'));
		register_setting('nm_api_keys_group', 'nm_pexels_api_key', array('sanitize_callback' => 'sanitize_text_field'));
		register_setting('nm_api_keys_group', 'nm_gnews_api_key', array('sanitize_callback' => 'sanitize_text_field'));
		register_setting('nm_api_keys_group', 'nm_scraper_api_key', array('sanitize_callback' => 'sanitize_text_field'));
		register_setting(
			'nm_api_keys_group',
			'nm_gemini_model_name',
			array(
				'sanitize_callback' => 'sanitize_text_field',
				'default'           => 'gemini-2.5-flash-preview-09-2025',
			)
		);

		// 2. News Generation
		register_setting('nm_news_generation_group', 'nm_news_categories', array('sanitize_callback' => array(self::class, 'sanitize_array')));
		register_setting('nm_news_generation_group', 'nm_news_country', array('sanitize_callback' => 'sanitize_key'));
		register_setting(
			'nm_news_generation_group',
			'nm_news_cron_schedule',
			array(
				'sanitize_callback' => 'sanitize_key',
				'default'           => 'hourly',
			)
		);
		register_setting(
			'nm_news_generation_group',
			'nm_news_generation_enabled',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 0,
			)
		);

		// @NEW 9.2.0: News roundup article generation settings.
		register_setting(
			'nm_news_generation_group',
			'nm_article_generation_enabled',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 0,
			)
		);
		register_setting(
			'nm_news_generation_group',
			'nm_article_auto_publish',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 0,
			)
		);
		register_setting(
			'nm_news_generation_group',
			'nm_article_authors',
			array(
				'sanitize_callback' => array( self::class, 'sanitize_int_array' ),
				'default'           => array(),
			)
		);
		// @FIX 9.3.3: Daily cap on roundup articles (the Current Affairs pipeline runs
		// its worker every ~5 min; without a cap it would spam articles all day).
		register_setting(
			'nm_news_generation_group',
			'nm_article_daily_limit',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 2,
			)
		);

		// @NEW 9.4.0: Topic Pillar generation settings (evergreen SEO/AIO/LLMO pillars).
		register_setting(
			'nm_pillar_generation_group',
			'nm_pillar_generation_enabled',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 0,
			)
		);
		register_setting(
			'nm_pillar_generation_group',
			'nm_pillar_topics',
			array(
				'sanitize_callback' => array( self::class, 'sanitize_int_array' ),
				'default'           => array(),
			)
		);
		register_setting(
			'nm_pillar_generation_group',
			'nm_pillar_exams',
			array(
				'sanitize_callback' => array( self::class, 'sanitize_int_array' ),
				'default'           => array(),
			)
		);
		register_setting(
			'nm_pillar_generation_group',
			'nm_pillar_interval_days',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 7,
			)
		);
		register_setting(
			'nm_pillar_generation_group',
			'nm_pillar_daily_limit',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 3,
			)
		);

		// @NEW 9.5.0: Monthly PDF Archive settings.
		register_setting(
			'nm_pdf_archive_group',
			'nm_pdf_archive_enabled',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 0,
			)
		);
		register_setting(
			'nm_pdf_archive_group',
			'nm_pdf_archive_topics',
			array(
				'sanitize_callback' => array( self::class, 'sanitize_int_array' ),
				'default'           => array(),
			)
		);
		// @NEW 9.5.6: Complete-bank volume cap (questions per PDF volume).
		register_setting(
			'nm_pdf_archive_group',
			'nm_pdf_volume_cap',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 200,
			)
		);

		// 3. Topic Generation
		register_setting('nm_topic_generation_group', 'nm_topic_list_ids', array('sanitize_callback' => array(self::class, 'sanitize_array')));
		register_setting('nm_topic_generation_group', 'nm_topic_mcq_count', array('sanitize_callback' => 'absint'));
		register_setting(
			'nm_topic_generation_group',
			'nm_topic_cron_schedule',
			array(
				'sanitize_callback' => 'sanitize_key',
				'default'           => 'hourly',
			)
		);
		register_setting(
			'nm_topic_generation_group',
			'nm_topic_generation_enabled',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 0,
			)
		);

		// 4. Current Affairs
		register_setting(
			'nm_current_affairs_group',
			'nm_current_affairs_enabled',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 0,
			)
		);
		register_setting(
			'nm_current_affairs_group',
			'nm_current_affairs_pakistan_count',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 1,
			)
		);
		register_setting(
			'nm_current_affairs_group',
			'nm_current_affairs_intl_count',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 1,
			)
		);
		register_setting(
			'nm_current_affairs_group',
			'nm_ca_questions_per_article',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 3,
			)
		);
		// NEW: Worker batch size (how many queued articles per worker run)
		register_setting(
			'nm_current_affairs_group',
			'nm_current_affairs_worker_batch',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 1,
			)
		);
		register_setting(
			'nm_current_affairs_group',
			'nm_current_affairs_max_queue',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 50,
			)
		);
		register_setting(
			'nm_current_affairs_group',
			'nm_current_affairs_cron_schedule',
			array(
				'sanitize_callback' => 'sanitize_key',
				'default'           => 'every_fifteen_minutes',
			)
		);

		// 5. Feed Importer
		register_setting(
			'nm_feed_importer_group',
			'nm_feed_importer_enabled',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 0,
			)
		);
		register_setting('nm_feed_importer_group', 'nm_mcq_feed_url', array('sanitize_callback' => 'esc_url_raw'));
		register_setting(
			'nm_feed_importer_group',
			'nm_feed_importer_cron_schedule',
			array(
				'sanitize_callback' => 'sanitize_key',
				'default'           => 'hourly',
			)
		);
		register_setting(
			'nm_feed_importer_group',
			'nm_feed_importer_max_items',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 10,
			)
		);

		// 6. Duplicate Detection
		register_setting('nm_duplicate_detection_group', 'nm_similarity_threshold', array('sanitize_callback' => 'floatval'));
		register_setting('nm_duplicate_detection_group', 'nm_skip_import_duplicate_check', array('sanitize_callback' => 'absint'));

		// 7. Related Questions
		register_setting(
			'nm_related_questions_group',
			'nm_enable_related_questions',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 1,
			)
		);
		register_setting(
			'nm_related_questions_group',
			'nm_related_questions_count',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 5,
			)
		);
		register_setting(
			'nm_related_questions_group',
			'nm_related_similarity_threshold',
			array(
				'sanitize_callback' => 'floatval',
				'default'           => 0.7,
			)
		);
		register_setting(
			'nm_related_questions_group',
			'nm_related_position',
			array(
				'sanitize_callback' => 'sanitize_key',
				'default'           => 'bottom',
			)
		);
		// ✅ NEW: Global Display Order
		register_setting(
			'nm_related_questions_group',
			'nm_mcq_display_order',
			array(
				'sanitize_callback' => 'sanitize_key',
				'default'           => 'date_desc', // @MODIFIED: Changed default from 'rand' to 'date_desc'
			)
		);

		// 8. Exam Blueprints (per-exam difficulty/Bloom mix + prompt hints)
		register_setting(
			'nm_exam_blueprints_group',
			'nm_exam_blueprints',
			array(
				'sanitize_callback' => array(self::class, 'sanitize_exam_blueprints'),
			)
		);

		// 9. Default exam mapping for generation (same group for single Save button)
		register_setting(
			'nm_exam_blueprints_group',
			'nm_default_exam_for_topics',
			array(
				'sanitize_callback' => 'sanitize_key',
			)
		);
		register_setting(
			'nm_exam_blueprints_group',
			'nm_default_exam_for_news',
			array(
				'sanitize_callback' => 'sanitize_key',
			)
		);
		// 10. Homepage Exam visibility (store array of exam slugs)
		register_setting(
			'nm_related_questions_group',
			'nm_homepage_exam_visibility',
			array(
				'sanitize_callback' => array(self::class, 'sanitize_array'),
			)
		);

        // 11. Social Sharing
        register_setting(
            'nm_social_sharing_group',
            'nm_enable_social_sharing',
            array(
                'sanitize_callback' => 'absint',
                'default'           => 0,
            )
        );

        // ✅ Buffer API Integration Settings
        register_setting(
            'nm_social_sharing_group',
            'nm_buffer_enabled',
            array(
                'sanitize_callback' => 'absint',
                'default'           => 0,
            )
        );
        register_setting(
            'nm_social_sharing_group',
            'nm_buffer_access_token',
            array(
                'sanitize_callback' => 'sanitize_text_field',
                'default'           => '',
            )
        );
        register_setting(
            'nm_social_sharing_group',
            'nm_buffer_daily_limit',
            array(
                'sanitize_callback' => 'absint',
                'default'           => 5,
            )
        );

        // Buffer enabled channels (array of channel IDs).
        register_setting(
            'nm_social_sharing_group',
            'nm_buffer_enabled_channels',
            array(
                'sanitize_callback' => function($value) {
                    return is_array($value) ? array_map('sanitize_text_field', $value) : array();
                },
                'default'           => array(),
            )
        );

        // Buffer channel post types (channel_id => post_type).
        register_setting(
            'nm_social_sharing_group',
            'nm_buffer_channel_types',
            array(
                'sanitize_callback' => function($value) {
                    if (! is_array($value)) {
                        return array();
                    }
                    $sanitized = array();
                    foreach ($value as $channel_id => $post_type) {
                        $sanitized[sanitize_text_field($channel_id)] = sanitize_text_field($post_type);
                    }
                    return $sanitized;
                },
                'default'           => array(),
            )
        );

        // Buffer channel sharing modes (channel_id => now|queue|draft).
        register_setting(
            'nm_social_sharing_group',
            'nm_buffer_channel_modes',
            array(
                'sanitize_callback' => function($value) {
                    if (! is_array($value)) {
                        return array();
                    }
                    $sanitized = array();
                    foreach ($value as $channel_id => $mode) {
                        $sanitized[sanitize_text_field($channel_id)] = sanitize_text_field($mode);
                    }
                    return $sanitized;
                },
                'default'           => array(),
            )
        );

        // Buffer channel message templates (channel_id => template string).
        register_setting(
            'nm_social_sharing_group',
            'nm_buffer_channel_templates',
            array(
                'sanitize_callback' => function($value) {
                    if (! is_array($value)) {
                        return array();
                    }
                    $sanitized = array();
                    foreach ($value as $channel_id => $template) {
                        $sanitized[sanitize_text_field($channel_id)] = wp_kses_post($template);
                    }
                    return $sanitized;
                },
                'default'           => array(),
            )
        );

        // Buffer channel link post toggle (channel_id => 1 for link post, 0 for image post).
        register_setting(
            'nm_social_sharing_group',
            'nm_buffer_channel_link_posts',
            array(
                'sanitize_callback' => function($value) {
                    if (! is_array($value)) {
                        return array();
                    }
                    $sanitized = array();
                    foreach ($value as $channel_id => $enabled) {
                        $sanitized[sanitize_text_field($channel_id)] = absint($enabled);
                    }
                    return $sanitized;
                },
                'default'           => array(),
            )
        );

        // Buffer Pinterest board selection (channel_id => board_service_id).
        register_setting(
            'nm_social_sharing_group',
            'nm_buffer_channel_pinterest_boards',
            array(
                'sanitize_callback' => function($value) {
                    if (! is_array($value)) {
                        return array();
                    }
                    $sanitized = array();
                    foreach ($value as $channel_id => $board_id) {
                        $sanitized[sanitize_text_field($channel_id)] = sanitize_text_field($board_id);
                    }
                    return $sanitized;
                },
                'default'           => array(),
            )
        );

        // Buffer Pinterest pin title templates (channel_id => title template string).
        register_setting(
            'nm_social_sharing_group',
            'nm_buffer_channel_pinterest_titles',
            array(
                'sanitize_callback' => function($value) {
                    if (! is_array($value)) {
                        return array();
                    }
                    $sanitized = array();
                    foreach ($value as $channel_id => $title) {
                        $sanitized[sanitize_text_field($channel_id)] = sanitize_text_field($title);
                    }
                    return $sanitized;
                },
                'default'           => array(),
            )
        );

        // Buffer channel story sharing toggle (channel_id => 1 for also share as story).
        register_setting(
            'nm_social_sharing_group',
            'nm_buffer_channel_share_story',
            array(
                'sanitize_callback' => function($value) {
                    if (! is_array($value)) {
                        return array();
                    }
                    $sanitized = array();
                    foreach ($value as $channel_id => $enabled) {
                        $sanitized[sanitize_text_field($channel_id)] = absint($enabled);
                    }
                    return $sanitized;
                },
                'default'           => array(),
            )
        );

        $default_template = "{question}\n\n{options}\n{link}\n\nLearn daily with thequizwire.com\n\nFollow WhatsApp Channel \n[Link of Channel]\n\nFollow YouTube Channel \n\n[Link of YT channel]\n\n#TheQuizWire #MCQs {tags}\n\nthequizwire GK MCQs";

        register_setting(
            'nm_social_sharing_group',
            'nm_jetpack_enabled',
            array(
                'sanitize_callback' => 'absint',
                'default'           => 1,
            )
        );
        register_setting(
            'nm_social_sharing_group',
            'nm_jetpack_template',
            array(
                'sanitize_callback' => 'wp_kses_post',
                'default'           => $default_template,
            )
        );

        register_setting(
            'nm_social_sharing_group',
            'nm_jetpack_daily_limit',
            array(
                'sanitize_callback' => 'absint',
                'default' => 5,
            )
        );

        register_setting(
            'nm_social_sharing_group',
            'nm_default_social_image',
            array(
                'sanitize_callback' => 'absint',
                'default' => 0,
            )
        );

		// 12. Uninstall Settings
		register_setting('nm_uninstall_settings_group', 'nm_preserve_settings_on_uninstall', array('sanitize_callback' => 'sanitize_key'));
		register_setting('nm_uninstall_settings_group', 'nm_remove_tables_on_uninstall', array('sanitize_callback' => 'sanitize_key'));
		register_setting('nm_uninstall_settings_group', 'nm_delete_posts_on_uninstall', array('sanitize_callback' => 'sanitize_key'));
		register_setting('nm_uninstall_settings_group', 'nm_delete_user_data_on_uninstall', array('sanitize_callback' => 'sanitize_key'));

		// Dashboard Integration
		register_setting(
			'nm_uninstall_settings_group',
			'nm_dashboard_api_key',
			array(
				'sanitize_callback' => 'sanitize_text_field',
				'default'           => '',
			)
		);

		// ✅ NEW: Log retention setting (single source of truth lives in NM_Generation_Logger).
		register_setting(
			'nm_uninstall_settings_group',
			'nm_log_retention_days',
			array(
				'sanitize_callback' => array( self::class, 'sanitize_log_retention_days' ),
				'default'           => class_exists( 'NM_Generation_Logger' ) ? NM_Generation_Logger::DEFAULT_RETENTION_DAYS : 30,
			)
		);

		// ✅ NEW v7.3.6: Engagement (Notifications + PWA)
		register_setting(
			'nm_engagement_group',
			'nm_notifications_enabled',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 1,
			)
		);
		register_setting(
			'nm_engagement_group',
			'nm_daily_digest_time',
			array(
				'sanitize_callback' => 'sanitize_key',
				'default'           => '08',
			)
		);
		register_setting(
			'nm_engagement_group',
			'nm_notification_check_interval',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 30000,
			)
		);
		register_setting(
			'nm_engagement_group',
			'nm_pwa_prompt_enabled',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 1,
			)
		);
		register_setting(
			'nm_engagement_group',
			'nm_pwa_delay_seconds',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 5,
			)
		);
		register_setting(
			'nm_engagement_group',
			'nm_pwa_required_visits',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 3,
			)
		);

		// 13. Scheduler Settings
		register_setting(
			'nm_scheduler_settings_group',
			'nm_scheduler_enabled',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 0,
			)
		);
		register_setting(
			'nm_scheduler_settings_group',
			'nm_scheduler_window_start',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 9,
			)
		);
		register_setting(
			'nm_scheduler_settings_group',
			'nm_scheduler_window_end',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 21,
			)
		);
		register_setting(
			'nm_scheduler_settings_group',
			'nm_scheduler_min_gap',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 15,
			)
		);
		register_setting(
			'nm_scheduler_settings_group',
			'nm_scheduler_max_gap',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 60,
			)
		);
		register_setting(
			'nm_scheduler_settings_group',
			'nm_scheduler_max_per_day',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 50,
			)
		);
		// @MODIFIED: Added min_per_day for randomization support
		register_setting(
			'nm_scheduler_settings_group',
			'nm_scheduler_min_per_day',
			array(
				'sanitize_callback' => 'absint',
				'default'           => 10,
			)
		);
		register_setting(
			'nm_scheduler_settings_group',
			'nm_scheduler_hot_topics',
			array(
				'sanitize_callback' => array(self::class, 'sanitize_array'),
				'default'           => array(),
			)
		);
		register_setting(
			'nm_scheduler_settings_group',
			'nm_scheduler_hot_exams',
			array(
				'sanitize_callback' => array(self::class, 'sanitize_array'),
				'default'           => array(),
			)
		);
	}

	public static function sanitize_array($input)
	{
		return is_array($input) ? array_map('sanitize_text_field', $input) : array();
	}

	/**
	 * @NEW 9.2.0: Sanitize an array of integer IDs (author user IDs).
	 */
	public static function sanitize_int_array($input)
	{
		if (! is_array($input)) {
			return array();
		}
		return array_values(array_map('absint', array_filter(array_map('absint', $input))));
	}

	/**
	 * ✅ NEW: Sanitize the log retention setting. Falls back to the logger's
	 * safe default if the value is missing/garbage.
	 */
	public static function sanitize_log_retention_days($input)
	{
		$default = class_exists('NM_Generation_Logger') ? NM_Generation_Logger::DEFAULT_RETENTION_DAYS : 30;
		$min     = class_exists('NM_Generation_Logger') ? NM_Generation_Logger::MIN_RETENTION_DAYS : 1;
		$max     = class_exists('NM_Generation_Logger') ? NM_Generation_Logger::MAX_RETENTION_DAYS : 365;

		$value = is_numeric($input) ? (int) $input : $default;
		if ($value < $min) {
			$value = $min;
		}
		if ($value > $max) {
			$value = $max;
		}
		return $value;
	}
	public static function sanitize_exam_blueprints($input)
	{
		if (! is_array($input)) {
			return array();
		}

		$output = array();

		foreach ($input as $slug => $config) {
			$slug = sanitize_key($slug);
			if (! $slug) {
				continue;
			}

			$difficulty = $config['difficulty'] ?? array();
			$bloom      = $config['bloom'] ?? array();

			$easy   = isset($difficulty['easy']) ? max(0, min(100, (int) $difficulty['easy'])) : 0;
			$medium = isset($difficulty['medium']) ? max(0, min(100, (int) $difficulty['medium'])) : 0;
			$hard   = isset($difficulty['hard']) ? max(0, min(100, (int) $difficulty['hard'])) : 0;

			$remember   = isset($bloom['remember']) ? max(0, min(100, (int) $bloom['remember'])) : 0;
			$understand = isset($bloom['understand']) ? max(0, min(100, (int) $bloom['understand'])) : 0;
			$apply      = isset($bloom['apply']) ? max(0, min(100, (int) $bloom['apply'])) : 0;
			$analyze    = isset($bloom['analyze']) ? max(0, min(100, (int) $bloom['analyze'])) : 0;
			$evaluate   = isset($bloom['evaluate']) ? max(0, min(100, (int) $bloom['evaluate'])) : 0;

			$prompt_hint = isset($config['prompt_hint'])
				? sanitize_textarea_field($config['prompt_hint'])
				: '';

			$output[$slug] = array(
				'difficulty'  => array(
					'easy'   => $easy,
					'medium' => $medium,
					'hard'   => $hard,
				),
				'bloom'       => array(
					'remember'   => $remember,
					'understand' => $understand,
					'apply'      => $apply,
					'analyze'    => $analyze,
					'evaluate'   => $evaluate,
				),
				'prompt_hint' => $prompt_hint,
			);
		}

		return $output;
	}
	/**
	 * Render Main Options Page
	 */
	public static function render_options_page()
	{
		if (! current_user_can('manage_options')) {
			return;
		}
		$active_tab = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : 'api_keys';
?>
		<div class="wrap">
			<h1><?php echo esc_html(get_admin_page_title()); ?></h1>
			<?php
			// ✅ START: ADD THIS BLOCK TO SHOW THE "SETTINGS SAVED" NOTICE
			if (isset($_GET['settings-updated']) && $_GET['settings-updated']) {
				add_settings_error(
					'nm_settings_messages',
					'nm_settings_saved',
					__('Settings saved successfully.', 'wp-news-mcq-generator'),
					'updated' // This makes it the green "success" box
				);
			}
			// This function prints any notices we've just added
			settings_errors('nm_settings_messages');
			// ✅ END: ADDED BLOCK
			?>
			<h2 class="nav-tab-wrapper">
				<a href="?page=news-mcq-generator&tab=api_keys" class="nav-tab <?php echo $active_tab === 'api_keys' ? 'nav-tab-active' : ''; ?>">🔑 API Keys</a>
				<a href="?page=news-mcq-generator&tab=news_generation" class="nav-tab <?php echo $active_tab === 'news_generation' ? 'nav-tab-active' : ''; ?>">📰 News</a>
				<a href="?page=news-mcq-generator&tab=topic_generation" class="nav-tab <?php echo $active_tab === 'topic_generation' ? 'nav-tab-active' : ''; ?>">📚 Topics</a>
				<a href="?page=news-mcq-generator&tab=current_affairs" class="nav-tab <?php echo $active_tab === 'current_affairs' ? 'nav-tab-active' : ''; ?>">🌍 Current Affairs</a>
				<a href="?page=news-mcq-generator&tab=feed_importer" class="nav-tab <?php echo $active_tab === 'feed_importer' ? 'nav-tab-active' : ''; ?>">🔗 Feed</a>
				<a href="?page=news-mcq-generator&tab=duplicate" class="nav-tab <?php echo $active_tab === 'duplicate' ? 'nav-tab-active' : ''; ?>">🔍 Duplicates</a>
				<a href="?page=news-mcq-generator&tab=exam_blueprints" class="nav-tab <?php echo $active_tab === 'exam_blueprints' ? 'nav-tab-active' : ''; ?>">📘 Blueprints</a>
				<a href="?page=news-mcq-generator&tab=related" class="nav-tab <?php echo $active_tab === 'related' ? 'nav-tab-active' : ''; ?>">🔗 Related</a>
				<a href="?page=news-mcq-generator&tab=social" class="nav-tab <?php echo $active_tab === 'social' ? 'nav-tab-active' : ''; ?>">📱 Social</a>
				<a href="?page=news-mcq-generator&tab=engagement" class="nav-tab <?php echo $active_tab === 'engagement' ? 'nav-tab-active' : ''; ?>">💡 Engagement</a>
				<a href="?page=news-mcq-generator&tab=scheduler" class="nav-tab <?php echo $active_tab === 'scheduler' ? 'nav-tab-active' : ''; ?>">📅 Scheduler</a>
				<a href="?page=news-mcq-generator&tab=pillars" class="nav-tab <?php echo $active_tab === 'pillars' ? 'nav-tab-active' : ''; ?>">🧭 Pillars</a>
				<a href="?page=news-mcq-generator&tab=pdf_archive" class="nav-tab <?php echo $active_tab === 'pdf_archive' ? 'nav-tab-active' : ''; ?>">📥 Monthly PDF</a>
				<a href="?page=news-mcq-generator&tab=uninstall" class="nav-tab <?php echo $active_tab === 'uninstall' ? 'nav-tab-active' : ''; ?>">🗑️ Uninstall</a>
			</h2>


			<form method="post" action="options.php">
				<?php
				switch ($active_tab) {
					case 'api_keys':
						settings_fields('nm_api_keys_group');
						self::render_api_keys_tab();
						break;
					case 'news_generation':
						settings_fields('nm_news_generation_group');
						self::render_news_generation_tab();
						break;
					case 'topic_generation':
						settings_fields('nm_topic_generation_group');
						self::render_topic_generation_tab();
						break;
					case 'current_affairs':
						settings_fields('nm_current_affairs_group');
						self::render_current_affairs_tab();
						break;
					case 'feed_importer':
						settings_fields('nm_feed_importer_group');
						self::render_feed_importer_tab();
						break;
					case 'duplicate':
						settings_fields('nm_duplicate_detection_group');
						self::render_duplicate_tab();
						break;
					case 'exam_blueprints':
						settings_fields('nm_exam_blueprints_group');
						self::render_exam_blueprints_tab();
						break;
					case 'related':
						settings_fields('nm_related_questions_group');
						self::render_related_tab();
						break;
					case 'social':
						settings_fields('nm_social_sharing_group');
						self::render_social_tab();
						break;
					case 'engagement':
						settings_fields('nm_engagement_group');
						self::render_engagement_tab();
						break;
					case 'scheduler':
						settings_fields('nm_scheduler_settings_group');
						self::render_scheduler_tab();
						break;
					case 'pillars':
						settings_fields('nm_pillar_generation_group');
						self::render_pillar_generation_tab();
						break;
					case 'pdf_archive':
						settings_fields('nm_pdf_archive_group');
						self::render_pdf_archive_tab();
						break;
					case 'uninstall':
						settings_fields('nm_uninstall_settings_group');
						self::render_uninstall_tab();
						break;
				}
				submit_button();
				?>
			</form>

			<?php
			// ✅ Render spike form separately for scheduler tab to avoid nesting
			if ($active_tab === 'scheduler') {
				self::render_spike_form();
			}
			?>

			<div id="nm-generation-log-wrapper" style="display: none;">
				<h3>📋 Generation Log</h3>
				<pre id="nm-generation-log" style="background: #f7f7f7; border: 1px solid #ccc; padding: 15px; border-radius: 4px; max-height: 400px; overflow-y: auto; font-size: 13px; line-height: 1.6;">Ready to begin. Click a button above to start generation.</pre>
			</div>

			<script type="text/javascript">
				jQuery(document).ready(function($) {
					'use strict';

					// Define nonces
					const generateNonce = '<?php echo wp_create_nonce('nm_ajax_generate_nonce'); ?>';
					const adminNonce = '<?php echo wp_create_nonce('nm_admin_action'); ?>'; // For feed import

					const logContainer = $('#nm-generation-log');
					const logWrapper = $('#nm-generation-log-wrapper');

					// Get all buttons
					const newsBtn = $('#nm-manual-generate-btn');
					const topicBtn = $('#nm-manual-topic-generate-btn');
					const feedBtn = $('#nm-manual-import-btn');

					function disableButtons() {
						newsBtn.prop('disabled', true);
						topicBtn.prop('disabled', true);
						feedBtn.prop('disabled', true);
					}

					function enableButtons() {
						newsBtn.prop('disabled', false);
						topicBtn.prop('disabled', false);
						feedBtn.prop('disabled', false);
					}

					// NEWS GENERATION
					newsBtn.on('click', function() {
						const spinner = $('#nm-news-spinner');
						const categories = <?php echo json_encode(get_option('nm_news_categories', array())); ?>;

						if (categories.length === 0) {
							logWrapper.show();
							logContainer.text('ERROR: Please select at least one news category and save settings first.');
							return;
						}

						let i = 0;
						disableButtons();
						spinner.addClass('is-active');
						logWrapper.show();
						logContainer.text('Starting news-based generation...\n');

						function processNextCategory() {
							if (i >= categories.length) {
								logContainer.append('\n✅ News generation complete!');
								enableButtons();
								spinner.removeClass('is-active');
								return;
							}

							logContainer.append('\n📰 Processing category: ' + categories[i] + '...');

							$.ajax({
								url: ajaxurl,
								type: 'POST',
								data: {
									action: 'nm_run_generation_for_category',
									category: categories[i],
									_ajax_nonce: generateNonce
								},
								success: function(res) {
									if (res.success && res.data.log) {
										logContainer.append('\n' + res.data.log.join('\n'));
									} else {
										logContainer.append('\n❌ ERROR: ' + (res.data.message || 'Unknown error'));
									}
								},
								error: function() {
									logContainer.append('\n❌ Server error for category: ' + categories[i]);
								},
								complete: function() {
									i++;
									setTimeout(processNextCategory, 500);
								}
							});
						}
						processNextCategory();
					});

					// TOPIC GENERATION
					topicBtn.on('click', function() {
						const spinner = $('#nm-topic-spinner');
						const topicIds = <?php echo json_encode(get_option('nm_topic_list_ids', array())); ?>;

						if (topicIds.length === 0) {
							logWrapper.show();
							logContainer.text('ERROR: Please select at least one topic and save settings first.');
							return;
						}

						let i = 0;
						disableButtons();
						spinner.addClass('is-active');
						logWrapper.show();
						logContainer.text('Starting topic-based generation...\n');

						function processNextTopic() {
							if (i >= topicIds.length) {
								logContainer.append('\n✅ Topic generation complete!');
								enableButtons();
								spinner.removeClass('is-active');
								return;
							}

							logContainer.append('\n📚 Processing topic ID: ' + topicIds[i] + '...');

							$.ajax({
								url: ajaxurl,
								type: 'POST',
								data: {
									action: 'nm_run_generation_for_topic',
									topic_id: topicIds[i],
									_ajax_nonce: generateNonce
								},
								success: function(res) {
									if (res.success && res.data.log) {
										logContainer.append('\n' + res.data.log.join('\n'));
									} else {
										logContainer.append('\n❌ ERROR: ' + (res.data.message || 'Unknown error'));
									}
								},
								error: function() {
									logContainer.append('\n❌ Server error for topic ID: ' + topicIds[i]);
								},
								complete: function() {
									i++;
									setTimeout(processNextTopic, 500);
								}
							});
						}
						processNextTopic();
					});

					// FEED IMPORT
					feedBtn.on('click', function() {
						const spinner = $('#nm-feed-spinner');

						disableButtons();
						spinner.addClass('is-active');
						logWrapper.show();
						logContainer.text('Starting feed import...\n');

						$.ajax({
							url: ajaxurl,
							type: 'POST',
							data: {
								action: 'nm_run_feed_import',
								_ajax_nonce: adminNonce // ✅ Use the correct nonce for this action
							},
							timeout: 120000,
							success: function(res) {
								if (res.success) {
									if (res.data.log) {
										logContainer.text(res.data.log.join('\n'));
									}
									logContainer.append('\n\n✅ SUCCESS: Created ' + (res.data.count || 0) + ' new MCQs.');
								} else {
									logContainer.text('❌ ERROR: ' + (res.data.message || 'Unknown error'));
								}
							},
							error: function(jqXHR, textStatus) {
								logContainer.text('❌ Server error: ' + textStatus);
							},
							complete: function() {
								enableButtons();
								spinner.removeClass('is-active');
							}
						});
					});

					// SYNC AUTHORS
					$('#nm-sync-authors-btn').on('click', function() {
						const btn = $(this);
						const spinner = $('#nm-sync-spinner');

						if (!confirm('This will update author names for ALL MCQs that are currently anonymous or set to "TheQuizWire". Proceed?')) {
							return;
						}

						disableButtons();
						btn.prop('disabled', true);
						spinner.addClass('is-active');
						logWrapper.show();
						logContainer.text('Starting Author Sync...\n');

						$.ajax({
							url: ajaxurl,
							type: 'POST',
							data: {
								action: 'nm_sync_post_authors',
								_ajax_nonce: adminNonce
							},
							success: function(res) {
								if (res.success) {
									logContainer.append('\n✅ SUCCESS: ' + (res.data.message || 'Authors synchronized.'));
								} else {
									logContainer.append('\n❌ ERROR: ' + (res.data.message || 'Unknown error'));
								}
							},
							error: function() {
								logContainer.append('\n❌ Server error during sync.');
							},
						complete: function() {
							enableButtons();
							btn.prop('disabled', false);
							spinner.removeClass('is-active');
						}
					});
				});

				// @NEW 9.5.5: CONVERT GENERATED POSTS TO GUTENBERG BLOCKS
				$('#nm-convert-blocks-btn').on('click', function() {
					const btn = $(this);
					const spinner = $('#nm-convert-blocks-spinner');
					const status = $('#nm-convert-blocks-status');

					if (!confirm('This will convert all previously generated posts (pillars, roundups, PDF archive pages) from classic HTML to Gutenberg block markup. Posts already in blocks are skipped; frontend output is unchanged. Continue?')) {
						return;
					}

					disableButtons();
					btn.prop('disabled', true);
					spinner.addClass('is-active');
					status.html('<p style="color:#666;">🧱 Converting posts to blocks in batches... <strong id="nm-convert-blocks-progress">starting</strong></p>');

					const batchSize = 25;
					let totalConverted = 0;

					function runBlocksBatch() {
						$.ajax({
							url: ajaxurl,
							type: 'POST',
							data: {
								action: 'nm_convert_blocks',
								_ajax_nonce: adminNonce,
								batch_size: batchSize
							},
							timeout: 120000,
							success: function(res) {
								if (res.success) {
									const d = res.data || {};
									totalConverted += (d.converted || 0);
									$('#nm-convert-blocks-progress').text(
										totalConverted + ' converted, ' + (d.remaining || 0) + ' left'
									);
									if (d.done || (d.remaining || 0) <= 0) {
										status.html(
											'<div class="notice notice-success" style="padding:10px; margin:0;"><p><strong>✅ Complete!</strong></p>' +
											'<p>' + (d.message || 'All generated posts are now stored as Gutenberg blocks.') + ' (' + totalConverted + ' converted this run.)</p></div>'
										);
										enableButtons();
										btn.prop('disabled', false);
										spinner.removeClass('is-active');
									} else {
										setTimeout(runBlocksBatch, 300);
									}
								} else {
									status.html(
										'<div class="notice notice-error" style="padding:10px; margin:0;"><p>❌ ' +
										((res.data && res.data.message) || 'Unknown error') + '</p></div>'
									);
									enableButtons();
									btn.prop('disabled', false);
									spinner.removeClass('is-active');
								}
							},
							error: function() {
								status.html(
									'<div class="notice notice-error" style="padding:10px; margin:0;"><p>❌ Server error during conversion. It is resumable — click the button again and it will skip already-converted posts and continue.</p></div>'
								);
								enableButtons();
								btn.prop('disabled', false);
								spinner.removeClass('is-active');
							}
						});
					}
					runBlocksBatch();
				});

				// ASSIGN RANDOM AUTHORS
				$('#nm-assign-random-authors-btn').on('click', function() {
					const btn = $(this);
					const spinner = $('#nm-assign-random-spinner');
					const status = $('#nm-assign-random-status');

					if (!confirm('This will assign a RANDOM author (from your Named Authors list) to every MCQ that does not already have a named author. MCQs that already have an author are SKIPPED. It runs in batches so large libraries won\'t time out. Continue?')) {
						return;
					}

					disableButtons();
					btn.prop('disabled', true);
					spinner.addClass('is-active');
					status.html('<p style="color:#666;">🎲 Assigning random authors in batches... <strong id="nm-assign-progress">starting</strong></p>');

					const batchSize = 25; // small batch per request — robust even on large libraries

					function runBatch() {
						$.ajax({
							url: ajaxurl,
							type: 'POST',
							data: {
								action: 'nm_assign_random_authors',
								_ajax_nonce: adminNonce,
								batch_size: batchSize
							},
							timeout: 120000, // 2 minutes per batch (well under server timeouts)
							success: function(res) {
								if (res.success) {
									const d = res.data || {};
									$('#nm-assign-progress').text(
										(d.processed || 0) + ' assigned, ' + (d.remaining || 0) + ' left'
									);
									if (d.done || (d.remaining || 0) <= 0) {
										status.html(
											'<div class="notice notice-success" style="padding:10px; margin:0;"><p><strong>✅ Complete!</strong></p>' +
											'<p>' + (d.message || 'All MCQs now have a named author.') + '</p></div>'
										);
										enableButtons();
										btn.prop('disabled', false);
										spinner.removeClass('is-active');
									} else {
										// Continue with the next batch after a short pause to
										// avoid overwhelming the server.
										setTimeout(runBatch, 300);
									}
								} else {
									status.html(
										'<div class="notice notice-error" style="padding:10px; margin:0;"><p>❌ ' +
										((res.data && res.data.message) || 'Unknown error') + '</p></div>'
									);
									enableButtons();
									btn.prop('disabled', false);
									spinner.removeClass('is-active');
								}
							},
							error: function() {
								status.html(
									'<div class="notice notice-error" style="padding:10px; margin:0;"><p>❌ Server error while assigning authors. It may have partially completed — just click the button again and it will skip already-assigned MCQs and continue.</p></div>'
								);
								enableButtons();
								btn.prop('disabled', false);
								spinner.removeClass('is-active');
							}
						});
					}

					runBatch();
				});

				// RUN MONTHLY PDF ARCHIVE NOW
				$('#nm-run-pdf-archive-btn').on('click', function() {
					const btn = $(this);
					const spinner = $('#nm-pdf-archive-spinner');
					const status = $('#nm-pdf-archive-status');

					if (!confirm('Generate the monthly PDFs now for all selected topics? PDFs are generated for the previous completed month, and can take up to a few minutes. Continue?')) {
						return;
					}

					btn.prop('disabled', true);
					spinner.addClass('is-active');
					status.html('<p style="color:#666;">Generating monthly PDFs... this can take a couple of minutes for large topics.</p>');

					$.ajax({
						url: ajaxurl,
						type: 'POST',
						data: {
							action: 'nm_run_pdf_archive',
							_ajax_nonce: adminNonce
						},
						timeout: 300000, // 5 minutes
						success: function(res) {
							if (res.success) {
								const d = res.data || {};
								let linksHtml = '';
								if (d.results && d.results.length) {
									linksHtml = '<ul style="margin:6px 0 0 18px;">';
									d.results.forEach(function(r) {
										let editLink = '';
										if (r.edit_url) editLink = ' <a href="' + r.edit_url + '" target="_blank">Edit page</a>';
										linksHtml += '<li>' + r.topic + ': ' + (r.count || 0) + ' MCQs' + editLink + '</li>';
									});
									linksHtml += '</ul>';
								}
								const errHtml = (d.errors && d.errors.length) ? '<p style="color:#dc3232;">' + d.errors.join('<br>') + '</p>' : '';
								status.html(
									'<div class="notice notice-success" style="padding:10px; margin:0;"><p><strong>✅ Done!</strong> ' +
									(d.message || 'PDFs generated.') + '</p>' + linksHtml + errHtml + '</div>'
								);
							} else {
								status.html(
									'<div class="notice notice-error" style="padding:10px; margin:0;"><p>❌ ' +
									((res.data && res.data.message) || 'Could not generate PDFs.') + '</p></div>'
								);
							}
						},
						error: function() {
							status.html(
								'<div class="notice notice-error" style="padding:10px; margin:0;"><p>❌ Server error while generating PDFs. It may have partially completed — run again and it will skip already-generated months.</p></div>'
							);
						},
						complete: function() {
							btn.prop('disabled', false);
							spinner.removeClass('is-active');
						}
					});
				});

				// RUN DAILY ROUNDUP NOW
				$('#nm-run-daily-roundup-btn').on('click', function() {
					const btn = $(this);
					const spinner = $('#nm-run-roundup-spinner');
					const status = $('#nm-run-roundup-status');

					if (!confirm('Generate today\'s daily practice roundup now? Only one is created per day, and it will be saved as a Draft / queued via the Scheduler. Continue?')) {
						return;
					}

					btn.prop('disabled', true);
					spinner.addClass('is-active');
					status.html('<p style="color:#666;">Generating today\'s daily roundup... this can take up to a minute.</p>');

					$.ajax({
						url: ajaxurl,
						type: 'POST',
						data: {
							action: 'nm_run_daily_roundup',
							_ajax_nonce: adminNonce
						},
						timeout: 180000, // 3 minutes
						success: function(res) {
							if (res.success) {
								const d = res.data || {};
								let linkHtml = '';
								if (d.edit_url) {
									linkHtml = ' <a href="' + d.edit_url + '" target="_blank">Edit this roundup →</a>';
								}
								status.html(
									'<div class="notice notice-success" style="padding:10px; margin:0;"><p><strong>✅ Done!</strong> ' +
									(d.message || 'Daily roundup created.') + '</p>' + linkHtml + '</div>'
								);
							} else {
								status.html(
									'<div class="notice notice-error" style="padding:10px; margin:0;"><p>❌ ' +
									((res.data && res.data.message) || 'Could not generate the daily roundup.') + '</p></div>'
								);
							}
						},
						error: function() {
							status.html(
								'<div class="notice notice-error" style="padding:10px; margin:0;"><p>❌ Server error while generating the daily roundup. Check the browser console.</p></div>'
							);
						},
						complete: function() {
							btn.prop('disabled', false);
							spinner.removeClass('is-active');
						}
					});
				});
			});
		</script>
		</div>
	<?php
	}

	private static function render_scheduler_tab()
	{
		$enabled     = get_option('nm_scheduler_enabled', 0);
		$start_hour  = get_option('nm_scheduler_window_start', 9);
		$end_hour    = get_option('nm_scheduler_window_end', 21);
		$min_gap     = get_option('nm_scheduler_min_gap', 15);
		$max_gap     = get_option('nm_scheduler_max_gap', 60);
		$max_per_day = get_option('nm_scheduler_max_per_day', 50);
		// @MODIFIED: Added min_per_day for randomization support
		$min_per_day = get_option('nm_scheduler_min_per_day', 10);

		// Hot Topics & Exams
		$hot_topics = get_option('nm_scheduler_hot_topics', array());
		$hot_exams  = get_option('nm_scheduler_hot_exams', array());

	?>
		<h3>📅 Human-Like Publication Scheduler</h3>
		<p>
			When enabled, generated MCQs are saved as <strong>Drafts</strong> and published one by one
			within your specified daily window. This mimics human activity and improves SEO signals.
		</p>

		<table class="form-table">
			<tr>
				<th scope="row">Enable Smart Scheduler</th>
				<td>
					<label>
						<input type="checkbox" name="nm_scheduler_enabled" value="1" <?php checked($enabled, 1); ?>>
						<strong>Force "Smart Schedule" for ALL generations</strong>
					</label>
					<p class="description">
						When enabled, this will override all individual generation settings and force ALL MCQs
						(News, Topics, Feeds, Current Affairs, Manual Imports) to be saved as drafts and queued for scheduled publishing.
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row">Daily Window</th>
				<td>
					Start Hour: <input type="number" name="nm_scheduler_window_start" value="<?php echo intval($start_hour); ?>" min="0" max="23" class="small-text">
					&nbsp;&nbsp;
					End Hour: <input type="number" name="nm_scheduler_window_end" value="<?php echo intval($end_hour); ?>" min="0" max="23" class="small-text">
					<p class="description">The scheduler will only publish between these hours (0-23) in your site's timezone.</p>
				</td>
			</tr>
			<tr>
				<th scope="row">Publication Intervals</th>
				<td>
					Min Gap (min): <input type="number" name="nm_scheduler_min_gap" value="<?php echo intval($min_gap); ?>" min="1" max="1440" class="small-text">
					&nbsp;&nbsp;
					Max Gap (min): <input type="number" name="nm_scheduler_max_gap" value="<?php echo intval($max_gap); ?>" min="1" max="1440" class="small-text">
					<p class="description">Random delay between publications. The scheduler picks a random time between Min and Max.</p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="nm_scheduler_max_per_day">Max Posts Per Day</label></th>
				<td>
					<input type="number" id="nm_scheduler_max_per_day" name="nm_scheduler_max_per_day" value="<?php echo intval($max_per_day); ?>" min="1" max="500" class="small-text">
					<p class="description">Maximum number of MCQs the scheduler is allowed to publish in a single day.</p>
				</td>
			</tr>
			<?php // @MODIFIED: Added Min Posts Per Day UI field 
			?>
			<tr>
				<th scope="row"><label for="nm_scheduler_min_per_day">Min Posts Per Day</label></th>
				<td>
					<input type="number" id="nm_scheduler_min_per_day" name="nm_scheduler_min_per_day" value="<?php echo intval($min_per_day); ?>" min="1" max="500" class="small-text">
					<p class="description">Setting a Min and Max value will cause the scheduler to pick a randomized target each day.</p>
				</td>
			</tr>
			<tr>
				<th scope="row">Hot Topics (Priority)</th>
				<td>
					<?php
					$all_topics = get_terms(
						array(
							'taxonomy'   => 'topic',
							'hide_empty' => false,
							'parent'     => 0, // @MODIFIED: Show only parent topics
						)
					);
					if (! empty($all_topics)) {
						echo '<div style="max-height: 150px; overflow-y: auto; border: 1px solid #ccd0d4; padding: 10px; background: #fff;">';
						foreach ($all_topics as $topic) {
							$checked = in_array($topic->term_id, $hot_topics);
							echo '<label style="display: block; margin-bottom: 5px;">';
							echo '<input type="checkbox" name="nm_scheduler_hot_topics[]" value="' . esc_attr($topic->term_id) . '" ' . checked($checked, true, false) . '> ';
							echo esc_html($topic->name);
							echo '</label>';
						}
						echo '</div>';
					} else {
						echo '<p>No topics found.</p>';
					}
					?>
					<p class="description">MCQs from these topics will be prioritized for publication (weighted random selection).</p>
				</td>
			</tr>
			<tr>
				<th scope="row">Hot Exams (Priority)</th>
				<td>
					<?php
					// @MODIFIED v7.3.15: Fixed taxonomy name from 'exam' to 'nm_exam'
					$all_exams = get_terms(
						array(
							'taxonomy'   => 'nm_exam',
							'hide_empty' => false,
						)
					);
					if (! empty($all_exams)) {
						echo '<div style="max-height: 150px; overflow-y: auto; border: 1px solid #ccd0d4; padding: 10px; background: #fff;">';
						foreach ($all_exams as $exam) {
							$checked = in_array($exam->term_id, $hot_exams);
							echo '<label style="display: block; margin-bottom: 5px;">';
							echo '<input type="checkbox" name="nm_scheduler_hot_exams[]" value="' . esc_attr($exam->term_id) . '" ' . checked($checked, true, false) . '> ';
							echo esc_html($exam->name);
							echo '</label>';
						}
						echo '</div>';
					} else {
						echo '<p>No exams found.</p>';
					}
					?>
					<p class="description">MCQs from these exams will be prioritized for publication (weighted random selection).</p>
				</td>
			</tr>
		</table>
	<?php
	}
	/**
	 * Render the manual spike form (separate from settings form to avoid nesting)
	 */
	private static function render_spike_form()
	{
		// Only show if scheduler is enabled
		if (! (int) get_option('nm_scheduler_enabled', 0)) {
			return;
		}

		$queue_count = get_posts(
			array(
				'post_type'      => 'mcq',
				'post_status'    => 'draft',
				'posts_per_page' => 1,
				'meta_query'     => array(
					'relation' => 'OR',
					array(
						'key'   => '_nm_ready_for_publish',
						'value' => 'yes',
					),
					array(
						'key'   => 'nmreadyforpublish',
						'value' => 'yes',
					),
				),
				'fields'         => 'ids',
			)
		);

		$queue_size = count($queue_count) > 0 ? wp_count_posts('mcq')->draft : 0;

		// Get today's stats from the scheduler's randomized target
		if (! class_exists('NMPublicationScheduler')) {
			require_once NM_PLUGIN_PATH . 'includes/class-nm-publication-scheduler.php';
		}
		$target_info = NMPublicationScheduler::get_today_target_info();
		$today_count = (int) $target_info['published'];
		$daily_target = (int) $target_info['target'];
		$remaining   = max(0, $daily_target - $today_count);
	?>

		<div style="margin-top: 30px; padding: 20px; background: #fff3cd; border-left: 4px solid #ffc107; border-radius: 4px;">
			<h3 style="margin-top: 0;">⚡ Manual Publishing Spike</h3>
			<p style="margin-bottom: 15px;">
				Immediately publish a batch of MCQs from the queue, bypassing the regular schedule.
				Useful for breaking news or high-demand topics.
			</p>

			<div style="background: white; padding: 15px; margin-bottom: 15px; border-radius: 4px;">
				<strong>📊 Current Status:</strong><br>
				<ul style="margin: 10px 0;">
					<li>Queue: <strong><?php echo $queue_size; ?></strong> MCQs waiting</li>
					<li>Published Today: <strong><?php echo $today_count; ?></strong> / <strong><?php echo $daily_target; ?></strong></li>
					<li>Remaining Today: <strong><?php echo $remaining; ?></strong></li>
				</ul>
			</div>

			<?php if ($queue_size > 0 && $remaining > 0) : ?>
				<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="display: inline-block;">
					<input type="hidden" name="action" value="nm_spike_publish">
					<?php wp_nonce_field('nm_spike_publish'); ?>

					<label style="display: inline-block; margin-right: 10px;">
						<strong>Number of MCQs:</strong>
						<input
							type="number"
							name="nm_spike_count"
							value="<?php echo min(5, $remaining); ?>"
							min="1"
							max="<?php echo min(50, $remaining); ?>"
							style="width: 80px; margin-left: 5px;">
					</label>

					<button
						type="submit"
						class="button button-primary"
						style="vertical-align: middle;"
						onclick="return confirm('Publish <?php echo min(5, $remaining); ?> MCQs immediately?');">
						🚀 Publish Now
					</button>
				</form>
			<?php elseif ($queue_size === 0) : ?>
				<p style="color: #856404; background: #fff3cd; padding: 10px; border-radius: 4px;">
					⚠️ <strong>Queue is empty.</strong> Generate some MCQs first using the tabs above.
				</p>
			<?php else : ?>
				<p style="color: #721c24; background: #f8d7da; padding: 10px; border-radius: 4px;">
					🛑 <strong>Daily cap reached.</strong> Already published <?php echo $today_count; ?> MCQs today.
					Limit resets at midnight.
				</p>
			<?php endif; ?>
		</div>
	<?php
	}

	// =================================================================
	// RENDER INDIVIDUAL TABS
	// =================================================================

	private static function render_api_keys_tab()
	{
		$gemini_key  = get_option('nm_gemini_api_key', '');
		$pexels_key  = get_option('nm_pexels_api_key', '');
		$gnews_key   = get_option('nm_gnews_api_key', '');
		$scraper_key = get_option('nm_scraper_api_key', '');
		$model_name  = get_option('nm_gemini_model_name', 'gemini-2.5-flash-preview-09-2025');
	?>
		<h3>API Configuration</h3>
		<table class="form-table">
			<tr>
				<th scope="row"><label for="nm_gemini_api_key">Gemini API Key</label></th>
				<td>
					<input type="password" id="nm_gemini_api_key" name="nm_gemini_api_key" value="<?php echo esc_attr($gemini_key); ?>" class="regular-text">
					<p class="description">Required for AI generation. <a href="https://makersuite.google.com/app/apikey" target="_blank">Get Key</a></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="nm_gemini_model_name">Gemini Model Name</label></th>
				<td>
					<input type="text" id="nm_gemini_model_name" name="nm_gemini_model_name" value="<?php echo esc_attr($model_name); ?>" class="regular-text">
					<p class="description">The Gemini model to use (e.g., 'gemini-2.5-flash-preview-09-2025').</p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="nm_pexels_api_key">Pexels API Key</label></th>
				<td>
					<input type="password" id="nm_pexels_api_key" name="nm_pexels_api_key" value="<?php echo esc_attr($pexels_key); ?>" class="regular-text">
					<p class="description">Required for stock video backgrounds. <a href="https://www.pexels.com/api/new/" target="_blank">Get Key</a></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="nm_gnews_api_key">GNews API Key</label></th>
				<td>
					<input type="password" id="nm_gnews_api_key" name="nm_gnews_api_key" value="<?php echo esc_attr($gnews_key); ?>" class="regular-text">
					<p class="description">Required for news generation. <a href="https://gnews.io/" target="_blank">Get Key</a></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="nm_scraper_api_key">ScraperAPI Key</label></th>
				<td>
					<input type="password" id="nm_scraper_api_key" name="nm_scraper_api_key" value="<?php echo esc_attr($scraper_key); ?>" class="regular-text">
					<p class="description">Optional. For scraping full article text. <a href="https://www.scraperapi.com/" target="_blank">Get Free Tier Key</a> (1,000 credits/mo)</p>
				</td>
			</tr>
		</table>
	<?php
	}

	private static function render_news_generation_tab()
	{
		$categories = get_option('nm_news_categories', array('all'));
		$country    = get_option('nm_news_country', 'us');
		$schedule   = get_option('nm_news_cron_schedule', 'hourly');
		$enabled    = get_option('nm_news_generation_enabled', 0);
	?>
		<h2>📰 News-Based Generation Settings</h2>
		<table class="form-table">
			<tr style="background: #f0f6fc; border-left: 4px solid #2271b1;">
				<th scope="row">Enable News Generation</th>
				<td>
					<label>
						<input type="checkbox" name="nm_news_generation_enabled" value="1" <?php checked($enabled, 1); ?>>
						<strong>Enable automatic MCQ generation from news articles</strong>
					</label>
					<p class="description">
						When <strong>unchecked</strong>, the plugin will NOT generate MCQs from news,
						regardless of the schedule setting below.
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row">News Categories</th>
				<td>
					<?php
					$all_cats = array('all', 'general', 'nation', 'business', 'technology', 'entertainment', 'sports', 'science', 'health');
					foreach ($all_cats as $cat) {
						$checked = in_array($cat, $categories);
						echo '<label style="margin-right: 15px;">';
						echo '<input type="checkbox" name="nm_news_categories[]" value="' . esc_attr($cat) . '" ' . checked($checked, true, false) . '> ';
						echo ucfirst($cat);
						echo '</label>';
					}
					?>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="nm_news_country">News Country</label></th>
				<td>
					<select id="nm_news_country" name="nm_news_country">
						<option value="pk" <?php selected($country, 'pk'); ?>>Pakistan</option>
						<option value="in" <?php selected($country, 'in'); ?>>India</option>
						<option value="us" <?php selected($country, 'us'); ?>>United States</option>
						<option value="gb" <?php selected($country, 'gb'); ?>>United Kingdom</option>
					</select>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="nm_news_cron_schedule">Automatic Schedule</label></th>
				<td>
					<select id="nm_news_cron_schedule" name="nm_news_cron_schedule">
						<?php foreach (NM_Cron_Manager::get_cron_schedules() as $key => $label) : ?>
							<option value="<?php echo esc_attr($key); ?>" <?php selected($schedule, $key); ?>><?php echo esc_html($label); ?></option>
						<?php endforeach; ?>
					</select>
					<p class="description">How often to automatically fetch news and generate new MCQs.</p>
				</td>
			</tr>
		</table>

		<hr style="margin: 20px 0;">
		<h3>📝 Daily Practice Roundup (Exam-Oriented, SEO / AIO / LLMO)</h3>
		<p>
			Generates <strong>one daily practice &amp; revision post</strong> (near end of day, ~23:30) that
			compiles <strong>ALL MCQs published that day</strong>, grouped by topic, as an organized study guide for
			aspirants. This is <strong>NOT a news article</strong> — it presents the day's practice questions and the
			current-affairs facts behind them as exam-revision material. It links to the topic hub and every MCQ from
			that day, and is SEO/AIO/LLMO optimized. These are your <strong>indexable, rankable pages</strong>
			(single MCQs are meant to be noindex via Rank Math).
		</p>
		<table class="form-table">
			<tr style="background: #f0f6fc; border-left: 4px solid #2271b1;">
				<th scope="row">Enable Daily Roundup</th>
				<td>
					<label>
						<input type="checkbox" name="nm_article_generation_enabled" value="1" <?php checked(get_option('nm_article_generation_enabled', 0), 1); ?>>
						<strong>Auto-generate ONE daily practice roundup of all MCQs published that day</strong>
					</label>
					<p class="description">
						Requires the same Gemini API key as news generation. When enabled, the plugin schedules a
						daily cron that produces <strong>one exam-practice post covering every MCQ published that day</strong>,
						grouped by topic — a daily study/revision guide (not one per news batch, and not a news article).
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row">Auto-Publish Articles</th>
				<td>
					<label>
						<input type="checkbox" name="nm_article_auto_publish" value="1" <?php checked(get_option('nm_article_auto_publish', 0), 1); ?>>
						<strong>Publish articles immediately</strong>
					</label>
					<p class="description">
						<strong>Note:</strong> Publishing of the daily roundup (and all articles) is governed by the
						<strong>Scheduler Tab</strong> when it is enabled. This toggle only applies when the Scheduler is <strong>OFF</strong>:
						When <strong>checked</strong>, the daily roundup publishes right away (fastest indexing). When <strong>unchecked</strong>,
						it is saved as <strong>Draft</strong> for your review.
						If the Scheduler is ON, roundups are queued (Draft + ready) and published on the Scheduler's
						human-like timing regardless of this toggle.
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="nm_article_daily_limit">Max Articles Per Day</label></th>
				<td>
					<input type="number" id="nm_article_daily_limit" name="nm_article_daily_limit" value="<?php echo esc_attr( get_option( 'nm_article_daily_limit', 2 ) ); ?>" min="1" max="50" class="small-text">
					<p class="description">
						Not used by the daily roundup (which is always limited to <strong>1 post per day</strong>).
						This cap only applies if any legacy per-batch article generation is active. You can safely
						leave it at its default.
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row">Named Article/MCQ Authors</th>
				<td>
					<?php
					$configured_authors = get_option('nm_article_authors', array());
					$author_users       = get_users(
						array(
							'role'    => 'author',
							'number'  => 100,
							'orderby' => 'display_name',
							'order'   => 'ASC',
						)
					);
					if (empty($author_users)) {
						echo '<p class="description">No users with the <strong>Author</strong> role found. Create 3–5 Author-role users (Users → Add New, role: Author) and they will be selectable here.</p>';
					} else {
						echo '<div style="max-height: 160px; overflow-y:auto; border:1px solid #ccd0d4; padding:10px; background:#fff;">';
						foreach ($author_users as $u) {
							$checked = in_array($u->ID, $configured_authors);
							echo '<label style="display:block;margin-bottom:5px;">';
							echo '<input type="checkbox" name="nm_article_authors[]" value="' . esc_attr($u->ID) . '" ' . checked($checked, true, false) . '> ';
							echo esc_html($u->display_name) . ' <code style="opacity:.7;">@' . esc_html($u->user_login) . '</code>';
							echo '</label>';
						}
						echo '</div>';
						echo '<p class="description">Select 3–5 authors. Each MCQ and article gets a random author from this list (E-E-A-T). Leave empty to use all Author-role users.</p>';
					}
					?>
				</td>
			</tr>
		</table>

		<div style="margin-top: 16px; padding: 14px; background: #f6f7f7; border: 1px solid #ccd0d4; border-radius: 6px;">
			<strong>⚡ Run Daily Roundup Now</strong>
			<p style="margin: 6px 0 10px;">
				Generate today's daily practice roundup immediately (instead of waiting for the ~23:30 cron).
				Only one roundup is created per day. The generated post is saved as a Draft / queued via the
				Scheduler for publishing.
			</p>
			<button type="button" id="nm-run-daily-roundup-btn" class="button button-secondary">
				🚀 Run Daily Roundup Now
			</button>
			<span id="nm-run-roundup-spinner" class="spinner" style="float: none; margin-top: 5px;"></span>
			<div id="nm-run-roundup-status" style="margin-top: 10px;"></div>
		</div>

		<hr style="margin: 20px 0;">
		<h3>🎯 Manual Generation Control</h3>
		<p>Uses your "News-Based" settings saved above.</p>
		<button type="button" id="nm-manual-generate-btn" class="button button-secondary">
			Generate MCQs From News
		</button>
		<span id="nm-news-spinner" class="spinner" style="float: none; margin-top: 5px;"></span>
	<?php
	}

	/**
	 * @NEW 9.5.0: Monthly PDF Archive tab.
	 */
	private static function render_pdf_archive_tab()
	{
		$enabled = get_option('nm_pdf_archive_enabled', 0);
		$selected = get_option('nm_pdf_archive_topics', array());
		if (! is_array($selected)) {
			$selected = array();
		}

		$parents = get_terms(
			array(
				'taxonomy'   => 'topic',
				'hide_empty' => false,
				'parent'     => 0,
				'orderby'    => 'name',
				'order'      => 'ASC',
			)
		);
	?>
		<h2>📥 Monthly MCQ PDF Archive</h2>
		<p>
			Generates a <strong>professionally formatted, downloadable PDF</strong> of all MCQs published each month
			for each selected topic, and maintains one <strong>evergreen archive page</strong> per topic
			(e.g. <code>/geography-mcqs-with-answers/</code>). The page&rsquo;s SEO title and
			"Download this month" CTA are updated automatically each month, with an accordion of past months&rsquo;
			PDFs. PDFs are built with <strong>Dompdf</strong> (cover page, site logo, page numbers, and each
			question kept intact on a page — nothing cut off).
		</p>

		<table class="form-table">
			<tr style="background: #f0f6fc; border-left: 4px solid #2271b1;">
				<th scope="row">Enable Monthly PDF Archive</th>
				<td>
					<label>
						<input type="checkbox" name="nm_pdf_archive_enabled" value="1" <?php checked($enabled, 1); ?>>
						<strong>Enable automatic monthly PDF generation</strong>
					</label>
					<p class="description">
						When enabled, a daily cron generates the previous month&rsquo;s PDF for each selected topic
						(once per topic per month) and updates the topic&rsquo;s evergreen page.
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row">Topics for Monthly PDFs</th>
				<td>
					<?php
					if (is_wp_error($parents) || empty($parents)) {
						echo '<p class="description">No parent topics found. Create topics first.</p>';
					} else {
						echo '<div style="max-height:260px;overflow-y:auto;border:1px solid #ccd0d4;padding:10px;background:#fff;">';
						foreach ($parents as $parent) {
							$checked = in_array($parent->term_id, $selected);
							echo '<div style="margin-bottom:8px;">';
							echo '<label style="font-weight:600;">';
							echo '<input type="checkbox" name="nm_pdf_archive_topics[]" value="' . esc_attr($parent->term_id) . '" ' . checked($checked, true, false) . '> ';
							echo esc_html($parent->name) . ' <code style="opacity:.6;">(' . (int) $parent->count . ' MCQs)</code>';
							echo '</label>';

							$children = get_terms(
								array(
									'taxonomy'   => 'topic',
									'hide_empty' => false,
									'parent'     => $parent->term_id,
									'orderby'    => 'name',
									'order'      => 'ASC',
								)
							);
							if (! empty($children) && ! is_wp_error($children)) {
								echo '<div style="margin-left:24px;margin-top:3px;">';
								foreach ($children as $child) {
									$child_checked = in_array($child->term_id, $selected);
									echo '<label style="display:block;margin:2px 0;">';
									echo '<input type="checkbox" name="nm_pdf_archive_topics[]" value="' . esc_attr($child->term_id) . '" ' . checked($child_checked, true, false) . '> ';
									echo esc_html($child->name) . ' <code style="opacity:.6;">(' . (int) $child->count . ')</code>';
									echo '</label>';
								}
								echo '</div>';
							}
							echo '</div>';
						}
						echo '</div>';
						echo '<p class="description">Check a parent topic to include ALL of its MCQs (including sub-topics) in one PDF, or check specific sub-topics for separate PDFs. Each checked topic gets its own evergreen page and monthly PDF.</p>';
					}
					?>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="nm_pdf_volume_cap">Complete-Bank Volume Cap</label></th>
				<td>
					<input type="number" id="nm_pdf_volume_cap" name="nm_pdf_volume_cap" value="<?php echo (int) get_option('nm_pdf_volume_cap', 200); ?>" min="100" max="300" step="10" class="small-text"> questions per volume
					<p class="description">
						<strong>Complete Question Bank volumes (9.5.6).</strong> Besides the monthly PDFs, each selected topic
						also gets a <strong>complete bank</strong> of ALL its published questions, split into append-only
						chronological volumes: Vol&nbsp;1 = oldest <em>N</em> questions (<strong>frozen forever</strong> once full —
						stable file &amp; URL), and only the newest volume grows — <strong>refreshed on the 1st of every month</strong>.
						Questions are grouped by sub-topic with section headings; reported/flagged MCQs are excluded from all PDFs.
						Default <strong>200</strong>, clamped 100–300 (Dompdf render-safety limit).
					</p>
				</td>
			</tr>
		</table>

		<div style="margin-top:14px;padding:14px;background:#f6f7f7;border:1px solid #ccd0d4;border-radius:6px;">
			<strong>⚡ Run Now</strong>
			<p style="margin:6px 0 10px;">Generate the PDFs immediately for all selected topics (defaults to the previous completed month).</p>
			<button type="button" id="nm-run-pdf-archive-btn" class="button button-secondary">🚀 Generate Monthly PDFs Now</button>
			<span id="nm-pdf-archive-spinner" class="spinner" style="float:none;margin-top:5px;"></span>
			<div id="nm-pdf-archive-status" style="margin-top:10px;"></div>
		</div>
	<?php
	}

	/**
	 * @NEW 9.4.0: Topic Pillar generation tab (evergreen SEO/AIO/LLMO pillars).
	 */
	private static function render_pillar_generation_tab()
	{
		$enabled       = get_option('nm_pillar_generation_enabled', 0);
		$topics        = get_option('nm_pillar_topics', array());
		$exams         = get_option('nm_pillar_exams', array());
		$interval_days = get_option('nm_pillar_interval_days', 30);
		$daily_limit   = get_option('nm_pillar_daily_limit', 3);

		if (! is_array($topics)) {
			$topics = array();
		}
		if (! is_array($exams)) {
			$exams = array();
		}

		$parent_topics = get_terms(
			array(
				'taxonomy'   => 'topic',
				'hide_empty' => false,
				'parent'     => 0,
				'orderby'    => 'name',
				'order'      => 'ASC',
			)
		);
		$all_exams = get_terms(
			array(
				'taxonomy'   => 'nm_exam',
				'hide_empty' => false,
				'orderby'    => 'name',
				'order'      => 'ASC',
			)
		);
	?>
		<h2>🧭 Topic Pillar Articles (Evergreen SEO / AIO / LLMO)</h2>
		<p>
			Generates <strong>evergreen pillar articles</strong> (800–1500 words) for the parent topics you
			select below. Each pillar is a <strong>standalone <code>post</code></strong> tagged with its topic
			(and optional exams), professionally written in the site's tone (by a random named author), with a
			generated featured image, a real <code>FAQ</code> section, and Rank Math SEO meta. These are your
			<strong>indexable, rankable long-form pages</strong> that convert each topic hub into a page Google
			can rank — separate from daily news roundups and the noindex MCQs.
		</p>

		<table class="form-table">
			<tr style="background: #f0f6fc; border-left: 4px solid #2271b1;">
				<th scope="row">Enable Pillar Generation</th>
				<td>
					<label>
						<input type="checkbox" name="nm_pillar_generation_enabled" value="1" <?php checked($enabled, 1); ?>>
						<strong>Enable automatic evergreen pillar generation</strong>
					</label>
					<p class="description">
						When <strong>enabled</strong>, the plugin runs a daily cron that generates one pillar for
						each selected topic that is due (per the cadence below). Pillars are saved as
						<strong>Drafts for your review</strong>; if the <strong>📅 Scheduler</strong> is ON, they
						are queued and published on the Scheduler's human-like timing.
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row">Topics to Generate Pillars For</th>
				<td>
					<?php
					if (is_wp_error($parent_topics) || empty($parent_topics)) {
						echo '<p class="description">No parent topics found. Create topics first.</p>';
					} else {
						echo '<div style="max-height:220px;overflow-y:auto;border:1px solid #ccd0d4;padding:10px;background:#fff;">';
						foreach ($parent_topics as $topic) {
							$checked = in_array($topic->term_id, $topics);
							echo '<label style="display:block;margin-bottom:5px;">';
							echo '<input type="checkbox" name="nm_pillar_topics[]" value="' . esc_attr($topic->term_id) . '" ' . checked($checked, true, false) . '> ';
							echo esc_html($topic->name) . ' <code style="opacity:.7;">(' . (int) $topic->count . ' MCQs)</code>';
							echo '</label>';
						}
						echo '</div>';
						echo '<p class="description">Select the parent topics that should each get an evergreen pillar guide. Every selected topic gets one pillar on its cadence.</p>';
					}
					?>
				</td>
			</tr>
			<tr>
				<th scope="row">Exams (optional tag)</th>
				<td>
					<?php
					if (is_wp_error($all_exams) || empty($all_exams)) {
						echo '<p class="description">No exams found.</p>';
					} else {
						echo '<div style="max-height:150px;overflow-y:auto;border:1px solid #ccd0d4;padding:10px;background:#fff;">';
						foreach ($all_exams as $exam) {
							$checked = in_array($exam->term_id, $exams);
							echo '<label style="display:block;margin-bottom:5px;">';
							echo '<input type="checkbox" name="nm_pillar_exams[]" value="' . esc_attr($exam->term_id) . '" ' . checked($checked, true, false) . '> ';
							echo esc_html($exam->name);
							echo '</label>';
						}
						echo '</div>';
						echo '<p class="description">Optionally tag each pillar with one or more exams (e.g. CSS, PMS, NTS) so they also appear under <code>/exam/&lt;slug&gt;/</code>. The pillar prompt references these exams.</p>';
					}
					?>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="nm_pillar_interval_days">Cadence (days per topic)</label></th>
				<td>
					<input type="number" id="nm_pillar_interval_days" name="nm_pillar_interval_days" value="<?php echo intval($interval_days); ?>" min="1" max="365" class="small-text">
					<p class="description">
						<strong>Refresh one pillar per selected topic every N days.</strong> Default <strong>30</strong> (monthly).
						Each topic keeps <strong>ONE canonical pillar post</strong> — refreshes update it in place
						(same URL, updated content, bumped "Last Updated" date). A new post is only created the
						first time a topic gets a pillar. On the very first run, every selected topic is "due"
						(up to the daily cap below).
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="nm_pillar_daily_limit">Max Pillars Per Day</label></th>
				<td>
					<input type="number" id="nm_pillar_daily_limit" name="nm_pillar_daily_limit" value="<?php echo intval($daily_limit); ?>" min="1" max="20" class="small-text">
					<p class="description">
						Global daily cap so a burst of overdue topics doesn't generate everything at once.
						Default <strong>3</strong>.
					</p>
				</td>
			</tr>
		</table>

		<div style="background:#f0f6fc;border-left:4px solid #2271b1;padding:15px;margin-top:10px;">
			<h4 style="margin:0 0 6px;">How it works</h4>
			<ul style="margin:0;padding-left:20px;">
				<li>Daily cron checks each selected topic; if its pillar hasn't been refreshed within the cadence, it regenerates it <strong>in place</strong> (one canonical URL per topic — no duplicate posts).</li>
				<li>Uses your Gemini key (same retry/failover as MCQ generation) and grounds the article in the topic's <strong>real evergreen MCQs</strong> (news-derived MCQs are excluded to keep pillars timeless).</li>
				<li>SEO/AIO/LLMO optimized: keyword title, 150–160 char meta, <code>h2</code> structure, "Key Concepts", "Why It Matters for Exams", single FAQ with schema, "Exam Takeaway".</li>
				<li>Related Practice MCQs render via the <code>[nm_related_mcqs]</code> shortcode — always current, published questions only.</li>
				<li>Filed under the <strong>Study Guides</strong> category. Saved <strong>Draft</strong> for review on first creation → if Scheduler is ON, queued to publish on schedule.</li>
				<li>Random named author + generated 1200×630 featured image + Rank Math focus keyword + FAQ schema.</li>
			</ul>
		</div>
	<?php
	}

	private static function render_topic_generation_tab()
	{
		$selected_ids = get_option('nm_topic_list_ids', array());
		$mcq_count    = get_option('nm_topic_mcq_count', 1);
		$schedule     = get_option('nm_topic_cron_schedule', 'disabled');
		$enabled      = get_option('nm_topic_generation_enabled', 0);
	?>
		<h3>📚 Topic-Based Generation Settings</h3>
		<p>This generator creates MCQs based on specific topics and sub-topics you select from the list.</p>

		<table class="form-table">
			<tr>
				<th scope="row">Enable Topic Generation</th>
				<td>
					<label>
						<input type="checkbox" name="nm_topic_generation_enabled" value="1" <?php checked($enabled, 1); ?>>
						<strong>Enable automatic MCQ generation from topics</strong>
					</label>
					<p class="description">
						When <strong>unchecked</strong>, the plugin will NOT generate MCQs from topics,
						regardless of the schedule setting below.
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row">Topics for Generation</th>
				<td>
					<div style="margin-bottom: 10px;">
						<a href="#" class="nm-check-all-topics" style="text-decoration: none;">Check All</a> |
						<a href="#" class="nm-uncheck-all-topics" style="text-decoration: none;">Uncheck All</a>
					</div>
					<div id="nm-topic-checklist-container" style="max-height: 250px; overflow-y: auto; border: 1px solid #ccd0d4; padding: 10px; background: #fff;">
						<ul style="margin: 0;">
							<?php
							$parents = get_terms(
								array(
									'taxonomy'   => 'topic',
									'hide_empty' => false,
									'parent'     => 0,
									'orderby'    => 'name',
								)
							);
							if (empty($parents)) {
								echo '<li>No topics found.</li>';
							} else {
								foreach ($parents as $parent) {
									echo '<li class="nm-topic-parent-item" style="margin-bottom: 10px;">';
									echo '<strong>' . esc_html($parent->name) . '</strong>';

									$children = get_terms(
										array(
											'taxonomy'   => 'topic',
											'hide_empty' => false,
											'parent'     => $parent->term_id,
											'orderby'    => 'name',
										)
									);

									if (! empty($children)) {
										echo '<span class="nm-topic-group-controls" style="font-size: 0.9em; margin-left: 10px;">';
										echo '(<a href="#" class="nm-check-group" style="text-decoration: none;">select group</a> | ';
										echo '<a href="#" class="nm-uncheck-group" style="text-decoration: none;">deselect group</a>)';
										echo '</span>';

										echo '<ul class="nm-topic-child-list" style="margin-top: 5px; margin-left: 20px; padding-left: 15px; border-left: 2px solid #eee;">';
										foreach ($children as $child) {
											$checked = in_array($child->term_id, $selected_ids);
											echo '<li style="margin-bottom: 2px;">';
											echo '<label>';
											echo '<input type="checkbox" name="nm_topic_list_ids[]" value="' . esc_attr($child->term_id) . '" ' . checked($checked, true, false) . '> ';
											echo esc_html($child->name);
											echo '</label>';
											echo '</li>';
										}
										echo '</ul>';
									} else {
										$checked = in_array($parent->term_id, $selected_ids);
										echo '<ul class="nm-topic-child-list" style="margin-top: 5px; margin-left: 20px; padding-left: 15px; border-left: 2px solid #eee;">';
										echo '<li style="margin-bottom: 2px; list-style-type: none;">';
										echo '<label>';
										echo '<input type="checkbox" name="nm_topic_list_ids[]" value="' . esc_attr($parent->term_id) . '" ' . checked($checked, true, false) . '> ';
										echo '<em>(Self)</em>';
										echo '</label>';
										echo '</li>';
										echo '</ul>';
									}

									echo '</li>';
								}
							}
							?>
						</ul>
					</div>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="nm_topic_mcq_count">MCQs per Topic</label></th>
				<td>
					<input type="number" id="nm_topic_mcq_count" name="nm_topic_mcq_count" value="<?php echo intval($mcq_count); ?>" min="1" max="10" class="small-text">
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="nm_topic_cron_schedule">Automatic Schedule</label></th>
				<td>
					<select id="nm_topic_cron_schedule" name="nm_topic_cron_schedule">
						<?php foreach (NM_Cron_Manager::get_cron_schedules() as $key => $label) : ?>
							<option value="<?php echo esc_attr($key); ?>" <?php selected($schedule, $key); ?>><?php echo esc_html($label); ?></option>
						<?php endforeach; ?>
					</select>
					<p class="description">How often to automatically generate MCQs from the topics list above.</p>
				</td>
			</tr>
		</table>

		<hr style="margin: 20px 0;">
		<h3>🎯 Manual Generation Control</h3>
		<p>Uses your "Topic-Based" settings saved above.</p>
		<button type="button" id="nm-manual-topic-generate-btn" class="button button-primary">
			Generate MCQs From Topics
		</button>
		<span id="nm-topic-spinner" class="spinner" style="float: none; margin-top: 5px;"></span>

		<script>
			jQuery(document).ready(function($) {
				const topicContainer = $('#nm-topic-checklist-container');

				$('.nm-check-all-topics').click(function(e) {
					e.preventDefault();
					topicContainer.find('input[type="checkbox"]').prop('checked', true);
				});
				$('.nm-uncheck-all-topics').click(function(e) {
					e.preventDefault();
					topicContainer.find('input[type="checkbox"]').prop('checked', false);
				});

				topicContainer.on('click', '.nm-check-group', function(e) {
					e.preventDefault();
					$(this).closest('.nm-topic-parent-item').find('input[type="checkbox"]').prop('checked', true);
				});
				topicContainer.on('click', '.nm-uncheck-group', function(e) {
					e.preventDefault();
					$(this).closest('.nm-topic-parent-item').find('input[type="checkbox"]').prop('checked', false);
				});
			});
		</script>
	<?php
	}

	private static function render_current_affairs_tab()
	{
		$enabled               = get_option('nm_current_affairs_enabled', 0);
		$pak_count             = get_option('nm_current_affairs_pakistan_count', 1);
		$intl_count            = get_option('nm_current_affairs_intl_count', 1);
		$questions_per_article = get_option('nm_ca_questions_per_article', 3);
		$worker_batch_size     = get_option('nm_current_affairs_worker_batch', 1);
		$max_queue_size        = get_option('nm_current_affairs_max_queue', 50);
		$schedule              = get_option('nm_current_affairs_cron_schedule', 'every_fifteen_minutes');
	?>
		<h3>🌍 Current Affairs Generator</h3>
		<p>Automatically generate MCQs from Pakistan and international news sources.</p>
		<table class="form-table">
			<tr>
				<th scope="row">Enable Current Affairs Generator</th>
				<td>
					<label>
						<input type="checkbox" name="nm_current_affairs_enabled" value="1" <?php checked($enabled, 1); ?>>
						Enable automatic generation
					</label>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="nm_current_affairs_pakistan_count">Pakistan Articles Per Run</label></th>
				<td>
					<input type="number" id="nm_current_affairs_pakistan_count" name="nm_current_affairs_pakistan_count" value="<?php echo intval($pak_count); ?>" min="0" max="10" class="small-text">
					<p class="description">Number of Pakistan news articles to process per cron cycle</p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="nm_current_affairs_intl_count">International Articles Per Run</label></th>
				<td>
					<input type="number" id="nm_current_affairs_intl_count" name="nm_current_affairs_intl_count" value="<?php echo intval($intl_count); ?>" min="0" max="10" class="small-text">
					<p class="description">Number of international news articles to process per cron cycle</p>
				</td>
			</tr>
			<!-- ✅ ADD THIS NEW TABLE ROW -->
			<tr>
				<th scope="row"><label for="nm_ca_questions_per_article">Questions Per Article</label></th>
				<td>
					<input type="number"
						id="nm_ca_questions_per_article"
						name="nm_ca_questions_per_article"
						value="<?php echo intval($questions_per_article); ?>"
						min="1" max="5"
						class="small-text">
					<p class="description">Number of questions to generate from each article (e.g., 1–5). Default: 3.</p>
				</td>
			</tr>

			<!-- NEW: Worker batch size -->
			<tr>
				<th scope="row"><label for="nm_current_affairs_worker_batch">Worker Batch Size</label></th>
				<td>
					<input type="number"
						id="nm_current_affairs_worker_batch"
						name="nm_current_affairs_worker_batch"
						value="<?php echo max(1, min(5, intval($worker_batch_size))); ?>"
						min="1" max="5"
						class="small-text">
					<p class="description">
						How many queued articles the Current Affairs Worker should process per cron run (1–5).
						Keep at 1 for maximum safety; increase carefully to 2–3 only if the queue often grows large.
					</p>
				</td>
			</tr>
			<!-- NEW: Max queue size -->
			<tr>
				<th scope="row"><label for="nm_current_affairs_max_queue">Max Queue Size</label></th>
				<td>
					<input type="number" id="nm_current_affairs_max_queue" name="nm_current_affairs_max_queue"
						value="<?php echo max(5, intval($max_queue_size)); ?>" min="5" max="200" class="small-text">
					<p class="description">
						Maximum number of articles allowed in the Current Affairs queue.
						If the queue grows beyond this number, the Worker will reset the queue
						on the next run. Recommended range: 20–50.
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="nm_current_affairs_cron_schedule">Execution Schedule</label></th>
				<td>
					<select id="nm_current_affairs_cron_schedule" name="nm_current_affairs_cron_schedule">
						<?php foreach (NM_Cron_Manager::get_cron_schedules() as $key => $label) : ?>
							<option value="<?php echo esc_attr($key); ?>" <?php selected($schedule, $key); ?>><?php echo esc_html($label); ?></option>
						<?php endforeach; ?>
					</select>
					<p class="description">How often to fetch and process Current Affairs articles.</p>
				</td>
			</tr>
		</table>
	<?php
	}

	private static function render_feed_importer_tab()
	{
		$enabled        = get_option('nm_feed_importer_enabled', 0);
		$url            = get_option('nm_mcq_feed_url', '');
		$schedule       = get_option('nm_feed_importer_cron_schedule', 'hourly');
		$max            = get_option('nm_feed_importer_max_items', 10);
		$feed_scheduled = wp_next_scheduled('nm_feed_import_cron');
	?>
		<h2>📥 Feed Importer Settings</h2>
		<p>Import and rewrite MCQs from an external JSON or RSS/XML feed with automatic scheduling.</p>

		<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin: 20px 0;">
			<div style="background: #fff; padding: 15px; border: 1px solid #ddd; border-radius: 8px;">
				<h3>🔄 Cron Status</h3>
				<p><strong>Scheduled:</strong> <?php echo $feed_scheduled ? '✅ Yes' : '❌ No'; ?></p>
				<p><strong>Status:</strong> <?php echo $enabled ? '✅ ENABLED' : '⚠️ DISABLED'; ?></p>
				<p><strong>Schedule:</strong> <?php echo esc_html($schedule); ?></p>
			</div>
			<div style="background: #fff; padding: 15px; border: 1px solid #ddd; border-radius: 8px;">
				<h3>ℹ️ How It Works</h3>
				<ul style="margin: 0; padding-left: 20px;">
					<li>Fetches MCQs from feed</li>
					<li>Extracts Q, options, answers</li>
					<li>Rephrase with AI</li>
					<li>Check duplicates</li>
					<li>Create MCQ posts</li>
				</ul>
			</div>
		</div>

		<table class="form-table">
			<tr>
				<th scope="row">Enable Feed Importer</th>
				<td>
					<label>
						<input type="checkbox" name="nm_feed_importer_enabled" value="1" <?php checked($enabled, 1); ?>>
						<strong>Enable automatic MCQ import from feed</strong>
					</label>
					<p class="description">When unchecked, feed imports will be disabled regardless of schedule.</p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="nm_mcq_feed_url">Feed URL</label></th>
				<td>
					<input type="url" id="nm_mcq_feed_url" name="nm_mcq_feed_url" value="<?php echo esc_attr($url); ?>" class="regular-text" placeholder="https://example.com/mcq-feed.json">
					<p class="description">Enter the URL of the JSON or RSS/XML feed containing MCQs.</p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="nm_feed_importer_max_items">Max Items Per Run</label></th>
				<td>
					<input type="number" id="nm_feed_importer_max_items" name="nm_feed_importer_max_items" value="<?php echo intval($max); ?>" min="1" max="50" class="small-text">
					<p class="description">Maximum MCQs to process per run (1-50)</p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="nm_feed_importer_cron_schedule">Import Schedule</label></th>
				<td>
					<select id="nm_feed_importer_cron_schedule" name="nm_feed_importer_cron_schedule">
						<?php foreach (NM_Cron_Manager::get_cron_schedules() as $key => $label) : ?>
							<option value="<?php echo esc_attr($key); ?>" <?php selected($schedule, $key); ?>><?php echo esc_html($label); ?></option>
						<?php endforeach; ?>
					</select>
					<p class="description">How often to check and import from feed</p>
				</td>
			</tr>
		</table>

		<hr style="margin: 20px 0;">
		<h3>🎯 Manual Import Control</h3>
		<p>Uses your "Feed Importer" settings saved above.</p>
		<button type="button" id="nm-manual-import-btn" class="button button-secondary">
			Import MCQs From Feed
		</button>
		<span id="nm-feed-spinner" class="spinner" style="float: none; margin-top: 5px;"></span>
	<?php
	}

	private static function render_duplicate_tab()
	{
		$threshold = get_option('nm_similarity_threshold', 0.7);
		$skip      = get_option('nm_skip_import_duplicate_check', 0);
	?>
		<h2>🔍 Duplicate Detection Settings</h2>
		<p>Control the sensitivity of the semantic duplicate check and importer behavior.</p>

		<table class="form-table">
			<tr>
				<th scope="row"><label for="nm_similarity_threshold">Similarity Threshold</label></th>
				<td>
					<input type="number" id="nm_similarity_threshold" name="nm_similarity_threshold" value="<?php echo esc_attr($threshold); ?>" min="0.5" max="1.0" step="0.05" class="small-text">
					<span style="margin-left: 10px; color: #666;">
						(Current: <strong><?php echo round($threshold * 100); ?>%</strong>)
					</span>
					<p class="description" style="margin-top: 10px;">
						<strong>Recommended:</strong> 0.7 (70%) - Balanced detection<br>
						Higher values = Stricter, Lower values = More sensitive
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row">Importer Check</th>
				<td>
					<label>
						<input type="checkbox" name="nm_skip_import_duplicate_check" value="1" <?php checked($skip, 1); ?>>
						Skip semantic duplicate check for imported MCQs
					</label>
					<p class="description">
						✅ <strong>Recommended for bulk importing</strong> trusted content to speed up the process.
					</p>
				</td>
			</tr>
		</table>

		<hr style="margin: 20px 0;">
		<h3>🛠️ E-E-A-T Maintenance</h3>
		<p>Use this tool to synchronize the "Author Name" meta field of all existing MCQs with their actual WordPress author's Display Name. This is highly recommended if your posts currently show "TheQuizWire" or are missing author names.</p>

		<button type="button" id="nm-sync-authors-btn" class="button button-secondary">
			🔄 Sync All Post Author Names
		</button>
		<span id="nm-sync-spinner" class="spinner" style="float: none; margin-top: 5px;"></span>
		<p class="description">Note: This will only update posts that have no author name or are set to "TheQuizWire". Customized names will be preserved.</p>

		<hr style="margin: 20px 0;">
		<p>
			Assign a <strong>random author</strong> (from your <strong>Named Article/MCQ Authors</strong> list on the
			<strong>📰 News</strong> tab — falls back to all Author-role users if the list is empty) to
			<strong>existing MCQs that don't already have a named author</strong>. MCQs that already got an author
			(from the News tab or a previous run) are <strong>skipped</strong>, so it only fills the gaps. It updates
			both the WordPress author and the byline meta, and runs in <strong>batches</strong> so large libraries
			(~4,000 MCQs) won't time out or error.
		</p>
		<button type="button" id="nm-assign-random-authors-btn" class="button button-primary">
			🎲 Assign Random Authors to All MCQs
		</button>
		<span id="nm-assign-random-spinner" class="spinner" style="float: none; margin-top: 5px;"></span>
		<div id="nm-assign-random-status" style="margin-top: 12px;"></div>

		<hr style="margin: 20px 0;">
		<p>
			Convert <strong>previously generated posts</strong> (topic pillars, news/daily roundups and monthly
			PDF archive pages) from classic HTML to <strong>Gutenberg block markup</strong>, so they open as real
			blocks in the editor instead of one "Classic" blob. Runs in <strong>batches</strong>, is
			<strong>resumable</strong>, and <strong>skips</strong> posts that are already blocks. Frontend output
			is unchanged. New posts are generated as blocks automatically since v9.5.4.
		</p>
		<button type="button" id="nm-convert-blocks-btn" class="button button-primary">
			🧱 Convert Generated Posts to Blocks
		</button>
		<span id="nm-convert-blocks-spinner" class="spinner" style="float: none; margin-top: 5px;"></span>
		<div id="nm-convert-blocks-status" style="margin-top: 12px;"></div>
	<?php
	}
	private static function render_exam_blueprints_tab()
	{
		// Load existing blueprint config
		$blueprints = get_option('nm_exam_blueprints', array());
		if (! is_array($blueprints)) {
			$blueprints = array();
		}

		// Load all exams
		$exam_terms = get_terms(
			array(
				'taxonomy'   => 'nm_exam',
				'hide_empty' => false,
				'orderby'    => 'name',
				'order'      => 'ASC',
			)
		);
	?>
		<h2>📘 Exam Blueprints</h2>
		<p>
			Configure target difficulty and Bloom (cognitive) distributions for each exam.
			The generator will use these blueprints to pick difficulty and cognitive level
			when creating new MCQs for that exam.
		</p>
		<?php
		if (is_wp_error($exam_terms) || empty($exam_terms)) {
			echo '<p>No exams found. Add exams under <strong>MCQs ➜ Exams</strong> first.</p>';
			return;
		}
		?>
		<table class="widefat striped" style="margin-top:15px;">
			<thead>
				<tr>
					<th style="width:18%;">Exam</th>
					<th style="width:26%;">Difficulty % (Easy / Medium / Hard)</th>
					<th style="width:32%;">Bloom % (Remember / Understand / Apply / Analyze / Evaluate)</th>
					<th style="width:24%;">Prompt Hint (optional)</th>
				</tr>
			</thead>
			<tbody>
				<?php
				foreach ($exam_terms as $term) :
					$slug = $term->slug;
					$cfg  = $blueprints[$slug] ?? array();

					$diff  = $cfg['difficulty'] ?? array();
					$bloom = $cfg['bloom'] ?? array();

					$easy   = isset($diff['easy']) ? (int) $diff['easy'] : 0;
					$medium = isset($diff['medium']) ? (int) $diff['medium'] : 0;
					$hard   = isset($diff['hard']) ? (int) $diff['hard'] : 0;

					$remember   = isset($bloom['remember']) ? (int) $bloom['remember'] : 0;
					$understand = isset($bloom['understand']) ? (int) $bloom['understand'] : 0;
					$apply      = isset($bloom['apply']) ? (int) $bloom['apply'] : 0;
					$analyze    = isset($bloom['analyze']) ? (int) $bloom['analyze'] : 0;
					$evaluate   = isset($bloom['evaluate']) ? (int) $bloom['evaluate'] : 0;

					$prompt_hint = isset($cfg['prompt_hint']) ? $cfg['prompt_hint'] : '';
				?>
					<tr>
						<td>
							<strong><?php echo esc_html($term->name); ?></strong><br>
							<code><?php echo esc_html($slug); ?></code><br>
							<span style="font-size:11px; color:#666;">
								MCQs: <?php echo number_format_i18n((int) $term->count); ?>
							</span>
						</td>
						<td>
							<input type="number"
								name="nm_exam_blueprints[<?php echo esc_attr($slug); ?>][difficulty][easy]"
								value="<?php echo esc_attr($easy); ?>"
								min="0" max="100" class="small-text"> Easy<br>
							<input type="number"
								name="nm_exam_blueprints[<?php echo esc_attr($slug); ?>][difficulty][medium]"
								value="<?php echo esc_attr($medium); ?>"
								min="0" max="100" class="small-text"> Medium<br>
							<input type="number"
								name="nm_exam_blueprints[<?php echo esc_attr($slug); ?>][difficulty][hard]"
								value="<?php echo esc_attr($hard); ?>"
								min="0" max="100" class="small-text"> Hard
							<p class="description" style="margin-top:4px;">
								You may, but do not have to, sum to 100%.
							</p>
						</td>
						<td>
							<input type="number"
								name="nm_exam_blueprints[<?php echo esc_attr($slug); ?>][bloom][remember]"
								value="<?php echo esc_attr($remember); ?>"
								min="0" max="100" class="small-text"> Remember<br>
							<input type="number"
								name="nm_exam_blueprints[<?php echo esc_attr($slug); ?>][bloom][understand]"
								value="<?php echo esc_attr($understand); ?>"
								min="0" max="100" class="small-text"> Understand<br>
							<input type="number"
								name="nm_exam_blueprints[<?php echo esc_attr($slug); ?>][bloom][apply]"
								value="<?php echo esc_attr($apply); ?>"
								min="0" max="100" class="small-text"> Apply<br>
							<input type="number"
								name="nm_exam_blueprints[<?php echo esc_attr($slug); ?>][bloom][analyze]"
								value="<?php echo esc_attr($analyze); ?>"
								min="0" max="100" class="small-text"> Analyze<br>
							<input type="number"
								name="nm_exam_blueprints[<?php echo esc_attr($slug); ?>][bloom][evaluate]"
								value="<?php echo esc_attr($evaluate); ?>"
								min="0" max="100" class="small-text"> Evaluate
						</td>
						<td>
							<textarea
								name="nm_exam_blueprints[<?php echo esc_attr($slug); ?>][prompt_hint]"
								rows="4" cols="25"
								style="width:100%;"><?php echo esc_textarea($prompt_hint); ?></textarea>
							<p class="description" style="margin-top:4px;">
								Optional extra guidance for this exam, e.g. "conceptual, avoid numericals"
								or "US_COMP style, focus on applied reasoning".
							</p>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<h3 style="margin-top: 25px;">Default Exam Mapping</h3>
		<table class="form-table" style="margin-bottom:18px;">
			<tr>
				<th scope="row" style="width:24%;">Default Exam for Topic-based Generation</th>
				<td>
					<?php
					$all_exams    = get_terms(
						array(
							'taxonomy'   => 'nm_exam',
							'hide_empty' => false,
						)
					);
					$chosen_topic = get_option('nm_default_exam_for_topics', '');
					?>
					<select name="nm_default_exam_for_topics">
						<option value="">— Not set —</option>
						<?php foreach ($all_exams as $ex) : ?>
							<option value="<?php echo esc_attr($ex->slug); ?>" <?php selected($chosen_topic, $ex->slug); ?>>
								<?php echo esc_html($ex->name); ?>
							</option>
						<?php endforeach; ?>
					</select>
					<p class="description">This exam’s blueprint will guide topic-based MCQ generation batches.</p>
				</td>
			</tr>
			<tr>
				<th scope="row" style="width:24%;">Default Exam for News/Current Affairs Generation</th>
				<td>
					<?php $chosen_news = get_option('nm_default_exam_for_news', ''); ?>
					<select name="nm_default_exam_for_news">
						<option value="">— Not set —</option>
						<?php foreach ($all_exams as $ex) : ?>
							<option value="<?php echo esc_attr($ex->slug); ?>" <?php selected($chosen_news, $ex->slug); ?>>
								<?php echo esc_html($ex->name); ?>
							</option>
						<?php endforeach; ?>
					</select>
					<p class="description">This exam’s blueprint will guide News/Current Affairs MCQ batches.</p>
				</td>
			</tr>
		</table>
		<p class="description">
			Use the main “Save Changes” button below to save both the exam blueprints and the default exam mapping together.
		</p>
	<?php
	}
	private static function render_related_tab()
	{
		$enabled   = get_option('nm_enable_related_questions', 1);
		$count     = get_option('nm_related_questions_count', 5);
		$threshold = get_option('nm_related_similarity_threshold', 0.7);
		$position  = get_option('nm_related_position', 'bottom');
		// @MODIFIED: Changed fallback from 'rand' to 'date_desc' as SEO guardrail
		$display_order = get_option('nm_mcq_display_order', 'date_desc');
	?>
		<h2>🔗 Related Questions & Display Settings</h2>
		<p>Configure how related questions are displayed and the global sort order of questions.</p>

		<table class="form-table">
			<!-- ✅ NEW section -->
			<tr style="background: #f0f6fc; border-left: 4px solid #72aee6;">
				<th scope="row"><label for="nm_mcq_display_order">Global Display Order</label></th>
				<td>
					<select id="nm_mcq_display_order" name="nm_mcq_display_order">
						<option value="rand" <?php selected($display_order, 'rand'); ?>>Random (Default)</option>
						<option value="date_desc" <?php selected($display_order, 'date_desc'); ?>>Newest First</option>
						<option value="date_asc" <?php selected($display_order, 'date_asc'); ?>>Oldest First</option>
					</select>
					<p class="description">
						Controls the ordering of questions on <strong>Homepage, Topic Archives, Exam Archives, and Tag Pages</strong>.
						<br><em>Use 'Random' for quiz practice, 'Newest First' for news/current affairs.</em>
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row">Enable Related Questions</th>
				<td><label><input type="checkbox" name="nm_enable_related_questions" value="1" <?php checked($enabled, 1); ?>> Show related questions below each MCQ</label></td>
			</tr>
			<tr>
				<th scope="row"><label for="nm_related_questions_count">Number of Related Questions</label></th>
				<td>
					<input type="number" id="nm_related_questions_count" name="nm_related_questions_count" value="<?php echo intval($count); ?>" min="1" max="10" class="small-text">
					<p class="description">How many related questions to show (3-10)</p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="nm_related_similarity_threshold">Similarity Threshold</label></th>
				<td>
					<input type="number" id="nm_related_similarity_threshold" name="nm_related_similarity_threshold" value="<?php echo esc_attr($threshold); ?>" min="0.5" max="0.95" step="0.05" class="small-text">
					<p class="description">Minimum similarity score to show related questions (0.5 - 0.95)</p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="nm_related_position">Display Position</label></th>
				<td>
					<select id="nm_related_position" name="nm_related_position">
						<option value="bottom" <?php selected($position, 'bottom'); ?>>Below Content</option>
						<option value="sidebar" <?php selected($position, 'sidebar'); ?>>Sidebar Widget</option>
					</select>
				</td>
			</tr>
		</table>
		<hr style="margin: 30px 0;" />

		<h3>Homepage Exam Visibility</h3>
		<p>Select which exams should appear in the homepage <em>Exam</em> dropdown. The MCQs column shows how many questions are tagged with each exam so you can avoid empty filters.</p>

		<table class="form-table">
			<tr>
				<th scope="row">Visible Exams</th>
				<td>
					<?php
					$selected_slugs = get_option('nm_homepage_exam_visibility', array());
					if (! is_array($selected_slugs)) {
						$selected_slugs = array();
					}

					$exam_terms = get_terms(
						array(
							'taxonomy'   => 'nm_exam',
							'hide_empty' => false,
							'orderby'    => 'name',
							'order'      => 'ASC',
						)
					);

					if (is_wp_error($exam_terms) || empty($exam_terms)) {
						echo '<p>No exams found. Add exams under <strong>MCQs ➜ Exams</strong>.</p>';
					} else {
						echo '<table class="widefat striped" style="max-width: 520px;">';
						echo '<thead><tr><th style="width:70px;">Show</th><th>Exam</th><th style="width:90px; text-align:right;">MCQs</th></tr></thead><tbody>';

						foreach ($exam_terms as $term) {
							$checked = in_array($term->slug, $selected_slugs, true) ? 'checked="checked"' : '';
							$count   = intval($term->count); // number of posts tagged with this exam

							echo '<tr>';
							echo '<td><input type="checkbox" name="nm_homepage_exam_visibility[]" value="' . esc_attr($term->slug) . '" ' . $checked . ' /></td>';
							echo '<td>' . esc_html($term->name) . ' <code style="opacity:.7;">' . esc_html($term->slug) . '</code></td>';
							echo '<td style="text-align:right;">' . esc_html(number_format_i18n($count)) . '</td>';
							echo '</tr>';
						}

						echo '</tbody></table>';
						echo '<p class="description">If you leave everything unchecked, <strong>all</strong> exams that have MCQs will be shown.</p>';
					}
					?>
				</td>
			</tr>
		</table>
	<?php
	}

    private static function render_social_tab()
    {
        $enabled  = get_option('nm_enable_social_sharing', 0);
        // ✅ Buffer settings
        $buffer_enabled = get_option('nm_buffer_enabled', 0);
        $buffer_token   = get_option('nm_buffer_access_token', '');
        $buffer_limit   = get_option('nm_buffer_daily_limit', 5);
    ?>
        <h2>📱 Social Sharing Settings</h2>
        <p>Enable social sharing buttons on your MCQ pages to boost engagement.</p>
        <table class="form-table">
            <tr>
                <th scope="row">Enable Social Sharing</th>
                <td>
                    <label>
                        <input type="checkbox" name="nm_enable_social_sharing" value="1" <?php checked($enabled, 1); ?>>
                        Add share buttons to MCQ pages
                    </label>
                    <p class="description">Shows Facebook, Twitter, WhatsApp, and LinkedIn share buttons.</p>
                </td>
            </tr>
        </table>

        <hr style="margin: 20px 0;">
        <h3>🔄 Jetpack Publicize Auto-Share</h3>
        <p>Customize the message text that Jetpack will post when an MCQ is published.</p>

        <table class="form-table">
            <tr style="background: #f0f6fc; border-left: 4px solid #2271b1;">
                <th scope="row">Enable Jetpack Sharing</th>
                <td>
                    <?php $jetpack_enabled = get_option('nm_jetpack_enabled', 1); ?>
                    <label>
                        <input type="checkbox" name="nm_jetpack_enabled" value="1" <?php checked($jetpack_enabled, 1); ?>>
                        <strong>Enable Jetpack Publicize auto-sharing</strong>
                    </label>
                    <p class="description">
                        When enabled, the plugin will use Jetpack Publicize to share MCQs to connected social networks. Disable if you use Buffer API instead.
                    </p>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="nm_jetpack_template">Message Template</label></th>
                <td>
                    <?php
                    $template = get_option('nm_jetpack_template');
                    if (!$template) {
                        $template = "{question}\n\n{options}\n{link}\n\nLearn daily with thequizwire.com\n\nFollow WhatsApp Channel \n[Link of Channel]\n\nFollow YouTube Channel \n\n[Link of YT channel]\n\n#TheQuizWire #MCQs {tags}\n\nthequizwire GK MCQs";
                    }
                    ?>
                    <textarea name="nm_jetpack_template" id="nm_jetpack_template" rows="8" class="large-text code"><?php echo esc_textarea($template); ?></textarea>
                    <p class="description">
                        <strong>Available Tags:</strong><br>
                        <code>{question}</code>, <code>{options}</code>, <code>{link}</code>, <code>{tags}</code>
                    </p>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="nm_jetpack_daily_limit">Max Daily Auto-Shares</label></th>
                <td>
                    <?php $daily_limit = get_option('nm_jetpack_daily_limit', 5); ?>
                    <input type="number" name="nm_jetpack_daily_limit" id="nm_jetpack_daily_limit" value="<?php echo intval($daily_limit); ?>" min="0" max="100" class="small-text">
                    <p class="description">
                        Limit of automatic shares via Jetpack per day. Set to <code>0</code> for unlimited.
                    </p>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="nm_default_social_image">Default Social Image</label></th>
                <td>
                    <?php $default_social_image = get_option('nm_default_social_image', 0); ?>
                    <input type="number" name="nm_default_social_image" id="nm_default_social_image" value="<?php echo intval($default_social_image); ?>" min="0" class="small-text">
                    <p class="description">
                        Attachment ID of the fallback image for social sharing (Facebook, Twitter) when a generated social image is unavailable. Upload an image to the Media Library, then paste its ID here. Recommended: 1200x630px.
                    </p>
                </td>
            </tr>
        </table>

        <hr style="margin: 20px 0;">
        <h3>🔄 Buffer API Direct Integration (GraphQL v2)</h3>
        <p>Enable direct Buffer GraphQL API integration to bypass Jetpack and share MCQs directly to connected social media channels.</p>

        <table class="form-table">
            <tr style="background: #f0f6fc; border-left: 4px solid #2271b1;">
                <th scope="row">Enable Buffer API</th>
                <td>
                    <label>
                        <input type="checkbox" name="nm_buffer_enabled" value="1" <?php checked($buffer_enabled, 1); ?>>
                        <strong>Enable direct Buffer API auto-sharing</strong>
                    </label>
                    <p class="description">
                        When enabled, the plugin will directly post to each connected Buffer channel when an MCQ is published, bypassing Jetpack Publicize.
                    </p>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="nm_buffer_access_token">Buffer API Key</label></th>
                <td>
                    <input type="password" id="nm_buffer_access_token" name="nm_buffer_access_token" value="<?php echo esc_attr($buffer_token); ?>" class="regular-text">
                    <p class="description">
                        Your Buffer API Key (Bearer token). <a href="https://publish.buffer.com/settings/api" target="_blank">Get it here</a> &rarr; Settings &rarr; API. Make sure you have connected social accounts in your Buffer dashboard.
                    </p>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="nm_buffer_daily_limit">Max Daily Buffer Shares</label></th>
                <td>
                    <input type="number" name="nm_buffer_daily_limit" id="nm_buffer_daily_limit" value="<?php echo intval($buffer_limit); ?>" min="0" max="100" class="small-text">
                    <p class="description">
                        Limit of automatic shares via Buffer per day. Set to <code>0</code> for unlimited. This is tracked independently of Jetpack.
                    </p>
                </td>
            </tr>
        </table>

        <?php
        // Load Buffer channels for configuration UI.
        $buffer_channels = array();
        $enabled_channels = get_option('nm_buffer_enabled_channels', array());
        $channel_types = get_option('nm_buffer_channel_types', array());

        if (! empty($buffer_token)) {
            // Try to fetch channels via Buffer API if token is set.
            if (class_exists('NM_Buffer_Integration')) {
                $buffer_channels = NM_Buffer_Integration::get_channels_for_settings();
            }
        }
        ?>

        <?php if (! empty($buffer_channels)) : ?>
        <hr style="margin: 20px 0;">
        <h4>📱 Channel Configuration</h4>
        <p>Select which channels to auto-share and configure post types for each.</p>

        <table class="form-table" id="nm-buffer-channels-table">
            <thead>
                <tr>
                    <th style="width: 30px;">Enable</th>
                    <th>Channel</th>
                    <th>Service</th>
                    <th>Post Type</th>
                    <th>Share Mode</th>
                    <th style="width: 60px;">Template</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($buffer_channels as $channel_id => $channel_data) :
                    $is_enabled = in_array($channel_id, $enabled_channels, true);
                    $service = $channel_data['service'] ?? 'unknown';
                    $display_name = $channel_data['display_name'] ?? $channel_data['name'] ?? $channel_id;
                    $current_type = $channel_types[$channel_id] ?? 'post';
                    $channel_templates = get_option('nm_buffer_channel_templates', array());
                    $current_template = $channel_templates[$channel_id] ?? '';

                    // Determine valid post types for this service.
                    $valid_types = array(
                        'facebook'  => array('post' => 'Post', 'story' => 'Story', 'reel' => 'Reel'),
                        'instagram' => array('post' => 'Post', 'story' => 'Story', 'reel' => 'Reel'),
                        'twitter'   => array('post' => 'Post'),
                        'linkedin'  => array('post' => 'Post'),
                        'pinterest' => array('post' => 'Post'),
                        'youtube'   => array('post' => 'Post', 'video' => 'Video'),
                        'threads'   => array('post' => 'Post', 'story' => 'Story'),
                        'tiktok'    => array('post' => 'Post', 'video' => 'Video'),
                    );

                    $service_types = $valid_types[$service] ?? array('post' => 'Post');
                ?>
                <tr>
                    <td>
                        <input type="checkbox" name="nm_buffer_enabled_channels[]" value="<?php echo esc_attr($channel_id); ?>" <?php checked($is_enabled); ?>>
                    </td>
                    <td>
                        <?php
                        $avatar = $channel_data['avatar'] ?? '';
                        if (! empty($avatar)) {
                            echo '<img src="' . esc_url($avatar) . '" style="width: 24px; height: 24px; border-radius: 50%; vertical-align: middle; margin-right: 8px;">';
                        }
                        echo esc_html($display_name);
                        ?>
                    </td>
                    <td>
                        <span class="nm-service-badge nm-service-<?php echo esc_attr($service); ?>">
                            <?php echo esc_html(ucfirst($service)); ?>
                        </span>
                    </td>
                    <td>
                        <select name="nm_buffer_channel_types[<?php echo esc_attr($channel_id); ?>]" class="nm-post-type-select" data-service="<?php echo esc_attr($service); ?>">
                            <?php foreach ($service_types as $type => $label) : ?>
                                <option value="<?php echo esc_attr($type); ?>" <?php selected($current_type, $type); ?>>
                                    <?php echo esc_html($label); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                    <td>
                        <?php
                        $channel_modes = get_option('nm_buffer_channel_modes', array());
                        $current_mode = ! empty($channel_modes[$channel_id]) ? $channel_modes[$channel_id] : 'now';
                        ?>
                        <select name="nm_buffer_channel_modes[<?php echo esc_attr($channel_id); ?>]" class="nm-share-mode-select" data-service="<?php echo esc_attr($service); ?>">
                            <option value="now" <?php selected($current_mode, 'now'); ?>>Share ASAP</option>
                            <option value="queue" <?php selected($current_mode, 'queue'); ?>>Add to Queue</option>
                            <option value="draft" <?php selected($current_mode, 'draft'); ?>>Draft</option>
                        </select>
                    </td>
                    <td style="text-align: center;">
                        <button type="button" class="button nm-toggle-template" data-channel="<?php echo esc_attr($channel_id); ?>" title="Customize message template">
                            <span class="dashicons dashicons-edit" style="font-size: 16px; width: 16px; height: 16px; vertical-align: middle;"></span>
                        </button>
                    </td>
                </tr>
                <tr id="nm-template-row-<?php echo esc_attr($channel_id); ?>" class="nm-template-row" style="display: none;">
                    <td colspan="6" style="padding: 0 0 15px 0;">
                        <div class="nm-template-wrapper" style="background: #f6f7f7; padding: 12px; border: 1px solid #c3c4c7; border-radius: 4px;">
                            <p style="margin: 0 0 6px 0;"><strong>Custom Message Template for <?php echo esc_html($display_name); ?></strong></p>
                            <p style="margin: 0 0 6px 0; font-size: 12px; color: #666;">
                                Leave blank to use the default Jetpack template. Available tags: <code>{question}</code> <code>{options}</code> <code>{link}</code> <code>{tags}</code>
                            </p>
                            <textarea name="nm_buffer_channel_templates[<?php echo esc_attr($channel_id); ?>]" rows="5" class="large-text code"><?php echo esc_textarea($current_template); ?></textarea>

                            <?php if (in_array($service, array('facebook', 'linkedin'), true)) :
                                $link_posts = get_option('nm_buffer_channel_link_posts', array());
                                $is_link_post = ! empty($link_posts[$channel_id]);
                            ?>
                            <p style="margin: 10px 0 0 0;">
                                <label>
                                    <input type="checkbox" name="nm_buffer_channel_link_posts[<?php echo esc_attr($channel_id); ?>]" value="1" <?php checked($is_link_post, 1); ?>>
                                    <strong>Post as link</strong> — image opens the MCQ page when clicked
                                </label>
                                <span style="font-size: 12px; color: #666; display: block; margin: 3px 0 0 22px;">
                                    When checked, the post uses a link format so the preview image links to the site.
                                </span>
                            </p>
                            <?php endif; ?>

                            <?php if (in_array($service, array('instagram', 'facebook'), true)) :
                                $share_story = get_option('nm_buffer_channel_share_story', array());
                                $is_story_enabled = ! empty($share_story[$channel_id]);
                            ?>
                            <p style="margin: 10px 0 0 0;">
                                <label>
                                    <input type="checkbox" name="nm_buffer_channel_share_story[<?php echo esc_attr($channel_id); ?>]" value="1" <?php checked($is_story_enabled, 1); ?>>
                                    <strong>Also share as story</strong> — creates an additional story post with the same image (no text)
                                </label>
                                <span style="font-size: 12px; color: #666; display: block; margin: 3px 0 0 22px;">
                                    The story post will contain only the image, no text or link.
                                </span>
                            </p>
                            <?php endif; ?>

                            <?php if ($service === 'pinterest') :
                                $pinterest_boards = array();
                                if (class_exists('NM_Buffer_Integration')) {
                                    $pinterest_boards = NM_Buffer_Integration::get_pinterest_boards($channel_id);
                                }
                                $selected_board = get_option('nm_buffer_channel_pinterest_boards', array());
                                $current_board = $selected_board[$channel_id] ?? '';
                                $pinterest_titles = get_option('nm_buffer_channel_pinterest_titles', array());
                                $current_pin_title = $pinterest_titles[$channel_id] ?? '';
                            ?>
                            <div style="margin-top: 12px; padding-top: 12px; border-top: 1px solid #ddd;">
                                <p style="margin: 0 0 8px 0;"><strong>Pinterest Pin Settings</strong></p>
                                <p style="margin: 0 0 6px 0; font-size: 12px; color: #666;">
                                    <label>
                                        <strong>Pin Title</strong> (max 100 characters):<br>
                                        <input type="text" name="nm_buffer_channel_pinterest_titles[<?php echo esc_attr($channel_id); ?>]" value="<?php echo esc_attr($current_pin_title); ?>" placeholder="{question}" class="regular-text" style="margin-top: 4px;">
                                    </label>
                                    <span style="display: block; margin-top: 3px;">
                                        Available tags: <code>{question}</code> <code>{options}</code> <code>{link}</code> <code>{tags}</code>. Leave blank to use <code>{question}</code>.
                                    </span>
                                </p>
                                <p style="margin: 8px 0 0 0; font-size: 12px; color: #666;">
                                    <label>
                                        <strong>Pinterest Board</strong>:<br>
                                        <select name="nm_buffer_channel_pinterest_boards[<?php echo esc_attr($channel_id); ?>]" style="margin-top: 4px;" class="nm-pinterest-board-select">
                                            <option value="">— Select Board —</option>
                                            <?php foreach ($pinterest_boards as $board_id => $board_name) : ?>
                                                <option value="<?php echo esc_attr($board_id); ?>" <?php selected($current_board, $board_id); ?>>
                                                    <?php echo esc_html($board_name); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </label>
                                    <span style="display: block; margin-top: 3px;">
                                        Board to save the Pin to. Fetched live from Buffer.
                                    </span>
                                </p>
                            </div>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <p style="margin-top: 10px;">
            <button type="button" class="button" id="nm-refresh-buffer-channels" data-nonce="<?php echo esc_attr(wp_create_nonce('nm_refresh_buffer_channels')); ?>">
                <span class="dashicons dashicons-update" style="font-size: 16px; width: 16px; height: 16px; vertical-align: middle;"></span> Refresh Channels from Buffer
            </button>
            <span id="nm-refresh-status" style="margin-left: 10px; font-size: 12px; color: #666; display: none;"></span>
        </p>

        <style>
        .nm-service-badge {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
        }
        .nm-service-facebook { background: #1877f2; color: #fff; }
        .nm-service-instagram { background: linear-gradient(45deg, #f09433, #e6683c, #dc2743, #cc2366, #bc1888); color: #fff; }
        .nm-service-twitter, .nm-service-x { background: #000; color: #fff; }
        .nm-service-linkedin { background: #0a66c2; color: #fff; }
        .nm-service-pinterest { background: #e60023; color: #fff; }
        .nm-service-youtube { background: #ff0000; color: #fff; }
        .nm-service-threads { background: #000; color: #fff; }
        .nm-service-tiktok { background: #000; color: #fff; }
        #nm-buffer-channels-table th { background: #f0f0f1; }
        #nm-buffer-channels-table td { vertical-align: middle; }
        </style>

        <!-- Channel Configuration Warning Messages -->
        <div id="nm-buffer-warnings" style="display: none;">
            <div class="nm-buffer-story-warning" style="background: #f9f9f9; border-left: 4px solid #d63638; padding: 10px; margin: 10px 0; display: none;" data-warning-id="story-warning">
                <strong>⚠️ Important:</strong> Stories do not support clickable links. Users must manually add a link sticker in the app.
            </div>
        </div>
        </script>

        <?php elseif (! empty($buffer_token)) : ?>
        <p style="color: #d63638;">Unable to fetch channels. Please verify your Buffer API Key is correct and you have connected accounts in Buffer.</p>
        <?php endif; ?>

        <script>
        jQuery(document).ready(function($) {
            // Toggle per-channel template rows
            $('#nm-buffer-channels-table').on('click', '.nm-toggle-template', function(e) {
                e.preventDefault();
                var channelId = $(this).data('channel');
                $('#nm-template-row-' + channelId).toggle();
            });

            // Show warning when story is selected for Instagram/Facebook
            function updateStoryWarning() {
                var showWarning = false;
                
                $('#nm-buffer-channels-table select.nm-post-type-select').each(function() {
                    var service = $(this).data('service');
                    var selectedType = $(this).val();
                    
                    // Show warning if story is selected for Instagram or Facebook
                    if ((service === 'instagram' || service === 'facebook') && selectedType === 'story') {
                        showWarning = true;
                    }
                });
                
                if (showWarning) {
                    $('#nm-buffer-warnings .nm-buffer-story-warning').show();
                } else {
                    $('#nm-buffer-warnings .nm-buffer-story-warning').hide();
                }
            }
            
            // Initial check
            updateStoryWarning();
            
            // Update on change
            $('#nm-buffer-channels-table').on('change', 'select.nm-post-type-select', function() {
                updateStoryWarning();
            });

            // Refresh Channels button
            $('#nm-refresh-buffer-channels').on('click', function(e) {
                e.preventDefault();
                var btn = $(this);
                var status = $('#nm-refresh-status');
                btn.prop('disabled', true);
                status.html('Refreshing...').show();
                $.post(ajaxurl, {
                    action: 'nm_refresh_buffer_channels',
                    _wpnonce: btn.data('nonce')
                }, function(res) {
                    if (res && res.success) {
                        status.html('Done! Reloading page...').css('color', '#46b450');
                        location.reload();
                    } else {
                        status.html('Error: ' + (res?.data?.message || 'Unknown error')).css('color', '#dc3232');
                        btn.prop('disabled', false);
                    }
                }).fail(function() {
                    status.html('Network error').css('color', '#dc3232');
                    btn.prop('disabled', false);
                });
            });
        });
        </script>

    <?php
    }

	// ✅ NEW v7.3.6: Engagement Settings Tab
	private static function render_engagement_tab()
	{
		$notifications_enabled = get_option('nm_notifications_enabled', 1);
		$digest_time           = get_option('nm_daily_digest_time', '08');
		$check_interval        = get_option('nm_notification_check_interval', 30000);
		$pwa_enabled           = get_option('nm_pwa_prompt_enabled', 1);
		$pwa_delay             = get_option('nm_pwa_delay_seconds', 5);
		$pwa_visits            = get_option('nm_pwa_required_visits', 3);
	?>
		<h2>💡 Engagement Settings</h2>
		<p>Control how your site engages users via notifications and PWA install prompts.</p>

		<!-- Notifications Section -->
		<h3>🔔 Notifications</h3>
		<table class="form-table">
			<tr>
				<th scope="row">Enable Notifications</th>
				<td>
					<label>
						<input type="checkbox" name="nm_notifications_enabled" value="1" <?php checked($notifications_enabled, 1); ?>>
						<strong>Enable notification system</strong>
					</label>
					<p class="description">
						When unchecked, disables all in-app notifications (bell icon will not appear on frontend).
					</p>
				</td>
			</tr>

			<tr>
				<th scope="row"><label for="nm_daily_digest_time">Daily Digest Time</label></th>
				<td>
					<select id="nm_daily_digest_time" name="nm_daily_digest_time">
						<?php
						for ($h = 0; $h < 24; $h++) :
							$hour    = str_pad($h, 2, '0', STR_PAD_LEFT);
							$display = date('g:00 A', strtotime("{$hour}:00"));
						?>
							<option value="<?php echo $hour; ?>" <?php selected($digest_time, $hour); ?>>
								<?php echo $display; ?>
							</option>
						<?php endfor; ?>
					</select>
					<p class="description">
						Time to send daily MCQ digest notification (server time).
						<strong>Default: 8:00 AM</strong>
					</p>
				</td>
			</tr>

			<tr>
				<th scope="row"><label for="nm_notification_check_interval">Check Interval</label></th>
				<td>
					<input type="number"
						id="nm_notification_check_interval"
						name="nm_notification_check_interval"
						value="<?php echo intval($check_interval); ?>"
						min="10000"
						max="120000"
						step="1000"
						class="small-text">
					<span>milliseconds</span>
					<p class="description">
						How often to check for new notifications (10,000 - 120,000ms).
						<strong>Default: 30,000 (30 seconds)</strong>. Lower = more frequent checks.
					</p>
				</td>
			</tr>
		</table>

		<hr style="margin: 30px 0;">

		<!-- PWA Section -->
		<h3>📱 PWA Install Prompt</h3>
		<table class="form-table">
			<tr>
				<th scope="row">Enable PWA Prompt</th>
				<td>
					<label>
						<input type="checkbox" name="nm_pwa_prompt_enabled" value="1" <?php checked($pwa_enabled, 1); ?>>
						<strong>Enable PWA install banner</strong>
					</label>
					<p class="description">
						When unchecked, disables the custom PWA install prompt (users can still install via browser menu).
					</p>
				</td>
			</tr>

			<tr>
				<th scope="row"><label for="nm_pwa_delay_seconds">Prompt Delay</label></th>
				<td>
					<input type="number"
						id="nm_pwa_delay_seconds"
						name="nm_pwa_delay_seconds"
						value="<?php echo intval($pwa_delay); ?>"
						min="0"
						max="30"
						class="small-text">
					<span>seconds</span>
					<p class="description">
						Delay before showing install banner on first visit (0-30 seconds).
						<strong>Default: 5 seconds</strong>. Set to 0 for immediate display.
					</p>
				</td>
			</tr>

			<tr>
				<th scope="row"><label for="nm_pwa_required_visits">Visits After Dismissal</label></th>
				<td>
					<input type="number"
						id="nm_pwa_required_visits"
						name="nm_pwa_required_visits"
						value="<?php echo intval($pwa_visits); ?>"
						min="1"
						max="10"
						class="small-text">
					<span>visits</span>
					<p class="description">
						How many visits before showing banner again after dismissal (1-10).
						<strong>Default: 3 visits</strong>. Higher = less frequent prompts.
					</p>
				</td>
			</tr>
		</table>

		<div style="background: #f0f6fc; border-left: 4px solid #2271b1; padding: 15px; margin-top: 20px;">
			<h4 style="margin-top: 0;">💡 Tips for Engagement</h4>
			<ul style="margin-bottom: 0;">
				<li><strong>Notifications:</strong> Daily digest at 8 AM works well for most users publishing 20–60 MCQs/day</li>
				<li><strong>PWA Prompt:</strong> 5-second delay on first visit gives good conversion (~8-12%)</li>
				<li><strong>Check Interval:</strong> 30 seconds balances real-time updates with server load</li>
				<li><strong>Retry Logic:</strong> 3 visits after dismissal targets engaged users without being annoying</li>
			</ul>
		</div>
	<?php
	}

	private static function render_uninstall_tab()
	{
		$preserve      = get_option('nm_preserve_settings_on_uninstall', 'yes');
		$remove_tables = get_option('nm_remove_tables_on_uninstall', 'no');
		$delete_posts  = get_option('nm_delete_posts_on_uninstall', 'no');
		$delete_users  = get_option('nm_delete_user_data_on_uninstall', 'no');
	?>
		<h2>🗑️ Uninstall Settings</h2>
		<p>Configure what data to keep when deleting the plugin.</p>
		<table class="form-table">
			<tr>
				<th scope="row">Preserve Settings</th>
				<td>
					<label>
						<input type="checkbox" name="nm_preserve_settings_on_uninstall" value="yes" <?php checked($preserve, 'yes'); ?>>
						<strong>Keep all settings when uninstalling plugin</strong>
					</label>
					<p class="description">
						✅ <strong>Recommended:</strong> Your API keys and configurations will be preserved if you reinstall.
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row">Remove Tables</th>
				<td>
					<label>
						<input type="checkbox" name="nm_remove_tables_on_uninstall" value="yes" <?php checked($remove_tables, 'yes'); ?>>
						<strong>Drop custom database tables</strong>
					</label>
					<p class="description">
						Keeps the optimizer table, embeddings table, and other custom tables.
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row">Delete MCQs</th>
				<td>
					<label>
						<input type="checkbox" name="nm_delete_posts_on_uninstall" value="yes" <?php checked($delete_posts, 'yes'); ?>>
						<strong style="color:red;">WARNING: Delete ALL MCQ posts</strong>
					</label>
					<p class="description">
						⚠️ <strong>Important:</strong> If checked, ALL your MCQ posts will be permanently deleted!
					</p>
				</td>
			</tr>
			<tr>
				<th scope="row">Delete User Data</th>
				<td>
					<label>
						<input type="checkbox" name="nm_delete_user_data_on_uninstall" value="yes" <?php checked($delete_users, 'yes'); ?>>
						<strong style="color:red;">Delete user progress and points</strong>
					</label>
					<p class="description">
						Preserves user answer history and preferences stored in user meta.
					</p>
 </td>
 </tr>
  <tr>
  <th scope="row"><label for="nm_default_social_image">Default Social Image</label></th>
  <td>
  <?php $default_social_image = get_option('nm_default_social_image', 0); ?>
  <input type="number" name="nm_default_social_image" id="nm_default_social_image" value="<?php echo intval($default_social_image); ?>" min="0" class="small-text">
  <p class="description>
  Attachment ID of the fallback image used for social sharing (Facebook, Twitter) when a generated social image is unavailable. Upload an image to the Media Library, then paste its ID here. Recommended size: 1200x630px.
  </p>
  </td>
</tr>
  <tr>
  <th scope="row"><label for="nm_log_retention_days"><?php esc_html_e('Generation Log Retention (Days)', 'wp-news-mcq-generator'); ?></label></th>
  <td>
  	<?php
  	$min_ret = class_exists('NM_Generation_Logger') ? NM_Generation_Logger::MIN_RETENTION_DAYS : 1;
  	$max_ret = class_exists('NM_Generation_Logger') ? NM_Generation_Logger::MAX_RETENTION_DAYS : 365;
  	$ret_opt = class_exists('NM_Generation_Logger') ? NM_Generation_Logger::get_retention_days() : 30;
  	?>
  	<input type="number" name="nm_log_retention_days" id="nm_log_retention_days" value="<?php echo intval($ret_opt); ?>" min="<?php echo intval($min_ret); ?>" max="<?php echo intval($max_ret); ?>" class="small-text">
  	<p class="description">
  		<?php esc_html_e('Number of days to keep generation log rows before they are purged by the weekly cleanup cron. Minimum', 'wp-news-mcq-generator'); ?> <?php echo intval($min_ret); ?>, <?php esc_html_e('maximum', 'wp-news-mcq-generator'); ?> <?php echo intval($max_ret); ?>. <?php esc_html_e('Default', 'wp-news-mcq-generator'); ?>: 30.
  	</p>
  	<p class="description">
  		📋 <?php esc_html_e('View, filter and download logs anytime from the new "MCQ Logs" admin page.', 'wp-news-mcq-generator'); ?>
  	</p>
  </td>
  </tr>
  <tr>
  <th scope="row"><label for="nm_dashboard_api_key"><?php esc_html_e('Dashboard API Key', 'wp-news-mcq-generator'); ?></label></th>
  <td>
  	<input type="text" name="nm_dashboard_api_key" id="nm_dashboard_api_key" class="regular-text code" value="<?php echo esc_attr(get_option('nm_dashboard_api_key', '')); ?>" placeholder="<?php esc_attr_e('Auto-generate or enter manually', 'wp-news-mcq-generator'); ?>">
  	<p class="description">
  		<?php esc_html_e('API key for the Universal Plugin Dashboard to access this site\'s metrics. Leave empty to auto-generate on save.', 'wp-news-mcq-generator'); ?>
  	</p>
  	<button type="button" class="button button-secondary" id="nm-generate-dashboard-key">
  		<?php esc_html_e('Generate New Key', 'wp-news-mcq-generator'); ?>
  	</button>
  </td>
  </tr>
</table>
<?php
	}
}
?>