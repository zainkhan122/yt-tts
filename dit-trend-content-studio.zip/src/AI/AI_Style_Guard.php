<?php

/**
 * AI Style Guard
 *
 * @package DIT_TrendStudio
 */

namespace DIT\TrendStudio\AI;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Enforces editorial standards and negativity constraints on AI prompts.
 * Centralizes the "Global Negative Prompt" logic.
 */
class AI_Style_Guard
{
    /**
     * Get the standard instruction block for style enforcement.
     *
     * @param string $vertical Content vertical (general, showbiz, etc.)
     * @return string
     */
    public static function get_prompt_instruction(string $vertical = 'general'): string
    {
        $base_rules = " GLOBAL EDITORIAL RULES (STRICTLY ENFORCE):
        1. NO FLUFF: Do not use empty phrases like 'In the world of...', 'It is worth noting that...', 'Let's delve into...'.
        2. NO REPETITION: Do not repeat the same adjective twice in one paragraph.
        3. NO ROBOTIC TRANSITIONS: Avoid 'Furthermore', 'Moreover', 'In conclusion'. Use natural conversational transitions.
        4. ACTIVE VOICE: Use active voice. (Bad: 'The dress was worn by...' Good: 'She wore the dress...').
        5. SHOW, DON'T TELL: Don't say 'It was beautiful'. Describe the visual details that make it beautiful.
        6. BOLDING: You MUST bold important names (people, brands), key facts (dates, locations), and critical figures (prices, percentages) using <strong>...</strong> whenever they first appear or are emphasized.
        7. URDU NAME ACCURACY (CRITICAL): When writing Pakistani celebrity/personality names in Urdu (for social_assets or anywhere), you MUST use the CORRECT established Urdu spelling — NOT a phonetic transliteration of the English spelling. Pakistani names have standard Urdu forms that differ from naive letter-by-letter conversion. Examples of WRONG vs CORRECT: 'راجاب بٹ' is WRONG → 'رجب بٹ' is CORRECT. 'فازلہ قاضی' is WRONG → 'فاضلہ قاضی' is CORRECT. 'عائشہ خان' not 'آئشا خان'. Use your knowledge or search to verify the authentic Urdu spelling. If unsure, use the name in English script rather than guessing an incorrect Urdu transliteration.
        ";

        if ($vertical === 'showbiz') {
            $base_rules .= "
            6. CULTURAL CONTEXT: Using 'Netizens' is allowed. Using 'Trolling' is allowed.
            7. RESPECTFUL GOSSIP: Discuss rumors but clarify when unverified.
            ";
        }

        return $base_rules;
    }
}
