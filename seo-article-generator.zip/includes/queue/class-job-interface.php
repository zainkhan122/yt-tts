<?php

/**
 * Job Interface
 *
 * @package SEO_Article_Generator
 * @MODIFIED 2026-03-02 v2.19.0: Industrial Queue Architecture
 */

namespace SEO_Article_Generator\Queue;

// Prevent direct access
if (! defined('ABSPATH')) {
    exit;
}

/**
 * Contract for all queue-based jobs.
 */
interface Job_Interface
{
    /**
     * Special return value for handle() to signal that the handler has
     * already reconciled the queue ticket terminal status (completed/failed).
     */
    public const STATUS_RECONCILED = 'reconciled';

    /**
     * Execute job logic.
     *
     * @return bool|string True on success, false on failure, or STATUS_RECONCILED.
     */
    public function handle();

    /**
     * Called when job fails permanently.
     *
     * @param \Throwable $e The exception.
     * @return void
     */
    public function failed(\Throwable $e);
}
