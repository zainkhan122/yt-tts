jQuery(document).ready(function($) {
    'use strict';

    // Check if the button exists on the page
    const generateBtn = $('#nm-manual-generate-btn');
    if (generateBtn.length === 0) {
        return;
    }

    generateBtn.on('click', function() {
        const btn = $(this);
        const spinner = $('#nm-spinner');
        const logContainer = $('#nm-generation-log');
        
        // Get categories and nonce from the localized script object
        const categories = nm_admin_object.categories;
        const nonce = nm_admin_object.nonce;

        if (!categories || categories.length === 0) {
            logContainer.text('ERROR: Please select at least one news category in the settings and save.');
            return;
        }

        let currentCategoryIndex = 0;

        btn.prop('disabled', true);
        spinner.addClass('is-active');
        logContainer.text('Starting generation process...');

        function processNextCategory() {
            if (currentCategoryIndex >= categories.length) {
                logContainer.append('\n\nINFO: All categories processed. Generation complete.');
                btn.prop('disabled', false);
                spinner.removeClass('is-active');
                return;
            }

            const category = categories[currentCategoryIndex];

            $.ajax({
                url: ajaxurl, // ajaxurl is a global variable in the WP admin
                type: 'POST',
                data: {
                    action: 'nm_run_generation_for_category',
                    category: category,
                    _wpnonce: nonce // <-- CRITICAL FIX HERE (was _ajax_nonce)
                },
                success: function(response) {
                    if (response.success) {
                        logContainer.append('\n' + response.data.log.join('\n'));
                    } else {
                        logContainer.append('\nERROR: ' + response.data.message);
                    }
                    currentCategoryIndex++;
                    processNextCategory(); // Process the next one
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    logContainer.append('\n\nFATAL: A server error occurred while processing ' + category + '. Status: ' + textStatus + ', Error: ' + errorThrown);
                    btn.prop('disabled', false);
                    spinner.removeClass('is-active');
                }
            });
        }

        processNextCategory();
    });
});