/**
 * MCQ Video Studio - Flexible Content Planner
 * 
 * Handles topic generation, batch style selection, and the "Auto-Runner" loop
 * for headless video generation.
 * 
 * @version 2.0.0
 */

(function ($) {
    'use strict';

    class ContentPlanner {
        constructor() {
            this.config = window.mcqvs_planner_config || {};

            this.init();
        }

        // @FIX 2026-08-04: Convert UTC datetime string (from DB) to site-local time string for display
        utcToLocal(utcStr) {
            if (!utcStr || utcStr === '0000-00-00 00:00:00') return '';
            try {
                const d = new Date(utcStr.replace(' ', 'T') + 'Z');
                const pad = n => String(n).padStart(2, '0');
                return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
            } catch (e) {
                return utcStr;
            }
        }

        utcToLocalTime(utcStr) {
            if (!utcStr) return '';
            try {
                const d = new Date(utcStr.replace(' ', 'T') + 'Z');
                const pad = n => String(n).padStart(2, '0');
                return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
            } catch (e) {
                return utcStr.substring(11, 16) || '';
            }
        }

    init() {
        // Inject calendar chip styles (hover-to-show delete, modal overlay)
        if (!$('#mcqvs-cal-styles').length) {
            $('<style id="mcqvs-cal-styles">')
                .text(`
                    .cal-topic-chip:hover .cal-chip-delete { opacity: 1 !important; }
                    .cal-chip-delete:hover { background: rgba(255,255,255,0.25) !important; }
                    .cal-modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.4); z-index: 100000; display: flex; align-items: center; justify-content: center; }
                    .cal-modal-box { background: #fff; border-radius: 6px; box-shadow: 0 4px 24px rgba(0,0,0,0.25); max-width: 520px; width: 94%; max-height: 80vh; overflow-y: auto; padding: 20px 24px; }
                    .cal-modal-box h3 { margin: 0 0 12px; font-size: 15px; }
                    .cal-modal-topic-row { display: flex; align-items: center; gap: 8px; padding: 8px 0; border-bottom: 1px solid #eee; }
                    .cal-modal-topic-row:last-child { border-bottom: none; }
                    .cal-modal-topic-name { flex: 1; font-size: 13px; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
                    .cal-modal-topic-time { width: 90px; font-size: 13px; }
                    .cal-modal-topic-del { background: none; border: none; color: #a00; cursor: pointer; font-size: 14px; padding: 2px 4px; }
                    .cal-modal-topic-del:hover { color: #d00; }
                    .cal-modal-footer { margin-top: 14px; display: flex; gap: 8px; justify-content: flex-end; }
                `)
                .appendTo('head');
        }

        // Event Bindings
        $('#btnGeneratePlan').on('click', (e) => { e.preventDefault(); this.generateTopics(); });
        $('#btnApprovePlan').on('click', () => this.approveAndSchedule());
        $('#btnClearPlan').on('click', (e) => { e.preventDefault(); this.clearPlan(); });
        $('#btnAddTopic').on('click', () => this.addTopicRow());

        // @MODIFIED 2026-02-23: Clear All Jobs
        $('#btnClearQueue').on('click', () => this.clearQueue());
        $('#btnRunWorker').on('click', () => this.runWorker());
        $('#btnRecoverFailed').on('click', () => this.recoverFailedJobs());

        // @NEW 2026-02-23: Populate BG Video batch dropdown via AJAX (Fix 2)
        this.populateBgVideoDropdown();

        // @NEW 2026-07-10: Saved Questions Bank bindings
        const cp = this;
        $('#btnPlannerBankRefresh').on('click', () => cp.refreshBankTopics());
        $('#plannerBankTopicSelect').on('change', (e) => { cp.loadBankQuestions($(e.target).val()); });
        $('#plannerBankSourceFilter').on('change', () => {
            const topicId = $('#plannerBankTopicSelect').val();
            if (topicId) cp.loadBankQuestions(topicId);
        });
        $('#plannerBankSelectAll').on('change', function () {
            const checked = $(this).prop('checked');
            $('.planner-bank-check').prop('checked', checked);
            cp.updateBankSelectedCount();
        });
        $('#plannerBankQuestionsBody').on('change', '.planner-bank-check', () => cp.updateBankSelectedCount());
        $('#btnPlannerComposeVideo').on('click', () => cp.composeVideoFromBank());
        this.loadBankTopics();

        // @NEW 2026-04-22: Auto-select save strategy from global delivery mode
        const deliveryMode = this.config.deliveryMode || 'local';
        if ($('#saveStrategy').find(`option[value="${deliveryMode}"]`).length) {
            $('#saveStrategy').val(deliveryMode);
        }

        this.loadQueue();

        // Periodic Queue Refresh
        setInterval(() => this.loadQueue(), 30000);
        // Pipeline Awareness Banner refresh (every 20s)
        setInterval(() => this.refreshPipelineBanner(), 20000);
        this.refreshPipelineBanner();

        // @FIX 1.4.9.49: Persist sidebar toggles so they survive page reloads.
        const savePlannerToggles = () => {
            try {
                $.post(this.config.ajaxUrl, {
                    action: 'mcqvs_planner_save_toggles',
                    nonce: this.config.nonce,
                    hook_visible: $('#plannerHookVisible').prop('checked') ? '1' : '0',
                    cover_enabled: $('#plannerCoverEnabled').prop('checked') ? '1' : '0'
                });
            } catch (_) { /* best-effort */ }
        };
        $('#plannerHookVisible').on('change', savePlannerToggles);
        $('#plannerCoverEnabled').on('change', savePlannerToggles);

        // @NEW 2026-07-26: Calendar Content Scheduler
        this.initCalendar();

        // @NEW 2026-07-30: Excel/CSV Import
        const imp = this;
        $('#excelFileInput').on('change', function () {
            if (this.files && this.files.length > 0) {
                $('#btnPreviewImport').show();
                $('#btnImportExcel').hide();
                $('#importResults').hide();
                $('#smartDefaultsNotice').hide();
            }
        });
        $('#btnPreviewImport').on('click', () => imp.previewExcelImport());
        $('#btnImportExcel').on('click', () => imp.importExcelTopics());
        $('#btnStartAIGeneration').on('click', () => imp.startAIGeneration());
        $('#btnStartAIGenerationSidebar').on('click', () => imp.startAIGeneration());
        $('#btnCancelGeneration').on('click', () => imp.cancelGeneration());

        // @NEW 2026-08-02: Hook text presets - populate hook input when preset selected
        $('#plannerHookPreset').on('change', function () {
            const preset = $(this).val();
            if (preset) {
                $('#plannerHookText').val(preset);
            }
        });

        // @NEW 2026-08-03: MCQ Editor - Event delegation for dynamically loaded queue
        $('#plannerQueueList').on('click', '.mcqvs-edit-questions-btn', (e) => {
            const jobId = $(e.currentTarget).data('job-id');
            this.openMCQEditor(jobId);
        });
    }

        /**
         * Refresh the pipeline-awareness banner at the top of the page.
         * Provides a single source of truth for: queued jobs, rendering jobs, batch tracker.
         * @NEW 2026-07-05
         */
        async refreshPipelineBanner() {
            const bannerEl = document.getElementById('plannerBannerPipeline');
            const guidanceEl = document.getElementById('plannerBannerGuidance');
            if (!bannerEl) return;
            try {
                const res = await this.ajaxPost('mcqvs_get_next_pending_job');
                if (!res.success) {
                    bannerEl.textContent = 'Idle';
                    return;
                }
                const jobs = res.data.jobs || [];
                const job = res.data.job || null;
                const readyCount = jobs.filter(j => j.status === 'ready_for_render').length;
                const pendingCount = jobs.filter(j => j.status === 'pending').length;
                const renderingPicked = job ? 1 : 0;

                const parts = [];
                if (pendingCount > 0) parts.push(`${pendingCount} pending`);
                if (readyCount > 0) parts.push(`${readyCount} ready for render`);
                if (renderingPicked > 0) parts.push(`1 rendering now`);
                bannerEl.textContent = parts.length > 0 ? parts.join(' · ') : 'No jobs in queue';
                bannerEl.style.fontWeight = '600';

                // Fetch batch tracker
                try {
                    const bt = await this.ajaxPost('mcqvs_get_batch_status');
                    if (bt.success && bt.data && bt.data.summary) {
                        const s = bt.data.summary;
                        const total = (s.completed || 0) + (s.failed || 0) + (s.retrying || 0) + (s.pending || 0);
                        if (total > 0 && guidanceEl) {
                            const lines = [];
                            // @FIX 1.4.9.48: CSV-imported topics carry their questions,
                            // so "AI generation" is inaccurate — say "background processing".
                            lines.push(`Background processing: ${s.completed}/${total} batches done`);
                            if (s.retrying > 0) lines.push(`⚠️ ${s.retrying} batch(es) waiting for AI quota — auto-retry scheduled`);
                            if (s.failed > 0) lines.push(`❌ ${s.failed} batch(es) failed — see logs`);
                            if (readyCount > 0) lines.push(`📋 ${readyCount} video job(s) waiting for the Queue Auto-Runner. Open the <a href="admin.php?page=mcqvs-editor">Studio Editor</a> with Auto-Runner enabled, or enable Headless Rendering in Settings.`);
                            guidanceEl.innerHTML = lines.join('<br>');
                        }
                    }
                } catch (_) { /* tracker optional */ }
            } catch (e) {
                bannerEl.textContent = 'Pipeline status unavailable';
            }
        }

        /**
         * @NEW 2026-07-10: Load bank topics for the Saved Questions Bank dropdown.
         */
        async loadBankTopics() {
            const select = $('#plannerBankTopicSelect');
            select.empty().append($('<option>').val('').text('— Select a topic —'));
            try {
                const res = await this.ajaxPost('mcqvs_planner_get_bank_topics');
                if (!res.success || !res.data) return;
                const topics = res.data;
                if (!topics.length) {
                    $('#plannerBankQuestionStatus').text('No topics in bank yet. Run the Content Planner or generate via Topic/News Card first.');
                    return;
                }
                topics.forEach(t => {
                    select.append($('<option>').val(t.id).text(`${t.title} (${t.count})`));
                });
            } catch (e) {
                console.warn('Failed to load bank topics', e);
            }
        }

        /**
         * @NEW 2026-07-10: Load bank questions for a selected topic.
         */
        async loadBankQuestions(topicId) {
            if (!topicId) {
                $('#plannerBankQuestionsTable').hide();
                $('#plannerBankNoResults').hide();
                $('#plannerBankActionBar').hide();
                return;
            }
            const sourceFilter = $('#plannerBankSourceFilter').val() || 'all';
            $('#plannerBankQuestionStatus').text('Loading questions…');
            try {
                const res = await this.ajaxPost('mcqvs_planner_get_topic_questions', { topic_id: topicId, limit: 100 });
                const tbody = $('#plannerBankQuestionsBody');
                tbody.empty();
                if (!res.success || !res.data || !res.data.questions) {
                    $('#plannerBankQuestionsTable').hide();
                    $('#plannerBankNoResults').show();
                    $('#plannerBankActionBar').hide();
                    $('#plannerBankQuestionStatus').text('');
                    return;
                }
                let questions = res.data.questions;
                if (sourceFilter !== 'all') {
                    questions = questions.filter(q => q.source_ref === sourceFilter);
                }
                if (!questions.length) {
                    $('#plannerBankQuestionsTable').hide();
                    $('#plannerBankNoResults').show();
                    $('#plannerBankActionBar').hide();
                    $('#plannerBankQuestionStatus').text('0 questions match filter');
                    return;
                }
                questions.forEach(q => {
                    const optCount = Array.isArray(q.options) ? q.options.length : 0;
                    const createdDate = q.created_at ? q.created_at.substring(0, 10) : '';
                    const sourceLabel = q.source_ref || 'unknown';
                    const tr = $('<tr>').append(
                        $('<td>').append($('<input type="checkbox" class="planner-bank-check">').data('qid', q.id)),
                        $('<td>').text(q.question),
                        $('<td>').text(optCount),
                        $('<td>').text(sourceLabel),
                        $('<td>').text(createdDate)
                    );
                    tbody.append(tr);
                });
                $('#plannerBankQuestionStatus').text(`${questions.length} question(s) for "${res.data.title}"`);
                $('#plannerBankQuestionsTable').show();
                $('#plannerBankNoResults').hide();
                $('#plannerBankActionBar').show();
                this.updateBankSelectedCount();
            } catch (e) {
                console.warn('Failed to load bank questions', e);
                $('#plannerBankQuestionStatus').text('Error loading questions.');
            }
        }

        /**
         * @NEW 2026-07-10: Refresh bank topics dropdown.
         */
        refreshBankTopics() {
            this.loadBankTopics();
            const topicId = $('#plannerBankTopicSelect').val();
            if (topicId) {
                this.loadBankQuestions(topicId);
            }
        }

        /**
         * @NEW 2026-07-10: Update selected count label.
         */
        updateBankSelectedCount() {
            const count = $('.planner-bank-check:checked').length;
            $('#plannerBankSelectedCount').text(count > 0 ? `${count} of ${$('.planner-bank-check').length} selected` : '');
        }

        /**
         * @NEW 2026-07-10: Compose a video from selected bank questions.
         */
        async composeVideoFromBank() {
            const topicId = $('#plannerBankTopicSelect').val();
            if (!topicId) {
                alert('Please select a topic first.');
                return;
            }
            const checked = $('.planner-bank-check:checked');
            if (!checked.length) {
                alert('Please select at least one question.');
                return;
            }
            const questionIds = checked.map(function () { return $(this).data('qid'); }).get();

            const styles = {
                style_template: $('#plannerTemplate').val(),
                style_font: $('#plannerFont').val(),
                style_music: $('#plannerMusic').val(),
                style_bg_video: $('#plannerBgVideo').val(),
                save_mode: $('#saveStrategy').val(),
                hook_visible: $('#plannerHookVisible').prop('checked') ? '1' : '0',
                style_hook_text: $('#plannerHookText').val() || '',
                publish_start_date: $('#plannerPublishStartDate').val() || '',
                publish_time: $('#plannerPublishTime').val() || '09:00',
                publish_frequency: $('#plannerPublishFrequency').val() || 'daily',
                buffer_channels: JSON.stringify($('#plannerBufferChannels').val() || []),
            };

            const btn = $('#btnPlannerComposeVideo');
            btn.prop('disabled', true).text('Creating Job…');

            try {
                const res = await this.ajaxPost('mcqvs_planner_compose_video', {
                    topic_id: topicId,
                    question_ids: JSON.stringify(questionIds),
                    ...styles,
                });
                if (res.success) {
                    alert(`Video job created! (${res.data.questions} questions, topic: ${res.data.topic})`);
                    this.loadQueue();
                    this.loadCalendar(); // Refresh calendar to show new draggable chip
                    $('.planner-bank-check').prop('checked', false);
                    $('#plannerBankSelectAll').prop('checked', false);
                    $('#plannerBankActionBar').hide();
                } else {
                    alert('Failed: ' + this.getErrorMessage(res));
                }
            } catch (e) {
                console.error('Compose video failed', e);
                alert('Error composing video job.');
            } finally {
                btn.prop('disabled', false).text('🎬 Generate Video From Selection');
            }
        }

        /**
         * Generate Topics via AI
         */
        async generateTopics() {
            const niche = $('#plannerNicheInput').val().trim();
            if (!niche) {
                alert('Please enter at least one niche/topic.');
                return;
            }

            const btn = $('#btnGeneratePlan');
            btn.prop('disabled', true).text('Generating... (Please Wait)');
            $('#plannerResultsArea').hide();

            try {
                // @MODIFIED 2026-02-19: Send custom video count
                const videoCount = $('#plannerVideoCount').val() || 30;
                const res = await this.ajaxPost('mcqvs_generate_topic_plan', {
                    niche,
                    video_count: videoCount
                });
                if (res.success && res.data.topics) {
                    this.renderTopicsTable(res.data.topics);
                    $('#plannerResultsArea').fadeIn();
                } else {
                    alert('Error: ' + this.getErrorMessage(res));
                }
            } catch (e) {
                console.error(e);
                alert('Failed to generate topics.');
            } finally {
                btn.prop('disabled', false).text('✨ Generate Topics (AI)');
            }
        }

        /**
         * Approve Plan & Schedule Jobs
         */
    async approveAndSchedule() {
        let topics = [];
        $('#plannerResultsTableBody tr').each(function () {
            const title = $(this).find('.topic-title').val().trim();
            if (title) {
                const topicData = { topic: title };
                const template = $(this).find('.topic-template').val();
                const font = $(this).find('.topic-font').val();
                const music = $(this).find('.topic-music').val();
                const bgVideo = $(this).find('.topic-bgvideo').val();
                const hookText = $(this).find('.topic-hooktext').val();
                const hookVisible = $(this).find('.topic-hookvisible').val();
                // @NEW 2026-08-03: Read calendar date/time from topic row
                const publishDate = $(this).find('.topic-publish-date').val();
                const publishTime = $(this).find('.topic-publish-time').val();

                if (template) topicData.template = template;
                if (font) topicData.font = font;
                if (music) topicData.music = music;
                if (bgVideo) topicData.bg_video = bgVideo;
                if (hookText) topicData.hookText = hookText;
                if (hookVisible !== undefined && hookVisible !== '') topicData.hookVisible = hookVisible === '1';
                // @NEW 2026-08-03: Include calendar date/time if set
                if (publishDate) topicData.publish_date = publishDate;
                if (publishTime) topicData.publish_time = publishTime;

                topics.push(topicData);
            }
        });

        if (topics.length === 0) {
            alert('No topics found. Please generate or add some topics first.');
            return;
        }

        // Gather Batch Styles
        const style = {
            template: $('#plannerTemplate').val(),
            font: $('#plannerFont').val(),
            music: $('#plannerMusic').val(),
            bg_video: $('#plannerBgVideo').val(),
            save_mode: $('#saveStrategy').val(),
            hookVisible: $('#plannerHookVisible').prop('checked'),
            hookText: $('#plannerHookText').val() || '',
            video_format: $('#plannerVideoFormat').val() || 'shorts'
        };

        // @NEW 2026-05-07: Gather publish scheduling params
        const publishSchedule = {
            publish_start_date: $('#plannerPublishStartDate').val() || '',
            publish_time: $('#plannerPublishTime').val() || '09:00',
            publish_frequency: $('#plannerPublishFrequency').val() || 'daily',
        };

        // @NEW 2026-05-07: Gather selected Buffer channels
        const selectedChannels = $('#plannerBufferChannels').val() || [];
        const bufferChannels = selectedChannels.length > 0 ? JSON.stringify(selectedChannels) : '[]';

        if (!confirm(`Schedule ${topics.length} videos?`)) return;

        const btn = $('#btnApprovePlan');
        btn.prop('disabled', true).text('Scheduling...');

        try {
            // Save plan first
            await this.ajaxPost('mcqvs_save_topic_plan', { topics: JSON.stringify(topics) });

            const videosPerTopic = $('#plannerVideosPerTopic').val() || 1;
            const questionsCount = $('#plannerQuestionCount').val() || 5;
            const res = await this.ajaxPost('mcqvs_approve_topic_plan', {
                style_template: style.template,
                style_font: style.font,
                style_music: style.music,
                style_bg_video: style.bg_video,
                save_mode: style.save_mode,
                hook_visible: style.hookVisible ? '1' : '0',
                style_hook_text: style.hookText,
                style_video_format: style.video_format,
                videos_per_topic: videosPerTopic,
                questions_count: questionsCount,
                publish_start_date: publishSchedule.publish_start_date,
                publish_time: publishSchedule.publish_time,
                publish_frequency: publishSchedule.publish_frequency,
                buffer_channels: bufferChannels
            });

        if (res.success) {
            const dashboardUrl = (window.mcqvs_planner_config && window.mcqvs_planner_config.dashboardUrl)
                || (typeof adminpage !== 'undefined' ? 'admin.php?page=mcqvs-dashboard' : 'admin.php?page=mcqvs-dashboard');
            alert(
                `Plan Approved! ${res.data.count} topics are being generated by AI in the background.\n\n` +
                `Next steps:\n` +
                `• AI quiz generation runs in the background (check the AI Generation Progress bar below).\n` +
                `• After AI generation, jobs sit in "Ready for Render" — they will be picked up automatically either by:\n` +
                `   - Headless Rendering (if enabled in Settings > Headless), OR\n` +
                `   - Queue Auto-Runner on the Studio Editor page (must be open in a browser tab).\n` +
                `• Watch progress in the Dashboard: ${dashboardUrl}`
            );
            this.clearPlan();
            this.loadQueue();
            // Give the user 600ms then redirect to Dashboard for full visibility
            if (confirm('Go to Dashboard now to track progress?')) {
                window.location.href = dashboardUrl;
            }
        } else {
            alert('Scheduling failed: ' + this.getErrorMessage(res));
        }
    } catch (e) {
        console.error(e);
        alert('Error scheduling jobs.');
    } finally {
        btn.prop('disabled', false).text('\u2705 Approve & Schedule Jobs');
    }
}

    /**
     * Helper: Safely extract error message
         */
        getErrorMessage(res) {
            if (res && res.data) {
                if (typeof res.data === 'string') return res.data;
                if (res.data.message) return res.data.message;
            }
            return 'Unknown error';
        }

        clearPlan() {
            $('#plannerNicheInput').val('');
            $('#plannerResultsTableBody').empty();
            $('#plannerResultsArea').hide();
        }

        renderTopicsTable(topics) {
            const tbody = $('#plannerResultsTableBody');
            tbody.empty();

            if (!Array.isArray(topics)) return;

            topics.forEach((topicData) => {
                const title = typeof topicData === 'string' ? topicData : (topicData.topic || '');
                const template = typeof topicData === 'object' && topicData.template ? topicData.template : '';
                const font = typeof topicData === 'object' && topicData.font ? topicData.font : '';
                const music = typeof topicData === 'object' && topicData.music ? topicData.music : '';
                const bgVideo = typeof topicData === 'object' && topicData.bg_video ? topicData.bg_video : '';
                const hookText = typeof topicData === 'object' && topicData.hookText ? topicData.hookText : '';
                const hookVisible = typeof topicData === 'object' && topicData.hookVisible !== undefined ? topicData.hookVisible : '';
                // @NEW 2026-08-03: Calendar date/time fields
                const publishDate = typeof topicData === 'object' && topicData.publish_date ? topicData.publish_date : '';
                const publishTime = typeof topicData === 'object' && topicData.publish_time ? topicData.publish_time : '';

                this.addTopicRow(title, template, font, music, bgVideo, hookText, hookVisible, publishDate, publishTime);
            });
        }

        addTopicRow(title = '', template = '', font = '', music = '', bgVideo = '', hookText = '', hookVisible = '', publishDate = '', publishTime = '') {
            const templateHtml = $('#plannerTemplate').html();
            // Since #plannerFont and #plannerMusic have 'Default' options, we'll extract just the actual options
            const fontHtml = $('#plannerFont option').filter(function () { return $(this).val() !== ''; }).map(function () { return this.outerHTML; }).get().join('');
            const musicHtml = $('#plannerMusic option').filter(function () { return $(this).val() !== ''; }).map(function () { return this.outerHTML; }).get().join('');
            // @NEW 2026-02-23: BG Video options from batch default select (Fix 2)
            const bgVideoHtml = $('#plannerBgVideo option').filter(function () { return $(this).val() !== ''; }).map(function () { return this.outerHTML; }).get().join('');

            const hookVisibleVal = hookVisible === '' ? '' : (hookVisible ? '1' : '0');
            const hookVisibleHtml = `<select class="topic-hookvisible" style="width:100%;"><option value="">(Batch Default)</option><option value="1"${hookVisibleVal === '1' ? ' selected' : ''}>Show</option><option value="0"${hookVisibleVal === '0' ? ' selected' : ''}>Hide</option></select>`;

            const publishDateVal = publishDate || '';
            const publishTimeVal = publishTime || '09:00';

            const tr = $('<tr>').append(
                $('<td>').append($('<input type="text" class="topic-title" placeholder="Topic Name" style="width:100%;">').val(title)),
                $('<td>').append($(`<select class="topic-template" style="width:100%;"><option value="">(Batch Default)</option>${templateHtml}</select>`).val(template)),
                $('<td>').append($(`<select class="topic-font" style="width:100%;"><option value="">(Batch Default)</option>${fontHtml}</select>`).val(font)),
                $('<td>').append($(`<select class="topic-music" style="width:100%;"><option value="">(Batch Default)</option>${musicHtml}</select>`).val(music)),
                $('<td>').append(
                    $(`<select class="topic-bgvideo" style="width:100%;"><option value="">(Batch Default)</option>${bgVideoHtml}</select>`).val(bgVideo)
                        .on('change', function () {
                            const url = $(this).val();
                            const preview = $(this).next('.topic-bg-preview');
                            if (!url) {
                                preview.hide().attr('src', '');
                            } else {
                                preview.attr('src', url).show()[0].play().catch(() => { });
                            }
                        })
                ).append($('<video class="topic-bg-preview" style="display:none; width:100%; max-height:60px; border-radius:4px; margin-top:4px; object-fit:cover;" muted loop></video>')),
                $('<td>').append($('<input type="text" class="topic-hooktext" placeholder="(Batch Default)" style="width:100%;">').val(hookText)),
                $('<td>').append($(hookVisibleHtml).val(hookVisibleVal)),
                // @NEW 2026-08-03: Calendar date/time fields
                $('<td>').append($('<input type="date" class="topic-publish-date" style="width:100%;">').val(publishDateVal)),
                $('<td>').append($('<input type="time" class="topic-publish-time" style="width:100%;">').val(publishTimeVal)),
                $('<td>').append($('<button type="button" class="button btn-remove-topic" style="color:#d9534f; border-color:#d9534f; background:transparent;">✖</button>').on('click', function () { $(this).closest('tr').remove(); }))
            );

            const $tr = $(tr);
            if (bgVideo) {
                setTimeout(() => {
                    $tr.find('.topic-bgvideo').trigger('change');
                }, 100);
            }

            $('#plannerResultsTableBody').append($tr);
        }

        /**
         * Populate BG Video dropdowns via AJAX
         * @NEW 2026-02-23: Fix 2
         */
        populateBgVideoDropdown() {
            const cfg = this.config;
            if (!cfg.ajaxUrl || !cfg.nonce) return;

            $.post(cfg.ajaxUrl, {
                action: 'mcqvs_list_bg_videos',
                nonce: cfg.nonce
            }, (res) => {
                if (!res.success || !res.data.categories) return;
                const select = $('#plannerBgVideo');
                const cats = res.data.categories;
                for (const [cat, videos] of Object.entries(cats)) {
                    const optgroup = $('<optgroup>').attr('label', cat);
                    videos.forEach(v => {
                        const sizeMB = (v.size / (1024 * 1024)).toFixed(1);
                        optgroup.append($('<option>').val(v.url).text(`${v.filename} (${sizeMB} MB)`));
                    });
                    select.append(optgroup);
                }

                // Handle sidebar preview
                select.on('change', function () {
                    const url = $(this).val();
                    const preview = $('#plannerBgVideoPreview');
                    if (!url) {
                        preview.hide().attr('src', '');
                    } else {
                        preview.attr('src', url).show()[0].play().catch(() => { });
                    }
                });
            });
        }

        /**
         * Load Pending Queue & Progress Tracking
         */
        async loadQueue() {
            try {
                // @NEW 2026-02-19: Check Batch Progress
                this.updateBatchProgress();

                const res = await this.ajaxPost('mcqvs_get_next_pending_job');
                const container = $('#plannerQueueList');

                // Existing queue rendering logic...

                // @MODIFIED 2026-02-19: Display multiple jobs in the queue
                if (res.success && res.data.jobs && res.data.jobs.length > 0) {
                    const jobs = res.data.jobs;
                    const html = jobs.map(job => this.renderJobCard(job)).join('');
                    const footer = jobs.length >= 5 ? `<div class="queue-footer" style="margin-top:10px; font-size:12px; text-align:center;">...and more in database. <a href="#" id="btnClearQueue" style="color:#d9534f; margin-left:10px; text-decoration:none; font-weight:bold;">Clear Stuck Jobs</a></div>` : '';
                    container.html(html + footer);

                    // @NEW 2026-02-23: Update queue summary (total jobs + unique topics)
                    const uniqueTopics = new Set();
                    jobs.forEach(job => {
                        try {
                            const s = typeof job.settings === 'string' ? JSON.parse(job.settings) : job.settings;
                            if (s && s.topic_name) uniqueTopics.add(s.topic_name);
                        } catch (_) { }
                    });
                    const totalLabel = jobs.length >= 5 ? `${jobs.length}+` : jobs.length;
                    $('#queueSummary').html(`📊 ${totalLabel} jobs · ${uniqueTopics.size} topics`);

                    // Re-bind footer actions
                    $('#btnClearQueue').off('click').on('click', (e) => {
                        e.preventDefault();
                        this.clearQueue();
                    });
                } else {
                    container.html('<p style="text-align:center; color:#999; padding:20px; border:1px dashed #ccc; border-radius:4px;">No upcoming jobs found.</p>');
                    $('#queueSummary').html('');
                }
            } catch (e) {
                console.error('Failed to load queue:', e);
            }
        }

        renderJobCard(job) {
            let topicName = 'Pending Topic...'; // Fixed fallback
            try {
                if (job.settings) {
                    const settings = typeof job.settings === 'string' ? JSON.parse(job.settings) : job.settings;
                    topicName = settings.topic_name || topicName;
                }
            } catch (e) {
                console.warn('Metadata parse failed for job', job.id);
            }

            const statusClass = job.status === 'ready_for_render' ? 'status-ready' : 'status-pending';
            const statusLabel = job.status === 'ready_for_render' ? 'Ready' : (job.status === 'pending' ? 'Queued - Processing...' : job.status.replace(/_/g, ' ')); // Updated label for 'pending'

            // @NEW 2026-08-03: Show "Edit Questions" button for jobs with questions
            const canEditQuestions = job.status === 'ready_for_render' || job.status === 'rendering' || job.status === 'completed';
            const editBtn = canEditQuestions ? `<button type="button" class="button button-small mcqvs-edit-questions-btn" data-job-id="${job.id}" style="margin-top:6px;">✏️ Edit Questions</button>` : '';

            return `
                <div class="pending-job-card" style="background:#fff; border-left:4px solid ${job.status === 'ready_for_render' ? '#4caf50' : '#ffa000'}; padding:10px; margin-bottom:8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border-radius: 0 4px 4px 0;">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <strong style="font-size:13px;">${topicName}</strong>
                        <span style="font-size:11px; background:#f0f0f0; padding:2px 6px; border-radius:10px; color:#666;">ID: ${job.id}</span>
                    </div>
                    <div style="font-size:11px; color:#888; margin-top:4px;">
                        <span style="color:${job.status === 'ready_for_render' ? '#4caf50' : '#ffa000'}; font-weight:600;">● ${statusLabel}</span>
                        ${job.platform ? ` | Platform: ${job.platform}` : ''}
                    </div>
                    ${editBtn}
                </div>
            `;
        }

        slugify(text) {
            return text.toString().toLowerCase()
                .replace(/\s+/g, '-')           // Replace spaces with -
                .replace(/[^\w\-]+/g, '')       // Remove all non-word chars
                .replace(/\-\-+/g, '-')         // Replace multiple - with single -
                .replace(/^-+/, '')             // Trim - from start of text
                .replace(/-+$/, '');            // Trim - from end of text
        }

        /**
         * @NEW 2026-07-26: Calendar Content Scheduler — Initialize
         */
        initCalendar() {
            this.calendarMonth = new Date().getMonth() + 1;
            this.calendarYear = new Date().getFullYear();
            this._lastCalendarAssignments = [];
            this._pendingCalendarChanges = [];

            const cal = this;
            $('#btnCalPrev').on('click', () => { cal.calendarMonth--; if (cal.calendarMonth < 1) { cal.calendarMonth = 12; cal.calendarYear--; } cal.loadCalendar(); });
            $('#btnCalNext').on('click', () => { cal.calendarMonth++; if (cal.calendarMonth > 12) { cal.calendarMonth = 1; cal.calendarYear++; } cal.loadCalendar(); });
            $('#btnCalAutoAssign').on('click', () => cal.autoAssignCalendar());
            $('#btnCalSaveAssignments').on('click', () => cal.saveCalendarAssignments());

            this.loadCalendar();
        }

        /**
         * @NEW 2026-07-26: Load calendar data from server
         */
        async loadCalendar() {
            try {
                const res = await this.ajaxPost('mcqvs_planner_get_calendar_data', {
                    month: this.calendarMonth,
                    year: this.calendarYear
                });
                if (!res.success) return;

                const { assignments, jobs } = res.data;
                this._lastCalendarAssignments = assignments;
                this.renderCalendarGrid(assignments, jobs);
                this.renderUnassignedTopics(assignments);
            } catch (e) {
                console.warn('Calendar load failed', e);
            }
        }

        /**
         * @NEW 2026-07-26: Render the monthly calendar grid
         */
        renderCalendarGrid(assignments, jobs) {
            const container = $('#mcqvsCalendarGrid');
            const monthLabel = $('#calMonthLabel');
            const months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
            monthLabel.text(`${months[this.calendarMonth - 1]} ${this.calendarYear}`);

            const firstDay = new Date(this.calendarYear, this.calendarMonth - 1, 1).getDay();
            const daysInMonth = new Date(this.calendarYear, this.calendarMonth, 0).getDate();
            const today = new Date();
            const todayStr = today.getFullYear() + '-' + String(today.getMonth()+1).padStart(2,'0') + '-' + String(today.getDate()).padStart(2,'0');

            const dateMap = {};
            assignments.forEach(a => {
                if (!a.publish_date) return;
                if (!dateMap[a.publish_date]) dateMap[a.publish_date] = [];
                dateMap[a.publish_date].push(a);
            });

            const jobDateMap = {};
            jobs.forEach(j => {
                if (!j.publish_at) return;
                // @FIX: Convert UTC to local for calendar date grouping
                const localDt = this.utcToLocal(j.publish_at);
                const d = localDt ? localDt.substring(0, 10) : j.publish_at.substring(0, 10);
                if (!jobDateMap[d]) jobDateMap[d] = [];
                jobDateMap[d].push(j);
            });

            let html = '<table class="wp-list-table widefat fixed" style="border-collapse:collapse;">';
            html += '<thead><tr>';
            ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].forEach(d => {
                html += `<th style="padding:8px;text-align:center;font-size:11px;width:14.28%;background:#f0f0f0;">${d}</th>`;
            });
            html += '</tr></thead><tbody>';

            let day = 1;
            for (let week = 0; week < 6; week++) {
                if (day > daysInMonth) break;
                html += '<tr>';
                for (let dow = 0; dow < 7; dow++) {
                    if (week === 0 && dow < firstDay) {
                        html += '<td style="padding:6px;height:90px;vertical-align:top;background:#fafafa;"></td>';
                    } else if (day > daysInMonth) {
                        html += '<td style="padding:6px;height:90px;vertical-align:top;background:#fafafa;"></td>';
                    } else {
                        const dateStr = this.calendarYear + '-' + String(this.calendarMonth).padStart(2,'0') + '-' + String(day).padStart(2,'0');
                        const isToday = dateStr === todayStr;
                        const dayAssignments = dateMap[dateStr] || [];
                        const dayJobs = jobDateMap[dateStr] || [];
                        const borderStyle = isToday ? 'border:2px solid #2271b1;' : 'border:1px solid #e0e0e0;';
                        const bgStyle = isToday ? 'background:#f0f6ff;' : (dayAssignments.length > 0 ? 'background:#f9fff9;' : 'background:#fff;');

                        html += `<td class="cal-day-cell" data-date="${dateStr}" style="padding:6px;height:90px;vertical-align:top;${borderStyle}${bgStyle}cursor:pointer;">`;
                        html += `<div style="font-size:12px;font-weight:${isToday?'700':'400'};margin-bottom:4px;display:flex;justify-content:space-between;"><span>${day}</span></div>`;

dayAssignments.forEach(a => {
                             const timeLabel = a.publish_time ? a.publish_time : '';
                             const jobIdAttr = a._job_id ? `data-job-id="${a._job_id}"` : '';
                             const bankComposedAttr = a._bank_composed ? `data-bank-composed="true"` : '';
                             html += `<div class="cal-topic-chip" draggable="true" data-index="${a.index}" data-date="${dateStr}" data-time="${timeLabel}" style="font-size:10px;padding:2px 5px;background:#4caf50;color:#fff;border-radius:3px;margin-bottom:2px;cursor:grab;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:flex;align-items:center;position:relative;" title="${a.topic}">
                                 <span style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${a.topic.substring(0,16)}</span>
                                 <button type="button" class="cal-chip-delete" data-index="${a.index}" data-date="${dateStr}" ${jobIdAttr} ${bankComposedAttr} title="${a._bank_composed ? 'Delete from calendar and remove job' : 'Remove from this date'}" style="background:none;border:none;color:#fff;cursor:pointer;padding:0 2px;font-size:10px;line-height:1;opacity:0;transition:opacity 0.15s;">✕</button>
                             </div>`;
                         });

                        dayJobs.forEach(j => {
                            const sColor = j.status === 'completed' ? '#4caf50' : (j.status === 'rendering' ? '#ff9800' : (j.status === 'ready_for_render' ? '#2196f3' : '#9e9e9e'));
                            // @FIX: Convert UTC to local for display
                            const jTime = j.publish_at ? this.utcToLocalTime(j.publish_at) : '';
                            html += `<div style="font-size:9px;padding:1px 4px;background:${sColor};color:#fff;border-radius:2px;margin-bottom:1px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" title="${j.topic_name} [${j.status}] @ ${jTime}">${j.topic_name.substring(0,14)} ●</div>`;
                        });

                        html += '</td>';
                        day++;
                    }
                }
                html += '</tr>';
            }
            html += '</tbody></table>';
            container.html(html);

            const cal = this;
            container.find('.cal-topic-chip').on('dragstart', function(e) {
                e.originalEvent.dataTransfer.setData('text/plain', $(this).data('index'));
            });
            container.find('.cal-day-cell').on('dragover', function(e) {
                e.preventDefault();
                $(this).css('background', '#e8f5e9');
            });
            container.find('.cal-day-cell').on('dragleave', function(e) {
                const dateStr = $(this).data('date');
                const isAssigned = cal._lastCalendarAssignments.some(a => a.publish_date === dateStr);
                $(this).css('background', isAssigned ? '#f9fff9' : '#fff');
            });
            container.find('.cal-day-cell').on('drop', function(e) {
                e.preventDefault();
                const idx = parseInt(e.originalEvent.dataTransfer.getData('text/plain'));
                const targetDate = $(this).data('date');
                if (!isNaN(idx) && targetDate) {
                    cal.promptTimeForTopic(idx, targetDate);
                }
            });
            // Click on a chip → open topic modal for that date
            container.find('.cal-topic-chip').on('click', function(e) {
                e.stopPropagation();
                const dateStr = $(this).data('date');
                if (dateStr) {
                    cal.showTopicModal(dateStr);
                }
            });
            container.find('.cal-day-cell').on('click', function(e) {
                const targetDate = $(this).data('date');
                if (targetDate) {
                    cal.showTopicModal(targetDate);
                }
            });

            // Delete button handler for calendar chips
            container.find('.cal-chip-delete').on('click', function(e) {
                e.stopPropagation();
                e.preventDefault();
                const idx = parseInt($(this).data('index'));
                const dateStr = $(this).data('date');
                const a = cal._lastCalendarAssignments.find(x => x.index === idx);
                if (!a) return;

                const isBankComposed = a._bank_composed === true;
                let msg = `Remove "${a.topic}" from ${dateStr}?`;
                if (isBankComposed) {
                    msg += '\n\nThis will also delete the associated video job. Continue?';
                }

                if (confirm(msg)) {
                    const btn = $(this);
                    btn.prop('disabled', true).text('…');

                    // Use AJAX endpoint for proper job deletion
                    $.post(cal.config.ajaxUrl, {
                        action: 'mcqvs_planner_delete_calendar_assignment',
                        nonce: cal.config.nonce,
                        index: idx,
                        delete_job: isBankComposed ? '1' : '0'
                    }, function(res) {
                        if (res.success) {
                            cal.loadCalendar();
                            cal.loadQueue();
                        } else {
                            alert('Failed: ' + cal.getErrorMessage(res));
                        }
                    }).fail(function() {
                        alert('Server error');
                    }).always(function() {
                        btn.prop('disabled', false).text('✕');
                    });
                }
            });

        }

        /**
         * @NEW 2026-07-26: Prompt user for time when dropping/assigning a topic to a date
         */
        promptTimeForTopic(index, dateStr) {
            const existing = this._lastCalendarAssignments.find(a => a.index === index);
            const defaultTime = existing && existing.publish_time ? existing.publish_time : ($('#calPublishTime').val() || '09:00');
            const time = prompt(`Set publish time for ${dateStr}:`, defaultTime);
            if (time === null) return;
            if (!/^\d{1,2}:\d{2}$/.test(time)) {
                alert('Invalid time format. Use HH:MM (e.g. 09:00, 14:30).');
                return;
            }
            this.moveTopicToDate(index, dateStr, time);
        }

        /**
         * @FIXED 2026-07-30: Now shows topics already on this day for editing,
         *        then offers remaining unassigned topics. Never says "already assigned".
         */
        showAssignTopicDialog(dateStr) {
            const plan = this._lastCalendarAssignments || [];
            const onThisDay = plan.filter(a => a.publish_date === dateStr);
            const unassigned = plan.filter(a => !a.publish_date);
            const assignedElsewhere = plan.filter(a => a.publish_date && a.publish_date !== dateStr);

            let msg = `📅 ${dateStr}\n`;
            if (onThisDay.length > 0) {
                msg += `\n◆ Topics on this day:\n`;
                onThisDay.forEach((a, i) => {
                    msg += `  ${i + 1}. ${a.topic} @ ${a.publish_time || '?'}\n`;
                });
            } else {
                msg += `\n(No topics on this day yet)\n`;
            }

            if (unassigned.length === 0 && onThisDay.length > 0) {
                msg += `\n✅ All topics are scheduled. Drag chips to rearrange days.\n`;
                msg += `Enter topic # above to remove it from this day: `;
                const removePick = prompt(msg);
                if (removePick !== null) {
                    const ri = parseInt(removePick) - 1;
                    if (!isNaN(ri) && onThisDay[ri]) {
                        onThisDay[ri].publish_date = '';
                        onThisDay[ri].publish_time = '09:00';
                        this._markCalendarChanged();
                        this.loadCalendar();
                    }
                }
                return;
            }

            if (unassigned.length > 0) {
                msg += `\n◆ Unassigned topics available:\n`;
                unassigned.forEach((a, i) => {
                    msg += `  ${i + 1}. ${a.topic}\n`;
                });
                msg += `\nEnter a number to assign: `;
            } else {
                msg += `\n(No unassigned topics remaining)\n`;
                if (onThisDay.length > 0) {
                    msg += `Enter topic # above to remove from this day: `;
                }
                const finalPick = prompt(msg);
                if (finalPick !== null) {
                    const ri = parseInt(finalPick) - 1;
                    if (!isNaN(ri) && onThisDay[ri]) {
                        onThisDay[ri].publish_date = '';
                        onThisDay[ri].publish_time = '09:00';
                        this._markCalendarChanged();
                        this.loadCalendar();
                    }
                }
                return;
            }

            const pick = prompt(msg);
            if (pick === null) return;
            const idx = parseInt(pick);
            if (isNaN(idx) || idx < 1 || idx > unassigned.length) return;
            this.promptTimeForTopic(unassigned[idx - 1].index, dateStr);
        }

        /**
         * @NEW 2026-07-30: Mark calendar as having pending changes
         */
        _markCalendarChanged() {
            if (!this._pendingCalendarChanges) this._pendingCalendarChanges = [];
            const btn = $('#btnCalSaveAssignments');
            if (btn) btn.show();
        }

        /**
         * @NEW 2026-08-17: Show modal popup for all topics on a given date
         */
        showTopicModal(dateStr) {
            const cal = this;
            const plan = this._lastCalendarAssignments || [];
            const onThisDay = plan.filter(a => a.publish_date === dateStr);

            // Remove any existing modal
            $('.cal-modal-overlay').remove();

            const months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
            const dt = new Date(dateStr + 'T12:00:00');
            const dateLabel = `${months[dt.getMonth()]} ${dt.getDate()}, ${dt.getFullYear()}`;

            let rowsHtml = '';
            if (onThisDay.length === 0) {
                rowsHtml = '<p style="color:#888;font-size:13px;margin:8px 0;">No topics scheduled for this date.</p>';
            } else {
                onThisDay.forEach(a => {
                    const jobIdAttr = a._job_id ? `data-job-id="${a._job_id}"` : '';
                    const bankComposedAttr = a._bank_composed ? 'data-bank-composed="true"' : '';
                    rowsHtml += `
                        <div class="cal-modal-topic-row" data-index="${a.index}">
                            <span class="cal-modal-topic-name" title="${a.topic}">${a.topic}</span>
                            <input type="time" class="cal-modal-topic-time" value="${a.publish_time || '09:00'}" data-index="${a.index}" />
                            <button type="button" class="cal-modal-topic-del" data-index="${a.index}" ${jobIdAttr} ${bankComposedAttr} title="Remove from this date">✕</button>
                        </div>`;
                });
            }

            const modalHtml = `
                <div class="cal-modal-overlay">
                    <div class="cal-modal-box">
                        <h3>📅 ${dateLabel}</h3>
                        <div class="cal-modal-topics">${rowsHtml}</div>
                        <div class="cal-modal-footer">
                            <button type="button" class="button cal-modal-cancel">Cancel</button>
                            <button type="button" class="button button-primary cal-modal-save">Save Changes</button>
                        </div>
                    </div>
                </div>`;

            $('body').append(modalHtml);

            // Close on cancel or overlay click
            $('.cal-modal-cancel').on('click', () => $('.cal-modal-overlay').remove());
            $('.cal-modal-overlay').on('click', function(e) {
                if (e.target === this) $(this).remove();
            });

            // Delete individual topic from this date
            $('.cal-modal-topic-del').on('click', function() {
                const idx = parseInt($(this).data('index'));
                const a = cal._lastCalendarAssignments.find(x => x.index === idx);
                if (!a) return;
                const isBankComposed = a._bank_composed === true;
                let msg = `Remove "${a.topic}" from ${dateStr}?`;
                if (isBankComposed) msg += '\n\nThis will also delete the associated video job.';
                if (confirm(msg)) {
                    $.post(cal.config.ajaxUrl, {
                        action: 'mcqvs_planner_delete_calendar_assignment',
                        nonce: cal.config.nonce,
                        index: idx,
                        delete_job: isBankComposed ? '1' : '0'
                    }, function(res) {
                        if (res.success) {
                            cal.loadCalendar();
                            cal.loadQueue();
                            // Refresh the modal
                            cal.showTopicModal(dateStr);
                        } else {
                            alert('Failed: ' + cal.getErrorMessage(res));
                        }
                    }).fail(function() { alert('Server error'); });
                }
            });

            // Save button: collect all time changes and apply
            $('.cal-modal-save').on('click', function() {
                const btn = $(this);
                btn.prop('disabled', true).text('Saving…');
                let hasError = false;

                $('.cal-modal-topic-row').each(function() {
                    const idx = parseInt($(this).find('.cal-modal-topic-time').data('index'));
                    const newTime = $(this).find('.cal-modal-topic-time').val() || '09:00';
                    if (!/^\d{1,2}:\d{2}$/.test(newTime)) {
                        alert('Invalid time format. Use HH:MM (e.g. 09:00, 14:30).');
                        hasError = true;
                        return false; // break each
                    }
                    cal.moveTopicToDate(idx, dateStr, newTime);
                });

                if (!hasError) {
                    cal._markCalendarChanged();
                    cal.renderCalendarGrid(cal._lastCalendarAssignments, []);
                    cal.renderUnassignedTopics(cal._lastCalendarAssignments);
                }
                btn.prop('disabled', false).text('Save Changes');
                $('.cal-modal-overlay').remove();
            });
        }

        /**
         * @NEW 2026-07-26: Render unassigned topics sidebar
         */
        renderUnassignedTopics(assignments) {
            const container = $('#calUnassignedTopics');
            const unassigned = assignments.filter(a => !a.publish_date);

            if (unassigned.length === 0) {
                container.html('<p style="color:#999;font-size:12px;text-align:center;">All topics assigned to dates.</p>');
                return;
            }

            let html = '';
            unassigned.forEach(a => {
                html += `<div class="cal-unassigned-chip" draggable="true" data-index="${a.index}" style="padding:6px 10px;background:#fff;border:1px solid #ddd;border-radius:4px;margin-bottom:4px;cursor:grab;font-size:12px;display:flex;justify-content:space-between;align-items:center;">
                    <span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1;">${a.topic}</span>
                    <button type="button" class="button button-small cal-assign-btn" data-index="${a.index}" style="margin-left:6px;flex-shrink:0;">📅</button>
                    <button type="button" class="button button-small cal-unassign-delete" data-index="${a.index}" title="Delete topic from plan" style="margin-left:4px;flex-shrink:0;color:#d9534f;">✕</button>
                </div>`;
            });
            container.html(html);

            const cal = this;
            container.find('.cal-unassigned-chip').on('dragstart', function(e) {
                e.originalEvent.dataTransfer.setData('text/plain', $(this).data('index'));
            });
            container.find('.cal-assign-btn').on('click', function(e) {
                e.stopPropagation();
                const idx = $(this).data('index');
                const date = prompt('Enter publish date (YYYY-MM-DD):');
                if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
                    if (date) alert('Invalid date format. Use YYYY-MM-DD.');
                    return;
                }
                cal.promptTimeForTopic(idx, date);
            });
            container.find('.cal-unassign-delete').on('click', function(e) {
                e.stopPropagation();
                const idx = $(this).data('index');
                const a = cal._lastCalendarAssignments.find(x => x.index === idx);
                if (a && confirm(`Delete "${a.topic}" from plan entirely?`)) {
                    // Remove from plan via AJAX
                    $.post(cal.config.ajaxUrl, {
                        action: 'mcqvs_save_topic_plan',
                        nonce: cal.config.nonce,
                        topics: JSON.stringify(cal._lastCalendarAssignments.filter(x => x.index !== idx))
                    }, function(res) {
                        if (res.success) {
                            cal.loadCalendar();
                            cal.loadQueue();
                        } else {
                            alert('Failed: ' + cal.getErrorMessage(res));
                        }
                    }).fail(function() { alert('Server error'); });
                }
            });
        }

        /**
         * @NEW 2026-07-26: Move a topic to a specific date with time
         */
        moveTopicToDate(index, dateStr, time) {
            if (!this._pendingCalendarChanges) this._pendingCalendarChanges = [];
            // Remove any prior pending change for the same index
            this._pendingCalendarChanges = this._pendingCalendarChanges.filter(c => c.index !== index);
            this._pendingCalendarChanges.push({ index, publish_date: dateStr, publish_time: time });
            // Optimistic local update
            const a = this._lastCalendarAssignments.find(x => x.index === index);
            if (a) {
                a.publish_date = dateStr;
                a.publish_time = time;
            }
            this.renderCalendarGrid(this._lastCalendarAssignments, []);
            this.renderUnassignedTopics(this._lastCalendarAssignments);
            $('#btnCalSaveAssignments').show();
        }

        /**
         * @NEW 2026-07-26: Auto-assign topics to calendar dates
         */
        async autoAssignCalendar() {
            const startDate = $('#calStartDate').val();
            const frequency = $('#calFrequency').val();
            const publishTime = $('#calPublishTime').val() || '09:00';

            if (!startDate) {
                alert('Please set a start date first.');
                return;
            }

            const btn = $('#btnCalAutoAssign');
            btn.prop('disabled', true).text('Assigning...');

            try {
                const res = await this.ajaxPost('mcqvs_planner_auto_assign_calendar', {
                    start_date: startDate,
                    frequency: frequency,
                    publish_time: publishTime
                });
                if (res.success) {
                    alert(`Auto-assigned ${res.data.assigned} topics starting ${res.data.start} (${res.data.frequency}, ${res.data.per_day}x/day).`);
                    this._pendingCalendarChanges = [];
                    this.loadCalendar();
                } else {
                    alert('Failed: ' + this.getErrorMessage(res));
                }
            } catch (e) {
                console.error(e);
                alert('Auto-assign failed.');
            } finally {
                btn.prop('disabled', false).text('Auto-Assign Dates');
            }
        }

        /**
         * @NEW 2026-07-26: Save calendar assignments to server
         */
        async saveCalendarAssignments() {
            if (!this._pendingCalendarChanges || this._pendingCalendarChanges.length === 0) {
                alert('No changes to save.');
                return;
            }

            const btn = $('#btnCalSaveAssignments');
            btn.prop('disabled', true).text('Saving...');

            try {
                const body = JSON.stringify(this._pendingCalendarChanges);
                console.log('Saving assignments:', body);
                const res = await this.ajaxPost('mcqvs_planner_save_calendar_assignments', {
                    assignments: body
                });
                if (res.success) {
                    this._pendingCalendarChanges = [];
                    alert(`Saved ${res.data.saved} date assignments.`);
                    this.loadCalendar();
                    btn.hide();
                } else {
                    alert('Failed: ' + this.getErrorMessage(res));
                }
            } catch (e) {
                console.error('Save assignments error:', e);
                console.error('Response text:', e.responseText);
                alert('Save failed. Check console (F12) for details.');
            } finally {
                btn.prop('disabled', false).text('Save Date Assignments');
            }
        }

        ajaxPost(action, data = {}) {
            return new Promise((resolve, reject) => {
                $.ajax({
                    url: this.config.ajaxUrl,
                    method: 'POST',
                    data: {
                        action: action,
                        nonce: this.config.nonce,
                        ...data
                    },
                    success: (res) => resolve(res),
                    error: (err) => reject(err)
                });
            });
        }

        async runWorker() {
            const btn = $('#btnRunWorker');
            btn.prop('disabled', true).text('Triggering Worker...');
            try {
                const res = await this.ajaxPost('mcqvs_run_worker', {});
                alert(res.data.message || 'Worker triggered.');
                this.loadQueue();
            } catch (e) {
                console.error('Failed to trigger worker', e);
            } finally {
                btn.prop('disabled', false).text('Process Pending Batches Now');
            }
        }

        async recoverFailedJobs() {
            if (!confirm('Reset auto-cleaned FAILED jobs back to pending/ready_for_render? Jobs with future scheduled times will wait until their slot.')) return;
            const btn = $('#btnRecoverFailed');
            btn.prop('disabled', true).text('Recovering...');
            try {
                const res = await this.ajaxPost('mcqvs_recover_failed_jobs', {});
                alert(res.data.message || 'Recovery done.');
                this.loadQueue();
            } catch (e) {
                console.error('Failed to recover jobs', e);
            } finally {
                btn.prop('disabled', false).text('Recover Failed Jobs');
            }
        }

        // @MODIFIED 2026-02-23: Clear ALL jobs (not just stuck)
        async clearQueue() {
            if (!confirm('⚠️ This will delete ALL jobs from the database (pending, completed, stuck). Are you sure?')) return;
            if (!confirm('This cannot be undone. Really clear ALL jobs?')) return;

            try {
                const res = await this.ajaxPost('mcqvs_clear_all_jobs', {});
                if (res.success) {
                    alert(res.data.message || 'All jobs cleared.');
                    this.loadQueue();
                }
            } catch (e) {
                console.error('Failed to clear queue', e);
            }
        }

        /**
         * @NEW 2026-02-19: Fetch and Display Background Batch Progress
         */
        async updateBatchProgress() {
            try {
                const res = await this.ajaxPost('mcqvs_get_batch_status');
                if (!res.success || !res.data.summary) return;

                const { completed, failed, retrying, pending } = res.data.summary;
                const total = completed + failed + retrying + (pending || 0);

                if (total === 0) {
                    $('#batchStatusArea').hide();
                    return;
                }

                let statusHtml = `
                    <div id="batchStatusArea" style="background: #f8f9fa; border: 1px solid #ddd; border-radius: 4px; padding: 10px; margin-bottom: 15px;">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px;">
                            <strong style="font-size: 13px;">AI Generation Progress</strong>
                            <span style="font-size: 12px; color: #666;">${completed} / ${total} Batches Done</span>
                        </div>
                        <div style="height: 8px; background: #eee; border-radius: 4px; overflow: hidden; margin-bottom: 10px;">
                            <div style="width: ${(completed / total) * 100}%; height: 100%; background: #4caf50; transition: width 0.5s;"></div>
                        </div>
                `;

                if (retrying > 0) {
                    statusHtml += `<div style="font-size: 11px; color: #ffa000; margin-top: 5px;">⚠️ ${retrying} batches waiting for Gemini Quota (Retrying automatically...)</div>`;
                }

                // @NEW 2026-08-03: Per-batch detail with retry buttons
                // @FIX 1.4.9.48: skip metadata keys (e.g. '_batch_id') — only render
                // numeric batch rows, so no more "Batch #NaN / unknown" entries.
                const batchEntries = (res.data.batches && typeof res.data.batches === 'object')
                    ? Object.entries(res.data.batches).filter(([k]) => !(String(k).indexOf('_') === 0))
                    : [];
                if (batchEntries.length > 0) {
                    statusHtml += `<details style="margin-top:10px;"><summary style="cursor:pointer;font-size:12px;color:#2271b1;">📋 Batch Details</summary><div style="margin-top:8px;max-height:200px;overflow-y:auto;">`;
                    batchEntries.forEach(([batchIndex, batch]) => {
                        const bStatus = batch.status || 'unknown';
                        const bSuccess = batch.success || 0;
                        const bTotal = batch.total_jobs || batch.topics || 0;
                        const bFailed = batch.failed ? batch.failed.length : 0;
                        const bTime = batch.time ? new Date(batch.time + ' UTC').toLocaleString() : '—';
                        const bError = batch.error || '';

                        let statusColor = '#9e9e9e';
                        if (bStatus === 'completed') statusColor = '#4caf50';
                        else if (bStatus === 'failed') statusColor = '#d9534f';
                        else if (bStatus === 'rate_limited') statusColor = '#ffa000';
                        else if (bStatus === 'pending') statusColor = '#2196f3';

                        statusHtml += `
                            <div style="border:1px solid #ddd;border-radius:4px;padding:8px;margin-bottom:6px;background:#fff;font-size:11px;">
                                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px;">
                                    <strong>Batch #${parseInt(batchIndex)+1}</strong>
                                    <span style="color:${statusColor};font-weight:600;">● ${bStatus}</span>
                                </div>
                                <div style="color:#666;">${bSuccess}/${bTotal} jobs · ${bTime}</div>
                        `;

                        if (bError) {
                            statusHtml += `<div style="color:#d9534f;margin-top:4px;font-family:monospace;font-size:10px;">${bError.substring(0,120)}</div>`;
                        }

                        if (bStatus === 'failed' && bFailed > 0) {
                            statusHtml += `
                                <button type="button" class="button button-small mcqvs-retry-batch-btn" 
                                        data-batch-index="${batchIndex}" 
                                        style="margin-top:6px;background:#d9534f;color:#fff;border-color:#d9534f;">
                                    🔄 Retry ${bFailed} Failed Topic(s)
                                </button>
                            `;
                        }

                        statusHtml += `</div>`;
                    });
                    statusHtml += `</div></details>`;
                }

                if (failed > 0 && (!res.data.batches || Object.keys(res.data.batches).length === 0)) {
                    statusHtml += `<div style="font-size: 11px; color: #d9534f; margin-top: 5px;">❌ ${failed} batches failed. Check logs for details.</div>`;
                }

                statusHtml += `</div>`;

                // Inject into container if not exists
                if ($('#batchStatusArea').length) {
                    $('#batchStatusArea').replaceWith(statusHtml);
                } else {
                    $('#plannerQueueList').before(statusHtml);
                }

                // Bind retry buttons
                $('#batchStatusArea .mcqvs-retry-batch-btn').off('click').on('click', (e) => {
                    const batchIndex = parseInt($(e.currentTarget).data('batch-index'), 10);
                    this.retryFailedBatch(batchIndex);
                });

                // @NEW 2026-08-03: Show/hide Cancel button based on active batches
                this.updateCancelButtonVisibility(res.data.batches);

            } catch (e) {
                console.warn('Progress poll failed', e);
            }
        }

        /**
         * @NEW 2026-08-03: Update Cancel Pending AI Generation button visibility
         * Shows only when there are batches with status 'pending' or 'rate_limited'
         */
        updateCancelButtonVisibility(batches) {
            const hasActive = batches && Object.values(batches).some(b => 
                b.status === 'pending' || b.status === 'rate_limited'
            );
            $('#btnCancelGeneration').toggle(hasActive);
        }

        /**
         * @NEW 2026-08-03: Retry failed topics for a specific batch
         */
        async retryFailedBatch(batchIndex) {
            if (!confirm(`Retry failed topics for batch #${batchIndex + 1}?`)) return;

            const btn = $(`.mcqvs-retry-batch-btn[data-batch-index="${batchIndex}"]`);
            const originalText = btn.text();
            btn.prop('disabled', true).text('Retrying...');

            try {
                const res = await this.ajaxPost('mcqvs_retry_failed_topics', { batch_index: batchIndex + 1 });
                if (res.success) {
                    alert(`✅ ${res.data.message}`);
                    this.updateBatchProgress();
                } else {
                    alert('Failed: ' + this.getErrorMessage(res));
                }
            } catch (e) {
                console.error('Retry failed', e);
                alert('Retry failed. Check console.');
            } finally {
                btn.prop('disabled', false).text(originalText);
            }
        }

        /**
         * @NEW 2026-07-30: Preview Excel/CSV file before importing
         */
        async previewExcelImport() {
            const fileInput = $('#excelFileInput')[0];
            if (!fileInput || !fileInput.files || !fileInput.files.length) {
                alert('Please select a file first.');
                return;
            }

            $('#importProgress').show();
            $('#progressText').text('Previewing file...');
            $('#progressBar').css('width', '20%');
            $('#progressPercent').text('20%');

            try {
                const res = await this.uploadFile('mcqvs_preview_excel_import', fileInput.files[0]);
                $('#progressBar').css('width', '100%');
                $('#progressPercent').text('100%');

                if (!res.success) {
                    alert('Preview failed: ' + this.getErrorMessage(res));
                    $('#importProgress').hide();
                    return;
                }

                const data = res.data;
                let previewHtml = '<div style="margin-bottom:12px;">';
                previewHtml += `<strong>📄 File:</strong> ${data.file_name} — <strong>Topics found:</strong> ${data.topics_count}<br>`;

                if (data.notes && data.notes.length) {
                    previewHtml += '<div style="background:#fff8e1;border:1px solid #ffe082;border-radius:4px;padding:8px;margin:8px 0;font-size:11px;">';
                    data.notes.forEach(n => { previewHtml += `✓ ${n}<br>`; });
                    previewHtml += '</div>';
                }

                previewHtml += '</div>';

                if (data.processed_topics && data.processed_topics.length > 0) {
                    previewHtml += '<div style="max-height:220px;overflow-y:auto;border:1px solid #ddd;border-radius:4px;padding:8px;background:#fff;">';
                    data.processed_topics.slice(0, 8).forEach((t, i) => {
                        previewHtml += `<div style="padding:4px 0;border-bottom:1px solid #f0f0f0;font-size:12px;">
                            <strong>${i + 1}.</strong> ${t.topic || '?'}
                            <span style="color:#666;"> — 🕐${t.publish_time || '?'} 🎨${t.template || 'auto'} 💾${t.save_mode || 'r2+buffer'}</span>
                        </div>`;
                    });
                    if (data.processed_topics.length > 8) {
                        previewHtml += `<div style="font-size:11px;color:#999;padding:4px;">...and ${data.processed_topics.length - 8} more</div>`;
                    }
                    previewHtml += '</div>';
                }

                $('#previewContent').html(previewHtml);
                $('#smartDefaultsNotice').show();
                $('#importResults').show();
                $('#btnImportExcel').show();
                $('html, body').animate({ scrollTop: $('#importResults').offset().top - 80 }, 400);
            } catch (e) {
                console.error('Preview error', e);
                alert('Preview failed. Check console.');
            } finally {
                setTimeout(() => { $('#importProgress').hide(); }, 800);
            }
        }

        /**
         * @NEW 2026-07-30: Execute the import after user approves preview
         */
        async importExcelTopics() {
            const fileInput = $('#excelFileInput')[0];
            if (!fileInput || !fileInput.files || !fileInput.files.length) return;

            if (!confirm('Import ' + fileInput.files[0].name + '? Topics will be added to the content plan with smart defaults applied.')) return;

            $('#importProgress').show();
            $('#progressText').text('Importing topics...');
            $('#progressBar').css('width', '10%');
            $('#progressPercent').text('10%');

            try {
                const res = await this.uploadFile('mcqvs_import_topics_from_excel', fileInput.files[0]);
                $('#progressBar').css('width', '100%');
                $('#progressPercent').text('100%');

                if (!res.success) {
                    alert('Import failed: ' + this.getErrorMessage(res));
                    $('#importProgress').hide();
                    return;
                }

                alert('✅ ' + res.data.message);
                this.loadQueue();
                this.loadCalendar();
                $('#btnStartAIGeneration').show();
                $('#btnStartAIGenerationSidebar').show();

                if (confirm('View the imported topics in the Calendar to set dates?')) {
                    $('html, body').animate({ scrollTop: $('#mcqvsCalendarGrid').offset().top - 80 }, 400);
                }
            } catch (e) {
                console.error('Import error', e);
                alert('Import failed. Check console.');
            } finally {
                setTimeout(() => { $('#importProgress').hide(); }, 800);
            }
        }

        /**
         * @NEW 2026-07-30: Upload a file via AJAX (FormData)
         */
        uploadFile(action, file) {
            return new Promise((resolve, reject) => {
                const fd = new FormData();
                fd.append('action', action);
                fd.append('nonce', this.config.nonce);
                fd.append('excel_file', file);
                fd.append('start_date', $('#plannerPublishStartDate').val() || '');
                // @FIX 1.4.9.48: send the sidebar controls so CSV imports honor them:
                // hook visibility, cover page, template, format, save mode, schedule.
                fd.append('hook_visible', $('#plannerHookVisible').prop('checked') ? '1' : '0');
                fd.append('cover_enabled', $('#plannerCoverEnabled').prop('checked') ? '1' : '0');
                fd.append('style_template', $('#plannerTemplate').val() || '');
                fd.append('style_video_format', $('#plannerVideoFormat').val() || 'shorts');
                fd.append('save_mode', $('#saveStrategy').val() || 'r2_buffer');
                fd.append('publish_time', $('#plannerPublishTime').val() || '09:00');
                fd.append('publish_frequency', $('#plannerPublishFrequency').val() || 'daily');
                fd.append('video_per_topic', $('#plannerVideosPerTopic').val() || '1');
                fd.append('questions_per_video', $('#plannerQuestionCount').val() || '5');

                $.ajax({
                    url: this.config.ajaxUrl,
                    method: 'POST',
                    data: fd,
                    processData: false,
                    contentType: false,
                    success: (res) => resolve(res),
                    error: (err) => reject(err)
                });
            });
        }

        /**
         * @NEW 2026-07-30: Start AI question generation for imported topics
         */
        async startAIGeneration() {
            // @FIX 1.4.9.53 (global STOP): block Start-AI while the dashboard
            // "Stop Everything" flag is set (server rejects too, belt & braces).
            if (window.mcqvs_planner_config && window.mcqvs_planner_config.globalStopped) {
                alert('Pipeline is STOPPED. Click "Resume" on the Dashboard before starting AI generation.');
                return;
            }
            const btns = $('#btnStartAIGeneration, #btnStartAIGenerationSidebar');
            if (!confirm('Start AI question generation for imported topics? This will process all topics in the plan and create video jobs.')) return;

            btns.prop('disabled', true).text('Starting AI generation...');

            try {
                const style = {
                    template: $('#plannerTemplate').val() || '',
                    font: $('#plannerFont').val() || '',
                    music: $('#plannerMusic').val() || '',
                    bg_video: $('#plannerBgVideo').val() || '',
                    save_mode: $('#saveStrategy').val() || 'local',
                    hookVisible: $('#plannerHookVisible').prop('checked'),
                    hookText: $('#plannerHookText').val() || '',
                    video_format: $('#plannerVideoFormat').val() || 'shorts'
                };
                const publishSchedule = {
                    publish_start_date: $('#plannerPublishStartDate').val() || '',
                    publish_time: $('#plannerPublishTime').val() || '09:00',
                    publish_frequency: $('#plannerPublishFrequency').val() || 'daily',
                };
                const selectedChannels = $('#plannerBufferChannels').val() || [];
                const bufferChannels = selectedChannels.length > 0 ? JSON.stringify(selectedChannels) : '[]';
                const videosPerTopic = $('#plannerVideosPerTopic').val() || 1;
                const questionsCount = $('#plannerQuestionCount').val() || 5;

                const res = await this.ajaxPost('mcqvs_approve_topic_plan', {
                    style_template: style.template,
                    style_font: style.font,
                    style_music: style.music,
                    style_bg_video: style.bg_video,
                    save_mode: style.save_mode,
                    hook_visible: style.hookVisible ? '1' : '0',
                    cover_enabled: $('#plannerCoverEnabled').prop('checked') ? '1' : '0',
                    style_hook_text: style.hookText,
                    style_video_format: style.video_format,
                    videos_per_topic: videosPerTopic,
                    questions_count: questionsCount,
                    publish_start_date: publishSchedule.publish_start_date,
                    publish_time: publishSchedule.publish_time,
                    publish_frequency: publishSchedule.publish_frequency,
                    buffer_channels: bufferChannels
                });

                if (res.success) {
                    const dashboardUrl = (window.mcqvs_planner_config && window.mcqvs_planner_config.dashboardUrl)
                        || 'admin.php?page=mcqvs-dashboard';
                    alert(
                        `AI Generation Started! ${res.data.count} topics are being processed in the background.\n\n` +
                        `Next steps:\n` +
                        `• AI quiz generation runs in background (check Dashboard for progress).\n` +
                        `• After AI generation, jobs sit in "Ready for Render" — auto-rendered.\n` +
                        `• Watch progress in the Dashboard: ${dashboardUrl}`
                    );
                    $('#btnCancelGeneration').show();
                    this.loadQueue();
                    if (confirm('Go to Dashboard now to track progress?')) {
                        window.location.href = dashboardUrl;
                    }
                } else {
                    alert('AI generation failed: ' + this.getErrorMessage(res));
                }
            } catch (e) {
                console.error('AI generation error:', e);
                alert('AI generation failed. Check console for details.');
            } finally {
                btns.prop('disabled', false).text('🎬 Start AI Question Generation');
            }
        }

        /**
         * @NEW 2026-07-30: Cancel pending AI generation batches
         */
        async cancelGeneration() {
            if (!confirm('Cancel all pending AI generation batches? This stops background processing and clears the batch tracker. Already generated jobs remain.')) return;

            const btn = $('#btnCancelGeneration');
            btn.prop('disabled', true).text('Cancelling...');

            try {
                const res = await this.ajaxPost('mcqvs_cancel_pending_batches', {});
                if (res.success) {
                    alert('✅ ' + res.data.message);
                    btn.hide();
                    this.loadQueue();
                } else {
                    alert('Failed: ' + this.getErrorMessage(res));
                }
            } catch (e) {
                console.error('Cancel error:', e);
                alert('Failed to cancel. Check console.');
} finally {
                btn.prop('disabled', false).text('🛑 Cancel Pending AI Generation');
            }
        }

/**
 * @NEW 2026-08-03: MCQ Editor - Open modal to edit questions for a job
 */
async openMCQEditor(jobId) {
    const btn = $(`.mcqvs-edit-questions-btn[data-job-id="${jobId}"]`);
    const originalText = btn.text();
    btn.prop('disabled', true).text('Loading...');

    try {
        const res = await this.ajaxPost('mcqvs_get_job_questions', { job_id: jobId });
        if (!res.success) {
            alert('Failed to load questions: ' + this.getErrorMessage(res));
            return;
        }

        this.showMCQEditorModal(res.data);
    } catch (e) {
        console.error('Failed to load questions', e);
        alert('Failed to load questions. Check console.');
    } finally {
        btn.prop('disabled', false).text(originalText);
    }
}

/**
 * @NEW 2026-08-03: MCQ Editor - Show modal with question editor
 */
showMCQEditorModal(data) {
    const { job_id, topic, questions, status, publish_at } = data;

    // Remove existing modal if any
    $('#mcqvs-mcq-editor-modal').remove();

    const publishInfo = publish_at ? `<div style="font-size:11px;color:#666;margin-bottom:10px;">📅 Scheduled Publish: ${this.utcToLocal(publish_at)} (site local) / ${publish_at} UTC</div>` : '';

    const modalHtml = `
        <div id="mcqvs-mcq-editor-modal" style="position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.5);z-index:100000;display:flex;align-items:center;justify-content:center;overflow-y:auto;padding:20px;">
            <div style="background:#fff;width:100%;max-width:900px;max-height:90vh;border-radius:8px;box-shadow:0 4px 20px rgba(0,0,0,0.2);display:flex;flex-direction:column;">
                <div style="padding:15px 20px;border-bottom:1px solid #ddd;display:flex;justify-content:space-between;align-items:center;">
                    <h2 style="margin:0;font-size:16px;">✏️ Edit Questions — ${topic}</h2>
                    <button type="button" id="mcqvs-mcq-editor-close" style="background:none;border:none;font-size:24px;cursor:pointer;color:#999;">&times;</button>
                </div>
                ${publishInfo}
                <div style="padding:15px 20px;border-bottom:1px solid #eee;background:#fafafa;font-size:12px;color:#666;">
                    <strong>Job ID:</strong> ${job_id} | <strong>Status:</strong> ${status} | <strong>Questions:</strong> ${questions.length}
                </div>
                <div id="mcqvs-mcq-editor-body" style="flex:1;overflow-y:auto;padding:20px;">
                    ${this.renderMCQEditorQuestions(questions)}
                </div>
                <div style="padding:15px 20px;border-top:1px solid #ddd;display:flex;justify-content:flex-end;gap:10px;background:#fafafa;">
                    <button type="button" id="mcqvs-mcq-editor-cancel" class="button">Cancel</button>
                    <button type="button" id="mcqvs-mcq-editor-save" class="button button-primary" data-job-id="${job_id}">💾 Save Changes</button>
                </div>
            </div>
        </div>
    `;

    $('body').append(modalHtml);

    // Bind events
    const modal = $('#mcqvs-mcq-editor-modal');
    modal.find('#mcqvs-mcq-editor-close, #mcqvs-mcq-editor-cancel').on('click', () => modal.remove());
    modal.on('click', (e) => { if (e.target === modal[0]) modal.remove(); });
    modal.find('#mcqvs-mcq-editor-save').on('click', (e) => this.saveMCQEditorChanges($(e.currentTarget).data('job-id'), modal));

    // Add/remove question handlers
    modal.on('click', '.mcqvs-mcq-add-question', () => this.addMCQEditorQuestion(modal));
    modal.on('click', '.mcqvs-mcq-remove-question', (e) => this.removeMCQEditorQuestion($(e.currentTarget), modal));
}

/**
 * @NEW 2026-08-03: MCQ Editor - Render questions in the editor
 */
renderMCQEditorQuestions(questions) {
    if (!questions.length) {
        return '<p style="text-align:center;color:#999;padding:20px;">No questions found. Click "Add Question" to create one.</p>';
    }

    let html = '<div class="mcqvs-mcq-questions-list">';
    questions.forEach((q, index) => {
        const options = Array.isArray(q.options) ? q.options : ['', '', '', ''];
        const correct = q.correct !== undefined ? q.correct : 0;
        const qId = q.id || `q_${index}`;

        html += `
            <div class="mcqvs-mcq-question-item" data-index="${index}" data-qid="${qId}" style="border:1px solid #ddd;border-radius:6px;padding:15px;margin-bottom:15px;background:#fafafa;position:relative;">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
                    <strong>Question ${index + 1}</strong>
                    <button type="button" class="mcqvs-mcq-remove-question button button-small" style="color:#d9534f;">🗑 Remove</button>
                </div>
                <div style="margin-bottom:10px;">
                    <label style="display:block;font-weight:600;margin-bottom:4px;">Question Text</label>
                    <textarea class="mcqvs-mcq-question-text" style="width:100%;min-height:60px;padding:8px;border:1px solid #ccc;border-radius:4px;font-family:inherit;" placeholder="Enter question...">${q.question || ''}</textarea>
                </div>
                <div style="margin-bottom:10px;">
                    <label style="display:block;font-weight:600;margin-bottom:4px;">Options (exactly 4 required)</label>
                    <div class="mcqvs-mcq-options" style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
                        ${options.map((opt, optIndex) => `
                            <div style="display:flex;align-items:center;gap:8px;">
                                <input type="radio" name="correct_${qId}" class="mcqvs-mcq-correct-radio" value="${optIndex}" ${optIndex === correct ? 'checked' : ''} style="flex-shrink:0;">
                                <input type="text" class="mcqvs-mcq-option" value="${opt || ''}" placeholder="Option ${optIndex + 1}" style="flex:1;padding:8px;border:1px solid #ccc;border-radius:4px;">
                            </div>
                        `).join('')}
                    </div>
                    <p class="description" style="margin:4px 0 0;font-size:11px;color:#666;">Select the correct answer using the radio button.</p>
                </div>
            </div>
        `;
    });
    html += '</div>';
    html += '<div style="text-align:center;margin-top:15px;"><button type="button" class="mcqvs-mcq-add-question button button-secondary">➕ Add Question</button></div>';
    return html;
}

/**
 * @NEW 2026-08-03: MCQ Editor - Add a new question row
 */
addMCQEditorQuestion(modal) {
    const list = modal.find('.mcqvs-mcq-questions-list');
    const index = list.find('.mcqvs-mcq-question-item').length;
    const qId = `q_new_${index}_${Date.now()}`;

    const html = `
        <div class="mcqvs-mcq-question-item" data-index="${index}" data-qid="${qId}" style="border:1px solid #ddd;border-radius:6px;padding:15px;margin-bottom:15px;background:#fafafa;position:relative;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
                <strong>Question ${index + 1}</strong>
                <button type="button" class="mcqvs-mcq-remove-question button button-small" style="color:#d9534f;">🗑 Remove</button>
            </div>
            <div style="margin-bottom:10px;">
                <label style="display:block;font-weight:600;margin-bottom:4px;">Question Text</label>
                <textarea class="mcqvs-mcq-question-text" style="width:100%;min-height:60px;padding:8px;border:1px solid #ccc;border-radius:4px;font-family:inherit;" placeholder="Enter question..."></textarea>
            </div>
            <div style="margin-bottom:10px;">
                <label style="display:block;font-weight:600;margin-bottom:4px;">Options (exactly 4 required)</label>
                <div class="mcqvs-mcq-options" style="display:grid;grid-template-columns:1fr 1fr;gap:8px;">
                    <div style="display:flex;align-items:center;gap:8px;">
                        <input type="radio" name="correct_${qId}" class="mcqvs-mcq-correct-radio" value="0" checked style="flex-shrink:0;">
                        <input type="text" class="mcqvs-mcq-option" value="" placeholder="Option 1" style="flex:1;padding:8px;border:1px solid #ccc;border-radius:4px;">
                    </div>
                    <div style="display:flex;align-items:center;gap:8px;">
                        <input type="radio" name="correct_${qId}" class="mcqvs-mcq-correct-radio" value="1" style="flex-shrink:0;">
                        <input type="text" class="mcqvs-mcq-option" value="" placeholder="Option 2" style="flex:1;padding:8px;border:1px solid #ccc;border-radius:4px;">
                    </div>
                    <div style="display:flex;align-items:center;gap:8px;">
                        <input type="radio" name="correct_${qId}" class="mcqvs-mcq-correct-radio" value="2" style="flex-shrink:0;">
                        <input type="text" class="mcqvs-mcq-option" value="" placeholder="Option 3" style="flex:1;padding:8px;border:1px solid #ccc;border-radius:4px;">
                    </div>
                    <div style="display:flex;align-items:center;gap:8px;">
                        <input type="radio" name="correct_${qId}" class="mcqvs-mcq-correct-radio" value="3" style="flex-shrink:0;">
                        <input type="text" class="mcqvs-mcq-option" value="" placeholder="Option 4" style="flex:1;padding:8px;border:1px solid #ccc;border-radius:4px;">
                    </div>
                </div>
                <p class="description" style="margin:4px 0 0;font-size:11px;color:#666;">Select the correct answer using the radio button.</p>
            </div>
        </div>
    `;

    list.append(html);
    // Re-index question numbers
    this.reindexMCQQuestions(modal);
}

/**
 * @NEW 2026-08-03: MCQ Editor - Remove a question row
 */
removeMCQEditorQuestion(btn, modal) {
    const item = btn.closest('.mcqvs-mcq-question-item');
    if (modal.find('.mcqvs-mcq-question-item').length <= 1) {
        alert('At least one question is required.');
        return;
    }
    item.remove();
    this.reindexMCQQuestions(modal);
}

/**
 * @NEW 2026-08-03: MCQ Editor - Re-index question numbers after add/remove
 */
reindexMCQQuestions(modal) {
    modal.find('.mcqvs-mcq-question-item').each(function (index) {
        $(this).find('strong').first().text(`Question ${index + 1}`);
        $(this).attr('data-index', index);
    });
}

/**
 * @NEW 2026-08-03: MCQ Editor - Save changes to job questions
 */
async saveMCQEditorChanges(jobId, modal) {
    const btn = modal.find('#mcqvs-mcq-editor-save');
    const originalText = btn.text();
    btn.prop('disabled', true).text('Saving...');

    const questions = [];
    let hasErrors = false;

    modal.find('.mcqvs-mcq-question-item').each(function () {
        const questionText = $(this).find('.mcqvs-mcq-question-text').val().trim();
        const options = [];
        $(this).find('.mcqvs-mcq-option').each(function () {
            options.push($(this).val().trim());
        });
        const correct = parseInt($(this).find('.mcqvs-mcq-correct-radio:checked').val(), 10);
        const qId = $(this).data('qid');

        // Validation
        if (!questionText) {
            alert('Question text is required for all questions.');
            hasErrors = true;
            return false; // break each
        }
        if (options.length !== 4) {
            alert('Each question must have exactly 4 options.');
            hasErrors = true;
            return false;
        }
        if (options.some(opt => opt === '')) {
            alert('All options must be filled.');
            hasErrors = true;
            return false;
        }
        if (isNaN(correct) || correct < 0 || correct > 3) {
            alert('Please select a correct answer for each question.');
            hasErrors = true;
            return false;
        }

        questions.push({
            id: qId,
            question: questionText,
            options: options,
            correct: correct,
            background: 'gradient'
        });
    });

    if (hasErrors) {
        btn.prop('disabled', false).text(originalText);
        return;
    }

    if (questions.length === 0) {
        alert('At least one question is required.');
        btn.prop('disabled', false).text(originalText);
        return;
    }

    try {
        const res = await this.ajaxPost('mcqvs_update_job_questions', {
            job_id: jobId,
            questions: JSON.stringify(questions)
        });

        if (res.success) {
            alert(`✅ ${res.data.message} (${res.data.count} questions)`);
            modal.remove();
            this.loadQueue();
        } else {
            alert('Failed to save: ' + this.getErrorMessage(res));
        }
    } catch (e) {
        console.error('Save failed', e);
        alert('Save failed. Check console.');
    } finally {
        btn.prop('disabled', false).text(originalText);
    }
}

}

    $(document).ready(function () {
        window.MCQVS_ContentPlanner = new ContentPlanner();
    });

})(jQuery);
