<?php
namespace AiSocialCollage\Contracts;

if ( ! defined( 'ABSPATH' ) ) exit;

interface ImageGeneratorInterface {
    /**
     * Executes the image generation process.
     * 
     * @param array $job_data Contains headline, hook, image_url, etc.
     * @return int|\WP_Error Returns the attachment ID of the generated image.
     */
    public function generate( array $job_data );
}