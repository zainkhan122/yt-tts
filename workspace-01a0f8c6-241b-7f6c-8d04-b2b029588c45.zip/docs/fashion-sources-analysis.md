# One Collection = One Draft Post
## Source & automation analysis for Pakistani multi-brand fashion stores

**Prepared for:** your fashion/dresses blog workflow
**Goal:** auto-generate WordPress **draft posts where one post = one full designer collection** (all or most dresses inside), which you then rewrite by hand — *not* one post per single dress.

Everything below was **tested live** (endpoints actually queried, platforms actually fingerprinted) on 28 Aug 2026.

---

## 1. Why WordPress Automatic currently gives you one dress per run

WordPress Automatic's mental model is: **one "item" → one post**. If your campaign points at something whose items are individual dresses (a product feed, a category page loop over product cards), you will always get one dress per post. That's the bug in the setup, not the plugin.

The fix is to point campaigns at things whose items are **collections**, or to grab **all images of a collection page into one post's gallery**. WP Automatic *can* do both — its official docs list the option **"Try to fetch all images: … grab all product images and add them as a gallery"**, and scraper campaigns can loop links on an index page, visit each, and extract from the target page. So the real question is: **which site structures its data so that "one collection with N dresses" is a single, machine-readable object?** That's what I analyzed.

---

## 2. Master table — all sites analyzed

| # | Site | Multi-brand? | Platform | How a "collection" exists in their data | Public data access (tested) | Fit for 1-collection-per-post |
|---|------|--------------|----------|------------------------------------------|------------------------------|-------------------------------|
| 1 | **thefashionstation.in** (The Fashion Station, India — sells Pakistani designers) | ✅ 500+ brands (Saira Shakira, Charizma, Afrozeh, Zara Shahjahan, Sana Safinaz…) | **WordPress / WooCommerce** | **A product category = a named collection** ("Bloom Lawn 2026 by Saira Shakira" = 16 dresses, "Charizma Vasal Vol 1 2026" = 11) | ✅ Public WooCommerce **Store API** + per-category **RSS feeds** | ★★★★★ **best** |
| 2 | **sanaullastore.com** (Sanaulla, PK) | ✅ ~200+ brands | **Shopify** | Shopify collection per brand/line (`/collections/afrozeh` = 59 dresses); finer "volume" lines encoded in product title prefixes & tags (e.g. `RA25AC`, `AF26USW`) | ✅ `/collections/{handle}/products.json?limit=250` public; `/collections` index lists **466 collections** | ★★★★☆ |
| 3 | **go.sanaullastore.com** (Sanaulla International, USD) | ✅ same catalog | **Shopify** | same as above | ✅ products.json public | ★★★☆☆ (prices in USD) |
| 4 | **stringnthread.com** (USA) | ✅ PK multi-brand | **Shopify** | same Shopify model | ✅ products.json | ★★★☆☆ |
| 5 | **houseofhuda.com** (USA) | ✅ PK multi-brand | **Shopify** | same | ✅ products.json | ★★★☆☆ |
| 6 | **laam.com** (Laam, PK/US) | ✅ 1000+ brands | **Custom Nuxt (Vue SSR)** | **"Drops" = exactly the seasonal designer collections** you described (`/drops/maria-b--the-evening-tea-affair-unstitched-chiffon26`) | ⚠️ No public JSON API. Sitemap indexes exist (`/drops-sitemap.xml`); product data is inside the SSR payload (escaped JSON), more items load via internal API on scroll | ★★★☆☆ (needs rendered scraping) |
| 7 | **thefabricstore.pk** (The Fabric Store, PK) | ✅ | **Shopify** | ⚠️ Product = one suit; collections page is mostly discount/campaign groupings; brand lines only as tags (`MOONSOON`, `Summer26`) | ✅ products.json public | ★★☆☆☆ |
| 8 | **fashionnaari.com** (India) | ✅ PK + Indian | **Shopify** | per-dress products | ✅ products.json | ★★☆☆☆ |
| 9 | **shopperspk.com** (PK) | ✅ but general lifestyle store | **WordPress / WooCommerce** | categories | ✅ Store API public | ★★☆☆☆ (not fashion-focused) |
| 10 | **786shop.com** (USA) | ✅ PK multi-brand | custom PHP | category pages | ❌ no JSON | ★☆☆☆☆ |
| 11 | **affordable.pk** (PK) | ✅ multi-vendor | custom | vendor listings | ❌ | ★☆☆☆☆ |
| 12 | **ishopping.pk** (PK) | ✅ marketplace | WordPress (hardened) | — | ❌ `/wp-json/` returns 403 | ★☆☆☆☆ |
| 13 | **goto.com.pk** (PK) | ✅ marketplace | blocked / none detected | — | ❌ | ☆ |
| 14 | **houseoffaiza.com** (UK) | — | **domain parked / dead** | — | — | ✗ (skip) |
| 15 | **daraz.pk** | ✅ giant marketplace | custom, anti-bot | — | ❌ (needs paid Apify Daraz actors, messy data) | ★☆☆☆☆ |

---

## 3. Deep dive on the four that matter

### 🥇 The Fashion Station — `thefashionstation.in`
**The only site found whose category tree literally *is* a list of designer collections**, with a public API on a WordPress stack.

Verified live:

```
# List of collections (= WooCommerce product categories), with dress counts
https://www.thefashionstation.in/wp-json/wc/store/v1/products/categories?per_page=100
→ "Afrozeh Brides Collection 2026" (8), "Bloom Lawn 2026 by Saira Shakira" (16),
  "Charizma Vasal Vol 1 2026" (11), "Alkaram 2026 Collection" (127), …

# All dresses of one collection, one call, with 5–6 images per dress + prices
https://www.thefashionstation.in/wp-json/wc/store/v1/products?per_page=100&category=bloom-lawn-2026-by-saira-shakira

# Human collection page (one page = whole collection)
https://www.thefashionstation.in/product-category/bloom-lawn-2026-by-saira-shakira/

# Bonus: per-collection RSS feed (8 items for the Afrozeh collection above)
https://www.thefashionstation.in/product-category/afrozeh-brides-collection-2026/feed/
```

- One API call → one collection → every dress with name, price, permalink, and 5–6 images each. 
- Because it's WooCommerce, the grouping you want is a first-class object; no scraping, no rendering, nothing breaks when the theme changes.
- Theme is Flatsome: product cards are `.product-small.box`, titles `.name.product-title` (useful for WP Automatic selectors).
- ⚠️ Caveats: Indian store — prices are INR and it ships from India, but the *brands and collections are the same Pakistani designers* you write about (Saira Shakira, Charizma, Afrozeh, Zara Shahjahan, Sana Safinaz, Mushq, Nureh…). For content purposes it's exactly your niche; for price display, convert or omit.

### 🥈 Sanaulla Store — `sanaullastore.com` (+ `go.sanaullastore.com`)
Shopify, so every collection page has a JSON twin:

```
# Index of ALL collections (466 links, cards are <a class="collection-item">)
https://sanaullastore.com/collections

# One brand collection = 59 dresses in one JSON call
https://sanaullastore.com/collections/afrozeh/products.json?limit=250

# Every product: title, 2–6 photos, price, tags (tags carry collection codes!)
# e.g. tags: ["new_arrivals","RN26URE","Roheenaz","trending"]
```

- Each product = one dress (unlike a "collection product" model), 2–6 images each — clean per-dress data.
- The truly granular seasonal lines ("Shehnai by Afrozeh AF26USW") are *not* separate collection pages; they're a shared **title prefix + tag code** across products. So for volume-level posts you group by tag/prefix — trivial in a script (the plugin I made does it), not possible in WP Automatic's UI.
- Sanaulla is a Pakistani store with PKR prices — great for a PK blog.

### 🥉 Laam — `laam.com`
- `laam.com/drops-sitemap.xml` → e.g. `imrozia--serene-hania-luxury-lawn26`, `maria-b--the-evening-tea-affair-unstitched-chiffon26` — **the "click a cover, see all dresses" pattern you described, exactly.**
- But it's a Nuxt JS app: no public JSON API; the drop page's HTML contains the first ~15–20 products in an escaped `window.__NUXT__` payload, the rest load on scroll via an internal API. My API guesses returned 500/no-route.
- Automatable only with a browser renderer (Apify Web Scraper with infinite scroll, or a custom script that reverse-engineers their internal catalog API). Medium-high effort, best done once and reused.

### The Fabric Store — `thefabricstore.pk`
- Shopify, products.json works — but products are single suits and the `/collections` page is discount campaigns (`20-discount`, `eid-collection-1`…), not designer lines. Brand lines survive only as product tags. You *can* group by tag with a script, but it's the weakest structure of the Shopify four.

---

## 4. Verdict — best-fit website(s)

| If you want… | Best source |
|---|---|
| **One collection per post, cleanest structure, public API, WordPress-native** | **The Fashion Station** ✅ |
| **Best Pakistani store + same capability** | **Sanaulla** (Shopify JSON per collection) |
| Editorial "drops" content at any cost | Laam (Apify browser scraping) |

**Do you need a custom plugin? Not necessarily.** There are three workable routes; pick by how much polish you want:

| Route | Setup effort | Quality of drafts | Detects NEW collections automatically | Cost |
|---|---|---|---|---|
| **A. WP Automatic only** (recipes below) | low | gallery of all dress images + title; no per-dress prices | partly (new links on index pages) | you own it |
| **B. Apify → WP REST** | medium | full structured data | ✅ | ~$5–15/mo |
| **C. Custom plugin** (I built it: `collection-post-generator.php`) | medium-low | **best**: per-dress blocks w/ names, prices, galleries, "N new designs" marker | ✅ | free |

---

## 5. Route A — make WordPress Automatic do it (no new tools)

### Recipe A1 — Sanaulla: one draft per collection, automatically discovering collections
1. New campaign → type **Scraper**.
2. URL: `https://sanaullastore.com/collections`
3. Item selector: `a.collection-item` (verified live) — each item is one collection link.
4. Enable **visiting the item link** and extracting title/content from the target page (collection title from `h1`, content from the product grid).
5. In campaign **Options → Images**: find images in **the original page** and tick the **fetch-all-images → add as gallery** option (docs wording: *"Try to fetch all images … add them as a gallery"*). Add exclusions for `logo`, `banner`, `icon` so only dress photos land in the gallery.
6. Post status: **Draft**. Search/replace or the content template can add your intro paragraph.
7. Result: **1 draft per collection; gallery = every dress photo on that collection page.**

Known limits: first page only on big collections (~24 dresses — usually enough); gallery contains *all* product images including alternate angles; no per-dress prices.

### Recipe A2 — The Fashion Station: one draft per chosen collection
1. Campaign type **Scraper**, URL: `https://www.thefashionstation.in/product-category/bloom-lawn-2026-by-saira-shakira/`
2. Single-page mode (no item loop): title from `h1`, content from `ul.products` (cards `.product-small.box`).
3. Same all-images-gallery option → draft contains the whole collection's photos.
4. Practical pattern: keep a small text file of category URLs you care about and clone the campaign per collection (their collection names are in the categories API, so picking them is 2 minutes).
5. ⚠️ Do **not** point WP Automatic at their per-category RSS (`/product-category/{slug}/feed/`) — that feed's items are single dresses; that would recreate your current one-dress-per-post problem.

### Recipe A3 — same logic on the other Shopify stores
`stringnthread.com`, `houseofhuda.com`, `go.sanaullastore.com`: find their collection index (`/collections`), same as A1.

### Why your current campaign failed
It was pointed at dress-level items (a feed or product card loop) → 1 item = 1 post = 1 dress. Point it at collection-level items + gallery grabbing, and the plugin's own model works for you.

---

## 6. Route B — Apify (best for Laam + bulk work)

| Need | Actor (verified on Apify store) | Notes |
|---|---|---|
| Shopify stores (Sanaulla, String & Thread, House of Huda, Fabric Store) | **`webdatalabs/shopify-product-scraper`** or `scraperx/shopify-store-scraper` | Uses the public `products.json` — no browser needed, cheap. Output includes all image URLs per product. |
| WooCommerce stores (Fashion Station, ShoppersPk) | **`scrapeflow/woocommerce-scraper`** or `trovevault/woocommerce-products-scraper` | Hits the public Store API; supports `category` filter and variations. |
| Laam (JS site) | `apify/web-scraper` with a small PageFunction (infinite scroll over a drop URL) | I can write the PageFunction for you — say the word. |
| Pushing drafts into WordPress | No special actor needed: **Apify webhook → your site's `POST /wp-json/wp/v2/posts`** with an Application Password (`Users → Profile → Application Passwords`), body `{"title": …, "content": …, "status": "draft"}` | One HTTP call; or glue with Make.com/n8n. |

Note: `jupri/wordpress` and similar "WordPress scrapers" on Apify are for *scraping other WP sites* (posts, wp-json), not publishing — don't confuse them.

---

## 7. Route C — the custom plugin (included in this workspace)

**`collection-post-generator.php`** — a drop-in WordPress must-use plugin I wrote for you:

- Add any number of **sources**: Shopify collection URLs (`/collections/{handle}/products.json`) **and** Fashion Station categories (Woo Store API) — both formats supported.
- Runs every 6 hours via WP-Cron; also trigger manually as a logged-in admin via `/?cpg_run=1` (or `wp eval 'cpg_run();'`).
- Creates **one draft per collection**: per-dress blocks (name, price, photo gallery, link to product), collection intro line, tags.
- First run creates the draft; later runs **append "🆕 N new designs added {date}"** to the same draft when the store adds dresses (dedupe state stored in options).
- Featured image = first dress photo; optional full media-library import (`CPG_SIDELOAD_ALL`) off by default to keep runs fast (hotlinking CDN images in drafts; WordPress will import them when you rewrite anyway, or enable the flag).
- Everything sanitized; only ever creates/updates **drafts**.

Install: upload to `wp-content/mu-plugins/` and edit the `CPG_SOURCES` array at the top. Both example sources are pre-filled and verified working (Sanaulla Afrozeh + Fashion Station Saira Shakira Bloom Lawn 2026).

**My honest recommendation:** start with Recipe A1/A2 tonight (zero new tools — you already own WP Automatic). When you want per-dress prices, "new arrivals" tracking and clean galleries, switch that source to the plugin. Use Apify only if you decide you must have Laam's drops.

---

## 8. Quick reference — every verified endpoint

```bash
# Shopify collection → all dresses, one call (works on sanaullastore.com,
# go.sanaullastore.com, stringnthread.com, houseofhuda.com, thefabricstore.pk)
https://{store}/collections/{handle}/products.json?limit=250

# Sanaulla index of all 466 collections (cards: a.collection-item)
https://sanaullastore.com/collections

# Fashion Station: list of collections w/ counts
https://www.thefashionstation.in/wp-json/wc/store/v1/products/categories?per_page=100
# Fashion Station: dresses of one collection
https://www.thefashionstation.in/wp-json/wc/store/v1/products?per_page=100&category={slug}
# Fashion Station: per-collection RSS (items = dresses; avoid in WP Automatic)
https://www.thefashionstation.in/product-category/{slug}/feed/

# Laam: index of designer drops / collections / brands
https://laam.com/drops-sitemap.xml
https://laam.com/collections-sitemap.xml
https://laam.com/brands-sitemap.xml
```

## 9. Housekeeping notes

- **Rights/attribution:** photos and descriptions belong to the brands/stores. Drafts-for-rewriting with a source link is the right instinct; keep attribution, don't republish catalogs verbatim at scale.
- **ToS:** Shopify JSON endpoints are public storefront data used widely by affiliate tools; still, throttle politely (the plugin does 6-hour intervals). Laam's internal API would be grey-area — prefer their sitemap + rendered pages if you go there.
- **Prices:** Fashion Station = INR; Sanaulla PK site = PKR; Laam shows USD/geo prices — normalize before publishing for a PK audience.
