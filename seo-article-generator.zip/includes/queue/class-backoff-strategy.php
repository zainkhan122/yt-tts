<?php

/**
 * Adaptive Backoff Strategy
 *
 * @package SEO_Article_Generator
 * @MODIFIED 2026-04-23: Intelligent Error System — uses API_Error_Info + Quota_State for adaptive delays
 */

namespace SEO_Article_Generator\Queue;

use SEO_Article_Generator\AI\API_Error_Info;
use SEO_Article_Generator\AI\Quota_State_Manager;

if (! defined('ABSPATH')) {
    exit;
}

class Backoff_Strategy
{
    private static $fallback_schedule = array(
        1 => 300,
        2 => 900,
        3 => 3600,
        4 => 21600,
    );

    public static function delay_for_attempt($attempt, ?API_Error_Info $error_info = null, string $provider = '', string $model = '')
    {
        $attempt = (int) $attempt;

        if ($error_info !== null && $error_info->is_quota_error()) {
            return self::compute_quota_delay($attempt, $error_info, $provider, $model);
        }

        if ($error_info !== null && $error_info->get_error_type() === API_Error_Info::TYPE_SERVER_OVERLOADED) {
            $api_delay = $error_info->get_retry_delay_seconds();
            $exponential = self::exponential_base($attempt);
            return max($api_delay, $exponential);
        }

        if ($error_info !== null && $error_info->get_retry_delay_seconds() > 0) {
            return max($error_info->get_retry_delay_seconds(), self::exponential_base($attempt));
        }

        return self::exponential_base($attempt);
    }

    private static function compute_quota_delay(int $attempt, API_Error_Info $info, string $provider, string $model): int
    {
        $now = \SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts();
        $reset_ts = $info->get_reset_at_ts();

        if ($info->is_daily_quota() && $reset_ts > $now) {
            $delay = $reset_ts - $now + 30;
            return min($delay, 86400);
        }

        if ($info->get_error_type() === API_Error_Info::TYPE_QUOTA_RPM) {
            $api_delay = $info->get_retry_delay_seconds();
            $recommended = 0;
            if ($provider !== '') {
                $recommended = Quota_State_Manager::get_recommended_interval($provider, $model);
            }
            return max($api_delay, $recommended, 30);
        }

        if ($info->get_error_type() === API_Error_Info::TYPE_QUOTA_TPM) {
            $api_delay = $info->get_retry_delay_seconds();
            return max($api_delay, 60);
        }

        $api_delay = $info->get_retry_delay_seconds();
        if ($api_delay > 0) {
            return $api_delay;
        }

        $safe_slot = 0;
        if ($provider !== '') {
            $safe_slot = Quota_State_Manager::next_safe_slot_ts($provider, $model);
        }
        if ($safe_slot > $now) {
            return $safe_slot - $now;
        }

        return self::exponential_base($attempt);
    }

private static function exponential_base(int $attempt): int
    {
        return isset(self::$fallback_schedule[$attempt])
            ? self::$fallback_schedule[$attempt]
            : 86400;
    }
}
