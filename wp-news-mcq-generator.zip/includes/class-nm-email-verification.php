<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Email Verification System
 * Handles user registration activation via email
 *
 * @package WP_News_MCQ_Generator
 * @version 1.0
 */

class NM_Email_Verification {

	private static $instance = null;

	public static function init() {
		if ( self::$instance === null ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		// Handle verification link clicks
		add_action( 'template_redirect', array( $this, 'handle_verification_link' ), 5 );

		// AJAX verification
		add_action( 'wp_ajax_nm_verify_email', array( $this, 'verify_email_ajax' ) );
		add_action( 'wp_ajax_nopriv_nm_verify_email', array( $this, 'verify_email_ajax' ) );
	}

	/**
	 * Generate verification token
	 */
	public static function generate_token( $user_id, $email ) {
		$hash = wp_hash( $user_id . $email . time(), 'auth' );
		update_user_meta( $user_id, 'nm_verification_token', $hash );
		update_user_meta( $user_id, 'nm_verification_sent', current_time( 'mysql' ) );
		return $hash;
	}

	/**
	 * Send verification email
	 */
	public static function send_verification_email( $user_id, $email, $username ) {
		$token      = self::generate_token( $user_id, $email );
		$verify_url = home_url( '/?nm_action=verify_email&token=' . $token . '&user=' . $user_id );
		$site_name  = get_bloginfo( 'name' );

		$subject = sprintf( 'Verify Your Email - %s', $site_name );

		$message = '
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; }
                .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }
                .content { background: #fff; padding: 30px; border: 1px solid #e0e0e0; border-radius: 0 0 8px 8px; }
                .button { display: inline-block; padding: 12px 30px; background: #667eea; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0; }
                .footer { background: #f8f9fa; padding: 20px; text-align: center; font-size: 12px; color: #888; margin-top: 20px; border-radius: 8px; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>Verify Your Email</h1>
                    <p>Complete your registration</p>
                </div>
                
                <div class="content">
                    <p>Hi ' . esc_html( $username ) . ',</p>
                    
                    <p>Thank you for registering at <strong>' . $site_name . '</strong>!</p>
                    
                    <p>To complete your registration and access your account, please verify your email address by clicking the button below:</p>
                    
                    <center>
                        <a href="' . esc_url( $verify_url ) . '" class="button">Verify Email Address</a>
                    </center>
                    
                    <p style="color: #888; font-size: 12px;">Or copy and paste this link in your browser:<br>
                    <a href="' . esc_url( $verify_url ) . '">' . esc_url( $verify_url ) . '</a></p>
                    
                    <hr style="border: none; border-top: 1px solid #e0e0e0; margin: 30px 0;">
                    
                    <p style="color: #888; font-size: 12px;">
                        <strong>This link will expire in 24 hours.</strong><br>
                        If you did not register on ' . $site_name . ', please ignore this email.
                    </p>
                </div>
                
                <div class="footer">
                    <p>&copy; ' . $site_name . '. All rights reserved.</p>
                </div>
            </div>
        </body>
        </html>
        ';

		$headers = array( 'Content-Type: text/html; charset=UTF-8' );

		return wp_mail( $email, $subject, $message, $headers );
	}

	/**
	 * Handle verification link from email
	 */
	public function handle_verification_link() {
		if ( ! isset( $_GET['nm_action'] ) || $_GET['nm_action'] !== 'verify_email' ) {
			return;
		}

		$token   = isset( $_GET['token'] ) ? sanitize_text_field( $_GET['token'] ) : '';
		$user_id = isset( $_GET['user'] ) ? intval( $_GET['user'] ) : 0;

		if ( empty( $token ) || empty( $user_id ) ) {
			$this->show_verification_page( 'error', 'Invalid verification link.' );
			return;
		}

		// Get user's stored token
		$stored_token = get_user_meta( $user_id, 'nm_verification_token', true );

		if ( empty( $stored_token ) || $stored_token !== $token ) {
			$this->show_verification_page( 'error', 'Verification link is invalid or expired.' );
			return;
		}

		// Check if token expired (24 hours)
		$sent_time = get_user_meta( $user_id, 'nm_verification_sent', true );
		if ( strtotime( $sent_time ) < strtotime( '-24 hours' ) ) {
			$this->show_verification_page( 'error', 'Verification link has expired. Please register again.' );
			return;
		}

		// Verify user
		$this->activate_user( $user_id );

		// Auto-login user
		wp_set_current_user( $user_id );
		wp_set_auth_cookie( $user_id );

		$this->show_verification_page( 'success', 'Email verified successfully! Redirecting to your dashboard...' );
	}

	/**
	 * Activate user account
	 */
	private function activate_user( $user_id ) {
		delete_user_meta( $user_id, 'nm_verification_token' );
		delete_user_meta( $user_id, 'nm_verification_sent' );
		update_user_meta( $user_id, 'nm_email_verified', 1 );
		update_user_meta( $user_id, 'nm_verified_date', current_time( 'mysql' ) );

	}

	/**
	 * Show verification page
	 */
	private function show_verification_page( $type, $message ) {
		?>
		<!DOCTYPE html>
		<html>
		<head>
			<meta charset="UTF-8">
			<meta name="viewport" content="width=device-width, initial-scale=1.0">
			<title>Email Verification</title>
			<style>
				body {
					font-family: Arial, sans-serif;
					background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
					min-height: 100vh;
					display: flex;
					align-items: center;
					justify-content: center;
					margin: 0;
					padding: 20px;
				}
				.container {
					background: white;
					padding: 40px;
					border-radius: 12px;
					box-shadow: 0 10px 40px rgba(0,0,0,0.2);
					max-width: 500px;
					text-align: center;
				}
				.success {
					color: #27ae60;
					font-size: 48px;
					margin-bottom: 20px;
				}
				.error {
					color: #e74c3c;
					font-size: 48px;
					margin-bottom: 20px;
				}
				h1 {
					margin: 20px 0;
					color: #333;
				}
				p {
					color: #666;
					line-height: 1.6;
					margin: 15px 0;
				}
				.button {
					display: inline-block;
					padding: 12px 30px;
					background: #667eea;
					color: white;
					text-decoration: none;
					border-radius: 5px;
					margin-top: 20px;
					transition: background 0.3s;
				}
				.button:hover {
					background: #764ba2;
				}
				.countdown {
					font-size: 14px;
					color: #888;
					margin-top: 20px;
				}
			</style>
		</head>
		<body>
			<div class="container">
				<?php if ( $type === 'success' ) : ?>
					<div class="success">✓</div>
					<h1>Email Verified!</h1>
					<p><?php echo esc_html( $message ); ?></p>
					<p class="countdown" id="countdown">Redirecting in <span id="timer">5</span> seconds...</p>
				<?php else : ?>
					<div class="error">✗</div>
					<h1>Verification Failed</h1>
					<p><?php echo esc_html( $message ); ?></p>
					<a href="<?php echo home_url( '/mcq-register/' ); ?>" class="button">Try Again</a>
				<?php endif; ?>
			</div>
			
			<?php if ( $type === 'success' ) : ?>
			<script>
				var countdown = 5;
				var timer = setInterval(function() {
					countdown--;
					document.getElementById('timer').textContent = countdown;
					if (countdown <= 0) {
						clearInterval(timer);
						window.location.href = '<?php echo esc_url( home_url( '/mcq-dashboard/' ) ); ?>';
					}
				}, 1000);
			</script>
			<?php endif; ?>
		</body>
		</html>
		<?php
		exit;
	}

	/**
	 * AJAX verification
	 */
	public function verify_email_ajax() {
		check_ajax_referer( 'nm_auth_nonce', 'nonce' );

		$token   = sanitize_text_field( $_POST['token'] );
		$user_id = intval( $_POST['user_id'] );

		// Validate token
		$stored_token = get_user_meta( $user_id, 'nm_verification_token', true );

		if ( empty( $stored_token ) || $stored_token !== $token ) {
			wp_send_json_error( array( 'message' => 'Invalid verification token' ) );
		}

		// Activate user
		$this->activate_user( $user_id );

		wp_send_json_success(
			array(
				'message'  => 'Email verified successfully!',
				'redirect' => home_url( '/mcq-dashboard/' ),
			)
		);
	}
}
