<?php

/**
 * Image Suggester Service
 *
 * @package DIT_TrendStudio
 * @MODIFIED 2025-12-14 - New service for free stock image suggestions
 */

namespace DIT\TrendStudio\Services;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Fetches image suggestions from Unsplash and Pexels APIs
 * 
 * Uses Unsplash as primary source, Pexels as fallback.
 * Both are free with proper attribution.
 */
class Image_Suggester
{
    /**
     * Unsplash API endpoint
     */
    private const UNSPLASH_API = 'https://api.unsplash.com/search/photos';

    /**
     * Pexels API endpoint
     */
    private const PEXELS_API = 'https://api.pexels.com/v1/search';

    /**
     * Unsplash API key
     * @var string
     */
    private string $unsplash_key;

    /**
     * Pexels API key
     * @var string
     */
    private string $pexels_key;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->unsplash_key = get_option('dit_ts_unsplash_api_key', '');
        $this->pexels_key = get_option('dit_ts_pexels_api_key', '');
    }

    /**
     * Search for images matching a query
     *
     * @param string $query Search query
     * @param int $per_page Number of results (max 10)
     * @return array Array of image suggestions
     */
    public function search(string $query, int $per_page = 3): array
    {
        $query = trim($query);
        if (empty($query)) {
            return [];
        }

        $per_page = min(max(1, $per_page), 10);

        // Try Unsplash first
        if (!empty($this->unsplash_key)) {
            $results = $this->search_unsplash($query, $per_page);
            if (!empty($results)) {
                return $results;
            }
        }

        // Fallback to Pexels
        if (!empty($this->pexels_key)) {
            $results = $this->search_pexels($query, $per_page);
            if (!empty($results)) {
                return $results;
            }
        }

        return [];
    }

    /**
     * Fetch suggestions for all sections in an article
     *
     * @param array $sections Array of sections with 'suggested_image_search' field
     * @param int $per_section Images per section
     * @return array Sections with 'image_suggestions' populated
     */
    public function fetch_for_sections(array $sections, int $per_section = 3): array
    {
        foreach ($sections as $i => $section) {
            $query = $section['suggested_image_search'] ?? '';
            $sections[$i]['image_suggestions'] = $this->search($query, $per_section);

            // Preserve existing selection if any
            if (!isset($sections[$i]['selected_image'])) {
                $sections[$i]['selected_image'] = null;
            }
        }

        return $sections;
    }

    /**
     * Search Unsplash API
     *
     * @param string $query Search query
     * @param int $per_page Results count
     * @return array Normalized image data
     */
    private function search_unsplash(string $query, int $per_page): array
    {
        $url = add_query_arg([
            'query' => $query,
            'per_page' => $per_page,
            'orientation' => 'landscape',
        ], self::UNSPLASH_API);

        $response = wp_remote_get($url, [
            'headers' => [
                'Authorization' => 'Client-ID ' . $this->unsplash_key,
            ],
            'timeout' => 15,
        ]);

        if (is_wp_error($response)) {
            return [];
        }

        $code = wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            return [];
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (empty($body['results'])) {
            return [];
        }

        $images = [];
        foreach ($body['results'] as $photo) {
            $images[] = [
                'id' => $photo['id'] ?? '',
                'thumb' => $photo['urls']['small'] ?? '',
                'regular' => $photo['urls']['regular'] ?? '',
                'full' => $photo['urls']['full'] ?? '',
                'alt' => $photo['alt_description'] ?? $photo['description'] ?? '',
                'photographer' => $photo['user']['name'] ?? 'Unknown',
                'photographer_url' => $photo['user']['links']['html'] ?? '',
                'source' => 'unsplash',
                'source_url' => $photo['links']['html'] ?? '',
                'attribution' => sprintf(
                    'Photo by %s on Unsplash',
                    $photo['user']['name'] ?? 'Unknown'
                ),
            ];
        }

        return $images;
    }

    /**
     * Search Pexels API
     *
     * @param string $query Search query
     * @param int $per_page Results count
     * @return array Normalized image data
     */
    private function search_pexels(string $query, int $per_page): array
    {
        $url = add_query_arg([
            'query' => $query,
            'per_page' => $per_page,
            'orientation' => 'landscape',
        ], self::PEXELS_API);

        $response = wp_remote_get($url, [
            'headers' => [
                'Authorization' => $this->pexels_key,
            ],
            'timeout' => 15,
        ]);

        if (is_wp_error($response)) {
            return [];
        }

        $code = wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            return [];
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (empty($body['photos'])) {
            return [];
        }

        $images = [];
        foreach ($body['photos'] as $photo) {
            $images[] = [
                'id' => (string) ($photo['id'] ?? ''),
                'thumb' => $photo['src']['small'] ?? '',
                'regular' => $photo['src']['medium'] ?? '',
                'full' => $photo['src']['large2x'] ?? $photo['src']['large'] ?? '',
                'alt' => $photo['alt'] ?? '',
                'photographer' => $photo['photographer'] ?? 'Unknown',
                'photographer_url' => $photo['photographer_url'] ?? '',
                'source' => 'pexels',
                'source_url' => $photo['url'] ?? '',
                'attribution' => sprintf(
                    'Photo by %s on Pexels',
                    $photo['photographer'] ?? 'Unknown'
                ),
            ];
        }

        return $images;
    }

    /**
     * Check if any API keys are configured
     *
     * @return bool True if at least one API is available
     */
    public function is_available(): bool
    {
        return !empty($this->unsplash_key) || !empty($this->pexels_key);
    }

    /**
     * Get availability status for UI display
     *
     * @return array Status of each API
     */
    public function get_status(): array
    {
        return [
            'unsplash' => !empty($this->unsplash_key),
            'pexels' => !empty($this->pexels_key),
            'available' => $this->is_available(),
        ];
    }
}
