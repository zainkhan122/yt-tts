<?php

/**
 * Content Scraper — Three-Tier Fallback Engine with Source-Aware Routing
 *
 * @package SEO_Article_Generator\Integration
 * @version 2026-03-02 (Complete Rewrite + Source Routing)
 *
 * @MODIFIED 2026-03-02 - WP Auto First, Native as Fallback (Preserve Structured Data)
 */

namespace SEO_Article_Generator\Integration;

if (! defined('ABSPATH')) {
    exit;
}

class WP_Automatic_Bridge
{

    /** Minimum clean-text characters to consider a scrape successful */
    const MIN_CONTENT_CHARS = 300;

    /** Tier 1: HTTP fetch timeout in seconds — hard cap, never blocks pipeline */
    const FETCH_TIMEOUT = 20;

    /** User agent sent with wp_remote_get requests */
    const USER_AGENT = 'Mozilla/5.0 (compatible; SoftwareBot/1.0; +https://softwareswave.com)';

    /** WP Automatic per-item campaign title prefix */
    const CAMPAIGN_PREFIX = 'SEO-Gen Bridge: ';

	// =========================================================================
	// PUBLIC API
	// =========================================================================

    /**
     * PRIMARY ENTRY POINT (Source-Aware + Priority Routing)
     *
     * @MODIFIED 2026-03-02 - Corrected priority: WP Automatic is Tier 1, Native is Tier 2.
     *
     * WHY WP AUTOMATIC IS TIER 1:
     *   Native fetches raw HTML → strips tags → structured data destroyed.
     *   WP Automatic with CSS selectors preserves download links/specs/tables.
     *
     * @param  string $url           Source article URL to scrape
     * @param  string $software_name Optional — passed for logging
     * @return array|false  ['content'=>string, 'image_url'=>string|null, 'image_id'=>int|null]
     */
    public static function scrape_url($url, $software_name = '')
    {
        if (empty($url) || ! \filter_var($url, FILTER_VALIDATE_URL)) {
            \error_log('[SEO-Gen Scraper] Invalid URL: ' . $url);
            return false;
        }

        // Resolve per-source scraper config (set by admin in Source Manager)
        $source_config = self::get_source_config_for_url($url);
        $scraper_type  = $source_config['scraper_type'] ?? 'auto';
        $campaign_id   = ! empty($source_config['campaign_id']) ? (int) $source_config['campaign_id'] : null;

        $camp_type_map = [
            'rss_feed'        => 'Feed',
            'multi_scraper'   => 'Multi',
            'article_scraper' => 'Article',
        ];

        switch ($scraper_type) {

            // ----------------------------------------------------------------
            // NATIVE ONLY — admin explicitly chose to skip WP Automatic.
            // ----------------------------------------------------------------
            case 'native':
                $result = self::tier1_native_fetch($url);
                \error_log(sprintf(
                    '[SEO-Gen Scraper] native-only for %s → %s',
                    $url,
                    $result ? \strlen(\strip_tags($result['content'])) . ' chars' : 'FAIL'
                ));
                return $result;

                // ----------------------------------------------------------------
                // WP AUTOMATIC TYPES — WP Auto is PRIMARY, native is the fallback.
                // ----------------------------------------------------------------
            case 'rss_feed':
            case 'multi_scraper':
            case 'article_scraper':
                $wp_type = $camp_type_map[$scraper_type] ?? 'Multi';

                if (self::is_wp_automatic_available()) {
                    $result = self::tier2_wp_automatic($url, $wp_type, $campaign_id);
                    if ($result && self::is_content_sufficient($result['content'])) {
                        \error_log('[SEO-Gen Scraper] WP Auto ' . $wp_type . ' SUCCESS (' . \strlen(\strip_tags($result['content'])) . ' chars): ' . $url);
                        return $result;
                    }
                    \error_log('[SEO-Gen Scraper] WP Auto ' . $wp_type . ' returned thin/no content for: ' . $url . '. Falling back to native.');
                } else {
                    \error_log('[SEO-Gen Scraper] WP Automatic not available for type ' . $scraper_type . '. Using native fallback.');
                }

                // Native fallback — better than nothing, but AI will have less context
                $native = self::tier1_native_fetch($url);
                if ($native) {
                    \error_log('[SEO-Gen Scraper] Native fallback: ' . \strlen(\strip_tags($native['content'])) . ' chars for: ' . $url);
                }
                return $native ?: false;

                // ----------------------------------------------------------------
                // AUTO (default) — WP Automatic first if available, native second.
                // ----------------------------------------------------------------
            default: // 'auto'
                if (self::is_wp_automatic_available()) {
                    // Use Multi as the default WP Auto type in auto mode.
                    $result = self::tier2_wp_automatic($url, 'Multi', null);
                    if ($result && self::is_content_sufficient($result['content'])) {
                        \error_log('[SEO-Gen Scraper] Auto→WP Auto SUCCESS (' . \strlen(\strip_tags($result['content'])) . ' chars): ' . $url);
                        return $result;
                    }
                    \error_log('[SEO-Gen Scraper] Auto→WP Auto thin. Falling back to native: ' . $url);
                }

                // Native fallback
                $native = self::tier1_native_fetch($url);
                if ($native && self::is_content_sufficient($native['content'])) {
                    \error_log('[SEO-Gen Scraper] Auto→native SUCCESS (' . \strlen(\strip_tags($native['content'])) . ' chars): ' . $url);
                    return $native;
                }

                // Return whatever native got (even if thin) — caller handles RSS Tier 3
                \error_log('[SEO-Gen Scraper] Auto→both tiers thin/failed for: ' . $url . '. Caller uses RSS fallback.');
                return $native ?: false;
        }
    }

    /**
     * Sideload a remote image into the WordPress media library.
     * Call this AFTER post creation — never during scraping to avoid blocking.
     *
     * @param  string $image_url  Remote URL of the image
     * @param  int    $post_id    Post to attach the attachment to (0 = unattached)
     * @return int|false  Attachment ID on success, false on failure
     */
    public static function sideload_image($image_url, $post_id = 0)
    {
        if (empty($image_url) || ! \filter_var($image_url, FILTER_VALIDATE_URL)) {
            return false;
        }

        global $wpdb;

        $existing_id = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT post_id FROM {$wpdb->postmeta}
                 WHERE meta_key = '_seo_gen_source_url'
                   AND meta_value = %s
                 LIMIT 1",
                $image_url
            )
        );
        if ($existing_id > 0) {
            if ($post_id > 0) {
                \set_post_thumbnail($post_id, $existing_id);
            }
            return $existing_id;
        }

        require_once \ABSPATH . 'wp-admin/includes/media.php';
        require_once \ABSPATH . 'wp-admin/includes/file.php';
        require_once \ABSPATH . 'wp-admin/includes/image.php';

        $attachment_id = \media_sideload_image($image_url, $post_id, null, 'id');

        if (\is_wp_error($attachment_id)) {
            \error_log('[SEO-Gen Scraper] Image sideload failed for ' . $image_url . ': ' . $attachment_id->get_error_message());
            return false;
        }

        $attachment_id = (int) $attachment_id;
        \update_post_meta($attachment_id, '_seo_gen_source_url', $image_url);

        return $attachment_id;
    }

	// =========================================================================
	// PUBLIC TEST WRAPPERS
	// Called by Bootstrap::ajax_test_source() to let admin test specific tiers
	// =========================================================================

    /**
     * @MODIFIED 2026-03-02 - Public wrappers for testing
     */
    public static function tier1_native_fetch_public($url)
    {
        return self::tier1_native_fetch($url);
    }

    public static function tier2_wp_automatic_public($url, $camp_type = 'Multi', $campaign_id = null)
    {
        return self::tier2_wp_automatic($url, $camp_type, $campaign_id);
    }

	// =========================================================================
	// TIER 2: NATIVE wp_remote_get() (Now effectively Tier 2 fallback)
	// =========================================================================

    /**
     * Fetch a URL via WordPress HTTP API with a hard 20-second timeout.
     *
     * @param  string $url
     * @return array|false  ['content'=>string, 'image_url'=>string|null, 'image_id'=>null]
     */
    private static function tier1_native_fetch($url)
    {
        $response = \wp_remote_get($url, [
            'timeout'     => self::FETCH_TIMEOUT,
            'user-agent'  => self::USER_AGENT,
            'sslverify'   => false,
            'redirection' => 5,
            'headers'     => [
                'Accept'          => 'text/html,application/xhtml+xml',
                'Accept-Language' => 'en-US,en;q=0.9',
                'Accept-Encoding' => 'gzip, deflate',
                'Cache-Control'   => 'no-cache',
            ],
        ]);

        if (\is_wp_error($response)) {
            \error_log('[SEO-Gen Scraper] wp_remote_get error for ' . $url . ': ' . $response->get_error_message());
            return false;
        }

        $http_code = \wp_remote_retrieve_response_code($response);
        if ($http_code < 200 || $http_code >= 400) {
            \error_log('[SEO-Gen Scraper] HTTP ' . $http_code . ' for: ' . $url);
            return false;
        }

        $html = \wp_remote_retrieve_body($response);
        if (empty($html)) {
            return false;
        }

        $clean_content = self::extract_main_content($html, $url);
        $image_url     = self::extract_first_image($html, $url);

        return [
            'content'   => $clean_content,
            'image_url' => $image_url,
            'image_id'  => null, // Sideloading is deferred
        ];
    }

	// =========================================================================
	// TIER 1: WP AUTOMATIC (Now effectively Tier 1 Primary)
	// =========================================================================

    /**
     * Scrape via WP Automatic using a per-URL campaign.
     *
     * @param  string   $url               Article URL to scrape
     * @param  string   $camp_type         WP Automatic camp_type value ('Feed','Multi','Article')
     * @param  int|null $reuse_campaign_id If set, reuse this existing campaign
     * @return array|false
     */
    private static function tier2_wp_automatic($url, $camp_type = 'Multi', $reuse_campaign_id = null)
    {
        global $wpdb;

        try {
            $use_dedicated = ($reuse_campaign_id !== null && $reuse_campaign_id > 0);

            if ($use_dedicated) {
                $campaign_id = (int) $reuse_campaign_id;
                \update_post_meta($campaign_id, 'camp_url', $url);
                \update_post_meta($campaign_id, 'camp_type', $camp_type); // ensure type matches source config

                // Clear WP Automatic history entry
                $history_table = $wpdb->prefix . 'automatic_camp_post';
                if ($wpdb->get_var("SHOW TABLES LIKE '{$history_table}'") === $history_table) {
                    $wpdb->query($wpdb->prepare(
                        "DELETE FROM {$history_table} WHERE camp_id = %d",
                        $campaign_id
                    ));
                }
            } else {
                $campaign_title = self::CAMPAIGN_PREFIX . \md5($url);

                $campaign_id = $wpdb->get_var($wpdb->prepare(
                    "SELECT ID FROM {$wpdb->posts} WHERE post_title = %s AND post_type = 'wp_automatic' LIMIT 1",
                    $campaign_title
                ));

                if (! $campaign_id) {
                    $campaign_id = \wp_insert_post([
                        'post_title'  => $campaign_title,
                        'post_type'   => 'wp_automatic',
                        'post_status' => 'publish',
                    ]);
                }

                if (! $campaign_id || \is_wp_error($campaign_id)) {
                    \error_log('[SEO-Gen Scraper] Failed to create per-item WP Auto campaign for: ' . $url);
                    return false;
                }

                // Configure with the specified campaign type
                \update_post_meta($campaign_id, 'camp_type',        $camp_type);
                \update_post_meta($campaign_id, 'camp_url',         $url);
                \update_post_meta($campaign_id, 'cg_post_status',   'draft');
                \update_post_meta($campaign_id, 'cg_update_record', 'yes');
                \update_post_meta($campaign_id, 'camp_keywords',    '');

                // Clear dedup history
                $history_table = $wpdb->prefix . 'automatic_camp_post';
                if ($wpdb->get_var("SHOW TABLES LIKE '{$history_table}'") === $history_table) {
                    $wpdb->query($wpdb->prepare(
                        "DELETE FROM {$history_table} WHERE camp_id = %d",
                        $campaign_id
                    ));
                }
            }

            // Run the campaign
            $start = \microtime(true);
            $ran   = false;

            // Runner A — global object (most common in ValvePress WP Automatic)
            global $WP_Automatic;
            if (! $ran && isset($WP_Automatic) && \is_object($WP_Automatic)) {
                foreach (['run_campaign', 'run', 'process', 'process_campaign'] as $method) {
                    if (\method_exists($WP_Automatic, $method)) {
                        $WP_Automatic->$method($campaign_id);
                        $ran = true;
                        \error_log('[SEO-Gen Scraper] WP Auto runner: $WP_Automatic->' . $method . '()');
                        break;
                    }
                }
            }

            // Runner B — global function (some forks)
            if (! $ran && \function_exists('wp_automatic_run_campaign')) {
                \wp_automatic_run_campaign($campaign_id);
                $ran = true;
                \error_log('[SEO-Gen Scraper] WP Auto runner: wp_automatic_run_campaign()');
            }

            // Runner C — action hooks
            if (! $ran) {
                foreach (['wp_automatic_process_campaign', 'wp_automatic_run'] as $hook) {
                    if (\has_action($hook)) {
                        \do_action($hook, $campaign_id);
                        $ran = true;
                        \error_log('[SEO-Gen Scraper] WP Auto runner: do_action(' . $hook . ')');
                        break;
                    }
                }
            }

            if (! $ran) {
                \error_log('[SEO-Gen Scraper] WARNING: No WP Automatic runner found for campaign #' . $campaign_id);
            }

            $elapsed = \round(\microtime(true) - $start, 2);
            \error_log('[SEO-Gen Scraper] WP Auto ' . $camp_type . ' took ' . $elapsed . 's for: ' . $url);

            $scraped_post = self::get_latest_scraped_post($campaign_id);

            // Clean up per-item campaigns
            if (! $use_dedicated) {
                \wp_delete_post($campaign_id, true);
            }

            if (! $scraped_post) {
                \error_log('[SEO-Gen Scraper] WP Auto created no draft post for: ' . $url);
                return false;
            }

            $image_id     = \get_post_thumbnail_id($scraped_post->ID);
            $post_content = $scraped_post->post_content;

            if ($image_id) {
                \wp_update_post(['ID' => (int) $image_id, 'post_parent' => 0]);
                \delete_post_thumbnail($scraped_post->ID);
            }

            \wp_delete_post($scraped_post->ID, true);

            return [
                'content'   => $post_content,
                'image_url' => null,
                'image_id'  => $image_id ?: null,
            ];
        } catch (\Exception $e) {
            \error_log('[SEO-Gen Scraper] Tier 2 exception for ' . $url . ': ' . $e->getMessage());
            return false;
        }
    }

	// =========================================================================
	// SOURCE-AWARE ROUTING HELPERS
	// =========================================================================

    /**
     * Find scraper config for a given article URL by matching its domain
     * against stored source configurations.
     *
     * @MODIFIED 2026-03-02 - Helper to resolve per-source config
     */
    private static function get_source_config_for_url($url)
    {
        $sources = \get_option('seo_gen_discovery_sources', []);
        if (empty($sources) || ! is_array($sources)) {
            return null;
        }

        $url_host = \parse_url($url, PHP_URL_HOST);
        if (! $url_host) {
            return null;
        }

        $url_domain = \strtolower(\preg_replace('/^www\./i', '', $url_host));

        foreach ($sources as $source) {
            $source_domain = \strtolower(\preg_replace('/^www\./i', '', $source['domain'] ?? ''));
            if ($source_domain && $source_domain === $url_domain) {
                return $source;
            }
        }

        return null;
    }

	// =========================================================================
	// CONTENT EXTRACTION HELPERS
	// =========================================================================

    /**
     * Extract the main article content from raw HTML.
     */
    private static function extract_main_content($html, $url)
    {
        if (\class_exists('\SEO_Article_Generator\Integration\Content_Cleaner')) {
            return \SEO_Article_Generator\Integration\Content_Cleaner::clean($html);
        }

        \libxml_use_internal_errors(true);
        $dom = new \DOMDocument();
        @$dom->loadHTML(
            \mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8'),
            LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD
        );
        \libxml_clear_errors();

        $xpath = new \DOMXPath($dom);

        $queries = [
            '//article',
            '//*[@id="content"]',
            '//*[@id="main"]',
            '//*[contains(@class,"entry-content")]',
            '//*[contains(@class,"post-content")]',
            '//*[contains(@class,"article-content")]',
            '//main',
            '//body',
        ];

        // Ensure structural tags (div, span) survive so Link_Resolver can read their data-* attributes
        $allowed_tags = '<a><button><p><br><ul><li><h1><h2><h3><h4><h5><h6><strong><em><div><span>';
        foreach ($queries as $query) {
            $nodes = $xpath->query($query);
            if ($nodes && $nodes->length > 0) {
                return \strip_tags($dom->saveHTML($nodes->item(0)), $allowed_tags);
            }
        }

        return \strip_tags($html, $allowed_tags);
    }

    /**
     * Extract the first meaningful image URL from HTML.
     */
    private static function extract_first_image($html, $base_url)
    {
        if (! \preg_match_all('/<img[^>]+src=["\']([^"\']+)["\'][^>]*>/i', (string)$html, $matches)) {
            return null;
        }

        $parsed    = \parse_url($base_url);
        $base_root = ($parsed['scheme'] ?? 'https') . '://' . ($parsed['host'] ?? '');

        foreach ($matches[1] as $src) {
            $src = (string)$src;
            if (\strpos($src, 'data:') === 0) {
                continue;
            }
            if (\preg_match('/pixel|1x1|icon|logo|avatar|badge|banner|ad[_\-]|ads[_\-]/i', $src)) {
                continue;
            }
            if (\preg_match('/[?&]w(?:idth)?=(\d+)/i', $src, $wm) && (int) $wm[1] < 100) {
                continue;
            }

            if (\strpos($src, 'http') !== 0) {
                if (\strpos($src, '//') === 0) {
                    $src = ($parsed['scheme'] ?? 'https') . ':' . $src;
                } else {
                    $src = \rtrim($base_root, '/') . '/' . \ltrim($src, '/');
                }
            }

            if (\preg_match('/\.(jpe?g|png|webp|gif)(\?|$)/i', $src)) {
                return $src;
            }
        }

        return null;
    }

    // =========================================================================
    // UTILITY HELPERS
    // =========================================================================

    private static function is_content_sufficient($content)
    {
        if (empty($content)) {
            return false;
        }
        return \strlen(\strip_tags($content)) >= self::MIN_CONTENT_CHARS;
    }

    private static function is_wp_automatic_available(): bool
    {
        // Signal 1 — custom post type is registered on every load when WP Auto is active.
        // This is the most reliable check in an AJAX context.
        if (\post_type_exists('wp_automatic')) return true;

        // Signal 2 — global object. WP Auto typically instantiates $WP_Automatic at init.
        global $WP_Automatic;
        if (isset($WP_Automatic) && \is_object($WP_Automatic)) return true;

        // Signal 3 — function-based (some forks/versions expose this)
        if (\function_exists('wp_automatic_run_campaign')) return true;

        // Signal 4 — class exists check (class name varies by version)
        if (\class_exists('WP_Automatic') || \class_exists('Wp_Automatic')) return true;

        // Signal 5 — plugin constant
        if (\defined('WP_AUTOMATIC_VERSION') || \defined('WP_AUTO_VERSION')) return true;

        // Signal 6 — action hook (custom/fork versions)
        if (\has_action('wp_automatic_process_campaign')) return true;

        return false;
    }

    /**
     * Public wrapper — bootstrap AJAX methods call this instead of duplicating the check inline.
     */
    public static function is_available(): bool
    {
        return self::is_wp_automatic_available();
    }

    private static function get_latest_scraped_post($campaign_id)
    {
        // WP Automatic stores campaign ID in post meta.
        // Key varies by version: 'wpautomaticcamp' (no extra underscore) is most common.
        // 'wp_automatic_camp' is used by some forks. Check both.
        foreach (['wpautomaticcamp', 'wp_automatic_camp', 'automatic_camp'] as $meta_key) {
            $posts = \get_posts([
                'post_type'      => 'post',
                'post_status'    => ['draft', 'publish', 'pending'],
                'meta_key'       => $meta_key,
                'meta_value'     => $campaign_id,
                'posts_per_page' => 1,
                'orderby'        => 'date',
                'order'          => 'DESC',
            ]);
            if (! empty($posts)) {
                \error_log('[SEO-Gen Scraper] Found scraped post via meta_key: ' . $meta_key);
                return $posts[0];
            }
        }
        return false;
    }
}
