<?php
/**
 * DIT Video Module — Cleanup
 *
 * Deletes generated videos, their attachments, and all temp/work data. Hooks
 * into DIT's existing daily cleanup action (dit_ts_daily_cleanup) and can be
 * invoked manually. Uses DIT logging.
 *
 * @package DIT\TrendStudio\Video
 */

namespace DIT\TrendStudio\Video;

use DIT\TrendStudio\Infrastructure\Logger;

if (!defined('ABSPATH')) {
    exit;
}

class Cleanup
{
    /** @var Settings */
    protected $settings;

    /** @var Logger */
    protected $logger;

    public function __construct(Settings $settings, Logger $logger)
    {
        $this->settings = $settings;
        $this->logger   = $logger;
    }

    /**
     * Register the daily-cleanup hook (call once from Module).
     */
    public function register_hooks(): void
    {
        add_action('dit_ts_daily_cleanup', array($this, 'run_daily'));
    }

    /**
     * Daily cleanup: purge temp work dirs + old video attachments past age.
     */
    public function run_daily(): void
    {
        if (!$this->settings->get_bool('cleanup_enabled', true)) {
            return;
        }
        $age_days = $this->settings->get_int('cleanup_age_days', 30);
        $cutoff   = time() - $age_days * DAY_IN_SECONDS;

        // 1) Temp work dirs under WP_CONTENT_DIR/dit-video/*
        $base = WP_CONTENT_DIR . '/dit-video';
        if (is_dir($base)) {
            foreach (glob($base . '/*') as $dir) {
                if (is_dir($dir) && filemtime($dir) < $cutoff) {
                    $this->remove_dir($dir);
                    $this->logger->info('DIT Video cleanup: removed temp dir ' . basename($dir));
                }
            }
        }

        // 2) Old video attachments flagged as video-ready (optional)
        $videos = get_posts(array(
            'post_type'      => 'attachment',
            'post_mime_type' => array('video/mp4'),
            'posts_per_page' => -1,
            'date_query'     => array('before' => gmdate('Y-m-d H:i:s', $cutoff)),
            'fields'         => 'ids',
        ));
        foreach ((array) $videos as $aid) {
            $owned = get_post_meta($aid, '_dit_ts_video_owned', true);
            if ((string) $owned === '1') {
                wp_delete_attachment($aid, true);
                $this->logger->info('DIT Video cleanup: deleted video attachment #' . $aid);
            }
        }
    }

    /**
     * Full manual cleanup: delete ALL video temp data + attachments.
     */
    public function clean_all(): array
    {
        $removed = 0;
        $base = WP_CONTENT_DIR . '/dit-video';
        if (is_dir($base)) {
            foreach (glob($base . '/*') as $dir) {
                if (is_dir($dir)) {
                    $this->remove_dir($dir);
                    $removed++;
                }
            }
        }

        $videos = get_posts(array(
            'post_type' => 'attachment', 'post_mime_type' => array('video/mp4'),
            'posts_per_page' => -1, 'fields' => 'ids',
        ));
        foreach ((array) $videos as $aid) {
            if ((string) get_post_meta($aid, '_dit_ts_video_owned', true) === '1') {
                wp_delete_attachment($aid, true);
                $removed++;
            }
        }
        $this->logger->info('DIT Video cleanup: manual clean_all removed ' . $removed . ' items.');
        return array('removed' => $removed);
    }

    private function remove_dir(string $dir): void
    {
        // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec
        @exec('rm -rf ' . escapeshellarg($dir));
    }
}
