<?php

/**
 * Rank Math Integration Class
 *
 * Handles Rank Math SEO and Sitemap enhancements for MCQ CPT.
 *
 * @package WP_News_MCQ_Generator
 */

if (! defined('ABSPATH')) {
    exit;
}

class NM_Rank_Math_Integration
{
    /**
     * Initialize the integration.
     */
    public static function init()
    {
        // Include social images in Rank Math Sitemap - Trying multiple filters for compatibility
        add_filter('rank_math/sitemap/urlset/images', array(self::class, 'add_social_images_to_sitemap'), 10, 2);
        add_filter('rank_math/sitemap/urlimages', array(self::class, 'add_social_images_to_sitemap'), 10, 2);
        add_filter('rank_math/sitemap/entry', array(self::class, 'add_images_to_sitemap_entry'), 10, 3);
        add_filter('rank_math/sitemap/content_images', array(self::class, 'add_social_images_to_sitemap'), 10, 2);

        // Force Rank Math to use our generated social image for OpenGraph/Twitter
        add_filter('rank_math/frontend/og_image', array(self::class, 'set_opengraph_image'));
        add_filter('rank_math/frontend/twitter_image', array(self::class, 'set_opengraph_image'));

        // @NEW 9.4.0: Exclude the whole 'mcq' post type from the Rank Math XML sitemap.
        // Individual MCQs are noindex (by design) and the /mcq/ archive is also noindex, so
        // they should NOT appear in the sitemap. Rank Math's per-post noindex already drops
        // the individual questions, but the post-type ARCHIVE URL (/mcq/) still shows up in
        // mcq-sitemapN.xml. This filter removes the entire post type from the sitemap, which
        // cleanly drops BOTH the archive URL and any leftover MCQ URLs. It is also robust to
        // the "Archive → noindex" option not being visible for this plugin-generated CPT.
        add_filter('rank_math/sitemap/exclude_post_type', array(self::class, 'exclude_mcq_from_sitemap'), 10, 2);
    }

    /**
     * Exclude the 'mcq' post type from the Rank Math sitemap.
     *
     * @param bool   $exclude Whether the post type is already excluded.
     * @param string $type    Post type name.
     * @return bool
     */
    public static function exclude_mcq_from_sitemap($exclude, $type)
    {
        if ($type === 'mcq') {
            return true;
        }
        return $exclude;
    }

    /**
     * Add MCQ social image to Rank Math sitemap entries using urlset/images filter.
     *
     * @param array $images Array of images for the URL.
     * @param int   $post_id Post ID.
     * @return array Modified array of images.
     */
    public static function add_social_images_to_sitemap($images, $post_id)
    {
        $post = get_post($post_id);
        if (! $post || $post->post_type !== 'mcq') {
            return $images;
        }

 $social_image_url = get_post_meta($post_id, '_nm_social_image_url', true);

 if ($social_image_url) {
 $social_image_url = set_url_scheme($social_image_url, 'https');

 foreach ($images as $img) {
 if ($img['src'] === $social_image_url) {
                    return $images;
                }
            }

            $images[] = array(
                'src'   => $social_image_url,
                'title' => get_the_title($post_id),
                'alt'   => get_the_title($post_id),
            );
        }

        return $images;
    }

    /**
     * Alternative strategy: Inject images directly into the sitemap entry array.
     * This often fixes the "0" image count in the sitemap index page.
     */
    public static function add_images_to_sitemap_entry($url, $type, $post)
    {
        if ($type !== 'post' || ! $post || $post->post_type !== 'mcq') {
            return $url;
        }

 $social_image_url = get_post_meta($post->ID, '_nm_social_image_url', true);
 if ($social_image_url) {
 $social_image_url = set_url_scheme($social_image_url, 'https');

 if (! isset($url['images'])) {
 $url['images'] = array();
 }

 foreach ($url['images'] as $img) {
 if ($img['src'] === $social_image_url) {
 return $url;
 }
 }

            $url['images'][] = array(
                'src'   => $social_image_url,
                'title' => $post->post_title,
                'alt'   => $post->post_title,
            );
        }

        return $url;
    }

    /**
     * Set the OpenGraph/Twitter image to our generated social image.
     *
     * @param string $image_url The image URL determined by Rank Math.
     * @return string Modified image URL.
     */
 public static function set_opengraph_image($image_url)
 {
 if (! is_singular('mcq')) {
 return $image_url;
 }

 $post_id = get_the_ID();
 $social_image_url = get_post_meta($post_id, '_nm_social_image_url', true);

 if ($social_image_url) {
 return set_url_scheme($social_image_url, 'https');
 }

 return $image_url;
 }
}
