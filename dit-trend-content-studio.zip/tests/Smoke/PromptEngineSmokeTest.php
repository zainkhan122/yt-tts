<?php

declare(strict_types=1);

namespace DIT\TrendStudio\Tests\Smoke;

use PHPUnit\Framework\TestCase;
use DIT\TrendStudio\Content\PromptEngine;
use DIT\TrendStudio\Tests\Fakes\FakeAIProvider;
use DIT\TrendStudio\Tests\Fakes\FakeLogger;

final class PromptEngineSmokeTest extends TestCase
{
	public function test_direct_strategy_returns_provider_output(): void
	{
		$provider = new FakeAIProvider([
			'headline' => 'Direct Headline',
			'sections' => [
				[
					'heading' => 'Intro',
					'bodyhtml' => '<p>Hello world</p>',
				],
			],
		], [], 'gemini-test');

		$logger = new FakeLogger();
		$engine = new PromptEngine($provider, $logger);

		$result = $engine->generate([
			'topic' => 'Smoke test article',
		], 'gemini');

		$this->assertSame('Direct Headline', $result['headline']);
		$this->assertSame('gemini_direct', $result['_generation_method']);
		$this->assertCount(1, $provider->calls);
		$this->assertSame('generate', $provider->calls[0]['method']);
	}

	public function test_custom_strategy_returns_provider_output(): void
	{
		$provider = new FakeAIProvider([
			'headline' => 'Custom Headline',
			'sections' => [
				['heading' => 'Intro', 'body_html' => 'Custom body'],
			],
		], [], 'custom-test');

		$logger = new FakeLogger();
		$engine = new PromptEngine($provider, $logger);

		$result = $engine->generate([], 'custom');

		$this->assertSame('Custom Headline', $result['headline']);
		$this->assertSame('custom_direct', $result['_generation_method']);
		$this->assertCount(1, $provider->calls);
		$this->assertSame('generate', $provider->calls[0]['method']);
	}
}
