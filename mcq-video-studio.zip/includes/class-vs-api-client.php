<?php

/**
 * Video Studio API Client
 *
 * Abstraction layer for communicating with the MCQ Plugin.
 * Currently uses direct class calls for reliability when running on the same server,
 * but structured to support REST API switch in the future.
 *
 * @package    MCQ_Video_Studio
 * @subpackage Includes
 * @since      1.0.0
 */

if (! defined('ABSPATH')) {
    exit;
}

/**
 * Class VS_API_Client
 *
 * Client for consuming MCQ data services.
 *
 * @since 1.0.0
 */
class VS_API_Client
{

    private static $instance = null;

    public static function init()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Get list of available topics/exams.
     *
     * @param string $type 'topic' or 'exam'.
     * @return array|WP_Error
     */
    public function get_sources($type = 'topic')
    {
        // @Refactored 2026-02-09: Use Custom Table Repository
        // Ignore $type 'exam' distinction for now, everything is in wp_vs_topics
        if (! class_exists('VS_MCQ_Repository')) {
            return new WP_Error('missing_class', 'VS_MCQ_Repository not found');
        }

        global $wpdb;
        $table_topics = $wpdb->prefix . 'vs_topics';
        $table_bank   = $wpdb->prefix . 'vs_mcq_bank';

        $topics = $wpdb->get_results("
            SELECT t.id, t.name, t.slug, COUNT(q.id) as count 
            FROM $table_topics t 
            LEFT JOIN $table_bank q ON t.id = q.topic_id 
            GROUP BY t.id
            HAVING count > 0
            ORDER BY t.name ASC
        ");

        $data = array();
        foreach ($topics as $t) {
            $data[] = array(
                'id'    => $t->id,
                'name'  => $t->name,
                'slug'  => $t->slug,
                'count' => $t->count,
            );
        }

        return $data;
    }

    /**
     * Reserve questions for a job.
     *
     * @FIX: `usage_count` was never initialized after reserve, leaving reserved rows stale.
     *       Add an explicit INCREMENT here so round-robin distribution actually works.
     *
     * @param int    $topic_id Topic ID.
     * @param int    $exam_id  Exam ID (optional).
     * @param int    $count    Number of questions.
     * @param string $job_id   Job Identifier.
     * @return array|WP_Error
     */
    public function reserve_questions($topic_id, $exam_id, $count, $job_id)
    {
        if (! class_exists('VS_MCQ_Repository')) {
            return new WP_Error('missing_class', 'VS_MCQ_Repository not found');
        }

        global $wpdb;
        $table_bank = $wpdb->prefix . 'vs_mcq_bank';

        // @FIX: ORDER BY `usage_count` requires the column to exist. Add defensive fallback
        //       for sites whose column was missed by using `(usage_count + 0)` as a stable
        //       secondary sort when `usage_count` is missing or NULL.
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table_bank} WHERE topic_id = %d AND status = %s ORDER BY COALESCE(usage_count, 0) ASC, RAND() LIMIT %d",
            absint($topic_id),
            'approved',
            absint($count)
        ), ARRAY_A);

        if (empty($results)) {
            return new WP_Error('no_questions', 'No questions found for Topic ID ' . $topic_id);
        }

        foreach ($results as $row) {
            if (is_numeric($row['id'])) {
                $wpdb->query($wpdb->prepare(
                    "UPDATE {$table_bank} SET last_used_job_id = %s, usage_count = COALESCE(usage_count, 0) + 1 WHERE id = %d",
                    $job_id,
                    $row['id']
                ));
            }
        }

        $questions = array();
        foreach ($results as $row) {
            $decoded_options = json_decode($row['options'], true);
            $questions[] = array(
                'id'             => $row['id'],
                'question'       => $row['question_text'],
                'options'        => is_array($decoded_options) ? $decoded_options : array(),
                'correct'        => intval($row['correct_index']),
                // @FIX 1.5.0 (SSOT): Preserve the source mapping + richer metadata so
                //       jobs rendered from reserved questions keep the link back to the
                //       source MCQ post (parent_post_id) and the explanation/difficulty
                //       the templates use. Previously these were dropped, so the video
                //       scheduler's back-link (article embed) could not resolve the source
                //       and explanation bars were always empty.
                'parent_post_id' => isset( $row['parent_post_id'] ) ? (int) $row['parent_post_id'] : 0,
                'topic_id'       => isset( $row['topic_id'] ) ? (int) $row['topic_id'] : 0,
                'explanation'    => isset( $row['explanation'] ) ? (string) $row['explanation'] : '',
                'difficulty'     => isset( $row['difficulty'] ) ? (string) $row['difficulty'] : '',
            );
        }

        return $questions;
    }

    /**
     * Mark questions as used.
     *
     * @param array  $question_ids Array of question IDs.
     * @param string $job_id       Job ID.
     * @param string $video_url    Video URL.
     * @return int|WP_Error Count updated or error.
     */
    public function mark_used($question_ids, $job_id, $video_url)
    {
        // @NEW 2026-02-18: Usage Tracking Implementation
        if (empty($question_ids)) {
            return 0;
        }

        if (! is_array($question_ids)) {
            $question_ids = array($question_ids);
        }

        global $wpdb;
        $table = $wpdb->prefix . 'vs_mcq_bank';
        $count = 0;

        // Verify table exists before attempting update (safety)
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") !== $table) {
            return 0;
        }

        foreach ($question_ids as $qid) {
            // Handle numeric IDs only (ignore temp 'topic_X' IDs from volatile generation)
            if (is_numeric($qid) && (int) $qid > 0) {
                $count += (int) $wpdb->query($wpdb->prepare(
                    "UPDATE $table SET usage_count = COALESCE(usage_count,0) + 1, last_used_job_id = %s WHERE id = %d",
                    $job_id,
                    (int) $qid
                ));
            }
        }

        return $count;
    }

    /**
     * Release reservation on failure/cancel.
     *
     * @param string $job_id Job ID.
     * @return int|WP_Error
     */
    public function release_reservation($job_id)
    {
        global $wpdb;
        $table_bank = $wpdb->prefix . 'vs_mcq_bank';
        if ($wpdb->get_var("SHOW TABLES LIKE '{$table_bank}'") !== $table_bank) {
            return true;
        }
        $wpdb->query($wpdb->prepare(
            "UPDATE {$table_bank} SET last_used_job_id = NULL WHERE last_used_job_id = %s",
            $job_id
        ));
        return true;
    }
    /**
     * Generate MCQs via Parent Plugin Gemini connection.
     *
     * @param string $topic
     * @param int    $count
     * @return array|WP_Error Array of raw MCQ data
     */
    public function generate_mcq_batch($topic, $count)
    {
        return $this->generate_mcq_batch_with_context($topic, $count, 'auto');
    }

    public function generate_mcq_batch_with_context($topic, $count, $context = 'auto')
    {
        if (! class_exists('NM_API_Client')) {
            // @MODIFIED 2026-02-18: Fallback to Local Generation (Independent Mode)
            // Use our own AI Handler to generate questions if Parent is missing.
            if (class_exists('VS_AJAX_AI_Quiz_Handler')) {
                $handler = VS_AJAX_AI_Quiz_Handler::get_instance();
                // Call public generation method
                $questions = $handler->generate_topic_quiz_data($topic, $count, $context);
                if (is_wp_error($questions)) {
                    return $questions;
                }
                return $questions;
            }
            return new WP_Error('dependency_missing', 'AI Handler not available.');
        }

        $api = NM_API_Client::get_instance();

        // Using the parent plugin's proven prompt engineering
        // Signature: generate_mcq_from_topic($topic_name, $parent_name, $num_questions, ...)
        $response = $api->generate_mcq_from_topic($topic, '', $count);

        if (! isset($response['success']) || ! $response['success']) {
            return new WP_Error('api_error', $response['error'] ?? 'Unknown API Error');
        }

        if (empty($response['data']['questions'])) {
            return new WP_Error('empty_response', 'AI returned no questions.');
        }

        return $response['data']['questions'];
    }
}
