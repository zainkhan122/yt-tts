jQuery(document).ready(function ($) {
	var debugLogState = {
		page: 1,
		totalPages: 1,
		perPage: 100,
		path: ''
	};

	// Tab switching
	$('.seo-gen-logs-tab').on('click', function () {
		var tab = $(this).data('tab');
		$('.seo-gen-logs-tab').removeClass('active');
		$(this).addClass('active');
		$('.seo-gen-logs-tab-content').hide();
		$('#seo-gen-tab-' + tab).show();
	});

	// Copy plugin logs to clipboard
	$('#seo-gen-copy-logs').on('click', function () {
		var logContent = $('#seo-gen-log-viewer').text();
		var tempInput = $('<textarea>');
		$('body').append(tempInput);
		tempInput.val(logContent).select();
		document.execCommand('copy');
		tempInput.remove();

		var originalText = $(this).text();
		$(this).text('Copied!').prop('disabled', true);
		setTimeout(function () {
			$('#seo-gen-copy-logs').text(originalText).prop('disabled', false);
		}, 2000);
	});

	// Copy debug log to clipboard
	$('#seo-gen-copy-debug-log').on('click', function () {
		var logContent = $('#seo-gen-debug-log-viewer').text();
		if (!logContent) {
			return;
		}
		var tempInput = $('<textarea>');
		$('body').append(tempInput);
		tempInput.val(logContent).select();
		document.execCommand('copy');
		tempInput.remove();

		var originalText = $(this).text();
		$(this).text('Copied!').prop('disabled', true);
		setTimeout(function () {
			$('#seo-gen-copy-debug-log').text(originalText).prop('disabled', false);
		}, 2000);
	});

	// Delete current log file
	$('#seo-gen-clear-current').on('click', function () {
		var $btn = $(this);
		var filename = $btn.data('file');

		if (!filename) {
			return;
		}

		if (confirm('Are you sure you want to delete this log file?')) {
			$btn.prop('disabled', true).text('Deleting...');

			$.ajax({
				url: seoGenData.ajax_url,
				type: 'POST',
				data: {
					action: 'seo_gen_delete_log',
					nonce: seoGenData.nonce,
					log_file: filename
				},
 success: function (response) {
if (response.success) {
var params = new URLSearchParams(window.location.search);
params.delete('log_file');
window.location.href = 'admin.php?page=seo-generator-logs&tab=' + (params.get('tab') || 'plugin');
} else {
						alert(response.data.message || 'Failed to delete log file.');
						$btn.prop('disabled', false).text('Delete This Log');
					}
				},
				error: function () {
					alert('An error occurred while deleting the log file.');
					$btn.prop('disabled', false).text('Delete This Log');
				}
			});
		}
	});

	// Save debug log path
	$('#seo-gen-save-debug-path').on('click', function () {
		var $btn = $(this);
		var path = $('#seo-gen-debug-log-path').val().trim();

		$btn.prop('disabled', true).text('Saving...');

		$.ajax({
			url: seoGenData.ajax_url,
			type: 'POST',
			data: {
				action: 'seo_gen_save_debug_log_path',
				nonce: seoGenData.nonce,
				debug_log_path: path
			},
			success: function (response) {
				if (response.success) {
					$btn.text('Saved!');
					var $meta = $('.seo-gen-debug-log-meta');
					if (response.data.file_info) {
						$meta.text(response.data.file_info.size + ' \u2014 ' + response.data.file_info.mtime);
						if ($meta.length === 0) {
							$('#seo-gen-debug-log-path').after(' <span class="seo-gen-debug-log-meta">' + response.data.file_info.size + ' \u2014 ' + response.data.file_info.mtime + '</span>');
						}
					} else {
						$meta.remove();
					}
				} else {
					alert(response.data.message || 'Failed to save path.');
					$btn.text('Save Path');
				}
			},
			error: function () {
				alert('An error occurred while saving the path.');
				$btn.text('Save Path');
			},
			complete: function () {
				setTimeout(function () {
					$btn.prop('disabled', false).text('Save Path');
				}, 1500);
			}
		});
	});

	function loadDebugLogPage(pageNum) {
		var path = $('#seo-gen-debug-log-path').val().trim();
		if (!path) {
			alert('Please enter a debug log path first.');
			return;
		}

		debugLogState.path = path;
		debugLogState.page = pageNum;

		var $btn = $('#seo-gen-load-debug-log');
		$btn.prop('disabled', true).text('Loading...');

		$.ajax({
			url: seoGenData.ajax_url,
			type: 'POST',
			data: {
				action: 'seo_gen_load_debug_log',
				nonce: seoGenData.nonce,
				debug_log_path: path,
				debug_log_page: pageNum,
				debug_log_per_page: debugLogState.perPage
			},
			success: function (response) {
				if (response.success) {
					var content = response.data.content || '(empty page)';
					$('#seo-gen-debug-log-viewer').text(content);
					$('#seo-gen-tab-debug .seo-gen-log-content-wrapper .description').remove();

					debugLogState.page = response.data.page;
					debugLogState.totalPages = response.data.total_pages;
					debugLogState.perPage = response.data.per_page;

					updatePaginationUI();

					var $meta = $('.seo-gen-debug-log-meta');
					var metaText = response.data.size + ' \u2014 ' + response.data.mtime + ' \u2014 ' + response.data.total_lines + ' lines';
					if ($meta.length === 0) {
						$('#seo-gen-debug-log-path').after(' <span class="seo-gen-debug-log-meta">' + metaText + '</span>');
					} else {
						$meta.text(metaText);
					}
				} else {
					alert(response.data.message || 'Failed to load debug log.');
				}
			},
			error: function () {
				alert('An error occurred while loading the debug log.');
			},
			complete: function () {
				$btn.prop('disabled', false).text('Load');
			}
		});
	}

	function updatePaginationUI() {
		var $pagination = $('#seo-gen-debug-log-pagination');
		var $prev = $('#seo-gen-debug-prev');
		var $next = $('#seo-gen-debug-next');
		var $info = $('#seo-gen-debug-page-info');

		if (debugLogState.totalPages <= 1) {
			$pagination.hide();
			return;
		}

		$pagination.show();
		$prev.prop('disabled', debugLogState.page <= 1);
		$next.prop('disabled', debugLogState.page >= debugLogState.totalPages);
		$info.text('Page ' + debugLogState.page + ' of ' + debugLogState.totalPages);
	}

	// Load debug log (initial load = page 1, most recent)
	$('#seo-gen-load-debug-log').on('click', function () {
		loadDebugLogPage(1);
	});

	// Pagination: Prev
	$('#seo-gen-debug-prev').on('click', function () {
		if (debugLogState.page > 1) {
			loadDebugLogPage(debugLogState.page - 1);
		}
	});

	// Pagination: Next
	$('#seo-gen-debug-next').on('click', function () {
		if (debugLogState.page < debugLogState.totalPages) {
			loadDebugLogPage(debugLogState.page + 1);
		}
	});

	// Auto-load debug log on page load if path is saved and tab is active
	if ($('#seo-gen-tab-debug').is(':visible') && $('#seo-gen-debug-log-path').val().trim()) {
		loadDebugLogPage(1);
	}
});
