<?php

/**
 * Link Whisper Bridge
 *
 * @package DIT_TrendStudio
 * @MODIFIED 2026-09-10 - Initial integration with Link Whisper Premium (v2.9.0).
 *                        DIT-specific zone strategy: flat Gutenberg block markup
 *                        parsed at the `<!-- wp:... -->` boundary, linkable block
 *                        types allowlisted, callout groups skipped, anchors derived
 *                        via LW's own getSuggestionAnchorWords().
 */

namespace DIT\TrendStudio\Integrations\LinkWhisper;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Bridge between DIT TrendStudio and Link Whisper Premium.
 *
 * Reads a post's `post_content` (already-serialized Gutenberg block markup),
 * asks LW for sentence-level internal-link suggestions via Wpil_Suggestion,
 * inserts <a> tags into the inner HTML of the matching linkable blocks,
 * and writes the modified content back via wp_update_post().
 *
 * Never blocks publishing. Every public entrypoint is wrapped so a failure
 * here can never prevent a DIT-generated post from being saved.
 */
class Link_Whisper_Bridge
{
    /** Default cap on links inserted per post. */
    public const DEFAULT_MAX_LINKS = 2;

    /**
     * Plugin-owned idempotency meta key. Set after a successful run.
     * If present, the bridge is a no-op (the post has already been processed).
     */
    public const PROCESSED_META_KEY = '_dit_ts_lw_processed';

    /**
     * Plugin-owned last-error meta key. Set on failure for support triage.
     * Cleared at the start of each run.
     */
    public const ERROR_META_KEY = '_dit_ts_lw_last_error';

    /**
     * Allowlist of Gutenberg block names whose inner HTML is considered
     * linkable. Heading H1 is the post title (post_title, not post_content);
     * H4-H6 are excluded to keep anchors out of ToC-style fragments.
     * image, embed, group (callout) are deliberately excluded
     * by name and by the callout-skip rule.
     *
     * @var string[]
     */
    private const LINKABLE_BLOCKS = [
        'paragraph',
        'list',
        'quote',
        'table',
    ];

    /**
     * Gutenberg block names whose inner HTML is linkable but only at H2/H3.
     * (H1 = post title, H4+ skipped per design.)
     *
     * @var string[]
     */
    private const LINKABLE_HEADINGS = ['heading'];

    /** Lower bound on inner-HTML length for a block to be considered linkable. */
    private const MIN_BLOCK_INNER_LEN = 20;

    /** Logger instance (optional). */
    private $logger;

    public function __construct($logger = null)
    {
        $this->logger = $logger;
    }

    /**
     * Convenience entrypoint used by Scheduler::auto_publish_job().
     *
     * Idempotent: bails out if the post has already been processed.
     *
     * @param int $post_id Existing post ID.
     * @return bool True if content was modified and written back, false otherwise.
     */
    public function inject_for_post(int $post_id): bool
    {
        $this->log('info', 'Link_Whisper_Bridge: inject_for_post ENTRY', [
            'post_id' => $post_id,
            'enabled_opt' => get_option('dit_ts_lw_integration_enabled', 'NOT_SET'),
            'lw_available' => self::is_lw_available(),
            'processed_meta' => get_post_meta($post_id, self::PROCESSED_META_KEY, true),
        ]);

        if ($post_id <= 0) {
            $this->log('info', 'Link_Whisper_Bridge: inject_for_post EXIT - invalid post_id', ['post_id' => $post_id]);
            return false;
        }

        if (!$this->is_enabled()) {
            $this->log('info', 'Link_Whisper_Bridge: integration disabled — link injection skipped (dit_ts_lw_integration_enabled=false)', [
                'post_id' => $post_id,
                'enabled_value' => get_option('dit_ts_lw_integration_enabled', 'NOT_SET'),
            ]);
            return false;
        }

        $this->log('info', 'Link_Whisper_Bridge: enabled check PASSED', ['post_id' => $post_id]);

        if (!$this->is_lw_available()) {
            // Toggle is ON but LW classes are missing — this is the #1 silent failure.
            $this->log('warning', 'Link_Whisper_Bridge: Link Whisper Premium not available — link injection skipped (is_lw_available=false)', [
                'post_id' => $post_id,
                'Wpil_Suggestion' => class_exists('Wpil_Suggestion'),
                'Wpil_Post' => class_exists('Wpil_Post'),
                'Wpil_Model_Post' => class_exists('Wpil_Model_Post'),
                'Wpil_Stemmer' => class_exists('Wpil_Stemmer'),
            ]);
            return false;
        }

        $this->log('info', 'Link_Whisper_Bridge: LW availability check PASSED', ['post_id' => $post_id]);

        if (get_post_meta($post_id, self::PROCESSED_META_KEY, true)) {
            $this->log('info', 'Link_Whisper_Bridge: inject_for_post EXIT - already processed (idempotent)', ['post_id' => $post_id]);
            return false;
        }

        $post = get_post($post_id);
        if (!$post || empty($post->post_content)) {
            $this->log('info', 'Link_Whisper_Bridge: inject_for_post EXIT - post not found or empty content', [
                'post_id' => $post_id,
                'post_found' => $post !== null,
                'content_empty' => $post ? empty($post->post_content) : 'N/A',
            ]);
            return false;
        }

        $this->log('info', 'Link_Whisper_Bridge: post content check PASSED', [
            'post_id' => $post_id,
            'content_len' => mb_strlen($post->post_content),
        ]);

        delete_post_meta($post_id, self::ERROR_META_KEY);

        try {
            $max_links = (int) get_option('dit_ts_lw_max_links_per_post', self::DEFAULT_MAX_LINKS);
            if ($max_links < 1) {
                $max_links = self::DEFAULT_MAX_LINKS;
            }

            $this->log('info', 'Link_Whisper_Bridge: calling inject()', [
                'post_id' => $post_id,
                'max_links' => $max_links,
            ]);

            $new_content = $this->inject($post->post_content, $post_id, $max_links);

            $this->log('info', 'Link_Whisper_Bridge: inject() returned', [
                'post_id' => $post_id,
                'content_changed' => $new_content !== $post->post_content,
                'orig_len' => mb_strlen($post->post_content),
                'new_len' => mb_strlen($new_content),
            ]);

            if ($new_content === $post->post_content) {
                // Distinguish a normal no-op (no suggestions / no matching anchors)
                // from an exception the inner catch already logged. Both leave content
                // unchanged, but the inner inject() now records _dit_ts_lw_last_error
                // on the exception path, so this info line is the "clean no-op" signal.
                $this->log('info', 'Link_Whisper_Bridge: no content changes (no links inserted for this run)', [
                    'post_id'        => $post_id,
                    'last_error_meta' => get_post_meta($post_id, self::ERROR_META_KEY, true),
                ]);
                return false;
            }

            $this->log('info', 'Link_Whisper_Bridge: calling wp_update_post', ['post_id' => $post_id]);

            $update = wp_update_post(
                [
                    'ID'           => $post_id,
                    'post_content' => $new_content,
                ],
                true
            );

            if (is_wp_error($update)) {
                $this->log('error', 'Link_Whisper_Bridge: wp_update_post failed', [
                    'post_id' => $post_id,
                    'error'   => $update->get_error_message(),
                ]);
                return false;
            }

            $this->log('info', 'Link_Whisper_Bridge: wp_update_post SUCCESS', ['post_id' => $post_id]);

            update_post_meta($post_id, self::PROCESSED_META_KEY, (string) time());
            return true;
        } catch (\Throwable $e) {
            update_post_meta($post_id, self::ERROR_META_KEY, $e->getMessage());
            $this->log('error', 'Link_Whisper_Bridge: uncaught exception', [
                'post_id' => $post_id,
                'message' => $e->getMessage(),
                'file'    => $e->getFile(),
                'line'    => $e->getLine(),
                'trace'   => $e->getTraceAsString(),
            ]);
            return false;
        }
    }

    /**
     * Master toggle check.
     */
    public function is_enabled(): bool
    {
        return (bool) get_option('dit_ts_lw_integration_enabled', false);
    }

    /**
     * LW availability check. Mirrors ref plan §2.1.
     */
    public static function is_lw_available(): bool
    {
        return class_exists('Wpil_Suggestion')
            && class_exists('Wpil_Post')
            && class_exists('Wpil_Model_Post')
            && class_exists('Wpil_Stemmer');
    }

    /**
     * Core injection routine.
     *
     * 1. Parse Gutenberg block comments to recover a flat list of
     *    (block_name, attrs, inner_html, byte_start, byte_end) entries.
     * 2. Build $zone_content by concatenating the inner HTML of every
     *    linkable block (with offsets recorded for reassembly).
     * 3. Override LW's in-memory content via Wpil_Model_Post::setContent().
     * 4. Call Wpil_Suggestion::getPostSuggestions() (or AI variant if enabled).
     * 5. For each suggestion, compute anchor via LW's getSuggestionAnchorWords()
     *    and insert <a> tags into the matching block's inner HTML.
     * 6. Re-serialize each touched block and substr_replace the full content.
     *
     * @param string $content  Full serialized block markup.
     * @param int    $post_id  Existing post ID.
     * @param int    $max_links Max links to insert.
     * @return string Modified content (or original on any failure).
     */
    public function inject(string $content, int $post_id, int $max_links = self::DEFAULT_MAX_LINKS): string
    {
        $this->log('info', 'Link_Whisper_Bridge: inject() ENTRY', [
            'post_id' => $post_id,
            'content_len' => mb_strlen($content),
            'max_links' => $max_links,
            'lw_available' => self::is_lw_available(),
        ]);

        if ($post_id <= 0 || trim($content) === '') {
            $this->log('info', 'Link_Whisper_Bridge: inject() EXIT - invalid post_id or empty content', ['post_id' => $post_id]);
            return $content;
        }
        if (!self::is_lw_available()) {
            $this->log('info', 'Link_Whisper_Bridge: inject() EXIT - LW not available', ['post_id' => $post_id]);
            return $content;
        }

        try {
            $skip_callouts = (bool) get_option('dit_ts_lw_skip_callouts', true);

            // 1. Parse blocks.
            $this->log('info', 'Link_Whisper_Bridge: parsing blocks', ['post_id' => $post_id, 'skip_callouts' => $skip_callouts]);
            $blocks = $this->parse_blocks($content, $skip_callouts);
            $this->log('info', 'Link_Whisper_Bridge: parse_blocks returned', [
                'post_id' => $post_id,
                'block_count' => count($blocks),
                'blocks' => array_map(function($b) { return ['name' => $b['name'], 'inner_len' => mb_strlen($b['inner_html']), 'skip' => $b['skip'] ?? false]; }, $blocks),
            ]);
            if (empty($blocks)) {
                $this->log('info', 'Link_Whisper_Bridge: inject() EXIT - no blocks parsed', ['post_id' => $post_id]);
                return $content;
            }

            // 2. Build zone content from linkable blocks.
            $zone_content = '';
            $linkable_count = 0;
            foreach ($blocks as $b) {
                if (!$this->is_block_linkable($b)) {
                    continue;
                }
                $zone_content .= $b['inner_html'] . "\n\n";
                $linkable_count++;
            }
            $this->log('info', 'Link_Whisper_Bridge: zone content built', [
                'post_id' => $post_id,
                'linkable_blocks' => $linkable_count,
                'zone_len' => mb_strlen($zone_content),
            ]);
            if (trim($zone_content) === '') {
                $this->log('info', 'Link_Whisper_Bridge: inject() EXIT - zone content empty', ['post_id' => $post_id]);
                return $content;
            }

            // 3. Inject into LW post model.
            $this->log('info', 'Link_Whisper_Bridge: creating Wpil_Model_Post and setting content', ['post_id' => $post_id]);
            $post = new \Wpil_Model_Post($post_id);
            $post->setContent($zone_content);

            // 4. Call LW suggestion engine.
            $use_ai = false;
            if (class_exists('Wpil_Settings') && method_exists('Wpil_Settings', 'get_use_ai_suggestions')) {
                $use_ai = (bool) \Wpil_Settings::get_use_ai_suggestions();
            }
            $this->log('info', 'Link_Whisper_Bridge: calling LW suggestion engine', [
                'post_id' => $post_id,
                'use_ai' => $use_ai,
            ]);

            if ($use_ai && method_exists('Wpil_Suggestion', 'getAIPostSuggestions')) {
                $count = 0;
                $phrases = \Wpil_Suggestion::getAIPostSuggestions($post, null, false, null, $count, 0);
            } else {
                $phrases = \Wpil_Suggestion::getPostSuggestions($post, null, false, null, 0, 0);
            }

            $this->log('info', 'Link_Whisper_Bridge: LW suggestion engine returned', [
                'post_id' => $post_id,
                'phrase_count' => is_array($phrases) ? count($phrases) : 'not_array',
                'phrases_type' => gettype($phrases),
            ]);

            if (empty($phrases) || !is_array($phrases)) {
                $this->log('info', 'Link_Whisper_Bridge: no suggestions returned by LW for this post', [
                    'post_id'  => $post_id,
                    'use_ai'   => $use_ai,
                    'zone_len' => mb_strlen($zone_content),
                ]);
                return $content;
            }

            // 5. Apply suggestions.
            $inserted = 0;
            $used_urls = [];
            $applied = [];

            $this->log('info', 'Link_Whisper_Bridge: starting suggestion application loop', [
                'post_id' => $post_id,
                'max_links' => $max_links,
                'total_phrases' => count($phrases),
            ]);

            foreach ($phrases as $phrase_idx => $phrase) {
                if ($inserted >= $max_links) {
                    $this->log('info', 'Link_Whisper_Bridge: max_links reached, breaking', ['post_id' => $post_id, 'inserted' => $inserted]);
                    break;
                }
                if (empty($phrase->suggestions) || !is_array($phrase->suggestions)) {
                    $this->log('info', 'Link_Whisper_Bridge: phrase has no suggestions, skipping', ['post_id' => $post_id, 'phrase_idx' => $phrase_idx]);
                    continue;
                }

                $sentence_text = trim(strip_tags($phrase->text ?? ''));
                if ($sentence_text === '' || mb_strlen($sentence_text) < 10) {
                    $this->log('info', 'Link_Whisper_Bridge: sentence too short/empty, skipping', ['post_id' => $post_id, 'phrase_idx' => $phrase_idx, 'sentence_len' => mb_strlen($sentence_text)]);
                    continue;
                }

                $this->log('info', 'Link_Whisper_Bridge: processing phrase', [
                    'post_id' => $post_id,
                    'phrase_idx' => $phrase_idx,
                    'sentence' => mb_substr($sentence_text, 0, 100),
                    'suggestion_count' => count($phrase->suggestions),
                ]);

                foreach ($phrase->suggestions as $sugg_idx => $suggestion) {
                    if ($inserted >= $max_links) {
                        break;
                    }

                    $target_post = $suggestion->post ?? null;
                    if (!$target_post || empty($target_post->id)) {
                        $this->log('info', 'Link_Whisper_Bridge: suggestion missing target post', ['post_id' => $post_id, 'phrase_idx' => $phrase_idx, 'sugg_idx' => $sugg_idx]);
                        continue;
                    }
                    $tid = (int) $target_post->id;
                    if ($tid === $post_id) {
                        $this->log('info', 'Link_Whisper_Bridge: suggestion targets same post, skipping', ['post_id' => $post_id, 'tid' => $tid]);
                        continue;
                    }

                    $url = '';
                    if (method_exists($target_post, 'getViewLink')) {
                        $url = $target_post->getViewLink();
                    }
                    if (empty($url)) {
                        $url = (string) get_permalink($tid);
                    }
                    if (empty($url)) {
                        $this->log('info', 'Link_Whisper_Bridge: could not get URL for target', ['post_id' => $post_id, 'tid' => $tid]);
                        continue;
                    }

                    if (strpos($content, $url) !== false) {
                        $this->log('info', 'Link_Whisper_Bridge: URL already in content, skipping', ['post_id' => $post_id, 'url' => $url]);
                        continue;
                    }
                    if (isset($used_urls[$url])) {
                        $this->log('info', 'Link_Whisper_Bridge: URL already used, skipping', ['post_id' => $post_id, 'url' => $url]);
                        continue;
                    }

                    // Map sentence to a specific linkable block.
                    $block_key = $this->find_block_for_sentence($blocks, $sentence_text);
                    if ($block_key === null) {
                        $this->log('info', 'Link_Whisper_Bridge: find_block_for_sentence returned null', [
                            'post_id' => $post_id,
                            'sentence' => mb_substr($sentence_text, 0, 100),
                            'linkable_blocks' => array_values(array_filter(array_map(function($b) { return $this->is_block_linkable($b) ? $b['name'] : null; }, $blocks))),
                        ]);
                        continue;
                    }

                    $words = $suggestion->words ?? [];
                    if (empty($words) || !is_array($words)) {
                        $this->log('info', 'Link_Whisper_Bridge: suggestion has no words', ['post_id' => $post_id, 'phrase_idx' => $phrase_idx, 'sugg_idx' => $sugg_idx]);
                        continue;
                    }
                    $anchor = $this->compute_anchor($sentence_text, $words);
                    if ($anchor === '') {
                        $this->log('info', 'Link_Whisper_Bridge: compute_anchor returned empty', ['post_id' => $post_id, 'sentence' => mb_substr($sentence_text, 0, 100), 'words' => $words]);
                        continue;
                    }
                    if (!$this->is_valid_anchor($anchor)) {
                        $this->log('info', 'Link_Whisper_Bridge: anchor not valid', ['post_id' => $post_id, 'anchor' => $anchor]);
                        continue;
                    }

                    $modified = $this->insert_anchor_into_html(
                        $blocks[$block_key]['inner_html'],
                        $anchor,
                        $url
                    );
                    if ($modified === null) {
                        $this->log('info', 'Link_Whisper_Bridge: insert_anchor_into_html returned null', ['post_id' => $post_id, 'anchor' => $anchor, 'block' => $blocks[$block_key]['name']]);
                        continue;
                    }

                    $blocks[$block_key]['inner_html'] = $modified;
                    $blocks[$block_key]['touched'] = true;
                    $used_urls[$url] = true;
                    $inserted++;
                    $applied[] = [
                        'target_id' => $tid,
                        'anchor'    => $anchor,
                        'url'       => $url,
                        'block'     => $blocks[$block_key]['name'],
                    ];

                    $this->log('info', 'Link_Whisper_Bridge: LINK INSERTED', [
                        'post_id' => $post_id,
                        'inserted' => $inserted,
                        'anchor' => $anchor,
                        'url' => $url,
                        'target_id' => $tid,
                        'block' => $blocks[$block_key]['name'],
                    ]);

                    break; // One link per sentence.
                }
            }

            if ($inserted === 0) {
                $this->log('info', 'Link_Whisper_Bridge: suggestions returned but no anchors inserted (no word matches in linkable blocks)', [
                    'post_id' => $post_id,
                ]);
                return $content;
            }

            // 6. Reassemble: re-serialize touched blocks and substr_replace them in.
            $this->log('info', 'Link_Whisper_Bridge: reassembling blocks', ['post_id' => $post_id, 'touched_count' => count(array_filter($blocks, function($b) { return !empty($b['touched']); }))]);
            $new_content = $this->reassemble_blocks($content, $blocks);

            // 7. Persist LW-owned meta for Reports.
            $this->store_link_meta($post_id, $applied);

            $this->log('info', 'Link_Whisper_Bridge: injected links', [
                'post_id'     => $post_id,
                'inserted'    => $inserted,
                'used_blocks' => array_values(array_unique(array_column($applied, 'block'))),
            ]);

            return $new_content;
        } catch (\Throwable $e) {
            // NEVER let the bridge break publishing.
            // Persist per-post error meta so the admin UI/DB shows WHY this post
            // was skipped, not just a log line.
            update_post_meta($post_id, self::ERROR_META_KEY, $e->getMessage());
            $this->log('warning', 'Link_Whisper_Bridge: injection failed, returning original', [
                'post_id' => $post_id,
                'message' => $e->getMessage(),
            ]);
            return $content;
        }
    }

    /**
     * Parse a flat sequence of top-level Gutenberg block comments into
     * an array of block descriptors. Only depth-0 (top-level) blocks are
     * emitted — nested blocks inside groups (e.g. the inner paragraph of
     * a callout group) are intentionally NOT extracted. This guarantees
     * the bridge never inserts links inside callouts, headings, or any
     * other wrapper group, even when those wrappers contain their own
     * paired inner blocks.
     *
     * @param string $content
     * @param bool   $skip_callouts
     * @return array<int, array{
     *     name: string, attrs: array, inner_html: string,
     *     start: int, end: int, touched: bool,
     *     skip: bool
     * }>
     */
    private function parse_blocks(string $content, bool $skip_callouts): array
    {
        $blocks = [];

        // Match either self-closing `wp:name` block (with trailing slash) or
        // a paired open/close comment pair. We use a single regex that
        // captures (a) the open comment, (b) optional inner HTML, and
        // (c) the close comment (if paired).
        $pattern = '/<!--\s*(\/)?wp:([a-z0-9_-]+(?:\/[a-z0-9_-]+)?)(?:\s+(\{[^}]*\}))?\s*(\/)?-->/';

        if (!preg_match_all($pattern, $content, $matches, PREG_OFFSET_CAPTURE)) {
            return [];
        }

        $n = count($matches[0]);
        // Stack of ['name', 'start', 'end', 'depth'].
        $open_stack = [];
        $depth      = 0;

        for ($i = 0; $i < $n; $i++) {
            $is_closer = ($matches[1][$i][0] !== '');
            $name      = $matches[2][$i][0];
            $attrs_raw = $matches[3][$i][0] ?? '';
            $is_void   = ($matches[4][$i][0] === '/');
            $match_str = $matches[0][$i][0];
            $offset    = $matches[0][$i][1];

            if ($is_closer) {
                // Pop the matching opener (LIFO).
                for ($j = count($open_stack) - 1; $j >= 0; $j--) {
                    if ($open_stack[$j]['name'] === $name) {
                        $opener = $open_stack[$j];
                        $was_depth_zero = ((int) $opener['depth'] === 0);
                        // Closer comment carries no attrs; use the opener's attrs
                        // (which were captured when the opener was pushed).
                        $opener_attrs = isset($opener['attrs']) ? $opener['attrs'] : [];
                        array_splice($open_stack, $j, 1);
                        // Always decrement depth when a paired block closes,
                        // whether it was at depth 0 or nested.
                        $depth = max(0, $depth - 1);

                        if ($was_depth_zero) {
                            $open_end = $opener['end'];
                            $close_start = $offset;
                            $inner_html = substr($content, $open_end, $close_start - $open_end);

                            $is_callout = $this->block_is_callout($name, $opener_attrs);

                            $blocks[] = [
                                'name'       => $name,
                                'attrs'      => $opener_attrs,
                                'inner_html' => $inner_html,
                                'start'      => $opener['start'],
                                'end'        => $offset + strlen($match_str),
                                'touched'    => false,
                                'skip'       => ($skip_callouts && $is_callout),
                            ];
                        }
                        // else: closer for a nested block we never tracked as a
                        // top-level descriptor; we already decremented depth above.
                        break;
                    }
                }
                continue;
            }

            if ($is_void) {
                // Self-closing block. Only emit if at depth 0.
                if ($depth === 0) {
                    $blocks[] = [
                        'name'       => $name,
                        'attrs'      => $this->decode_attrs($attrs_raw),
                        'inner_html' => '',
                        'start'      => $offset,
                        'end'        => $offset + strlen($match_str),
                        'touched'    => false,
                        'skip'       => false,
                    ];
                }
                continue;
            }

            // Opener. Push to stack with its captured attrs so the matching
            // closer (which carries no attrs) can find them.
            $opener_attrs = $this->decode_attrs($attrs_raw);
            $open_stack[] = [
                'name'  => $name,
                'start' => $offset,
                'end'   => $offset + strlen($match_str),
                'depth' => $depth,
                'attrs' => $opener_attrs,
            ];
            $depth++;
        }

        return $blocks;
    }

    /**
     * Best-effort JSON decode of a block's attribute literal.
     *
     * @param string $raw
     * @return array
     */
    private function decode_attrs(string $raw): array
    {
        $raw = trim($raw);
        if ($raw === '') {
            return [];
        }
        $decoded = json_decode($raw, true);
        return is_array($decoded) ? $decoded : [];
    }

    /**
     * Determine whether a block is the editorial callout we want to skip.
     * Per Content_Schema, callouts render as core/group with className=dit-ts-callout.
     */
    private function block_is_callout(string $name, array $attrs): bool
    {
        if ($this->block_base_name($name) !== 'group') {
            return false;
        }
        $classes = (string) ($attrs['className'] ?? '');
        if ($classes !== '' && stripos($classes, 'dit-ts-callout') !== false) {
            return true;
        }
        return false;
    }

    /**
     * Is this block one LW should see and we should insert into?
     */
    private function is_block_linkable(array $block): bool
    {
        if (!empty($block['skip'])) {
            return false;
        }
        $name = $this->block_base_name($block['name']);
        if (in_array($name, self::LINKABLE_BLOCKS, true)) {
            return mb_strlen(trim($block['inner_html'])) >= self::MIN_BLOCK_INNER_LEN;
        }
        if (in_array($name, self::LINKABLE_HEADINGS, true)) {
            $level = (int) ($block['attrs']['level'] ?? 0);
            if ($level === 2 || $level === 3) {
                return mb_strlen(trim(strip_tags($block['inner_html']))) >= self::MIN_BLOCK_INNER_LEN;
            }
        }
        return false;
    }

    /**
     * Normalize a parsed block name to its short (namespace-free) form.
     * WP core blocks are serialized either as `wp:paragraph` (editor-normalized,
     * the canonical DB form) or `wp:core/paragraph` (raw serialize_block output).
     * Consumers must accept both.
     */
    private function block_base_name(string $name): string
    {
        $pos = strrpos($name, '/');
        return $pos === false ? $name : substr($name, $pos + 1);
    }

    /**
     * Map an LW-returned sentence back to the block whose inner HTML
     * contains it. Falls back to a fuzzy 8-word prefix match.
     */
    private function find_block_for_sentence(array $blocks, string $sentence): ?int
    {
        $norm_sentence = preg_replace('/\s+/', ' ', trim(mb_strtolower($sentence)));
        if ($norm_sentence === '') {
            return null;
        }

        $sent_words = explode(' ', $norm_sentence);
        $fuzzy_prefix = implode(' ', array_slice($sent_words, 0, min(8, count($sent_words))));

        foreach ($blocks as $key => $block) {
            if (!$this->is_block_linkable($block)) {
                continue;
            }
            $plain = mb_strtolower(wp_strip_all_tags(
                html_entity_decode($block['inner_html'], ENT_QUOTES, 'UTF-8')
            ));
            $plain = preg_replace('/\s+/', ' ', trim($plain));
            if ($plain === '') {
                continue;
            }
            if (strpos($plain, $norm_sentence) !== false) {
                return $key;
            }
            if ($fuzzy_prefix !== '' && mb_strlen($fuzzy_prefix) >= 20 && strpos($plain, $fuzzy_prefix) !== false) {
                return $key;
            }
        }
        return null;
    }

    /**
     * Derive multi-word anchor text using LW's own getSuggestionAnchorWords().
     * Ref plan §2.5.
     */
    private function compute_anchor(string $sentence, array $suggestion_words): string
    {
        $sentence_clean = trim(preg_replace('/\s+/', ' ', $sentence));
        $words_real = array_map(
            function ($w) { return trim($w, "():'\""); },
            explode(' ', $sentence_clean)
        );
        if (empty($words_real)) {
            return '';
        }

        // Build stemmed array preserving keys (position indexes).
        $stemmed = $words_real;
        foreach ($stemmed as $key => $value) {
            $value = trim($value, '.,;:!?()[]{}"\'-');
            if (mb_strlen($value) < 2) {
                unset($stemmed[$key]);
                continue;
            }
            $stemmed[$key] = \Wpil_Stemmer::Stem(mb_strtolower(strip_tags($value)));
        }
        if (empty($stemmed)) {
            return '';
        }

        if (!method_exists('Wpil_Suggestion', 'getSuggestionAnchorWords')) {
            return '';
        }
        $indexes = \Wpil_Suggestion::getSuggestionAnchorWords($stemmed, $suggestion_words, true);
        if (empty($indexes) || !isset($indexes['min'], $indexes['max'])) {
            return '';
        }
        $min = (int) $indexes['min'];
        $max = (int) $indexes['max'];
        $span = $max - $min + 1;

        $lw_min = $this->get_min_anchor_length();
        $lw_max = $this->get_max_anchor_length();
        if ($span < $lw_min) {
            return '';
        }
        if ($lw_max > 0 && $span > $lw_max) {
            return '';
        }

        $parts = [];
        for ($i = $min; $i <= $max; $i++) {
            if (isset($words_real[$i])) {
                $parts[] = $words_real[$i];
            }
        }
        if (empty($parts)) {
            return '';
        }
        return trim(implode(' ', $parts));
    }

    private function get_min_anchor_length(): int
    {
        if (method_exists('Wpil_Suggestion', 'get_min_anchor_length')) {
            return (int) \Wpil_Suggestion::get_min_anchor_length();
        }
        if (class_exists('Wpil_Settings') && method_exists('Wpil_Settings', 'getSuggestionMinAnchorSize')) {
            return (int) \Wpil_Settings::getSuggestionMinAnchorSize();
        }
        return 1;
    }

    private function get_max_anchor_length(): int
    {
        if (method_exists('Wpil_Suggestion', 'get_max_anchor_length')) {
            return (int) \Wpil_Suggestion::get_max_anchor_length();
        }
        if (class_exists('Wpil_Settings') && method_exists('Wpil_Settings', 'getSuggestionMaxAnchorSize')) {
            return (int) \Wpil_Settings::getSuggestionMaxAnchorSize();
        }
        return 5;
    }

    /**
     * Reject anchors that are entirely generic single words.
     * Ref plan §5.
     */
    private function is_valid_anchor(string $anchor): bool
    {
        if (mb_strlen($anchor) < 3) {
            return false;
        }
        $generic = [
            'windows', 'macos', 'linux', 'android', 'ios',
            'download', 'free', 'software', 'app', 'tool',
            'feature', 'settings', 'file', 'version', 'update',
        ];
        $words = preg_split('/\s+/', mb_strtolower($anchor));
        $non_generic = array_filter($words, function ($w) use ($generic) {
            return !in_array($w, $generic, true);
        });
        if (empty($non_generic)) {
            return false;
        }
        if (count($words) === 1) {
            // Single-word anchors must be Capitalized or ALL CAPS to count as proper noun.
            if ($anchor !== ucfirst($anchor) && $anchor !== mb_strtoupper($anchor)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Insert a <a> tag around the first occurrence of $anchor in $html.
     * Ref plan §2.6, with "already inside <a>" guard.
     */
    private function insert_anchor_into_html(string $html, string $anchor, string $url): ?string
    {
        $pos = mb_stripos($html, $anchor);
        if ($pos === false) {
            return null;
        }

        $before = mb_substr($html, 0, $pos);
        if (preg_match('/<a\s[^>]*$/i', $before)) {
            return null;
        }

        $after = mb_substr($html, $pos);
        if (preg_match('/^' . preg_quote($anchor, '/') . '\s*<\/a>/i', $after)) {
            return null;
        }

        $actual = mb_substr($html, $pos, mb_strlen($anchor));
        $link   = '<a href="' . esc_url($url) . '">' . $actual . '</a>';

        return mb_substr($html, 0, $pos) . $link . mb_substr($html, $pos + mb_strlen($anchor));
    }

    /**
     * Re-serialize every touched block via WP's serialize_block() and
     * substr_replace the original markup. Untouched blocks are left
     * byte-for-byte identical.
     */
    private function reassemble_blocks(string $content, array $blocks): string
    {
        $touched = array_filter($blocks, function ($b) { return !empty($b['touched']); });
        if (empty($touched)) {
            return $content;
        }

        // Sort by start descending so substr_replace doesn't shift earlier offsets.
        usort($touched, function ($a, $b) {
            return $b['start'] <=> $a['start'];
        });

        foreach ($touched as $block) {
            $new_serialized = $this->serialize_block_safe($block['name'], $block['attrs'], $block['inner_html']);
            if ($new_serialized === '') {
                continue;
            }
            $len = $block['end'] - $block['start'];
            $content = substr_replace($content, $new_serialized, $block['start'], $len);
        }

        return $content;
    }

    /**
     * WP's serialize_block() needs (name, attrs, innerBlocks=[], innerHTML).
     * innerBlocks can't be reconstructed reliably from a flat parse, so we
     * fall back to the legacy string form (attrs + innerHTML concatenation)
     * if the block had no nested blocks.
     */
    private function serialize_block_safe(string $name, array $attrs, string $inner_html): string
    {
        if (function_exists('serialize_block')) {
            return (string) serialize_block([
                'blockName'    => $name,
                'attrs'        => $attrs,
                'innerBlocks'  => [],
                'innerHTML'    => $inner_html,
                'innerContent' => [$inner_html],
            ]);
        }
        // Fallback (should never run on modern WP).
        $attr_str = '';
        if (!empty($attrs) && function_exists('serialize_block_attributes')) {
            $attr_str = ' ' . serialize_block_attributes($attrs);
        }
        return "<!-- wp:{$name}{$attr_str} -->{$inner_html}<!-- /wp:{$name} -->";
    }

    /**
     * Persist LW-owned wpil_links meta so LW Reports sees the applied links.
     * Ref plan §2.8.
     */
    private function store_link_meta(int $post_id, array $applied): void
    {
        if (empty($applied)) {
            return;
        }
        if (!class_exists('Wpil_Toolbox') || !method_exists('Wpil_Toolbox', 'get_encoded_post_meta')) {
            return;
        }
        $existing = \Wpil_Toolbox::get_encoded_post_meta($post_id, 'wpil_links', true);
        if (!is_array($existing)) {
            $existing = [];
        }
        foreach ($applied as $link) {
            $existing[] = [
                'post_origin'          => 'internal',
                'site_url'             => '',
                'sentence'             => $link['anchor'],
                'sentence_with_anchor' => '<a href="' . esc_url($link['url']) . '">' . esc_html($link['anchor']) . '</a>',
                'id'                   => $link['target_id'],
                'type'                 => 'post',
            ];
        }
        if (method_exists('Wpil_Toolbox', 'update_encoded_post_meta')) {
            \Wpil_Toolbox::update_encoded_post_meta($post_id, 'wpil_links', $existing);
        }
    }

    /**
     * Thin logger wrapper. Tolerates a null logger (unit tests).
     */
    private function log(string $level, string $message, array $context = []): void
    {
        if (!$this->logger) {
            return;
        }
        if (method_exists($this->logger, $level)) {
            $this->logger->{$level}($message, $context);
            return;
        }
        if (method_exists($this->logger, 'info')) {
            $this->logger->info($message, $context);
        }
    }
}
