package com.snsaver.app
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import androidx.work.WorkManager
import com.snsaver.app.data.network.PlatformDetector
import com.snsaver.app.domain.model.DownloadItem
import com.snsaver.app.domain.repository.DownloadRepository
import com.snsaver.app.worker.DownloadWorker
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import javax.inject.Inject
@AndroidEntryPoint class ShareReceiverActivity:ComponentActivity(){
 @Inject lateinit var repo:DownloadRepository;@Inject lateinit var detector:PlatformDetector;@Inject lateinit var work:WorkManager
 override fun onCreate(state:Bundle?){super.onCreate(state);val url=detector.extract(intent?.getStringExtra(Intent.EXTRA_TEXT).orEmpty());if(intent?.action!=Intent.ACTION_SEND||url==null){finish();return};lifecycleScope.launch{val id=repo.add(DownloadItem(sourceUrl=url,platform=detector.detect(url)));val request=DownloadWorker.request(id);work.enqueue(request);repo.get(id)?.let{repo.update(it.copy(workerId=request.id.toString()))};startActivity(Intent(this@ShareReceiverActivity,MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));finish()}}
}
