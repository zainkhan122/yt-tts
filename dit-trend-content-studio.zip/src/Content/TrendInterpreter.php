<?php

/**
 * Topic Researcher Agent (Trend Interpreter)
 *
 * @package DIT_TrendStudio
 */

namespace DIT\TrendStudio\Content;

use DIT\TrendStudio\Sources\Google_Autocomplete;
use DIT\TrendStudio\Contracts\AIProviderInterface;
use DIT\TrendStudio\Infrastructure\Logger;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Orchestrates the "Deep Research" phase.
 * 1. Fetches raw data from Google Autocomplete.
 * 2. Uses AI to categorize and "Drill Down" into sub-niches.
 * 3. Detailed Strategy Generation for selected topics.
 */
class TrendInterpreter
{
    /**
     * @var AIProviderInterface
     */
    private $ai_client;

    /**
     * @var Google_Autocomplete
     */
    private $autocomplete;

    /**
     * @var Logger
     */
    private $logger;

    /**
     * Constructor
     *
     * @param AIProviderInterface $ai_client
     * @param Logger $logger
     */
    public function __construct(AIProviderInterface $ai_client, Logger $logger)
    {
        $this->ai_client = $ai_client;
        $this->logger = $logger;
        $this->autocomplete = new Google_Autocomplete();
    }

    /**
     * Step 1: Research and Expand a topic
     *
     * @param string $topic User input (e.g. "Fashion")
     * @return array Structured categories and niche ideas
     */
    public function research_topic(string $topic): array
    {
        // 1. Gather Data (Multi-context approach)
        $raw_suggestions = [];
        // @MODIFIED 2026-01-16 - Added 'rankable' for low-competition keyword discovery
        $contexts = ['general', 'trend', 'question', 'buying', 'rankable'];

        foreach ($contexts as $context) {
            $suggestions = $this->autocomplete->get_suggestions($topic, $context);
            // Limit each context to 20 to ensure even distribution across all 5 contexts
            $raw_suggestions = array_merge($raw_suggestions, array_slice($suggestions, 0, 20));
        }

        $raw_suggestions = array_unique($raw_suggestions);
        // Shuffle to randomize the order presented to AI (helps reduce recency bias and ensures diverse sample)
        shuffle($raw_suggestions);
        $raw_data_string = implode(", ", array_slice($raw_suggestions, 0, 100)); // Limit context window

        // 2. AI Processing (Drill-Down)
        $prompt = $this->build_expansion_prompt($topic, $raw_data_string);

        try {
            // using custom_json from AI_Client
            $result = $this->ai_client->generateCustomJson($prompt);
            // Gemini returns ['data' => ..., 'raw_request' => ..., 'raw_response' => ...]
            // Custom/DeepSeek/Groq/OpenRouter return the flat parsed array directly.
            // Mirror the defensive shape used by Research_Orchestrator::generate_side_band_json()
            // and Gap_Analyzer::analyze() so cross-provider fallback responses are not discarded.
            $data = $result['data'] ?? $result;
            return is_array($data) ? $data : [];
        } catch (\DIT\TrendStudio\AI_Exception $e) {
            $this->logger->error("Topic Research Failed (AI): " . $e->getMessage());
            throw $e; // Re-throw so caller's fallback chain (Topic_Research_Admin etc.) can operate
        } catch (\Exception $e) {
            $this->logger->error("Topic Research Failed: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Step 2: Generate Strategy Blueprint for a selected niche
     *
     * @param array $niche_data Data from step 1 selection
     * @return array Strategy Blueprint Data Array
     */
    public function generate_strategy(array $niche_data): array
    {
        $topic = $niche_data['title'] ?? '';
        $intent = $niche_data['intent'] ?? 'mixed';
        $category = $niche_data['category'] ?? 'General';

        $prompt = $this->build_strategy_prompt($topic, $intent, $category);

        try {
            $this->logger->info("Strategy Prompt: " . $prompt);
            $result = $this->ai_client->generateCustomJson($prompt);

            // Log raw AI response for debugging
            $this->logger->info("Strategy AI Result: " . print_r($result, true));

            // Gemini returns ['data' => ..., 'raw_request' => ..., 'raw_response' => ...]
            // Custom/DeepSeek/Groq/OpenRouter return the flat parsed array directly.
            // Mirror the defensive shape used by Research_Orchestrator and Gap_Analyzer
            // so cross-provider fallback responses are not silently discarded (which
            // falsely presents fallback providers as "exhausted" and forces Gemini reuse).
            $data = $result['data'] ?? $result;
            return is_array($data) ? $data : [];
        } catch (\DIT\TrendStudio\AI_Exception $e) {
            $this->logger->error("Strategy Generation Failed (AI): " . $e->getMessage());
            throw $e;
        } catch (\Exception $e) {
            $this->logger->error("Strategy Generation Failed: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Construct Prompt 1: Topic Expansion
     */
    private function build_expansion_prompt(string $topic, string $raw_data): string
    {
        $current_year = date('Y');
        return <<<PROMPT
You are an Expert Editorial Strategist.
Task: Analyze real-time search data for the topic "{$topic}" and organize it into high-potential content buckets.

input_data: "{$raw_data}"

Instructions:
1. Identify 3-5 major sub-categories (e.g., if topic is "Fashion", categories could be "Ladies", "Mens", "Sub-culture specific").
2. Under each category, suggest 2-3 specific "Drill-down" niche stories that are trending or high-value.
3. Assign a "Trend Context" (Why is this hot now?).

Output ONLY valid JSON structure (Strictly NO markdown formatting or backticks):
{
    "categories": [
        {
            "name": "Category Name",
            "ideas": [
                {
                    "title": "Specific Niche Title (e.g., Sustainable Office Wear {$current_year})",
                    "intent": "commercial|informational|mixed",
                    "trend_context": "Reason for popularity",
                    "search_volume_proxy": "high|medium"
                }
            ]
        }
    ]
}
PROMPT;
    }

    /**
     * Construct Prompt 2: Strategy Blueprint
     */
    private function build_strategy_prompt(string $topic, string $intent, string $category): string
    {
        // @MODIFIED 2026-01-16 - Added Opportunity Score, Editorial Persona, and Secondary Keywords
        return <<<PROMPT
You are an Elite Content Architect & SEO Strategist.
Task: Create a comprehensive "Article Strategy Blueprint" for the topic: "{$topic}".
Context: Category: {$category}, Intent: {$intent}.

CRITICAL INSTRUCTION: Assess the "Opportunity Score" based on:
- **High Opportunity:** Topic is specific (long-tail), targets a pain point, or has "problem/alternative/beginner" framing.
- **Medium Opportunity:** Topic is moderately specific but may have some competition.
- **Low Opportunity:** Topic is generic (e.g., "Best Laptop"), highly competitive, dominated by major publishers.

For `editorial_persona`, you MUST choose ONLY from these exact values:
- "enthusiast" (Excited & Positive)
- "skeptic" (Critical & Questioning)
- "analyst" (Data-Driven & Objective)
- "neutral" (Balanced & Informative)
- "contrarian" (Challenging Norms)

For `secondary_keywords`, provide 3-5 **long-tail, rankable** keyword phrases (not single words). Focus on specific queries a beginner or problem-solver might search.

Output ONLY valid JSON structure (Strictly NO markdown formatting or backticks):
{
    "idea_title": "A viral, high-CTR headline",
    "primary_keyword": "The best focused keyword for SEO",
    "secondary_keywords": ["long tail keyword 1", "long tail keyword 2", "long tail keyword 3"],
    "search_intent": "{$intent}",
    "editorial_persona": "enthusiast|skeptic|analyst|neutral|contrarian",
    "target_audience": "Specific persona (age, role, pain points)",
    "opportunity_score": "high|medium|low",
    "opportunity_reason": "Brief explanation why this score was assigned",
    "hooks": [
        "Hook 1 (Controversial or surprising fact)",
        "Hook 2 (Relatable pain point)"
    ],
    "structure_blueprint": {
        "type": "guide|listicle|analysis|review",
        "tone": "authority_level (e.g., Professional yet witty)",
        "required_sections": {
            "Section Name 1": "What to cover specifically...",
            "Section Name 2": "What to cover specifically..."
        }
    }
}
PROMPT;
    }
}
