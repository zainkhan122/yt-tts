<?php
namespace AiSocialCollage\Services;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ContentCleaner {
    
    public static function clean( $html ) {
        if ( empty( $html ) ) {
            return '';
        }

        libxml_use_internal_errors( true );
        $dom = new \DOMDocument();
        $loaded = @$dom->loadHTML( self::utf8_to_html_entities( $html ), LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );

        if ( ! $loaded ) {
            libxml_clear_errors();
            return wp_kses_post( wp_unslash( $html ) );
        }

        $tags_to_remove = [ 'script', 'style', 'nav', 'footer', 'aside', 'iframe', 'header', 'form', 'button', 'input', 'select' ];
        foreach ( $tags_to_remove as $tag ) {
            $elements = $dom->getElementsByTagName( $tag );
            for ( $i = $elements->length - 1; $i >= 0; $i-- ) {
                $node = $elements->item( $i );
                if ( $node && $node->parentNode ) {
                    $node->parentNode->removeChild( $node );
                }
            }
        }

        $cleaned_html = $dom->saveHTML();
        libxml_clear_errors();

		return wp_kses_post( wp_unslash( $cleaned_html ) );
	}

	private static function utf8_to_html_entities( $string ) {
		if ( PHP_VERSION_ID >= 80200 ) {
			$convmap = [ 0x80, 0x10FFFF, 0, 0xFFFFF ];
			return mb_encode_numericentity( $string, $convmap, 'UTF-8' );
		}
		return mb_convert_encoding( $string, 'HTML-ENTITIES', 'UTF-8' );
	}
}