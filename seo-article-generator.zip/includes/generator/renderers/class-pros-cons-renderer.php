<?php

namespace SEO_Article_Generator\Generator\Renderers;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Handles rendering of Pros & Cons blocks
 */
class Pros_Cons_Renderer
{
    use \SEO_Article_Generator\Traits\Markdown_Processor;

    /**
     * Render Pros & Cons as a Gutenberg block array
     *
     * @MODIFIED 2026-03-26: Block-First Architecture
     *
     * @param array  $pros_cons Pros and cons data
     * @param string $heading   Section heading
     * @param string $anchor_id Section anchor ID
     * @return array Block array
     */
    public function render_blocks($pros_cons, $heading = 'Pros & Cons', $anchor_id = 'pros-cons')
    {
        if (empty($pros_cons) || !is_array($pros_cons)) {
            return array();
        }

        $pros = isset($pros_cons['pros']) && is_array($pros_cons['pros']) ? $pros_cons['pros'] : array();
        $cons = isset($pros_cons['cons']) && is_array($pros_cons['cons']) ? $pros_cons['cons'] : array();

        $max_rows = max(count($pros), count($cons));
        if ($max_rows === 0) {
            return array();
        }

        $blocks = array();
        
        // Use Content_Formatter helper if available via static or pass-thru
        // Since we don't want to create cross-dependency cycles, we build the blocks manually here
        // matching the Content_Formatter::make_block pattern.
        
        // Heading
        $blocks[] = array(
            'blockName'    => 'core/heading',
            'attrs'        => array('level' => 2, 'anchor' => $anchor_id),
            'innerHTML'    => '<h2 class="wp-block-heading" id="' . \esc_attr($anchor_id) . '">' . \esc_html($heading) . '</h2>',
            'innerContent' => array('<h2 class="wp-block-heading" id="' . \esc_attr($anchor_id) . '">' . \esc_html($heading) . '</h2>'),
        );

        // Table logic
        $thead = '<thead><tr><th>Pros</th><th>Cons</th></tr></thead>';
        $tbody = '<tbody>';
        for ($i = 0; $i < $max_rows; $i++) {
            $pro_text = isset($pros[$i]) ? $pros[$i] : '';
            $con_text = isset($cons[$i]) ? $cons[$i] : '';
            $pro_cell = $pro_text !== '' ? \wp_kses_post(self::process_markdown($pro_text)) : '';
            $con_cell = $con_text !== '' ? \wp_kses_post(self::process_markdown($con_text)) : '';
            $tbody .= '<tr><td>' . $pro_cell . '</td><td>' . $con_cell . '</td></tr>';
        }
        $tbody .= '</tbody>';
        $table_html = '<figure class="wp-block-table is-style-stripes"><table>' . $thead . $tbody . '</table></figure>';

        $blocks[] = array(
            'blockName'    => 'core/table',
            'attrs'        => array('hasFixedLayout' => false, 'className' => 'is-style-stripes'),
            'innerHTML'    => $table_html,
            'innerContent' => array($table_html),
        );

        return $blocks;
    }

    public function render($pros_cons, $heading = 'Pros & Cons', $anchor_id = 'pros-cons')
    {
        $blocks = $this->render_blocks($pros_cons, $heading, $anchor_id);
        return \serialize_blocks($blocks);
    }
}
