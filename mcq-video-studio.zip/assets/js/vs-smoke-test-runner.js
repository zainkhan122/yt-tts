/**
 * Video Studio Smoke Test Runner
 *
 * Handles logic for the System Health > Server Smoke Test tab.
 * Extracted from settings.js
 *
 * @package MCQ_Video_Studio
 * @since 1.2.0
 */

(function ($) {
    "use strict";

    // Note: We use mcqvsSettings global for nonce/ajaxUrl, 
    // or we need to ensure localizer provides it here.
    // In previous structure it relied on mcqvs-settings script localization.

    // Checking if mcqvsSettings exists, otherwise might need a fallback.
    // Ideally, the PHP enqueue_assets for system health page should localize 'mcqvsSystemHealth' 
    // but to keep it simple we can reuse or check context. 
    // For now let's assume we'll localize 'mcqvsSystemHealth' in class-vs-core.php

    var config = window.mcqvsSystemHealth || window.mcqvsSettings || {};

    /**
     * Run comprehensive smoke test.
     */
    var smokeTestResults = null;

    $("#mcqvs-run-smoke-test").on("click", function () {
        var $btn = $(this);
        var $progress = $("#mcqvs-smoke-test-progress");
        var $progressFill = $("#mcqvs-progress-fill");
        var $progressText = $("#mcqvs-progress-text");
        var $results = $("#mcqvs-smoke-test-results");
        var $exportBtn = $("#mcqvs-export-results");

        $btn.prop("disabled", true);
        $progress.show();
        $results.hide().empty();
        $exportBtn.hide();
        $progressFill.css("width", "0%");
        $progressText.text("Running comprehensive tests...");

        console.log("[MCQVS Smoke Test] Starting comprehensive tests...");
        if (window.mcqvsLogger) {
            mcqvsLogger.log("info", "Smoke Test: User initiated comprehensive tests.");
        }

        $.post(
            config.ajaxUrl,
            {
                action: "mcqvs_run_smoke_test",
                nonce: config.nonce,
            },
            function (response) {
                $btn.prop("disabled", false);
                $progressFill.css("width", "100%");
                $progressText.text("Tests complete!");

                if (response.success) {
                    console.log("[MCQVS Smoke Test] Tests completed successfully.", response.data);
                    if (window.mcqvsLogger) {
                        mcqvsLogger.log("info", "Smoke Test: Completed.", { summary: response.data.summary });
                    }
                    smokeTestResults = response.data;
                    displayResults(response.data);
                    $exportBtn.show();
                } else {
                    console.error("[MCQVS Smoke Test] Tests failed:", response.data);
                    if (window.mcqvsLogger) {
                        mcqvsLogger.log("error", "Smoke Test: Failed.", { error: response.data });
                    }
                    $results.html(
                        '<div class="notice notice-error"><p>Error: ' +
                        (response.data || "Unknown error") +
                        "</p></div>"
                    );
                    $results.show();
                }

                setTimeout(function () {
                    $progress.hide();
                }, 1000);
            }
        ).fail(function (xhr, status, error) {
            console.error("[MCQVS Smoke Test] Network error:", error);
            if (window.mcqvsLogger) {
                mcqvsLogger.log("critical", "Smoke Test: Network error.", { error: error, status: status });
            }
            $btn.prop("disabled", false);
            $progress.hide();
            $results.html(
                '<div class="notice notice-error"><p>Network error occurred while running tests.</p></div>'
            );
            $results.show();
        });
    });

    /**
     * Display smoke test results.
     */
    function displayResults(data) {
        var $results = $("#mcqvs-smoke-test-results");
        var summary = data.summary;
        var results = data.results;

        var html = '<div class="mcqvs-test-summary">';
        html += "<h3>Test Summary</h3>";
        html += '<div class="summary-stats">';
        html +=
            '<div class="stat-item"><strong>Total Tests:</strong> ' +
            summary.total_tests +
            "</div>";
        html +=
            '<div class="stat-item success"><strong>Passed:</strong> ' +
            summary.total_passed +
            "</div>";
        html +=
            '<div class="stat-item error"><strong>Failed:</strong> ' +
            summary.total_failed +
            "</div>";
        html +=
            '<div class="stat-item"><strong>Pass Rate:</strong> ' +
            summary.pass_rate +
            "%</div>";
        html += "</div>";

        if (summary.overall_status === "pass") {
            html +=
                '<div class="notice notice-success"><p><strong>✅ All tests passed!</strong></p></div>';
        } else {
            html +=
                '<div class="notice notice-error"><p><strong>❌ Some tests failed. See details below.</strong></p></div>';
        }
        html += "</div>";

        // Display each category
        for (var category in results) {
            if (!results.hasOwnProperty(category)) continue;
            var categoryData = results[category];
            var hasFailures = categoryData.failed > 0;

            html += '<div class="mcqvs-test-category ' + (hasFailures ? "has-failures" : "") + '">';
            html += '<h4 class="category-header">';
            html +=
                '<span class="status-icon">' +
                (hasFailures ? "❌" : "✅") +
                "</span>";
            html += categoryData.category;
            html +=
                ' <span class="category-stats">(' +
                categoryData.passed +
                " passed, " +
                categoryData.failed +
                " failed)</span>";
            html += "</h4>";
            html += '<div class="category-tests">';

            categoryData.tests.forEach(function (test) {
                var statusClass = test.passed ? "test-pass" : "test-fail";
                var statusIcon = test.passed ? "✓" : "✗";
                if (test.skipped) {
                    statusClass = "test-skip";
                    statusIcon = "⊗";
                }

                html += '<div class="test-item ' + statusClass + '">';
                html += '<span class="test-status">' + statusIcon + "</span>";
                html += '<span class="test-name">' + escapeHtml(test.name) + "</span>";
                html +=
                    '<span class="test-message">' + escapeHtml(test.message) + "</span>";
                html += "</div>";
            });

            html += "</div></div>";
        }

        $results.html(html).show();
    }

    /**
     * Export smoke test results.
     */
    $("#mcqvs-export-results").on("click", function () {
        if (!smokeTestResults) {
            alert("No test results to export");
            return;
        }

        var format = "json";
        var content =
            format === "json"
                ? JSON.stringify(smokeTestResults, null, 2)
                : formatAsText(smokeTestResults);
        var filename =
            "smoke-test-results-" +
            new Date().toISOString().slice(0, 10) +
            "." +
            (format === "json" ? "json" : "txt");

        var blob = new Blob([content], {
            type: format === "json" ? "application/json" : "text/plain",
        });
        var url = URL.createObjectURL(blob);
        var a = document.createElement("a");
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    });

    /**
     * Format results as text.
     */
    function formatAsText(data) {
        var text = "=== MCQ Video Studio Comprehensive Smoke Test ===\n\n";
        text +=
            "Date: " + new Date().toISOString() + "\n";
        text += "Total Tests: " + data.summary.total_tests + "\n";
        text += "Passed: " + data.summary.total_passed + "\n";
        text += "Failed: " + data.summary.total_failed + "\n";
        text += "Pass Rate: " + data.summary.pass_rate + "%\n\n";

        for (var category in data.results) {
            if (!data.results.hasOwnProperty(category)) continue;
            var categoryData = data.results[category];
            text += "[" + categoryData.category + "]\n";
            text +=
                "Passed: " +
                categoryData.passed +
                " | Failed: " +
                categoryData.failed +
                "\n\n";

            categoryData.tests.forEach(function (test) {
                var status = test.passed ? "[PASS]" : test.skipped ? "[SKIP]" : "[FAIL]";
                text +=
                    "  " +
                    status +
                    " " +
                    test.name +
                    " - " +
                    test.message +
                    "\n";
            });
            text += "\n";
        }

        return text;
    }

    /**
     * Escape HTML for safe display.
     */
    function escapeHtml(text) {
        if (!text) return "";
        var map = {
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            '"': "&quot;",
            "'": "&#039;",
        };
        return String(text).replace(/[&<>"']/g, function (m) {
            return map[m];
        });
    }
})(jQuery);
