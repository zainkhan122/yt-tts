<?php

namespace DIT\TrendStudio\Database;

class Queue_Table
{
    const TABLE_VERSION = '1.2';
    const OPTION_KEY    = 'dit_ts_queue_table_version';

    public static function get_table_name(): string
    {
        global $wpdb;
        return $wpdb->prefix . 'dit_ts_social_queue';
    }

    public static function install(): void
    {
        global $wpdb;
        $table = self::get_table_name();

        // Check if table exists
        $table_exists = (bool) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s",
            $table
        ));

        if (!$table_exists) {
            $charset_collate = $wpdb->get_charset_collate();
            $sql = "CREATE TABLE {$table} (
                id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                post_id       BIGINT UNSIGNED NOT NULL,
                share_slot    TINYINT UNSIGNED NOT NULL DEFAULT 1,
                image_url     TEXT NOT NULL,
                message       TEXT NOT NULL,
                networks      VARCHAR(512) NOT NULL DEFAULT '',
                scheduled_at  DATETIME NOT NULL,
                status        ENUM('pending','processing','sent','failed') NOT NULL DEFAULT 'pending',
                attempts      TINYINT UNSIGNED NOT NULL DEFAULT 0,
                last_error    TEXT NULL,
                lock_token   VARCHAR(36) DEFAULT NULL,
                created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY   (id),
                INDEX idx_post      (post_id),
                INDEX idx_due       (scheduled_at, status),
                INDEX idx_slot      (post_id, share_slot),
                INDEX idx_lock_token (lock_token)
            ) {$charset_collate};";
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
            dbDelta($sql);
            update_option(self::OPTION_KEY, self::TABLE_VERSION);
            return;
        }

        // Schema migration: Add missing columns to existing table
        $has_lock_token = (bool) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND COLUMN_NAME = 'lock_token'",
            $table
        ));

        if (!$has_lock_token) {
            $wpdb->query("ALTER TABLE `{$table}` ADD COLUMN `lock_token` VARCHAR(36) DEFAULT NULL AFTER `last_error`");
        }

        // Add index if missing
        $index_exists = (bool) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND INDEX_NAME = 'idx_lock_token'",
            $table
        ));
        if (!$index_exists) {
            $wpdb->query("ALTER TABLE `{$table}` ADD INDEX `idx_lock_token` (`lock_token`)");
        }

        update_option(self::OPTION_KEY, self::TABLE_VERSION);
    }

    public static function uninstall(): void
    {
        global $wpdb;
        $wpdb->query('DROP TABLE IF EXISTS ' . self::get_table_name());
        delete_option(self::OPTION_KEY);
    }
}
