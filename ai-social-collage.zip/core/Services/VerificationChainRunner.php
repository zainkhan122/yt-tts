<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class VerificationChainRunner {

    private $providers = [];
    private $audit_log = [];

    public function __construct() {
        $this->initialize_providers();
    }

    private function initialize_providers(): void {
        $chain_config = get_option( Config::OPTION_VERIFICATION_PROVIDER_CHAIN, [] );
        if ( ! is_array( $chain_config ) ) {
            $chain_config = [];
        }

        foreach ( $chain_config as $provider_config ) {
            $provider_id = $provider_config['id'] ?? '';
            $api_key = $provider_config['api_key'] ?? '';
            $model = $provider_config['model'] ?? '';

            if ( empty( $provider_id ) || empty( $api_key ) ) {
                continue;
            }

            $this->providers[] = [
                'id' => $provider_id,
                'instance' => $this->create_provider( $provider_id, $api_key, $model ),
                'config' => $provider_config,
            ];
        }

        if ( empty( $this->providers ) ) {
            $this->providers = $this->get_default_chain();
        }
    }

    private function get_default_chain(): array {
        $chain = [];

        $hf_key = get_option( Config::OPTION_HF_API_KEY, '' );
        if ( ! empty( $hf_key ) ) {
            $chain[] = [
                'id' => Config::PROVIDER_VERIFICATION_HF,
                'instance' => new HuggingFaceVerificationProvider( $hf_key ),
                'config' => ['id' => Config::PROVIDER_VERIFICATION_HF],
            ];
        }

        $google_key = get_option( Config::OPTION_GOOGLE_VISION_KEY, '' );
        if ( ! empty( $google_key ) ) {
            $chain[] = [
                'id' => Config::PROVIDER_VERIFICATION_GOOGLE,
                'instance' => new GoogleVisionVerificationProvider( $google_key ),
                'config' => ['id' => Config::PROVIDER_VERIFICATION_GOOGLE],
            ];
        }

        return $chain;
    }

    private function create_provider( string $provider_id, string $api_key, string $model ) {
        switch ( $provider_id ) {
            case Config::PROVIDER_VERIFICATION_HF:
                return new HuggingFaceVerificationProvider( $api_key, $model );
            case Config::PROVIDER_VERIFICATION_GOOGLE:
                return new GoogleVisionVerificationProvider( $api_key );
            default:
                return null;
        }
    }

    public function verify_image( string $image_path, string $original_image_path, int $post_id = 0 ): array {
        $this->audit_log = [];
        $start_time = microtime( true );

        $this->log_audit( 'verification_started', [
            'image' => basename( $image_path ),
            'original' => basename( $original_image_path ),
            'post_id' => $post_id,
        ] );

        if ( empty( $this->providers ) ) {
            $this->log_audit( 'no_providers_configured', [] );
            return $this->build_result( false, [], 'No verification providers configured', 0.0 );
        }

        $combined_result = null;
        $errors = [];

        foreach ( $this->providers as $provider_entry ) {
            $provider = $provider_entry['instance'];
            $provider_id = $provider_entry['id'];

            if ( ! $provider->is_available() ) {
                $this->log_audit( 'provider_unavailable', [ 'provider' => $provider_id ] );
                continue;
            }

            try {
                $prompt = $this->build_verification_prompt( $original_image_path, $image_path );
                $options = [
                    'original_image' => $original_image_path,
                    'generated_image' => $image_path,
                ];

                $result = $provider->analyze_image( $image_path, $prompt, $options );
                $combined_result = $result;

                $this->log_audit( 'provider_success', [
                    'provider' => $provider_id,
                    'model' => $provider->get_model_name(),
                    'clean' => $result['clean'] ?? true,
                ] );

                if ( $result['clean'] ?? true ) {
                    break;
                }

            } catch ( \Throwable $e ) {
                $errors[] = $provider_id . ': ' . $e->getMessage();
                $this->log_audit( 'provider_error', [
                    'provider' => $provider_id,
                    'error' => $e->getMessage(),
                ] );
            }
        }

        $execution_time = microtime( true ) - $start_time;
        $this->log_audit( 'verification_completed', [
            'execution_time' => round( $execution_time, 3 ),
            'errors' => $errors,
        ] );

        if ( $combined_result === null ) {
            return $this->build_result( true, [], 'All providers failed, assuming clean', 0.0 );
        }

        return $this->build_result(
            (bool) ( $combined_result['clean'] ?? true ),
            (array) ( $combined_result['issues'] ?? [] ),
            $combined_result['details'] ?? '',
            (float) ( $combined_result['confidence'] ?? 0.5 ),
            $execution_time
        );
    }

    private function build_verification_prompt( string $original_path, string $generated_path ): string {
        return "Compare these two images. The first is the original source image, the second is a generated collage. 

CRITICAL: Check if the generated collage still contains:
1. Source logos/watermarks from the original
2. Text bands/headline bars from the original  
3. Any text overlays that should have been removed

If ANY such elements are visible in the generated image, the verification FAILED.

Return JSON: {\"clean\": true/false, \"issues\": [\"logo\", \"text_band\"], \"details\": \"explanation\"}";
    }

    private function build_result( bool $clean, array $issues, string $details, float $confidence = 0.0, float $execution_time = 0.0 ): array {
        return [
            'clean' => $clean,
            'issues' => $issues,
            'details' => $details,
            'confidence' => $confidence,
            'execution_time' => $execution_time,
            'audit_log' => $this->audit_log,
        ];
    }

    private function log_audit( string $action, array $data = [] ): void {
        $this->audit_log[] = [
            'timestamp' => current_time( 'mysql' ),
            'action' => $action,
            'data' => $data,
        ];
    }

    public function get_providers(): array {
        return $this->providers;
    }
}