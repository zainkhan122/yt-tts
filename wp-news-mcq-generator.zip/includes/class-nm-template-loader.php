<?php

/**
 * Template Loader for Virtual Pages AND CPTs
 *
 * @version 1.7
 *
 * @MODIFIED: Added "Dummy Post Injection" for /exam/ root.
 * This forces themes (like Astra) to render the content wrapper
 * instead of showing a 404/Sidebar-only layout.
 */

if (! defined('ABSPATH')) {
	exit;
}

class NM_Template_Loader
{


	private static $instance = null;

	public static function init()
	{
		if (self::$instance === null) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct()
	{
		add_action('init', array($this, 'register_virtual_pages'));
		add_filter('template_include', array($this, 'load_template'), 99);
		add_filter('body_class', array($this, 'add_body_classes'));
		add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));
	}

	/**
	 * Register virtual pages
	 */
	public function register_virtual_pages()
	{
		add_rewrite_rule('^mcq-login/?$', 'index.php?nm_login=1', 'top');
		add_rewrite_tag('%nm_login%', '1');

		add_rewrite_rule('^mcq-register/?$', 'index.php?nm_register=1', 'top');
		add_rewrite_tag('%nm_register%', '1');

		add_rewrite_rule('^mcq-reset-password/?$', 'index.php?nm_reset_password=1', 'top');
		add_rewrite_tag('%nm_reset_password%', '1');

		add_rewrite_rule('^leaderboard/?$', 'index.php?nm_leaderboard=1', 'top');
		add_rewrite_tag('%nm_leaderboard%', '1');
	}
	/**
	 * Load appropriate template for virtual pages AND CPTs
	 */
	public function load_template($template)
	{
		global $wp_query;

		// --- 1. Virtual Page Templates ---
		if (get_query_var('nm_login')) {
			if (is_user_logged_in()) {
				wp_redirect(home_url('/mcq-dashboard/'));
				exit;
			}
			return $this->get_template_path('login.php');
		}

		if (get_query_var('nm_register')) {
			if (is_user_logged_in()) {
				wp_redirect(home_url('/mcq-dashboard/'));
				exit;
			}
			return $this->get_template_path('register.php');
		}

		if (get_query_var('nm_reset_password')) {
			return $this->get_template_path('reset-password.php');
		}

		if (get_query_var('nm_leaderboard')) {
			return $this->get_template_path('leaderboard.php');
		}

		// --- 2. CPT Templates ---
		if (is_singular('mcq')) {
			return $this->get_template_path('single-mcq.php', $template);
		}
		// --- 3. Handle /exam/ Root Page ---
		// Use the shared MCQ archive layout for the Exam landing page (/exam/)
		if (is_page() && get_post_field('post_name', get_queried_object_id()) === 'exam') {
			// Ensure Astra treats this as a normal page with content
			$wp_query->is_404      = false;
			$wp_query->is_page     = true;
			$wp_query->is_singular = true;

			status_header(200);

			return $this->get_template_path('archive-mcq.php', $template);
		}
		// Topic and Exam TERM pages: /topic/{term} and /exam/{term} and /tag/{term}
		if (is_tax('topic') || is_tax('nm_exam') || is_tax('mcq_tag')) {
			return $this->get_template_path('taxonomy-topic.php', $template);
		}

		if (is_post_type_archive('mcq')) {
			return $this->get_template_path('archive-mcq.php', $template);
		}

		return $template;
	}

	/**
	 * Get template path (with theme override support)
	 */
	private function get_template_path($template_name, $fallback_template = null)
	{
		// Check theme directory first: /your-theme/nm-mcq/template-name.php
		$theme_template = locate_template('nm-mcq/' . $template_name);

		if ($theme_template) {
			return $theme_template;
		}

		// Use plugin template
		$plugin_template = NM_PLUGIN_DIR . 'templates/' . $template_name;

		if (file_exists($plugin_template)) {
			return $plugin_template;
		}

		// Fallback to the original WP template
		if ($fallback_template) {
			return $fallback_template;
		}

		// Final fallback for virtual pages
		return get_template_directory() . '/page.php';
	}

	/**
	 * Add body classes for virtual pages
	 */
	public function add_body_classes($classes)
	{
		if (get_query_var('nm_login')) {
			$classes[] = 'nm-login-page';
		}
		if (get_query_var('nm_register')) {
			$classes[] = 'nm-register-page';
		}
		if (get_query_var('nm_dashboard')) {
			$classes[] = 'nm-dashboard-page';
		}
		if (get_query_var('nm_leaderboard')) {
			$classes[] = 'nm-leaderboard-page';
		}
		if (get_query_var('nm_reset_password')) {
			$classes[] = 'nm-reset-password-page';
		}

		// Add a general class to all our virtual pages
		if (get_query_var('nm_login') || get_query_var('nm_register') || get_query_var('nm_reset_password')) {
			$classes[] = 'nm-auth-page';
		}

		return $classes;
	}

	/**
	 * Enqueue ALL frontend assets
	 */
	public function enqueue_assets()
	{

		$is_mcq_page = is_singular('mcq');
		// Topic and Exam TERM pages (taxonomy archives)
		$is_topic_page   = is_tax('topic') || is_tax('nm_exam') || is_tax('mcq_tag');
		$is_archive_page = is_post_type_archive('mcq');
		// Root Exam archive Page: /exam/
		$is_exam_root      = is_page() && get_post_field('post_name', get_queried_object_id()) === 'exam';
		$is_dashboard_page = (bool) get_query_var('nm_dashboard');

		// --- 1. Auth Pages (Login, Register, Reset) ---
		if (get_query_var('nm_login') || get_query_var('nm_register') || get_query_var('nm_reset_password')) {
			wp_enqueue_style('nm-auth-style', NM_PLUGIN_URL . 'assets/css/auth.css', array(), filemtime(NM_PLUGIN_PATH . 'assets/css/auth.css'));
		}

		// --- 2. Dashboard Page ---
		if ($is_dashboard_page) {
			wp_enqueue_media(); // For avatar uploads
			wp_enqueue_style('nm-dashboard-style', NM_PLUGIN_URL . 'assets/css/dashboard.css', array(), filemtime(NM_PLUGIN_PATH . 'assets/css/dashboard.css'));
			wp_enqueue_script('chart-js', 'https://cdn.jsdelivr.net/npm/chart.js', array(), '3.9.1', true);
			wp_enqueue_script('nm-dashboard-script', NM_PLUGIN_URL . 'assets/js/dashboard.js', array('jquery', 'chart-js'), filemtime(NM_PLUGIN_PATH . 'assets/js/dashboard.js'), true);

			wp_localize_script(
				'nm-dashboard-script',
				'dashboardConfig',
				array(
					'ajaxurl'   => admin_url('admin-ajax.php'),
					'ajaxNonce' => wp_create_nonce('nm_dashboard_ajax_nonce'),
					'apiUrl'    => rest_url('nm-mcq/v1/dashboard/'),
					'nonce'     => wp_create_nonce('wp_rest'),
					'userId'    => get_current_user_id(),
				)
			);
		}

		// --- 3. Leaderboard Page ---
		if (get_query_var('nm_leaderboard')) {
			wp_enqueue_style('nm-leaderboard-style', NM_PLUGIN_URL . 'assets/css/leaderboard.css', array(), filemtime(NM_PLUGIN_PATH . 'assets/css/leaderboard.css'));
			wp_enqueue_script('nm-leaderboard-script', NM_PLUGIN_URL . 'assets/js/leaderboard.js', array('jquery'), filemtime(NM_PLUGIN_PATH . 'assets/js/leaderboard.js'), true);
			wp_localize_script(
				'nm-leaderboard-script',
				'nmLeaderboard',
				array(
					'ajaxurl' => admin_url('admin-ajax.php'),
					'nonce'   => wp_create_nonce('nm_auth_nonce'),
				)
			);
		}

		// --- 4. CPT Templates & Dashboard (for Widgets) ---

		if ($is_mcq_page || $is_topic_page || $is_archive_page || $is_exam_root || $is_dashboard_page) {

			// Shared MCQ styles (cards, buttons, etc.)
			if (! wp_style_is('nm-mcq-styles', 'enqueued')) {
				wp_enqueue_style(
					'nm-mcq-styles',
					NM_PLUGIN_URL . 'assets/css/frontend.css',
					array(),
					filemtime(NM_PLUGIN_PATH . 'assets/css/frontend.css')
				);
			}

			// Shared MCQ scripts (same behaviour as [display_mcqs] homepage shortcode)
			if (! wp_script_is('nm-mcq-scripts', 'enqueued')) {
				wp_enqueue_script(
					'nm-mcq-scripts',
					NM_PLUGIN_URL . 'assets/js/frontend.js',
					array('jquery'),
					filemtime(NM_PLUGIN_PATH . 'assets/js/frontend.js'),
					true
				);

				wp_localize_script(
					'nm-mcq-scripts',
					'nm_mcq_ajax_object',
					array(
						'ajax_url'          => admin_url('admin-ajax.php'),
						'nonce'             => wp_create_nonce('nm_mcq_nonce'),
						'is_user_logged_in' => is_user_logged_in() ? 'yes' : 'no',
					)
				);
			}

			// Load specific stylesheets for each CPT template
			if ($is_mcq_page) {
				wp_enqueue_style(
					'nm-single-mcq',
					NM_PLUGIN_URL . 'assets/css/single-mcq.css',
					array(),
					filemtime(NM_PLUGIN_PATH . 'assets/css/single-mcq.css')
				);
			}

			if ($is_topic_page) {
				// Topic and Exam TERM pages
				wp_enqueue_style(
					'nm-taxonomy-topic',
					NM_PLUGIN_URL . 'assets/css/taxonomy-topic.css',
					array(),
					filemtime(NM_PLUGIN_PATH . 'assets/css/taxonomy-topic.css')
				);
			}

			// MCQ archive and root Exam archive share the same archive layout
			if ($is_archive_page || $is_exam_root) {
				wp_enqueue_style(
					'nm-archive-mcq',
					NM_PLUGIN_URL . 'assets/css/archive-mcq.css',
					array(),
					filemtime(NM_PLUGIN_PATH . 'assets/css/archive-mcq.css')
				);
			}
		}
	}
}
