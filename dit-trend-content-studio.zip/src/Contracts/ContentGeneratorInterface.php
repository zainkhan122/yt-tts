<?php

namespace DIT\TrendStudio\Contracts;

/**
 * Contract for content generators. Classes implementing this interface
 * should accept raw input data and return a fully composed article.
 */
interface ContentGeneratorInterface
{
    /**
     * Generate content from input data.
     *
     * @param array $input Input parameters describing the content to generate.
     * @return array Completed article data.
     */
    public function generateContent(array &$input): array;
}
