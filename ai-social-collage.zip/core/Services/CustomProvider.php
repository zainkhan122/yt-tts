<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Contracts\AIProviderInterface;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CustomProvider implements AIProviderInterface {

	private $api_key;
    private $provider_config;
    private $provider_slug;
    private $current_model;
    private $fallback_enabled;
    private array $remaining_fallbacks = [];
    private $actual_request_count = 0;

private static array $MODEL_MAX_TOKENS = [
  		'gpt-4o' => 128000,
  		'gpt-4o-mini' => 128000,
  		'gpt-4-turbo' => 128000,
  		'gpt-4' => 8192,
  		'gpt-3.5-turbo' => 16385,
  		'claude-3-5-sonnet-20241022' => 200000,
  		'claude-3-5-haiku-20241022' => 200000,
  		'claude-3-opus-20240229' => 200000,
  		'claude-3-sonnet-20240229' => 200000,
  		'claude-3-haiku-20240307' => 200000,
  		'gemini-2.0-flash' => 8192,
  		'gemini-2.5-flash' => 65536,
  		'gemini-2.5-flash-lite' => 65536,
  		'gemini-2.5-pro' => 65536,
  		'gemini-3.5-flash' => 65536,
  		'gemini-3.5-pro' => 65536,
  		'gemini-3.6-flash' => 65536,
  		'gemini-3.7-flash' => 65536,
  		'gemini-1.5-flash' => 8192,
  		'gemini-1.5-pro' => 8192,
  		'llama-3.3-70b-versatile' => 128000,
  		'llama-3.2-11b-vision-preview' => 128000,
  		'llama-3.2-90b-vision-preview' => 128000,
  		'llama-3.1-8b-instant' => 128000,
  		'llama-3.1-70b-versatile' => 128000,
  		'llama3-8b-8192' => 8192,
  		'llama3-70b-8192' => 8192,
  		'mixtral-8x7b-32768' => 32768,
  		'mixtral-8x22b-65536' => 65536,
  		'deepseek-chat' => 65536,
  		'deepseek-reasoner' => 65536,
  		'qwen-2.5-72b-instruct' => 131072,
  		'qwen-2.5-32b-instruct' => 131072,
  		'qwen-2.5-14b-instruct' => 131072,
  		'command-r-plus' => 131072,
  		'command-r' => 32768,
  	];

	private static $MODELS_NO_RESPONSE_FORMAT = [
		'moonshot-v1-8k', 'moonshot-v1-32k', 'moonshot-v1-128k',
		'MiniMax-Text-01', 'minimax-text-01', 'minimaxai/minimax-m2.7',
		'abab6.5s-chat', 'abab7-chat-preview',
		'z-ai/glm-5.1:reasoning',
		'google/gemma-4-31b-it', 'google/gemma-3-27b-it',
	];

	private static $MODELS_RESPONSE_FORMAT_SUPPORTED = [
		'minimaxai/minimax-m2.5',
	];

	private static $GOOGLE_OPENAI_BASE_URL = 'https://generativelanguage.googleapis.com/v1beta/openai/';


	public function __construct( $api_key, array $provider_config, $provider_slug = '' ) {
		$this->api_key = $api_key;
		$this->provider_config = $provider_config;
		$this->provider_slug = $provider_slug !== '' ? $provider_slug : ( $provider_config['id'] ?? 'custom' );
		$this->current_model = $this->resolve_primary_model();
 		$this->fallback_enabled = ! empty( $provider_config['fallback_enabled'] );
	$all_models = $provider_config['models'] ?? $provider_config['fallback_models'] ?? [];
	$this->remaining_fallbacks = array_column( $all_models, 'model_id' );
	$primary = $this->current_model;
	$this->remaining_fallbacks = array_values( array_filter( $this->remaining_fallbacks, static function ( $m ) use ( $primary ) { return $m !== $primary; } ) );
	}

	public function get_provider_name() {
		return $this->provider_slug;
	}

	public function get_model_name() {
		return $this->current_model;
	}

	private function resolve_primary_model() {
		$models = $this->provider_config['models'] ?? [];
		if ( ! empty( $models[0]['model_id'] ) ) {
			return $models[0]['model_id'];
		}
		return 'gpt-4o-mini';
	}

public function generate_content( $post_content, $system_prompt = '' ) {
		$config = $this->provider_config;
		$endpoint = rtrim( $config['api_url'], '/' ) . '/chat/completions';

		$is_google_openai = $this->is_google_openai_endpoint( $endpoint );

		$enable_web_search = ! empty( $config['enable_web_search'] );
		$web_search_type = $config['web_search_config']['type'] ?? Config::WEB_SEARCH_NONE;
		$use_web_search = $enable_web_search && $web_search_type !== Config::WEB_SEARCH_NONE;

		$headers = [
			'Authorization' => 'Bearer ' . $this->api_key,
			'Content-Type' => 'application/json',
		];

		if ( strpos( $endpoint, 'openrouter' ) !== false ) {
			$headers['HTTP-Referer'] = home_url();
			$headers['X-Title'] = 'AI Social Collage';
		}

  		$models_to_try = [ $this->current_model ];
  		if ( $this->fallback_enabled ) {
 			$models_to_try = array_merge( $models_to_try, $this->remaining_fallbacks );
 		}

 		$last_error    = '';
 		$last_http_code = 0;
 		$last_body     = '';

 		foreach ( $models_to_try as $model ) {
 			$this->current_model = $model;
 			$this->actual_request_count++;
 
 			$max_tokens = $this->get_max_tokens_for_model( $model );
 
 			$body = [
 				'model' => $model,
 				'messages' => [
 					[ 'role' => 'system', 'content' => $system_prompt ],
 					[ 'role' => 'user', 'content' => $post_content ],
 				],
 				'stream' => false,
 				'temperature' => 0.2,
 				'max_tokens' => $max_tokens,
 			];
 
 			if ( $this->model_supports_response_format( $model ) ) {
 				$body['response_format'] = [ 'type' => 'json_object' ];
 			}
 
if ( $use_web_search ) {
			$tools = $this->build_web_search_tool( $web_search_type, $is_google_openai );
			if ( ! empty( $tools ) ) {
				$body['tools'] = $tools;
			}
		}
 
 			$start_time = microtime( true );
 
 			$response = wp_remote_post( $endpoint, [
 				'headers' => $headers,
 				'body' => wp_json_encode( $body ),
 				'timeout' => 30,
 			] );
 
 			if ( is_wp_error( $response ) ) {
 				Logger::debug( Config::LOG_ACTION_CUSTOM_PROVIDER_RESPONSE, null, $body, '0', $response->get_error_message(), 0 );
 				continue;
 			}
 
 			$code = wp_remote_retrieve_response_code( $response );
 			$raw = wp_remote_retrieve_body( $response );
 			$execution_time = microtime( true ) - $start_time;
 
 			Logger::debug( Config::LOG_ACTION_CUSTOM_PROVIDER_RESPONSE, null, $body, (string) $code, $raw, $execution_time );
 
 			$last_http_code = (int) $code;
 			$last_body      = (string) $raw;
 
 			if ( $code === 401 || $code === 403 ) {
 				$last_error = "{$this->provider_slug} model '{$model}' HTTP {$code} - authentication failure";
 				continue;
 			}
 
 			if ( $code === 429 ) {
 				$last_error = "{$this->provider_slug} model '{$model}' HTTP {$code} - rate limited";
 				continue;
 			}

 			if ( $code === 400 && $use_web_search && isset( $body['tools'] ) ) {
 				$body['tools'] = null;
 				$body['messages'][0]['content'] = $this->strip_web_search_instructions( $system_prompt );
 				$response = wp_remote_post( $endpoint, [
 					'headers' => $headers,
 					'body' => wp_json_encode( $body ),
 					'timeout' => 30,
 				] );
 				if ( ! is_wp_error( $response ) ) {
 					$code = wp_remote_retrieve_response_code( $response );
 					$raw = wp_remote_retrieve_body( $response );
 					if ( $code === 200 ) {
 						return $this->parse_response( $raw );
 					}
 				}
 				continue;
 			}

 			if ( $code === 400 && isset( $body['response_format'] ) ) {
 				$body['response_format'] = null;
 				$response = wp_remote_post( $endpoint, [
 					'headers' => $headers,
 					'body' => wp_json_encode( $body ),
 					'timeout' => 30,
 				] );
 				if ( ! is_wp_error( $response ) ) {
 					$code = wp_remote_retrieve_response_code( $response );
 					$raw = wp_remote_retrieve_body( $response );
 					if ( $code === 200 ) {
 						return $this->parse_response( $raw );
 					}
 				}
 				continue;
 			}

 			if ( $code !== 200 ) {
 				continue;
 			}

 			$data = json_decode( $raw, true );
 			$message = $data['choices'][0]['message'] ?? [];
 			$content = $message['content'] ?? '';

 			if ( empty( $content ) && ! empty( $message['tool_calls'] ) ) {
 				$tool_args = [];
 				foreach ( $message['tool_calls'] as $tc ) {
 					$args = $tc['function']['arguments'] ?? '';
 					if ( $args !== '' ) {
 						$tool_args[] = $args;
 					}
 				}
 				if ( ! empty( $tool_args ) ) {
 					$merged = implode( "\n", $tool_args );
 					if ( is_array( json_decode( $merged, true ) ) ) {
 						$content = $merged;
 					}
 				}
 			}

			if ( empty( $content ) ) {
				continue;
			}

			try {
				return $this->parse_response( $raw );
			} catch ( \Exception $e ) {
				continue;
			}
		}

  		throw new \Exception( "{$this->provider_slug} API: all models failed. Last: " . mb_substr( $last_body, 0, 500 ), $last_http_code );
  	}

  	private function parse_response( string $raw ): array {
 		$data = json_decode( $raw, true );
 		if ( ! is_array( $data ) ) {
 			return [];
 		}

 		$message = $data['choices'][0]['message'] ?? [];
 		$content = $message['content'] ?? '';

 		if ( empty( $content ) ) {
 			throw new \Exception( 'Empty response content' );
 		}

 		// Strip markdown code fences (```json ... ```) that some models add without response_format enforcement
 		$content = preg_replace( '/^```(?:json)?\s*\n?(.*?)\n?```\s*$/s', '$1', $content );

 		$result = json_decode( $content, true );
 		if ( $result === null || ! is_array( $result ) ) {
 			throw new \Exception( 'AI response content is not valid JSON: ' . mb_substr( $content, 0, 200 ) );
 		}

 		$input_tokens = (int) ( $data['usage']['prompt_tokens'] ?? 0 );
 		$output_tokens = (int) ( $data['usage']['completion_tokens'] ?? 0 );
 		$result['_meta'] = [
 			'input_tokens' => $input_tokens,
 			'output_tokens' => $output_tokens,
 		];

 		return $result;
 	}

public function analyze_image( $image_path, $system_prompt = '' ) {
		$config = $this->provider_config;
		$endpoint = rtrim( $config['api_url'], '/' ) . '/chat/completions';

		$is_google_openai = $this->is_google_openai_endpoint( $endpoint );

		if ( ! file_exists( $image_path ) ) {
			throw new \Exception( 'Image file not found: ' . $image_path );
		}

		$mime = mime_content_type( $image_path );
		$base64 = base64_encode( file_get_contents( $image_path ) );
		if ( empty( $base64 ) ) {
			throw new \Exception( 'Failed to read image for Vision analysis.' );
		}

		$mime = mime_content_type( $image_path );
		$base64_data = base64_encode( file_get_contents( $image_path ) );

   		$models_to_try = [ $this->current_model ];
   		if ( $this->fallback_enabled ) {
   			$models_to_try = array_merge( $models_to_try, $this->remaining_fallbacks );
   		}

		$last_error     = '';
		$last_http_code = 0;
		$last_body      = '';

		foreach ( $models_to_try as $model ) {
			$this->current_model = $model;
			$this->actual_request_count++;

			$max_tokens = $this->get_max_tokens_for_model( $model );

			$image_content = [
				[ 'type' => 'text', 'text' => $system_prompt ],
			];

			// Google OpenAI-compatible endpoint uses standard image_url format
			$image_content[] = [ 'type' => 'image_url', 'image_url' => [ 'url' => "data:{$mime};base64,{$base64_data}" ] ];

			$body = [
				'model' => $model,
				'messages' => [
					[
						'role' => 'user',
						'content' => $image_content,
					]
				],
				'stream' => false,
				'temperature' => 0.2,
				'max_tokens' => $max_tokens,
			];

			if ( $this->model_supports_response_format( $model ) ) {
				$body['response_format'] = [ 'type' => 'json_object' ];
			}

			$headers = [
				'Authorization' => 'Bearer ' . $this->api_key,
				'Content-Type' => 'application/json',
			];

			if ( strpos( $endpoint, 'openrouter' ) !== false ) {
				$headers['HTTP-Referer'] = home_url();
				$headers['X-Title'] = 'AI Social Collage';
			}
 
 			$start_time = microtime( true );
 			$response = wp_remote_post( $endpoint, [
 				'headers' => $headers,
 				'body' => wp_json_encode( $body ),
 				'timeout' => 60,
 			] );
 			$execution_time = microtime( true ) - $start_time;
 
 			if ( is_wp_error( $response ) ) {
 				Logger::debug( Config::LOG_ACTION_CUSTOM_PROVIDER_RESPONSE, null, [ 'model' => $model, 'image' => true ], '0', $response->get_error_message(), $execution_time );
 				continue;
 			}
 
 			$code = wp_remote_retrieve_response_code( $response );
 			$raw = wp_remote_retrieve_body( $response );
 
 			Logger::debug( Config::LOG_ACTION_CUSTOM_PROVIDER_RESPONSE, null, [ 'model' => $model, 'image' => true ], (string) $code, mb_substr( $raw, 0, 1000 ), $execution_time );
 
 			$last_http_code = (int) $code;
 			$last_body      = (string) $raw;
 
 			if ( $code === 401 || $code === 403 ) {
 				$last_error = "{$this->provider_slug} Vision model '{$model}' HTTP {$code} - authentication failure";
 				continue;
 			}
 
 			if ( $code === 429 ) {
 				$last_error = "{$this->provider_slug} Vision model '{$model}' HTTP {$code} - rate limited";
 				continue;
 			}

 			if ( $code === 400 && isset( $body['response_format'] ) ) {
 				$body['response_format'] = null;
 				$response = wp_remote_post( $endpoint, [
 					'headers' => $headers,
 					'body' => wp_json_encode( $body ),
 					'timeout' => 60,
 				] );
 				if ( ! is_wp_error( $response ) ) {
 					$code = wp_remote_retrieve_response_code( $response );
 					$raw = wp_remote_retrieve_body( $response );
 					if ( $code === 200 ) {
 						return $this->parse_vision_response( $raw );
 					}
 				}
 				continue;
 			}

 			if ( $code !== 200 ) {
 				continue;
 			}

 			$data = json_decode( $raw, true );
 			$result_text = $data['choices'][0]['message']['content'] ?? '{}';

 			if ( strpos( $result_text, '```json' ) !== false ) {
 				$result_text = preg_replace( '/```json\s*(.*?)\s*```/s', '$1', $result_text );
 			} elseif ( strpos( $result_text, '```' ) !== false ) {
 				$result_text = preg_replace( '/```\s*(.*?)\s*```/s', '$1', $result_text );
 			}

 			$result_text = trim( $result_text );

 			$result = json_decode( $result_text, true );
 			if ( $result === null ) {
 				$result = [];
 			}

 			$input_tokens = (int) ( $data['usage']['prompt_tokens'] ?? 0 );
 			$output_tokens = (int) ( $data['usage']['completion_tokens'] ?? 0 );
 			$result['_meta'] = [
 				'input_tokens' => $input_tokens,
 				'output_tokens' => $output_tokens,
 			];

 			return $result;
 		}

  		throw new \Exception( "{$this->provider_slug} Vision API: all models failed. Last: " . mb_substr( $last_body, 0, 500 ), $last_http_code );
  	}

 	private function parse_vision_response( string $raw ): array {
 		$data = json_decode( $raw, true );
 		if ( ! is_array( $data ) ) {
 			return [];
 		}

 		$result_text = $data['choices'][0]['message']['content'] ?? '{}';

 		if ( strpos( $result_text, '```json' ) !== false ) {
 			$result_text = preg_replace( '/```json\s*(.*?)\s*```/s', '$1', $result_text );
 		} elseif ( strpos( $result_text, '```' ) !== false ) {
 			$result_text = preg_replace( '/```\s*(.*?)\s*```/s', '$1', $result_text );
 		}

 		$result_text = trim( $result_text );

 		$result = json_decode( $result_text, true );
 		if ( $result === null ) {
 			$result = [];
 		}

 		$input_tokens = (int) ( $data['usage']['prompt_tokens'] ?? 0 );
 		$output_tokens = (int) ( $data['usage']['completion_tokens'] ?? 0 );
 		$result['_meta'] = [
 			'input_tokens' => $input_tokens,
 			'output_tokens' => $output_tokens,
 		];

 		return $result;
 	}

	public function get_actual_request_count() {
		return $this->actual_request_count;
	}

	public function test_connection() {
		$model = $this->current_model;
		$endpoint = rtrim( $this->provider_config['api_url'], '/' ) . '/chat/completions';

		$headers = [
			'Authorization' => 'Bearer ' . $this->api_key,
			'Content-Type' => 'application/json',
		];

		$body = wp_json_encode( [
			'model' => $model,
			'messages' => [ [ 'role' => 'user', 'content' => 'Ping' ] ],
			'max_tokens' => 5,
			'temperature' => 0,
		] );

		Logger::debug( 'custom_provider_test_request', null, [
			'endpoint' => $endpoint,
			'model' => $model,
			'headers' => $headers,
			'body' => json_decode( $body, true ),
		] );

		if ( strpos( $endpoint, 'openrouter' ) !== false ) {
			$headers['HTTP-Referer'] = home_url();
			$headers['X-Title'] = 'AI Social Collage';
		}

		$response = wp_remote_post( $endpoint, [
			'headers' => $headers,
			'body' => $body,
			'timeout' => 30,
		] );

		if ( is_wp_error( $response ) ) {
			$err = $response->get_error_message();
			Logger::debug( 'custom_provider_test_wp_error', null, [
				'endpoint' => $endpoint,
				'model' => $model,
				'error' => $err,
			] );
			return [ 'success' => false, 'error' => $err ];
		}

		$code = wp_remote_retrieve_response_code( $response );
		$raw = wp_remote_retrieve_body( $response );

		Logger::debug( Config::LOG_ACTION_CUSTOM_PROVIDER_RESPONSE, null, [
			'endpoint' => $endpoint,
			'model' => $model,
			'body' => json_decode( $body, true ),
		], (string) $code, mb_substr( $raw, 0, 500 ), 0 );

		if ( $code === 200 ) {
			return [ 'success' => true, 'message' => 'Connection successful.' ];
		}

		$data = json_decode( $body, true );
		$error_msg = isset( $data['error']['message'] ) ? $data['error']['message'] : "HTTP {$code}";
		return [ 'success' => false, 'error' => $error_msg ];
	}

	private function get_max_tokens_for_model( $model ) {
		$requested = (int) get_option( Config::OPTION_AI_MAX_OUTPUT_TOKENS, 8192 );
		$normalized = str_replace( '/', '-', $model );
		foreach ( self::$MODEL_MAX_TOKENS as $pattern => $cap ) {
			if ( $model === $pattern || stripos( $normalized, $pattern ) === 0 ) {
				return min( $requested, $cap );
			}
		}
		$base = explode( '-', $normalized )[0];
		foreach ( self::$MODEL_MAX_TOKENS as $pattern => $cap ) {
			$pbase = explode( '-', $pattern )[0];
			if ( $pbase === $base || stripos( $base, $pbase ) === 0 || stripos( $pbase, $base ) === 0 ) {
				return min( $requested, $cap );
			}
		}
		return min( $requested, 8192 );
	}

	private function model_supports_response_format( $model ) {
		if ( in_array( $model, self::$MODELS_NO_RESPONSE_FORMAT, true ) ) {
			return false;
		}
		if ( in_array( $model, self::$MODELS_RESPONSE_FORMAT_SUPPORTED, true ) ) {
			return true;
		}
		foreach ( self::$MODELS_NO_RESPONSE_FORMAT as $pattern ) {
			if ( stripos( $model, $pattern ) === 0 ) {
				return false;
			}
		}
		$no_format_prefixes = [ 'moonshot', 'minimax', 'abab' ];
		$base = explode( '-', str_replace( '/', '-', $model ) )[0];
		// Google Gemini models via OpenAI-compatible endpoint have limited response_format support
		$gemini_prefixes = [ 'gemini' ];
		if ( in_array( strtolower( $base ), $gemini_prefixes, true ) ) {
			return false;
		}
		return ! in_array( strtolower( $base ), $no_format_prefixes, true );
	}

	private function is_google_openai_endpoint( $endpoint ) {
		return strpos( $endpoint, 'generativelanguage.googleapis.com/v1beta/openai' ) !== false;
	}

	private function build_web_search_tool( $type, $is_google_openai = false ) {
		// Google OpenAI-compatible endpoint doesn't support google_search tool
		if ( $is_google_openai && $type === Config::WEB_SEARCH_GOOGLE ) {
			return [];
		}

		switch ( $type ) {
			case Config::WEB_SEARCH_GOOGLE:
				return [ [ 'google_search' => new \stdClass() ] ];
			case Config::WEB_SEARCH_PERPLEXITY:
				return [];
			case Config::WEB_SEARCH_ZHIPUAI:
				return [ [ 'type' => 'web_search', 'web_search' => [ 'enable' => true, 'search_engine' => 'search_pro' ] ] ];
			case Config::WEB_SEARCH_KIMI:
				return [ [ 'type' => 'web_search', 'web_search' => [ 'enable' => true, 'search_result' => true ] ] ];
			case Config::WEB_SEARCH_MINIMAX:
				return [ [ 'type' => 'web_search', 'web_search' => [ 'enable' => true ] ] ];
			default:
				return [];
		}
	}

	private function strip_web_search_instructions( $prompt ) {
		$marker = '## Web Search Instructions';
		if ( strpos( $prompt, $marker ) !== false ) {
			$parts = explode( $marker, $prompt, 2 );
			return rtrim( $parts[0] );
		}
		return $prompt;
	}
}
