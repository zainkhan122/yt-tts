<?php
/**
 * Buffer API Integration
 *
 * @package SEO_Article_Generator
 */

namespace SEO_Article_Generator\Integration;

use SEO_Article_Generator\Logger;
use SEO_Article_Generator\Option_Registry;

if (!defined('ABSPATH')) {
    exit;
}

class Buffer_Integration
{
    private $logger;

    public static $pending_tags = array();

    const API_BASE = 'https://api.buffer.com';
    const TRANSIENT_ORG_ID = 'seo_gen_buffer_org_id';
    const TRANSIENT_CHANNELS = 'seo_gen_buffer_channels';
    const TRANSIENT_PINTEREST_BOARDS = 'seo_gen_buffer_pinterest_boards_';
    const CACHE_DURATION = HOUR_IN_SECONDS;
    const PINTEREST_CACHE_DURATION = 900;

    public function __construct(Logger $logger)
    {
        $this->logger = $logger;
    }

    public function register_hooks()
    {
        add_action('transition_post_status', array($this, 'handle_status_transition'), 20, 3);

        if (is_admin()) {
            add_action('wp_ajax_seo_gen_refresh_buffer_channels', array($this, 'ajax_refresh_channels'));
        }
    }

    private function is_ai_post($post_id)
    {
        if (get_post_meta($post_id, '_seo_gen_regen_sections', true) || get_post_meta($post_id, 'seogenherodata', true)) {
            return true;
        }

        if (version_compare(PHP_VERSION, '5.3.6', '>=')) {
            $trace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 15);
        } else {
            $trace = debug_backtrace(false);
        }

        foreach ($trace as $frame) {
            if (isset($frame['class'], $frame['function']) &&
                $frame['class'] === 'SEO_Article_Generator\\Jobs\\Job_Handler' &&
                $frame['function'] === 'finalize_generated_post') {
                return true;
            }
        }

        return false;
    }

    public function handle_status_transition($new_status, $old_status, $post)
    {
        if ($new_status !== 'publish') {
            return;
        }

        if ($new_status === $old_status) {
            return;
        }

        if (!$this->is_ai_post($post->ID)) {
            return;
        }

        // Finding 3 (Publish-Watchdog Share Fix): pass the $post object that
        // WordPress already built for the transition hook into share_post()
        // instead of re-fetching via get_post(). During wp_publish_post()
        // (used by seo_gen_publish_watchdog), transition_post_status fires
        // inside wp_insert_post() BEFORE clean_post_cache() runs, so a
        // get_post() call here would return a stale object whose post_status
        // is still 'future', causing share_post()'s guard at line 83 to
        // silently return with zero log output.
        $this->share_post($post->ID, $post);
    }

    public function share_post($post_id, $post = null)
    {
        if ($post === null) {
            $post = get_post($post_id);
        }
        if (!$post || $post->post_status !== 'publish') {
            return;
        }

        $enabled = get_option(Option_Registry::BUFFER_ENABLED, false);
        if (!$enabled) {
            $this->logger->info("Buffer Integration: Skipping post {$post_id} — Buffer sharing is disabled.");
            return;
        }

        $access_token = get_option(Option_Registry::BUFFER_ACCESS_TOKEN, '');
        if (empty($access_token)) {
            $this->logger->error("Buffer Integration: Skipping post {$post_id} — access token missing.");
            return;
        }

        $daily_limit = (int) get_option(Option_Registry::BUFFER_DAILY_LIMIT, 5);
        $tracker = get_option(Option_Registry::BUFFER_PUB_TRACKER, array('date' => '', 'ids' => array()));

        if (!is_array($tracker)) {
            $tracker = array('date' => '', 'ids' => array());
        }

        $today = gmdate('Y-m-d');

        if ($tracker['date'] !== $today) {
            $tracker = array('date' => $today, 'ids' => array());
        }

        // Finding 4 (Buffer Publish-Watchdog Share Fix): the daily limit is
        // per-POST per-day, not per-channel-share per-day. Previously the
        // inner channel loop appended $post_id once per successful channel,
        // so a 4-channel share burned 4 of the 5 daily quota on ONE post.
        // Deduplicate first: a post already counted today is allowed to fan
        // out to additional channels without re-counting; a NEW post is
        // counted once at the survival-of-the-loop's end.
        $already_counted = in_array((int) $post_id, $tracker['ids'], true);

        if ($daily_limit > 0 && !$already_counted && count($tracker['ids']) >= $daily_limit) {
            $this->logger->info("Buffer Integration: Skipping post {$post_id} — daily Buffer share limit ({$daily_limit}) reached.");
            return;
        }

        $history = get_post_meta($post_id, '_seo_gen_buffer_share_history', true);
        if (is_array($history) && !empty($history)) {
            // Check both successful shares AND attempt timestamps for 24h dedup
            foreach (array_reverse($history) as $entry) {
                $shared_at = isset($entry['shared_at']) ? $entry['shared_at'] : '';
                if ($shared_at) {
                    $now = time();
                    $then = strtotime($shared_at . ' GMT');
                    $hours_since = ($now - $then) / 3600;
                    if ($hours_since < 24) {
                        $remaining = round(24 - $hours_since, 1);
                        $this->logger->info("Buffer Integration: Skipping post {$post_id} — already shared/attempted {$remaining}h ago. Minimum 24h between shares.");
                        return;
                    }
                    break; // Only need to check the most recent entry
                }
            }
        }

        $channels = $this->get_channels($access_token);
        if (empty($channels)) {
            $this->logger->error("Buffer Integration: No Buffer channels found for post {$post_id}.");
            return;
        }

        $this->logger->info("Buffer Integration: Starting share for post {$post_id}.");

        // Record attempt immediately so failed shares still count toward 24h dedup
        $this->record_share_attempt($post_id);

        $enabled_channels = get_option(Option_Registry::BUFFER_ENABLED_CHANNELS, array());

        if (empty($enabled_channels)) {
            $all_enabled = true;
        } else {
            $all_enabled = false;
        }

        $any_success = false;

        foreach ($channels as $channel) {
            $channel_id = $channel['id'];
            $service = isset($channel['service']) ? strtolower($channel['service']) : '';

            if (!$all_enabled && !in_array($channel_id, $enabled_channels, true)) {
                $this->logger->info("Buffer Integration: Skipping channel {$channel_id} ({$service}) — not enabled in settings.");
                continue;
            }

            $result = $this->create_post($post, $channel, $access_token);

            if ($result) {
                $this->record_share_history($post_id, $channel_id, $service, $result);
                $any_success = true;
            }
        }

        // Finding 4: count the post once toward the daily limit only if at
        // least one channel share succeeded and the post wasn't already
        // counted today. This prevents the same-day second publish (e.g.
        // #30426 at 4:03 PM followed by #30427 at 5:03 PM) from silently
        // hitting the daily-limit gate due to per-channel over-counting.
        if ($any_success && !$already_counted) {
            $tracker['ids'][] = (int) $post_id;
            update_option(Option_Registry::BUFFER_PUB_TRACKER, $tracker);
        }
    }

    // NEW: Record share attempt in history BEFORE API calls so failed attempts
    // still count toward 24h dedup. This prevents retries from hitting Buffer
    // with "already scheduled" errors when Overdue Recovery loops.
    private function record_share_attempt($post_id)
    {
        $history = get_post_meta($post_id, '_seo_gen_buffer_share_history', true);
        if (!is_array($history)) {
            $history = array();
        }

        $history[] = array(
            'channel_id' => 'attempt',
            'service'    => 'attempt',
            'post_id'    => '',
            'due_at'     => '',
            'shared_at'  => gmdate('Y-m-d H:i:s'),
        );

        update_post_meta($post_id, '_seo_gen_buffer_share_history', $history);
    }

    private function get_channels($access_token)
    {
        $cached = get_transient(self::TRANSIENT_CHANNELS);
        if ($cached !== false && is_array($cached)) {
            return $cached;
        }

        $org_id = $this->get_organization_id($access_token);
        if (empty($org_id)) {
            return array();
        }

        $query = 'query GetChannels($input: ChannelsInput!) { channels(input: $input) { id name service avatar isQueuePaused } }';
        $variables = array(
            'input' => array(
                'organizationId' => $org_id,
            ),
        );

        $response = $this->graphql_request($access_token, $query, $variables);
        if (!$response || isset($response['errors'])) {
            return array();
        }

        $channels = isset($response['data']['channels']) ? $response['data']['channels'] : array();
        set_transient(self::TRANSIENT_CHANNELS, $channels, self::CACHE_DURATION);

        return $channels;
    }

    private function get_organization_id($access_token)
    {
        $cached = get_transient(self::TRANSIENT_ORG_ID);
        if ($cached !== false && !empty($cached)) {
            return $cached;
        }

        $query = 'query GetOrganizations { account { organizations { id name } } }';
        $response = $this->graphql_request($access_token, $query);

        if (!$response || isset($response['errors'])) {
            return '';
        }

        $orgs = isset($response['data']['account']['organizations']) ? $response['data']['account']['organizations'] : array();
        if (empty($orgs)) {
            return '';
        }

        $org_id = $orgs[0]['id'];
        set_transient(self::TRANSIENT_ORG_ID, $org_id, self::CACHE_DURATION);

        return $org_id;
    }

    private function get_pinterest_boards($channel_id, $access_token)
    {
        $cache_key = self::TRANSIENT_PINTEREST_BOARDS . md5($channel_id);
        $cached = get_transient($cache_key);
        if ($cached !== false && is_array($cached)) {
            return $cached;
        }

        $query = 'query GetChannel($input: ChannelInput!) { channel(input: $input) { metadata { ... on PinterestMetadata { boards { serviceId name } } } } }';
        $variables = array(
            'input' => array(
                'id' => $channel_id,
            ),
        );

        $response = $this->graphql_request($access_token, $query, $variables);
        if (!$response || isset($response['errors'])) {
            return array();
        }

        $metadata = isset($response['data']['channel']['metadata']) ? $response['data']['channel']['metadata'] : array();
        $boards = isset($metadata['boards']) ? $metadata['boards'] : array();

        $result = array();
        foreach ($boards as $board) {
            $result[$board['serviceId']] = $board['name'];
        }

        set_transient($cache_key, $result, self::PINTEREST_CACHE_DURATION);

        return $result;
    }

    private function graphql_request($access_token, $query, $variables = null)
    {
        $body = array('query' => $query);
        if ($variables !== null) {
            $body['variables'] = $variables;
        }

        $response = \wp_remote_post(self::API_BASE . '/graphql', array(
            'headers' => array(
                'Authorization' => 'Bearer ' . $access_token,
                'Content-Type'  => 'application/json',
            ),
            'body'    => \wp_json_encode($body),
            'timeout' => 30,
        ));

        if (\is_wp_error($response)) {
            $this->logger->error("Buffer Integration: HTTP error - " . $response->get_error_message());
            return null;
        }

        $code = \wp_remote_retrieve_response_code($response);
        $body = \wp_remote_retrieve_body($response);

        if ($code === 401) {
            $this->logger->error("Buffer Integration: 401 Unauthorized — API key is invalid or revoked.");
            return null;
        }

        if ($code !== 200) {
            $this->logger->error("Buffer Integration: HTTP {$code} error - " . $body);
            return null;
        }

        return \json_decode($body, true);
    }

    private function create_post($post, $channel, $access_token)
    {
        $channel_id = $channel['id'];
        $service = isset($channel['service']) ? strtolower($channel['service']) : '';

        $channel_types = get_option(Option_Registry::BUFFER_CHANNEL_TYPES, array());
        $channel_templates = get_option(Option_Registry::BUFFER_CHANNEL_TEMPLATES, array());
        $link_posts = get_option(Option_Registry::BUFFER_CHANNEL_LINK_POSTS, array());
        $omit_links = get_option(Option_Registry::BUFFER_CHANNEL_OMIT_LINKS, array());
        $obfuscate_links = get_option(Option_Registry::BUFFER_CHANNEL_OBFUSCATE_LINKS, array());
        $pinterest_boards = get_option(Option_Registry::BUFFER_CHANNEL_PINTEREST_BOARDS, array());
        $pinterest_titles = get_option(Option_Registry::BUFFER_CHANNEL_PINTEREST_TITLES, array());

        // Per-channel link mode. Precedence: omit > obfuscate > default
        // (omitting link is safer; flagged when both are misconfigured)
        $omit_link = in_array($channel_id, $omit_links, true);
        $obfuscate_link = in_array($channel_id, $obfuscate_links, true);

        if ($omit_link && $obfuscate_link) {
            $this->logger->warning("Buffer Integration: Channel {$channel_id} ({$service}) has both Omit Link and Obfuscate Link enabled. Omit Link takes precedence.");
            $obfuscate_link = false;
        }

        $title = $post->post_title;
        $excerpt = \wp_strip_all_tags($post->post_excerpt ?: \wp_trim_words($post->post_content, 40));
        // [FIX] Social hashtags must be ONLY AI-generated, SEO-optimized tags and must
        // NOT include source post tags, slugs or categories. The post's WordPress tags
        // are deterministic (category names, OS slugs, software name, license) and are
        // intentionally NOT used here. Source priority:
        //   1) in-memory AI tags set during finalize (self::$pending_tags)
        //   2) persisted AI tags from post meta (survives watchdog publishes)
        //   3) global DEFAULT_TAGS option fallback
        $tags_array = array();
        if (!empty(self::$pending_tags)) {
            $tags_array = self::$pending_tags;
        } elseif ($ai_tags = \get_post_meta($post->ID, '_seo_gen_ai_tags', true)) {
            $tags_array = is_array($ai_tags) ? $ai_tags : array();
        } else {
            $default_tags = \get_option(Option_Registry::DEFAULT_TAGS, array());
            if (is_string($default_tags)) {
                $default_tags = array_filter(array_map('trim', explode(',', $default_tags)), static function ($t) {
                    return $t !== '';
                });
            }
            $tags_array = is_array($default_tags) ? $default_tags : array();
        }
        // [FIX] Enforce STRICT single-token hashtags. Strip any leading '#', remove
        // spaces and all non-hashtag characters so a value like "media player" becomes
        // "mediaplayer" (never "#media player"). Guarantees no multi-word hashtags even
        // if the AI or DEFAULT_TAGS supplies them.
        $tags_array = array_filter(array_map(static function ($t) {
            $t = trim((string) $t);
            $t = ltrim($t, '#');
            $t = preg_replace('/[^A-Za-z0-9_]/', '', $t);
            return $t;
        }, $tags_array), static function ($t) {
            return $t !== '';
        });
        $tags = !empty($tags_array) ? '#' . implode(' #', $tags_array) : '';
        $link = \get_permalink($post->ID);

        // Render {link} placeholder according to per-channel mode
        if ($omit_link) {
            $text_link = '';
        } elseif ($obfuscate_link) {
            // Obfuscate the last dot of the hostname (domain.TLD boundary)
            // so SMN link scanners do not auto-detect it as a link, while
            // staying copy-pasteable (user removes the () to recover the URL).
            // Shape: https://www.site(.)com/post  (dot wrapped in parens)
            $text_link = $link;
            $host_start = 0;
            if (stripos($link, '://') !== false) {
                $host_start = stripos($link, '://') + 3;
            }
            $host_end = strpos($link, '/', $host_start);
            if ($host_end === false) {
                $host_end = strlen($link);
            }
            $hostname = substr($link, $host_start, $host_end - $host_start);
            $last_dot = strrpos($hostname, '.');
            if ($last_dot !== false) {
                $abs_dot = $host_start + $last_dot;
                $before = substr($link, 0, $abs_dot);
                $after  = substr($link, $abs_dot + 1);
                $text_link = $before . '(.)' . $after;
            }
        } else {
            $text_link = $link;
        }

        $template = isset($channel_templates[$channel_id]) ? $channel_templates[$channel_id] : "{title}\n\n{excerpt}\n\n{tags}\n\n{link}";
  $text = str_replace(
  array('{title}', '{excerpt}', '{tags}', '{link}'),
  array($title, $excerpt, $tags, $text_link),
  $template
  );

  // Finding 5 (Twitter Buffer Error Fix): Twitter/X rejects posts > 280
  // characters at the API level. The default template contains title +
  // excerpt + tags + link, which routinely exceeds 280 chars. Truncate
  // the rendered text before sending so Buffer does not return an
  // InvalidInputError that causes a hard failure on every Twitter share.
  if ($service === 'twitter') {
    $max_chars = 280;
    if (mb_strlen($text) > $max_chars) {
      $truncated = mb_substr($text, 0, $max_chars);
      $last_space = mb_strrpos($truncated, ' ');
      if ($last_space !== false) {
        $truncated = mb_substr($truncated, 0, $last_space);
      }
      $text = $truncated;
      $this->logger->warning("Buffer Integration: Truncated Twitter share text for post {$post->ID} to {$max_chars} chars (was " . mb_strlen($text . ' ... truncated') . "+ chars).");
    }
  }

        // is_link_post only applies when sharing the link as a Buffer link
        // attachment; omit/obfuscate modes intentionally suppress that.
        $is_link_post = !$omit_link && !$obfuscate_link && in_array($channel_id, $link_posts, true);
        $post_type = isset($channel_types[$channel_id]) ? $channel_types[$channel_id] : 'post';

        if ($service === 'instagram' && $post_type === 'story') {
            $thumbnail_id = (int) get_post_thumbnail_id($post->ID);
            if (!$thumbnail_id) {
                $this->logger->warning("Buffer Integration: Skipping Instagram story for post {$post->ID} — no image available (stories require an image).");
                return false;
            }
        }

        if ($service === 'pinterest') {
            $board_id = isset($pinterest_boards[$channel_id]) ? $pinterest_boards[$channel_id] : '';
            if (empty($board_id)) {
                $this->logger->error("Buffer Integration: Skipping Pinterest channel {$channel_id} — no board selected.");
                return false;
            }
            $pin_title = isset($pinterest_titles[$channel_id]) ? $pinterest_titles[$channel_id] : $title;
            $pin_title = mb_substr(\wp_strip_all_tags($pin_title), 0, 100);

            $thumbnail_id = (int) get_post_thumbnail_id($post->ID);
            if (!$thumbnail_id) {
                $this->logger->error("Buffer Integration: Skipping Pinterest channel {$channel_id} — no image available (Pinterest requires an image).");
                return false;
            }
        }

        $due_at = gmdate('Y-m-d\TH:i:s', time() + 300) . '.000Z';

        $input = array(
            'channelId'      => $channel_id,
            'schedulingType' => 'automatic',
            'mode'           => 'customScheduled',
            'dueAt'          => $due_at,
            'text'           => $text,
        );

        if ($is_link_post && !empty($link)) {
            // Buffer API: metadata.{service}.linkAttachment is mutually exclusive
            // with a non-empty assets array (CreatePostInput docs). For fb/linkedin
            // we send ONLY linkAttachment. Other services have no linkAttachment
            // field and the link is already present in the `text` body via the
            // {link} template token, so we send no assets here (image falls back
            // below in the else-branch on next share, not this one).
            if (in_array($service, array('facebook', 'linkedin'), true)) {
                $input['metadata'] = array();
                if ($service === 'facebook') {
                    $fb_type = ($post_type !== 'post') ? $post_type : 'post';
                    $input['metadata']['facebook'] = array(
                        'type'            => $fb_type,
                        'linkAttachment'  => array('url' => $link),
                    );
                } else {
                    $input['metadata']['linkedin'] = array(
                        'linkAttachment' => array('url' => $link),
                    );
                }
            } else {
                // No documented linkAttachment for this service.
                // The {link} token already put the URL in `text`; attach the
                // featured image as a normal asset (no link asset sent).
                $thumbnail_id = (int) get_post_thumbnail_id($post->ID);
                $image_url = $thumbnail_id ? \wp_get_attachment_url($thumbnail_id) : '';
                if (!empty($image_url)) {
                    $input['assets'] = array(
                        array('image' => array('url' => $image_url)),
                    );
                }

                $effective_meta_link = ($omit_link || $obfuscate_link) ? '' : $link;
                $metadata = $this->build_service_metadata($service, $post_type, $effective_meta_link, $post, $channel_id);
                if (!empty($metadata)) {
                    $input['metadata'] = $metadata;
                }
            }
        } else {
            $thumbnail_id = (int) get_post_thumbnail_id($post->ID);
            $image_url = $thumbnail_id ? \wp_get_attachment_url($thumbnail_id) : '';

            if (!empty($image_url)) {
                $input['assets'] = array(
                    array('image' => array('url' => $image_url)),
                );
            }

            $effective_meta_link = ($omit_link || $obfuscate_link) ? '' : $link;
            $metadata = $this->build_service_metadata($service, $post_type, $effective_meta_link, $post, $channel_id);
            if (!empty($metadata)) {
                $input['metadata'] = $metadata;
            }
        }

        $mutation = 'mutation CreatePost($input: CreatePostInput!) {
            createPost(input: $input) {
                ... on PostActionSuccess {
                    post {
                        id
                        text
                        dueAt
                    }
                }
                ... on InvalidInputError {
                    message
                }
                ... on LimitReachedError {
                    message
                }
                ... on UnauthorizedError {
                    message
                }
                ... on NotFoundError {
                    message
                }
                ... on UnexpectedError {
                    message
                }
                ... on RestProxyError {
                    message
                }
            }
        }';

        $variables = array('input' => $input);

        $response = $this->graphql_request($access_token, $mutation, $variables);

        if (!$response) {
            return false;
        }

        if (isset($response['errors'])) {
            $messages = array();
            foreach ($response['errors'] as $err) {
                $messages[] = isset($err['message']) ? $err['message'] : 'Unknown error';
            }
            $this->logger->error("Buffer Integration: GraphQL errors on channel {$channel_id} ({$service}) - " . implode('; ', $messages));
            return false;
        }

        $result = isset($response['data']['createPost']) ? $response['data']['createPost'] : null;

        if (!is_array($result)) {
            $this->logger->error("Buffer Integration: createPost returned non-array result on channel {$channel_id} ({$service}).");
            return false;
        }

        if (!isset($result['post']['id'])) {
            $error_msg = isset($result['message']) ? $result['message'] : 'Unknown Buffer API error (no post ID in response)';

            // Buffer returns "already got this one scheduled" when the same content
            // is already queued/posted. Treat this as success since the share exists.
            if (stripos($error_msg, 'already got this one scheduled') !== false ||
                stripos($error_msg, 'duplicate') !== false) {
                $this->logger->info("Buffer Integration: Post {$post->ID} already shared to {$service} (channel {$channel_id}) — treating as success.");
                return array(
                    'id'    => 'duplicate-' . $channel_id,
                    'dueAt' => gmdate('Y-m-d\TH:i:s', time() + 300) . '.000Z',
                );
            }

            $this->logger->error("Buffer Integration: createPost error on channel {$channel_id} ({$service}) - {$error_msg}");
            return false;
        }

        $buffer_post_id = $result['post']['id'];
        $post_due = isset($result['post']['dueAt']) ? $result['post']['dueAt'] : '';

        $this->logger->info("Buffer Integration: Shared post {$post->ID} to {$service} (channel {$channel_id}). Buffer post ID: {$buffer_post_id}, due: {$post_due}.");

        return array(
            'id'    => $buffer_post_id,
            'dueAt' => $post_due,
        );
    }

    // $link is the effective share link: real permalink (default mode),
    // or empty string when omit-link / obfuscate-link mode is active for
    // this channel. An empty value suppresses the Pinterest `url` field.
    private function build_service_metadata($service, $post_type, $link, $post, $channel_id)
    {
        $metadata = array();

        switch ($service) {
            case 'facebook':
                $fb_type = ($post_type === 'story' || $post_type === 'reel') ? $post_type : 'post';
                $metadata['facebook'] = array('type' => $fb_type);
                break;

            case 'instagram':
                $ig_type = ($post_type === 'story' || $post_type === 'reel') ? $post_type : 'post';
                $metadata['instagram'] = array(
                    'type'               => $ig_type,
                    'shouldShareToFeed'  => true,
                );
                break;

            case 'linkedin':
                $metadata['linkedin'] = array();
                break;

            case 'pinterest':
                $pinterest_boards = get_option(Option_Registry::BUFFER_CHANNEL_PINTEREST_BOARDS, array());
                $pinterest_titles = get_option(Option_Registry::BUFFER_CHANNEL_PINTEREST_TITLES, array());

                $board_id = isset($pinterest_boards[$channel_id]) ? $pinterest_boards[$channel_id] : '';
                $pin_title = isset($pinterest_titles[$channel_id]) ? $pinterest_titles[$channel_id] : $post->post_title;
                $pin_title = mb_substr(\wp_strip_all_tags($pin_title), 0, 100);

                if (!empty($board_id)) {
                    $pin_metadata = array(
                        'title'          => $pin_title,
                        'boardServiceId' => $board_id,
                    );
                    if (!empty($link)) {
                        $pin_metadata['url'] = $link;
                    }
                    $metadata['pinterest'] = $pin_metadata;
                }
                break;

            case 'tiktok':
                if ($post_type === 'video') {
                    $metadata['tiktok'] = array();
                }
                break;

            case 'threads':
                $threads_type = ($post_type === 'story') ? 'story' : 'post';
                if ($threads_type !== 'post') {
                    $metadata['threads'] = array('type' => $threads_type);
                }
                break;

            case 'bluesky':
                $metadata['bluesky'] = array();
                break;

            case 'youtube':
                if ($post_type === 'video') {
                    $metadata['youtube'] = array();
                }
                break;

            default:
                break;
        }

        return $metadata;
    }

    private function record_share_history($post_id, $channel_id, $service, $result)
    {
        $history = get_post_meta($post_id, '_seo_gen_buffer_share_history', true);
        if (!is_array($history)) {
            $history = array();
        }

        $history[] = array(
            'channel_id' => $channel_id,
            'service'    => $service,
            'post_id'    => isset($result['id']) ? $result['id'] : '',
            'due_at'     => isset($result['dueAt']) ? $result['dueAt'] : '',
            'shared_at'  => gmdate('Y-m-d H:i:s'),
        );

        update_post_meta($post_id, '_seo_gen_buffer_share_history', $history);
    }

    public function ajax_refresh_channels()
    {
        check_ajax_referer('seo_gen_nonce', '_ajax_nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Unauthorized'));
        }

        $this->clear_all_caches();

        $token = get_option(Option_Registry::BUFFER_ACCESS_TOKEN, '');
        if (empty($token)) {
            wp_send_json_error(array('message' => 'No access token configured.'));
        }

        $channels = $this->get_channels($token);
        if (empty($channels)) {
            wp_send_json_error(array('message' => 'No channels found. Verify your token and Buffer account.'));
        }

        wp_send_json_success($channels);
    }

    public function clear_all_caches()
    {
        delete_transient(self::TRANSIENT_ORG_ID);
        delete_transient(self::TRANSIENT_CHANNELS);

        global $wpdb;
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
            $wpdb->esc_like('_transient_') . self::TRANSIENT_PINTEREST_BOARDS . '%',
            $wpdb->esc_like('_transient_timeout_') . self::TRANSIENT_PINTEREST_BOARDS . '%'
        ));
    }

    public static function get_pinterest_boards_static($channel_id)
    {
        $instance = new self(new Logger());
        $token = get_option(Option_Registry::BUFFER_ACCESS_TOKEN, '');
        if (empty($token)) {
            return array();
        }
        return $instance->get_pinterest_boards($channel_id, $token);
    }
}
