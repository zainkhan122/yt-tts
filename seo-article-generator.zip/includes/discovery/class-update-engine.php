<?php
namespace SEO_Article_Generator\Discovery;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Update_Engine {

	public static function get_save_hook_map( string $post_type ): array {
		return [
			[
				'hook'          => 'save_post',
				'callback'      => [ __CLASS__, 'trigger_on_save' ],
				'priority'      => 10,
				'accepted_args' => 3,
			],
			[
				'hook'          => "save_post_{$post_type}",
				'callback'      => [ __CLASS__, 'trigger_on_save' ],
				'priority'      => 10,
				'accepted_args' => 3,
			],
		];
	}

	public static function register_for_post_type( string $post_type ): void {
		foreach ( self::get_save_hook_map( $post_type ) as $item ) {
			if ( false === has_action( $item['hook'], $item['callback'] ) ) {
				add_action(
					$item['hook'],
					$item['callback'],
					$item['priority'],
					$item['accepted_args']
				);
			}
		}
	}

	/**
	 * Unhook save_post to prevent recursion during atomic writes.
	 */
	public function unhook_save_post( string $post_type = 'post' ): void {
		foreach ( self::get_save_hook_map( $post_type ) as $item ) {
			remove_action( $item['hook'], $item['callback'], $item['priority'] );
		}
	}

	/**
	 * Re-hook save_post after atomic write.
	 */
	public function hook_save_post( string $post_type = 'post' ): void {
		self::register_for_post_type( $post_type );
	}

	public static function trigger_on_save( int $post_id, \WP_Post $post, bool $update ): void {
		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( 'auto-draft' === $post->post_status ) {
			return;
		}

		if ( ! self::is_plugin_managed_post( $post_id, $post ) ) {
			return;
		}

		/**
		 * Hand off to your actual queue/discovery layer.
		 * Replace this with your concrete dispatcher if you already have one.
		 */
		do_action( 'seo_gen_queue_regeneration_on_save', $post_id, $post, $update );
	}

	private static function is_plugin_managed_post( int $post_id, \WP_Post $post ): bool {
		if ( 'post' !== $post->post_type ) {
			return false;
		}

		return metadata_exists( 'post', $post_id, '_seo_gen_software_name' );
	}
}
