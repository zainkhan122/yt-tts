<?php
/**
 * DIT Video Module — Settings
 *
 * Self-contained settings store for the optional video-shorts module.
 * Every key is namespaced with dit_ts_video_ so it never collides with the
 * main DIT plugin. This module is additive and fully optional.
 *
 * @package DIT\TrendStudio\Video
 */

namespace DIT\TrendStudio\Video;

if (!defined('ABSPATH')) {
    exit;
}

class Settings
{
    public const PREFIX = 'dit_ts_video_';

    /**
     * Defaults for every option (used on first access / reset).
     */
    public function defaults(): array
    {
        return array(
            'enabled'              => 0,          // master on/off (off = no effect)
            'auto_generate'        => 0,          // auto-generate on publish
            'tts_backend'          => 'edge',     // edge | kokoro | none
            'tts_voice'            => 'ur-PK-UzmaNeural', // Edge-TTS Urdu female
            'tts_speed'            => '1.15',     // energetic / fast-paced
            'max_duration'         => 60,         // Shorts cap
            'heading_font_size'    => 64,         // SEPARATE from collage heading font
            'width'                => 1080,
            'height'               => 1920,
            'fps'                  => 30,
            'use_black_bars'       => 1,          // no-crop letterbox (smart fit)
            'cleanup_enabled'      => 1,
            'cleanup_age_days'     => 30,
            'runner_dir'           => '',         // override path to video-runner/
            'last_diagnostics'     => '',
            // YouTube link-back integration.
            'yt_api_key'           => '',
            'yt_channel_id'        => '',
            'detach_local_after_yt' => 1,          // once YT embedded, allow local video cleanup
            'embed_after_2nd_para'  => 1,          // insert native YT Gutenberg block after 2nd paragraph
            // Multi-SMN sharing of the generated video via DIT's Buffer share.
            // If on, the video is shared to all enabled Buffer channels (YouTube +
            // any other SMNs you've enabled for the account). Off = YouTube only.
            'share_video_all_smn'   => 1,
        );
    }

    public function get(string $key, $default = null)
    {
        $defaults = $this->defaults();
        if (null === $default && array_key_exists($key, $defaults)) {
            $default = $defaults[$key];
        }
        return get_option(self::PREFIX . $key, $default);
    }

    public function get_bool(string $key, $default = false): bool
    {
        return (bool) $this->get($key, $default ? '1' : '0');
    }

    public function get_int(string $key, $default = 0): int
    {
        return (int) $this->get($key, $default);
    }

    public function set(string $key, $value): bool
    {
        return update_option(self::PREFIX . $key, $value);
    }

    /**
     * The absolute path to the video-runner directory.
     * Defaults to <plugin_dir>/video-runner.
     */
    public function runner_dir(): string
    {
        $override = (string) $this->get('runner_dir', '');
        if ($override !== '' && is_dir($override)) {
            return untrailingslashit($override);
        }
        return untrailingslashit(DIT_TS_PLUGIN_DIR . 'video-runner');
    }

    /**
     * True when the module is enabled AND a runner exists (no-op otherwise).
     */
    public function is_active(): bool
    {
        return $this->get_bool('enabled', false) && is_dir($this->runner_dir());
    }
}
