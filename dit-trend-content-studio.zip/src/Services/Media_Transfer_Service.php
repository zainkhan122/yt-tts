<?php

/**
 * Media Transfer Service
 *
 * Transfers job-managed media from a source idea/draft to the final published post.
 * This prevents orphan attachments and makes draft cleanup safe/reliable.
 *
 * @package DIT_TrendStudio
 * @since 2.15.15
 * @MODIFIED 2026-02-25 - Added media transfer after auto-publish
 */

namespace DIT\TrendStudio\Services;

use DIT\TrendStudio\Infrastructure\Logger;

if (!defined('ABSPATH')) {
    exit;
}

class Media_Transfer_Service
{
    private ?Logger $logger;

    public function __construct(?Logger $logger = null)
    {
        $this->logger = $logger;
    }

    /**
     * Transfer managed attachments for a job from source post to destination post.
     *
     * Managed attachments are identified by:
     * - _dit_ts_media_managed = 1
     * - _dit_ts_media_owner   = $source_post_id
     * - _dit_ts_media_job     = $job_id
     *
     * @param int $source_post_id
     * @param int $dest_post_id
     * @param int $job_id
     * @return array{moved:int,skipped:int}
     */
    public function transfer_job_media(int $source_post_id, int $dest_post_id, int $job_id): array
    {
        $source_post_id = (int) $source_post_id;
        $dest_post_id   = (int) $dest_post_id;
        $job_id         = (int) $job_id;

        if ($source_post_id <= 0 || $dest_post_id <= 0 || $job_id <= 0) {
            return array('moved' => 0, 'skipped' => 0);
        }

	$q = new \WP_Query(array(
		'post_type' => 'attachment',
		'post_status' => 'inherit',
		'posts_per_page' => -1,
		'fields' => 'ids',
		'meta_query' => array(
			'relation' => 'AND',
			array(
				'key' => '_dit_ts_media_managed',
				'value' => '1',
				'compare' => '=',
			),
			array(
				'key' => '_dit_ts_media_owner',
				'value' => (string) $source_post_id,
				'compare' => '=',
			),
			array(
				'key' => '_dit_ts_media_job',
				'value' => (string) $job_id,
				'compare' => '=',
			),
		),
		'no_found_rows' => true,
	));

        $moved = 0;
        $skipped = 0;

        foreach ((array) ($q->posts ?? array()) as $att_id) {
            $att_id = (int) $att_id;
            if ($att_id <= 0) {
                continue;
            }

            // Re-parent to the published post for organization and cleanup safety.
            $ok = wp_update_post(array(
                'ID'          => $att_id,
                'post_parent' => $dest_post_id,
            ), true);

            if (is_wp_error($ok)) {
                $skipped++;
                if ($this->logger) {
                    $this->logger->warning('Media Transfer: failed to re-parent attachment', array(
                        'attachment_id' => $att_id,
                        'error'         => $ok->get_error_message(),
                    ));
                }
                continue;
            }

		update_post_meta($att_id, '_dit_ts_media_source_owner', $source_post_id);
		update_post_meta($att_id, '_dit_ts_media_owner', $dest_post_id);

		$moved++;
	}

    // @MODIFIED 2026-05-07 - Write _dit_ts_images meta so Social_Bootstrap::get_post_image_urls()
    // can find them. Previously only the Scheduler auto_publish block wrote this meta, but if the
    // execution path reaches this service first (Plugin.php handle_auto_publish), _dit_ts_images
    // was never written, causing social posts with no images.
    // Query uses all three meta keys (consistent with primary transfer query) to prevent
    // cross-contamination if job IDs overlap across ideas.
    if ($moved > 0) {
        $all_managed = get_posts(array(
            'post_type' => 'attachment',
            'post_status' => 'inherit',
            'meta_query' => array(
                'relation' => 'AND',
                array('key' => '_dit_ts_media_job', 'value' => (string) $job_id, 'compare' => '='),
                array('key' => '_dit_ts_media_managed', 'value' => '1', 'compare' => '='),
                array('key' => '_dit_ts_media_owner', 'value' => (string) $dest_post_id, 'compare' => '='),
            ),
            'fields' => 'ids',
            'posts_per_page' => -1,
        ));
		if (!empty($all_managed)) {
			update_post_meta($dest_post_id, '_dit_ts_images', array_map('intval', $all_managed));
		}
	}

	if ($this->logger) {
            $this->logger->info('Media Transfer: completed', array(
                'source_post_id' => $source_post_id,
                'dest_post_id'   => $dest_post_id,
                'job_id'         => $job_id,
                'moved'          => $moved,
                'skipped'        => $skipped,
            ));
        }

        return array('moved' => $moved, 'skipped' => $skipped);
    }
}
