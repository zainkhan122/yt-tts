# DIT Video Shorts Module (optional)

Self-contained, additive module that turns DIT-generated posts into 60-second
Urdu-voiced vertical Shorts. It reuses DIT's **own** brand (logo + bar text),
**Urdu fonts**, logging, AI providers, Buffer sharing, and daily cleanup —
without modifying any DIT pipeline logic.

## Why it's safe
- **Optional**: master toggle (`dit_ts_video_enabled`). Off = zero effect.
- **Guarded**: every step is try/caught and logged via DIT's Logger; a missing
  dependency or any error never throws up the stack or breaks DIT.
- **No pipeline changes**: it only adds hooks (`dit_ts_video_generate` job,
  auto-generate on publish, `dit_ts_daily_cleanup`, a dashboard card, a "Video"
  submenu). DIT's own generation/sharing is untouched.

## How it fits DIT
1. A qualified post (DIT-generated, published, has images + Urdu heading) is queued.
2. `Script_AI` builds the narration script + YouTube title/description/hashtags,
   reusing DIT's `AI_Provider_Factory` (fallback to a deterministic Urdu script).
3. `Generator` gathers the post's images (featured + attached, quality-first),
   writes `narration.txt` + `manifest.json`, and runs `video-runner/render.mjs`.
4. `render.mjs` does Urdu TTS (Edge-TTS `ur-PK-UzmaNeural`, fast) + letterboxed
   Ken Burns scenes + heading/brand overlay (puppeteer) + ffmpeg concat/mux.
5. The video is attached to the post and `_dit_ts_video_id` is set — so DIT's
   **existing** Buffer `Queue_Manager` uploads it to YouTube and shares the
   collage/featured image to other channels. You publish, it shares.

## Requirements (VPS)
- PHP exec() enabled; Node.js >= 18; Python 3; ffmpeg; Chrome/Chromium.
- Urdu fonts already ship in `assets/fonts/` (Noto Nastaliq).
- Python: `pip install edge-tts` (Urdu). Optional: `pip install kokoro-onnx soundfile imageio-ffmpeg` (self-hosted TTS — NOTE: Kokoro has **no Urdu**; use Edge ur-PK for Urdu).
- Node: `cd video-runner && npm install` (puppeteer-core).

## Configuration (Admin → Trend Studio → Video Shorts)
- Enable, auto-generate on publish, TTS backend/voice/speed, max duration,
  **heading font size (independent of Social Collage)**, black-bar fit (no crop),
  runner dir override, cleanup age.
- **Diagnostics** table shows what's missing (node, python, ffmpeg, puppeteer,
  edge-tts, kokoro, Urdu font, brand logo).
- Actions: "Generate for all qualified", "Generate for latest", "Clean all".

## Files
```
src/Video/
  Module.php        entry point / hooks (singleton)
  Settings.php      option store (dit_ts_video_*)
  Brand.php         reuses DIT logo/bar-text/Urdu font
  Script_AI.php     narration + YT meta via DIT AI (or fallback)
  Generator.php     gather images, manifest, run runner, attach video, set meta
  Job_Manager.php   qualified-post detection + Action Scheduler queue
  Cleanup.php       delete videos + temp (hooks dit_ts_daily_cleanup)
  Diagnostics.php   dependency detection
  Admin.php         "Video Shorts" submenu + AJAX
video-runner/
  render.mjs        Node orchestrator (TTS + overlays + ffmpeg)
  tts.py            Edge-TTS Urdu (ur-PK-UzmaNeural)
  tts_kokoro.py     Kokoro (English/Hindi — no Urdu)
  package.json
```
