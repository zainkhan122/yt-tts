<?php

/**
 * R2 Storage Client (S3 Compatible)
 *
 * Handles uploading video files to Cloudflare R2 / S3.
 * Implements basic S3 Signature V4 for PutObject.
 *
 * @package    MCQ_Video_Studio
 * @subpackage Includes
 * @since      1.0.0
 */

if (! defined('ABSPATH')) {
    exit;
}

/**
 * Class VS_R2_Storage
 *
 * Minimal S3/R2 Uploader.
 *
 * @since 1.0.0
 */
class VS_R2_Storage
{

    private $endpoint;
    private $access_key;
    private $secret_key;
    private $bucket;
    private $region;

    public function __construct()
    {
        $this->endpoint   = get_option('mcqvs_r2_endpoint', ''); // e.g., https://<accountid>.r2.cloudflarestorage.com
        $this->access_key = get_option('mcqvs_r2_access_key', '');
        $this->secret_key = get_option('mcqvs_r2_secret_key', '');
        $this->bucket     = get_option('mcqvs_r2_bucket', '');
        $this->region     = 'auto'; // R2 uses auto
    }

    /**
     * Upload a file to R2.
     *
     * @param string $file_path Local path.
     * @param string $key Remote key (filename).
     * @param string $content_type Mime type.
     * @return string|WP_Error Public URL or Error.
     */
    public function upload_file($file_path, $key, $content_type = 'video/mp4')
    {
        if (empty($this->access_key) || empty($this->secret_key) || empty($this->endpoint)) {
            VS_Error_Logger::get_instance()->log('R2 Upload: Missing Config', 'error');
            return new WP_Error('missing_config', 'R2/S3 Credentials missing.');
        }

        if (!file_exists($file_path)) {
            VS_Error_Logger::get_instance()->log('R2 Upload: File not found', 'error', array('path' => $file_path));
            return new WP_Error('file_not_found', 'File does not exist: ' . $file_path);
        }

        $file_size = filesize($file_path);
        $uri = '/' . $this->bucket . '/' . $key;
        $host = parse_url($this->endpoint, PHP_URL_HOST);
        $url = $this->endpoint . $uri;

        $ctx = hash_init('sha256');
        $stream = fopen($file_path, 'rb');
        if (!$stream) {
            return new WP_Error('open_failed', 'Cannot open file: ' . $file_path);
        }
        while (!feof($stream)) {
            hash_update($ctx, fread($stream, 8192));
        }
        $payload_hash = hash_final($ctx);
        fclose($stream);

        $timestamp = gmdate('Ymd\THis\Z');
        $date = gmdate('Ymd');

        // @FIX: Include `content-type` in the signed headers so the canonical request
        //       actually matches what curl sends. Without this, S3v4 strict verifiers
        //       (Cloudflare R2 in particular) return SignatureDoesNotMatch intermittently.
        $headers = array(
            'host' => $host,
            'x-amz-content-sha256' => $payload_hash,
            'x-amz-date' => $timestamp,
            'content-type' => $content_type,
        );

        ksort($headers);
        $canonical_headers = '';
        $signed_headers = '';
        foreach ($headers as $k => $v) {
            $canonical_headers .= $k . ':' . $v . "\n";
            $signed_headers .= $k . ';';
        }
        $signed_headers = rtrim($signed_headers, ';');

        $canonical_request = "PUT\n{$uri}\n\n{$canonical_headers}\n{$signed_headers}\n{$payload_hash}";

        $algorithm = 'AWS4-HMAC-SHA256';
        $credential_scope = "{$date}/{$this->region}/s3/aws4_request";
        $string_to_sign = "{$algorithm}\n{$timestamp}\n{$credential_scope}\n" . hash('sha256', $canonical_request);

        $k_secret = 'AWS4' . $this->secret_key;
        $k_date = hash_hmac('sha256', $date, $k_secret, true);
        $k_region = hash_hmac('sha256', $this->region, $k_date, true);
        $k_service = hash_hmac('sha256', 's3', $k_region, true);
        $k_signing = hash_hmac('sha256', 'aws4_request', $k_service, true);
        $signature = hash_hmac('sha256', $string_to_sign, $k_signing);

        $authorization = "{$algorithm} Credential={$this->access_key}/{$credential_scope}, SignedHeaders={$signed_headers}, Signature={$signature}";

        $ch = curl_init($url);
        $fp = fopen($file_path, 'rb');
        if (!$fp) {
            return new WP_Error('open_failed', 'Cannot open file for upload: ' . $file_path);
        }

        curl_setopt_array($ch, array(
            CURLOPT_PUT => true,
            CURLOPT_INFILE => $fp,
            CURLOPT_INFILESIZE => $file_size,
            CURLOPT_HTTPHEADER => array(
                "Authorization: {$authorization}",
                "x-amz-date: {$timestamp}",
                "x-amz-content-sha256: {$payload_hash}",
                "Content-Type: {$content_type}",
                "Host: {$host}",
            ),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 300,
            CURLOPT_SSL_VERIFYPEER => true,
        ));

        $start_time = microtime(true);
        $response_body = curl_exec($ch);
        $duration = microtime(true) - $start_time;
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch);
        fclose($fp);
        curl_close($ch);

        VS_Error_Logger::get_instance()->log_api($url, 'PUT', array('key' => $key, 'size' => $file_size), array('code' => $http_code), $duration);

        if ($curl_error) {
            VS_Error_Logger::get_instance()->log('R2 Upload cURL Error', 'error', array('error' => $curl_error));
            return new WP_Error('curl_error', $curl_error);
        }

        if ($http_code !== 200) {
            $msg = 'R2 Upload Failed: ' . $http_code . ' ' . substr($response_body, 0, 500);
            VS_Error_Logger::get_instance()->log('R2 Upload Failed', 'error', array('code' => $http_code, 'msg' => $msg));
            return new WP_Error('upload_failed', $msg);
        }

        $public_domain = trim((string) get_option('mcqvs_r2_public_domain', ''));
        if ($public_domain === '') {
            // @FIX: Previously we fell back to `endpoint/bucket` (the R2 API URL) — invalid for
            //       public playback and silently broken in Buffer. Reject the upload instead and
            //       require the operator to configure the public CDN/Workers domain.
            VS_Error_Logger::get_instance()->log('R2 Upload: Missing public domain', 'error', array(
                'hint' => 'Configure the R2 public domain (Workers custom domain or public bucket) under Settings > Cloudflare R2.',
            ));
            return new WP_Error('missing_public_domain', 'R2 public domain not configured. Set the public-facing CDN URL in Settings > Cloudflare R2 (`mcqvs_r2_public_domain`). Bucket/key are: ' . $this->bucket . '/' . $key);
        }

        return rtrim($public_domain, '/') . '/' . $key;
    }

    /**
     * Test R2 connection by performing a HEAD request for a dummy object.
     *
     * This method verifies credentials and endpoint without uploading any data.
     * It expects a 404 Not Found if the dummy object doesn't exist (successful authentication),
     * or a 403 Forbidden if authentication fails or access is denied.
     *
     * @return true|WP_Error True on successful connection (404/200), WP_Error on failure.
     */
    public function test_connection()
    {
        if (empty($this->access_key) || empty($this->secret_key) || empty($this->endpoint) || empty($this->bucket)) {
            return new WP_Error('missing_config', 'R2/S3 credentials or bucket missing.');
        }

        // Also validate the public domain is not empty and doesn't match the WP site host.
        $public_domain = trim((string) get_option('mcqvs_r2_public_domain', ''));
        if (empty($public_domain)) {
            return new WP_Error('missing_public_domain', 'R2 public domain not configured. Set mcqvs_r2_public_domain in Settings > Cloudflare R2.');
        }
        $pd_host   = wp_parse_url($public_domain, PHP_URL_HOST);
        $site_host = wp_parse_url(home_url(), PHP_URL_HOST);
        if ($pd_host && $site_host && strtolower($pd_host) === strtolower($site_host)) {
            return new WP_Error('public_domain_is_site', 'R2 public domain points at this WordPress site (' . $site_host . '). Videos will be unplayable. Set a Cloudflare Workers custom domain or enable Public Bucket on the R2 bucket and use the generated URL.');
        }

        $dummy_key = 'mcqvs-test-connection-dummy-object'; // A key that should not exist
        $uri = '/' . $this->bucket . '/' . $dummy_key;
        $host = parse_url($this->endpoint, PHP_URL_HOST);
        $url = $this->endpoint . $uri;

        $timestamp = gmdate('Ymd\THis\Z');
        $date = gmdate('Ymd');

        // For HEAD, payload hash is 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' (empty string SHA256)
        $payload_hash = 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855';

        $headers = array(
            'host' => $host,
            'x-amz-content-sha256' => $payload_hash,
            'x-amz-date' => $timestamp,
        );

        ksort($headers);
        $canonical_headers = '';
        $signed_headers = '';
        foreach ($headers as $k => $v) {
            $canonical_headers .= $k . ':' . $v . "\n";
            $signed_headers .= $k . ';';
        }
        $signed_headers = rtrim($signed_headers, ';');

        $canonical_request = "HEAD\n{$uri}\n\n{$canonical_headers}\n{$signed_headers}\n{$payload_hash}";

        $algorithm = 'AWS4-HMAC-SHA256';
        $credential_scope = "{$date}/{$this->region}/s3/aws4_request";
        $string_to_sign = "{$algorithm}\n{$timestamp}\n{$credential_scope}\n" . hash('sha256', $canonical_request);

        $k_secret = 'AWS4' . $this->secret_key;
        $k_date = hash_hmac('sha256', $date, $k_secret, true);
        $k_region = hash_hmac('sha256', $this->region, $k_date, true);
        $k_service = hash_hmac('sha256', 's3', $k_region, true);
        $k_signing = hash_hmac('sha256', 'aws4_request', $k_service, true);
        $signature = hash_hmac('sha256', $string_to_sign, $k_signing);

        $authorization = "{$algorithm} Credential={$this->access_key}/{$credential_scope}, SignedHeaders={$signed_headers}, Signature={$signature}";

        $ch = curl_init($url);

        curl_setopt_array($ch, array(
            CURLOPT_CUSTOMREQUEST => 'HEAD',
            CURLOPT_NOBODY => true, // Only fetch headers
            CURLOPT_HTTPHEADER => array(
                "Authorization: {$authorization}",
                "x-amz-date: {$timestamp}",
                "x-amz-content-sha256: {$payload_hash}",
                "Host: {$host}",
            ),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 10, // Shorter timeout for connection test
            CURLOPT_SSL_VERIFYPEER => true,
        ));

        curl_exec($ch); // Response body is not needed for HEAD
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch);
        curl_close($ch);

        if ($curl_error) {
            return new WP_Error('curl_error', 'R2 Test cURL Error: ' . $curl_error);
        }

        // Expected codes: 200 (if dummy object exists unexpectedly), 404 (object not found, success), 403 (unauthorized)
        if (in_array($http_code, array(200, 404))) {
            return true; // Connection successful (dummy object not found, or found and accessible)
        } else {
            return new WP_Error('connection_failed', 'R2 Test Failed: Endpoint returned: ' . $http_code);
        }
    }
}

