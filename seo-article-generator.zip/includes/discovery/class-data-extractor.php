<?php

namespace SEO_Article_Generator\Discovery;

require_once __DIR__ . '/../generator/class-download-content.php';

/**
 * Data Extractor - Pre-AI Grounding Truth Discovery
 * 
 * Extracts links, versions, and technical metadata from raw HTML 
 * to ground the AI and provide a "Clean Plate" for generation.
 *
 * @package SEO_Article_Generator\Discovery
 * @since   2.22.6
 */
class Data_Extractor
{
	public static function extract($html, array $args = array())
	{
		$data = array(
			'version' => '',
			'file_size' => '',
			'trial_link' => '',
			'direct_link' => '',
			'portal_link' => '',
			'license' => '',
			'developer' => '',
			'homepage_url' => '',
			'changelog_url' => '',
			'all_links' => array(),
			'rejected_links' => array(),
			'metadata_links' => array(),
			'primary_text' => '',
			'grounding_hints' => array(),
			'target_platforms'=> array(),
			'os_support' => '',
		);

		if (empty($html)) {
			return $data;
		}

		$dom = self::load_dom($html);
		$xpath = $dom ? new \DOMXPath($dom) : null;

		// 1. Primary Text Discovery (XPath based)
		$data['primary_text'] = self::extract_primary_text($xpath, $dom, $html);

		// Prefer a recognized product Download Zone; metadata is still extracted from the full DOM.
		$scope = \SEO_Article_Generator\Generator\Download_Content::inspect((string)$html, (string)($args['software_name'] ?? ''));
		$link_html = $scope['found'] ? $scope['html'] : (string)$html;

		// 2. Deterministic Link Resolution
		$resolved = class_exists('\\SEO_Article_Generator\\Integration\\Link_Resolver')
			? \SEO_Article_Generator\Integration\Link_Resolver::resolve_from_html($link_html, $args)
			: array();

		if (!class_exists('\\SEO_Article_Generator\\Integration\\Link_Resolver')) {
			$link_dom = self::load_dom($link_html);
			$link_xpath = $link_dom ? new \DOMXPath($link_dom) : null;
			$fallback_links = self::normalize_fallback_links(
				self::extract_links($link_xpath, $link_dom, $link_html)
			);

			$resolved = array(
				'links' => $fallback_links,
				'rejected_links' => array(),
				'metadata_links' => array(),
				'grounding_hints' => array(),
				'target_platforms' => array(),
				'os_support' => '',
			);
		}

		$data['all_links'] = \SEO_Article_Generator\Generator\Download_Link_Helper::normalize_links($resolved['links'] ?? array(), 'Other');
		// Embedded source facts are a producer too; classify them through the same contract.
		if (preg_match('/<!--\s*seo_gen_facts:\s*(\{.*?\})\s*-->/s', (string) $html, $facts_match)) {
			$inline = json_decode($facts_match[1], true);
			$inline_links = is_array($inline) && is_array($inline['resolved_links'] ?? null) ? $inline['resolved_links'] : array();
			$data['all_links'] = \SEO_Article_Generator\Generator\Download_Link_Helper::reconcile_source_links($data['all_links'], $inline_links);
		}
		$data['rejected_links'] = $resolved['rejected_links'] ?? array();
		$data['metadata_links'] = $resolved['metadata_links'] ?? array();
		$data['grounding_hints'] = $resolved['grounding_hints'] ?? array();
		$data['target_platforms'] = \SEO_Article_Generator\Generator\Download_Link_Helper::link_platforms($data['all_links']);
		$data['os_support'] = implode(', ', $data['target_platforms']);

		// 3. Link convenience fields
		foreach ($data['all_links'] as $link) {
			if (empty($data['direct_link']) && (($link['link_type'] ?? '') === 'direct')) {
				$data['direct_link'] = $link['url'];
			}
			if (empty($data['portal_link']) && (($link['link_type'] ?? '') === 'portal')) {
				$data['portal_link'] = $link['url'];
			}
			if (empty($data['trial_link']) && stripos((string) ($link['variant'] ?? ''), 'trial') !== false) {
				$data['trial_link'] = $link['url'];
			}
		}

		// 4. Recover metadata links (homepage, changelog) from rejected links
		$recovered = self::recover_metadata_links($data['rejected_links'], $dom, $xpath, (string) $html);
		if (!empty($recovered['homepage_url'])) {
			$data['homepage_url'] = $recovered['homepage_url'];
		}
		if (!empty($recovered['changelog_url'])) {
			$data['changelog_url'] = $recovered['changelog_url'];
		}
		if (!empty($recovered['metadata_links'])) {
			$existing_urls = array();
			foreach ($data['metadata_links'] as $ml) {
				$existing_urls[strtolower((string) ($ml['url'] ?? ''))] = true;
			}
			foreach ($recovered['metadata_links'] as $ml) {
				$key = strtolower((string) ($ml['url'] ?? ''));
				if (!isset($existing_urls[$key])) {
					$data['metadata_links'][] = $ml;
					$existing_urls[$key] = true;
				}
			}
		}

		// 5. DOM-based homepage / changelog extraction (stronger than rejected-link recovery)
		$dom_homepage = self::extract_homepage_url($xpath, $dom, (string) $html);
		if (!empty($dom_homepage) && empty($data['homepage_url'])) {
			$data['homepage_url'] = $dom_homepage;
		}
		$dom_changelog = self::extract_changelog_url($xpath, $dom, (string) $html);
		if (!empty($dom_changelog) && empty($data['changelog_url'])) {
			$data['changelog_url'] = $dom_changelog;
		}

		// 5b. Purge metadata links from the extracted download links pool
		$metadata_urls = array();
		if (!empty($data['homepage_url'])) {
			$metadata_urls[strtolower(trim($data['homepage_url'], '/'))] = true;
		}
		if (!empty($data['changelog_url'])) {
			$metadata_urls[strtolower(trim($data['changelog_url'], '/'))] = true;
		}

		if (!empty($metadata_urls) && !empty($data['all_links'])) {
			$filtered_links = array();
			foreach ($data['all_links'] as $link) {
				$url = strtolower(trim((string) ($link['url'] ?? ''), '/'));
				if (!isset($metadata_urls[$url]) || !empty($link['_bypass_homepage_guard'])) {
					$filtered_links[] = $link;
				} else {
					$data['rejected_links'][] = $link;
				}
			}
			$data['all_links'] = $filtered_links;
		}

		$data['all_links'] = \SEO_Article_Generator\Generator\Download_Link_Helper::normalize_links($data['all_links'], 'Other');
		$data['target_platforms'] = \SEO_Article_Generator\Generator\Download_Link_Helper::link_platforms($data['all_links']);
		$data['os_support'] = implode(', ', $data['target_platforms']);
		$data['direct_link'] = $data['portal_link'] = $data['trial_link'] = '';
		$data['grounding_hints'] = array();
		foreach ($data['all_links'] as $link) {
			$type = ($link['link_type'] ?? '') === 'portal' ? 'portal_link' : 'direct_link';
			if ($data[$type] === '') $data[$type] = $link['url'];
			if ($data['trial_link'] === '' && stripos($link['variant'], 'trial') !== false) $data['trial_link'] = $link['url'];
			if ($link['platform'] !== 'Other') $data['grounding_hints'][strtolower($link['platform'])][] = $link;
		}

		// 6. Metadata Extraction (Focus on primary text, fallback to full HTML for file_size)
		$full_text = \wp_strip_all_tags((string) $html);
		$search_text = $data['primary_text'] ?: $full_text;
		$data['version'] = self::extract_version($search_text);
		$data['file_size'] = self::extract_file_size($search_text);
		if ($data['file_size'] === '' && $search_text !== $full_text) {
			$data['file_size'] = self::extract_file_size($full_text);
		}
		$data['license'] = self::extract_license($search_text);
		$data['developer'] = self::extract_developer($search_text);

		return $data;
	}

	/**
	 * Extract all discoverable URLs from HTML.
     * Handles: standard anchors, lazy-loaded href variants, button data attributes,
     * and any element carrying a data-download-url or data-href attribute.
     * Results are deduplicated by normalized URL.
     *
     * @param \DOMXPath|null $xpath
     * @param \DOMDocument|null $dom
     * @param string $html
     * @return array  [ ['url' => string, 'text' => string], ... ]
     */
    private static function extract_links( $xpath, $dom, string $html ): array {
        $links     = [];
        $seen_urls = [];

        $add = static function ( string $url, string $text ) use ( &$links, &$seen_urls ) {
            $url = trim( $url );
            if ( empty( $url ) || ! \filter_var( $url, FILTER_VALIDATE_URL ) ) {
                return;
            }
            $key = strtolower( $url );
            if ( isset( $seen_urls[ $key ] ) ) {
                return;
            }
            $links[]          = [ 'url' => $url, 'text' => self::normalize_text( $text ) ];
            $seen_urls[ $key ] = true;
        };

        if ( $dom ) {
            // 1. Standard anchor tags + lazy-loaded href variants
            $data_href_attrs = [ 'data-href', 'data-url', 'data-link', 'data-download', 'data-download-url' ];
            foreach ( $dom->getElementsByTagName( 'a' ) as $node ) {
                $href = trim( $node->getAttribute( 'href' ) );
                if ( empty( $href ) || strpos( $href, 'http' ) !== 0 ) {
                    // Try common lazy-load / JS-driven href alternatives
                    foreach ( $data_href_attrs as $attr ) {
                        $val = trim( $node->getAttribute( $attr ) );
                        if ( $val && strpos( $val, 'http' ) === 0 ) {
                            $href = $val;
                            break;
                        }
                    }
                }
                $add( $href, $node->textContent );
            }

            // 2. Button elements with data-url / data-href (download portal buttons)
            foreach ( $dom->getElementsByTagName( 'button' ) as $button ) {
                foreach ( $data_href_attrs as $attr ) {
                    $val = trim( $button->getAttribute( $attr ) );
                    if ( $val ) {
                        $add( $val, $button->textContent );
                        break; // First found wins per button
                    }
                }
            }

            // 3. XPath scan: any element carrying a download-relevant data attribute
            // Covers custom widgets, React-rendered download cards, etc.
            if ( $xpath ) {
                $data_attr_query = '//*[@data-download-url or @data-direct-url or @data-portal-url]';
                $nodes = $xpath->query( $data_attr_query );
                if ( $nodes ) {
                    foreach ( $nodes as $node ) {
                        if ($node instanceof \DOMElement) {
                            foreach ( [ 'data-download-url', 'data-direct-url', 'data-portal-url' ] as $attr ) {
                                $val = trim( $node->getAttribute( $attr ) );
                                if ( $val ) {
                                    $add( $val, $node->textContent );
                                }
                            }
                        }
                    }
                }
            }
        }

        // Regex fallback (only used when DOM parsing fails entirely)
        if ( empty( $links ) ) {
            // Standard anchors
            if ( preg_match_all( '/href=["\'](https?:\/\/[^"\'> ]+)["\'][^>]*>(.*?)<\/a>/is', $html, $m ) ) {
                foreach ( $m[1] as $i => $url ) { // @FIXED: AI formatting artifact
                    $add( $url, $m[2][ $i ] );
                }
            }
            // data-* download attributes on any element
            if ( preg_match_all(
                '/data-(?:download-url|direct-url|portal-url|url|href)=["\'](https?:\/\/[^"\'> ]+)["\']/i',
                $html,
                $m
            ) ) {
                foreach ( $m[1] as $url ) { // @FIXED: AI formatting artifact
                    $add( $url, '' );
                }
            }
        }

        return $links;
    }

    private static function categorize_links($all_links)
    {
        $categorized = array(
            'windows' => array(),
            'macos'   => array(),
            'linux'   => array(),
            'android' => array(),
            'ios'     => array(),
            'trial'   => array(),
        );

        foreach ((array) $all_links as $link) {
            $platform = strtolower((string) ($link['platform'] ?? ''));
            if ($platform === 'windows') {
                $categorized['windows'][] = $link;
            } elseif ($platform === 'macos') {
                $categorized['macos'][] = $link;
            } elseif ($platform === 'linux') {
                $categorized['linux'][] = $link;
            } elseif ($platform === 'android') {
                $categorized['android'][] = $link;
            } elseif ($platform === 'ios') {
                $categorized['ios'][] = $link;
            }

            if (stripos((string) ($link['variant'] ?? ''), 'trial') !== false) {
                $categorized['trial'][] = $link['url'];
            }
        }

        return \array_filter($categorized);
    }

    private static function extract_version($text)
    {
        $patterns = array(
            '/Version\s*[:\-]?\s*(\d+(?:\.\d+)+)/i',
            '/v\s*(\d+(?:\.\d+)+)/i',
            '/release\s*(\d+(?:\.\d+)+)/i',
            '/(\d+(?:\.\d+){2,})/i', // Strong pattern: 1.2.3
        );

        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $text, $matches)) {
                return trim($matches[1]);
            }
        }

        return '';
    }

    private static function extract_file_size($text)
    {
        $patterns = array(
            '/Size\s*[:\-]?\s*([\d.,]+\s*(?:MB|GB|KB|Bytes))/i',
            '/([\d.,]+\s*(?:MB|GB|KB))/i',
        );

        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $text, $matches)) {
                return trim($matches[1]);
            }
        }

        return '';
    }

    private static function extract_license($text)
    {
        if (preg_match('/(?:license|licence)\s*[:\-]\s*(\w+)/i', $text, $matches)) {
            return $matches[1];
        }
        if (preg_match('/(freeware|open source|gpl|mit|trial|demo|shareware|paid)/i', $text, $matches)) {
            return ucfirst(strtolower($matches[1]));
        }
        return '';
    }

    private static function extract_developer($text)
    {
        if (preg_match('/(?:developer|author|by)\s*[:\-]\s*([A-Za-z0-9\s.]{2,30})/i', $text, $matches)) {
            return trim($matches[1]);
        }
        return '';
    }

	private static function extract_homepage_url($xpath, $dom, string $html): string
	{
		$patterns = array(
			'/\b(?:homepage|home\s*page|official\s*(?:page|site|website|url)|product\s*page|developer\s*(?:site|url))\b/i',
		);

		if ($dom) {
			foreach ($dom->getElementsByTagName('a') as $node) {
				$href = trim($node->getAttribute('href'));
				if ($href === '' || strpos($href, 'http') !== 0) {
					continue;
				}
				$anchor_text = self::normalize_text($node->textContent);
				foreach ($patterns as $pat) {
					if (preg_match($pat, $anchor_text)) {
						return $href;
					}
				}
				$parent = $node->parentNode;
				if ($parent instanceof \DOMElement) {
					$parent_text = self::normalize_text($parent->textContent);
					foreach ($patterns as $pat) {
						if (preg_match($pat, $parent_text) && !preg_match('/\b(?:download|changelog|changes|release)/i', $parent_text)) {
							return $href;
						}
					}
				}
			}
		}

		if (preg_match_all('/href=["\'](https?:\/\/[^"\'> ]+)["\'][^>]*>(.*?)<\/a>/is', $html, $m)) {
			foreach ($m[1] as $i => $url) {
				$text = self::normalize_text($m[2][$i]);
				foreach ($patterns as $pat) {
					if (preg_match($pat, $text)) {
						return $url;
					}
				}
			}
		}

		if (preg_match('/(?:homepage|home\s*page)\s*[–\x{2013}\x{2014}\-:]\s*(https?:\/\/[^\s<"]+)/iu', $html, $m)) {
			return trim($m[1]);
		}

		return '';
	}

	private static function extract_changelog_url($xpath, $dom, string $html): string
	{
		$text_patterns = array(
			'/\b(?:changelog|changes|release\s*notes|what[\s\'-]*s\s*new|update\s*log|fixed\s*issues|version\s*history)\b/i',
		);
		$url_patterns = array(
			'~/changelog~i',
			'~/release-?notes~i',
			'~/update-?log~i',
			'~/whats-?new~i',
			'~/fixed-?issues~i',
			'~/kb/fixed~i',
			'~/history~i',
		);

		if ($dom) {
			foreach ($dom->getElementsByTagName('a') as $node) {
				$href = trim($node->getAttribute('href'));
				if ($href === '' || strpos($href, 'http') !== 0) {
					continue;
				}
				$anchor_text = self::normalize_text($node->textContent);
				foreach ($text_patterns as $pat) {
					if (preg_match($pat, $anchor_text)) {
						return $href;
					}
				}
				foreach ($url_patterns as $pat) {
					if (preg_match($pat, $href)) {
						return $href;
					}
				}
			}
		}

		if (preg_match_all('/href=["\'](https?:\/\/[^"\'> ]+)["\'][^>]*>(.*?)<\/a>/is', $html, $m)) {
			foreach ($m[1] as $i => $url) {
				$text = self::normalize_text($m[2][$i]);
				foreach ($text_patterns as $pat) {
					if (preg_match($pat, $text)) {
						return $url;
					}
				}
				foreach ($url_patterns as $pat) {
					if (preg_match($pat, $url)) {
						return $url;
					}
				}
			}
		}

		return '';
	}

	private static function recover_metadata_links(array $rejected_links, $dom, $xpath, string $html): array
	{
		$result = array(
			'homepage_url' => '',
			'changelog_url' => '',
			'metadata_links' => array(),
		);

		$homepage_text_pat = '/\b(?:homepage|home\s*page|official\s*(?:page|site|website|url)|product\s*page)\b/i';
		$changelog_text_pat = '/\b(?:changelog|changes|release\s*notes|what[\s\'-]*s\s*new|update\s*log|fixed\s*issues|version\s*history)\b/i';
		$changelog_url_pat = '~/(?:changelog|release-?notes|update-?log|whats-?new|fixed-?issues|kb/fixed|history)~i';

		foreach ($rejected_links as $link) {
			$url = (string) ($link['url'] ?? '');
			$text = (string) ($link['text'] ?? '');
			if ($url === '' || !filter_var($url, FILTER_VALIDATE_URL)) {
				continue;
			}
			if (empty($result['homepage_url']) && preg_match($homepage_text_pat, $text)) {
				$result['homepage_url'] = $url;
				$result['metadata_links'][] = array('url' => $url, 'type' => 'homepage', 'text' => $text);
				continue;
			}
			if (empty($result['changelog_url']) && (preg_match($changelog_text_pat, $text) || preg_match($changelog_url_pat, $url))) {
				$result['changelog_url'] = $url;
				$result['metadata_links'][] = array('url' => $url, 'type' => 'changelog', 'text' => $text);
				continue;
			}
		}

		return $result;
	}

	private static function load_dom($html)
    {
        $html = (string) $html;
        if (trim($html) === '') {
            return null;
        }

        $dom = new \DOMDocument();

        \libxml_use_internal_errors(true);
        $loaded = $dom->loadHTML('<?xml encoding="utf-8" ?>' . $html, LIBXML_NOWARNING | LIBXML_NOERROR);
        \libxml_clear_errors();

        return $loaded ? $dom : null;
    }

    private static function extract_primary_text($xpath, $dom, $html)
    {
        if (!$xpath) {
            return self::normalize_text(\wp_strip_all_tags($html));
        }

        $queries = array(
            '//main',
            '//*[@role="main"]',
            '//*[@id="content"]',
            '//*[@id="main"]',
            '//*[contains(concat(" ", normalize-space(@class), " "), " entry-content ")]',
            '//*[contains(concat(" ", normalize-space(@class), " "), " post-content ")]',
            '//*[contains(concat(" ", normalize-space(@class), " "), " article-content ")]',
            '//*[contains(concat(" ", normalize-space(@class), " "), " td-post-content ")]',
            '//*[contains(concat(" ", normalize-space(@class), " "), " changelog ")]',
        );

        foreach ($queries as $query) {
            $nodes = $xpath->query($query);
            if (!$nodes || !$nodes->length) {
                continue;
            }

            foreach ($nodes as $node) {
                $text = self::normalize_text($node->textContent);
                if (mb_strlen($text) >= 200) {
                    return $text;
                }
            }
        }

        $bodyNodes = $dom->getElementsByTagName('body');
        if ($bodyNodes->length > 0) {
            return self::normalize_text($bodyNodes->item(0)->textContent);
        }

        return self::normalize_text(\wp_strip_all_tags($html));
    }

    private static function normalize_text($text)
    {
        $text = html_entity_decode(\wp_strip_all_tags((string) $text), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = preg_replace('/\s+/u', ' ', $text);
        return trim($text);
    }

    /**
     * Normalize raw extracted links into the Link_Resolver output format.
     *
     * @param array $links Raw links from extract_links().
     * @return array Normalized links with url, text, platform, variant, link_type.
     */
        private static function normalize_fallback_links(array $links): array
    {
        $normalized = array();
        $has_resolver = class_exists('\\SEO_Article_Generator\\Integration\\Link_Resolver');

        foreach ($links as $link) {
            $text = strtolower((string) ($link['text'] ?? ''));
            $url  = (string) ($link['url'] ?? '');

            if ($url === '') {
                continue;
            }

            if ($has_resolver) {
                $host = \SEO_Article_Generator\Integration\Link_Resolver::host($url);
                if (
                    \SEO_Article_Generator\Integration\Link_Resolver::is_noisy_or_social($url, $host) ||
                    \SEO_Article_Generator\Integration\Link_Resolver::is_non_download_path($url)
                ) {
                    continue;
                }
            }

            $link_type = 'portal';
            // @FIXED 2026-09-14: Also check URL path for "download" keyword (not just link text).
            // Dynamic download pages like browser.yandex.com/download/?full=1 have "download"
            // in the URL path but the link text may say "Windows" or "Get Yandex Browser".
            // Also check the download allowlist — admin-configured domains are always legitimate.
            $is_download_url = (
                strpos($text, 'download') !== false
                || stripos($url, '/download') !== false
                || stripos($url, 'download') !== false
                || preg_match('/\.(exe|msi|msp|zip|dmg|pkg|apk|deb|rpm|appimage|flatpak|snap)(\?|$)/i', $url)
            );
            if ( ! $is_download_url
                && class_exists('\SEO_Article_Generator\Generator\Download_Link_Helper')
                && \SEO_Article_Generator\Generator\Download_Link_Helper::is_url_in_allowlist($url)
            ) {
                $is_download_url = true; // Allowlisted domain — treat as download link
            }
            if ($is_download_url) {
                $link_type = 'direct';
            }

            $variant = (strpos($text, 'trial') !== false) ? 'Trial' : 'Standard';

            $normalized[] = array(
                'url'       => $url,
                'text'      => (string) ($link['text'] ?? ''),
                'platform'  => '',
                'variant'   => $variant,
                'link_type' => $link_type,
            );
        }

        return $normalized;
    }
}
