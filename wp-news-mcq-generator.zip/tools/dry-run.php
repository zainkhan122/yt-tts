<?php
/**
 * Dry run for the 9.5.2 fixes. Loads the REAL plugin classes against an in-memory
 * WordPress stub layer and asserts the new behaviour end-to-end (no live site needed).
 *
 * Run: php tools/dry-run-9.5.2.php
 */

error_reporting(E_ALL & ~E_DEPRECATED);
define('ABSPATH', '/tmp/wp/');
define('DAY_IN_SECONDS', 86400);

/* ------------------------------------------------------------------ */
/* In-memory WordPress                                                  */
/* ------------------------------------------------------------------ */
$GLOBALS['db'] = array(
	'posts'      => array(),  // id => [post_type, post_status, post_author, post_name, title, modified_ts, date_ts]
	'meta'       => array(),  // id => [key => value]
	'terms'      => array(),  // taxonomy => [slug => [term_id, name]]
	'next_post'  => 1000,
	'next_term'  => 90,
	'inserts'    => array(),  // recorded wp_insert_post args
	'updates'    => array(),  // recorded wp_update_post args
	'obj_terms'  => array(),  // recorded wp_set_object_terms calls
	'categories' => array(),  // recorded wp_set_post_categories calls
	'options'    => array(
		'nm_article_authors'   => array(2, 3, 4),
		'nm_scheduler_enabled' => 0,
		'blogname'             => 'TheQuizWire',
	),
	'users'      => array(
		1 => 'Zain',
		2 => 'Ayesha Raza',
		3 => 'Bilal Ahmed',
		4 => 'Sara Khan',
	),
	'wpq_handler' => null,
);

class WP_Error {
	private $c; private $m;
	public function __construct($c = '', $m = '') { $this->c = $c; $this->m = $m; }
	public function get_error_message() { return $this->m; }
}
function is_wp_error($t) { return $t instanceof WP_Error; }

class WP_Query {
	public $posts = array(); public $found_posts = 0;
	public function __construct($args = array()) {
		$h = $GLOBALS['db']['wpq_handler'];
		if (is_callable($h)) { $this->posts = (array) $h($args); }
		$this->found_posts = count($this->posts);
	}
}

/* --- options / users --- */
function get_option($k, $d = false) { return array_key_exists($k, $GLOBALS['db']['options']) ? $GLOBALS['db']['options'][$k] : $d; }
function update_option($k, $v) { $GLOBALS['db']['options'][$k] = $v; return true; }
function get_users($a = array()) {
	if (isset($a['role']) && $a['role'] === 'author') { return array(2, 3, 4); }
	if (isset($a['role']) && $a['role'] === 'administrator') { return array(1); }
	return array();
}
function get_userdata($id) {
	if (! isset($GLOBALS['db']['users'][$id])) { return false; }
	return (object) array('ID' => $id, 'display_name' => $GLOBALS['db']['users'][$id]);
}
function get_current_user_id() { return 1; /* Zain */ }
function get_bloginfo($k = 'name') { return $GLOBALS['db']['options']['blogname']; }

/* --- posts --- */
function wp_insert_post($args, $wp_error = false) {
	$id = ++$GLOBALS['db']['next_post'];
	$GLOBALS['db']['posts'][$id] = array_merge(array(
		'post_type' => 'post', 'post_status' => 'draft', 'post_author' => 0,
		'post_name' => '', 'post_title' => '', 'modified_ts' => time(), 'date_ts' => time(),
	), $args);
	$GLOBALS['db']['inserts'][] = array('id' => $id, 'args' => $args);
	return $id;
}
function wp_update_post($args, $wp_error = false) {
	$id = (int) $args['ID'];
	if (isset($GLOBALS['db']['posts'][$id])) {
		$GLOBALS['db']['posts'][$id] = array_merge($GLOBALS['db']['posts'][$id], $args);
		$GLOBALS['db']['posts'][$id]['modified_ts'] = time();
	}
	$GLOBALS['db']['updates'][] = $args;
	return $id;
}
function get_post($id) {
	$p = isset($GLOBALS['db']['posts'][$id]) ? $GLOBALS['db']['posts'][$id] : null;
	return $p ? (object) array_merge(array('ID' => $id), $p) : null;
}
function get_post_field($f, $id) { $p = $GLOBALS['db']['posts'][$id] ?? null; return $p[$f] ?? ''; }
function get_post_status($id) { $p = $GLOBALS['db']['posts'][$id] ?? null; return $p ? $p['post_status'] : false; }
function get_post_type($id) { $p = $GLOBALS['db']['posts'][$id] ?? null; return $p ? $p['post_type'] : false; }
function get_the_title($id) { $p = $GLOBALS['db']['posts'][$id] ?? null; return $p ? ($p['post_title'] ?? '') : ''; }
function get_permalink($id) {
	$p = $GLOBALS['db']['posts'][$id] ?? null;
	if (! $p) { return false; }
	if ($p['post_status'] !== 'publish') { return 'https://thequizwire.com/?post_type=' . $p['post_type'] . '&p=' . $id; }
	$base = $p['post_type'] === 'mcq' ? '/mcq/' : '/';
	return 'https://thequizwire.com' . $base . $p['post_name'] . '/';
}
function get_post_timestamp($id, $field = 'date') {
	$p = $GLOBALS['db']['posts'][$id] ?? null;
	if (! $p) { return false; }
	return $field === 'modified' ? ($p['modified_ts'] ?? false) : ($p['date_ts'] ?? false);
}
function get_post_thumbnail_id($id) { return 0; }

/* --- meta --- */
function update_post_meta($id, $k, $v) { $GLOBALS['db']['meta'][$id][$k] = $v; return true; }
function get_post_meta($id, $k, $single = false) { return $GLOBALS['db']['meta'][$id][$k] ?? ''; }
function delete_post_meta($id, $k) { unset($GLOBALS['db']['meta'][$id][$k]); return true; }

/* --- terms --- */
function term_exists($term, $tax = '', $parent = 0) {
	foreach ($GLOBALS['db']['terms'][$tax] ?? array() as $slug => $t) {
		if ($slug === $term || $t['name'] === $term || $t['term_id'] == $term) { return array('term_id' => $t['term_id']); }
	}
	return false;
}
function wp_insert_term($name, $tax, $args = array()) {
	$id = ++$GLOBALS['db']['next_term'];
	$slug = $args['slug'] ?? strtolower(str_replace(' ', '-', $name));
	$GLOBALS['db']['terms'][$tax][$slug] = array('term_id' => $id, 'name' => $name);
	return array('term_id' => $id);
}
function get_term($id, $tax = '') {
	foreach ($GLOBALS['db']['terms'][$tax] ?? array() as $slug => $t) {
		if ($t['term_id'] == $id) { return (object) array('term_id' => $id, 'name' => $t['name'], 'slug' => $slug, 'description' => ''); }
	}
	return null;
}
function get_term_by($by, $val, $tax) {
	foreach ($GLOBALS['db']['terms'][$tax] ?? array() as $slug => $t) {
		if (($by === 'name' && $t['name'] === $val) || ($by === 'slug' && $slug === $val)) {
			return (object) array('term_id' => $t['term_id'], 'name' => $t['name'], 'slug' => $slug);
		}
	}
	return false;
}
function get_term_link($term) { return 'https://thequizwire.com/topic/' . $term->slug . '/'; }
function wp_set_object_terms($id, $terms, $tax) { $GLOBALS['db']['obj_terms'][] = array($id, $terms, $tax); return array(); }
function wp_set_post_categories($id, $cats, $append = false) { $GLOBALS['db']['categories'][] = array($id, $cats); return $cats; }
function get_the_terms($id, $tax) {
	$t = $GLOBALS['db']['post_terms'][$id] ?? null;
	return $t === null ? false : $t;
}

/* --- sanitizers / escapers --- */
function esc_url($u) { return $u; }
function esc_url_raw($u) { return $u; }
function esc_html($s) { return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8', false); }
function esc_attr($s) { return esc_html($s); }
function sanitize_text_field($s) { return trim(strip_tags((string) $s)); }
function sanitize_key($s) { return strtolower(preg_replace('/[^a-z0-9_\-]/', '', strtolower((string) $s))); }
function wp_strip_all_tags($s) { return trim(strip_tags((string) $s)); }
function wp_kses_post($s) { return $s; } // permissive for the dry run; kses never balanced tags anyway
function absint($n) { return abs((int) $n); }
function wp_json_encode($d) { return json_encode($d, JSON_UNESCAPED_UNICODE); }
function shortcode_atts($defaults, $atts, $name = '') { $atts = (array) $atts; $out = array(); foreach ($defaults as $k => $v) { $out[$k] = array_key_exists($k, $atts) ? $atts[$k] : $v; } return $out; }
function home_url($p = '') { return 'https://thequizwire.com' . $p; }
function current_time($t) { if ($t === 'mysql') { return date('Y-m-d H:i:s'); } if ($t === 'timestamp') { return time(); } return date($t); }
function get_gmt_from_date($d) { return $d; }
function date_i18n($fmt, $ts = null) { return date($fmt, $ts === null ? time() : $ts); }
function trailingslashit($s) { return rtrim($s, '/') . '/'; }
function sanitize_title($s) { return strtolower(preg_replace('/[^a-z0-9\-]+/', '-', strtolower((string) $s))); }
function wp_parse_url($url, $c = -1) { return $c === -1 ? parse_url($url) : parse_url($url, $c); }
function wp_upload_dir() { return array('basedir' => '/tmp/nm-uploads', 'baseurl' => 'https://thequizwire.com/wp-content/uploads'); }
function wp_mkdir_p($dir) { return is_dir($dir) || mkdir($dir, 0777, true); }
function get_theme_mod($k) { return 0; }
function get_attached_file($id) { return false; }
function get_posts($args = array()) {
	// Minimal: find pages by slug ('name') or by meta_key/meta_value.
	$out = array();
	foreach ($GLOBALS['db']['posts'] as $id => $p) {
		if (($args['post_type'] ?? 'post') !== ($p['post_type'] ?? 'post')) { continue; }
		if (isset($args['name']) && $args['name'] !== ($p['post_name'] ?? '')) { continue; }
		if (isset($args['meta_key'])) {
			$mv = $GLOBALS['db']['meta'][$id][$args['meta_key']] ?? null;
			if ((string) $mv !== (string) ($args['meta_value'] ?? '')) { continue; }
		}
		$out[] = $id;
	}
	return array_slice($out, 0, (int) ($args['posts_per_page'] ?? 5));
}

/* Simplified port of WP's force_balance_tags: drops orphan closers, closes orphan openers. */
function force_balance_tags($text) {
	$void = array('br','hr','img','input','meta','link','source','embed','area','base','col','track','wbr');
	$stack = array(); $out = '';
	$parts = preg_split('/(<\/?[a-zA-Z][a-zA-Z0-9]*(?:\s[^>]*)?>)/', $text, -1, PREG_SPLIT_DELIM_CAPTURE);
	foreach ($parts as $part) {
		if (preg_match('/^<\/([a-zA-Z][a-zA-Z0-9]*)/', $part, $m)) {
			$tag = strtolower($m[1]);
			if (in_array($tag, $stack, true)) {
				while (! empty($stack)) { $t = array_pop($stack); $out .= '</' . $t . '>'; if ($t === $tag) break; }
			} // orphan closer: dropped
		} elseif (preg_match('/^<([a-zA-Z][a-zA-Z0-9]*)(\s[^>]*)?>$/s', $part, $m)) {
			$tag = strtolower($m[1]);
			$out .= $part;
			if (! in_array($tag, $void, true) && substr(rtrim(substr($part, 0, -1)), -1) !== '/') { $stack[] = $tag; }
		} else { $out .= $part; }
	}
	while (! empty($stack)) { $out .= '</' . array_pop($stack) . '>'; }
	return $out;
}

/* --- hooks (no-op recorders) --- */
function add_action() {} function add_filter() {} function add_shortcode() {}
function do_action() {} function apply_filters($t, $v) { return $v; }
function did_action($h) { return 0; }
function register_setting() {} function set_transient() {} function get_transient($k) { return false; }
function wp_next_scheduled() { return false; } function wp_schedule_event() {}
function is_singular() { return false; } function get_the_ID() { return 0; }

/* --- plugin-class stubs (only ones NOT under test) --- */
class NM_Generation_Logger {
	public static $log = array();
	public static function nm_log_activity($msg, $lvl = 'info', $ctx = array()) { self::$log[] = "[$lvl] $msg"; }
	public static function finish_run() {}
}
class NM_API_Client { // fake — real client not under test here
	public static function get_gemini_api_key() { return 'FAKE-KEY'; }
	public static function get_instance() { return new self(); }
	public function get_embedding($q, $k) { return null; }
	public function generate_topic_pillar($name, $desc, $exams, $mcqs, $min, $max) {
		return array('success' => true, 'data' => $GLOBALS['fake_pillar_data']);
	}
}

/* ------------------------------------------------------------------ */
/* Load the REAL classes under test                                    */
/* ------------------------------------------------------------------ */
require __DIR__ . '/../includes/class-nm-news-article-generator.php';
require __DIR__ . '/../includes/class-nm-shortcode-manager.php';
require __DIR__ . '/../includes/class-nm-topic-pillar-generator.php';
require __DIR__ . '/../includes/class-nm-post-type-manager.php';
if ( ! defined('NM_PLUGIN_PATH') ) { define('NM_PLUGIN_PATH', __DIR__ . '/../'); }
require __DIR__ . '/../includes/class-nm-monthly-pdf-archive.php';

/* Test double: record volume HTML + write placeholder files instead of running Dompdf. */
class NM_PDF_Test extends NM_Monthly_PDF_Archive {
	public static $rendered = array(); // file => html (last render)
	public static $render_count = array(); // file => times rendered
	protected static function render_pdf_file( $file, $html ) {
		self::$rendered[ $file ] = $html;
		self::$render_count[ $file ] = ( self::$render_count[ $file ] ?? 0 ) + 1;
		file_put_contents( $file, 'PDF-PLACEHOLDER' );
		return true;
	}
}

/* ------------------------------------------------------------------ */
/* Assertion helper                                                    */
/* ------------------------------------------------------------------ */
$PASS = 0; $FAIL = 0;
function check($label, $cond, $detail = '') {
	global $PASS, $FAIL;
	if ($cond) { $PASS++; echo "  ✅ PASS  $label\n"; }
	else { $FAIL++; echo "  ❌ FAIL  $label" . ($detail !== '' ? "  → $detail" : '') . "\n"; }
}

/* ================================================================== */
echo "=== T1: build_content() — sanitization of a 'broken' model output ===\n";
/* Replicates every defect seen in the user's real published posts. */
$dirty = '<p>Science is the systematic study of the physical world.</p>'
	. '<h2>By TheQuizWire Editorial Team</h2>'
	. '<p>See [our guide](https://thequizwire.com/topic/science/) for more.</p>'
	. '<h2>Key Concepts</h2><p>Atoms have protons.</p>'
	. '<h2>Common Questions &amp; Answers</h2><h3>What is an atom?</h3><p>A unit of matter.</p>'
	. '<h2>Related Practice MCQs</h2><p>Test yourself:</p><ul><li><a href="https://x/mcq/a/">Q</a></li></ul>'
	. '<h2>Frequently Asked Questions</h2><h3>Dup?</h3><p>Dup answer.</p>'
	. '<p>Trailing text with stray closer</p></p>'
	. '<p><a href="https://thequizwire.com/topic/science/">Explore more Science MCQs</a> today.</p>';

$data = array(
	'content' => $dirty,
	'faq'     => array(array('q' => 'What is an atom?', 'a' => 'The basic unit of matter.')),
);
$out = NM_News_Article_Generator::build_content($data, array(), array('related_shortcode' => '[nm_related_mcqs topic_id="42" count="6"]'));

check('in-content byline <h2>By ...</h2> stripped', strpos($out, 'Editorial Team') === false);
check('model "Common Questions & Answers" section stripped', stripos($out, 'Common Questions') === false);
check('model "Frequently Asked Questions" section stripped, ours appended once', substr_count($out, 'Frequently Asked Questions') === 1);
check('appended FAQ contains the schema Q/A', strpos($out, 'The basic unit of matter.') !== false);
check('model "Related Practice MCQs" section stripped', substr_count($out, 'Related Practice MCQs') === 0);
check('dynamic shortcode embedded instead of baked links', strpos($out, '[nm_related_mcqs topic_id="42" count="6"]') !== false);
check('markdown link converted to <a>', strpos($out, '<a href="https://thequizwire.com/topic/science/" rel="noopener"') !== false);
check('"Explore more" paragraph stripped', stripos($out, 'Explore more') === false);
check('stray </p> balanced away', substr_count($out, '</p>') === substr_count($out, '<p>'), 'openers=' . substr_count($out, '<p>') . ' closers=' . substr_count($out, '</p>'));
check('legit body content preserved', strpos($out, 'Atoms have protons.') !== false);

/* ================================================================== */
echo "\n=== T2: build_content() fallback — baked links restricted to PUBLISHED MCQs ===\n";
$GLOBALS['db']['posts'][11] = array('post_type' => 'mcq', 'post_status' => 'publish', 'post_author' => 2, 'post_name' => 'published-q', 'post_title' => 'Published question?');
$GLOBALS['db']['posts'][12] = array('post_type' => 'mcq', 'post_status' => 'draft',   'post_author' => 2, 'post_name' => 'draft-q',     'post_title' => 'Draft question?');
$out2 = NM_News_Article_Generator::build_content(
	array('content' => '<p>Body.</p>', 'faq' => array()),
	array(
		array('post_id' => 11, 'question' => 'Published question?', 'topic' => ''),
		array('post_id' => 12, 'question' => 'Draft question?', 'topic' => ''),
	)
	/* no related_shortcode arg → legacy baked mode */
);
check('published MCQ link baked', strpos($out2, '/mcq/published-q/') !== false);
check('draft MCQ link NOT baked (was the 404 trap)', strpos($out2, 'draft-q') === false && strpos($out2, '?post_type=') === false);

/* ================================================================== */
echo "\n=== T3: [nm_related_mcqs] shortcode — render-time resolution ===\n";
$html = NM_Shortcode_Manager::render_related_mcqs(array('ids' => '11,12,999', 'count' => 10));
check('ids mode: published MCQ rendered', strpos($html, 'Published question?') !== false);
check('ids mode: draft MCQ skipped', strpos($html, 'Draft question?') === false);
check('ids mode: deleted/unknown id skipped without error', true);
check('heading present when links exist', strpos($html, 'Related Practice MCQs') !== false);

$GLOBALS['db']['wpq_handler'] = function ($args) {
	if (($args['post_type'] ?? '') === 'mcq' && ! empty($args['tax_query'])) { return array(11); }
	return array();
};
$html2 = NM_Shortcode_Manager::render_related_mcqs(array('topic_id' => 42, 'count' => 6));
check('topic mode: queries published MCQs of topic', strpos($html2, 'Published question?') !== false);
$GLOBALS['db']['wpq_handler'] = function ($args) { return array(); };
$html3 = NM_Shortcode_Manager::render_related_mcqs(array('topic_id' => 42));
check('empty result → empty string (no orphan heading)', $html3 === '');

/* ================================================================== */
echo "\n=== T4: save_mcq_post_unified() — author rotation now reaches news/topic MCQs ===\n";
$GLOBALS['db']['wpq_handler'] = function ($args) { return array(); };
$mcq_data = array( // exactly what the FIXED news path now sends (no author_name)
	'question'     => 'Which particle carries a negative charge?',
	'options'      => array('A' => 'Electron', 'B' => 'Proton', 'C' => 'Neutron', 'D' => 'Photon'),
	'answer'       => 'A',
	'explanation'  => 'Electrons carry negative charge.',
	'source_name'  => 'News Source',
	'source_url'   => 'https://example.com/article',
	'fact_checked' => 'yes',
);
$dist = array();
for ($i = 0; $i < 30; $i++) {
	$pid = NM_Post_Type_Manager::save_mcq_post_unified($mcq_data, array('topic' => 'Science', 'subtopic' => 'Physics'));
	$author = (int) get_post_field('post_author', $pid);
	$meta   = get_post_meta($pid, 'mcq_author_name');
	$dist[$author] = ($dist[$author] ?? 0) + 1;
	if ($i === 0) {
		check('post_author drawn from configured pool (not Zain/#1)', in_array($author, array(2, 3, 4), true), "got author=$author");
		check('mcq_author_name meta MATCHES post_author display name', $meta === $GLOBALS['db']['users'][$author], "meta='$meta' vs user='{$GLOBALS['db']['users'][$author]}'");
		check('meta is no longer "TheQuizWire"', $meta !== 'TheQuizWire');
	}
}
check('rotation actually rotates across the pool (30 saves)', count($dist) >= 2, 'distribution: ' . json_encode($dist));
$only_pool = empty(array_diff(array_keys($dist), array(2, 3, 4)));
check('no save ever fell back to admin #1', $only_pool, 'distribution: ' . json_encode($dist));

/* explicit author_name still respected (importer/CSV path) */
$pid = NM_Post_Type_Manager::save_mcq_post_unified(array_merge($mcq_data, array('author_name' => 'CSV Import Author')), array('topic' => 'Science'));
check('explicit author_name (importer) still honored, rotation skipped', get_post_meta($pid, 'mcq_author_name') === 'CSV Import Author');

/* ================================================================== */
echo "\n=== T5: Scheduler publish preserves rotated author (code-path check) ===\n";
$sched = file_get_contents(__DIR__ . '/../includes/class-nm-publication-scheduler.php');
check('scheduler no longer stamps current user onto published MCQs', strpos($sched, "'post_author' => \$post_author, // ✅ Persist intended author") === false);
check('scheduler only repairs author 0', strpos($sched, "0 === \$existing_author") !== false);
$gen = file_get_contents(__DIR__ . '/../includes/class-nm-generation-service.php');
check("generation service: hard-coded 'TheQuizWire' removed (both paths)", strpos($gen, "'TheQuizWire'") === false);
check('generation service: dead post_author save-arg removed', ! preg_match("/'post_author'\s*=>\s*\\\$current_user_id/", $gen));

/* ================================================================== */
echo "\n=== T6: Pillar generation — create once, then refresh IN PLACE ===\n";
$GLOBALS['db']['terms']['topic']['science'] = array('term_id' => 42, 'name' => 'Science');
$GLOBALS['fake_pillar_data'] = array(
	'title'   => 'Science MCQs: Complete Guide & Practice for CSS & PMS',
	'slug'    => 'science-mcqs-complete-guide',
	'excerpt' => 'Master Science MCQs for CSS, PMS, NTS and FPSC with this evergreen guide covering physics, chemistry, biology and earth science fundamentals.',
	'content' => '<h2>Key Concepts</h2><p>Light waves travel through a vacuum; sound waves cannot.</p>',
	'faq'     => array(array('q' => 'Do light waves need a medium?', 'a' => 'No — light propagates through a vacuum.')),
);

/* grounding + latest-pillar queries */
$GLOBALS['db']['wpq_handler'] = function ($args) {
	if (($args['meta_key'] ?? '') === '_nm_pillar_topic') {
		return $GLOBALS['existing_pillar'] ? array($GLOBALS['existing_pillar']) : array();
	}
	if (($args['post_type'] ?? '') === 'mcq') {
		// assert the grounding query excludes news MCQs
		$GLOBALS['seen_meta_query'] = $args['meta_query'] ?? null;
		return array(11);
	}
	return array();
};

/* --- first run: no pillar exists → INSERT --- */
$GLOBALS['existing_pillar'] = 0;
$before_inserts = count($GLOBALS['db']['inserts']);
$new_id = NM_Topic_Pillar_Generator::generate_pillar(42);
check('first run returns a post id', is_int($new_id) && $new_id > 0);
check('first run INSERTS a new post', count($GLOBALS['db']['inserts']) === $before_inserts + 1);
check('grounding query excludes news-derived MCQs (meta_query on mcq_source_url)',
	isset($GLOBALS['seen_meta_query']) && json_encode($GLOBALS['seen_meta_query']) === json_encode(array(
		'relation' => 'OR',
		array('key' => 'mcq_source_url', 'compare' => 'NOT EXISTS'),
		array('key' => 'mcq_source_url', 'value' => '', 'compare' => '='),
	)));
check('pillar content embeds dynamic shortcode with its topic id', strpos(get_post_field('post_content', $new_id), '[nm_related_mcqs topic_id="42" count="6"]') !== false);
check('author stamped from pool on creation', in_array((int) get_post_field('post_author', $new_id), array(2, 3, 4), true));
$study_cat = false;
foreach ($GLOBALS['db']['categories'] as $c) { if ($c[0] === $new_id) { $study_cat = $c[1]; } }
$sg = term_exists('study-guides', 'category');
check('filed under "Study Guides" category (not Uncategorized)', $study_cat && $sg && in_array($sg['term_id'], $study_cat));
check('refresh timestamp meta written', get_post_meta($new_id, '_nm_pillar_refreshed') !== '');

/* --- second run: pillar exists → UPDATE IN PLACE --- */
$GLOBALS['existing_pillar'] = $new_id;
$GLOBALS['db']['posts'][$new_id]['post_status'] = 'publish'; // pillar went live
$orig_author = (int) get_post_field('post_author', $new_id);
$orig_slug   = get_post_field('post_name', $new_id);
$orig_meta_author = get_post_meta($new_id, 'mcq_author_name');
$GLOBALS['fake_pillar_data']['title']   = 'Science MCQs: Updated Guide & Practice for CSS & PMS';
$GLOBALS['fake_pillar_data']['slug']    = 'science-mcqs-a-DIFFERENT-slug'; // model changed slug — must be ignored
$GLOBALS['fake_pillar_data']['content'] = '<h2>Key Concepts</h2><p>REFRESHED CONTENT v2.</p>';
$before_inserts = count($GLOBALS['db']['inserts']);
$before_updates = count($GLOBALS['db']['updates']);
$upd_id = NM_Topic_Pillar_Generator::generate_pillar(42);
check('second run returns the SAME post id (canonical URL preserved)', $upd_id === $new_id, "got #$upd_id, expected #$new_id");
check('second run does NOT insert a new post', count($GLOBALS['db']['inserts']) === $before_inserts);
check('second run UPDATES the existing post', count($GLOBALS['db']['updates']) > $before_updates);
check('slug/URL unchanged on refresh (model slug ignored)', get_post_field('post_name', $upd_id) === $orig_slug, 'slug=' . get_post_field('post_name', $upd_id));
check('post stays PUBLISHED through refresh', get_post_status($upd_id) === 'publish');
check('content actually refreshed', strpos(get_post_field('post_content', $upd_id), 'REFRESHED CONTENT v2.') !== false);
check('author unchanged on refresh (byline stability)', (int) get_post_field('post_author', $upd_id) === $orig_author);
check('mcq_author_name meta unchanged on refresh', get_post_meta($upd_id, 'mcq_author_name') === $orig_meta_author);

/* ================================================================== */
echo "\n=== T7: is_due() — cadence measured against LAST MODIFIED ===\n";
$GLOBALS['existing_pillar'] = $new_id;
$GLOBALS['db']['posts'][$new_id]['date_ts']     = time() - 200 * DAY_IN_SECONDS; // ancient publish date
$GLOBALS['db']['posts'][$new_id]['modified_ts'] = time() - 2 * DAY_IN_SECONDS;   // freshly refreshed
check('freshly refreshed pillar is NOT due despite old publish date (old code would re-run every sweep)', NM_Topic_Pillar_Generator::is_due(42, 30) === false);
$GLOBALS['db']['posts'][$new_id]['modified_ts'] = time() - 31 * DAY_IN_SECONDS;
check('pillar due again after cadence elapses', NM_Topic_Pillar_Generator::is_due(42, 30) === true);
$GLOBALS['existing_pillar'] = 0;
check('topic with no pillar is always due', NM_Topic_Pillar_Generator::is_due(4242, 30) === true);
check('default cadence is now 30 days', NM_Topic_Pillar_Generator::interval_days() === 30);

/* ================================================================== */
echo "\n=== T8: ensure_category() — idempotent get-or-create ===\n";
$a = NM_News_Article_Generator::ensure_category('Daily Roundups', 'daily-roundups');
$b = NM_News_Article_Generator::ensure_category('Daily Roundups', 'daily-roundups');
check('category created with valid id', $a > 0);
check('second call reuses the same term (no duplicates)', $a === $b);

/* ================================================================== */
echo "\n=== T9: Pillar prompt — static content checks ===\n";
$api = file_get_contents(__DIR__ . '/../includes/class-nm-api-client.php');
check('prompt no longer requests "Common Questions & Answers" section', strpos($api, '"Common Questions &amp; Answers" <h2> (2') === false && strpos($api, 'a "Common Questions & Answers" <h2>') === false);
check('prompt forbids in-content bylines', strpos($api, 'Do NOT include any byline') !== false);
check('prompt forbids in-content FAQ (single source of truth = JSON faq array)', strpos($api, 'ONLY in the JSON "faq" array') !== false);
check('prompt forbids model-emitted Related MCQs section', strpos($api, 'Do NOT include a "Related MCQs"') !== false);
check('prompt demands well-formed HTML', strpos($api, 'well-formed HTML') !== false);
check('prompt hardens evergreen constraint (no news-cycle facts)', strpos($api, 'news-cycle fact') !== false);

/* ================================================================== */
echo "\n=== T10: Topic hub CTA — placement + copy (9.5.3) ===\n";
$GLOBALS['db']['terms']['topic']['geography'] = array('term_id' => 77, 'name' => 'Geography');

/* explicit topic mode (pillar path) */
$cta_out = NM_News_Article_Generator::build_content(
	array('content' => '<p>Body text.</p>', 'faq' => array(array('q' => 'Q1?', 'a' => 'A1.'))),
	array(),
	array('related_shortcode' => '[nm_related_mcqs topic_id="77" count="6"]', 'topic_term_id' => 77)
);
check('CTA rendered with "Read the latest {Topic} MCQs Now" copy', strpos($cta_out, 'Read the latest Geography MCQs Now') !== false);
check('CTA links to the topic archive', strpos($cta_out, 'https://thequizwire.com/topic/geography/') !== false);
check('CTA carries styling hook class nm-topic-cta', strpos($cta_out, 'class="nm-topic-cta"') !== false);
$pos_related = strpos($cta_out, '[nm_related_mcqs');
$pos_cta     = strpos($cta_out, 'nm-topic-cta');
$pos_faq     = strpos($cta_out, 'Frequently Asked Questions');
check('ORDER: related block → CTA → FAQ (CTA no longer last)', $pos_related !== false && $pos_cta !== false && $pos_faq !== false && $pos_related < $pos_cta && $pos_cta < $pos_faq,
	"related@$pos_related cta@$pos_cta faq@$pos_faq");
check('CTA present even with EMPTY mcqs list (explicit topic_term_id)', true);

/* fallback derivation mode (roundup path — topic from batch MCQs) */
$cta_out2 = NM_News_Article_Generator::build_content(
	array('content' => '<p>Body.</p>', 'faq' => array()),
	array(
		array('post_id' => 11, 'question' => 'Q?', 'topic' => 'Geography'),
		array('post_id' => 12, 'question' => 'Q2?', 'topic' => 'Geography'),
		array('post_id' => 13, 'question' => 'Q3?', 'topic' => 'Science'),
	)
);
check('roundup fallback: CTA derived from MOST COMMON batch topic', strpos($cta_out2, 'Read the latest Geography MCQs Now') !== false);
check('unknown topic → no broken CTA emitted', strpos(NM_News_Article_Generator::build_content(array('content' => '<p>B.</p>', 'faq' => array()), array(array('post_id' => 11, 'question' => 'Q?', 'topic' => 'NoSuchTopic'))), 'nm-topic-cta') === false);

/* pillar generator passes topic_term_id through */
$GLOBALS['existing_pillar'] = 0;
$pid_cta = NM_Topic_Pillar_Generator::generate_pillar(42);
check('pillar content contains the topic CTA (Science)', strpos(get_post_field('post_content', $pid_cta), 'Read the latest Science MCQs Now') !== false);

/* ================================================================== */
echo "\n=== T11: Gutenberg block markup (9.5.4) ===\n";
$blk = NM_News_Article_Generator::build_content(
	array(
		'content' => '<p>Intro paragraph.</p><h2>Key Concepts</h2><h3>Sub part</h3><p>Body text.</p>'
			. '<ul><li>Fact one</li><li>Fact two</li></ul>'
			. '<div style="border:1px solid red;">Styled box stays as-is.</div>',
		'faq'     => array(array('q' => 'Q1?', 'a' => 'A1.')),
	),
	array(),
	array('related_shortcode' => '[nm_related_mcqs topic_id="77" count="6"]', 'topic_term_id' => 77)
);
check('output starts with a block comment (no Classic blob)', strpos(ltrim($blk), '<!-- wp:') === 0);
check('h2 → core/heading', strpos($blk, "<!-- wp:heading -->\n<h2 class=\"wp-block-heading\">Key Concepts</h2>") !== false);
check('h3 → core/heading {"level":3}', strpos($blk, '<!-- wp:heading {"level":3} -->') !== false);
check('p → core/paragraph', strpos($blk, "<!-- wp:paragraph -->\n<p>Intro paragraph.</p>") !== false);
check('ul → core/list with core/list-item children', strpos($blk, '<!-- wp:list -->') !== false && substr_count($blk, '<!-- wp:list-item -->') >= 2 && strpos($blk, '<ul class="wp-block-list">') !== false);
check('[nm_related_mcqs] → core/shortcode block', strpos($blk, "<!-- wp:shortcode -->\n[nm_related_mcqs topic_id=\"77\" count=\"6\"]\n<!-- /wp:shortcode -->") !== false);
check('CTA paragraph carries {"className":"nm-topic-cta"}', strpos($blk, '<!-- wp:paragraph {"className":"nm-topic-cta"} -->') !== false);
check('styled <div> preserved inside core/html (valid block, nothing dropped)', strpos($blk, "<!-- wp:html -->\n<div style=\"border:1px solid red;\">Styled box stays as-is.</div>\n<!-- /wp:html -->") !== false);
check('FAQ heading + answers block-wrapped too', strpos($blk, '>Frequently Asked Questions</h2>') !== false && strpos($blk, '<p>A1.</p>') !== false);

/* Editor-critical invariants */
$opens  = substr_count($blk, '<!-- wp:');
$closes = substr_count($blk, '<!-- /wp:');
check('every block opened is closed (' . $closes . '/' . $opens . ')', $opens > 0 && $opens === $closes);
$stripped = preg_replace('/<!--\s*\/?wp:[^>]*-->/', '', $blk);
$plain    = preg_replace('/\s+/', '', strip_tags($stripped));
foreach (array('Introparagraph.', 'KeyConcepts', 'Factone', 'Facttwo', 'Styledboxstaysas-is.', 'A1.') as $needle) {
	if (strpos($plain, $needle) === false) { check("no content lost ($needle)", false); }
}
check('no text content lost in conversion', strpos($plain, 'Introparagraph.') !== false && strpos($plain, 'Facttwo') !== false);
check('conversion is idempotent (already-block content passes through)', NM_News_Article_Generator::convert_html_to_blocks($blk) === $blk);

/* pillar + roundup pipelines produce block markup */
$GLOBALS['existing_pillar'] = 0;
$pid_blk = NM_Topic_Pillar_Generator::generate_pillar(42);
check('generated PILLAR post_content is block markup', strpos(ltrim(get_post_field('post_content', $pid_blk)), '<!-- wp:') === 0);

/* ================================================================== */
echo "\n=== T12: Batch migration of EXISTING classic posts to blocks (9.5.5) ===\n";
/* Seed: one classic pillar, one already-block roundup, one classic PDF page. */
$GLOBALS['db']['posts'][801] = array('post_type' => 'post', 'post_status' => 'publish', 'post_author' => 2, 'post_name' => 'old-pillar', 'post_title' => 'Old pillar', 'post_content' => '<h2>Old Guide</h2><p>Classic HTML body.</p><ul><li>One</li><li>Two</li></ul>');
$GLOBALS['db']['meta'][801]  = array('_nm_pillar_generated' => 'yes', '_nm_article_generated' => 'yes');
$GLOBALS['db']['posts'][802] = array('post_type' => 'post', 'post_status' => 'publish', 'post_author' => 3, 'post_name' => 'new-roundup', 'post_title' => 'New roundup', 'post_content' => "<!-- wp:paragraph -->\n<p>Already blocks.</p>\n<!-- /wp:paragraph -->");
$GLOBALS['db']['meta'][802]  = array('_nm_article_generated' => 'yes');
$GLOBALS['db']['posts'][803] = array('post_type' => 'page', 'post_status' => 'publish', 'post_author' => 1, 'post_name' => 'pdf-page', 'post_title' => 'PDF page', 'post_content' => '<p>Intro.</p><div style="border:1px solid;">Download card</div>');
$GLOBALS['db']['meta'][803]  = array('_nm_pdf_topic_term_id' => 42);

$GLOBALS['db']['wpq_handler'] = function ($args) {
	// Emulate the migration query: generated posts without _nm_blocks_converted.
	if (in_array('page', (array) ($args['post_type'] ?? array()), true)) {
		$ids = array();
		foreach (array(801, 802, 803) as $id) {
			$m = $GLOBALS['db']['meta'][$id] ?? array();
			$flagged = (($m['_nm_article_generated'] ?? '') === 'yes') || (($m['_nm_pillar_generated'] ?? '') === 'yes') || isset($m['_nm_pdf_topic_term_id']);
			if ($flagged && ! isset($m['_nm_blocks_converted'])) { $ids[] = $id; }
		}
		return array_slice($ids, 0, (int) ($args['posts_per_page'] ?? 25));
	}
	return array();
};

$r1 = NM_News_Article_Generator::convert_existing_posts_batch(25);
check('batch processed all 3 pending posts', $r1['processed'] === 3, json_encode($r1));
check('exactly the 2 classic posts converted, block post skipped', $r1['converted'] === 2 && $r1['skipped'] === 1, json_encode($r1));
check('batch reports done', $r1['done'] === true && $r1['remaining'] === 0);
check('classic pillar now starts with block comment', strpos(ltrim(get_post_field('post_content', 801)), '<!-- wp:') === 0);
check('pillar list converted to core/list blocks', strpos(get_post_field('post_content', 801), '<!-- wp:list-item -->') !== false);
check('PDF page: styled div preserved in core/html', strpos(get_post_field('post_content', 803), "<!-- wp:html -->\n<div style=\"border:1px solid;\">Download card</div>") !== false);
check('already-block roundup left byte-identical', get_post_field('post_content', 802) === "<!-- wp:paragraph -->\n<p>Already blocks.</p>\n<!-- /wp:paragraph -->");
check('all processed posts stamped _nm_blocks_converted', get_post_meta(801, '_nm_blocks_converted') === 'yes' && get_post_meta(802, '_nm_blocks_converted') === 'yes' && get_post_meta(803, '_nm_blocks_converted') === 'yes');

$r2 = NM_News_Article_Generator::convert_existing_posts_batch(25);
check('second run finds nothing (resumable/idempotent)', $r2['processed'] === 0 && $r2['done'] === true, json_encode($r2));

/* new generated posts are stamped at creation */
$GLOBALS['existing_pillar'] = 0;
$GLOBALS['db']['wpq_handler'] = function ($args) {
	if (($args['meta_key'] ?? '') === '_nm_pillar_topic') { return array(); }
	if (($args['post_type'] ?? '') === 'mcq') { return array(11); }
	return array();
};
$pid_new = NM_Topic_Pillar_Generator::generate_pillar(42);
check('newly generated pillar is stamped _nm_blocks_converted (born as blocks)', get_post_meta($pid_new, '_nm_blocks_converted') === 'yes');

/* ================================================================== */
echo "\n=== T13: Complete-bank PDF volumes (9.5.6) ===\n";
@mkdir('/tmp/nm-uploads', 0777, true);
$GLOBALS['db']['options']['nm_pdf_volume_cap'] = 100; // clamps to 100 (min)
check('volume cap clamped to 100–300 range', NM_Monthly_PDF_Archive::volume_cap() === 100);
$GLOBALS['db']['options']['nm_pdf_volume_cap'] = 999;
check('over-cap clamped down to 300', NM_Monthly_PDF_Archive::volume_cap() === 300);
$GLOBALS['db']['options']['nm_pdf_volume_cap'] = 200;

/* partition logic */
$fake = array_fill(0, 470, array('q' => 'x'));
$parts = NM_Monthly_PDF_Archive::partition_volumes($fake, 200);
check('470 Qs at cap 200 → 3 volumes of 200/200/70', count($parts) === 3 && count($parts[0]) === 200 && count($parts[2]) === 70);

/* Seed: Geography topic (term 42 'Science' exists; add 55 = Geography + subtopics) */
$GLOBALS['db']['terms']['topic']['geo'] = array('term_id' => 55, 'name' => 'Geography');
$GLOBALS['db']['terms']['topic']['physical-geo'] = array('term_id' => 56, 'name' => 'Physical Geography');
$GLOBALS['db']['terms']['topic']['world-geo'] = array('term_id' => 57, 'name' => 'World Geography');
$sub56 = (object) array('term_id' => 56, 'name' => 'Physical Geography', 'parent' => 55);
$sub57 = (object) array('term_id' => 57, 'name' => 'World Geography', 'parent' => 55);

/* 5 published geography MCQs (IDs 901–905), one REPORTED (903), cap=2 → volumes 1(frozen),2(frozen? no: 4 clean → vol1=2 frozen, vol2=2 frozen... use 5 clean minus 1 reported = 4 → 2 full volumes; add 905 clean → 5 clean = vol3 open(1)) */
foreach (array(901, 902, 903, 904, 905, 906) as $i => $id) {
	$GLOBALS['db']['posts'][$id] = array('post_type' => 'mcq', 'post_status' => 'publish', 'post_author' => 2, 'post_name' => "geo-q$id", 'post_title' => "Geography question $id?");
	$GLOBALS['db']['meta'][$id] = array('mcq_options' => array('A' => 'Opt A', 'B' => 'Opt B'), 'mcq_answer' => 'A', 'mcq_explanation' => "Because $id.");
	$GLOBALS['db']['post_terms'][$id] = array($i % 2 === 0 ? $sub56 : $sub57);
}
$GLOBALS['db']['meta'][903]['mcq_reported'] = 'yes'; // quality gate target
$GLOBALS['db']['options']['nm_pdf_volume_cap'] = 100; // min clamp = 100; too big for test — use partition directly? No: we want small cap. Clamp forbids <100…

/* Use reflection-free approach: cap is clamped ≥100, so seed 0 extra and test with the real cap via handler-limited MCQ set (5 Qs → 1 open volume). */
$GLOBALS['db']['wpq_handler'] = function ($args) {
	if (($args['post_type'] ?? '') === 'mcq' && ($args['orderby'] ?? '') === 'ID') {
		$GLOBALS['seen_vol_query'] = $args;
		// Emulate the quality gate: exclude 903 (reported).
		return array(901, 902, 904, 905, 906);
	}
	return array();
};

$r = NM_PDF_Test::ensure_complete_volumes(55);
check('volume run returns 1 open volume for 5 questions', $r['volumes'] === 1 && $r['built'] === 1 && $r['total_questions'] === 5, json_encode($r));
check('collector queries ID ASC (stable append-only order)', ($GLOBALS['seen_vol_query']['orderby'] ?? '') === 'ID' && ($GLOBALS['seen_vol_query']['order'] ?? '') === 'ASC');
check('collector carries the quality-gate meta_query (mcq_reported)', json_encode($GLOBALS['seen_vol_query']['meta_query'] ?? null) === json_encode(NM_Monthly_PDF_Archive::quality_gate_meta_query()));

$page_id = $r['page_id'];
$vols = get_post_meta($page_id, NM_Monthly_PDF_Archive::META_VOLUMES);
check('volume recorded with range Q1–Q5, open (not frozen)', isset($vols[1]) && $vols[1]['from'] === 1 && $vols[1]['to'] === 5 && $vols[1]['frozen'] === false, json_encode($vols));
check('stable filename ({slug}-complete-vol-01.pdf)', strpos($vols[1]['file'], 'geo-complete-vol-01.pdf') !== false, $vols[1]['file']);
check('volume PDF file written', file_exists($vols[1]['file']));

/* page content immediately after first build: open volume badge + range + link */
$pc_open = get_post_field('post_content', $page_id);
check('page lists volume with question range + download link', strpos($pc_open, 'Questions 1&ndash;5') !== false && strpos($pc_open, 'geo-complete-vol-01.pdf') !== false);
check('open volume badged "Updated monthly"', strpos($pc_open, 'Updated monthly') !== false);

$vol_html = NM_PDF_Test::$rendered[$vols[1]['file']];
check('PDF grouped by sub-topic with section headings', strpos($vol_html, 'Physical Geography') !== false && strpos($vol_html, 'World Geography') !== false && substr_count($vol_html, 'class="sec"') === 2);
check('sections alphabetical (Physical before World)', strpos($vol_html, 'Physical Geography') < strpos($vol_html, 'World Geography'));
check('continuous numbering starts at Q1', strpos($vol_html, 'Q1.') !== false && strpos($vol_html, 'Q5.') !== false);
check('reported MCQ 903 NOT in the PDF', strpos($vol_html, 'question 903?') === false);
check('cover states 1st-of-month refresh policy (open volume)', strpos($vol_html, '1st of every month') !== false);
check('cover shows Volume 1 of 1', strpos($vol_html, 'Volume 1 of 1') !== false);

/* numbering offset for later volumes */
$chunk2_html_probe = new ReflectionMethod('NM_Monthly_PDF_Archive', 'build_volume_pdf_html');
$chunk2_html_probe->setAccessible(true);
$geo_term = get_term(55, 'topic');
$probe_html = $chunk2_html_probe->invoke(null, $geo_term, 2, 3, array(array('post_id' => 902, 'question' => 'Later Q?', 'options' => array('A' => 'x'), 'answer' => 'A', 'explanation' => '', 'subtopic' => 'World Geography')), 201);
check('Vol 2 numbering starts at Q201 (continuous across volumes)', strpos($probe_html, 'Q201.') !== false);
check('frozen-volume cover says it will not change', strpos($probe_html, 'will not change') !== false || strpos($probe_html, '1st of every month') !== false);

/* frozen volumes are never re-rendered */
$vols[1]['frozen'] = true; // simulate: volume filled up and froze
update_post_meta($page_id, NM_Monthly_PDF_Archive::META_VOLUMES, $vols);
$before = NM_PDF_Test::$render_count[$vols[1]['file']];
NM_PDF_Test::ensure_complete_volumes(55);
check('frozen volume skipped on re-run (file untouched)', NM_PDF_Test::$render_count[$vols[1]['file']] === $before);

/* monthly trigger: runs once per calendar month */
delete_post_meta($page_id, NM_Monthly_PDF_Archive::META_VOLUMES_MONTH);
$first  = NM_PDF_Test::maybe_refresh_volumes(55);
$second = NM_PDF_Test::maybe_refresh_volumes(55);
check('1st-of-month trigger: first call runs, same-month second call skips', is_array($first) && $second === false);

/* archive page content: complete-bank section with the refresh note */
$page_content = get_post_field('post_content', $page_id);
check('page shows "Complete Geography MCQ Bank — All 5 Questions"', strpos($page_content, 'Complete Geography MCQ Bank') !== false && strpos($page_content, 'All 5 Questions') !== false);
check('page states the 1st-of-month refresh policy (user-visible)', strpos($page_content, 'refreshed on the 1st of every month') !== false);
check('frozen volume badged "Complete" after freeze', strpos($page_content, 'Complete</span>') !== false);
check('archive page stored as block markup', strpos(ltrim($page_content), '<!-- wp:') === 0);

/* monthly collector also carries the quality gate */
$GLOBALS['db']['wpq_handler'] = function ($args) {
	if (($args['post_type'] ?? '') === 'mcq' && ! empty($args['date_query'])) { $GLOBALS['seen_month_query'] = $args; return array(); }
	return array();
};
NM_PDF_Test::ensure_archive(55, 2026, 7);
check('MONTHLY collector also excludes reported MCQs', json_encode($GLOBALS['seen_month_query']['meta_query'] ?? null) === json_encode(NM_Monthly_PDF_Archive::quality_gate_meta_query()));

/* ================================================================== */
echo "\n" . str_repeat('=', 60) . "\n";
echo "RESULT: $PASS passed, $FAIL failed\n";
exit($FAIL === 0 ? 0 : 1);
