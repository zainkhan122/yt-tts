<?php

namespace DIT\TrendStudio\Services;

use DIT\TrendStudio\Infrastructure\Logger;

if (!defined('ABSPATH')) {
    exit;
}

class Visual_Sourcing_Service
{
    private Logger $logger;

    public function __construct(Logger $logger)
    {
        $this->logger = $logger;
    }

    /**
     * Fetch images for a topic from SerpApi or Google Custom Search,
     * download them to the Media Library, and return HTML img tags.
     */
    public function source_images_for_topic(string $topic, int $limit = 20): string
    {
        $provider = get_option('dit_ts_image_api_provider', 'serpapi');
        $this->logger->info("Visual Sourcing started for topic: {$topic} using provider: {$provider}");

        $image_urls = [];

        $image_urls = $this->search_serpapi($topic, $limit);

        if (empty($image_urls)) {
            $this->logger->info("No visual sourcing images found for topic: {$topic}");
            return '';
        }

        $html = '';
        foreach ($image_urls as $url) {
            // Sideload to Media Library
            $attachment_id = $this->sideload_image($url, $topic);
            if ($attachment_id && !is_wp_error($attachment_id)) {
                $local_url = wp_get_attachment_url($attachment_id);
                $html .= sprintf('<img src="%s" alt="%s" />', esc_url($local_url), esc_attr($topic)) . "\n";
            }
        }

        return $html;
    }

    private function search_serpapi(string $topic, int $limit): array
    {
        $api_key = get_option('dit_ts_serpapi_key', '');
        if (empty($api_key)) {
            $this->logger->error("SerpApi key missing");
            return [];
        }

        $url = add_query_arg([
            'engine' => 'google_images',
            'q' => $topic,
            'api_key' => $api_key,
            'num' => $limit,
            'tbs' => 'isz:l' // Force large (HD) images
        ], 'https://serpapi.com/search.json');

        $response = wp_remote_get($url, ['timeout' => 15]);

        if (is_wp_error($response)) {
            $this->logger->error("SerpApi request failed: " . $response->get_error_message());
            return [];
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (empty($data['images_results'])) {
            return [];
        }

        $urls = [];
        $blocked_domains = ['tiktok.com', 'instagram.com', 'facebook.com', 'twitter.com', 'x.com'];
        foreach ($data['images_results'] as $item) {
            if (!empty($item['original'])) {
                if (strpos($item['original'], 'data:image') === 0) continue;
                $img_host = strtolower(parse_url($item['original'], PHP_URL_HOST) ?: '');
                $skip = false;
                foreach ($blocked_domains as $bd) {
                    if ($img_host === $bd || substr($img_host, -strlen($bd) - 1) === '.' . $bd) {
                        $skip = true;
                        break;
                    }
                }
                if ($skip) continue;
                $urls[] = $item['original'];
                if (count($urls) >= $limit) break;
            }
        }

        return $urls;
    }


    private function sideload_image(string $url, string $topic): int
    {
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');

        // Download file
        $tmp = download_url($url);
        if (is_wp_error($tmp)) {
            $this->logger->error("Failed to sideload image: {$url}");
            return 0;
        }

        // Determine actual mime type and extension of the downloaded file
        $mime = mime_content_type($tmp);
        if (!$mime) {
            $mime = 'image/jpeg';
        }

        $ext = 'jpg';
        switch ($mime) {
            case 'image/png':
                $ext = 'png';
                break;
            case 'image/gif':
                $ext = 'gif';
                break;
            case 'image/webp':
                $ext = 'webp';
                break;
            case 'image/jpeg':
            default:
                $ext = 'jpg';
                break;
        }

        // Give the file a safe name based on the topic
        $clean_topic = sanitize_title($topic);
        $unique = wp_generate_password(6, false, false);
        $filename = sprintf('%s-%s.%s', $clean_topic, $unique, $ext);

        $file_array = [
            'name' => $filename,
            'tmp_name' => $tmp
        ];

        $attachment_id = media_handle_sideload($file_array, 0, $topic);

        if (is_wp_error($attachment_id)) {
            @unlink($tmp);
            $this->logger->error("Failed to insert attachment: " . $attachment_id->get_error_message());
            return 0;
        }

        return $attachment_id;
    }
}
