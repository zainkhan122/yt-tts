<?php
function gm_setting() {
 
	// license ini
	$licenseactive = get_option ( 'wp_automatic_license_active', '' );
	$licenseactive_purchase = get_option ( 'wp_automatic_license_active_purchase', '' ); // purchase code for which the license is active
	
	$actual_link = (isset ( $_SERVER ['HTTPS'] ) && $_SERVER ['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
	$state = base64_encode ( $actual_link );
	
	// Save FB token returned from FB login
	if (isset ( $_GET ['token'] )) {
		update_option ( 'wp_automatic_fb_token', $_GET ['token'] );
	}
	
	// purchase check if not already active or if the purchase code changed
	if (! empty ( $_POST ['wp_automatic_license'] ) &&  ( wp_automatic_trim( $licenseactive ) == '' || ( $licenseactive_purchase != $_POST['wp_automatic_license'] ) ) ) {
		
		// save it
		update_option ( 'wp_automatic_license', $_POST ['wp_automatic_license'] );
		
		// activating
		// curl ini
		$ch = curl_init ();
		curl_setopt ( $ch, CURLOPT_HEADER, 0 );
		curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, 1 );
		curl_setopt ( $ch, CURLOPT_CONNECTTIMEOUT, 10 );
		curl_setopt ( $ch, CURLOPT_TIMEOUT, 20 );
		curl_setopt ( $ch, CURLOPT_REFERER, 'http://www.bing.com/' );
		curl_setopt ( $ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.8) Gecko/2009032609 Firefox/3.0.8' );
		curl_setopt ( $ch, CURLOPT_MAXREDIRS, 5 ); // Good leeway for redirections.
		@curl_setopt ( $ch, CURLOPT_FOLLOWLOCATION, 1 ); // Many login forms redirect at least once.
		                                                 // curl_setopt($ch, CURLOPT_COOKIEJAR , "cookie.txt");
		                                                 
		// curl get
		$x = 'error';
		
		// change domain ?
		$append = '';
		
		if (isset ( $_POST ['wp_automatic_options'] ) && in_array ( 'OPT_CHANGE_DOMAIN', $_POST ['wp_automatic_options'] )) {
			$append = '&changedomain=yes';
		}
		
		$proxy = false;
		
		if ($proxy == false) {
			$url = 'https://deandev.com/license/index.php?itm=1904470&domain=' . $_SERVER ['HTTP_HOST'] . '&purchase=' . wp_automatic_trim( $_POST ['wp_automatic_license'] ) . $append;
		} else {
			$url = 'http://deandev-proxy.appspot.com/license/index.php?itm=1904470&domain=' . $_SERVER ['HTTP_HOST'] . '&purchase=' . wp_automatic_trim( $_POST ['wp_automatic_license'] ) . $append;
		}

		//add version to the url
		$version = WPAUTOMATIC_VERSION;
		$url.='&v='.$version;
		
		 

		curl_setopt ( $ch, CURLOPT_HTTPGET, 1 );
		curl_setopt ( $ch, CURLOPT_URL, wp_automatic_trim( $url ) );
		$exec = curl_exec ( $ch );
		$x = curl_error ( $ch );
		$resback = $exec;
		
		if (wp_automatic_trim( $exec ) == '' || ! stristr ( $exec, '{' )) {
			
			$url = 'http://deandev-proxy.appspot.com/license/index.php?itm=1904470&domain=' . $_SERVER ['HTTP_HOST'] . '&purchase=' . wp_automatic_trim( $_POST ['wp_automatic_license'] ) . $append;
			
			$url.='&v='.$version;

			curl_setopt ( $ch, CURLOPT_HTTPGET, 1 );
			curl_setopt ( $ch, CURLOPT_URL, wp_automatic_trim( $url ) );
			
			$exec = curl_exec ( $ch );
			$resback = $exec;
			$x = curl_error ( $ch );
		}
		
		$resarr = json_decode ( $resback );
		
		if (isset ( $resarr->message )) {
			$wp_automatic_active_message = $resarr->message;
			
			// activate the plugin
			update_option ( 'wp_automatic_license_active', 'active' );
			update_option ( 'wp_automatic_license_active_date', time () );

			// update license active for which purchase code
			update_option ( 'wp_automatic_license_active_purchase', wp_automatic_trim( $_POST ['wp_automatic_license'] ) );

			$licenseactive = get_option ( 'wp_automatic_license_active', '' );
		} else {
			if (isset ( $resarr->error )){

				$wp_automatic_active_error = $resarr->error;

				
				update_option ( 'wp_automatic_license_active', '' );
				$licenseactive = '';

			}
				
		}
	}
	
	// save values if post requested
	$updated = '';
	if ( isset($_POST['_wpnonce'])  && isset ( $_POST ['wp_amazonpin_tw'] ) && current_user_can ( 'administrator' )) {
		

		//validate nonce  wp_automatic_nonce
		if ( ! wp_verify_nonce( $_POST['_wpnonce'], 'wp_automatic_nonce' ) ) {
			$updated = '<div class="updated below-h2" id="message"><p>Settings update Failed, Please refresh the page and try again.  </p></div>';
		}else{

			// default check
			if (! isset ( $_POST ['wp_automatic_options'] )) {
				$_POST ['wp_automatic_options'] = array ();
			}
			
			foreach ( $_POST as $key => $val ) {
				
				if (stristr ( $key, 'content' )) {
					$key =wp_automatic_str_replace( 'content', '', $key );
				}
				
				update_option ( $key, $val );
			}
			
			$updated = '<div class="updated below-h2" id="message"><p>Settings updated.  </p></div>';

		}
	}
	
	// remove twitter token
	if (isset ( $_POST ['wp_automatic_opt'] )) {
		
		if (in_array ( 'wp_automatic_tw_reset', $_POST ['wp_automatic_opt'] )) {
			delete_option ( 'wp_automatic_tw_token' );
		}
		
		if (in_array ( 'wp_automatic_fb_reset', $_POST ['wp_automatic_opt'] )) {
			delete_option ( 'wp_automatic_fb_token' );
		}
	}
	
	$dir = WP_PLUGIN_URL . '/' .wp_automatic_str_replace( basename ( __FILE__ ), "", plugin_basename ( __FILE__ ) );
	$dir = plugins_url ( '/', __FILE__ );
	
	// echo dirname(__FILE__);
	if (! function_exists ( 'cchecked' )) {
		function cchecked($name, $val) {
			$arr = get_option ( $name, array (
					'OPT_CRON' 
			) );
			
			if (in_array ( $val, $arr )) {
				return 'checked="checked"';
			}
		}
	}
	
	?>

<script type="text/javascript" src="<?php   echo $dir; ?>js/jquery.tools.js"></script>
<script type="text/javascript" src="<?php   echo $dir; ?>js/jquery.uniform.min.js"></script>
<script type="text/javascript" src="<?php   echo $dir; ?>js/main.js?ver=5.0.3"></script>

<link href='<?php   echo $dir; ?>css/style.css' rel='stylesheet' type='text/css'>
<link href='<?php   echo $dir; ?>css/uniform.css' rel='stylesheet' type='text/css'>

<style>
.wp_automatic_hide_noactive { <?php
	
if ($licenseactive != 'active')
		echo 'display:none ';
	?>;
	
}

.wp_automatic_box_icon {
	width: 30px;
	padding-top: 12px;
	float: left;
}

.hndle {
	height: 50px;
}

h2 span {
	display: block;
	padding-top: 16px;
	padding-left: 42px;
}

.postbox .hndle {
	cursor: default !important;
}
</style>

<div>
	<div class="wrap">
		<div style="margin-left: 8px" class="icon32" id="icon-options-general">
			<br>
		</div>
		<h2>General Settings</h2>
		<p style="margin-top: 0">Set configuration for sources you posts from:</p>
			
			<?php   echo $updated?>
			
			<!--start container-->

		<div dir="ltr" id="dashboard-widgets-wrap">

			<form method="post" novalidate="novalidate">

				<!--generated nonce field -->
				<?php  wp_nonce_field('wp_automatic_nonce')?>  
				 

				<div class="metabox-holder columns-2 " id="dashboard-widgets">



					<!-- General post box -->
					<div class="postbox-container wp_automatic_hide_noactive">
						<div style="min-height: 1px;" class="meta-box-sortables ui-sortable" id="normal-sortables">

							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle">
									<img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/amazon.png',__FILE__)?>" /> <span>Amazon settings</span>
								</h2>
								<div class="inside main" style="padding-bottom: 14px">
									<!--start container-->
									<div class="TTWForm">

										<input type="hidden" value="200" name="wp_amazonpin_tw" />

										<div id="field285-container" class="field f_100  ">
											<label for="field285"> Amazon Associate ID* ( required ) <br> ( used for recieving commisions ) <a target="blank" href="https://affiliate-program.amazon.com/gp/advertising/api/detail/main.html">( apply here )</a>
											</label> <input value="<?php   echo get_option( 'wp_amazonpin_aaid' ) ?>" name="wp_amazonpin_aaid" id="field285" type="text">
										</div>

										<div id="field285-container" class="field f_100  ">
											<label for="field285"> Amazon Access Key ID ( optional ) (API v5) <a target="_blank" href="https://www.youtube.com/watch?v=UtQVQPpjDcM"> ( tutorial ) </a>
											</label> <input value="<?php   echo get_option( 'wp_amazonpin_abk' ) ?>" name="wp_amazonpin_abk" id="field285" type="text">
										</div>

										<div id="field285-container" class="field f_100  ">
											<label for="field285"> Amazon Secret Access Key ( optional ) (API v5) </label> <input value="<?php   echo get_option( 'wp_amazonpin_apvtk' ) ?>" name="wp_amazonpin_apvtk" id="field285" type="text">
										</div>

										<div class="field f_100  ">
											<label> User agent when scraping ( optional ) </label> <input value="<?php   echo get_option( 'wp_automatic_amazon_agent' , 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.163 Safari/537.36' ) ?>" name="wp_automatic_amazon_agent" type="text">
										</div>

										 <!-- Prices decimal seprator default to . -->
										<div class="field f_100  ">
											<label> Desired decimal separator for prices </label>
											<input value="<?php   echo get_option( 'wp_automatic_amazon_price_decimal' , '' ) ?>" name="wp_automatic_amazon_price_decimal" type="text">
											<div class="description">Set as "." without quotes or "," without quotes</div>
										</div>

										<div class="field f_100  ">
											<label> Desired thousands separator for prices </label>
											<input value="<?php   echo get_option( 'wp_automatic_amazon_price_thousands' , '' ) ?>" name="wp_automatic_amazon_price_thousands" type="text">
										</div>



										<div class="field f_100">
											<div class="option clearfix">
												<input name="wp_automatic_options[]" <?php   echo cchecked('wp_automatic_options', 'OPT_AMAZON_NOAPI')  ?> value="OPT_AMAZON_NOAPI" type="checkbox"> <span class="option-title"> Do not use API and scrape amazon directly</span>
											</div>
										</div>

										<!--  
										<div  class="field f_100">
											<div class="option clearfix">
												<input name="wp_automatic_options[]" <?php   echo cchecked('wp_automatic_options', 'OPT_AMAZON_LOC')  ?> value="OPT_AMAZON_LOC" type="checkbox"> <span class="option-title"> Simulate delivery address </span>
												<div class="description">(If your server country is different than the Amazon site country)</div>
											</div>
										</div>
										  -->
										<div class="field f_100">
											<div class="option clearfix">
												<input name="wp_automatic_options[]" <?php   echo cchecked('wp_automatic_options', 'OPT_AMAZON_PRICE')  ?> value="OPT_AMAZON_PRICE" type="checkbox"> <span class="option-title">Check & update Amazon product prices (daily)</span>

												<div class="field f_100">
													
													<div class="option clearfix">
														<input name="wp_automatic_options[]" <?php   echo cchecked('wp_automatic_options', 'OPT_AMAZON_DELETE')  ?> value="OPT_AMAZON_DELETE" type="checkbox"> <span class="option-title"> Delete amazon not found products (no more on amazon)</span>
													</div>
													
													<div class="option clearfix">
														<input name="wp_automatic_options[]" <?php   echo cchecked('wp_automatic_options', 'OPT_AMAZON_PENDING')  ?> value="OPT_AMAZON_PENDING" type="checkbox"> <span class="option-title"> Set products that got out of stock to pending & publish them when they get back available</span>
													</div>

													<!-- hint: must setup an external cron job https://valvepress.com/how-to-update-amazon-products-prices-imported-automatically-using-wordpress-automatic-plugin/ -->
													<div class="description">	
														*Note: You must setup an external cron job for price updates to work <br> <br>*Check <a href="https://valvepress.com/how-to-update-amazon-products-prices-imported-automatically-using-wordpress-automatic-plugin/" target="_blank">this tutorial</a> 
													</div>

												</div>
												
 												
												
												
											</div>
										</div>



										<div id="form-submit" class="field f_100 clearfix submit" style>
											<input style="margin-left: 0" value="Save Changes" type="submit">
										</div>



									</div>
									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>
							<!-- post box -->

							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle">
									<img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/clickbank.png',__FILE__)?>"><span> Clickbank settings</span>
								</h2>
								<div class="inside TTWForm main" style="padding-bottom: 14px">
									<!--start container-->
									<div id="field285-container" class="field f_100 ">
										<label for="field285"> Clickbank username ? </label> <input value="<?php   echo get_option( 'wp_wp_automatic_cbu' ) ?>" name="wp_wp_automatic_cbu" id="field285" type="text">
									</div>


									<div id="form-submit" class="field f_100 clearfix submit" style>
										<input style="margin-left: 0" value="Save Changes" type="submit">
									</div>

									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>

							<!-- post box -->

							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle">
									<img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/aliexpress.ico',__FILE__)?>"><span> AliExpress settings</span>
								</h2>
								<div class="inside TTWForm main" style="padding-bottom: 14px">
									<!--start container-->

									<!-- app id -->
									<div class="field f_100 ">
										<p>Check this <a target="_blank" href="https://valvepress.com/how-to-create-aliexpress-app-key-and-secret-code/">tutorial</a> on how to create an AliExpress app key and secret code</p>
										<label for="field285"> AppKey  </label> <input value="<?php   echo get_option( 'wp_automatic_ali_app_id' ) ?>" name="wp_automatic_ali_app_id" id="field285" type="text">
									</div>

									<!-- app secret -->
									<div class="field f_100 ">
										<label for="field285"> App Secret  </label> <input value="<?php   echo get_option( 'wp_automatic_ali_app_secret' ) ?>" name="wp_automatic_ali_app_secret" id="field285" type="text">
									</div>

									<!-- tracking id optional -->
									<div class="field f_100 ">
										<label for="field285"> Tracking ID (optional) </label> <input value="<?php   echo get_option( 'wp_automatic_ali_tracking_id' ) ?>" name="wp_automatic_ali_tracking_id" id="field285" type="text">
										<div class="description">Your tracking ID for affiliate earnings from AliExpress</div>
									</div>

									 

									<div id="form-submit" class="field f_100 clearfix submit" style>
										<input style="margin-left: 0" value="Save Changes" type="submit">
									</div>

									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>


							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle">
									<img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/ez.jpg',__FILE__)?>"><span> Custom search settings</span>
								</h2>
								<div class="inside TTWForm main" style="padding-bottom: 14px">
									<!--start container-->
									<div id="field285-container" class="field f_100 ">
										<label for="field285"> Google custom search API key? </label> <input value="<?php   echo get_option( 'wp_automatic_search_key' ) ?>" name="wp_automatic_search_key" type="text">

										<div class="description">
											Visit <a href="http://valvepress.com/how-to-create-a-google-custom-search-api-key/">This tutorial</a> for how to create an api key. <br>*a key gives us 100 request/day <br>*You can add multiple keys and separate them with Comma but every key should be from a different Google account.
										</div>


									</div>

									<div id="form-submit" class="field f_100 clearfix submit" style>
										<input style="margin-left: 0" value="Save Changes" type="submit">
									</div>

									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>

							<!-- Bing news serach API key -->
							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle">
									<img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/bing.png',__FILE__)?>"><span> Bing news settings</span>
								</h2>
								<div class="inside TTWForm main" style="padding-bottom: 14px">
									<!--start container-->
									<div id="field285-container" class="field f_100 ">
										<label for="field285"> Bing news search API key? </label> <input value="<?php   echo get_option( 'wp_automatic_bing_key' ) ?>" name="wp_automatic_bing_key" type="text">

										<div class="description">
											Visit <a target="_blank" href="https://valvepress.com/how-to-create-a-bing-news-search-api-key/">This tutorial</a> for how to create an API key. 
										</div>


									</div>
								
									<div id="form-submit" class="field f_100 clearfix submit" style>
										<input style="margin-left: 0" value="Save Changes" type="submit">
									</div>
								
									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>

							<!-- SpinRewriter email and apikey -->
							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle">
									<img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/spinrewriter.png',__FILE__)?>"><span> SpinRewriter settings</span>
								</h2>
								<div class="inside TTWForm main" style="padding-bottom: 14px">
									<!--start container-->
									<div id="field285-container" class="field f_100 ">
										<label for="field285"> <a href="http://www.spinrewriter.com/?ref=11ade" target="_blank" >SpinRewriter</a> email? </label> <input value="<?php   echo get_option( 'wp_automatic_spinrewriter_email' ) ?>" name="wp_automatic_spinrewriter_email" type="text">
									</div>

									<div id="field285-container" class="field f_100 ">
										<label for="field285"> SpinRewriter API key? </label> <input value="<?php   echo get_option( 'wp_automatic_spinrewriter_key' ) ?>" name="wp_automatic_spinrewriter_key" type="text">
									</div>

									<div id="form-submit" class="field f_100 clearfix submit" style>
										<input style="margin-left: 0" value="Save Changes" type="submit">
									</div>

									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>
 

							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle">
									<img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/flicker.png',__FILE__)?>"><span> Flicker settings</span>
								</h2>
								<div class="inside TTWForm main" style="padding-bottom: 14px">
									<!--start container-->

									<div id="field285-container" class="field f_100 ">
										<label for="field285"> <b><a target="blank" href="http://www.flickr.com/services/api/misc.api_keys.html"> Flicker Api key </a></b> <i>(click the link to get your's)</i>
										</label> <input value="<?php   echo get_option( 'wp_automatic_flicker' ) ?>" name="wp_automatic_flicker" id="field285" type="text">
									</div>

									<div id="form-submit" class="field f_100 clearfix submit" style>
										<input style="margin-left: 0" value="Save Changes" type="submit">
									</div>

									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>

							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle">
									<img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/ebay.png',__FILE__)?>"><span> eBay settings</span>
								</h2>
								<div class="inside TTWForm main" style="padding-bottom: 14px">
									<!--start container-->

									<div class="field f_100 ">
										<label>API APP ID (Used to make use of the API)</label> <input value="<?php   echo get_option( 'wp_automatic_ebay_app' ) ?>" name="wp_automatic_ebay_app" type="text">
										<div class="description">
											Check <a target="_blank" href="http://valvepress.com/how-to-get-ebay-api-app-key/">this tutorial</a> on how to get it
										</div>
									</div>

									<div class="field f_100 ">
										<label>Cert ID (Client Secret)</label> <input value="<?php   echo get_option( 'wp_automatic_ebay_app_secret' ) ?>" name="wp_automatic_ebay_app_secret" type="text">

									</div>

									<div class="field f_100 ">
										<label> Campaign ID (Used for affiliate link generation)</label> <input value="<?php   echo get_option( 'wp_automatic_ebay_camp' ) ?>" name="wp_automatic_ebay_camp" type="text">
										<div class="description">
											Check <a target="_blank" href="http://valvepress.com/how-to-get-ebay-campaign-id-for-affiliate-earnings-from-ebay/">this tutorial</a> on how to get it
										</div>
									</div>

									<div class="field f_100 ">
										<label> affiliate Reference Id (Optional) (Used to track sales)</label> <input value="<?php   echo get_option( 'wp_automatic_ebay_refid' ) ?>" name="wp_automatic_ebay_refid" type="text">
									</div>

									<div class="field f_100 ">
										<label>Marketplace account deletion notification endpoint</label> <input disabled="disabled" value="<?php  $ebay_endpoint = plugins_url( 'ebay_clo.php' , __FILE__ )  ; $ebay_endpoint = wp_automatic_str_replace('http:/' , 'https:/', $ebay_endpoint);  echo $ebay_endpoint   ?>" name="wp_automatic_ebay_camp_delete" type="text">
										<div class="description">
											Check <a target="_blank" href="http://valvepress.com/how-to-setup-ebay-marketplace-account-deletion-closure-for-wp-automatic/">this tutorial</a> on how to setup Marketplace account deletion/closure notification
										</div>
									</div>

									<div class="field f_100 ">
										<label> Verification token </label> <input disabled="disabled" value="<?php $ebay_endpoint_md5 =  md5($ebay_endpoint) ; echo $ebay_endpoint_md5  ?>" name="wp_automatic_ebay_camp_delete_verification" type="text">
										<div class="description">*Your site must be in https if it is in http, you must set it up for HTTPS</div>
									</div>

									<div class="field f_100">
											<div class="option clearfix">
												<input name="wp_automatic_options[]" <?php   echo cchecked('wp_automatic_options', 'OPT_EBAY_PRICE')  ?> value="OPT_EBAY_PRICE" type="checkbox"> <span class="option-title">Check & update eBay products prices (daily)</span>

												<div class="field f_100">
													
													<div class="option clearfix">
														<input name="wp_automatic_options[]" <?php   echo cchecked('wp_automatic_options', 'OPT_EBAY_DELETE')  ?> value="OPT_EBAY_DELETE" type="checkbox"> <span class="option-title"> Delete not found products (no more on eBay)</span>
													</div>
													 
												</div>
												 
											</div>
										</div>



									<div id="form-submit" class="field f_100 clearfix submit" style>
										<input style="margin-left: 0" value="Save Changes" type="submit">
									</div>

									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>


							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle">
									<img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/ig.png',__FILE__)?>"><span> Instagram settings</span>
								</h2>
								<div class="inside TTWForm main" style="padding-bottom: 14px">
									<!--start container-->

									<div class="field f_100 ">
										<label>Session ID</label> <input value="<?php   echo get_option( 'wp_automatic_ig_sess' ) ?>" name="wp_automatic_ig_sess" type="text">
										<div class="description">
											Check <a target="_blank" href="http://valvepress.com/how-to-get-instagram-session-cookie/">this tutorial</a> on how to get it.
										</div>
									</div>

									<div class="field f_100">
										<div class="option clearfix">
											<input name="wp_automatic_options[]" <?php   echo cchecked('wp_automatic_options', 'OPT_wp_automatic_ig_sess')  ?> value="OPT_wp_automatic_ig_sess" type="checkbox"> <span class="option-title"> Send me an email notification if the session expires and need renewal</span>
										</div>
										<div class="description">*Make sure that you have added your email to the notification email settings field</div>
									</div>

									<div id="form-submit" class="field f_100 clearfix submit" style>
										<input style="margin-left: 0" value="Save Changes" type="submit">
									</div>

									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>


							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now_yt">
								<h2 class="hndle">
									<img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/yt.png',__FILE__)?>"><span> Youtube settings</span>
								</h2>
								<div class="inside TTWForm main" style="padding-bottom: 14px">
									<!--start container-->

									<div class="field f_100 ">
										<label>Youtube API Key</label>
										<textarea name="wp_automatic_yt_tocken"><?php   echo get_option( 'wp_automatic_yt_tocken' ) ?></textarea>
										<div class="description">
											*Check <a href="http://valvepress.com/how-to-get-a-youtube-api-key-to-post-from-youtube-to-wordpress/" target="_blank">this tutorial</a> on how to get your youtube api key<br> <br>*You can create multiple projects from different Google accounts (one project per Google account) and add multiple keys (one per line), each key gives 100 daily searches
										</div>

									</div>

									<!-- Youtube transcript API key https://transcriptapi.com/ textarea -->
									<div class="field f_100 ">
										<label>Youtube Transcript API Key (optional)</label> 
										<textarea name="wp_automatic_yt_transcript_api"><?php   echo get_option( 'wp_automatic_yt_transcript_api' ) ?></textarea>
										<div class="description">
											*Check <a href="https://transcriptapi.com/" target="_blank">this site</a> on how to get your youtube transcript api key<br> <br>*Used to get video transcripts if you want it<br><br>*One key per line if you have multiple keys
										</div>	
									</div>


									<div id="form-submit" class="field f_100 clearfix submit" style>
										<input style="margin-left: 0" value="Save Changes" type="submit">
									</div>

									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>


							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle">
									<img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/vimeo.png',__FILE__)?>"><span> Vimeo settings</span>
								</h2>
								<div class="inside TTWForm main" style="padding-bottom: 14px">
									<!--start container-->

									<div class="field f_100 ">
										<label> Access Token</label> <input value="<?php   echo get_option( 'wp_automatic_vm_tocken' ) ?>" name="wp_automatic_vm_tocken" type="text">
										<div class="description">
											Check <a href="http://valvepress.com/how-to-generate-a-vimeo-access-token-to-post-from-vimeo-to-wordpress/" target="_blank">this tutorial</a> on how to get your vimeo access token
										</div>
									</div>

									<div id="form-submit" class="field f_100 clearfix submit" style>
										<input style="margin-left: 0" value="Save Changes" type="submit">
									</div>

									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>



							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle">
									<img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/itunes.png',__FILE__)?>"><span> Itunes settings</span>
								</h2>
								<div class="inside TTWForm main" style="padding-bottom: 14px">
									<!--start container-->

									<div class="field f_100 ">
										<label>Affiliate ID (Token)</label> <input value="<?php   echo get_option( 'wp_automatic_iu_id' ) ?>" name="wp_automatic_iu_id" type="text">
										<div class="description">
											Apply <a href="http://www.apple.com/itunes/affiliates/" target="_blank">Here</a> for an ID
										</div>
									</div>


									<div id="form-submit" class="field f_100 clearfix submit" style>
										<input style="margin-left: 0" value="Save Changes" type="submit">
									</div>

									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>

							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle">
									<img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/envato.png',__FILE__)?>"><span>Envato settings</span>
								</h2>
								<div class="inside TTWForm main" style="padding-bottom: 14px">
									<!--start container-->

									<div class="field f_100 ">
										<label>Envato Authorization token</label> <input value="<?php   echo get_option( 'wp_automatic_envato_token' ) ?>" name="wp_automatic_envato_token" type="text">
										<div class="description">
											Get your token <a href="https://build.envato.com/create-token/" target="_blank">Here</a> just choose the name and click "Create token"
										</div>
									</div>

									<div class="field f_100 ">
										<label>Impact Radius affiliate URL</label> <input value="<?php   echo get_option( 'wp_automatic_envato_ir' ) ?>" name="wp_automatic_envato_ir" type="text">
										<div class="description">
											Check <a href="http://valvepress.com/how-to-get-envato-impact-radium-affiliate-url/">this tutorial</a> on how to get it
										</div>
									</div>

									<div id="form-submit" class="field f_100 clearfix submit" style>
										<input style="margin-left: 0" value="Save Changes" type="submit">
									</div>

									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>


							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle">
									<img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/fb.png',__FILE__)?>"><span> Facebook settings</span>
								</h2>
								<div class="inside TTWForm main" style="padding-bottom: 14px">
									<!--start container-->


									<div class="field f_100 ">
										<label>c_user cookie value</label> <input value="<?php   echo get_option( 'wp_automatic_fb_cuser' ) ?>" name="wp_automatic_fb_cuser" type="text">
										<div class="description">
											Check this tutorial <a href="http://valvepress.com/how-to-config-wp-automatic-for-fb/" target="_blank">Here</a> to know how to get these values
										</div>
									</div>

									<div class="field f_100 ">
										<label>xs cookie value</label> <input value="<?php   echo get_option( 'wp_automatic_fb_xs' ) ?>" name="wp_automatic_fb_xs" type="text">

									</div>

									<div class="field f_100">
										<div class="option clearfix">
											<input name="wp_automatic_options[]" <?php   echo cchecked('wp_automatic_options', 'OPT_wp_automatic_fb_xs')  ?> value="OPT_wp_automatic_fb_xs" type="checkbox"> <span class="option-title"> Send me an email notification if the session expires and need renewal</span>
										</div>
										<div class="description">*Make sure that you have added your email to the notification email settings field</div>
									</div>


									<div class="field f_100 ">
										<label>"Watch" text in your language?</label> <input value="<?php   echo get_option( 'wp_automatic_fb_w' ) ?>" name="wp_automatic_fb_w" type="text">
										<div class="description">FB appends the word "Watch" before the video title. The plugin removes this word so If your account is not in English, add the equivelant word in your language</div>
									</div>

									<div class="field f_100 ">
										<label>"Watch video" text in your language?</label> <input value="<?php   echo get_option( 'wp_automatic_fb_wv' ) ?>" name="wp_automatic_fb_wv" type="text">
									</div>

									<!-- video width defaults to 500 -->
									<div class="field f_100 ">
										<label>Video width</label> <input value="<?php   echo get_option( 'wp_automatic_fb_vw' , 500 ) ?>" name="wp_automatic_fb_vw" type="text">
									</div>



									<div id="form-submit" class="field f_100 clearfix submit" style>
										<input style="margin-left: 0" value="Save Changes" type="submit">
									</div>

									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>


							
							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle">
									<img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/tw.png',__FILE__)?>"><span> x.com settings</span>
								</h2>
								<div class="inside TTWForm main" style="padding-bottom: 14px">
									<!--start container-->

									<div class="field f_100 ">
										<label>Access Token</label> 
										
										<textarea name ="wp_automatic_x_rapid_token"   type="text"><?php   echo get_option( 'wp_automatic_x_rapid_token' ) ?></textarea>
										
										<div class="description">
											
										*Click <a href="https://rapidapi.com/alexanderxbx/api/twitter-api45" target="_blank">here</a> to apply for the API and get the token<br><br>  *Check <a href="https://valvepress.com/how-to-generate-x-com-api-token-to-post-from-x-to-wordpress-automatically/" target="_blank">this tutorial</a> on how to get the bearer token<br><br>*You can add many tokens from different accounts one per line and the plugin will rotate using them
										
										</div>
									</div>
									 
									<div id="form-submit" class="field f_100 clearfix submit" style>
										<input style="margin-left: 0" value="Save Changes" type="submit">
									</div>

									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>

							<!-- Reddit session cookie -->
							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle">
									<img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/rd.png',__FILE__)?>"><span> Reddit settings</span>
								</h2>
								<div class="inside TTWForm main" style="padding-bottom: 14px">
									<!--start container-->
									<div id="field285-container" class="field f_100 ">
										<label for="field285"> Reddit session cookie value </label> <input value="<?php   echo get_option( 'wp_automatic_reddit_sess' ) ?>" name="wp_automatic_reddit_sess" type="text">
										<div class="description">
											Check <a href="https://valvepress.com/how-to-get-reddit-session-cookie-to-auto-post-from-reddit-to-wordpress-complete-guide/" target="_blank">this tutorial</a> on how to get it
										</div>
									</div>
									 
									<div id="form-submit" class="field f_100 clearfix submit" style>
										<input style="margin-left: 0" value="Save Changes" type="submit">
									</div>
								
									<!--start container-->
									<div style="clear: both"></div>
										</div>
							</div>
							


							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle">
									<img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/walmart.png',__FILE__)?>"><span> Walmart Settings</span>
								</h2>
								<div class="inside TTWForm main" style="padding-bottom: 14px">
									<!--start container-->

									<div class="field f_100 ">
										<label>API key</label> <input value="<?php   echo get_option( 'wp_automatic_wm_api' ) ?>" name="wp_automatic_wm_api" type="text">
										<div class="description">
											Apply <a href="https://developer.walmartlabs.com/member" target="_blank">here</a>
										</div>
									</div>


									<div class="field f_100 ">
										<label>Impact Radius Publisher ID (optional)</label> <input value="<?php   echo get_option( 'wp_automatic_wm_ir_publisher' ) ?>" name="wp_automatic_wm_ir_publisher" type="text">
										<div class="description">
											Apply <a href="https://affiliates.walmart.com/" target="_blank">here</a> for recieving affiliate commisions. and check <a target="_blank" href="http://valvepress.com/how-to-get-your-walmart-publisher-id/">this tutorial</a> on how to find your publisher ID
										</div>

									</div>


									<div id="form-submit" class="field f_100 clearfix submit" style>
										<input style="margin-left: 0" value="Save Changes" type="submit">
									</div>

									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>

							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle">
									<img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/cj.png',__FILE__)?>"><span>Careerjet Settings</span>
								</h2>
								<div class="inside TTWForm main" style="padding-bottom: 14px">
									<!--start container-->

									<!-- API key -->
									<div class="field f_100 ">
										<label>API Key</label> <input value="<?php   echo get_option( 'wp_automatic_cj_key' ) ?>" name="wp_automatic_cj_key" type="text">
										<div class="description">
											Click <a href="http://www.careerjet.com/partners/?ak=a551ffb1b11a967e629c447bc929c067" target="_blank">here</a> to apply. ex: 21e5b4f9fa5dd06e59eec7e6a21898dc<br><br>Click <a href="<?php echo site_url('/?wp_automatic=show_ip') ?>" target="_blank">Here</a> to know your server IP 
										</div>
									</div>

									<!-- Check tutorial -->
									<div class="field f_100 ">
										<p>Check <a href="https://valvepress.com/how-to-create-careerjet-api-key/" target="_blank">this tutorial</a> on how to get your API key</p>
									</div>

									<div id="form-submit" class="field f_100 clearfix submit" style>
										<input style="margin-left: 0" value="Save Changes" type="submit">
									</div>

									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>



							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle">
									<img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/translator.microsoft.png',__FILE__)?>"><span> Microsoft Translator Settings</span>
								</h2>
								<div class="inside TTWForm main" style="padding-bottom: 14px">
									<!--start container-->

									<div class="field f_100 ">
										<label>Microsoft Access Key</label> <input value="<?php   echo get_option( 'wp_automatic_mt_key' ) ?>" name="wp_automatic_mt_key" type="text">
										<div class="description">
											Check <a href="http://valvepress.com/how-to-get-microfost-translator-access-key-from-azure/" target="_blank">this tutorial</a> on how to get this access key.
										</div>
									</div>

									<div class="field f_100 ">
										<label>Region</label> <input value="<?php   echo get_option( 'wp_automatic_mt_region' ) ?>" name="wp_automatic_mt_region" type="text">
										<div class="description">
											Optional: default region is "global", If you have set your app on a different region, add it here<br>e.g: eastasia
										</div>
									</div>


									<div id="form-submit" class="field f_100 clearfix submit" style>
										<input style="margin-left: 0" value="Save Changes" type="submit">
									</div>

									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>


							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle">
									<img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/yandex.png',__FILE__)?>"><span> Yandex Translator Settings</span>
								</h2>
								<div class="inside TTWForm main" style="padding-bottom: 14px">
									<!--start container-->

									<div class="field f_100 ">
										<label>Yandex Translate API Key</label> <input value="<?php   echo get_option( 'wp_automatic_yt_key' ) ?>" name="wp_automatic_yt_key" type="text">
										<div class="description">
											Check <a href="http://valvepress.com/how-to-get-a-yandex-translate-api-key/" target="_blank">this tutorial</a> on how to get your API key
										</div>
									</div>



									<div id="form-submit" class="field f_100 clearfix submit" style>
										<input style="margin-left: 0" value="Save Changes" type="submit">
									</div>

									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>


							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle">
									<img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/deepl.svg',__FILE__)?>"><span> Deepl PRO API Settings</span>
								</h2>
								<div class="inside TTWForm main" style="padding-bottom: 14px">
									<!--start container-->

									<div class="field f_100 ">
										<label>Authentication Key for DeepL API</label> <input value="<?php   echo get_option( 'wp_automatic_dl_key' ) ?>" name="wp_automatic_dl_key" type="text">
										<div class="description">
											Check <a href="http://valvepress.com/how-to-get-a-deepl-api-authentication-key/" target="_blank">this tutorial</a> on how to get your API key
										</div>
									</div>

									<div class="field f_100">
										<div class="option clearfix">
											<input name="wp_automatic_options[]" <?php   echo cchecked('wp_automatic_options', 'OPT_DEEPL_FREE')  ?> value="OPT_DEEPL_FREE" type="checkbox"> <span class="option-title"> Use the free API endpoint (If your subscription kind is free)</span>
										</div>

										<div class="option clearfix">
											<input name="wp_automatic_options[]" <?php   echo cchecked('wp_automatic_options', 'OPT_DEEPL_FORMAL')  ?> value="OPT_DEEPL_FORMAL" type="checkbox"> <span class="option-title"> Set formality to more formal</span>
										</div>

										<div class="option clearfix">
											<input name="wp_automatic_options[]" <?php   echo cchecked('wp_automatic_options', 'OPT_DEEPL_NFORMAL')  ?> value="OPT_DEEPL_NFORMAL" type="checkbox"> <span class="option-title"> Set formality to less formal</span>
										</div>

									</div>

									<div id="form-submit" class="field f_100 clearfix submit" style>
										<input style="margin-left: 0" value="Save Changes" type="submit">
									</div>

									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>

							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle">
									<img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/apify.svg',__FILE__)?>"><span> APIFY API Settings</span>
								</h2>
								<div class="inside TTWForm main" style="padding-bottom: 14px">
									<!--start container-->

									<div class="field f_100 ">
										<label><a href="https://www.apify.com?fpr=htjt0">APIFY</a> API token</label> 
										
										<textarea name="wp_automatic_apify_key"><?php   echo get_option( 'wp_automatic_apify_key' ) ?></textarea>
												
										<div class="description">
											*Check <a href="http://valvepress.com/how-to-get-apify-token-to-import-from-sites-that-depends-on-javascript/" target="_blank">this tutorial</a> on how to get your API token<br><br>*You can add multiple keys (one per line) for the plugin to rotate between them
										</div>
									</div>



									<div id="form-submit" class="field f_100 clearfix submit" style>
										<input style="margin-left: 0" value="Save Changes" type="submit">
									</div>

									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>

							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle">
									<img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/pixabay.png',__FILE__)?>"><span> PixaBay API Settings</span>
								</h2>
								<div class="inside TTWForm main" style="padding-bottom: 14px">
									<!--start container-->

									<div class="field f_100 ">
										<label>PixaBay API Key</label> <input value="<?php   echo get_option( 'wp_automatic_pixabay_key' ) ?>" name="wp_automatic_pixabay_key" type="text">
										<div class="description">
											Check <a href="https://valvepress.com/how-to-get-pixabay-api-key-for-automatic-featured-image/" target="_blank">this tutorial</a> on how to get your API token
										</div>
									</div>



									<div id="form-submit" class="field f_100 clearfix submit" style>
										<input style="margin-left: 0" value="Save Changes" type="submit">
									</div>

									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>

							<!-- Google places API key -->
							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle"> <img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/places.png',__FILE__)?>"><span> Google Places API Key</span> </h2>
								<div class="inside TTWForm main" style="padding-bottom: 14px"> <!--start container-->
									<div class="field f_100 ">
										<label>Google Places API Key</label> <input value="<?php   echo get_option( 'wp_automatic_google_places_key' ) ?>" name="wp_automatic_google_places_key" type="text">
										<div class="description">
											Check <a href="https://valvepress.com/how-to-get-google-places-api-key-for-automatic-plugin/" target="_blank">this tutorial</a> on how to get your API token
										</div>
									</div>
									<div id="form-submit" class="field f_100 clearfix submit" style> <input style="margin-left: 0" value="Save Changes" type="submit"> </div>
									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>

							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle">
									<img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/openai.png',__FILE__)?>"><span> OpenAI API Settings</span>
								</h2>
								<div class="inside TTWForm main" style="padding-bottom: 14px">
									<!--start container-->

									<div class="field f_100 ">
										<label>OpenAI API Key</label> 
										
										<textarea name="wp_automatic_openai_key"><?php   echo get_option( 'wp_automatic_openai_key' ) ?></textarea>
										<div class="description">
											*Check <a href="https://valvepress.com/how-to-find-your-openai-api-key-for-wordpress-automatic-plugin/" target="_blank">this tutorial</a> on how to get your API token
											<br><br>*You can add a single key or a list of keys(one per line) for the plugin to rotate between them
										</div>
									</div>

									<!-- Enable OpenAI web search -->
									<div class="field f_100">
										<div class="option clearfix">
											<input name="wp_automatic_options[]" <?php   echo cchecked('wp_automatic_options', 'OPT_OPENAI_WEB_SEARCH')  ?> value="OPT_OPENAI_WEB_SEARCH" type="checkbox"> <span class="option-title">Force enable OpenAI web search on all campaigns</span>
										</div>
										<div class="description">
											*This option will enable the plugin to use OpenAI web search to get the latest information from the internet<br><br>*This option is increase the cost of the API so use it only if you need updated information from the internet for your prompts<br><br>*Enabling this option will enable the web search on all campaigns that use OpenAI API, you can disable it and enable the same option on specific campaigns from the campaign settings page
										</div>
									</div>

									<!-- default model defaults to -->
									<div class="field f_100">
										<label>Default model (optional)</label> <input placeholder="<?php echo WPAUTOMATIC_OPENAI_MODEL ?>" value="<?php   echo get_option( 'wp_automatic_openai_model', WPAUTOMATIC_OPENAI_MODEL ) ?>" name="wp_automatic_openai_model" type="text">
										<div class="description">
											*The default model to use if no model is specified in the campaign. <br><br>*Check <a href="https://platform.openai.com/docs/models" target="_blank">OpenAI models</a> for available models. e.g: <?php echo WPAUTOMATIC_OPENAI_MODEL ?>	<br><br>*If left empty, the plugin will use the model "<?php echo WPAUTOMATIC_OPENAI_MODEL ?><br><br>*gpt-4o-mini is recommended because it is fast and chepest 
										</div>
									</div>	
									 
									<!-- default search country -->
									<div class="field f_100 ">
										<label>Default search country (optional)</label> <input value="<?php   echo get_option( 'wp_automatic_openai_country' ) ?>" name="wp_automatic_openai_country" type="text">
										<div class="description">
											*The default country to use if no country is specified in the campaign so the model can search the internet from this country and the results should be relevant to this country<br><br>Example: "US" for United States, "GB" for United Kingdom, "CA" for Canada<br><br>*If left empty, the plugin will use the default country of the OpenAI model which is "us"

										</div>
									</div>


									<div id="form-submit" class="field f_100 clearfix submit" style>
										<input style="margin-left: 0" value="Save Changes" type="submit">
									</div>

									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>

							<!-- Google Gemini API key -->
							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle"> <img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/gemini.png',__FILE__)?>"><span> Google Gemini API Key</span> </h2>
								<div class="inside TTWForm main" style="padding-bottom: 14px"> <!--start container-->
									<div class="field f_100 ">
										<label>Google Gemini API Key</label> 
										<textarea name="wp_automatic_gemini_key"><?php   echo get_option( 'wp_automatic_gemini_key' ) ?></textarea>
										<div class="description">
											*Check <a href="https://valvepress.com/how-to-create-google-gemini-api-key/" target="_blank">this tutorial</a> on how to get your API token
											<br><br>*You can add a single key or a list of keys(one per line) for the plugin to rotate between them
										</div>

										<!-- default model defaults to -->
										<div class="field ">
											<label>Default model (optional)</label> <input placeholder="<?php echo WPAUTOMATIC_GEMINI_MODEL ?>" value="<?php   echo get_option( 'wp_automatic_gemini_model', WPAUTOMATIC_GEMINI_MODEL ) ?>" name="wp_automatic_gemini_model" type="text">
											<div class="description">
												*The default model to use if no model is specified in the campaign. <br><br>*Check <a href="https://ai.google.dev/gemini-api/docs/models" target="_blank">Gemini models</a> for available models. e.g: <?php echo WPAUTOMATIC_GEMINI_MODEL ?>	<br><br>*If left empty, the plugin will use the model "<?php echo WPAUTOMATIC_GEMINI_MODEL ?>"
											</div>
										</div>
 
									</div>

									<div id="form-submit" class="field f_100 clearfix submit" style> <input style="margin-left: 0" value="Save Changes" type="submit"> </div>
									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>

							<!-- Claude API key -->
							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle"> <img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/claude.ico',__FILE__)?>"><span> Claude API Key</span> </h2>
								<div class="inside TTWForm main" style="padding-bottom: 14px"> <!--start container-->
									<div class="field f_100 ">
										<label>Claude API Key</label> <textarea name="wp_automatic_claude_key"><?php   echo get_option( 'wp_automatic_claude_key' ) ?></textarea>
										<div class="description">
											*Check <a href="https://valvepress.com/how-to-create-claude-api-key/" target="_blank">this tutorial</a> on how to get your API token
											<br><br>*You can add a single key or a list of keys(one per line) for the plugin to rotate between them
										</div>
										<!-- default model defaults to -->
										<div class="field ">
											<label>Default model (optional)</label> <input placeholder="<?php echo WPAUTOMATIC_CLAUDE_MODEL ?>" value="<?php   echo get_option( 'wp_automatic_claude_model', WPAUTOMATIC_CLAUDE_MODEL ) ?>" name="wp_automatic_claude_model" type="text">
											<div class="description">
												*The default model to use if no model is specified in the campaign. <br><br>*Check <a href="https://platform.claude.com/docs/en/about-claude/models/overview" target="_blank">Claude models</a> for available models. e.g: <?php echo WPAUTOMATIC_CLAUDE_MODEL ?>	<br><br>*If left empty, the plugin will use the model "<?php echo WPAUTOMATIC_CLAUDE_MODEL ?>"
											</div>
										</div>

										<div id="form-submit" class="field f_100 clearfix submit" style> <input style="margin-left: 0" value="Save Changes" type="submit"> </div>
										<!--start container-->
										<div style="clear: both"></div>

									</div>
								</div>
							</div>

							<!-- OpenRouter API key -->
							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle"> <img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/openrouter.ico',__FILE__)?>"><span> OpenRouter API Key</span> </h2>
								<div class="inside TTWForm main" style="padding-bottom: 14px"> <!--start container-->
									<div class="field f_100 ">
										<label>OpenRouter API Key*</label> <textarea name="wp_automatic_openrouter_key"><?php   echo get_option( 'wp_automatic_openrouter_key' ) ?></textarea>
										<div class="description">
											*Check <a href="https://valvepress.com/how-to-generate-an-openrouter-api-key-for-wordpress-automatic-plugin/" target="_blank">this tutorial</a> on how to get your API token
											<br><br>*You can add a single key or a list of keys(one per line) for the plugin to rotate between them.
										</div>
									</div>

									<!-- default model -->
									<div class="field f_100 ">
										<label>Default model (optional)</label> <input value="<?php   echo get_option( 'wp_automatic_openrouter_model', WPAUTOMATIC_OPENROUTER_MODEL ) ?>" name="wp_automatic_openrouter_model" type="text">
										<div class="description">
											*The default model to use if no model is specified in the campaign. <br><br>*Check <a href="https://openrouter.ai/models" target="_blank">OpenRouter models</a> for available models. e.g: google/gemini<br><br>*You can use free models like "<?php echo WPAUTOMATIC_OPENROUTER_MODEL ?>"<br><br>*If left empty, the plugin will use the free model "<?php echo WPAUTOMATIC_OPENROUTER_MODEL ?>"<br><br>*OpenRouter free models are limited to 50 daily requests per account if you did not add credit to your account and to 1000 daily if you added at least 10 credits, check exact limits <a href="https://openrouter.ai/docs/api-reference/limits" target="_blank">here</a>
										</div>
									</div>

									<div id="form-submit" class="field f_100 clearfix submit" style> <input style="margin-left: 0" value="Save Changes" type="submit"> </div>
									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>

							<!-- CloudFlare workers option contains cloudflare worker for images generation which is the URL of the worker and the API Key-->
							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle"> <img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/cloudflare.ico',__FILE__)?>"><span> CloudFlare Workers Settings</span> </h2>
								<div class="inside TTWForm main" style="padding-bottom: 14px"> <!--start container-->
									<div class="field f_100 ">
										<label>CloudFlare Worker URL (For image generation)</label> <input value="<?php   echo get_option( 'wp_automatic_cf_worker_url' ) ?>" name="wp_automatic_cf_worker_url" type="text">
										<div class="description">
											*This is optional field but if you want to use the image generation feature of the plugin you need to add your CloudFlare worker URL here<br><br>*Check <a href="https://valvepress.com/how-to-create-ai-images-generation-api-for-free-using-cloudflare-workers/" target="_blank">this tutorial</a> on how to create a CloudFlare worker and get the URL
										</div>
									</div>

									<div class="field f_100 ">
										<label>CloudFlare API Key (For image generation)</label> <input value="<?php   echo get_option( 'wp_automatic_cf_api_key' ) ?>" name="wp_automatic_cf_api_key" type="text">
										<div class="description">
											*This is the key that you have set when applying the tutorial
										</div>
									</div>


									<div id="form-submit" class="field f_100 clearfix submit" style> <input style="margin-left: 0" value="Save Changes" type="submit"> </div>
									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>

						</div>
					</div>
					<!-- End post box  -->

					<!-- General post box -->
					<div class="postbox-container">
						<div style="min-height: 1px;" class="meta-box-sortables ui-sortable" id="normal-sortables">

							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle">
									<img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/search.png',__FILE__)?>"><span> Search and Replace</span>
								</h2>
								<div class="inside main TTWForm" style="padding-bottom: 14px">
									<!--start container-->

									<div class="field f_100 ">

										<p style="margin-bottom: 10px;">
											Search for words in the article and replace it (one set per line) <br>like <strong>word1|word2|word3</strong> . if the post contains <strong>word1</strong> it will be replaced by <strong>word2</strong> or <strong>word3</strong>
										</p>
										<textarea name="wp_automatic_replace"><?php   echo  stripslashes( get_option('wp_automatic_replace') )?></textarea>

									</div>

									<div class="field f_100">
										<div class="option clearfix">
											<input name="wp_automatic_options[]" <?php   echo cchecked('wp_automatic_options', 'OPT_REPLACE_NO_REGEX')  ?> value="OPT_REPLACE_NO_REGEX" type="checkbox"> <span class="option-title">Replace literally. </span> <br>

										</div>
										<div class="description">
											<small><i>By default, The plugin expects that you have inserted words above so for example if you added "fox" it will not replace it at the word "firefox" but will replace only if "fox" is a word. Tick this if you want to disable this behaviour and replace anywhere.</i></small>
										</div>
									</div>

									<div class="field f_100">
										<div class="option clearfix">
											<input name="wp_automatic_options[]" <?php   echo cchecked('wp_automatic_options', 'OPT_REPLACE_NO_PROTECT')  ?> value="OPT_REPLACE_NO_PROTECT" type="checkbox"> <span class="option-title">Do not protect HTML tags. </span> <br>

										</div>
										<div class="description">
											<small><i>By default, The plugin mask HTML tags before doing the search and replace. </i></small>
										</div>
									</div>

									<div id="form-submit" class="field f_100 clearfix submit" style>
										<input style="margin-left: 0" value="Save Changes" type="submit">
									</div>


									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>

							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle">
									<img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/money.png',__FILE__)?>"`><span>Ads settings</span>
								</h2>
								<div class="inside main TTWForm" style="padding-bottom: 14px">
									<!--start container-->
									<div id="field11-container" class="field f_100">
										<label for="field11"> Top Ad Code <i>(optional)</i>
										</label>
										<textarea rows="5" cols="20" name="wp_automatic_ad1content" id="field11"><?php   echo stripslashes(  get_option('wp_automatic_ad1') )?></textarea>
									</div>
									<div id="field11-container" class="field f_100">
										<label for="field11"> Bottom Ad Code <i>(optional)</i>
										</label>
										<textarea rows="5" cols="20" name="wp_automatic_ad2content" id="field11"><?php   echo stripslashes( get_option('wp_automatic_ad2') )?></textarea>
									</div>

									<div id="form-submit" class="field f_100 clearfix submit" style>
										<input style="margin-left: 0" value="Save Changes" type="submit">
									</div>

									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>

							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle">
									<img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/proxy.png',__FILE__)?>"><span> Proxy settings</span>
								</h2>
								<div class="inside main TTWForm" style="padding-bottom: 14px">
									<!--start container-->


									<div id="field11-container" class="field f_100">
										<label for="field11"> Use this proxy list <i>(one/line)(optional)</i>
										</label>
										<textarea rows="5" cols="20" name="wp_automatic_proxy" id="field11"><?php   echo stripslashes( get_option('wp_automatic_proxy') )?></textarea>


										<!-- checkbox Rotate proxies to use a new proxy every run -->
										<div class="option clearfix">
											<input name="wp_automatic_options[]" <?php   echo cchecked('wp_automatic_options', 'OPT_ROTATE_PROXY')  ?> value="OPT_ROTATE_PROXY" type="checkbox"> <span class="option-title"> Rotate proxies to use a new proxy every run</span>
										</div>

										<!-- checkbox force use these proxies on all campaigns -->
										<div class="option clearfix">
											<input name="wp_automatic_options[]" <?php   echo cchecked('wp_automatic_options', 'OPT_FORCE_PROXY')  ?> value="OPT_FORCE_PROXY" type="checkbox"> <span class="option-title"> Force use these proxies on all campaigns</span>
										</div>

									

										<div class="description">

											*Make sure your proxies are with port 80 (always open) or 8080 (sometimes open) which are open for connection with most servers or use any port that is open to connect on your server <br> *Format:<strong>ip:port</strong> <br> *Another Format : <strong>IP:port:username:password</strong> for proxies with authentication <br> *one proxy per line <br> *Some proxy services require server IP for authentication <a target="_blank" href="<?php echo site_url('/?wp_automatic=show_ip') ?>"><strong>Click here</strong></a> to know your server IP to use <br> *Check <a href="http://valvepress.com/use-private-proxies-pinterest-automatic/" target="_blank"><strong>this tutorial</strong></a> showing a tested service named <a href="https://instantproxies.com/billing/aff.php?aff=762">InstantProxies</a> you can use. <br> *Don't use public proxies used by thousands of pepole, it may get you into
											zillion troubles.
										</div>

									</div>
									<div id="form-submit" class="field f_100 clearfix submit" style>
										<input style="margin-left: 0" value="Save Changes" type="submit">
									</div>

									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>

							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle">
									<img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/settings.png',__FILE__)?>"><span> General settings</span>
								</h2>
								<div class="inside main TTWForm" style="padding-bottom: 14px">
									<!--start container-->

									<div class="field f_100 ">
										<label>Notifications to this email address</label> <input value="<?php   echo get_option( 'wp_automatic_fb_email' ) ?>" name="wp_automatic_fb_email" type="text">
										<div class="description">You can insert your email address here for the plugin to send an email notifications when required</div>
									</div>

									<div class="field f_100">
										<label> Title to tags/hashtags stop words <i>(in lower case)(one/line)(optional)</i></label>
										<textarea rows="5" cols="20" name="wp_automatic_ttt_stop"><?php   echo stripslashes( get_option('wp_automatic_ttt_stop') )?></textarea>
									</div>

									<div class="field f_100">
										<label>Additional Banned words (Skip posting the post if it contains any of these)(one/line)(optional)</i></label>
										<textarea rows="5" cols="20" name="wp_automatic_ccc_stop"><?php   echo stripslashes( get_option('wp_automatic_ccc_stop') )?></textarea>
										<div class="description">list get added to banned words only if the option is active at the campaign page</div>
									</div>

									<div class="field f_100">
										<label>Translation protected keywords (Protect these <strong>words</strong> when translating)(one/line)(optional)</i></label>
										<textarea rows="5" cols="20" name="wp_automatic_tra_stop"><?php   echo stripslashes( get_option('wp_automatic_tra_stop') )?></textarea>
										<div class="description">keywords list get protected when the translation option is active in the campaign page</div>
									</div>
									<div class="field f_100">
										<label>Limit categories list in the campaign to these categories IDs</i></label>
										<textarea rows="5" cols="20" name="wp_automatic_spec_cats"><?php   echo stripslashes( get_option('wp_automatic_spec_cats') )?></textarea>
										<div class="description">Add a comma seprated list of categories IDs only if you have too many categories and have problems getting all of them loaded when visiting the campaign. ex: 123,456</div>
									</div>

									<div class="field f_100 ">
										<label> Google translate char limit</label> <input value="<?php   echo get_option( 'wp_automatic_gtranslate_limit' ) ?>" name="wp_automatic_gtranslate_limit" type="text">
										<div class="description">Default: 13000, set to higher if needed and at your own peril, higher limit may cause performance and server load issues (NOT RECOMMENDED)(DANGER)</div>
									</div>

									<div class="field f_100 ">
										<label> Woo-Commerce Amazon product buy now text (optional)</label> <input value="<?php   echo get_option( 'wp_automatic_woo_buy' ) ?>" name="wp_automatic_woo_buy" type="text">
									</div>

									<div class="field f_100 ">
										<label> Woo-Commerce eBay product buy now text (optional)</label> <input value="<?php   echo get_option( 'wp_automatic_woo_buy2' ) ?>" name="wp_automatic_woo_buy2" type="text">
									</div>

									<div class="field f_100 ">
										<label>Maximum number of feeds to process per campaign on single run</label> <input value="<?php   echo get_option( 'wp_automatic_feed_max' ) ?>" name="wp_automatic_feed_max" type="text">
									</div>

									<!-- Name of the default category for posts for the plugin to remove from added posts -->
									<div class="field f_100 ">
										<label>ID of the Default category to remove from added posts (optional)</label> <input value="<?php   echo get_option( 'wp_automatic_default_cat' ) ?>" name="wp_automatic_default_cat" type="text">
										<div class="description">If you have a category named "Uncategorized" and you want the plugin to remove it from the added posts, add the id of the category here, you can find the id by visiting the category from your dashboard and find the tag_ID= value</div>
									</div>
									
									<?php if( function_exists('td_bbp_change_avatar_size') ){ ?>
										<div class="field f_100">
										<div class="option clearfix">
											<input name="wp_automatic_options[]" <?php   echo cchecked('wp_automatic_options', 'OPT_NO_NEWSPAPER')  ?> value="OPT_NO_NEWSPAPER" type="checkbox"> <span class="option-title">Disable Newspaper theme video integration</span>
										</div>
									</div>
									<?php }?>
									
									<div class="field f_100">
										<div class="option clearfix">
											<input name="wp_automatic_options[]" <?php   echo cchecked('wp_automatic_options', 'OPT_NO_FATAL')  ?> value="OPT_NO_FATAL" type="checkbox"> <span class="option-title">Disable register_shutdown_function (If you click the run now button and always get nothing )</span>
											<div style="padding-left:25px" class="description"><small>*If this option is enabled, prices updates will not work, used resources will not be reported after campaign/cron run.</small></div>
										</div>
										
									</div>

									<div class="field f_100">
										<div class="option clearfix">
											<input name="wp_automatic_options[]" <?php   echo cchecked('wp_automatic_options', 'OPT_NO_FRONT_JS')  ?> value="OPT_NO_FRONT_JS" type="checkbox"> <span class="option-title">Disable front end script and style from Automatic </span>
											<div style="padding-left:25px" class="description"><small>* When this option is enabled, Gallery for products will not work normally. disable if you do not import galleries like Amazon product galleries</small></div>
										</div>
										
									</div>

									 <!-- checkbox for enable showing private post types as well, by default the plugin shows public post types 	-->
									<div class="field f_100">
										<div class="option clearfix">
											<input name="wp_automatic_options[]" <?php   echo cchecked('wp_automatic_options', 'OPT_PRIVATE')  ?> value="OPT_PRIVATE" type="checkbox"> <span class="option-title">Show private post types as well</span>
										</div>
										<div style="padding-left:25px" class="description">
											<small><i>By default, The plugin shows only public post types for selection on the plugin campaign page. Tick this if you want to show private post types as well.</i></small>
										</div>
									</div>

									<div id="form-submit" class="field f_100 clearfix submit" style>
										<input style="margin-left: 0" value="Save Changes" type="submit">
									</div>

									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>


							<div class="postbox wp_automatic_hide_noactive" id="dashboard_right_now">
								<h2 class="hndle">
									<img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/cron.png',__FILE__)?>"><span> Cron settings</span>
								</h2>
								<div class="inside main TTWForm" style="padding-bottom: 14px">
									<!--start container-->


									<label> Cron Secret word [optional]</label> <input placeholder="cron" value="<?php   echo get_option( 'wp_automatic_cron_secret' ) ?>" name="wp_automatic_cron_secret" type="text">
									<div class="description">
										Your cron link will be <strong>example.com/?wp_automatic=YOUR_SECRET_WORD</strong> and if you setup your cron job you will need to use the new cron link appears below after clicking save.
									</div>

									<br> <br>


									<label> Number of campaigns to process per cron call [optional]</label> <input placeholder="1" value="<?php   echo get_option( 'wp_automatic_cron_campaigns_to_process' ) ?>" name="wp_automatic_cron_campaigns_to_process" type="text">
									<div class="description">
										By default, the cron job when called, it will process one campaign and exit, change this value if you want to increase number of campaigns at your own peril!. This option is not recommended but at some cases, you may be confident of your server and have no problem processing multiple campaigns on a single run [default: 1] <br><br>NOTE: if any of the being processed campaign resulted in a new post, the cron exist instantly there is a hard limit which is one post per cron call.
									</div>

									<br> <br>
									
									
					     <?php
	
	$wp_automatic_secret = wp_automatic_trim( get_option ( 'wp_automatic_cron_secret' ) );
	if (wp_automatic_trim( $wp_automatic_secret ) == '')
		$wp_automatic_secret = 'cron';
	
	$cronurl = home_url ( '?wp_automatic=' . $wp_automatic_secret )?>
					    Cron Command - ( <a target="blank" href="<?php   echo $cronurl ?>">Start now </a>)
									<div style="background-color: #FFFBCC; border: 1px solid #E6DB55; color: #555555; padding: 5px; width: 97%; margin-top: 10px">
						<?php
	
	echo 'curl ' . $cronurl;
	?> 
						</div>
									<br>

									<p>if the above command didn't work, use the one below</p>
									<div style="background-color: #FFFBCC; border: 1px solid #E6DB55; color: #555555; padding: 5px; width: 97%; margin-top: 10px">
						<?php
	// curl --location --request POST 'https://www.gentlemanreport.com/?wp_automatic=cron'
	

	echo "curl --location --request POST '" . $cronurl . "'" ;
	?>
						</div>

									<br>

									<p>if the above command didn't work, use the one below</p>
									<div style="background-color: #FFFBCC; border: 1px solid #E6DB55; color: #555555; padding: 5px; width: 97%; margin-top: 10px">
						<?php
	// $cronpath = dirname ( __FILE__ ) . '/cron.php';
	echo 'wget -O /dev/null ' . $cronurl;
	?>
						</div>
						<br>

						<p>Use this command instead if you want to bypass forced cache issues</p>
									<div style="background-color: #FFFBCC; border: 1px solid #E6DB55; color: #555555; padding: 5px; width: 97%; margin-top: 10px">
						<?php
	// $cronpath = dirname ( __FILE__ ) . '/cron.php';
	echo 'curl -L https://deandev.com/redirector/redirector/?redirect=' . base64_encode( $cronurl ) ;
	?>
						</div>


						<br>
						<p>
							Tutorial: <a href="http://valvepress.com/wordpress-internal-cron-job-work-may-need-setup-external-cron/" target="_blank">How to setup cron job for WordPress Automatic plugin</a>
							<br>Tutorial: <a href="https://valvepress.com/how-to-exclude-wordpress-automatic-plugin-cron-url-from-cloudflare-caching" target="_blank">How to exclude WordPress Automatic plugin cron URL from Cloudflare caching</a>
						</p>

 

									<div class="field f_100">
										<div class="option clearfix">
											<input name="wp_automatic_options[]" <?php   echo cchecked('wp_automatic_options', 'OPT_CRON')  ?> value="OPT_CRON" type="checkbox"> <span class="option-title"> Use <abbr title="Tick this option to use wordpress built-in cron ">Built in cron</abbr> instead
											</span>
										</div>
									</div>

									<div class="field f_100">
										<div class="option clearfix">
											<input name="wp_automatic_options[]" <?php   echo cchecked('wp_automatic_options', 'OPT_PREVIEW_EDIT')  ?> value="OPT_PREVIEW_EDIT" type="checkbox"> <span class="option-title">Preview posts in edit screen not via front end</span>
										</div>
									</div>

									<div class="field f_100">
										<div class="option clearfix">
											<input name="wp_automatic_options[]" <?php   echo cchecked('wp_automatic_options', 'OPT_ADMIN_ONLY')  ?> value="OPT_ADMIN_ONLY" type="checkbox"> <span class="option-title">Show menu to admins only</span>
										</div>
									</div>


									<div id="form-submit" class="field f_100 clearfix submit" style>
										<input style="margin-left: 0" value="Save Changes" type="submit">
									</div>

									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>



							<div class="postbox " id="dashboard_right_now">
								<h2 class="hndle">
									<img class="wp_automatic_box_icon" src="<?php   echo plugins_url('images/key.png',__FILE__)?>"><span> License</span>
								</h2>
								<div class="inside main TTWForm" style="padding-bottom: 14px">

									<!--start container-->
 
 									<?php
	
	$the_license = get_option ( 'wp_automatic_license', '' );
	
	 
		
		?>
 										
 										<div class="field f_100 ">
										<label> Purchase code</label> <input placeholder="Ex: 4308eedb-1add-43a9-bbba-6f5d5aa6b8ee" value="<?php   echo $the_license ?>" name="wp_automatic_license" type="text">
										<div class="description">Your plugin purchase code</div>
									</div>		
 									
 									 
 									
									
									<?php if( isset($wp_automatic_active_error) && stristr($wp_automatic_active_error,	 'another')  ) {?>
								
										<div class="field f_100 ">
										<label> Change domain </label> <input name="wp_automatic_options[]" value="OPT_CHANGE_DOMAIN" type="checkbox">
										<div class="description">Disable license at the other domain and use it with this domain</div>
									</div>
									
									<?php } ?>
 
 
 									<div class="field f_100 ">
										<label> License status:</label>
										<div class="description">
 										
 											<?php
	
	if (wp_automatic_trim( $licenseactive ) != '') {
		echo 'Active';
	} else {
		echo '<span style="color:red">Inactive</span> ';
		
	}
	
	if (isset ( $wp_automatic_active_error ))
			echo '<p><span style="color:red">' . $wp_automatic_active_error . '</span></p>';

	?>


										</div>
									</div>

									<div id="form-submit" class="field f_100 clearfix submit" style>
										<input style="margin-left: 0" value="Save Changes" type="submit">
									</div>

									<!--start container-->
									<div style="clear: both"></div>
								</div>
							</div>



						</div>
					</div>
					<!-- End post box  -->


				</div>
				<!-- dashboard widgets -->
			</form>
		</div>
		<!-- dashboard widgets wrap -->

		<!--start container-->
	</div>
</div>
<!-- Panels -->

<script type="text/javascript">

		var pluginDir='';

		jQuery('.postbox h3').click( function() {
		   jQuery(jQuery(this).parent().get(0)).toggleClass('');

		} );
</script>


<?php } ?>