<?php

/**
 * E-E-A-T Verification Badge Renderer
 * 
 * Displays last verified date and fact-checker attribution.
 *
 * @package SEO_Article_Generator
 * @since   2.2.0
 */

namespace SEO_Article_Generator\Frontend;

use SEO_Article_Generator\EEAT\Author_Profile_Manager;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Verification Badge Renderer
 * @MODIFIED 2025-12-16 v2.2.0: Created for E-E-A-T verification signals
 */
class Verification_Badge_Renderer
{

    /**
     * Render verification badge
     */
    public function render_badge($post_id)
    {
        $hero_data = \SEO_Article_Generator\Plugin::get_instance()->get_hero_data($post_id);
        $last_verified = is_array($hero_data) ? ($hero_data['last_verified_date'] ?? '') : '';
        $fact_checked_by = get_post_meta($post_id, '_seo_fact_checked_by', true);

        if (! $last_verified && ! $fact_checked_by) {
            return '';
        }

        $author_manager = new Author_Profile_Manager();
        $fact_checker = $fact_checked_by ? $author_manager->get_author_profile($fact_checked_by) : null;

        ob_start();
?>
        <div class="seo-verification-badge">
            <div class="seo-verification-icon">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="#00a32a">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
                </svg>
            </div>

            <div class="seo-verification-text">
                <?php if ($last_verified) : ?>
                    <strong>Last Verified:</strong>
                    <time datetime="<?php echo esc_attr($last_verified); ?>">
                        <?php echo esc_html(date('F j, Y', strtotime($last_verified))); ?>
                    </time>
                <?php endif; ?>

                <?php if ($fact_checker) : ?>
                    <br>
                    <strong>Fact-Checked by:</strong>
                    <a href="<?php echo esc_url($fact_checker['posts_url']); ?>">
                        <?php echo esc_html($fact_checker['name']); ?>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    <?php
        return ob_get_clean();
    }

    /**
     * Render compact badge (for article header)
     */
    public function render_compact_badge($post_id)
    {
        $hero_data = \SEO_Article_Generator\Plugin::get_instance()->get_hero_data($post_id);
        $last_verified = is_array($hero_data) ? ($hero_data['last_verified_date'] ?? '') : '';

        if (! $last_verified) {
            return '';
        }

        $days_ago = floor((time() - strtotime($last_verified)) / DAY_IN_SECONDS);

        ob_start();
    ?>
        <span class="seo-verified-compact" title="Last verified <?php echo esc_attr(date('F j, Y', strtotime($last_verified))); ?>">
            ✓ Verified <?php echo esc_html($days_ago === 0 ? 'today' : $days_ago . ' days ago'); ?>
        </span>
<?php
        return ob_get_clean();
    }
}
