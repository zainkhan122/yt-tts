package com.snsaver.app.data.network

import com.google.gson.*
import com.snsaver.app.domain.model.Platform
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.jsoup.Jsoup
import javax.inject.Inject

data class ExtractedMedia(val urls:List<String>,val types:List<String>,val filename:String?=null)
data class Metadata(val caption:String?=null,val hashtags:List<String> = emptyList(),val title:String?=null,val thumbnail:String?=null,val profileName:String?=null,val profileUrl:String?=null)

class PlatformDetector @Inject constructor(){
 fun extract(text:String)=Regex("https?://[^\\s<>]+",RegexOption.IGNORE_CASE).find(text)?.value?.trimEnd('.',',',')',']')
 fun detect(url:String):Platform { val host=runCatching{java.net.URI(url).host?.lowercase().orEmpty()}.getOrDefault("");return when{
  host.endsWith("instagram.com")->Platform.INSTAGRAM;host.endsWith("tiktok.com")->Platform.TIKTOK
  host.endsWith("x.com")||host.endsWith("twitter.com")->Platform.TWITTER;host.endsWith("facebook.com")||host.endsWith("fb.watch")->Platform.FACEBOOK
  host.endsWith("youtube.com")||host.endsWith("youtu.be")->Platform.YOUTUBE;host.endsWith("reddit.com")||host.endsWith("redd.it")->Platform.REDDIT
  host.endsWith("pinterest.com")||host.endsWith("pin.it")->Platform.PINTEREST;host.endsWith("snapchat.com")->Platform.SNAPCHAT;else->Platform.UNKNOWN}}
}

class CobaltApiService @Inject constructor(private val client:OkHttpClient,private val gson:Gson){
 suspend fun fetch(source:String,endpoint:String,key:String)=withContext(Dispatchers.IO){
  val json=JsonObject().apply{addProperty("url",source);addProperty("downloadMode","auto");addProperty("filenameStyle","basic")}
  val req=Request.Builder().url(endpoint.trimEnd('/')+"/").post(gson.toJson(json).toRequestBody("application/json".toMediaType())).header("Accept","application/json").apply{if(key.isNotBlank())header("Authorization","ApiKey $key")}.build()
  client.newCall(req).execute().use { res ->
   val body=res.body?.string().orEmpty();if(!res.isSuccessful)error("Extractor returned HTTP ${res.code}")
   val obj=JsonParser.parseString(body).asJsonObject
   if(obj["status"]?.asString=="error") error(obj.getAsJsonObject("error")?.get("code")?.asString?:"Extraction failed")
   val urls=mutableListOf<String>();val types=mutableListOf<String>()
   obj["url"]?.takeIf{!it.isJsonNull}?.asString?.let{urls+=it;types+="video"}
   obj.getAsJsonArray("picker")?.forEach{e->e.asJsonObject.let{p->p["url"]?.asString?.let(urls::add);types+=p["type"]?.asString?:"video"}}
   if(urls.isEmpty()) error("Extractor returned no downloadable media")
   ExtractedMedia(urls,types,obj["filename"]?.takeIf{!it.isJsonNull}?.asString)
  }
 }
}
class MetadataScraper @Inject constructor(private val client: OkHttpClient) {
    suspend fun scrape(url: String, platform: Platform): Metadata = withContext(Dispatchers.IO) {
        runCatching {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36")
                .build()
            client.newCall(request).execute().use { response ->
                val document = Jsoup.parse(response.body?.string().orEmpty())
                fun meta(property: String): String? = document
                    .selectFirst("meta[property=$property]")
                    ?.attr("content")
                    ?.takeIf { it.isNotBlank() }

                val caption = meta("og:description")
                    ?: document.selectFirst("meta[name=description]")?.attr("content")
                val title = meta("og:title")
                val tags = Regex("#([\\p{L}\\p{N}_]+)")
                    .findAll(caption.orEmpty())
                    .map { it.groupValues[1] }
                    .distinct()
                    .toList()
                val user = if (platform == Platform.INSTAGRAM) {
                    Regex("^(@?[\\w.]+) on Instagram")
                        .find(title.orEmpty())?.groupValues?.get(1)?.removePrefix("@")
                } else null
                Metadata(caption, tags, title, meta("og:image"), user, user?.let { "https://instagram.com/$it" })
            }
        }.getOrDefault(Metadata())
    }
}
