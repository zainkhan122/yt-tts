## [9.5.6] - 2026-08-23

### Added — Complete Question Bank PDFs (append-only volumes)
- Each PDF-archive topic now also gets a **complete bank of ALL its published questions** (e.g. all 70 Geography MCQs, not just the 3 from July), split into append-only chronological volumes via `NM_Monthly_PDF_Archive::ensure_complete_volumes()`.
- **Volume design:** Vol 1 = oldest N questions, **frozen forever once full** (file never rebuilt — stable URL and bytes for bookmarks/backlinks); only the newest (open) volume regenerates as questions arrive, overwriting the same filename (stable URL). Membership is anchored to post-ID order, so boundaries never shift.
- **Cap:** `nm_pdf_volume_cap` setting, default **200**, clamped 100–300 (Dompdf memory/render-safety limit). Configurable in the PDF tab.
- **Refresh trigger:** the **1st of every month** (daily cron with per-page `Y-m` stamp = automatic catch-up if WP-Cron misses the 1st). The refresh policy is stated on the archive page AND on each PDF cover, so users know when to come back.
- **Quality gate:** reported/flagged MCQs (`mcq_reported = yes`) are excluded from **both** the complete-bank and the monthly PDFs (`quality_gate_meta_query()` shared by both collectors).
- **Ordering:** inside each volume, questions are grouped by **sub-topic with section headings** (alphabetical sections, chronological within), with **continuous numbering across volumes** (Vol 2 at cap 200 starts at Q201).
- Archive page gains a headline **"Complete {Topic} MCQ Bank — All N Questions"** section above the monthly downloads, listing each volume with its question range, count, and a ✓ Complete / ↻ Updated monthly badge.
- Refactor: Dompdf rendering extracted into shared `render_pdf_file()` (used by monthly + volume PDFs; late-static-bound for testability).

## [9.5.5] - 2026-08-23

### Added — One-click migration of EXISTING generated posts to Gutenberg blocks
- New **"🧱 Convert Generated Posts to Blocks"** admin tool (next to the author tools): batch-converts all previously generated pillars, news/daily roundups and monthly PDF archive pages from classic HTML to block markup via `NM_News_Article_Generator::convert_existing_posts_batch()`.
- Resumable & idempotent: every processed post is stamped `_nm_blocks_converted`; re-running (or resuming after a timeout) only touches the remainder, and posts already in blocks are skipped unchanged. Frontend output is byte-for-byte unaffected.
- New posts are stamped at creation (they're born as blocks since 9.5.4), keeping the tool's remaining-count accurate.
- New AJAX endpoint `nm_convert_blocks` (admin-only, nonce-protected, 25-post batches).

## [9.5.4] - 2026-08-23

### Changed — Generated posts now use Gutenberg BLOCK markup
- New `NM_News_Article_Generator::convert_html_to_blocks()`: all generated content (pillars, news roundups, daily roundups, monthly PDF archive pages) is now stored as native block markup instead of raw HTML, so posts open in the Block Editor as real blocks — not one legacy "Classic" blob.
- Mapping (validity-first): attribute-free `h1–h6` → `core/heading`, plain/class-only `<p>` → `core/paragraph` (class preserved as `className`, e.g. the `nm-topic-cta` CTA), flat `<ul>/<ol>` → `core/list` + `core/list-item`, bare `[shortcode]` (the `[nm_related_mcqs]` block) → `core/shortcode`.
- Anything that can't be mapped losslessly (inline styles, divs, tables, nested lists) is wrapped in `core/html` (Custom HTML block) — always a VALID block, never an "invalid content" editor warning, and no content is ever dropped. Already-converted content passes through untouched (idempotent).

## [9.5.3] - 2026-08-23

### Changed — Topic hub CTA placement & copy
- The topic hub link in generated pillars/roundups moved from the very END of the page (below the FAQ, where readers never scroll) to **directly under the "Related Practice MCQs" block** — the highest-engagement slot on the page.
- Upgraded from a bare topic-name link to a real call-to-action: **"Read the latest {Topic} MCQs Now →"** (wrapped in `<p class="nm-topic-cta">` for easy styling).
- Pillars now pass their topic explicitly (`topic_term_id`) to `build_content()`, so the CTA renders even when the related-MCQ list is empty; roundups keep deriving it from the day's most common topic.

## [9.5.2] - 2026-08-23

### Fixed — Author attribution (admin vs frontend mismatch)
- **Random named-author rotation now applies to ALL MCQ generation paths.** `class-nm-generation-service.php` hard-coded `author_name = 'TheQuizWire'` in both the News and Topic cron paths, which caused `save_mcq_post_unified()` to skip the 9.2.0 rotation entirely — every MCQ's `post_author` stayed the triggering admin while the frontend byline showed something else. The hard-coded lines are removed; `post_author` + `mcq_author_name` are now assigned together from the configured author pool.
- **Smart Scheduler no longer overwrites `post_author` at publish time.** `publish_one_from_queue()` used to stamp the current user / first admin onto every scheduled MCQ, silently undoing the rotation. It now preserves the creation-time author and only repairs orphaned posts (author 0).
- Removed the dead `'post_author'` save-arg in the topic path (`save_mcq_post_unified()` never read it).

### Fixed — Evergreen pillars (SEO)
- **Pillars are refreshed IN PLACE — one canonical post per topic.** `generate_pillar()` previously inserted a brand-new post every cadence sweep (default weekly), piling up near-duplicate pillars targeting the same keyword (cannibalization / scaled-content risk). It now updates the existing pillar (same ID/URL/backlinks, bumped `post_modified`, "Last Updated" shows automatically) and only inserts when the topic has no pillar yet.
- `is_due()` now measures cadence against **last modified** (publish date never moves on in-place refresh); default cadence raised 7 → **30 days**.
- **News-derived MCQs are excluded from pillar grounding** (`meta_query` on `mcq_source_url`), so dated news facts no longer leak into evergreen guides.
- Pillar prompt hardened: no in-content bylines ("By …" headings), no in-content FAQ/"Common Questions & Answers" (single FAQ + schema is appended by the site), no model-emitted "Related MCQs" section, well-formed-HTML requirement, stronger evergreen constraint.

### Fixed — Generated article content quality
- `build_content()`: FAQ-strip regex now also removes "Common Questions & Answers" / "Q&A" variants (double-FAQ bug); strips in-content byline headings; runs `force_balance_tags()` after `wp_kses_post()` (stray `</p>` bug).

### Changed — Related Practice MCQs are now DYNAMIC
- New `[nm_related_mcqs]` shortcode (`class-nm-shortcode-manager.php`): resolves published MCQs at render time. Topic mode (`topic_id`) for pillars — auto-refreshes as new MCQs publish; fixed-set mode (`ids`) for roundups — silently drops drafts/deleted posts. Kills the 404 trap where roundups baked pretty permalinks to still-draft MCQs.
- Pillars and both roundup paths now embed the shortcode instead of static `<a>` lists; the legacy baked-link fallback now links to **published** MCQs only.

### Added — Categories for generated posts
- Pillars are filed under **Study Guides** (`study-guides`), roundup articles under **Daily Roundups** (`daily-roundups`) via a new `NM_News_Article_Generator::ensure_category()` helper — no more "Uncategorized". Topic terms are deliberately NOT mirrored as categories (the `topic` taxonomy owns topical archives).

## [9.1.1] - 2026-07-31
- **Fixed**: "Total Created Today" dashboard card counting Buffer social share events (logged as `event_type: created` with `mcq_id`) as MCQ creations — `NM_Ajax_Admin::nm_get_activity_stats()` now excludes `source_type = 'buffer'` so only real MCQ creations are counted.
- **Fixed**: Duplicate detection logged twice per question in news/topic generation (`class-nm-generation-service.php`) — removed the redundant legacy `nm_log_activity` call so only the structured `nm_log_duplicate_detection` event (with method + similarity) is written, eliminating duplicate rows in the Logs page and inflated duplicate counts in activity stats.

## [9.1.0] - 2026-07-29
- **Added**: Audit trail for all Buffer share events via `NM_Generation_Logger` — every share, skip, and error is now visible in the Logs page and CSV export.
- **Fixed**: Facebook Buffer share failing with "A link attachment cannot be combined with assets" — the image asset is now excluded when "Post as link" is enabled for Facebook, preventing the Buffer API conflict.
- **Changed**: All 21 `error_log()` calls in `class-nm-buffer-integration.php` replaced with structured audit log events (`source_type: buffer`).

## [8.9.1] - 2026-01-13
- **Added**: MCQ Tag fallback logic to ensure every MCQ is tagged using its parent topic/subtopic if AI tags are missing.
- **Improved**: MCQ Tag relevance by refining AI prompts to demand specific academic subjects and forbidding generic tags.
- **Fixed**: Inflated "Total Created Today" count on dashboard by correcting cron log severities and filtering stats queries to count only valid MCQs.

## [2.2.1] - 2026-01-07
- **Fix**: Resolved issue where auto-generated MCQs (Cron) were stuck in "Pending" status due to missing author assignment.
- **Improved**: Added "Pending MCQs" recovery tool to System Health widget to fix previously stuck MCQs.

## [8.6.0] - 2025-12-18

### Added - Video Studio: Intelligent Visuals & AI Orchestration

- **AI Background Studio**: Integrated DALL-E 3 for generating high-quality, vertical (9:16) background synthesis directly within the Studio.
- **Smart Keyword Auto-Mapper**: Automatically scans quiz content and assigns appropriate background visuals and sound effects based on thematic keyword detection.
- **Interactive Animated Overlays**: Expanded the animation engine to support physics-based "Smart Stickers" that trigger dynamically during narration.
- **Improved UI**: New "Generate AI Background" controls integrated into the Assets panel.

### Changed

- **`class-nm-video-studio.php`**: Added `ajax_generate_ai_background` and expanded the AI & Tools UI.
- **`nm-video-studio.js`**: Refactored asset loading to support dynamic AI synthesis and keyword orchestration.
- **`nm-animation-engine.js`**: Enhanced overlay module for interactive keyword-driven visuals.

---

## [8.5.0] - 2025-12-18

### Added - Architectural Consolidation & Logic Hardening

- **Refactored Template Engine**: Unified `NM_TemplateManager` and `NM_VideoTemplates` into a cohesive OOP system with specialized renderers for all 17 templates.
- **Reactive Waveform**: True audio analysis replacement for the `Math.random()` placeholder, supporting real-time peaks and deterministic rendering.
- **Multi-Provider TTS (Full Support)**: Truth-in-labeling for Google Cloud, Azure, and OpenAI providers with high-quality neural voice integration.
- **Drift-Free Captions**: Implemented non-linear timing models based on word length to eliminate caption synchronization issues.

### Changed

- **`nm-video-studio.js`**: Surgically removed 500+ lines of redundant legacy rendering code, delegating all visual logic to the new `NM_TemplateManager`.
- **`nm-animation-engine.js`**: Upgraded `dynamicCaptions` to a non-linear timing model.
- **`nm-tts-manager.js`**: Unified server-side TTS handling for OpenAI, Google, and Azure.
- **`class-nm-video-studio.php`**: Upgraded `ajax_generate_tts` to handle multiple providers natively.

---

## [8.4.1] - 2025-12-18

### Added - Video Studio: High-Performer SEO Upgrades

- **Search-Driven SEO**: New "Target Keyphrases" field for AI-powered algorithm indexing.
- **Platform Intelligence**: Context-aware metadata generation for TikTok, YouTube Shorts, and Instagram Reels.
- **3-3-3 Hashtag Strategy**: Implements industry-standard tag hierarchy (Broad, Niche, Search-Specific).
- **Psychological Hooks**: AI-generated descriptions now use curiosity gaps and engagement-focused CTAs.
- **SEO Apply System**: One-click sync from generated SEO data to video export metadata.

### Changed

- **`nm-seo-generator.js`**: Complete refactor of the prompt engineering logic to high-performer standards.
- **`nm-video-studio.js`**: Enhanced bindings for SEO keywords and platform-aware generation.
- **`class-nm-video-studio.php`**: Upgraded SEO metadata UI panel with keyword support and expanded description preview.

---

## [8.4.0] - 2025-12-18

### Added - Video Studio: Viral Juice & Advanced Automation

- **Dynamic Captions (Hormozi Style)**: Real-time word highlighting and "pop" effects synced with TTS narration.
- **Ken Burns Camera Motion**: Subtle, cinematic background scale/pan to make static visuals feel alive.
- **Automated Sound Design**: Integrated "Whoosh" SFX for every slide transition and "Pop" reveals for kinetic text.
- **Engine Enhancements**:
  - `NM_AnimationEngine`: New `dynamicCaptions()` and `startKenBurns()` modules.
  - `NM_AudioManager`: New `autoSFX()` layer for event-driven sound triggering.

### Changed

- **`nm-video-studio.js`**:
  - Wired transition whooshes to the `QUESTION_TRANSITION_START` event.
  - Optimized camera transform stack for smoother 60FPS preview.
- **`wp-news-mcq-generator.php`**:
  - Incremented version to 8.4.0.

---

## [8.3.0] - 2025-12-18

### Added - Video Studio: Batch Job Manager UI

- **Job Manager Dashboard**: New persistent UI for tracking rendering jobs
  - **Persistent History**: Jobs are saved to `localStorage` (up to 50 items) for persistence across sessions
  - **Batch Queue Tracking**: Real-time status updates per batch with attempt counters
  - **Clear History**: Integrated option to wipe job logs
- **Smart Auto-Retry Logic**: Enhanced robustness for long renders
  - Automatically retries failing batches up to 3 times before reporting an error
  - Handles transient browser/FFmpeg stalls gracefully
  - Manual "Retry" button for failed jobs in history
- **UI Refinement**: Added Job Manager panel to the studio sidebar for better professional workflow

### Changed

- **`nm-video-studio.js`**:
  - Implemented `logJob()` and `renderJobManager()` for persistent state
  - Refactored `startBatchGeneration()` with an async retry loop
  - Wired Job Manager UI events (clear, retry)
- **`class-nm-video-studio.php`**:
  - Added Job Manager control group and queue list container
- **`wp-news-mcq-generator.php`**:
  - Incremented version to 8.3.0

---

## [8.2.0] - 2025-12-18

### Added - Video Studio: Kinetic Overlays & Audio Sync

- **Kinetic Overlays**: Automatically spawned emojis based on keyword detection
  - Detects "money", "time", "world", "love", "idea", "win" and spawns theme-matched emojis
  - Physics-based animation: Gravity, rotation, and fading for viral energy
- **Timeline Synchronization**:
  - **Boundary Markers**: Visual indicators on the scrubber for question and answer transitions
  - **Simulated Waveform**: Professional aesthetic decorator on the timeline to aid navigation

### Changed

- **`nm-animation-engine.js`**:
  - Created `NM_AnimationEngine.overlays` system for managing kinetic elements
- **`nm-video-studio.js`**:
  - Integrated keyword scanning in the `drawFrame` loop
- **`nm-timeline.js`**:
  - Added marker storage and simulated waveform rendering logic

---

## [8.1.0] - 2025-12-18

### Added - Video Studio: Industry Standard Enhancements

- **Motion Effects & Blur**: Integrated high-quality motion blur into transitions
  - Uses offscreen buffering for smooth, high-fidelity blurring without performance hit
  - New professional easings: `smoothStep`, `backOut`, `anticipate`
- **Scrubbable Timeline**: Interactive frame-by-frame seeking in the studio
  - New `nm-timeline.js` manages seek logic and time formatting
  - Real-time sync between playback and scrubber UI
  - Supports manual scrubbing even when paused for precise editing
- **Asset Library**: Reusable visual asset management
  - Save custom backgrounds (images/videos) to local library
  - Persistent storage via `localStorage`
  - Quick apply/remove UI with tabbed categorization

### Changed

- **`nm-animation-engine.js`**:
  - Implemented `motionBlur` utility in `NM_AnimationEngine.utils`
  - Added offscreen buffer support to `NM_AnimationEngine.transitions`
  - Refactored slide transitions to use integrated motion blur
- **`nm-video-studio.js`**:
  - Wired `NM_Timeline` to detect scrubbing and update preview
  - Added Asset Library hooks and rendering logic
- **`class-nm-video-studio.php`**:
  - Added Timeline UI and Asset Library panels
  - Enqueued `nm-timeline.js` and `nm-asset-library.js`

---

## [8.0.0] - 2025-12-18

### Added - Video Studio: Deterministic Rendering & SEO Generator

- **Deterministic Rendering Engine**: Replaced real-time `MediaRecorder` with frame-by-frame capture
  - Renders at exact 30FPS regardless of device performance
  - Uses `canvas.toBlob()` per frame → FFmpeg image sequence → MP4
  - Progress UI shows "Rendering Frame X/Y" for user feedback
  - Solves browser throttling issues when tab is inactive
- **Template Manager** (`nm-template-manager.js`): Abstracted drawing logic
  - `VideoTemplate` base class with `render(ctx, state, assets)` method
  - `TriviaTemplate` and `NeonTemplate` implementations
  - Supports Video Backgrounds and Outro screens
- **SEO Metadata Generator** (`nm-seo-generator.js`): AI-powered metadata
  - Generates viral Title, Description, and Hashtags
  - Calls new `ajax_generate_seo` PHP endpoint
  - Uses Gemini Flash API with fallback defaults

### Changed

- **`nm-video-studio.js`**:
  - `drawFrame()` now accepts optional `manualElapsed` for deterministic mode
  - `startBatchGeneration()` refactored to use `renderBatchJob()`
  - Removed `recordBatch()` (legacy MediaRecorder logic)
  - Integrated `NM_TemplateManager` for all rendering
- **`class-nm-video-studio.php`**:
  - Added `ajax_generate_seo` AJAX handler
  - Enqueued `nm-template-manager.js` and `nm-seo-generator.js`

### Technical Details

- **New Files**:
  - `assets/js/nm-template-manager.js` (180 lines)
  - `assets/js/nm-seo-generator.js` (95 lines)
- **Rendering Performance**: ~40-90s for 5-question video (depends on local PC)
- **VPS Impact**: Zero (all rendering is client-side)

---

## [7.7.0] - 2025-12-17

### Added - Video Studio Priority 3: Workflow Efficiency

- **Batch Logging**: Success/failure tracking with retry (1 retry)
- **Brand Kit Presets**: Save/load branding configs via localStorage
- **Export Options State**: Platform, quality, watermark persisted
- **New State Properties**: batchLog, previewMode, exportOptions, brandKitPresets

---

## [7.6.1] - 2025-12-17

### Added - Video Studio Phase 3: UI Polish

- **AI Hook Dropdown**: UI with regenerate button, AJAX binding
- **Export Options**: Platform (TikTok/Reels/Shorts), quality, watermark toggle
- **Animated Score Cards**: Count-up animation with easing, particle burst on CTA
- **`generateHooks()`**: Async JS method for AI hook fetch

---

## [7.6.0] - 2025-12-17

### Added - Video Studio Phase 3: Kinetic Text & AI Hooks

- **Word-by-Word Hooks**: `drawHook()` uses `kineticText.wordByWord()` with popIn effect
- **Animated Questions**: `drawQuestionCard()` reveals text with slideUp effect (first 1.5s)
- **Template Integration**: Kinetic text uses template colors and fonts
- **AI Hook Generator**: `ajax_generate_hooks()` generates 5 viral hook variations via Gemini AI
- **Fallback Hooks**: Default hooks provided when API unavailable

---

## [7.5.2] - 2025-12-17

### Changed - Video Studio: Visual Integration

- **Camera Effects**: Shake on answer reveal, transform applied per frame
- **Transitions**: 8 transition types triggered between questions (fadeZoom, slideLeft, etc.)
- **Template Selector**: Expanded to 17 templates grouped by category
- **Event Emissions**: ANSWER_REVEAL and QUESTION_TRANSITION_START

---

## [7.5.1] - 2025-12-17

### Changed - Video Studio Phase 2: Module Integration

- **Event-Driven Architecture**: Added EventBus pub/sub system with EVENTS constants
- **Audio Integration**: Wired `playSfx()` to NM_AudioManager with synthesizer fallback
- **TTS Integration**: Wired `speakText()` to NM_TTSManager with TTS_START/TTS_END events
- **Playback Events**: PREVIEW_START/PREVIEW_STOP emissions for music lifecycle
- **Code Quality**: JSDoc documentation, @MODIFIED comments for all changes

---

## [7.5.0] - 2025-12-17

### Added - Video Studio Phase 1: Supercharged Client-Side Rendering

**Animation Engine** (`nm-animation-engine.js` - 580 lines)

- 15 easing functions (quad, cubic, expo, bounce, elastic, etc.)
- Kinetic typography with word-by-word reveals (popIn, slideUp, fadeIn, bounce effects)
- Typewriter effect for character-by-character reveals
- 8 transition presets: fadeZoom, slideLeft, slideRight, swipeUp, flashWhite, zoomBlur, pixelate, glitch
- Camera effects: shake, zoom, pan with duration and easing control
- Enhanced particle system: confetti, sparks, stars with physics (gravity, wind, rotation)

**TTS Manager** (`nm-tts-manager.js` - 380 lines)

- Multi-provider support: Edge TTS (free), Google Cloud TTS (4M chars/month free), Web Speech API (fallback)
- 8 Edge TTS voices, 6 Google Cloud voices pre-configured
- Audio caching to avoid redundant API calls
- Pre-generation for batch processing
- Duration estimation for animation sync
- Automatic fallback chain if primary provider fails

**17 Professional Templates** (`nm-video-templates.js` - 520 lines)

- **Professional**: corporate, minimalist, elegant
- **Energetic**: neon, fire, electric
- **Themed**: horror, space, nature, retro80s, cyberpunk
- **Educational**: classroom, science, history
- **Existing (upgraded)**: tech, sports, trivia
- Each template includes: colors, fonts, background gradients, transition preferences, particle types

**Audio Manager** (`nm-audio-manager.js` - 310 lines)

- SFX support: tick, correct, wrong, whoosh, reveal, countdown, transition, success
- Background music with loop and fade controls
- Volume control per channel (master, SFX, music)
- Music ducking during TTS playback
- Custom audio loading from uploads

### Technical Details

- **New Files**:

  - `assets/js/nm-animation-engine.js` - Animation library
  - `assets/js/nm-tts-manager.js` - TTS provider abstraction
  - `assets/js/nm-video-templates.js` - Template definitions
  - `assets/js/nm-audio-manager.js` - Audio management
  - `assets/audio/README.md` - Audio asset documentation
  - `assets/audio/sfx/` - SFX directory (user adds MP3s)
  - `assets/audio/music/` - Music directory (user adds loops)

- **Modified Files**:

  - `includes/class-nm-video-studio.php` - Added script registrations, TTS config, audio paths
  - `assets/js/nm-video-studio.js` - Module initialization, state properties

- **New WordPress Options**:
  - `nm_video_studio_tts_provider` - TTS provider selection (webspeech, edge, google)
  - `nm_google_cloud_tts_key` - Google Cloud TTS API key (optional)

### Notes

- Audio files not bundled with plugin - see `assets/audio/README.md` for free sources
- Google Cloud TTS requires API key setup in GCP Console (4M chars/month free tier)
- Edge TTS uses browser's native speech synthesis with Azure voices when available

---

## [7.4.0] - 2025-12-01

### Added

- **Video Studio Module**: Complete YouTube Shorts/TikTok video creation system for MCQs
  - **Admin Interface**: New "🎥 Video Studio" submenu under MCQ Generator menu
  - **Data Integration**: Load questions from Topics or Mock Exams (50 questions max)
  - **Canvas-Based Rendering**: 1080x1920 portrait video generation with real-time preview
  - **AI Quiz Generation**: Server-side Gemini AI integration for quiz creation from topics
  - **Text-to-Speech**: OpenAI TTS API integration + browser Web Speech API fallback
  - **Video Backgrounds**: Upload custom video backgrounds with parallax effects
  - **Split Screen Mode**: Bottom 30% overlay for viral retention (e.g., gameplay footage)
  - **Batch Generation**: Process questions in chunks of 5 with progress tracking
  - **MP4 Export**: Native MP4 support in Chrome/Edge, FFmpeg WebM→MP4 conversion fallback
  - **Rank System CTA**: Engagement-optimized call-to-action (25-30% comment boost)
  - **Customizable Branding**: Brand name, logo, hook text, CTA text, website URL
  - **Template System**: Pre-built templates (Tech, Sports, Trivia, Education)
  - **Audio Features**: Background music upload, SFX (tick, correct, wrong sounds)
  - **SEO Tools**: AI-powered title/description/hashtag generation
  - **Import/Export**: JSON format for quiz data portability
  - **Thumbnail Capture**: Screenshot functionality for video thumbnails

### Technical Details

- **New Files Created**:

  - `includes/class-nm-video-studio.php` (429 lines) - Main WordPress integration class
  - `assets/js/nm-video-studio.js` (1,383 lines) - Canvas rendering and FFmpeg logic
  - `assets/css/nm-video-studio.css` (141 lines) - Admin UI styling
  - `assets/js/ffmpeg/` - Local FFmpeg.js library (v0.12.7) with WASM support

- **AJAX Endpoints** (all secured with nonce + capability checks):

  - `nm_get_studio_data` - Fetch topics/exams and questions
  - `nm_generate_ai_quiz` - Server-side AI quiz generation via Gemini API
  - `nm_generate_tts` - Server-side text-to-speech via OpenAI API

- **Security Enhancements**:

  - API keys retrieved server-side only (no client exposure)
  - Uses existing `nm_gemini_api_key` and `nm_openai_api_key` settings
  - All AJAX handlers verify `manage_options` capability
  - Input sanitization with `sanitize_text_field()`
  - Nonce verification on all requests

- **Performance Optimizations**:

  - Cached gradients for reduced canvas redraw overhead
  - Local FFmpeg assets (no CDN dependency)
  - Conditional asset loading (only on Video Studio page)
  - MediaRecorder native MP4 support (Chrome 104+, Edge 104+)
  - Ultrafast FFmpeg preset for quick conversions

- **Integration Points**:
  - Main plugin file: Lines 116-120 (conditional loading)
  - Admin menu: Priority 20 under `nm_mcq_generator` parent
  - Settings: Reuses existing API key options
  - Post types: Queries `mcq` post type with topic/exam taxonomies

### Changed

- **Plugin Version**: Updated to 7.4.0 across all constants
- **Main Plugin File** (`wp-news-mcq-generator.php`):
  - Added Video Studio class loading with `file_exists()` check
  - Integrated `NM_Video_Studio::init()` into plugin bootstrap

### Notes

- Backups created: `backups/class-nm-video-studio.php.backup-*`, `backups/nm-video-studio.js.backup-*`
- Browser compatibility: Chrome/Edge (full support), Firefox (WebM fallback), Safari (limited)
- FFmpeg conversion timeout: 30 seconds per batch (configurable)
- Requires PHP 7.4+, WordPress 6.0+ (same as existing plugin requirements)

---

    - First visit: Shows after 5-second delay
    - After dismissal: Shows again after 3 visits
    - Same-day dismissal blocker (won't show again today if dismissed)

## [27.1] - 2025-11-25

### Changed

- **Code Quality Improvements**: Systematic audit recommendations implemented
  - Created centralized `META_KEYS.md` documentation registry (80+ meta keys documented)
  - Standardized logging in `class-nm-cron-manager.php` to use `NM_Generation_Logger::nm_log_activity()` (28 instances)
  - Improved logging consistency for better debugging and centralized log control

### Documentation

- Added comprehensive metakey reference documentation:
  - WordPress Options (50+ settings across all modules)
  - Post Meta (15+ MCQ custom fields including E-A-T, scheduler, social)
  - Taxonomy Meta (topic/exam social images)
  - User Meta (gamification, authentication, notifications)
  - Transients (8 cache keys with TTL specifications)
  - Database Tables (3 tables with complete schema documentation)
- Each meta key includes: type, default value, description, and version added
- Deprecated keys documented with migration path

### Technical Changes

- Modified `includes/class-nm-cron-manager.php`:
  - Replaced all direct `error_log()` calls with `NM_Generation_Logger::nm_log_activity()`
  - Supports severity levels: 'info', 'success', 'error', 'warning'
  - Backwards compatible with class_exists() checks
  - Maintains emoji-free log messages for clean log parsing

### Notes

- Backups created: `backups/minor_improvements_v7.3.15/includes/`
- Lint errors for WordPress functions are false positives (IDE missing WordPress stubs)
- Severity mapping: success→'created', error→'error', warning→'skipped', info→'info'

---

## [27] - 2025-11-22

### Added

- **Server-Side MCQ Content Validator**: Enforces character limits before database save
  - **Validation Rules**:
    - Question text: Maximum 160 characters
    - Option text: Maximum 60 characters per option (A, B, C, D)
    - Required fields check (question, options, answer)
    - Options structure validation (must contain A, B, C, D keys)
    - Answer validation (must be valid key A-D)
  - **Rejection Strategy**: Over-length MCQs are rejected completely with detailed error logging
  - **Integration Point**: `NM_Post_Type_Manager::save_mcq_post_unified()` - validates ALL MCQs regardless of source
  - **Sources Protected**: News generation, topic generation, feed imports, current affairs
  - **Logging**: Error logs include violation details, character counts, and question preview
  - **Optional Logger**: Integrates with `NM_Generation_Logger` when available
  - **Warnings**: MCQs approaching limits (140+ chars question, 50+ chars options) get warnings but still save
- **Prompt Updates for Conciseness**: Enhanced AI prompts in all generation methods
  - Added explicit character limits to `generate_mcq_from_text()`
  - Added explicit character limits to `generate_mcq_from_topic()`
  - Added explicit character limits to `generate_mcq_with_categorization()`
  - Instructions include bad/good examples for AI guidance
  - Changed conciseness from suggestion to **CRITICAL requirement**

### Technical Changes

- Modified `includes/class-nm-validator.php`:
  - Added `validate_mcq_content()` method (110 lines)
  - Uses `mb_strlen()` for UTF-8 character counting
  - Returns structured result: `['valid' => bool, 'errors' => array, 'warnings' => array]`
- Modified `includes/class-nm-post-type-manager.php`:
  - Integrated validator into `save_mcq_post_unified()` before `wp_insert_post()`
  - Added comprehensive error logging with question preview
  - Added optional `NM_Generation_Logger` integration
  - Graceful fallback if `NM_Validator` class not available
- Modified `includes/class-nm-api-client.php`:
  - Updated all three generation prompts with conciseness rules
  - Applied PSR-2 coding standards (opening braces on new lines)

### Architectural Benefits

- **Single Chokepoint Validation**: All MCQs validated at one location regardless of source
- **Defense in Depth**: Prompt instructions + server-side enforcement
- **Protects Against AI Failures**: Guardrail for when LLM ignores character limits
- **Zero Breaking Changes**: Backward compatible, existing MCQs unaffected
- **Performance**: Negligible overhead (~0.001s string validation)
- **Professional Pattern**: Industry-standard validator pattern used by production exam platforms

### Notes

- Backups created: `class-nm-validator.php.bak`, `class-nm-post-type-manager.php.bak`
- Validation failures visible in WordPress debug.log with `[NM MCQ Validator]` prefix
- Implementation plan saved to artifacts
- Lint errors for WordPress functions are false positives (IDE missing WordPress stubs)

---

    - Visit counter tracked via localStorage

- **Install Prompt Features**:
  - Captures `beforeinstallprompt` event (Chrome/Edge)
  - "Install Now" button triggers native install dialog
  - "Maybe Later" button with smart retry logic
  - Close button (×) with dismissal tracking
  - Animated slide-up entrance
  - App icon (📱) with benefit-focused copy
  - 4 key benefits highlighted:
    - ✓ 20-60 new MCQs daily
    - ✓ Offline practice mode
    - ✓ Real-time notifications
    - ✓ Lightning-fast loading
- **Mobile-First Design**:
  - Full-width on mobile (<768px)
  - Bottom sheet style with rounded top corners
  - Touch-friendly buttons (48px height)
  - iOS safe area insets for notch devices
  - Landscape mode optimization (<500px height)
  - Desktop: 480px max-width, bottom-right positioning
- **iOS Support**:
  - Auto-detects iOS devices
  - Shows custom install instructions
  - Step-by-step guide with Share button icon
  - Separate iOS-specific banner design
  - Same timing logic as other platforms
- **Engagement Tracking** (localStorage):
  - Visit count tracking
  - Dismissal count and dates
  - "Never ask again" option (optional)
  - Install status detection
  - First visit timestamp
- **Analytics Events**:
  - `pwa_prompt_shown` - Banner displayed
  - `pwa_install_clicked` - User clicked Install
  - `pwa_install_success` - User accepted install
  - `pwa_install_declined` - User declined install
  - `pwa_dismissed_later` - User clicked Later
  - `pwa_dismissed_close` - User clicked ×
  - `pwa_ios_prompt_shown` - iOS banner shown
  - Google Analytics integration ready (gtag events)

### Changed

- **PWA Support Class** (`class-nm-pwa-support.php`):
  - Enhanced `enqueue_pwa_scripts()` to include CSS/JS for install prompt
  - Added configuration via `wp_localize_script`:
    - `appName`: Site name from WordPress
    - `delaySeconds`: 5 (configurable)
    - `requiredVisits`: 3 (configurable)
    - `benefits`: Array of app benefits

### Technical Details

- **LocalStorage Schema**: `nm_pwa_prompt` with visit/dismissal tracking
- **Browser Support**: Chrome, Edge (full), Safari iOS (manual instructions), Firefox (limited)
- **Animations**: CSS cubic-bezier slide-up, fade-in icon
- **Accessibility**: Focus styles, high contrast mode, reduced motion support
- **Performance**: Lightweight (~250 lines JS, ~400 lines CSS), no external dependencies
- **Responsive**: 4 breakpoints (320px, 480px, 768px, desktop)
- **Conversion Expected**: ~7-10% install rate (2-5% first visit, 10-15% after 3 visits)
- **Backup Created**: `backup_v734_pwa_prompt/`

### User Experience Flow

```
First Visit:
  Page loads → Wait 5s → Check installable → Show banner

User Dismisses:
  Click "Later" → Hide banner → Track dismissal → Reset counter

Next 3 Visits:
  Visit 1 → Counter: 1 → No banner
  Visit 2 → Counter: 2 → No banner
  Visit 3 → Counter: 3 → Show banner → Reset counter

User Installs:
  Click "Install Now" → Native prompt → User accepts → App installs → Never show again
```

### Files Created

- `assets/js/pwa-install-prompt.js` - Smart timing logic, event handling, localStorage tracking
- `assets/css/pwa-install-prompt.css` - Bottom sheet design, animations, responsive styles

### Mobile Optimization

- Touch targets: 48px minimum
- Safe area insets: iOS notch support
- Bottom sheet: Natural thumb reach on phones
- Landscape mode: Scrollable with max-height
- High contrast: Black background with white border

---

- **Performance Optimization**: Reduced JavaScript file size and improved load times

---

## [7.3.11] - 2025-11-22

### Fixed

- **Duplicate Scanner UI State Management**: Comprehensive fix for UI state issues
  - **Added Missing Stop Button**: Now appears during scans, properly hidden when not scanning
  - **Fixed "Scanning..." Text**: Changed from static to dynamic, updates to show scan progress/completion
  - **Fixed Results Display**: Results container now properly shows/hides based on scan status
  - **Fixed Progress Bar State**: Properly resets between scans, shows accurate percentages
  - **Better State Reset**: Complete UI reset when starting new scan or after errors
- **Incremental Scan Progress Bar**: Fixed stuck progress bar in "Scan from last scan" mode
  - Root cause: Was incorrectly checking `$_POST['cursor'] > 0` which failed on first batch
  - Total count now properly calculated for incremental scans from the start
  - Progress calculation now accurate (was stuck at ~20%)
  - Scans now complete to 100% successfully
- **UI Flow Improvements**:
  - Scan button changes to "Scan Again" after completion
  - Status text shows: "Ready to scan..." → "Scanning..." → "Scan complete!"
  - Color-coded status (blue during scan, green on completion)
  - Better visual feedback throughout scan lifecycle

### Technical Changes

- Modified `class-nm-ajax-admin.php`: Fixed condition in `ajax_scan_batch_handler()` line 712
  - Changed from `if ($mode === 'since_last' && isset($_POST['cursor']) && $_POST['cursor'] > 0)`
  - To: `if ($mode === 'since_last')`
  - Added v7.3.11 documentation comment explaining the fix
- Modified `class-nm-duplicate-tool.php`: Enhanced UI state management
  - Added stop button HTML (line 106)
  - Made scanning status dynamic with ID `nm-scanning-status` (line 109)
  - Added `scanningStatus` variable to jQuery (line 204)
  - Improved `startBtn` click handler with comprehensive UI reset (line 237-248)
  - Enhanced `finishScan()` with proper status updates and results display (line 318-354)
  - Improved `resetUI()` function with complete state reset (line 356-363)

### Notes

- All changes backed up to `backups/class-nm-duplicate-tool.php.bak-TIMESTAMP`
- All changes backed up to `backups/class-nm-ajax-admin.php.bak-TIMESTAMP`
- Implementation plan saved to `Implementation Plans/duplicate-scanner-fix-TIMESTAMP.md`
- Lint errors are false positives (Intelephense doesn't recognize WordPress core functions)
- Professional industry-standard solution following WordPress coding standards

---

## [7.3.10] - 2025-11-22

### Fixed

- **Quiz Modal Close Button Overlap**: Repositioned close button to prevent overlap with question number
  - Moved button to top: 10px, right: 15px (from top: 15px, right: 20px)
  - Increased header right padding to 65px for button clearance
  - Improved visual hierarchy and usability
- **Social Share Buttons Dark Mode**: Fixed text readability in dark mode
  - Added explicit dark mode CSS with high specificity
  - All 4 buttons (Facebook, Twitter, WhatsApp, LinkedIn) now have white text (#ffffff !important)
  - Brand colors maintained on dark backgrounds
- **Homepage E-A-T Display**: Enhanced to match topic page elegance
  - Changed from inline text to structured box with icons
  - Added light background (#f8f9fa) with purple accent border
  - Better visual separation from question text (25px margin)
  - Difficulty displayed as colored badges
  - Full dark mode support
- **MCQ Sync Errors**: Fixed "Synced: 0, Errors: 100" batch processing issue
  - `sync_mcq_data()` now returns boolean for proper error tracking
  - Function was returning void, causing all syncs to count as errors
  - Batch processing now works correctly
- **Duplicate Scan Incremental Mode**: Fixed progress bar stuck at 20%
  - Total count now calculated based on scan mode (full vs. incremental)
  - Incremental mode now counts only new MCQs after last scan cursor
  - Progress calculation now accurate for both scan modes
  - Scan completes to 100% successfully
- **PWA Install Prompt**: Fixed prompt not appearing on mobile
  - Removed homepage-only restriction (`!is_front_page()`)
  - PWA prompt now shows on all pages, not just homepage
  - Increases installation opportunities across the site

### Technical Changes

- Modified `class-nm-database-optimizer.php`: Added return boolean to `sync_mcq_data()`
- Modified `class-nm-ajax-admin.php`: Dynamic total calculation for scan modes
- Modified `class-nm-pwa-support.php`: Removed page restriction for PWA prompt

### Notes

- All 6 production issues resolved
- All modified files backed up to `backups/backup_v7.3.10/`
- PHP lint errors are false positives (WordPress functions not recognized by IDE)

---

## [7.3.9] - 2025-11-22

### Fixed

- **Quiz Modal UX Issues**: Improved modal viewport sizing and close button positioning
  - Increased modal height to 85vh (from 80vh) for better content visibility
  - Increased modal width to 700px (from 600px) for better readability
  - Redesigned close button: Circular design (40px), repositioned to top-right corner
  - Added hover animation (red background) and shadow for better visual prominence
- **E-A-T Author Display**: Fixed author attribution showing correctly
  - Changed fallback logic to show "By TheQuizWire" instead of just "AUTHOR" label
  - Updated label from "Author" to "By" for better readability
- **Homepage E-A-T Spacing**: Improved visual distinction and spacing
  - Increased bottom margin from 15px to 20px for better separation from question text
  - Added light background (#f8f9fa) with left accent border (3px purple)
  - Added padding (10px 12px) for better visual containment
  - Dark mode: Custom dark background (#1a1a1a) with maintained accent border
- **Dark Mode Readability**: Fixed contrast issues across multiple components
  - **Exam Tags**: Added dark mode styles (light green #a5d6a7 on dark background)
  - **Mock Exam**: Fixed answer text color (#e5e7eb), button hover states (white text), review text
  - **Mock Exam Buttons**: Secondary and flag buttons now show white text on hover (was unreadable)
  - **Option Labels**: Improved contrast with proper background colors (#374151)
  - **Review Answers**: Fixed answer text and explanation readability
  - **Progress Labels**: Muted gray (#9ca3af) for better hierarchy

### Notes

- Social share buttons already had proper dark mode (no changes needed)
- Mobile menu already had proper dark mode (no changes needed)
- All changes backed up to `backups/backup_v7.3.9/`

---

## [7.3.8] - 2025-11-22

### Added

- **E-A-T Backfill Admin Tool**: New admin interface for setting default E-A-T data
  - Added to MCQ → Tools menu with professional UI card
  - AJAX-powered backfill function with batch processing
  - Sets default values: Author (TheQuizWire), Fact Checked (Yes), Difficulty (Medium)
  - Shows statistics: Total processed, Updated, Already with data
  - Confirmation dialog before execution
  - 2-minute timeout for large databases
- **Mock Exam Shortcode**: Full-featured mock examination system
  - **Shortcode**: `[nm_mock_exam]` with customizable attributes
  - **Attributes**: topic, questions, time_limit, difficulty, passing_score, title
  - **Database**: Auto-creates `wp_nm_exam_results` table for logged-in users
  - **Timer**: Strict countdown with auto-submit on timeout
  - **Features**: Question navigation, answer flagging, review mode, results analysis
  - **Design**: Professional gradient UI, mobile-first responsive, dark mode support
  - **Analytics**: Stores exam data, scores, time taken, and detailed answers
  - **Guest Support**: Shows results without saving (prompts login for persistence)
- **Mock Exam UI Components**:
  - Start screen with exam info and instructions
  - Question screen with timer and progress tracking
  - Navigation controls (Previous, Flag, Next, Submit)
  - Results screen with circular score meter
  - Question-by-question review with explanations
  - Retry and share functionality
  - Responsive design (320px to desktop)

### Fixed

- **Quiz Modal Mobile Scrolling**: Enhanced mobile scrolling experience
  - Body scroll lock when quiz modal is open (prevents background scrolling)
  - Added `nm-modal-open` class to body element
  - Modal content scrolls independently with touch scrolling support
  - iOS-optimized with `-webkit-overflow-scrolling: touch`
  - Responsive adjustments for 768px and 575px breakpoints
  - Reduced padding on mobile for better content visibility

### Technical

- Created new file: `includes/class-nm-mock-exam.php` (410 lines)
- Created new file: `assets/css/mock-exam.css` (520 lines)
- Created new file: `assets/js/mock-exam.js` (410 lines)
- Modified: `includes/class-nm-admin-menu.php` (+82 lines)
- Modified: `assets/css/quiz-frontend.css` (+45 lines)
- Modified: `assets/js/quiz-frontend.js` (+8 lines)
- Registered Mock Exam class in main plugin file
- All files backed up to `backups/backup_v7.3.8/`

---

## [7.3.7] - 2025-11-21

### Added

- **E-A-T Implementation**: Site-wide Expertise, Authoritativeness, Trustworthiness metadata
  - Author attribution (default: TheQuizWire)
  - Fact-checked status with visual badge
  - Difficulty levels (easy, medium, hard) with color coding
  - Published/Last Updated dates
  - Displayed on single MCQ pages, topic archives, and homepage

### Fixed

- Dark mode support for E-A-T components
- Responsive design for E-A-T boxes

---

## [7.3.4] - 2025-11-21

### Fixed

- **Notification System - Critical Fixes**: Fixed notifications not working due to missing database table and JavaScript file
  - **Database Table**: Added `NM_Notifications::create_tables()` to activation hook - creates `wp_nm_notifications` table
  - **Missing Files**: Created `assets/js/notifications.js` (auto-refresh, AJAX, interactions)
  - **Missing Styles**: Created `assets/css/notifications.css` (mobile-first, dark mode, responsive)
  - **Frontend UI**: Bell icon system implemented (badge count, dropdown list, mark as read/delete)

### Added

- **Daily Digest System**: Non-intrusive daily summary at 8 AM for active users
  - WP-Cron scheduled task `nm_send_daily_digest`
  - Batches 20-60 daily MCQs into single notification (no spam)
  - Only sent to users logged in within last 30 days
  - User can disable via preferences (`nm_enable_daily_digest` meta)
  - Counts published MCQs from last 24 hours
  - Error logging for debugging
- **Notification Frontend**:
  - Bell icon with animated badge (shows unread count, 99+ limit)
  - Dropdown notification list (90vw on mobile, 400px max on desktop)
  - Auto-refresh every 30 seconds (configurable)
  - Mark as read on click
  - Delete individual notifications
  - Mark all as read button
  - Toast popup system for real-time notifications
  - Empty state messaging
  - Time-ago formatting (Just now, 5 minutes ago, etc.)
- **Mobile-First Design**:
  - Touch-friendly tap targets (44px+ minimum)
  - Bottom sheet dropdown on phones (< 480px)
  - Top-aligned toasts on mobile (thumb-friendly)
  - Smooth iOS scrolling (`-webkit-overflow-scrolling`)
  - Responsive breakpoints: 768px (tablet), 480px (mobile), 320px (small)
  - Always-visible delete buttons on mobile

-**Dark Mode Support**:

- Full dark mode styling for all notification components
- CSS variable integration with existing dark mode system
- Consistent theming across light/dark modes

- **Notification Types**:
  - Daily Digest (📰): Batch summary of new MCQs
  - Achievements (🏆): Gamification unlocks
  - Points (🎯): Points earned
  - Level Up (⭐): New levels reached
  - Streaks (🔥): Daily streak milestones
  - Leaderboard (📊): Rank changes
  - New Content (📚): Batch MCQ uploads

### Changed

- **Activation Hook** (`wp-news-mcq-generator.php`):
  - Added `NM_Notifications::create_tables()` call
  - Scheduled daily digest cron (`strtotime('tomorrow 8:00 AM')`)
  - Added error logging for activation steps
- **Deactivation Hook** (`wp-news-mcq-generator.php`):
  - Clear daily digest schedule via `wp_clear_scheduled_hook('nm_send_daily_digest')`
- **Notifications Class** (`class-nm-notifications.php`):
  - Added `send_daily_digest()` static method
  - Added daily digest cron hook registration
  - Added CSS enqueue for `notifications.css`
  - Updated JavaScript enqueue with proper dependencies

### Technical Details

- **Database Table**: `wp_nm_notifications` with indexes on user_id, is_read, created_at
- **Cron Schedule**: Daily at 8 AM server time
- **AJAX Endpoints**: Uses existing `nm_auth_nonce` for security
- **Auto-cleanup**: Removes read notifications >30 days, all >90 days
- **Performance**: Targets only active users (last 30 days login)
- **Scalability**: Batch processing, indexed queries, configurable intervals
- **Accessibility**: Focus styles, reduced motion support, keyboard navigation
- **Dependencies**: jQuery (existing), WordPress AJAX API
- **Backup Created**: `backup_v733_notification_system/`

### User Experience

- Non-intrusive daily summary (no per-MCQ spam)
- Real-time update badge with pulse animation
- Smooth dropdown animations
- Mobile-optimized for thumb reach
- Persistent notifications across sessions
- Control via user preferences

---

## [7.3.3] - 2025-11-21

### Fixed

- **Quiz Modal Viewport Fix**: Complete professional solution using flexbox sticky header/footer pattern
  - **Problem**: Modal exceeded viewport height on laptop and mobile, timer and Next button were cut off
  - **Solution**: Restructured modal with three distinct sections:
    - Sticky header (timer + progress) - always visible at top
    - Scrollable body (question + options) - scrolls independently
    - Sticky footer (Next button) - always visible at bottom
  - Modal constrained to 90vh max-height to never exceed screen
  - Timer moved inside header (removed absolute positioning)
  - Added manual "Next Question →" button for better user control
  - Touch-friendly sizing on mobile (44px tap targets, 48px buttons)
  - Smooth iOS touch scrolling with `-webkit-overflow-scrolling`
  - Dark mode support for all new sections
- **Quiz Timer Extended**: Increased from 10 seconds to 20 seconds for comfortable reading time on longer questions (aligns with educational quiz standards)

### Changed

- **CSS Architecture** (`assets/css/quiz-frontend.css`):

  - Converted `#nm-quiz-modal-content` to flexbox container
  - Added `.nm-quiz-header` class for sticky header section
  - Added `.nm-quiz-body` class for scrollable content area
  - Added `.nm-quiz-footer` class for sticky footer section
  - Added `.nm-quiz-next-btn` class for navigation button
  - Updated responsive breakpoints for new structure (768px, 480px)
  - Enhanced dark mode styles for new sections

- **JavaScript Functionality** (`assets/js/quiz-frontend.js`):
  - Restructured `displayQuestion()` with new wrapper divs
  - Updated `handleAnswerSelection()` to enable Next button
  - Added manual Next button click handler
  - Auto-advance timer still works (2 seconds) OR manual click
  - Better quiz flow control for users

### Technical Details

- Industry-standard flexbox sticky header/footer pattern
- Scalable solution works for any content length
- Backwards compatible with existing quiz functionality
- Performance: CSS-only sticky positioning (no JavaScript calculations)
- Accessibility: Keyboard navigation, screen reader friendly
- Mobile-first with progressive enhancement
- Created backup in `backup_v732_modal_fix/` folder

---

## [7.3.2] - 2025-11-21

### Fixed

- **Critical AJAX Security Fix**: Fixed nonce mismatch causing 403 Forbidden errors on all embedding admin features
  - Changed JavaScript nonce from `nm_admin_nonce` to `nm_ajax_dashboard` to match server-side AJAX handler expectations
  - Restored functionality for:
    - Backfill process (was failing to start/progress)
    - Stats card refresh (was showing 403 errors)
    - Orphaned embeddings cleanup (was showing "Server Error")
    - Post meta migration (was blocked by 403)
  - Modified: `includes/class-nm-embedding-database.php` line 425
  - All AJAX requests now return 200 OK instead of 403 Forbidden

### Technical Details

- Single-line critical fix resolving security validation mismatch
- No changes to AJAX handlers, only corrected client-side nonce generation
- All previous embedding admin features now fully functional

---

## [7.3.1] - 2025-11-21

### Fixed

- **Email Subscription Text Accuracy**: Changed subscription form default text from "Weekly MCQs" to "Daily MCQs" to accurately reflect the actual email delivery schedule (emails are sent daily via cron)

  - Modified: `includes/class-nm-shortcode-manager.php` line 143
  - Verified cronschedule in `includes/class-nm-cron-manager.php` line 179

- **Quiz Modal Responsiveness**: Added comprehensive mobile support for quiz popup to prevent text overflow on smaller screens
  - Implemented fluid typography using CSS `clamp()` for auto-scaling text sizes
  - Added word-wrapping and overflow handling for long question text
  - Added responsive breakpoints for tablets (768px) and mobile phones (480px)
  - Implemented vertical scrolling for overflow content
  - Added flexible button layout that stacks on mobile devices
  - Modified: `assets/css/quiz-frontend.css`

### Technical Details

- Used modern CSS best practices (`clamp()`, `overflow-wrap`, responsive breakpoints)
- All changes are backward compatible with existing functionality
- No JavaScript changes required
- Created `backup_v28` folder containing original files before applying fixes

---

## [7.3.0] - 2025-11-21

### Added

- **Blueprint vs Actual Analytics:** New dashboard card comparing configured difficulty targets (CSS, PMS, NTS) against actual AI generation performance over the last 30 days.
- **Enhanced System Health:** Added "Current Affairs Queue" monitoring (Queue Size, Worker Last Run) to the System Health card for better observability.

### Changed

- **Plugin Version:** Updated to 7.3.0.

## [7.2.0] - 2025-11-21

### Fixed

- **Email Digest:**
  - Changed frequency text from "Weekly" to "Daily" to match the actual schedule.
  - Fixed the "Browse All Questions" link to point to the correct archive URL (`/mcq/` instead of `/mcqs/`).
  - Implemented functional Unsubscribe logic. Clicking "Unsubscribe" now properly updates the user status and shows a confirmation page.
- **Archive Page:**
  - Fixed pagination output to use a clean, styled list instead of raw text.
  - Added CSS for pagination to match the modern UI (flexbox, rounded corners, hover states).
- **Single MCQ:**
  - Updated Difficulty label to display "Difficulty - [Level]" for better clarity.

### Added

- **Backup:** Created a `backup_v27` folder containing original files before applying fixes.

## [7.1.0] - 2025-11-21

### Added

- **Social Sharing:**
  - Enhanced WhatsApp sharing message with "Daily Quiz Challenge" header, full question text, options, and call-to-action.
  - Improved Twitter/X sharing message with hashtags and clear CTA.
  - Professionalized LinkedIn sharing summary.

### Changed

- **SEO:**
  - Analyzed Schema markup strategy for Google's 2026 deprecation of "Practice Problem" rich results.
  - Recommended retaining `Quiz` schema and adding `FAQPage` schema.

## [7.0.0] - 2025-11-20

### Added

- **Core:** Initial analysis of plugin structure, AI generation service, and frontend templates.
- **Features:** Exam Blueprints for context-aware question generation.
