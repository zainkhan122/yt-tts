<?php

namespace SEO_Article_Generator;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Ajax Router
 * 
 * Handles registration of AJAX actions and delegates to the main Plugin instance.
 * @since 2.13.5
 */
class Ajax_Router
{
    /** 
     * @var Plugin
     */
    private $plugin;

    public function __construct(Plugin $plugin)
    {
        $this->plugin = $plugin;
        $this->register_hooks();
    }

    private function register_hooks()
    {
        // Generation handlers
        add_action('wp_ajax_seo_gen_submit', array($this->plugin, 'ajax_submit_generation'));
        add_action('wp_ajax_seo_gen_status', array($this->plugin, 'ajax_check_status'));
        add_action('wp_ajax_seo_gen_preview', array($this->plugin, 'ajax_get_preview'));
        add_action('wp_ajax_seo_gen_publish', array($this->plugin, 'ajax_publish_article'));
        add_action('wp_ajax_seo_gen_sync_meta', array($this->plugin, 'ajax_sync_meta'));

        // Post search
        add_action('wp_ajax_seo_gen_search_posts', array($this->plugin, 'ajax_search_posts'));

        // Ratings
        add_action('wp_ajax_seo_gen_submit_rating', array($this->plugin, 'ajax_submit_rating'));
        add_action('wp_ajax_nopriv_seo_gen_submit_rating', array($this->plugin, 'ajax_submit_rating'));

        // Sitemap
        add_action('wp_ajax_seo_gen_upload_sitemap', array($this->plugin, 'ajax_upload_sitemap'));
        add_action('wp_ajax_seo_gen_refresh_sitemap', array($this->plugin, 'ajax_refresh_sitemap'));

        // @MODIFIED 2026-03-04: Log deletion handler
        add_action('wp_ajax_seo_gen_delete_log', array($this->plugin, 'ajax_delete_log'));

	// @MODIFIED 2026-03-06: Bulk Log Deletion (v2.26.0)
	add_action('wp_ajax_seo_gen_delete_all_logs', array($this->plugin, 'ajax_delete_all_logs'));

	// @MODIFIED 2026-04-24: Debug log viewer AJAX handlers
	add_action('wp_ajax_seo_gen_load_debug_log', array($this->plugin, 'ajax_load_debug_log'));
	add_action('wp_ajax_seo_gen_save_debug_log_path', array($this->plugin, 'ajax_save_debug_log_path'));
	add_action('wp_ajax_seo_gen_download_debug_log', array($this->plugin, 'ajax_download_debug_log'));

        // Settings
        add_action('wp_ajax_seo_gen_test_api', array($this->plugin, 'ajax_test_api'));
        add_action('wp_ajax_seo_gen_testapi', array($this->plugin, 'ajax_test_api')); // legacy alias

        // Custom provider test
        add_action('wp_ajax_seo_gen_test_custom_provider', array($this->plugin, 'ajax_test_custom_provider'));

        // @MODIFIED 2026-07-12 - OpenRouter free model auto-sync (manual trigger)
        add_action('wp_ajax_seo_gen_sync_openrouter_models', array($this->plugin, 'ajax_sync_openrouter_models'));

        // OpenCode Zen free model auto-sync (manual trigger) — sibling of OpenRouter sync
        add_action('wp_ajax_seo_gen_sync_zen_models', array($this->plugin, 'ajax_sync_zen_models'));

        // @MODIFIED 2026-01-06 v2.16.0: Smoke test AJAX handler
        add_action('wp_ajax_seo_gen_run_smoke_test', array($this->plugin, 'ajax_run_smoke_test'));
        add_action('wp_ajax_seo_gen_runsmoketest', array($this->plugin, 'ajax_run_smoke_test')); // legacy alias

        // Dashboard Integration
        add_action('wp_ajax_seo_gen_generate_dashboard_key', array($this->plugin, 'ajax_generate_dashboard_key'));

        // Download tracking (Public)
        add_action('wp_ajax_seo_gen_track_download', array($this->plugin, 'ajax_track_download'));
        add_action('wp_ajax_nopriv_seo_gen_track_download', array($this->plugin, 'ajax_track_download'));

        // RankMath Migration
        add_action('wp_ajax_seo_gen_detect_rankmath_template', array($this->plugin, 'ajax_detect_rankmath_template'));
        add_action('wp_ajax_seo_gen_start_migration', array($this->plugin, 'ajax_start_migration'));
        add_action('wp_ajax_seo_gen_process_migration_batch', array($this->plugin, 'ajax_process_migration_batch'));

        // Canonical Slug Migration (Issue 6: Evergreen Clean URLs)
        add_action('wp_ajax_seo_gen_slug_dry_run', array($this->plugin, 'ajax_slug_dry_run'));
        add_action('wp_ajax_seo_gen_slug_migrate', array($this->plugin, 'ajax_slug_migrate'));
        add_action('wp_ajax_seo_gen_slug_rollback', array($this->plugin, 'ajax_slug_rollback'));
        add_action('wp_ajax_seo_gen_slug_state', array($this->plugin, 'ajax_slug_state'));
        add_action('wp_ajax_seo_gen_slug_clear_redirections', array($this->plugin, 'ajax_slug_clear_redirections'));

        // Internal Links Update
        add_action('wp_ajax_seo_gen_update_links', array($this->plugin, 'ajax_update_internal_links'));
        add_action('wp_ajax_seo_gen_rollback_links', array($this->plugin, 'ajax_rollback_internal_links'));
        add_action('wp_ajax_seo_gen_link_state', array($this->plugin, 'ajax_link_update_state'));

        // Legacy Aliases for Smoke Test
        add_action('wp_ajax_seogen_detect_rankmath_template', array($this->plugin, 'ajax_detect_rankmath_template'));
        add_action('wp_ajax_seogen_start_migration', array($this->plugin, 'ajax_start_migration'));
        add_action('wp_ajax_seogen_process_migration_batch', array($this->plugin, 'ajax_process_migration_batch'));
    }
}
