<?php

/**
 * Admin Menu
 *
 * @package SEO_Article_Generator
 */

namespace SEO_Article_Generator\Admin;

use SEO_Article_Generator\Logger;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Admin menu and page registration
 */
class Admin_Menu
{
    /**
     * Logger instance
     *
     * @var Logger
     */
    private $logger;

    /**
     * Constructor
     *
     * @param Logger $logger Logger instance
     */
    public function __construct($logger)
    {
        $this->logger = $logger;
    }

    /**
     * Initialize admin menu
     *
     * @return void
     */
    public function init()
    {
        \add_action('admin_menu', array($this, 'register_menu'));
        \add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        \add_action('wp_ajax_seo_gen_buffer_fetch_profiles', array($this, 'ajax_buffer_fetch_profiles'));
    }

    /**
     * Register admin menu pages
     *
     * @return void
     */
    public function register_menu()
    {
        // Main menu
        \add_menu_page(
            \__('SEO Generator', 'seo-article-generator'),
            \__('SEO Generator', 'seo-article-generator'),
            'manage_options',
            'seo-generator',
            array($this, 'render_generator_page'),
            'dashicons-edit-large',
            30
        );

        // Generator page (default)
        \add_submenu_page(
            'seo-generator',
            \__('Generate Article', 'seo-article-generator'),
            \__('Generate Article', 'seo-article-generator'),
            'manage_options',
            'seo-generator',
            array($this, 'render_generator_page')
        );

        // Sitemap manager
        \add_submenu_page(
            'seo-generator',
            \__('Sitemap Manager', 'seo-article-generator'),
            \__('Sitemap Manager', 'seo-article-generator'),
            'manage_options',
            'seo-generator-sitemap',
            array($this, 'render_sitemap_page')
        );

        // Settings page
        \add_submenu_page(
            'seo-generator',
            \__('Settings', 'seo-article-generator'),
            \__('Settings', 'seo-article-generator'),
            'manage_options',
            'seo-generator-settings',
            array($this, 'render_settings_page')
        );

        // Logs page
        \add_submenu_page(
            'seo-generator',
            \__('Logs', 'seo-article-generator'),
            \__('Logs', 'seo-article-generator'),
            'manage_options',
            'seo-generator-logs',
            array($this, 'render_logs_page')
        );
    }

    /**
     * Enqueue admin assets
     *
     * @param string $hook Current admin page hook
     * @return void
     */
public function enqueue_admin_assets($hook)
    {
        if (\strpos($hook, 'seo-generator') === false) {
            return;
        }

        \wp_enqueue_media();
  
         // Enqueue generic styles
         \wp_enqueue_style('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css');
         \wp_enqueue_script('select2', 'https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js', array('jquery'), '4.1.0', true);
  
         // Enqueue plugin assets
         \wp_enqueue_style('seo-gen-admin-style', \SEO_GEN_PLUGIN_URL . 'assets/css/admin.css', array('select2'), \SEO_GEN_VERSION);
         \wp_enqueue_script('seo-gen-admin-script', \SEO_GEN_PLUGIN_URL . 'assets/js/admin-generator.js', array('jquery', 'select2'), \SEO_GEN_VERSION, true);
  
         // If it's a specific sub-page
         if (\strpos($hook, 'seo-generator-settings') !== false) {
             // Enqueue jQuery UI dialog for migration confirm dialogs
             \wp_enqueue_script('jquery-ui-dialog');
             \wp_enqueue_style('wp-jquery-ui-dialog');
         }
  
     if (\strpos($hook, 'seo-generator-logs') !== false) {
         \wp_enqueue_script('seo-gen-logs-script', \SEO_GEN_PLUGIN_URL . 'assets/js/admin-logs.js', array('jquery'), \SEO_GEN_VERSION, true);
         \wp_localize_script('seo-gen-logs-script', 'seoGenData', array(
             'ajax_url' => \admin_url('admin-ajax.php'),
             'nonce' => \wp_create_nonce('seo_gen_nonce'),
         ));
     }
 
     // Localize script
     \wp_localize_script('seo-gen-admin-script', 'seoGenData', array(
         'ajax_url' => \admin_url('admin-ajax.php'),
         'nonce' => \wp_create_nonce('seo_gen_nonce'),
         'debug' => \defined('WP_DEBUG') && \WP_DEBUG,
         'strings' => array(
             'processing' => \__('Processing...', 'seo-article-generator'),
             'validating' => \__('Validating...', 'seo-article-generator'),
             'completed' => \__('Completed!', 'seo-article-generator'),
         )
 ));
 }

/**
     * Render generator page
     *
     * @return void
     */
    public function render_generator_page()
    {
        require_once SEO_GEN_PLUGIN_DIR . 'admin/views/generator-form.php';
    }

    /**
     * Render sitemap page
     *
     * @return void
     */
    public function render_sitemap_page()
    {
        require_once SEO_GEN_PLUGIN_DIR . 'admin/views/sitemap-manager.php';
    }

    /**
     * Render settings page
     *
     * @return void
     */
    public function render_settings_page()
    {
        // Handle log clearing if requested
         if (isset($_POST['seo_gen_clear_logs'])) {
             \check_admin_referer('seo_gen_settings');
             $this->logger->clear_old_logs(0); // 0 days means clear all
             \add_settings_error('seo_gen_settings', 'logs_cleared', \__('All logs have been cleared.', 'seo-article-generator'), 'success');
         }

        // Save settings if submitted
        if (isset($_POST['seo_gen_save_settings'])) {
            \check_admin_referer('seo_gen_settings');
            $this->save_settings();
        }

        require_once SEO_GEN_PLUGIN_DIR . 'admin/views/settings.php';
    }

    /**
     * Render logs page
     *
     * @return void
     */
    public function render_logs_page()
    {
        require_once SEO_GEN_PLUGIN_DIR . 'admin/views/logs.php';
    }

    /**
     * AJAX handler for fetching Buffer profiles
     */
    public function ajax_buffer_fetch_profiles()
    {
        \check_ajax_referer('seo_gen_nonce', '_ajax_nonce');

        if (!\current_user_can('manage_options')) {
            \wp_send_json_error(array('message' => 'Unauthorized'));
        }

        $token = isset($_POST['token']) ? \sanitize_text_field($_POST['token']) : '';
        if (empty($token)) {
            \wp_send_json_error(array('message' => 'No token provided'));
        }

        $url = 'https://api.buffer.com/1/graphql';
        $headers = array(
            'Authorization' => 'Bearer ' . $token,
            'Content-Type'  => 'application/json',
        );

        // 1. Fetch organization
        $org_query = 'query GetOrganizations { account { organizations { id name } } }';
        $org_response = \wp_remote_post($url, array(
            'headers' => $headers,
            'body'    => \wp_json_encode(array('query' => $org_query)),
            'timeout' => 15
        ));

        if (\is_wp_error($org_response)) {
            \wp_send_json_error(array('message' => $org_response->get_error_message()));
        }

        $code = \wp_remote_retrieve_response_code($org_response);
        $org_body = \wp_remote_retrieve_body($org_response);

        if ($code !== 200) {
            $err = \json_decode($org_body, true);
            $msg = isset($err['error']) ? $err['error'] : 'HTTP Error ' . $code;
            if (isset($err['errors'][0]['message'])) {
                $msg = $err['errors'][0]['message'];
            }
            \wp_send_json_error(array('message' => $msg));
        }

        $org_data = \json_decode($org_body, true);
        if (isset($org_data['errors'])) {
            $msg = isset($org_data['errors'][0]['message']) ? $org_data['errors'][0]['message'] : 'GraphQL Error';
            \wp_send_json_error(array('message' => $msg));
        }

        $orgs = isset($org_data['data']['account']['organizations']) ? $org_data['data']['account']['organizations'] : array();
        if (empty($orgs)) {
            \wp_send_json_error(array('message' => 'Could not retrieve organizations. API key exists but has no access to any Buffer organization.'));
        }

        $org_id = $orgs[0]['id'];

        // 2. Fetch channels
        $channels_query = 'query GetChannels { channels(input: { organizationId: "' . \esc_js($org_id) . '" }) { id name service avatar } }';
        $channels_response = \wp_remote_post($url, array(
            'headers' => $headers,
            'body'    => \wp_json_encode(array('query' => $channels_query)),
            'timeout' => 15
        ));

        if (\is_wp_error($channels_response)) {
            \wp_send_json_error(array('message' => $channels_response->get_error_message()));
        }

        $channels_body = \wp_remote_retrieve_body($channels_response);
        $channels_data = \json_decode($channels_body, true);

        if (isset($channels_data['errors'])) {
            $msg = isset($channels_data['errors'][0]['message']) ? $channels_data['errors'][0]['message'] : 'GraphQL Error';
            \wp_send_json_error(array('message' => $msg));
        }

        $channels = isset($channels_data['data']['channels']) ? $channels_data['data']['channels'] : array();

        \wp_send_json_success($channels);
    }

    /**
     * Save settings
     *
     * @return void
     */
	private function save_settings()
	{
		$settings = \SEO_Article_Generator\Option_Registry::settings_form_keys();

		// Preserve legacy keys not yet in registry
		$legacy_keys = array(
			'seo_gen_link_source',
			'seo_gen_db_csv_ratio',
		);
		$settings = array_unique(array_merge($settings, $legacy_keys));

		$checkbox_settings = \SEO_Article_Generator\Option_Registry::boolean_keys();

		// @MODIFIED 2026-04-07 - Prevent silent save failures when a checkbox is added
		// to $checkbox_settings but omitted from $settings.
		$settings = array_values(array_unique(array_merge($settings, $checkbox_settings)));

	// @MODIFIED 2026-03-01 - Textarea fields need sanitize_textarea_field
		$textarea_settings = array(
			\SEO_Article_Generator\Option_Registry::DOWNLOAD_ALLOWLIST,
			\SEO_Article_Generator\Option_Registry::DOWNLOAD_DOMAIN_DENYLIST,
			\SEO_Article_Generator\Option_Registry::CATEGORY_KEYWORD_MAP,
			\SEO_Article_Generator\Option_Registry::TAG_BLOCKLIST,
			\SEO_Article_Generator\Option_Registry::JETPACK_TEMPLATE,
		);

        // Arrays containing textareas
        $textarea_array_settings = array(
            \SEO_Article_Generator\Option_Registry::JETPACK_NETWORK_TEMPLATES,
            \SEO_Article_Generator\Option_Registry::BUFFER_CHANNEL_TEMPLATES,
            \SEO_Article_Generator\Option_Registry::BUFFER_CHANNEL_PINTEREST_TITLES,
        );

        // Associative arrays that must preserve their keys
        $assoc_array_settings = array(
            \SEO_Article_Generator\Option_Registry::JETPACK_NETWORKS,
            \SEO_Article_Generator\Option_Registry::JETPACK_NETWORK_TEMPLATES,
            \SEO_Article_Generator\Option_Registry::BUFFER_CHANNEL_TYPES,
            \SEO_Article_Generator\Option_Registry::BUFFER_CHANNEL_TEMPLATES,
            \SEO_Article_Generator\Option_Registry::BUFFER_CHANNEL_PINTEREST_BOARDS,
            \SEO_Article_Generator\Option_Registry::BUFFER_CHANNEL_PINTEREST_TITLES,
            \SEO_Article_Generator\Option_Registry::BUFFER_CHANNEL_LINK_POSTS,
        );

		// --- Gemini Model Mode/Custom Pre-processing ---
		$defaults = \SEO_Article_Generator\Option_Registry::defaults();
		$posted_gemini_mode = isset($_POST[\SEO_Article_Generator\Option_Registry::GEMINI_MODEL_MODE])
			? \sanitize_text_field(wp_unslash($_POST[\SEO_Article_Generator\Option_Registry::GEMINI_MODEL_MODE]))
			: (string) $defaults[\SEO_Article_Generator\Option_Registry::GEMINI_MODEL_MODE];
		$posted_gemini_custom = isset($_POST[\SEO_Article_Generator\Option_Registry::GEMINI_CUSTOM_MODEL])
			? trim(\sanitize_text_field(wp_unslash($_POST[\SEO_Article_Generator\Option_Registry::GEMINI_CUSTOM_MODEL])))
			: '';
		$verified_gemini_models = \SEO_Article_Generator\AI\AI_Client::get_gemini_models();
		$effective_gemini_model = '';

		// Validate Gemini mode/custom combination
		if ($posted_gemini_mode === 'custom') {
			if ($posted_gemini_custom === '') {
				$existing_custom = (string) \get_option(
					\SEO_Article_Generator\Option_Registry::GEMINI_CUSTOM_MODEL,
					$defaults[\SEO_Article_Generator\Option_Registry::GEMINI_CUSTOM_MODEL]
				);
				if ($existing_custom !== '') {
					$posted_gemini_custom = $existing_custom;
				} else {
					\add_settings_error(
						'seo_gen_settings',
						'seo_gen_gemini_custom_model_empty',
						\__('Gemini Custom model was selected, but no custom model ID was provided. Reverted to the default verified Gemini model.', 'seo-article-generator'),
						'warning'
					);
					$posted_gemini_mode = \SEO_Article_Generator\AI\AI_Client::get_default_model_for_provider('gemini');
				}
			}
			if ($posted_gemini_mode === 'custom') {
				$effective_gemini_model = $posted_gemini_custom;
			}
		} else {
			if (!isset($verified_gemini_models[$posted_gemini_mode])) {
				\add_settings_error(
					'seo_gen_settings',
					'seo_gen_gemini_model_mode_invalid',
					\__('Invalid Gemini model selection was submitted. Reverted to the default verified Gemini model.', 'seo-article-generator'),
					'warning'
				);
				$posted_gemini_mode = \SEO_Article_Generator\AI\AI_Client::get_default_model_for_provider('gemini');
			}
			$effective_gemini_model = $posted_gemini_mode;
		}

		// Force normalized Gemini settings into $_POST before generic save loop
		$_POST[\SEO_Article_Generator\Option_Registry::GEMINI_MODEL_MODE] = $posted_gemini_mode;
		$_POST[\SEO_Article_Generator\Option_Registry::GEMINI_CUSTOM_MODEL] = $posted_gemini_mode === 'custom' ? $posted_gemini_custom : '';
		$_POST[\SEO_Article_Generator\Option_Registry::GEMINI_MODEL] = $effective_gemini_model;
		// --- End Gemini pre-processing ---

		foreach ($settings as $setting) {

            // Checkboxes: must be explicitly set false if unchecked (not present in POST)
            if (\in_array($setting, $checkbox_settings, true)) {
                \update_option($setting, !empty($_POST[$setting]) ? 1 : 0);
                continue;
            }

            // All other fields: only update if present
            if (!isset($_POST[$setting])) {
                // @MODIFIED 2026-03-09: Ensure checkbox lists (arrays) persist as empty if unchecked
                $array_keys = array(
                    'seo_gen_active_days',
                    'seo_gen_discovery_sections',
                    'seo_gen_update_sections',
                    'seo_gen_title_style',
                    'seo_gen_jetpack_networks',
                    'seo_gen_buffer_enabled_channels',
                    'seo_gen_buffer_channel_link_posts',
                    'seo_gen_buffer_channel_omit_links',
                    'seo_gen_buffer_channel_obfuscate_links',
                );
                if (\in_array($setting, $array_keys, true)) {
                    if ($setting === 'seo_gen_title_style') {
                        \update_option($setting, array('1', '2', '3'));
                    } else {
                        \update_option($setting, array());
                    }
                }
                continue;
            }

            $value = $_POST[$setting];

            // Sanitize based on type
            if (\is_array($value)) {
                if (\in_array($setting, $textarea_array_settings, true)) {
                    $value = \array_map('sanitize_textarea_field', $value);
                } else {
                    $value = \array_map('sanitize_text_field', $value);
                }

                if ($setting === \SEO_Article_Generator\Option_Registry::JETPACK_NETWORK_TEMPLATES) {
                    $global_template = \sanitize_textarea_field(wp_unslash($_POST[\SEO_Article_Generator\Option_Registry::JETPACK_TEMPLATE] ?? ''));
                    foreach ($value as $svc => $tpl) {
                        if (trim($tpl) === trim($global_template) || trim($tpl) === '') {
                            $value[$svc] = '';
                        }
                    }
                }

                if ($setting === 'seo_gen_active_days') {
                    $allowedDays = array('mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun');
                    $value = array_values(array_intersect($allowedDays, array_map('strtolower', $value)));
} elseif ($setting === 'seo_gen_discovery_sections') {
			$defaultSections = \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::DISCOVERY_SECTIONS];
			$value = \SEO_Article_Generator\Generator\Article_Schema::normalize_sections($value, array('toc'));

			if (empty($value)) {
				$value = $defaultSections;
                        \add_settings_error(
                            'seo_gen_settings',
                            'seogen_discovery_sections_empty',
                            \__('Discovery Generation Sections was empty or invalid. It has been reset to the canonical default set.', 'seo-article-generator'),
                            'warning'
                        );
                    }
} elseif ($setting === 'seo_gen_update_sections') {
			$defaultSections = \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::UPDATE_SECTIONS];
			$value = \SEO_Article_Generator\Generator\Article_Schema::normalize_sections($value);

                    if (empty($value)) {
                        $value = $defaultSections;
                        \add_settings_error(
                            'seo_gen_settings',
                            'seogen_update_sections_empty',
                            \__('AI Update Sections was empty or invalid. It has been reset to the canonical default set.', 'seo-article-generator'),
                            'warning'
                        );
                    }
                } else {
                    $filtered = array_filter($value, static function ($item) {
                        return is_string($item) && trim($item) !== '';
                    });
                    $value = \in_array($setting, $assoc_array_settings, true) ? $filtered : array_values($filtered);
                }
                \update_option($setting, $value);

                if ($setting === \SEO_Article_Generator\Option_Registry::JETPACK_NETWORKS) {
                    \update_option(\SEO_Article_Generator\Option_Registry::JETPACK_NETWORKS_INITIALIZED, true);
                }

                continue;
            } elseif (\in_array($setting, $textarea_settings, true)) {
                $value = \sanitize_textarea_field($value);
            } elseif (\strpos($setting, 'api_key') !== false) {
                $value    = \sanitize_text_field($value);
                $existing = (string) \get_option($setting, '');

                // Keep stored key when the admin leaves a masked password field blank.
                if ($value === '' && $existing !== '') {
                    continue;
                }

                // Backward-safe handling for old masked UI behavior.
                if ($value === '••••••••') {
                    continue;
                }
		} elseif (\is_numeric($value)) {
			// @MODIFIED 2026-03-09: Standardize integer casting for count/delay settings
			$int_keys = array(
				'seo_gen_internal_link_count',
				'seo_gen_draft_retention_days',
				'seo_gen_posts_per_day',
				'seo_gen_updates_per_day',
				'seo_gen_update_delay_min',
				'seo_gen_update_delay_max',
				'seo_gen_publish_interval_min',
				'seo_gen_publish_interval_max',
				'seo_gen_auto_generation_batch',
				'seo_gen_auto_generation_interval',
				'seo_gen_platform_threshold',
				'seo_gen_log_retention',
		'seo_gen_daily_quota',
		'seo_gen_tag_max_count',
		'seo_gen_buffer_daily_limit',
	);
			$value = \in_array($setting, $int_keys, true) ? (int) $value : \sanitize_text_field($value);

			if ($setting === 'seo_gen_internal_link_count') {
				$original = $value;
				$value = max(0, min(3, $value));

				if ($value !== $original) {
					\add_settings_error(
						'seo_gen_settings',
						'seo_gen_internal_link_count_clamped',
						\__('Internal link count must be between 0 and 3. The submitted value was clamped to the supported range.', 'seo-article-generator'),
						'warning'
					);
				}
			}

			if ($setting === \SEO_Article_Generator\Option_Registry::DRAFT_RETENTION_DAYS) {
				$value = max(0, min(90, $value));
			}
		} else {
			$value = \sanitize_text_field($value);
			// Guard: GEMINI_MODEL must never be empty
			if ($setting === \SEO_Article_Generator\Option_Registry::GEMINI_MODEL && $value === '') {
				$value = \SEO_Article_Generator\AI\AI_Client::get_default_model_for_provider('gemini');
			}
		}

            \update_option($setting, $value);
        }

        if (isset($_POST[\SEO_Article_Generator\Option_Registry::BUFFER_PUB_TRACKER]) && is_array($_POST[\SEO_Article_Generator\Option_Registry::BUFFER_PUB_TRACKER])) {
            $raw_tracker = wp_unslash($_POST[\SEO_Article_Generator\Option_Registry::BUFFER_PUB_TRACKER]);
            $tracker = array(
                'date' => sanitize_text_field(isset($raw_tracker['date']) ? $raw_tracker['date'] : ''),
                'ids'  => array(),
            );
            if (isset($raw_tracker['ids']) && is_array($raw_tracker['ids'])) {
                $tracker['ids'] = array_values(array_filter(array_map('absint', $raw_tracker['ids'])));
            }
            \update_option(\SEO_Article_Generator\Option_Registry::BUFFER_PUB_TRACKER, $tracker);
        }

        // Save custom providers
        $this->save_custom_providers();

        // @MODIFIED 2026-04-05 - Clean up dead/stale options
        \delete_option('seo_gen_enable_web_search');
        \delete_option('seo_gen_content_mode');
        \delete_option('seo_gen_include_competitors');
        \delete_option('seo_gen_auto_publish');

        // @MODIFIED 2026-03-05 - Trigger rescheduling of automated tasks
        \do_action('seo_gen_settings_saved');


        \add_settings_error(
             'seo_gen_settings',
             'settings_updated',
             \__('Settings saved successfully.', 'seo-article-generator'),
             'success'
         );
    }

    private function save_custom_providers(): void
    {
        if (!isset($_POST['seo_gen_custom_providers']) || !is_array($_POST['seo_gen_custom_providers'])) {
            return;
        }

        $registry = \SEO_Article_Generator\AI\Provider_Registry::get_instance();
        $existing = $registry->get_custom_providers();
        $existing_ids = array();
        foreach ($existing as $ep) {
            $existing_ids[$ep['id']] = $ep;
        }

        $saved = array();
        $submitted = wp_unslash($_POST['seo_gen_custom_providers']);

        foreach ($submitted as $idx => $profile) {
            if (!is_array($profile)) {
                continue;
            }

            $id = isset($profile['id']) ? sanitize_key($profile['id']) : '';
            $name = isset($profile['name']) ? sanitize_text_field($profile['name']) : '';
            $api_url = isset($profile['api_url']) ? esc_url_raw($profile['api_url']) : '';
            $posted_key = isset($profile['api_key']) ? sanitize_text_field($profile['api_key']) : '';

            if (empty($name) || empty($api_url)) {
                continue;
            }

            if (empty($id)) {
                $id = 'prov_' . time() . '_' . wp_generate_password(5, false);
            }

            $api_key = $posted_key;
            if (empty($api_key) && isset($existing_ids[$id])) {
                $api_key = $existing_ids[$id]['api_key'];
            }
            if ($api_key === '••••••••' && isset($existing_ids[$id])) {
                $api_key = $existing_ids[$id]['api_key'];
            }

            $models = array();
            if (isset($profile['models']) && is_array($profile['models'])) {
                foreach ($profile['models'] as $m) {
                    $mid = isset($m['model_id']) ? sanitize_text_field($m['model_id']) : '';
                    $mname = isset($m['display_name']) ? sanitize_text_field($m['display_name']) : $mid;
                    if (!empty($mid)) {
                        $models[] = array('model_id' => $mid, 'display_name' => $mname);
                    }
                }
            }

            if (empty($models)) {
                continue;
            }

            $saved[] = array(
                'id' => $id,
                'name' => $name,
                'api_url' => $api_url,
                'api_key' => $api_key,
                'enable_web_search' => !empty($profile['enable_web_search']),
                'fallback_enabled' => !empty($profile['fallback_enabled']),
                'supports_json_schema' => !empty($profile['supports_json_schema']),
                'web_search_config' => array(
                    'type' => isset($profile['web_search_config']['type']) ? sanitize_text_field($profile['web_search_config']['type']) : 'none',
                    'search_engine' => isset($profile['web_search_config']['search_engine']) ? sanitize_text_field($profile['web_search_config']['search_engine']) : 'search_pro',
                    'search_count' => min(20, max(1, (int)($profile['web_search_config']['search_count'] ?? 10))),
                ),
                'models' => $models,
            );
        }

        $registry->save_custom_providers($saved);
    }

}
