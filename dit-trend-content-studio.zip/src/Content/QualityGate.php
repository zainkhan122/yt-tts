<?php

/**
 * Truth Enforcer
 *
 * Detects hallucinations and validates citation density.
 *
 * @package DIT_TrendStudio\Validation
 * @since   1.3.0
 */

namespace DIT\TrendStudio\Content;

use DIT\TrendStudio\Schema\Content_Schema;
use DIT\TrendStudio\Infrastructure\Logger;
use DIT\TrendStudio\Content\ReadabilityChecker;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Enforces factual accuracy and verification
 */
class QualityGate
{
    /**
     * Hallucinated domain patterns (extracted from legacy logic).
     */
    private const SUSPICIOUS_DOMAINS = [
        'example.com',
        'placeholder.com',
        'celeb-daily-news.com',
        'officialsite.com',
        'download-now.org',
    ];

    /**
     * Audit article for truthfulness and grounding.
     * @MODIFIED 2026-01-12 - Replaced min_citations with claim-based verification
     * @MODIFIED 2026-01-12 - Made superlative checking context-aware for commercial intent
     *
     * @param Content_Schema $schema
     * @param array          $config
     * @return array
     */
    public function audit(Content_Schema $schema, array $config): array
    {
        $issues = [];
        $pts_lost = 0;

        // --- Readability & Style Enforcement ---
        $checker    = new ReadabilityChecker();
        $readability = $checker->evaluate($schema->to_array());
        // Threshold (default 60) can be overridden with the tcs_readability_threshold filter
        $score_threshold = (float) apply_filters('tcs_readability_threshold', 60.0);
        if ($readability['score'] < $score_threshold) {
            $issues[] = sprintf(
                'Readability score %.1f is below the threshold of %.1f.',
                $readability['score'],
                $score_threshold
            );
            $pts_lost += 5;
        }
        if ($readability['passive_sentences'] > 0) {
            $issues[] = sprintf('Detected %d sentences likely in passive voice.', $readability['passive_sentences']);
            $pts_lost += $readability['passive_sentences'];
        }
        if ($readability['paragraphs_too_long'] > 0) {
            $issues[] = sprintf('Detected %d paragraphs exceeding word limit.', $readability['paragraphs_too_long']);
            $pts_lost += $readability['paragraphs_too_long'];
        }

        // @MODIFIED 2026-01-12 - Replace density check with claim-based ratio check
        $source_count = count($schema->sources);

        // @MODIFIED 2026-01-12 - Pass intent to skip superlatives in commercial content
        $search_intent = $config['search_intent'] ?? 'mixed';
        $claims = $this->spot_claims($schema, $search_intent);
        $uncited_claims = $this->count_uncited_claims($claims, $schema);

        if ($uncited_claims > 0) {
            $ratio = $uncited_claims / max(count($claims), 1);
            if ($ratio > 0.5) {
                $issues[] = sprintf('Claim verification: %d of %d specific claims lack nearby citations.', $uncited_claims, count($claims));
                $pts_lost += ($uncited_claims * 3);
            }
        }

        // 2. Unnamed Source Pattern Detection
        $unnamed_patterns = [
            '/(unnamed|anonymous|inside) sources? (says|claims|reports)/i',
            '/(according to) (some|multiple|various) reports/i',
            '/rumors (are|have it)/i',
        ];

        $unnamed_count = 0;
        foreach ($schema->sections as $section) {
            foreach ($unnamed_patterns as $pattern) {
                if (preg_match($pattern, $section['body_html'])) {
                    $unnamed_count++;
                }
            }
        }

        if ($unnamed_count > 0) {
            $penalty = $unnamed_count * $config['penalty_unnamed'];
            $issues[] = sprintf('Detected %d instances of "unnamed source" claims (-%d pts).', $unnamed_count, $penalty);
            $pts_lost += $penalty;
        }

        // 3. Hallucinated Link Check
        foreach ($schema->sources as $source) {
            $url = $source['url'] ?? '';
            foreach (self::SUSPICIOUS_DOMAINS as $domain) {
                if (strpos($url, $domain) !== false) {
                    $issues[] = sprintf('Suspicious/hallucinated source detected: %s', $url);
                    $pts_lost += 20; // Critical penalty
                    break;
                }
            }
        }

        // --- Media passthrough integrity ---
        // @MODIFIED 2026-02-16 - Detect leaked [VISUAL_N] tokens (should never reach final content).
        $html_blob = '';
        foreach ((array) $schema->sections as $section) {
            $html_blob .= "\n" . (string) ($section['body_html'] ?? $section['bodyhtml'] ?? '');
        }
        if (preg_match_all('/\[(?:SOURCE_)?VISUAL_\d+\]/i', $html_blob, $m) && ! empty($m[0])) {
            $issues[] = sprintf('Media passthrough: detected %d leaked visual tokens in final content.', count($m[0]));
            $pts_lost += min(20, count($m[0]) * 2);
        }

        // @MODIFIED 2026-02-16 - Phase 3: Structured blocks validation (visual_ref integrity)
        $pmode = (string) get_option('dit_ts_media_placement_mode', 'token_matcher');
        if ($pmode === 'structured_blocks') {
            // @MODIFIED 2026-02-17 - Phase 4.1.1: $article is not in scope here; use config-provided visual map.
            $source_map = [];
            if (!empty($config['source_visual_map']) && is_array($config['source_visual_map'])) {
                $source_map = $config['source_visual_map'];
            } elseif (!empty($config['_source_visual_map']) && is_array($config['_source_visual_map'])) {
                $source_map = $config['_source_visual_map'];
            }

            // Scan structured blocks for leaked tokens too.
            $leaks = 0;
            foreach ((array) $schema->sections as $s) {
                foreach ((array) ($s['blocks'] ?? []) as $b) {
                    if (!is_array($b)) {
                        continue;
                    }
                    $blob = (string) ($b['html'] ?? $b['text'] ?? $b['url'] ?? '');
                    if ($blob !== '' && preg_match_all('/\[(?:SOURCE_)?VISUAL_\d+\]/i', $blob, $mm)) {
                        $leaks += count($mm[0]);
                    }
                }
            }
            if ($leaks > 0) {
                $issues[] = sprintf('Structured blocks: detected %d leaked visual tokens inside blocks.', $leaks);
                $pts_lost += min(20, $leaks * 2);
            }

            $expected_ids = [];
            foreach (array_keys($source_map) as $k) {
                if (preg_match('/^\[VISUAL_(\d+)\]$/', (string) $k, $mm)) {
                    $expected_ids[] = (int) $mm[1];
                }
            }
            $expected_ids = array_values(array_unique($expected_ids));

            $seen_ids = [];
            foreach ((array) ($schema->sections ?? []) as $s) {
                foreach ((array) ($s['blocks'] ?? []) as $b) {
                    if (!is_array($b)) {
                        continue;
                    }
                    if (($b['type'] ?? '') === 'visual_ref' && isset($b['id'])) {
                        $seen_ids[] = (int) $b['id'];
                    }
                }
            }
            $seen_ids = array_values(array_unique($seen_ids));

            if (!empty($expected_ids) && empty($seen_ids)) {
                $issues[] = 'Structured blocks: source visuals exist but no visual_ref blocks were output.';
                $pts_lost += 15;
            } else {
                // Unknown refs
                $unknown = array_diff($seen_ids, $expected_ids);
                if (!empty($unknown)) {
                    $issues[] = 'Structured blocks: unknown visual_ref ids detected: ' . implode(',', array_map('intval', $unknown));
                    $pts_lost += min(15, count($unknown) * 3);
                }
            }
        }

        return [
            'issues'   => $issues,
            'pts_lost' => $pts_lost,
            'is_grounded' => ($source_count > 0 && $pts_lost < 30),
            'claims_found' => count($claims),
            'uncited_claims' => $uncited_claims,
        ];
    }

    /**
     * Spot specific claims that require citations
     * @MODIFIED 2026-01-12 - NEW: Identifies numbers, dates, and absolute claims
     * @MODIFIED 2026-01-12 - Made superlative checking intent-aware (skips for commercial)
     *
     * @param Content_Schema $schema
     * @param string         $search_intent Search intent for context-aware checking
     * @return array List of claims found with their context
     */
    private function spot_claims(Content_Schema $schema, string $search_intent = 'mixed'): array
    {
        $claims = [];

        // Patterns for claims that need citations
        $claim_patterns = [
            '/\$[\d,]+(\.\\d+)?/' => 'monetary_value',           // $1,000
            '/\d{1,2}\/\d{1,2}\/\d{2,4}/' => 'date',            // 12/31/2024
            '/\b(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},?\s*\d{4}/i' => 'date', // January 1, 2024
            '/\b\d{4}\b/' => 'year',                            // 2024 (standalone year)
            '/\b\d+(\.\d+)?%/' => 'percentage',                 // 50%
            '/\b(study|research|survey|poll|report)\s+(shows|found|reveals|indicates)/i' => 'study_reference',
        ];

        // @MODIFIED 2026-01-12 - Only check superlatives for non-commercial content
        // Commercial/review content is allowed to use opinion superlatives
        if ($search_intent !== 'commercial') {
            $claim_patterns['/\b(first|best|worst|largest|smallest|most|least|only)\b/i'] = 'superlative';
        }

        foreach ($schema->sections as $section) {
            $text = wp_strip_all_tags($section['body_html'] ?? '');

            foreach ($claim_patterns as $pattern => $type) {
                if (preg_match_all($pattern, $text, $matches, PREG_OFFSET_CAPTURE)) {
                    foreach ($matches[0] as $match) {
                        $claims[] = [
                            'text' => $match[0],
                            'type' => $type,
                            'position' => $match[1],
                            'section' => $section['heading'] ?? 'unknown',
                        ];
                    }
                }
            }
        }

        return $claims;
    }

    /**
     * Count claims that lack nearby citation tags
     * @MODIFIED 2026-01-12 - NEW: Checks for [cite] or source reference near claims
     *
     * @param array          $claims Claims array from spot_claims
     * @param Content_Schema $schema Content schema
     * @return int Number of uncited claims
     */
    private function count_uncited_claims(array $claims, Content_Schema $schema): int
    {
        $uncited = 0;

        foreach ($schema->sections as $section) {
            $body = $section['body_html'] ?? '';
            $text = wp_strip_all_tags($body);

            // Check for citation markers
            $has_citations = (
                strpos($body, '[cite') !== false ||
                strpos($body, 'data-source') !== false ||
                preg_match('/\[[\d,]+\]/', $body) ||  // [1] style
                preg_match('/\(source:?\s/i', $body)   // (source: ...) style
            );

            // If section has claims but no citation mechanism, count uncited
            $section_claims = array_filter($claims, fn($c) => ($c['section'] ?? '') === ($section['heading'] ?? ''));

            // Skip superlatives in non-factual sections (they may be opinion)
            $factual_claims = array_filter($section_claims, fn($c) => $c['type'] !== 'superlative');

            if (!$has_citations && count($factual_claims) > 0) {
                $uncited += count($factual_claims);
            }
        }

        return $uncited;
    }
}
