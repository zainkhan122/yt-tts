<?php

/**
 * Generation Context (Immutable Value Object)
 *
 * @package SEO_Article_Generator\Generator
 * @since 2.20.0
 * @MODIFIED 2026-03-03: Created as part of lean industrial refactor
 */

namespace SEO_Article_Generator\Generator;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Immutable value object representing the context for a single generation run.
 *
 * Replaces raw associative arrays with typed, validated properties.
 * Prevents state leakage between retries and ensures every downstream
 * consumer (Prompt_Builder, Providers, Normalizer) operates on deterministic input.
 */
class Generation_Context
{
    /** @var string Prompt template version — stored in post meta to prevent silent drift */
    const PROMPT_VERSION = '2.0.0';

    /** @var string Generation type: 'new' | 'update' | 'upgrade' | 'partial' */
    public $type;

    /** @var string Grounding strategy: 'search' | 'provided' */
    public $grounding;

    /** @var array Sections to regenerate, e.g. ['all'] or ['tech_specs', 'download'] */
    public $sections;

    /** @var bool Whether to preserve tone from existing post */
    public $preserve_tone;

    /** @var bool Whether to preserve featured image from existing post */
    public $preserve_images;

    /** @var string The prompt template version */
    public $prompt_version;

    /** @var string Input source: 'manual' | 'discovery' */
    public $input_type; // @MODIFIED 2026-03-07

    /**
     * Build a Generation_Context from raw input data.
     *
     * Factory method — single point of context creation.
     * Determines grounding and type from input signals, not from caller opinions.
     *
     * @param array  $input_data  Raw input from Job_Handler or Discovery_Processor
     * @param string $input_type  'manual' or 'discovery'
     * @return self
     */
    public static function from_input(array $input_data, string $input_type = 'manual'): self
    {
        $ctx = new self();
        $ctx->input_type = $input_type; // @MODIFIED 2026-03-07

        // ── Grounding: Determined by data presence and post state ──
        // @MODIFIED 2026-03-03: Grounding tied to data presence per architectural review
        // @MODIFIED 2026-04-12: NEW discovery posts always use 'search' grounding.
        // build_grounding_instruction() maps 'provided' -> HYBRID MODE which tells Gemini:
        // "use search ONLY for missing metadata and moat_data" — that 'ONLY' causes the
        // model to synthesise MOAT from provided HTML context instead of searching the web.
        // For NEW posts there is no existing article to preserve, so RESEARCH MODE is correct.
        // UPDATE posts keep 'provided' grounding so HYBRID MODE protects their existing content.
        $has_rich_content = !empty($input_data['article_context'])
            && mb_strlen($input_data['article_context']) > 500;

        $is_update_post = !empty($input_data['existing_post_id']);

        if ($input_type === 'discovery' && !$is_update_post) {
            // New discovery post: full RESEARCH MODE — AI searches everything including MOAT.
            // The changelog HTML in article_context is still visible as supplementary context.
            $ctx->grounding = 'search';
        } else {
            $ctx->grounding = $has_rich_content ? 'provided' : 'search';
        }

        // ── Type: Determined by post state ──
        $is_update = !empty($input_data['existing_post_id']);

        if (!$is_update) {
            $ctx->type = 'new';
        } elseif (!empty($input_data['is_legacy_upgrade'])) {
            $ctx->type = 'upgrade';
        } elseif (!empty($input_data['regen_sections']) && !in_array('all', (array) $input_data['regen_sections'], true)) {
            $ctx->type = 'partial';
        } else {
            $ctx->type = 'update';
        }

        // ── Sections ──
        $ctx->sections = !empty($input_data['regen_sections'])
            ? (array) $input_data['regen_sections']
            : array('all');

        // ── Preservation flags ──
        $ctx->preserve_tone   = in_array($ctx->type, array('update', 'partial'), true);
        $ctx->preserve_images = in_array($ctx->type, array('update', 'partial', 'upgrade'), true);

        // ── Prompt version ──
        $ctx->prompt_version = self::PROMPT_VERSION;

        return $ctx;
    }

    /**
     * Whether this context requires web search from the AI provider.
     *
     * @return bool
     */
    public function needs_search(): bool
    {
        // @MODIFIED 2026-03-11: Restored for Robustness.
        // Even if rich content is provided, AI should have search capability 
        // to fill gaps in tech specs (Dev, Size, etc.) as per user feedback.
        if (isset($this->input_type) && $this->input_type === 'discovery') {
            return true;
        }

        return $this->grounding === 'search';
    }

    /**
     * Whether this is a full article generation (all sections).
     *
     * @return bool
     */
    public function is_full(): bool
    {
        return in_array('all', $this->sections, true);
    }
}
