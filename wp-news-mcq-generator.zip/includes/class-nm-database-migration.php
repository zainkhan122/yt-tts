<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Database Migration Handler
 * Handles database version updates ONLY (not initial creation)
 * Initial creation is done in activation hook
 *
 * @package WP_News_MCQ_Generator
 * @version 2.1
 */

class NM_Database_Migration {

	private static $instance   = null;
	private static $db_version = '2.2';

	public static function init() {
		if ( self::$instance === null ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		// Check for database updates on admin_init
		add_action( 'admin_init', array( $this, 'check_database_version' ), 1 );
	}

	/**
	 * Check if database needs updating
	 */
	public function check_database_version() {
		$installed_version = get_option( 'nm_db_version', '0' );

		if ( version_compare( $installed_version, self::$db_version, '<' ) ) {
			$this->upgrade_database( $installed_version );
		}
	}

	/**
	 * Upgrade database from older version
	 */
	private function upgrade_database( $from_version ) {
		global $wpdb;


		// Version-specific upgrades
		if ( version_compare( $from_version, '2.0', '<' ) ) {
			// Upgrade to 2.0 - add any new columns or indexes here
			$this->upgrade_to_2_0();
		}

		if ( version_compare( $from_version, '2.1', '<' ) ) {
			// Upgrade to 2.1 - add cognitive_level column and index to nmmcqdata
			$this->upgrade_to_2_1();
		}

		if ( version_compare( $from_version, '2.2', '<' ) ) {
			// Upgrade to 2.2 - add topic_slug + exam_slug columns and indexes to nmmcqdata
			$this->upgrade_to_2_2();
		}

		// Update version
		update_option( 'nm_db_version', self::$db_version );

		// Clear all caches
		if ( class_exists( 'NM_Cache_Manager' ) ) {
			NM_Cache_Manager::clear_all();
		}

	}

	/**
	 * Upgrade to version 2.0
	 */
	private function upgrade_to_2_0() {
		global $wpdb;

		// Add any missing indexes
		$this->add_missing_indexes();

		// Optimize tables
		$tables = array(
			'nm_rate_limits',
			'nm_points_log',
			'nm_user_answers',
			'nm_certificates',
			'nm_notifications',
			'nm_user_sessions',
			'nm_quiz_sessions',
		);

		foreach ( $tables as $table ) {
			$wpdb->query( $wpdb->prepare( 'OPTIMIZE TABLE %i', $wpdb->prefix . $table ) );
		}
	}
	/**
	 * Upgrade to version 2.1
	 * - Ensure nm_mcq_data has a cognitive_level column and index.
	 */
	private function upgrade_to_2_1() {
		global $wpdb;

		// Use the new optimized table name
		$mcq_table = $wpdb->prefix . 'nm_mcq_data';

		// First: check if the optimized table actually exists
		$table_exists = $wpdb->get_var(
			$wpdb->prepare(
				'SHOW TABLES LIKE %s',
				$mcq_table
			)
		);

		// If there is no optimized table yet, bail out quietly
		if ( empty( $table_exists ) ) {
			return;
		}

		// Check if the cognitive_level column already exists
		$column_exists = $wpdb->get_var(
			$wpdb->prepare(
				"SHOW COLUMNS FROM {$mcq_table} LIKE %s",
				'cognitive_level'
			)
		);

		if ( empty( $column_exists ) ) {
			// Add the cognitive_level column
			$wpdb->query(
				"ALTER TABLE {$mcq_table}
                 ADD COLUMN cognitive_level varchar(20) DEFAULT 'understand' AFTER difficulty"
			);

			// Add an index on cognitive_level (avoid IF NOT EXISTS for wider MySQL support)
			$index_exists = $wpdb->get_var(
				$wpdb->prepare(
					"SHOW INDEX FROM {$mcq_table} WHERE Key_name = %s",
					'idx_nm_mcq_data_cognitive_level'
				)
			);

			if ( empty( $index_exists ) ) {
				$wpdb->query(
					"CREATE INDEX idx_nm_mcq_data_cognitive_level
                     ON {$mcq_table} (cognitive_level)"
				);
			}
		}
	}
	/**
	 * Upgrade to version 2.2
	 *
	 * - Add topic_slug and exam_slug columns to nm_mcq_data
	 * - Add indexes for topic_slug, exam_slug, and (exam_slug, topic_slug, difficulty)
	 */
	private function upgrade_to_2_2() {
		global $wpdb;

		$table_name = $wpdb->prefix . 'nm_mcq_data';

		// Bail out if table does not exist
		$exists = $wpdb->get_var(
			$wpdb->prepare(
				'SHOW TABLES LIKE %s',
				$table_name
			)
		);

		if ( $exists !== $table_name ) {
			return;
		}

		// ---------------------------------------------------------------------
		// 1) Add topic_slug column if missing
		// ---------------------------------------------------------------------
		$column_topic = $wpdb->get_var(
			$wpdb->prepare(
				"SHOW COLUMNS FROM {$table_name} LIKE %s",
				'topic_slug'
			)
		);

		if ( ! $column_topic ) {
			$alter_sql = "ALTER TABLE {$table_name} 
            ADD COLUMN topic_slug VARCHAR(191) NOT NULL DEFAULT '' 
            AFTER cognitive_level";

			$wpdb->query( $alter_sql );
		}

		// ---------------------------------------------------------------------
		// 2) Add exam_slug column if missing
		// ---------------------------------------------------------------------
		$column_exam = $wpdb->get_var(
			$wpdb->prepare(
				"SHOW COLUMNS FROM {$table_name} LIKE %s",
				'exam_slug'
			)
		);

		if ( ! $column_exam ) {
			$alter_sql = "ALTER TABLE {$table_name} 
            ADD COLUMN exam_slug VARCHAR(191) NOT NULL DEFAULT '' 
            AFTER topic_slug";

			$wpdb->query( $alter_sql );
		}

		// ---------------------------------------------------------------------
		// 3) Add single-column indexes
		// ---------------------------------------------------------------------
		$existing_indexes = $wpdb->get_results(
			$wpdb->prepare(
				"SHOW INDEX FROM {$table_name} WHERE Column_name IN (%s,%s,%s)",
				'topic_slug',
				'exam_slug',
				'difficulty'
			),
			ARRAY_A
		);

		$has_topic_index = false;
		$has_exam_index  = false;

		if ( ! empty( $existing_indexes ) ) {
			foreach ( $existing_indexes as $idx ) {
				if ( $idx['Column_name'] === 'topic_slug' ) {
					$has_topic_index = true;
				}
				if ( $idx['Column_name'] === 'exam_slug' ) {
					$has_exam_index = true;
				}
			}
		}

		if ( ! $has_topic_index ) {
			$wpdb->query( "CREATE INDEX idx_nm_mcq_data_topic_slug ON {$table_name} (topic_slug)" );
		}

		if ( ! $has_exam_index ) {
			$wpdb->query( "CREATE INDEX idx_nm_mcq_data_exam_slug ON {$table_name} (exam_slug)" );
		}

		// ---------------------------------------------------------------------
		// 4) Add composite index for (exam_slug, topic_slug, difficulty)
		// ---------------------------------------------------------------------
		$composite_index = $wpdb->get_var(
			$wpdb->prepare(
				"SHOW INDEX FROM {$table_name} WHERE Key_name = %s",
				'idx_nm_mcq_data_exam_topic_diff'
			)
		);

		if ( ! $composite_index ) {
			$wpdb->query(
				"CREATE INDEX idx_nm_mcq_data_exam_topic_diff 
                      ON {$table_name} (exam_slug, topic_slug, difficulty)"
			);
		}
	}
	/**
	 * Add missing indexes
	 */
	private function add_missing_indexes() {
		global $wpdb;

		$indexes = array(
			'nm_points_log'    => array(
				'idx_user_points_created' => '(user_id, created_at, points)',
			),
			'nm_user_answers'  => array(
				'idx_user_mcq_correct' => '(user_id, is_correct, answered_at)',
			),
			'nm_notifications' => array(
				'idx_user_read_created' => '(user_id, is_read, created_at)',
			),
		);

		foreach ( $indexes as $table => $table_indexes ) {
			foreach ( $table_indexes as $index_name => $columns ) {
				$full_table = $wpdb->prefix . $table;

				// Check if index exists
				$index_exists = $wpdb->get_results(
					$wpdb->prepare(
						'SHOW INDEX FROM %i WHERE Key_name = %s',
						$full_table,
						$index_name
					)
				);

				if ( empty( $index_exists ) ) {
					// Note: CREATE INDEX cannot be fully prepared, but %i and %s are safe internal variables.
					// This is an acceptable use case.
					$wpdb->query(
						$wpdb->prepare(
							"CREATE INDEX %i ON %i $columns", // $columns is hardcoded, not user input
							$index_name,
							$full_table
						)
					);
				}
			}
		}
	}

	/**
	 * Get database statistics
	 */
	public static function get_statistics() {
		global $wpdb;

		$stats = array();

		$tables = array(
			'nm_rate_limits'   => 'Rate Limit Entries',
			'nm_points_log'    => 'Points Transactions',
			'nm_user_answers'  => 'User Answers',
			'nm_certificates'  => 'Certificates Issued',
			'nm_notifications' => 'Notifications',
			'nm_user_sessions' => 'Active Sessions',
			'nm_quiz_sessions' => 'Quiz Sessions',
		);

		foreach ( $tables as $table => $label ) {
			$count           = $wpdb->get_var(
				$wpdb->prepare(
					'SELECT COUNT(*) FROM %i',
					$wpdb->prefix . $table
				)
			);
			$stats[ $table ] = array(
				'label' => $label,
				'count' => (int) $count,
			);
		}

		return $stats;
	}

	/**
	 * Cleanup old data
	 */
	public static function cleanup_old_data() {
		global $wpdb;

		// Clean old rate limit entries (older than 24 hours)
		$wpdb->query(
			$wpdb->prepare(
				'DELETE FROM %i WHERE created_at < DATE_SUB(NOW(), INTERVAL 24 HOUR)',
				$wpdb->prefix . 'nm_rate_limits'
			)
		);

		// Clean expired sessions
		$wpdb->query(
			$wpdb->prepare(
				'DELETE FROM %i WHERE expires_at < NOW()',
				$wpdb->prefix . 'nm_user_sessions'
			)
		);

		// Notifications cleanup is handled by nm_cleanup_notifications_cron (daily),
		// which runs a stricter retention (read >30d, all >90d). Do not duplicate here.

		// Clean old quiz sessions (completed and older than 7 days)
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM %i WHERE status = 'completed' AND end_time < DATE_SUB(NOW(), INTERVAL 7 DAY)",
				$wpdb->prefix . 'nm_quiz_sessions'
			)
		);

		// ✅ NEW: Enforce log retention window on nm_generation_events.
		// Single source of truth for retention lives in NM_Generation_Logger::get_retention_days()
		// (configurable from Settings → Uninstall/Logs → "Generation Log Retention (Days)").
		if ( class_exists( 'NM_Generation_Logger' ) ) {
			NM_Generation_Logger::purge_old_logs();
		}

	}

	/**
	 * Cleanup buffer share history older than 30 days.
	 * Trims _nm_buffer_share_history post meta arrays month-wise so the
	 * wp_postmeta table and get_lifetime_stats() do not grow without bound.
	 */
	public static function cleanup_buffer_share_history() {
		global $wpdb;

		$cutoff = gmdate('Y-m-d H:i:s', strtotime('-30 days'));

		$results = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = %s",
				'_nm_buffer_share_history'
			)
		);

		if (empty($results)) {
			return;
		}

		foreach ($results as $row) {
			$history = maybe_unserialize($row->meta_value);
			if (! is_array($history) || empty($history)) {
				delete_post_meta($row->post_id, '_nm_buffer_share_history');
				continue;
			}

			$trimmed = array_values(array_filter($history, function ($entry) use ($cutoff) {
				return isset($entry['shared_at']) && $entry['shared_at'] >= $cutoff;
			}));

			if (empty($trimmed)) {
				delete_post_meta($row->post_id, '_nm_buffer_share_history');
			} elseif (count($trimmed) < count($history)) {
				update_post_meta($row->post_id, '_nm_buffer_share_history', $trimmed);
			}
		}
	}
}
