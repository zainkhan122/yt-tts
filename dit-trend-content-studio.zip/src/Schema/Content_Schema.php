<?php

/**
 * Content Schema DTO
 *
 * @package DIT_TrendStudio
 * @MODIFIED 2025-12-13 - New minimal schema for magazine content
 * @MODIFIED 2025-12-13 - Added image_attribution and verification_status for P0 compliance
 */

namespace DIT\TrendStudio\Schema;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Minimal schema for magazine/showbiz/fashion content
 * 
 * Unlike the SEO Article Generator's ArticleSchema which was designed for
 * software download pages, this schema is intentionally simpler and focused
 * on editorial content without structural claims like version numbers, file sizes, etc.
 */
class Content_Schema
{
    /**
     * Article headline
     *
     * @var string
     */
    public string $headline = '';

    /**
     * Dek/subhead (summary line under headline)
     *
     * @var string
     */
    public string $dek = '';

    /**
     * Primary category
     *
     * @var string
     */
    public string $category = '';

    /**
     * Tags array
     *
     * @var string[]
     */
    public array $tags = array();

    /**
     * Hero image URL
     *
     * @var string
     */
    public string $hero_image = '';

    /**
     * Hero image alt text
     *
     * @var string
     */
    public string $hero_image_alt = '';

    /**
     * Image attribution data
     * @MODIFIED 2025-12-13 - Added for P0 image attribution compliance
     *
     * @var array{credit: string, license: string, source_url: string}
     */
    public array $image_attribution = array();

    /**
     * Content sections
     * Each section: ['heading' => string, 'body_html' => string, 'verification_status' => string]
     *
     * @var array
     */
    public array $sections = array();

    /**
     * Source references
     * Each source: ['url' => string, 'label' => string, 'fetched_at' => string]
     *
     * @var array
     */
    public array $sources = array();

    /**
     * Internal link suggestions
     * Each link: ['url' => string, 'anchor' => string]
     *
     * @var array
     */
    public array $internal_links = array();

    /**
     * Content blocks for rankability (vertical-specific)
     * @since 1.8.1
     * E.g., fashion: ['what_to_buy' => [...], 'how_to_wear' => [...]]
     *
     * @var array
     */
    public array $content_blocks = array();

    /**
     * SEO meta description
     *
     * @var string
     */
    public string $meta_description = '';

    /**
     * Primary keyword for SEO
     *
     * @var string
     */
    public string $primary_keyword = '';

    /**
     * Social assets (e.g. Urdu text for collages)
     *
     * @var array
     */
    public array $social_assets = array();

    /**
     * Content vertical: showbiz, fashion, beauty
     *
     * @var string
     */
    public string $vertical = 'showbiz';

    /**
     * Source idea ID (dit_idea post ID)
     *
     * @var int|null
     */
    public ?int $idea_id = null;

    /**
     * Create schema from AI response array
     *
     * @param array $data Raw AI response data
     * @return self
     */
    public static function from_ai_array(array $data): self
    {
        $schema = new self();

        $schema->headline = trim($data['headline'] ?? $data['title'] ?? '');
        $schema->dek = trim($data['dek'] ?? $data['subhead'] ?? $data['excerpt'] ?? '');
        $schema->category = trim($data['category'] ?? '');
        $schema->tags = self::ensure_array($data, 'tags');
        $schema->hero_image = trim($data['hero_image'] ?? $data['heroimage'] ?? '');
        $schema->hero_image_alt = trim($data['hero_image_alt'] ?? $data['heroimagealt'] ?? '');

        // @MODIFIED 2025-12-27 - Auto-trim meta description to 160 chars max
        $meta = trim($data['meta_description'] ?? $data['metadescription'] ?? '');
        if (mb_strlen($meta) > 160) {
            $meta = mb_substr($meta, 0, 157) . '…';
        }
        $schema->meta_description = $meta;
        $schema->primary_keyword = trim($data['primary_keyword'] ?? $data['focus_keyword'] ?? '');
        $schema->vertical = trim($data['vertical'] ?? 'showbiz');

        // @MODIFIED 2025-12-13 - Parse image attribution for P0 compliance
        $raw_attribution = $data['image_attribution'] ?? $data['imageattribution'] ?? array();
        if (is_array($raw_attribution)) {
            $schema->image_attribution = array(
                'credit' => trim($raw_attribution['credit'] ?? ''),
                'license' => trim($raw_attribution['license'] ?? ''),
                'source_url' => trim($raw_attribution['source_url'] ?? $raw_attribution['sourceurl'] ?? ''),
            );
        }

        // Normalize sections
        // @MODIFIED 2025-12-13 - Added verification_status parsing for P0 fact-check signals
        // @MODIFIED 2025-12-14 - Added image suggestion fields
        // @MODIFIED 2025-12-27 - VERIFIED fail-closed: downgrade if no [N] citation markers
        $raw_sections = self::ensure_array($data, 'sections');
        $schema->sections = array_map(function ($section) {
            $status = trim($section['verification_status'] ?? $section['verificationstatus'] ?? '');
            // Normalize to valid enum values, default to UNVERIFIED for safety
            if (!in_array($status, array('VERIFIED', 'UNVERIFIED', 'REPORT_CLAIMS'), true)) {
                $status = 'UNVERIFIED';
            }
            $body_html = trim($section['body_html'] ?? $section['bodyhtml'] ?? $section['body'] ?? $section['content'] ?? '');
            $raw_blocks = $section['blocks'] ?? $section['section_blocks'] ?? null;
            $blocks = [];
            if (is_array($raw_blocks)) {
                foreach ($raw_blocks as $b) {
                    if (!is_array($b)) {
                        continue;
                    }
                    $type = trim((string) ($b['type'] ?? ''));
                    if ($type === '') {
                        continue;
                    }
                    $nb = ['type' => $type];

                    // Normalize common fields
                    if (isset($b['html'])) {
                        $nb['html'] = (string) $b['html'];
                    }
                    if (isset($b['text'])) {
                        $nb['text'] = (string) $b['text'];
                    }
                    if (isset($b['level'])) {
                        $nb['level'] = (int) $b['level'];
                    }
                    if (isset($b['id'])) {
                        $nb['id'] = (int) $b['id'];
                    }
                    if (isset($b['url'])) {
                        $nb['url'] = (string) $b['url'];
                    }
                    $blocks[] = $nb;
                }
            }

            // Play nice with legacy validators: if blocks exist, derive body_html from them
            if (!empty($blocks)) {
                $derived = '';
                foreach ($blocks as $b) {
                    $t = (string) ($b['type'] ?? '');
                    if ($t === 'p' && !empty($b['html'])) {
                        $derived .= "\n" . (string) $b['html'];
                    } elseif ($t === 'html' && !empty($b['html'])) {
                        $derived .= "\n" . (string) $b['html'];
                    }
                }
                if (trim($derived) !== '') {
                    $body_html = trim($derived);
                }
            }

            // Fail-closed: VERIFIED requires actual inline citations [N]
            if ($status === 'VERIFIED' && !preg_match('/\[\d+\]/', $body_html)) {
                $status = 'UNVERIFIED';
            }
            return array(
                'heading' => trim($section['heading'] ?? ''),
                'body_html' => $body_html,
                'verification_status' => $status,
                'blocks' => $blocks, // @MODIFIED 2026-02-16 - Phase 3 structured blocks
                // Image suggestion fields
                'suggested_image_search' => trim($section['suggested_image_search'] ?? $section['suggestedimagesearch'] ?? ''),
                'image_suggestions' => $section['image_suggestions'] ?? [],
                'selected_image' => $section['selected_image'] ?? null,
                // Editorial Callouts (v1.6.0)
                'editorial_callout' => !empty($section['editorial_callout']) ? array(
                    'title' => trim($section['editorial_callout']['title'] ?? ''),
                    'content' => trim($section['editorial_callout']['content'] ?? ''),
                ) : null,
            );
        }, $raw_sections);

        // @MODIFIED 2026-02-08 - Fallback for Showbiz/Fashion 'story_narrative' structure
        // If no sections found but 'story_narrative' exists, convert it to a main section
        if (empty($schema->sections) && !empty($data['story_narrative'])) {
            $schema->sections[] = array(
                'heading' => 'Story',
                'body_html' => trim($data['story_narrative']),
                'verification_status' => 'UNVERIFIED',
            );
        }

        // @MODIFIED 2026-03-14 - Defensive rescue: AI sometimes returns body_html/content as top-level key
        // instead of nesting it inside sections[]. Capture it so the post isn't empty.
        if (empty($schema->sections)) {
            $rescue_html = trim(
                (string) ($data['body_html'] ?? $data['bodyhtml'] ?? $data['content'] ?? $data['narrative'] ?? '')
            );
            if ($rescue_html !== '') {
                $schema->sections[] = array(
                    'heading'             => '',
                    'body_html'           => $rescue_html,
                    'verification_status' => 'UNVERIFIED',
                );
            }
        }


        // Normalize sources and filter invalid entries
        // @MODIFIED 2025-12-27 - Filter empty/invalid URLs before scoring
        $raw_sources = self::ensure_array($data, 'sources');
        $schema->sources = array_values(array_filter(
            array_map(function ($source) {
                $url = trim($source['url'] ?? '');
                // Skip sources with empty or invalid URLs
                if (empty($url) || !filter_var($url, FILTER_VALIDATE_URL)) {
                    return null;
                }
                return array(
                    'url' => $url,
                    'label' => trim($source['label'] ?? $source['title'] ?? ''),
                    'fetched_at' => trim($source['fetched_at'] ?? gmdate('c')),
                );
            }, $raw_sources),
            fn($s) => $s !== null
        ));

        // Normalize internal links
        $raw_links = self::ensure_array($data, 'internal_links');
        if (empty($raw_links)) {
            $raw_links = self::ensure_array($data, 'internallinks');
        }
        $schema->internal_links = array_map(function ($link) {
            return array(
                'url' => trim($link['url'] ?? ''),
                'anchor' => trim($link['anchor'] ?? $link['text'] ?? ''),
            );
        }, $raw_links);

        // @MODIFIED 2025-12-27 - Parse content blocks for rankability
        // Try both key variants for AI output compatibility
        $schema->content_blocks = self::ensure_array($data, 'content_blocks');
        if (empty($schema->content_blocks)) {
            $schema->content_blocks = self::ensure_array($data, 'contentblocks');
        }

	// @MODIFIED 2026-03-06 - Parse social assets
	// @MODIFIED 2026-05-04 - Normalize Urdu text: strip HTML tags that AI may inject (e.g. <strong>لان</strong>)
	// @MODIFIED 2026-05-08 - AI sometimes returns 'social_asset' (singular); fall back to it if plural is empty
	$raw_social = self::ensure_array($data, 'social_assets');
	if (empty($raw_social)) {
		$raw_social = self::ensure_array($data, 'social_asset');
	}
	$schema->social_assets = self::sanitize_social_assets($raw_social);

        return $schema;
    }

    /**
     * Create schema from database/stored array without AI-time coercion.
     * @MODIFIED 2026-03-09 - Pure re-hydration path (Issue #FixPersistence)
     *
     * @param array $data
     * @return self
     */
    public static function from_array(array $data): self
    {
        $schema = new self();

        $schema->headline          = trim((string) ($data['headline'] ?? ''));
        $schema->dek               = trim((string) ($data['dek'] ?? ''));
        $schema->category          = trim((string) ($data['category'] ?? ''));
        $schema->tags              = is_array($data['tags'] ?? null) ? array_values($data['tags']) : [];
        $schema->hero_image        = trim((string) ($data['hero_image'] ?? ''));
        $schema->hero_image_alt    = trim((string) ($data['hero_image_alt'] ?? ''));
        $schema->image_attribution = is_array($data['image_attribution'] ?? null) ? $data['image_attribution'] : [];
        $schema->sources           = is_array($data['sources'] ?? null) ? array_values($data['sources']) : [];
        $schema->internal_links    = is_array($data['internal_links'] ?? null) ? array_values($data['internal_links']) : [];
        $schema->content_blocks    = is_array($data['content_blocks'] ?? null) ? $data['content_blocks'] : [];
	$schema->social_assets = is_array($data['social_assets'] ?? null) ? self::sanitize_social_assets($data['social_assets']) : [];
	// @MODIFIED 2026-05-08 - Fallback: AI may store 'social_asset' (singular) in DB from old runs
	if (empty($schema->social_assets) && is_array($data['social_asset'] ?? null)) {
		$schema->social_assets = self::sanitize_social_assets($data['social_asset']);
	}
        $schema->meta_description  = trim((string) ($data['meta_description'] ?? ''));
        $schema->primary_keyword   = trim((string) ($data['primary_keyword'] ?? ''));
        $schema->vertical          = trim((string) ($data['vertical'] ?? 'showbiz'));
        $schema->idea_id           = isset($data['idea_id']) ? (int) $data['idea_id'] : null;

        $schema->sections = [];
        foreach ((array) ($data['sections'] ?? []) as $section) {
            if (!is_array($section)) {
                continue;
            }

            $schema->sections[] = [
                'heading'                => trim((string) ($section['heading'] ?? '')),
                'body_html'              => (string) ($section['body_html'] ?? $section['bodyhtml'] ?? ''),
                'verification_status'    => trim((string) ($section['verification_status'] ?? 'UNVERIFIED')),
                'blocks'                 => is_array($section['blocks'] ?? null) ? array_values($section['blocks']) : [],
                'suggested_image_search' => trim((string) ($section['suggested_image_search'] ?? '')),
                'image_suggestions'      => is_array($section['image_suggestions'] ?? null) ? $section['image_suggestions'] : [],
                'selected_image'         => is_array($section['selected_image'] ?? null) ? $section['selected_image'] : null,
                'editorial_callout'      => is_array($section['editorial_callout'] ?? null) ? $section['editorial_callout'] : null,
            ];
        }

        return $schema;
    }

    /**
     * Convert schema to array for storage
     *
     * @return array
     */
    public function to_array(): array
    {
        return array(
            'headline' => $this->headline,
            'dek' => $this->dek,
            'category' => $this->category,
            'tags' => $this->tags,
            'hero_image' => $this->hero_image,
            'hero_image_alt' => $this->hero_image_alt,
            'image_attribution' => $this->image_attribution,
            'sections' => $this->sections,
            'sources' => $this->sources,
            'internal_links' => $this->internal_links,
            'content_blocks' => $this->content_blocks,  // @MODIFIED 2025-12-27
            'social_assets' => $this->social_assets,    // @MODIFIED 2026-03-06
            'meta_description' => $this->meta_description,
            'primary_keyword' => $this->primary_keyword,
            'vertical' => $this->vertical,
            'idea_id' => $this->idea_id,
        );
    }

    /**
     * Get total word count across all sections
     *
     * @return int
     */
    public function get_word_count(): int
    {
        $text = $this->headline . ' ' . $this->dek;
        foreach ($this->sections as $section) {
            $text .= ' ' . wp_strip_all_tags($section['body_html'] ?? '');
        }
        return str_word_count($text);
    }

    /**
     * Check if schema has minimum required content
     *
     * @return bool
     */
    public function is_valid(): bool
    {
        return !empty($this->headline)
            && count($this->sections) >= 1
            && $this->get_word_count() >= 100;
    }

    /**
     * Ensure a key exists as array
     *
     * @param array  $data Data array
     * @param string $key  Key name
     * @return array
     */
    private static function ensure_array(array $data, string $key): array
    {
        if (!isset($data[$key])) {
            return array();
        }
        return is_array($data[$key]) ? $data[$key] : array();
    }

    public static function sanitize_social_assets(array $assets): array
    {
        $text_keys = array('urdu_heading', 'urdu_description');
        foreach ($text_keys as $key) {
            if (isset($assets[$key]) && is_string($assets[$key])) {
                $clean = wp_strip_all_tags(html_entity_decode(trim($assets[$key]), ENT_QUOTES | ENT_HTML5, 'UTF-8'));
                // Clean up known machine-translation artifacts (e.g., Hindi 'پتن' for husband -> 'شوہر')
                $clean = str_replace(['اپنے پتن', 'پتن'], ['اپنے شوہر', 'شوہر'], $clean);
                $clean = str_replace('پیشکش کار', 'اینکر', $clean);
                $assets[$key] = trim($clean);
            }
        }
        if (isset($assets['hashtags']) && is_array($assets['hashtags'])) {
            $assets['hashtags'] = implode(' ', array_values(array_filter(array_map('trim', $assets['hashtags']))));
        }
        return $assets;
    }

    public static function extract_social_assets($data): array
    {
        if (is_object($data)) {
            if (isset($data->social_assets) && is_array($data->social_assets)) {
                return self::sanitize_social_assets($data->social_assets);
            }
            $data = (array) $data;
        }
        if (!is_array($data)) {
            return [];
        }
        $sa = $data['social_assets'] ?? $data['social_asset'] ?? null;
        if (is_string($sa)) {
            $decoded = json_decode($sa, true);
            if (is_array($decoded)) {
                $sa = $decoded;
            }
        }
        if (is_array($sa)) {
            return self::sanitize_social_assets($sa);
        }
        return [];
    }
}
