<?php

/**
 * Main Plugin Class
 *
 * @package DIT_TrendStudio
 * @MODIFIED 2025-12-13 - Forked from SEO Article Generator, simplified for magazine content
 */

namespace DIT\TrendStudio\Core;

// Import sources and services from the correct namespaces.
use DIT\TrendStudio\Sources\Idea_Importer;
use DIT\TrendStudio\Sources\NewsAPI_Provider;
use DIT\TrendStudio\Sources\Social_Searcher_Provider;
use DIT\TrendStudio\Sources\RSS_Provider;
use DIT\TrendStudio\Infrastructure\Logger;
use DIT\TrendStudio\Infrastructure\Scheduler; // formerly Job_Handler
use DIT\TrendStudio\Admin\SettingsPage;        // formerly Admin_Menu
use DIT\TrendStudio\Admin\JobMonitor;          // formerly Briefing_Room
use DIT\TrendStudio\Integrations\Gemini\Client as AI_Client;
use DIT\TrendStudio\Content\TrendInterpreter;  // formerly Topic_Researcher
use DIT\TrendStudio\Services\Draft_Cleanup_Service;
use DIT\TrendStudio\Core\Bootstrap;
use DIT\TrendStudio\Error_Handler;
use DIT\TrendStudio\SEO\MetadataGenerator;
use DIT\TrendStudio\SEO\SchemaGenerator;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Main plugin controller class
 * Coordinates all plugin components using singleton pattern
 */
class Plugin
{
    /**
     * Single instance of the class
     *
     * @var Plugin
     */
    private static $instance = null;

    /**
     * Error handler instance
     *
     * @var Error_Handler
     */
    private $error_handler;

    /**
     * Logger instance
     *
     * @var Logger
     */
    protected $logger;

    /**
     * Admin menu instance
     *
     * @var SettingsPage
     */
    private $admin_menu;

    /**
     * Idea importer instance
     *
     * @var Idea_Importer
     */
    protected $idea_importer;

    /**
     * Job Handler instance
     *
     * @var Scheduler
     */
    protected $job_handler;

    /**
     * Briefing Room instance
     *
     * @var JobMonitor
     */
    private $briefing_room;

    /**
     * Get singleton instance
     *
     * @return Plugin
     */
    public static function get_instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Private constructor to prevent direct instantiation
     */
    private function __construct()
    {
        // Constructor intentionally left empty
        // Use init() method for initialization
    }

    /**
     * Initialize the plugin
     *
     * @return void
     */
    public function init()
    {
        // Initialize error handler and logger first
        $this->logger = new Logger();

        $this->error_handler = new Error_Handler();
        $this->error_handler->set_logger($this->logger);
        $this->error_handler->init();

        // Load text domain for translations
        add_action('init', array($this, 'load_textdomain'));

        // Register dit_idea CPT on init via Bootstrap. Installer is aliased for BC.
        add_action('init', array(Bootstrap::class, 'register_post_types'));

        // @MODIFIED 2026-06-01 - Run database upgrades on init so background cron/watchdog tasks also run them
        add_action('init', array(Bootstrap::class, 'upgrade'), 5);

        // @MODIFIED 2026-04-02 - Ensure queue table exists (run on every init)
        add_action('init', array(\DIT\TrendStudio\Database\Queue_Table::class, 'install'), 5);

        // @MODIFIED 2026-01-25 - Add custom cron schedules
        add_filter('cron_schedules', array($this, 'add_cron_intervals'));

        // Initialize source providers
        $this->init_source_providers();

        // Initialize admin components if in admin area
        if (is_admin()) {
            $this->init_admin();
        }

        // Initialize frontend
        $this->init_frontend();

        // @MODIFIED 2026-02-24 - Canonical SEO namespace (DIT\TrendStudio\SEO\*).
        new SchemaGenerator();
        // @MODIFIED 2026-01-13 - Initialize Rank Math Bridge
        // (new SEO\Rank_Math_Bridge())->init();

        // Initialize Job Handler
        $this->job_handler = new Scheduler($this->logger);

        // Register AJAX handlers
        $this->register_ajax_handlers();

        // Register REST API endpoints for Universal Plugin Dashboard (on rest_api_init)
        add_action('rest_api_init', [$this, 'register_rest_endpoints']);

        // @MODIFIED 2026-01-30 - Ensure schedule is initialized AFTER Action Scheduler is ready
        // Hook into init (priority 20) to ensure Action Scheduler has loaded
        add_action('init', array($this, 'ensure_schedule'), 20);

        // @MODIFIED 2026-06-01 - Ensure publish watchdog is registered (recovers missed-schedule posts)
        add_action('init', array($this, 'ensure_publish_watchdog'), 20);

        // @ADDED 2026-07-12 - OpenRouter free-model auto-sync (3-day recurring action + callback).
        add_action('init', array($this, 'ensure_openrouter_sync'), 20);
        add_action(
            \DIT\TrendStudio\Services\OpenRouterModelSync::ACTION_HOOK,
            array($this, 'run_openrouter_model_sync')
        );

        // @ADDED 2026-07-17 - OpenCode Zen free-model auto-sync (3-day recurring action + callback).
        add_action('init', array($this, 'ensure_opencode_sync'), 20);
        add_action(
            \DIT\TrendStudio\Services\OpenCodeZenModelSync::ACTION_HOOK,
            array($this, 'run_opencode_model_sync')
        );

        // Register auto-publish handler
        add_action('dit_ts_job_auto_published', array($this, 'handle_auto_publish'), 10, 3);

        // @MODIFIED 2026-02-09 - Self-healing: Schedule stuck post cleanup
        if (!wp_next_scheduled('dit_ts_cleanup_orphans')) {
            wp_schedule_event(time(), 'hourly', 'dit_ts_cleanup_orphans');
        }
        add_action('dit_ts_cleanup_orphans', array($this, 'cleanup_orphans'));

        // Immediate Cleanup Check from Admin (throttled)
        // Runs on every admin page load (once per 10 mins) to fix stuck posts
        add_action('admin_init', function () {
            if (current_user_can('manage_options') && !get_transient('dit_ts_cleanup_run_immediate')) {
                $this->cleanup_orphans();
                set_transient('dit_ts_cleanup_run_immediate', true, 600);
            }
        });

        // @MODIFIED 2026-02-28 - When a TrendsStudio-generated post is trashed/deleted, trash/delete its plugin-managed attachments.
        add_action('wp_trash_post', array($this, 'handle_generated_post_trashed'), 10, 1);
        add_action('untrash_post', array($this, 'handle_generated_post_untrashed'), 10, 1);
        add_action('before_delete_post', array($this, 'handle_generated_post_before_delete'), 10, 1);

        // @MODIFIED 2026-08-30 - 504 fix: background continuation handler for attachment
        // purges deferred by handle_generated_post_before_delete() when the per-request
        // budget is exhausted. Runs in Action Scheduler context, not the HTTP request.
        add_action('dit_ts_continue_attachment_purge', array($this, 'handle_continue_attachment_purge'), 10, 1);

        // @MODIFIED 2026-03-06 - Social Meta Cleanup
        (new \DIT\TrendStudio\Services\Social_Cleanup_Service())->init();

        // @MODIFIED 2026-09-10 - Link Whisper integration: idempotent backstop observer.
        // When a DIT-scheduled `future` post transitions to `publish` (publish watchdog or
        // manual editor click), apply LW links if auto_publish_job did not already do so.
        // The bridge's _dit_ts_lw_processed meta guard makes this safe to re-fire.
        add_action('future_to_publish', function ($post_id) {
            if (!is_numeric($post_id) || (int) $post_id <= 0) {
                return;
            }
            // Only touch DIT-generated posts.
            if (!get_post_meta((int) $post_id, '_dit_ts_scheduled', true)) {
                return;
            }
            if ($this->logger) {
                $this->logger->info('future_to_publish: LW observer triggered', [
                    'post_id' => (int) $post_id,
                    'class_exists' => class_exists('\\DIT\\TrendStudio\\Integrations\\LinkWhisper\\Link_Whisper_Bridge'),
                ]);
            }
            if (!class_exists('\\DIT\\TrendStudio\\Integrations\\LinkWhisper\\Link_Whisper_Bridge')) {
                if ($this->logger) {
                    $this->logger->info('future_to_publish: LW bridge class not found', ['post_id' => (int) $post_id]);
                }
                return;
            }
            try {
                if ($this->logger) {
                    $this->logger->info('future_to_publish: instantiating Link_Whisper_Bridge', ['post_id' => (int) $post_id]);
                }
                $bridge = new \DIT\TrendStudio\Integrations\LinkWhisper\Link_Whisper_Bridge($this->logger);
                if ($this->logger) {
                    $this->logger->info('future_to_publish: calling inject_for_post', ['post_id' => (int) $post_id]);
                }
                $bridge->inject_for_post((int) $post_id);
                if ($this->logger) {
                    $this->logger->info('future_to_publish: inject_for_post returned', ['post_id' => (int) $post_id]);
                }
            } catch (\Throwable $e) {
                if ($this->logger) {
                    $this->logger->warning('Link Whisper future_to_publish observer failed (non-fatal)', [
                        'post_id' => (int) $post_id,
                        'message' => $e->getMessage(),
                        'file' => $e->getFile(),
                        'line' => $e->getLine(),
                    ]);
                }
            }
        }, 10, 1);

        // @MODIFIED 2026-05-15 - Orphaned temp file cleanup (24h TTL)
        (new \DIT\TrendStudio\Services\Temp_File_Cleanup_Service($this->logger))->init();

        // @MODIFIED 2026-03-08 - Initialize Jetpack Social Integration
        $this->init_services();
    }

    /**
     * Services container
     *
     * @var array
     */
    private $services = [];

    /**
     * Initialize services
     *
     * @return void
     */
    private function init_services()
    {
        $generator = new \DIT\TrendStudio\Services\Collage_Generator($this->logger);
        $queue     = new \DIT\TrendStudio\Services\Social_Queue_Manager($generator, $this->logger);
        $social    = new \DIT\TrendStudio\Core\Social_Bootstrap($this->logger, $generator, $queue);
        $connector = new \DIT\TrendStudio\Integrations\BitSocial\Connector($queue);
        $settings  = new \DIT\TrendStudio\Admin\Drip_Settings_Page($queue);

        $social->init();
        $connector->init();
        
        if (is_admin()) {
            $settings->init();
        }

        $this->services['social'] = $social;
        $this->services['social_queue'] = $queue;
    }

    /**
     * Get a service by name
     *
     * @param string $name Service name
     * @return mixed|null
     */
    public function get_service(string $name)
    {
        return $this->services[$name] ?? null;
    }

    /**
     * Initialize source providers
     *
     * @since 1.0.0
     * @since 1.5.0 Added NewsAPI and Social Searcher providers
     * @return void
     */
    private function init_source_providers()
    {
        $this->idea_importer = new Idea_Importer($this->logger);

        // Register NewsAPI provider if API key is configured
        if (get_option('dit_ts_newsapi_key')) {
            $newsapi_provider = new NewsAPI_Provider($this->logger);
            $this->idea_importer->register_provider($newsapi_provider);
            $this->logger->info('NewsAPI provider registered');
        }

        // Register Social Searcher provider if API key is configured
        if (get_option('dit_ts_social_searcher_key')) {
            $social_provider = new Social_Searcher_Provider($this->logger);
            $this->idea_importer->register_provider($social_provider);
            $this->logger->info('Social Searcher provider registered');
        }

        // Register RSS provider if feeds are configured
        $rss_provider = new RSS_Provider($this->logger);
        if ($rss_provider->is_available()) {
            $this->idea_importer->register_provider($rss_provider);
            $this->logger->info('RSS provider registered');
        }
    }

    /**
     * Get idea importer instance
     *
     * @return Idea_Importer
     */
    public function get_idea_importer(): Idea_Importer
    {
        return $this->idea_importer;
    }

    /**
     * Get job handler instance
     *
     * @return \DIT\TrendStudio\Infrastructure\Scheduler
     */
    public function get_job_handler()
    {
        return $this->job_handler;
    }

    /**
     * Initialize admin components
     *
     * @return void
     */
private function init_admin()
    {
		$strategy = \DIT\TrendStudio\Infrastructure\AI_Provider_Factory::get_effective_strategy();
		$ai_client = \DIT\TrendStudio\Infrastructure\AI_Provider_Factory::create($strategy, $this->logger);

        $topic_researcher = new TrendInterpreter($ai_client, $this->logger);
        $topic_admin = new \DIT\TrendStudio\Admin\Topic_Research_Admin($topic_researcher, $this->logger, $strategy);

        $topic_admin->init();

        $this->admin_menu = new SettingsPage($this->logger, $this->idea_importer);
        $this->admin_menu->init();

        $this->briefing_room = new JobMonitor($this->logger);

        // @MODIFIED 2026-02-18 - Collage Admin
        $collage_admin = new \DIT\TrendStudio\Admin\Collage_Admin($this->logger);
        $collage_admin->init();
        $this->admin_menu->set_collage_admin($collage_admin);
    }

    /**
     * Initialize frontend components
     *
     * @return void
     */
    private function init_frontend()
    {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_styles'));
    }

    /**
     * Enqueue frontend styles
     *
     * @return void
     */
    /**
     * Get asset version for cache busting
     * 
     * Strategy:
     * - WP_DEBUG on: Use current timestamp (time()) to force reload on every refresh.
     * - WP_DEBUG off: Use file modification time (filemtime) so it only refreshes when file changes.
     * - Fallback: Use plugin version.
     *
     * @param string $relative_path Path relative to plugin root (e.g. 'assets/css/style.css')
     * @return string|int Version string or timestamp
     */
    public function get_asset_version(string $relative_path)
    {
        // If debug mode is on, always burst cache
        if (defined('WP_DEBUG') && WP_DEBUG) {
            return time();
        }

        $file_path = DIT_TS_PLUGIN_DIR . ltrim($relative_path, '/');

        if (file_exists($file_path)) {
            return filemtime($file_path);
        }

        return DIT_TS_VERSION;
    }

    /**
     * Enqueue frontend styles
     *
     * @return void
     */
    public function enqueue_frontend_styles()
    {
        $css_path = 'assets/css/dit-ts-article-styles.css';
        wp_enqueue_style(
            'dit-ts-article-styles',
            DIT_TS_PLUGIN_URL . $css_path,
            array(),
            $this->get_asset_version($css_path)
        );
    }

    public function ajax_get_campaign_stats()
    {
        // Simple permission check
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        $campaigns = json_decode(get_option('dit_ts_campaigns', '[]'), true);
        $stats = [];

        foreach ($campaigns as $c) {
            if (empty($c['id'])) continue;

            $next_run = 0;
            if (function_exists('as_next_scheduled_action')) {
                $next_run = as_next_scheduled_action('dit_ts_run_campaign', ['campaign_id' => $c['id']], 'dit_ts_campaigns');
            }

            $stats[$c['id']] = [
                'next_run_ts' => $next_run,
                'next_run_human' => $next_run ? human_time_diff($next_run) : 'Not Scheduled'
            ];
        }

        wp_send_json_success($stats);
    }

    /**
     * Register AJAX handlers
     *
     * @return void
     */
    private function register_ajax_handlers()
    {
        // Generation handlers
        add_action('wp_ajax_dit_ts_submit', array($this, 'ajax_submit_generation'));
        add_action('wp_ajax_dit_ts_status', array($this, 'ajax_check_status'));
        add_action('wp_ajax_dit_ts_preview', array($this, 'ajax_get_preview'));
        add_action('wp_ajax_dit_ts_publish', array($this, 'ajax_publish_article'));

        // Import handlers
        add_action('wp_ajax_dit_ts_import_ideas', array($this, 'ajax_import_ideas'));

        // Settings handlers
        add_action('wp_ajax_dit_ts_test_api', array($this, 'ajax_test_api'));

        // Admin AJAX for Settings
        add_action('wp_ajax_dit_ts_test_gemini', array($this, 'ajax_test_gemini'));

        // Multi-Campaign Handlers
        add_action('dit_ts_run_campaign', array($this, 'run_campaign_job'));
        add_action('wp_ajax_dit_ts_get_campaign_stats', array($this, 'ajax_get_campaign_stats'));
        add_action('wp_ajax_dit_ts_force_run_campaign', array($this, 'ajax_force_run_campaign'));

        // Frontend Shortcodes@MODIFIED 2026-01-25 - Clear stuck jobs
        add_action('wp_ajax_dit_ts_clear_stuck_jobs', array($this, 'ajax_clear_stuck_jobs'));
        // @MODIFIED 2026-01-27 - Clear ALL jobs
        add_action('wp_ajax_dit_ts_clear_all_jobs', array($this, 'ajax_clear_all_jobs'));

        // @MODIFIED 2026-02-24 - Manual Trash Purge (settings button)
        add_action('wp_ajax_dit_ts_purge_trash_now', array($this, 'ajax_purge_trash_now'));

        // @MODIFIED 2026-02-25 - Orphan Media Purge (settings button)
        add_action('wp_ajax_dit_ts_purge_orphan_media_now', array($this, 'ajax_purge_orphan_media_now'));

        // @MODIFIED 2026-02-25 - DANGER: Empty Trash (Global)
        add_action('wp_ajax_dit_ts_empty_trash_now', array($this, 'ajax_empty_trash_now'));

        // @MODIFIED 2026-01-29 - Force run job manually
        add_action('wp_ajax_dit_ts_force_run_job', array($this, 'ajax_force_run_job'));
        add_action('wp_ajax_dit_ts_cancel_job', array($this, 'ajax_cancel_job'));

        // @MODIFIED 2026-02-10 - Master AI Switch and Job Control
        add_action('wp_ajax_dit_ts_toggle_ai_automation', array($this, 'ajax_toggle_ai_automation'));
        add_action('wp_ajax_dit_ts_cancel_all_jobs', array($this, 'ajax_cancel_all_jobs'));

        // Cron schedules
        add_filter('cron_schedules', array($this, 'add_cron_intervals'));

        // Daily cleanup
        add_action('dit_ts_daily_cleanup', array($this, 'run_daily_cleanup'));
        if (!wp_next_scheduled('dit_ts_daily_cleanup')) {
            wp_schedule_event(time(), 'daily', 'dit_ts_daily_cleanup');
        }

        // Watchdog: clear/mark stuck jobs frequently
        add_action('dit_ts_job_watchdog', array($this, 'run_job_watchdog'));
        if (!wp_next_scheduled('dit_ts_job_watchdog')) {
            wp_schedule_event(time(), 'dit_ts_ten_minutes', 'dit_ts_job_watchdog');
        }
    }

    /**
     * Ensure import schedule exists and is valid
     * @MODIFIED 2026-01-30 - Completely rewritten for reliability
     * 
     * This method is atomic and always ensures the schedule is in the correct state.
     * It processes overdue actions and recreates the schedule if needed.
     *
     * @return void
     */
    public function ensure_schedule()
    {
        // Always register the handler
        add_action('dit_ts_scheduled_import', array($this, 'run_scheduled_import'));

        $schedule = get_option('dit_ts_import_schedule', 'daily');

        // Manual mode = no schedule
        if ('manual' === $schedule) {
            $this->clear_all_scheduled_imports();
            return;
        }

        // Determine interval
        switch ($schedule) {
            case 'every_15_mins':
                $interval = 15 * 60;
                break;
            case 'every_30_mins':
                $interval = 30 * 60;
                break;
            case 'hourly':
                $interval = HOUR_IN_SECONDS;
                break;
            case 'daily':
            default:
                $interval = DAY_IN_SECONDS;
                break;
        }

        // Calculate next run time
        // NOTE: Action Scheduler requires UTC timestamps
        // We must use WordPress functions to ensure proper timezone conversion
        $local_now = current_time('mysql');
        $local_next = date('Y-m-d H:i:s', strtotime($local_now) + 60);
        $next_run = mysql2date('U', get_gmt_from_date($local_next), false); // Convert local to GMT timestamp

        if ('daily' === $schedule) {
            $import_time = get_option('dit_ts_import_time', '02:00');
            $target_local = substr($local_now, 0, 10) . ' ' . $import_time . ':00';
            $next_run = mysql2date('U', get_gmt_from_date($target_local), false);

            // If that time has passed today, schedule for tomorrow
            if ($next_run <= mysql2date('U', get_gmt_from_date($local_now), false)) {
                $next_run += DAY_IN_SECONDS;
            }
        }

        // Use Action Scheduler if available
        if (class_exists('ActionScheduler') && function_exists('as_schedule_recurring_action')) {
            $this->ensure_action_scheduler_schedule($interval, $next_run);
        } else {
            // Fallback to WP Cron
            $this->ensure_wp_cron_schedule($schedule, $interval, $next_run);
        }
    }

    /**
     * Ensure Action Scheduler has a valid recurring action
     * @MODIFIED 2026-01-30 - New atomic method
     *
     * @param int $interval Interval in seconds
     * @param int $next_run Next run timestamp
     * @return void
     */
    private function ensure_action_scheduler_schedule($interval, $next_run)
    {
        if (!function_exists('as_get_scheduled_actions')) {
            return;
        }

        // Get all pending actions
        $pending = as_get_scheduled_actions(array(
            'hook' => 'dit_ts_scheduled_import',
            'status' => 'pending',
            'per_page' => 10,
        ));

        // Process overdue actions and check for valid future action
        $has_valid_future_action = false;
        // NOTE: Action Scheduler stores UTC timestamps, so we compare with time() not current_time()
        $now = time();

        foreach ($pending as $action) {
            $scheduled_time = $action->get_schedule()->get_date()->getTimestamp();

            if ($scheduled_time < $now) {
                // Overdue - will be processed by queue runner
                continue;
            } else {
                // Valid future action exists
                $has_valid_future_action = true;
                break;
            }
        }

        // Trigger queue runner if there are overdue actions
        if (count($pending) > 0 && !$has_valid_future_action) {
            if (class_exists('ActionScheduler_QueueRunner')) {
                $runner = \ActionScheduler_QueueRunner::instance();
                $runner->run();
            }
        }

        // Create recurring action if none exists or if we need to reschedule
        if (!$has_valid_future_action) {
            try {
                as_schedule_recurring_action($next_run, $interval, 'dit_ts_scheduled_import', array(), '');
            } catch (\Exception $e) {
                $this->logger->error("Action Scheduler scheduling failed: " . $e->getMessage());
            }
        }
    }

    /**
     * Ensure WP Cron has a valid scheduled event
     * @MODIFIED 2026-01-30 - New atomic method
     *
     * @param string $schedule Schedule name
     * @param int $interval Interval in seconds  
     * @param int $next_run Next run timestamp
     * @return void
     */
    private function ensure_wp_cron_schedule($schedule, $interval, $next_run)
    {
        $timestamp = wp_next_scheduled('dit_ts_scheduled_import');

        // If no schedule exists or it's in the past, create new one
        if (!$timestamp || $timestamp < time()) {
            if ($timestamp) {
                wp_unschedule_event($timestamp, 'dit_ts_scheduled_import');
            }
            wp_schedule_event($next_run, $schedule, 'dit_ts_scheduled_import');
        }
    }

    /**
     * Ensure the publish watchdog is registered.
     *
     * The watchdog fires every 2 minutes via Action Scheduler. It scans for plugin-generated
     * posts (`_dit_ts_scheduled = '1'`) that are still in `future` status past their
     * `post_date_gmt`, and force-publishes them. This is the recovery layer for the
     * WordPress "Missed schedule" condition.
     *
     * Action Scheduler is used (not WP-Cron) because it survives on hosts that disable
     * WP-Cron (WPEngine, Kinsta, Pressable) and because its queue is persistent in the
     * database — it does not require a site visit to fire.
     *
     * @MODIFIED 2026-06-01 - Added publish watchdog registration.
     * @return void
     */
    public function ensure_publish_watchdog()
    {
        if (!function_exists('as_schedule_recurring_action') || !function_exists('as_next_scheduled_action')) {
            // Action Scheduler not available — the plugin's job-handler queue runner
            // (used elsewhere) also falls back to WP-Cron, so we mirror that behaviour
            // here. The user's server-level cron (every 5 min) will still trigger wp-cron.php
            // and WordPress's own publish_future_post. Our watchdog is a strict upgrade.
            return;
        }

        $hook     = 'dit_ts_publish_due_posts';
        $interval = 120; // 2 minutes — strict upgrade over the user's 5-min server cron
        $group    = 'dit_ts_publish_watchdog';

        $next = as_next_scheduled_action($hook, array(), $group);
        if ($next === false) {
            try {
                as_schedule_recurring_action(time() + 60, $interval, $hook, array(), $group);
                $this->logger->info("Publish Watchdog: registered recurring action every {$interval}s.");
            } catch (\Exception $e) {
                $this->logger->error('Publish Watchdog: scheduling failed: ' . $e->getMessage());
            }
        }
    }

    /**
     * Ensure the OpenRouter free-model auto-sync is registered.
     *
     * Schedules a 3-day recurring Action Scheduler task only when (a) Action
     * Scheduler is available AND (b) a custom provider whose api_url contains
     * "openrouter.ai" is configured. Skips scheduling silently otherwise — the
     * cron callback would be a no-op anyway, and we don't want a zombie action
     * polluting the queue.
     *
     * @ADDED 2026-07-12 — OpenRouter free-model sync (universal plan §3).
     * @return void
     */
    public function ensure_openrouter_sync()
    {
        if (!function_exists('as_schedule_recurring_action') || !function_exists('as_next_scheduled_action')) {
            return;
        }

        if (!class_exists(\DIT\TrendStudio\Services\OpenRouterModelSync::class)) {
            return;
        }

        if (!\DIT\TrendStudio\Services\OpenRouterModelSync::has_openrouter_provider()) {
            return;
        }

        $hook     = \DIT\TrendStudio\Services\OpenRouterModelSync::ACTION_HOOK;
        $interval = 3 * DAY_IN_SECONDS; // 259200s per spec
        $group    = \DIT\TrendStudio\Services\OpenRouterModelSync::AS_GROUP;

        if (as_next_scheduled_action($hook, array(), $group) === false) {
            try {
                as_schedule_recurring_action(time() + $interval, $interval, $hook, array(), $group);
                $this->logger->info("OpenRouter sync: registered recurring action every {$interval}s.");
            } catch (\Exception $e) {
                $this->logger->error('OpenRouter sync: scheduling failed: ' . $e->getMessage());
            }
        }
    }

    /**
     * Action Scheduler callback for the OpenRouter free-model sync.
     *
     * Mirrors `ensure_publish_watchdog` runtime semantics:
     *  - Uses the master AI automation switch as the "pipeline paused" gate.
     *  - On failure that is NOT "no provider found", logs a warning (the sync()
     *    method itself logs successes and the silent no-op short-circuit).
     *
     * @ADDED 2026-07-12 — OpenRouter free-model sync (universal plan §3).
     * @return void
     */
    public function run_openrouter_model_sync()
    {
        // Master switch — matches the "pipeline paused" semantics used in
        // process_pending_queue() and the campaign runner. Manual sync via AJAX
        // bypasses this gate (handled inside the AJAX handler).
        $is_automation_enabled = get_option('dit_ts_enable_ai_automation', '1');
        if (!$is_automation_enabled) {
            $this->logger->info('OpenRouter sync: AI automation globally disabled, skipping cron sync.');
            return;
        }

        try {
            $result = \DIT\TrendStudio\Services\OpenRouterModelSync::sync();
        } catch (\Throwable $e) {
            $this->logger->error('OpenRouter sync: unhandled exception.', array(
                'error' => $e->getMessage(),
            ));
            return;
        }

        // Failures excepted by `success=false` from sync() are already logged
        // inside the service; we surface here only the unexceptional ones.
        if (!empty($result) && empty($result['success'])) {
            $msg = $result['message'] ?? '';
            if ($msg !== __('No OpenRouter custom provider found.', 'dit-trend-content-studio')) {
                $this->logger->warning('OpenRouter sync: cron run reported failure.', array(
                    'message' => $msg,
                    'source'  => 'weekly_cron',
                ));
            }
        }
    }

    /**
     * OpenCode Zen free-model auto-sync scheduler.
     *
     * Only registers a recurring Action Scheduler task when an OpenCode Zen
     * provider is configured. Skips scheduling silently otherwise.
     *
     * @ADDED 2026-07-17 — OpenCode Zen free-model sync (parallel to OpenRouter).
     * @return void
     */
    public function ensure_opencode_sync()
    {
        if (!function_exists('as_schedule_recurring_action') || !function_exists('as_next_scheduled_action')) {
            return;
        }

        if (!class_exists(\DIT\TrendStudio\Services\OpenCodeZenModelSync::class)) {
            return;
        }

        if (!\DIT\TrendStudio\Services\OpenCodeZenModelSync::has_zen_provider()) {
            return;
        }

        $hook     = \DIT\TrendStudio\Services\OpenCodeZenModelSync::ACTION_HOOK;
        $interval = 3 * DAY_IN_SECONDS;
        $group    = \DIT\TrendStudio\Services\OpenCodeZenModelSync::AS_GROUP;

        if (as_next_scheduled_action($hook, array(), $group) === false) {
            try {
                as_schedule_recurring_action(time() + $interval, $interval, $hook, array(), $group);
                $this->logger->info("OpenCode Zen sync: registered recurring action every {$interval}s.");
            } catch (\Exception $e) {
                $this->logger->error('OpenCode Zen sync: scheduling failed: ' . $e->getMessage());
            }
        }
    }

    /**
     * Action Scheduler callback for the OpenCode Zen free-model sync.
     *
     * Mirrors `run_openrouter_model_sync` runtime semantics:
     *  - Uses the master AI automation switch as the "pipeline paused" gate.
     *  - On failure that is NOT "no provider found", logs a warning.
     *
     * @ADDED 2026-07-17 — OpenCode Zen free-model sync (parallel to OpenRouter).
     * @return void
     */
    public function run_opencode_model_sync()
    {
        $is_automation_enabled = get_option('dit_ts_enable_ai_automation', '1');
        if (!$is_automation_enabled) {
            $this->logger->info('OpenCode Zen sync: AI automation globally disabled, skipping cron sync.');
            return;
        }

        try {
            $result = \DIT\TrendStudio\Services\OpenCodeZenModelSync::sync();
        } catch (\Throwable $e) {
            $this->logger->error('OpenCode Zen sync: unhandled exception.', array(
                'error' => $e->getMessage(),
            ));
            return;
        }

        if (!empty($result) && empty($result['success'])) {
            $msg = $result['message'] ?? '';
            if ($msg !== __('No OpenCode Zen custom provider found (URL must contain opencode.ai).', 'dit-trend-content-studio')) {
                $this->logger->warning('OpenCode Zen sync: cron run reported failure.', array(
                    'message' => $msg,
                    'source'  => 'weekly_cron',
                ));
            }
        }
    }

    /**
     * Public wrapper used by admin/actions to (re)schedule imports.
     *
     * @param bool $force Whether to clear and rebuild schedules.
     */
    public function reschedule_imports($force = true): void
    {
        $this->schedule_imports((bool) $force);
    }

    private function schedule_imports(bool $force = false): void
    {
        if ($force) {
            $this->clear_all_scheduled_imports();
        }
        $this->ensure_schedule();
    }

    /**
     * Clear all scheduled imports (both Action Scheduler and WP Cron)
     * @MODIFIED 2026-01-30 - Helper method to ensure complete cleanup
     *
     * @return void
     */
    private function clear_all_scheduled_imports()
    {
        // Clear Action Scheduler
        if (function_exists('as_unschedule_all_actions')) {
            as_unschedule_all_actions('dit_ts_scheduled_import');
        }

        // Clear WP Cron
        $timestamp = wp_next_scheduled('dit_ts_scheduled_import');
        if ($timestamp) {
            wp_unschedule_event($timestamp, 'dit_ts_scheduled_import');
        }
    }

    /**
     * Run scheduled import
     *
     * @return void
     */
    public function run_scheduled_import()
    {
        $this->logger->info('Running scheduled idea import');
        $results = $this->idea_importer->import_all();
        $this->logger->info('Scheduled import completed', $results);

        // @MODIFIED 2026-01-25 - Auto-process pending ideas (Drafts/Inbox)
        // Strictly serial processing: 1 at a time, with checks inside
        $this->process_pending_queue(1);
    }

    /**
     * Process pending ideas (Auto-Generation)
     * @since 2.0.0
     *
     * @param int $limit Max items to process
     * @param bool $bypass_cooldown Force process even if cooldown active (Manual trigger)
     * @return int Number of jobs started
     */
    public function process_pending_queue(int $limit = 1, bool $bypass_cooldown = false)
    {
        // 0. Auto-recover stuck jobs (Watchdog)
        // If a job takes > 10 mins (600s), it's likely stuck. Retry or fail.
        // @MODIFIED 2026-01-29 - Reduced timeout to 5 mins
        $this->job_handler->clear_stuck_jobs(300);

        // @MODIFIED 2026-05-08 - Also detect orphaned pending jobs stuck in quota-pause loops.
        // Pending jobs older than 2 hours with no near-term Action Scheduler action are marked failed.
        $this->job_handler->clear_stale_pending_jobs(7200);

        // @MODIFIED 2026-02-10 - Master AI Switch Check
        $is_automation_enabled = get_option('dit_ts_enable_ai_automation', '1');
        if (!$is_automation_enabled) {
            $this->logger->info('Auto-Process: AI Automation is globally DISABLED. Skipping.');
            return 0;
        }

        // @MODIFIED 2026-02-12 - Removed Global Gemini Quota Pause Check
        // Jobs now decide based on their own effective strategy/provider inside Scheduler::process_job().

        // 1. Check for running jobs vs Worker Limit
        $worker_limit = (int) get_option('dit_ts_worker_limit', 1);
        $running_count = $this->job_handler->get_running_jobs_count();

        if ($running_count >= $worker_limit) {
            $this->logger->info(sprintf('Auto-Process: Worker limit reached (%d/%d). Skipping new schedule.', $running_count, $worker_limit));
            return 0;
        }

        $available_slots = $worker_limit - $running_count;
        $this->logger->info(sprintf('Auto-Process: %d workers active. %d slots available.', $running_count, $available_slots));

        // Adjust limit to fit available slots
        if ($limit > $available_slots) {
            $limit = $available_slots;
        }

        // 2. Check Cooldown after last completion
        if (!$bypass_cooldown) {
            $last_completion = get_option('dit_ts_last_job_completion', 0);
            $cooldown_seconds = 5 * 60; // @MODIFIED 2026-04-26 - Reduced from 20 min to 5 min to prevent multi-campaign starvation
            $time_since = time() - $last_completion;

            if ($time_since < $cooldown_seconds) {
                $mins_left = ceil(($cooldown_seconds - $time_since) / 60);
                $this->logger->info(sprintf('Auto-Process: Cooldown active. %d mins remaining.', $mins_left));
                return 0;
            }
        }

        // @MODIFIED 2026-02-08 - Multi-Campaign Support
        // Load campaigns or use default legacy fallback
        $campaigns_json = get_option('dit_ts_campaigns', '[]');
        $campaigns = json_decode($campaigns_json, true);

        if (empty($campaigns) || !is_array($campaigns)) {
            $this->logger->info('Auto-Process: No campaigns configured. Using default legacy settings.');
            $campaigns = array(
                array(
                    'name' => 'Default',
                    'category' => null, // Use global setting (null triggers fallback in Importer)
                    'vertical' => null, // Use global setting (handled inside loop)
                    'active' => true
                )
            );
        }

        // @MODIFIED 2026-01-31 - Clean HTML before sending to AI to remove scripts, ads, malformed markup
        $cleaner = new \DIT\TrendStudio\Services\Content_Cleaner();

        $total_started = 0;

        foreach ($campaigns as $campaign) {
            if ($total_started >= $limit) {
                break;
            }

            if (empty($campaign['active'])) {
                continue;
            }

            // @MODIFIED 2026-02-26 - Strategy/Provider-aware quota pause
            // If the provider is paused (e.g. Gemini RPD exhausted), do NOT schedule new jobs.
		$strategy = (string) (!empty($campaign['strategy']) ? $campaign['strategy'] : get_option('dit_ts_ai_strategy', 'gemini'));
		$provider = \DIT\TrendStudio\Infrastructure\AI_Provider_Factory::strategy_to_provider($strategy);

		$provider_pause = false;
		$pause_until = 0;
		$reason = '';

		if (class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Pause_Manager')) {
			$provider_pause = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::is_paused($provider);
			$pause_until = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::get_pause_until($provider);
			$reason = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::get_reason($provider);
		}



		if ($provider_pause) {
			// @MODIFIED 2026-07-04 - Cross-Provider Fallback on Pause
			// When the primary provider is paused, check if a fallback provider is available.
			$fallback = \DIT\TrendStudio\Infrastructure\Scheduler::resolve_first_available_fallback($strategy, []);

			if ($fallback !== null) {
				// Override strategy for this campaign's jobs to use the fallback provider.
				$strategy = $fallback['strategy'];
				$provider = $fallback['strategy']; // For logging
				$campaign['strategy'] = $fallback['strategy'];
				if ($fallback['strategy'] === 'custom') {
					$campaign['custom_provider_id'] = $fallback['provider_id'];
				} else {
					unset($campaign['custom_provider_id']);
				}
				$this->logger->info(sprintf(
					'Auto-Process [%s]: Primary provider paused. Using fallback provider %s (strategy: %s, provider_id: %s).',
					$campaign['name'],
					$fallback['label'],
					$fallback['strategy'],
					$fallback['provider_id']
				));
				// Fall through — campaign proceeds with fallback strategy.
			} else {
				// No available fallback — skip as before.
				$until_str = '';
				if ($pause_until > 0 && class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Reset_Calculator')) {
					$until_str = \DIT\TrendStudio\Infrastructure\Quota_Reset_Calculator::format_in_wp_tz($pause_until);
				}
				$this->logger->info(sprintf(
					'Auto-Process [%s]: Provider pause active (%s). Reason=%s. RetryAfter=%s. No fallback available. Skipping scheduling.',
					$campaign['name'],
					$provider,
					$reason !== '' ? $reason : 'unknown',
					$until_str !== '' ? $until_str : 'n/a'
				));
				continue;
			}
		}

            $category_filter = !empty($campaign['category']) ? $campaign['category'] : null;

            // Fetch pending ideas for this campaign
            $pending = $this->idea_importer->get_pending_ideas($limit - $total_started, $category_filter);

            if (empty($pending)) {
                $this->logger->info(sprintf('Auto-Process [%s]: No pending ideas found.', $campaign['name']));
                continue;
            }

            $this->logger->info(sprintf('Auto-Process [%s]: Found %d pending ideas. Starting generation...', $campaign['name'], count($pending)));

            foreach ($pending as $post) {
                try {
                    // Clean the HTML to remove scripts, ads, tracking pixels, malformed markup
                    // While preserving legitimate media (images, iframes, social embeds)
                    $clean_content = $cleaner->clean($post->post_content);

                    // Determine Vertical
                    // 1. Campaign Override
                    // 2. Dynamic Detection
                    // 3. Global Default
                    // @MODIFIED 2026-02-13 - Fixed persona mixup: Use '_pk' suffix to match PromptBlueprint keys
                    $target_vertical = isset($campaign['vertical']) ? $campaign['vertical'] : null;

                    if (empty($target_vertical)) {
                        // Default Dynamic Logic
                        if (has_category('fashion', $post) || has_category('style', $post)) {
                            $target_vertical = 'fashion_pk';
                        } elseif (has_category('beauty', $post)) {
                            $target_vertical = 'beauty';
                        } else {
                            $target_vertical = get_option('dit_ts_content_vertical', 'showbiz_pk');
                        }
                    }

                    // Construct input data from post
		$input_data = array(
			'idea_id' => $post->ID,
			'idea_title' => $post->post_title,
			'idea_text' => $clean_content,
			'category' => $category_filter ?: '',
			'dest_category' => $campaign['dest_category'] ?? '',
			'tags' => '',
			'campaign_tags' => $campaign['tags'] ?? '',
			'vertical' => $target_vertical,
			'search_intent' => get_post_meta($post->ID, '_dit_search_intent', true) ?: 'news',
			'editorial_angle' => 'neutral',
			'is_auto_process' => true,
			'publish_status' => $campaign['publish_status'] ?? 'publish',
            'strategy_override' => !empty($campaign['strategy']) ? $campaign['strategy'] : null,
            'custom_provider_id' => !empty($campaign['custom_provider_id']) ? sanitize_key($campaign['custom_provider_id']) : '',
            'custom_model_id' => !empty($campaign['custom_model_id']) ? sanitize_text_field($campaign['custom_model_id']) : '',
            'cross_provider_fallback' => !empty($campaign['cross_provider_fallback']),
        );

                    // If it's a dit_idea, we might have source URL in meta
                    $source_url = get_post_meta($post->ID, '_dit_ts_source_url', true);
                    if ($source_url) {
                        $input_data['source_urls'] = $source_url;
                    }

                // @MODIFIED 2026-04-26 - Set _dit_ts_generated='queued' before scheduling.
                // 'queued' prevents duplicate pickup by other campaigns (NOT EXISTS won't match),
                // but is distinct from 'processing' (set in Scheduler::process_job when job actually runs).
                // This replaces the old 'processing' lock which was confusing because it implied the
                // job was actively running when it was just waiting in the Action Scheduler queue.
                update_post_meta($post->ID, '_dit_ts_generated', 'queued');
                update_post_meta($post->ID, '_dit_ts_flag_set_at', time());

            // Schedule Job
                    // @MODIFIED 2026-03-01 - User Author ID from Campaign, fallback to post author, else 1
                    $user_id = !empty($campaign['author']) ? (int) $campaign['author'] : ($post->post_author ?: 1);
                    $job_id = $this->job_handler->schedule_generation($input_data, $user_id);

                    $this->logger->info(sprintf('Auto-Process [%s]: Scheduled Job %d for Idea %d (Vertical: %s)', $campaign['name'], $job_id, $post->ID, $target_vertical));

                    $total_started++;

                    if ($total_started >= $limit) {
                        break 2; // Break both loops
                    }
                } catch (\Exception $e) {
                    $this->logger->error(sprintf('Auto-Process Failed for Idea %d: %s', $post->ID, $e->getMessage()));
                }
            }
        }

        return $total_started;
    }

    /**
     * Clear stuck 'processing' flags on source posts (Self-Healing)
     * @since 2.1.8
     */
    public function cleanup_orphans()
    {
        // @MODIFIED 2026-05-08 - Removed blanket has_running_jobs() guard.
        // The per-idea active-job check below (lines ~919-928) already prevents wiping
        // flags that are legitimately owned by a running job. The blanket guard caused
        // cleanup to NEVER run in systems with continuous job activity, leaving orphans
        // permanently deadlocked. The per-idea check is the correct granularity.

        // Find posts stuck in 'processing' OR 'queued' state
        // @MODIFIED 2026-04-26 - Also reset 'queued' posts whose jobs never reached process_job()
        // @MODIFIED 2026-05-05 - Finding 5: Also reset 'failed' state so source drafts from
        // permanently-failed jobs become visible to the Idea Importer again. Without this,
        // drafts whose jobs hit update_job_status('failed') stay invisible indefinitely because
        // the Idea Importer queries NOT EXISTS and 'failed' is not a recognised recoverable value.
    $args = [
        'post_type' => ['post', 'dit_idea'],
        'meta_query' => [
            'relation' => 'AND',
            [
                'key' => '_dit_ts_generated',
                'value' => ['processing', 'queued', 'failed'],
                'compare' => 'IN'
            ],
            // @MODIFIED 2026-05-08 - Exclude Roman Urdu–flagged posts from self-healing reset.
            // Without this, the language gate's _dit_ts_generated='failed' gets reset by
            // self-healing, causing the Idea Importer to re-pick the same idea → same
            // fallback model writes Roman Urdu again → infinite loop.
            [
                'key' => '_dit_ts_language_flag',
                'compare' => 'NOT EXISTS'
            ],
        ],
        'posts_per_page' => 50, // Limit to 50 at a time to avoid timeout
        'fields' => 'ids',
        'post_status' => 'any'
    ];

        $posts = get_posts($args);

        if (!empty($posts)) {
            // @MODIFIED 2026-05-06 - Check for active job rows before wiping flags.
            // A 'queued' post may have a pending/scheduled job; wiping its flag causes duplicate pickup.
            global $wpdb;
            $jobs_table = $wpdb->prefix . 'dit_ts_jobs';
            $active_states = "'pending','processing','briefing','researching','outlining','drafting'";

            // @MODIFIED 2026-06-01 - Dynamic self-healing safety: check if updated_at exists once before loop
            $has_updated_at = $wpdb->get_results("SHOW COLUMNS FROM {$jobs_table} LIKE 'updated_at'");
            $date_expr = !empty($has_updated_at) ? '(updated_at IS NULL OR updated_at >= %s)' : '(created_at IS NULL OR created_at >= %s)';

        $reset_count = 0;
        foreach ($posts as $pid) {
            // Only clear the flag if no RECENTLY active job row exists for this idea_id.
            // @MODIFIED 2026-05-08 - Added age check: jobs stuck in processing/pending for
            // > 30 minutes without an updated_at heartbeat are considered stale/zombie and
            // should NOT block the self-healing reset. This prevents 16+ zombie jobs from
            // permanently blocking orphan-flag cleanup (as seen in logs where Self-Healing
            // skipped all 16 ideas because has_active_job trusted stale rows).
            $stale_cutoff = gmdate('Y-m-d H:i:s', time() - 1800);
            $has_active_job = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$jobs_table}
                WHERE status IN ({$active_states})
                AND input_data LIKE %s
                AND {$date_expr}
                LIMIT 1",
                '%' . $wpdb->esc_like('"idea_id":' . ((int) $pid)) . '%',
                $stale_cutoff
            ));

            if ((int) $has_active_job > 0) {
                    $flag = get_post_meta($pid, '_dit_ts_generated', true);
                    $this->logger->info("Self-Healing: Skipped Idea {$pid} — active job exists (flag='{$flag}')");
                    continue;
                }

                // @MODIFIED 2026-05-08 - Age-based guard: only reset flags older than 30 minutes.
                // Prevents wiping a flag that was just set seconds ago by a concurrent schedule_generation().
                $flag_set_at = (int) get_post_meta($pid, '_dit_ts_flag_set_at', true);
                if ($flag_set_at > 0 && (time() - $flag_set_at) < 1800) {
                    continue;
                }

                delete_post_meta($pid, '_dit_ts_generated');
                delete_post_meta($pid, '_dit_ts_flag_set_at');
                $reset_count++;
            }

            if ($reset_count > 0) {
                $this->logger->info("Self-Healing: Reset {$reset_count} orphaned post(s) out of " . count($posts) . " found.");
            }
        }
    }

    /**
     * AJAX: Force run a campaign manually
     * @since 2.1.0
     * 
     * @return void
     */
    public function ajax_force_run_campaign()
    {
        // Check capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        // Verify nonce
        // @MODIFIED 2026-02-08 - Fixed nonce mismatch (was 'dit_ts_admin_nonce', now matches JS localized 'dit_ts_nonce')
        $nonce = isset($_POST['nonce']) ? $_POST['nonce'] : '';
        if (!wp_verify_nonce($nonce, 'dit_ts_nonce')) {
            wp_send_json_error('Invalid nonce');
        }

        $campaign_id = isset($_POST['campaign_id']) ? sanitize_text_field($_POST['campaign_id']) : '';

        if (empty($campaign_id)) {
            wp_send_json_error('Mission Campaign ID');
        }

        // @MODIFIED 2026-02-12 - Resolve Campaign Strategy before blocking
        $campaigns = json_decode(get_option('dit_ts_campaigns', '[]'), true);
		$strategy = get_option('dit_ts_ai_strategy', 'gemini');
        foreach ($campaigns as $c) {
            if (isset($c['id']) && $c['id'] === $campaign_id) {
                $strategy = (string) (!empty($c['strategy']) ? $c['strategy'] : $strategy);
                break;
            }
        }

 $provider = \DIT\TrendStudio\Infrastructure\AI_Provider_Factory::strategy_to_provider($strategy);

 $paused = false;
 $until = 0;
 $reason = '';
 if (class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Pause_Manager')) {
 $paused = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::is_paused($provider);
 $until = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::get_pause_until($provider);
 $reason = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::get_reason($provider);
 }

 if ($paused) {
            // @MODIFIED 2026-07-04 - Cross-Provider Fallback on Pause
            // When the primary provider is paused, check if a fallback provider is available.
            $fallback = \DIT\TrendStudio\Infrastructure\Scheduler::resolve_first_available_fallback($strategy, []);

            if ($fallback !== null) {
                // Override strategy for this campaign to use the fallback provider.
                $strategy = $fallback['strategy'];
                $provider = $fallback['strategy']; // For logging
                $campaign['strategy'] = $fallback['strategy'];
                if ($fallback['strategy'] === 'custom') {
                    $campaign['custom_provider_id'] = $fallback['provider_id'];
                } else {
                    unset($campaign['custom_provider_id']);
                }
                // Note: We don't persist campaign changes here — this is a one-time manual trigger.
                // The run_campaign_job() method will use the overridden strategy from $campaign.
                $this->logger->info(sprintf(
                    'Force Run Campaign: Primary provider paused. Using fallback provider %s (strategy: %s, provider_id: %s).',
                    $fallback['label'],
                    $fallback['strategy'],
                    $fallback['provider_id']
                ));
                // Fall through — campaign proceeds with fallback strategy.
            } else {
                // No available fallback — return error as before.
                $until_str = '';
                if ($until > 0 && class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Reset_Calculator')) {
                    $until_str = \DIT\TrendStudio\Infrastructure\Quota_Reset_Calculator::format_in_wp_tz((int) $until);
                }

                wp_send_json_error(array(
                    'message' => sprintf(
                        'Provider pause active (%s). Reason=%s. RetryAfter=%s. No fallback providers available. Configure cross-provider fallback in Settings.',
                        $provider,
                        $reason !== '' ? $reason : 'quota',
                        $until_str !== '' ? $until_str : 'n/a'
                    )
                ));
            }
        }

        // Trigger Run
        $this->run_campaign_job($campaign_id);

        wp_send_json_success('Job Triggered');
    }

    /**
     * Run a single campaign job (Triggered by Action Scheduler)
     * @since 2.1.0
     * 
     * @param string|array $campaign_id
     * @return void
     */
    public function run_campaign_job($campaign_id)
    {
        // Check if passed as array (Action Scheduler sometimes passes args array) or single var
        if (is_array($campaign_id) && isset($campaign_id['campaign_id'])) {
            $campaign_id = $campaign_id['campaign_id'];
        }

        $this->logger->info("Action Scheduler: Triggered run_campaign_job for ID: $campaign_id");

        // Load Campaign Config
        $campaigns = json_decode(get_option('dit_ts_campaigns', '[]'), true);
        $campaign = null;

        foreach ($campaigns as $c) {
            if (isset($c['id']) && $c['id'] === $campaign_id) {
                $campaign = $c;
                break;
            }
        }


        if (!$campaign || empty($campaign['active'])) {
            // @MODIFIED 2026-02-08 - Enhanced logging for troubleshooting campaign ID issues
            if (strpos($campaign_id, 'new_') === 0) {
                $this->logger->error("Action Scheduler: Campaign $campaign_id uses temporary ID! This should have been replaced on save. Check SettingsPage.php ID replacement logic.");
            } else {
                $this->logger->info("Action Scheduler: Campaign $campaign_id not found or inactive.");
            }
            return;
        }

        // 1. Master AI Switch Check (Emergency Stop)
        // @MODIFIED 2026-02-11 - Prevent scheduling when automation is disabled
        // @MODIFIED 2026-02-11 - Prevent scheduling when automation is disabled
        $is_automation_enabled = get_option('dit_ts_enable_ai_automation', '1');
        if (!$is_automation_enabled) {
            $this->logger->info("Action Scheduler: Aborted run_campaign_job for $campaign_id. AI Automation is globally DISABLED.");
            return;
        }

$strategy = (string) (!empty($campaign['strategy']) ? $campaign['strategy'] : get_option('dit_ts_ai_strategy', 'gemini'));
		$provider = \DIT\TrendStudio\Infrastructure\AI_Provider_Factory::strategy_to_provider($strategy);

		$paused = false;
		$until = 0;
		$reason = '';
		if (class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Pause_Manager')) {
			$paused = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::is_paused($provider);
			$until = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::get_pause_until($provider);
			$reason = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::get_reason($provider);
		}

		if ($paused) {
            // @MODIFIED 2026-07-04 - Cross-Provider Fallback on Pause
            // When the primary provider is paused, check if a fallback provider is available.
            $fallback = \DIT\TrendStudio\Infrastructure\Scheduler::resolve_first_available_fallback($strategy, []);

            if ($fallback !== null) {
                // Override strategy for this campaign's jobs to use the fallback provider.
                $strategy = $fallback['strategy'];
                $provider = $fallback['strategy']; // For logging
                $campaign['strategy'] = $fallback['strategy'];
                if ($fallback['strategy'] === 'custom') {
                    $campaign['custom_provider_id'] = $fallback['provider_id'];
                } else {
                    unset($campaign['custom_provider_id']);
                }
                $this->logger->info(sprintf(
                    'Action Scheduler: Primary provider paused for campaign %s. Using fallback provider %s (strategy: %s, provider_id: %s).',
                    $campaign_id,
                    $fallback['label'],
                    $fallback['strategy'],
                    $fallback['provider_id']
                ));
                // Fall through — campaign proceeds with fallback strategy.
            } else {
                // No available fallback — abort as before.
                $until_str = '';
                if ($until > 0 && class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Reset_Calculator')) {
                    $until_str = \DIT\TrendStudio\Infrastructure\Quota_Reset_Calculator::format_in_wp_tz((int) $until);
                }
                $this->logger->info(sprintf(
                    'Action Scheduler: Aborted run_campaign_job for %s. Provider pause active (%s). Reason=%s. RetryAfter=%s. No fallback available.',
                    $campaign_id,
                    $provider,
                    $reason !== '' ? $reason : 'quota',
                    $until_str !== '' ? $until_str : 'n/a'
                ));
                return;
            }
        }

        // Logic similar to process_pending_queue but strictly scoped to this campaign
        $limit = 1; // Strict batch size for stability

        // 1. Recover Stuck Jobs
        $this->job_handler->clear_stuck_jobs(300);
        $this->job_handler->clear_stale_pending_jobs(7200);

        // 2. Check Running
        // @MODIFIED 2026-02-10 - Use updated robust check (DB + Atomic Lock)
        // @MODIFIED 2026-02-22 - Fixed Bug: Pass false to exclude 'pending' status from busy check.
        // Pending jobs wait for the 20-min gap; they are not active and shouldn't block recovery.
        // @MODIFIED 2026-05-05 - Finding 7: Instead of silently skipping (which causes the recurring
        // Action Scheduler interval to drift), schedule a one-shot catch-up in 5 minutes so this
        // campaign is retried promptly once the running job finishes.
        if ($this->job_handler->has_running_jobs(0, false)) {
            $this->logger->info("Action Scheduler: System busy. Scheduling catch-up for $campaign_id in 5 minutes.");
            if (function_exists('as_schedule_single_action') && function_exists('as_has_scheduled_action')) {
                $catchup_args = array('campaign_id' => $campaign_id);
                if (!as_has_scheduled_action('dit_ts_run_campaign', $catchup_args, 'dit_ts_campaigns')) {
                    as_schedule_single_action(time() + 300, 'dit_ts_run_campaign', $catchup_args, 'dit_ts_campaigns');
                }
            }
            return;
        }

        $category_filter = !empty($campaign['category']) ? $campaign['category'] : null;

        // 3. Import Fresh Content
        // (Optional: trigger import if needed, but for now rely on existing drafts)

        // 4. Process Queue
        $pending = $this->idea_importer->get_pending_ideas($limit, $category_filter);

        if (empty($pending)) {
            $this->logger->info("Action Scheduler: No pending ideas for {$campaign['name']}.");
            return;
        }

        $cleaner = new \DIT\TrendStudio\Services\Content_Cleaner();

        foreach ($pending as $post) {
            $vertical = !empty($campaign['vertical']) ? $campaign['vertical'] : get_option('dit_ts_content_vertical', 'default');

            // @MODIFIED 2026-02-08 - Smart Vertical: Auto-detect generic 'showbiz'/'fashion' from post category
            // This ensures we use the specialized Pakistani personas even if the campaign vertical is 'default' or 'general'
            // @MODIFIED 2026-02-13 - Fixed persona mixup: Use '_pk' suffix to match PromptBlueprint keys
            if ($vertical === 'default' || $vertical === 'general' || empty($vertical)) {
                $cats = get_the_category($post->ID);
                if (!empty($cats) && !is_wp_error($cats)) {
                    foreach ($cats as $cat) {
                        if (stripos($cat->slug, 'showbiz') !== false || stripos($cat->name, 'showbiz') !== false) {
                            $vertical = 'showbiz_pk'; // Maps to Pakistani Showbiz in PromptBlueprint
                            break;
                        }
                        if (stripos($cat->slug, 'fashion') !== false || stripos($cat->name, 'fashion') !== false) {
                            $vertical = 'fashion_pk'; // Maps to Pakistani Fashion in PromptBlueprint
                            break;
                        }
                    }
                }
            }

            // @MODIFIED 2026-02-08 - Fixed empty topic bug: Changed 'title' to 'idea_title' and 'content' to 'idea_text'
            // to match GenerationRequestDTO property expectations (Issue #empty-topic)
            $data = [
                'idea_id' => $post->ID,
                'idea_title' => $post->post_title,
                'idea_text' => $cleaner->clean($post->post_content),
                'source_url' => get_post_meta($post->ID, '_dit_source_url', true),
                'vertical' => $vertical,
                'category' => $category_filter,
                // @MODIFIED 2026-02-08 - Enable auto-publish for campaign jobs (Issue #auto-publish)
                'is_auto_process' => true,
                // @MODIFIED 2026-02-12 - Pass Campaign Strategy to Job (Fixes Perplexity Quota Block)
            'strategy_override' => !empty($campaign['strategy']) ? $campaign['strategy'] : null,
            'custom_provider_id' => !empty($campaign['custom_provider_id']) ? sanitize_key($campaign['custom_provider_id']) : '',
            'custom_model_id' => !empty($campaign['custom_model_id']) ? sanitize_text_field($campaign['custom_model_id']) : '',
            'cross_provider_fallback' => !empty($campaign['cross_provider_fallback']),
            'dest_category' => $campaign['dest_category'] ?? array(), // @MODIFIED 2026-02-14
                'publish_status' => !empty($campaign['publish_status']) ? $campaign['publish_status'] : 'publish', // @MODIFIED 2026-02-14 - Fix Draft vs Publish bug
                'campaign_tags'  => $campaign['tags'] ?? '', // @MODIFIED 2026-03-01
            ];

try {
                // @MODIFIED 2026-04-26 - Set _dit_ts_generated='queued' before scheduling.
                // 'queued' prevents duplicate pickup by other campaigns (NOT EXISTS won't match),
                // but is distinct from 'processing' (set in Scheduler::process_job when job actually runs).
                update_post_meta($post->ID, '_dit_ts_generated', 'queued');
                update_post_meta($post->ID, '_dit_ts_flag_set_at', time());

            // @MODIFIED 2026-03-01 - User Author ID from Campaign, fallback 1
            $user_id = !empty($campaign['author']) ? (int) $campaign['author'] : ($post->post_author ?: 1);
            $job_id = $this->job_handler->schedule_generation($data, $user_id);
            $this->logger->info("Action Scheduler: Started Job $job_id for {$campaign['name']}");
            } catch (\Exception $e) {
                $this->logger->error("Action Scheduler: Failed {$campaign['name']} - " . $e->getMessage());
            }
        }
    }

    /**
     * Handle auto-publish completion
     * Link the generated post back to the idea and trash the source draft
     */
    public function handle_auto_publish($job_id, $post_id, $idea_id)
    {
        $this->idea_importer->mark_as_generated($idea_id, $post_id);

    // @MODIFIED 2026-02-25 - Transfer job-managed media to the published post (prevents orphan media + makes cleanup safe).
        if (class_exists('DIT\\TrendStudio\\Services\\Media_Transfer_Service')) {
        $transfer = new \DIT\TrendStudio\Services\Media_Transfer_Service($this->logger);
        $transfer_result = $transfer->transfer_job_media((int) $idea_id, (int) $post_id, (int) $job_id);
        // @MODIFIED 2026-05-07 - Abort source trash if media transfer had failures OR moved zero.
        // moved=0 means no attachments were transferred (likely never tagged by localizer/sweep).
        // skipped>0 means some transfers failed. Either case means trashing would orphan attachments.
        $moved = (int) ($transfer_result['moved'] ?? 0);
        $skipped = (int) ($transfer_result['skipped'] ?? 0);
        if ($moved === 0 || $skipped > 0) {
            $this->logger->warning('Auto-publish: media transfer incomplete, deferring source trash', [
                'idea_id' => $idea_id,
                'post_id' => $post_id,
                'job_id' => $job_id,
                'moved' => $moved,
                'skipped' => $skipped,
            ]);
        } else {
            // @MODIFIED 2026-02-24 - Trash processed source drafts to keep editorial UI clean.
            $cleanup_enabled = (bool) get_option('dit_ts_enable_draft_cleanup', false);
            if ($cleanup_enabled) {
                $p = get_post((int) $idea_id);
                if ($p && $p->post_type === 'post' && $p->post_status === 'draft') {
                    wp_trash_post((int) $idea_id);
                    $this->logger->info('Auto-publish: trashed source draft', [
                        'idea_id' => (int) $idea_id,
                        'post_id' => (int) $post_id,
                        'job_id' => (int) $job_id,
                    ]);
                }
            }
        }
    } else {
        // @MODIFIED 2026-05-07 - No Media_Transfer_Service available — cannot safely trash.
        // Without transfer, trashing would orphan all attachments. Log warning and skip.
        $this->logger->warning('Auto-publish: Media_Transfer_Service unavailable, skipping source trash', [
            'idea_id' => $idea_id,
            'post_id' => $post_id,
        'job_id' => $job_id,
        ]);
    }
    }



    /**
     * AJAX: Submit article generation
     *
     * @return void
     */
    public function ajax_submit_generation()
    {
        try {
            check_ajax_referer('dit_ts_nonce', 'nonce');

            if (!current_user_can('edit_posts')) {
                throw new \Exception('Insufficient permissions');
            }

            $input_data = $this->sanitize_input_data($_POST);

            $job_handler = new Scheduler($this->logger);
            $job_id = $job_handler->schedule_generation($input_data, get_current_user_id());

            wp_send_json_success(array(
                'job_id' => $job_id,
                'message' => 'Article generation started',
            ));
        } catch (\Throwable $e) {
            $this->logger->error('Generation submit failed: ' . $e->getMessage());
            wp_send_json_error(array(
                'message' => $e->getMessage(),
            ));
        }
    }




    /**
     * AJAX: Check job status
     *
     * @return void
     */
    public function ajax_check_status()
    {
        try {
            check_ajax_referer('dit_ts_nonce', 'nonce');

            if (!current_user_can('edit_posts')) {
                throw new \Exception('Insufficient permissions');
            }

            $job_id = isset($_POST['job_id']) ? intval($_POST['job_id']) : 0;
            if (!$job_id) {
                throw new \Exception('Invalid job ID');
            }

            $job_handler = new Scheduler($this->logger);
            $status = $job_handler->get_job_status($job_id);

            wp_send_json_success($status);
        } catch (\Throwable $e) {
            $this->logger->error('Status check failed: ' . $e->getMessage());
            wp_send_json_error(array(
                'message' => $e->getMessage(),
            ));
        }
    }

    /**
     * AJAX: Force run a job manually
     *
     * @return void
     */
    public function ajax_force_run_job()
    {
        try {
            // @MODIFIED 2026-01-29 - Aggressive Recovery: Override time limit
            if (function_exists('set_time_limit')) {
                set_time_limit(300); // 5 minutes
            }

            check_ajax_referer('dit_ts_nonce', 'nonce');

            if (!current_user_can('edit_posts')) {
                throw new \Exception('Insufficient permissions');
            }

            $job_id = isset($_POST['job_id']) ? intval($_POST['job_id']) : 0;
            if (!$job_id) {
                throw new \Exception('Invalid job ID');
            }

            $reset = isset($_POST['reset']) && $_POST['reset'] === '1';

            $job_handler = new Scheduler($this->logger);

            // @MODIFIED 2026-02-24 - Regenerate: Hard reset + enqueue processing via Action Scheduler.
            if ($reset) {
                $ok = $job_handler->recover_job($job_id);
                if (!$ok) {
                    wp_send_json_error(array('message' => 'Failed to reset job (job not found or invalid payload).'));
                }

                if (function_exists('as_schedule_single_action')) {
                    as_schedule_single_action(time() + 5, 'dit_ts_process_job', array($job_id));
                }

                $status_data = $job_handler->get_job_status($job_id);

                wp_send_json_success(array(
                    'message' => 'Job reset and queued for processing.',
                    'job'     => $status_data,
                ));
                return;
            }

            // Run the job processing
            // @MODIFIED 2026-02-11 - UX: Explicit Feedback for Blocked Jobs
            if (!get_option('dit_ts_enable_ai_automation', '1')) {
                wp_send_json_error(array('message' => 'AI Automation is globally DISABLED. Enable it in Settings to run jobs.'));
            }
            // @MODIFIED 2026-02-12 - Strategy-Aware Quota Pause (Manual)
            $input_data = $job_handler->get_job_input_data($job_id);
            // @MODIFIED 2026-02-24 - Respect job-level strategy overrides when present.
		$strategy = (string) ($input_data['strategy_override'] ?? $input_data['ai_strategy'] ?? get_option('dit_ts_ai_strategy', 'gemini'));
		$provider = \DIT\TrendStudio\Infrastructure\AI_Provider_Factory::strategy_to_provider($strategy);

		$paused = false;
            $until = 0;
            $reason = '';
            if (class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Pause_Manager')) {
                $paused = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::is_paused($provider);
                $until = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::get_pause_until($provider);
                $reason = \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::get_reason($provider);
            }



            if ($paused) {
                // @MODIFIED 2026-07-04 - Cross-Provider Fallback on Pause
                // When the primary provider is paused, check if a fallback provider is available.
                $fallback = \DIT\TrendStudio\Infrastructure\Scheduler::resolve_first_available_fallback($strategy, $input_data);

                if ($fallback !== null) {
                    // Swap strategy/provider to the available fallback and proceed.
                    $input_data['strategy_override'] = $fallback['strategy'];
                    if ($fallback['strategy'] === 'custom') {
                        $input_data['custom_provider_id'] = $fallback['provider_id'];
                    } else {
                        unset($input_data['custom_provider_id']);
                    }
                    $input_data['cross_provider_fallback'] = true;

                    // Persist the swapped input_data so the job uses the fallback provider.
                    global $wpdb;
                    $table = $wpdb->prefix . 'dit_ts_jobs';
                    $wpdb->update($table, array('input_data' => json_encode($input_data)), array('id' => $job_id));

                    $this->logger->info("Force Run Job {$job_id}: Primary provider '{$provider}' paused. Falling back to '{$fallback['label']}' (strategy: {$fallback['strategy']}, provider_id: {$fallback['provider_id']}).");
                    // Fall through — job proceeds with fallback provider.
                } else {
                    // No available fallback — return error as before.
                    $until_str = '';
                    if ($until > 0 && class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Reset_Calculator')) {
                        $until_str = \DIT\TrendStudio\Infrastructure\Quota_Reset_Calculator::format_in_wp_tz((int) $until);
                    }
                    wp_send_json_error(array('message' => sprintf('Provider pause active (%s). Reason=%s. RetryAfter=%s. No fallback providers available. Configure cross-provider fallback in Settings.', $provider, $reason !== '' ? $reason : 'quota', $until_str !== '' ? $until_str : 'n/a')));
                }
            }

            $job_handler->process_job($job_id);

            wp_send_json_success(array('message' => 'Job processed'));
        } catch (\Throwable $e) {
            $this->logger->error('Force run failed: ' . $e->getMessage());
            wp_send_json_error(array(
                'message' => $e->getMessage(),
            ));
        }
    }

    /**
     * AJAX: Cancel a job
     */
    public function ajax_cancel_job()
    {
        try {
            check_ajax_referer('dit_ts_nonce', 'nonce');

            if (!current_user_can('edit_posts')) {
                throw new \Exception('Insufficient permissions');
            }

            $job_id = isset($_POST['job_id']) ? intval($_POST['job_id']) : 0;
            if (!$job_id) {
                throw new \Exception('Invalid job ID');
            }

            $job_handler = new Scheduler($this->logger);
            $job_handler->update_job_status($job_id, 'failed');

            // Log manually since update_job_status doesn't log cancellation specifically (it just updates DB)
            $this->logger->info("Job {$job_id} cancelled by user.");

            $status_data = $job_handler->get_job_status($job_id);

            wp_send_json_success(array(
                'message' => 'Job cancelled',
                'job'     => $status_data,
            ));
        } catch (\Throwable $e) {
            $this->logger->error('Cancel failed: ' . $e->getMessage());
            wp_send_json_error(array(
                'message' => $e->getMessage(),
            ));
        }
    }

    /**
     * AJAX: Get article preview
     *
     * @return void
     */
    public function ajax_get_preview()
    {
        try {
            check_ajax_referer('dit_ts_nonce', 'nonce');

            if (!current_user_can('edit_posts')) {
                throw new \Exception('Insufficient permissions');
            }

            $job_id = isset($_POST['job_id']) ? intval($_POST['job_id']) : 0;
            if (!$job_id) {
                throw new \Exception('Invalid job ID');
            }

            $preview = $this->job_handler->get_preview($job_id);

            wp_send_json_success($preview);
        } catch (\Throwable $e) {
            $this->logger->error('Preview failed: ' . $e->getMessage());
            wp_send_json_error(array(
                'message' => $e->getMessage(),
            ));
        }
    }

    /**
     * AJAX: Publish article as draft
     * @MODIFIED 2025-12-14 - Secure publish: server-side content, ownership check, no wp_kses_post on blocks
     *
     * @return void
     */
    public function ajax_publish_article()
    {
        try {
            check_ajax_referer('dit_ts_nonce', 'nonce');

            // @MODIFIED 2025-12-14 - Correct capability for drafts
            if (!current_user_can('edit_posts')) {
                throw new \Exception('Insufficient permissions');
            }

            // @MODIFIED 2025-12-14 - Only accept job_id and optional title override, not content
            $job_id = isset($_POST['job_id']) ? absint($_POST['job_id']) : 0;
            $title_override = isset($_POST['title']) ? sanitize_text_field($_POST['title']) : '';

            if (!$job_id) {
                throw new \Exception('Invalid job ID');
            }

            // @MODIFIED 2025-12-14 - Server-side fetch with ownership verification
            $job_handler = new Scheduler($this->logger);
            $job_data = $job_handler->get_job_for_publish($job_id, get_current_user_id());

            // Use stored block markup (no wp_kses_post - block comments must survive)
            $content = $job_data['block_markup'];

            // @MODIFIED 2025-12-14 - Validate block markup is non-empty and parseable
            if (empty($content)) {
                throw new \Exception('Block markup is empty. Please regenerate the article.');
            }
            $parsed = parse_blocks($content);
            if (empty($parsed) || (count($parsed) === 1 && empty($parsed[0]['blockName']))) {
                throw new \Exception('Block markup is invalid. Please regenerate the article.');
            }

            $title = !empty($title_override) ? $title_override : $job_data['title'];

            // Create draft post
            $post_id = wp_insert_post(array(
                'post_title' => $title,
                'post_content' => $content,
                'post_status' => 'draft',
                'post_author' => get_current_user_id(),
                'post_type' => 'post',
            ));

            if (is_wp_error($post_id)) {
                throw new \Exception($post_id->get_error_message());
            }

            // @MODIFIED 2026-01-24 - Assign Collage as Featured Image
            // @MODIFIED 2026-02-28 - Mark featured collage as plugin-managed so it can be safely cleaned up if the post is trashed/deleted.
            if (!empty($job_data['article']['_featured_collage_id'])) {
                $cid = (int) $job_data['article']['_featured_collage_id'];
                set_post_thumbnail($post_id, $cid);
                if ($cid > 0) {
                    update_post_meta($cid, '_dit_ts_media_managed', 1);
                    update_post_meta($cid, '_dit_ts_media_owner', (int) $post_id);
                    update_post_meta($cid, '_dit_ts_media_job', (int) $job_id);
                }
            }
            // @MODIFIED 2026-05-31 - Re-parent job-managed attachments from source draft to new post.
            // ajax_publish_article() previously skipped this step, leaving images parented to the
            // draft (idea_id) instead of the published post. This caused images to appear orphaned
            // and not visible in the post's media library.
            $idea_id = (int) ($job_data['input_data']['idea_id'] ?? 0);
            if ($idea_id > 0 && $job_id > 0) {
                $re_parent_ids = get_posts([
                    'post_type'      => 'attachment',
                    'post_status'    => 'inherit',
                    'fields'         => 'ids',
                    'posts_per_page' => -1,
                    'meta_query'     => [
                        'relation' => 'AND',
                        ['key' => '_dit_ts_media_job', 'value' => (string) $job_id, 'compare' => '='],
                        ['key' => '_dit_ts_media_managed', 'value' => '1', 'compare' => '='],
                        ['key' => '_dit_ts_media_owner', 'value' => (string) $idea_id, 'compare' => '='],
                    ],
                ]);
                if (!empty($re_parent_ids)) {
                    foreach ($re_parent_ids as $att_id) {
                        wp_update_post(['ID' => (int) $att_id, 'post_parent' => $post_id]);
                    }
                    update_post_meta($post_id, '_dit_ts_images', array_map('intval', $re_parent_ids));
                    if (isset($this->logger)) {
                        $this->logger->info("Manual publish: Re-parented " . count($re_parent_ids) . " attachments to Post {$post_id}");
                    }
                }
            }

            // Save metadata
            $article = $job_data['article'];
            $validation = $job_data['validation'];

            if (!empty($article) && is_array($article)) {
                update_post_meta($post_id, '_dit_ts_article_snapshot', $article);
                update_post_meta($post_id, '_dit_ts_schema_modified', time());
            }

            if (!empty($validation) && is_array($validation)) {
                update_post_meta($post_id, '_dit_ts_validation_results', $validation);
            }

            update_post_meta($post_id, '_dit_ts_job_id', $job_id);
            // @MODIFIED 2026-02-18 - Protect manual publishes from cleanup
            update_post_meta($post_id, '_dit_ts_generated', '1');
        update_post_meta($post_id, '_dit_ts_flag_set_at', time());

            // Persist SEO meta (consistent with auto-publish in Scheduler.php)
            if (class_exists('DIT\\TrendStudio\\SEO\\MetadataGenerator')) {
                $meta = MetadataGenerator::generate($article);
                if (!empty($meta['title'])) {
                    update_post_meta($post_id, '_dit_ts_meta_title', $meta['title']);
                    update_post_meta($post_id, '_yoast_wpseo_title', $meta['title']);
                    update_post_meta($post_id, 'rank_math_title', $meta['title']);
                }
                if (!empty($meta['description'])) {
                    update_post_meta($post_id, '_dit_ts_meta_description', $meta['description']);
                    update_post_meta($post_id, '_yoast_wpseo_metadesc', $meta['description']);
                    update_post_meta($post_id, 'rank_math_description', $meta['description']);
                }
                $focus_keyword = $article['primary_keyword'] ?? $meta['primary_keyword'] ?? '';
                if (empty($focus_keyword)) {
                    $tags = $article['tags'] ?? array();
                    $focus_keyword = is_array($tags) && !empty($tags) ? (string) reset($tags) : '';
                }
                if (empty($focus_keyword)) {
                    $focus_keyword = $article['headline'] ?? '';
                }
                if (!empty($focus_keyword)) {
                    update_post_meta($post_id, 'rank_math_focus_keyword', $focus_keyword);
                }
            }

            // [NEW] Apply Fashion Tags (Manual Publish)
            if (!empty($article['_meta_tags'])) {
                $tags = is_array($article['_meta_tags']) ? $article['_meta_tags'] : explode(',', $article['_meta_tags']);
                $tags = array_filter($tags, function ($t) {
                    return is_string($t) && !empty($t);
                });
                wp_set_post_tags($post_id, $tags, true);
            }

            // @MODIFIED 2026-01-13 - Save Strategy & Schema Meta
            if (isset($job_data['input_data']['search_intent'])) {
                update_post_meta($post_id, '_dit_search_intent', $job_data['input_data']['search_intent']);
            }
            if (isset($job_data['input_data']['editorial_angle'])) {
                update_post_meta($post_id, '_dit_editorial_angle', $job_data['input_data']['editorial_angle']);
            }
            // Save Review Data if available
            if (isset($job_data['review_data'])) {
                if (!empty($job_data['review_data']['rating'])) {
                    update_post_meta($post_id, '_dit_ai_rating', $job_data['review_data']['rating']);
                }
                if (!empty($job_data['review_data']['pros'])) {
                    update_post_meta($post_id, '_dit_ai_pros', $job_data['review_data']['pros']);
                }
                if (!empty($job_data['review_data']['cons'])) {
                    update_post_meta($post_id, '_dit_ai_cons', $job_data['review_data']['cons']);
                }
            }

            // If generated from idea, mark idea as used
            if (!empty($article['idea_id'])) {
                $this->idea_importer->mark_as_generated($article['idea_id'], $post_id);
            }

            $this->logger->info("Article published: Post ID {$post_id}");

            wp_send_json_success(array(
                'post_id' => $post_id,
                'edit_url' => get_edit_post_link($post_id, 'raw'),
                'message' => 'Article saved as draft',
            ));
        } catch (\Throwable $e) {
            $this->logger->error('Publish failed: ' . $e->getMessage());
            wp_send_json_error(array(
                'message' => $e->getMessage(),
            ));
        }
    }

    /**
     * AJAX: Import ideas from sources
     *
     * @return void
     */
    public function ajax_import_ideas()
    {
        try {
            check_ajax_referer('dit_ts_nonce', 'nonce');

            if (!current_user_can('edit_posts')) {
                throw new \Exception('Insufficient permissions');
            }

            $provider_type = isset($_POST['provider']) ? sanitize_text_field($_POST['provider']) : '';

            if ($provider_type) {
                $results = $this->idea_importer->import_from($provider_type);
            } else {
                $results = $this->idea_importer->import_all();
            }

            // @MODIFIED 2026-01-25 - Trigger processing of pending drafts/inbox
            // Force bypass cooldown for manual "Import Now"
            $jobs_started = $this->process_pending_queue(1, true);

            $msg = sprintf('Imported %d new ideas from feeds.', $results['imported']);
            if ($jobs_started > 0) {
                $msg .= ' Started processing 1 pending draft.';
            } else {
                // If 0 started even with bypass, it means Queue is empty or Job is running
                if ($this->job_handler->has_running_jobs()) {
                    $msg .= ' Queue skipped: A job is already running.';
                } else {
                    $msg .= ' Queue skipped: No pending drafts found.';
                }
            }

            wp_send_json_success(array(
                'imported' => $results['imported'],
                'skipped' => $results['skipped'],
                'errors' => $results['errors'],
                'message' => $msg,
            ));
        } catch (\Throwable $e) {
            $this->logger->error('Import failed: ' . $e->getMessage());
            wp_send_json_error(array(
                'message' => $e->getMessage(),
            ));
        }
    }

    /**
     * AJAX: Clear stuck jobs
     * @MODIFIED 2026-01-25 - Manual cleanup for stuck jobs
     *
     * @return void
     */
    public function ajax_clear_stuck_jobs()
    {
        try {
            check_ajax_referer('dit_ts_nonce', 'nonce');

            if (!current_user_can('manage_options')) {
                throw new \Exception('Insufficient permissions');
            }

            // @MODIFIED 2026-01-27 - Force delete stuck jobs instead of just marking failed
            // Use 5 minute timeout (300s) for manual clear to be more aggressive than auto-cleanup
            $cleared = $this->job_handler->force_clear_stuck_jobs(300);

            wp_send_json_success(array(
                'cleared' => $cleared,
                'message' => sprintf('Cleared %d stuck job(s). You can now click Import Now again.', $cleared),
            ));
        } catch (\Throwable $e) {
            $this->logger->error('Clear stuck jobs failed: ' . $e->getMessage());
            wp_send_json_error(array(
                'message' => $e->getMessage(),
            ));
        }
    }

    /**
     * AJAX: Clear ALL jobs
     * @MODIFIED 2026-01-27 - Nuclear option handler
     *
     * @return void
     */
    public function ajax_clear_all_jobs()
    {
        try {
            check_ajax_referer('dit_ts_nonce', 'nonce');

            if (!current_user_can('manage_options')) {
                throw new \Exception('Insufficient permissions');
            }

            $cleared = $this->job_handler->clear_all_jobs();

            wp_send_json_success(array(
                'cleared' => $cleared,
                'message' => sprintf('Nuclear Option Executed: Cleared ALL %d jobs.', $cleared),
            ));
        } catch (\Throwable $e) {
            $this->logger->error('Clear all jobs failed: ' . $e->getMessage());
            wp_send_json_error(array(
                'message' => $e->getMessage(),
            ));
        }
    }


    /**
     * AJAX: Purge trashed source drafts now (manual test button)
     * @MODIFIED 2026-02-24 - Manual purge ignores age threshold and only targets plugin-marked sources.
     *
     * @return void
     */
    public function ajax_purge_trash_now()
    {
        try {
            check_ajax_referer('dit_ts_nonce', 'nonce');

            if (!current_user_can('manage_options')) {
                throw new \Exception('Insufficient permissions');
            }

            $service = new \DIT\TrendStudio\Services\Draft_Cleanup_Service($this->logger);
            $results = $service->purge_trashed_cleanup_candidates_now();

            if (!empty($results['status']) && $results['status'] === 'disabled') {
                wp_send_json_error(array(
                    'message' => __('Automated Draft Cleanup is disabled. Enable it first to purge trashed sources.', 'dit-trend-content-studio'),
                ));
            }

            $deleted = (int) ($results['deleted_posts'] ?? 0);
            $deleted_media = (int) ($results['deleted_media'] ?? 0);
            $remaining = (int) ($results['remaining'] ?? 0);

            $message = sprintf(
                /* translators: 1: deleted posts, 2: deleted media, 3: remaining */
                __('Purged %1$d trashed source post(s) and %2$d attachment(s). Remaining eligible in Trash: %3$d.', 'dit-trend-content-studio'),
                $deleted,
                $deleted_media,
                $remaining
            );

            wp_send_json_success(array(
                'deleted' => $deleted,
                'deleted_media' => $deleted_media,
                'remaining' => $remaining,
                'message' => $message,
            ));
        } catch (\Throwable $e) {
            $this->logger->error('Trash purge failed: ' . $e->getMessage());
            wp_send_json_error(array(
                'message' => $e->getMessage(),
            ));
        }
    }

    /**
     * AJAX: Purge orphan attachments whose parent posts are missing.
     *
     * @MODIFIED 2026-02-25 - Remediation tool to remove orphan media left behind by earlier purges.
     *
     * @return void
     */
    public function ajax_purge_orphan_media_now()
    {
        try {
            check_ajax_referer('dit_ts_nonce', 'nonce');

            if (!current_user_can('manage_options')) {
                throw new \Exception('Insufficient permissions');
            }

            $service = new \DIT\TrendStudio\Services\Draft_Cleanup_Service($this->logger);
            $results = $service->purge_orphaned_attachments_now();

            if (!empty($results['status']) && $results['status'] === 'disabled') {
                wp_send_json_error(array(
                    'message' => __('Automated Draft Cleanup is disabled. Enable it first to purge orphan media.', 'dit-trend-content-studio'),
                ));
            }

            if (!empty($results['status']) && $results['status'] === 'media_delete_disabled') {
                wp_send_json_error(array(
                    'message' => __('Delete Associated Media is disabled. Enable it first to purge orphan media.', 'dit-trend-content-studio'),
                ));
            }

            $deleted = (int) ($results['deleted_media'] ?? 0);
            $detached = (int) ($results['detached_media'] ?? 0);
            $remaining = (int) ($results['remaining'] ?? 0);

            $message = sprintf(
                /* translators: 1: deleted count, 2: detached count, 3: remaining */
                __('Purged %1$d orphan attachment(s). Detached %2$d in-use attachment(s). Remaining orphan attachments: %3$d.', 'dit-trend-content-studio'),
                $deleted,
                $detached,
                $remaining
            );

            wp_send_json_success(array(
                'deleted' => $deleted,
                'detached' => $detached,
                'remaining' => $remaining,
                'message' => $message,
            ));
        } catch (\Throwable $e) {
            $this->logger->error('Orphan media purge failed: ' . $e->getMessage());
            wp_send_json_error(array(
                'message' => $e->getMessage(),
            ));
        }
    }

    /**
     * AJAX: Test API connection
     *
     * @return void
     */


    /**
     * AJAX: Empty WP Trash globally (ALL post types) with optional media cleanup.
     *
     * Safety:
     * - Requires confirm=DELETE
     * - When include_media=1, attachments are deleted only if not referenced elsewhere unless force_media=1.
     *
     * @MODIFIED 2026-02-25 - Global Trash purge (manual admin tool).
     *
     * @return void
     */
    public function ajax_empty_trash_now()
    {
        try {
            check_ajax_referer('dit_ts_nonce', 'nonce');

            if (!current_user_can('manage_options')) {
                throw new \Exception('Insufficient permissions');
            }

            $confirm = isset($_POST['confirm']) ? sanitize_text_field(wp_unslash($_POST['confirm'])) : '';
            if ($confirm !== 'DELETE') {
                throw new \Exception('Confirmation missing. Type DELETE to proceed.');
            }

            $batch_size = isset($_POST['batch_size']) ? max(5, min(50, absint($_POST['batch_size']))) : 25;
            $include_media = !empty($_POST['include_media']);
            $force_media = !empty($_POST['force_media']);

            $svc = new \DIT\TrendStudio\Services\Trash_Purge_Service($this->logger);
            $res = $svc->purge_all_trash_now($batch_size, $include_media, $force_media);

            wp_send_json_success(array(
                'deleted_posts'  => (int) ($res['deleted_posts'] ?? 0),
                'deleted_media'  => (int) ($res['deleted_media'] ?? 0),
                'detached_media' => (int) ($res['detached_media'] ?? 0),
                'remaining'      => (int) ($res['remaining'] ?? 0),
                'done'           => (bool) ($res['done'] ?? true),
            ));
        } catch (\Throwable $e) {
            $this->logger->error('Empty trash failed: ' . $e->getMessage());
            wp_send_json_error(array(
                'message' => $e->getMessage(),
            ));
        }
    }

    public function ajax_test_api()
    {
        try {
            check_ajax_referer('dit_ts_nonce', 'nonce');

            if (!current_user_can('manage_options')) {
                throw new \Exception('Insufficient permissions');
            }

            $api_key = isset($_POST['api_key']) ? sanitize_text_field($_POST['api_key']) : '';
            if (!$api_key) {
                throw new \Exception('API key is required');
            }

$provider = isset($_POST['provider']) ? sanitize_text_field($_POST['provider']) : 'gemini';

        // @MODIFIED 2026-06-01 - Use factory for test connection (openrouter/groq are no longer standalone providers)
        $ai_client = \DIT\TrendStudio\Infrastructure\AI_Provider_Factory::create_from_test($provider, $api_key, $this->logger);

            $result = $ai_client->test_connection();

            wp_send_json_success(array(
                'message' => 'API connection successful',
                'details' => $result,
            ));
        } catch (\Throwable $e) {
            $this->logger->error('API test failed: ' . $e->getMessage());
            wp_send_json_error(array(
                'message' => $e->getMessage(),
            ));
        }
    }

    /**
     * Sanitize input data for generation
     * @MODIFIED 2025-12-27 - Added SEO targeting fields
     *
     * @param array $data Raw input data
     * @return array Sanitized data
     */
    private function sanitize_input_data($data)
    {
        // Remove slashes added by WordPress for POST requests
        $data = wp_unslash($data);
        return array(
            'idea_id' => isset($data['idea_id']) ? absint($data['idea_id']) : 0,
            'idea_title' => isset($data['idea_title']) ? sanitize_text_field($data['idea_title']) : '',
            'idea_text' => isset($data['idea_text']) ? wp_kses_post($data['idea_text']) : '',
            'category' => isset($data['category']) ? sanitize_text_field($data['category']) : '',
            'tags' => isset($data['tags']) ? sanitize_text_field($data['tags']) : '',
            'vertical' => isset($data['vertical']) ? sanitize_text_field($data['vertical']) : 'showbiz',
            'source_urls' => isset($data['source_urls']) ? wp_kses_post($data['source_urls']) : '',
            // SEO targeting fields
            'primary_keyword' => isset($data['primary_keyword']) ? sanitize_text_field($data['primary_keyword']) : '',
            'search_intent' => isset($data['search_intent']) ? sanitize_text_field($data['search_intent']) : 'mixed',
            'editorial_angle' => isset($data['editorial_angle']) ? sanitize_text_field($data['editorial_angle']) : 'neutral',
            'secondary_keywords' => isset($data['secondary_keywords']) ? sanitize_text_field($data['secondary_keywords']) : '',
            'ai_strategy' => isset($data['ai_strategy']) ? sanitize_text_field($data['ai_strategy']) : '',
            'custom_provider_id' => isset($data['custom_provider_id']) ? sanitize_key($data['custom_provider_id']) : '',
            'custom_model_id' => isset($data['custom_model_id']) ? sanitize_text_field($data['custom_model_id']) : '',
            'cross_provider_fallback' => !empty($data['cross_provider_fallback']),
            'auto_source_images' => !empty($data['auto_source_images']),
            'is_auto_process' => !empty($data['is_auto_process']),
        );
    }

    /**
     * Load plugin text domain
     *
     * @return void
     */
    public function load_textdomain()
    {
        load_plugin_textdomain('dit-trend-content-studio', false, dirname(DIT_TS_PLUGIN_BASENAME) . '/languages');
    }

    /**
     * Get plugin version
     *
     * @return string
     */
    public function get_version()
    {
        return DIT_TS_VERSION;
    }

    /**
     * Get logger instance
     *
     * @return Logger
     */
    public function get_logger(): Logger
    {
        return $this->logger;
    }

    /**
     * Run daily cleanup
     * @since 2.2.0
     * @return void
     */
    public function run_daily_cleanup()
    {
        // 1. Clean Jobs (3 days retention)
        $deleted_jobs = $this->job_handler->clean_old_jobs(3);

        // 2. Attempt to clear stuck jobs older than one hour
        // @MODIFIED 2026-01-29 - Force clean stuck jobs per user request
        $cleared_stuck = $this->job_handler->force_clear_stuck_jobs(3600);

        // 3. Clean Logs (3 days retention)
        $deleted_logs = $this->logger->clear_old_logs(3);

        // 4. Automated Draft Cleanup
        // @since 2.8.2
        $draft_service = new Draft_Cleanup_Service($this->logger);
        $cleanup_results = $draft_service->cleanup_old_drafts();

        if ($deleted_jobs > 0 || $cleared_stuck > 0 || $deleted_logs > 0 || $cleanup_results['deleted_posts'] > 0) {
            $this->logger->info(sprintf(
                "Daily Cleanup: Deleted %d old jobs, marked %d stuck jobs failed, deleted %d log files, and cleaned up %d old drafts (%d media items).",
                $deleted_jobs,
                $cleared_stuck,
                $deleted_logs,
                $cleanup_results['deleted_posts'],
                $cleanup_results['deleted_media']
            ));
        }
    }

    /**
     * Add custom cron intervals
     * @since 2.1.2
     *
     * @param array $schedules WP cron schedules
     * @return array Modified schedules
     */
    public function add_cron_intervals($schedules)
    {
        $schedules['every_15_mins'] = array(
            'interval' => 15 * 60,
            'display'  => __('Every 15 Minutes', 'dit-trend-content-studio')
        );
        $schedules['every_30_mins'] = array(
            'interval' => 30 * 60,
            'display'  => __('Every 30 Minutes', 'dit-trend-content-studio')
        );
        if (!isset($schedules['dit_ts_ten_minutes'])) {
            $schedules['dit_ts_ten_minutes'] = array(
                'interval' => 600,
                'display'  => __('Every 10 Minutes (TrendStudio)', 'dit-trend-content-studio'),
            );
        }
        return $schedules;
    }

    /**
     * Watchdog handler
     */
    public function run_job_watchdog()
    {
        // 15 minutes timeout by default (filterable)
        $timeout = (int) apply_filters('dit_ts_watchdog_timeout_seconds', 900);
        $cleared = $this->job_handler->force_clear_stuck_jobs($timeout);

        if ($cleared > 0) {
            $this->logger->info(sprintf('Watchdog: marked %d stuck jobs as failed (timeout=%ds).', $cleared, $timeout));
        }
    }

    /**
     * AJAX: Toggle Master AI Automation Switch
     * @since 2.4.9
     */
    public function ajax_toggle_ai_automation()
    {
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        check_ajax_referer('dit_ts_nonce', 'nonce');

        $enabled = isset($_POST['enabled']) ? (int) $_POST['enabled'] : 0;
        update_option('dit_ts_enable_ai_automation', $enabled);

        $status = $enabled ? 'ENABLED' : 'DISABLED';
        $this->logger->info("Master AI Automation Switch toggled to: {$status}");

        // @MODIFIED 2026-02-11 - Sync schedules when toggle changes
        $this->sync_automation_schedules();

        wp_send_json_success([
            'message' => "AI Automation is now {$status}" . ($enabled ? " (Schedules Restored)" : " (Schedules Paused)"),
            'enabled' => $enabled
        ]);
    }

    /**
     * Synchronize Action Scheduler jobs with AI Automation toggle
     * @MODIFIED 2026-02-11 - Professional Disable: Unschedule when off, restore when on
     * @since 2.5.0
     */
    public function sync_automation_schedules()
    {
        $enabled = (int) get_option('dit_ts_enable_ai_automation', '1');

        if (!$enabled) {
            // UNSCHEDULE EVERYTHING
            $this->logger->info("Sync: AI Automation is DISABLED. Clearing all background schedules.");

            // 1. Clear Campaigns
            if (function_exists('as_unschedule_all_actions')) {
                as_unschedule_all_actions('dit_ts_run_campaign');
            }

            // 2. Clear Imports
            $this->clear_all_scheduled_imports();

            // 3. Clear Watchdog (optional, but keeps it clean)
            if (function_exists('as_unschedule_all_actions')) {
                as_unschedule_all_actions('dit_ts_job_watchdog');
                // @MODIFIED 2026-06-01 - Also clear the publish watchdog so it does not republish
                // while automation is globally disabled
                as_unschedule_all_actions('dit_ts_publish_due_posts');
            }

            // 4. Clear queued job runners (prevents jobs firing while Master Switch is OFF)
            // @MODIFIED 2026-02-26 - Stop already-enqueued job executions when automation is disabled
            if (function_exists('as_unschedule_all_actions')) {
                as_unschedule_all_actions('dit_ts_process_job');
                as_unschedule_all_actions('dit_ts_quota_probe');
                as_unschedule_all_actions('dit_ts_resume_pending_jobs');
            }

            // Clear pending-drain flag (resume only when re-enabled)
            delete_transient('dit_ts_pending_drain_active');
        } else {
            // RESTORE EVERYTHING
            $this->logger->info("Sync: AI Automation is ENABLED. Restoring background schedules.");

            // 1. Restore Campaigns
            $campaigns = json_decode(get_option('dit_ts_campaigns', '[]'), true);
            if (!empty($campaigns) && is_array($campaigns)) {
                $this->logger->info("Sync: Restoring " . count($campaigns) . " campaigns.");
                // We reuse the logic from SettingsPage by effectively "re-saving" the schedules.
                // However, since we don't want to duplicate logic, we'll implement a clean restorer here.
                foreach ($campaigns as $campaign) {
                    if (empty($campaign['active']) || empty($campaign['id'])) continue;

                    // Trigger a re-scheduling by calling the core logic if we had it extracted, 
                    // otherwise we repeat the basic scheduler call.
                    $this->schedule_campaign_recurring($campaign);
                }
            }

            // 2. Restore Imports
            $this->ensure_schedule();

            // 3. Restore Watchdog
            if (!wp_next_scheduled('dit_ts_job_watchdog')) {
                wp_schedule_event(time(), 'dit_ts_ten_minutes', 'dit_ts_job_watchdog');
            }

            // @MODIFIED 2026-06-01 - Restore the publish watchdog (recovers missed-schedule posts)
            $this->ensure_publish_watchdog();

            // 4. Resume orphaned pending jobs (jobs that were already created but unscheduled while OFF)
            // @MODIFIED 2026-02-26 - Safe one-at-a-time pending drain to avoid Action Scheduler stampedes
            set_transient('dit_ts_pending_drain_active', '1', 12 * HOUR_IN_SECONDS);

            if (function_exists('as_schedule_single_action')) {
                $tkey = 'dit_ts_pending_drain_triggered';
                if (!get_transient($tkey)) {
                    set_transient($tkey, '1', 300);
                    as_schedule_single_action(time() + 30, 'dit_ts_resume_pending_jobs', array(1));
                }
            }
        }
    }

    /**
     * Helper to schedule a campaign recurring action
     * @since 2.5.0
     */
    private function schedule_campaign_recurring($campaign)
    {
        if (!function_exists('as_schedule_recurring_action') || empty($campaign['schedule']) || $campaign['schedule'] === 'manual') {
            return;
        }

        $hook = 'dit_ts_run_campaign';
        $args = array('campaign_id' => $campaign['id']);
        $group = 'dit_ts_campaigns';

        // Map schedule string to interval
        $intervals = [
            'every_15_mins' => 900,
            'every_30_mins' => 1800,
            'hourly'        => 3600,
            '2hours'        => 7200,
            '3hours'        => 10800,
            '4hours'        => 14400,
            '5hours'        => 18000,
            '6hours'        => 21600,
            '7hours'        => 25200,
            '8hours'        => 28800,
            '9hours'        => 32400,
            '10hours'       => 36000,
            '11hours'       => 39600,
            '12hours'       => 43200,
            'daily'         => 86400,
            'twice_daily'   => 43200,
            '48hours'       => 172800,
        ];

        $interval = $intervals[$campaign['schedule']] ?? 3600;

        // Clean existing
        as_unschedule_action($hook, $args, $group);

        // Schedule new (start in 1 min)
        as_schedule_recurring_action(time() + 60, $interval, $hook, $args, $group);
        $this->logger->info("Scheduled campaign {$campaign['name']} ({$campaign['id']}) every {$interval}s");
    }

    /**
     * AJAX: Cancel all pending and processing jobs
     * @since 2.4.9
     */
    public function ajax_cancel_all_jobs()
    {
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        check_ajax_referer('dit_ts_nonce', 'nonce');

        $count = $this->job_handler->cancel_all_jobs();
        $this->logger->info("Emergency Stop: Cancelled {$count} jobs via Admin.");

        wp_send_json_success([
            'message' => "Cancelled {$count} active jobs and cleared the queue.",
            'count' => $count
        ]);
    }
    /**
     * Determine if this is a TrendsStudio-generated WP post.
     *
     * @param int $post_id
     * @return bool
     * @MODIFIED 2026-02-28
     */
    private function is_trendsstudio_generated_post(int $post_id): bool
    {
        $post_id = (int) $post_id;
        if ($post_id <= 0) {
            return false;
        }

        $post = get_post($post_id);
        if (!$post || $post->post_type !== 'post') {
            return false;
        }

        return ((string) get_post_meta($post_id, '_dit_ts_generated', true) === '1');
    }

    /**
     * Collect plugin-managed attachment IDs owned by a post.
     *
     * @param int $post_id
     * @return int[]
     * @MODIFIED 2026-02-28
     */
    private function get_managed_attachment_ids_for_post(int $post_id): array
    {
        global $wpdb;

        $post_id = (int) $post_id;
        if ($post_id <= 0) {
            return array();
        }

        $ids = array();

        $sql = "
        SELECT pm.post_id
        FROM {$wpdb->postmeta} pm
        INNER JOIN {$wpdb->postmeta} pm2 ON pm.post_id = pm2.post_id
        WHERE pm.meta_key = '_dit_ts_media_owner'
          AND pm.meta_value = %d
          AND pm2.meta_key = '_dit_ts_media_managed'
          AND pm2.meta_value = '1'
    ";
        $rows = $wpdb->get_col($wpdb->prepare($sql, $post_id));
        foreach ((array) $rows as $rid) {
            $ids[] = (int) $rid;
        }

        $children = get_children(array(
            'post_parent' => $post_id,
            'post_type'   => 'attachment',
            'fields'      => 'ids',
        ));
        foreach ((array) $children as $aid) {
            $aid = (int) $aid;
            if ($aid > 0 && (int) get_post_meta($aid, '_dit_ts_media_managed', true) === 1) {
                $ids[] = $aid;
            }
        }

        return array_values(array_unique(array_filter(array_map('intval', $ids))));
    }

    /**
     * Trash plugin-managed attachments when the generated post is trashed.
     *
     * @param int $post_id
     * @return void
     * @MODIFIED 2026-02-28
     */
    public function handle_generated_post_trashed($post_id): void
    {
        $post_id = (int) $post_id;

        if (!$this->is_trendsstudio_generated_post($post_id)) {
            return;
        }

        $ids = $this->get_managed_attachment_ids_for_post($post_id);
        if (empty($ids)) {
            return;
        }

        update_post_meta($post_id, '_dit_ts_trash_managed_attachments', $ids);

        foreach ($ids as $aid) {
            $aid = (int) $aid;
            if ($aid <= 0) {
                continue;
            }

            if (class_exists('DIT\\TrendStudio\\Services\\Media_Cleanup_Helper')) {
                $used = \DIT\TrendStudio\Services\Media_Cleanup_Helper::is_attachment_used_elsewhere($aid, array($post_id));
                if ($used > 0) {
                    continue;
                }
            }

            if (get_post_status($aid) !== 'trash') {
                wp_trash_post($aid);
            }
        }
    }

    /**
     * Restore previously trashed attachments if post is untrashed.
     *
     * @param int $post_id
     * @return void
     * @MODIFIED 2026-02-28
     */
    public function handle_generated_post_untrashed($post_id): void
    {
        $post_id = (int) $post_id;

        if (!$this->is_trendsstudio_generated_post($post_id)) {
            return;
        }

        $ids = get_post_meta($post_id, '_dit_ts_trash_managed_attachments', true);
        if (!is_array($ids) || empty($ids)) {
            return;
        }

        foreach ($ids as $aid) {
            $aid = (int) $aid;
            if ($aid > 0 && get_post_status($aid) === 'trash') {
                wp_untrash_post($aid);
            }
        }

        delete_post_meta($post_id, '_dit_ts_trash_managed_attachments');
    }

	/**
	 * Permanently delete attachments when a post is permanently deleted,
	 * only if they are not used elsewhere by another post.
	 *
	 * Handles three post types:
	 * 1. Generated posts (_dit_ts_generated=1) — deletes their plugin-managed media
	 * 2. Plugin-used source posts (_dit_ts_cleanup_candidate=1) — deletes leftover
	 *    attachments that were not transferred to the generated post
	 * 3. All other posts (no plugin meta) — deletes ALL child attachments that are
	 *    not referenced by any other non-trashed post
	 *
	 * @param int $post_id
	 * @return void
	 * @MODIFIED 2026-02-28
	 * @MODIFIED 2026-04-26 - Extended to cover source posts and all non-plugin posts
	 */
	public function handle_generated_post_before_delete($post_id): void
	{
		$post_id = (int) $post_id;
		if ($post_id <= 0) {
			return;
		}

		$post = get_post($post_id);
		if (!$post || $post->post_type !== 'post') {
			return;
		}

		// @MODIFIED 2026-08-30 - 504 fix: short-circuit for already-trashed posts.
		// handle_generated_post_trashed() already handled attachment cleanup when the post
		// was moved to Trash. Re-running the cascade on permanent delete caused recursive
		// before_delete_post chains that breached the proxy timeout on bulk/empty-trash.
		if ($post->post_status === 'trash') {
			return;
		}

		if (!class_exists('DIT\\TrendStudio\\Services\\Media_Cleanup_Helper')) {
			return;
		}

		if (apply_filters('dit_ts_skip_before_delete_cleanup', false, $post_id)) {
			return;
		}

		$is_generated = $this->is_trendsstudio_generated_post($post_id);
		$is_source = (get_post_meta($post_id, '_dit_ts_cleanup_candidate', true) === '1');

		// @MODIFIED 2026-08-30 - 504 fix: fast-exit for posts that have no plugin-managed
		// media at all. The previous code fell through into Media_Cleanup_Helper and ran
		// regex + LIKE-on-post_content scans for every regular post, stacking with the
		// Autoremove Attachments plugin and breaching the proxy timeout.
		if (!$is_generated && !$is_source) {
			$managed_children = get_children(array(
				'post_parent' => $post_id,
				'post_type'   => 'attachment',
				'fields'      => 'ids',
				'meta_query'  => array(
					array(
						'key'     => '_dit_ts_media_managed',
						'value'   => '1',
						'compare' => '=',
					),
				),
			));
			if (empty($managed_children) || !is_array($managed_children)) {
				return;
			}
		}

		$ids = array();

		if ($is_generated) {
			$ids = $this->get_managed_attachment_ids_for_post($post_id);
			$stored = get_post_meta($post_id, '_dit_ts_trash_managed_attachments', true);
			if (is_array($stored) && !empty($stored)) {
				$ids = array_merge($ids, $stored);
			}
		}

		if ($is_source || (!$is_generated)) {
			$candidate_ids = \DIT\TrendStudio\Services\Media_Cleanup_Helper::get_candidate_attachment_ids_for_post($post_id);
			if (!empty($candidate_ids)) {
				$ids = array_merge($ids, $candidate_ids);
			}
			// @MODIFIED 2026-05-07 - Meta-key fallback for source posts with detached attachments.
			// transfer_* mode now detaches attachments (post_parent=0) so the auto_publish re-parent
			// query can find them. If the source idea is permanently deleted before transfer completes,
			// get_candidate_attachment_ids_for_post misses them (post_parent≠$post_id, content may be
			// rewritten). This fallback finds orphaned job-managed media by _dit_ts_media_owner meta.
			if ($is_source) {
				global $wpdb;
				$meta_ids = $wpdb->get_col($wpdb->prepare(
					"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_dit_ts_media_owner' AND meta_value = %d",
					$post_id
				));
				if (!empty($meta_ids)) {
					$ids = array_merge($ids, array_map('intval', $meta_ids));
				}
			}
		}

		$ids = array_values(array_unique(array_filter(array_map('intval', $ids))));
		if (empty($ids)) {
			if ($is_generated) {
				delete_post_meta($post_id, '_dit_ts_trash_managed_attachments');
			}
			return;
		}

		$deleted_count = 0;
		$skipped_count = 0;

		// @MODIFIED 2026-08-30 - 504 fix: budget the synchronous work per request.
		// Any IDs we cannot process in-budget are deferred to Action Scheduler so the
		// HTTP request always finishes within the proxy timeout window.
		$budget       = (int) apply_filters('dit_ts_before_delete_attachment_budget', 25);
		$deferred_ids = array();

		// @MODIFIED 2026-08-30 - 504 fix: IDs that were already validated during the trash
		// step (handle_generated_post_trashed) do not need a second is_attachment_used_elsewhere
		// scan — that decision was made and persisted in _dit_ts_trash_managed_attachments.
		$pre_validated = array();
		if ($is_generated) {
			$stored = get_post_meta($post_id, '_dit_ts_trash_managed_attachments', true);
			if (is_array($stored) && !empty($stored)) {
				foreach ($stored as $sid) {
					$sid = (int) $sid;
					if ($sid > 0) {
						$pre_validated[$sid] = true;
					}
				}
			}
		}

		foreach ($ids as $aid) {
			$aid = (int) $aid;
			if ($aid <= 0) {
				continue;
			}

			if (get_post_status($aid) === false) {
				continue;
			}

			// @MODIFIED 2026-08-30 - 504 fix: respect the per-request budget; defer the rest.
			if ($budget <= 0) {
				$deferred_ids[] = $aid;
				continue;
			}

			// @MODIFIED 2026-08-30 - 504 fix: trust the prior validation done at trash time.
			if (isset($pre_validated[$aid])) {
				wp_delete_attachment($aid, true);
				$deleted_count++;
				$budget--;
				continue;
			}

			$used = \DIT\TrendStudio\Services\Media_Cleanup_Helper::is_attachment_used_elsewhere($aid, array($post_id));
			if ($used > 0) {
				if (get_post_status($aid) === 'trash') {
					\DIT\TrendStudio\Services\Media_Cleanup_Helper::restore_attachment_from_trash($aid);
				} else {
					\DIT\TrendStudio\Services\Media_Cleanup_Helper::detach_attachment($aid);
				}
				$skipped_count++;
				$budget--;
				continue;
			}

			wp_delete_attachment($aid, true);
			$deleted_count++;
			$budget--;
		}

		// @MODIFIED 2026-08-30 - 504 fix: hand off the overflow to Action Scheduler.
		// The leftover attachments are processed in the background so the user's delete
		// request returns well within the proxy timeout. The continuation re-enters the
		// same handler logic with the explicit $deferred_ids list.
		if (!empty($deferred_ids)) {
			if (function_exists('as_schedule_single_action')) {
				as_schedule_single_action(
					time() + 5,
					'dit_ts_continue_attachment_purge',
					array(
						'post_id'  => $post_id,
						'attached' => array_values(array_map('intval', $deferred_ids)),
						'is_generated' => (bool) $is_generated,
						'is_source'    => (bool) $is_source,
					),
					'dit_ts_attachment_purge'
				);
				if (isset($this->logger)) {
					$this->logger->info('before_delete_post: deferred ' . count($deferred_ids) . ' attachment(s) to Action Scheduler', array(
						'post_id' => $post_id,
						'deferred' => count($deferred_ids),
					));
				}
			} else {
				// AS unavailable — best-effort sync fallback. Bounded to avoid 504 even
				// without the scheduler; further overflow is dropped (WP-Cron retry).
				foreach ($deferred_ids as $aid) {
					$aid = (int) $aid;
					if ($aid <= 0 || get_post_status($aid) === false) {
						continue;
					}
					$used = \DIT\TrendStudio\Services\Media_Cleanup_Helper::is_attachment_used_elsewhere($aid, array($post_id));
					if ($used > 0) {
						$skipped_count++;
						continue;
					}
					wp_delete_attachment($aid, true);
					$deleted_count++;
				}
			}
		}

		if ($deleted_count > 0 || $skipped_count > 0) {
			$label = $is_generated ? 'generated' : ($is_source ? 'source' : 'regular');
			$this->logger->info("before_delete_post: Cleaned up attachments for {$label} post {$post_id}", array(
				'deleted' => $deleted_count,
				'skipped_in_use' => $skipped_count,
			));
		}
if ($is_generated) {
			delete_post_meta($post_id, '_dit_ts_trash_managed_attachments');
		}
	}

	/**
	 * Background continuation of attachment purge deferred by handle_generated_post_before_delete()
	 * when the per-request synchronous budget was exhausted. Runs under Action Scheduler so it
	 * does not block the originating HTTP delete request and therefore cannot cause a 504.
	 *
	 * @MODIFIED 2026-08-30 - 504 fix: companion to the budget guard in handle_generated_post_before_delete().
	 *
	 * @param array $payload
	 * @return void
	 */
	public function handle_continue_attachment_purge($payload): void
	{
		if (!is_array($payload)) {
			return;
		}

		$post_id = isset($payload['post_id']) ? (int) $payload['post_id'] : 0;
		$attached = isset($payload['attached']) && is_array($payload['attached']) ? $payload['attached'] : array();

		if ($post_id <= 0 || empty($attached)) {
			return;
		}

		if (!class_exists('DIT\\TrendStudio\\Services\\Media_Cleanup_Helper')) {
			return;
		}

		$deleted_count = 0;
		$skipped_count = 0;

		// Background runs get a larger budget; the HTTP request already spent its share.
		$budget = (int) apply_filters('dit_ts_continue_attachment_purge_budget', 100);

		$index = 0;
		foreach ($attached as $aid) {
			if ($budget <= 0) {
				// Reschedule whatever is left for the next AS tick.
				$remaining = array_values(array_slice($attached, $index));
				if (!empty($remaining) && function_exists('as_schedule_single_action')) {
					as_schedule_single_action(
						time() + 30,
						'dit_ts_continue_attachment_purge',
						array(
							'post_id'  => $post_id,
							'attached' => array_map('intval', $remaining),
							'is_generated' => !empty($payload['is_generated']),
							'is_source'    => !empty($payload['is_source']),
						),
						'dit_ts_attachment_purge'
					);
				}
				break;
			}

			$aid = (int) $aid;
			$index++;
			if ($aid <= 0 || get_post_status($aid) === false) {
				continue;
			}

			$used = \DIT\TrendStudio\Services\Media_Cleanup_Helper::is_attachment_used_elsewhere($aid, array($post_id));
			if ($used > 0) {
				if (get_post_status($aid) === 'trash') {
					\DIT\TrendStudio\Services\Media_Cleanup_Helper::restore_attachment_from_trash($aid);
				} else {
					\DIT\TrendStudio\Services\Media_Cleanup_Helper::detach_attachment($aid);
				}
				$skipped_count++;
				$budget--;
				continue;
			}

			wp_delete_attachment($aid, true);
			$deleted_count++;
			$budget--;
		}

		if (($deleted_count > 0 || $skipped_count > 0) && isset($this->logger)) {
			$this->logger->info('continue_attachment_purge: finished batch for post ' . $post_id, array(
				'deleted'       => $deleted_count,
				'skipped_in_use'=> $skipped_count,
			));
		}
	}

	/**
	 * Register REST API endpoints for Universal Plugin Dashboard
	 *
	 * @return void
	 */
	public function register_rest_endpoints()
	{
		// Only register if REST API is available
		if (!function_exists('register_rest_route')) {
			return;
		}

		// Metrics endpoint
		register_rest_route('wp/v2', '/metrics', [
			'methods'             => 'GET',
			'callback'            => [$this, 'get_metrics'],
			'permission_callback' => [$this, 'verify_dashboard_key'],
		]);

		// Status endpoint
		register_rest_route('wp/v2', '/status', [
			'methods'             => 'GET',
			'callback'            => [$this, 'get_status'],
			'permission_callback' => [$this, 'verify_dashboard_key'],
		]);
	}

	/**
	 * Verify Dashboard API Key
	 *
	 * @param WP_REST_Request $request
	 * @return bool|WP_Error
	 */
	public function verify_dashboard_key($request)
	{
		$api_key = $request->get_header('X-Dashboard-Key');
		$expected_key = get_option('dit_ts_dashboard_api_key', '');

		if (empty($expected_key)) {
			return new \WP_Error('unconfigured', 'Dashboard API key not configured', ['status' => 503]);
		}

		if (empty($api_key) || !hash_equals($expected_key, $api_key)) {
			return new \WP_Error('unauthorized', 'Invalid API key', ['status' => 401]);
		}

		return true;
	}

	/**
	 * REST API: Get plugin metrics for Universal Dashboard
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function get_metrics($request)
	{
		global $wpdb;

		$jobs_table = $wpdb->prefix . 'dit_ts_jobs';

		// Total posts generated (lifetime) — count plugin-generated posts, NOT completed job
		// rows: dit_ts_jobs rows are pruned after 3 days by clean_old_jobs(), which made the
		// old COUNT('completed') a rolling window. Generated posts are marked with
		// '_dit_ts_scheduled'='1' (auto-publish) or '_dit_ts_job_id' (manual publish).
		// @MODIFIED 2026-08-14 - Option A: lifetime article counter decoupled from jobs table.
		$total_posts = $wpdb->get_var(
			"SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p
			 INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
			 WHERE p.post_type = 'post'
			 AND p.post_status NOT IN ('trash', 'auto-draft', 'inherit')
			 AND ((pm.meta_key = '_dit_ts_scheduled' AND pm.meta_value = '1') OR pm.meta_key = '_dit_ts_job_id')"
		);

		// Today's posts (completed today in site timezone)
		$today_start = current_time('Y-m-d 00:00:00');
		$today_posts = $wpdb->get_var($wpdb->prepare(
			"SELECT COUNT(*) FROM {$jobs_table} WHERE status = 'completed' AND completed_at >= %s",
			$today_start
		));

		// Buffer shares today - check _nm_buffer_share_history post meta
		$buffer_shares_today = 0;
		$month_start = date('Y-m-01 00:00:00');
		$buffer_history_rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT pm.meta_value FROM {$wpdb->postmeta} pm
				 INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				 WHERE pm.meta_key = '_nm_buffer_share_history'
				 AND p.post_date >= %s",
				$month_start
			),
			ARRAY_A
		);
		if (!empty($buffer_history_rows)) {
			foreach ($buffer_history_rows as $row) {
				$history = maybe_unserialize($row['meta_value']);
				if (is_array($history)) {
					foreach ($history as $share) {
						$share_date = isset($share['shared_at']) ? date('Y-m-d', strtotime($share['shared_at'])) : '';
						if ($share_date === date('Y-m-d')) {
							$buffer_shares_today++;
						}
					}
				}
			}
		}

		// Recent errors (last 50 failed jobs)
		$errors = $wpdb->get_results($wpdb->prepare(
			"SELECT error_message, completed_at as timestamp FROM {$jobs_table}
			 WHERE status = 'failed' AND error_message != ''
			 ORDER BY completed_at DESC LIMIT 50"
		));

		$error_logs = [];
		foreach ((array) $errors as $error) {
			$error_logs[] = [
				'message'   => $error->error_message,
				'timestamp' => $error->timestamp,
			];
		}

		// Health score based on success rate
		$total_completed = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$jobs_table} WHERE status IN ('completed', 'failed')");
		$total_failed = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$jobs_table} WHERE status = 'failed'");
		$health_score = $total_completed > 0 ? max(0, 100 - round(($total_failed / $total_completed) * 100)) : 100;

		// AI API metrics
		$ai_metrics = [];
		if (class_exists('\\DIT\\TrendStudio\\Infrastructure\\Usage_Tracker')) {
			$ai_metrics = \DIT\TrendStudio\Infrastructure\Usage_Tracker::get_all_stats();
		}

		// Queue stats
		$queue_stats = [];
		if (class_exists('\\DIT\\TrendStudio\\Infrastructure\\Scheduler')) {
			$scheduler = new \DIT\TrendStudio\Infrastructure\Scheduler($this->logger);
			$queue_stats = $scheduler->get_queue_stats();
		}

		// Jetpack Stats (traffic/visitors)
		$traffic_stats = [];
		if (class_exists('\\DIT\\TrendStudio\\Core\\Social_Bootstrap')) {
			$social = $this->get_service('social');
			if ($social && method_exists($social, 'get_site_stats')) {
				$traffic_stats = $social->get_site_stats('day');
			}
		}

		return rest_ensure_response([
			'total_posts_generated' => (int) $total_posts,
			'today_posts'           => (int) $today_posts,
			'buffer_shares_today'   => (int) $buffer_shares_today,
			'error_logs'            => $error_logs,
			'health_score'          => (int) $health_score,
			'last_updated'          => current_time('c'),
			'plugin_version'        => DIT_TS_VERSION,
			'ai_metrics'            => $ai_metrics,
			'queue_stats'           => $queue_stats,
			'traffic'               => $traffic_stats,
		]);
	}

	/**
	 * REST API: Get plugin status for Universal Dashboard
	 *
	 * @param WP_REST_Request $request
	 * @return WP_REST_Response
	 */
	public function get_status($request)
	{
		global $wpdb;

		// Check database connectivity
		$db_status = 'connected';
		try {
			$wpdb->get_var('SELECT 1');
		} catch (\Throwable $e) {
			$db_status = 'error';
		}

		// Check AI provider availability
		$ai_status = 'unknown';
		$ai_details = [];
		if (class_exists('\\DIT\\TrendStudio\\Infrastructure\\AI_Provider_Factory')) {
			$strategy = get_option('dit_ts_ai_strategy', 'gemini');
			$provider = \DIT\TrendStudio\Infrastructure\AI_Provider_Factory::strategy_to_provider($strategy);
			$ai_status = 'available';
			$ai_details = [
				'strategy'  => $strategy,
				'provider'  => $provider,
			];
		}

		// Check scheduler
		$scheduler_status = 'unknown';
		if (class_exists('ActionScheduler')) {
			$scheduler_status = 'active';
		}

		// Plugin version
		$version = DIT_TS_VERSION;

		// Uptime
		$activated_ts = get_option('dit_ts_activated_timestamp', time());
		$uptime = time() - $activated_ts;

		return rest_ensure_response([
			'status'           => 'active',
			'version'          => $version,
			'php_version'      => PHP_VERSION,
			'wp_version'       => get_bloginfo('version'),
			'uptime_seconds'   => $uptime,
			'database'         => $db_status,
			'ai_providers'     => $ai_status,
			'ai_details'       => $ai_details,
			'scheduler'        => $scheduler_status,
			'last_checked'     => current_time('c'),
		]);
	}

	/**
	 * AJAX: Generate Dashboard API Key
	 */
	public function ajax_generate_dashboard_key()
	{
		try {
			check_ajax_referer('dit_ts_nonce', 'nonce');

			if (!current_user_can('manage_options')) {
				throw new \Exception('Insufficient permissions');
			}

			$key = wp_generate_password(32, false);
			update_option('dit_ts_dashboard_api_key', $key, false);

			wp_send_json_success([
				'key' => $key,
				'message' => 'Dashboard API key generated successfully',
			]);
		} catch (\Throwable $e) {
			$this->logger->error('Dashboard key generation failed: ' . $e->getMessage());
			wp_send_json_error([
				'message' => $e->getMessage(),
			]);
		}
	}

}
