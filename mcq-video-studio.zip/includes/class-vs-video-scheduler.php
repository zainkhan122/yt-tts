<?php
/**
 * VS Video Scheduler — Full Auto-Video Generation System
 *
 * Turns the mcq-video-studio bank (fed by the News MCQ Generator plugin's auto-sync)
 * into a scheduled, end-to-end video production pipeline:
 *
 *   1. On a configured schedule, pick fresh/unused questions from configured topics
 *      (optionally filtered by exam) using the existing reserve_questions() round-robin
 *      (dedup via usage_count).
 *   2. Build a full job with ALL render settings (template, cover, hook, CTA, logo,
 *      music, voiceover, SFX, format) so rendered videos match the Studio/Content
 *      Planner exactly.
 *   3. Set publish_at for the existing publish scheduler (Buffer distribution).
 *   4. The existing automation engine renders the job (headless/server) and the
 *      publish scheduler pushes to Buffer at publish_at.
 *   5. On publish, back-link the video URL to the source article(s)/MCQ page(s) so
 *      articles embed the Short and every social post links back to the site.
 *
 * This is the "full system" (not a band-aid) — a single source of truth config option
 * (`mcqvs_auto_video_config`) consumed by this scheduler, and one cron hook.
 *
 * @package MCQ_Video_Studio
 * @subpackage Includes
 * @since 1.5.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class VS_Video_Scheduler {

	const CONFIG_KEY   = 'mcqvs_auto_video_config';
	const CRON_HOOK    = 'vs_video_schedule_cron';
	const MENU_SLUG    = 'mcqvs-video-scheduler';
	const OPT_INSTALL  = 'mcqvs_video_scheduler_installed';

	/**
	 * Singleton.
	 */
	private static $instance = null;

	public static function init() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'init', array( $this, 'register_cron' ) );
		add_action( self::CRON_HOOK, array( $this, 'run_scheduled_build' ) );
		// @FIX 1.5.0: The submenu is registered in class-vs-core.php::add_menu_page() so it
		// lands right after Content Planner. We no longer self-register (removed) to avoid
		// a duplicate menu item at the end. We keep register_settings + the render method.
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		// Back-link when a job is published (fires from automation publish scheduler).
		add_action( 'mcqvs_video_job_published', array( $this, 'link_back_on_publish' ), 10, 2 );
		// Manual "run now" AJAX.
		add_action( 'wp_ajax_mcqvs_video_scheduler_run', array( $this, 'ajax_run_now' ) );
	}

	/**
	 * Get the full scheduler config (single source of truth).
	 */
	public static function get_config() {
		$defaults = array(
			'enabled'         => 0,
			'schedule_times'  => array( '06:00' ), // site-time HH:MM
			'topics'          => array(),           // bank topic IDs (empty = all with enough questions)
			'exams'           => array(),           // exam slugs (optional filter; bank is topic-keyed, kept for forward-compat)
			'qty_per_video'   => 5,
			'videos_per_run'  => 1,
			'format'          => 'shorts',          // shorts | youtube
			'template'        => 'trivia',
			'cover_config'    => array( 'enabled' => false ),
			'hook'            => '',
			'hookVisible'     => 1,
			'ctaText'         => 'Comment your score 👇',
			'ctaStyle'        => 'score',
			'brandName'       => '',
			'quizName'        => '',
			'logoPath'        => '',
			'logoPosition'    => 'all',
			'music'           => '',
			'bg_video'        => '',
			'save_mode'       => 'local',           // local | r2 | r2_buffer
			'buffer_channels' => array(),
			'publish_mode'    => 'now',             // now | queue | draft
			'publish_time'    => '09:00',
			'voiceover'       => null,              // null = use studio defaults
			'sfxEnabled'      => 1,
			'showExplanation' => 0,
		);

		$cfg = get_option( self::CONFIG_KEY, array() );
		if ( ! is_array( $cfg ) ) {
			$cfg = array();
		}
		$merged = wp_parse_args( $cfg, $defaults );
		// Normalize arrays.
		foreach ( array( 'schedule_times', 'topics', 'exams', 'buffer_channels' ) as $arr_key ) {
			if ( ! is_array( $merged[ $arr_key ] ) ) {
				$merged[ $arr_key ] = array();
			}
		}
		return $merged;
	}

	/**
	 * Register the recurring cron hook at the configured times.
	 *
	 * Uses WP cron (wp_schedule_event) at each HH:MM in the site timezone.
	 * Only rebuilds events when the config fingerprint changed since the last rebuild
	 * (or when no events exist yet) — NOT on every page load. This avoids the cost and
	 * risk of clearing/rescheduling cron on every request.
	 */
	public function register_cron() {
		$cfg      = self::get_config();
		$enabled  = ! empty( $cfg['enabled'] ) && ! empty( $cfg['schedule_times'] );
		$times    = $enabled ? array_values( array_unique( $cfg['schedule_times'] ) ) : array();

		// Fingerprint = enabled flag + sorted times. Rebuild only when it changed.
		sort( $times );
		$fingerprint = ( $enabled ? '1' : '0' ) . ':' . implode( ',', $times );
		$last        = get_option( 'mcqvs_video_scheduler_fp', '' );

		// Determine if we already have the exact set of scheduled events (avoids churn).
		$need_rebuild = ( $fingerprint !== $last );
		if ( ! $need_rebuild ) {
			$cron = _get_cron_array();
			$found = 0;
			foreach ( (array) $cron as $ts => $jobs ) {
				if ( is_array( $jobs ) && isset( $jobs[ self::CRON_HOOK ] ) ) {
					$found += count( $jobs[ self::CRON_HOOK ] );
				}
			}
			// If events are missing but we expect some, rebuild.
			$need_rebuild = ( $found === 0 && $enabled ) || ( $found > 0 && ! $enabled );
		}

		if ( $need_rebuild ) {
			// Clear existing events for this hook.
			$existing = _get_cron_array();
			foreach ( (array) $existing as $ts => $jobs ) {
				if ( ! is_array( $jobs ) ) {
					continue;
				}
				foreach ( $jobs as $hook => $instances ) {
					if ( $hook === self::CRON_HOOK ) {
						foreach ( (array) $instances as $key => $data ) {
							wp_unschedule_event( $ts, $hook, $data['args'] ?? array() );
						}
					}
				}
			}

			if ( $enabled ) {
				try {
					$tz = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'UTC' );
				} catch ( Exception $e ) {
					$tz = new DateTimeZone( 'UTC' );
				}
				foreach ( $times as $hhmm ) {
					try {
						$now    = time();
						$target = new DateTime( 'today ' . $hhmm . ':00', $tz );
						if ( $target->getTimestamp() <= $now ) {
							$target->modify( '+1 day' );
						}
						$seconds = max( 60, $target->getTimestamp() - $now );
						if ( ! wp_next_scheduled( self::CRON_HOOK, array( $hhmm ) ) ) {
							wp_schedule_event( time() + $seconds, 'daily', self::CRON_HOOK, array( $hhmm ) );
						}
					} catch ( Exception $e ) {
						continue;
					}
				}
			}

			update_option( 'mcqvs_video_scheduler_fp', $fingerprint, false );
		}
	}

	/**
	 * The cron callback. Builds the configured number of video jobs from the bank.
	 *
	 * @param string $hhmm Optional scheduled time arg.
	 */
	public function run_scheduled_build( $hhmm = null ) {
		$this->build_video_jobs();
	}

	/**
	 * Core: build video jobs from configured topics using fresh (unused) bank questions.
	 *
	 * @return array { created, errors, message }
	 */
	public function build_video_jobs() {
		$cfg = self::get_config();

		if ( function_exists( 'mcqvs_is_global_stopped' ) && mcqvs_is_global_stopped() ) {
			return array( 'created' => 0, 'errors' => 1, 'message' => 'Global STOP active.' );
		}
		if ( empty( $cfg['enabled'] ) ) {
			return array( 'created' => 0, 'errors' => 0, 'message' => 'Video scheduler disabled.' );
		}

		$api   = VS_API_Client::init();
		$repo  = VS_Job_Repository::init();
		$qty   = max( 3, min( 10, (int) $cfg['qty_per_video'] ) );
		$max   = max( 1, (int) $cfg['videos_per_run'] );

		// Resolve topics to build from.
		$topics = array();
		if ( ! empty( $cfg['topics'] ) ) {
			foreach ( $cfg['topics'] as $tid ) {
				$tid = (int) $tid;
				if ( $tid > 0 ) {
					$topics[] = $tid;
				}
			}
		} else {
			// All bank topics that have at least `qty` approved questions.
			$all = $api->get_sources( 'topic' );
			if ( ! is_wp_error( $all ) ) {
				foreach ( $all as $t ) {
					if ( (int) $t['count'] >= $qty ) {
						$topics[] = (int) $t['id'];
					}
				}
			}
		}

		if ( empty( $topics ) ) {
			return array( 'created' => 0, 'errors' => 0, 'message' => 'No topics configured/available with enough questions.' );
		}

		// Studio render defaults (single source of truth for branding/voiceover).
		$studio_defaults = class_exists( 'VS_Content_Planner' )
			? VS_Content_Planner::get_studio_render_defaults()
			: array(
				'hookText'      => 'Can you score 5/5?',
				'hookVisible'   => true,
				'ctaText'       => 'Comment your score 👇',
				'ctaStyle'      => 'score',
				'brandName'     => get_bloginfo( 'name' ),
				'quizName'      => '',
				'logoPath'      => '',
				'logoPosition'  => 'all',
				'voiceover'     => array( 'enabled' => true, 'provider' => 'edge', 'voice' => ( class_exists( 'VS_Settings' ) ? VS_Settings::get_next_rotation_voice() : 'en-US-AriaNeural' ), 'rate' => 1.2, 'pitch' => 0, 'speakHook' => true, 'speakOptions' => true, 'speakAnswer' => true, 'speakCta' => false, 'answerPhrase' => 'correct answer is' ),
				'sfxEnabled'    => true,
				'showExplanation' => false,
			);

		$created = 0;
		$errors  = 0;
		$topic_idx = 0;

		while ( $created < $max && $topic_idx < count( $topics ) ) {
			$topic_id = $topics[ $topic_idx ];
			$topic_idx++;

			// Reserve fresh questions (round-robin by usage_count = least-used first).
			$job_ref = 'auto_' . uniqid();
			$reserved = $api->reserve_questions( $topic_id, null, $qty, $job_ref );
			if ( is_wp_error( $reserved ) ) {
				$errors++;
				continue;
			}

			$topic_name = 'Topic #' . $topic_id;
			if ( class_exists( 'VS_MCQ_Repository' ) ) {
				$t = VS_MCQ_Repository::get_instance()->get_topic( $topic_id );
				if ( $t && ! empty( $t['name'] ) ) {
					$topic_name = $t['name'];
				}
			}

			$job_settings = $this->build_job_settings( $cfg, $studio_defaults, $topic_name );

			// Publish scheduling.
			$publish_at = null;
			$status     = VS_Job_Status::READY_FOR_RENDER;
			if ( $cfg['publish_mode'] === 'queue' ) {
				// Schedule at next occurrence of publish_time.
				$publish_at = $this->next_publish_at( $cfg['publish_time'] );
				$status     = VS_Job_Status::READY_FOR_RENDER; // render now, publish later
			}
			// 'draft' => save as a job that is NOT rendered/published yet (manual release). We
			// still create as READY_FOR_RENDER so it renders; publish scheduler only pushes
			// jobs whose publish_at has arrived, so draft jobs won't push until publish_at set.

			$job_settings['_mcqvs_scheduler'] = true;
			$job_settings['publish_mode']     = $cfg['publish_mode'];
			$job_settings['_publish_computed_at'] = gmdate( 'Y-m-d H:i:s' );

			$model_provider = null;
			$model_id       = null;
			if ( class_exists( 'VS_Provider_Registry' ) ) {
				$rotation = VS_Provider_Registry::get_instance()->get_next_model( 'automation' );
				$model_provider = $rotation['provider'];
				$model_id       = $rotation['model'];
			}

			$job_id = $repo->create_job(
				array(
					'topic_id'       => $topic_id,
					'exam_id'        => null,
					'question_count' => count( $reserved ),
					'platform'       => 'all',
					'status'         => $status,
					'quiz_data'      => wp_json_encode( $reserved ),
					'settings'       => wp_json_encode( $job_settings ),
					'scheduled_at'   => gmdate( 'Y-m-d H:i:s' ),
					'model_provider' => $model_provider,
					'model_id'       => $model_id,
				)
			);

			if ( is_wp_error( $job_id ) ) {
				$errors++;
				if ( class_exists( 'VS_Error_Logger' ) ) {
					VS_Error_Logger::get_instance()->log( 'Video Scheduler: create_job failed for topic ' . $topic_id . ': ' . $job_id->get_error_message(), 'error' );
				}
				continue;
			}

			// Persist publish_at for the publish scheduler.
			if ( $publish_at ) {
				$repo->update_publish_at( $job_id, $publish_at );
				$job_settings['_publish_at'] = $publish_at;
				$repo->update_job_fields( $job_id, array( 'settings' => wp_json_encode( $job_settings ) ) );
			}

			$created++;

			if ( class_exists( 'VS_Error_Logger' ) ) {
				VS_Error_Logger::get_instance()->log( 'Video Scheduler: created job ' . $job_id . ' for topic "' . $topic_name . '" (' . count( $reserved ) . ' Q, ' . $cfg['format'] . '), publish=' . ( $publish_at ? $publish_at : 'now' ), 'info' );
			}
		}

		$message = "Video Scheduler run: created {$created} job(s), {$errors} error(s).";
		if ( class_exists( 'VS_Error_Logger' ) ) {
			VS_Error_Logger::get_instance()->log( $message, 'info' );
		}
		return array( 'created' => $created, 'errors' => $errors, 'message' => $message );
	}

	/**
	 * Build a full job settings array from scheduler config + studio defaults.
	 */
	private function build_job_settings( $cfg, $studio_defaults, $topic_name ) {
		$voiceover = ! empty( $cfg['voiceover'] ) && is_array( $cfg['voiceover'] )
			? $cfg['voiceover']
			: $studio_defaults['voiceover'];

		$cover_config = ( isset( $cfg['cover_config'] ) && is_array( $cfg['cover_config'] ) )
			? $cfg['cover_config']
			: array();
		if ( ! isset( $cover_config['enabled'] ) ) {
			$cover_config['enabled'] = false;
		}

		$hook = ! empty( $cfg['hook'] ) ? $cfg['hook'] : $studio_defaults['hookText'];

		return array(
			'topic_name'    => $topic_name,
			'topic_base'    => $topic_name,
			// Render format (shorts/youtube) — drives resolution + fps server-side.
			'save_mode_video_format' => ( $cfg['format'] === 'youtube' ? 'youtube' : 'shorts' ),
			'videoFormat'   => ( $cfg['format'] === 'youtube' ? 'youtube' : 'shorts' ),
			'template'      => ! empty( $cfg['template'] ) ? $cfg['template'] : 'trivia',
			'currentTemplate' => ! empty( $cfg['template'] ) ? $cfg['template'] : 'trivia',
			'font'          => '',
			'music'         => isset( $cfg['music'] ) ? $cfg['music'] : '',
			'bg_video'      => isset( $cfg['bg_video'] ) ? $cfg['bg_video'] : '',
			'save_mode'     => in_array( $cfg['save_mode'], array( 'local', 'r2', 'r2_buffer' ), true ) ? $cfg['save_mode'] : 'local',
			'buffer_channels' => is_array( $cfg['buffer_channels'] ) ? $cfg['buffer_channels'] : array(),
			'hookText'      => $hook,
			'hookVisible'   => ! empty( $cfg['hookVisible'] ),
			'ctaText'       => ! empty( $cfg['ctaText'] ) ? $cfg['ctaText'] : $studio_defaults['ctaText'],
			'ctaStyle'      => ! empty( $cfg['ctaStyle'] ) ? $cfg['ctaStyle'] : 'score',
			'brandName'     => ! empty( $cfg['brandName'] ) ? $cfg['brandName'] : $studio_defaults['brandName'],
			'quizName'      => ! empty( $cfg['quizName'] ) ? $cfg['quizName'] : $topic_name,
			// @FIX 1.5.0 (logo SSOT): the logo comes ONLY from the Asset Tab (Studio
			// branding), never entered here. Force the studio default so the scheduler
			// video matches the Asset Tab logo exactly, regardless of any stale config.
			'logoPath'      => $studio_defaults['logoPath'],
			'logoPosition'  => ! empty( $studio_defaults['logoPosition'] ) ? $studio_defaults['logoPosition'] : 'all',
			'voiceover'     => $voiceover,
			'sfxEnabled'    => ! empty( $cfg['sfxEnabled'] ),
			'showExplanation' => ! empty( $cfg['showExplanation'] ),
			'cover_config'  => $cover_config,
		);
	}

	/**
	 * Compute next publish timestamp for a HH:MM in site timezone.
	 */
	private function next_publish_at( $hhmm ) {
		$hhmm = preg_replace( '/[^0-9:]/', '', (string) $hhmm );
		if ( ! preg_match( '/^\d{1,2}:\d{2}$/', $hhmm ) ) {
			$hhmm = '09:00';
		}
		try {
			$tz = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'UTC' );
		} catch ( Exception $e ) {
			$tz = new DateTimeZone( 'UTC' );
		}
		try {
			$target = new DateTime( 'today ' . $hhmm . ':00', $tz );
			$now    = new DateTime( 'now', $tz );
			if ( $target <= $now ) {
				$target->modify( '+1 day' );
			}
			$target->setTimezone( new DateTimeZone( 'UTC' ) );
			return $target->format( 'Y-m-d H:i:s' );
		} catch ( Exception $e ) {
			return null;
		}
	}

	/**
	 * Back-link a published video to the source article/MCQ pages.
	 *
	 * When the publish scheduler successfully pushes a job to Buffer, it fires
	 * `mcqvs_video_job_published($job_id, $video_url)`. We read the job's questions,
	 * map each to its source MCQ post (bank.parent_post_id) and the roundup article
	 * that referenced it (_nm_article_mcqs), then store the video URL back onto the
	 * article (_nm_article_short_url) so the article embeds the Short and links out.
	 *
	 * @param string $job_id
	 * @param string $video_url
	 */
	public function link_back_on_publish( $job_id, $video_url ) {
		$job_id = (string) $job_id;
		if ( $job_id === '' ) {
			return;
		}
		$repo = VS_Job_Repository::init();
		$job  = $repo->get_job( $job_id );
		if ( ! $job ) {
			return;
		}

		// Resolve full question objects (bank rows carry parent_post_id).
		$quiz = VS_Job_Repository::normalize_quiz_data(
			$job['quiz_data'] ?? '',
			class_exists( 'VS_MCQ_Repository' ) ? VS_MCQ_Repository::get_instance() : null
		);

		$source_post_ids = array();
		foreach ( $quiz as $q ) {
			if ( ! empty( $q['parent_post_id'] ) ) {
				$source_post_ids[] = (int) $q['parent_post_id'];
			}
		}
		$source_post_ids = array_values( array_unique( array_filter( $source_post_ids ) ) );
		if ( empty( $source_post_ids ) ) {
			return;
		}

		// Find roundup articles that reference any of these source MCQ posts.
		// Article stores _nm_article_mcqs = array of MCQ post IDs.
		$articles = get_posts(
			array(
				'post_type'      => 'post',
				'post_status'    => array( 'publish', 'draft', 'future', 'pending' ),
				'posts_per_page' => -1,
				'meta_key'       => '_nm_article_generated',
				'meta_value'     => 'yes',
				'fields'         => 'ids',
			)
		);
		foreach ( $articles as $article_id ) {
			$mcq_ids = get_post_meta( $article_id, '_nm_article_mcqs', true );
			if ( ! is_array( $mcq_ids ) ) {
				continue;
			}
			$intersect = array_intersect( array_map( 'intval', $mcq_ids ), $source_post_ids );
			if ( ! empty( $intersect ) ) {
				// Store the video URL so the article embeds the Short.
				update_post_meta( $article_id, '_nm_article_short_url', esc_url_raw( $video_url ) );
			}
		}
	}

	/**
	 * Register the scheduler admin page (under Video Studio menu).
	 */
	public function register_admin_page() {
		add_submenu_page(
			'mcqvs-dashboard',
			__( 'Video Scheduler', 'mcq-video-studio' ),
			__( 'Video Scheduler', 'mcq-video-studio' ),
			'manage_options',
			self::MENU_SLUG,
			array( $this, 'render_admin_page' )
		);
	}

	/**
	 * Register the config option.
	 */
	public function register_settings() {
		register_setting( 'mcqvs_video_scheduler_group', self::CONFIG_KEY, array( $this, 'sanitize_config' ) );
	}

	/**
	 * Sanitize the config array.
	 */
	public function sanitize_config( $input ) {
		if ( ! is_array( $input ) ) {
			return array();
		}
		$cfg = self::get_config();

		$cfg['enabled']         = ! empty( $input['enabled'] ) ? 1 : 0;
		$cfg['schedule_times']  = array();
		if ( ! empty( $input['schedule_times'] ) && is_array( $input['schedule_times'] ) ) {
			foreach ( $input['schedule_times'] as $t ) {
				$t = preg_replace( '/[^0-9:]/', '', (string) $t );
				if ( preg_match( '/^\d{1,2}:\d{2}$/', $t ) ) {
					$cfg['schedule_times'][] = $t;
				}
			}
		}
		$cfg['topics'] = array();
		if ( ! empty( $input['topics'] ) && is_array( $input['topics'] ) ) {
			$cfg['topics'] = array_values( array_map( 'absint', array_filter( array_map( 'absint', $input['topics'] ) ) ) );
		}
		$cfg['exams'] = array();
		if ( ! empty( $input['exams'] ) && is_array( $input['exams'] ) ) {
			$cfg['exams'] = array_values( array_filter( array_map( 'sanitize_key', $input['exams'] ) ) );
		}
		$cfg['qty_per_video']  = max( 3, min( 10, (int) ( $input['qty_per_video'] ?? 5 ) ) );
		$cfg['videos_per_run'] = max( 1, min( 20, (int) ( $input['videos_per_run'] ?? 1 ) ) );
		$cfg['format']         = ( ( $input['format'] ?? 'shorts' ) === 'youtube' ) ? 'youtube' : 'shorts';
		$cfg['template']       = sanitize_key( $input['template'] ?? 'trivia' );
		$cfg['hook']           = sanitize_text_field( $input['hook'] ?? '' );
		$cfg['hookVisible']    = ! empty( $input['hookVisible'] ) ? 1 : 0;
		$cfg['ctaText']        = sanitize_text_field( $input['ctaText'] ?? 'Comment your score 👇' );
		$cfg['ctaStyle']       = sanitize_key( $input['ctaStyle'] ?? 'score' );
		$cfg['brandName']      = sanitize_text_field( $input['brandName'] ?? '' );
		$cfg['quizName']       = sanitize_text_field( $input['quizName'] ?? '' );
		$cfg['logoPath']       = esc_url_raw( $input['logoPath'] ?? '' );
		$cfg['logoPosition']   = sanitize_key( $input['logoPosition'] ?? 'all' );
		$cfg['music']          = sanitize_text_field( $input['music'] ?? '' );
		$cfg['bg_video']       = sanitize_text_field( $input['bg_video'] ?? '' );
		$save_mode_in = isset( $input['save_mode'] ) ? sanitize_key( $input['save_mode'] ) : 'local';
		$cfg['save_mode'] = in_array( $save_mode_in, array( 'local', 'r2', 'r2_buffer' ), true ) ? $save_mode_in : 'local';
		$cfg['buffer_channels'] = array();
		if ( ! empty( $input['buffer_channels'] ) && is_array( $input['buffer_channels'] ) ) {
			$cfg['buffer_channels'] = array_values( array_filter( array_map( 'sanitize_text_field', $input['buffer_channels'] ) ) );
		}
		$cfg['publish_mode'] = in_array( ( $input['publish_mode'] ?? 'now' ), array( 'now', 'queue', 'draft' ), true ) ? sanitize_key( $input['publish_mode'] ) : 'now';
		$cfg['publish_time'] = preg_replace( '/[^0-9:]/', '', (string) ( $input['publish_time'] ?? '09:00' ) );
		if ( ! preg_match( '/^\d{1,2}:\d{2}$/', $cfg['publish_time'] ) ) {
			$cfg['publish_time'] = '09:00';
		}
		$cfg['voiceover']       = ( ! empty( $input['voiceover'] ) && is_array( $input['voiceover'] ) ) ? $input['voiceover'] : null;
		$cfg['sfxEnabled']      = ! empty( $input['sfxEnabled'] ) ? 1 : 0;
		$cfg['showExplanation'] = ! empty( $input['showExplanation'] ) ? 1 : 0;

		// @FIX 1.5.0 (cover tick): the cover_config checkbox was never read back from
		// $input, so ticking "Show cover page" did NOT persist. Now we read it. Because an
		// unchecked checkbox submits no value, presence of the key means it was ticked.
		$cover_input = ( isset( $input['cover_config'] ) && is_array( $input['cover_config'] ) ) ? $input['cover_config'] : array();
		$cover_base  = ( isset( $cfg['cover_config'] ) && is_array( $cfg['cover_config'] ) ) ? $cfg['cover_config'] : array();
		$cfg['cover_config']            = $cover_base;
		$cfg['cover_config']['enabled'] = ! empty( $cover_input['enabled'] ) ? true : false;

		// Rebuild cron on next init.
		update_option( 'mcqvs_video_scheduler_config_updated', time() );
		return $cfg;
	}

	/**
	 * AJAX: manual "Run Now" — build video jobs immediately.
	 */
	public function ajax_run_now() {
		check_ajax_referer( 'mcqvs_video_scheduler_run', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Access denied' );
		}
		$result = $this->build_video_jobs();
		wp_send_json_success( $result );
	}

	/**
	 * Render the admin config page.
	 */
	public function render_admin_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$cfg = self::get_config();
		$api = VS_API_Client::init();
		$sources = $api->get_sources( 'topic' );
		?>
		<div class="wrap">
			<h1>🎬 Video Scheduler — Auto Video Generation</h1>
			<p>Generate videos automatically from the question bank (fed by the News MCQ Generator plugin), on your schedule, with full render settings, then distribute to your social channels via Buffer.</p>
			<form method="post" action="options.php">
				<?php settings_fields( 'mcqvs_video_scheduler_group' ); ?>
				<table class="form-table">
					<tr>
						<th scope="row">Enable Scheduler</th>
						<td><label><input type="checkbox" name="mcqvs_auto_video_config[enabled]" value="1" <?php checked( $cfg['enabled'], 1 ); ?>> Enable scheduled video generation</label></td>
					</tr>
					<tr>
						<th scope="row">Schedule Times</th>
						<td>
							<?php for ( $i = 0; $i < 4; $i++ ) :
								$val = $cfg['schedule_times'][ $i ] ?? ''; ?>
								<input type="text" name="mcqvs_auto_video_config[schedule_times][]" value="<?php echo esc_attr( $val ); ?>" placeholder="HH:MM (e.g. 06:00)" class="small-text">
							<?php endfor; ?>
							<p class="description">Run times in your site timezone (up to 4). Leave blank to disable that slot.</p>
						</td>
					</tr>
					<tr>
						<th scope="row">Source Topics</th>
						<td>
							<div style="max-height:160px;overflow-y:auto;border:1px solid #ccd0d4;padding:10px;background:#fff;">
								<?php
								if ( is_wp_error( $sources ) || empty( $sources ) ) {
									echo '<p>No topics in the bank yet. Auto-sync MCQs from the News MCQ Generator first, or generate in Content Planner.</p>';
								} else {
									foreach ( $sources as $t ) {
										$checked = in_array( (int) $t['id'], $cfg['topics'] );
										echo '<label style="display:block;margin-bottom:4px;"><input type="checkbox" name="mcqvs_auto_video_config[topics][]" value="' . esc_attr( $t['id'] ) . '" ' . checked( $checked, true, false ) . '> ' . esc_html( $t['name'] ) . ' <code style="opacity:.7;">(' . (int) $t['count'] . ')</code></label>';
									}
								}
								?>
							</div>
							<p class="description">Select which topics to pull questions from. Leave all unchecked to auto-select any topic with enough questions.</p>
						</td>
					</tr>
					<tr>
						<th scope="row">Questions Per Video</th>
						<td><input type="number" name="mcqvs_auto_video_config[qty_per_video]" value="<?php echo esc_attr( $cfg['qty_per_video'] ); ?>" min="3" max="10" class="small-text"> <span class="description">(3–10; 3–5 recommended for Shorts)</span></td>
					</tr>
					<tr>
						<th scope="row">Videos Per Run</th>
						<td><input type="number" name="mcqvs_auto_video_config[videos_per_run]" value="<?php echo esc_attr( $cfg['videos_per_run'] ); ?>" min="1" max="20" class="small-text"></td>
					</tr>
					<tr>
						<th scope="row">Video Format</th>
						<td>
							<select name="mcqvs_auto_video_config[format]">
								<option value="shorts" <?php selected( $cfg['format'], 'shorts' ); ?>>Shorts (1080×1920)</option>
								<option value="youtube" <?php selected( $cfg['format'], 'youtube' ); ?>>YouTube (1920×1080)</option>
							</select>
						</td>
					</tr>
					<tr>
						<th scope="row">Template</th>
						<td>
							<select name="mcqvs_auto_video_config[template]">
								<?php
								$templates = array( 'trivia' => 'General Trivia', 'corporate' => 'Corporate', 'elegant' => 'Elegant', 'neon' => 'Neon Nights', 'science' => 'Science Lab', 'history' => 'History', 'space' => 'Space', 'nature' => 'Nature', 'tech' => 'Tech Mastery', 'sports' => 'Sports Arena', 'retro80s' => 'Retro 80s', 'cyberpunk' => 'Cyberpunk', 'classroom' => 'Classroom' );
								foreach ( $templates as $id => $name ) {
									echo '<option value="' . esc_attr( $id ) . '" ' . selected( $cfg['template'], $id, false ) . '>' . esc_html( $name ) . '</option>';
								}
								?>
							</select>
						</td>
					</tr>
					<tr>
						<th scope="row">Cover Page</th>
						<td><label><input type="checkbox" name="mcqvs_auto_video_config[cover_config][enabled]" value="1" <?php checked( ! empty( $cfg['cover_config']['enabled'] ), true ); ?>> Show cover page (thumbnail card)</label></td>
					</tr>
					<tr>
						<th scope="row">Hook Text</th>
						<td><input type="text" name="mcqvs_auto_video_config[hook]" value="<?php echo esc_attr( $cfg['hook'] ); ?>" class="regular-text" placeholder="e.g. Can you score 5/5?"></td>
					</tr>
					<tr>
						<th scope="row">Show Hook On Video</th>
						<td><label><input type="checkbox" name="mcqvs_auto_video_config[hookVisible]" value="1" <?php checked( $cfg['hookVisible'], 1 ); ?>> Yes</label></td>
					</tr>
					<tr>
						<th scope="row">CTA Text</th>
						<td><input type="text" name="mcqvs_auto_video_config[ctaText]" value="<?php echo esc_attr( $cfg['ctaText'] ); ?>" class="regular-text"></td>
					</tr>
					<tr>
						<th scope="row">CTA Style</th>
						<td><input type="text" name="mcqvs_auto_video_config[ctaStyle]" value="<?php echo esc_attr( $cfg['ctaStyle'] ); ?>" class="regular-text"></td>
					</tr>
					<tr>
						<th scope="row">Brand Name</th>
						<td><input type="text" name="mcqvs_auto_video_config[brandName]" value="<?php echo esc_attr( $cfg['brandName'] ); ?>" class="regular-text"></td>
					</tr>
					<tr>
						<th scope="row">Quiz Name</th>
						<td><input type="text" name="mcqvs_auto_video_config[quizName]" value="<?php echo esc_attr( $cfg['quizName'] ); ?>" class="regular-text" placeholder="Defaults to topic name"></td>
					</tr>
					<tr>
						<th scope="row">Logo</th>
						<td>
							<?php
							// @FIX 1.5.0 (logo SSOT): logo is taken from the Asset Tab (Studio
							// branding) automatically — no input needed here. Show a preview so
							// the user can confirm which logo will be used.
							$sched_logo = '';
							if ( class_exists( 'VS_Content_Planner' ) && method_exists( 'VS_Content_Planner', 'get_studio_render_defaults' ) ) {
								$sd = VS_Content_Planner::get_studio_render_defaults();
								$sched_logo = ! empty( $sd['logoPath'] ) ? $sd['logoPath'] : '';
							}
							if ( $sched_logo ) :
								?>
								<img src="<?php echo esc_url( $sched_logo ); ?>" alt="Brand logo" style="max-height:60px;max-width:120px;border:1px solid #ccd0d4;border-radius:6px;padding:4px;background:#fff;">
								<p class="description">Logo is used automatically from the <strong>Asset Tab</strong> (Settings → Assets).</p>
							<?php else : ?>
								<p class="description">No logo set in the <strong>Asset Tab</strong> (Settings → Assets). Add one there; it will be used automatically in rendered videos.</p>
							<?php endif; ?>
						</td>
					</tr>
					<tr>
						<th scope="row">Save Mode</th>
						<td>
							<select name="mcqvs_auto_video_config[save_mode]">
								<option value="local" <?php selected( $cfg['save_mode'], 'local' ); ?>>Download Locally</option>
								<option value="r2" <?php selected( $cfg['save_mode'], 'r2' ); ?>>Upload to R2</option>
								<option value="r2_buffer" <?php selected( $cfg['save_mode'], 'r2_buffer' ); ?>>R2 + Buffer</option>
							</select>
						</td>
					</tr>
					<tr>
						<th scope="row">Publish Mode</th>
						<td>
							<select name="mcqvs_auto_video_config[publish_mode]">
								<option value="now" <?php selected( $cfg['publish_mode'], 'now' ); ?>>Publish ASAP</option>
								<option value="queue" <?php selected( $cfg['publish_mode'], 'queue' ); ?>>Schedule for a time</option>
								<option value="draft" <?php selected( $cfg['publish_mode'], 'draft' ); ?>>Draft (review first)</option>
							</select>
							<p class="description">When 'Schedule for a time' is selected, videos publish at the Publish Time below.</p>
						</td>
					</tr>
					<tr>
						<th scope="row">Publish Time</th>
						<td><input type="text" name="mcqvs_auto_video_config[publish_time]" value="<?php echo esc_attr( $cfg['publish_time'] ); ?>" class="small-text" placeholder="HH:MM"></td>
					</tr>
				</table>
				<?php submit_button( 'Save Scheduler' ); ?>
			</form>

			<hr>
			<h2>⚡ Run Now</h2>
			<p>Immediately build the configured number of video jobs from the selected topics.</p>
			<button type="button" id="mcqvs-vs-run" class="button button-primary" data-nonce="<?php echo esc_attr( wp_create_nonce( 'mcqvs_video_scheduler_run' ) ); ?>">Run Scheduler Now</button>
			<span id="mcqvs-vs-result" style="margin-left:10px;"></span>
			<script>
			jQuery(function($){
				$('#mcqvs-vs-run').on('click', function(){
					var btn=$(this), sp=$('#mcqvs-vs-result');
					btn.prop('disabled',true); sp.text('Running...');
					$.post(ajaxurl, { action:'mcqvs_video_scheduler_run', nonce: btn.data('nonce') })
					  .done(function(r){ sp.text(r && r.success ? (r.data.message||'Done') : 'Error: '+(r&&r.data||'unknown')); })
					  .fail(function(){ sp.text('Server error'); })
					  .always(function(){ btn.prop('disabled',false); });
				});
			});
			</script>
		</div>
		<?php
	}
}
