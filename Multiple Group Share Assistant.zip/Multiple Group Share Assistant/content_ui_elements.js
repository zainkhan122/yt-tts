// content_ui_elements.js - In-page UI elements (buttons, checkboxes)
(function() {
  'use strict';

  // Initialize Namespace
  window.ShareUnlimited = window.ShareUnlimited || {};
  window.ShareUnlimited.UI = window.ShareUnlimited.UI || {};
  
  const UI = window.ShareUnlimited.UI;
  // Core will be available as window.ShareUnlimited.Core

  /**
   * Keeps the toolbar's Presets button live-synced with chrome.storage, no matter
   * where a preset was created (this tab's Save-Preset dialog, the popup, or
   * another tab). Without this, the button only reflected storage at the moment
   * the toolbar was built — a first preset never appeared until the dialog was
   * closed and reopened, and a badge count went stale immediately after.
   * Idempotent: safe to call on every 'groupPresets' storage change, whether or
   * not the toolbar is currently mounted.
   */
  function syncGroupPresetsButton() {
    chrome.storage.local.get(['groupPresets'], (result) => {
      const presets = result.groupPresets || [];
      const existing = document.getElementById('share-unlimited-group-presets-btn');

      if (presets.length === 0) {
        if (existing) existing.remove();
        return;
      }

      const html = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;"><path d="M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z"/><path d="m22 17.65-9.17 4.16a2 2 0 0 1-1.66 0L2 17.65"/><path d="m22 12.65-9.17 4.16a2 2 0 0 1-1.66 0L2 12.65"/></svg> Presets <span class="su-badge">${presets.length}</span>`;

      if (existing) {
        existing.innerHTML = html;
        return;
      }

      // No button yet — only add it if the toolbar is actually mounted right
      // now; otherwise the next dialog open already builds it fresh from storage.
      const toolbar = document.getElementById('share-unlimited-action-toolbar');
      if (!toolbar) return;

      const btn = document.createElement('button');
      btn.id = 'share-unlimited-group-presets-btn';
      btn.className = 'su-ghost-btn';
      btn.innerHTML = html;
      btn.addEventListener('click', (e) => {
        e.preventDefault(); e.stopPropagation();
        if (window.ShareUnlimited.UI && window.ShareUnlimited.UI.showGroupPresetsModal) {
          window.ShareUnlimited.UI.showGroupPresetsModal();
        }
      });
      toolbar.appendChild(btn);
    });
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.groupPresets) {
      syncGroupPresetsButton();
    }
  });

  /**
   * Resolves the live "Share to a group" dialog across Facebook's two markup variants
   * (aria-labelledby vs aria-label="Share to a group"). Delegates to Core.findShareDialog
   * so both files share one detection path; falls back to the legacy selector if Core
   * hasn't loaded yet (load order guarantees it normally has). Purely additive — the
   * legacy aria-labelledby dialog is still matched first, so working setups are untouched.
   */
  function getShareDialog() {
    const Core = window.ShareUnlimited.Core;
    if (Core && Core.findShareDialog) return Core.findShareDialog();
    return document.querySelector('div[role="dialog"][aria-labelledby]');
  }

  // --- Checkbox Selection Persistence ---

  function getFacebookUserId() {
    const match = document.cookie.match(/(?:^|;\s*)c_user=(\d+)/);
    if (!match) return null;
    // Include i_user (Facebook's "additional profile" id) — must stay in sync with
    // Core.getFacebookUserIdCore() so selections and inventory agree on identity.
    const iUser = document.cookie.match(/(?:^|;\s*)i_user=(\d+)/);
    return iUser ? `${match[1]}:${iUser[1]}` : match[1];
  }

  /**
   * Saves the current checkbox selections to sessionStorage, tagged with the current FB user ID.
   */
  function saveCheckboxSelections() {
    // MERGE into the existing saved map — do NOT rebuild from scratch.
    // Facebook virtualizes the group list (only ~20 rows live in the DOM at once),
    // so querying .multi-share-checkbox only sees the visible rows. Rebuilding would
    // wipe selections for any group scrolled out of view. We update just the visible
    // rows and keep everything else intact.
    const selections = loadCheckboxSelections();
    document.querySelectorAll('.multi-share-checkbox').forEach(checkbox => {
      const button = checkbox.closest('div[role="button"]');
      const Core = window.ShareUnlimited.Core;
      if (button && Core) {
        const buttonText = button.textContent.trim();
        const groupName = Core.extractAndValidateGroupName(buttonText, button);
        if (groupName) {
          // v15.9: entries are keyed by the group's stable ID ("gid:<id>") so two
          // groups with the SAME display name stay two separate selections. The
          // display name rides along in the entry for search/UI. Rows whose ID can't
          // be read fall back to the legacy name key (and get purged on next load).
          const groupId = Core.extractGroupIdFromRow ? Core.extractGroupIdFromRow(button) : null;
          if (groupId) {
            selections[`gid:${groupId}`] = { checked: checkbox.checked, name: groupName, id: groupId };
            delete selections[groupName]; // migrate any legacy name-keyed entry
            if (Core.rememberGroupId) Core.rememberGroupId(groupName, groupId);
          } else {
            selections[groupName] = checkbox.checked;
          }
        }
      }
    });
    const userId = getFacebookUserId();
    sessionStorage.setItem('shareUnlimited_checkboxSelections', JSON.stringify({ userId, selections }));
    console.log('💾 Saved checkbox selections:', Object.keys(selections).filter(k => selections[k]).length, 'selected');
  }

  /**
   * Loads checkbox selections from sessionStorage.
   * Returns empty object if the stored selections belong to a different FB account.
   */
  function loadCheckboxSelections() {
    const saved = sessionStorage.getItem('shareUnlimited_checkboxSelections');
    if (saved) {
      try {
        const data = JSON.parse(saved);
        // New format: { userId, selections }
        if (data && typeof data === 'object' && 'selections' in data) {
          const currentUserId = getFacebookUserId();
          if (currentUserId && data.userId && data.userId !== currentUserId) {
            console.log('🔄 Different FB account detected — clearing stale checkbox selections');
            sessionStorage.removeItem('shareUnlimited_checkboxSelections');
            return {};
          }
          return data.selections || {};
        }
        // Legacy format: plain { groupName: bool } — use as-is (no userId to compare)
        return data;
      } catch (e) {
        console.error('Failed to parse saved selections:', e);
      }
    }
    return {};
  }

  /**
   * Clears saved checkbox selections
   */
  function clearCheckboxSelections() {
    sessionStorage.removeItem('shareUnlimited_checkboxSelections');
    console.log('🗑️ Cleared checkbox selections');
  }

  /**
   * One-time purge per page load (v15.9): deselect any saved selection that has NO
   * captured group ID. Legacy selections (made before the ID feature) can only be
   * matched by display name — the exact failure mode that posted to wrong groups —
   * so they must be re-ticked by the user, which captures their ID. Selections made
   * under v15.9 save their ID at click time, so this never touches them.
   */
  let legacySelectionsPurged = false;
  function purgeSelectionsWithoutIds() {
    if (legacySelectionsPurged) return;
    const Core = window.ShareUnlimited.Core;
    if (!Core || !Core.getKnownGroupId) return; // Core not ready — retry on next call
    legacySelectionsPurged = true;
    const selections = loadCheckboxSelections();
    const dropped = [];
    let migrated = 0;
    Object.keys(selections).forEach(key => {
      const val = selections[key];
      if (val && typeof val === 'object') return; // v15.9 id-keyed entry — has an ID by construction
      if (val !== true) return;                   // legacy unchecked — harmless
      const knownId = Core.getKnownGroupId(key);
      if (knownId) {
        // Legacy selected entry whose ID we DO know — migrate to the id-keyed format.
        selections[`gid:${knownId}`] = { checked: true, name: key, id: knownId };
        delete selections[key];
        migrated++;
      } else {
        selections[key] = false;
        dropped.push(key);
      }
    });
    if (dropped.length || migrated) {
      const userId = getFacebookUserId();
      sessionStorage.setItem('shareUnlimited_checkboxSelections', JSON.stringify({ userId, selections }));
      if (migrated) console.log(`🔁 Migrated ${migrated} legacy selection(s) to id-keyed format`);
      if (dropped.length) console.log(`🧹 Deselected ${dropped.length} legacy selection(s) saved without a group ID — please re-tick them:`, dropped);
    }
  }

  /**
   * Applies saved selection state to a checkbox
   */
  function applySelectionState(checkbox, groupName) {
    purgeSelectionsWithoutIds();
    const selections = loadCheckboxSelections();
    // Look up by this ROW's id first (id-keyed v15.9 entries), then legacy name key —
    // so of two identically-named groups only the actually-selected one gets ticked.
    const Core = window.ShareUnlimited.Core;
    const button = checkbox.closest('div[role="button"]');
    const groupId = (Core && Core.extractGroupIdFromRow && button) ? Core.extractGroupIdFromRow(button) : null;
    const entry = (groupId && selections[`gid:${groupId}`] !== undefined)
      ? selections[`gid:${groupId}`]
      : selections[groupName];
    if (entry === true || (entry && typeof entry === 'object' && entry.checked === true)) {
      checkbox.checked = true;
      console.log('✅ Restored selection for:', groupName, groupId ? `[${groupId}]` : '');
    }
  }

  // ── Guided flow (v16.1): attention ring + Load-All-first guard ─────────────
  // Step 1 = Load All (build the inventory), step 2 = Search. A rotating blue
  // ring highlights whichever button is the user's sensible next step.
  let loadAllCompletedThisSession = false;

  function ensureGuideStyles() {
      if (document.getElementById('su-guide-styles')) return;
      const st = document.createElement('style');
      st.id = 'su-guide-styles';
      st.textContent = `
        @property --su-ga { syntax: '<angle>'; inherits: false; initial-value: 0deg; }
        /* Ring colors are variables so a host element can recolor the sweep on
           hover/state without redefining the geometry (see the Multi-Group
           button's orange hover). Defaults are the original FB blue — every
           existing .su-attn user renders exactly as before. */
        .su-attn {
          position: relative !important;
          --su-ring-0: rgba(24,119,242,0);
          --su-ring-1: rgba(110,175,255,0.6);
          --su-ring-2: #1877f2;
          --su-ring-3: #b7dcff;
        }
        /* TRUE border ring: the conic tail is masked to a 3px donut OUTSIDE the
           button's edge (padding-box XOR full box), so it circles the button
           instead of glowing inside it. pointer-events:none — never eats clicks. */
        .su-attn::after {
          content: ''; position: absolute; inset: -4px; border-radius: 11px;
          padding: 3px; pointer-events: none;
          background: conic-gradient(from var(--su-ga),
            var(--su-ring-0) 0deg, var(--su-ring-0) 220deg,
            var(--su-ring-1) 285deg, var(--su-ring-2) 325deg, var(--su-ring-3) 358deg,
            var(--su-ring-0) 360deg);
          -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
          -webkit-mask-composite: xor;
          mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
          mask-composite: exclude;
          animation: suGuideSweep 1.2s linear infinite;
        }
        @keyframes suGuideSweep { to { --su-ga: 360deg; } }
        @keyframes suGuidePop { 0% { opacity: 0; transform: scale(0.92) translateY(8px); } 100% { opacity: 1; transform: scale(1) translateY(0); } }
        @keyframes suGuideFadeIn { from { opacity: 0; } to { opacity: 1; } }
      `;
      document.head.appendChild(st);
  }

  function setAttention(btn, on) {
      if (!btn) return;
      ensureGuideStyles();
      btn.classList.toggle('su-attn', !!on);
  }

  // ── First-run auto-setup (v16.4) ────────────────────────────────────────────
  // If the ACTIVE FB profile has zero cached groups (Inventory is per-profile,
  // keyed via getFacebookUserIdCore), the first successful open of the group
  // dialog runs the Load All sweep automatically behind a friendly progress
  // modal — the user never has to discover the Load All button. Any profile
  // with ≥1 inventoried group skips this entirely (normal guided flow). One
  // attempt per page load, so a 0-group sweep can't loop.
  let autoSetupAttemptedThisPage = false;

  // Best-effort display name of the ACTIVE FB profile. Single implementation
  // lives in Core.Profile (v17.0) — it verifies the name against the active
  // profile id, so "switch profile" no longer risks showing the main account's
  // name. Returns null when unknown; callers degrade to generic wording.
  function getFbProfileName() {
      const C = window.ShareUnlimited && window.ShareUnlimited.Core;
      return (C && C.Profile) ? C.Profile.getName() : null;
  }

  function ensureAutoSetupStyles() {
      ensureGuideStyles(); // suGuidePop / suGuideFadeIn
      if (document.getElementById('su-auto-setup-styles')) return;
      const st = document.createElement('style');
      st.id = 'su-auto-setup-styles';
      st.textContent = `
        @keyframes suSetupPulse { 0%, 100% { transform: scale(0.6); opacity: 0.35; } 50% { transform: scale(1); opacity: 1; } }
        @keyframes suSetupPop { 0% { transform: scale(1.35); } 100% { transform: scale(1); } }
      `;
      document.head.appendChild(st);
  }

  /**
   * Progress modal for the first-run sweep — FB-native LIGHT idiom (§5 style
   * guide). Returns { setCount, done, close, cancel, onCancel }.
   *
   * **This screen's job is to lower anxiety, not to report throughput (v18.2).**
   * It is the very first thing a new user sees us do, it appears unprompted, and
   * it reads over their shoulder while a counter climbs — which is exactly the
   * shape of something malicious. The rewrite therefore:
   *
   *   - names the ACTION ("Setting you up for multiple group sharing") rather than
   *     announcing an installation;
   *   - states the limit of what we do, once, in one line — a longer privacy
   *     statement reads as defensive and scares people more than it reassures;
   *   - makes the count SMALL. A 42px number ticking upward is the single most
   *     alarming element on the screen; it is progress feedback, not a headline;
   *   - gives a real way out. "Not now" genuinely aborts the sweep — a modal that
   *     can only be hidden while it keeps working is what an uninstall feels like.
   *
   * `onCancel(fn)` registers the abort handler; the caller wires it to stop the
   * sweep. `Hide` keeps the old behaviour (dismiss the modal, sweep continues).
   *
   * Profile name / counts are set via textContent — group and profile names can
   * contain &, <, RTL marks (never innerHTML-interpolate them).
   */
  function showAutoSetupModal(profileName) {
      ensureAutoSetupStyles();
      const existing = document.getElementById('su-auto-setup-modal');
      if (existing) existing.remove();

      const overlay = document.createElement('div');
      overlay.id = 'su-auto-setup-modal';
      overlay.style.cssText = `
          position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 999999999;
          display: flex; align-items: center; justify-content: center;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
          animation: suGuideFadeIn 0.15s ease-out;`;
      const box = document.createElement('div');
      box.style.cssText = `
          position: relative; background: white; border-radius: 12px; max-width: 420px; width: 90%;
          padding: 28px 24px 20px; text-align: center; box-shadow: 0 12px 40px rgba(0,0,0,0.3);
          animation: suGuidePop 0.22s cubic-bezier(0.16, 1, 0.3, 1);`;

      // Loading animation: a row of "group avatar" dots pulsing in sequence.
      const dots = document.createElement('div');
      dots.style.cssText = 'display: flex; justify-content: center; gap: 10px; margin-bottom: 16px; height: 26px; align-items: center;';
      ['#1877f2', '#42b72a', '#f7b928', '#e41e3f', '#8a3ab9'].forEach((color, idx) => {
          const d = document.createElement('div');
          d.style.cssText = `width: 22px; height: 22px; border-radius: 50%; background: ${color};
              animation: suSetupPulse 1.2s ease-in-out ${(idx * 0.15).toFixed(2)}s infinite;`;
          dots.appendChild(d);
      });

      const title = document.createElement('div');
      title.textContent = 'Setting you up for multiple group sharing';
      title.style.cssText = 'color: #050505; font-size: 20px; font-weight: 700; margin-bottom: 10px; line-height: 1.3;';

      const profileLine = document.createElement('div');
      profileLine.style.cssText = 'color: #65676b; font-size: 14px; margin-bottom: 4px;';
      if (profileName) {
          profileLine.append("You're on profile ");
          const b = document.createElement('b');
          b.style.color = '#050505';
          b.textContent = profileName;
          profileLine.appendChild(b);
      } else {
          profileLine.textContent = 'Getting this Facebook profile ready';
      }

      const statusLine = document.createElement('div');
      statusLine.textContent = 'Just making a list of your groups so you can find them later.';
      statusLine.style.cssText = 'color: #65676b; font-size: 14px; line-height: 1.5; margin-bottom: 12px;';

      // One line, not three. The claim is verified: `groupInventory` is written to
      // chrome.storage.local and read back by Search/presets — no code path sends a
      // group name anywhere. The three network calls in background/ carry an auth
      // code, form-fill page text and AI prompt text, none of them the inventory.
      // If that ever changes, this sentence changes with it.
      const safety = document.createElement('div');
      safety.style.cssText = `background: #f0f2f5; color: #65676b; font-size: 13px; border-radius: 8px;
          padding: 9px 12px; line-height: 1.45; margin-bottom: 14px; text-align: left;
          display: flex; gap: 8px; align-items: flex-start;`;
      const lock = document.createElement('span');
      lock.textContent = '🔒';
      lock.style.cssText = 'font-size: 12px; line-height: 1.6; flex-shrink: 0;';
      const safetyText = document.createElement('span');
      safetyText.textContent = 'Nothing is shared, posted or changed — your group list stays on this device.';
      safety.appendChild(lock);
      safety.appendChild(safetyText);

      // Deliberately quiet. This used to be a 42px count over a bold label; at that
      // size a number climbing on its own reads as a scan running away with itself.
      const countLine = document.createElement('div');
      countLine.style.cssText = 'color: #65676b; font-size: 14px; line-height: 1.4; margin-bottom: 14px;';
      const countEl = document.createElement('b');
      countEl.textContent = '0';
      countEl.style.cssText = 'color: #050505; font-weight: 600; display: inline-block;';
      const countLabel = document.createElement('span');
      countLabel.textContent = ' groups so far…';
      countLine.appendChild(countEl);
      countLine.appendChild(countLabel);

      const footnote = document.createElement('div');
      footnote.textContent = 'One-time only. You can stop this at any point — nothing is lost.';
      footnote.style.cssText = 'color: #8a8d91; font-size: 12px; line-height: 1.4; margin-bottom: 16px;';

      // "Not now" is the wider, more obvious of the two: the way out must not be the
      // one you have to hunt for.
      const footer = document.createElement('div');
      footer.style.cssText = 'display: flex; gap: 8px; justify-content: center; align-items: center;';
      const notNowBtn = document.createElement('button');
      notNowBtn.textContent = 'Not now';
      notNowBtn.style.cssText = `background: #e4e6eb; color: #050505; border: none; border-radius: 6px;
          padding: 8px 18px; font-size: 14px; font-weight: 600; font-family: inherit; cursor: pointer;
          transition: background 0.15s;`;
      notNowBtn.addEventListener('mouseenter', () => notNowBtn.style.background = '#d8dadf');
      notNowBtn.addEventListener('mouseleave', () => notNowBtn.style.background = '#e4e6eb');
      const hideBtn = document.createElement('button');
      hideBtn.textContent = 'Hide';
      hideBtn.style.cssText = `background: transparent; color: #65676b; border: none; border-radius: 6px;
          padding: 8px 14px; font-size: 14px; font-weight: 500; font-family: inherit; cursor: pointer;
          transition: background 0.15s;`;
      hideBtn.addEventListener('mouseenter', () => hideBtn.style.background = '#f0f2f5');
      hideBtn.addEventListener('mouseleave', () => hideBtn.style.background = 'transparent');
      footer.appendChild(notNowBtn);
      footer.appendChild(hideBtn);

      box.appendChild(dots);
      box.appendChild(title);
      box.appendChild(profileLine);
      box.appendChild(statusLine);
      box.appendChild(safety);
      box.appendChild(countLine);
      box.appendChild(footnote);
      box.appendChild(footer);
      overlay.appendChild(box);
      document.body.appendChild(overlay);

      let closed = false;
      let cancelled = false;
      const cancelHandlers = [];

      function close() {
          if (closed) return;
          closed = true;
          overlay.style.transition = 'opacity 0.25s ease';
          overlay.style.opacity = '0';
          setTimeout(() => overlay.remove(), 260);
      }

      /** Registers an abort handler. The caller uses it to stop the sweep. */
      function onCancel(fn) {
          if (typeof fn === 'function') cancelHandlers.push(fn);
      }

      function cancel() {
          if (cancelled || closed) return;
          cancelled = true;
          // Handlers first: the sweep must be told to stop before we start telling
          // the user it stopped.
          cancelHandlers.forEach(fn => {
              try { fn(); } catch (e) { console.warn('Auto-setup cancel handler failed:', e); }
          });

          dots.replaceChildren();
          const wave = document.createElement('div');
          wave.textContent = '👋';
          wave.style.cssText = 'font-size: 26px; line-height: 26px;';
          dots.appendChild(wave);
          title.textContent = 'Stopped — no problem';
          profileLine.remove();
          statusLine.textContent = 'Setup will run next time you open the share dialog, or you can ' +
              'start it any time from the 📋 Load All button.';
          safety.remove();
          countLine.remove();
          footnote.remove();
          footer.remove();
          setTimeout(close, 4000);
      }

      notNowBtn.addEventListener('click', cancel);
      hideBtn.addEventListener('click', close);

      let lastCount = 0;
      function setCount(n) {
          if (closed || cancelled || n === lastCount) return;
          lastCount = n;
          countEl.textContent = String(n);
          // restart the pop animation on every update
          countEl.style.animation = 'none';
          void countEl.offsetWidth;
          countEl.style.animation = 'suSetupPop 0.25s ease-out';
      }

      function done(total) {
          if (closed || cancelled) return;
          dots.replaceChildren();
          const check = document.createElement('div');
          check.textContent = '✅';
          check.style.cssText = 'font-size: 26px; line-height: 26px;';
          dots.appendChild(check);
          title.textContent = "You're all set!";
          setCount(total);
          countLabel.textContent = total === 1 ? ' group saved to this device' : ' groups saved to this device';
          statusLine.textContent = 'This won’t run again on this profile.';
          footnote.textContent = 'Use the highlighted 🔍 Select Groups button to pick who you share with.';
          footer.remove();
          setTimeout(close, 3500);
      }

      return { setCount, done, close, cancel, onCancel };
  }

  // addQuickShareButton is now built inline inside continueAddingSelectAllCheckbox (Row 2 of the container)
  function addQuickShareButton() { /* no-op: kept for export compatibility */ }

  /**
   * Updates the Quick Share button visibility based on selected checkboxes
   */
  function updateQuickShareButtonVisibility() {
      const row = document.querySelector('#share-unlimited-quick-share-btn');
      if (!row) return;

      // Count from the saved selections map (source of truth) so the total is correct
      // even though Facebook's virtualized list only keeps ~20 checkboxes in the DOM.
      // Union with any currently-checked DOM boxes to catch a just-clicked-not-yet-saved one.
      const saved = loadCheckboxSelections();
      // Keys are "gid:<id>" (v15.9) or legacy names — either way one key per GROUP,
      // so two identically-named groups count as 2, not 1.
      const selectedKeys = new Set(Object.keys(saved).filter(k => {
          const v = saved[k];
          return v === true || (v && typeof v === 'object' && v.checked === true);
      }));
      document.querySelectorAll('.multi-share-checkbox:checked').forEach(cb => {
          const button = cb.closest('div[role="button"]');
          const Core = window.ShareUnlimited.Core;
          if (button && Core) {
              const name = Core.extractAndValidateGroupName(button.textContent.trim(), button);
              if (!name) return;
              const id = Core.extractGroupIdFromRow ? Core.extractGroupIdFromRow(button) : null;
              selectedKeys.add(id ? `gid:${id}` : name);
          }
      });
      const checkedCount = selectedKeys.size;

      if (checkedCount > 0) {
          row.style.setProperty('opacity', '1', 'important');
          row.style.setProperty('max-height', '60px', 'important');
          row.style.setProperty('padding', '8px 16px', 'important');
          row.style.setProperty('pointer-events', 'auto', 'important');

          const shareBtn = row.querySelector('#share-unlimited-share-btn');
          if (shareBtn) {
              shareBtn.textContent = `Share to ${checkedCount} Group${checkedCount > 1 ? 's' : ''}`;
          }
      } else {
          row.style.setProperty('opacity', '0', 'important');
          row.style.setProperty('max-height', '0', 'important');
          row.style.setProperty('padding', '0 12px', 'important');
          row.style.setProperty('pointer-events', 'none', 'important');
      }
  }

  // Free-forever model (v15.8): most users are permanently unlicensed, so the silent
  // server check below would otherwise fire on EVERY dialog open. Once per page load
  // is enough — it still covers the fresh-install-with-valid-license case.
  let licenseServerCheckedThisPage = false;

  /**
   * True when the element is actually rendered on screen. FB keeps previous
   * share-flow screens MOUNTED as hidden sibling dialogs, so any "does our UI
   * already exist" check must ignore (and clean up) copies living inside those
   * dead screens — otherwise a stale hidden toolbar blocks the real one.
   */
  function isVisiblyRendered(el) {
      if (!el || !el.getClientRects().length) return false;
      const style = window.getComputedStyle(el);
      return style.visibility !== 'hidden' && style.display !== 'none';
  }

  /**
   * Resolves the share dialog like getShareDialog(), but prefers a VISIBLE one.
   * Core.findShareDialog returns the first match in document order, which can be
   * a stale hidden dialog after a close/reopen — inserting our toolbar there
   * makes it silently invisible.
   */
  function getVisibleShareDialog() {
      const primary = getShareDialog();
      if (primary && isVisiblyRendered(primary)) return primary;

      const dialogs = Array.from(document.querySelectorAll('div[role="dialog"]')).filter(isVisiblyRendered);
      return dialogs.find(d => d.hasAttribute('aria-labelledby')) ||
             dialogs.find(d => (d.getAttribute('aria-label') || '').trim() === 'Share to a group') ||
             dialogs.find(d => Array.from(d.querySelectorAll('h2, h3')).some(h => {
                 const t = h.textContent.trim();
                 const span = h.querySelector('span');
                 return t === 'Share to a group' || (span && span.textContent.trim() === 'Share to a group');
             })) ||
             // Non-English UI (v17.7): search box + group rows identify the picker
             // without reading any label.
             dialogs.find(d => {
                 const Core = window.ShareUnlimited && window.ShareUnlimited.Core;
                 return Core && Core.Struct && Core.Struct.findGroupSearchInput(d) &&
                        d.querySelector('div[role="listitem"]');
             }) ||
             null;
  }

  /**
   * Document-wide toolbar existence check that self-heals: stale copies inside
   * hidden mounted screens are removed, and only a VISIBLE toolbar counts as
   * "already there". Fixes both failure modes of the naive per-dialog check —
   * the double toolbar (two dialogs each getting one) and the missing toolbar
   * (a hidden stale copy vetoing insertion of the real one).
   */
  function hasLiveSelectAllToolbar() {
      let live = false;
      document.querySelectorAll('[id="share-unlimited-select-all-container"]').forEach(el => {
          if (isVisiblyRendered(el)) live = true;
          else el.remove();
      });
      return live;
  }

  /**
   * Injects a "Select All" checkbox into the dialog header or list top
   */
  function addSelectAllCheckbox(dialog) {
      if (hasLiveSelectAllToolbar()) return;

      chrome.storage.local.get(['authExpiry'], async (result) => {
        // Re-query the live dialog — the original reference may be stale after the async gap
        const liveDialog = getVisibleShareDialog();
        if (!liveDialog) return;

        // Bail if another call already inserted the container while we were waiting
        if (hasLiveSelectAllToolbar()) return;

        // Toolbar FIRST — it doesn't depend on license state, and the silent
        // license check below is a network round-trip (background → Vercel) that
        // can take 10s+ on a serverless cold start. Blocking on it made the
        // toolbar appear ~15s late for free users on first dialog open.
        continueAddingSelectAllCheckbox(liveDialog);

        let { authExpiry } = result;

        // Silently check the server whenever local state says UNLICENSED — that means
        // no authExpiry at all (fresh install, cleared storage, licensed but never
        // opened the popup) OR an authExpiry in the past.
        //
        // The expired case matters as much as the missing one: before v16.8 this was
        // gated on `!authExpiry`, so once a lapse pinned authExpiry to a past date the
        // check NEVER ran again. A user who then subscribed stayed watermarked until
        // they happened to click a button by hand. Re-checking a stale expiry is what
        // makes a purchase self-heal.
        const locallyUnlicensed = !authExpiry || new Date(authExpiry) <= new Date();
        if (locallyUnlicensed && !licenseServerCheckedThisPage && window.ExpiredOverlay && window.ExpiredOverlay.checkAndActivateLicense) {
          licenseServerCheckedThisPage = true;
          const hasLicense = await window.ExpiredOverlay.checkAndActivateLicense();
          if (hasLicense) {
            // License verified — re-read the newly saved expiry from storage
            const refreshed = await new Promise(resolve => chrome.storage.local.get(['authExpiry'], resolve));
            authExpiry = refreshed.authExpiry;
          }
        }

        // Same predicate that decides whether a share gets stamped — the banner is
        // shown for exactly the users who will see a watermark, so there is always
        // an on-screen control to fix a stale license.
        const isExpired = !authExpiry || new Date(authExpiry) <= new Date();

        if (isExpired) {
          // Free-forever model (v15.8): new AND expired users both get the full sharing
          // UI — never blocked. The banner upsells paid watermark removal (new users)
          // or license renewal (expired users); watermark added on share.
          // Re-resolve the dialog — it may have re-rendered during the await above.
          const bannerDialog = getVisibleShareDialog();
          if (bannerDialog) {
            const insertLocation = findInsertionLocation(bannerDialog);
            if (insertLocation && window.ExpiredOverlay) {
              window.ExpiredOverlay.createFacebookExpiredButton(insertLocation);
            }
          }
        }
      });
  }
  
  /**
   * Helper to find insertion location for buttons.
   * Returns the element that the Select All bar / expired CTA should be inserted BEFORE.
   *
   * Strategy: anchor to the "Share to a group" h2 and use its next sibling.
   * This is the most reliable approach because the h2 is always present whenever
   * checkboxes appear, regardless of whether a role="list" wrapper exists.
   */
  function findInsertionLocation(dialog) {
      // BEST: insert before the search input — it sits right below the header,
      // in its own full-width block, so our toolbar won't squish the h2.
      const searchInput = dialog.querySelector('input[type="search"], input[placeholder*="Search"], input[aria-label*="Search"]');
      if (searchInput) {
          // Walk up to find a block-level container that's a direct child of a column layout
          let node = searchInput.parentElement;
          while (node && node !== dialog) {
              if (node.parentElement && node.parentElement !== dialog) {
                  node = node.parentElement;
                  continue;
              }
              // node is a direct child of the dialog — insert before it
              return node;
          }
          // Fallback: just insert before the input's immediate parent
          return searchInput.parentElement || searchInput;
      }

      // FALLBACK: find "Share to a group" h2, then walk UP until we reach
      // a direct child of the dialog so we don't insert inside the header row.
      const h2Elements = dialog.querySelectorAll('h2');
      let shareToGroupH2 = null;
      for (const h2 of h2Elements) {
          const h2Text = h2.textContent.trim();
          const spanText = (h2.querySelector('span') || {}).textContent?.trim() || '';
          if (h2Text === 'Share to a group' || spanText === 'Share to a group') {
              shareToGroupH2 = h2;
              break;
          }
      }
      // Non-English UI (v17.7): no English heading exists to anchor to. The search
      // input sits in the same header block, so walk up from that instead.
      if (!shareToGroupH2) {
          const Core = window.ShareUnlimited && window.ShareUnlimited.Core;
          const input = Core && Core.Struct && Core.Struct.findGroupSearchInput(dialog);
          if (input) shareToGroupH2 = input;
      }
      if (!shareToGroupH2) return null;

      // Walk up to a direct child of the dialog, then return its next sibling
      let ancestor = shareToGroupH2.parentElement;
      while (ancestor && ancestor.parentElement !== dialog) {
          ancestor = ancestor.parentElement;
      }
      // ancestor is now a direct child of dialog (the header section)
      if (ancestor && ancestor.nextElementSibling) {
          return ancestor.nextElementSibling;
      }

      return null;
  }
  
  /**
   * Continues adding Select All checkbox for authorized users
   */
  function continueAddingSelectAllCheckbox(dialog) {
      // Re-check right before building the container — addSelectAllCheckbox's own
      // guard runs BEFORE an await on a network license call, so a second
      // observer-fired call can slip through that check while the first is still
      // waiting on the network, then both land here and each build a container.
      // This is the last synchronous checkpoint before insertion, so it's the one
      // that actually closes the race.
      if (hasLiveSelectAllToolbar()) return;

      const insertLocation = findInsertionLocation(dialog);
      if (!insertLocation) return;

      // Outer wrapper — column flex so the rows stack vertically. Themed via the
      // shared .su-native CSS variables (expired_overlay.js) so light and dark FB
      // share one component; FB's theme is detected at render time. Layout styles
      // stay inline with !important to prevent Facebook CSS from overriding them.
      if (window.ExpiredOverlay && window.ExpiredOverlay.ensureNativeStyles) {
          window.ExpiredOverlay.ensureNativeStyles();
      }
      const fbDark = !!(window.ExpiredOverlay && window.ExpiredOverlay.isFbDarkMode &&
          window.ExpiredOverlay.isFbDarkMode());
      const container = document.createElement('div');
      container.id = 'share-unlimited-select-all-container';
      container.className = 'su-native' + (fbDark ? ' su-dark' : '');
      container.style.cssText = `
          width: 100% !important;
          box-sizing: border-box !important;
          display: flex !important;
          flex-direction: column !important;
          align-items: stretch !important;
          background: var(--su-surface) !important;
          border: 1px solid var(--su-border) !important;
          border-radius: 8px !important;
          margin-bottom: 8px !important;
          z-index: 10 !important;
          position: relative !important;
          overflow: visible !important;
      `;

      // ── Row 1: Select All on its own line ───────────────────────────────────
      const selectRow = document.createElement('div');
      selectRow.style.cssText = `
          display: flex !important;
          align-items: center !important;
          gap: 8px !important;
          padding: 10px 16px 0 16px !important;
      `;

      // ── Row 2: action toolbar — content-sized ghost buttons, 8px gaps ──────
      // wrap: the buttons size to their labels (.su-ghost-btn flex basis auto), so
      // on a narrow share dialog they drop to a second line instead of squashing
      // and clipping their own text. Never let this row overflow the dialog.
      const toolbar = document.createElement('div');
      toolbar.id = 'share-unlimited-action-toolbar';
      toolbar.style.cssText = `
          width: 100% !important;
          box-sizing: border-box !important;
          display: flex !important;
          flex-direction: row !important;
          flex-wrap: wrap !important;
          align-items: stretch !important;
          gap: 8px !important;
          padding: 8px 16px 10px 16px !important;
      `;

      // Custom-drawn checkbox (.su-cb): 18px, 4px radius, #0866FF when checked —
      // native inputs render black under FB dark mode, so appearance:none it is.
      const checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      checkbox.id = 'share-unlimited-select-all';
      checkbox.className = 'su-cb';

      const label = document.createElement('label');
      label.htmlFor = 'share-unlimited-select-all';
      label.textContent = 'Select All';
      label.style.cssText = `
          display: inline-flex !important;
          align-items: center !important;
          font-weight: 600 !important;
          cursor: pointer !important;
          font-size: 13px !important;
          color: var(--su-text) !important;
          white-space: nowrap !important;
          flex-shrink: 0 !important;
          margin: 0 !important;
          line-height: 18px !important;
      `;

      // Old behaviour: tick only the currently-mounted (~20) checkboxes.
      function selectVisibleCheckboxes() {
          dialog.querySelectorAll('.multi-share-checkbox').forEach(cb => {
              if (!cb.checked) {
                  cb.click();
                  cb.checked = true;
              }
          });
      }

      // Full select: write EVERY inventoried group straight into the saved
      // selections map (keyed by group id — the source of truth), then mirror onto
      // whatever checkboxes happen to be mounted. Virtualization can't hide groups
      // from this path. Returns how many were selected.
      async function selectAllKnownGroups() {
          const Core = window.ShareUnlimited.Core;
          if (!Core || !Core.Inventory) { selectVisibleCheckboxes(); return 0; }
          const inv = await Core.Inventory.getAll();
          if (!inv.length) { selectVisibleCheckboxes(); return 0; }
          const selections = loadCheckboxSelections();
          inv.forEach(g => { selections[`gid:${g.id}`] = { checked: true, name: g.name, id: g.id }; });
          sessionStorage.setItem('shareUnlimited_checkboxSelections',
              JSON.stringify({ userId: getFacebookUserId(), selections }));
          document.querySelectorAll('.multi-share-checkbox').forEach(cb => { cb.checked = true; });
          updateQuickShareButtonVisibility();
          console.log(`☑️ Selected ALL ${inv.length} known groups (from inventory)`);
          return inv.length;
      }

      // Guard modal: Select All before Load All would silently miss every
      // not-yet-loaded group. Offer to load everything first.
      function showLoadAllFirstModal() {
          ensureGuideStyles();
          const existing = document.getElementById('su-loadall-first-modal');
          if (existing) existing.remove();
          const visibleCount = dialog.querySelectorAll('.multi-share-checkbox').length;

          const overlay = document.createElement('div');
          overlay.id = 'su-loadall-first-modal';
          overlay.style.cssText = `
              position: fixed; inset: 0; background: rgba(0,0,0,0.6); z-index: 999999999;
              display: flex; align-items: center; justify-content: center;
              font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
              animation: suGuideFadeIn 0.15s ease-out;`;
          const box = document.createElement('div');
          box.style.cssText = `
              background: white; border-radius: 12px; max-width: 400px; width: 90%;
              padding: 24px; text-align: center; box-shadow: 0 12px 40px rgba(0,0,0,0.3);
              animation: suGuidePop 0.22s cubic-bezier(0.16, 1, 0.3, 1);`;
          box.innerHTML = `
              <div style="font-size: 40px; margin-bottom: 10px;">📋</div>
              <div style="color:#050505;font-size:18px;font-weight:700;margin-bottom:8px;">
                  Load all your groups first?</div>
              <div style="color:#65676b;font-size:14px;line-height:1.5;margin-bottom:18px;">
                  You haven't loaded your full group list yet — Select All would only tick the
                  <b>${visibleCount} groups currently visible</b>. Load everything first so you
                  don't miss any.</div>`;
          const yesBtn = document.createElement('button');
          yesBtn.textContent = '🚀 Yes, Load All first';
          yesBtn.style.cssText = 'width:100%;background:#1877f2;color:white;border:none;border-radius:8px;padding:12px 0;font-size:15px;font-weight:700;cursor:pointer;margin-bottom:8px;transition:background 0.15s;';
          yesBtn.addEventListener('mouseenter', () => yesBtn.style.background = '#166fe5');
          yesBtn.addEventListener('mouseleave', () => yesBtn.style.background = '#1877f2');
          const noBtn = document.createElement('button');
          noBtn.textContent = `Select ${visibleCount} visible only`;
          noBtn.style.cssText = 'width:100%;background:#e4e6eb;color:#050505;border:none;border-radius:8px;padding:11px 0;font-size:14px;font-weight:600;cursor:pointer;transition:background 0.15s;';
          noBtn.addEventListener('mouseenter', () => noBtn.style.background = '#d8dadf');
          noBtn.addEventListener('mouseleave', () => noBtn.style.background = '#e4e6eb');
          box.appendChild(yesBtn);
          box.appendChild(noBtn);
          overlay.appendChild(box);
          document.body.appendChild(overlay);

          yesBtn.addEventListener('click', async () => {
              overlay.remove();
              await runLoadAllSweep();
              const n = await selectAllKnownGroups();
              checkbox.checked = true;
              if (window.ShareUnlimited.UI && window.ShareUnlimited.UI.showSuccessNotification) {
                  window.ShareUnlimited.UI.showSuccessNotification(`✅ Selected all ${n} groups`);
              }
          });
          noBtn.addEventListener('click', () => {
              overlay.remove();
              selectVisibleCheckboxes();
              checkbox.checked = true;
          });
          if (window.ShareUnlimited.UI && window.ShareUnlimited.UI.wireBackdropDismiss) {
              window.ShareUnlimited.UI.wireBackdropDismiss(overlay, () => overlay.remove());
          } else {
              overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
          }
      }

      checkbox.addEventListener('change', async (e) => {
          const isChecked = e.target.checked;
          if (!isChecked) {
              // Deselect EVERYTHING — after an all-groups select, unticking only the
              // ~20 mounted boxes would leave the rest selected invisibly.
              clearCheckboxSelections();
              document.querySelectorAll('.multi-share-checkbox').forEach(cb => { cb.checked = false; });
              updateQuickShareButtonVisibility();
              return;
          }
          if (loadAllCompletedThisSession) {
              // Everything is indexed — Select All really means ALL.
              await selectAllKnownGroups();
              return;
          }
          // Not loaded yet — ask before silently missing groups.
          e.target.checked = false; // revert until the user decides
          showLoadAllFirstModal();
      });

      selectRow.appendChild(checkbox);
      selectRow.appendChild(label);
      container.appendChild(selectRow);

      // 16px Lucide-style icons — stroke: currentColor, so they inherit each
      // button's themed text color in both light and dark mode.
      const iconSvg = (name, size = 18) => {
          const paths = {
              'clipboard-list': '<rect width="8" height="4" x="8" y="2" rx="1" ry="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="M12 11h4"/><path d="M12 16h4"/><path d="M8 11h.01"/><path d="M8 16h.01"/>',
              'search': '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
              'layers': '<path d="M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z"/><path d="m22 17.65-9.17 4.16a2 2 0 0 1-1.66 0L2 17.65"/><path d="m22 12.65-9.17 4.16a2 2 0 0 1-1.66 0L2 12.65"/>',
              'zap': '<path d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"/>'
          };
          return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;">${paths[name] || ''}</svg>`;
      };

      // Shared button factory — equal ghost ACTION buttons (these are not tabs, so
      // no active segment). Styling + hover live in the namespaced .su-ghost-btn
      // rules; flex: 1 1 0 there makes the row stretch full-width with equal widths.
      const makeBtn = (id, html) => {
          const btn = document.createElement('button');
          btn.id = id;
          btn.className = 'su-ghost-btn';
          btn.innerHTML = html;
          return btn;
      };

      // Load All button
      const showAllButton = makeBtn('share-unlimited-show-all-btn', `${iconSvg('clipboard-list')} Load All <span id="group-count-badge" class="su-badge">…</span>`);
      // Full sweep — shared by the button click, the Select-All guard modal and
      // the first-run auto-setup. onProgress (optional) receives the live count
      // of unique groups discovered so far, once per scroll pass.
      let sweepInProgress = false;
      /**
       * @param {function|null} shouldAbort polled once per scroll pass; returning true
       *   stops the sweep. Only the first-run setup modal passes it ("Not now").
       *   A cancelled sweep takes the epilogue at the bottom instead of the success
       *   ceremony — it must leave the toolbar exactly as it found it.
       */
      async function runLoadAllSweep(onProgress = null, shouldAbort = null) {
          if (sweepInProgress) return 0;
          if (!window.ShareUnlimited.Core || !window.ShareUnlimited.Core.scrollToLoadAllGroups) return 0;
          sweepInProgress = true;
          setAttention(showAllButton, false);
          showAllButton.innerHTML = 'Loading…';
          showAllButton.disabled = true;
          showAllButton.style.opacity = '0.7';

          // Load All = REBUILD, not merge: wipe this account's inventory so the
          // Search My Groups list ends up with exactly what this sweep discovers.
          // Groups the user left (or another profile's groups from before
          // per-profile keying) would otherwise linger forever, since record()
          // only ever adds. Presets/templates live elsewhere and are untouched.
          // The snapshot is what each group used to be called (v17.7). Held across the
          // sweep so the epilogue can rewrite stale names by ID — see reconcileGroupNames.
          let previousInventory = null;
          if (window.ShareUnlimited.Core.Inventory && window.ShareUnlimited.Core.Inventory.reset) {
              previousInventory = await window.ShareUnlimited.Core.Inventory.reset();
          }

          const addedGroupNames = new Set();
          const discovered = await window.ShareUnlimited.Core.scrollToLoadAllGroups(() => {
              const allButtons = dialog.querySelectorAll('div[role="button"]');
              let newCheckboxes = 0;
              allButtons.forEach((button) => {
                  const buttonText = button.textContent.trim();
                  const buttonTextLength = buttonText.length;
                  const hasImage = button.querySelector('image, img, svg') !== null;
                  const isInGroupList = button.closest('[role="listitem"]') !== null;
                  const hasGroupIndicator = buttonText.includes('Public group') ||
                                           buttonText.includes('Private group') ||
                                           buttonText.toLowerCase().includes('members') ||
                                           (isInGroupList && (buttonText.includes('Public') || buttonText.includes('Private'))) ||
                                 // Non-English UI (v17.7): all markers above are English, so a
                                 // translated group list produced NO checkboxes at all. A row inside
                                 // the picker's listitem that carries an avatar is a group row in any
                                 // language.
                                 (isInGroupList && hasImage);
                  if (buttonTextLength > 10 && buttonTextLength < 200 && hasImage && hasGroupIndicator) {
                      const groupName = window.ShareUnlimited.Core.extractAndValidateGroupName(buttonText, button);
                      if (groupName && !addedGroupNames.has(groupName) && !button.querySelector('.multi-share-checkbox')) {
                          addedGroupNames.add(groupName);
                          const cb = document.createElement('input');
                          cb.type = 'checkbox';
                          cb.className = 'multi-share-checkbox';
                          cb.style.cssText = `margin-right:16px !important;height:44px !important;width:44px !important;cursor:pointer !important;z-index:9999 !important;position:relative !important;accent-color:#1877f2 !important;flex-shrink:0 !important;background:white !important;`;
                          applySelectionState(cb, groupName);
                          cb.addEventListener('click', (ev) => { ev.stopPropagation(); setTimeout(updateQuickShareButtonVisibility, 50); setTimeout(saveCheckboxSelections, 100); }, true);
                          cb.addEventListener('mousedown', (ev) => { ev.stopPropagation(); }, true);
                          button.style.cssText += 'display:flex !important;align-items:center !important;gap:8px !important;';
                          button.prepend(cb);
                          newCheckboxes++;
                      }
                  }
              });
              return newCheckboxes;
          }, null, null, onProgress, shouldAbort);

          // CANCELLED: leave no trace. The sweep is a REBUILD, so by now the
          // inventory holds a partial list — and a partial list is worse than none,
          // because a non-empty inventory is exactly what tells first-run setup it
          // has already happened. The user would be left permanently half-indexed
          // with no prompt to finish, which also makes the modal's "setup will run
          // next time" promise a lie. Wiping it back to empty keeps that promise.
          let cancelled = false;
          try { cancelled = !!(shouldAbort && shouldAbort()); } catch (e) {}
          if (cancelled) {
              if (window.ShareUnlimited.Core.Inventory && window.ShareUnlimited.Core.Inventory.reset) {
                  // reset() clears its own pending debounced write, so nothing lands after this.
                  try { await window.ShareUnlimited.Core.Inventory.reset(); } catch (e) {}
              }
              sweepInProgress = false;
              // Restore the button to its untouched first-run state — inventory is
              // empty again, so it is "Load All" with a zero badge, and the ring
              // stays on it because step 1 is still the user's next move.
              if (document.body.contains(showAllButton)) {
                  showAllButton.disabled = false;
                  showAllButton.style.opacity = '';
                  showAllButton.innerHTML = `${iconSvg('clipboard-list')} Load All <span id="group-count-badge" class="su-badge">0</span>`;
                  setAttention(showAllButton, true);
              }
              console.log('🚫 First-run setup cancelled by the user — inventory left empty');
              return 0;
          }

          // Report groups DISCOVERED during the sweep — counting DOM checkboxes
          // always shows ~20 because FB only keeps ~20 rows mounted at once.
          const total = discovered || dialog.querySelectorAll('.multi-share-checkbox').length;

          // A sync is a REBUILD, so it is also the moment every stored name should catch
          // up to reality (v17.7). Group IDs are permanent; names change when an admin
          // renames a group or the user switches Facebook's language. Awaited but fully
          // guarded internally — it can never fail the sweep.
          if (window.ShareUnlimited.Core.reconcileGroupNames) {
              await window.ShareUnlimited.Core.reconcileGroupNames(previousInventory);
          }

          loadAllCompletedThisSession = true;
          sweepInProgress = false;
          showAllButton.innerHTML = `✓ ${total} groups`;
          showAllButton.style.setProperty('background', 'rgba(66,183,42,0.25)', 'important');
          setTimeout(() => { showAllButton.style.opacity = '0'; setTimeout(() => showAllButton.remove(), 300); }, 2000);

          // Step-2 handoff: the index is built — the ring moves to Search.
          setAttention(document.getElementById('share-unlimited-search-groups-btn'), true);
          return total;
      }
      showAllButton.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          runLoadAllSweep();
      });
      toolbar.appendChild(showAllButton);

      // Search My Groups button (v16.1) — searches the persistent inventory built by
      // Load All / scans, so it finds ALL matching groups (FB's own search caps at ~10).
      // Kept short ("Select Groups", not "Select Groups To Share With") so it doesn't
      // crowd out the Sync/Presets buttons — the three content-sized buttons
      // (.su-ghost-btn, flex basis auto) then fit the row without wrapping.
      const searchGroupsBtn = makeBtn('share-unlimited-search-groups-btn', `${iconSvg('search')} Select Groups`);
      searchGroupsBtn.addEventListener('click', (e) => {
          e.preventDefault(); e.stopPropagation();
          if (window.ShareUnlimited.UI && window.ShareUnlimited.UI.showGroupSearchModal) {
              window.ShareUnlimited.UI.showGroupSearchModal();
          }
      });
      toolbar.appendChild(searchGroupsBtn);

      // Guidance ring — EXACTLY ONE button is always lit, and it must point at
      // the step the user actually has left to do.
      //
      // Session state alone got this wrong for a RETURNING profile: its groups
      // are already indexed (the button even relabels itself "Sync Latest
      // Groups (197)"), yet with no sweep run this session the ring pointed
      // back at Sync — telling the user to redo step 1 when their real next
      // move is Select Groups. The INVENTORY decides: empty → Sync (step 1),
      // populated → Select Groups (step 2). The session flag still counts, so
      // the ring hands over the instant a sweep finishes without waiting on a
      // storage round-trip.
      //
      // Applied async (a storage read) rather than lighting a default first —
      // a synchronous guess would visibly flash the ring on the wrong button.
      const applyGuidanceRing = async () => {
          let hasInventory = loadAllCompletedThisSession;
          if (!hasInventory) {
              const Core = window.ShareUnlimited.Core;
              if (Core && Core.Inventory && Core.Inventory.getAll) {
                  try { hasInventory = (await Core.Inventory.getAll()).length > 0; } catch (e) {}
              }
          }
          // The dialog can close (and these buttons be removed) while we read.
          if (!document.body.contains(searchGroupsBtn)) return;
          setAttention(showAllButton, !hasInventory);
          setAttention(searchGroupsBtn, hasInventory);
      };
      applyGuidanceRing();

      // 1-Click Presets button (added async after storage check)
      chrome.storage.local.get(['oneClickTemplates'], (result) => {
          if ((result.oneClickTemplates || []).length > 0) {
              const btn = makeBtn('share-unlimited-one-click-btn', `${iconSvg('zap')} 1-Click`);
              btn.addEventListener('click', (e) => {
                  e.preventDefault(); e.stopPropagation();
                  if (window.ShareUnlimited.UI && window.ShareUnlimited.UI.showOneClickPresetsModal) {
                      window.ShareUnlimited.UI.showOneClickPresetsModal();
                  }
              });
              toolbar.appendChild(btn);
          }
      });

      // Group Presets button (added async after storage check)
      chrome.storage.local.get(['groupPresets'], (result) => {
          const presets = result.groupPresets || [];
          if (presets.length > 0) {
              const btn = makeBtn('share-unlimited-group-presets-btn',
                  `${iconSvg('layers')} Presets <span class="su-badge">${presets.length}</span>`);
              btn.addEventListener('click', (e) => {
                  e.preventDefault(); e.stopPropagation();
                  if (window.ShareUnlimited.UI && window.ShareUnlimited.UI.showGroupPresetsModal) {
                      window.ShareUnlimited.UI.showGroupPresetsModal();
                  }
              });
              toolbar.appendChild(btn);
          }
      });

      container.appendChild(toolbar);

      // ── Row 2: Quick Share button (hidden until checkboxes selected) ─────────
      const quickShareRow = document.createElement('div');
      quickShareRow.id = 'share-unlimited-quick-share-btn';
      quickShareRow.style.cssText = `
          width: 100% !important;
          box-sizing: border-box !important;
          display: flex !important;
          flex-direction: row !important;
          align-items: center !important;
          gap: 8px !important;
          background: #1877f2 !important;
          overflow: hidden !important;
          max-height: 0 !important;
          opacity: 0 !important;
          pointer-events: none !important;
          transition: max-height 0.25s ease, opacity 0.25s ease, padding 0.25s ease !important;
          padding: 0 16px !important;
          border-top: 1px solid rgba(255,255,255,0.15) !important;
          border-radius: 0 0 7px 7px !important;
      `;

      const shareBtn = document.createElement('button');
      shareBtn.id = 'share-unlimited-share-btn';
      shareBtn.textContent = 'Share to Selected Groups';
      shareBtn.style.cssText = `
          flex: 1 !important;
          background: transparent !important;
          color: white !important;
          padding: 8px 16px !important;
          border: 2px solid rgba(255,255,255,0.4) !important;
          border-radius: 8px !important;
          font-size: 14px !important;
          font-weight: 700 !important;
          cursor: pointer !important;
          white-space: nowrap !important;
          pointer-events: auto !important;
          line-height: 1.4 !important;
      `;
      shareBtn.addEventListener('click', async () => {
          const Core = window.ShareUnlimited.Core;
          if (!Core || !Core.handleQuickShare) return;
          // NOTE: per-share setup is NOT started here. handleQuickShare only opens the
          // post-content modal and returns; the actual share (shareToSelectedGroups)
          // runs later when the user confirms that modal. Anything that must live for
          // the whole share (e.g. VisibilityWatch) starts inside shareToSelectedGroups.
          await Core.handleQuickShare();
      });

      const resetBtn = document.createElement('button');
      resetBtn.id = 'share-unlimited-reset-btn';
      resetBtn.textContent = '🔄 Reset';
      resetBtn.style.cssText = `
          background: rgba(255,59,48,0.2) !important;
          color: white !important;
          padding: 8px 14px !important;
          border: 2px solid rgba(255,59,48,0.5) !important;
          border-radius: 8px !important;
          font-size: 13px !important;
          font-weight: 600 !important;
          cursor: pointer !important;
          white-space: nowrap !important;
          pointer-events: auto !important;
          line-height: 1.4 !important;
          flex-shrink: 0 !important;
      `;
      resetBtn.addEventListener('click', () => {
          dialog.querySelectorAll('.multi-share-checkbox').forEach(cb => { cb.checked = false; });
          const selectAll = document.getElementById('share-unlimited-select-all');
          if (selectAll) selectAll.checked = false;
          clearCheckboxSelections();
          updateQuickShareButtonVisibility();
      });

      quickShareRow.appendChild(shareBtn);
      quickShareRow.appendChild(resetBtn);
      container.appendChild(quickShareRow);

      // First-run auto-setup (v16.4): zero cached groups for this profile means
      // the user has never built their inventory — run the Load All sweep for
      // them behind a progress modal instead of waiting for a button click.
      // Runs AFTER toolbar insertion and never blocks it (same rule as the
      // license check: functional UI must not wait on anything async).
      async function maybeAutoRunFirstTimeSetup() {
          if (autoSetupAttemptedThisPage || loadAllCompletedThisSession || sweepInProgress) return;
          const Core = window.ShareUnlimited.Core;
          if (!Core || !Core.Inventory || !Core.scrollToLoadAllGroups) return;
          let cached;
          try { cached = await Core.Inventory.getAll(); } catch (e) { return; }
          if (cached.length > 0) return; // returning profile — normal guided flow
          // Re-check after the await — a second toolbar build or a manual click
          // could have started things while we were reading storage.
          if (autoSetupAttemptedThisPage || loadAllCompletedThisSession || sweepInProgress) return;
          autoSetupAttemptedThisPage = true;

          // Give FB a beat to hydrate the first screenful (same reason as the
          // SETTLE re-scans), then confirm the dialog is still open.
          await new Promise(r => setTimeout(r, 800));
          if (sweepInProgress || !hasLiveSelectAllToolbar() || !getVisibleShareDialog()) return;

          console.log('🪄 First run for this profile (0 cached groups) — auto-running Load All');
          const modal = showAutoSetupModal(getFbProfileName());
          // "Not now" must actually stop us. The modal owns the message it shows the
          // user; all we do here is flip the flag the sweep polls.
          let userCancelled = false;
          modal.onCancel(() => { userCancelled = true; });

          const total = await runLoadAllSweep((n) => modal.setCount(n), () => userCancelled);

          // The modal is already showing its own "Stopped — no problem" state; saying
          // anything else over the top of it would undo the point of the button.
          if (userCancelled) return;
          if (total > 0 && getVisibleShareDialog()) modal.done(total);
          else modal.close(); // dialog closed mid-sweep / nothing found — no ceremony
      }

      // Insert and update badge count + restore quick-share visibility
      if (insertLocation.parentElement) {
          insertLocation.parentElement.insertBefore(container, insertLocation);

          setTimeout(async () => {
              // Prefer the profile's persisted inventory count over the DOM checkbox
              // count — FB only ever mounts ~20 rows at once (virtualization), so the
              // DOM count understates a profile that already has hundreds of groups
              // synced. A non-empty inventory also means this isn't a first-time sync,
              // so the button reads "Sync Latest Groups" instead of "Load All".
              if (!loadAllCompletedThisSession && !sweepInProgress) {
                  const Core = window.ShareUnlimited.Core;
                  let cachedCount = 0;
                  if (Core && Core.Inventory && Core.Inventory.getAll) {
                      try { cachedCount = (await Core.Inventory.getAll()).length; } catch (e) {}
                  }
                  // Re-check after the await — the sweep may have started/finished
                  // (or the dialog closed and the button been removed) while waiting.
                  if (!loadAllCompletedThisSession && !sweepInProgress && document.getElementById('share-unlimited-show-all-btn')) {
                      const badgeCount = cachedCount > 0 ? cachedCount : dialog.querySelectorAll('.multi-share-checkbox').length;
                      const label = cachedCount > 0 ? 'Sync Latest Groups' : 'Load All';
                      showAllButton.innerHTML = `${iconSvg('clipboard-list')} ${label} <span id="group-count-badge" class="su-badge">${badgeCount}</span>`;
                      // Keep the ring honest: "Sync Latest Groups" means the
                      // index already exists, so the lit button must be Select
                      // Groups. Same condition, same moment — they can't drift.
                      applyGuidanceRing();
                  }
              }
              // Restore the Share button if groups were already checked (e.g. after page refresh)
              updateQuickShareButtonVisibility();
          }, 1000);

          maybeAutoRunFirstTimeSetup();
      }
  }

  /**
   * Injects checkboxes next to each group in the share dialog.
   */
  /**
   * Resolves the live "Share to a group" dialog and the "All groups" heading that
   * marks where the group list begins. Returns null if the current dialog isn't the
   * share-to-group dialog. Re-queried on every call because React frequently
   * replaces these nodes.
   */
  function getShareDialogContext() {
    const dialog = getShareDialog();
    if (!dialog) return null;

    let isShareToGroupDialog = false;
    let allGroupsElement = null;
    // Both variants matter: the new UI labels the "All groups" heading as <h3> (was <h2>).
    const h2Elements = dialog.querySelectorAll('h2, h3');
    for (const h2 of h2Elements) {
      const h2Text = h2.textContent.trim();
      const spanInH2 = h2.querySelector('span');
      const spanText = spanInH2 ? spanInH2.textContent.trim() : '';

      if (h2Text === 'Share to a group' || spanText === 'Share to a group') {
        isShareToGroupDialog = true;
      }
      if (h2Text === 'All groups' || spanText === 'All groups') {
        allGroupsElement = h2;
      }
    }

    // Non-English UI (v17.7): both headings above are English. `allGroupsElement` stays
    // null, which the caller already tolerates (it only uses it to skip buttons ABOVE
    // the heading), so the toolbar and checkboxes still go in.
    if (!isShareToGroupDialog) {
      const Core = window.ShareUnlimited && window.ShareUnlimited.Core;
      if (Core && Core.Struct && Core.Struct.findGroupSearchInput(dialog) &&
          dialog.querySelector('div[role="listitem"]')) {
        isShareToGroupDialog = true;
      }
    }

    if (!isShareToGroupDialog) return null;
    return { dialog, allGroupsElement };
  }

  /**
   * Synchronous, idempotent single pass: adds a checkbox to every currently-rendered
   * group row that doesn't already have one. Returns the number of NEW checkboxes added.
   *
   * Safe to call repeatedly. Facebook virtualizes the group list — only ~20 rows exist
   * in the DOM at any moment, and rows mount/unmount as the user scrolls — so this must
   * be re-run on every scroll/list mutation to keep coverage complete (see the persistent
   * observer in content_main.js).
   */
  function scanAndAddCheckboxes(dialog, allGroupsElement) {
      let newCheckboxes = 0;
      const allButtons = dialog.querySelectorAll('div[role="button"]');
      const addedGroupNames = new Set();

      allButtons.forEach((button, index) => {
        // Skip if this button appears before "All groups" heading
        if (allGroupsElement) {
          const buttonPosition = button.compareDocumentPosition(allGroupsElement);
          // If button comes before allGroupsElement in document order, skip it
          if (buttonPosition & Node.DOCUMENT_POSITION_FOLLOWING) {
            return; // Skip buttons that appear before "All groups"
          }
        }
        
        const buttonText = button.textContent.trim();
        const buttonTextLength = buttonText.length;
        const hasImage = button.querySelector('image, img, svg') !== null;
        
        const isInGroupList = button.closest('[role="listitem"]') !== null;
        const hasGroupIndicator = buttonText.includes('Public group') ||
                                 buttonText.includes('Private group') ||
                                 buttonText.toLowerCase().includes('members') ||
                                 (isInGroupList && (buttonText.includes('Public') || buttonText.includes('Private'))) ||
                                 // Non-English UI (v17.7): all markers above are English, so a
                                 // translated group list produced NO checkboxes at all. A row inside
                                 // the picker's listitem that carries an avatar is a group row in any
                                 // language.
                                 (isInGroupList && hasImage);

        if (buttonTextLength > 10 && buttonTextLength < 200 && hasImage && hasGroupIndicator) {
          if (button.querySelector('.multi-share-checkbox')) return;
          
          // Use the same validation as getGroupNames()
          if (!window.ShareUnlimited.Core || !window.ShareUnlimited.Core.extractAndValidateGroupName) return;
          const groupName = window.ShareUnlimited.Core.extractAndValidateGroupName(buttonText, button);
          if (!groupName || addedGroupNames.has(groupName)) return;
          addedGroupNames.add(groupName);
  
          const checkbox = document.createElement('input');
          checkbox.type = 'checkbox';
          checkbox.className = 'multi-share-checkbox';
          checkbox.style.cssText = `
            margin-right: 16px !important; 
            height: 44px !important; 
            width: 44px !important; 
            cursor: pointer !important; 
            z-index: 9999 !important; 
            position: relative !important;
            accent-color: #1877f2 !important;
            border: 3px solid #1877f2 !important;
            border-radius: 6px !important;
            flex-shrink: 0 !important;
            background: white !important;
          `;
          
          // Restore saved selection state
          applySelectionState(checkbox, groupName);
          
          checkbox.addEventListener('click', (e) => {
            e.stopPropagation();
            setTimeout(updateQuickShareButtonVisibility, 50);
            // Save selections when checkbox state changes
            setTimeout(saveCheckboxSelections, 100);
          }, true);
          
          checkbox.addEventListener('mousedown', (e) => { e.stopPropagation(); }, true);
          
          button.style.display = 'flex';
          button.style.alignItems = 'center';
          button.style.gap = '8px';
          button.prepend(checkbox);
          newCheckboxes++;
        }
      });
      return newCheckboxes;
  }

  /**
   * Live wrapper: resolves the current dialog and runs one idempotent checkbox pass.
   * Returns the number of new checkboxes added (0 if not on the share dialog).
   * This is what the persistent scroll/mutation observer calls.
   */
  function scanAndAddCheckboxesLive() {
    const ctx = getShareDialogContext();
    if (!ctx) return 0;
    const added = scanAndAddCheckboxes(ctx.dialog, ctx.allGroupsElement);
    if (added > 0) addSelectAllCheckbox(ctx.dialog);
    return added;
  }

  /**
   * Initial checkbox pass when the dialog opens. Retries (groups may still be
   * loading) until at least one checkbox is added. Ongoing coverage as the user
   * scrolls the virtualized list is handled by the persistent observer in
   * content_main.js, which repeatedly calls scanAndAddCheckboxesLive().
   */
  async function addCheckboxesToGroups() {
    let attempts = 0;
    const maxAttempts = 10;

    while (attempts < maxAttempts) {
      attempts++;
      await new Promise(r => setTimeout(r, 500));

      // Re-query live dialog each attempt — React may have replaced the element
      // during the wait, making the original reference stale/detached.
      const added = scanAndAddCheckboxesLive();
      if (added > 0) break;
    }
  }

  /**
   * Adds "Multi-Group" buttons next to native Facebook share buttons
   */
  function addMultiGroupButtons() {
    // Find all potential share buttons that don't already have a Multi-Group button
    const allButtons = document.querySelectorAll('div[role="button"]');
    
    allButtons.forEach(button => {
      // Skip if we already added a button here
      if (button.dataset.multiGroupAdded === 'true') return;
      
      // Skip if this IS a Multi-Group button (to avoid infinite loops)
      if (button.dataset.multiGroupButton === 'true') return;
      
      // Check if this is a Share button
      // Use data-ad-rendering-role="share_button" as the most reliable signal (Facebook structural attr)
      // Also keep aria-label fallback for compatibility
      const ariaLabel = (button.getAttribute('aria-label') || '').toLowerCase();

      const isShareButton = (
        button.querySelector('[data-ad-rendering-role="share_button"]') !== null ||
        ariaLabel.includes('send this to friends') ||
        (ariaLabel.includes('share') && !ariaLabel.includes('boost') && !ariaLabel.includes('promote'))
      );

      if (!isShareButton) return;

      // Skip if in a dialog (only add to post buttons, not dialog buttons)
      if (button.closest('div[role="dialog"]')) return;

      // Get the parent container structurally (direct parent of the share button wrapper)
      // Do NOT use fragile class-name selectors that break when Facebook changes their CSS
      const parentContainer = button.parentElement;

      if (!parentContainer) return;

      // Only mark as processed AFTER we confirm we can actually insert — prevents silent failures
      button.dataset.multiGroupAdded = 'true';

      // Build a completely fresh button — do NOT clone FB's button since it inherits
      // CSS rules that hide or collapse text (color: transparent, overflow: hidden, etc.)
      const multiGroupButton = document.createElement('div');
      multiGroupButton.setAttribute('role', 'button');
      multiGroupButton.setAttribute('tabindex', '0');
      multiGroupButton.setAttribute('aria-label', 'Share this to multiple groups at once');
      multiGroupButton.dataset.multiGroupButton = 'true';

      // Themed neutral surface (NOT solid blue) so it reads as a native FB action
      // button in both light and dark mode — same .su-native variable system as the
      // toolbar's ghost buttons. The blue is carried entirely by the permanent
      // attention ring below, which draws the eye far better than a flat blue fill.
      if (window.ExpiredOverlay && window.ExpiredOverlay.ensureNativeStyles) {
        window.ExpiredOverlay.ensureNativeStyles();
      }
      const mgbDark = !!(window.ExpiredOverlay && window.ExpiredOverlay.isFbDarkMode &&
        window.ExpiredOverlay.isFbDarkMode());
      multiGroupButton.className = 'su-native' + (mgbDark ? ' su-dark' : '');
      multiGroupButton.style.cssText = `
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 6px 12px;
        /* --su-mgb-fg drives the LABEL color. The label span needs its own explicit
           color declaration to beat FB's cascade (which can render it transparent),
           so it can't simply inherit — routing it through a variable is what lets
           the hover rule below flip it to white. */
        --su-mgb-fg: var(--su-text);
        background: var(--su-surface-2);
        color: var(--su-mgb-fg);
        border-radius: 6px;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        user-select: none;
        white-space: nowrap;
        line-height: 1.4;
        border: 1px solid var(--su-border);
        outline: none;
        font-family: inherit;
        /* 4px (was 2px) so the ring, which sits at inset:-4px, isn't clipped by
           FB's action-bar layout or crowded against the neighbouring Share icon. */
        margin: 4px;
        transition: background 0.2s ease, border-color 0.2s ease, color 0.2s ease,
                    transform 0.2s cubic-bezier(0.16, 1, 0.3, 1), box-shadow 0.2s ease;
      `;
      // MGSA brand mark in place of the 🚀 emoji. images/* is already exposed via
      // web_accessible_resources (<all_urls>), so the content script can load it.
      // The logo is a TRANSPARENT, predominantly-blue PNG — bare, it would all but
      // vanish against the #1877F2 hover fill — so it sits on a small white chip
      // that stays legible on the grey idle surface, in FB dark mode, and on the
      // blue hover alike. getURL throws once the extension context is invalidated
      // (reload-without-tab-refresh), so the emoji stays as the fallback.
      let mgbIconHtml = '<span style="pointer-events:none;">🚀</span>';
      try {
        const mgbLogoUrl = chrome.runtime.getURL('images/icon128.png');
        mgbIconHtml =
          '<span style="display:inline-flex;align-items:center;justify-content:center;' +
          'width:20px;height:20px;border-radius:5px;background:#ffffff;flex-shrink:0;' +
          'pointer-events:none;">' +
          '<img src="' + mgbLogoUrl + '" alt="" ' +
          'style="display:block;width:15px;height:15px;pointer-events:none;">' +
          '</span>';
      } catch (e) {
        console.warn('MGSA logo unavailable, using emoji fallback:', e);
      }
      multiGroupButton.innerHTML = mgbIconHtml +
        '<span style="color:var(--su-mgb-fg);font-size:14px;font-weight:600;pointer-events:none;">Multi-Share</span>';

      // Permanent rotating blue ring — this button is the extension's entry point,
      // so it stays lit at all times (unlike the toolbar's guided one-at-a-time ring).
      setAttention(multiGroupButton, true);

      // Spinner keyframes for the button's busy state (injected once per page)
      if (!document.getElementById('su-mgb-spinner-style')) {
        const spinnerStyle = document.createElement('style');
        spinnerStyle.id = 'su-mgb-spinner-style';
        // CSS-only states (matching .su-ghost-btn's approach — no JS hover
        // handlers). All gated on :not([data-busy="true"]) so the Working…
        // spinner state never shifts under the cursor.
        const MGB = '[data-multi-group-button="true"]:not([data-busy="true"])';
        spinnerStyle.textContent =
          '@keyframes su-mgb-spin { to { transform: rotate(360deg); } }' +
          // A FEED can hold dozens of these buttons at once, so the ring runs much
          // slower here (4.5s vs the toolbar's 1.2s) — a calm drift instead of dozens
          // of fast spinners competing for attention. Scoped to this button so the
          // in-dialog guidance ring, where exactly ONE is ever lit, keeps its pace.
          '[data-multi-group-button="true"].su-attn::after { animation-duration: 4.5s !important; }' +
          // Hover: neutral surface → FB blue with a white label, lifted on a warm
          // glow. Blue/orange are complementary, so the ring reads as a deliberate
          // accent against the fill rather than a clash.
          MGB + ':hover {' +
            'background: #1877F2 !important;' +
            'border-color: #1877F2 !important;' +
            '--su-mgb-fg: #ffffff !important;' +
            'transform: translateY(-1px) !important;' +
            'box-shadow: 0 6px 18px rgba(255,138,0,0.32) !important;' +
            // Recolor the rotating sweep to orange — geometry/animation untouched,
            // only the conic gradient's color stops swap, so there's no restart jump.
            '--su-ring-0: rgba(255,138,0,0) !important;' +
            '--su-ring-1: rgba(255,183,77,0.65) !important;' +
            '--su-ring-2: #ff8a00 !important;' +
            '--su-ring-3: #ffd9a0 !important;' +
          '}' +
          // Tactile press — settles back to flat before the click flow starts.
          MGB + ':active { transform: translateY(0) scale(0.97) !important;' +
            'box-shadow: 0 2px 8px rgba(255,138,0,0.28) !important; }';
        document.head.appendChild(spinnerStyle);
      }

      // Add click handler
      multiGroupButton.addEventListener('click', async (e) => {
        e.preventDefault();
        e.stopPropagation();

        console.log('🎯 Multi-Group button clicked!');

        // Re-entry guard + spinner: reaching the group dialog can take several
        // seconds (popup poll + paint buffer, and longer on the "More options"
        // menu variant). A second click mid-flow re-clicks the Share button and
        // derails the whole sequence. So: swallow clicks while busy and show a
        // spinner until the flow finishes — with a 10s hard cap so the button can
        // never get stuck spinning if Facebook never shows the popup.
        // (Deliberately NOT pointer-events:none — that would let clicks fall
        // through to whatever is underneath the button.)
        if (multiGroupButton.dataset.busy === 'true') {
          console.log('⏳ Multi-Group is already working — extra click ignored');
          return;
        }
        multiGroupButton.dataset.busy = 'true';
        const idleHTML = multiGroupButton.innerHTML;
        // currentColor-based so the spinner stays legible on the themed neutral
        // surface in both light and dark mode (it was white-on-blue before).
        multiGroupButton.innerHTML =
          '<span style="display:inline-block;width:14px;height:14px;border:2px solid rgba(128,128,128,0.4);border-top-color:currentColor;border-radius:50%;animation:su-mgb-spin 0.8s linear infinite;pointer-events:none;flex-shrink:0;"></span>' +
          '<span style="color:var(--su-mgb-fg);font-size:14px;font-weight:600;pointer-events:none;">Working…</span>';
        multiGroupButton.style.cursor = 'default';
        multiGroupButton.style.opacity = '0.85';
        const restoreButton = () => {
          multiGroupButton.dataset.busy = 'false';
          multiGroupButton.innerHTML = idleHTML;
          multiGroupButton.style.cursor = 'pointer';
          multiGroupButton.style.opacity = '1';
        };
        // Safety net only — must outlast the ~9.5s worst-case Group-option poll below.
        const spinnerSafetyTimer = setTimeout(restoreButton, 15000);

        try {

        // CRITICAL: pin THIS listing's Share button as the authoritative target before
        // anything else. The user clicked Multi-Group on a specific listing, so `button`
        // is the only reliable signal of *which* listing to share. Marking it here makes
        // every later findShareButton() (pre-cache + reopenShareDialog for groups 2+)
        // resolve back to this exact button instead of re-scanning the whole page and
        // grabbing another visible listing's Share button (which caused the extension to
        // scroll to and share the WRONG listing).
        if (window.ShareUnlimited.Core && window.ShareUnlimited.Core.markAndCacheButton) {
          window.ShareUnlimited.Core.markAndCacheButton(button);
          console.log('📌 Pinned this listing\'s Share button as the share target.');
        }

        // First, click the original Share button to track it
        console.log('📍 Step 1: Clicking original Share button...');
        button.click();

        // Wait for the thing we actually need, not just "a dialog". "Any
        // div[role=dialog] exists" is NOT a readiness signal: on permalink/theater
        // views a dialog is already in the DOM before the popover mounts (and FB keeps
        // hidden previous share screens mounted as sibling dialogs), so a
        // dialog-presence poll exits on its first tick and a one-shot Group-option
        // scan then runs before the menu items exist — the popover just sits there
        // un-clicked (~half of Multi-Group clicks). So poll for the goal itself, up to
        // 8s: either the combined dialog already showing the groups list, or a
        // clickable "Group" / "Share to a group" option.
        console.log('📍 Step 2: Waiting for groups list or Group option in Share modal...');

        // NEW UI: Facebook can show the "Share to a group" groups list INSIDE the main
        // Share modal (same dialog as "Share now" and "Send in Messenger").
        const dialogHasGroupsHeading = () => {
          const shareDialog = getShareDialog();
          if (!shareDialog) return false;
          const byHeading = Array.from(shareDialog.querySelectorAll('h2, h3')).some(h2 => {
            const text = h2.textContent.trim();
            const span = h2.querySelector('span');
            return text === 'Share to a group' || (span && span.textContent.trim() === 'Share to a group');
          });
          if (byHeading) return true;
          // Non-English UI (v17.7): search box + group rows means the list is showing.
          const Core = window.ShareUnlimited && window.ShareUnlimited.Core;
          return !!(Core && Core.Struct && Core.Struct.findGroupSearchInput(shareDialog) &&
                    shareDialog.querySelector('div[role="listitem"]'));
        };

        // Scans the current menu and clicks the "Group" / "Share to a group" item.
        // Returns true if it found and clicked one. Re-runnable so it can retry on
        // every poll tick and again after revealing more items via "More options".
        const clickGroupOptionInModal = () => {
          const menuItems = document.querySelectorAll('div[role="button"], div[role="menuitem"], div[role="option"]');
          for (const item of menuItems) {
            if (item.dataset.multiGroupButton === 'true') continue;

            const itemAriaLabel = (item.getAttribute('aria-label') || '').trim();
            const hasShareToGroupAriaLabel = itemAriaLabel === 'Share to a group';
            const hasExactGroupSpan = Array.from(item.querySelectorAll('span')).some(span =>
              span.textContent.trim() === 'Group' || span.textContent.trim() === 'Share to a group'
            );
            const isExactGroupText = item.textContent.trim() === 'Group' || item.textContent.trim() === 'Share to a group';

            if (hasShareToGroupAriaLabel || hasExactGroupSpan || isExactGroupText) {
              console.log('✅ Found Group option:', item.textContent.trim(), '| aria-label:', itemAriaLabel);
              item.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
              item.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
              item.click();
              return true;
            }
          }

          // Non-English UI (v17.7): all three checks above are English, so the manual
          // Multi-Group click found nothing on a translated share sheet. Fall back to
          // the tile's ICON, which is the same sprite offset in every locale.
          const Core = window.ShareUnlimited && window.ShareUnlimited.Core;
          const byIcon = Core && Core.Struct && Core.Struct.findGroupOptionByIcon();
          if (byIcon) {
            console.log('🌍 Found Group option by icon (non-English UI)');
            byIcon.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
            byIcon.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
            byIcon.click();
            return true;
          }

          return false;
        };

        let groupFlowOpened = false;
        let triedMoreOptions = false;
        for (let waited = 0; waited < 8000; waited += 250) {
          await new Promise(resolve => setTimeout(resolve, 250));

          if (dialogHasGroupsHeading()) {
            // New combined-dialog UI: groups are already in the modal.
            // The MutationObserver in content_main.js will detect the heading and add checkboxes.
            console.log('✅ New combined Share dialog detected — groups section already visible, MutationObserver will handle it.');
            groupFlowOpened = true;
            break;
          }

          // Only scan for the Group option once some popup/menu is actually mounted,
          // so exact-text matches can't grab unrelated page elements pre-popover.
          const popupPresent = document.querySelector('div[role="dialog"], div[role="menu"], div[role="menuitem"], div[role="listbox"]');
          if (popupPresent && clickGroupOptionInModal()) {
            groupFlowOpened = true;
            break;
          }

          // NEW UI variant: "Share to a group" is nested behind a "More options" item.
          // Give the direct option 1.5s to mount first, then reveal the submenu (once
          // per run) and keep polling — the revealed items can take a beat to mount too.
          if (!triedMoreOptions && waited >= 1500 && popupPresent &&
              window.ShareUnlimited.Core && window.ShareUnlimited.Core.clickMoreOptionsIfPresent) {
            triedMoreOptions = await window.ShareUnlimited.Core.clickMoreOptionsIfPresent();
            if (triedMoreOptions) {
              console.log('📍 Step 2b: Re-scanning for Group option after "More options"...');
            }
          }
        }

        if (!groupFlowOpened) {
          console.warn('⚠️ Could not find Group option in Share modal within 8s — check Facebook UI structure');
        }

        } finally {
          // Flow finished (or threw) — stop the spinner and re-arm the button.
          clearTimeout(spinnerSafetyTimer);
          restoreButton();
        }
      }, true);
      
      // Wrap in a div styled to sit inline with the other action buttons
      const wrapper = document.createElement('div');
      wrapper.dataset.multiGroupWrapper = 'true';
      wrapper.style.cssText = 'display:inline-flex;align-items:center;';
      wrapper.appendChild(multiGroupButton);

      // Insert right after the Share button's parent container
      if (parentContainer.parentElement) {
        parentContainer.parentElement.insertBefore(wrapper, parentContainer.nextSibling);
        console.log('✅ Multi-Group button inserted next to Share button');
      } else {
        delete button.dataset.multiGroupAdded;
        console.warn('⚠️ Could not insert Multi-Group button — parentContainer has no parent');
      }
    });
  }

  /**
   * Shows a success notification at the top right
   */
  function showSuccessNotification(message) {
    const existing = document.getElementById('share-unlimited-success-notification');
    if (existing) existing.remove();
    
    const notification = document.createElement('div');
    notification.id = 'share-unlimited-success-notification';
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%);
        color: white;
        padding: 16px 24px;
        border-radius: 12px;
        font-size: 16px;
        font-weight: 600;
        z-index: 999999999;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
        animation: slideInRight 0.3s ease-out;
    `;
    notification.textContent = message;
    
    // Add animation
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideInRight {
            from {
                opacity: 0;
                transform: translateX(100px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
    `;
    document.head.appendChild(style);
    
    document.body.appendChild(notification);
    
    // Auto-remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideInRight 0.3s ease-out reverse';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
  }

  /**
   * Legacy applyGroupPresetOnFacebook removed: presets now share directly via
   * showMergedPresetsConfirmation → showPostContentModal (content_ui_modals.js),
   * which searches for each group at share time instead of ticking checkboxes.
   */

  // Export functions
  Object.assign(UI, {
    addQuickShareButton,
    updateQuickShareButtonVisibility,
    addSelectAllCheckbox,
    addCheckboxesToGroups,
    scanAndAddCheckboxesLive,
    addMultiGroupButtons,
    showSuccessNotification,
    // Source-of-truth accessor for selections (survives list virtualization).
    getSavedSelections: loadCheckboxSelections
  });

})();
