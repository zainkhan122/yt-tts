/**
 * AI post variants — the in-Facebook (overlay) generator. (v17.9)
 *
 * The popup has had AI variations since early on (popup.html + ai_content.js →
 * background `generate_content` → background/api.js `generatePostVariations`).
 * This module brings the same capability to the surface where people actually
 * write their post: the "What's on your mind?" box inside the share modal.
 *
 * It generates 10–20 versions of one post. `shareToSelectedGroups` already
 * rotates them (`postVariations[i % postVariations.length]`), so group 21 with
 * 20 variants wraps back to the first — the rotation is NOT implemented here.
 *
 * WHY the prompts are so long: Facebook's spam heuristics key on the *same* text
 * appearing in group after group, so the variants have to differ — but the
 * user's post is theirs, and changing what it says or how it feels is a bug, not
 * a feature. The default PRESERVE prompt spends most of its length pinning down
 * what must NOT move (meaning, sentiment, length, structure, every detail) so
 * that the only thing left moving is surface wording.
 *
 * Exposed as window.ShareUnlimited.AIVariants; consumed by content_ui_modals.js.
 */
(function () {
  'use strict';

  window.ShareUnlimited = window.ShareUnlimited || {};

  // Hard ceiling. More than this stops being "a different post each time" and
  // starts being padding — and every extra variant is more to read and approve.
  const MAX_VARIANTS = 20;
  const COUNT_OPTIONS = [10, 15, 20];
  const DEFAULT_COUNT = 10;

  // ---------------------------------------------------------------------------
  // The prompts. This is the product.
  //
  // THREE BASE PROMPTS, not one base plus modifiers. The first two give the
  // model opposite orders and cannot be merged:
  //
  //   PRESERVE  (default) — same post, minimally reworded. Same meaning, same
  //             sentiment, same length, same structure, same details. The change
  //             is only enough that no two groups get a byte-identical string.
  //   REWRITE   — genuinely different posts: different opening, length, register.
  //   CUSTOM    — the user writes the styling instruction; the base supplies the
  //             context they'd otherwise have to explain, plus the safety rules.
  //
  // All three embed NO_INVENT verbatim. That block is not a style — it is the
  // guarantee that a variant never says something the user didn't.
  //
  // PRESERVE is the default because it is what people actually want when they
  // have already written their post: the first release defaulted to REWRITE and
  // the variants read as a different author with a different mood. A rewrite is
  // a creative choice the user opts into, never something that happens to the
  // text they typed.
  //
  // background/api.js appends its own "Task: generate N / Format: raw JSON array"
  // block after these strings — don't restate the output format here or the two
  // instructions start competing.
  // ---------------------------------------------------------------------------

  /**
   * The no-invention block. Shared VERBATIM by all three bases — this is the one
   * part of the prompt that no mode, style or custom instruction may soften.
   *
   * The reported failure it exists for: a user sharing SOMEONE ELSE'S house
   * ("check out this home, it feels like home") got variants ending "DM me for
   * more info". They can't answer questions about it — it isn't theirs. The model
   * hadn't gone rogue: `rewriteBase` used to order it to "end with one clear ask
   * (comment, DM, tag someone)", so it dutifully invented a CTA and, with it, an
   * implied claim of ownership. Hence two separate defences below: never add an
   * ask that wasn't there, and never change who is speaking or what they are to
   * the thing they're posting about.
   */
  const NO_INVENT = `NEVER INVENT. This is the most important rule here, and it outranks every stylistic instruction:
- Add no facts. No prices, dates, sizes, conditions, features, locations, availability, guarantees, statistics or opinions that are not already in the user's post.
- Add no call to action and no contact route that is not already in the user's post. No "DM me", "message me", "send me a message", "comment below", "tag a friend", "link in comments", "call me", no phone number, no email, no WhatsApp. If the post makes no ask, every version makes no ask.
- Do not change WHO is speaking or their relationship to what they are posting about. If they are passing along, recommending or sharing something on someone else's behalf, every version keeps exactly that stance — never write as though they own it, live there, sell it, profit from it, or can answer questions about it. Words like "my", "mine", "I'm selling", "come see it", "I can show you around" are forbidden unless the user's post already says them.
- Add no endorsement or feeling the user did not express. Not "I love this place", not "highly recommend", not "amazing deal", not "you won't regret it" — unless their post already says it.
- If something in the post is vague, LEAVE IT VAGUE. Never resolve an ambiguity by guessing, and never fill a gap with a plausible detail.

Everything a version says must trace back to the user's post. If you are unsure whether something is in there, leave it out.`;

  /**
   * PRESERVE. Every line here defends one thing: the user must still recognise
   * their own post. Sentiment, length and structure are locked; only surface
   * wording moves. The percentages are deliberate — a model told merely to
   * "change it slightly" either rewrites anyway or returns the input verbatim.
   */
  function preserveBase(count) {
    return `You are lightly rewording ONE Facebook post so the same person can post it in several groups without it being the identical string every time.

This is a MINIMAL-CHANGE task. The user already wrote what they want to say. Produce ${count} versions that any reader would call the SAME POST — same message, same sentiment, same length, same structure — but that are not identical text.

Keep, exactly:
- The MEANING and the SENTIMENT. Warm stays warm, blunt stays blunt, excited stays excited, plain stays plain. Never add enthusiasm, urgency, humour, politeness or salesiness that isn't already there, and never drain any that is.
- The LENGTH. Each version stays within about 10% of the original's word count. Never expand one line into a paragraph. Never compress a paragraph into one line.
- The STRUCTURE. Same number of lines and paragraph breaks, same order of information, same subject in the opening line, same closing line and same call to action.
- Every concrete detail EXACTLY as written: prices, numbers, dates, times, names, places, links, phone numbers, @mentions, hashtags.
- The EMOJI: the same emoji, the same number of them, in the same places.
- The user's formatting habits: their capitalisation, their line breaks, their bullet characters, any word they chose to put in CAPS.

Change, and only lightly:
- Swap a handful of words for natural equivalents a real person would use.
- Reorder a clause or two inside a sentence.
- Adjust small connective words and punctuation (a comma where they had a dash, "and" for "plus").
- Contract or expand a contraction where it still sounds like them.

Target: roughly 10–20% of the words differ between any two versions. Enough that they aren't the same string; little enough that the user reads it back and thinks "yes, that's my post".

Never:
- rewrite the opening into a different kind of hook
- change the tone, register or personality
- add or remove information, claims, questions, calls to action, hashtags or emoji
- pad a short post to make it look more different — a two-line post gets two lightly-changed lines, and that is correct
- change the language: write in the same language, dialect and slang as the original

${NO_INVENT}

Output the post text only — no numbering, no labels, no surrounding quotes, no markdown.`;
  }

  /** REWRITE. Opt-in. Genuinely different posts, for when the seed is a rough brief. */
  function rewriteBase(count) {
    return `You are a real person who posts in Facebook groups. You are not a marketer and not an AI assistant. You write the way people actually type into a group.

Rewrite the user's message as ${count} genuinely DIFFERENT posts. Same offer, same facts, same intent — different post each time, not a synonym pass.

Sound human:
- Change the OPENING every single time. Some start with the thing itself, some with one line of story, some with a question, a number, an admission, a recommendation, a mild complaint.
- Change the LENGTH hard. Some one line. Some two or three. Some five or six short lines with breaks. Never the same shape twice.
- Change the REGISTER: casual, blunt, warm, excited, dry, matter-of-fact, funny. A few with 1–3 emoji placed where a person would put them, several with none at all.
- Real typing habits: contractions, sentence fragments, an em dash, the occasional lowercase opening. Use filler like "honestly" or "btw" only where that register earns it.
- Keep every concrete detail the user gave — prices, dates, names, places, links, phone numbers — EXACTLY as written. Never invent one that wasn't given.

Make them worth stopping for:
- Lead with the most interesting thing the post ALREADY contains, not with setup or context.
- If the post ends with an ask, keep that ask — you may word it differently. If the post has no ask, do not give it one.
- The first eight words have to earn the rest. Assume the reader is scrolling fast.

Hard rules — these protect the poster's account:
- No two variants may share their first six words, and no variant may read like a find-and-replace of another.
- No hashtag spam (0–2, only where natural). No emoji chains. No ALL-CAPS shouting. No "DM ME NOW!!!". No urgency, scarcity, guarantee, statistic or testimonial the user did not supply.
- Write in the SAME LANGUAGE as the user's message. If they wrote in Hebrew, Spanish or Arabic, every variant is in that language.

${NO_INVENT}

Freedom here is about HOW the post is written — the opening, the length, the rhythm, the tone. It is never freedom to change WHAT it says or WHO is saying it.

Output the post text only — no numbering, no labels, no "Variation 1:", no surrounding quotes, no markdown.`;
  }

  /**
   * CUSTOM. The user writes the styling instruction themselves.
   *
   * They are typing one line ("keep it very close but make it warmer", "third
   * person, I'm posting for a friend"), NOT a system prompt — so everything they
   * would otherwise have to know is stated for them first: what the output is
   * for, how many, that the versions rotate across groups, and that they must
   * never be identical. That preamble is why a one-line instruction works here.
   *
   * Precedence is explicit and one-directional: their instruction decides HOW
   * MUCH and IN WHAT DIRECTION the text moves, and NO_INVENT still governs what
   * may be said. The one carve-out is deliberate — if they explicitly ask for
   * something to be added, that is their own post's content, not a hallucination.
   */
  const MAX_CUSTOM_CHARS = 600;

  function customBase(count, instruction) {
    const asked = String(instruction || '').trim().slice(0, MAX_CUSTOM_CHARS);
    return `You are helping someone post the SAME Facebook post to several groups.

Here is what is happening, so you can judge the request properly:
- The user has written one post. It is pasted below as the user prompt.
- Posting the identical text into group after group is what gets an account flagged, so they need ${count} versions of it.
- Each group receives ONE version, in order, cycling back to the first when the versions run out. A reader only ever sees one of them.
- So the versions must not be identical to each other — but they must all still be the post the user meant to publish.

The user has written their own instruction for how you should change it. It is the styling brief for this job, and it decides how far the wording moves and in which direction. Follow it as closely as you can:

<<<USER INSTRUCTION
${asked}
USER INSTRUCTION

If their instruction does not say how much to change, change as little as possible while keeping the versions distinct from one another.

${NO_INVENT}

The one exception to the rule above: if the user's instruction explicitly asks you to add something — a greeting, a sign-off, a specific line, a particular ask — then add it, because they chose it. Adding anything they did NOT ask for and that is NOT in their post remains forbidden.

Always, regardless of the instruction:
- Write in the same language as the user's post.
- Keep every price, number, date, name, place, link, phone number and @mention exactly as written.
- Output the post text only — no numbering, no labels, no explanations, no surrounding quotes, no markdown.`;
  }

  // `mode` picks the base prompt; `clause` is appended to it. A style may only
  // append — anything that needs to contradict its base needs its own base.
  const STYLES = {
    subtle: {
      mode: 'preserve',
      group: 'Keep my post',
      label: 'Subtle — same post, lightly reworded',
      hint: 'Your exact message, sentiment and length. Only a few words move — just enough that no two groups get identical text.',
      clause: ''
    },
    fresh: {
      mode: 'preserve',
      group: 'Keep my post',
      label: 'Fresh wording — same message & length',
      hint: 'Same message, sentiment, length and structure — but reworded more noticeably than Subtle.',
      clause: '\n\nAdjustment to the target above: aim for roughly 30–40% of the words to differ between versions. You may rebuild a sentence rather than only swap words — but every "Keep, exactly" rule above still holds without exception, especially the sentiment, the length and the opening subject.'
    },
    auto: {
      mode: 'rewrite',
      group: 'Rewrite it for me',
      label: 'Creative mix — full rewrites',
      hint: '⚠️ Writes genuinely different posts — different openings, lengths and tone. Best when you typed a rough brief, not a finished post.',
      clause: ''
    },
    casual: {
      mode: 'rewrite', group: 'Rewrite it for me', label: 'Rewrite — casual & friendly',
      hint: '⚠️ Full rewrites, leaning relaxed and friendly.',
      clause: '\n\nOverall lean: relaxed and friendly, like telling a friend. Still vary the openings and lengths.'
    },
    hype: {
      mode: 'rewrite', group: 'Rewrite it for me', label: 'Rewrite — excited / high energy',
      hint: '⚠️ Full rewrites, leaning high-energy.',
      clause: '\n\nOverall lean: high energy and enthusiastic — genuine excitement, not advertising shout. Still vary the openings and lengths.'
    },
    story: {
      mode: 'rewrite', group: 'Rewrite it for me', label: 'Rewrite — story-first',
      hint: '⚠️ Full rewrites that open with a small moment before the point.',
      clause: '\n\nOverall lean: open with a small, specific, believable moment before the point. Keep the stories short and different from each other.'
    },
    offer: {
      mode: 'rewrite', group: 'Rewrite it for me', label: 'Rewrite — straight to the offer',
      hint: '⚠️ Full rewrites, plain and direct.',
      clause: '\n\nOverall lean: plain and direct — what it is, what it costs, how to get it. Vary the phrasing, keep the fluff out.'
    },
    question: {
      mode: 'rewrite', group: 'Rewrite it for me', label: 'Rewrite — question hook',
      hint: '⚠️ Full rewrites that open with a question.',
      clause: '\n\nOverall lean: open with a real question the reader might answer. Use a different question every time; never the same template.'
    },
    custom: {
      mode: 'custom',
      group: 'Your own instructions',
      label: '✏️ Custom — tell the AI what to do',
      hint: 'You write the instruction. The AI is already told what the job is — just say how you want your post changed.',
      clause: ''
    }
  };

  // The safe default: never restyle text the user already finished writing.
  const DEFAULT_STYLE = 'subtle';

  function buildSystemPrompt(count, style, custom) {
    const s = STYLES[style] || STYLES[DEFAULT_STYLE];
    if (s.mode === 'custom') return customBase(count, custom);
    const base = s.mode === 'rewrite' ? rewriteBase(count) : preserveBase(count);
    return base + (s.clause || '');
  }

  // ---------------------------------------------------------------------------
  // Generation
  // ---------------------------------------------------------------------------

  /**
   * Asks the background worker for `count` variants of `seed`.
   * Resolves with a cleaned, de-duplicated array (never longer than MAX_VARIANTS).
   * Rejects with a message safe to show the user.
   */
  function generateVariants({ seed, count, style, custom }) {
    const n = clampCount(count);
    return new Promise((resolve, reject) => {
      let settled = false;
      const fail = (msg) => { if (!settled) { settled = true; reject(new Error(msg)); } };

      // A cold Vercel start plus generation can be slow, but not this slow —
      // without a timeout a dropped sendMessage callback leaves the UI spinning
      // forever with no way back.
      const timer = setTimeout(() => fail('That took too long. Check your connection and try again.'), 90000);

      try {
        chrome.runtime.sendMessage({
          type: 'generate_content',
          prompt: seed,
          count: n,
          systemPrompt: buildSystemPrompt(n, style, custom),
          apiKey: null // background fetches the shared key
        }, (response) => {
          clearTimeout(timer);
          if (chrome.runtime.lastError) {
            return fail('Lost the connection to the extension. Reload the page and try again.');
          }
          if (!response || !response.success) {
            return fail((response && response.message) || 'Generation failed. Please try again.');
          }
          const cleaned = cleanVariants(response.variations);
          if (!cleaned.length) return fail('The AI returned nothing usable. Try rewording your description.');
          settled = true;
          resolve(cleaned);
        });
      } catch (e) {
        clearTimeout(timer);
        fail('Lost the connection to the extension. Reload the page and try again.');
      }
    });
  }

  function clampCount(count) {
    const n = parseInt(count, 10);
    if (isNaN(n)) return DEFAULT_COUNT;
    return Math.max(2, Math.min(MAX_VARIANTS, n));
  }

  /**
   * Models leak formatting no matter how firmly you ask them not to: markdown
   * bold, "1. " prefixes, wrapping quotes. Strip those, drop blanks and
   * near-duplicates, and cap the list.
   */
  function cleanVariants(raw) {
    if (!Array.isArray(raw)) return [];
    const seen = new Set();
    const out = [];

    raw.forEach((item) => {
      if (typeof item !== 'string') return;
      let t = item
        .replace(/\*\*/g, '')
        .replace(/^\s*(?:variation|variant|option|post)\s*#?\d+\s*[:.\-—]\s*/i, '')
        .replace(/^\s*\d+[.)]\s+/, '')
        .trim();

      // A whole-string wrapping quote pair, not quotes the user actually wants.
      if (t.length > 1 && /^["'“”].*["'“”]$/s.test(t) && !/["'“”]/.test(t.slice(1, -1))) {
        t = t.slice(1, -1).trim();
      }
      if (!t) return;

      const key = t.toLowerCase().replace(/\s+/g, ' ');
      if (seen.has(key)) return;
      seen.add(key);
      out.push(t);
    });

    return out.slice(0, MAX_VARIANTS);
  }

  /** "30 groups · 12 variants" → how many times each one gets used. */
  function rotationSummary(groupCount, variantCount) {
    if (!groupCount || !variantCount) return '';
    if (variantCount >= groupCount) return `enough for all ${groupCount} groups — no repeats`;
    const min = Math.floor(groupCount / variantCount);
    const max = Math.ceil(groupCount / variantCount);
    const times = min === max ? `${min}×` : `${min}–${max}×`;
    return `each used ${times} across ${groupCount} groups`;
  }

  // ---------------------------------------------------------------------------
  // Modal
  //
  // Standalone overlay, so it follows the FB-native LIGHT idiom from the style
  // guide (white card, #1877f2 primary, #e4e6eb secondary). It layers ABOVE the
  // share modal, which stays mounted underneath — closing this one returns the
  // user exactly where they were. Height-capped with a scrolling body per the
  // v17.1 rule so 20 variants can't push the footer off a laptop screen.
  // ---------------------------------------------------------------------------

  const MODAL_ID = 'share-unlimited-ai-variants-modal';

  function ensureStyles() {
    if (document.getElementById('su-aiv-styles')) return;
    const s = document.createElement('style');
    s.id = 'su-aiv-styles';
    s.textContent = `
      @keyframes su-aiv-in { from { opacity: 0; transform: translateY(8px) scale(.985); } to { opacity: 1; transform: none; } }
      @keyframes su-aiv-fade { from { opacity: 0; } to { opacity: 1; } }
      @keyframes su-aiv-pulse { 0%,100% { opacity: 1; } 50% { opacity: .45; } }
      @keyframes su-aiv-pop { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: none; } }

      #${MODAL_ID} {
        position: fixed !important; inset: 0 !important;
        background: rgba(0,0,0,0.55) !important;
        z-index: 999999999 !important;
        display: flex !important; align-items: center !important; justify-content: center !important;
        padding: 16px !important; box-sizing: border-box !important;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif !important;
        animation: su-aiv-fade .16s ease !important;
      }
      #${MODAL_ID} * { box-sizing: border-box !important; }

      .su-aiv-card {
        background: #fff !important; border-radius: 14px !important;
        width: 100% !important; max-width: 580px !important;
        max-height: min(88vh, 780px) !important;
        display: flex !important; flex-direction: column !important; overflow: hidden !important;
        box-shadow: 0 24px 64px rgba(0,0,0,0.30), 0 2px 8px rgba(0,0,0,0.12) !important;
        animation: su-aiv-in .18s cubic-bezier(.2,.8,.3,1) !important;
      }

      .su-aiv-head {
        flex: 0 0 auto !important; display: flex !important; align-items: flex-start !important;
        justify-content: space-between !important; gap: 12px !important;
        padding: 14px 16px 12px 18px !important; border-bottom: 1px solid #e4e6eb !important;
      }
      .su-aiv-title { margin: 0 !important; color: #050505 !important; font-size: 19px !important; font-weight: 700 !important; letter-spacing: -.2px !important; }
      .su-aiv-sub { margin-top: 3px !important; color: #65676b !important; font-size: 12.5px !important; }
      .su-aiv-x {
        flex: 0 0 auto !important; width: 32px !important; height: 32px !important; border-radius: 50% !important;
        background: #f0f2f5 !important; border: none !important; color: #65676b !important;
        font-size: 15px !important; cursor: pointer !important; transition: background .15s !important;
        display: flex !important; align-items: center !important; justify-content: center !important;
      }
      .su-aiv-x:hover { background: #d8dadf !important; }

      .su-aiv-body { flex: 1 1 auto !important; overflow-y: auto !important; padding: 14px 18px !important; }
      .su-aiv-body::-webkit-scrollbar { width: 8px !important; }
      .su-aiv-body::-webkit-scrollbar-thumb { background: #ccd0d5 !important; border-radius: 4px !important; }

      .su-aiv-label { display: block !important; color: #050505 !important; font-size: 13.5px !important; font-weight: 600 !important; margin-bottom: 6px !important; }
      .su-aiv-hint { color: #65676b !important; font-size: 12px !important; font-weight: 400 !important; }

      .su-aiv-seed {
        width: 100% !important; min-height: 96px !important; resize: vertical !important;
        padding: 11px 12px !important; border: 2px solid transparent !important; border-radius: 8px !important;
        background: #f0f2f5 !important; color: #050505 !important; font-size: 14px !important;
        line-height: 1.5 !important; font-family: inherit !important; outline: none !important;
        transition: border-color .15s, background .15s !important;
      }
      .su-aiv-seed:focus { border-color: #1877f2 !important; background: #fff !important; }

      .su-aiv-controls { display: flex !important; gap: 10px !important; margin-top: 12px !important; }
      .su-aiv-ctl { flex: 1 1 0 !important; min-width: 0 !important; }
      .su-aiv-select {
        width: 100% !important; padding: 9px 10px !important; border-radius: 8px !important;
        border: 1px solid #ccd0d5 !important; background: #fff !important; color: #050505 !important;
        font-size: 13px !important; font-family: inherit !important; cursor: pointer !important; outline: none !important;
      }
      .su-aiv-select:focus { border-color: #1877f2 !important; }

      /* Live description of the selected mode. The rewrite modes get the amber
         treatment because they change the user's wording, tone and length —
         that must never be something the user discovers only in the results. */
      .su-aiv-styledesc {
        margin-top: 8px !important; padding: 8px 10px !important; border-radius: 8px !important;
        background: #f0f2f5 !important; color: #65676b !important;
        font-size: 12px !important; line-height: 1.5 !important;
      }
      .su-aiv-styledesc.su-aiv-warnstyle { background: #fff8e1 !important; color: #7a5b00 !important; }

      /* ---- custom instruction ---- */
      .su-aiv-custom[hidden] { display: none !important; }
      .su-aiv-custom { margin-top: 12px !important; padding-top: 12px !important; border-top: 1px solid #e4e6eb !important; }
      .su-aiv-custominput {
        width: 100% !important; min-height: 62px !important; resize: vertical !important;
        padding: 10px 12px !important; border: 2px solid transparent !important; border-radius: 8px !important;
        background: #f0f2f5 !important; color: #050505 !important; font-size: 13.5px !important;
        line-height: 1.5 !important; font-family: inherit !important; outline: none !important;
        transition: border-color .15s, background .15s !important;
      }
      .su-aiv-custominput:focus { border-color: #1877f2 !important; background: #fff !important; }
      .su-aiv-customfoot { display: flex !important; align-items: flex-start !important; gap: 10px !important; margin-top: 6px !important; }
      .su-aiv-customnote { flex: 1 1 auto !important; color: #65676b !important; font-size: 11.5px !important; line-height: 1.5 !important; }
      .su-aiv-chars { flex: 0 0 auto !important; color: #8a8d91 !important; font-size: 11px !important; padding-top: 1px !important; }
      .su-aiv-chips { display: flex !important; flex-wrap: wrap !important; gap: 6px !important; margin-top: 8px !important; }
      .su-aiv-chip {
        background: #e7f3ff !important; color: #1877f2 !important; border: 1px solid #cfe3ff !important;
        border-radius: 999px !important; padding: 5px 11px !important;
        font-size: 11.5px !important; font-weight: 600 !important; font-family: inherit !important;
        cursor: pointer !important; transition: background .15s !important; text-align: left !important;
      }
      .su-aiv-chip:hover { background: #d8e9ff !important; }

      .su-aiv-go {
        width: 100% !important; margin-top: 12px !important;
        background: linear-gradient(135deg, #1877f2 0%, #0a66d8 100%) !important; color: #fff !important;
        border: none !important; border-radius: 8px !important; padding: 11px 16px !important;
        font-size: 15px !important; font-weight: 700 !important; font-family: inherit !important;
        cursor: pointer !important; transition: filter .15s !important;
      }
      .su-aiv-go:hover { filter: brightness(1.07) !important; }
      .su-aiv-go[disabled] { opacity: .55 !important; cursor: not-allowed !important; filter: none !important; }
      .su-aiv-go.su-aiv-busy { animation: su-aiv-pulse 1.1s ease-in-out infinite !important; }

      .su-aiv-reuse {
        width: 100% !important; margin-top: 8px !important;
        background: #e4e6eb !important; color: #050505 !important; border: none !important;
        border-radius: 8px !important; padding: 9px 14px !important;
        font-size: 13px !important; font-weight: 600 !important; font-family: inherit !important;
        cursor: pointer !important; transition: background .15s !important;
      }
      .su-aiv-reuse:hover { background: #d8dadf !important; }

      .su-aiv-status { margin-top: 10px !important; font-size: 12.5px !important; line-height: 1.5 !important; display: none !important; }
      .su-aiv-status.su-aiv-on { display: block !important; }
      .su-aiv-status.su-aiv-err { color: #b3261e !important; background: #fdeded !important; border-radius: 8px !important; padding: 9px 11px !important; }
      .su-aiv-status.su-aiv-ok { color: #2a7d1d !important; }
      .su-aiv-status.su-aiv-load { color: #65676b !important; }

      .su-aiv-results { margin-top: 16px !important; display: none !important; }
      .su-aiv-results.su-aiv-on { display: block !important; animation: su-aiv-pop .2s ease !important; }
      .su-aiv-results-head {
        display: flex !important; align-items: center !important; gap: 8px !important;
        padding-bottom: 8px !important; border-bottom: 1px solid #e4e6eb !important; margin-bottom: 10px !important;
      }
      .su-aiv-results-title { color: #050505 !important; font-size: 13.5px !important; font-weight: 700 !important; }
      .su-aiv-rot { color: #1877f2 !important; background: #e7f3ff !important; font-size: 11px !important; font-weight: 700 !important; padding: 3px 9px !important; border-radius: 999px !important; white-space: nowrap !important; }
      .su-aiv-grow { flex: 1 1 auto !important; }
      .su-aiv-mini {
        background: #e4e6eb !important; color: #050505 !important; border: none !important;
        border-radius: 6px !important; padding: 5px 10px !important;
        font-size: 12px !important; font-weight: 600 !important; font-family: inherit !important;
        cursor: pointer !important; transition: background .15s !important; white-space: nowrap !important;
      }
      .su-aiv-mini:hover { background: #d8dadf !important; }

      .su-aiv-item {
        border: 1px solid #e4e6eb !important; border-radius: 10px !important;
        padding: 8px 10px 10px !important; margin-bottom: 8px !important; background: #fff !important;
        transition: border-color .15s, background .15s !important;
      }
      .su-aiv-item.su-aiv-off { background: #f7f8fa !important; opacity: .6 !important; }
      .su-aiv-item-head { display: flex !important; align-items: center !important; gap: 8px !important; margin-bottom: 6px !important; }
      .su-aiv-cb { width: 16px !important; height: 16px !important; accent-color: #1877f2 !important; cursor: pointer !important; flex: 0 0 auto !important; margin: 0 !important; }
      .su-aiv-item-label { color: #65676b !important; font-size: 12px !important; font-weight: 700 !important; cursor: pointer !important; }
      .su-aiv-count { color: #8a8d91 !important; font-size: 11px !important; }
      .su-aiv-text {
        width: 100% !important; min-height: 70px !important; resize: vertical !important;
        padding: 8px 10px !important; border: 1px solid #e4e6eb !important; border-radius: 8px !important;
        background: #f7f8fa !important; color: #050505 !important; font-size: 13px !important;
        line-height: 1.5 !important; font-family: inherit !important; outline: none !important;
        transition: border-color .15s, background .15s !important;
      }
      .su-aiv-text:focus { border-color: #1877f2 !important; background: #fff !important; }

      .su-aiv-foot {
        flex: 0 0 auto !important; display: flex !important; gap: 8px !important;
        padding: 12px 18px 14px !important; border-top: 1px solid #e4e6eb !important; background: #fff !important;
      }
      .su-aiv-btn {
        border: none !important; border-radius: 8px !important; padding: 11px 16px !important;
        font-size: 14.5px !important; font-weight: 700 !important; font-family: inherit !important;
        cursor: pointer !important; transition: background .15s, filter .15s !important;
      }
      .su-aiv-btn:active { transform: scale(.985) !important; }
      .su-aiv-btn-ghost { background: #e4e6eb !important; color: #050505 !important; flex: 1 1 auto !important; }
      .su-aiv-btn-ghost:hover { background: #d8dadf !important; }
      .su-aiv-btn-primary { background: #1877f2 !important; color: #fff !important; flex: 2 1 auto !important; }
      .su-aiv-btn-primary:hover { filter: brightness(1.07) !important; }
      .su-aiv-btn-primary[disabled] { opacity: .5 !important; cursor: not-allowed !important; filter: none !important; }
    `;
    document.head.appendChild(s);
  }

  /**
   * @param {object}   opts
   * @param {string}   opts.seedText   what the user already typed in the share modal
   * @param {number}   opts.groupCount how many groups this share targets (for the rotation copy)
   * @param {string[]} opts.existing   variants already applied, if they're editing
   * @param {function} opts.onApply    called with the chosen string[]
   */
  function showAiVariantsModal(opts) {
    const { seedText = '', groupCount = 0, existing = null, onApply } = opts || {};

    const old = document.getElementById(MODAL_ID);
    if (old) old.remove();
    ensureStyles();

    const modal = document.createElement('div');
    modal.id = MODAL_ID;

    const card = document.createElement('div');
    card.className = 'su-aiv-card';
    card.setAttribute('role', 'dialog');
    card.setAttribute('aria-modal', 'true');
    card.setAttribute('aria-label', 'Generate AI post variants');

    card.innerHTML = `
      <div class="su-aiv-head">
        <div>
          <h2 class="su-aiv-title">✨ AI Post Variants</h2>
          <div class="su-aiv-sub">Your post, worded a little differently for each group — so no two groups get identical text.</div>
        </div>
        <button id="su-aiv-close" class="su-aiv-x" aria-label="Close">✕</button>
      </div>

      <div class="su-aiv-body">
        <label class="su-aiv-label" for="su-aiv-seed">
          Your post
          <span class="su-aiv-hint"></span>
        </label>
        <textarea id="su-aiv-seed" class="su-aiv-seed"
          placeholder="Paste or type your post exactly as you want it. e.g. Selling a 2019 Corolla, 78k km, one owner, $11,500. Pickup in Haifa this weekend — WhatsApp 054-000-0000."></textarea>

        <div class="su-aiv-controls">
          <div class="su-aiv-ctl">
            <label class="su-aiv-label" for="su-aiv-count">How many</label>
            <select id="su-aiv-count" class="su-aiv-select"></select>
          </div>
          <div class="su-aiv-ctl">
            <label class="su-aiv-label" for="su-aiv-style">How much to change</label>
            <select id="su-aiv-style" class="su-aiv-select"></select>
          </div>
        </div>
        <div class="su-aiv-styledesc" id="su-aiv-styledesc"></div>

        <!-- Custom instruction. Hidden unless the Custom style is picked. The
             explainer tells the user what they DON'T have to write, because the
             system prompt already states the task and the no-invention rules. -->
        <div class="su-aiv-custom" id="su-aiv-customwrap" hidden>
          <label class="su-aiv-label" for="su-aiv-custom">Your instruction to the AI</label>
          <textarea id="su-aiv-custom" class="su-aiv-custominput" maxlength="600"
            placeholder="e.g. Keep it almost the same, just make it sound a bit warmer."></textarea>
          <div class="su-aiv-customfoot">
            <span class="su-aiv-customnote">The AI already knows it's making versions of your post for different groups, and it's already told never to invent facts, contact details or a "DM me" line. Just say how you want it changed.</span>
            <span class="su-aiv-chars" id="su-aiv-customchars"></span>
          </div>
          <div class="su-aiv-chips" id="su-aiv-chips"></div>
        </div>

        <button id="su-aiv-go" class="su-aiv-go">✨ Generate variants</button>
        <button id="su-aiv-reuse" class="su-aiv-reuse" style="display:none;"></button>
        <div id="su-aiv-status" class="su-aiv-status"></div>

        <div id="su-aiv-results" class="su-aiv-results">
          <div class="su-aiv-results-head">
            <span class="su-aiv-results-title" id="su-aiv-results-title">Variants</span>
            <span class="su-aiv-rot" id="su-aiv-rot"></span>
            <span class="su-aiv-grow"></span>
            <button id="su-aiv-toggle-all" class="su-aiv-mini">Unselect all</button>
          </div>
          <div id="su-aiv-list"></div>
        </div>
      </div>

      <div class="su-aiv-foot">
        <button id="su-aiv-cancel" class="su-aiv-btn su-aiv-btn-ghost">Cancel</button>
        <button id="su-aiv-apply" class="su-aiv-btn su-aiv-btn-primary" disabled>Use variants</button>
      </div>
    `;

    modal.appendChild(card);
    document.body.appendChild(modal);

    const seedEl    = card.querySelector('#su-aiv-seed');
    const countEl   = card.querySelector('#su-aiv-count');
    const styleEl   = card.querySelector('#su-aiv-style');
    const goBtn     = card.querySelector('#su-aiv-go');
    const reuseBtn  = card.querySelector('#su-aiv-reuse');
    const statusEl  = card.querySelector('#su-aiv-status');
    const resultsEl = card.querySelector('#su-aiv-results');
    const listEl    = card.querySelector('#su-aiv-list');
    const rotEl     = card.querySelector('#su-aiv-rot');
    const titleEl   = card.querySelector('#su-aiv-results-title');
    const toggleAll = card.querySelector('#su-aiv-toggle-all');
    const applyBtn  = card.querySelector('#su-aiv-apply');
    const cancelBtn = card.querySelector('#su-aiv-cancel');
    const closeBtn  = card.querySelector('#su-aiv-close');

    // The hint carries the live count, so it can't be baked into the template.
    const hintEl = card.querySelector('.su-aiv-hint');

    const styleDescEl   = card.querySelector('#su-aiv-styledesc');
    const customWrap    = card.querySelector('#su-aiv-customwrap');
    const customEl      = card.querySelector('#su-aiv-custom');
    const customCharsEl = card.querySelector('#su-aiv-customchars');
    const chipsEl       = card.querySelector('#su-aiv-chips');

    COUNT_OPTIONS.forEach((n) => {
      const o = document.createElement('option');
      o.value = String(n);
      o.textContent = `${n} variants`;
      countEl.appendChild(o);
    });

    // Grouped so "keep my post" and "rewrite it" can never be confused for each
    // other in a flat list — picking a rewrite has to be a deliberate act.
    const groups = [];
    Object.keys(STYLES).forEach((key) => {
      const g = STYLES[key].group;
      let bucket = groups.find((x) => x.name === g);
      if (!bucket) { bucket = { name: g, keys: [] }; groups.push(bucket); }
      bucket.keys.push(key);
    });
    groups.forEach((bucket) => {
      const og = document.createElement('optgroup');
      og.label = bucket.name;
      bucket.keys.forEach((key) => {
        const o = document.createElement('option');
        o.value = key;
        o.textContent = STYLES[key].label;
        og.appendChild(o);
      });
      styleEl.appendChild(og);
    });

    countEl.value = String(DEFAULT_COUNT);
    styleEl.value = DEFAULT_STYLE;

    seedEl.value = seedText || '';

    const currentStyle = () => STYLES[styleEl.value] || STYLES[DEFAULT_STYLE];

    const HINT_BY_MODE = {
      rewrite:  (n) => `— rewritten ${n} different ways`,
      preserve: (n) => `— reworded ${n} ways, same message and length`,
      custom:   (n) => `— ${n} versions, changed the way you describe below`
    };

    const syncHint = () => {
      const s = currentStyle();
      hintEl.textContent = (HINT_BY_MODE[s.mode] || HINT_BY_MODE.preserve)(countEl.value);
      styleDescEl.textContent = s.hint || '';
      styleDescEl.classList.toggle('su-aiv-warnstyle', s.mode === 'rewrite');
      customWrap.hidden = s.mode !== 'custom';
      if (s.mode === 'custom') setTimeout(() => customEl.focus(), 30);
    };

    // One-tap starting points. They fill the box rather than firing generation,
    // so the instruction stays the user's to edit.
    const CUSTOM_EXAMPLES = [
      'Keep it almost identical, just change a few words.',
      "I'm posting this for someone else — keep it that way, never sound like it's mine.",
      'Make it a little warmer and friendlier, same length.',
      'Slightly shorter and easier to skim.',
      'Add a short friendly greeting at the start.',
      'Keep it strictly factual, no selling language.'
    ];
    CUSTOM_EXAMPLES.forEach((text) => {
      const chip = document.createElement('button');
      chip.type = 'button';
      chip.className = 'su-aiv-chip';
      chip.textContent = text;
      chip.addEventListener('click', () => {
        customEl.value = text;
        syncCustomChars();
        customEl.focus();
      });
      chipsEl.appendChild(chip);
    });

    function syncCustomChars() {
      const n = customEl.value.length;
      customCharsEl.textContent = n ? `${n}/${MAX_CUSTOM_CHARS}` : '';
    }
    customEl.addEventListener('input', syncCustomChars);
    syncCustomChars();

    syncHint();
    countEl.addEventListener('change', syncHint);
    styleEl.addEventListener('change', syncHint);

    const close = () => {
      document.removeEventListener('keydown', onKeyDown, true);
      modal.remove();
    };
    const onKeyDown = (e) => {
      if (e.key !== 'Escape') return;
      if (!modal.isConnected) { document.removeEventListener('keydown', onKeyDown, true); return; }
      e.stopPropagation();
      close();
    };
    document.addEventListener('keydown', onKeyDown, true);

    closeBtn.addEventListener('click', close);
    cancelBtn.addEventListener('click', close);
    modal.addEventListener('click', (e) => { if (e.target === modal) close(); });

    const setStatus = (msg, kind) => {
      statusEl.textContent = msg || '';
      statusEl.className = `su-aiv-status${msg ? ` su-aiv-on su-aiv-${kind}` : ''}`;
    };

    // -- results rendering ----------------------------------------------------

    function renderResults(variants) {
      listEl.innerHTML = '';
      variants.forEach((text, i) => {
        const item = document.createElement('div');
        item.className = 'su-aiv-item';

        const head = document.createElement('div');
        head.className = 'su-aiv-item-head';

        const cb = document.createElement('input');
        cb.type = 'checkbox';
        cb.className = 'su-aiv-cb';
        cb.checked = true;
        cb.id = `su-aiv-cb-${i}`;

        const label = document.createElement('label');
        label.className = 'su-aiv-item-label';
        label.htmlFor = cb.id;
        label.textContent = `Variant ${i + 1}`;

        const chars = document.createElement('span');
        chars.className = 'su-aiv-count';

        const ta = document.createElement('textarea');
        ta.className = 'su-aiv-text';
        // .value, never innerHTML: generated text can contain <, &, quotes and
        // RTL control marks, same rule as group names elsewhere in this codebase.
        ta.value = text;

        const syncChars = () => { chars.textContent = `${ta.value.trim().length} chars`; };
        syncChars();
        ta.addEventListener('input', () => { syncChars(); refreshApply(); });

        cb.addEventListener('change', () => {
          item.classList.toggle('su-aiv-off', !cb.checked);
          refreshApply();
        });

        head.appendChild(cb);
        head.appendChild(label);
        head.appendChild(chars);
        item.appendChild(head);
        item.appendChild(ta);
        listEl.appendChild(item);
      });

      resultsEl.classList.add('su-aiv-on');
      toggleAll.textContent = 'Unselect all';
      refreshApply();
    }

    function collectSelected() {
      const out = [];
      listEl.querySelectorAll('.su-aiv-item').forEach((item) => {
        const cb = item.querySelector('input[type="checkbox"]');
        const ta = item.querySelector('textarea');
        const t = ta.value.trim();
        if (cb.checked && t) out.push(t);
      });
      return out;
    }

    function refreshApply() {
      const n = collectSelected().length;
      applyBtn.disabled = n === 0;
      applyBtn.textContent = n ? `Use ${n} variant${n === 1 ? '' : 's'}` : 'Use variants';
      titleEl.textContent = `${n} selected`;
      rotEl.textContent = rotationSummary(groupCount, n);
      rotEl.style.display = rotEl.textContent ? '' : 'none';
    }

    toggleAll.addEventListener('click', () => {
      const boxes = Array.from(listEl.querySelectorAll('input[type="checkbox"]'));
      const anyChecked = boxes.some((b) => b.checked);
      boxes.forEach((b) => {
        b.checked = !anyChecked;
        b.closest('.su-aiv-item').classList.toggle('su-aiv-off', !b.checked);
      });
      toggleAll.textContent = anyChecked ? 'Select all' : 'Unselect all';
      refreshApply();
    });

    // -- generate -------------------------------------------------------------

    let busy = false;
    goBtn.addEventListener('click', async () => {
      if (busy) return;
      const seed = seedEl.value.trim();
      if (!seed) {
        setStatus('Paste or type your post first.', 'err');
        seedEl.focus();
        return;
      }
      const custom = customEl.value.trim();
      if (currentStyle().mode === 'custom' && !custom) {
        setStatus('Tell the AI how you want your post changed — or pick one of the ready-made options above.', 'err');
        customEl.focus();
        return;
      }

      busy = true;
      goBtn.disabled = true;
      goBtn.classList.add('su-aiv-busy');
      goBtn.textContent = `Writing ${countEl.value} variants…`;
      reuseBtn.style.display = 'none';
      setStatus('This usually takes 5–15 seconds.', 'load');

      try {
        const variants = await generateVariants({ seed, count: countEl.value, style: styleEl.value, custom });
        renderResults(variants);
        setStatus(
          variants.length < parseInt(countEl.value, 10)
            ? `Generated ${variants.length} usable variants (exact duplicates were dropped). Edit anything you like, then apply.`
            : `${variants.length} variants ready. Edit anything you like, then apply.`,
          'ok'
        );
        rememberSet(seed, styleEl.value, custom, variants);
        resultsEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      } catch (e) {
        setStatus(e.message || 'Generation failed. Please try again.', 'err');
      } finally {
        busy = false;
        goBtn.disabled = false;
        goBtn.classList.remove('su-aiv-busy');
        goBtn.textContent = listEl.children.length ? '✨ Regenerate' : '✨ Generate variants';
      }
    });

    applyBtn.addEventListener('click', () => {
      const chosen = collectSelected();
      if (!chosen.length) return;
      rememberSet(seedEl.value.trim(), styleEl.value, customEl.value.trim(), chosen);
      close();
      if (typeof onApply === 'function') onApply(chosen);
    });

    // -- prefill --------------------------------------------------------------
    // Editing an applied set: show it immediately, no regeneration needed.
    if (Array.isArray(existing) && existing.length) {
      renderResults(existing.slice(0, MAX_VARIANTS));
      goBtn.textContent = '✨ Regenerate';
      setStatus('Editing your current variants. Regenerate for a fresh set, or just tweak these.', 'ok');
    }

    loadLastSet((last) => {
      if (!last) return;
      // Always restore the seed when the box is empty — otherwise "Edit variants →
      // Regenerate" would demand the user retype the blurb they already described.
      if (!seedEl.value.trim() && last.seed) seedEl.value = last.seed;
      if (typeof last.custom === 'string' && !customEl.value.trim()) { customEl.value = last.custom; syncCustomChars(); }
      if (last.style && STYLES[last.style]) { styleEl.value = last.style; syncHint(); }
      // The reuse button only makes sense when nothing is on screen yet.
      if (!last.variants || !last.variants.length) return;
      if (listEl.children.length) return;
      reuseBtn.textContent = `↩ Reuse last ${last.variants.length} variants`;
      reuseBtn.style.display = '';
      reuseBtn.addEventListener('click', () => {
        renderResults(last.variants.slice(0, MAX_VARIANTS));
        reuseBtn.style.display = 'none';
        goBtn.textContent = '✨ Regenerate';
        setStatus('Loaded your last set. Edit anything you like, then apply.', 'ok');
      });
    });

    setTimeout(() => seedEl.focus(), 40);
  }

  // ---------------------------------------------------------------------------
  // Last-set memory. Best-effort only — every failure is swallowed, because
  // nothing here may block generating or applying variants.
  // ---------------------------------------------------------------------------
  function rememberSet(seed, style, custom, variants) {
    try {
      chrome.storage.local.set({
        aiVariantSet: {
          seed: seed || '',
          style: style || DEFAULT_STYLE,
          custom: (custom || '').slice(0, MAX_CUSTOM_CHARS),
          variants: variants.slice(0, MAX_VARIANTS),
          savedAt: Date.now()
        }
      }, () => void chrome.runtime.lastError);
    } catch (_) { /* context invalidated — not worth surfacing */ }
  }

  function loadLastSet(cb) {
    try {
      chrome.storage.local.get(['aiVariantSet'], (res) => {
        if (chrome.runtime.lastError) return cb(null);
        cb((res && res.aiVariantSet) || null);
      });
    } catch (_) { cb(null); }
  }

  window.ShareUnlimited.AIVariants = {
    MAX_VARIANTS,
    showAiVariantsModal,
    generateVariants,
    rotationSummary
  };

  console.log('✨ ShareUnlimited AI variants module loaded');
})();
