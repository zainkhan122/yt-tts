<?php
if (! defined('ABSPATH')) {
	exit;
}

/**
 * Notification System for MCQ Plugin
 * Email notifications, in-app notifications, push notifications
 *
 * @package WP_News_MCQ_Generator
 * @version 1.0
 */

class NM_Notifications
{


	private static $instance = null;

	public static function init()
	{
		if (self::$instance === null) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct()
	{
		// AJAX handlers
		add_action('wp_ajax_nm_get_notifications', array($this, 'get_notifications'));
		add_action('wp_ajax_nm_mark_notification_read', array($this, 'mark_notification_read'));
		add_action('wp_ajax_nm_mark_all_read', array($this, 'mark_all_read'));
		add_action('wp_ajax_nm_delete_notification', array($this, 'delete_notification'));

		// Notification triggers
		add_action('nm_points_awarded', array($this, 'notify_points_earned'), 10, 3);
		add_action('nm_achievement_unlocked', array($this, 'notify_achievement'), 10, 2);
		add_action('nm_level_up', array($this, 'notify_level_up'), 10, 2);
		add_action('nm_streak_milestone', array($this, 'notify_streak'), 10, 2);
		add_action('nm_leaderboard_position', array($this, 'notify_leaderboard_change'), 10, 3);

		// Enqueue notification scripts
		add_action('wp_enqueue_scripts', array($this, 'enqueue_notification_scripts'));

		// @MODIFIED: Render notification bell for all users
		add_action('wp_footer', array($this, 'render_notification_bell'));

		// ✅ NEW v7.3.4: Daily digest cron hook
		add_action('nm_send_daily_digest', array(__CLASS__, 'send_daily_digest'));
	}

	/**
	 * Enqueue notification scripts
	 *
	 * @MODIFIED: Now enqueues for ALL users (not just logged-in)
	 */
	public function enqueue_notification_scripts()
	{
		// @MODIFIED: Enqueue for all users if notifications are enabled
		if (! get_option('nm_notifications_enabled', 1)) {
			return;
		}

		// ✅ v7.3.4: Enqueue notification CSS
		wp_enqueue_style(
			'nm-notifications-css',
			NM_PLUGIN_URL . 'assets/css/notifications.css',
			array(),
			filemtime(NM_PLUGIN_PATH . 'assets/css/notifications.css')
		);

		// ✅ v7.3.4: Enqueue notification JavaScript
		wp_enqueue_script(
			'nm-notifications',
			NM_PLUGIN_URL . 'assets/js/notifications.js',
			array('jquery'),
			filemtime(NM_PLUGIN_PATH . 'assets/js/notifications.js'),
			true
		);

		wp_localize_script(
			'nm-notifications',
			'nmNotifications',
			array(
				'ajaxurl'       => admin_url('admin-ajax.php'),
				'nonce'         => wp_create_nonce('nm_auth_nonce'),
				'isLoggedIn'    => is_user_logged_in(),
				// ✅ v7.3.6: Use configurable check interval from settings
				'checkInterval' => get_option('nm_notification_check_interval', 30000),
			)
		);
	}

	/**
	 * Create notification
	 */
	public static function create($user_id, $type, $title, $message, $data = array())
	{
		global $wpdb;
		$table = $wpdb->prefix . 'nm_notifications';

		$inserted = $wpdb->insert(
			$table,
			array(
				'user_id'    => $user_id,
				'type'       => $type,
				'title'      => $title,
				'message'    => $message,
				'data'       => json_encode($data),
				'is_read'    => 0,
				'created_at' => current_time('mysql'),
			),
			array('%d', '%s', '%s', '%s', '%s', '%d', '%s')
		);

		if ($inserted) {
			// Send email if enabled
			if (get_option('nm_email_notifications_' . $type, 1)) {
				self::send_email_notification($user_id, $title, $message);
			}

			// Send push notification if enabled
			if (get_option('nm_push_notifications', 0)) {
				self::send_push_notification($user_id, $title, $message);
			}
		}

		return $inserted;
	}

	/**
	 * Get user notifications
	 */
	public function get_notifications()
	{
		check_ajax_referer('nm_auth_nonce', 'nonce');

		if (! is_user_logged_in()) {
			wp_send_json_error(array('message' => 'Please login first.'));
		}

		$user_id     = get_current_user_id();
		$limit       = min(50, (int) ($_POST['limit'] ?? 20));
		$offset      = (int) ($_POST['offset'] ?? 0);
		$unread_only = rest_sanitize_boolean($_POST['unread_only'] ?? false);

		global $wpdb;
		$table = $wpdb->prefix . 'nm_notifications';

		$where  = 'user_id = %d';
		$params = array($user_id);

		if ($unread_only) {
			$where .= ' AND is_read = 0';
		}

		$query    = "SELECT * FROM {$table} WHERE {$where} ORDER BY created_at DESC LIMIT %d OFFSET %d";
		$params[] = $limit;
		$params[] = $offset;

		$notifications = $wpdb->get_results($wpdb->prepare($query, $params));

		// Get unread count
		$unread_count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND is_read = 0",
				$user_id
			)
		);

		// Format notifications
		$formatted = array_map(
			function ($notification) {
				$notification->data     = json_decode($notification->data, true);
				$notification->time_ago = $this->time_ago($notification->created_at);
				return $notification;
			},
			$notifications
		);

		wp_send_json_success(
			array(
				'notifications' => $formatted,
				'unread_count'  => (int) $unread_count,
			)
		);
	}

	/**
	 * Mark notification as read
	 */
	public function mark_notification_read()
	{
		check_ajax_referer('nm_auth_nonce', 'nonce');

		if (! is_user_logged_in()) {
			wp_send_json_error(array('message' => 'Please login first.'));
		}

		$user_id         = get_current_user_id();
		$notification_id = (int) ($_POST['notification_id'] ?? 0);

		global $wpdb;
		$table = $wpdb->prefix . 'nm_notifications';

		$updated = $wpdb->update(
			$table,
			array('is_read' => 1),
			array(
				'id'      => $notification_id,
				'user_id' => $user_id,
			),
			array('%d'),
			array('%d', '%d')
		);

		if ($updated !== false) {
			wp_send_json_success(array('message' => 'Notification marked as read.'));
		} else {
			wp_send_json_error(array('message' => 'Failed to mark notification.'));
		}
	}

	/**
	 * Mark all notifications as read
	 */
	public function mark_all_read()
	{
		check_ajax_referer('nm_auth_nonce', 'nonce');

		if (! is_user_logged_in()) {
			wp_send_json_error(array('message' => 'Please login first.'));
		}

		$user_id = get_current_user_id();

		global $wpdb;
		$table = $wpdb->prefix . 'nm_notifications';

		$wpdb->update(
			$table,
			array('is_read' => 1),
			array('user_id' => $user_id),
			array('%d'),
			array('%d')
		);

		wp_send_json_success(array('message' => 'All notifications marked as read.'));
	}

	/**
	 * Delete notification
	 */
	public function delete_notification()
	{
		check_ajax_referer('nm_auth_nonce', 'nonce');

		if (! is_user_logged_in()) {
			wp_send_json_error(array('message' => 'Please login first.'));
		}

		$user_id         = get_current_user_id();
		$notification_id = (int) ($_POST['notification_id'] ?? 0);

		global $wpdb;
		$table = $wpdb->prefix . 'nm_notifications';

		$deleted = $wpdb->delete(
			$table,
			array(
				'id'      => $notification_id,
				'user_id' => $user_id,
			),
			array('%d', '%d')
		);

		if ($deleted) {
			wp_send_json_success(array('message' => 'Notification deleted.'));
		} else {
			wp_send_json_error(array('message' => 'Failed to delete notification.'));
		}
	}

	/**
	 * Notify points earned
	 */
	public function notify_points_earned($user_id, $points, $reason)
	{
		if ($points <= 0) {
			return;
		}

		$title   = '🎯 Points Earned!';
		$message = "You earned {$points} points for {$reason}!";

		self::create(
			$user_id,
			'points',
			$title,
			$message,
			array(
				'points' => $points,
				'reason' => $reason,
			)
		);
	}

	/**
	 * Notify achievement unlock
	 */
	public function notify_achievement($user_id, $achievement_key)
	{
		$achievements = NM_Gamification::get_achievement_definitions();
		$achievement  = $achievements[$achievement_key] ?? null;

		if (! $achievement) {
			return;
		}

		$title   = '🏆 Achievement Unlocked!';
		$message = "You've unlocked: {$achievement['name']}";

		self::create(
			$user_id,
			'achievement',
			$title,
			$message,
			array(
				'achievement_key'  => $achievement_key,
				'achievement_name' => $achievement['name'],
				'points'           => $achievement['points'],
			)
		);
	}

	/**
	 * Notify level up
	 */
	public function notify_level_up($user_id, $new_level)
	{
		$title   = '⭐ Level Up!';
		$message = "Congratulations! You've reached Level {$new_level}!";

		self::create(
			$user_id,
			'level_up',
			$title,
			$message,
			array(
				'level' => $new_level,
			)
		);
	}

	/**
	 * Notify streak milestone
	 */
	public function notify_streak($user_id, $streak_days)
	{
		$title   = '🔥 Streak Milestone!';
		$message = "Amazing! You've maintained a {$streak_days}-day streak!";

		self::create(
			$user_id,
			'streak',
			$title,
			$message,
			array(
				'streak_days' => $streak_days,
			)
		);
	}

	/**
	 * Notify leaderboard position change
	 */
	public function notify_leaderboard_change($user_id, $old_rank, $new_rank)
	{
		if ($new_rank >= $old_rank) {
			return; // Only notify improvements
		}

		$title   = '📊 Leaderboard Update!';
		$message = "You've climbed to rank #{$new_rank} on the leaderboard!";

		self::create(
			$user_id,
			'leaderboard',
			$title,
			$message,
			array(
				'old_rank' => $old_rank,
				'new_rank' => $new_rank,
			)
		);
	}

	/**
	 * Send email notification
	 *
	 * @MODIFIED v7.3.15: Added robust HTML detection and proper email headers
	 */
	private static function send_email_notification($user_id, $title, $message)
	{
		$user = get_userdata($user_id);

		$subject = strip_tags($title) . ' - ' . get_bloginfo('name');

		// @MODIFIED v7.3.15: Professional HTML detection with multiple checks
		// Detect HTML by checking for actual HTML tags (not just < or >)
		$is_html = preg_match('/<[a-z][\s\S]*>/i', $message) && ($message != strip_tags($message));

		if ($is_html) {
			$headers       = array('Content-Type: text/html; charset=UTF-8');
			$email_message = $message;
		} else {
			$headers        = array('Content-Type: text/plain; charset=UTF-8');
			$email_message  = "Hi {$user->display_name},\n\n";
			$email_message .= strip_tags($message) . "\n\n";
			$email_message .= 'View your dashboard: ' . home_url('/mcq-dashboard/') . "\n\n";
			$email_message .= "Best regards,\n";
			$email_message .= get_bloginfo('name');
		}

		wp_mail($user->user_email, $subject, $email_message, $headers);
	}

	/**
	 * Send push notification
	 */
	private static function send_push_notification($user_id, $title, $message)
	{
		// This would integrate with Web Push API
		// Requires subscription management and VAPID keys
		// Implementation depends on your push notification service

		// Placeholder for push notification logic
		do_action('nm_send_push_notification', $user_id, $title, $message);
	}

	/**
	 * Time ago helper
	 */
	private function time_ago($datetime)
	{
		$timestamp = strtotime($datetime);
		$diff      = time() - $timestamp;

		if ($diff < 60) {
			return 'Just now';
		} elseif ($diff < 3600) {
			$minutes = floor($diff / 60);
			return $minutes . ' minute' . ($minutes > 1 ? 's' : '') . ' ago';
		} elseif ($diff < 86400) {
			$hours = floor($diff / 3600);
			return $hours . ' hour' . ($hours > 1 ? 's' : '') . ' ago';
		} elseif ($diff < 604800) {
			$days = floor($diff / 86400);
			return $days . ' day' . ($days > 1 ? 's' : '') . ' ago';
		} else {
			return date('M j, Y', $timestamp);
		}
	}

	/**
	 * ✅ NEW v7.3.4: Send daily digest at 8 AM
	 * Triggered by wp-cron: nm_send_daily_digest
	 * Batches MCQ uploads into single notification (non-intrusive)
	 */
	public static function send_daily_digest()
	{
		global $wpdb;

		// Get yesterday's date for counting new MCQs
		$yesterday = date('Y-m-d H:i:s', strtotime('-24 hours'));

		// Count new MCQs published in last 24 hours
		$new_mcq_count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->posts} 
             WHERE post_type = 'mcq' 
             AND post_status = 'publish' 
             AND post_date >= %s",
				$yesterday
			)
		);

		if ($new_mcq_count == 0) {
			return; // No MCQs, no digest
		}

		// Get all active users (logged in within last 30 days)
		$active_users = $wpdb->get_col(
			"
            SELECT DISTINCT user_id 
            FROM {$wpdb->usermeta} 
            WHERE meta_key = 'nm_last_login' 
            AND meta_value >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        "
		);

		if (empty($active_users)) {
			return;
		}

		// Prepare Digest Content
		$site_name = get_bloginfo('name');

		$latest_mcqs = get_posts(
			array(
				'post_type'      => 'mcq',
				'posts_per_page' => 10,
				'post_status'    => 'publish',
				'date_query'     => array(array('after' => '24 hours ago')),
			)
		);

		$scheduled_mcqs = get_posts(
			array(
				'post_type'      => 'mcq',
				'post_status'    => 'future',
				'posts_per_page' => 5,
			)
		);

		$total_mcqs = wp_count_posts('mcq')->publish;

		ob_start();
?>
		<!DOCTYPE html>
		<html>

		<head>
			<style>
				body {
					font-family: Arial, sans-serif;
					line-height: 1.6;
					color: #333;
				}

				.container {
					max-width: 600px;
					margin: 0 auto;
				}

				.header {
					background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
					color: white;
					padding: 30px;
					text-align: center;
					border-radius: 8px 8px 0 0;
				}

				.content {
					background: #fff;
					padding: 30px;
					border: 1px solid #e0e0e0;
				}

				.stats-box {
					background: #f8f9fa;
					padding: 20px;
					border-radius: 8px;
					margin: 20px 0;
				}

				.mcq-item {
					margin-bottom: 20px;
					padding: 15px;
					background: #f8f9fa;
					border-left: 4px solid #667eea;
					border-radius: 4px;
				}

				.btn {
					display: inline-block;
					padding: 12px 30px;
					background: #667eea;
					color: white;
					text-decoration: none;
					border-radius: 5px;
					margin: 20px 0;
				}

				.footer {
					background: #f8f9fa;
					padding: 20px;
					text-align: center;
					font-size: 12px;
					color: #888;
					border-radius: 0 0 8px 8px;
				}
			</style>
		</head>

		<body>
			<div class="container">
				<div class="header">
					<h1 style="margin: 0;">📚 Daily MCQ Digest</h1>
					<p><?php echo $site_name; ?></p>
				</div>
				<div class="content">
					<h2>Today's Highlights</h2>
					<div class="stats-box">
						<p><strong>📊 Total Questions:</strong> <?php echo number_format($total_mcqs); ?></p>
						<p><strong>🆕 New Today:</strong> <?php echo count($latest_mcqs); ?></p>
						<?php if (! empty($scheduled_mcqs)) : ?>
							<p><strong>📅 Coming Soon:</strong> <?php echo count($scheduled_mcqs); ?> scheduled</p>
						<?php endif; ?>
					</div>
					<?php if (! empty($latest_mcqs)) : ?>
						<h3>🆕 Latest Questions</h3>
						<?php foreach (array_slice($latest_mcqs, 0, 5) as $mcq) : ?>
							<div class="mcq-item">
								<h4 style="margin: 0 0 10px 0; color: #333;"><?php echo esc_html($mcq->post_title); ?></h4>
								<a href="<?php echo get_permalink($mcq->ID); ?>" style="color: #667eea; text-decoration: none; font-weight: bold;">Take Quiz →</a>
							</div>
						<?php endforeach; ?>
					<?php endif; ?>
					<center>
						<a href="<?php echo home_url('/mcq/'); ?>" class="btn">Browse All Questions</a>
					</center>
				</div>
				<div class="footer">
					<p>You're receiving this because you are an active user on <?php echo $site_name; ?>.</p>
					<!-- @MODIFIED v7.3.15: Changed from dashboard link to homepage to prevent 404 for non-logged-in users -->
					<p>Visit our <a href="<?php echo home_url(); ?>">Homepage</a> for more.</p>
				</div>
			</div>
		</body>

		</html>
		<?php
		$digest_html = ob_get_clean();

		$sent_count = 0;

		// Send digest notification to each active user
		foreach ($active_users as $user_id) {
			// Skip if user disabled daily digest
			$digest_enabled = get_user_meta($user_id, 'nm_enable_daily_digest', true);
			if ($digest_enabled === '0' || $digest_enabled === false) {
				continue;
			}

			$title = '📰 Daily MCQ Digest';
			// For in-app notification, keep it simple
			$message = "{$new_mcq_count} new MCQ" . ($new_mcq_count > 1 ? 's' : '') . ' published in the last 24 hours!';

			// @MODIFIED v7.3.15: Manual DB insert to prevent double email via self::create() triggering email again
			$insert_result = $wpdb->insert(
				$wpdb->prefix . 'nm_notifications',
				array(
					'user_id'    => $user_id,
					'type'       => 'daily_digest',
					'title'      => $title,
					'message'    => $message,
					'data'       => json_encode(
						array(
							'mcq_count'   => $new_mcq_count,
							'date'        => date('Y-m-d'),
							'digest_type' => 'daily',
						)
					),
					'is_read'    => 0,
					'created_at' => current_time('mysql'),
				),
				array('%d', '%s', '%s', '%s', '%s', '%d', '%s')
			);

			// @MODIFIED v7.3.15: Added error checking for DB insert
			if ($insert_result === false) {
				continue; // Skip this user and continue with next
			}

			// Send the rich HTML email
			if (get_option('nm_email_notifications_daily_digest', 1)) {
				self::send_email_notification($user_id, $title, $digest_html);
			}

			++$sent_count;
		}
	}

	/**
	 * Cleanup old notifications (cron job)
	 */
	public static function cleanup_old_notifications()
	{
		global $wpdb;
		$table = $wpdb->prefix . 'nm_notifications';

		// Delete read notifications older than 30 days
		$wpdb->query(
			"
            DELETE FROM {$table}
            WHERE is_read = 1
            AND created_at < DATE_SUB(NOW(), INTERVAL 30 DAY)
        "
		);

		// Delete all notifications older than 90 days
		$wpdb->query(
			"
            DELETE FROM {$table}
            WHERE created_at < DATE_SUB(NOW(), INTERVAL 90 DAY)
        "
		);
	}

	/**
	 * Create database table
	 */
	public static function create_tables()
	{
		global $wpdb;
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}nm_notifications (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id bigint(20) UNSIGNED NOT NULL,
            type varchar(50) NOT NULL,
            title varchar(255) NOT NULL,
            message text NOT NULL,
            data text,
            is_read tinyint(1) NOT NULL DEFAULT 0,
            created_at datetime NOT NULL,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY is_read (is_read),
            KEY created_at (created_at)
        ) $charset_collate;";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta($sql);
	}

	/**
	 * @MODIFIED: Render notification bell icon for all users
	 * Logged-in users see notifications dropdown
	 * Visitors see email subscription form
	 */
	public function render_notification_bell()
	{
		if (! get_option('nm_notifications_enabled', 1)) {
			return;
		}

		$is_logged_in = is_user_logged_in();
		?>
		<div id="nm-notification-wrapper">
			<div class="nm-notification-bell" id="nm-notification-bell" role="button" aria-label="Notifications" tabindex="0">
				<span class="nm-bell-icon">🔔</span>
				<span class="nm-notification-badge" id="nm-notification-badge"></span>
			</div>

			<?php if ($is_logged_in) : ?>
				<!-- Notification dropdown for logged-in users -->
				<div class="nm-notification-dropdown" id="nm-notification-dropdown">
					<div class="nm-notification-header">
						<h3>Notifications</h3>
						<button id="nm-mark-all-read">Mark all read</button>
					</div>
					<div class="nm-notification-list" id="nm-notification-list">
						<div class="nm-notification-loading">Loading notifications</div>
					</div>
					<div class="nm-notification-footer">
						<a href="<?php echo home_url('/mcq-dashboard/'); ?>">View All</a>
					</div>
				</div>
			<?php else : ?>
				<!-- Email subscription form for visitors -->
				<div class="nm-notification-dropdown" id="nm-notification-dropdown">
					<div class="nm-notification-header">
						<h3>📧 Stay Updated</h3>
					</div>
					<div class="nm-subscription-content">
						<p>Subscribe to get daily MCQ updates delivered to your inbox!</p>
						<form id="nm-bell-subscribe-form">
							<input type="email" name="email" placeholder="Your email address" required>
							<input type="text" name="name" placeholder="Your name (optional)">
							<button type="submit" class="nm-subscribe-btn">
								Subscribe Now
							</button>
						</form>
						<div class="nm-subscribe-message"></div>
						<p>✅ No spam. Unsubscribe anytime.</p>
					</div>
					<div class="nm-notification-footer">
						<a href="<?php echo wp_login_url(); ?>">Login to view notifications</a>
					</div>
				</div>
			<?php endif; ?>
		</div>
<?php
	}
}
