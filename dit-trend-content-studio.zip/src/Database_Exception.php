<?php

/**
 * Database Exception
 *
 * @package DIT_TrendStudio
 * @MODIFIED 2025-12-13 - Extracted from class-error-handler.php for autoloader compatibility
 */

namespace DIT\TrendStudio;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Custom exception for database errors
 */
class Database_Exception extends \Exception {}
