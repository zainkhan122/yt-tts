<?php

/**
 * Content Formatter
 *
 * @package SEO_Article_Generator
 */

namespace SEO_Article_Generator\Generator;

use SEO_Article_Generator\Traits\Type_Safety;
use SEO_Article_Generator\Traits\Markdown_Processor;

use SEO_Article_Generator\Generator\Renderers\Competitor_Renderer;
use SEO_Article_Generator\Generator\Renderers\Download_Renderer;
use SEO_Article_Generator\Generator\Article_Schema;
use SEO_Article_Generator\Generator\Renderers\Moat_Renderer;
use SEO_Article_Generator\Generator\Renderers\Tech_Specs_Renderer;
use SEO_Article_Generator\Generator\Renderers\TOC_Renderer;

// Prevent direct access
if (! defined('ABSPATH')) {
	exit;
}

use SEO_Article_Generator\Validation\ChangelogVerifier;

/**
 * Handles HTML formatting of AI-generated content.
 * Refactored Phase 5: Delegating to specific Renderers.
 */
class Content_Formatter
{
	use Type_Safety;
	use Markdown_Processor;


	// @MODIFIED 2026-03-08: PLACEHOLDER_URL constant removed — Download_Link_Helper::is_placeholder_url() is now the single source of truth

	/**
	 * Heading variation map for the current article.
	 *
	 * @since 2.8.2
	 * @var array
	 */
	private $heading_map = array();

	private $competitor_renderer;
	private $download_renderer;
	private $moat_renderer;
	private $tech_specs_renderer;
	private $pros_cons_renderer;
	private $faq_renderer;
	private $toc_renderer;

	/**
	 * Whether to add a Table of Contents.
	 * @var bool
	 */
	private $should_add_toc = false;

	/**
	 * Safely read a nested array path without ever throwing offset/type errors.
	 *
	 * @param array $source
	 * @param array $path
	 * @param mixed $default
	 * @return mixed
	 */
	private function array_path(array $source, array $path, $default = null)
	{
		$value = $source;

		foreach ($path as $segment) {
			if (!is_array($value) || !array_key_exists($segment, $value)) {
				return $default;
			}
			$value = $value[$segment];
		}

		return $value;
	}

	/**
	 * Canonicalize article data through Article_Schema and normalize containers.
	 *
	 * @param array $article_data
	 * @return array
	 */
	private function canonicalize_article_contract(array $article_data): array
	{
		// Pre-screen: force all known container sections to arrays before
		// passing to Article_Schema::from_array(), which may throw on scalars.
		foreach (array('download_section', 'tech_specs', 'hero_section', 'features', 'faqs',
			'pros_cons', 'related_software', 'whats_new', 'installation_guide',
			'safety', 'competitors', 'moat_data') as $_pre) {
			if (isset($article_data[$_pre]) && !is_array($article_data[$_pre])) {
				$article_data[$_pre] = array();
			}
		}

		$article_data = Article_Schema::from_array($article_data)->to_array();

		$array_sections = array(
			'hero_section',
			'download_section',
			'tech_specs',
			'safety',
			'installation_guide',
			'pros_cons',
			'features',
			'whats_new',
			'faqs',
			'competitors',
			'related_software',
			'main_software_comparison',
			'comparison_field_order',
			'moat_data',
		);

		foreach ($array_sections as $key) {
			if (!isset($article_data[$key]) || !is_array($article_data[$key])) {
				$article_data[$key] = array();
			}
		}

		if (!isset($article_data['download_section']['links']) || !is_array($article_data['download_section']['links'])) {
			$article_data['download_section']['links'] = array();
		}

		if (!isset($article_data['installation_guide']['steps']) || !is_array($article_data['installation_guide']['steps'])) {
			$article_data['installation_guide']['steps'] = array();
		}

		if (!isset($article_data['installation_guide']['common_issues']) || !is_array($article_data['installation_guide']['common_issues'])) {
			$article_data['installation_guide']['common_issues'] = array();
		}

		if (!isset($article_data['pros_cons']['pros']) || !is_array($article_data['pros_cons']['pros'])) {
			$article_data['pros_cons']['pros'] = array();
		}

		if (!isset($article_data['pros_cons']['cons']) || !is_array($article_data['pros_cons']['cons'])) {
			$article_data['pros_cons']['cons'] = array();
		}

		return $article_data;
	}

	/**
	 * Order of sections is derived from Article_Schema::SECTION_REGISTRY.
	 * Shuffling logic is handled in to_html during the build phase.
	 */

	/**
	 * Constructor
	 *
	 * @since 2.8.2
	 *
	 * @param array $heading_map   Optional map of section_id => heading_text
	 * @param bool  $should_add_toc Whether to inject a TOC block.
	 */
	public function __construct($heading_map = array(), $should_add_toc = false)
	{
		$this->heading_map         = $this->normalize_heading_map($heading_map);
		$this->competitor_renderer = new Competitor_Renderer();
		$this->download_renderer   = new Download_Renderer();
		$this->moat_renderer       = new Moat_Renderer();
		$this->tech_specs_renderer = new Tech_Specs_Renderer();
		$this->pros_cons_renderer  = new \SEO_Article_Generator\Generator\Renderers\Pros_Cons_Renderer();
		$this->faq_renderer        = new \SEO_Article_Generator\Generator\Renderers\FAQ_Renderer();
		$this->toc_renderer        = new TOC_Renderer();
		$this->should_add_toc      = $should_add_toc;
	}

	/**
	 * Normalize heading map keys to canonical form.
	 *
	 * @since 2.30.0
	 * @param mixed $heading_map Raw heading map (array or serialized string)
	 * @return array Normalized heading map
	 */
	private function normalize_heading_map($heading_map): array
	{
		if (is_string($heading_map)) {
			$maybe = maybe_unserialize($heading_map);
			$heading_map = is_array($maybe) ? $maybe : array();
		}

		if (!is_array($heading_map)) {
			return array();
		}

		if (isset($heading_map['faq']) && !isset($heading_map['faqs'])) {
			$heading_map['faqs'] = $heading_map['faq'];
		}

		$normalized = array();

		foreach ($heading_map as $map_key => $map_value) {
			if (!is_string($map_key) || !is_string($map_value)) {
				continue;
			}

			$map_key   = trim($map_key);
			$map_value = trim($map_value);

			if ($map_key === '' || $map_value === '') {
				continue;
			}

			$canonical_key = Article_Schema::get_canonical_key($map_key);
			if ($canonical_key === null) {
				continue;
			}

			$normalized[$canonical_key] = $map_value;
		}

		return $normalized;
	}

	/**
	 * Get heading text for a section, managing backfill and persistence.
	 *
	 * @since 2.8.2
	 *
	 * @param string $section_id Section ID from Phrase_Variator::SECTION_CONFIG
	 * @param int    $post_id    Post ID for persistence check
	 * @return string Heading text
	 */
	private function get_heading($section_id, $post_id)
	{
		$section_id = Article_Schema::get_canonical_key((string) $section_id) ?: (string) $section_id;

		if (!empty($this->heading_map[$section_id])) {
			return $this->heading_map[$section_id];
		}

		if (empty($post_id)) {
			$post_id = get_the_ID();
		}

		$persisted_map = $this->normalize_heading_map(get_post_meta($post_id, '_seo_gen_heading_map', true));

		if (!empty($persisted_map[$section_id])) {
			$this->heading_map[$section_id] = $persisted_map[$section_id];
			return $persisted_map[$section_id];
		}

		$default_text = Article_Schema::get_default_heading($section_id);
		if ($default_text === '') {
			$default_text = ucwords(str_replace('-', ' ', $section_id));
		}

		$new_map   = $this->normalize_heading_map(Phrase_Variator::generate_heading_map());
		$final_map = array_merge($new_map, $persisted_map);

		update_post_meta($post_id, '_seo_gen_heading_map', $final_map);
		$this->heading_map = $final_map;

		return $final_map[$section_id] ?? $default_text;
	}

	private function get_anchor_for_section(string $section_id): string
	{
		$section_id = Article_Schema::get_canonical_key($section_id) ?: $section_id;
		return Article_Schema::get_anchor($section_id);
	}

	private function installation_guide_has_content(array $guide): bool
	{
		$intro = trim(wp_strip_all_tags((string) ($guide['intro'] ?? $guide['summary'] ?? '')));
		if ($intro !== '') {
			return true;
		}

		$steps = isset($guide['steps']) && is_array($guide['steps']) ? $guide['steps'] : array();
		foreach ($steps as $step) {
			if (is_array($step)) {
				$text = trim(
					wp_strip_all_tags(
						(string) ($step['title'] ?? '') . ' ' .
						(string) ($step['description'] ?? '') . ' ' .
						(string) ($step['content'] ?? '')
					)
				);
			} else {
				$text = trim(wp_strip_all_tags((string) $step));
			}

			if ($text !== '') {
				return true;
			}
		}

		$notes = trim(wp_strip_all_tags((string) ($guide['compatibility_notes'] ?? '')));
		return $notes !== '';
	}

	private function build_section_renderer(string $section, array $article_data, int $post_id)
	{
		$section = Article_Schema::get_canonical_key($section) ?: $section;

		switch ($section) {
			case 'toc_placeholder':
			case 'tocplaceholder':
				return function () {
					return [
						array(
							'blockName'    => null,
							'attrs'        => [],
							'innerBlocks'  => [],
							'innerHTML'    => '<!-- seo-gen-toc-placeholder -->',
							'innerContent' => ['<!-- seo-gen-toc-placeholder -->'],
						),
					];
				};

			case 'hero':
				return function () use ($article_data) {
					if (empty($article_data['hero_section'])) {
						return array();
					}
					return self::parse_required_markup('<!-- wp:seo-gen/hero /-->', 'hero');
				};

			case 'introduction':
				return function () use ($article_data) {
					if (empty($article_data['introduction'])) {
						return array();
					}

					$blocks     = array();
					$paragraphs = is_array($article_data['introduction']) ? $article_data['introduction'] : array($article_data['introduction']);

					foreach ($paragraphs as $para) {
						if (trim((string) $para) === '') {
							continue;
						}
						$blocks[] = self::paragraph_block(self::process_markdown($para));
					}

					return $blocks;
				};

			case 'moat':
				return function () use ($article_data, $post_id) {
					$moat_data = isset($article_data['moat_data']) ? $article_data['moat_data'] : array();
					
					// [ROBUST FIX] Fetch and inject the varied heading
					$heading = $this->get_heading('moat', $post_id);
					$moat_data['heading'] = $heading;
					
					return $this->moat_renderer->render_blocks($moat_data);
				};

	case 'download':
		return function () use ($article_data, $post_id) {
			$download_section = $this->array_path($article_data, array('download_section'), array());
			$download_section = is_array($download_section) ? $download_section : array();

			$os_support = (string) $this->array_path($article_data, array('tech_specs', 'os_support'), '');
			$safety = $this->array_path($article_data, array('safety'), array());
			$safety = is_array($safety) ? $safety : array();

			$tech_specs = $this->array_path($article_data, array('tech_specs'), array());
			$tech_specs = is_array($tech_specs) ? $tech_specs : array();

			// @MODIFIED 2026-08-12: Pass regen_sections to Download_Renderer so it can
			// disable link continuity when download section is explicitly regenerated.
			$regen_sections = $this->array_path($article_data, array('regen_sections'), array());
			$regen_sections = is_array($regen_sections) ? $regen_sections : array();

			// [AUDIT FIX] Pass the canonical download anchor so DownloadRenderer
			// can emit an anchored <h2> that TOCRenderer can detect.
			// ArticleSchema::SECTIONREGISTRY['download']['anchor'] = 'download-portal'.
			$anchor = $this->get_anchor_for_section('download');

			return $this->download_renderer->render_blocks(
				$download_section,
				$os_support,
				$safety,
				$tech_specs,
				$anchor,
				$post_id,
				$regen_sections
			);
		};

			case 'tech_specs':
				return function () use ($article_data, $post_id) {
					if (empty($article_data['tech_specs']) || !is_array($article_data['tech_specs'])) {
						return array();
					}

					$heading = $this->get_heading('tech_specs', $post_id);
					$anchor  = $this->get_anchor_for_section('tech_specs');

					$blocks   = array();
					$blocks[] = self::heading_block($heading, 2, $anchor);

					$specs_blocks = $this->tech_specs_renderer->render_blocks($article_data['tech_specs'], $post_id);
					if (!empty($specs_blocks)) {
						$blocks = array_merge($blocks, $specs_blocks);
					}

					return $blocks;
				};

			case 'system_requirements':
				return function () use ($article_data, $post_id) {
					if (empty($article_data['system_requirements'])) {
						return array();
					}

					$heading = $this->get_heading('system_requirements', $post_id);
					$anchor  = $this->get_anchor_for_section('system_requirements');

					return $this->format_system_requirements($article_data['system_requirements'], $heading, $anchor);
				};

case 'features':
				return function () use ($article_data, $post_id) {
					if (empty($article_data['features']) || !is_array($article_data['features'])) {
						return array();
					}

					$heading = $this->get_heading('features', $post_id);
					$anchor  = $this->get_anchor_for_section('features');

					$blocks   = array();
					$blocks[] = self::heading_block($heading, 2, $anchor);

					$list_items = array();
					foreach ($article_data['features'] as $feature) {
						$feature = Article_Schema::normalize_feature_item($feature);
						if ($feature === null) {
							continue;
						}

						$name = $feature['name'];
						$desc = $feature['description'];

						$li_html = '';
						if ($name !== '') {
							$li_html .= '<strong>' . wp_kses_post(self::process_markdown($name)) . ':</strong> ';
						}
						$li_html .= wp_kses_post(self::process_markdown($desc));

						$list_items[] = self::make_block('core/list-item', array(), '<li>' . $li_html . '</li>');
					}

					$list_markup = '<!-- wp:list --><ul>' . serialize_blocks($list_items) . '</ul><!-- /wp:list -->';
					$parsed_list = self::parse_required_markup($list_markup, 'features_list');
					if (!empty($parsed_list[0])) {
						$blocks[] = $parsed_list[0];
					}

					return $blocks;
				};

			case 'whats_new':
				return function () use ($article_data, $post_id) {
					if (empty($article_data['whats_new']) || !is_array($article_data['whats_new'])) {
						return array();
					}

					// Changelog is always supplied as source context, so the
					// bullets are trusted; the verified URL (if any) only
					// drives the optional "official release notes" link.
					$cl_verify   = ChangelogVerifier::verify($article_data);
					$verified_url = $cl_verify['ok'] ? $cl_verify['url'] : '';

					$heading = $this->get_heading('whats_new', $post_id);
					$anchor  = $this->get_anchor_for_section('whats_new');

					$blocks = $this->format_whats_new_blocks($article_data['whats_new'], $heading, $anchor, $verified_url);

					// Cumulative version history: newest is the visible block
					// above; older entries (max 5) render in an accordion.
					$history = (isset($article_data['whats_new_history']) && is_array($article_data['whats_new_history']))
						? $article_data['whats_new_history']
						: ($post_id > 0 ? (array) \get_post_meta($post_id, '_seo_gen_whats_new_history', true) : array());
					if (!is_array($history)) {
						$history = array();
					}
					$older = array_slice($history, 1, 5);
					if (!empty($older)) {
						$accordion = $this->format_whats_new_history_accordion($older, $post_id);
						if (!empty($accordion)) {
							$blocks = array_merge($blocks, $accordion);
						}
					}

					return $blocks;
				};

			case 'pros_cons':
				return function () use ($article_data, $post_id) {
					if (empty($article_data['pros_cons'])) {
						return array();
					}

					$pros = isset($article_data['pros_cons']['pros']) ? $article_data['pros_cons']['pros'] : array();
					$cons = isset($article_data['pros_cons']['cons']) ? $article_data['pros_cons']['cons'] : array();
					if (empty($pros) || empty($cons)) {
						return array();
					}

					$heading = $this->get_heading('pros_cons', $post_id);
					$anchor  = $this->get_anchor_for_section('pros_cons');

					return $this->pros_cons_renderer->render_blocks($article_data['pros_cons'], $heading, $anchor);
				};

			case 'installation':
				return function () use ($article_data, $post_id) {
					$guide = isset($article_data['installation_guide']) && is_array($article_data['installation_guide'])
						? $article_data['installation_guide']
						: array();

					if (! $this->installation_guide_has_content($guide)) {
						return array();
					}

					$heading = $this->get_heading('installation', $post_id);
					$anchor  = $this->get_anchor_for_section('installation');

					$blocks   = array();
					$blocks[] = self::heading_block($heading, 2, $anchor);

					$inner_blocks = $this->format_installation_guide($guide, $post_id);
					if (!empty($inner_blocks)) {
						$blocks = array_merge($blocks, $inner_blocks);
					}

					return $blocks;
				};

			case 'troubleshooting':
				return function () use ($article_data, $post_id) {
					$issues = $this->array_path($article_data, array('installation_guide', 'common_issues'), array());
					$issues = is_array($issues) ? $issues : array();

					if (empty($issues)) {
						return array();
					}

					$heading = $this->get_heading('troubleshooting', $post_id);
					$anchor  = $this->get_anchor_for_section('troubleshooting');
					$blocks  = array();

					$blocks[] = self::heading_block($heading, 2, $anchor);
					$inner    = $this->format_troubleshooting($issues, $post_id);

					if (!empty($inner)) {
						$blocks = array_merge($blocks, $inner);
					}

					return $blocks;
				};

			case 'video':
				return function () use ($article_data) {
					if (empty($article_data['video_url'])) {
						return array();
					}
					return $this->format_video_embed($article_data['video_url']);
				};

			case 'faqs':
				return function () use ($article_data, $post_id) {
					if (empty($article_data['faqs'])) {
						return array();
					}

					$heading = $this->get_heading('faqs', $post_id);
					$anchor  = $this->get_anchor_for_section('faqs');

					return $this->faq_renderer->render_blocks($article_data['faqs'], $post_id, $heading, $anchor);
				};

			case 'competitors':
				return function () use ($article_data, $post_id) {
					if (empty($article_data['competitors']) || !is_array($article_data['competitors'])) {
						return array();
					}

					$heading = $this->get_heading('competitors', $post_id);

					// [ROBUST FIX] Dynamically inject the software name into the heading.
					// Using str_replace instead of sprintf prevents fatal errors if the AI 
					// accidentally generates a "%" sign in the heading text.
					if (strpos($heading, '%s') !== false) {
						$software_name = isset($article_data['tech_specs']['software_name']) 
							? trim(wp_strip_all_tags((string) $article_data['tech_specs']['software_name'])) 
							: '';

						if ($software_name !== '') {
							$heading = str_replace('%s', $software_name, $heading);
						} else {
							// Graceful fallback if AI somehow didn't provide a software name
							$heading = str_replace(' to %s', '', $heading);
							$heading = str_replace('%s Alternatives', 'Alternatives', $heading);
							$heading = str_replace('%s', 'This Software', $heading);
						}
					}

					$anchor  = $this->get_anchor_for_section('competitors');

					$blocks   = array();
					$blocks[] = self::heading_block($heading, 2, $anchor);

					$comp_blocks = $this->format_competitor_comparison_blocks($article_data['competitors'], $article_data);
					if (!empty($comp_blocks)) {
						$blocks = array_merge($blocks, $comp_blocks);
					}

					return $blocks;
				};

			case 'related_software':
				return function () use ($article_data) {
					if (empty($article_data['related_software'])) {
						return array();
					}
					return $this->format_related_software($article_data['related_software']);
				};
		}

		return null;
	}

	/**
	 * Convert article data to HTML
	 *
	 * @MODIFIED 2025-12-03 v1.2.7: Pass post_id to formatters
	 * @MODIFIED 2025-12-12 v1.9.4: Declarative section ordering for download-intent UX
	 *
	 * @param array $article_data Article data from AI
	 * @param int   $post_id Post ID for unique IDs
	 * @return string HTML content
	 */
	// to_html moved to line 926

	/**
	 * Build section-to-renderer mapping
	 *
	 * @MODIFIED 2025-12-12 v1.9.4: Extracted from to_html for declarative ordering
	 * @MODIFIED 2026-03-11: Made public for Surgical_Patcher integration
	 *
	 * Each renderer is a callable that returns HTML string (empty if section has no data).
	 * This design allows easy per-mode ordering in the future.
	 *
	 * @param array $article_data Article data from AI
	 * @param int   $post_id Post ID for unique IDs
	 * @return array<string, callable> Section key => renderer callable
	 */
	public function get_section_renderers($article_data, $post_id)
	{
		$article_data = $this->canonicalize_article_contract((array) $article_data);

		$renderers = array(
			'toc_placeholder' => $this->build_section_renderer('toc_placeholder', (array) $article_data, (int) $post_id),
		);

		foreach (Article_Schema::get_ordered_section_keys() as $section) {
			$renderer = $this->build_section_renderer($section, (array) $article_data, (int) $post_id);
			if (is_callable($renderer)) {
				$renderers[$section] = $renderer;
			}
		}

		return $renderers;
	}

	/**
	 * Markup helper for What's New to simplify closure
	 *
	 * @MODIFIED 2026-03-26: Refactored to block arrays
	 */
	private function format_whats_new_blocks($items, $heading, $anchor, $verified_url = '')
	{
		$inner_blocks = array();
		$inner_blocks[] = self::heading_block($heading, 2, $anchor);

		$list_html = '<ul>';
		foreach ($items as $item) {
			if ($item === '') continue;
			$list_html .= '<li>' . wp_kses_post(self::process_markdown($item)) . '</li>';
		}
		$list_html .= '</ul>';
		$inner_blocks[] = self::make_block('core/list', array(), $list_html);

		if (! empty($verified_url)) {
			$inner_blocks[] = self::make_block(
				'core/paragraph',
				array('className' => 'seo-gen-eeat-source'),
				'<p class="seo-gen-eeat-source">For complete changelog, visit the <a href="' . esc_url($verified_url) . '" target="_blank" rel="noopener">official release notes</a>.</p>'
			);
		}

		$group_markup = '<!-- wp:group {"className":"seo-gen-whats-new-section"} -->'
			. '<div class="wp-block-group seo-gen-whats-new-section">'
			. serialize_blocks($inner_blocks)
			. '</div><!-- /wp:group -->';

		$parsed_group = self::parse_required_markup($group_markup, 'whats_new');
		return !empty($parsed_group) ? $parsed_group : array();
	}

	/**
	 * Render older What's New entries as a collapsed accordion,
	 * mirroring the installation guide accordion.
	 *
	 * @param array $entries Ordered list of {version,date,bullets}[].
	 * @param int   $post_id Post ID for unique IDs.
	 * @return array Gutenberg blocks (empty if none).
	 */
	private function format_whats_new_history_accordion(array $entries, int $post_id): array
	{
		if (empty($entries)) {
			return array();
		}

		$content_id = 'whats-new-history-' . (int) $post_id . '-' . substr(md5(serialize($entries)), 0, 8);

		$inner_blocks = array();
		foreach ($entries as $entry) {
			// [ROBUST FIX] Normalize entry into {version, date, bullets} regardless of
			// stored shape. Legacy/accumulated post meta may hold flat string lists,
			// or use 'whats_new'/'items' as the bullet alias, or omit 'bullets' entirely.
			// Without this, version collapses to '' ("previous version") and bullets
			// collapse to [] (blank list) — the exact "accordion shows nothing" bug.
			$version = '';
			$date    = '';
			$bullets = array();

			if (is_string($entry) && $entry !== '') {
				$bullets = array($entry);
			} elseif (is_array($entry)) {
				$version = isset($entry['version']) ? trim((string) $entry['version']) : '';
				$date    = isset($entry['date']) ? trim((string) $entry['date']) : '';

				$candidate = null;
				foreach (array('bullets', 'whats_new', 'items') as $bk) {
					if (isset($entry[$bk]) && is_array($entry[$bk])) {
						$candidate = $entry[$bk];
						break;
					}
				}
				$has_struct_keys = isset($entry['version']) || isset($entry['date'])
					|| isset($entry['bullets']) || isset($entry['whats_new']) || isset($entry['items']);
				if ($candidate === null && !$has_struct_keys) {
					// Entry itself is a flat list of bullet strings.
					$candidate = $entry;
				}
				if (is_array($candidate)) {
					foreach ($candidate as $b) {
						$b = is_scalar($b) ? trim((string) $b) : '';
						if ($b !== '') {
							$bullets[] = $b;
						}
					}
				}
			}

			if (empty($bullets)) {
				continue;
			}

			$sub_heading = 'Changes in ' . ($version !== '' ? $version : 'previous version')
				. ($date !== '' ? ' (' . $date . ')' : '');
			$inner_blocks[] = self::heading_block($sub_heading, 4, '');

			$list_html = '<ul>';
			foreach ($bullets as $b) {
				$list_html .= '<li>' . wp_kses_post(self::process_markdown($b)) . '</li>';
			}
			$list_html .= '</ul>';
			$inner_blocks[] = self::make_block('core/list', array(), $list_html);
		}

		$inner_html  = serialize_blocks($inner_blocks);
		$group_markup = '<!-- wp:group {"anchor":"' . esc_attr($content_id) . '","className":"seo-gen-accordion-content"} -->'
			. '<div id="' . esc_attr($content_id) . '" class="wp-block-group seo-gen-accordion-content">' . $inner_html . '</div><!-- /wp:group -->';
		$parsed_group = self::parse_required_markup($group_markup, 'whats_new_history');
		if (empty($parsed_group)) {
			return array();
		}

		$trigger_html  = '<div class="seo-gen-accordion-trigger" role="button" tabindex="0" aria-expanded="false" aria-controls="'
			. esc_attr($content_id) . '" data-target="' . esc_attr($content_id) . '">';
		$trigger_html .= esc_html(__('Version History', 'seo-article-generator'))
			. '<span class="accordion-icon" aria-hidden="true"></span>';
		$trigger_html .= '</div>';

		$blocks       = array(self::make_block('core/html', array(), $trigger_html), $parsed_group[0]);
		$outer_html   = serialize_blocks($blocks);
		$outer_markup = '<!-- wp:group {"className":"seo-gen-accordion-block"} -->'
			. '<div class="wp-block-group seo-gen-accordion-block">' . $outer_html . '</div><!-- /wp:group -->';
		$parsed_outer = self::parse_required_markup($outer_markup, 'whats_new_history_outer');

		return !empty($parsed_outer) ? $parsed_outer : array();
	}

	/**
	 * Format competitor comparison table - INLINE (no accordion)
	 *
	 * @MODIFIED 2025-12-04 v1.5.0: Option A detailed comparison
	 * @MODIFIED 2025-12-04 v1.5.0 FIX: Accept article_data for dynamic main software values
	 * @MODIFIED 2025-12-15 v2.1.1: Removed accordion, display inline for SEO and conversion
	 * @MODIFIED 2025-12-15 v2.2.0: Dynamic category-aware fields from AI
	 * @MODIFIED 2025-12-29 v2.7.0: Removed redundant intro sentence
	 *
	 * @param array $competitors Array of competitor data
	 * @param array $article_data Full article data for main software values
	 * @return string HTML output
	 */
	/**
	 * Format competitor comparison as a Gutenberg core/table block.
	 * Delegates to Competitor_Renderer for the single source of truth.
	 *
	 * Output includes the required <figure class="wp-block-table"> wrapper
	 * plus seo-gen-* wrapper and cell classes for comparison styling.
	 */
	private function format_competitor_comparison_blocks($competitors, $article_data)
	{
		if (empty($competitors) || !is_array($competitors)) {
			return array();
		}

		$markup = $this->competitor_renderer->render($competitors, $article_data);
		return self::parse_required_markup($markup, 'competitor_comparison');
	}





	/**
	 * Format technical specifications table
	 *
	 * @param array $specs Technical specs
	 * @return string HTML table
	 */
	/**
	 * Technical specifications as a Gutenberg table block.
	 */
	/**
	 * Format technical specifications via Renderer.
	 */
	private function format_tech_specs($specs)
	{
		return $this->tech_specs_renderer->render($specs);
	}


	/**
	 * Format download section.
	 *
	 * @MODIFIED 2025-12-03 Phase 3: Backward compatibility for new links[] structure
	 * @MODIFIED 2025-12-05 v1.5.2: Primary CTA first + platform-aware layout
	 *
	 * @param array  $download_section Download section data.
	 * @param string $os_support       OS support string for platform badges.
	 * @param array  $safety           Safety data from Safety_Data DTO (optional).
	 * @param array  $tech_specs       Tech specs for software name/version/size (optional).
	 * @return string HTML.
	 */
	/**
	 * Format download section via Renderer.
	 */
	private function format_download_section($download_section, $os_support = '', $safety = array(), $tech_specs = array(), $post_id = 0)
	{
		return $this->download_renderer->render($download_section, $os_support, $safety, $tech_specs, '', $post_id);
	}

	/**
	 * Convert article data to HTML using block-first architecture.
	 *
	 * @param array $article_data Article data from AI
	 * @param int   $post_id Post ID for unique IDs
	 * @return string HTML content (serialized blocks)
	 */
	public function to_html($article_data, $post_id = 0)
	{
		if (defined('SEO_GEN_DEBUG_RENDER') && SEO_GEN_DEBUG_RENDER) {
			error_log(wp_json_encode(array(
				'msg' => 'Content_Formatter runtime',
				'file' => __FILE__,
				'mtime' => @filemtime(__FILE__),
			)));
		}

		$article_data = $this->canonicalize_article_contract((array) $article_data);

		if (empty($post_id)) {
			$post_id = get_the_ID();
		}

		$blocks    = array();
		$renderers = $this->get_section_renderers($article_data, $post_id);

		// 1. Determine Order from Registry Metadata
		$registry = Article_Schema::SECTION_REGISTRY;
		
		$top    = array();
		$middle = array();
		$bottom = array();

		foreach ($registry as $key => $config) {
			$order = $config['order'] ?? 100;
			
			if ($order <= 40) {
				$top[] = $key;
			} elseif ($order < 100) {
				$middle[] = $key;
			} else {
				$bottom[] = $key;
			}
		}

		// Inject toc_placeholder after intro
		$intro_pos = array_search('introduction', $top, true);
		if ($intro_pos !== false) {
			array_splice($top, $intro_pos + 1, 0, 'toc_placeholder');
		}

		// Deterministic sort for middle tier (no global RNG mutation)
		// FINDING-7 FIX: Use content-derived seed for new posts (post_id=0) to avoid
		// identical ordering for all new posts, and use spaceship operator to avoid int overflow.
		usort($middle, function ($a, $b) use ($post_id, $article_data) {
			// For new posts (post_id=0), derive a unique seed from the article's own content
			// so each article still gets varied ordering even before the post is created.
			$seed = $post_id > 0
				? $post_id
				: abs(crc32(serialize(array(
					$article_data['title']        ?? '',
					$article_data['tech_specs']['software_name'] ?? '',
					$article_data['tech_specs']['version']      ?? '',
				))));
			// Use spaceship operator to avoid int overflow from crc32 subtraction.
			return crc32((string) $seed . ':' . $a) <=> crc32((string) $seed . ':' . $b);
		});

		// @MODIFIED 2026-08-24: Pin the Video block immediately AFTER the Features
		// section. Both live in the shuffleable middle tier (features=70, video=75),
		// so the deterministic shuffle above could relocate the video. Remove it from
		// its shuffled position and re-insert it directly after 'features' to make the
		// placement stable regardless of the shuffle outcome.
		$video_pos = array_search('video', $middle, true);
		if ($video_pos !== false) {
			array_splice($middle, $video_pos, 1);
			$features_pos = array_search('features', $middle, true);
			$video_insert_at = ($features_pos !== false) ? $features_pos + 1 : count($middle);
			array_splice($middle, $video_insert_at, 0, 'video');
		}

		$final_order = array_merge($top, $middle, $bottom);

		// @MODIFIED 2026-09-01: Honor $regen_sections strictly.
		// Sections NOT in $regen_sections (and not 'all') MUST NOT be rendered.
		// This prevents AI-hallucinated zones (e.g. competitors returned for
		// COMPLEX_ENGINE new posts when the user did not request competitors)
		// from being inserted into the post. Always-included zones (hero,
		// toc_placeholder) bypass the filter.
		$regen_sections_filter = $this->array_path($article_data, array('regen_sections'), array());
		$regen_sections_filter = is_array($regen_sections_filter) ? $regen_sections_filter : array();
		$always_included = array('hero', 'toc_placeholder');
		if (!empty($regen_sections_filter) && !in_array('all', $regen_sections_filter, true)) {
			$allowed = array_merge($always_included, $regen_sections_filter);
			$final_order = array_values(array_intersect($final_order, $allowed));
		}

		// 2. Accumulate Blocks
foreach ($final_order as $section) {
			if (isset($renderers[$section])) {
				$section_blocks = (array) $renderers[$section]();

				$section_blocks = array_values(array_filter($section_blocks, static function ($block) {
					return is_array($block)
						&& array_key_exists('blockName', $block)
						&& array_key_exists('innerBlocks', $block)
						&& array_key_exists('innerContent', $block);
				}));

				if (empty($section_blocks)) {
					continue;
				}

				// Wrap in seo-gen/section if not already wrapped
				if ($section !== 'toc_placeholder' && $section !== 'hero') {
					$section_blocks = self::zone_block($section, $section_blocks);
					$section_blocks = self::filter_valid_block_trees($section_blocks);
					if (empty($section_blocks)) {
						continue;
					}
				}

				$blocks = array_merge($blocks, $section_blocks);
			}
		}

	// 3. Serialize
		$html = serialize_blocks($blocks);

		// Normalize the hero block comment to the canonical parser-safe form.
		// Single source of truth lives in Article_Schema::canonicalize_hero_block_comment();
		// the surrounding newlines are kept for visual separation in the editor, matching
		// the historical layout that the new-post path has always emitted.
		$hero_canonical = Article_Schema::canonicalize_hero_block_comment( $html );
		if ( $hero_canonical !== $html && strpos( $hero_canonical, 'wp:seo-gen/hero' ) !== false ) {
			$html = preg_replace(
				'~<!--\s*wp:seo-gen/hero\s*/?\s*-->~i',
				"\n<!-- wp:seo-gen/hero /-->\n",
				$hero_canonical
			);
		} else {
			$html = $hero_canonical;
		}

		// 4. Post-Rendering TOC Injection
		// The toc_placeholder is emitted as a null-blockName freeform node (no wp:html wrapper).
		// The preg_replace below is a runtime safety net: if serialize_blocks() ever wraps it
		// in <!-- wp:html --> despite the null blockName, the regex strips it so the
		// rank-math/toc-block always lands as a top-level block in the saved post content.
		if ($this->should_add_toc && strpos($html, '<!-- seo-gen-toc-placeholder -->') !== false) {
			$actual_toc = $this->toc_renderer->generate_from_html($html);
			// Primary: strip any wp:html wrapper that may surround the placeholder
			$html = preg_replace(
				'/<!-- wp:html -->\s*<!-- seo-gen-toc-placeholder -->\s*<!-- \/wp:html -->/',
				$actual_toc,
				$html,
				1
			);
			// Fallback: bare placeholder (normal path — null blockName emits no wrapper)
			$html = str_replace('<!-- seo-gen-toc-placeholder -->', $actual_toc, $html);
		} else {
			$html = preg_replace(
				'/<!-- wp:html -->\s*<!-- seo-gen-toc-placeholder -->\s*<!-- \/wp:html -->/',
				'',
				$html
			);
			$html = str_replace('<!-- seo-gen-toc-placeholder -->', '', $html);
		}

		return $html;
	}

	/**
	 * Serialize a content section into a native Gutenberg block.
	 * 
	 * @since 2.30.0
	 * @param string $zone Zone name.
	 * @param string $inner_html HTML content.
	 * @return string Serialized block.
	 */
	private function serialize_section_block(string $zone, string $inner_html): string
	{
		$attrs = array('zone' => $zone);

		if (function_exists('get_comment_delimited_block_content')) {
			return get_comment_delimited_block_content(
				'seo-gen/section',
				$attrs,
				$inner_html
			);
		}

		$attrs_json = wp_json_encode(
			$attrs,
			JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
		);

		return sprintf(
			'<!-- wp:seo-gen/section %1$s -->%2$s<!-- /wp:seo-gen/section -->',
			$attrs_json,
			$inner_html
		);
	}



	/**
	 * Format features list
	 *
	 * @param array $features Features array
	 * @return string HTML
	 */
	private function format_features($features)
	{
		$html  = '<h2 class="wp-block-heading" id="key-features">Key Features</h2>' . "\n";
		$html .= '<ul class="seo-gen-features-list">' . "\n";

		foreach ($features as $feature) {
			$html .= '<li>';
			$html .= '<strong>' . wp_kses_post(self::process_markdown($feature['name'])) . ':</strong> ';
			$html .= wp_kses_post($feature['description']);
			$html .= '</li>' . "\n";
		}

		$html .= '</ul>' . "\n\n";
		return $html;
	}

	/**
	 * Format what's new section
	 *
	 * @param array  $whats_new What's new items
	 * @param string $version Version number
	 * @return string HTML
	 */
	private function format_whats_new($whats_new, $version)
	{
		$html  = '<!-- wp:heading -->' . "\n";
		$html .= '<h2 class="wp-block-heading" id="' . esc_attr(sanitize_title($version)) . '">What\'s New in Version ' . esc_html($version) . '</h2>' . "\n";
		$html .= '<!-- /wp:heading -->' . "\n";
		$html .= '<!-- wp:list -->' . "\n";
		$html .= '<ul>' . "\n";

		foreach ($whats_new as $item) {
			$html .= '<!-- wp:list-item -->' . "\n";
			$html .= '<li>' . wp_kses_post(self::process_markdown($item)) . '</li>' . "\n";
			$html .= '<!-- /wp:list-item -->' . "\n";
		}

		$html .= '</ul>' . "\n";
		$html .= '<!-- /wp:list -->' . "\n";
		return $html;
	}

	/**
	 * Map common system spec keys to user-friendly labels.
	 *
	 * @param string $key
	 * @return string
	 */
	private function normalize_spec_label($key)
	{
		$map = array(
			'os'         => 'OS',
			'ram'        => 'RAM',
			'cpu'        => 'Processor',
			'processor'  => 'Processor',
			'gpu'        => 'Graphics',
			'graphics'   => 'Graphics',
			'disk_space' => 'Disk Space',
			'storage'    => 'Disk Space',
			'disk'       => 'Disk Space',
			'screen'     => 'Screen',
			'monitor'    => 'Monitor',
			'network'    => 'Network',
			'internet'   => 'Internet',
			'sound'      => 'Sound Card',
			'audio'      => 'Sound',
		);

		$k = strtolower(trim($key));
		if (isset($map[$k])) {
			return $map[$k];
		}

		return ucwords(str_replace('_', ' ', $key));
	}

	/**
	 * System requirements as heading + two list blocks.
	 *
	 * @MODIFIED 2025-12-30 v2.8.2: Support dynamic heading and anchor
	 */
	private function format_system_requirements($requirements, $heading = 'System Requirements', $anchor_id = 'system-requirements')
	{
		if (empty($requirements) || !is_array($requirements)) {
			return array();
		}

		$has_detailed_reqs = false;

		foreach (array('minimum', 'recommended') as $type) {
			if (!empty($requirements[$type]) && is_array($requirements[$type])) {
				foreach ($requirements[$type] as $value) {
					if ($value !== '' && $value !== null) {
						$has_detailed_reqs = true;
						break 2;
					}
				}
			}
		}

		if (!$has_detailed_reqs) {
			return array();
		}

		$blocks = array();
		$blocks[] = self::heading_block($heading, 2, $anchor_id);

		foreach (array('minimum' => 'Minimum', 'recommended' => 'Recommended') as $type => $label) {
			if (empty($requirements[$type]) || !is_array($requirements[$type])) {
				continue;
			}

			$items = array();
			foreach ($requirements[$type] as $key => $value) {
				if ($value === '' || $value === null) {
					continue;
				}

				$item_html = '<li><strong>' . esc_html($this->normalize_spec_label($key)) . ':</strong> ' . wp_kses_post(self::process_markdown($value)) . '</li>';
				$items[] = self::make_block('core/list-item', array(), $item_html);
			}

			if (empty($items)) {
				continue;
			}

			$blocks[] = self::heading_block($label, 3);

			$list_markup = '<!-- wp:list --><ul>' . serialize_blocks($items) . '</ul><!-- /wp:list -->';
			$parsed_list = self::parse_required_markup($list_markup, 'system_requirements_list');
			if (!empty($parsed_list[0])) {
				$blocks[] = $parsed_list[0];
			}
		}

		return $blocks;
	}


	/**
	 * Format screenshot gallery
	 *
	 * @MODIFIED 2026-03-26: Refactored to block arrays
	 */
	private function format_screenshots($screenshot_ids)
	{
		if (empty($screenshot_ids)) {
			return array();
		}

		$blocks = array();
		$blocks[] = self::heading_block('Screenshots', 2);

		$ids = is_array($screenshot_ids) ? $screenshot_ids : explode(',', (string) $screenshot_ids);
		$images_html = '';

		foreach ($ids as $id) {
			$id = trim($id);
			if (empty($id)) {
				continue;
			}

			$img_src_info = \wp_get_attachment_image_src(absint($id), 'large');
			if (is_array($img_src_info) && isset($img_src_info[0])) {
				$images_html .= '<img src="' . esc_url($img_src_info[0]) . '" alt="Screenshot" loading="lazy">' . "\n";
			}
		}

		if ($images_html !== '') {
			$html = '<div class="seo-gen-screenshot-gallery">' . "\n" . $images_html . '</div>';
			$blocks[] = self::make_block('core/html', array(), $html);
		}

		return $blocks;
	}

	/**
	 * Format installation guide with accordion
	 *
	 * @MODIFIED 2026-03-26: Refactored to block arrays
	 */
	private function format_installation_guide($guide, $post_id = 0)
	{
		if (! is_array($guide)) {
			return array();
		}

		$intro = trim((string) ($guide['intro'] ?? $guide['summary'] ?? ''));
		$steps = ! empty($guide['steps']) && is_array($guide['steps']) ? $guide['steps'] : array();
		$notes = trim((string) ($guide['compatibility_notes'] ?? ''));

		if ($intro === '' && empty($steps) && $notes === '') {
			return array();
		}

		$content_id   = 'install-content-' . (int) $post_id;
		$inner_blocks = array();

		if ($intro !== '') {
			$inner_blocks[] = self::paragraph_block(self::process_markdown($intro));
		}

		if (! empty($steps)) {
			$inner_blocks[] = self::heading_block('Installation Steps', 3);

			$list_items = array();
			foreach ($steps as $step) {
				$text = '';

				if (is_array($step)) {
					$parts = array_filter(array(
						trim((string) ($step['title'] ?? '')),
						trim((string) ($step['description'] ?? '')),
						trim((string) ($step['content'] ?? '')),
					));
					$text = trim(implode(' — ', $parts));
				} else {
					$text = trim((string) $step);
				}

				if ($text === '') {
					continue;
				}

				// [ROBUST FIX] Strip AI-generated numbers, bullets, or "Step X:" 
				// to prevent double numbering inside the HTML <ol>
				$text = preg_replace('/^(?:Step\s*\d+\s*[:\-.]?\s*|\d+[\.\)]\s*|\-\s*|\*\s*)/i', '', $text);
				$text = trim($text);

				$list_items[] = self::make_block(
					'core/list-item',
					array(),
					'<li>' . wp_kses_post(self::process_markdown($text)) . '</li>'
				);
			}

			if (! empty($list_items)) {
				$list_markup = '<!-- wp:list {"ordered":true} --><ol>' . serialize_blocks($list_items) . '</ol><!-- /wp:list -->';
				$parsed_list = self::parse_required_markup($list_markup, 'installationguide-steps');
				if (! empty($parsed_list[0])) {
					$inner_blocks[] = $parsed_list[0];
				}
			}
		}

		if ($notes !== '') {
			$inner_blocks[] = self::paragraph_block('<strong>Compatibility:</strong> ' . self::process_markdown($notes));
		}

		if (empty($inner_blocks)) {
			return array();
		}

		$blocks = array();

		$trigger_html  = '<div class="seo-gen-accordion-trigger" role="button" tabindex="0" aria-expanded="false" aria-controls="' . esc_attr($content_id) . '" data-target="' . esc_attr($content_id) . '">';
		$trigger_html .= 'Show Installation Steps<span class="accordion-icon" aria-hidden="true"></span>';
		$trigger_html .= '</div>';
		$blocks[] = self::make_block('core/html', array(), $trigger_html);

		$inner_html   = serialize_blocks($inner_blocks);
		$group_markup = '<!-- wp:group {"anchor":"' . esc_attr($content_id) . '","className":"seo-gen-accordion-content"} --><div id="' . esc_attr($content_id) . '" class="wp-block-group seo-gen-accordion-content">' . $inner_html . '</div><!-- /wp:group -->';
		$parsed_group = self::parse_required_markup($group_markup, 'installationguide');
		if (! empty($parsed_group[0])) {
			$blocks[] = $parsed_group[0];
		}

		$outer_html   = serialize_blocks($blocks);
		$outer_markup = '<!-- wp:group {"className":"seo-gen-accordion-block"} --><div class="wp-block-group seo-gen-accordion-block">' . $outer_html . '</div><!-- /wp:group -->';
		$parsed_outer = self::parse_required_markup($outer_markup, 'installationguideouter');

		return ! empty($parsed_outer) ? $parsed_outer : array();
	}
	/**
	 * Format troubleshooting section standalone
	 *
	 * @MODIFIED 2026-03-26: Refactored to block arrays
	 */
	private function format_troubleshooting($issues, $post_id = 0)
	{
		if (empty($issues) || !is_array($issues)) {
			return array();
		}

		$content_hash = substr(md5(serialize($issues)), 0, 8);
		$content_id   = 'troubleshoot-content-' . ($post_id ?: $content_hash);
		$heading      = 'Show Common Issues';

		$inner_blocks = array();
		$list_html    = '<ul>';

		foreach ($issues as $issue) {
			if (is_string($issue) || is_numeric($issue) || is_bool($issue)) {
				$text = trim((string) $issue);
				if ($text === '') {
					continue;
				}

				$list_html .= '<li>' . wp_kses_post(self::process_markdown($text)) . '</li>';
				continue;
			}

			if (!is_array($issue)) {
				continue;
			}

			$issue_text    = isset($issue['issue']) ? trim((string) $issue['issue']) : '';
			$solution_text = isset($issue['solution']) ? trim((string) $issue['solution']) : '';

			if ($issue_text === '' && $solution_text === '') {
				continue;
			}

			// Process Markdown safely
			$clean_issue    = wp_kses_post(self::process_markdown($issue_text));
			$clean_solution = wp_kses_post(self::process_markdown($solution_text));

			// Strip <p> tags generated by Markdown so it doesn't break inline HTML structure inside <li> or <strong>
			$clean_issue    = preg_replace('/^<p>(.*?)<\/p>$/is', '$1', trim($clean_issue));
			$clean_solution = preg_replace('/^<p>(.*?)<\/p>$/is', '$1', trim($clean_solution));

			$li_html = '';

			// Defensive rendering: If AI crammed everything into the issue field (no solution), don't force-bold the whole thing.
			if ($clean_solution === '') {
				$li_html .= $clean_issue;
			} else {
				// If AI didn't already bold the issue text via markdown, we bold it here.
				if ($clean_issue !== '' && strpos($clean_issue, '<strong>') === false) {
					$li_html .= '<strong>' . $clean_issue . '</strong>';
				} else {
					$li_html .= $clean_issue;
				}
				
				if ($clean_solution !== '') {
					$li_html .= '<br>' . $clean_solution;
				}
			}

			$list_html .= '<li>' . $li_html . '</li>';
		}

		$list_html .= '</ul>';

		if ($list_html === '<ul></ul>') {
			return array();
		}

		$inner_blocks[] = self::make_block('core/list', array(), $list_html);

		$trigger_html  = '<div class="seo-gen-accordion-trigger" role="button" tabindex="0" aria-expanded="false" aria-controls="' . esc_attr($content_id) . '" data-target="' . esc_attr($content_id) . '">';
		$trigger_html .= esc_html($heading) . '<span class="accordion-icon" aria-hidden="true"></span>';
		$trigger_html .= '</div>';

		$blocks   = array();
		$blocks[] = self::make_block('core/html', array(), $trigger_html);

		// Content Container - use parse_block_markup
		$inner_html = serialize_blocks($inner_blocks);
		$group_markup = '<!-- wp:group {"anchor":"' . esc_attr($content_id) . '","className":"seo-gen-accordion-content"} -->'
			. '<div id="' . esc_attr($content_id) . '" class="wp-block-group seo-gen-accordion-content">' . $inner_html . '</div><!-- /wp:group -->';
		$parsed_group = self::parse_required_markup($group_markup, 'troubleshooting');
		if (!empty($parsed_group[0])) {
			$blocks[] = $parsed_group[0];
		}

		// Wrap in container - use parse_block_markup
		$outer_html = serialize_blocks($blocks);
		$outer_markup = '<!-- wp:group {"className":"seo-gen-accordion-block"} -->'
			. '<div class="wp-block-group seo-gen-accordion-block">' . $outer_html . '</div><!-- /wp:group -->';
		$parsed_outer = self::parse_required_markup($outer_markup, 'troubleshooting_outer');
		return !empty($parsed_outer) ? $parsed_outer : array();
	}
	/**
	 * Format editor rating
	 *
	 * @MODIFIED 2026-03-26: Refactored to block arrays
	 */
	private function format_editor_rating($rating)
	{
		$rating = floatval($rating);
		if ($rating < 1 || $rating > 5) {
			return array();
		}

		$full_stars  = floor($rating);
		$half_star   = ($rating - $full_stars) >= 0.5 ? 1 : 0;
		$empty_stars = 5 - $full_stars - $half_star;

		$rating_stars = '';
		for ($i = 0; $i < $full_stars; $i++) {
			$rating_stars .= '★';
		}
		if ($half_star) {
			$rating_stars .= '⯨';
		}
		for ($i = 0; $i < $empty_stars; $i++) {
			$rating_stars .= '☆';
		}

		$html = '<div class="seo-gen-editor-rating">' . "\n";
		$html .= '<strong>Editor Rating:</strong> ' . "\n";
		$html .= '<span class="stars">' . $rating_stars . '</span> ';
		$html .= '<span class="rating-number">' . esc_html(number_format($rating, 1)) . '/5</span>';
		$html .= '</div>';

		return array(
			self::make_block('core/html', array(), $html)
		);
	}
	/**
	 * Format related software card
	 *
	 * @MODIFIED 2026-03-26: Refactored to block arrays
	 */
	/**
	 * Format related software card.
	 *
	 * @MODIFIED 2026-03-26: Emits fully valid core/group block with wrapper HTML
	 */
	private function format_related_software($related)
	{
		if (empty($related)) {
			return array();
		}

		if (isset($related['name']) || isset($related['url']) || isset($related['title']) || isset($related['link'])) {
			$related = array($related);
		}

		if (!is_array($related)) {
			return array();
		}

		$cards = array();

		foreach ($related as $item) {
			if (!is_array($item)) {
				continue;
			}

			$name = isset($item['name']) ? trim((string) $item['name']) : trim((string) ($item['title'] ?? ''));
			$url  = isset($item['url']) ? trim((string) $item['url']) : trim((string) ($item['link'] ?? ''));

			if ($name === '' || $url === '') {
				continue;
			}

			$clean_name = $this->clean_software_display_name($name);

			$markup  = '<!-- wp:group {"className":"seo-gen-related-card"} -->';
			$markup .= '<div class="wp-block-group seo-gen-related-card">';
			$markup .= '<!-- wp:heading {"textAlign":"center","level":3,"className":"related-title"} -->';
			$markup .= '<h3 class="wp-block-heading has-text-align-center related-title">You May Like</h3>';
			$markup .= '<!-- /wp:heading -->';
			$markup .= '<!-- wp:paragraph {"align":"center","className":"related-content"} -->';
			$markup .= '<p class="has-text-align-center related-content"><a href="' . esc_url($url) . '" class="related-link" rel="nofollow">' . $clean_name . ' <span class="related-arrow">&nbsp;&rarr;</span></a></p>';
			$markup .= '<!-- /wp:paragraph -->';
			$markup .= '</div>';
			$markup .= '<!-- /wp:group -->';

			$parsed = self::parse_required_markup($markup, 'related_software');
			if (!empty($parsed)) {
				$cards = array_merge($cards, $parsed);
			}
		}

		return $cards;
	}
	/**
	 * Video Embed Block
	 *
	 * @MODIFIED 2026-03-26: Refactored to block arrays
	 */
	private function format_video_embed($video_url)
	{
		if (empty($video_url)) {
			return array();
		}

		// Validate URL
		$invalid_patterns = array(
			'/Placeholder/i', '/%20/', '/no%20clear/i', '/not%20found/i', '/\.\.\./',
			'/example\.com/i', '/placeholder/i', '/y-\d{2}-\d{2}/i', '/v\d+-\d+/i', 
			'/v\d+-[x\d]+/i', '/v23/i',
		);
		foreach ($invalid_patterns as $pattern) {
			if (preg_match($pattern, (string) $video_url)) {
				return array();
			}
		}

		$parsed_url = \wp_parse_url($video_url);
		$host       = $parsed_url['host'] ?? '';
		$provider_slug = 'youtube';
		$provider_class = ' is-provider-youtube wp-block-embed-youtube';
		
		if (strpos($host, 'vimeo.com') !== false) {
			$provider_slug = 'vimeo';
			$provider_class = ' is-provider-vimeo wp-block-embed-vimeo';
		} elseif (strpos($host, 'dailymotion.com') !== false) {
			$provider_slug = 'dailymotion';
			$provider_class = ' is-provider-dailymotion wp-block-embed-dailymotion';
		}

		// Normalize YouTube URLs (Safely catch optional http/https protocols to prevent double https://)
		if (strpos($video_url, 'youtube.com/embed/') !== false) {
			$video_url = preg_replace('/^(?:https?:\/\/)?(?:www\.)?youtube\.com\/embed\/([^?#\s]+).*/i', 'https://www.youtube.com/watch?v=$1', $video_url);
		} elseif (strpos($video_url, 'youtu.be/') !== false) {
			$video_url = preg_replace('/^(?:https?:\/\/)?(?:www\.)?youtu\.be\/([^?#\s]+).*/i', 'https://www.youtube.com/watch?v=$1', $video_url);
		}
		
		// Ultimate fallback safety net to strip accidental double protocols
		$video_url = str_replace('https://https://', 'https://', $video_url);

		$blocks = array();
		$blocks[] = self::heading_block('Video Tutorial', 2);

		$attrs = array(
			'url' => esc_url($video_url),
			'type' => 'video',
			'providerNameSlug' => $provider_slug,
			'responsive' => true,
			'className' => 'wp-embed-aspect-16-9 wp-has-aspect-ratio' . $provider_class,
		);

		$embed_html = '<figure class="wp-block-embed is-type-video wp-embed-aspect-16-9 wp-has-aspect-ratio' . $provider_class . '"><div class="wp-block-embed__wrapper">' . "\n";
		$embed_html .= esc_url($video_url) . "\n";
		$embed_html .= '</div></figure>';

		$blocks[] = self::make_block('core/embed', $attrs, $embed_html);

		return $blocks;
	}


	// @MODIFIED v2.0.9: Deleted inject_faq_schema() - Rank Math FAQ block handles FAQPage schema

	/**
	 * Clean version and date strings from software names for display.
	 * 
	 * @MODIFIED 2026-03-04: Robust name display for "You May Like" block.
	 *
	 * @param string $name Software name
	 * @return string Cleaned name
	 */
	private function clean_software_display_name($name)
	{
		// 1. Remove version patterns: 1.7.22822, v2.0, etc.
		$name = preg_replace('/\s+v?\d+(\.\d+)+/i', '', $name);

		// 2. Remove date patterns: (Mar 2026), (2026), 2026
		$name = preg_replace('/\s*\((?:(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+)?20\d{2}\)/i', '', $name);
		$name = preg_replace('/\s+20\d{2}$/', '', $name);
		return esc_html(trim($name));
	}

	/**
	 * Create a canonical Gutenberg block structure.
	 *
	 * @param string $name         Block name (e.g., core/paragraph)
	 * @param array  $attrs        Block attributes
	 * @param string $inner_html   Inner HTML content
	 * @param array  $inner_blocks Array of nested blocks
	 * @return array Block structure
	 */
	public static function make_block($name, $attrs = array(), $inner_html = '', $inner_blocks = array())
	{
		if (!empty($inner_blocks)) {
			trigger_error('Parent blocks must be created with parse_block_markup().', E_USER_DEPRECATED);
			return array();
		}

		return array(
			'blockName'   => $name,
			'attrs'       => $attrs,
			'innerBlocks' => array(),
			'innerHTML'   => $inner_html,
			'innerContent'=> array($inner_html),
		);
	}

	/**
	 * Create a core/heading block.
	 */
	public static function heading_block($text, $level = 2, $anchor = '')
	{
		$attrs = array('level' => $level);
		if ($anchor) {
			$attrs['anchor'] = $anchor;
		}
		$id_attr = $anchor ? ' id="' . esc_attr($anchor) . '"' : '';
		$tag     = 'h' . $level;
		$html    = '<' . $tag . ' class="wp-block-heading"' . $id_attr . '>' . wp_kses_post($text) . '</' . $tag . '>';

		return self::make_block('core/heading', $attrs, $html);
	}

	/**
	 * Create a core/paragraph block.
	 */
	public static function paragraph_block($content)
	{
		$html = '<p>' . wp_kses_post($content) . '</p>';
		return self::make_block('core/paragraph', array(), $html);
	}

	/**
	 * Parse raw HTML into blocks and extract them.
	 */
	public static function parse_block_markup($html)
	{
		if (empty($html)) {
			return array();
		}
		$blocks_data = (array) parse_blocks($html);
		if (empty($blocks_data)) {
			return array();
		}
		// Strip null blocks (whitespace/clutter)
		return array_values(array_filter($blocks_data, function ($b) {
			return ! empty($b['blockName']);
		}));
	}

	/**
	 * Parse markup with logging on failure for observability.
	 *
	 * @param string $html    Raw block markup.
	 * @param string $context Identifier for logging (e.g. 'whats_new', 'installation_guide').
	 * @return array Parsed blocks, or empty array with error_log on failure.
	 */
	private static function parse_required_markup($html, $context = 'unknown')
	{
		if (empty($html)) {
			if (defined('SEO_GEN_DEBUG_RENDER') && SEO_GEN_DEBUG_RENDER) {
				error_log("SEO_GEN: parse_required_markup({$context}) received empty markup.");
			}
			return array();
		}

		$blocks = self::parse_block_markup($html);

		if (empty($blocks)) {
			if (defined('SEO_GEN_DEBUG_RENDER') && SEO_GEN_DEBUG_RENDER) {
				error_log("SEO_GEN: parse_required_markup({{$context}}) returned 0 blocks from markup: " . substr($html, 0, 200));
			}
			return array();
		}

		return $blocks;
	}

	/**
	 * Recursively validate block tree structure.
	 *
	 * @param mixed $block
	 * @return bool
	 */
	private static function is_valid_block_tree($block): bool
	{
		if (!is_array($block)) {
			return false;
		}

		if (empty($block['blockName']) || !array_key_exists('innerBlocks', $block) || !array_key_exists('innerContent', $block)) {
			return false;
		}

		if (!is_array($block['innerBlocks']) || !is_array($block['innerContent'])) {
			return false;
		}

		foreach ($block['innerBlocks'] as $child) {
			if (!self::is_valid_block_tree($child)) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Filter array of blocks to only valid block trees.
	 *
	 * @param array $blocks
	 * @return array
	 */
	private static function filter_valid_block_trees(array $blocks): array
	{
		return array_values(array_filter($blocks, static function ($block) {
			return self::is_valid_block_tree($block);
		}));
	}

	/**
	 * Wrap blocks in a canonical seo-gen/section block.
	 */
	public static function zone_block($zone, array $inner_blocks): array
	{
		$zone = Article_Schema::get_canonical_key((string) $zone) ?: (string) $zone;

		if (empty($inner_blocks)) {
			return array();
		}

		$inner_html = serialize_blocks($inner_blocks);
		$markup = '<!-- wp:seo-gen/section ' . wp_json_encode(array('zone' => $zone), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . ' -->' . "\n"
			. $inner_html . "\n" .
			'<!-- /wp:seo-gen/section -->';

		return self::parse_block_markup($markup);
	}

	/**
	 * Render a zone's blocks directly (for standalone patching).
	 */
	public function render_zone_blocks($zone, $article_data, $post_id = 0)
	{
		$zone      = Article_Schema::get_canonical_key((string) $zone) ?: (string) $zone;
		$renderers = $this->get_section_renderers((array) $article_data, (int) $post_id);

		if (!isset($renderers[$zone]) || !is_callable($renderers[$zone])) {
			return array();
		}

		$section_blocks = self::filter_valid_block_trees((array) $renderers[$zone]());
		if (empty($section_blocks)) {
			return array();
		}

		// @MODIFIED 2026-04-03: Do NOT re-wrap in zone_block here.
		// Surgical_Patcher already wraps via zone_block() at line ~106.
		// Re-wrapping here causes double-zone-wrapper bug (Zone appears twice).
		// Exception: hero and toc zones need special handling elsewhere.
		if ($zone !== 'toc_placeholder' && $zone !== 'hero') {
			// Just return the inner blocks - Surgical_Patcher will wrap them
			return $section_blocks;
		}

		return $section_blocks;
	}

	/**
	 * Render a zone's HTML (proxies render_zone_blocks + serialize).
	 */
	public function render_zone_html($zone, $article_data, $post_id)
	{
		$blocks = self::filter_valid_block_trees($this->render_zone_blocks($zone, $article_data, $post_id));
		return empty($blocks) ? '' : serialize_blocks($blocks);
	}

	/**
	 * Prepend sentinel to HTML (Legacy path - maintained for partial compatibility)
	 *
	 * @deprecated 2026-04-03 Block-first architecture uses wp:seo-gen/section zone blocks.
	 *             This method emits the legacy Format B comment sentinel which is only
	 *             understood by Sentinel_Injector::upgrade_comment_format() during backfill.
	 *             Do NOT call this on any content that will be stored to post_content.
	 *
	 * @param string $zone Zone ID
	 * @param string $html HTML content
	 * @return string Content with sentinel
	 */
	private function prepend_zone_sentinel($zone, $html)
	{
		trigger_error(
			'Content_Formatter::prepend_zone_sentinel() is deprecated. Use Content_Formatter::zone_block() instead.',
			E_USER_DEPRECATED
		);

if (empty($html)) {
            return '';
        }
        // Guard: never inject legacy comment if block-format zone already present
        if (strpos($html, 'data-seo-gen-zone') !== false || strpos($html, 'seo-gen/section') !== false) {
            return $html;
        }
        return "<!-- seo-gen-zone:{$zone} -->\n" . $html;
	}
}
