<?php

namespace SEO_Article_Generator\Tests\Fakes;

/**
 * Spy Validator for testing
 */
class Spy_Validator extends \SEO_Article_Generator\Validation\Validator
{
    public $last_validated_article = null;

    public function __construct()
    {
        // Bypass parent constructor
    }

    public function validate($article_data, $input_data = array())
    {
        $this->last_validated_article = $article_data;
        return array(
            'score'  => 100,
            'passed' => true,
            'errors' => array()
        );
    }
}
