<?php
$_tests_dir = getenv( 'WP_TESTS_DIR' ) ?: rtrim( sys_get_temp_dir(), '/\\' ) . '/wordpress-tests-lib';

if ( file_exists( $_tests_dir . '/includes/functions.php' ) ) {
	require_once $_tests_dir . '/includes/functions.php';
} else {
	// Fallback: mock WordPress functions for pure unit testing without WP test lib.
	if ( ! function_exists( 'add_action' ) ) {
		function add_action() {}
	}
	if ( ! function_exists( 'add_filter' ) ) {
		function add_filter() {}
	}
	if ( ! function_exists( 'get_option' ) ) {
		function get_option( $key, $default = false ) {
			return $default;
		}
	}
	if ( ! function_exists( 'set_transient' ) ) {
		function set_transient() {
			return true;
		}
	}
	if ( ! function_exists( 'get_transient' ) ) {
		function get_transient() {
			return false;
		}
	}
	if ( ! function_exists( 'sanitize_text_field' ) ) {
		function sanitize_text_field( $str ) {
			return strip_tags( stripslashes( trim( $str ) ) );
		}
	}
	if ( ! function_exists( 'sanitize_key' ) ) {
		function sanitize_key( $str ) {
			return preg_replace( '/[^a-zA-Z0-9_\-]/', '', strtolower( $str ) );
		}
	}
	if ( ! function_exists( 'wp_kses_post' ) ) {
		function wp_kses_post( $html ) {
			return strip_tags( $html, '<p><a><strong><em><br><ul><ol><li><h1><h2><h3><h4><h5><h6><blockquote><img><figure><figcaption><div><span>' );
		}
	}
	if ( ! function_exists( 'wp_unslash' ) ) {
		function wp_unslash( $value ) {
			return is_string( $value ) ? stripslashes( $value ) : $value;
		}
	}
	if ( ! function_exists( 'wp_strip_all_tags' ) ) {
		function wp_strip_all_tags( $str ) {
			return strip_tags( $str );
		}
	}
	if ( ! function_exists( 'sanitize_title' ) ) {
		function sanitize_title( $str ) {
			return strtolower( preg_replace( '/[^a-zA-Z0-9\-]/', '-', $str ) );
		}
	}
	if ( ! function_exists( 'sanitize_textarea_field' ) ) {
		function sanitize_textarea_field( $str ) {
			return sanitize_text_field( $str );
		}
	}
	if ( ! function_exists( 'maybe_serialize' ) ) {
		function maybe_serialize( $data ) {
			return is_scalar( $data ) ? $data : serialize( $data );
		}
	}
	if ( ! function_exists( 'current_time' ) ) {
		function current_time( $type = 'mysql' ) {
			return $type === 'mysql' ? date( 'Y-m-d H:i:s' ) : time();
		}
	}
	if ( ! function_exists( 'wp_json_encode' ) ) {
		function wp_json_encode( $data ) {
			return json_encode( $data, JSON_UNESCAPED_UNICODE );
		}
	}
	if ( ! function_exists( 'esc_html' ) ) {
		function esc_html( $str ) {
			return htmlspecialchars( $str, ENT_QUOTES, 'UTF-8' );
		}
	}
	if ( ! function_exists( 'esc_attr' ) ) {
		function esc_attr( $str ) {
			return htmlspecialchars( $str, ENT_QUOTES, 'UTF-8' );
		}
	}
	if ( ! function_exists( 'esc_url' ) ) {
		function esc_url( $str ) {
			return filter_var( $str, FILTER_SANITIZE_URL );
		}
	}
	if ( ! function_exists( 'check_ajax_referer' ) ) {
		function check_ajax_referer() {
			return true;
		}
	}
	if ( ! function_exists( 'current_user_can' ) ) {
		function current_user_can() {
			return true;
		}
	}
	if ( ! function_exists( 'wp_send_json_error' ) ) {
		function wp_send_json_error( $data ) {
			throw new \RuntimeException( 'wp_send_json_error: ' . json_encode( $data ) );
		}
	}
	if ( ! function_exists( 'wp_send_json_success' ) ) {
		function wp_send_json_success( $data ) {}
	}
	if ( ! function_exists( 'as_enqueue_async_action' ) ) {
		function as_enqueue_async_action() {}
	}
	if ( ! function_exists( 'as_next_scheduled_action' ) ) {
		function as_next_scheduled_action() {
			return false;
		}
	}
	if ( ! function_exists( 'as_schedule_recurring_action' ) ) {
		function as_schedule_recurring_action() {}
	}
	if ( ! function_exists( 'wp_remote_post' ) ) {
		function wp_remote_post() {
			return new WP_Error( 'http_error', 'HTTP transport not available in unit tests.' );
		}
	}
	if ( ! class_exists( 'WP_Error' ) ) {
		class WP_Error {
			public $errors = [];
			public function __construct( $code = '', $msg = '' ) {
				$this->errors[ $code ][] = $msg;
			}
			public function get_error_message() {
				foreach ( $this->errors as $msgs ) {
					return $msgs[0] ?? '';
				}
				return '';
			}
		}
	}
	if ( ! function_exists( 'is_wp_error' ) ) {
		function is_wp_error( $thing ) {
			return $thing instanceof WP_Error;
		}
	}
	if ( ! function_exists( 'wp_remote_retrieve_response_code' ) ) {
		function wp_remote_retrieve_response_code() {
			return 0;
		}
	}
	if ( ! function_exists( 'wp_remote_retrieve_body' ) ) {
		function wp_remote_retrieve_body() {
			return '';
		}
	}
}

require_once __DIR__ . '/../vendor/autoload.php';
