<?php

/**
 * Taxonomy Template for 'topic'
 * @version 2.0 - Hardened with XSS Prevention & Caching
 *
 * @MODIFIED: Added esc_html(), esc_url(), and esc_attr() to all dynamic output.
 * @MODIFIED: Cached database queries for stats, months, and related topics.
 * @MODIFIED: Used wp_kses_post() for topic description.
 */

if (!defined('ABSPATH')) exit;

$current_topic = get_queried_object();
global $wpdb;

// ===================================================================
// START CACHING LOGIC
// ===================================================================
$cache_version = class_exists('NM_Cache_Manager') ? NM_Cache_Manager::get_topic_cache_version() : 1;
$cache_expiration = 6 * HOUR_IN_SECONDS; // 6 hours
$term_id = $current_topic->term_id;
$parent_id = $current_topic->parent;
$slug = $current_topic->slug;

// --- 1. Cache: Available Months (SECURED) ---
$months_cache_key = 'nm_topic_months_v' . $cache_version . '_' . absint($term_id);
$available_months = get_transient($months_cache_key);
if ($available_months === false) {
    $available_months = $wpdb->get_results($wpdb->prepare(
        "SELECT DISTINCT YEAR(p.post_date) AS year, MONTH(p.post_date) AS month
        FROM {$wpdb->posts} p
        INNER JOIN {$wpdb->term_relationships} tr ON p.ID = tr.object_id
        INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id
        WHERE tt.term_id = %d
        AND p.post_type = %s
        AND p.post_status = %s
        ORDER BY year DESC, month DESC",
        absint($term_id),
        'mcq',
        'publish'
    ));

    if ($available_months && !is_wp_error($available_months)) {
        set_transient($months_cache_key, $available_months, $cache_expiration);
    } else {
        $available_months = [];
    }
}
// --- 2. Cache: Topic Stats (OPTIMIZED & SECURED) ---
$stats_cache_key = 'nm_topic_stats_v' . $cache_version . '_' . absint($term_id);
$stats = NM_Cache_Manager::get($stats_cache_key); // ✅ Use NM_Cache_Manager
if ($stats === false) {
    $total_count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(DISTINCT p.ID)
        FROM {$wpdb->posts} p
        INNER JOIN {$wpdb->term_relationships} tr ON p.ID = tr.object_id
        INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id
        WHERE tt.term_id = %d
        AND p.post_type = %s
        AND p.post_status = %s",
        absint($term_id),
        'mcq',
        'publish'
    ));

    // ✅ START FIX: Cache global topic count separately
    $global_topic_count = NM_Cache_Manager::get('nm_global_topic_count');
    if ($global_topic_count === false) {
        $global_topic_count = wp_count_terms('topic', ['hide_empty' => true]);
        NM_Cache_Manager::set('nm_global_topic_count', $global_topic_count, 6 * HOUR_IN_SECONDS);
    }

    // ✅ END FIX

    $stats = [
        'total' => (int) $total_count,
        'topics' => (int) $global_topic_count
    ];

    if (!$wpdb->last_error) {
        NM_Cache_Manager::set($stats_cache_key, $stats, $cache_expiration); // ✅ Use NM_Cache_Manager
    } else {
        error_log('[Taxonomy-Topic] SQL Error in stats query: ' . $wpdb->last_error);
        $stats = ['total' => 0, 'topics' => 0];
    }
}

// --- 3. Cache: Initial 10 MCQs (for SEO) ---
$mcqs_cache_key = 'nm_topic_initial_mcqs_v' . $cache_version . '_' . $slug;
$mcqs_data = NM_Cache_Manager::get($mcqs_cache_key); // ✅ Use NM_Cache_Manager
if ($mcqs_data === false) {
    if (class_exists('NM_AJAX_Frontend') && method_exists('NM_AJAX_Frontend', 'nm_get_mcqs')) {
        $mcqs_data = NM_AJAX_Frontend::nm_get_mcqs([
            'count' => 10,
            'topic' => $slug,
            'month' => 'all' // Default to all
        ]);
    } else {
        $mcqs_data = [];
        error_log('[MCQ Template] Error: NM_AJAX_Frontend::nm_get_mcqs() not found.');
    }
    NM_Cache_Manager::set($mcqs_cache_key, $mcqs_data, $cache_expiration); // ✅ Use NM_Cache_Manager
}
// ===================================================================
// END CACHING LOGIC
// ===================================================================

$nm_mcq_nonce = wp_create_nonce('nm_load_more_nonce');
get_header();

$is_astra = function_exists('astra_page_layout');
?>
<?php if ($is_astra) : ?>
    <div id="primary" <?php astra_primary_class(); ?>>
        <?php astra_primary_content_top(); ?>
    <?php endif; ?>

    <div class="nm-custom-breadcrumb">
        <a href="<?php echo esc_url(home_url()); ?>">🏠 Home</a>
        <span class="separator">›</span>
        <a href="<?php echo esc_url(get_post_type_archive_link('mcq')); ?>">MCQs</a>
        <span class="separator">›</span>
        <span class="current"><?php echo esc_html($current_topic->name); ?></span>
    </div>

    <div class="nm-topic-wrap">

        <div class="nm-topic-stats-header">
            <h1><?php echo esc_html($current_topic->name); ?> MCQs</h1>

            <?php if ($current_topic->description) : ?>
                <div class="nm-topic-description">
                    <?php
                    $description = wp_kses_post($current_topic->description);
                    $description = preg_replace('/<\/?h[1-6][^>]*>/', '', $description);
                    $topic_name = preg_quote($current_topic->name, '/');
                    $description = preg_replace('/^\s*\b' . $topic_name . '\s+MCQs?\b[:\s]*/i', '', $description);
                    $description = preg_replace('/^Explore\s+(global\s+)?/i', '', $description);
                    $description = preg_replace('/\s+/', ' ', $description);
                    $description = trim($description);

                    if (empty($description)) {
                        echo 'Test your knowledge with our comprehensive collection of ' . esc_html($current_topic->name) . ' questions.';
                    } else {
                        echo $description; // Already safe from wp_kses_post
                    }
                    ?>
                </div>
            <?php else : ?>
                <div class="nm-topic-description">
                    Test your knowledge with our comprehensive collection of <?php echo esc_html($current_topic->name); ?> questions.
                </div>
            <?php endif; ?>

            <div class="nm-stats-grid">
                <div class="nm-stat-box">
                    <span class="nm-stat-number"><?php echo (int) $stats['total']; ?></span>
                    <span class="nm-stat-label">Total Questions</span>
                </div>
                <div class="nm-stat-box">
                    <span class="nm-stat-number"><?php echo (int) $stats['topics']; ?></span>
                    <span class="nm-stat-label">Topics Available</span>
                </div>
            </div>

            <p>🔄 Updated daily | 📱 Mobile-friendly | 🎯 Exam-focused</p>
        </div>

        <?php
        // @NEW 9.4.0: "Full Topic Guide" card — links to the evergreen pillar post for this
        // topic (standalone indexable article). Prominent internal linking hub ↔ pillar.
        $pillar_id = 0;
        if (class_exists('NM_Topic_Pillar_Generator')) {
            $pillar_id = NM_Topic_Pillar_Generator::get_latest_pillar($term_id);
        }
        if ($pillar_id && get_post_status($pillar_id) === 'publish') :
            $pillar_ex = get_the_excerpt($pillar_id);
        ?>
            <div style="margin:20px 0;padding:20px 22px;background:linear-gradient(135deg,#f0f6fc 0%,#e8effc 100%);border:1px solid #c9d8f0;border-left:5px solid #667eea;border-radius:8px;">
                <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:16px;flex-wrap:wrap;">
                    <div style="flex:1;min-width:220px;">
                        <span style="display:inline-block;background:#667eea;color:#fff;font-size:11px;font-weight:700;letter-spacing:.5px;text-transform:uppercase;padding:3px 10px;border-radius:20px;margin-bottom:8px;">📖 Full Topic Guide</span>
                        <h2 style="margin:0 0 6px;font-size:20px;line-height:1.3;">
                            <a href="<?php echo esc_url(get_permalink($pillar_id)); ?>" style="text-decoration:none;color:inherit;"><?php echo esc_html(get_the_title($pillar_id)); ?></a>
                        </h2>
                        <?php if ($pillar_ex) : ?>
                            <p style="margin:0;font-size:.95em;opacity:.8;"><?php echo esc_html(wp_trim_words($pillar_ex, 24)); ?></p>
                        <?php endif; ?>
                    </div>
                    <a href="<?php echo esc_url(get_permalink($pillar_id)); ?>" style="flex-shrink:0;background:#667eea;color:#fff;text-decoration:none;padding:10px 18px;border-radius:6px;font-weight:600;align-self:center;">
                        Read the Full Guide →
                    </a>
                </div>
            </div>
        <?php endif; ?>

        <?php
        // @NEW 9.2.0: Latest News section on the topic hub — lists recent roundup
        // articles tagged with this topic, linking hub ↔ article (SEO internal linking).
        // Posts get the 'topic' taxonomy too (registered for both 'mcq' and 'post').
        $hub_articles = get_posts(
            array(
                'post_type'      => 'post',
                'post_status'    => 'publish',
                'posts_per_page' => 4,
                'orderby'        => 'date',
                'order'          => 'DESC',
                'tax_query'      => array(
                    array(
                        'taxonomy' => 'topic',
                        'field'    => 'term_id',
                        'terms'    => $term_id,
                    ),
                ),
            )
        );
        if (! empty($hub_articles)) :
        ?>
            <div class="nm-topic-latest-news" style="margin:20px 0;padding:16px;background:rgba(255,255,255,.04);border-left:4px solid #c4302b;border-radius:6px;">
                <h3 style="margin:0 0 12px;">📰 Latest <?php echo esc_html($current_topic->name); ?> News</h3>
                <ul style="list-style:none;margin:0;padding:0;">
                    <?php foreach ($hub_articles as $ha) : ?>
                        <li style="margin-bottom:10px;">
                            <a href="<?php echo esc_url(get_permalink($ha->ID)); ?>" style="text-decoration:none;font-weight:600;">
                                <?php echo esc_html(get_the_title($ha->ID)); ?>
                            </a>
                            <?php $ha_ex = get_the_excerpt($ha->ID); if ($ha_ex) : ?>
                                <p style="margin:3px 0 0;font-size:.9em;color:inherit;opacity:.75;">
                                    <?php echo esc_html(wp_trim_words($ha_ex, 16)); ?>
                                </p>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="nm-topic-nav-premium">
            <?php
            $current_term_id = $current_topic->term_id;

            if ($parent_id != 0) {
                $parent_term = get_term($parent_id, 'topic');
                if ($parent_term && !is_wp_error($parent_term)) {
            ?>
                    <div class="nm-topic-breadcrumb">
                        <a href="<?php echo esc_url(get_term_link($parent_term)); ?>" class="nm-parent-link">
                            <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M10 12L6 8L10 4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                            </svg>
                            Back to <?php echo esc_html($parent_term->name); ?>
                        </a>
                    </div>
                    <?php

                    // --- 4. Cache: Sibling Topics (SECURED) ---
                    $siblings_cache_key = 'nm_topic_siblings_v' . $cache_version . '_' . absint($parent_id);
                    $siblings = NM_Cache_Manager::get($siblings_cache_key); // ✅ Use NM_Cache_Manager
                    if ($siblings === false) {
                        $siblings = get_terms([
                            'taxonomy' => 'topic',
                            'hide_empty' => true,
                            'parent' => $parent_id,
                            'exclude' => [$current_term_id],
                            'orderby' => 'name',
                            'order' => 'ASC',
                            'number' => 10
                        ]);
                        NM_Cache_Manager::set($siblings_cache_key, $siblings, $cache_expiration); // ✅ Use NM_Cache_Manager
                    }

                    if (!empty($siblings) && !is_wp_error($siblings)) {
                    ?>
                        <div class="nm-related-topics-section">
                            <h3 class="nm-section-title">Related Topics</h3>
                            <div class="nm-topics-pills">
                                <?php foreach ($siblings as $sibling) { ?>
                                    <a href="<?php echo esc_url(get_term_link($sibling)); ?>" class="nm-topic-pill">
                                        <?php echo esc_html($sibling->name); ?>
                                        <span class="nm-pill-count"><?php echo (int) $sibling->count; ?></span>
                                    </a>
                                <?php } ?>
                            </div>
                        </div>
                <?php
                    }
                }
            }

            // --- 5. Cache: Child Topics (SECURED) ---
            $children_cache_key = 'nm_topic_children_v' . $cache_version . '_' . absint($current_term_id);
            $children = NM_Cache_Manager::get($children_cache_key); // ✅ Use NM_Cache_Manager
            if ($children === false) {
                $children = get_terms([
                    'taxonomy' => 'topic',
                    'hide_empty' => true,
                    'parent' => $current_term_id,
                    'orderby' => 'count',
                    'order' => 'DESC'
                ]);
                NM_Cache_Manager::set($children_cache_key, $children, $cache_expiration); // ✅ Use NM_Cache_Manager
            }

            if (!empty($children) && !is_wp_error($children)) {
                ?>
                <div class="nm-subtopics-section">
                    <h3 class="nm-section-title">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M2.5 5.83333C2.5 5.3731 2.8731 5 3.33333 5H6.66667C7.1269 5 7.5 5.3731 7.5 5.83333V9.16667C7.5 9.6269 7.1269 10 6.66667 10H3.33333C2.8731 10 2.5 9.6269 2.5 9.16667V5.83333Z" stroke="currentColor" stroke-width="1.5" />
                            <path d="M2.5 13.3333C2.5 12.8731 2.8731 12.5 3.33333 12.5H6.66667C7.1269 12.5 7.5 12.8731 7.5 13.3333V16.6667C7.5 17.1269 7.1269 17.5 6.66667 17.5H3.33333C2.8731 17.5 2.5 17.1269 2.5 16.6667V13.3333Z" stroke="currentColor" stroke-width="1.5" />
                            <path d="M10 5.83333C10 5.3731 10.3731 5 10.8333 5H14.1667C14.6269 5 15 5.3731 15 5.83333V9.16667C15 9.6269 14.6269 10 14.1667 10H10.8333C10.3731 10 10 9.6269 10 9.16667V5.83333Z" stroke="currentColor" stroke-width="1.5" />
                            <path d="M10 13.3333C10 12.8731 10.3731 12.5 10.8333 12.5H14.1667C14.6269 12.5 15 12.8731 15 13.3333V16.6667C15 17.1269 14.6269 17.5 14.1667 17.5H10.8333C10.3731 17.5 15 17.1269 10 16.6667V13.3333Z" stroke="currentColor" stroke-width="1.5" />
                        </svg>
                        Explore <?php echo esc_html($current_topic->name); ?> Subtopics
                    </h3>
                    <div class="nm-subtopics-grid">
                        <?php foreach ($children as $child) { ?>
                            <a href="<?php echo esc_url(get_term_link($child)); ?>" class="nm-subtopic-card">
                                <div class="nm-card-icon">📁</div>
                                <div class="nm-card-content">
                                    <h4 class="nm-card-title"><?php echo esc_html($child->name); ?></h4>
                                    <p class="nm-card-meta"><?php echo (int) $child->count; ?> MCQ<?php echo $child->count != 1 ? 's' : ''; ?></p>
                                </div>
                                <div class="nm-card-arrow">→</div>
                            </a>
                        <?php } ?>
                    </div>
                </div>
                <?php
            }

            if ($parent_id == 0 && empty($children)) {
                // --- 6. Cache: Popular Topics (SECURED) ---
                $popular_cache_key = 'nm_topic_popular_v' . $cache_version . '_' . absint($current_term_id);
                $popular_topics = NM_Cache_Manager::get($popular_cache_key); // ✅ Use NM_Cache_Manager
                if ($popular_topics === false) {
                    $popular_topics = get_terms([
                        'taxonomy' => 'topic',
                        'hide_empty' => true,
                        'parent' => 0,
                        'exclude' => [$current_term_id],
                        'orderby' => 'count',
                        'order' => 'DESC',
                        'number' => 8
                    ]);
                    NM_Cache_Manager::set($popular_cache_key, $popular_topics, $cache_expiration); // ✅ Use NM_Cache_Manager
                }

                if (!empty($popular_topics) && !is_wp_error($popular_topics)) {
                ?>
                    <div class="nm-related-topics-section">
                        <h3 class="nm-section-title">Other Popular Topics</h3>
                        <div class="nm-topics-pills">
                            <?php foreach ($popular_topics as $topic) { ?>
                                <a href="<?php echo esc_url(get_term_link($topic)); ?>" class="nm-topic-pill">
                                    <?php echo esc_html($topic->name); ?>
                                    <span class="nm-pill-count"><?php echo (int) $topic->count; ?></span>
                                </a>
                            <?php } ?>
                        </div>
                    </div>
            <?php
                }
            }
            ?>
        </div>

        <div class="nm-quiz-section">
            <div class="nm-quiz-intro">
                <h3>🧠 Interactive Daily Quiz</h3>
                <p>New questions added automatically. Select an answer for immediate feedback and explanations.</p>
            </div>
            <?php if (!empty($available_months)) : ?>
                <div class="nm-filter-controls">
                    <label for="nm-month-filter">Filter by Month:</label>
                    <select id="nm-month-filter">
                        <option value="all">All Time (Default)</option>
                        <?php foreach ($available_months as $month) : ?>
                            <?php
                            $month_value = sprintf('%d-%02d', $month->year, $month->month);
                            $month_name = date('F Y', mktime(0, 0, 0, $month->month, 1, $month->year));
                            ?>
                            <option value="<?php echo esc_attr($month_value); ?>">
                                <?php echo esc_html($month_name); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            <?php endif; ?>
            <div id="nm-mcq-app">
                <?php
                // Build [display_mcqs] shortcode dynamically for Topic and Exam archives
                $term      = get_queried_object();
                $shortcode = '[display_mcqs count="10"';

                if ($term && ! is_wp_error($term)) {
                    if ('topic' === $term->taxonomy) {
                        $shortcode .= ' topic="' . esc_attr($term->slug) . '"';
                    } elseif ('nm_exam' === $term->taxonomy) {
                        $shortcode .= ' exam="' . esc_attr($term->slug) . '"';
                    } elseif ('mcq_tag' === $term->taxonomy) {
                        $shortcode .= ' tag="' . esc_attr($term->slug) . '"';
                    }
                }

                $shortcode .= ']';

                echo do_shortcode($shortcode);
                ?>
            </div>
        </div> <!-- .nm-quiz-section -->
        <div class="nm-content-section">
            <h2>✅ Why Practice with Our MCQs?</h2>
            <ul>
                <li><strong>Always Current:</strong> Questions generated from today's top news headlines</li>
                <li><strong>Exam-Focused:</strong> Perfect for competitive exams' current affairs sections</li>
                <li><strong>Build Confidence:</strong> Regular practice helps identify weak areas</li>
                <li><strong>Quick & Convenient:</strong> Practice anytime, anywhere on any device</li>
                <li><strong>Instant Feedback:</strong> Get immediate results with detailed explanations</li>
            </ul>
        </div>

        <?php
        if (function_exists('get_field')) {
            $topics_content = get_field('topics_we_cover_content', $current_topic);
            if ($topics_content) :
        ?>
                <div class="nm-content-section">
                    <h2>📚 Topics We Cover</h2>
                    <?php echo wp_kses_post($topics_content); ?>
                </div>
        <?php
            endif;
        }
        ?>

        <?php
        if ($parent_id == 0 && empty($children) && !empty($popular_topics) && !is_wp_error($popular_topics)) :
        ?>
            <div class="nm-related-topics">
                <h2>📚 Practice More Topics</h2>
                <div class="nm-topics-grid">
                    <?php foreach ($popular_topics as $topic) : ?>
                        <a href="<?php echo esc_url(get_term_link($topic)); ?>" class="nm-topic-card">
                            <div class="nm-topic-card-title"><?php echo esc_html($topic->name); ?></div>
                            <div class="nm-topic-card-count"><?php echo (int) $topic->count; ?> Questions →</div>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <div class="nm-content-section">
            <h2>❓ Frequently Asked Questions</h2>
            <h4>How often are the MCQs updated?</h4>
            <p>Our quiz is updated multiple times daily with new questions from current events.</p>
            <h4>Where are these questions sourced from?</h4>
            <p>Questions are curated from reputable news outlets, focusing on factual information relevant for competitive exams.</p>
            <h4>Can I practice on mobile devices?</h4>
            <p>Absolutely! Our platform is fully responsive and works seamlessly on all devices.</p>
        </div>

    </div>
    <?php if ($is_astra): ?>
        <?php astra_primary_content_bottom(); ?>
    </div><?php if (astra_page_layout() === 'right-sidebar'): ?>
        <?php get_sidebar(); ?>
    <?php endif; ?>
<?php endif; ?>

<?php get_footer(); ?>