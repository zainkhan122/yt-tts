// scheduler.js — Background auto-share scheduler (v18.7 cache-bust)
// Uses the EXACT same flow as the manual Multi-Group button:
// 1. Click Share on a post → 2. Click "Group" → 3. Auto-select groups → 4. Share

const ALARM_NAME = 'autoShareCheck';
const ALARM_PERIOD_MINUTES = 1;

let schedulerActive = false;

function getConfig() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['autoShareConfig'], (result) => {
      resolve(result.autoShareConfig || getDefaultConfig());
    });
  });
}

function getDefaultConfig() {
  return {
    enabled: false,
    timeStart: '15:00',
    timeEnd: '23:00',
    fbPageUrl: '',
    groupsPerPost: 5,
    delayMin: 10,
    delayMax: 20,
    lastPostTime: null
  };
}

function saveConfig(config) {
  return new Promise((resolve) => {
    chrome.storage.local.set({ autoShareConfig: config }, resolve);
  });
}

function isInTimeWindow(config) {
  const now = new Date();
  const [startH, startM] = config.timeStart.split(':').map(Number);
  const [endH, endM] = config.timeEnd.split(':').map(Number);
  
  const start = new Date(now);
  start.setHours(startH, startM, 0, 0);
  
  const end = new Date(now);
  end.setHours(endH, endM, 0, 0);
  
  if (end <= start) {
    end.setDate(end.getDate() + 1);
    if (now < start) now.setDate(now.getDate() + 1);
  }
  
  return now >= start && now <= end;
}

function getActiveFacebookTab() {
  return new Promise((resolve) => {
    // Prefer a facebook tab that is currently active/focused...
    chrome.tabs.query({ url: ['*://*.facebook.com/*', '*://facebook.com/*'], active: true, currentWindow: true }, (activeTabs) => {
      if (activeTabs.length) { resolve(activeTabs[0]); return; }
      // ...otherwise any facebook tab (auto-share may run while another window is focused)
      chrome.tabs.query({ url: ['*://*.facebook.com/*', '*://facebook.com/*'] }, (anyTabs) => {
        resolve(anyTabs[0] || null);
      });
    });
  });
}

async function ensureContentScriptsInjected(tabId) {
  const scripts = [
    "expired_overlay.js",
    "content_core.js",
    "content_ui_progress.js",
    "content_ui_modals.js",
    "content_ui_elements.js",
    "content_main.js"
  ];
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: scripts });
    return true;
  } catch (err) {
    console.warn('Failed to inject content scripts:', err.message);
    return false;
  }
}

async function triggerAutoShare(tabId, groupsPerPost) {
  return new Promise((resolve) => {
    try {
      chrome.tabs.sendMessage(tabId, {
        type: 'auto_share_from_page',
        groupsPerPost
      }, (response) => {
        if (chrome.runtime.lastError) {
          resolve({ success: false, message: chrome.runtime.lastError.message });
        } else if (!response) {
          resolve({ success: false, message: 'No response from page' });
        } else {
          resolve({ success: !!response.success, message: String(response.message || '') });
        }
      });
    } catch (e) {
      resolve({ success: false, message: e.message });
    }
  });
}

async function runAutoShareCycle() {
  try {
    const config = await getConfig();
    
    if (!config.enabled) return;
    if (!isInTimeWindow(config)) return;
    
    const now = Date.now();
    const randomDelayMs = (config.delayMin + Math.random() * (config.delayMax - config.delayMin)) * 60 * 1000;
    if (config.lastPostTime && (now - config.lastPostTime) < randomDelayMs) return;
    
    const tab = await getActiveFacebookTab();
    if (!tab) {
      console.log('Auto-share: No active Facebook tab found');
      return;
    }
    
    await ensureContentScriptsInjected(tab.id);
    await new Promise(r => setTimeout(r, 1000));
    
    console.log(`Auto-share: Running on "${tab.title}"`);
    
    const result = await triggerAutoShare(tab.id, config.groupsPerPost || 5);
    const msg = (result && result.message) ? String(result.message) : 'Unknown result';
    const ok = !!(result && result.success);

    if (ok) {
      console.log(`✅ Auto-share: ${msg}`);
      await saveConfig({ ...config, lastPostTime: Date.now() });
    } else {
      console.log(`Auto-share: ${msg}`);
    }
  } catch (err) {
    console.error('Auto-share cycle error (non-fatal):', err && err.message);
  }
}

export async function startAutoShareScheduler() {
  if (schedulerActive) return;
  console.log('Starting auto-share scheduler...');
  schedulerActive = true;
  await chrome.alarms.create(ALARM_NAME, { periodInMinutes: ALARM_PERIOD_MINUTES });
  runAutoShareCycle().catch(console.error);
}

export async function stopAutoShareScheduler() {
  if (!schedulerActive) return;
  console.log('Stopping auto-share scheduler...');
  schedulerActive = false;
  await chrome.alarms.clear(ALARM_NAME);
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_NAME) {
    runAutoShareCycle().catch(console.error);
  }
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.autoShareConfig) {
    console.log('Auto-share config changed');
  }
});
