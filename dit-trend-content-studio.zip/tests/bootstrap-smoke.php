<?php

declare(strict_types=1);

if (!defined('ABSPATH')) {
    define('ABSPATH', dirname(__DIR__) . '/');
}

// Load composer autoloader
if (file_exists(dirname(__DIR__) . '/vendor/autoload.php')) {
    require_once dirname(__DIR__) . '/vendor/autoload.php';
}

/*
|--------------------------------------------------------------------------
| Minimal WordPress function shims for smoke tests
|--------------------------------------------------------------------------
*/

if (!function_exists('wp_json_encode')) {
    function wp_json_encode($value, int $flags = 0, int $depth = 512)
    {
        return json_encode($value, $flags, $depth);
    }
}

if (!function_exists('wp_strip_all_tags')) {
    function wp_strip_all_tags($text, bool $remove_breaks = false)
    {
        $text = strip_tags((string) $text);
        if ($remove_breaks) {
            $text = preg_replace('/[\r\n\t ]+/', ' ', $text);
        }
        return trim((string) $text);
    }
}

if (!function_exists('esc_attr')) {
    function esc_attr($text)
    {
        return htmlspecialchars((string) $text, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('get_option')) {
    function get_option($key, $default = false)
    {
        return $default;
    }
}

if (!function_exists('home_url')) {
    function home_url($path = '')
    {
        return 'https://example.com/' . ltrim($path, '/');
    }
}

if (!function_exists('site_url')) {
    function site_url($path = '')
    {
        return 'https://example.com/' . ltrim($path, '/');
    }
}

if (!function_exists('attachment_url_to_postid')) {
    function attachment_url_to_postid($url)
    {
        return 0;
    }
}

if (!function_exists('wp_upload_dir')) {
    function wp_upload_dir()
    {
        return [
            'path' => '/tmp',
            'url' => 'https://example.com/wp-content/uploads',
            'subdir' => '',
            'basedir' => '/tmp',
            'baseurl' => 'https://example.com/wp-content/uploads',
            'error' => false,
        ];
    }
}

if (!function_exists('apply_filters')) {
    function apply_filters($tag, $value)
    {
        return $value;
    }
}

if (!function_exists('esc_url')) {
    function esc_url($url)
    {
        return $url;
    }
}

if (!function_exists('wp_unslash')) {
    function wp_unslash($data)
    {
        return $data;
    }
}

if (!function_exists('esc_html')) {
    function esc_html($text)
    {
        return htmlspecialchars((string) $text, ENT_QUOTES, 'UTF-8');
    }
}

/*
|--------------------------------------------------------------------------
| Load production classes under test (Custom Autoloader)
|--------------------------------------------------------------------------
*/
spl_autoload_register(function ($class) {
    $prefix = 'DIT\\TrendStudio\\';
    $base_dir = dirname(__DIR__) . '/src/';

    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    $relative_class = substr($class, $len);
    $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';

    if (file_exists($file)) {
        require $file;
    }
});

/*
|--------------------------------------------------------------------------
| Load fakes
|--------------------------------------------------------------------------
*/
foreach (glob(__DIR__ . '/Fakes/*.php') as $filename) {
    require_once $filename;
}
