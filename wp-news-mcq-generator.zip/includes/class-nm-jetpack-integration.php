<?php

/**
 * Jetpack Integration Class
 *
 * Handles Jetpack Publicize and other Jetpack-specific features for MCQ CPT.
 *
 * @package WP_News_MCQ_Generator
 */

if (! defined('ABSPATH')) {
    exit;
}

class NM_Jetpack_Integration
{
    /**
     * Initialize the integration.
     */
    public static function init()
    {
        // Enable Publicize for MCQ post type
        add_filter('jetpack_publicize_post_types', array(self::class, 'enable_publicize_for_mcq'));

        // Automatically construct the social share text when an MCQ is published
        add_action('transition_post_status', array(self::class, 'set_custom_publicize_message'), 8, 3);

        // Enforce daily sharing limit and enabled check
        add_filter('publicize_should_publicize_published_post', array(self::class, 'should_share_post'), 10, 2);

        // Ensure featured image is set BEFORE Jetpack reads it - runs at priority 1 (very early)
        add_action('transition_post_status', array(self::class, 'prepare_featured_image_early'), 1, 3);

        // Hook into Open Graph tags - multiple attempts to ensure it works
        add_filter('og_meta_tags', array(self::class, 'force_og_image'), 10, 2);
        add_filter('jetpack_open_graph_image_default', array(self::class, 'get_og_image_for_jetpack'), 10, 2);
    }

    /**
     * Check if Jetpack sharing is enabled in settings.
     *
     * @return bool True if enabled.
     */
    public static function is_enabled()
    {
        return (bool) get_option('nm_jetpack_enabled', 1);
    }

    /**
     * Prepare featured image very early in the transition process.
     * This runs at priority 1, before most other hooks.
     */
    public static function prepare_featured_image_early($new_status, $old_status, $post)
    {
        if ($post->post_type !== 'mcq') {
            return;
        }

        if ($new_status === 'publish' && $old_status !== 'publish') {
            // Ensure the social image is generated and set as featured image
            if (class_exists('NM_Social_Image_Generator')) {
                NM_Social_Image_Generator::get_or_generate_image($post->ID, '', 4, true);
            }
        }
    }

    /**
     * Force OG image meta tags for MCQ posts.
     */
    public static function force_og_image($og_tags, $post)
    {
        if (! $post || $post->post_type !== 'mcq') {
            return $og_tags;
        }

        $social_image_url = self::get_mcq_social_image_url($post->ID);
        if ($social_image_url) {
            // Determine image type from extension
            $image_type = 'image/webp';
            if (preg_match('/\.jpe?g$/i', $social_image_url)) {
                $image_type = 'image/jpeg';
            } elseif (preg_match('/\.png$/i', $social_image_url)) {
                $image_type = 'image/png';
            }

            $og_tags['og:image']             = $social_image_url;
            $og_tags['og:image:secure_url']  = set_url_scheme($social_image_url, 'https');
            $og_tags['og:image:width']       = '1200';
            $og_tags['og:image:height']      = '630';
            $og_tags['og:image:type']        = $image_type;
        }

        return $og_tags;
    }

    /**
     * Get OG image for Jetpack - returns our custom generated image.
     */
    public static function get_og_image_for_jetpack($image, $post)
    {
        if (! $post || $post->post_type !== 'mcq') {
            return $image;
        }

        $social_image_url = self::get_mcq_social_image_url($post->ID);
        if ($social_image_url) {
            return $social_image_url;
        }

        return $image;
    }

    /**
     * Get the generated social image URL for an MCQ post.
     * Checks multiple sources to find the image.
     */
    private static function get_mcq_social_image_url($post_id)
    {
        // First check the stored URL meta
        $stored_url = get_post_meta($post_id, '_nm_social_image_url', true);
        if ($stored_url) {
            return set_url_scheme($stored_url, 'https');
        }

        // Check if image file exists based on version meta
        if (class_exists('NM_Social_Image_Generator')) {
            $version = get_post_meta($post_id, '_nm_social_image_version', true);
            if ($version) {
                $upload_dir = wp_upload_dir();
                $file_path  = $upload_dir['basedir'] . '/nm-social/mcq-' . $post_id . '-' . $version . '.webp';
                if (file_exists($file_path)) {
                    return set_url_scheme($upload_dir['baseurl'] . '/nm-social/mcq-' . $post_id . '-' . $version . '.webp', 'https');
                }
            }
        }

        // Fallback to featured image if set
        $thumbnail_id = get_post_thumbnail_id($post_id);
        if ($thumbnail_id) {
            $thumbnail_url = wp_get_attachment_image_url($thumbnail_id, 'full');
            if ($thumbnail_url) {
                return set_url_scheme($thumbnail_url, 'https');
            }
        }

        return false;
    }

    /**
     * Determine if a post should be publicized based on enabled setting and daily limits.
     */
    public static function should_share_post($should_share, $post)
    {
        if ($post->post_type !== 'mcq') {
            return $should_share;
        }

        // Check if Jetpack sharing is enabled.
        if (! self::is_enabled()) {
            error_log('NM Jetpack Integration: Skipping share — Jetpack sharing is disabled in settings.');
            return false;
        }

        $limit = intval(get_option('nm_jetpack_daily_limit', 5));
        if ($limit === 0) {
            return $should_share;
        }

        $today = gmdate('Y-m-d');
        $tracker = get_option('nm_jetpack_pub_tracker', array('date' => '', 'ids' => array()));

        // Reset tracker if it's a new day
        if ($tracker['date'] !== $today) {
            $tracker = array('date' => $today, 'ids' => array());
        }

        // If already shared today, allow it (Jetpack might call this filter multiple times)
        if (in_array($post->ID, $tracker['ids'])) {
            return $should_share;
        }

        // If we hit the limit, block sharing and log
        if (count($tracker['ids']) >= $limit) {
            error_log('NM Jetpack Integration: Daily limit (' . $limit . ') reached for post ' . $post->ID);
            return false;
        }

        // Otherwise, "reserve" a spot by adding the ID to the tracker
        $tracker['ids'][] = $post->ID;
        update_option('nm_jetpack_pub_tracker', $tracker);

        return $should_share;
    }

    /**
     * Add 'mcq' to the list of post types supported by Jetpack Publicize.
     *
     * @param array $post_types Array of post types.
     * @return array Modified array of post types.
     */
    public static function enable_publicize_for_mcq($post_types)
    {
        if (! in_array('mcq', $post_types)) {
            $post_types[] = 'mcq';
        }
        return $post_types;
    }

    /**
     * Set a default structured message for social sharing via Jetpack Publicize.
     */
    public static function set_custom_publicize_message($new_status, $old_status, $post)
    {
        if ($post->post_type !== 'mcq') {
            return;
        }

        if ($new_status === 'publish' && $old_status !== 'publish') {
            // Skip if Jetpack sharing is disabled.
            if (! self::is_enabled()) {
                error_log('NM Jetpack Integration: Not setting publicize message for post ' . $post->ID . ' — Jetpack sharing is disabled.');
                return;
            }
            // Check if a custom message was already explicitly set (e.g., via the editor sidebar)
            $existing_message = get_post_meta($post->ID, '_wpas_mess', true);

            if (empty($existing_message)) {
                $default_template = "{question}\n\n{options}\n{link}\n\nLearn daily with thequizwire.com\n\nFollow WhatsApp Channel \n[Link of Channel]\n\nFollow YouTube Channel \n\n[Link of YT channel]\n\n#TheQuizWire #MCQs {tags}\n\nthequizwire GK MCQs";
                $template = get_option('nm_jetpack_template', $default_template);

                // 1. {question}
                $question = html_entity_decode(strip_tags($post->post_title));

                // 2. {options}
                $options_array = get_post_meta($post->ID, 'mcq_options', true);
                $options_text = "";
                if (is_array($options_array)) {
                    foreach (array('A', 'B', 'C', 'D') as $opt) {
                        if (!empty($options_array[$opt])) {
                            $options_text .= $opt . ".\n" . html_entity_decode(strip_tags($options_array[$opt])) . "\n\n";
                        }
                    }
                }

 // 3. {link}
 $link = set_url_scheme(get_permalink($post->ID), 'https');

                // 4. {tags}
                $tags = wp_get_post_terms($post->ID, 'mcq_tag', array('fields' => 'names'));
                $exams = wp_get_post_terms($post->ID, 'nm_exam', array('fields' => 'names'));

                $all_tags = array_merge((array)$tags, (array)$exams);
                $hashtags = array();

                foreach ($all_tags as $t) {
                    $cleaned = preg_replace('/[^a-zA-Z0-9]/', '', $t);
                    if (!empty($cleaned)) {
                        $hashtags[] = '#' . $cleaned;
                    }
                }
                $tags_text = !empty($hashtags) ? implode(' ', $hashtags) : "";

                // 5. Replace placeholders
                $message = str_replace(
                    array('{question}', '{options}', '{link}', '{tags}'),
                    array($question, trim($options_text), $link, $tags_text),
                    $template
                );

                // Clean up any excessive empty lines that might result from empty tags
                $message = preg_replace("/\n{3,}/", "\n\n", trim($message));

                // Save it so Jetpack picks it up during its priority 20 hook
                update_post_meta($post->ID, '_wpas_mess', $message);
            }
        }
    }
}
