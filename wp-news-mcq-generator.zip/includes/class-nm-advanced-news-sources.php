<?php

/**
 * Advanced News Sources Integration
 * Version: 1.2.0 - Ported V23 UI elements
 *
 * @MODIFIED: Added "Test RSS Feeds" button and script from V23.
 * @MODIFIED: Standardized AJAX nonce to 'nm_ajax_dashboard'.
 */

if (! defined('ABSPATH')) {
	exit;
}

class NM_Advanced_News_Sources
{

	/**
	 * Initialize hooks
	 */
	public static function init()
	{
		// Register the submenu page
		add_action('admin_menu', array(self::class, 'register_submenu'), 17); // 17 = after Content Calendar
	}

	/**
	 * Register the submenu page
	 */
	public static function register_submenu()
	{
		add_submenu_page(
			'nm_mcq_generator',   // Parent Slug
			'News Sources',       // Page Title
			'📰 News Sources',    // Menu Title
			'manage_options',     // Capability
			'nm-news-sources',    // Menu Slug
			array(self::class, 'render_page') // Callback
		);
	}

	// ... (all other PHP methods like get_sources, fetch_articles, etc., remain unchanged) ...
	private static $sources = array(
		'dawn_pakistan'    => array(
			'name'        => 'Dawn News Pakistan',
			'url'         => 'https://www.dawn.com/feeds/home',
			'reliability' => 90,
			'category'    => 'pakistan',
		),
		'tribune_pakistan' => array(
			'name'        => 'Express Tribune',
			'url'         => 'https://tribune.com.pk/feed/home',
			'reliability' => 85,
			'category'    => 'pakistan',
		),
		'geo_news'         => array(
			'name'        => 'Geo News',
			'url'         => 'https://www.geo.tv/rss/1/1',
			'reliability' => 85,
			'category'    => 'pakistan',
		),
		'the_news'         => array(
			'name'        => 'The News International',
			'url'         => 'https://www.thenews.com.pk/rss/1/1',
			'reliability' => 88,
			'category'    => 'pakistan',
		),
		'aljazeera'        => array(
			'name'        => 'Al Jazeera',
			'url'         => 'https://www.aljazeera.com/xml/rss/all.xml',
			'reliability' => 92,
			'category'    => 'world',
		),
		'reuters_general'  => array(
			'name'        => 'Reuters Top News',
			'url'         => 'https://news.google.com/rss/search?q=site:reuters.com&hl=en-PK&gl=PK&ceid=PK:en',
			'reliability' => 95,
			'category'    => 'world',
		),
		'bbc_world'        => array(
			'name'        => 'BBC World News',
			'url'         => 'https://news.google.com/rss/search?q=site:bbc.com&hl=en-PK&gl=PK&ceid=PK:en',
			'reliability' => 95,
			'category'    => 'world',
		),
		'guardian_world'   => array(
			'name'        => 'The Guardian World',
			'url'         => 'https://www.theguardian.com/world/rss',
			'reliability' => 93,
			'category'    => 'world',
		),
		'ap_news'          => array(
			'name'        => 'AP News',
			'url'         => 'https://feedx.net/rss/ap.xml',
			'reliability' => 97,
			'category'    => 'general',
		),
		'bol_news'         => array(
			'name'        => 'BOL News',
			'url'         => 'https://www.bolnews.com/feed/',
			'reliability' => 82,
			'category'    => 'pakistan',
		),
		'daily_pakistan'   => array(
			'name'        => 'Daily Pakistan',
			'url'         => 'https://en.dailypakistan.com.pk/feed/',
			'reliability' => 80,
			'category'    => 'pakistan',
		),
		'aaj_news'         => array(
			'name'        => 'Aaj News',
			'url'         => 'https://aaj.tv/feeds/latest-news',
			'reliability' => 81,
			'category'    => 'pakistan',
		),
	);
	public static function fetch_via_google_news($query, $limit = 10)
	{
		$url       = 'https://news.google.com/rss/search?q=' . urlencode($query) . '&hl=en-PK&gl=PK&ceid=PK:en';
		$cache_key = 'nm_gnews_' . md5($query);
		$cached    = get_transient($cache_key);
		if ($cached !== false) {
			return $cached;
		}
		$rss = fetch_feed($url);
		if (is_wp_error($rss)) {
			return array();
		}
		$articles = array();
		$items    = $rss->get_items(0, $limit);
		foreach ($items as $item) {
			$articles[] = array(
				'title'       => $item->get_title(),
				'description' => strip_tags($item->get_description()),
				'link'        => $item->get_permalink(),
				'date'        => $item->get_date('Y-m-d H:i:s'),
				'source'      => 'Google News',
				'source_key'  => 'google_news',
				'reliability' => 90,
			);
		}
		// ✅ START FIX: Implement smarter caching
		if (! empty($articles)) {
			// Only cache if we actually got articles
			set_transient($cache_key, $articles, 1800); // 30-minute cache for success
		} else {
			// If we got an empty list, cache it for only 1 minute
			// This prevents back-to-back failures but allows a quick recovery
			set_transient($cache_key, array(), 60); // 1-minute cache for failure
		}
		// ✅ END FIX
		return $articles;
	}
	public static function get_sources()
	{
		return self::$sources;
	}
	public static function get_sources_by_category($category)
	{
		return array_filter(
			self::$sources,
			function ($source) use ($category) {
				return $source['category'] === $category;
			}
		);
	}
	public static function fetch_articles($source_key, $limit = 10)
	{
		if (! isset(self::$sources[$source_key])) {
			return array();
		}
		$source    = self::$sources[$source_key];
		$cache_key = 'nm_rss_' . $source_key;
		$cached    = get_transient($cache_key);
		if ($cached !== false) {
			return $cached;
		}
		$rss = fetch_feed($source['url']);
		if (is_wp_error($rss)) {
			$domain = parse_url($source['url'], PHP_URL_HOST);
			if ($domain) {
				return self::fetch_via_google_news($source['name'], $limit);
			}
			return array();
		}
		$articles = array();
		$items    = $rss->get_items(0, $limit);
		foreach ($items as $item) {
			$articles[] = array(
				'title'       => $item->get_title(),
				'description' => strip_tags($item->get_description()),
				'link'        => $item->get_permalink(),
				'date'        => $item->get_date('Y-m-d H:i:s'),
				'source'      => $source['name'],
				'source_key'  => $source_key,
				'reliability' => $source['reliability'],
			);
		}
		set_transient($cache_key, $articles, 1800);
		return $articles;
	}
	public static function fetch_mixed_articles($sources = array(), $limit = 20)
	{
		if (empty($sources)) {
			$sources = array_keys(self::$sources);
		}
		$all_articles = array();
		foreach ($sources as $source_key) {
			$articles     = self::fetch_articles($source_key, 5);
			$all_articles = array_merge($all_articles, $articles);
		}
		usort(
			$all_articles,
			function ($a, $b) {
				return strtotime($b['date']) - strtotime($a['date']);
			}
		);
		return array_slice($all_articles, 0, $limit);
	}
	public static function generate_mcq_from_article($article, $topic_id = null)
	{
		if (! function_exists('nm_generate_single_mcq')) {
			return false;
		}
		$content = $article['title'] . '. ' . $article['description'];
		if (! $topic_id) {
			$topic_id = self::detect_topic_from_content($content);
		}
		$result = nm_generate_single_mcq($content, $topic_id);
		if ($result && isset($result['id'])) {
			update_post_meta($result['id'], 'mcq_source', $article['source']);
			update_post_meta($result['id'], 'mcq_source_url', $article['link']);
			update_post_meta($result['id'], 'mcq_source_reliability', $article['reliability']);
			update_post_meta($result['id'], 'mcq_source_date', $article['date']);
			return $result['id'];
		}
		return false;
	}
	private static function detect_topic_from_content($content)
	{
		$content_lower  = strtolower($content);
		$topic_keywords = array(
			'Pakistan'      => array('pakistan', 'islamabad', 'karachi', 'lahore', 'pmln', 'pti', 'imran khan'),
			'India'         => array('india', 'delhi', 'mumbai', 'modi', 'bjp', 'congress'),
			'World Affairs' => array('un', 'united nations', 'nato', 'eu', 'european union', 'world'),
			'Science'       => array('science', 'research', 'study', 'scientist', 'discovery', 'technology'),
			'Technology'    => array('technology', 'tech', 'ai', 'software', 'internet', 'computer', 'digital'),
			'Sports'        => array('cricket', 'football', 'tennis', 'sports', 'player', 'match', 'game'),
			'Economy'       => array('economy', 'economic', 'gdp', 'inflation', 'stock', 'market', 'trade'),
			'Health'        => array('health', 'medical', 'hospital', 'doctor', 'disease', 'vaccine', 'covid'),
		);
		$matches        = array();
		foreach ($topic_keywords as $topic_name => $keywords) {
			$count = 0;
			foreach ($keywords as $keyword) {
				if (strpos($content_lower, $keyword) !== false) {
					++$count;
				}
			}
			if ($count > 0) {
				$matches[$topic_name] = $count;
			}
		}
		if (empty($matches)) {
			return null;
		}
		arsort($matches);
		$topic_name = array_key_first($matches);
		$topic      = get_term_by('name', $topic_name, 'topic');
		if (! $topic) {
			$topic_result = wp_insert_term($topic_name, 'topic');
			if (! is_wp_error($topic_result)) {
				return $topic_result['term_id'];
			}
			return null;
		}
		return $topic->term_id;
	}


	/**
	 * ✅ RENDER NEWS SOURCES PAGE (Ported from V23)
	 */
	public static function render_page()
	{
		if (! current_user_can('manage_options')) {
			wp_die('Access denied');
		}
		$sources = self::$sources;
		$enabled = get_option('nm_enabled_news_sources', array_keys($sources));

		if (isset($_POST['save_sources']) && check_admin_referer('nm_sources_nonce')) {
			$enabled = isset($_POST['enabled_sources']) ? array_map('sanitize_text_field', $_POST['enabled_sources']) : array();
			update_option('nm_enabled_news_sources', $enabled, false);
			echo '<div class="notice notice-success"><p>Sources saved!</p></div>';
		}
?>
		<div class="wrap">
			<h1>📰 News Sources</h1>
			<p>Select which RSS feeds to use for MCQ generation. Sources with higher reliability scores are prioritized.</p>

			<form method="post">
				<?php wp_nonce_field('nm_sources_nonce'); ?>

				<div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px; margin: 30px 0;">
					<?php
					foreach ($sources as $key => $source) :
						$checked           = in_array($key, $enabled) ? 'checked' : '';
						$reliability_color = $source['reliability'] >= 95 ? '#27ae60' : ($source['reliability'] >= 90 ? '#f39c12' : '#95a5a6');
					?>
						<div style="background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); border-left: 4px solid <?php echo $reliability_color; ?>;">
							<label style="display: flex; align-items: flex-start; cursor: pointer;">
								<input type="checkbox" name="enabled_sources[]" value="<?php echo esc_attr($key); ?>" <?php echo $checked; ?> style="margin-top: 3px;">
								<div style="margin-left: 12px; flex: 1;">
									<div style="font-weight: 600; font-size: 16px; margin-bottom: 8px;">
										<?php echo esc_html($source['name']); ?>
									</div>
									<div style="display: flex; gap: 10px; margin-bottom: 8px;">
										<span style="background: <?php echo $reliability_color; ?>; color: white; padding: 2px 8px; border-radius: 3px; font-size: 11px; font-weight: 600;">
											<?php echo $source['reliability']; ?>% Reliable
										</span>
										<span style="background: #3498db; color: white; padding: 2px 8px; border-radius: 3px; font-size: 11px; font-weight: 600;">
											<?php echo ucfirst($source['category']); ?>
										</span>
									</div>
									<div style="font-size: 12px; color: #666; word-break: break-all;">
										<?php echo esc_html($source['url']); ?>
									</div>
								</div>
							</label>
						</div>
					<?php endforeach; ?>
				</div>

				<p class="submit">
					<button type="submit" name="save_sources" class="button button-primary button-large">
						💾 Save Sources Configuration
					</button>
					<button type="button" id="nm-test-sources" class="button button-secondary button-large" style="margin-left: 10px;">
						🧪 Test RSS Feeds
					</button>
				</p>
			</form>

			<div id="nm-test-results" style="display: none; margin-top: 30px; padding: 20px; background: #f7f7f7; border-radius: 8px;">
				<h2>📊 Feed Test Results</h2>
				<div id="nm-test-content"></div>
			</div>
		</div>

		<script>
			jQuery(document).ready(function($) {
				$('#nm-test-sources').on('click', function() {
					const btn = $(this);
					btn.prop('disabled', true).text('Testing...');

					$('#nm-test-results').show();
					$('#nm-test-content').html('<div class="nm-spinner" style="border:3px solid #f3f3f3; border-top:3px solid #0073aa; border-radius:50%; width:40px; height:40px; animation:nm-spin 1s linear infinite; margin:20px auto;"></div>');

					$.ajax({
						url: ajaxurl,
						type: 'POST',
						data: {
							action: 'nm_test_news_sources', // This handler must be added to NM_AJAX_Manager
							_ajax_nonce: '<?php echo wp_create_nonce('nm_ajax_dashboard'); ?>', // ✅ Use dashboard nonce
							enabled_sources: $('input[name="enabled_sources[]"]:checked').map(function() {
								return $(this).val();
							}).get()
						},
						success: function(response) {
							if (response.success) {
								let html = '<div style="display: grid; gap: 15px;">';

								response.data.results.forEach(function(result) {
									const statusColor = result.success ? '#27ae60' : '#e74c3c';
									const statusIcon = result.success ? '✅' : '❌';

									html += '<div style="background: white; padding: 15px; border-left: 4px solid ' + statusColor + '; border-radius: 4px;">';
									html += '<div style="font-weight: 600; margin-bottom: 5px;">' + statusIcon + ' ' + result.name + '</div>';
									html += '<div style="font-size: 13px; color: #666;">' + result.message + '</div>';
									if (result.article_count) {
										html += '<div style="font-size: 12px; color: #3498db; margin-top: 5px;">Found ' + result.article_count + ' articles</div>';
									}
									html += '</div>';
								});

								html += '</div>';
								$('#nm-test-content').html(html);
							}

							btn.prop('disabled', false).text('🧪 Test RSS Feeds');
						}
					});
				});
			});
		</script>
<?php
	}
}
?>