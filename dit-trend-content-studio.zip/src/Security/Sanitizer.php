<?php

/**
 * AI JSON Response Sanitizer
 *
 * Handles 20+ common AI output format issues to ensure reliable JSON parsing.
 *
 * @package DIT_TrendStudio\Security
 * @since 2.1.1
 */

namespace DIT\TrendStudio\Security;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Sanitizes and repairs JSON from AI responses
 * 
 * LLMs frequently return JSON that is syntactically invalid due to:
 * - Markdown code fences
 * - Trailing commas
 * - Single quotes
 * - Unquoted keys
 * - JavaScript comments
 * - Control characters
 * - HTML entities
 * 
 * This class handles all known variations to provide reliable parsing.
 */
class Sanitizer
{
    /**
     * Last error message from parsing attempts
     * @var string
     */
    private static $last_error = '';

    /**
     * Track which cleaning steps were applied
     * @var array
     */
    private static $cleaning_steps = [];
    /**
     * Sanitize and parse AI-generated JSON
     *
     * @param string $raw_text The raw AI response text
     * @return array|null Parsed JSON as array, or null if unparseable
     */
    public static function parse(string $raw_text): ?array
    {
        // Reset tracking
        self::$cleaning_steps = [];
        self::$last_error = '';

        // 1. New Strategy: Iterative JSON Block Search (Find valid blocks in raw text)
        // This handles cases like "Thinking... {block} Result: {json}"
        // It uses score_json_candidate to pick the most likely article payload.
        $iterative_data = self::find_valid_json_block($raw_text);
        if ($iterative_data !== null) {
            // If it's a truncated block metadata, return it directly. 
            // The caller (Client.php) will handle the repair.
            if (isset($iterative_data['_is_truncated_block'])) {
                return self::recursive_html_decode($iterative_data);
            }
            // @MODIFIED 2026-02-14 - Ensure HTML entities are decoded even in fast path
            return self::recursive_html_decode($iterative_data);
        }

        // 2. Fallback: Clean the text (strip markdown, fix quotes, etc.)
        $clean_text = self::clean($raw_text);

        // 3. Try parsing the clean text
        $data = json_decode($clean_text, true);
        if (json_last_error() === JSON_ERROR_NONE) {
            return self::recursive_html_decode($data);
        }
        self::$last_error = 'After clean(): ' . json_last_error_msg();

        // 4. Backward compatibility: Aggressive repair on clean text
        $repaired_text = self::repair($clean_text);
        $data = json_decode($repaired_text, true);
        if (json_last_error() === JSON_ERROR_NONE) {
            return self::recursive_html_decode($data);
        }
        self::$last_error .= ' | After repair(): ' . json_last_error_msg();

        self::$last_error .= ' | After direct repair: ' . json_last_error_msg();
        self::$last_error .= ' | Steps applied: ' . implode(', ', self::$cleaning_steps);

        // FALLBACK: If we still failed, it might be a payload inside a smaller block we skipped.
        // Try the largest balanced block regardless of scoring.
        $largest = self::aggressive_json_extract($raw_text);
        if ($largest) {
            $data = json_decode(self::clean($largest), true);
            if (json_last_error() === JSON_ERROR_NONE) {
                return self::recursive_html_decode($data);
            }
        }

        return null;
    }

    /**
     * Clean raw AI text into potential JSON string.
     * Applies all string-level sanitization steps.
     * 
     * @param string $text Raw input
     * @return string Cleaned JSON candidate string
     */
    public static function clean(string $text): string
    {
        // @MODIFIED 2026-01-31 - Added BOM and invisible Unicode stripping
        $text = self::strip_bom_and_invisible($text);
        // @MODIFIED 2026-02-06 - Added HTML comment stripping
        $text = self::strip_html_comments($text);
        // @MODIFIED 2026-02-09 - Removed extract_json_block to prevent picking the wrong block early.
        // Extraction is now handled by find_valid_json_block in the parse() entry point.
        $text = self::strip_markdown_fences($text);
        $text = self::fix_control_characters($text);
        $text = self::fix_html_entities($text);
        $text = self::strip_js_comments($text);
        $text = self::fix_trailing_commas($text);
        $text = self::fix_single_quotes($text);
        $text = self::fix_unquoted_keys($text);
        $text = self::fix_python_booleans($text);
        $text = self::fix_multiline_strings($text);
        $text = self::fix_smart_quotes($text);

        return $text;
    }

    /**
     * Repair broken JSON string.
     * Applies aggressive recovery techniques like brace balancing.
     * 
     * @param string $text Potentially broken JSON string
     * @return string Repaired string
     */
    public static function repair(string $text): string
    {
        // 1. Try aggressive extraction (finding largest balanced block)
        $extracted = self::aggressive_json_extract($text);
        if ($extracted) {
            $text = $extracted;
        }

        // 2. Repair truncation (close open strings/braces)
        $text = self::repair_truncated_json($text);

        return $text;
    }

    /**
     * Get the last parsing error (for debugging)
     */
    public static function get_last_error(): string
    {
        return !empty(self::$last_error) ? self::$last_error : json_last_error_msg();
    }

    // -------------------------------------------------------------------------
    // SANITIZATION METHODS
    // -------------------------------------------------------------------------

    /**
     * 13. Repair Truncated JSON
     *     Auto-closes open strings and braces/brackets
     *     @since 2.1.5
     * @MODIFIED 2026-01-31 - Enhanced mid-word truncation detection
     */
    private static function repair_truncated_json(string $text): string
    {
        $len = strlen($text);
        $in_string = false;
        $escape = false;
        $stack = [];
        $truncation_detected = false;
        $truncation_position = -1;

        for ($i = 0; $i < $len; $i++) {
            $char = $text[$i];

            if ($escape) {
                $escape = false;
                continue;
            }

            if ($char === '\\') {
                $escape = true;
                continue;
            }

            if ($char === '"') {
                $in_string = !$in_string;
                continue;
            }

            if (!$in_string) {
                if ($char === '{') {
                    array_push($stack, '}');
                } elseif ($char === '[') {
                    array_push($stack, ']');
                } elseif ($char === '}' || $char === ']') {
                    if (!empty($stack)) {
                        $last = array_pop($stack);
                        // Mismatched closing brace? Ignore or accept?
                        // For repair, we assume integrity up to truncation.
                    }
                }
            }
        }

        // @MODIFIED 2026-01-31 - Detect mid-word truncation in string values
        if ($in_string) {
            // Check if the last few characters suggest mid-word truncation
            $last_10 = substr($text, -10);
            $has_space = strpos($last_10, ' ') !== false;

            // If no space in last 10 chars and string ends abruptly, likely mid-word truncation
            if (!$has_space && strlen($last_10) >= 5) {
                $truncation_detected = true;
                $truncation_position = $len;
            }

            $text .= '"';
        }

        // Close open structures
        while (!empty($stack)) {
            $text .= array_pop($stack);
        }

        // @MODIFIED 2026-01-31 - Validate repair didn't make things worse
        // Quick sanity check: balanced braces after repair
        $open_braces = substr_count($text, '{');
        $close_braces = substr_count($text, '}');
        $open_brackets = substr_count($text, '[');
        $close_brackets = substr_count($text, ']');

        // If still unbalanced after repair, something went wrong
        if (($open_braces !== $close_braces) || ($open_brackets !== $close_brackets)) {
            // Repair failed, return original to avoid corruption
            return substr($text, 0, $len); // Return original length
        }

        return $text;
    }

    /**
     * 0. Strip BOM and invisible Unicode characters
     *    @since 2026-01-31 - NEW
     */
    private static function strip_bom_and_invisible(string $text): string
    {
        // Remove UTF-8 BOM
        if (substr($text, 0, 3) === "\xEF\xBB\xBF") {
            $text = substr($text, 3);
            self::$cleaning_steps[] = 'stripped_utf8_bom';
        }

        // Remove other BOMs (UTF-16, UTF-32)
        $boms = [
            "\xFE\xFF",     // UTF-16 BE
            "\xFF\xFE",     // UTF-16 LE
            "\x00\x00\xFE\xFF", // UTF-32 BE
            "\xFF\xFE\x00\x00", // UTF-32 LE
        ];

        foreach ($boms as $bom) {
            if (substr($text, 0, strlen($bom)) === $bom) {
                $text = substr($text, strlen($bom));
                self::$cleaning_steps[] = 'stripped_bom';
            }
        }

        // Remove zero-width spaces and other invisible Unicode chars
        $text = preg_replace('/[\x{200B}-\x{200D}\x{FEFF}]/u', '', $text);

        return $text;
    }

    /**
     * 0b. Strip HTML comments
     *     Handles: <!-- ... --> anywhere in the response
     *     @MODIFIED 2026-02-06 - NEW
     */
    private static function strip_html_comments(string $text): string
    {
        $original_len = strlen($text);

        // Remove HTML comments (non-greedy to handle multiple comments)
        $text = preg_replace('/<!--[\s\S]*?-->/', '', $text);

        if (strlen($text) !== $original_len) {
            self::$cleaning_steps[] = 'stripped_html_comments';
        }

        return $text;
    }

    /**
     * 1. Strip Markdown code fences
     *    Handles: ```json, ```, ~~~json, ~~~, ```javascript, etc.
     *    @MODIFIED 2026-02-08 - Fixed: Allow fence immediately followed by JSON (```json{)
     */
    private static function strip_markdown_fences(string $text): string
    {
        $original_len = strlen($text);

        // Pattern 1: Find opening fence anywhere in the text
        // @MODIFIED 2026-02-08 - Removed newline/space requirement after fence
        // Now matches: ```json\n{...} AND ```json{...}
        if (preg_match('/```(?:json|javascript|js|JSON)?\s*([\s\S]*)/i', $text, $m, PREG_OFFSET_CAPTURE)) {
            $fence_content = $m[1][0]; // Content after the opening fence

            // detailed check: do we have a closing fence?
            // search for closing ``` in the captured content
            if (preg_match('/```/', $fence_content, $m_close, PREG_OFFSET_CAPTURE)) {
                // We have a closing fence, take everything up to it
                $text = substr($fence_content, 0, $m_close[0][1]);
            } else {
                // No closing fence (truncation?), take everything
                $text = $fence_content;
            }
        }

        // Handle tilde fences (~~~json ... ~~~) - same logic
        elseif (preg_match('/~~~(?:json|javascript|js)?\s*([\s\S]*)/i', $text, $m, PREG_OFFSET_CAPTURE)) {
            $fence_content = $m[1][0];
            if (preg_match('/~~~/', $fence_content, $m_close, PREG_OFFSET_CAPTURE)) {
                $text = substr($fence_content, 0, $m_close[0][1]);
            } else {
                $text = $fence_content;
            }
        } else {
            // Fallback: If no internal fence found, check for leading/trailing just in case
            // (Standard cleanup for clean strings)
            $text = preg_replace('/^\s*```(?:json|javascript|js|JSON)?\s*/i', '', $text);
            $text = preg_replace('/\s*```\s*$/i', '', $text);

            $text = preg_replace('/^\s*~~~(?:json|javascript|js)?\s*/i', '', $text);
            $text = preg_replace('/\s*~~~\s*$/i', '', $text);
        }

        if (strlen($text) !== $original_len) {
            self::$cleaning_steps[] = 'stripped_markdown_fences';
        }

        return trim($text);
    }

    /**
     * 2. Extract JSON block from surrounding text
     *    Handles: "Here is the JSON: {...}" or "The result is: [...]"
     *    @MODIFIED 2026-02-06 - Enhanced preamble stripping with common AI phrases
     */
    private static function extract_json_block(string $text): string
    {
        // If already starts with { or [, return as-is
        if (preg_match('/^\s*[\{\[]/', $text)) {
            return $text;
        }

        // @MODIFIED 2026-02-06 - Strip common AI preamble phrases
        $preamble_patterns = [
            '/^.*?(?:here\s+is|here\'s)\s+(?:the\s+)?(?:json|data|result|response|output)\s*[:\-]?\s*/is',
            '/^.*?(?:sure|okay|alright)[!,.]?\s*/is',
            '/^.*?(?:thinking|let\s+me\s+think).*?\n/is',
            '/^.*?(?:result|output|response)\s*[:\-]\s*/is',
            '/^.*?(?:the\s+(?:json|data)\s+is)\s*[:\-]?\s*/is',
            '/^.*?(?:I\'ve\s+generated|I\s+generated|Generated)\s*[:\-]?\s*/is',
        ];

        foreach ($preamble_patterns as $pattern) {
            $stripped = preg_replace($pattern, '', $text, 1);
            if ($stripped !== null && preg_match('/^\s*[\{\[]/', $stripped)) {
                self::$cleaning_steps[] = 'stripped_preamble';
                return $stripped;
            }
        }

        // @MODIFIED 2026-02-09 - Use balanced extraction instead of greedy regex
        // Greedy regex (/\{[\s\S]*\}|\[[\s\S]*\]/) can corrupt responses with multiple blocks.
        $start_brace = strpos($text, '{');
        $start_bracket = strpos($text, '[');

        if ($start_brace === false && $start_bracket === false) {
            return $text;
        }

        $start = ($start_brace !== false && ($start_bracket === false || $start_brace < $start_bracket)) ? $start_brace : $start_bracket;
        $extracted = self::extract_balanced_block($text, $start);

        return $extracted ?: $text;
    }

    /**
     * 3. Fix control characters
     *    Handles: \r, literal tabs, null bytes, etc.
     * @MODIFIED 2026-01-25 - More aggressive control char stripping
     */
    private static function fix_control_characters(string $text): string
    {
        // Remove NULL bytes
        $text = str_replace("\0", '', $text);

        // Normalize line endings
        $text = str_replace(["\r\n", "\r"], "\n", $text);

        // Remove other control characters except \n and \t (standard JSON whitespace)
        // This now also removes \x7F (DEL) and extended control chars
        $text = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $text);

        // Escape any remaining control characters that might be INSIDE string values
        // by converting them to their Unicode escape sequences
        $text = preg_replace_callback('/[\x00-\x1F]/', function ($matches) {
            $char = ord($matches[0]);
            // Allow \n and \t to pass through as-is (handled by fix_multiline_strings)
            if ($char === 0x0A || $char === 0x09) {
                return $matches[0];
            }
            return sprintf('\\u%04x', $char);
        }, $text);

        return $text;
    }

    /**
     * 4. Decode HTML entities
     *    Handles: &quot;, &apos;, &lt;, &gt;, &amp;, &#x27;, etc.
     */
    private static function fix_html_entities(string $text): string
    {
        return html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }

    /**
     * 5. Strip JavaScript-style comments
     *    Handles: single-line (//) and multi-line block comments
     */
    private static function strip_js_comments(string $text): string
    {
        // Remove single-line comments (but not // inside strings)
        // This is a simplified approach - doesn't handle all edge cases
        $text = preg_replace('#^\s*//.*$#m', '', $text);

        // Remove multi-line comments
        $text = preg_replace('#/\*[\s\S]*?\*/#', '', $text);

        return $text;
    }

    /**
     * 6. Fix trailing commas (invalid in JSON, valid in JS)
     *    Handles: {"a": 1,} or ["a", "b",]
     */
    private static function fix_trailing_commas(string $text): string
    {
        // Comma before closing brace/bracket
        $text = preg_replace('/,(\s*[\}\]])/', '$1', $text);

        return $text;
    }

    /**
     * 7. Replace single quotes with double quotes
     *    Handles: {'key': 'value'} -> {"key": "value"}
     *    Note: This is risky for apostrophes inside values, but AI rarely outputs that
     */
    private static function fix_single_quotes(string $text): string
    {
        // Only fix if the text looks like it uses single quotes for JSON
        if (preg_match("/^\\s*\\{'[^\"]*\\}/s", $text)) {
            // Replace 'key': 'value' with "key": "value"
            $text = preg_replace_callback(
                "/(?<=[\[{,:])\s*'([^']*)'(?=\s*[:,\]}])/",
                function ($m) {
                    return '"' . str_replace('"', '\\"', $m[1]) . '"';
                },
                $text
            );
        }

        return $text;
    }

    /**
     * 8. Fix unquoted keys
     *    Handles: {key: "value"} -> {"key": "value"}
     */
    private static function fix_unquoted_keys(string $text): string
    {
        // Match unquoted keys (word characters before colon, not already quoted)
        $text = preg_replace('/([{\[,])\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*:/', '$1"$2":', $text);

        return $text;
    }

    /**
     * 9. Fix Python-style booleans
     *    Handles: True -> true, False -> false, None -> null
     */
    private static function fix_python_booleans(string $text): string
    {
        // Only replace when they appear as standalone values
        $text = preg_replace('/:\s*True\b/', ': true', $text);
        $text = preg_replace('/:\s*False\b/', ': false', $text);
        $text = preg_replace('/:\s*None\b/', ': null', $text);

        return $text;
    }

    /**
     * 10. Fix multiline strings (invalid in JSON)
     *     Handles: Literal newlines inside string values
     */
    private static function fix_multiline_strings(string $text): string
    {
        // Replace literal newlines inside strings with \n escape
        // This is a simplified approach
        return preg_replace_callback(
            '/"([^"\\\\]*(?:\\\\.[^"\\\\]*)*)"/s',
            function ($matches) {
                $content = $matches[1];
                // Replace actual newlines with escaped version
                $content = str_replace(["\n", "\r"], ["\\n", ""], $content);
                return '"' . $content . '"';
            },
            $text
        );
    }

    /**
     * 11. Fix smart/curly quotes
     *     Handles: "quote" -> "quote", 'apostrophe' -> 'apostrophe'
     */
    private static function fix_smart_quotes(string $text): string
    {
        // Support both actual UTF-8 characters and JSON escape sequences
        // This is safe to run on raw JSON because these characters almost always
        // represent intended quotes/apostrophes in the article content.
        $replacements = [
            "\u{201C}" => '"',  // Left double “
            "\u{201D}" => '"',  // Right double ”
            "\u{2018}" => "'",  // Left single ‘
            "\u{2019}" => "'",  // Right single ’
            '\\u201c' => '\"',  // JSON escape left double (lowercase)
            '\\u201C' => '\"',  // JSON escape left double (uppercase)
            '\\u201d' => '\"',  // JSON escape right double
            '\\u201D' => '\"',
            '\\u2018' => "'",  // JSON escape left single
            '\\u2019' => "'",  // JSON escape right single
            "\u{00AB}" => '"',  // French left «
            "\u{00BB}" => '"',  // French right »
            "\u{201E}" => '"',  // German low „
            "\u{201F}" => '"',  // German high ‟
        ];

        return strtr($text, $replacements);
    }

    /**
     * 12. Aggressive JSON extraction (last resort)
     *     Tries to find the largest valid JSON block by balancing braces
     */
    private static function aggressive_json_extract(string $text): ?string
    {
        // Find the first { or [
        $start_brace = strpos($text, '{');
        $start_bracket = strpos($text, '[');

        if ($start_brace === false && $start_bracket === false) {
            return null;
        }

        // Determine which comes first
        if ($start_brace === false) {
            $start = $start_bracket;
            $open = '[';
            $close = ']';
        } elseif ($start_bracket === false) {
            $start = $start_brace;
            $open = '{';
            $close = '}';
        } else {
            $start = min($start_brace, $start_bracket);
            $open = ($start === $start_brace) ? '{' : '[';
            $close = ($start === $start_brace) ? '}' : ']';
        }

        // Balance braces to find the end
        $depth = 0;
        $in_string = false;
        $escape = false;
        $len = strlen($text);

        for ($i = $start; $i < $len; $i++) {
            $char = $text[$i];

            if ($escape) {
                $escape = false;
                continue;
            }

            if ($char === '\\' && $in_string) {
                $escape = true;
                continue;
            }

            if ($char === '"') {
                $in_string = !$in_string;
                continue;
            }

            if (!$in_string) {
                if ($char === $open || ($open === '{' && $char === '[') || ($open === '[' && $char === '{')) {
                    $depth++;
                } elseif ($char === $close || ($close === '}' && $char === ']') || ($close === ']' && $char === '}')) {
                    $depth--;
                    if ($depth === 0) {
                        return substr($text, $start, $i - $start + 1);
                    }
                }
            }
        }

        // @MODIFIED 2026-01-30 - Handle Truncated JSON
        // If we hit EOF but found a start brace, assume truncation and return what we have.
        // This allows repair_truncated_json() to fix it later.
        if ($depth > 0) {
            return substr($text, $start);
        }

        return null;
    }

    /**
     * Iteratively search for VALID JSON blocks in text.
     * Use this when standard cleaning fails.
     * 
     * @param string $text Raw text
     * @return array|null Parsed JSON or null
     */
    private static function find_valid_json_block(string $text): ?array
    {
        $text = self::strip_bom_and_invisible($text); // Basic hygiene
        $len = strlen($text);
        $start_positions = [];

        // Find all potential start positions
        for ($i = 0; $i < $len; $i++) {
            if ($text[$i] === '{' || $text[$i] === '[') {
                $start_positions[] = $i;
            }
        }

        $best_candidate = null;
        $best_score = -1;
        $is_best_truncated = false;

        foreach ($start_positions as $start) {
            // 1. Try complete extraction
            $block = self::extract_balanced_block($text, $start, false);
            if ($block) {
                // Try decoding
                $decoded = json_decode($block, true);
                if (json_last_error() !== JSON_ERROR_NONE) {
                    $decoded = json_decode(self::clean_inner_block($block), true);
                }

                if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                    $score = self::score_json_candidate($decoded);
                    if ($score > $best_score) {
                        $best_candidate = $decoded;
                        $best_score = $score;
                        $is_best_truncated = false;
                    }
                }
            }

            // 2. Try truncated extraction (only if it might score better)
            $trunc_block = self::extract_balanced_block($text, $start, true);
            if ($trunc_block) {
                $score = self::score_raw_json_chunk($trunc_block);
                // We add a 'completeness' penalty to truncated blocks so they need to be significantly better to win
                $normalized_score = $score - 30;

                if ($normalized_score > $best_score) {
                    $best_candidate = $trunc_block;
                    $best_score = $normalized_score;
                    $is_best_truncated = true;
                }
            }
        }

        if ($best_candidate !== null) {
            if ($is_best_truncated) {
                return ['_is_truncated_block' => true, 'raw' => $best_candidate];
            }
            return $best_candidate;
        }

        return null;
    }

    /**
     * Score a RAW potentially truncated JSON chunk to see if it's the article.
     * 
     * @param string $chunk
     * @return int
     */
    private static function score_raw_json_chunk(string $chunk): int
    {
        $score = 0;
        $len = strlen($chunk);

        if (strpos($chunk, '"sections"') !== false) $score += 100;
        if (strpos($chunk, '"story_narrative"') !== false) $score += 80;
        if (strpos($chunk, '"headline"') !== false || strpos($chunk, '"title"') !== false) $score += 50;

        // Reward length (but cap it)
        $score += min(200, (int)floor($len / 100));

        return $score;
    }

    /**
     * Score a decoded JSON candidate.
     *
     * We often receive multiple JSON objects in one response (schema echoes, examples, nested objects).
     * Picking the FIRST valid block is brittle and can return an empty schema template.
     *
     * Higher score = more likely to be the actual article payload.
     *
     * @since 2026-02-06
     */
    private static function score_json_candidate(array $data): int
    {
        $score = 0;

        // Prefer objects that look like our article schema
        $has_sections = isset($data['sections']) && is_array($data['sections']);
        $has_headline = isset($data['headline']) || isset($data['title']);

        if ($has_sections) {
            $score += 200;
            $score += min(50, count($data['sections']) * 5);
        }
        if ($has_headline) {
            $headline = trim((string)($data['headline'] ?? $data['title'] ?? ''));
            $score += min(80, (int)floor(strlen($headline) / 5));
            if ($headline !== '') {
                $score += 30;
            }
        }

        // Reward non-empty body content
        if ($has_sections) {
            $total_chars = 0;
            foreach ($data['sections'] as $s) {
                if (!is_array($s)) {
                    continue;
                }
                $body = (string)($s['body_html'] ?? $s['bodyhtml'] ?? $s['body'] ?? '');
                $body_plain = trim(strip_tags($body));
                $total_chars += strlen($body_plain);
            }
            $score += min(250, (int)floor($total_chars / 40));
        }

        // @MODIFIED 2026-02-09 - Reward story_narrative (Fashion/Showbiz)
        if (!empty($data['story_narrative']) && is_string($data['story_narrative'])) {
            $score += 150;
            $score += min(200, (int)floor(strlen(strip_tags($data['story_narrative'])) / 50));
        }

        // @MODIFIED 2026-02-09 - Reward content_blocks (Fashion/Generic)
        if (!empty($data['content_blocks']) && is_array($data['content_blocks'])) {
            $score += 50;
            $score += count($data['content_blocks']) * 10;
        }

        // De-prioritize tiny nested objects that aren't the full payload
        $top_keys = count($data);
        $score += min(30, $top_keys * 2);

        return $score;
    }

    /**
     * Extract a balanced block starting at a specific index
     */
    private static function extract_balanced_block(string $text, int $start, bool $allow_truncated = false): ?string
    {
        $len = strlen($text);
        $open = $text[$start];
        $close = ($open === '{') ? '}' : ']';
        $depth = 0;
        $in_string = false;
        $escape = false;

        for ($i = $start; $i < $len; $i++) {
            $char = $text[$i];

            if ($escape) {
                $escape = false;
                continue;
            }

            if ($char === '\\' && $in_string) {
                $escape = true;
                continue;
            }

            if ($char === '"') {
                $in_string = !$in_string;
                continue;
            }

            if (!$in_string) {
                if ($char === $open) {
                    $depth++;
                } elseif ($char === $close) {
                    $depth--;
                    if ($depth === 0) {
                        return substr($text, $start, $i - $start + 1);
                    }
                }
            }
        }

        // @MODIFIED 2026-02-09 - Handle truncation
        return $allow_truncated ? substr($text, $start) : null;
    }

    /**
     * Helper to clean an extracted block (lighter version of clean)
     */
    private static function clean_inner_block(string $text): string
    {
        $text = self::fix_control_characters($text);
        $text = self::fix_trailing_commas($text);
        $text = self::fix_python_booleans($text);
        // Add other safe fixers if needed
        return $text;
    }

    /**
     * Recursively decode HTML entities in array values
     * @since 2026-02-14
     */
    public static function recursive_html_decode(array $data): array
    {
        foreach ($data as $key => $value) {
            if (is_array($value)) {
                $data[$key] = self::recursive_html_decode($value);
            } elseif (is_string($value)) {
                // @MODIFIED 2026-02-14 - Decode iteratively to handle double-encoding (e.g. &amp;lt;)
                // Limit to 3 passes to prevent infinite loops or excessive processing
                $decoded = $value;
                for ($i = 0; $i < 3; $i++) {
                    $new = html_entity_decode($decoded, ENT_QUOTES | ENT_HTML5, 'UTF-8');
                    if ($new === $decoded) {
                        break;
                    }
                    $decoded = $new;
                }
                $data[$key] = $decoded;
            }
        }
        return $data;
    }

    /**
     * Safely decode AI-generated strings (URLs, tags).
     * Handles:
     * - Iterative HTML entity decoding (up to 3 levels)
     * - Literal \uXXXX sequences conversion (preserving \u0026 -> &)
     * - Removal of escape backslashes (\", \/) WITHOUT destroying \u sequences.
     * 
     * @since 2.7.7
     * @param string $input
     * @return string
     */
    public static function decode_ai_string(string $input): string
    {
        $input = trim($input);
        if ($input === '') {
            return '';
        }

        // 1. Iterative HTML entity decoding
        $decoded = $input;
        for ($i = 0; $i < 3; $i++) {
            $new = html_entity_decode($decoded, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            if ($new === $decoded) {
                break;
            }
            $decoded = $new;
        }

        // 2. Convert literal \uXXXX sequences to UTF-8
        // This MUST happen before any backslash stripping logic
        $decoded = preg_replace_callback('/\\\\u([0-9a-fA-F]{4})/', function ($m) {
            return mb_convert_encoding(pack('H*', $m[1]), 'UTF-8', 'UTF-16BE');
        }, $decoded);

        // 3. Surgical removal of common AI/JSON escapes
        // We avoid stripslashes() as it destructive towards \u sequences we might have missed
        $decoded = str_replace(['\"', '\/'], ['"', '/'], $decoded);

        return $decoded;
    }
}
