package com.snsaver.app.ui.components
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.snsaver.app.domain.model.*
import java.io.File

@Composable fun PlatformBadge(platform:Platform){Text(platform.shortName,color=if(platform==Platform.TIKTOK||platform==Platform.SNAPCHAT)Color.Black else Color.White,style=MaterialTheme.typography.labelSmall,modifier=Modifier.clip(RoundedCornerShape(6.dp)).background(Color(platform.color)).padding(horizontal=7.dp,vertical=3.dp))}
@Composable fun EmptyState(title:String,subtitle:String){Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Default.CloudDownload,null,Modifier.size(56.dp),tint=MaterialTheme.colorScheme.primary);Spacer(Modifier.height(16.dp));Text(title,style=MaterialTheme.typography.titleLarge);Text(subtitle,style=MaterialTheme.typography.bodyMedium,color=MaterialTheme.colorScheme.onSurfaceVariant)}}}
@Composable fun DownloadCard(item:DownloadItem,onClick:()->Unit,onRetry:()->Unit){Card(onClick=onClick,colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surfaceContainer),modifier=Modifier.fillMaxWidth()){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(48.dp).clip(CircleShape).background(if(item.status==DownloadStatus.FAILED)MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.primaryContainer),contentAlignment=Alignment.Center){Text(when(item.status){DownloadStatus.COMPLETED->"✓";DownloadStatus.FAILED->"!";DownloadStatus.PENDING->"…";else->"${item.progress}%"})};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Row(verticalAlignment=Alignment.CenterVertically){PlatformBadge(item.platform);Spacer(Modifier.width(8.dp));Text(item.profileName?:item.title?:item.sourceUrl,maxLines=1,overflow=TextOverflow.Ellipsis)};Text(when(item.status){DownloadStatus.EXTRACTING->"Extracting media…";DownloadStatus.DOWNLOADING->"Downloading…";DownloadStatus.FAILED->item.errorMessage?:"Failed";DownloadStatus.COMPLETED->item.caption?:"Saved";else->"Waiting for network"},style=MaterialTheme.typography.bodySmall,color=if(item.status==DownloadStatus.FAILED)MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,maxLines=2,overflow=TextOverflow.Ellipsis);if(item.status==DownloadStatus.DOWNLOADING||item.status==DownloadStatus.EXTRACTING)LinearProgressIndicator(progress={item.progress/100f},Modifier.fillMaxWidth().padding(top=8.dp))};if(item.status==DownloadStatus.FAILED)TextButton(onClick=onRetry){Text("Retry")}}}}
@Composable fun GalleryTile(item:DownloadItem,onClick:()->Unit){Column(Modifier.clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceContainer).clickable(onClick=onClick)){Box(Modifier.fillMaxWidth().aspectRatio(1f)){val path=item.thumbnailPath?:item.filePath;if(path!=null)AsyncImage(if(path.startsWith("http"))path else File(path),null,Modifier.fillMaxSize(),contentScale=ContentScale.Crop);PlatformBadge(item.platform);if(item.mediaType!=MediaType.IMAGE)Icon(Icons.Default.PlayCircle,null,Modifier.align(Alignment.Center).size(44.dp),tint=Color.White)};Text(item.caption?:item.title?:"Saved media",Modifier.padding(9.dp),maxLines=1,overflow=TextOverflow.Ellipsis,style=MaterialTheme.typography.bodySmall)}}
