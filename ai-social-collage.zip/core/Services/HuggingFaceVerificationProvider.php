<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Contracts\VerificationProviderInterface;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class HuggingFaceVerificationProvider implements VerificationProviderInterface {

    private $api_key;
    private $model;

    public function __construct( string $api_key = '', string $model = 'microsoft/trocr-base-large' ) {
        $this->api_key = $api_key;
        $this->model = $model;
    }

    public function get_provider_name(): string {
        return Config::PROVIDER_VERIFICATION_HF;
    }

    public function get_model_name(): string {
        return $this->model;
    }

    public function is_available(): bool {
        return ! empty( $this->api_key );
    }

    public function get_cost_estimate( int $image_count = 1 ): float {
        $free_tier_limit = 10000;
        $tokens_per_image = 150;
        $total_tokens = $tokens_per_image * $image_count;
        return ( $total_tokens / $free_tier_limit ) * 100;
    }

    public function analyze_image( string $image_path, string $prompt, array $options = [] ): array {
        if ( ! file_exists( $image_path ) ) {
            throw new \Exception( 'Image file not found: ' . $image_path );
        }

        $api_url = "https://api-inference.huggingface.co/models/" . urlencode( $this->model );
        
        $image_data = file_get_contents( $image_path );
        if ( ! $image_data ) {
            throw new \Exception( 'Failed to read image: ' . $image_path );
        }

        $response = wp_remote_post( $api_url, [
            'timeout' => 60,
            'headers' => [
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json',
            ],
            'body' => wp_json_encode( [
                'inputs' => base64_encode( $image_data ),
            ] ),
        ] );

        if ( is_wp_error( $response ) ) {
            throw new \Exception( 'HF API error: ' . $response->get_error_message() );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );

        if ( $code !== 200 ) {
            throw new \Exception( "HF API returned HTTP {$code}: " . mb_substr( $body, 0, 500 ) );
        }

        $result = json_decode( $body, true );
        if ( ! is_array( $result ) ) {
            throw new \Exception( 'Invalid HF response format' );
        }

        return $this->parse_result( $result, $options );
    }

    private function parse_result( array $result, array $options ): array {
        $text = $result['text'] ?? '';
        $boxes = $result['boxes'] ?? [];

        return [
            'text' => $text,
            'boxes' => $boxes,
            'clean' => empty( $options['expected_text'] ) || ! $this->contains_text( $text, $options['expected_text'] ),
            'confidence' => 0.85,
            'provider' => $this->get_provider_name(),
            'model' => $this->get_model_name(),
        ];
    }

    private function contains_text( string $haystack, string $needle ): bool {
        similar_text( strtolower( $haystack ), strtolower( $needle ), $percent );
        return $percent > 70;
    }
}