<?php

/**
 * Email Digest System v3.1
 *
 * @MODIFIED: Refactored all procedural code into the NM_Email_Digest class.
 * @MODIFIED: Added init() and register_submenu() to hook into the new admin menu.
 * @MODIFIED: Renamed class from NM_Email_Subscribers to NM_Email_Digest.
 * * @package WP_News_MCQ_Generator
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class NM_Email_Digest {


	private static $table_name = 'nm_subscribers';

	/**
	 * ✅ NEW: Initialize all hooks
	 */
	public static function init() {
		// Register the submenu page
		add_action( 'admin_menu', array( self::class, 'register_submenu' ), 18 ); // 18 = after Embeddings

		// Hook for creating the table
		add_action( 'admin_init', array( self::class, 'create_subscribers_table' ), 1 );

		// AJAX handler for subscription
		add_action( 'wp_ajax_nm_subscribe_user', array( self::class, 'ajax_subscribe_user' ) );
		add_action( 'wp_ajax_nopriv_nm_subscribe_user', array( self::class, 'ajax_subscribe_user' ) );

		// Cron handler for sending the digest
		add_action( 'nm_email_digest_cron', array( self::class, 'send_digest_emails' ) );

		// Handle CSV export
		add_action( 'admin_init', array( self::class, 'handle_csv_export' ) );

		// ✅ NEW: Handle Unsubscribe Action
		add_action( 'init', array( self::class, 'handle_unsubscribe_request' ) );
	}

	/**
	 * ✅ NEW: Handle Unsubscribe Request
	 */
	public static function handle_unsubscribe_request() {
		if ( isset( $_GET['action'] ) && $_GET['action'] === 'unsubscribe' && isset( $_GET['email'] ) ) {
			$email = sanitize_email( $_GET['email'] );
			if ( is_email( $email ) ) {
				self::unsubscribe( $email );
				wp_die( '✅ You have been unsubscribed successfully. <br><br><a href="' . home_url() . '">← Return to homepage</a>', 'Unsubscribed', array( 'response' => 200 ) );
			}
		}
	}

	/**
	 * ✅ NEW: Register the submenu page
	 */
	public static function register_submenu() {
		add_submenu_page(
			'nm_mcq_generator',   // Parent Slug
			'Subscribers',       // Page Title
			'📧 Subscribers',    // Menu Title
			'manage_options',     // Capability
			'nm-subscribers',    // Menu Slug
			array( self::class, 'render_page' ) // Callback
		);
	}

	// ==================================================================================
	// 1. CREATE SUBSCRIBERS TABLE
	// ==================================================================================

	public static function create_subscribers_table() {
		global $wpdb;
		$table_name      = self::get_table_name();
		$charset_collate = $wpdb->get_charset_collate();

		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) == $table_name ) {
			return; // Exit silently
		}

		$sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            email varchar(255) NOT NULL,
            name varchar(100) DEFAULT NULL,
            status varchar(20) DEFAULT 'active',
            source varchar(50) DEFAULT 'website',
            subscribed_date datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            last_email_date datetime DEFAULT NULL,
            confirm_token varchar(64) DEFAULT NULL,
            unsubscribe_token varchar(64) DEFAULT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY email_unique (email),
            KEY status_index (status),
            KEY source_index (source)
        ) $charset_collate;";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );

	}

	// ===================================================================================
	// 2. SUBSCRIBER MANAGEMENT
	// ===================================================================================

	public static function get_table_name() {
		global $wpdb;
		return $wpdb->prefix . self::$table_name;
	}

	public static function table_exists() {
		global $wpdb;
		$table = self::get_table_name();
		return $wpdb->get_var( "SHOW TABLES LIKE '$table'" ) == $table;
	}

	public static function get_active_subscribers( $limit = 1000, $offset = 0 ) {
		global $wpdb;
		$table = self::get_table_name();

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM $table WHERE status = 'active' ORDER BY subscribed_date DESC LIMIT %d OFFSET %d",
				$limit,
				$offset
			)
		);
	}

	public static function get_all_subscribers( $limit = 100, $offset = 0 ) {
		global $wpdb;
		$table = self::get_table_name();

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM $table ORDER BY subscribed_date DESC LIMIT %d OFFSET %d",
				$limit,
				$offset
			)
		);
	}

	public static function get_subscriber_count() {
		global $wpdb;
		$table = self::get_table_name();

		if ( ! self::table_exists() ) {
			return array(
				'total'        => 0,
				'active'       => 0,
				'pending'      => 0,
				'unsubscribed' => 0,
			);
		}

		return array(
			'total'        => (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i', $table ) ),
			'active'       => (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE status = %s', $table, 'active' ) ),
			'pending'      => (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE status = %s', $table, 'pending' ) ),
			'unsubscribed' => (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i WHERE status = %s', $table, 'unsubscribed' ) ),
		);
	}

	public static function add_subscriber( $email, $name = '', $auto_activate = true ) {
		global $wpdb;
		$table = self::get_table_name();

		$exists = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM $table WHERE email = %s",
				$email
			)
		);

		if ( $exists ) {
			if ( $exists->status === 'active' ) {
				return array(
					'success' => false,
					'message' => 'Already subscribed',
				);
			} elseif ( $exists->status === 'unsubscribed' ) {
				$wpdb->update(
					$table,
					array(
						'status'          => 'active',
						'subscribed_date' => current_time( 'mysql' ),
					),
					array( 'email' => $email )
				);
				return array(
					'success' => true,
					'message' => 'Subscription reactivated!',
				);
			}
		}

		$result = $wpdb->insert(
			$table,
			array(
				'email'             => $email,
				'name'              => $name,
				'status'            => $auto_activate ? 'active' : 'pending',
				'source'            => 'website',
				'subscribed_date'   => current_time( 'mysql' ),
				'unsubscribe_token' => bin2hex( random_bytes( 32 ) ),
			),
			array( '%s', '%s', '%s', '%s', '%s', '%s' )
		);

		if ( $result ) {
			self::send_welcome_email( $email, $name );
			return array(
				'success' => true,
				'message' => 'Successfully subscribed!',
			);
		}

		return array(
			'success' => false,
			'message' => 'Subscription failed',
		);
	}

	public static function unsubscribe( $email ) {
		global $wpdb;
		$table = self::get_table_name();

		return $wpdb->update(
			$table,
			array( 'status' => 'unsubscribed' ),
			array( 'email' => $email ),
			array( '%s' ),
			array( '%s' )
		);
	}

	private static function send_welcome_email( $email, $name = '' ) {
		$site_name    = get_bloginfo( 'name' );
		$display_name = $name ? $name : 'there';
		$subject      = sprintf( 'Welcome to %s MCQ Digest!', $site_name );
		$message      = self::get_email_template(
			'welcome',
			array(
				'name'      => $display_name,
				'email'     => $email,
				'site_name' => $site_name,
			)
		);
		$headers      = array( 'Content-Type: text/html; charset=UTF-8' );
		return wp_mail( $email, $subject, $message, $headers );
	}

	private static function get_email_template( $type, $data ) {
		// (Keeping template logic internal and minimal for brevity)
		if ( $type === 'welcome' ) {
			return '
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                    <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0;">
                        <h1 style="margin: 0;">Welcome to ' . $data['site_name'] . '!</h1>
                    </div>
                    <div style="background: #fff; padding: 30px; border: 1px solid #e0e0e0;">
                        <p>Hi ' . $data['name'] . '!</p>
                        <p>Thank you for subscribing to our MCQ digest. You\'ll receive fresh MCQs, quiz highlights, and learning tips.</p>
                        <p style="text-align: center; margin-top: 30px;">
                            <a href="' . home_url( '/mcq/' ) . '" style="display: inline-block; padding: 12px 30px; background: #667eea; color: white; text-decoration: none; border-radius: 5px;">
                                Start Taking Quizzes
                            </a>
                        </p>
                    </div>
                    <div style="background: #f8f9fa; padding: 20px; text-align: center; font-size: 12px; color: #888; border-radius: 0 0 8px 8px;">
                        <p>To unsubscribe: <a href="' . home_url( '/?action=unsubscribe&email=' . urlencode( $data['email'] ) ) . '">Click here</a></p>
                    </div>
                </div>';
		}
		return '';
	}

	// ===================================================================================
	// 3. AJAX SUBSCRIPTION HANDLER
	// ===================================================================================

	public static function ajax_subscribe_user() {
		if ( empty( $_POST['email'] ) ) {
			wp_send_json_error( array( 'message' => 'Email is required' ) );
		}

		$email = sanitize_email( trim( $_POST['email'] ) );
		$name  = isset( $_POST['name'] ) ? sanitize_text_field( $_POST['name'] ) : '';

		if ( ! is_email( $email ) ) {
			wp_send_json_error( array( 'message' => 'Invalid email address' ) );
		}

		$result = self::add_subscriber( $email, $name, true );

		if ( $result['success'] ) {
			wp_send_json_success( array( 'message' => $result['message'] ) );
		} else {
			wp_send_json_error( array( 'message' => $result['message'] ) );
		}
	}

	// ===================================================================================
	// 4. ACTUAL DIGEST SENDING (CRON HANDLER)
	// ===================================================================================

	public static function send_digest_emails() {
		$subscribers = self::get_active_subscribers();

		if ( empty( $subscribers ) ) {
			return;
		}

		$digest_html = self::generate_digest_content();
		$sent        = 0;
		$failed      = 0;

		foreach ( $subscribers as $subscriber ) {
			$result = self::send_single_digest( $subscriber->email, $digest_html );
			if ( $result ) {
				++$sent;
				global $wpdb;
				$wpdb->update(
					self::get_table_name(),
					array( 'last_email_date' => current_time( 'mysql' ) ),
					array( 'email' => $subscriber->email )
				);
			} else {
				++$failed;
			}
			usleep( 500000 ); // 0.5s delay
		}
	}

	public static function generate_digest_content() {
		$site_name = get_bloginfo( 'name' );

		$latest_mcqs = get_posts(
			array(
				'post_type'      => 'mcq',
				'posts_per_page' => 10,
				'post_status'    => 'publish',
				'date_query'     => array( array( 'after' => '7 days ago' ) ),
			)
		);

		$scheduled_mcqs = get_posts(
			array(
				'post_type'      => 'mcq',
				'post_status'    => 'future',
				'posts_per_page' => 5,
			)
		);

		$total_mcqs = wp_count_posts( 'mcq' )->publish;

		ob_start();
		?>
		<!DOCTYPE html>
		<html>

		<head>
			<style>
				/* ... (email styles) ... */
			</style>
		</head>

		<body>
			<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
				<div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0;">
					<h1 style="margin: 0;">📚 Weekly MCQ Digest</h1>
					<p><?php echo $site_name; ?></p>
				</div>
				<div style="background: #fff; padding: 30px; border: 1px solid #e0e0e0;">
					<h2>This Week's Highlights</h2>
					<div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
						<p><strong>📊 Total Questions:</strong> <?php echo number_format( $total_mcqs ); ?></p>
						<p><strong>🆕 New This Week:</strong> <?php echo count( $latest_mcqs ); ?></p>
						<?php if ( ! empty( $scheduled_mcqs ) ) : ?>
							<p><strong>📅 Coming Soon:</strong> <?php echo count( $scheduled_mcqs ); ?> scheduled</p>
						<?php endif; ?>
					</div>
					<?php if ( ! empty( $latest_mcqs ) ) : ?>
						<h3>🆕 Latest Questions</h3>
						<?php foreach ( array_slice( $latest_mcqs, 0, 5 ) as $mcq ) : ?>
							<div style="margin-bottom: 20px; padding: 15px; background: #f8f9fa; border-left: 4px solid #667eea; border-radius: 4px;">
								<h4 style="margin: 0 0 10px 0; color: #333;"><?php echo esc_html( $mcq->post_title ); ?></h4>
								<a href="<?php echo get_permalink( $mcq->ID ); ?>" style="color: #667eea; text-decoration: none; font-weight: bold;">Take Quiz →</a>
							</div>
						<?php endforeach; ?>
					<?php endif; ?>
					<center>
						<a href="<?php echo home_url( '/mcq/' ); ?>" style="display: inline-block; padding: 12px 30px; background: #667eea; color: white; text-decoration: none; border-radius: 5px; margin: 20px 0;">Browse All Questions</a>
					</center>
				</div>
				<div style="background: #f8f9fa; padding: 20px; text-align: center; font-size: 12px; color: #888; border-radius: 0 0 8px 8px;">
					<p>You're receiving this because you subscribed to <?php echo $site_name; ?> MCQ Digest.</p>
					<p><a href="{UNSUBSCRIBE_LINK}">Unsubscribe</a></p>
				</div>
			</div>
		</body>

		</html>
		<?php
		return ob_get_clean();
	}

	public static function send_single_digest( $email, $content ) {
		$site_name       = get_bloginfo( 'name' );
		$subject         = sprintf( 'Weekly MCQ Digest - %s', $site_name );
		$unsubscribe_url = home_url( '/?action=unsubscribe&email=' . urlencode( $email ) );
		$content         = str_replace( '{UNSUBSCRIBE_LINK}', $unsubscribe_url, $content );
		$headers         = array( 'Content-Type: text/html; charset=UTF-8' );
		return wp_mail( $email, $subject, $content, $headers );
	}

	// ===================================================================================
	// 5. CSV EXPORT HANDLER
	// ===================================================================================

	public static function handle_csv_export() {
		if ( isset( $_GET['page'] ) && $_GET['page'] === 'nm-subscribers' && isset( $_GET['export'] ) && $_GET['export'] === 'csv' ) {
			if ( ! current_user_can( 'manage_options' ) ) {
				wp_die( 'Permission denied' );
			}

			header( 'Content-Type: text/csv' );
			header( 'Content-Disposition: attachment; filename="subscribers-' . date( 'Y-m-d' ) . '.csv"' );

			$output = fopen( 'php://output', 'w' );
			fputcsv( $output, array( 'Email', 'Name', 'Status', 'Source', 'Subscribed Date', 'Last Email' ) );

			$subscribers = self::get_all_subscribers( 999999 );
			foreach ( $subscribers as $sub ) {
				fputcsv(
					$output,
					array(
						$sub->email,
						$sub->name ?: '',
						$sub->status,
						$sub->source,
						$sub->subscribed_date,
						$sub->last_email_date ?: '',
					)
				);
			}
			fclose( $output );
			exit;
		}
	}

	// ===================================================================================
	// 6. ADMIN PAGE RENDERER
	// ===================================================================================

	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Access denied' );
		}

		if ( isset( $_POST['action'] ) && $_POST['action'] === 'delete' && isset( $_POST['email'] ) ) {
			check_admin_referer( 'nm_subscriber_action' );
			global $wpdb;
			$email = sanitize_email( $_POST['email'] );
			$wpdb->delete( self::get_table_name(), array( 'email' => $email ), array( '%s' ) );
			echo '<div class="notice notice-success"><p>✅ Subscriber deleted.</p></div>';
		}

		$stats       = self::get_subscriber_count();
		$subscribers = self::get_all_subscribers( 100 );

		?>
		<div class="wrap">
			<h1>📧 Email Subscribers</h1>

			<div class="nm-stats-grid" style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin: 20px 0;">
				<div class="stat-card" style="background: #fff; padding: 20px; border-left: 4px solid #667eea; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
					<h3 style="margin: 0; color: #666; font-size: 14px;">Total Subscribers</h3>
					<p style="font-size: 32px; font-weight: bold; margin: 10px 0; color: #667eea;"><?php echo number_format( $stats['total'] ); ?></p>
				</div>
				<div class="stat-card" style="background: #fff; padding: 20px; border-left: 4px solid #27ae60; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
					<h3 style="margin: 0; color: #666; font-size: 14px;">Active</h3>
					<p style="font-size: 32px; font-weight: bold; margin: 10px 0; color: #27ae60;"><?php echo number_format( $stats['active'] ); ?></p>
				</div>
				<div class="stat-card" style="background: #fff; padding: 20px; border-left: 4px solid #f39c12; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
					<h3 style="margin: 0; color: #666; font-size: 14px;">Pending</h3>
					<p style="font-size: 32px; font-weight: bold; margin: 10px 0; color: #f39c12;"><?php echo number_format( $stats['pending'] ); ?></p>
				</div>
				<div class="stat-card" style="background: #fff; padding: 20px; border-left: 4px solid #95a5a6; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
					<h3 style="margin: 0; color: #666; font-size: 14px;">Unsubscribed</h3>
					<p style="font-size: 32px; font-weight: bold; margin: 10px 0; color: #95a5a6;"><?php echo number_format( $stats['unsubscribed'] ); ?></p>
				</div>
			</div>

			<div class="card" style="background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-top: 20px;">
				<?php if ( empty( $subscribers ) ) : ?>
					<p style="text-align: center; padding: 40px; color: #999;">
						No subscribers yet. Add the subscription form to your site using: <code>[nm_subscribe_form]</code>
					</p>
				<?php else : ?>
					<style>
						.nm-subscribers-table {
							width: 100%;
							border-collapse: collapse;
							background: #fff;
						}

						.nm-subscribers-table th {
							background: #f8f9fa;
							padding: 12px;
							text-align: left;
							font-weight: 600;
							border-bottom: 2px solid #dee2e6;
							white-space: nowrap;
						}

						.nm-subscribers-table td {
							padding: 12px;
							border-bottom: 1px solid #dee2e6;
							vertical-align: middle;
						}

						.nm-subscribers-table tbody tr:hover {
							background: #f8f9fa;
						}

						.nm-email-cell {
							max-width: 250px;
							overflow: hidden;
							text-overflow: ellipsis;
							white-space: nowrap;
						}

						.nm-status-badge {
							display: inline-block;
							padding: 4px 12px;
							border-radius: 12px;
							font-size: 11px;
							font-weight: 600;
							text-transform: uppercase;
							white-space: nowrap;
						}

						.status-active {
							background: #d4edda;
							color: #155724;
						}

						.status-pending {
							background: #fff3cd;
							color: #856404;
						}

						.status-unsubscribed {
							background: #e2e3e5;
							color: #383d41;
						}
					</style>
					<div style="overflow-x: auto;">
						<div style="margin-bottom: 15px; display: flex; justify-content: space-between; align-items: center;">
							<h2 style="margin: 0;">Subscribers List</h2>
							<a href="<?php echo admin_url( 'admin.php?page=nm-subscribers&export=csv' ); ?>"
								class="button button-primary"
								style="background: #667eea; border-color: #667eea;">
								📥 Export to CSV
							</a>
						</div>
						<table class="nm-subscribers-table widefat">
							<thead>
								<tr>
									<th style="width: 30%;">Email</th>
									<th style="width: 15%;">Name</th>
									<th style="width: 10%;">Status</th>
									<th style="width: 10%;">Source</th>
									<th style="width: 12%;">Subscribed</th>
									<th style="width: 12%;">Last Email</th>
									<th style="width: 11%;">Actions</th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ( $subscribers as $sub ) : ?>
									<tr>
										<td class="nm-email-cell"><strong title="<?php echo esc_attr( $sub->email ); ?>"><?php echo esc_html( $sub->email ); ?></strong></td>
										<td><?php echo esc_html( $sub->name ?: '—' ); ?></td>
										<td>
											<span class="nm-status-badge status-<?php echo strtolower( $sub->status ); ?>">
												<?php echo ucfirst( $sub->status ); ?>
											</span>
										</td>
										<td><?php echo esc_html( $sub->source ?? 'website' ); ?></td>
										<td><span style="white-space: nowrap;"><?php echo date( 'M d, Y', strtotime( $sub->subscribed_date ) ); ?></span></td>
										<td><span style="white-space: nowrap;"><?php echo $sub->last_email_date ? date( 'M d, Y', strtotime( $sub->last_email_date ) ) : '—'; ?></span></td>
										<td>
											<form method="post" style="display: inline; margin: 0;" onsubmit="return confirm('Delete this subscriber?');">
												<?php wp_nonce_field( 'nm_subscriber_action' ); ?>
												<input type="hidden" name="action" value="delete">
												<input type="hidden" name="email" value="<?php echo esc_attr( $sub->email ); ?>">
												<button type="submit" class="button button-small" style="background: #dc3545; color: white; border: none; padding: 6px 12px; border-radius: 4px; cursor: pointer; font-size: 12px;">
													🗑️ Delete
												</button>
											</form>
										</td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					</div>
					<p style="margin-top: 15px; color: #666; font-size: 13px;">
						Showing <?php echo count( $subscribers ); ?> of <?php echo $stats['total']; ?> total subscribers
					</p>
				<?php endif; ?>
			</div>

			<div class="card" style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin-top: 20px;">
				<h3>📋 How to Add Subscription Forms</h3>
				<p>Use these shortcodes anywhere on your site:</p>
				<ul style="list-style: none; padding: 0;">
					<li style="margin-bottom: 10px;"><code style="background: #fff; padding: 8px 12px; border-radius: 4px; display: inline-block;">[nm_subscribe_form]</code> <span style="color: #666; margin-left: 10px;">— Full subscription form</span></li>
					<li style="margin-bottom: 10px;"><code style="background: #fff; padding: 8px 12px; border-radius: 4px; display: inline-block;">[nm_subscribe_compact]</code> <span style="color: #666; margin-left: 10px;">— Compact form (for sidebars)</span></li>
				</ul>
			</div>
		</div>
		<?php
	}
}
?>
