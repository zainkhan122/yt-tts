<?php

/**
 * MCQ Repository
 *
 * Data Access Layer for the dedicated MCQ tables.
 * Prevents raw SQL usage in business logic.
 *
 * @package MCQ_Video_Studio
 */

if (! defined('ABSPATH')) {
    exit;
}

class VS_MCQ_Repository
{

    private static $instance = null;

    private $table_bank;
    private $table_topics;

    public static function get_instance()
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function __construct()
    {
        global $wpdb;
        $this->table_bank   = $wpdb->prefix . 'vs_mcq_bank';
        $this->table_topics = $wpdb->prefix . 'vs_topics';
    }

    /**
     * Insert a new MCQ into the bank.
     * automatically handles hashing and duplicate checks.
     *
     * @FIX: Validate against `VS_Validation_Service` so admins can't bypass
     *       server-side length and correct_index caps by calling the repo directly.
     *
     * @param array $data MCQ data [question_text, options, correct_index, topic_id, etc]
     * @return int|WP_Error Inserted ID or Error
     */
    public function insert_mcq($data)
    {
        global $wpdb;

        // 1. Validate required fields
        if (empty($data['question_text']) || empty($data['options'])) {
            return new WP_Error('missing_data', 'Question text and options are required.');
        }

        // @NEW: Centralized schema validation -- enforce 180/80 char caps + index range
        // @FIX: Previously bypassed entirely; long questions flowed into the bank.
        if (class_exists('VS_Validation_Service')) {
            $validation = VS_Validation_Service::validate_mcq_structure(array(
                'question_text' => $data['question_text'],
                'options'       => is_array($data['options']) ? $data['options'] : json_decode((string) $data['options'], true),
                'correct_index' => isset($data['correct_index']) ? (int) $data['correct_index'] : 0,
            ));
            if (is_wp_error($validation)) {
                return $validation;
            }
        }

        // 2. Generate Hash
        $content_hash = md5(trim($data['question_text']));

        // 3. Check for duplicates (Local Bank)
        $exists_local = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$this->table_bank} WHERE content_hash = %s", $content_hash));
        if ($exists_local) {
            return new WP_Error('duplicate_mcq', 'Duplicate (Local Bank)', array('id' => $exists_local));
        }

        // 3b. Check for duplicates (Parent Plugin - Hybrid Mode)
        // If we have a parent_post_id, we assume it's linked.
        // But what if we are inserting a NEW question that might exist in Parent?
        // We do a text search on wp_posts if strict mode is needed.
        // For performance, we skip strict text search on wp_posts for now unless explicitly requested.

        // 4. Prepare Data
        $insert_data = array(
            'content_hash'  => $content_hash,
            'question_text' => trim($data['question_text']),
            'options'       => is_string($data['options']) ? $data['options'] : wp_json_encode($data['options']),
            'correct_index' => intval($data['correct_index']),
            'topic_id'      => intval($data['topic_id']),
            'parent_post_id' => isset($data['parent_post_id']) ? intval($data['parent_post_id']) : null,
            'difficulty'    => $data['difficulty'] ?? 'medium',
            'status'        => $data['status'] ?? 'draft',
            'explanation'   => $data['explanation'] ?? '',
            'source_ref'    => $data['source_ref'] ?? null,
            'usage_count'   => 0, // Always 0 on insert
            'created_at'    => gmdate('Y-m-d H:i:s'),
        );

        // 5. Insert
        $result = $wpdb->insert($this->table_bank, $insert_data);

        if (false === $result) {
            return new WP_Error('db_error', 'Could not insert MCQ into database: ' . $wpdb->last_error);
        }

        return $wpdb->insert_id;
    }

    /**
     * Find MCQs based on criteria (Mimics WP_Query).
     *
     * @FIX: Honor `id` arg with prepared SQL. Previously the WHERE was always `1=1`,
     *       so `find(array('id' => $id))` returned the whole bank.
     *
     * @param array $args
     * @return array
     */
    public function find($args = array())
    {
        global $wpdb;

        $defaults = array(
            'id'       => 0,
            'topic_id' => 0,
            'status'   => 'approved',
            'limit'    => 10,
            'offset'   => 0,
            'orderby'  => 'created_at',
            'order'    => 'DESC',
        );
        $args     = wp_parse_args($args, $defaults);

        $where = array('1=1');
        $vals  = array();

        // @FIX: Allow exact-id lookup via prepared clause.
        if (! empty($args['id'])) {
            $where[] = 'id = %d';
            $vals[]  = (int) $args['id'];
        }

        if (! empty($args['topic_id'])) {
            $where[] = 'topic_id = %d';
            $vals[]  = $args['topic_id'];
        }

        if (! empty($args['status'])) {
            $where[] = 'status = %s';
            $vals[]  = $args['status'];
        }

        $where_sql = implode(' AND ', $where);
        $limit     = absint($args['limit']);
        $offset    = absint($args['offset']);
        $orderby   = sanitize_sql_orderby($args['orderby'] . ' ' . $args['order']);

        $sql = "SELECT * FROM {$this->table_bank} WHERE $where_sql ORDER BY $orderby LIMIT %d OFFSET %d";
        $vals[] = $limit;
        $vals[] = $offset;

        return $wpdb->get_results($wpdb->prepare($sql, $vals), ARRAY_A);
    }

    /**
     * Get topic by ID or Slug.
     * @FIX 1.4.9.51: accept a RAW topic NAME too. Topics are stored with
     * `slug = sanitize_title(name)`; callers (calendar drag-save, job creation)
     * pass the human-readable name, so a bare `WHERE slug = <name>` always missed
     * and every lookup returned null → calendar re-stamps silently did nothing.
     * Now: numeric → by id; else try the raw string as slug, then the sanitized slug.
     */
    public function get_topic($id_or_slug)
    {
        global $wpdb;
        if (is_numeric($id_or_slug)) {
            return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table_topics} WHERE id = %d", $id_or_slug), ARRAY_A);
        }
        $slug = sanitize_title($id_or_slug);
        // Try the value as-is first (already a slug), then the sanitized form.
        foreach (array_unique(array((string) $id_or_slug, $slug)) as $candidate) {
            if ($candidate === '') {
                continue;
            }
            $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->table_topics} WHERE slug = %s", $candidate), ARRAY_A);
            if ($row) {
                return $row;
            }
        }
        return null;
    }

    /**
     * Create a topic.
     */
    public function create_topic($name, $type = 'subject', $parent_id = 0)
    {
        global $wpdb;
        $slug = sanitize_title($name);

        // Check exists
        $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$this->table_topics} WHERE slug = %s", $slug));
        if ($exists) {
            return $exists;
        }

        $wpdb->insert(
            $this->table_topics,
            array(
                'name'      => $name,
                'slug'      => $slug,
                'type'      => $type,
                'parent_id' => $parent_id,
            )
        );
        return $wpdb->insert_id;
    }
    /**
     * Get count of items in the bank.
     * @NEW 2026-02-09: For Dashboard Stats
     *
     * @param string $status Filter by status (optional)
     * @param string $date_filter 'today', 'total' (optional)
     * @return int Count
     */
    public function count_items($status = null, $date_filter = 'total')
    {
        global $wpdb;

        $sql = "SELECT COUNT(*) FROM {$this->table_bank}";
        $where = array();
        $args  = array();

        if ($status) {
            $where[] = 'status = %s';
            $args[]  = $status;
        }

        if ($date_filter === 'today') {
            $where[] = 'DATE(created_at) = CURDATE()';
        }

        if (!empty($where)) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }

        if (!empty($args)) {
            $query = $wpdb->prepare($sql, $args);
            return (int) $wpdb->get_var($query);
        } else {
            return (int) $wpdb->get_var($sql);
        }
    }

    /**
     * Update an existing MCQ in the bank.
     * @NEW 2026-08-03: For MCQ Editor
     *
     * @param int   $id   MCQ ID
     * @param array $data MCQ data [question_text, options, correct_index, etc]
     * @return bool|WP_Error
     */
    public function update_mcq($id, $data)
    {
        global $wpdb;

        if (empty($id)) {
            return new WP_Error('missing_id', 'MCQ ID is required.');
        }

        // Validate required fields
        if (empty($data['question_text']) || empty($data['options'])) {
            return new WP_Error('missing_data', 'Question text and options are required.');
        }

        // Validate options count
        $options = is_array($data['options']) ? $data['options'] : json_decode((string) $data['options'], true);
        if (!is_array($options) || count($options) !== 4) {
            return new WP_Error('invalid_options', 'Exactly 4 options are required.');
        }

        // Validate correct_index
        $correct_index = isset($data['correct_index']) ? (int) $data['correct_index'] : 0;
        if ($correct_index < 0 || $correct_index > 3) {
            return new WP_Error('invalid_correct_index', 'Correct index must be 0-3.');
        }

        // Generate new hash
        $content_hash = md5(trim($data['question_text']));

        // Check for duplicate (excluding self)
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$this->table_bank} WHERE content_hash = %s AND id != %d",
            $content_hash, $id
        ));
        if ($exists) {
            return new WP_Error('duplicate_mcq', 'Duplicate question exists.', array('id' => $exists));
        }

        $update_data = array(
            'content_hash'  => $content_hash,
            'question_text' => trim($data['question_text']),
            'options'       => wp_json_encode($options),
            'correct_index' => $correct_index,
            'difficulty'    => $data['difficulty'] ?? 'medium',
            'status'        => $data['status'] ?? 'approved',
            'explanation'   => $data['explanation'] ?? '',
            'source_ref'    => $data['source_ref'] ?? null,
        );

        $result = $wpdb->update(
            $this->table_bank,
            $update_data,
            array('id' => $id),
            array('%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s'),
            array('%d')
        );

        if (false === $result) {
            return new WP_Error('db_error', 'Could not update MCQ: ' . $wpdb->last_error);
        }

        return true;
    }
}
