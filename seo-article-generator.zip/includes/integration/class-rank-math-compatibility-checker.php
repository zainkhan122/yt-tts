<?php

/**
 * Rank Math Compatibility Checker
 * 
 * Validates Rank Math installation and displays admin notices if misconfigured.
 *
 * @package SEO_Article_Generator
 * @since   2.2.0
 */

namespace SEO_Article_Generator\Integration;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Rank Math Compatibility Checker
 * 
 * Validates that Rank Math is active and schema is configured correctly
 */
class RankMath_Compatibility_Checker
{

    /**
     * Check if Rank Math is active
     * @MODIFIED 2025-12-16 v2.2.0: Created for E-E-A-T dependency validation
     */
    public function is_active()
    {
        return defined('RANK_MATH_VERSION');
    }

    /**
     * Check if schema module is enabled
     */
    public function is_schema_enabled()
    {
        if (! $this->is_active()) {
            return false;
        }

        return \RankMath\Helper::is_module_active('rich-snippet');
    }

    /**
     * Get current schema type for posts
     */
    public function get_post_schema_type()
    {
        if (! $this->is_active()) {
            return null;
        }

        return get_option('rank_math_rich_snippet_post_type', 'Article');
    }

    /**
     * Validate configuration and return issues
     */
    public function validate_configuration()
    {
        $issues = [];

        if (! $this->is_active()) {
            $issues[] = [
                'severity' => 'critical',
                'message'  => 'Rank Math SEO plugin is not active. E-E-A-T schema enhancement requires Rank Math.',
                'action'   => 'Install and activate Rank Math SEO plugin.',
            ];
            return $issues;
        }

        if (! $this->is_schema_enabled()) {
            $issues[] = [
                'severity' => 'error',
                'message'  => 'Rank Math Schema module is not enabled.',
                'action'   => 'Go to Rank Math → Dashboard → Modules → Enable "Rich Snippet"',
            ];
        }

        $schema_type = $this->get_post_schema_type();
        if (! in_array($schema_type, ['Article', 'TechArticle', 'BlogPosting'], true)) {
            $issues[] = [
                'severity' => 'warning',
                'message'  => sprintf('Post schema type is set to "%s". E-E-A-T enhancements work best with Article schemas.', $schema_type),
                'action'   => 'Go to Rank Math → Titles & Meta → Posts → Schema Type → Select "Article" or "TechArticle"',
            ];
        }

        return $issues;
    }

    /**
     * Display admin notice if configuration issues exist
     */
    public function display_admin_notice()
    {
        $issues = $this->validate_configuration();

        if (empty($issues)) {
            return;
        }

        foreach ($issues as $issue) {
            $class = $issue['severity'] === 'critical' ? 'error' : 'warning';
?>
            <div class="notice notice-<?php echo esc_attr($class); ?>">
                <p>
                    <strong>SEO Article Generator E-E-A-T:</strong>
                    <?php echo esc_html($issue['message']); ?>
                </p>
                <p><?php echo esc_html($issue['action']); ?></p>
            </div>
<?php
        }
    }
}
