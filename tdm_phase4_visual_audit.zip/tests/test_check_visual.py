#!/usr/bin/env python3
from __future__ import annotations
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path("/home/user")
CHK = [sys.executable, str(ROOT / "tools/check_visual.py")]
PLAN = [sys.executable, str(ROOT / "tools/plan_visual.py")]


class Visual(unittest.TestCase):
    def test_usage(self):
        p = subprocess.run(CHK, capture_output=True, text=True)
        self.assertEqual(p.returncode, 1)

    def test_s02_owner_pass(self):
        subprocess.run(PLAN + [str(ROOT / "videos/short_s02")], check=True, capture_output=True)
        p = subprocess.run(CHK + [str(ROOT / "videos/short_s02")], capture_output=True, text=True)
        self.assertEqual(p.returncode, 0, p.stdout + p.stderr)
        self.assertIn("mechanism", p.stdout)

    def test_clone_doors_fail(self):
        d = Path(tempfile.mkdtemp()) / "short_s99"
        d.mkdir()
        html = (ROOT / "videos/short_s02/index.html").read_text()
        (d / "index.html").write_text(html)
        (d / "voiceover.txt").write_text("Hello maze.\nWrite it below.\n")
        (d / "beat_needs.json").write_text(json.dumps({
            "needs": [
                {"start": "Hello", "kind": "diagram", "hf": "door_soul", "label": "X"},
                {"start": "Write", "kind": "object", "hf": "phone_bubble", "label": "Y"},
            ]
        }))
        subprocess.run(PLAN + [str(d)], capture_output=True)
        p = subprocess.run(CHK + [str(d)], capture_output=True, text=True)
        self.assertEqual(p.returncode, 3, p.stdout)
        self.assertNotEqual(p.returncode, 2)

    def test_consecutive_hf_fail(self):
        d = Path(tempfile.mkdtemp()) / "short_s98"
        d.mkdir()
        (d / "voiceover.txt").write_text("A.\nB.\n")
        (d / "index.html").write_text('<div id="root"></div>')
        (d / "beat_needs.json").write_text(json.dumps({
            "needs": [
                {"start": "A", "kind": "diagram", "hf": "still_label"},
                {"start": "B", "kind": "diagram", "hf": "still_label"},
            ]
        }))
        subprocess.run(PLAN + [str(d)], capture_output=True)
        p = subprocess.run(CHK + [str(d)], capture_output=True, text=True)
        self.assertEqual(p.returncode, 3, p.stdout)
        self.assertIn("consecutive", p.stdout)

    def test_never_exit_2(self):
        p = subprocess.run(CHK, capture_output=True, text=True)
        self.assertNotEqual(p.returncode, 2)

    def test_five_identities(self):
        data = json.loads((ROOT / "tools/visual_identities.json").read_text())
        modes = {i["mode"] for i in data["identities"]}
        self.assertEqual(modes, {"symbol", "character", "mechanism", "environment", "object"})


if __name__ == "__main__":
    unittest.main()
