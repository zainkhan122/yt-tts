<?php

namespace DIT\TrendStudio\Services;

use DIT\TrendStudio\Database\Queue_Table;

class Social_Queue_Manager
{
    private Collage_Generator $generator;
    private $logger;

    // Drip rules option key
    const RULES_OPTION = 'dit_ts_drip_rules';

    // Active drip job transient prefix (used to pass image to Bit Social filter)
    const ACTIVE_JOB_TRANSIENT = 'dit_ts_active_drip_job_';

    public function __construct(Collage_Generator $generator, $logger = null)
    {
        $this->generator = $generator;
        $this->logger = $logger;
    }

    // ── Public API ─────────────────────────────────────────────────────────

    /**
     * Build drip queue for a post based on its vertical/category rules.
     * Called once when post transitions to publish or future.
     */
    public function build_queue(int $post_id): void
    {
        // @MODIFIED 2026-05-08 - Pre-check: Skip queue build entirely if no social
        // sharing integration is available. Without Bit Social or X direct API credentials,
        // every drip job will permanently fail, accumulating dead rows. This prevents the
        // @MODIFIED 2026-05-11 - Check for Jetpack, Bit Social, or X API
        // @MODIFIED 2026-06-07 - Align with Social_Bootstrap/Scheduler detection.
        // Legacy has_action() hooks (jetpack_publicize_on_publish, publicize_jetpack_on_publish)
        // don't exist in modern Jetpack Social. class_exists() fails during transition_post_status
        // due to autoloader timing. The option is the authoritative gate used by all other Jetpack
        // code paths in Social_Bootstrap.php, Scheduler.php, and SettingsPage.php.
        $has_jetpack = (bool) \get_option('dit_ts_jetpack_enabled', false);
        $has_bit_social = (
            \has_action('bit_social_manual_share')
            || \has_action('bit_social_post_now')
            || class_exists('\\BitApps\\BtSocial\\Modules\\WpPosts\\WpPostsController')
            || class_exists('\\BitApps\\Social\\Modules\\WpPosts\\WpPostsController')
        );
        $x_consumer_key = (string) \get_option('dit_ts_x_consumer_key', '');
        $x_access_token = (string) \get_option('dit_ts_x_access_token', '');
        $has_x_direct = (!empty($x_consumer_key) && !empty($x_access_token));

        if (!$has_jetpack && !$has_bit_social && !$has_x_direct) {
            // @MODIFIED 2026-05-08 - Also clean stale pending rows for this post that were
            // inserted before Bit Social was deactivated. Without this, those rows sit in
            // 'pending' forever and process_due_jobs() will keep retrying them.
            global $wpdb;
            $table = Queue_Table::get_table_name();
            $wpdb->query($wpdb->prepare(
                "DELETE FROM {$table} WHERE post_id = %d AND status = 'pending'",
                $post_id
            ));
            if ($this->logger) {
                $this->logger->warning("Social queue build skipped for post {$post_id}: No sharing integration available (Jetpack not enabled, Bit Social not active, X API not configured).");
            }
            return;
        }

        $vertical = $this->resolve_vertical($post_id);
        $rules    = $this->get_rules_for_vertical($vertical);

        if (empty($rules)) {
            return;
        }

        $urdu_head = get_post_meta($post_id, '_dit_ts_urdu_heading', true);
        $urdu_desc = get_post_meta($post_id, '_dit_ts_urdu_description', true);
        $hashtags  = get_post_meta($post_id, '_dit_ts_hashtags', true);
        if (is_array($hashtags)) {
            $hashtags = implode(' ', $hashtags);
        }

	if (empty($urdu_head) || empty($urdu_desc)) {
		global $wpdb;
		$row = $wpdb->get_row($wpdb->prepare(
			"SELECT urdu_heading, urdu_description, hashtags
			FROM {$wpdb->prefix}dit_ts_social_meta
			WHERE post_id = %d AND status IN ('pending','completed','published')
			ORDER BY id DESC LIMIT 1",
			$post_id
		), ARRAY_A);
            if ($row) {
                $urdu_head = $urdu_head ?: (string) $row['urdu_heading'];
                $urdu_desc = $urdu_desc ?: (string) $row['urdu_description'];
                $hashtags = $hashtags ?: (string) $row['hashtags'];
            }
        }

        $link      = get_permalink($post_id);

        // Resolve all gallery images upfront
        $gallery_ids  = (array)(get_post_meta($post_id, '_dit_ts_images', true) ?: []);
        $collage_url  = \DIT\TrendStudio\Core\Social_Bootstrap::resolve_collage_url($post_id);

        global $wpdb;
        $table       = Queue_Table::get_table_name();
        $publish_time = current_time('timestamp');

        foreach ($rules as $slot => $rule) {
            if (empty($rule['enabled'])) {
                continue;
            }

            $image_url = $this->resolve_image_url(
                $rule['image_source'],
                $gallery_ids,
                $collage_url,
                $post_id
            );

            if (empty($image_url)) {
                continue; // Skip slots with no resolvable image
            }

            $message = $this->render_message_template(
                $rule['message_template'] ?? "{urdu_head}\n\n{urdu_desc}\n\n{hashtags}\n\n{link}",
                $urdu_head,
                $urdu_desc,
                $hashtags,
                $link
            );

            $delay_seconds   = ((int)($rule['delay_minutes'] ?? 0)) * MINUTE_IN_SECONDS;
            $scheduled_at    = gmdate('Y-m-d H:i:s', $publish_time + $delay_seconds);
            $networks_string = implode(',', array_filter((array)($rule['networks'] ?? [])));

            $sent_exists = (int) $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM $table WHERE post_id = %d AND share_slot = %d AND status IN ('sent','processing')",
                $post_id,
                $slot
            ));

            if ($sent_exists) {
                continue;
            }

            $wpdb->query($wpdb->prepare(
                "DELETE FROM $table WHERE post_id = %d AND share_slot = %d AND status NOT IN ('sent','processing')",
                $post_id,
                $slot
            ));

            $wpdb->insert($table, [
                'post_id'      => $post_id,
                'share_slot'   => (int)$slot,
                'image_url'    => $image_url,
                'message'      => $message,
                'networks'     => $networks_string,
                'scheduled_at' => $scheduled_at,
                'status'       => 'pending',
                'attempts'     => 0,
            ], ['%d', '%d', '%s', '%s', '%s', '%s', '%s', '%d']);
        }
    }

    /**
     * Process jobs that are due. Called by WP-Cron every 5 minutes.
     * Picks up to 3 jobs per run to avoid timeouts.
     */
    public function process_due_jobs(): void
    {
        global $wpdb;
        $table    = Queue_Table::get_table_name();
        $batch    = 3;
        $now      = current_time('mysql', true);
        $lock_tok = wp_generate_uuid4();

        $wpdb->query($wpdb->prepare(
            "UPDATE {$table}
             SET    status = 'processing',
                    attempts = attempts + 1,
                    lock_token = %s
             WHERE  status = 'pending'
               AND  scheduled_at <= %s
               AND  attempts < 3
             LIMIT  %d",
            $lock_tok,
            $now,
            $batch
        ));

        if ($wpdb->rows_affected === 0) {
            return;
        }

        $jobs = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table}
             WHERE  lock_token = %s",
            $lock_tok
        ));

        foreach ($jobs as $job) {
            $success    = $this->dispatch_job($job);
            $exhausted  = !$success && $job->attempts >= 3;
            $new_status = $success ? 'sent' : ($exhausted ? 'failed' : 'pending');

		$update_data = ['status' => $new_status, 'lock_token' => null];
		$update_format = ['%s', '%s'];

		$wpdb->update($table, $update_data, ['id' => $job->id], $update_format, ['%d']);

            if (!$success && $this->logger) {
                // @MODIFIED 2026-05-05 - Finding 4: Escalate to ERROR on the final exhaustion
                // attempt so the persistent integration failure surfaces clearly in logs.
                if ($exhausted) {
                    $this->logger->error(
                        "Drip job #{$job->id} for post {$job->post_id} permanently failed after {$job->attempts} attempts. " .
                        "Social sharing is not working. Check Bit Social plugin status and trigger configuration."
                    );
                } else {
                    $this->logger->warning("Drip job #{$job->id} for post {$job->post_id} failed (attempt {$job->attempts})");
                }
            }
        }
    }

    /**
     * Resolve image URL from image_source setting string.
     */
    public function resolve_image_url(
        string $source,
        array $gallery_ids,
        string $collage_url,
        int $post_id
    ): string {
        if ($source === 'collage') {
            return $collage_url;
        }

        if ($source === 'featured') {
            $thumb_id = (int)get_post_thumbnail_id($post_id);
            return $thumb_id ? (wp_get_attachment_image_url($thumb_id, 'full') ?: '') : '';
        }

        if (str_starts_with($source, 'gallery_index:')) {
            $index  = (int)substr($source, strlen('gallery_index:'));
            $att_id = $gallery_ids[$index] ?? null;
            return $att_id ? (wp_get_attachment_url((int)$att_id) ?: '') : '';
        }

        return '';
    }

    // ── Rules Management ───────────────────────────────────────────────────

    public function get_all_rules(): array
    {
        return (array)(get_option(self::RULES_OPTION) ?: $this->default_rules());
    }

    public function get_rules_for_vertical(string $vertical): array
    {
        $all = $this->get_all_rules();
        return $all[$vertical] ?? $all['general'] ?? [];
    }

    public function save_rules(array $rules): void
    {
        update_option(self::RULES_OPTION, $rules, false);
    }

    // ── Private Helpers ────────────────────────────────────────────────────

    private function dispatch_job(object $job): bool
    {
        $rule        = $this->get_rule_for_slot($job->post_id, $job->share_slot);
        $gallery_ids = array_filter((array) get_post_meta($job->post_id, '_dit_ts_images', true));
        $collage_url = \DIT\TrendStudio\Core\Social_Bootstrap::resolve_collage_url($job->post_id);

        $image_sources = (array) ($rule['image_sources'] ?? [$rule['image_source'] ?? 'collage']);
        $skip_featured = (bool) ($rule['skip_featured'] ?? false);
        $image_count   = max(1, (int) ($rule['image_count'] ?? 1));

        $ordered_images = [];
        foreach ($image_sources as $source) {
            if (count($ordered_images) >= $image_count) {
                break;
            }
            $url = $this->resolve_image_url($source, $gallery_ids, $collage_url, $job->post_id);
            if (!empty($url)) {
                if ($skip_featured) {
                    $thumb_id  = (int) get_post_thumbnail_id($job->post_id);
                    $thumb_url = $thumb_id ? wp_get_attachment_image_url($thumb_id, 'full') : '';
                    if ($thumb_url && $url === $thumb_url) {
                        continue;
                    }
                }
                $ordered_images[] = $url;
            }
        }

        $primary_image = $ordered_images[0] ?? $job->image_url;

		set_transient(
			self::ACTIVE_JOB_TRANSIENT . $job->post_id,
			[
				'image_url' => $primary_image,
				'images' => $ordered_images,
				'image_count' => $image_count,
				'skip_featured'=> $skip_featured,
				'message' => $job->message,
				'networks' => explode(',', $job->networks),
				'job_id' => $job->id,
			],
			30 * MINUTE_IN_SECONDS
		);

        try {
            $result = $this->trigger_bit_social_share((int)$job->post_id, $job);
        } catch (\Throwable $e) {
            global $wpdb;
            $wpdb->update(
                Queue_Table::get_table_name(),
                ['last_error' => $e->getMessage()],
                ['id' => $job->id]
            );
            delete_transient(self::ACTIVE_JOB_TRANSIENT . $job->post_id);
            return false;
        }

        return $result;
    }

    private function get_rule_for_slot(int $post_id, int $slot): array
    {
        $vertical = $this->resolve_vertical($post_id);
        $rules    = $this->get_rules_for_vertical($vertical);
        return $rules[$slot] ?? [];
    }

    /**
     * Trigger Bit Social to share a post programmatically.
     *
     * @MODIFIED 2026-05-05 - Finding 4: Widened trigger probe; added last_error persistence
     *   on permanent failure; escalated final-attempt logging to ERROR.
     */
    private function trigger_bit_social_share(int $post_id, object $job): bool
    {
        // Strategy 1: Bit Social's documented action hook (safest, future-proof).
        // Covers plugin versions that register 'bit_social_manual_share'.
        if (has_action('bit_social_manual_share')) {
            do_action('bit_social_manual_share', $post_id);
            return true;
        }

        // Strategy 1b: Alternative hook name used in some Bit Social versions.
        if (has_action('bit_social_post_now')) {
            do_action('bit_social_post_now', $post_id);
            return true;
        }

        // Strategy 2: Instance method invocation (NOT static).
        // Try both known controller class locations across Bit Social versions.
        $controller_candidates = [
            '\\BitApps\\BtSocial\\Modules\\WpPosts\\WpPostsController',
            '\\BitApps\\Social\\Modules\\WpPosts\\WpPostsController',
        ];
        foreach ($controller_candidates as $controller_class) {
            if (!class_exists($controller_class)) {
                continue;
            }
            try {
                $controller = new $controller_class();
                if (method_exists($controller, 'shareNow')) {
                    $controller->shareNow($post_id);
                    return true;
                }
                if (method_exists($controller, 'share')) {
                    $controller->share($post_id);
                    return true;
                }
            } catch (\Throwable $e) {
                if ($this->logger) {
                    $this->logger->warning("Bit Social instance call ({$controller_class}) failed: " . $e->getMessage());
                }
            }
        }

        // Strategy 3: X direct API (always available if configured, no Bit Social needed).
        $networks = explode(',', $job->networks);
        if (in_array('x', $networks, true) || in_array('twitter', $networks, true)) {
            $this->post_to_x_direct($job->message, $job->image_url, $post_id);
            return true;
        }

        // No Bit Social plugin and no X direct configured — skip gracefully.
        // Bit Social is optional; no warning needed when it's absent.
        if ($this->logger) {
            $this->logger->info("Social share skipped for post {$post_id}: Bit Social not active and X direct not in networks.");
        }

        return true;
    }

    /**
     * Direct X API v2 post (Free tier: 500 posts/month).
     */
    private function post_to_x_direct(string $message, string $image_url, int $post_id): void
    {
        $consumer_key    = get_option('dit_ts_x_consumer_key');
        $consumer_secret = get_option('dit_ts_x_consumer_secret');
        $access_token    = get_option('dit_ts_x_access_token');
        $token_secret    = get_option('dit_ts_x_token_secret');

        if (!$consumer_key || !$access_token) {
            return; // Not configured
        }

        // Step 1: Upload media
        $media_id = $this->x_upload_media($image_url, $consumer_key, $consumer_secret, $access_token, $token_secret);

        // Step 2: Post tweet
        $tweet_body = ['text' => mb_substr($message, 0, 280)];
        if ($media_id) {
            $tweet_body['media'] = ['media_ids' => [$media_id]];
        }

        $this->x_api_request(
            'POST',
            'https://api.twitter.com/2/tweets',
            $tweet_body,
            $consumer_key,
            $consumer_secret,
            $access_token,
            $token_secret
        );
    }

    private function x_upload_media(string $image_url, string $ck, string $cs, string $at, string $ts): ?string
    {
        $bytes = @file_get_contents($image_url);
        if (!$bytes) return null;

        $response = $this->x_api_request(
            'POST',
            'https://upload.twitter.com/1.1/media/upload.json',
            ['media_data' => base64_encode($bytes)],
            $ck, $cs, $at, $ts,
            true // form-encoded
        );

        return $response['media_id_string'] ?? null;
    }

    private function x_api_request(
        string $method,
        string $url,
        array $body,
        string $ck, string $cs, string $at, string $ts,
        bool $form_encoded = false
    ): array {
        $oauth = [
            'oauth_consumer_key'     => $ck,
            'oauth_nonce'            => wp_generate_uuid4(),
            'oauth_signature_method' => 'HMAC-SHA1',
            'oauth_timestamp'        => time(),
            'oauth_token'            => $at,
            'oauth_version'          => '1.0',
        ];

        $base_params = array_merge($oauth, $form_encoded ? $body : []);
        ksort($base_params);
        $param_string = http_build_query($base_params, '', '&', PHP_QUERY_RFC3986);
        $base_string  = strtoupper($method) . '&' . rawurlencode($url) . '&' . rawurlencode($param_string);
        $signing_key  = rawurlencode($cs) . '&' . rawurlencode($ts);
        $oauth['oauth_signature'] = base64_encode(hash_hmac('sha1', $base_string, $signing_key, true));

        $auth_header = 'OAuth ' . implode(', ', array_map(
            fn($k, $v) => rawurlencode($k) . '="' . rawurlencode($v) . '"',
            array_keys($oauth),
            $oauth
        ));

        $args = [
            'method'  => $method,
            'headers' => ['Authorization' => $auth_header],
            'timeout' => 15,
        ];

        if ($form_encoded) {
            $args['headers']['Content-Type'] = 'application/x-www-form-urlencoded';
            $args['body'] = http_build_query($body);
        } else {
            $args['headers']['Content-Type'] = 'application/json';
            $args['body'] = wp_json_encode($body);
        }

        $resp = wp_remote_request($url, $args);
        if (is_wp_error($resp)) return [];
        return json_decode(wp_remote_retrieve_body($resp), true) ?: [];
    }

    private function resolve_vertical(int $post_id): string
    {
        $meta = get_post_meta($post_id, 'vertical', true);
        if ($meta) return sanitize_key($meta);

        // Fallback: check WP category slugs
        $cats = wp_get_post_categories($post_id, ['fields' => 'slugs']);
        if (in_array('fashion', $cats, true)) return 'fashion';
        if (in_array('showbiz', $cats, true)) return 'showbiz';

        return 'general';
    }

    /**
     * Separates clean description from embedded hashtags.
     * Ports the original regex from sync_to_jetpack() so drip shares
     * get the same intelligent parsing as Jetpack messages.
     *
     * Handles both cases:
     *  Case A: $hashtags meta exists → use it directly
     *  Case B: Hashtags embedded at end of $urdu_desc → extract via regex
     *
     * @return array{desc: string, tags: string}
     */
    public static function split_desc_and_hashtags(string $urdu_desc, string $hashtags): array
    {
        $clean_desc = wp_strip_all_tags(html_entity_decode(trim($urdu_desc), ENT_QUOTES | ENT_HTML5, 'UTF-8'));
        $clean_tags = wp_strip_all_tags(trim($hashtags));

        // Case A: Separate hashtags meta already exists
        if ($clean_tags !== '') {
            return [
                'desc' => $clean_desc,
                'tags' => $clean_tags,
            ];
        }

        // Case B: Hashtags embedded in description — extract via regex
        // Matches Urdu/Arabic hashtags: #[\w\x{0600}-\x{06FF}]+
        $pattern = '/^(.*?)((?:\s*(?:#[\w\x{0600}-\x{06FF}]+)\s*)+)$/us';

        if (preg_match($pattern, $clean_desc, $matches)) {
            return [
                'desc' => wp_strip_all_tags(trim($matches[1])),
                'tags' => trim($matches[2]),
            ];
        }

        // Case C: No hashtags anywhere
        return [
            'desc' => $clean_desc,
            'tags' => '',
        ];
    }
    
    /**
     * Forces pretty permalink even for draft/future posts.
     * Ported from original sync_to_jetpack() inline closure.
     */
    public function resolve_permalink(string $post_id_or_url): string
    {
        $post_id = is_numeric($post_id_or_url) ? (int)$post_id_or_url : url_to_postid($post_id_or_url);
        $p = get_post($post_id);
        if (!$p) return get_permalink($post_id);

        $old = $p->post_status;
        if (in_array($old, ['draft', 'auto-draft', 'future'], true)) {
            $p->post_status = 'publish';
        }
        $link = get_permalink($p);
        $p->post_status = $old;
        return $link;
    }

    /**
     * Updated render_message_template — now uses hashtag splitter.
     */
    private function render_message_template(
        string $template,
        string $urdu_head,
        string $urdu_desc,
        string $hashtags,
        string $link
    ): string {
        // Use shared splitter — same logic as sync_to_jetpack()
        $parsed = self::split_desc_and_hashtags($urdu_desc, $hashtags);

        // Pretty permalink fallback for draft/future posts
        $permalink = $this->resolve_permalink($link);

        $message = str_replace(
            ['{urdu_head}', '{urdu_desc}', '{hashtags}', '{link}', '\n'],
            [
                wp_strip_all_tags(html_entity_decode(trim($urdu_head), ENT_QUOTES | ENT_HTML5, 'UTF-8')),
                $parsed['desc'],
                $parsed['tags'],
                $permalink,
                "\n",
            ],
            $template
        );

        return preg_replace("/\n{3,}/", "\n\n", trim($message));
    }

    private function default_rules(): array
    {
        return [
            'fashion' => [
                1 => [
                    'enabled'          => true,
                    'delay_minutes'    => 0,
                    'networks'         => ['facebook', 'instagram', 'x', 'pinterest'],
                    'image_source'    => 'collage',
                    'image_sources'    => ['collage'],
                    'image_count'      => 1,
                    'skip_featured'    => true,
                    'message_template' => "{urdu_head}\n\n{urdu_desc}\n\n{hashtags}\n\n{link}",
                ],
                2 => [
                    'enabled'          => true,
                    'delay_minutes'    => 120,
                    'networks'         => ['pinterest', 'instagram'],
                    'image_source'    => 'featured',
                    'image_sources'    => ['featured'],
                    'image_count'      => 1,
                    'skip_featured'    => false,
                    'message_template' => "{urdu_head}\n\n{hashtags}\n\n{link}",
                ],
                3 => [
                    'enabled'          => true,
                    'delay_minutes'    => 300,
                    'networks'         => ['pinterest', 'x'],
                    'image_source'    => 'featured',
                    'image_sources'    => ['featured'],
                    'image_count'      => 1,
                    'skip_featured'    => false,
                    'message_template' => "{urdu_head}\n\n{hashtags}\n\n{link}",
                ],
                4 => [
                    'enabled'          => true,
                    'delay_minutes'    => 480,
                    'networks'         => ['pinterest', 'facebook'],
                    'image_source'    => 'featured',
                    'image_sources'    => ['featured'],
                    'image_count'      => 1,
                    'skip_featured'    => false,
                    'message_template' => "{urdu_head}\n\n{hashtags}\n\n{link}",
                ],
            ],
            'showbiz' => [
                1 => [
                    'enabled'          => true,
                    'delay_minutes'    => 0,
                    'networks'         => ['facebook', 'instagram', 'x'],
                    'image_source'    => 'collage',
                    'image_sources'    => ['collage'],
                    'image_count'      => 1,
                    'skip_featured'    => true,
                    'message_template' => "{urdu_head}\n\n{urdu_desc}\n\n{hashtags}\n\n{link}",
                ],
                2 => [
                    'enabled'          => true,
                    'delay_minutes'    => 180,
                    'networks'         => ['x', 'facebook'],
                    'image_source'    => 'featured',
                    'image_sources'    => ['featured'],
                    'image_count'      => 1,
                    'skip_featured'    => false,
                    'message_template' => "{urdu_head}\n\n{hashtags}\n\n{link}",
                ],
            ],
            'general' => [
                1 => [
                    'enabled'          => true,
                    'delay_minutes'    => 0,
                    'networks'         => ['facebook', 'x'],
                    'image_source'    => 'collage',
                    'image_sources'    => ['collage'],
                    'image_count'      => 1,
                    'skip_featured'    => true,
                    'message_template' => "{urdu_head}\n\n{urdu_desc}\n\n{hashtags}\n\n{link}",
                ],
            ],
        ];
    }
}
