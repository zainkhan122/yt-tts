<?php

/**
 * Plugin_Time — Canonical time utility for SEO Article Generator.
 *
 * ARCHITECTURE RULE (enforced here, nowhere else):
 *   - All DB columns store UTC datetimes (Y-m-d H:i:s in UTC).
 *   - All internal arithmetic uses pure UTC Unix timestamps (time()).
 *   - Site timezone is applied ONLY at display / human-output edges via wp_date().
 *   - current_time('timestamp') is BANNED from storage/comparison (it is a fake UTC+offset int).
 *   - date() and gmdate() are BANNED (use this class instead).
 *   - UNIX_TIMESTAMP() in raw MySQL is BANNED (server TZ may differ from WP TZ).
 *
 * @package SEO_Article_Generator\Utils
 * @since   2026-03-09
 */

namespace SEO_Article_Generator\Utils;

if (! defined('ABSPATH')) {
    exit;
}

final class Plugin_Time
{
    // -------------------------------------------------------------------------
    // UTC SOURCE OF TRUTH
    // -------------------------------------------------------------------------

    /**
     * Current Unix timestamp (UTC). Use for all arithmetic.
     */
    public static function now_utc_ts(): int
    {
        return time();
    }

    /**
     * Current time as a UTC MySQL string.
     * Use for all DB inserts/updates where the column stores UTC.
     */
    public static function utc_mysql_now(): string
    {
        return gmdate('Y-m-d H:i:s', self::now_utc_ts());
    }

    // -------------------------------------------------------------------------
    // UTC ↔ UTC CONVERSIONS
    // -------------------------------------------------------------------------

    /**
     * Format a UTC Unix timestamp as a UTC MySQL datetime string.
     *
     * @param int $utc_ts UTC Unix timestamp.
     * @return string 'Y-m-d H:i:s' in UTC.
     */
    public static function utc_mysql_from_utc_ts(int $utc_ts): string
    {
        return gmdate('Y-m-d H:i:s', $utc_ts);
    }

    /**
     * Parse a UTC MySQL datetime string into a UTC Unix timestamp.
     *
     * @param string $utc_mysql UTC-stored 'Y-m-d H:i:s'.
     * @return int UTC Unix timestamp.
     */
    public static function utc_ts_from_utc_mysql(string $utc_mysql): int
    {
        $dt = new \DateTimeImmutable($utc_mysql, new \DateTimeZone('UTC'));
        return $dt->getTimestamp();
    }

    // -------------------------------------------------------------------------
    // SITE TIMEZONE ↔ UTC CONVERSIONS
    // -------------------------------------------------------------------------

    /**
     * Convert a site-local MySQL datetime string (as stored by WP in post_date)
     * into a UTC MySQL datetime string.
     * Wraps WP's get_gmt_from_date() natively, but uses robust DateTime bounds for DST safety.
     *
     * @param string $site_mysql Site-local 'Y-m-d H:i:s'.
     * @return string UTC 'Y-m-d H:i:s'.
     */
    public static function utc_mysql_from_site_mysql(string $site_mysql): string
    {
        try {
            $site_dt = new \DateTimeImmutable($site_mysql, \wp_timezone());
            return $site_dt->setTimezone(new \DateTimeZone('UTC'))->format('Y-m-d H:i:s');
        } catch (\Throwable $e) {
            // Fallback for extremely malformed dates where DateTimeImmutable triggers an exception
            return \get_gmt_from_date($site_mysql, 'Y-m-d H:i:s');
        }
    }

    /**
     * Convert a site-local MySQL datetime string into a UTC Unix timestamp.
     *
     * @param string $site_mysql Site-local 'Y-m-d H:i:s'.
     * @return int UTC Unix timestamp.
     */
    public static function utc_ts_from_site_mysql(string $site_mysql): int
    {
        return self::utc_ts_from_utc_mysql(
            self::utc_mysql_from_site_mysql($site_mysql)
        );
    }

    // -------------------------------------------------------------------------
    // UTC → SITE TIMEZONE DISPLAY (edge-only)
    // -------------------------------------------------------------------------

    /**
     * Format a UTC Unix timestamp as a site-timezone MySQL datetime string.
     * USE ONLY for display or for wp_insert_post(post_date) (which expects local).
     *
     * @param int $utc_ts UTC Unix timestamp.
     * @return string Site-local 'Y-m-d H:i:s'.
     */
    public static function site_mysql_from_utc_ts(int $utc_ts): string
    {
        return \wp_date('Y-m-d H:i:s', $utc_ts);
    }

    /**
     * Format a UTC Unix timestamp as a site-timezone Y-m-d string.
     * USE ONLY for display or daily-bucket comparisons against post_date.
     *
     * @param int $utc_ts UTC Unix timestamp.
     * @return string Site-local 'Y-m-d'.
     */
    public static function site_ymd_from_utc_ts(int $utc_ts): string
    {
        return \wp_date('Y-m-d', $utc_ts);
    }

    /**
     * Today's date in the site timezone, formatted as Y-m-d.
     * Replaces the invalid current_time('Y-m-d') call.
     */
    public static function site_today_ymd(): string
    {
        return \wp_date('Y-m-d', self::now_utc_ts());
    }

    // -------------------------------------------------------------------------
    // SCHEDULING HELPERS
    // -------------------------------------------------------------------------

    /**
     * Advance a UTC timestamp to the start of the next calendar day in the site timezone.
     *
     * Example: if $utc_ts is "Monday 22:00 UTC" and the site is UTC+5,
     * the site sees "Tuesday 03:00". This method returns the UTC timestamp
     * for "Tuesday 00:00 site time" = "Monday 19:00 UTC".
     *
     * Used for day-rollover in the scheduling loops (replaces gmdate()+get_gmt_from_date hacks).
     *
     * @param int $utc_ts Any UTC Unix timestamp.
     * @return int UTC Unix timestamp of next site-local midnight.
     */
    public static function next_site_midnight_utc_ts(int $utc_ts): int
    {
        $site_tz = \wp_timezone();
        $site_dt = (new \DateTimeImmutable('@' . $utc_ts))->setTimezone($site_tz);
        $next    = $site_dt->setTime(0, 0, 0)->modify('+1 day');
        return $next->setTimezone(new \DateTimeZone('UTC'))->getTimestamp();
    }

    /**
     * Build a UTC timestamp from a site-local date string + clock components.
     *
     * Example: site_clock_to_utc_ts('2026-03-09', 9, 0) → UTC ts for
     * 09:00 site time on that date.
     *
     * Used when turning "start_time = 09:00" settings into comparison timestamps.
     *
     * @param string $ymd    Site-local date in 'Y-m-d' format.
     * @param int    $hour   Hour in site timezone (0–23).
     * @param int    $minute Minute (0–59).
     * @param int    $second Second (0–59).
     * @return int UTC Unix timestamp.
     */
    public static function site_clock_to_utc_ts(
        string $ymd,
        int $hour,
        int $minute = 0,
        int $second = 0
    ): int {
        $site_dt = new \DateTimeImmutable(
            sprintf('%s %02d:%02d:%02d', $ymd, $hour, $minute, $second),
            \wp_timezone()
        );
        return $site_dt->setTimezone(new \DateTimeZone('UTC'))->getTimestamp();
    }

    /**
     * Parse a "HH:MM" setting string + a site-local date string into a UTC ts.
     *
     * Example: site_hhmm_to_utc_ts('2026-03-09', '09:00') → UTC ts for 09:00 site time.
     *
     * @param string $site_ymd  'Y-m-d' in site timezone.
     * @param string $hhmm      'H:i' string from plugin settings.
     * @return int UTC Unix timestamp.
     */
    public static function site_hhmm_to_utc_ts(string $site_ymd, string $hhmm): int
    {
        [$h, $m] = array_map('intval', explode(':', $hhmm));
        return self::site_clock_to_utc_ts($site_ymd, $h, $m, 0);
    }

    /**
     * Get the day-of-week abbreviation (mon/tue/.../sun) for a UTC timestamp
     * evaluated in the site timezone.
     *
     * Replaces: strtolower(date('D', $candidate_ts)) — which used the server TZ.
     *
     * @param int $utc_ts UTC Unix timestamp.
     * @return string Three-letter lowercase day abbreviation.
     */
    public static function site_day_of_week(int $utc_ts): string
    {
        $site_tz = \wp_timezone();
        // Use PHP's internal formatting which is always English for 'D' (Mon, Tue...) 
        // unlike wp_date() which translates based on site locale.
        $dt = (new \DateTimeImmutable('@' . $utc_ts))->setTimezone($site_tz);
        return strtolower($dt->format('D'));
    }

    /**
     * Get the site-local Y-m-d string for a UTC timestamp.
     * Alias of site_ymd_from_utc_ts() for readability inside scheduling loops.
     *
     * @param int $utc_ts UTC Unix timestamp.
     * @return string 'Y-m-d' in site timezone.
     */
    public static function site_date_str(int $utc_ts): string
    {
        return self::site_ymd_from_utc_ts($utc_ts);
    }

    /**
     * Shared helper to format a timestamp as a site-timezone datetime string.
     * Replaces raw date() or wp_date() calls that leak server timezone.
     *
     * @param int $ts Unix timestamp (UTC).
     * @return string Formatted datetime in site timezone.
     */
    public static function site_datetime(int $ts): string
    {
        return \wp_date(\get_option('date_format') . ' ' . \get_option('time_format'), $ts, \wp_timezone());
    }
}
