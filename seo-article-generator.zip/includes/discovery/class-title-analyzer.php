<?php
/**
 * Title_Analyzer — Smart Version & Name Extraction Engine
 *
 * Handles: dotted names (PAINT.NET, node.js), slash-separated multi-version titles
 * (VLC 3.2.0 / 4.0 Beta), year-in-name (Office 2026 17.2), build/RC/Beta/SP
 * suffixes, v-prefixed versions, stacked promo prefixes, and trailing noise.
 *
 * @package SEO_Article_Generator\Discovery
 * @version 3.2.1
 */

namespace SEO_Article_Generator\Discovery;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Title_Analyzer {

	/**
	 * VERSION_PATTERN — matches all common version string formats in one pass.
	 *
	 * Form A  : dot-separated  →  1.0 | 2.1.3 | 10.0.19041 | 3.2.0 Beta 3 | 6.42 Build 3313
	 * Form B  : single + label →  10 Build 3313 | 2 RC1 | 1 Beta | 2026 Build 21.2
	 * Form C  : V-prefix no-dot →  V267 | V100 | v3
	 */
	private const VERSION_PATTERN = '/\b (?: v? (?: \d+ (?: [.\-] \d+ )+ [a-z]? (?: \s* [.\-]? \s* (?: Build | Revision | Rev | RC | SP | HF | CU | Beta | Alpha | Preview | Canary | Nightly | Dev ) \s* \d* (?: [.\-] \d+ )* )? | \d+ \s+ (?: Build | Revision | Rev | RC | SP | HF | Beta | Alpha | Preview | Canary | Dev ) \s* \d* (?: [.\-] \d+ )* ) | [vV] \d+ (?! \s* [.\-] \d+ ) (?: \s* (?: Build | Revision | Rev | RC | Beta | Alpha | Preview ) \s* \d* )? ) \b/ixu';

	/** 4-digit year: 1970–2099 treated as product-name year, not a version */
	private const YEAR_RE = '/^(19[7-9]\d|20[0-9]\d)$/';

	/** Strip one or more stacked promotional prefixes at the start */
	private const PROMO_PREFIX_RE = '/^(?:(?:download|get|install|free|new|updated?|latest)\s+)+/iu';

	/** Strip trailing noise after a separator character */
	private const TRAILING_SEP_NOISE_RE = '/\s* [-–—|:] \s* (?: latest\s+version | latest | best | new | stable | released? | download | free | setup | full | offline | installer | repack | now\s+available | available | out\s+now | updated? | final | draft | changelog | review | crack | keygen | serial | patch | license\s*key | full\s+version | powerful | simple | easy | ultimate | excellent | fast | secure | popular ) .*$/ixu';

	/** Strip standalone trailing noise words */
	private const TRAILING_WORD_NOISE_RE = '/\s+ (?: free | download | setup | full | offline | installer | repack | now\s+available | released? | available | out\s+now | stable\s+release | changelog | final | draft | full\s+version | crack | keygen | serial | license\s*key | patch ) \s*$/ixu';

	/** Strip trailing platform/OS qualifiers: "for macOS", "for Windows 64-bit", "macOS", etc. */
	private const TRAILING_PLATFORM_RE = '/\s+ (?: for\s+ )? (?: macOS | mac\s+os\s*x? | windows | linux | android | ios | ubuntu | debian | fedora | centos | chrome\s*os ) (?: \s+ (?: 32[-\s]?bit | 64[-\s]?bit | arm64 | x86_64 | x64 | x86 | intel | apple\s+silicon | aarch64 | amd64 | universal ) )? \s*$/ixu';

	/**
	 * Extract software name and version from a raw title string.
	 *
	 * @param  string $raw_title
	 * @return array|false {name: string, version: string} or false
	 */
	public function extract( string $raw_title ) {
		$clean = $this->normalize( $raw_title );
		if ( mb_strlen( $clean ) < 2 ) {
			return false;
		}

		// Slash-separated titles ("VLC 3.2.0 / 4.0 Beta", "Wine 10.0 RC4 / 9.0 Stable")
		// Only treat as slash-separated if the slash separates two version-bearing segments
		// Allows pre-release labels (RC, Beta, etc.) between version and slash
		if ( strpos( $clean, '/' ) !== false && preg_match( '/\d+(?:[.\-]\d+)+(?:\s*(?:RC|Beta|Alpha|Stable|Final|Release|Build|SP|Dev|Preview|Nightly|Canary)\s*\d*)?\s*\/\s*v?\d/ixu', $clean ) ) {
			$result = $this->extract_from_slash( $clean );
			if ( null !== $result ) {
				return $result;
			}
		}

		return $this->extract_single( $clean ) ?? false;
	}

	/**
	 * Compare two version strings.
	 */
	public static function is_newer_version( $new_version, $old_version, $logger = null ): bool {
		$new = strtolower( trim( (string) $new_version ) );
		$old = strtolower( trim( (string) $old_version ) );

		if ( $new === $old ) {
			if ( $logger ) {
				$logger->debug( sprintf( '[is_newer_version] Versions equal: new="%s" old="%s" — skipping.', $new, $old ) );
			}
			return false;
		}
		if ( in_array( $new, array( 'unknown', '' ), true ) ) {
			return false;
		}
		if ( in_array( $old, array( 'unknown', '' ), true ) ) {
			return true;
		}

		$new = \ltrim( (string) $new, 'v' );
		$old = \ltrim( (string) $old, 'v' );

		$base_new = self::extract_base_version( $new );
		$base_old = self::extract_base_version( $old );

		if ( null === $base_new || null === $base_old ) {
			if ( $logger ) {
				$logger->warning( sprintf( '[is_newer_version] Base extraction failed. new="%s" old="%s"', $new, $old ) );
			}
			return strcmp( $new, $old ) > 0;
		}

		$cmp = version_compare( $base_new, $base_old );
		if ( $cmp !== 0 ) {
			return $cmp > 0;
		}

		// Handle single-letter revision suffixes (e.g., 1.2.3c > 1.2.3b > 1.2.3)
		// PHP version_compare considers '1.0' > '1.0a', which we override here.
		// We use a negative lookbehind to ensure it's a SINGLE letter suffix.
		preg_match( '/(?<![a-z])[a-z]$/i', $new, $m_new );
		preg_match( '/(?<![a-z])[a-z]$/i', $old, $m_old );
		$s_new = $m_new[0] ?? '';
		$s_old = $m_old[0] ?? '';
		if ( $s_new !== $s_old ) {
			return strcmp( $s_new, $s_old ) > 0;
		}

		// Base versions are equal: compare pre-release tier
		$tier_new = self::prerelease_tier( $new );
		$tier_old = self::prerelease_tier( $old );

		if ( $tier_new !== $tier_old ) {
			return $tier_new > $tier_old;
		}

		// Same tier: compare build/revision numbers
		$build_new = self::extract_build_number( $new );
		$build_old = self::extract_build_number( $old );

		return $build_new > $build_old;
	}

	private function normalize( string $title ): string {
		$s = trim( html_entity_decode( $title, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );

		// Step 0: Strip mid-title noise phrases that precede a version number
		// e.g., "download - Latest Version 29.3.0" → " 29.3.0"
		$s = (string) preg_replace( '/\s+(?:download)?\s*[-–—]\s*(?:latest\s+version|latest|version)\s+(?=v?\d)/ixu', ' ', $s ) ?? $s;

		// Step 1: Strip trailing separator + noise (when no version follows)
		$s = (string) preg_replace( self::TRAILING_SEP_NOISE_RE, '', $s ) ?? $s;

		// Step 1b: Clean up parenthetical markers EARLY so platform patterns can match at end
		$s = (string) preg_replace( '/\s*\((?:Trial|Paid|Free|Demo|Beta|Preview|Pro|Lite)[\/\w\s]*\)\s*$/iu', '', $s ) ?? $s;

		// Step 2: Strip composite "Free Download for Windows 10/11" / "setup for macOS" patterns (with optional OS version)
		$s = (string) preg_replace( '/\s+(?:free\s+)?(?:download|setup|full|offline|installer)\s+(?:for\s+)?(?:macos|mac\s+os\s*x?|windows|linux|android|ios|ubuntu|debian|fedora|centos|chrome\s*os)(?:\s+(?:32[-\s]?bit|64[-\s]?bit|arm64|x86_64|x64|x86|intel|apple\s+silicon|aarch64|amd64|universal|[\d.\/]+))?\s*$/ixu', '', $s ) ?? $s;

		// Step 2b: Strip "for <platform>" followed by separator + noise (e.g., "for Windows – Free Disc Burning Suite")
		$s = (string) preg_replace( '/\s+for\s+(?:macOS|mac\s+os\s*x?|windows|linux|android|ios|ubuntu|debian|fedora|centos|chrome\s*os)(?:\s+[\d.\/]+)?\s*[-–—|:].*/ixu', '', $s ) ?? $s;
		// Also strip trailing bare "for <platform>" at end (with optional OS version like "10/11")
		$s = (string) preg_replace( '/\s+for\s+(?:macOS|mac\s+os\s*x?|windows|linux|android|ios|ubuntu|debian|fedora|centos|chrome\s*os)(?:\s+(?:32[-\s]?bit|64[-\s]?bit|arm64|x86_64|x64|x86|intel|apple\s+silicon|aarch64|amd64|universal|[\d.\/]+))?\s*$/ixu', '', $s ) ?? $s;

		// Step 3: Strip trailing platform qualifiers
		$s = (string) preg_replace( self::TRAILING_PLATFORM_RE, '', $s ) ?? $s;

		// Step 4: Strip bare "Download" / "download" when immediately preceding a version (v-prefix or digit)
		$s = (string) preg_replace( '/\s+[Dd]ownload\s+(?=v?\d)/u', ' ', $s ) ?? $s;
		// Also strip trailing bare "Download" after any content
		$s = (string) preg_replace( '/\s+[Dd]ownload\s*$/u', '', $s ) ?? $s;

		// Step 5: Strip stacked promotional prefixes from the start
		// BUT protect compound product names like "Free Download Manager"
		if ( preg_match( self::PROMO_PREFIX_RE, $s, $pm ) ) {
			$remainder = trim( substr( $s, strlen( $pm[0] ) ) );
			// Extract the name portion of the remainder (before any version)
			$name_portion = preg_replace( '/\s+v?\d+(?:[.\-]\d+)*.*$/su', '', $remainder );
			$name_portion = trim( (string) $name_portion );
			$name_words = count( array_filter( preg_split( '/\s+/', $name_portion ) ) );
			// Only strip prefix if remainder has >= 2 name words (not just one like "Manager")
			// This protects "Free Download Manager", "Free Video Converter", etc.
			if ( $name_words >= 2 ) {
				$s = $remainder;
			}
		}

		// Step 6: Strip trailing noise words
		$s = (string) preg_replace( self::TRAILING_WORD_NOISE_RE, '', $s ) ?? $s;

		// Step 7: Strip trailing "- Latest Version" / "- Stable" / "- Final" and similar
		$s = (string) preg_replace( '/\s*[-–—]\s*(?:latest\s+version|stable|final|new|released?)\s*$/ixu', '', $s ) ?? $s;

		// Step 8a: Strip trailing "by <vendor>" attribution (e.g., "Wipe 2605 by PrivacyRoot")
		$s = (string) preg_replace( '/\s+by\s+.+$/iu', '', $s ) ?? $s;

		// Step 8b: Strip trailing pricing info (e.g., "– from $14", "for $29.99")
		$s = (string) preg_replace( '/\s*[-–—]\s*from\s*\$?[\d.,]+\s*$/iu', '', $s ) ?? $s;
		$s = (string) preg_replace( '/\s+for\s*\$?[\d.,]+\s*$/iu', '', $s ) ?? $s;

		// Step 8: Strip trailing orphan separators (leftover from partial stripping)
		$s = (string) preg_replace( '/\s*[-–—|:]\s*$/u', '', $s ) ?? $s;

		return trim( (string) preg_replace( '/\s{2,}/u', ' ', $s ) ?? $s );
	}

	private function extract_from_slash( string $clean ): ?array {
		$parts = array_map( 'trim', explode( '/', $clean, 2 ) );

		// Try primary segment first
		$primary = $this->extract_single( $parts[0] );
		if ( $primary && 'Unknown' !== $primary['version'] ) {
			return $primary;
		}

		// Primary had no version — borrow version from secondary, name from primary
		if ( $primary ) {
			$secondary = $this->extract_single( $parts[1] );
			if ( $secondary && 'Unknown' !== $secondary['version'] ) {
				return array(
					'name'    => $primary['name'],
					'version' => $secondary['version'],
				);
			}
		}

		return null;
	}

	private function extract_single( string $text ): ?array {
		preg_match_all( self::VERSION_PATTERN, $text, $hits, PREG_OFFSET_CAPTURE );

		if ( ! empty( $hits[0] ) ) {
			$chosen = $this->pick_best_match( $hits[0], $text );
			if ( null !== $chosen ) {
				list( $raw_ver, $offset ) = $chosen;
				$raw_name = trim( substr( $text, 0, (int) $offset ) );

				if ( preg_match( '/^(\d{4})\s+(?:Build|Revision|Rev|RC|SP|HF|Beta|Alpha|Preview|Canary|Dev)\b/iu', trim( $raw_ver ), $ybm ) ) {
					$year = $ybm[1];
					$year_int = (int) $year;
					if ( $year_int >= 1970 && $year_int <= 2099 ) {
						$raw_name = trim( $raw_name . ' ' . $year );
						$raw_ver = trim( preg_replace( '/^\d{4}\s+/', '', trim( $raw_ver ) ) );
					}
				}

				return array(
					'name' => $this->clean_name( $raw_name ),
					'version' => $this->normalize_version( $raw_ver ),
				);
			}
		}

		// Fallback: single trailing number (Half-Life 2, DirectX 12, Office 365, PotPlayer 250430)
		if ( preg_match( '/^(.+?)\s+(\d{1,6})\s*$/u', $text, $m ) ) {
			$candidate_ver = trim( $m[2] );
			// If it matches a 4-digit year pattern, treat it as product identity, not version
			if ( preg_match( self::YEAR_RE, $candidate_ver ) ) {
				// Year IS the product name — return as name with Unknown version
				return array(
					'name' => $this->clean_name( $text ),
					'version' => 'Unknown',
				);
			}
			return array(
				'name' => $this->clean_name( trim( $m[1] ) ),
				'version' => $candidate_ver,
			);
		}

		// No version found — attempt aggressive extraction of trailing version debris
		$aggressive = $this->aggressive_extract( $text );
		if ( null !== $aggressive ) {
			return $aggressive;
		}

		if ( mb_strlen( $text ) >= 2 ) {
			return array(
				'name' => $this->clean_name( $text ),
				'version' => 'Unknown',
			);
		}

		return null;
	}

	private function aggressive_extract( string $text ): ?array {
		if ( preg_match( '/^(.+?)\s+\d+(?:\.\d+)+(?:\s*\w+)*\s*$/iu', $text, $m ) ) {
			$name = trim( $m[1] );
			if ( mb_strlen( $name ) >= 2 && ! preg_match( '/^(?:\d+|[a-z]{1,2})$/iu', $name ) ) {
				$ver_part = trim( substr( $text, strlen( $m[1] ) ) );
				return array(
					'name' => $this->clean_name( $name ),
					'version' => $this->normalize_version( $ver_part ),
				);
			}
		}
		return null;
	}

	private function pick_best_match( array $candidates, string $text ): ?array {
		if ( 1 === count( $candidates ) ) {
			return $this->validate_year_build_match( $candidates[0], $text ) ? $candidates[0] : null;
		}

		$non_year = array_values( array_filter(
			$candidates,
			static function( $c ) {
				return ! preg_match( self::YEAR_RE, trim( $c[0] ) );
			}
		) );

		$pool = ! empty( $non_year ) ? $non_year : $candidates;

		$chosen = end( $pool ) ?: null;
		if ( $chosen && $this->validate_year_build_match( $chosen, $text ) ) {
			return $chosen;
		}

		foreach ( array_reverse( $pool ) as $candidate ) {
			if ( $this->validate_year_build_match( $candidate, $text ) ) {
				return $candidate;
			}
		}

		return null;
	}

	/**
	 * Validate a Form B year+build match.
	 *
	 * IMPORTANT: When the match starts with YEAR + Build/RC/etc, the reabsorption
	 * code in extract_single() (line 170) will move the year back into the name.
	 * So we ALLOW these matches through — the reabsorption handles them.
	 *
	 * We ONLY reject when the match is a BARE year (no Build/label) consumed
	 * from a single-word name, because those are product-identity years.
	 */
	private function validate_year_build_match( array $match, string $text ): bool {
		list( $raw_ver, $offset ) = $match;
		$trimmed_ver = trim( $raw_ver );

		// If it's a year + Build/label, ALLOW it — reabsorption will fix the name
		if ( preg_match( '/^\d{4}\s+(?:Build|Revision|Rev|RC|SP|HF|Beta|Alpha|Preview|Canary|Dev)\b/iu', $trimmed_ver ) ) {
			return true;
		}

		// If it's a bare year (no label) and remaining name has < 2 words → reject
		if ( preg_match( self::YEAR_RE, $trimmed_ver ) ) {
			$raw_name = trim( substr( $text, 0, (int) $offset ) );
			$word_count = count( array_filter( preg_split( '/\s+/', $raw_name ) ) );
			if ( $word_count < 2 ) {
				return false;
			}
		}

		return true;
	}

	private function normalize_version( string $v ): string {
		$v = trim( $v );

		// Strip leading version labels, but preserve Build/Revision/Rev/SP/HF/CU when they start the version string
		// as they are significant version qualifiers (e.g. "Build 8985").
		$v = (string) preg_replace( '/^(?:Version|Ver|Update|Patch|Hotfix|Release)\s+/i', '', $v );
		// Strip single v/V prefix (after any label was removed)
		$v = (string) preg_replace( '/^[vV]/', '', $v );

		// Only strip stable/final trailing labels. Preserve RC, Beta, Alpha, Nightly, Preview, Canary, Dev, Pro, Lite, etc.
		// because stripping them breaks is_newer_version pre-release tier comparison.
		$v = preg_replace( '/\s+(?:Stable|Final|Release)(?:\s*\d*)?$/i', '', $v );

		$v = (string) preg_replace( '/\s{2,}/', ' ', $v );
		return trim( $v );
	}

	private function clean_name( string $name ): string {
		if ( empty( $name ) ) {
			return $name;
		}

		// Strip trailing version debris that leaked into the name
		$clean = preg_replace( '/\s+v?\d+(?:\.\d+)*\s*(?:RC|Beta|Alpha|Build|Rev|Preview|SP|HF)\s*\d*\s*$/iu', '', $name );
		$clean = preg_replace( '/\s+v?\d+(?:\.\d+)+\s*$/iu', '', (string) $clean ?? $name );
		$clean = preg_replace( '/\s+v?\d+(?:\.\d+)*\s*\($/iu', '', (string) $clean ?? $name );
		$clean = trim( (string) preg_replace( '/\s{2,}/u', ' ', (string) $clean ?? $name ) );

		// NOTE: We do NOT strip trailing years here. The reabsorption logic in
		// extract_single() is the single source of truth for whether a year belongs
		// in the product name. Stripping here would contradict it.

		return ( mb_strlen( $clean ) >= 2 ) ? $clean : trim( $name );
	}

	private static function extract_base_version( string $v ): ?string {
		if ( preg_match( '/(\d+(?:[.\-]\d+)*)/', $v, $m ) ) {
			return $m[1];
		}
		return null;
	}

	private static function prerelease_tier( string $v ): int {
		// @FIX 2026-07-26: Real-world release-channel taxonomy aligned to vendor schemes
		// across the 178-software catalog (Mozilla Dev/Nightly/Beta/ESR/Release,
		// Google Chrome Canary/Dev/Beta/Stable, Microsoft Edge Dev/Canary/Beta/Stable,
		// Opera Beta/Developer/Stable, Vivaldi Snapshot/Stable, Brave Beta/Nightly/Release,
		// Wine Beta/Stable, Adobe Pre-release/Stable). Prior matrix co-tiered Canary with
		// Preview and omitted ESR entirely, causing Thunderbird 153 ESR to tie tier 5 with
		// stable and fall through to extract_build_number() returning 0 for both sides —
		// discarding the update. Order ranks ascending channel maturity.
		if ( preg_match( '/\b(?:dev|nightly)\b/i', $v ) ) {
			return 1;
		}
		if ( preg_match( '/\b(?:canary)\b/i', $v ) ) {
			return 2;
		}
		if ( preg_match( '/\b(?:preview)\b/i', $v ) ) {
			return 3;
		}
		if ( preg_match( '/\b(?:alpha)\b/i', $v ) ) {
			return 4;
		}
		if ( preg_match( '/\b(?:beta)\b/i', $v ) ) {
			return 5;
		}
		if ( preg_match( '/\b(?:rc|release\s*candidate)\b/i', $v ) ) {
			return 6;
		}
		// ESR (Mozilla Thunderbird / Firefox ESR) — stable, ranks above RC but below SP/HF.
		if ( preg_match( '/\b(?:esr|extended\s+support\s+release)\b/i', $v ) ) {
			return 7;
		}
		// SP/HF/CU/Patch are post-stable servicing — rank highest to satisfy
		// "patched build > unpatched stable of the same dotted base".
		if ( preg_match( '/\b(?:sp|hf|hotfix|cu|patch)\s*\d+/i', $v ) ) {
			return 9;
		}
		// Default: stable/release channel.
		return 8;
	}

	private static function extract_build_number( string $v ): int {
		// @FIX 2026-07-26: Mozilla tags release builds with a Bugzilla numeric id in
		// parentheses or with a leading hash — e.g. "Thunderbird 153.0.1 ESR by Mozilla
		// (#30400)" and "Wine 11.14 Beta (#30409)" — surfaced by user-reported drafts.
		// Previously extract_build_number only matched the Build/Rev/SP/HF/CU keyword
		// forms, so equal-tier ESR/RC/Beta comparisons fell through to "0 > 0 = false",
		// discarding legitimate build bumps. We now extract (a) the canonical Build-form,
		// (b) the #NNNNN form, and (c) the parenthesized (#NNNNN) form. We DO NOT match
		// bare 6-8 digit YYYYMMDD forms to avoid false-positives on 4-digit one-token
		// versions like "2607"; those are handled by version_compare via base extraction.
		if ( preg_match( '/\b(?:build|rev|revision|sp|hf|hotfix|cu)\s*(\d+)\b/i', $v, $m ) ) {
			return (int) $m[1];
		}
		if ( preg_match( '/#(\d+)\b/', $v, $m ) ) {
			return (int) $m[1];
		}
		if ( preg_match( '/\(\s*#?(\d{4,8})\s*\)/', $v, $m ) ) {
			return (int) $m[1];
		}
		return 0;
	}
}
