<?php

/**
 * Smoke Test Service
 *
 * Runs a non-destructive diagnostic suite to validate plugin integrity:
 * - required file presence (partial-deploy detection)
 * - critical class autoloadability
 * - DB schema presence for jobs table
 * - scheduler hooks availability
 * - pipeline dry-run (media tokenization -> schema -> composer -> quality gate)
 *
 * IMPORTANT: This does NOT call external AI providers.
 *
 * @package DIT_TrendStudio
 * @since 2.15.8
 * @MODIFIED 2026-02-25 - Added comprehensive smoke test suite in Settings > Diagnostics.
 */

namespace DIT\TrendStudio\Services;

use DIT\TrendStudio\Infrastructure\Logger;
use DIT\TrendStudio\Content\Media\MediaSelector;
use DIT\TrendStudio\Schema\Content_Schema;
use DIT\TrendStudio\Content\PostComposer;
use DIT\TrendStudio\Content\QualityGate;
use DIT\TrendStudio\Content\PromptEngine;
use DIT\TrendStudio\Content\ContentPipeline;
use DIT\TrendStudio\Infrastructure\Usage_Tracker;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Smoke_Test_Service
{
    private Logger $logger;

    public function __construct(Logger $logger)
    {
        $this->logger = $logger;
    }

    /**
     * Run the smoke test suite.
     *
     * @return array
     */
    public function run(): array
    {
        $run_at_gmt = gmdate('c');
        $results = [
            'run_at_gmt' => $run_at_gmt,
            'version'    => defined('DIT_TS_VERSION') ? (string) DIT_TS_VERSION : 'unknown',
            'status'     => 'pass',
            'summary'    => [
                'pass' => 0,
                'warn' => 0,
                'fail' => 0,
            ],
            'groups'     => [],
        ];

        try {
            $groups = [];
            $groups[] = $this->check_environment();
            $groups[] = $this->check_required_files();
            $groups[] = $this->check_classes();
            $groups[] = $this->check_database();
            $groups[] = $this->check_scheduling();
            $groups[] = $this->check_pipeline_dry_run();
            $groups[] = $this->simulate_end_to_end_pipeline();

            $results['groups'] = $groups;

            foreach ($groups as $g) {
                foreach (($g['checks'] ?? []) as $c) {
                    $st = (string) ($c['status'] ?? 'warn');
                    if (!isset($results['summary'][$st])) {
                        $st = 'warn';
                    }
                    $results['summary'][$st]++;
                }
            }

            if ($results['summary']['fail'] > 0) {
                $results['status'] = 'fail';
            } elseif ($results['summary']['warn'] > 0) {
                $results['status'] = 'warn';
            }
        } catch (\Throwable $e) {
            $this->logger->error('Smoke test crashed: ' . $e->getMessage());
            $results['status'] = 'fail';
            $results['groups'][] = [
                'id'     => 'internal_error',
                'label'  => 'Internal Error',
                'checks' => [
                    [
                        'id'      => 'exception',
                        'label'   => 'Unhandled exception',
                        'status'  => 'fail',
                        'details' => $e->getMessage(),
                    ],
                ],
            ];
            $results['summary']['fail']++;
        }

        update_option('dit_ts_last_smoke_test', wp_json_encode($results));
        return $results;
    }

    private function check_environment(): array
    {
        $g = $this->group('environment', 'Environment');

        $php_ok = version_compare(PHP_VERSION, '7.4', '>=');
        $this->add_check($g, 'php_version', 'PHP version >= 7.4', $php_ok ? 'pass' : 'fail', 'Current: ' . PHP_VERSION);

        foreach (['curl', 'json', 'mbstring'] as $ext) {
            $loaded = extension_loaded($ext);
            $this->add_check(
                $g,
                'ext_' . $ext,
                'PHP extension: ' . $ext,
                $loaded ? 'pass' : 'fail',
                $loaded ? 'Loaded' : 'Missing'
            );
        }

        $uploads = wp_upload_dir();
        $writable = !empty($uploads['basedir']) && is_dir($uploads['basedir']) && wp_is_writable($uploads['basedir']);
        $this->add_check(
            $g,
            'uploads_writable',
            'WP uploads directory writable',
            $writable ? 'pass' : 'warn',
            (string) ($uploads['basedir'] ?? '')
        );

        $gemini_key = (string) get_option('dit_ts_gemini_api_key', '');
        $this->add_check($g, 'gemini_key', 'Gemini API key configured', ($gemini_key !== '') ? 'pass' : 'warn', ($gemini_key !== '') ? 'Present' : 'Not set');

	$strategy = (string) get_option('dit_ts_ai_strategy', 'gemini');

	$custom_key = (string) get_option('dit_ts_custom_api_key', '');
	$custom_url = (string) get_option('dit_ts_custom_api_url', '');
	if ($strategy === 'custom') {
		$this->add_check(
			$g,
			'custom_key',
			'Custom Provider API key configured (required for selected strategy)',
			($custom_key !== '') ? 'pass' : 'warn',
			($custom_key !== '') ? 'Present' : 'Not set'
		);
		$this->add_check(
			$g,
			'custom_url',
		'Custom Provider API URL configured',
		($custom_url !== '') ? 'pass' : 'warn',
		($custom_url !== '') ? 'Present' : 'Not set'
	);
}

        return $g;
    }

    private function check_required_files(): array
    {
        $g = $this->group('files', 'Required Files');

        $required = [
            'dit-trend-content-studio.php',
            'src/Core/Plugin.php',
            'src/Core/Bootstrap.php',
            'src/Admin/SettingsPage.php',
            'src/Infrastructure/Scheduler.php',
            'src/Content/ContentPipeline.php',
            'src/Content/PromptEngine.php',
            'src/Content/PostComposer.php',
            'src/Schema/Content_Schema.php',
            'src/Schema/Content_Blocks.php',
            'assets/js/admin.js',
            'assets/css/admin.css',
            'src/Services/Smoke_Test_Service.php',
		'src/Content/Custom_Client.php',
            'src/Services/Media_Cleanup_Helper.php',
            'src/Services/Trash_Purge_Service.php',
        ];

        foreach ($required as $rel) {
            $path = trailingslashit(DIT_TS_PLUGIN_DIR) . ltrim($rel, '/');
            $ok = file_exists($path);
            $this->add_check($g, 'file_' . md5($rel), $rel, $ok ? 'pass' : 'fail', $ok ? 'Present' : 'Missing');
        }

        return $g;
    }

    private function check_classes(): array
    {
        $g = $this->group('classes', 'Critical Classes');

        $classes = [
            'DIT\\TrendStudio\\Core\\Plugin',
            'DIT\\TrendStudio\\Core\\Bootstrap',
            'DIT\\TrendStudio\\Infrastructure\\Scheduler',
            'DIT\\TrendStudio\\Content\\ContentPipeline',
            'DIT\\TrendStudio\\Content\\PromptEngine',
            'DIT\\TrendStudio\\Content\\PostComposer',
            'DIT\\TrendStudio\\Content\\QualityGate',
            'DIT\\TrendStudio\\Schema\\Content_Schema',
            'DIT\\TrendStudio\\Schema\\Content_Blocks',
            'DIT\\TrendStudio\\Services\\Draft_Cleanup_Service',
            'DIT\\TrendStudio\\Services\\Smoke_Test_Service',
		'DIT\\TrendStudio\\Content\\Custom_Client',
            'DIT\\TrendStudio\\Services\\Media_Cleanup_Helper',
            'DIT\\TrendStudio\\Services\\Trash_Purge_Service',
        ];

        foreach ($classes as $class) {
            $ok = class_exists($class);
            $this->add_check(
                $g,
                'class_' . md5($class),
                $class,
                $ok ? 'pass' : 'fail',
                $ok ? 'Loadable' : 'Not found (autoload missing or file absent)'
            );
        }

        $as_ok = class_exists('ActionScheduler') || function_exists('as_schedule_single_action');
        $this->add_check($g, 'action_scheduler', 'Action Scheduler available', $as_ok ? 'pass' : 'warn', $as_ok ? 'Available' : 'Not detected (fallback to WP-Cron only)');

        return $g;
    }

    private function check_database(): array
    {
        global $wpdb;
        $g = $this->group('database', 'Database');

        $table = $wpdb->prefix . 'dit_ts_jobs';
        $exists = ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) === $table);
        $this->add_check(
            $g,
            'jobs_table',
            'Jobs table exists: ' . $table,
            $exists ? 'pass' : 'fail',
            $exists ? 'Present' : 'Missing (reactivate plugin or run installer)'
        );

        if ($exists) {
            $cols = $wpdb->get_results('SHOW COLUMNS FROM ' . $table, ARRAY_A);
            $have = [];
            foreach ((array) $cols as $c) {
                if (!empty($c['Field'])) {
                    $have[] = (string) $c['Field'];
                }
            }

            // @MODIFIED 2026-02-25 - Column name is error_message (legacy). Accept either error_message or error.
            $required_cols = ['id', 'status', 'input_data', 'output_data', 'created_at', 'completed_at'];
            $missing = array_values(array_diff($required_cols, $have));

            $has_error_col = in_array('error_message', $have, true) || in_array('error', $have, true);
            if (!$has_error_col) {
                $missing[] = 'error_message';
            }
            $this->add_check(
                $g,
                'jobs_columns',
                'Jobs table columns present',
                empty($missing) ? 'pass' : 'fail',
                empty($missing) ? 'OK' : ('Missing: ' . implode(', ', array_unique($missing)))
            );
        }

        return $g;
    }

    private function check_scheduling(): array
    {
        $g = $this->group('scheduling', 'Scheduling');

        foreach (['dit_ts_cleanup_orphans', 'dit_ts_daily_cleanup', 'dit_ts_job_watchdog', 'dit_ts_scheduled_import'] as $hook) {
            $next = wp_next_scheduled($hook);
            $this->add_check(
                $g,
                'cron_' . $hook,
                'WP-Cron hook scheduled: ' . $hook,
                $next ? 'pass' : 'warn',
                $next ? ('Next: ' . gmdate('c', (int) $next)) : 'Not scheduled (may be disabled or pending init)'
            );
        }

        $master = (bool) get_option('dit_ts_master_automation', true);
        $this->add_check($g, 'master_switch', 'Master automation switch enabled', $master ? 'pass' : 'warn', $master ? 'Enabled' : 'Disabled (jobs will not run)');

        return $g;
    }

    private function check_pipeline_dry_run(): array
    {
        $g = $this->group('pipeline', 'Pipeline Dry Run (No API Calls)');

        $html = '<p>Intro</p>'
            . '<img src="https://example.com/a.jpg" alt="A" width="1200" height="800" />'
            . '<img src="https://example.com/icon-16x16.png" alt="icon" width="16" height="16" />'
            . '<img src="https://example.com/b.jpg" alt="B" width="1200" height="800" />';

        $res = MediaSelector::tokenize_images($html, 2, 'showbiz');
        $map = (array) ($res['visual_map'] ?? []);
        $html_out = (string) ($res['html'] ?? '');
        $tok_ok = (!empty($map) && strpos($html_out, '[VISUAL_0]') !== false);
        $this->add_check($g, 'tokenize_images', 'MediaSelector::tokenize_images()', $tok_ok ? 'pass' : 'warn', $tok_ok ? ('Selected: ' . count($map)) : 'No visuals tokenized (all filtered)');

        $ai = [
            'headline' => 'Smoke Test Headline',
            'dek' => 'Smoke test dek',
            'meta_description' => 'Smoke test meta description.',
            'vertical' => 'showbiz',
            'sources' => [
                [
                    'url' => 'https://example.org/source',
                    'label' => 'Example Source',
                    'fetched_at' => gmdate('c'),
                ],
            ],
            'sections' => [
                [
                    'heading' => 'Section 1',
                    'verification_status' => 'VERIFIED',
                    'body_html' => '<p>Smoke test body [1].</p>'
                        . '<iframe src="https://www.youtube.com/embed/abc123def45" allowfullscreen loading="lazy"></iframe>'
                        . '<blockquote class="tiktok-embed" cite="https://www.tiktok.com/@user/video/123"></blockquote>',
                ],
            ],
        ];

        $schema = Content_Schema::from_ai_array($ai);
        $schema_ok = (!empty($schema->headline) && !empty($schema->sections));
        $this->add_check($g, 'schema_parse', 'Content_Schema::from_ai_array()', $schema_ok ? 'pass' : 'fail', $schema_ok ? ('Sections: ' . count($schema->sections)) : 'Schema parse failed');

        $composer = new PostComposer();
        $markup = $composer->to_block_markup($schema->to_array(), true);
        // @MODIFIED 2026-02-25 - WP core serializer strips core/ namespace in comment delimiter (wp:embed).
        $embed_ok = (strpos($markup, 'wp:embed') !== false || strpos($markup, 'wp:core/embed') !== false);
        $this->add_check(
            $g,
            'composer_blocks',
            'PostComposer::to_block_markup() produces embed blocks',
            $embed_ok ? 'pass' : 'warn',
            $embed_ok ? 'embed blocks present' : 'No embed blocks detected'
        );

        $qg = new QualityGate();
        $audit = $qg->audit($schema, [
            'search_intent' => 'mixed',
            'penalty_unnamed' => 1,
            'source_visual_map' => $map,
        ]);
        $audit_ok = is_array($audit) && isset($audit['pts_lost']);
        $this->add_check($g, 'quality_gate', 'QualityGate::audit() executes', $audit_ok ? 'pass' : 'fail', $audit_ok ? ('pts_lost: ' . (int) $audit['pts_lost']) : 'Audit failed');

        return $g;
    }

    private function simulate_end_to_end_pipeline(): array
    {
        $g = $this->group('pipeline_sim', 'Content Pipeline (End-to-End Simulation)');

        try {
            // 1. Prepare Fakes (using internal anonymous classes or inline mocks since we are in WP context)
            $fake_json = wp_json_encode([
                'headline' => 'Simulated Headline',
                'dek' => 'Simulated dek',
                'meta_description' => 'Simulated meta description.',
                'vertical' => 'showbiz_pk',
                'sections' => [
                    [
                        'heading' => 'Simulated Section',
                        'body_html' => '<p>This is simulated content [VISUAL_0].</p>',
                        'verification_status' => 'VERIFIED'
                    ]
                ],
                'sources' => [['url' => 'https://example.com', 'label' => 'Source']]
            ]);

        // We need a way to mock AIProvider without PHPUnit's MockBuilder here.
        // @FIXED 2026-04-24 - PromptEngine now requires (AIProviderInterface, Logger) not just Logger
        $fake_provider = new class implements \DIT\TrendStudio\Contracts\AIProviderInterface {
            public function generate(array $promptData): array { return []; }
            public function generateFromResearch(array $promptData, array $researchData): array { return []; }
            public function generateCustomJson(string $prompt): array { return ['data' => [], 'raw_request' => '', 'raw_response' => '']; }
            public function get_model(): string { return 'smoke-test-fake'; }
        };
        $engine = new PromptEngine($fake_provider, $this->logger);
            $pipeline = new ContentPipeline(
                $engine,
                $this->logger,
                null, // media
                null, // cleaner
                function ($opt) {
                    return get_option($opt);
                }
            );

            $this->add_check($g, 'pipeline_init', 'Pipeline Instantiation (DI)', 'pass', 'Successfully initialized with DI');

            // 2. Test Media Tokenization logic
            $html = '<img src="https://example.com/test.jpg" width="800" height="600" />';
            $tokenized = MediaSelector::tokenize_images($html, 5, 'showbiz_pk');
            $has_tokens = !empty($tokenized['visual_map']) && strpos($tokenized['html'], '[VISUAL_0]') !== false;

            $this->add_check(
                $g,
                'token_logic',
                'Visual Tokenization Logic',
                $has_tokens ? 'pass' : 'fail',
                $has_tokens ? 'Tokens generated correctly' : 'Tokenization failed or filtered'
            );

            // 3. Test Schema & Blocks logic
            $schema = Content_Schema::from_ai_array(json_decode($fake_json, true));
            $composer = new PostComposer();
            $blocks = $composer->to_block_markup($schema->to_array(), true);

            $has_blocks = strpos($blocks, '<!-- wp:paragraph -->') !== false;
            $this->add_check(
                $g,
                'block_logic',
                'Gutenberg Block Serialization',
                $has_blocks ? 'pass' : 'fail',
                $has_blocks ? 'Blocks generated' : 'Block serialization failed'
            );

            // 4. Test Orchestration (Partial)
            // We verify that the pipeline can handle the mapping restoration
            $ai_data = ['sections' => [['body_html' => $blocks]]];
            $input_data = ['source_visual_map' => $tokenized['visual_map']];

            $swapped = $pipeline->swap_visual_tokens_back($ai_data, $input_data);
            $restored = (string) ($swapped['sections'][0]['body_html'] ?? '');
            $has_img = strpos($restored, '<img') !== false;

            $this->add_check(
                $g,
                'token_restoration',
                'Token Restoration (Mapping)',
                $has_img ? 'pass' : 'fail',
                $has_img ? 'Tokens restored to HTML' : 'Mapping failed'
            );
        } catch (\Throwable $e) {
            $this->add_check($g, 'sim_error', 'Simulation Error', 'fail', $e->getMessage());
        }

        return $g;
    }

    private function group(string $id, string $label): array
    {
        return [
            'id' => $id,
            'label' => $label,
            'checks' => [],
        ];
    }

    private function add_check(array &$group, string $id, string $label, string $status, string $details = ''): void
    {
        $status = in_array($status, ['pass', 'warn', 'fail'], true) ? $status : 'warn';
        $group['checks'][] = [
            'id' => $id,
            'label' => $label,
            'status' => $status,
            'details' => $details,
        ];
    }
}
