<?php

namespace DIT\TrendStudio\Pipeline;

use DIT\TrendStudio\Contracts\MiddlewareInterface;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * MiddlewarePipe
 *
 * Manages the execution of a stack of middleware for the content generation pipeline.
 *
 * @package DIT_TrendStudio
 * @since 2.10.0
 */
class MiddlewarePipe
{
    /**
     * @var array Stack of middleware instances.
     */
    protected array $stack = [];

    /**
     * Add middleware to the pipe.
     *
     * @param MiddlewareInterface $middleware
     * @return self
     */
    public function pipe(MiddlewareInterface $middleware): self
    {
        $this->stack[] = $middleware;
        return $this;
    }

    /**
     * Process the data through the stack.
     *
     * @param array $data    The data to process.
     * @param array $context The pipeline context.
     * @return array
     */
    public function process(array $data, array $context): array
    {
        $pipeline = array_reduce(
            array_reverse($this->stack),
            function ($next, MiddlewareInterface $middleware) use ($context) {
                return function ($data) use ($middleware, $context, $next) {
                    return $middleware->handle($data, $context, $next);
                };
            },
            function ($data) {
                return $data; // Final return when all middleware are exhausted
            }
        );

        return $pipeline($data);
    }
}
