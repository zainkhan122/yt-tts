package com.snsaver.app.domain.repository
import com.snsaver.app.domain.model.*
import kotlinx.coroutines.flow.Flow
interface DownloadRepository {
 fun observeAll():Flow<List<DownloadItem>>
 fun observeCompleted():Flow<List<DownloadItem>>
 fun observe(id:Long):Flow<DownloadItem?>
 suspend fun get(id:Long):DownloadItem?
 suspend fun add(item:DownloadItem):Long
 suspend fun update(item:DownloadItem)
 suspend fun setStatus(id:Long,status:DownloadStatus,progress:Int=0)
 suspend fun fail(id:Long,message:String?)
 suspend fun delete(id:Long)
 suspend fun deleteAll()
}
