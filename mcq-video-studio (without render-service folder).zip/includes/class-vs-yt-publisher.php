<?php

/**
 * YouTube Publisher — direct YouTube Data API v3 uploads for LONG-FORM videos.
 *
 * WHY THIS EXISTS (owner decision 2026-09-15, docs/yt-longform-distribution-audit.md):
 * Buffer's YouTube integration is SHORTS-ONLY (<=3 min, 9:16) — long-form videos
 * can never be uploaded through Buffer. This module uploads rendered long-form
 * jobs straight to YouTube (resumable upload, full SEO snippet from the job's
 * settings['seo']), then returns the watch URL so the existing Buffer pipeline
 * shares THAT link to every other network.
 *
 * Conventions followed (no invented patterns):
 *  - file/class naming: includes/class-vs-*.php / VS_* (same as VS_Buffer_Client)
 *  - config: single option array mcqvs_yt_config (same shape as mcqvs_r2_config)
 *  - logging: VS_Error_Logger::log_pipeline() stages like buffer.push
 *  - job bookkeeping: vs_jobs.yt_video_id column (idempotent uploads)
 *  - registration: VS_Core::init() + wp_ajax_ hooks like every other handler
 *
 * @package MCQ_Video_Studio
 * @since 1.6.0
 */

if (! defined('ABSPATH')) {
    exit;
}

class VS_YT_Publisher
{
    const CONFIG_KEY = 'mcqvs_yt_config';
    // @FIX (thumbnail scope): youtube.thumbnails.set REQUIRES the
    // youtube.force-ssl scope. Without it the API answers 403
    // "insufficientPermissions" and the rendered cover frame is never
    // applied. youtube.readonly is needed for forMine search + channel reads.
    const SCOPE      = 'https://www.googleapis.com/auth/youtube.upload https://www.googleapis.com/auth/youtube.readonly https://www.googleapis.com/auth/youtube.force-ssl';
    const CHUNK_BYTES = 8388608; // 8 MiB (multiple of 256 KiB per resumable protocol)

    // Option holding the channel's uploads playlist id (UU…), used to resolve
    // freshly uploaded videos without the lagging search index.
    const UPLOADS_PLAYLIST_OPTION = 'mcqvs_yt_uploads_playlist_id';

    // Cooldown (seconds) before retrying a job whose YouTube video could not
    // be resolved yet (Buffer upload still propagating to YouTube).
    const RETRY_COOLDOWN = 900;

    /**
     * Full config with defaults.
     *
     * @return array
     */
    public static function get_config()
    {
        $defaults = array(
            'enabled'       => 0,
            'client_id'     => '',
            'client_secret' => '',
            'refresh_token' => '',
            'access_token'  => '',
            'token_expires' => 0,
            'channel_id'    => '',
            'channel_title' => '',
            'privacy'       => 'public',   // public|unlisted|private
            'category_id'   => '27',       // 27 = Education
            'thumb'         => 1,          // set cover frame as thumbnail
        );
        $cfg = get_option(self::CONFIG_KEY, array());
        if (! is_array($cfg)) {
            $cfg = array();
        }
        return wp_parse_args($cfg, $defaults);
    }

    public static function save_config($cfg)
    {
        return update_option(self::CONFIG_KEY, $cfg);
    }

    /**
     * @return bool True when direct uploads are configured and switched on.
     */
    public static function is_enabled()
    {
        $cfg = self::get_config();
        return ! empty($cfg['enabled'])
            && ! empty($cfg['client_id'])
            && ! empty($cfg['client_secret'])
            && ! empty($cfg['refresh_token']);
    }

    /**
     * Google OAuth consent URL (redirect back to the Settings → YouTube tab).
     *
     * @return string
     */
    public static function auth_url()
    {
        $cfg = self::get_config();
        $redirect = admin_url('admin.php?page=mcqvs-settings&tab=youtube');
        return 'https://accounts.google.com/o/oauth2/v2/auth?' . http_build_query(array(
            'client_id'     => $cfg['client_id'],
            'redirect_uri'  => $redirect,
            'response_type' => 'code',
            'scope'         => self::SCOPE,
            'access_type'   => 'offline',
            'prompt'        => 'consent',
        ));
    }

    /**
     * Exchange an OAuth code (admin_init redirect) and store tokens + channel.
     *
     * @param string $code
     * @return true|WP_Error
     */
    public static function connect_with_code($code)
    {
        $cfg = self::get_config();
        if (empty($cfg['client_id']) || empty($cfg['client_secret'])) {
            return new WP_Error('yt_no_client', 'Enter Client ID and Client Secret first.');
        }
        $res = wp_remote_post('https://oauth2.googleapis.com/token', array(
            'body' => array(
                'client_id'     => $cfg['client_id'],
                'client_secret' => $cfg['client_secret'],
                'code'          => $code,
                'grant_type'    => 'authorization_code',
                'redirect_uri'  => admin_url('admin.php?page=mcqvs-settings&tab=youtube'),
            ),
            'timeout' => 20,
        ));
        if (is_wp_error($res)) {
            return $res;
        }
        $body = json_decode(wp_remote_retrieve_body($res), true);
        if (empty($body['access_token']) || empty($body['refresh_token'])) {
            return new WP_Error('yt_token_fail', 'Google did not return tokens: ' . ($body['error_description'] ?? 'unknown error'));
        }
        $cfg['access_token']  = $body['access_token'];
        $cfg['refresh_token'] = $body['refresh_token'];
        $cfg['token_expires'] = time() + (int) ($body['expires_in'] ?? 3600) - 60;
        self::save_config($cfg);
        return self::refresh_channel_info();
    }

    /**
     * Fetch the authenticated channel and store id/title.
     *
     * @return true|WP_Error
     */
    public static function refresh_channel_info()
    {
        $token = self::ensure_access_token();
        if (is_wp_error($token)) {
            return $token;
        }
        $res = wp_remote_get('https://www.googleapis.com/youtube/v3/channels?part=snippet,contentDetails&mine=true', array(
            'headers' => array('Authorization' => 'Bearer ' . $token),
            'timeout' => 20,
        ));
        if (is_wp_error($res)) {
            return $res;
        }
        $body = json_decode(wp_remote_retrieve_body($res), true);
        $item = $body['items'][0] ?? null;
        if (! $item) {
            return new WP_Error('yt_no_channel', 'Token works but no channel found on this Google account.');
        }
        $cfg = self::get_config();
        $cfg['channel_id']    = $item['id'];
        $cfg['channel_title'] = $item['snippet']['title'] ?? '';
        self::save_config($cfg);
        // @NEW 1.8.0: cache the uploads playlist id (UU…) — used to resolve
        // freshly uploaded videos (search.list lags behind uploads).
        $uploads = (string) ($item['contentDetails']['relatedPlaylists']['uploads'] ?? '');
        if ($uploads !== '') {
            update_option(self::UPLOADS_PLAYLIST_OPTION, $uploads);
        } else {
            delete_option(self::UPLOADS_PLAYLIST_OPTION);
        }
        return true;
    }

    /**
     * Valid access token, refreshing via refresh_token when expired.
     *
     * @return string|WP_Error
     */
    public static function ensure_access_token()
    {
        $cfg = self::get_config();
        if (! empty($cfg['access_token']) && (int) $cfg['token_expires'] > time() + 30) {
            return $cfg['access_token'];
        }
        if (empty($cfg['refresh_token'])) {
            return new WP_Error('yt_no_refresh', 'Not connected to YouTube (no refresh token).');
        }
        $res = wp_remote_post('https://oauth2.googleapis.com/token', array(
            'body' => array(
                'client_id'     => $cfg['client_id'],
                'client_secret' => $cfg['client_secret'],
                'refresh_token' => $cfg['refresh_token'],
                'grant_type'    => 'refresh_token',
            ),
            'timeout' => 20,
        ));
        if (is_wp_error($res)) {
            return $res;
        }
        $body = json_decode(wp_remote_retrieve_body($res), true);
        if (empty($body['access_token'])) {
            return new WP_Error('yt_refresh_fail', 'Token refresh failed: ' . ($body['error_description'] ?? 'unknown'));
        }
        $cfg['access_token']  = $body['access_token'];
        $cfg['token_expires'] = time() + (int) ($body['expires_in'] ?? 3600) - 60;
        self::save_config($cfg);
        return $cfg['access_token'];
    }

    /**
     * Single choke-point entry, called by VS_Buffer_Client::push_job_to_buffer()
     * for EVERY push path. Idempotent per job (yt_video_id column).
     *
     * @param string $job_id
     * @param string $video_url Current public URL (R2/local).
     * @param array  $job       Job row.
     * @return string The URL downstream sharing should use (YT watch URL on success,
     *                otherwise the original URL — publishing must never break push).
     */
    public static function maybe_publish_long_job($job_id, $video_url, $job)
    {
        $settings = is_string($job['settings'] ?? '') ? json_decode($job['settings'], true) : ($job['settings'] ?? array());
        if (! is_array($settings)) {
            $settings = array();
        }
        $is_long = (($settings['videoFormat'] ?? '') === 'youtube');
        if (! $is_long || ! self::is_enabled()) {
            return $video_url;
        }
        if (! empty($job['yt_video_id'])) {
            // Already published — reuse the watch URL (idempotent re-pushes).
            return 'https://www.youtube.com/watch?v=' . $job['yt_video_id'];
        }

        $log = VS_Error_Logger::get_instance();
        $log->log_pipeline('yt.publish', 'started', $job_id, "Direct YouTube upload starting for job {$job_id}", 'info');

        // Local file first; fall back to downloading the public URL to temp.
        $file_path = ! empty($job['video_path']) && @is_readable($job['video_path']) ? $job['video_path'] : null;
        if (! $file_path) {
            $tmp = get_temp_dir() . 'mcqvs_yt_' . $job_id . '.mp4';
            $downloaded = self::download_file($video_url, 300);
            if (is_wp_error($downloaded)) {
                $log->log_pipeline('yt.publish', 'failed', $job_id, 'Could not stage video file: ' . $downloaded->get_error_message(), 'error');
                return $video_url;
            }
            @rename($downloaded, $tmp);
            $file_path = $tmp;
        }
        $size = (int) @filesize($file_path);
        if ($size <= 0) {
            $log->log_pipeline('yt.publish', 'failed', $job_id, 'Staged video file is empty', 'error');
            return $video_url;
        }

        $seo   = isset($settings['seo']) && is_array($settings['seo']) ? $settings['seo'] : array();
        $cfg   = self::get_config();
        $title = ! empty($seo['title']) ? $seo['title'] : ($settings['topic_name'] ?? 'Quiz Video');
        $title = mb_substr($title, 0, 100);
        $desc  = ! empty($seo['description']) ? $seo['description'] : '';
        // @NEW 1.8.0: auto-chapters from the render's FINAL adaptive plan
        // (chapters.json written by render-node) — key-moments SEO for long-form.
        $chapters = self::chapters_block($job_id);
        if ($chapters !== '') {
            $desc .= "\n\nChapters:\n" . $chapters;
        }
        if (! empty($seo['hashtags']) && is_array($seo['hashtags'])) {
            $desc .= "\n\n" . implode(' ', $seo['hashtags']);
        }
        $desc = mb_substr($desc, 0, 5000);
        $tags = ! empty($seo['tags']) && is_array($seo['tags']) ? array_slice($seo['tags'], 0, 8) : array();

        $token = self::ensure_access_token();
        if (is_wp_error($token)) {
            $log->log_pipeline('yt.publish', 'failed', $job_id, 'Auth: ' . $token->get_error_message(), 'error');
            return $video_url;
        }

        // 1) Start resumable session.
        $meta = array(
            'snippet' => array(
                'title'       => $title,
                'description' => $desc,
                'tags'        => $tags,
                'categoryId'  => (string) $cfg['category_id'],
            ),
            'status'  => array(
                'privacyStatus' => in_array($cfg['privacy'], array('public', 'unlisted', 'private'), true) ? $cfg['privacy'] : 'public',
                'madeForKids'   => false,
                'selfDeclaredMadeForKids' => false,
            ),
        );
        $session = wp_remote_request('https://www.googleapis.com/upload/youtube/v3/videos?part=snippet,status&uploadType=resumable', array(
            'method'  => 'POST',
            'headers' => array(
                'Authorization'           => 'Bearer ' . $token,
                'Content-Type'            => 'application/json; charset=UTF-8',
                'X-Upload-Content-Length' => (string) $size,
                'X-Upload-Content-Type'   => 'video/mp4',
            ),
            'body'    => wp_json_encode($meta),
            'timeout' => 30,
        ));
        if (is_wp_error($session)) {
            $log->log_pipeline('yt.publish', 'failed', $job_id, 'Session: ' . $session->get_error_message(), 'error');
            return $video_url;
        }
        $session_code = (int) wp_remote_retrieve_response_code($session);
        $location = wp_remote_retrieve_header($session, 'Location');
        if ($session_code !== 200 || empty($location)) {
            $log->log_pipeline('yt.publish', 'failed', $job_id, 'Session HTTP ' . $session_code . ': ' . wp_remote_retrieve_body($session), 'error');
            return $video_url;
        }

        // 2) Chunked PUT.
        $fh = @fopen($file_path, 'rb');
        if (! $fh) {
            $log->log_pipeline('yt.publish', 'failed', $job_id, 'Could not open staged file', 'error');
            return $video_url;
        }
        $offset = 0;
        $yt_id  = '';
        while ($offset < $size) {
            $chunk = fread($fh, self::CHUNK_BYTES);
            $chunk_len = strlen($chunk);
            $range_end = $offset + $chunk_len - 1;
            $put = wp_remote_request($location, array(
                'method'  => 'PUT',
                'headers' => array(
                    'Content-Length' => (string) $chunk_len,
                    'Content-Range'  => 'bytes ' . $offset . '-' . $range_end . '/' . $size,
                ),
                'body'    => $chunk,
                'timeout' => 300,
            ));
            if (is_wp_error($put)) {
                fclose($fh);
                $log->log_pipeline('yt.publish', 'failed', $job_id, 'Chunk upload: ' . $put->get_error_message(), 'error');
                return $video_url;
            }
            $code = (int) wp_remote_retrieve_response_code($put);
            if ($code === 200 || $code === 201) {
                $final = json_decode(wp_remote_retrieve_body($put), true);
                $yt_id = (string) ($final['id'] ?? '');
                break;
            }
            if ($code !== 308) {
                fclose($fh);
                $log->log_pipeline('yt.publish', 'failed', $job_id, 'Chunk HTTP ' . $code . ': ' . wp_remote_retrieve_body($put), 'error');
                return $video_url;
            }
            $range = wp_remote_retrieve_header($put, 'Range');
            $offset = $range && preg_match('/-(\d+)$/', (string) $range, $m) ? ((int) $m[1]) + 1 : $offset + $chunk_len;
        }
        fclose($fh);
        if ($yt_id === '') {
            $log->log_pipeline('yt.publish', 'failed', $job_id, 'Upload finished without a video id', 'error');
            return $video_url;
        }

        // 3) Thumbnail from the rendered cover frame (optional, never fatal).
        $thumb_applied = false;
        if (! empty($cfg['thumb'])) {
            $thumb_applied = self::try_set_thumbnail($yt_id, $token, $job, $settings);
        }

        // 4) Bookkeeping: yt id + swap the shared URL to the watch page.
        if (class_exists('VS_Job_Repository')) {
            $repo = VS_Job_Repository::init();
            $settings['pre_yt_video_url'] = $video_url;
            // @NEW 1.8.0: remember that the cover was applied so the sync
            //       orchestrator does not call thumbnails.set (50 quota units)
            //       a second time for the same video.
            if ($thumb_applied) {
                $settings['yt_cover_applied'] = true;
            }
            $repo->update_job_fields($job_id, array(
                'yt_video_id' => $yt_id,
                'settings'    => wp_json_encode($settings),
            ));
            $repo->update_video_url($job_id, 'https://www.youtube.com/watch?v=' . $yt_id);
        }

        // 5) @NEW 1.8.0: file the long-form set into its pillar playlist.
        self::attach_job_to_playlist($job_id, $yt_id, $settings['series'] ?? '', $settings['topic_name'] ?? ($settings['quizName'] ?? ''));
        $log->log_pipeline('yt.publish', 'completed', $job_id, "Uploaded to YouTube: https://www.youtube.com/watch?v={$yt_id}", 'info');
        return 'https://www.youtube.com/watch?v=' . $yt_id;
    }

    /**
     * Download a remote file to a local temp file.
     *
     * download_url() lives in wp-admin/includes/file.php, which is NOT loaded
     * in cron / REST / Action Scheduler contexts. Calling it unguarded there
     * is a fatal error ("Call to undefined function"), which would abort the
     * whole publish cron run.
     *
     * @NEW 1.8.0
     * @param string $url     Remote URL.
     * @param int    $timeout Timeout in seconds.
     * @return string|WP_Error Temp file path.
     */
    private static function download_file($url, $timeout = 60)
    {
        if (! function_exists('download_url')) {
            $admin_file = ABSPATH . 'wp-admin/includes/file.php';
            if (is_readable($admin_file)) {
                require_once $admin_file;
            }
        }
        if (! function_exists('download_url')) {
            return new WP_Error('yt_download_unavailable', 'download_url() unavailable (wp-admin/includes/file.php not loadable).');
        }
        return download_url($url, $timeout);
    }

    /**
     * Best-effort thumbnail: reuse the render's uploaded cover image when the
     * job recorded one; otherwise skip silently (YouTube auto-picks a frame).
     *
     * @param string $yt_id
     * @param string $token
     * @param array  $job
     * @param array  $settings
     * @return bool True when the thumbnail was accepted by the API.
     */
    private static function try_set_thumbnail($yt_id, $token, $job, $settings)
    {
        if (is_wp_error($token)) {
            return false;
        }
        // The renderer stores the uploaded cover as settings.cover_image_url.
        $cover_url = ! empty($settings['cover_image_url']) ? $settings['cover_image_url'] : '';
        if ($cover_url === '') {
            return false;
        }
        $tmp = self::download_file($cover_url, 60);
        if (is_wp_error($tmp)) {
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log('yt.thumb.download_failed: ' . $tmp->get_error_message(), 'warning', array('yt_id' => $yt_id, 'cover_url' => $cover_url));
            }
            return false;
        }

        // @FIX (mime): the render service extracts the cover as a PNG
        // (render-node.js writes "<out>.mp4" -> "<out>-cover.png"), but this
        // method hard-coded image/jpeg + thumb.jpg. A PNG payload declared as
        // JPEG is rejected/mis-decoded by the YouTube thumbnails endpoint, so
        // the cover was silently never applied. Detect the real MIME type.
        // NOTE: the detection MUST run before the temp file is deleted —
        // download_url() returns an extension-less temp name, so both
        // wp_check_filetype() and getimagesize() need the file to exist.
        $mime = 'image/jpeg';
        if (function_exists('wp_check_filetype')) {
            $ft = wp_check_filetype($tmp);
            if (! empty($ft['type']) && strpos((string) $ft['type'], 'image/') === 0) {
                $mime = (string) $ft['type'];
            }
        }
        if (strpos($mime, 'image/') !== 0 && function_exists('getimagesize')) {
            $info = @getimagesize($tmp);
            if (! empty($info['mime']) && strpos((string) $info['mime'], 'image/') === 0) {
                $mime = (string) $info['mime'];
            }
        }
        if (strpos($mime, 'image/png') === 0) {
            $ext = 'png';
        } else {
            $mime = 'image/jpeg';
            $ext  = 'jpg';
        }

        $file_bin = @file_get_contents($tmp);
        @unlink($tmp);
        if (! $file_bin) {
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log('yt.thumb.read_failed', 'warning', array('yt_id' => $yt_id, 'cover_url' => $cover_url));
            }
            return false;
        }

        // @FIX (multipart): build a spec-compliant multipart/related body —
        // a JSON part followed by the media part. The previous body used
        // form-data dispositions under a multipart/related header and carried
        // no JSON part at all, which the endpoint does not reliably accept.
        $boundary = 'mcqvs' . wp_rand(100000, 999999);
        $body = '--' . $boundary . "\r\n"
            . "Content-Type: application/json; charset=UTF-8\r\n\r\n"
            . "{}\r\n"
            . '--' . $boundary . "\r\n"
            . "Content-Type: {$mime}\r\n\r\n"
            . $file_bin . "\r\n"
            . '--' . $boundary . '--';

        $res = wp_remote_request('https://www.googleapis.com/upload/youtube/v3/thumbnails/set?videoId=' . rawurlencode($yt_id), array(
            'method'  => 'POST',
            'headers' => array(
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'multipart/related; boundary=' . $boundary,
            ),
            'body'    => $body,
            'timeout' => 60,
        ));
        if (is_wp_error($res)) {
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log('yt.thumb.http_error: ' . $res->get_error_message(), 'warning', array('yt_id' => $yt_id));
            }
            return false;
        }
        $code = (int) wp_remote_retrieve_response_code($res);
        if ($code < 200 || $code >= 300) {
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log(
                    'yt.thumb.api_error: HTTP ' . $code . ' ' . substr((string) wp_remote_retrieve_body($res), 0, 300),
                    'warning',
                    array('yt_id' => $yt_id, 'http_code' => $code, 'mime' => $mime)
                );
            }
            return false;
        }
        if (class_exists('VS_Error_Logger')) {
            VS_Error_Logger::get_instance()->log(
                'yt.thumb.applied',
                'info',
                array('yt_id' => $yt_id, 'mime' => $mime, 'ext' => $ext, 'bytes' => strlen($file_bin))
            );
        }
        return true;
    }

    /**
     * AJAX: connect (OAuth code returned to the settings tab).
     */
    public function ajax_connect()
    {
        check_ajax_referer('mcqvs_yt_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }
        $code = isset($_POST['code']) ? sanitize_text_field(wp_unslash($_POST['code'])) : '';
        if ($code === '') {
            wp_send_json_error('Missing code');
        }
        $res = self::connect_with_code($code);
        if (is_wp_error($res)) {
            wp_send_json_error($res->get_error_message());
        }
        $cfg = self::get_config();
        wp_send_json_success(array('channel' => $cfg['channel_title'], 'channel_id' => $cfg['channel_id']));
    }

    /**
     * AJAX: disconnect (tokens only; uploaded videos stay on YouTube).
     */
    public function ajax_disconnect()
    {
        check_ajax_referer('mcqvs_yt_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }
        $cfg = self::get_config();
        $cfg['refresh_token'] = '';
        $cfg['access_token']  = '';
        $cfg['token_expires'] = 0;
        $cfg['channel_id']    = '';
        $cfg['channel_title'] = '';
        $cfg['enabled']       = 0;
        self::save_config($cfg);
        // @NEW 1.8.0: drop the cached uploads playlist id — it belongs to the
        // channel we just disconnected from.
        delete_option(self::UPLOADS_PLAYLIST_OPTION);
        wp_send_json_success(true);
    }

    // ------------------------------------------------------------------
    //  PLAYLISTS + CHAPTERS (v1.8.0 growth pipeline, owner-approved)
    // ------------------------------------------------------------------

    /** @NEW 1.8.0 */
    public static function playlists_enabled()
    {
        return (bool) get_option('mcqvs_yt_playlist_auto', 1);
    }

    /** @NEW 1.8.0 Register lifecycle hooks (called once from bootstrap). */
    public static function init_hooks()
    {
        // Buffer-published Shorts: attach to the pillar playlist once the
        // video exists on YouTube (title lookup, 100 quota units per video).
        add_action('mcqvs_video_job_published', array(__CLASS__, 'on_job_published'), 10, 2);
    }

    /**
     * Minimal JSON helper for Data API v3 calls (OAuth Bearer).
     *
     * @NEW 1.8.0
     * @return array|WP_Error
     */
    private static function yt_request($method, $url, $token, $body = null)
    {
        $args = array(
            'method'  => $method,
            'headers' => array('Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json'),
            'timeout' => 30,
        );
        if ($body !== null) {
            $args['body'] = wp_json_encode($body);
        }
        $res = wp_remote_request($url, $args);
        if (is_wp_error($res)) {
            return $res;
        }
        $code = (int) wp_remote_retrieve_response_code($res);
        $data = json_decode(wp_remote_retrieve_body($res), true);
        if ($code >= 400) {
            return new WP_Error('yt_api_' . $code, $data['error']['message'] ?? ('HTTP ' . $code));
        }
        return is_array($data) ? $data : array();
    }

    /**
     * Idempotent playlist ensure (name → id map persisted in options).
     *
     * @NEW 1.8.0
     * @return string|WP_Error playlist id.
     */
    public static function ensure_playlist($title)
    {
        $title = trim((string) $title);
        if ($title === '') {
            return new WP_Error('yt_playlist_name', 'Empty playlist name');
        }
        $map = get_option('mcqvs_yt_playlists', array());
        if (! is_array($map)) {
            $map = array();
        }
        if (! empty($map[$title])) {
            return $map[$title];
        }
        $token = self::ensure_access_token();
        if (is_wp_error($token)) {
            return $token;
        }
        $res = self::yt_request('POST', 'https://www.googleapis.com/youtube/v3/playlists?part=snippet,status', $token, array(
            'snippet' => array('title' => $title, 'description' => 'Auto-curated quiz sets by TheQuizWire pipeline.'),
            // @FIX (2026-11-04): the YouTube API defaults a new playlist to
            //       private, which hides the pillar playlist from the channel
            //       page and from viewers — the "Auto-playlists" feature would
            //       file every video correctly but the playlist would stay
            //       invisible. Create it public.
            'status'  => array('privacyStatus' => 'public'),
        ));
        if (is_wp_error($res)) {
            return $res;
        }
        $id = (string) ($res['id'] ?? '');
        if ($id === '') {
            return new WP_Error('yt_playlist_id', 'Playlist created but no id returned');
        }
        $map[$title] = $id;
        update_option('mcqvs_yt_playlists', $map);
        return $id;
    }

    /**
     * Add a video to a playlist (duplicate-insert errors are tolerated).
     *
     * @NEW 1.8.0
     */
    public static function add_video_to_playlist($playlist_id, $video_id)
    {
        $token = self::ensure_access_token();
        if (is_wp_error($token)) {
            return $token;
        }
        $res = self::yt_request('POST', 'https://www.googleapis.com/youtube/v3/playlistItems?part=snippet', $token, array(
            'snippet' => array(
                'playlistId' => $playlist_id,
                'resourceId' => array('kind' => 'youtube#video', 'videoId' => $video_id),
            ),
        ));
        return $res;
    }

    /**
     * Resolve the connected channel's uploads playlist id (UU…).
     *
     * The uploads playlist is the cheapest reliable way to find a freshly
     * uploaded video: search.list costs 100 quota units and its index lags
     * behind actual uploads, while playlistItems.list costs 1 unit and
     * reflects uploads immediately. The id is cached in an option; it is
     * refreshed by refresh_channel_info() and re-resolved here when missing.
     *
     * @NEW 1.8.0
     * @param string $token Optional bearer token (skips a token refresh).
     * @return string Uploads playlist id, or '' when unavailable.
     */
    public static function get_uploads_playlist_id($token = '')
    {
        $cached = (string) get_option(self::UPLOADS_PLAYLIST_OPTION, '');
        if ($cached !== '') {
            return $cached;
        }
        if (! is_string($token) || $token === '') {
            $token = self::ensure_access_token();
        }
        if (is_wp_error($token)) {
            return '';
        }
        $res = self::yt_request('GET', 'https://www.googleapis.com/youtube/v3/channels?part=contentDetails&mine=true', $token);
        if (is_wp_error($res) || empty($res['items'][0]['contentDetails']['relatedPlaylists']['uploads'])) {
            return '';
        }
        $uploads = (string) $res['items'][0]['contentDetails']['relatedPlaylists']['uploads'];
        if ($uploads !== '') {
            update_option(self::UPLOADS_PLAYLIST_OPTION, $uploads);
        }
        return $uploads;
    }

    /**
     * List the most recent items of the channel's uploads playlist.
     *
     * @NEW 1.8.0
     * @param string $token     Bearer token.
     * @param int    $max_items Maximum number of items to read.
     * @return array Array of ['id' => videoId, 'title' => string, 'published_at' => ISO8601].
     */
    private static function list_uploads_playlist_items($token, $max_items = 150)
    {
        $uploads = self::get_uploads_playlist_id($token);
        if ($uploads === '') {
            return array();
        }
        $items  = array();
        $page   = '';
        $guard  = 0;
        $max    = max(1, (int) $max_items);
        while (count($items) < $max && $guard < 5) {
            $guard++;
            $url = 'https://www.googleapis.com/youtube/v3/playlistItems?part=snippet,contentDetails&playlistId=' . rawurlencode($uploads) . '&maxResults=50';
            if ($page !== '') {
                $url .= '&pageToken=' . rawurlencode($page);
            }
            $res = self::yt_request('GET', $url, $token);
            if (is_wp_error($res)) {
                break;
            }
            foreach ((array) ($res['items'] ?? array()) as $item) {
                $vid = (string) ($item['snippet']['resourceId']['videoId'] ?? '');
                if ($vid === '') {
                    continue;
                }
                $items[] = array(
                    'id'           => $vid,
                    'title'        => (string) ($item['snippet']['title'] ?? ''),
                    'published_at' => (string) ($item['contentDetails']['videoPublishedAt'] ?? ''),
                );
            }
            $page = (string) ($res['nextPageToken'] ?? '');
            if ($page === '') {
                break;
            }
        }
        return $items;
    }

    /**
     * Normalize a YouTube title for comparison (case + whitespace).
     *
     * @NEW 1.8.0
     * @param string $title
     * @return string
     */
    private static function normalize_yt_title($title)
    {
        $t = strtolower(trim((string) $title));
        $t = preg_replace('/\s+/u', ' ', $t);
        return (string) $t;
    }

    /**
     * Find MY videos whose title matches one of the given candidate titles.
     *
     * Primary lookup is the channel's uploads playlist (1 quota unit per
     * page, reflects uploads immediately). search.list (100 units, index
     * lags) is only used as a fallback. Several ids can be returned: the
     * same title may exist more than once on the channel (a job pushed to
     * several YouTube channels, or a re-publish).
     *
     * @NEW 1.8.0
     * @param array $titles   Candidate titles (Buffer's YouTube title formula).
     * @param int   $since_ts Optional lower bound for the video publish time.
     * @param int   $until_ts Optional upper bound for the video publish time.
     * @return array Array of video ids.
     */
    public static function find_my_video_ids_by_titles(array $titles, $since_ts = 0, $until_ts = 0)
    {
        $titles = array_values(array_filter(array_map(function ($t) { return trim((string) $t); }, $titles), function ($t) { return $t !== ''; }));
        if (empty($titles)) {
            return array();
        }
        $wanted = array();
        foreach ($titles as $t) {
            $wanted[self::normalize_yt_title($t)] = true;
        }

        $token = self::ensure_access_token();
        if (is_wp_error($token)) {
            return array();
        }

        $found = array();
        // The uploads playlist is authoritative for the connected channel:
        // it contains every video the channel owns, immediately. search.list
        // (100 units per call) is only used when the uploads playlist itself
        // could not be read — otherwise a job whose video is not on this
        // channel would burn 100+ quota units on every retry.
        $uploads      = self::get_uploads_playlist_id($token);
        $have_uploads = ($uploads !== '');
        if ($have_uploads) {
            foreach (self::list_uploads_playlist_items($token, 150) as $item) {
                if (! isset($wanted[self::normalize_yt_title($item['title'])])) {
                    continue;
                }
                $ts = $item['published_at'] !== '' ? strtotime($item['published_at']) : 0;
                if ($ts > 0 && $since_ts > 0 && $ts < $since_ts) {
                    continue;
                }
                if ($ts > 0 && $until_ts > 0 && $ts > $until_ts) {
                    continue;
                }
                $found[] = $item['id'];
            }
        }

        if (empty($found) && ! $have_uploads) {
            // Fallback: forMine search (100 units, index lags behind uploads).
            foreach (array_slice($titles, 0, 3) as $title) {
                $url = 'https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=5&forMine=true&q=' . rawurlencode($title);
                $res = self::yt_request('GET', $url, $token);
                if (is_wp_error($res)) {
                    continue;
                }
                foreach ((array) ($res['items'] ?? array()) as $item) {
                    $vid = (string) ($item['id']['videoId'] ?? '');
                    if ($vid === '') {
                        continue;
                    }
                    if (self::normalize_yt_title((string) ($item['snippet']['title'] ?? '')) !== self::normalize_yt_title($title)) {
                        continue;
                    }
                    $found[] = $vid;
                }
            }
        }

        return array_values(array_unique($found));
    }

    /**
     * Find one of MY videos by exact title.
     *
     * @NEW 1.8.0
     * @param string $title
     * @return string video id or ''.
     */
    public static function find_my_video_id_by_title($title)
    {
        $ids = self::find_my_video_ids_by_titles(array((string) $title));
        return ! empty($ids) ? (string) $ids[0] : '';
    }

    /**
     * Chapters block ("Chapters:\n00:00 …") from the render's chapters.json.
     *
     * @NEW 1.8.0
     * @return string '' when absent.
     */
    public static function chapters_block($job_id)
    {
        $dir = self::job_temp_dir($job_id);
        if ($dir === '' || ! is_file($dir . '/chapters.json')) {
            return '';
        }
        $chapters = json_decode((string) @file_get_contents($dir . '/chapters.json'), true);
        if (! is_array($chapters) || empty($chapters)) {
            return '';
        }
        $lines = array();
        foreach ($chapters as $c) {
            $sec = (int) ($c['startSec'] ?? 0);
            $h = intdiv($sec, 3600); $m = intdiv($sec % 3600, 60); $s = $sec % 60;
            $stamp = ($h > 0) ? sprintf('%d:%02d:%02d', $h, $m, $s) : sprintf('%d:%02d', $m, $s);
            $lines[] = $stamp . ' ' . sanitize_text_field((string) ($c['label'] ?? ('Q' . (count($lines) + 1))));
        }
        return count($lines) ? implode("\n", $lines) : '';
    }

    /**
     * Attach a published job's video to its pillar playlist.
     *
     * Persists yt_video_id + yt_playlist_attached on the job row so subsequent
     * calls (backfill, resume, re-push) reuse the known YouTube video id
     * instead of re-running a fragile title search.
     *
     * @NEW 1.8.0
     */
    public static function attach_job_to_playlist($job_id, $video_id, $series, $fallback_name)
    {
        if (! self::file_video_into_playlist($job_id, $video_id, $series, $fallback_name)) {
            return false;
        }
        // Persist the known YouTube video id + attachment flag so the job is
        // never re-searched by title and the resume/backfill path skips it.
        if (class_exists('VS_Job_Repository')) {
            $repo = VS_Job_Repository::init();
            $job = $repo->get_job($job_id);
            if ($job) {
                $settings = self::decode_settings($job);
                $settings['yt_playlist_attached'] = true;
                $ids = isset($settings['yt_video_ids']) && is_array($settings['yt_video_ids']) ? $settings['yt_video_ids'] : array();
                $ids[] = $video_id;
                $settings['yt_video_ids'] = array_values(array_unique($ids));
                $repo->update_job_fields($job_id, array(
                    'yt_video_id' => $video_id,
                    'settings'    => wp_json_encode($settings),
                ));
            }
        }
        return true;
    }

    /**
     * File ONE video into the pillar playlist for a series/topic.
     *
     * A video that is already in the playlist is treated as SUCCESS: the
     * YouTube API answers 400 "duplicate" for a repeated insert, which would
     * otherwise keep the job permanently un-flagged and make every backfill
     * run repeat the same failing call.
     *
     * @NEW 1.8.0
     * @param string $job_id
     * @param string $video_id
     * @param string $series       CSV series column (playlist name).
     * @param string $fallback_name Topic name used when series is empty.
     * @return bool True when the video is in the playlist.
     */
    public static function file_video_into_playlist($job_id, $video_id, $series, $fallback_name)
    {
        if (! self::playlists_enabled() || $video_id === '') {
            return false;
        }
        $name = trim((string) $series) !== '' ? trim((string) $series) : trim((string) $fallback_name);
        if ($name === '') {
            return false;
        }
        $pid = self::ensure_playlist($name);
        if (is_wp_error($pid)) {
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log('yt.playlist.ensure_failed: ' . $pid->get_error_message(), 'warning', array('job_id' => $job_id, 'playlist' => $name));
            }
            return false;
        }
        $add = self::add_video_to_playlist($pid, $video_id);
        if (is_wp_error($add)) {
            $msg = strtolower($add->get_error_message());
            if (strpos($msg, 'duplicate') !== false || strpos($msg, 'already exist') !== false) {
                // Already filed — idempotent success.
                return true;
            }
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log('yt.playlist.add_failed: ' . $add->get_error_message(), 'warning', array('job_id' => $job_id, 'video_id' => $video_id));
            }
            return false;
        }
        return true;
    }

    /**
     * Buffer publish hook: file the published video into its pillar playlist
     * (series column, else topic name) and apply the rendered cover frame as
     * its YouTube thumbnail.
     *
     * Thin wrapper around sync_job_to_youtube() — the hook only signals
     * "this job went out". All work happens in the orchestrator so the
     * periodic backfill repairs a missed hook with exactly the same code.
     *
     * @NEW 1.8.0
     */
    public static function on_job_published($job_id, $video_url)
    {
        // Thin wrapper: the publish hook only signals "this job went out".
        // All playlist/thumbnail work happens in the orchestrator so the
        // periodic backfill can repair a missed hook with the same code.
        self::sync_job_to_youtube($job_id);
    }

    /**
     * Decode a job row's settings JSON into an array.
     *
     * @NEW 1.8.0
     * @param array $job Job row.
     * @return array
     */
    private static function decode_settings($job)
    {
        $settings = isset($job['settings']) ? $job['settings'] : array();
        if (is_string($settings)) {
            $settings = json_decode($settings, true);
        }
        return is_array($settings) ? $settings : array();
    }

    /**
     * Timestamp used to bound the video lookup window.
     *
     * @NEW 1.8.0
     * @param array $job
     * @param array $settings
     * @return int Unix timestamp, 0 when unknown.
     */
    private static function job_publish_anchor_ts($job, array $settings)
    {
        $candidates = array(
            isset($settings['publish_at']) ? $settings['publish_at'] : '',
            isset($job['publish_at']) ? $job['publish_at'] : '',
            isset($job['completed_at']) ? $job['completed_at'] : '',
            isset($job['created_at']) ? $job['created_at'] : '',
        );
        foreach ($candidates as $raw) {
            $raw = trim((string) $raw);
            if ($raw === '' || $raw === '0000-00-00 00:00:00') {
                continue;
            }
            // DATETIME columns are stored in UTC; ISO strings carry their own zone.
            $ts = (strpos($raw, 'T') !== false || preg_match('/(Z|[+-]\d{2}:?\d{2})$/', $raw))
                ? strtotime($raw)
                : strtotime($raw . ' UTC');
            if ($ts > 0) {
                return $ts;
            }
        }
        return 0;
    }

    /**
     * Every YouTube title Buffer may have used for this job.
     *
     * Buffer resolves the YouTube title per Buffer account (an account owns
     * exactly one YouTube channel), so one job pushed to two accounts
     * produces two videos with two different titles. The formula mirrors
     * VS_Buffer_Client::push_job_to_buffer_single() exactly:
     *   title_override > account youtube_title template > seo.title > '{topic} - Quiz'
     * then {topic}/{score}/{total}/{hook}/{hashtags} substitution, trim and
     * the 100-character YouTube title cap.
     *
     * @NEW 1.8.0
     * @param array $settings Job settings.
     * @param array $job      Job row (question_count).
     * @return array Candidate titles.
     */
    private static function youtube_title_candidates(array $settings, array $job)
    {
        $topic_name = (string) ($settings['topic_name'] ?? 'Quiz Video');
        $count      = absint($job['question_count'] ?? 5);
        $hook       = isset($settings['hook']) ? $settings['hook'] : '';
        $hashtags   = isset($settings['hashtags']) ? $settings['hashtags'] : '';
        if (is_array($hook)) {
            $hook = '';
        }
        if (is_array($hashtags)) {
            $hashtags = implode(' ', $hashtags);
        }
        $hook     = (string) $hook;
        $hashtags = (string) $hashtags;
        $override   = isset($settings['title_override']) ? sanitize_text_field((string) $settings['title_override']) : '';
        $seo_title  = isset($settings['seo']['title']) ? sanitize_text_field((string) $settings['seo']['title']) : '';

        $templates = array();
        if ($override !== '') {
            // A CSV title override replaces the template for EVERY account.
            $templates['__override__'] = $override;
        } else {
            if (class_exists('VS_Buffer_Account_Registry')) {
                $accounts = VS_Buffer_Account_Registry::get_accounts();
                if (is_array($accounts)) {
                    foreach ($accounts as $account_id => $account) {
                        $tpl = is_array($account) ? (string) ($account['youtube_title'] ?? '') : '';
                        if ($tpl !== '') {
                            $templates['acct_' . $account_id] = $tpl;
                        }
                    }
                }
            }
            // Legacy single-account installs read the global option.
            $global_tpl = (string) get_option('mcqvs_buffer_youtube_title', '');
            if ($global_tpl !== '') {
                $templates['__global__'] = $global_tpl;
            }
            if (empty($templates)) {
                // No template anywhere: Buffer fell back to seo.title / '{topic} - Quiz'.
                $templates['__fallback__'] = ($seo_title !== '') ? $seo_title : '{topic} - Quiz';
            }
        }

        $candidates = array();
        foreach ($templates as $tpl) {
            $t = str_replace(
                array('{topic}', '{score}', '{total}', '{hook}', '{hashtags}'),
                array($topic_name, $count, $count, $hook, $hashtags),
                (string) $tpl
            );
            $t = trim($t);
            if ($t === '') {
                $t = 'Quiz Video';
            }
            if (class_exists('VS_Buffer_Client')) {
                $t = VS_Buffer_Client::truncate_caption_for_service($t, '__youtube_title__');
            } elseif (function_exists('mb_substr')) {
                $t = mb_substr($t, 0, 100);
            } else {
                $t = substr($t, 0, 100);
            }
            $t = trim((string) $t);
            if ($t !== '') {
                $candidates[] = $t;
            }
        }
        return array_values(array_unique($candidates));
    }

    /**
     * Orchestrator: file the job's YouTube video into its pillar playlist and
     * apply the rendered cover frame as its thumbnail.
     *
     * Called by the publish hook (mcqvs_video_job_published) AND by the
     * periodic backfill, so a missed hook is repaired later with the exact
     * same code path. Idempotent: a job that is already attached (and
     * thumbnailed when the thumb setting is on) costs no API calls.
     *
     * @NEW 1.8.0
     * @param string $job_id Job id.
     * @return array {attached: bool, thumb: bool, video_ids: array, skipped: string}
     */
    public static function sync_job_to_youtube($job_id)
    {
        $out = array('attached' => false, 'thumb' => false, 'video_ids' => array(), 'skipped' => '');
        if (! self::playlists_enabled() || ! class_exists('VS_Job_Repository')) {
            $out['skipped'] = 'disabled';
            return $out;
        }
        $repo = VS_Job_Repository::init();
        $job  = $repo->get_job($job_id);
        if (! $job) {
            $out['skipped'] = 'no_job';
            return $out;
        }
        $settings = self::decode_settings($job);
        $cfg      = self::get_config();
        $thumb_on = ! empty($cfg['thumb']);

        // What still has to happen for this job?
        $need_playlist = empty($settings['yt_playlist_attached']);
        // A thumbnail can only be applied when the render produced a cover
        // image (settings.cover_image_url). Without one there is nothing to
        // retry — YouTube picks its own frame.
        $need_thumb = $thumb_on
            && ! empty($settings['cover_image_url'])
            && empty($settings['yt_cover_applied']);

        // Fast path: nothing left to do — costs no API calls.
        if (! $need_playlist && ! $need_thumb) {
            $out['skipped'] = 'already_synced';
            return $out;
        }

        // Back-off: a video that is not on YouTube yet (Buffer upload still
        // propagating) is retried at most every RETRY_COOLDOWN seconds.
        if ((int) ($settings['yt_playlist_retry_at'] ?? 0) > time()) {
            $out['skipped'] = 'cooldown';
            return $out;
        }

        $series = trim((string) ($settings['series'] ?? ''));
        $topic  = trim((string) ($settings['topic_name'] ?? ($settings['quizName'] ?? '')));

        // ---- 1) Resolve the YouTube video id(s) -----------------------------
        $ids = array();
        if (! empty($job['yt_video_id'])) {
            $ids[] = (string) $job['yt_video_id'];
        }
        if (isset($settings['yt_video_ids']) && is_array($settings['yt_video_ids'])) {
            foreach ($settings['yt_video_ids'] as $sid) {
                $sid = trim((string) $sid);
                if ($sid !== '') {
                    $ids[] = $sid;
                }
            }
        }
        $ids = array_values(array_unique($ids));

        $titles = array();
        if (empty($ids) && (($settings['videoFormat'] ?? 'shorts') !== 'youtube')) {
            $anchor  = self::job_publish_anchor_ts($job, $settings);
            $titles  = self::youtube_title_candidates($settings, $job);
            $ids     = self::find_my_video_ids_by_titles(
                $titles,
                $anchor > 0 ? $anchor - (2 * DAY_IN_SECONDS) : 0,
                $anchor > 0 ? $anchor + (90 * DAY_IN_SECONDS) : 0
            );
        }

        if (empty($ids)) {
            // Bounded exponential back-off (900s → 1800s → 3600s → 7200s): a
            // job whose video never reaches this channel (e.g. Buffer pushed it
            // to a different YouTube channel) must not keep spending quota
            // every tick.
            $attempts = (int) ($settings['yt_playlist_attempts'] ?? 0);
            $factor   = min(8, 1 << min($attempts, 3));
            $settings['yt_playlist_retry_at']  = time() + (self::RETRY_COOLDOWN * $factor);
            $settings['yt_playlist_attempts'] = $attempts + 1;
            $repo->update_job_fields($job_id, array('settings' => wp_json_encode($settings)));
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log(
                    'yt.playlist.video_not_found',
                    'warning',
                    array('job_id' => $job_id, 'titles' => $titles)
                );
            }
            $out['skipped'] = 'video_not_found';
            return $out;
        }
        unset($settings['yt_playlist_retry_at']);
        $settings['yt_playlist_attempts'] = 0;

        // ---- 2) Playlist ------------------------------------------------------
        $attached = ! empty($settings['yt_playlist_attached']);
        if ($need_playlist) {
            $attached = false;
            if ($series !== '' || $topic !== '') {
                foreach ($ids as $vid) {
                    if (self::file_video_into_playlist($job_id, $vid, $series, $topic)) {
                        $attached = true;
                    }
                }
            } else {
                // No series/topic: nothing to file into (not an error).
                $attached = true;
            }
            if ($attached) {
                $settings['yt_playlist_attached'] = true;
            }
        }

        // ---- 3) Thumbnail -----------------------------------------------------
        $thumb_done = ! empty($settings['yt_cover_applied']);
        if ($need_thumb) {
            $token = self::ensure_access_token();
            $thumb_done = false;
            foreach ($ids as $vid) {
                if (self::try_set_thumbnail($vid, $token, $job, $settings)) {
                    $thumb_done = true;
                }
            }
            if ($thumb_done) {
                $settings['yt_cover_applied'] = true;
            }
        }

        // ---- 4) Persist -------------------------------------------------------
        $settings['yt_video_ids'] = $ids;
        $fields = array('settings' => wp_json_encode($settings));
        if (empty($job['yt_video_id'])) {
            $fields['yt_video_id'] = $ids[0];
        }
        $repo->update_job_fields($job_id, $fields);

        if (class_exists('VS_Error_Logger')) {
            VS_Error_Logger::get_instance()->log(
                'yt.playlist.synced',
                'info',
                array(
                    'job_id'    => $job_id,
                    'video_ids' => $ids,
                    'attached'  => $attached,
                    'thumb'     => $thumb_done,
                )
            );
        }

        $out['attached']  = $attached;
        $out['thumb']     = $thumb_done;
        $out['video_ids'] = $ids;
        return $out;
    }

    /**
     * Backfill playlist attachment (and cover thumbnail) for completed jobs
     * that were published but never filed into their series/topic playlist —
     * e.g. published before the mcqvs_video_job_published hook was wired, or
     * the hook didn't fire because the Buffer push took the server-render
     * path, or the video had not reached YouTube yet at hook time.
     *
     * Idempotent: the orchestrator (sync_job_to_youtube) skips jobs that are
     * already attached, honours a per-job retry cooldown, and caps the number
     * of jobs touched per run so one cron tick cannot exhaust the YouTube
     * daily quota.
     *
     * @NEW 1.8.0
     * @return int Number of jobs synced.
     */
    public static function backfill_playlists()
    {
        if (! self::playlists_enabled() || ! class_exists('VS_Job_Repository')) {
            return 0;
        }
        global $wpdb;
        $table = $wpdb->prefix . 'vs_jobs';
        $synced   = 0;
        $examined = 0;

        $rows = $wpdb->get_results(
            "SELECT job_id FROM {$table}
             WHERE status = 'completed'
               AND (
                 (yt_video_id IS NOT NULL AND yt_video_id != '')
                 OR (published_channels IS NOT NULL AND published_channels != '')
               )
             ORDER BY id DESC
             LIMIT 200",
            ARRAY_A
        );
        if (! is_array($rows)) {
            // @FIX (silent-failure 2026-11-04): a failed SELECT (missing column,
            //       crashed table, DB error) used to return 0 with no log at all,
            //       making the broken repair path indistinguishable from a healthy
            //       "nothing to do" run. Surface $wpdb->last_error.
            if (class_exists('VS_Error_Logger')) {
                VS_Error_Logger::get_instance()->log_pipeline(
                    'yt.playlist.backfill',
                    'failed',
                    'cron',
                    'yt.playlist.backfill: eligible-jobs query failed: ' . (string) $wpdb->last_error,
                    'error',
                    array('table' => $table, 'last_error' => $wpdb->last_error)
                );
            }
            return 0;
        }

        // API budget per run. A playlist insert costs 50 quota units and a
        // thumbnail 50, so the number of jobs touched per tick is capped and
        // every job that actually performs work consumes the budget — a job
        // that keeps failing must not be able to spend the daily quota.
        $budget = 5;
        foreach ($rows as $row) {
            $job_id = isset($row['job_id']) ? $row['job_id'] : '';
            if (empty($job_id)) {
                continue;
            }
            $res = self::sync_job_to_youtube($job_id);
            $skip = isset($res['skipped']) ? (string) $res['skipped'] : '';
            if ($skip === 'already_synced' || $skip === 'cooldown' || $skip === 'disabled' || $skip === 'no_job') {
                // No API work performed — do not consume the budget.
                continue;
            }
            $budget--;
            $examined++;
            if ($skip === '') {
                $synced++;
            }
            if ($budget <= 0) {
                break;
            }
        }

        // @FIX (observability 2026-11-04): every run with eligible rows now
        //       leaves ONE fingerprint row (message carries the event name so a
        //       log-viewer search for "yt" finds it — message LIKE on
        //       wp_vs_logs is the only searchable column). This makes
        //       "eligible rows exist but no sync attempt happened" provable,
        //       which is otherwise indistinguishable from an idle cron.
        if (! empty($rows) && class_exists('VS_Error_Logger')) {
            VS_Error_Logger::get_instance()->log_pipeline(
                'yt.playlist.backfill',
                ($examined > 0 || $synced > 0) ? 'completed' : 'skipped',
                'cron',
                'yt.playlist.backfill: eligible=' . count($rows) . " examined={$examined} synced={$synced}",
                'info',
                array('eligible' => count($rows), 'examined' => $examined, 'synced' => $synced)
            );
        }

        return $synced;
    }

    /**
     * AJAX: save settings block (called from Settings → YouTube tab form JS).
     */
    public function ajax_save_config()
    {
        check_ajax_referer('mcqvs_yt_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }
        $cfg = self::get_config();
        $cfg['enabled']       = ! empty($_POST['enabled']) ? 1 : 0;
        $cfg['client_id']     = isset($_POST['client_id']) ? sanitize_text_field(wp_unslash($_POST['client_id'])) : $cfg['client_id'];
        $cfg['client_secret'] = isset($_POST['client_secret']) && $_POST['client_secret'] !== '' ? sanitize_text_field(wp_unslash($_POST['client_secret'])) : $cfg['client_secret'];
        $cfg['privacy']       = isset($_POST['privacy']) && in_array($_POST['privacy'], array('public', 'unlisted', 'private'), true) ? $_POST['privacy'] : 'public';
        $cfg['category_id']   = isset($_POST['category_id']) && preg_match('/^\d{1,2}$/', (string) $_POST['category_id']) ? (string) $_POST['category_id'] : '27';
        $cfg['thumb']         = ! empty($_POST['thumb']) ? 1 : 0;
        self::save_config($cfg);
        wp_send_json_success(true);
    }
}
