<?php

namespace DIT\TrendStudio\Services;

use DIT\TrendStudio\Infrastructure\Logger;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Image Renamer Service
 *
 * Renames attachment files (and intermediate sizes) to match the generated post title.
 * Also supports fixing double extensions (e.g., .webp.webp).
 *
 * @package DIT_TrendStudio
 */
class Image_Renamer
{
    private ?Logger $logger;

    public function __construct(?Logger $logger = null)
    {
        $this->logger = $logger;
    }

    /**
     * Fix double extensions (e.g., .webp.webp) for all attachments of a post.
     */
    public function fix_double_extensions(int $post_id): void
    {
        $attachments = get_children([
            'post_parent'    => $post_id,
            'post_type'      => 'attachment',
            'posts_per_page' => -1,
        ]);

        foreach ((array) $attachments as $attachment) {
            $this->process_single_attachment((int) $attachment->ID, null);
        }
    }

    /**
     * Rename all attachments of a post to match a target title and enforce a hard cap.
     *
     * @param int    $post_id     Post (Idea/Draft) ID.
     * @param string $target_title New headline used for metadata and base slug.
     * @param int    $max_images  Max images to keep. Surplus will be deleted. (0 = no limit)
     * @return array Map of [old_url => new_url] and optional ['_deleted_urls' => string[]]
     */
    public function rename_attachments_to_match_title(int $post_id, string $target_title, int $max_images = 0): array
    {
        $attachments = get_children([
            'post_parent'    => $post_id,
            'post_type'      => 'attachment',
            'posts_per_page' => -1,
            'orderby'        => 'ID',
            'order'          => 'ASC',
        ]);

        if (empty($attachments)) {
            return [];
        }

        $ids = [];
        foreach ($attachments as $a) {
            $ids[] = (int) $a->ID;
        }

        return $this->rename_attachments_by_ids($ids, $target_title, $max_images);
    }

    /**
     * Rename attachments in a specific order, optionally enforcing a hard cap (deleting surplus).
     *
     * @since 2.8.3
     * @MODIFIED 2026-02-19 - Preserve caller order (no sorting), rename size variants, and hard-delete surplus beyond cap.
     *
     * @param int[]  $attachment_ids Ordered list of attachment IDs.
     * @param string $target_title   Headline/title used for filenames and metadata.
     * @param int    $max_images     Max images to keep. Surplus will be deleted. (0 = no limit)
     * @return array Map of [old_url => new_url] plus optional ['_deleted_urls' => string[]]
     */
    public function rename_attachments_by_ids(array $attachment_ids, string $target_title, int $max_images = 0): array
    {
        $attachment_ids = array_values(array_unique(array_filter(array_map('intval', $attachment_ids))));
        if (empty($attachment_ids)) {
            return [];
        }

        $target_title = strip_tags($target_title);
        $base_slug = sanitize_title($target_title);

        $url_map = [];
        $deleted_urls = [];

        $keep_ids = $attachment_ids;
        $delete_ids = [];

        if ($max_images > 0 && count($attachment_ids) > $max_images) {
            $keep_ids = array_slice($attachment_ids, 0, $max_images);
            $delete_ids = array_slice($attachment_ids, $max_images);
        }

        // @MODIFIED 2026-02-22 - 3-Pillar Setup: Defer Deletion to Scheduler
        // We no longer physically delete files here. The Scheduler handles surplus deletion
        // and deep scrubbing simultaneously to prevent 404s. We just return the URLs that 
        // *would have* been deleted if the cap was hit here, so upstream can scrub them.
        foreach ($delete_ids as $del_id) {
            if (!\wp_attachment_is_image($del_id)) {
                continue;
            }

            $del_url = \wp_get_attachment_url($del_id);
            if (!empty($del_url)) {
                $deleted_urls[] = $del_url;
            }

            if ($this->logger) {
                $this->logger->info('Skipped surplus attachment deletion (deferred to Scheduler)', [
                    'attachment_id' => (int) $del_id,
                ]);
            }
        }

        // Rename kept attachments in provided order.
        $counter = 1;
        foreach ($keep_ids as $attachment_id) {
            if (!wp_attachment_is_image($attachment_id)) {
                continue;
            }

            $new_name = $base_slug . '-' . $counter;
            $pretty_name = $target_title . ' - ' . $counter;

            $single_map = $this->process_single_attachment($attachment_id, $new_name);
            if (!empty($single_map)) {
                $url_map = array_merge($url_map, $single_map);
            }

            wp_update_post([
                'ID'         => $attachment_id,
                'post_title' => $pretty_name,
                'post_name'  => $new_name,
            ]);
            update_post_meta($attachment_id, '_wp_attachment_image_alt', $pretty_name);

            $counter++;
        }

        if (!empty($deleted_urls)) {
            $url_map['_deleted_urls'] = $deleted_urls;
        }

        return $url_map;
    }

    /**
     * Process a single attachment: fix double extension and optionally rename.
     *
     * Returns a URL map for main file and intermediate sizes so callers can safely
     * replace src/srcset URLs in generated content.
     *
     * @MODIFIED 2026-02-19 - Renames intermediate sizes and returns a full URL map.
     *
     * @param int         $attachment_id
     * @param string|null $new_filename_base New base filename (without extension). Null keeps current base.
     * @return array Map of [old_url => new_url] for main file and intermediate sizes.
     */
    protected function process_single_attachment(int $attachment_id, ?string $new_filename_base): array
    {
        $file_path = get_attached_file($attachment_id);
        if (empty($file_path) || !file_exists($file_path)) {
            return [];
        }

        $old_url = wp_get_attachment_url($attachment_id);
        $old_dir_url = $old_url ? trailingslashit(dirname($old_url)) : '';

        $path_info = pathinfo($file_path);
        $dir = $path_info['dirname'] ?? '';
        $ext = strtolower($path_info['extension'] ?? '');
        $name = $path_info['filename'] ?? '';

        if ($dir === '' || $ext === '' || $name === '') {
            return [];
        }

        $dirty = false;
        $final_name = $name;

        // Fix double extensions (filename contains .ext and extension is also ext)
        if ($ext === 'webp' && preg_match('/\.webp$/i', $name)) {
            $final_name = preg_replace('/\.webp$/i', '', $name);
            $dirty = true;
        } elseif (($ext === 'jpg' || $ext === 'jpeg') && preg_match('/\.jpe?g$/i', $name)) {
            $final_name = preg_replace('/\.jpe?g$/i', '', $name);
            $dirty = true;
        } elseif ($ext === 'png' && preg_match('/\.png$/i', $name)) {
            $final_name = preg_replace('/\.png$/i', '', $name);
            $dirty = true;
        }

        if (!empty($new_filename_base)) {
            $final_name = $new_filename_base;
            $dirty = true;
        }

        if (!$dirty) {
            return [];
        }

        $new_path = $dir . '/' . $final_name . '.' . $ext;

        // Avoid collision
        if (file_exists($new_path) && $new_path !== $file_path) {
            $final_name .= '-' . uniqid();
            $new_path = $dir . '/' . $final_name . '.' . $ext;
        }

        $url_map = [];

        $meta = wp_get_attachment_metadata($attachment_id);
        if (!is_array($meta)) {
            $meta = [];
        }

        // Rename main file.
        if ($new_path !== $file_path) {
            if (!@rename($file_path, $new_path)) {
                return [];
            }
            update_attached_file($attachment_id, $new_path);
        }

        $uploads = wp_upload_dir();
        if (!empty($uploads['basedir'])) {
            $rel = ltrim(str_replace(trailingslashit($uploads['basedir']), '', $new_path), '/');
            if ($rel !== '') {
                $meta['file'] = $rel;
            }
        }

        // Rename intermediate sizes on disk and in metadata.
        if (!empty($meta['sizes']) && is_array($meta['sizes'])) {
            foreach ($meta['sizes'] as $size_key => $size_info) {
                if (empty($size_info['file'])) {
                    continue;
                }

                $old_size_file = (string) $size_info['file'];
                $w = (int) ($size_info['width'] ?? 0);
                $h = (int) ($size_info['height'] ?? 0);

                $size_ext = strtolower(pathinfo($old_size_file, PATHINFO_EXTENSION));
                if ($size_ext === '') {
                    $size_ext = $ext;
                }

                $new_size_file = $final_name;
                if ($w > 0 && $h > 0) {
                    $new_size_file .= '-' . $w . 'x' . $h;
                }
                $new_size_file .= '.' . $size_ext;

                $old_size_path = $dir . '/' . $old_size_file;
                $new_size_path = $dir . '/' . $new_size_file;

                if ($old_size_path !== $new_size_path && file_exists($old_size_path)) {
                    if (file_exists($new_size_path)) {
                        $new_size_file = $final_name . '-' . uniqid() . '-' . $w . 'x' . $h . '.' . $size_ext;
                        $new_size_path = $dir . '/' . $new_size_file;
                    }
                    @rename($old_size_path, $new_size_path);
                }

                $meta['sizes'][$size_key]['file'] = $new_size_file;

                if ($old_dir_url !== '') {
                    $url_map[$old_dir_url . $old_size_file] = $old_dir_url . $new_size_file;
                }
            }
        }

        // Persist metadata update.
        if (!empty($meta)) {
            wp_update_attachment_metadata($attachment_id, $meta);
        }

        // Map main URL.
        $new_url = wp_get_attachment_url($attachment_id);
        if (!empty($old_url) && !empty($new_url) && $old_url !== $new_url) {
            $url_map[$old_url] = $new_url;
        }

        if ($this->logger) {
            $this->logger->info('Renamed attachment', [
                'attachment_id' => (int) $attachment_id,
                'from'          => $file_path,
                'to'            => $new_path,
            ]);
        }

        return $url_map;
    }
}
