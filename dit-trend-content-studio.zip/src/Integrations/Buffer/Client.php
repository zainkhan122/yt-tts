<?php

namespace DIT\TrendStudio\Integrations\Buffer;

class Client
{
    const API_URL = 'https://api.buffer.com';
    const ORG_ID_TRANSIENT = 'nm_buffer_org_id';
    const CHANNELS_TRANSIENT = 'nm_buffer_channels';

    private $access_token;
    private $logger;
    private $account_id;

    public function __construct(string $access_token, $logger = null, string $account_id = '')
    {
        $this->access_token = $access_token;
        $this->logger = $logger;
        $this->account_id = $account_id;
    }

    public function get_account_id(): string
    {
        return $this->account_id;
    }

    public function graphql_request(string $query): array
    {
        $response = wp_remote_post(self::API_URL, [
            'timeout' => 30,
            'headers' => [
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $this->access_token,
            ],
            'body' => wp_json_encode(['query' => $query]),
        ]);

        if (is_wp_error($response)) {
            $this->log_error('GraphQL request failed', $response->get_error_message());
            return ['success' => false, 'errors' => [['message' => $response->get_error_message()]]];
        }

        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if ($status_code !== 200) {
            $this->log_error('GraphQL request HTTP error', "Status: {$status_code}, Body: {$body}");
            return ['success' => false, 'errors' => [['message' => "HTTP {$status_code}: {$body}"]]];
        }

        if (isset($data['errors']) && !empty($data['errors'])) {
            $this->log_error('GraphQL errors', wp_json_encode($data['errors']));
            return ['success' => false, 'errors' => $data['errors']];
        }

        return ['success' => true, 'data' => $data['data'] ?? []];
    }

    public function get_organization_id(): ?string
    {
        $cache_key = self::ORG_ID_TRANSIENT . ($this->account_id ? '_' . $this->account_id : '');
        $cached = get_option($cache_key, null);
        if ($cached !== null) {
            return $cached;
        }

        $query = '
            query GetOrganizations {
                account {
                    organizations {
                        id
                        name
                    }
                }
            }
        ';

        $result = $this->graphql_request($query);

        if (!$result['success']) {
            $this->log_error('Failed to get organizations', wp_json_encode($result['errors']));
            return null;
        }

        $orgs = $result['data']['account']['organizations'] ?? [];
        if (empty($orgs)) {
            $this->log_error('No organizations found', 'API key may not have access to any Buffer organization');
            return null;
        }

        $org_id = $orgs[0]['id'];
        $cache_key = self::ORG_ID_TRANSIENT . ($this->account_id ? '_' . $this->account_id : '');
        update_option($cache_key, $org_id, false);

        return $org_id;
    }

    public function get_channels(): array
    {
        $token_hash = md5($this->access_token);
        $cache_key = self::CHANNELS_TRANSIENT . '_' . $token_hash . ($this->account_id ? '_' . $this->account_id : '');
        $cached = get_option($cache_key, null);
        if ($cached !== null) {
            return $cached;
        }

        $org_id = $this->get_organization_id();
        if (!$org_id) {
            return [];
        }

        // Buffer GraphQL API does NOT support variables — org ID must be inlined as string literal
        $org_id_escaped = addslashes($org_id);
        $query = "
            query GetChannels {
                channels(input: { organizationId: \"{$org_id_escaped}\" }) {
                    id
                    name
                    displayName
                    service
                    avatar
                    isQueuePaused
                }
            }
        ";

        $result = $this->graphql_request($query);

        if (!$result['success']) {
            $this->log_error('Failed to get channels', wp_json_encode($result['errors']));
            return [];
        }

        $channels = $result['data']['channels'] ?? [];
        if (empty($channels) && $this->logger) {
            $this->logger->info('Buffer get_channels: empty response', [
                'org_id' => $org_id,
                'raw_data' => wp_json_encode($result['data']),
            ]);
        }

        $formatted = [];
        foreach ($channels as $channel) {
            $formatted[$channel['id']] = [
                'id' => $channel['id'],
                'name' => $channel['name'] ?? $channel['displayName'] ?? '',
                'service' => strtolower($channel['service']),
                'avatar' => $channel['avatar'] ?? '',
                'isQueuePaused' => $channel['isQueuePaused'] ?? false,
            ];
        }

        update_option($cache_key, $formatted, false);

        return $formatted;
    }

    public function create_post(
        string $channel_id,
        string $text,
        string $service,
        string $post_type = 'post',
        ?string $image_url = null,
        bool $is_link_post = false,
        string $link_url = '',
        ?string $pinterest_board_id = null,
        ?string $pinterest_title = null,
        ?string $tiktok_title = null,
        ?string $youtube_title = null,
        ?string $youtube_category_id = null,
        ?string $youtube_privacy = null,
        ?bool $youtube_embeddable = null,
        ?string $youtube_license = null,
        ?bool $youtube_made_for_kids = null,
        ?bool $youtube_notify_subscribers = null,
        ?bool $youtube_is_ai_generated = null
    ): array {
        $mutation_body = $this->build_create_post_mutation_body(
            $channel_id, $text, $service, $post_type, $image_url,
            $is_link_post, $link_url, $pinterest_board_id, $pinterest_title, $tiktok_title,
            $youtube_title, $youtube_category_id, $youtube_privacy, $youtube_embeddable,
            $youtube_license, $youtube_made_for_kids, $youtube_notify_subscribers, $youtube_is_ai_generated
        );

        $query = "mutation CreatePost {\n            {$mutation_body}\n        }";

        $result = $this->graphql_request($query);

        if (!$result['success']) {
            return $result;
        }

        $post_data = $result['data']['createPost']['post'] ?? null;
        if ($post_data) {
            return ['success' => true, 'post' => $post_data];
        }

        $mutation_error = $result['data']['createPost'] ?? null;
        if (isset($mutation_error['message'])) {
            $full_error = $mutation_error;
            return ['success' => false, 'errors' => [['message' => $mutation_error['message'], 'full_error' => $full_error]]];
        }

        return ['success' => false, 'errors' => [['message' => 'Unknown error from Buffer API']]];
    }

    public function create_posts_batch(array $channel_posts): array
    {
        if (empty($channel_posts)) {
            return ['success' => false, 'errors' => [['message' => 'No channel posts provided']]];
        }

        $mutation_parts = [];
        $alias_map = [];

        foreach ($channel_posts as $post_key => $post) {
            // Use post_key for GraphQL alias (must be unique), but real channel_id for API
            $alias = 'c' . preg_replace('/[^a-zA-Z0-9]/', '_', $post_key);
            $real_channel_id = $post['channel_id'] ?? $post_key;
            $alias_map[$alias] = $post_key;

            $body = $this->build_create_post_mutation_body(
                $real_channel_id,
                $post['text'],
                $post['service'],
                $post['post_type'] ?? 'post',
                $post['image_url'] ?? null,
                $post['is_link_post'] ?? false,
                $post['link_url'] ?? '',
                $post['pinterest_board_id'] ?? null,
                $post['pinterest_title'] ?? null,
                $post['tiktok_title'] ?? null,
                $post['youtube_title'] ?? null,
                $post['youtube_category_id'] ?? null,
                $post['youtube_privacy'] ?? null,
                $post['youtube_embeddable'] ?? null,
                $post['youtube_license'] ?? null,
                $post['youtube_made_for_kids'] ?? null,
                $post['youtube_notify_subscribers'] ?? null,
                $post['youtube_is_ai_generated'] ?? null
            );

            $mutation_parts[] = "{$alias}: {$body}";
        }

        $query = "mutation CreatePostsBatch {\n  " . implode("\n  ", $mutation_parts) . "\n}";
        $result = $this->graphql_request($query);

        if (!$result['success']) {
            return $result;
        }

        $output = [];
        foreach ($alias_map as $alias => $channel_id) {
            $mutation_result = $result['data'][$alias] ?? [];
            if (isset($mutation_result['post'])) {
                $output[$channel_id] = ['success' => true, 'post' => $mutation_result['post']];
            } else {
                $full_error = $mutation_result;
                $output[$channel_id] = [
                    'success' => false,
                    'errors' => [['message' => $mutation_result['message'] ?? 'Unknown error from Buffer API', 'full_error' => $full_error]],
                ];
            }
        }

        return ['success' => true, 'results' => $output];
    }

    private function build_create_post_mutation_body(
        string $channel_id,
        string $text,
        string $service,
        string $post_type = 'post',
        ?string $image_url = null,
        bool $is_link_post = false,
        string $link_url = '',
        ?string $pinterest_board_id = null,
        ?string $pinterest_title = null,
        ?string $tiktok_title = null,
        ?string $youtube_title = null,
        ?string $youtube_category_id = null,
        ?string $youtube_privacy = null,
        ?bool $youtube_embeddable = null,
        ?string $youtube_license = null,
        ?bool $youtube_made_for_kids = null,
        ?bool $youtube_notify_subscribers = null,
        ?bool $youtube_is_ai_generated = null
    ): string {
        $due_at = gmdate('Y-m-d\TH:i:s.000\Z', time() + 300);

        $metadata = $this->build_service_metadata($service, $post_type, $is_link_post, $link_url, $pinterest_board_id, $pinterest_title, $tiktok_title, $youtube_title, $youtube_category_id, $youtube_privacy, $youtube_embeddable, $youtube_license, $youtube_made_for_kids, $youtube_notify_subscribers, $youtube_is_ai_generated);

        $assets_graphql = '';
        if (!empty($image_url)) {
            $escaped_url = $this->graphql_escape_string($image_url);
            // YouTube uses video asset, others use image asset
            if ($service === 'youtube') {
                $assets_graphql = 'assets: [ { video: { url: "' . $escaped_url . '" } } ]';
            } else {
                $assets_graphql = 'assets: [ { image: { url: "' . $escaped_url . '", thumbnailUrl: "' . $escaped_url . '" } } ]';
            }
        }

        $metadata_graphql = '';
        if (!empty($metadata)) {
            $metadata_parts = [];
            foreach ($metadata as $service_key => $service_meta) {
                $service_meta_parts = [];
                foreach ($service_meta as $key => $value) {
                    if ($key === 'linkAttachment' && is_array($value) && isset($value['url'])) {
                        $url_escaped = $this->graphql_escape_string($value['url']);
                        $service_meta_parts[] = "{$key}: { url: \"{$url_escaped}\" }";
                    } elseif (is_bool($value)) {
                        $service_meta_parts[] = "{$key}: " . ($value ? 'true' : 'false');
                    } elseif ($key === 'type') {
                        $service_meta_parts[] = "{$key}: {$value}";
                    } else {
                        $value_escaped = $this->graphql_escape_string($value);
                        $service_meta_parts[] = "{$key}: \"{$value_escaped}\"";
                    }
                }
                if (!empty($service_meta_parts)) {
                    $metadata_parts[] = "{$service_key}: { " . implode(", ", $service_meta_parts) . " }";
                }
            }
            if (!empty($metadata_parts)) {
                $metadata_graphql = 'metadata: { ' . implode(", ", $metadata_parts) . ' }';
            }
        }

        $text_escaped = $this->graphql_escape_string($text);
        $channel_id_escaped = $this->graphql_escape_string($channel_id);

        return "createPost(input: {
                    text: \"{$text_escaped}\"
                    channelId: \"{$channel_id_escaped}\"
                    schedulingType: automatic
                    mode: customScheduled
                    dueAt: \"{$due_at}\"
                    {$assets_graphql}
                    {$metadata_graphql}
                }) {
                    ... on PostActionSuccess {
                        post {
                            id
                            text
                            dueAt
                            status
                        }
                    }
                    ... on MutationError {
                        message
                    }
                }";
    }

    private function build_service_metadata(string $service, string $post_type, bool $is_link_post, string $link_url, ?string $pinterest_board_id = null, ?string $pinterest_title = null, ?string $tiktok_title = null, ?string $youtube_title = null, ?string $youtube_category_id = null, ?string $youtube_privacy = null, ?bool $youtube_embeddable = null, ?string $youtube_license = null, ?bool $youtube_made_for_kids = null, ?bool $youtube_notify_subscribers = null, ?bool $youtube_is_ai_generated = null): array
    {
        $valid_types = [
            'facebook' => ['post', 'story', 'reel'],
            'instagram' => ['post', 'story', 'reel'],
            'twitter' => ['post'],
            'linkedin' => ['post'],
            'pinterest' => ['post'],
            'youtube' => ['video'],
            'threads' => ['post', 'story'],
            'tiktok' => ['post', 'video'],
        ];

        $allowed = $valid_types[$service] ?? ['post'];
        if (!in_array($post_type, $allowed, true)) {
            $post_type = 'post';
        }

        $meta = [];

        switch ($service) {
            case 'facebook':
                $meta['facebook'] = ['type' => $post_type];
                if ($is_link_post && !empty($link_url)) {
                    $meta['facebook']['linkAttachment'] = ['url' => $link_url];
                }
                break;

            case 'instagram':
                $meta['instagram'] = [
                    'type' => $post_type,
                    'shouldShareToFeed' => true,
                ];
                break;

            case 'linkedin':
                if ($is_link_post && !empty($link_url)) {
                    $meta['linkedin'] = ['linkAttachment' => ['url' => $link_url]];
                }
                break;

            case 'pinterest':
                $pinterest_meta = [];
                if (!empty($pinterest_title)) {
                    $pinterest_meta['title'] = mb_substr($pinterest_title, 0, 100, 'UTF-8');
                }
                if (!empty($link_url)) {
                    $pinterest_meta['url'] = $link_url;
                }
                if (!empty($pinterest_board_id)) {
                    $pinterest_meta['boardServiceId'] = $pinterest_board_id;
                }
                if (!empty($pinterest_meta)) {
                    $meta['pinterest'] = $pinterest_meta;
                }
                break;

            case 'tiktok':
                if (!empty($tiktok_title)) {
                    $meta['tiktok'] = ['title' => $tiktok_title];
                } else {
                    $meta['tiktok'] = [];
                }
                break;

            case 'youtube':
                $youtube_meta = [];
                if (!empty($youtube_title)) {
                    $youtube_meta['title'] = $youtube_title;
                }
                if (!empty($youtube_category_id)) {
                    $youtube_meta['categoryId'] = $youtube_category_id;
                }
                if (!empty($youtube_privacy)) {
                    $youtube_meta['privacy'] = $youtube_privacy;
                }
                if ($youtube_embeddable !== null) {
                    $youtube_meta['embeddable'] = $youtube_embeddable;
                }
                if (!empty($youtube_license)) {
                    $youtube_meta['license'] = $youtube_license;
                }
                if ($youtube_made_for_kids !== null) {
                    $youtube_meta['madeForKids'] = $youtube_made_for_kids;
                }
                if ($youtube_notify_subscribers !== null) {
                    $youtube_meta['notifySubscribers'] = $youtube_notify_subscribers;
                }
                if ($youtube_is_ai_generated !== null) {
                    $youtube_meta['isAiGenerated'] = $youtube_is_ai_generated;
                }
                if (!empty($youtube_meta)) {
                    $meta['youtube'] = $youtube_meta;
                }
                break;
        }

        return $meta;
    }

    public function get_pinterest_boards(string $channel_id): array
    {
        $transient_key = 'nm_buffer_pinterest_boards_' . md5($channel_id . $this->access_token);
        $cached = get_transient($transient_key);
        if ($cached !== false) {
            return $cached;
        }

        $channel_id_escaped = addslashes($channel_id);
        $query = "
            query GetChannel {
                channel(input: { id: \"{$channel_id_escaped}\" }) {
                    metadata {
                        ... on PinterestMetadata {
                            boards {
                                serviceId
                                name
                            }
                        }
                    }
                }
            }
        ";

        $result = $this->graphql_request($query);

        if (!$result['success']) {
            $this->log_error('Failed to get Pinterest boards', wp_json_encode($result['errors']));
            return [];
        }

        $boards_raw = $result['data']['channel']['metadata']['boards'] ?? [];
        $boards = [];
        foreach ($boards_raw as $board) {
            $boards[$board['serviceId']] = $board['name'];
        }

        set_transient($transient_key, $boards, 15 * MINUTE_IN_SECONDS);

        return $boards;
    }

    /**
     * Read cached channels from wp_options without making any API call.
     * Returns empty array if no cache exists.
     */
    public function get_cached_channels(): array
    {
        $token_hash = md5($this->access_token);
        $cache_key = self::CHANNELS_TRANSIENT . '_' . $token_hash . ($this->account_id ? '_' . $this->account_id : '');
        $cached = get_option($cache_key, null);
        if ($cached !== null) {
            return $cached;
        }
        return [];
    }

    public function clear_all_caches(?string $specific_account_id = null): void
    {
        $account_suffix = $specific_account_id ?? $this->account_id;
        $org_key = self::ORG_ID_TRANSIENT . ($account_suffix ? '_' . $account_suffix : '');
        delete_option($org_key);
        delete_option(self::CHANNELS_TRANSIENT . '_' . md5($this->access_token) . ($account_suffix ? '_' . $account_suffix : ''));

        global $wpdb;
        $like = '%_transient_nm_buffer_pinterest_boards_%';
        if ($account_suffix) {
            $like = '%_transient_nm_buffer_pinterest_boards_' . $wpdb->esc_like($account_suffix) . '%';
        }
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
            $like,
            str_replace('_transient_', '_transient_timeout_', $like)
        ));
    }

    private function graphql_escape_string(string $string): string
    {
        return str_replace(
            ["\\", "\n", "\r", "\t", "\""],
            ["\\\\", "\\n", "\\r", "\\t", "\\\""],
            $string
        );
    }

    private function log_error(string $context, string $message): void
    {
        if ($this->logger) {
            $this->logger->error("NM Buffer Client: {$context} - {$message}");
        }
    }
}
