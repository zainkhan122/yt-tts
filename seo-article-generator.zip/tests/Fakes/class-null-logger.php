<?php

namespace SEO_Article_Generator\Tests\Fakes;

/**
 * Null Logger for testing
 */
class Null_Logger extends \SEO_Article_Generator\Logger
{
    public function __construct()
    {
        // Bypass parent constructor
    }

    public function log($level, $message, $context = array()) {}
    public function info($message, $context = array()) {}
    public function warning($message, $context = array()) {}
    public function error($message, $context = array()) {}
    public function debug($message, $context = array()) {}
}
