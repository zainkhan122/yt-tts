<?php

namespace SEO_Article_Generator\Support;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Section_Registry {

	public static function map(): array {
		return [
			'download' => [
				'section'    => 'download',
				'zone'       => 'download',
				'data_attr'  => 'download',
				'render_key' => 'download',
				'payload'    => 'download_section',
			],
			'tech_specs' => [
				'section'    => 'tech_specs',
				'zone'       => 'tech_specs',
				'data_attr'  => 'tech_specs',
				'render_key' => 'tech_specs',
				'payload'    => 'tech_specs',
			],
			'whats_new' => [
				'section'    => 'whats_new',
				'zone'       => 'whats_new',
				'data_attr'  => 'changelog',
				'render_key' => 'whats_new',
				'payload'    => 'whats_new',
			],
			'moat' => [
				'section'    => 'moat',
				'zone'       => 'moat_content',
				'data_attr'  => 'moat',
				'render_key' => 'moat_content',
				'payload'    => 'moat_data',
			],
			'pros_cons' => [
				'section'    => 'pros_cons',
				'zone'       => 'pros_cons',
				'data_attr'  => 'pros_cons',
				'render_key' => 'pros_cons',
				'payload'    => 'pros_cons',
			],
			'faq' => [
				'section'    => 'faq',
				'zone'       => 'faq',
				'data_attr'  => 'faq',
				'render_key' => 'faq',
				'payload'    => 'faqs',
			],
			'features' => [
				'section'    => 'features',
				'zone'       => 'features',
				'data_attr'  => 'features',
				'render_key' => 'features',
				'payload'    => 'features',
			],
			'competitors' => [
				'section'    => 'competitors',
				'zone'       => 'competitors',
				'data_attr'  => 'competitors',
				'render_key' => 'competitors',
				'payload'    => 'competitors',
			],
			'requirements' => [
				'section'    => 'requirements',
				'zone'       => 'system_requirements',
				'data_attr'  => 'system_requirements',
				'render_key' => 'system_requirements',
				'payload'    => 'system_requirements',
			],
			'installation' => [
				'section'    => 'installation',
				'zone'       => 'installation',
				'data_attr'  => 'installation',
				'render_key' => 'installation',
				'payload'    => 'installation_guide',
			],
		];
	}

	public static function normalize( string $key ): string {
		$key = strtolower( trim( $key ) );

		$aliases = [
			'techspecs'            => 'tech_specs',
			'tech_specs'           => 'tech_specs',
			'specs'                => 'tech_specs',
			'whatsnew'             => 'whats_new',
			'whats_new'            => 'whats_new',
			'changelog'            => 'whats_new',
			'moatcontent'          => 'moat',
			'moat_content'         => 'moat',
			'proscons'             => 'pros_cons',
			'pros_cons'            => 'pros_cons',
			'systemrequirements'   => 'requirements',
			'system_requirements'  => 'requirements',
			'requirements'         => 'requirements',
			'faqs'                 => 'faq',
		];

		return $aliases[ $key ] ?? $key;
	}

	public static function zones_for_sections( array $sections ): array {
		$map = self::map();
		$out = [];

		foreach ( $sections as $section ) {
			$section = self::normalize( (string) $section );
			if ( isset( $map[ $section ] ) ) {
				$out[] = $map[ $section ]['zone'];
			}
		}

		return array_values( array_unique( $out ) );
	}
}
