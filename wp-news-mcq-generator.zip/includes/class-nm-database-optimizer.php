<?php

/**
 * Database Optimizer
 *
 * @version 2.1 - Restored initial sync cron method
 *
 * @MODIFIED: Added the missing public static function run_initial_sync()
 * This method was in the V23 procedural cron file but was
 * lost during the refactor, causing a fatal error.
 */

if (! defined('ABSPATH')) {
	exit;
}

if (! class_exists('NM_Database_Optimizer')) {

	class NM_Database_Optimizer
	{


		private static $instance = null;

    public static function init()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }

        add_action('save_post_mcq', array(self::class, 'sync_on_save'), 50, 3);

        return true;
    }

		/**
		 * Safe table creation
		 */
		public static function create_tables()
		{
			try {
				global $wpdb;

				if (! $wpdb || ! $wpdb->ready) {
					return false;
				}

				$charset_collate = $wpdb->get_charset_collate();

				// Simple MCQ data table
				$mcq_table = $wpdb->prefix . 'nm_mcq_data';
				$mcq_sql   = "CREATE TABLE IF NOT EXISTS $mcq_table (
                id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                post_id bigint(20) unsigned NOT NULL,
                question text NOT NULL,
                options longtext NOT NULL,
                correct_answer char(1) NOT NULL,
                explanation text,
                difficulty varchar(20) DEFAULT 'medium',
				cognitive_level varchar(20) DEFAULT 'understand',
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY post_id (post_id),
                KEY difficulty (difficulty),
				KEY cognitive_level (cognitive_level),
                KEY created_at (created_at)
            ) $charset_collate;";

				require_once ABSPATH . 'wp-admin/includes/upgrade.php';
				dbDelta($mcq_sql);

				// Ensure cognitive_level column exists even on older installs
				$column_exists = $wpdb->get_var(
					$wpdb->prepare(
						"SHOW COLUMNS FROM {$mcq_table} LIKE %s",
						'cognitive_level'
					)
				);

				if (empty($column_exists)) {
					// Add the cognitive_level column
					$wpdb->query(
						"ALTER TABLE {$mcq_table}
                     ADD COLUMN cognitive_level varchar(20) DEFAULT 'understand' AFTER difficulty"
					);

					// Add an index on cognitive_level if missing
					$index_exists = $wpdb->get_var(
						$wpdb->prepare(
							"SHOW INDEX FROM {$mcq_table} WHERE Key_name = %s",
							'idx_nm_mcq_data_cognitive_level'
						)
					);

					if (empty($index_exists)) {
						$wpdb->query(
							"CREATE INDEX idx_nm_mcq_data_cognitive_level
                         ON {$mcq_table} (cognitive_level)"
						);
					}
				}

        return true;
    } catch (Exception $e) {
        return false;
    }
    }

    public static function sync_on_save($post_id, $post, $update)
    {
        if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) {
            return;
        }
        if (! $post || $post->post_type !== 'mcq') {
            return;
        }
        if (! in_array($post->post_status, array('publish', 'draft', 'pending'), true)) {
            return;
        }
        self::sync_mcq_data($post_id);
    }

		/**
		 * Safe MCQ data sync - USES SERIALIZATION (not JSON)
		 */
		/**
		 * Syncs a single MCQ post into the optimized table.
		 * ✅ MODIFIED v7.3.10: Now returns bool for proper error tracking
		 */
		public static function sync_mcq_data($post_id)
		{
			global $wpdb;

			$post = get_post($post_id);
			if (! $post || $post->post_type !== 'mcq') {
				return false;
			}

			$table = $wpdb->prefix . 'nm_mcq_data';

			// Core fields
			$question    = get_the_title($post_id);
			$options     = get_post_meta($post_id, 'mcq_options', true);
			$answer      = get_post_meta($post_id, 'mcq_answer', true);
			$explanation = get_post_meta($post_id, 'mcq_explanation', true);

			// Difficulty / cognitive level
			$difficulty      = get_post_meta($post_id, 'mcq_difficulty', true);
			$cognitive_level = get_post_meta($post_id, 'mcq_cognitive_level', true);

			// Normalize difficulty and cognitive_level
			$difficulty_raw      = get_post_meta($post_id, 'mcq_difficulty', true) ?: 'medium';
			$cognitive_level_raw = get_post_meta($post_id, 'mcq_cognitive_level', true) ?: 'understand';
			$difficulty          = sanitize_key(trim((string) $difficulty_raw));
			$cognitive_level     = sanitize_key(trim((string) $cognitive_level_raw));

			// ---------------------------------------------------------------------
			// NEW: Primary topic_slug and exam_slug from taxonomies
			// ---------------------------------------------------------------------
			$topic_slug = '';
			$exam_slug  = '';

			// Topic taxonomy (use first term slug)
			$topic_terms = wp_get_post_terms($post_id, 'topic', array('fields' => 'slugs'));
			if (! is_wp_error($topic_terms) && ! empty($topic_terms)) {
				// Use the first slug as the primary topic
				$topic_slug = sanitize_title($topic_terms[0]);
			}

			// Exam taxonomy (nm_exam) - use first term slug
			$exam_terms = wp_get_post_terms($post_id, 'nm_exam', array('fields' => 'slugs'));
			if (! is_wp_error($exam_terms) && ! empty($exam_terms)) {
				$exam_slug = sanitize_title($exam_terms[0]);
			}

			// Serialize options if needed
			if (is_array($options)) {
				$options_serialized = maybe_serialize($options);
			} else {
				$options_serialized = (string) $options;
			}

			// Safety guard: do not insert incomplete MCQs
			if (empty($question) || empty($options_serialized) || empty($answer)) {
				return false; // ✅ MODIFIED v7.3.10: Return false for incomplete data
			}

			$data = array(
				'post_id'         => (int) $post_id,
				'question'        => $question,
				'options'         => $options_serialized,
				'correct_answer'  => $answer,
				'explanation'     => $explanation,
				'difficulty'      => $difficulty,
				'cognitive_level' => $cognitive_level,
				'topic_slug'      => $topic_slug,
				'exam_slug'       => $exam_slug,
				'updated_at'      => current_time('mysql'),
			);

			// When inserting new rows, created_at will default via table definition
			$format = array(
				'%d', // post_id
				'%s', // question
				'%s', // options
				'%s', // correct_answer
				'%s', // explanation
				'%s', // difficulty
				'%s', // cognitive_level
				'%s', // topic_slug
				'%s', // exam_slug
				'%s', // updated_at
			);

			$result = $wpdb->replace($table, $data, $format);

			// ✅ MODIFIED v7.3.10: Return success status
			return $result !== false;
		}

		/**
		 * ✅ NEW: Restored batch processor from V23 cron file
		 * This method is called by NM_Cron_Manager::run_initial_sync()
		 * and was the cause of the fatal error.
		 */
		public static function run_initial_sync()
		{
			global $wpdb;

			// Check if sync is already in progress
			$sync_lock = get_transient('nm_sync_lock');
			if ($sync_lock) {
				return;
			}

			// Set lock for 5 minutes
			set_transient('nm_sync_lock', true, 5 * MINUTE_IN_SECONDS);

			$table = $wpdb->prefix . 'nm_mcq_data';
			if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
				delete_transient('nm_sync_lock');
				return; // Table doesn't exist
			}

			$batch      = (int) get_option('nm_sync_batch', 0);
			$batch_size = 100; // Sync 100 MCQs per batch
			$offset     = $batch * $batch_size;

			$mcqs = get_posts(
				array(
					'post_type'      => 'mcq',
					'posts_per_page' => $batch_size,
					'offset'         => $offset,
					'post_status'    => 'publish',
					'orderby'        => 'ID',
					'order'          => 'ASC',
					'fields'         => 'ids', // More efficient
				)
			);

			if (empty($mcqs)) {
				// Sync complete!
				delete_option('nm_sync_batch');
				update_option('nm_optimizer_initial_sync_done', true);
				delete_transient('nm_sync_lock');
				return;
			}

			$synced = 0;
			$errors = 0;

			foreach ($mcqs as $post_id) {
				// Call the existing method in this class
				$result = self::sync_mcq_data($post_id);
				if ($result) {
					++$synced;
				} else {
					++$errors;
				}
			}

			// Schedule next batch
			update_option('nm_sync_batch', $batch + 1);

			// Re-schedule the *same* cron hook to continue the batch
			if (! wp_next_scheduled('nm_initial_sync_cron')) {
				wp_schedule_single_event(time() + 30, 'nm_initial_sync_cron');
			}

			delete_transient('nm_sync_lock');
		}
		/**
		 * Simple optimized query
		 *
		 * Now supports:
		 * - difficulty
		 * - cognitive_level
		 * - topic (via topic_slug)
		 * - exam (via exam_slug)
		 */
		public static function get_mcqs_optimized($args = array())
		{
			try {
				global $wpdb;

				$defaults = array(
					'count'           => 5,
					'topic'           => '',
					'exam'            => '',
					'difficulty'      => '',
					'cognitive_level' => '',
					'exclude_ids'     => array(),
					'orderby'         => 'random', // 'random' or 'latest'
				);

				$args = wp_parse_args($args, $defaults);

				$mcq_table = $wpdb->prefix . 'nm_mcq_data';

				// Check if our table exists, fallback to regular WP_Query
				$table_exists = $wpdb->get_var("SHOW TABLES LIKE '{$mcq_table}'");
				if (! $table_exists) {
					return self::fallback_get_mcqs($args);
				}

				$where_conditions = array('1=1');
				$prepare_values   = array();

				// Topic filter (topic_slug)
				if (! empty($args['topic'])) {
					$where_conditions[] = 'topic_slug = %s';
					$prepare_values[]   = sanitize_title($args['topic']);
				}

				// Exam filter (exam_slug)
				if (! empty($args['exam'])) {
					$where_conditions[] = 'exam_slug = %s';
					$prepare_values[]   = sanitize_title($args['exam']);
				}

				// Difficulty filter
				if (! empty($args['difficulty'])) {
					$where_conditions[] = 'difficulty = %s';
					$prepare_values[]   = sanitize_key($args['difficulty']);
				}

				// Cognitive level filter
				if (! empty($args['cognitive_level'])) {
					$where_conditions[] = 'cognitive_level = %s';
					$prepare_values[]   = sanitize_key($args['cognitive_level']);
				}

				// Exclude IDs
				if (! empty($args['exclude_ids'])) {
					$placeholders       = implode(',', array_fill(0, count($args['exclude_ids']), '%d'));
					$where_conditions[] = "post_id NOT IN ($placeholders)";
					$prepare_values     = array_merge(
						$prepare_values,
						array_map('intval', $args['exclude_ids'])
					);
				}

				// Order by
				// @MODIFIED: Expanded sorting options for display order support
				if ($args['orderby'] === 'latest') {
					$order_by = 'created_at DESC';
				} elseif ($args['orderby'] === 'oldest') {
					$order_by = 'created_at ASC';
				} else {
					$order_by = 'RAND()';
				}

				$where_clause = implode(' AND ', $where_conditions);
				$limit        = intval($args['count']);

				$sql = "SELECT * FROM {$mcq_table}
                WHERE {$where_clause}
                ORDER BY {$order_by}
                LIMIT {$limit}";

				if (! empty($prepare_values)) {
					$sql = $wpdb->prepare($sql, $prepare_values);
				}

				$results = $wpdb->get_results($sql);

				// Convert to expected format
				$mcqs = array();
				foreach ($results as $row) {
					$mcqs[] = array(
						'id'              => isset($row->post_id) ? $row->post_id : 0,
						'question'        => isset($row->question) ? $row->question : '',
						'options'         => isset($row->options) ? maybe_unserialize($row->options) : array(),
						'answer'          => isset($row->correct_answer) ? $row->correct_answer : '',
						'explanation'     => isset($row->explanation) ? $row->explanation : '',
						'difficulty'      => isset($row->difficulty) ? $row->difficulty : '',
						'cognitive_level' => isset($row->cognitive_level) ? $row->cognitive_level : '',
						'permalink'       => class_exists('NM_AJAX_Frontend') ? NM_AJAX_Frontend::get_mcq_permalink($row->post_id) : get_permalink($row->post_id),
					);
				}

				return $mcqs;
			} catch (Exception $e) {
				return self::fallback_get_mcqs($args);
			}
		}

		/**
		 * Fallback to regular WP_Query
		 */
		private static function fallback_get_mcqs($args)
		{
			try {
				$wp_args = array(
					'post_type'      => 'mcq',
					'posts_per_page' => $args['count'],
					'orderby'        => $args['orderby'] === 'random' ? 'rand' : 'date',
					'post__not_in'   => $args['exclude_ids'],
				);

				$query = new WP_Query($wp_args);
				$mcqs  = array();

				if ($query->have_posts()) {
					while ($query->have_posts()) {
						$query->the_post();
						$mcq_id = get_the_ID();

						$mcqs[] = array(
							'id'              => $mcq_id,
							'question'        => get_the_title(),
							'options'         => get_post_meta($mcq_id, 'mcq_options', true) ?: array(),
							'answer'          => get_post_meta($mcq_id, 'mcq_answer', true),
							'explanation'     => get_post_meta($mcq_id, 'mcq_explanation', true),
							'difficulty'      => get_post_meta($mcq_id, 'mcq_difficulty', true) ?: 'medium',
							'cognitive_level' => get_post_meta($mcq_id, 'mcq_cognitive_level', true) ?: '',
							'permalink'       => class_exists('NM_AJAX_Frontend') ? NM_AJAX_Frontend::get_mcq_permalink($mcq_id) : get_permalink($mcq_id),
						);
					}
					wp_reset_postdata();
				}

				return $mcqs;
			} catch (Exception $e) {
				return array();
			}
		}
	}
} // End class_exists check