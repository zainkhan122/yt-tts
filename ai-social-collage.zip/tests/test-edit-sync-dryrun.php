﻿<?php
/**
 * AI Social Collage — Publish-Sync DRY-RUN (real log data)
 *
 * Replays the FULL producer -> consumer chain with REAL Gemini JSON payloads
 * extracted from ai-collage-logs-2026-08-17-16-47-54.csv:
 *   - post 28069 (job 3121, image)   -> log row "gemini_api_response" 16:40:20
 *   - post 28065 (job 3120, video)   -> log row "gemini_api_response" 16:35:14
 *
 * Chain covered (all UP producers, all DOWN consumers):
 *   UP : QueueProcessor::step_rewrite  meta write (469-491 real shape)
 *   UP : QueueProcessor::step_render    Gutenberg block build (812-862 / 1256-1307 real shape)
 *   MID: PostObserver::sync_user_edits_to_meta (REAL method, fixed file)
 *   MID: BufferIntegration::parse_post_content_for_buffer (REAL method, fixed file)
 *   DOWN: BufferIntegration::share_to_account text-source reads (176-207) + twitter rule (307) + compile_template (REAL via reflection)
 *   DOWN: SocialBridge::build_payload (REAL via reflection)
 *   DOWN: JetpackSocial message reads (40-55 real key contract)
 *
 * Verifies the user complaint scenario honestly:
 *   S1 publish WITHOUT edits  -> meta must NOT drift from AI values
 *   S2 edit description para  -> description follows edit, X fields stable
 *   S3 edit X paragraph       -> X text must follow the edit (Buffer twitter text)
 *   S4 video post + mentions  -> mentions/hashtags/x tags intact, no errors
 *   S5 older partial meta     -> ai_x_* missing keys: no warnings/fatals (E_ALL)
 *   S6 append-tags OFF        -> ai_hashtags preserved via fallback (no drift)
 *
 * Run:  php tests/test-edit-sync-dryrun.php
 */

error_reporting( E_ALL );
ini_set( 'display_errors', '1' );
$GLOBALS['__php_errors'] = [];

set_error_handler( function ( $severity, $msg, $file, $line ) {
    $GLOBALS['__php_errors'][] = $msg . ' @ ' . basename( $file ) . ':' . $line;
    return true; // swallow; assertions count them
} );

// ───────────────────────────────────────────────────────────────────────────
//  REAL LOG DATA (Gemini JSON replies, extracted verbatim from the CSV)
// ───────────────────────────────────────────────────────────────────────────

$REAL_IMAGE = [
    'job_id'           => 3121,
    'post_id'          => 28069,
    'headline'         => "معصوم رومی اب نوجوان، نئے ڈرامے میں بدلا ہوا روپ مداحوں کی توجہ کا مرکز",
    'hook'             => "ڈرامہ سیریل ’میرے پاس تم ہو‘ میں معصوم رومی کا کردار ادا کرنے والے چائلڈ اسٹار اب نوجوان ہو چکے ہیں۔",
    'detailed_description' => "حال ہی میں وہ اپنے نئے ڈرامہ سیریل ’ہمراہی‘ کی آخری قسط کی اسکریننگ میں شریک ہوئے، جہاں ان کی نئی شخصیت اور بدلا ہوا انداز مداحوں کی توجہ کا مرکز بن گیا۔ رومی کی نئی تصاویر دیکھ کر کئی مداحوں کو ان کے پرانے معصوم چہرے اور ’میرے پاس تم ہو‘ کے دن یاد آ گئے۔",
    'hashtags'         => [ '#SheesSajjadGul', '#PakistaniDrama', '#Humraahi', '#MerePaasTumHo', '#ChildStar' ],
    'x_description'    => "چائلڈ سٹار شیز سجاد گل (رومی) اب نوجوان ہو گئے! نئے ڈرامے ’ہمراہی‘ کی اسکریننگ میں ان کے بدلے ہوئے روپ نے سب کو حیران کر دیا۔ تصاویر وائرل۔",
    'x_hashtags'       => [ '#SheesSajjadGul', '#PakistaniCelebrities' ],
    'mentions'         => [],
];

$REAL_VIDEO = [
    'job_id'           => 3120,
    'post_id'          => 28065,
    'headline'         => "جیو نیوز پر ہم جنس پرستی کے مبینہ مواد کی تشہیر کا الزام، ناظرین کی جانب سے سخت تنقید",
    'hook'             => "جیو نیوز کو مبینہ طور پر 'ہم جنس پرستی' سے متعلق مواد نشر کرنے پر پاکستانی ناظرین کی جانب سے شدید تنقید کا سامنا ہے۔",
    'detailed_description' => "پاکستان میں جیو نیوز کو مبینہ طور پر 'ہم جنس پرستی' سے متعلق مواد دکھانے پر بعض ناظرین کی جانب سے شدید تنقید کا سامنا ہے۔ اس بحث نے سوشل میڈیا پر مرکزی دھارے کے خبروں اور میڈیا پلیٹ فارمز پر پیش کیے جانے والے مواد اور ناظرین کے ردعمل کے بارے میں ایک نئی بحث چھیڑ دی ہے۔\n\nجبکہ ناظرین کو اپنے خدشات اور آراء کا اظہار کرنے کی آزادی حاصل ہے، تاہم کسی بھی نتیجے پر پہنچنے سے پہلے مواد کے اصل سیاق و سباق اور ارادے پر غور کرنا ضروری ہے۔ یہ تنقید میڈیا کے انتخاب، نمائندگی اور پاکستانی ناظرین کی توقعات کے بارے میں جاری عوامی بحث کی عکاسی کرتی ہے۔\n\nناقدین کی جانب سے اظہار کردہ آراء ان کی اپنی ہیں، اور مواد کو 'ہم جنس پرستی' سے متعلق فروغ دینے کے طور پر بیان کرنا ان کی اپنی تشریح ہے نہ کہ کوئی آزادانہ طور پر قائم شدہ حقیقت۔",
    'hashtags'         => [ '#GeoNews', '#LGBTControversy', '#MediaEthics', '#SocialDebate', '#AudienceFeedback' ],
    'x_description'    => "جیو نیوز پر 'ہم جنس پرستی' سے متعلق مواد نشر کرنے پر پاکستانی ناظرین کی جانب سے شدید تنقید، سوشل میڈیا پر نئی بحث کا آغاز۔ کیا میڈیا اداروں کو اپنے مواد پر نظرثانی کرنی چاہیے؟ مزید تفصیلات کے لیے پڑھیں۔",
    'x_hashtags'       => [ '#GeoNews', '#LGBTControversy', '#MediaEthics' ],
    'mentions'         => [ '@harpalgeotv', '@govtofpakistan', '@atta_tarar', '@gottalentpakistan' ],
];

// ───────────────────────────────────────────────────────────────────────────
//  WORDPRESS FUNCTION STUBS + IN-MEMORY STORE
// ───────────────────────────────────────────────────────────────────────────

$GLOBALS['__post_meta'] = [];
$GLOBALS['__post_tags'] = [];
$GLOBALS['__options']   = [];
$GLOBALS['__posts']     = [];

define( 'ABSPATH', __DIR__ . '/../' );

function __meta_get( $pid, $key )    { return $GLOBALS['__post_meta'][ (int) $pid ][ $key ] ?? false; }
function __meta_set( $pid, $key, $v ) { $GLOBALS['__post_meta'][ (int) $pid ][ $key ] = $v; }
function __post_up( $pid, $obj )      { $GLOBALS['__posts'][ (int) $pid ] = $obj; }

if ( ! function_exists( 'get_post_meta' ) ) {
    function get_post_meta( $post_id, $key = '', $single = false ) { return __meta_get( $post_id, $key ); }
}
if ( ! function_exists( 'update_post_meta' ) ) {
    function update_post_meta( $post_id, $meta_key, $meta_value, $prev_value = '' ) { __meta_set( $post_id, $meta_key, $meta_value ); return true; }
}
if ( ! function_exists( 'add_post_meta' ) ) {
    function add_post_meta( $post_id, $meta_key, $meta_value, $unique = false ) { __meta_set( $post_id, $meta_key, $meta_value ); return true; }
}
if ( ! function_exists( 'delete_post_meta' ) ) {
    function delete_post_meta( $post_id, $meta_key, $meta_value = '' ) { unset( $GLOBALS['__post_meta'][ (int) $post_id ][ $meta_key ] ); return true; }
}
if ( ! function_exists( 'get_post' ) ) {
    function get_post( $post_id ) { return $GLOBALS['__posts'][ (int) $post_id ] ?? null; }
}
if ( ! function_exists( 'get_post_field' ) ) {
    function get_post_field( $field, $post_id ) {
        $p = get_post( $post_id );
        if ( ! $p ) return '';
        return $p->{$field} ?? '';
    }
}
if ( ! function_exists( 'get_option' ) ) {
    function get_option( $key, $default = false ) {
        return array_key_exists( $key, $GLOBALS['__options'] ) ? $GLOBALS['__options'][ $key ] : $default;
    }
}
if ( ! function_exists( 'update_option' ) ) {
    function update_option( $key, $value, $autoload = true ) { $GLOBALS['__options'][ $key ] = $value; return true; }
}
if ( ! function_exists( 'delete_option' ) ) {
    function delete_option( $key ) { unset( $GLOBALS['__options'][ $key ] ); return true; }
}
if ( ! function_exists( 'get_transient' ) ) { function get_transient( $k ) { return false; } }
if ( ! function_exists( 'set_transient' ) ) { function set_transient() {} }
if ( ! function_exists( 'delete_transient' ) ) { function delete_transient() {} }
if ( ! function_exists( 'sanitize_text_field' ) ) { function sanitize_text_field( $s ) { return trim( (string) $s ); } }
if ( ! function_exists( 'sanitize_key' ) ) { function sanitize_key( $s ) { return $s; } }
if ( ! function_exists( 'is_wp_error' ) ) { function is_wp_error( $t ) { return $t instanceof WP_Error; } }
if ( ! function_exists( 'current_time' ) ) { function current_time( $type = 'mysql' ) { return $type === 'mysql' ? date( 'Y-m-d H:i:s' ) : time(); } }
if ( ! function_exists( 'esc_html' ) ) { function esc_html( $s ) { return htmlspecialchars( (string) $s, ENT_QUOTES, 'UTF-8' ); } }
if ( ! function_exists( 'esc_url' ) ) { function esc_url( $s ) { return $s; } }
if ( ! function_exists( 'get_permalink' ) ) { function get_permalink( $pid = 0 ) { return 'https://example.test/?p=' . (int) $pid; } }
if ( ! function_exists( 'wp_get_attachment_url' ) ) { function wp_get_attachment_url( $id = 0 ) { return 'https://example.test/wp-content/uploads/a' . (int) $id . '.jpg'; } }
if ( ! function_exists( 'get_attached_file' ) ) { function get_attached_file( $id = 0 ) { return '/tmp/a' . (int) $id . '.jpg'; } }
if ( ! function_exists( 'get_post_mime_type' ) ) { function get_post_mime_type( $id = 0 ) { return ''; } }
if ( ! function_exists( 'get_bloginfo' ) ) { function get_bloginfo( $k = '' ) { return 'DryRun Blog'; } }
if ( ! function_exists( 'get_post_thumbnail_id' ) ) { function get_post_thumbnail_id( $pid = 0 ) { return 0; } }
if ( ! function_exists( 'wp_is_post_revision' ) ) { function wp_is_post_revision( $id ) { return false; } }
if ( ! function_exists( 'wp_is_post_autosave' ) ) { function wp_is_post_autosave( $id ) { return false; } }
if ( ! function_exists( 'add_action' ) ) { function add_action() {} }
if ( ! function_exists( 'add_filter' ) ) { function add_filter() {} }
if ( ! function_exists( 'do_action' ) ) { function do_action() {} }
if ( ! function_exists( 'wp_trim_words' ) ) {
    function wp_trim_words( $text, $num_words = 55, $more = null ) {
        $text = wp_strip_all_tags( $text );
        $words_array = preg_split( "/[\n\r\t ]+/", trim( $text ), -1, PREG_SPLIT_NO_EMPTY );
        if ( count( $words_array ) <= $num_words ) { return implode( ' ', $words_array ); }
        // Faithful to WP core: default $more is the literal entity '&hellip;'.
        $more = null === $more ? '&hellip;' : $more;
        return implode( ' ', array_slice( $words_array, 0, $num_words ) ) . ( $more === '' ? '' : ' ' . $more );
    }
}
if ( ! function_exists( 'wp_strip_all_tags' ) ) { function wp_strip_all_tags( $t ) { return strip_tags( (string) $t ); } }
if ( ! function_exists( 'wp_kses_post' ) ) { function wp_kses_post( $html ) { return $html; } }
if ( ! function_exists( 'wp_set_post_tags' ) ) {
    function wp_set_post_tags( $post_id, $tags, $append = false ) {
        $existing = $GLOBALS['__post_tags'][ (int) $post_id ] ?? [];
        $incoming = is_array( $tags ) ? $tags : array_map( 'trim', explode( ',', (string) $tags ) );
        $GLOBALS['__post_tags'][ (int) $post_id ] = $append
            ? array_values( array_unique( array_merge( $existing, $incoming ) ) )
            : array_values( array_unique( $incoming ) );
        return true;
    }
}
if ( ! function_exists( 'has_blocks' ) ) {
    function has_blocks( $content ) { return strpos( (string) $content, '<!-- wp:' ) !== false; }
}
if ( ! function_exists( 'parse_blocks' ) ) {
    function parse_blocks( $content ) {
        $blocks = [];
        if ( preg_match_all( '/<!--\s+wp:([a-z0-9\/-]+)\s*(\{[^}]*\})?\s*-->(.*?)<!--\s+\/wp:\1\s*-->/s', $content, $m, PREG_SET_ORDER ) ) {
            foreach ( $m as $mm ) {
                $inner = $mm[3];
                $blocks[] = [
                    'blockName'    => 'core/' . $mm[1],
                    'attrs'        => $mm[2] !== '' ? json_decode( $mm[2], true ) : [],
                    'innerHTML'    => $inner,
                    'innerContent' => [ $inner ],
                ];
            }
        }
        if ( preg_match_all( '/<!--\s+wp:([a-z0-9\/-]+)\s*(\{[^}]*\})?\s*\/-->/s', $content, $m2, PREG_SET_ORDER ) ) {
            foreach ( $m2 as $mm2 ) {
                $blocks[] = [ 'blockName' => 'core/' . $mm2[1], 'attrs' => [], 'innerHTML' => '', 'innerContent' => [ '' ] ];
            }
        }
        return $blocks;
    }
}

$GLOBALS['wpdb'] = new class {
    public $prefix = 'wp_';
    public function get_var( $q ) { return null; }
    public function insert( $t, $d, $f = [] ) { return true; }
    public function update( $t, $d, $w, $f = [], $fw = [] ) { return true; }
    public function prepare( $q, ...$a ) { return $q; }
    public function query( $q ) { return 0; }
    public function get_row( $q ) { return null; }
    public function get_results( $q ) { return []; }
    public function esc_like( $s ) { return $s; }
};

class WP_Error {
    private $code, $msg;
    public function __construct( $code = '', $msg = '' ) { $this->code = $code; $this->msg = $msg; }
    public function get_error_message() { return $this->msg; }
}

// ───────────────────────────────────────────────────────────────────────────
//  LOAD PLUGIN CLASSES (REAL FIXED CODE — never stubbed)
// ───────────────────────────────────────────────────────────────────────────

$base = __DIR__ . '/../core/';
require_once $base . 'Config.php';
require_once $base . 'Logger.php';
require_once $base . 'Services/BufferIntegration.php';
require_once $base . 'Services/SocialBridge.php';
require_once $base . 'Actions/PostObserver.php';

use AiSocialCollage\Config;
use AiSocialCollage\Services\BufferIntegration;

function reflect_call( string $class, string $method, array $args, $obj = null ) {
    $ref = new \ReflectionMethod( $class, $method );
    $ref->setAccessible( true );
    return $ref->invokeArgs( $obj, $args );
}

// ───────────────────────────────────────────────────────────────────────────
//  PRODUCER REPLAY — exact QueueProcessor code shape with REAL data
// ───────────────────────────────────────────────────────────────────────────

function producer_write_meta( int $post_id, array $ai ): array {
    // QueueProcessor.php:469-491 (real shape)
    $ai_meta = [
        'suggested_template'       => 'news-card',
        'suggested_category'       => 'news',
        'ai_language'              => 'ur',
        'ai_hashtags'              => $ai['hashtags'] ?? [],
        'ai_headline'              => $ai['headline'] ?? '',
        'ai_hook'                  => $ai['hook'] ?? '',
        'ai_detailed_description'  => $ai['detailed_description'] ?? '',
        'ai_x_hashtags'            => $ai['x_hashtags'] ?? [],
        'ai_x_description'         => $ai['x_description'] ?? '',
        'ai_mentions'              => $ai['mentions'] ?? [],
    ];
    if ( ! empty( $ai['x_description'] ) ) {
        $x_hashtags = $ai['x_hashtags'] ?? $ai['hashtags'] ?? [];
        $x_text = trim( $ai['x_description'] );
        if ( ! empty( $x_hashtags ) ) {
            $x_text .= "\n" . implode( ' ', array_slice( $x_hashtags, 0, 5 ) );
        }
        $ai_meta['x_content'] = $x_text;
    }
    update_post_meta( $post_id, Config::META_AUTO_META, $ai_meta );

    $tag_names = array_map( function ( $t ) { return ltrim( $t, '#' ); }, $ai['hashtags'] ?? [] );
    wp_set_post_tags( $post_id, array_slice( array_unique( $tag_names ), 0, 10 ), true );
    return $ai_meta;
}

function producer_build_blocks( int $post_id, string $headline, string $description, int $attachment_id, bool $is_video ): string {
    // QueueProcessor.php:812-862 (image) / 1256-1307 (video) — exact real shape.
    $blocks = [];
    if ( $attachment_id > 0 ) {
        $url = wp_get_attachment_url( $attachment_id );
        if ( $is_video ) {
            $blocks[] = '<!-- wp:video {"src":"' . esc_url( $url ) . '"} --><figure class="wp-block-video"><video controls src="' . esc_url( $url ) . '"></video></figure><!-- /wp:video -->';
        } else {
            $blocks[] = '<!-- wp:image {"id":' . $attachment_id . ',"sizeSlug":"full","linkDestination":"none"} --><figure class="wp-block-image size-full"><img src="' . esc_url( $url ) . '" alt="" /></figure><!-- /wp:image -->';
        }
    }
    $blocks[] = '<!-- wp:heading {"level":2} --><h2 class="wp-block-heading">' . esc_html( $headline ) . '</h2><!-- /wp:heading -->';
    $desc = wp_strip_all_tags( $description );
    $blocks[] = '<!-- wp:paragraph --><p>' . $desc . '</p><!-- /wp:paragraph -->';

    $auto_meta = get_post_meta( $post_id, Config::META_AUTO_META, true );
    $auto_meta = is_array( $auto_meta ) ? $auto_meta : [];

    if ( (bool) get_option( Config::OPTION_APPEND_TAGS_TO_POST, false ) ) {
        $ai_hashtags = $auto_meta['ai_hashtags'] ?? [];
        if ( is_array( $ai_hashtags ) && ! empty( $ai_hashtags ) ) {
            $tag_strings = array_map( function ( $tag ) {
                return '#' . preg_replace( '/[^\p{L}\p{N}]/u', '', ltrim( $tag, '#' ) );
            }, array_slice( $ai_hashtags, 0, 10 ) );
            $blocks[] = '<!-- wp:paragraph --><p>' . implode( ' ', $tag_strings ) . '</p><!-- /wp:paragraph -->';
        }
    }
    if ( ! empty( $auto_meta['x_content'] ) ) {
        $blocks[] = '<!-- wp:paragraph --><p>' . esc_html( $auto_meta['x_content'] ) . '</p><!-- /wp:paragraph -->';
    }
    $ai_mentions = $auto_meta['ai_mentions'] ?? [];
    if ( is_array( $ai_mentions ) && ! empty( $ai_mentions ) ) {
        $blocks[] = '<!-- wp:paragraph --><p>' . implode( ' ', array_slice( $ai_mentions, 0, 10 ) ) . '</p><!-- /wp:paragraph -->';
    }
    return implode( "\n\n", $blocks );
}

function produce_post( int $post_id, array $ai, int $attachment_id, bool $is_video ): string {
    producer_write_meta( $post_id, $ai );
    $content = producer_build_blocks( $post_id, $ai['headline'], $ai['detailed_description'], $attachment_id, $is_video );
    $post = new stdClass();
    $post->ID = $post_id;
    $post->post_type = 'post';
    $post->post_status = 'publish';
    $post->post_title = $ai['headline'];
    $post->post_content = $content;
    __post_up( $post_id, $post );
    return $content;
}

// ───────────────────────────────────────────────────────────────────────────
//  MIDDLE — real modified methods
// ───────────────────────────────────────────────────────────────────────────

function run_publish_sync( int $post_id ) {
    // Exact sequence of PostObserver::on_publish_transition (Fix 2) before share:
    $observer = new \AiSocialCollage\Actions\PostObserver();
    $post = get_post( $post_id );
    $observer->sync_user_edits_to_meta( $post_id, $post, true );
    return get_post_meta( $post_id, Config::META_AUTO_META, true );
}

// ───────────────────────────────────────────────────────────────────────────
//  DOWNSTREAM — real consumer text-resolution (BufferIntegration.php:176-207,
//  twitter rule :307) + REAL compile_template
// ───────────────────────────────────────────────────────────────────────────

function buffer_share_texts( int $post_id ): array {
    $auto_meta = get_post_meta( $post_id, Config::META_AUTO_META, true );
    $auto_meta = is_array( $auto_meta ) ? $auto_meta : [];

    $headline = $auto_meta['ai_headline'] ?? '';
    if ( empty( $headline ) ) { $headline = get_post_field( 'post_title', $post_id ); }

    $description = $auto_meta['ai_detailed_description'] ?? $auto_meta['ai_hook'] ?? '';
    if ( empty( $description ) ) { $description = wp_trim_words( wp_strip_all_tags( get_post_field( 'post_content', $post_id ) ), 30 ); }

    $x_content = $auto_meta['x_content'] ?? '';
    $x_hashtags = '';
    if ( ! empty( $auto_meta['ai_x_hashtags'] ) && is_array( $auto_meta['ai_x_hashtags'] ) ) {
        $x_hashtags = implode( ' ', array_slice( $auto_meta['ai_x_hashtags'], 0, 5 ) );
    }
    $x_description = $auto_meta['ai_x_description'] ?? '';
    $mentions = '';
    if ( ! empty( $auto_meta['ai_mentions'] ) && is_array( $auto_meta['ai_mentions'] ) ) {
        $mentions = implode( ' ', array_slice( $auto_meta['ai_mentions'], 0, 10 ) );
    }

    // BufferIntegration.php:307 — twitter channel body = x_content
    $twitter_body = ( ! empty( $x_content ) ) ? $x_content : $description;

    // REAL consumer: BufferIntegration::get_hashtags (SSOT for {hashtags})
    $default_hashtags = reflect_call( BufferIntegration::class, 'get_hashtags', [ $post_id ] );

    // REAL compile_template with the placeholders actually shipped to Buffer
    $twitter_text = reflect_call( BufferIntegration::class, 'compile_template', [ "{headline}\n\n{description}\n\n{hashtags}", $headline, $twitter_body, $default_hashtags, '', $x_hashtags, $x_description, $mentions ] );
    $instagram_text = reflect_call( BufferIntegration::class, 'compile_template', [ "{headline}\n\n{description}\n\n{hashtags}", $headline, $description, $default_hashtags, '', $x_hashtags, $x_description, $mentions ] );

    return [
        'headline'       => $headline,
        'description'    => $description,
        'x_content'      => $x_content,
        'x_hashtags'     => $x_hashtags,
        'x_description'  => $x_description,
        'mentions'       => $mentions,
        'hashtags'       => $default_hashtags,
        'twitter_body'   => $twitter_body,
        'twitter_text'   => $twitter_text,
        'instagram_text' => $instagram_text,
    ];
}

// ───────────────────────────────────────────────────────────────────────────
//  ASSERT HELPERS + NORMALIZATION
// ───────────────────────────────────────────────────────────────────────────

$GLOBALS['__passed'] = 0;
$GLOBALS['__failed'] = 0;
$GLOBALS['__failMsg'] = [];

function norm( $s ): string {
    $s = str_replace( "\xE2\x80\x8E", '', (string) $s ); // LRM
    return trim( preg_replace( '/\s+/u', ' ', $s ) );
}
function norm_deep( $v ) {
    if ( is_array( $v ) ) {
        $out = [];
        foreach ( $v as $k => $item ) { $out[ $k ] = norm_deep( $item ); }
        return $out;
    }
    return norm( $v );
}
function assert_deep_equal_norm( string $name, $actual, $expected, string $detail = '' ) {
    assert_true( $name, norm_deep( $actual ) == norm_deep( $expected ), $detail . ' expected=' . var_export( norm_deep( $expected ), true ) . ' actual=' . var_export( norm_deep( $actual ), true ) );
}
function assert_true( string $name, $condition, string $detail = '' ) {
    if ( $condition ) { $GLOBALS['__passed']++; echo "  PASS  {$name}\n"; }
    else { $GLOBALS['__failed']++; $m = "  FAIL  {$name}" . ( $detail ? " — {$detail}" : '' ); $GLOBALS['__failMsg'][] = $m; echo "{$m}\n"; }
}
function assert_same( string $name, $actual, $expected, string $detail = '' ) {
    $ok = ( is_array( $expected ) && is_array( $actual ) ) ? ( $actual == $expected ) : ( $actual === $expected );
    assert_true( $name, $ok, $detail . ' expected=' . var_export( $expected, true ) . ' actual=' . var_export( $actual, true ) );
}
function assert_no_php_errors( string $name ) {
    $errs = $GLOBALS['__php_errors'];
    $GLOBALS['__php_errors'] = [];
    assert_true( $name, empty( $errs ), 'PHP warnings/notices: ' . implode( ' || ', $errs ) );
}

echo "\n==============================================================\n";
echo "  REAL DATA: posts 28069 (image) + 28065 (video) from logs\n";
echo "==============================================================\n\n";

// ───────────────────────────────────────────────────────────────────────────
//  S1 — image post 28069, publish WITHOUT edits (append-tags ON)
//  Must be a NO-OP: meta must stay byte-equal to the AI values.
// ───────────────────────────────────────────────────────────────────────────

echo "--- S1: no-edit publish (append-tags ON) ---\n";
$GLOBALS['__options'][ Config::OPTION_APPEND_TAGS_TO_POST ] = true;
$p1 = 28069;
produce_post( $p1, $REAL_IMAGE, 28078, false );
$before1 = get_post_meta( $p1, Config::META_AUTO_META, true );
$meta1 = run_publish_sync( $p1 );
$t1 = buffer_share_texts( $p1 );

assert_same( 'S1 ai_headline unchanged', $meta1['ai_headline'], $REAL_IMAGE['headline'] );
assert_same( 'S1 ai_detailed_description unchanged', norm( $meta1['ai_detailed_description'] ), norm( $REAL_IMAGE['detailed_description'] ) );
assert_same( 'S1 ai_hashtags unchanged (5 real tags)', $meta1['ai_hashtags'], $REAL_IMAGE['hashtags'], 'got=' . implode( ' ', $meta1['ai_hashtags'] ?? [] ) );
assert_same( 'S1 ai_x_hashtags unchanged (AI x tags)', $meta1['ai_x_hashtags'], $REAL_IMAGE['x_hashtags'] );
assert_same( 'S1 ai_x_description unchanged (AI x text)', norm( $meta1['ai_x_description'] ), norm( $REAL_IMAGE['x_description'] ) );
assert_same( 'S1 mentions unchanged', $meta1['ai_mentions'], [] );
assert_deep_equal_norm( 'S1 meta no drift (whitespace-normalized)', $meta1, $before1 );
assert_true( 'S1 twitter body == AI x_content', norm( $t1['twitter_body'] ) === norm( $REAL_IMAGE['x_description'] . ' ' . implode( ' ', $REAL_IMAGE['x_hashtags'] ) ), 'body=' . norm( $t1['twitter_body'] ) );
assert_no_php_errors( 'S1 no PHP warnings/notices' );
unset( $GLOBALS['__options'][ Config::OPTION_APPEND_TAGS_TO_POST ] );

// ───────────────────────────────────────────────────────────────────────────
//  S2 — user edits the DESCRIPTION paragraph, publishes.
//  Description must follow the edit; headline + X fields must stay stable.
// ───────────────────────────────────────────────────────────────────────────

echo "\n--- S2: edit description paragraph ---\n";
$GLOBALS['__options'][ Config::OPTION_APPEND_TAGS_TO_POST ] = true;
produce_post( $p1, $REAL_IMAGE, 28078, false );
$post = get_post( $p1 );
$EDITED_DESC = "رومی اپنے نئے ڈرامے میں بدلا ہوا روپ مداحوں کی توجہ کا مرکز بن گئے، اور پرانی تصاویر وائرل ہو گئیں۔";
$needle2 = '<!-- wp:paragraph --><p>' . wp_strip_all_tags( $REAL_IMAGE['detailed_description'] ) . '</p><!-- /wp:paragraph -->';
if ( strpos( $post->post_content, $needle2 ) === false ) {
    assert_true( 'S2 target description block found', false, 'needle not present in content' );
}
$post->post_content = str_replace( $needle2, '<!-- wp:paragraph --><p>' . $EDITED_DESC . '</p><!-- /wp:paragraph -->', $post->post_content );
__post_up( $p1, $post );
$meta2 = run_publish_sync( $p1 );
$t2 = buffer_share_texts( $p1 );

assert_true( 'S2 ai_detailed_description = edited text', norm( $meta2['ai_detailed_description'] ) === norm( $EDITED_DESC ), 'got=' . norm( $meta2['ai_detailed_description'] ) );
assert_same( 'S2 ai_headline unchanged', $meta2['ai_headline'], $REAL_IMAGE['headline'] );
assert_same( 'S2 x_hashtags stable (AI x tags)', $meta2['ai_x_hashtags'], $REAL_IMAGE['x_hashtags'], 'got=' . implode( ' ', $meta2['ai_x_hashtags'] ?? [] ) );
assert_tagg_enabled_description_s2: if ( true ) {
    assert_true( 'S2 instagram body contains edited desc', stripos( $t2['instagram_text'], $EDITED_DESC[0] ) !== false );
}
assert_no_php_errors( 'S2 no PHP warnings/notices' );
unset( $GLOBALS['__options'][ Config::OPTION_APPEND_TAGS_TO_POST ] );

// ───────────────────────────────────────────────────────────────────────────
//  S3 — user edits the X paragraph (twitter text), publishes.
//  Buffer twitter body MUST contain the user's edited X text.
// ───────────────────────────────────────────────────────────────────────────

echo "\n--- S3: edit X paragraph ---\n";
$GLOBALS['__options'][ Config::OPTION_APPEND_TAGS_TO_POST ] = true;
produce_post( $p1, $REAL_IMAGE, 28078, false );
$post = get_post( $p1 );
$EDITED_X = "رومی کی نئی تصویروں نے سب کو حیران کر دیا! #SheesSajjadGul #NewLook";
$meta_for_needle = get_post_meta( $p1, Config::META_AUTO_META, true );
$needle3 = '<!-- wp:paragraph --><p>' . esc_html( $meta_for_needle['x_content'] ) . '</p><!-- /wp:paragraph -->';
if ( strpos( $post->post_content, $needle3 ) === false ) {
    assert_true( 'S3 target X block found', false, 'x_content needle not present in content' );
}
$post->post_content = str_replace( $needle3, '<!-- wp:paragraph --><p>' . esc_html( $EDITED_X ) . '</p><!-- /wp:paragraph -->', $post->post_content );
__post_up( $p1, $post );
$meta3 = run_publish_sync( $p1 );
$t3 = buffer_share_texts( $p1 );

assert_true( 'S3 ai_x_description = edited X text (tags stripped)', norm( $meta3['ai_x_description'] ) === norm( "رومی کی نئی تصویروں نے سب کو حیران کر دیا!" ), 'got=' . norm( $meta3['ai_x_description'] ?? '' ) );
assert_same( 'S3 ai_x_hashtags = edited X tags', array_values( $meta3['ai_x_hashtags'] ?? [] ), [ '#SheesSajjadGul', '#NewLook' ], 'got=' . implode( ' ', $meta3['ai_x_hashtags'] ?? [] ) );
assert_true( 'S3 Buffer twitter body contains edited X text', strpos( $t3['twitter_body'], 'نئی تصویروں نے سب کو حیران' ) !== false, 'body=' . norm( $t3['twitter_body'] ) );
assert_true( 'S3 Buffer twitter body has edited hashtags', strpos( $t3['twitter_body'], '#NewLook' ) !== false, 'body=' . norm( $t3['twitter_body'] ) );
assert_true( 'S3 description unchanged after X-only edit', norm( $meta3['ai_detailed_description'] ) === norm( $REAL_IMAGE['detailed_description'] ), 'got=' . norm( $meta3['ai_detailed_description'] ?? '' ) );
assert_no_php_errors( 'S3 no PHP warnings/notices' );
unset( $GLOBALS['__options'][ Config::OPTION_APPEND_TAGS_TO_POST ] );

// ───────────────────────────────────────────────────────────────────────────
//  S4 — video post 28065 (multi-paragraph, mentions), no edits.
// ───────────────────────────────────────────────────────────────────────────

echo "\n--- S4: video post no-edit (append-tags ON) ---\n";
$GLOBALS['__options'][ Config::OPTION_APPEND_TAGS_TO_POST ] = true;
$p4 = 28065;
produce_post( $p4, $REAL_VIDEO, 28071, true );
$before4 = get_post_meta( $p4, Config::META_AUTO_META, true );
$meta4 = run_publish_sync( $p4 );
$t4 = buffer_share_texts( $p4 );

assert_same( 'S4 ai_hashtags unchanged (5)', $meta4['ai_hashtags'], $REAL_VIDEO['hashtags'] );
assert_same( 'S4 ai_x_hashtags unchanged (3)', $meta4['ai_x_hashtags'], $REAL_VIDEO['x_hashtags'] );
assert_same( 'S4 ai_x_description unchanged', norm( $meta4['ai_x_description'] ), norm( $REAL_VIDEO['x_description'] ) );
assert_same( 'S4 mentions unchanged (4 handles)', array_values( $meta4['ai_mentions'] ), [ '@harpalgeotv', '@govtofpakistan', '@atta_tarar', '@gottalentpakistan' ], 'got=' . implode( ' ', $meta4['ai_mentions'] ?? [] ) );
assert_same( 'S4 ai_detailed_description unchanged', norm( $meta4['ai_detailed_description'] ), norm( $REAL_VIDEO['detailed_description'] ) );
assert_deep_equal_norm( 'S4 meta no drift (whitespace-normalized)', $meta4, $before4 );
assert_true( 'S4 mentions reach Buffer payload', strpos( $t4['mentions'], '@harpalgeotv' ) !== false );
assert_no_php_errors( 'S4 no PHP warnings/notices' );
unset( $GLOBALS['__options'][ Config::OPTION_APPEND_TAGS_TO_POST ] );

// ───────────────────────────────────────────────────────────────────────────
//  S5 — older posts with PARTIAL meta (ai_x_* keys absent) — must not fatal
// ───────────────────────────────────────────────────────────────────────────

echo "\n--- S5: partial legacy meta (ai_x_* missing) ---\n";
$p5 = 28033;
$auto5 = [
    'ai_headline'             => $REAL_VIDEO['headline'],
    'ai_hook'                 => $REAL_VIDEO['hook'],
    'ai_detailed_description' => $REAL_VIDEO['detailed_description'],
    'ai_hashtags'             => $REAL_VIDEO['hashtags'],
    'ai_mentions'             => [],
];
update_post_meta( $p5, Config::META_AUTO_META, $auto5 );
$post5 = new stdClass();
$post5->ID = $p5;
$post5->post_type = 'post';
$post5->post_status = 'publish';
$post5->post_title = $REAL_VIDEO['headline'];
$post5->post_content = '<!-- wp:heading {"level":2} --><h2 class="wp-block-heading">' . $REAL_VIDEO['headline'] . '</h2><!-- /wp:heading -->' . "\n\n" . '<!-- wp:paragraph --><p>' . wp_strip_all_tags( $REAL_VIDEO['detailed_description'] ) . '</p><!-- /wp:paragraph -->';
__post_up( $p5, $post5 );
$meta5 = run_publish_sync( $p5 );
assert_same( 'S5 ai_x_hashtags created as [] (no fatal)', $meta5['ai_x_hashtags'] ?? 'MISSING', [] );
assert_same( 'S5 ai_x_description preserved as empty string', $meta5['ai_x_description'] ?? 'MISSING', '' );
assert_true( 'S5 legacy ai_hashtags preserved', $meta5['ai_hashtags'] == $REAL_VIDEO['hashtags'] );
assert_same( 'S5 legacy x_content empty, no mismatch', $meta5['x_content'] ?? 'MISSING', '' );
assert_no_php_errors( 'S5 no PHP warnings/notices' );

// ───────────────────────────────────────────────────────────────────────────
//  S6 — append-tags OFF (no hashtag paragraph in content):
//  content has no general-tags block; meta must preserve AI values
// ───────────────────────────────────────────────────────────────────────────

echo "\n--- S6: no-edit publish (append-tags OFF) ---\n";
$p6 = 28061;
produce_post( $p6, $REAL_IMAGE, 28063, false );
unset( $GLOBALS['__options'][ Config::OPTION_APPEND_TAGS_TO_POST ] );
$before6 = get_post_meta( $p6, Config::META_AUTO_META, true );
$meta6 = run_publish_sync( $p6 );
$t6 = buffer_share_texts( $p6 );

assert_same( 'S6 ai_hashtags preserved (5 AI tags)', $meta6['ai_hashtags'], $REAL_IMAGE['hashtags'], 'got=' . implode( ' ', $meta6['ai_hashtags'] ?? [] ) );
assert_same( 'S6 ai_x_hashtags preserved (2 AI x tags)', $meta6['ai_x_hashtags'], $REAL_IMAGE['x_hashtags'] );
assert_same( 'S6 ai_x_description preserved', norm( $meta6['ai_x_description'] ), norm( $REAL_IMAGE['x_description'] ) );
assert_deep_equal_norm( 'S6 meta no drift (whitespace-normalized)', $meta6, $before6 );
assert_true( 'S6 instagram text keeps the 5 AI hashtags', strpos( $t6['instagram_text'], '#ChildStar' ) !== false, 'text=' . norm( $t6['instagram_text'] ) );
assert_no_php_errors( 'S6 no PHP warnings/notices' );

// ───────────────────────────────────────────────────────────────────────────
//  S7 — post 28090 / job 3125 (Deosai bears, REAL production payload from
//  ai-collage-logs-2026-08-17-18-30-59.csv, render_success row). User EDITED
//  the description (cut the AI-disclosure sentence). On the live site this
//  produced a Buffer caption ending in literal '&hellip;' — wp_trim_words()
//  with the default $more appends the entity when it truncates at 80 words.
//  Regression: meta/caption must carry the FULL edited text, no '&hellip;'.
// ───────────────────────────────────────────────────────────────────────────

echo "\n--- S7: post 28090 edited >80-word desc (regression: no literal &hellip;) ---\n";
$p7 = 28090;
$HEADLINE_S7 = 'گلگت بلتستان: دیوسائی نیشنل پارک میں نایاب ہمالین براؤن بیئرز کی جوڑی ایک ساتھ دیکھی گئی';
$AI_DESC_S7 = 'پاکستان میں ہمالین براؤن بیئر کو قانوناً انتہائی تحفظ یافتہ جنگلی حیات کا درجہ حاصل ہے۔ جب 1993 میں دیوسائی نیشنل پارک قائم کیا گیا تھا، تو اس وقت یہاں ان ریچھوں کی نسل شدید خطرے سے دوچار تھی اور ان کی کل تعداد محض 15 کے قریب تھی۔ تاہم، طویل مدتی حفاظتی اقدامات اور انتھک کوششوں کے نتیجے میں 2023 کی جنگلی حیات کی مردم شماری کے مطابق پارک میں ریچھوں کی تعداد بڑھ کر 76 ریکارڈ کی گئی۔ سال 2024 سے 2026 کے دوران پیدا ہونے والے نئے بچوں کے بعد اب یہ تعداد 80 سے تجاوز کر چکی ہے۔ واضح رہے کہ خبر کے ساتھ دی گئی تصویر مصنوعی ذہانت (AI) کی مدد سے تیار کی گئی ہے جو صرف علامتی طور پر استعمال کی جا رہی ہے۔';
// User's actual edit: deleted the AI-disclosure sentence (live post content ends
// right after "...80 سے تجاوز کر چکی ہے۔"). ~97 words — over the old 80-word budget.
$EDITED_DESC_S7 = 'پاکستان میں ہمالین براؤن بیئر کو قانوناً انتہائی تحفظ یافتہ جنگلی حیات کا درجہ حاصل ہے۔ جب 1993 میں دیوسائی نیشنل پارک قائم کیا گیا تھا، تو اس وقت یہاں ان ریچھوں کی نسل شدید خطرے سے دوچار تھی اور ان کی کل تعداد محض 15 کے قریب تھی۔ تاہم، طویل مدتی حفاظتی اقدامات اور انتھک کوششوں کے نتیجے میں 2023 کی جنگلی حیات کی مردم شماری کے مطابق پارک میں ریچھوں کی تعداد بڑھ کر 76 ریکارڈ کی گئی۔ سال 2024 سے 2026 کے دوران پیدا ہونے والے نئے بچوں کے بعد اب یہ تعداد 80 سے تجاوز کر چکی ہے۔';
$TAGS_S7 = [ '#HimalayanBrownBear', '#DeosaiNationalPark', '#WildlifeConservation', '#GilgitBaltistan', '#SaveTheBears' ];
// X paragraph per the user's report of the live post layout (text + hashtags).
$X_TEXT_S7 = 'دیوسائی نیشنل پارک میں براؤن بیئرز کی جوڑی ایک ساتھ دیکھنے کو ملی، یہ نایاب منظر سوشل میڈیا پر وائرل ہو گیا';
$X_TAGS_S7 = [ '#HimalayanBrownBear', '#WildlifeConservation' ];

$ai7 = [
    'headline'             => $HEADLINE_S7,
    'hook'                 => $AI_DESC_S7,
    'detailed_description' => $AI_DESC_S7,
    'hashtags'             => $TAGS_S7,
    'x_description'        => $X_TEXT_S7,
    'x_hashtags'           => $X_TAGS_S7,
    'mentions'             => [],
];
$GLOBALS['__options'][ Config::OPTION_APPEND_TAGS_TO_POST ] = true;
produce_post( $p7, $ai7, 28102, false );

// Negative control: the faithful wp_trim_words stub MUST reproduce the original
// production bug (80-word truncation appends the literal entity '&hellip;').
assert_true( 'S7 stub reproduces wp_trim_words entity bug', strpos( wp_trim_words( $EDITED_DESC_S7, 80 ), '&hellip;' ) !== false, 'stub no longer models WP core default $more' );

$post7 = get_post( $p7 );
$needle7 = '<!-- wp:paragraph --><p>' . wp_strip_all_tags( $AI_DESC_S7 ) . '</p><!-- /wp:paragraph -->';
if ( strpos( $post7->post_content, $needle7 ) === false ) {
    assert_true( 'S7 target description block found', false, 'needle not present in content' );
}
$post7->post_content = str_replace( $needle7, '<!-- wp:paragraph --><p>' . $EDITED_DESC_S7 . '</p><!-- /wp:paragraph -->', $post7->post_content );
__post_up( $p7, $post7 );
$meta7 = run_publish_sync( $p7 );
$t7 = buffer_share_texts( $p7 );

assert_true( 'S7 description = FULL edited text (no truncation)', norm( $meta7['ai_detailed_description'] ) === norm( $EDITED_DESC_S7 ), 'got=' . norm( $meta7['ai_detailed_description'] ) );
assert_true( 'S7 description ends with the real last sentence', strpos( $meta7['ai_detailed_description'], 'تجاوز کر چکی ہے۔' ) !== false );
assert_true( 'S7 meta contains NO literal &hellip; entity', strpos( (string) $meta7['ai_detailed_description'], '&hellip;' ) === false );
assert_true( 'S7 caption contains NO literal &hellip; entity', strpos( $t7['instagram_text'], '&hellip;' ) === false && strpos( $t7['twitter_text'], '&hellip;' ) === false, 'caption=' . norm( $t7['instagram_text'] ) );
assert_true( 'S7 caption keeps the tail sentence', strpos( $t7['instagram_text'], 'تجاوز کر چکی ہے۔' ) !== false, 'caption=' . norm( $t7['instagram_text'] ) );
assert_same( 'S7 ai_headline unchanged', $meta7['ai_headline'], $HEADLINE_S7 );
assert_same( 'S7 ai_hashtags = 5 real post tags', $meta7['ai_hashtags'], $TAGS_S7, 'got=' . implode( ' ', $meta7['ai_hashtags'] ?? [] ) );
assert_same( 'S7 ai_x_hashtags = X paragraph tags', $meta7['ai_x_hashtags'], $X_TAGS_S7, 'got=' . implode( ' ', $meta7['ai_x_hashtags'] ?? [] ) );
assert_true( 'S7 ai_x_description = X text (no truncation)', norm( $meta7['ai_x_description'] ) === norm( $X_TEXT_S7 ), 'got=' . norm( $meta7['ai_x_description'] ) );
assert_true( 'S7 instagram caption contains headline', strpos( $t7['instagram_text'], 'دیوسائی نیشنل پارک میں نایاب' ) !== false );
assert_no_php_errors( 'S7 no PHP warnings/notices' );
unset( $GLOBALS['__options'][ Config::OPTION_APPEND_TAGS_TO_POST ] );

// ───────────────────────────────────────────────────────────────────────────
//  SUMMARY
// ───────────────────────────────────────────────────────────────────────────

echo "\n==============================================================\n";
echo "  RESULTS: {$GLOBALS['__passed']} passed, {$GLOBALS['__failed']} failed\n";
echo "==============================================================\n";
if ( $GLOBALS['__failed'] > 0 ) {
    echo "\n  FAILURES:\n";
    foreach ( $GLOBALS['__failMsg'] as $f ) { echo "  {$f}\n"; }
    echo "\n";
    exit( 1 );
}
echo "\n  ALL DRY-RUN SCENARIOS PASSED (no drift, no edit loss, no PHP errors)\n\n";
exit( 0 );
