<?php
/**
 * Uninstall Script for MCQ Video Studio
 *
 * Called directly by WordPress when the plugin is deleted via the Plugins page.
 * Also serves as the uninstall.php entry point (WordPress checks both).
 *
 * @package MCQ_Video_Studio
 */

if (!defined('ABSPATH')) {
    exit;
}

// Load WordPress utilities needed for cleanup.
require_once ABSPATH . 'wp-admin/includes/upgrade.php';
require_once ABSPATH . 'wp-admin/includes/file.php';

/**
 * Clean up all plugin state on uninstall.
 *
 * Mirrors the logic in mcqvs_uninstall_plugin() in mcq-video-studio.php
 * to allow direct execution of this file without loading the full plugin
 * (avoids partial-load fatal errors that would abort deletion).
 */
function mcqvs_uninstall_plugin_direct()
{
    global $wpdb;

    // @FIX 2026-08-12 (data-loss): NEVER destroy user data on uninstall by default.
    // Deleting the plugin folder (part of the ZIP-update flow) used to wipe the
    // Content Planner, batch tracker, generated-Qs table (vs_mcq_bank), jobs/projects,
    // the Artifact Cleanup retention settings, API keys and the uploads tree. Preserve
    // all data unless the site admin opts in with:
    //   define('MCQVS_PURGE_DATA_ON_UNINSTALL', true);   // wp-config.php
    //   OR Settings > Data > "Delete all plugin data on uninstall" (default: KEEP).
    $purge = (defined('MCQVS_PURGE_DATA_ON_UNINSTALL') && MCQVS_PURGE_DATA_ON_UNINSTALL);
    if (!$purge && function_exists('get_option')) {
        $purge = (bool) get_option('mcqvs_purge_data_on_uninstall', false);
    }

    if (function_exists('as_unschedule_all_actions')) {
        as_unschedule_all_actions('vs_process_bulk_schedule');
        as_unschedule_all_actions('mcqvs_process_topic_batch');
        as_unschedule_all_actions('vs_generate_mcq_batch');
        as_unschedule_all_actions('vs_headless_render_cron');
        as_unschedule_all_actions('vs_publish_scheduled_cron');
        as_unschedule_all_actions('mcqvs_render_claim');
        as_unschedule_all_actions('mcqvs_kill_orphan_render');
    }

    wp_clear_scheduled_hook('vs_daily_schedule_event');
    wp_clear_scheduled_hook('vs_headless_render_cron');
    wp_clear_scheduled_hook('vs_publish_scheduled_cron');
    wp_clear_scheduled_hook('mcqvs_orphan_kill_cron');
    wp_clear_scheduled_hook('mcqvs_daily_telemetry_prune');
    // @NEW 2026-08-09: Cancel the artifact-prune daily cron.
    wp_clear_scheduled_hook('mcqvs_daily_artifact_prune');

    $wpdb->query("DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_mcqvs_job_lock_%' OR option_name LIKE '_transient_mcqvs_render_pid_%' OR option_name LIKE '_transient_mcqvs_render_auth_%' OR option_name LIKE '_transient_mcqvs_render_auth_verified_%'");
    $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", '_transient_mcqvs_render_started_%'));
    $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s", 'mcqvs_api_count_%', 'mcqvs_videos_created_%'));
    $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", '_transient_mcqvs_auth_attempts_%'));
    $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", '_transient_mcqvs_render_log_%'));
    $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", '_transient_mcqvs_render_status_%'));
    $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", '_transient_mcqvs_render_payload_%'));
    $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", '_transient_mcqvs_render_out_%'));
    $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", '_transient_mcqvs_render_exit_%'));
    $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", '_transient_mcqvs_render_auth_%'));
    $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", '_transient_mcqvs_render_auth_verified_%'));

    // Volatile logs table only — user-data tables are purged only when opted in.
    $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}vs_logs");

    // ---- Destructive cleanup: only when MCQVS_PURGE_DATA_ON_UNINSTALL === true ----
    if ($purge) {
        $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", 'mcqvs_batch_%'));

        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}vs_topics");
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}vs_mcq_bank");
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}vs_exam_calendar");
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}vs_jobs");
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}vs_projects");
        $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}vs_project_questions");

        delete_option('mcqvs_db_version');
        delete_option('mcqvs_db_enum_fix_136');
        delete_option('mcqvs_db_varchar_migration');
        delete_option('mcqvs_publish_columns_migration');
        delete_option('mcqvs_model_provider_column_migration');
        delete_option('mcqvs_batch_tracker');
        delete_option('mcqvs_content_plan');
        delete_option('mcqvs_content_plan_pending_batches');
        delete_option('mcqvs_selftest_status');
        delete_option('mcqvs_selftest_last_run');
        delete_option('mcqvs_selftest_last_report');
        delete_option('mcqvs_dismissed_dependency_notice');
        delete_option('mcqvs_dismissed_selftest_notice');
        delete_option('mcqvs_rotation_state');
        delete_option('mcqvs_did_init_log');
        delete_option('mcqvs_did_core_init_log');
        delete_option('mcqvs_api_provider');
        delete_option('mcqvs_custom_providers');
        delete_option('mcqvs_gemini_api_key');
        delete_option('mcqvs_external_assets_url');
        delete_option('mcqvs_version');

        // @NEW 2026-08-09: Artifact cleanup retention options + dry-run flag.
        delete_option('mcqvs_artifact_retention_tts');
        delete_option('mcqvs_artifact_retention_covers');
        delete_option('mcqvs_artifact_retention_generated');
        delete_option('mcqvs_artifact_retention_exports');
        delete_option('mcqvs_artifact_retention_batch');
        delete_option('mcqvs_artifact_retention_render_temp');
        delete_option('mcqvs_artifact_retention_temp');
        delete_option('mcqvs_artifact_retention_dry_run');

        // @NEW 2026-08-09: Drop the entire uploads/mcq-video-studio/ tree.
        if (function_exists('wp_upload_dir')) {
            $uploads = wp_upload_dir();
            if (empty($uploads['error']) && ! empty($uploads['basedir'])) {
                $root = $uploads['basedir'] . '/mcq-video-studio';
                if (is_dir($root)) {
                    try {
                        $iter = new RecursiveIteratorIterator(
                            new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS),
                            RecursiveIteratorIterator::CHILD_FIRST
                        );
                        foreach ($iter as $entry) {
                            try {
                                $is_link = $entry->isLink();
                            } catch (\Throwable $e) {
                                $is_link = false;
                            }
                            if ($is_link) {
                                @unlink($entry->getPathname());
                                continue;
                            }
                            if ($entry->isDir()) {
                                @rmdir($entry->getPathname());
                            } else {
                                @unlink($entry->getPathname());
                            }
                        }
                        @rmdir($root);
                    } catch (\Throwable $e) {
                        // best-effort: ignore
                    }
                }
            }
        }
    }
}

// WordPress routes uninstall.php through the register_uninstall_hook path,
// but calling mcqvs_uninstall_plugin() directly here covers direct file access.
if (function_exists('mcqvs_uninstall_plugin')) {
    mcqvs_uninstall_plugin();
} else {
    mcqvs_uninstall_plugin_direct();
}
