Template Preview Images
======================

Place PNG preview images here for each template:

- news-card.png
- dual-photo.png
- text-heavy.png

Each preview should be 540x675 (half of 1080x1350) showing a representative
render of the template with sample Urdu text.
