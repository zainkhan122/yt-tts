<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) exit;

class ImageMagickCompositor {

	private $temp_dir;

	public function __construct() {
		$this->temp_dir = AI_SOCIAL_COLLAGE_PATH . 'assets/temp';
		if ( ! is_dir( $this->temp_dir ) ) {
			wp_mkdir_p( $this->temp_dir );
		}
	}

	public function render( string $template, array $job_data, $headline_gd = null, $hook_gd = null ): ?string {
		switch ( $template ) {
			case Config::TEMPLATE_DUAL_PHOTO:
				return $this->render_dual_photo( $job_data, $headline_gd, $hook_gd );
			case Config::TEMPLATE_TEXT_HEAVY:
				return $this->render_text_heavy( $job_data, $headline_gd, $hook_gd );
			default:
				return $this->render_news_card( $job_data, $headline_gd, $hook_gd );
		}
	}

	private function render_news_card( array $d, $headline_gd, $hook_gd ): ?string {
		$w = $d['width'] ?? 800;
		$h = $d['height'] ?? 1000;
		$bg_color = $d['colors']['text_backing'] ?? '#0a0a0a';
		$accent = $d['colors']['accent'] ?? '#FF1744';
		
		// Calculate dynamic heights based on campaign zones if defined
		$image_zone = $d['image_zone'] ?? null;
		$image_h_ratio = isset( $image_zone['h'] ) ? floatval( $image_zone['h'] ) : 0.55;
		$image_h = (int)( $h * $image_h_ratio );
		$brand_h_pct = floatval( ( $d['brand'] ?? [] )['brand_bar_height_pct'] ?? Config::DEFAULT_BRAND_BAR_HEIGHT_PCT );
		$brand_h = (int)( $h * $brand_h_pct / 100 );
		$remaining_text_h = max( 0, $h - $image_h - $brand_h );
		$heading_h = (int)( $remaining_text_h * ( 10 / 35 ) );
		$desc_h = $remaining_text_h - $heading_h;

		$canvas = imagecreatetruecolor( $w, $h );
		if ( ! $canvas ) return null;
		imagesavealpha( $canvas, true );

		$bg_rgb = $this->hex_to_rgb( $bg_color );
		$bg_alloc = imagecolorallocate( $canvas, $bg_rgb['r'], $bg_rgb['g'], $bg_rgb['b'] );
		imagefill( $canvas, 0, 0, $bg_alloc );

		$img1 = $this->load_image( $d['image_url'] ?? '' );
		if ( $img1 ) {
			$src_w = imagesx( $img1 );
			$src_h = imagesy( $img1 );
			if ( $src_w > 0 && $src_h > 0 ) {
				$scale = max( $w / $src_w, $image_h / $src_h );
				$scaled_w = (int)( $src_w * $scale );
				$scaled_h = (int)( $src_h * $scale );
				$dst_x = (int)( ( $w - $scaled_w ) / 2 );
				$dst_y = (int)( ( $image_h - $scaled_h ) / 2 );
				imagecopyresampled( $canvas, $img1, $dst_x, $dst_y, 0, 0, $scaled_w, $scaled_h, $src_w, $src_h );
			}
			imagedestroy( $img1 );
		}

		// Gradient overlay for image-to-text transition
		$gradient_h = (int)( $h * 0.06 );
		$gradient_top = $image_h - $gradient_h;
		$this->draw_gradient_overlay( $canvas, $w, $gradient_h, $gradient_top, $bg_color );

		// Heading section at 10% height
		$heading_start_y = $image_h;
		$padding_x = (int)( $w * 0.06 );

		// Draw Category Badge
		$category_badge_text = $d['category_badge'] ?? 'خبر';
		$badge_font_path = $this->resolve_font_path(Config::DEFAULT_BRAND_FONT_BODY);
		if ($badge_font_path) {
			$badge_size = 14;
			$bbox = imagettfbbox($badge_size, 0, $badge_font_path, $category_badge_text);
			$badge_width = abs($bbox[4] - $bbox[0]) + 20;
			$badge_height = abs($bbox[5] - $bbox[1]) + 10;
			$badge_bg_color_rgb = $this->hex_to_rgb($accent);
			$badge_bg_color = imagecolorallocate($canvas, $badge_bg_color_rgb['r'], $badge_bg_color_rgb['g'], $badge_bg_color_rgb['b']);
			$white = imagecolorallocate($canvas, 255, 255, 255);
			$language = $d['language'] ?? 'en';
			$is_rtl = ($language === 'ur');
			if ($is_rtl) {
				$badge_x = $w - $padding_x - $badge_width;
				imagefilledrectangle($canvas, $badge_x, $heading_start_y + 8, $badge_x + $badge_width, $heading_start_y + 8 + $badge_height, $badge_bg_color);
				imagettftext($canvas, $badge_size, 0, $badge_x + 10, $heading_start_y + 8 + $badge_size + 2, $white, $badge_font_path, $category_badge_text);
			} else {
				imagefilledrectangle($canvas, $padding_x, $heading_start_y + 8, $padding_x + $badge_width, $heading_start_y + 8 + $badge_height, $badge_bg_color);
				imagettftext($canvas, $badge_size, 0, $padding_x + 10, $heading_start_y + 8 + $badge_size + 2, $white, $badge_font_path, $category_badge_text);
			}
		}

		$headline_paste_y = isset($badge_height) ? $heading_start_y + 8 + $badge_height + 6 : $heading_start_y + 8;
		if ( $headline_gd && ( is_resource( $headline_gd ) || $headline_gd instanceof \GdImage ) ) {
			$hw = imagesx( $headline_gd );
			$hh = imagesy( $headline_gd );
			imagecopy( $canvas, $headline_gd, $padding_x, $headline_paste_y, 0, 0, $hw, $hh );
		}

		// Description section at 25% height
		$desc_start_y = $image_h + $heading_h;
		if ( $hook_gd && ( is_resource( $hook_gd ) || $hook_gd instanceof \GdImage ) ) {
			$kw = imagesx( $hook_gd );
			$kh = imagesy( $hook_gd );
			imagecopy( $canvas, $hook_gd, $padding_x, $desc_start_y + 8, 0, 0, $kw, $kh );
		}

		$brand = $d['brand'] ?? [];
		$this->draw_brand_bar( $canvas, $brand, $d['colors'] ?? [], $w, $h, $d );

		$out = $this->temp_dir . '/render_' . uniqid() . '.png';
		$saved = imagepng( $canvas, $out, 1 );
		imagedestroy( $canvas );

		if ( ! $saved || ! file_exists( $out ) || filesize( $out ) < 50 ) {
			Logger::error( 'imagemagick_command_failed', $d['job_id'] ?? 0, [
				'error' => 'GD save failed',
				'file_exists' => file_exists( $out ),
				'file_size' => file_exists( $out ) ? filesize( $out ) : 0,
			], '500' );
			return null;
		}
		return $out;
	}

	private function render_dual_photo( array $d, $headline_gd, $hook_gd ): ?string {
		$w = $d['width'] ?? 1080;
		$h = $d['height'] ?? 1350;
		$bg_color = $d['colors']['text_backing'] ?? '#0a0a0a';
		$accent = $d['colors']['accent'] ?? '#FF1744';
		$image_zone = $d['image_zone'] ?? null;
		$image_h_ratio = isset( $image_zone['h'] ) ? floatval( $image_zone['h'] ) : 0.52;
		$photo_h = (int)( $h * $image_h_ratio );
		$half_w = (int)( $w / 2 );

		$canvas = imagecreatetruecolor( $w, $h );
		if ( ! $canvas ) return null;
		imagesavealpha( $canvas, true );

		$bg_rgb = $this->hex_to_rgb( $bg_color );
		$bg_alloc = imagecolorallocate( $canvas, $bg_rgb['r'], $bg_rgb['g'], $bg_rgb['b'] );
		imagefill( $canvas, 0, 0, $bg_alloc );

		$img1 = $this->load_image( $d['image_url'] ?? '' );
		if ( $img1 ) {
			$src_w = imagesx( $img1 );
			$src_h = imagesy( $img1 );
			if ( $src_w > 0 && $src_h > 0 ) {
				$scale = max( $half_w / $src_w, $photo_h / $src_h );
				$scaled_w = (int)( $src_w * $scale );
				$scaled_h = (int)( $src_h * $scale );
				$dst_x = (int)( ( $half_w - $scaled_w ) / 2 );
				$dst_y = (int)( ( $photo_h - $scaled_h ) / 2 );
				imagecopyresampled( $canvas, $img1, $dst_x, $dst_y, 0, 0, $scaled_w, $scaled_h, $src_w, $src_h );
			}
			imagedestroy( $img1 );
		}

		$img2 = $this->load_image( $d['image_url_2'] ?? '' );
		if ( $img2 ) {
			$src_w = imagesx( $img2 );
			$src_h = imagesy( $img2 );
			if ( $src_w > 0 && $src_h > 0 ) {
				$scale = max( $half_w / $src_w, $photo_h / $src_h );
				$scaled_w = (int)( $src_w * $scale );
				$scaled_h = (int)( $src_h * $scale );
				$dst_x = $half_w + (int)( ( $half_w - $scaled_w ) / 2 );
				$dst_y = (int)( ( $photo_h - $scaled_h ) / 2 );
				imagecopyresampled( $canvas, $img2, $dst_x, $dst_y, 0, 0, $scaled_w, $scaled_h, $src_w, $src_h );
			}
			imagedestroy( $img2 );
		}

		$gap_alloc = imagecolorallocate( $canvas, 0, 0, 0 );
		imagefilledrectangle( $canvas, $half_w - 2, 0, $half_w + 2, $photo_h, $gap_alloc );

		$gradient_h = 60;
		$gradient_top = $photo_h - $gradient_h;
		$this->draw_gradient_overlay( $canvas, $w, $gradient_h, $gradient_top, $bg_color );

		$text_start_y = $photo_h + 30;
		$padding_x = (int)( $w * 0.06 );

		// Draw Category Badge
		$category_badge_text = $d['category_badge'] ?? 'خبر';
		$badge_font_path = $this->resolve_font_path(Config::DEFAULT_BRAND_FONT_BODY);
		if ($badge_font_path) {
			$badge_size = 14;
			$bbox = imagettfbbox($badge_size, 0, $badge_font_path, $category_badge_text);
			$badge_width = abs($bbox[4] - $bbox[0]) + 20;
			$badge_height = abs($bbox[5] - $bbox[1]) + 10;
			$badge_bg_color_rgb = $this->hex_to_rgb($accent);
			$badge_bg_color = imagecolorallocate($canvas, $badge_bg_color_rgb['r'], $badge_bg_color_rgb['g'], $badge_bg_color_rgb['b']);
			$white = imagecolorallocate($canvas, 255, 255, 255);
			$language = $d['language'] ?? 'en';
			$is_rtl = ($language === 'ur');
			if ($is_rtl) {
				$badge_x = $w - $padding_x - $badge_width;
				imagefilledrectangle($canvas, $badge_x, $text_start_y, $badge_x + $badge_width, $text_start_y + $badge_height, $badge_bg_color);
				imagettftext($canvas, $badge_size, 0, $badge_x + 10, $text_start_y + $badge_size + 2, $white, $badge_font_path, $category_badge_text);
			} else {
				imagefilledrectangle($canvas, $padding_x, $text_start_y, $padding_x + $badge_width, $text_start_y + $badge_height, $badge_bg_color);
				imagettftext($canvas, $badge_size, 0, $padding_x + 10, $text_start_y + $badge_size + 2, $white, $badge_font_path, $category_badge_text);
			}
			$text_start_y += $badge_height + 10;
		}

		// Draw Photo Labels
		$photo_label_1_text = $d['photo_label_1'] ?? '';
		$photo_label_2_text = $d['photo_label_2'] ?? '';
		$label_font_path = $this->resolve_font_path(Config::DEFAULT_BRAND_FONT_BODY);
		if ($label_font_path && !empty($photo_label_1_text)) {
			$label_size = 12;
			$black_alpha = imagecolorallocatealpha($canvas, 0, 0, 0, 50);
			imagettftext($canvas, $label_size, 0, (int)($w * 0.03), (int)($h * 0.48), $text_color_rgb, $label_font_path, $photo_label_1_text);
		}
		if ($label_font_path && !empty($photo_label_2_text)) {
			$label_size = 12;
			imagettftext($canvas, $label_size, 0, (int)($w * 0.53), (int)($h * 0.48), $text_color_rgb, $label_font_path, $photo_label_2_text);
		}

		if ( $headline_gd && ( is_resource( $headline_gd ) || $headline_gd instanceof \GdImage ) ) {
			$hw = imagesx( $headline_gd );
			$hh = imagesy( $headline_gd );
			imagecopy( $canvas, $headline_gd, $padding_x, $text_start_y, 0, 0, $hw, $hh );
			$text_start_y += $hh + 16;
		}
		if ( $hook_gd && ( is_resource( $hook_gd ) || $hook_gd instanceof \GdImage ) ) {
			$kw = imagesx( $hook_gd );
			$kh = imagesy( $hook_gd );
			imagecopy( $canvas, $hook_gd, $padding_x, $text_start_y, 0, 0, $kw, $kh );
		}

		$brand = $d['brand'] ?? [];
		$this->draw_brand_bar( $canvas, $brand, $d['colors'] ?? [], $w, $h, $d );
		// NOTE: hook_gd was already composited above at line ~240. Do NOT composite again.
		// The second imagecopy here (removed) was rendering the description text twice,
		// causing garbled overlapping text in the output image (Finding 8 fix).
		$this->draw_top_logo( $canvas, $brand, $w, $d );

		$out = $this->temp_dir . '/render_' . uniqid() . '.png';
		$saved = imagepng( $canvas, $out, 1 );
		imagedestroy( $canvas );

		if ( ! $saved || ! file_exists( $out ) || filesize( $out ) < 50 ) {
			Logger::error( 'imagemagick_command_failed', $d['job_id'] ?? 0, [
				'error' => 'GD save failed',
			], '500' );
			return null;
		}
		return $out;
	}

	private function render_text_heavy( array $d, $headline_gd, $hook_gd ): ?string {
		$w = $d['width'] ?? 1080;
		$h = $d['height'] ?? 1350;
		$bg_color = $d['colors']['text_backing'] ?? '#0a0a0a';
		$accent = $d['colors']['accent'] ?? '#FF1744';
		$image_zone = $d['image_zone'] ?? null;
		$image_h_ratio = isset( $image_zone['h'] ) ? floatval( $image_zone['h'] ) : 0.30;
		$photo_h = (int)( $h * $image_h_ratio );

		$canvas = imagecreatetruecolor( $w, $h );
		if ( ! $canvas ) return null;
		imagesavealpha( $canvas, true );

		$bg_rgb = $this->hex_to_rgb( $bg_color );
		$bg_alloc = imagecolorallocate( $canvas, $bg_rgb['r'], $bg_rgb['g'], $bg_rgb['b'] );
		imagefill( $canvas, 0, 0, $bg_alloc );

		$img1 = $this->load_image( $d['image_url'] ?? '' );
		if ( $img1 ) {
			$src_w = imagesx( $img1 );
			$src_h = imagesy( $img1 );
			if ( $src_w > 0 && $src_h > 0 ) {
				$scale = max( $w / $src_w, $photo_h / $src_h );
				$scaled_w = (int)( $src_w * $scale );
				$scaled_h = (int)( $src_h * $scale );
				$dst_x = (int)( ( $w - $scaled_w ) / 2 );
				$dst_y = (int)( ( $photo_h - $scaled_h ) / 2 );
				imagecopyresampled( $canvas, $img1, $dst_x, $dst_y, 0, 0, $scaled_w, $scaled_h, $src_w, $src_h );
			}
			imagedestroy( $img1 );
		}

		$gradient_h = 60;
		$gradient_top = $photo_h - $gradient_h;
		$this->draw_gradient_overlay( $canvas, $w, $gradient_h, $gradient_top, $bg_color );

		$text_start_y = $photo_h + 60;
		$padding_x = (int)( $w * 0.06 );

		// Draw Category Badge (if applicable for text-heavy)
		$category_badge_text = $d['category_badge'] ?? 'بیان';
		$badge_font_path = $this->resolve_font_path(Config::DEFAULT_BRAND_FONT_BODY);
		if ($badge_font_path) {
			$badge_size = 14;
			$bbox = imagettfbbox($badge_size, 0, $badge_font_path, $category_badge_text);
			$badge_width = abs($bbox[4] - $bbox[0]) + 20;
			$badge_height = abs($bbox[5] - $bbox[1]) + 10;
			$badge_bg_color_rgb = $this->hex_to_rgb($accent);
			$badge_bg_color = imagecolorallocate($canvas, $badge_bg_color_rgb['r'], $badge_bg_color_rgb['g'], $badge_bg_color_rgb['b']);
			$white = imagecolorallocate($canvas, 255, 255, 255);
			$language = $d['language'] ?? 'en';
			$is_rtl = ($language === 'ur');
			if ($is_rtl) {
				$badge_x = $w - $padding_x - $badge_width;
				imagefilledrectangle($canvas, $badge_x, $text_start_y, $badge_x + $badge_width, $text_start_y + $badge_height, $badge_bg_color);
				imagettftext($canvas, $badge_size, 0, $badge_x + 10, $text_start_y + $badge_size + 2, $white, $badge_font_path, $category_badge_text);
			} else {
				imagefilledrectangle($canvas, $padding_x, $text_start_y, $padding_x + $badge_width, $text_start_y + $badge_height, $badge_bg_color);
				imagettftext($canvas, $badge_size, 0, $padding_x + 10, $text_start_y + $badge_size + 2, $white, $badge_font_path, $category_badge_text);
			}
			$text_start_y += $badge_height + 10;
		}

		if ( $headline_gd && ( is_resource( $headline_gd ) || $headline_gd instanceof \GdImage ) ) {
			$hw = imagesx( $headline_gd );
			$hh = imagesy( $headline_gd );
			$center_x = (int)( ( $w - $hw ) / 2 );
			imagecopy( $canvas, $headline_gd, $center_x, $text_start_y, 0, 0, $hw, $hh );
			$text_start_y += $hh + 20;
		}
		// For text-heavy, hook_gd is used for attribution
		$attribution_text = $d['attribution'] ?? '';
		if ( !empty($attribution_text) ) {
			$attribution_font_path = $this->resolve_font_path(Config::DEFAULT_BRAND_FONT_BODY);
			if ($attribution_font_path) {
				$attribution_size = 14;
				$bbox = imagettfbbox($attribution_size, 0, $attribution_font_path, $attribution_text);
				$attribution_width = abs($bbox[4] - $bbox[0]);
				$center_x_attr = (int)( ( $w - $attribution_width ) / 2 );
				$accent_rgb_attr = $this->hex_to_rgb($accent);
				$accent_alloc_attr = imagecolorallocate($canvas, $accent_rgb_attr['r'], $accent_rgb_attr['g'], $accent_rgb_attr['b']);
				imagettftext($canvas, $attribution_size, 0, $center_x_attr, $text_start_y, $accent_alloc_attr, $attribution_font_path, $attribution_text);
			}
		}

		$brand = $d['brand'] ?? [];
		$this->draw_brand_bar( $canvas, $brand, $d['colors'] ?? [], $w, $h, $d );
		if ( $hook_gd && ( is_resource( $hook_gd ) || $hook_gd instanceof \GdImage ) ) {
			$kw = imagesx( $hook_gd );
			$kh = imagesy( $hook_gd );
			$center_x = (int)( ( $w - $kw ) / 2 );
			imagecopy( $canvas, $hook_gd, $center_x, $text_start_y, 0, 0, $kw, $kh );
		}
		$this->draw_top_logo( $canvas, $brand, $w, $d );

		$out = $this->temp_dir . '/render_' . uniqid() . '.png';
		$saved = imagepng( $canvas, $out, 1 );
		imagedestroy( $canvas );

		if ( ! $saved || ! file_exists( $out ) || filesize( $out ) < 50 ) {
			Logger::error( 'imagemagick_command_failed', $d['job_id'] ?? 0, [
				'error' => 'GD save failed',
			], '500' );
			return null;
		}
		return $out;
	}

	private function load_image( $url ) {
		if ( empty( $url ) ) return null;

		// If it's a local filesystem path and exists, load it directly
		if ( ! preg_match( '/^https?:\/\//i', $url ) && file_exists( $url ) ) {
			$ext = strtolower( pathinfo( $url, PATHINFO_EXTENSION ) );
			if ( $ext === 'jpg' || $ext === 'jpeg' ) return @imagecreatefromjpeg( $url );
			if ( $ext === 'png' ) return @imagecreatefrompng( $url );
			if ( $ext === 'webp' ) return @imagecreatefromwebp( $url );
			return @imagecreatefromstring( file_get_contents( $url ) );
		}

		$upload_dir = wp_upload_dir();
		if ( strpos( $url, $upload_dir['baseurl'] ) === 0 ) {
			$path = str_replace( $upload_dir['baseurl'], $upload_dir['basedir'], $url );
			if ( file_exists( $path ) ) {
				$ext = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
				if ( $ext === 'jpg' || $ext === 'jpeg' ) return @imagecreatefromjpeg( $path );
				if ( $ext === 'png' ) return @imagecreatefrompng( $path );
				if ( $ext === 'webp' ) return @imagecreatefromwebp( $path );
				return @imagecreatefromstring( file_get_contents( $path ) );
			}
		}
		if ( ! function_exists( 'download_url' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$tmp = download_url( $url, 30 );
		if ( is_wp_error( $tmp ) ) {
			Logger::warning( 'prep_img_download_failed', null, [ 'url' => mb_substr( $url, 0, 120 ) ], '500' );
			return null;
		}
		$img = @imagecreatefromstring( file_get_contents( $tmp ) );
		@unlink( $tmp );
		return $img;
	}

	private function load_logo( array $d ) {
		$brand = $d['brand'] ?? [];
		$logo_url = $brand['logo_url'] ?? '';
		if ( empty( $logo_url ) ) return null;

		$logo = $this->load_image( $logo_url );
		if ( ! $logo ) return null;

		$logo_w = imagesx( $logo );
		$logo_h = imagesy( $logo );
		$new_logo_w = 100;
		$new_logo_h = (int)( $logo_h * $new_logo_w / $logo_w );
		$resized_logo = imagecreatetruecolor( $new_logo_w, $new_logo_h );
		imagesavealpha( $resized_logo, true );
		imagefill( $resized_logo, 0, 0, imagecolorallocatealpha( $resized_logo, 0, 0, 0, 127 ) );
		imagecopyresampled( $resized_logo, $logo, 0, 0, 0, 0, $new_logo_w, $new_logo_h, $logo_w, $logo_h );
		imagedestroy( $logo );

		return $resized_logo;
	}

	private function draw_gradient_overlay( $canvas, $width, $height, $y_start, $color_hex ) {
		$rgb = $this->hex_to_rgb( $color_hex );
		$steps = min( $height, 100 );
		for ( $i = 0; $i < $steps; $i++ ) {
			$ratio = $i / $steps;
			$alpha = (int)( 127 * ( 1 - $ratio ) );
			$y = $y_start + (int)( $ratio * $height );
			$bar_h = max( 1, (int)( $height / $steps ) + 1 );
			$color = imagecolorallocatealpha( $canvas, $rgb['r'], $rgb['g'], $rgb['b'], $alpha );
			imagefilledrectangle( $canvas, 0, $y, $width, $y + $bar_h, $color );
		}
	}

	private function resolve_font_path( $font_family ) {
		$map = [
			'Noto Nastaliq Urdu'        => 'NotoNastaliqUrdu-Regular.ttf',
			'Noto Nastaliq Urdu Medium' => 'NotoNastaliqUrdu-Medium.ttf',
			'Jameel Noori Nastaliq'     => 'JameelNooriNastaliq.ttf',
			'Nafees Web Naskh'          => 'NafeesWebNaskh.ttf',
			'Noto Sans Arabic'          => 'NotoSansArabic-Regular.ttf',
			'Montserrat'                => 'Montserrat-Bold.ttf',
			'Inter'                     => 'Inter-Regular.ttf',
			'Playfair Display'          => 'PlayfairDisplay-Regular.ttf',
			'Oswald'                    => 'Oswald-Regular.ttf',
			'Roboto'                    => 'Roboto-Regular.ttf',
			'Poppins'                   => 'Poppins-Regular.ttf',
			'Bebas Neue'                => 'BebasNeue-Regular.ttf',
			'Lora'                      => 'Lora-Regular.ttf',
			'Raleway'                   => 'Raleway-Regular.ttf',
		];
		$file = $map[ $font_family ] ?? '';
		if ( $file === '' ) {
			return '';
		}
		$path = AI_SOCIAL_COLLAGE_PATH . 'assets/fonts/' . $file;
		if ( file_exists( $path ) ) {
			return $path;
		}
		$system_fallbacks = [
			'/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
			'/usr/share/fonts/dejavu/DejaVuSans-Bold.ttf',
			'/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf',
			'C:\\Windows\\Fonts\\arial.ttf',
			'C:\\Windows\\Fonts\\verdana.ttf',
		];
		foreach ( $system_fallbacks as $fb ) {
			if ( file_exists( $fb ) ) return $fb;
		}
		return '';
	}

	private function hex_to_rgb( $hex ) {
		$hex = ltrim( $hex, '#' );
		if ( strlen( $hex ) !== 6 || ! ctype_xdigit( $hex ) ) {
			return [ 'r' => 0, 'g' => 0, 'b' => 0 ];
		}
		return [
			'r' => hexdec( substr( $hex, 0, 2 ) ),
			'g' => hexdec( substr( $hex, 2, 2 ) ),
			'b' => hexdec( substr( $hex, 4, 2 ) ),
		];
	}

	private function parse_css_color( $color, $default_alpha = 0 ) {
		if ( preg_match( '/^rgba\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*([\d.]+)\s*\)$/i', $color, $m ) ) {
			return [
				'r'     => (int) $m[1],
				'g'     => (int) $m[2],
				'b'     => (int) $m[3],
				'alpha' => (int) round( ( 1 - (float) $m[4] ) * 127 ),
			];
		}
		if ( preg_match( '/^rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)$/i', $color, $m ) ) {
			return [ 'r' => (int) $m[1], 'g' => (int) $m[2], 'b' => (int) $m[3], 'alpha' => $default_alpha ];
		}
		$rgb = $this->hex_to_rgb( $color );
		return [ 'r' => $rgb['r'], 'g' => $rgb['g'], 'b' => $rgb['b'], 'alpha' => $default_alpha ];
	}

	private function draw_brand_bar( $canvas, $brand, $colors, $w, $h, $d = [] ) {
		$brand_name_text = $brand['brand_name'] ?? '';
		$brand_url_text  = $brand['brand_url'] ?? '';
		$accent          = $colors['accent'] ?? '#FF1744';
		$text_color      = ! empty( $brand['brand_bar_text_color'] ) ? $brand['brand_bar_text_color'] : ( $colors['text_color'] ?? '#ffffff' );

		$bar_height_pct = floatval( $brand['brand_bar_height_pct'] ?? Config::DEFAULT_BRAND_BAR_HEIGHT_PCT );
		$brand_bar_h    = max( 1, (int) round( $h * $bar_height_pct / 100 ) );
		$brand_bar_y    = $h - $brand_bar_h;

		$bg_css = ! empty( $brand['brand_bar_bg_color'] ) ? $brand['brand_bar_bg_color'] : Config::DEFAULT_BRAND_BAR_BG_COLOR;
		$bg     = $this->parse_css_color( $bg_css, 120 );
		$bar_bg = imagecolorallocatealpha( $canvas, $bg['r'], $bg['g'], $bg['b'], $bg['alpha'] );
		imagefilledrectangle( $canvas, 0, $brand_bar_y, $w, $h, $bar_bg );

		$show_accent = ( isset( $brand['brand_bar_accent_line'] ) && $brand['brand_bar_accent_line'] === '1' );
		if ( $show_accent ) {
			$line_rgb   = $this->hex_to_rgb( $accent );
			$line_alloc = imagecolorallocatealpha( $canvas, $line_rgb['r'], $line_rgb['g'], $line_rgb['b'], 60 );
			imagefilledrectangle( $canvas, 0, $brand_bar_y, $w, $brand_bar_y + 1, $line_alloc );
		}

		$logo_padding_x = 20;
		$logo           = $this->load_logo( $d );
		$logo_w         = 0;
		if ( $logo ) {
			$logo_w = imagesx( $logo );
			$logo_h = imagesy( $logo );
			$logo_y = $brand_bar_y + (int) ( ( $brand_bar_h - $logo_h ) / 2 );
			imagecopy( $canvas, $logo, $logo_padding_x, $logo_y, 0, 0, $logo_w, $logo_h );
			imagedestroy( $logo );
		}

		$font_size = intval( $brand['brand_bar_font_size'] ?? Config::DEFAULT_BRAND_BAR_FONT_SIZE );
		$text_rgb  = $this->hex_to_rgb( $text_color );
		$text_alloc = imagecolorallocate( $canvas, $text_rgb['r'], $text_rgb['g'], $text_rgb['b'] );
		$font_path_body = $this->resolve_font_path( Config::DEFAULT_BRAND_FONT_BODY );
		if ( $font_path_body ) {
			$text_x = $logo ? $logo_padding_x + $logo_w + 10 : $logo_padding_x;
			imagettftext( $canvas, $font_size, 0, $text_x, $brand_bar_y + (int) ( $brand_bar_h / 2 ) + (int) ( $font_size / 3 ), $text_alloc, $font_path_body, $brand_name_text );

			$brand_url_rgb    = $this->hex_to_rgb( $accent );
			$brand_url_alloc  = imagecolorallocate( $canvas, $brand_url_rgb['r'], $brand_url_rgb['g'], $brand_url_rgb['b'] );
			$url_font_size    = max( 9, $font_size - 2 );
			imagettftext( $canvas, $url_font_size, 0, $w - $logo_padding_x - (strlen( $brand_url_text ) * (int)( $url_font_size * 0.6 )), $brand_bar_y + (int) ( $brand_bar_h / 2 ) + (int) ( $url_font_size / 3 ), $brand_url_alloc, $font_path_body, $brand_url_text );
		}

		return $brand_bar_y;
	}

	private function draw_top_logo( $canvas, $brand, $w, $d = [] ) {
		$logo_position = $brand['logo_position'] ?? Config::DEFAULT_BRAND_LOGO_POSITION;
		if ( $logo_position !== 'top-left' && $logo_position !== 'top-right' ) {
			return;
		}

		$logo = $this->load_logo( $d );
		if ( ! $logo ) return;
		$logo_w = imagesx( $logo );
		$logo_h = imagesy( $logo );
		$max_w  = 100;
		if ( $logo_w > $max_w ) {
			$new_h    = (int) ( $logo_h * $max_w / $logo_w );
			$resized  = imagecreatetruecolor( $max_w, $new_h );
			imagesavealpha( $resized, true );
			imagefill( $resized, 0, 0, imagecolorallocatealpha( $resized, 0, 0, 0, 127 ) );
			imagecopyresampled( $resized, $logo, 0, 0, 0, 0, $max_w, $new_h, $logo_w, $logo_h );
			imagedestroy( $logo );
			$logo = $resized;
			$logo_w = $max_w;
			$logo_h = $new_h;
		}

		if ( $logo_position === 'top-left' ) {
			$logo_x = 20;
		} else {
			$logo_x = $w - 20 - $logo_w;
		}
		imagecopy( $canvas, $logo, $logo_x, 20, 0, 0, $logo_w, $logo_h );
		imagedestroy( $logo );
	}
}
