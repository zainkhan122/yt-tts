/**
 * SEO Generator Accordion Script
 * Unified handler for all accordion types (Installation, Troubleshooting, FAQ)
 *
 * @package SEO_Article_Generator
 * @version 2.5.3
 */
(function ($) {
  "use strict";

  $(document).ready(function () {
    console.log("[SEO-GEN] Accordion logic initializing...");

    var AccordionController = {
      isBusy: false,

      toggle: function ($trigger, $content, $container) {
        if (this.isBusy || !$content.length) return;

        // Prevent double-toggle if another script is acting
        if ($content.data("animating")) return;

        var self = this;
        var $icon = $trigger.find(".accordion-icon, .seo-gen-accordion-icon");

        // Rank Math wrapper item (only exists for FAQs)
        var $rankMathItem = $trigger.closest(
          ".rank-math-faq-item, .rank-math-list-item"
        );
        if ($rankMathItem.length) $rankMathItem.stop(true, true).show();
        var isOpen = $trigger.hasClass("active") || $content.is(":visible");

        $content.data("animating", true);
        this.isBusy = true;

        // Stop queued animations (prevents weird states on rapid clicks)
        $content.stop(true, true);

        if (isOpen) {
          // Close
          $content.slideUp(300, function () {
            $trigger.removeClass("active").attr("aria-expanded", "false");
            $content.removeClass("open").attr("aria-hidden", "true");

            if ($rankMathItem.length) $rankMathItem.removeClass("active");
            if ($icon.length) $icon.text("▼");

            $content.data("animating", false);
            self.isBusy = false;
          });
          return;
        }

        // Open (exclusive mode: close others inside same container)
        if ($container && $container.length) {
          var $others = $container
            .find(
              ".rank-math-question.active, .seo-gen-accordion-trigger.active, .seo-gen-accordion-toggle.active"
            )
            .not($trigger);

          $others.each(function () {
            var $otherTrigger = $(this);
            var $otherContent = self.findContent($otherTrigger);
            var $otherIcon = $otherTrigger.find(
              ".accordion-icon, .seo-gen-accordion-icon"
            );
            var $otherItem = $otherTrigger.closest(
              ".rank-math-faq-item, .rank-math-list-item"
            );
            if ($otherItem.length) $otherItem.stop(true, true).show();
            $otherTrigger.removeClass("active").attr("aria-expanded", "false");
            if ($otherItem.length) $otherItem.removeClass("active");

            if ($otherContent.length) {
              $otherContent
                .stop(true, true)
                .slideUp(200)
                .removeClass("open")
                .attr("aria-hidden", "true");
              $otherContent.data("animating", false);
            }

            if ($otherIcon.length) $otherIcon.text("▼");
          });
        }

        // Mark active BEFORE slideDown so CSS that depends on .active works immediately
        $trigger.addClass("active").attr("aria-expanded", "true");
        $content.addClass("open").attr("aria-hidden", "false");
        if ($rankMathItem.length) $rankMathItem.addClass("active");
        if ($icon.length) $icon.text("▲");

        $content.slideDown(300, function () {
          $content.data("animating", false);
          self.isBusy = false;
        });
      },

      findContent: function ($trigger) {
        // 1) Explicit target
        var targetId =
          $trigger.data("target") || $trigger.attr("aria-controls");
        if (targetId) {
          var $target = $("#" + targetId);
          if ($target.length) return $target;
        }

        // 2) Rank Math structure
        var $next = $trigger.next(".rank-math-answer");
        if ($next.length) return $next;

        var $item = $trigger.closest(
          ".rank-math-faq-item, .rank-math-list-item"
        );
        if ($item.length) {
          var $ans = $item.find(".rank-math-answer").first();
          if ($ans.length) return $ans;
        }

        return $();
      },
    };

    // 1) Standard Accordions (Installation, Troubleshooting)
    $(document).on(
      "click keypress",
      ".seo-gen-accordion-trigger",
      function (e) {
        if (e.type === "keypress" && e.which !== 13 && e.which !== 32) return;
        e.preventDefault();

        var $trigger = $(this);
        AccordionController.toggle(
          $trigger,
          AccordionController.findContent($trigger),
          $trigger.closest(".seo-gen-accordion-block")
        );
      }
    );
    // 3) UI Buttons (Comparison/Alternatives)
    $(document).on("click keypress", ".seo-gen-accordion-toggle", function (e) {
      if (e.type === "keypress" && e.which !== 13 && e.which !== 32) return;
      e.preventDefault();

      var $trigger = $(this);
      AccordionController.toggle(
        $trigger,
        AccordionController.findContent($trigger),
        $trigger.closest(".seo-gen-accordion-block")
      );
    });

    // AUTO-OPEN (First FAQ)
    setTimeout(function () {
      var $first = $("#rank-math-faq, .wp-block-rank-math-faq-block")
        .first()
        .find(".rank-math-question")
        .first();
      if (
        $first.length &&
        !$first.hasClass("active") &&
        !window.seoGenNoAutoOpen
      ) {
        if ($first[0]) $first[0].click();
      }
    }, 500);
    // 4) Rank Math FAQ capture handler (bypasses stopPropagation)
    document.addEventListener(
      "click",
      function (e) {
        var el = e.target.closest(
          "#rank-math-faq .rank-math-question, .wp-block-rank-math-faq-block .rank-math-question"
        );
        if (!el) return;

        if (e.target.closest("a")) return;

        e.preventDefault();
        e.stopPropagation();

        var $trigger = jQuery(el);
        var $container = $trigger.closest(
          "#rank-math-faq, .wp-block-rank-math-faq-block, .rank-math-block"
        );

        AccordionController.toggle(
          $trigger,
          AccordionController.findContent($trigger),
          $container
        );
      },
      true // CAPTURE
    );
  });
})(jQuery);
