<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Logger;
use AiSocialCollage\Database\JobManager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class QueueHealthMonitor {

	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public function init() {
		// Hook the health check to native WP Cron (independent watchdog)
		add_action( 'ai_social_collage_native_health_check', [ $this, 'run_health_check' ] );
		
		// Hook the health check to admin_init with throttling to self-heal on admin load
		add_action( 'admin_init', [ $this, 'run_health_check_throttled' ] );
		
		// Register a custom 5-minute cron interval
		add_filter( 'cron_schedules', [ $this, 'add_cron_intervals' ] );
		
		// Schedule the native cron event on init
		add_action( 'init', [ $this, 'schedule_native_health_check' ] );

		// Register standalone REST endpoint for server-level cron health check
		add_action( 'rest_api_init', [ $this, 'register_rest_health_check' ] );
	}

	public function add_cron_intervals( $schedules ) {
		if ( ! isset( $schedules['every_minute'] ) ) {
			$schedules['every_minute'] = [
				'interval' => 60,
				'display'  => esc_html__( 'Every Minute', 'ai-social-collage' ),
			];
		}
		if ( ! isset( $schedules['every_5_minutes'] ) ) {
			$schedules['every_5_minutes'] = [
				'interval' => 300,
				'display'  => esc_html__( 'Every 5 Minutes', 'ai-social-collage' ),
			];
		}
		return $schedules;
	}

	public function schedule_native_health_check() {
		if ( ! wp_next_scheduled( 'ai_social_collage_native_health_check' ) ) {
			wp_schedule_event( time(), 'every_5_minutes', 'ai_social_collage_native_health_check' );
		}
	}

	public function run_health_check_throttled() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$last_run = get_transient( 'ai_collage_last_health_check' );
		if ( false !== $last_run ) {
			return;
		}
		set_transient( 'ai_collage_last_health_check', time(), 300 );
		$this->run_health_check();
	}

public function run_health_check() {
        $stats = [
            'stale_running' => 0,
            'orphaned_claims' => 0,
            'locks_cleared' => 0,
            'actions_unclaimed' => 0,
            'recurring_fixed' => 0,
            'as_queue_runner_active' => 0,
            'orphaned_jobs_reenqueued' => 0,
            'queue_forced' => 0,
            'auto_recovery' => 0,
            'cleanup_forced' => 0,
        ];

         $stats['stale_running'] = $this->fix_stale_running_actions();
         $stats['orphaned_claims'] = $this->fix_orphaned_claims();
         $stats['locks_cleared'] = $this->clear_as_locks();
         $stats['recurring_fixed'] = $this->ensure_recurring_actions_exist();
         $stats['as_queue_runner_active'] = $this->ensure_as_queue_runner_active();
         $stats['orphaned_jobs_reenqueued'] = $this->fix_orphaned_db_jobs();
         $stats['cleanup_forced'] = $this->ensure_cleanup_ran();

         $stats['auto_recovery'] = $this->auto_recover_stuck_pipeline();
         $this->maybe_quota_panic_recovery();

        if ( $this->force_queue_run() ) {
            $stats['queue_forced'] = 1;
        }

        if ( array_sum( $stats ) > 0 ) {
            Logger::info( 'queue_health_check_fixed', null, $stats, '200' );
        }

        return $stats;
    }

	public function fix_stale_running_actions() {
		global $wpdb;

		$timeout_minutes = 3;
		$as_table = $wpdb->prefix . 'actionscheduler_actions';
		$claims_table = $wpdb->prefix . 'actionscheduler_claims';

		if ( $wpdb->get_var( "SHOW TABLES LIKE '$as_table'" ) !== $as_table ) {
			return 0;
		}

		$hooks = [
			Config::ACTION_PROCESS_JOB,
			Config::ACTION_POLL_CAMPAIGNS,
			Config::ACTION_POLL_FEEDS,
			Config::ACTION_DAILY_CLEANUP,
			Config::ACTION_REFRESH_BUFFER_STATS,
		];
		$hook_placeholders = implode( ',', array_fill( 0, count( $hooks ), '%s' ) );

		$stuck_actions = $wpdb->get_results( $wpdb->prepare(
			"SELECT action_id, hook, args, claim_id, status FROM `$as_table` 
			 WHERE status IN (%s, %s)
			 AND hook IN ($hook_placeholders)
			 AND claim_id != 0 
			 AND last_attempt_gmt < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d MINUTE)",
			array_merge(
				[ \ActionScheduler_Store::STATUS_RUNNING, \ActionScheduler_Store::STATUS_PENDING ],
				$hooks,
				[ $timeout_minutes ]
			)
		) );

		if ( empty( $stuck_actions ) ) {
			return 0;
		}

		$fixed = 0;
		$orphan_claim_ids = [];
		foreach ( $stuck_actions as $action ) {
			$action_id = (int) $action->action_id;
			$hook = $action->hook;
			$args_str = $action->args;
			$status = $action->status;
			$job_id = null;

			if ( $hook === Config::ACTION_PROCESS_JOB && ! empty( $args_str ) ) {
				$args_data = json_decode( $args_str, true );
				if ( is_array( $args_data ) ) {
					$job_id = isset( $args_data['job_id'] ) ? (int) $args_data['job_id'] : ( isset( $args_data[0] ) ? (int) $args_data[0] : null );
				}
			}

			$update_data = [ 'claim_id' => 0 ];
			if ( $status === \ActionScheduler_Store::STATUS_RUNNING ) {
				$update_data['status'] = 'pending';
			}

			$wpdb->update(
				$as_table,
				$update_data,
				[ 'action_id' => $action_id ],
				[ '%d' ],
				[ '%d' ]
			);

			if ( $job_id ) {
				JobManager::update_status( $job_id, Config::STATUS_PENDING );
				delete_transient( 'ai_collage_job_lock_' . (int) $job_id );
			}

			$claim_id = (int) $action->claim_id;
			if ( $claim_id > 0 ) {
				$orphan_claim_ids[] = $claim_id;
			}

			$fixed++;
		}

		if ( ! empty( $orphan_claim_ids ) && $wpdb->get_var( "SHOW TABLES LIKE '$claims_table'" ) === $claims_table ) {
			$unique_claims = array_unique( $orphan_claim_ids );
			$claim_placeholders = implode( ',', array_fill( 0, count( $unique_claims ), '%d' ) );
			$wpdb->query( $wpdb->prepare(
				"DELETE FROM `$claims_table` WHERE claim_id IN ($claim_placeholders)",
				$unique_claims
			) );
		}

		if ( $fixed > 0 ) {
			Logger::warning( 'queue_stale_running_fixed', null, [
				'count' => $fixed,
				'timeout_minutes' => $timeout_minutes,
				'orphan_claims_deleted' => count( array_unique( $orphan_claim_ids ) ),
			], '200' );
		}

		return $fixed;
	}

	public function fix_orphaned_claims() {
		global $wpdb;

		$claims_table = $wpdb->prefix . 'actionscheduler_claims';
		$actions_table = $wpdb->prefix . 'actionscheduler_actions';

		if ( $wpdb->get_var( "SHOW TABLES LIKE '$claims_table'" ) !== $claims_table ) {
			return 0;
		}

		$orphaned = $wpdb->get_col(
			"SELECT c.claim_id FROM `$claims_table` c
			 LEFT JOIN `$actions_table` a ON c.claim_id = a.claim_id
			 WHERE a.action_id IS NULL"
		);

		if ( empty( $orphaned ) ) {
			return 0;
		}

		$deleted = 0;
		foreach ( $orphaned as $claim_id ) {
			$wpdb->delete(
				$claims_table,
				[ 'claim_id' => absint( $claim_id ) ],
				[ '%d' ]
			);
			$deleted++;
		}

		Logger::warning( 'queue_orphaned_claims_deleted', null, [
			'count' => $deleted,
		], '200' );

		return $deleted;
	}

	public function clear_as_locks() {
		$locks = [
			'action_scheduler_lock_async-request-runner',
			'action_scheduler_lock_queue_runner',
		];

		$cleared = 0;
		foreach ( $locks as $lock_name ) {
			$lock_expiration = get_option( $lock_name );
			if ( false !== $lock_expiration ) {
				$deleted = delete_option( $lock_name );
				if ( $deleted ) {
					$cleared++;
				}
			}
			$transient = get_transient( $lock_name );
			if ( false !== $transient ) {
				delete_transient( $lock_name );
				$cleared++;
			}
		}

		if ( $cleared > 0 ) {
			delete_transient( 'action_scheduler_run_queue' );
		}

		return $cleared;
	}

	public function ensure_recurring_actions_exist() {
		if ( ! function_exists( 'as_next_scheduled_action' ) || ! function_exists( 'as_schedule_recurring_action' ) ) {
			return 0;
		}

		$fixed = 0;

		$recurring = [
			[
				'hook' => Config::ACTION_POLL_CAMPAIGNS,
				'interval' => Config::CRON_POLL_INTERVAL,
				'args' => [],
				'enabled' => true,
			],
			[
				'hook' => Config::ACTION_POLL_FEEDS,
				'interval' => (int) get_option( Config::OPTION_RSS_FREQUENCY, 3600 ),
				'args' => [],
				'enabled' => (bool) get_option( Config::OPTION_RSS_ENABLED, false ),
			],
			[
				'hook' => Config::ACTION_DAILY_CLEANUP,
				'interval' => DAY_IN_SECONDS,
				'args' => [],
				'enabled' => true,
			],
			[
				'hook' => Config::ACTION_REFRESH_BUFFER_STATS,
				'interval' => 12 * HOUR_IN_SECONDS,
				'args' => [],
				'enabled' => (bool) get_option( Config::OPTION_BUFFER_ENABLED, false ),
			],
		];

		foreach ( $recurring as $action ) {
			$next = as_next_scheduled_action( $action['hook'], $action['args'], Config::AS_GROUP );
			if ( $action['enabled'] ) {
				if ( false === $next ) {
					as_schedule_recurring_action(
						time(),
						$action['interval'],
						$action['hook'],
						$action['args'],
						Config::AS_GROUP
					);
					$fixed++;
					Logger::warning( 'queue_recurring_action_reregistered', null, [
						'hook' => $action['hook'],
						'interval' => $action['interval'],
					], '200' );
				}
			} else {
				if ( false !== $next && function_exists( 'as_unschedule_action' ) ) {
					as_unschedule_action( $action['hook'], $action['args'], Config::AS_GROUP );
				}
			}
		}

		return $fixed;
	}

	public function fix_orphaned_db_jobs() {
		global $wpdb;

		$jobs_table = $wpdb->prefix . Config::TABLE_JOBS;
		$as_table = $wpdb->prefix . 'actionscheduler_actions';

		if ( $wpdb->get_var( "SHOW TABLES LIKE '$jobs_table'" ) !== $jobs_table ) {
			return 0;
		}
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$as_table'" ) !== $as_table ) {
			return 0;
		}

		$stuck_statuses = [ Config::STATUS_PENDING, Config::STATUS_REWRITING, Config::STATUS_RENDERING ];
		$placeholders = implode( ',', array_fill( 0, count( $stuck_statuses ), '%s' ) );

		// FIXED: Increased threshold from 2 to 5 minutes.
		// 2 minutes was too aggressive — with batch size 10 and multiple campaigns,
		// legitimate jobs were being re-queued before the runner could process them,
		// causing the orphaned_db_jobs_reenqueued warning loops seen in logs.
		$orphaned_jobs = $wpdb->get_results( $wpdb->prepare(
			"SELECT id, post_id, status FROM `$jobs_table`
			 WHERE status IN ($placeholders)
			   AND updated_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL 5 MINUTE)",
			array_merge( $stuck_statuses )
		) );

		if ( empty( $orphaned_jobs ) ) {
			return 0;
		}

		$reenqueued = 0;
		foreach ( $orphaned_jobs as $job ) {
			$job_id = (int) $job->id;

			// FIX: Only consider an AS action as "live" if it was scheduled
			// within the last 5 minutes. Actions pending longer than that
			// are effectively dead — the AS runner is not processing them.
			// Without this age check, stale AS actions shield orphaned DB
			// jobs from re-enqueue, causing the permanent PENDING stuck state.
			$live_action = $wpdb->get_var( $wpdb->prepare(
				"SELECT action_id FROM `$as_table`
				 WHERE hook = %s
				   AND status IN ('pending', 'in-progress')
				   AND scheduled_date_gmt > DATE_SUB(UTC_TIMESTAMP(), INTERVAL 5 MINUTE)
				   AND ( args LIKE %s OR args LIKE %s OR args LIKE %s )",
				Config::ACTION_PROCESS_JOB,
				'%"job_id":' . $job_id . '}',
				'%"job_id": ' . $job_id . '}',
				'%\'job_id\':' . $job_id . ';%'
			) );

			if ( $live_action ) {
				continue;
			}

			// Delete any stale AS action before re-enqueueing to prevent duplicates
			$wpdb->query( $wpdb->prepare(
				"DELETE FROM `$as_table`
				 WHERE hook = %s
				   AND status = 'pending'
				   AND scheduled_date_gmt < DATE_SUB(UTC_TIMESTAMP(), INTERVAL 5 MINUTE)
				   AND ( args LIKE %s OR args LIKE %s OR args LIKE %s )",
				Config::ACTION_PROCESS_JOB,
				'%"job_id":' . $job_id . '}',
				'%"job_id": ' . $job_id . '}',
				'%\'job_id\':' . $job_id . ';%'
			) );

			delete_transient( 'ai_collage_job_lock_' . $job_id );

			if ( function_exists( 'as_schedule_single_action' ) ) {
				$action_id = as_schedule_single_action(
					time(),
					Config::ACTION_PROCESS_JOB,
					[ 'job_id' => $job_id ],
					Config::AS_GROUP
				);

				if ( $action_id ) {
					$wpdb->update(
						$jobs_table,
						[
							'status' => Config::STATUS_PENDING,
							'updated_at' => gmdate( 'Y-m-d H:i:s' ),
						],
						[ 'id' => $job_id ],
						[ '%s', '%s' ],
						[ '%d' ]
					);

					$reenqueued++;
				}
			}
		}

		if ( $reenqueued > 0 ) {
			Logger::warning( 'queue_orphaned_db_jobs_reenqueued', null, [
				'count' => $reenqueued,
			], '200' );
		}

		return $reenqueued;
	}

	public function ensure_as_queue_runner_active() {
		if ( ! function_exists( 'wp_next_scheduled' ) || ! function_exists( 'wp_schedule_event' ) ) {
			return 0;
		}

		$fixed = 0;
		$cron_context = [ 'WP Cron' ];
		$as_cron_hook = 'action_scheduler_run_queue';

		if ( ! wp_next_scheduled( $as_cron_hook, $cron_context ) ) {
			wp_schedule_event( time(), 'every_minute', $as_cron_hook, $cron_context );
			$fixed++;
		}

		if ( ! wp_next_scheduled( 'action_scheduler_cleanup' ) ) {
			wp_schedule_event( time(), 'twicedaily', 'action_scheduler_cleanup' );
			$fixed++;
		}

		// DIRECT FIX: If WP Cron runner is not reliably firing, manually trigger
		// the Action Scheduler runner when there are overdue pending actions.
		// This catches the case where wp_schedule_event fires but AS runner doesn't execute.
		if ( function_exists( 'as_get_scheduled_actions' ) ) {
			$overdue = as_get_scheduled_actions(
				[
					'hook' => Config::ACTION_PROCESS_JOB,
					'status' => \ActionScheduler_Store::STATUS_PENDING,
				],
				'ids',
				Config::AS_GROUP
			);

			if ( count( $overdue ) > 0 ) {
				// Check if runner is actually running by looking at the transient lock
				$runner_lock = get_transient( 'action_scheduler_lock_queue_runner' );
				$runner_active = ( false !== $runner_lock && ( time() - (int) $runner_lock ) < 120 );

				if ( ! $runner_active ) {
					$this->clear_as_locks();
					if ( function_exists( 'do_action' ) ) {
						do_action( 'action_scheduler_run_queue', 'Health Monitor: Pending actions detected' );
						$fixed++;
						Logger::info( 'as_runner_manually_triggered', null, [
							'pending_count' => count( $overdue ),
						], '200' );
					}
				}
			}
		}

		if ( $fixed > 0 ) {
			Logger::warning( 'as_queue_runner_rescheduled', null, [], '200' );
		}

		return $fixed;
	}

	public function force_queue_run() {
		$forced_run_enabled = get_option( Config::OPTION_HEALTH_MONITOR_FORCED_RUN, '1' ) === '1';
		if ( ! $forced_run_enabled ) {
			return false;
		}

		// Always attempt direct background processing of stuck DB jobs.
		// This is the PRIMARY mechanism — it dispatches background REST requests
		// that each process one job in its own PHP process (no timeout).
		// The AS runner trigger below is a secondary attempt.
		$directly_processed = $this->process_pending_jobs_directly();
		if ( $directly_processed > 0 ) {
			Logger::info( 'direct_job_processing_triggered', null, [
				'jobs_dispatched' => $directly_processed,
			], '200' );
			return true;
		}

		// Secondary: try to kick the AS runner if it has pending actions
		if ( function_exists( 'as_get_scheduled_actions' ) ) {
			$hooks_to_check = [
				Config::ACTION_PROCESS_JOB,
				Config::ACTION_POLL_CAMPAIGNS,
				Config::ACTION_POLL_FEEDS,
				Config::ACTION_DAILY_CLEANUP,
				Config::ACTION_REFRESH_BUFFER_STATS,
			];

			$pending_count = 0;

			foreach ( $hooks_to_check as $hook ) {
				$pending = as_get_scheduled_actions(
					[
						'hook' => $hook,
						'status' => \ActionScheduler_Store::STATUS_PENDING,
					],
					'ids',
					Config::AS_GROUP
				);

				$count = count( $pending );
				if ( $count > 0 ) {
					$pending_count += $count;
					break;
				}
			}

			if ( $pending_count > 0 ) {
				$this->clear_as_locks();

				if ( function_exists( 'do_action' ) ) {
					do_action( 'action_scheduler_run_queue', 'Plugin Health Monitor' );
					Logger::info( 'queue_forced_run_executed', null, [
						'pending_actions' => $pending_count,
					], '200' );
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Watchdog for the daily cleanup deliverables (logs, source posts,
	 * generated posts & media, completed/failed jobs, temp files, social meta,
	 * Buffer drafts, API-call audit rows).
	 *
	 * The recurring ACTION_DAILY_CLEANUP hook is only EXISTENCE-checked by
	 * ensure_recurring_actions_exist(). This method also verifies it actually
	 * RAN recently: execute_cleanup() records a heartbeat (OPTION_LAST_CLEANUP_RUN,
	 * UTC). If the heartbeat is missing or older than ~25h, the cleanup is
	 * re-queued and the AS runner is force-triggered so the retention policy
	 * cannot be silently violated when the AS runner dies while the job queue
	 * is empty (the previous failure mode — cleanup only ran as a side-effect
	 * of a busy job queue).
	 */
	public function ensure_cleanup_ran(): int {
		$last = get_option( Config::OPTION_LAST_CLEANUP_RUN, '' );
		$overdue = false;

		if ( empty( $last ) ) {
			$overdue = true;
		} else {
			$ts = strtotime( $last . ' UTC' );
			if ( false === $ts || ( time() - $ts ) > ( DAY_IN_SECONDS + HOUR_IN_SECONDS ) ) {
				$overdue = true;
			}
		}

		if ( ! $overdue ) {
			return 0;
		}

		// The recurring ACTION_DAILY_CLEANUP exists but is anchored up to 24h in
		// the future, so the AS runner will NOT execute it on demand and
		// as_next_scheduled_action() always returns the next timestamp (never
		// false). We therefore must enqueue a SINGLE action scheduled NOW (which
		// is immediately due) — but only if one isn't already claimable
		// (scheduled_at <= now), otherwise every 5-min health check would pile
		// up duplicate actions. Note: a future-due recurring cleanup action is
		// stored as status=PENDING but has scheduled_at in the future; it will
		// NOT match the 'date <=' query below and therefore must not block us.
		$already_queued = false;
		if ( function_exists( 'as_get_scheduled_actions' ) ) {
			$pending = as_get_scheduled_actions(
				[
					'hook'     => Config::ACTION_DAILY_CLEANUP,
					'status'   => [ \ActionScheduler_Store::STATUS_PENDING, \ActionScheduler_Store::STATUS_RUNNING ],
					'date'     => 'now',
					'per_page' => 1,
				],
				'ids',
				Config::AS_GROUP
			);
			$already_queued = ! empty( $pending );
		}

		$fixed = 0;

		if ( ! $already_queued && function_exists( 'as_schedule_single_action' ) ) {
			as_schedule_single_action( time(), Config::ACTION_DAILY_CLEANUP, [], Config::AS_GROUP );
			$fixed++;
		}

		// Kick the AS runner so the now-due single action is claimed and
		// execute_cleanup() actually runs and records the heartbeat.
		$this->clear_as_locks();
		if ( function_exists( 'do_action' ) ) {
			do_action( 'action_scheduler_run_queue', 'Health Monitor: daily cleanup overdue' );
			$fixed++;
		}

		Logger::warning( 'cleanup_overdue_forced', null, [
			'last_run'       => $last,
			'already_queued' => $already_queued ? 1 : 0,
			'queued_now'     => $already_queued ? 0 : 1,
		], '200' );

		return $fixed;
	}

	/**
	 * Directly process pending jobs from the plugin's DB table, bypassing Action Scheduler.
	 * This is the nuclear option when AS runner is completely dead.
	 * Only processes jobs that are genuinely stuck (pending for > 3 minutes).
	 */
	private function process_pending_jobs_directly(): int {
		global $wpdb;

		$jobs_table = $wpdb->prefix . Config::TABLE_JOBS;

		$table_exists = $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = %s AND table_name = %s",
			$wpdb->dbname,
			$jobs_table
		) );

		if ( ! $table_exists ) {
			Logger::info( 'direct_processing_table_missing', null, [ 'table' => $jobs_table ], '404' );
			return 0;
		}

		$pending_jobs = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, post_id, created_at FROM `$jobs_table`
				 WHERE status = %s
				   AND created_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d MINUTE)
				 ORDER BY created_at ASC
				 LIMIT 1",
				Config::STATUS_PENDING,
				3
			)
		);

		if ( empty( $pending_jobs ) ) {
			Logger::info( 'direct_processing_no_stuck_jobs', null, [], '200' );
			return 0;
		}

		$job = $pending_jobs[0];
		$job_id = (int) $job->id;

		Logger::info( 'direct_processing_found_stuck', $job_id, [
			'created_at' => $job->created_at,
		], '200' );

		$lock_key = 'ai_collage_job_lock_' . $job_id;
		$lock_value = get_transient( $lock_key );
		if ( false !== $lock_value ) {
			// FIX: If lock is older than 5 minutes, it's stale — delete it
			$lock_age = time() - (int) $lock_value;
			if ( $lock_age < 300 ) {
				Logger::info( 'direct_processing_skip_locked', $job_id, [
					'lock_age_seconds' => $lock_age,
				], '429' );
				return 0;
			}
			Logger::info( 'direct_processing_stale_lock_deleted', $job_id, [
				'lock_age_seconds' => $lock_age,
			], '200' );
			delete_transient( $lock_key );
		}

		// FIX: Set up process isolation BEFORE logging/processing.
		// Do NOT call fastcgi_finish_request() — this runs from health check
		// context (admin_init / WP Cron), not an HTTP request.
		ignore_user_abort( true );
		if ( function_exists( 'set_time_limit' ) ) {
			@set_time_limit( 120 );
		}

		Logger::info( 'direct_processing_starting_sync', $job_id, [], '200' );

		do_action( Config::ACTION_PROCESS_JOB, $job_id );

		Logger::info( 'direct_processing_completed_sync', $job_id, [], '200' );

		$still_pending = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM `$jobs_table` WHERE status = %s AND created_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d MINUTE)",
				Config::STATUS_PENDING,
				3
			)
		);

		if ( $still_pending > 0 && function_exists( 'wp_schedule_single_event' ) ) {
			wp_schedule_single_event( time() + 10, 'ai_social_collage_native_health_check' );
		}

		return 1;
	}

 	/**
	 * Detect quota-panic state where NO provider can possibly process a job.
	 * Uses the same availability logic as the fallback chain builder
	 * (get_available_providers) so providers with fallback_enabled=false
	 * are correctly excluded. Triggers when zero providers are usable,
	 * including the case where all are daily-quota-blocked.
	 */
	public function maybe_quota_panic_recovery(): int {
		if ( false === get_transient( 'ai_collage_quota_panic_window' ) ) {
			return 0;
		}

		$providers = array_keys( Config::get_registered_providers() );
		$can_process = 0;
		$daily_blocked = 0;
		$hard_blocked = 0;
		$fallback_disabled = 0;
		foreach ( $providers as $p ) {
			$has_key = Config::has_valid_api_key( $p );
			if ( ! $has_key ) {
				$hard_blocked++;
				continue;
			}
			if ( ProviderCooldown::is_misconfigured( $p ) ) {
				$hard_blocked++;
				continue;
			}
			if ( ProviderCooldown::is_daily_quota_blocked( $p ) ) {
				$daily_blocked++;
				continue;
			}
			if ( ProviderCooldown::is_in_cooldown( $p ) ) {
				$hard_blocked++;
				continue;
			}
			if ( ! QuotaStateManager::can_make_request( $p ) ) {
				$hard_blocked++;
				continue;
			}
			if ( Config::is_custom_provider( $p ) ) {
				$profile = Config::get_custom_profile( $p );
				if ( is_array( $profile ) && empty( $profile['fallback_enabled'] ) ) {
					$fallback_disabled++;
					continue;
				}
			}
			$can_process++;
		}

		if ( $can_process > 0 ) {
			return 0;
		}

		$panic_needed = true;

		$last_attempt = (int) get_transient( 'ai_collage_quota_panic_last_recovery' );
		if ( $last_attempt > 0 && ( time() - $last_attempt ) < 180 ) {
			return 0;
		}
		set_transient( 'ai_collage_quota_panic_last_recovery', time(), 180 );

		Logger::warning( 'quota_panic_recovery_triggered', null, [
			'providers_total'    => count( $providers ),
			'can_process'        => $can_process,
			'daily_blocked'      => $daily_blocked,
			'hard_blocked'       => $hard_blocked,
			'fallback_disabled'  => $fallback_disabled,
		], '200' );

		foreach ( $providers as $p ) {
			if ( ! Config::has_valid_api_key( $p ) ) {
				ProviderCooldown::mark_misconfigured( $p );
				continue;
			}
			ProviderCooldown::reset_provider( $p );
		}

		QuotaStateManager::reset_all();

		global $wpdb;
		$jobs_table = $wpdb->prefix . Config::TABLE_JOBS;
		if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $jobs_table ) ) === $jobs_table ) {
			$stuck_jobs = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT id, post_id FROM `$jobs_table` WHERE status = %s",
					Config::STATUS_PENDING
				)
			);
			foreach ( (array) $stuck_jobs as $sj ) {
				$job_id = (int) $sj->id;
				delete_transient( 'ai_collage_job_lock_' . $job_id );
				delete_transient( 'ai_collage_queued_recent_' . (int) $sj->post_id );
				if ( function_exists( 'as_schedule_single_action' )
					&& ! \AiSocialCollage\Actions\QueueProcessor::check_pending_action_for_job( $job_id, 300 ) ) {
					as_schedule_single_action(
						time(),
						Config::ACTION_PROCESS_JOB,
						[ 'job_id' => $job_id ],
						Config::AS_GROUP
					);
					$wpdb->update(
						$jobs_table,
						[ 'updated_at' => gmdate( 'Y-m-d H:i:s' ) ],
						[ 'id' => $job_id ],
						[ '%s' ],
						[ '%d' ]
					);
				}
			}
		}

		$this->clear_as_locks();
		if ( function_exists( 'do_action' ) ) {
			do_action( 'action_scheduler_run_queue', 'Quota Panic Recovery' );
		}

		Logger::warning( 'quota_panic_recovery_completed', null, [], '200' );
		return 1;
	}

	/**
	 * Auto-recover stuck pipeline by replicating what the manual System Reset does,
	 * but only when jobs have been genuinely stuck for > 15 minutes.
	 *
	 * This is the key missing piece: after API errors, providers get cooldown'd
	 * and quota counters fill up. No provider can process jobs. The health check
	 * must reset these states to restore normal operation.
	 */
 	private function auto_recover_stuck_pipeline(): int {
		global $wpdb;

		$jobs_table = $wpdb->prefix . Config::TABLE_JOBS;
		if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $jobs_table ) ) !== $jobs_table ) {
			return 0;
		}

 		$pending_count = (int) $wpdb->get_var(
 			$wpdb->prepare(
 				"SELECT COUNT(*) FROM `$jobs_table` WHERE status = %s AND created_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d MINUTE)",
 				Config::STATUS_PENDING,
 				5
 			)
 		);

 		if ( $pending_count === 0 ) {
 			return 0;
 		}

 		$last_recovery = get_transient( 'ai_collage_last_auto_recovery' );
 		if ( false !== $last_recovery && ( time() - (int) $last_recovery ) < 300 ) {
 			// Throttled. The previous patch preserved daily-quota state, but
 			// we still need to ensure pending jobs actually got re-enqueued.
 			// Re-enqueue stuck pending jobs even when recovery throttling is
 			// active, so they don't sit in the queue for >15 minutes.
 			$this->reenqueue_stuck_pending_jobs( $jobs_table, $pending_count );
 			return 0;
 		}
 		set_transient( 'ai_collage_last_auto_recovery', time(), 300 );

		Logger::warning( 'auto_recovery_triggered', null, [
			'pending_stuck_count' => $pending_count,
		], '200' );

		$recovered = 0;

		// 1. Reset provider cooldowns — PRESERVE daily-quota blocks UNLESS
		// doing so would leave zero usable providers (pipeline deadlock).
		// When ALL providers that could appear in the fallback chain are
		// daily-blocked, we must clear them to unblock the pipeline.
		if ( class_exists( '\AiSocialCollage\Services\ProviderCooldown' ) ) {
			$registered_providers = array_keys( Config::get_registered_providers() );
			$daily_blocked_providers = [];
			$usable_after_reset = 0;

			foreach ( $registered_providers as $provider_name ) {
				if ( \AiSocialCollage\Services\ProviderCooldown::is_daily_quota_blocked( $provider_name ) ) {
					$daily_blocked_providers[] = $provider_name;
					continue;
				}
				\AiSocialCollage\Services\ProviderCooldown::reset_provider( $provider_name );

				if ( $this->is_provider_usable_in_chain( $provider_name ) ) {
					$usable_after_reset++;
				}
			}

			if ( $usable_after_reset === 0 && ! empty( $daily_blocked_providers ) ) {
				foreach ( $daily_blocked_providers as $provider_name ) {
					\AiSocialCollage\Services\ProviderCooldown::reset_provider( $provider_name );
					Logger::warning( 'auto_recovery_reset_daily_quota_deadlock', null, [
						'provider' => $provider_name,
					], '200' );
				}
			} else {
				foreach ( $daily_blocked_providers as $provider_name ) {
					Logger::info( 'auto_recovery_preserved_daily_quota', null, [
						'provider' => $provider_name,
						'remaining' => \AiSocialCollage\Services\ProviderCooldown::get_daily_quota_remaining( $provider_name ),
					], '200' );
				}
			}
			$recovered++;
		}

		// 2. Reset quota state
		if ( class_exists( '\AiSocialCollage\Services\QuotaStateManager' ) ) {
			\AiSocialCollage\Services\QuotaStateManager::reset_all();
			$recovered++;
		}

		// 3. Clear pipeline pause
		$pipeline_paused = (bool) get_option( Config::OPTION_PIPELINE_PAUSED, false );
		if ( $pipeline_paused ) {
			update_option( Config::OPTION_PIPELINE_PAUSED, false );
			if ( function_exists( 'wp_cache_delete' ) ) {
				wp_cache_delete( 'alloptions', 'options' );
			}
			$recovered++;
		}

		// 4. Clear ALL queued_recent transients (stale deduplication guards)
		$wpdb->query(
			"DELETE FROM `{$wpdb->options}` WHERE option_name LIKE '_transient_ai_collage_queued_recent_%' OR option_name LIKE '_transient_timeout_ai_collage_queued_recent_%'"
		);

		// 5. Clear job locks and re-enqueue stuck pending jobs
 		$stuck_jobs = $wpdb->get_results(
 			$wpdb->prepare(
 				"SELECT id, post_id FROM `$jobs_table` WHERE status = %s AND created_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d MINUTE)",
 				Config::STATUS_PENDING,
 				5
 			)
 		);

		if ( ! empty( $stuck_jobs ) && function_exists( 'as_schedule_single_action' ) ) {
			foreach ( $stuck_jobs as $job ) {
				$job_id = (int) $job->id;

				delete_transient( 'ai_collage_job_lock_' . $job_id );
				delete_transient( 'ai_collage_queued_recent_' . (int) $job->post_id );

			// FIX: Pass 300s max age — stale AS actions should not block re-enqueue
			if ( \AiSocialCollage\Actions\QueueProcessor::check_pending_action_for_job( $job_id, 300 ) ) {
				continue;
			}

			$action_id = as_schedule_single_action(
					time(),
					Config::ACTION_PROCESS_JOB,
					[ 'job_id' => $job_id ],
					Config::AS_GROUP
				);

				if ( $action_id ) {
					$wpdb->update(
						$jobs_table,
						[ 'updated_at' => gmdate( 'Y-m-d H:i:s' ) ],
						[ 'id' => $job_id ],
						[ '%s' ],
						[ '%d' ]
					);
					$recovered++;
				}
			}
		}

		// 6. Clear stale AS locks and trigger runner
		$this->clear_as_locks();
		if ( function_exists( 'do_action' ) ) {
			do_action( 'action_scheduler_run_queue', 'Auto Recovery: Pipeline stuck' );
		}

		if ( $recovered > 0 ) {
			Logger::warning( 'auto_recovery_completed', null, [
				'actions_taken' => $recovered,
				'pending_jobs_found' => count( $stuck_jobs ?? [] ),
			], '200' );
		}

		return $recovered;
	}

	/**
	 * Re-enqueue any pending jobs older than 7 minutes that have no live
	 * Action Scheduler action. This is the safety net invoked during the
	 * throttled window of auto_recover_stuck_pipeline(): even when the full
	 * recovery routine is gated by the 5-min throttle, we still ensure that
	 * genuinely stuck jobs get fresh AS actions so they don't sit untouched
	 * for hours.
	 *
	 * Evidence: 2026-06-30 logs showed jobs 71069 and 71079 sitting in
	 * status=pending for 25+ minutes with no fallback_chain_initiated.
	 */
	private function reenqueue_stuck_pending_jobs( string $jobs_table, int $expected ): int {
		global $wpdb;

		$stuck_jobs = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, post_id FROM `$jobs_table` WHERE status = %s AND created_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL %d MINUTE)",
				Config::STATUS_PENDING,
				7
			)
		);

		if ( empty( $stuck_jobs ) ) {
			return 0;
		}

		$requeued = 0;
		foreach ( $stuck_jobs as $job ) {
			$job_id = (int) $job->id;

			delete_transient( 'ai_collage_job_lock_' . $job_id );
			delete_transient( 'ai_collage_queued_recent_' . (int) $job->post_id );

			// FIX: Pass 300s max age so stale AS actions (pending >5min) are not
			// treated as live. Without this, dead AS actions shield orphaned jobs.
			if ( \AiSocialCollage\Actions\QueueProcessor::check_pending_action_for_job( $job_id, 300 ) ) {
				continue;
			}

			$action_id = function_exists( 'as_schedule_single_action' ) ? as_schedule_single_action(
				time(),
				Config::ACTION_PROCESS_JOB,
				[ 'job_id' => $job_id ],
				Config::AS_GROUP
			) : null;

			if ( $action_id ) {
				$wpdb->update(
					$jobs_table,
					[ 'updated_at' => gmdate( 'Y-m-d H:i:s' ) ],
					[ 'id' => $job_id ],
					[ '%s' ],
					[ '%d' ]
				);
				$requeued++;
			}
		}

		if ( $requeued > 0 ) {
			Logger::warning( 'auto_recovery_throttled_reenqueue', null, [
				'jobs_reenqueued' => $requeued,
				'expected_pending' => $expected,
			], '200' );
		}

		return $requeued;
	}

	// ── Standalone REST health check endpoint ────────────────────────────────

	public function register_rest_health_check() {
		register_rest_route(
			'ai-collage/v1',
			'/health-check',
			[
				'methods'             => 'GET',
				'callback'            => [ $this, 'rest_health_check_handler' ],
				'permission_callback' => '__return_true',
				'args'                => [
					'token' => [
						'required' => true,
						'type'     => 'string',
					],
				],
			]
		);

		register_rest_route(
			'ai-collage/v1',
			'/run-job',
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'rest_run_job_handler' ],
				'permission_callback' => '__return_true',
				'args'                => [
					'token' => [
						'required' => true,
						'type'     => 'string',
					],
					'job_id' => [
						'required' => true,
						'type'     => 'integer',
					],
				],
			]
		);
	}

	public function rest_run_job_handler( \WP_REST_Request $request ) {
		$token = $request->get_param( 'token' );
		$valid_token = get_option( 'ai_collage_health_check_token', '' );

		if ( empty( $valid_token ) || ! hash_equals( $valid_token, $token ) ) {
			return new \WP_REST_Response( [ 'error' => 'Invalid token' ], 403 );
		}

		$job_id = (int) $request->get_param( 'job_id' );
		if ( $job_id <= 0 ) {
			return new \WP_REST_Response( [ 'error' => 'Invalid job_id' ], 400 );
		}

		Logger::info( 'rest_run_job_received', $job_id, [], '200' );

		do_action( Config::ACTION_PROCESS_JOB, $job_id );

		return new \WP_REST_Response( [ 'status' => 'processed', 'job_id' => $job_id ], 200 );
	}

	public function rest_health_check_handler( \WP_REST_Request $request ) {
		$token = $request->get_param( 'token' );
		$valid_token = get_option( 'ai_collage_health_check_token', '' );

		if ( empty( $valid_token ) || ! hash_equals( $valid_token, $token ) ) {
			return new \WP_REST_Response( [ 'error' => 'Invalid token' ], 403 );
		}

		$stats = $this->run_health_check();

		$force_recovered = $this->force_recover_stuck_jobs();

		$summary = [
			'status'         => array_sum( $stats ) > 0 || $force_recovered > 0 ? 'fixed' : 'ok',
			'fixed'          => array_sum( $stats ),
			'force_recovered' => $force_recovered,
			'details'        => $stats,
			'time'           => current_time( 'mysql' ),
		];

		Logger::info( 'rest_health_check_executed', null, $summary, '200' );

		return new \WP_REST_Response( $summary, 200 );
	}

	public static function get_or_create_health_check_token(): string {
		$token = get_option( 'ai_collage_health_check_token', '' );
		if ( empty( $token ) ) {
			$token = wp_generate_password( 32, false );
			update_option( 'ai_collage_health_check_token', $token, false );
		}
		return $token;
	}

	/**
	 * Direct DB-level stuck job recovery — bypasses Action Scheduler entirely.
	 * Callable from WP-CLI or REST endpoint even when AS queue runner is dead.
	 */
	public function force_recover_stuck_jobs(): int {
		global $wpdb;

		$jobs_table = $wpdb->prefix . Config::TABLE_JOBS;
		if ( $wpdb->get_var( "SHOW TABLES LIKE '$jobs_table'" ) !== $jobs_table ) {
			return 0;
		}

		$stuck_statuses = [ Config::STATUS_REWRITING, Config::STATUS_RENDERING ];
		$placeholders = implode( ',', array_fill( 0, count( $stuck_statuses ), '%s' ) );

		$stuck_jobs = $wpdb->get_results( $wpdb->prepare(
			"SELECT id, post_id, status, updated_at FROM `$jobs_table`
			 WHERE status IN ($placeholders)
			   AND updated_at < DATE_SUB(UTC_TIMESTAMP(), INTERVAL 5 MINUTE)",
			array_merge( $stuck_statuses )
		) );

		if ( empty( $stuck_jobs ) ) {
			return 0;
		}

		$recovered = 0;
		foreach ( $stuck_jobs as $job ) {
			$job_id = (int) $job->id;

			delete_transient( 'ai_collage_job_lock_' . $job_id );

			$wpdb->update(
				$jobs_table,
				[
					'status'     => Config::STATUS_FAILED,
					'updated_at' => gmdate( 'Y-m-d H:i:s' ),
				],
				[ 'id' => $job_id ],
				[ '%s', '%s' ],
				[ '%d' ]
			);

			$recovered++;
		}

		if ( $recovered > 0 ) {
			Logger::warning( 'rest_stuck_jobs_force_recovered', null, [
				'count' => $recovered,
			], '200' );
		}

		return $recovered;
	}

	/**
	 * Check if a provider would appear in the fallback chain.
	 * Mirrors the filtering logic in AIProviderRegistry::get_available_providers().
	 */
	private function is_provider_usable_in_chain( string $provider_name ): bool {
		if ( ! Config::has_valid_api_key( $provider_name ) ) {
			return false;
		}
		if ( ProviderCooldown::is_misconfigured( $provider_name ) ) {
			return false;
		}
		if ( ProviderCooldown::is_daily_quota_blocked( $provider_name ) ) {
			return false;
		}
		if ( Config::is_custom_provider( $provider_name ) ) {
			$profile = Config::get_custom_profile( $provider_name );
			if ( is_array( $profile ) && empty( $profile['fallback_enabled'] ) ) {
				return false;
			}
		}
		return true;
	}
}