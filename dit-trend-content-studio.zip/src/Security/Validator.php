<?php

/**
 * Validator
 *
 * @package DIT_TrendStudio
 * @MODIFIED 2025-12-13 - Minimal structural validation only, no scoring
 * @MODIFIED 2025-12-18 - Elite Quality Suite integration: weighted scoring and truth enforcement.
 * @MODIFIED 2025-12-18 - softened gates to advisories (user decision mode).
 * @MODIFIED 2025-12-27 - Added content blocks and SEO keyword validation
 */

namespace DIT\TrendStudio\Security;

use DIT\TrendStudio\Schema\Content_Schema;
use DIT\TrendStudio\Schema\Content_Blocks;
use DIT\TrendStudio\Infrastructure\Logger;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Validates magazine article structure and quality using the Elite Quality Suite.
 */
class Validator
{
    /**
     * Logger instance
     */
    private Logger $logger;

    /**
     * Scoring Engine instance
     */
    private Scoring_Engine $scoring_engine;

    /**
     * Constructor
     *
     * @param Logger $logger Logger instance
     */
    public function __construct(Logger $logger)
    {
        $this->logger = $logger;
        $this->scoring_engine = new Scoring_Engine();
    }

    /**
     * Validate article data with weighted scoring.
     * @MODIFIED 2025-12-27 - Added content blocks and SEO keyword validation
     *
     * @param array $article Article data array
     * @return array Validation results
     */
    public function validate(array $article): array
    {
        $schema = Content_Schema::from_array($article);
        $mode = get_option('dit_ts_content_mode', 'editorial');

        // 1. Run Weighted Scoring Engine
        $audit = $this->scoring_engine->calculate($schema, $mode);

        $errors = array();
        $warnings = array();

        // 2. Map Audit Issues to Warnings
        foreach ($audit['breakdown'] as $category => $data) {
            foreach ($data['issues'] as $issue) {
                $warnings[] = sprintf('[%s] %s', ucfirst($category), $issue);
            }
        }

        // 3. Editorial Quality Advisories (Softened from Phase 6 Hard Gates)

        // Truth Advisory: Warn if 0 citations in an editorial post
        if (empty($schema->sources) && $mode === 'editorial') {
            $warnings[] = 'QUALITY ADVISORY: Editorial articles strongly recommend official sources. Zero citations may affect credibility.';
        }

        // Structural Hard Gates
        // @MODIFIED 2026-06-07 - Empty headline or zero sections are hard-fail conditions.
        // Prevents corrupted best-effort payloads from reaching auto-publish.
        if (empty($schema->headline) || strlen($schema->headline) < 15) {
            $errors[] = 'STRUCTURAL GATE: Headline is missing or too short for publication.';
        }

        if (count($schema->sections) < 1) {
            $errors[] = 'STRUCTURAL GATE: Article has zero sections. Cannot publish.';
        }

        if (count($schema->sections) >= 1 && count($schema->sections) < 3) {
            $warnings[] = 'STRUCTURAL ADVISORY: Article has low depth (min 3 sections recommended for elite indexing).';
        }

        // 4. Quality Threshold Enforcement
        if ($audit['score'] < $audit['threshold']) {
            $warnings[] = sprintf('CONFORMITY: Article score (%d) is below the recommended %s quality threshold (%d).', $audit['score'], $mode, $audit['threshold']);
        }

        // 5. Content Blocks Validation (rankability)
        if (!empty($schema->content_blocks)) {
            $blocks_result = Content_Blocks::validate($schema->content_blocks, $schema->vertical);
            foreach ($blocks_result['errors'] as $block_error) {
                $warnings[] = sprintf('[RANKABILITY] %s', $block_error);
            }
            foreach ($blocks_result['warnings'] as $block_warning) {
                $warnings[] = sprintf('[RANKABILITY] %s', $block_warning);
            }
        } else {
            // No content blocks generated at all - list specific required blocks
            $required = Content_Blocks::get_required_blocks($schema->vertical);
            $missing_names = array_keys(array_filter($required, fn($b) => $b['required']));
            if (!empty($missing_names)) {
                $warnings[] = sprintf(
                    '[RANKABILITY] Missing required blocks for %s: %s',
                    $schema->vertical,
                    implode(', ', $missing_names)
                );
            }
        }

        // 6. SEO Keyword Validation (soft warnings)
        $primary_keyword = $article['primary_keyword'] ?? '';
        if (!empty($primary_keyword)) {
            $keyword_lower = mb_strtolower($primary_keyword);

            // Check headline
            if (mb_strpos(mb_strtolower($schema->headline), $keyword_lower) === false) {
                $warnings[] = sprintf('[SEO] Primary keyword "%s" not found in headline', $primary_keyword);
            }

            // Check meta description
            if (mb_strpos(mb_strtolower($schema->meta_description), $keyword_lower) === false) {
                $warnings[] = sprintf('[SEO] Primary keyword "%s" not found in meta description', $primary_keyword);
            }

            // Check first 100 words
            $first_section_text = '';
            if (!empty($schema->sections[0]['body_html'])) {
                $first_section_text = wp_strip_all_tags($schema->sections[0]['body_html']);
            }
            $first_100_words = implode(' ', array_slice(str_word_count($first_section_text, 1), 0, 100));
            if (mb_strpos(mb_strtolower($first_100_words), $keyword_lower) === false) {
                $warnings[] = sprintf('[SEO] Primary keyword "%s" not found in first 100 words', $primary_keyword);
            }
        }

        // Overall pass/fail: FAIL if any structural hard gates triggered
        // @MODIFIED 2026-06-07 - Structural gates (empty headline, zero sections) now produce errors
        // that block publication. SEO/depth advisories remain as warnings.
        $passed = empty($errors);

        $this->logger->info('Elite Validation completed (Warning-only mode)', array(
            'passed' => $passed,
            'score' => $audit['score'],
            'errors' => count($errors),
            'warnings' => count($warnings),
        ));

        return array(
            'passed'    => $passed,
            'score'     => $audit['score'],
            'errors'    => $errors,
            'warnings'  => $warnings,
            'breakdown' => $audit['breakdown'], // Pass breakdown for UI rendering
        );
    }
}
