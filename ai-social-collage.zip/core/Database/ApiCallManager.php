<?php
namespace AiSocialCollage\Database;

use AiSocialCollage\Config;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ApiCallManager {

	public static function create_call( array $data ) {
		global $wpdb;
		$table = $wpdb->prefix . Config::TABLE_API_CALLS;

		$result = $wpdb->insert( $table, [
			'job_id' => (int) ( $data['job_id'] ?? 0 ) ?: null,
			'provider' => sanitize_text_field( $data['provider'] ?? '' ),
			'model' => sanitize_text_field( $data['model'] ?? '' ),
			'request_hash' => sanitize_text_field( $data['request_hash'] ?? '' ),
			'request_payload' => maybe_serialize( $data['request_payload'] ?? '' ),
			'response_code' => sanitize_text_field( $data['response_code'] ?? '' ),
			'response_body' => maybe_serialize( $data['response_body'] ?? '' ),
			'token_count_input' => (int) ( $data['token_count_input'] ?? 0 ) ?: null,
			'token_count_output' => (int) ( $data['token_count_output'] ?? 0 ) ?: null,
			'execution_time' => (float) ( $data['execution_time'] ?? 0.0 ),
			'quota_allowed' => ! empty( $data['quota_allowed'] ) ? 1 : 0,
			'status' => sanitize_text_field( $data['status'] ?? Config::API_CALL_PENDING ),
			'caller_context' => sanitize_text_field( $data['caller_context'] ?? '' ),
			'created_at' => current_time( 'mysql' ),
		], [ '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%f', '%d', '%s', '%s', '%s' ] );

		if ( $result === false ) {
			return false;
		}

		return $wpdb->insert_id;
	}

	public static function update_call( $call_id, array $data ) {
		global $wpdb;
		$table = $wpdb->prefix . Config::TABLE_API_CALLS;

		$fields = [];
		$format = [];
		$mappings = [
			'response_code' => [ 'val' => $data['response_code'] ?? null, 'fmt' => '%s' ],
			'response_body' => [ 'val' => $data['response_body'] ?? null, 'fmt' => '%s' ],
			'token_count_input' => [ 'val' => $data['token_count_input'] ?? null, 'fmt' => '%d' ],
			'token_count_output' => [ 'val' => $data['token_count_output'] ?? null, 'fmt' => '%d' ],
			'execution_time' => [ 'val' => $data['execution_time'] ?? null, 'fmt' => '%f' ],
			'status' => [ 'val' => $data['status'] ?? null, 'fmt' => '%s' ],
		];

		foreach ( $mappings as $col => $spec ) {
			if ( $spec['val'] !== null ) {
				$fields[ $col ] = $spec['val'];
				$format[] = $spec['fmt'];
			}
		}

		if ( empty( $fields ) ) {
			return;
		}

		$format[] = '%d';
		$wpdb->update( $table, $fields, [ 'id' => (int) $call_id ], $format, [ '%d' ] );
	}

	public static function get_call( $call_id ) {
		global $wpdb;
		$table = $wpdb->prefix . Config::TABLE_API_CALLS;
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `$table` WHERE id = %d", (int) $call_id ) );
	}

	public static function get_calls_for_job( $job_id ) {
		global $wpdb;
		$table = $wpdb->prefix . Config::TABLE_API_CALLS;
		return $wpdb->get_results( $wpdb->prepare( "SELECT * FROM `$table` WHERE job_id = %d ORDER BY created_at DESC", (int) $job_id ) );
	}

	public static function get_provider_counts( $days = 7 ) {
		global $wpdb;
		$table = $wpdb->prefix . Config::TABLE_API_CALLS;
		return $wpdb->get_results( $wpdb->prepare(
			"SELECT provider, status, COUNT(*) as cnt FROM `$table` WHERE created_at >= DATE_SUB(NOW(), INTERVAL %d DAY) GROUP BY provider, status",
			$days
		) );
	}

	public static function get_summary_stats() {
		global $wpdb;
		$table = $wpdb->prefix . Config::TABLE_API_CALLS;

		if ( $wpdb->get_var( "SHOW TABLES LIKE '$table'" ) !== $table ) {
			return [ 'total' => 0, 'success' => 0, 'failed' => 0, 'blocked' => 0, 'total_input_tokens' => 0, 'total_output_tokens' => 0, 'avg_exec' => 0, 'by_provider' => [] ];
		}

		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM `$table`" );
		$success = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `$table` WHERE status = %s", Config::API_CALL_SUCCESS ) );
		$failed = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `$table` WHERE status = %s", Config::API_CALL_FAILED ) );
		$blocked = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `$table` WHERE status = %s", Config::API_CALL_BLOCKED ) );
		$total_input_tokens = (int) $wpdb->get_var( "SELECT COALESCE(SUM(token_count_input), 0) FROM `$table`" );
		$total_output_tokens = (int) $wpdb->get_var( "SELECT COALESCE(SUM(token_count_output), 0) FROM `$table`" );
		$avg_exec = (float) $wpdb->get_var( "SELECT AVG(execution_time) FROM `$table` WHERE execution_time > 0" );

		$by_provider = [];
		$rows = $wpdb->get_results( "SELECT provider, COUNT(*) as cnt FROM `$table` GROUP BY provider" );
		foreach ( $rows as $row ) {
			$by_provider[ $row->provider ] = (int) $row->cnt;
		}

		return compact( 'total', 'success', 'failed', 'blocked', 'total_input_tokens', 'total_output_tokens', 'avg_exec', 'by_provider' );
	}

public static function hash_request( $provider, $payload ) {
		return hash( 'sha256', $provider . '|' . wp_json_encode( $payload ) );
	}

    public static function request_hash_exists( $request_hash ) {
        global $wpdb;
        $table = $wpdb->prefix . Config::TABLE_API_CALLS;
        $count = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM `$table` WHERE request_hash = %s", $request_hash ) );
        return $count > 0;
    }

    public static function get_call_by_hash( $request_hash ) {
        global $wpdb;
        $table = $wpdb->prefix . Config::TABLE_API_CALLS;
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM `$table` WHERE request_hash = %s ORDER BY id DESC LIMIT 1", $request_hash ) );
    }

    public static function mark_call_superseded( $call_id ) {
        global $wpdb;
        $table = $wpdb->prefix . Config::TABLE_API_CALLS;
        $wpdb->update( $table, [ 'status' => 'superseded' ], [ 'id' => (int) $call_id ], [ '%s' ] );
    }

    public static function purge_old_calls( $days ) {
        global $wpdb;
        $table = $wpdb->prefix . Config::TABLE_API_CALLS;
        return (int) $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM `$table` WHERE created_at < DATE_SUB(NOW(), INTERVAL %d DAY)",
                (int) $days
            )
        );
    }
}
