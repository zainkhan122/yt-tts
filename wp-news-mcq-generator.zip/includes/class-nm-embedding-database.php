<?php

/**
 * Custom Database Table for Fast Embedding Storage & Retrieval
 * Version: 1.4.0 - Added AJAX Stats Refresh
 * * @MODIFIED: Ported V23 UI for a more comprehensive admin page.
 *
 * @MODIFIED: Added refreshStatsCard() JS function to dynamically update
 * the stats card on page load and after backfill completion.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class NM_Embedding_Database {


	private $table_name;
	private $cache        = array();
	private $cache_loaded = false;

	/**
	 * Initialize hooks
	 */
		/**
		 * Initialize hooks
		 */
	public static function init() {
		// Register the submenu page
		add_action( 'admin_menu', array( self::class, 'register_submenu' ), 18 );

		// Automatically generate embeddings for new/updated MCQs.
		add_action( 'save_post_mcq', array( self::class, 'maybe_generate_embedding_on_save' ), 20, 3 );

		// Cron worker hook: processes one MCQ without an embedding per run.
		// The actual schedule (how often it runs) should be managed by your central cron manager.
		add_action( 'nm_embedding_backfill_cron', array( self::class, 'run_embedding_backfill_cron' ) );
	}

	/**
	 * Register the submenu page
	 */
	public static function register_submenu() {
		add_submenu_page(
			'nm_mcq_generator',
			'Embeddings',
			'🔄 Embeddings',
			'manage_options',
			'nm_migrate_embeddings',
			array( self::class, 'render_page' )
		);
	}

	public function __construct() {
		global $wpdb;
		$this->table_name = $wpdb->prefix . 'mcq_embeddings';
	}

		/**
		 * Create or upgrade the embeddings table on plugin activation.
		 *
		 * This is idempotent and will:
		 * - Create the table if missing.
		 * - Ensure the canonical `embedding_model` column exists.
		 * - Rename an old `embeddingmodel` column to `embedding_model` if found.
		 */
	public function create_table() {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$this->table_name} (
            id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            post_id bigint(20) UNSIGNED NOT NULL,
            embedding_hash varchar(64) NOT NULL,
            embedding longtext NOT NULL,
            embedding_model varchar(64) NOT NULL DEFAULT '',
            question_text text NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY post_id (post_id),
            KEY embedding_hash (embedding_hash),
            KEY created_at (created_at)
        ) {$charset_collate};";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );

		// -----------------------------------------------------------------
		// Ensure the embedding_model column exists for all installs.
		// Also handle legacy installs that used `embeddingmodel`
		// (no underscore) by renaming that column in-place.
		// -----------------------------------------------------------------
		$schema = DB_NAME;
		$table  = $this->table_name;

		// Check for canonical column name.
		$has_embedding_model = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*)
                 FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = %s
                   AND TABLE_NAME   = %s
                   AND COLUMN_NAME  = 'embedding_model'",
				$schema,
				$table
			)
		);

		// Check for legacy column name without underscore.
		$has_legacy_embeddingmodel = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*)
                 FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = %s
                   AND TABLE_NAME   = %s
                   AND COLUMN_NAME  = 'embeddingmodel'",
				$schema,
				$table
			)
		);

		if ( ! $has_embedding_model && $has_legacy_embeddingmodel ) {
			// Upgrade legacy column name in place.
			$wpdb->query(
				"ALTER TABLE {$this->table_name}
                 CHANGE COLUMN embeddingmodel embedding_model varchar(64) NOT NULL DEFAULT ''"
			);
		} elseif ( ! $has_embedding_model && ! $has_legacy_embeddingmodel ) {
			// Older table with no model column at all: add canonical column.
			$wpdb->query(
				"ALTER TABLE {$this->table_name}
                 ADD COLUMN embedding_model varchar(64) NOT NULL DEFAULT '' AFTER embedding"
			);
		}

		// Final sanity check & logging.
		$table_exists = $wpdb->get_var(
			$wpdb->prepare( 'SHOW TABLES LIKE %s', $this->table_name )
		);

		if ( $table_exists === $this->table_name ) {
			return true;
		}

		return false;
	}

	/**
	 * Store embedding in custom table
	 */
	public function store_embedding( $post_id, $question, $embedding ) {
		global $wpdb;
		if ( ! is_array( $embedding ) || empty( $embedding ) ) {
			return false;
		}
				$embedding_json = json_encode( $embedding );
		$hash                   = md5( $embedding_json );

		$embedding_model = class_exists( 'NM_API_Client' )
			? NM_API_Client::get_embedding_model_name()
			: 'gemini-embedding-2';

		$result = $wpdb->replace(
			$this->table_name,
			array(
				'post_id'         => $post_id,
				'embedding_hash'  => $hash,
				'embedding'       => $embedding_json,
				'embedding_model' => $embedding_model,
				'question_text'   => sanitize_text_field( $question ),
			),
			array( '%d', '%s', '%s', '%s', '%s' )
		);
		if ( isset( $this->cache[ $post_id ] ) ) {
			unset( $this->cache[ $post_id ] );
		}

		// Clear stats cache on change
		NM_Cache_Manager::delete( 'embedding_stats' );

		return $result !== false;
	}

	/**
	 * Get embedding for a specific post
	 */
	public function get_embedding( $post_id ) {
		global $wpdb;
		if ( isset( $this->cache[ $post_id ] ) ) {
			return $this->cache[ $post_id ];
		}
		$current_model = class_exists( 'NM_API_Client' ) ? NM_API_Client::get_embedding_model_name() : 'gemini-embedding-2';
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT embedding FROM {$this->table_name} WHERE post_id = %d AND embedding_model = %s", $post_id, $current_model ) );
		if ( $row ) {
			$embedding               = json_decode( $row->embedding, true );
			$this->cache[ $post_id ] = $embedding;
			return $embedding;
		}
		return null;
	}

	/**
	 * Get embedding for a specific post, filtered by the current active model.
	 * Used by maybe_generate_embedding_on_save to ensure we don't skip
	 * new-model generation when only an old-model embedding exists.
	 */
	public function get_embedding_for_model( $post_id ) {
		global $wpdb;
		$current_model = class_exists( 'NM_API_Client' ) ? NM_API_Client::get_embedding_model_name() : 'gemini-embedding-2';
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT embedding FROM {$this->table_name} WHERE post_id = %d AND embedding_model = %s", $post_id, $current_model ) );
		if ( $row ) {
			return json_decode( $row->embedding, true );
		}
		return null;
	}

	/**
	 * Get all embeddings (with session-level caching)
	 */
	public function get_all_embeddings( $limit = 5000 ) {
		global $wpdb;
		if ( $this->cache_loaded && ! empty( $this->cache ) ) {
			return $this->cache;
		}

		$current_model = class_exists( 'NM_API_Client' ) ? NM_API_Client::get_embedding_model_name() : 'gemini-embedding-2';

		$results = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT post_id, embedding FROM {$this->table_name} WHERE embedding_model = %s ORDER BY created_at DESC LIMIT %d",
				$current_model,
				$limit
			)
		);

		$embeddings = array();
		foreach ( $results as $row ) {
			$embeddings[ $row->post_id ] = json_decode( $row->embedding, true );
		}
		$this->cache        = $embeddings;
		$this->cache_loaded = true;
		return $embeddings;
	}
	/**
	 * Get all embeddings for a specific topic ID.
	 *
	 * @param int $topic_id The term_id of the topic.
	 * @return array Array of [post_id => embedding]
	 */
	public function get_embeddings_for_topic( $topic_id ) {
		global $wpdb;

		if ( empty( $topic_id ) ) {
			return array(); // Don't scan against "uncategorized"
		}

		// This query joins the embeddings table with the post table
		// and the term relationships table to find embeddings
		// for posts *only* in the specified topic.
		$current_model = class_exists( 'NM_API_Client' ) ? NM_API_Client::get_embedding_model_name() : 'gemini-embedding-2';

		$results = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT e.post_id, e.embedding
             FROM {$this->table_name} e
             INNER JOIN {$wpdb->posts} p ON e.post_id = p.ID
             INNER JOIN {$wpdb->term_relationships} tr ON e.post_id = tr.object_id
             INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id
             WHERE p.post_type = 'mcq'
             AND p.post_status IN ('publish', 'draft')
             AND e.embedding_model = %s
             AND tt.taxonomy = 'topic'
             AND tt.term_id = %d
             ORDER BY e.created_at DESC",
				$current_model,
				$topic_id
			)
		);

		$embeddings = array();
		foreach ( $results as $row ) {
			$embeddings[ $row->post_id ] = json_decode( $row->embedding, true );
		}

		// Note: We don't cache this result in $this->cache
		// because the main cache is for *all* embeddings (for the old method).
		// This is a specific, filtered query.
		return $embeddings;
	}
	/**
	 * Delete embedding for a post
	 */
	public function delete_embedding( $post_id ) {
		global $wpdb;
		$result = $wpdb->delete( $this->table_name, array( 'post_id' => $post_id ), array( '%d' ) );
		if ( isset( $this->cache[ $post_id ] ) ) {
			unset( $this->cache[ $post_id ] );
		}

		// Clear stats cache on change
		NM_Cache_Manager::delete( 'embedding_stats' );

		return $result !== false;
	}

	/**
	 * Get statistics about embeddings table
	 */
	public function get_statistics() {
		// Try cache first
		$cached_stats = NM_Cache_Manager::get( 'embedding_stats' );
		if ( $cached_stats !== false ) {
			return $cached_stats;
		}

		global $wpdb;
		$current_model = class_exists( 'NM_API_Client' ) ? NM_API_Client::get_embedding_model_name() : 'gemini-embedding-2';

		$total_embeddings = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT e.post_id) FROM %i e
             INNER JOIN {$wpdb->posts} p ON e.post_id = p.ID
             WHERE p.post_type = %s AND p.post_status IN ('publish', 'draft', 'pending')
             AND e.embedding_model = %s",
				$this->table_name,
				'mcq',
				$current_model
			)
		);
		$total_mcqs       = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = %s AND post_status IN ('publish', 'draft', 'pending')",
				'mcq'
			)
		);
		$coverage         = $total_mcqs > 0 ? round( ( $total_embeddings / $total_mcqs ) * 100, 2 ) : 0;
		$table_size       = $wpdb->get_var(
			$wpdb->prepare(
				'SELECT ROUND(((data_length + index_length) / 1024 / 1024), 2) 
             FROM information_schema.TABLES WHERE table_schema = %s AND table_name = %s',
				DB_NAME,
				$this->table_name
			)
		);
		$orphaned         = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM %i e
             LEFT JOIN {$wpdb->posts} p ON e.post_id = p.ID
             WHERE p.ID IS NULL",
				$this->table_name
			)
		);

		$stats = array(
			'total_embeddings'    => $total_embeddings,
			'total_mcqs'          => $total_mcqs,
			'coverage_percentage' => $coverage,
			'table_size_mb'       => $table_size ? floatval( $table_size ) : 0,
			'cache_loaded'        => $this->cache_loaded,
			'cached_items'        => count( $this->cache ),
			'orphaned_embeddings' => $orphaned,
		);

		// Cache stats for 15 minutes
		NM_Cache_Manager::set( 'embedding_stats', $stats, 900 );

		return $stats;
	}

	/**
	 * Clean up orphaned embeddings
	 */
	public function truncate_table() {
		global $wpdb;
		$result = $wpdb->query( "TRUNCATE TABLE {$this->table_name}" );

		$this->cache        = array();
		$this->cache_loaded = false;
		NM_Cache_Manager::delete( 'embedding_stats' );

		return $result !== false;
	}

	public function cleanup_orphaned_embeddings() {
		global $wpdb;
		$deleted = $wpdb->query(
			$wpdb->prepare(
				"DELETE e FROM %i e
             LEFT JOIN {$wpdb->posts} p ON e.post_id = p.ID
             WHERE p.ID IS NULL",
				$this->table_name
			)
		);
		$this->clear_cache();

		// Clear stats cache on change
		NM_Cache_Manager::delete( 'embedding_stats' );

		return $deleted;
	}

	/**
	 * Migrate embeddings from post meta to custom table
	 */
	public function migrate_from_postmeta() {
		global $wpdb;
		$log                  = array();
		$migrated             = 0;
		$failed               = 0;
		$log[]                = 'Starting migration from post meta...';
		$mcqs_with_embeddings = $wpdb->get_results(
			"SELECT pm.post_id, pm.meta_value, p.post_title FROM {$wpdb->postmeta} pm
             INNER JOIN {$wpdb->posts} p ON pm.post_id = p.ID
             WHERE pm.meta_key = 'mcq_embedding' AND p.post_type = 'mcq'"
		);
		$log[]                = 'Found ' . count( $mcqs_with_embeddings ) . ' embeddings to migrate.';
		foreach ( $mcqs_with_embeddings as $row ) {
			$embedding = maybe_unserialize( $row->meta_value );
			if ( is_array( $embedding ) && ! empty( $embedding ) ) {
				$success = $this->store_embedding( $row->post_id, $row->post_title, $embedding );
				if ( $success ) {
					++$migrated;
				} else {
					++$failed;
					$log[] = "Failed to migrate ID: {$row->post_id}";
				}
			} else {
				++$failed;
				$log[] = "Invalid embedding for ID: {$row->post_id}";
			}
		}
		$log[] = "Migration complete. Migrated: {$migrated}, Failed: {$failed}";

		// Clear stats cache on change
		NM_Cache_Manager::delete( 'embedding_stats' );

		return array(
			'success'  => true,
			'migrated' => $migrated,
			'failed'   => $failed,
			'log'      => $log,
		);
	}

	/**
	 * Clear all cache
	 */
		/**
		 * Clear all cache
		 */
	public function clear_cache() {
		$this->cache        = array();
		$this->cache_loaded = false;
	}

	/**
	 * Maybe generate an embedding when an MCQ is created or updated.
	 *
	 * Hooks into save_post_mcq and reuses the same Gemini logic
	 * as the admin backfill (nm_backfill_single_embedding) callback.
	 *
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post object.
	 * @param bool    $update  Whether this is an existing post being updated.
	 */
	public static function maybe_generate_embedding_on_save( $post_id, $post, $update ) {
		// Safety checks: autosaves, revisions, wrong type.
		if ( wp_is_post_revision( $post_id ) ) {
			return;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( ! isset( $post->post_type ) || $post->post_type !== 'mcq' ) {
			return;
		}

		// Only generate for relevant statuses.
		if ( ! in_array( $post->post_status, array( 'publish', 'draft', 'pending' ), true ) ) {
			return;
		}

		// Need the API client and Gemini key.
		if ( ! class_exists( 'NM_API_Client' ) ) {
			return;
		}

		$gemini_api_key = NM_API_Client::get_gemini_api_key();
		if ( empty( $gemini_api_key ) ) {
			return;
		}

		// Skip if an embedding already exists for the current model.
		$db       = new self();
		$existing = $db->get_embedding_for_model( $post_id );
		if ( is_array( $existing ) && ! empty( $existing ) ) {
			return;
		}

		// Generate and store the embedding.
		self::generate_embedding_for_post( $post_id );
	}

	/**
	 * Generate and store a Gemini embedding for a single MCQ post.
	 *
	 * This is the shared logic used by both the cron worker and on-save hook,
	 * mirroring the behaviour of nmbackfillsingleembeddingcallback in the admin AJAX.
	 *
	 * @param int $post_id
	 * @return bool True on success, false on failure.
	 */
	public static function generate_embedding_for_post( $post_id ) {
		if ( ! class_exists( 'NM_API_Client' ) ) {
			return false;
		}

		$gemini_api_key = NM_API_Client::get_gemini_api_key();
		if ( empty( $gemini_api_key ) ) {
			return false;
		}

		$question_text = get_the_title( $post_id );
		if ( empty( $question_text ) ) {
			return false;
		}

		try {
			$client    = NM_API_Client::get_instance();
			$embedding = $client->get_embedding( $question_text, $gemini_api_key );
		} catch ( \Throwable $e ) {
			if ( class_exists( 'NM_Generation_Logger' ) ) {
				NM_Generation_Logger::genlog_event(
					array(
						'event_type'    => 'error',
						'severity'      => 'error',
						'source_type'   => 'embedding',
						'source_ref'    => 'generate_for_post',
						'mcq_id'        => $post_id,
						'error_code'    => 'embedding_exception',
						'error_message' => 'Exception while generating embedding: ' . $e->getMessage(),
						'meta'          => array(
							'model'         => class_exists( 'NM_API_Client' ) ? NM_API_Client::get_embedding_model_name() : 'unknown',
							'question_text' => $question_text,
						),
					)
				);
			}
			return false;
		}

		if ( ! $embedding || ! is_array( $embedding ) ) {
			if ( class_exists( 'NM_Generation_Logger' ) ) {
				NM_Generation_Logger::genlog_event(
					array(
						'event_type'    => 'error',
						'severity'      => 'error',
						'source_type'   => 'embedding',
						'source_ref'    => 'generate_for_post',
						'mcq_id'        => $post_id,
						'error_code'    => 'embedding_empty',
						'error_message' => 'Embedding generation returned empty/false for MCQ #' . $post_id,
						'meta'          => array(
							'model'         => class_exists( 'NM_API_Client' ) ? NM_API_Client::get_embedding_model_name() : 'unknown',
							'question_text' => $question_text,
						),
					)
				);
			}
			return false;
		}

		$db     = new self();
		$stored = $db->store_embedding( $post_id, $question_text, $embedding );

		if ( $stored ) {
			return true;
		}

		return false;
	}

	/**
	 * Cron worker: process exactly one MCQ that is missing an embedding.
	 *
	 * Intended to be triggered by the nm_embedding_backfill_cron hook,
	 * which should be scheduled by your central cron manager.
	 * Uses a transient lock to avoid overlapping runs.
	 */
	public static function run_embedding_backfill_cron() {
		if ( ! class_exists( 'NM_API_Client' ) ) {
			return;
		}

		$lock_key = 'nm_embedding_backfill_lock';

		// Prevent overlapping runs; lock for ~60 seconds.
		if ( get_transient( $lock_key ) ) {
			return;
		}
		set_transient( $lock_key, time(), 60 );

		try {
			global $wpdb;

			$db         = new self();
			$table_name = $db->table_name;

			$gemini_api_key = NM_API_Client::get_gemini_api_key();
			if ( empty( $gemini_api_key ) ) {
				return;
			}

						$current_model = class_exists( 'NM_API_Client' ) ? NM_API_Client::get_embedding_model_name() : 'gemini-embedding-2';

			// Pick the oldest MCQ without an embedding for the current model.
			$post_id = (int) $wpdb->get_var(
				$wpdb->prepare(
					"
                SELECT p.ID
                FROM {$wpdb->posts} AS p
                LEFT JOIN {$table_name} AS e ON p.ID = e.post_id AND e.embedding_model = %s
                WHERE p.post_type = 'mcq'
                  AND p.post_status IN ('publish','draft','pending')
                  AND e.post_id IS NULL
                ORDER BY p.ID ASC
                LIMIT 1
                ",
					$current_model
				)
			);

			if ( ! $post_id ) {
				// Nothing left to do; safe to leave the worker scheduled,
				// it will simply no-op until new MCQs are created.
				return;
			}

			$ok = self::generate_embedding_for_post( $post_id );

			if ( $ok ) {
			} else {
			}
		} catch ( \Throwable $e ) {
		} finally {
			delete_transient( $lock_key );
		}
	}

	/**
	 * RENDER EMBEDDINGS PAGE (Ported from V23)
	 */
	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'Access denied' );
		}

		// Get initial stats
				$db     = new self();
		$stats          = $db->get_statistics();
		$gemini_api_key = class_exists( 'NM_API_Client' )
			? NM_API_Client::get_gemini_api_key()
			: '';

		$total_mcqs              = $stats['total_mcqs'];
		$mcqs_with_embeddings    = $stats['total_embeddings'];
		$mcqs_without_embeddings = max( 0, $total_mcqs - $mcqs_with_embeddings );
		$coverage                = $stats['coverage_percentage'];
		$orphaned                = $stats['orphaned_embeddings'];

		?>
		<div class="wrap">
			<h1>🔄 Embeddings Manager</h1>
			<p>Generate semantic embeddings for MCQs to enable advanced duplicate detection.</p>

			<?php if ( empty( $gemini_api_key ) ) : ?>
				<div class="notice notice-error">
					<p><strong>Error:</strong> Gemini API key is not configured. Please add it in <a href="<?php echo admin_url( 'admin.php?page=news-mcq-generator&tab=api_keys' ); ?>">Settings</a> first.</p>
				</div>
			<?php else : ?>

				<div class="card nm-stats-grid" style="max-width: 800px; margin: 20px 0;">
					<h2>📊 Current Status</h2>
					<table class="widefat" style="margin-top: 10px;">
						<tbody>
							<tr>
								<th style="width: 200px;">Total MCQs</th>
								<td><strong id="stats-total-mcqs"><?php echo number_format( $total_mcqs ); ?></strong></td>
							</tr>
							<tr>
								<th>MCQs with Embeddings</th>
								<td><strong id="stats-with-embeddings" style="color: green;"><?php echo number_format( $mcqs_with_embeddings ); ?></strong></td>
							</tr>
							<tr>
								<th>MCQs without Embeddings</th>
								<td><strong id="stats-without-embeddings" style="color: <?php echo $mcqs_without_embeddings > 0 ? 'red' : 'green'; ?>;"><?php echo number_format( $mcqs_without_embeddings ); ?></strong></td>
							</tr>
							<tr>
								<th>Coverage</th>
								<td>
									<strong id="stats-coverage-percent"><?php echo $coverage; ?>%</strong>
									<div style="background: #ddd; height: 20px; width: 100%; margin-top: 5px; border-radius: 3px; overflow: hidden;">
										<div id="stats-coverage-bar" style="background: #2271b1; height: 100%; width: <?php echo min( 100, $coverage ); ?>%;"></div>
									</div>
								</td>
							</tr>
							<tr>
								<th>Table Size</th>
								<td><strong id="stats-table-size"><?php echo $stats['table_size_mb']; ?> MB</strong></td>
							</tr>
							<?php if ( $orphaned > 0 ) : ?>
								<tr id="stats-orphaned-row">
									<th>Orphaned Embeddings</th>
									<td>
										<strong id="stats-orphaned" style="color: orange;"><?php echo number_format( $orphaned ); ?></strong>
										<p class="description">Embeddings for deleted or trashed MCQs</p>
									</td>
								</tr>
							<?php endif; ?>
						</tbody>
					</table>
				</div>

				<?php if ( $orphaned > 0 ) : ?>
					<div id="nm-cleanup-orphans-notice" class="notice notice-warning inline" style="max-width: 760px;">
						<p><strong>⚠️ Found <span id="nm-orphaned-count"><?php echo $orphaned; ?></span> orphaned embedding(s)</strong></p>
						<p>These are embeddings for MCQs that have been deleted or trashed. Clean them up to improve accuracy.</p>
						<button type="button" id="nm-cleanup-orphans-btn" class="button">Clean Up Orphaned Embeddings</button>
						<span id="nm-cleanup-spinner" class="spinner" style="float: none;"></span>
						<span id="nm-cleanup-result" style="margin-left: 10px;"></span>
					</div>
				<?php endif; ?>

				<div class="card" id="nm-backfill-card" style="max-width: 800px; margin: 20px 0; <?php echo $mcqs_without_embeddings > 0 ? '' : 'display:none;'; ?>">
					<h2>⚡ Backfill Embeddings</h2>
					<p>Generate embeddings for all <strong id="nm-total-count-text"><?php echo $mcqs_without_embeddings; ?></strong> MCQs that don't have them yet.</p>
					<p><strong>Note:</strong> This process respects API rate limits (7 seconds between requests).</p>

					<button type="button" id="nm-start-backfill-btn" class="button button-primary button-hero" style="margin-top: 10px;">
						🚀 Start Backfill Process
					</button>
					<button type="button" id="nm-stop-backfill-btn" class="button button-secondary" style="margin-top: 10px; display: none;">
						⏸️ Pause
					</button>
					<button type="button" class="button button-link-delete" id="nm-truncate-embeddings-btn" style="color: #d63638; margin-left: 20px;">?? Truncate All Embeddings</button>

					<div id="nm-backfill-status" style="margin-top: 20px; display: none;">
						<h3>Progress</h3>
						<div style="background: #f0f0f1; padding: 15px; border-radius: 4px;">
							<div style="margin-bottom: 10px;">
								<strong>Processed:</strong> <span id="nm-processed-count">0</span> / <span id="nm-total-count"><?php echo $mcqs_without_embeddings; ?></span>
							</div>
							<div style="background: #ddd; height: 30px; border-radius: 3px; overflow: hidden;">
								<div id="nm-progress-bar" style="background: #2271b1; height: 100%; width: 0%; transition: width 0.3s;"></div>
							</div>
							<div style="margin-top: 10px; font-size: 13px; color: #666;">
								<span id="nm-status-text">Initializing...</span>
							</div>
						</div>

						<h3 style="margin-top: 20px;">Recent Activity</h3>
						<pre id="nm-backfill-log" style="background: #f7f7f7; border: 1px solid #ccc; padding: 15px; border-radius: 4px; max-height: 300px; overflow-y: auto; font-size: 13px; line-height: 1.6;"></pre>
					</div>
				</div>

				<div id="nm-all-done-notice" class="notice notice-success inline" style="max-width: 760px; <?php echo $mcqs_without_embeddings > 0 ? 'display:none;' : ''; ?>">
					<p><strong>✅ All Done!</strong> All your MCQs already have embeddings.</p>
				</div>

				<div class="card" style="max-width: 800px; margin: 20px 0;">
					<h2>🔄 Migrate from Post Meta</h2>
					<p>If you have embeddings stored in the old post meta format, migrate them to the new optimized database.</p>

					<button type="button" id="nm-migrate-postmeta-btn" class="button button-secondary">
						Migrate Old Embeddings
					</button>
					<span id="nm-migrate-spinner" class="spinner" style="float: none; margin-top: 5px;"></span>

					<pre id="nm-migrate-log" style="background: #f7f7f7; border: 1px solid #ccc; padding: 15px; border-radius: 4px; max-height: 200px; overflow-y: auto; font-size: 13px; line-height: 1.6; margin-top: 15px; display: none;"></pre>
				</div>

			<?php endif; ?>
		</div>

		<script>
			jQuery(document).ready(function($) {
				const ajaxNonce = '<?php echo wp_create_nonce( 'nm_ajax_dashboard' ); ?>'; // ✅ FIXED v7.3.2: Changed from "nm_admin_nonce" to match AJAX handler expectations
				let isRunning = false;
				let shouldStop = false;
				let processedCount = 0;
				let totalCount = 0; // Will be set by refreshStatsCard
				let mcqIds = [];
				let currentIndex = 0;

				const backfillCard = $('#nm-backfill-card');
				const allDoneNotice = $('#nm-all-done-notice');

				/**
				 * ✅ NEW: Function to refresh the stats card via AJAX
				 */
				function refreshStatsCard() {
					const statsCard = $('.nm-stats-grid');
					statsCard.css('opacity', 0.5);

					$.ajax({
						url: ajaxurl,
						type: 'POST',
						data: {
							action: 'nm_get_embedding_stats',
							_wpnonce: ajaxNonce
						},
						success: function(response) {
							if (response.success) {
								const stats = response.data;
								const without = Math.max(0, stats.total_mcqs - stats.total_embeddings);
								const coverage = stats.coverage_percentage;

								$('#stats-total-mcqs').text(stats.total_mcqs.toLocaleString());
								$('#stats-with-embeddings').text(stats.total_embeddings.toLocaleString());
								$('#stats-without-embeddings').text(without.toLocaleString())
									.css('color', without > 0 ? 'red' : 'green');
								$('#stats-coverage-percent').text(coverage + '%');
								$('#stats-coverage-bar').css('width', coverage + '%');
								$('#stats-table-size').text(stats.table_size_mb + ' MB');

								// Update orphan count
								if ($('#stats-orphaned-row').length) {
									$('#stats-orphaned').text(stats.orphaned_embeddings.toLocaleString());
									if (stats.orphaned_embeddings > 0) {
										$('#nm-cleanup-orphans-notice').show();
										$('#nm-orphaned-count').text(stats.orphaned_embeddings);
									} else {
										$('#nm-cleanup-orphans-notice').hide();
									}
								}

								// Update the 'to-do' count for the backfill process
								totalCount = without;
								$('#nm-total-count, #nm-total-count-text').text(without);

								// Show/hide the backfill card
								if (without > 0) {
									backfillCard.show();
									allDoneNotice.hide();
								} else {
									backfillCard.hide();
									allDoneNotice.show();
								}
							}
						},
						complete: function() {
							statsCard.css('opacity', 1);
						}
					});
				}

				// Initial load
				refreshStatsCard();

				// Cleanup orphaned embeddings
				$('#nm-cleanup-orphans-btn').on('click', function() {
					if (!confirm('Clean up ' + $('#nm-orphaned-count').text() + ' orphaned embedding(s)? This action cannot be undone.')) return;

					const btn = $(this);
					const spinner = $('#nm-cleanup-spinner');
					const result = $('#nm-cleanup-result');

					btn.prop('disabled', true);
					spinner.addClass('is-active');
					result.text('');

					$.ajax({
						url: ajaxurl,
						type: 'POST',
						data: {
							action: 'nm_cleanup_orphaned_embeddings',
							_wpnonce: ajaxNonce
						},
						success: function(response) {
							if (response.success) {
								result.html('<strong style="color: green;">✓ Cleaned up ' + response.data.deleted + ' orphaned record(s)</strong>');
								setTimeout(refreshStatsCard, 1500); // Refresh stats instead of reload
							} else {
								result.html('<strong style="color: red;">✗ Failed</strong>');
								btn.prop('disabled', false);
							}
						},
						error: function() {
							result.html('<strong style="color: red;">✗ Server Error</strong>');
							btn.prop('disabled', false);
						},
						complete: function() {
							spinner.removeClass('is-active');
						}
					});
				});

				$('#nm-truncate-embeddings-btn').on('click', function() {
					if (!confirm('CRITICAL WARNING: This will permanently delete ALL embeddings in the database. You will need to run the Backfill Process to regenerate them using the new Gemini Embedding 2 model. Are you absolutely sure?')) {
						return;
					}

					$('#nm-status-text').text('Truncating table...');
					$(this).prop('disabled', true);

					$.ajax({
						url: ajaxurl,
						type: 'POST',
						data: {
							action: 'nm_truncate_embeddings',
							_wpnonce: ajaxNonce
						},
						success: function(response) {
							if (response.success) {
								alert('All embeddings have been truncated successfully. You can now start the Backfill Process.');
								location.reload();
							} else {
								alert('Error truncating table.');
								$('#nm-truncate-embeddings-btn').prop('disabled', false);
							}
						},
						error: function() {
							alert('Server error truncating table.');
							$('#nm-truncate-embeddings-btn').prop('disabled', false);
						}
					});
				});

				// Backfill process
				$('#nm-start-backfill-btn').on('click', function() {
					if (isRunning) return;

					isRunning = true;
					shouldStop = false;
					processedCount = 0;
					currentIndex = 0;

					$('#nm-backfill-status').show();
					$(this).hide();
					$('#nm-stop-backfill-btn').show();
					$('#nm-backfill-log').text('Fetching MCQs without embeddings...\n');
					$('#nm-status-text').text('Fetching list of MCQs...');

					// Refresh stats one last time before starting
					refreshStatsCard();

					$.ajax({
						url: ajaxurl,
						type: 'POST',
						data: {
							action: 'nm_get_mcqs_without_embedding',
							_wpnonce: ajaxNonce
						},
						success: function(response) {
							if (response.success && response.data.length > 0) {
								mcqIds = response.data;
								totalCount = mcqIds.length; // Ensure totalCount is accurate
								$('#nm-total-count, #nm-total-count-text').text(totalCount);
								$('#nm-backfill-log').append('Found ' + totalCount + ' MCQs to process.\n');
								$('#nm-status-text').text('Starting backfill...');
								processNextBatch();
							} else {
								$('#nm-backfill-log').append('No MCQs found without embeddings.\n');
								$('#nm-status-text').text('Complete!');
								stopBackfill();
							}
						},
						error: function() {
							$('#nm-backfill-log').append('ERROR: Failed to fetch MCQ list.\n');
							stopBackfill();
						}
					});
				});

				$('#nm-stop-backfill-btn').on('click', function() {
					shouldStop = true;
					$('#nm-status-text').text('Pausing...');
					$(this).prop('disabled', true);
				});

				function processNextBatch() {
					if (shouldStop || currentIndex >= mcqIds.length) {
						stopBackfill();
						return;
					}

					const postId = mcqIds[currentIndex];
					$('#nm-status-text').text('Processing MCQ #' + postId + '...');

					$.ajax({
						url: ajaxurl,
						type: 'POST',
						data: {
							action: 'nm_backfill_single_embedding',
							post_id: postId,
							_wpnonce: ajaxNonce
						},
						success: function(response) {
							processedCount++;
							currentIndex++;

							if (response.success) {
								$('#nm-backfill-log').append('✓ MCQ #' + postId + ' - Success\n');
							} else {
								$('#nm-backfill-log').append('✗ MCQ #' + postId + ' - Failed\n');
							}

							updateProgress();

							const log = $('#nm-backfill-log')[0];
							log.scrollTop = log.scrollHeight;

							if (currentIndex < mcqIds.length) {
								$('#nm-status-text').text('Waiting 7 seconds (rate limit)...');
								setTimeout(processNextBatch, 7000);
							} else {
								processNextBatch(); // This will trigger the stop condition
							}
						},
						error: function() {
							processedCount++;
							currentIndex++;
							$('#nm-backfill-log').append('✗ MCQ #' + postId + ' - Server Error\n');
							updateProgress();
							setTimeout(processNextBatch, 7000);
						}
					});
				}

				function updateProgress() {
					$('#nm-processed-count').text(processedCount);
					const percentage = totalCount > 0 ? (processedCount / totalCount * 100) : 0;
					$('#nm-progress-bar').css('width', percentage + '%');
				}

				function stopBackfill() {
					isRunning = false;
					$('#nm-start-backfill-btn').show();
					$('#nm-stop-backfill-btn').hide().prop('disabled', false);

					if (shouldStop) {
						$('#nm-status-text').text('Paused');
					} else {
						$('#nm-status-text').text('Complete!');
						$('#nm-backfill-log').append('\n✅ Backfill complete!\n');
					}

					// ✅ ALWAYS refresh stats when stopping
					refreshStatsCard();
				}

				// Migration from post meta
				$('#nm-migrate-postmeta-btn').on('click', function() {
					const btn = $(this);
					const spinner = $('#nm-migrate-spinner');
					const log = $('#nm-migrate-log');

					btn.prop('disabled', true);
					spinner.addClass('is-active');
					log.show().text('Starting migration...\n');

					$.ajax({
						url: ajaxurl,
						type: 'POST',
						data: {
							action: 'nm_migrate_embeddings',
							_wpnonce: ajaxNonce
						},
						success: function(response) {
							if (response.success) {
								log.text(response.data.log.join('\n'));
								refreshStatsCard(); // Refresh stats on success
							} else {
								log.text('ERROR: ' + (response.data?.message || 'Migration failed'));
							}
						},
						error: function() {
							log.text('ERROR: Server error during migration');
						},
						complete: function() {
							btn.prop('disabled', false);
							spinner.removeClass('is-active');
						}
					});
				});
			});
		</script>
		<?php
	}
	/**
	 * Finds similar embeddings based on cosine similarity.
	 * Assumes embeddings are stored as JSON-encoded arrays.
	 *
	 * This PHP-based calculation is necessary for standard MySQL environments.
	 *
	 * @param array $new_embedding The embedding vector (array of floats) of the new question.
	 * @param int   $limit The number of similar posts to return.
	 * @param float $threshold The similarity threshold (e.g., 0.95). Higher is more similar.
	 * @return array An array of matching posts, each with 'post_id' and 'similarity'.
	 */
	public function find_similar_embeddings( $new_embedding, $limit = 1, $threshold = 0.95 ) {
		global $wpdb;
		$table_name = $this->table_name;

		// Normalize the new vector (calculate its magnitude)
		$new_mag = 0;
		foreach ( $new_embedding as $val ) {
			$new_mag += $val * $val;
		}
		$new_mag = sqrt( $new_mag );

		if ( $new_mag == 0 ) {
			return array(); // Avoid division by zero for a zero-length vector
		}

		// We must fetch all embeddings and compare in PHP.
		// This is less efficient than a dedicated vector DB, but works on any MySQL setup.
		// For performance, you could add caching or only fetch recent embeddings.
		$current_model = class_exists( 'NM_API_Client' ) ? NM_API_Client::get_embedding_model_name() : 'gemini-embedding-2';
		$all_embeddings = $wpdb->get_results( $wpdb->prepare( "SELECT post_id, embedding FROM $table_name WHERE embedding_model = %s", $current_model ) );

		$similar_posts = array();

		foreach ( $all_embeddings as $row ) {
			$existing_embedding = json_decode( $row->embedding, true );
			if ( ! is_array( $existing_embedding ) || count( $existing_embedding ) != count( $new_embedding ) ) {
				// Skip if embedding is invalid or dimension mismatch
				continue;
			}

			// Calculate Dot Product and Existing Vector Magnitude
			$dot_product  = 0;
			$existing_mag = 0;
			$vector_count = count( $new_embedding );

			for ( $i = 0; $i < $vector_count; $i++ ) {
				$dot_product  += $new_embedding[ $i ] * $existing_embedding[ $i ];
				$existing_mag += $existing_embedding[ $i ] * $existing_embedding[ $i ];
			}
			$existing_mag = sqrt( $existing_mag );

			if ( $existing_mag == 0 ) {
				continue; // Avoid division by zero for a zero-length vector
			}

			// Calculate Cosine Similarity
			$similarity = $dot_product / ( $new_mag * $existing_mag );

			if ( $similarity >= $threshold ) {
				$similar_posts[] = array(
					'post_id'    => (int) $row->post_id,
					'similarity' => (float) $similarity,
				);
			}
		}

		// Sort by similarity, descending
		usort(
			$similar_posts,
			function ( $a, $b ) {
				return $b['similarity'] <=> $a['similarity'];
			}
		);

		return array_slice( $similar_posts, 0, $limit );
	}
}
?>
