/**
 * MCQ Video Studio - Edge TTS Helper
 *
 * Free Edge TTS generation using Microsoft Edge's online TTS WebSocket service.
 * Called by PHP (VS_AJAX_TTS_Handler) via shell_exec / proc_open.
 *
 * Implements the Edge TTS protocol directly (based on github.com/rany2/edge-tts)
 * including the Sec-MS-GEC DRM token that Microsoft now requires (since late 2024).
 * NO API KEY REQUIRED. Unlimited usage.
 *
 * Dependencies: ws (WebSocket client) — listed in render-service/package.json
 *
 * Usage:
 *   node edge-tts-helper.js --text="Hello world" --voice=en-US-AriaNeural --rate=+0% --pitch=+0Hz --output=/path/to/output.mp3
 *
 * Exit codes:
 *   0 = success, audio written to --output path
 *   1 = error (message printed to stderr)
 *
 * @version 2.0.0
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// ─── Edge TTS Constants (from rany2/edge-tts constants.py) ──────────
const BASE_URL = 'speech.platform.bing.com/consumer/speech/synthesize/readaloud';
const TRUSTED_CLIENT_TOKEN = '6A5AA1D4EAFF4E9FB37E23D68491D6F4';
const WSS_URL = `wss://${BASE_URL}/edge/v1?TrustedClientToken=${TRUSTED_CLIENT_TOKEN}`;
const WIN_EPOCH = 11644473600;
const S_TO_NS = 1e9;

// ─── DRM: Sec-MS-GEC Token Generation ───────────────────────────────
let clockSkewSeconds = 0.0;

function getUnixTimestamp() {
    return (Date.now() / 1000) + clockSkewSeconds;
}

function generateSecMsGec() {
    let ticks = getUnixTimestamp();
    ticks += WIN_EPOCH;
    ticks -= ticks % 300;
    ticks *= S_TO_NS / 100;
    const strToHash = `${Math.floor(ticks)}${TRUSTED_CLIENT_TOKEN}`;
    return crypto.createHash('sha256').update(strToHash, 'ascii').digest('hex').toUpperCase();
}

function generateMuid() {
    return crypto.randomBytes(16).toString('hex').toUpperCase();
}

function uuidNoDashes() {
    return crypto.randomUUID().replace(/-/g, '');
}

// ─── CLI Argument Parsing ───────────────────────────────────────────
function parseArgs() {
    const args = {};
    process.argv.slice(2).forEach(arg => {
        const [key, ...rest] = arg.replace(/^--/, '').split('=');
        args[key] = rest.join('=') || true;
    });
    return args;
}

// ─── Main Edge TTS Logic ────────────────────────────────────────────
function synthesize(text, voice, rate, pitch, volume, outputPath) {
    return new Promise((resolve, reject) => {
        let WebSocket;
        try {
            WebSocket = require('ws');
        } catch (_) {
            reject(new Error('ws module not installed. Run: cd render-service && npm install'));
            return;
        }

        const secMsGec = generateSecMsGec();
        const muid = generateMuid();
        const connectionId = uuidNoDashes();
        const wsUrl = `${WSS_URL}&Sec-MS-GEC=${secMsGec}&Sec-MS-GEC-Version=1-143.0.3650.75&ConnectionId=${connectionId}`;

        const ws = new WebSocket(wsUrl, {
            host: 'speech.platform.bing.com',
            origin: 'chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold',
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0',
                'Cookie': `muid=${muid};`,
                'Pragma': 'no-cache',
                'Cache-Control': 'no-cache',
            },
            compress: true,
        });

        const audioChunks = [];
        let turnEndReceived = false;

        const safeText = text.replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&apos;','"':'&quot;'}[c]));

        const speechConfig = JSON.stringify({
            context: {
                synthesis: {
                    audio: {
                        metadataoptions: { sentenceBoundaryEnabled: false, wordBoundaryEnabled: false },
                        outputFormat: 'audio-24khz-48kbitrate-mono-mp3',
                    },
                },
            },
        });

        const configMessage = `X-Timestamp:${new Date().toString()}\r\nContent-Type:application/json; charset=utf-8\r\nPath:speech.config\r\n\r\n${speechConfig}`;

        // Derive xml:lang from the voice ID (e.g. 'en-IN-NeerjaNeural' -> 'en-IN')
        const langFromVoice = voice && voice.includes('-') ? voice.split('-').slice(0, 2).join('-') : 'en-US';

        const ssml = `<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='${langFromVoice}'><voice name='${voice}'><prosody pitch='${pitch}' rate='${rate}' volume='${volume}'>${safeText}</prosody></voice></speak>`;
        const ssmlMessage = `X-RequestId:${uuidNoDashes()}\r\nContent-Type:application/ssml+xml\r\nX-Timestamp:${new Date().toString()}Z\r\nPath:ssml\r\n\r\n${ssml}`;

        const timeout = setTimeout(() => {
            ws.close();
            reject(new Error('Edge TTS WebSocket timed out (45s)'));
        }, 45000);

        ws.on('open', () => {
            ws.send(configMessage, { compress: true }, (configErr) => {
                if (configErr) { clearTimeout(timeout); reject(configErr); return; }
                ws.send(ssmlMessage, { compress: true }, (ssmlErr) => {
                    if (ssmlErr) { clearTimeout(timeout); reject(ssmlErr); }
                });
            });
        });

        ws.on('message', (rawData, isBinary) => {
            if (!isBinary) {
                const dataStr = rawData.toString('utf8');
                if (dataStr.includes('turn.end')) {
                    turnEndReceived = true;
                    clearTimeout(timeout);
                    ws.close();
                    const audioBuffer = Buffer.concat(audioChunks);
                    resolve(audioBuffer);
                }
                return;
            }

            // Handle binary audio messages - Edge TTS sends audio with optional headers
            const raw = Buffer.isBuffer(rawData) ? rawData : Buffer.from(rawData);
            
            // Try to find the audio data separator
            const separator = Buffer.from('Path:audio\r\n');
            let audioData = raw;
            const sepIdx = raw.indexOf(separator);
            if (sepIdx !== -1) {
                // Found separator, extract audio data after it
                audioData = raw.subarray(sepIdx + separator.length);
            }
            // If separator not found, assume entire message is audio data
            
            if (audioData.length > 0) {
                audioChunks.push(audioData);
            }
        });

        ws.on('error', (err) => {
            clearTimeout(timeout);
            const errMsg = err.message || '';
            
            // Handle 403: Clock skew — adjust and retry
            if (errMsg.includes('403')) {
                const serverDateHeader = err.headers && err.headers['date'];
                if (serverDateHeader) {
                    const serverTime = new Date(serverDateHeader).getTime() / 1000;
                    const clientTime = Date.now() / 1000;
                    clockSkewSeconds = serverTime - clientTime;
                }
            }
            
            // Handle 429: Rate limiting — mark for retry with delay
            if (errMsg.includes('429') || errMsg.includes('Too Many Requests') || errMsg.includes('rate limit')) {
                err._isRateLimit = true;
            }
            
            reject(err);
        });

        ws.on('close', (code, reason) => {
            clearTimeout(timeout);
if (!turnEndReceived) {
                reject(new Error(`WebSocket closed (${code}) — no audio received`));
            }
        });
    });
}

// ─── Entry Point ────────────────────────────────────────────────────
async function main() {
    try {
    const config = parseArgs();

    // @NEW 2026-08-11: Batch mode — synthesize MANY segments in ONE process.
    //   --texts=<JSON array>  --outputs=<JSON array>  (same length)
    //   Falls back to single-segment mode (--text/--output) for backward compat
    //   (PHP test calls, manual usage). Batching cuts ~2 process spawns per segment
    //   (node + ffmpeg) down to ~2 total per video — the #1 render-time win.
    if (config.texts && config.outputs) {
        let texts, outputs;
        try {
            texts = JSON.parse(config.texts);
            outputs = JSON.parse(config.outputs);
        } catch (e) {
            process.stderr.write('[edge-tts-helper] ERROR: --texts/--outputs must be valid JSON arrays.\n');
            process.exit(1);
        }
        if (!Array.isArray(texts) || !Array.isArray(outputs) || texts.length !== outputs.length || texts.length === 0) {
            process.stderr.write('[edge-tts-helper] ERROR: --texts and --outputs must be equal-length non-empty arrays.\n');
            process.exit(1);
        }

        const voice = config.voice || 'en-US-AriaNeural';
        const rate = config.rate || '+0%';
        const pitch = config.pitch || '+0Hz';
        const volume = config.volume || '+0%';

        const results = [];
        for (let i = 0; i < texts.length; i++) {
            const text = String(texts[i] || '');
            const outputPath = String(outputs[i] || '');
            if (!text || !outputPath) {
                results.push({ success: false, index: i, error: 'empty text or output' });
                continue;
            }
            const outputDir = path.dirname(outputPath);
            if (!fs.existsSync(outputDir)) fs.mkdirSync(outputDir, { recursive: true });

            let attempts = 0;
            const maxAttempts = 3;
            let done = false;
            while (attempts < maxAttempts && !done) {
                attempts++;
                try {
                    const audioBuffer = await synthesize(text, voice, rate, pitch, volume, outputPath);
                    if (!audioBuffer || audioBuffer.length === 0) throw new Error('No audio received from Edge TTS service');
                    fs.writeFileSync(outputPath, audioBuffer);
                    results.push({ success: true, index: i, path: outputPath, size: audioBuffer.length });
                    done = true;
                } catch (err) {
                    if (attempts >= maxAttempts) {
                        results.push({ success: false, index: i, error: err && err.message ? err.message : String(err) });
                    } else {
                        await new Promise((r) => setTimeout(r, 800 * attempts));
                    }
                }
            }
        }

        process.stdout.write(JSON.stringify({ success: true, batch: results }) + '\n');
        process.exit(0);
    }

    if (!config.text || !config.output) {
        process.stderr.write('[edge-tts-helper] ERROR: --text and --output are required (or --texts/--outputs for batch).\n');
        process.exit(1);
    }

    const text = config.text;
    const voice = config.voice || 'en-US-AriaNeural';
    const rate = config.rate || '+0%';
    const pitch = config.pitch || '+0Hz';
    const volume = config.volume || '+0%';
    const outputPath = config.output;

    const outputDir = path.dirname(outputPath);
    if (!fs.existsSync(outputDir)) {
        fs.mkdirSync(outputDir, { recursive: true });
    }

    let attempts = 0;
    const maxAttempts = 3;

    while (attempts < maxAttempts) {
        attempts++;
        try {
            const audioBuffer = await synthesize(text, voice, rate, pitch, volume, outputPath);

            if (!audioBuffer || audioBuffer.length === 0) {
                throw new Error('No audio received from Edge TTS service');
            }

            fs.writeFileSync(outputPath, audioBuffer);

            process.stdout.write(JSON.stringify({
                success: true,
                path: outputPath,
                size: audioBuffer.length,
                voice: voice,
            }) + '\n');

            process.exit(0);
        } catch (err) {
            const isRateLimit = err._isRateLimit || (err.message && (err.message.includes('429') || err.message.includes('Too Many Requests')));
            const isClockSkew = err.message && err.message.includes('403');
            
            if (attempts < maxAttempts && (isRateLimit || isClockSkew)) {
                // Exponential backoff: 1s, 2s, 4s for rate limits; 500ms for clock skew
                const delay = isRateLimit ? Math.min(1000 * Math.pow(2, attempts - 1), 8000) : 500;
                process.stderr.write(`[edge-tts-helper] ${isRateLimit ? '429 rate limit' : '403 clock skew'} received (attempt ${attempts}), retrying in ${delay}ms...\n`);
                await new Promise(resolve => setTimeout(resolve, delay));
                continue;
            }
            // Clean up partial output file if helper wrote one before error
            try { if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath); } catch (_) {}
            process.stderr.write('[edge-tts-helper] ERROR: ' + err.message + '\n');
            process.exit(1);
        }
    }

    process.stderr.write('[edge-tts-helper] ERROR: Failed after ' + maxAttempts + ' attempts\n');
    process.exit(1);
} catch (err) {
    // Catch any uncaught exceptions from parseArgs or setup
    process.stderr.write('[edge-tts-helper] FATAL ERROR: ' + err.message + '\n');
    process.exit(1);
}

}
main();
