<?php

/**
 * View: Topic Research Lab
 * 
 * @package DIT_TrendStudio
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap ts-wrap">

    <div class="ts-header">
        <h1>Topic Strategy Lab <span class="ts-beta-tag">Premium</span></h1>
        <p>Turn a single keyword into a complete editorial strategy.</p>
    </div>

    <!-- Hero Search -->
    <div class="ts-hero-section">
        <div class="ts-search-wrapper">
            <input type="text" id="ts-topic-input" class="ts-search-input" placeholder="Enter a topic (e.g. 'Fashion', 'Crypto', 'Keto')..." />
            <button id="ts-research-btn" class="ts-search-btn">Analyze Trends & Angles</button>
        </div>

        <!-- Loader (Hidden by default, no is-active class) -->
        <div id="ts-loading-research" class="ts-loader">
            <div class="ts-css-spinner"></div>
            <span>Scanning Google Trends, Autocomplete & Analyzing Intent...</span>
        </div>
    </div>

    <!-- Results Area -->
    <div id="ts-results-area" class="ts-results-area">
        <div class="ts-results-header">
            <h2 style="font-size: 1.5rem; margin:0;">Trend Analysis: <span id="ts-current-topic" style="color:var(--ts-primary);"></span></h2>
            <button class="button" onclick="jQuery('#ts-results-area').hide(); jQuery('.ts-hero-section').removeClass('is-minimized');">New Search</button>
        </div>

        <div id="ts-results-grid" class="ts-results-grid">
            <!-- Filled via JS -->
        </div>
    </div>

    <!-- Strategy Panel (Slide up) -->
    <div id="ts-strategy-panel" class="ts-strategy-panel">
        <div class="ts-panel-header">
            <h3 style="margin:0;">Strategy Blueprint</h3>
            <button class="button button-large" onclick="closeStrategyPanel()">Close Panel</button>
        </div>

        <div class="ts-panel-content">
            <!-- Loader -->
            <div id="ts-loading-strategy" class="ts-loader">
                <div class="ts-css-spinner"></div>
                <span>Architecting content strategy with 200+ ranking factors...</span>
            </div>

            <div id="ts-strategy-content" style="display:none;">
                <div class="ts-blueprint">
                    <h2 id="st-title"></h2>

                    <div class="ts-meta-grid">
                        <div class="ts-meta-item">
                            <strong>Editorial Angle</strong>
                            <span id="st-angle"></span>
                        </div>
                        <div class="ts-meta-item">
                            <strong>Target Audience</strong>
                            <span id="st-audience"></span>
                        </div>
                        <div class="ts-meta-item">
                            <strong>Opportunity Score</strong>
                            <span id="st-opportunity"></span>
                        </div>
                        <div class="ts-meta-item">
                            <strong>Search Intent</strong>
                            <span id="st-intent"></span>
                        </div>
                        <div class="ts-meta-item">
                            <strong>Primary Keyword</strong>
                            <span id="st-keyword"></span>
                        </div>
                    </div>

                    <h4>Why This Works (Hooks)</h4>
                    <ul id="st-hooks" class="ts-section-list" style="margin-bottom: 30px;"></ul>

                    <h4>Structure Blueprint</h4>
                    <ul id="st-structure" class="ts-section-list"></ul>

                    <div style="margin-top: 40px; text-align: center;">
                        <button id="ts-send-to-writer" class="ts-search-btn" style="margin:0; width: 100%;">
                            <span class="dashicons dashicons-edit" style="vertical-align: middle; margin-right:8px;"></span>
                            Create Content Brief
                        </button>
                    </div>
                </div>

                <!-- Hidden Input for Copy -->
                <textarea id="ts-hidden-strategy-json" style="display:none;"></textarea>
            </div>
        </div>
    </div>
</div>

<script>
    jQuery(document).ready(function($) {

        // 1. Research Trigger
        $('#ts-research-btn').on('click', function() {
            const topic = $('#ts-topic-input').val().trim();
            if (!topic) return alert('Please enter a topic');

            // UI Transition
            $(this).prop('disabled', true);
            $('#ts-loading-research').addClass('is-visible'); // Explicit toggle
            $('#ts-results-area').hide();
            $('#ts-current-topic').text(topic);

            $.post(ajaxurl, {
                action: 'dit_ts_research_topic',
                nonce: '<?php echo wp_create_nonce("dit_ts_admin_nonce"); ?>',
                topic: topic
            }, function(response) {
                $('#ts-loading-research').removeClass('is-visible');
                $('#ts-research-btn').prop('disabled', false);

                if (response.success) {
                    renderResults(response.data);
                    $('.ts-hero-section').addClass('is-minimized'); // Animate hero
                } else {
                    alert('Error: ' + response.data);
                }
            });
        });

        // Enter Key Support
        $('#ts-topic-input').on('keypress', function(e) {
            if (e.which == 13) {
                $('#ts-research-btn').click();
            }
        });

        // Render Columns
        function renderResults(data) {
            const grid = $('#ts-results-grid');
            grid.empty();

            if (!data.categories) {
                grid.html('<p>No trends found. Try a different topic.</p>');
                $('#ts-results-area').fadeIn();
                return;
            }

            data.categories.forEach(cat => {
                let html = `<div class="ts-category-col">`;
                html += `<div class="ts-category-title">${cat.name}</div>`;

                cat.ideas.forEach(idea => {
                    const jsonIdea = JSON.stringify(idea).replace(/'/g, "&apos;").replace(/"/g, "&quot;");
                    html += `
                    <div class="ts-card" onclick='generateStrategy(${jsonIdea})'>
                        <div class="ts-card-title">${idea.title}</div>
                        <div class="ts-card-context">${idea.trend_context}</div>
                        <div class="ts-tags-row">
                            <span class="ts-pill ${idea.intent}">${idea.intent}</span>
                            <span class="ts-pill trend">Trend Score: ${idea.search_volume_proxy || 'High'}</span>
                        </div>
                        <button class="button button-small" style="margin-top:10px;">Generate Strategy &rarr;</button>
                    </div>
                `;
                });

                html += `</div>`;
                grid.append(html);
            });

            $('#ts-results-area').fadeIn();
        }

        // 2. Strategy Trigger
        window.generateStrategy = function(nicheData) {
            // Safe Parse if string
            if (typeof nicheData === 'string') {
                nicheData = JSON.parse(nicheData);
            }

            $('#ts-strategy-panel').addClass('is-open');
            $('#ts-loading-strategy').addClass('is-visible');
            $('#ts-strategy-content').hide();

            $.post(ajaxurl, {
                action: 'dit_ts_generate_strategy',
                nonce: '<?php echo wp_create_nonce("dit_ts_admin_nonce"); ?>',
                niche_data: JSON.stringify(nicheData)
            }, function(response) {
                $('#ts-loading-strategy').removeClass('is-visible');

                if (response.success) {
                    renderStrategy(response.data);
                } else {
                    alert('Error generating strategy: ' + response.data);
                }
            });
        };

        window.closeStrategyPanel = function() {
            $('#ts-strategy-panel').removeClass('is-open');
        }

        function renderStrategy(data) {
            const content = $('#ts-strategy-content');

            $('#st-title').text(data.idea_title);
            $('#st-angle').text(data.editorial_persona || data.editorial_angle);
            $('#st-audience').text(data.target_audience);
            $('#st-intent').text(data.search_intent);
            $('#st-keyword').text(data.primary_keyword);
            
            let oppText = (data.opportunity_score || 'N/A').toUpperCase();
            if (data.opportunity_reason) {
                oppText += ' - ' + data.opportunity_reason;
            }
            $('#st-opportunity').text(oppText);

            // Hooks
            const hooksList = $('#st-hooks');
            hooksList.empty();
            if (data.hooks) {
                data.hooks.forEach(hook => {
                    hooksList.append(`<li>${hook}</li>`);
                });
            }

            // Structure
            const structList = $('#st-structure');
            structList.empty();
            if (data.structure_blueprint && data.structure_blueprint.required_sections) {
                $.each(data.structure_blueprint.required_sections, function(key, val) {
                    structList.append(`<li><strong>${key}:</strong> ${val}</li>`);
                });
            }

            // Store for "Send to Writer"
            $('#ts-hidden-strategy-json').val(JSON.stringify(data));

            content.fadeIn();
        }

        // 3. Send to Writer
        $('#ts-send-to-writer').on('click', function() {
            const strategyData = $('#ts-hidden-strategy-json').val();
            if (!strategyData) return;

            localStorage.setItem('dit_ts_prefill_strategy', strategyData);
            window.location.href = 'admin.php?page=dit-trend-studio-generator';
        });
    });
</script>