<?php
/**
 * DIT Video Module — Job_Manager
 *
 * Finds "qualified" posts and queues video generation. A post is qualified when:
 *   - it is DIT-generated (_dit_ts_generated = 1)
 *   - it is published (or set to be published)
 *   - it has at least one usable image
 *   - it has Urdu content assets (heading/description)
 *   - it has not already had a video generated for this content (dedupe)
 *
 * Scheduling reuses Action Scheduler (already bundled with DIT) so it never
 * blocks a request. Every step is logged.
 *
 * @package DIT\TrendStudio\Video
 */

namespace DIT\TrendStudio\Video;

use DIT\TrendStudio\Infrastructure\Logger;

if (!defined('ABSPATH')) {
    exit;
}

class Job_Manager
{
    const HOOK = 'dit_ts_video_generate';
    const QUEUE_META = '_dit_ts_video_queued';

    /** @var Settings */
    protected $settings;

    /** @var Logger */
    protected $logger;

    /** @var Generator */
    protected $generator;

    public function __construct(Settings $settings, Logger $logger, Generator $generator)
    {
        $this->settings  = $settings;
        $this->logger    = $logger;
        $this->generator = $generator;
    }

    /**
     * Register the Action Scheduler handler (call once from Module).
     */
    public function register_hooks(): void
    {
        if (function_exists('as_schedule_single_action')) {
            add_action(self::HOOK, array($this, 'run'), 10, 1);
        }
    }

    /**
     * True if a post is eligible for a video.
     */
    public function is_qualified(int $post_id): bool
    {
        if ((string) get_post_meta($post_id, '_dit_ts_generated', true) !== '1') {
            return false;
        }
        $post = get_post($post_id);
        if (!$post || 'post' !== $post->post_type) {
            return false;
        }
        $status = get_post_status($post_id);
        if (!in_array($status, array('publish', 'future', 'draft'), true)) {
            return false;
        }

        $urdu = trim(wp_strip_all_tags((string) get_post_meta($post_id, '_dit_ts_urdu_heading', true)));
        if ($urdu === '') {
            $urdu = trim(wp_strip_all_tags((string) get_post_meta($post_id, '_dit_ts_urdu_description', true)));
        }
        if ($urdu === '') {
            return false;
        }

        // Must have at least one usable image.
        $thumb = (int) get_post_thumbnail_id($post_id);
        $children = get_children(array(
            'post_parent' => $post_id, 'post_type' => 'attachment',
            'post_mime_type' => 'image', 'fields' => 'ids',
        ));
        if (!$thumb && empty($children)) {
            return false;
        }

        // Dedupe: skip if already generated for this content.
        if (get_post_meta($post_id, '_dit_ts_video_ready', true) === '1') {
            return false;
        }

        return true;
    }

    /**
     * Queue video generation for a post (idempotent via meta).
     */
    public function queue(int $post_id): bool
    {
        if (!$this->settings->is_active()) {
            return false;
        }
        if (!$this->is_qualified($post_id)) {
            return false;
        }
        if (get_post_meta($post_id, self::QUEUE_META, true) === '1') {
            return true; // already queued
        }
        update_post_meta($post_id, self::QUEUE_META, '1');
        $this->logger->info('DIT Video: queued generation for post ' . $post_id);

        if (function_exists('as_schedule_single_action')) {
            as_schedule_single_action(time() + 30, self::HOOK, array($post_id), 'dit-video');
        } else {
            // Fallback: run inline (guarded).
            $this->run($post_id);
        }
        return true;
    }

    /**
     * Action Scheduler callback — run generation for a post.
     */
    public function run(int $post_id): void
    {
        delete_post_meta($post_id, self::QUEUE_META);
        $this->logger->info('DIT Video: running generation for post ' . $post_id);
        $this->generator->generate_for_post($post_id);
    }

    /**
     * Queue a backfill: generate videos for all currently-qualified published posts.
     * Used by a manual "Generate all" button.
     */
    public function queue_all_qualified(int $limit = 20): array
    {
        $posts = get_posts(array(
            'post_type'      => 'post',
            'post_status'    => array('publish', 'future'),
            'posts_per_page' => (int) $limit,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'meta_query'     => array(
                array('key' => '_dit_ts_generated', 'value' => '1'),
            ),
        ));
        $queued = 0;
        foreach ($posts as $p) {
            if ($this->queue((int) $p->ID)) {
                $queued++;
            }
        }
        return array('scanned' => count($posts), 'queued' => $queued);
    }
}
