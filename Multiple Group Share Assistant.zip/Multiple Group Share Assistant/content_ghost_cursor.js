// content_ghost_cursor.js — the "ghost cursor" (v17.3)
//
// A purely cosmetic virtual mouse pointer that mirrors what the automation is
// doing: it glides to each element the share loop is about to touch, flashes a
// blue click ripple, rides the caret while the post text is typed, floats
// organically while the loop is waiting, and finishes with a grow → spin →
// dive flourish when the run ends.
//
// It exists ONLY to make the automation legible ("a human is doing this, and I
// can see exactly what it's clicking"). It therefore obeys three hard rules:
//
//   1. It NEVER touches Facebook. No events are dispatched from here, nothing
//      is focused, nothing is clicked. The real click still comes from
//      content_core.js immediately after the ripple.
//   2. It NEVER blocks. Every public method resolves, always, even if the tab
//      is hidden (requestAnimationFrame stops there), the layer was ripped out
//      of the DOM by a React re-render, or the extension context was
//      invalidated. Awaiting a cosmetic animation must not be able to stall a
//      share — see the watchdog in moveTo() and the visibilitychange settler.
//   3. It NEVER renders outside an automation run. start()/stop() bracket the
//      share loop; when inactive the layer is display:none and the rAF loop is
//      cancelled, so idle Facebook pays nothing.
//
// Disable per-user with chrome.storage.local { ghostCursorDisabled: true }.
// Users with prefers-reduced-motion never see it.
(function () {
  'use strict';

  window.ShareUnlimited = window.ShareUnlimited || {};
  if (window.ShareUnlimited.Ghost) return; // double-injection guard

  // ------------------------------------------------------------------ config
  const LAYER_ID  = 'mgsa-ghost-layer';
  const STYLE_ID  = 'mgsa-ghost-styles';
  const BLUE      = '#0866FF';        // same blue as .su-cb / .su-primary-btn
  const NEAR_PX   = 26;               // already-there radius: press without travelling
  const MIN_MS    = 340;              // never snap
  const MAX_MS    = 1150;             // never crawl
  const IDLE_AMP  = 19;               // px of organic wander while parked
  // The wander amplitude is eased between states rather than switched, so a
  // move never starts with a 19px snap. Slow to swell, quick to get out of the
  // way when the pointer has somewhere to be.
  const IDLE_RISE = 0.03;             // per-frame approach rate, settling into a wander
  const IDLE_FALL = 0.18;             // per-frame approach rate, a move taking over
  const FINALE_MS = 1650;

  // --- Artwork (images/cursor.png) -----------------------------------------
  // The pointer is a bitmap, so the hotspot has to be declared rather than
  // designed in. Measured from the file: the canvas is 272x296, the visible
  // artwork occupies x 4..207 / y 4..245 (the rest is transparent padding),
  // and the apex of the rounded tip sits at pixel (22, 4).
  //
  // ART_W is the rendered width of the WHOLE canvas; the visible arrow comes
  // out ~30px wide, a little larger than a system cursor so the blue icon
  // inside stays legible. TIP_* are that same scale applied to the apex, and
  // are pulled back out as a negative margin so the tip lands exactly on the
  // transform origin — i.e. exactly on the point the ripple is drawn at and
  // the element the share loop is about to click.
  //
  // If the PNG is ever replaced, re-measure all four of these.
  const ART_NAT_W = 272, ART_NAT_H = 296;
  const ART_TIP_X = 22,  ART_TIP_Y = 4;
  const ART_W = 40;
  const ART_SCALE = ART_W / ART_NAT_W;
  const ART_H  = +(ART_NAT_H * ART_SCALE).toFixed(2);
  const TIP_X  = +(ART_TIP_X * ART_SCALE).toFixed(2);
  const TIP_Y  = +(ART_TIP_Y * ART_SCALE).toFixed(2);

  // --- Speech bubble -------------------------------------------------------
  // Comic-book styling: white fill, heavy ink outline, hard offset shadow. The
  // whole shape (rounded body AND tail) is ONE generated SVG path rather than a
  // CSS box plus a border-triangle, because the usual triangle trick has to
  // paint over the body's own border to hide the seam — which only lines up for
  // one corner radius and one tail position. Here the tail is part of the
  // outline, so it can slide along the edge and lean toward the pointer.
  const BUB_MAX_W  = 250;   // px before the text wraps and the bubble grows down
  const BUB_PAD    = 4;     // room inside the SVG for the stroke
  const BUB_TAIL_H = 15;
  const BUB_TAIL_W = 20;
  const BUB_R      = 13;    // corner radius
  const BUB_INK    = '#141414';

  // ------------------------------------------------------------------- state
  let layer = null;   // fixed full-screen container (pointer-events: none)
  let cursor = null;  // translate only — written by the rAF loop
  let tilt = null;    // rotate only — velocity lean
  let fx = null;      // scale/spin — CSS keyframes (materialise, press, finale)

  let bubble = null, bubbleIn = null, bubbleShape = null, bubblePath = null, bubbleText = null;
  let bubbleOn = false;
  let bubbleMsg = '';
  const bubbleBox = { w: 0, h: 0 };          // measured text box
  const bubblePos = { x: 0, y: 0, set: false }; // sprung screen position
  let bubbleBelow = false;
  let lastPathKey = '';

  let active = false;
  let rafId = null;
  let finaleOn = false;
  let optedOut = false;

  // Logical tip position, in viewport px, BEFORE the idle drift is added.
  const pos = { x: 0, y: 0 };
  // Where the tip actually ended up on screen this frame (pos + drift). Click
  // ripples MUST be drawn here, not at `pos` — while the pointer is parked the
  // wander carries it up to IDLE_AMP away, and a ripple at the logical position
  // would visibly miss the cursor.
  const render = { x: 0, y: 0 };
  let ampCur = 0;         // eased wander amplitude, 0..1

  // In-flight travel tween (quadratic Bézier so the path arcs instead of
  // running dead straight — a straight line is the thing that reads as a robot).
  const tw = { on: false, seq: 0, x0: 0, y0: 0, cx: 0, cy: 0, x1: 0, y1: 0, t0: 0, dur: 0, resolve: null };
  let arcSign = 1;

  let follow = null;      // () => {x, y} | null — caret-follow while typing
  let lastDrawX = 0;
  let tiltDeg = 0;

  // Where the user's real pointer was last seen, so the ghost materialises
  // under their actual cursor instead of teleporting in from nowhere.
  const pointer = { x: 0, y: 0, seen: false };

  // ------------------------------------------------------------------ helpers
  function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }

  // Minimum-jerk profile — the standard model of a natural human reaching
  // movement. Gentler in and out than any cubic/quint ease, and it never has a
  // fast segment in the middle, which is exactly the brief.
  function minJerk(t) { return t * t * t * (10 + t * (-15 + 6 * t)); }

  function reducedMotion() {
    try {
      return !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
    } catch (e) { return false; }
  }

  function waitMs(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  try {
    window.addEventListener('mousemove', (e) => {
      pointer.x = e.clientX; pointer.y = e.clientY; pointer.seen = true;
    }, { passive: true, capture: true });
  } catch (e) { /* non-fatal */ }

  try {
    chrome.storage.local.get(['ghostCursorDisabled'], (r) => {
      if (chrome.runtime.lastError) return;
      optedOut = !!(r && r.ghostCursorDisabled);
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes.ghostCursorDisabled) {
        optedOut = !!changes.ghostCursorDisabled.newValue;
        if (optedOut && active) stop({ finale: false });
      }
    });
  } catch (e) { /* storage unavailable — default to enabled */ }

  // -------------------------------------------------------------------- DOM
  function ensureStyles() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement('style');
    style.id = STYLE_ID;
    style.textContent = `
      #${LAYER_ID}{
        position:fixed !important; inset:0 !important; z-index:2147483647 !important;
        pointer-events:none !important; overflow:hidden !important;
        contain:layout style !important;
      }
      #${LAYER_ID} *{ pointer-events:none !important; user-select:none !important; }

      .mgsa-ghost{
        position:absolute !important; left:0 !important; top:0 !important;
        width:0 !important; height:0 !important;
        opacity:0; transition:opacity 200ms ease-out;
        will-change:transform;
      }
      .mgsa-ghost.is-visible{ opacity:1; }
      .mgsa-ghost__tilt{ position:absolute; left:0; top:0; transform-origin:0 0; }
      .mgsa-ghost__fx{ position:absolute; left:0; top:0; transform-origin:0 0; }
      /* Negative margin = the measured tip offset, pulled back out so the
         artwork's tip apex sits on the transform origin. See ART_* above. */
      .mgsa-ghost__art{
        display:block !important;
        width:${ART_W}px !important; height:${ART_H}px !important;
        margin:${-TIP_Y}px 0 0 ${-TIP_X}px !important;
        /* the PNG carries its own soft shadow, so this only lifts it off busy
           feed content — heavier and it doubles up */
        filter:drop-shadow(0 2px 5px rgba(0,0,0,.34));
      }
      /* fallback arrow only — its tip offset comes from the padded viewBox */
      .mgsa-ghost__svg{
        display:block !important; margin:-2.17px 0 0 -2.19px !important;
        filter:drop-shadow(0 3px 6px rgba(0,0,0,.42));
      }
      /* soft blue halo — "something is driving this" without shouting.
         Offset to sit under the body of the arrow, not the tip. */
      .mgsa-ghost__glow{
        position:absolute; left:0; top:0; width:56px; height:56px; margin:-10px 0 0 -16px;
        border-radius:50%; background:radial-gradient(circle, rgba(8,102,255,.34) 0%, rgba(8,102,255,.13) 45%, rgba(8,102,255,0) 72%);
        animation:mgsa-ghost-breathe 2600ms ease-in-out infinite;
      }
      @keyframes mgsa-ghost-breathe{
        0%,100%{ transform:scale(.86); opacity:.55; }
        50%    { transform:scale(1.08); opacity:.95; }
      }

      /* materialise under the user's real pointer */
      .mgsa-ghost__fx.is-in{ animation:mgsa-ghost-in 340ms cubic-bezier(.18,.9,.3,1.3) both; }
      @keyframes mgsa-ghost-in{
        0%  { transform:scale(.3) rotate(-18deg); }
        100%{ transform:scale(1) rotate(0deg); }
      }

      /* click press — the pointer dips into the surface */
      .mgsa-ghost__fx.is-press{ animation:mgsa-ghost-press 240ms cubic-bezier(.3,.8,.3,1) both; }
      @keyframes mgsa-ghost-press{
        0%  { transform:scale(1); }
        34% { transform:scale(.82) translate(1px,1px); }
        100%{ transform:scale(1); }
      }

      /* finale: grow → spin → dive into the page */
      .mgsa-ghost__fx.is-finale{ animation:mgsa-ghost-finale ${FINALE_MS}ms both; }
      @keyframes mgsa-ghost-finale{
        0%  { transform:scale(1) rotate(0deg) translateY(0); opacity:1; filter:blur(0px);
              animation-timing-function:cubic-bezier(.2,.9,.25,1.4); }
        19% { transform:scale(2.05) rotate(0deg) translateY(-14px);
              animation-timing-function:cubic-bezier(.45,0,.55,1); }
        27% { transform:scale(1.95) rotate(-28deg) translateY(-14px);
              animation-timing-function:cubic-bezier(.4,0,.15,1); }
        68% { transform:scale(2.15) rotate(690deg) translateY(-20px);
              animation-timing-function:cubic-bezier(.55,-.35,.9,.4); }
        77% { transform:scale(2.32) rotate(772deg) translateY(-27px); opacity:1; filter:blur(0px);
              animation-timing-function:cubic-bezier(.72,0,.9,.32); }
        100%{ transform:scale(.04) rotate(1090deg) translateY(38px); opacity:0; filter:blur(3px); }
      }

      /* Click ripple. Four layers, all centred on the cursor tip: a soft glow
         flash for visibility against busy feed content, a solid dot that pops,
         and two expanding rings (the second an echo) that carry the click far
         enough out to be unmissable. The white box-shadow edge on the dot and
         ring is what keeps it legible when the click lands on one of Facebook's
         own blue buttons — pure blue on blue would disappear. */
      .mgsa-ghost-rip{ position:absolute; left:0; top:0; width:0; height:0; }
      .mgsa-ghost-rip__flash{
        position:absolute; left:0; top:0; width:104px; height:104px; margin:-52px 0 0 -52px;
        border-radius:50%;
        background:radial-gradient(circle, rgba(8,102,255,.62) 0%, rgba(8,102,255,.28) 38%, rgba(8,102,255,0) 70%);
        animation:mgsa-ghost-flash 460ms cubic-bezier(.2,.75,.3,1) forwards;
      }
      @keyframes mgsa-ghost-flash{
        0%  { transform:scale(.25); opacity:.95; }
        100%{ transform:scale(1.6); opacity:0; }
      }
      .mgsa-ghost-rip__dot{
        position:absolute; left:0; top:0; width:30px; height:30px; margin:-15px 0 0 -15px;
        border-radius:50%; background:${BLUE};
        box-shadow:0 0 0 2px rgba(255,255,255,.9), 0 0 26px rgba(8,102,255,.95);
        animation:mgsa-ghost-dot 300ms cubic-bezier(.2,.7,.3,1) forwards;
      }
      @keyframes mgsa-ghost-dot{
        0%  { transform:scale(.16); opacity:.9; }
        60% { transform:scale(1.25); opacity:.55; }
        100%{ transform:scale(1.85); opacity:0; }
      }
      .mgsa-ghost-rip__ring{
        position:absolute; left:0; top:0; width:34px; height:34px; margin:-17px 0 0 -17px;
        border-radius:50%; border:4px solid ${BLUE};
        box-shadow:0 0 20px rgba(8,102,255,.9), 0 0 0 1.5px rgba(255,255,255,.75),
                   inset 0 0 12px rgba(8,102,255,.55);
        animation:mgsa-ghost-ring 640ms cubic-bezier(.15,.85,.32,1) forwards;
      }
      @keyframes mgsa-ghost-ring{
        0%  { transform:scale(.28); opacity:1; }
        100%{ transform:scale(3.7); opacity:0; }
      }
      .mgsa-ghost-rip__ring2{
        position:absolute; left:0; top:0; width:34px; height:34px; margin:-17px 0 0 -17px;
        border-radius:50%; border:2.5px solid rgba(70,150,255,.95);
        box-shadow:0 0 14px rgba(8,102,255,.7);
        animation:mgsa-ghost-ring 660ms cubic-bezier(.15,.85,.32,1) 150ms forwards;
        opacity:0;
      }
      /* landing shockwave for the finale — same anatomy, scaled up */
      .mgsa-ghost-rip.is-burst .mgsa-ghost-rip__ring{
        width:50px; height:50px; margin:-25px 0 0 -25px; border-width:5px;
        animation-duration:900ms;
      }
      .mgsa-ghost-rip.is-burst .mgsa-ghost-rip__ring2{
        width:50px; height:50px; margin:-25px 0 0 -25px;
        animation-duration:920ms;
      }
      .mgsa-ghost-rip.is-burst .mgsa-ghost-rip__flash{
        width:150px; height:150px; margin:-75px 0 0 -75px; animation-duration:700ms;
      }
      .mgsa-ghost-rip.is-burst .mgsa-ghost-rip__dot{ display:none; }

      /* ---- speech bubble ---- */
      .mgsa-ghost-bubble{
        position:absolute !important; left:0 !important; top:0 !important;
        max-width:${BUB_MAX_W}px !important;
        will-change:transform;
      }
      .mgsa-ghost-bubble__in{
        position:relative; display:block;
        transform-origin:24px 100%;          /* pop out of the tail, not the middle */
        opacity:0;
      }
      .mgsa-ghost-bubble.is-below .mgsa-ghost-bubble__in{ transform-origin:24px 0%; }
      .mgsa-ghost-bubble__shape{
        position:absolute !important; left:${-BUB_PAD}px; top:${-BUB_PAD}px;
        overflow:visible !important;
        filter:drop-shadow(2px 3px 0 rgba(0,0,0,.72));
      }
      .mgsa-ghost-bubble__text{
        position:relative; display:block;
        max-width:${BUB_MAX_W}px;
        padding:9px 14px 10px 14px;
        font:700 13.5px/1.36 "Segoe UI", Helvetica, Arial, sans-serif !important;
        color:${BUB_INK} !important; letter-spacing:.1px;
        text-align:left !important;
        /* group names can be Hebrew/Arabic; isolate keeps them from reordering
           the English around them (they are wrapped in FSI/PDI at source too) */
        direction:ltr !important; unicode-bidi:isolate !important;
        overflow-wrap:break-word; word-break:normal; white-space:pre-wrap;
        text-shadow:none !important;
      }
      .mgsa-ghost-bubble__in.is-enter{ animation:mgsa-bub-in 320ms cubic-bezier(.2,.9,.28,1.42) both; }
      @keyframes mgsa-bub-in{
        0%  { opacity:0; transform:scale(.35) translateY(6px); }
        70% { opacity:1; transform:scale(1.06); }
        100%{ opacity:1; transform:scale(1); }
      }
      /* text changed while already open — a nudge, not a re-entrance */
      .mgsa-ghost-bubble__in.is-pop{ animation:mgsa-bub-pop 260ms cubic-bezier(.25,.85,.3,1.3) both; }
      @keyframes mgsa-bub-pop{
        0%  { opacity:1; transform:scale(1); }
        38% { opacity:1; transform:scale(1.075); }
        100%{ opacity:1; transform:scale(1); }
      }
      .mgsa-ghost-bubble__in.is-out{ animation:mgsa-bub-out 200ms ease-in both; }
      @keyframes mgsa-bub-out{
        0%  { opacity:1; transform:scale(1); }
        100%{ opacity:0; transform:scale(.7) translateY(4px); }
      }

      @media (prefers-reduced-motion: reduce){ #${LAYER_ID}{ display:none !important; } }
    `;
    (document.head || document.documentElement).appendChild(style);
  }

  // Last-resort pointer for when images/cursor.png can't be loaded. Same
  // contract as the PNG: tip at the transform origin, readable on FB light and
  // FB dark. Not the shipped look — just never an invisible cursor.
  function buildFallbackArrow() {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('class', 'mgsa-ghost__svg');
    svg.setAttribute('viewBox', '-1.4 -1.4 16 22');
    svg.setAttribute('width', '25');
    svg.setAttribute('height', '34');
    const poly = document.createElementNS('http://www.w3.org/2000/svg', 'polygon');
    poly.setAttribute('points', '0,0 0,16.5 4.2,12.6 6.9,18.6 9.6,17.4 6.9,11.4 11.7,11.4');
    poly.setAttribute('fill', '#ffffff');
    poly.setAttribute('stroke', 'rgba(20,22,26,.72)');
    poly.setAttribute('stroke-width', '1.25');
    poly.setAttribute('stroke-linejoin', 'round');
    svg.appendChild(poly);
    return svg;
  }

  function ensureLayer() {
    ensureStyles();
    if (layer && document.body && document.body.contains(layer)) return layer;

    layer = document.createElement('div');
    layer.id = LAYER_ID;
    layer.setAttribute('aria-hidden', 'true');
    layer.style.display = 'none';

    cursor = document.createElement('div');
    cursor.className = 'mgsa-ghost';

    tilt = document.createElement('div');
    tilt.className = 'mgsa-ghost__tilt';

    fx = document.createElement('div');
    fx.className = 'mgsa-ghost__fx';

    const glow = document.createElement('div');
    glow.className = 'mgsa-ghost__glow';

    // The artwork: images/cursor.png, positioned so its tip apex lands on the
    // transform origin (see ART_* / .mgsa-ghost__art). It has to be resolved
    // through chrome.runtime.getURL — a content script can't reference packed
    // files by relative path — which means it also has to survive that failing.
    let url = null;
    try { url = chrome.runtime.getURL('images/cursor.png'); } catch (e) { url = null; }

    let art;
    if (url) {
      art = document.createElement('img');
      art.className = 'mgsa-ghost__art';
      art.alt = '';
      art.draggable = false;
      // If the asset can't load (dropped from the package, or the extension
      // context was invalidated by a reload) swap in the drawn arrow rather
      // than running the whole automation behind an invisible pointer.
      art.addEventListener('error', function () {
        if (art.parentNode) art.parentNode.replaceChild(buildFallbackArrow(), art);
      });
      art.src = url;
    } else {
      art = buildFallbackArrow();
    }

    fx.appendChild(glow);
    fx.appendChild(art);
    tilt.appendChild(fx);
    cursor.appendChild(tilt);

    bubble = document.createElement('div');
    bubble.className = 'mgsa-ghost-bubble';
    bubbleIn = document.createElement('div');
    bubbleIn.className = 'mgsa-ghost-bubble__in';
    bubbleShape = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    bubbleShape.setAttribute('class', 'mgsa-ghost-bubble__shape');
    bubblePath = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    bubblePath.setAttribute('fill', '#ffffff');
    bubblePath.setAttribute('stroke', BUB_INK);
    bubblePath.setAttribute('stroke-width', '3');
    bubblePath.setAttribute('stroke-linejoin', 'round');
    bubbleShape.appendChild(bubblePath);
    bubbleText = document.createElement('div');
    bubbleText.className = 'mgsa-ghost-bubble__text';
    bubbleIn.appendChild(bubbleShape);
    bubbleIn.appendChild(bubbleText);
    bubble.appendChild(bubbleIn);
    bubble.style.display = 'none';

    layer.appendChild(bubble);
    layer.appendChild(cursor);
    (document.body || document.documentElement).appendChild(layer);
    return layer;
  }

  // ---------------------------------------------------------- speech bubble
  // One closed path: rounded body, with the tail cut into whichever edge faces
  // the pointer. `tipX` is where the tail's point goes (clamped near its base),
  // which is what lets the tail lean toward the cursor as the bubble trails it.
  function buildBubblePath(w, h, tipX, below) {
    const P = BUB_PAD, R = BUB_R, TH = BUB_TAIL_H, TW = BUB_TAIL_W;
    const top = below ? P + TH : P;
    const bot = top + h;
    // Tail base, kept clear of both rounded corners.
    const lo = P + R + 3, hi = P + w - R - 3;
    let b1 = clamp(tipX - TW / 2, lo, Math.max(lo, hi - TW));
    let b2 = Math.min(b1 + TW, hi);
    const px = clamp(tipX, b1 - 16, b2 + 16);
    const d = [];
    d.push('M', P + R, top);
    if (below) {
      d.push('H', b1, 'L', px, top - TH, 'L', b2, top);
    }
    d.push('H', P + w - R);
    d.push('A', R, R, 0, 0, 1, P + w, top + R);
    d.push('V', bot - R);
    d.push('A', R, R, 0, 0, 1, P + w - R, bot);
    if (!below) {
      d.push('H', b2, 'L', px, bot + TH, 'L', b1, bot);
    }
    d.push('H', P + R);
    d.push('A', R, R, 0, 0, 1, P, bot - R);
    d.push('V', top + R);
    d.push('A', R, R, 0, 0, 1, P + R, top);
    d.push('Z');
    return d.join(' ');
  }

  // Forces layout, so it runs ONLY on a text change — never from the rAF loop.
  function measureBubble() {
    const w = Math.ceil(bubbleText.offsetWidth);
    const h = Math.ceil(bubbleText.offsetHeight);
    if (w && h) { bubbleBox.w = w; bubbleBox.h = h; }
  }

  // Repaints the outline from the cached box. Runs per frame, but the key check
  // means it only actually touches the DOM when the tail has moved a whole px.
  function paintBubble(tipX) {
    const w = bubbleBox.w, h = bubbleBox.h;
    if (!w || !h) return;
    const key = w + ':' + h + ':' + Math.round(tipX) + ':' + (bubbleBelow ? 1 : 0);
    if (key === lastPathKey) return;
    lastPathKey = key;
    const sw = w + BUB_PAD * 2;
    const sh = h + BUB_PAD * 2 + BUB_TAIL_H;
    bubbleShape.setAttribute('width', sw);
    bubbleShape.setAttribute('height', sh);
    bubbleShape.setAttribute('viewBox', '0 0 ' + sw + ' ' + sh);
    bubbleShape.style.top = (bubbleBelow ? -(BUB_PAD + BUB_TAIL_H) : -BUB_PAD) + 'px';
    bubblePath.setAttribute('d', buildBubblePath(w, h, tipX, bubbleBelow));
  }

  // A falsy `cls` just clears any running animation — used for a quiet text
  // swap, where re-adding a class would restart the bounce.
  function playBubbleFx(cls, ms) {
    if (!bubbleIn) return;
    bubbleIn.classList.remove('is-enter', 'is-pop', 'is-out');
    if (!cls) return;
    void bubbleIn.offsetWidth;
    bubbleIn.classList.add(cls);
    if (ms) setTimeout(() => { if (bubbleIn) bubbleIn.classList.remove(cls); }, ms);
  }

  function say(text, quiet) {
    if (!active || !bubble) return;
    text = String(text == null ? '' : text);
    if (!text) return hush();
    if (text === bubbleMsg && bubbleOn) return;   // loops call this every tick
    const wasOn = bubbleOn;
    bubbleMsg = text;
    bubbleText.textContent = text;
    bubbleOn = true;
    bubble.style.display = 'block';
    // A fresh bubble is placed outright, not sprung in from wherever the last
    // one ended, so it can never flash across the screen or appear at 0,0.
    if (!wasOn) bubblePos.set = false;
    measureBubble();
    lastPathKey = '';
    layoutBubble();
    // The base rule is opacity:0; the entrance/pop animations only cover their
    // own duration, so the resting state has to be pinned inline.
    bubbleIn.style.opacity = '1';
    // `quiet` swaps the text in place with no bounce. The countdown re-says
    // itself once a second; popping on every tick turns a calm "I'm waiting on
    // purpose" into a nervous twitch.
    if (wasOn && quiet) playBubbleFx(null, 0);
    else playBubbleFx(wasOn ? 'is-pop' : 'is-enter', wasOn ? 280 : 340);
  }

  function hush() {
    if (!bubbleOn) return;
    bubbleOn = false;
    bubbleMsg = '';
    playBubbleFx('is-out', 0);
    setTimeout(() => {
      if (!bubbleOn && bubble) { bubble.style.display = 'none'; bubbleIn.style.opacity = '0'; }
    }, 210);
  }

  // Keeps the bubble beside the pointer: prefers up-and-right, flips left near
  // the right edge and below near the top, and springs rather than snapping so
  // it trails the cursor like a held sign. The tail slides along the edge to
  // keep pointing at the cursor even while the body is still catching up.
  function layoutBubble() {
    if (!bubbleOn || !bubble) return;
    const w = bubbleBox.w, h = bubbleBox.h;
    const vw = window.innerWidth, vh = window.innerHeight;
    const cx = render.x, cy = render.y;

    let bx = cx + 18;
    if (bx + w > vw - 12) bx = cx - w - 12;
    bx = clamp(bx, 12, Math.max(12, vw - w - 12));

    let by = cy - h - 22;
    const below = by < 12 + BUB_TAIL_H;
    if (below) by = cy + 30;
    by = clamp(by, 12 + (below ? BUB_TAIL_H : 0), Math.max(12, vh - h - 12 - BUB_TAIL_H));

    if (!bubblePos.set) { bubblePos.x = bx; bubblePos.y = by; bubblePos.set = true; }
    else { bubblePos.x += (bx - bubblePos.x) * 0.24; bubblePos.y += (by - bubblePos.y) * 0.24; }

    if (below !== bubbleBelow) { bubbleBelow = below; lastPathKey = ''; }
    bubble.classList.toggle('is-below', below);
    bubble.style.transform =
      'translate3d(' + bubblePos.x.toFixed(1) + 'px,' + bubblePos.y.toFixed(1) + 'px,0)';

    // +BUB_PAD: the SVG's origin sits that far left of the text box, and the
    // path is authored in SVG coordinates.
    paintBubble(cx - bubblePos.x + BUB_PAD);
  }

  // ------------------------------------------------------------ render loop
  function frame(now) {
    if (!active) { rafId = null; return; }
    rafId = requestAnimationFrame(frame);

    if (tw.on) {
      const t = tw.dur > 0 ? Math.min(1, (now - tw.t0) / tw.dur) : 1;
      const e = minJerk(t);
      const u = 1 - e;
      pos.x = u * u * tw.x0 + 2 * u * e * tw.cx + e * e * tw.x1;
      pos.y = u * u * tw.y0 + 2 * u * e * tw.cy + e * e * tw.y1;
      if (t >= 1) endTween();
    } else if (follow) {
      const p = follow();
      if (p) {
        // Spring toward the caret rather than tweening — the caret moves every
        // few ms while typing, so a tween would restart forever.
        pos.x += (p.x - pos.x) * 0.32;
        pos.y += (p.y - pos.y) * 0.32;
      }
    }

    // Organic wander, in three octaves per axis: a slow drift that carries the
    // pointer a real distance, a mid sway, and a fast micro-tremor so it is
    // never frozen even at the turning points of the slow one. The periods are
    // deliberately incommensurate, so the path never visibly repeats.
    //
    // Amplitude is scaled by what the pointer is doing: full wander only while
    // genuinely parked, a tremor while travelling, and heavily damped while
    // following the caret (a ±19px wobble there would smear the "it's typing
    // this" illusion the follow exists for). Eased, never switched — see
    // IDLE_RISE/IDLE_FALL.
    const ampTarget = finaleOn ? 0 : (tw.on ? 0.06 : (follow ? 0.14 : 1));
    ampCur += (ampTarget - ampCur) * (ampTarget < ampCur ? IDLE_FALL : IDLE_RISE);
    const amp = IDLE_AMP * ampCur;

    const x = pos.x + amp * (
      Math.sin(now / 2630)       * 0.60 +
      Math.sin(now / 1070 + 1.7) * 0.29 +
      Math.sin(now / 337  + 0.4) * 0.11
    );
    const y = pos.y + amp * (
      Math.sin(now / 3190 + 0.8) * 0.58 +
      Math.sin(now / 1290 + 2.6) * 0.30 +
      Math.sin(now / 291  + 1.9) * 0.12
    );

    // Lean into the direction of travel, plus a slow sway of its own so even a
    // parked pointer reads as hand-held rather than pinned to the page.
    const sway = amp * 0.16 * Math.sin(now / 2210 + 0.5);
    tiltDeg += ((clamp((x - lastDrawX) * 0.85, -9, 9) + sway) - tiltDeg) * 0.18;
    lastDrawX = x;

    render.x = x; render.y = y;
    cursor.style.transform = 'translate3d(' + x.toFixed(2) + 'px,' + y.toFixed(2) + 'px,0)';
    tilt.style.transform = 'rotate(' + tiltDeg.toFixed(2) + 'deg)';
    layoutBubble();
  }

  function endTween() {
    tw.on = false;
    const r = tw.resolve;
    tw.resolve = null;
    if (r) r();
  }

  // Jump an in-flight tween to its destination and resolve its promise. Called
  // whenever a new movement supersedes it, and whenever the tab goes hidden
  // (rAF stops dead there, so without this an await would never return).
  function settleTween() {
    if (!tw.on) return;
    pos.x = tw.x1; pos.y = tw.y1;
    endTween();
  }

  try {
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) settleTween();
    });
  } catch (e) { /* non-fatal */ }

  // ------------------------------------------------------------- primitives
  function elPoint(el) {
    if (!el || typeof el.getBoundingClientRect !== 'function') return null;
    let r;
    try { r = el.getBoundingClientRect(); } catch (e) { return null; }
    if (!r || (!r.width && !r.height)) return null;
    const vw = window.innerWidth, vh = window.innerHeight;
    if (r.bottom < 0 || r.top > vh || r.right < 0 || r.left > vw) return null;
    // Aim slightly off dead-centre; humans never hit the exact middle twice.
    const jx = (Math.random() - 0.5) * Math.min(r.width * 0.34, 26);
    const jy = (Math.random() - 0.5) * Math.min(r.height * 0.34, 14);
    return {
      x: clamp(r.left + r.width / 2 + jx, 3, vw - 3),
      y: clamp(r.top + r.height / 2 + jy, 3, vh - 3)
    };
  }

  // Where the text caret currently is, so the pointer can ride along the line
  // as the post (and the watermark) is typed character by character.
  function caretPoint(el) {
    try {
      const sel = window.getSelection();
      if (sel && sel.rangeCount) {
        const range = sel.getRangeAt(0);
        if (el === range.startContainer || el.contains(range.startContainer)) {
          let rect = range.getBoundingClientRect();
          if (!rect || (!rect.height && !rect.width)) {
            const rects = range.getClientRects();
            if (rects && rects.length) rect = rects[rects.length - 1];
          }
          if (rect && (rect.height || rect.width)) return { x: rect.left, y: rect.top };
        }
      }
    } catch (e) { /* fall through */ }

    // Chrome can hand back an empty rect for a collapsed range, so measure the
    // last laid-out character instead — the trailing edge of the typed text is
    // where the caret is, which is the whole point of following it.
    try {
      const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT, null);
      let last = null, node;
      while ((node = walker.nextNode())) {
        if (node.nodeValue && node.nodeValue.length) last = node;
      }
      if (last) {
        const range = document.createRange();
        range.setStart(last, last.nodeValue.length - 1);
        range.setEnd(last, last.nodeValue.length);
        const rects = range.getClientRects();
        if (rects && rects.length) {
          const r = rects[rects.length - 1];
          return { x: r.right, y: r.top };
        }
      }
    } catch (e) { /* fall through */ }

    // Empty editor — sit at the start of the first line.
    try {
      const rects = el.getClientRects();
      if (rects && rects.length) {
        const r = rects[0];
        return { x: Math.min(r.right - 6, r.left + 10), y: r.top + 4 };
      }
    } catch (e) { /* fall through */ }
    return null;
  }

  function moveTo(x, y, opts) {
    opts = opts || {};
    if (!active) return Promise.resolve();
    follow = null;
    settleTween();

    // A hidden tab has no rAF, so there is nothing to animate and nothing to
    // wait for — teleport silently and let the share loop carry on.
    if (document.hidden) { pos.x = x; pos.y = y; return Promise.resolve(); }

    const dist = Math.hypot(x - pos.x, y - pos.y);
    if (!opts.force && dist < (opts.near == null ? NEAR_PX : opts.near)) {
      pos.x = x; pos.y = y;
      return Promise.resolve();
    }

    const dur = opts.duration || clamp(340 + Math.pow(dist, 0.78) * 3.2, MIN_MS, MAX_MS);
    const nx = -(y - pos.y) / (dist || 1);
    const ny = (x - pos.x) / (dist || 1);
    arcSign = -arcSign;
    const bow = clamp(dist * 0.14, 0, 68) * arcSign;

    tw.x0 = pos.x; tw.y0 = pos.y;
    tw.x1 = x;     tw.y1 = y;
    tw.cx = (pos.x + x) / 2 + nx * bow;
    tw.cy = (pos.y + y) / 2 + ny * bow;
    tw.t0 = performance.now();
    tw.dur = dur;
    tw.on = true;
    const seq = ++tw.seq;

    return new Promise(resolve => {
      tw.resolve = resolve;
      // Watchdog. rAF can stop (hidden tab, background throttling) and this
      // promise is awaited by the share loop — it must not be possible to hang.
      setTimeout(() => { if (tw.on && tw.seq === seq) settleTween(); }, dur + 450);
    });
  }

  function ripple(x, y, isBurst) {
    if (!layer) return;
    const rip = document.createElement('div');
    rip.className = 'mgsa-ghost-rip' + (isBurst ? ' is-burst' : '');
    rip.style.transform = 'translate3d(' + x.toFixed(1) + 'px,' + y.toFixed(1) + 'px,0)';
    // Painted back to front: glow, echo ring, main ring, dot.
    ['flash', 'ring2', 'ring', 'dot'].forEach(part => {
      const span = document.createElement('span');
      span.className = 'mgsa-ghost-rip__' + part;
      rip.appendChild(span);
    });
    layer.appendChild(rip);
    // Outlives the click itself on purpose — the ripple lives in our own layer,
    // so it stays readable even after Facebook has swapped the dialog underneath.
    setTimeout(() => { if (rip.parentNode) rip.parentNode.removeChild(rip); }, isBurst ? 1000 : 850);
  }

  function playFx(cls, ms) {
    if (!fx) return;
    fx.classList.remove('is-in', 'is-press');
    void fx.offsetWidth; // restart the animation
    fx.classList.add(cls);
    setTimeout(() => { if (fx) fx.classList.remove(cls); }, ms);
  }

  // ------------------------------------------------------------- narration
  // Every line the pointer says, in one place — this is the file to edit for
  // copy, not content_core.js, which only ever names a key and passes data.
  //
  // Voice: first person, doing the work FOR the user, a little proud of itself.
  // The waiting line matters most: a long silent pause is the moment a user
  // decides something has hung, so the pause has to explain that it is
  // deliberate (and why it keeps their account safe).
  //
  // Group names are wrapped in FSI/PDI (U+2068/U+2069) so a Hebrew or Arabic
  // name can't reorder the English sentence around it.
  function q(name) {
    return '“⁨' + String(name == null ? '' : name) + '⁩”';
  }

  // A post is not a group name: it can be 500 characters over eight lines. The
  // preview is flattened to one line and clipped, because the bubble grows DOWN
  // past BUB_MAX_W and an un-clipped post would cover the composer it is
  // describing. Clipped at a word boundary where one is near the cut.
  const PREVIEW_MAX = 90;
  function preview(text) {
    const flat = String(text == null ? '' : text).replace(/\s+/g, ' ').trim();
    if (flat.length <= PREVIEW_MAX) return flat;
    const cut = flat.slice(0, PREVIEW_MAX);
    const sp = cut.lastIndexOf(' ');
    return (sp > PREVIEW_MAX - 18 ? cut.slice(0, sp) : cut).trimEnd() + '…';
  }

  const LINES = {
    start: d => d.total >= 15
      ? `Woah — ${d.total} groups! That's a lot of work. Let's get started 💪`
      : `${d.total} group${d.total === 1 ? '' : 's'} to share to. Let's go! 🚀`,
    find:       d => `Group ${d.index}/${d.total} — I need to find ${q(d.name)}`,
    searching:  d => `Searching for ${q(d.name)}…`,
    scrolling:  'Scrolling through your groups to find it…',
    found:      d => `Found it! Clicking ${q(d.name)} now 👆`,
    notFound:   d => `Hmm — I can't find ${q(d.name)} on this profile. Skipping it.`,
    reopen:     'Opening the Share menu again…',
    groupMenu:  'Looking for the "Group" option…',
    // Shown BEFORE a single character is typed, during the wait that was already
    // there while the composer opens. Nothing may appear in the user's box that
    // they weren't shown first — the watermark included, and especially when AI
    // variants mean this group's wording differs from the last one's.
    willType: d => {
      // `text` is the CAPTION ONLY — the signature/watermark arrives separately,
      // because quoting the joined string showed the watermark inside the user's
      // own sentence (its blank line collapses to a space in a one-line preview)
      // and then announced it a second time underneath.
      const caption = preview(d.text);
      const sig = preview(d.signature);
      // The watermark is OURS, the sign-off is THEIRS — the possessive is not
      // interchangeable. A free user with their own sign-off gets both named.
      const addOn = d.watermark
        ? (d.ownSignature ? 'your signature and our watermark' : 'our watermark')
        : 'your signature';

      if (!caption) {
        return sig
          ? `Your post has no text, so I'm only adding ${addOn}:\n${q(sig)}`
          : 'No text for this one — posting it as it is.';
      }

      const head = d.variants > 1
        ? `Variant ${d.variant} of ${d.variants} — about to type this in the box:`
        : 'About to type this in the box:';
      // Named rather than quoted: it lands at the END of the text, which is
      // exactly the part a clipped preview cuts off.
      const tail = sig ? `\n…then ${addOn} on the line below.` : '';
      return `${head}\n${q(caption)}${tail}`;
    },
    typing:     'Writing your post…',
    posting:    d => `Alright — hitting Post on ${q(d.name)} 📮`,
    posted:     d => `Posted to ${q(d.name)}! ✅`,
    scheduling: d => `Scheduling this one for ${d.date}, ${d.time} 📅`,
    scheduled:  d => `Scheduled for ${q(d.name)}! ✅`,
    duplicate:  d => `I've already posted to ${q(d.name)} this run — skipping it so you don't get flagged 🛡️`,
    audience:   d => `That composer wasn't pointing at ${q(d.name)} — backing out to keep you safe 🛡️`,
    postFail:   d => `The Post button never showed up for ${q(d.name)}. Moving on.`,
    nextUp:     d => `Up next: group ${d.index}/${d.total} — ${q(d.name)}`,
    wait:       d => `Waiting ${d.seconds}s so I look like a human sharing for you 😉`,
    // v18.0: said when the run comes back from a pause (locked screen, other tab).
    // The user has just returned and needs to know instantly that nothing was lost —
    // this is the first thing they read, before the overlay's own paused row.
    resumed:    d => `Welcome back! Nothing was lost — picking up at group ${d.index}/${d.total} 👍`,
    done: d => d.ok
      ? `All done — shared to all ${d.total} of them 🎉 Nice one!`
      : `Finished: ${d.success}/${d.total} shared. Check the list for the rest.`,
    cancelled:  'Stopped — no more posts from me 👌'
  };

  // Stages that re-say themselves on a timer, and so must not re-animate.
  const QUIET = { wait: true };

  function narrate(key, data) {
    const line = LINES[key];
    if (line == null) return;
    say(typeof line === 'function' ? line(data || {}) : line, !!QUIET[key]);
  }

  // ----------------------------------------------------------- public API
  function start() {
    try {
      if (active || optedOut || reducedMotion()) return;
      ensureLayer();
      active = true;
      finaleOn = false;
      follow = null;
      const from = pointer.seen
        ? pointer
        : { x: window.innerWidth * 0.52, y: window.innerHeight * 0.55 };
      pos.x = from.x; pos.y = from.y;
      lastDrawX = from.x;
      render.x = from.x; render.y = from.y;
      tiltDeg = 0;
      ampCur = 0;
      bubbleOn = false; bubbleMsg = ''; bubblePos.set = false; lastPathKey = '';
      bubble.style.display = 'none';
      layer.style.display = 'block';
      cursor.style.transform = 'translate3d(' + pos.x + 'px,' + pos.y + 'px,0)';
      fx.classList.remove('is-finale', 'is-press');
      void cursor.offsetWidth; // commit display:block so the fade-in transition runs
      cursor.classList.add('is-visible');
      playFx('is-in', 360);
      if (rafId == null) rafId = requestAnimationFrame(frame);
    } catch (e) { active = false; }
  }

  async function stop(opts) {
    if (!active) return;
    const wantFinale = !!(opts && opts.finale) && !document.hidden;
    try {
      if (wantFinale) {
        // Land centre-stage, then grow → spin → dive. The sign-off the caller
        // already put in the bubble rides along and gets a beat on its own
        // before the dive takes the pointer out from under it.
        await moveTo(window.innerWidth / 2, window.innerHeight * 0.42, { duration: 620, force: true });
        settleTween();
        await waitMs(700);
        finaleOn = true;
        if (fx) {
          fx.classList.remove('is-in', 'is-press');
          void fx.offsetWidth;
          fx.classList.add('is-finale');
        }
        setTimeout(() => hush(), 900);
        setTimeout(() => { if (active) ripple(render.x, render.y + 20, true); }, 1180);
        setTimeout(() => { if (active) ripple(render.x, render.y + 26, true); }, 1320);
        await waitMs(FINALE_MS);
      }
    } catch (e) { /* cosmetic */ }

    active = false;
    finaleOn = false;
    follow = null;
    settleTween();
    if (rafId != null) { cancelAnimationFrame(rafId); rafId = null; }
    try {
      bubbleOn = false; bubbleMsg = '';
      if (bubble) bubble.style.display = 'none';
      if (cursor) cursor.classList.remove('is-visible');
      if (fx) fx.classList.remove('is-finale', 'is-press', 'is-in');
      setTimeout(() => { if (!active && layer) layer.style.display = 'none'; }, 260);
    } catch (e) { /* cosmetic */ }
  }

  // Flash a click where the pointer already is, then give the ripple ~100ms to
  // register before the caller fires the real click.
  async function press() {
    if (!active || document.hidden) return;
    try {
      ripple(render.x, render.y, false);
      playFx('is-press', 260);
    } catch (e) { return; }
    await waitMs(100);
  }

  function moveToElement(el, duration) {
    const p = elPoint(el);
    if (!p) return Promise.resolve();
    return moveTo(p.x, p.y, duration ? { duration: duration } : undefined);
  }

  async function clickElement(el) {
    if (!active) return;
    await moveToElement(el);
    await press();
  }

  // Ride the caret while `el` is typed into. The pointer sits just ABOVE the
  // insertion point so the text stays readable underneath it.
  function followCaret(el) {
    if (!active || !el) return;
    settleTween();
    follow = function () {
      const p = caretPoint(el);
      return p ? { x: p.x + 1, y: p.y - 5 } : null;
    };
  }

  function stopFollow() {
    follow = null;
  }

  // Self-contained showcase for tuning the feel without running a real share.
  // Paste `ShareUnlimited.Ghost.demo()` into the Facebook tab's console: it
  // travels, clicks, floats and plays the finale, touching nothing on the page.
  async function demo() {
    const wasOptedOut = optedOut;
    optedOut = false;
    start();
    if (!active) { optedOut = wasOptedOut; console.warn('Ghost cursor is disabled (prefers-reduced-motion?)'); return; }
    const vw = window.innerWidth, vh = window.innerHeight;
    const name = 'Real Estate Investors of Los Angeles';
    // Walks the same beats a real run does, including a long group name (to see
    // the bubble wrap and grow) and a live countdown (to see it tick in place
    // without re-animating).
    const beats = [
      [0.22, 0.30, 'start',     { total: 20 }],
      [0.70, 0.26, 'find',      { index: 1, total: 20, name: name }],
      [0.70, 0.26, 'searching', { name: name }],
      [0.60, 0.62, 'found',     { name: name }],
      // Both shapes of the pre-typing announcement: a long AI variant that has to
      // clip, and the watermark-only case where the user typed nothing at all.
      [0.34, 0.70, 'willType',  { text: 'Open house this Saturday 11–2 at 14 Maple Street. Three bedrooms, huge garden, walk to the station.', signature: 'Shared using MGSApro', variant: 3, variants: 12, watermark: true, ownSignature: false }],
      [0.34, 0.70, 'willType',  { text: '', signature: 'Shared using MGSApro', variant: 0, variants: 0, watermark: true, ownSignature: false }],
      [0.34, 0.70, 'typing',    {}],
      [0.48, 0.44, 'posting',   { name: name }],
      [0.48, 0.44, 'posted',    { name: name }]
    ];
    for (const b of beats) {
      await moveTo(vw * b[0], vh * b[1], { force: true });
      narrate(b[2], b[3]);
      await press();
      await waitMs(1500);
    }
    narrate('nextUp', { index: 2, total: 20, name: 'Startup Founders UK' });
    await waitMs(2200);
    for (let n = 6; n > 0; n--) { narrate('wait', { seconds: n }); await waitMs(1000); }
    narrate('done', { ok: true, total: 20, success: 20 });
    await stop({ finale: true });
    optedOut = wasOptedOut;
  }

  window.ShareUnlimited.Ghost = {
    start: start,
    demo: demo,
    say: say,
    narrate: narrate,
    hush: hush,
    stop: stop,
    press: press,
    moveTo: moveTo,
    moveToElement: moveToElement,
    clickElement: clickElement,
    followCaret: followCaret,
    stopFollow: stopFollow,
    isActive: function () { return active; }
  };
})();
