<?php

namespace DIT\TrendStudio\Content\Media;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * MediaMatcher
 *
 * Phase 2: Lightweight deterministic matcher to align dress H3 blocks
 * with the most relevant remaining images (when AI placement is imperfect).
 *
 * @package DIT_TrendStudio
 * @since 2.10.0
 */
class MediaMatcher
{
    /**
     * Highly localized matching for Fashion PK.
     * Aligns H3 "slots" (dresses) with the best-matching image based on semantic overlap (colors, fabrics).
     * @MODIFIED 2026-03-09 - Phase 2 Semantic Matcher (Issue #FashionPrecision)
     * @MODIFIED 2026-05-06 - Phase 3 Sequential Fallback (Issue #ImageMismatch):
     *   - Lowered confidence gate from 3.0 to 1.0 so weak signals still produce matches.
     *   - Added sequential fallback: when no H3 slot achieves threshold, images are assigned
     *     in document order (slot 0 -> image 0, slot 1 -> image 1, etc.).
     *   - This ensures dress images always appear in the correct H3 block even when
     *     the source post lacks rich alt text or color keywords.
     *
     * @param array $stream      Content stream (sections from AI response)
     * @param array $dress_queue Available images (with src, alt, hint, visual_idx)
     * @return array Reordered queue
     */
    public static function match_fashion_dress_slots(array $stream, array $dress_queue): array
    {
        if (count($dress_queue) < 2) return $dress_queue;

        $slots = self::extract_h3_slots($stream);
        if (empty($slots)) return $dress_queue;

        $remaining = $dress_queue;
        $ordered = [];
        $debug_log = [];
        $matched_any = false;

        foreach ($slots as $slot) {
            $best_i = null;
            $best_score = -1.0;

            foreach ($remaining as $i => $img) {
                $score = self::score_slot_image($slot, $img);
                if ($score > $best_score) {
                    $best_score = $score;
                    $best_i = $i;
                }
            }

            // @MODIFIED 2026-05-06 - Lowered confidence gate to 1.0 for fashion_pk weak signals
            if ($best_i !== null && $best_score >= 1.0) {
                $match = $remaining[$best_i];
                $ordered[] = $match;
                unset($remaining[$best_i]);
                $remaining = array_values($remaining);
                $matched_any = true;

                $debug_log[] = "[Match] '{$slot['h3']}' -> " . basename($match['src'] ?? '') . " (Score: {$best_score})";
            } else {
                $debug_log[] = "[No Match] '{$slot['h3']}' (Score: {$best_score})";
            }

            if (empty($remaining)) break;
        }

        // @MODIFIED 2026-05-06 - Sequential fallback: if no matches found at all,
        // assign images in strict source order to prevent empty H3 blocks.
        if (!$matched_any && !empty($ordered)) {
            // Some matched, some didn't — keep partial matches as-is
        } elseif (!$matched_any && !empty($dress_queue)) {
            $debug_log[] = "[Fallback] Sequential assignment: matching H3 slots to images in source order";
            $ordered = [];
            $remaining = $dress_queue;
            foreach ($slots as $slot_i => $slot) {
                if (isset($remaining[$slot_i])) {
                    $ordered[] = $remaining[$slot_i];
                    unset($remaining[$slot_i]);
                }
            }
            $remaining = array_values($remaining);
        }

        // Final result: Matches followed by unused images
        $result = array_merge($ordered, $remaining);

        if (defined('WP_DEBUG') && \WP_DEBUG) {
            error_log("TrendStudio MediaMatcher: " . implode(" | ", $debug_log));
        }

        return array_values($result);
    }

    /**
     * Score a single image against an H3 slot using semantic heuristics.
     */
    private static function score_slot_image(array $slot, array $img): float
    {
        $slot_text = strtolower($slot['h3'] . ' ' . $slot['para']);
        $img_text = strtolower(($img['alt'] ?? '') . ' ' . ($img['hint'] ?? ''));

        $score = 0.0;

        // 1. Color Matching (High Priority)
        $colors = ['red', 'maroon', 'mustard', 'yellow', 'blue', 'green', 'black', 'white', 'pink', 'purple', 'orange', 'nude', 'beige'];
        foreach ($colors as $color) {
            if (strpos($slot_text, $color) !== false && strpos($img_text, $color) !== false) {
                $score += 5.0;
            }
        }

        // 2. Fabric Matching (Medium-High Priority)
        $fabrics = ['lawn', 'chiffon', 'organza', 'silk', 'cambric', 'jacquard', 'khaddar', 'linen', 'karandi'];
        foreach ($fabrics as $fabric) {
            if (strpos($slot_text, $fabric) !== false && strpos($img_text, $fabric) !== false) {
                $score += 4.0;
            }
        }

        // 3. Style/Component Matching
        $styles = ['shirt', 'dupatta', 'trouser', 'suit', 'unstitched', 'stitched', 'kurta', 'motif', 'embroidery', 'printed'];
        foreach ($styles as $style) {
            if (strpos($slot_text, $style) !== false && strpos($img_text, $style) !== false) {
                $score += 2.0;
            }
        }

        // 4. Token Overlap (General Relevance)
        $slot_tokens = self::tokens($slot_text);
        $img_tokens = self::tokens($img_text);
        $common = array_intersect($slot_tokens, $img_tokens);
        $score += (float) count($common);

        // 5. Visual ID Bonus (If AI explicitly requested this token)
        if (isset($img['visual_idx'])) {
            $score += 0.5;
        }

        return $score;
    }

    private static function extract_h3_slots(array $stream): array
    {
        $slots = [];
        $current_h3 = '';

        foreach ($stream as $el) {
            if (($el['type'] ?? '') === 'heading' && (int) ($el['level'] ?? 0) === 3) {
                $current_h3 = self::clean_text((string) ($el['content'] ?? ''));
                continue;
            }

            if ($current_h3 !== '' && ($el['type'] ?? '') === 'paragraph') {
                $para = self::clean_text((string) ($el['content'] ?? ''));
                $slots[] = ['h3' => $current_h3, 'para' => $para];
                $current_h3 = '';
            }
        }

        return $slots;
    }

    private static function tokens(string $text): array
    {
        $t = strtolower(self::clean_text($text));
        if ($t === '') return [];

        $t = preg_replace('/[^a-z0-9\s]+/i', ' ', $t);
        $parts = array_filter(array_map('trim', preg_split('/\s+/', $t)));

        $stop = ['the', 'and', 'for', 'with', 'this', 'that', 'from', 'into', 'your', 'you', 'she', 'his', 'her', 'its', 'are', 'was', 'were', 'look'];

        $out = [];
        foreach ($parts as $p) {
            if (strlen($p) < 3 || in_array($p, $stop, true)) continue;
            $out[] = $p;
        }

        return array_values(array_unique($out));
    }

    private static function clean_text(string $html): string
    {
        $txt = function_exists('wp_strip_all_tags') ? wp_strip_all_tags($html) : strip_tags($html);
        $txt = preg_replace('/\s+/', ' ', (string) $txt);
        return trim((string) $txt);
    }
}
