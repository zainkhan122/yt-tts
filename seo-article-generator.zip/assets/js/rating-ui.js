(function () {
  "use strict";

  document.addEventListener("DOMContentLoaded", function () {
    var widgets = document.querySelectorAll(".seo-gen-rating-widget");

    widgets.forEach(function (widget) {
      if (widget.getAttribute("data-rated") === "true") return;

      var postId = widget.getAttribute("data-post-id");
      var container = widget.querySelector(".seo-gen-rating-stars-container");
      var buttons = widget.querySelectorAll(".seo-gen-star-btn");
      var feedback = widget.querySelector(".seo-gen-rating-feedback");

      if (!buttons.length || !container) return;

      // Hover effects
      buttons.forEach(function (btn, index) {
        btn.addEventListener("mouseenter", function () {
          highlightStars(buttons, index + 1);
        });

        btn.addEventListener("click", function () {
          var rating = parseInt(btn.getAttribute("data-rating"), 10);
          submitRating(widget, postId, rating);
        });
      });

      container.addEventListener("mouseleave", function () {
        highlightStars(buttons, 0);
      });
    });

    function highlightStars(buttons, count) {
      buttons.forEach(function (btn, index) {
        if (index < count) {
          btn.style.color = "#fbbf24";
          btn.style.transform = "scale(1.2)";
        } else {
          btn.style.color = "";
          btn.style.transform = "";
        }
      });
    }

    function submitRating(widget, postId, rating) {
      var container = widget.querySelector(".seo-gen-rating-stars-container");
      var feedback = widget.querySelector(".seo-gen-rating-feedback");
      var buttons = widget.querySelectorAll(".seo-gen-star-btn");

      if (!feedback) return;

      // Disable buttons
      buttons.forEach(function (btn) {
        btn.disabled = true;
      });

      // Show loading
      feedback.innerHTML = '<span class="is-loading">Submitting...</span>';
      feedback.className = "seo-gen-rating-feedback is-loading";

      // AJAX
      var formData = new FormData();
      formData.append("action", "seo_gen_submit_rating");
      formData.append("nonce", seo_gen_Rating.nonce);
      formData.append("post_id", postId);
      formData.append("rating", rating);

      fetch(seo_gen_Rating.ajax_url, {
        method: "POST",
        body: formData,
        credentials: "same-origin",
      })
        .then(function (response) {
          return response.json();
        })
        .then(function (data) {
          if (data.success) {
            feedback.innerHTML = '<span class="is-success">✓ ' + data.data.message + "</span>";
            feedback.className = "seo-gen-rating-feedback is-success";

            // Mark as rated
            widget.setAttribute("data-rated", "true");
            container.classList.remove("is-interactive");
            container.classList.add("is-rated");

            // Update counts in meta
            var avgEl = widget.querySelector(".seo-gen-rating-avg");
            var countEl = widget.querySelector(".seo-gen-rating-count");
            if (avgEl) avgEl.textContent = parseFloat(data.data.average).toFixed(1);
            if (countEl) countEl.textContent = "(" + data.data.count + ")";

            // Hide "Rate it" label
            var label = widget.querySelector(".seo-gen-rating-label");
            if (label) label.style.display = "none";

            // Convert buttons to static spans
            buttons.forEach(function (btn) {
              var span = document.createElement("span");
              span.className = "seo-gen-star-static";
              span.innerHTML = btn.innerHTML;
              btn.parentNode.replaceChild(span, btn);
            });

          } else {
            feedback.innerHTML = '<span class="is-error">' + (data.data.message || "Error") + "</span>";
            feedback.className = "seo-gen-rating-feedback is-error";
            buttons.forEach(function (btn) { btn.disabled = false; });
          }
        })
        .catch(function () {
          feedback.innerHTML = '<span class="is-error">Network error</span>';
          feedback.className = "seo-gen-rating-feedback is-error";
          buttons.forEach(function (btn) { btn.disabled = false; });
        });
    }
  });
})();
