<?php
namespace AiSocialCollage\Contracts;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

interface AIProviderInterface {

	public function generate_content( $post_content, $system_prompt = '' );

	public function get_provider_name();

	public function get_model_name();

	public function test_connection();
}
