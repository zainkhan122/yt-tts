<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class QuotaStateManager {

	const STATE_KEY_PREFIX = 'ai_collage_qstate_';

	const DEFAULT_RPM_LIMIT = 10;
	const DEFAULT_RPD_LIMIT = 1500;
	const RPM_WINDOW = 60;

	private static function default_state( string $provider = '' ): array {
		$rpm_limit = self::DEFAULT_RPM_LIMIT;
		
		if ( $provider === Config::PROVIDER_GROQ ) {
			$rpm_limit = 30;
		} elseif ( strpos( $provider, Config::PROVIDER_CUSTOM_PREFIX ) === 0 ) {
			$profile = Config::get_custom_profile( $provider );
			if ( $profile && stripos( $profile['name'] ?? '', 'groq' ) !== false ) {
				$rpm_limit = 30;
			}
		}

		return [
			'rpm_used'         => 0,
			'rpm_limit'        => $rpm_limit,
			'rpm_window'       => self::RPM_WINDOW,
			'rpm_window_start' => 0,
			'rpd_used'         => 0,
			'rpd_limit'        => self::DEFAULT_RPD_LIMIT,
			'rpd_day_key'      => '',
			'rpd_reset_at'     => 0,
			'last_success_at'  => 0,
			'last_error_at'    => 0,
			'last_error_type'  => '',
		];
	}

	private static function get_state( string $provider ): array {
		$key = self::STATE_KEY_PREFIX . $provider;
		$state = get_transient( $key );
		if ( ! is_array( $state ) ) {
			return self::default_state( $provider );
		}
		return array_merge( self::default_state( $provider ), $state );
	}

	private static function save_state( string $provider, array $state ): void {
		$key = self::STATE_KEY_PREFIX . $provider;
		set_transient( $key, $state, 86400 );
	}

	private static function rpd_day_key( string $provider ): string {
		if ( $provider === Config::PROVIDER_GEMINI ) {
			$pt = new \DateTimeZone( 'America/Los_Angeles' );
			$now = new \DateTimeImmutable( 'now', $pt );
			return $now->format( 'Y-m-d' );
		}
		return gmdate( 'Y-m-d' );
	}

	public static function record_success( string $provider, array $usage = [] ): void {
		$state = self::get_state( $provider );
		$now = time();

		$rpd_key = self::rpd_day_key( $provider );
		if ( $state['rpd_day_key'] !== $rpd_key ) {
			$state['rpd_used'] = 0;
			$state['rpd_day_key'] = $rpd_key;
			$state['rpd_reset_at'] = self::next_rpd_reset_ts( $provider );
		}

		if ( ( $now - $state['rpm_window_start'] ) >= self::RPM_WINDOW ) {
			$state['rpm_used'] = 0;
			$state['rpm_window_start'] = $now;
		}

		$state['rpm_used']++;
		$state['rpd_used']++;
		$state['last_success_at'] = $now;

		self::save_state( $provider, $state );

		Logger::debug( 'quota_state_record_success', null, [
			'provider'  => $provider,
			'rpm_used'  => $state['rpm_used'],
			'rpd_used'  => $state['rpd_used'],
		] );
	}

	public static function record_failure( string $provider, APIErrorInfo $error_info ): void {
		$state = self::get_state( $provider );
		$now = time();

		$rpd_key = self::rpd_day_key( $provider );
		if ( $state['rpd_day_key'] !== $rpd_key ) {
			$state['rpd_used'] = 0;
			$state['rpd_day_key'] = $rpd_key;
		}

		if ( ( $now - $state['rpm_window_start'] ) >= self::RPM_WINDOW ) {
			$state['rpm_used'] = 0;
			$state['rpm_window_start'] = $now;
		}

		$state['last_error_at'] = $now;
		$state['last_error_type'] = $error_info->error_type;

		if ( $error_info->is_daily_quota() ) {
			if ( $error_info->get_reset_at_ts() > 0 ) {
				$state['rpd_reset_at'] = $error_info->get_reset_at_ts();
			}
			ProviderCooldown::set_daily_quota( $provider, $error_info->get_reset_at_ts() > 0 ? $error_info->get_reset_at_ts() : self::next_rpd_reset_ts( $provider ) );
		} elseif ( $error_info->error_type === APIErrorInfo::TYPE_QUOTA_RPM
			|| $error_info->error_type === APIErrorInfo::TYPE_QUOTA_TPM ) {
			$state['rpm_used'] = $state['rpm_limit'];
			$state['rpm_window_start'] = $now;
		} elseif ( $error_info->error_type === APIErrorInfo::TYPE_QUOTA_UNKNOWN ) {
			$retry_after = $error_info->get_retry_after();
			$state['rpm_used'] = $state['rpm_limit'];
			$state['rpm_window_start'] = $now;
			if ( $retry_after > 0 && $retry_after < 301 ) {
				$state['rpm_reset_at'] = $now + $retry_after;
			}
			if ( $state['rpd_reset_at'] <= 0 ) {
				$state['rpd_reset_at'] = self::next_rpd_reset_ts( $provider );
			}
		} elseif ( $error_info->error_type === APIErrorInfo::TYPE_SERVER_OVERLOADED
			|| $error_info->error_type === APIErrorInfo::TYPE_TRANSIENT ) {
			$retry_after = $error_info->get_retry_after();
			if ( $retry_after > 0 && $retry_after < 121 ) {
				$state['rpm_used'] = $state['rpm_limit'];
				$state['rpm_window_start'] = $now + $retry_after;
			}
		}

		if ( $error_info->error_type === APIErrorInfo::TYPE_AUTH_FAILURE
			|| $error_info->error_type === APIErrorInfo::TYPE_MODEL_NOT_FOUND ) {
			$state['rpm_used'] = $state['rpm_limit'];
			$state['rpd_used'] = $state['rpd_limit'];
			$state['rpm_window_start'] = $now;
			$state['rpd_reset_at'] = $now + 300;
		}

		self::save_state( $provider, $state );

		Logger::debug( 'quota_state_record_failure', null, [
			'provider'   => $provider,
			'error_type' => $error_info->error_type,
			'rpm_used'   => $state['rpm_used'],
			'rpd_used'   => $state['rpd_used'],
		] );
	}

	public static function can_make_request( string $provider ): bool {
		$state = self::get_state( $provider );
		$now = time();

		if ( $state['rpd_day_key'] !== self::rpd_day_key( $provider ) ) {
			return true;
		}

		if ( ( $now - $state['rpm_window_start'] ) >= self::RPM_WINDOW ) {
			return true;
		}

		if ( $state['rpm_used'] >= $state['rpm_limit'] ) {
			return false;
		}

		$rpd_limit = $state['rpd_limit'];
		if ( $rpd_limit > 0 && $state['rpd_used'] >= $rpd_limit ) {
			return false;
		}

		return true;
	}

	public static function should_slow_down( string $provider ): bool {
		$state = self::get_state( $provider );
		$rpm_ratio = self::ratio( $state, 'rpm' );
		$rpd_ratio = self::ratio( $state, 'rpd' );

		return $rpm_ratio > 0.70 || $rpd_ratio > 0.75;
	}

	public static function get_recommended_interval( string $provider ): int {
		$state = self::get_state( $provider );
		$base = self::base_interval( $provider );
		$rpm_ratio = self::ratio( $state, 'rpm' );
		$rpd_ratio = self::ratio( $state, 'rpd' );

		if ( $rpd_ratio > 0.90 ) {
			return $base * 4;
		}
		if ( $rpd_ratio > 0.75 ) {
			return (int) ( $base * 2.5 );
		}
		if ( $rpm_ratio > 0.85 ) {
			return $base * 3;
		}
		if ( $rpm_ratio > 0.70 ) {
			return $base * 2;
		}

		return $base;
	}

	public static function next_safe_slot_ts( string $provider ): int {
		$state = self::get_state( $provider );
		$now = time();
		$rpm_ratio = self::ratio( $state, 'rpm' );
		$rpd_ratio = self::ratio( $state, 'rpd' );

		$earliest = $now;

		if ( $rpm_ratio > 0.85 ) {
			$rpm_end = $state['rpm_window_start'] + self::RPM_WINDOW;
			$earliest = max( $earliest, $rpm_end );
		}

		if ( $rpd_ratio > 0.95 && $state['rpd_reset_at'] > 0 ) {
			$earliest = max( $earliest, $state['rpd_reset_at'] );
		}

		return $earliest;
	}

	public static function get_quota_status( string $provider ): array {
		$state = self::get_state( $provider );
		$now = time();

		$rpm_effective = $state['rpm_used'];
		if ( ( $now - $state['rpm_window_start'] ) >= self::RPM_WINDOW ) {
			$rpm_effective = 0;
		}

		$rpd_effective = $state['rpd_used'];
		if ( $state['rpd_day_key'] !== self::rpd_day_key( $provider ) ) {
			$rpd_effective = 0;
		}

		return [
			'provider'       => $provider,
			'rpm_used'       => $rpm_effective,
			'rpm_limit'      => $state['rpm_limit'],
			'rpm_remaining'  => max( 0, $state['rpm_limit'] - $rpm_effective ),
			'rpd_used'       => $rpd_effective,
			'rpd_limit'      => $state['rpd_limit'],
			'rpd_remaining'  => max( 0, $state['rpd_limit'] - $rpd_effective ),
			'rpd_reset_at'   => $state['rpd_reset_at'],
			'last_error'     => $state['last_error_type'],
		];
	}

	public static function reset_quota( string $provider ): void {
		delete_transient( self::STATE_KEY_PREFIX . $provider );
	}

	public static function reset_all(): void {
		global $wpdb;

		$like_pattern         = '_transient_' . self::STATE_KEY_PREFIX . '%';
		$timeout_like_pattern = '_transient_timeout_' . self::STATE_KEY_PREFIX . '%';

		// Enumerate first so the cache can be purged precisely afterwards.
		$names = $wpdb->get_col( $wpdb->prepare(
			"SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
			$wpdb->esc_like( $like_pattern ),
			$wpdb->esc_like( $timeout_like_pattern )
		) );

		$wpdb->query( $wpdb->prepare(
			"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
			$wpdb->esc_like( $like_pattern ),
			$wpdb->esc_like( $timeout_like_pattern )
		) );

		// AUDIT FIX F12: is_object_cache_active() is not a WordPress function, so
		// the guard that used to be here was always false and wp_cache_flush()
		// never ran. Quota rows were deleted from the DB while WordPress kept
		// serving the stale values out of cache.
		if ( function_exists( 'wp_cache_delete' ) ) {
			foreach ( ( is_array( $names ) ? $names : [] ) as $option_name ) {
				wp_cache_delete( $option_name, 'options' );
			}

			wp_cache_delete( 'alloptions', 'options' );
			wp_cache_delete( 'notoptions', 'options' );
		}

		if ( function_exists( 'wp_using_ext_object_cache' ) && wp_using_ext_object_cache() ) {
			wp_cache_flush();
		}
	}

	private static function ratio( array $state, string $type ): float {
		$used = $state[ $type . '_used' ] ?? 0;
		$limit = $state[ $type . '_limit' ] ?? 1;
		if ( $limit <= 0 ) {
			return 0.0;
		}
		return (float) $used / (float) $limit;
	}

	private static function base_interval( string $provider ): int {
		switch ( $provider ) {
			case Config::PROVIDER_GEMINI:
				return 6;
			case Config::PROVIDER_GROQ:
				return 4;
			default:
				return 5;
		}
	}

	private static function next_rpd_reset_ts( string $provider ): int {
		if ( $provider === Config::PROVIDER_GEMINI ) {
			$pt = new \DateTimeZone( 'America/Los_Angeles' );
			$now = new \DateTimeImmutable( 'now', $pt );
			$next = $now->modify( 'tomorrow' )->setTime( 0, 0, 0 );
			return (int) $next->getTimestamp();
		}
		// For custom providers (OpenRouter, Groq, etc.) we DO NOT assume a
		// midnight-UTC reset — their billing/quota windows can land anywhere
		// in the day. Returning midnight-UTC would over-quarantine by up to
		// ~20 hours when the real reset is minutes away. Cap at 1 hour so
		// the next attempt can re-evaluate against live state. If a custom
		// provider returns a real Retry-After timestamp, that path takes
		// priority (see AIProviderRegistry::execute_with_fallback).
		if ( strpos( $provider, Config::PROVIDER_CUSTOM_PREFIX ) === 0 ) {
			return time() + 3600;
		}
		// Plain Groq (non-custom): use midnight UTC as a safe default.
		$now = new \DateTimeImmutable( 'now', new \DateTimeZone( 'UTC' ) );
		$next = $now->modify( 'tomorrow' )->setTime( 0, 0, 0 );
		return (int) $next->getTimestamp();
	}
}