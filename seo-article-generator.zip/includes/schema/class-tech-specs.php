<?php

/**
 * Tech Specs DTO
 *
 * @package SEO_Article_Generator
 */

namespace SEO_Article_Generator\Schema;

use SEO_Article_Generator\Traits\Type_Safety;

// Prevent direct access.
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Value Object for Technical Specifications.
 */
class Tech_Specs
{
    use Type_Safety;

    /** @var string */
    public $software_name = '';

    /** @var string */
    public $version = '';

    /** @var string */
    public $license = '';

    /** @var string */
    public $file_size = '';

    /** @var string */
    public $os_support = '';

    /** @var string */
    public $language_support = '';

    /** @var string */
    public $developer = '';

    /** @var string */
    public $publisher = '';

    /** @var string */
    public $homepage = '';

    /** @var string */
    public $changelogurl = '';

    /** @var string */
    public $last_updated = '';

	/** @var string */
	public $file_type = '';

	/** @var string */
	public $application_category = '';

	/**
	 * Create from array with defaults.
     *
     * @param array $data Input array.
     * @return self
     */
    public static function from_array($data = array())
    {
        $instance = new self();
        $data = (array) $data;

        $instance->software_name = isset($data['software_name']) ? self::as_string($data['software_name']) : '';
        $instance->version = isset($data['version']) ? self::as_string($data['version']) : '';
        $instance->license = isset($data['license']) ? self::as_string($data['license']) : '';
        $instance->file_size = isset($data['file_size']) ? self::as_string($data['file_size']) : '';
        $instance->os_support = isset($data['os_support']) ? self::as_string($data['os_support']) : '';
        $instance->language_support = isset($data['language_support']) ? self::as_string($data['language_support']) : '';
        $instance->developer = isset($data['developer']) ? self::as_string($data['developer']) : '';
        $instance->publisher = isset($data['publisher']) ? self::as_string($data['publisher']) : '';
        $instance->homepage = isset($data['homepage']) ? self::as_string($data['homepage']) : '';
        $instance->changelogurl = isset($data['changelogurl']) ? self::as_string($data['changelogurl']) : '';
        $instance->last_updated = isset($data['last_updated']) ? self::as_string($data['last_updated']) : '';
		$instance->file_type = isset($data['file_type']) ? self::as_string($data['file_type']) : '';
		$instance->application_category = isset($data['application_category']) ? self::as_string($data['application_category']) : '';

        return $instance;
    }

    /**
     * Convert to array (for legacy consumers).
     *
     * @return array
     */
    public function to_array()
    {
        return get_object_vars($this);
    }
}
