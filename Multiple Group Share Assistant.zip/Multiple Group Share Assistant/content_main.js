// content_main.js - Initialization and Event Listeners
(function() {
  'use strict';
  
  console.log('Share Unilimited content script loaded and active.');
  
  // Ensure namespace exists (should be created by core/ui scripts)
  window.ShareUnlimited = window.ShareUnlimited || {};
  
  const Core = window.ShareUnlimited.Core;
  const UI = window.ShareUnlimited.UI;
  const State = window.ShareUnlimited.State;

  /**
   * Resolves the live "Share to a group" dialog across Facebook's two markup variants
   * (aria-labelledby vs aria-label="Share to a group"). Delegates to Core.findShareDialog
   * (loaded before this file) so all three content scripts share one detection path.
   * Purely additive — the legacy aria-labelledby dialog is still matched first.
   */
  function getShareDialog() {
    if (Core && Core.findShareDialog) return Core.findShareDialog();
    return document.querySelector('div[role="dialog"][aria-labelledby]');
  }

  // --- DOM Observer Logic ---

  let lastProcessedDialog = null;
  let shareToGroupHeadingPresent = false;

  /**
   * Sets up an interceptor on the "Post" button.
   */
  function setupPostButtonInterceptor() {
    if (!Core || !Core.findPostButton) return;

    // Silent pre-check: only proceed if a "Post" button actually exists in the dialog.
    // Avoids calling findPostButton (which logs a warning) every 1.5s while just browsing.
    const dialogButtons = document.querySelectorAll('div[role="dialog"] div[role="button"]');
    let hasPostButton = Array.from(dialogButtons).some(
      btn => btn.textContent.trim().toLowerCase() === 'post' &&
             btn.getAttribute('aria-disabled') !== 'true'
    );

    // Non-English UI (v17.7): this cheap gate is English-only, so on a translated
    // Facebook it short-circuited and the Post interceptor was never installed.
    // Defer to the structural check, which stays cheap (one querySelectorAll).
    if (!hasPostButton && Core.Struct) {
      const byShape = Core.Struct.findSubmitButtonByShape(
        (Core.findShareDialog && Core.findShareDialog()) || document.querySelector('div[role="dialog"]')
      );
      hasPostButton = !!(byShape && byShape.getAttribute('aria-disabled') !== 'true');
    }

    if (!hasPostButton) return;

    const postButton = Core.findPostButton();

    if (postButton && !postButton.dataset.intercepted) {
      postButton.dataset.intercepted = 'true';

      const interceptor = async (event) => {
        // If automated sharing is in progress, ignore interception
        if (State && State.isSharingInProgress) {
          console.log('Post button clicked, allowing pass-through (automation active)');
          return;
        }

        console.log('Post button clicked, intercepting...');
        
        event.stopPropagation();
        event.preventDefault();

        if (Core.handleMultiPost) {
          const shouldProceed = await Core.handleMultiPost();
          
          if (shouldProceed) {
            // Remove listener to allow click to pass
            postButton.removeEventListener('click', interceptor, true);
            postButton.click();
            // Re-add listener after a short delay
            setTimeout(() => {
               postButton.addEventListener('click', interceptor, true);
            }, 500);
          }
        }
      };

      // We add our listener in the "capture" phase to ensure it runs before any other listeners.
      postButton.addEventListener('click', interceptor, true);
    }
  }

  /**
   * Checks if "Share to a group" heading is present in any dialog
   */
  function isShareToGroupHeadingPresent() {
    const dialog = getShareDialog();
    if (!dialog) return false;

    const h2Elements = dialog.querySelectorAll('h2, h3');
    for (const h2 of h2Elements) {
      const h2Text = h2.textContent.trim();
      const spanInH2 = h2.querySelector('span');
      const spanText = spanInH2 ? spanInH2.textContent.trim() : '';
      
      if (h2Text === 'Share to a group' || spanText === 'Share to a group') {
        return true;
      }
    }

    // Non-English UI (v17.7): the heading is translated, so this returned false forever
    // and the checkbox scanner never started — the toolbar simply never appeared on a
    // Hebrew/Arabic/Spanish Facebook. A dialog with a search box AND group rows is the
    // picker regardless of language.
    const Core = window.ShareUnlimited && window.ShareUnlimited.Core;
    if (Core && Core.Struct && Core.Struct.findGroupSearchInput(dialog) &&
        dialog.querySelector('div[role="listitem"]')) {
      return true;
    }

    return false;
  }

  /**
   * Starts aggressive scanning when "Share to a group" heading is detected
   */
  function startAggressiveScanning() {
    // Tear down any previous watcher
    if (window.groupScanInterval) {
      clearInterval(window.groupScanInterval);
      window.groupScanInterval = null;
    }
    if (window.groupScanObserver) {
      window.groupScanObserver.disconnect();
      window.groupScanObserver = null;
    }

    // Tear down any previous scroll watcher
    if (window.groupScanScrollHandler) {
      document.removeEventListener('scroll', window.groupScanScrollHandler, true);
      window.groupScanScrollHandler = null;
    }

    // Tear down any previous search-input watcher
    if (window.groupScanInputHandler) {
      document.removeEventListener('input', window.groupScanInputHandler, true);
      window.groupScanInputHandler = null;
    }

    console.log('🔄 Starting checkbox scanning (scroll-driven mode)...');

    // Initial pass — covers the first screenful of groups (and retries while the
    // first batch loads via fetch, before any scrolling happens).
    if (UI && UI.addCheckboxesToGroups) {
      UI.addCheckboxesToGroups();
    }
    setupPostButtonInterceptor();

    // SETTLE PASSES: FB keeps hydrating the first screenful for a couple of seconds
    // after the dialog opens, so rows that mount just AFTER the initial pass had no
    // checkboxes until the user happened to scroll ("some checkboxes only show up
    // when I scroll a little"). A short burst of one-shot re-scans catches those
    // late rows without moving the user's view. Safe against the old flicker loop:
    // the scan is idempotent and these are fixed timers — they don't react to DOM
    // changes the way a MutationObserver did.
    [400, 900, 1600, 2500].forEach(ms => setTimeout(() => {
      if (isShareToGroupHeadingPresent() && UI && UI.scanAndAddCheckboxesLive) {
        UI.scanAndAddCheckboxesLive();
      }
    }, ms));

    // Facebook VIRTUALIZES the group list: only ~20 rows ever exist in the DOM at once,
    // and new rows mount ONLY when the user scrolls. We therefore add checkboxes to the
    // newly-revealed rows on the SCROLL event (debounced) rather than via a
    // MutationObserver.
    //
    // Why not a MutationObserver: reacting to list mutations created an endless
    // flashing loop — adding a checkbox makes React reconcile/replace that row, which
    // the observer saw as a new change → scan again → checkboxes flickered on/off
    // forever. Scroll events only fire on real user action, so there is NO idle
    // feedback loop: when the user isn't scrolling, we do nothing and the checkboxes
    // sit still.
    let scrollDebounce = null;
    const onScroll = () => {
      if (!isShareToGroupHeadingPresent()) return;
      clearTimeout(scrollDebounce);
      scrollDebounce = setTimeout(() => {
        if (!isShareToGroupHeadingPresent()) return;
        if (UI && UI.scanAndAddCheckboxesLive) UI.scanAndAddCheckboxesLive();
        // Virtualized rows can finish rendering slightly after the scroll settles —
        // a single follow-up pass catches those without polling.
        setTimeout(() => {
          if (isShareToGroupHeadingPresent() && UI && UI.scanAndAddCheckboxesLive) {
            UI.scanAndAddCheckboxesLive();
          }
        }, 300);
      }, 120);
    };

    window.groupScanScrollHandler = onScroll;
    // capture:true — scroll events don't bubble, so we must listen in the capture phase
    // to catch scrolling inside the dialog's inner scroll container. passive:true for perf.
    document.addEventListener('scroll', onScroll, { capture: true, passive: true });

    // SEARCH: typing in the dialog's "Search" box filters the list and re-mounts rows
    // WITHOUT a scroll, so the scroll handler never fires and the filtered rows had no
    // checkboxes until the user nudged the scroll. Re-scan (debounced) on search input.
    // Like scroll, 'input' only fires on real user typing, so there is no idle feedback
    // loop. Extra follow-up passes catch rows that render slightly after the filter runs.
    let inputDebounce = null;
    const onSearchInput = (e) => {
      const t = e.target;
      // Only care about typing inside the group dialog (the search field).
      if (!t || !t.closest || !t.closest('div[role="dialog"]')) return;
      if (!isShareToGroupHeadingPresent()) return;
      clearTimeout(inputDebounce);
      inputDebounce = setTimeout(() => {
        if (!isShareToGroupHeadingPresent()) return;
        if (UI && UI.scanAndAddCheckboxesLive) UI.scanAndAddCheckboxesLive();
        [300, 700].forEach(ms => setTimeout(() => {
          if (isShareToGroupHeadingPresent() && UI && UI.scanAndAddCheckboxesLive) {
            UI.scanAndAddCheckboxesLive();
          }
        }, ms));
      }, 200);
    };

    window.groupScanInputHandler = onSearchInput;
    document.addEventListener('input', onSearchInput, { capture: true, passive: true });

    console.log('✅ Scroll- and search-driven checkbox scanning active (no flicker, covers virtualized scroll + search filtering)');
  }

  /**
   * Checks if the current dialog has the group list (called on dialog content changes)
   */
  function checkForGroupDialog() {
    const headingPresent = isShareToGroupHeadingPresent();

    // Heading appeared or reappeared
    if (headingPresent && !shareToGroupHeadingPresent) {
      console.log('✅ "Share to a group" heading DETECTED - starting checkbox observer');
      shareToGroupHeadingPresent = true;
      startAggressiveScanning();
    }
    // Heading disappeared
    else if (!headingPresent && shareToGroupHeadingPresent) {
      console.log('⏹️ "Share to a group" heading DISAPPEARED - stopping checkbox scanning');
      shareToGroupHeadingPresent = false;
      if (window.groupScanObserver) {
        window.groupScanObserver.disconnect();
        window.groupScanObserver = null;
      }
      if (window.groupScanScrollHandler) {
        document.removeEventListener('scroll', window.groupScanScrollHandler, true);
        window.groupScanScrollHandler = null;
      }
      if (window.groupScanInputHandler) {
        document.removeEventListener('input', window.groupScanInputHandler, true);
        window.groupScanInputHandler = null;
      }
    }
  }

  /**
   * Watches for the share dialog to appear and initializes the script.
   */
  const observer = new MutationObserver((mutationsList) => {
    for (const mutation of mutationsList) {
      if (mutation.type === 'childList') {
        // Check for the share-to-group dialog (either markup variant)
        const dialog = getShareDialog();

        // Check if dialog was just removed
        if (!dialog && lastProcessedDialog) {
            console.log('📴 Group selection dialog removed');
            lastProcessedDialog = null;
            shareToGroupHeadingPresent = false;
            if (window.groupScanObserver) {
                window.groupScanObserver.disconnect();
                window.groupScanObserver = null;
            }
        }

        // If dialog exists, check if it has the group list
        if (dialog) {
          checkForGroupDialog();
        }
      }
    }
  });

  // Start observing the entire document body for changes.
  observer.observe(document.body, {
    childList: true,
    subtree: true
  });

  // --- Multi-Group Button Observer ---
  
  /**
   * Sets up an observer to continuously watch for Share buttons and add Multi-Group buttons
   */
  function setupMultiGroupButtonObserver() {
    console.log('🔍 Setting up Multi-Group button observer...');
    
    // Run once on page load
    if (UI && UI.addMultiGroupButtons) {
      UI.addMultiGroupButtons();
    }
    
    // Use a debounced approach to prevent excessive calls
    let debounceTimer = null;
    
    // Set up a mutation observer to watch for new Share buttons
    const multiGroupObserver = new MutationObserver(() => {
      // Clear existing timer
      if (debounceTimer) {
        clearTimeout(debounceTimer);
      }
      
      // Set a new timer - only run after 500ms of no mutations
      debounceTimer = setTimeout(() => {
        if (UI && UI.addMultiGroupButtons) {
          UI.addMultiGroupButtons();
        }
      }, 500);
    });
    
    // Start observing
    multiGroupObserver.observe(document.body, {
      childList: true,
      subtree: true
    });
    
    console.log('✅ Multi-Group button observer active');
  }
  
  // Initialize Multi-Group button observer when page loads
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', setupMultiGroupButtonObserver);
  } else {
    setupMultiGroupButtonObserver();
  }

  // Record which profile this page belongs to (v17.0), so the preset chooser can
  // name a profile the user isn't currently switched to. FB's name blob isn't
  // always in the DOM on first paint, so retry once after the page settles.
  function rememberActiveProfile() {
    if (Core && Core.Profile) Core.Profile.remember().catch(() => {});
  }
  rememberActiveProfile();
  setTimeout(rememberActiveProfile, 4000);

  // --- Auto-Share (reuses the existing Multi-Group button) ---
  // SIMPLE automation: click the already-working animated Multi-Share button on a post.
  // Its own handler opens the native share popup, clicks "Group", and loads groups.
  // We then auto-tick the configured groups and click "Share to Selected Groups".
  async function runAutoShareFromPage(request, sendResponse) {
    try {
      const groupsPerPost = request.groupsPerPost || 5;
      const Core = window.ShareUnlimited.Core;
      if (!Core) { sendResponse({ success: false, message: 'Core not loaded' }); return; }

      // Find a post's Multi-Share button (the animated button that already works manually).
      // Do NOT filter by offsetParent/busy — the button exists even if slightly off-screen.
      // Retry for a few seconds in case the buttons are still being injected.
      let mgButtons = [];
      for (let attempt = 0; attempt < 20; attempt++) {
        mgButtons = Array.from(document.querySelectorAll('[data-multi-group-button="true"]'))
          .filter(b => b.dataset.busy !== 'true');
        if (mgButtons.length) break;
        await new Promise(r => setTimeout(r, 500));
      }
      if (!mgButtons.length) {
        sendResponse({ success: false, message: 'No Multi-Share buttons found. Scroll to a post first.' });
        return;
      }

      const mgButton = mgButtons[0];
      // Clear any stale busy flag from a previous failed cycle (the button's own
      // handler ignores clicks while busy, which would silently do nothing).
      mgButton.dataset.busy = 'false';
      console.log('Auto-share: clicking Multi-Share button for a post...');
      // The button's OWN handler opens the native popup, clicks "Group", and loads the
      // group list with checkboxes (this is the manual flow that already works).
      mgButton.click();

      // Wait for the "Share to a group" dialog to appear (the button's handler
      // should open it). Poll up to 10s.
      // CRITICAL: Must specifically find the GROUP PICKER dialog (has search input + listitems),
      // NOT the native Share popup (aria-label="Share") which opens simultaneously.
      function findGroupPickerDialog() {
        const dialogs = document.querySelectorAll('div[role="dialog"]');
        for (const d of dialogs) {
          if (Core.Struct && Core.Struct.findGroupSearchInput(d) && d.querySelector('div[role="listitem"]')) {
            return d;
          }
        }
        return null;
      }

      let groupDialog = null;
      for (let i = 0; i < 20; i++) {
        await new Promise(r => setTimeout(r, 500));
        groupDialog = findGroupPickerDialog();
        if (groupDialog) break;
      }
      if (!groupDialog) {
        sendResponse({ success: false, message: 'Group picker dialog did not open after clicking Multi-Share.' });
        return;
      }

      // The group picker is open but checkboxes (.multi-share-checkbox) may not yet
      // exist — they are injected by our content_ui_elements.js when the "Share to a
      // group" heading is detected. If they are missing, trigger the scan manually.
      let checkboxes = document.querySelectorAll('.multi-share-checkbox');
      if (!checkboxes.length && Core && Core.Struct) {
        console.log('Auto-share: no checkboxes found — triggering checkbox scan...');
        // Ensure the search input is cleared so all groups are visible
        const searchInput = Core.Struct.findGroupSearchInput(groupDialog);
        if (searchInput && searchInput.value) {
          const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
          nativeSetter.call(searchInput, '');
          searchInput.dispatchEvent(new Event('input', { bubbles: true }));
          await new Promise(r => setTimeout(r, 500));
        }
        // Scroll to load groups and add checkboxes
        await Core.scrollToLoadAllGroups(() => {
          let added = 0;
          groupDialog.querySelectorAll('div[role="button"]').forEach(button => {
            if (button.querySelector('.multi-share-checkbox')) return;
            if (button.dataset.multiGroupButton === 'true') return;
            const buttonText = button.textContent.trim();
            const hasImage = button.querySelector('image, img, svg') !== null;
            const isInGroupList = button.closest('[role="listitem"]') !== null;
            const hasGroupIndicator = hasImage && isInGroupList;
            if (buttonText.length > 10 && buttonText.length < 200 && hasGroupIndicator) {
              const groupName = Core.extractAndValidateGroupName ? Core.extractAndValidateGroupName(buttonText, button) : null;
              if (!groupName) return;
              const checkbox = document.createElement('input');
              checkbox.type = 'checkbox';
              checkbox.className = 'multi-share-checkbox';
              checkbox.style.cssText = 'margin-right:12px !important; height:20px !important; width:20px !important; cursor:pointer !important; accent-color:#1877f2 !important; flex-shrink:0 !important;';
              button.style.display = 'flex';
              button.style.alignItems = 'center';
              button.style.gap = '8px';
              button.prepend(checkbox);
              added++;
            }
          });
          return added;
        }, null, null, null, null);
        checkboxes = document.querySelectorAll('.multi-share-checkbox');
      }

      if (!checkboxes.length) {
        sendResponse({ success: false, message: 'Group list did not load after clicking Multi-Share.' });
        return;
      }

      // Build available groups with stable names
      const availableGroups = [];
      checkboxes.forEach(cb => {
        const row = cb.closest('div[role="button"]');
        if (!row) return;
        const name = (Core.extractAndValidateGroupName ? Core.extractAndValidateGroupName(row.textContent, row) : (row.querySelector('span') ? row.querySelector('span').textContent.trim() : '')).trim();
        if (name && name.length > 2) availableGroups.push({ name, checkbox: cb });
      });
      if (!availableGroups.length) {
        sendResponse({ success: false, message: 'No valid groups found in dialog.' });
        return;
      }

      // Round-robin rotation stored in chrome.storage.local
      const rotation = await new Promise(res => {
        chrome.storage.local.get(['autoShareGroupRotation'], r => res(r.autoShareGroupRotation || { shuffledNames: [], index: 0 }));
      });
      if (!rotation.shuffledNames.length || rotation.index >= rotation.shuffledNames.length) {
        const names = availableGroups.map(g => g.name);
        for (let i = names.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [names[i], names[j]] = [names[j], names[i]];
        }
        rotation.shuffledNames = names;
        rotation.index = 0;
      }
      const selectedNames = rotation.shuffledNames.slice(rotation.index, rotation.index + groupsPerPost);
      rotation.index += groupsPerPost;
      chrome.storage.local.set({ autoShareGroupRotation: rotation });

      // Tick the selected groups
      checkboxes.forEach(cb => { cb.checked = false; });
      let selectedCount = 0;
      availableGroups.forEach(g => {
        if (selectedNames.includes(g.name) && selectedCount < groupsPerPost) {
          g.checkbox.checked = true;
          selectedCount++;
        }
      });
      // Trigger the same save the manual UI uses
      if (window.ShareUnlimited.UI && window.ShareUnlimited.UI.getSavedSelections) {
        // dispatch change events so the UI's handler saves selections
        checkboxes.forEach(cb => cb.dispatchEvent(new Event('change', { bubbles: true })));
      }
      await new Promise(r => setTimeout(r, 800));

      // Click "Share to Selected Groups" — the exact manual button
      const shareBtn = document.getElementById('share-unlimited-share-btn');
      if (shareBtn) {
        shareBtn.click();
        sendResponse({ success: true, message: `Shared to ${selectedCount} groups` });
      } else {
        // Fallback to handleQuickShare()
        if (Core.handleQuickShare) { await Core.handleQuickShare(); sendResponse({ success: true, message: `Shared to ${selectedCount} groups` }); }
        else sendResponse({ success: false, message: 'Share button not found in dialog.' });
      }
    } catch (e) {
      console.error('runAutoShareFromPage error:', e);
      sendResponse({ success: false, message: e.message });
    }
  }

  // --- Message Listeners ---

  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === 'ping') {
      console.log('Received ping from popup');
      sendResponse({ status: 'ready' });
      return true;
    }

    // Can the user actually SEE our entry point right now? (v17.7)
    //
    // The popup's "how to start" panel points at the Multi-Share button, so it needs
    // to know whether that button exists on this page — and, if not, whether that is
    // simply because there is no shareable post on screen (normal) or because we
    // could not recognise Facebook's own Share button (the genuine unsupported-layout
    // case, and the ONLY situation where suggesting an English fallback is honest).
    if (request.type === 'get_injection_status') {
      let buttonPresent = false;
      let shareButtonFound = false;
      try {
        buttonPresent = !!document.querySelector('[data-multi-group-button="true"]');
        // Facebook's own Share control, matched the same language-independent way the
        // rest of the extension does: an aria-label'd button is language-specific, so
        // fall back to counting posts that expose any share affordance.
        shareButtonFound = buttonPresent ||
          !!document.querySelector('div[role="article"] div[role="button"][aria-label]');
      } catch (e) { /* status is advisory — never throw at the popup */ }
      sendResponse({ buttonPresent, shareButtonFound });
      return true;
    }

    // Which FB profile this tab is on — the popup can't read FB's cookies or
    // page, so it asks the content script (v17.0). Used to stamp new presets and
    // to mark which saved presets belong to the profile in use.
    if (request.type === 'get_profile_identity') {
      const profile = (Core && Core.Profile) ? Core.Profile.getActive() : { id: null, name: null };
      sendResponse({ profile });
      return true;
    }

    if (request.type === 'get_groups') {
      if (Core && Core.getGroupNames) {
        Core.getGroupNames().then(groups => {
          console.log('Popup requested groups, found:', groups);
          sendResponse({ groups: groups });
        });
      } else {
        sendResponse({ groups: [] });
      }
      return true; 
    }

    if (request.type === 'show_all_groups') {
      console.log('Show all groups requested from popup');
      
      const dialog = getShareDialog();
      if (!dialog) {
        sendResponse({ success: false, message: 'Group dialog not open. Please open "Share to a group" dialog first.' });
        return true;
      }

      const h2Elements = dialog.querySelectorAll('h2, h3');
      let isShareToGroupDialog = false;
      for (const h2 of h2Elements) {
        const h2Text = h2.textContent.trim();
        const spanInH2 = h2.querySelector('span');
        const spanText = spanInH2 ? spanInH2.textContent.trim() : '';
        if (h2Text === 'Share to a group' || spanText === 'Share to a group') {
          isShareToGroupDialog = true;
          break;
        }
      }
      
      // Non-English UI (v17.7): the heading check above is English-only, so the popup's
      // share command reported "Wrong dialog open" on a translated Facebook even with the
      // picker plainly on screen.
      if (!isShareToGroupDialog && Core && Core.Struct &&
          Core.Struct.findGroupSearchInput(dialog) && dialog.querySelector('div[role="listitem"]')) {
        isShareToGroupDialog = true;
      }

      if (!isShareToGroupDialog) {
        sendResponse({ success: false, message: 'Wrong dialog open. Please open "Share to a group" dialog.' });
        return true;
      }
      
      (async () => {
        if (!Core) {
           sendResponse({ success: false, message: 'Core not loaded' });
           return;
        }
        
        console.log('Clearing search input before loading all groups...');
        const searchInputs = dialog.querySelectorAll('input[type="search"], input[placeholder*="Search"], input[aria-label*="Search"]');
        for (const input of searchInputs) {
          if (input.value) {
            console.log('Found search input with value, clearing it:', input.value);
            input.value = '';
            input.dispatchEvent(new Event('input', { bubbles: true }));
            input.dispatchEvent(new Event('change', { bubbles: true }));
            await Core.sleep(500); 
          }
        }
        
        // FIX: Move addedGroupNames Set OUTSIDE the callback to persist across all scroll iterations
        // This prevents the same group from being processed multiple times
        const addedGroupNames = new Set();
        
        await Core.scrollToLoadAllGroups(() => {
          const allButtons = dialog.querySelectorAll('div[role="button"]');
          let newCheckboxes = 0;
          
          allButtons.forEach((button) => {
            const buttonText = button.textContent.trim();
            const buttonTextLength = buttonText.length;
            const hasImage = button.querySelector('image, img, svg') !== null;
            
            const isInGroupList = button.closest('[role="listitem"]') !== null;
            const hasGroupIndicator = buttonText.includes('Public group') ||
                                     buttonText.includes('Private group') ||
                                     buttonText.toLowerCase().includes('members') ||
                                     (isInGroupList && (buttonText.includes('Public') || buttonText.includes('Private'))) ||
                                 // Non-English UI (v17.7): all markers above are English, so a
                                 // translated group list produced NO checkboxes at all. A row inside
                                 // the picker's listitem that carries an avatar is a group row in any
                                 // language.
                                 (isInGroupList && hasImage);

            if (buttonTextLength > 10 && buttonTextLength < 200 && hasImage && hasGroupIndicator) {
              // Use the same validation as getGroupNames()
              const groupName = Core.extractAndValidateGroupName(buttonText, button);
              if (groupName && !addedGroupNames.has(groupName) && !button.querySelector('.multi-share-checkbox')) {
                addedGroupNames.add(groupName);
                const checkbox = document.createElement('input');
                checkbox.type = 'checkbox';
                checkbox.className = 'multi-share-checkbox';
                checkbox.style.cssText = `
                  margin-right: 16px !important; 
                  height: 44px !important; 
                  width: 44px !important; 
                  cursor: pointer !important; 
                  z-index: 9999 !important; 
                  position: relative !important;
                  accent-color: #1877f2 !important;
                  border: 3px solid #1877f2 !important;
                  border-radius: 6px !important;
                  flex-shrink: 0 !important;
                  background: white !important;
                `;
                
                // Restore saved selection state
                if (UI && UI.applySelectionState) {
                  const selections = sessionStorage.getItem('shareUnlimited_checkboxSelections');
                  if (selections) {
                    try {
                      const parsed = JSON.parse(selections);
                      if (parsed[groupName] === true) {
                        checkbox.checked = true;
                      }
                    } catch (e) {}
                  }
                }
                
                checkbox.addEventListener('click', (e) => { 
                  e.stopPropagation(); 
                  // Save selections when checkbox state changes
                  setTimeout(() => {
                    const selections = {};
                    document.querySelectorAll('.multi-share-checkbox').forEach(cb => {
                      const btn = cb.closest('div[role="button"]');
                      if (btn && Core && Core.extractAndValidateGroupName) {
                        const btnText = btn.textContent.trim();
                        const gName = Core.extractAndValidateGroupName(btnText, btn);
                        if (gName) {
                          selections[gName] = cb.checked;
                        }
                      }
                    });
                    sessionStorage.setItem('shareUnlimited_checkboxSelections', JSON.stringify(selections));
                  }, 100);
                }, true);
                checkbox.addEventListener('mousedown', (e) => { e.stopPropagation(); }, true);
                
                button.style.display = 'flex';
                button.style.alignItems = 'center';
                button.style.gap = '8px';
                button.prepend(checkbox);
                newCheckboxes++;
              }
            }
          });
          
          return newCheckboxes;
        });
        
        const groups = await Core.getGroupNames();
        console.log(`✓ All groups loaded: ${groups.length} total`);
        sendResponse({ success: true, totalGroups: groups.length });
      })();
      
      return true; 
    }

    if (request.type === 'share_to_groups') {
      console.log('Popup requested sharing to groups:', request.groups);
      if (Core && Core.shareToSelectedGroups) {
        (async () => {
          // Free-forever model (v15.8): never license-gated — unlicensed and expired
          // users share with a watermark, added inside shareToSelectedGroups
          const result = await Core.shareToSelectedGroups(
            request.groups,
            request.postContent,
            request.postVariations,
            request.postSignature,
            request.delay,
            request.randomizeDelay
          );
          sendResponse(result);
        })();
      } else {
        sendResponse({ success: false, message: 'Core functionality not loaded' });
      }
      return true;
    }

    if (request.type === 'schedule_to_groups') {
      console.log('Popup requested scheduling to groups:', request.groups, 'at', request.scheduledDate, request.scheduledTime);
      if (Core && Core.shareToSelectedGroups) {
        (async () => {
          // Free-forever model (v15.8): never license-gated — watermark added on share
          const result = await Core.shareToSelectedGroups(
            request.groups,
            request.postContent,
            request.postVariations,
            request.postSignature,
            request.delay,
            request.randomizeDelay,
            request.scheduledDate,
            request.scheduledTime
          );
          sendResponse(result);
        })();
      } else {
        sendResponse({ success: false, message: 'Core functionality not loaded' });
      }
      return true;
    }

    // ==================== AUTO-SHARE (reuses the existing Multi-Group button) ====================
    // SIMPLE automation: click the already-working animated Multi-Share button on a post.
    // Its own handler opens the native share popup, clicks "Group", and loads groups.
    // We then auto-tick the configured groups and click "Share to Selected Groups".

    if (request.type === 'auto_share_from_page') {
      console.log('Auto-share: reusing existing Multi-Share button flow');
      runAutoShareFromPage(request, sendResponse);
      return true;
    }
  });
})();
