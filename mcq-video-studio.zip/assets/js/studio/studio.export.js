/**
 * MCQ Video Studio - Export Module
 * 
 * Handles video export via Web Worker with WebCodecs/mp4-muxer.
 * Split from studio.controller.js for maintainability.
 * 
 * @requires MCQVSLogger (studio.logger.js)
 * @requires Worker (vs-render-worker.js)
 * 
 * @version 8.7.1
 * @since 2026-02-01
 */

(function (window) {
    'use strict';

    const Logger = window.MCQVSLogger;

    class ExportManager {
        constructor(state, config) {
            this.state = state;
            this.config = config;
            this.worker = null;
            this.abortController = null;
            this.isPaused = false; // @NEW 2026-02-09
            this.exportPart = null; // @NEW 2026-02-11: Support part suffix

            if (Logger) {
                Logger.info('EXPORT_INIT');
            }
        }

        /**
         * Start batch export
         * 
         * @param {Array} questionIndices - Indices of questions to export
         * @returns {Promise}
         */
        /**
         * Start batch export
         * 
         * @param {Array} questionIndices - Indices of questions to export
         * @param {Object} options - Export options (e.g. { part: 1 })
         * @returns {Promise}
         */
        async startExport(questionIndices, options = {}) {
            console.log('[Export] Starting export...', questionIndices, options);
            if (!questionIndices || questionIndices.length === 0) {
                throw new Error('No questions selected for export');
            }

            // @NEW 2026-02-11: Store part suffix for filename
            this.exportPart = options.part !== undefined ? options.part : null;

            // @MODIFIED 2026-02-02: Capability preflight before any work
            this.checkCapabilities();

            // Security check: HTTPS required for video export
            if (!this.checkSecureContext()) {
                throw new Error('HTTPS required for video export');
            }

            // Create abort controller for cancellation
            this.abortController = new AbortController();

        try {
            // @NEW 2026-04-22: Ensure background video frames are extracted for URL-based videos
            await this.ensureBgVideoFrames();

            // @NEW 2026-04-22: Capture WebSpeech voiceover for export parity
            await this.captureWebSpeechForExport();

            // Spawn worker
                console.log('[Export] Spawning worker...');
                await this.spawnWorker();
                console.log('[Export] Worker spawned.');

                // Prepare job data
                console.log('[Export] Preparing jobs...');
                const jobs = await this.prepareJobData(questionIndices);
                console.log('[Export] Jobs prepared:', jobs.length);

                // FIX 2026-02-03: renderPlan is REQUIRED by vs-render-worker.js
                // @FIX: Build render plan ONCE before audio+video so audio and video share the same plan
                console.log('[Export] Ensuring render plan...');
                const plan = this._buildExportPlanForAudio(questionIndices);
                this.state.renderPlan = plan;
                console.log('[Export] Render plan ready:', plan ? 'Yes' : 'No');

                // Prepare audio (passes the shared plan to avoid drift)
                console.log('[Export] Preparing audio...');
                const audioData = await this.prepareAudio(jobs, plan);
                console.log('[Export] Audio prepared:', audioData ? 'Yes' : 'No');

                // Start worker processing
                console.log('[Export] Starting worker processing...');
                await this.startWorkerProcessing(jobs, audioData);
                console.log('[Export] Worker processing started (awaiting completion).');

                if (Logger) {
                    Logger.info('EXPORT_COMPLETE', {
                        jobCount: jobs.length,
                        timestamp: Date.now()
                    });
                }

            } catch (error) {
                console.error('[Export] Fatal error:', error);
                if (Logger) {
                    Logger.error('EXPORT_FAIL', {
                        error: error.message,
                        stack: error.stack
                    });
                }
                throw error;
            } finally {
                this.cleanup();
            }
        }

        // FIX 2026-02-03: Worker requires a valid renderPlan (scenes + totalMs). Modular state never sets it.
        // Build a deterministic plan here so export works even if Preview was never started.
        getTimingForWorker() {
            const t = this.state.timing || {};

            const hookIntro = Number(t.hookIntro ?? 1200);   // shorts-first (SSOT)
            const outroDuration = Number(t.outroDuration ?? 3200);

            // Map modular timing -> worker timing contract (questionPhases + questionTotal)
            const intro = Number(t.questionAppear ?? 600);
            const reveal = Number(t.revealAnswer ?? 2000);

            // optionsAppear + userThinkTime approximates the "reading" window
            const readingCandidate =
                Number(t.optionsAppear ?? 500) + Number(t.userThinkTime ?? 4600);

            const questionTotal =
                Number(t.questionTotal ?? (intro + readingCandidate + reveal));

            const reading = Math.max(0, questionTotal - intro - reveal);

            return {
                hookIntro,
                questionTotal,
                questionPhases: { intro, reading, reveal },
                outroDuration
            };
        }

        // FIX 2026-02-03: Build the playlist used to create renderPlan scenes.
        buildPlaylistForExport(questionIndices) {
            const timing = this.getTimingForWorker();
            const playlist = [];

            // @FIX 2026-08-11 (SSOT): This path was the ONLY one omitting the cover
            // scene — plan.builder (preview) and server-renderer both include it when
            // coverConfig.enabled !== false, so a plan built here differed (cover
            // dropped) from preview/headless renders. Mirror them: 1000ms cover scene
            // gated on the same coverConfig.enabled check.
            const coverCfg = this.state.coverConfig || {};
            if (coverCfg.enabled !== false) {
                playlist.push({
                    id: "cover",
                    type: "cover",
                    duration: 1000,
                    content: {},
                    timing
                });
            }

            const hookText = String(this.state.hookText || "").trim();
            // @FIX 2026-08-11: Skip the hook scene when hidden — no dead gap before Q1.
            //       Mirrors plan.builder.js + server-renderer.js (SSOT).
            if (hookText && this.state.hookVisible !== false) {
                playlist.push({
                    id: "hook",
                    type: "hook",
                    duration: timing.hookIntro,
                    content: { hookText, hookVisible: (this.state.hookVisible !== false) },
                    timing
                });
            }

            const totalQuestions = questionIndices.length;

            questionIndices.forEach((qIndex, sequenceIndex) => {
                const q = this.state.questions?.[qIndex];
                if (!q) return;

                playlist.push({
                    id: `q${qIndex}`, // keep stable id matching original index
                    type: "question",
                    duration: timing.questionTotal,
                    content: {
                        ...q,
                        questionIndex: qIndex,
                        sequenceIndex,
                        totalQuestions
                    },
                    timing
                });
            });

            // Outro always exists
            const ctaText = String(
                this.state.computedCtaText || this.state.ctaText || "Subscribe!"
            ).trim();

            playlist.push({
                id: "outro",
                type: "outro",
                duration: timing.outroDuration,
                content: { ctaText },
                timing
            });

            return playlist;
        }

        // FIX 2026-02-03: Ensure renderPlan exists and is valid before calling STARTBATCH.
        ensureRenderPlan(questionIndices) {
            // @FIX 2026-02-09: Force rigorous plan rebuild if exporting a subset (Batch Mode).
            // Prevent reusing global plan (e.g. 20 Qs) for a batch (e.g. 5 Qs).
            const isBatchExport = Array.isArray(questionIndices) && questionIndices.length > 0;

            // Only reuse cached plan if NOT in batch mode, or if cache matches batch size (heuristic)
            const existing = this.state.renderPlan;
            if (!isBatchExport && existing && Array.isArray(existing.scenes) && existing.scenes.length > 0 && Number(existing.totalMs) > 0) {
                return existing;
            }

            const playlist = this.buildPlaylistForExport(questionIndices);

	const fps = Number(this.state.fps || 30);
		const width = Number(this.state.width || (window.StudioController?.RESOLUTION?.width) || (this.config?.canvasSize?.width) || 1080);
		const height = Number(this.state.height || (window.StudioController?.RESOLUTION?.height) || (this.config?.canvasSize?.height) || 1920);

            // @FIX 2026-07-02: Use MCQVS_PlanBuilder (adds sfxEvents/fxEvents/duckWindows via getCuePoints)
            // instead of raw MCQVSRenderPlan which produces a plan WITHOUT cue points.
            let plan = null;

            if (window.MCQVS_PlanBuilder && typeof window.MCQVS_PlanBuilder.buildFromPlaylist === "function") {
                const sfxUrl = (name) => this._resolveSfxUrl(name);
                plan = window.MCQVS_PlanBuilder.buildFromPlaylist(playlist, {
                    fps,
                    width,
                    height,
                    templateId: this.state.currentTemplate,
                    sfxMap: {
                        tick: sfxUrl('tick'),
                        correct: sfxUrl('correct'),
                        wrong: sfxUrl('wrong'),
                        reveal: sfxUrl('reveal'),
                        transition: sfxUrl('transition'),
                        whoosh: sfxUrl('whoosh'),
                        success: sfxUrl('success')
                    }
                });
            } else if (window.MCQVSRenderPlan && typeof window.MCQVSRenderPlan.buildFromPlaylist === "function") {
                plan = window.MCQVSRenderPlan.buildFromPlaylist(playlist, {
                    fps,
                    width,
                    height,
                    templateId: this.state.currentTemplate
                });
            } else {
                // Fallback: worker-compatible minimal plan.
                let cursor = 0;
                const scenes = playlist.map(s => {
                    const startMs = cursor;
                    const durMs = Number(s.duration || 0);
                    cursor += durMs;
                    return {
                        id: String(s.id),
                        type: String(s.type),
                        startMs,
                        durMs,
                        endMs: startMs + durMs,
                        content: s.content || {},
                        timing: s.timing || null
                    };
                });

                plan = {
                    templateId: this.state.currentTemplate,
                    fps,
                    frameMs: 1000 / fps,
                    width,
                    height,
                    scenes,
                    totalMs: cursor,
                    createdAt: Date.now(),
                    fxEvents: [],
                    sfxEvents: [],
                    duckWindows: []
                };
            }

            // Final hard validation (fail-fast, better than letting worker crash)
            if (!plan || !Array.isArray(plan.scenes) || plan.scenes.length === 0 || !Number(plan.totalMs)) {
                throw new Error("RenderPlan build failed: empty scenes or invalid totalMs.");
            }

            this.state.renderPlan = plan;
            return plan;
        }

        /**
         * @NEW 2026-02-02: Preflight check - verify WebCodecs + Worker + OffscreenCanvas support
         * Fails fast with actionable error before worker spawn
         */
        checkCapabilities() {
            const missing = [];

            if (!window.OffscreenCanvas) {
                missing.push('OffscreenCanvas');
            }
            if (!window.Worker) {
                missing.push('Web Worker');
            }
            if (!window.VideoEncoder) {
                missing.push('VideoEncoder (WebCodecs)');
            }
            if (!window.AudioEncoder) {
                missing.push('AudioEncoder (WebCodecs)');
            }

            if (missing.length > 0) {
                const msg = `Export not supported in this browser. Missing: ${missing.join(', ')}. Use Chrome 94+, Edge 94+, or Opera 80+.`;
                if (Logger) {
                    Logger.error('EXPORT_UNSUPPORTED_BROWSER', {
                        missing: missing,
                        userAgent: navigator.userAgent
                    });
                }
                throw new Error(msg);
            }

            if (Logger) {
                Logger.info('EXPORT_CAPABILITIES_OK', {
                    browser: navigator.userAgent.split(' ').pop()
                });
            }
        }

        /**
         * Check if secure context (HTTPS/localhost)
         */
        checkSecureContext() {
            const isLocalhost =
                location.hostname === 'localhost' ||
                location.hostname === '127.0.0.1';

            if (!window.isSecureContext && !isLocalhost) {
                if (Logger) {
                    Logger.error('EXPORT_INSECURE_CONTEXT', {
                        hostname: location.hostname
                    });
                }
                return false;
            }

            return true;
        }

        /**
         * Spawn render worker
         */
        async spawnWorker() {
            return new Promise((resolve, reject) => {
                (async () => {
                    try {
                        const pluginUrl = this.config.rootUrl + 'assets/';
                        // @MODIFIED 2026-02-07: Force reload for Parity (Font sizes etc.)
                        const v = Date.now();
                        const workerUrl = `${pluginUrl}js/vs-render-worker.js?v=${v}`;

                        if (this.worker) {
                            this.worker.terminate();
                        }

                        this.worker = new Worker(workerUrl);

                        if (Logger) {
                            Logger.info('EXPORT_WORKER_SPAWN', { workerUrl });
                        }

                        // Create OffscreenCanvas
const width = Number(this.state.width) || (window.StudioController?.RESOLUTION?.width) || (this.config?.canvasSize?.width) || 1080;
const height = Number(this.state.height) || (window.StudioController?.RESOLUTION?.height) || (this.config?.canvasSize?.height) || 1920;
const offscreen = new OffscreenCanvas(width, height);

                        // Prepare assets
                        const assets = await this.prepareAssets();

                        // Prepare fonts
                        const fonts = await this.prepareFonts();

                        // FIX 2026-02-03: Normalize timing for worker/templates (questionPhases + questionTotal)
                        const workerTiming = this.getTimingForWorker();

                        // Worker config
        const workerConfig = {
            ...this.config,
            assetsUrl: this.config.assetsUrl || pluginUrl,
            fontOverride: this.state.fontOverride || null,
            templateConfig: this.state.templateConfig || {},
            templateColors: this.state.templateColors || null,
            templateFonts: this.state.templateFonts || null,
            templateEffects: this.state.templateEffects || null,
            textEffects: this.state.textEffects || null,
            brandColor: this.state.brandColor || null,
            subHookText: this.state.subHookText || '',

brandName: this.state.brandName || 'TheQuizWire',
quizName: this.state.quizName || '',
coverConfig: this.state.coverConfig || null,
            // @FIX 2026-08-11 (Gap 1): logoPosition was missing from the worker config,
            // so worker renders always fell back to 'all', ignoring the user's
            // corner/outro preference in the exported video.
            logoPosition: this.state.logoPosition || 'all',
            // @NEW 2026-08-11: Explanation bar toggle (default OFF — ultra-minimal Shorts).
            showExplanation: this.state.showExplanation === true,
width: width,
height: height,
hookText: this.state.hookText || 'Can you score 5/5?',
            hookVisible: (this.state.hookVisible !== false),
            ctaText: this.state.computedCtaText || this.state.ctaText || 'Subscribe!',
            websiteUrl: this.state.websiteUrl || '',
            bgVideoFrameDur: this.state.bgVideoFrameDur || 33.33,
            timing: workerTiming
        };

                        // Setup message handler
                        let initComplete = false;

                        this.worker.onmessage = (e) => {
                            const { type, data } = e.data;

                            if (type === 'INIT_COMPLETE') {
                                initComplete = true;
                                if (Logger) Logger.info('EXPORT_WORKER_READY');
                                resolve();
                            } else if (type === 'ERROR' && !initComplete) {
                                if (Logger) {
                                    Logger.error('EXPORT_WORKER_INIT_FAIL', { error: e.data.error });
                                }
                                reject(new Error(e.data.error));
                            }
                        };

                        this.worker.onerror = (error) => {
                            if (Logger) {
                                Logger.error('EXPORT_WORKER_ERROR', { error: error.message });
                            }
                            reject(error);
                        };

                        // Send init message
                        const transferables = [offscreen];
                        if (assets.logoImage) transferables.push(assets.logoImage);
                        if (assets.bgImage) transferables.push(assets.bgImage);
                        if (assets.bgVideoFrames) assets.bgVideoFrames.forEach(bm => transferables.push(bm));
                        fonts.forEach(f => transferables.push(f.buffer));

                        this.worker.postMessage({
                            type: 'INIT',
                            data: {
                                config: workerConfig,
                                canvas: offscreen,
                                assets: assets,
                                fonts: fonts
                            }
                        }, transferables);

                        // @MODIFIED 2026-02-14: Timeout after 60 seconds (increased from 30s)
                        setTimeout(() => {
                            if (!initComplete) {
                                reject(new Error('Worker initialization timeout'));
                            }
                        }, 60000);

                    } catch (err) {
                        reject(err);
                    }
                })();
            });
        }

    /**
     * @NEW 2026-04-22: Capture WebSpeech voiceover via server TTS fallback for export
     * @FIX: Backs up the original provider so it can be restored after export.
     */
    async captureWebSpeechForExport() {
        const vo = this.state.voiceover;
        if (!vo || !vo.enabled) return;
        const provider = String(vo.provider || '').trim();
        if (provider !== 'webspeech') return;

        console.log('[Export] WebSpeech voiceover detected — switching to free Edge TTS for export');
        if (!vo._originalProviderBackup) {
            vo._originalProviderBackup = 'webspeech';
        }
        vo.provider = 'edge';
        vo.webspeechCapturedAudio = true;
    }

    /**
     * @NEW 2026-04-22: Restore original voiceover provider after export
     */
    restoreVoiceoverProvider() {
        const vo = this.state && this.state.voiceover;
        if (!vo || !vo._originalProviderBackup) return;
        if (vo.provider === 'edge' && vo.webspeechCapturedAudio) {
            vo.provider = vo._originalProviderBackup;
        }
        delete vo._originalProviderBackup;
        delete vo.webspeechCapturedAudio;
    }

    /**
     * @NEW 2026-04-22: Ensure background video frames are extracted for URL-based videos
     * If bgVideoFrames is empty but a video URL exists, extract frames now.
     * This guarantees the Worker gets the same background the user sees in preview.
     */
    async ensureBgVideoFrames() {
        const hasFrames = Array.isArray(this.state.bgVideoFrames) && this.state.bgVideoFrames.length > 0;
        const hasVideoUrl = !!(this.state.bgVideoUrl || this.state.bgVideo);

        if (hasFrames || !hasVideoUrl) return;

        const videoUrl = this.state.bgVideoUrl || this.state.bgVideo;
        console.log('[Export] Extracting background video frames from URL for Worker:', videoUrl);

        try {
            if (typeof this.controller?.extractVideoFrames === 'function') {
                await this.controller.extractVideoFrames(videoUrl);
                // @FIX 2026-07-31: Video frames replace any stale image background so the
                //       exported video matches the preview (template-manager prefers frames,
                //       but a leftover bgImage could surface if extraction returned nothing).
                if (Array.isArray(this.state.bgVideoFrames) && this.state.bgVideoFrames.length > 0) {
                    this.state.bgImage = null;
                }
            } else {
                const video = document.createElement('video');
                video.crossOrigin = 'anonymous';
                video.muted = true;
                video.preload = 'auto';
                video.src = videoUrl;

                await new Promise((resolve, reject) => {
                    video.onloadeddata = resolve;
                    video.onerror = reject;
                    setTimeout(() => reject(new Error('Video load timeout')), 30000);
                });

                const maxFrames = 60;
                const duration = video.duration || 10;
                const interval = duration / maxFrames;
                const frames = [];

                for (let i = 0; i < maxFrames; i++) {
                    video.currentTime = i * interval;
                    // @FIX 2026-07-31: The old double-resolve (onseeked + 200ms timeout)
                    //       resolved immediately on the timeout, capturing a not-yet-seeked
                    //       (blank) frame. Seek-then-timeout now races deterministically.
                    await new Promise(r => {
                        let settled = false;
                        const done = () => { if (settled) return; settled = true; clearTimeout(t); r(); };
                        video.onseeked = done;
                        const t = setTimeout(done, 200);
                    });
                    const canvas = document.createElement('canvas');
canvas.width = Number(this.state.width) || (window.StudioController?.RESOLUTION?.width) || (this.config?.canvasSize?.width) || 1080;
canvas.height = Number(this.state.height) || (window.StudioController?.RESOLUTION?.height) || (this.config?.canvasSize?.height) || 1920;
                    const ctx = canvas.getContext('2d');
                    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
                    const img = new Image();
                    img.src = canvas.toDataURL('image/jpeg', 0.85);
                    await new Promise(r => { img.onload = r; img.onerror = r; });
                    frames.push(img);
                }

                this.state.bgVideoFrames = frames;
                this.state.bgVideoFrameDur = interval * 1000;
                // @FIX 2026-07-31: Video replaces any stale image background.
                if (frames.length > 0) this.state.bgImage = null;
                console.log('[Export] Extracted', frames.length, 'background video frames for Worker');
            }
        } catch (e) {
            console.warn('[Export] Failed to extract background video frames:', e.message);
        }
    }

    /**
     * Prepare assets for worker
     */
        async prepareAssets() {
            const assets = {};

            // Convert Image -> ImageBitmap for structured clone + drawImage in worker [PATCH 2026-02-03]
            const toBitmap = async (img) => {
                if (!img) return null;
                // @MODIFIED 2026-02-12: Check for detached Bitmaps (Fixes Batch Font/Image Compression)
                if (img instanceof ImageBitmap && (img.width === 0 || img.height === 0)) {
                    console.warn('[Export] Source bitmap is detached, skipping clone');
                    return null;
                }
                try { return await createImageBitmap(img); } catch (_) { return null; }
            };

            // Logo
            if (this.state.brandLogoImage) {
                const bm = await toBitmap(this.state.brandLogoImage);
                if (bm) assets.logoImage = bm;
            }

            // Background
            if (this.state.bgImage) {
                const bm = await toBitmap(this.state.bgImage);
                if (bm) assets.bgImage = bm;
            }

            // Background video frames (array)
            if (Array.isArray(this.state.bgVideoFrames) && this.state.bgVideoFrames.length) {
                const bitmaps = [];
                for (const f of this.state.bgVideoFrames) {
                    const bm = await toBitmap(f);
                    if (bm) bitmaps.push(bm);
                }
                if (bitmaps.length) assets.bgVideoFrames = bitmaps;
            }

            return assets;
        }

        /**
         * @MODIFIED 2026-02-02: Deterministic font extraction from document.fonts
         * Matches main-thread font registry to prevent preview/export parity issues
         */
    async prepareFonts() {
        const pluginUrl = this.config.assetsUrl || (this.config.rootUrl + 'assets/') || (window.MCQVSConfig && window.MCQVSConfig.assetsUrl);

        const fontList = [
            { name: 'Inter', url: pluginUrl + 'fonts/Inter-Bold.ttf', weight: '700' },
            { name: 'Outfit', url: pluginUrl + 'fonts/Outfit-Bold.ttf', weight: '700' },
            { name: 'Roboto', url: pluginUrl + 'fonts/Roboto-Black.ttf', weight: '900' },
            { name: 'Roboto', url: pluginUrl + 'fonts/Roboto-Bold.ttf', weight: '700' }
        ];

        // @NEW 2026-04-22: Scan document.fonts for all loaded weights to match preview exactly
        try {
            if (document.fonts && document.fonts.forEach) {
                const docFonts = new Map();
                document.fonts.forEach(f => {
                    const key = f.family + '|' + f.weight;
                    if (!docFonts.has(key)) {
                        docFonts.set(key, { name: f.family, weight: f.weight, style: f.style });
                    }
                });
                for (const [, info] of docFonts) {
                    const alreadyAdded = fontList.some(f => f.name === info.name && f.weight === info.weight);
                    if (!alreadyAdded) {
                        const w = info.weight || '400';
                        const weightFile = this._weightToFilename(info.name, w, pluginUrl);
                        if (weightFile) {
                            fontList.push({ name: info.name, url: weightFile, weight: w });
                        }
                    }
                }
            }
        } catch (_) { }

        const currentTemplateId = this.state.currentTemplate || 'trivia';
        let templateFonts = [];

	if (window.MCQVS_VideoTemplates && window.MCQVS_VideoTemplates.get) {
		const tmpl = window.MCQVS_VideoTemplates.get(currentTemplateId);
            if (tmpl && tmpl.fonts) {
                if (tmpl.fonts.primary) templateFonts.push(tmpl.fonts.primary);
                if (tmpl.fonts.secondary) templateFonts.push(tmpl.fonts.secondary);
            }
        }

        if (this.state.fontOverride) {
            templateFonts.push(this.state.fontOverride);
        }

	const fontMap = {
		'Bangers': 'Bangers-Regular.ttf',
		'Permanent Marker': 'PermanentMarker-Regular.ttf',
		'Orbitron': 'Orbitron-Bold.ttf',
		'Press Start 2P': 'PressStart2P-Regular.ttf',
		'Creepster': 'Creepster-Regular.ttf',
		'Cinzel': 'Cinzel-Bold.ttf',
		'Audiowide': 'Audiowide-Regular.ttf',
		'Open Sans': 'OpenSans-Bold.ttf',
		'Lato': 'Lato-Bold.ttf',
		'Playfair Display': 'PlayfairDisplay-Bold.ttf',
		'Quicksand': 'Quicksand-Bold.ttf',
		'Rajdhani': 'Rajdhani-Bold.ttf',
		'Electrolize': 'Electrolize-Regular.ttf',
		'Nosifer': 'Nosifer-Regular.ttf',
		// @FIX 2026-05-02: Removed 'Exo 2' -> 'Exo2-Bold.ttf' (file does not exist on disk, caused 404).
		// Added 'Roboto Mono' which was missing (used by electric & science templates).
		'Roboto Mono': 'RobotoMono-Bold.ttf',
		'VT323': 'VT323-Regular.ttf',
		'Share Tech Mono': 'ShareTechMono-Regular.ttf',
		'Patrick Hand': 'PatrickHand-Regular.ttf',
		'EB Garamond': 'EBGaramond-Bold.ttf',
		'Fira Code': 'FiraCode-Bold.ttf',
		'JetBrains Mono': 'JetBrainsMono-Bold.ttf',
		'Bebas Neue': 'BebasNeue-Regular.ttf',
		'Oswald': 'Oswald-Bold.ttf'
	};

	// @NEW 2026-04-22: Extended weight map for common fonts
	// @FIX 2026-05-02: Removed entries for font weight files that do not exist on disk
	// (Inter-Regular, Inter-Medium, Inter-SemiBold, Inter-Black, Roboto-Regular, Roboto-Medium,
	//  Outfit-Regular, Outfit-Medium, Outfit-SemiBold, Outfit-Black — all produce 404s).
	const weightFileMap = {
		'Inter': { '700': 'Inter-Bold.ttf' },
		'Roboto': { '700': 'Roboto-Bold.ttf', '900': 'Roboto-Black.ttf' },
		'Outfit': { '700': 'Outfit-Bold.ttf' },
	};

        for (const fontName of templateFonts) {
            const name = fontName.split(',')[0].trim().replace(/['"]/g, '');
            if (fontMap[name]) {
                if (!fontList.some(f => f.name === name)) {
                    fontList.push({ name: name, url: pluginUrl + 'fonts/' + fontMap[name], weight: '700' });
                }
            }
        }

        const fonts = [];
        const seen = new Set();

        // @FIX: Add a robust fallback so a single 404 on a weight file (e.g. Inter-Regular)
        //       does not silently drop the entire font. We always end up with at least one
        //       valid TTF buffer for any registered family so export/preview parity holds.
        const FALLBACK_FONT_URL = pluginUrl + 'fonts/Inter-Bold.ttf';
        const FAMILY_FALLBACKS = {};

        for (const font of fontList) {
            const key = font.name + '|' + font.weight;
            if (seen.has(key)) continue;
            seen.add(key);

            try {
                const res = await fetch(font.url, { cache: 'force-cache' });
                if (res.ok) {
                    const buffer = await res.arrayBuffer();
                    fonts.push({ name: font.name, buffer, weight: font.weight || '400' });
                    FAMILY_FALLBACKS[font.name] = font.url;
                    continue;
                }
            } catch (_) { }

            // Primary URL 404'd — try the same family Bold (if different), then Inter-Bold as last resort.
            const candidate =
                FAMILY_FALLBACKS[font.name] ||
                (fontMap && fontMap[font.name] ? pluginUrl + 'fonts/' + fontMap[font.name] : null) ||
                FALLBACK_FONT_URL;
            if (candidate && candidate !== font.url) {
                try {
                    const res2 = await fetch(candidate, { cache: 'force-cache' });
                    if (res2.ok) {
                        const buffer = await res2.arrayBuffer();
                        fonts.push({ name: font.name, buffer, weight: font.weight || '700' });
                        continue;
                    }
                } catch (_) { }
            }
            // Inter-Bold always works (bundled). Use it as generic fallback so the worker
            // has at least one usable font buffer.
            try {
                const fb = await fetch(FALLBACK_FONT_URL, { cache: 'force-cache' });
                if (fb.ok) {
                    const buffer = await fb.arrayBuffer();
                    fonts.push({ name: font.name, buffer, weight: '700' });
                }
            } catch (_) { }
        }

        return fonts;
    }

	_weightToFilename(name, weight, pluginUrl) {
		// @FIX 2026-05-02: Removed entries for font weight files that do not exist on disk
		const weightFileMap = {
			'Inter': { '700': 'Inter-Bold.ttf' },
			'Roboto': { '700': 'Roboto-Bold.ttf', '900': 'Roboto-Black.ttf' },
			'Outfit': { '700': 'Outfit-Bold.ttf' },
		};
		if (weightFileMap[name] && weightFileMap[name][weight]) {
			return pluginUrl + 'fonts/' + weightFileMap[name][weight];
		}
		return null;
	}

        /**
         * Prepare job data
         */
        async prepareJobData(indices) {
            const jobs = [];

            for (const idx of indices) {
                const question = this.state.questions[idx];

                if (!question) {
                    if (Logger) {
                        Logger.warn('EXPORT_INVALID_INDEX', { index: idx });
                    }
                    continue;
                }

                jobs.push({
                    index: idx,
                    question: question,
                    timing: this.state.timing,
                    template: this.state.currentTemplate || 'trivia',
                    fontOverride: this.state.fontOverride || null // @NEW 2026-02-07
                });
            }

            return jobs;
        }

        /**
         * Prepare audio for export
         */
        async prepareAudio(jobs, prebuiltPlan = null) {
            // Master audio gate
            if (!this.state.audioEnabled) return null;

            // Voiceover is an independent audio source — don't skip it just because music + sfx are off.
            const _voiceoverWanted = this._isVoiceoverEnabledForExport();
            // Nothing to do if music + sfx + voiceover are all disabled
            if (!this.state.musicEnabled && !this.state.sfxEnabled && !_voiceoverWanted) return null;

            // @FIX: Reuse the prebuilt render plan supplied by startExport so audio + video share one plan
            let plan = prebuiltPlan;
            if (!plan) {
                // Fallback for chunked re-prepares or external callers
                const chunkIndices = jobs.map(j => j.index);
                plan = this._buildExportPlanForAudio(chunkIndices);
            }
            if (!plan) return null;

            const sampleRate = 44100;

            // Use renderPlan timing (parity), fallback to legacy duration
            const totalMs = Number(plan.totalMs || 0) || (this.calculateTotalDuration(jobs) * 1000);
            const totalDurationSec = Math.max(0.01, totalMs / 1000);

            const offlineCtx = new OfflineAudioContext(2, Math.ceil(sampleRate * totalDurationSec), sampleRate);

            try {
                // 0) Voiceover (TTS) - decode first so we can extend duck windows before mixing music
                let voicePack = null;
                if (this._isVoiceoverEnabledForExport()) {
                    voicePack = await this._prepareVoiceoverAssets(offlineCtx, plan);
                    if (voicePack && Array.isArray(voicePack.duckWindows) && voicePack.duckWindows.length) {
                        plan.duckWindows = Array.isArray(plan.duckWindows) ? plan.duckWindows : [];
                        plan.duckWindows = plan.duckWindows.concat(voicePack.duckWindows);
                    }
                }

                // 1) Background Music (with duck automation)
                if (this.state.musicEnabled && this.state.bgMusicUrl) {
                    await this._mixBackgroundMusicWithDucking(offlineCtx, this.state.bgMusicUrl, totalDurationSec, plan);
                }

                // 1.5) Voiceover placement (after music so voice sits on top)
                if (voicePack && Array.isArray(voicePack.segments) && voicePack.segments.length) {
                    this._mixVoiceoverSegments(offlineCtx, voicePack.segments);
                }

                // 2) SFX timeline (time-locked to plan.sfxEvents)
                if (this.state.sfxEnabled) {
                    await this._mixSfxEvents(offlineCtx, plan);
                }

                // Render final audio
                const renderedBuffer = await offlineCtx.startRendering();

                return {
                    left: new Float32Array(renderedBuffer.getChannelData(0)),
                    right: new Float32Array(renderedBuffer.getChannelData(1)),
                    sampleRate,
                    duration: totalDurationSec
                };

            } catch (error) {
                if (Logger) Logger.warn('EXPORT_AUDIO_FAIL', { error: error.message });
                return null;
            }
        }

        /**
         * Mix background music into OfflineAudioContext
         */
        async mixBackgroundMusic(ctx, url, duration) {
            const response = await fetch(url);
            const arrayBuffer = await response.arrayBuffer();
            const audioBuffer = await ctx.decodeAudioData(arrayBuffer);

            const source = ctx.createBufferSource();
            source.buffer = audioBuffer;
            source.loop = true;

            const gainNode = ctx.createGain();
            gainNode.gain.value = this.state.musicVolume || 0.3;

            source.connect(gainNode);
            gainNode.connect(ctx.destination);
            source.start(0);
        }

        /**
         * Calculate total export duration
         */
        calculateTotalDuration(jobs) {
            const timing = this.state.timing || {};
            const hookDuration = timing.hookIntro || 2000;
            const outroDuration = timing.outroDuration || 5000;
            const questionDuration = timing.questionTotal || 12000;

            return (hookDuration + (jobs.length * questionDuration) + outroDuration) / 1000;
        }
        _buildExportPlanForAudio(subIndices = null) {
            try {
                if (!window.MCQVS_PlanBuilder || typeof window.MCQVS_PlanBuilder.buildFromState !== 'function') {
                    if (Logger) Logger.warn('EXPORT_PLANBUILDER_MISSING');
                    return null;
                }

                // SFX mapping: cue-name -> URL (export uses URLs directly)
                const sfxUrl = (name) => this._resolveSfxUrl(name);

                const sfxMap = {
                    tick: sfxUrl('tick'),
                    correct: sfxUrl('correct'),
                    wrong: sfxUrl('wrong'),
                    reveal: sfxUrl('reveal'),
                    transition: sfxUrl('transition'),
                    whoosh: sfxUrl('whoosh'),
                    success: sfxUrl('success')
                };

                // Asset config is used by PlanBuilder to collect deps if needed
                const assetConfig = {
                    musicUrl: String(this.state.bgMusicUrl || '').trim() || null,
                    sfx: sfxMap
                };

                // @MODIFIED 2026-02-09: Support "Shadow State" for Batch Exports
                // If subIndices is provided, create a localized state that only includes those questions.
                // This ensures MCQVS_PlanBuilder generates a plan (and duration) matching the video chunk.
                let stateToUse = this.state;
                if (Array.isArray(subIndices) && subIndices.length > 0) {
                    stateToUse = Object.assign({}, this.state, {
                        selectedQuestions: subIndices
                    });
                }

return window.MCQVS_PlanBuilder.buildFromState(stateToUse, {
fps: 30,
width: Number(this.state.width) || (window.StudioController?.RESOLUTION?.width) || (this.config?.canvasSize?.width) || 1080,
height: Number(this.state.height) || (window.StudioController?.RESOLUTION?.height) || (this.config?.canvasSize?.height) || 1920,
                    templateId: this.state.templateId || this.state.currentTemplate || 'trivia',
                    sfxMap,
                    assetConfig
                });
            } catch (e) {
                if (Logger) Logger.warn('EXPORT_PLAN_BUILD_FAIL', { error: e.message });
                return null;
            }
        }

        _resolveSfxUrl(name) {
            const n = String(name || '').trim();
            if (!n) return null;

            // If plan already provides URL, accept it
            if (/^(blob:|data:|https?:\/\/|\/)/i.test(n) || /\.(mp3|wav|ogg)(\?|#|$)/i.test(n)) return n;

            // Preferred: deterministic state storage (if you add it later)
            const map = (this.state && this.state.sfxUrls && typeof this.state.sfxUrls === 'object') ? this.state.sfxUrls : null;
            if (map && map[n]) return String(map[n]);

            // Fallback: AudioLibrary
            const lib = window.MCQVS_AudioLibrary;
            if (lib && lib.sfx && lib.sfx[n] && Array.isArray(lib.sfx[n]) && lib.sfx[n][0] && lib.sfx[n][0].url) {
                return lib.sfx[n][0].url;
            }

            // Last fallback: local assets convention
            const base = (this.config && this.config.assetsUrl) ? String(this.config.assetsUrl) : './assets/';
            return base.replace(/\/+$/, '') + '/audio/sfx/' + n + '.mp3';
        }

        async _fetchDecode(offlineCtx, url) {
            const u = String(url || '').trim();
            if (!u) return null;

            try {
                // @FIX 2026-07-14: 30s AbortController — audio fetches (music,
                //                 SFX, TTS blob) had no timeout, so a hung TCP
                //                 connection stalled prepareAudio() forever,
                //                 which stalled startExport(), which left
                //                 __MCQVSRenderRunnerReady unset and the job wedged
                //                 in `rendering` until render.js's 900s budget.
                const ac = new AbortController();
                const t = setTimeout(() => ac.abort(), 30000);
                let res;
                try {
                    res = await fetch(u, { signal: ac.signal });
                } finally {
                    clearTimeout(t);
                }
                if (!res.ok) {
                    console.warn('[Export] Audio fetch failed:', u, res.status);
                    return null;
                }
                const buf = await res.arrayBuffer();
                return await offlineCtx.decodeAudioData(buf);
            } catch (e) {
                console.warn('[Export] Audio decode failed:', u, e.message);
                return null;
            }
        }

        async _mixBackgroundMusicWithDucking(offlineCtx, musicUrl, totalDurationSec, plan) {
            const musicBuffer = await this._fetchDecode(offlineCtx, musicUrl);
            if (!musicBuffer) return;

            const src = offlineCtx.createBufferSource();
            src.buffer = musicBuffer;
            src.loop = true;

            const gain = offlineCtx.createGain();
            const baseVol = 0.30; // match router defaults
            gain.gain.setValueAtTime(baseVol, 0);

            // Apply duck windows from plan (volume field is absolute 0..1)
            const ducks = Array.isArray(plan.duckWindows) ? plan.duckWindows : [];
            const ramp = 0.040;

            for (const w of ducks) {
                const s = Math.max(0, Number(w.startMs || 0) / 1000);
                const e = Math.max(s, Number(w.endMs || 0) / 1000);
                const v = Math.max(0, Math.min(1, Number(w.volume != null ? w.volume : 0.18)));

                // ramp down
                gain.gain.setValueAtTime(baseVol, Math.max(0, s - ramp));
                gain.gain.linearRampToValueAtTime(v, s);

                // hold and ramp up
                gain.gain.setValueAtTime(v, Math.max(s, e - ramp));
                gain.gain.linearRampToValueAtTime(baseVol, e);
            }

            src.connect(gain).connect(offlineCtx.destination);
            src.start(0);
        }

        async _mixSfxEvents(offlineCtx, plan) {
            const events = Array.isArray(plan.sfxEvents) ? plan.sfxEvents : [];
            if (!events.length) return;

            // Cache decoded buffers by URL
            const cache = new Map();

            for (const ev of events) {
                try {
                    const atSec = Math.max(0, Number(ev.atMs || 0) / 1000);
                    const gainVal = Math.max(0, Math.min(2, Number(ev.gain != null ? ev.gain : 1)));

                    const url = this._resolveSfxUrl(ev.name);
                    if (!url) continue;

                    let buf = cache.get(url);
                    if (!buf) {
                        buf = await this._fetchDecode(offlineCtx, url);
                        if (!buf) continue;
                        cache.set(url, buf);
                    }

                    const src = offlineCtx.createBufferSource();
                    src.buffer = buf;

                    const g = offlineCtx.createGain();
                    const sfxBase = 0.80; // match router defaults
                    g.gain.setValueAtTime(sfxBase * gainVal, atSec);

                    src.connect(g).connect(offlineCtx.destination);
                    src.start(atSec);
                } catch (sfxErr) {
                    // @FIX 2026-07-02: Skip individual SFX failures instead of killing entire audio mix.
                    // Matches preview behavior where AudioRouter silently skips missing buffers.
                    console.warn('[Export] SFX mix skip:', ev.name, sfxErr.message);
                }
            }
        }

        // ============================================================
        // Voiceover (TTS) - mixed into the final MP4
        // ============================================================
    _isVoiceoverEnabledForExport() {
        const vo = (this.state && this.state.voiceover) ? this.state.voiceover : null;
        if (!vo || !vo.enabled) return false;
        const provider = String(vo.provider || '').trim();
        if (!provider || provider === 'webspeech') {
            // @MODIFIED 2026-04-22: Capture WebSpeech audio via server TTS fallback
            // If WebSpeech was used in preview, we request server-side TTS for export
            if (vo.webspeechCapturedAudio) return true;
            return false;
        }
        return true;
    }

        _normalizeTtsText(s) {
            return String(s || '')
                .replace(/<[^>]+>/g, ' ')
                .replace(/[\r\n\t]+/g, ' ')
                .replace(/\s{2,}/g, ' ')
                .trim();
        }

        _voiceLetter(i) {
            return ['A', 'B', 'C', 'D'][Number(i) || 0] || 'A';
        }

        _buildVoiceoverCues(plan) {
            const cues = [];
            const vo = this.state.voiceover || {};
            const speakHook = (vo.speakHook !== false);
            const speakOptions = (vo.speakOptions !== false);
            const speakAnswer = (vo.speakAnswer !== false);
            const speakCta = !!vo.speakCta;

            const hookText = this._normalizeTtsText(this.state.hookText);
            if (speakHook && hookText && this.state.hookVisible !== false) {
                // @FIX 2026-07-30: Offset hook TTS cue by cover scene duration so audio
                //       stays in sync with the visual hook scene (which now starts AFTER
                //       the cover scene). Mirrors the same fix in server-renderer.js.
                // @FIX 2026-08-11 (DRIFT FIX): attach sceneId so the hook scene can be
                //       extended to fit long hook TTS and the cue re-anchors to the rebuilt
                //       hook scene — parity with render-node Phase 3 placement.
                const coverScene = scenes.find(s => s && s.type === 'cover');
                const coverDur = coverScene ? Number(coverScene.durMs || 0) : 0;
                const hookScene = scenes.find(s => s && s.type === 'hook');
                cues.push({ atMs: 50 + coverDur, text: hookText, kind: 'hook', sceneId: hookScene ? hookScene.id : '' });
            }

            const scenes = Array.isArray(plan && plan.scenes) ? plan.scenes : [];
            const questionScenes = scenes.filter(s => s && s.type === 'question');
            const outroScene = scenes.find(s => s && s.type === 'outro');

            questionScenes.forEach((scene, idx) => {
                const c = scene.content || {};
                const qText = this._normalizeTtsText(c.question || c.text);
                const opts = Array.isArray(c.options) ? c.options.map(o => this._normalizeTtsText(o)) : [];
                const correct = Number.isInteger(c.correct) ? c.correct : Number.isInteger(c.correctAnswer) ? c.correctAnswer : 0;

                // 1) Question + options
                // @FIX 2026-07-24: Match server-renderer.js text exactly. The previous
                // "Options:" prefix was an extra spoken word that the WPM estimator did not
                // account for, lengthening real TTS vs the timer. Server uses no wrapper.
                let line = qText ? `Question ${idx + 1}. ${qText}.` : `Question ${idx + 1}.`;
                if (speakOptions && opts.length) {
                    if (opts[0]) line += ` ${opts[0]}.`;
                    if (opts[1]) line += ` ${opts[1]}.`;
                    if (opts[2]) line += ` ${opts[2]}.`;
                    if (opts[3]) line += ` ${opts[3]}.`;
                }
                line = this._normalizeTtsText(line);

                const startMs = Math.max(0, Number(scene.startMs || 0) + 80);
                if (line) cues.push({ atMs: startMs, text: line, kind: 'q_read', sceneId: scene.id });

                // Reveal cue placement: match server-renderer.js exactly. The actual TTS
                // lengths are unknown at cue-build time (Phase 1 measures them later),
                // so a simple startMs+250 baseline is used. computeAdaptiveTiming + the
                // chained cursor in _prepareVoiceoverAssets will guarantee no overlap.
                const earliestRevealCueExport = startMs + 250;

                // 2) Reveal
                if (speakAnswer && opts.length) {
                    const revealMs = Number(scene.timing?.questionPhases?.reveal || 3000);
                    const endMsScene = Number(scene.endMs || (Number(scene.startMs || 0) + Number(scene.durMs || 0)));
                    const revealStart = Math.max(0, endMsScene - revealMs);
                    const letter = this._voiceLetter(correct);
                    const optText = opts[correct] || '';
                    const phraseTplRaw = (typeof vo.answerPhrase === 'string') ? vo.answerPhrase : '';
                    const phraseTpl = this._normalizeTtsText(phraseTplRaw) || 'correct answer is';

                    let ansText = '';
                    if (phraseTplRaw && /\s/.test(phraseTplRaw)) {
                        if (/\{letter\}|\{option\}|\{text\}/i.test(phraseTplRaw)) {
                            ansText = phraseTplRaw
                                .replace(/\{letter\}/gi, letter)
                                .replace(/\{option\}|\{text\}/gi, optText);
                            ansText = this._normalizeTtsText(ansText);
                        } else {
                            ansText = this._normalizeTtsText(`${phraseTpl} ${optText}.`);
                        }
                    } else {
                        ansText = this._normalizeTtsText(`${phraseTpl} ${optText}.`);
                    }

                    const ansLine = ansText;
                    // Match server-renderer.js reveal cue clamp (line 199)
                    const revealCueTime = Math.min(
                        Math.max(revealStart + 20, earliestRevealCueExport),
                        Math.max(earliestRevealCueExport, endMsScene - 100)
                    );
                    cues.push({ atMs: revealCueTime, text: ansLine, kind: 'reveal', sceneId: scene.id });
                }
            });

            // Outro CTA
            if (speakCta && outroScene) {
                const cta = this._normalizeTtsText((outroScene.content && outroScene.content.ctaText) || this.state.computedCtaText || this.state.ctaText);
                if (cta) cues.push({ atMs: Math.max(0, Number(outroScene.startMs || 0) + 200), text: cta, kind: 'cta', sceneId: outroScene.id });
            }

            return cues;
        }

        // @FIX 2026-07-25 (parity with server-renderer.js): Re-derive
        //                 plan.fxEvents / plan.sfxEvents / plan.duckWindows from
        //                 the rebuilt cues so countdown ticks, reveal SFX,
        //                 sparkle bursts, and music duck windows fire at the
        //                 NEW reveal moment — in sync with TTS playback and the
        //                 visual pill countdown. Mirrors vs-video-templates.js
        //                 getCuePoints' cue -> event mapping.
        _realignCueDerivedEvents(plan) {
            if (!plan || !Array.isArray(plan.cues)) return plan;

            // @FIX 2026-07-31 (parity with server-renderer.js): Prefer the REAL
            //                 template getCuePoints — the same one
            //                 MCQVS_PlanBuilder.buildFromPlaylist uses for the
            //                 original pre-adaptive events — so realigned events
            //                 keep the template-aware glow rect, per-template
            //                 intensities/colors, intro/outro flashes, and
            //                 transition SFX. The previous hand-ported mapping
            //                 pinned the glow rect to {24,180,72,72} (top-left
            //                 corner instead of the pill) and dropped flash and
            //                 transition events entirely.
            try {
                const tm = window.MCQVS_TemplateManager;
                if (tm && typeof tm.getTemplate === 'function') {
                    const tpl = tm.getTemplate(plan.templateId) || tm.getTemplate('trivia');
                    const cfg = tpl && tpl.config;
                    if (cfg && typeof cfg.getCuePoints === 'function') {
                        const pack = cfg.getCuePoints(plan) || {};
                        plan.fxEvents = Array.isArray(pack.fxEvents) ? pack.fxEvents : [];
                        plan.sfxEvents = Array.isArray(pack.sfxEvents) ? pack.sfxEvents : [];
                        plan.duckWindows = Array.isArray(pack.duckWindows) ? pack.duckWindows : [];
                        return plan;
                    }
                }
            } catch (_) { /* fall through to the manual mapping below */ }

            const cues = plan.cues;
            const byType = (type) => cues.filter((c) => c.type === type);
            const baseMusicDuck = 0.18;

            const duckWindows = [];
            byType('reveal_start').forEach((c) => {
                const at = Math.max(0, Number(c.atMs || 0));
                duckWindows.push({ startMs: Math.max(0, at - 250), endMs: at + 1400, volume: baseMusicDuck });
            });
            byType('intro_start').forEach((c) => {
                const at = Math.max(0, Number(c.atMs || 0));
                duckWindows.push({ startMs: at, endMs: at + 700, volume: baseMusicDuck });
            });
            byType('outro_start').forEach((c) => {
                const at = Math.max(0, Number(c.atMs || 0));
                duckWindows.push({ startMs: at, endMs: at + 700, volume: baseMusicDuck });
            });

            const sfxEvents = [];
            byType('tick').forEach((c) => sfxEvents.push({ name: 'tick', atMs: Number(c.atMs || 0), gain: 0.55 }));
            byType('reveal_start').forEach((c) => sfxEvents.push({ name: 'reveal', atMs: Number(c.atMs || 0), gain: 1.0 }));
            byType('reveal_correct').forEach((c) => sfxEvents.push({ name: 'correct', atMs: Number(c.atMs || 0), gain: 1.0 }));

            const fxEvents = [];
            // @FIX 2026-07-31: Use OR logic (reveal_correct OR reveal_start) to match
            //                  vs-video-templates.getCuePoints — the previous AND logic
            //                  fired both, doubling particle bursts.
            const particleCues = byType('reveal_correct');
            const revealCues = particleCues.length ? particleCues : byType('reveal_start');
            revealCues.forEach((c) => fxEvents.push({ type: 'particles_burst', atMs: Number(c.atMs || 0), kind: 'sparkles' }));
            // @FIX 2026-07-31: Use template-specific glow intensity and shake magnitude
            //                  instead of hardcoded values, matching vs-video-templates
            //                  getCuePoints. Resolve template opts from MCQVS_TemplateManager.
            let glowIntensity = 0.75;
            let shakeMag = 10;
            try {
                const tm3 = (typeof MCQVS_TemplateManager !== 'undefined') ? MCQVS_TemplateManager : null;
                if (tm3 && typeof tm3.getTemplate === 'function') {
                    const t3 = tm3.getTemplate(plan.templateId) || tm3.getTemplate('trivia');
                    const o3 = t3 && t3.config && t3.config.opts;
                    if (o3) {
                        if (o3.timerGlowIntensity != null) glowIntensity = Number(o3.timerGlowIntensity);
                        if (o3.shakeMag != null) shakeMag = Number(o3.shakeMag);
                    }
                }
            } catch (_) { /* use defaults */ }
            byType('tick').forEach((c) => fxEvents.push({ type: 'timer_glow', atMs: Number(c.atMs || 0), durationMs: 240, intensity: glowIntensity, color: '#00f0ff' }));
            byType('reveal_start').forEach((c) => fxEvents.push({ type: 'screen_shake', atMs: Number(c.atMs || 0), durationMs: 360, magnitude: shakeMag }));

            plan.fxEvents = fxEvents;
            plan.sfxEvents = sfxEvents;
            plan.duckWindows = duckWindows;
            return plan;
        }

        async _mapLimit(items, limit, fn) {
            const list = Array.isArray(items) ? items : [];
            const out = new Array(list.length);
            let i = 0;
            const run = async () => {
                while (i < list.length) {
                    const idx = i++;
                    out[idx] = await fn(list[idx], idx);
                }
            };
            const workers = [];
            const n = Math.max(1, Math.min(limit || 1, list.length || 1));
            for (let k = 0; k < n; k++) workers.push(run());
            await Promise.all(workers);
            return out;
        }

        async _requestTtsAudioUrl(text, provider, voice) {
            const ajaxUrl = (this.config && (this.config.ajaxUrl || this.config.ajaxurl)) || window.ajaxurl;
            const nonce = (this.config && this.config.nonce) || (window.MCQVS_Config && window.MCQVS_Config.nonce) || '';
            if (!ajaxUrl) throw new Error('Missing AJAX URL');
            if (!nonce) throw new Error('Missing nonce');

            const vo = this.state.voiceover || {};
            const rate = Number.isFinite(Number(vo.rate)) ? Number(vo.rate) : 1.0;
            const pitch = Number.isFinite(Number(vo.pitch)) ? Number(vo.pitch) : 0;

            const key = `${provider}::${voice}::${rate}::${pitch}::${text}`;
            this._ttsUrlCache = this._ttsUrlCache || new Map();
            if (this._ttsUrlCache.has(key)) return this._ttsUrlCache.get(key);

            const body = new URLSearchParams();
            body.set('action', 'mcqvs_generate_tts');
            body.set('nonce', nonce);
            body.set('text', text);
            body.set('provider', provider);
            body.set('voice', voice);
            body.set('rate', String(rate));
            body.set('pitch', String(pitch));

            // @FIX 2026-07-14: 30s AbortController — TTS providers (Edge,
            //                 Google, ElevenLabs) can hang at the network layer
            //                 without aborting, which wedged prepareAudio() →
            //                 startExport() → render-runner run() indefinitely.
            const ttsAc = new AbortController();
            const ttsTimer = setTimeout(() => ttsAc.abort(), 30000);
            let res;
            try {
                res = await fetch(ajaxUrl, {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                    body: body.toString(),
                    signal: ttsAc.signal
                });
            } finally {
                clearTimeout(ttsTimer);
            }

            const json = await res.json().catch(() => null);
            if (!json || !json.success) {
                const msg = (json && json.data) ? String(json.data) : 'TTS failed';
                throw new Error(msg);
            }

            const url = json.data && json.data.audio_url ? String(json.data.audio_url) : '';
            if (!url) throw new Error('TTS returned no audio_url');

            this._ttsUrlCache.set(key, url);
            return url;
        }

    async _prepareVoiceoverAssets(offlineCtx, plan) {
        const vo = this.state.voiceover || {};
        const provider = String(vo.provider || '').trim() || 'edge';
        const voice = String(vo.voice || '').trim();
            if (!voice) return null;

            const cues = this._buildVoiceoverCues(plan);
            if (!cues.length) return null;

            // Limit concurrency to avoid rate-limit spikes
            const decoded = await this._mapLimit(cues, 2, async (cue) => {
                try {
                    const t = this._normalizeTtsText(cue.text);
                    if (!t) return null;
                    const audioUrl = await this._requestTtsAudioUrl(t, provider, voice);
                    const buf = await this._fetchDecode(offlineCtx, audioUrl);
                    if (!buf) return null;
                    const durMs = Math.max(0, (buf.duration || 0) * 1000);
                    return Object.assign({}, cue, { buffer: buf, durMs });
                } catch (e) {
                    if (Logger) Logger.warn('EXPORT_TTS_SEGMENT_FAIL', { error: e.message, kind: cue.kind });
                    return null;
                }
            });

            // @FIX 2026-07-24: Port server-renderer's Phase 2+3 adaptive timing.
            // The previous logic only delayed overlapping TTS (Math.max(scheduled, cursorEnd))
            // but never extended the scene durMs — so TTS bled past scene end into the next Qs.
            // Now we recompute each question scene's duration from ACTUAL TTS measurement,
            // then chain scenes sequentially with snapped frame boundaries. This guarantees:
            //   (a) q_read TTS + reveal TTS both fit inside their scene
            //   (b) no TTS overlaps the next question (next scene starts AFTER prev TTS ends)
            //   (c) video length adapts to real TTS (with "Question N", "A./B./C./D." spoken)
            const valid = decoded.filter(Boolean);
            if (!valid.length) return null;

            const fps = Number(this.state.fps || 30);
            const frameMs = 1000 / fps;
            const snap = (ms) => Math.max(0, Math.round(Number(ms || 0) / frameMs)) * frameMs;

            // ----- Phase 2: compute perScene required duration from actual TTS lengths -----
            // @FIX 2026-07-25 (parity with server-renderer.js): When TTS is enabled,
            //                  scene durMs = q_read TTS length + reveal phase only —
            //                  no separate "thinking" budget (reveal fires immediately
            //                  after TTS finishes). Pill countdown therefore hits 0
            //                  exactly when reveal begins, in sync with TTS playback.
            // @FIX 2026-08-11 (DRIFT FIX — align with node computeAdaptiveTiming):
            //                  - Format-aware caps: shorts 12.5s/question max (was 25s!),
            //                    min 5.2s; youtube keeps 8s/25s. The old 25s made browser
            //                    export scenes up to 2x longer than Content Planner renders.
            //                  - Hook scene extension: if hook TTS outgrows hookIntro, the
            //                    hook scene grows to fit (capped 4s) so hook audio never
            //                    spills into Q1 — mirrors server-renderer computeAdaptiveTiming.
            // @FIX 1.4.9.56 (TTS CORRECTNESS): same rules as server-renderer.js — a
            // question's scene is sized to the FULL measured TTS (read + gap + reveal).
            // No truncating cap: the old 12.5s/question cap cut long reads (options
            // spoken) mid-way, so the browser export skipped the 4th option and jumped
            // to the reveal / next question. The ceiling is now only a pathological
            // runaway guard (90s/question), never a truncator.
            const phaseReveal = Number((this.state.timing && this.state.timing.questionPhases && this.state.timing.questionPhases.reveal) || 3000);
            const isYoutube = String(this.state.videoFormat || 'shorts') === 'youtube';
            const minQuestionMs = isYoutube ? 8000 : 5200;
            const maxQuestionMs = isYoutube ? 120000 : 90000;
            const maxReadingMs  = isYoutube ? 110000 : 80000;
            const ttsBufferMs   = 300;

            const scenes = Array.isArray(plan && plan.scenes) ? plan.scenes : [];
            const perSceneDur = {};

            // Hook scene extension (mirrors server-renderer computeAdaptiveTiming hook pass).
            for (const scene of scenes) {
                if (!scene || scene.type !== 'hook' || !scene.id) continue;
                const hookCue = valid.find(t => t && t.sceneId === scene.id && t.kind === 'hook');
                const hookDur = hookCue ? Number(hookCue.durMs || 0) : 0;
                if (Number.isFinite(hookDur) && hookDur > 0) {
                    const hookBase = Number((this.state.timing && this.state.timing.hookIntro) || 1200);
                    const hookNeed = Math.min(8000, Math.max(hookBase, hookDur + 200));
                    if (hookNeed > Number(scene.durMs || 0)) perSceneDur[scene.id] = hookNeed;
                }
            }

            for (const scene of scenes) {
                if (!scene || scene.type !== 'question' || !scene.id) continue;
                const sceneTts = valid.filter(t => t && t.sceneId === scene.id);
                if (!sceneTts.length) continue;

                const qReadCue = sceneTts.find(t => t.kind === 'q_read');
                if (!qReadCue) continue;
                // @FIX 2026-07-25 (parity with server-renderer.js): Skip scenes
                //                 whose q_read TTS failed (durMs 0/NaN) — keeps
                //                 base durMs from render-plan.js, prevents
                //                 spillover, no division-by-NaN downstream.
                const qReadRaw = Number(qReadCue.durMs);
                if (!Number.isFinite(qReadRaw) || qReadRaw <= 0) continue;

                const qReadStartOffsetMs = 80;
                // @FIX 1.4.9.56: use the FULL measured read — never truncate it.
                const qReadDurMs = Math.max(0, Math.min(qReadRaw, maxReadingMs));

                const revealCue = sceneTts.find(t => t.kind === 'reveal');
                const revealTtsDur = revealCue ? (Number(revealCue.durMs || 0)) : 0;
                const effectiveReveal = Math.max(phaseReveal, revealTtsDur + 200);

                const requiredMs = Math.min(
                    maxQuestionMs,
                    Math.max(
                        qReadStartOffsetMs + qReadDurMs + ttsBufferMs + effectiveReveal,
                        minQuestionMs
                    )
                );

                const currentDurMs = Number(scene.durMs || 0);
                if (requiredMs > currentDurMs) {
                    perSceneDur[scene.id] = requiredMs;
                }
            }

            // ----- Phase 3: rebuild plan scene startMs/durMs/endMs sequentially -----
            // Replicate server-renderer rebuildPlanWithAdaptiveTiming exactly: chain
            // scenes so a delayed next scene absorbs any excess from the previous one,
            // rather than both scenes overlapping the same timeline window.
            // @FIX 2026-07-30: Always rebuild when TTS data exists. _revealStartRel is
            //                  anchored to reading TTS end + 300ms (not durMs - revealMs).
            //                  Answer TTS fires at the same moment (render-node.js Phase 3).
            if (Object.keys(perSceneDur).length || valid.length > 0) {
                let cursor = 0;
                const newScenes = [];
                for (const scene of scenes) {
                    const startMs = snap(cursor);
                    const durMs = (perSceneDur[scene.id] != null)
                        ? snap(perSceneDur[scene.id])
                        : Number(scene.durMs || 0);
                    const endMs = startMs + durMs;

                    let ttsReadMs = null;
                    if (scene.type === 'question') {
                        const qRead = valid.find(t => t.sceneId === scene.id && t.kind === 'q_read');
                        if (qRead) ttsReadMs = Math.round(Number(qRead.durMs || 0));
                    }
                    const newTiming = scene.timing ? Object.assign({}, scene.timing, { questionTotal: durMs }) : null;
                    if (newTiming && ttsReadMs !== null) {
                        newTiming._ttsReadMs = ttsReadMs;
                        // @FIX 2026-07-25: See server-renderer.js — use 80ms TTS start offset,
                        //                 NOT introMs (visual intro phase is unrelated to TTS).
                        newTiming._readingEndRel = Math.round(80 + ttsReadMs);
                        // @FIX 2026-07-25: Recompute _revealStartRel from the NEW durMs so
                        //                 vs-template-manager _drawTimerPill (line 944-946)
                        //                 does not use the stale pre-adaptive reveal moment.
                        const revealMs = Number((scene.timing && scene.timing.questionPhases && scene.timing.questionPhases.reveal) || 3000);
                        newTiming._oldRevealStartRel = scene.timing ? scene.timing._revealStartRel : undefined;
                        newTiming._oldSceneStartMs   = scene.startMs;
                        // @FIX 2026-07-30: Anchor to reading TTS end + 300ms gap, not
                        //                   durMs - revealMs. Parity with server-renderer.js.
                        newTiming._revealStartRel    = Math.max(0, 80 + ttsReadMs + 300);
                    }

                    newScenes.push(Object.assign({}, scene, {
                        startMs, durMs, endMs, timing: newTiming
                    }));
                    cursor = endMs;
                }
                plan.scenes = newScenes;
                plan.totalMs = snap(
                    newScenes.length ? newScenes[newScenes.length - 1].endMs : 0
                );
                // Reflect on controller state to keep preview/total UI in sync.
                try {
                    this.state.totalDurationMs = plan.totalMs;
                } catch (_) { }

                // @FIX 2026-07-25 (parity with server-renderer.js): Realign plan.cues
                //                 to the rebuilt scene boundaries so countdown ticks,
                //                 reveal_start, reveal_correct, and the correct-answer
                //                 reveal animation fire at the NEW reveal moment — in
                //                 sync with TTS playback and the visual pill countdown.
                if (Array.isArray(plan.cues)) {
                    const sceneByIdRebuilt = {};
                    for (const s of newScenes) sceneByIdRebuilt[s.id] = s;
                    const rebuiltCues = [];
                    for (const cue of plan.cues) {
                        const sc = cue.sceneId ? sceneByIdRebuilt[cue.sceneId] : null;
                        if (sc) {
                            // @FIX 2026-07-31: Remap intro/outro boundary cues to REBUILT
                            //                 scene times so intro/outro flash FX and duck
                            //                 windows follow scene shifts (extending a
                            //                 question pushes the outro right).
                            if (cue.type === 'intro_start') { rebuiltCues.push(Object.assign({}, cue, { atMs: sc.startMs })); continue; }
                            if (cue.type === 'intro_end') { rebuiltCues.push(Object.assign({}, cue, { atMs: sc.endMs })); continue; }
                            if (cue.type === 'outro_start') { rebuiltCues.push(Object.assign({}, cue, { atMs: sc.startMs })); continue; }
                        }
                        if (!sc || sc.type !== 'question') { rebuiltCues.push(cue); continue; }
                        const revealMs = Number((sc.timing && sc.timing.questionPhases && sc.timing.questionPhases.reveal) || 3000);
                        // @FIX 2026-07-30: Use _revealStartRel (reading-anchored). Parity
                        //                   with server-renderer.js.
                        const revealStartRel = (sc.timing && sc.timing._revealStartRel !== undefined)
                            ? sc.timing._revealStartRel
                            : Math.max(0, sc.durMs - revealMs);
                        const visualRevealStart = Math.max(0, (sc.startMs || 0) + revealStartRel);
                        if (cue.type === 'reveal_start' || cue.type === 'reveal_correct') {
                            rebuiltCues.push(Object.assign({}, cue, { atMs: visualRevealStart }));
                        } else if (cue.type === 'countdown_start') {
                            // @FIX 2026-07-28: Tick window begins 5s before visual reveal.
                            rebuiltCues.push(Object.assign({}, cue, { atMs: Math.max(sc.startMs, visualRevealStart - 5000) }));
                        } else if (cue.type === 'tick') {
                            const oldRevealStartRel = Number(sc.timing && sc.timing._oldRevealStartRel || 0);
                            const oldSceneStart     = Number(sc.timing && sc.timing._oldSceneStartMs || 0);
                            const oldRevealAbs      = oldSceneStart + oldRevealStartRel;
                            const oldCountdownStart = Math.max(oldSceneStart, oldRevealAbs - 5000);
                            const tickIdx = Math.round((Number(cue.atMs || 0) - oldCountdownStart) / 1000);
                            if (tickIdx >= 0 && tickIdx < 5) {
                                // @FIX 2026-07-28: Ticks anchored to visual reveal start.
                                const newCountdownStart = Math.max(sc.startMs, visualRevealStart - 5000);
                                rebuiltCues.push(Object.assign({}, cue, { atMs: newCountdownStart + tickIdx * 1000 }));
                            }
                        } else {
                            rebuiltCues.push(cue);
                        }
                    }
                    plan.cues = rebuiltCues;

                    // @FIX 2026-07-25: Re-derive plan.fxEvents / plan.sfxEvents /
                    //                 plan.duckWindows from the rebuilt cues so
                    //                 every count-down tick, reveal SFX, sparkle
                    //                 burst, and music duck window fires at the
                    //                 NEW reveal moment (in sync with TTS playback
                    //                 and the visual pill countdown).
                    this._realignCueDerivedEvents(plan);

                    // @FIX 2026-07-25: Strip in-flight _oldRevealStartRel /
                    //                 _oldSceneStartMs from scene.timing so the
                    //                 scratch fields don't leak into plan cache
                    //                 (state.renderPlan) or persistence paths.
                    for (const s of newScenes) {
                        if (s && s.timing && typeof s.timing === 'object') {
                            delete s.timing._oldRevealStartRel;
                            delete s.timing._oldSceneStartMs;
                        }
                    }
                }
            }

            // ----- Place TTS segments sequentially (no overlap, no spillover) -----
            const seq = valid
                .slice()
                .sort((a, b) => (Number(a.atMs || 0) - Number(b.atMs || 0)));
            const segments = [];
            const duckWindows = [];
            // Use the rebuilt scene startMs for each cue's sceneId so a delayed scene
            // pushes its own TTS cues to the new position instead of the original atMs.
            const sceneById = {};
            if (plan && Array.isArray(plan.scenes)) {
                for (const s of plan.scenes) sceneById[s.id] = s;
            }
            let cursorEndSec = 0;
            for (const d of seq) {
                const parent = d.sceneId ? sceneById[d.sceneId] : null;
                const sceneStartSec = parent ? (Number(parent.startMs || 0) / 1000) : 0;
                const relAtSec = parent
                    ? Math.max(0, (Number(d.atMs || 0) - Number(parent.startMs || 0)) / 1000)
                    : (Number(d.atMs || 0) / 1000);
                const scheduledAtSec = sceneStartSec + relAtSec;
                const durSec = Number(d.durMs || 0) / 1000;
                const actualStartSec = Math.max(scheduledAtSec, cursorEndSec);
                segments.push({ atSec: actualStartSec, buffer: d.buffer });
                duckWindows.push({
                    startMs: Math.max(0, actualStartSec * 1000 - 50),
                    endMs: Math.max(0, actualStartSec * 1000 + durSec * 1000 + 80),
                    volume: 0.14
                });
                cursorEndSec = actualStartSec + durSec;
            }

            return { segments, duckWindows };
        }

        _mixVoiceoverSegments(offlineCtx, segments) {
            const list = Array.isArray(segments) ? segments : [];
            if (!list.length) return;

            for (const seg of list) {
                if (!seg || !seg.buffer) continue;
                const at = Math.max(0, Number(seg.atSec || 0));
                const src = offlineCtx.createBufferSource();
                src.buffer = seg.buffer;
                const g = offlineCtx.createGain();
                g.gain.setValueAtTime(1.0, at);
                src.connect(g).connect(offlineCtx.destination);
                src.start(at);
            }
        }

        /**
         * Start worker processing
         */
        async startWorkerProcessing(jobs, audioData) {
            // @FIX 2026-07-14: Wrap the worker Promise in a 600s race. The
            //                 worker has onerror (added 2026-05-02) which
            //                 catches silent crashes, but a WebCodecs
            //                 `videoEncoder.flush()` or `audioEncoder.flush()`
            //                 hang (known Chrome issue under GPU memory
            //                 pressure) never triggers onerror — the worker
            //                 sits in an await that never resolves. Without
            //                 this race, startExport() would never settle and
            //                 render-runner run() would block until render.js's
            //                 900s watchdog force-exits with exit=4.
            return Promise.race([
                this._startWorkerProcessingInner(jobs, audioData),
                new Promise((_, reject) =>
                    setTimeout(() => reject(new Error('startWorkerProcessing timed out after 600s (worker flush hang?)')),
                        600000)
                )
            ]);
        }

        async _startWorkerProcessingInner(jobs, audioData) {
            return new Promise((resolve, reject) => {
                // @NEW 2026-02-02: Store progress listener for cleanup
                const progressListener = (e) => {
                    const percent = Math.round((e.detail.frame / e.detail.total) * 100);
                    if (Logger) {
                        Logger.debug('EXPORT_PROGRESS', { percent });
                    }
                };

                document.addEventListener('mcqvs:export:progress', progressListener);

                // Cleanup helper
                const cleanup = () => {
                    document.removeEventListener('mcqvs:export:progress', progressListener);
                };

                // Setup progress handler
                this.worker.onmessage = (e) => {
                    // @MODIFIED 2026-02-06: Robust message handling (support both flat and nested payloads)
                    const type = e.data.type;
                    const data = e.data.data !== undefined ? e.data.data : e.data;

                    switch (type) {
                        case 'PROGRESS':
                            this.handleProgress(data);
                            break;

                        case 'JOB_COMPLETE':
                            this.handleJobComplete(data);
                            cleanup(); // @MODIFIED 2026-02-02: Remove listener on success
                            resolve();
                            break;

		case 'ERROR':
				if (Logger) {
					Logger.error('EXPORT_WORKER_ERROR', { error: data.error });
				}
				cleanup(); // @MODIFIED 2026-02-02: Remove listener on error
				reject(new Error(data.error));
				break;
			}
		};

		// @FIX 2026-05-02: Add onerror handler — without this, worker crashes that don't post an ERROR
		// message (e.g. unhandled exceptions in onmessage itself) cause the Promise to hang forever,
		// resulting in the export popup disappearing with no video downloaded.
		this.worker.onerror = (error) => {
			if (Logger) {
				Logger.error('EXPORT_WORKER_UNHANDLED_ERROR', { error: error && error.message ? error.message : String(error) });
			}
			cleanup();
			reject(new Error('Worker unhandled error: ' + (error && error.message ? error.message : String(error))));
		};

		// Send batch data
                const transferables = [];
                if (audioData) {
                    transferables.push(audioData.left.buffer, audioData.right.buffer);
                }

                // Ensure renderPlan exists [PATCH 2026-02-03]
                // Use strict ensuring (fails fast if invalid)
                console.log('[Export] Validation OK. Posting STARTBATCH to worker.');
                const renderPlan = this.ensureRenderPlan(jobs.map(j => j.index));

                this.worker.postMessage({
                    type: 'STARTBATCH', // Compatible with legacy & modular workers (via patch)
                    data: {
                        jobs: jobs,
                        audioData: audioData,
                        renderPlan: renderPlan,
                        // @MODIFIED 2026-02-07: Disable debug logging for performance (30mins -> 2mins)
                        debugMode: false
                    }
                }, transferables);
            });
        }

        /**
         * Handle progress updates
         * @MODIFIED 2026-02-02: Dispatch event only (listener cleanup handled by startWorkerProcessing)
         */
        handleProgress(data) {
            // @MODIFIED 2026-02-08: Fix NaN% by supporting worker's 'totalFrames' and handling 0
            const total = (typeof data.total === 'number') ? data.total : (data.totalFrames || 0);
            const current = (typeof data.frame === 'number') ? data.frame : 0;
            const percent = (total > 0) ? Math.round((current / total) * 100) : 0;

            // Update UI via event
            // @MODIFIED 2026-02-23: Use computed total (handles worker's totalFrames field) and current
            const event = new CustomEvent('mcqvs:export:progress', {
                detail: { percent, frame: current, total: total }
            });
            document.dispatchEvent(event);
        }

    /**
     * Handle job complete
     * @MODIFIED 2026-04-22: saveMode-aware routing — local downloads, r2/r2_buffer uploads to server
     */
    async handleJobComplete(data) {
        const blob = new Blob([data.video], { type: 'video/mp4' });
        const saveMode = this.state.saveMode || 'local';

        try {
            if (saveMode === 'local') {
                await this.downloadVideo(blob, data.index, this.exportPart);
                const toastApi = window.MCQVS_ToastManager || window.MCQVS_Toast || null;
                if (toastApi && toastApi.success) {
                    toastApi.success('Download started!', 3000);
                }
            } else {
                await this.uploadBlobToServer(blob);
            }

            try {
                const cfg = window.MCQVS_Config || {};
                if (cfg.ajaxUrl && cfg.nonce) {
                    const fd = new FormData();
                    fd.append('action', 'mcqvs_increment_video_count');
                    fd.append('nonce', cfg.nonce);
                    fetch(cfg.ajaxUrl, { method: 'POST', body: fd }).catch(() => { });
                }
            } catch (_) { /* non-critical */ }

        } catch (err) {
            if (Logger) Logger.error('EXPORT_SAVE_FAIL', { error: err.message });
            console.error('[MCQVS] Export completion failed:', err);
        }
    }

    /**
     * Upload video blob to server for R2/Buffer pipeline
     * @NEW 2026-04-22
     */
    async uploadBlobToServer(blob) {
        const jobId = this.state.activeJobId || '';
        const projectId = this.state.activeProjectId || '';
        const saveMode = this.state.saveMode || 'local';

        const formData = new FormData();
        formData.append('action', 'mcqvs_update_video_url');
        formData.append('nonce', this.config.nonce || '');
        formData.append('job_id', jobId);
        formData.append('project_id', projectId);
        formData.append('save_mode', saveMode);
        formData.append('video_blob', blob, 'video_' + (jobId || Date.now()) + '.mp4');

        const toastApi = window.MCQVS_ToastManager || window.MCQVS_Toast || null;
        if (toastApi && toastApi.progress) {
            this._uploadToast = toastApi.progress('Uploading to Cloud...', 0);
        }

        try {
            // @FIX 2026-07-14: 120s AbortController — without this, a stalled
            //                 upload after the worker finished encoding left
            //                 startExport() wedged forever on this fetch, so
            //                 __MCQVSRenderRunnerReady was never set and the
            //                 job row stayed `rendering` while the encoded
            //                 video sat in memory. 120s is loose enough for a
            //                 30-40MB MP4 on a slow residential uplink.
            const uploadAc = new AbortController();
            const uploadTimer = setTimeout(() => uploadAc.abort(), 120000);
            let response;
            try {
                response = await fetch(this.config.ajaxurl || this.config.ajaxUrl || window.ajaxurl || '', {
                    method: 'POST',
                    body: formData,
                    signal: uploadAc.signal,
                });
            } finally {
                clearTimeout(uploadTimer);
            }

            const result = await response.json();

            if (this._uploadToast && typeof this._uploadToast.updateProgress === 'function') {
                this._uploadToast.updateProgress(100, 'Upload complete');
                setTimeout(() => {
                    if (this._uploadToast && typeof this._uploadToast.dismiss === 'function') {
                        this._uploadToast.dismiss();
                        this._uploadToast = null;
                    }
                }, 1500);
            }

            if (!result.success) {
                console.warn('[MCQVS] Server upload failed, falling back to local download:', result.data);
                if (toastApi && toastApi.warning) {
                    toastApi.warning('Server upload failed. Downloading locally.', 5000);
                }
                await this._markJobUploadFailed(jobId, 'Server upload failed: ' + (result.data || 'Unknown'));
                await this.downloadVideo(blob);
                return;
            }

            if (Logger) Logger.info('UPLOAD_TO_SERVER_SUCCESS', { save_mode: saveMode, result });

            if (toastApi && toastApi.success) {
                const method = result.data?.method || saveMode;
                const bufferInfo = result.data?.buffer ? ' + Buffer posted' : '';
                toastApi.success('Video uploaded to ' + method.toUpperCase() + bufferInfo + '!', 5000);
            }
        } catch (e) {
            if (this._uploadToast && typeof this._uploadToast.dismiss === 'function') {
                this._uploadToast.dismiss();
                this._uploadToast = null;
            }
            console.warn('[MCQVS] Server upload error, falling back to local download:', e);
            if (toastApi && toastApi.warning) {
                toastApi.warning('Upload error. Downloading locally.', 5000);
            }
            await this._markJobUploadFailed(jobId, 'Upload error: ' + (e.message || String(e)));
            await this.downloadVideo(blob);
        }
    }

    async _markJobUploadFailed(jobId, errorMsg) {
        if (!jobId) return;
        try {
            const fd = new FormData();
            fd.append('action', 'mcqvs_update_job_status');
            fd.append('nonce', this.config.nonce || '');
            fd.append('job_id', jobId);
            fd.append('status', 'failed');
            fd.append('error', errorMsg || 'Upload failed');
            await fetch(this.config.ajaxurl || this.config.ajaxUrl || window.ajaxurl || '', { method: 'POST', body: fd });
        } catch (_) {}
    }

        /**
         * Trigger video download
         * @NEW 2026-02-18: Restored from backup/legacy flow to fix missing method bug
         */
        async downloadVideo(blob, index, part = null) {
            // @MODIFIED 2026-02-08: Use [Quiz Name]-[Brand Name] format
            const toSlug = (str) => String(str || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
            const qSlug = toSlug(this.state.quizName);
            const bSlug = toSlug(this.state.brandName);

            let fileName = '';
            if (qSlug && bSlug) {
                fileName = `${qSlug}-${bSlug}`;
            } else if (qSlug) {
                fileName = `${qSlug}`;
            } else {
                fileName = `quiz-video-${Date.now()}`;
            }

            if (part != null) {
                fileName += `-part-${part}`;
            }

            fileName += '.mp4';

            const toastApi = window.MCQVS_ToastManager || window.MCQVS_Toast || null;

            try {
                // 1. Try modern File System Access API if available
                if (window.showSaveFilePicker) {
                    try {
                        const handle = await window.showSaveFilePicker({
                            suggestedName: fileName,
                            types: [{ description: 'MP4 Video', accept: { 'video/mp4': ['.mp4'] } }]
                        });

                        const writable = await handle.createWritable();
                        const stream = blob.stream ? blob.stream() : new Response(blob).body;
                        const reader = stream.getReader();

                        const total = blob.size || 1;
                        let written = 0;

                        while (true) {
                            const { done, value } = await reader.read();
                            if (done) break;
                            await writable.write(value);
                            written += (value.byteLength || value.length || 0);

                            // Optional: Update global progress if we have a way to find the toast
                            // For now, we rely on the main success notification.
                        }

                        await writable.close();
                        if (Logger) Logger.info('EXPORT_DOWNLOAD_STREAM', { size: blob.size });
                        return;

                    } catch (e) {
                        if (e.name === 'AbortError') return;
                        console.warn('[MCQVS] FilePicker failed, falling back to auto-download:', e);
                    }
                }

                // 2. Fallback: Automatic Download via <a> tag
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.style.display = 'none';
                a.href = url;
                a.download = fileName;
                document.body.appendChild(a);
                a.click();

                // Cleanup
                setTimeout(() => {
                    document.body.removeChild(a);
                    URL.revokeObjectURL(url);
                }, 60000);

                if (Logger) Logger.info('EXPORT_DOWNLOAD_AUTO', { size: blob.size });

            } catch (err) {
                // 3. Final Fallback: Manual Save Button in Toast
                if (toastApi && toastApi.show) {
                    const url = URL.createObjectURL(blob);
                    toastApi.show({
                        title: 'Download Video',
                        message: `<button class="button button-primary" onclick="const a=document.createElement('a');a.href='${url}';a.download='${fileName}';document.body.appendChild(a);a.click();document.body.removeChild(a);this.closest('.mcqvs-toast').remove();">💾 Click to Save</button>`,
                        type: 'success',
                        duration: 0
                    });
                }
                throw err;
            }
        }


        /**
         * Cancel export
         */
        cancel() {
            if (this.abortController) {
                this.abortController.abort();
            }

            if (this.worker) {
                // @MODIFIED 2026-02-09: Force immediate termination and signal
                this.worker.postMessage({ type: 'CANCEL' });
                // We don't terminate immediately if we want the worker to clean up its own muxer,
                // but for "emergency stop" we might need to. 
                // However, runConsolidatedExport checks stopSignal every frame.
                // We'll give it a tiny window then terminate.
                setTimeout(() => {
                    if (this.worker) this.cleanup();
                }, 100);
            }

            if (Logger) {
                Logger.info('EXPORT_CANCEL');
            }
        }

        /**
         * Pause export
         * @NEW 2026-02-09
         */
        pause() {
            if (this.worker && !this.isPaused) {
                this.isPaused = true;
                this.worker.postMessage({ type: 'PAUSE' });
                if (Logger) Logger.info('EXPORT_PAUSE');
            }
        }

        /**
         * Resume export
         * @NEW 2026-02-09
         */
        resume() {
            if (this.worker && this.isPaused) {
                this.isPaused = false;
                this.worker.postMessage({ type: 'RESUME' });
                if (Logger) Logger.info('EXPORT_RESUME');
            }
        }

        /**
         * Cleanup resources
         */
        cleanup() {
            if (this.worker) {
                this.worker.terminate();
                this.worker = null;
            }

            try { this.restoreVoiceoverProvider(); } catch (_) {}

            this.abortController = null;

            if (Logger) {
                Logger.info('EXPORT_CLEANUP');
            }
        }

        /**
         * Destroy manager
         */
        destroy() {
            this.cleanup();
        }
    }

    // Export (Controller expects MCQVSExportManager) [PATCH 2026-02-03]
    window.MCQVSExportManager = ExportManager;

    // Back-compat alias
    window.MCQVS_ExportManager = ExportManager;

})(window);
