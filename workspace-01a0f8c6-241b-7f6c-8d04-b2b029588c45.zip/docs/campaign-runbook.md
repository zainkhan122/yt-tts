# Runbook: 3 collection drafts/day with WordPress Automatic v6.3

---

# Blog sources — sites that publish collections AS POSTS (StyloStreet-style)

Deep-verified Aug 2026. The StyloStreet genre ("one brand collection/sale per post, dress-by-dress with Rs prices") has almost no direct competitors — everything else is either a store or a lifestyle magazine.

## ✅ Usable in WPA

### 1. stylostreet.com — the reference site (WordPress, RSS DISABLED)
Verified: all feed URLs (`/feed/`, `/?feed=rss2`, atom) return the homepage — feeds are switched off. But **wp-json is open** and category pages are plain HTML.
Categories (live counts): `sale` (447 posts), `winter-collections` (214), `summer-collection` (200), `whats-on-sale` (124), `eid-dresses` (102), `shoes` (77), `dresses` (63), `bridal` (74).

**WPA setup — Multi-page scraper campaign:**
| Setting | Value |
|---|---|
| Items list page URL | `https://www.stylostreet.com/category/summer-collection/` (or `/category/sale/`) |
| Links extraction | REGEX → `https://www\.stylostreet\.com/[a-z0-9-]{20,}/?` |
| Pagination | Fixed → `https://www.stylostreet.com/category/summer-collection/page/[page_number]/`, base 1, increment 1 |
| Caching | enabled |
| Item title | Auto detect |
| Item content | **Auto detect full content** (their posts are already image+price catalogs — nothing to extract selectively) |
| Images | featured + gallery (downloaded) |
| Skip words | `hairstyles, celebrities` (their non-collection categories) |
| Schedule | e.g. Every 24 Hours → +1 post/day |

### 2. nishatlinen.com — Nishat Linen brand blog, WORKING feed
`https://nishatlinen.com/blogs/news.atom` — verified 23 entries, real collection/sale posts ("Celebrate Eid ul Adha with Nishat's Collection", "Eid Sale Flat 25% Off…"). Same Feeds-campaign treatment as Gul Ahmed.

### 3. gulahmedshop.com — brand blog with a WORKING feed
`https://www.gulahmedshop.com/blogs/news.atom` — verified 30 entries ("Gul Ahmed Azadi Sale 2026 – Up to 50% off Everything", "Lawn Collection 2026: Complete Guide"). Gul Ahmed's own blog; collection/sale announcements + season guides.
**WPA:** plain **Feeds campaign** → feed URL = the .atom link → "Auto detect full content" → images/gallery ticks. Works with zero scraping.

### 4. salesiren.pk/blog — sale-tracker editorial (WordPress, feed WAF-blocked)
Posts like "Khaadi Sale: How to Get 70% Off Like a Pro". `/feed/` returns "Not Acceptable" (WAF) → use the same **Multi-page campaign pattern as StyloStreet** on `https://salesiren.pk/blog/`. Secondary source.

### 5. Adjacent brand blogs with working .atom feeds (guides, not catalogs)
- `https://www.stringnthread.com/blogs/news.atom` (styling guides for Pakistani outfits)
- `https://rangreza.net/blogs/news.atom` (brand/designer guides)
- `https://beechtree.pk/blogs/news.atom` — only 2 posts, thin (optional)
- ❌ no blogs: sapphireonline.pk, limelight.pk, alkaramstudio.com, crossstitch.pk, laam.pk, sanaullastore.com (all verified 0 entries)
Use as **Feeds campaigns** if you want mixed editorial content.

## ❌ Checked and dead/blocked (don't waste time)
| Site | Status |
|---|---|
| style.pk | Cloudflare "Just a moment…" challenge — WPA's curl can't pass |
| dekho.com.pk | WordPress but 403 WAF on feed AND wp-json |
| siddysays.com / karachistas.com | JS-gated lifestyle magazines, not collection catalogs |
| fashioncentral.pk | Legacy portal, WP but feed broken (301) |
| houseoffaiza.com | domain parked |
| affordable.pk/blog | general lifestyle blog (mobile packages etc.), not fashion collections |
| brandstore.pk/blog, goto.com.pk/blog | empty / unreachable |

**Strategic note:** the gap StyloStreet occupies is basically uncontested — your own WPA pipeline (Sanaullah + TFS campaigns) is already generating the same product. Use StyloStreet as your main *rewriting inspiration + source*, not as a competitor to beat.

## Before both campaigns (one-time, 2 min)
1. **Settings → WordPress Automatic**: nothing needed (no Apify for these two).
2. Make sure WP-Cron fires: if the site has low traffic, add a real cron hitting `wp-cron.php` every 5 min (otherwise schedules drift).
3. Posts → create a category **Collections** (used by both campaigns).

---

## CAMPAIGN 1 — Sanaulla (Multi-page → 2 posts/day) — v3: BRAND DIRECTORY

⚠️ v1/v2 lesson: the `/collections` grid is polluted with placeholder junk (`000`, `10607`, discount ranges, "1-piece" type pages) — that's why you got a meaningless mega-post with no title. Use the curated A-Z **brand directory** instead: `sanaullastore.com/pages/brands` — ONE page, ~400 real designer collections (Maria B, Mushq, Sana Safinaz…; verified: anchors carry the brand name as link text; each brand page has a proper `<h1>` + dress grid).

**WP Automatic → Add New Campaign**

| Screen section | Setting | Value |
|---|---|---|
| Campaign Type | Type | **Multi-page scraper** |
| Basic | Title | `Sanaulla – Brands` |
| Basic | Post Type / Post Status | Post / **Draft** |
| Basic | Post Category | Collections |
| Scraper box | **Items list page URL** | `https://sanaullastore.com/pages/brands` |
| Scraper box | Links extraction method | **CSS selector** → type **class** → value **`bp-tile`** → Matches **all** → Wrap **outer** ⚠️ v3.1 fix: `mobile-cat-sublink` also matches the mega-menu drawer (475 links incl. junk). The visible A-Z directory is `section.bp-brands-section` → 243 anchors, ALL class `bp-tile`, 100% pure brand collections, zero junk (verified) |
| Scraper box | Pagination | **Auto detect** (whole directory is ONE page — 441 links) |
| Scraper box | **Caching** | **enabled** |
| Item settings | Single item title extraction method | **CSS selector** → type **xPath** → `//h1` → single → inner |
| Item settings | Link to a single item extraction method | **CSS selector** → Rule 1: type **xPath** → `(//div[contains(@class,'grid-product__content')])[position()<=15]` → Matches **all** → inner ⚠️ parentheses REQUIRED — without them the cap silently matches every card |
| Filters | Skip posts containing | ⚠️ use ANCHOR-TEXT words (the filter checks the item's title/description = the link text, NOT the URL — slug-style words like `wedding-dresses` never match): `Under, Co-Ord, Ready to Wear, Casual, Summers, Winters, Eid Collection, Wedding Dresses, Kurti, Abaya, Saree, Kaftan, Maxi, Shawl, Shoes, Heels, Bags, Men, Kids, New Arrivals` |
| Filters / cleanup | Strip content using CSS → class | `grid-product__secondary-image` + `visually-hidden` |
| Filters / cleanup | Strip content using REGEX — add these lines (order matters) | `<script.*?</script>` · `<template.*?</template>` · `<span class="visually-hidden">.*?</span>` · `<span class="grid-product__price--savings">.*?</span>` · `<div class="grid-product__tag grid-product__tag--sale">.*?</div>` · `<div[^>]*data-yango[^>]*>.*?</div>` · `<div style="margin-top: 5px; display: flex; justify-content: center;"[^>]*>\s*</div>` · `<button class="quick-product__btn.*?</button>` · `<link[^>]*>` · `<image-element[^>]*>\|</image-element>` |
| Filters / cleanup | ✅ Strip-tags option (allowed-tags input) → set allowed tags | `<img><a><p><br><h3><strong>` — flattens every remaining div/span/wrapper; code order guarantees regex runs first, so what's left per dress is a clean `img + title + Rs. price` line |
| Images | ✅ featured · ✅ width ≥400 · ✅ **Gallery (downloaded)** · ❌ UNTICK "Try to generate a name for the image from the post title" | the generated filename breaks featured-image matching ("No images found to set as featured" despite images cached) |
| Filters / cleanup | Strip content using REGEX — add these 4 lines | `<script.*?</script>` · `<template.*?</template>` · `<link[^>]*>` · `<button class="quick-product__btn.*?</button>` (removes Sanaulla's pay-widget/quick-view junk from each card) |
| Time | Run frequency | **Every 12 Hours** |

**⚠️ STRONGLY RECOMMENDED: build this as a NEW campaign** ("Sanaulla – Brands") instead of editing 30165 — the old campaign carries a stale link-cache AND a duplicate-cache full of junk URLs (proof: its feed file `73c6f309…xml` = md5 of the OLD `/collections` URL, and it keeps serving mega-menu junk like `1-million-cotton-lawn-MENS-2025`). Deactivate/delete 30165, create the new one fresh, verify the first Run Now log shows `Loading: https://sanaullastore.com/pages/brands` → `Approved found links: ~400` → post URL = `/collections/{brand}` (e.g. `maria-b`, `mushq`). Delete all junk drafts from the old campaign.

**Notes:** each Sanaulla card holds 2 photos (cover + product shot) — for exactly 1 image per dress use `[position()<=8]` (16 imgs). 243 brands ÷ 2/day ≈ 4 months of runway.

### ⚠️ The dedupe limitation — and how to catch NEW collections (v3.2)

The Multi campaign posts each brand link **exactly once, forever** (duplicate cache is per-URL). `/collections/mushq` never changes URL — when Mushq launches a new seasonal line, the dresses are *added to the same page*, so the Multi campaign stays silent. It only fires for **new brands** that appear in the directory later.

**The fix — add "watcher" campaigns for hot brands (Single-page scraper):**

| Setting | Value |
|---|---|
| Campaign Type | **Single-page scraper** (one campaign per brand you actively cover) |
| Source URL | `https://sanaullastore.com/collections/mushq` |
| Title | xPath `//h1` |
| Content | xPath `(//div[contains(@class,'grid-product__content')])[position()<=15]` → all → inner |
| **When campaign runs again** | **Create new post when content changes** (plugin md5-hashes title+content; new dresses ⇒ new hash ⇒ NEW draft; unchanged ⇒ silent) |
| Schedule | Every 3–7 Days (churn control) |
| Images/strip | same ticks + regex lines as the Multi campaign |

How it plays together:
- **Multi campaign** = the backfill: every brand gets one post ever (your content base).
- **Single "watcher" campaigns** (10–20 favorite brands) = the news radar: a fresh draft whenever that brand's grid changes (new line launched).
- Caveat: the hash also changes on price/stock/order churn → occasional "new" drafts that aren't a real launch — that's the queue you curate anyway (you rewrite/delete drafts before publishing). Weekly runs keep noise low.
- Optional extra radar: one more Single campaign on `/collections/new-arrival` with **update** mode = a living "New Arrivals" draft that refreshes in place, showing which brands just dropped what.
- For true per-line tracking ("Astoria by Mushq MQ26UAL" as its own post), WPA has no selector — that's the custom-plugin territory (it stores product IDs and appends "🆕 N new designs" to the same brand draft).

### v4: ONE LINE PER POST (Nirvana ≠ Secret Garden) — plugin v2 territory

Verified: every Sanaulla line has its own page via Shopify tag URLs — `/collections/mushq/MU26UNR` = exactly the 10 Nirvana dresses, `/collections/mushq/MU26USG` = the 6 Secret Garden dresses. BUT nothing on the site links those URLs → **WPA's Multi engine (which only discovers linked items) can never find them — no settings change fixes this.** Line codes live in product tags/titles, which only a data feed exposes.

**Solution — `collection-post-generator.php` v2 (in workspace, upload to mu-plugins):**
- Reads `/collections/{brand}/products.json`, groups products by line code (tag regex `[A-Z]{1,4}\d{2}[A-Z]{1,5}`, title fallback), creates **one draft per line**: "Nirvana by Mushq Unstitched Printed Raw Silk (MU26UNR)" with 10 dresses; "The Secret Garden … (MU26USG)" with 6.
- Each dress block = **1 photo + name + Rs price + fabric description** (from the product's own body_html — the detail WPA can't reach).
- New line launched later = new line code = **new draft automatically**. New dresses in a known line → appended under "🆕".
- Verified live: Mushq 89 products → 17 line-posts (≥2 dresses), Maria B 23 → 3 line-posts.
- Config: add one source array per brand (`'group_by' => 'line'`), keep WPA for TFS/blogs/brand-backfill. Lines with <2 dresses skipped (`CPG_MIN_DRESSES_PER_LINE`).

**Division of labor now:** WPA = TFS collections + Sanaulla brand backfill + blog feeds · Plugin v2 = Sanaulla per-line posts (the "new collection launched" radar). If you want a few hot brands kept in WPA instead: use Multi + fixed list of tag-URLs (e.g. `https://sanaullastore.com/collections/mushq/MU26UNR`) — works with your existing extraction settings, but adding each new line is manual.

---

## (same dedupe logic applies to TFS)
TFS collection URLs are *seasonal* (`charizma-vasal-vol-1-2026`) — each new collection = **new URL** = new post automatically. TFS needs no watcher campaigns; only Sanaulla (permanent brand URLs) does.

## CAMPAIGN 2 — The Fashion Station (Multi-page, FULLY automatic → 1 post/day)

Auto-discovery source: the **TFS homepage** lists 65 product-category links that are real designer collections (verified: `charizma-vasal-vol-1-2026`, `elan-summer-lawn-2026-2`, `gul-ahmed-flora-lawn-2026`, `khaadi-2026-collection`, `limelight-2026-collection`…). New collections appear there when TFS adds them → campaign picks them up by itself.

| Screen section | Setting | Value |
|---|---|---|
| Campaign Type | Type | **Multi-page scraper** |
| Basic | Title | `TFS – Collections` |
| Basic | Post Type / Post Status | Post / **Draft** |
| Basic | Post Category | Collections |
| Scraper box | **Items list page URL** | `https://www.thefashionstation.in/` |
| Scraper box | Links extraction method | **REGEX** → `https://www\.thefashionstation\.in/product-category/[a-z0-9-]+/?` (no container class needed; the plugin extracts these URLs and its fallback converts them into item links — designed code path) |
| Scraper box | **Caching** | **enabled** |
| Scraper box | Pagination | **Auto detect** (single page) |
| Filters | Skip posts containing | `ready-to-ship, kurtis-for-women, luxe-pret, nur-basics` (generic categories among the 65 — slugs match the URL text, keep hyphens exactly) |
| Item settings | Single item title extraction method | **Auto detect** ⚠️ their category pages have NO `<h1>` (verified) — auto uses `<title>` → "Collection Name | … | The Fashion Station"; trim the suffix when rewriting |
| Item settings | Link to a single item extraction method | **CSS selector** → Rule 1: type **xPath** → `(//div[contains(@class,'product-small')])[position()<=15]` → Matches **all** → inner (parentheses REQUIRED — verified: returns exactly 15 cards; without them you get all 30) |
| Filters / cleanup | Strip content using CSS → class | `show-on-hover` (removes the hover image → exactly **1 image per dress**; the card keeps name + ₹ price text) |
| Images | ❌ UNTICK "Try to generate a name for the image from the post title" | the generated filename contains an em-dash from titles ("…— Original…") which breaks the featured-image/gallery matching (`<-- no content` spam in the log). Original filenames (S26W8191_HoneyPeach_Cover1.png) are cleaner anyway |
| Images | same 3 ticks as Campaign 1 | featured + width 400 + **Gallery (downloaded)** |
| Time | Run frequency | **Every 1 Days** |

**Optional (₹ prices):** Filters → strip by REGEX → line `<span class="woocommerce-Price-amount amount">.*?</span>` removes price blocks from drafts.

**Test:** Run Now. Log must show:
`Loading: https://www.thefashionstation.in/` → `Approved found links: 65` (minus skips) → first item = a real `/product-category/…/` page → `Extracting content by xpath: //div[…product-small…][position()<=15]` → gallery lines.

**Result:** 1 collection draft/day in homepage order; when TFS publishes a collection and links it on the homepage, it enters the queue automatically. No manual list, ever.

---

## Operating notes
- **1 run = 1 post** for Multi campaigns — the schedule *is* the throttle (12 h = 2/day, 24 h = 1/day).
- **⚠️ Changed a scraping setting? The campaign keeps using its OLD cached links feed** ("Cache found, loading items from the cache" in the log). To force a fresh scrape: set **Caching → disabled → Update → Run Now** (verify the new log: `Loading:` the source + `Approved found links: ~400 (Sanaulla) / 65 (TFS)`), then set **Caching → enabled → Update** again. There is no "clear cache" button in v6.3.
- **XPath caps need parentheses**: `(//div[…])[position()<=15]` ✅ — without them `position()` is evaluated per parent element and the cap silently matches everything.
- Deleting a draft does **not** repost it — dedupe is by source link, permanent per campaign.
- Don't like a posted collection? Delete the draft and move on; the campaign already advanced.
- To pause: deactivate the campaign (link cache survives).
- Big Sanaulla collections (>100 dresses) still cap at what page 1 renders + your 15-image XPath — by design.
