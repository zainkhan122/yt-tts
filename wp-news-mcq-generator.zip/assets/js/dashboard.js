/**
 * User Dashboard Script - v4.5
 * Handles tab switching, chart loading, and settings form submissions.
 *
 * @MODIFIED: This file was previously empty. It now contains all the
 * necessary JavaScript to make the dashboard interactive.
 * @MODIFIED: All AJAX calls now use the new `nm_dashboard_ajax_nonce`.
 * @MODIFIED: Profile/Password forms now use the correct nonces from the
 * dashboard.php template.
 */

jQuery(function ($) {
    'use strict';

    // Check if we are on the dashboard
    if ($('.nm-dashboard-wrapper').length === 0) {
        return;
    }

    // --- 1. CONFIGURATION & STATE ---
    const config = window.dashboardConfig || {};
    const ajaxUrl = config.ajaxurl || '/wp-admin/admin-ajax.php';
    const ajaxNonce = config.ajaxNonce || '';
    let performanceChart = null;

    // --- 2. TAB SWITCHING ---
    const tabs = $('.nm-tab-btn');
    const panels = $('.nm-tab-panel');

    tabs.on('click', function (e) {
        e.preventDefault();
        const tab = $(this).data('tab');

        // Update tabs
        tabs.removeClass('active');
        $(this).addClass('active');

        // Update panels
        panels.removeClass('active');
        $('.nm-tab-panel[data-panel="' + tab + '"]').addClass('active');

        // Load data for the activated tab
        loadDataForTab(tab);
    });

    // --- 3. DATA LOADING ---

    /**
     * Load data for the currently active tab
     * @param {string} tabName - The 'data-tab' attribute value
     */
    function loadDataForTab(tabName) {
        switch (tabName) {
            case 'overview':
                loadRecentActivity();
                break;
            case 'performance':
                loadPerformanceChart();
                break;
            case 'progress':
                loadTopicProgress();
                break;
        }
    }

    /**
     * Load Recent Activity (Overview Tab)
     */
    function loadRecentActivity() {
        const container = $('#nm-recent-activity');
        if (container.data('loaded')) return; // Already loaded

        container.html('<div class="nm-spinner-wrapper"><div class="nm-spinner"></div></div>');

        $.ajax({
            url: ajaxUrl,
            type: 'POST',
            data: {
                action: 'nm_get_recent_activity',
                nonce: ajaxNonce
            },
            success: function (response) {
                if (response.success && response.data.length > 0) {
                    let html = '';
                    response.data.forEach(item => {
                        const icon = item.is_correct ? '✅' : '❌';
                        const statusClass = item.is_correct ? 'correct' : 'wrong';
                        html += `
                            <div class="nm-activity-item ${statusClass}">
                                <a href="${item.url}" class="nm-activity-link" target="_blank">
                                    <span class="nm-activity-icon">${icon}</span>
                                    <div class="nm-activity-content">
                                        <h4 class="nm-activity-title">${item.title}</h4>
                                        <p class="nm-activity-meta">
                                            <span>${item.topic}</span>
                                            &bull;
                                            <span>${item.time_ago}</span>
                                        </p>
                                    </div>
                                </a>
                            </div>
                        `;
                    });
                    container.html(html);
                    container.data('loaded', true);
                } else {
                    container.html(`
                        <div class="nm-activity-empty">
                            <p>No activity yet.</p>
                            <p class="nm-activity-hint">Your answered questions will appear here.</p>
                        </div>
                    `);
                }
            },
            error: function () {
                container.html('<div class="nm-activity-empty"><p>Error loading activity.</p></div>');
            }
        });
    }

    /**
     * Load Performance Chart (Performance Tab)
     */
    function loadPerformanceChart() {
        const ctx = document.getElementById('nm-performance-chart');
        if (!ctx || $(ctx).data('loaded')) return; // No canvas or already loaded

        $.ajax({
            url: ajaxUrl,
            type: 'POST',
            data: {
                action: 'nm_get_performance_chart',
                nonce: ajaxNonce
            },
            success: function (response) {
                if (response.success) {
                    const labels = response.data.map(item => item.date);
                    const data = response.data.map(item => item.accuracy);

                    if (performanceChart) {
                        performanceChart.destroy();
                    }

                    performanceChart = new Chart(ctx, {
                        type: 'line',
                        data: {
                            labels: labels,
                            datasets: [{
                                label: 'Accuracy %',
                                data: data,
                                fill: true,
                                backgroundColor: 'rgba(102, 126, 234, 0.1)',
                                borderColor: 'rgba(102, 126, 234, 1)',
                                tension: 0.3,
                                pointBackgroundColor: 'rgba(102, 126, 234, 1)',
                                pointRadius: 5
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            scales: {
                                y: {
                                    beginAtZero: true,
                                    max: 100,
                                    ticks: {
                                        callback: function (value) {
                                            return value + '%';
                                        }
                                    }
                                }
                            },
                            plugins: {
                                legend: {
                                    display: false
                                },
                                tooltip: {
                                    callbacks: {
                                        label: function (context) {
                                            return 'Accuracy: ' + context.parsed.y + '%';
                                        }
                                    }
                                }
                            }
                        }
                    });
                    $(ctx).data('loaded', true);
                }
            }
        });
    }

    /**
     * Load Topic Progress (Progress Tab)
     */
    function loadTopicProgress() {
        const container = $('#nm-topic-progress-body');
        if (container.data('loaded')) return;

        container.html('<tr><td colspan="4"><div class="nm-spinner-wrapper" style="padding: 40px 0;"><div class="nm-spinner"></div></div></td></tr>');

        $.ajax({
            url: ajaxUrl,
            type: 'POST',
            data: {
                action: 'nm_get_topic_progress',
                nonce: ajaxNonce
            },
            success: function (response) {
                if (response.success && response.data.length > 0) {
                    let html = '';
                    response.data.forEach(item => {
                        let accuracyClass = 'high';
                        if (item.accuracy < 75) accuracyClass = 'medium';
                        if (item.accuracy < 50) accuracyClass = 'low';

                        html += `
                            <tr>
                                <td><strong>${item.name}</strong></td>
                                <td>
                                    <span class="nm-score-badge ${accuracyClass}">${item.accuracy}%</span>
                                </td>
                                <td>
                                    <div class="nm-progress-bar">
                                        <div class="nm-progress-fill" style="width: ${item.percentage}%;"></div>
                                    </div>
                                </td>
                                <td>
                                    <span class="nm-completed-count">${item.completed} / ${item.total}</span>
                                </td>
                            </tr>
                        `;
                    });
                    container.html(html);
                    container.data('loaded', true);
                } else {
                    container.html('<tr><td colspan="4"><div class="nm-no-data">No topic progress yet.</div></td></tr>');
                }
            },
            error: function () {
                container.html('<tr><td colspan="4"><div class="nm-no-data">Error loading progress.</div></td></tr>');
            }
        });
    }

    // --- 4. SETTINGS FORM HANDLERS ---
    
    // Helper to show alerts
    function showSettingAlert(form, message, type = 'success') {
        form.find('.nm-alert').remove();
        const alertHtml = `<div class="nm-alert ${type}">${message}</div>`;
        form.prepend(alertHtml);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            form.find('.nm-alert').fadeOut(300, function() { $(this).remove(); });
        }, 5000);
    }

    /**
     * Handle Profile Form Submission
     */
    $('#nm-profile-form').on('submit', function(e) {
        e.preventDefault();
        const form = $(this);
        const btn = form.find('button[type="submit"]');
        const btnText = btn.html();

        btn.prop('disabled', true).html('Updating...');

        $.ajax({
            url: ajaxUrl,
            type: 'POST',
            data: {
                action: 'nm_update_user_profile',
                // ✅ FIX: Use the correct nonce from the form
                _wpnonce: form.find('#_wpnonce').val() || form.find('#nm_profile_nonce').val(),
                display_name: form.find('#display_name').val(),
                nm_user_bio: form.find('#nm_user_bio').val(),
                nm_public_profile: form.find('[name="nm_public_profile"]').is(':checked') ? 1 : 0
            },
            success: function(response) {
                if (response.success) {
                    showSettingAlert(form, response.data.message, 'success');
                    // Update header
                    $('.nm-user-name').text(form.find('#display_name').val());
                    $('.nm-user-bio').text(form.find('#nm_user_bio').val() || 'No bio added yet. Click ⚙️ Settings to add one!');
                } else {
                    showSettingAlert(form, response.data.message, 'error');
                }
            },
            error: function(xhr) {
                showSettingAlert(form, xhr.responseJSON?.data?.message || 'Failed to update profile. Please try again.', 'error');
            },
            complete: function() {
                btn.prop('disabled', false).html(btnText);
            }
        });
    });
    
    /**
     * Handle Password Change Form Submission
     */
    $('#nm-password-form').on('submit', function(e) {
        e.preventDefault();
        const form = $(this);
        const btn = form.find('button[type="submit"]');
        const btnText = btn.html();

        const newPass = form.find('#new_password').val();
        const confirmPass = form.find('#confirm_password').val();

        if (newPass !== confirmPass) {
            showSettingAlert(form, 'New passwords do not match.', 'error');
            return;
        }

        btn.prop('disabled', true).html('Changing...');

        $.ajax({
            url: ajaxUrl,
            type: 'POST',
            data: {
                action: 'nm_change_user_password',
                // ✅ FIX: Use the correct nonce from the form
                _wpnonce: form.find('#_wpnonce').val() || form.find('#nm_password_nonce').val(),
                current_password: form.find('#current_password').val(),
                new_password: newPass
            },
            success: function(response) {
                if (response.success) {
                    showSettingAlert(form, response.data.message, 'success');
                    form[0].reset();
                } else {
                    showSettingAlert(form, response.data.message, 'error');
                }
            },
            error: function() {
                showSettingAlert(form, 'An error occurred. Please try again.', 'error');
            },
            complete: function() {
                btn.prop('disabled', false).html(btnText);
            }
        });
    });
    
    /**
     * Handle Delete Account
     */
    $('#nm-delete-account-btn').on('click', function() {
        if (!confirm('Are you absolutely sure?\nThis action cannot be undone and all your data (points, progress, history) will be permanently deleted.')) {
            return;
        }

        const btn = $(this);
        const btnText = btn.html();
        btn.prop('disabled', true).html('Deleting...');

        $.ajax({
            url: ajaxUrl,
            type: 'POST',
            data: {
                action: 'nm_delete_user_account',
                // ✅ FIX: Use the dashboard-wide nonce
                _wpnonce: ajaxNonce
            },
            success: function(response) {
                if (response.success) {
                    alert('Account deleted successfully. You will now be logged out.');
                    window.location.href = '/'; // Redirect to home
                } else {
                    alert('Error: ' + response.data.message);
                    btn.prop('disabled', false).html(btnText);
                }
            },
            error: function() {
                alert('An error occurred. Please try again.');
                btn.prop('disabled', false).html(btnText);
            }
        });
    });

    // --- 5. INITIAL LOAD ---
    // Load data for the default active tab (Overview)
    loadDataForTab('overview');
});