<?php

/**
 * Media Localizer Service
 *
 * Downloads external images referenced in a source (idea) post into the local
 * Media Library and replaces URLs in post_content.
 *
 * Also optionally hard-deletes surplus images beyond persona caps.
 *
 * @package DIT_TrendStudio
 * @since 2.13.9
 */

namespace DIT\TrendStudio\Services;

use DIT\TrendStudio\Infrastructure\Logger;

if (!defined('ABSPATH')) {
    exit;
}

class Media_Localizer
{
    private ?Logger $logger;

    public function __construct(?Logger $logger = null)
    {
        $this->logger = $logger;
    }

    /**
     * Localize images in an HTML string WITHOUT mutating the source post.
     *
     * This is the safe path for rewrite personas (fashion_pk/showbiz_pk) so we never
     * rename/delete shared attachments on the source draft/idea.
     *
     * - External images are sideloaded as NEW, job-owned attachments.
     * - Local images: tag (transfer_exclusive/transfer_force) or clone (clone mode).
     * - Surplus images beyond $max_images are removed from the HTML string only (no deletion here).
     *
     * @MODIFIED 2026-02-24 - Non-destructive persona media pipeline (Fix #Showbiz404)
     * @MODIFIED 2026-05-11 - Add local_mode parameter to replace clone_local bool
     * @MODIFIED 2026-06-25 - Add vertical parameter for dimension-aware image selection
     *
     * @param string $html
     * @param int    $owner_post_id
     * @param int    $max_images
     * @param int    $job_id
     * @param string $local_mode  (clone|transfer_exclusive|transfer_force|keep)
     * @param string $vertical    (showbiz_pk|fashion_pk|general) — drives dimension-aware sorting
     * @return array{updated:bool,post_id:int,kept:int,imported:int,removed:int,deleted:int,failed:int,updated_content:string}
     */
    public function localize_html_images(string $html, int $owner_post_id, int $max_images, int $job_id = 0, string $local_mode = 'clone', string $vertical = ''): array
    {
        // Normalize local_mode to valid options
        $local_mode = in_array($local_mode, ['clone', 'transfer_exclusive', 'transfer_force', 'keep'], true) ? $local_mode : 'clone';

        // Determine clone behavior from local_mode
        $should_clone = ($local_mode === 'clone');
        $content = (string) $html;
        if (trim($content) === '') {
            return [
                'updated'  => false,
                'post_id'  => $owner_post_id,
                'kept'     => 0,
                'imported' => 0,
                'removed'  => 0,
                'deleted'  => 0,
                'failed'   => 0,
                'updated_content' => $content,
            ];
        }

        $max_images = max(1, (int) $max_images);

        $inv = new Media_Inventory($this->logger);
        $raw_urls = $inv->extract_image_urls($content);

        // De-dup while preserving order.
        $ordered = [];
        $seen = [];
        foreach ($raw_urls as $u) {
            $u = trim((string) $u);
            if ($u === '') {
                continue;
            }

            $abs = $inv->normalize_to_absolute_url($u);
            $key = strtolower(preg_replace('/[?#].*/', '', $abs));
            if ($key === '') {
                continue;
            }

            if (isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            // @MODIFIED 2026-05-10 - Check if this is a "bare filename" (no path component)
            // Generator outputs like "1777406419_536_Name.jpg" without domain/path.
            // These won't match is_local_url() but ARE local attachments - try resolution anyway.
            $is_bare_filename = ($u !== '' && !preg_match('#^[a-z][a-z0-9+.-]*://#i', $u) && strpos($u, '/') === false && preg_match('/\.(jpe?g|png|webp)$/i', $u));
            $ordered[] = [
                'raw' => $u,
                'abs' => $abs,
                'is_bare' => $is_bare_filename,
            ];
        }

        // @MODIFIED 2026-06-25 - Dimension-aware image selection for persona verticals.
        // For showbiz_pk/fashion_pk, sort by height descending so the tallest images
        // (celebrity photos) are kept first, not comment screenshots (which are wide but short).
        $is_persona = (strpos($vertical, 'showbiz') !== false || strpos($vertical, 'fashion') !== false);
        if ($is_persona && !empty($ordered)) {
            // Extract height from HTML <img> tags for each URL
            foreach ($ordered as &$item) {
                $item['height'] = 0;
                $raw_url = (string) ($item['raw'] ?? '');
                if ($raw_url !== '') {
                    // Find the <img> tag containing this URL and extract height attribute
                    if (preg_match('/<img[^>]+(?:src|data-src|data-lazy-src)=["\']' . preg_quote($raw_url, '/') . '["\'][^>]*\bheight=["\'](\d+)["\']/i', $content, $hm)) {
                        $item['height'] = (int) $hm[1];
                    } elseif (preg_match('/<img[^>]*\bheight=["\'](\d+)["\'][^>]+(?:src|data-src|data-lazy-src)=["\']' . preg_quote($raw_url, '/') . '["\']/i', $content, $hm)) {
                        $item['height'] = (int) $hm[1];
                    }
                }
            }
            unset($item);

            // Sort by height descending (tallest first), preserving original order for ties
            usort($ordered, static function ($a, $b) {
                return ($b['height'] ?? 0) <=> ($a['height'] ?? 0);
            });

            if (isset($this->logger)) {
                $this->logger->info('Media_Localizer: dimension-aware sort applied', [
                    'vertical' => $vertical,
                    'top_heights' => array_slice(array_column($ordered, 'height'), 0, 5),
                ]);
            }
        }

        if (empty($ordered)) {
            return [
                'updated'  => false,
                'post_id'  => $owner_post_id,
                'kept'     => 0,
                'imported' => 0,
                'removed'  => 0,
                'deleted'  => 0,
                'failed'   => 0,
                'updated_content' => $content,
            ];
        }

        $keep = array_slice($ordered, 0, $max_images);
        $surplus = array_slice($ordered, $max_images);

        $updated = false;
        $imported = 0;
        $removed = 0;
        $failed = 0;

        $replace = [];

        // 1) Import/clone + replace keep URLs.
        foreach ($keep as $i => $item) {
            $raw = (string) $item['raw'];
            $abs = (string) $item['abs'];
            $is_bare = !empty($item['is_bare']);

            // @MODIFIED 2026-05-10 - Also treat bare filenames as local (bypasses is_local_url check)
            // @MODIFIED 2026-05-11 - Use $should_clone based on local_mode
            // @MODIFIED 2026-05-11 - Handle keep mode (skip all processing)
            if ($this->is_local_url($abs) || $is_bare) {
                if ($local_mode === 'keep') {
                    // keep mode: don't touch local images at all
                    continue;
                }
                if (!$should_clone) {
                    $att_id = (int) $inv->resolve_attachment_id_from_url($abs, (int) $owner_post_id);
                    if ($att_id <= 0 && (int) $owner_post_id > 0) {
                        $att_id = $this->register_wpa_image($raw, (int) $owner_post_id, (int) $job_id);
                    }
                    if ($att_id > 0) {
                        update_post_meta($att_id, '_dit_ts_media_owner', (int) $owner_post_id);
                        update_post_meta($att_id, '_dit_ts_media_managed', 1);
                        update_post_meta($att_id, '_dit_ts_content_url', $raw);
                        if ($job_id > 0) {
                            update_post_meta($att_id, '_dit_ts_media_job', (int) $job_id);
                        }
                        $att_url = wp_get_attachment_url($att_id);
                        if (!empty($att_url) && $att_url !== $raw) {
                            $replace[$raw] = $att_url;
                            if ($abs !== $raw && $att_url !== $abs) {
                                $replace[$abs] = $att_url;
                            }
                        }
                        $updated = true;
                    } else {
                        $this->logger->info('Media_Localizer: could not resolve attachment', [
                            'raw_url' => $raw,
                            'abs_url' => $abs,
                            'owner_post_id' => $owner_post_id,
                        ]);
                        $failed++;
                    }
                    continue;
                }

                $att_id = (int) $inv->resolve_attachment_id_from_url($abs, (int) $owner_post_id);
                if ($att_id <= 0) {
                    $failed++;
                    continue;
                }

                $clone_id = $this->clone_local_attachment($att_id, $owner_post_id, $job_id, $i + 1);
                if ($clone_id > 0) {
                    $new_url = wp_get_attachment_url($clone_id);
                    if (!empty($new_url)) {
                        $replace[$raw] = $new_url;
                        if ($abs !== $raw) {
                            $replace[$abs] = $new_url;
                        }
                        $imported++;
                        $updated = true;
                    } else {
                        $failed++;
                    }
                } else {
                    $failed++;
                }

                continue;
            }

            // External: always sideload as a NEW attachment to avoid cross-post coupling.
            $new_id = $this->sideload_image($abs, 0, $job_id, $i + 1);
            if ($new_id > 0) {
                $new_url = wp_get_attachment_url($new_id);
                if (!empty($new_url)) {
                    // Mark ownership for later rename/delete.
                    update_post_meta($new_id, '_dit_ts_media_owner', (int) $owner_post_id);
                    update_post_meta($new_id, '_dit_ts_media_managed', 1);
                    if ($job_id > 0) {
                        update_post_meta($new_id, '_dit_ts_media_job', (int) $job_id);
                    }

                    $replace[$raw] = $new_url;
                    if ($abs !== $raw) {
                        $replace[$abs] = $new_url;
                    }
                    $imported++;
                    $updated = true;
                } else {
                    $failed++;
                }
            } else {
                $failed++;
            }
        }

        if (!empty($replace)) {
            $content = strtr($content, $replace);
        }

        // 2) Remove surplus beyond cap from HTML only.
        foreach ($surplus as $item) {
            $raw = (string) $item['raw'];
            $abs = (string) $item['abs'];

            $before = $content;
            $content = $this->remove_image_by_src($content, $raw);
            if ($abs !== $raw) {
                $content = $this->remove_image_by_src($content, $abs);
            }

            if ($content !== $before) {
                $removed++;
                $updated = true;
            }
        }

        return [
            'updated'  => (bool) $updated,
            'post_id'  => $owner_post_id,
            'kept'     => count($keep),
            'imported' => (int) $imported,
            'removed'  => (int) $removed,
            'deleted'  => 0,
            'failed'   => (int) $failed,
            'updated_content' => $content,
        ];
    }

    /**
     * Clone a local attachment into a NEW job-owned attachment.
     *
     * @MODIFIED 2026-02-24 - Non-destructive local clone for personas (Fix #Showbiz404)
     */
    private function clone_local_attachment(int $attachment_id, int $owner_post_id, int $job_id, int $index): int
    {
        $src_path = get_attached_file($attachment_id);
        if (empty($src_path) || !file_exists($src_path)) {
            return 0;
        }

        if (!function_exists('wp_generate_attachment_metadata')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }

        $pi = pathinfo($src_path);
        $dir = (string) ($pi['dirname'] ?? '');
        $basename = (string) ($pi['basename'] ?? '');

        if ($dir === '' || $basename === '') {
            return 0;
        }

        $dest_basename = wp_unique_filename($dir, $basename);
        $dest_path = trailingslashit($dir) . $dest_basename;

        if (!@copy($src_path, $dest_path)) {
            return 0;
        }

        $filetype = wp_check_filetype($dest_basename, null);

        $attachment = [
            'post_mime_type' => (string) ($filetype['type'] ?? ''),
            'post_title'     => (string) (get_the_title($attachment_id) ?: ('Image ' . (int) $index)),
            'post_content'   => '',
            'post_status'    => 'inherit',
            'post_parent'    => 0, // Unattached until auto_publish transfers ownership.
        ];

        $new_id = (int) wp_insert_attachment($attachment, $dest_path, 0);
        if ($new_id <= 0) {
            @unlink($dest_path);
            return 0;
        }

        $meta = wp_generate_attachment_metadata($new_id, $dest_path);
        if (!empty($meta)) {
            wp_update_attachment_metadata($new_id, $meta);
        }

        update_post_meta($new_id, '_dit_ts_source_attachment_id', (int) $attachment_id);
        update_post_meta($new_id, '_dit_ts_media_owner', (int) $owner_post_id);
        update_post_meta($new_id, '_dit_ts_media_managed', 1);
        if ($job_id > 0) {
            update_post_meta($new_id, '_dit_ts_media_job', (int) $job_id);
        }

        return $new_id;
    }

    /**
     * Localize external images in a post.
     *
     * @MODIFIED 2026-02-19 - Added for persona rewrite pipelines (fashion_pk/showbiz_pk)
     * to ensure deterministic collage generation, renaming, and surplus deletion.
     *
     * @param int $post_id
     * @param int $max_images
     * @param int $job_id
     * @return array{updated:bool,post_id:int,kept:int,imported:int,removed:int,deleted:int,failed:int}
     */
    public function localize_post_images(int $post_id, int $max_images, int $job_id = 0): array
    {
        $post = get_post($post_id);
        if (empty($post)) {
            return [
                'updated'  => false,
                'post_id'  => $post_id,
                'kept'     => 0,
                'imported' => 0,
                'removed'  => 0,
                'deleted'  => 0,
                'failed'   => 0,
            ];
        }

        $content = (string) $post->post_content;
        if (trim($content) === '') {
            return [
                'updated'  => false,
                'post_id'  => $post_id,
                'kept'     => 0,
                'imported' => 0,
                'removed'  => 0,
                'deleted'  => 0,
                'failed'   => 0,
            ];
        }

        // Avoid re-running for the same job.
        if ($job_id > 0) {
            $last = (int) get_post_meta($post_id, '_dit_ts_media_localizer_job', true);
            if ($last === $job_id) {
                return [
                    'updated'  => false,
                    'post_id'  => $post_id,
                    'kept'     => 0,
                    'imported' => 0,
                    'removed'  => 0,
                    'deleted'  => 0,
                    'failed'   => 0,
                ];
            }
        }

        $max_images = max(1, (int) $max_images);

        $inv = new Media_Inventory($this->logger);
        $raw_urls = $inv->extract_image_urls($content);

        // De-dup while preserving order.
        $ordered = [];
        $seen = [];
        foreach ($raw_urls as $u) {
            $u = trim((string) $u);
            if ($u === '') {
                continue;
            }

            $abs = $inv->normalize_to_absolute_url($u);
            $key = strtolower(preg_replace('/[?#].*/', '', $abs));
            if ($key === '') {
                continue;
            }

            if (isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            $ordered[] = [
                'raw' => $u,
                'abs' => $abs,
            ];
        }

        if (empty($ordered)) {
            return [
                'updated'  => false,
                'post_id'  => $post_id,
                'kept'     => 0,
                'imported' => 0,
                'removed'  => 0,
                'deleted'  => 0,
                'failed'   => 0,
            ];
        }

        $keep = array_slice($ordered, 0, $max_images);
        $surplus = array_slice($ordered, $max_images);

        $updated = false;
        $imported = 0;
        $removed = 0;
        $deleted = 0;
        $failed = 0;

        $replace = [];

        // 1) Import + replace keep URLs.
        foreach ($keep as $i => $item) {
            $raw = (string) $item['raw'];
            $abs = (string) $item['abs'];

            if ($this->is_local_url($abs)) {
                continue;
            }

            $existing_id = $this->find_existing_import_id($abs, $post_id);
            if ($existing_id > 0) {
                $new_url = wp_get_attachment_url($existing_id);
                if (!empty($new_url)) {
                    $replace[$raw] = $new_url;
                    if ($abs !== $raw) {
                        $replace[$abs] = $new_url;
                    }
                    continue;
                }
            }

            $new_id = $this->sideload_image($abs, $post_id, $job_id, $i + 1);
            if ($new_id > 0) {
                $new_url = wp_get_attachment_url($new_id);
                if (!empty($new_url)) {
                    $replace[$raw] = $new_url;
                    if ($abs !== $raw) {
                        $replace[$abs] = $new_url;
                    }
                    $imported++;
                    $updated = true;
                } else {
                    $failed++;
                }
            } else {
                $failed++;
            }
        }

        if (!empty($replace)) {
            $content = strtr($content, $replace);
        }

        // 2) Remove + hard-delete surplus beyond cap.
        foreach ($surplus as $item) {
            $raw = (string) $item['raw'];
            $abs = (string) $item['abs'];

            $before = $content;
            $content = $this->remove_image_by_src($content, $raw);
            if ($abs !== $raw) {
                $content = $this->remove_image_by_src($content, $abs);
            }

            if ($content !== $before) {
                $removed++;
                $updated = true;
            }

            // If this was already downloaded as a local attachment, hard-delete it (safe-parent only).
            if ($this->is_local_url($abs)) {
                // @MODIFIED 2026-05-09 - PASS owner_post_id for owner-scoped resolution (consistent with line 129 fix)
                $att_id = (int) $inv->resolve_attachment_id_from_url($abs, (int) $post_id);
                if ($att_id > 0 && $this->is_safe_delete($att_id, $post_id)) {
                    wp_delete_attachment($att_id, true);
                    $deleted++;
                    $updated = true;
                }
            } else {
                // External surplus cannot be deleted. We already removed from content.
            }
        }

        if ($updated) {
            wp_update_post([
                'ID'           => $post_id,
                'post_content' => $content,
            ]);

            update_post_meta($post_id, '_dit_ts_media_localized', current_time('mysql'));
            if ($job_id > 0) {
                update_post_meta($post_id, '_dit_ts_media_localizer_job', (int) $job_id);
            }
        }

        return [
            'updated'  => (bool) $updated,
            'post_id'  => $post_id,
            'kept'     => count($keep),
            'imported' => (int) $imported,
            'removed'  => (int) $removed,
            'deleted'  => (int) $deleted,
            'failed'   => (int) $failed,
            // Convenience for callers that want the final text.
            'updated_content' => $content,
        ];
    }

    /**
     * Determine if URL is local to this site.
     */
    private function is_local_url(string $url): bool
    {
        $url = trim($url);
        if ($url === '') {
            return false;
        }

        $uploads = wp_upload_dir();
        $baseurl = (string) ($uploads['baseurl'] ?? '');
        if ($baseurl !== '' && strpos($url, $baseurl) === 0) {
            return true;
        }

        $home = home_url('/');
        if ($home !== '' && strpos($url, $home) === 0) {
            return true;
        }

        // Also treat absolute wp-content/uploads as local.
        $path = (string) (parse_url($url, PHP_URL_PATH) ?: '');
        if (strpos($path, '/wp-content/uploads/') !== false) {
            return true;
        }

        return false;
    }

    /**
     * Find an existing imported attachment for a given external URL.
     */
    private function find_existing_import_id(string $source_url, int $post_id): int
    {
        global $wpdb;

        $source_url = trim($source_url);
        if ($source_url === '') {
            return 0;
        }

        $sql = $wpdb->prepare(
            "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_dit_ts_source_url' AND meta_value = %s ORDER BY meta_id DESC LIMIT 1",
            $source_url
        );
        $found = (int) $wpdb->get_var($sql);
        if ($found > 0) {
            return $found;
        }

        return 0;
    }

/**
     * Download external image and attach to $post_id.
     */
    private function sideload_image(string $url, int $post_id, int $job_id, int $index): int
    {
        $url = trim($url);
        if ($url === '' || !filter_var($url, FILTER_VALIDATE_URL)) {
            return 0;
        }

        // Ensure WP media functions are available in cron.
        if (!function_exists('media_handle_sideload')) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
            require_once ABSPATH . 'wp-admin/includes/image.php';
        }

        $tmp = download_url($url, 30);
        if (is_wp_error($tmp)) {
            if ($this->logger) {
                $this->logger->warning('Media_Localizer: download_url failed', [
                    'url'   => $url,
                    'error' => $tmp->get_error_message(),
                ]);
            }
            return 0;
        }

        $name = basename((string) (parse_url($url, PHP_URL_PATH) ?: 'image'));
        $name = preg_replace('/[^A-Za-z0-9._-]/', '-', (string) $name);
        if ($name === '' || $name === '-') {
            $name = 'image-' . (int) $index . '.jpg';
        }

        $file_array = [
            'name'     => $name,
            'tmp_name' => $tmp,
        ];

        $att_id = (int) media_handle_sideload($file_array, 0, 'image-' . $index);
        if (is_wp_error($att_id) || $att_id <= 0) {
            @unlink($tmp);
            if ($this->logger) {
                $this->logger->warning('Media_Localizer: media_handle_sideload failed', [
                    'url'   => $url,
                    'error' => is_wp_error($att_id) ? $att_id->get_error_message() : 'unknown',
                ]);
            }
            return 0;
        }

        // Mark provenance for later cleanup / auditing.
        update_post_meta($att_id, '_dit_ts_source_url', $url);
        update_post_meta($att_id, '_dit_ts_media_owner', (int) $post_id);
        if ($job_id > 0) {
            update_post_meta($att_id, '_dit_ts_media_job', (int) $job_id);
        }
        update_post_meta($att_id, '_dit_ts_media_managed', 1);

        return $att_id;
    }

    /**
     * Remove image tags (and common wrappers) by matching src.
     */
    private function remove_image_by_src(string $html, string $src): string
    {
        $src = trim($src);
        if ($src === '') {
            return $html;
        }

        $q = preg_quote($src, '/');

        // Remove common wrapper blocks first.
        $html = preg_replace('/<figure\b[^>]*>\s*<img\b[^>]*\bsrc=["\']' . $q . '["\'][^>]*>.*?<\/figure>\s*/is', '', $html);
        $html = preg_replace('/<p\b[^>]*>\s*<img\b[^>]*\bsrc=["\']' . $q . '["\'][^>]*>\s*<\/p>\s*/is', '', $html);

        // Remove the <img> tag itself.
        $html = preg_replace('/<img\b[^>]*\bsrc=["\']' . $q . '["\'][^>]*>\s*/is', '', $html);

        // Also remove data-src variants.
        $html = preg_replace('/<img\b[^>]*\b(?:data-src|data-lazy-src)=["\']' . $q . '["\'][^>]*>\s*/is', '', $html);

        return (string) $html;
    }

    /**
     * Only hard-delete attachments that are unparented or already attached to this post.
     */
    private function is_safe_delete(int $attachment_id, int $post_id): bool
    {
        $managed = (int) get_post_meta($attachment_id, '_dit_ts_media_managed', true);
        $owner   = (int) get_post_meta($attachment_id, '_dit_ts_media_owner', true);

        if ($managed !== 1 || $owner !== $post_id) {
            if ($this->logger) {
                $this->logger->warning('Media_Localizer: skip delete (not managed or wrong owner)', [
                    'attachment_id' => $attachment_id,
                    'managed'       => $managed,
                    'owner'         => $owner,
                    'post_id'       => $post_id,
                ]);
            }
            return false;
        }

        return true;
    }

    /**
     * Register a WPA-downloaded image as a proper WordPress attachment.
     *
     * WPA downloads image files to the uploads directory but does NOT create
     * wp_posts attachment entries (except for the featured image). This method
     * finds the file on disk, creates an attachment post with metadata, and
     * returns the new attachment ID so the pipeline can rename, re-parent, and
     * track the image through all subsequent phases.
     */
    private function register_wpa_image(string $url, int $owner_post_id, int $job_id): int
    {
        $uploads = wp_upload_dir();
        $uploads_url = trailingslashit($uploads['baseurl'] ?? '');
        $uploads_dir = trailingslashit($uploads['basedir'] ?? '');
        $file_path = '';

        if (strpos($url, $uploads_url) === 0) {
            $rel = ltrim(substr($url, strlen($uploads_url)), '/');
            $candidate = $uploads_dir . $rel;
            if (@is_file($candidate)) {
                $file_path = $candidate;
            } elseif ($rel !== urldecode($rel)) {
                $decoded_candidate = $uploads_dir . urldecode($rel);
                if (@is_file($decoded_candidate)) {
                    $file_path = $decoded_candidate;
                }
            }
        }

        if ($file_path === '') {
            $basename = basename((string) (parse_url($url, PHP_URL_PATH) ?: $url));
            $basename_decoded = urldecode($basename);
            if ($basename_decoded !== '' && strpos($basename_decoded, '.') !== false) {
                $stem = preg_replace('/^(?:\d+_)*/', '', $basename_decoded);
                $stem = ltrim($stem, '_');
                if ($stem === '') return 0;
                $year_month = current_time('Y/m');
                foreach ([$uploads_dir . $year_month, $uploads_dir . dirname((string) (parse_url($url, PHP_URL_PATH) ?: ''))] as $dir) {
                    if (!@is_dir($dir)) continue;
                    $dh = @opendir($dir);
                    if (!$dh) continue;
                    while (($entry = readdir($dh)) !== false) {
                        if ($entry === '.' || $entry === '..') continue;
                        if (!preg_match('/\.(jpe?g|png|webp|gif)$/i', $entry)) continue;
                        $entry_stem = preg_replace('/^(?:\d+_)*/', '', $entry);
                        $entry_stem = ltrim($entry_stem, '_');
                        if ($entry_stem === $stem) {
                            $candidate = $dir . '/' . $entry;
                            if (@is_file($candidate)) {
                                $file_path = $candidate;
                                closedir($dh);
                                break 2;
                            }
                        }
                    }
                    closedir($dh);
                }
            }
        }

        if ($file_path === '' || !@is_file($file_path)) {
            return 0;
        }

        $rel_path = ltrim(str_replace(trailingslashit($uploads_dir), '', $file_path), '/');
        global $wpdb;
        $existing = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_wp_attached_file' AND meta_value = %s LIMIT 1",
            $rel_path
        ));
        if ($existing > 0) {
            return $existing;
        }

        if (!function_exists('wp_generate_attachment_metadata')) {
            require_once ABSPATH . 'wp-admin/includes/image.php';
            require_once ABSPATH . 'wp-admin/includes/file.php';
            require_once ABSPATH . 'wp-admin/includes/media.php';
        }

        $filetype = wp_check_filetype(basename($file_path));
        $att_id = (int) wp_insert_attachment([
            'post_mime_type' => $filetype['type'] ?? '',
            'post_title'     => pathinfo($file_path, PATHINFO_FILENAME),
            'post_content'   => '',
            'post_status'    => 'inherit',
            'post_parent'    => $owner_post_id,
            'guid'           => $uploads_url . $rel_path,
        ], $file_path, $owner_post_id);

        if ($att_id > 0) {
            update_post_meta($att_id, '_wp_attached_file', $rel_path);
            $meta = wp_generate_attachment_metadata($att_id, $file_path);
            if (!empty($meta)) {
                wp_update_attachment_metadata($att_id, $meta);
            }
            if ($this->logger) {
                $this->logger->info('Media_Localizer: registered WPA image', [
                    'attachment_id' => $att_id,
                    'file'          => $file_path,
                    'owner_post_id' => $owner_post_id,
                ]);
            }
        }

        return $att_id;
    }
}
