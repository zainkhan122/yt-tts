<?php

/**
 * Structured Output Schemas
 *
 * Centralizes JSON schema definitions used for provider-side schema enforcement
 * (Gemini responseSchema / Perplexity response_format json_schema).
 *
 * @package DIT_TrendStudio\AI
 * @since 2.12.0
 */

namespace DIT\TrendStudio\AI;

if (!defined('ABSPATH')) {
    exit;
}

class StructuredOutputSchema
{
    /**
     * Detect placement mode from the human-readable output schema string.
     *
     * IMPORTANT:
     * In this plugin, structured blocks are stored at sections[].blocks (NOT top-level blocks).
     *
     * @param string $output_schema Output schema text (often a JSON stub string).
     * @return string token_matcher|structured_blocks
     */
    public static function detect_mode_from_output_schema(string $output_schema): string
    {
        $trim = trim($output_schema);

        // Prefer parsing when the schema is a JSON stub (more reliable than substring matching).
        if ($trim !== '' && ($trim[0] === '{' || $trim[0] === '[')) {
            $decoded = json_decode($trim, true);
            if (is_array($decoded)) {
                // Structured blocks in this plugin are sections[].blocks
                if (isset($decoded['sections'][0]['blocks'])) {
                    return 'structured_blocks';
                }
                // Legacy / alt shapes fallback
                if (isset($decoded['blocks'])) {
                    return 'structured_blocks';
                }
                return 'token_matcher';
            }
        }

        // Fallback heuristic (keep it simple)
        return (stripos($output_schema, '"blocks"') !== false) ? 'structured_blocks' : 'token_matcher';
    }

    /**
     * JSON Schema for Perplexity response_format json_schema.
     *
     * @param string $mode Placement mode.
     * @return array
     */
    public static function json_schema_article(string $mode = 'token_matcher'): array
    {
	$base_props = array(
		'headline' => array('type' => 'string'),
		'dek' => array('type' => 'string'),
		'category' => array('type' => 'string'),
		'vertical' => array('type' => 'string'),
		'meta_description' => array('type' => 'string'),
		'primary_keyword' => array('type' => 'string'),
		'tags' => array(
			'type' => 'array',
			'items' => array('type' => 'string'),
		),
		'sources' => array(
			'type' => 'array',
			'items' => array(
				'type' => 'object',
				'properties' => array(
					'title' => array('type' => 'string'),
					'url' => array('type' => 'string'),
				),
				'required' => array('url', 'title'),
				'additionalProperties' => false,
			),
		),
		'source_snippets' => array(
			'type' => 'array',
			'items' => array('type' => 'string'),
		),
		'social_assets' => array(
			'type' => 'object',
			'properties' => array(
				'urdu_heading' => array('type' => 'string'),
				'urdu_description' => array('type' => 'string'),
				'hashtags' => array(
					'type' => 'array',
					'description' => 'List of relevant hashtags. MUST BE IN ENGLISH ONLY.',
					'items' => array('type' => 'string'),
				),
			),
			'required' => array('urdu_heading', 'urdu_description', 'hashtags'),
			'additionalProperties' => false,
		),
	);

        $block_item = array(
            'type'       => 'object',
            'properties' => array(
                'type'    => array('type' => 'string'), // paragraph|heading|visual_ref|embed_ref|html|...
                'level'   => array('type' => 'integer'), // for headings
                'id'      => array('type' => 'integer'), // for visual_ref
                'url'     => array('type' => 'string'),  // for embed_ref, sources, etc.
                'html'    => array('type' => 'string'),
                'text'    => array('type' => 'string'),
	'caption' => array('type' => 'string'),
		),
		'required' => array('type', 'level', 'id', 'url', 'html', 'text', 'caption'),
		'additionalProperties' => false,
        );

        if ($mode === 'structured_blocks') {
            // Structured Blocks Mode (plugin shape): sections[].blocks
            $base_props['sections'] = array(
                'type'  => 'array',
                'items' => array(
                    'type'       => 'object',
                    'properties' => array(
                        'heading'             => array('type' => 'string'),
                        'blocks'              => array(
                            'type'  => 'array',
                            'items' => $block_item,
                        ),
                        // Optional (some providers still emit this)
                        'bodyhtml'            => array('type' => 'string'),
                        'body_html'           => array('type' => 'string'),
'verification_status' => array('type' => 'string'),
		),
		'required' => array('heading', 'blocks', 'bodyhtml', 'body_html', 'verification_status'),
		'additionalProperties' => false,
                ),
            );

            $required = array('headline', 'primary_keyword', 'sections', 'social_assets');
        } else {
            // Token Matcher Mode (sections[].bodyhtml)
            $base_props['sections'] = array(
                'type'  => 'array',
                'items' => array(
                    'type'       => 'object',
                    'properties' => array(
                        'heading'             => array('type' => 'string'),
                        // IMPORTANT: prompts + pipeline expect bodyhtml
                        'bodyhtml'            => array('type' => 'string'),
                        // Accept alias (optional) for tolerance, but DO NOT require it
                        'body_html'           => array('type' => 'string'),
                        'verification_status' => array('type' => 'string'),
                        // Optional: allow blocks to exist without failing parsing (but not required here)
                        'blocks'              => array(
                            'type'  => 'array',
'items' => $block_item,
		),
	),
	'required' => array('heading', 'bodyhtml', 'body_html', 'verification_status', 'blocks'),
	'additionalProperties' => false,
                ),
            );

            $required = array('headline', 'primary_keyword', 'sections', 'social_assets');
        }

        return array(
            'type'                 => 'object',
            'properties'           => $base_props,
            'required'             => $required,
            'additionalProperties' => false,
        );
    }

    /**
     * Gemini responseSchema (OpenAPI-like) for generationConfig.responseSchema.
     *
     * @param string $mode Placement mode.
     * @return array
     */
    public static function gemini_article_schema(string $mode = 'token_matcher'): array
    {
        $base_props = array(
            'headline'         => array('type' => 'STRING'),
            'dek'              => array('type' => 'STRING'),
            'category'         => array('type' => 'STRING'),
            'vertical'         => array('type' => 'STRING'),
            'meta_description' => array('type' => 'STRING'),
            'primary_keyword'  => array('type' => 'STRING'),
            'tags'             => array(
                'type'  => 'ARRAY',
                'items' => array('type' => 'STRING'),
            ),
            'sources'          => array(
                'type'  => 'ARRAY',
                'items' => array(
                    'type'       => 'OBJECT',
                    'properties' => array(
                        'title' => array('type' => 'STRING'),
                        'url'   => array('type' => 'STRING'),
                    ),
		'required' => array('url'),
                ),
            ),
            'source_snippets'  => array(
                'type'  => 'ARRAY',
                'items' => array('type' => 'STRING'),
            ),
            'social_assets'    => array(
                'type'       => 'OBJECT',
                'properties' => array(
                    'urdu_heading'     => array('type' => 'STRING'),
                    'urdu_description' => array('type' => 'STRING'),
                    'hashtags'         => array(
                        'type'        => 'ARRAY',
                        'description' => 'List of relevant hashtags. MUST BE IN ENGLISH ONLY.',
                        'items'       => array('type' => 'STRING'),
                    ),
                ),
		'required' => array('urdu_heading', 'urdu_description'),
            ),
        );

        $block_item = array(
            'type'       => 'OBJECT',
            'properties' => array(
                'type'    => array('type' => 'STRING'),
                'level'   => array('type' => 'INTEGER'),
                'id'      => array('type' => 'INTEGER'),
                'url'     => array('type' => 'STRING'),
                'html'    => array('type' => 'STRING'),
                'text'    => array('type' => 'STRING'),
                'caption' => array('type' => 'STRING'),
            ),
		'required' => array('type'),
        );

        if ($mode === 'structured_blocks') {
            // Structured blocks in this plugin: sections[].blocks
            $base_props['sections'] = array(
                'type'  => 'ARRAY',
                'items' => array(
                    'type'       => 'OBJECT',
                    'properties' => array(
                        'heading'             => array('type' => 'STRING'),
                        'blocks'              => array(
                            'type'  => 'ARRAY',
                            'items' => $block_item,
                        ),
                        // Optional tolerance
                        'bodyhtml'            => array('type' => 'STRING'),
                        'body_html'           => array('type' => 'STRING'),
                        'verification_status' => array('type' => 'STRING'),
                    ),
		'required' => array('heading', 'blocks'),
                ),
            );

            $required = array('headline', 'primary_keyword', 'sections', 'social_assets');
        } else {
            // Token matcher: sections[].bodyhtml
            $base_props['sections'] = array(
                'type'  => 'ARRAY',
                'items' => array(
                    'type'       => 'OBJECT',
                    'properties' => array(
                        'heading'             => array('type' => 'STRING'),
                        'bodyhtml'            => array('type' => 'STRING'),
                        'body_html'           => array('type' => 'STRING'),
                        'verification_status' => array('type' => 'STRING'),
                        // Optional tolerance
                        'blocks'              => array(
                            'type'  => 'ARRAY',
                            'items' => $block_item,
                        ),
                    ),
		'required' => array('heading', 'bodyhtml'),
                ),
            );

            $required = array('headline', 'primary_keyword', 'sections', 'social_assets');
        }

        return array(
            'type'       => 'OBJECT',
            'properties' => $base_props,
            'required'   => $required,
        );
    }
}
