<?php

/**
 * Topic Research Admin Handling
 *
 * @package DIT_TrendStudio
 */

namespace DIT\TrendStudio\Admin;

use DIT\TrendStudio\Content\TrendInterpreter;
use DIT\TrendStudio\Infrastructure\Logger;
use DIT\TrendStudio\Core\Plugin;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Handles the Topic Research page and AJAX endpoints.
 */
class Topic_Research_Admin
{
    /**
     * @var TrendInterpreter
     */
    private $researcher;

    /**
     * @var Logger
     */
    private $logger;

    /**
     * @var string Primary AI strategy ('gemini'|'custom').
     */
    private $strategy;

    public function __construct(TrendInterpreter $researcher, Logger $logger, string $strategy = 'gemini')
    {
        $this->researcher = $researcher;
        $this->logger = $logger;
        $this->strategy = $strategy;
    }

    /**
     * Initialize hooks
     */
    public function init()
    {
        add_action('admin_menu', [$this, 'add_menu_item'], 20);
        add_action('wp_ajax_dit_ts_research_topic', [$this, 'handle_research_topic']);
        add_action('wp_ajax_dit_ts_generate_strategy', [$this, 'handle_generate_strategy']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
    }

    /**
     * Add "Topic Research" to admin menu
     */
    public function add_menu_item()
    {
        add_submenu_page(
            'dit-trend-studio',
            'Topic Strategy Lab',
            'Topic Strategy',
            'manage_options',
            'dit-ts-topic-research',
            [$this, 'render_page']
        );
    }

    /**
     * Enqueue JS/CSS
     */
    public function enqueue_assets($hook)
    {
        // Check for our specific page hook
        if (strpos($hook, 'dit-ts-topic-research') === false) {
            return;
        }

        wp_enqueue_style(
            'dit-ts-topic-research',
            DIT_TS_PLUGIN_URL . 'assets/css/topic-research.css',
            ['dit-ts-admin'], // Depend on main admin css
            Plugin::get_instance()->get_asset_version('assets/css/topic-research.css')
        );

        wp_enqueue_script('jquery');
    }

    /**
     * Render the admin page
     */
    public function render_page()
    {
        // @MODIFIED 2026-01-29 - Fixed path to src/Admin/Views
        include DIT_TS_PLUGIN_DIR . 'src/Admin/Views/view-topic-research.php';
    }

    /**
     * DATA_SOURCE_LIMITATION: Using Google Autocomplete as proxy for Trends
     */

    /**
     * AJAX: Research Topic
     */
    public function handle_research_topic()
    {
        check_ajax_referer('dit_ts_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        $topic = sanitize_text_field($_POST['topic']);
        if (empty($topic)) {
            wp_send_json_error('Topic is required');
        }

        try {
            $results = $this->researcher->research_topic($topic);

            if (empty($results)) {
                wp_send_json_error('No results found. AI might be busy.');
            }

            wp_send_json_success($results);
        } catch (\DIT\TrendStudio\AI_Exception $e) {
            $ctx = $e->get_context();
            $this->logger->warning("Topic Research AI_Exception, attempting fallback: " . $e->getMessage(), $ctx);

            // Build fallback chain — try other providers before giving up.
            $fallback_config = \get_option('dit_ts_custom_fallback_config', []);
            if (\is_string($fallback_config)) {
                $fallback_config = \json_decode($fallback_config, true) ?: [];
            }

            $primary_id = ($this->strategy === 'custom') ? '' : '';

            $chain = \DIT\TrendStudio\Infrastructure\AI_Provider_Factory::build_fallback_chain(
                $this->strategy,
                $primary_id,
                $fallback_config
            );

            foreach ($chain as $entry) {
                // @MODIFIED 2026-07-14 - Honor RPD quarantine: skip providers paused by Quota_Pause_Manager
                // so a quarantined Gemini (or custom) provider is never retried within the fallback chain.
                $fb_slug = ($entry['strategy'] === 'custom') ? $entry['provider_id'] : $entry['strategy'];
                if (class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Pause_Manager')
                    && \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::is_paused($fb_slug)) {
                    $this->logger->info("Topic Strategy Lab fallback skipping paused (quarantined) provider '{$entry['provider_id']}'.");
                    continue;
                }
                try {
                    $fb_input = [
                        'strategy_override' => $entry['strategy'],
                        'custom_provider_id' => $entry['provider_id'],
                    ];
                    $client = \DIT\TrendStudio\Infrastructure\AI_Provider_Factory::create(
                        $entry['strategy'],
                        $this->logger,
                        $fb_input
                    );
                    $fallback_researcher = new \DIT\TrendStudio\Content\TrendInterpreter($client, $this->logger);
                    $fb_results = $fallback_researcher->research_topic($topic);

                    if (!empty($fb_results)) {
                        $this->logger->info("Topic Research fallback succeeded via provider '{$entry['provider_id']}'");
                        wp_send_json_success($fb_results);
                    }

                    $this->logger->warning("Topic Research fallback returned empty for '{$entry['provider_id']}'");
                } catch (\Exception $fb_e) {
                    $this->logger->warning("Topic Research fallback failed for '{$entry['provider_id']}': " . $fb_e->getMessage());
                    continue;
                }
            }

            // No fallback providers available — pass through original error.
            if (empty($chain)) {
                $this->logger->error("Topic Research failed — no fallback providers configured.");
                wp_send_json_error('Topic Research failed: ' . $e->getMessage());
            } else {
                $this->logger->error("Topic Research failed, all fallback providers exhausted.");
                wp_send_json_error('Topic Research failed (all fallback providers exhausted): ' . $e->getMessage());
            }
        } catch (\Throwable $e) {
            $this->logger->error("Topic Research Error: " . $e->getMessage() . "\n" . $e->getTraceAsString());
            wp_send_json_error('System Error: ' . $e->getMessage());
        }
    }

    /**
     * AJAX: Generate Strategy
     */
    public function handle_generate_strategy()
    {
        check_ajax_referer('dit_ts_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        // We receive the full node object from the frontend selection
        $raw_json = stripslashes($_POST['niche_data']);
        $this->logger->info("Strategy Request Raw: " . substr($raw_json, 0, 100) . "..."); // Log first 100 chars

        $niche_data = isset($_POST['niche_data']) ? json_decode($raw_json, true) : [];

        if (json_last_error() !== JSON_ERROR_NONE) {
            $this->logger->error("JSON Decode Error: " . json_last_error_msg());
            wp_send_json_error('Invalid topic data structure');
        }

        if (empty($niche_data)) {
            $this->logger->error("Strategy Error: Empty niche data");
            wp_send_json_error('Invalid topic data');
        }

        try {
            $strategy = $this->researcher->generate_strategy($niche_data);

            if (empty($strategy)) {
                $this->logger->error("Strategy Generation returned empty result.");
                wp_send_json_error('Failed to generate strategy (AI returned empty).');
            }

            wp_send_json_success($strategy);
        } catch (\DIT\TrendStudio\AI_Exception $e) {
            $ctx = $e->get_context();
            $this->logger->warning("Strategy AI_Exception, attempting fallback: " . $e->getMessage(), $ctx);

            // Build fallback chain — try other providers before giving up.
            $fallback_config = \get_option('dit_ts_custom_fallback_config', []);
            if (\is_string($fallback_config)) {
                $fallback_config = \json_decode($fallback_config, true) ?: [];
            }

            $primary_id = ($this->strategy === 'custom')
                ? ($niche_data['custom_provider_id'] ?? '')
                : '';

            $chain = \DIT\TrendStudio\Infrastructure\AI_Provider_Factory::build_fallback_chain(
                $this->strategy,
                $primary_id,
                $fallback_config
            );

            foreach ($chain as $entry) {
                // @MODIFIED 2026-07-14 - Honor RPD quarantine: skip providers paused by Quota_Pause_Manager
                // so a quarantined Gemini (or custom) provider is never retried within the fallback chain.
                $fb_slug = ($entry['strategy'] === 'custom') ? $entry['provider_id'] : $entry['strategy'];
                if (class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Pause_Manager')
                    && \DIT\TrendStudio\Infrastructure\Quota_Pause_Manager::is_paused($fb_slug)) {
                    $this->logger->info("Topic Strategy Lab fallback skipping paused (quarantined) provider '{$entry['provider_id']}'.");
                    continue;
                }
                try {
                    $fb_input = [
                        'strategy_override' => $entry['strategy'],
                        'custom_provider_id' => $entry['provider_id'],
                    ];
                    $client = \DIT\TrendStudio\Infrastructure\AI_Provider_Factory::create(
                        $entry['strategy'],
                        $this->logger,
                        $fb_input
                    );
                    $fallback_researcher = new \DIT\TrendStudio\Content\TrendInterpreter($client, $this->logger);
                    $result = $fallback_researcher->generate_strategy($niche_data);

                    if (!empty($result)) {
                        $this->logger->info("Strategy fallback succeeded via provider '{$entry['provider_id']}'");
                        wp_send_json_success($result);
                    }

                    $this->logger->warning("Strategy fallback returned empty for '{$entry['provider_id']}'");
                } catch (\Exception $fb_e) {
                    $this->logger->warning("Strategy fallback failed for '{$entry['provider_id']}': " . $fb_e->getMessage());
                    continue;
                }
            }

            // No fallback providers available — pass through original error.
            if (empty($chain)) {
                $this->logger->error("Strategy Generation failed — no fallback providers configured.");
                wp_send_json_error('Strategy generation failed: ' . $e->getMessage());
            } else {
                $this->logger->error("Strategy Generation failed, all fallback providers exhausted.");
                wp_send_json_error('Strategy generation failed (all fallback providers exhausted): ' . $e->getMessage());
            }
        } catch (\Throwable $e) {
            $this->logger->error("Strategy Exception: " . $e->getMessage() . "\n" . $e->getTraceAsString());
            wp_send_json_error('System Error: ' . $e->getMessage());
        }
    }
}
