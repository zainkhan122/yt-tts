<?php
/**
 * DIT Video Module — Brand
 *
 * Reads the SAME branding DIT uses for its social collages so the video shares
 * the logo, brand name/bar text, and Urdu font — without duplicating config.
 * All reads are guarded (get_option with safe defaults); never writes.
 *
 * @package DIT\TrendStudio\Video
 */

namespace DIT\TrendStudio\Video;

if (!defined('ABSPATH')) {
    exit;
}

class Brand
{
    /**
     * Resolve the brand logo as a local file path (if any).
     * Reads DIT's brand logo attachment id + brand bar text.
     */
    public function logo_path(): string
    {
        $logo_id = (int) get_option('dit_ts_brand_logo_id', 0);
        if ($logo_id) {
            $file = get_attached_file($logo_id);
            if ($file && file_exists($file)) {
                return $file;
            }
        }
        return '';
    }

    /**
     * The brand/bar text shown on the video's bottom bar.
     */
    public function brand_text(): string
    {
        $text = trim((string) get_option('dit_ts_brand_bar_text', ''));
        if ($text !== '') {
            return $text;
        }
        $site = get_bloginfo('name');
        return $site !== '' ? $site : 'Daily InfoTainment';
    }

    /**
     * Resolve the Urdu font file used by DIT's social collage generator.
     * Prefers Noto Nastaliq Urdu (RTL shaping) — matches DIT assets/fonts.
     */
    public function urdu_font_path(): string
    {
        $fonts_dir = DIT_TS_PLUGIN_DIR . 'assets/fonts/';

        $configured = trim((string) get_option('dit_ts_social_font', ''));
        if ($configured !== '' && file_exists($fonts_dir . basename($configured))) {
            return $fonts_dir . basename($configured);
        }

        $preferred = array(
            'NotoNastaliqUrdu-Regular.ttf',
            'NotoNastaliqUrdu-Medium.ttf',
            'NotoSansArabic-Regular.ttf',
        );
        foreach ($preferred as $f) {
            if (file_exists($fonts_dir . $f) && is_readable($fonts_dir . $f)) {
                return $fonts_dir . $f;
            }
        }
        $fonts = glob($fonts_dir . '*.ttf') ?: array();
        foreach ($fonts as $path) {
            if (is_readable($path)) {
                return $path;
            }
        }
        return '';
    }

    /**
     * A Latin/Roman font for the brand bar text (falls back to a bundled font).
     */
    public function latin_font_path(): string
    {
        $dir = DIT_TS_PLUGIN_DIR . 'assets/fonts/';
        foreach (array('Inter-Bold.ttf', 'Roboto-Bold.ttf', 'EBGaramond-Bold.ttf') as $f) {
            if (file_exists($dir . $f)) {
                return $dir . $f;
            }
        }
        return $this->urdu_font_path();
    }
}
