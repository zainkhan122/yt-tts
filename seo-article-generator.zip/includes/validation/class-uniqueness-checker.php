<?php

/**
 * Uniqueness Checker
 *
 * Compares new articles against recently published articles to detect
 * template-based content that could trigger Google's doorway page penalties.
 *
 * @package SEO_Article_Generator
 * @since   2.2.0
 */

namespace SEO_Article_Generator\Validation;

// Prevent direct access.
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Detects cross-article similarity using n-gram shingling.
 *
 * Uses Jaccard similarity on 5-word shingles to measure overlap.
 * High overlap suggests template-based generation.
 */
class Uniqueness_Checker
{
    /**
     * Minimum uniqueness score (0-100) required to pass.
     * Now delegated to Threshold_Config for mode-awareness.
     */

    /**
     * Number of recent articles to compare against.
     *
     * @var int
     */
    private const COMPARISON_LIMIT = 10;

    /**
     * Shingle size (n-gram length in words).
     *
     * @var int
     */
    private const SHINGLE_SIZE = 5;

    /**
     * Check article uniqueness against recent posts.
     *
     * @param string $new_content New article HTML content.
     * @param int    $limit       Number of recent posts to compare (default: 10).
     * @return array [
     *     'uniqueness_score' => float,      // 0-100 (higher = more unique)
     *     'passed' => bool,                 // true if score >= MIN_UNIQUENESS
     *     'most_similar_post_id' => int,    // ID of most similar post
     *     'most_similar_title' => string,   // Title of most similar post
     *     'overlap_percentage' => float,    // % of shingles shared
     * ]
     */
    public static function check(string $new_content, int $limit = self::COMPARISON_LIMIT): array
    {
        // Get recent seo-gen posts
        $recent_posts = get_posts([
            'post_type' => 'post',
            'posts_per_page' => $limit,
            'meta_key' => '_seo_gen_article',
            'meta_value' => '1',
            'orderby' => 'date',
            'order' => 'DESC',
        ]);

        // Get mode-aware threshold
	$mode = 'blog';
        $cfg = Threshold_Config::get($mode);
        $min_uniqueness = $cfg['uniqueness']['pass_threshold'] ?? 55;

        // No comparison possible if no previous posts
        if (empty($recent_posts)) {
            return [
                'uniqueness_score' => 100.0,
                'passed' => true,
                'most_similar_post_id' => 0,
                'most_similar_title' => '',
                'overlap_percentage' => 0.0,
            ];
        }

        // Strip structural scaffolding (headings, labels) to focus on unique content
        $new_stripped = self::strip_scaffolding($new_content);
        $new_text = wp_strip_all_tags($new_stripped);
        $new_shingles = self::get_shingles($new_text, self::SHINGLE_SIZE);

        // No shingles = very short content, consider unique
        if (empty($new_shingles)) {
            return [
                'uniqueness_score' => 100.0,
                'passed' => true,
                'most_similar_post_id' => 0,
                'most_similar_title' => '',
                'overlap_percentage' => 0.0,
            ];
        }

        $max_overlap = 0.0;
        $most_similar_id = 0;
        $most_similar_title = '';

        foreach ($recent_posts as $post) {
            $existing_stripped = self::strip_scaffolding($post->post_content);
            $existing_text = wp_strip_all_tags($existing_stripped);
            $existing_shingles = self::get_shingles($existing_text, self::SHINGLE_SIZE);

            if (empty($existing_shingles)) {
                continue;
            }

            $overlap = self::jaccard_similarity($new_shingles, $existing_shingles);

            if ($overlap > $max_overlap) {
                $max_overlap = $overlap;
                $most_similar_id = $post->ID;
                $most_similar_title = $post->post_title;
            }
        }

        $uniqueness = 100.0 - ($max_overlap * 100.0);

        return [
            'uniqueness_score' => round($uniqueness, 1),
            'passed' => $uniqueness >= $min_uniqueness,
            'most_similar_post_id' => $most_similar_id,
            'most_similar_title' => $most_similar_title,
            'overlap_percentage' => round($max_overlap * 100, 1),
        ];
    }

    /**
     * Get minimum uniqueness threshold.
     *
     * @return int Threshold percentage (0-100).
     */
    public static function get_threshold(): int
    {
	$mode = 'blog';
        $cfg = Threshold_Config::get($mode);
        return $cfg['uniqueness']['pass_threshold'] ?? 55;
    }

    /**
     * Generate word n-gram shingles from text.
     *
     * @param string $text Raw text.
     * @param int    $n    Shingle size (words).
     * @return array Unique shingles.
     */
    private static function get_shingles(string $text, int $n): array
    {
        // Normalize: lowercase, remove excessive whitespace
        $text = strtolower(preg_replace('/\s+/', ' ', trim($text)));

        // Remove common stop words to reduce false positives
        $stop_words = ['the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been', 
                       'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 
                       'would', 'could', 'should', 'may', 'might', 'must', 'can',
                       'this', 'that', 'these', 'those', 'it', 'its', 'and', 'or',
                       'but', 'if', 'then', 'than', 'so', 'as', 'for', 'of', 'to',
                       'in', 'on', 'at', 'by', 'with', 'from', 'up', 'down', 'out'];
        
        $words = preg_split('/\s+/', $text);
        $words = array_filter($words, function($word) use ($stop_words) {
            return strlen($word) > 2 && !in_array($word, $stop_words, true);
        });
        $words = array_values($words); // Re-index

        if (count($words) < $n) {
            return [];
        }

        $shingles = [];
        for ($i = 0; $i <= count($words) - $n; $i++) {
            $shingles[] = implode(' ', array_slice($words, $i, $n));
        }

        return array_unique($shingles);
    }

    /**
     * Calculate Jaccard similarity coefficient between two shingle sets.
     *
     * @param array $a First shingle set.
     * @param array $b Second shingle set.
     * @return float Similarity (0.0 = no overlap, 1.0 = identical).
     */
    private static function jaccard_similarity(array $a, array $b): float
    {
        $intersection = count(array_intersect($a, $b));
        $union = count(array_unique(array_merge($a, $b)));

        if ($union === 0) {
            return 0.0;
        }

        return $intersection / $union;
    }

    /**
     * Strip common scaffolding (headings, labels) that triggers false duplicates.
     *
     * @param string $html Content HTML.
     * @return string Content with scaffolding removed.
     */
    private static function strip_scaffolding(string $html): string
    {
        $common_labels = [
            'Table of Contents',
            'System Requirements',
            'Technical Specifications',
            'Features',
            'Installation Guide',
            'Conclusion',
            'FAQ',
            'Frequently Asked Questions',
            'Download',
            'Pros and Cons',
            'Safety',
            'Overview',
            'What\'s New',
            'Description',
            'Key Features',
        ];

        // Remove these phrases when they appear in headings or isolated blocks
        $cleaned = $html;
        foreach ($common_labels as $label) {
            // Remove from tags like <h2>Label</h2> or <strong>Label</strong>
            $cleaned = preg_replace('/<[hH][1-6][^>]*>\s*' . preg_quote($label, '/') . '\s*<\/[hH][1-6]>/i', '', $cleaned);
            $cleaned = preg_replace('/<strong[^>]*>\s*' . preg_quote($label, '/') . '\s*<\/strong>/i', '', $cleaned);
        }

        return $cleaned;
    }
}
