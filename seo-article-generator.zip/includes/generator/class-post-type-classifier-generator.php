<?php
namespace SEO_Article_Generator\Generator;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
Zero files across the repo use or call PostTypeClassifier. All callers use TypeClassifier directly. The wrapper has a hardcoded relative path __DIR__ . '/../discovery/class-post-type-classifier.php' that will silently fail if the file is placed anywhere other than includes/generator/.
**/

final class Post_Type_Classifier {

	public const TYPE_NEW           = 'new';
	public const TYPE_LEGACY        = 'legacy';
	public const TYPE_PLUGIN        = 'plugingenerated';
	public const TYPE_PLUGIN_LEGACY = 'plugingeneratedlegacy';

	private static function ensure_canonical_loaded(): void {
		if ( ! class_exists( '\\SEO_Article_Generator\\Discovery\\Post_Type_Classifier', false ) ) {
			require_once __DIR__ . '/../discovery/class-post-type-classifier.php';
		}
	}

	public static function classify( int $post_id ): string {
		self::ensure_canonical_loaded();
		return \SEO_Article_Generator\Discovery\Post_Type_Classifier::classify( $post_id );
	}

	public static function is_plugin_owned( string $type ): bool {
		self::ensure_canonical_loaded();
		return \SEO_Article_Generator\Discovery\Post_Type_Classifier::is_plugin_owned( $type );
	}

	public static function label( string $type ): string {
		self::ensure_canonical_loaded();
		return \SEO_Article_Generator\Discovery\Post_Type_Classifier::label( $type );
	}
}