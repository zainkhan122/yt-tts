<?php

namespace SEO_Article_Generator\AI\Providers;

use SEO_Article_Generator\AI_Exception;
use SEO_Article_Generator\AI\AI_Rate_Limit_Exception;
use SEO_Article_Generator\AI\API_Error_Parser;
use SEO_Article_Generator\AI\API_Error_Info;
use SEO_Article_Generator\AI\JSON_Recovery;

if (! defined('ABSPATH')) {
	exit;
}

/**
 * Gemini AI Provider
 *
 * @since 2.13.5
 */
class Gemini_Provider extends Abstract_Provider
{
	/**
	 * API Endpoint
	 * @var string
	 */
	private $endpoint;

	/**
	 * Model override for scout operations
	 * @var string|null
	 */
	private $model_override = null;

	/**
	 * Constructor
	 *
	 * @param string $api_key
	 * @param \SEO_Article_Generator\Logger $logger
	 * @param \SEO_Article_Generator\AI\AI_Client $ai_client
	 */
	public function __construct($api_key, $logger, $ai_client)
	{
		parent::__construct($api_key, $logger, $ai_client);

		$model = \SEO_Article_Generator\AI\AI_Client::get_gemini_model();
		$this->endpoint = \SEO_Article_Generator\AI\AI_Client::get_gemini_endpoint($model);
	}

	public function override_model(string $model): void
	{
		$this->model_override = $model;
		$this->endpoint = \SEO_Article_Generator\AI\AI_Client::get_gemini_endpoint($model);
	}

	public function reset_model_override(): void
	{
		$this->model_override = null;
		$this->endpoint = \SEO_Article_Generator\AI\AI_Client::get_gemini_endpoint(
			\SEO_Article_Generator\AI\AI_Client::get_gemini_model()
		);
	}

	/**
	 * Resolve the active model from override, fallback-injected key, or primary option.
	 *
	 * FIX: AI_Client fallback loop sets '_resolved_model' (underscore prefix).
	 * Previously this method checked 'resolved_model' (no prefix) — a key mismatch
	 * that caused the fallback model to be silently ignored.
	 *
	 * @param array $prompt_data
	 * @return string
	 */
	private function resolve_model(array $prompt_data): string
	{
		if ($this->model_override !== null) {
			return $this->model_override;
		}
		// FIX: match the key AI_Client::generate_article() actually writes
		if (!empty($prompt_data['_resolved_model'])) {
			return (string) $prompt_data['_resolved_model'];
		}
		return \SEO_Article_Generator\AI\AI_Client::get_gemini_model();
	}

	/**
	 * Attempt intra-Gemini model chain fallback for any API error.
	 * Returns the recursive result if a next model exists, otherwise throws an AI_Exception.
	 *
	 * @param array  $prompt_data
	 * @param string $currentModel
	 * @param string $exceptionMessage
	 * @return array
	 * @throws AI_Exception
	 */
	private function intra_fallback_or_throw(array $prompt_data, string $currentModel, string $exceptionMessage): array
	{
		$fallbackEnabled = (bool) \get_option('seo_gen_gemini_fallback', 0);
		if ($fallbackEnabled) {
			$fallbackModel = \SEO_Article_Generator\AI\AI_Client::get_gemini_model(true, $currentModel);
			if ($fallbackModel !== $currentModel && $fallbackModel !== null) {
				$hopCount = (int) ($prompt_data['_gemini_fallback_depth'] ?? 0);
				$this->logger->info("Gemini fallback — hop {$hopCount}: {$currentModel} → {$fallbackModel}");
				$this->model_override = $fallbackModel;
				$prompt_data['_gemini_fallback_depth'] = $hopCount + 1;
				$prompt_data['_resolved_model'] = $fallbackModel;
				return $this->generate_article($prompt_data);
			}
		}
		throw new AI_Exception($exceptionMessage);
	}

/**
 * Determine whether the google_search grounding tool is supported for a given model.
 *
 * All currently routed Gemini registry models use the v1beta endpoint tier.
 * Keep this denylist-based guard so future custom or preview models can be
 * blocked from grounding until explicitly verified.
 *
 * @param string $model
 * @return bool
 */
private function model_supports_grounding(string $model): bool
{
$no_grounding = array(
// Reserved for future unconfirmed or preview models
);
return ! \in_array($model, $no_grounding, true);
}

	/**
	 * Generate article
	 *
	 * @param array $prompt_data
	 * @return array
	 * @throws AI_Exception
	 */
	public function generate_article(array $prompt_data): array
	{
try {
$model = $this->resolve_model($prompt_data);
$endpoint = \SEO_Article_Generator\AI\AI_Client::get_gemini_endpoint($model);

// Extract API version from endpoint path
$version = \parse_url($endpoint, PHP_URL_PATH);
$version = $version ? (\ltrim(\explode('/models/', $version)[0] ?? 'v1', '/')) : 'v1';
$is_beta = ($version === 'v1beta');

$context = $prompt_data['_generation_context'] ?? null;
$enable_web_search = $context ? $context->needs_search() : (bool) \get_option('seo_gen_enable_web_search', true);

// Guard: disable web search for models that don't support grounding
if ($enable_web_search && ! $this->model_supports_grounding($model)) {
$this->logger->info(
"Grounding disabled for model {$model} (not confirmed supported on {$version} tier)."
);
$enable_web_search = false;
}

// v1beta is always used; always use the correct snake_case key
$sys_key = 'system_instruction';

        // FIX: Respect scout payloads - short-circuit heavy Prompt_Builder for lightweight update checks
        $system_text = !empty($prompt_data['_scout_call']) && !empty($prompt_data['system'])
            ? (string) $prompt_data['system']
            : \SEO_Article_Generator\Generator\Prompt_Builder::build_system_prompt(array(
                'enable_web_search' => $enable_web_search,
                'focus_keyword' => $prompt_data['focus_keyword'] ?? '',
            ));

        $request_body = array(
            $sys_key => array(
                'parts' => array(
                    array(
                        'text' => $system_text,
                    ),
                ),
            ),
				'contents' => array(
					array(
						'parts' => array(
							array(
								'text' => $this->build_prompt($prompt_data),
							),
						),
					),
				),
				'generationConfig' => array(
					'temperature' => 0.2,
					'topK' => 40,
					'topP' => 0.95,
					'maxOutputTokens' => 32768,
				),
			);

	if (! $enable_web_search) {
		$request_body['generationConfig']['responseMimeType'] = 'application/json';
	}

// Grounding tools are only attached when the resolved endpoint tier supports them.
if ($enable_web_search && $is_beta) {
$request_body['tools'] = array(
array('google_search' => new \stdClass()),
);
}

			$this->last_raw_prompt = \wp_json_encode($request_body, JSON_PRETTY_PRINT);

			if (\function_exists('wp_raise_memory_limit')) {
				\wp_raise_memory_limit('admin');
			}

			$response = $this->ai_client->execute_safe_request(
				"{$endpoint}?key={$this->api_key}",
				array(
					'timeout' => 180,
					'headers' => array('Content-Type' => 'application/json'),
					'body' => \wp_json_encode($request_body),
				),
				'gemini',
				$model
			);

        if (\is_wp_error($response)) {
            $error_code = $response->get_error_code();
            $error_message = $response->get_error_message();

            if ($error_code === 'rate_limit') {
                $error_data = $response->get_error_data();
                if (! \is_array($error_data)) {
                    $error_data = array();
                }
                $error_info = isset($error_data['error_info']) && $error_data['error_info'] instanceof API_Error_Info
                    ? $error_data['error_info'] : null;

                $should_fallback = $error_info !== null
                    && $error_info->recommended_action() === API_Error_Info::ACTION_ROUTE_NEXT;

                $fallbackEnabled = (bool) \get_option('seo_gen_gemini_fallback', 0);
                if ($should_fallback && $fallbackEnabled) {
                    $fallbackModel = \SEO_Article_Generator\AI\AI_Client::get_gemini_model(true, $model);
                    if ($fallbackModel !== $model) {
                        // Intra-provider hopping is now unlimited (bounded by the chain
                        // itself) so Gemini walks every configured model before the outer
                        // AI_Client cross-provider fallback takes over.
                        $hopCount = (int) ($prompt_data['_gemini_fallback_depth'] ?? 0);
                        $this->logger->info("Gemini rate limit ({$error_info->get_error_type()}) — hop {$hopCount}: {$model} → {$fallbackModel}");
                        $this->model_override = $fallbackModel;
                        $prompt_data['_gemini_fallback_depth'] = $hopCount + 1;
                        $prompt_data['_resolved_model'] = $fallbackModel;
                        return $this->generate_article($prompt_data);
                    }
                }
                throw new AI_Rate_Limit_Exception($error_message, 429, $error_data);
            }

            return $this->intra_fallback_or_throw($prompt_data, $model, 'HTTP request failed: ' . $error_message);
        }

        $status_code = \wp_remote_retrieve_response_code($response);
        $body = \wp_remote_retrieve_body($response);
        $this->last_raw_response = $body;

        if (429 === (int) $status_code) {
            $error_info = API_Error_Parser::parse('gemini', 429, $body);

            $should_fallback = $error_info->recommended_action() === API_Error_Info::ACTION_ROUTE_NEXT;

            $fallbackEnabled = (bool) \get_option('seo_gen_gemini_fallback', 0);
            if ($should_fallback && $fallbackEnabled) {
                $fallbackModel = \SEO_Article_Generator\AI\AI_Client::get_gemini_model(true, $model);
                if ($fallbackModel !== $model) {
                    $hopCount = (int) ($prompt_data['_gemini_fallback_depth'] ?? 0);
                    $this->logger->info("Gemini 429 ({$error_info->get_error_type()}) — hop {$hopCount}: {$model} → {$fallbackModel}");
                    $this->model_override = $fallbackModel;
                    $prompt_data['_gemini_fallback_depth'] = $hopCount + 1;
                    $prompt_data['_resolved_model'] = $fallbackModel;
                    return $this->generate_article($prompt_data);
                }
            }

            throw new AI_Rate_Limit_Exception(
                "Gemini rate limit: {$error_info->get_message()}",
                429,
                array('error_info' => $error_info)
            );
        }

			if (200 !== $status_code) {
				return $this->intra_fallback_or_throw($prompt_data, $model, "AI service error (HTTP {$status_code}).");
			}

			$data = \json_decode($body, true);

			if (! \is_array($data) || empty($data['candidates']) || ! \is_array($data['candidates'])) {
				return $this->intra_fallback_or_throw($prompt_data, $model, 'AI returned empty response or error.');
			}

			$candidate = $data['candidates'][0];
			$finish_reason = $candidate['finishReason'] ?? 'UNKNOWN';

			$non_retryable = array('SAFETY', 'RECITATION', 'PROHIBITED_CONTENT', 'SPII');
			if (\in_array($finish_reason, $non_retryable, true)) {
				return $this->intra_fallback_or_throw($prompt_data, $model, 'Generation blocked by safety filters (' . $finish_reason . ').');
			}

			$text = '';
			if (isset($candidate['content']['parts']) && \is_array($candidate['content']['parts'])) {
				foreach ($candidate['content']['parts'] as $part) {
					if (isset($part['text'])) {
						$text .= $part['text'];
					}
				}
			}

			if ($text === '') {
				return $this->intra_fallback_or_throw($prompt_data, $model, 'AI returned empty content (reason: ' . $finish_reason . ').');
			}

			if (\preg_match('/```(?:json)?\s*([\s\S]*?)```/i', $text, $m)) {
				$text = $m[1];
			}

			$trimmed = \trim($text);
			if (! \preg_match('/^[\{\[]/', $trimmed)) {
				$start = \strpos($trimmed, '{');
				$end = \strrpos($trimmed, '}');
				if ($start !== false && $end !== false && $end > $start) {
					$text = \substr($trimmed, $start, $end - $start + 1);
				}
			}

		// DEBUG: Log raw response before JSON recovery
		if ($this->logger) {
			$this->logger->debug('Gemini provider JSON payload preview', [
				'provider' => 'gemini',
				'model' => $model,
				'length' => strlen($text),
				'preview' => substr($text, 0, 500),
			]);
		}

		try {
			$article_data = JSON_Recovery::decode($text, 'gemini', $this->logger);
		} catch (\Throwable $e) {
			if ($this->logger) {
				$this->logger->error('Gemini provider JSON decode failed', [
					'provider' => 'gemini',
					'model' => $model,
					'error' => $e->getMessage(),
					'raw_content' => $text,
				]);
			}
			throw $e;
		}

		$article_data = $this->strip_citations_recursive($article_data);

		$article_data['_provider_meta'] = array(
			'provider' => 'gemini',
			'model' => $model,
			'software' => $prompt_data['software_name'] ?? 'unknown',
			'timestamp' => \SEO_Article_Generator\Utils\Plugin_Time::utc_mysql_now(),
		);

		if (isset($candidate['groundingMetadata'])) {
				$grounding = $candidate['groundingMetadata'];
				$article_data['_grounding_metadata'] = array(
					'web_search_used' => ! empty($grounding['webSearchQueries']),
					'query_count' => isset($grounding['webSearchQueries']) ? \count($grounding['webSearchQueries']) : 0,
					'support_count' => isset($grounding['groundingSupports']) ? \count($grounding['groundingSupports']) : 0,
				);
			}

		return $article_data;
		} catch (AI_Exception $e) {
			throw $e;
		} catch (\Exception $e) {
			throw new AI_Exception($e->getMessage());
		}
	}

	/**
	 * Test connection
	 *
	 * @return array
	 * @throws AI_Exception
	 */
	public function test_connection()
	{
		$request_body = array(
			'contents'         => array(
				array(
					'parts' => array(
						array('text' => 'Return JSON: {"status": "ok", "test": true}'),
					),
				),
			),
			'generationConfig' => array(
				'maxOutputTokens'  => 100,
				'responseMimeType' => 'application/json',
			),
		);

		$response = $this->ai_client->execute_safe_request(
			"{$this->endpoint}?key={$this->api_key}",
			array(
				'timeout' => 30,
				'headers' => array('Content-Type' => 'application/json'),
				'body'    => wp_json_encode($request_body),
			),
			'gemini'
		);

		if (is_wp_error($response)) {
			throw new AI_Exception('Connection test failed: ' . $response->get_error_message());
		}

		return array(
			'success'     => true,
			'provider'    => 'gemini',
			'status_code' => 200,
		);
	}

    private function build_prompt($prompt_data)
    {
        // FIX: Short-circuit heavy article generation logic for lightweight update discovery
        if (!empty($prompt_data['_scout_call']) && !empty($prompt_data['user'])) {
            return (string) $prompt_data['user'];
        }
        $prompt_builder = new \SEO_Article_Generator\Generator\Prompt_Builder();
        $context = $prompt_data['_generation_context'] ?? null;
        return $prompt_builder->build_full_instruction_set($prompt_data, $context);
    }
}