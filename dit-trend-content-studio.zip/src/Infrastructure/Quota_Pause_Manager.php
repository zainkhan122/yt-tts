<?php

/**
 * Quota Pause Manager
 *
 * Centralizes provider quota pauses with adaptive error-classification.
 * Instead of rigid hardcoded thresholds, the system classifies API errors
 * by severity and adjusts its response accordingly:
 *
 * - rpm_burst:   Short-lived per-minute rate bump → back off 2-5 min, no pause
 * - rpm_sustained: Repeated per-minute hits → escalate to short pause
 * - daily_quota:  Genuine daily exhaustion → pause until reset window
 * - quota_zero:   Hard quota=0 (plan/model mismatch) → terminal, no retry
 *
 * The system learns from consecutive error patterns: a single transient 429
 * never locks the system. Only sustained, confirmed exhaustion triggers a pause.
 *
 * @package DIT_TrendStudio
 * @since 2.15.11
 * @MODIFIED 2026-04-22 - Adaptive error-classification engine replaces rigid thresholds.
 */

namespace DIT\TrendStudio\Infrastructure;

if (!defined('ABSPATH')) {
    exit;
}

class Quota_Pause_Manager
{
    const META_VERSION = 2;

    /**
     * Classify a 429/403 error from an API response into an adaptive category.
     *
     * Gemini returns structured JSON like:
     * {
     *   "error": {
     *     "code": 429,
     *     "status": "RESOURCE_EXHAUSTED",
     *     "details": [
     *       { "@type": "RetryDelay", "retryDelay": "60s" },
     *       { "@type": "QuotaFailure", "violations": [{
     *           "quotaMetric": "generativelanguage.googleapis.com/generate_content_free_tier_requests",
     *           "quotaId": "GenerateContentFreeTierRequestsPerDayPerProjectPerModel"
     *       }]}
     *     ]
     *   }
     * }
     *
     * This method parses that structure to determine the TRUE nature of the error.
     *
     * @param int $http_code HTTP status code
     * @param string $raw_body Raw response body
     * @param string $provider_slug Provider identifier
     * @return array {
     *   @type string $class       Error class: 'rpm_burst' | 'rpm_sustained' | 'daily_quota' | 'quota_zero' | 'unknown_429'
     *   @type string $reason      Machine-readable reason for pause system
     *   @type int    $suggested_delay Seconds the API suggests we wait (0 if not provided)
     *   @type string $metric      The quota metric name (e.g. 'generate_content_free_tier_requests')
     *   @type string $quota_id    The quota ID from the violation details
     *   @type bool   $is_daily    True if this is a per-day (RPD) quota, not per-minute (RPM)
     *   @type string $raw_status  The error.status field from JSON (e.g. 'RESOURCE_EXHAUSTED')
     * }
     */
    public static function classify_api_error(int $http_code, string $raw_body, string $provider_slug = 'gemini'): array
    {
        $lower = strtolower($raw_body);
        $parsed = json_decode($raw_body, true);
        $error = $parsed['error'] ?? [];

        $result = [
            'class' => 'unknown_429',
            'reason' => 'rate_limit_retry',
            'suggested_delay' => 0,
            'metric' => '',
            'quota_id' => '',
            'is_daily' => false,
            'raw_status' => (string) ($error['status'] ?? ''),
        ];

        // Extract structured details from JSON
        $details = (array) ($error['details'] ?? []);
        $retry_delay = 0;
        $violations = [];

        foreach ($details as $detail) {
            $type = $detail['@type'] ?? '';

            // Extract retryDelay
            if (stripos($type, 'RetryDelay') !== false && isset($detail['retryDelay'])) {
                $retry_delay = (int) $detail['retryDelay'];
            }

            // Extract QuotaFailure violations
            if (stripos($type, 'QuotaFailure') !== false && !empty($detail['violations'])) {
                foreach ($detail['violations'] as $v) {
                    $violations[] = [
                        'metric' => (string) ($v['quotaMetric'] ?? ''),
                        'id' => (string) ($v['quotaId'] ?? ''),
                    ];
                }
            }

            // Extract ErrorInfo with metadata (alternative format)
            if (stripos($type, 'ErrorInfo') !== false) {
                $domain = strtolower($detail['domain'] ?? '');
                $reason_str = strtolower($detail['reason'] ?? '');
                if (strpos($domain, 'quota') !== false || strpos($reason_str, 'quota') !== false) {
                    $violations[] = [
                        'metric' => (string) ($detail['metadata']['quota_metric'] ?? $detail['metadata']['service'] ?? ''),
                        'id' => (string) ($detail['metadata']['quota_id'] ?? ''),
                    ];
                }
            }
        }

        $result['suggested_delay'] = $retry_delay;

        // Also check Retry-After header equivalent in body
        if ($retry_delay === 0 && isset($error['retryDelay'])) {
            $result['suggested_delay'] = (int) $error['retryDelay'];
        }

        // Analyze violations to classify the error
        if (!empty($violations)) {
            $metric = strtolower($violations[0]['metric']);
            $quota_id = strtolower($violations[0]['id']);
            $result['metric'] = $violations[0]['metric'];
            $result['quota_id'] = $violations[0]['id'];

            // Detect DAILY quota (RPD) vs MINUTE quota (RPM) from quota ID patterns
            $is_rpd = (strpos($quota_id, 'perday') !== false
                || strpos($quota_id, 'per_day') !== false
                || strpos($quota_id, '_rpd') !== false
                || strpos($quota_id, 'daily') !== false);

            $is_rpm = (strpos($quota_id, 'perminute') !== false
                || strpos($quota_id, 'per_minute') !== false
                || strpos($quota_id, '_rpm') !== false
                || strpos($quota_id, 'minute') !== false);

            // Also detect from metric name patterns
            if (!$is_rpd && !$is_rpm) {
                $is_rpd = (strpos($metric, 'requests_per_day') !== false
                    || strpos($metric, 'perday') !== false
                    || strpos($lower, 'requests per day') !== false);
                $is_rpm = (strpos($metric, 'requests_per_minute') !== false
                    || strpos($metric, 'perminute') !== false);
            }

            $result['is_daily'] = $is_rpd;

            // Check for quota=0 (hard block — plan/model mismatch)
            if (strpos($lower, 'limit: 0') !== false && !$is_rpd) {
                $result['class'] = 'quota_zero';
                $result['reason'] = 'model_quota_zero';
                return $result;
            }

            if ($is_rpd) {
                $result['class'] = 'daily_quota';
                $result['reason'] = 'daily_quota_exhausted';
            } elseif ($is_rpm) {
                // RPM hit — check if it's sustained or a single burst
                $consecutive = self::get_consecutive_rpm_429s($provider_slug);
                if ($consecutive >= 2) {
                    $result['class'] = 'rpm_sustained';
                    $result['reason'] = 'rpm_sustained';
                } else {
                    $result['class'] = 'rpm_burst';
                    $result['reason'] = 'rpm_burst';
                }
            } else {
                // Can't determine quota type from structured data — fall back to body heuristics
                $result['class'] = self::classify_by_body_heuristics($lower, $provider_slug);
                $result['reason'] = ($result['class'] === 'daily_quota') ? 'daily_quota_exhausted' : 'rate_limit_retry';
            }
        } else {
            // No structured violations — use body heuristics
            $result['class'] = self::classify_by_body_heuristics($lower, $provider_slug);
            $result['reason'] = ($result['class'] === 'daily_quota') ? 'daily_quota_exhausted' : 'rate_limit_retry';
        }

        return $result;
    }

    /**
     * Fallback classification using body text patterns when structured data is unavailable.
     */
    private static function classify_by_body_heuristics(string $lower_body, string $provider_slug): string
    {
        $has_daily_signal = (
            strpos($lower_body, 'generate_content_free_tier_requests') !== false
            || strpos($lower_body, 'requests per day') !== false
            || strpos($lower_body, 'requests_per_day') !== false
            || (strpos($lower_body, 'rpd') !== false && strpos($lower_body, 'quota') !== false)
        );

        $has_quota_signal = (
            strpos($lower_body, 'quota') !== false
            || strpos($lower_body, 'resource_exhausted') !== false
            || strpos($lower_body, 'exceeded') !== false
            || strpos($lower_body, 'daily quota reached') !== false
        );

        $has_zero_limit = (strpos($lower_body, 'limit: 0') !== false);

        if ($has_zero_limit && !$has_daily_signal) {
            return 'quota_zero';
        }

        if ($has_daily_signal && $has_quota_signal) {
            return 'daily_quota';
        }

        if ($has_quota_signal && !$has_daily_signal) {
            // Generic quota error — could be RPM or something else
            $consecutive = self::get_consecutive_rpm_429s($provider_slug);
            return ($consecutive >= 2) ? 'rpm_sustained' : 'rpm_burst';
        }

        // Just a plain 429 with no quota details — treat as RPM burst
        return 'rpm_burst';
    }

    /**
     * Adaptively handle a 429/403 error based on its classified type.
     *
     * This is the main entry point called from API clients. It replaces
     * the old pattern of immediately calling pause() on every 429.
     *
     * @param string $provider_slug
     * @param int $http_code
     * @param string $raw_body
     * @return array {
     *   @type string $class       Error class from classify_api_error()
     *   @type string $reason      Machine-readable reason
     *   @type bool   $pause_activated Whether a full pause was set
     *   @type int    $until       Pause-until timestamp (0 if no pause)
     *   @type int    $retry_after Suggested seconds before next attempt
     *   @type int    $consecutive Current consecutive error count for this class
     *   @type string $action      'pause' | 'backoff' | 'terminal'
     * }
     */
    public static function handle_429(string $provider_slug, int $http_code, string $raw_body): array
    {
        $provider_slug = sanitize_key($provider_slug);
        $classification = self::classify_api_error($http_code, $raw_body, $provider_slug);

        $result = [
            'class' => $classification['class'],
            'reason' => $classification['reason'],
            'pause_activated' => false,
            'until' => 0,
            'retry_after' => $classification['suggested_delay'],
            'consecutive' => 0,
            'action' => 'backoff',
            'metric' => $classification['metric'] ?? '',
        ];

        switch ($classification['class']) {
            case 'quota_zero':
                // Hard block — no amount of retrying helps. Terminal.
                $result['action'] = 'terminal';
                $result['reason'] = 'model_quota_zero';
                break;

            case 'daily_quota':
                // Daily quota — track consecutive daily-quota 429s.
                // First occurrence: just backoff (could be transient).
                // Second: confidence building.
                // Third+: confirmed daily exhaustion → pause until reset.
                $key = "dit_ts_{$provider_slug}_consecutive_daily_quota_429s";
                $count = (int) get_transient($key);
                $count++;
                set_transient($key, $count, 12 * HOUR_IN_SECONDS);
                $result['consecutive'] = $count;

                // Adaptive threshold: if the API gave us a suggested delay > 5min,
                // it's likely genuine daily exhaustion — activate pause sooner.
                $adaptive_threshold = ($classification['suggested_delay'] >= 300) ? 2 : 3;

                if ($count >= $adaptive_threshold) {
                    $result['until'] = self::pause($provider_slug, 'daily_quota_exhausted', 3600, 86400);
                    $result['pause_activated'] = true;
                    $result['action'] = 'pause';
                    delete_transient($key);
                } else {
                    // Not yet confirmed — back off with increasing delay
                    $result['retry_after'] = max($classification['suggested_delay'], 120 * $count);
                    $result['action'] = 'backoff';
                    $result['reason'] = 'daily_quota_candidate';
                }
                break;

            case 'rpm_sustained':
                // Repeated RPM hits — short pause to let the minute window reset
                $rpm_key = "dit_ts_{$provider_slug}_consecutive_rpm_429s";
                $rpm_count = (int) get_transient($rpm_key);
                $rpm_count++;
                set_transient($rpm_key, $rpm_count, 5 * MINUTE_IN_SECONDS);
                $result['consecutive'] = $rpm_count;

                if ($rpm_count >= 3) {
                    // 3+ consecutive RPM hits → short 5-10 min pause
                    $pause_seconds = min(600, 120 * $rpm_count);
                    $result['until'] = self::pause_until($provider_slug, time() + $pause_seconds, 'rpm_sustained', 900);
                    $result['pause_activated'] = true;
                    $result['action'] = 'pause';
                    $result['retry_after'] = $pause_seconds;
                } else {
                    $result['retry_after'] = max($classification['suggested_delay'], 60);
                    $result['action'] = 'backoff';
                }
                break;

            case 'rpm_burst':
            default:
                // Single transient rate bump — just back off, no pause
                $rpm_key = "dit_ts_{$provider_slug}_consecutive_rpm_429s";
                $rpm_count = (int) get_transient($rpm_key);
                $rpm_count++;
                set_transient($rpm_key, $rpm_count, 5 * MINUTE_IN_SECONDS);
                $result['consecutive'] = $rpm_count;

                $result['retry_after'] = max($classification['suggested_delay'], 30);
                $result['action'] = 'backoff';
                break;
        }

        return $result;
    }

    /**
     * Reset all consecutive error counters on a successful API response.
     * This is the key to the adaptive system: any success clears the streak,
     * so transient blips never escalate to a full pause.
     *
     * @MODIFIED 2026-04-22
     */
    public static function reset_consecutive_on_success(string $provider_slug): void
    {
        $provider_slug = sanitize_key($provider_slug);
        delete_transient("dit_ts_{$provider_slug}_consecutive_daily_quota_429s");
        delete_transient("dit_ts_{$provider_slug}_consecutive_rpm_429s");
    }

    // ─── Legacy compatibility methods ──────────────────────────────────

    /**
     * Get pause reason for a provider.
     */
    public static function get_reason(string $provider_slug): string
    {
        $provider_slug = sanitize_key($provider_slug);
        return (string) get_option("dit_ts_{$provider_slug}_quota_pause_reason", '');
    }

    /**
     * Get stored reset-at timestamp (when known) for a provider.
     */
    public static function get_reset_at(string $provider_slug): int
    {
        $provider_slug = sanitize_key($provider_slug);
        return (int) get_option("dit_ts_{$provider_slug}_quota_reset_at", 0);
    }

    /**
     * Get pause-until timestamp for a provider.
     */
 public static function get_pause_until(string $provider_slug): int
 {
 $provider_slug = sanitize_key($provider_slug);
 $ts = (int) get_option("dit_ts_{$provider_slug}_quota_pause_until", 0);
 if ($ts > 0 && time() < $ts) {
 return $ts;
 }

        if ($ts > 0 && time() >= $ts) {
            delete_option("dit_ts_{$provider_slug}_quota_pause_until");
            delete_option("dit_ts_{$provider_slug}_quota_pause_reason");
            delete_transient("dit_ts_{$provider_slug}_quota_pause_level");

            if (function_exists('as_has_scheduled_action') && !as_has_scheduled_action('dit_ts_quota_probe', array($provider_slug))) {
                if (function_exists('as_schedule_single_action')) {
                    as_schedule_single_action(time() + 60, 'dit_ts_quota_probe', array($provider_slug));
                }
            }
        }

 return 0;
 }

    /**
     * Pause provider until a fixed timestamp.
     */
    public static function pause_until(string $provider_slug, int $until_ts, string $reason = 'quota', int $max_seconds = 86400): int
    {
        $provider_slug = sanitize_key($provider_slug);
        $reason = sanitize_key($reason);

        $now = time();
        if ($until_ts <= $now) {
            $until_ts = $now + 900;
        }

        $cap = $now + max(3600, (int) $max_seconds);
        if ($until_ts > $cap) {
            $until_ts = $cap;
        }

 update_option("dit_ts_{$provider_slug}_quota_pause_until", (int) $until_ts, false);
 update_option("dit_ts_{$provider_slug}_quota_pause_reason", $reason, false);

 if ($provider_slug === 'gemini') {
 delete_transient('dit_ts_gemini_quota_pause');
 delete_transient('dit_ts_gemini_daily_quota_exhausted');
 }

 return (int) $until_ts;
    }

    /**
     * Is provider currently paused?
     */
 public static function is_paused(string $provider_slug): bool
 {
 $until = self::get_pause_until($provider_slug);
 if ($until > 0 && time() < $until) {
 return true;
 }

 if ($provider_slug === 'gemini') {
 delete_transient('dit_ts_gemini_quota_pause');
 delete_transient('dit_ts_gemini_daily_quota_exhausted');
 }

 return false;
 }

    /**
     * Pause provider with exponential backoff.
     * For Gemini daily_quota_exhausted, pauses until midnight PT.
     * @MODIFIED 2026-05-05 - Day-boundary reset for pause_level prevents yesterday's
     * accumulated backoff from poisoning today's transient 429s.
     */
    public static function pause(string $provider_slug, string $reason = 'quota', int $base_seconds = 3600, int $max_seconds = 86400): int
    {
        $provider_slug = sanitize_key($provider_slug);
        $reason = sanitize_key($reason);

        if (
            $provider_slug === 'gemini'
            && $reason === 'daily_quota_exhausted'
            && class_exists('DIT\\TrendStudio\\Infrastructure\\Quota_Reset_Calculator')
        ) {
            $reset_at = \DIT\TrendStudio\Infrastructure\Quota_Reset_Calculator::gemini_next_rpd_reset_ts(time());
            $until = $reset_at + 120;
            update_option('dit_ts_gemini_quota_reset_at', (int) $reset_at, false);
            return self::pause_until('gemini', (int) $until, 'daily_quota_exhausted', 2 * 86400);
        }

        $level_key = "dit_ts_{$provider_slug}_quota_pause_level";
        $level = (int) get_transient($level_key);
        $level = max(0, $level);

        $last_pause_day = (int) get_transient("dit_ts_{$provider_slug}_quota_pause_day");
        $today_key = self::quota_day_key($provider_slug);
        if ($last_pause_day !== 0 && $last_pause_day !== $today_key) {
            $level = 0;
            delete_transient($level_key);
        }
        set_transient("dit_ts_{$provider_slug}_quota_pause_day", $today_key, 36 * HOUR_IN_SECONDS);

        $level++;

        $seconds = (int) min($max_seconds, $base_seconds * (2 ** min(6, ($level - 1))));
        $until = time() + $seconds;

        set_transient($level_key, $level, $max_seconds + 600);
 update_option("dit_ts_{$provider_slug}_quota_pause_until", $until, false);
 update_option("dit_ts_{$provider_slug}_quota_pause_reason", $reason, false);
 delete_option("dit_ts_{$provider_slug}_quota_reset_at");

 if ($provider_slug === 'gemini') {
 delete_transient('dit_ts_gemini_quota_pause');
 delete_transient('dit_ts_gemini_daily_quota_exhausted');
 }

 return $until;
    }

    /**
     * Clear provider pause and all error counters.
     * @MODIFIED 2026-05-05 - Also clear legacy per-provider quota_pause transient
     * and day-boundary tracking to prevent phantom stale state.
     */
    public static function clear(string $provider_slug): void
    {
        $provider_slug = sanitize_key($provider_slug);

        delete_transient("dit_ts_{$provider_slug}_quota_pause_level");
        delete_option("dit_ts_{$provider_slug}_quota_pause_until");
        delete_option("dit_ts_{$provider_slug}_quota_pause_reason");
        delete_option("dit_ts_{$provider_slug}_quota_reset_at");
        delete_transient("dit_ts_{$provider_slug}_consecutive_daily_quota_429s");
        delete_transient("dit_ts_{$provider_slug}_consecutive_rpm_429s");
        delete_transient("dit_ts_{$provider_slug}_quota_pause");
        delete_transient("dit_ts_{$provider_slug}_quota_pause_day");

        if ($provider_slug === 'gemini') {
            delete_transient('dit_ts_gemini_quota_pause');
            delete_transient('dit_ts_gemini_daily_quota_exhausted');
        }
    }

    /**
     * Compute a day-key integer for the provider's quota day boundary.
     * Gemini resets at midnight Pacific; others at midnight UTC.
     * @MODIFIED 2026-05-05
     */
    private static function quota_day_key(string $provider_slug): int
    {
        if ($provider_slug === 'gemini') {
            try {
                $pt = new \DateTimeZone('America/Los_Angeles');
                return (int) (new \DateTimeImmutable('now', $pt))->format('Ymd');
            } catch (\Throwable $e) {
                return (int) gmdate('Ymd');
            }
        }
        return (int) gmdate('Ymd');
    }

    // ─── Backward-compat aliases ──────────────────────────────────────

    public static function record_daily_quota_429(string $provider_slug, string $reason = 'daily_quota_exhausted', int $base_seconds = 3600, int $max_seconds = 86400, int $threshold = 3): array
    {
        $key = "dit_ts_{$provider_slug}_consecutive_daily_quota_429s";
        $count = (int) get_transient($key);
        $count++;
        set_transient($key, $count, 12 * HOUR_IN_SECONDS);

        $pause_activated = false;
        $until = 0;

        if ($count >= $threshold) {
            $until = self::pause($provider_slug, $reason, $base_seconds, $max_seconds);
            $pause_activated = true;
            delete_transient($key);
        }

        return [
            'count' => $count,
            'pause_activated' => $pause_activated,
            'until' => $until,
        ];
    }

    public static function reset_consecutive_daily_quota_429s(string $provider_slug): void
    {
        self::reset_consecutive_on_success($provider_slug);
    }

    public static function get_consecutive_daily_quota_429s(string $provider_slug): int
    {
        $provider_slug = sanitize_key($provider_slug);
        return (int) get_transient("dit_ts_{$provider_slug}_consecutive_daily_quota_429s");
    }

    public static function get_consecutive_rpm_429s(string $provider_slug): int
    {
        $provider_slug = sanitize_key($provider_slug);
        return (int) get_transient("dit_ts_{$provider_slug}_consecutive_rpm_429s");
    }
}
