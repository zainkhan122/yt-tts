<?php

/**
 * Shortcode Manager
 *
 * @version 2.1 - Removed all inline styles for Dark Mode compatibility.
 *
 * @MODIFIED: Removed all `style="..."` attributes from shortcode HTML.
 * @MODIFIED: Replaced them with CSS classes (e.g., .nm-subscribe-form).
 * @MODIFIED: Updated inline JS to use .addClass()/.removeClass() for messages.
 * @MODIFIED: Added .nm-btn classes to [mcq_start_quiz] button.
 */

if (! defined('ABSPATH')) {
	exit;
}

class NM_Shortcode_Manager
{


	/**
	 * Initialize all hooks.
	 */
	public static function init()
	{
		// Register all shortcodes
		add_shortcode('nm_subscribe_form', array(self::class, 'render_subscribe_form'));
		add_shortcode('display_mcqs', array(self::class, 'render_display_mcqs'));
		add_shortcode('mcq_start_quiz', array(self::class, 'render_start_quiz'));
		// ✅ NEW: Register the dark mode toggle shortcode
		add_shortcode('nm_dark_mode_toggle', array(self::class, 'render_dark_mode_toggle'));
		// @NEW 9.2.0: Latest News shortcode (drop on homepage/any page)
		add_shortcode('nm_latest_news', array(self::class, 'render_latest_news'));
		// @NEW 9.5.2: Dynamic "Related Practice MCQs" block for generated articles/pillars.
		// Resolves PUBLISHED MCQs at render time — no stale baked links, no 404s.
		add_shortcode('nm_related_mcqs', array(self::class, 'render_related_mcqs'));
		// Register the AJAX handler for the subscription form
		add_action('wp_ajax_nm_subscribe_user', array(self::class, 'ajax_subscribe_user'));
		add_action('wp_ajax_nopriv_nm_subscribe_user', array(self::class, 'ajax_subscribe_user'));

		// Enqueue assets only when shortcodes are used
		add_action('wp_enqueue_scripts', array(self::class, 'enqueue_frontend_assets'));
	}

	/**
	 * Enqueue assets for shortcodes.
	 */
	public static function enqueue_frontend_assets()
	{
		global $post;
		// @FIX 9.2.0: Asset enqueue previously only fired when the shortcode was
		// directly in $post->post_content. If used via a widget, block, theme
		// template, or a homepage with the shortcode injected elsewhere, CSS/JS never
		// loaded. Now we also enqueue when the shortcode was rendered at all (flag set
		// in render_display_mcqs) or on the front page.
		$has_display_mcqs = false;
		$has_start_quiz   = false;

		if (is_a($post, 'WP_Post')) {
			$has_display_mcqs = has_shortcode($post->post_content, 'display_mcqs');
			$has_start_quiz   = has_shortcode($post->post_content, 'mcq_start_quiz');
		}

		if (! empty($GLOBALS['nm_has_mcq_shortcode'])) {
			$has_display_mcqs = true;
		}
		if (is_front_page() || is_home()) {
			$has_display_mcqs = $has_display_mcqs || has_shortcode(get_the_content(), 'display_mcqs');
		}

		// Enqueue general frontend styles if either quiz shortcode is present
		// Enqueue general frontend styles if either quiz shortcode is present
		if ($has_display_mcqs || $has_start_quiz) {

			// Global/navigation + variables (colors, backgrounds, etc.)
			if (! wp_style_is('nm-top-nav', 'enqueued')) {
				wp_enqueue_style(
					'nm-top-nav',
					NM_MCQ_GENERATOR_URL . 'assets/css/top-nav.css',
					array(),
					filemtime(NM_PLUGIN_PATH . 'assets/css/top-nav.css')
				);
			}

			// Core MCQ card styling (shared everywhere)
			if (! wp_style_is('nm-mcq-styles', 'enqueued')) {
				wp_enqueue_style(
					'nm-mcq-styles',
					NM_MCQ_GENERATOR_URL . 'assets/css/frontend.css',
					array(),
					filemtime(NM_PLUGIN_PATH . 'assets/css/frontend.css')
				);
			}

			// Topic/Exam card enhancements (EEAT box, hover effects, etc.)
			if (! wp_style_is('nm-taxonomy-topic', 'enqueued')) {
				wp_enqueue_style(
					'nm-taxonomy-topic',
					NM_MCQ_GENERATOR_URL . 'assets/css/taxonomy-topic.css',
					array('nm-mcq-styles'),
					filemtime(NM_PLUGIN_PATH . 'assets/css/taxonomy-topic.css')
				);
			}

			// Behaviour (answer selection, feedback, buttons) – same as Topic/Exam
			if (! wp_script_is('nm-mcq-scripts', 'enqueued')) {
				wp_enqueue_script(
					'nm-mcq-scripts',
					NM_MCQ_GENERATOR_URL . 'assets/js/frontend.js',
					array('jquery'),
					filemtime(NM_PLUGIN_PATH . 'assets/js/frontend.js'),
					true
				);

				wp_localize_script(
					'nm-mcq-scripts',
					'nm_mcq_ajax_object',
					array(
						'ajax_url'          => admin_url('admin-ajax.php'),
						'nonce'             => wp_create_nonce('nm_mcq_nonce'),
						'is_user_logged_in' => is_user_logged_in() ? 'yes' : 'no',
					)
				);
			}
		}
		// Enqueue quiz modal assets only if [mcq_start_quiz] is present
		if ($has_start_quiz) {
			if (! wp_style_is('nm-quiz-styles', 'enqueued')) {
				wp_enqueue_style('nm-quiz-styles', NM_MCQ_GENERATOR_URL . 'assets/css/quiz-frontend.css', array(), filemtime(NM_PLUGIN_PATH . 'assets/css/quiz-frontend.css'));
			}
			if (! wp_script_is('nm-quiz-scripts', 'enqueued')) {
				wp_enqueue_script('nm-quiz-scripts', NM_MCQ_GENERATOR_URL . 'assets/js/quiz-frontend.js', array('jquery'), filemtime(NM_PLUGIN_PATH . 'assets/js/quiz-frontend.js'), true);

				wp_localize_script(
					'nm-quiz-scripts',
					'nm_quiz_object',
					array(
						'ajax_url'          => admin_url('admin-ajax.php'),
						'rest_url'          => get_rest_url(null, 'nm-mcq/v1'),
						'nonce'             => wp_create_nonce('nm_quiz_nonce'),
						'is_user_logged_in' => is_user_logged_in() ? 'yes' : 'no',
					)
				);
			}
		}
	}

	/**
	 * AJAX handler for the subscription form.
	 *
	 * @MODIFIED v7.3.15: Accept both nm_subscribe_form_nonce and nm_auth_nonce for compatibility
	 */
	public static function ajax_subscribe_user()
	{
		// ✅ FIX: Accept both nonces (shortcode form uses nm_subscribe_form_nonce, bell uses nm_auth_nonce)
		$nonce_valid = false;
		if (isset($_POST['nonce'])) {
			if (wp_verify_nonce($_POST['nonce'], 'nm_subscribe_form_nonce')) {
				$nonce_valid = true;
			} elseif (wp_verify_nonce($_POST['nonce'], 'nm_auth_nonce')) {
				$nonce_valid = true;
			}
		}

		if (! $nonce_valid) {
			wp_send_json_error(array('message' => 'Security check failed. Please refresh the page.'));
		}

		$ip = NM_Security_Manager::get_client_ip();
		if (! NM_Security_Manager::check_rate_limit('subscribe_attempt', $ip, 5, HOUR_IN_SECONDS)) {
			NM_Response_Handler::error('Too many attempts. Please try again in an hour.');
		}
		// ✅ END FIX

		if (empty($_POST['email'])) {
			wp_send_json_error(array('message' => 'Email is required'));
		}

		$email = sanitize_email(trim($_POST['email']));
		$name  = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : '';

		if (! is_email($email)) {
			wp_send_json_error(array('message' => 'Invalid email address'));
		}

		if (! class_exists('NM_Email_Digest')) {
			wp_send_json_error(array('message' => 'Subscription service is unavailable.'));
		}

		$result = NM_Email_Digest::add_subscriber($email, $name, true);

		if ($result['success']) {
			wp_send_json_success(array('message' => $result['message']));
		} else {
			wp_send_json_error(array('message' => $result['message']));
		}
	}

	/**
	 * Renders the [nm_subscribe_form] shortcode.
	 * ✅ REMOVED all inline styles
	 */
	/**
	 * Renders the [nm_subscribe_form] shortcode.
	 *
	 * @MODIFIED v7.3.1: Changed default title from "Weekly MCQs" to "Daily MCQs"
	 *                   to accurately reflect the actual email delivery schedule
	 *                   (verified in class-nm-cron-manager.php:179 - cron runs daily)
	 */
	public static function render_subscribe_form($atts)
	{
		// ✅ START FIX: Create Nonce
		$nonce = wp_create_nonce('nm_subscribe_form_nonce');
		// ✅ END FIX

		$atts = shortcode_atts(
			array(
				'title'       => '📧 Subscribe for Daily MCQs', // ✅ MODIFIED v7.3.1: Changed from "Weekly MCQs" to "Daily MCQs"
				'description' => 'Get fresh MCQs delivered to your inbox',
			),
			$atts
		);

		ob_start();
?>
		<div class="nm-subscribe-form nm-widget-wrapper">
			<h3><?php echo esc_html($atts['title']); ?></h3>
			<p><?php echo esc_html($atts['description']); ?></p>

			<form id="nm-subscribe-form-<?php echo uniqid(); ?>" class="nm-subscribe-form-ajax" data-nonce="<?php echo esc_attr($nonce); ?>">
				<input type="email" name="email" placeholder="Your email address" required>
				<button type="submit" class="nm-subscribe-btn nm-btn nm-btn-primary">
					Subscribe Now
				</button>
			</form>

			<div class="nm-subscribe-message"></div>
			<p class="nm-subscribe-footer">✅ No spam. Unsubscribe anytime.</p>
		</div>

		<script>
			jQuery(function($) {
				$(document).on('submit', 'form.nm-subscribe-form-ajax', function(e) {
					e.preventDefault();
					var form = $(this);
					var email = form.find('[name="email"]').val();
					var btn = form.find('.nm-subscribe-btn').prop('disabled', true).text('Subscribing...');
					var msg = form.siblings('.nm-subscribe-message');

					// ✅ START FIX: Read nonce from form and send with AJAX
					var nonce = form.data('nonce');

					$.post('<?php echo admin_url('admin-ajax.php'); ?>', {
						action: 'nm_subscribe_user',
						email: email,
						nonce: nonce
					}, function(resp) {
						// ✅ END FIX
						if (resp.success) {
							// ✅ MODIFIED: Use classes instead of inline styles
							msg.removeClass('error').addClass('success').text(resp.data.message).show();
							form[0].reset();
						} else {
							// ✅ MODIFIED: Use classes instead of inline styles
							msg.removeClass('success').addClass('error').text(resp.data.message).show();
						}
						btn.prop('disabled', false).text('Subscribe Now');
					});
				});
			});
		</script>
	<?php
		return ob_get_clean();
	}

	/**
	 * Renders the [display_mcqs] shortcode.
	 * ✅ REMOVED old dark mode toggle HTML
	 */
	public static function render_display_mcqs($atts)
	{
		$GLOBALS['nm_has_mcq_shortcode'] = true;

		// Ensure all expected shortcode attributes exist.
		$atts = shortcode_atts(
			array(
				'count' => 10,
				'topic' => '',
				'exam'  => '',
				'tag'   => '',
			),
			$atts,
			'display_mcqs'
		);
		// If no topic/exam passed explicitly, infer from current taxonomy.
		// This lets the same taxonomy-topic.php work for Topic *and* Exam archives
		// while still rendering the first 10 MCQs server-side for SEO.
		if (empty($atts['topic']) && empty($atts['exam']) && empty($atts['tag'])) {

			// Topic taxonomy context
			if (is_tax('topic')) {
				$term = get_queried_object();
				if ($term && ! is_wp_error($term)) {
					$atts['topic'] = $term->slug;
					// ✅ Handle Subtopic Pages: Select Parent in main dropdown, Child in sub dropdown
					if ($term->parent != 0) {
						$parent_term = get_term($term->parent, 'topic');
						if ($parent_term && ! is_wp_error($parent_term)) {
							$atts['subtopic_selected'] = $term->slug;
							$atts['topic']             = $parent_term->slug; // Override for main dropdown
						}
					}
				}

				// Exam taxonomy context (nm_exam)
			} elseif (is_tax('nm_exam')) {
				$term = get_queried_object();
				if ($term && ! is_wp_error($term)) {
					$atts['exam'] = $term->slug;
				}

				// Tag taxonomy context (mcq_tag)
			} elseif (is_tax('mcq_tag')) {
				$term = get_queried_object();
				if ($term && ! is_wp_error($term)) {
					$atts['tag'] = $term->slug;
				}
			}
		}

		ob_start();
	?>
		<div id="nm-mcq-app" class="nm-mcq-container">
			<div class="nm-quiz-header">
				<?php
				$topics_cache_key = 'top_level_topics';
				$top_level_topics = NM_Cache_Manager::get($topics_cache_key);
				if ($top_level_topics === false) {
					$top_level_topics = get_terms(
						array(
							'taxonomy'   => 'topic',
							'hide_empty' => true,
							'parent'     => 0,
						)
					);
					NM_Cache_Manager::set($topics_cache_key, $top_level_topics, 21600);
				}

				// Load all exam terms (non-hierarchical nm_exam taxonomy)
				$exam_terms = get_terms(
					array(
						'taxonomy'   => 'nm_exam',
						'hide_empty' => true,
						'orderby'    => 'name',
						'order'      => 'ASC',
					)
				);

				// Apply admin-selected visibility for homepage exams
				$visible_exam_slugs = get_option('nm_homepage_exam_visibility', array());
				if (! is_array($visible_exam_slugs)) {
					$visible_exam_slugs = array();
				}

				$filtered_exam_terms = array();

				if (is_wp_error($exam_terms) || empty($exam_terms)) {
					$filtered_exam_terms = array();
				} elseif (! empty($visible_exam_slugs)) {
					// Keep only exams whose slug is in the visibility list, preserving that order
					$exam_terms_by_slug = array();
					foreach ($exam_terms as $term) {
						$exam_terms_by_slug[$term->slug] = $term;
					}
					foreach ($visible_exam_slugs as $slug) {
						if (isset($exam_terms_by_slug[$slug])) {
							$filtered_exam_terms[] = $exam_terms_by_slug[$slug];
						}
					}
				} else {
					// No explicit visibility set: show all exams with MCQs
					$filtered_exam_terms = $exam_terms;
				}

				// Context-aware filter visibility
				$is_topic_archive = is_tax('topic');
				$is_exam_archive  = is_tax('nm_exam');
				$filtered_topics  = is_array($top_level_topics) ? $top_level_topics : array();
				?>

				<?php if ((! empty($filtered_topics) && ! $is_exam_archive) || (! $is_topic_archive && ! empty($filtered_exam_terms))) : ?>
					<div class="nm-filters-wrapper">

						<?php if (! $is_exam_archive && ! empty($filtered_topics)) : ?>
							<div class="nm-topic-filter-wrapper">
								<label for="nm-topic-filter">Topic:</label>
								<select id="nm-topic-filter">
									<option value=""><?php echo esc_html__('All Topics', 'wp-news-mcq-generator'); ?></option>
									<?php foreach ($filtered_topics as $topic_term) : ?>
										<option value="<?php echo esc_attr($topic_term->slug); ?>"
											data-id="<?php echo esc_attr($topic_term->term_id); ?>"
											<?php selected($atts['topic'], $topic_term->slug); ?>>
											<?php echo esc_html($topic_term->name); ?>
										</option>
									<?php endforeach; ?>
								</select>
							</div>

							<?php
							// Pre-populate subtopics if a parent topic is selected
							$sub_options   = '<option value="">All Subtopics</option>';
							$show_sub_wrap = 'style="display:none;"';

							if (! empty($atts['topic'])) {
								$parent_slug = $atts['topic'];
								$parent_obj  = get_term_by('slug', $parent_slug, 'topic');
								if ($parent_obj && ! is_wp_error($parent_obj)) {
									$children = get_terms(array(
										'taxonomy'   => 'topic',
										'parent'     => $parent_obj->term_id,
										'hide_empty' => true,
									));

									if (! empty($children) && ! is_wp_error($children)) {
										$show_sub_wrap = ''; // Show wrapper
										foreach ($children as $child) {
											$is_sel = (isset($atts['subtopic_selected']) && $atts['subtopic_selected'] === $child->slug) ? 'selected' : '';
											$sub_options .= '<option value="' . esc_attr($child->slug) . '" ' . $is_sel . '>' . esc_html($child->name) . '</option>';
										}
									}
								}
							}
							?>
							<div class="nm-subtopic-filter-wrapper" <?php echo $show_sub_wrap; ?>>
								<label for="nm-subtopic-filter">Subtopic:</label>
								<select id="nm-subtopic-filter">
									<?php echo $sub_options; ?>
								</select>
							</div>
						<?php endif; ?>

						<?php if (! $is_topic_archive && ! empty($filtered_exam_terms)) : ?>
							<div class="nm-exam-filter-wrapper">
								<label for="nm-exam-filter">Exam:</label>
								<select id="nm-exam-filter">
									<option value=""><?php echo esc_html__('All Exams', 'wp-news-mcq-generator'); ?></option>
									<?php foreach ($filtered_exam_terms as $exam_term) : ?>
										<option value="<?php echo esc_attr($exam_term->slug); ?>"
											<?php selected($atts['exam'], $exam_term->slug); ?>>
											<?php echo esc_html($exam_term->name); ?>
										</option>
									<?php endforeach; ?>
								</select>
							</div>
						<?php endif; ?>

					</div>
				<?php endif; ?>

			</div>
			<?php $score_id = 'nm-home-score-' . uniqid(); ?>
			<div class="nm-score-tracker" id="<?php echo esc_attr($score_id); ?>" aria-live="polite" aria-atomic="true" style="display:none">
				<div class="nm-score-title">Your Score</div>
				<div class="nm-score-number">
					<span id="<?php echo esc_attr($score_id); ?>-correct">0</span>/<span id="<?php echo esc_attr($score_id); ?>-total">0</span>
				</div>
				<div class="nm-score-label">Correct answers</div>
			</div>
			<script>
				window.nmScoreMounts = window.nmScoreMounts || [];
				window.nmScoreMounts.push({
					boxId: '<?php echo esc_js($score_id); ?>',
					correctId: '<?php echo esc_js($score_id); ?>-correct',
					totalId: '<?php echo esc_js($score_id); ?>-total'
				});
			</script>
			<div
				class="nm-mcq-list"
				role="list"
				data-initial-count="<?php echo (int) $atts['count']; ?>"
				data-initial-topic="<?php echo esc_attr($atts['topic']); ?>"
				data-initial-exam="<?php echo esc_attr($atts['exam']); ?>"
				data-server-rendered="true">
				<?php
				if (class_exists('NM_AJAX_Frontend') && method_exists('NM_AJAX_Frontend', 'nm_get_mcqs')) {
					$mcqs_data = NM_AJAX_Frontend::nm_get_mcqs(
						array(
							'count' => intval($atts['count']),
							'topic' => $atts['topic'],
							'exam'  => $atts['exam'],
							'tag'   => $atts['tag'],
						)
					);
				} else {
					$mcqs_data = array();
				}
				if (! empty($mcqs_data)) {
					$question_num = 1;
					foreach ($mcqs_data as $mcq) {
						$post_id        = $mcq['id'];
						$question       = $mcq['question'];
						$options        = $mcq['options'];
						$correct_answer = $mcq['answer'];
						$explanation    = $mcq['explanation'];
						$permalink      = $mcq['permalink'];
						if (! is_array($options) || empty($correct_answer)) {
							continue;
						}

						// @MODIFIED v7.3.15: Unified Card Rendering
						// Now uses shared function for 100% consistency with Topic pages
						$card_data = array(
							'post_id'     => $post_id,
							'question'    => $question,
							'options'     => $options,
							'answer'      => $correct_answer,
							'explanation' => $explanation,
							'permalink'   => $permalink,
							'author'      => get_post_meta($post_id, 'mcq_author_name', true),
							'difficulty'  => get_post_meta($post_id, 'mcq_difficulty', true),
							'factchecked' => get_post_meta($post_id, 'mcq_fact_checked', true),
							'published_date' => get_the_date('d M Y', $post_id),
							'topic_name'  => '', // Homepage usually doesn't show topic badge per card, but can be added if needed
						);

						echo self::render_mcq_card($card_data, $question_num);

						++$question_num;
					}
				} else {
					echo '<div class="nm-no-mcqs">No questions available at the moment. Please check back later.</div>';
				}
				?>
			</div>
			<div class="nm-mcq-pagination"></div>
		</div>
	<?php
		return ob_get_clean();
	}

	/**
	 * ✅ NEW v7.3.15: Centralized MCQ Card Renderer
	 * Ensures identical markup for Homepage (Shortcode) and Topic Pages (AJAX)
	 */
	public static function render_mcq_card($data, $questionnum)
	{
		// Defaults
		// ✅ MODIFIED v9.0.3: Dynamic fallback
		if (! empty($data['author'])) {
			$author = esc_html($data['author']);
		} else {
			$post_author_id = get_post_field('post_author', $data['post_id']);
			$user           = get_userdata($post_author_id);
			$author         = esc_html($user ? $user->display_name : get_bloginfo('name'));
		}
		$difficulty  = ! empty($data['difficulty']) ? esc_html(ucfirst(strtolower($data['difficulty']))) : 'Medium';

		// Looser check for fact checked (handles 'yes', 'on', '1', true)
		$fc_raw      = $data['factchecked'] ?? '';
		$factchecked = ! empty($fc_raw) && ($fc_raw === 'yes' || $fc_raw === 'on' || $fc_raw == 1 || $fc_raw === true);

		$date        = ! empty($data['published_date']) ? esc_html($data['published_date']) : '';
		$topic_name  = ! empty($data['topic_name']) ? '<span class="nm-meta-badge topic">' . esc_html($data['topic_name']) . '</span>' : '';

		// Build Options HTML
		$options_html = '';
		if (! empty($data['options']) && is_array($data['options'])) {
			foreach ($data['options'] as $optKey => $optText) {
				$options_html .= '<div class="nm-mcq-option">';
				$options_html .= '<button class="nm-option-btn" data-option="' . esc_attr($optKey) . '">';
				$options_html .= '<span class="nm-option-label">' . esc_html($optKey) . '.</span>';
				$options_html .= '<span itemprop="text">' . esc_html($optText) . '</span>';
				$options_html .= '</button>';
				$options_html .= '</div>';
			}
		}

		// Build Compact Meta HTML (Badge Style)
		$eeat_html  = '<div class="nm-eat-bar compact">';

		// 1. Author
		$eeat_html .= '<div class="nm-eat-item author">';
		$eeat_html .= '<span class="nm-eat-value">By ' . $author . '</span>';
		$eeat_html .= '</div>';

		// 2. Difficulty (Badge)
		$eeat_html .= '<div class="nm-eat-separator">•</div>';
		$eeat_html .= '<div class="nm-eat-item difficulty">';
		$eeat_html .= '<span class="nm-eat-badge ' . strtolower($difficulty) . '">' . $difficulty . '</span>';
		$eeat_html .= '</div>';

		// 3. Fact Checked (if yes)
		if ($factchecked) {
			$eeat_html .= '<div class="nm-eat-separator">•</div>';
			$eeat_html .= '<div class="nm-eat-item fact-checked">';
			$eeat_html .= '<span class="dashicons dashicons-yes-alt"></span>';
			$eeat_html .= '<span class="nm-eat-value">Fact Checked</span>';
			$eeat_html .= '</div>';
		}

		// 4. Date (if available)
		if (! empty($date)) {
			$eeat_html .= '<div class="nm-eat-separator">•</div>';
			$eeat_html .= '<div class="nm-eat-item published">';
			$eeat_html .= '<span class="dashicons dashicons-calendar-alt"></span>';
			$eeat_html .= '<span class="nm-eat-value">' . $date . '</span>';
			$eeat_html .= '</div>';
		}

		$eeat_html .= '</div>';

		ob_start();
	?>
		<article class="nm-mcq-item nm-mcq-card" id="mcq-<?php echo esc_attr($data['post_id']); ?>" data-post-id="<?php echo esc_attr($data['post_id']); ?>" data-correct="<?php echo esc_attr($data['answer']); ?>" itemscope itemtype="https://schema.org/Question">
			<div class="nm-mcq-header">
				<div>
					<span class="nm-meta-badge number">#<?php echo $questionnum; ?></span>
					<?php echo $topic_name; ?>
				</div>
			</div>
			<?php echo $eeat_html; ?>
			<div class="nm-mcq-question" itemprop="text"><?php echo esc_html($data['question']); ?></div>
			<div class="nm-mcq-options"><?php echo $options_html; ?></div>
			<div class="nm-result-message"></div>
			<?php if (! empty($data['explanation'])) : ?>
				<div class="nm-explanation" style="display:none" itemprop="acceptedAnswer" itemscope itemtype="https://schema.org/Answer">
					<strong>💡 Explanation:</strong> <span itemprop="text"><?php echo esc_html($data['explanation']); ?></span>
				</div>
			<?php endif; ?>
			<div class="nm-mcq-actions">
				<button class="nm-show-answer-btn">Show Answer</button>
				<button class="nm-report-btn">Report</button>
				<button
					class="nm-comments-btn"
					data-permalink="<?php echo esc_url($data['permalink']); ?>">
					Discuss
				</button>
				<button class="nm-share-btn">Share</button>
				<?php if (! empty($data['explanation'])) : ?>
					<button class="nm-show-explanation-btn" style="display:none;">Show Explanation</button>
				<?php endif; ?>
			</div>
			<div class="nm-share-container" style="display:none;"></div>
		</article>
	<?php
		return ob_get_clean();
	}

	/**
	 * Renders the [mcq_start_quiz] shortcode.
	 */
	public static function render_start_quiz()
	{
		$GLOBALS['nm_has_mcq_shortcode'] = true;
		ob_start();
	?>
		<div class="nm-start-quiz-wrapper nm-widget-wrapper">
			<button id="nm-start-quiz-btn" class="nm-btn nm-btn-primary nm-btn-block">Start a New Quiz</button>
		</div>
		<div id="nm-quiz-modal-overlay" style="display: none;">
			<div id="nm-quiz-modal-content">
				<button id="nm-quiz-close-btn">&times;</button>
				<div id="nm-quiz-setup-pane" class="nm-quiz-pane active">
					<div class="nm-quiz-header">
						<h2 style="margin:0; color:#fff; font-size: 1.25rem;">Create Your Quiz</h2>
					</div>
					<div class="nm-quiz-body">
						<div class="nm-form-group">
							<label for="nm-quiz-topic-input">1. Choose a Topic</label>
							<!-- ✅ FIX: autocomplete="off" to prevent browser overlays interference -->
							<input type="text" id="nm-quiz-topic-input" placeholder="e.g., Capitals, Geography..." autocomplete="off">
							<input type="hidden" id="nm-quiz-topic-slug">
							<div id="nm-topic-suggestions"></div>
						</div>
						<div class="nm-form-group">
							<label for="nm-quiz-count-input">2. Number of Questions</label>
							<input type="number" id="nm-quiz-count-input" value="10" min="1" max="50">
						</div>
					</div>
					<div class="nm-quiz-footer">
						<button id="nm-generate-quiz-btn" class="button-primary" disabled>Generate Quiz</button>
					</div>
				</div>
				<div id="nm-quiz-question-pane" class="nm-quiz-pane">
					<p>Question area...</p>
				</div>
				<div id="nm-quiz-results-pane" class="nm-quiz-pane">
					<p>Results area...</p>
				</div>
			</div>
		</div>
<?php
		return ob_get_clean();
	}

	/**
	 * Renders the [nm_latest_news count="5" show_image="1" show_short="1"] shortcode.
	 * Lists the latest generated roundup articles (SEO-friendly, server-rendered).
	 */
	public static function render_latest_news($atts)
	{
		$atts = shortcode_atts(
			array(
				'count'      => 5,
				'show_image' => '1',
				'show_short' => '1',
				'title'      => 'Latest News',
			),
			$atts,
			'nm_latest_news'
		);

		$count      = max(1, min(10, (int) $atts['count']));
		$show_image = ! in_array(strtolower($atts['show_image']), array('0', 'false', 'no'), true);
		$show_short = ! in_array(strtolower($atts['show_short']), array('0', 'false', 'no'), true);

		$articles = get_posts(
			array(
				'post_type'      => 'post',
				'post_status'    => 'publish',
				'posts_per_page' => $count,
				'orderby'        => 'date',
				'order'          => 'DESC',
				'meta_key'       => '_nm_article_generated',
				'meta_value'     => 'yes',
			)
		);

		if (empty($articles)) {
			return '<div class="nm-latest-news">' . esc_html__('No news articles yet. Check back soon.', 'wp-news-mcq-generator') . '</div>';
		}

		ob_start();
		?>
		<div class="nm-latest-news nm-mcq-container">
			<?php if (! empty($atts['title'])) : ?>
				<h2 class="nm-latest-news-title"><?php echo esc_html($atts['title']); ?></h2>
			<?php endif; ?>
			<ul class="nm-latest-news-list" style="list-style:none;margin:0;padding:0;">
				<?php foreach ($articles as $a) :
					$permalink = get_permalink($a->ID);
					$short_url = get_post_meta($a->ID, '_nm_article_short_url', true);
				?>
					<li class="nm-latest-news-item" style="margin-bottom:18px;padding-bottom:14px;border-bottom:1px solid rgba(0,0,0,.08);display:flex;gap:14px;">
						<?php if ($show_image && has_post_thumbnail($a->ID)) : ?>
							<a href="<?php echo esc_url($permalink); ?>" style="flex:0 0 110px;">
								<?php echo get_the_post_thumbnail($a->ID, 'medium', array('style' => 'width:110px;height:auto;border-radius:8px;object-fit:cover;')); ?>
							</a>
						<?php endif; ?>
						<div>
							<h3 style="margin:0 0 6px;font-size:1.05em;">
								<a href="<?php echo esc_url($permalink); ?>" style="text-decoration:none;"><?php echo esc_html(get_the_title($a->ID)); ?></a>
							</h3>
							<?php $ex = get_the_excerpt($a->ID); if ($ex) : ?>
								<p style="margin:0 0 6px;font-size:.92em;color:inherit;opacity:.8;"><?php echo esc_html(wp_trim_words($ex, 22)); ?></p>
							<?php endif; ?>
							<?php if ($show_short && $short_url) : ?>
								<a href="<?php echo esc_url($short_url); ?>" target="_blank" rel="noopener" style="display:inline-block;font-size:.88em;color:#c4302b;">▶ Watch Short</a>
							<?php endif; ?>
						</div>
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Renders the [nm_dark_mode_toggle] shortcode.
	 */
	public static function render_dark_mode_toggle()
	{
		// This HTML is identical to the widget, so CSS styles will apply to both
		return '
            <div class="nm-theme-toggle-container">
                <button type"button" id="nm-theme-toggle-btn" class="nm-theme-toggle-btn" title="Toggle theme">
                    <span class="nm-theme-icon-light">☀️</span>
                    <span class="nm-theme-icon-dark">🌙</span>
                </button>
            </div>
        ';
	}

	/**
	 * @NEW 9.5.2: Renders the [nm_related_mcqs] shortcode.
	 *
	 * Dynamic replacement for the static "Related Practice MCQs" lists that used to be
	 * baked into generated pillar/roundup post_content. Resolved fresh on every render
	 * against PUBLISHED MCQs only, so the block never links to drafts, deleted posts,
	 * or stale slugs.
	 *
	 * Modes:
	 *  - [nm_related_mcqs topic_id="12" count="6"]   → latest published MCQs in a topic
	 *    (used by evergreen pillars; auto-refreshes as new MCQs publish).
	 *  - [nm_related_mcqs ids="1,2,3" count="10"]    → a fixed set (used by roundups),
	 *    filtered to whichever of those MCQs are currently published.
	 *
	 * Returns '' when nothing is publishable (no empty heading in the page).
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string HTML.
	 */
	public static function render_related_mcqs($atts)
	{
		$atts = shortcode_atts(
			array(
				'topic_id' => 0,
				'ids'      => '',
				'count'    => 6,
				'title'    => 'Related Practice MCQs',
				'intro'    => 'Test yourself on these related questions:',
			),
			$atts,
			'nm_related_mcqs'
		);

		$count = max(1, min(20, (int) $atts['count']));
		$ids   = array();

		if (! empty($atts['ids'])) {
			// Fixed-set mode (roundups): keep given order, drop non-published.
			$requested = array_filter(array_map('absint', explode(',', (string) $atts['ids'])));
			foreach ($requested as $pid) {
				if (get_post_type($pid) === 'mcq' && get_post_status($pid) === 'publish') {
					$ids[] = $pid;
				}
				if (count($ids) >= $count) {
					break;
				}
			}
		} elseif ((int) $atts['topic_id'] > 0) {
			// Topic mode (pillars): latest published MCQs in the topic.
			$q = new WP_Query(
				array(
					'post_type'      => 'mcq',
					'post_status'    => 'publish',
					'posts_per_page' => $count,
					'fields'         => 'ids',
					'no_found_rows'  => true,
					'orderby'        => 'date',
					'order'          => 'DESC',
					'tax_query'      => array(
						array(
							'taxonomy' => 'topic',
							'field'    => 'term_id',
							'terms'    => (int) $atts['topic_id'],
						),
					),
				)
			);
			$ids = array_map('intval', (array) $q->posts);
		}

		if (empty($ids)) {
			return '';
		}

		$items = array();
		foreach ($ids as $pid) {
			$url = get_permalink($pid);
			if (! $url || strpos($url, '?post_type=') !== false) {
				continue; // never emit non-pretty/draft-style URLs
			}
			$items[] = '<li><a href="' . esc_url($url) . '">' . esc_html(get_the_title($pid)) . '</a></li>';
		}

		if (empty($items)) {
			return '';
		}

		return '<div class="nm-related-mcqs"><h2>' . esc_html($atts['title']) . '</h2>'
			. '<p>' . esc_html($atts['intro']) . '</p>'
			. '<ul>' . implode("\n", $items) . '</ul></div>';
	}
}
?>