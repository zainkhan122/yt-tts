<?php

/**
 * E-E-A-T Article Attribution Metabox
 * 
 * Post editor metabox for assigning reviewers, fact-checkers, and verification metadata.
 *
 * @package SEO_Article_Generator
 * @since   2.2.0
 */

namespace SEO_Article_Generator\EEAT;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Article Attribution Meta Box
 * 
 * Allows editors to assign reviewers and track verification
 */
class Article_Attribution_Metabox
{
    // Meta Keys
    public const META_PRIMARY_AUTHOR  = 'post_author'; // Map to native field
    public const META_REVIEWED_BY     = '_seo_reviewed_by';
    public const META_FACT_CHECKED_BY = '_seo_fact_checked_by';
    public const META_LAST_VERIFIED   = 'seogenherodata'; // Verification date moved to unified store
    public const META_NOTES           = '_seo_verification_notes';

    /**
     * Get today's date in local ISO format (Y-m-d)
     *
     * @return string
     */
    private static function today_local_iso(): string
    {
        return wp_date('Y-m-d', current_time('timestamp'));
    }

    /**
     * Register the metabox
     * @MODIFIED 2025-12-16 v2.2.0: Created for E-E-A-T compliance
     */
    public function register_metabox()
    {
        add_meta_box(
            'seo_article_attribution',
            'Article Attribution & E-E-A-T',
            [$this, 'render_metabox'],
            'post',
            'side',
            'high'
        );
    }

    /**
     * Render meta box
     */
    public function render_metabox($post)
    {
        wp_nonce_field('seo_attribution_nonce', 'seo_attribution_nonce');

        $author_manager = new Author_Profile_Manager();

        // Get current author
        $current_author_id = $post->post_author;
        $current_author = $author_manager->get_author_profile($current_author_id);

        // Get all potential authors
        $authors = get_users(['capability' => ['edit_posts'], 'orderby' => 'display_name']);

        // Get attribution metadata
        // Get attribution metadata
        $reviewed_by     = get_post_meta($post->ID, self::META_REVIEWED_BY, true);
        $fact_checked_by = get_post_meta($post->ID, self::META_FACT_CHECKED_BY, true);
        $verification_notes = get_post_meta($post->ID, self::META_NOTES, true);

        // Get unified hero data for verification date
        $hero_data = get_post_meta($post->ID, 'seogenherodata', true);
        $last_verified = is_array($hero_data) && isset($hero_data['last_verified_date']) ? $hero_data['last_verified_date'] : '';

        // Effective author for UI: native post_author is now the only source
        $effective_author_id = $current_author_id;

?>
        <div class="seo-attribution-box">

            <!-- Primary Author -->
            <p>
                <label for="post_author_override"><strong>Primary Author</strong></label>
                <select name="post_author_override" id="post_author_override" class="widefat">
                    <?php foreach ($authors as $author) : ?>
                        <option value="<?php echo esc_attr($author->ID); ?>"
                            <?php selected($author->ID, $effective_author_id); ?>>
                            <?php echo esc_html($author->display_name); ?>
                            <?php
                            $title = get_user_meta($author->ID, 'seo_author_title', true);
                            if ($title) {
                                echo ' — ' . esc_html($title);
                            }
                            ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </p>

            <!-- Reviewed By -->
            <p>
                <label for="seo_reviewed_by"><strong>Reviewed By (Optional)</strong></label>
                <select name="seo_reviewed_by" id="seo_reviewed_by" class="widefat">
                    <option value="">— None —</option>
                    <?php foreach ($authors as $author) : ?>
                        <option value="<?php echo esc_attr($author->ID); ?>"
                            <?php selected($author->ID, $reviewed_by); ?>>
                            <?php echo esc_html($author->display_name); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <small>Shows "Reviewed by [Name]" in article header</small>
            </p>

            <!-- Fact Checked By -->
            <p>
                <label for="seo_fact_checked_by"><strong>Fact-Checked By (Optional)</strong></label>
                <select name="seo_fact_checked_by" id="seo_fact_checked_by" class="widefat">
                    <option value="">— None —</option>
                    <?php foreach ($authors as $author) : ?>
                        <option value="<?php echo esc_attr($author->ID); ?>"
                            <?php selected($author->ID, $fact_checked_by); ?>>
                            <?php echo esc_html($author->display_name); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <small>Shows "Fact-checked by [Name]" in article footer</small>
            </p>

            <!-- Last Verified Date -->
            <p>
                <label for="seo_last_verified"><strong>Last Verified</strong></label>
                <table>
                    <tr>
                        <td>
                            <input
                                type="date"
                                name="seo_last_verified"
                                id="seo_last_verified"
                                value="<?php echo esc_attr($last_verified ?: self::today_local_iso()); ?>"
                                class="regular-text" />
                            <button type="button" id="seo_set_verified_today" class="button">Today</button>
                        </td>
                    </tr>
                </table>
                <small>When download links/specs were last manually checked</small>
            </p>

            <!-- Verification Notes -->
            <p>
                <label for="seo_verification_notes"><strong>Verification Notes (Internal)</strong></label>
                <textarea
                    name="seo_verification_notes"
                    id="seo_verification_notes"
                    rows="3"
                    class="widefat"
                    placeholder="e.g., Verified download link on official site, tested on Windows 11..."><?php echo esc_textarea($verification_notes); ?></textarea>
                <small>Not shown publicly. For editorial reference.</small>
            </p>

            <!-- Quick Actions -->
            <p>
                <button type="button" class="button button-secondary" id="seo-verify-now">
                    ✓ Mark as Verified Now
                </button>
            </p>

            <script>
                jQuery(document).ready(function($) {
                    $('#seo-verify-now').on('click', function() {
                        $('#seo_last_verified').val('<?php echo self::today_local_iso(); ?>');
                        alert('Last verified date set to today. Remember to save the post!');
                    });
                    $('#seo_set_verified_today').on('click', function() {
                        $('#seo_last_verified').val('<?php echo esc_js(self::today_local_iso()); ?>');
                    });
                });
            </script>

            <style>
                .seo-attribution-box p {
                    margin-bottom: 15px;
                }

                .seo-attribution-box label {
                    display: block;
                    margin-bottom: 5px;
                }

                .seo-attribution-box small {
                    display: block;
                    color: #666;
                    margin-top: 4px;
                }
            </style>

        </div>
<?php
    }

    /**
     * Save meta box data
     */
    public function save_metabox($post_id)
    {
        // Security checks
        if (
            ! isset($_POST['seo_attribution_nonce']) ||
            ! wp_verify_nonce($_POST['seo_attribution_nonce'], 'seo_attribution_nonce')
        ) {
            return;
        }

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        if (! current_user_can('edit_post', $post_id)) {
            return;
        }

        // Save attribution meta
        $meta_fields = [
            'seo_reviewed_by'        => 'intval',
            'seo_fact_checked_by'    => 'intval',
            'seo_verification_notes' => 'sanitize_textarea_field',
        ];

        foreach ($meta_fields as $field => $sanitize_callback) {
            if (isset($_POST[$field])) {
                $value = call_user_func($sanitize_callback, $_POST[$field]);
                update_post_meta($post_id, "_{$field}", $value);
            }
        }

        // [ARCHITECTURAL-FIX] Finding 3: Prevent reviewer name drift and verification date split
        $hero_data = get_post_meta($post_id, 'seogenherodata', true);
        if (!is_array($hero_data)) {
            $hero_data = array();
        }

        // Sync verification date to unified store
        if (isset($_POST['seo_last_verified'])) {
            $hero_data['last_verified_date'] = sanitize_text_field($_POST['seo_last_verified']);
        }

        // Use canonical write_hero_data() for normalization, cache invalidation,
        // and Cloudflare dirty transient. Direct update_post_meta() was causing
        // stale per-request cache and missing cache bypass for first visitor.
        \SEO_Article_Generator\Plugin::get_instance()->write_hero_data($post_id, $hero_data);

        // [ARCHITECTURAL-FIX] Finding 2: Direct native post_author sync
        if (isset($_POST['post_author_override'])) {
            $author_id = intval($_POST['post_author_override']);
            
            // Native field IS the source of truth now. No override key needed.
            $wp_post = get_post($post_id);
            if ($wp_post && (int) $wp_post->post_author !== $author_id) {
                remove_action('save_post', array($this, 'save_metabox'));
                // Prevent Hero_Meta_Box::save_meta_box from re-running the full
                // schema sync + write_hero_data + Cloudflare purge chain.
                // wp_update_post fires save_post, and without removing this handler,
                // the redundant save causes unnecessary DB writes and purge API calls.
                remove_action('save_post', 'SEO_Article_Generator\\Admin\\Hero_Meta_Box::save_meta_box', 10);
                wp_update_post(array('ID' => $post_id, 'post_author' => $author_id));
                // Do NOT re-add Hero_Meta_Box::save_meta_box here — it's already registered
                // by Hero_Meta_Box::init(). Re-adding would cause double execution on every save.
                add_action('save_post', array($this, 'save_metabox'));
            }
            
            // Cleanup legacy override key if it exists
            delete_post_meta($post_id, '_post_author_override');
        }
    }

    /**
     * Build meta input for generated posts
     * 
     * @MODIFIED 2026-03-26: Implements random author/reviewer selection for NEW/Legacy posts
     */
     public static function buildGeneratedMetaInput(array $article, int $post_id = 0): array
    {
        $payload = array();
        
        $is_update = $post_id > 0;

        // @MODIFIED 2026-04-03: Preserve attribution for ALL existing post updates (legacy + plugin-generated).
        // META_PRIMARY_AUTHOR is intentionally excluded — post_author is not in $postarr for updates,
        // so WordPress preserves it natively. Adding it here would re-trigger the PATCH 3B overwrite.
        if ($is_update) {
            $existing_reviewer     = (int) get_post_meta($post_id, self::META_REVIEWED_BY, true);
            $existing_fact_checker = (int) get_post_meta($post_id, self::META_FACT_CHECKED_BY, true);

            // FIXED 2026-04-03: If existing post has no reviewer, assign one randomly from
            // eligible authors — explicitly excluding the post's own author.
            if (empty($existing_reviewer)) {
                $post_author_id = (int) get_post_field('post_author', $post_id);

                $authors = get_users(array(
                    'capability' => array('edit_posts'),
                    'fields'     => array('ID', 'display_name'),
                    'exclude'    => $post_author_id > 0 ? array($post_author_id) : array(),
                ));

                if (!empty($authors)) {
                    $picked_index     = array_rand($authors);
                    $existing_reviewer = (int) $authors[$picked_index]->ID;
                }
                // If no other eligible author exists, existing_reviewer stays 0/empty.
                // This is the correct silent fallback — do not assign author as reviewer.
            }

            return array(
                self::META_REVIEWED_BY     => $existing_reviewer ?: '',
                self::META_FACT_CHECKED_BY => $existing_fact_checker ?: '',
            );
        }

        // @MODIFIED 2026-04-03: New post only - random assignment from eligible authors
        $authors = get_users(array(
            'capability' => array('edit_posts'),
            'fields'     => array('ID', 'display_name'),
        ));

        if (empty($authors)) {
            return array();
        }

        $primary_index     = array_rand($authors);
        $primary_author_id = (int) $authors[$primary_index]->ID;

        $reviewer_id = 0;
        if (count($authors) > 1) {
            $remaining = $authors;
            unset($remaining[$primary_index]);
            $remaining = array_values($remaining);
            $reviewer_index = array_rand($remaining);
            $reviewer_id = (int) $remaining[$reviewer_index]->ID;
        }

        // [CANONICAL-FIX] Patch 3: do not seed seogenherodata here.
        // Verification date belongs to editorial state, not random generation bootstrap.
        return array(
            self::META_PRIMARY_AUTHOR  => $primary_author_id,
            self::META_REVIEWED_BY     => $reviewer_id ?: '',
            self::META_FACT_CHECKED_BY => '',
        );
    }
}
