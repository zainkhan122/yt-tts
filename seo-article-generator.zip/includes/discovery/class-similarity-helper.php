<?php
/**
 * Similarity_Helper — String Similarity & Match Safety Engine
 *
 * Replaces simple matching with production-grade algorithms:
 * - Jaro-Winkler : Prefix-aware similarity, excellent for proper nouns.
 * - Token-Sort Ratio: Handles word-order variation ("Photoshop Adobe" ≈ "Adobe Photoshop").
 * - Token-Set Ratio : Handles partial containment ("App Pro" vs "App Pro Plus").
 * - Combined Score : Max of all three — most resilient overall.
 *
 * Also provides qualifier conflict detection to prevent false positives
 * (e.g., App Pro ≠ App Lite even at 90% similarity).
 *
 * @package SEO_Article_Generator\Discovery
 * @version 1.1.0
 */

namespace SEO_Article_Generator\Discovery;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Similarity_Helper {

	/**
	 * Edition qualifiers — longest first to prevent partial-word collisions
	 */
	private const EDITION_QUALIFIERS = array(
		'professional',
		'enterprise',
		'workstation',
		'business',
		'corporate',
		'ultimate',
		'premium',
		'complete',
		'community',
		'education',
		'academic',
		'personal',
		'home',
		'family',
		'express',
		'portable',
		'standalone',
		'installer',
		'offline',
		'advanced',
		'expert',
		'extended',
		'enhanced',
		'unlimited',
		'server',
		'client',
		'desktop',
		'cloud',
		'online',
		'plus',
		'extra',
		'max',
		'mini',
		'micro',
		'nano',
		'pro',
		'lite',
		'light',
		'basic',
		'free',
		'open',
		'esr',
		'lts',
		'beta',
		'alpha',
		'rc',
		'preview',
		'canary',
		'nightly',
		'dev',
		'trial',
		'platinum',
		'suite',
		'leap',
		'tumbleweed',
		'repack',
		'cracked',
	);

	private const ARCH_QUALIFIERS = array(
		'apple silicon',
		'aarch64',
		'64-bit',
		'32-bit',
		'64bit',
		'32bit',
		'arm64',
		'amd64',
		'win64',
		'win32',
		'x86_64',
		'x64',
		'x86',
		'arm',
		'intel',
		'universal',
	);

	/**
	 * Jaro similarity.
	 * Range: 0.0 (no similarity) → 1.0 (identical).
	 */
	public static function jaro( string $s1, string $s2 ): float {
		if ( $s1 === $s2 ) {
			return 1.0;
		}

		$len1 = strlen( $s1 );
		$len2 = strlen( $s2 );
		if ( 0 === $len1 || 0 === $len2 ) {
			return 0.0;
		}

		$match_dist = max( (int) floor( max( $len1, $len2 ) / 2 ) - 1, 0 );

		$s1_flags = array_fill( 0, $len1, false );
		$s2_flags = array_fill( 0, $len2, false );
		$matches = 0;

		for ( $i = 0; $i < $len1; $i++ ) {
			$lo = max( 0, $i - $match_dist );
			$hi = min( $i + $match_dist + 1, $len2 );
			for ( $j = $lo; $j < $hi; $j++ ) {
				if ( $s2_flags[ $j ] || $s1[ $i ] !== $s2[ $j ] ) {
					continue;
				}
				$s1_flags[ $i ] = $s2_flags[ $j ] = true;
				$matches++;
				break;
			}
		}

		if ( 0 === $matches ) {
			return 0.0;
		}

		$k = $t = 0;
		for ( $i = 0; $i < $len1; $i++ ) {
			if ( ! $s1_flags[ $i ] ) {
				continue;
			}
			while ( ! $s2_flags[ $k ] ) {
				$k++;
			}
			if ( $s1[ $i ] !== $s2[ $k ] ) {
				$t++;
			}
			$k++;
		}

		return (
			( $matches / $len1 ) +
			( $matches / $len2 ) +
			( ( $matches - $t / 2.0 ) / $matches )
		) / 3.0;
	}

	/**
	 * Jaro-Winkler similarity — boosts score for common prefixes (max 4 chars).
	 */
	public static function jaro_winkler( string $s1, string $s2, float $p = 0.1 ): float {
		$jaro = self::jaro( $s1, $s2 );
		$limit = min( 4, strlen( $s1 ), strlen( $s2 ) );
		$prefix = 0;
		for ( $i = 0; $i < $limit; $i++ ) {
			if ( $s1[ $i ] === $s2[ $i ] ) {
				$prefix++;
			} else {
				break;
			}
		}
		return $jaro + $prefix * $p * ( 1.0 - $jaro );
	}

	/**
	 * Token-sort ratio.
	 */
	public static function token_sort_ratio( string $s1, string $s2 ): float {
		return self::jaro_winkler(
			self::sorted_tokens( $s1 ),
			self::sorted_tokens( $s2 )
		);
	}

	/**
	 * Token-set ratio.
	 */
	public static function token_set_ratio( string $s1, string $s2 ): float {
		$t1 = self::tokenize( $s1 );
		$t2 = self::tokenize( $s2 );

		$intersection = array_values( array_intersect( $t1, $t2 ) );
		sort( $intersection );

		$only1 = array_values( array_diff( $t1, $intersection ) );
		$only2 = array_values( array_diff( $t2, $intersection ) );
		sort( $only1 );
		sort( $only2 );

		$base = implode( ' ', $intersection );
		$str1 = trim( $base . ' ' . implode( ' ', $only1 ) );
		$str2 = trim( $base . ' ' . implode( ' ', $only2 ) );

		return max(
			self::jaro_winkler( $str1, $str2 ),
			self::jaro_winkler( $base, $str1 ),
			self::jaro_winkler( $base, $str2 )
		);
	}

	/**
	 * Combined similarity score.
	 *
	 * @return float 0.0–1.0
	 */
	public static function combined_score( string $s1, string $s2 ): float {
		$a = self::normalize( $s1 );
		$b = self::normalize( $s2 );

		if ( $a === $b ) {
			return 1.0;
		}
		if ( '' === $a || '' === $b ) {
			return 0.0;
		}

		return max(
			self::jaro_winkler( $a, $b ),
			self::token_sort_ratio( $a, $b ),
			self::token_set_ratio( $a, $b )
		);
	}

	/**
	 * Check for conflicting brand qualifiers.
	 */
	public static function has_qualifier_conflict( string $name1, string $name2 ): bool {
		$q1 = self::extract_qualifiers( $name1, true );
		$q2 = self::extract_qualifiers( $name2, true );
		return $q1 !== $q2;
	}

	public static function extract_qualifiers( string $name, bool $edition_only = false ): array {
		$lower = strtolower( $name );
		$found = array();

		foreach ( self::EDITION_QUALIFIERS as $q ) {
			if ( preg_match( '/\b' . preg_quote( $q, '/' ) . '\b/', $lower ) ) {
				$found[] = strtolower( $q );
			}
		}

		if ( ! $edition_only ) {
			foreach ( self::ARCH_QUALIFIERS as $q ) {
				if ( preg_match( '/\b' . preg_quote( $q, '/' ) . '\b/', $lower ) ) {
					$found[] = strtolower( $q );
				}
			}
		}

		sort( $found );
		return $found;
	}

	/**
	 * Normalize a software name for comparison.
	 */
	public static function normalize( string $name ): string {
		$s = strtolower( trim( $name ) );
		$s = preg_replace( '/[^\w.]+/', ' ', $s ) ?? $s;
		return trim( (string) preg_replace( '/\s{2,}/', ' ', $s ) ?? $s );
	}

	private static function extract_year_tokens( string $name ): array {
		preg_match_all( '/\b(19[7-9]\d|20[0-9]\d)\b/', $name, $m );
		return ! empty( $m[1] ) ? $m[1] : array();
	}

	private static function tokenize( string $s ): array {
		$tokens = preg_split( '/\s+/', self::normalize( $s ), -1, PREG_SPLIT_NO_EMPTY ) ?: array();
		return array_values( array_unique( (array) $tokens ) );
	}

	private static function sorted_tokens( string $s ): string {
		$tokens = self::tokenize( $s );
		sort( $tokens );
		return implode( ' ', $tokens );
	}

	/**
	 * Full match result with confidence label.
	 */
	public static function match_result( string $s1, string $s2 ): array {
		$score = self::combined_score( $s1, $s2 );
		$conflict = self::has_qualifier_conflict( $s1, $s2 );

		$years1 = self::extract_year_tokens( $s1 );
		$years2 = self::extract_year_tokens( $s2 );
		$year_conflict = false;
		if ( ! empty( $years1 ) && ! empty( $years2 ) ) {
			$common = array_intersect( $years1, $years2 );
			if ( empty( $common ) ) {
				$year_conflict = true;
			}
		}

		$effective_conflict = $conflict || $year_conflict;

		$label = 'none';
		if ( $score >= 1.0 ) {
			$label = 'exact';
		} elseif ( $score >= 0.92 ) {
			$label = 'high';
		} elseif ( $score >= 0.80 ) {
			$label = 'medium';
		} elseif ( $score >= 0.65 ) {
			$label = 'low';
		}

		return array(
			'score' => round( $score, 4 ),
			'label' => $label,
			'safe' => ! $effective_conflict && $score >= 0.80,
		);
	}
}
