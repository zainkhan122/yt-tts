/**
 * MCQ Video Studio - Structured Logger
 * 
 * Replaces 400+ console.log calls with structured, filterable logging.
 * 
 * @version 8.7.1
 * @since 2026-02-01
 */

(function(window) {
    'use strict';

    const LogLevel = {
        DEBUG: 0,
        INFO: 1,
        WARN: 2,
        ERROR: 3,
        NONE: 99
    };

    class StructuredLogger {
        constructor(options = {}) {
            this.enabled = options.enabled !== false;
            this.level = options.level || LogLevel.INFO;
            this.prefix = options.prefix || 'MCQVS';
            this.persist = options.persist || false;
            this.buffer = [];
            this.maxBufferSize = 500;
            
            // Performance tracking
            this.metrics = {
                render: [],
                export: [],
                audio: []
            };
        }

        /**
         * Log debug message
         */
        debug(event, data = {}) {
            this._log(LogLevel.DEBUG, event, data);
        }

        /**
         * Log info message
         */
        info(event, data = {}) {
            this._log(LogLevel.INFO, event, data);
        }

        /**
         * Log warning
         */
        warn(event, data = {}) {
            this._log(LogLevel.WARN, event, data);
        }

        /**
         * Log error
         */
        error(event, data = {}) {
            this._log(LogLevel.ERROR, event, data);
        }

        /**
         * Internal log method
         */
        _log(level, event, data) {
            if (!this.enabled || level < this.level) {
                return;
            }

            const entry = {
                timestamp: Date.now(),
                level: this._getLevelName(level),
                event: event,
                data: data,
                url: window.location.href
            };

            // Add to buffer
            if (this.persist) {
                this.buffer.push(entry);
                if (this.buffer.length > this.maxBufferSize) {
                    this.buffer.shift();
                }
            }

            // Console output
            const consoleFn = this._getConsoleMethod(level);
            const prefix = `[${this.prefix}:${entry.level}:${event}]`;

            if (Object.keys(data).length > 0) {
                consoleFn(prefix, data);
            } else {
                consoleFn(prefix);
            }

            // Track performance metrics
            this._trackMetrics(event, data);
        }

        /**
         * Get level name
         */
        _getLevelName(level) {
            switch (level) {
                case LogLevel.DEBUG: return 'DEBUG';
                case LogLevel.INFO: return 'INFO';
                case LogLevel.WARN: return 'WARN';
                case LogLevel.ERROR: return 'ERROR';
                default: return 'UNKNOWN';
            }
        }

        /**
         * Get console method for level
         */
        _getConsoleMethod(level) {
            switch (level) {
                case LogLevel.DEBUG: return console.debug.bind(console);
                case LogLevel.INFO: return console.info.bind(console);
                case LogLevel.WARN: return console.warn.bind(console);
                case LogLevel.ERROR: return console.error.bind(console);
                default: return console.log.bind(console);
            }
        }

        /**
         * Track performance metrics
         */
        _trackMetrics(event, data) {
            // Render performance
            if (event === 'PREVIEW_FRAME_RENDER' && data.duration) {
                this.metrics.render.push(data.duration);
                if (this.metrics.render.length > 60) {
                    this.metrics.render.shift();
                }
            }

            // Export performance
            if (event === 'EXPORT_FRAME_ENCODE' && data.duration) {
                this.metrics.export.push(data.duration);
                if (this.metrics.export.length > 100) {
                    this.metrics.export.shift();
                }
            }

            // Audio performance
            if (event === 'AUDIO_MIX_COMPLETE' && data.duration) {
                this.metrics.audio.push(data.duration);
                if (this.metrics.audio.length > 20) {
                    this.metrics.audio.shift();
                }
            }
        }

        /**
         * Get performance stats
         */
        getStats() {
            const calcStats = (arr) => {
                if (arr.length === 0) return null;
                const sum = arr.reduce((a, b) => a + b, 0);
                const avg = sum / arr.length;
                const sorted = [...arr].sort((a, b) => a - b);
                const p50 = sorted[Math.floor(sorted.length * 0.5)];
                const p95 = sorted[Math.floor(sorted.length * 0.95)];
                return { avg, p50, p95, count: arr.length };
            };

            return {
                render: calcStats(this.metrics.render),
                export: calcStats(this.metrics.export),
                audio: calcStats(this.metrics.audio)
            };
        }

        /**
         * Export logs as JSON
         */
        export() {
            return {
                logs: this.buffer,
                stats: this.getStats(),
                exported: Date.now()
            };
        }

        /**
         * Clear buffer
         */
        clear() {
            this.buffer = [];
            this.metrics = {
                render: [],
                export: [],
                audio: []
            };
        }

        /**
         * Set log level
         */
        setLevel(level) {
            this.level = level;
        }

        /**
         * Enable logging
         */
        enable() {
            this.enabled = true;
        }

        /**
         * Disable logging
         */
        disable() {
            this.enabled = false;
        }
    }

    // Create global instance
    // The diagnostics card lives in production too — keep the ring buffer alive regardless of origin,
    // even when verbose console output is suppressed outside dev hosts.
    const isDevelopment =
        window.location.hostname === 'localhost' ||
        window.location.hostname === '127.0.0.1' ||
        window.location.search.includes('mcqvs_debug=1');

    window.MCQVSLogger = new StructuredLogger({
        enabled: true,
        level: LogLevel.DEBUG,
        persist: true
    });
    // Track origin in dev-only console output (still kept in buffer for Diagnostics).
    window.MCQVSLogger._isDevelopment = !!isDevelopment;

    // Expose LogLevel for external configuration
    window.MCQVSLogLevel = LogLevel;

    // Export stats to console
    window.MCQVS_LogStats = () => {
        console.table(window.MCQVSLogger.getStats());
    };

})(window);
