<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Contracts\AIProviderInterface;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class GroqProvider implements AIProviderInterface {

	public function get_provider_name() {
		return Config::PROVIDER_GROQ;
	}

	public function get_model_name() {
		$model = get_option( Config::OPTION_GROQ_MODEL, Config::DEFAULT_GROQ_MODEL );
		return ! empty( $model ) ? $model : Config::DEFAULT_GROQ_MODEL;
	}

	public function generate_content( $post_content, $system_prompt = '' ) {
 		$api_key = get_option( Config::OPTION_GROQ_KEY, '' );
 		if ( empty( $api_key ) ) {
 			throw new \Exception( 'Groq API Key is missing. Configure it in AI Social Collage → Settings.' );
 		}

 		$payload = [
 			'model' => $this->get_model_name(),
 			'messages' => [
 				[ 'role' => 'system', 'content' => $system_prompt ],
 				[ 'role' => 'user', 'content' => $post_content ],
 			],
 			'response_format' => [ 'type' => 'json_object' ],
 		];

 		$start_time = microtime( true );
 		$response = wp_remote_post(
 			'https://api.groq.com/openai/v1/chat/completions',
 			[
 				'body' => wp_json_encode( $payload ),
 				'headers' => [
 					'Content-Type' => 'application/json',
 					'Authorization' => 'Bearer ' . $api_key,
 				],
 				'timeout' => 30,
 			]
 		);
 		$execution_time = microtime( true ) - $start_time;

 		if ( is_wp_error( $response ) ) {
 			throw new \Exception( 'Groq API Connection Error: ' . $response->get_error_message() );
 		}

 		$response_code = wp_remote_retrieve_response_code( $response );
 		$body = wp_remote_retrieve_body( $response );

 		Logger::debug( Config::LOG_ACTION_GROQ_RESPONSE, null, $payload, (string) $response_code, $body, $execution_time );

		if ( $response_code === 200 ) {
			$data = json_decode( $body, true );
			$result_text = $data['choices'][0]['message']['content'] ?? '{}';

			// Strip markdown code fences (```json ... ```) some models add without response_format enforcement
			$result_text = preg_replace( '/^```(?:json)?\s*\n?(.*?)\n?```\s*$/s', '$1', $result_text );

			$result = json_decode( $result_text, true );
			if ( $result === null || ! is_array( $result ) ) {
				throw new \Exception( 'Groq API response content is not valid JSON: ' . mb_substr( $result_text, 0, 200 ) );
			}

			$input_tokens = (int) ( $data['usage']['prompt_tokens'] ?? 0 );
			$output_tokens = (int) ( $data['usage']['completion_tokens'] ?? 0 );
			$result['_meta'] = [
				'input_tokens' => $input_tokens,
				'output_tokens' => $output_tokens,
			];

			return $result;
		}

 		if ( $response_code === 401 || $response_code === 403 ) {
 			throw new \Exception( 'Groq API returned HTTP ' . $response_code, $response_code );
 		}

 		if ( $response_code === 429 ) {
 			throw new \Exception( 'Groq API returned HTTP 429: rate limited', 429 );
 		}

 		throw new \Exception( 'Groq API returned HTTP ' . $response_code . ': ' . mb_substr( $body, 0, 500 ), $response_code );
 	}

	public function analyze_image( $image_path, $system_prompt = '' ) {
		$api_key = get_option( Config::OPTION_GROQ_KEY, '' );
		if ( empty( $api_key ) ) {
			throw new \Exception( 'Groq API Key is missing. Configure it in AI Social Collage → Settings.' );
		}

		if ( ! file_exists( $image_path ) ) {
			throw new \Exception( 'Image file not found: ' . $image_path );
		}

		$mime = mime_content_type( $image_path );
		$base64 = base64_encode( file_get_contents( $image_path ) );
		if ( empty( $base64 ) ) {
			throw new \Exception( 'Failed to read image for Groq Vision.' );
		}

		$payload = [
			'model' => 'llama-3.2-11b-vision-preview',
			'messages' => [
				[
					'role' => 'user',
					'content' => [
						[ 'type' => 'text', 'text' => $system_prompt ],
						[ 'type' => 'image_url', 'image_url' => [ 'url' => "data:{$mime};base64,{$base64}" ] ]
					]
				]
			],
			'response_format' => [ 'type' => 'json_object' ],
		];

		$start_time = microtime( true );
		$response = wp_remote_post(
			'https://api.groq.com/openai/v1/chat/completions',
			[
				'body' => wp_json_encode( $payload ),
				'headers' => [
					'Content-Type' => 'application/json',
					'Authorization' => 'Bearer ' . $api_key,
				],
				'timeout' => 60,
			]
		);
		$execution_time = microtime( true ) - $start_time;

		if ( is_wp_error( $response ) ) {
			throw new \Exception( 'Groq Vision API Connection Error: ' . $response->get_error_message() );
		}

		$response_code = wp_remote_retrieve_response_code( $response );
		$body = wp_remote_retrieve_body( $response );

		Logger::debug( Config::LOG_ACTION_GROQ_RESPONSE, null, [ 'model' => 'llama-3.2-11b-vision-preview', 'image' => true ], (string) $response_code, mb_substr($body, 0, 1000), $execution_time );

		if ( $response_code !== 200 ) {
			throw new \Exception( 'Groq Vision API returned HTTP ' . $response_code . ': ' . mb_substr($body, 0, 200) );
		}

		$data = json_decode( $body, true );
		$result_text = $data['choices'][0]['message']['content'] ?? '{}';

		$result = json_decode( $result_text, true );
		if ( $result === null ) {
			$result = [];
		}

		$input_tokens = (int) ( $data['usage']['prompt_tokens'] ?? 0 );
		$output_tokens = (int) ( $data['usage']['completion_tokens'] ?? 0 );
		$result['_meta'] = [
			'input_tokens' => $input_tokens,
			'output_tokens' => $output_tokens,
		];

		return $result;
	}

	public function test_connection() {
		$api_key = get_option( Config::OPTION_GROQ_KEY, '' );
		if ( empty( $api_key ) ) {
			return [ 'success' => false, 'error' => 'Groq API Key is missing.' ];
		}
		$response = wp_remote_post(
			'https://api.groq.com/openai/v1/chat/completions',
			[
				'body' => wp_json_encode( [
					'model' => $this->get_model_name(),
					'messages' => [ [ 'role' => 'user', 'content' => 'Ping' ] ],
					'max_tokens' => 5,
					'temperature' => 0,
				] ),
				'headers' => [
					'Content-Type' => 'application/json',
					'Authorization' => 'Bearer ' . $api_key,
				],
				'timeout' => 30,
			]
		);
		if ( is_wp_error( $response ) ) {
			return [ 'success' => false, 'error' => $response->get_error_message() ];
		}
		$code = wp_remote_retrieve_response_code( $response );
		if ( $code === 200 ) {
			return [ 'success' => true, 'message' => 'Connection successful.' ];
		}
		return [ 'success' => false, 'error' => "HTTP {$code}" ];
	}
}
