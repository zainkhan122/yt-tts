<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Leaderboard System for MCQ Plugin
 *
 * @version 2.1 - Standardized Cache & Response
 *
 * @MODIFIED: Replaced get_transient/set_transient with NM_Cache_Manager.
 * @MODIFIED: Replaced wp_send_json_success/error with NM_Response_Handler.
 * * @package WP_News_MCQ_Generator
 */

class NM_Leaderboard {

	private static $instance = null;

	public static function init() {
		if ( self::$instance === null ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_ajax_nm_get_leaderboard', array( $this, 'get_leaderboard' ) );
		add_action( 'wp_ajax_nopriv_nm_get_leaderboard', array( $this, 'get_leaderboard' ) );
		add_action( 'wp_ajax_nm_get_user_rank', array( $this, 'get_user_rank' ) );
		add_shortcode( 'nm_leaderboard', array( $this, 'leaderboard_shortcode' ) );
	}

	/**
	 * ✅ OPTIMIZED: Get leaderboard data with proper caching
	 */
	public function get_leaderboard() {
		check_ajax_referer( 'nm_leaderboard_nonce', 'nonce' );

		$period   = sanitize_text_field( $_POST['period'] ?? 'all_time' );
		$limit    = absint( $_POST['limit'] ?? 50 );
		$limit    = min( $limit, 100 ); // Cap at 100 for performance
		$topic_id = absint( $_POST['topic_id'] ?? 0 );

		// ✅ PERFORMANCE: Cache with specific parameters
		$cache_key = "nm_leaderboard_{$period}_{$topic_id}_{$limit}_v2";

		// ✅ START FIX: Use NM_Cache_Manager
		$cached = NM_Cache_Manager::get( $cache_key );

		if ( false !== $cached ) {
			NM_Response_Handler::success( $cached ); // ✅ Use NM_Response_Handler
			return;
		}
		// ✅ END FIX

		// Route to appropriate method
		switch ( $period ) {
			case 'weekly':
				$leaderboard = $this->get_weekly_leaderboard( $limit, $topic_id );
				break;
			case 'monthly':
				$leaderboard = $this->get_monthly_leaderboard( $limit, $topic_id );
				break;
			default:
				$leaderboard = $this->get_all_time_leaderboard( $limit, $topic_id );
		}

		// Cache for 15 minutes
		// ✅ START FIX: Use NM_Cache_Manager and NM_Response_Handler
		NM_Cache_Manager::set( $cache_key, $leaderboard, 15 * MINUTE_IN_SECONDS );

		NM_Response_Handler::success( $leaderboard );
		// ✅ END FIX
	}

	/**
	 * ✅ OPTIMIZED: All-time leaderboard with single SQL query
	 */
	private function get_all_time_leaderboard( $limit = 50, $topic_id = 0 ) {
		global $wpdb;

		// ✅ PERFORMANCE: Single query with LEFT JOINs for all user meta
		$query = "
            SELECT 
                u.ID as user_id,
                u.display_name,
                CAST(COALESCE(pm_points.meta_value, 0) AS UNSIGNED) as total_points,
                CAST(COALESCE(pm_level.meta_value, 1) AS UNSIGNED) as level,
                CAST(COALESCE(pm_public.meta_value, 1) AS UNSIGNED) as is_public
            FROM {$wpdb->users} u
            LEFT JOIN {$wpdb->usermeta} pm_points 
                ON u.ID = pm_points.user_id AND pm_points.meta_key = 'nm_total_points'
            LEFT JOIN {$wpdb->usermeta} pm_level 
                ON u.ID = pm_level.user_id AND pm_level.meta_key = 'nm_level'
            LEFT JOIN {$wpdb->usermeta} pm_public 
                ON u.ID = pm_public.user_id AND pm_public.meta_key = 'nm_public_profile'
            WHERE CAST(COALESCE(pm_points.meta_value, 0) AS UNSIGNED) > 0
            ORDER BY total_points DESC
            LIMIT %d
        ";

		$results = $wpdb->get_results( $wpdb->prepare( $query, $limit ) );

		// ✅ ERROR HANDLING: Log and return empty on failure
		if ( $wpdb->last_error ) {
			return array();
		}

		$leaderboard = array();
		$rank        = 1;

		foreach ( $results as $row ) {
			$is_public = (int) $row->is_public;

			$leaderboard[] = array(
				'rank'         => $rank++,
				'user_id'      => (int) $row->user_id,
				'display_name' => $is_public !== 0 ? esc_html( $row->display_name ) : 'Anonymous',
				'points'       => (int) $row->total_points,
				'level'        => (int) $row->level,
				'avatar'       => get_avatar_url( $row->user_id, array( 'size' => 64 ) ),
			);
		}

		return $leaderboard;
	}

	/**
	 * ✅ OPTIMIZED: Weekly leaderboard with date filtering
	 */
	private function get_weekly_leaderboard( $limit = 50, $topic_id = 0 ) {
		global $wpdb;

		$one_week_ago  = date( 'Y-m-d H:i:s', strtotime( '-7 days' ) );
		$answers_table = $wpdb->prefix . 'nm_user_answers';

		// Check if table exists
		if ( $wpdb->get_var( "SHOW TABLES LIKE '{$answers_table}'" ) != $answers_table ) {
			return array();
		}

		$query = "
            SELECT 
                u.ID as user_id,
                u.display_name,
                SUM(CASE WHEN ans.is_correct = 1 THEN 10 ELSE 0 END) as weekly_points,
                CAST(COALESCE(pm_level.meta_value, 1) AS UNSIGNED) as level,
                CAST(COALESCE(pm_public.meta_value, 1) AS UNSIGNED) as is_public
            FROM {$wpdb->users} u
            INNER JOIN {$answers_table} ans ON u.ID = ans.user_id
            LEFT JOIN {$wpdb->usermeta} pm_level 
                ON u.ID = pm_level.user_id AND pm_level.meta_key = 'nm_level'
            LEFT JOIN {$wpdb->usermeta} pm_public 
                ON u.ID = pm_public.user_id AND pm_public.meta_key = 'nm_public_profile'
            WHERE ans.answered_at >= %s
            GROUP BY u.ID
            HAVING weekly_points > 0
            ORDER BY weekly_points DESC
            LIMIT %d
        ";

		$results = $wpdb->get_results( $wpdb->prepare( $query, $one_week_ago, $limit ) );

		if ( $wpdb->last_error ) {
			return array();
		}

		$leaderboard = array();
		$rank        = 1;

		foreach ( $results as $row ) {
			$is_public = (int) $row->is_public;

			$leaderboard[] = array(
				'rank'         => $rank++,
				'user_id'      => (int) $row->user_id,
				'display_name' => $is_public !== 0 ? esc_html( $row->display_name ) : 'Anonymous',
				'points'       => (int) $row->weekly_points,
				'level'        => (int) $row->level,
				'avatar'       => get_avatar_url( $row->user_id, array( 'size' => 64 ) ),
			);
		}

		return $leaderboard;
	}

	/**
	 * ✅ OPTIMIZED: Monthly leaderboard
	 */
	private function get_monthly_leaderboard( $limit = 50, $topic_id = 0 ) {
		global $wpdb;

		$one_month_ago = date( 'Y-m-d H:i:s', strtotime( '-30 days' ) );
		$answers_table = $wpdb->prefix . 'nm_user_answers';

		// Check if table exists
		if ( $wpdb->get_var( "SHOW TABLES LIKE '{$answers_table}'" ) != $answers_table ) {
			return array();
		}

		$query = "
            SELECT 
                u.ID as user_id,
                u.display_name,
                SUM(CASE WHEN ans.is_correct = 1 THEN 10 ELSE 0 END) as monthly_points,
                CAST(COALESCE(pm_level.meta_value, 1) AS UNSIGNED) as level,
                CAST(COALESCE(pm_public.meta_value, 1) AS UNSIGNED) as is_public
            FROM {$wpdb->users} u
            INNER JOIN {$answers_table} ans ON u.ID = ans.user_id
            LEFT JOIN {$wpdb->usermeta} pm_level 
                ON u.ID = pm_level.user_id AND pm_level.meta_key = 'nm_level'
            LEFT JOIN {$wpdb->usermeta} pm_public 
                ON u.ID = pm_public.user_id AND pm_public.meta_key = 'nm_public_profile'
            WHERE ans.answered_at >= %s
            GROUP BY u.ID
            HAVING monthly_points > 0
            ORDER BY monthly_points DESC
            LIMIT %d
        ";

		$results = $wpdb->get_results( $wpdb->prepare( $query, $one_month_ago, $limit ) );

		if ( $wpdb->last_error ) {
			return array();
		}

		$leaderboard = array();
		$rank        = 1;

		foreach ( $results as $row ) {
			$is_public = (int) $row->is_public;

			$leaderboard[] = array(
				'rank'         => $rank++,
				'user_id'      => (int) $row->user_id,
				'display_name' => $is_public !== 0 ? esc_html( $row->display_name ) : 'Anonymous',
				'points'       => (int) $row->monthly_points,
				'level'        => (int) $row->level,
				'avatar'       => get_avatar_url( $row->user_id, array( 'size' => 64 ) ),
			);
		}

		return $leaderboard;
	}

	/**
	 * ✅ OPTIMIZED: Get user's rank with single query
	 */
	public function get_user_rank() {
		check_ajax_referer( 'nm_leaderboard_nonce', 'nonce' );

		// ✅ START FIX: Use NM_Response_Handler
		if ( ! is_user_logged_in() ) {
			NM_Response_Handler::error( 'Not logged in', 'not_logged_in' );
			return;
		}
		// ✅ END FIX

		$user_id     = get_current_user_id();
		$user_points = (int) get_user_meta( $user_id, 'nm_total_points', true );

		global $wpdb;

		// ✅ PERFORMANCE: Single COUNT query instead of loading all users
		$rank = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) + 1 
            FROM {$wpdb->usermeta} 
            WHERE meta_key = 'nm_total_points' 
            AND CAST(meta_value AS UNSIGNED) > %d",
				$user_points
			)
		);

		// ✅ START FIX: Use NM_Response_Handler
		NM_Response_Handler::success(
			array(
				'rank'   => (int) $rank,
				'points' => $user_points,
			)
		);
		// ✅ END FIX
	}

	/**
	 * Shortcode render
	 */
	public function leaderboard_shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'limit'  => 10,
				'period' => 'all_time',
			),
			$atts
		);

		ob_start();
		?>
		<div class="nm-leaderboard-widget" 
			data-period="<?php echo esc_attr( $atts['period'] ); ?>" 
			data-limit="<?php echo esc_attr( $atts['limit'] ); ?>">
			<div class="nm-leaderboard-header">
				<h3>🏆 Top Players</h3>
				<select class="nm-leaderboard-period">
					<option value="all_time" <?php selected( $atts['period'], 'all_time' ); ?>>All Time</option>
					<option value="monthly" <?php selected( $atts['period'], 'monthly' ); ?>>This Month</option>
					<option value="weekly" <?php selected( $atts['period'], 'weekly' ); ?>>This Week</option>
				</select>
			</div>
			<div class="nm-leaderboard-body">
				<div class="nm-leaderboard-loading">Loading...</div>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * ✅ STATIC: Cron method for cache clearing
	 * Method name uses underscores to match WordPress naming convention
	 */
	public static function recalculate_all_leaderboards() {
		global $wpdb;

		// Clear all leaderboard caches
		// ✅ FIX: Replaced the direct $wpdb->query (and the old flush_group call)
		// with the correct Cache Manager method.
		if ( class_exists( 'NM_Cache_Manager' ) ) {
			// This is the correct method to call, using 'leaderboard_' as the prefix.
			NM_Cache_Manager::clear_by_prefix( 'leaderboard_' );
		} else {
			// Fallback just in case, this is the old (but working) query.
			$wpdb->query(
				"
            DELETE FROM {$wpdb->options} 
            WHERE option_name LIKE '_transient_nm_leaderboard_%' 
            OR option_name LIKE '_transient_timeout_nm_leaderboard_%'
        "
			);
		}


		// Optional: Pre-warm cache for most common queries
		// Note: We create a new instance as this is a static method
		try {
			$instance = new self();
			$instance->get_all_time_leaderboard( 50, 0 );
		} catch ( Exception $e ) {
		}
	}
}
?>
