<?php

/**
 * Plugin Installer
 *
 * @package SEO_Article_Generator
 */

namespace SEO_Article_Generator;

use SEO_Article_Generator\Utils\Plugin_Time;
use SEO_Article_Generator\Queue\AS_Registry;
use SEO_Article_Generator\Queue\Job_Repository;
use SEO_Article_Generator\Option_Registry;

// Prevent direct access
if (! defined('ABSPATH')) {
	exit();
}

/**
 * Handles plugin activation and deactivation
 */
class Installer {
	public const DB_VERSION = '2.20.1';

    public const OPTION_DB_VERSION   = 'seo_gen_db_version';
    public const OPTION_PLUGIN_VER   = 'seo_gen_version';
    public const OPTION_INSTALL_ERR  = 'seo_gen_install_error';
    public const OPTION_INSTALL_STATE = 'seo_gen_install_state';

    public static function table_jobs(): string {
        global $wpdb;
        return $wpdb->prefix . 'seo_generation_jobs';
    }

    public static function table_queue(): string {
        global $wpdb;
        return $wpdb->prefix . 'seo_gen_queue';
    }

    public static function table_links(): string {
        global $wpdb;
        return $wpdb->prefix . 'seo_gen_internal_links';
    }

    public static function table_discovery(): string {
        global $wpdb;
        return $wpdb->prefix . 'seo_gen_discovery';
    }

    public static function table_locks(): string {
        global $wpdb;
        return $wpdb->prefix . 'seo_gen_runtimelocks';
    }

    /**
     * Run on plugin activation
     *
     * @return void
     */
public static function activate(): void {
		self::load_action_scheduler();

    // [HARDENING] Immediate recovery of jobs stranded in 'reserved' state by deactivation
    if (self::is_as_initialized()) {
        global $wpdb;
        try {
            $repo = new Job_Repository($wpdb);
            $repo->cleanup_stale_reservations();

            // FINDING-7 FIX: Reset zombie discovery rows (generating/finalizing/processing) back to queued
            // after deactivate → reactivate. Deactivation calls clear_scheduled_actions() but leaves
            // discovery row states untouched, causing zombie rows after reactivation.
            $discovery_table = self::table_discovery();
            $wpdb->query(
                "UPDATE {$discovery_table}
                SET status = 'queued',
                    job_id = NULL,
                    queue_job_id = NULL,
                    action_id = NULL,
                    error_message = NULL,
                    heartbeat_at = NULL,
                    scheduled_at = NULL,
                    completed_at = NULL
                WHERE status IN ('generating', 'finalizing', 'processing', 'deferred')"
            );

            $plugin = \SEO_Article_Generator\Plugin::get_instance();
            $processor = $plugin->get_discovery_processor();
            if ($processor && method_exists($processor, 'after_history_mutation_reconcile')) {
                $processor->after_history_mutation_reconcile();
            }

            // FINDING-7 FIX: Re-schedule discovery jobs after resetting zombie rows
            // schedule_discovery_jobs() lives in Discovery_Bootstrap, NOT Discovery_Processor
            $bootstrap = \SEO_Article_Generator\Discovery\Discovery_Bootstrap::get_instance();
            if ($bootstrap && method_exists($bootstrap, 'schedule_discovery_jobs')) {
                $bootstrap->schedule_discovery_jobs();
            }
        } catch (\Throwable $e) {
            error_log('SEO Article Generator: Failed to cleanup stale reservations on activation: ' . $e->getMessage());
        }
    }

		self::run_installation(true);
	}

    private static function run_installation(bool $is_activation): void {
        self::load_action_scheduler();
        self::migrate_legacy_options();
        update_option(self::OPTION_INSTALL_STATE, 'installing', false);
        delete_option(self::OPTION_INSTALL_ERR);

        try {
            self::create_tables();
            self::create_discovery_table();
            self::normalize_discovery_schema();
            self::drop_legacy_duplicate_indexes();
            self::run_column_migrations();
            self::verify_schema();
            self::set_default_options();
            self::backfill_discovery_section_defaults();
            self::schedule_cleanup_or_fail();

            update_option(self::OPTION_PLUGIN_VER, SEO_GEN_VERSION, false);
            update_option(self::OPTION_DB_VERSION, self::DB_VERSION, false);
            update_option(self::OPTION_INSTALL_STATE, 'installed', false);
            delete_option(self::OPTION_INSTALL_ERR);

            // Set activation timestamp for uptime tracking
            if ($is_activation && !get_option('seo_gen_activated_timestamp', false)) {
                update_option('seo_gen_activated_timestamp', time(), false);
            }

		if ($is_activation) {
			flush_rewrite_rules();
			self::reconcile_orphaned_draft_deletions();
		}
        } catch (\Throwable $e) {
            self::clear_scheduled_actions();
            update_option(self::OPTION_INSTALL_STATE, 'failed', false);
            update_option(self::OPTION_INSTALL_ERR, $e->getMessage(), false);
            throw $e;
        }
    }

    /**
     * Secure Action Scheduler inclusion to prevent fatal errors.
     * 
     * @return void
     */
	private static function load_action_scheduler(): void {
		if (! class_exists('ActionScheduler')) {
			$as_path = SEO_GEN_PLUGIN_DIR . 'vendor/action-scheduler/action-scheduler.php';
			if (file_exists($as_path)) {
				require_once $as_path;
			}
		}
	}

	/**
	 * Re-schedule draft deletion AS actions that were lost during deactivation.
	 * Scans discovery table for terminal-status rows with a draft_post_id that
	 * still exists as a post but has no pending seo_gen_delete_draft_post action.
	 *
	 * @MODIFIED 2026-05-05: SSOT Unification — prevents orphaned drafts on reactivation.
	 */
	private static function reconcile_orphaned_draft_deletions(): void {
		global $wpdb;

		$table = self::table_discovery();
		if (! self::table_exists($table)) {
			return;
		}

		if (! class_exists('\SEO_Article_Generator\Queue\AS_Registry')
			|| ! class_exists('\SEO_Article_Generator\Discovery\Discovery_Engine')) {
			return;
		}

		$rows = $wpdb->get_results(
			"SELECT DISTINCT draft_post_id
			 FROM {$table}
			 WHERE draft_post_id IS NOT NULL
			 AND draft_post_id > 0
			 AND status IN ('done','skippedduplicate','skippednotnewer','failed','ignored','timeout')"
		);

		if (empty($rows)) {
			return;
		}

		foreach ($rows as $row) {
			$draft_id = (int) $row->draft_post_id;
			if ($draft_id <= 0) {
				continue;
			}

			if (! \get_post($draft_id)) {
				$wpdb->query($wpdb->prepare(
					"UPDATE {$table} SET draft_post_id = NULL WHERE draft_post_id = %d",
					$draft_id
				));
				continue;
			}

			$has_pending = \SEO_Article_Generator\Queue\AS_Registry::has_scheduled_action(
				\SEO_Article_Generator\Queue\AS_Registry::HOOK_DELETE_DRAFT,
				[$draft_id],
				\SEO_Article_Generator\Queue\AS_Registry::GROUP
			);

			if (! $has_pending) {
				\SEO_Article_Generator\Discovery\Discovery_Engine::schedule_draft_deletion($draft_id);
			}
		}
	}

	/**
	 * Verify database schema and indexes
     *
     * @return void
     */
    private static function verify_schema(): void {
        $required = [
            self::table_queue() => [
                'columns' => [
                    'id', 'type', 'reference_id', 'payload', 'status', 'reservation_token', 'attempts',
                    'reserved_at', 'processing_started_at', 'heartbeat_at', 'lease_expires_at', 'available_at', 'completed_at', 'created_at', 'updated_at',
                ],
                'indexes' => [
                    'PRIMARY', 'idx_queue_ready', 'idx_queue_lease',
                    'idx_queue_heartbeat', 'idx_queue_ref',
                ],
            ],
            self::table_jobs() => [
                'columns' => [
                    'id', 'user_id', 'status', 'queue_job_id', 'input_data', 'output_data',
                    'validation_results', 'debug_data', 'error_message', 'retry_count',
                    'hallucination_count', 'failed_sections_count', 'validation_errors_count',
                    'status_started_at', 'heartbeat_at', 'available_at',
                    'created_at', 'completed_at',
                ],
                'indexes' => [
                    'PRIMARY', 'idx_jobs_available', 'idx_jobs_stale', 'idx_jobs_completed', 'idx_jobs_queue',
                    'idx_status_created', 'idx_status_started', 'idx_completed_at',
                ],
            ],
            self::table_links() => [
                'columns' => [
                    'id', 'title', 'url', 'category', 'keywords', 'created_at', 'used_count',
                ],
                'indexes' => [
                    'PRIMARY', 'idx_keywords_title',
                ],
            ],
            self::table_locks() => [
                'columns' => [
                    'lock_name', 'owner_key', 'lease_expires_at', 'heartbeat_at',
                    'created_at', 'updated_at',
                ],
                'indexes' => [
                    'PRIMARY', 'idx_lease_expires_at',
                ],
            ],
            self::table_discovery() => [
                'columns' => [
                    'id', 'software_name', 'discovered_version', 'current_version',
                    'type', 'status', 'existing_post_id', 'matched_post_id',
                    'draft_post_id', 'job_id', 'queue_job_id', 'action_id', 'poll_count',
                    'consecutive_failures', 'last_failure_at', 'error_message',
                    'source_type', 'source_url', 'source_image_url', 'source_thumbnail_url', 'changelog',
                    'featured_image_id', 'discovered_at', 'scheduled_at',
                    'publish_at', 'completed_at', 'heartbeat_at', 'dedupe_key',
                    'created_at',
                ],
                'indexes' => [
                    'PRIMARY', 'idx_dedupe', 'idx_status', 'idx_existing_post',
                    'idx_matched_post', 'idx_job_id', 'idx_queue_job_id',
                    'idx_status_completed', 'idx_heartbeatat', 'idx_auto_gen',
                ],
            ],
        ];

        $errors = [];

        foreach ($required as $table => $spec) {
            if (! self::table_exists($table)) {
                $errors[] = "Missing table {$table}";
                continue;
            }

            $missing_columns = self::get_missing_columns($table, $spec['columns']);
            if ($missing_columns) {
                $errors[] = sprintf(
                    '%s missing columns: %s',
                    $table,
                    implode(', ', $missing_columns)
                );
            }

            $missing_indexes = self::get_missing_indexes($table, $spec['indexes']);
            if ($missing_indexes) {
                $errors[] = sprintf(
                    '%s missing indexes: %s',
                    $table,
                    implode(', ', $missing_indexes)
                );
            }
        }

        if ($errors) {
            $msg = 'Schema verification failed: ' . implode(' | ', $errors);
            error_log('SEO Article Generator: ' . $msg);
            throw new \RuntimeException($msg);
        }
    }

    /**
     * Safe wrapper for verifySchema
     *
     * @return bool
     */
    public static function is_schema_healthy(): bool {
        // Per-request cache: schema health cannot change within a single PHP request.
        // Eliminates ~15 SHOW TABLES/COLUMNS/INDEX queries on repeated calls
        // (seo_gen_maybe_upgrade + seo_gen_boot both call this on every page load).
        static $cache = null;
        if ($cache !== null) {
            return $cache;
        }
        try {
            self::verify_schema();
            $cache = true;
            return true;
        } catch (\Throwable $e) {
            $cache = false;
            return false;
        }
    }

    private static function table_exists(string $table): bool {
        global $wpdb;

        $exists = $wpdb->get_var(
            $wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table))
        );

        return (string) $exists === $table;
    }

    private static function get_missing_columns(string $table, array $required): array {
        global $wpdb;

        $rows = $wpdb->get_results("SHOW COLUMNS FROM `{$table}`", ARRAY_A);
        $existing = [];

        foreach ((array) $rows as $row) {
            if (! empty($row['Field'])) {
                $existing[] = (string) $row['Field'];
            }
        }

        return array_values(array_diff($required, $existing));
    }

    private static function get_missing_indexes(string $table, array $required): array {
        global $wpdb;

        $rows = $wpdb->get_results("SHOW INDEX FROM `{$table}`", ARRAY_A);
        $existing = [];

        foreach ((array) $rows as $row) {
            if (! empty($row['Key_name'])) {
                $existing[] = (string) $row['Key_name'];
            }
        }

        $existing = array_values(array_unique($existing));

        return array_values(array_diff($required, $existing));
    }

    private static function drop_legacy_duplicate_indexes(): void {
        global $wpdb;

        $table = self::table_discovery();

        if (! self::table_exists($table)) {
            return;
        }

        $rows = $wpdb->get_results(
            "SHOW INDEX FROM `{$table}` WHERE Key_name IN ('idx_auto_gen','idx_status_type_scheduled')",
            ARRAY_A
        );

        $names = [];
        foreach ((array) $rows as $row) {
            if (! empty($row['Key_name'])) {
                $names[(string) $row['Key_name']] = true;
            }
        }

        if (isset($names['idx_auto_gen']) && isset($names['idx_status_type_scheduled'])) {
            $wpdb->query("ALTER TABLE `{$table}` DROP INDEX `idx_status_type_scheduled`");
        }
    }

    /**
     * Schedule daily cleanup task
     *
     * @return void
     */
    private static function schedule_cleanup_or_fail(): void {
        $hook = AS_Registry::HOOK_DAILY_CLEANUP;
        $legacy_hooks = ['seo_gen_dailycleanup', 'seo_gen_daily_cleanup'];
        $timestamp = Plugin_Time::next_site_midnight_utc_ts(Plugin_Time::now_utc_ts());

        // 1. Purge everything first for a clean state
        $legacy_hooks = ['seo_gen_dailycleanup', 'seo_gen_daily_cleanup', 'seo_gen_reconcile_job_timeout'];
        $all_to_purge = array_merge([$hook], $legacy_hooks);
        foreach ($all_to_purge as $h) {
            while (($ts = wp_next_scheduled($h)) !== false) {
                wp_unschedule_event($ts, $h);
            }
            if (function_exists('as_unschedule_all_actions') && self::is_as_initialized()) {
                as_unschedule_all_actions($h);
            }
        }

        // 2. Schedule the canonical hook
        $ok_as = AS_Registry::schedule_daily_cleanup($timestamp);
        $ok_wp = true;

        if (! $ok_as) {
            $ok_wp = (bool) wp_schedule_event($timestamp, 'daily', $hook);
        }

        if (! $ok_as && ! $ok_wp) {
            throw new \RuntimeException('Failed to register cleanup schedules.');
        }

        // v2.29.0: Publish Watchdog — force-publish plugin-owned posts stuck in 'future'.
        // Mirrors the daily-cleanup scheduling pattern so first-time activation
        // gets the watchdog even if Discovery_Bootstrap::schedule_discovery_jobs()
        // has not yet been reached.
        $pw_defaults  = Option_Registry::defaults();
        $pw_enabled   = (int) \get_option( Option_Registry::ENABLE_PUBLISH_WATCHDOG, $pw_defaults[ Option_Registry::ENABLE_PUBLISH_WATCHDOG ] );
        $pw_interval  = (int) \get_option( Option_Registry::PUBLISH_WATCHDOG_INTERVAL, $pw_defaults[ Option_Registry::PUBLISH_WATCHDOG_INTERVAL ] );
        $pw_interval  = max( 60, $pw_interval );
        if ( $pw_enabled ) {
            AS_Registry::schedule_publish_watchdog( $pw_interval );
            \update_option( Option_Registry::PUBLISH_WATCHDOG_APPLIED, $pw_interval );
        } else {
            AS_Registry::unschedule_all( AS_Registry::HOOK_PUBLISH_WATCHDOG );
            \delete_option( Option_Registry::PUBLISH_WATCHDOG_APPLIED );
        }
    }

    /**
     * Run on plugin deactivation
     *
     * @return void
     */
    public static function deactivate(): void {
        self::load_action_scheduler();
        self::clear_scheduled_actions();
        // FINDING-8 FIX: Clear active job option to prevent stale state after reactivation
        \delete_option('seo_gen_active_job');
        // Clear slug migration state and rollback data
        \delete_option('seo_gen_slug_migration_state');
        \delete_option('seo_gen_slug_rollback_data');
        flush_rewrite_rules();
    }

    /**
     * Clear all plugin scheduled actions.
     *
     * @return void
     */
protected static function clear_scheduled_actions(): void {
	$group = AS_Registry::GROUP;

	// Current canonical hooks via AS_Registry constants
	$hooks = [
		AS_Registry::HOOK_DAILY_CLEANUP,
		AS_Registry::HOOK_PROCESS_ITEM,
		AS_Registry::HOOK_CHECK_JOB,
		AS_Registry::HOOK_PASSIVE_DISCOVERY,
		AS_Registry::HOOK_ACTIVE_DISCOVERY,
		AS_Registry::HOOK_SIDELOAD_IMAGE,
		AS_Registry::HOOK_QUEUE_WORKER,
		AS_Registry::HOOK_QUEUE_CLEANUP,
		AS_Registry::HOOK_WP_AUTO_DRAFT_POLL,
		\SEO_Article_Generator\Queue\AS_Registry::HOOK_AUTO_GEN_CRON,
		AS_Registry::HOOK_DELETE_DRAFT,
		AS_Registry::HOOK_PUBLISH_WATCHDOG,
		// Legacy hooks - documented as intentional for cleanup of deprecated hooks
		'seo_gen_daily_cleanup',
		'seo_gen_dailycleanup',
		'seo_gen_generationjob',
		'seo_gen_discoveryjob',
		'seo_gen_processarticle',
		'generate-article-job',
		'process-draft-job',
		'seo_gen_reconcile_job_timeout',
		'seo_gen_process_article',
		'seo_gen_generation_job',
		'seo_gen_discovery_job',
		'seo_gen_check_discovery_job',
        ];

        if (function_exists('as_unschedule_all_actions') && self::is_as_initialized()) {
            foreach ($hooks as $hook) {
                as_unschedule_all_actions($hook, [], $group);
                as_unschedule_all_actions($hook);
            }
        }

        foreach ($hooks as $hook) {
            while (($ts = wp_next_scheduled($hook)) !== false) {
                wp_unschedule_event($ts, $hook);
            }
        }
    }

    /**
     * Create database tables
     *
     * @return void
     */
    private static function create_tables(): void {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();
        $jobs_table      = self::table_jobs();
        $links_table     = self::table_links();
        $locks_table     = self::table_locks();
        $queue_table     = self::table_queue();

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // Audit Fix: Rename misspelled table if it exists
        $legacy_jobs_table = $wpdb->prefix . 'seo_gen_erationjobs';
        $legacy_exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($legacy_jobs_table)));
        $jobs_exists   = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($jobs_table)));

        if ($legacy_exists === $legacy_jobs_table && $jobs_exists !== $jobs_table) {
            $wpdb->query("RENAME TABLE `{$legacy_jobs_table}` TO `{$jobs_table}`");
        }

        // @MODIFIED 2026-03-24: Phase 6 Hardening - Link Table Migration
        $legacy_links_variants = array(
            $wpdb->prefix . 'seointernallinks',
            $wpdb->prefix . 'seo_internal_links'
        );
        $links_exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($links_table)));

        foreach ($legacy_links_variants as $legacy_links) {
            $exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($legacy_links)));
            if ($exists === $legacy_links && $links_exists !== $links_table) {
                $wpdb->query("RENAME TABLE `{$legacy_links}` TO `{$links_table}`");
                $links_exists = $links_table; // Update for subsequent loops
            }
        }

        // Table for queue tickets (Sequential Queue Architecture)
        $queue_sql = "CREATE TABLE {$queue_table} (
id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
type VARCHAR(50) NOT NULL,
reference_id BIGINT UNSIGNED DEFAULT NULL,
payload LONGTEXT NULL,
status VARCHAR(50) NOT NULL DEFAULT '" . \SEO_Article_Generator\Queue\Job_Repository::STATUS_QUEUED . "',
reservation_token CHAR(36) NULL,
attempts INT UNSIGNED NOT NULL DEFAULT 0,
reserved_at DATETIME NULL,
processing_started_at DATETIME NULL,
heartbeat_at DATETIME NULL,
lease_expires_at DATETIME NULL,
available_at DATETIME NOT NULL,
completed_at DATETIME NULL,
created_at DATETIME NOT NULL,
updated_at DATETIME NULL,
PRIMARY KEY  (id),
KEY idx_queue_ready (status, available_at, id),
KEY idx_queue_lease (status, lease_expires_at, id),
KEY idx_queue_heartbeat (status, heartbeat_at, id),
KEY idx_queue_ref (type, reference_id)
) {$charset_collate};";

        // Table for internal links cache
        $links_sql = "CREATE TABLE {$links_table} (
id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
title VARCHAR(255) NOT NULL,
url VARCHAR(255) NOT NULL,
category VARCHAR(100) DEFAULT NULL,
keywords TEXT DEFAULT NULL,
created_at DATETIME NOT NULL,
used_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
PRIMARY KEY  (id)
) {$charset_collate};";

        // Table for generation jobs
        $jobs_sql = "CREATE TABLE {$jobs_table} (
id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
user_id BIGINT UNSIGNED DEFAULT 0,
status VARCHAR(50) NOT NULL DEFAULT 'pending',
queue_job_id BIGINT UNSIGNED DEFAULT NULL,
input_data LONGTEXT NULL,
output_data LONGTEXT NULL,
validation_results LONGTEXT NULL,
debug_data LONGTEXT NULL,
error_message TEXT NULL,
retry_count INT UNSIGNED DEFAULT 0,
hallucination_count INT UNSIGNED DEFAULT 0,
failed_sections_count INT UNSIGNED DEFAULT 0,
validation_errors_count INT UNSIGNED DEFAULT 0,
status_started_at DATETIME NULL,
heartbeat_at DATETIME NULL,
available_at DATETIME NULL,
created_at DATETIME NOT NULL,
completed_at DATETIME NULL,
PRIMARY KEY  (id),
KEY idx_jobs_available (status, available_at, id),
KEY idx_jobs_stale (status, heartbeat_at, status_started_at, id),
KEY idx_jobs_completed (status, completed_at, id),
KEY idx_jobs_queue (queue_job_id),
KEY idx_status_created (status, created_at),
KEY idx_status_started (status, status_started_at),
KEY idx_completed_at (completed_at)
) {$charset_collate};";

        // Table for runtime locks (mutex replacements)
        $locks_sql = "CREATE TABLE {$locks_table} (
lock_name varchar(191) NOT NULL,
owner_key varchar(64) NOT NULL,
lease_expires_at datetime NOT NULL,
heartbeat_at datetime NOT NULL,
created_at datetime NOT NULL,
updated_at datetime NOT NULL,
PRIMARY KEY  (lock_name),
KEY idx_lease_expires_at (lease_expires_at)
) {$charset_collate};";

        // Execute table creation
        \dbDelta($links_sql);
        \dbDelta($jobs_sql);
        \dbDelta($locks_sql);
        \dbDelta($queue_sql);

        // Ensure FULLTEXT index on links table (dbDelta can be unreliable for FULLTEXT)
        $has_ft = $wpdb->get_row("SHOW INDEX FROM `{$links_table}` WHERE Key_name = 'idx_keywords_title' AND Index_type = 'FULLTEXT'");
        if (! $has_ft) {
            $wpdb->query("ALTER TABLE `{$links_table}` DROP INDEX IF EXISTS `idx_keywords_title` ");
            $wpdb->query("ALTER TABLE `{$links_table}` ADD FULLTEXT INDEX `idx_keywords_title` (keywords, title)");
        }
    }

    public static function create_discovery_table(): void {
        global $wpdb;

        $table_name      = self::table_discovery();
        $charset_collate = $wpdb->get_charset_collate();

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

$sql = "CREATE TABLE {$table_name} (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
software_name varchar(255) NOT NULL,
discovered_version varchar(50) NOT NULL,
current_version varchar(50) DEFAULT NULL,
type enum('new','update','legacy','plugin_generated','plugingenerated','plugingeneratedlegacy') NOT NULL DEFAULT 'new',
status ENUM('pending','queued','processing','generating','finalizing','deferred','done','failed','timeout','skippednotnewer','skippedduplicate','ignored') NOT NULL DEFAULT 'pending',
existing_post_id bigint(20) DEFAULT NULL,
matched_post_id bigint(20) unsigned DEFAULT NULL,
draft_post_id bigint(20) DEFAULT NULL,
job_id bigint(20) DEFAULT NULL,
queue_job_id bigint(20) unsigned DEFAULT NULL,
last_job_id bigint(20) DEFAULT NULL,
action_id bigint(20) unsigned DEFAULT NULL,
poll_count int(10) unsigned DEFAULT 0,
consecutive_failures int(10) unsigned DEFAULT 0,
last_failure_at datetime DEFAULT NULL,
error_message text DEFAULT NULL,
source_type varchar(50) DEFAULT 'manual',
source_url text DEFAULT NULL,
source_image_url text DEFAULT NULL,
source_thumbnail_url text DEFAULT NULL,
changelog text DEFAULT NULL,
featured_image_id bigint(20) DEFAULT NULL,
discovered_at datetime DEFAULT NULL,
scheduled_at datetime DEFAULT NULL,
publish_at datetime DEFAULT NULL,
completed_at datetime DEFAULT NULL,
heartbeat_at datetime DEFAULT NULL,
dedupe_key varchar(32) DEFAULT NULL,
created_at datetime DEFAULT NULL,
PRIMARY KEY  (id),
UNIQUE KEY idx_dedupe (dedupe_key),
KEY idx_status (status),
KEY idx_existing_post (existing_post_id),
KEY idx_matched_post (matched_post_id),
KEY idx_job_id (job_id),
KEY idx_queue_job_id (queue_job_id),
KEY idx_status_type_scheduled (status, type, scheduled_at),
KEY idx_auto_gen (status, type, scheduled_at),
KEY idx_status_completed (status, completed_at),
KEY idx_heartbeatat (heartbeat_at)
) {$charset_collate};";

        \dbDelta($sql);
    }

    /**
     * Set default plugin options
     *
     * @return void
     */
private static function set_default_options(): void {
        foreach (Option_Registry::defaults() as $key => $value) {
            if (false === \get_option($key)) {
                \add_option($key, $value);
            }
        }
    }

    /**
     * Check if database needs upgrade
     *
     * @return bool
     */
    public static function needs_upgrade(): bool {
        $current = get_option(self::OPTION_DB_VERSION, '0.0.0');
        $target  = self::DB_VERSION;
        return version_compare($current, $target, '<');
    }

    /**
     * Run after activation/update.
     */
    public static function upgrade(): void {
        $current_db_version = get_option(self::OPTION_DB_VERSION, '0.0.0');

        if (version_compare($current_db_version, self::DB_VERSION, '<')) {
            self::run_installation(false);
        }

        if (version_compare($current_db_version, '1.6.5', '<')) {
            self::backfill_validation_counts();
        }
        if (version_compare($current_db_version, '1.6.6', '<')) {
            self::migrate_legacy_post_meta();
        }
        if (version_compare($current_db_version, '1.6.7', '<')) {
            self::backfill_discovery_section_defaults();
        }
        if (version_compare($current_db_version, '1.6.8', '<')) {
            self::add_source_thumbnail_url_column();
        }
	if (version_compare($current_db_version, '1.6.9', '<')) {
			self::add_links_usage_count_column();
		}
		if (version_compare($current_db_version, '1.7.0', '<')) {
			self::migrate_legacy_draft_meta_keys();
		}
	}

    /**
     * Run all pending column-level ALTER TABLE migrations, idempotently.
     *
     * Must be called BEFORE verify_schema() in run_installation(). Each individual
     * migration is guarded by an INFORMATION_SCHEMA existence check and is safe
     * to call on every activation/upgrade cycle.
     *
     * @return void
     */
    private static function run_column_migrations(): void
    {
        self::add_source_thumbnail_url_column();
        self::add_links_usage_count_column();
        self::add_poll_count_column();
        self::add_failure_breaker_columns();
        self::migrate_dedupe_keys_to_post_id();
    }

    /**
     * Schema migration 2.20.1 — add consecutive_failures + last_failure_at to discovery.
     * Idempotent: safe to run on a table that already has the columns.
     * Powers the Phase 3A per-item failure circuit breaker (park after N consecutive
     * failures so rescan + auto-gen cannot burn AI quota on poison items forever).
     *
     * @throws \RuntimeException on ALTER TABLE failure.
     */
    private static function add_failure_breaker_columns(): void {
        global $wpdb;

        $table = self::table_discovery();

        foreach ( array( 'consecutive_failures', 'last_failure_at' ) as $column ) {
            $col = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COLUMN_NAME
               FROM INFORMATION_SCHEMA.COLUMNS
              WHERE TABLE_SCHEMA = DATABASE()
                AND TABLE_NAME   = %s
                AND COLUMN_NAME  = %s",
                    $table,
                    $column
                )
            );

            if ( $col ) {
                continue; // Column already present — nothing to do.
            }

            $definition = ( $column === 'consecutive_failures' )
                ? '`consecutive_failures` int(10) unsigned DEFAULT 0'
                : '`last_failure_at` datetime DEFAULT NULL';

            $result = $wpdb->query(
                "ALTER TABLE `{$table}` ADD COLUMN {$definition} AFTER `poll_count`"
            );

            if ( $result === false ) {
                throw new \RuntimeException(
                    'Schema migration 2.20.1 failed: could not add ' . $column . '. '
                    . $wpdb->last_error
                );
            }
        }
    }

    /**
     * Schema migration 1.6.8 — add source_thumbnail_url to the discovery table.
     * Idempotent: safe to run on a table that already has the column.
     *
     * @throws \RuntimeException on ALTER TABLE failure.
     */
    private static function add_source_thumbnail_url_column(): void {
        global $wpdb;

        $table = self::table_discovery();

        // INFORMATION_SCHEMA check — avoids a fatal "Duplicate column" error
        // if this migration runs more than once (e.g. plugin re-activated).
        $col = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COLUMN_NAME
               FROM INFORMATION_SCHEMA.COLUMNS
              WHERE TABLE_SCHEMA = DATABASE()
                AND TABLE_NAME   = %s
                AND COLUMN_NAME  = 'source_thumbnail_url'",
                $table
            )
        );

        if ( $col ) {
            return; // Column already present — nothing to do.
        }

        $result = $wpdb->query(
            "ALTER TABLE `{$table}`
             ADD COLUMN `source_thumbnail_url` text DEFAULT NULL
             AFTER `source_image_url`"
        );

        if ( $result === false ) {
            throw new \RuntimeException(
                'Schema migration 1.6.8 failed: could not add source_thumbnail_url. '
                . $wpdb->last_error
            );
        }
    }

    /**
     * Schema migration 1.6.9: add used_count to seogeninternallinks.
     * Idempotent — safe to re-run.
     *
     * @throws \RuntimeException on ALTER TABLE failure.
     */
    private static function add_links_usage_count_column(): void {
        global $wpdb;

        $table = self::table_links();

        $col = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COLUMN_NAME
               FROM INFORMATION_SCHEMA.COLUMNS
              WHERE TABLE_SCHEMA = DATABASE()
                AND TABLE_NAME   = %s
                AND COLUMN_NAME  = 'used_count'",
                $table
            )
        );

        if ( $col ) {
            return;
        }

        $result = $wpdb->query(
            "ALTER TABLE `{$table}` ADD COLUMN `used_count` BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER `created_at`"
        );

        if ( $result === false ) {
            throw new \RuntimeException(
                'Schema migration 1.6.9 failed: could not add used_count. '
                . $wpdb->last_error
            );
        }
    }

    /**
     * Schema migration 2.20.0: add poll_count to discovery table.
     * Idempotent — safe to re-run.
     *
     * @throws \RuntimeException on ALTER TABLE failure.
     */
    private static function add_poll_count_column(): void {
        global $wpdb;

        $table = self::table_discovery();

        $col = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COLUMN_NAME
               FROM INFORMATION_SCHEMA.COLUMNS
              WHERE TABLE_SCHEMA = DATABASE()
                AND TABLE_NAME   = %s
                AND COLUMN_NAME  = 'poll_count'",
                $table
            )
        );

        if ( $col ) {
            return;
        }

        $result = $wpdb->query(
            "ALTER TABLE `{$table}` ADD COLUMN `poll_count` INT UNSIGNED NOT NULL DEFAULT 0 AFTER `action_id`"
        );

        if ( $result === false ) {
            throw new \RuntimeException(
                'Schema migration 2.20.0 failed: could not add poll_count. '
                . $wpdb->last_error
            );
        }
    }

    /**
     * Schema migration: re-key dedupe_key to use post_id for existing posts.
     * Ensures same post+version always produces the same dedupe_key regardless of name variant.
     * Idempotent — safe to re-run.
     */
    private static function migrate_dedupe_keys_to_post_id(): void {
        global $wpdb;

        $table = self::table_discovery();

        $col = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COLUMN_NAME
               FROM INFORMATION_SCHEMA.COLUMNS
              WHERE TABLE_SCHEMA = DATABASE()
                AND TABLE_NAME   = %s
                AND COLUMN_NAME  = 'dedupe_key'",
                $table
            )
        );

        if ( ! $col ) {
            return;
        }

        $migrated = $wpdb->query(
            "UPDATE {$table}
             SET dedupe_key = MD5(CONCAT(CAST(existing_post_id AS CHAR), '|', discovered_version))
             WHERE existing_post_id > 0
               AND existing_post_id IS NOT NULL"
        );

        if ( $migrated > 0 ) {
            $wpdb->query(
                "DELETE t1 FROM {$table} t1
                 INNER JOIN {$table} t2
                 ON t1.dedupe_key = t2.dedupe_key
                    AND t1.id < t2.id
                 WHERE t1.existing_post_id > 0"
            );
        }
    }

    private static function backfill_discovery_section_defaults(): void
    {
        $old_default = array(
            'introduction',
            'features',
            'download',
            'tech_specs',
            'safety',
            'faqs',
        );

        $new_default = array(
            'introduction',
            'features',
            'download',
            'tech_specs',
            'installation',
            'safety',
            'faqs',
            'moat',
        );

        $current = get_option('seo_gen_discovery_sections', false);

        if ($current === false || ! is_array($current)) {
            update_option('seo_gen_discovery_sections', $new_default, false);
            return;
        }

        $sorted_current = array_values(array_unique(array_map('strval', $current)));
        $sorted_old     = $old_default;

        sort($sorted_current);
        sort($sorted_old);

        if ($sorted_current === $sorted_old) {
            update_option('seo_gen_discovery_sections', $new_default, false);
        }
    }

    /**
     * Migrate old seogen_downloads meta to _seo_gen_download_count
     */
    private static function migrate_legacy_post_meta(): void {
        global $wpdb;
        $wpdb->query(
            "UPDATE {$wpdb->postmeta} pm
             SET pm.meta_key = '_seo_gen_download_count'
             WHERE pm.meta_key IN ('seogen_downloads', '_seo_gen_downloads')
               AND NOT EXISTS (
                   SELECT 1 FROM (SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_seo_gen_download_count') AS tmp WHERE tmp.post_id = pm.post_id
               )"
        );
        $wpdb->query("DELETE FROM {$wpdb->postmeta} WHERE meta_key IN ('seogen_downloads', '_seo_gen_downloads')");
    }

    /**
     * Defensive normalization for discovery schema status enum.
     *
     * @return void
     */
    private static function normalize_discovery_schema(): void {
        global $wpdb;

        $table = self::table_discovery();

        if (! self::table_exists($table)) {
            throw new \RuntimeException("Discovery table does not exist: {$table}");
        }

        $result = $wpdb->query(
            "ALTER TABLE `{$table}`
            MODIFY status ENUM(
                'pending',
                'queued',
                'processing',
                'generating',
                'finalizing',
                'deferred',
                'done',
                'failed',
                'timeout',
                'skippednotnewer',
                'skippedduplicate',
                'ignored'
            ) NOT NULL DEFAULT 'pending'"
        );

        if ($result === false) {
            throw new \RuntimeException(
                'Failed to normalize discovery schema: ' . $wpdb->last_error
            );
        }

        $result_type = $wpdb->query(
            "ALTER TABLE `{$table}`
            MODIFY type ENUM(
                'new',
                'update',
                'legacy',
                'plugin_generated',
                'plugingenerated',
                'plugingeneratedlegacy'
            ) NOT NULL DEFAULT 'new'"
        );

        if ($result_type === false) {
            throw new \RuntimeException(
                'Failed to normalize discovery schema type enum: ' . $wpdb->last_error
            );
        }
    }

    /**
     * Migrate legacy seo_gen_* options to standardized seo_gen_* prefix.
     *
     * @return void
     */
    private static function migrate_legacy_options(): void {
        $map = [
            'seogendbversion'                   => self::OPTION_DB_VERSION,
            'seogenversion'                     => self::OPTION_PLUGIN_VER,
            'seogeninstallerror'                => self::OPTION_INSTALL_ERR,
            'seogeninstallstate'                => self::OPTION_INSTALL_STATE,
            'seogen_provider_fallback_order'    => 'seo_gen_provider_fallback_order',
            'seogen_enable_gemini'              => 'seo_gen_enable_gemini',
            'seogen_enable_openai'              => 'seo_gen_enable_openai',
            'seogen_enable_groq'                => 'seo_gen_enable_groq',
            'seogen_model_gemini'               => 'seo_gen_model_gemini',
            'seogen_model_openai'               => 'seo_gen_model_openai',
            'seogen_model_groq'                 => 'seo_gen_model_groq',
            'seogendiscoveryenabled'            => 'seo_gen_discovery_enabled',
            'seogenrssdiscoveryenabled'         => 'seo_gen_rss_discovery_enabled',
            'seogenaidiscoveryenabled'          => 'seo_gen_ai_discovery_enabled',
            'seogenwpautocategoryid'            => 'seo_gen_wp_auto_category_id',
            'seogenautogenerationinterval'      => 'seo_gen_auto_generation_interval',
            'seogenautogenerationbatch'         => 'seo_gen_auto_generation_batch',
            'seogenpassivediscovery'            => 'seo_gen_passive_discovery',
            'seogenactiveaidiscovery'           => 'seo_gen_active_ai_discovery',
            'seogenwpautodraftpoll'             => 'seo_gen_wp_auto_draft_poll',
            'seogenupdatesections'              => 'seo_gen_update_sections',
            'seogendiscoverysections'           => 'seo_gen_discovery_sections',
            'seogeninternallinkcount'         => 'seo_gen_internal_link_count',
        ];

        foreach ($map as $old => $new) {
            $value = get_option($old);
            if (false !== $value) {
                if (false === get_option($new)) {
                    update_option($new, $value, false);
                }
                delete_option($old);
            }
        }

		if (false === \get_option('seo_gen_custom_providers')) {
			\add_option('seo_gen_custom_providers', '[]');
		}
		if (false === \get_option('seo_gen_custom_default_provider')) {
			\add_option('seo_gen_custom_default_provider', '');
		}

		// Specifically migrate old hours-based retention
        $old_hours_key = 'seogendraftretentionhours';
        $new_hours_key = 'seo_gen_draft_retention_hours';
        $days_key      = 'seo_gen_draft_retention_days';
        
        $hours_value = false;
        if (false !== get_option($old_hours_key)) {
            $hours_value = get_option($old_hours_key);
            delete_option($old_hours_key);
        } elseif (false !== get_option($new_hours_key)) {
            $hours_value = get_option($new_hours_key);
            delete_option($new_hours_key);
        }

        if (false !== $hours_value) {
            if (false === get_option($days_key)) {
                $days = max(1, (intval($hours_value) / 24));
                update_option($days_key, ceil($days), false);
            }
        }
    }
    /**
     * Check if Action Scheduler is initialized.
     *
     * @return bool
     */
    private static function is_as_initialized(): bool {
        global $wpdb;
        $table = $wpdb->prefix . 'actionscheduler_actions';
        return self::table_exists($table);
    }

    /**
     * Backfill validation_errors_count for existing jobs to ensure dashboard accuracy.
     */
    private static function backfill_validation_counts(): void {
        global $wpdb;
        $table = self::table_jobs();
        
        // Find failed_validation jobs that might need a count refresh
        $jobs = $wpdb->get_results("SELECT id, validation_results FROM {$table} WHERE status = 'failed_validation' AND (validation_errors_count = 0 OR validation_errors_count IS NULL) LIMIT 300");
        
        if (empty($jobs)) return;

        foreach ($jobs as $job) {
            $val = json_decode($job->validation_results, true);
            $count = count($val['errors'] ?? []);
            if ($count > 0) {
                $wpdb->update($table, ['validation_errors_count' => $count], ['id' => $job->id]);
            }
        }
    }
}

