<?php

if (! defined('ABSPATH')) exit;

$tab   = $tab ?? (isset($_GET['stab']) ? \sanitize_key($_GET['stab']) : 'pending');
$nonce = \wp_create_nonce('seo_gen_nonce');

$bootstrap = $bootstrap ?? ($this instanceof \SEO_Article_Generator\Discovery\Discovery_Bootstrap ? $this : null);

if (! function_exists('seo_gen_dashboard_existing_post_id')) {
	function seo_gen_dashboard_existing_post_id($item): int
	{
		if (! is_array($item)) {
			return 0;
		}

		$post_id = isset($item['existing_post_id']) ? \absint($item['existing_post_id']) : 0;
		return $post_id > 0 ? $post_id : 0;
	}
}

if (! function_exists('seo_gen_dashboard_item_presentation')) {
	function seo_gen_dashboard_item_presentation($item): array
	{
		if (is_array($item) && ! empty($item['typeui']) && is_array($item['typeui'])) {
			return array(
				'type'           => (string) ($item['typeui']['key'] ?? 'new'),
				'label'          => (string) ($item['typeui']['label'] ?? 'New Post'),
				'class'          => (string) ($item['typeui']['class'] ?? 'new'),
				'postid'         => (int) ($item['existing_post_id'] ?? 0),
				'raw_type'       => (string) ($item['type'] ?? ''),
				'canonical_type' => (string) ($item['type'] ?? ''),
			);
		}

	$postid   = seo_gen_dashboard_existing_post_id($item);
	$raw_type = is_array($item) ? (string) ($item['type'] ?? '') : '';

	$classify = 'new';
	$label    = 'New Post';
	$cls      = 'new';

	// When the discovery table says "new", preserve it — do NOT
	// re-classify against the post's runtime signals.
	if ($raw_type === \SEO_Article_Generator\Discovery\Post_Type_Classifier::TYPE_NEW) {
		$classify = \SEO_Article_Generator\Discovery\Post_Type_Classifier::TYPE_NEW;
		$label    = 'New Post';
		$cls      = 'new';
	} elseif ($postid > 0) {
		if (class_exists('\SEO_Article_Generator\Discovery\Post_Type_Classifier')) {
			$resolved = \SEO_Article_Generator\Discovery\Post_Type_Classifier::classify($postid);
			$classify = $resolved;
			$label = \SEO_Article_Generator\Discovery\Post_Type_Classifier::label($resolved);
			if ($resolved === \SEO_Article_Generator\Discovery\Post_Type_Classifier::TYPE_PLUGIN) {
				$cls = 'plugin';
			} elseif ($resolved === \SEO_Article_Generator\Discovery\Post_Type_Classifier::TYPE_PLUGIN_LEGACY) {
				$cls = 'plugin';
			} elseif ($resolved === \SEO_Article_Generator\Discovery\Post_Type_Classifier::TYPE_LEGACY) {
				$cls = 'legacy';
			}
		} else {
			$classify = 'legacy';
			$label = 'Legacy Update';
			$cls = 'legacy';
		}
	}

	return array(
		'type' => $classify,
		'label' => $label,
		'class' => $cls,
		'postid' => $postid,
		'raw_type' => $raw_type,
		'canonical_type' => is_array($item) ? (string) ($item['type'] ?? '') : '',
	);
	}
}

if (! function_exists('seo_gen_dashboard_item_name')) {
	function seo_gen_dashboard_item_name($item): string
	{
		foreach (array('software_name', 'softwarename') as $key) {
			if (is_array($item) && isset($item[$key]) && trim((string) $item[$key]) !== '') {
				return trim((string) $item[$key]);
			}
			if (is_object($item) && isset($item->$key) && trim((string) $item->$key) !== '') {
				return trim((string) $item->$key);
			}
		}

		$post_id = 0;
		if (is_array($item)) {
			$post_id = isset($item['existing_post_id']) ? max(0, (int) $item['existing_post_id']) : (isset($item['existingpostid']) ? max(0, (int) $item['existingpostid']) : 0);
		} elseif (is_object($item)) {
			$post_id = isset($item->existing_post_id) ? max(0, (int) $item->existing_post_id) : 0;
		}

		if ($post_id > 0) {
			$post_title = get_the_title($post_id);
			if (is_string($post_title) && trim($post_title) !== '') {
				return trim($post_title);
			}
		}

		return __('Untitled', 'seo-article-generator');
	}
}

if (! function_exists('seo_gen_dashboard_human_utc_age')) {
	function seo_gen_dashboard_human_utc_age(?string $mysql_utc): string
	{
		if (empty($mysql_utc)) {
			return '—';
		}

		$ts = \strtotime($mysql_utc . ' UTC');
		if (! $ts) {
			return '—';
		}

		return \human_time_diff($ts, \SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts()) . ' ago';
	}
}

if (! function_exists('seo_gen_discovery_is_paused')) {
	function seo_gen_discovery_is_paused(): bool
	{
		// PHASE 6 FIX: Use Option_Registry instead of raw option key
		$defaults = \SEO_Article_Generator\Option_Registry::defaults();
		return ! (bool) \get_option(
			\SEO_Article_Generator\Option_Registry::DISCOVERY_ENABLED,
			$defaults[\SEO_Article_Generator\Option_Registry::DISCOVERY_ENABLED]
		);
	}
}

if (! function_exists('seo_gen_discovery_paused_attr')) {
	function seo_gen_discovery_paused_attr(string $classes = '', bool $pausable = true): string
	{
		$classes = trim($classes);
		if ($pausable) {
			$classes = trim($classes . ' js-pausable-discovery-action');
		}

		$attrs = $classes !== '' ? ' class="' . \esc_attr($classes) . '"' : '';

		if ($pausable) {
			$attrs .= ' data-paused-scope="discovery"';
		}

		if (! $pausable || ! seo_gen_discovery_is_paused()) {
			return $attrs;
		}

		return $attrs . ' disabled="disabled" aria-disabled="true" data-paused-lock="1"';
	}
}

/**
 * Render the pipeline table HTML (called on page load and by AJAX refresh).
 * Extracted to a function so both can share identical markup.
 */
	if (! function_exists('seo_gen_render_pipeline_table')) {
	function seo_gen_render_pipeline_table($items, $is_paused = false)
	{
		if (empty($items)) {
			return '<tr><td colspan="7"><div class="sgd-empty"><span class="dashicons dashicons-yes-alt"></span>No items currently in the pipeline.</div></td></tr>';
		}

		$stage_index = [
			'queued'     => 0,
			'processing' => 1,
			'generating' => 2,
			'finalizing' => 3,
		];

		$labels = [
			'queued'     => 'Queued',
			'processing' => 'Processing',
			'generating' => 'Generating',
			'finalizing' => 'Finalizing',
		];

		ob_start();

		foreach ((array) $items as $item) {
			$row = is_array($item)
				? $item
				: (is_object($item) ? get_object_vars($item) : array());

			$item_id   = (int) ($row['id'] ?? 0);
			$post_id   = seo_gen_dashboard_existing_post_id($row);
			$post_name = $post_id > 0 ? get_the_title($post_id) : '';
			$type_ui   = seo_gen_dashboard_item_presentation($row);
			$type_cls  = (string) ($type_ui['class'] ?? 'new');
			$type_lbl  = (string) ($type_ui['label'] ?? 'New Post');

			$raw_status = (string) ($row['status'] ?? '');
			$status     = isset($labels[$raw_status]) ? $raw_status : 'queued';
			$active_at  = $stage_index[$status];

			$software_name = isset($row['software_name']) ? trim((string) $row['software_name']) : '';
			if ($software_name === '' && $post_name !== '') {
				$software_name = $post_name;
			}
			if ($software_name === '') {
				$software_name = 'Untitled';
			}

			$display = isset($row['display_status']) && is_array($row['display_status'])
				? $row['display_status']
				: array(
					'label' => ucfirst($status),
					'class' => $status,
				);

			$actions = isset($row['allowed_actions']) && is_array($row['allowed_actions'])
				? $row['allowed_actions']
				: array('run_now' => true, 'kill' => true);

			$discovered_version = isset($row['discovered_version']) && $row['discovered_version'] !== ''
				? (string) $row['discovered_version']
				: '—';

			$current_version = isset($row['current_version']) && $row['current_version'] !== ''
				? (string) $row['current_version']
				: '—';

			$display_error = ! empty($row['error_message'])
				? (string) $row['error_message']
				: (string) ($row['job_error'] ?? '');

			$discovered_at = (string) ($row['discovered_at'] ?? '');
			$discovered_ts = $discovered_at !== '' ? strtotime($discovered_at . ' UTC') : 0;
			$scheduled_raw = $row['scheduled_at'] ?? $row['scheduledat'] ?? '';
			$scheduled_ts  = ($scheduled_raw !== '' && $scheduled_raw !== null) ? strtotime($scheduled_raw . ' UTC') : 0;
			$now_utc       = \SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts();
			?>
			<tr id="sgd-pipeline-row-<?php echo $item_id; ?>">
				<td class="name-cell">
					<span class="name-title"><?php echo esc_html($software_name); ?></span>
					<?php if ($post_id > 0): ?>
						<a href="<?php echo esc_url(get_edit_post_link($post_id)); ?>" target="_blank"><?php echo esc_html($post_name); ?></a>
					<?php endif; ?>
				</td>
				<td>
					<div class="version-new"><?php echo esc_html($discovered_version); ?></div>
					<div class="version-old">Current: <?php echo esc_html($current_version); ?></div>
				</td>
				<td>
					<span class="type-pill <?php echo esc_attr($type_cls); ?>"><?php echo esc_html($type_lbl); ?></span>
				</td>
				<td>
					<span class="sgd-badge-status <?php echo esc_attr((string) ($display['class'] ?? $status)); ?>">
						<?php echo esc_html((string) ($display['label'] ?? ucfirst($status))); ?>
					</span>

					<div class="sgd-timeline">
						<?php
						$ordered = ['queued', 'processing', 'generating', 'finalizing'];
						foreach ($ordered as $i => $step) {
							$cls = [];
							if ($i < $active_at) {
								$cls[] = 'done';
							} elseif ($i === $active_at) {
								$cls[] = 'active';
							}
							?>
							<div class="sgd-tl-step <?php echo esc_attr(implode(' ', $cls)); ?>">
								<span class="dot"></span>
								<span><?php echo esc_html($labels[$step]); ?></span>
								<?php if ($i < 3): ?><span class="line"></span><?php endif; ?>
							</div>
							<?php
						}
						?>
					</div>
				</td>
				<td>
					<?php
					$error_msg = ! empty($row['error_message']) ? (string) $row['error_message'] : '';
					$status_key = (string) ($row['status'] ?? '');
					// PHASE 6 FIX: Use Option_Registry instead of raw option key
					$defaults = \SEO_Article_Generator\Option_Registry::defaults();
					$is_paused = ! (bool) \get_option(
						\SEO_Article_Generator\Option_Registry::DISCOVERY_ENABLED,
						$defaults[\SEO_Article_Generator\Option_Registry::DISCOVERY_ENABLED]
					);

					if ($is_paused && in_array($status_key, ['queued', 'processing', 'generating', 'finalizing'], true)) {
						echo '<span class="seo-gen-badge seo-gen-badge--paused" title="Pipeline is paused globally.">Awaiting Resume</span>';
					} elseif ($scheduled_ts > 0 && $scheduled_ts > $now_utc) {
						$remaining = $scheduled_ts - $now_utc;
						$r_h = (int) floor($remaining / 3600);
						$r_m = (int) floor(($remaining % 3600) / 60);
						$r_parts = array();
						if ($r_h > 0) { $r_parts[] = $r_h . 'h'; }
						if ($r_m > 0 || $r_h === 0) { $r_parts[] = $r_m . 'm'; }
						$remaining_str = implode(' ', $r_parts);
						printf(
							'<span title="In %s">%s<br><span style="color:#6b7280; font-size:11px;">(%s)</span></span>',
							esc_attr($remaining_str),
							esc_html(\SEO_Article_Generator\Utils\Plugin_Time::site_datetime($scheduled_ts)),
							esc_html($remaining_str)
						);
					} elseif ($scheduled_ts > 0 && $scheduled_ts <= $now_utc) {
						$overdue = $now_utc - $scheduled_ts;
						$o_h = (int) floor($overdue / 3600);
						$o_m = (int) floor(($overdue % 3600) / 60);
						$o_parts = array();
						if ($o_h > 0) { $o_parts[] = $o_h . 'h'; }
						if ($o_m > 0 || $o_h === 0) { $o_parts[] = $o_m . 'm'; }
						$overdue_str = implode(' ', $o_parts);
						printf(
							'<span style="color:#d97706;" title="Recorded schedule time has passed.">%s<br><span style="font-size:11px;">(overdue %s)</span></span>',
							esc_html(\SEO_Article_Generator\Utils\Plugin_Time::site_datetime($scheduled_ts)),
							esc_html($overdue_str)
						);
					} elseif ($scheduled_ts === 0 && in_array($status_key, ['queued', 'processing', 'generating', 'finalizing'], true)) {
						echo '<span style="color:#6b7280;" title="Action Scheduler will pick this item up shortly.">Queued</span>';
					} elseif ($discovered_ts > 0) {
						printf(
							'<span style="color:#9ca3af;" title="No schedule recorded">%s ago</span>',
							esc_html(human_time_diff($discovered_ts, $now_utc))
						);
					} else {
						echo '<span style="color:#9ca3af;">—</span>';
					}
					?>
				</td>
				<td>
					<?php if ($display_error !== ''): ?>
						<div class="sgd-error-msg"><?php echo esc_html($display_error); ?></div>
					<?php else: ?>
						—
					<?php endif; ?>
				</td>
				<td style="white-space:nowrap;">
					<?php if (! empty($actions['run_now'])) : ?>
						<button<?php echo seo_gen_discovery_paused_attr('sgd-btn-small sgd-run-item-btn'); ?> data-id="<?php echo $item_id; ?>" title="Run now">Run</button>
					<?php endif; ?>
					<?php if (! empty($actions['kill'])) : ?>
						<button class="sgd-btn-small sgd-kill-pipeline-btn" data-id="<?php echo $item_id; ?>" title="Kill item">Kill</button>
					<?php endif; ?>
				</td>
			</tr>
			<?php
		}

		return ob_get_clean();
	}
}

if (! function_exists('seo_gen_render_pending_table')) {
	function seo_gen_render_pending_table($items, $is_paused = false)
	{
		if (empty($items)) {
			return '<tr><td colspan="6"><div class="sgd-empty"><span class="dashicons dashicons-yes-alt"></span>All clear — no items waiting for approval.</div></td></tr>';
		}

		ob_start();
		foreach ((array) $items as $item) {
			$row = is_array($item) ? $item : (is_object($item) ? get_object_vars($item) : array());

			$item_id      = (int) ($row['id'] ?? 0);
			$post_id      = seo_gen_dashboard_existing_post_id($row);
			$display_name = seo_gen_dashboard_item_name($row);
			$type_ui      = seo_gen_dashboard_item_presentation($row);

			$source_url         = isset($row['source_url']) ? (string) $row['source_url'] : '';
			$changelog          = isset($row['changelog']) ? (string) $row['changelog'] : '';
			$discovered_version = isset($row['discovered_version']) ? (string) $row['discovered_version'] : '';
			$current_version    = isset($row['current_version']) ? (string) $row['current_version'] : '';
			$discovered_at      = isset($row['discovered_at']) ? (string) $row['discovered_at'] : '';
			$show_version_old   = $current_version !== '' && $current_version !== 'Unknown'
				&& strcasecmp(trim($current_version), trim($discovered_version)) !== 0;
			?>
			<tr id="sgd-row-<?php echo (int) $item_id; ?>">
				<td class="name-cell">
					<div style="display:flex; align-items:center; gap:8px;">
						<div class="name-title" title="<?php echo esc_attr($display_name); ?>">
							<?php echo esc_html($display_name); ?>
						</div>
						<?php if ($post_id > 0) : ?>
							<a href="<?php echo esc_url(get_edit_post_link($post_id)); ?>" target="_blank" style="flex-shrink:0;">
								<?php esc_html_e('View Existing Post', 'seo-article-generator'); ?>
							</a>
						<?php endif; ?>
					</div>
				</td>

				<td>
					<div class="version-new"><?php echo esc_html($discovered_version); ?></div>
					<?php if ($show_version_old) : ?>
						<div class="version-old"><?php echo esc_html__('was', 'seo-article-generator') . ' ' . esc_html($current_version); ?></div>
					<?php endif; ?>
				</td>

				<td>
					<span class="type-pill <?php echo esc_attr((string) ($type_ui['class'] ?? 'new')); ?>">
						<?php echo esc_html((string) ($type_ui['label'] ?? __('New Post', 'seo-article-generator'))); ?>
					</span>
				</td>

				<td>
					<?php if ($source_url !== '') : ?>
						<a href="<?php echo esc_url($source_url); ?>" target="_blank" class="sgd-btn sgd-btn-view">
							<?php esc_html_e('View Source', 'seo-article-generator'); ?>
						</a>
					<?php endif; ?>

					<?php if ($changelog !== '') : ?>
						<div style="font-size:11px;color:#777;margin-top:4px;max-width:260px;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;">
							<?php echo esc_html(wp_strip_all_tags($changelog)); ?>
						</div>
					<?php endif; ?>
				</td>

				<td style="white-space:nowrap;font-size:12px;color:#777;">
					<?php echo esc_html(seo_gen_dashboard_human_utc_age($discovered_at)); ?>
				</td>

				<td style="white-space:nowrap;">
					<button<?php echo seo_gen_discovery_paused_attr('sgd-btn sgd-btn-approve sgd-approve-btn'); ?>
						data-id="<?php echo (int) $item_id; ?>">
						<?php esc_html_e('Approve', 'seo-article-generator'); ?>
					</button>

					<button class="sgd-btn sgd-btn-ignore sgd-ignore-btn"
						data-id="<?php echo (int) $item_id; ?>"
						style="margin-left:4px;">
						<?php esc_html_e('Dismiss', 'seo-article-generator'); ?>
					</button>
				</td>
			</tr>
			<?php
		}

		return ob_get_clean();
	}
}

if (! function_exists('seo_gen_render_failed_table')) {
	function seo_gen_render_failed_table($items, $is_paused = false)
	{
		if (empty($items)) {
			return '<tr><td colspan="7"><div class="sgd-empty"><span class="dashicons dashicons-smiley"></span>No failures.</div></td></tr>';
		}

		ob_start();

		foreach ((array) $items as $item) {
			$row = is_array($item) ? $item : (is_object($item) ? get_object_vars($item) : array());

			$item_id            = (int) ($row['id'] ?? 0);
			$post_id            = seo_gen_dashboard_existing_post_id($row);
			$display_name       = seo_gen_dashboard_item_name($row);
			$type_ui            = seo_gen_dashboard_item_presentation($row);
			$status             = sanitize_key((string) ($row['status'] ?? 'failed'));
			$status_label       = $status !== '' ? ucfirst($status) : 'Failed';
			$discovered_version = isset($row['discovered_version']) && $row['discovered_version'] !== '' ? (string) $row['discovered_version'] : '—';
			$current_version    = isset($row['current_version']) && $row['current_version'] !== '' ? (string) $row['current_version'] : '';
			$display_error      = ! empty($row['error_message']) ? (string) $row['error_message'] : (string) ($row['job_error'] ?? '');
			$job_id             = (int) ($row['job_id'] ?? 0);
			$failed_actions     = isset($row['allowed_actions']) && is_array($row['allowed_actions'])
				? $row['allowed_actions']
				: array('retry' => true, 'ignore' => true, 'run_now' => true);
			$show_version_old   = $current_version !== '' && $current_version !== 'Unknown'
				&& strcasecmp(trim($current_version), trim($discovered_version)) !== 0;
			?>
			<tr id="sgd-row-<?php echo (int) $item_id; ?>">
				<td class="name-cell">
					<div style="display:flex; align-items:center; gap:8px;">
						<div class="name-title" title="<?php echo esc_attr($display_name); ?>">
							<?php echo esc_html($display_name); ?>
						</div>
						<?php if ($post_id > 0) : ?>
							<a href="<?php echo esc_url(get_edit_post_link($post_id)); ?>" target="_blank" style="flex-shrink:0;">View Post ↗</a>
						<?php endif; ?>
					</div>
				</td>
				<td>
					<span class="version-new"><?php echo esc_html($discovered_version); ?></span>
					<?php if ($show_version_old) : ?>
						<div class="version-old">was: <?php echo esc_html($current_version); ?></div>
					<?php endif; ?>
				</td>
				<td>
					<span class="type-pill <?php echo esc_attr((string) ($type_ui['class'] ?? 'new')); ?>">
						<?php echo esc_html((string) ($type_ui['label'] ?? __('New Post', 'seo-article-generator'))); ?>
					</span>
				</td>
				<td>
					<span class="sgd-badge-status <?php echo esc_attr($status); ?>">
						<?php echo esc_html($status_label); ?>
					</span>
				</td>
				<td>
					<?php if ($display_error !== '') : ?>
						<div class="sgd-error-msg"><?php echo esc_html($display_error); ?></div>
					<?php else : ?>
						<span style="color:#aaa;font-size:11px;">No details</span>
					<?php endif; ?>
				</td>
				<td style="font-size:11px;color:#aaa;">
					<?php if ($job_id > 0) : ?>
						#<?php echo (int) $job_id; ?>
					<?php else : ?>
						—
					<?php endif; ?>
				</td>
				<td style="white-space:nowrap;">
					<?php if (! empty($failed_actions['retry'])) : ?>
						<button type="button"<?php echo seo_gen_discovery_paused_attr('sgd-btn sgd-btn-retry sgd-retry-btn'); ?> data-id="<?php echo (int) $item_id; ?>">Retry</button>
					<?php endif; ?>
					<?php if (! empty($failed_actions['run_now'])) : ?>
						<button type="button"<?php echo seo_gen_discovery_paused_attr('sgd-btn-small sgd-run-item-btn'); ?> data-id="<?php echo (int) $item_id; ?>" style="margin-left:4px;">Run Now</button>
					<?php endif; ?>
					<?php if (! empty($failed_actions['ignore'])) : ?>
						<button class="sgd-btn sgd-btn-ignore sgd-ignore-btn" data-id="<?php echo (int) $item_id; ?>" style="margin-left:4px;">Dismiss</button>
					<?php endif; ?>
				</td>
			</tr>
			<?php
		}

		return ob_get_clean();
	}
}

/**
 * Render a single row for the "Completed" tab.
 * Extracted to a function for reuse in "Today" and "History" sections.
 */
if (! function_exists('seo_gen_render_done_row')) {
	function seo_gen_render_done_row($item)
	{
		$row = is_array($item) ? $item : (is_object($item) ? get_object_vars($item) : array());

		\ob_start();

		$item_id            = (int) ($row['id'] ?? 0);
		$post_title         = seo_gen_dashboard_item_name($row);
		$discovered_version = isset($row['discovered_version']) && $row['discovered_version'] !== '' ? (string) $row['discovered_version'] : '—';
		$current_version    = isset($row['current_version']) ? (string) $row['current_version'] : '';
		$type_ui            = seo_gen_dashboard_item_presentation($row);
		$completed_source   = ! empty($row['completed_at']) ? (string) $row['completed_at'] : (string) ($row['discovered_at'] ?? '');
		$completed_ts       = $completed_source !== '' ? \strtotime($completed_source . ' UTC') : 0;
		$failed_count       = (int) ($row['failed_sections_count'] ?? 0);
		$hallucination_count= (int) ($row['hallucination_count'] ?? 0);
		$val_errors         = (int) ($row['validation_errors_count'] ?? 0);
		$validation_errors  = !empty($row['validation_error_items']) && is_array($row['validation_error_items'])
			? $row['validation_error_items']
			: array();
		$validation_title  = '';
		if (!empty($validation_errors)) {
			$validation_title = \esc_attr(implode(" | ", $validation_errors));
		}
		$job_id             = (int) ($row['job_id'] ?? 0);
		$done_post_id       = seo_gen_dashboard_existing_post_id($row);
		$show_version_old   = $current_version !== '' && $current_version !== 'Unknown'
			&& strcasecmp(trim($current_version), trim($discovered_version)) !== 0;
		?>
		<tr id="sgd-row-<?php echo (int) $item_id; ?>">
			<td class="name-cell">
				<div style="display:flex; align-items:center; gap:8px;">
					<div class="name-title" title="<?php echo \esc_attr($post_title); ?>">
						<?php echo \esc_html($post_title); ?>
					</div>
				</div>
			</td>
			<td>
				<span class="version-new"><?php echo \esc_html($discovered_version); ?></span>
				<?php if ($show_version_old) : ?>
					<div class="version-old">was: <?php echo \esc_html($current_version); ?></div>
				<?php endif; ?>
			</td>
			<td>
				<span class="type-pill <?php echo esc_attr((string) ($type_ui['class'] ?? 'new')); ?>">
					<?php echo esc_html((string) ($type_ui['label'] ?? __('New Post', 'seo-article-generator'))); ?>
				</span>
			</td>
			<td>
				<?php 
				$post_status = $done_post_id > 0 ? get_post_status($done_post_id) : 'publish';
				if ($post_status === 'future'): ?>
					<span class="sgd-badge-status waiting" style="background:#dbeafe; color:#1e40af; padding:2px 8px; border-radius:12px; font-size:11px; font-weight:600;" title="Post is generated and scheduled in WordPress to go live later.">SCHEDULED</span>
				<?php else: ?>
					<span class="sgd-badge-status done" style="background:#def7ec; color:#03543f; padding:2px 8px; border-radius:12px; font-size:11px; font-weight:600;">DONE</span>
				<?php endif; ?>
			</td>
			<td style="white-space:nowrap;font-size:12px;color:#777;">
				<?php echo \esc_html($completed_ts > 0 ? \human_time_diff($completed_ts, \SEO_Article_Generator\Utils\Plugin_Time::now_utc_ts()) . ' ago' : '—'); ?>
				<?php if ($completed_ts > 0) : ?>
					<div style="font-size:9px; color:#999; margin-top:2px;"><?php echo \esc_html(\SEO_Article_Generator\Utils\Plugin_Time::site_datetime($completed_ts)); ?></div>
				<?php endif; ?>
			</td>
			<td style="white-space:nowrap;">
				<?php if ($job_id > 0) : ?>
					<div style="font-size:10px;color:#bbb;">Job #<?php echo (int) $job_id; ?></div>

					<?php if ($failed_count > 0): ?>
						<div style="font-size:9px; color:#d97706; margin-top:2px;" title="Sections failed AI generation and were omitted or kept from old version">
							⚠️ <?php echo $failed_count; ?> section faults
						</div>
					<?php endif; ?>

					<?php if ($hallucination_count > 0): ?>
						<div style="font-size:9px; color:#dc2626; margin-top:2px;" title="Potential AI hallucinations or factual inaccuracies detected">
							🚩 <?php echo $hallucination_count; ?> factual risks
						</div>
					<?php endif; ?>

					<?php if ($val_errors > 0): ?>
						<div style="font-size:9px; color:#ef4444; margin-top:2px;" title="<?php echo $validation_title; ?>">
							❌ <?php echo $val_errors; ?> val errors
						</div>
					<?php endif; ?>
				<?php endif; ?>
			</td>
			<td style="white-space:nowrap;">
				<?php if ($done_post_id > 0) : ?>
					<a href="<?php echo \esc_url(\get_permalink($done_post_id)); ?>" target="_blank" class="sgd-btn" style="background:#6b7280;color:#fff;text-decoration:none;font-size:11px;padding:3px 8px;">View Live ↗</a>
					<a href="<?php echo \esc_url(\get_edit_post_link($done_post_id)); ?>" target="_blank" class="sgd-btn" style="margin-left:4px;background:#4b5563;color:#fff;text-decoration:none;font-size:11px;padding:3px 8px;">Edit</a>
				<?php endif; ?>
				<button class="sgd-btn sgd-btn-ignore sgd-ignore-btn" data-id="<?php echo (int) $item_id; ?>" style="margin-left:4px;font-size:11px;padding:3px 8px;">✕ Dismiss</button>
			</td>
		</tr>
		<?php

		return \ob_get_clean();
	}
}

$snapshot = (isset($bootstrap) && method_exists($bootstrap, 'get_dashboard_ui_snapshot'))
	? (array) $bootstrap->get_dashboard_ui_snapshot()
	: array();

$discovery_enabled = ! empty($snapshot['discovery']['enabled']) ? 1 : 0;

$tabs      = (array) ($snapshot['tabs'] ?? array());
$cards     = (array) ($snapshot['cards'] ?? array());
$counts    = (array) ($cards['counts'] ?? array());
$today     = (array) ($cards['today'] ?? array());
$activity  = (array) ($cards['activity'] ?? array());
$health_snapshot  = (array) ($cards['health'] ?? array());
$api_snapshot     = (array) ($cards['api']['stats'] ?? array());
$api_pause_snapshot = (array) ($cards['api']['pause'] ?? array());
$scanners  = (array) ($cards['scanners'] ?? array());
$sources_snapshot = (array) ($cards['sources'] ?? array());
$next_runs  = (array) ($cards['next_runs'] ?? array());
$as_queue_count = (int) ($cards['as_queue'] ?? 0);

$pending_list = is_array($snapshot['lists']['pending'] ?? null) ? $snapshot['lists']['pending'] : array();
$pending      = isset($pending_list['rows']) && is_array($pending_list['rows']) ? $pending_list['rows'] : (array) $pending_list;
$pending_html = isset($pending_list['html'])
    ? (string) $pending_list['html']
    : seo_gen_render_pending_table($pending, ! $discovery_enabled);

$pipeline_list = is_array($snapshot['lists']['pipeline'] ?? null) ? $snapshot['lists']['pipeline'] : array();
$pipeline_rows = isset($pipeline_list['rows']) && is_array($pipeline_list['rows']) ? $pipeline_list['rows'] : (array) $pipeline_list;
$pipeline_html = isset($pipeline_list['html'])
	? (string) $pipeline_list['html']
	: seo_gen_render_pipeline_table($pipeline_rows, ! $discovery_enabled);

$failed_list = is_array($snapshot['lists']['failed'] ?? null) ? $snapshot['lists']['failed'] : array();
$failed_rows = isset($failed_list['rows']) && is_array($failed_list['rows']) ? $failed_list['rows'] : (array) $failed_list;
$failed_html = isset($failed_list['html'])
	? (string) $failed_list['html']
	: seo_gen_render_failed_table($failed_rows, ! $discovery_enabled);

$completed_list = is_array($snapshot['lists']['completed'] ?? null)
    ? $snapshot['lists']['completed']
    : array();

$completed_group_map = is_array($completed_list['groups'] ?? null)
    ? $completed_list['groups']
    : array();

$completed_group_today = is_array($completed_group_map['today'] ?? null)
    ? $completed_group_map['today']
    : array(
        'count' => 0,
        'html'  => '',
    );

$completed_group_history = is_array($completed_group_map['history'] ?? null)
    ? $completed_group_map['history']
    : array(
        'count' => 0,
        'html'  => '',
    );

$completed_today_total = max(0, (int) ($completed_group_today['count'] ?? 0));
$completed_history_total = max(0, (int) ($completed_group_history['count'] ?? 0));
$completed_today_markup = (string) ($completed_group_today['html'] ?? '');
$completed_history_markup = (string) ($completed_group_history['html'] ?? '');
$completed_visible_total = $completed_today_total + $completed_history_total;

$active_gen_id = (int) ($health_snapshot['active_job_id'] ?? 0);

// PHASE 6 FIX: Use Option_Registry instead of raw option keys
$defaults = \SEO_Article_Generator\Option_Registry::defaults();
$posts_per_day       = (int) \get_option(\SEO_Article_Generator\Option_Registry::POSTS_PER_DAY, $defaults[\SEO_Article_Generator\Option_Registry::POSTS_PER_DAY]);
$updates_per_day     = (int) \get_option(\SEO_Article_Generator\Option_Registry::UPDATES_PER_DAY, $defaults[\SEO_Article_Generator\Option_Registry::UPDATES_PER_DAY]);
$posts_today_count   = (int) ($activity['new_posts_today'] ?? 0);
$updates_today_count = (int) ($activity['updated_posts_today'] ?? 0);
$update_cap_reached  = $updates_today_count >= $updates_per_day;
$post_cap_reached    = $posts_today_count >= $posts_per_day;

$as_debug_info = [
	'worker'  => (int) ($health_snapshot['worker_next'] ?? 0),
	'rss'     => (int) ($next_runs['rss'] ?? 0),
	'ai'      => (int) ($next_runs['ai'] ?? 0),
	'wp_auto' => (int) ($next_runs['wp_auto'] ?? 0),
	'pending' => $as_queue_count,
	'failed'  => 0,
];

$api_paused         = (bool) ($api_pause_snapshot['paused'] ?? false);
$api_cooldown_until = $api_pause_snapshot['until'] ?? 0;
$api_pause_reason   = $api_pause_snapshot['reason'] ?? '';
$api_resume_diff    = $api_pause_snapshot['resume_diff'] ?? '';
// PHASE 6 FIX: Use Option_Registry instead of raw option key
$defaults = \SEO_Article_Generator\Option_Registry::defaults();
$ai_provider        = \get_option(\SEO_Article_Generator\Option_Registry::API_PROVIDER, $defaults[\SEO_Article_Generator\Option_Registry::API_PROVIDER]);

$providers_detail_raw = is_array($api_pause_snapshot['providers_detail'] ?? null) ? $api_pause_snapshot['providers_detail'] : array();
$providers_detail  = array();
$active_providers  = array();
foreach ($providers_detail_raw as $_pd) {
	if (isset($_pd['provider'])) {
		$providers_detail[$_pd['provider']] = $_pd;
		if (! empty($_pd['enabled']) && ! empty($_pd['available'])) {
			$active_providers[$_pd['provider']] = $_pd;
		}
	}
}
unset($_pd);

$provider_names_map = array(
	'gemini'     => 'Gemini',
);
if (class_exists('\\SEO_Article_Generator\\AI\\Provider_Registry')) {
	$registry = \SEO_Article_Generator\AI\Provider_Registry::get_instance();
	foreach ($registry->get_custom_providers() as $profile) {
		if (! empty($profile['id'])) {
			$provider_names_map[strtolower($profile['id'])] = $profile['name'] ?? $profile['id'];
		}
	}
}
$is_single_provider   = (count($active_providers) === 1);
$single_provider_id   = $is_single_provider ? (string) array_key_first($active_providers) : '';
$single_provider_data = $is_single_provider ? ($active_providers[$single_provider_id] ?? array()) : array();

if ($api_paused && $ai_provider && $api_pause_reason) {
	$api_pause_reason = \strtoupper($ai_provider) . ': ' . $api_pause_reason;
}

// PHASE 6 FIX: Use Option_Registry instead of raw option keys
$rss_enabled = (int) ($scanners['rss']['enabled'] ?? \get_option(\SEO_Article_Generator\Option_Registry::RSS_DISCOVERY_ENABLED, $defaults[\SEO_Article_Generator\Option_Registry::RSS_DISCOVERY_ENABLED]));
$ai_enabled  = (int) ($scanners['ai']['enabled'] ?? \get_option(\SEO_Article_Generator\Option_Registry::AI_DISCOVERY_ENABLED, $defaults[\SEO_Article_Generator\Option_Registry::AI_DISCOVERY_ENABLED]));

$has_usable_sources = ! empty($sources_snapshot['has_usable']);
?>

<div class="wrap seo-gen-discovery" id="sgd-dashboard-root"
     data-discovery-paused="<?php echo seo_gen_discovery_is_paused() ? '1' : '0'; ?>"
     data-provider-names="<?php echo \esc_attr(\wp_json_encode($provider_names_map)); ?>">

	<style>
		/* ── Layout ── */
		.seo-gen-discovery {
			font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
		}

		.seo-gen-discovery h1 {
			margin-bottom: 0;
		}

		/* ── Stats Bar ── */
		.sgd-stats {
			display: flex;
			gap: 12px;
			flex-wrap: wrap;
			margin: 16px 0 20px;
		}

		.sgd-stat {
			background: #fff;
			border: 1px solid #ddd;
			border-radius: 6px;
			padding: 14px 20px;
			min-width: 130px;
			text-align: center;
			flex: 1;
		}

		.sgd-stat .sgd-num {
			display: block;
			font-size: 28px;
			font-weight: 700;
			line-height: 1;
		}

		.sgd-stat .sgd-lbl {
			display: block;
			font-size: 12px;
			color: #777;
			margin-top: 4px;
			text-transform: uppercase;
			letter-spacing: .05em;
		}

		.sgd-stat.pending {
			border-top: 3px solid #f0ad4e;
		}

		.sgd-stat.pipeline {
			border-top: 3px solid #0073aa;
		}

		.sgd-stat.done {
			border-top: 3px solid #46b450;
		}

		.sgd-stat.failed {
			border-top: 3px solid #dc3232;
		}

		.sgd-stat.in-progress {
			border-top: 3px solid #0073aa;
		}

		.sgd-stat.shares-card {
			border-top: 3px solid #8b5cf6;
			background: linear-gradient(135deg, #faf5ff 0%, #fff 100%);
		}

		.sgd-stat.next-run {
			border-top: 3px solid #a0a0a0;
			min-width: 200px;
		}

		/* ── Tab Nav ── */
		.sgd-tabs {
			display: flex;
			gap: 0;
			border-bottom: 2px solid #ddd;
			margin-bottom: 20px;
		}

		.sgd-tab {
			padding: 10px 18px;
			cursor: pointer;
			border: 1px solid transparent;
			border-bottom: none;
			margin-bottom: -2px;
			border-radius: 4px 4px 0 0;
			font-weight: 500;
			color: #555;
			background: #f6f6f6;
		}

		.sgd-tab:hover {
			background: #eee;
		}

		.sgd-tab.active {
			background: #fff;
			border-color: #ddd;
			color: #0073aa;
			font-weight: 600;
		}

		.sgd-tab .sgd-badge {
			background: #777;
			color: #fff;
			font-size: 10px;
			font-weight: 700;
			border-radius: 10px;
			padding: 1px 7px;
			margin-left: 6px;
		}

		.sgd-tab.active .sgd-badge,
		.sgd-tab[data-tab="pending"] .sgd-badge {
			background: #f0ad4e;
		}

		.sgd-tab[data-tab="pipeline"] .sgd-badge {
			background: #0073aa;
		}

		.sgd-tab[data-tab="done"] .sgd-badge {
			background: #46b450;
		}

		.sgd-tab[data-tab="failed"] .sgd-badge {
			background: #dc3232;
		}

		/* ── Panes ── */
		.sgd-pane {
			display: none;
		}

		.sgd-pane.active {
			display: block;
		}

		/* ── Tables ── */
		.sgd-table {
			width: 100%;
			border-collapse: collapse;
			background: #fff;
		}

		.sgd-table th {
			background: #f9f9f9;
			border-bottom: 2px solid #ddd;
			padding: 10px 12px;
			text-align: left;
			font-size: 12px;
			text-transform: uppercase;
			letter-spacing: .05em;
			color: #555;
		}

		.sgd-table td {
			padding: 12px;
			border-bottom: 1px solid #f0f0f0;
			vertical-align: middle;
			font-size: 13px;
		}

		.sgd-table tr:last-child td {
			border-bottom: none;
		}

		.sgd-table tr:hover td {
			background: #fafafa;
		}

		.sgd-table .name-cell {
			font-weight: 600;
			max-width: 350px;
		}

		.sgd-table .name-title {
			display: block;
			overflow: hidden;
			text-overflow: ellipsis;
			white-space: nowrap;
			margin-bottom: 0;
		}

		.sgd-table .name-cell a {
			color: #0073aa;
			text-decoration: none;
			font-size: 11px;
			font-weight: 400;
			opacity: 0.8;
		}

		.sgd-table .name-cell a:hover {
			text-decoration: underline;
			opacity: 1;
		}

		.sgd-table .version-new {
			color: #46b450;
			font-weight: 600;
			font-size: 13px;
		}

		.sgd-table .version-old {
			color: #999;
			font-size: 11px;
			margin-top: 2px;
		}

		/* ── Status Badges ── */
		.sgd-badge-status {
			display: inline-flex;
			align-items: center;
			gap: 6px;
			padding: 3px 10px;
			border-radius: 12px;
			font-size: 11px;
			font-weight: 600;
			text-transform: uppercase;
			letter-spacing: .05em;
			white-space: nowrap;
		}

		.sgd-badge-status.queued {
			background: #e8f4fd;
			color: #0073aa;
		}

		.sgd-badge-status.processing {
			background: #fff3cd;
			color: #856404;
		}

		.sgd-badge-status.generating {
			background: #d4edda;
			color: #155724;
		}

		.sgd-badge-status.waiting {
			background: #f0f4f8;
			color: #5a6b7d;
			border: 1px solid #d1d9e4;
		}

		.sgd-badge-status.done {
			background: #d4edda;
			color: #155724;
		}

		.sgd-badge-status.failed {
			background: #f8d7da;
			color: #721c24;
		}

		.sgd-badge-status.timeout {
			background: #f8d7da;
			color: #721c24;
		}

		.sgd-badge-status.pending {
			background: #fff3cd;
			color: #856404;
		}

		/* ── Type Pills ── */
		.type-pill {
			display: inline-block;
			padding: 2px 9px;
			border-radius: 4px;
			font-size: 10px;
			font-weight: 700;
			text-transform: uppercase;
			letter-spacing: .05em;
			white-space: nowrap;
		}

		.type-pill.new {
			background: #d4edda;
			color: #155724;
			border: 1px solid #c3e6cb;
		}

		.type-pill.legacy {
			background: #fff3cd;
			color: #856404;
			border: 1px solid #ffeeba;
		}

		.type-pill.plugin {
			background: #d1ecf1;
			color: #0c5460;
			border: 1px solid #bee5eb;
		}

		.type-pill.update {
			background: #e0e7ff;
			color: #3730a3;
			border: 1px solid #c7d2fe;
		}

		/* ── Pipeline Timeline ── */
		.sgd-timeline {
			display: flex;
			align-items: center;
			gap: 4px;
			margin: 4px 0 0;
			font-size: 10px;
			color: #aaa;
			white-space: nowrap;
		}

		.sgd-tl-step {
			display: flex;
			align-items: center;
			gap: 3px;
		}

		.sgd-tl-step .dot {
			width: 8px;
			height: 8px;
			border-radius: 50%;
			background: #ddd;
		}

		.sgd-tl-step.done .dot {
			background: #46b450;
		}

		.sgd-tl-step.active .dot {
			background: #0073aa;
			animation: pulse 1.5s infinite;
		}

		.sgd-tl-step .line {
			width: 16px;
			height: 2px;
			background: #ddd;
		}

		.sgd-tl-step.done .line {
			background: #46b450;
		}

		@keyframes pulse {

			0%,
			100% {
				box-shadow: 0 0 0 0 rgba(0, 115, 170, .4);
			}

			50% {
				box-shadow: 0 0 0 4px rgba(0, 115, 170, 0);
			}
		}

		/* ── Spinner ── */
		.sgd-spinner {
			display: inline-block;
			width: 12px;
			height: 12px;
			border: 2px solid #ccc;
			border-top-color: #0073aa;
			border-radius: 50%;
			animation: spin .8s linear infinite;
		}

		@keyframes spin {
			to {
				transform: rotate(360deg);
			}
		}

		/* ── Buttons ── */
		.sgd-btn {
			display: inline-block;
			padding: 5px 12px;
			border-radius: 4px;
			font-size: 12px;
			font-weight: 600;
			cursor: pointer;
			border: none;
			text-decoration: none;
			line-height: 1.5;
		}

		.sgd-btn-approve {
			background: #0073aa;
			color: #fff;
		}

		.sgd-btn-approve:hover {
			background: #005a87;
			color: #fff;
		}

		.sgd-btn-ignore {
			background: transparent;
			color: #dc3232;
			border: 1px solid #dc3232;
		}

		.sgd-btn-ignore:hover {
			background: #dc3232;
			color: #fff;
		}

		.sgd-btn-retry {
			background: #f0ad4e;
			color: #fff;
		}

		.sgd-btn-retry:hover {
			background: #d68910;
			color: #fff;
		}

		/* @MODIFIED 2026-03-04 - New Card Buttons */
		.sgd-card-actions {
			margin-top: 10px;
			padding-top: 8px;
			border-top: 1px solid #eee;
			display: flex;
			gap: 6px;
			justify-content: center;
		}

		.sgd-btn-small {
			padding: 3px 8px;
			font-size: 10px;
			background: #f0f0f0;
			color: #555;
			border: 1px solid #ccc;
			border-radius: 3px;
			text-decoration: none;
			cursor: pointer;
		}

		.sgd-btn-small:hover {
			background: #e0e0e0;
			color: #333;
		}

		.sgd-btn-accent {
			background: #7c3aed;
			color: #fff;
			border-color: #6d28d9;
		}

		.sgd-btn-accent:hover {
			background: #6d28d9;
			color: #fff;
		}

		.sgd-btn-danger-link {
			color: #dc3232;
			background: none;
			border: none;
			padding: 0;
			font-size: 11px;
			text-decoration: underline;
			cursor: pointer;
		}

		.sgd-btn-danger-link:hover {
			color: #a00;
		}

		.sgd-quota-paused {
			background: #fff8f8;
			border: 1px solid #fecaca;
			color: #b91c1c;
			padding: 3px 5px;
			border-radius: 4px;
			font-size: 10px;
			margin-top: 4px;
			text-align: center;
		}

		/* ── API Card v2 – MODIFIED 2026-04-03 ── */
		.sgd-api-metrics {
			display: flex; align-items: stretch;
			background: #f9fafb; border: 1px solid #eee;
			border-radius: 5px; padding: 4px 3px; margin: 4px 0 0;
		}
		.sgd-api-metric-item {
			flex: 1; display: flex; flex-direction: column;
			align-items: center; gap: 2px; padding: 0 4px;
		}
		.sgd-api-metric-divider {
			width: 1px; background: #e5e7eb; align-self: stretch; flex-shrink: 0; margin: 2px 0;
		}
		.sgd-api-metric-icon { font-size: 12px; font-weight: 700; line-height: 1; }
		.sgd-api-metric-pass .sgd-api-metric-icon { color: #16a34a; }
		.sgd-api-metric-fail .sgd-api-metric-icon { color: #dc2626; }
		.sgd-api-metric-nums { display: flex; align-items: baseline; gap: 2px; }
		.sgd-api-metric-today { font-size: 12px; font-weight: 700; color: #1f2937; }
		.sgd-api-metric-sep   { font-size: 10px; color: #d1d5db; }
		.sgd-api-metric-total { font-size: 10px; color: #6b7280; }
		.sgd-api-metric-lbl   { font-size: 9px; text-transform: uppercase; letter-spacing: .06em; color: #9ca3af; }
		.sgd-api-section-divider { height: 1px; background: #eee; margin: 4px 0 3px; }
		.sgd-api-mode-tag {
			font-size: 9px; text-transform: uppercase; letter-spacing: .08em;
			color: #aaa; font-weight: 600; margin-bottom: 2px;
		}
		.sgd-api-mode-fallback { color: #0369a1; }
		.sgd-provider-row {
			display: flex; align-items: center; gap: 4px;
			font-size: 10px; color: #555; line-height: 1.4;
		}
		.sgd-provider-name   { flex: 1; }
		.sgd-provider-counts { color: #888; font-weight: 600; font-size: 10px; min-width: 36px; text-align: right; }
		.sgd-provider-badge  {
			font-size: 9px; font-weight: 700; padding: 1px 5px;
			border-radius: 9999px; white-space: nowrap; flex-shrink: 0;
		}
		.sgd-badge-active   { color: #15803d; background: #dcfce7; }
		.sgd-badge-idle     { color: #9ca3af; background: #f3f4f6; }
		.sgd-badge-cooldown { color: #1d4ed8; background: #dbeafe; }
		.sgd-badge-misconfig{ color: #92400e; background: #fef3c7; }
		.sgd-api-single-provider {
			display: flex; align-items: center; gap: 6px;
			background: #f9fafb; border: 1px solid #eee; border-radius: 5px; padding: 7px 10px;
		}
		.sgd-api-single-name { font-size: 13px; font-weight: 700; color: #1f2937; flex: 1; }

		.sgd-stat[data-tab],
		.sgd-jump-tab {
			cursor: pointer;
			transition: all 0.2s ease;
		}

		.sgd-stat[data-tab]:hover,
		.sgd-jump-tab:hover {
			transform: translateY(-2px);
			box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
		}

		.sgd-toggle-card {
			cursor: pointer;
			transition: all 0.2s ease;
		}

		.sgd-toggle-card:hover {
			transform: translateY(-2px);
			box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
		}

		.sgd-btn-view {
			background: #6c757d;
			color: #fff;
			font-size: 11px;
			padding: 3px 8px;
		}

		.sgd-btn-view:hover {
			background: #545b62;
			color: #fff;
		}

		/* ── Live refresh indicator ── */
		.sgd-live {
			display: flex;
			align-items: center;
			gap: 6px;
			font-size: 11px;
			color: #777;
		}

		.sgd-live-dot {
			width: 7px;
			height: 7px;
			border-radius: 50%;
			background: #46b450;
			animation: pulse 2s infinite;
		}

		/* ── Error detail ── */
		.sgd-error-msg {
			font-size: 11px;
			color: #721c24;
			background: #f8d7da;
			padding: 4px 8px;
			border-radius: 3px;
			margin-top: 4px;
			max-width: 280px;
			word-break: break-all;
		}

		/* ── Empty state ── */
		.sgd-empty {
			text-align: center;
			padding: 40px;
			color: #aaa;
		}

		.sgd-empty .dashicons {
			font-size: 36px;
			display: block;
			margin-bottom: 8px;
		}

		/* ── Next run info ── */
		.sgd-next-run-val {
			font-size: 12px;
			font-weight: 600;
		}

		/* @MODIFIED 2026-03-09: History Styles */
		.sgd-history-header {
			background: #fdfdfd;
			padding: 10px 15px;
			border-radius: 6px;
			border: 1px solid #eee;
			margin: 20px 0 10px;
			display: flex;
			justify-content: space-between;
			align-items: center;
		}
/* --- Switch Toggle Styles --- */
.sgd-switch {
  position: relative;
  display: inline-block;
  width: 32px;
  height: 18px;
}

.sgd-switch input { 
  opacity: 0;
  width: 0;
  height: 0;
}

.sgd-slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
  border-radius: 18px;
}

.sgd-slider:before {
  position: absolute;
  content: "";
  height: 12px;
  width: 12px;
  left: 3px;
  bottom: 3px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
  border-radius: 50%;
}

input:checked + .sgd-slider {
  background-color: #46b450;
}

input:focus + .sgd-slider {
  box-shadow: 0 0 1px #46b450;
}

input:checked + .sgd-slider:before {
  -webkit-transform: translateX(14px);
  -ms-transform: translateX(14px);
  transform: translateX(14px);
}
/* --- End Switch Toggle Styles --- */

		.sgd-history-title {
			font-weight: 700;
			color: #666;
			font-size: 14px;
			text-transform: uppercase;
			letter-spacing: 0.05em;
		}
	</style>

	<!-- ============================================================ -->
	<!-- HEADER: Title + Action Bar -->
	<!-- ============================================================ -->
	<div style="display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:10px; margin-bottom:12px;">
		<h1 style="margin:0;"><?php \esc_html_e('Discovery Dashboard', 'seo-article-generator'); ?></h1>
		<div class="sgd-live">
			<span class="sgd-live-dot"></span>
			<span id="sgd-global-refresh-status">Live Monitoring</span>
		</div>
	</div>

	<!-- ============================================================ -->
	<!-- STATS BAR — Row 1: Discovery Pipeline Counts -->
	<!-- ============================================================ -->
	<div class="sgd-stats" style="margin-top:14px;">

		<!-- System Health -->
		<div id="sgd-health-stat-card"
			 class="sgd-stat"
			 style="border-top:3px solid <?php echo esc_attr($health_snapshot['color']); ?>; border-color:<?php echo esc_attr($health_snapshot['border_color']); ?>; min-width:160px;">
			<span id="sgd-health-status-text"
				  class="sgd-num"
				  style="color:<?php echo esc_attr($health_snapshot['color']); ?>; font-size:20px;">
				<?php echo esc_html($health_snapshot['icon'] . ' ' . $health_snapshot['label']); ?>
			</span>
			<span class="sgd-lbl">System Health</span>
			<div id="sgd-health-status-desc" style="font-size:10px; color:#999; margin-top:4px;">
				<?php echo esc_html($health_snapshot['description']); ?>
			</div>

			<div class="sgd-as-debug" style="display:none; font-size:9px; text-align:left; background:#f0f0f0; padding:5px; margin-top:8px; border-radius:3px; color:#666;">
				<strong>AS Debug</strong><br>
				Worker: <?php echo $as_debug_info['worker'] ? \SEO_Article_Generator\Utils\Plugin_Time::site_datetime($as_debug_info['worker']) : 'OFF'; ?><br>
				RSS: <?php echo $as_debug_info['rss'] ? \SEO_Article_Generator\Utils\Plugin_Time::site_datetime($as_debug_info['rss']) : 'OFF'; ?><br>
				AI: <?php echo $as_debug_info['ai'] ? \SEO_Article_Generator\Utils\Plugin_Time::site_datetime($as_debug_info['ai']) : 'OFF'; ?><br>
				WP Auto: <?php echo $as_debug_info['wp_auto'] ? \SEO_Article_Generator\Utils\Plugin_Time::site_datetime($as_debug_info['wp_auto']) : 'OFF'; ?><br>
				Group Pending: <?php echo (int) $as_debug_info['pending']; ?><br>
				Group Failed: <?php echo (int) $as_debug_info['failed']; ?>
			</div>
			<script>
				window.sgd_show_health_debug = function() {
					jQuery('.sgd-as-debug').toggle();
				};
			</script>

			<div class="sgd-card-actions" style="margin-top:6px; display:flex; flex-wrap:wrap; gap:4px;">
				<button id="sgd-repair-queue" class="sgd-btn-small" style="background:#dc3232; color:#fff; border-color:#b91c1c;">↺ Repair</button>
				<button id="sgd-health-diag" class="sgd-btn-small" title="Run deep diagnostic check">🔍 Diag</button>
				<button id="sgd-reset-as-queue" class="sgd-btn-small" title="Clear all pending/failed AS actions and release cooldowns"> Reset (<?php echo (int) $as_queue_count; ?>)</button>
				<button id="sgd-purge-history" class="sgd-btn-small" style="color:#dc3232; border-color:#fca5a5;" title="TRUNCATE Discovery Table (Safe)">🗑 Purge</button>
				<button id="sgd-purge-drafts" class="sgd-btn-small" style="color:#b45309; border-color:#fbbf24; background:#fffbeb;" title="Delete processed WP-Auto draft posts">🗑 Drafts</button>
				<button id="sgd-fix-block-encoding" class="sgd-btn-small" style="background:#7c3aed; color:#fff; border-color:#6d28d9;" title="Fix broken unicode encoding in block comments of existing posts">🔧 Block Fix</button>
			</div>

			<?php if ($active_gen_id): ?>
				<div style="margin-top:10px; padding:6px; background:#f0f9ff; border:1px solid #bae6fd; border-radius:4px; font-size:11px; color:#0369a1;">
					<span style="display:block; font-weight:600; margin-bottom:2px;">🔄 Gen Active</span>
					Job #<?php echo $active_gen_id; ?>
				</div>
			<?php endif; ?>
		</div>

		<!-- In Progress: Combined Pending + Pipeline -->
		<div class="sgd-stat in-progress" data-tab="pending" title="View pending items" style="border-top:3px solid #0073aa; min-width:140px;">
			<span id="sgd-card-in-progress-value" class="sgd-num" style="color:#0073aa;">
				<?php echo (int) (($tabs['pending'] ?? 0) + ($tabs['pipeline'] ?? 0)); ?>
			</span>
			<span class="sgd-lbl">In Progress</span>
			<div style="font-size:10px; color:#999; margin-top:4px;">
				<span id="sgd-card-pending-mini">⏳ <?php echo (int) ($tabs['pending'] ?? 0); ?> pending</span>
				<span style="margin:0 3px; color:#ccc;">·</span>
				<span id="sgd-card-pipeline-mini">⚙️ <?php echo (int) ($tabs['pipeline'] ?? 0); ?> pipeline</span>
			</div>
			<?php if ((int) ($tabs['pending'] ?? 0) > 0): ?>
				<div style="margin-top:6px;">
					<button id="sgd-kill-pending-card" class="sgd-btn-danger-link" title="Clear all items waiting for approval">🗑 Clear All</button>
				</div>
			<?php endif; ?>
		</div>

		<!-- Completed -->
		<div class="sgd-stat done" data-tab="done" style="border-top:3px solid #46b450; min-width:140px;">
			<span id="sgd-card-done-value" class="sgd-num" style="color:#46b450;">
				<?php echo (int) ($tabs['done'] ?? 0); ?>
			</span>
			<span class="sgd-lbl">Completed</span>
			<div id="sgd-card-done-today-note" style="font-size:10px; color:#999; margin-top:4px;">
				Today: <?php echo (int) ($today['done_today'] ?? 0); ?>
			</div>
		</div>

		<!-- Shares: Buffer + Jetpack -->
		<?php
			$shares_data = \SEO_Article_Generator\Discovery\Discovery_Bootstrap::get_social_shares_snapshot();
			$total_shares = $shares_data['total'] ?? 0;
			$buffer_total = $shares_data['buffer_total'] ?? 0;
			$jetpack_total = $shares_data['jetpack_total'] ?? 0;
		?>
		<div class="sgd-stat shares-card" style="border-top:3px solid #8b5cf6; min-width:200px; text-align:left;">
			<div style="display:flex; align-items:baseline; gap:8px; margin-bottom:6px;">
				<span id="sgd-card-shares-total" class="sgd-num" style="color:#8b5cf6; font-size:26px;">
					<?php echo (int) $total_shares; ?>
				</span>
				<span class="sgd-lbl" style="margin-top:0;">Shares</span>
			</div>
			<div style="display:flex; gap:12px; font-size:11px; color:#666;">
				<div style="display:flex; align-items:center; gap:4px;">
					<span style="width:8px; height:8px; border-radius:50%; background:#0068ff; display:inline-block;"></span>
					<strong id="sgd-card-buffer-total" style="color:#0068ff;"><?php echo (int) $buffer_total; ?></strong>
					<span>Buffer</span>
				</div>
				<div style="display:flex; align-items:center; gap:4px;">
					<span style="width:8px; height:8px; border-radius:50%; background:#f56e28; display:inline-block;"></span>
					<strong id="sgd-card-jetpack-total" style="color:#f56e28;"><?php echo (int) $jetpack_total; ?></strong>
					<span>Jetpack</span>
				</div>
			</div>
			<?php if (!empty($shares_data['by_platform'])): ?>
				<div id="sgd-card-shares-breakdown" style="margin-top:8px; font-size:10px; color:#888; display:flex; flex-wrap:wrap; gap:4px 10px;">
					<?php foreach ($shares_data['by_platform'] as $platform => $counts): ?>
						<span>
							<?php echo esc_html(ucfirst($platform)); ?>:
							<?php echo (int) ($counts['buffer'] ?? 0); ?>B
							<?php echo (int) ($counts['jetpack'] ?? 0); ?>J
						</span>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>

		<!-- Failed / Timeout -->
		<div class="sgd-stat failed" data-tab="failed" style="border-top:3px solid #dc3232; min-width:140px;">
			<span id="sgd-card-failed-value" class="sgd-num" style="color:#dc3232;">
				<?php echo (int) ($tabs['failed'] ?? 0); ?>
			</span>
			<span class="sgd-lbl">Failed / Timeout</span>
			<div id="sgd-card-failed-today-note" style="font-size:10px; color:#999; margin-top:4px;">
				Today: <?php echo (int) ($today['failed_today'] ?? 0); ?>
			</div>
		</div>

	</div>

	<!-- ============================================================ -->
	<!-- STATS BAR — Row 2: API + Posts + Health -->
	<!-- ============================================================ -->
	<div class="sgd-stats" style="margin-top:8px;">

		<!-- API Calls Card – MODIFIED 2026-04-03: top = metrics, bottom = provider status -->
		<div class="sgd-stat" style="border-top:3px solid #7c3aed; min-width:175px; text-align:left; padding-bottom:8px;">

			<!-- ── TOP: headline count ── -->
			<div style="text-align:center;">
				<span id="sgd-api-attempts-today" class="sgd-num" style="color:#7c3aed; font-size:18px; line-height:1;">
					<?php echo (int) ($api_snapshot['attempts_today'] ?? 0); ?>
				</span>
				<span class="sgd-lbl" style="margin-top:2px; display:block;">AI Requests Today</span>
				<div style="font-size:10px; color:#aaa; margin-top:2px; text-transform:uppercase; letter-spacing:.04em;">
					Total&nbsp;<strong id="sgd-api-attempts-total" style="color:#555; font-size:12px; text-transform:none; letter-spacing:0;">
						<?php echo \number_format((int) ($api_snapshot['attempts_total'] ?? 0)); ?>
					</strong>
				</div>
			</div>

			<!-- ── Pass / Fail metrics ── -->
			<div class="sgd-api-metrics">
				<div class="sgd-api-metric-item sgd-api-metric-pass">
					<span class="sgd-api-metric-icon">✓</span>
					<div class="sgd-api-metric-nums">
						<strong id="sgd-api-success-today" class="sgd-api-metric-today"><?php echo (int) ($api_snapshot['success_today'] ?? 0); ?></strong>
						<span class="sgd-api-metric-sep">/</span>
						<span id="sgd-api-success-total" class="sgd-api-metric-total"><?php echo \number_format((int) ($api_snapshot['success_total'] ?? 0)); ?></span>
					</div>
					<span class="sgd-api-metric-lbl">Pass</span>
				</div>
				<div class="sgd-api-metric-divider"></div>
				<div class="sgd-api-metric-item sgd-api-metric-fail">
					<span class="sgd-api-metric-icon">✗</span>
					<div class="sgd-api-metric-nums">
						<strong id="sgd-api-failures-today" class="sgd-api-metric-today"><?php echo (int) ($api_snapshot['failures_today'] ?? 0); ?></strong>
						<span class="sgd-api-metric-sep">/</span>
						<span id="sgd-api-failures-total" class="sgd-api-metric-total"><?php echo \number_format((int) ($api_snapshot['failures_total'] ?? 0)); ?></span>
					</div>
					<span class="sgd-api-metric-lbl">Fail</span>
				</div>
			</div>

			<!-- ── Quota paused alert – id preserved for existing JS ── -->
			<div id="sgd-api-quota-wrap">
				<?php if ($api_paused): ?>
					<div class="sgd-quota-paused">
						<strong>Quota Paused</strong>
						<?php if ($api_pause_reason): ?>
							<div style="font-size:9px;margin-bottom:2px;"><?php echo \esc_html($api_pause_reason); ?></div>
						<?php endif; ?>
						<span>Resumes in: <?php echo $api_resume_diff ? \esc_html($api_resume_diff) : '&mdash;'; ?></span>
						<div style="margin-top:3px;">
							<button id="sgd-reset-api-cooldown" class="sgd-btn-small"
									style="background:#fee2e2;border-color:#fca5a5;color:#991b1b;"
									title="Emergency manual override of API cooldown">Reset</button>
						</div>
					</div>
				<?php endif; ?>
			</div>

			<!-- ── Section divider ── -->
			<div class="sgd-api-section-divider"></div>

			<!-- ── BOTTOM: provider status panel – id preserved for JS re-render ── -->
			<div id="sgd-api-provider-panel">
				<?php if ($is_single_provider && $single_provider_id): ?>
					<!-- Single Provider Mode -->
					<div class="sgd-api-mode-tag">Single Provider</div>
					<div class="sgd-api-single-provider">
						<span class="sgd-api-single-name"><?php 
							$single_pid_lower = strtolower($single_provider_id);
							echo \esc_html($provider_names_map[$single_pid_lower] ?? \ucfirst($single_provider_id)); 
						?></span>
						<?php
						$sp_state   = $single_provider_data['state']      ?? 'ok';
						$sp_cooling = ! empty($single_provider_data['cooling']);
						$sp_diff    = $single_provider_data['resume_diff'] ?? '';
						$sp_reason  = $single_provider_data['reason']     ?? '';
						if ($sp_cooling): ?>
							<span class="sgd-provider-badge sgd-badge-cooldown"
								  title="<?php echo \esc_attr($sp_reason); ?>">
								❄ Rate Limit<?php if ($sp_diff): ?> · <?php echo \esc_html($sp_diff); ?><?php endif; ?>
							</span>
						<?php elseif ($sp_state === 'misconfigured'): ?>
							<span class="sgd-provider-badge sgd-badge-misconfig">⚠ Not Configured</span>
						<?php else: ?>
							<span class="sgd-provider-badge sgd-badge-active">● Active</span>
						<?php endif; ?>
					</div>

				<?php else: ?>
					<!-- Fallback Mode -->
					<div class="sgd-api-mode-tag sgd-api-mode-fallback">Fallback Mode</div>
					<?php
					$aiclient = class_exists('SEO_Article_Generator\\AI\\AI_Client') ? 'SEO_Article_Generator\\AI\\AI_Client' : null;
					$all_pids = $aiclient ? $aiclient::get_all_providers() : array('gemini', 'openai', 'groq', 'perplexity');
					foreach ($all_pids as $providerid):
						$pdata   = $providers_detail[$providerid] ?? array();
						$pstats  = (array) ($api_snapshot['providers'][$providerid] ?? array());
						$today   = (int) ($pstats['success_today'] ?? $pstats['today']  ?? 0);
						$total   = (int) ($pstats['success_total'] ?? $pstats['total']  ?? 0);
						$p_state = $pdata['state']   ?? 'ok';
						$cooling = ! empty($pdata['cooling']);
						$p_diff  = $pdata['resume_diff'] ?? '';
						$p_rsn   = $pdata['reason']     ?? '';
						$p_en    = ! empty($pdata['enabled']);
						$p_av    = ! empty($pdata['available']);
					?>
					<div class="sgd-provider-row">
						<span class="sgd-provider-name"><?php 
							$pid_lower = strtolower($providerid);
							echo \esc_html($provider_names_map[$pid_lower] ?? \ucfirst($providerid)); 
						?></span>
						<span class="sgd-provider-counts"><?php echo $today; ?> / <?php echo \number_format($total); ?></span>
						<?php if ($cooling): ?>
							<span class="sgd-provider-badge sgd-badge-cooldown"
								  title="<?php echo \esc_attr($p_rsn); ?>">
								❄<?php if ($p_diff): ?>&nbsp;<?php echo \esc_html($p_diff); ?><?php endif; ?>
							</span>
						<?php elseif ($p_state === 'misconfigured'): ?>
							<span class="sgd-provider-badge sgd-badge-misconfig">⚠</span>
						<?php elseif ($p_en && $p_av): ?>
							<span class="sgd-provider-badge sgd-badge-active">●</span>
						<?php else: ?>
							<span class="sgd-provider-badge sgd-badge-idle">–</span>
						<?php endif; ?>
					</div>
					<?php endforeach; ?>
				<?php endif; ?>
			</div>

		</div>

		<!-- Update Fetcher (Manual Triggers + Schedule) -->
		<div class="sgd-stat" style="border-top:3px solid #f0ad4e; min-width:180px;">
			<span class="sgd-lbl" style="font-size:13px; font-weight:700; color:#555; margin-bottom:8px;">Update Scanner</span>

			<div id="sgd-sources-health" style="font-size:10px; color:#888; margin-bottom:10px;">
				<?php echo esc_html($sources_snapshot['summary']); ?>
			</div>

			<div style="background:#f9fafb; border:1px solid #eee; border-radius:4px; padding:8px; text-align:left;">
				<div id="sgd-scanner-times" style="font-size:10px; color:#777; margin-bottom:10px;">
					<div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
						<span>RSS Scan: <strong id="sgd-card-rss-state"><?php echo esc_html($scanners['rss']['label'] ?? ($rss_enabled ? 'Scheduled' : 'Disabled')); ?></strong></span>
						<label class="sgd-switch" title="Toggle RSS Discovery">
							<input id="sgd-toggle-rss" type="checkbox"<?php echo seo_gen_discovery_paused_attr('sgd-toggle-scanner'); ?> data-type="rss" <?php checked($rss_enabled, 1); ?>>
							<span class="sgd-slider"></span>
						</label>
					</div>
					<div style="display:flex; justify-content:space-between; align-items:center;">
						<span>AI Scout: <strong id="sgd-card-ai-state"><?php echo esc_html($scanners['ai']['label'] ?? ($ai_enabled ? 'Scheduled' : 'Disabled')); ?></strong></span>
						<label class="sgd-switch" title="Toggle AI Scout">
							<input id="sgd-toggle-ai" type="checkbox"<?php echo seo_gen_discovery_paused_attr('sgd-toggle-scanner'); ?> data-type="ai" <?php checked($ai_enabled, 1); ?>>
							<span class="sgd-slider"></span>
						</label>
					</div>
					<div style="display:flex; justify-content:space-between; align-items:center; margin-top:4px;">
						<span>
							New + Legacy Only
							<strong id="sgd-card-plugin-filter-state">
								<?php
								echo esc_html(
									(string) (
										$scanners['plugin_filter']['label']
										?? (((int) ($scanners['plugin_filter']['enabled'] ?? 0) === 1) ? 'On' : 'Off')
									)
								);
								?>
							</strong>
						</span>
						<label class="sgd-switch" title="Keep plugin-generated discoveries visible, but block them until zones are added manually">
							<input
								id="sgd-toggle-plugin-filter"
								type="checkbox"
								<?php checked((int) ($scanners['plugin_filter']['enabled'] ?? 0), 1); ?>
							>
							<span class="sgd-slider"></span>
						</label>
					</div>
				</div>
				<div id="sgd-plugin-filter-note" style="font-size:10px; color:#777; margin-top:6px;">
					<?php
					echo esc_html(
						(string) (
							$scanners['plugin_filter']['message']
							?? 'All discovery types are allowed.'
						)
					);
					?>
				</div>
				<div class="sgd-card-actions">
					<button id="sgd-run-rss"<?php echo seo_gen_discovery_paused_attr('sgd-btn-small'); ?> title="Trigger manual RSS discovery scan" <?php disabled($rss_enabled, 0); ?>>▶ RSS</button>
					<button id="sgd-run-ai-scout"<?php echo seo_gen_discovery_paused_attr('sgd-btn-small'); ?> title="Trigger manual AI update scout" <?php disabled($ai_enabled, 0); ?>>🔍 AI Scout</button>
				</div>
				<div id="sgd-scanner-status-note" style="font-size:10px; color:#777; margin-top:8px;"></div>
			</div>
		</div>

		<!-- Generation Activities: Completed Breakdown -->
		<div class="sgd-stat" data-tab="done" style="border-top:3px solid #46b450; min-width:220px; cursor:pointer;" title="View Completed tab">
			<span class="sgd-lbl" style="font-size:13px; font-weight:700; color:#555; margin-bottom:8px;">Generation Activities</span>

			<div style="display:grid; grid-template-columns:1fr 1px 1fr; align-items:center; background:#f9fafb; border:1px solid #eee; border-radius:4px; padding:10px 8px; margin-top:6px; gap:0;">
				<!-- New Posts Column -->
				<div style="text-align:center; padding:0 6px;">
					<span class="sgd-lbl" style="font-size:9px; text-transform:uppercase; letter-spacing:.05em; color:#aaa; display:block; margin-bottom:2px;">New Posts</span>
					<span id="sgd-card-activity-new" style="color:#0ea5e9; font-size:22px; font-weight:700; display:block; line-height:1;"><?php echo (int) ($activity['new_posts_today'] ?? 0); ?></span>
					<span style="font-size:9px; color:#bbb;">Today</span>
					<div style="margin-top:5px; padding-top:5px; border-top:1px dashed #eee;">
						<span id="sgd-card-activity-new-total" style="font-size:13px; font-weight:700; color:#555;"><?php echo (int) ($activity['new_posts_total'] ?? 0); ?></span>
						<span style="font-size:9px; color:#bbb; display:block;">All Time</span>
					</div>
				</div>

				<!-- Divider -->
				<div style="background:#eee; height:60px; width:1px;"></div>

				<!-- Updates Column -->
				<div style="text-align:center; padding:0 6px;">
					<span class="sgd-lbl" style="font-size:9px; text-transform:uppercase; letter-spacing:.05em; color:#aaa; display:block; margin-bottom:2px;">Updates</span>
					<span id="sgd-card-activity-updated" style="color:#f59e0b; font-size:22px; font-weight:700; display:block; line-height:1;"><?php echo (int) ($activity['updated_posts_today'] ?? 0); ?></span>
					<span style="font-size:9px; color:#bbb;">Today</span>
					<div style="margin-top:5px; padding-top:5px; border-top:1px dashed #eee;">
						<span id="sgd-card-activity-updated-total" style="font-size:13px; font-weight:700; color:#555;"><?php echo (int) ($activity['updated_posts_total'] ?? 0); ?></span>
						<span style="font-size:9px; color:#bbb; display:block;">All Time</span>
					</div>
				</div>
			</div>

			<div style="font-size:11px; color:#999; margin-top:8px; text-align:center;">
				Total Completed: <strong style="color:#46b450;"><?php echo \number_format((int) ($tabs['done'] ?? 0)); ?></strong>
			</div>
		</div>

		<!-- Discovery Status (Interactive Toggle) -->
		<div id="sgd-status-toggle"
			class="sgd-stat sgd-toggle-card <?php echo $discovery_enabled ? 'is-running' : 'is-paused'; ?>"
			style="border-top:3px solid <?php echo $discovery_enabled ? '#46b450' : '#f0ad4e'; ?>;"
			data-enabled="<?php echo $discovery_enabled; ?>">

			<span id="sgd-status-icon" style="font-size:24px; margin-bottom:4px; display:block;">
				<?php echo $discovery_enabled ? '▶' : 'Ⅱ'; ?>
			</span>
			<span id="sgd-status-text" class="sgd-num" style="color:<?php echo $discovery_enabled ? '#46b450' : '#f0ad4e'; ?>; font-size:18px;">
				<?php echo $discovery_enabled ? 'Running' : 'Paused'; ?>
			</span>
			<span class="sgd-lbl">Discovery Control</span>
			<div style="font-size:10px; color:#999; margin-top:4px;">Stops new discovery and manual queue triggers</div>
		</div>

	</div>


	<!-- ============================================================ -->
	<!-- TAB NAVIGATION -->
	<!-- ============================================================ -->
	<div class="sgd-tabs">
		<div class="sgd-tab <?php echo $tab === 'pending' ? 'active' : ''; ?>" data-tab="pending">
			Pending Approval
			<span id="sgd-tab-badge-pending" class="sgd-badge"><?php echo (int) ($tabs['pending'] ?? 0); ?></span>
		</div>
		<div class="sgd-tab <?php echo $tab === 'pipeline' ? 'active' : ''; ?>" data-tab="pipeline">
			In Pipeline
			<span id="sgd-tab-badge-pipeline" class="sgd-badge"><?php echo (int) ($tabs['pipeline'] ?? 0); ?></span>
		</div>
		<div class="sgd-tab <?php echo $tab === 'done' ? 'active' : ''; ?>" data-tab="done">
			Completed
			<span id="sgd-tab-badge-done" class="sgd-badge"><?php echo (int) ($tabs['done'] ?? 0); ?></span>
		</div>
		<div class="sgd-tab <?php echo $tab === 'failed' ? 'active' : ''; ?>" data-tab="failed">
			Failed / Timeout
			<span id="sgd-tab-badge-failed" class="sgd-badge"><?php echo (int) ($tabs['failed'] ?? 0); ?></span>
		</div>
		<!-- @MODIFIED 2026-03-02 - Added Sources tab -->
		<div class="sgd-tab <?php echo $tab === 'sources' ? 'active' : ''; ?>" data-tab="sources">
			Sources
		</div>
		<!-- @MODIFIED 2026-03-02 - Added WP Auto Settings tab -->
		<div class="sgd-tab <?php echo $tab === 'wp-auto' ? 'active' : ''; ?>" data-tab="wp-auto">
			WP Auto Settings
		</div>
	</div>

	<!-- ============================================================ -->
	<!-- TAB: PENDING APPROVAL -->
	<!-- ============================================================ -->
	<div class="sgd-pane <?php echo $tab === 'pending' ? 'active' : ''; ?>" id="sgd-pane-pending">
		<table class="sgd-table">
			<thead>
				<tr>
					<th><?php esc_html_e('Software', 'seo-article-generator'); ?></th>
					<th><?php esc_html_e('Version', 'seo-article-generator'); ?></th>
					<th><?php esc_html_e('Type', 'seo-article-generator'); ?></th>
					<th><?php esc_html_e('Source Preview', 'seo-article-generator'); ?></th>
					<th><?php esc_html_e('Discovered', 'seo-article-generator'); ?></th>
					<th><?php esc_html_e('Actions', 'seo-article-generator'); ?></th>
				</tr>
			</thead>
			<tbody id="sgd-pending-body">
				<?php echo $pending_html; ?>
			</tbody>
		</table>
	</div>

	<!-- ============================================================ -->
	<!-- TAB: IN PIPELINE (auto-refreshes every 15s) -->
	<!-- ============================================================ -->
	<div class="sgd-pane <?php echo $tab === 'pipeline' ? 'active' : ''; ?>" id="sgd-pane-pipeline">

		<div style="margin-bottom:12px; display:flex; justify-content:space-between; align-items:center;">
			<div style="display:flex; align-items:center; gap:10px;">
				<p style="margin:0;font-size:13px;color:#555;">
					Items approved and actively being processed. This panel refreshes automatically.
				</p>
				<button id="sgd-run-queue-now"<?php echo seo_gen_discovery_paused_attr('sgd-btn sgd-btn-approve'); ?> style="font-size:11px;padding:4px 10px;" <?php disabled($discovery_enabled, 0); ?>>▶ Run Queue Now</button>
			</div>
			<div class="sgd-live">
				<span class="sgd-live-dot"></span>
				<span id="sgd-pipeline-refresh-status">Auto-refreshing every 15s</span>
			</div>
		</div>
		<table class="sgd-table">
			<thead>
				<tr>
					<th style="width: 25%;"><?php \esc_html_e('Software', 'seo-article-generator'); ?></th>
					<th style="width: 15%;"><?php \esc_html_e('Version', 'seo-article-generator'); ?></th>
					<th style="width: 10%;"><?php \esc_html_e('Type', 'seo-article-generator'); ?></th>
					<th style="width: 20%;"><?php \esc_html_e('Status', 'seo-article-generator'); ?></th>
					<th style="width: 10%;"><?php \esc_html_e('Scheduled', 'seo-article-generator'); ?></th>
					<th style="width: 10%;"><?php \esc_html_e('Error / Log', 'seo-article-generator'); ?></th>
					<th style="width: 10%;"><?php \esc_html_e('Actions', 'seo-article-generator'); ?></th>
				</tr>
			</thead>
			<tbody id="sgd-pipeline-body">
				<?php echo !empty($pipeline['html']) ? $pipeline['html'] : seo_gen_render_pipeline_table($pipeline['rows'] ?? array(), !$discovery_enabled); ?>
			</tbody>
		</table>

	</div>

	<!-- ============================================================ -->
	<!-- TAB: COMPLETED -->
	<!-- ============================================================ -->
	<div class="sgd-pane <?php echo $tab === 'done' ? 'active' : ''; ?>" id="sgd-pane-done">
		<div id="sgd-done-empty-state" class="sgd-empty" <?php echo $completed_visible_total > 0 ? 'style="display:none;"' : ''; ?>>
			<span class="dashicons dashicons-archive"></span>
			<?php esc_html_e('No completed items yet.', 'seo-article-generator'); ?>
		</div>

		<div id="sgd-done-today-section" <?php echo $completed_today_total > 0 ? '' : 'style="display:none;"'; ?>>
			<div class="sgd-history-header" style="background:#f0fdf4;border-color:#dcfce7;">
				<span class="sgd-history-title" style="color:#15803d;"><?php esc_html_e('Generated Today', 'seo-article-generator'); ?></span>
				<span id="sgd-done-today-count" style="font-size:11px;color:#166534;font-weight:600;">
					<?php echo (int) $completed_today_total; ?> <?php esc_html_e('completions', 'seo-article-generator'); ?>
				</span>
			</div>
			<table class="sgd-table">
				<thead>
					<tr>
						<th><?php esc_html_e('Software', 'seo-article-generator'); ?></th>
						<th><?php esc_html_e('Version', 'seo-article-generator'); ?></th>
						<th><?php esc_html_e('Type', 'seo-article-generator'); ?></th>
						<th><?php esc_html_e('Status', 'seo-article-generator'); ?></th>
						<th><?php esc_html_e('Completed', 'seo-article-generator'); ?></th>
						<th><?php esc_html_e('Actions', 'seo-article-generator'); ?></th>
					</tr>
				</thead>
				<tbody id="sgd-done-today-body"><?php echo $completed_today_markup; ?></tbody>
			</table>
		</div>

		<div id="sgd-done-history-section" <?php echo $completed_history_total > 0 ? '' : 'style="display:none;"'; ?>>
			<div class="sgd-history-header">
				<span class="sgd-history-title"><?php esc_html_e('History', 'seo-article-generator'); ?></span>
				<div style="display:flex;align-items:center;gap:10px;">
					<span id="sgd-done-history-count" style="font-size:11px;color:#666;font-weight:600;">
						<?php echo (int) $completed_history_total; ?> <?php esc_html_e('items', 'seo-article-generator'); ?>
					</span>
					<button id="sgd-clear-history" class="sgd-btn-small" style="color:#dc3232;border-color:#fca5a5;" title="<?php esc_attr_e('Remove items older than 72 hours', 'seo-article-generator'); ?>">
						<?php esc_html_e('Clear History', 'seo-article-generator'); ?>
					</button>
				</div>
			</div>
			<table class="sgd-table">
				<thead>
					<tr>
						<th><?php esc_html_e('Software', 'seo-article-generator'); ?></th>
						<th><?php esc_html_e('Version', 'seo-article-generator'); ?></th>
						<th><?php esc_html_e('Type', 'seo-article-generator'); ?></th>
						<th><?php esc_html_e('Status', 'seo-article-generator'); ?></th>
						<th><?php esc_html_e('Completed', 'seo-article-generator'); ?></th>
						<th><?php esc_html_e('Actions', 'seo-article-generator'); ?></th>
					</tr>
				</thead>
				<tbody id="sgd-done-history-body"><?php echo $completed_history_markup; ?></tbody>
			</table>
		</div>
	</div>

	<!-- ============================================================ -->
	<!-- TAB: FAILED / TIMEOUT -->
	<!-- ============================================================ -->
	<div class="sgd-pane <?php echo $tab === 'failed' ? 'active' : ''; ?>" id="sgd-pane-failed">
		<div style="margin-bottom: 12px; display: flex; justify-content: flex-end;">
			<button type="button" id="sgd-retry-all-failed" class="sgd-btn sgd-btn-retry" title="Move all failed items back to the queue.">Retry All Failed</button>
		</div>

		<table class="sgd-table">
			<thead>
				<tr>
					<th>Software</th>
					<th>Version</th>
					<th>Type</th>
					<th>Status</th>
					<th>Error</th>
					<th>Job</th>
					<th>Actions</th>
				</tr>
			</thead>
			<tbody id="sgd-failed-body">
				<?php echo $failed_html; ?>
			</tbody>
		</table>
	</div><!-- /.sgd-pane-failed -->

	<!-- ============================================================ -->
	<!-- TAB: SOURCES MANAGER -->
	<!-- ============================================================ -->
	<div class="sgd-pane <?php echo $tab === 'sources' ? 'active' : ''; ?>" id="sgd-pane-sources">
		<?php
		// @MODIFIED 2026-03-02 - Include independent Source Manager view
		$sources_view = \dirname(__FILE__) . '/discovery-sources-manager.php';
		if (\file_exists($sources_view)) {
			include $sources_view;
		} else {
			echo '<div class="sgd-empty">Source Manager view missing: ' . \esc_html($sources_view) . '</div>';
		}
		?>
	</div>

	<!-- ============================================================ -->
	<!-- TAB: WP AUTOMATIC SETTINGS -->
	<!-- ============================================================ -->
	<div class="sgd-pane <?php echo $tab === 'wp-auto' ? 'active' : ''; ?>" id="sgd-pane-wp-auto">
		<?php
		$wp_auto_view = \dirname(__FILE__) . '/partials/discovery-wp-auto-settings.php';
		if (\file_exists($wp_auto_view)) {
			include $wp_auto_view;
		} else {
			echo '<div class="sgd-empty">WP Auto Settings view missing.</div>';
		}
		?>
	</div>

</div><!-- /.wrap -->

<?php
/**
 * Render the pipeline table HTML (called on page load and by AJAX refresh).
 * Extracted to a function so both can share identical markup.
 */
if (! function_exists('seo_gen_render_pipeline_table')) {
	function seo_gen_render_pipeline_table($items)
	{
		// Moved to top of file
	}
}

?>

<!-- ============================================================ -->
<!-- JAVASCRIPT: Tabs + AJAX Approve/Ignore/Retry + Live Polling -->
<!-- ============================================================ -->
<script>
	(function($) {
		'use strict';

	var nonce = '<?php echo \esc_js($nonce); ?>';
	var ajaxUrl = '<?php echo \esc_js(\admin_url('admin-ajax.php')); ?>';
	var pollTimer = null;
	var pollActive = true;
	var hasUsableSources = <?php echo $has_usable_sources ? 'true' : 'false'; ?>;

		function discoveryPaused() {
			return String(jQuery('#sgd-dashboard-root').attr('data-discovery-paused')) === '1';
		}

		function syncDiscoveryPauseUi(paused) {
			paused = !!paused;

			jQuery('#sgd-dashboard-root').attr('data-discovery-paused', paused ? '1' : '0');

			jQuery('[data-paused-scope="discovery"]').each(function() {
				var $el = jQuery(this);

				if (paused) {
					if ($el.attr('data-paused-prev-disabled') === undefined) {
						$el.attr('data-paused-prev-disabled', $el.prop('disabled') ? '1' : '0');
					}

					$el.prop('disabled', true)
					   .attr('aria-disabled', 'true')
					   .attr('data-paused-lock', '1')
					   .addClass('is-paused-locked');
					return;
				}

				if ($el.attr('data-paused-lock') === '1') {
					var wasDisabled = $el.attr('data-paused-prev-disabled') === '1';
					$el.prop('disabled', wasDisabled)
					   .removeAttr('aria-disabled')
					   .removeAttr('data-paused-lock')
					   .removeAttr('data-paused-prev-disabled')
					   .removeClass('is-paused-locked');
				}
			});
		}

		function blockIfPaused(e) {
			if (!discoveryPaused()) {
				return false;
			}

			if (e) {
				e.preventDefault();
				e.stopImmediatePropagation();
			}

			syncDiscoveryPauseUi(true);
			alert('Discovery is paused. Resume it before starting queue or generation work.');
			return true;
		}

		jQuery(document).on('click', '[data-paused-scope="discovery"]', function(e) {
			return !blockIfPaused(e);
		});

		// ---- Tab switching ----
		function activateTab(tab) {
			tab = String(tab || '').trim();
			if (!tab) {
				return;
			}

			jQuery('.sgd-tab').removeClass('active');
			jQuery('.sgd-tab[data-tab="' + tab + '"]').addClass('active');

			jQuery('.sgd-pane').removeClass('active');
			jQuery('#sgd-pane-' + tab).addClass('active');

			if (window.history && window.history.replaceState) {
				var url = new URL(window.location.href);
				url.searchParams.set('stab', tab);
				window.history.replaceState({ path: url.href }, '', url.href);
			}

			if (tab === 'pipeline') {
				startPolling();
			} else {
				stopPolling();
			}
		}

		jQuery(document).on('click', '.sgd-tab, .sgd-stat[data-tab], .sgd-jump-tab', function (e) {
			e.preventDefault();
			activateTab(jQuery(this).data('tab'));
		});

		// ---- Approve button ----
		jQuery(document).on('click', '.sgd-approve-btn', function(e) {
			if (blockIfPaused(e)) return;
			var btn = jQuery(this);
			var id = btn.data('id');
			var row = jQuery('#sgd-row-' + id);

			btn.text('Approving…').prop('disabled', true);

			jQuery.post(ajaxUrl, {
				action: 'seo_gen_approve_discovery',
				id: id,
				nonce: nonce
			}, function(res) {
				if (res.success) {
					row.css({
						background: '#d4edda',
						transition: 'opacity .4s'
					});
					setTimeout(function() {
						row.fadeOut(400, function() {
							row.remove();
							if (res.data && res.data.snapshot) {
								renderDashboardSnapshot(res.data.snapshot);
							}
							activateTab('pipeline');
						});
					}, 600);
				} else {
					btn.text('Approve').prop('disabled', false);
					alert('Error: ' + (res.data && res.data.message ? res.data.message : 'Unknown error'));
				}
			}).fail(function() {
				btn.text('Approve').prop('disabled', false);
				alert('Network error. Please try again.');
			});
		});

		// ---- Ignore button ----
		jQuery(document).on('click', '.sgd-ignore-btn', function() {
			var btn = jQuery(this);
			var id = btn.data('id');
			var row = jQuery('#sgd-row-' + id);

			if (!confirm('Dismiss this item?')) return;

			btn.prop('disabled', true);

			jQuery.post(ajaxUrl, {
				action: 'seo_gen_ignore_discovery',
				id: id,
				nonce: nonce
			}, function(res) {
				if (res.success) {
					row.fadeOut(300, function() {
						row.remove();
						if (res.data && res.data.snapshot) {
							renderDashboardSnapshot(res.data.snapshot);
						}
					});
				} else {
					btn.prop('disabled', false);
					alert('Error: ' + (res.data && res.data.message ? res.data.message : 'Unknown error'));
				}
			}).fail(function() {
				btn.prop('disabled', false);
				alert('Network error while dismissing item.');
			});
		});

		// ---- Retry button ----
		jQuery(document).on('click', '.sgd-retry-btn', function(e) {
			if (blockIfPaused(e)) return;
	e.preventDefault();
	e.stopPropagation();
			var btn = jQuery(this);
			var id = btn.data('id');
			var row = jQuery('#sgd-row-' + id);

			btn.text('Retrying…').prop('disabled', true);

			jQuery.post(ajaxUrl, {
				action: 'seo_gen_retry_discovery',
				id: id,
				nonce: nonce
			}, function(res) {
				if (res.success) {
					row.css({
						background: '#d4edda'
					});
					setTimeout(function() {
						row.fadeOut(400, function() {
							row.remove();
							if (res.data && res.data.snapshot) {
								renderDashboardSnapshot(res.data.snapshot);
							}
							jQuery('.sgd-tab[data-tab="pipeline"]').trigger('click');
						});
					}, 600);
				} else {
					btn.text('↺ Retry').prop('disabled', false);
					alert('Error: ' + (res.data && res.data.message ? res.data.message : 'Unknown error'));
				}
			}).fail(function() {
				btn.text('↺ Retry').prop('disabled', false);
				alert('Network error while retrying item.');
			});
		});

		// ---- Toggle Scanner Buttons (RSS / AI Scout) ----
		jQuery(document).on('change', '.sgd-toggle-scanner', function(e) {
			var toggle = jQuery(this);
			var wasChecked = !toggle.is(':checked');

			if (blockIfPaused(e)) {
				toggle.prop('checked', wasChecked);
				syncDiscoveryPauseUi(true);
				return;
			}

	var type = toggle.data('type');
	var enabled = toggle.is(':checked') ? 1 : 0;

	if (type === 'rss' && enabled && !hasUsableSources) {
				alert('No usable RSS sources. Add and test at least one working source in the Sources tab first.');
				toggle.prop('checked', false);
				return;
			}

			toggle.prop('disabled', true);

			jQuery.post(ajaxUrl, {
				action: 'seo_gen_toggle_scanner_mode',
				type: type,
				enabled: enabled,
				nonce: nonce
			}, function(res) {
				toggle.prop('disabled', false);

				if (res.success) {
					if (res.data && res.data.snapshot) {
						renderDashboardSnapshot(res.data.snapshot);
					}
				} else {
					toggle.prop('checked', !enabled);
					alert('Failed to update scanner: ' + (res.data && res.data.message ? res.data.message : 'Unknown error'));
				}
			}).fail(function() {
				toggle.prop('disabled', false).prop('checked', !enabled);
				alert('Network error while updating scanner.');
			});
		});

		// ---- Toggle Plugin Type Filter ----
		jQuery(document).on('change', '#sgd-toggle-plugin-filter', function() {
			var toggle = jQuery(this);
			var enabled = toggle.is(':checked') ? 1 : 0;
			var revertTo = !toggle.is(':checked');

			toggle.prop('disabled', true);

			jQuery.post(ajaxUrl, {
				action: 'seo_gen_toggle_plugin_filter',
				enabled: enabled,
				nonce: nonce
			}, function(res) {
				toggle.prop('disabled', false);

				if (res && res.success) {
					if (res.data && res.data.snapshot) {
						renderDashboardSnapshot(res.data.snapshot);
					}
					return;
				}

				toggle.prop('checked', revertTo);
				alert('Failed to update filter: ' + (res && res.data && res.data.message ? res.data.message : 'Unknown error'));
			}).fail(function() {
				toggle.prop('disabled', false).prop('checked', revertTo);
				alert('Network error while updating filter.');
			});
		});

		// ---- Run Manual Scans (RSS / AI Scout) ----
		jQuery(document).on('click', '#sgd-run-rss, #sgd-run-ai-scout', function(e) {
			if (blockIfPaused(e)) return;
			var btn = jQuery(this);
			var isAi = btn.attr('id') === 'sgd-run-ai-scout';

			btn.prop('disabled', true).addClass('loading');
			var originalText = btn.text();
			btn.text('...');

			jQuery.post(ajaxUrl, {
				action: 'seo_gen_run_discovery_manual',
				type: isAi ? 'ai' : 'rss',
				nonce: nonce
			}, function(res) {
				btn.prop('disabled', false).removeClass('loading');
				if (res.success) {
					btn.text('✅');
					if (res.data && res.data.snapshot) {
						renderDashboardSnapshot(res.data.snapshot);
					}
					setTimeout(function() {
						btn.text(originalText);
					}, 1500);
				} else {
					btn.text(originalText);
					alert('Error: ' + (res.data && res.data.message ? res.data.message : 'Unknown error'));
				}
			}).fail(function() {
				btn.prop('disabled', false).text(originalText);
				alert('Network error.');
			});
		});

		// ---- Toggle Discovery Engine (Status Card) ----
		jQuery(document).on('click', '#sgd-status-toggle', function() {
			var card = jQuery(this);
			var enabled = parseInt(card.attr('data-enabled') || card.data('enabled') || 0, 10) === 1 ? 1 : 0;
			var newEnabled = enabled ? 0 : 1;

			card.css('opacity', 0.6).css('pointer-events', 'none');

			jQuery.post(ajaxUrl, {
				action: 'seo_gen_toggle_discovery',
				nonce: nonce,
				enabled: newEnabled
			}, function(res) {
				card.css('opacity', 1).css('pointer-events', 'auto');

				if (res && res.success) {
					if (res.data && res.data.snapshot) {
						renderDashboardSnapshot(res.data.snapshot);
						return;
					}

					alert('Discovery state changed, but the dashboard snapshot was missing from the response. Refresh the page.');
					return;
				}

				alert('Toggle failed: ' + (res.data && res.data.message ? res.data.message : 'Unknown error.'));
			}).fail(function() {
				card.css('opacity', 1).css('pointer-events', 'auto');
				alert('Network error while toggling discovery engine.');
			});
		});

		// ---- Kill Pending Items (Staging Card) ----
		jQuery(document).on('click', '#sgd-kill-pending-card', function() {
			if (!confirm('⚠️ Delete ALL pending staging items?\n\nThis will remove all items waiting for approval.')) return;

			var btn = jQuery(this);
			var originalText = btn.text();
			btn.text('Clearing...').prop('disabled', true);

			jQuery.post(ajaxUrl, {
				action: 'seo_gen_clear_discovery_jobs',
				nonce: nonce
			}, function(res) {
				if (res.success) {
					if (res.data && res.data.snapshot) {
						renderDashboardSnapshot(res.data.snapshot);
					}
					if (res.data && res.data.message) {
						alert(res.data.message);
					}
				} else {
					btn.text(originalText).prop('disabled', false);
					alert('Error: ' + (res.data && res.data.message ? res.data.message : 'Unknown error'));
				}
			}).fail(function() {
				btn.text(originalText).prop('disabled', false);
				alert('Network error while clearing pending items.');
			});
		});

		// ---- Reset API Cooldown (Quota Card) ----
		jQuery(document).on('click', '#sgd-reset-api-cooldown', function() {
			var btn = jQuery(this);
			btn.prop('disabled', true).text('...');

			jQuery.post(ajaxUrl, {
				action: 'seo_gen_reset_api_cooldown',
				nonce: nonce
			}, function(res) {
				if (res.success) {
					if (res.data && res.data.snapshot) {
						renderDashboardSnapshot(res.data.snapshot);
					}
					if (res.data && res.data.message) {
						alert(res.data.message);
					}
				} else {
					btn.prop('disabled', false).text('Reset');
					alert('Error: ' + (res.data && res.data.message ? res.data.message : 'Unknown error'));
				}
			}).fail(function() {
				btn.prop('disabled', false).text('Reset');
				alert('Network error while resetting API cooldown.');
			});
		});

		// ---- Kill Pipeline Job ----
		jQuery(document).on('click', '.sgd-kill-pipeline-btn', function() {
			var btn = jQuery(this);

			if (!confirm('Kill this pipeline job?\n\nIt will be marked as failed and moved to the Failed tab.')) return;
			var id = btn.data('id');
			var row = jQuery('#sgd-pipeline-row-' + id);

			btn.text('Killing…').prop('disabled', true);

			jQuery.post(ajaxUrl, {
				action: 'seo_gen_kill_pipeline_item',
				id: id,
				nonce: nonce
			}, function(res) {
				if (res.success) {
					row.fadeOut(300, function() {
						row.remove();
						if (res.data && res.data.snapshot) {
							renderDashboardSnapshot(res.data.snapshot);
						}
					});
				} else {
					btn.text('✕ Kill').prop('disabled', false);
					alert('Error: ' + (res.data && res.data.message ? res.data.message : 'Unknown error'));
				}
			}).fail(function() {
				btn.text('✕ Kill').prop('disabled', false);
				alert('Network error. Please try again.');
			});
		});

		// ---- Run Queue Now (Manual Trigger) ----
		jQuery(document).on('click', '#sgd-run-queue-now', function(e) {
			if (blockIfPaused(e)) return;
			var btn = jQuery(this);
			btn.prop('disabled', true).text('Starting…');

			jQuery.post(ajaxUrl, {
				action: 'seo_gen_run_queue_now',
				nonce: nonce
			}, function(res) {
				if (res.success) {
					btn.text('✅ Started');
					setTimeout(function() {
						btn.prop('disabled', false).text('▶ Run Queue Now');
						if (res.data && res.data.snapshot) {
							renderDashboardSnapshot(res.data.snapshot);
						}
					}, 2000);
				} else {
					btn.prop('disabled', false).text('▶ Run Queue Now');
					alert('Error: ' + (res.data && res.data.message ? res.data.message : 'Unknown error'));
				}
			}).fail(function() {
				btn.prop('disabled', false).text('▶ Run Queue Now');
				alert('Network error while starting queue.');
			});
		});

		// ---- Run Item Now (Manual Trigger) ----
		jQuery(document).on('click', '.sgd-run-item-btn', function(e) {
			if (blockIfPaused(e)) return;
			var btn = jQuery(this);
			var id = btn.data('id');
			btn.prop('disabled', true).text('…');

			jQuery.post(ajaxUrl, {
				action: 'seo_gen_run_item_now',
				id: id,
				nonce: nonce
			}, function(res) {
				if (res.success) {
					btn.text('✅');
					setTimeout(function() {
						if (res.data && res.data.snapshot) {
							renderDashboardSnapshot(res.data.snapshot);
						}
					}, 1000);
				} else {
					btn.prop('disabled', false).text('▶');
					alert('Error: ' + (res.data && res.data.message ? res.data.message : 'Unknown error'));
				}
			}).fail(function() {
				btn.prop('disabled', false).text('▶');
				alert('Network error while starting item.');
			});
		});



		// ---- Repair Queue health card button ----
		jQuery(document).on('click', '#sgd-repair-queue', function () {
			if (!confirm('Repair the queue worker and refresh dashboard state?')) {
				return;
			}

			var btn = jQuery(this);

			btn.text('Repairing...').prop('disabled', true);

			jQuery.ajax({
				url: ajaxUrl,
				type: 'POST',
				dataType: 'json',
				timeout: 30000,
				data: {
					action: 'seo_gen_reset_as_queue',
					nonce: nonce
				}
			}).done(function (res) {
				if (res && res.success) {
					if (res.data && res.data.snapshot) {
						renderDashboardSnapshot(res.data.snapshot);
					}
					alert((res.data && res.data.message) ? res.data.message : 'Queue repaired.');
					return;
				}

				alert('Repair failed: ' + ((res && res.data && res.data.message) ? res.data.message : 'Unknown error.'));
			}).fail(function (xhr, status) {
				console.error('Repair AJAX failed', status, xhr);
				alert('Network error during repair.');
			}).always(function () {
				btn.text('Repair').prop('disabled', false);
			});
		});

		// ---- Reset AS Queue emergency recovery button ----
		jQuery(document).on('click', '#sgd-reset-as-queue', function () {
			if (!confirm('Reset Action Scheduler queue and refresh dashboard state?')) {
				return;
			}

			var btn = jQuery(this);

			btn.text('Resetting...').prop('disabled', true);

			jQuery.ajax({
				url: ajaxUrl,
				type: 'POST',
				dataType: 'json',
				timeout: 30000,
				data: {
					action: 'seo_gen_reset_as_queue',
					nonce: nonce
				}
			}).done(function (res) {
				if (res && res.success) {
					if (res.data && res.data.snapshot) {
						renderDashboardSnapshot(res.data.snapshot);
					}
					alert((res.data && res.data.message) ? res.data.message : 'Queue reset completed.');
					return;
				}

				alert('Reset failed: ' + ((res && res.data && res.data.message) ? res.data.message : 'Unknown error.'));
			}).fail(function (xhr, status) {
				console.error('Reset AJAX failed', status, xhr);
				alert('Network error during reset.');
			}).always(function () {
				btn.text('Reset').prop('disabled', false);
			});
		});

		// ---- Purge History (Health card button) ----
		jQuery(document).on('click', '#sgd-purge-history', function() {
			if (!confirm('⚠️ Purge ALL Discovery History?\n\nThis will TRUNCATE the discovery table, clearing all completed, failed, and approved records.\n\nExisting posts on your site will remain protected from duplication by the engine lookup logic.\n\nContinue?')) return;

			var btn = jQuery(this);
			btn.text('Purging…').prop('disabled', true);

			jQuery.post(ajaxUrl, {
				action: 'seo_gen_purge_discovery_history',
				nonce: nonce
			}, function(res) {
				if (res.success) {
					if (res.data && res.data.snapshot) {
						renderDashboardSnapshot(res.data.snapshot);
					}
					if (res.data && res.data.message) {
						alert(res.data.message);
					}
				} else {
					btn.text('🗑 Purge').prop('disabled', false);
					alert('Error: ' + (res.data && res.data.message ? res.data.message : 'Unknown error'));
				}
			}).fail(function() {
				btn.text('🗑 Purge').prop('disabled', false);
				alert('Network error during purge.');
			});
		});

		// ---- Clean Drafts (Health card button) ----
		jQuery(document).on('click', '#sgd-purge-drafts', function() {
			if (!confirm('Delete all processed WP-Auto draft posts?\n\nThis will:\n• Delete drafts processed by the plugin\n• Delete orphaned WP-Auto drafts\n• Re-schedule deletion for remaining drafts\n\nPublished posts will NOT be affected.\n\nContinue?')) return;

			var btn = jQuery(this);
			btn.text('Cleaning…').prop('disabled', true);

			jQuery.post(ajaxUrl, {
				action: 'seo_gen_purge_processed_drafts',
				nonce: nonce
			}, function(res) {
				if (res.success) {
					if (res.data && res.data.snapshot) {
						renderDashboardSnapshot(res.data.snapshot);
					}
					if (res.data && res.data.message) {
						alert(res.data.message);
					}
					btn.text('🗑 Drafts').prop('disabled', false);
				} else {
					btn.text('🗑 Drafts').prop('disabled', false);
					alert('Error: ' + (res.data && res.data.message ? res.data.message : 'Unknown error'));
				}
			}).fail(function() {
				btn.text('🗑 Drafts').prop('disabled', false);
				alert('Network error during draft cleanup.');
			});
		});

		// ---- Retry All Failed (Failed tab button) ----
		jQuery(document).on('click', '#sgd-retry-all-failed', function(e) {
			if (blockIfPaused(e)) return;
			if (!confirm('Move ALL failed/timeout items back to the queue? They will be trickle-processed by the background worker.')) return;

			var btn = jQuery(this);
			btn.text('Queueing…').prop('disabled', true);

			jQuery.post(ajaxUrl, {
				action: 'seo_gen_retry_all_failed',
				nonce: nonce
			}, function(res) {
				if (res.success) {
					if (res.data && res.data.snapshot) {
						renderDashboardSnapshot(res.data.snapshot);
					}
					if (res.data && res.data.message) {
						alert(res.data.message);
					}
				} else {
					btn.text('↺ Retry All Failed').prop('disabled', false);
					alert('Error: ' + (res.data && res.data.message ? res.data.message : 'Unknown'));
				}
			}).fail(function() {
				btn.text('↺ Retry All Failed').prop('disabled', false);
				alert('Network error while retrying all failed items.');
			});
		});

		function startPolling() {
			pollActive = true;
			pollNow();
		}

		function stopPolling() {
			pollActive = false;
			clearTimeout(pollTimer);
		}

		function updateHealthCard(health) {
			if (!health || typeof health !== 'object') {
				return;
			}

			const card = jQuery('#sgd-health-stat-card');
			const text = jQuery('#sgd-health-status-text');
			const desc = jQuery('#sgd-health-status-desc');

			const state = String(health.state || '').toLowerCase();
			const label = health.label || (state === 'healthy' ? 'Healthy' : (state === 'paused' ? 'Paused' : 'Stalled'));
			const icon  = health.icon || (state === 'healthy' ? '✓' : (state === 'paused' ? '⏸' : '✕'));
			const color = health.color || (state === 'healthy' ? '#46b450' : (state === 'paused' ? '#f0ad4e' : '#dc3232'));
			const borderColor = health.border_color || (state === 'healthy' ? '#ddd' : color);
			const description = health.description || (
				state === 'healthy' ? 'Scheduler Active' :
				state === 'paused'  ? 'Scheduler Paused' :
				                      'Scheduler Stalled'
			);

			text.text(icon + ' ' + label).css('color', color);
			card.css({
				'border-top-color': color,
				'border-color': borderColor
			});
			desc.text(description);
		}

		function renderDashboardSnapshot(snapshot) {
			if (!snapshot || typeof snapshot !== 'object') {
				return false;
			}

			try {
				var discovery = snapshot.discovery && typeof snapshot.discovery === 'object' ? snapshot.discovery : {};
			var tabs = snapshot.tabs && typeof snapshot.tabs === 'object' ? snapshot.tabs : {};
			var cards = snapshot.cards && typeof snapshot.cards === 'object' ? snapshot.cards : {};
			var counts = cards.counts && typeof cards.counts === 'object' ? cards.counts : {};
			var today = cards.today && typeof cards.today === 'object' ? cards.today : {};
			var activity = cards.activity && typeof cards.activity === 'object' ? cards.activity : {};
			var scanners = cards.scanners && typeof cards.scanners === 'object' ? cards.scanners : {};
			var health = cards.health && typeof cards.health === 'object' ? cards.health : {};
			var api = cards.api && typeof cards.api === 'object' ? cards.api : {};
			var sources = cards.sources && typeof cards.sources === 'object' ? cards.sources : {};
			var lists = snapshot.lists && typeof snapshot.lists === 'object' ? snapshot.lists : {};

			var shares = cards.shares && typeof cards.shares === 'object' ? cards.shares : {};

			var pending = lists.pending && typeof lists.pending === 'object' ? lists.pending : {};
			var pipeline = lists.pipeline && typeof lists.pipeline === 'object' ? lists.pipeline : {};
			var failed = lists.failed && typeof lists.failed === 'object' ? lists.failed : {};
			var completed = lists.completed && typeof lists.completed === 'object' ? lists.completed : {};
			var groups = completed.groups && typeof completed.groups === 'object' ? completed.groups : {};
			var completedToday = groups.today && typeof groups.today === 'object' ? groups.today : {};
			var completedHistory = groups.history && typeof groups.history === 'object' ? groups.history : {};

			var enabled = parseInt(discovery.enabled || 0, 10) === 1 ? 1 : 0;

			var pendingCount = parseInt(counts.pending || tabs.pending || pending.count || 0, 10);
			var pipelineCount = parseInt(counts.pipeline || tabs.pipeline || pipeline.count || 0, 10);
			var doneCount = parseInt(counts.done || tabs.done || completed.count || 0, 10);
			var failedCount = parseInt(counts.failed || tabs.failed || failed.count || 0, 10);

			var doneTodayCount = parseInt(today.done_today || 0, 10);
			var failedTodayCount = parseInt(today.failed_today || 0, 10);

			var sharesTotal = parseInt(shares.total || 0, 10);
			var sharesBuffer = parseInt(shares.buffer_total || 0, 10);
			var sharesJetpack = parseInt(shares.jetpack_total || 0, 10);

			var newPostsToday = parseInt(activity.new_posts_today || 0, 10);
			var updatedPostsToday = parseInt(activity.updated_posts_today || 0, 10);
			var newPostsTotal = parseInt(activity.new_posts_total || 0, 10);
			var updatedPostsTotal = parseInt(activity.updated_posts_total || 0, 10);

			var completedTodayCount = parseInt(completedToday.count || 0, 10);
			var completedHistoryCount = parseInt(completedHistory.count || 0, 10);
			var completedVisibleTotal = completedTodayCount + completedHistoryCount;

			jQuery('#sgd-dashboard-root').attr('data-discovery-paused', enabled ? '0' : '1');

			jQuery('#sgd-status-toggle')
				.attr('data-enabled', enabled ? '1' : '0')
				.toggleClass('is-running', enabled === 1)
				.toggleClass('is-paused', enabled !== 1)
				.css('border-top-color', enabled === 1 ? '#46b450' : '#f0ad4e');

			jQuery('#sgd-status-icon').text(enabled === 1 ? '▶' : '⏸');
			jQuery('#sgd-status-text')
				.text(enabled === 1 ? 'Running' : 'Paused')
				.css('color', enabled === 1 ? '#46b450' : '#f0ad4e');

			syncDiscoveryPauseUi(enabled !== 1);

			jQuery('#sgd-tab-badge-pending').text(pendingCount);
			jQuery('#sgd-tab-badge-pipeline').text(pipelineCount);
			jQuery('#sgd-tab-badge-done').text(doneCount);
			jQuery('#sgd-tab-badge-failed').text(failedCount);

			jQuery('#sgd-card-in-progress-value').text(pendingCount + pipelineCount);
			jQuery('#sgd-card-pending-mini').text('⏳ ' + pendingCount + ' pending');
			jQuery('#sgd-card-pipeline-mini').text('⚙️ ' + pipelineCount + ' pipeline');
			jQuery('#sgd-card-done-value').text(doneCount);
			jQuery('#sgd-card-failed-value').text(failedCount);

			jQuery('#sgd-card-done-today-note').text('Today ' + doneTodayCount);
			jQuery('#sgd-card-failed-today-note').text('Today ' + failedTodayCount);

			jQuery('#sgd-card-shares-total').text(sharesTotal);
			jQuery('#sgd-card-buffer-total').text(sharesBuffer);
			jQuery('#sgd-card-jetpack-total').text(sharesJetpack);

			if (shares.by_platform && typeof shares.by_platform === 'object') {
				var breakdownHtml = '';
				var platforms = Object.keys(shares.by_platform);
				for (var pi = 0; pi < platforms.length; pi++) {
					var pl = platforms[pi];
					var c = shares.by_platform[pl];
					breakdownHtml += '<span>' + pl.charAt(0).toUpperCase() + pl.slice(1) + ': ' + (c.buffer || 0) + 'B ' + (c.jetpack || 0) + 'J</span>';
				}
				jQuery('#sgd-card-shares-breakdown').html(breakdownHtml);
			}

			jQuery('#sgd-card-activity-new').text(newPostsToday);
			jQuery('#sgd-card-activity-updated').text(updatedPostsToday);
			jQuery('#sgd-card-activity-new-total').text(newPostsTotal);
			jQuery('#sgd-card-activity-updated-total').text(updatedPostsTotal);

			if (typeof pending.html !== 'undefined') {
				jQuery('#sgd-pending-body').html(String(pending.html || ''));
			}

			if (typeof pipeline.html !== 'undefined') {
				jQuery('#sgd-pipeline-body').html(String(pipeline.html || ''));
			}

			if (typeof failed.html !== 'undefined') {
				jQuery('#sgd-failed-body').html(String(failed.html || ''));
			}

			jQuery('#sgd-done-today-body').html(String(completedToday.html || ''));
			jQuery('#sgd-done-history-body').html(String(completedHistory.html || ''));
			jQuery('#sgd-done-today-count').text(completedTodayCount + ' completions');
			jQuery('#sgd-done-history-count').text(completedHistoryCount + ' items');
	jQuery('#sgd-done-empty-state').toggle(completedVisibleTotal === 0);
	jQuery('#sgd-done-today-section').toggle(completedTodayCount > 0);
	jQuery('#sgd-done-history-section').toggle(completedHistoryCount > 0);

	hasUsableSources = !!(sources && (sources.has_usable === true || parseInt(sources.has_usable || 0, 10) === 1));

			if (scanners.rss && typeof scanners.rss === 'object') {
				jQuery('#sgd-card-rss-state').text(scanners.rss.label || 'Unknown');
				jQuery('#sgd-toggle-rss').prop('checked', parseInt(scanners.rss.enabled || 0, 10) === 1);
			}

			if (scanners.ai && typeof scanners.ai === 'object') {
				jQuery('#sgd-card-ai-state').text(scanners.ai.label || 'Unknown');
				jQuery('#sgd-toggle-ai').prop('checked', parseInt(scanners.ai.enabled || 0, 10) === 1);
			}

			if (scanners.plugin_filter && typeof scanners.plugin_filter === 'object') {
				var filterEnabled = parseInt(scanners.plugin_filter.enabled || 0, 10) === 1;
				jQuery('#sgd-card-plugin-filter-state').text(scanners.plugin_filter.label || (filterEnabled ? 'On' : 'Off'));
				jQuery('#sgd-toggle-plugin-filter').prop('checked', filterEnabled);
				jQuery('#sgd-plugin-filter-note').text(scanners.plugin_filter.message || '');
			}

			if (sources && typeof sources === 'object' && typeof sources.summary !== 'undefined') {
				jQuery('#sgd-sources-health').text(String(sources.summary || ''));
			}

			if (api.stats) {
				updateApiNumbers(api.stats);
			}

			if (api.pause) {
				renderApiPause(api.pause);
				renderProviderPanel(api.stats, api.pause);
			}

			if (health) {
				updateHealthCard(health);
			}
		} catch (err) {
			console.error('SEO-Gen dashboard snapshot render failed', err, snapshot);
			return false;
		}

		return true;
	}

		function pollNow() {
			if (!pollActive) return;

			jQuery.post(ajaxUrl, {
				action: 'seo_gen_pipeline_status',
				nonce: nonce
			}, function(res) {
				if (res.success && res.data && res.data.snapshot) {
					renderDashboardSnapshot(res.data.snapshot);

			var refreshTime = new Date().toLocaleTimeString();
			var el = document.getElementById('sgd-pipeline-refresh-status');
			if (el) {
				el.textContent = 'Last refreshed: ' + refreshTime;
			}
				}
			}).always(function() {
				if (pollActive) {
					pollTimer = setTimeout(pollNow, 15000);
				}
			});
		}

		// ── Always-on API snapshot polling (independent of Pipeline tab) ──
		function renderApiPause(state) {
			const wrap = jQuery('#sgd-api-quota-wrap');

			if (!state || !state.paused) {
				wrap.empty();
				return;
			}

			const reasonHtml = state.reason
				? '<div style="font-size:9px;margin-bottom:2px;">' + state.reason + '</div>'
				: '';

			const resumeText = state.resume_diff || '&mdash;';
			wrap.html(
				'<div class="sgd-quota-paused"><strong>Quota Paused</strong>' + reasonHtml + '<span>Resumes in: ' + resumeText + '</span><div style="margin-top:3px;"><button id="sgd-reset-api-cooldown" class="sgd-btn-small" style="background:#fee2e2;border-color:#fca5a5;color:#991b1b;">Reset</button></div></div>'
			);
		}

		function updateApiNumbers(api) {
			if (!api) return;

			jQuery('#sgd-api-attempts-today').text(api.attempts_today || 0);
			jQuery('#sgd-api-attempts-total').text(api.attempts_total || 0);
			jQuery('#sgd-api-success-today').text(api.success_today || 0);
			jQuery('#sgd-api-success-total').text(api.success_total || 0);
			jQuery('#sgd-api-failures-today').text(api.failures_today || 0);
			jQuery('#sgd-api-failures-total').text(api.failures_total || 0);
		}

		// ---- Provider panel re-render – MODIFIED 2026-04-03 ----
		function _sgdUcFirst(s) { return s ? s.charAt(0).toUpperCase() + s.slice(1) : ''; }

		function renderProviderPanel(api, pause) {
			var panel = document.getElementById('sgd-api-provider-panel');
			if (!panel) return;

			var root = document.getElementById('sgd-dashboard-root');
			var providerNames = {};
			if (root) {
				try {
					providerNames = JSON.parse(root.getAttribute('data-provider-names') || '{}');
				} catch(e) {}
			}

			var detailRaw = (pause && pause.providers_detail) ? pause.providers_detail : [];
			var detail = {};
			if (Array.isArray(detailRaw)) {
				detailRaw.forEach(function(item) {
					if (item && item.provider) {
						detail[item.provider] = item;
					}
				});
			} else if (detailRaw && typeof detailRaw === 'object') {
				detail = detailRaw;
			}

			var stats = (api && api.providers) ? api.providers : {};

			var allPidsMap = {};
			Object.keys(stats).forEach(function(k) { allPidsMap[k] = true; });
			Object.keys(detail).forEach(function(k) { allPidsMap[k] = true; });
			var allPids = Object.keys(allPidsMap);
			if (allPids.length === 0) {
				allPids = ['gemini', 'openai', 'groq', 'perplexity', 'openrouter'];
			}

			var builtinOrder = ['gemini', 'openai', 'groq', 'perplexity', 'openrouter'];
			allPids.sort(function(a, b) {
				var idxA = builtinOrder.indexOf(a);
				var idxB = builtinOrder.indexOf(b);
				if (idxA !== -1 && idxB !== -1) {
					return idxA - idxB;
				}
				if (idxA !== -1) return -1;
				if (idxB !== -1) return 1;
				return a.localeCompare(b);
			});

			var activePids = allPids.filter(function(pid) {
				var p = detail[pid] || {};
				return p.enabled && p.available;
			});
			var html = '';

			if (activePids.length === 1) {
				// Single Provider Mode
				var pid    = activePids[0];
				var pdata  = detail[pid] || {};
				var badge  = pdata.cooling
					? '<span class="sgd-provider-badge sgd-badge-cooldown" title="' + (pdata.reason || '') + '">❄ Rate Limit' + (pdata.resume_diff ? ' · ' + pdata.resume_diff : '') + '</span>'
					: (pdata.state === 'misconfigured')
						? '<span class="sgd-provider-badge sgd-badge-misconfig">⚠ Not Configured</span>'
						: '<span class="sgd-provider-badge sgd-badge-active">● Active</span>';
				html  = '<div class="sgd-api-mode-tag">Single Provider</div>';
				html += '<div class="sgd-api-single-provider"><span class="sgd-api-single-name">' + (providerNames[pid] || _sgdUcFirst(pid)) + '</span>' + badge + '</div>';
			} else {
				// Fallback Mode
				html = '<div class="sgd-api-mode-tag sgd-api-mode-fallback">Fallback Mode</div>';
				allPids.forEach(function(pid) {
					var pdata  = detail[pid] || {};
					var pstats = stats[pid]  || {};
					var today  = parseInt(pstats.success_today || pstats.today  || 0, 10);
					var total  = parseInt(pstats.success_total || pstats.total  || 0, 10);
					var badge;
					if (pdata.cooling) {
						badge = '<span class="sgd-provider-badge sgd-badge-cooldown" title="' + (pdata.reason || '') + '">❄' + (pdata.resume_diff ? '&nbsp;' + pdata.resume_diff : '') + '</span>';
					} else if (pdata.state === 'misconfigured') {
						badge = '<span class="sgd-provider-badge sgd-badge-misconfig">⚠</span>';
					} else if (pdata.enabled && pdata.available) {
						badge = '<span class="sgd-provider-badge sgd-badge-active">●</span>';
					} else {
						badge = '<span class="sgd-provider-badge sgd-badge-idle">–</span>';
					}
					html += '<div class="sgd-provider-row"><span class="sgd-provider-name">' + (providerNames[pid] || _sgdUcFirst(pid)) + '</span>'
						  + '<span class="sgd-provider-counts">' + today + ' / ' + total.toLocaleString() + '</span>'
						  + badge + '</div>';
				});
			}
			panel.innerHTML = html;
		}

		function pollApiSnapshot() {
			jQuery.post(ajaxUrl, {
				action: 'seo_gen_dashboard_api_snapshot',
				nonce: nonce
			}, function(res) {
				if (!res || !res.success || !res.data) return;

				updateApiNumbers(res.data.api || {});
				renderApiPause(res.data.pause || {});
				renderProviderPanel(res.data.api, res.data.pause);

				if (res.data.health) {
					updateHealthCard(res.data.health);
				}
			}).always(function() {
				setTimeout(pollApiSnapshot, 15000);
			});
		}

		// ---- Deep Health Diag ----
		jQuery(document).on('click', '#sgd-health-diag', function () {
			var btn = jQuery(this);
			var debugArea = jQuery('.sgd-as-debug');

			btn.text('Checking...').prop('disabled', true);
			debugArea.show().html('<strong>Running Deep Diagnostics...</strong>');

			jQuery.ajax({
				url: ajaxUrl,
				type: 'POST',
				dataType: 'json',
				timeout: 20000,
				data: {
					action: 'seogenhealthcheck',
					nonce: nonce
				}
			}).done(function (res) {
				var d = (res && res.data && res.data.debug) ? res.data.debug : (res && res.data ? res.data : null);

				if (!res || !res.success || !d) {
					debugArea.html('<span style="color:#dc3232;">Diag failed: ' + ((res && res.data && res.data.message) ? res.data.message : 'Invalid JSON payload.') + '</span>');
					return;
				}

				var html = '<strong>AS Diagnostics</strong><br>';
				html += 'Library: ' + (d.library || 'MISSING') + '<br>';
				html += 'Store: ' + (d.store || 'MISSING') + '<br>';
				html += 'Table actions: ' + (d.tableactions || 'MISSING') + '<br>';
				html += 'Table groups: ' + (d.tablegroups || 'MISSING') + '<br>';
				html += 'Group ID: ' + (d.groupid || 0) + '<br>';
				html += 'Pending: ' + (d.pending || 0) + '<br>';
				html += 'Worker: ' + (d.workernext ? 'Scheduled' : 'MISSING') + '<br>';

				if (Array.isArray(d.recentfailed) && d.recentfailed.length) {
					html += '<br><strong>Recent Failures</strong><br>';
					d.recentfailed.forEach(function (f) {
						html += (f.hook || 'unknown') + ' @ ' + (f.lastattemptgmt || 'n/a') + '<br>';
					});
				}

				debugArea.html(html);
			}).fail(function (xhr, status) {
				console.error('Diag AJAX failed', status, xhr);
				debugArea.html('<span style="color:#dc3232;">Network failure during diagnostics.</span>');
			}).always(function () {
				btn.text('Diag').prop('disabled', false);
			});
		});

		jQuery(document).on('click', '#sgd-clear-history', function() {
			if (!confirm('This will purge terminal history items older than 72 hours. Continue?')) return;

			const $btn = jQuery(this);
			$btn.prop('disabled', true).text('Purging...');

			jQuery.post(ajaxUrl, {
				action: 'seo_gen_clear_discovery_history',
				nonce: nonce
			}, function(res) {
				if (res.success) {
					if (res.data && res.data.snapshot) {
						renderDashboardSnapshot(res.data.snapshot);
					}
					if (res.data && res.data.message) {
						alert(res.data.message);
					}
				} else {
					alert('Error: ' + (res.data && res.data.message ? res.data.message : 'Unknown error'));
					$btn.prop('disabled', false).text('🗑 Clear History');
				}
			});
		});

		// Initial tab activation
		jQuery(document).ready(function() {
			syncDiscoveryPauseUi(discoveryPaused());

			var initialTab = jQuery('.sgd-tabs .sgd-tab.active').data('tab');
			if (initialTab === 'pipeline') {
				startPolling();
			}

			pollApiSnapshot();
		});

		// ---- Block Encoding Fix button ----
		jQuery(document).on('click', '#sgd-fix-block-encoding', function () {
			var btn = jQuery(this);

			// Phase 1: Dry-run scan
			btn.text('Scanning...').prop('disabled', true);

			jQuery.ajax({
				url: ajaxUrl,
				type: 'POST',
				dataType: 'json',
				timeout: 120000,
				data: {
					action: 'seo_gen_block_encoder_fix',
					nonce: nonce,
					dry_run: '1'
				}
			}).done(function (res) {
				if (!res || !res.success) {
					alert('Scan failed: ' + ((res && res.data && res.data.message) ? res.data.message : 'Unknown error.'));
					btn.text('🔧 Block Fix').prop('disabled', false);
					return;
				}

				var d = res.data;
				var msg = 'Scan complete.\n\n'
					+ 'Posts scanned: ' + d.scanned + '\n'
					+ 'Posts with broken encoding: ' + d.fixed + '\n'
					+ 'Posts already OK: ' + d.skipped;

				if (d.post_titles && d.post_titles.length > 0) {
					msg += '\n\nAffected Posts:\n- ' + d.post_titles.join('\n- ');
				}

				if (d.fixed === 0) {
					msg += '\n\nNo posts need fixing.';
					alert(msg);
					btn.text('🔧 Block Fix').prop('disabled', false);
					return;
				}

				msg += '\n\nApply fix to ' + d.fixed + ' post(s)?';

				if (!confirm(msg)) {
					btn.text('🔧 Block Fix').prop('disabled', false);
					return;
				}

				// Phase 2: Apply fix
				btn.text('Fixing ' + d.fixed + ' posts...');

				jQuery.ajax({
					url: ajaxUrl,
					type: 'POST',
					dataType: 'json',
					timeout: 120000,
					data: {
						action: 'seo_gen_block_encoder_fix',
						nonce: nonce,
						dry_run: '0'
					}
				}).done(function (res2) {
					if (!res2 || !res2.success) {
						alert('Fix failed: ' + ((res2 && res2.data && res2.data.message) ? res2.data.message : 'Unknown error.'));
						btn.text('🔧 Block Fix').prop('disabled', false);
						return;
					}

					var d2 = res2.data;
					var msg2 = 'Fix applied.\n\n'
						+ 'Posts fixed: ' + d2.fixed + '\n'
						+ 'Errors: ' + d2.errors.length;

					if (d2.post_titles && d2.post_titles.length > 0) {
						msg2 += '\n\nFixed Posts:\n- ' + d2.post_titles.join('\n- ');
					}

					if (d2.errors.length > 0) {
						msg2 += '\n\nErrors:\n' + d2.errors.join('\n');
					}

					msg2 += '\n\nReload the page to verify block recovery is gone.';

					alert(msg2);
					btn.text('✓ Done').prop('disabled', true);
				}).fail(function (xhr, status) {
					console.error('Block fix AJAX failed', status, xhr);
					alert('Network error during fix.');
					btn.text('🔧 Block Fix').prop('disabled', false);
				});
			}).fail(function (xhr, status) {
				console.error('Block scan AJAX failed', status, xhr);
				alert('Network error during scan.');
				btn.text('🔧 Block Fix').prop('disabled', false);
			});
		});

	})(jQuery);
</script>