/**
 * Notification System Frontend
 * Handles fetching, displaying, and interacting with notifications
 * 
 * @package WP_News_MCQ_Generator
 * @version 7.3.4
 * @mobile-first Mobile-optimized design
 */

(function ($) {
    'use strict';

    let notificationCheckInterval;
    let unreadCount = 0;

    /**
     * Initialize notification system
     * @MODIFIED: Now handles both logged-in users and visitors
     */
    function init() {
        if (!nmNotifications) {
            console.error('NM Notifications: Configuration not found');
            return;
        }

        const isLoggedIn = nmNotifications.isLoggedIn;

        if (isLoggedIn) {
            // Initial fetch for logged-in users
            fetchNotifications();

            // Set up auto-refresh (default: 30 seconds)
            const checkInterval = nmNotifications.checkInterval || 30000;
            notificationCheckInterval = setInterval(fetchNotifications, checkInterval);
        } else {
            // Set up subscription form for visitors
            setupSubscriptionForm();
        }

        // Event listeners (for all users)
        setupEventListeners();

        console.log('NM Notifications: Initialized (Logged in: ' + isLoggedIn + ')');
    }

    /**
     * Fetch notifications from server
     */
    function fetchNotifications() {
        $.ajax({
            url: nmNotifications.ajaxurl,
            type: 'POST',
            data: {
                action: 'nm_get_notifications',
                nonce: nmNotifications.nonce,
                limit: 20,
                unread_only: false
            },
            success: function (response) {
                if (response.success) {
                    updateBadge(response.data.unread_count);
                    renderNotifications(response.data.notifications);
                }
            },
            error: function (xhr, status, error) {
                console.error('NM Notifications: Fetch failed', error);
            }
        });
    }

    /**
     * Update notification badge count
     */
    function updateBadge(count) {
        unreadCount = parseInt(count) || 0;
        const $badge = $('#nm-notification-badge');

        if (unreadCount > 0) {
            $badge.text(unreadCount > 99 ? '99+' : unreadCount).fadeIn();
            // Add pulsing animation for new notifications
            if (!$badge.hasClass('pulse')) {
                $badge.addClass('pulse');
            }
        } else {
            $badge.fadeOut();
        }
    }

    /**
     * Render notifications in dropdown
     */
    function renderNotifications(notifications) {
        const $list = $('#nm-notification-list');

        if (!notifications || notifications.length === 0) {
            $list.html('<div class="nm-notification-empty">No notifications yet</div>');
            return;
        }

        let html = '';
        notifications.forEach(function (notification) {
            const unreadClass = notification.is_read == '0' ? 'unread' : '';
            const icon = getNotificationIcon(notification.type);

            html += `
                <div class="nm-notification-item ${unreadClass}" data-id="${notification.id}">
                    <div class="nm-notification-icon">${icon}</div>
                    <div class="nm-notification-content">
                        <div class="nm-notification-title">${notification.title}</div>
                        <div class="nm-notification-message">${notification.message}</div>
                        <div class="nm-notification-time">${notification.time_ago}</div>
                    </div>
                    <button class="nm-notification-delete" data-id="${notification.id}" title="Delete">
                        &times;
                    </button>
                </div>
            `;
        });

        $list.html(html);
    }

    /**
     * Get icon for notification type
     */
    function getNotificationIcon(type) {
        const icons = {
            'daily_digest': '📰',
            'achievement': '🏆',
            'points': '🎯',
            'level_up': '⭐',
            'streak': '🔥',
            'leaderboard': '📊',
            'new_content': '📚'
        };
        return icons[type] || '🔔';
    }

    /**
     * Setup event listeners
     */
    function setupEventListeners() {
        // Toggle dropdown
        $(document).on('click', '#nm-notification-bell', function (e) {
            e.stopPropagation();
            toggleDropdown();
        });

        // Click notification item (mark as read)
        $(document).on('click', '.nm-notification-item', function (e) {
            if ($(e.target).hasClass('nm-notification-delete')) {
                return; // Delete button has its own handler
            }

            const $item = $(this);
            const notificationId = $item.data('id');

            if ($item.hasClass('unread')) {
                markAsRead(notificationId, $item);
            }
        });

        // Delete notification
        $(document).on('click', '.nm-notification-delete', function (e) {
            e.stopPropagation();
            const notificationId = $(this).data('id');
            deleteNotification(notificationId, $(this).closest('.nm-notification-item'));
        });

        // Mark all as read
        $(document).on('click', '#nm-mark-all-read', function (e) {
            e.preventDefault();
            markAllAsRead();
        });

        // Close dropdown when clicking outside
        $(document).on('click', function (e) {
            if (!$(e.target).closest('#nm-notification-bell').length) {
                closeDropdown();
            }
        });

        // Prevent dropdown from closing when clicking inside
        $(document).on('click', '#nm-notification-dropdown', function (e) {
            e.stopPropagation();
        });
    }

    /**
     * Toggle notification dropdown
     */
    function toggleDropdown() {
        const $dropdown = $('#nm-notification-dropdown');
        $dropdown.toggleClass('active');

        // Remove pulse animation when opening
        if ($dropdown.hasClass('active')) {
            $('#nm-notification-badge').removeClass('pulse');
        }
    }

    /**
     * Close notification dropdown
     */
    function closeDropdown() {
        $('#nm-notification-dropdown').removeClass('active');
    }

    /**
     * Mark notification as read
     */
    function markAsRead(notificationId, $item) {
        $.ajax({
            url: nmNotifications.ajaxurl,
            type: 'POST',
            data: {
                action: 'nm_mark_notification_read',
                nonce: nmNotifications.nonce,
                notification_id: notificationId
            },
            success: function (response) {
                if (response.success) {
                    $item.removeClass('unread');
                    unreadCount = Math.max(0, unreadCount - 1);
                    updateBadge(unreadCount);
                }
            },
            error: function (xhr, status, error) {
                console.error('NM Notifications: Mark as read failed', error);
            }
        });
    }

    /**
     * Mark all notifications as read
     */
    function markAllAsRead() {
        $.ajax({
            url: nmNotifications.ajaxurl,
            type: 'POST',
            data: {
                action: 'nm_mark_all_read',
                nonce: nmNotifications.nonce
            },
            success: function (response) {
                if (response.success) {
                    $('.nm-notification-item').removeClass('unread');
                    updateBadge(0);
                }
            },
            error: function (xhr, status, error) {
                console.error('NM Notifications: Mark all read failed', error);
            }
        });
    }

    /**
     * Delete notification
     */
    function deleteNotification(notificationId, $item) {
        // Optimistic UI update
        $item.slideUp(200, function () {
            $(this).remove();

            // Check if list is empty
            if ($('#nm-notification-list .nm-notification-item').length === 0) {
                $('#nm-notification-list').html('<div class="nm-notification-empty">No notifications yet</div>');
            }
        });

        // If it was unread, decrease count
        if ($item.hasClass('unread')) {
            unreadCount = Math.max(0, unreadCount - 1);
            updateBadge(unreadCount);
        }

        // Send delete request
        $.ajax({
            url: nmNotifications.ajaxurl,
            type: 'POST',
            data: {
                action: 'nm_delete_notification',
                nonce: nmNotifications.nonce,
                notification_id: notificationId
            },
            error: function (xhr, status, error) {
                console.error('NM Notifications: Delete failed', error);
                // Reload notifications on error
                fetchNotifications();
            }
        });
    }

    /**
     * Show toast notification (for new notifications)
     * Can be triggered via custom event
     */
    function showToast(notification) {
        const icon = getNotificationIcon(notification.type);
        const $toast = $(`
            <div class="nm-toast">
                <div class="nm-toast-icon">${icon}</div>
                <div class="nm-toast-content">
                    <div class="nm-toast-title">${notification.title}</div>
                    <div class="nm-toast-message">${notification.message}</div>
                </div>
                <button class="nm-toast-close">&times;</button>
            </div>
        `);

        $('body').append($toast);

        // Trigger animation
        setTimeout(function () {
            $toast.addClass('show');
        }, 10);

        // Auto-dismiss after 4 seconds
        const autoClose = setTimeout(function () {
            closeToast($toast);
        }, 4000);

        // Manual close
        $toast.find('.nm-toast-close').on('click', function () {
            clearTimeout(autoClose);
            closeToast($toast);
        });

        // Pause auto-close on hover
        $toast.on('mouseenter', function () {
            clearTimeout(autoClose);
        });
    }

    /**
     * Close toast notification
     */
    function closeToast($toast) {
        $toast.removeClass('show');
        setTimeout(function () {
            $toast.remove();
        }, 300);
    }

    /**
     * @MODIFIED: Setup subscription form for non-logged-in visitors
     */
    function setupSubscriptionForm() {
        $(document).on('submit', '#nm-bell-subscribe-form', function (e) {
            e.preventDefault();

            const $form = $(this);
            const $btn = $form.find('button[type="submit"]');
            const $msg = $form.siblings('.nm-subscribe-message');
            const email = $form.find('[name="email"]').val();
            const name = $form.find('[name="name"]').val();

            // Disable button
            $btn.prop('disabled', true).text('Subscribing...');
            $msg.html('').removeClass('error success');

            $.post(nmNotifications.ajaxurl, {
                action: 'nm_subscribe_user',
                email: email,
                name: name,
                nonce: nmNotifications.nonce
            }, function (response) {
                if (response.success) {
                    $msg.addClass('success').html('✅ ' + response.data.message);
                    $form[0].reset();
                } else {
                    $msg.addClass('error').html('❌ ' + response.data.message);
                }
                $btn.prop('disabled', false).text('Subscribe Now');
            }).fail(function () {
                $msg.addClass('error').html('❌ An error occurred. Please try again.');
                $btn.prop('disabled', false).text('Subscribe Now');
            });
        });
    }

    /**
     * Public API
     */
    window.NM_Notifications = {
        refresh: fetchNotifications,
        showToast: showToast,
        markAsRead: markAsRead
    };

    // Initialize on DOM ready
    $(document).ready(init);

})(jQuery);
