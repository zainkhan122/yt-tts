<?php

/**
 * Rank Math Software Schema Enhancer
 *
 * Appends or merges exactly one SoftwareApplication node into Rank Math's JSON-LD graph.
 * Provides a non-destructive fallback if native write-time schema generation fails,
 * treating _seo_gen_article_snapshot (via hero_data materialized view) as source of truth.
 *
 * @package SEO_Article_Generator\Integration
 */

namespace SEO_Article_Generator\Integration;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Rank Math Software Enhancer
 */
class RankMath_Software_Enhancer
{
    /**
     * Register Rank Math filter hooks.
     */
    public function register_hooks()
    {
        \add_filter('rank_math/json_ld', [$this, 'enhance_software_schema'], 90, 2);
    }

    /**
     * Passive Appender: Merges pre-normalized Hero meta into the graph.
     */
    public function enhance_software_schema($data, $jsonld = null)
    {
        try {
            if (!\is_singular()) return $data;
            
            $has_graph = isset($data['@graph']) && is_array($data['@graph']);
            $graph     = $has_graph ? $data['@graph'] : $data;
            if (!is_array($graph)) return $data;

            $post_id = $this->get_post_id($jsonld);
            if ($post_id <= 0) return $data;

            // @MODIFIED 2026-03-24: If write-time schema exists, Rank Math inherently handles it.
            if (\get_post_meta($post_id, 'rank_math_schema_SoftwareApplication', true)) {
                return $data;
            }

	$hero_data = \SEO_Article_Generator\Plugin::get_instance()->get_hero_data($post_id);
	if (empty($hero_data) || !\is_array($hero_data)) return $data;

            $permalink = \get_permalink($post_id);
            if (!$permalink) return $data;

            $software_id = $this->build_fragment_id($permalink, 'software');
            $article_id  = ''; // Will be discovered from graph

            $article_keys  = [];
            $software_keys = [];

            foreach ($graph as $key => &$item) {
                if (!is_array($item) || empty($item['@type'])) continue;
                $types   = (array)$item['@type'];
                $item_id = isset($item['@id']) ? (string) $item['@id'] : '';

                if ($this->is_software_entity($types, $item_id)) {
                    $software_keys[] = $key;
                    continue;
                }

                if ($this->is_article_entity($types)) {
                    $article_keys[] = $key;
                    // @MODIFIED 2026-03-20: Finding 5 - Use existing Article ID instead of overwriting it.
                    if ($item_id && !$article_id) {
                        $article_id = $item_id;
                    }
                }
            }
            unset($item);

            // Link Article -> Software
            foreach ($article_keys as $key) {
                $graph[$key] = $this->append_about_reference($graph[$key], $software_id);
            }

            // Merge or Append Software Node
            if (!empty($software_keys)) {
                // @MODIFIED TODAY: Implement actual parity by merging plugin-owned fields into an existing node,
                // and ONLY deduping nodes that match our explicit fingerprint.
                $plugin_specs = \SEO_Article_Generator\Integration\Rank_Math_Schema_Handler::build_software_schema_from_hero_data($post_id, $hero_data, $permalink);
                
                // Identify target node: Prioritize our own node if it exists, otherwise use the first generic one.
                $target_idx = null;
                foreach ($software_keys as $key) {
                    if (isset($graph[$key]['@id']) && $graph[$key]['@id'] === $software_id) {
                        $target_idx = $key;
                        break;
                    }
                }
                if ($target_idx === null) {
                    $target_idx = \current($software_keys);
                }

                // Inject our payload ensuring parity, but don't strip unrelated fields
                $graph[$target_idx] = \array_merge($graph[$target_idx], $plugin_specs);
                
                if (empty($graph[$target_idx]['@id'])) {
                    $graph[$target_idx]['@id'] = $software_id;
                }
                
                if ($article_id && empty($graph[$target_idx]['mainEntityOfPage'])) {
                    $graph[$target_idx]['mainEntityOfPage'] = ['@id' => $article_id];
                }

                // Destructive deduplication bug fix: ONLY kill extra nodes that explicitly claim our fingerprint
                foreach ($software_keys as $dup) {
                    if ($dup !== $target_idx && isset($graph[$dup]['@id']) && $graph[$dup]['@id'] === $software_id) {
                        unset($graph[$dup]);
                    }
                }
            } else {
                // If native meta failed/missing, we generate the rich fallback node
                $specs = \SEO_Article_Generator\Integration\Rank_Math_Schema_Handler::build_software_schema_from_hero_data($post_id, $hero_data, $permalink);
                $specs['@id'] = $software_id;
                
                if ($article_id) {
                    $specs['mainEntityOfPage'] = ['@id' => $article_id];
                }
                
                $graph[] = $specs;
            }

            $graph = \array_values($graph);
            if ($has_graph) $data['@graph'] = $graph;
            else $data = $graph;

            return $data;
        } catch (\Throwable $t) {
            return \is_array($data) ? $data : [];
        }
    }



    private function normalize_schema_url($url)
    {
        return \trailingslashit((string)$url);
    }

    private function is_article_entity(array $types)
    {
        return (bool) array_intersect(['Article', 'BlogPosting', 'TechArticle', 'WebPage'], $types);
    }

    private function is_software_entity(array $types, $item_id = '')
    {
        if (array_intersect(['SoftwareApplication', 'Software'], $types)) return true;
        return is_string($item_id) && substr($item_id, -9) === '#software';
    }

    private function append_about_reference(array $item, $software_id)
    {
        $ref = ['@id' => $software_id];
        if (empty($item['about'])) { $item['about'] = $ref; return $item; }
        $current = is_array($item['about']) && isset($item['about']['@id']) ? [$item['about']] : (is_array($item['about']) ? $item['about'] : (array)$item['about']);
        foreach ($current as $a) if (is_array($a) && isset($a['@id']) && $a['@id'] === $software_id) return $item;
        $item['about'] = array_merge($current, [$ref]);
        return $item;
    }

    private function build_fragment_id($url, $fragment)
    {
        return rtrim((string)$url, '/') . '/#' . $fragment;
    }

    private function get_post_id($jsonld)
    {
        if ($jsonld && \method_exists($jsonld, 'get_post_id')) return (int)$jsonld->get_post_id();
        return (int)\get_the_ID() ?: (int)\get_queried_object_id();
    }
}
