<?php

/**
 * Media Inventory Service
 *
 * Extracts ordered attachment IDs and image URLs from source content.
 * Used to ensure deterministic image capping, renaming, and cleanup for rewrite pipelines.
 *
 * @package DIT_TrendStudio
 * @since 2.13.8
 */

namespace DIT\TrendStudio\Services;

use DIT\TrendStudio\Infrastructure\Logger;

if (!defined('ABSPATH')) {
    exit;
}

class Media_Inventory
{
    private ?Logger $logger;

    public function __construct(?Logger $logger = null)
    {
        $this->logger = $logger;
    }

    /**
     * Get ordered image inventory for a post.
     *
     * @param int $post_id
     * @return array{ordered_ids:int[],hit_urls:array<int,string[]>,unresolved_urls:string[]}
     */
    public function get_post_image_inventory(int $post_id): array
    {
        $post = get_post($post_id);
        if (empty($post) || empty($post->post_content)) {
            return [
                'ordered_ids'      => [],
                'hit_urls'         => [],
                'unresolved_urls'  => [],
            ];
        }

        return $this->extract_from_content((string) $post->post_content);
    }

    /**
     * Extract ordered attachment IDs and URLs from Gutenberg blocks + HTML.
     */
    public function extract_from_content(string $content): array
    {
        $ordered_ids = [];
        $hit_urls = [];
        $unresolved = [];

        $seen = [];

        // 1) Prefer block IDs (most reliable)
        foreach ($this->extract_attachment_ids_from_blocks($content) as $att_id) {
            $att_id = (int) $att_id;
            if ($att_id <= 0) {
                continue;
            }
            $k = 'id:' . $att_id;
            if (isset($seen[$k])) {
                continue;
            }
            $seen[$k] = true;
            $ordered_ids[] = $att_id;
        }

        // 2) HTML <img> URLs
        foreach ($this->extract_image_urls($content) as $raw_url) {
            $raw_url = trim((string) $raw_url);
            if ($raw_url === '') {
                continue;
            }

            $abs = $this->normalize_to_absolute_url($raw_url);
            $att_id = $this->resolve_attachment_id_from_url($abs);

            if ($att_id > 0) {
                $k = 'id:' . $att_id;
                if (!isset($seen[$k])) {
                    $seen[$k] = true;
                    $ordered_ids[] = $att_id;
                }

                if (!isset($hit_urls[$att_id])) {
                    $hit_urls[$att_id] = [];
                }
                // Preserve the raw URL variant for downstream replacement.
                if (!in_array($raw_url, $hit_urls[$att_id], true)) {
                    $hit_urls[$att_id][] = $raw_url;
                }
                if ($abs !== $raw_url && !in_array($abs, $hit_urls[$att_id], true)) {
                    $hit_urls[$att_id][] = $abs;
                }
                continue;
            }

            if (!in_array($raw_url, $unresolved, true)) {
                $unresolved[] = $raw_url;
            }
        }

        return [
            'ordered_ids'      => array_values($ordered_ids),
            'hit_urls'         => $hit_urls,
            'unresolved_urls'  => $unresolved,
        ];
    }

    /**
     * Extract attachment IDs from blocks in content.
     *
     * @return int[]
     */
    public function extract_attachment_ids_from_blocks(string $content): array
    {
        if (!function_exists('parse_blocks')) {
            return [];
        }

        $blocks = parse_blocks($content);
        $ids = [];

        $walk = function (array $blocks) use (&$walk, &$ids): void {
            foreach ($blocks as $block) {
                if (!is_array($block)) {
                    continue;
                }

                $attrs = $block['attrs'] ?? [];
                if (is_array($attrs)) {
                    foreach (['id', 'mediaId'] as $k) {
                        if (!empty($attrs[$k])) {
                            $id = (int) $attrs[$k];
                            if ($id > 0) {
                                $ids[] = $id;
                            }
                        }
                    }

                    if (!empty($attrs['ids']) && is_array($attrs['ids'])) {
                        foreach ($attrs['ids'] as $id) {
                            $id = (int) $id;
                            if ($id > 0) {
                                $ids[] = $id;
                            }
                        }
                    }

                    if (!empty($attrs['images']) && is_array($attrs['images'])) {
                        foreach ($attrs['images'] as $img) {
                            if (is_array($img) && !empty($img['id'])) {
                                $id = (int) $img['id'];
                                if ($id > 0) {
                                    $ids[] = $id;
                                }
                            }
                        }
                    }
                }

                if (!empty($block['innerBlocks']) && is_array($block['innerBlocks'])) {
                    $walk($block['innerBlocks']);
                }
            }
        };

        $walk($blocks);

        return $ids;
    }

    /**
     * Extract image URLs from HTML.
     *
     * @return string[]
     */
    public function extract_image_urls(string $content): array
    {
        $urls = [];
        if (preg_match_all('/<img[^>]+?\b(?:src|data-src|data-lazy-src)=["\'](.*?)["\'][^>]*>/i', $content, $m)) {
            foreach ($m[1] as $u) {
                $u = \DIT\TrendStudio\Security\Sanitizer::decode_ai_string((string) $u);
                $u = trim($u);
                if ($u !== '') {
                    $urls[] = $u;
                }
            }
        }
        return $urls;
    }

    /**
     * Normalize relative / protocol-relative URLs to absolute.
     */
    public function normalize_to_absolute_url(string $url): string
    {
        $url = trim($url);
        if ($url === '') {
            return '';
        }

        // Strip HTML entities that may be embedded.
        $url = html_entity_decode($url, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        if (strpos($url, '//') === 0) {
            return (is_ssl() ? 'https:' : 'http:') . $url;
        }

        if (strpos($url, '/') === 0 && stripos($url, 'http') !== 0) {
            return home_url($url);
        }

        if (stripos($url, 'wp-content/') === 0) {
            return home_url('/' . ltrim($url, '/'));
        }

        return $url;
    }

    /**
     * Resolve attachment ID from URL using multiple fallbacks.
     */
    public function resolve_attachment_id_from_url(string $url, int $owner_post_id = 0): int
    {
        $url = trim($url);
        if ($url === '') {
            return 0;
        }

        $url = $this->normalize_to_absolute_url($url);

        // Remove query strings for stable lookup.
        $base_url = preg_replace('/[?#].*/', '', $url);
        if (empty($base_url)) {
            $base_url = $url;
        }

        $variants = [];
        $variants[] = $base_url;
        // @MODIFIED 2026-02-26 - Add scheme variants (http<->https) for mixed-content installs/migrations.
        if (strpos($base_url, "http://") === 0) {
            $variants[] = "https://" . substr($base_url, 7);
        } elseif (strpos($base_url, "https://") === 0) {
            $variants[] = "http://" . substr($base_url, 8);
        }


        // Handle double extensions like .webp.webp
        $path = (string) (parse_url($base_url, PHP_URL_PATH) ?: '');
        if ($path !== '' && preg_match('/\.(jpe?g|png|webp)\.(jpe?g|png|webp)$/i', $path)) {
            $variants[] = preg_replace('/\.(jpe?g|png|webp)$/i', '', $base_url);
        }

        // Handle -scaled, -123x456 patterns.
        $variants[] = preg_replace('/-\d+x\d+(?=\.(jpe?g|png|webp)$)/i', '', $base_url);
        $variants[] = preg_replace('/-scaled(?=\.(jpe?g|png|webp)$)/i', '', $base_url);

        foreach (array_unique(array_filter($variants)) as $v) {
            $id = (int) attachment_url_to_postid($v);
            if ($id > 0) {
                return $id;
            }
        }

        // Fallback: search by _wp_attached_file (scheme/domain-agnostic).
        // @MODIFIED 2026-02-26 - Fix attachment resolution when content URLs are http but uploads baseurl is https.
        $uploads = wp_upload_dir();
        $uploads_baseurl = (string) ($uploads['baseurl'] ?? '');
        $uploads_path = (string) (parse_url($uploads_baseurl, PHP_URL_PATH) ?: '');
        $url_path = (string) (parse_url($base_url, PHP_URL_PATH) ?: '');

        if ($uploads_path !== '' && $url_path !== '' && strpos($url_path, $uploads_path) !== false) {
            $rel = ltrim(substr($url_path, strpos($url_path, $uploads_path) + strlen($uploads_path)), '/');
        } elseif ($uploads_baseurl !== '' && strpos($base_url, $uploads_baseurl) === 0) {
            $rel = ltrim(str_replace($uploads_baseurl, '', $base_url), '/');
        } else {
            $rel = '';
        }

	// @MODIFIED 2026-05-08 - Build _wp_attached_file relative path variants including
	// double-extension stripped version (.webp.webp → .webp) so that sideloaded images
	// whose filename was fixed by Idea_Importer::maybe_sideload_image can still resolve.
	$rel_variants = [];
	if ($rel !== '') {
		$rel_variants[] = $rel;
		$stripped_rel = preg_replace('/\.(jpe?g|png|webp)$/i', '', $rel);
		if ($stripped_rel !== '' && $stripped_rel !== $rel && strpos($stripped_rel, '.') !== false) {
			$rel_variants[] = $stripped_rel;
		}
	}
	if (!empty($rel_variants)) {
		global $wpdb;
		foreach ($rel_variants as $rv) {
			$found = (int) $wpdb->get_var($wpdb->prepare(
				"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_wp_attached_file' AND meta_value = %s LIMIT 1",
				$rv
			));
			if ($found > 0) {
				return $found;
			}
		}
	}

	// @MODIFIED 2026-05-06 - Finding 2: Basename-only fallback.
	// Covers two failure modes:
	// (a) _wp_attached_file stored without year/month subdirectory (root-level upload)
	// (b) URL path prefix mismatch between the content URL and the stored uploads path
	// (common for showbiz images with numeric-prefix filenames like 1778000643_726_Name.jpg
	// imported via RSS where the WP media record has a different base path).
	// Guard: only run when the filename contains a dot (i.e. is an actual image file, not a
	// path fragment) to avoid false positives on ambiguous tokens.
	$url_basename = basename((string) (parse_url($base_url, PHP_URL_PATH) ?: ''));
	// @MODIFIED 2026-05-08 - Build HTML-decoded basename variants so that URLs containing
	// &amp; (HTML entity) can match _wp_attached_file values that store the decoded & character.
	// @MODIFIED 2026-05-09 - Also handle double extensions (.webp.webp → .webp) for URL normalization bugs.
	// @MODIFIED 2026-05-10 - Also handle URL-encoded characters (%E2%80%93 = en-dash, %20 = space, etc.)
	// that appear in generated content but _wp_attached_file stores decoded.
	$basename_variants = [];
	if ($url_basename !== '' && strpos($url_basename, '.') !== false) {
		$basename_variants[] = $url_basename;

		// Variant 1: HTML-decode (&amp; → &, &ndash; → –, etc.)
		$decoded = html_entity_decode($url_basename, ENT_QUOTES | ENT_HTML5, 'UTF-8');
		if ($decoded !== $url_basename && $decoded !== '') {
			$basename_variants[] = $decoded;
		}

		// Variant 2: URL-decode (%E2%80%93 → –, %20 → space, etc.)
		// This is critical for URLs from generator output that have URL-encoded special chars.
		$url_decoded = urldecode($url_basename);
		if ($url_decoded !== $url_basename && $url_decoded !== '') {
			$basename_variants[] = $url_decoded;
			// Also add HTML-decoded version of URL-decoded (both encodings might be present)
			$both_decoded = html_entity_decode($url_decoded, ENT_QUOTES | ENT_HTML5, 'UTF-8');
			if ($both_decoded !== $url_decoded && $both_decoded !== '' && !in_array($both_decoded, $basename_variants, true)) {
				$basename_variants[] = $both_decoded;
			}
		}

		// Handle double extensions (e.g., image.webp.webp → image.webp)
		if (preg_match('/\.(jpe?g|png|webp)\.(jpe?g|png|webp)$/i', $url_basename)) {
			$double_stripped = preg_replace('/\.(jpe?g|png|webp)$/i', '', $url_basename);
			if ($double_stripped !== $url_basename && $double_stripped !== '') {
				$basename_variants[] = $double_stripped;
				// Also add HTML-decoded double-stripped variant
				$decoded_double = html_entity_decode($double_stripped, ENT_QUOTES | ENT_HTML5, 'UTF-8');
				if ($decoded_double !== $double_stripped && $decoded_double !== '') {
					$basename_variants[] = $decoded_double;
				}
				// Also add URL-decoded double-stripped variant
				$url_decoded_double = urldecode($double_stripped);
				if ($url_decoded_double !== $double_stripped && $url_decoded_double !== '' && !in_array($url_decoded_double, $basename_variants, true)) {
					$basename_variants[] = $url_decoded_double;
				}
			}
		}
	}
	// @MODIFIED 2026-05-10 - Fallback: Handle bare filenames (no path component)
	// When generator returns just "filename.jpg" instead of full URL, parse_url returns no path.
	// In this case, try matching against ALL attachments by basename (no path prefix).
	if (empty($basename_variants) && $url !== '' && preg_match('/\.(jpe?g|png|webp)$/i', $url)) {
		$bare_variants = [];
		$bare_variants[] = $url;
		$bare_decoded = html_entity_decode($url, ENT_QUOTES | ENT_HTML5, 'UTF-8');
		if ($bare_decoded !== $url && $bare_decoded !== '') {
			$bare_variants[] = $bare_decoded;
		}
		$bare_url_decoded = urldecode($url);
		if ($bare_url_decoded !== $url && $bare_url_decoded !== '') {
			$bare_variants[] = $bare_url_decoded;
			$bare_both = html_entity_decode($bare_url_decoded, ENT_QUOTES | ENT_HTML5, 'UTF-8');
			if ($bare_both !== $bare_url_decoded && $bare_both !== '') {
				$bare_variants[] = $bare_both;
			}
		}
		// Strip double extensions for bare filenames too
		if (preg_match('/\.(jpe?g|png|webp)\.(jpe?g|png|webp)$/i', $url)) {
			$bare_double = preg_replace('/\.(jpe?g|png|webp)$/i', '', $url);
			if ($bare_double !== $url && $bare_double !== '' && !in_array($bare_double, $bare_variants, true)) {
				$bare_variants[] = $bare_double;
			}
		}
		if (!empty($bare_variants)) {
			global $wpdb;
			foreach ($bare_variants as $bv) {
				$found = (int) $wpdb->get_var($wpdb->prepare(
					"SELECT post_id FROM {$wpdb->postmeta}
					WHERE meta_key = '_wp_attached_file'
					AND (meta_value = %s OR meta_value LIKE %s)
					ORDER BY post_id DESC
					LIMIT 1",
					$bv,
					'%/' . $wpdb->esc_like($bv)
				));
				if ($found > 0) {
					return $found;
				}
			}
		}
	}
	if (!empty($basename_variants)) {
		global $wpdb;
		foreach ($basename_variants as $bv) {
			$found = (int) $wpdb->get_var($wpdb->prepare(
				"SELECT post_id FROM {$wpdb->postmeta}
				WHERE meta_key = '_wp_attached_file'
				AND (meta_value = %s OR meta_value LIKE %s)
				ORDER BY post_id DESC
				LIMIT 1",
				$bv,
				'%/' . $wpdb->esc_like($bv)
			));
			if ($found > 0) {
				return $found;
			}
		}
	}

	if (!empty($basename_variants) && (int) $owner_post_id > 0) {
		global $wpdb;
		foreach ($basename_variants as $bv) {
			$found = (int) $wpdb->get_var($wpdb->prepare(
				"SELECT p.ID FROM {$wpdb->posts} p
				INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_wp_attached_file'
				WHERE p.post_type = 'attachment'
				AND p.post_parent = %d
				AND (pm.meta_value = %s OR pm.meta_value LIKE %s)
				ORDER BY p.ID DESC
				LIMIT 1",
				(int) $owner_post_id,
				$bv,
				'%/' . $wpdb->esc_like($bv)
			));
			if ($found > 0) {
				return $found;
			}
		}
	}

	// @MODIFIED 2026-05-08 - Finding 3: guid column fallback.
	// When _wp_attached_file mismatches (filename was renamed during sideload but the
	// original URL is still referenced in content), the wp_posts.guid column stores the
	// original upload URL. This is the most reliable match for images where
	// Idea_Importer::maybe_sideload_image renamed the file to an SEO-friendly name
	// but the source draft content still references the original numeric-prefix URL.
	$guid_variants = [$base_url, $url]; // Add the original $url to variants, just in case $base_url strips something important.
	if (strpos($base_url, "http://") === 0) {
		$guid_variants[] = "https://" . substr($base_url, 7);
	} elseif (strpos($base_url, "https://") === 0) {
		$guid_variants[] = "http://" . substr($base_url, 8);
	}
	if (strpos($url, "http://") === 0) { // Also check original URL for scheme variants
		$guid_variants[] = "https://" . substr($url, 7);
	} elseif (strpos($url, "https://") === 0) {
		$guid_variants[] = "http://" . substr($url, 8);
	}
	$guid_variants = array_unique(array_filter($guid_variants));
	// @MODIFIED 2026-05-08 - Add basename matching for GUID column.
	// @MODIFIED 2026-05-09 - Also handle double extensions for GUID fallback.
	// @MODIFIED 2026-05-10 - Also handle URL-encoded characters (%E2%80%93 = en-dash, etc.)
	$url_basename = basename((string) (parse_url($base_url, PHP_URL_PATH) ?: ''));
	if ($url_basename !== '' && strpos($url_basename, '.') !== false) {
		$guid_basename_variants = [$url_basename];
		// HTML-decode variant
		$decoded_url_basename = html_entity_decode($url_basename, ENT_QUOTES | ENT_HTML5, 'UTF-8');
		if ($decoded_url_basename !== $url_basename && $decoded_url_basename !== '') {
			$guid_basename_variants[] = $decoded_url_basename;
		}
		// URL-decode variant
		$url_decoded_basename = urldecode($url_basename);
		if ($url_decoded_basename !== $url_basename && $url_decoded_basename !== '') {
			$guid_basename_variants[] = $url_decoded_basename;
			// Also add HTML-decoded version of URL-decoded
			$both_decoded = html_entity_decode($url_decoded_basename, ENT_QUOTES | ENT_HTML5, 'UTF-8');
			if ($both_decoded !== $url_decoded_basename && $both_decoded !== '' && !in_array($both_decoded, $guid_basename_variants, true)) {
				$guid_basename_variants[] = $both_decoded;
			}
		}
		// Handle double extensions in GUID lookup
		if (preg_match('/\.(jpe?g|png|webp)\.(jpe?g|png|webp)$/i', $url_basename)) {
			$double_stripped = preg_replace('/\.(jpe?g|png|webp)$/i', '', $url_basename);
			if ($double_stripped !== $url_basename && $double_stripped !== '') {
				$guid_basename_variants[] = $double_stripped;
				$decoded_double = html_entity_decode($double_stripped, ENT_QUOTES | ENT_HTML5, 'UTF-8');
				if ($decoded_double !== $double_stripped && $decoded_double !== '') {
					$guid_basename_variants[] = $decoded_double;
				}
				// URL-decode double-stripped variant
				$url_decoded_double = urldecode($double_stripped);
				if ($url_decoded_double !== $double_stripped && $url_decoded_double !== '' && !in_array($url_decoded_double, $guid_basename_variants, true)) {
					$guid_basename_variants[] = $url_decoded_double;
				}
			}
		}
		foreach ($guid_basename_variants as $gbv) {
			$found = (int) $wpdb->get_var($wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts}
				WHERE post_type = 'attachment'
				AND guid LIKE %s
				LIMIT 1",
				'%/' . $wpdb->esc_like($gbv)
			));
			if ($found > 0) {
				return $found;
			}
		}
	}

	if (!empty($guid_variants)) {
		global $wpdb;
		foreach ($guid_variants as $gv) {
			$found = (int) $wpdb->get_var($wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts}
				WHERE post_type = 'attachment'
				AND guid = %s
				LIMIT 1",
				$gv
			));
			if ($found > 0) {
				return $found;
			}
		}
	}

	// @MODIFIED 2026-05-08 - Finding 3b: guid fallback scoped by post_parent.
	// Same as above but restricts to attachments parented to $owner_post_id,
	// eliminating false positives from other posts with similar filenames.
	if (!empty($guid_variants) && (int) $owner_post_id > 0) {
		global $wpdb;
		foreach ($guid_variants as $gv) {
			$found = (int) $wpdb->get_var($wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts}
				WHERE post_type = 'attachment'
				AND post_parent = %d
				AND guid = %s
				LIMIT 1",
				(int) $owner_post_id,
				$gv
			));
			if ($found > 0) {
				return $found;
			}
		}
	}

	return 0;
    }

    /**
     * Resolve attachment IDs from a source_visual_map array.
     *
     * @param array $visual_map
     * @return int[]
     */
    public function get_attachment_ids_from_visual_map(array $visual_map): array
    {
        if (empty($visual_map)) {
            return [];
        }

        // Sort tokens: [VISUAL_0], [VISUAL_1]...
        uksort($visual_map, static function ($a, $b) {
            $ai = (int) preg_replace('/\D+/', '', (string) $a);
            $bi = (int) preg_replace('/\D+/', '', (string) $b);
            return $ai <=> $bi;
        });

        $ids = [];
        $seen = [];

        foreach ($visual_map as $token => $data) {
            if (!is_array($data)) {
                continue;
            }

            $id = (int) ($data['attachment_id'] ?? $data['attachmentId'] ?? 0);
            if ($id <= 0 && !empty($data['url'])) {
                $id = $this->resolve_attachment_id_from_url((string) $data['url']);
            }

            if ($id > 0 && !isset($seen[$id])) {
                $seen[$id] = true;
                $ids[] = $id;
            }
        }

        return $ids;
    }
}
