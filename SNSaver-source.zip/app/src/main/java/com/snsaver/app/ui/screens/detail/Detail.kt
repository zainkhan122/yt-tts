package com.snsaver.app.ui.screens.detail
import android.content.*
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.snsaver.app.domain.model.*
import com.snsaver.app.domain.repository.DownloadRepository
import com.snsaver.app.ui.components.PlatformBadge
import com.snsaver.app.util.*
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject
@HiltViewModel class DetailViewModel @Inject constructor(private val repo:DownloadRepository,private val clip:ClipboardHelper,private val files:FileHelper,@ApplicationContext private val context:Context):ViewModel(){
 private val id=MutableStateFlow(-1L);val item=id.filter{it>=0}.flatMapLatest(repo::observe).stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),null)
 fun load(value:Long){id.value=value};fun copy(value:String){clip.copy(value)}
 fun open(){item.value?.sourceUrl?.let{context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(it)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))}}
 fun share(){item.value?.filePath?.let{p->val file=File(p);val uri=FileProvider.getUriForFile(context,"${context.packageName}.fileprovider",file);context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType(if(p.endsWith(".jpg"))"image/jpeg" else "video/mp4").putExtra(Intent.EXTRA_STREAM,uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION),"Share media").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))}}
 fun delete(done:()->Unit)=viewModelScope.launch{item.value?.let{it.downloadedFiles.forEach(files::delete);it.thumbnailPath?.takeUnless{p->p.startsWith("http")}?.let(files::delete);repo.delete(it.id);done()}}
}
@OptIn(ExperimentalMaterial3Api::class) @Composable fun DetailScreen(id:Long,onBack:()->Unit,vm:DetailViewModel=hiltViewModel()){LaunchedEffect(id){vm.load(id)};val item by vm.item.collectAsStateWithLifecycle();var confirm by remember{mutableStateOf(false)};if(confirm)AlertDialog({confirm=false},title={Text("Delete download?")},text={Text("The app copy and its metadata will be permanently removed.")},confirmButton={TextButton({confirm=false;vm.delete(onBack)}){Text("Delete")}},dismissButton={TextButton({confirm=false}){Text("Cancel")}});Scaffold(topBar={TopAppBar({Text("Details")},navigationIcon={IconButton(onBack){Icon(Icons.AutoMirrored.Filled.ArrowBack,null)}},actions={IconButton(vm::open){Icon(Icons.Default.OpenInNew,null)};IconButton({confirm=true}){Icon(Icons.Default.Delete,null)}})}){pad->val it=item;if(it==null)Box(Modifier.fillMaxSize().padding(pad),contentAlignment=Alignment.Center){CircularProgressIndicator()}else Column(Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState())){val preview=it.thumbnailPath?:it.filePath;if(preview!=null)AsyncImage(if(preview.startsWith("http"))preview else File(preview),null,Modifier.fillMaxWidth().height(300.dp),contentScale=ContentScale.Crop);Row(Modifier.fillMaxWidth().padding(16.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(vm::share,Modifier.weight(1f)){Icon(Icons.Default.Share,null);Text(" Share")};it.caption?.let{c->OutlinedButton({vm.copy(c)},Modifier.weight(1f)){Icon(Icons.Default.ContentCopy,null);Text(" Caption")}}};Column(Modifier.padding(horizontal=16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Row(verticalAlignment=Alignment.CenterVertically){PlatformBadge(it.platform);Spacer(Modifier.width(10.dp));Text(it.profileName?:it.platform.displayName,style=MaterialTheme.typography.titleMedium)};it.title?.let{t->Text(t,style=MaterialTheme.typography.titleLarge)};it.caption?.let{c->Card{Text(c,Modifier.padding(14.dp))}};if(it.hashtags.isNotEmpty())Card(Modifier.fillMaxWidth()){Text(it.hashtags.joinToString(" "){t->"#$t"},Modifier.padding(14.dp),color=MaterialTheme.colorScheme.primary)};ListItem(headlineContent={Text("Source")},supportingContent={Text(it.sourceUrl)},trailingContent={IconButton({vm.copy(it.sourceUrl)}){Icon(Icons.Default.ContentCopy,null)}});Text("${it.mediaType.name.lowercase().replaceFirstChar(Char::uppercase)} • ${formatSize(it.fileSize)}",color=MaterialTheme.colorScheme.onSurfaceVariant);Spacer(Modifier.height(28.dp))}}}}
private fun formatSize(v:Long)=when{v<1024->"$v B";v<1048576->"%.1f KB".format(v/1024.0);v<1073741824->"%.1f MB".format(v/1048576.0);else->"%.1f GB".format(v/1073741824.0)}
