<?php

/**
 * Quota Reset Calculator
 *
 * Provider-specific quota reset helpers.
 *
 * Gemini API Requests-per-day (RPD) quotas reset at midnight Pacific time.
 * Ref: https://ai.google.dev/gemini-api/docs/rate-limits
 *
 * @package SEO_Article_Generator\AI
 * @since 2.15.0
 */

namespace SEO_Article_Generator\AI;

if (!defined('ABSPATH')) {
    exit;
}

class Quota_Reset_Calculator
{
    /**
     * Compute the next Gemini RPD reset timestamp (midnight Pacific).
     *
     * @param int $now_ts Unix timestamp (defaults to now).
     * @return int Unix timestamp of the next reset moment.
     */
    public static function gemini_next_rpd_reset_ts(int $now_ts = 0): int
    {
        $now_ts = ($now_ts > 0) ? $now_ts : \time();

        try {
            $pt = new \DateTimeZone('America/Los_Angeles');
            $now = (new \DateTimeImmutable('@' . $now_ts))->setTimezone($pt);
            $next = $now->modify('tomorrow')->setTime(0, 0, 0);
            return (int) $next->getTimestamp();
        } catch (\Throwable $e) {
            // Conservative fallback: 12h ahead (forces probe/backoff to recover).
            return (int) ($now_ts + 12 * 3600);
        }
    }

    /**
     * Compute the next generic (UTC) reset timestamp (midnight UTC).
     *
     * @param int $now_ts Unix timestamp (defaults to now).
     * @return int Unix timestamp of the next reset moment.
     */
    public static function generic_next_reset_ts(int $now_ts = 0): int
    {
        $now_ts = ($now_ts > 0) ? $now_ts : \time();

        try {
            $utc = new \DateTimeZone('UTC');
            $now = (new \DateTimeImmutable('@' . $now_ts))->setTimezone($utc);
            $next = $now->modify('tomorrow')->setTime(0, 0, 0);
            return (int) $next->getTimestamp();
        } catch (\Throwable $e) {
            return (int) ($now_ts + 12 * 3600);
        }
    }

    /**
     * Format a timestamp in the site's timezone.
     *
     * @param int $ts
     * @return string
     */
    public static function format_in_wp_tz(int $ts): string
    {
        if ($ts <= 0) {
            return '';
        }

        try {
            $tz = function_exists('\\wp_timezone') ? \wp_timezone() : new \DateTimeZone('UTC');
            $dt = (new \DateTimeImmutable('@' . $ts))->setTimezone($tz);
            return (string) $dt->format('Y-m-d H:i:s T');
        } catch (\Throwable $e) {
            return (string) \gmdate('Y-m-d H:i:s', $ts) . ' UTC';
        }
    }
}
