<?php

/**
 * Jobs list view
 *
 * @package DIT_TrendStudio
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="wrap dit-ts-admin">
    <h1><?php esc_html_e('Generation Jobs', 'dit-trend-content-studio'); ?></h1>

    <?php if (empty($jobs)): ?>
        <p><?php esc_html_e('No jobs found.', 'dit-trend-content-studio'); ?></p>
    <?php else: ?>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th style="width:60px;"><?php esc_html_e('ID', 'dit-trend-content-studio'); ?></th>
                    <th><?php esc_html_e('Type', 'dit-trend-content-studio'); ?></th>
                    <th><?php esc_html_e('Status', 'dit-trend-content-studio'); ?></th>
                    <th><?php esc_html_e('Created', 'dit-trend-content-studio'); ?></th>
                    <th><?php esc_html_e('Completed', 'dit-trend-content-studio'); ?></th>
                    <th><?php esc_html_e('Actions', 'dit-trend-content-studio'); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($jobs as $job): ?>
                    <tr id="job-row-<?php echo esc_attr($job['id']); ?>" data-job-id="<?php echo esc_attr($job['id']); ?>" class="job-row-status-<?php echo esc_attr($job['status']); ?>">
                        <td><?php echo esc_html($job['id']); ?></td>
                        <td><?php echo esc_html(ucfirst($job['job_type'])); ?></td>
                        <td class="status-cell">
                            <span class="job-status job-status-<?php echo esc_attr($job['status']); ?>">
                                <?php echo esc_html(ucfirst($job['status'])); ?>
                            </span>
                        </td>
                        <td><?php echo esc_html($job['created_at']); ?></td>
                        <td><?php echo $job['completed_at'] ? esc_html($job['completed_at']) : '—'; ?></td>
                        <td>
                            <button type="button" class="button button-small dit-ts-preview-job"
                                data-job-id="<?php echo esc_attr($job['id']); ?>">
                                <?php esc_html_e('Preview', 'dit-trend-content-studio'); ?>
                            </button>
                            <button type="button" class="button button-small dit-ts-regenerate-job"
                                data-job-id="<?php echo esc_attr($job['id']); ?>">
                                <?php echo $job['status'] === 'completed' ? esc_html__('Regenerate', 'dit-trend-content-studio') : esc_html__('Run', 'dit-trend-content-studio'); ?>
                            </button>
                            <?php if (!in_array($job['status'], ['completed', 'failed'])): ?>
                                <button type="button" class="button button-small dit-ts-cancel-job" style="color: #d63638; border-color: #d63638; margin-left: 4px;" data-job-id="<?php echo esc_attr($job['id']); ?>">
                                    <?php esc_html_e('Cancel', 'dit-trend-content-studio'); ?>
                                </button>
                            <?php endif; ?>
                            <?php if ($job['status'] === 'failed'): ?>
                                <details class="error-details">
                                    <summary class="error-message">
                                        <?php esc_html_e('Error', 'dit-trend-content-studio'); ?> ▾
                                    </summary>
                                    <pre class="error-full"><?php echo esc_html($job['error_message']); ?></pre>
                                </details>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

