package com.snsaver.app.data.db

import androidx.room.*
import com.snsaver.app.domain.model.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName="downloads", indices=[Index("timestamp"),Index("platform"),Index("status")])
data class DownloadEntity(
 @PrimaryKey(autoGenerate=true) val id:Long=0, val sourceUrl:String, val platform:Platform, val status:DownloadStatus,
 val mediaType:MediaType=MediaType.UNKNOWN, val filePath:String?=null, val thumbnailPath:String?=null,
 val caption:String?=null, val hashtagsRaw:String="[]", val profileUrl:String?=null, val profileName:String?=null,
 val mediaUrlsRaw:String="[]", val downloadedFilesRaw:String="[]", val progress:Int=0, val errorMessage:String?=null,
 val fileSize:Long=0, val timestamp:Long=System.currentTimeMillis(), val title:String?=null, val workerId:String?=null)

class RoomConverters {
 @TypeConverter fun platform(v:Platform)=v.name
 @TypeConverter fun platform(v:String)=runCatching{Platform.valueOf(v)}.getOrDefault(Platform.UNKNOWN)
 @TypeConverter fun status(v:DownloadStatus)=v.name
 @TypeConverter fun status(v:String)=runCatching{DownloadStatus.valueOf(v)}.getOrDefault(DownloadStatus.FAILED)
 @TypeConverter fun type(v:MediaType)=v.name
 @TypeConverter fun type(v:String)=runCatching{MediaType.valueOf(v)}.getOrDefault(MediaType.UNKNOWN)
}
@Dao interface DownloadDao {
 @Insert suspend fun insert(item:DownloadEntity):Long
 @Update suspend fun update(item:DownloadEntity)
 @Query("SELECT * FROM downloads ORDER BY timestamp DESC") fun observeAll():Flow<List<DownloadEntity>>
 @Query("SELECT * FROM downloads WHERE status IN (:statuses) ORDER BY timestamp DESC") fun observeStatuses(statuses:List<DownloadStatus>):Flow<List<DownloadEntity>>
 @Query("SELECT * FROM downloads WHERE id=:id") fun observe(id:Long):Flow<DownloadEntity?>
 @Query("SELECT * FROM downloads WHERE id=:id") suspend fun get(id:Long):DownloadEntity?
 @Query("UPDATE downloads SET status=:status, progress=:progress WHERE id=:id") suspend fun setStatus(id:Long,status:DownloadStatus,progress:Int)
 @Query("UPDATE downloads SET status='FAILED', errorMessage=:message WHERE id=:id") suspend fun fail(id:Long,message:String?)
 @Query("DELETE FROM downloads WHERE id=:id") suspend fun delete(id:Long)
 @Query("DELETE FROM downloads") suspend fun deleteAll()
}
@Database(entities=[DownloadEntity::class],version=1,exportSchema=false)
@TypeConverters(RoomConverters::class)
abstract class AppDatabase:RoomDatabase(){abstract fun downloads():DownloadDao}
