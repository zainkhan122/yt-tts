<?php

/**
 * Article Generator
 *
 * @package SEO_Article_Generator
 */

namespace SEO_Article_Generator\Generator;

use SEO_Article_Generator\AI\AI_Client;
use SEO_Article_Generator\Links\Link_Finder;
use SEO_Article_Generator\Validation\Validator;
use SEO_Article_Generator\Logger;
use SEO_Article_Generator\AI\DeterministicFailureException;
use SEO_Article_Generator\Generator\Article_Schema;
use SEO_Article_Generator\Services\Schema_Sync_Service;
use SEO_Article_Generator\Validation\ChangelogVerifier;
use SEO_Article_Generator\Generator\Surgical_Patcher;
use SEO_Article_Generator\Generator\Prompt_Builder;
use SEO_Article_Generator\Generator\Generation_Context;
use SEO_Article_Generator\Generator\Phrase_Variator;
use SEO_Article_Generator\Generator\Hero_Data_Provider;
use SEO_Article_Generator\Generator\Response_Normalizer;
use SEO_Article_Generator\Generator\Content_Formatter;
use SEO_Article_Generator\Discovery\Post_Type_Classifier;
use SEO_Article_Generator\Discovery\Title_Analyzer;
use SEO_Article_Generator\Utils\SeoGen_Version_Resolver;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Main article generation orchestrator
 */
class Article_Generator
{
    /**
     * AI client instance
     *
     * @var AI_Client
     */
    private $ai_client;

    /**
     * Link finder instance
     *
     * @var Link_Finder
     */
    private $link_finder;

    /**
     * Validator instance
     *
     * @var Validator
     */
    private $validator;

    /**
     * Logger instance
     *
     * @var Logger
     */
    private $logger;

    /**
     * Prompt builder instance
     * @var Prompt_Builder
     */
    private $prompt_builder;

    /**
     * Hallucination filter warnings (if any detected)
     * @MODIFIED 2025-12-15 v2.2.0: Added for Google compliance
     *
     * @var array|null
     */
    private $hallucination_warnings = null;

    /**
     * Constructor
     *
     * @param AI_Client   $ai_client AI client instance
     * @param Link_Finder $link_finder Link finder instance
     * @param Validator   $validator Validator instance
     * @param Logger      $logger Logger instance
     */
    public function __construct($ai_client, $link_finder, $validator, $logger)
    {
        $this->ai_client      = $ai_client;
        $this->link_finder    = $link_finder;
        $this->validator      = $validator;
        $this->logger         = $logger;
        $this->prompt_builder = new Prompt_Builder();
    }

    /**
     * Generate article
     * @MODIFIED 2025-12-03 v1.3.0: Dual-mode support (manual/auto-update)
     *
     * @param array $input_data Input data from user
     * @param callable|null $heartbeat_callback Optional callback for long-running heartbeats
     * @return array Generated article with validation results
     * @throws \Throwable If generation fails
     */
    public function generate(array $input_data, ?callable $heartbeat_callback = null)
    {
        // @MODIFIED 2025-12-04 v1.5.1: Default to auto mode (Manual mode removed)
        $generation_mode = isset($input_data['generation_mode']) ? $input_data['generation_mode'] : 'auto';

        // Force auto mode only - manual mode disabled
        if ($generation_mode !== 'auto') {
            if ($this->logger) {
                $this->logger->warning('Manual mode requested but disabled - forcing auto mode');
            }
            $generation_mode = 'auto';
        }

        $gen_type = !empty($input_data['existing_post_id']) ? 'update' : 'new';
        if ($this->logger) {
            $this->logger->info('Generation pipeline initialized', array(
                'mode'      => 'auto',
                'post_type' => $gen_type,
                'post_id'   => $input_data['existing_post_id'] ?? 0,
            ));
        }
        return $this->generate_auto_update($input_data, $heartbeat_callback);

        // @MODIFIED 2025-12-04 v1.5.1: Manual mode completely removed
        // This legacy code path is now unreachable but preserved for reference
        // All article generation now goes through generate_auto_update() only
    }


    /**
     * Inject internal links into article features
     *
     * @param array $article_data Article data
     * @param array $internal_links Internal links to inject
     * @return array Modified article data
     */
    /**
     * Inject internal links into strict structured sections only.
     *
     * Allowed resolution paths:
     * - introduction[*]
     * - moat_data[*] => canonical zone moatdata
     * - features[*][description]
     *
     * @param array $article_data Article data.
     * @param array $internal_links Internal links to inject.
     * @return array Modified article data.
     */
	private function inject_internal_links(array $article_data, array $internal_links, int $internal_linking_count = 0)
	{
		if ($internal_linking_count <= 0) {
			$internal_linking_count = (int) \get_option(
				\SEO_Article_Generator\Option_Registry::INTERNAL_LINK_COUNT,
				\SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::INTERNAL_LINK_COUNT] ?? 3
			);
		}

		if ($internal_linking_count <= 0) {
      if ($this->logger) {
        $this->logger->info('Internal linking skipped: feature disabled (count=0).');
      }
      return $article_data;
    }

    if (empty($internal_links)) {
      if ($this->logger) {
        $this->logger->info('Internal linking skipped: empty internal link contract.');
      }
      return $article_data;
    }

    // ENFORCEMENT: Truncate to the user-configured limit BEFORE building the token map.
    // Prevents AI over-generation (e.g. AI returns 7 tokens when setting is 3) from
    // injecting more links than the operator configured.
    if (count($internal_links) > $internal_linking_count) {
      if ($this->logger) {
        $this->logger->info('Internal link contract truncated to configured limit.', array(
          'received' => count($internal_links),
          'limit' => $internal_linking_count,
        ));
      }
      // $internal_links is keyed by token string (e.g. 'SEOGEN_LINK_1'), NOT numeric.
      // array_slice with preserve_keys=true maintains string keys for token map lookup.
      $internal_links = array_slice($internal_links, 0, $internal_linking_count, true);
    }

    $token_map = array();

        foreach ($internal_links as $key => $meta) {
            $token = is_string($key) ? sanitize_text_field((string) $key) : '';
            $url = '';
            $zone = '';
            $title = '';

            if (is_array($meta)) {
                $url = isset($meta['url']) ? esc_url_raw((string) $meta['url']) : '';
                $zone = strtolower(trim((string) ($meta['zone'] ?? '')));
                $title = isset($meta['title']) ? sanitize_text_field((string) $meta['title']) : '';
            }

            if ($zone === 'moat' || $zone === 'moat_data') {
                $zone = 'moatdata';
            }

            if (!preg_match('/^SEOGEN_LINK_\d+$/', $token) || $url === '' || !in_array($zone, array('introduction', 'moatdata', 'features'), true)) {
                if ($this->logger) {
                    $this->logger->warning('Internal link token map entry rejected inside injector.', array(
                        'token' => $token,
                        'zone' => $zone,
                        'url' => $url,
                        'title' => $title,
                    ));
                }
                continue;
            }

            $token_map[$token] = array(
                'url' => $url,
                'zone' => $zone,
                'title' => $title,
            );
        }

        if (empty($token_map)) {
            if ($this->logger) {
                $this->logger->warning('Internal linking skipped: normalized token map is empty.');
            }
            return $article_data;
        }

        $metrics = array(
            'expected' => count($token_map),
            'resolved' => 0,
            'dropped_unused' => 0,
            'malformed' => 0,
            'wrong_zone' => 0,
            'disallowed_section' => 0,
            'unmapped' => 0,
            'duplicate_token' => 0,
            'empty_anchor' => 0,
        );

        $resolved_tokens = array();

        $walk = function (&$node, array $path = array()) use (&$walk, &$token_map, &$metrics, &$resolved_tokens) {
            if (is_array($node)) {
                foreach ($node as $key => &$value) {
                    $next_path = $path;
                    $next_path[] = (string) $key;
                    $walk($value, $next_path);
                }
                unset($value);
                return;
            }

            if (!is_string($node) || strpos($node, 'SEOGEN_LINK') === false) {
                return;
            }

            $root_field = isset($path[0]) ? (string) $path[0] : '';
            $leaf_field = !empty($path) ? (string) $path[count($path) - 1] : '';

            $actual_zone = '';
            $allow_resolution = false;

            if ($root_field === 'introduction') {
                $actual_zone = 'introduction';
                $allow_resolution = true;
            } elseif ($root_field === 'moat_data') {
                $actual_zone = 'moatdata';
                $allow_resolution = true;
            } elseif ($root_field === 'features' && $leaf_field === 'description') {
                $actual_zone = 'features';
                $allow_resolution = true;
            }

            $node = preg_replace_callback(
                '/\[SEOGEN_LINK_(\d+)\](.*?)\[\/SEOGEN_LINK_\1\]/s',
                function ($matches) use (&$token_map, &$metrics, &$resolved_tokens, $actual_zone, $allow_resolution, $path) {
                    $token = 'SEOGEN_LINK_' . $matches[1];
                    $anchor = html_entity_decode((string) $matches[2], ENT_QUOTES, 'UTF-8');
                    $anchor = trim(preg_replace('/\s+/u', ' ', wp_strip_all_tags($anchor)));

                    if (!isset($token_map[$token])) {
                        $metrics['unmapped']++;
                        if ($this->logger) {
                            $this->logger->warning('Internal link token dropped: token not in normalized map.', array(
                                'token' => $token,
                                'path' => implode('.', $path),
                            ));
                        }
                        return $anchor;
                    }

                    if (!$allow_resolution) {
                        $metrics['disallowed_section']++;
                        if ($this->logger) {
                            $this->logger->warning('Internal link token dropped: disallowed structured section.', array(
                                'token' => $token,
                                'expected_zone' => $token_map[$token]['zone'],
                                'actual_path' => implode('.', $path),
                            ));
                        }
                        return $anchor;
                    }

                    if ($token_map[$token]['zone'] !== $actual_zone) {
                        $metrics['wrong_zone']++;
                        if ($this->logger) {
                            $this->logger->warning('Internal link token dropped: zone mismatch.', array(
                                'token' => $token,
                                'expected_zone' => $token_map[$token]['zone'],
                                'actual_zone' => $actual_zone,
                                'actual_path' => implode('.', $path),
                            ));
                        }
                        return $anchor;
                    }

                    if (isset($resolved_tokens[$token])) {
                        $metrics['duplicate_token']++;
                        if ($this->logger) {
                            $this->logger->warning('Internal link token dropped: duplicate token reuse.', array(
                                'token' => $token,
                                'first_path' => $resolved_tokens[$token]['path'],
                                'next_path' => implode('.', $path),
                            ));
                        }
                        return $anchor;
                    }

                    if ($anchor === '') {
                        $metrics['empty_anchor']++;
                        if ($this->logger) {
                            $this->logger->warning('Internal link token dropped: empty anchor.', array(
                                'token' => $token,
                                'path' => implode('.', $path),
                            ));
                        }
                        return '';
                    }

                    $resolved_tokens[$token] = array(
                        'path' => implode('.', $path),
                        'zone' => $actual_zone,
                        'anchor' => $anchor,
                    );

                    $metrics['resolved']++;

                    if ($this->logger) {
                        $this->logger->info('Internal link token resolved.', array(
                            'token' => $token,
                            'url' => $token_map[$token]['url'],
                            'zone' => $actual_zone,
                            'path' => implode('.', $path),
                            'anchor' => $anchor,
                        ));
                    }

                    return '<a href="' . esc_url($token_map[$token]['url']) . '">' . esc_html($anchor) . '</a>';
                },
                $node
            );

            if (strpos($node, '[SEOGEN_LINK') !== false || strpos($node, '[/SEOGEN_LINK') !== false) {
                $metrics['malformed']++;
                if ($this->logger) {
                    $this->logger->warning('Malformed internal link token syntax detected and stripped.', array(
                        'path' => implode('.', $path),
                        'value' => substr($node, 0, 300),
                    ));
                }

                $node = preg_replace('/\[(\/)?SEOGEN_LINK[^\]]*\]/', '', $node);
            }
        };

        $walk($article_data);

        foreach ($token_map as $token => $meta) {
            if (!isset($resolved_tokens[$token])) {
                $metrics['dropped_unused']++;
                if ($this->logger) {
                    $this->logger->warning('Internal link token not resolved in final article.', array(
                        'token' => $token,
                        'zone' => $meta['zone'],
                        'url' => $meta['url'],
                    ));
                }
            }
        }

        $strict_pass = (
            $metrics['expected'] === $metrics['resolved']
            && $metrics['malformed'] === 0
            && $metrics['wrong_zone'] === 0
            && $metrics['disallowed_section'] === 0
            && $metrics['unmapped'] === 0
            && $metrics['duplicate_token'] === 0
            && $metrics['empty_anchor'] === 0
        );
        $success_rate = $metrics['expected'] > 0
            ? round(($metrics['resolved'] / $metrics['expected']) * 100, 2)
            : 100.0;

        if ($this->logger) {
            $log_method = $strict_pass ? 'info' : 'warning';
            $this->logger->{$log_method}('Internal linking summary.', array(
                'strict_pass' => $strict_pass,
                'success_rate' => $success_rate,
                'expected' => $metrics['expected'],
                'resolved' => $metrics['resolved'],
                'dropped_unused' => $metrics['dropped_unused'],
                'malformed' => $metrics['malformed'],
                'wrong_zone' => $metrics['wrong_zone'],
                'disallowed_section' => $metrics['disallowed_section'],
                'unmapped' => $metrics['unmapped'],
                'duplicate_token' => $metrics['duplicate_token'],
                'empty_anchor' => $metrics['empty_anchor'],
            ));
        }

        return $article_data;
    }

    /**
     * Generate article in Auto-Update mode
     * @MODIFIED 2025-12-03 v1.3.0: Auto-Update mode implementation
     *
     * @param array $input_data Input data with 'article_context'
     * @param callable|null $heartbeat_callback Optional callback for long-running heartbeats
     * @return array Generated article with validation results
     * @throws \Throwable If generation fails
     */
    private function generate_auto_update(array $input_data, ?callable $heartbeat_callback = null)
    {
        if ($this->logger) {
            $this->logger->info('Article_Generator runtime', array(
                'file' => __FILE__,
                'mtime' => @filemtime(__FILE__),
            ));
        }

        // @MODIFIED 2025-12-12 v1.8.1: Track failed partial regen sections for admin notice
        $failed_sections = array();
        $is_update       = !empty($input_data['existing_post_id']);

        // Step 1: Validate article_context field
        $article_context = isset($input_data['article_context']) ? trim($input_data['article_context']) : '';

        if (empty($article_context)) {
            $message = 'Article text or software name is required in Auto-Update mode';
            if ($this->logger) {
                $this->logger->error($message);
            }
            throw new \InvalidArgumentException($message);
        }

        // Step 2: Prepare context and grounding
        // @MODIFIED 2026-03-03: Build Generation_Context for deterministic pipeline control
        $input_type          = $input_data['input_type'] ?? 'manual';
        $context             = Generation_Context::from_input($input_data, $input_type);
        $context_text_length = mb_strlen($article_context);
        $extracted_data      = array();

        if ($this->logger) {
            $this->logger->info('Generation context', array(
                'type'      => $context->type,
                'grounding' => $context->grounding,
                'sections'  => $context->sections,
                'version'   => $context->prompt_version,
            ));
        }

        $has_pre_resolved_metadata = !empty($input_data['detected_metadata']) || !empty($input_data['source_url']);
        $is_provided_source = in_array($input_type, ['discovery', 'wpauto', 'provided'], true);
        
        $has_manual_metadata_seed = ($input_type === 'manual')
            && !empty($input_data['software_name'])
            && !empty($input_data['source_url']);

        if ($context->needs_search() && !$has_pre_resolved_metadata && !$is_provided_source && !$has_manual_metadata_seed) {
            if ($this->logger) {
                $this->logger->info('Query Mode: Using ContextExtractor for grounding', [
                    'software' => $input_data['software_name'] ?? 'unknown',
                ]);
            }
            try {
                $extractor      = new \SEO_Article_Generator\AI\Context_Extractor($this->ai_client, $this->logger);
                $extracted_data = $extractor->extract($article_context);

                if (!is_array($extracted_data)) {
                    throw new \Exception('ContextExtractor returned non-array payload');
                }
            } catch (\Exception $e) {
                if ($this->logger) {
                    $this->logger->warning('ContextExtractor failed; falling back to direct metadata seed', [
                        'software' => $input_data['software_name'] ?? 'unknown',
                        'error'    => $e->getMessage(),
                    ]);
                }

                $extracted_data = [
                    'software_name'       => $input_data['software_name'] ?? '',
                    'version'             => $input_data['version'] ?? '',
'homepage' => $input_data['homepage_url'] ?? ($input_data['source_url'] ?? ''),
                    'category'            => $input_data['category'] ?? '',
                    'is_existing_article' => !empty($input_data['existing_post_id']),
                ];
            }
        } else {
            if ($this->logger) {
                $this->logger->info('Extracted Mode: Bypassing ContextExtractor', [
                    'grounding'    => $context->grounding,
                    'length'       => $context_text_length,
                    'input_type'   => $input_type,
                    'has_metadata' => $has_pre_resolved_metadata,
                ]);
            }
            $extracted_data = [
                'software_name'       => $input_data['software_name'] ?? '',
                'version'             => $input_data['version'] ?? '',
                'homepage' => $input_data['homepage_url'] ?? ($input_data['source_url'] ?? ''),
                'category'            => $input_data['category'] ?? '',
                'is_existing_article' => !empty($input_data['existing_post_id']),
            ];
        }

        // @MODIFIED 2026-03-18: Robust Metadata Integration
        // Favor pre-resolved links from Discovery_Processor if available.
        $pre_resolved_links = array();
        if (!empty($input_data['detected_metadata'])) {
            $meta = is_string($input_data['detected_metadata']) ? json_decode($input_data['detected_metadata'], true) : $input_data['detected_metadata'];
            if (!empty($meta['resolved_links'])) {
                $pre_resolved_links = $meta['resolved_links'];
            }
        }

        $detected_metadata = \SEO_Article_Generator\Discovery\Data_Extractor::extract($input_data['article_context'] ?? '', ['source_url' => $input_data['source_url'] ?? '', 'software_name' => $input_data['software_name'] ?? '']);

        if (!is_array($detected_metadata)) {
            $detected_metadata = array();
        }

        if (empty($detected_metadata['all_links']) || !is_array($detected_metadata['all_links'])) {
            $detected_metadata['all_links'] = array();
        }

        if (empty($detected_metadata['grounding_hints']) || !is_array($detected_metadata['grounding_hints'])) {
            $detected_metadata['grounding_hints'] = array();
        }

        $pre_resolved_links = \SEO_Article_Generator\Generator\Download_Link_Helper::reconcile_source_links(
            $pre_resolved_links, $detected_metadata['all_links']
        );
        $extracted_data = array_merge($extracted_data, array(
            'detected_version'   => $detected_metadata['version'],
            'detected_file_size' => $detected_metadata['file_size'],
            'resolved_links'     => !empty($pre_resolved_links) ? $pre_resolved_links : $detected_metadata['all_links'],
            'detected_links'     => !empty($pre_resolved_links) ? $pre_resolved_links : $detected_metadata['all_links'], // Legacy fallback
            'detected_trial'     => $detected_metadata['trial_link'] ?? '',
            'detected_direct'    => $detected_metadata['direct_link'] ?? '',
            'detected_portal'    => $detected_metadata['portal_link'] ?? '',
            'grounding_hints'    => $detected_metadata['grounding_hints'] ?? []
        ));

        // @MODIFIED 2026-03-04: Fetch site categories for semantic AI selection
        $taxonomy_map = array();
        if (function_exists('\get_categories')) {
            $categories = \get_categories(array('hide_empty' => false));
            if (is_array($categories)) {
                foreach ($categories as $cat) {
                    $taxonomy_map[] = array(
                        'slug' => $cat->slug,
                        'name' => $cat->name
                    );
                }
            }
        }

        // @MODIFIED 2026-04-07: Groq TPM safety - truncate input if too large
        $provider = \get_option('seo_gen_api_provider', 'gemini');
        $max_input_chars = 3500; // Groq TPM safety (6000 - system~2000 - output~1500)
        if ($provider === 'groq' && $context->grounding === 'provided' && mb_strlen($article_context) > $max_input_chars) {
            $article_context = mb_substr($article_context, 0, $max_input_chars);
            if ($this->logger) {
                $this->logger->info("Input truncated for Groq TPM", array('chars_before' => $context_text_length, 'chars_after' => mb_strlen($article_context)));
            }
        }

        // Validation is mandatory for all generated articles.
        // Do not accept runtime bypass flags from prompt/input builders.

        // Strip any stale bypass flag from caller input so it cannot leak.
        unset($input_data['skip_validation']);

    // Step 3a: Internal linking feature gate and normalized contract.
    // [PHASE 3E, 2.33.0] SCOPED PAYLOAD: internal-link tokens are only
    // contractable into zones the AI is actually asked to generate.
    // Tokens whose zone (introduction / moatdata / features) is NOT in the
    // regeneration scope are dropped BEFORE the prompt is built and BEFORE
    // the prompt-internal-link mandate is emitted - otherwise the AI is
    // instructed to embed tokens in sections it never returns, producing
    // guaranteed dropped_unused failures (log evidence: job 1155, 0/3).
    $_il_scope = Article_Schema::normalize_sections(
        (array) ($input_data['regen_sections'] ?? array('all')),
        array('all', 'toc')
    );
    $_il_scope_all = empty($_il_scope) || in_array('all', $_il_scope, true);
    $_il_zone_in_scope = static function ($zone) use ($_il_scope, $_il_scope_all) {
        if ($_il_scope_all) {
            return true;
        }
        $zone = strtolower(trim((string) $zone));
        if ($zone === 'moat' || $zone === 'moat_data') {
            $zone = 'moatdata';
        }
        // moatdata tokens land in the moat section; canonical 'moat'.
        if ($zone === 'moatdata') {
            return in_array('moat', $_il_scope, true);
        }
        return in_array($zone, $_il_scope, true);
    };
    if ( ! $_il_scope_all && ! empty( $input_data['seogen_links'] ) && is_array( $input_data['seogen_links'] ) ) {
        $_il_before = count( (array) $input_data['seogen_links'] );
        $input_data['seogen_links'] = array_values( array_filter(
            (array) $input_data['seogen_links'],
            static function ( $link ) use ( $_il_zone_in_scope ) {
                return is_array( $link ) && $_il_zone_in_scope( (string) ( $link['zone'] ?? '' ) );
            }
        ) );
        if ( ! empty( $input_data['seogen_token_map'] ) && is_array( $input_data['seogen_token_map'] ) ) {
            $_map = array();
            foreach ( (array) $input_data['seogen_token_map'] as $tok => $meta ) {
                if ( is_array( $meta ) && $_il_zone_in_scope( (string) ( $meta['zone'] ?? '' ) ) ) {
                    $_map[ $tok ] = $meta;
                }
            }
            $input_data['seogen_token_map'] = $_map;
        }
        $_il_after = count( (array) $input_data['seogen_links'] );
        if ( $_il_after !== $_il_before && $this->logger ) {
            $this->logger->info( 'Internal link contract scoped: dropped ' . ( $_il_before - $_il_after ) . ' token(s) whose target section is not in regeneration scope.', array( 'before' => $_il_before, 'after' => $_il_after, 'scope' => $_il_scope ) );
        }
    }
    // MODIFIED: Use Option_Registry constant instead of raw string for refactoring safety
    $internal_linking_count = (int) \get_option(
      \SEO_Article_Generator\Option_Registry::INTERNAL_LINK_COUNT,
      \SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::INTERNAL_LINK_COUNT] ?? 3
    );
    $internal_linking_enabled = ($internal_linking_count > 0);
    $internal_links = array();
    $prompt_internal_links = array();
    $selection_metrics = array(
      'enabled' => $internal_linking_enabled,
      'received_links' => 0,
      'received_map' => 0,
      'accepted' => 0,
      'rejected' => 0,
    );

        if ($internal_linking_enabled) {
            $raw_prompt_links = (!empty($input_data['seogen_links']) && is_array($input_data['seogen_links']))
                ? $input_data['seogen_links']
                : array();

            $raw_token_map = (!empty($input_data['seogen_token_map']) && is_array($input_data['seogen_token_map']))
                ? $input_data['seogen_token_map']
                : array();

            $selection_metrics['received_links'] = count($raw_prompt_links);
            $selection_metrics['received_map'] = count($raw_token_map);

            foreach ($raw_prompt_links as $index => $link) {
                if (!is_array($link)) {
                    $selection_metrics['rejected']++;
                    if ($this->logger) {
                        $this->logger->warning('Internal link selection rejected: non-array seogen_links item.', array(
                            'index' => $index,
                        ));
                    }
                    continue;
                }

                $token = isset($link['token']) ? sanitize_text_field((string) $link['token']) : '';
                $title = isset($link['title']) ? sanitize_text_field((string) $link['title']) : '';
                $url = isset($link['url']) ? esc_url_raw((string) $link['url']) : '';
                $zone = strtolower(trim((string) ($link['zone'] ?? '')));

                if ($zone === 'moat' || $zone === 'moat_data') {
                    $zone = 'moatdata';
                }

                if (!preg_match('/^SEOGEN_LINK_\d+$/', $token)) {
                    $selection_metrics['rejected']++;
                    if ($this->logger) {
                        $this->logger->warning('Internal link selection rejected: invalid token format.', array(
                            'index' => $index,
                            'token' => $token,
                        ));
                    }
                    continue;
                }

                if ($url === '') {
                    $selection_metrics['rejected']++;
                    if ($this->logger) {
                        $this->logger->warning('Internal link selection rejected: empty URL.', array(
                            'index' => $index,
                            'token' => $token,
                            'zone' => $zone,
                        ));
                    }
                    continue;
                }

                if (!in_array($zone, array('introduction', 'moatdata', 'features'), true)) {
                    $selection_metrics['rejected']++;
                    if ($this->logger) {
                        $this->logger->warning('Internal link selection rejected: invalid zone.', array(
                            'index' => $index,
                            'token' => $token,
                            'zone' => $zone,
                            'url' => $url,
                        ));
                    }
                    continue;
                }

                if (isset($internal_links[$token])) {
                    $selection_metrics['rejected']++;
                    if ($this->logger) {
                        $this->logger->warning('Internal link selection rejected: duplicate token in prompt links.', array(
                            'index' => $index,
                            'token' => $token,
                        ));
                    }
                    continue;
                }

                $prompt_internal_links[] = array(
                    'token' => $token,
                    'title' => $title,
                    'url' => $url,
                    'zone' => $zone,
                );

                $internal_links[$token] = array(
                    'url' => $url,
                    'zone' => $zone,
                    'title' => $title,
                );

                $selection_metrics['accepted']++;
            }

            foreach ($raw_token_map as $token_key => $meta) {
                $token = is_string($token_key) ? sanitize_text_field((string) $token_key) : '';
                $url = '';
                $zone = '';
                $title = '';

                if (is_array($meta)) {
                    $url = isset($meta['url']) ? esc_url_raw((string) $meta['url']) : '';
                    $zone = strtolower(trim((string) ($meta['zone'] ?? '')));
                    $title = isset($meta['title']) ? sanitize_text_field((string) $meta['title']) : '';
                }

                if ($zone === 'moat' || $zone === 'moat_data') {
                    $zone = 'moatdata';
                }

                if (!preg_match('/^SEOGEN_LINK_\d+$/', $token)) {
                    if ($this->logger) {
                        $this->logger->warning('Internal link token map entry rejected: invalid token format.', array(
                            'token' => $token,
                        ));
                    }
                    continue;
                }

                if ($url === '') {
                    if ($this->logger) {
                        $this->logger->warning('Internal link token map entry rejected: empty URL.', array(
                            'token' => $token,
                            'zone' => $zone,
                        ));
                    }
                    continue;
                }

                if (!in_array($zone, array('introduction', 'moatdata', 'features'), true)) {
                    if ($this->logger) {
                        $this->logger->warning('Internal link token map entry rejected: invalid zone.', array(
                            'token' => $token,
                            'zone' => $zone,
                            'url' => $url,
                        ));
                    }
                    continue;
                }

                if (!isset($internal_links[$token])) {
                    $internal_links[$token] = array(
                        'url' => $url,
                        'zone' => $zone,
                        'title' => $title,
                    );
                }
            }

            if ($this->logger) {
                $this->logger->info('Internal link selection contract accepted.', array(
                    'enabled' => true,
                    'received_links' => $selection_metrics['received_links'],
                    'received_map' => $selection_metrics['received_map'],
                    'accepted' => $selection_metrics['accepted'],
                    'rejected' => $selection_metrics['rejected'],
                    'tokens' => array_keys($internal_links),
                    'zones' => array_values(array_unique(array_map(static function ($item) {
                        return isset($item['zone']) ? (string) $item['zone'] : '';
                    }, $internal_links))),
                ));
            }
        } else {
            unset($input_data['seogen_links'], $input_data['seogen_token_map']);

            if ($this->logger) {
                $this->logger->info('Internal linking skipped: feature disabled.', array(
                    'reason' => 'seo_gen_internal_link_count=0',
                ));
            }
        }

        // Step 3: Build prompt data using the Prompt_Builder with Generation_Context
        $prompt_input = array_merge($input_data, array(
            'software_name'         => $extracted_data['software_name'] ?: ($input_data['software_name'] ?? ''),
            'version'               => $extracted_data['version'] ?: ($input_data['version'] ?? ''),
            'homepage'              => $extracted_data['homepage'] ?: ($input_data['source_url'] ?? ''),
            'source_url'              => $extracted_data['homepage'] ?: ($input_data['source_url'] ?? ''),
            'download_link'         => $input_data['download_link'] ?? '',
            'article_context'       => $article_context,
            'valid_taxonomy_map'    => \json_encode($taxonomy_map),
            'detected_metadata'     => \json_encode($extracted_data), // Pass grounding hints
            'seogen_links'         => $internal_linking_enabled ? $prompt_internal_links : array(),
        ));

        $prompt_data = $this->prompt_builder->build_prompt_data($prompt_input, $input_type, $context);

        $software_name = $prompt_data['software_name'];
        $category      = $prompt_data['category'];

        // @MODIFIED 2025-12-04 v1.5.0: Partial regeneration - pass selected sections
        // @MODIFIED 2026-01-04: Build excluded_sections list for the validator
        $normalized_regen_sections = $this->normalize_regen_sections((array) ($input_data['regen_sections'] ?? array()));
        $is_full_article           = empty($normalized_regen_sections) || in_array('all', $normalized_regen_sections, true);
        $excluded_sections         = array();

        if (!$is_full_article) {
            $prompt_data['regen_sections'] = array_values(
                array_filter(
                    $normalized_regen_sections,
                    static function ($section) {
                        return $section !== 'toc';
                    }
                )
            );

            if ($this->logger) {
                $this->logger->info('Partial regeneration mode', array('sections' => $prompt_data['regen_sections']));
            }

            $all_fields      = Article_Schema::get_validation_field_list(Article_Schema::get_ordered_section_keys());
            $included_fields = Article_Schema::get_validation_field_list($prompt_data['regen_sections']);
            $excluded_sections = array_values(array_diff($all_fields, $included_fields));
        }

        // ─────────────────────────────────────────────────────────────
        // [PHASE 3D, 2.32.28] THIN-OUTPUT GUARD — full-render self-heal.
        // When an UPDATE is run as a FULL render (regen_sections is the
        // full section set — forced-legacy rewrite or sentinel-absent
        // self-heal), a 200-OK AI response that OMITS the prose sections
        // is not an acceptable publish: merged_clone can only preserve
        // what the live schema snapshot holds, and sentinel-absent posts
        // often hold nothing for those zones (log evidence 2026-09-06
        // job 1155/post 351: gemini-2.5-flash returned only tech_specs,
        // pros_cons, whats_new, system_requirements, hero_section and
        // the page shipped with 3 zones). Retry the AI call ONCE with a
        // DIFFERENT provider/model; if the retry is also thin, throw a
        // deterministic failure so the job handler parks the discovery
        // ('full_render_ai_omitted_sections' -> abort strategy: post left
        // untouched, item parked in Failed tab, manual Run-now overrides).
        // Scoped surgical (partial) updates are NOT affected: only full
        // renders on existing posts are guarded.
        // ─────────────────────────────────────────────────────────────
        $_tg_is_full_render = ( empty( $normalized_regen_sections )
            || in_array( 'all', $normalized_regen_sections, true ) );
        $_tg_is_update_post  = ! empty( $input_data['existing_post_id'] );
        $_tg_guard_enabled   = $_tg_is_full_render && $_tg_is_update_post;

        // One full-render thin-output retry per job process (defensive:
        // never loop more than twice even if a caller re-enters).
        $_tg_attempt          = 0;
        $_tg_thin_sections    = array();
        $_tg_retry_model      = '';
        $_tg_retry_provider   = '';

        // Closure: run the AI call + normalize + schema build once. On a
        // thin full-render output it returns the list of missing expected
        // sections; success returns an empty array. $article_data/$schema
        // /$debug_data are written back by reference for the success path.
        $_tg_run_attempt = function () use (
            &$raw_article_data, &$debug_data, &$article_data, &$schema,
            &$excluded_sections, &$failed_sections, &$internal_links,
            &$is_full_article, &$is_update,
            $prompt_data, $input_data, $context, $heartbeat_callback,
            $article_context, $extracted_data, $normalized_regen_sections,
            $internal_linking_count, $internal_linking_enabled,
            $pre_resolved_links, $software_name, $taxonomy_map
        ) {
            // Step 6: Call AI API
            if ($this->logger) {
                $this->logger->info('Calling AI', array('grounding' => $context->grounding, 'type' => $context->type));
            }
            $raw_article_data = $this->ai_client->generate_article($prompt_data);

            if ($this->logger) {
                $this->logger->info('DEBUG: Parsed AI Output Keys', array_keys($raw_article_data));
                if (isset($raw_article_data['moat_data'])) {
                    $this->logger->info('DEBUG: Moat Data Structure', array('moat' => $raw_article_data['moat_data']));
                }
            }

            // Audit Fix: Heartbeat immediately after long AI call to reset timeout window
            if (is_callable($heartbeat_callback)) {
                call_user_func($heartbeat_callback);
            }

            if (!is_array($raw_article_data)) {
                $message = 'AI client returned non-array payload: ' . gettype($raw_article_data);
                if ($this->logger) {
                    $this->logger->error($message);
                }
                throw new \RuntimeException($message);
            }

            // Preserve debug data before schema coercion strips unknown keys.
            $debug_data = isset($raw_article_data['_debug']) && is_array($raw_article_data['_debug'])
                ? $raw_article_data['_debug']
                : array();

            unset($raw_article_data['_debug']);

            // Normalize provider-specific response, then force canonical contract.
            $article_data = $this->normalize_ai_response($raw_article_data, $context);
            $article_data = $this->canonicalize_article_payload($article_data);

            // @FIX 2026-08-24: Deterministic Video Block contract.
            // Runs AFTER Response_Normalizer::normalize() so source/existing videos
            // bypass the flaky 3s oEmbed gate that strips AI guesses. Resolution
            // priority (see apply_video_block_contract):
            //   1. Update: existing post already has a video -> keep it, never add another.
            //   2. Source post carries a video -> adopt it (new posts and video-less updates).
            //   3. Fall back to the AI-returned (oEmbed-verified) video_url, else empty.
            $article_data = $this->apply_video_block_contract($article_data, $input_data);

            // @MODIFIED 2026-05-20: AI no longer generates download_section.
            // Discard any download_section from AI output — system builds it from canonical links.
            unset($article_data['download_section']);

            /*
             * HARDEN STRUCTURED FACTS BEFORE MANUAL OVERRIDES / HERO BUILD
             * Why here:
             * - article_data is already canonicalized
             * - discovery-approved links still exist in $extracted_data['resolved_links']
             * - valid taxonomy map still exists in $taxonomy_map path
             * This keeps one authority: repair the article contract itself, then let downstream
             * hero/meta/taxonomy consumers read the repaired contract.
             */

    // @MODIFIED 2026-05-20: Build download_section from canonical links only.
        // AI no longer generates download links — system is the single source of truth.
        $canonicalInputLinks = array();
        if (!empty($input_data['canonical_download_links']) && is_array($input_data['canonical_download_links'])) {
            $canonicalInputLinks = $input_data['canonical_download_links'];
        } elseif (!empty($pre_resolved_links) && is_array($pre_resolved_links)) {
            $canonicalInputLinks = $pre_resolved_links;
        }

        if (!empty($resolvedMetaLinks) && empty($canonicalInputLinks)) {
            $canonicalInputLinks = $resolvedMetaLinks;
        }

        $canonicalInputLinks = \SEO_Article_Generator\Generator\Download_Link_Helper::reconcile_source_links($canonicalInputLinks, $pre_resolved_links);

        // DIAGNOSTIC: Log input canonical links
        if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
            error_log( sprintf(
                '[ArticleGenerator] canonicalInputLinks: count=%d | source=%s | software=%s',
                count( $canonicalInputLinks ),
                ! empty( $input_data['canonical_download_links'] ) ? 'canonical_download_links' : ( ! empty( $pre_resolved_links ) ? 'pre_resolved_links' : 'resolvedMetaLinks' ),
                $software_name
            ) );
            foreach ( $canonicalInputLinks as $_i => $_link ) {
                $_url = is_array( $_link ) ? ( $_link['url'] ?? '' ) : (string) $_link;
                $_text = is_array( $_link ) ? ( $_link['text'] ?? '' ) : '';
                $_variant = is_array( $_link ) ? ( $_link['variant'] ?? '' ) : '';
                $_platform = is_array( $_link ) ? ( $_link['platform'] ?? '' ) : '';
                error_log( sprintf(
                    '[ArticleGenerator]   INPUT[%d]: url=%s | text=%s | variant=%s | platform=%s',
                    $_i, $_url, substr( $_text, 0, 60 ), $_variant, $_platform
                ) );
            }
        }

        if (!empty($canonicalInputLinks)) {
            $fallback_platform = 'Windows';
            if (!empty($article_data['tech_specs']['os_support'])) {
                $parts = array_map('trim', explode(',', $article_data['tech_specs']['os_support']));
                if (!empty($parts[0])) {
                    $fallback_platform = $parts[0];
                }
            }

            $homepage_for_guard = trim((string) ($article_data['tech_specs']['homepage'] ?? $extracted_data['homepage'] ?? ''));
    		if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
    			error_log( '[ArticleGenerator] canonical links: homepage_guard=' . $homepage_for_guard . ' | input_count=' . count($canonicalInputLinks) . ' | software=' . $software_name);
    		}

            $normalizedCanonicalLinks = \SEO_Article_Generator\Generator\Download_Link_Helper::normalize_links(
                $canonicalInputLinks, 'Other', $homepage_for_guard, (string) $software_name
            );
            \SEO_Article_Generator\Generator\Download_Link_Helper::trace_links('article_canonical:' . (string) $software_name, $canonicalInputLinks, $normalizedCanonicalLinks, $this->logger);

            // DIAGNOSTIC: Log output summary
            if ( defined( 'SEO_GEN_DEBUG_LINKS' ) && SEO_GEN_DEBUG_LINKS ) {
                error_log( sprintf(
                    '[ArticleGenerator] NORMALIZATION RESULT: input=%d | output=%d | dropped=%d | software=%s',
                    count( $canonicalInputLinks ), count( $normalizedCanonicalLinks ),
                    count( $canonicalInputLinks ) - count( $normalizedCanonicalLinks ), $software_name
                ) );
                foreach ( $normalizedCanonicalLinks as $_i => $_link ) {
                    error_log( sprintf(
                        '[ArticleGenerator]   OUTPUT[%d]: url=%s | platform=%s | variant=%s | primary=%s',
                        $_i, $_link['url'] ?? '', $_link['platform'] ?? '', $_link['variant'] ?? '',
                        ! empty( $_link['is_primary'] ) ? 'yes' : 'no'
                    ) );
                }
            }

            if (!empty($normalizedCanonicalLinks)) {
                $article_data['download_section'] = array(
                    'heading' => 'Download ' . ($input_data['software_name'] ?? $software_name),
                    'links'   => $normalizedCanonicalLinks,
                );
                $article_data['_canonical_download_links'] = $normalizedCanonicalLinks;

                if ($this->logger) {
                    $this->logger->info(
                        'Download section built from canonical_download_links (' . count($normalizedCanonicalLinks) . ' links).',
                        array('software' => $software_name)
                    );
                }
            }
        }

            // 2) Recover category from valid taxonomymap when AI omitted/returned an invalid category.
            $validCategorySlugMap = array();
            $validCategoryNameToSlug = array();
            foreach ($taxonomy_map as $row) {
                if (!is_array($row)) {
                    continue;
                }

                $slug = isset($row['slug']) ? sanitize_title((string) $row['slug']) : '';
                $name = isset($row['name']) ? trim((string) $row['name']) : '';

                if ($slug !== '') {
                    $validCategorySlugMap[$slug] = $slug;
                }
                if ($name !== '' && $slug !== '') {
                    $validCategoryNameToSlug[strtolower($name)] = $slug;
                }
            }

            $rawCategoryField = $article_data['category'] ?? '';
            $categoryCandidateList = is_array($rawCategoryField)
                ? $rawCategoryField
                : array_filter(array_map('trim', explode(',', (string)$rawCategoryField)));

            $normalizedArticleCategory = '';
            foreach ($categoryCandidateList as $candidateRaw) {
                $candidateSlug = sanitize_title($candidateRaw);
                if (isset($validCategorySlugMap[$candidateSlug])) {
                    $normalizedArticleCategory = $candidateSlug;
                    break;
                }
                $candidateNameKey = strtolower($candidateRaw);
                if (isset($validCategoryNameToSlug[$candidateNameKey])) {
                    $normalizedArticleCategory = $validCategoryNameToSlug[$candidateNameKey];
                    break;
                }
            }

    	if (!$normalizedArticleCategory && !empty($input_data['category'])) {
    		$seedCategory = trim((string) $input_data['category']);
    		$seedSlug = sanitize_title($seedCategory);
    		if (isset($validCategorySlugMap[$seedSlug])) {
    			$normalizedArticleCategory = $seedSlug;
    		} else {
    			$seedNameKey = strtolower($seedCategory);
    			if (isset($validCategoryNameToSlug[$seedNameKey])) {
    				$normalizedArticleCategory = $validCategoryNameToSlug[$seedNameKey];
    			}
    		}
    	}

    	// @MODIFIED 2026-05-01: Try tech_specs.application_category and hero_section category as category hints
    	// DO NOT add software_type — it contains COMPLEX_ENGINE/SIMPLE_UTILITY (moat tokens, not categories)
    	if (!$normalizedArticleCategory) {
    		$fallbackHints = array_filter(array_map('trim', explode(',', (string)($article_data['tech_specs']['application_category'] ?? ''))));
    		// @MODIFIED 2026-04-29: Also try hero_section category when root category is empty
    		$heroCat = trim((string)($article_data['hero_section']['category'] ?? ''));
    		if ($heroCat !== '') {
    			$fallbackHints[] = $heroCat;
    		}
    		foreach ($fallbackHints as $hint) {
    			if ($hint === '') continue;
    			$hintSlug = sanitize_title($hint);
    			if (isset($validCategorySlugMap[$hintSlug])) {
    				$normalizedArticleCategory = $hintSlug;
    				break;
    			}
    			$hintNameKey = strtolower($hint);
    			if (isset($validCategoryNameToSlug[$hintNameKey])) {
    				$normalizedArticleCategory = $validCategoryNameToSlug[$hintNameKey];
    				break;
    			}
    		}
    	}

            if ($normalizedArticleCategory !== '') {
                $article_data['category'] = $normalizedArticleCategory;
                if (!isset($article_data['hero_section']) || !is_array($article_data['hero_section'])) {
                    $article_data['hero_section'] = array();
                }
                if (empty($article_data['hero_section']['category'])) {
                    $article_data['hero_section']['category'] = $normalizedArticleCategory;
                }
            }

    	// 3) [FIX] Do NOT recover tags from category / software metadata.
    	// Social hashtags (Buffer/Jetpack) must be ONLY AI-generated, SEO-optimized tags.
    	// Injecting software_name / license / category here reproduces the source post
    	// tags, slugs and categories the user explicitly banned from social shares.
    	// On-site taxonomy is owned separately by assign_taxonomies() (which discards
    	// AI tags anyway), so leaving article_data['tags'] empty when the AI omits it
    	// is safe and keeps this field purely AI-generated. The Buffer/Jetpack share
    	// layer falls back to the configured DEFAULT_TAGS option when no AI tags exist.
    	if (empty($article_data['tags']) || !is_array($article_data['tags'])) {
    		$article_data['tags'] = array();
    	}

            $article_data = $this->canonicalize_article_payload($article_data);

            // Inject internal links if enabled.
            if ($internal_linking_enabled && !empty($internal_links)) {
    		$article_data = $this->inject_internal_links($article_data, $internal_links, $internal_linking_count);
            } elseif ($internal_linking_enabled && $this->logger) {
                $this->logger->info('Internal linking enabled but no valid token map survived normalization.');
            }

            // [AUDIT FIX — v2] MOAT empty-section guard.
            // Condition: moat was requested AND moat_data is empty.
            // software_type is a classification signal, NOT a content delivery guarantee.
            // Checking software_type in the AND was masking the abandonment case where
            // the AI classifies the type but still returns no moat_data body.
    	$moat_was_requested = in_array('all', $normalized_regen_sections, true)
    		|| in_array('moat', $normalized_regen_sections, true);

            if ($moat_was_requested && empty($article_data['moat_data'])) {
                $is_simple_utility = \SEO_Article_Generator\Generator\Article_Schema::is_simple_utility($article_data['software_type'] ?? null);
                if ($is_simple_utility) {
                    if ($this->logger) {
                        $this->logger->info(
                            'MOAT omitted by design for SIMPLE_UTILITY — skipping failure gate.',
                            [
                                'software'      => $software_name,
                                'software_type' => $article_data['software_type'],
                            ]
                        );
                    }
                } else {
                    if ($this->logger) {
                        $this->logger->warning(
                            'MOAT section requested but AI returned no moat_data. ' .
                            'software_type present: ' . (!empty($article_data['software_type']) ? $article_data['software_type'] : 'absent') . '. ' .
                            'Prompt gate may have suppressed generation due to thin grounding.',
                            [
                                'software'      => $software_name,
                                'grounding_len' => mb_strlen($article_context),
                                'sections'      => $normalized_regen_sections,
                                'software_type' => $article_data['software_type'] ?? null,
                            ]
                        );
                    }
                    $failed_sections[] = 'moat';
                }
    }

    // @MODIFIED 2026-05-02: Conditional competitor exclusion for SIMPLE_UTILITY.
    // SIMPLE_UTILITY software (file cleaners, format converters, small utilities) rarely
    // has meaningful competitor comparisons. Omit to avoid padded/low-value tables.
    // @MODIFIED 2026-08-26 [DATA-PRESERVE]: Blank FAQ/MOAT on the FRESH payload only.
    // Enforcement formerly lived in Article_Schema::normalize(), which also ran on
    // Schema_Sync_Service::load_schema() and silently wiped stored faqs/moat_data from
    // _seo_gen_article_snapshot once software_type had been persisted.
    // Generation-time is the only safe point: new posts render no faq/moat zones;
    // updates keep empty payloads so merged_clone()/PPB preserve the live zones untouched.
    if (\SEO_Article_Generator\Generator\Article_Schema::is_simple_utility($article_data['software_type'] ?? null)) {
    	if (!empty($article_data['competitors'])) {
    		$orig_comp_count = count($article_data['competitors']);
    		$article_data['competitors'] = array();
    		$article_data['main_software_comparison'] = array();
    		if ($this->logger) {
    			$this->logger->info('Competitor table omitted for SIMPLE_UTILITY', array(
    				'software' => $software_name,
    				'original_count' => $orig_comp_count,
    			));
    		}
    	}
    	// [DATA-PRESERVE 2026-08-26] Blank FAQ/MOAT on fresh payload — safe because
    	// merged_clone() with preserve_non_empty will keep live zones when scope excludes them.
    	$article_data['moat_data'] = array('content' => array());
    	$article_data['faqs']      = array();
    }

    // @MODIFIED 2026-03-04: Strict Section Filtering via regen_sections
            // This handles both UI checkboxes (manual) and Discovery settings.
            // It ensures AI hallucinations or prompt disobedience don't bypass user choices.
            // NOTE: strip_excluded_validation_fields is only needed to prevent the AI returning
            // hallucinated data for excluded sections. It must NOT remove existing data that
            // to_html() and Surgical_Patcher need for untouched zones.
            // The prompt already receives $prompt_data['regen_sections'] to constrain AI output.
            // No further stripping of $article_data is needed here.
            // REMOVED: strip_excluded_validation_fields call on $article_data.
            if (!empty($excluded_sections)) {
                // Only scope the AI prompt — do NOT mutate $article_data that feeds to_html().
                // $article_data retains all sections so the formatter can render untouched zones.
            }

    // @MODIFIED 2025-12-15 v2.2.0: Hallucination filter - warn about likely fabrications
            // Per user decision: warn + suggest improvements, NOT block
            $hallucination_check = \SEO_Article_Generator\Validation\Hallucination_Filter::check(
                $article_data,
                $input_data
            );
            if (!$hallucination_check['valid']) {
                if ($this->logger) {
                    $this->logger->warning('Hallucination filter detected potential issues', [
                        'issues' => $hallucination_check['issues'],
                        'suggestions' => $hallucination_check['suggestions'],
                    ]);
                }
                // Store warnings for frontend display (attached to result, not blocking)
                $this->hallucination_warnings = $hallucination_check;
            }

            // @MODIFIED 2026-07-18: Single-source-of-truth version enforcement.
            // The known/authoritative version is the staged/input version that the
            // is_newer_version() gate already matched during staging. That version
            // MUST be the only version written to the post. Previously the correction
            // only fired on a "Version mismatch" warning and only patched a hard-coded
            // subset, so hero_section.version and preserved legacy text in
            // meta_description/introduction (partial regen) kept stale versions. Now we
            // force the canonical version into EVERY version-bearing surface whenever
            // the input version is valid. Because Hero_Data_Provider::from_schema
            // (line 92) and resolve_plugin_update_title (line 1217) both derive from
            // tech_specs.version, this one write propagates to the canonical post meta
            // (_seo_gen_version, seogenherodata) and the title for New / Legacy /
            // Update / self-heal paths alike.
            $canonical_version = trim((string) ($input_data['version'] ?? ''));
            $canonical_valid   = (bool) preg_match('/^\d+\.\d+(\.\d+)?/', $canonical_version);

            if ($canonical_valid) {
                $ai_version = isset($article_data['tech_specs']['version'])
                    ? (string) $article_data['tech_specs']['version']
                    : '';

                // Guard: keep the AI version when the input is clearly malformed
                // (e.g. "0.13" supplied for a major release like Adobe Animate 2024).
                $input_suspicious = (
                    $ai_version !== ''
                    && floatval($canonical_version) < 1
                    && floatval($ai_version) >= 10
                );

                if (! $input_suspicious) {
                    // Stale tokens to replace: the AI-returned version AND the
                    // previously-published version still embedded in preserved
                    // meta_description / introduction / title text (read from the live
                    // post via the version resolver, priority _seo_gen_version).
                    $post_id = isset($input_data['existing_post_id'])
                        ? (int) $input_data['existing_post_id']
                        : 0;

                    $legacy_version = $post_id > 0
                        ? SeoGen_Version_Resolver::current_version($post_id)
                        : '';

                    $stale_versions = array_unique(array_filter(
                        array($ai_version, $legacy_version),
                        static function ($v) use ($canonical_version) {
                            return is_string($v) && $v !== '' && $v !== $canonical_version;
                        }
                    ));

                    // 1) Canonical version on every structured field.
                    $article_data['tech_specs']['version'] = $canonical_version;
                    if (isset($article_data['version'])) {
                        $article_data['version'] = $canonical_version;
                    }
                    if (! isset($article_data['hero_section']) || ! is_array($article_data['hero_section'])) {
                        $article_data['hero_section'] = array();
                    }
                    $article_data['hero_section']['version'] = $canonical_version;

                    // 2) Replace stale version tokens inside every text carrier.
                    foreach ($stale_versions as $stale) {
                        $vr_pattern = '/\b' . preg_quote($stale, '/') . '\b/';

                        if (! empty($article_data['download_section']['heading'])) {
                            $article_data['download_section']['heading'] = preg_replace(
                                $vr_pattern,
                                $canonical_version,
                                (string) $article_data['download_section']['heading']
                            );
                        }

                        if (! empty($article_data['download_section']['links']) && is_array($article_data['download_section']['links'])) {
                            foreach ($article_data['download_section']['links'] as &$dlink) {
                                if (! empty($dlink['text'])) {
                                    $dlink['text'] = preg_replace($vr_pattern, $canonical_version, (string) $dlink['text']);
                                }
                            }
                            unset($dlink);
                        }

                        if (is_string($article_data['meta_description'] ?? null)) {
                            $article_data['meta_description'] = \SEO_Article_Generator\Generator\Hero_Data_Provider::repair_meta_to_spec(
                                $article_data['meta_description'],
                                $article_data
                            );
                        }

                        if (is_array($article_data['introduction'] ?? null)) {
                            foreach ($article_data['introduction'] as $intro_idx => $intro_text) {
                                if (is_string($intro_text)) {
                                    $article_data['introduction'][$intro_idx] = preg_replace($vr_pattern, $canonical_version, $intro_text);
                                }
                            }
                        }

                        if (is_array($article_data['whats_new'] ?? null)) {
                            foreach ($article_data['whats_new'] as $wn_idx => $wn_item) {
                                if (is_string($wn_item)) {
                                    $article_data['whats_new'][$wn_idx] = preg_replace($vr_pattern, $canonical_version, $wn_item);
                                }
                            }
                        }
                    }

                    // 3) Catch-all for preserved legacy text. In partial regen the
                    //    previous generation's meta_description / introduction are kept
                    //    verbatim, so they may still carry a version we did not know
                    //    about (e.g. 6.34.0.6878) AND leaked markdown like **bold**.
                    //    Normalize both: strip markdown, then force ANY software
                    //    version token (3+ dotted segments, or a "Build N" suffix) to
                    //    the canonical version. The 3+-segment requirement avoids
                    //    clobbering two-segment numbers such as file sizes (e.g. 46.6).
                    $vt_pattern = '/\b\d+\.\d+\.\d+(?:\.\d+)?(?:\s*Build\s*\d+)?\b/i';

                    if (is_string($article_data['meta_description'] ?? null)) {
                        $article_data['meta_description'] = \SEO_Article_Generator\Generator\Hero_Data_Provider::repair_meta_to_spec(
                            $article_data['meta_description'],
                            $article_data
                        );
                    }

                    if (is_array($article_data['introduction'] ?? null)) {
                        foreach ($article_data['introduction'] as $intro_idx => $intro_text) {
                            // NOTE: do NOT strip_markdown here — the Content_Formatter
                            // re-processes introduction through process_markdown(), so
                            // stripping would discard intended **bold** emphasis.
                            if (is_string($intro_text)) {
                                $article_data['introduction'][$intro_idx] = preg_replace($vt_pattern, $canonical_version, $intro_text);
                            }
                        }
                    }

                    if (! empty($article_data['download_section']['heading'])) {
                        $article_data['download_section']['heading'] = preg_replace(
                            $vt_pattern,
                            $canonical_version,
                            (string) $article_data['download_section']['heading']
                        );
                    }

                    if ($this->logger) {
                        $this->logger->info(
                            'Version SSOT enforced across all surfaces.',
                            array(
                                'software'  => $software_name,
                                'canonical' => $canonical_version,
                                'replaced'  => $stale_versions,
                                'post_id'   => $post_id,
                            )
                        );
                    }
                } elseif ($this->logger) {
                    $this->logger->info(
                        'Version validation: Input version appears invalid, keeping AI version.',
                        array(
                            'ai_returned'   => $ai_version,
                            'input_version' => $canonical_version,
                            'software'      => $software_name,
                        )
                    );
                }
            }

    // @MODIFIED 2025-12-11 v1.6.1: Use strict Schema validation immediately
            // @MODIFIED 2025-12-12 v1.8.1: Partial regen merge logic with sanity checks

            // @MODIFIED 2025-01-XX: Changelog Verification Gate
            // Ensure that any generated changelog/whats_new data is backed by a verifiable source.
            // Two modes:
            // - CONTEXT MODE: whats_new from provided article_context (changelog HTML) - verified if context contains version
            // - URL MODE: whats_new from web search - requires valid changelogurl
            // Set source hint for verifier
            $hasContext = !empty($article_context);
            $article_data['whats_new_source'] = $hasContext ? 'context' : 'search';
            $article_data['article_context'] = $article_context; // Pass to verifier

            $clVerify = $this->verify_changelog_data($article_data);
            if (!$clVerify['ok'] && !empty($article_data['whats_new'])) {
                // Verification failed
                if ($clVerify['mode'] === 'context') {
                    // Context mode failed - context didn't contain version or was too thin
                    // Log but keep whats_new (it came from provided source)
                    if ($this->logger) {
                        $this->logger->warning('Changelog context verification inconclusive - keeping whats_new from source', [
                            'reason' => $clVerify['reason'],
                            'mode' => $clVerify['mode'],
                        ]);
                    }
                } else {
                    // URL mode failed - no valid changelogurl and no verified context
                    // OMIT whats_new entirely to prevent hallucinated changelogs
                    if ($this->logger) {
                        $this->logger->warning('Changelog verification failed - OMITTING whats_new (no verified source)', [
                            'reason' => $clVerify['reason'],
                            'mode' => $clVerify['mode'],
                        ]);
                    }
                    unset($article_data['whats_new']);
                    $article_data['whats_new'] = [];
                }

                // Always flag changelogurl for manual review if it was provided but invalid
                if (isset($article_data['tech_specs']) && is_array($article_data['tech_specs'])) {
                    $article_data['tech_specs']['changelogurl'] = null;
                }

                if (!isset($article_data['needs_manual_input']) || !is_array($article_data['needs_manual_input'])) {
                    $article_data['needs_manual_input'] = [];
                }
                if (!in_array('tech_specs.changelogurl', $article_data['needs_manual_input'], true)) {
                    $article_data['needs_manual_input'][] = 'tech_specs.changelogurl';
                }
            } elseif ($clVerify['ok'] && isset($article_data['tech_specs']) && is_array($article_data['tech_specs'])) {
                // Verification passed, normalize the URL if in URL mode
                if ($clVerify['mode'] === 'url' && $clVerify['url'] !== '') {
                    $article_data['tech_specs']['changelogurl'] = $clVerify['url'];
                }
                if ($this->logger) {
                    $this->logger->info('Changelog verification passed', [
                        'mode' => $clVerify['mode'],
                        'reason' => $clVerify['reason'],
                    ]);
                }
            }

            // @MODIFIED 2026-03-20: Preserve manual input flags across DTO conversion
            $manual_flags = $article_data['needs_manual_input'] ?? [];

            // @MODIFIED 2026-04-05: [FAQ GROUNDING FIX] Filter unsupported FAQ claims against grounded context
            if (!empty($article_data['faqs']) && is_array($article_data['faqs'])) {
                $grounded_bag = strtolower(wp_json_encode(array(
                    'techspecs'           => $article_data['tech_specs'] ?? array(),
                    'systemrequirements'  => $article_data['systemrequirements'] ?? array(),
                    'downloadsection'     => $article_data['download_section'] ?? array(),
                    'features'            => $article_data['features'] ?? array(),
                    'articlecontext'      => $article_context,
                )));

                $filtered_faqs = array();

                foreach ($article_data['faqs'] as $faq) {
                    if (!is_array($faq)) {
                        continue;
                    }

                    $question = trim((string) ($faq['question'] ?? ''));
                    $answer   = trim(wp_strip_all_tags((string) ($faq['answer'] ?? '')));

                    if ($question === '' || $answer === '') {
                        continue;
                    }

                    $requires_grounding = (bool) preg_match(
                        '/\b\d+(?:,\d+)*(?:\.\d+)?\b|quota|trial|free|paid|supports?|compatible|requires?|windows|mac|linux|kindle|bookwalker|dmm|audiobooks\.com/i',
                        $answer
                    );

                    if ($requires_grounding) {
                        $tokens = preg_split('/[^a-z0-9\.]+/i', strtolower($question . ' ' . $answer));
                        $tokens = array_values(array_unique(array_filter($tokens, static function ($token) {
                            return is_string($token) && strlen($token) >= 4;
                        })));

                        $matches = 0;
                        foreach ($tokens as $token) {
                            if (strpos($grounded_bag, $token) !== false) {
                                $matches++;
                            }
                            if ($matches >= 3) {
                                break;
                            }
                        }

                        if ($matches < 3) {
                            continue;
                        }
                    }

                    $filtered_faqs[] = $faq;

                    if (count($filtered_faqs) >= 3) {
                        break;
                    }
                }

                if (empty($filtered_faqs)) {
                    unset($article_data['faqs']);
                } else {
                    $article_data['faqs'] = array_values($filtered_faqs);
                }
            }

            try {
                $partial_schema = Article_Schema::from_ai_array($article_data);
            } catch (\Exception $e) {
                $message = 'AI client returned invalid schema: ' . $e->getMessage();
                if ($this->logger) {
                    $this->logger->error($message, array('error' => $e->getMessage()));
                }
                throw new \RuntimeException($message);
            }

            // Partial regen: merge only valid sections into existing snapshot
            $base_schema = null;
            if (!empty($prompt_data['regen_sections'])) {
                $post_id = isset($input_data['existing_post_id']) ? (int) $input_data['existing_post_id'] : 0;
                $base_schema = $this->load_base_schema_snapshot($post_id);

                if ($base_schema !== null) {
                    $valid_sections = array();

                    foreach ($prompt_data['regen_sections'] as $section) {
                        if ($this->section_passes_sanity_check($partial_schema, $section)) {
                            $valid_sections[] = $section;
                        } else {
                            $failed_sections[] = $section;
                        }
                    }

                    if (!empty($failed_sections) && $this->logger) {
                        $this->logger->warning('Partial regen returned empty for sections', array(
                            'failed' => $failed_sections,
                            'valid' => $valid_sections,
                        ));
                    }

                    if (!empty($valid_sections)) {
                        $schema = Article_Schema::merged_clone($base_schema, $partial_schema, $valid_sections);
                    } else {
                        $message = 'All partial regeneration sections failed sanity check. No changes applied.';
                        if ($this->logger) {
                            $this->logger->error($message, array('failed_sections' => $failed_sections));
                        }
                        throw new \RuntimeException($message);
                    }
                } else {
                    // No existing snapshot (new post or missing data)
                    $schema = $partial_schema;
                }
            } else {
                // Full generation
                $schema = $partial_schema;
            }

            // Convert to array for the existing pipeline
            $article_data = $schema->to_array();
            $article_data = $this->normalize_required_containers($article_data);

            // [DOWNLOAD-REBUILD FIX 2026-09-09] merged_clone() overwrites $article_data
            // with the merged schema's content. For partial regens where 'download' failed
            // the AI sanity check (AI returned empty download), the merged schema inherits
            // the base schema's download section — which may be empty or stale. The canonical
            // download links were built into $article_data BEFORE merged_clone (line ~989)
            // but were destroyed by $article_data = $schema->to_array() above. Re-apply
            // them here so the mandatory gate always sees the system-built download section.
            if (!empty($canonicalInputLinks)) {
                $fallback_platform = 'Windows';
                $os_for_dl = (string) $this->array_path($article_data, array('tech_specs', 'os_support'), '');
                if ($os_for_dl !== '') {
                    $dl_parts = array_map('trim', explode(',', $os_for_dl));
                    if (!empty($dl_parts[0])) {
                        $fallback_platform = $dl_parts[0];
                    }
                }
                $normalizedCanonicalLinks = \SEO_Article_Generator\Generator\Download_Link_Helper::normalize_links(
                    $canonicalInputLinks,
                    $fallback_platform,
                    (string) $this->array_path($article_data, array('tech_specs', 'homepage'), ''),
                    $software_name,
                    (string) $this->array_path($article_data, array('tech_specs', 'changelogurl'), '')
                );
                if (!empty($normalizedCanonicalLinks)) {
                    $article_data['download_section'] = array(
                        'heading' => 'Download ' . $software_name,
                        'links'   => $normalizedCanonicalLinks,
                    );
                    $article_data['_canonical_download_links'] = $normalizedCanonicalLinks;
                    $schema = Article_Schema::from_array($article_data);
                    if ($this->logger) {
                        $this->logger->info(
                            'Download section rebuilt from canonical links after merged_clone (' . count($normalizedCanonicalLinks) . ' links).',
                            array('software' => $software_name)
                        );
                    }
                }
            }

            // @MODIFIED 2026-04-05: [UNTOUCHED SECTIONS PRESERVATION v2] Preserve sections not requested for regen
            if ($is_update && !empty($base_schema)) {
                $base_array = $base_schema->to_array();
                $requested_sections = array_values(array_filter((array) ($prompt_data['regen_sections'] ?? array())));
                $full_regen = empty($requested_sections) || in_array('all', $requested_sections, true);

                $preserve_map = array(
                    'moat'            => 'moatdata',
                    'whatsnew'        => 'whatsnew',
                    'faqs'            => 'faqs',
                    'competitors'     => 'competitors',
                    'relatedsoftware' => 'relatedsoftware',
                );

                if (!$full_regen) {
                    foreach ($preserve_map as $regen_key => $article_key) {
                        if (in_array($regen_key, $requested_sections, true)) {
                            continue;
                        }

                        if (empty($article_data[$article_key]) && !empty($base_array[$article_key])) {
                            $article_data[$article_key] = $base_array[$article_key];
                        }
                    }
                }
            }

            // Redundant manual normalization removed (handled by from_ai_array)

            // Step 6b: Override AI download links with manual input when provided.
            // Manual textarea field is sanitized in SEO_Article_Generator_Plugin::sanitize_input_data().
            $manual_input = isset($input_data['download_link'])
                ? trim((string) $input_data['download_link'])
                : '';

            // @MODIFIED 2026-03-08: Determine fallback platform from tech specs
            $fallback_platform = 'Windows';
            $os_support = (string) $this->array_path($article_data, array('tech_specs', 'os_support'), '');
            if ($os_support !== '') {
                $parts = array_map('trim', explode(',', $os_support));
                if (!empty($parts[0])) {
                    $fallback_platform = $parts[0];
                }
            }

            // @MODIFIED 2026-03-08: Actually wire up manual download override (was dead code before)
            if ($manual_input !== '' && ($is_full_article || in_array('download', (array) ($input_data['regen_sections'] ?? []), true))) {
                $manual_links = $this->parse_manual_download_links($manual_input, array($fallback_platform));
                $manual_links = \SEO_Article_Generator\Generator\Download_Link_Helper::normalize_links($manual_links, $fallback_platform, '', $software_name);

                if (!empty($manual_links)) {
                    if (!isset($article_data['download_section']) || !is_array($article_data['download_section'])) {
                        $article_data['download_section'] = array();
                    }
                    $article_data['download_section']['links'] = $manual_links;

                    if ($this->logger) {
                        $this->logger->info('Manual download links applied', array(
                            'accepted_count' => count($manual_links),
                            'raw_input_length' => strlen($manual_input),
                            'software' => $software_name,
                        ));
                    }
                } elseif ($this->logger) {
                    $this->logger->warning('Manual download input provided but no valid links survived normalization', array(
                        'raw_input_start' => substr($manual_input, 0, 50),
                        'software' => $software_name,
                    ));
                }
            }

    	// Use canonical containers contract then normalize download links
    	$article_data = $this->normalize_required_containers($article_data);

    	// @MODIFIED 2026-04-22: Pass homepage for homepage-as-download guard.
    	// Canonical path: tech_specs.homepage is the contract field (Article_Schema has no top-level homepage).
    	// Fallback to extracted_data['homepage'] (source_url) if AI left tech_specs.homepage empty.
    	$_homepage_for_dl_guard = trim((string) ($article_data['tech_specs']['homepage'] ?? $extracted_data['homepage'] ?? ''));
    	$_changelog_for_dl_guard = trim((string) ($article_data['tech_specs']['changelogurl'] ?? $extracted_data['changelogurl'] ?? ''));

    	if (!empty($article_data['download_section']['links'])) {
    		$article_data['download_section']['links'] = \SEO_Article_Generator\Generator\Download_Link_Helper::normalize_links(
    			$article_data['download_section']['links'],
    			$fallback_platform,
    			$_homepage_for_dl_guard,
    			$software_name,
    			$_changelog_for_dl_guard
    		);
    	}

    	$article_data['_canonical_download_links'] = $article_data['download_section']['links'] ?? array();

    	// @MODIFIED 2026-05-20: Link Continuity — AI no longer generates download links.
    	// Recovery only needed when no canonical links exist (edge case: new software, no source links).
    	$has_real_links = false;
    	if (!empty($article_data['download_section']['links'])) {
    		foreach ($article_data['download_section']['links'] as $link) {
    			if (empty($link['_portal_fallback'])) {
    				$has_real_links = true;
    				break;
    			}
    		}
    	}

    	if (!$has_real_links) {
    		// Recovery path A: existing post HTML (updates only)
    		if ($is_update && !empty($input_data['existing_article_html'])) {
    			if ($this->logger) {
    				$this->logger->info('Link Continuity: No new links found. Attempting recovery from existing post content.');
    			}
    			$recovered = array('links' => \SEO_Article_Generator\Integration\Link_Resolver::recover_existing_post_links((int)($input_data['existing_post_id'] ?? 0), $software_name));
    			if (! empty($recovered['links'])) {
    				$article_data['download_section']['links'] = \SEO_Article_Generator\Generator\Download_Link_Helper::normalize_links(
    					$recovered['links'],
    					$fallback_platform,
    					$_homepage_for_dl_guard,
    					$software_name,
    					$_changelog_for_dl_guard
    				);
    				if (!empty($article_data['download_section']['links'])) {
    					$has_real_links = true;
    				}
    				if ($this->logger) {
    					$this->logger->info(sprintf('Link Continuity: Successfully recovered %d link(s) from existing content.', count($article_data['download_section']['links'])));
    				}
    			}
    		}

    		// Recovery path B: grounding=provided new post — escalate to search grounding
    		if (
    			!$has_real_links
    			&& isset($context->grounding)
    			&& $context->grounding === 'provided'
    			&& !$is_update
    			&& !empty($software_name)
    		) {
    			if ($this->logger) {
    				$this->logger->warning(
    					'Link Continuity: provided-grounding new post has no download links. Escalating to search grounding for URL recovery.',
    					['software' => $software_name]
    				);
    			}
    			try {
    				$search_extractor = new \SEO_Article_Generator\AI\Context_Extractor($this->ai_client, $this->logger);
    				$search_extracted = $search_extractor->extract($software_name);
    				$search_links = $search_extracted['resolved_links'] ?? $search_extracted['all_links'] ?? [];
    				$fallback_platform = 'Windows';
    				$search_links = \SEO_Article_Generator\Generator\Download_Link_Helper::normalize_links($search_links, $fallback_platform, $_homepage_for_dl_guard, $software_name, $_changelog_for_dl_guard);
    				if (! empty($search_links)) {
    					$article_data['download_section']['links'] = $search_links;
    					if ($this->logger) {
    						$this->logger->info(
    							sprintf('Link Continuity: Search escalation recovered %d links.', count($search_links)),
    							['software' => $software_name]
    						);
    					}
    				}
    			} catch (\Exception $e) {
    				if ($this->logger) {
    					$this->logger->warning(
    						'Link Continuity: Search escalation failed.',
    						['software' => $software_name, 'error' => $e->getMessage()]
    					);
    				}
    			}
    		}
    	}

            // Step 9: Normalize article through schema and populate hero_section BEFORE formatting
            // @MODIFIED 2025-12-15 v2.1.4: CRITICAL FIX - Moved schema creation and hero population
            // BEFORE to_html() call. Previously hero_section was populated AFTER formatting,
            // causing Content_Formatter to skip the hero block (hero_section was empty).
            $schema = Article_Schema::from_array($article_data);

            // ── Thin-output evaluation for full-render updates ──
            // Expected sections = the full discovery section set (same SSOT
            // Content_Formatter renders), minus toc/all directives, minus
            // faqs/moat for SIMPLE_UTILITY (mirrors the gate at L~1830).
            $_tg_expected = array();
            $defaults = \SEO_Article_Generator\Option_Registry::defaults();
            $_tg_raw = \get_option(
                \SEO_Article_Generator\Option_Registry::DISCOVERY_SECTIONS,
                $defaults[ \SEO_Article_Generator\Option_Registry::DISCOVERY_SECTIONS ]
            );
            if ( is_array( $_tg_raw ) && ! empty( $_tg_raw ) ) {
                $_tg_expected = Article_Schema::normalize_sections( $_tg_raw, array() );
            } else {
                $_tg_expected = Article_Schema::normalize_sections(
                    (array) $defaults[ \SEO_Article_Generator\Option_Registry::DISCOVERY_SECTIONS ],
                    array()
                );
            }
            $_tg_expected = array_values( array_filter( $_tg_expected, static function ( $s ) {
                return is_string( $s ) && $s !== '' && $s !== 'all' && $s !== 'toc';
            } ) );

            if ( \SEO_Article_Generator\Generator\Article_Schema::is_simple_utility( $schema->software_type ) ) {
                $_tg_expected = array_values( array_diff( $_tg_expected, array( 'faqs', 'moat' ) ) );
            }

            // download + hero are rebuilt deterministically/from DTOs even
            // when the AI omits them; their MANDATORY gate already runs below.
            // The guard exists to catch PROSE omissions that would silently
            // ship a page with 3 zones.
            $_tg_prose = array_values( array_diff( $_tg_expected, array( 'hero', 'download', 'video', 'whats_new' ) ) );

            $_tg_missing = array();
            foreach ( $_tg_prose as $_tg_section ) {
                if ( ! $this->section_passes_sanity_check( $schema, $_tg_section ) ) {
                    $_tg_missing[] = $_tg_section;
                }
            }

            return array_values( array_unique( $_tg_missing ) );
        };

        if ( $_tg_guard_enabled ) {
            $_tg_missing = $_tg_run_attempt();
            $_tg_attempt = 1;

            if ( ! empty( $_tg_missing ) ) {
                $_tg_thin_sections = $_tg_missing;
                $this->logger->warning(
                    'THIN-OUTPUT GUARD: full-render update AI response omitted expected prose sections; retrying once with a different model.',
                    array(
                        'software'         => (string) ( $input_data['software_name'] ?? '' ),
                        'existing_post_id' => (int) ( $input_data['existing_post_id'] ?? 0 ),
                        'missing_sections' => $_tg_thin_sections,
                    )
                );

                // Pick a different provider/model via the SAME fallback SSOT
                // the API-error fallback chain uses. Skip the candidate that
                // matches the currently-resolved provider/model so the retry
                // genuinely changes models (and, for reasoning-only free
                // models, gives a non-reasoning model a chance).
                $_tg_candidates = array();
                if ( class_exists( '\\SEO_Article_Generator\\AI\\AI_Client' )
                    && method_exists( '\\SEO_Article_Generator\\AI\\AI_Client', 'get_fallback_candidates' ) ) {
                    $_tg_candidates = (array) \SEO_Article_Generator\AI\AI_Client::get_fallback_candidates();
                }

                $_tg_current_provider = (string) ( $prompt_data['_resolved_provider'] ?? \get_option( 'seo_gen_api_provider', 'gemini' ) );
                $_tg_current_model    = (string) ( $prompt_data['_resolved_model'] ?? '' );

                foreach ( $_tg_candidates as $_tg_cand ) {
                    $_tg_cp = (string) ( $_tg_cand['provider'] ?? '' );
                    $_tg_cm = (string) ( $_tg_cand['model'] ?? '' );
                    if ( $_tg_cp === '' || $_tg_cm === '' ) {
                        continue;
                    }
                    if ( $_tg_cp === $_tg_current_provider && $_tg_cm === $_tg_current_model ) {
                        continue;
                    }
                    $_tg_retry_provider = $_tg_cp;
                    $_tg_retry_model    = $_tg_cm;
                    break;
                }

                if ( $_tg_retry_model !== '' ) {
                    $_tg_model_override = static function ( $current ) use ( &$_tg_retry_model ) {
                        return $_tg_retry_model;
                    };
                    \add_filter( 'seo_gen_use_model', $_tg_model_override, 20, 1 );
                    $prompt_data['_resolved_provider'] = $_tg_retry_provider;
                    $prompt_data['_resolved_model']    = $_tg_retry_model;

                    try {
                        $_tg_missing = $_tg_run_attempt();
                        $_tg_attempt = 2;
                    } catch ( \Throwable $_tg_retry_error ) {
                        // The retry itself errored (rate limit, timeout, 4xx).
                        // Restore the filter and rethrow — the normal API-error
                        // fallback/retry machinery owns error handling; the thin
                        // guard only governs 200-OK-but-incomplete responses.
                        \remove_filter( 'seo_gen_use_model', $_tg_model_override, 20 );
                        throw $_tg_retry_error;
                    }

                    \remove_filter( 'seo_gen_use_model', $_tg_model_override, 20 );

                    if ( empty( $_tg_missing ) ) {
                        $this->logger->info(
                            'THIN-OUTPUT GUARD: retry with a different model produced the missing sections; proceeding with retry output.',
                            array(
                                'retry_provider' => $_tg_retry_provider,
                                'retry_model'    => $_tg_retry_model,
                            )
                        );
                    } else {
                        $_tg_thin_sections = $_tg_missing;
                    }
                } else {
                    $this->logger->warning(
                        'THIN-OUTPUT GUARD: no alternate provider/model available for retry; evaluating first attempt as final.'
                    );
                }
            }

            if ( ! empty( $_tg_thin_sections ) ) {
                // Both attempts (or the single attempt when no alternate model
                // exists) left the full render without expected prose zones.
                // Park: throw a DETERMINISTIC failure. The job handler treats
                // this signature as terminal (no job-level retry) and the
                // discovery recovery registry classifies it as 'abort' (Failed
                // tab; rescan/auto-gen do not resurrect; the published post is
                // NOT modified — the exception fires before any PPB/Content_
                // Formatter write). Manual Retry/Run-now resets the breaker.
                $this->logger->error(
                    'THIN-OUTPUT GUARD: full-render update still missing expected prose sections after model retry; parking discovery (post left unchanged).',
                    array(
                        'software'         => (string) ( $input_data['software_name'] ?? '' ),
                        'existing_post_id' => (int) ( $input_data['existing_post_id'] ?? 0 ),
                        'attempts'         => $_tg_attempt,
                        'retry_provider'   => $_tg_retry_provider,
                        'retry_model'      => $_tg_retry_model,
                        'missing_sections' => $_tg_thin_sections,
                    )
                );

                throw new \SEO_Article_Generator\AI\DeterministicFailureException(
                    'full_render_ai_omitted_sections: AI omitted required prose sections on full self-heal render ('
                    . implode( ', ', $_tg_thin_sections )
                    . '). Post left unchanged; parked for manual review after model retry ('
                    . ( $_tg_retry_model !== '' ? ( $_tg_retry_provider . '/' . $_tg_retry_model ) : 'no alternate model available' )
                    . ').',
                    0,
                    array(
                        'missing_sections' => $_tg_thin_sections,
                        'attempts'         => $_tg_attempt,
                        'retry_provider'   => $_tg_retry_provider,
                        'retry_model'      => $_tg_retry_model,
                    )
                );
            }
        } else {
            // Scoped surgical update (or new post): run the identical block
            // once with no thin-output retry — historical behavior.
            $_tg_run_attempt();
        }

        unset( $_tg_run_attempt, $_tg_is_full_render, $_tg_is_update_post, $_tg_guard_enabled,
            $_tg_attempt, $_tg_thin_sections, $_tg_retry_model, $_tg_retry_provider,
            $_tg_candidates, $_tg_current_provider, $_tg_current_model, $_tg_cand, $_tg_cp, $_tg_cm,
            $_tg_model_override, $_tg_missing, $_tg_expected, $_tg_raw, $_tg_prose, $_tg_section, $_tg_retry_error );


        $requested_sections = array();

        if (!empty($normalized_regen_sections) && is_array($normalized_regen_sections)) {
            $requested_sections = array_values(array_filter(
                Article_Schema::normalize_sections($normalized_regen_sections, array()),
                static function ($section) {
                    return $section !== 'all' && $section !== 'toc';
                }
            ));
        }

        if (empty($requested_sections) && !empty($input_data['sections']) && is_array($input_data['sections'])) {
            $requested_sections = array_values(array_filter(
                Article_Schema::normalize_sections($input_data['sections'], array()),
                static function ($section) {
                    return $section !== 'all' && $section !== 'toc';
                }
            ));
        }

        if (empty($requested_sections) && !empty($input_data['section_selection']) && is_array($input_data['section_selection'])) {
            $requested_sections = array_values(array_filter(
                Article_Schema::normalize_sections($input_data['section_selection'], array()),
                static function ($section) {
                    return $section !== 'all' && $section !== 'toc';
                }
            ));
        }

$is_update = !empty($input_data['existing_post_id']) || !empty($input_data['is_update']);
$is_explicit_partial = !empty($requested_sections);

	// SSOT: Settings determine which sections are required for validation.
	// Never use hardcoded arrays — read from the same options that control
	// what the AI is asked to generate.
	if (empty($requested_sections)) {
		$defaults = \SEO_Article_Generator\Option_Registry::defaults();

		if ($is_update) {
			// Update posts: validate only sections toggled ON in AI Update Sections settings.
			$raw_sections = \get_option(
				\SEO_Article_Generator\Option_Registry::UPDATE_SECTIONS,
				false
			);
			if ($raw_sections === false || !is_array($raw_sections) || empty($raw_sections)) {
				$raw_sections = $defaults[\SEO_Article_Generator\Option_Registry::UPDATE_SECTIONS];
			}
		} else {
			// New posts: validate only sections toggled ON in Discovery Generation Sections settings.
			$raw_sections = \get_option(
				\SEO_Article_Generator\Option_Registry::DISCOVERY_SECTIONS,
				$defaults[\SEO_Article_Generator\Option_Registry::DISCOVERY_SECTIONS]
			);
			if (!is_array($raw_sections) || empty($raw_sections)) {
				$raw_sections = $defaults[\SEO_Article_Generator\Option_Registry::DISCOVERY_SECTIONS];
			}
		}

		$requested_sections = Article_Schema::normalize_sections($raw_sections, array());
		// Exclude 'all' and 'toc' — these are render directives, not content sections.
		$requested_sections = array_values(array_filter($requested_sections, static function ($s) {
			return $s !== 'all' && $s !== 'toc';
		}));
	}

	// @MODIFIED 2026-07-14: SIMPLE_UTILITY exemption is run AFTER both branches so
	// the gate honors the AI's classification regardless of whether $requested_sections
	// was inferred from settings (if) or carried in from partial regen (elseif).
	// Mirrors the MOAT skip pattern at L1176-1204 so FAQ/MOAT use the same SSOT.
	if (\SEO_Article_Generator\Generator\Article_Schema::is_simple_utility($schema->software_type)) {
		$before = $requested_sections;
		$requested_sections = array_values(array_diff($requested_sections, array('faqs', 'moat')));
		if ($before !== $requested_sections && $this->logger) {
			$this->logger->info('SIMPLE_UTILITY exemption: stripped faqs/moat from required sections.', array(
				'software'      => (string) ($input_data['software_name'] ?? ''),
				'software_type' => $schema->software_type,
				'stripped'      => array_values(array_diff($before, $requested_sections)),
			));
		}
		// Ensure Validator knows to skip faqs/moat for SIMPLE_UTILITY
		$excluded_sections = array_merge($excluded_sections, array('faqs', 'moat'));
		$excluded_sections = array_values(array_unique($excluded_sections));
	}

// @MODIFIED 2026-07-28: Partial-success gate. Only `download` and `hero`
// are mandatory/blocking — their failure aborts the article (deterministic
// retry). All other sections (tech_specs, whats_new, related_software,
// features, faqs, installation, moat, pros_cons, introduction, toc) are
// SOFT: if the AI omitted/produced a thin section, the article still
// proceeds with whatever sections ARE valid. Soft-fail sections are
// logged; no retry, no regen scheduling. Existing section content for
// soft-failed keys is preserved downstream by publish-payload-builder
// merge. whats_new_history is already guarded in discovery-processor
// (L4011-4013) so an empty/thin whats_new never pollutes history meta.
$mandatory_sections = array('download', 'hero');

$missing_mandatory_sections = array();
$missing_soft_sections     = array();

foreach ($requested_sections as $section) {
	$canonical = Article_Schema::get_canonical_key((string) $section) ?: (string) $section;
	if (!$this->section_passes_sanity_check($schema, $section)) {
		if (in_array($canonical, $mandatory_sections, true)) {
			$missing_mandatory_sections[] = $section;
		} else {
			$missing_soft_sections[] = $section;
		}
	}
}

$missing_mandatory_sections = array_values(array_unique($missing_mandatory_sections));
$missing_soft_sections     = array_values(array_unique($missing_soft_sections));

        if (!empty($missing_mandatory_sections)) {
            if ($this->logger) {
                $this->logger->error('Generated article failed MANDATORY section completeness gate.', array(
                    'missing_mandatory' => $missing_mandatory_sections,
                    'missing_soft'     => $missing_soft_sections,
                    'software_name'    => (string) ($input_data['software_name'] ?? ''),
                    'existing_post_id'  => (int) ($input_data['existing_post_id'] ?? 0),
                    'is_update'        => $is_update,
                    'explicit_partial' => $is_explicit_partial,
                    'regen_sections'   => $normalized_regen_sections,
                ));
            }

            throw new \RuntimeException(
                'Generated article missing required populated sections: ' . implode(', ', $missing_mandatory_sections)
            );
        }

        // SOFT-fail path: article proceeds with whatever sections passed.
        // Existing copy for soft-failed keys is preserved by the publish
        // payload builder's merge step (surgical patcher). No retry is
        // scheduled per product decision (2026-07-28): missing non-critical
        // sections are acceptable; only the validation result is logged.
        if (!empty($missing_soft_sections) && $this->logger) {
            $this->logger->warning('Generated article proceeding with missing SOFT (non-critical) sections.', array(
                'missing_soft_sections' => $missing_soft_sections,
                'software_name'         => (string) ($input_data['software_name'] ?? ''),
                'existing_post_id'       => (int) ($input_data['existing_post_id'] ?? 0),
                'is_update'              => $is_update,
                'explicit_partial'       => $is_explicit_partial,
                'regen_sections'         => $normalized_regen_sections,
                'note'                   => 'Existing content for these sections (if any) is preserved via publish-payload-builder merge. No retry scheduled.',
            ));
        }

        // @MODIFIED 2026-03-20: Professional Consistency Guard
        // Sync platform names between tech specs and the actually resolved download links.
        $schema->sync_platforms();

        // @MODIFIED 2025-12-08 v1.6.0: Populate hero data strictly from Schema DTOs (Single Source of Truth)
        // @MODIFIED 2025-12-15 v2.1.4: Now happens BEFORE to_html() so hero block is included
        // @MODIFIED 2025-12-19: Use Hero_Data_Provider to honor AI-suggested overrides in hero_section
        // @MODIFIED 2026-01-06: Pass existing post ID for featured image auto-fetch
        $existing_post_id = isset($input_data['existing_post_id']) ? (int) $input_data['existing_post_id'] : 0;
        
        // Prevent old hero meta from clobbering fresh schema data during updates
        $hero_overrides = is_array($schema->hero_section) ? $schema->hero_section : [];
        if ($existing_post_id > 0) {
            unset($hero_overrides['software_name'], $hero_overrides['version'], $hero_overrides['file_size'], $hero_overrides['download_links'], $hero_overrides['last_updated'], $hero_overrides['last_verified_date']);
        }
        
        $schema->hero_section = Hero_Data_Provider::from_schema($schema, $hero_overrides, $existing_post_id);

        // Convert to array for Content_Formatter (now includes populated hero_section and related_software)
        $article_array = $schema->to_array();
        $article_array = $this->normalize_required_containers($article_array);
        // @MODIFIED 2026-03-13: Pass post ID for renderer context (modified date tracking)
        $article_array['post_id'] = $existing_post_id;
        // @MODIFIED 2026-08-12: Pass regen_sections to Content_Formatter so Download_Renderer
        // can disable link continuity when download section is explicitly regenerated.
        $article_array['regen_sections'] = $normalized_regen_sections;

        // @MODIFIED 2026-03-04: Format Smart Title (Issue 6 & 9)
        // @MODIFIED 2026-03-09: Pass full $article_array for portable/platform detection
        if (!empty($article_array['title'])) {
            $tech_specs = isset($article_array['tech_specs']) ? $article_array['tech_specs'] : array();
            $article_array['title'] = $this->format_smart_title($article_array['title'], $tech_specs, $is_update, $article_array);
        }

        // Step 10: Format content
        // @MODIFIED 2025-12-30 v2.8.2: Generate heading map before formatting
        // Pass it to Formatter to ensure consistency and once-per-post generation
        // @MODIFIED 2026-04-05: [HEADING-MAP DRIFT FIX v2] Normalize keys to canonical form for reliable lookup
        $stored_heading_map = array();

        if ($existing_post_id > 0) {
            $raw_heading_map = get_post_meta($existing_post_id, 'seogenheadingmap', true);

            if (is_string($raw_heading_map) && $raw_heading_map !== '') {
                $maybe = maybe_unserialize($raw_heading_map);
                if (is_array($maybe)) {
                    $raw_heading_map = $maybe;
                }
            }

            if (is_array($raw_heading_map)) {
                foreach ($raw_heading_map as $map_key => $map_value) {
                    if (!is_string($map_key) || !is_string($map_value)) {
                        continue;
                    }

                    $map_key   = trim($map_key);
                    $map_value = trim($map_value);

                    if ($map_key === '' || $map_value === '') {
                        continue;
                    }

                    $canonical_key = \SEO_Article_Generator\Generator\Article_Schema::get_canonical_key($map_key);
                    if (!$canonical_key) {
                        continue;
                    }

                    $stored_heading_map[$canonical_key] = $map_value;
                }
            }
        }

        $heading_map = \SEO_Article_Generator\Generator\Phrase_Variator::generate_heading_map();

        if (is_array($heading_map)) {
            $normalized_heading_map = array();

            foreach ($heading_map as $map_key => $map_value) {
                if (!is_string($map_key) || !is_string($map_value)) {
                    continue;
                }

                $map_key   = trim($map_key);
                $map_value = trim($map_value);

                if ($map_key === '' || $map_value === '') {
                    continue;
                }

                $canonical_key = \SEO_Article_Generator\Generator\Article_Schema::get_canonical_key($map_key);
                if (!$canonical_key) {
                    continue;
                }

                $normalized_heading_map[$canonical_key] = $map_value;
            }

            $heading_map = $normalized_heading_map;
        } else {
            $heading_map = array();
        }

        if (!empty($stored_heading_map)) {
            $freeze_keys = array(
                'hero',
                'download',
            );

            foreach ($freeze_keys as $map_key) {
                if (!empty($stored_heading_map[$map_key])) {
                    $heading_map[$map_key] = $stored_heading_map[$map_key];
                }
            }
        }

        $article_array['_seo_gen_heading_map'] = $heading_map; // Persist for core save
        $article_array['seogenheadingmap'] = $heading_map; // Also store under canonical name for classifier

        // @MODIFIED 2026-03-12: Enter Deterministic Routing Pipeline
        // Replaces nested ifs with a clean, single-point-of-truth classification.
        $post_type = Post_Type_Classifier::classify($existing_post_id);
        
        switch ($post_type) {
            case Post_Type_Classifier::TYPE_PLUGIN:
                // DO NOT patch HTML here.
                // Only return generated article/DTO payload.
                $article_array['html_content'] = '';
                break;

            case Post_Type_Classifier::TYPE_PLUGIN_LEGACY:
                // FIX: Plugin-owned post with old CSS-class zone format.
                // Surgical_Patcher cannot patch it yet (no sentinels), but we must NOT
                // overwrite it with stripped fresh HTML either.
                // Set html_content = '' to signal PPB to handle migration + patching.
                // PPB will use Sentinel_Fallback_Utility to inject sentinels, then patch.
                // If migration fails in PPB, PPB will throw → job retries as full regen.
                if ($this->logger) {
                    $this->logger->info(
                        'PATH C: Plugin-owned old-format post. Delegating migration + patch to PPB.',
                        ['post_id' => $existing_post_id]
                    );
                }
                $article_array['html_content'] = '';
                break;

            case Post_Type_Classifier::TYPE_LEGACY:
                if ($this->logger) {
                    $this->logger->info(
                        'PATH B: True legacy post (not plugin-owned). Forcing full ownership rewrite.',
                        ['post_id' => $existing_post_id]
                    );
                }
                // Intentional drop-through to TYPE_NEW logic (Full Rewrite)
            case Post_Type_Classifier::TYPE_NEW:
            default:
                if ($post_type === Post_Type_Classifier::TYPE_NEW && $this->logger) {
                    $this->logger->info('PATH A: New post generation.');
                }

	// TOC render decision: Legacy full-rewrites (is_update=true, forced full rewrite) MUST get TOC.

	// Build comprehensive TOC selection source from multiple inputs
	$toc_raw_sources = array_merge(
		(array) ($input_data['regen_sections'] ?? array()),
		(array) ($input_data['sections'] ?? array()),
		(array) ($input_data['section_selection'] ?? array())
	);

	// Normalize the combined sections, allowing 'toc' and 'all' as valid values
	$normalized_toc_selection = Article_Schema::normalize_sections($toc_raw_sources, array('all', 'toc'));

	$is_toc_selected = empty($normalized_toc_selection)
		|| in_array('all', $normalized_toc_selection, true)
		|| in_array('toc', $normalized_toc_selection, true);

	$is_legacy_rewrite = $is_update && ($input_type === 'discovery');
	$should_add_toc = $is_toc_selected || $is_legacy_rewrite;

	if ($this->logger) {
		$this->logger->info('TOC render decision.', array(
			'input_type' => (string) $input_type,
			'post_type' => (string) $post_type,
			'is_legacy_rewrite' => (bool) $is_legacy_rewrite,
			'is_toc_selected' => (bool) $is_toc_selected,
			'should_add_toc' => (bool) $should_add_toc,
		));
	}

		$formatter = $this->build_content_formatter($heading_map, $should_add_toc);
		$article_array['html_content'] = $formatter->to_html($article_array, $existing_post_id);
		break;
        }

        if (
            $post_type !== Post_Type_Classifier::TYPE_PLUGIN &&
            ! empty( $article_array['html_content'] ) &&
            trim( (string) $article_array['html_content'] ) !== ''
        ) {
            // Already native blocks from Content_Formatter
        }

        // @MODIFIED 2025-12-04 v1.4.2: PHP-based keyword optimization (auto-update mode)
        $seo_input = array(
            'software_name' => $software_name,
            // @MODIFIED 2026-01-03 v2.13.0: Remove forced "download" suffix - use software name only
            'focus_keyword' => isset($prompt_data['focus_keyword']) ? $prompt_data['focus_keyword'] : $software_name,
        );
        $article_array = $this->optimize_seo($article_array, $seo_input);

        // Step 11: Validate article
        // @MODIFIED 2026-03-20: Re-inject manual input flags lost during DTO serialization
        if (!empty($manual_flags)) {
            $article_array['needs_manual_input'] = $manual_flags;
        }

        // Build minimal input_data for validator
        $validator_input = array(
            'software_name'     => $software_name,
            'category'          => $category,
            'excluded_sections' => $excluded_sections, // @since 2.13.1: Pass user-excluded sections
            'is_update'         => $is_update, // @MODIFIED 2026-03-20: Reflect actual pipeline state (true=update, false=new)
        );
        $validation_results = $this->validator->validate($article_array, $validator_input);

        if (!is_array($validation_results)) {
            $message = 'Validator returned invalid results (non-array).';
            if ($this->logger) {
                $this->logger->error($message, array('validation_type' => gettype($validation_results)));
            }
            throw new \RuntimeException($message);
        }

        // Ensure expected keys
        if (!array_key_exists('score', $validation_results)) {
            $validation_results['score'] = 0;
        }
        if (!array_key_exists('passed', $validation_results)) {
            $validation_results['passed'] = false;
        }

		// Step 11: Final Sanity Check before preparing output
		if (! $this->perform_final_sanity_check($article_array, $prompt_data, $excluded_sections)) {
			throw new DeterministicFailureException(
				'AI Output failed final sanity check: Essential factual data is missing or invalid.',
				0,
				array(
					'article'      => $article_array,
					'software_name' => $software_name
				)
			);
		}

		// Step 12: Prepare final output
		// @MODIFIED 2025-12-12 v1.8.1: Include failed_sections for admin notice
		$result = array(
			'article' => $article_array,
			'validation' => $validation_results,
			'internal_links' => $internal_links,
			'generated_at' => \SEO_Article_Generator\Utils\Plugin_Time::utc_mysql_now(),
			'mode' => 'auto',
			'failed_sections' => $failed_sections, // Partial regen failures for UI notice
			'hallucination_warnings' => $this->hallucination_warnings, // @MODIFIED 2026-03-20: Audit Fix #5
			'_debug' => $this->prune_debug_payload($this->strip_raw_tokens($debug_data)), // @MODIFIED: Pruned for database safety
		);

		if ($this->logger) {
			$this->logger->info('Article generation complete', array(
				'software' => $software_name,
				'score'    => $validation_results['score'],
				'passed'   => $validation_results['passed'],
				'errors'   => !empty($validation_results['errors']) ? $validation_results['errors'] : 'none',
				'warnings' => !empty($validation_results['warnings']) ? $validation_results['warnings'] : 'none',
			));
		}
		return $result;
	}

	private function normalize_regen_sections(array $sections): array
	{
		return Article_Schema::normalize_sections($sections, array('all', 'toc'));
	}

	private function strip_excluded_validation_fields(array $article_data, array $excluded_fields): array
	{
		foreach ($excluded_fields as $field_path) {
			Article_Schema::remove_field_path($article_data, $field_path);
		}

		return $article_data;
	}

	/**
	 * Perform a final sanity check on the generated article data.
	 *
	 * @param array $article_data      The generated article array.
	 * @param array $prompt_data       The input prompt data.
	 * @param array $excluded_sections Fields excluded from this generation pass.
	 * @return bool True if sanity check passes.
	 */
	private function perform_final_sanity_check(array $article_data, array $prompt_data, array $excluded_sections = array()): bool
	{
		$context = $prompt_data['_generation_context'] ?? null;
		$gen_type = $context instanceof \SEO_Article_Generator\Generator\Generation_Context ? $context->type : 'manual';
		$is_explicit_partial = ($gen_type === 'partial');

		// 1. Structural requirements.
		// 'title' and 'meta_description' are top-level fields outside the section schema.
		// strip_excluded_validation_fields() never touches them, so they are legitimately
		// absent in EXPLICIT partial-regen mode where the AI was instructed to skip them.
		// Enforce for new, upgrade (legacy rewrite), and update types.
		if (! $is_explicit_partial) {
			if (empty($article_data['title']) || empty($article_data['meta_description'])) {
				// Derive meta_description from introduction if missing
				if (empty($article_data['meta_description']) && ! empty($article_data['introduction'])) {
					$_intro_parts = is_array($article_data['introduction']) ? $article_data['introduction'] : array($article_data['introduction']);
					$_intro_text = trim(implode(' ', array_filter(array_map('wp_strip_all_tags', $_intro_parts))));
					if ($_intro_text !== '') {
						$_derived = mb_substr($_intro_text, 0, 158);
						$_last_space = mb_strrpos($_derived, ' ');
						if ($_last_space !== false && $_last_space > 80) {
							$_derived = mb_substr($_derived, 0, $_last_space);
						}
						$article_data['meta_description'] = class_exists('\\SEO_Article_Generator\\Generator\\Response_Normalizer')
							? \SEO_Article_Generator\Generator\Response_Normalizer::strip_markdown(trim($_derived))
							: trim($_derived);
					}
				}
				// Fallback 2: title + software_name + version
				if (empty($article_data['meta_description']) && (! empty($article_data['title']) || ! empty($article_data['tech_specs']['software_name']))) {
				$sw = $article_data['tech_specs']['software_name'] ?? $article_data['software_name'] ?? '';
				$article_data['meta_description'] = sprintf('Download %s', $sw);
				}
				if (empty($article_data['title']) || empty($article_data['meta_description'])) {
					return false;
				}
			}
		}

		// 2. Factual requirements (Software name matching)
        $expected_name = $prompt_data['software_name'] ?? '';
        $found_name     = (string) $this->array_path($article_data, array('tech_specs', 'software_name'), '');

		if (! empty($expected_name) && ! empty($found_name)) {
			// @MODIFIED 2026-03-25: Professional Lenient Matcher
			// Allows for variations like "Visual Studio" vs "Microsoft Visual Studio"
			// and handles version strings being appended to the name by the AI.
			if (! $this->is_software_name_match($found_name, $expected_name)) {
				if ($this->logger) {
					$this->logger->warning('Factual verification failed: Software name mismatch.', array(
						'expected' => $expected_name,
						'found'    => $found_name
					));
				}
				return false;
			}
		}

		// 3. Validation results
		// If the validator returned 'failed' or 'passed' is false, it's NOT necessarily a deterministic failure
		// unless it's a structural breach that shouldn't happen with the normalizer.
		// We'll trust the caller to handle validation score failures.

		return true;
	}

    /**
     * Check if a regenerated section has meaningful content.
     */
    private function section_passes_sanity_check(Article_Schema $schema, $section)
    {
        $section = Article_Schema::get_canonical_key((string) $section) ?: (string) $section;

        switch ($section) {
            case 'download':
                $download = $schema->get_section_payload('download');
                $links    = (is_array($download) && isset($download['links']) && is_array($download['links'])) ? $download['links'] : array();

                foreach ($links as $link) {
                    if (!is_array($link)) {
                        continue;
                    }
                    $url = isset($link['url']) ? (string) $link['url'] : '';
                    // FIX F13 (Phase 3A): a bare repo page is not download signal.
                    if ($url !== ''
                        && !\SEO_Article_Generator\Generator\Download_Link_Helper::is_placeholder_url($url)
                        && !\SEO_Article_Generator\Generator\Download_Link_Helper::is_repo_page_url($url)
                    ) {
                        return true;
                    }
                }
                return false;

            // @MODIFIED 2026-07-28: Explicit hero case. Previously `hero` fell
            // to the default branch which only checked array_has_meaningful_content
            // on the raw AI hero_section payload — too lax for a MANDATORY
            // section. Hero_Data_Provider::from_schema() (run downstream at
            // L~1872) populates the final hero from tech_specs.software_name
            // OR schema.title + download_section.links, so the gate must
            // mirror that contract: pass if EITHER raw hero_section carries
            // software_name OR (tech_specs.software_name / schema.title is
            // non-empty). Otherwise the provider would throw downstream,
            // which is a deterministic failure we want to surface cleanly
            // via the mandatory gate instead.
            case 'hero':
                $hero = $schema->get_section_payload('hero');
                $hero = is_array($hero) ? $hero : array();
                $hero_sw = trim((string) ($hero['software_name'] ?? ''));
                if ($hero_sw !== '') {
                    return true;
                }
                $tech_sw = is_object($schema->tech_specs) ? trim((string) ($schema->tech_specs->software_name ?? '')) : '';
                $title   = trim((string) ($schema->title ?? ''));
                return $tech_sw !== '' || $title !== '';

            case 'introduction':
                $intro = $schema->get_section_payload('introduction');
                $intro = is_array($intro) ? $intro : array($intro);
                // Phase 3F: also reject placeholder-stub intros (e.g. "Step 1: ...").
                foreach ($intro as $intro_piece) {
                    if (is_string($intro_piece) && self::is_placeholder_content($intro_piece)) {
                        return false;
                    }
                }
                return strlen(trim(implode(' ', array_filter($intro)))) > 20;

            case 'features':
                $features = $schema->get_section_payload('features');
                return is_array($features) && count($features) >= 2;

            case 'faqs':
                $faqs = $schema->get_section_payload('faqs');
                return is_array($faqs) && count($faqs) >= 2;

            case 'troubleshooting':
                $issues = $schema->get_section_payload('troubleshooting');
                return is_array($issues) && !empty($issues);

            case 'moat':
                $moat = $schema->get_section_payload('moat');

                if (is_string($moat)) {
                    return strlen(trim(wp_strip_all_tags($moat))) > 40;
                }

                if (!is_array($moat)) {
                    return false;
                }

                if (!empty($moat['body']) && is_string($moat['body'])) {
                    return strlen(trim(wp_strip_all_tags($moat['body']))) > 40;
                }

                $content = array();

	if (isset($moat['content']) && is_array($moat['content'])) {
		$content = $moat['content'];
	} elseif (isset($moat['steps']) && is_array($moat['steps'])) {
		$content = $moat['steps'];
	} elseif (isset($moat[0])) {
		$content = $moat;
	}

                foreach ($content as $entry) {
                    if (is_string($entry)) {
                        if (strlen(trim(wp_strip_all_tags($entry))) > 40) {
                            return true;
                        }
                        continue;
                    }

                    if (!is_array($entry)) {
                        continue;
                    }

                    $heading = trim((string) ($entry['heading'] ?? ''));
                    $body    = trim((string) ($entry['body'] ?? ''));
                    $recipe  = trim((string) ($entry['recipe'] ?? ''));
                    $why     = trim((string) ($entry['why'] ?? ''));

                    $substantive = $body !== '' ? $body : trim($recipe . ' ' . $why);

                    if ($heading !== '' && strlen(wp_strip_all_tags($substantive)) > 20) {
                        return true;
                    }

                    if ($heading === '' && strlen(wp_strip_all_tags($substantive)) > 40) {
                        return true;
                    }
                }

        return false;

		case 'competitors':
			$competitors = $schema->get_section_payload('competitors');
			if (!is_array($competitors) || empty($competitors)) {
				return false;
			}
			$valid_count = 0;
			foreach ($competitors as $competitor) {
				if (!is_array($competitor)) {
					continue;
				}
				$name = trim((string) ($competitor['name'] ?? ''));
				if ($name !== '' && $name !== 'N/A' && $name !== 'null') {
					$valid_count++;
				}
			}
			return $valid_count >= 2;

		default:
			$payload = $schema->get_section_payload($section);
			if (is_array($payload)) {
				return self::array_has_meaningful_content($payload);
			}
			if (is_string($payload)) {
				// Phase 3F: reject template stubs even when long enough by char count.
				return strlen(trim($payload)) >= 10 && ! self::is_placeholder_content($payload);
			}
			return $payload !== null && $payload !== '';
	}
}

	/**
	 * Recursively check if an array contains meaningful content
	 *
	 * @param array $array The array to check
	 * @return bool True if array contains meaningful content
	 */
	private static function array_has_meaningful_content(array $array): bool {
		if (empty($array)) {
			return false;
		}
		$has_content = false;
		foreach ($array as $value) {
			// PHASE 3F (2.34.0): a string only counts as meaningful if it is not
			// a template placeholder. The 09-06 log accepted a 59-byte payload of
			// "Step 1: ..."/"Step 2: ..." stubs (post 31804) because the old
			// strlen>=3 test passed on any non-empty token, then the normalizer
			// backfilled every other zone -> thin page that re-entered self-heal.
			if (is_string($value) && strlen(trim($value)) >= 3 && ! self::is_placeholder_content($value)) {
				$has_content = true;
				break;
			}
			if (is_array($value) && self::array_has_meaningful_content($value)) {
				$has_content = true;
				break;
			}
			if (is_numeric($value) && $value !== 0 && $value !== '') {
				$has_content = true;
				break;
			}
		}
		return $has_content;
	}

	/**
	 * Phase 3F (2.34.0): detect template-stub / placeholder text that the model
	 * emits instead of real content (e.g. "Step 1: ...", "TODO", "N/A", "lorem
	 * ipsum", "your text here"). Returns true when the string carries no real
	 * information and must NOT count as meaningful section content.
	 *
	 * @param string $text
	 * @return bool
	 */
	private static function is_placeholder_content($text): bool {
		if (! is_string($text)) {
			return false;
		}
		$t = trim(wp_strip_all_tags($text));
		if ($t === '') {
			return true;
		}
		$lower = function_exists('mb_strtolower') ? mb_strtolower($t) : strtolower($t);

		// Dots/ellipses-only or a label followed by only dots (e.g. "Step 1: ...").
		$stripped = preg_replace('/[\s.\…\-\_:;|]/u', '', $t);
		$bare_lower = preg_replace('/[\s.\…\-\_:;|0-9]/u', '', $lower);

		$literal_stubs = array(
			'lorem ipsum', 'todo', 'tbd', 'n/a', 'na', 'null', 'none',
			'placeholder', 'your text here', 'add content', 'sample text',
			'content here', 'example text', 'xxxxx', 'coming soon',
			'step here', 'write here', 'fill in',
		);
		foreach ($literal_stubs as $stub) {
			if (strpos($bare_lower, $stub) !== false) {
				return true;
			}
		}

		// "Step N" / "Part N" / "Section N" style enumerations whose only body is
		// dots/ellipses (the model's way of emitting an empty ordered list).
		if (preg_match('/^(step|part|section|phase|item|point|note)\s*\d+\b/iu', $t) && strlen((string) $stripped) <= 12) {
			return true;
		}

		// Nothing but repeated punctuation/ellipsis after removing alnum tokens.
		if ($stripped === '' || (strlen($stripped) <= 3 && ! preg_match('/[a-zA-Z]{3,}/', $t))) {
			return true;
		}

		return false;
	}

	/**
     * Format a smart, SEO-optimised title.
     *
     * @param string $title      AI-generated title to reform.
     * @param array  $tech_specs tech_specs array from the article schema.
     * @param bool   $is_update  True when updating an existing post.
     * @param array  $article_data Full article data (for download links + portable detection).
     * @return string Formatted title.
     */
    private function format_smart_title($title, $tech_specs, $is_update = false, $article_data = array())
    {
        if (empty($title)) {
            return $title;
        }

        // ============================================================
        // PATH A: UPDATE – Only swap the version/build string
        // ============================================================
        if ($is_update && !empty($tech_specs['existing_post_id'])) {
            $existing_post = \get_post($tech_specs['existing_post_id']);
            if ($existing_post && !empty($existing_post->post_title)) {
                $old_title   = $existing_post->post_title;
                $new_version = trim($tech_specs['version'] ?? '');

                // Append build number if present (e.g. "3.0.20 Build 14")
                $build = trim($tech_specs['build'] ?? '');
                if (!empty($build)) {
                    $build_label = (stripos($build, 'build') === false) ? ' Build ' : ' ';
                    $new_version .= $build_label . $build;
                }

                if (!empty($new_version)) {
                    // Audit Fix #4: Use TitleAnalyzer for accurate version segment identification
                    $titleAnalyzerFile = __DIR__ . '/../discovery/class-title-analyzer.php';

                    if (!class_exists(Title_Analyzer::class, false) && file_exists($titleAnalyzerFile)) {
                        require_once $titleAnalyzerFile;
                    }

                    if (class_exists(Title_Analyzer::class, false)) {
                        $analyzer = new Title_Analyzer();
                        $extracted = $analyzer->extract($old_title);

                        if ($extracted && !empty($extracted['version'])) {
                            $oldFragment = (string) $extracted['version'];

			if ($oldFragment !== $new_version) {
				$title_vr_pattern = '/\b' . preg_quote($oldFragment, '/') . '\b/i';
				return preg_replace($title_vr_pattern, $new_version, $old_title);
                            }
                        }
                    }

                    return $old_title;
                }
            }
        }

        // ============================================================
        // PATH B: NEW POST – Build the title intelligently
        // ============================================================
        
        // 1. Base Name: Prioritize tech_specs name, fallback to title
        $name = !empty($tech_specs['software_name']) ? $tech_specs['software_name'] : $title;
        $version_raw = trim($tech_specs['version'] ?? '');
        
        // Remove version from name if it exists there
        if ($version_raw !== '') {
            $name = str_ireplace($version_raw, '', $name);
        }

        // Strip dates, years, and common SEO suffixes that the AI might have included
        $name = preg_replace('/\s*\((?:(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+)?20\d{2}\)/i', '', $name);
        $name = preg_replace('/\s+20\d{2}$/', '', $name);

        // Strip keywords GLOBALLY from the name to avoid duplication since we re-inject them
        $name = preg_replace('/\b(?:Portable|Free|Download|Download\s+Free|Free\s+Download|for\s+(?:Windows|macOS|Mac|Linux|Android|iOS|iPhone|All\s+Platforms))\b/i', '', $name);

        // Clean up multiple spaces and trim
        $name = trim(preg_replace('/\s+/', ' ', $name));
        
        // Emergency Fallback: If name becomes empty (e.g. AI returned only keywords), use the original software_name or title
        if (empty($name)) {
            $tech_specs = is_array($tech_specs) ? $tech_specs : array();
            $name = !empty($tech_specs['software_name']) ? (string) $tech_specs['software_name'] : $title;
        }


        // 2. Format version + build
        $version = $version_raw;
        $build   = trim($tech_specs['build'] ?? '');
        if (!empty($build)) {
            $build_label = (stripos($build, 'build') === false) ? ' Build ' : ' ';
            $version .= $build_label . $build;
        }

        // 3. Determine platforms
        $os_support = isset($tech_specs['os_support']) && !is_array($tech_specs['os_support'])
            ? (string) $tech_specs['os_support']
            : 'Windows';

        $platforms_raw = array_map('trim', explode(',', $os_support));
        $normalized_platforms = array();
        foreach ($platforms_raw as $p) {
            if (stripos($p, 'Windows') !== false) $normalized_platforms[] = 'Windows';
            elseif (stripos($p, 'macOS') !== false || stripos($p, 'Mac') !== false) $normalized_platforms[] = 'macOS';
            elseif (stripos($p, 'Linux') !== false) $normalized_platforms[] = 'Linux';
            elseif (stripos($p, 'Android') !== false) $normalized_platforms[] = 'Android';
            elseif (stripos($p, 'iOS') !== false || stripos($p, 'iPhone') !== false) $normalized_platforms[] = 'iOS';
        }
        $normalized_platforms = array_unique($normalized_platforms);
        
        $threshold = (int) \get_option('seo_gen_platform_threshold', 3);
        $platform_str = 'Windows';

        if (count($normalized_platforms) > $threshold) {
            $platform_str = 'All Platforms';
        } elseif (count($normalized_platforms) > 0) {
            if (count($normalized_platforms) === 1) {
                $platform_str = reset($normalized_platforms);
            } else {
                $last = array_pop($normalized_platforms);
                $platform_str = implode(', ', $normalized_platforms) . ' & ' . $last;
            }
        }

        // 4. Handle Portable
        $is_portable = false;
        if (stripos($name, 'portable') !== false) {
            $is_portable = true;
        } else {
        $download_links = $this->array_path((array) $article_data, array('download_section', 'links'), array());
        $download_links = is_array($download_links) ? $download_links : array();
            foreach ($download_links as $link) {
                if (!is_array($link)) {
                    continue;
                }
                $link_text = strtolower($link['text'] ?? ($link['label'] ?? ($link['title'] ?? '')));
                $link_url  = strtolower($link['url'] ?? '');
                if (stripos($link_text, 'portable') !== false || stripos($link_url, 'portable') !== false) {
                    $is_portable = true;
                    break;
                }
            }
        }

        // 5. Select Style (Random rotation from the allowed options)
        $raw_setting = \get_option('seo_gen_title_style', array('1', '2', '3'));

        if (\is_string($raw_setting) && $raw_setting !== '') {
            $raw_setting = array($raw_setting);
        } elseif (! \is_array($raw_setting)) {
            $raw_setting = array('1', '2', '3');
        }

        $style_aliases = array(
            '1'      => '1',
            '2'      => '2',
            '3'      => '3',
            'style1' => '1',
            'style2' => '2',
            'style3' => '3',
        );

        $style_pool = array();
        foreach ($raw_setting as $raw_style) {
            $raw_style = \sanitize_text_field((string) $raw_style);
            if (isset($style_aliases[$raw_style])) {
                $style_pool[] = $style_aliases[$raw_style];
            }
        }

        $style_pool = array_values(array_unique($style_pool));
        if (empty($style_pool)) {
            $style_pool = array('1', '2', '3');
        }

        $selected_style = $style_pool[array_rand($style_pool)];

        $title_styles = array(
            '1' => '{name} {version} Free Download for {platforms}',
            '2' => '{name} {version} Download Free for {platforms}',
            '3' => '{name} {version} Download for {platforms}',
        );

        $template = isset($title_styles[$selected_style]) ? $title_styles[$selected_style] : $title_styles['1'];

        // Adjust for portable
        if ($is_portable) {
            $template = str_replace(
                array('Free Download', 'Download Free', 'Download'),
                array('Portable Free Download', 'Portable Download Free', 'Portable Download'),
                $template
            );
        }

        // 6. Final Assembly
        $final_title = str_replace(
            array('{name}', '{version}', '{platforms}'),
            array($name, $version, $platform_str),
            $template
        );

        return $final_title;
    }

    /**
     * Normalize AI response through Response_Normalizer.
     *
     * @param array              $article_data Raw AI data.
     * @param Generation_Context $context      Generation context.
     * @return array Normalized data.
     */
    private function normalize_ai_response(array $article_data, Generation_Context $context)
    {
        return Response_Normalizer::normalize($article_data, $context);
    }

    /**
     * Deterministic Video Block contract.
     *
     * @MODIFIED 2026-08-24: Source-post videos were silently discarded because
     * the AI context is built with wp_strip_all_tags() (video URLs live in
     * attributes, so the AI never sees them) and the oEmbed gate strips AI
     * guesses. This resolves video_url from structured ground truth instead:
     *   1. Update: existing post already has a video -> keep it, never add another.
     *   2. Source post carries a video -> adopt it (ground truth from the source).
     *   3. Fall back to the AI-returned (oEmbed-verified) video_url, else empty.
     * Content_Formatter::format_video_embed() renders the block when non-empty,
     * so no renderer changes are required.
     *
     * @param array $article_data Canonical article contract.
     * @param array $input_data   Raw generation input (source_video_url, existing_article_html).
     * @return array Article contract with resolved video_url.
     */
    private function apply_video_block_contract(array $article_data, array $input_data): array
    {
        $cleaner_class    = '\SEO_Article_Generator\Integration\Content_Cleaner';
        $cleaner_present  = class_exists($cleaner_class) && method_exists($cleaner_class, 'extract_video_url');
        $existing_post_id = isset($input_data['existing_post_id']) ? (int) $input_data['existing_post_id'] : 0;

        $ai_video = isset($article_data['video_url']) && is_string($article_data['video_url'])
            ? trim($article_data['video_url'])
            : '';

        // 1) Existing-post video wins on update. Never layer a new video over one
        //    the live post already has.
        if ($existing_post_id > 0 && $cleaner_present) {
            $existing_html = isset($input_data['existing_article_html']) && is_string($input_data['existing_article_html'])
                ? $input_data['existing_article_html']
                : (string) \get_post_field('post_content', $existing_post_id, 'raw');

            if (trim($existing_html) !== '') {
                $existing_video = $cleaner_class::extract_video_url($existing_html);
                if ($existing_video !== '') {
                    if ($this->logger) {
                        $this->logger->info(
                            sprintf(
                                'Video contract: existing post %d already has a video (%s) — keeping it, no new video added.',
                                $existing_post_id,
                                $existing_video
                            )
                        );
                    }
                    $article_data['video_url'] = $existing_video;
                    return $article_data;
                }
            }
        }

        // 2) Adopt the source-post video — it is the ground truth for this article.
        $source_video = isset($input_data['source_video_url']) && is_string($input_data['source_video_url'])
            ? trim($input_data['source_video_url'])
            : '';

        if ($source_video === '' && $cleaner_present && !empty($input_data['article_context'])) {
            // Fallback for manual/legacy inputs: article_context is tag-stripped,
            // so only bare video URLs can still be found here.
            $source_video = $cleaner_class::extract_video_url((string) $input_data['article_context']);
        }

        if ($source_video !== '') {
            if ($this->logger) {
                $this->logger->info(
                    sprintf(
                        'Video contract: adopting source-post video %s for post %d (AI value %s).',
                        $source_video,
                        $existing_post_id,
                        $ai_video !== '' ? $ai_video : 'was empty'
                    )
                );
            }
            $article_data['video_url'] = $source_video;
            return $article_data;
        }

        // 3) No existing, no source video — keep whatever the AI survived with.
        $article_data['video_url'] = $ai_video;
        return $article_data;
    }

    /**
     * Verify changelog data via ChangelogVerifier.
     *
     * @param array $article_data Article data.
     * @return array Verification results.
     */
    private function verify_changelog_data($article_data)
    {
        return ChangelogVerifier::verify($article_data);
    }

    /**
     * Load existing schema snapshot from post meta.
     *
     * @param int $post_id Post ID.
     * @return Article_Schema|null
     */
    private function load_base_schema_snapshot($post_id)
    {
        if (!$post_id) {
            return null;
        }

		// @MODIFIED 2026-03-25: Use Schema_Sync_Service for canonical accuracy
		// Previously used _seo_gen_hero_data which is an incomplete presentation cache.
		return Schema_Sync_Service::load_schema($post_id);
    }

    /**
     * Parse manual download links from textarea input.
     *
     * @param string $input    Raw textarea input.
     * @param array  $platforms List of detected platforms.
     * @return array Parsed links.
     */
    private function parse_manual_download_links($input, $platforms = array())
    {
        $lines = explode("\n", str_replace("\r", "", $input));
        $links = array();

        foreach ($lines as $line) {
            $line = trim($line);
            if (empty($line)) {
                continue;
            }

            // Simple URL detection
            if (filter_var($line, FILTER_VALIDATE_URL)) {
                // Reject bare repo/project pages (e.g. github.com/owner/repo).
                // A download URL must point to a binary file, a release asset,
                // or an admin-allowlisted host. Mirrors the contract used in
                // Link_Resolver::resolve_from_html().
                if (!\SEO_Article_Generator\Generator\Download_Link_Helper::is_binary_link_url($line)) {
                    if (defined('SEO_GEN_DEBUG_LINKS') && SEO_GEN_DEBUG_LINKS) {
                        error_log('[ArticleGenerator] parse_manual_download_links REJECTED: url=' . $line . ' | reason=not_binary_link');
                    }
                    continue;
                }
                $links[] = array(
                    'url'      => $line,
                    'platform' => \SEO_Article_Generator\Generator\Download_Link_Helper::infer_platform_from_url($line) ?: 'Other',
                    'variant'  => 'Standard',
                );
            }
        }

        return $links;
    }

    /**
     * Build Content_Formatter instance.
     *
     * @param array $heading_map   Heading map.
     * @param bool  $should_add_toc Whether to add TOC.
     * @return Content_Formatter
     */
    private function build_content_formatter($heading_map, $should_add_toc = false)
    {
        return new Content_Formatter($heading_map, $should_add_toc);
    }

    /**
     * Optimize SEO keywords in content.
     *
     * @param array $article_array Article data.
     * @param array $seo_input    SEO input (software name, keyword).
     * @return array Optimized data.
     */
    private function optimize_seo($article_array, $seo_input)
    {
        // This is a placeholder for the actual SEO optimization logic
        // For now, we return the article as is or with basic keyword anchoring.
        return $article_array;
    }

    /**
     * Prune debug payload for storage safety.
     *
     * @param array $debug_data Debug data.
     * @return array Pruned data.
     */
    private function prune_debug_payload($debug_data)
    {
		if (!is_array($debug_data)) {
			return array();
		}

		$safe = $debug_data;

		// Preserve raw_prompt and raw_response for debug panel (Raw Request/Raw Response buttons)
		// Strip only sensitive/auth data and verbose fields
		unset($safe['messages'], $safe['system_prompt'], $safe['full_response_body']);

		if (!empty($safe['search_trace']['sample']) && is_array($safe['search_trace']['sample'])) {
			$safe['search_trace']['sample'] = array_slice($safe['search_trace']['sample'], 0, 3);
		}

		if (!empty($safe['http_trace']['response_head'])) {
			$safe['http_trace']['response_head'] = substr((string) $safe['http_trace']['response_head'], 0, 500);
		}

		return $safe;
    }

    /**
     * Strip raw tokens from debug data.
     *
     * @param array $debug_data Debug data.
     * @return array Cleaned data.
     */
    private function strip_raw_tokens($debug_data)
    {
        if (!is_array($debug_data)) {
            return array();
        }

        // Generic token stripping logic if needed
        return $debug_data;
    }
    /**
     * Legacy proxy for Surgical_Patcher::patch
     * @since 2.16.0 (Legacy Support)
     */
    public static function patch($content, $article_data, $regen_sections = array())
    {
        return Surgical_Patcher::patch($content, $article_data, $regen_sections);
    }

    /**
     * Safely read a nested array path without ever throwing offset/type errors.
     *
     * @param array $source
     * @param array $path
     * @param mixed $default
     * @return mixed
     */
    private function array_path(array $source, array $path, $default = null)
    {
        $value = $source;
        foreach ($path as $segment) {
            if (!is_array($value) || !array_key_exists($segment, $value)) {
                return $default;
            }
            $value = $value[$segment];
        }
        return $value;
    }

    /**
     * Force critical top-level and nested containers into predictable array shapes.
     *
     * @param array $article_data
     * @return array
     */
    private function normalize_required_containers(array $article_data): array
    {
        $array_sections = array(
            'tech_specs',
            'download_section',
            'hero_section',
            'pros_cons',
            'moat_data',
            'related_software',
            'needs_manual_input',
            'features',
            'faqs',
            'whats_new',
            'installation_guide',
            'safety',
            'competitors',
        );

        foreach ($array_sections as $key) {
            if (!isset($article_data[$key]) || !is_array($article_data[$key])) {
                $article_data[$key] = array();
            }
        }

        if (!isset($article_data['download_section']['links']) || !is_array($article_data['download_section']['links'])) {
            $article_data['download_section']['links'] = array();
        }

        if (!isset($article_data['installation_guide']['steps']) || !is_array($article_data['installation_guide']['steps'])) {
            $article_data['installation_guide']['steps'] = array();
        }

        if (!isset($article_data['installation_guide']['common_issues']) || !is_array($article_data['installation_guide']['common_issues'])) {
            $article_data['installation_guide']['common_issues'] = array();
        }

        if (!isset($article_data['pros_cons']['pros']) || !is_array($article_data['pros_cons']['pros'])) {
            $article_data['pros_cons']['pros'] = array();
        }

        if (!isset($article_data['pros_cons']['cons']) || !is_array($article_data['pros_cons']['cons'])) {
            $article_data['pros_cons']['cons'] = array();
        }

        return $article_data;
    }

    /**
     * Canonicalize AI output through Article_Schema and immediately normalize
     * high-risk containers so later code never touches scalar section shapes.
     *
     * @param array $article_data
     * @return array
     */
    private function canonicalize_article_payload(array $article_data): array
    {
        try {
            $article_data = Article_Schema::from_ai_array($article_data)->to_array();
        } catch (\Throwable $e) {
            $message = 'AI client returned invalid schema: ' . $e->getMessage();
            if ($this->logger) {
                $this->logger->error($message, array('error' => $e->getMessage()));
            }
            throw new \RuntimeException($message, 0, $e);
        }

        return $this->normalize_required_containers($article_data);
    }

    /**
     * Legacy proxy for Post_Type_Classifier::classify
     * @since 2.16.0 (Legacy Support)
     */
    public static function is_plugin_controlled_post($post_id)
    {
        return Post_Type_Classifier::classify($post_id) === Post_Type_Classifier::TYPE_PLUGIN;
    }

	/**
	 * Lenient software name matching logic.
	 * Returns true if the names are "mostly" the same (substring or high word overlap).
	 */
    private function is_software_name_match(string $found, string $expected): bool
    {
        $normalize_name = static function (string $s): string {
            $s = strtolower($s);
            $s = preg_replace('/[^a-z0-9\s]/', ' ', $s);
            $s = preg_replace('/\s+/', ' ', $s);
            return trim($s);
        };

        $found_norm = $normalize_name($found);
        $expected_norm = $normalize_name($expected);

        if ($found_norm === $expected_norm) {
            return true;
        }

        if (stripos($found_norm, $expected_norm) !== false || stripos($expected_norm, $found_norm) !== false) {
            return true;
        }

        $found_words = array_filter(explode(' ', $found_norm));
        $expected_words = array_filter(explode(' ', $expected_norm));

        $intersect = array_intersect($found_words, $expected_words);
        $min_count = min(count($found_words), count($expected_words));

        if ($min_count > 1 && (count($intersect) / $min_count) >= 0.6) {
            return true;
        }

        return false;
    }
}
