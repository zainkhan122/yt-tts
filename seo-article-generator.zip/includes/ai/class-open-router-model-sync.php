<?php

namespace SEO_Article_Generator\AI;

use SEO_Article_Generator\Logger;
use SEO_Article_Generator\Option_Registry;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * OpenRouter Free Model Auto-Sync
 *
 * Pulls free, text-only content-creation models from the OpenRouter API and
 * merges them into the site's OpenRouter-compatible custom provider profile.
 *
 * Design rules enforced here:
 *  - Order preservation: existing model order is NEVER changed. New free
 *    models are appended strictly AFTER existing ones.
 *  - Filtering pipeline: pricing === 0, text-only OUTPUT modality, modality
 *    string fallback, and blocked provider prefixes (audio/image/video).
 *  - Multiple INPUT modalities including text are allowed AS LONG AS the only
 *    OUTPUT modality is text (e.g. vision+text input, text output = allowed).
 *  - Expiration: models whose expiration_date falls within SYNC_WINDOW_DAYS
 *    are removed.
 *  - Misconfigured pruning: models flagged via
 *    AI_Client::mark_provider_misconfigured() (per-model transient set on a
 *    live 404/"Invalid model configured" response from the gateway) are removed
 *    even if they remain listed in OpenRouter's catalog. This catches slugs
 *    OpenRouter keeps published but gates behind the paid tier.
 *  - Failure safety: any API/parse failure aborts WITHOUT touching the
 *    stored model list (no silent wipe).
 *
 * @since 2.30.x
 */
class OpenRouter_Model_Sync {

	const API_URL          = 'https://openrouter.ai/api/v1/models';
	const SYNC_WINDOW_DAYS = 3;

	/**
	 * Models NOT for text content creation (audio/image/video generation).
	 * Matching is prefix-based against the model id.
	 *
	 * @var string[]
	 */
	private static $BLOCKED_MODEL_PREFIXES = array(
		'google/lyria',
		'google/imagen',
		'openai/dall-e',
		'openai/gpt-image',
		'openai/sora',
		'stabilityai/stable-diffusion',
		'stabilityai/stable-video',
		'midjourney',
		'black-forest-labs/flux',
		'tencent/hunyuan-video',
		'kgm/ace-step',
	);

	/**
	 * Modalities that indicate NON-text output and therefore disqualify a model
	 * when present in the OUTput modality list.
	 *
	 * @var string[]
	 */
	private static $NON_TEXT_OUTPUT_MODALITIES = array(
		'audio',
		'image',
		'video',
		'embeddings',
	);

	/**
	 * Model id substrings that indicate non-generation utility models
	 * (content safety, embeddings, rerankers, classifiers, guard models).
	 * These accept prompts but return structured safety/embedding output —
	 * they are structurally incapable of producing article JSON.
	 *
	 * @since 2.34.12
	 * @var string[]
	 */
	private static $BLOCKED_PURPOSE_PATTERNS = array(
		'-content-safety',
		'-embed',
		'-embedding',
		'-reranker',
		'-classifier',
		'-guard',
		'-moderation',
		'-reward',
		'-judge',
	);

	/**
	 * Run the sync.
	 *
	 * @return array{ success: bool, message: string, added: int, removed: int, total: int }
	 */
	public static function sync(): array {
		$registry = Provider_Registry::get_instance();
		$providers = $registry->get_custom_providers();

		$or_index = self::find_openrouter_index( $providers );
		if ( $or_index < 0 ) {
			return self::result( false, 'No OpenRouter custom provider found.' );
		}

		// Provider slug for this OpenRouter-compatible profile — needed to read
		// per-model misconfigured transients set by AI_Client::mark_provider_misconfigured().
		$provider_slug = (string) ( $providers[ $or_index ]['id'] ?? '' );

		$api_models = self::fetch_free_models();
		if ( null === $api_models ) {
			return self::result( false, 'OpenRouter API request failed; existing models left unchanged.' );
		}
		if ( empty( $api_models ) ) {
			return self::result( false, 'OpenRouter API returned no models; existing models left unchanged.' );
		}

		$current_models = $providers[ $or_index ]['models'] ?? array();
		$current_ids    = array();
		foreach ( $current_models as $m ) {
			if ( ! empty( $m['model_id'] ) ) {
				$current_ids[] = $m['model_id'];
			}
		}

		$api_ids = array();
		foreach ( $api_models as $m ) {
			$api_ids[] = $m['model_id'];
		}

		$expiration_cutoff = time() + ( self::SYNC_WINDOW_DAYS * DAY_IN_SECONDS );

		// Step 6: Detect removals (current vs API + expiration + misconfigured flag).
		// Three removal triggers run in order; only one needs to fire:
		//   a) model is no longer present in OpenRouter's free catalog
		//   b) model is expiring within SYNC_WINDOW_DAYS
		//   c) AI_Client::mark_provider_misconfigured() has set a per-model transient
		//      for this provider+model — proof that a recent live 404 ("model
		//      unavailable for free"/"Invalid model configured") has occurred. This
		//      catches slugs OpenRouter keeps in its catalog but gates behind the
		//      paid tier (e.g. openai/gpt-oss-120b:free), so they cannot sneak back
		//      into the fallback chain on the next sync after a transient expires.
		$removed_ids = array();
		$misconfigured_lookup_helper = null;
		if ( $provider_slug !== '' && class_exists( '\SEO_Article_Generator\AI\AI_Client' )
			&& method_exists( '\SEO_Article_Generator\AI\AI_Client', 'is_provider_misconfigured' ) ) {
			$misconfigured_lookup_helper = array( '\SEO_Article_Generator\AI\AI_Client', 'is_provider_misconfigured' );
		}
		foreach ( $current_models as $m ) {
			$id = $m['model_id'] ?? '';
			if ( '' === $id ) {
				continue;
			}
			if ( ! in_array( $id, $api_ids, true ) ) {
				$removed_ids[ $id ] = true;
				continue;
			}
			if ( self::is_expiring( $m, $expiration_cutoff ) ) {
				$removed_ids[ $id ] = true;
				continue;
			}
			// Per-model misconfigured transient set when the gateway observed a
			// 404/"model unavailable for free"/"Invalid model configured" response
			// for this provider+model pair. See class-ai-client.php ~line 1914.
			if ( null !== $misconfigured_lookup_helper
				&& (bool) call_user_func( $misconfigured_lookup_helper, $provider_slug, $id ) ) {
				$removed_ids[ $id ] = true;
			}
		}

		// Step 7: Detect additions (API vs current, excluding removed).
		$added = array();
		foreach ( $api_models as $m ) {
			$id = $m['model_id'] ?? '';
			if ( '' === $id ) {
				continue;
			}
			if ( in_array( $id, $current_ids, true ) ) {
				continue;
			}
			if ( isset( $removed_ids[ $id ] ) ) {
				continue;
			}
			$added[] = $m;
		}

		if ( empty( $added ) && empty( $removed_ids ) ) {
			self::update_last_sync();

			return self::result(
				true,
				'No changes: OpenRouter model list already in sync.',
				0,
				0,
				count( $current_models )
			);
		}

		// Step 9: Rebuild preserving order, then append new models AFTER.
		$new_models = array();
		foreach ( $current_models as $m ) {
			$id = $m['model_id'] ?? '';
			if ( '' !== $id && isset( $removed_ids[ $id ] ) ) {
				continue;
			}
			$new_models[] = $m;
		}
		foreach ( $added as $m ) {
			$new_models[] = $m;
		}

		// Step 10: Never save a blank provider.
		if ( empty( $new_models ) ) {
			return self::result(
				false,
				'Sync would remove all models; aborting to preserve existing provider.'
			);
		}

		// Step 11: Direct, order-preserving save (bypass generic re-savers).
		$providers[ $or_index ]['models'] = $new_models;
		$registry->save_custom_providers( $providers );

		self::update_last_sync();

		$logger = self::logger();
		if ( $logger ) {
			$logger->info(
				sprintf(
					'[OpenRouter Sync] Added %d, removed %d, total %d models.',
					count( $added ),
					count( $removed_ids ),
					count( $new_models )
				),
				array(
					'action'  => Option_Registry::LOG_ACTION_OPENROUTER_SYNC,
					'added'   => wp_list_pluck( $added, 'model_id' ),
					'removed' => array_keys( $removed_ids ),
				)
			);
		}

		$message = sprintf(
			'Sync complete: %d new model(s) added, %d removed. %d total.',
			count( $added ),
			count( $removed_ids ),
			count( $new_models )
		);

		return self::result( true, $message, count( $added ), count( $removed_ids ), count( $new_models ) );
	}

	/**
	 * Fetch and filter free text-only models from the API.
	 *
	 * @return array<int,array{model_id:string,display_name:string,expiration_date?:string}>|null
	 *         Null on transport/parse failure.
	 */
	private static function fetch_free_models(): ?array {
		$url = add_query_arg(
			array(
				'max_price' => '0',
			),
			self::API_URL
		);

		$response = wp_remote_get(
			$url,
			array(
				'timeout'     => 30,
				'headers'     => array( 'Accept' => 'application/json' ),
				'user-agent'  => 'SEO-Article-Generator/' . ( defined( 'SEO_GEN_VERSION' ) ? SEO_GEN_VERSION : '1.0' ),
			)
		);

		if ( is_wp_error( $response ) ) {
			$logger = self::logger();
			if ( $logger ) {
				$logger->warning( 'OpenRouter sync fetch failed: ' . $response->get_error_message() );
			}
			return null;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		if ( $code < 200 || $code >= 300 ) {
			$logger = self::logger();
			if ( $logger ) {
				$logger->warning( 'OpenRouter sync fetch HTTP error: ' . $code );
			}
			return null;
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );
		if ( ! is_array( $data ) || ! isset( $data['data'] ) || ! is_array( $data['data'] ) ) {
			$logger = self::logger();
			if ( $logger ) {
				$logger->warning( 'OpenRouter sync: malformed API response.' );
			}
			return null;
		}

		$filtered = array();
		foreach ( $data['data'] as $model ) {
			$entry = self::filter_model( $model );
			if ( null !== $entry ) {
				$filtered[] = $entry;
			}
		}

		return $filtered;
	}

	/**
	 * Apply the full filtering pipeline to a single API model record.
	 *
	 * Pipeline order:
	 *   1. Blocked prefix (audio/image/video generators)
	 *   2. Pricing === 0 (prompt AND completion)
	 *   3. Output modality filter (text-only output required)
	 *   4. Modality string fallback filter
	 *
	 * @param array $model Raw model record from the API.
	 * @return array{model_id:string,display_name:string,expiration_date?:string}|null
	 */
	private static function filter_model( array $model ): ?array {
		$model_id = isset( $model['id'] ) ? (string) $model['id'] : '';
		if ( '' === $model_id ) {
			return null;
		}

		// --- 1. Blocked prefix filter ---
		foreach ( self::$BLOCKED_MODEL_PREFIXES as $prefix ) {
			if ( strncmp( $model_id, $prefix, strlen( $prefix ) ) === 0 ) {
				return null;
			}
		}

		// --- 1b. Blocked purpose-pattern filter (safety/embed/reranker/guard) ---
		// These models accept prompts but return structured safety/embedding output;
		// they cannot produce article JSON. @since 2.34.12
		$model_id_lower = strtolower( $model_id );
		foreach ( self::$BLOCKED_PURPOSE_PATTERNS as $pattern ) {
			if ( strpos( $model_id_lower, $pattern ) !== false ) {
				return null;
			}
		}

		// --- 2. Pricing filter (must be free: prompt + completion === "0") ---
		$pricing = $model['pricing'] ?? array();
		$prompt = isset( $pricing['prompt'] ) ? (string) $pricing['prompt'] : null;
		$completion = isset( $pricing['completion'] ) ? (string) $pricing['completion'] : null;
		if ( null === $prompt || null === $completion ) {
			return null;
		}
		$is_free = ( '0' === $prompt || '0.0' === $prompt || 0.0 == $prompt )
			&& ( '0' === $completion || '0.0' === $completion || 0.0 == $completion );
		if ( ! $is_free ) {
			return null;
		}

		// --- 3. Output modality filter (text-only output required) ---
		$architecture = $model['architecture'] ?? array();
		$output_modalities = $architecture['output_modalities'] ?? null;

		$output_ok = false;
		if ( is_array( $output_modalities ) && ! empty( $output_modalities ) ) {
			$output_ok = self::is_text_only_output( $output_modalities );
		} elseif ( isset( $architecture['modality'] ) ) {
			// --- 4. Modality string fallback filter ---
			$output_ok = self::is_text_modality_string( (string) $architecture['modality'] );
		} else {
			// No architecture field: include (safe default — cannot prove it is
			// non-text output). Keeps parity with plan edge-case handling.
			$output_ok = true;
		}

		if ( ! $output_ok ) {
			return null;
		}

		$entry = array(
			'model_id'     => $model_id,
			'display_name' => isset( $model['name'] ) && '' !== (string) $model['name']
				? (string) $model['name']
				: $model_id,
		);

		if ( ! empty( $model['expiration_date'] ) ) {
			$entry['expiration_date'] = (string) $model['expiration_date'];
		}

		return $entry;
	}

	/**
	 * Determine whether an output modality list is text-only.
	 *
	 * A model with multiple INPUT modalities (e.g. image+text input) and a
	 * single text OUTPUT is allowed. We ONLY inspect the output list here.
	 *
	 * @param string[] $modalities
	 * @return bool
	 */
	private static function is_text_only_output( array $modalities ): bool {
		foreach ( $modalities as $mod ) {
			$mod = strtolower( trim( (string) $mod ) );
			if ( '' === $mod ) {
				continue;
			}
			if ( 'text' !== $mod ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Fallback check when only a modality STRING (not array) is present.
	 * Allows strings that include "text" and do NOT name any non-text output.
	 *
	 * @param string $modality
	 * @return bool
	 */
	private static function is_text_modality_string( string $modality ): bool {
		$lower = strtolower( $modality );
		if ( false === strpos( $lower, 'text' ) ) {
			return false;
		}
		foreach ( self::$NON_TEXT_OUTPUT_MODALITIES as $bad ) {
			if ( false !== strpos( $lower, $bad ) ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Is the given stored model expiring within the sync window?
	 *
	 * @param array $model Stored model (may carry 'expiration_date').
	 * @param int   $cutoff Unix timestamp cutoff.
	 * @return bool
	 */
	private static function is_expiring( array $model, int $cutoff ): bool {
		$exp = $model['expiration_date'] ?? null;
		if ( empty( $exp ) ) {
			return false;
		}
		$ts = strtotime( (string) $exp );
		if ( false === $ts || $ts <= 0 ) {
			return false;
		}
		return $ts < $cutoff;
	}

	/**
	 * Locate the first OpenRouter-compatible custom provider index.
	 *
	 * @param array $providers
	 * @return int Negative when none found.
	 */
	private static function find_openrouter_index( array $providers ): int {
		$registry = Provider_Registry::get_instance();
		foreach ( $providers as $i => $profile ) {
			$url = (string) ( $profile['api_url'] ?? '' );
			if ( $registry->is_openrouter_compatible( $url ) ) {
				return (int) $i;
			}
		}
		return -1;
	}

	/**
	 * Whether an OpenRouter-compatible provider exists.
	 *
	 * @return bool
	 */
	public static function has_openrouter_provider(): bool {
		return self::find_openrouter_index( Provider_Registry::get_instance()->get_custom_providers() ) >= 0;
	}

	/**
	 * Get the last successful sync timestamp.
	 *
	 * @return int Unix timestamp (0 = never).
	 */
	public static function get_last_sync_time(): int {
		return (int) get_option( Option_Registry::OPENROUTER_LAST_SYNC, 0 );
	}

	/**
	 * Update the last-sync timestamp.
	 */
	private static function update_last_sync(): void {
		update_option( Option_Registry::OPENROUTER_LAST_SYNC, time(), false );
	}

	/**
	 * Build a standardized result array.
	 *
	 * @param bool   $success
	 * @param string $message
	 * @param int    $added
	 * @param int    $removed
	 * @param int    $total
	 * @return array{success:bool,message:string,added:int,removed:int,total:int}
	 */
	private static function result( bool $success, string $message, int $added = 0, int $removed = 0, int $total = 0 ): array {
		return array(
			'success' => $success,
			'message' => $message,
			'added'   => $added,
			'removed' => $removed,
			'total'   => $total,
		);
	}

	/**
	 * Best-effort logger resolution.
	 *
	 * @return Logger|null
	 */
	private static function logger(): ?Logger {
		if ( class_exists( '\SEO_Article_Generator\Logger' ) ) {
			return new Logger();
		}
		return null;
	}
}
