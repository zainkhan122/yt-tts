<?php

namespace DIT\TrendStudio\Core;

$base_dir = defined('DIT_TS_PLUGIN_DIR') ? DIT_TS_PLUGIN_DIR : dirname(__DIR__, 2) . '/';

$compat_map = array(
    'DIT\\TrendStudio\\Installer' => array('file' => $base_dir . 'src/Core/Bootstrap.php', 'class' => 'DIT\\TrendStudio\\Core\\Bootstrap'),
    'DIT\\TrendStudio\\Jobs\\Job_Handler' => array('file' => $base_dir . 'src/Infrastructure/Scheduler.php', 'class' => 'DIT\\TrendStudio\\Infrastructure\\Scheduler'),
    'DIT\\TrendStudio\\Admin\\Admin_Menu' => array('file' => $base_dir . 'src/Admin/SettingsPage.php', 'class' => 'DIT\\TrendStudio\\Admin\\SettingsPage'),
    'DIT\\TrendStudio\\Admin\\Briefing_Room' => array('file' => $base_dir . 'src/Admin/JobMonitor.php', 'class' => 'DIT\\TrendStudio\\Admin\\JobMonitor'),
    'DIT\\TrendStudio\\Logger' => array('file' => $base_dir . 'src/Infrastructure/Logger.php', 'class' => 'DIT\\TrendStudio\\Infrastructure\\Logger'),
);

foreach ($compat_map as $alias => $info) {
    $source_file = $info['file'];
    $source_class = $info['class'];
    
    if (file_exists($source_file) && !class_exists($alias, false)) {
        require_once $source_file;
        if (class_exists($source_class, false)) {
            class_alias($source_class, $alias);
        }
    }
}
