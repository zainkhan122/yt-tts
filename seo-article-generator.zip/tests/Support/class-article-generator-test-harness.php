<?php

namespace SEO_Article_Generator\Tests\Support;

/**
 * Article Generator Test Harness
 * 
 * Provides a version of Article_Generator with test seams exposed.
 * Used by the Content Pipeline smoke test.
 */
class Article_Generator_Test_Harness extends \SEO_Article_Generator\Generator\Article_Generator
{
    private $forced_changelog_result = array('ok' => true, 'url' => 'https://example.org/changelog');
    private $forced_base_schema = null;

    public function set_forced_changelog_result(array $result)
    {
        $this->forced_changelog_result = $result;
    }

    public function set_forced_base_schema($schema)
    {
        $this->forced_base_schema = $schema;
    }

    protected function verify_changelog_data($article_data)
    {
        return $this->forced_changelog_result;
    }

    protected function load_base_schema_snapshot($post_id)
    {
        return $this->forced_base_schema;
    }
}
