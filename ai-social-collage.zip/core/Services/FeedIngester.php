<?php
namespace AiSocialCollage\Services;

	use AiSocialCollage\Config;
	use AiSocialCollage\Logger;
	use AiSocialCollage\Services\SocialMediaDownloader;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class FeedIngester {

	public static function ingest_feed( array $feed_config ) {
		if ( empty( $feed_config['url'] ) ) {
			return [];
		}

		$feed = fetch_feed( $feed_config['url'] );

		if ( is_wp_error( $feed ) ) {
			Logger::error( 'rss_fetch_failed', null, [
				'url' => $feed_config['url'],
				'error' => $feed->get_error_message(),
			], '500' );
			return [];
		}

		if ( $feed->get_item_quantity() === 0 ) {
			Logger::warning( 'rss_feed_empty', null, [ 'url' => $feed_config['url'] ], '200' );
			return [];
		}

		$max_items = (int) ( $feed_config['max_items'] ?? Config::RSS_DEFAULT_MAX_PER_RUN );
		$items = $feed->get_items( 0, $max_items );
		$ingested = [];

		foreach ( $items as $item ) {
			$result = self::ingest_item( $item, $feed_config );
			if ( $result ) {
				$ingested[] = $result;
			}
		}

		Logger::info( Config::LOG_ACTION_RSS_FEED_POLLED, null, [
			'url' => $feed_config['url'],
			'name' => $feed_config['name'] ?? '',
			'items_found' => count( $items ),
			'items_ingested' => count( $ingested ),
		], '200' );

		return $ingested;
	}

	private static function ingest_item( $item, array $feed_config ) {
		$source_url = esc_url_raw( $item->get_permalink() ?: '' );

		if ( empty( $source_url ) ) {
			return null;
		}

		if ( self::is_already_ingested( $source_url ) ) {
			return null;
		}

		// Check if this is a social media URL
		$platform_type = self::detect_platform_from_url( $source_url );
		if ( $platform_type ) {
			return self::ingest_social_media_item( $item, $feed_config, $source_url, $platform_type );
		}

		$raw_title = $item->get_title() ?: '';
		$raw_content = $item->get_content() ?: '';
		$raw_description = $item->get_description() ?: '';
		$image_url = self::extract_image( $item );
		$source_name = $feed_config['name'] ?? parse_url( $feed_config['url'], PHP_URL_HOST ) ?: 'RSS';
		$language = $feed_config['language'] ?? 'en';

		$clean_title = self::sanitize_feed_text( $raw_title, true );
		$clean_content = self::sanitize_feed_content( $raw_content, $raw_description );

		if ( empty( $clean_title ) ) {
			Logger::warning( 'rss_item_no_title', null, [
				'source_url' => $source_url,
				'raw_title' => mb_substr( $raw_title, 0, 100 ),
			], '200' );
			return null;
		}

		if ( empty( $clean_content ) ) {
			Logger::warning( 'rss_item_no_content', null, [
				'source_url' => $source_url,
				'title' => mb_substr( $clean_title, 0, 100 ),
				'raw_content_len' => strlen( $raw_content ),
				'raw_desc_len' => strlen( $raw_description ),
			], '200' );
			return null;
		}

		$prefilter_result = self::prefilter_check( $clean_title, $clean_content, $feed_config );
		if ( ! $prefilter_result['pass'] ) {
			Logger::info( Config::LOG_ACTION_PREFILTER_BLOCKED, null, [
				'source_url' => $source_url,
				'title' => mb_substr( $clean_title, 0, 80 ),
				'reason' => $prefilter_result['reason'],
				'score' => $prefilter_result['score'],
			], '200' );
			return null;
		}

		$post_data = [
			'post_title' => $clean_title,
			'post_content' => '',
			'post_status' => 'draft',
			'post_type' => 'post',
		];

		if ( ! empty( $feed_config['category'] ) ) {
			$cat_id = self::resolve_category( $feed_config['category'] );
			if ( $cat_id > 0 ) {
				$post_data['post_category'] = [ $cat_id ];
			}
		}

		$post_id = wp_insert_post( $post_data );

		if ( is_wp_error( $post_id ) ) {
			Logger::error( 'rss_insert_failed', null, [
				'title' => mb_substr( $clean_title, 0, 100 ),
				'error' => $post_id->get_error_message(),
			], '500' );
			return null;
		}

		update_post_meta( $post_id, Config::META_RSS_CONTENT, $clean_content );
		update_post_meta( $post_id, Config::META_RSS_SOURCE_URL, $source_url );
		update_post_meta( $post_id, Config::META_RSS_SOURCE_NAME, sanitize_text_field( $source_name ) );

		if ( ! empty( $image_url ) ) {
			$attachment_id = self::sideload_featured_image( $image_url, $post_id );
			if ( $attachment_id > 0 ) {
				update_post_meta( $post_id, Config::META_RSS_SOURCE_IMAGE, esc_url_raw( $image_url ) );
			}
		}

		if ( ! empty( $feed_config['campaign_id'] ) ) {
			$campaigns = Config::get_option_array( Config::OPTION_CAMPAIGNS, [] );
			foreach ( $campaigns as $campaign ) {
				if ( ( $campaign['id'] ?? '' ) === $feed_config['campaign_id'] ) {
					update_post_meta( $post_id, Config::META_CAMPAIGN_DATA, $campaign );
					break;
				}
			}
		}

		Logger::info( Config::LOG_ACTION_RSS_ITEM_INGESTED, null, [
			'post_id' => $post_id,
			'source_url' => $source_url,
			'source_name' => $source_name,
			'title' => mb_substr( $clean_title, 0, 80 ),
		], '200' );

		self::enqueue_feed_post( $post_id, $feed_config );

		return [
			'post_id' => $post_id,
			'title' => $clean_title,
			'source_url' => $source_url,
			'source_name' => $source_name,
		];
	}

	private static function enqueue_feed_post( $post_id, array $feed_config ) {
		if ( \AiSocialCollage\Database\JobManager::job_exists_for_post( $post_id, true ) ) {
			return;
		}

		$pipeline_paused = (bool) get_option( Config::OPTION_PIPELINE_PAUSED, false );
		if ( $pipeline_paused ) {
			Logger::warning( 'feed_post_skipped_pipeline_paused', null, [ 'post_id' => $post_id ], '200' );
			return;
		}

		$campaign = null;
		if ( ! empty( $feed_config['campaign_id'] ) ) {
			$campaigns = Config::get_option_array( Config::OPTION_CAMPAIGNS, [] );
			foreach ( $campaigns as $c ) {
				if ( ( $c['id'] ?? '' ) === $feed_config['campaign_id'] ) {
					$campaign = $c;
					break;
				}
			}
		} else {
			$campaign = self::find_matching_campaign( $post_id );
		}

		if ( ! $campaign ) {
			Logger::info( 'feed_post_no_campaign_match', null, [ 'post_id' => $post_id ], '200', 'No active campaign matches this post; skipping.' );
			return;
		}

		$job_id = \AiSocialCollage\Database\JobManager::create_job( $post_id );
		if ( ! $job_id ) {
			Logger::error( 'feed_job_create_failed', null, [ 'post_id' => $post_id ], '500' );
			return;
		}

		update_post_meta( $post_id, Config::META_CAMPAIGN_DATA, $campaign );

		if ( function_exists( 'as_schedule_single_action' ) ) {
			$action_id = as_schedule_single_action(
				time(),
				Config::ACTION_PROCESS_JOB,
				[ 'job_id' => $job_id ],
				Config::AS_GROUP
			);
			if ( $action_id ) {
				Logger::info( 'feed_job_enqueued', $job_id, [ 'post_id' => $post_id, 'campaign_id' => $campaign['id'] ], '200' );
				\AiSocialCollage\Actions\CronScheduler::update_campaign_last_run( $campaign['id'] );
			} else {
				Logger::error( 'feed_job_as_enqueue_failed', $job_id, [ 'post_id' => $post_id ], '500', 'Action Scheduler returned 0; job created but not scheduled.' );
			}
		} else {
			Logger::warning( 'feed_job_no_as', $job_id, [ 'post_id' => $post_id ], '200', 'Action Scheduler not available.' );
		}
	}

	private static function find_matching_campaign( $post_id ) {
		$categories = get_the_category( $post_id );
		if ( is_wp_error( $categories ) || empty( $categories ) ) {
			return null;
		}

		$campaigns = Config::get_option_array( Config::OPTION_CAMPAIGNS, [] );
		if ( empty( $campaigns ) ) {
			return null;
		}

		$post_slugs = array_map( function( $cat ) {
			return $cat->slug;
		}, $categories );

		foreach ( $campaigns as $campaign ) {
			if ( empty( $campaign['active'] ) ) {
				continue;
			}
			$source_slug = sanitize_title( $campaign['source_category'] ?? '' );
			if ( ! empty( $source_slug ) && in_array( $source_slug, $post_slugs, true ) ) {
				return $campaign;
			}
		}

		return null;
	}

	private static function is_already_ingested( $source_url ) {
		global $wpdb;
		$count = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value = %s LIMIT 1",
			Config::META_RSS_SOURCE_URL,
			$source_url
		) );
		return $count > 0;
	}

	public static function sanitize_feed_text( $text, $is_title = false ) {
		if ( empty( $text ) ) {
			return '';
		}

		$text = html_entity_decode( $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		$text = wp_strip_all_tags( $text );
		$text = preg_replace( '/\s+/', ' ', $text );

		if ( $is_title ) {
			$text = wp_check_invalid_utf8( $text );
			$text = sanitize_text_field( $text );
		} else {
			$text = wp_check_invalid_utf8( $text );
			$text = sanitize_textarea_field( $text );
		}

		return trim( $text );
	}

	public static function sanitize_feed_content( $content, $description = '' ) {
		$source = ! empty( $content ) ? $content : $description;

		if ( empty( $source ) ) {
			return '';
		}

		$source = html_entity_decode( $source, ENT_QUOTES | ENT_HTML5, 'UTF-8' );

		libxml_use_internal_errors( true );
		$dom = new \DOMDocument();
		$utf8_source = PHP_VERSION_ID >= 80200
			? mb_encode_numericentity( $source, [ 0x80, 0x10FFFF, 0, 0xFFFFF ], 'UTF-8' )
			: mb_convert_encoding( $source, 'HTML-ENTITIES', 'UTF-8' );
		$loaded = @$dom->loadHTML( '<div>' . $utf8_source . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD );

		if ( ! $loaded ) {
			libxml_clear_errors();
			return self::sanitize_feed_text( $source );
		}

		$remove_tags = [ 'script', 'style', 'nav', 'footer', 'aside', 'iframe', 'header', 'form', 'button', 'input', 'select', 'noscript', 'svg', 'figure', 'figcaption', 'address', 'map', 'area' ];
		foreach ( $remove_tags as $tag ) {
			$elements = $dom->getElementsByTagName( $tag );
			for ( $i = $elements->length - 1; $i >= 0; $i-- ) {
				$node = $elements->item( $i );
				if ( $node && $node->parentNode ) {
					$node->parentNode->removeChild( $node );
				}
			}
		}

		$xpath = new \DOMXPath( $dom );
		$remove_attrs = [ 'onclick', 'onload', 'onerror', 'onmouseover', 'onmouseout', 'onfocus', 'onblur', 'target', 'rel' ];
		foreach ( $xpath->query( '//*[@*]' ) as $node ) {
			foreach ( $remove_attrs as $attr ) {
				if ( $node->hasAttribute( $attr ) ) {
					$node->removeAttribute( $attr );
				}
			}
		}

		foreach ( $xpath->query( '//a' ) as $link ) {
			$href = $link->getAttribute( 'href' );
			$text = $link->textContent;
			if ( $link->parentNode ) {
				$text_node = $dom->createTextNode( $text );
				$link->parentNode->replaceChild( $text_node, $link );
			}
		}

		foreach ( $xpath->query( '//img' ) as $img ) {
			if ( $img->parentNode ) {
				$img->parentNode->removeChild( $img );
			}
		}

		$allowed_tags = '<p><br><strong><em><b><i><ul><ol><li><h1><h2><h3><h4><blockquote><span><div>';
		$cleaned = strip_tags( $dom->saveHTML(), $allowed_tags );

		libxml_clear_errors();

		$cleaned = wp_kses_post( wp_unslash( $cleaned ) );

		$cleaned = self::remove_source_links( $cleaned );
		$cleaned = self::remove_boilerplate( $cleaned );

		if ( empty( trim( $cleaned ) ) ) {
			$plain_text = trim( $dom->textContent );
			if ( ! empty( $plain_text ) ) {
				$cleaned = self::sanitize_feed_text( $plain_text, false );
			}
		}

		$cleaned = preg_replace( '/<div[^>]*>|<\/div>/', '', $cleaned );
		$cleaned = preg_replace( '/<(p|div|span)>[\s]*<\/\1>/', '', $cleaned );
		$cleaned = preg_replace( '/(<br\s*\/?>\s*){3,}/', '<br><br>', $cleaned );
		$cleaned = preg_replace( '/\n{3,}/', "\n\n", $cleaned );

		return trim( $cleaned );
	}

	private static function remove_source_links( $content ) {
		$patterns = [
			'/Read more.*?(?:<|$)/i',
			'/Continue reading.*?(?:<|$)/i',
			'/Read the full article.*?(?:<|$)/i',
			'/Source:.*?(?:<|$)/i',
			'/Via:.*?(?:<|$)/i',
			'/Originally published at.*?(?:<|$)/i',
			'/This article.*?originally appeared.*?(?:<|$)/i',
			'/—\s*Read more.*?(?:<|$)/i',
			'/The post\s+.*?\s+appeared first on.*?(?:<|$)/i',
			'/View the original article.*?(?:<|$)/i',
			'/Click here to read.*?(?:<|$)/i',
			'/For more.*?visit.*?(?:<|$)/i',
			'/Follow us on.*?(?:<|$)/i',
			'/Subscribe to.*?(?:<|$)/i',
			'/Download our app.*?(?:<|$)/i',
		];

		foreach ( $patterns as $pattern ) {
			$content = preg_replace( $pattern, '', $content );
		}

		$content = preg_replace( '/https?:\/\/[^\s<]+/i', '', $content );

		return $content;
	}

	private static function remove_boilerplate( $content ) {
		$patterns = [
			'/Sign up for.*?newsletter.*?(?:<|$)/i',
			'/Get the.*?newsletter.*?(?:<|$)/i',
			'/Copyright\s*\d{4}.*?(?:<|$)/i',
			'/All rights reserved\.?/i',
			'/Disclaimer:.*?(?:<|$)/i',
			'/Disclaimer\..*?(?:<|$)/i',
			'/Editor\'s note:.*?(?:<|$)/i',
			'/This content is.*?by.*?(?:<|$)/i',
		];

		foreach ( $patterns as $pattern ) {
			$content = preg_replace( $pattern, '', $content );
		}

		return $content;
	}

	private static function detect_platform_from_url( $url ) {
		$patterns = [
			'/instagram\.com\/p\//' => Config::SOURCE_TYPE_INSTAGRAM,
			'/facebook\.com\/.*\/posts\//' => Config::SOURCE_TYPE_FACEBOOK,
			'/twitter\.com\/.*\/status\//' => Config::SOURCE_TYPE_TWITTER,
			'/tiktok\.com\/@.*\/video\//' => Config::SOURCE_TYPE_TIKTOK,
			'/youtube\.com\/watch\//' => Config::SOURCE_TYPE_YOUTUBE,
			'/linkedin\.com\/.*\/posts\//' => Config::SOURCE_TYPE_LINKEDIN,
		];
		
		foreach ( $patterns as $pattern => $type ) {
			if ( preg_match( $pattern, $url ) ) {
				return $type;
			}
		}
		
		return false;
	}

	private static function ingest_social_media_item( $item, array $feed_config, $source_url, $platform_type ) {
		// Try to download media from social media URL
		try {
			$media_data = self::download_social_media_media( $source_url, $platform_type );
			if ( ! $media_data ) {
				return null;
			}
			
			// Extract metadata using existing methods
			$raw_title = $item->get_title() ?: '';
			$raw_content = $item->get_content() ?: '';
			$raw_description = $item->get_description() ?: '';
			$source_name = $feed_config['name'] ?? parse_url( $feed_config['url'], PHP_URL_HOST ) ?: 'Social Media';
			$language = $feed_config['language'] ?? 'en';
			
			// Clean and validate content
			$clean_title = self::sanitize_feed_text( $raw_title, true );
			$clean_content = self::sanitize_feed_content( $raw_content, $raw_description );
			
			if ( empty( $clean_title ) ) {
				Logger::warning( 'social_media_item_no_title', null, [
					'source_url' => $source_url,
					'platform' => $platform_type,
				], '200' );
				return null;
			}
			
			if ( empty( $clean_content ) ) {
				Logger::warning( 'social_media_item_no_content', null, [
					'source_url' => $source_url,
					'platform' => $platform_type,
					'raw_content_len' => strlen( $raw_content ),
					'raw_desc_len' => strlen( $raw_description ),
				], '200' );
				return null;
			}
			
			// Create post with social media metadata
			$post_data = [
				'post_title' => $clean_title,
				'post_content' => '',
				'post_status' => 'draft',
				'post_type' => 'post',
			];
			
			$post_id = wp_insert_post( $post_data );
			
			if ( is_wp_error( $post_id ) ) {
				Logger::error( 'social_media_insert_failed', null, [
					'title' => mb_substr( $clean_title, 0, 100 ),
					'error' => $post_id->get_error_message(),
				], '500' );
				return null;
			}
			
			// Store social media specific metadata
			update_post_meta( $post_id, Config::META_RSS_CONTENT, $clean_content );
			update_post_meta( $post_id, Config::META_RSS_SOURCE_URL, $source_url );
			update_post_meta( $post_id, Config::META_RSS_SOURCE_NAME, sanitize_text_field( $source_name ) );
			update_post_meta( $post_id, '_ai_collage_platform_type', $platform_type );
			update_post_meta( $post_id, '_ai_collage_original_author', $media_data['author'] ?? '' );
			update_post_meta( $post_id, '_ai_collage_original_caption', $media_data['caption'] ?? '' );
			update_post_meta( $post_id, '_ai_collage_original_hashtags', $media_data['hashtags'] ?? '' );
			update_post_meta( $post_id, '_ai_collage_processing_mode', 'rewrite' );
			
			// Handle downloaded media
			if ( ! empty( $media_data['file_path'] ) ) {
				$file_path = $media_data['file_path'];
				$is_video = SocialMediaDownloader::is_video_file( $file_path );
				$attachment_id = 0;

				if ( $is_video ) {
					// Source video from social media — do NOT mark as AI collage
					$attachment_id = self::sideload_source_video( $file_path, $post_id, $source_url );
					// For videos, we don't set as post thumbnail (should be an image)
					// Don't set META_IS_AI_COLLAGE — this is the raw source video
				} else {
					// Image — use existing logic
					$attachment_id = self::sideload_featured_image( $file_path, $post_id );
					if ( $attachment_id > 0 ) {
						set_post_thumbnail( $post_id, $attachment_id );
					}
				}

				if ( $attachment_id > 0 ) {
					update_post_meta( $post_id, '_ai_collage_branding_removed', $media_data['branding_removed'] ?? 0 );
					update_post_meta( $post_id, '_ai_collage_ocr_text', $media_data['ocr_text'] ?? '' );
				}
			}
			
			Logger::info( Config::LOG_ACTION_RSS_ITEM_INGESTED, null, [
				'post_id' => $post_id,
				'source_url' => $source_url,
				'source_name' => $source_name,
				'platform' => $platform_type,
				'title' => mb_substr( $clean_title, 0, 80 ),
			], '200' );
			
			self::enqueue_feed_post( $post_id, $feed_config );
			
			return [
				'post_id' => $post_id,
				'title' => $clean_title,
				'source_url' => $source_url,
				'source_name' => $source_name,
				'platform' => $platform_type,
			];
			
		} catch ( \Exception $e ) {
			Logger::error( 'social_media_download_failed', null, [
				'source_url' => $source_url,
				'platform' => $platform_type,
				'error' => $e->getMessage(),
			], '500' );
			return null;
		}
	}

	private static function download_social_media_media( $url, $platform_type ) {
		try {
			$downloader = new SocialMediaDownloader();
			return $downloader->download_media( $url, $platform_type );
		} catch ( \Exception $e ) {
			Logger::error( 'social_media_download_failed_downloader', null, [
				'url' => $url,
				'platform' => $platform_type,
				'error' => $e->getMessage(),
			], '500' );
			return null;
		}
	}



	private static function extract_image( $item ) {
		$enclosure = $item->get_enclosure();
		if ( $enclosure ) {
			$link = $enclosure->get_link();
			$type = $enclosure->get_type();
			if ( ! empty( $link ) && $type && strpos( $type, 'image/' ) === 0 ) {
				return self::sanitize_url_preserve_utf8( is_string( $link ) ? $link : '' );
			}
		}

		$thumbnail = $item->get_thumbnail();
		if ( $thumbnail && is_string( $thumbnail ) ) {
			return self::sanitize_url_preserve_utf8( $thumbnail );
		}

		$content = $item->get_content() ?: '';
		if ( preg_match( '/<img[^>]+src=["\']([^"\']+)["\']/i', $content, $m ) ) {
			return self::sanitize_url_preserve_utf8( $m[1] );
		}

		return '';
	}

	/**
	 * Sanitize a URL for HTTP fetching while preserving UTF-8 characters in the path.
	 * Unlike esc_url_raw(), this does NOT strip non-ASCII characters needed for
	 * internationalized filenames (Urdu, Arabic, Chinese, etc.).
	 */
	private static function sanitize_url_preserve_utf8( $url ) {
		$url = trim( $url );
		if ( $url === '' ) {
			return '';
		}
		$parsed = wp_parse_url( $url );
		if ( ! $parsed || empty( $parsed['scheme'] ) || empty( $parsed['host'] ) ) {
			return '';
		}
		$scheme = strtolower( $parsed['scheme'] );
		if ( ! in_array( $scheme, [ 'http', 'https' ], true ) ) {
			return '';
		}
		$path = $parsed['path'] ?? '';
		if ( $path !== '' ) {
			$path = rawurlencode( rawurldecode( $path ) );
			$path = str_replace( '%2F', '/', $path );
			$path = str_replace( '%20', '+', $path );
		}
		$query = isset( $parsed['query'] ) ? '?' . $parsed['query'] : '';
		$fragment = isset( $parsed['fragment'] ) ? '#' . $parsed['fragment'] : '';
		return $scheme . '://' . $parsed['host'] . $path . $query . $fragment;
	}

	private static function resolve_category( $category_identifier ) {
		if ( is_numeric( $category_identifier ) ) {
			return (int) $category_identifier;
		}

		$term = get_term_by( 'slug', sanitize_title( $category_identifier ), 'category' );
		if ( $term ) {
			return (int) $term->term_id;
		}

		$term = get_term_by( 'name', $category_identifier, 'category' );
		if ( $term ) {
			return (int) $term->term_id;
		}

		return 0;
	}

	private static function sideload_featured_image( $image_url, $post_id ) {
		if ( ! function_exists( 'media_handle_sideload' ) ) {
			require_once ABSPATH . 'wp-admin/includes/media.php';
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/image.php';
		}

		// Check if image is already on this server (same domain).
		$home_url = parse_url( home_url(), PHP_URL_HOST );
		$img_host = parse_url( $image_url, PHP_URL_HOST );
		$is_local = ( $home_url && $img_host && $home_url === $img_host );

		if ( $is_local ) {
			// Local image — convert URL to filesystem path, no download needed.
			$url_path = parse_url( $image_url, PHP_URL_PATH );
			// Decode percent-encoded characters (e.g. %D9%85 → م) for real filesystem path.
			$url_path_decoded = rawurldecode( $url_path );
			$ABSPATH_trimmed = rtrim( ABSPATH, '/' );
			$local_file = $ABSPATH_trimmed . $url_path_decoded;

			if ( file_exists( $local_file ) && is_readable( $local_file ) ) {
				$ext = pathinfo( $local_file, PATHINFO_EXTENSION );
				if ( empty( $ext ) || ! in_array( strtolower( $ext ), [ 'jpg', 'jpeg', 'png', 'gif', 'webp' ], true ) ) {
					$ext = 'jpg';
				}
				$tmp = tempnam( sys_get_temp_dir(), 'rss_' );
				if ( $ext !== pathinfo( $tmp, PATHINFO_EXTENSION ) ) {
					rename( $tmp, $tmp . '.' . $ext );
					$tmp = $tmp . '.' . $ext;
				}
				copy( $local_file, $tmp );

				$file_array = [
					'name' => 'rss_' . uniqid() . '.' . $ext,
					'tmp_name' => $tmp,
				];

				$attachment_id = media_handle_sideload( $file_array, $post_id );

				if ( is_wp_error( $attachment_id ) ) {
					@unlink( $tmp );
					Logger::error( 'rss_image_sideload_failed', $post_id, [
						'image_url' => $image_url,
						'local_file' => $local_file,
						'error' => $attachment_id->get_error_message(),
					], '500' );
					return 0;
				}

				update_post_meta( $attachment_id, Config::META_IS_AI_COLLAGE, '1' );
				set_post_thumbnail( $post_id, $attachment_id );
				return $attachment_id;
			}

			Logger::warning( 'rss_local_image_not_found', $post_id, [
				'image_url' => $image_url,
				'expected_path' => $local_file,
			], '404' );
			return 0;
		}

		// Remote image — download then sideload.
		$tmp = download_url( $image_url, 30 );

		if ( is_wp_error( $tmp ) ) {
			Logger::error( 'rss_image_download_failed', $post_id, [
				'image_url' => $image_url,
				'error' => $tmp->get_error_message(),
			], '404' );
			return 0;
		}

		$ext = pathinfo( wp_parse_url( $image_url, PHP_URL_PATH ), PATHINFO_EXTENSION );
		if ( empty( $ext ) || ! in_array( strtolower( $ext ), [ 'jpg', 'jpeg', 'png', 'gif', 'webp' ], true ) ) {
			$ext = 'jpg';
		}

		$file_array = [
			'name' => 'rss_' . uniqid() . '.' . $ext,
			'tmp_name' => $tmp,
		];

		$attachment_id = media_handle_sideload( $file_array, $post_id );

		if ( is_wp_error( $attachment_id ) ) {
			@unlink( $tmp );
			Logger::error( 'rss_image_sideload_failed', $post_id, [
				'image_url' => $image_url,
				'error' => $attachment_id->get_error_message(),
			], '500' );
			return 0;
		}

		update_post_meta( $attachment_id, Config::META_IS_AI_COLLAGE, '1' );
		set_post_thumbnail( $post_id, $attachment_id );

		return $attachment_id;
	}

	private static function sideload_source_video( $file_path, $post_id, $source_url = '' ) {
		if ( ! function_exists( 'media_handle_sideload' ) ) {
			require_once ABSPATH . 'wp-admin/includes/media.php';
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/image.php';
		}

		$ext = pathinfo( $file_path, PATHINFO_EXTENSION );
		if ( empty( $ext ) || ! in_array( strtolower( $ext ), Config::VIDEO_EXTENSIONS, true ) ) {
			$ext = 'mp4';
		}

		$file_array = [
			'name' => 'rss_source_video_' . uniqid() . '.' . $ext,
			'tmp_name' => $file_path,
		];

		$attachment_id = media_handle_sideload( $file_array, $post_id );

		if ( is_wp_error( $attachment_id ) ) {
			Logger::error( 'rss_source_video_sideload_failed', $post_id, [
				'source_url' => $source_url,
				'error' => $attachment_id->get_error_message(),
			], '500' );
			return 0;
		}

		// Mark as SOURCE video (not AI-generated) — critical to prevent Buffer from sharing the raw source
		update_post_meta( $attachment_id, Config::META_SOURCE_VIDEO, '1' );
		update_post_meta( $attachment_id, Config::META_CONTENT_TYPE, Config::CONTENT_TYPE_VIDEO );

		// Store source video URL for reference
		if ( ! empty( $source_url ) ) {
			update_post_meta( $post_id, Config::META_RSS_SOURCE_VIDEO, esc_url_raw( $source_url ) );
		}

		// Do NOT set as post thumbnail for videos (thumbnail should be an image)
		// Do NOT set META_IS_AI_COLLAGE — this is the raw source, not the AI-generated reel

		Logger::info( 'rss_source_video_sideloaded', $post_id, [
			'attachment_id' => $attachment_id,
			'source_url' => $source_url,
		], '200' );

		return $attachment_id;
	}

	public static function test_feed( $url ) {
		$feed = fetch_feed( $url );

		if ( is_wp_error( $feed ) ) {
			return [
				'success' => false,
				'error' => $feed->get_error_message(),
				'items' => 0,
				'title' => '',
			];
		}

		return [
			'success' => true,
			'error' => '',
			'items' => $feed->get_item_quantity(),
			'title' => $feed->get_title() ?: '',
		];
	}

 	private static function validate_source_content_quality( $title, $content ) {
 		$plain = trim( wp_strip_all_tags( $content ) );
 		if ( $plain === '' ) {
 			return [ 'valid' => false, 'reason' => 'empty_content_after_strip' ];
 		}
 		if ( ! mb_check_encoding( $plain, 'UTF-8' ) && ! mb_check_encoding( $plain, 'ISO-8859-1' ) ) {
 			return [ 'valid' => false, 'reason' => 'unrecognizable_encoding' ];
 		}
 		$meaningful = preg_replace( '/[\s\d\p{P}\p{S}]/u', '', $plain );
 		if ( mb_strlen( $meaningful, 'UTF-8' ) < 20 ) {
 			return [ 'valid' => false, 'reason' => 'insufficient_meaningful_text' ];
 		}
 		$hex_blob = preg_match( '/^[A-Fa-f0-9\s]{40,}$/', $plain );
 		if ( $hex_blob ) {
 			return [ 'valid' => false, 'reason' => 'hex_blob_detected' ];
 		}
 		$base64_blob = preg_match( '/^[A-Za-z0-9+\/=]{50,}$/', $plain );
 		if ( $base64_blob ) {
 			return [ 'valid' => false, 'reason' => 'base64_blob_detected' ];
 		}
 		$html_entities = preg_match('/&[a-zA-Z]+;|&#\d+;/', $plain );
 		$has_words = preg_match( '/\b\w{2,}\b/u', $plain );
 		if ( $html_entities && ! $has_words ) {
 			return [ 'valid' => false, 'reason' => 'html_entities_without_words' ];
 		}
 		return [ 'valid' => true, 'reason' => 'passed' ];
 	}

 	private static function prefilter_check( $title, $content, array $feed_config ) {
 		$score = 50;
 		$reasons = [];
 
 		$block_keywords = get_option( Config::OPTION_RSS_BLOCK_KEYWORDS, Config::get_default_block_keywords() );
 		if ( ! is_array( $block_keywords ) ) {
 			$block_keywords = Config::get_default_block_keywords();
 		}
 
 		$combined = mb_strtolower( $title . ' ' . $content, 'UTF-8' );
 		foreach ( $block_keywords as $keyword ) {
 			if ( mb_strpos( $combined, mb_strtolower( $keyword, 'UTF-8' ) ) !== false ) {
 				return [
 					'pass' => false,
 					'reason' => 'block_keyword:' . $keyword,
 					'score' => 0,
 				];
 			}
 		}

 		$min_length = (int) get_option( Config::OPTION_RSS_MIN_CONTENT_LENGTH, Config::RSS_DEFAULT_MIN_CONTENT_LENGTH );
 		$content_length = mb_strlen( wp_strip_all_tags( $content ), 'UTF-8' );
 		if ( $content_length < $min_length ) {
 			return [
 				'pass' => false,
 				'reason' => 'content_too_short:' . $content_length . '<' . $min_length,
 				'score' => 0,
 			];
 		}

 		$quality = self::validate_source_content_quality( $title, $content );
 		if ( ! $quality['valid'] ) {
 			return [
 				'pass' => false,
 				'reason' => 'content_quality:' . $quality['reason'],
 				'score' => 0,
 			];
 		}

		if ( $content_length > 500 ) {
			$score += 10;
		}
		if ( $content_length > 1000 ) {
			$score += 10;
		}

		$title_word_count = str_word_count( $title );
		if ( $title_word_count < 3 ) {
			$score -= 20;
			$reasons[] = 'title_too_short';
		}
		if ( $title_word_count > 20 ) {
			$score -= 10;
			$reasons[] = 'title_too_long';
		}

		$source_reputation = Config::get_default_source_reputation();
		$feed_host = parse_url( $feed_config['url'] ?? '', PHP_URL_HOST );
		if ( $feed_host ) {
			foreach ( $source_reputation as $domain => $rep_score ) {
				if ( stripos( $feed_host, $domain ) !== false ) {
					$score += $rep_score;
					break;
				}
			}
		}

		if ( stripos( $title, 'press release' ) !== false || stripos( $title, 'sponsored' ) !== false ) {
			$score -= 30;
			$reasons[] = 'promotional_content';
		}

		if ( preg_match( '/^\d+\s*(stocks?|market|index|dow|s&p|nasdaq)/i', $title ) ) {
			$score -= 15;
			$reasons[] = 'market_update';
		}

		$has_numbers = preg_match( '/\d+/', $title );
		if ( $has_numbers ) {
			$score += 5;
		}

		$has_action_verb = preg_match( '/\b(?:announces|launches|reveals|kills|saves|wins|loses|bans|allows|cuts|raises|slams|rejects|approves|arrests|resigns|dies|crashes|surges|plunges)\b/i', $title );
		if ( $has_action_verb ) {
			$score += 10;
		}

		$score = max( 0, min( 100, $score ) );

		$threshold = (int) get_option( Config::OPTION_RSS_PREFILTER_THRESHOLD, Config::RSS_DEFAULT_PREFILTER_THRESHOLD );
		if ( $score < $threshold ) {
			return [
				'pass' => false,
				'reason' => 'low_score:' . $score . ' (' . implode( ', ', $reasons ) . ')',
				'score' => $score,
			];
		}

		return [
			'pass' => true,
			'reason' => 'passed',
			'score' => $score,
		];
	}
}
