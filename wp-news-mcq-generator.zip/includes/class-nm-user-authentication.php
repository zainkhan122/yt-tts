<?php
if (! defined('ABSPATH')) {
	exit;
}

/**
 * User Authentication System for MCQ Plugin
 * Handles registration, login, password reset, profile management
 *
 * @package WP_News_MCQ_Generator
 * @version 2.6 - Removed Avatar Upload Remnants
 *
 * @MODIFIED: Removed 'nm_profile_picture_id' from cleanup_deleted_user.
 */

class NM_User_Authentication
{

	private static $instance = null;

	public static function init()
	{
		if (self::$instance === null) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct()
	{
		add_action('delete_user', array($this, 'cleanup_deleted_user'));
		add_action('wp_ajax_nopriv_nm_user_register', array($this, 'handle_registration'));
		add_action('wp_ajax_nopriv_nm_user_login', array($this, 'handle_login'));
		add_action('wp_ajax_nopriv_nm_user_forgot_password', array($this, 'handle_forgot_password'));
		add_action('wp_ajax_nopriv_nm_user_reset_password', array($this, 'handle_reset_password'));
		add_action('wp_ajax_nm_user_logout', array($this, 'handle_logout'));
		add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
		add_action('user_register', array($this, 'initialize_user_data'), 10, 1);

		// Avatar upload hooks are intentionally REMOVED.
	}

	public function enqueue_scripts()
	{
		if (! is_user_logged_in() || get_option('nm_enable_user_system', 1)) {
			wp_enqueue_script(
				'nm-auth-handler',
				NM_PLUGIN_URL . 'assets/js/auth-handler.js',
				array('jquery'),
				filemtime(NM_PLUGIN_PATH . 'assets/js/auth-handler.js'),
				true
			);

			wp_localize_script(
				'nm-auth-handler',
				'nmAuthData',
				array(
					'ajaxurl'             => admin_url('admin-ajax.php'),
					'nonce'               => wp_create_nonce('nm_auth_nonce'),
					'homeUrl'             => home_url(),
					'loginUrl'            => home_url('/mcq-login/'),
					'registerUrl'         => home_url('/mcq-register/'),
					'dashboardUrl'        => home_url('/mcq-dashboard/'),
					'enableGoogleLogin'   => get_option('nm_enable_google_oauth', 0),
					'enableFacebookLogin' => get_option('nm_enable_facebook_oauth', 0),
					'enablePasskeys'      => get_option('nm_enable_passkeys', 0),
				)
			);
		}
	}

	private function check_rate_limit($action, $identifier, $max_attempts = 5, $timeframe = 900)
	{
		global $wpdb;
		$table = $wpdb->prefix . 'nm_rate_limits';

		$key = md5($action . $identifier);
		$now = current_time('mysql');

		// Clean old attempts
		$wpdb->query(
			$wpdb->prepare(
				'DELETE FROM %i WHERE attempt_key = %s AND created_at < %s',
				$table,
				$key,
				date('Y-m-d H:i:s', strtotime("-{$timeframe} seconds"))
			)
		);

		// Count recent attempts
		$count = $wpdb->get_var(
			$wpdb->prepare(
				'SELECT COUNT(*) FROM %i WHERE attempt_key = %s AND created_at > %s',
				$table,
				$key,
				date('Y-m-d H:i:s', strtotime("-{$timeframe} seconds"))
			)
		);

		if ($count >= $max_attempts) {
			return false;
		}

		// Log this attempt
		$wpdb->insert(
			$table,
			array(
				'attempt_key' => $key,
				'action'      => $action,
				'identifier'  => $identifier,
				'created_at'  => $now,
			),
			array('%s', '%s', '%s', '%s')
		);

		return true;
	}

	public function handle_registration()
	{
		check_ajax_referer('nm_auth_nonce', 'nonce');

		$username         = NM_Security_Manager::sanitize_text($_POST['username'] ?? '');
		$email            = NM_Security_Manager::sanitize_email($_POST['email'] ?? '');
		$password         = $_POST['password'] ?? '';
		$confirm_password = $_POST['confirm_password'] ?? '';
		$display_name     = NM_Security_Manager::sanitize_text($_POST['display_name'] ?? $username);

		if (empty($username) || empty($email) || empty($password)) {
			wp_send_json_error(array('message' => 'All fields are required.'));
		}

		if (! is_email($email)) {
			wp_send_json_error(array('message' => 'Invalid email address.'));
		}

		$ip = NM_Security_Manager::get_client_ip();

		if (email_exists($email)) {
			if (! $this->check_rate_limit('registration', $ip . '_' . $email, 1, 3600)) {
				wp_send_json_error(array('message' => 'This email is already registered. Use "Forgot Password" to recover your account.'));
			}
		} elseif (! $this->check_rate_limit('registration', $ip, 5, 3600)) {
			wp_send_json_error(array('message' => 'Too many registration attempts from your IP. Please try again later.'));
		}

		if (strlen($password) < 8) {
			wp_send_json_error(array('message' => 'Password must be at least 8 characters long.'));
		}

		if ($password !== $confirm_password) {
			wp_send_json_error(array('message' => 'Passwords do not match.'));
		}

		if (! $this->validate_password_strength($password)) {
			wp_send_json_error(array('message' => 'Password must contain uppercase, lowercase, number, and special character.'));
		}

		if (username_exists($username)) {
			wp_send_json_error(array('message' => 'Username already exists.'));
		}

		if (email_exists($email)) {
			wp_send_json_error(array('message' => 'Email already registered.'));
		}

		$user_id = wp_create_user($username, $password, $email);

		if (is_wp_error($user_id)) {
			wp_send_json_error(array('message' => $user_id->get_error_message()));
		}

		wp_update_user(
			array(
				'ID'           => $user_id,
				'display_name' => $display_name,
				'role'         => 'quiz_taker',
			)
		);

		$this->initialize_user_data($user_id);

		// Send verification email if class exists
		if (class_exists('NM_Email_Verification')) {
			NM_Email_Verification::send_verification_email($user_id, $email, $username);
		}

		// Mark as unverified initially
		update_user_meta($user_id, 'nm_email_verified', 0);


		wp_send_json_success(
			array(
				'message'              => 'Registration successful! Please check your email to verify your account.',
				'pending_verification' => true,
				'email'                => $email,
			)
		);
	}

	public function handle_login()
	{
		check_ajax_referer('nm_auth_nonce', 'nonce');

		$username = NM_Security_Manager::sanitize_text($_POST['username'] ?? '');
		$password = $_POST['password'] ?? '';
		$remember = rest_sanitize_boolean($_POST['remember'] ?? false);

		$ip = NM_Security_Manager::get_client_ip();
		if (! $this->check_rate_limit('login', $ip, 5, 900)) {
			wp_send_json_error(array('message' => 'Too many login attempts. Please try again in 15 minutes.'));
		}

		if (empty($username) || empty($password)) {
			wp_send_json_error(array('message' => 'Username and password are required.'));
		}

		$user = wp_authenticate($username, $password);

		if (is_wp_error($user)) {
			wp_send_json_error(array('message' => 'Invalid username or password.'));
		}

		$email_verified = get_user_meta($user->ID, 'nm_email_verified', true);
		if ($email_verified === 0 || $email_verified === '0' || $email_verified === false) {
			$sent_time = get_user_meta($user->ID, 'nm_verification_sent', true);
			// Resend if older than 24 hours
			if (! $sent_time || strtotime($sent_time) < strtotime('-24 hours')) {
				if (class_exists('NM_Email_Verification')) {
					NM_Email_Verification::send_verification_email($user->ID, $user->user_email, $user->user_login);
				}
			}

			wp_send_json_error(
				array(
					'message'              => 'Please verify your email first. Check your inbox for the verification link.',
					'pending_verification' => true,
				)
			);
		}

		wp_set_auth_cookie($user->ID, $remember);
		update_user_meta($user->ID, 'nm_last_login', current_time('mysql'));

		if (class_exists('NM_Gamification')) {
			NM_Gamification::check_login_streak($user->ID);
		}

		wp_send_json_success(
			array(
				'message'  => 'Login successful!',
				'redirect' => home_url('/mcq-dashboard/'),
			)
		);
	}

	public function handle_logout()
	{
		check_ajax_referer('nm_auth_nonce', 'nonce');
		wp_logout();
		wp_send_json_success(
			array(
				'message'  => 'Logged out successfully.',
				'redirect' => home_url('/mcq-login/'),
			)
		);
	}

	public function handle_forgot_password()
	{
		check_ajax_referer('nm_auth_nonce', 'nonce');
		$email = NM_Security_Manager::sanitize_email($_POST['email'] ?? '');

		$ip = NM_Security_Manager::get_client_ip();
		if (! $this->check_rate_limit('forgot_password', $ip, 3, 3600)) {
			wp_send_json_error(array('message' => 'Too many password reset requests. Please try again later.'));
		}

		if (empty($email) || ! is_email($email)) {
			wp_send_json_error(array('message' => 'Please enter a valid email address.'));
		}

		$user = get_user_by('email', $email);

		if (! $user) {
			wp_send_json_success(array('message' => 'If the email exists, a reset link has been sent.'));
			return;
		}

		$reset_key = wp_generate_password(20, false);
		update_user_meta($user->ID, 'nm_password_reset_key', $reset_key);
		update_user_meta($user->ID, 'nm_password_reset_expiry', time() + 3600);

		$reset_url = add_query_arg(
			array(
				'key'   => $reset_key,
				'email' => urlencode($email),
			),
			home_url('/mcq-reset-password/')
		);

		$subject = 'Password Reset Request - ' . get_bloginfo('name');
		$message = "Hi {$user->display_name},\n\nWe received a request to reset your password.\n\nClick here to reset your password:\n{$reset_url}\n\nThis link will expire in 1 hour.\n\nIf you didn't request this, please ignore this email.\n\nThanks,\n" . get_bloginfo('name');

		wp_mail($email, $subject, $message);

		wp_send_json_success(array('message' => 'If the email exists, a reset link has been sent.'));
	}

	public function handle_reset_password()
	{
		check_ajax_referer('nm_auth_nonce', 'nonce');

		$email            = NM_Security_Manager::sanitize_email($_POST['email'] ?? '');
		$key              = NM_Security_Manager::sanitize_text($_POST['key'] ?? '');
		$password         = $_POST['password'] ?? '';
		$confirm_password = $_POST['confirm_password'] ?? '';

		if (empty($email) || empty($key) || empty($password)) {
			wp_send_json_error(array('message' => 'Invalid reset request.'));
		}

		$user = get_user_by('email', $email);
		if (! $user) {
			wp_send_json_error(array('message' => 'Invalid reset request.'));
		}

		$stored_key = get_user_meta($user->ID, 'nm_password_reset_key', true);
		$expiry     = get_user_meta($user->ID, 'nm_password_reset_expiry', true);

		if ($stored_key !== $key || time() > $expiry) {
			wp_send_json_error(array('message' => 'Reset link has expired or is invalid.'));
		}

		if ($password !== $confirm_password) {
			wp_send_json_error(array('message' => 'Passwords do not match.'));
		}

		if (strlen($password) < 8) {
			wp_send_json_error(array('message' => 'Password must be at least 8 characters long.'));
		}

		if (! $this->validate_password_strength($password)) {
			wp_send_json_error(array('message' => 'Password must contain uppercase, lowercase, number, and special character.'));
		}

		wp_set_password($password, $user_id);

		delete_user_meta($user->ID, 'nm_password_reset_key');
		delete_user_meta($user->ID, 'nm_password_reset_expiry');

		wp_send_json_success(
			array(
				'message'  => 'Password reset successfully! You can now login.',
				'redirect' => home_url('/mcq-login/'),
			)
		);
	}

	public function initialize_user_data($user_id)
	{
		update_user_meta($user_id, 'nm_total_points', 0);
		update_user_meta($user_id, 'nm_current_streak', 0);
		update_user_meta($user_id, 'nm_longest_streak', 0);
		update_user_meta($user_id, 'nm_total_quizzes', 0);
		update_user_meta($user_id, 'nm_correct_answers', 0);
		update_user_meta($user_id, 'nm_wrong_answers', 0);
		update_user_meta($user_id, 'nm_achievements', array());
		update_user_meta($user_id, 'nm_badges', array());
		update_user_meta($user_id, 'nm_level', 1);
		update_user_meta($user_id, 'nm_registration_date', current_time('mysql'));
		update_user_meta($user_id, 'nm_public_profile', true);
	}

	private function validate_password_strength($password)
	{
		$uppercase = preg_match('/[A-Z]/', $password);
		$lowercase = preg_match('/[a-z]/', $password);
		$number    = preg_match('/[0-9]/', $password);
		$special   = preg_match('/[^A-Za-z0-9]/', $password);

		return $uppercase && $lowercase && $number && $special;
	}

	public static function cleanup_rate_limits()
	{
		global $wpdb;
		$table = $wpdb->prefix . 'nm_rate_limits';

		$wpdb->query(
			$wpdb->prepare(
				'DELETE FROM %i WHERE created_at < DATE_SUB(NOW(), INTERVAL 24 HOUR)',
				$table
			)
		);
	}

	public function cleanup_deleted_user($user_id)
	{
		delete_user_meta($user_id, 'nm_total_points');
		delete_user_meta($user_id, 'nm_current_streak');
		delete_user_meta($user_id, 'nm_longest_streak');
		delete_user_meta($user_id, 'nm_total_quizzes');
		delete_user_meta($user_id, 'nm_correct_answers');
		delete_user_meta($user_id, 'nm_wrong_answers');
		delete_user_meta($user_id, 'nm_achievements');
		delete_user_meta($user_id, 'nm_badges');
		delete_user_meta($user_id, 'nm_level');
		delete_user_meta($user_id, 'nm_email_verified');
		delete_user_meta($user_id, 'nm_verification_token');
		delete_user_meta($user_id, 'nm_pending_registration_bonus');

		// ✅ MODIFIED: This line is now removed.
		// delete_user_meta($user_id, 'nm_profile_picture_id');

	}
}
