/**
 * MCQ Video Studio — Server Render Core: Browser Global Shim
 *
 * Provides the minimal `window` / `document` / Web API surface that the
 * browser-authored rendering modules (vs-unified-renderer, vs-template-manager,
 * vs-animation-engine, vs-text-effects, vs-video-templates) expect, so they can
 * run unmodified inside Node.js with node-canvas. No Chrome, no Playwright, no
 * WordPress, no admin-ajax, no nonce — frames are drawn to a node-canvas 2D
 * context and piped to FFmpeg.
 *
 * This is the same shim pattern already used by the browser worker
 * (vs-render-worker.js lines 12-24), extended for the few extra globals the
 * templates touch (window.location, window.MCQVSConfig assetsUrl, an offscreen
 * <canvas> factory).
 *
 * @package MCQ_Video_Studio
 * @subpackage render-service/render-core
 */

'use strict';

const { createCanvas } = require('canvas');

/**
 * The shim is installed onto `global` so that the rendering modules, which
 * reference bare `window` / `document` / `OffscreenCanvas` / `self`, resolve
 * against the Node global scope exactly as they would in a browser worker.
 */
function installDomShim(opts) {
    opts = opts || {};
    const width = opts.width || 1080;
    const height = opts.height || 1920;

    // OffscreenCanvas-equivalent backed by node-canvas.
    function makeCanvas(w, h) {
        w = w || width;
        h = h || height;
        const c = createCanvas(w, h);
        // node-canvas does not implement roundRect on older versions; polyfill
        // it (mirrors vs-render-worker.js:26-45) so templates draw identically.
        if (typeof c.getContext('2d').roundRect !== 'function') {
            const proto = Object.getPrototypeOf(c.getContext('2d'));
            proto.roundRect = function (x, y, w, h, radii) {
                if (!radii) radii = 0;
                if (typeof radii === 'number') radii = { tl: radii, tr: radii, br: radii, bl: radii };
                else if (Array.isArray(radii)) radii = { tl: radii[0], tr: radii[0], br: radii[0], bl: radii[0] };
                this.beginPath();
                this.moveTo(x + radii.tl, y);
                this.lineTo(x + w - radii.tr, y);
                this.quadraticCurveTo(x + w, y, x + w, y + radii.tr);
                this.lineTo(x + w, y + h - radii.br);
                this.quadraticCurveTo(x + w, y + h, x + w - radii.br, y + h);
                this.lineTo(x + radii.bl, y + h);
                this.quadraticCurveTo(x, y + h, x, y + h - radii.bl);
                this.lineTo(x, y + radii.tl);
                this.quadraticCurveTo(x, y, x + radii.tl, y);
                this.closePath();
            };
        }
        return c;
    }

    const documentShim = {
        createElement(tag) {
            if (tag === 'canvas') {
                return makeCanvas(width, height);
            }
            if (tag === 'video') {
                // Server mode cannot decode background videos. Return a no-op
                // object so vs-template-manager's background-video branch fails
                // soft and falls back to the gradient/color branch. This keeps
                // output deterministic and WebCodecs-free.
                return {
                    crossOrigin: null,
                    src: '',
                    play() { return Promise.resolve(); },
                    pause() {},
                    addEventListener() {},
                    removeEventListener() {},
                    getContext() { return null; },
                };
            }
            return { style: {}, addEventListener() {}, removeEventListener() {} };
        },
        fonts: { add() {}, load() { return Promise.resolve(); }, ready: Promise.resolve() },
        addEventListener() {},
        removeEventListener() {},
    };

    const windowShim = {
        // Used by vs-template-manager for resolving relative asset URLs.
        location: { origin: opts.origin || '', href: opts.origin || '' },
        MCQVSConfig: { assetsUrl: opts.assetsUrl || '', version: opts.version || 'server' },
        devicePixelRatio: 1,
        addEventListener() {},
        removeEventListener() {},
        // AnimationEngine / TextEffects / VideoTemplates attach themselves here.
        __MCQVS_BG_VIDEOS: new Set ? new Set() : { add() {}, delete() {} },
        // Exposed so the Node renderer can register the real drawing modules.
        // (populated by server-renderer.js after loading the browser files)
    };

    global.window = windowShim;
    global.document = documentShim;
    global.self = global;
    global.OffscreenCanvas = function (w, h) { return makeCanvas(w, h); };
    global.location = windowShim.location;
    if (!Object.isFrozen(global) && !global.navigator) {
        global.navigator = { userAgent: 'mcqvs-server-renderer' };
    }

    // Provide a real OffscreenCanvasRenderingContext2D prototype reference if
    // missing, so the worker's roundRect polyfill guard doesn't throw.
    if (typeof global.OffscreenCanvasRenderingContext2D === 'undefined') {
        global.OffscreenCanvasRenderingContext2D = Object.getPrototypeOf(makeCanvas().getContext('2d')).constructor;
    }

    windowShim.createCanvas = makeCanvas;

    return { window: windowShim, document: documentShim, makeCanvas };
}

module.exports = { installDomShim };
