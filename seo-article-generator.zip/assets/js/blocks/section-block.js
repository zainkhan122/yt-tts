/**
 * SEO Gen Section Block - Editor Registration
 * 
 * @MODIFIED 2026-03-22: Added JS block registration for editor compatibility
 * 
 * This block is server-side rendered. This JS file only registers it with
 * the WordPress block editor so it doesn't show "block not supported" error.
 */
(function (wp) {
    var registerBlockType = wp.blocks.registerBlockType;
    var el = wp.element.createElement;
    var InnerBlocks = wp.blockEditor.InnerBlocks;

    registerBlockType('seo-gen/section', {
        apiVersion: 3,
        title: 'SEO Gen Section',
        description: 'A dynamic article section with zone identifier. Server-side rendered.',
        icon: 'layout',
        category: 'layout',

        // Attributes - matching the PHP side
        attributes: {
            zone: {
                type: 'string',
                default: ''
            },
            title: {
                type: 'string',
                default: ''
            }
        },

        // Editor placeholder
        edit: function (props) {
            var zone = props.attributes.zone || 'Unnamed Zone';
            
            return el(
                'div',
                {
                    style: {
                        padding: '15px',
                        border: '1px dashed #764ba2',
                        borderRadius: '8px',
                        marginBottom: '10px',
                        position: 'relative',
                        backgroundColor: '#f9f9f9'
                    }
                },
                el('div', {
                    style: {
                        fontSize: '10px',
                        color: '#764ba2',
                        marginBottom: '5px',
                        fontWeight: 'bold',
                        textTransform: 'uppercase'
                    }
                }, 'Zone: ' + zone),
                // Render InnerBlocks so we can see content in editor (though usually empty)
                el(InnerBlocks, {
                    renderAppender: InnerBlocks.ButtonBlockAppender
                })
            );
        },

        // Dynamic block - no save, server renders
        save: function () {
            return el(InnerBlocks.Content);
        }
    });
})(window.wp);
