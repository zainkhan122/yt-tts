/**
 * PWA Install Prompt - Professional Bottom Sheet Banner
 * Smart timing: 5s delay first visit, 3 visits after dismissal
 * 
 * @package WP_News_MCQ_Generator
 * @version 7.3.5
 * @mobile-first Mobile-optimized design
 */

(function () {
    'use strict';

    const STORAGE_KEY = 'nm_pwa_prompt';
    let deferredPrompt = null;
    let tracking = null;

    /**
     * Initialize PWA install prompt
     */
    function init() {
        // Check if PWA config exists
        if (typeof nmPwaConfig === 'undefined') {
            console.warn('NM PWA: Configuration not found');
            return;
        }

        // Load tracking data
        tracking = loadTracking();

        // Check if should skip
        if (shouldSkip()) {
            console.log('NM PWA: Skipping prompt (already installed, never ask, or dismissed today)');
            return;
        }

        // Listen for beforeinstallprompt event
        window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

        // Check if already installed
        window.addEventListener('appinstalled', handleAppInstalled);

        // iOS detection
        detectIOS();

        console.log('NM PWA: Install prompt initialized');
    }

    /**
     * Load tracking data from localStorage
     */
    function loadTracking() {
        const saved = localStorage.getItem(STORAGE_KEY);
        if (saved) {
            try {
                return JSON.parse(saved);
            } catch (e) {
                console.error('NM PWA: Failed to parse tracking data', e);
            }
        }

        // Default tracking data
        return {
            visitCount: 0,
            dismissCount: 0,
            lastDismissDate: null,
            neverAsk: false,
            installed: false,
            firstVisit: new Date().toISOString().split('T')[0]
        };
    }

    /**
     * Save tracking data to localStorage
     */
    function saveTracking() {
        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(tracking));
        } catch (e) {
            console.error('NM PWA: Failed to save tracking data', e);
        }
    }

    /**
     * Check if should skip showing prompt
     */
    function shouldSkip() {
        // Never ask again
        if (tracking.neverAsk) {
            return true;
        }

        // Already installed
        if (tracking.installed) {
            return true;
        }

        // Check if standalone mode (already installed)
        if (window.matchMedia('(display-mode: standalone)').matches ||
            window.navigator.standalone === true) {
            tracking.installed = true;
            saveTracking();
            return true;
        }

        // Dismissed today?
        const today = new Date().toISOString().split('T')[0];
        if (tracking.lastDismissDate === today) {
            return true;
        }

        return false;
    }

    /**
     * Handle beforeinstallprompt event
     */
    function handleBeforeInstallPrompt(e) {
        console.log('NM PWA: beforeinstallprompt event fired');

        // Prevent default browser prompt
        e.preventDefault();

        // Store event for later use
        deferredPrompt = e;

        // Decide when to show based on visit logic
        checkShowTiming();
    }

    /**
     * Check timing logic for showing prompt
     */
    function checkShowTiming() {
        const isFirstVisit = tracking.visitCount === 0 && tracking.dismissCount === 0;

        if (isFirstVisit) {
            // First visit: wait 5 seconds
            console.log('NM PWA: First visit - showing prompt after 5 seconds');
            setTimeout(showBanner, nmPwaConfig.delaySeconds * 1000);
            trackEvent('pwa_prompt_scheduled', { source: 'first_visit', delay: 5 });
        } else {
            // Not first visit: check if dismissed before
            tracking.visitCount++;
            saveTracking();

            console.log(`NM PWA: Visit count: ${tracking.visitCount}`);

            if (tracking.visitCount >= nmPwaConfig.requiredVisits) {
                // Reached required visits, show prompt
                console.log('NM PWA: Reached 3 visits - showing prompt');
                setTimeout(showBanner, nmPwaConfig.delaySeconds * 1000);
                trackEvent('pwa_prompt_scheduled', {
                    source: 'after_3_visits',
                    visit_count: tracking.visitCount
                });

                // Reset visit counter for next cycle
                tracking.visitCount = 0;
                saveTracking();
            } else {
                console.log(`NM PWA: Need ${nmPwaConfig.requiredVisits - tracking.visitCount} more visits`);
            }
        }
    }

    /**
     * Show install banner (bottom sheet)
     */
    function showBanner() {
        // Check if already showing
        if (document.getElementById('nm-pwa-banner')) {
            return;
        }

        // Build banner HTML
        const banner = document.createElement('div');
        banner.id = 'nm-pwa-banner';
        banner.className = 'nm-pwa-banner';
        banner.innerHTML = `
            <button class="nm-pwa-close" id="nm-pwa-close" aria-label="Close" title="Close">×</button>
            
            <div class="nm-pwa-content">
                <div class="nm-pwa-icon">📱</div>
                
                <div class="nm-pwa-text">
                    <h3 class="nm-pwa-title">Install ${nmPwaConfig.appName}</h3>
                    <p class="nm-pwa-subtitle">Get instant access to:</p>
                    
                    <ul class="nm-pwa-benefits">
                        <li>✓ 20-60 new MCQs daily</li>
                        <li>✓ Offline practice mode</li>
                        <li>✓ Real-time notifications</li>
                        <li>✓ Lightning-fast loading</li>
                    </ul>
                </div>
            </div>
            
            <div class="nm-pwa-actions">
                <button class="nm-pwa-install" id="nm-pwa-install">Install Now</button>
                <button class="nm-pwa-later" id="nm-pwa-later">Maybe Later</button>
            </div>
        `;

        document.body.appendChild(banner);

        // Trigger slide-up animation
        setTimeout(() => {
            banner.classList.add('show');
        }, 10);

        // Setup event listeners
        setupBannerEvents(banner);

        // Track shown event
        trackEvent('pwa_prompt_shown', {
            visit_count: tracking.visitCount,
            dismiss_count: tracking.dismissCount
        });
    }

    /**
     * Setup banner event listeners
     */
    function setupBannerEvents(banner) {
        // Install button
        document.getElementById('nm-pwa-install').addEventListener('click', handleInstallClick);

        // Maybe later button
        document.getElementById('nm-pwa-later').addEventListener('click', () => {
            handleDismiss('later', banner);
        });

        // Close button
        document.getElementById('nm-pwa-close').addEventListener('click', () => {
            handleDismiss('close', banner);
        });
    }

    /**
     * Handle install button click
     */
    function handleInstallClick() {
        if (!deferredPrompt) {
            console.warn('NM PWA: No deferred prompt available');
            return;
        }

        // Track click
        trackEvent('pwa_install_clicked');

        // Show native install prompt
        deferredPrompt.prompt();

        // Wait for user choice
        deferredPrompt.userChoice.then((choiceResult) => {
            if (choiceResult.outcome === 'accepted') {
                console.log('NM PWA: User accepted install');

                // Mark as installed
                tracking.installed = true;
                saveTracking();

                // Track success
                trackEvent('pwa_install_success');

                // Hide banner
                hideBanner();
            } else {
                console.log('NM PWA: User declined install');

                // Track decline
                trackEvent('pwa_install_declined');

                // Treat as dismissal
                handleDismiss('declined');
            }

            // Clear deferred prompt
            deferredPrompt = null;
        });
    }

    /**
     * Handle dismissal (Later/Close)
     */
    function handleDismiss(type, banner) {
        console.log(`NM PWA: Dismissed (${type})`);

        // Update tracking
        tracking.dismissCount++;
        tracking.lastDismissDate = new Date().toISOString().split('T')[0];
        tracking.visitCount = 0; // Reset counter
        saveTracking();

        // Track event
        trackEvent('pwa_dismissed_' + type, {
            dismiss_count: tracking.dismissCount
        });

        // Hide banner
        hideBanner(banner);
    }

    /**
     * Hide banner with animation
     */
    function hideBanner(banner) {
        const bannerEl = banner || document.getElementById('nm-pwa-banner');
        if (!bannerEl) return;

        bannerEl.classList.remove('show');

        setTimeout(() => {
            bannerEl.remove();
        }, 400);
    }

    /**
     * Handle app installed event
     */
    function handleAppInstalled() {
        console.log('NM PWA: App installed successfully');

        tracking.installed = true;
        saveTracking();

        trackEvent('pwa_app_installed');

        hideBanner();
    }

    /**
     * Detect and handle iOS devices
     */
    function detectIOS() {
        const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
        const isStandalone = window.navigator.standalone === true;

        if (isIOS && !isStandalone && !tracking.installed && !tracking.neverAsk) {
            // iOS doesn't support beforeinstallprompt
            // Show custom iOS instructions after delay
            const isFirstVisit = tracking.visitCount === 0 && tracking.dismissCount === 0;

            if (isFirstVisit) {
                setTimeout(() => showIOSBanner(), nmPwaConfig.delaySeconds * 1000);
            } else {
                tracking.visitCount++;
                saveTracking();

                if (tracking.visitCount >= nmPwaConfig.requiredVisits) {
                    setTimeout(() => showIOSBanner(), nmPwaConfig.delaySeconds * 1000);
                    tracking.visitCount = 0;
                    saveTracking();
                }
            }
        }
    }

    /**
     * Show iOS-specific install instructions
     */
    function showIOSBanner() {
        // Check if already showing
        if (document.getElementById('nm-pwa-banner')) {
            return;
        }

        const banner = document.createElement('div');
        banner.id = 'nm-pwa-banner';
        banner.className = 'nm-pwa-banner nm-pwa-ios';
        banner.innerHTML = `
            <button class="nm-pwa-close" id="nm-pwa-close" aria-label="Close">×</button>
            
            <div class="nm-pwa-content">
                <div class="nm-pwa-icon">📱</div>
                
                <div class="nm-pwa-text">
                    <h3 class="nm-pwa-title">Install ${nmPwaConfig.appName}</h3>
                    <p class="nm-pwa-subtitle">To install this app:</p>
                    
                    <ol class="nm-pwa-ios-steps">
                        <li>Tap the Share button <span class="nm-ios-icon">⎙</span></li>
                        <li>Scroll down and tap "Add to Home Screen"</li>
                        <li>Tap "Add" in the top-right corner</li>
                    </ol>
                </div>
            </div>
            
            <div class="nm-pwa-actions">
                <button class="nm-pwa-later" id="nm-pwa-later">Got It</button>
            </div>
        `;

        document.body.appendChild(banner);

        setTimeout(() => {
            banner.classList.add('show');
        }, 10);

        // Setup close handlers
        document.getElementById('nm-pwa-later').addEventListener('click', () => {
            handleDismiss('ios_got_it', banner);
        });

        document.getElementById('nm-pwa-close').addEventListener('click', () => {
            handleDismiss('ios_close', banner);
        });

        trackEvent('pwa_ios_prompt_shown');
    }

    /**
     * Track analytics event
     */
    function trackEvent(action, data) {
        // Log to console for debugging
        console.log('NM PWA Event:', action, data);

        // Can integrate with Google Analytics, custom tracking, etc.
        if (typeof gtag !== 'undefined') {
            gtag('event', action, {
                event_category: 'PWA',
                ...data
            });
        }

        // Can also send to WordPress admin-ajax.php for logging
        // (Optional implementation)
    }

    /**
     * Public API (for debugging)
     */
    window.NM_PWA = {
        showBanner: showBanner,
        hideBanner: hideBanner,
        resetTracking: function () {
            localStorage.removeItem(STORAGE_KEY);
            console.log('NM PWA: Tracking data reset');
        },
        getTracking: function () {
            return tracking;
        }
    };

    // Initialize on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();
