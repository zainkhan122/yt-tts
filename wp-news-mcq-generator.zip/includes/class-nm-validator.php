<?php

/**
 * Input Validator
 * Reusable validation methods for all user inputs
 *
 * @package WP_News_MCQ_Generator
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class NM_Validator {


	/**
	 * Validate month format (YYYY-MM or 'all')
	 *
	 * @param string $month The month string to validate
	 * @return array ['valid' => bool, 'message' => string]
	 */
	public static function validate_month( $month ) {
		if ( $month === 'all' || $month === '' ) {
			return array(
				'valid'   => true,
				'message' => '',
			);
		}

		if ( ! preg_match( '/^\d{4}-\d{2}$/', $month ) ) {
			return array(
				'valid'   => false,
				'message' => 'Invalid month format. Expected YYYY-MM (e.g., 2025-01).',
			);
		}

		// Validate actual date
		list($year, $month_num) = explode( '-', $month );
		$year                   = (int) $year;
		$month_num              = (int) $month_num;

		if ( $year < 2020 || $year > 2100 ) {
			return array(
				'valid'   => false,
				'message' => 'Year must be between 2020 and 2100.',
			);
		}

		if ( $month_num < 1 || $month_num > 12 ) {
			return array(
				'valid'   => false,
				'message' => 'Month must be between 01 and 12.',
			);
		}

		return array(
			'valid'   => true,
			'message' => '',
		);
	}

	/**
	 * Validate topic slug
	 *
	 * @param string $slug The topic slug
	 * @return array ['valid' => bool, 'message' => string]
	 */
	public static function validate_topic_slug( $slug ) {
		if ( empty( $slug ) ) {
			return array(
				'valid'   => true,
				'message' => '',
			); // Empty is allowed (means all topics)
		}

		// Check if term exists
		$term = get_term_by( 'slug', $slug, 'topic' );

		if ( ! $term || is_wp_error( $term ) ) {
			return array(
				'valid'   => false,
				'message' => 'Topic "' . esc_html( $slug ) . '" does not exist.',
			);
		}

		return array(
			'valid'   => true,
			'message' => '',
			'term'    => $term,
		);
	}

	/**
	 * Validate MCQ count parameter
	 *
	 * @param mixed $count The count to validate
	 * @param int   $min Minimum allowed (default 1)
	 * @param int   $max Maximum allowed (default 50)
	 * @return array ['valid' => bool, 'message' => string, 'value' => int]
	 */
	public static function validate_count( $count, $min = 1, $max = 50 ) {
		$count = absint( $count );

		if ( $count < $min ) {
			return array(
				'valid'   => false,
				'message' => 'Count must be at least ' . $min . '.',
				'value'   => $min,
			);
		}

		if ( $count > $max ) {
			return array(
				'valid'   => false,
				'message' => 'Count cannot exceed ' . $max . '. Use pagination for more results.',
				'value'   => $max,
			);
		}

		return array(
			'valid'   => true,
			'message' => '',
			'value'   => $count,
		);
	}

	/**
	 * Validate email address
	 *
	 * @param string $email Email to validate
	 * @return array ['valid' => bool, 'message' => string]
	 */
	public static function validate_email( $email ) {
		$email = sanitize_email( $email );

		if ( empty( $email ) ) {
			return array(
				'valid'   => false,
				'message' => 'Email address is required.',
			);
		}

		if ( ! is_email( $email ) ) {
			return array(
				'valid'   => false,
				'message' => 'Invalid email format.',
			);
		}

		// Check if email already exists
		if ( email_exists( $email ) ) {
			return array(
				'valid'   => false,
				'message' => 'This email is already registered.',
			);
		}

		return array(
			'valid'   => true,
			'message' => '',
		);
	}

	/**
	 * Validate username
	 *
	 * @param string $username Username to validate
	 * @return array ['valid' => bool, 'message' => string]
	 */
	public static function validate_username( $username ) {
		$username = sanitize_user( $username );

		if ( empty( $username ) ) {
			return array(
				'valid'   => false,
				'message' => 'Username is required.',
			);
		}

		if ( strlen( $username ) < 3 ) {
			return array(
				'valid'   => false,
				'message' => 'Username must be at least 3 characters.',
			);
		}

		if ( ! preg_match( '/^[a-zA-Z0-9_-]+$/', $username ) ) {
			return array(
				'valid'   => false,
				'message' => 'Username can only contain letters, numbers, hyphens, and underscores.',
			);
		}

		if ( username_exists( $username ) ) {
			return array(
				'valid'   => false,
				'message' => 'This username is already taken.',
			);
		}

		return array(
			'valid'   => true,
			'message' => '',
		);
	}

	/**
	 * Validate post ID
	 *
	 * @param mixed  $post_id Post ID to validate
	 * @param string $post_type Expected post type (optional)
	 * @return array ['valid' => bool, 'message' => string, 'post' => WP_Post|null]
	 */
	public static function validate_post_id( $post_id, $post_type = '' ) {
		$post_id = absint( $post_id );

		if ( $post_id === 0 ) {
			return array(
				'valid'   => false,
				'message' => 'Invalid post ID.',
				'post'    => null,
			);
		}

		$post = get_post( $post_id );

		if ( ! $post ) {
			return array(
				'valid'   => false,
				'message' => 'Post not found.',
				'post'    => null,
			);
		}

		if ( ! empty( $post_type ) && $post->post_type !== $post_type ) {
			return array(
				'valid'   => false,
				'message' => 'Post is not of type "' . $post_type . '".',
				'post'    => null,
			);
		}

		if ( $post->post_status !== 'publish' ) {
			return array(
				'valid'   => false,
				'message' => 'This post is not published.',
				'post'    => null,
			);
		}

		return array(
			'valid'   => true,
			'message' => '',
			'post'    => $post,
		);
	}

	/**
	 * Sanitize and validate multiple values at once
	 *
	 * @param array $data Array of field => value pairs
	 * @param array $rules Array of field => validation_method pairs
	 * @return array ['valid' => bool, 'errors' => array, 'data' => array]
	 */
	public static function validate_multiple( $data, $rules ) {
		$errors    = array();
		$validated = array();

		foreach ( $rules as $field => $rule ) {
			$value = $data[ $field ] ?? null;

			// Call the validation method
			if ( method_exists( self::class, $rule ) ) {
				$result = self::$rule( $value );

				if ( ! $result['valid'] ) {
					$errors[ $field ] = $result['message'];
				} else {
					$validated[ $field ] = $result['value'] ?? $value;
				}
			}
		}

		return array(
			'valid'  => empty( $errors ),
			'errors' => $errors,
			'data'   => $validated,
		);
	}

	/**
	 * Validate MCQ content for length constraints and structure.
	 *
	 * Enforces server-side validation of character limits to ensure
	 * AI-generated content doesn't exceed maximum lengths.
	 *
	 * @param array $mcq_data MCQ data with 'question', 'options', 'answer'
	 * @return array ['valid' => bool, 'errors' => array, 'warnings' => array]
	 *
	 * @MODIFIED: Added in v27 to enforce conciseness requirements
	 */
	public static function validate_mcq_content( $mcq_data ) {
		$errors   = array();
		$warnings = array();

		// --- 1. Required Fields Check ---
		if ( empty( $mcq_data['question'] ) ) {
			$errors[] = 'Question is required.';
		}

		if ( empty( $mcq_data['options'] ) || ! is_array( $mcq_data['options'] ) ) {
			$errors[] = 'Options must be a valid array.';
		}

		if ( empty( $mcq_data['answer'] ) ) {
			$errors[] = 'Answer is required.';
		}

		// --- 2. Question Length Validation ---
		if ( ! empty( $mcq_data['question'] ) ) {
			$question_length     = mb_strlen( $mcq_data['question'], 'UTF-8' );
			$max_question_length = 140;

			if ( $question_length > $max_question_length ) {
				$errors[] = sprintf(
					'Question exceeds %d characters (found %d chars). Question: "%s"',
					$max_question_length,
					$question_length,
					mb_substr( $mcq_data['question'], 0, 80 ) . '...'
				);
			} elseif ( $question_length > 120 ) {
				$warnings[] = sprintf(
					'Question is approaching limit (%d/%d chars).',
					$question_length,
					$max_question_length
				);
			}
		}

		// --- 3. Options Structure & Length Validation ---
		if ( is_array( $mcq_data['options'] ) ) {
			$required_keys = array( 'A', 'B', 'C', 'D' );
			$found_keys    = array_keys( $mcq_data['options'] );

			// Check if all required option keys exist
			$missing_keys = array_diff( $required_keys, $found_keys );
			if ( ! empty( $missing_keys ) ) {
				$errors[] = 'Missing option keys: ' . implode( ', ', $missing_keys );
			}

			// Validate each option length
			$max_option_length = 50;
			foreach ( $mcq_data['options'] as $key => $option ) {
				if ( empty( $option ) ) {
					$errors[] = "Option {$key} is empty.";
					continue;
				}

				$option_length = mb_strlen( $option, 'UTF-8' );

				if ( $option_length > $max_option_length ) {
					$errors[] = sprintf(
						'Option %s exceeds %d characters (found %d chars). Text: "%s"',
						$key,
						$max_option_length,
						$option_length,
						mb_substr( $option, 0, 40 ) . '...'
					);
				} elseif ( $option_length > 40 ) {
					$warnings[] = sprintf(
						'Option %s is approaching limit (%d/%d chars).',
						$key,
						$option_length,
						$max_option_length
					);
				}
			}
		}

		// --- 4. Answer Validation ---
		if ( ! empty( $mcq_data['answer'] ) && is_array( $mcq_data['options'] ) ) {
			$answer = strtoupper( $mcq_data['answer'] );
			if ( ! in_array( $answer, array( 'A', 'B', 'C', 'D' ) ) ) {
				$errors[] = 'Answer must be A, B, C, or D.';
			} elseif ( ! array_key_exists( $answer, $mcq_data['options'] ) ) {
				$errors[] = "Answer '{$answer}' does not exist in options.";
			}
		}

		return array(
			'valid'    => empty( $errors ),
			'errors'   => $errors,
			'warnings' => $warnings,
		);
	}
}
