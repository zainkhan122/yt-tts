package com.snsaver.app
import android.app.Application
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject
@HiltAndroidApp class SnsSaverApp:Application(),Configuration.Provider{
 @Inject lateinit var factory:HiltWorkerFactory
 override val workManagerConfiguration get()=Configuration.Builder().setWorkerFactory(factory).build()
}
