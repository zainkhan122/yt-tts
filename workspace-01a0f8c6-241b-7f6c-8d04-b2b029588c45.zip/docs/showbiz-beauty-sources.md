# WPA Source Research — Showbiz (PK/IN) + Mehndi/Nails/Hair
Verified 2026-08-29: feed fetched live, freshness = date of newest feed item, WAF tested with browser UA.

## Showbiz — Pakistan (all WordPress, verified working)

| Site | Feed URL | Freshness | Content | Notes |
|---|---|---|---|---|
| reviewit.pk | https://reviewit.pk/feed/ | today | Drama reviews, ratings, celebs | Already running (baseline) |
| pakgossip.com | https://www.pakgossip.com/feed/ | 20 Aug 2026 | Viral celebrity gossip, drama news | WP 7.1; closest match to reviewit |
| somethinghaute.com | https://www.somethinghaute.com/feed/ | 29 Aug 2026 | Interviews, dramas, films, lifestyle | WP 7.1; premium editorial |
| pakdramacentral.com | https://pakdramacentral.com/feed/ | 28 Aug 2026 | Drama reviews + actor biographies | WP 7.0; some Urdu content |

## Showbiz — India (verified working)

| Site | Feed URL | Freshness | Content | Notes |
|---|---|---|---|---|
| pinkvilla.com | https://www.pinkvilla.com/rss.xml | today | Bollywood gossip, fashion, TV | 49 items per pull — highest volume; custom feed (no per-item categories) |
| bollywoodbubble.com | https://www.bollywoodbubble.com/feed/ | today | Bollywood, TV, South | Categories in feed: Entertainment/Bollywood/TV/South |
| filmfare.com | https://www.filmfare.com/feeds/feeds.xml | today | News, reviews, celeb lifestyle | Magazine-grade |
| koimoi.com | https://www.koimoi.com/feed/ | today | News + box office | WP; ~60% box-office items — keyword EXCLUDE "box office" if unwanted |
| missfilmy.com | https://missfilmy.com/feed | today | Bollywood news | Small site, 6 items/feed — backup only |

## Mehndi / Nails / Hair (verified working)

| Site | Feed URL | Freshness | Content | Notes |
|---|---|---|---|---|
| stylesatlife.com | https://stylesatlife.com/feed/ | 20 Aug 2026 | Mehndi designs, hairstyles, nail art, hair care | WP 6.8; BEST all-rounder for the niche |
| helloswanky.com | https://www.helloswanky.com/blogs/mehndi-design.atom | seasonal (Dec 2025) | Pure mehndi designs | Shopify Atom (stringnthread-style), 30 entries; bursts around Eid/wedding season |
| simplemehandidesigns.com | https://simplemehandidesigns.com/feed/ | 10 Jul 2026 | Pure bridal/mehndi designs | WP; seasonal |
| stylecraze.com | https://www.stylecraze.com/feed/ | feed stale (Mar 2026) | Huge: mehndi/nails/hair | Feed lags; use Multi-page campaign on /articles/mehandi-designs/, /articles/nail-art/, /articles/hair/ listing pages instead |
| stringnthread.com | https://www.stringnthread.com/blogs/news.atom | 23 Jun 2026 | Fashion + occasional mehndi articles | Already known (fashion list) — overlaps both niches |

## Dead ends (verified — do NOT create campaigns)

- **WAF/Cloudflare 403**: bollywoodlife.com, fashionlady.in, bebeautiful.in, beautybook.nykaa.com, dnaindia.com, indianexpress.com, news18.com
- **Stale/dead feeds**: pakium.pk (frozen Apr 2021), stylesgap.com (Apr 2026), hipinpk.com (unreachable), businessofcinema.com (Jul 2026, borderline)
- **No feed / feed disabled**: showbizpk.com, urdughar.com, missmalini.com, zoomtventertainment.com, k4fashion.com (feed returns HTML), weddingbazaar.com, corallista.com

## Suggested WPA setup

1. One **Feed campaign** per site (original-content mode, existing strip regex kit).
2. Starter set: pakgossip + somethinghaute (PK) · pinkvilla + bollywoodbubble (IN) · stylesatlife (beauty).
3. koimoi: add keyword exclude `box office` unless numbers posts are wanted.
4. helloswanky + simplemehandidesigns: schedule 3–7 days; mehndi is seasonal (Eid + Oct–Mar wedding season) — expect quiet months, not dead feeds.
5. Dedupe is automatic (WPA permanent URL cache).

## Round 2 (deep search) — MORE Mehndi/Nails/Hair, verified 2026-08-29

### New verified additions

| Site | Feed URL | Freshness | Content | Notes |
|---|---|---|---|---|
| thenailsnation.com | https://thenailsnation.com/blog/feed | Jun 2026 | Nail design ideas + tutorials | WP; pure nail niche |
| hennasooq.com | https://hennasooq.com/blogs/henna-101.atom | Jul 2026 | Henna hair dye + Ayurvedic hair care + mehndi | Shopify Atom; best hair+mehndi overlap for PK/IN |
| naio-nails.com | https://naio-nails.com/blogs/nail-art-guides.atom | Jul 2026 | Pro nail tutorials (gel/acrylic) | 27 entries; rare UK-regulatory posts |
| ehmkaynails.blogspot.com | https://ehmkaynails.blogspot.com/feeds/posts/default | Aug 2026 | Personal nail art blog | Very active, low volume |
| renaissancehenna.com | https://renaissancehenna.com/feed | Sep 2025 | Natural henna hair coloring | Secondary — slowing |
| twistmepretty.com | https://www.twistmepretty.com/feed | Feb 2026 | Hairstyles, DIY beauty | Secondary — US-flavored, slowed |

### Verified dead/ghost this round (do not use)

- Frozen/abandoned: sonailicious.com (Feb 2022), createdbyconnie.co.uk (2022), newmehendidesigner.wordpress.com (2019), mehndiartistdelhi.blogspot.com (Dec 2024), hennaart.ca (~1 item/yr), hennamendhi.tumblr (rate-limited)
- WAF 403: femina.in, healthshots.com, thehealthsite.com
- No feed: vedix.com, wedmegood.com, vogue.in, homeofnailart.com, thelittlecanvas.com, 25sweetpeas.com, mindbodyhenna.com, k4fashion.com (HTML for all feed paths)
- Empty feed: glazmart.com (0 items) · Server errors: bhaavyakapur.com (500), jademaxx.com (429/empty) · Unreachable: shaadisaga.com, traya.in, makeupandbeauty.com

### Niche volume equation

stylesatlife (anchor) + hennasooq (hair/henna) + thenailsnation + naio (nails) + helloswanky & simplemehndi (seasonal bursts). Bigger volume = stylecraze Multi-page on /articles/mehandi-designs/, /articles/nail-art/, /articles/hair/.

## Round 3 — 2 NEW validated mehndi sites (2026-08-29, pipeline-reproduced)

### destinationweddingsindia.com (Site 1)
- FEED: https://destinationweddingsindia.com/category/mehndi-bridal-styling/feed/ (7 items, 100% mehndi/bridal, fresh Jul 21 2026, WP 7.1)
- Pipeline validated on front-hand-mehndi-design/: container class post-content, 126 imgs (quoted src), 109 survive strip_tags, srcset stripped by WPA default
- WPA: original-content mode, custom class post-content; CSS strip: dwiac-twrap, link_wrap, wp-block-spacer; regex EMPTY; standard allowed-tags list
- Images mostly .avif (WP 6.5+ ok)

### shaadidukaan.com (Site 2)
- FEED: https://www.shaadidukaan.com/vogue/category/mehendi-design/feed/ (100% mehndi, fresh Aug 6, site updates daily; WP 7.0.2 under /vogue/)
- Feed carries FULL content (content:encoded) → feed-content mode, no page extraction; fallback custom class entry-content
- Regex kit (SAFE, [^\n]*-bounded, no .*): Image via: / Source via: / Credit via: / Photo Courtesy: / Picture Courtesy: / Picture via: / Shared By: / Top vendors are getting booked / Book yours Now! / Book Now: / Also Checkout:? / More Checkout:?-? / If you.{0,3}re also looking for / <img[^>]*CTA[^>]*>
- Validated via fetch_page egress (sandbox curl cannot route to this host — if user's host also fails, drop this source)

### Rejected in round 3 (evidence): weddingbazaar (JS galleries, no container), weddingz.in + wedmegood (no feeds), k4fashion (dormant Jan 2025), mannoaesthetic (AI/Pinterest farm), thebridalbox (frozen Oct 2025), tipsandbeauty (0 mehndi), shaadiwish (unreachable), thepinkstory (feed 404), weddingforward (mehndi hub = 404 page), stylesgap (fashion feed, 1 mehndi item, stale)
