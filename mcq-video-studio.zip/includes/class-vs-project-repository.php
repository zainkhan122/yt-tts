<?php

/**
 * Project Repository
 *
 * Manages video studio projects in the database.
 * Replaces localStorage-based project storage.
 *
 * @package    MCQ_Video_Studio
 * @subpackage Includes
 * @since      1.2.0
 */

if (! defined('ABSPATH')) {
    exit;
}

/**
 * Class VS_Project_Repository
 *
 * CRUD operations for video projects and questions.
 *
 * @since 1.2.0
 */
class VS_Project_Repository
{

    const TABLE_PROJECTS  = 'vs_projects';
    const TABLE_QUESTIONS = 'vs_project_questions';

    private static $instance = null;

    /**
     * Singleton init
     */
    public static function init()
    {
        if (null === self::$instance) {
            self::$instance = new self();
            self::ensure_table_exists();
        }
        return self::$instance;
    }

    private static function ensure_table_exists()
    {
        global $wpdb;
        $projects_table = self::get_projects_table();

        if ($wpdb->get_var("SHOW TABLES LIKE '{$projects_table}'") !== $projects_table) {
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
            $tables = VS_Schema::get_tables_to_create();
            if (isset($tables['vs_projects'])) {
                dbDelta($tables['vs_projects']);
            }
            if (isset($tables['vs_project_questions'])) {
                dbDelta($tables['vs_project_questions']);
            }
        }
    }

    /**
     * Get projects table name
     */
    public static function get_projects_table()
    {
        global $wpdb;
        return $wpdb->prefix . self::TABLE_PROJECTS;
    }

    /**
     * Get questions table name
     */
    public static function get_questions_table()
    {
        global $wpdb;
        return $wpdb->prefix . self::TABLE_QUESTIONS;
    }

    /**
     * Create database tables
     * Called on plugin activation and version upgrade
     */
    public static function create_tables()
    {
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $tables = VS_Schema::get_tables_to_create();
        if (isset($tables['vs_projects'])) {
            dbDelta($tables['vs_projects']);
        }
        if (isset($tables['vs_project_questions'])) {
            dbDelta($tables['vs_project_questions']);
        }
    }

    /**
     * Create a new project
     *
     * @param array $args Project arguments
     * @return int|WP_Error Project ID on success
     */
    public function create_project($args)
    {
        global $wpdb;

        $defaults = array(
            'user_id'  => get_current_user_id(),
            'title'    => '',
            'template' => 'modern',
            'settings' => array(),
            'status'   => VS_Project_Status::DRAFT,
        );

        $data = wp_parse_args($args, $defaults);

        if (empty($data['user_id'])) {
            return new WP_Error('invalid_user', 'User ID is required.');
        }

        if (!VS_Project_Status::is_valid($data['status'])) {
            $data['status'] = VS_Project_Status::DRAFT;
        }

        $inserted = $wpdb->insert(
            self::get_projects_table(),
            array(
                'user_id'  => absint($data['user_id']),
                'title'    => sanitize_text_field($data['title']),
                'template' => sanitize_text_field($data['template']),
                'settings' => wp_json_encode($data['settings']),
                'status'   => $data['status'],
            ),
            array('%d', '%s', '%s', '%s', '%s')
        );

        if (!$inserted) {
            return new WP_Error('db_insert_error', 'Could not create project.');
        }

        return $wpdb->insert_id;
    }

    /**
     * Add questions to a project
     *
     * @param int   $project_id Project ID
     * @param array $questions  Array of question objects
     * @return int Number of questions added
     */
    public function add_questions($project_id, $questions)
    {
        global $wpdb;
        $count = 0;

        foreach ($questions as $index => $q) {
            $options = isset($q['options']) ? $q['options'] : array();
            if (is_array($options)) {
                $options = wp_json_encode($options);
            }

            $inserted = $wpdb->insert(
                self::get_questions_table(),
                array(
                    'project_id'    => absint($project_id),
                    'question_text' => sanitize_textarea_field($q['question'] ?? ''),
                    'options'       => $options,
                    'correct_index' => absint($q['correct'] ?? $q['correct_index'] ?? 0),
                    'background'    => sanitize_text_field($q['background'] ?? 'gradient'),
                    'sort_order'    => absint($index),
                ),
                array('%d', '%s', '%s', '%d', '%s', '%d')
            );

            if ($inserted) {
                $count++;
            }
        }

        return $count;
    }

    /**
     * Get project by ID
     *
     * @param int $project_id Project ID
     * @return array|null Project data with questions
     */
    public function get_project($project_id)
    {
        global $wpdb;

        $project = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM " . self::get_projects_table() . " WHERE id = %d",
                $project_id
            ),
            ARRAY_A
        );

        if (!$project) {
            return null;
        }

        $project['settings'] = json_decode($project['settings'], true) ?: array();

        $project['questions'] = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM " . self::get_questions_table() . "
                WHERE project_id = %d ORDER BY sort_order ASC",
                $project_id
            ),
            ARRAY_A
        );

        foreach ($project['questions'] as &$q) {
            $q['options'] = json_decode($q['options'], true) ?: array();
        }

        return $project;
    }

    /**
     * Get projects by user
     *
     * @param int $user_id User ID
     * @param int $limit   Limit
     * @return array Projects list
     */
    public function get_user_projects($user_id, $limit = 20)
    {
        global $wpdb;

        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, title, template, status, video_url, created_at, updated_at
                FROM " . self::get_projects_table() . "
                WHERE user_id = %d
                ORDER BY updated_at DESC
                LIMIT %d",
                $user_id,
                $limit
            ),
            ARRAY_A
        );
    }

    /**
     * Update project status with validation
     *
     * @param int    $project_id Project ID
     * @param string $status     New status
     * @param array  $extras     Extra fields to update
     * @return int|false Rows affected
     */
    public function update_status($project_id, $status, $extras = array())
    {
        global $wpdb;

        if (!VS_Project_Status::is_valid($status)) {
            return false;
        }

        if (!empty($project_id) && is_numeric($project_id)) {
            $existing = $wpdb->get_row($wpdb->prepare(
                "SELECT status FROM " . self::get_projects_table() . " WHERE id = %d",
                absint($project_id)
            ), ARRAY_A);
            if ($existing && !VS_Project_Status::can_transition($existing['status'], $status)) {
                return false;
            }
        }

        $data = array_merge(
            array('status' => $status),
            $extras
        );

        return $wpdb->update(
            self::get_projects_table(),
            $data,
            array('id' => $project_id)
        );
    }

    /**
     * Update project video URL after render
     *
     * @param int    $project_id Project ID
     * @param string $video_url  Video URL
     * @return int|false
     */
    public function update_video_url($project_id, $video_url)
    {
        global $wpdb;

        return $wpdb->update(
            self::get_projects_table(),
            array('video_url' => $video_url),
            array('id' => $project_id)
        );
    }

    /**
     * Update project
     *
     * @param int   $project_id Project ID
     * @param array $data       Data to update
     * @return int|false Rows affected
     */
    public function update_project($project_id, $data)
    {
        global $wpdb;

        if (isset($data['settings']) && is_array($data['settings'])) {
            $data['settings'] = wp_json_encode($data['settings']);
        }

        return $wpdb->update(
            self::get_projects_table(),
            $data,
            array('id' => $project_id)
        );
    }

    /**
     * Delete project and questions
     *
     * @param int $project_id Project ID
     * @return int|false Rows affected
     */
    public function delete_project($project_id)
    {
        global $wpdb;

        $wpdb->delete(
            self::get_questions_table(),
            array('project_id' => $project_id),
            array('%d')
        );

        return $wpdb->delete(
            self::get_projects_table(),
            array('id' => $project_id),
            array('%d')
        );
    }

    /**
     * Save project from frontend (create or update)
     *
     * @param array $data Project data from JS
     * @return int|WP_Error Project ID
     */
    public function save_from_frontend($data)
    {
        $project_id = isset($data['project_id']) ? absint($data['project_id']) : 0;
        $questions = isset($data['questions']) ? $data['questions'] : array();

        if ($project_id > 0) {
            $this->update_project($project_id, array(
                'title'    => sanitize_text_field($data['title'] ?? ''),
                'template' => sanitize_text_field($data['template'] ?? 'modern'),
                'settings' => $data['settings'] ?? array(),
            ));

            global $wpdb;
            $wpdb->delete(
                self::get_questions_table(),
                array('project_id' => $project_id),
                array('%d')
            );
            $this->add_questions($project_id, $questions);
        } else {
            $project_id = $this->create_project(array(
                'title'    => sanitize_text_field($data['title'] ?? ''),
                'template' => sanitize_text_field($data['template'] ?? 'modern'),
                'settings' => $data['settings'] ?? array(),
            ));

            if (is_wp_error($project_id)) {
                return $project_id;
            }

            $this->add_questions($project_id, $questions);
        }

        return $project_id;
    }

    /**
     * Link a job to this project
     *
     * @param int    $project_id Project ID
     * @param string $job_id     Job ID
     * @return bool
     */
    public function link_job($project_id, $job_id)
    {
        global $wpdb;
        return (bool) $wpdb->update(
            VS_Job_Repository::get_table_name(),
            array('project_id' => absint($project_id)),
            array('job_id' => $job_id),
            array('%d'),
            array('%s')
        );
    }
}