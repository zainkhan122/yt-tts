/**
 * NM Text Effects Library
 * Professional text rendering with stroke, shadow, and glow effects
 * 
 * @package WP_News_MCQ_Generator
 * @version 1.0.0
 * @author Video Studio Enhancement
 */

(function (window) {
    'use strict';

    const MCQVS_TextEffects = {

        /**
         * Draw text with professional effects
         * 
         * @param {CanvasRenderingContext2D} ctx Canvas context
         * @param {string} text Text to render
         * @param {number} x X position
         * @param {number} y Y position
         * @param {Object} options Style options
         */
        drawStyledText: function (ctx, text, x, y, options = {}) {
            if (!ctx || !text) return;

            const defaults = {
                fontSize: 32,
                fontFamily: 'Inter, Roboto, sans-serif',
                fontWeight: 'bold',
                fill: '#FFFFFF',
                stroke: null,
                shadow: null,
                glow: null,
                shadows: null, // Array for 3D effect
                align: 'center',
                baseline: 'middle',
                maxWidth: null,
                lineHeight: 1.2, // Multiplier of fontSize
                glitchOffset: null // For glitch effect
            };

            const opts = Object.assign({}, defaults, options);

            // @FIX 2026-01-07: Sanitize maxWidth. Explicit 'null' can cause 0-width rendering in some browsers.
            if (opts.maxWidth === null) {
                opts.maxWidth = undefined;
            }

            // Set font
            ctx.font = `${opts.fontWeight} ${opts.fontSize}px ${opts.fontFamily}`;
            ctx.textAlign = opts.align;
            ctx.textBaseline = opts.baseline;

            // Handle Text Wrapping
            const lines = [];
            if (opts.maxWidth && ctx.measureText(text).width > opts.maxWidth) {
                const words = text.toString().split(' ');
                let currentLine = words[0];

                for (let i = 1; i < words.length; i++) {
                    const word = words[i];
                    const width = ctx.measureText(currentLine + " " + word).width;
                    if (width < opts.maxWidth) {
                        currentLine += " " + word;
                    } else {
                        lines.push(currentLine);
                        currentLine = word;
                    }
                }
                lines.push(currentLine); // Push last line
            } else {
                lines.push(text);
            }

            // Calculate total height to center vertically if needed (optional optimization)
            // For now, we assume 'y' is the center/start of the text block depending on baseline
            // If baseline is middle, we offset to center the whole block
            const lineHeightPx = opts.fontSize * opts.lineHeight;
            let startY = y;

            if (opts.baseline === 'middle' && lines.length > 1) {
                const totalHeight = (lines.length - 1) * lineHeightPx;
                startY = y - totalHeight / 2;
            }

            // Render Each Line
            lines.forEach((line, index) => {
                const lineY = startY + (index * lineHeightPx);

                // GLOBAL SAVE - Protects the canvas state before we start messing with shadows
                ctx.save();

                // === LAYER 1: Glow (outermost) ===
                if (opts.glow) {
                    ctx.save();
                    ctx.shadowBlur = opts.glow.blur || 20;
                    ctx.shadowColor = opts.glow.color || '#FFFFFF';
                    ctx.fillStyle = opts.glow.color || '#FFFFFF';
                    ctx.globalAlpha = 0.8;
                    ctx.fillText(line, x, lineY);
                    ctx.restore();
                }

                // === LAYER 2: Multiple Shadows (for 3D effect) ===
                if (opts.shadows && Array.isArray(opts.shadows)) {
                    opts.shadows.forEach(shadow => {
                        ctx.save();
                        ctx.shadowBlur = shadow.blur || 0;
                        ctx.shadowColor = shadow.color || '#000000';
                        ctx.shadowOffsetX = shadow.offsetX || 0;
                        ctx.shadowOffsetY = shadow.offsetY || 0;
                        ctx.fillStyle = shadow.color || '#000000';
                        ctx.fillText(line, x, lineY);
                        ctx.restore();
                    });
                }
                // === LAYER 2 (alternative): Single Shadow ===
                else if (opts.shadow) {
                    ctx.save();
                    ctx.shadowBlur = opts.shadow.blur || 5;
                    ctx.shadowColor = opts.shadow.color || 'rgba(0,0,0,0.5)';
                    ctx.shadowOffsetX = opts.shadow.offsetX || 2;
                    ctx.shadowOffsetY = opts.shadow.offsetY || 2;
                    ctx.fillStyle = opts.fill; // Draw shadow using fill color basis? usually shadowColor handles it
                    // Actually, to cast a shadow, you draw the text. The shadow props apply to it.
                    // But we want JUST the shadow here if we are layering? 
                    // No, standard canvas shadow draws both. 
                    // FIX: Draw simple text with shadow properties active.
                    ctx.fillText(line, x, lineY);
                    ctx.restore();
                }

                // === LAYER 3: Stroke (outline) ===
                if (opts.stroke) {
                    ctx.save(); // Isolate stroke settings
                    ctx.shadowBlur = 0; // Ensure no shadow on stroke unless desired
                    ctx.strokeStyle = opts.stroke.color || '#000000';
                    ctx.lineWidth = opts.stroke.width || 2;
                    ctx.lineJoin = 'round';
                    ctx.miterLimit = 2;
                    ctx.strokeText(line, x, lineY);
                    ctx.restore();
                }

                // === LAYER 4: Fill (main text) ===
                ctx.save(); // Isolate fill settings
                ctx.shadowBlur = 0; // Disable shadow for clean fill on top
                ctx.shadowColor = 'transparent';

                // Handle gradient fills
                if (typeof opts.fill === 'string' && opts.fill.startsWith('linear-gradient')) {
                    const gradient = this.parseGradient(ctx, opts.fill, x, lineY, opts.fontSize);
                    ctx.fillStyle = gradient;
                } else {
                    ctx.fillStyle = opts.fill;
                }

                // === Glitch Effect ===
                if (opts.glitchOffset) {
                    // Red channel
                    ctx.save();
                    ctx.globalCompositeOperation = 'screen';
                    ctx.fillStyle = 'rgba(255, 0, 0, 0.5)';
                    ctx.fillText(line, x + opts.glitchOffset.r, lineY);
                    ctx.restore();

                    // Green channel (main)
                    ctx.fillText(line, x + opts.glitchOffset.g, lineY);

                    // Blue channel
                    ctx.save();
                    ctx.globalCompositeOperation = 'screen';
                    ctx.fillStyle = 'rgba(0, 0, 255, 0.5)';
                    ctx.fillText(line, x + opts.glitchOffset.b, lineY);
                    ctx.restore();
                } else {
                    // Normal fill
                    ctx.fillText(line, x, lineY);
                }

                ctx.restore(); // End Fill Isolation

                // GLOBAL RESTORE - Reset everything for the next line/element
                ctx.restore();
            });
        },

        /**
         * Parse CSS linear-gradient to Canvas gradient
         * Simple parser for basic gradients
         */
        parseGradient: function (ctx, gradientStr, x, y, size) {
            // Extract colors from "linear-gradient(135deg, #FFD700, #FFA500)"
            const matches = gradientStr.match(/#[0-9A-Fa-f]{6}/g);
            if (!matches || matches.length < 2) {
                return matches ? matches[0] : '#FFFFFF';
            }

            // Create linear gradient (vertical for text)
            const gradient = ctx.createLinearGradient(x, y - size / 2, x, y + size / 2);
            gradient.addColorStop(0, matches[0]);
            gradient.addColorStop(1, matches[1]);
            return gradient;
        },

        /**
         * 10 Professional Text Effect Presets
         */
        presets: {

            // 1. Classic Bold (Default Enhanced)
            classicBold: {
                question: {
                    fontSize: 48,
                    fontWeight: '900',
                    fill: '#FFFFFF',
                    stroke: { color: '#000000', width: 4 },
                    shadow: { blur: 8, color: 'rgba(0,0,0,0.6)', offsetX: 2, offsetY: 2 }
                },
                option: {
                    fontSize: 36,
                    fontWeight: 'bold',
                    fill: '#FFFFFF',
                    stroke: { color: '#1a1a1a', width: 3 },
                    shadow: { blur: 5, color: 'rgba(0,0,0,0.5)', offsetX: 2, offsetY: 2 }
                },
                timer: {
                    fontSize: 64,
                    fontWeight: '900',
                    fill: '#FF3B30',
                    stroke: { color: '#FFFFFF', width: 5 },
                    shadow: { blur: 10, color: 'rgba(0,0,0,0.7)', offsetX: 3, offsetY: 3 }
                },
                correct: {
                    fontSize: 42,
                    fontWeight: 'bold',
                    fill: '#34C759',
                    stroke: { color: '#FFFFFF', width: 4 },
                    shadow: { blur: 8, color: 'rgba(0,0,0,0.6)', offsetX: 2, offsetY: 2 }
                },
                hook: {
                    fontSize: 52,
                    fontWeight: '900',
                    fill: '#FFFFFF',
                    stroke: { color: '#000000', width: 5 },
                    shadow: { blur: 12, color: 'rgba(0,0,0,0.7)', offsetX: 3, offsetY: 3 }
                }
            },

            // @NEW 2026-08-11: Dark-on-light preset for the QuizWire Brand template.
            // The classicBold preset fills text WHITE (designed for dark glass cards),
            // which made QuizWire's white cards unreadable (white-on-white). This preset
            // uses near-black text with a subtle shadow — matches the Canva brand design
            // (white bg, black text, red accent). "correct" stays dark (white card +
            // green border) — the engine forces colors.text on correct answers anyway.
            quizwireBold: {
                question: {
                    fontSize: 48,
                    fontWeight: '900',
                    fill: '#111111',
                    shadow: { blur: 4, color: 'rgba(0,0,0,0.25)', offsetX: 1, offsetY: 2 }
                },
                option: {
                    fontSize: 36,
                    fontWeight: '700',
                    fill: '#111111',
                    shadow: { blur: 2, color: 'rgba(0,0,0,0.15)', offsetX: 1, offsetY: 1 }
                },
                timer: {
                    fontSize: 64,
                    fontWeight: '900',
                    fill: '#E50914',
                    shadow: { blur: 6, color: 'rgba(0,0,0,0.25)', offsetX: 2, offsetY: 2 }
                },
                correct: {
                    fontSize: 42,
                    fontWeight: '800',
                    fill: '#111111',
                    shadow: { blur: 3, color: 'rgba(0,0,0,0.2)', offsetX: 1, offsetY: 1 }
                },
                hook: {
                    fontSize: 52,
                    fontWeight: '900',
                    fill: '#111111',
                    shadow: { blur: 5, color: 'rgba(0,0,0,0.3)', offsetX: 2, offsetY: 2 }
                }
            },

            // 2. Neon Glow (Viral TikTok Style)
            neonGlow: {
                question: {
                    fontSize: 52,
                    fontWeight: '900',
                    fill: '#FFFFFF',
                    stroke: { color: '#000000', width: 3 },
                    glow: { blur: 30, color: '#00F0FF' },
                    shadow: { blur: 15, color: 'rgba(0,240,255,0.8)', offsetX: 0, offsetY: 0 }
                },
                option: {
                    fontSize: 38,
                    fontWeight: 'bold',
                    fill: '#FFFFFF',
                    stroke: { color: '#000000', width: 2 },
                    glow: { blur: 20, color: '#FF00FF' }
                },
                timer: {
                    fontSize: 72,
                    fontWeight: '900',
                    fill: '#FF0080',
                    stroke: { color: '#FFFFFF', width: 5 },
                    glow: { blur: 40, color: '#FF0080' }
                },
                correct: {
                    fontSize: 42,
                    fontWeight: 'bold',
                    fill: '#FFFFFF', // @FIX: White text for contrast on green box
                    stroke: { color: '#000000', width: 4 }, // Added stroke for readability
                    glow: { blur: 35, color: '#00FF00' },
                    shadow: { blur: 20, color: 'rgba(0,255,0,0.8)', offsetX: 0, offsetY: 0 }
                },
                hook: {
                    fontSize: 56,
                    fontWeight: '900',
                    fill: '#FFD700',
                    stroke: { color: '#000000', width: 4 },
                    glow: { blur: 35, color: '#FFD700' }
                }
            },

            // 3. Gold Luxury (Premium Feel)
            goldLuxury: {
                question: {
                    fontSize: 50,
                    fontWeight: '900',
                    fill: 'linear-gradient(135deg, #FFD700, #FFA500)',
                    stroke: { color: '#8B4513', width: 5 },
                    glow: { blur: 25, color: '#FFD700' },
                    shadow: { blur: 12, color: 'rgba(139,69,19,0.7)', offsetX: 3, offsetY: 3 }
                },
                option: {
                    fontSize: 36,
                    fontWeight: 'bold',
                    fill: '#FFD700',
                    stroke: { color: '#654321', width: 3 },
                    shadow: { blur: 8, color: 'rgba(0,0,0,0.6)', offsetX: 2, offsetY: 2 }
                },
                timer: {
                    fontSize: 68,
                    fontWeight: '900',
                    fill: 'linear-gradient(135deg, #FFD700, #FF8C00)',
                    stroke: { color: '#8B4513', width: 6 },
                    glow: { blur: 30, color: '#FFD700' }
                },
                correct: {
                    fontSize: 42,
                    fontWeight: 'bold',
                    fill: '#FFFFFF', // @FIX: White text for contrast
                    stroke: { color: '#8B4513', width: 4 },
                    glow: { blur: 25, color: '#FFD700' }
                },
                hook: {
                    fontSize: 54,
                    fontWeight: '900',
                    fill: 'linear-gradient(135deg, #FFD700, #FFA500)',
                    stroke: { color: '#8B4513', width: 6 },
                    glow: { blur: 30, color: '#FFD700' }
                }
            },

            // 4. 3D Pop (Depth Effect)
            '3dPop': {
                question: {
                    fontSize: 54,
                    fontWeight: '900',
                    fill: '#FF3B30',
                    stroke: { color: '#000000', width: 4 },
                    shadows: [
                        { blur: 0, color: '#C91F1F', offsetX: 2, offsetY: 2 },
                        { blur: 0, color: '#A01717', offsetX: 4, offsetY: 4 },
                        { blur: 0, color: '#770F0F', offsetX: 6, offsetY: 6 },
                        { blur: 10, color: 'rgba(0,0,0,0.5)', offsetX: 8, offsetY: 8 }
                    ]
                },
                option: {
                    fontSize: 38,
                    fontWeight: 'bold',
                    fill: '#34C759',
                    shadows: [
                        { blur: 0, color: '#28A745', offsetX: 2, offsetY: 2 },
                        { blur: 0, color: '#1E7A34', offsetX: 4, offsetY: 4 },
                        { blur: 8, color: 'rgba(0,0,0,0.4)', offsetX: 6, offsetY: 6 }
                    ]
                },
                timer: {
                    fontSize: 70,
                    fontWeight: '900',
                    fill: '#FF9500',
                    shadows: [
                        { blur: 0, color: '#CC7700', offsetX: 3, offsetY: 3 },
                        { blur: 0, color: '#995500', offsetX: 6, offsetY: 6 },
                        { blur: 12, color: 'rgba(0,0,0,0.6)', offsetX: 9, offsetY: 9 }
                    ]
                },
                correct: {
                    fontSize: 42,
                    fontWeight: 'bold',
                    fill: '#FFFFFF', // @FIX: White text for contrast
                    stroke: { color: '#006400', width: 3 }, // Dark green stroke
                    shadows: [
                        { blur: 0, color: '#004d00', offsetX: 2, offsetY: 2 },
                        { blur: 0, color: '#003300', offsetX: 4, offsetY: 4 }
                    ]
                },
                hook: {
                    fontSize: 56,
                    fontWeight: '900',
                    fill: '#FFFFFF',
                    shadows: [
                        { blur: 0, color: '#CCCCCC', offsetX: 2, offsetY: 2 },
                        { blur: 0, color: '#999999', offsetX: 4, offsetY: 4 },
                        { blur: 0, color: '#666666', offsetX: 6, offsetY: 6 },
                        { blur: 15, color: 'rgba(0,0,0,0.7)', offsetX: 8, offsetY: 8 }
                    ]
                }
            },

            // 5. Minimal Clean (Plain Fallback)
            minimalClean: {
                // @FIX 1.4.9.52 (CRITICAL): minimalClean fills were #FFFFFF (white) but
                //       the minimalist template has a WHITE #FAFAFA background + white
                //       solid cards — question/option/hook text rendered WHITE-ON-WHITE
                //       (invisible) in every pipeline that applies text effects (Studio
                //       preview, browser export, worker). All fills are now dark
                //       (#1A1A1A) to match the template's dark text color.
                question: {
                    fontSize: 48,
                    fontWeight: 'bold',
                    fill: '#1A1A1A',
                    shadow: { blur: 3, color: 'rgba(0,0,0,0.25)', offsetX: 1, offsetY: 1 }
                },
                option: {
                    fontSize: 36,
                    fontWeight: 'normal',
                    fill: '#1A1A1A',
                    shadow: { blur: 2, color: 'rgba(0,0,0,0.18)', offsetX: 1, offsetY: 1 }
                },
                timer: {
                    fontSize: 64,
                    fontWeight: 'bold',
                    fill: '#E53935',
                    shadow: { blur: 4, color: 'rgba(0,0,0,0.25)', offsetX: 1, offsetY: 1 }
                },
                correct: {
                    fontSize: 42,
                    fontWeight: 'bold',
                    fill: '#FFFFFF',
                    shadow: { blur: 3, color: 'rgba(0,0,0,0.3)', offsetX: 1, offsetY: 1 }
                },
                hook: {
                    fontSize: 52,
                    fontWeight: 'bold',
                    fill: '#1A1A1A',
                    shadow: { blur: 4, color: 'rgba(0,0,0,0.3)', offsetX: 2, offsetY: 2 }
                }
            },

            // 6. Comic Bold (Fun & Energetic)
            comicBold: {
                question: {
                    fontSize: 56,
                    fontWeight: '900',
                    fill: '#FFEB3B',
                    stroke: { color: '#000000', width: 6 },
                    shadow: { blur: 0, color: '#000000', offsetX: 5, offsetY: 5 }
                },
                option: {
                    fontSize: 40,
                    fontWeight: '900',
                    fill: '#FFFFFF',
                    stroke: { color: '#000000', width: 5 },
                    shadow: { blur: 0, color: '#000000', offsetX: 4, offsetY: 4 }
                },
                timer: {
                    fontSize: 80,
                    fontWeight: '900',
                    fill: '#FF5722',
                    stroke: { color: '#000000', width: 7 },
                    shadow: { blur: 0, color: '#000000', offsetX: 6, offsetY: 6 }
                },
                correct: {
                    fontSize: 44,
                    fontWeight: '900',
                    fill: '#FFFFFF', // @FIX White
                    stroke: { color: '#000000', width: 5 },
                    shadow: { blur: 0, color: '#000000', offsetX: 4, offsetY: 4 }
                },
                hook: {
                    fontSize: 60,
                    fontWeight: '900',
                    fill: '#FF9800',
                    stroke: { color: '#000000', width: 7 },
                    shadow: { blur: 0, color: '#000000', offsetX: 6, offsetY: 6 }
                }
            },

            // 7. Fire & Ice (Dramatic Contrast)
            fireIce: {
                question: {
                    fontSize: 52,
                    fontWeight: '900',
                    fill: '#FF4500',
                    stroke: { color: '#8B0000', width: 4 },
                    glow: { blur: 35, color: '#FF6347' },
                    shadow: { blur: 20, color: 'rgba(255,69,0,0.8)', offsetX: 0, offsetY: 0 }
                },
                option: {
                    fontSize: 38,
                    fontWeight: 'bold',
                    fill: '#00CED1',
                    stroke: { color: '#006494', width: 3 },
                    glow: { blur: 25, color: '#00CED1' }
                },
                timer: {
                    fontSize: 70,
                    fontWeight: '900',
                    fill: '#FF0000',
                    stroke: { color: '#FFFFFF', width: 5 },
                    glow: { blur: 40, color: '#FF0000' }
                },
                correct: {
                    fontSize: 42,
                    fontWeight: '900',
                    fill: '#FFFFFF', // @FIX White
                    stroke: { color: '#000000', width: 3 },
                    glow: { blur: 40, color: '#00FF00' }
                },
                hook: {
                    fontSize: 56,
                    fontWeight: '900',
                    fill: '#FF4500',
                    stroke: { color: '#8B0000', width: 5 },
                    glow: { blur: 40, color: '#FF6347' }
                }
            },

            // 8. Retro Arcade (80s Nostalgia)
            retroArcade: {
                // @FIX 2026-08-11: Glow blurs were 20-35px — neon washout on dark cards
                //       made the text hard to read. Tightened to 10-16px while keeping the
                //       synthwave neon look; black stroke retained for crisp edges.
                question: {
                    fontSize: 50,
                    fontWeight: '900',
                    fill: '#FF00FF',
                    stroke: { color: '#000000', width: 5 },
                    glow: { blur: 14, color: '#FF00FF' },
                    shadow: { blur: 0, color: 'rgba(255,0,255,0.3)', offsetX: 0, offsetY: 2 }
                },
                option: {
                    fontSize: 36,
                    fontWeight: 'bold',
                    fill: '#00FFFF',
                    stroke: { color: '#000000', width: 4 },
                    glow: { blur: 10, color: '#00FFFF' }
                },
                timer: {
                    fontSize: 68,
                    fontWeight: '900',
                    fill: '#FFFF00',
                    stroke: { color: '#000000', width: 6 },
                    glow: { blur: 16, color: '#FFFF00' }
                },
                correct: {
                    fontSize: 42,
                    fontWeight: 'bold',
                    fill: '#FFFFFF', // @FIX White
                    stroke: { color: '#000000', width: 4 }, // Added stroke
                    glow: { blur: 14, color: '#00FF00' }
                },
                hook: {
                    fontSize: 54,
                    fontWeight: '900',
                    fill: '#FF00FF',
                    stroke: { color: '#000000', width: 6 },
                    glow: { blur: 16, color: '#FF00FF' }
                }
            },

            // 9. Elegant Serif (Sophisticated)
            elegantSerif: {
                question: {
                    fontSize: 46,
                    fontFamily: '"EB Garamond", serif',
                    fontWeight: 'bold',
                    fill: '#F5F5DC',
                    stroke: { color: '#2F4F4F', width: 2 },
                    shadow: { blur: 10, color: 'rgba(47,79,79,0.7)', offsetX: 3, offsetY: 3 }
                },
                option: {
                    fontSize: 34,
                    fontFamily: '"EB Garamond", serif',
                    fontWeight: 'normal',
                    fill: '#FFFFFF',
                    stroke: { color: '#2F4F4F', width: 2 },
                    shadow: { blur: 6, color: 'rgba(0,0,0,0.5)', offsetX: 2, offsetY: 2 }
                },
                timer: {
                    fontSize: 60,
                    fontFamily: '"EB Garamond", serif',
                    fontWeight: 'bold',
                    fill: '#CD853F',
                    stroke: { color: '#2F4F4F', width: 3 },
                    shadow: { blur: 8, color: 'rgba(0,0,0,0.6)', offsetX: 2, offsetY: 2 }
                },
                correct: {
                    fontSize: 40,
                    fontFamily: '"EB Garamond", serif',
                    fontWeight: 'bold',
                    fill: '#FFFFFF', // @FIX White
                    stroke: { color: '#2F4F4F', width: 3 },
                    shadow: { blur: 8, color: 'rgba(0,0,0,0.5)', offsetX: 2, offsetY: 2 }
                },
                hook: {
                    fontSize: 50,
                    fontFamily: '"EB Garamond", serif',
                    fontWeight: 'bold',
                    fill: '#F5F5DC',
                    stroke: { color: '#2F4F4F', width: 3 },
                    shadow: { blur: 12, color: 'rgba(47,79,79,0.7)', offsetX: 3, offsetY: 3 }
                }
            },

            // 10. Glitch Effect (Cyberpunk)
            glitchEffect: {
                question: {
                    fontSize: 52,
                    fontWeight: '900',
                    fill: '#00FF00',
                    stroke: { color: '#000000', width: 3 },
                    glitchOffset: { r: -3, g: 0, b: 3 },
                    glow: { blur: 20, color: '#00FF00' },
                    shadow: { blur: 15, color: 'rgba(0,255,0,0.6)', offsetX: 0, offsetY: 0 }
                },
                option: {
                    fontSize: 38,
                    fontWeight: 'bold',
                    fill: '#FFFFFF',
                    stroke: { color: '#00FF00', width: 2 },
                    glitchOffset: { r: -2, g: 0, b: 2 }
                },
                timer: {
                    fontSize: 70,
                    fontWeight: '900',
                    fill: '#FF0000',
                    glitchOffset: { r: -4, g: 0, b: 4 },
                    glow: { blur: 30, color: '#FF0000' }
                },
                correct: {
                    fontSize: 42,
                    fontWeight: 'bold',
                    fill: '#FFFFFF', // @FIX White
                    glitchOffset: { r: -2, g: 0, b: 2 },
                    glow: { blur: 25, color: '#00FFFF' }
                },
                hook: {
                    fontSize: 56,
                    fontWeight: '900',
                    fill: '#00FF00',
                    stroke: { color: '#000000', width: 4 },
                    glitchOffset: { r: -4, g: 0, b: 4 },
                    glow: { blur: 30, color: '#00FF00' }
                }
            }
        }
    };

    // Expose to global scope
    window.MCQVS_TextEffects = MCQVS_TextEffects;

})(window);
