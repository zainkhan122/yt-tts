/**
 * MCQVS Render Plan
 * Single source of truth for timeline timing + cue points shared by Preview and Export.
 *
 * @package MCQ_Video_Studio
 * @since 9.0.0
 */
(function (window) {
  "use strict";

  const MCQVS_RenderPlan = {
    /**
     * Build a deterministic render plan from an already-built playlist.
     *
     * @param {Array} playlist - [{id,type,duration,content,timing}]
     * @param {Object} opts - {fps,width,height,templateId}
     * @returns {Object} plan
     */
    buildFromPlaylist(playlist, opts = {}) {
      const fps = Number(opts.fps || 30);
      const frameMs = 1000 / fps;

      const snap = (ms) => {
        const frames = Math.max(0, Math.round(Number(ms || 0) / frameMs));
        return frames * frameMs;
      };

      const plan = {
        version: 1,
        fps,
        frameMs,
        width: Number(opts.width || 1080),
        height: Number(opts.height || 1920),
        templateId: opts.templateId || null,
        createdAt: new Date().toISOString(),
        scenes: [],
        cues: [],
        assets: {
          images: [],
          audio: [],
          fonts: [],
        },
        totalMs: 0,
      };

      let cursor = 0;
      let firstSceneStart = null;
      let lastSceneEnd = null;
      (playlist || []).forEach((scene) => {
        const dur = snap(scene.duration || 0);
        const startMs = snap(cursor);
        if (firstSceneStart === null) firstSceneStart = startMs;

        const sceneEntry = {
          id: String(scene.id || ""),
          type: String(scene.type || "unknown"),
          startMs,
          durMs: dur,
          endMs: startMs + dur,
          content: scene.content || {},
          timing: scene.timing ? Object.assign({}, scene.timing, { questionTotal: dur }) : null,
        };
        plan.scenes.push(sceneEntry);

        // Global cue points for intro/outro boundaries
        if (sceneEntry.type === "hook" || sceneEntry.type === "intro") {
          plan.cues.push({ type: "intro_start", sceneId: sceneEntry.id, atMs: sceneEntry.startMs });
          plan.cues.push({ type: "intro_end", sceneId: sceneEntry.id, atMs: sceneEntry.endMs });
        }
        if (sceneEntry.type === "outro") {
          plan.cues.push({ type: "outro_start", sceneId: sceneEntry.id, atMs: sceneEntry.startMs });
        }

        // Cue points for question reveal (used by sparkles, SFX, etc.)
        if (sceneEntry.type === "question") {
          const revealMs = Number(sceneEntry.timing?.questionPhases?.reveal || 3000);
          const introMs = Number(sceneEntry.timing?.questionPhases?.intro || 0);
          const revealStart = snap(Math.max(0, sceneEntry.endMs - revealMs));
          sceneEntry.timing._revealStartRel = revealStart - sceneEntry.startMs;
          const readingDur = Math.max(0, revealStart - sceneEntry.startMs - introMs);
          // @FIX 2026-07-28: Ticks start 5 seconds BEFORE the visual reveal point (timer=0).
          //                   This ensures the timer glow/blinking fires in the last 5 seconds
          //                   of the countdown, matching user requirement.
          const tickStart = snap(Math.max(sceneEntry.startMs, revealStart - 5000));
          plan.cues.push({
            type: "question_start",
            sceneId: sceneEntry.id,
            atMs: sceneEntry.startMs,
          });
          plan.cues.push({
            type: "reveal_start",
            sceneId: sceneEntry.id,
            atMs: revealStart,
          });

          // Correct answer is displayed at reveal start (used for sparkles + result SFX)
          plan.cues.push({
            type: "reveal_correct",
            sceneId: sceneEntry.id,
            atMs: revealStart,
          });

          // Countdown begins (5 seconds before reveal)
          plan.cues.push({
            type: "countdown_start",
            sceneId: sceneEntry.id,
            atMs: tickStart,
          });

          // Countdown ticks in the last 5 seconds before reveal
          for (let i = 0; i < 5; i++) {
            const at = tickStart + i * 1000;
            if (at >= sceneEntry.startMs && at < revealStart) {
              plan.cues.push({
                type: "tick",
                sceneId: sceneEntry.id,
                atMs: snap(at),
              });
            }
          }

          // Useful for audio ducking and FX scheduling
          plan.cues.push({
            type: "reading_end",
            sceneId: sceneEntry.id,
            atMs: revealStart,
            meta: { readingMs: snap(readingDur), revealMs: snap(revealMs) },
          });
        }

        cursor = sceneEntry.endMs;
        lastSceneEnd = sceneEntry.endMs;
      });

      plan.totalMs = snap(cursor);

      // @FIX 2026-10-29: shorts have a VIDEO-level ceiling, not just per-scene.
      // maxTotal: 30000 is applied per question scene (estimateQuestionMs lines 221,
      // 234) and never to plan.totalMs — 5 questions x 30 s + hook + cover + outro
      // produced 60-85 s videos, which land in the worst-performing duration bucket
      // on this channel (median 286 views vs 1,026 for the 30-45 s bucket). Clamp
      // total and surface it as a diagnostic; do NOT silently truncate scenes
      // (truncating a question mid-reveal is worse than a long video).
      // @FIX 2026-10-30: This block referenced `config`, which is NOT in scope —
      // the enclosing parameter is `opts` (buildFromPlaylist(playlist, opts)).
      // The ReferenceError crashed EVERY plan build since @FIX 2026-10-29:
      // preview stayed black (playPreview bailed on null plan) and the play
      // button died with "Uncaught (in promise) ReferenceError".
      if (String(opts.videoFormat || '') !== 'youtube') {
        const _MAX_SHORT_MS = 45000;
        const _totalMs = snap(cursor);
        if (_totalMs > _MAX_SHORT_MS) {
          plan.videoOverMax = true;
          plan.videoOverByMs = _totalMs - _MAX_SHORT_MS;
          plan.videoMaxMs = _MAX_SHORT_MS;
        }
      }

      if (firstSceneStart !== null) {
        plan.cues.push({ type: "timeline_start", sceneId: "_", atMs: snap(firstSceneStart) });
      }
      if (lastSceneEnd !== null) {
        plan.cues.push({ type: "timeline_end", sceneId: "_", atMs: snap(lastSceneEnd) });
      }

      return plan;
    },

    /**
     * Collect assets referenced by config (best-effort).
     * This does NOT attempt deep template introspection (templates remain independent).
     */
    collectAssetsFromConfig(plan, config = {}) {
      const add = (arr, v) => {
        if (!v) return;
        if (Array.isArray(v)) v.forEach((x) => add(arr, x));
        else if (!arr.includes(v)) arr.push(v);
      };

      // Audio
      add(plan.assets.audio, config.musicUrl);
      add(plan.assets.audio, config.voiceUrl);
      if (config.sfx) Object.values(config.sfx).forEach((u) => add(plan.assets.audio, u));

      // Images
      add(plan.assets.images, config.logoUrl);
      add(plan.assets.images, config.backgroundImageUrl);

      // Fonts (worker-safe font list)
      add(plan.assets.fonts, config.fontFamily);

      return plan;
    },
  };

  window.MCQVS_RenderPlan = MCQVS_RenderPlan;
  // @FIX: Some legacy callers (`studio.export.js` line ~223) reference `MCQVSRenderPlan`
  //       without the underscore; alias both forms to the same object so neither fails.
  // @NEW 1.6.3 (owner spec): content-based per-question timing — the SINGLE
  // authority for how long a question scene lasts when no measured TTS exists,
  // and the readability floor when TTS does exist. Long questions / answers /
  // explanations get longer scenes in BOTH formats (shorts + youtube); the flat
  // per-format constants remain only as fallbacks when content is missing.
  const READ_WORDS_PER_SEC = 3.0; // ~180 wpm silent on-screen reading
  const EXPLAIN_PAD_MS = 400;

  function _words(text) {
    const s = String(text == null ? '' : text).trim();
    if (!s) return 0;
    return s.split(/\s+/).length;
  }

  function _formatBounds(opts) {
    const isYoutube = String((opts && opts.format) || 'shorts') === 'youtube';
    return isYoutube
      ? { minReading: 7000, maxReading: 60000, minTotal: 8000, maxTotal: 120000 }
      : { minReading: 4600, maxReading: 20000, minTotal: 5200, maxTotal: 30000 };
  }

  /**
   * Estimate question scene timing from the ACTUAL text volume.
   * @param {Object} content Question object {question, options, explanation}.
   * @param {Object} timing Base timing (questionPhases intro/reveal).
   * @param {Object} opts {format:'shorts'|'youtube', showExplanation:bool}
   * @returns {{intro:number,reading:number,reveal:number,total:number}|null}
   */
  MCQVS_RenderPlan.estimateQuestionMs = function (content, timing, opts) {
    if (!content || !content.question) return null;
    const t = timing || {};
    const phases = t.questionPhases || {};
    const b = _formatBounds(opts);
    const intro = Math.max(300, Number(phases.intro) || 600);
    const optText = Array.isArray(content.options)
      ? content.options.join(' ')
      : (content.options && typeof content.options === 'object' ? Object.values(content.options).join(' ') : '');
    const reading = Math.max(b.minReading, Math.min(b.maxReading,
      Math.round((_words(String(content.question) + ' ' + optText) / READ_WORDS_PER_SEC) * 1000)));
    let reveal = Math.max(800, Number(phases.reveal) || 2000);
    if (opts && opts.showExplanation && content.explanation) {
      const explainMs = Math.round((_words(content.explanation) / READ_WORDS_PER_SEC) * 1000) + EXPLAIN_PAD_MS;
      reveal = Math.max(reveal, Math.min(20000, explainMs));
    }
    const total = Math.max(b.minTotal, Math.min(b.maxTotal, intro + reading + reveal));
    return { intro, reading, reveal, total };
  };

  /**
   * Merge measured-TTS duration with the content estimate: the scene must fit
   * BOTH the narration and a comfortable silent read. Clamped per format.
   * @NEW 1.6.3
   */
  MCQVS_RenderPlan.mergeAdaptiveSceneMs = function (estimateTotal, ttsDerivedMs, opts) {
    const b = _formatBounds(opts);
    const est = Number.isFinite(Number(estimateTotal)) ? Number(estimateTotal) : 0;
    const tts = Number.isFinite(Number(ttsDerivedMs)) ? Number(ttsDerivedMs) : 0;
    return Math.max(b.minTotal, Math.min(b.maxTotal, Math.max(est, tts)));
  };

  window.MCQVSRenderPlan  = MCQVS_RenderPlan;
  if (window.MCQVS_PlanBuilder && window.MCQVS_PlanBuilder.buildFromPlaylist) {
      window.MCQVSPlanBuilder = window.MCQVS_PlanBuilder;
  }
})(window);
