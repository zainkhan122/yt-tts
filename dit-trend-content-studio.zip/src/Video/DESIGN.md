# DIT Video Shorts — Design Answers & Decisions

Answers to the engineering questions, grounded in **real posts** pulled from
dailyinfotainment.com across Showbiz / Fashion / Lifestyle.

---

## 1. Real-post analysis (fetched & parsed)

| Type | Example | Images | Orientation | Content | Embeds |
|---|---|---|---|---|---|
| Showbiz | Aqib Javed daughter wedding | 17 | mostly landscape | 4.4k chars | 1 IG Reel |
| Showbiz | Babrik Shah film clips | 9 | landscape | 3.7k chars | 0 |
| Fashion | Sapphire Khaddar | 22 | **mixed** land+port | 5.4k chars | 0 |
| Fashion | Saya Azadi Sale | 21 | mixed port+land | 4.8k chars | 0 |
| Fashion | Limelight Summer Lawn | 19 | mixed port+land | 5.3k chars | 0 |
| Lifestyle | Nail Art | 17 | portrait | **11.2k chars** | 0 |
| Lifestyle | Mehndi Designs | 35 | mixed | 5.1k chars | 0 |
| Lifestyle | Winter Hair Care | 13 | portrait | **12.1k chars** | 0 |

**Takeaways that shaped the design:**
- Image counts are high (9–35) → the module caps at ~8–10 scenes and picks the
  best-quality images (DIT already rates by W×H; the module sorts by resolution).
- **Mixed orientation everywhere** → no-crop **letterbox (black bars)** is the
  correct universal strategy. Portrait fills, landscape letterboxes.
- **Lifestyle posts are very long** (11–12k chars) → content is truncated to ~6k
  for the prompt to avoid context overflow.
- Image alt-text is repetitive (same title per image) → the AI **cannot** rely on
  it. Alignment is done **structurally** (see §3).
- Only Showbiz tends to embed short video (IG Reel); Fashion/Lifestyle are image-only.

---

## 2. Does the system handle all scenarios? (self-assessment)

| Scenario | Status |
|---|---|
| Showbiz story post, many landscape imgs + IG reel | ✅ images letterboxed; short clip used as hook scene |
| Fashion post, mixed portrait/landscape, each img = product | ✅ per-scene script per image, product CTA |
| Lifestyle post, portrait images, huge text | ✅ truncation + portrait fill + ideas CTA |
| Long YouTube embed (hours) | ⚠️ not blindly cropped — excluded from short clips (too risky); handled via images + article narrative |
| Short-form embed (IG Reel / YT Short / TikTok) | ✅ detected (`short_clips`) and dropped in as a hook video scene |
| Post still a Draft (scheduled publish) | ✅ Job_Manager qualifies drafts; video generates & waits in draft |
| Video must be replaced by YT link on publish | ✅ Publish_Integrator embeds YT block after 2nd paragraph |

The design is **uniform but content-aware**: one pipeline, with post-type logic
in the prompt/CTA and orientation-aware compositing in the renderer.

---

## 3. AI prompt & image alignment (the core question)

**Problem:** a text model can't see the images, and alt-text is not descriptive.

**Solution — structural alignment (no vision needed):**
1. The module builds an **ordered image manifest** `[{path, width, height, orientation}]`
   exactly matching the order the renderer will display.
2. The AI is told the manifest (position + orientation) and the post type.
3. The AI returns **`scene_scripts[]` with exactly N entries** where index i plays
   over image i. The article narrates images in order, so alignment is natural.
4. The renderer uses `scene_scripts[i]` as the TTS for scene i — so what's spoken
   matches what's shown.

What we feed the AI:
- ordered image manifest (count + orientation per slot)
- post title + content (truncated, wrapped as untrusted `<article>` data)
- Urdu heading (reuse)
- post type (Showbiz/Fashion/Lifestyle) + **category-specific CTA instruction**

Why it's robust: even without a vision model, "image #3 = a pink 3-piece lawn suit
(the 3rd product shown)" maps to scene 3's narration "this pink 3-piece lawn suit…".
A future upgrade can pass real per-image captions/vision descriptions, but the
structural contract already guarantees alignment.

---

## 4. Urdu TTS — beyond Edge + making Edge more effective

**Kokoro v0.19 does NOT support Urdu** (only EN/ES/FR/HI/IT/JA/PT/ZH). Options:

| Option | Urdu? | Cost | Notes |
|---|---|---|---|
| **Edge-TTS** (`ur-PK-UzmaNeural`) | ✅ | Free | best free Urdu; improved below |
| Piper (self-hosted) | ✅ (community `ur` voices) | Free | offline, lower fidelity |
| Kokoro | ❌ | Free | closest = Hindi `hf_alpha` — NOT Urdu |
| ElevenLabs | ✅ | Paid | best quality, commercial license needed |
| Google/Azure Neural | ✅ | Paid | high quality Urdu |

**Making Edge-TTS less robotic (implemented):**
- `+15%` rate → energetic/fast vlogger pacing.
- `+4Hz` pitch boost → brighter, more confident female voice.
- **Loudness normalization** (`loudnorm I=-16 LUFS`) → consistent, broadcast-level.
- **Silence trimming** (head/tail) → natural starts/ends, no dead air.
- Verified: mean volume went −22dB → **−17dB**, max −4.6 → −2.0dB.

For premium later: keep the same `tts.py` contract and swap to ElevenLabs/Azure by
adding one more backend.

---

## 5. Animations (so it's not "static images + VO")

Current renderer (verified):
- **Varied Ken Burns** — cycles zoom-in / zoom-out / pan-right / pan-down per scene
  (not one repetitive motion).
- **Crossfade transitions** between scenes (`xfade` video + `acrossfade` audio).
- **Gradient overlay** + subtle shadow for depth; logo/brand bar with backdrop-blur.

Planned/higher-polish (needs puppeteer/Chrome, not in this sandbox):
- **Animated heading** (fade/slide via CSS) — puppeteer already renders the
  heading element; add a CSS keyframe animation.
- Optional **background music** with sidechain ducking under the VO (from the
  earlier standalone design) for a produced feel.

---

## 6. SMN & YouTube videos in Shorts

- **Long YouTube videos:** NOT blindly downloaded/cropped (hours-long, wrong for a
  60s short, and you can't know which second is the good shot without watching).
  These are handled through **images + the article narrative** instead. If you want
  a specific clip, the transcript/chapter path (from the standalone work) can find
  a relevant window — but it's off by default for DIT to keep it fast and safe.
- **Short-form embeds (IG Reel / YT Short / TikTok):** these are *already short
  clips*, so the module **detects them** (`detect_short_clips`) and drops the clip
  in as a **hook scene**, composited to vertical with a blurred pillarbox (no crop).
  It preserves the original clip's visuals, only adding the brand/heading overlay.

---

## 7. Draft → publish workflow (implemented)

1. DIT generates a post → **Draft** (per DIT's scheduling).
2. `Job_Manager` qualifies it (DIT-generated + has images + Urdu heading, in
   `draft/future/publish`) and **generates the video while it's a draft**.
3. Video is attached; `_dit_ts_video_id` + YT meta are set.
4. On publish, DIT's **existing** Buffer `Queue_Manager` uploads the video to
   YouTube (because `_dit_ts_video_id` is set) and shares the image to other
   channels.
5. `Publish_Integrator` (after Buffer, priority 40) resolves the YT link and
   **inserts a native YouTube Gutenberg block after the 2nd paragraph**.
6. Optionally detaches the local video so cleanup can remove it.

---

## 8. Getting the YouTube link back (implemented: YT_Lookup)

- **Buffer's publish response does not reliably return the final YouTube URL** for
  uploads — so don't depend on it.
- **Robust solution:** `YT_Lookup` uses the **YouTube Data API** to search **your
  own channel** (channel ID in settings) for the generated title, fuzzy-matches
  the result, and returns the watch URL + embed URL.
- If you add a YouTube API key (or DIT's Google key is present) + your channel ID,
  this works without depending on Buffer's response.
- Fallback chain: exact title → slugified → newest on-channel result. No key = the
  block is simply not inserted (logged).

---

## 9. Per-post-type CTAs (implemented in Script_AI)

The prompt injects a category-specific CTA so the closing line fits the content:

- **Showbiz:** "check the post, link in caption for the complete details of what happened"
- **Fashion (dresses/lawn):** "check the details of the dresses and prices, link in caption"
- **Lifestyle (mehndi/hair/nails):** "which one is your favourite? see more ideas in our post, link in caption"

The AI adapts these to the exact content; the deterministic fallback also follows
them.

---

## 10. Files added (this module)

```
src/Video/  Settings, Brand, Script_AI, Generator, Job_Manager, Cleanup,
            Diagnostics, YT_Lookup, Publish_Integrator, Admin, Module, DESIGN.md
video-runner/  render.mjs, tts.py (edge+enhanced), tts_kokoro.py, package.json
+ guarded hook into dit-trend-content-studio.php
+ guarded dashboard card in Admin/Views/dashboard.php
```
