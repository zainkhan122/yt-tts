<?php

/**
 * Readability and Style Checker
 *
 * Calculates Flesch Reading Ease, detects passive voice and flags long paragraphs.
 *
 * @package DIT_TrendStudio\Content
 */

namespace DIT\TrendStudio\Content;

// Block direct access
defined('ABSPATH') || exit;

/**
 * Class ReadabilityChecker
 * Provides readability metrics for AI-generated content.
 */
class ReadabilityChecker
{
    /** @var int Maximum words allowed per paragraph */
    private int $maxWordsPerParagraph;

    /**
     * Constructor.
     *
     * @param int $max_words_per_paragraph Default 180 words.
     */
    public function __construct(int $max_words_per_paragraph = 180)
    {
        $this->maxWordsPerParagraph = (int) apply_filters('tcs_readability_max_paragraph_words', $max_words_per_paragraph);
    }

    /**
     * Evaluate the readability of an article.
     *
     * Returns an array with keys:
     * - score: Flesch Reading Ease score
     * - passive_sentences: number of sentences likely in passive voice
     * - paragraphs_too_long: number of paragraphs exceeding the maximum word count
     *
     * @param mixed $article GenerationResultDTO or associative array
     * @return array
     */
    public function evaluate($article): array
    {
        // Extract plain text and sections
        $text = '';
        $sections = [];

        if (is_object($article) && property_exists($article, 'sections')) {
            $sections = $article->sections;
        } elseif (is_array($article) && isset($article['sections'])) {
            $sections = $article['sections'];
        }

        foreach ($sections as $sec) {
            $body = $sec['body'] ?? ($sec['body_html'] ?? '');
            $text .= ' ' . wp_strip_all_tags($body);
        }
        $text = trim($text);

        $score = $this->calculate_flesch_score($text);
        $passive_count = $this->count_passive_sentences($text);
        $long_paragraphs = $this->count_long_paragraphs($sections);

        return [
            'score' => $score,
            'passive_sentences' => $passive_count,
            'paragraphs_too_long' => $long_paragraphs,
        ];
    }

    /**
     * Calculate Flesch Reading Ease.
     *
     * @param string $text
     * @return float
     */
    private function calculate_flesch_score(string $text): float
    {
        if (empty($text)) {
            return 100.0;
        }

        $sentences = preg_split('/[.!?]+/u', $text, -1, PREG_SPLIT_NO_EMPTY);
        $sentence_count = max(count($sentences), 1);

        $words = preg_split('/\s+/u', $text, -1, PREG_SPLIT_NO_EMPTY);
        $word_count = max(count($words), 1);

        $syllable_count = 0;
        foreach ($words as $word) {
            $syllable_count += $this->count_syllables($word);
        }

        $score = 206.835 - (1.015 * ($word_count / $sentence_count)) - (84.6 * ($syllable_count / $word_count));
        return round($score, 2);
    }

    /**
     * Estimate syllable count in a word.
     *
     * @param string $word
     * @return int
     */
    private function count_syllables(string $word): int
    {
        $word = preg_replace('/[^a-z]/i', '', strtolower($word));
        if ($word === '') {
            return 0;
        }
        preg_match_all('/[aeiouy]{1,2}/', $word, $matches);
        $count = count($matches[0]);
        if (substr($word, -1) === 'e') {
            $count--;
        }
        return max($count, 1);
    }

    /**
     * Count sentences likely to use passive voice.
     *
     * @param string $text
     * @return int
     */
    private function count_passive_sentences(string $text): int
    {
        $count = 0;
        $sentences = preg_split('/[.!?]+/u', $text, -1, PREG_SPLIT_NO_EMPTY);
        $patterns = [
            '/\b(is|are|was|were|be|been|being)\b[^.!?]{0,10}\bby\b/i',
        ];
        foreach ($sentences as $sentence) {
            foreach ($patterns as $pattern) {
                if (preg_match($pattern, $sentence)) {
                    $count++;
                    break;
                }
            }
        }
        return $count;
    }

    /**
     * Count paragraphs that exceed the max word threshold.
     *
     * @param array $sections
     * @return int
     */
    private function count_long_paragraphs(array $sections): int
    {
        $long = 0;
        foreach ($sections as $sec) {
            $body = $sec['body'] ?? ($sec['body_html'] ?? '');
            $paragraphs = preg_split('/\n+/u', wp_strip_all_tags($body), -1, PREG_SPLIT_NO_EMPTY);
            foreach ($paragraphs as $p) {
                $words = preg_split('/\s+/u', $p, -1, PREG_SPLIT_NO_EMPTY);
                if (count($words) > $this->maxWordsPerParagraph) {
                    $long++;
                }
            }
        }
        return $long;
    }
}
