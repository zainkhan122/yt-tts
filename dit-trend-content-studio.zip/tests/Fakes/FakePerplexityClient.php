<?php

declare(strict_types=1);

namespace DIT\TrendStudio\Tests\Fakes;

use DIT\TrendStudio\Contracts\AIProviderInterface;
use DIT\TrendStudio\Content\Perplexity_Client;
use DIT\TrendStudio\Infrastructure\Logger;

final class FakePerplexityClient extends Perplexity_Client
{
    private array $researchResponse;
    private array $articleResponse;

    public array $calls = [];

    public function __construct(array $researchResponse = [], array $articleResponse = [])
    {
        $this->researchResponse = $researchResponse;
        $this->articleResponse  = $articleResponse;
    }

    public function research(array $promptData): array
    {
        $this->calls[] = [
            'method'     => 'research',
            'promptData' => $promptData,
        ];

        return $this->researchResponse;
    }

    public function generate_article(array $promptData, array $research): array
    {
        $this->calls[] = [
            'method'     => 'generate_article',
            'promptData' => $promptData,
            'research'   => $research,
        ];

        return $this->articleResponse;
    }

    public function generate(array $promptData): array
    {
        $this->calls[] = [
            'method'     => 'generate',
            'promptData' => $promptData,
        ];
        return $this->articleResponse;
    }

    public function generateFromResearch(array $promptData, array $researchData): array
    {
        return $this->generate_article($promptData, $researchData);
    }

    public function generateCustomJson(string $prompt): array
    {
        return [];
    }

    public function get_model(): string
    {
        return 'sonar';
    }
}
