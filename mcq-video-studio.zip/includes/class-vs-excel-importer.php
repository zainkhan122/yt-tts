<?php

/**
 * Excel Utility for MCQ Video Studio Plugin
 * 
 * Provides Excel file import and parsing capabilities for the Content Planner.
 * 
 * @package    MCQ_Video_Studio
 * @since      1.0.0
 */

if (! defined('ABSPATH')) {
    exit;
}

/**
 * Class VS_Excel_Importer
 *
 * Handles Excel file import and parsing for the Content Planner.
 *
 * @since 1.0.0
 */
class VS_Excel_Importer
{

    /**
     * Parse Excel file content.
     * 
     * @since 1#24-*08: Handles simple topic parsing for Excel/CSV files with flexible formats
     * Reads topics and descriptions from various column layouts.
     * 
     * @param string $excel_content Raw file content from Excel or CSV
     * @return array Parsed topics or error message
     */
    public static function parse_excel_content($excel_content)
    {
        // @FIX 1.4.9.46 (CRITICAL): Strip a UTF-8 BOM (\xEF\xBB\xBF). Files saved
        // by Excel/Google Sheets often start with one, and it corrupts the FIRST
        // header cell — "topic" became "\xEF\xBB\xBFtopic", so every row failed
        // the `!empty($topic_data['topic'])` gate and previews/imports reported
        // "No topics found in the uploaded file" for a perfectly valid file
        // (e.g. Aug-26-videos-v3.csv: 0 topics with BOM, 500 without).
        if (substr((string) $excel_content, 0, 3) === "\xEF\xBB\xBF") {
            $excel_content = substr((string) $excel_content, 3);
        }

        // Try CSV parsing first (common fallback for Excel files)
        if (self::is_likely_csv($excel_content)) {
            return self::parse_csv_content($excel_content);
        }
        
        // Try raw text parsing as last resort
        $excel_content = str_replace(array("\r\n", "\r"), "\n", $excel_content);
        $lines = explode("\n", $excel_content);
        $topics = array();
        
        foreach ($lines as $line) {
            $line = trim($line);
            if (empty($line)) {
                continue;
            }
            
            // Try to parse as simple CSV (one topic per line)
            $parts = self::parse_csv_line($line);
            if (!empty($parts)) {
                $topic_name = trim($parts[0] ?? '');
                $description = trim($parts[1] ?? '');
                
                if (!empty($topic_name)) {
                    $topics[] = array(
                        'topic' => $topic_name,
                        'description' => $description,
                    );
                }
            }
        }
        
        return $topics;
    }
    
    /**
     * Check if content looks like CSV format.
     *
     * @since 1.0.0
     * @param string $content File content to check
     * @return bool True if looks like CSV
     */
    private static function is_likely_csv($content)
    {
        $content = str_replace(array("\r\n", "\r"), "\n", $content);
        $lines = explode("\n", $content);
        $csv_like = 0;
        $total_lines = count($lines);
        
        foreach ($lines as $line) {
            if (preg_match('/^[^\x00-\x1F]*$/', $line) && 
                (strpos($line, ',') !== false || strpos($line, "\t") !== false)) {
                $csv_like++;
            }
        }
        
        return $csv_like > $total_lines * 0.7;
    }
    
    /**
     * Parse CSV content.
     *
     * @since 1.0.0
     * @param string $csv_content CSV file content
     * @return array Array of parsed topic data
     */
    private static function parse_csv_content($csv_content)
    {
        $csv_content = str_replace(array("\r\n", "\r"), "\n", $csv_content);
        $lines = explode("\n", $csv_content);
        $topics = array();

        $headers = null;
        $supported_columns = array(
            'topic', 'niche', 'description',
            'publish_date', 'publish_time', 'frequency',
            'template', 'font', 'music', 'bg_video', 'save_mode',
            'videos_per_topic', 'questions_per_video',
            'hook_text', 'hook_visible', 'brand_name', 'quiz_name',
            'logo_path', 'logo_position',
            'buffer_channel',
            'bg_color', 'text_color', 'accent_color',
            'difficulty', 'platform',
            'speak_hook', 'speak_options', 'speak_answer', 'speak_cta',
            'question', 'option_a', 'option_b', 'option_c', 'option_d', 'correct_answer',
        );
        
        foreach ($lines as $line) {
            $line = trim($line);
            if (empty($line)) {
                continue;
            }
            
            $parts = self::parse_csv_line($line);
            
            if (empty($parts)) {
                continue;
            }

            // First non-empty row is the header
            if ($headers === null) {
                $headers = array_map('strtolower', array_map('trim', $parts));
                continue;
            }
            
            // Map values to header column names
            $topic_data = array();
            foreach ($headers as $col_index => $col_name) {
                $value = trim($parts[$col_index] ?? '');
                if ($value === '') {
                    continue;
                }
                // Normalize known column aliases
                if ($col_name === 'hook_text') {
                    $col_name = 'hookText';
                } elseif ($col_name === 'hook_visible') {
                    $col_name = 'hookVisible';
                } elseif ($col_name === 'brand_name') {
                    $col_name = 'brandName';
                } elseif ($col_name === 'quiz_name') {
                    $col_name = 'quizName';
                } elseif ($col_name === 'logo_path') {
                    $col_name = 'logoPath';
                } elseif ($col_name === 'logo_position') {
                    $col_name = 'logoPosition';
                } elseif ($col_name === 'buffer_channel') {
                    $col_name = 'buffer_channels';
                } elseif ($col_name === 'bg_color') {
                    $col_name = 'bgColor';
                } elseif ($col_name === 'text_color') {
                    $col_name = 'textColor';
                } elseif ($col_name === 'accent_color') {
                    $col_name = 'accentColor';
                } elseif ($col_name === 'videos_per_topic') {
                    $col_name = 'videos_per_topic';
                } elseif ($col_name === 'questions_per_video') {
                    $col_name = 'questions_per_video';
                } elseif ($col_name === 'speak_hook') {
                    $col_name = 'speakHook';
                } elseif ($col_name === 'speak_options') {
                    $col_name = 'speakOptions';
                } elseif ($col_name === 'speak_answer') {
                    $col_name = 'speakAnswer';
                                } elseif ($col_name === 'speak_cta') {
                    $col_name = 'speakCta';
                } elseif ($col_name === 'hashtags') {
                    // Pass through; AI or CSV will provide comma/space sep list
                } elseif ($col_name === 'hook') {
                    $col_name = 'hookText';
                }
                $topic_data[$col_name] = $value;
            }

            // Normalize booleans
            foreach (array('hookVisible', 'speakHook', 'speakOptions', 'speakAnswer', 'speakCta') as $bool_key) {
                if (isset($topic_data[$bool_key])) {
                    $v = strtolower($topic_data[$bool_key]);
                    $topic_data[$bool_key] = ($v === 'true' || $v === '1' || $v === 'yes');
                }
            }

            // Normalize numeric fields
            foreach (array('videos_per_topic', 'questions_per_video') as $num_key) {
                if (isset($topic_data[$num_key])) {
                    $topic_data[$num_key] = max(1, (int) $topic_data[$num_key]);
                }
            }

            // Handle buffer_channel as single value → array
            if (isset($topic_data['buffer_channels']) && !is_array($topic_data['buffer_channels'])) {
                $topic_data['buffer_channels'] = array($topic_data['buffer_channels']);
            }

            // @NEW 2026-08-05: Per-row MCQ columns → normalize letter answers to correct_index.
            // Each CSV row with question/options produces ONE MCQ attached to the topic.
            $has_mcq_row = (
                !empty($topic_data['question']) &&
                !empty($topic_data['option_a']) &&
                !empty($topic_data['option_b']) &&
                !empty($topic_data['option_c']) &&
                !empty($topic_data['option_d']) &&
                !empty($topic_data['correct_answer'])
            );
            if ($has_mcq_row) {
                $correct_index = self::normalize_correct_answer(
                    $topic_data['correct_answer'],
                    array(
                        $topic_data['option_a'],
                        $topic_data['option_b'],
                        $topic_data['option_c'],
                        $topic_data['option_d'],
                    )
                );
                if ($correct_index === null) {
                    $topic_data['_mcq_error'] = 'correct_answer could not be resolved';
                } else {
                    $topic_data['_inline_question'] = array(
                        'question'   => trim($topic_data['question']),
                        'options'    => array(
                            trim($topic_data['option_a']),
                            trim($topic_data['option_b']),
                            trim($topic_data['option_c']),
                            trim($topic_data['option_d']),
                        ),
                        'correct'    => $correct_index,
                        'difficulty' => !empty($topic_data['difficulty']) ? $topic_data['difficulty'] : 'medium',
                    );
                }
            }

            // Validate topic exists
            if (!empty($topic_data['topic'])) {
                $topics[] = $topic_data;
            }
        }
        
        return $topics;
    }
    
    /**
     * Parse a single CSV line, handling quoted fields per RFC-style rules.
     *
     * @since 1.0.0
     * @param string $line CSV line
     * @return array Parsed fields
     */
    private static function parse_csv_line($line)
    {
        $result = array();
        $current = '';
        $in_quotes = false;
        $len = strlen($line);

        for ($i = 0; $i < $len; $i++) {
            $char = $line[$i];

            if ($char === '"') {
                if ($in_quotes && $i + 1 < $len && $line[$i + 1] === '"') {
                    // Escaped quote inside a quoted field ("" → ").
                    $current .= '"';
                    $i++; // consume the second quote
                } else {
                    // Opening or closing delimiter — never part of the value.
                    $in_quotes = !$in_quotes;
                }
            } elseif ($char === ',' && !$in_quotes) {
                $result[] = trim($current);
                $current = '';
            } else {
                $current .= $char;
            }
        }

        $result[] = trim($current);

        return $result;
    }

    /**
     * Resolve a user-supplied "correct answer" cell to a 0-3 index.
     *
     * Accepts letter ("A"/"a"), 1-based index ("1"), 0-based index ("0"),
     * or the literal option text. Returns null on unresolvable input.
     *
     * @since 1.0.0
     * @param string $answer Raw cell value
     * @param array  $options Four option strings in declared order
     * @return int|null 0..3 or null
     */
    private static function normalize_correct_answer($answer, $options)
    {
        $answer = trim((string) $answer);
        if ($answer === '') {
            return null;
        }
        $upper = strtoupper($answer);
        if (in_array($upper, array('A', 'B', 'C', 'D'), true)) {
            return ord($upper) - ord('A');
        }
        if (is_numeric($answer)) {
            $n = (int) $answer;
            if ($n >= 1 && $n <= 4) {
                return $n - 1;
            }
            if ($n >= 0 && $n <= 3) {
                return $n;
            }
        }
        foreach ($options as $i => $opt) {
            if (strcasecmp(trim((string) $opt), $answer) === 0) {
                return $i;
            }
        }
        return null;
    }

    /**
     * Process legacy Excel/CSV topics into enhanced content plan format.
     * Handles all smart defaults and settings based on user requirements.
     * 
     * @since 1.0.0
     * @param array $topics Array of topic data from Excel/CSV (with topic and description)
     * @param array $import_settings Import settings
     * @return array Processed topics ready for content plan
     */
    public static function process_legacy_excel_content($topics, $import_settings)
    {
        $content_plan = array();
        
        // @FIX 1.4.9.56: minimalist + quizwire templates were removed (white-on-white
        //       readability). The allow-list below is the live set in vs-video-templates.js;
        //       any CSV `template` value outside it falls back to 'corporate' (safe, dark).
        $available_templates = array('corporate', 'elegant', 'neon',
                                    'fire', 'electric', 'horror', 'classroom',
                                    'history', 'tech', 'sports', 'trivia',
                                    'science', 'nature', 'space', 'retro80s', 'cyberpunk');
        
        // Get hooks for randomization
        $available_hooks = array(
            "Only Geniuses Get 5/5",
            "Can You Beat This Quiz?", 
            "99% Get This Wrong",
            "How Many Can You Get Right?",
            "Your Brain Will Trick You",
            "Do Not Answer Too Fast",
            "Can You Get All 5?",
            "Bet You Cannot Score 5/5",
            "Expert-Level Quiz",
            "Only 1 Percent Can Pass"
        );
        
        // Get all available buffer channels from the real configured list.
        // @FIX 2026-08-06: Never inject placeholder IDs like 'buffer_channel_1'
        //       — Buffer rejects them ("Invalid ChannelId format"). Read the actual
        //       configured channels (same precedence as the Buffer push path:
        //       enabled channels, then cached full list) so CSV-imported jobs push
        //       to the channels already configured in Settings > Buffer.
        $buffer_channels = class_exists('VS_Buffer_Client') ? VS_Buffer_Client::get_valid_saved_channel_ids() : array();
        
        // @NEW 2026-08-05: First pass — group CSV rows that share the same
        // (topic + publish_date + publish_time) so a multi-row MCQ import
        // collapses into ONE plan entry whose _inline_questions[] carries the
        // full question set. This matches the existing per-topic grouping in
        // create_job_for_topic() which already keys on topic + offset.
        // Intra-CSV dedup uses the same md5(trim(question_text)) hash as
        // VS_MCQ_Repository::insert_mcq() so duplicates inside the file are
        // dropped here instead of being caught (and wasting a bank insert)
        // downstream.
        $grouped = array();
        $seen_hashes = array();
        foreach ($topics as $topic_data) {
            $topic_name = trim($topic_data['topic'] ?? '');
            if ($topic_name === '') {
                continue;
            }
            $slot_key = $topic_name
                . '|' . ($topic_data['publish_date'] ?? '')
                . '|' . ($topic_data['publish_time'] ?? '');
            if (!isset($grouped[$slot_key])) {
                $grouped[$slot_key] = $topic_data;
                $grouped[$slot_key]['_inline_questions'] = array();
                $seen_hashes[$slot_key] = array();
            }
            if (!empty($topic_data['_inline_question'])) {
                $hash = md5(trim($topic_data['_inline_question']['question']));
                if (isset($seen_hashes[$slot_key][$hash])) {
                    if (!isset($grouped[$slot_key]['_mcq_errors'])) {
                        $grouped[$slot_key]['_mcq_errors'] = array();
                    }
                    $grouped[$slot_key]['_mcq_errors'][] = 'Duplicate question in CSV (skipped): ' . substr($topic_data['_inline_question']['question'], 0, 60);
                    continue;
                }
                $seen_hashes[$slot_key][$hash] = true;
                $grouped[$slot_key]['_inline_questions'][] = $topic_data['_inline_question'];
            } elseif (!empty($topic_data['_mcq_error'])) {
                if (!isset($grouped[$slot_key]['_mcq_errors'])) {
                    $grouped[$slot_key]['_mcq_errors'] = array();
                }
                $grouped[$slot_key]['_mcq_errors'][] = $topic_data['_mcq_error'];
            }
        }

        foreach ($grouped as $topic_data) {
            $topic_info = array();

            // Ensure topic exists
            $topic_name = trim($topic_data['topic'] ?? '');
            if (empty($topic_name)) {
                continue;
            }

            $topic_info['topic'] = $topic_name;
            
            // Add description if available
            if (!empty($topic_data['description'])) {
                $topic_info['description'] = $topic_data['description'];
            }
            
            // Add scheduling: use CSV-provided values when present, otherwise generate defaults
            if (!empty($topic_data['publish_date']) && !empty($topic_data['publish_time'])) {
                // CSV provided explicit date + time — normalize date to Y-m-d
                $raw_date = $topic_data['publish_date'];
                $normalized_date = $raw_date;
                // Try to parse various formats and normalize to Y-m-d
                $parsed = false;
                foreach (array('m/d/Y', 'm/d/y', 'd/m/Y', 'd/m/y', 'Y-m-d', 'Y/m/d') as $fmt) {
                    $dt = DateTime::createFromFormat($fmt, $raw_date);
                    if ($dt !== false) {
                        $normalized_date = $dt->format('Y-m-d');
                        $parsed = true;
                        break;
                    }
                }
                if (!$parsed) {
                    // Fallback: try strtotime
                    $ts = strtotime($raw_date);
                    if ($ts !== false) {
                        $normalized_date = date('Y-m-d', $ts);
                    }
                }
                
                $topic_info['publish_date'] = $normalized_date;
                $topic_info['publish_time'] = $topic_data['publish_time'];
                $topic_info['publish_frequency'] = $topic_data['frequency'] ?? ($import_settings['publish_frequency'] ?? 'daily');
                $topic_info['_calendar_assigned'] = true;
            } elseif (!empty($topic_data['publish_date'])) {
                // CSV provided date only — normalize date
                $raw_date = $topic_data['publish_date'];
                $normalized_date = $raw_date;
                $parsed = false;
                foreach (array('m/d/Y', 'm/d/y', 'd/m/Y', 'd/m/y', 'Y-m-d', 'Y/m/d') as $fmt) {
                    $dt = DateTime::createFromFormat($fmt, $raw_date);
                    if ($dt !== false) {
                        $normalized_date = $dt->format('Y-m-d');
                        $parsed = true;
                        break;
                    }
                }
                if (!$parsed) {
                    $ts = strtotime($raw_date);
                    if ($ts !== false) {
                        $normalized_date = date('Y-m-d', $ts);
                    }
                }
                
                $topic_info['publish_date'] = $normalized_date;
                $topic_info['publish_time'] = $topic_data['publish_time'] ?? ($import_settings['publish_time'] ?? get_option('mcqvs_default_publish_time', '09:00'));
                $topic_info['publish_frequency'] = $topic_data['frequency'] ?? ($import_settings['publish_frequency'] ?? 'daily');
                $topic_info['_calendar_assigned'] = true;
            } elseif (!empty($import_settings['start_date'])) {
                // @FIX 2026-08-07: No CSV dates — derive publish_date + publish_time from
                // the Buffer-tab settings (publish_frequency + publish_time_window).
                // SSOT for "videos per day" is Publish Frequency (already registered).
                // Slot math divides [start, end] evenly into N equal slots and stacks
                // successive rows on different days. No Gemini call is involved —
                // this branch is reached only when the row already carries
                // _inline_questions (authoritative).
                $topic_index = count($content_plan);

                $frequency = $import_settings['publish_frequency'] ?? get_option('mcqvs_publish_frequency', 'daily');
                $per_day = 1;
                if (preg_match('/^(\d+)x[_\s]?daily$/i', (string) $frequency, $m)) {
                    $per_day = max(1, (int) $m[1]);
                } elseif ($frequency === 'twice_daily') {
                    $per_day = 2;
                } elseif ($frequency === 'every_3_days' || $frequency === 'weekly' || $frequency === 'asap') {
                    $per_day = 1;
                }

                $day_offset = intdiv($topic_index, $per_day);
                $slot_index = $topic_index % $per_day;

                $publish_date = new DateTime($import_settings['start_date']);
                $publish_date->modify("+{$day_offset} days");
                $topic_info['publish_date'] = $publish_date->format('Y-m-d');

                $window_start = get_option('mcqvs_publish_time_window_start', '18:00');
                $window_end   = get_option('mcqvs_publish_time_window_end', '21:00');
                if (!preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $window_start)) {
                    $window_start = '18:00';
                }
                if (!preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $window_end)) {
                    $window_end = '21:00';
                }
                list($sh, $sm) = array_map('intval', explode(':', $window_start));
                list($eh, $em) = array_map('intval', explode(':', $window_end));
                $start_minutes = ($sh * 60) + $sm;
                $end_minutes   = ($eh * 60) + $em;
                if ($end_minutes <= $start_minutes) {
                    // Invalid / same-time window — fall back to the legacy single-time
                    // default so the slot still lands on a sane time of day.
                    $end_minutes = $start_minutes + max(1, $per_day) * 15;
                }
                $slot_total = max(1, $per_day);
                $slot_increment = ($end_minutes - $start_minutes) / $slot_total;
                $slot_minutes = (int) round($start_minutes + ($slot_index * $slot_increment));
                if ($slot_minutes >= 24 * 60) {
                    $slot_minutes -= 24 * 60;
                    $publish_date->modify('+1 day');
                    $topic_info['publish_date'] = $publish_date->format('Y-m-d');
                }
                $slot_h = intdiv($slot_minutes, 60);
                $slot_m = $slot_minutes % 60;
                $topic_info['publish_time'] = sprintf('%02d:%02d', $slot_h, $slot_m);

                $topic_info['publish_frequency'] = $frequency;
                $topic_info['_publish_day_offset'] = $day_offset;
                // @NEW 2026-08-05: Persist _publish_start_date so the linear path inside
                // create_job_for_topic() can recompute publish_at deterministically even
                // when the planner UI passes an empty publish_start_date.
                $topic_info['_publish_start_date'] = $import_settings['start_date'];
            }
            
            // Template selection: use CSV value if valid, else random
            if (!empty($topic_data['template'])) {
                $template = $topic_data['template'];
                if (in_array($template, $available_templates)) {
                    $topic_info['template'] = $template;
                } else {
                    $topic_info['template'] = 'corporate';
                }
            } elseif (!empty($import_settings['template'])) {
                $template = $import_settings['template'];
                if (in_array($template, $available_templates)) {
                    $topic_info['template'] = $template;
                } else {
                    $topic_info['template'] = 'corporate';
                }
            } else {
                $topic_info['template'] = $available_templates[array_rand($available_templates)];
            }
            
            // Font: use CSV value if provided, else empty (auto from template)
            if (!empty($topic_data['font'])) {
                $topic_info['font'] = $topic_data['font'];
            }
            
            // Music: use CSV value if provided
            if (!empty($topic_data['music'])) {
                $topic_info['music'] = $topic_data['music'];
            }
            
            // Background video: use CSV value if provided, else random from folder
            if (!empty($topic_data['bg_video'])) {
                $topic_info['bg_video'] = $topic_data['bg_video'];
            } else {
                // @NEW 2026-08-18: Randomly assign background video from assets/bg-videos/ folder
                // when not explicitly provided in CSV. Scans the folder for .mp4 files and picks
                // one at random - no name matching needed, works with any videos user has placed there.
                $bg_dir = mcqvs_assets_dir('bg-videos/');
                $bg_files = glob($bg_dir . '*.mp4');
                if ($bg_files && is_array($bg_files) && count($bg_files) > 0) {
                    $random_file = $bg_files[array_rand($bg_files)];
                    // Store just the filename so renderer can resolve it via basename()
                    $topic_info['bg_video'] = basename($random_file);
                } else {
                    // Fallback: try common default names if folder is empty
                    $topic_info['bg_video'] = '';
                }
            }
            
            // Save mode: use CSV value if valid, else fall back to the sidebar
            // control (NOT hardcoded r2_buffer — import must honor the UI).
            if (!empty($topic_data['save_mode']) && in_array($topic_data['save_mode'], array('local', 'r2', 'r2_buffer'))) {
                $topic_info['save_mode'] = $topic_data['save_mode'];
            } else {
                $topic_info['save_mode'] = $import_settings['save_mode'] ?? 'r2_buffer';
            }
            
            // Hook: use CSV value if provided, else random
            if (!empty($topic_data['hookText'])) {
                $topic_info['hookText'] = $topic_data['hookText'];
            } else {
                $topic_info['hookText'] = $available_hooks[array_rand($available_hooks)];
            }
            $topic_info['hookVisible'] = isset($topic_data['hookVisible'])
                ? $topic_data['hookVisible']
                : (isset($import_settings['hook_visible']) ? (bool) $import_settings['hook_visible'] : true);

            // @FIX 1.4.9.46: Persist CSV hashtags. v3 CSVs carry a per-topic tag
            // list that must feed the Buffer caption {hashtags} placeholder and
            // the pinned-comment copy — it was parsed from the file but dropped
            // here, so imported captions silently lost their tags.
            if (!empty($topic_data['hashtags'])) {
                $topic_info['hashtags'] = trim((string) $topic_data['hashtags'], " \t\n\r\0\x0B\"'");
            }
            
            // Branding: use CSV values if provided, else defaults
            $topic_info['brandName'] = !empty($topic_data['brandName']) ? $topic_data['brandName'] : 'TheQuizWire';
            $topic_info['quizName'] = !empty($topic_data['quizName']) ? $topic_data['quizName'] : $topic_name;
            
            // Logo settings: use CSV values if provided
            $topic_info['logoPosition'] = !empty($topic_data['logoPosition']) ? $topic_data['logoPosition'] : 'all';
            if (!empty($topic_data['logoPath'])) {
                $topic_info['logoPath'] = $topic_data['logoPath'];
            } else {
                $logo_path = get_option('MCQVS_studio_branding_logo_url', '');
                if (!empty($logo_path)) {
                    $topic_info['logoPath'] = $logo_path;
                }
            }
            
            // Video/question counts: use CSV values if provided
            $topic_info['videos_per_topic'] = !empty($topic_data['videos_per_topic']) ? (int) $topic_data['videos_per_topic'] : 1;
            $topic_info['questions_per_video'] = !empty($topic_data['questions_per_video']) ? (int) $topic_data['questions_per_video'] : 5;
            
            // Buffer channels: use CSV value if provided and valid, else real saved channels
            $csv_channels = (!empty($topic_data['buffer_channels']) && is_array($topic_data['buffer_channels'])) ? $topic_data['buffer_channels'] : array();
            $valid_csv_channels = array_values(array_filter($csv_channels, function ($cid) {
                return is_string($cid) && (bool) preg_match('/^[0-9a-fA-F]{24}$/', trim($cid));
            }));
            if (!empty($valid_csv_channels)) {
                $topic_info['buffer_channels'] = $valid_csv_channels;
            } elseif (!empty($buffer_channels)) {
                $topic_info['buffer_channels'] = $buffer_channels;
            }
            
            // TTS settings: use CSV values if provided
            // @FIX 1.4.9.56 (TTS SSOT): voiceover knobs come from Settings — the CSV
            // columns override only when the CSV explicitly provides them. Previously
            // rate was hardcoded 1.0, so CSV-imported jobs ignored the user's
            // Settings rate (e.g. 1.2) and their TTS ran slower/longer than every
            // other pipeline — which then hit the old 12.5s cap and got cut off.
            // Adaptive timing is computed from the REAL TTS durations generated with
            // these settings, so the scene length automatically matches "what the
            // checked settings will speak".
            $topic_info['voiceover'] = array(
                'enabled'              => get_option('mcqvs_tts_enabled', true) ? true : false,
                'provider'             => 'edge',
                'voice'                => class_exists('VS_Settings') ? VS_Settings::get_next_rotation_voice() : 'en-US-AriaNeural',
                'rate'                 => (float) get_option('mcqvs_tts_rate', 1.2),
                'pitch'                => 0.0,
                'speakHook'            => isset($topic_data['speakHook']) ? $topic_data['speakHook'] : (bool) get_option('mcqvs_tts_speak_hook', true),
                'speakOptions'         => isset($topic_data['speakOptions']) ? $topic_data['speakOptions'] : (bool) get_option('mcqvs_tts_speak_options', true),
                'speakAnswer'          => isset($topic_data['speakAnswer']) ? $topic_data['speakAnswer'] : (bool) get_option('mcqvs_tts_speak_answer', true),
                'speakCta'             => isset($topic_data['speakCta']) ? $topic_data['speakCta'] : (bool) get_option('mcqvs_tts_speak_cta', false),
                'answerPhrase'         => 'correct answer is',
                'webspeechCapturedAudio' => true,
            );
            
            // Difficulty: use CSV value if valid
            if (!empty($topic_data['difficulty']) && in_array($topic_data['difficulty'], array('easy', 'medium', 'hard'))) {
                $topic_info['difficulty'] = $topic_data['difficulty'];
            }

            // Platform: use CSV value if valid
            if (!empty($topic_data['platform']) && in_array($topic_data['platform'], array('all', 'mobile', 'desktop'))) {
                $topic_info['platform'] = $topic_data['platform'];
            }

            // Style colors: use CSV values if provided
            if (!empty($topic_data['bgColor'])) {
                $topic_info['bgColor'] = $topic_data['bgColor'];
            }
            if (!empty($topic_data['textColor'])) {
                $topic_info['textColor'] = $topic_data['textColor'];
            }
            if (!empty($topic_data['accentColor'])) {
                $topic_info['accentColor'] = $topic_data['accentColor'];
            }

            // Niche: preserve if provided
            if (!empty($topic_data['niche'])) {
                $topic_info['niche'] = $topic_data['niche'];
            }

            // @FIX 2026-08-06: Preserve _inline_questions collected during grouping
            if (!empty($topic_data['_inline_questions']) && is_array($topic_data['_inline_questions'])) {
                $topic_info['_inline_questions'] = $topic_data['_inline_questions'];
            }

            // @FIX 2026-08-06: Preserve _mcq_errors collected during grouping
            if (!empty($topic_data['_mcq_errors']) && is_array($topic_data['_mcq_errors'])) {
                $topic_info['_mcq_errors'] = $topic_data['_mcq_errors'];
            }

            $content_plan[] = $topic_info;
        }
        
        return $content_plan;
    }
    
    /**
     * Validate topic list.
     * 
     * @since 1.0.0
     * @param array $topics Array of topics to validate
     * @return array Validation results
     */
    public static function validate_topics($topics)
    {
        $errors = array();
        $warnings = array();
        
        // Check if topics array is valid
        if (!is_array($topics)) {
            $errors[] = 'Topics data is not in the correct format';
            return array('errors' => $errors, 'warnings' => $warnings);
        }
        
        foreach ($topics as $index => $topic) {
            // Ensure topic exists
            if (empty($topic['topic'])) {
                $errors[] = "Topic at line " . ($index + 2) . " is missing a topic name";
            }
            
            // Check for duplicates
            for ($i = $index + 1; $i < count($topics); $i++) {
                if (isset($topics[$i]['topic']) && 
                    $topics[$i]['topic'] === $topic['topic']) {
                    $warnings[] = "Topic '{$topic['topic']}' appears multiple times (line " . ($i + 2) . ")";
                }
            }
        }
        
        return array('errors' => $errors, 'warnings' => $warnings);
    }
    
    /**
     * Convert legacy format topics to enhanced content plan format.
     * Extracts topic names and descriptions, applies smart defaults and processing.
     * 
     * @since 1.0.0
     * @param array $topics_from_excel Topics from Excel/CSV file (simple format)
     * @param array $import_settings Import settings
     * @return array Content plan ready for saving
     */
    public static function convert_to_enhanced_content_plan($topics_from_excel, $import_settings)
    {
        $content_plan = array();
        
        foreach ($topics_from_excel as $topic_item) {
            $plan_entry = array();
            
            // Extract topic name - support both simple strings and structured objects
            $topic_name = '';
            $description = '';
            
            if (is_array($topic_item)) {
                $topic_name = $topic_item['topic'] ?? '';
                $description = $topic_item['description'] ?? '';
                
                // Preserve any additional fields from the original topic
                foreach ($topic_item as $key => $value) {
                    if (!in_array($key, array('topic', 'description'))) {
                        $plan_entry[$key] = $value;
                    }
                }
            } else {
                $topic_name = $topic_item;
            }
            
            if (empty($topic_name)) {
                continue;
            }
            
            $plan_entry['topic'] = $topic_name;
            
            if (!empty($description)) {
                $plan_entry['description'] = $description;
            }
            
            // Add scheduling settings only if not already provided by CSV/topic data
            if (empty($plan_entry['publish_date']) && !empty($import_settings['start_date'])) {
                $plan_entry['publish_date'] = $import_settings['start_date'];
                $plan_entry['publish_time'] = $import_settings['publish_time'] ?? '06:00';
                $plan_entry['publish_frequency'] = $import_settings['publish_frequency'] ?? 'daily';
                
                // Calculate day offset using the exact same logic as the legacy method
                $plan_entry['_publish_day_offset'] = count($content_plan);
            } elseif (!empty($plan_entry['publish_date']) && empty($plan_entry['publish_time'])) {
                // Have date but no time — fill in default
                $plan_entry['publish_time'] = $import_settings['publish_time'] ?? '09:00';
            }
            
            // Use the processing method to handle smart defaults
            $processed_topics = self::process_legacy_excel_content(array($plan_entry), $import_settings);
            if (!empty($processed_topics)) {
                $content_plan[] = $processed_topics[0]; // Extract the processed entry
            }
        }
        
        return $content_plan;
    }
    
    /**
     * Get import settings from Excel/CSV file (legacy format).
     * Detects file format and parses header row to extract basic metadata and topics.
     *
     * @since 1.0.0
     * @param string $file_content Raw file content
     * @return array Array with topics and import_settings for legacy file format
     */
    public static function get_legacy_import_settings_and_topics($file_content)
    {
        $topics = self::parse_excel_content($file_content);
        
        // Try to extract basic import settings based on user requirements
        $import_settings = array(
            'start_date' => gmdate('Y-m-d'),
            'publish_time' => get_option('mcqvs_default_publish_time', '09:00'),
            'publish_frequency' => 'daily',
            'videos_per_day' => 3,
            // @FIX 1.4.9.56: quizwire template removed — safe default is corporate.
            'template' => 'corporate',
            'music' => '',
            'font' => '',
            'bg_video' => '',
            'hook_visible' => true,
        );
        
        return array(
            'topics' => $topics,
            'settings' => $import_settings,
        );
    }
}
