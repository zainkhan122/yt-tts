<?php

/**
 * Main generation page view
 *
 * @package DIT_TrendStudio
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}
?>
<div class="wrap dit-ts-admin">
    <h1><?php esc_html_e('Generate Article', 'dit-trend-content-studio'); ?></h1>

    <div class="dit-ts-generator">

        <!-- @MODIFIED 2026-01-14 - Unified Intelligence Dashboard -->
        <div class="dit-ts-intelligence-box postbox" style="margin-bottom: 20px;">
            <div class="postbox-header">
                <h2 style="padding:10px 15px; margin:0;"><?php esc_html_e('Step 1: Intelligence & Strategy', 'dit-trend-content-studio'); ?></h2>
            </div>
            <div class="inside" style="padding:15px;">
                <p class="description" style="margin-top:0;">
                    <?php esc_html_e('Paste a competitor URL or a Brand Press Release. We will analyze it and auto-fill the strategy below.', 'dit-trend-content-studio'); ?>
                </p>

                <div style="display:flex; gap:20px; align-items:flex-start; margin-top:15px;">
                    <div style="flex:1;">
                        <textarea id="dit_ts_gap_source" name="dit_ts_gap_source" rows="3" class="large-text"
                            placeholder="<?php esc_attr_e('Paste Source URL or Text Content here...', 'dit-trend-content-studio'); ?>"></textarea>
                    </div>
                    <div style="width: 250px;">
                        <fieldset>
                            <legend class="screen-reader-text"><span><?php esc_html_e('Analysis Mode', 'dit-trend-content-studio'); ?></span></legend>
                            <label style="display:block; margin-bottom:8px;">
                                <input type="radio" name="dit_ts_analysis_mode" value="competitor" checked="checked">
                                <strong><?php esc_html_e('Competitor Gap', 'dit-trend-content-studio'); ?></strong>
                                <span class="description" style="display:block; font-size:11px; margin-left:24px;">Finds missing angles & weaknesses.</span>
                            </label>
                            <label style="display:block;">
                                <input type="radio" name="dit_ts_analysis_mode" value="brand">
                                <strong><?php esc_html_e('Brand Enhancement', 'dit-trend-content-studio'); ?></strong>
                                <span class="description" style="display:block; font-size:11px; margin-left:24px;">Elevates tone & preserves facts.</span>
                            </label>
                        </fieldset>
                        <button type="button" id="dit-ts-analyze-btn" class="button button-secondary button-hero" style="margin-top:15px; width:100%;">
                            <?php esc_html_e('Analyze Strategy', 'dit-trend-content-studio'); ?>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <form id="dit-ts-generate-form" class="dit-ts-form">
            <h2 style="padding: 0 0 10px 0; border-bottom: 1px solid #ccc; margin-bottom: 20px;"><?php esc_html_e('Step 2: Configuration & Generation', 'dit-trend-content-studio'); ?></h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="idea_source"><?php esc_html_e('Idea Source', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <select name="idea_source" id="idea_source">
                            <option value="manual"><?php esc_html_e('Manual Entry', 'dit-trend-content-studio'); ?>
                            </option>
                            <option value="inbox"><?php esc_html_e('From Idea Inbox', 'dit-trend-content-studio'); ?>
                            </option>
                        </select>
                    </td>
                </tr>

                <tr class="idea-inbox-row" style="display:none;">
                    <th scope="row">
                        <label for="idea_id"><?php esc_html_e('Select Idea', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <select name="idea_id" id="idea_id">
                            <option value=""><?php esc_html_e('-- Select an idea --', 'dit-trend-content-studio'); ?>
                            </option>
                            <?php foreach ($ideas as $idea): ?>
                                <option value="<?php echo esc_attr($idea->ID); ?>">
                                    <?php echo esc_html($idea->post_title); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <?php if (empty($ideas)): ?>
                            <p class="description">
                                <?php esc_html_e('No pending ideas. Import some ideas first.', 'dit-trend-content-studio'); ?>
                            </p>
                        <?php endif; ?>
                    </td>
                </tr>

                <tr class="manual-entry-row">
                    <th scope="row">
                        <label
                            for="idea_title"><?php esc_html_e('Topic / Title', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <input type="text" name="idea_title" id="idea_title" class="regular-text"
                            placeholder="<?php esc_attr_e('e.g., Celebrity Style at Met Gala 2025', 'dit-trend-content-studio'); ?>">
                        <div style="margin-top: 8px;">
                            <label>
                                <input type="checkbox" name="auto_source_images" id="auto_source_images" value="1">
                                <?php esc_html_e('Auto-Fetch Source Images (Google Lens / SerpApi based on Topic)', 'dit-trend-content-studio'); ?>
                            </label>
                        </div>
                    </td>
                </tr>

                <tr class="manual-entry-row">
                    <th scope="row">
                        <label
                            for="idea_text"><?php esc_html_e('Additional Context', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <textarea name="idea_text" id="idea_text" rows="4" class="large-text"
                            placeholder="<?php esc_attr_e('Any additional details, angles, or notes...', 'dit-trend-content-studio'); ?>"></textarea>
                    </td>
                </tr>

                <tr class="manual-entry-row">
                    <th scope="row">
                        <label for="source_urls"><?php esc_html_e('Source URLs', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <textarea name="source_urls" id="source_urls" rows="3" class="large-text"
                            placeholder="<?php esc_attr_e('One URL per line (optional)', 'dit-trend-content-studio'); ?>"></textarea>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="category"><?php esc_html_e('Category', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <select name="category" id="category">
                            <option value=""><?php esc_html_e('-- Select --', 'dit-trend-content-studio'); ?></option>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?php echo esc_attr($cat->name); ?>">
                                    <?php echo esc_html($cat->name); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label
                            for="vertical"><?php esc_html_e('Content Vertical', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <select name="vertical" id="vertical">
                            <option value="showbiz"><?php esc_html_e('Showbiz - General', 'dit-trend-content-studio'); ?></option>
                            <option value="fashion"><?php esc_html_e('Fashion - General', 'dit-trend-content-studio'); ?></option>
                            <option value="beauty"><?php esc_html_e('Beauty', 'dit-trend-content-studio'); ?></option>
                            <option value="showbiz_pk"><?php esc_html_e('Showbiz - PK', 'dit-trend-content-studio'); ?></option>
                            <option value="fashion_pk"><?php esc_html_e('Fashion - PK', 'dit-trend-content-studio'); ?></option>
                            <option value="lifestyle_pk"><?php esc_html_e('Lifestyle - PK (Mehndi/Nail Art)', 'dit-trend-content-studio'); ?></option>
                        </select>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="ai_strategy"><?php esc_html_e('AI Provider Strategy', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <select name="ai_strategy" id="ai_strategy">
			<option value=""><?php esc_html_e('-- Use Global Default --', 'dit-trend-content-studio'); ?></option>
			<option value="gemini"><?php esc_html_e('Gemini (Google Search Grounding)', 'dit-trend-content-studio'); ?></option>
                <option value="custom"><?php esc_html_e('Custom Provider (OpenAI-Compatible)', 'dit-trend-content-studio'); ?></option>
            </select>
        </td>
    </tr>

    <tr id="dit-ts-custom-provider-row" style="display:none;">
        <th scope="row">
            <label for="custom_provider_id"><?php esc_html_e('Custom Provider', 'dit-trend-content-studio'); ?></label>
        </th>
        <td>
            <select name="custom_provider_id" id="custom_provider_id">
                <option value=""><?php esc_html_e('-- Default Provider --', 'dit-trend-content-studio'); ?></option>
            </select>
        </td>
    </tr>

    <tr id="dit-ts-custom-model-row" style="display:none;">
        <th scope="row">
            <label for="custom_model_id"><?php esc_html_e('Custom Model', 'dit-trend-content-studio'); ?></label>
        </th>
        <td>
            <select name="custom_model_id" id="custom_model_id">
                <option value=""><?php esc_html_e('-- Default Model --', 'dit-trend-content-studio'); ?></option>
            </select>
            <p class="description"><?php esc_html_e('Select a specific model from the chosen provider, or leave as default.', 'dit-trend-content-studio'); ?></p>
        </td>
    </tr>

                <!-- @MODIFIED 2025-12-27 - SEO Targeting Fields -->
                <tr>
                    <th scope="row">
                        <label for="primary_keyword"><?php esc_html_e('Primary Keyword (SEO)', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <input type="text" name="primary_keyword" id="primary_keyword" class="regular-text"
                            placeholder="<?php esc_attr_e('e.g., winter 2026 coat trends', 'dit-trend-content-studio'); ?>">
                        <p class="description">
                            <?php esc_html_e('Main search term to optimize for. Will appear in title, first 100 words, one H2, and meta description.', 'dit-trend-content-studio'); ?>
                        </p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="search_intent"><?php esc_html_e('Content Strategy (Blueprint)', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <select name="search_intent" id="search_intent">
                            <option value="mixed" selected><?php esc_html_e('Standard Editorial (Balanced)', 'dit-trend-content-studio'); ?></option>
                            <option value="commercial"><?php esc_html_e('Commercial Review (Best for Affiliate)', 'dit-trend-content-studio'); ?></option>
                            <option value="informational"><?php esc_html_e('Deep Dive Explainer (Best for SEO)', 'dit-trend-content-studio'); ?></option>
                            <option value="news"><?php esc_html_e('News Cycle (Best for Trending)', 'dit-trend-content-studio'); ?></option>
                        </select>
                        <p class="description">
                            <?php esc_html_e('Selects the structural blueprint (e.g., Reviews get tables & verdict boxes).', 'dit-trend-content-studio'); ?>
                        </p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="editorial_angle"><?php esc_html_e('Editorial Persona', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <select name="editorial_angle" id="editorial_angle">
                            <option value="neutral" selected><?php esc_html_e('Objective / Neutral', 'dit-trend-content-studio'); ?></option>
                            <option value="skeptical"><?php esc_html_e('The Skeptic (Critical & Hard-hitting)', 'dit-trend-content-studio'); ?></option>
                            <option value="enthusiast"><?php esc_html_e('The Enthusiast (Excited & Positive)', 'dit-trend-content-studio'); ?></option>
                            <option value="educational"><?php esc_html_e('The Professor (Simple & Clear)', 'dit-trend-content-studio'); ?></option>
                        </select>
                        <p class="description">
                            <?php esc_html_e('Defines the voice constraints and vocabulary restrictions.', 'dit-trend-content-studio'); ?>
                        </p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">
                        <label for="secondary_keywords"><?php esc_html_e('Secondary Keywords', 'dit-trend-content-studio'); ?></label>
                    </th>
                    <td>
                        <input type="text" name="secondary_keywords" id="secondary_keywords" class="regular-text"
                            placeholder="<?php esc_attr_e('long coats, maxi coats, winter outerwear', 'dit-trend-content-studio'); ?>">
                        <p class="description">
                            <?php esc_html_e('Comma-separated. Optional supporting terms.', 'dit-trend-content-studio'); ?>
                        </p>
                    </td>
                </tr>
            </table>

            <p class="submit">
                <button type="submit" class="button button-primary" id="dit-ts-generate-btn">
                    <?php esc_html_e('Generate Article', 'dit-trend-content-studio'); ?>
                </button>
                <span class="spinner"></span>
            </p>
        </form>

        <!-- Status -->
        <div id="dit-ts-status" class="dit-ts-status" style="display:none;">
            <p class="status-message"></p>
            <div class="progress-bar">
                <div class="progress"></div>
            </div>
        </div>

        <!-- Preview -->
        <div id="dit-ts-preview" class="dit-ts-preview" style="display:none;">
            <h2><?php esc_html_e('Preview', 'dit-trend-content-studio'); ?></h2>

            <div class="dit-ts-preview-actions" style="margin-bottom: 15px; display: flex; gap: 10px;">
                <button type="button" class="button" id="dit-ts-copy-request"><?php esc_html_e('Copy Request', 'dit-trend-content-studio'); ?></button>
                <button type="button" class="button" id="dit-ts-copy-response"><?php esc_html_e('Copy Response', 'dit-trend-content-studio'); ?></button>
                <button type="button" class="button" id="dit-ts-copy-html"><?php esc_html_e('Copy HTML', 'dit-trend-content-studio'); ?></button>
            </div>

            <div class="dit-ts-validation">
                <h3><?php esc_html_e('Validation', 'dit-trend-content-studio'); ?></h3>
                <div class="validation-results"></div>
            </div>

            <div class="dit-ts-preview-content">
                <div class="preview-title"></div>
                <div class="preview-html"></div>
            </div>

            <p class="submit">
                <button type="button" class="button button-primary" id="dit-ts-publish-btn">
                    <?php esc_html_e('Save as Draft', 'dit-trend-content-studio'); ?>
                </button>
            </p>
        </div>
    </div>
</div>

<script>
    jQuery(document).ready(function($) {
        // Toggle idea source
        $('#idea_source').on('change', function() {
            if ($(this).val() === 'inbox') {
                $('.idea-inbox-row').show();
                $('.manual-entry-row').hide();
            } else {
                $('.idea-inbox-row').hide();
                $('.manual-entry-row').show();
            }
        });
    });
</script>