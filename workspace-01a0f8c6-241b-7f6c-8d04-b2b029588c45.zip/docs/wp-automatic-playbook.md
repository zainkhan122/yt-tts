# WordPress Automatic v6.3 — Deep Code Audit + Collection-Post Playbook
### How to get "one draft post per collection (with all its dresses)" from your top 3 sites

Audited from the actual plugin source you shared (`wp-automatic (1).zip`, v6.3.1, 330 files) — every claim below is traced to code, and every selector/endpoint was verified live against the stores.

---

# PART 1 — WHAT THE CODE ACTUALLY DOES

## 1.0 Plugin anatomy

| File | Role |
|---|---|
| `wp-automatic.php` | Bootstrap, campaign post type, license |
| `core.php` (503 KB) | Main class `wp_automatic`: the posting pipeline — item → filters → title/content build → **image download & gallery** → `wp_insert_post` |
| `core.feeds.php` | **Feeds** engine (also the engine Multi runs on) |
| `core.single.php` | **Single-page scraper** engine |
| `core.multi.php` | **Multi-page scraper** engine (a wrapper that *becomes* a Feeds campaign) |
| `p_metabox.php` + `metabox_*.php` | The campaign edit screen (all settings below) |
| `inc/class.dom.php` | DOM extraction: by class / id / XPath / regex, `getSimilarLinks()` for the visual selector |
| `inc/class.apify.php` | Apify.com rendering client (for JS pages) |
| `inc/wp_automatic_readability/` | "Auto detect full content" extraction |

**The pipeline:** WP-Cron → campaign → engine returns ONE item (`$temp` array: title, content, link) → `core.php` applies keyword filters, search/replace, strip rules, template → image handling (featured / download / gallery) → post created with `camp_post_status` (Draft/Publish/Pending/Private — set in the campaign's **Basic** box).

---

## 1.1 FEEDS engine (`camp_type = 'Feeds'`)

**Mental model:** feed in → many items out → **1 item = 1 post**.

Key mechanics found in `core.feeds.php`:

1. **Feed URLs** — textarea "Feeds to parse", one per line (`$camp->feeds`). Processes up to **3 feeds per run** (filterable via `wp_automatic_feed_max`), then dies and rotates next run. `OPT_RANDOM_FEEDS` shuffles them.
2. **Per item, in order:**
   - **Keyword filter** — campaign keywords (Basic box) matched against item title/content with the Filters-box modes (any/all/exact, require/skip words).
   - **Duplicate check** — item link checked against the campaign's duplicate cache (`wp_automatic_duplicate_cache` post meta) → already-posted items are skipped forever.
   - **Content build** — the dropdown **"Link to a single item extraction method"** (`cg_feed_extraction_method`) decides what the post body is. THIS is the field that decides everything for you:
     | Option | Code behavior |
     |---|---|
     | `auto` — "Auto detect full content" | **Visits the item's page** and extracts the article with Readability |
     | `summary` — "Post content from feed as-is" | Uses the feed's `<description>` (usually truncated) |
     | `visual` — visual selector | Visits item page, XPath from the point-and-click picker, finds *similar* blocks |
     | `css` — CSS selector (ID/Class/XPath) | Visits item page, extracts **each rule**; a rule can return **single** or **ALL matches** (all matches are joined with newlines into one post!) |
     | `regex` — REGEX | Visits item page, raw regex on the HTML |
   - CSS rules support multiple rules concatenated; per rule: `class`/`id`/`xpath`, **inner/outer** HTML, **single/all** matches.
3. **Strip/cleanup options:** strip by class/id (`OPT_STRIP_CSS`), strip by regex lines (`OPT_STRIP_R`), strip tags w/ allowed list (`OPT_STRIP_T`), min/max length checks, remove images (`OPT_STRIP_IMGS` / `OPT_REMOVE_IMAGES`).
4. **Extras:** og:image fallback for thumbnails, original tags/categories/author extraction (`OPT_ORIGINAL_*`), custom field mapping.

> ⚠️ The trap you fell into: a Feeds campaign pointed at a product feed = each dress is an item = one dress per post. Feeds is only right for you if **one feed item = one collection** (Multi manufactures exactly that — below).

---

## 1.2 SINGLE-page scraper (`camp_type = 'Single'`, `core.single.php`)

**Mental model:** ONE URL in → extract from that one page → ONE post.

- **Source URL** (`cg_sn_source`) + optional **cookie** header (`cg_sn_cookie`).
- **Title** method (`cg_sn_ttl_method`): auto (`<title>`), css (class/id/xpath), visual, regex.
- **Content** method (`cg_sn_cnt_method`):
  - `auto` = Readability full-page extraction,
  - `css` = **multi-rule array** (like Feeds) — each rule: class/id/xpath + **inner/outer** + **single/ALL matches**. *All matches* = every element with that class is captured and joined into ONE post. **This is the whole-collection grabber.**
  - `visual` / `regex` = multi-rule equivalents.
- **JS rendering:** tick *load using APIFY.com* (`OPT_FEED_APIFY`) + wait milliseconds (`cg_apify_wait_for_single`) → the page is fetched by a headless browser first. Falls back to curl on failure.
- Automatic lazy-load image fix (`lazy_loading_auto_fix`) and relative-path fix — product images in data-src get rescued.
- **Re-run behaviour** (`cg_sn_after`, shown when a Single campaign runs again) — the plugin md5-hashes title+content and compares with the last post:
  | Setting | Behavior |
  |---|---|
  | Create a new post each time (`justnew`) | always new post |
  | Delete previous post and create a new one each time (`delete`) | replace |
  | Delete previous post … if content got changed (`deletechange`) | replace only when changed |
  | Create new post when content changes (`new`) | keeps old, adds new |
  | **Update the same post when content changes (`update`)** | **the SAME post silently updates when the store adds dresses** |
- Always exactly 1 candidate post per run — no feed, no item loop.

---

## 1.3 MULTI-page scraper (`camp_type = 'Multi'`, `core.multi.php`)

**Mental model:** a listing page → harvest item LINKS → build a **virtual RSS feed** (an XML cached in `/wp-content/uploads/`) → hand it to the **Feeds engine**. So: *1 found link = 1 post*, and each found link's post content is controlled by the **Feeds** extraction settings ("Link to a single item extraction method").

Step by step in code:

1. **Link discovery** (`cg_ml_lnk_method`):
   - `visual` — XPath of the first item link → `getSimilarLinks()` finds all structurally similar links (the point-and-click picker).
   - `css` — class/id/xpath rules extract a region, then every `<a href>` inside it becomes an item (anchor text becomes the item title). Fallbacks: bare-URL regex, and numeric-ID lists (prefixed with the domain).
   - `regex` — regex-extract a region then parse links from it.
2. **Link rewriting** (very powerful for our use):
   - `OPT_MULTI_SEARCH_REPLACE` — lines of `search|replace` applied to every found link.
   - `OPT_MULTI_APPEND` — append a fixed string to every link.
3. **Pagination** (`cg_ml_cnt_method`): `auto` (off), `visual`/`css`/`regex` (extract the "next page" link; stored in `wp_automatic_nextpage`), `fixed` — a URL pattern with `[page_number]` (`cg_ml_page_2_url`, base + increment), and `infinite` (special mode using pasted content).
4. **Cache** (`cg_ml_cache`): when enabled, the harvested links feed is cached; next runs consume it (posting a few items per run) until exhausted, *then* re-harvests. **This is what makes "post N collections per run, remember where I stopped" work.**
5. **Fixed list mode** (`OPT_MULTI_FIXED_LIST` + `cg_multi_posts_list`): skip scraping entirely — paste a list of URLs, one per line; each line = one feed item = one post.
6. **Per-item title** (`cg_ml_ttl_method`): auto (anchor text) or css/visual/regex **from the item page**.
7. **Per-item content:** the Feeds "Link to a single item extraction method" settings — exactly as in §1.1.
8. Listing page can also be loaded via **Apify** (`OPT_FEED_APIFY2` + wait) — for JS listing pages. Cookies supported too.

---

## 1.4 The image & gallery pipeline (`metabox_imgs.php` + `core.php`)

- **Featured image:** `OPT_THUMB` "Set First image/Vid image as featured image" (+ strip-first-image, alt/caption/width options, `OPT_THUMB_WIDTH_CHECK` to skip thin banner images — set min width ~400px).
- **The money option —** `OPT_GALLERY_ALL`: **"Make all images from extracted content as a WordPress Gallery (Images will be downloaded)"**
  - Code effect (`core.php` ~1868): auto-enables `OPT_CACHE` + `OPT_FEED_MEDIA` → every `<img>` in the extracted content is **downloaded into your Media Library**, attached, and a native **Gutenberg gallery block** (or classic `[gallery ids="…"]` with `OPT_FEED_GALLERY_OLD`) is appended.
  - Sub-options: remove images from content after gallery (`OPT_FEED_GALLERY_DELETE`), add gallery even if only one image (`OPT_FEED_GALLERY_LIMIT`), link gallery to media file/attachment page.
- Without `OPT_CACHE`-family options, images stay **hotlinked** to the store CDN (fast, no hosting cost, but not your copies).
- `OPT_REMOVE_IMAGES` strips all images if you ever want text-only drafts.

So the recipe shape for every site is:
> **capture the whole product grid into the content of ONE item → tick OPT_GALLERY_ALL → Draft.**

---

# PART 2 — SITE PLAYBOOKS (top 3 sites, exact settings)

Verified live numbers before configuring:

| Fact | Sanaulla | The Fashion Station | Laam |
|---|---|---|---|
| Platform | Shopify | WordPress/Woo (Flatsome) | Nuxt JS app |
| Collection page renders (server-side) | **all dresses** up to big ones (Afrozeh 59/59, Maria B 23/23; a 250-product collection showed 12 — paginated) | 8 per category page | first ~15 dresses, rest via JS |
| Dress card class (verified) | `grid-product__content` / card `grid__item grid-product` | `product-small` (text: `box-text-products`) | obfuscated classes — use visual picker |
| Collections index | `/collections` — 466 links, cards `a.collection-item` | category URLs = collections (sitemap 404s → use fixed list) | `/drops-sitemap.xml` |
| Needs Apify | no | no | **yes** (per item page) |

**Settings common to every campaign below** (Basic box): Post Type = Post, **Post Status = Draft**, assign a category like "Collections". Test each campaign with **Run Now** from the campaign list and watch the log panel — it prints every extraction step (`Extracting content by class: … <-- N chars`).

---

## 2.1 🥇 SANAULLA — Multi-page scraper: auto-discover ALL collections, 1 draft each

*This is the flagship setup: it walks Sanaulla's own collections index and turns every collection into one draft post containing that collection's dresses.*

**Campaign → Add New → Campaign Type: Multi-page scraper**

### A. Link harvesting (the listing page)
| Field | Value |
|---|---|
| Source URL (`cg_ml_source`) | `https://sanaullastore.com/collections` |
| Link extraction method | **CSS selector** → type **class** → value `collection-item` → matches **all**, wrap *inner* |
| (alternative) | Visual Selector: click the first collection tile on that page |
| Pagination | `auto` (the index already exposes 466 links server-side — verified) |
| Search/replace on links | *(empty)* |
| Append to links | *(empty)* |
| Cache | **enabled** — posts a few collections per run and remembers where it stopped |

Result of step A: a virtual feed of 466 collection URLs; item titles = the collection names (anchor text).

### B. Per-item (each collection) — these live in the Feeds-style boxes of the same campaign
| Field | Value |
|---|---|
| Item title (`cg_ml_ttl_method`) | CSS → xpath `//h1` → inner (clean collection name from the collection page; fallback: auto) |
| **Link to a single item extraction method** | **CSS selector** → type **class** → value `grid-product__content` → **ALL matches** → inner |
| What this captures | every dress card's photo + name + price block for that collection, joined into ONE post body |

### C. Images box
- ✅ Set First image as featured image
- ✅ Check image width, min **400px** (kills logos/icons)
- ✅ **Make all images from extracted content as a WordPress Gallery (Images will be downloaded)**
- ❌ don't tick "Remove the images from the post content" (keep dresses inline + gallery)

### D. What you get / limits
- One draft per collection; gallery = every dress photo of that collection; inline cards keep names + PKR prices.
- Big collections (100+ dresses, e.g. Sana Safinaz 250) render ~12 on page 1 → the draft gets those 12. Fine for "all or few dresses" rewriting; for the full 250 use the `collection-post-generator.php` plugin from last session (uses `products.json`).
- Each collection is posted **once** (duplicate cache). Later restocks → use campaign 2.2 for hot collections.

### E. Optional filters
- Put brand keywords (e.g. `Maria B, Sana Safinaz, Afrozeh`) in the campaign keywords + "any" mode → only those collections become posts. Or add `Opt no links containing` style filters via the Filters box (skip words like `sale`, `shoes`).

---

## 2.2 SANAULLA — Single-page scraper: living draft per hot collection (auto-updates)

*For collections you actively cover (New Arrivals, a brand's current line) — the SAME draft silently updates when the store adds dresses.*

**Campaign Type: Single-page scraper**

| Field | Value |
|---|---|
| Source URL | `https://sanaullastore.com/collections/new-arrival` *(or any /collections/{handle})* |
| Title | CSS → xpath `//h1` → inner |
| Content | CSS → class `grid-product__content` → **ALL matches** → inner |
| APIFY | off (Shopify pages are static HTML) |
| **When campaign runs again** | **"Update the same post when content changes"** — hash-checked; if new dresses appeared, the draft updates; if nothing changed, nothing happens |
| Run frequency | daily (campaign schedule) |
| Images | same as §2.1 C |

Result: `New Arrivals — Sanaulla` draft that grows with the store, gallery included. Clone this campaign per collection you care about.

---

## 2.3 🥈 THE FASHION STATION — Multi-page scraper with a FIXED LIST of collection URLs

*Their product categories ARE designer collections, but the category sitemap 404s and nav pages are messy — so feed WPA the exact list (curated from their public categories API in 2 minutes).*

**Step 1 — build your list.** Open in a browser:
```
https://www.thefashionstation.in/wp-json/wc/store/v1/products/categories?per_page=100
```
Every collection is there with its dress count (`"name":"Bloom Lawn 2026 by Saira Shakira","slug":"bloom-lawn-2026-by-saira-shakira","count":16`). Each slug becomes:
```
https://www.thefashionstation.in/product-category/{slug}/
```
Paste as many as you want, one per line.

**Step 2 — Campaign Type: Multi-page scraper**

| Field | Value |
|---|---|
| **Fixed list option** (`OPT_MULTI_FIXED_LIST`) | ✅ tick "post from a fixed list of links" |
| Links list (`cg_multi_posts_list`) | your URLs, one per line |
| Cache | **enabled** (consumes the list across runs, a few posts per run) |
| Pagination | auto |
| Item title (`cg_ml_ttl_method`) | **regex** → `<h1[^>]*>(.*?)</h1>` (robust across Flatsome pages; fallback auto) |
| **Link to a single item extraction method** | **CSS selector** → type **class** → value `product-small` → **ALL matches** → inner |
| Images | featured + width check 400px + **Gallery (downloaded)** — same as §2.1 C |

**What you get:** one draft per collection, e.g. *Bloom Lawn 2026 by Saira Shakira* with its 8 on-page dresses (name + ₹ price + photo each) and a downloaded gallery. Their collections average 6–20 dresses; the page shows 8 → for the long tail use the plugin/Apify route, or append `/page/2/` of the same category as a second list line (it lands as a second draft you merge while rewriting).

**Tips**
- Prices are ₹ INR — that's a rewrite task (or search/replace `₹`→`Rs` won't convert values; just delete prices in content via strip regex `{:price:}` if you prefer no prices).
- Keyword filter the list by season (`2026`, `Lawn`, `Festive`) to control volume.
- New collections appear in the API weekly → paste the new URL into the fixed list; cache picks it up next run.

### Variant — single collection deep-dive
Single-page scraper, Source = the category URL, content class `product-small` all-matches, re-run mode `update`. Same mechanics as §2.2.

---

## 2.4 🥉 LAAM — Single-page scraper + APIFY (JS rendering), update mode

*Laam's drop pages build in the browser; the plugin's curl fetch only sees ~15 dresses in escaped JSON. Apify renders the page first.*

**One-time:** Apify.com account → copy API key → WPA Settings → Apify key field (`wp_automatic_apify_key`).

**Campaign Type: Single-page scraper**

| Field | Value |
|---|---|
| Source URL | a drop URL, e.g. `https://laam.com/drops/mohagni-winter-2025` (browse `laam.com/drops-sitemap.xml`, or open laam.com → New In → click a collection cover and copy the URL) |
| **Load using APIFY.com** (`OPT_FEED_APIFY`) | ✅ |
| Wait before content load | **5000** ms (let the grid and images populate; raise to 8000 if galleries miss items) |
| Title | regex `<h1[^>]*>(.*?)</h1>` |
| Content | **Visual Selector**: after a test run, use the picker on one product card in the rendered page → it generates an XPath; keep **ALL matches**. (Laam's class names are machine-generated — the picker is the reliable way; `getSimilarLinks/getSimilarBlocks` then grabs every card.) |
| **When campaign runs again** | **update** (drops grow — the draft grows with them) |
| Images | featured + width check 400px + **Gallery (downloaded)** |
| Run | manual or weekly; each run ≈ 1 Apify render (~fraction of a cent) |

**What you get:** one draft per drop with the rendered dresses (typically the first 15–30 — infinite-scroll depth depends on render wait). This is the *editorial* source — best coverage of brand-new drops, weakest completeness.

**Do NOT** use a Multi campaign for Laam drops: the per-item pages inside Feeds are fetched by plain curl (no Apify in that path) → you'd get the escaped-JSON shell, not dresses. Multi+Apify only renders the *listing* page.

---

# PART 4 — Addendum: the 15-images / 3-posts-per-day architecture (v1.1)

## Verdict: WPA. Apify only as an optional renderer inside WPA (for Laam).

At 15 images and 3 posts per day, a standalone Apify pipeline is over-engineering: you'd pay monthly, maintain JSON→WordPress glue (application passwords, webhooks/n8n), and still end up rewriting drafts by hand. WPA already does drafts, galleries, dedupe and scheduling natively — at this volume it costs nothing and nothing breaks.

### Enforcing 15 images max
The plugin has **no built-in image-count cap** (audited: only a min-width filter exists), so cap at the extraction layer — verified the XPath engine is real `DOMXPath`, so positional predicates work:

| Campaign | Content rule (XPath, ALL matches) | Extra strip rule |
|---|---|---|
| Sanaulla | `//div[contains(@class,'grid-product__content')][position()<=15]` | strip class `grid-product__secondary-image` (kills the hover image → 15 cards = exactly 15 imgs) |
| Fashion Station | `//div[contains(@class,'product-small')][position()<=15]` | — (1 image per card) |
| Laam (if used) | visual-picker XPath on the card, then append `[position()<=15]` to it | — |

Enter these as **CSS selector → xPath** rules (not "class") — everything else in Part 2 stays the same. Gallery checkbox unchanged; you end with ≤15 downloaded images + featured image.

### Enforcing 3 posts per day
Code fact: one campaign run = **exactly one post** (the Feeds engine returns a single item). The schedule box (`Every [n] Minutes/Hours/Days`) therefore directly sets posts/day:

| Campaign | Schedule | Output |
|---|---|---|
| Sanaulla Multi (collections index, cache ON) | every **12 hours** | 2 collections/day |
| Fashion Station Multi (fixed list, cache ON) | every **1440 minutes (1 day)** | 1 collection/day |
| **Total** | | **3 drafts/day** |

- Multi's link cache hands each run the next unposted collection — the 466-collection list ≈ 5 months of runway at this pace.
- Any Single-page "living draft" campaigns (update mode) don't count: they only update an existing draft when content changes, they don't add posts.
- Rebalance anytime (e.g. 2×TFS + 1×Sanaulla) by changing the two schedule values.

### Where Apify fits (and its real cost)
- Only Laam needs rendering. WPA → Settings → Apify token → tick *load using APIFY.com* on the Laam Single-page campaign (5,000 ms wait, update mode).
- WPA calls Apify's official `apify~web-scraper` actor per run (verified in `inc/class.apify.php`). At ≤3 renders/day (~90/month) this sits **inside Apify's free $5 monthly credit** — effectively $0.
- Skip Laam entirely → you never need Apify at all.

### Standalone-Apify would only win if…
…you later want 30+ posts/day, per-dress structured data (price tables/CSV), Laam at scale, or publishing to non-WordPress destinations. Until then it's cost + glue code with no gain. For full-catalog backfills of huge collections (250+ dresses), keep `collection-post-generator.php` as the manual backstop — it caps images per dress and can be rate-limited the same way.

---

# PART 3 — Cheat sheet & troubleshooting

## Which campaign type for what (from the code)
| Situation | Use |
|---|---|
| One page that already lists the whole collection | **Single-page** + css class of the product card + ALL matches + gallery |
| A page that lists many collections → one post per collection | **Multi-page** on the collections index; per-item extraction grabs each collection's grid |
| You already know the exact collection URLs | **Multi-page + fixed list** (or N clones of Single-page) |
| Page builds with JavaScript | Single-page **+ Apify** (per-item pages in Multi don't get Apify) |
| Collection that keeps growing | Single-page with re-run = **update** (content-hash change detection) |

## Exact UI labels → code names (for reference)
| UI label | option / field |
|---|---|
| "Set First image/Vid image as featured image" | `OPT_THUMB` |
| "Make all images from extracted content as a WordPress Gallery (Images will be downloaded)" | `OPT_GALLERY_ALL` (auto-enables image caching + media import) |
| "Add the gallery even if there is only one image available" | `OPT_FEED_GALLERY_LIMIT` |
| "Check image width…" min width | `OPT_THUMB_WIDTH_CHECK` / `cg_minimum_width` |
| "Link to a single item extraction method" (Feeds & Multi per-item) | `cg_feed_extraction_method` + rules (`cg_feed_custom_id`, single/all per rule) |
| Multi: fixed list / search|replace / append | `OPT_MULTI_FIXED_LIST`+`cg_multi_posts_list` / `OPT_MULTI_SEARCH_REPLACE` / `OPT_MULTI_APPEND` |
| Multi: cache found links | `cg_ml_cache` |
| Single: "When campaign runs again" = update | `cg_sn_after='update'` (+`wp_automatic_previous_hash`) |
| Single/Multi: "Load the content using APIFY.com" + wait | `OPT_FEED_APIFY`/`OPT_FEED_APIFY2` + `cg_apify_wait_for(_single)` |
| Post Status (Draft/Published/…) | `camp_post_status` (Basic box) |

## Troubleshooting quick hits
- **Log says `Extracting content by class: … <-- 0 chars`** → wrong class or the page paginates/lazy-loads: try the visual selector, check the class against "View page source" (Ctrl+U, not DevTools Elements — DevTools shows JS-injected nodes curl can't see).
- **Posts contain 1 dress each** → you're in per-dress items (feed of products or item links = dresses). Re-point the campaign at the collection level (§2.1/§2.3).
- **Gallery empty** → extraction rules captured text without `<img>`; ensure the rule wraps the card element that contains the image (e.g. `product-small`, `grid-product__content`), and enable `OPT_GALLERY_ALL`.
- **Same collection posted twice** → you cloned a campaign without its duplicate cache; that's expected — each campaign dedupes independently.
- **Big Sanaulla collections truncated at ~12** → theme pagination; accept page 1 for drafts, or run `collection-post-generator.php` (products.json route) for the full set.
- **WPA cron idle** → no traffic / DISABLE_WP_CRON; trigger manually with Run Now, or set a real cron hitting `wp-cron.php`.

## Rights reminder
All three setups pull photos the stores host. Drafts-for-rewriting with a source link is the sane, low-risk workflow you already planned; prefer hotlinked (non-downloaded) images where you can, and keep galleries only where you'll actually edit that post into something of your own.
