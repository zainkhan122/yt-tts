<?php
namespace AiSocialCollage\Services;

use AiSocialCollage\Config;
use AiSocialCollage\Logger;
use AiSocialCollage\Services\GeminiProvider;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AutoHashtagGenerator {
	
	/**
	 * Generate hashtags based on content analysis
	 *
	 * @param int $post_id Post ID
	 * @param string $strategy 'ai' or 'trending'
	 * @return array Generated hashtags
	 */
	public static function generate_hashtags( $post_id, $strategy = 'ai' ) {
		if ( $strategy === 'trending' ) {
			return self::get_trending_hashtags_pakistan();
		}
		
		return self::ai_generate_hashtags( $post_id );
	}
	
	/**
	 * AI-generate context-aware hashtags
	 *
	 * @param int $post_id Post ID
	 * @return array Hashtags
	 */
	private static function ai_generate_hashtags( $post_id ) {
		$title = get_the_title( $post_id );
		$content = get_post_field( 'post_content', $post_id );
		
		if ( empty( $title ) && empty( $content ) ) {
			return [];
		}
		
		$gen_ai = new GeminiProvider();
		$prompt = "Generate EXACTLY 5 highly relevant hashtags for this post, optimized for X/Twitter and Instagram engagement.
CRITICAL RULES:
1. Generate EXACTLY 5 hashtags — no more, no less.
2. Hashtags MUST be in English for maximum algorithmic reach.
3. Each hashtag must be DIRECTLY relevant to the specific content of this post — no generic filler tags.
4. Follow X/Instagram hashtag style: short, punchy, camel-case (e.g., #BreakingNews, #TrendingPakistan).
5. Mix: 2-3 topic-specific tags + 1-2 trending/reach tags + 1 niche/community tag.
6. NO generic tags like #News, #Pakistan, #Viral — be specific to THIS story.

Title: {$title}
Content: " . wp_trim_words( $content, 50 ) . "

Return ONLY a JSON array of exactly 5 hashtag strings. Example: [\"#ErlingHaaland\", \"#FootballNews\", \"#SportsUpdate\", \"#TrendingNow\", \"#GoalMachine\"]";
		
 		try {
 			$response = AIProviderRegistry::execute( $gen_ai, $prompt, 'You are a hashtag generator.', [
				'job_id' => null,
				'caller' => 'AutoHashtagGenerator::ai_generate_hashtags',
			] );

 			if ( ! is_array( $response ) ) {
 				return self::get_default_pakistani_tags();
 			}

 			if ( isset( $response['hashtags'] ) ) {
 				if ( is_string( $response['hashtags'] ) ) {
 					preg_match_all( '/#[\w\x{600}-\x{6FF}]+/u', $response['hashtags'], $matches );
 					if ( ! empty( $matches[0] ) ) {
 						$hashtags = array_unique( array_slice( $matches[0], 0, 5 ) );
 						update_post_meta( $post_id, Config::META_GENERATED_HASHTAGS, $hashtags );
 						return $hashtags;
 					}
 				} elseif ( is_array( $response['hashtags'] ) ) {
 					$hashtags = array_filter( $response['hashtags'], 'is_string' );
 					if ( ! empty( $hashtags ) ) {
						$hashtags = array_values( array_unique( $hashtags ) );
						$hashtags = array_slice( $hashtags, 0, 5 );
						update_post_meta( $post_id, Config::META_GENERATED_HASHTAGS, $hashtags );
						return $hashtags;
 					}
 				}
 			}

 			if ( isset( $response[0] ) && is_string( $response[0] ) ) {
 				$hashtags = array_filter( $response, 'is_string' );
 				if ( ! empty( $hashtags ) ) {
					$hashtags = array_values( array_unique( $hashtags ) );
					$hashtags = array_slice( $hashtags, 0, 5 );
					update_post_meta( $post_id, Config::META_GENERATED_HASHTAGS, $hashtags );
					return $hashtags;
 				}
 			}

 			$subject = wp_json_encode( $response );
 			preg_match_all( '/#[\w\x{600}-\x{6FF}]+/u', $subject, $matches );
 			if ( ! empty( $matches[0] ) ) {
 				$hashtags = array_unique( array_slice( $matches[0], 0, 5 ) );
 				update_post_meta( $post_id, Config::META_GENERATED_HASHTAGS, $hashtags );
 				return $hashtags;
 			}
 		} catch ( \Exception $e ) {
			Logger::warning( 'hashtag_generation_failed', null, [
				'post_id' => $post_id,
				'error' => $e->getMessage(),
			], '500' );
		}
		
		// Fallback to default Pakistani tags
		return self::get_default_pakistani_tags();
	}
	
	/**
	 * Get trending topics from Twitter (if API available) or AI estimation
	 *
	 * @return array Trending hashtags
	 */
	private static function get_trending_hashtags_pakistan() {
		// Try to get cached trending topics
		$cache_key = 'ai_collage_trending_pakistan';
		$cache_time = 3600; // 1 hour
		
		$trending = get_transient( $cache_key );
		if ( $trending ) {
			return $trending;
		}
		
		// Free method: AI estimation of likely trending topics
		// In production, integrate Twitter API v2 if budget allows
		$trending = [
			'#Pakistan',
			'#PakistanNews',
			'#ImranKhan',
			'#ShehbazSharif',
			'#PTI',
			'#PMLN',
			'#PPP',
			'#Cricket',
			'#PCB',
			'#T20',
			'#Economy',
			'#PetrolPrices',
			'#Inflation',
			'#Weather',
		];
		
		set_transient( $cache_key, $trending, $cache_time );
		
		return $trending;
	}
	
	/**
	 * Default Pakistani hashtags fallback
	 *
	 * @return array Default tags
	 */
	private static function get_default_pakistani_tags() {
		return [
			'#Pakistan',
			'#PakistanNews',
			'#TrendingNow',
			'#JustIn',
			'#Update',
		];
	}
	
	/**
	 * Format hashtags for social platforms
	 *
	 * @param array $hashtags Hashtag array
	 * @param int $max Maximum number to return
	 * @return string Formatted hashtag string
	 */
	public static function format_hashtags( $hashtags, $max = 5 ) {
		if ( empty( $hashtags ) ) {
			return '';
		}
		
		$limited = array_slice( $hashtags, 0, $max );
		return implode( ' ', $limited );
	}
}
