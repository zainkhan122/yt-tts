<?php

/**
 * AJAX Handler for Video Cover Settings
 *
 * Manages per-job cover image configuration (background color, badge style, etc.)
 * and generates cover images for the Studio Editor and Content Planner.
 *
 * @package MCQ_Video_Studio
 * @since 1.5.0
 */

if (! defined('ABSPATH')) {
    exit;
}

class VS_AJAX_Cover_Handler
{
    private static $instance = null;

    public static function get_instance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * AJAX: Save cover configuration for a specific job/project.
     * Stored in job settings as 'cover_config' key.
     */
    public function ajax_save_cover_config()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        $job_id = sanitize_text_field(wp_unslash($_POST['job_id'] ?? ''));
        if (empty($job_id)) {
            wp_send_json_error('Job ID required');
        }

        // @NEW 2026-08-11: `mode` — cover image source: 'scene' (branded cover scene at
        //       frame 0) or 'first_q_mid' (frame at 50% of the first question's duration).
        //       Consumed by render-node cover extraction + Studio cover card preview.
        $mode = sanitize_text_field(wp_unslash($_POST['mode'] ?? 'scene'));
        if (!in_array($mode, array('scene', 'first_q_mid'), true)) {
            $mode = 'scene';
        }

        $cover_config = array(
            'enabled'       => ! empty($_POST['enabled']),
            'bg_color'      => sanitize_hex_color(wp_unslash($_POST['bg_color'] ?? '')),
            'badge_style'   => sanitize_text_field(wp_unslash($_POST['badge_style'] ?? 'gold')),
            'show_logo'     => ! empty($_POST['show_logo']),
            'brand_size'    => sanitize_text_field(wp_unslash($_POST['brand_size'] ?? 'large')),
            'mode'          => $mode,
        );

        if (class_exists('VS_Job_Repository')) {
            $job_repo = VS_Job_Repository::init();
            $job = $job_repo->get_job($job_id);
            if ($job) {
                $settings = is_string($job['settings'] ?? '') ? json_decode($job['settings'], true) : ($job['settings'] ?? array());
                if (!is_array($settings)) {
                    $settings = array();
                }
                $settings['cover_config'] = $cover_config;
                $job_repo->update_job_fields($job_id, array('settings' => wp_json_encode($settings)));
            }
        }

        wp_send_json_success(array('message' => 'Cover config saved', 'cover_config' => $cover_config));
    }

    /**
     * AJAX: Get cover configuration for a job/project.
     * Merges saved per-job config with global branding defaults.
     */
    public function ajax_get_cover_config()
    {
        check_ajax_referer('mcqvs_studio_nonce', 'nonce');
        if (! current_user_can('manage_options')) {
            wp_send_json_error('Access denied');
        }

        $job_id = sanitize_text_field(wp_unslash($_POST['job_id'] ?? ''));
        $cover_config = array();

        if (! empty($job_id) && class_exists('VS_Job_Repository')) {
            $job_repo = VS_Job_Repository::init();
            $job = $job_repo->get_job($job_id);
            if ($job) {
                $settings = is_string($job['settings'] ?? '') ? json_decode($job['settings'], true) : ($job['settings'] ?? array());
                if (is_array($settings) && !empty($settings['cover_config'])) {
                    $cover_config = $settings['cover_config'];
                }
            }
        }

        $branding = get_option('MCQVS_studio_branding', array());

        wp_send_json_success(array(
            'cover_config' => wp_parse_args($cover_config, array(
                'enabled'     => true,
                'bg_color'    => '',
                'badge_style' => 'gold',
                'show_logo'   => true,
                'brand_size'  => 'large',
                'mode'        => 'scene',
            )),
            'branding' => array(
                'brand_name' => $branding['brand_name'] ?? 'Quiz Master',
                'quiz_name'  => $branding['quiz_name'] ?? '',
                'logo_url'   => $branding['logo_url'] ?? '',
            ),
        ));
    }
}