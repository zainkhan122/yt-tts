<?php
namespace AiSocialCollage\Services\ImageAI;

use AiSocialCollage\Config;
use AiSocialCollage\Contracts\ImageAIProviderInterface;
use AiSocialCollage\Logger;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PollinationsProvider implements ImageAIProviderInterface {

	private $api_key;

	public function __construct( $api_key = '' ) {
		$this->api_key = $api_key;
	}

	public function generate_image( $prompt, $width = 1080, $height = 1350 ) {
		$url = 'https://image.pollinations.ai/prompt/' . urlencode( $prompt ) . '?width=' . (int) $width . '&height=' . (int) $height . '&nologo=true&seed=' . wp_rand( 1, 999999 );

		if ( ! empty( $this->api_key ) ) {
			$url .= '&pk=' . urlencode( $this->api_key );
		}

		$response = wp_remote_get( $url, [
			'timeout' => 120,
			'headers' => [ 'Accept' => 'image/png' ],
		] );

		if ( is_wp_error( $response ) ) {
			Logger::error( 'pollinations_image_error', null, [ 'error' => $response->get_error_message() ], '500' );
			throw new \Exception( 'Pollinations AI request failed: ' . $response->get_error_message() );
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( $code !== 200 ) {
			$body = wp_remote_retrieve_body( $response );
			Logger::error( 'pollinations_image_error', null, [ 'code' => $code, 'body' => mb_substr( $body, 0, 500 ) ], '500' );
			throw new \Exception( "Pollinations AI returned HTTP {$code}" );
		}

		$image_data = wp_remote_retrieve_body( $response );
		if ( empty( $image_data ) || strlen( $image_data ) < 1000 ) {
			throw new \Exception( 'Pollinations AI returned empty or invalid image data' );
		}

		return $this->save_temp_image( $image_data );
	}

	private function save_temp_image( $data ) {
		$temp_dir = AI_SOCIAL_COLLAGE_PATH . 'assets/temp';
		if ( ! is_dir( $temp_dir ) ) {
			wp_mkdir_p( $temp_dir );
		}

		$filename = 'ai_gen_' . uniqid() . '.png';
		$path = $temp_dir . '/' . $filename;
		file_put_contents( $path, $data );

		return $path;
	}

	public function get_provider_name() {
		return Config::PROVIDER_IMAGE_POLLINATIONS;
	}

	public function get_model_name() {
		return 'pollinations-flux';
	}
}
