<?php

/**
 * Topic Pillar Article Generator
 *
 * Generates evergreen, SEO / AIO / LLMO-optimized "pillar" articles (800–1500 words)
 * for selected parent topics (+ optional exams), each as a standalone `post` tagged
 * with that topic. Pillars are saved DRAFT-first for review and, when the Scheduler
 * (smart scheduler) is enabled, queued via `_nm_ready_for_publish` so they publish on
 * the same human-like timing as MCQs and roundup articles.
 *
 * Cadence: one pillar per selected topic every N configured days.
 *
 * @package wp-news-mcq-generator
 * @since   9.4.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class NM_Topic_Pillar_Generator {

	/** Option key controlling whether pillar generation is enabled. */
	const OPTION_ENABLED = 'nm_pillar_generation_enabled';

	/** Option key storing selected parent-topic term IDs (array). */
	const OPTION_TOPICS = 'nm_pillar_topics';

	/** Option key storing selected exam term IDs (array, optional). */
	const OPTION_EXAMS = 'nm_pillar_exams';

	/** Option key storing cadence in days (one pillar per topic every N days). */
	const OPTION_INTERVAL_DAYS = 'nm_pillar_interval_days';

	/** Option key storing a global daily cap (so a burst of overdue topics doesn't flood). */
	const OPTION_DAILY_LIMIT = 'nm_pillar_daily_limit';

	/**
	 * Cron hook for the daily pillar sweep.
	 */
	const CRON_HOOK = 'nm_pillar_generation_cron';

	/** Singleton. */
	private static $instance = null;

	public static function init() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		// Run the daily pillar sweep.
		add_action( self::CRON_HOOK, array( $this, 'run_cron' ) );
		// Pillar posts carry _nm_article_generated = 'yes', so the Article + FAQ schema
		// injector already registered by NM_News_Article_Generator::init() applies to them.
	}

	/* ------------------------------------------------------------------
	 * Settings getters
	 * ---------------------------------------------------------------- */

	public static function is_enabled() {
		return (bool) get_option( self::OPTION_ENABLED, 0 );
	}

	/** @return int[] Selected parent topic term IDs. */
	public static function get_topics() {
		$t = get_option( self::OPTION_TOPICS, array() );
		return is_array( $t ) ? array_values( array_filter( array_map( 'absint', $t ) ) ) : array();
	}

	/** @return int[] Selected exam term IDs. */
	public static function get_exams() {
		$t = get_option( self::OPTION_EXAMS, array() );
		return is_array( $t ) ? array_values( array_filter( array_map( 'absint', $t ) ) ) : array();
	}

	/** @return int Cadence in days. */
	public static function interval_days() {
		// @FIX 9.5.2: Default raised 7 → 30. Pillars are refreshed IN PLACE (see
		// generate_pillar), so a monthly refresh is the sensible evergreen cadence.
		return max( 1, (int) get_option( self::OPTION_INTERVAL_DAYS, 30 ) );
	}

	/** @return int Global daily cap. */
	public static function daily_limit() {
		return max( 1, (int) get_option( self::OPTION_DAILY_LIMIT, 3 ) );
	}

	/* ------------------------------------------------------------------
	 * Cron
	 * ---------------------------------------------------------------- */

	/**
	 * Daily sweep: for each selected topic that is "due", generate one pillar,
	 * respecting the daily cap. Runs via NM_Cron_Manager::schedule_all_crons.
	 */
	public static function run_cron() {
		if ( ! self::is_enabled() ) {
			return;
		}
		$topics = self::get_topics();
		if ( empty( $topics ) ) {
			return;
		}

		// Rotate so topics aren't always processed in the same order across sweeps.
		shuffle( $topics );

		$limit    = self::daily_limit();
		$interval = self::interval_days();
		$made     = 0;
		$failed   = array();

		foreach ( $topics as $term_id ) {
			if ( $made >= $limit ) {
				break;
			}
			if ( ! self::is_due( $term_id, $interval ) ) {
				continue;
			}
			$result = self::generate_pillar( $term_id );
			if ( is_numeric( $result ) ) {
				$made++;
			} else {
				$err  = is_wp_error( $result ) ? $result->get_error_message() : 'Unknown error';
				$term = get_term( $term_id, 'topic' );
				$name = ( $term && ! is_wp_error( $term ) ) ? $term->name : ( '#' . $term_id );
				$failed[] = $name . ' (' . $err . ')';
			}
		}

		if ( class_exists( 'NM_Generation_Logger' ) ) {
			NM_Generation_Logger::nm_log_activity(
				sprintf( '[PILLAR CRON] Sweep complete: generated %d pillar(s).%s', $made, $failed ? ' Failures: ' . implode( '; ', $failed ) : '' ),
				$failed ? 'warning' : 'info'
			);
		}
	}

	/**
	 * Whether a topic is due for a new pillar.
	 *
	 * @param int $term_id
	 * @param int $interval_days
	 * @return bool
	 */
	public static function is_due( $term_id, $interval_days = 30 ) {
		$latest = self::get_latest_pillar( $term_id );
		if ( ! $latest ) {
			return true; // never generated
		}
		// @FIX 9.5.2: Pillars are refreshed IN PLACE, so the publish date never moves.
		// Cadence must therefore be measured against the LAST MODIFIED time, otherwise
		// the sweep would re-refresh the pillar on every single run after the first
		// interval elapsed.
		$ts = get_post_timestamp( $latest, 'modified' );
		if ( ! $ts ) {
			$ts = get_post_timestamp( $latest );
		}
		if ( ! $ts ) {
			return true;
		}
		return ( time() - $ts ) >= ( $interval_days * DAY_IN_SECONDS );
	}

	/**
	 * Most recent pillar post id for a topic (any status), or 0.
	 */
	public static function get_latest_pillar( $term_id ) {
		$q = new WP_Query(
			array(
				'post_type'      => 'post',
				'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'orderby'        => 'date',
				'order'          => 'DESC',
				'meta_key'       => '_nm_pillar_topic',
				'meta_value'     => $term_id,
			)
		);
		return ! empty( $q->posts ) ? (int) $q->posts[0] : 0;
	}

	/* ------------------------------------------------------------------
	 * Generation
	 * ---------------------------------------------------------------- */

	/**
	 * Generate ONE pillar for a parent topic.
	 *
	 * @param int $term_id Topic term id.
	 * @return int|WP_Error Post id on success.
	 */
	public static function generate_pillar( $term_id ) {
		$term = get_term( $term_id, 'topic' );
		if ( ! $term || is_wp_error( $term ) ) {
			return new WP_Error( 'bad_topic', 'Invalid topic term.' );
		}
		if ( ! class_exists( 'NM_API_Client' ) || ! method_exists( 'NM_API_Client', 'generate_topic_pillar' ) ) {
			return new WP_Error( 'no_api_method', 'Pillar generation method unavailable.' );
		}
		$api_key = NM_API_Client::get_gemini_api_key();
		if ( empty( $api_key ) ) {
			return new WP_Error( 'no_key', 'Gemini API key missing.' );
		}

		// Exam names (for prompt grounding + tagging).
		$exam_names = array();
		$exam_ids   = self::get_exams();
		foreach ( $exam_ids as $eid ) {
			$e = get_term( $eid, 'nm_exam' );
			if ( $e && ! is_wp_error( $e ) ) {
				$exam_names[] = $e->name;
			}
		}

		// Grounding context from the topic's real MCQs.
		$mcqs = self::get_topic_mcqs( $term_id, 12 );

		$client = NM_API_Client::get_instance();
		$result = $client->generate_topic_pillar( $term->name, $term->description, $exam_names, $mcqs, 800, 1500 );
		if ( empty( $result['success'] ) || empty( $result['data'] ) ) {
			return new WP_Error( 'gen_failed', isset( $result['error'] ) ? $result['error'] : 'Pillar generation failed.' );
		}
		$data = $result['data'];

		// Author.
		$author = class_exists( 'NM_News_Article_Generator' ) ? NM_News_Article_Generator::pick_random_author() : array( 'user_id' => 0, 'display_name' => get_bloginfo( 'name' ) );

		// Build content via the shared sanitizer (markdown links, FAQ dedupe, related MCQs, hub link).
		// @FIX 9.5.2: Related MCQs are no longer baked as static <a> links — we pass a
		// shortcode that resolves the topic's latest PUBLISHED MCQs at render time
		// (no stale lists, no 404s when an MCQ is deleted or re-slugged).
		$mcq_links = self::get_topic_mcq_links( $term_id, 6 );
		$content   = class_exists( 'NM_News_Article_Generator' )
			? NM_News_Article_Generator::build_content(
				$data,
				$mcq_links,
				array(
					'related_shortcode' => '[nm_related_mcqs topic_id="' . (int) $term_id . '" count="6"]',
					// @NEW 9.5.3: Explicit topic for the "Read the latest {Topic} MCQs Now →"
					// CTA under the Related MCQs block (renders even if $mcq_links is empty).
					'topic_term_id'     => (int) $term_id,
				)
			)
			: ( isset( $data['content'] ) ? $data['content'] : '' );

		$word_count = (int) str_word_count( wp_strip_all_tags( $content ) );

		// @FIX 9.5.2 (SEO): ONE canonical pillar per topic, refreshed IN PLACE.
		// The old behaviour inserted a brand-new post every cadence sweep, which piled
		// up near-duplicate pillars all targeting the same keyword (cannibalization /
		// scaled-content risk). Now: if a pillar already exists for this topic, we
		// UPDATE it (same ID, same URL, same backlinks) and bump post_modified; a new
		// post is only inserted when the topic has no pillar yet.
		$existing_id = self::get_latest_pillar( $term_id );
		$is_update   = $existing_id > 0;

		// Draft-first for review (new pillars). If the Scheduler is ON, queue for scheduled publish.
		$post_status    = 'draft';
		$is_smart_sched = (bool) get_option( 'nm_scheduler_enabled', 0 );

		if ( $is_update ) {
			// Refresh in place: keep slug (URL), keep author (byline stability), keep
			// current status (a live pillar stays live — its post_modified is bumped).
			$update_args = array(
				'ID'           => $existing_id,
				'post_title'   => $data['title'],
				'post_content' => $content,
				'post_excerpt' => isset( $data['excerpt'] ) ? $data['excerpt'] : '',
			);
			$result_id = wp_update_post( $update_args, true );
			if ( is_wp_error( $result_id ) || empty( $result_id ) ) {
				return is_wp_error( $result_id ) ? $result_id : new WP_Error( 'update_failed', 'wp_update_post failed for pillar refresh.' );
			}
			$post_id = $existing_id;
		} else {
			$post_id = wp_insert_post(
				array(
					'post_type'    => 'post',
					'post_status'  => $post_status,
					'post_title'   => $data['title'],
					'post_name'    => $data['slug'],
					'post_content' => $content,
					'post_excerpt' => isset( $data['excerpt'] ) ? $data['excerpt'] : '',
					'post_author'  => (int) $author['user_id'],
				),
				true
			);

			if ( is_wp_error( $post_id ) || empty( $post_id ) ) {
				return is_wp_error( $post_id ) ? $post_id : new WP_Error( 'insert_failed', 'wp_insert_post failed for pillar.' );
			}

			if ( $is_smart_sched ) {
				update_post_meta( $post_id, '_nm_ready_for_publish', 'yes' );
			}
		}

		// Taxonomies.
		wp_set_object_terms( $post_id, array( $term_id ), 'topic' );
		if ( $exam_ids ) {
			wp_set_object_terms( $post_id, $exam_ids, 'nm_exam' );
		}

		// @NEW 9.5.2 (Fix: "No category assigned"): file pillars under a dedicated
		// content-type category. We deliberately do NOT mirror topic terms as
		// categories — the `topic` taxonomy already provides the topical archives,
		// and duplicating it as categories would create competing archive pages.
		if ( class_exists( 'NM_News_Article_Generator' ) && method_exists( 'NM_News_Article_Generator', 'ensure_category' ) ) {
			$cat_id = NM_News_Article_Generator::ensure_category( 'Study Guides', 'study-guides' );
			if ( $cat_id ) {
				wp_set_post_categories( $post_id, array( $cat_id ), false );
			}
		}

		// Metadata.
		update_post_meta( $post_id, '_nm_pillar_generated', 'yes' );
		update_post_meta( $post_id, '_nm_blocks_converted', 'yes' ); // @NEW 9.5.5: born as blocks
		// Also flag _nm_article_generated so the shared Article + FAQ schema injector in
		// NM_News_Article_Generator applies to pillars too (same meta contract).
		update_post_meta( $post_id, '_nm_article_generated', 'yes' );
		update_post_meta( $post_id, '_nm_pillar_topic', $term_id );
		update_post_meta( $post_id, '_nm_pillar_word_count', $word_count );
		update_post_meta( $post_id, '_nm_pillar_refreshed', current_time( 'mysql' ) );
		// Keep the byline stable on refresh — only stamp the author on first creation.
		if ( ! $is_update ) {
			update_post_meta( $post_id, 'mcq_author_name', sanitize_text_field( $author['display_name'] ) );
		}
		update_post_meta( $post_id, 'rank_math_focus_keyword', sanitize_text_field( $term->name ) );

		if ( ! empty( $data['excerpt'] ) ) {
			update_post_meta( $post_id, 'rank_math_description', sanitize_text_field( $data['excerpt'] ) );
			update_post_meta( $post_id, '_yoast_wpseo_metadesc', sanitize_text_field( $data['excerpt'] ) );
		}

		// FAQ (Rank Math FAQ block + our own JSON-LD fallback).
		if ( ! empty( $data['faq'] ) && is_array( $data['faq'] ) ) {
			update_post_meta( $post_id, '_nm_article_faq', $data['faq'] );
			$rm_faq = array();
			foreach ( $data['faq'] as $item ) {
				if ( ! empty( $item['q'] ) && ! empty( $item['a'] ) ) {
					$rm_faq[] = array( 'question' => $item['q'], 'answer' => $item['a'] );
				}
			}
			if ( $rm_faq ) {
				update_post_meta( $post_id, 'rank_math_faq_block_off', 'off' );
				update_post_meta( $post_id, 'rank_math_faq_block_title', 'Frequently Asked Questions' );
				update_post_meta( $post_id, 'rank_math_faq_block_content', wp_json_encode( $rm_faq ) );
			}
		}

		// Dedicated featured image (Design 2 / MCQ colors). On refresh, only generate
		// if the pillar somehow lost its image — no need to re-render every cycle.
		if ( ( ! $is_update || ! get_post_thumbnail_id( $post_id ) )
			&& class_exists( 'NM_Social_Image_Generator' ) && method_exists( 'NM_Social_Image_Generator', 'generate_article_image' ) ) {
			NM_Social_Image_Generator::generate_article_image( $post_id );
		}

		if ( class_exists( 'NM_Generation_Logger' ) ) {
			NM_Generation_Logger::nm_log_activity(
				sprintf(
					'[PILLAR] %s pillar for topic "%s" (post #%d, %d words, author "%s", status=%s).',
					$is_update ? 'Refreshed' : 'Generated',
					$term->name,
					$post_id,
					$word_count,
					$author['display_name'],
					get_post_status( $post_id )
				),
				'info'
			);
		}

		return $post_id;
	}

	/* ------------------------------------------------------------------
	 * Helpers
	 * ---------------------------------------------------------------- */

	/**
	 * Fetch a topic's published MCQs for grounding (question + correct answer text).
	 *
	 * @param int $term_id
	 * @param int $limit
	 * @return array[] [{post_id, question, answer, permalink, topic}]
	 */
	private static function get_topic_mcqs( $term_id, $limit = 12 ) {
		$q = new WP_Query(
			array(
				'post_type'      => 'mcq',
				'post_status'    => 'publish',
				'posts_per_page' => max( 1, $limit ),
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'orderby'        => 'rand',
				'tax_query'      => array(
					array(
						'taxonomy' => 'topic',
						'field'    => 'term_id',
						'terms'    => $term_id,
					),
				),
				// @FIX 9.5.2 (evergreen purity): exclude NEWS-derived MCQs from pillar
				// grounding. News MCQs carry a `mcq_source_url`; injecting them as
				// "verified facts" was how dated news items (satellite launches, hospital
				// announcements, etc.) leaked into evergreen guides. Topic-generated MCQs
				// have no source URL and are safe evergreen grounding.
				'meta_query'     => array(
					'relation' => 'OR',
					array(
						'key'     => 'mcq_source_url',
						'compare' => 'NOT EXISTS',
					),
					array(
						'key'     => 'mcq_source_url',
						'value'   => '',
						'compare' => '=',
					),
				),
			)
		);
		$out = array();
		foreach ( $q->posts as $pid ) {
			$ans_code = get_post_meta( $pid, 'mcq_answer', true );
			$options  = get_post_meta( $pid, 'mcq_options', true );
			$answer   = ( is_array( $options ) && isset( $options[ $ans_code ] ) ) ? $options[ $ans_code ] : (string) $ans_code;
			$out[]    = array(
				'post_id'   => (int) $pid,
				'question'  => get_the_title( $pid ),
				'answer'    => trim( (string) $answer ),
				'permalink' => get_permalink( $pid ),
				'topic'     => get_term( $term_id, 'topic' ) ? get_term( $term_id, 'topic' )->name : '',
			);
		}
		return $out;
	}

	/**
	 * Lighter variant of get_topic_mcqs() for the shared build_content() related-links
	 * section (only fields build_content needs).
	 */
	private static function get_topic_mcq_links( $term_id, $limit = 6 ) {
		$mcqs = self::get_topic_mcqs( $term_id, $limit );
		return array_map(
			function ( $m ) {
				return array(
					'post_id'   => $m['post_id'],
					'question'  => $m['question'],
					'permalink' => $m['permalink'],
					'topic'     => $m['topic'],
				);
			},
			$mcqs
		);
	}
}
