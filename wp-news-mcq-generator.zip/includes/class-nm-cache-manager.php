<?php

/**
 * Class NM_Cache_Manager
 *
 * Manages caching for the plugin using WordPress Transients.
 *
 * @package News_MCQ_Generator
 * @version 1.2 - Merged V23 methods (clear_by_prefix, get_stats, prefixing) with V25 versioning.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class NM_Cache_Manager {


	// ✅ RESTORED: V23 cache prefix
	private static $cache_prefix = 'nm_mcq_';

	// Default expiration time (6 hours)
	private static $default_expiration = 6 * HOUR_IN_SECONDS;

	/**
	 * ✅ KEPT: V25 cache-busting hooks
	 */
	public static function init() {
		// Bust cache when an MCQ post is saved or trashed
		add_action( 'save_post_mcq', array( self::class, 'bust_topic_cache' ) );
		add_action( 'delete_post', array( self::class, 'bust_topic_cache_on_delete' ), 10, 1 );

		// Bust cache when a 'topic' term is modified
		add_action( 'create_term', array( self::class, 'bust_topic_cache_on_term_change' ), 10, 3 );
		add_action( 'edit_term', array( self::class, 'bust_topic_cache_on_term_change' ), 10, 3 );
		add_action( 'delete_term', array( self::class, 'bust_topic_cache_on_term_change' ), 10, 3 );
	}

	/**
	 * Get a value from the cache.
	 * ✅ UPDATED: Now uses V23 prefix
	 *
	 * @param string $key The cache key.
	 * @return mixed The cached data, or false if not found/expired.
	 */
	public static function get( $key ) {
		return get_transient( self::$cache_prefix . $key );
	}

	/**
	 * Set a value in the cache.
	 * ✅ UPDATED: Merged V23 prefix and "no-random" logic
	 *
	 * @param string   $key The cache key.
	 * @param mixed    $value The data to cache.
	 * @param int|null $expiration The expiration time in seconds.
	 */
	public static function set( $key, $value, $expiration = null ) {
		// ✅ RESTORED: V23 logic to never cache randomized data
		$no_cache_patterns = array( 'mcq_data_', 'random_', 'shuffled_' );

		foreach ( $no_cache_patterns as $pattern ) {
			if ( strpos( $key, $pattern ) !== false ) {
				return false; // Don't cache randomized content
			}
		}

		if ( is_null( $expiration ) ) {
			$expiration = self::$default_expiration;
		}

		return set_transient( self::$cache_prefix . $key, $value, $expiration );
	}

	/**
	 * Delete a value from the cache.
	 * ✅ UPDATED: Now uses V23 prefix
	 *
	 * @param string $key The cache key.
	 */
	public static function delete( $key ) {
		return delete_transient( self::$cache_prefix . $key );
	}

	/**
	 * ✅ KEPT: V25 cache versioning function
	 *
	 * @return int The current cache version.
	 */
	public static function get_topic_cache_version() {
		return (int) get_option( 'nm_topic_cache_version', 1 );
	}

	/**
	 * ✅ KEPT: V25 cache-busting function
	 */
	public static function bust_topic_cache() {
		$version = self::get_topic_cache_version();
		update_option( 'nm_topic_cache_version', $version + 1 );

		// ✅ NEW: Also clear leaderboard cache when topics change
		self::clear_by_prefix( 'leaderboard_' );
	}

	/**
	 * ✅ KEPT: V25 helper function
	 */
	public static function bust_topic_cache_on_delete( $post_id ) {
		if ( get_post_type( $post_id ) === 'mcq' ) {
			self::bust_topic_cache();
		}
	}

	/**
	 * ✅ KEPT: V25 helper function
	 */
	public static function bust_topic_cache_on_term_change( $term_id, $tt_id, $taxonomy ) {
		if ( $taxonomy === 'topic' ) {
			self::bust_topic_cache();
		}
	}

	// ===================================================================
	// ✅ START: RESTORED V23 METHODS (Fixes Fatal Error)
	// ===================================================================

	/**
	 * ✅ RESTORED: Clear all plugin caches with a specific prefix
	 * This method was called by NM_Leaderboard::recalculate_all_leaderboards()
	 */
	public static function clear_by_prefix( $prefix = '' ) {
		global $wpdb;

		$pattern = self::$cache_prefix . $prefix . '%';

		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
				$wpdb->esc_like( '_transient_' . $pattern )
			)
		);

		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
				$wpdb->esc_like( '_transient_timeout_' . $pattern )
			)
		);
	}

	/**
	 * ✅ RESTORED: Clear all MCQ-related caches
	 */
	public static function clear_all() {
		self::clear_by_prefix( '' );
		if ( defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
		}
	}
	/**
	 * Purge Cloudflare/Super Page Cache for specific URLs (edge HTML).
	 * This is a thin wrapper used by integration classes.
	 *
	 * @param string[] $urls
	 */
	public static function purge_cloudflare_urls( array $urls ): void {

		// Super Page Cache provides this action for programmatic purging.
		if ( ! has_action( 'swcfpc_purge_cache' ) ) {
			return;
		}

		$urls = array_values( array_unique( array_filter( $urls ) ) );

		if ( empty( $urls ) ) {
			return;
		}

		do_action( 'swcfpc_purge_cache', $urls );
	}

	/**
	 * ✅ RESTORED: Get cache stats for admin dashboard
	 * This is likely used by your admin dashboard and should be restored.
	 */
	public static function get_stats() {
		global $wpdb;

		$total = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE %s",
				$wpdb->esc_like( '_transient_' . self::$cache_prefix ) . '%'
			)
		);

		$size = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT SUM(LENGTH(option_value)) FROM {$wpdb->options} WHERE option_name LIKE %s",
				$wpdb->esc_like( '_transient_' . self::$cache_prefix ) . '%'
			)
		);

		return array(
			'total_items'      => intval( $total ),
			'total_size_bytes' => intval( $size ),
			'total_size_mb'    => round( $size / ( 1024 * 1024 ), 2 ),
		);
	}
	// ===================================================================
	// ✅ END: RESTORED V23 METHODS
	// ===================================================================
}
