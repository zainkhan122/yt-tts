<?php
/**
 * Response Handler
 * Centralizes all AJAX and API responses with consistent formatting
 *
 * @package WP_News_MCQ_Generator
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class NM_Response_Handler {

	/**
	 * Send success response
	 *
	 * @param mixed  $data The data to return
	 * @param string $message Optional success message
	 * @param int    $code HTTP status code (default 200)
	 */
	public static function success( $data = null, $message = '', $code = 200 ) {
		$response = array(
			'success'   => true,
			'code'      => $code,
			'message'   => $message,
			'data'      => $data,
			'timestamp' => current_time( 'mysql' ),
		);

		// Log successful operations for debugging
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
		}

		wp_send_json( $response, $code );
	}

	/**
	 * Send error response
	 *
	 * @param string $message Error message for user
	 * @param string $code Error code for developers
	 * @param array  $details Additional error details
	 * @param int    $http_code HTTP status code (default 400)
	 */
	public static function error( $message, $code = 'error', $details = array(), $http_code = 400 ) {
		$response = array(
			'success'   => false,
			'code'      => $code,
			'message'   => $message,
			'details'   => $details,
			'timestamp' => current_time( 'mysql' ),
		);

		// Log errors for debugging
		if ( ! empty( $details ) ) {
		}

		wp_send_json( $response, $http_code );
	}

	/**
	 * Send validation error response
	 *
	 * @param array $errors Array of field => error message pairs
	 */
	public static function validation_error( $errors ) {
		self::error(
			'Validation failed. Please check your input.',
			'validation_error',
			array( 'fields' => $errors ),
			422 // 422 Unprocessable Entity
		);
	}

	/**
	 * Send permission denied response
	 *
	 * @param string $message Custom message (optional)
	 */
	public static function permission_denied( $message = 'You do not have permission to perform this action.' ) {
		self::error(
			$message,
			'permission_denied',
			array( 'required_capability' => 'unknown' ),
			403 // 403 Forbidden
		);
	}

	/**
	 * Send not found response
	 *
	 * @param string $resource What was not found (e.g., "MCQ", "User")
	 */
	public static function not_found( $resource = 'Resource' ) {
		self::error(
			$resource . ' not found.',
			'not_found',
			array( 'resource' => $resource ),
			404 // 404 Not Found
		);
	}

	/**
	 * Send rate limit response
	 *
	 * @param int $retry_after Seconds until user can retry
	 */
	public static function rate_limited( $retry_after = 60 ) {
		self::error(
			'Too many requests. Please try again in ' . $retry_after . ' seconds.',
			'rate_limited',
			array( 'retry_after' => $retry_after ),
			429 // 429 Too Many Requests
		);
	}

	/**
	 * Wrap a callback in try-catch and return formatted response
	 *
	 * @param callable $callback The function to execute
	 * @param string   $error_message Default error message if callback fails
	 */
	public static function try_execute( $callback, $error_message = 'An error occurred' ) {
		try {
			$result = $callback();

			// If callback returns false, treat as error
			if ( $result === false ) {
				self::error( $error_message, 'execution_failed' );
				return;
			}

			// Success
			self::success( $result );

		} catch ( Exception $e ) {

			self::error(
				$error_message,
				'exception',
				array(
					'exception' => $e->getMessage(),
					'file'      => $e->getFile(),
					'line'      => $e->getLine(),
				),
				500 // 500 Internal Server Error
			);
		}
	}

	/**
	 * Check if user is logged in, send error if not
	 *
	 * @return bool True if logged in, false if error sent
	 */
	public static function require_login() {
		if ( ! is_user_logged_in() ) {
			self::error(
				'You must be logged in to perform this action.',
				'not_logged_in',
				array(),
				401 // 401 Unauthorized
			);
			return false;
		}
		return true;
	}

	/**
	 * Check user capability, send error if insufficient
	 *
	 * @param string $capability Required capability
	 * @return bool True if has capability, false if error sent
	 */
	public static function require_capability( $capability ) {
		if ( ! current_user_can( $capability ) ) {
			self::error(
				'You do not have permission to perform this action.',
				'insufficient_permissions',
				array( 'required_capability' => $capability ),
				403
			);
			return false;
		}
		return true;
	}
}
