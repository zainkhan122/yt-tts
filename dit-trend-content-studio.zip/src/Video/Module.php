<?php
/**
 * DIT Video Module — Module (entry point)
 *
 * Wires the optional video-shorts module into DIT TrendStudio WITHOUT touching
 * DIT's own pipeline. Everything is guarded: if the module is disabled, or a
 * required tool is missing, it is a silent no-op (never breaks DIT).
 *
 * Integration points (all additive hooks):
 *   - Action Scheduler job for generation (dit_ts_video_generate)
 *   - dit_ts_job_auto_published + transition_post_status -> auto-generate on publish
 *   - dit_ts_daily_cleanup -> video temp + attachment cleanup
 *   - admin_menu -> a "Video" submenu under the DIT menu (settings/diagnostics/jobs)
 *   - Dashboard card (rendered by Admin::dashboard_card via the dashboard view)
 *
 * @package DIT\TrendStudio\Video
 */

namespace DIT\TrendStudio\Video;

use DIT\TrendStudio\Infrastructure\Logger;

if (!defined('ABSPATH')) {
    exit;
}

final class Module
{
    /** @var Module|null */
    private static $instance = null;

    /** @var Settings */
    public $settings;

    /** @var Logger */
    public $logger;

    /** @var Generator */
    public $generator;

    /** @var Job_Manager */
    public $jobs;

    /** @var Cleanup */
    public $cleanup;

    /** @var Diagnostics */
    public $diagnostics;

    /** @var YT_Lookup */
    public $yt;

    /** @var Publish_Integrator */
    public $publisher;

    /** @var Admin */
    public $admin;

    public static function instance(): Module
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct()
    {
        $this->settings    = new Settings();
        $this->logger      = new Logger();
        $this->generator   = new Generator($this->settings, $this->logger);
        $this->jobs        = new Job_Manager($this->settings, $this->logger, $this->generator);
        $this->cleanup     = new Cleanup($this->settings, $this->logger);
        $this->diagnostics = new Diagnostics($this->settings);
        $this->yt          = new YT_Lookup($this->settings, $this->logger);
        $this->publisher   = new Publish_Integrator($this->settings, $this->logger, $this->yt);
        $this->admin       = new Admin($this->settings, $this->logger, $this->jobs, $this->cleanup, $this->diagnostics);

        $this->register_hooks();
    }

    private function register_hooks(): void
    {
        // Generation via Action Scheduler.
        $this->jobs->register_hooks();

        // Auto-generate when a DIT-generated post is published.
        add_action('dit_ts_job_auto_published', array($this, 'on_dit_auto_publish'), 20, 3);
        add_action('transition_post_status', array($this, 'on_post_published'), 20, 3);

        // Publish workflow: embed YT link after Buffer share.
        $this->publisher->register_hooks();

        // Daily cleanup.
        $this->cleanup->register_hooks();

        // Admin UI.
        if (is_admin()) {
            add_action('admin_menu', array($this->admin, 'register_menu'));
            add_action('admin_enqueue_scripts', array($this->admin, 'enqueue_assets'));
            add_action('admin_init', array($this->admin, 'handle_settings_post'));
            add_action('wp_ajax_dit_video_generate', array($this->admin, 'ajax_generate'));
            add_action('wp_ajax_dit_video_diagnostics', array($this->admin, 'ajax_diagnostics'));
            add_action('wp_ajax_dit_video_cleanup', array($this->admin, 'ajax_cleanup'));
        }
    }

    /**
     * On DIT auto-publish, queue a video for the new post (if enabled + qualified).
     */
    public function on_dit_auto_publish($job_id, $post_id, $idea_id): void
    {
        $this->maybe_auto_generate((int) $post_id);
    }

    /**
     * On any post -> publish transition, maybe generate.
     */
    public function on_post_published($new_status, $old_status, $post): void
    {
        if ('publish' !== $new_status || 'publish' === $old_status) {
            return;
        }
        if ('post' !== ($post->post_type ?? '')) {
            return;
        }
        $this->maybe_auto_generate((int) $post->ID);
    }

    private function maybe_auto_generate(int $post_id): void
    {
        if (!$this->settings->get_bool('auto_generate', false)) {
            return;
        }
        $this->jobs->queue($post_id);
    }
}
