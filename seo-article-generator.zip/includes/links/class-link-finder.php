<?php

/**
 * Link Finder
 *
 * @package SEO_Article_Generator
 */

namespace SEO_Article_Generator\Links;

use SEO_Article_Generator\Logger;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Find relevant internal links from sitemap cache and database
 * 
 * @MODIFIED 2025-12-01 - Added hybrid DB/CSV link discovery
 */
class Link_Finder
{
    /**
     * Logger instance
     *
     * @var Logger
     */
    private $logger;

    /**
     * DB post finder instance
     *
     * @var DB_Post_Finder
     * @MODIFIED 2025-12-01 - Added for hybrid search
     */
    private $db_finder;

    /**
     * Constructor
     *
     * @param Logger         $logger    Logger instance
     * @param DB_Post_Finder $db_finder DB post finder instance
     * @MODIFIED 2025-12-01 - Added $db_finder parameter
     */
    public function __construct($logger, $db_finder = null)
    {
        $this->logger = $logger;
        $this->db_finder = $db_finder;
	}

	/**
	 * Find related internal links (Unified Pool - Relevance First)
	 *
	 * @param string $software_name Software name
	 * @param string $category Category
	 * @param int $count Number of links to find
	 * @return array Array of related links
	 * @MODIFIED 2026-04-26 - Removed category-based Pool 1. Category was identical
	 * to software_name causing DB posts from the same software-name category to
	 * be returned (near-identical titles). Now uses keyword-based relevance only.
	 */
	public function find_related($software_name, $category, $count = 3)
    {
        // @MODIFIED 2026-01-08: Ensure category is always a string (AI may return array)
        if (is_array($category)) {
            $category = implode(', ', array_filter($category));
        }
        $category = is_string($category) ? $category : '';

        $this->logger->debug('Finding related links (Unified Pool)', array(
            'software' => $software_name,
            'category' => $category,
            'count' => $count,
        ));

        // Pool 1: Keyword Relevance (extracted from software name)
        $pool_keywords = array();
        $keywords = $this->extract_keywords($software_name);

        // fetch from DB
        if ($this->db_finder) {
            $pool_keywords = array_merge($pool_keywords, $this->db_finder->search_by_keywords($keywords, $count));
        }
        // fetch from links table
        $pool_keywords = array_merge($pool_keywords, $this->search_by_keywords($keywords, $count));

        $pool_keywords = $this->remove_duplicates($pool_keywords);

        // Sort by used_count ASC for fair rotation
        usort($pool_keywords, function ($a, $b) {
            $a_count = isset($a['used_count']) ? (int) $a['used_count'] : 0;
            $b_count = isset($b['used_count']) ? (int) $b['used_count'] : 0;
            return $a_count <=> $b_count;
        });

        // Slice to requested count
        $final_links = array_slice($pool_keywords, 0, $count);

        $this->increment_usage_counts($final_links);
        $this->logger->debug('Found links (Unified)', array('count' => count($final_links)));

        return $final_links;
	}

	/**
	 * Search by category
     *
     * @param string $category Category name
     * @param int    $limit    Result limit
     * @return array Links
     */
    private function search_by_category($category, $limit)
    {
        global $wpdb;

        $table = \SEO_Article_Generator\Installer::table_links();

        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, title, url, category, used_count 
                FROM {$table} 
                WHERE category LIKE %s 
                ORDER BY used_count ASC, RAND() 
                LIMIT %d",
                '%' . $wpdb->esc_like($category) . '%',
                $limit
            ),
            ARRAY_A
        );

        return $results ? $results : array();
    }

/**
     * Search by keywords
     *
     * @param array $keywords Keywords to search
     * @param int   $limit   Result limit
     * @return array Links
     */
    private function search_by_keywords($keywords, $limit)
    {
        global $wpdb;

        $table = \SEO_Article_Generator\Installer::table_links();

        if (empty($keywords)) {
            return array();
        }

        // Build MATCH AGAINST query for fulltext search
        $keyword_string = implode(' ', $keywords);

        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, title, url, category, used_count,
                MATCH(keywords, title) AGAINST(%s) as relevance
                FROM {$table}
                WHERE MATCH(keywords, title) AGAINST(%s)
                ORDER BY used_count ASC, relevance DESC
                LIMIT %d",
                $keyword_string,
                $keyword_string,
                $limit
            ),
            ARRAY_A
        );

        // Fallback: LIKE search when FULLTEXT returns empty (short keywords, sparse index)
        if (empty($results)) {
            $like_conditions = array();
            foreach ($keywords as $kw) {
                if (strlen($kw) >= 2) {
                    $like_conditions[] = $wpdb->prepare(
                        '(keywords LIKE %s OR title LIKE %s)',
                        '%' . $wpdb->esc_like($kw) . '%',
                        '%' . $wpdb->esc_like($kw) . '%'
                    );
                }
            }

            if (!empty($like_conditions)) {
                $like_clause = implode(' OR ', $like_conditions);
                $results = $wpdb->get_results(
                    "SELECT id, title, url, category, used_count
                    FROM {$table}
                    WHERE {$like_clause}
                    ORDER BY used_count ASC
                    LIMIT " . (int) $limit,
                    ARRAY_A
                );
            }
        }

        // Last resort: return least-used links with no keyword filter
        if (empty($results)) {
            $results = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT id, title, url, category, used_count
                    FROM {$table}
                    ORDER BY used_count ASC, created_at DESC
                    LIMIT %d",
                    $limit
                ),
                ARRAY_A
            );

            if (!empty($results) && $this->logger) {
                $this->logger->info(sprintf(
                    'LinkFinder: No keyword match. Using least-used fallback (%d links).',
                    count($results)
                ));
            }
        }

        return $results ? $results : array();
    }

    /**
     * Extract keywords from software name
     *
     * @param string $software_name Software name
     * @return array Keywords
     */
    private function extract_keywords($software_name)
    {
        // Remove version numbers
        $name = preg_replace('/\d+(\.\d+)*/', '', $software_name);

        // Remove common words
        $stop_words = array('the', 'a', 'an', 'and', 'or', 'but', 'for', 'download', 'free', 'pro', 'plus', 'edition');

        // Split into words
        $words = preg_split('/[\s\-_]+/', strtolower($name));

        // Filter stop words
        $keywords = array_filter($words, function ($word) use ($stop_words) {
            return strlen($word) > 2 && !in_array($word, $stop_words);
        });

        return array_values($keywords);
    }

    /**
     * Remove duplicate links
     *
     * @param array $links Links array
     * @return array Unique links
     */
    private function remove_duplicates($links)
    {
        $unique = array();
        $urls = array();

        foreach ($links as $link) {
            if (!isset($link['url']) || in_array($link['url'], $urls)) {
                continue;
            }
            $unique[] = $link;
            $urls[] = $link['url'];
        }

        return $unique;
    }

    /**
     * Get total link count in cache
     *
     * @return int Link count
     */
    public function get_total_links()
    {
        global $wpdb;

        $table = \SEO_Article_Generator\Installer::table_links();
        $count = $wpdb->get_var("SELECT COUNT(*) FROM {$table}");

        return (int) $count;
    }

    /**
     * Increment used_count for selected links after injection.
     *
     * @param array $links Array of link rows
     * @return void
     */
    private function increment_usage_counts(array $links): void
    {
        global $wpdb;
        $table = \SEO_Article_Generator\Installer::table_links();

        if (empty($links)) {
            return;
        }

        $ids = array();
        foreach ($links as $link) {
            if (!empty($link['id']) && is_numeric($link['id'])) {
                $ids[] = (int) $link['id'];
            }
        }

        if (empty($ids)) {
            return;
        }

        $id_list = implode(',', array_map('intval', $ids));
        $wpdb->query("UPDATE {$table} SET used_count = used_count + 1 WHERE id IN ({$id_list})");
    }
}
