<?php

namespace SEO_Article_Generator\Generator;

/**
 * Prompt Builder Class
 *
 * Consolidates prompt templates and logic for both Manual and Discovery pipelines.
 * Decoupled into three responsibilities: Grounding, State, Assembly.
 *
 * @since 2.19.2
 * @MODIFIED 2026-03-03: Lean industrial refactor — uses Generation_Context for typed input
 * @MODIFIED 2026-03-08: Added "Single Size Mandate" to instructions to unify file size display.
 */
class Prompt_Builder
{

  /**
   * Build the system prompt for AI providers to ensure consistent persona and formatting.
   *
   * @param array $options {
   *     @type bool   $enable_web_search Whether web search is enabled.
   *     @type string $focus_keyword     Optional focus keyword for search orientation.
   *     @type array  $domain_filter     Optional list of allowed domains.
   *     @type bool   $strict_mode       Whether to enforce strict source policy.
   * }
   * @return string
   */
  public static function build_system_prompt(array $options = []): string
  {
    $enable_web_search = $options['enable_web_search'] ?? false;
    $focus_keyword     = $options['focus_keyword'] ?? '';
    $domain_filter     = $options['domain_filter'] ?? [];
    $strict_mode       = $options['strict_mode'] ?? false;

    if ($enable_web_search) {
      $system = 'You are a professional software documentation writer. Use web search to find accurate, up-to-date information about the software. ';
    } else {
      $system = 'You are a professional software documentation writer. Extract information ONLY from the provided content. Do NOT use web search. ';
    }

    $system .= 'You are a strict JSON content generator. Return ONLY one valid JSON object with no markdown formatting and no code fences. No commentary. '
      . 'If information is limited, return null for those fields. Do NOT guess or provide inaccurate data if it is not the requested field.';

    $system .= ' OUTPUT LANGUAGE (STRICT): Write the ENTIRE article and all natural-language fields (title, meta_description, focus_keyword, introduction, features, whats_new, faqs, pros_cons, installation_guide, moat_data, competitors, tags) in ENGLISH ONLY. '
      . 'Even when the provided source CONTEXT is written in another language (e.g., Bulgarian), translate and rewrite it into fluent, natural English. '
      . 'Never mix languages and never echo the source language into the output. Keep factual proper nouns (software name, developer, URLs, file names, version numbers) verbatim.';

    if ($focus_keyword) {
      $system .= ' CONTENT FOCUS: Write naturally about "' . $focus_keyword . '". Prioritize user value over keyword placement. Use the software name and related action terms (download, install, get) when contextually appropriate, not forced into fixed positions.';
    }

    if ($strict_mode && ! empty($domain_filter)) {
      $system .= ' STRICT SOURCE POLICY: Use sources ONLY from ' . implode(', ', $domain_filter) . '. If you cannot confirm a field from those sources, set it to null/[] (do not use other domains).';
    }

    return $system;
  }


  /**
   * Build full instruction set for the AI Provider
   *
   * @param array              $prompt_data  Prompt data array
   * @param Generation_Context $context      Generation context (optional for backward compat)
   * @return string Assembled prompt
   */
  public function build_full_instruction_set(array $prompt_data, ?Generation_Context $context = null)
  {
    // Build context if missing
    if ($context === null) {
      $context = $prompt_data['_generation_context'] ?? Generation_Context::from_input($prompt_data, $prompt_data['input_type'] ?? 'manual');
    }

    // [PHASE 3E, 2.33.0] Scope sections must be resolved BEFORE any method that
    // consumes them. (Regression fix 2.34.9: this line previously sat AFTER the
    // get_discovery_instructions() call below, so $_scope_sections was undefined
    // and passed as null to the array-typed parameter → TypeError on PHP 8.4.)
    $_scope_sections = (array) ($prompt_data['regen_sections'] ?? array('all'));

    // @MODIFIED 2026-03-04: Personas based on context/input_type
    $is_discovery = ($prompt_data['input_type'] ?? '') === 'discovery';
    $system       = $is_discovery ? self::get_discovery_instructions($_scope_sections) : self::get_manual_instructions();
    $schema       = $this->get_json_schema($_scope_sections, $context);

    $grounding        = $prompt_data['grounding_instruction'] ?? '';
    $state            = $prompt_data['state_instruction'] ?? '';
    $software_name    = is_array($prompt_data['software_name'] ?? '') ? implode(' ', $prompt_data['software_name']) : ($prompt_data['software_name'] ?? 'Unknown Software');
    $version          = (! empty($prompt_data['version']) && is_array($prompt_data['version'])) ? implode('.', $prompt_data['version']) : (! empty($prompt_data['version']) ? $prompt_data['version'] : 'Latest');
    $category         = is_array($prompt_data['category'] ?? '') ? implode(', ', $prompt_data['category']) : ($prompt_data['category'] ?? '');
    $article_context  = $prompt_data['changelog'] ?? ($prompt_data['article_context'] ?? '');
    $target_platforms = is_array($prompt_data['target_platforms'] ?? '') ? implode(', ', $prompt_data['target_platforms']) : ($prompt_data['target_platforms'] ?? 'Windows');
    $taxonomy_map     = ! empty($prompt_data['valid_taxonomy_map']) ? $prompt_data['valid_taxonomy_map'] : '[]';
    $detected_hint    = ! empty($prompt_data['detected_metadata']) ? $prompt_data['detected_metadata'] : '{}';

    $prompt  = $system . "\n\n" . $grounding . "\n\n" . $state . "\n\n";
    $prompt .= "CONTEXT / ARTICLE DATA:\n" . $article_context . "\n\n";
    $prompt .= "SOURCE_URL: " . ($prompt_data['source_url'] ?? 'unknown') . "\n\n";
    $prompt .= "PHP_DETECTED_METADATA (Weak Hints):\n" . $detected_hint . "\n\n";
    $prompt .= "VALID_TAXONOMY_MAP:\n" . $taxonomy_map . "\n\n";

    if ($is_discovery) {
      $prompt .= "STRICT IDENTITY RULE (DISCOVERY MODE):\n";
      $prompt .= "- If the Software Name or Version in the CONTEXT below differs from the Metadata above, the CONTEXT is the absolute source of truth.\n";
      $prompt .= "- Use the name and version found in the Context HTML for all schema fields.\n\n";
    }

    $prompt .= "**DOWNLOAD LINKS**: Do NOT generate download_section or download links. The system will populate download links from verified source data. Focus on article content only.\n";

    if ($is_discovery) {
      $prompt .= "- TRUSTED SOURCES: github.com, sourceforge.net, google.com/store, apple.com/app-store, and the official site.\n";

      if ($context->grounding === 'provided') {
        $prompt .= "- **AUGMENTATION MANDATE (TOKEN EFFICIENCY)**: You have been provided with rich context. Do NOT use search for general research or article body content. ONLY use search to verify or find SPECIFIC missing metadata (Developer, File Size, License) if they are absent from the PROVIDED_CONTEXT.\n";
        $prompt .= "- **PRIORITY**: Trust the PROVIDED_CONTEXT for the article's tone, structure, and general facts.\n";
      }

      // MOAT SEARCH EXCEPTION: MOAT/Quick-Start content requires knowing how to USE the software.
      // This is never in a changelog/RSS source. Always search for it regardless of grounding mode.
      if (in_array('moat', (array) ($prompt_data['regen_sections'] ?? ['all']), true) || in_array('all', (array) ($prompt_data['regen_sections'] ?? ['all']), true)) {
        $prompt .= "- **MOAT SEARCH EXCEPTION**: You MUST use web search to generate `moat_data`. Search for '[software name] tips', '[software name] settings guide', '[software name] quick start'. The CONTEXT does not contain this. Do NOT leave moat_data empty.\n";
      }

      $prompt .= "- FILE SIZE: Search for 'Size: XX MB', 'XX MB', or similar patterns in the text and extract them accurately.\n";
    }


    $prompt .= "FORMATTING MANDATE:\n";
    $prompt .= "- You MUST use **bold** text to emphasize the software name, important settings, and key features. Apply this ONLY within the Introduction, MOAT, and Features sections.\n";

	$seogen_links = $prompt_data['seogen_links'] ?? array();
	if (!empty($seogen_links) && is_array($seogen_links)) {
		$prompt .= "\nINTERNAL LINKING MANDATE:\n";
		$prompt .= "- You MUST embed the following internal link tokens in the article sections specified by their 'zone' field.\n";
		$prompt .= "- Wrap anchor text inside each token pair like: [SEOGEN_LINK_N]your anchor text[/SEOGEN_LINK_N]\n";
		$prompt .= "- Place each link in its designated zone: introduction, moat_data, or features.\n";
		$prompt .= "- Use natural, contextual anchor text that fits the surrounding sentence.\n";
		$prompt .= "- Do NOT place links outside their designated zone.\n";
		$prompt .= "- Do NOT add any internal links beyond these tokens.\n";
		$prompt .= "- Integrate links as part of the natural flow of the sentence — NOT as standalone 'for more details' or 'see also' phrases.\n";
		$prompt .= "- The anchor text between the token tags must read like a normal part of the sentence, not a robotic plug.\n\n";
		$prompt .= "INTERNAL_LINK_TOKENS:\n";
		foreach ($seogen_links as $il) {
			$tok = $il['token'] ?? '';
			$ttl = $il['title'] ?? '';
			$zne = $il['zone'] ?? '';
			$prompt .= "- {$tok} | Title: \"{$ttl}\" | Zone: {$zne}\n";
		}
	}

	// [PHASE 3E, 2.33.0] explicit scope directive so prose instructions
	// cannot re-expand output beyond the pruned schema.
	$_scope_all = empty($_scope_sections) || in_array('all', $_scope_sections, true);
	if ( ! $_scope_all ) {
		$prompt .= "\nSECTION SCOPE (STRICT): Return ONLY the JSON keys shown in the JSON SCHEMA below. Do not add or invent sections not listed there (no faqs, moat_data, pros_cons, installation_guide, competitors, features, whats_new or other blocks unless their key is present). Empty [] or null is acceptable for anything included but unverifiable.\n";
	}
	$prompt .= "\n\nJSON SCHEMA:\n" . $schema;

    return $prompt;
  }

  /**
   * Build prompt data for the AI Provider
   *
   * @MODIFIED 2026-03-03: Accepts Generation_Context for deterministic grounding/state
   *
   * @param array              $input_data Raw input from Generator or Discovery
   * @param string             $input_type 'manual' or 'discovery' (legacy, used as fallback)
   * @param Generation_Context $context    Optional typed context (preferred)
   * @return array Ready-to-use prompt data
   */
  public function build_prompt_data(array $input_data, string $input_type = 'manual', ?Generation_Context $context = null)
  {
    // Build context from input if not provided (backward compatibility)
    if ($context === null) {
      $context = Generation_Context::from_input($input_data, $input_type);
    }

    $software_name   = $input_data['software_name'] ?? '';
    $version         = $input_data['version'] ?? '';
    $article_context = $input_data['article_context'] ?? '';

    // ── Grounding: driven by Generation_Context, not input_type ──
    // @MODIFIED 2026-03-03: Context-aware grounding replaces input_type-based branching
    $grounding_instruction = $this->build_grounding_instruction($context);

    // ── State: driven by Generation_Context type ──
    // @MODIFIED 2026-03-03: Context-aware state replaces is_update branching
    $state_instruction = $this->build_state_instruction($context);

    // Combine into prompt_data
    return array(
      'software_name'         => $software_name,
      'version'               => $version,
      'changelog'             => $article_context,
      'input_type'            => $input_type,
      'grounding_instruction' => $grounding_instruction,
      'state_instruction'     => $state_instruction,
      'target_platforms'      => $input_data['target_platforms'] ?? array('Windows', 'macOS', 'Linux'),
      'regen_sections'        => $input_data['regen_sections'] ?? array('all'),
      'include_faqs'          => $input_data['include_faqs'] ?? 1,
      'include_pros_cons'     => $input_data['include_pros_cons'] ?? 1,
      'include_competitors'   => $input_data['include_competitors'] ?? 1,
      'include_moat'          => $input_data['include_moat'] ?? 1,
      'include_installation'  => $input_data['include_installation'] ?? 1,
		'homepage' => $input_data['homepage_url'] ?? ($input_data['homepage'] ?? ($input_data['source_url'] ?? '')),
      'changelogurl'          => $input_data['changelog_url'] ?? '',
      'category'              => $input_data['category'] ?? '',
		'existing_post_id' => $input_data['existing_post_id'] ?? 0,
		'detected_metadata' => $input_data['detected_metadata'] ?? '{}', // Pass grounding hints
		'seogen_links' => $input_data['seogen_links'] ?? array(),
		'_generation_context' => $context,
	);
  }

  /**
   * Build grounding instruction from context.
   *
   * @MODIFIED 2026-03-03: Separated from monolithic if/else
   *
   * @param Generation_Context $context
   * @return string
   */
  private function build_grounding_instruction(Generation_Context $context): string
  {
    if ($context->needs_search() && $context->grounding !== 'provided') {
      return 'RESEARCH MODE: Use Google Search to find the latest official information, changelogs, and download links. Do NOT invent data.';
    }

    if ($context->needs_search() && $context->grounding === 'provided') {
      $_hybrid = 'HYBRID MODE: You have been provided with rich source content. Use it as your PRIMARY source for article structure, version data, and download links. Use Google Search ONLY for: (1) missing metadata like Developer, File Size, License';
      // [PHASE 3E, 2.33.0] moat search mandate only when moat is in scope.
      $_hybrid_sections = (array) ($context->sections ?? array());
      if ( empty($_hybrid_sections) || in_array('all', $_hybrid_sections, true) || in_array('moat', $_hybrid_sections, true) ) {
          $_hybrid .= ', (2) the moat_data section when requested - search for "[software name] tips", "[software name] settings guide", "[software name] quick start" to generate moat_data';
      }
      $_hybrid .= '. Do NOT use search to find a different version than what is in the provided content.';
      return $_hybrid;
    }

    return 'EXTRACTION MODE: You are being provided with a rich HTML changelog/post. Extract features, versions, and links directly from this text. Do NOT use search.';
  }

  /**
   * Build state instruction from context.
   *
   * @MODIFIED 2026-03-03: Separated from monolithic if/else
   *
   * @param Generation_Context $context
   * @return string
   */
  private function build_state_instruction(Generation_Context $context): string
  {
    switch ($context->type) {
	case 'upgrade':
		return 'STATE: LEGACY UPGRADE. Convert the existing manual text into plugin-standard blocks (FAQs, Pros/Cons, etc.). Preserve existing user-written value but update technical data (version, links). You MUST generate ALL top-level SEO fields (title, meta_description, focus_keyword, slug) — they are required for the new plugin-standard post.';

      case 'update':
        return 'STATE: PLUGIN UPDATE. Keep existing tone and structure. ONLY update version-specific fields (Whats New, Tech Specs, Links). Do NOT rewrite perfectly good background paragraphs. Do NOT add new download platforms/OS support that did not exist in the original post.';

      case 'partial':
        return 'STATE: PARTIAL REGENERATION. Only regenerate the specific sections requested. Leave all other sections unchanged.';

      case 'new':
      default:
        return 'STATE: NEW POST. Create a comprehensive, high-quality software download post from scratch following the provided schema.';
    }
  }

  /**
   * Manual Mode Persona: Creative, human-like, balanced.
   */
  public static function get_manual_instructions()
  {
    return <<<'PROMPT'
You are a technical software documentor writing for a software download site.
Your sole priority is accuracy. Never pad content with fluff, never guess values, never optimize for search engines.
Write only what you can verify from official sources. Detailed and verified info beats generic padding.

HUMAN WRITING STYLE (STRICT ENFORCEMENT):
1. SENTENCE VARIANCE (THE "BURSTINESS" RULE):
   - You MUST vary sentence length drastically.
   - Requirement: Write very short sentences (4-7 words) for impact.
   - Requirement: Follow them with longer, complex sentences (20-30 words) for nuance.
   - NEVER write three sentences in a row of similar length.
2. SYNTAX VARIETY:
   - BAN: Do NOT start consecutive sentences with "The software", "It", "This app", or the Software Name.
   - FIX: Start sentences with dependent clauses, prepositions, or verbs (e.g., "While testing...", "Despite its size...", "To get the best results...").
3. ROBOTIC VOCABULARY BAN:
   - DO NOT USE: "Additionally", "Moreover", "Furthermore", "In conclusion", "Vital", "Game-changer", "Landscape".
   - Use simple transitions: "Also", "Plus", "But", "So".
4. PARAGRAPH STRUCTURE:
   - Vary paragraph depth. Use a 1-sentence paragraph to emphasize a key point. Follow it with a 3-sentence description.
5. FORMATTING:
   - Use **bold** for the software name, important settings, and key features within the Introduction, MOAT, and Features sections.
6. INTRODUCTION:
   - Return 1 to 3 distinct paragraphs (up to 200 words total). Adjust length based on software complexity.
7. TAXONOMY (CRITICAL PRO RULE):
   - You are provided with `VALID_TAXONOMY_MAP`.
   - You MUST select MULTIPLE relevant categories from this map.
   - FORMULA: First, select all supported Operating Systems (e.g., Windows, Mac, Android) if they exist in the map. Second, select the specific Software Type (e.g., Media Player, VPN, Security Suite) from the map.
   - You MUST return only the SLUGS (not the names) in the `category` field.
   - Do NOT invent categories. ONLY choose from the provided list.
8. CATEGORIZATION:
   - `category`: Return a comma-separated list of the selected category slugs.
9. **FILE SIZE RULE**:
   - You MUST return only a single, clean value for `file_size` (e.g., '15.5 MB').
   - If multiple installers or platforms exist, pick the primary Windows installer size.
   - NEVER list multiple sizes or add parenthetical descriptions like '(online installer)' in the size field.
PROMPT;
  }

	/**
	 * Discovery Mode Persona: Analytical Data Auditor with same human style.
	 *
	 * @param array|null $scope_sections Sections in scope; null/empty => 'all'.
	 */
	public static function get_discovery_instructions($scope_sections = array('all'))
	{
		// Defensive: tolerate null/non-array (a null previously threw a TypeError
		// against an `array` typed parameter on PHP 8.4).
		if (! is_array($scope_sections)) {
			$scope_sections = array('all');
		}
		$scope_sections = empty($scope_sections) ? array('all') : array_values($scope_sections);
		// [PHASE 3E, 2.33.0] SCOPED PAYLOAD: prose instructions are pruned to
		// the exact sections the job will generate. The JSON schema is already
		// pruned to these keys; persona paragraphs that demand faqs/moat/
		// competitors must be conditional too, otherwise models emit the zones
		// regardless of the schema (prose overrides schema shape).
		$_scope_is_all = empty($scope_sections) || in_array('all', $scope_sections, true);
		$_scope_wants = static function ($canonical) use ($scope_sections, $_scope_is_all) {
			if ($_scope_is_all) {
				return true;
			}
			foreach ($scope_sections as $_sec) {
				$_key = \SEO_Article_Generator\Generator\Article_Schema::get_canonical_key((string) $_sec);
				if (is_string($_key) && $_key === $canonical) {
					return true;
				}
			}
			return false;
		};
		$portable_mandate_enabled = (bool) \get_option(
			\SEO_Article_Generator\Option_Registry::ENABLE_PORTABLE_DISCOVERY,
			\SEO_Article_Generator\Option_Registry::defaults()[\SEO_Article_Generator\Option_Registry::ENABLE_PORTABLE_DISCOVERY]
		);

		$portable_line = $portable_mandate_enabled
			? "- **PORTABLE VARIANT MANDATE**: You MUST check for the existence of \"Portable\" versions (often for Windows and macOS). If they exist on the official site or trusted repositories (GitHub/PortableApps), extract their URLs and variants explicitly.\n"
			: '';

		$block_one = <<<'DISC_BLOCK_A'
You are a technical software auditor. Your task is to process technical context and reformat it into a structured schema.
Accuracy is your ONLY metric, but COMPREHENSIVENESS is your goal.

STRICT DISCOVERY RULES:
1. DATA PRIORITY:
- The provided CONTEXT HTML / CHANGELOG is your Primary Source of Truth.
- If the Software Name or Version in the Context HTML contradicts the Metadata, YOU MUST USE THE DATA FROM THE CONTEXT.

2. **SEARCH MANDATE**:
- You HAVE access to Google Search. If any technical metadata (License, Developer, File Size, Category) is missing or ambiguous in the CONTEXT, YOU MUST SEARCH FOR IT.
- **THOROUGHNESS**: Do not stop at the first result. Verify the official developer site. Identify the correct license (Freeware, Open Source, Trial, etc.).
DISC_BLOCK_A;

		$block_two = <<<'DISC_BLOCK_B'

7. DOWNLOAD LINKS: Extract all download links verbatim from the context. The system already handles referral link filtering and de-obfuscation; simply extract the URLs precisely as they appear in the source text. Whitelist GitHub, SourceForge, and Official App Stores.
8. FILE SIZE: Be aggressive in finding the file size. If not in the context, SEARCH for it. Extract it precisely.
9. DEVELOPER: Identify the developer. If not in the text, YOU MUST SEARCH for the official vendor. Do NOT leave null.

4. WRITING STYLE:
- YOU MUST FOLLOW THE EXACT SAME "HUMAN WRITING STYLE" (Sentence Variance, No Robotic Vocab, Syntax Variety) as defined for the regular mode.
- The site voice must remain consistent across all posts.

5. TAXONOMY:
- Map the detected software to the `VALID_TAXONOMY_MAP` slugs.
- FORMULA: You MUST select MULTIPLE categories. First, choose the supported Operating Systems. Then, choose the Software Type. Use SEARCH to verify categorization if unsure.

6. CATEGORIZATION:
- `category`: Return a comma-separated list of the selected category slugs.
10. **FILE SIZE RULE**:
- You MUST return only a single, clean value for `file_size` (e.g., '15.5 MB').
- If multiple installers or platforms exist, pick the primary Windows installer size.
- NEVER list multiple sizes or add parenthetical descriptions like '(online installer)' in the size field.
DISC_BLOCK_B;

		// [PHASE 3E, 2.33.0] SCOPED PAYLOAD: FAQ and MOAT mandates are appended
		// only when those sections are in the generation scope.
		if ( $_scope_wants('faqs') ) {
			$block_two_faqs = <<<'DISC_BLOCK_FAQS'
3. **FAQ GENERATION**:
- Generate 0-3 FAQs based on genuine user demand. Zero FAQs is acceptable for simple utilities where no real questions exist. Quality over quantity — 2 excellent FAQs beat 3 padded ones. RANDOMIZE: if the software has rich FAQ material, generate 2-3; if it's a simple tool, simply omit it.
- If the source doesn't contain FAQs, create them based on common user questions for this type of software (e.g., "Is [Software] free?", "Is it safe to download?", "What are the system requirements?").
- **SIMPLE_UTILITY FAQ RULE**: If software_type is SIMPLE_UTILITY, the faqs array MUST be empty []. Do NOT generate any FAQ content for simple utilities — not even one. This is a hard exclusion, not a suggestion.
- Ensure answers are VERSION-AGNOSTIC and journal-style. Write FAQs about the software in general (e.g., "Is Malwarebytes free?" NOT "Is Malwarebytes 5.5.5.253 free?"). These FAQs persist across version updates and must remain accurate regardless of version. Never embed specific version numbers in FAQ questions or answers.
DISC_BLOCK_FAQS;
			$block_two .= "\n" . $block_two_faqs;
		}
		if ( $_scope_wants('moat') ) {
			$block_two_moat = <<<'DISC_BLOCK_MOAT'
10. **MOAT SECTION**:
- `moat_data` is MANDATORY for every article. You MUST always include the key in your JSON response.
- **SIMPLE_UTILITY MOAT RULE**: If software_type is SIMPLE_UTILITY, set moat_data to `{}` (empty object). Do NOT generate any moat content — no headings, no recipes, no why text. This is a hard exclusion.
- For COMPLEX_ENGINE software: If the provided context does not contain "Quick Start" or "Settings" guides, YOU MUST SEARCH for "[software name] settings", "[software name] tips", "[software name] quick start guide".
- For COMPLEX_ENGINE software: Generate 2-3 practical settings recipes or quick-start steps that deliver real user value. NEVER pad with generic steps.
DISC_BLOCK_MOAT;
			// Re-scope legacy 'MANDATORY for every article' wording.
			$block_two_moat = str_replace('`moat_data` is MANDATORY for every article. You MUST always include the key in your JSON response.', '`moat_data` is requested in the JSON SCHEMA below - populate it as specified.', $block_two_moat);
			$block_two .= "\n" . $block_two_moat;
		}
		if ( ! $_scope_is_all ) {
			$block_two .= "\n12. SCOPE (STRICT): Generate ONLY the top-level keys present in the JSON SCHEMA below. Do NOT add sections, arrays, objects or fields for any key not shown in the schema - omit them entirely (empty array [] where an array is expected). The structural SEO keys (title, meta_description, focus_keyword, slug, tags, tech_specs, software_type, category) are always required.";
		}


		return $block_one . "\n" . $portable_line . $block_two;
	}

  /**
   * Map article sections to JSON schema keys for pruning.
   *
   * @param array $sections List of sections to include.
   * @return array List of schema keys to keep.
   */
  private function map_sections_to_keys(array $sections): array
  {
    $map = array(
      'hero'               => array('hero_section'),
      'introduction'       => array('introduction'),
      'moat'               => array('moat_data', 'software_type'),
      // [PHASE 3E, 2.33.0] download links are system-built; the AI is told NOT to generate download_section, so it is not requested as a key.

      'tech_specs'        => array('tech_specs', 'system_requirements'),
      'system_requirements' => array('system_requirements'),
      'features'           => array('features', '_features_note'),
      'whats_new'         => array('whats_new'),
      'pros_cons'         => array('pros_cons'),
      'installation'       => array('installation_guide'),
      'troubleshooting'    => array('installation_guide'),
      'video'              => array('video_url'),
      'faqs'               => array('faqs', '_faqs_note'),
      'competitors'        => array('competitors', 'comparison_field_order', 'main_software_comparison'),
      'related_software'  => array('related_software'),
      'tags'               => array('tags'),
    );

    $keys_to_keep = array('needs_manual_input');

    foreach ($sections as $section) {
      if (isset($map[$section])) {
        $keys_to_keep = array_merge($keys_to_keep, $map[$section]);
      }
    }

    // [FIX] Always request the AI 'tags' field (and its instruction note) so that
    // partial-regeneration / update jobs also produce AI-generated SEO hashtags for
    // social sharing (Buffer/Jetpack). Previously map_sections_to_keys() omitted
    // 'tags' for every non-'all' section set, so updates were shipped with no hashtags
    // (or, before the social-tag fix, with deterministic post tags/slugs/categories).
    // 'tags' is independent of which sections are regenerated and is cheap to include.
    $keys_to_keep[] = 'tags';
    $keys_to_keep[] = '_tags_note';

    return array_unique($keys_to_keep);
  }

  /**
   * Get the JSON schema structure with dynamic pruning.
   *
   * @param array                  $regen_sections Sections to include (['all'] for everything).
   * @param Generation_Context|null $context        Generation context for new post detection.
   * @return string
   */
  public function get_json_schema(array $regen_sections = array('all'), ?Generation_Context $context = null)
  {
    $full_schema_raw = <<<'SCHEMA'
{
  "title": "Software Name Version Download for Platform (Month Year) (e.g., VLC 3.0.20 Download for Windows (Mar 2026))",
  "meta_description": "130-160 chars. Write ONE natural, high-CTR sentence that leads with the user's primary benefit, names the license (Free / Open Source / Trial) and supported OS, and ends with a distinct, concrete CTA. Never use boilerplate filler such as 'features, and FAQ', 'Official/Safe download, features, requirements', or 'Get the official installer'. **Do NOT include the software version number OR the file size (e.g. '26 MB') in the meta description.** Keep phrasing plain and factual so it stays LLM-friendly.",
  "slug": "software-name",
  "_slug_note": "Natural slug based on software name and category, e.g., 'vlc-media-player', 'notepad-editor', not forced 'download' suffix",
  "focus_keyword": "software name",
  "_focus_keyword_note": "Software name only. Natural download intent conveyed through content, not keyword repetition",
  "long_tail_keywords": [
    "software name + platform + architecture (e.g., VLC Windows 11 64-bit)",
    "software name + installer type (e.g., VLC offline installer)",
    "software name + version + year (e.g., VLC 3.0.20 2024)"
  ],
  "lsi_keywords": [
    "term1 (e.g., multimedia framework)",
    "term2 (e.g., video playback)",
    "term3 (e.g., open source media player)",
    "term4",
    "term5"
  ],
  "needs_manual_input": [
    "tech_specs.homepage",
    "system_requirements.minimum.os"
    ],
  "_needs_manual_input_note": "Array of dot-notation field paths that are MISSING from web search and need human entry. Only use for verifiability fields: version, homepage, license, file_size, download_section.links.",
  "keyword_variations": [
    "download software name",
    "get software name",
    "software name installer",
    "software name for platform"
  ],
  "introduction": ["Paragraph 1", "Paragraph 2"],
  "tech_specs": {
    "software_name": "Full name",
    "file_name": "setup.exe or null if unknown",
    "version": "string or null - ONLY from official site, never guess",
    "license": "Free/Trial/Paid",
    "developer": "Company name (MUST extract)",
    "homepage": "URL",
    "changelogurl": "URL or null - ONLY from official site",
    "file_size": "string or null - ONLY if clearly shown on official page. If multiple sizes exist, pick the primary Windows size.",
    "os_support": "Comma-separated list of ALL supported platforms (e.g., Windows 11, 10; macOS 12+; Linux). MUST extract.",
    "language_support": "English, Spanish, French (multi-language)",
    "last_updated": "string or null - ONLY if explicitly dated. If active but date missing, use current Month YYYY."
  },
  "safety": {
    "verified_download": false,
    "file_hash": "SHA256 or MD5 string or null if unavailable",
    "scanned_by": "string or null if not verified"
  },
  "pros_cons": {
    "pros": ["Benefit 1", "Benefit 2", "Benefit 3"],
    "cons": ["Limitation 1", "Limitation 2"]
  },

  "video_url": "https://youtube.com/watch?v=... (Extract from provided context HTML if a YouTube/Vimeo link is present, OR from official site/YouTube channel). DO NOT fabricate. DO NOT use links that look like versions or dates (e.g. y-20-00-00-00). Leave empty string if no REAL video link is found.",
  "features": [
    {
      "name": "Feature Name",
      "description": "Detailed description (30-50 words)"
    }
  ],
  "_features_note": "5-8 items. Write detailed feature descriptions. If specific version features are missing, list CORE PERMANENT FEATURES.",
  "whats_new": [
    "ONLY items explicitly documented in official changelog for THIS version",
    "If vendor says 'bug fixes and improvements', use that exact phrase",
    "Make the changelog concise, short, and include only the most important points, up to a maximum of 8 bullet points.",
    "Empty array [] if no changelog found - do NOT invent features"
  ],
  "system_requirements": {
    "minimum": {
      "os": "string or null - only if explicitly stated",
      "processor": "string or null - only if explicitly stated",
      "ram": "string or null - NEVER assume '4 GB' unless written",
      "disk_space": "string or null - NEVER assume '500 MB' unless written",
      "graphics": "string or null - only if explicitly stated"
    },
    "recommended": {
      "os": "string or null",
      "processor": "string or null",
      "ram": "string or null",
      "disk_space": "string or null"
    },
    "_note": "Set entire minimum/recommended to null if no requirements documented. Ensure 'os' is populated if data exists."
  },
  "faqs": [
    {
      "question": "Download-intent question - exact focus keyword in at most 2 questions",
      "answer": "Concise answer - ONLY if verifiable from official sources"
    }
  ],
  "_faqs_note": "0-3 items max. Zero is acceptable. VERSION-AGNOSTIC only — never embed version numbers. If answer cannot be verified, omit the FAQ entirely. Do NOT invent licensing or pricing details. For SIMPLE_UTILITY, NO FAQ needed. For COMPLEX_ENGINE, prefer 2-3. Randomize between 0-3 to avoid pattern uniformity across the site.",
  "installation_guide": {
    "steps": [
      "Step 1: Click the download button above to get the installer for your operating system",
      "Step 2: Locate the downloaded file and double-click to run the installer",
      "Step 3: Follow the on-screen installation wizard to complete setup"
    ],
    "compatibility_notes": "Compatible with Windows 7 and later versions",
    "common_issues": [
      "Issue: Installation fails → Solution: Run as administrator"
    ]
  },
"tags": ["software-name", "freeware|shareware", "software-type-tag"],
  "_tags_note": "3-4 tags MAX. Each tag MUST be a SINGLE token with NO spaces — run words together or use camelCase (e.g., 'diskcleaner', 'privacytool', 'crossplatform', 'screencapture'). NEVER multi-word tags like 'disk cleaner' or 'privacy tool'. NEVER generic tags like 'software', 'download', 'utility', 'free', 'app', 'application'. Do NOT include version numbers, developer names, or any '#' symbol. License types: use 'freeware' (free/open source) or 'shareware' (trial/commercial/paid). Prefer: software subtype, license type (freeware/shareware).",
  "comparison_field_order": ["Price", "Platform", "Open Source", "File Size", "Key Strength", "Weakness vs Main"],
  "main_software_comparison": [
    {"field": "Price", "value": "Value for main software"},
    {"field": "Platform", "value": "Value for main software"},
    {"field": "Open Source", "value": "true/false/null"},
    {"field": "File Size", "value": "value or null"},
    {"field": "Key Strength", "value": "value or null"},
    {"field": "Weakness vs Main", "value": "N/A (this is the main software)"}
  ],
  "competitors": [
    {
      "name": "Alternative software name",
      "comparison_fields": [
        {"field": "Price", "value": "Free/Paid ($XX)"},
        {"field": "Platform", "value": "Windows, macOS, Linux"},
        {"field": "Open Source", "value": "true/false/null"},
        {"field": "File Size", "value": "XX MB or null"},
        {"field": "Key Strength", "value": "Main benefit of this alternative"},
        {"field": "Weakness vs Main", "value": "Why main software is better"}
      ],
      "verdict": "Best for [specific use case]"
    }
  ],
  "software_type": "MANDATORY. Classify as COMPLEX_ENGINE or SIMPLE_UTILITY. COMPLEX_ENGINE = richly configurable software requiring deep user expertise (video/audio editors, IDEs, security suites, database engines, VMs). SIMPLE_UTILITY = single-purpose or task-focused tools (file cleaners, format converters, screenshot tools, small utilities, media players). If uncertain, default to SIMPLE_UTILITY. SECTION_CONDITIONALS: If SIMPLE_UTILITY — set competitors to empty array [], set moat_data to empty object {}, and set faqs to empty array []. Do NOT generate any moat or FAQ content. If COMPLEX_ENGINE — generate 2-3 competitors and 2-3 moat items and 2-3 FAQs.",
  "moat_data": {
    "_note": "MANDATORY key — always include moat_data in your JSON response. First classify software_type. For SIMPLE_UTILITY, set to empty object {}. For COMPLEX_ENGINE, generate 2-3 items with heading/recipe/why structure. Do NOT skip this key.",
    "content": [
      {
        "heading": "Setting or Quick Start Topic",
        "recipe": "Steps as newline-separated list (each step on its own line, e.g., 1. Step one\n2. Step two)",
        "why": "Why this matters for the user - performance, quality, etc."
      }
    ]
  },
  "_moat_note": "0-3 items max. Zero is acceptable for simple tools with no meaningful settings. Focus on quality over quantity. Do NOT pad with generic steps. For SIMPLE_UTILITY, NO item needed. For COMPLEX_ENGINE, prefer 2-3.",
  "hero_section": {
    "software_name": "Smart context-aware full name (e.g. 'Opera Developer Browser' instead of just 'Opera' to avoid confusion)",
    "version": "version",
    "license": "license type",
    "file_size": "size or empty",
    "rating": 4.0,
    "download_links": [],
    "min_os": "minimum OS",
    "last_updated": "date"
  },
  "editor_rating": 0,
  "category": "Comma-separated list of chosen category slugs (Must include OS and Software Type from VALID_TAXONOMY_MAP)"
}
SCHEMA;

    if (in_array('all', $regen_sections, true)) {
      return $full_schema_raw;
    }

    $schema_array = json_decode($full_schema_raw, true);
    if (! is_array($schema_array)) {
      return $full_schema_raw;
    }

    $keys_to_include = $this->map_sections_to_keys($regen_sections);

	$is_new_post = $context instanceof Generation_Context && $context->type === 'new';
	$is_upgrade = $context instanceof Generation_Context && $context->type === 'upgrade';
	if ($is_new_post || $is_upgrade) {
		// [PHASE 3E, 2.33.0] SCOPED PAYLOAD - unified always-on structural
		// skeleton for full new / legacy-upgrade posts. These keys are
		// required for EVERY publishable post regardless of which content
		// sections the user toggled: SEO fields (title/slug/meta/keywords),
		// taxonomy category, tags (also force-added by map_sections_to_keys),
		// the tech_specs IDENTITY DTO (software_name/version/license/developer
		// /file size/OS support - feeds Hero_Data_Provider hero badge, Version
		// SSOT and Rank Math meta; the visible specs TABLE still renders only
		// when tech_specs is selected) and software_type (global SIMPLE_UTILITY
		// gate). Content sections come solely from map_sections_to_keys().
		$keys_to_include = array_merge(
			$keys_to_include,
			array(
				'title',
				'_slug_note',
				'slug',
				'meta_description',
				'focus_keyword',
				'_focus_keyword_note',
				'long_tail_keywords',
				'lsi_keywords',
				'keyword_variations',
				'category',
				'tech_specs',
				'software_type',
			)
		);
	}

    $keys_to_include = array_values(array_unique($keys_to_include));

    $resolved_section_keys = array_diff(
      $keys_to_include,
      array('needs_manual_input')
    );
    if (empty($resolved_section_keys)) {
      return $full_schema_raw;
    }

    foreach ($schema_array as $key => $value) {
      if (! in_array($key, $keys_to_include, true)) {
        unset($schema_array[$key]);
      }
    }

    // [PHASE 3E, 2.33.0] When competitors/faqs/moat keys are pruned, the
    // software_type schema description still tells the model to 'generate
    // 2-3 competitors and 2-3 moat items and 2-3 FAQs for COMPLEX_ENGINE'.
    // Neutralize that sentence so the scoped schema cannot resurrect pruned sections.
    $_scoped_json = json_encode($schema_array, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ( is_string($_scoped_json) ) {
      if ( ! in_array('competitors', $keys_to_include, true) ) {
        $_scoped_json = str_replace(
          'If COMPLEX_ENGINE — generate 2-3 competitors and 2-3 moat items and 2-3 FAQs.',
          'Only generate the keys present in this schema; omit competitors, moat_data and faqs unless their key is present.',
          $_scoped_json
        );
      }
      return $_scoped_json;
    }

    return $full_schema_raw;
  }
}
